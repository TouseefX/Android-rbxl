/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 25000 ; VA 0x00b7eaa0 ; FUN_00b7eaa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00b7eaa0(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = thunk_FUN_00b847d0();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ef1c14) {
      FUN_016f3809(&DAT_01ef1c14);
      if (DAT_01ef1c14 == -1) {
        _DAT_01ef1c08 = FUN_005c65e0;
        _DAT_01ef1c0c = FUN_005c65e0;
        _DAT_01ef1c10 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ef1c14);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01ef1c08) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01ef1c08;
  }
  return;
}



/* FUNCTION 25001 ; VA 0x00b7eb60 ; FUN_00b7eb60 */

void FUN_00b7eb60(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00b84860();
    *param_2 = uVar3;
    iVar4 = FUN_00b84ac0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 25002 ; VA 0x00b7ebc0 ; FUN_00b7ebc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00b7ebc0(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = thunk_FUN_00b84910();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ef1c04) {
      FUN_016f3809(&DAT_01ef1c04);
      if (DAT_01ef1c04 == -1) {
        _DAT_01ef1bf8 = FUN_005c65e0;
        _DAT_01ef1bfc = FUN_005c65e0;
        _DAT_01ef1c00 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ef1c04);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01ef1bf8) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01ef1bf8;
  }
  return;
}



/* FUNCTION 25003 ; VA 0x00b7ec80 ; FUN_00b7ec80 */

void FUN_00b7ec80(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00b849a0();
    *param_2 = uVar3;
    iVar4 = FUN_00b84b30();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 25004 ; VA 0x00b7ece0 ; FUN_00b7ece0 */

void FUN_00b7ece0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00b84a30();
    *param_2 = uVar3;
    iVar4 = FUN_00b84c10();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 25005 ; VA 0x00b7ed40 ; FUN_00b7ed40 */

void FUN_00b7ed40(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00b847d0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25006 ; VA 0x00b7ed80 ; FUN_00b7ed80 */

void FUN_00b7ed80(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b84860();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25007 ; VA 0x00b7edc0 ; FUN_00b7edc0 */

void FUN_00b7edc0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00b84910();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25008 ; VA 0x00b7ee00 ; FUN_00b7ee00 */

void FUN_00b7ee00(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00b849a0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25009 ; VA 0x00b7ee40 ; FUN_00b7ee40 */

void FUN_00b7ee40(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00b84a30();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25010 ; VA 0x00b7ee80 ; FUN_00b7ee80 */

void __thiscall FUN_00b7ee80(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_c [8];
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_c,param_2);
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,auStack_c);
  return;
}



/* FUNCTION 25011 ; VA 0x00b7eeb0 ; FUN_00b7eeb0 */

undefined4 * FUN_00b7eeb0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00634cd0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 25012 ; VA 0x00b7ef20 ; FUN_00b7ef20 */

undefined __thiscall FUN_00b7ef20(int param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined uVar4;
  float *pfVar5;
  undefined4 *puVar6;
  int iVar7;
  double dVar8;
  uint auStack_14 [4];
  
  if (*param_2 == 0) {
    return 0;
  }
  cVar3 = FUN_008ff170();
  if (cVar3 == '\0') goto LAB_00b7f0d2;
  cVar3 = FUN_00d81cb0();
  if ((cVar3 != '\0') && (*(char *)(*param_2 + 0xb4) != '\0')) {
    iVar7 = *(int *)(*param_2 + 0x54);
    if ((DAT_01ef1771 != '\0') && (cVar3 = FUN_00b82a50(), cVar3 != '\0')) {
      iVar7 = 7;
    }
    if (*(int *)(param_1 + 0x19c) != iVar7) {
      iVar2 = *(int *)(*param_2 + 0xa8);
      if ((((iVar2 == 0x3f8) || (iVar2 == 0x3f9)) || (iVar2 == 0x3ee)) || (iVar2 == 0x3ef)) {
        pfVar5 = (float *)FUN_00d81770(auStack_14);
        dVar8 = (double)(*pfVar5 * *pfVar5 + pfVar5[1] * pfVar5[1] + pfVar5[2] * pfVar5[2]);
        FUN_017267a0();
        if ((double)(float)dVar8 < DAT_018e2380) goto LAB_00b7f063;
      }
      if (iVar7 == 4) {
        if (*(int *)(*param_2 + 0x58) == 4) {
LAB_00b7f019:
          if (*(char *)(param_1 + 0x195) != '\x01') {
            *(undefined *)(param_1 + 0x195) = 1;
            FUN_008a4940(&DAT_0212d858);
          }
          if (*(char *)(param_1 + 0x194) != '\x01') {
            *(undefined *)(param_1 + 0x194) = 1;
            FUN_008a4940(&DAT_0212d820);
          }
        }
      }
      else if (iVar7 == 8) goto LAB_00b7f019;
      *(int *)(param_1 + 0x19c) = iVar7;
      FUN_005e6780(iVar7);
    }
  }
LAB_00b7f063:
  if (DAT_01d67708 == '\0') {
    FUN_00b77c00(param_2);
  }
  else {
    FUN_00b79ae0(param_2);
  }
  FUN_00b79e00(param_2);
  if (*(int *)(*param_2 + 0x54) == 2) {
    if (*(int *)(*param_2 + 0x5c) == 0) {
      puVar6 = (undefined4 *)FUN_00b788e0(auStack_14);
      *(undefined4 *)(param_1 + 500) = *puVar6;
      *(undefined4 *)(param_1 + 0x1f8) = puVar6[1];
    }
    else {
      *(undefined4 *)(param_1 + 500) = 0;
      *(undefined4 *)(param_1 + 0x1f8) = 0;
    }
  }
LAB_00b7f0d2:
  iVar7 = FUN_008f7870(param_1);
  if (iVar7 == 0) {
    return 0;
  }
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar4 = FUN_00906050(*param_2,param_2[1]);
  cVar3 = FUN_008ff170();
  if (cVar3 != '\0') {
    if (*(uint *)(*param_2 + 0x54) < 5) {
      FUN_006150c0(uVar4,param_2);
    }
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_0089bf10(*param_2,param_2[1],uVar4);
  }
  auStack_14[0] = auStack_14[0] & 0xffffff00;
  if ((iVar7 != -0xc) && (iVar7 = FUN_006ebb70(), iVar7 != 0)) {
    auStack_14[0] = CONCAT31(auStack_14[0]._1_3_,*(undefined *)(iVar7 + 0x16e));
  }
  FUN_00b84570(param_2,param_3,uVar4,auStack_14[0]);
  return uVar4;
}



/* FUNCTION 25013 ; VA 0x00b7f1c0 ; FUN_00b7f1c0 */

void __thiscall
FUN_00b7f1c0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ba5;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar3 = *(undefined4 **)(param_1 + 0x40);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088d730();
    iStack_e8 = 0;
    uStack_e4 = *puVar3;
    uStack_e0 = puVar3[1];
    iStack_e8 = FUN_006314d0();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar3 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar1 = FUN_0088d730();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x44);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar3 = &uStack_1bc;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_0088d730();
    iStack_e8 = 0;
    uStack_e4 = *puVar3;
    uStack_e0 = puVar3[1];
    iStack_e8 = FUN_006314d0();
    puVar3 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088d730();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 4) != 0) {
    uVar4 = uVar4 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x48);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar3 = &uStack_1bc;
    uStack_8 = 9;
    uVar4 = uVar4 | 0x20;
  }
  else {
    uStack_ec = FUN_0088d730();
    iStack_e8 = 0;
    uStack_e4 = *puVar3;
    uStack_e0 = puVar3[1];
    iStack_e8 = FUN_006314d0();
    puVar3 = &uStack_ec;
    uStack_8 = 8;
    uVar4 = uVar4 | 0x10;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088d730();
  uVar2 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 0x20) != 0) {
    uVar4 = uVar4 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 0x10) != 0) {
    uVar4 = uVar4 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar3 = &uStack_35c;
    uStack_8 = 0xd;
    uVar4 = uVar4 | 0x80;
  }
  else {
    uStack_28c = FUN_0088d730();
    iStack_288 = 0;
    uStack_284 = *puVar3;
    uStack_280 = puVar3[1];
    iStack_288 = FUN_006314d0();
    puVar3 = &uStack_28c;
    uStack_8 = 0xc;
    uVar4 = uVar4 | 0x40;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088d730();
  uVar2 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((char)uVar4 < '\0') {
    uVar4 = uVar4 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 0x40) != 0) && (uStack_8 = 0xf, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(&uStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25014 ; VA 0x00b7f5f0 ; FUN_00b7f5f0 */

void __thiscall FUN_00b7f5f0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar4 = 2;
  }
  else {
    uStack_ec = thunk_FUN_00b84a30();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar5;
    iStack_e8 = FUN_00b84c10();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar5 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar2 = thunk_FUN_00b84a30();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar1 = *(undefined **)(param_1 + 0x44);
  if (puVar1 == (undefined *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = FUN_0088daf0();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar1;
    iStack_1b8 = FUN_005c9ef0();
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25015 ; VA 0x00b7f810 ; FUN_00b7f810 */

void __thiscall FUN_00b7f810(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 auStack_1b4 [50];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_0088daf0();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar4 = *(undefined4 **)(param_1 + 0x40);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar3 = 2;
  }
  else {
    uStack_ec = thunk_FUN_00b84a30();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_00b84c10();
    puStack_18 = &uStack_ec;
    uVar3 = 1;
  }
  uStack_8 = (uint)(puVar4 == (undefined4 *)0x0);
  uStack_14 = uVar3;
  uVar1 = thunk_FUN_00b84a30();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar3 & 2) != 0) {
    uVar3 = uVar3 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar3;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar3 & 1) != 0) {
    uVar3 = uVar3 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar3;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 5;
    uVar3 = uVar3 | 8;
  }
  else {
    uStack_1bc = thunk_FUN_00896d50();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar4;
    iStack_1b8 = FUN_00897340();
    puVar4 = &uStack_1bc;
    uStack_8 = 4;
    uVar3 = uVar3 | 4;
  }
  uStack_14 = uVar3;
  uVar1 = thunk_FUN_00896d50();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar4);
  if ((uVar3 & 8) != 0) {
    uVar3 = uVar3 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar3;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar3 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25016 ; VA 0x00b7fa30 ; FUN_00b7fa30 */

void FUN_00b7fa30(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined param_6)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_360;
  undefined4 uStack_35c;
  undefined4 uStack_358;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f87da;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_360 = FUN_0088c960();
  uStack_35c = 0;
  uStack_358 = param_2;
  uStack_35c = FUN_00630820();
  iStack_8._0_1_ = 1;
  uStack_290 = FUN_0088d730();
  uStack_288 = param_3;
  uStack_28c = 0;
  uStack_284 = param_4;
  uStack_28c = FUN_006314d0();
  iStack_8._0_1_ = 2;
  uStack_1c0 = FUN_0088c960();
  uStack_1bc = 0;
  uStack_1b8 = param_5;
  uStack_1bc = FUN_00630820();
  iStack_8._0_1_ = 3;
  uStack_f0 = FUN_0088daf0();
  uStack_ec = 0;
  uStack_e8 = param_6;
  uStack_ec = FUN_005c9ef0();
  iStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_360,&uStack_20,piVar1);
  iStack_8._0_1_ = 5;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 6;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_360,0xd0,4,FUN_0056e5b0);
  iStack_8 = 7;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25017 ; VA 0x00b7fbc0 ; FUN_00b7fbc0 */

int FUN_00b7fbc0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
                undefined4 param_6,undefined param_7)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  code *pcVar4;
  undefined4 uVar5;
  int iVar6;
  undefined auStack_430 [208];
  undefined4 uStack_360;
  undefined4 uStack_35c;
  undefined4 uStack_358;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f884d;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290(DAT_02110da8);
  piVar3 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar4 = *(code **)(*piVar3 + 4);
  uStack_20 = uVar5;
  FUN_005c1420(&param_2);
  uStack_8._0_1_ = 2;
  uStack_360 = FUN_0088c960();
  uStack_35c = 0;
  uStack_358 = param_4;
  uStack_35c = FUN_00630820();
  uStack_8._0_1_ = 3;
  uStack_290 = FUN_0088c960();
  uStack_28c = 0;
  uStack_288 = param_5;
  uStack_28c = FUN_00630820();
  uStack_8._0_1_ = 4;
  FUN_00b79e60(&param_6);
  uStack_8._0_1_ = 5;
  uStack_f0 = FUN_0088daf0();
  uStack_ec = 0;
  uStack_e8 = param_7;
  uStack_ec = FUN_005c9ef0();
  uStack_8._0_1_ = 6;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(auStack_430,&uStack_20,piVar3);
  uStack_8._0_1_ = 7;
  (*pcVar4)(&uStack_1c);
  uStack_8._0_1_ = 8;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(auStack_430,0xd0,5,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  iVar6 = FUN_01675290(uVar5);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 25018 ; VA 0x00b7fd70 ; FUN_00b7fd70 */

int FUN_00b7fd70(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
                undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined param_9)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  code *pcVar4;
  undefined4 uVar5;
  int iVar6;
  undefined auStack_430 [208];
  undefined4 uStack_360;
  undefined4 uStack_35c;
  undefined4 uStack_358;
  undefined4 uStack_354;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f884d;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290(DAT_02110da8);
  piVar3 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar4 = *(code **)(*piVar3 + 4);
  uStack_20 = uVar5;
  FUN_005c1420(&param_2);
  uStack_8._0_1_ = 2;
  uStack_360 = FUN_0088d730();
  uStack_358 = param_4;
  uStack_35c = 0;
  uStack_354 = param_5;
  uStack_35c = FUN_006314d0();
  uStack_8._0_1_ = 3;
  uStack_290 = FUN_0088d730();
  uStack_288 = param_6;
  uStack_28c = 0;
  uStack_284 = param_7;
  uStack_28c = FUN_006314d0();
  uStack_8._0_1_ = 4;
  FUN_00b79e60(&param_8);
  uStack_8._0_1_ = 5;
  uStack_f0 = FUN_0088daf0();
  uStack_ec = 0;
  uStack_e8 = param_9;
  uStack_ec = FUN_005c9ef0();
  uStack_8._0_1_ = 6;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(auStack_430,&uStack_20,piVar3);
  uStack_8._0_1_ = 7;
  (*pcVar4)(&uStack_1c);
  uStack_8._0_1_ = 8;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(auStack_430,0xd0,5,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  iVar6 = FUN_01675290(uVar5);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 25019 ; VA 0x00b7ff20 ; FUN_00b7ff20 */

int FUN_00b7ff20(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  code *pcVar4;
  undefined4 uVar5;
  int iVar6;
  undefined auStack_290 [416];
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f88a7;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290(DAT_02110da8);
  piVar3 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar4 = *(code **)(*piVar3 + 4);
  uStack_20 = uVar5;
  FUN_005c1420(&param_2);
  uStack_8._0_1_ = 2;
  FUN_00b79e60(&param_4);
  uStack_8._0_1_ = 3;
  uStack_f0 = FUN_0088daf0();
  uStack_ec = 0;
  uStack_e8 = param_5;
  uStack_ec = FUN_005c9ef0();
  uStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(auStack_290,&uStack_20,piVar3);
  uStack_8._0_1_ = 5;
  (*pcVar4)(&uStack_1c);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(auStack_290,0xd0,3,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  iVar6 = FUN_01675290(uVar5);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 25020 ; VA 0x00b80070 ; FUN_00b80070 */

int FUN_00b80070(int param_1,undefined4 param_2,int *param_3,undefined param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  code *pcVar4;
  undefined4 uVar5;
  int iVar6;
  undefined auStack_1c0 [208];
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f88fc;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290(DAT_02110da8);
  piVar3 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar4 = *(code **)(*piVar3 + 4);
  uStack_20 = uVar5;
  FUN_005c1420(&param_2);
  uStack_8._0_1_ = 2;
  uStack_f0 = FUN_0088daf0();
  uStack_ec = 0;
  uStack_e8 = param_4;
  uStack_ec = FUN_005c9ef0();
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(auStack_1c0,&uStack_20,piVar3);
  uStack_8._0_1_ = 4;
  (*pcVar4)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(auStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  iVar6 = FUN_01675290(uVar5);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 25021 ; VA 0x00b801b0 ; FUN_00b801b0 */

int FUN_00b801b0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
                undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
                undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
                undefined4 param_14,undefined4 param_15)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  int *piStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3c7c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 1;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_1c0 = FUN_0088cdc0();
  uStack_1bc = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_1b8 = param_2;
  piStack_1b4 = param_3;
  uStack_1bc = FUN_006309e0();
  uStack_8._0_1_ = 2;
  uStack_f0 = FUN_00b00260();
  uStack_ec = 0;
  uStack_e8 = param_4;
  uStack_e4 = param_5;
  uStack_e0 = param_6;
  uStack_dc = param_7;
  uStack_d8 = param_8;
  uStack_d4 = param_9;
  uStack_d0 = param_10;
  uStack_cc = param_11;
  uStack_c8 = param_12;
  uStack_c4 = param_13;
  uStack_c0 = param_14;
  uStack_bc = param_15;
  uStack_ec = FUN_00630d60();
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,pcVar3);
  uStack_8._0_1_ = 4;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 25022 ; VA 0x00b80340 ; FUN_00b80340 */

int FUN_00b80340(int param_1,undefined4 param_2,int *param_3,undefined param_4)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  int *piStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3c7c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 1;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_1c0 = FUN_0088cdc0();
  uStack_1bc = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_1b8 = param_2;
  piStack_1b4 = param_3;
  uStack_1bc = FUN_006309e0();
  uStack_8._0_1_ = 2;
  uStack_f0 = FUN_0088daf0();
  uStack_ec = 0;
  uStack_e8 = param_4;
  uStack_ec = FUN_005c9ef0();
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,pcVar3);
  uStack_8._0_1_ = 4;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 25023 ; VA 0x00b804c0 ; FUN_00b804c0 */

void FUN_00b804c0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbcf9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_f0 = FUN_0088d730();
  uStack_e8 = param_2;
  uStack_ec = 0;
  uStack_e4 = param_3;
  uStack_ec = FUN_006314d0();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,piVar1);
  iStack_8._0_1_ = 2;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 3;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  iStack_8 = 4;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25024 ; VA 0x00b805c0 ; FUN_00b805c0 */

void FUN_00b805c0(int param_1,undefined4 param_2,undefined4 param_3,undefined param_4)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8524;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = FUN_0088d730();
  uStack_1b8 = param_2;
  uStack_1bc = 0;
  uStack_1b4 = param_3;
  uStack_1bc = FUN_006314d0();
  iStack_8._0_1_ = 1;
  uStack_f0 = FUN_0088daf0();
  uStack_ec = 0;
  uStack_e8 = param_4;
  uStack_ec = FUN_005c9ef0();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  iStack_8._0_1_ = 3;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 4;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  iStack_8 = 5;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25025 ; VA 0x00b806f0 ; FUN_00b806f0 */

void FUN_00b806f0(int param_1,undefined4 param_2,undefined4 param_3,undefined param_4)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e104f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_290 = FUN_00b84860();
  uStack_28c = 0;
  uStack_288 = param_2;
  uStack_28c = FUN_00b84ac0();
  iStack_8._0_1_ = 1;
  uStack_1c0 = FUN_0088c8c0();
  uStack_1bc = 0;
  uStack_1b8 = param_3;
  uStack_1bc = FUN_005c9cc0();
  iStack_8._0_1_ = 2;
  uStack_f0 = FUN_0088daf0();
  uStack_ec = 0;
  uStack_e8 = param_4;
  uStack_ec = FUN_005c9ef0();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,piVar1);
  iStack_8._0_1_ = 4;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 5;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  iStack_8 = 6;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25026 ; VA 0x00b80840 ; FUN_00b80840 */

void FUN_00b80840(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined4 param_14)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8524;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = thunk_FUN_00b849a0();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1bc = FUN_00b84b30();
  iStack_8._0_1_ = 1;
  uStack_f0 = FUN_00b00260();
  uStack_ec = 0;
  uStack_e8 = param_3;
  uStack_e4 = param_4;
  uStack_e0 = param_5;
  uStack_dc = param_6;
  uStack_d8 = param_7;
  uStack_d4 = param_8;
  uStack_d0 = param_9;
  uStack_cc = param_10;
  uStack_c8 = param_11;
  uStack_c4 = param_12;
  uStack_c0 = param_13;
  uStack_bc = param_14;
  uStack_ec = FUN_00630d60();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  iStack_8._0_1_ = 3;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 4;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  iStack_8 = 5;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25027 ; VA 0x00b80980 ; FUN_00b80980 */

void FUN_00b80980(int param_1,undefined4 param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbcf9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_f0 = thunk_FUN_00b84a30();
  uStack_ec = 0;
  uStack_e8 = param_2;
  uStack_ec = FUN_00b84c10();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,piVar1);
  iStack_8._0_1_ = 2;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 3;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  iStack_8 = 4;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25028 ; VA 0x00b80a80 ; FUN_00b80a80 */

int __fastcall FUN_00b80a80(int param_1)

{
  float fVar1;
  uint3 uVar2;
  float *pfVar3;
  float *pfVar4;
  undefined2 uVar5;
  undefined auStack_14 [8];
  undefined auStack_c [8];
  
  pfVar3 = (float *)(**(code **)(param_1 + 8))(auStack_c);
  pfVar4 = (float *)(**(code **)(param_1 + 8))(auStack_14);
  fVar1 = *pfVar3;
  uVar5 = (undefined2)((uint)pfVar4 >> 0x10);
  uVar2 = CONCAT21(uVar5,(fVar1 == *pfVar4) << 6 | (NAN(fVar1) || NAN(*pfVar4)) << 2 | 2U |
                         fVar1 < *pfVar4);
  if ((NAN(fVar1) || NAN(*pfVar4)) != (fVar1 == *pfVar4)) {
    fVar1 = pfVar3[1];
    pfVar4 = pfVar4 + 1;
    uVar2 = CONCAT21(uVar5,(fVar1 == *pfVar4) << 6 | (NAN(fVar1) || NAN(*pfVar4)) << 2 | 2U |
                           fVar1 < *pfVar4);
    if ((NAN(fVar1) || NAN(*pfVar4)) != (fVar1 == *pfVar4)) {
      return CONCAT31(uVar2,1);
    }
  }
  return (uint)uVar2 << 8;
}



/* FUNCTION 25029 ; VA 0x00b80ae0 ; FUN_00b80ae0 */

undefined4 __thiscall FUN_00b80ae0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01256300(param_3);
  uVar2 = FUN_00b81e50(param_3,param_4,1,iVar1 - param_4,param_1 + 0x40);
  uVar2 = (**(code **)(param_1 + 0x38))(aiStack_28,uVar2);
  uStack_8 = 0;
  uVar2 = FUN_009d5710(param_3,uVar2);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar1 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar1 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 25030 ; VA 0x00b80b90 ; FUN_00b80b90 */

undefined4 __thiscall FUN_00b80b90(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795998;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_3);
  uVar3 = FUN_00b821b0(param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  uVar3 = (**(code **)(param_1 + 0x38))(auStack_18,uVar3);
  uStack_8 = 0;
  uVar3 = FUN_009d5950(param_3,uVar3);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 25031 ; VA 0x00b80c40 ; FUN_00b80c40 */

undefined4 FUN_00b80c40(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined auStack_144 [48];
  undefined4 uStack_114;
  int iStack_110;
  undefined auStack_10c [200];
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8927;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300(param_2);
  iVar1 = param_3;
  iVar3 = iVar3 - param_3;
  if (0 < iVar3) {
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1a84)
       && (FUN_016f3809(&DAT_01ef1a84), DAT_01ef1a84 == -1)) {
      uStack_8 = 0;
      FUN_00baf9b0();
      FUN_016f3654(&LAB_018903c0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ef1a84);
    }
    cVar2 = FUN_009d1e20(&DAT_01ef1a20,param_2,iVar1 + 1,&param_3);
    iVar6 = param_3;
    if (cVar2 != '\0') goto LAB_00b80d64;
  }
  if (0 < iVar3) {
    uStack_114 = FUN_00888530();
    iStack_110 = 0;
    uStack_8 = 1;
    cVar2 = FUN_009d1bf0(param_2,iVar1 + 1,&uStack_114,1);
    if (cVar2 != '\0') {
      piVar4 = (int *)FUN_00baf470();
      iVar6 = *piVar4;
      uStack_8 = 2;
      if (iStack_110 != 0) {
        (**(code **)(iStack_110 + 8))(auStack_10c);
      }
      uStack_8 = 0xffffffff;
      goto LAB_00b80d64;
    }
    uStack_8 = 3;
    if (iStack_110 != 0) {
      (**(code **)(iStack_110 + 8))(auStack_10c);
    }
    uStack_8 = 0xffffffff;
  }
  if (*(int **)(iStack_14 + 0x40) == (int *)0x0) {
    FUN_016756b0(&uStack_20,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(&uStack_20,&DAT_01c17198);
  }
  iVar6 = **(int **)(iStack_14 + 0x40);
LAB_00b80d64:
  puVar5 = (undefined4 *)(**(code **)(iStack_14 + 0x38))(auStack_144,iVar6);
  uStack_24 = *puVar5;
  uStack_20 = puVar5[1];
  uStack_1c = puVar5[2];
  uStack_18 = puVar5[3];
  uStack_34 = puVar5[4];
  uStack_30 = puVar5[5];
  uStack_2c = puVar5[6];
  uStack_28 = puVar5[7];
  uStack_44 = puVar5[8];
  uStack_40 = puVar5[9];
  uStack_3c = puVar5[10];
  uStack_38 = puVar5[0xb];
  puVar5 = (undefined4 *)FUN_0087ddc0(param_2,PTR_DAT_01d6d364,0x30,DAT_01ede6d4);
  *puVar5 = uStack_24;
  puVar5[1] = uStack_20;
  puVar5[2] = uStack_1c;
  puVar5[3] = uStack_18;
  puVar5[4] = uStack_34;
  puVar5[5] = uStack_30;
  puVar5[6] = uStack_2c;
  puVar5[7] = uStack_28;
  puVar5[8] = uStack_44;
  puVar5[9] = uStack_40;
  puVar5[10] = uStack_3c;
  puVar5[0xb] = uStack_38;
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 25032 ; VA 0x00b80e50 ; FUN_00b80e50 */

undefined4 __thiscall FUN_00b80e50(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined auStack_10 [8];
  undefined4 uStack_8;
  
  puVar2 = (undefined4 *)(**(code **)(param_1 + 0x38))(auStack_10);
  uVar1 = *puVar2;
  uStack_8 = puVar2[1];
  puVar2 = (undefined4 *)FUN_0087ddc0(param_3,PTR_s_Vector2_01d6d384,8,DAT_01ede6c4);
  *puVar2 = uVar1;
  puVar2[1] = uStack_8;
  return 1;
}



/* FUNCTION 25033 ; VA 0x00b80ea0 ; FUN_00b80ea0 */

undefined4 __thiscall FUN_00b80ea0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f894c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = (**(code **)(param_1 + 0x38))();
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1b54) {
    FUN_016f3809(&DAT_01ef1b54);
    if (DAT_01ef1b54 == -1) {
      uStack_8 = 0;
      FUN_00e034e0();
      FUN_016f3654(&LAB_01890360);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ef1b54);
    }
  }
  iVar2 = FUN_009cb050(uVar1);
  if (iVar2 == 0) {
    FUN_01256980(param_3);
  }
  else {
    FUN_00880a00(param_3,iVar2);
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 25034 ; VA 0x00b80f70 ; FUN_00b80f70 */

undefined4 __thiscall FUN_00b80f70(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f896c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = (**(code **)(param_1 + 0x38))();
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1bbc) {
    FUN_016f3809(&DAT_01ef1bbc);
    if (DAT_01ef1bbc == -1) {
      uStack_8 = 0;
      FUN_00e03540();
      FUN_016f3654(&LAB_018903a0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ef1bbc);
    }
  }
  iVar2 = FUN_009cb050(uVar1);
  if (iVar2 == 0) {
    FUN_01256980(param_3);
  }
  else {
    FUN_00880a00(param_3,iVar2);
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 25035 ; VA 0x00b81040 ; FUN_00b81040 */

undefined4 __thiscall FUN_00b81040(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = (**(code **)(param_1 + 0x38))();
  FUN_00b84a30();
  iVar2 = FUN_009cb050(uVar1);
  if (iVar2 != 0) {
    FUN_00880a00(param_3,iVar2);
    return 1;
  }
  FUN_01256980(param_3);
  return 1;
}



/* FUNCTION 25036 ; VA 0x00b81090 ; FUN_00b81090 */

undefined4 FUN_00b81090(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined auStack_30 [8];
  undefined auStack_28 [8];
  undefined auStack_20 [8];
  undefined auStack_18 [8];
  undefined4 uStack_10;
  int iStack_c;
  int iStack_8;
  
  iVar1 = FUN_01256300(param_2);
  iVar1 = iVar1 - param_3;
  iStack_c = iVar1;
  uStack_10 = FUN_00b5e260(auStack_18,param_2,param_3,4,iVar1,iStack_8 + 0x4c);
  uVar2 = FUN_00b5e260(auStack_20,param_2,param_3,3,iVar1,iStack_8 + 0x48);
  uVar3 = FUN_00b5e260(auStack_28,param_2,param_3,2,iVar1,iStack_8 + 0x44);
  uVar4 = FUN_00b5e260(auStack_30,param_2,param_3,1,iStack_c,iStack_8 + 0x40);
  (**(code **)(iStack_8 + 0x38))(uVar4,uVar3,uVar2,uStack_10);
  return 0;
}



/* FUNCTION 25037 ; VA 0x00b81140 ; FUN_00b81140 */

undefined4 __thiscall FUN_00b81140(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined uVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar2 = FUN_01256300(param_3);
  uVar1 = FUN_009d1aa0(param_3,param_4,2,iVar2 - param_4,param_1 + 0x44);
  uVar3 = FUN_00b821b0(param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  (**(code **)(param_1 + 0x38))(uVar3,uVar1);
  return 0;
}



/* FUNCTION 25038 ; VA 0x00b811a0 ; FUN_00b811a0 */

void __thiscall FUN_00b811a0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_01256300(param_3);
  uVar2 = FUN_00b81e50(param_3,param_4,1,iVar1 - param_4,param_1 + 0x40);
  uVar2 = (**(code **)(param_1 + 0x38))(uVar2);
  FUN_009d5ac0(param_3,uVar2);
  return;
}



/* FUNCTION 25039 ; VA 0x00b811f0 ; FUN_00b811f0 */

void __thiscall FUN_00b811f0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_01256300(param_3);
  uVar2 = FUN_00b821b0(param_3,param_4,1,iVar1 - param_4,param_1 + 0x40);
  uVar2 = (**(code **)(param_1 + 0x38))(uVar2);
  FUN_009d5ac0(param_3,uVar2);
  return;
}



/* FUNCTION 25040 ; VA 0x00b81240 ; FUN_00b81240 */

void __thiscall FUN_00b81240(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  iVar1 = FUN_01256300(param_3);
  uVar2 = FUN_00b81e50(param_3,param_4,2,iVar1 - param_4,param_1 + 0x44);
  uVar3 = FUN_00b821b0(param_3,param_4,1,iVar1 - param_4,param_1 + 0x40);
  uVar2 = (**(code **)(param_1 + 0x38))(uVar3,uVar2);
  FUN_009d5ac0(param_3,uVar2);
  return;
}



/* FUNCTION 25041 ; VA 0x00b812b0 ; FUN_00b812b0 */

void FUN_00b812b0(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  undefined *puVar8;
  undefined4 *puVar9;
  int *piVar10;
  undefined4 uStack_18;
  
  iVar5 = *param_2;
  iVar6 = *(int *)(iVar5 + 0x270);
  iVar7 = FUN_0088daf0();
  if (iVar6 == iVar7) {
    puVar8 = (undefined *)(iVar5 + 0x278);
    if (*(int *)(iVar5 + 0x274) == 0) {
      puVar8 = (undefined *)0x0;
    }
    uVar4 = *puVar8;
    iVar5 = *param_2;
    iVar6 = *(int *)(iVar5 + 0x1a0);
    iVar7 = FUN_0088c960();
    if (iVar6 == iVar7) {
      puVar9 = (undefined4 *)(iVar5 + 0x1a8);
      if (*(int *)(iVar5 + 0x1a4) == 0) {
        puVar9 = (undefined4 *)0x0;
      }
      uVar1 = *puVar9;
      iVar5 = *param_2;
      iVar6 = *(int *)(iVar5 + 0xd0);
      iVar7 = FUN_0088d730();
      if (iVar6 == iVar7) {
        param_2 = (int *)*param_2;
        puVar9 = (undefined4 *)(iVar5 + 0xd8);
        iVar6 = *param_2;
        if (*(int *)(iVar5 + 0xd4) == 0) {
          puVar9 = (undefined4 *)0x0;
        }
        uVar2 = *puVar9;
        uVar3 = puVar9[1];
        iVar7 = FUN_0088c960();
        if (iVar6 == iVar7) {
          piVar10 = param_2 + 2;
          if (param_2[1] == 0) {
            piVar10 = (int *)0x0;
          }
          uStack_18 = CONCAT31((int3)((uint)(iVar5 + 0xd0) >> 8),uVar4);
          FUN_00b7ca70(*piVar10,uVar2,uVar3,uVar1,uStack_18);
          return;
        }
      }
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25042 ; VA 0x00b813d0 ; FUN_00b813d0 */

void FUN_00b813d0(undefined4 param_1,undefined4 param_2)

{
  FUN_00b7a950(param_1,param_2,param_2);
  return;
}



/* FUNCTION 25043 ; VA 0x00b813f0 ; FUN_00b813f0 */

void FUN_00b813f0(undefined4 param_1,undefined4 param_2)

{
  FUN_00b7aaf0(param_1,param_2,param_2);
  return;
}



/* FUNCTION 25044 ; VA 0x00b81410 ; FUN_00b81410 */

void FUN_00b81410(undefined4 param_1,int *param_2)

{
  undefined uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined *puVar4;
  undefined4 *puVar5;
  int iVar6;
  int *piVar7;
  int iVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8988;
  pvStack_10 = ExceptionList;
  iVar8 = *param_2;
  iVar6 = *(int *)(iVar8 + 0x1a0);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088daf0();
  if (iVar6 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar4 = (undefined *)(iVar8 + 0x1a8);
  iVar6 = *param_2;
  if (*(int *)(iVar8 + 0x1a4) == 0) {
    puVar4 = (undefined *)0x0;
  }
  iVar8 = *(int *)(iVar6 + 0xd0);
  uVar1 = *puVar4;
  iVar3 = thunk_FUN_00d82070();
  if (iVar8 == iVar3) {
    puVar5 = (undefined4 *)(iVar6 + 0xd8);
    param_2 = (int *)*param_2;
    if (*(int *)(iVar6 + 0xd4) == 0) {
      puVar5 = (undefined4 *)0x0;
    }
    iVar8 = *param_2;
    uVar2 = *puVar5;
    iVar6 = FUN_008882f0();
    if (iVar8 == iVar6) {
      piVar7 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar7 = (int *)0x0;
      }
      iVar8 = piVar7[1];
      if (iVar8 != 0) {
        LOCK();
        *(int *)(iVar8 + 4) = *(int *)(iVar8 + 4) + 1;
        UNLOCK();
        iVar8 = piVar7[1];
      }
      uStack_8 = 0;
      FUN_00b7cd90(*piVar7,iVar8,uVar2,CONCAT31((int3)((uint)puVar4 >> 8),uVar1));
      ExceptionList = pvStack_10;
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25045 ; VA 0x00b81520 ; FUN_00b81520 */

void FUN_00b81520(undefined4 param_1,int *param_2)

{
  undefined uVar1;
  int iVar2;
  undefined *puVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795998;
  pvStack_10 = ExceptionList;
  iVar6 = *param_2;
  iVar4 = *(int *)(iVar6 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088daf0();
  if (iVar4 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar3 = (undefined *)(iVar6 + 0xd8);
  param_2 = (int *)*param_2;
  if (*(int *)(iVar6 + 0xd4) == 0) {
    puVar3 = (undefined *)0x0;
  }
  iVar6 = *param_2;
  uVar1 = *puVar3;
  iVar4 = FUN_008882f0();
  if (iVar6 == iVar4) {
    piVar5 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar5 = (int *)0x0;
    }
    iVar6 = piVar5[1];
    if (iVar6 != 0) {
      LOCK();
      *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
      UNLOCK();
      iVar6 = piVar5[1];
    }
    uStack_8 = 0;
    FUN_00b7ce90(*piVar5,iVar6,CONCAT31((int3)((uint)puVar3 >> 8),uVar1));
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25046 ; VA 0x00b815f0 ; FUN_00b815f0 */

void __thiscall FUN_00b815f0(int param_1,undefined4 param_2,int *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  int iVar13;
  undefined4 *puVar14;
  int iVar15;
  int *piVar16;
  int iVar17;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017a9558;
  pvStack_1c = ExceptionList;
  iVar17 = *param_3;
  iVar15 = *(int *)(iVar17 + 0xd0);
  ExceptionList = &pvStack_1c;
  iVar13 = FUN_00b00260();
  if (iVar15 != iVar13) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar14 = (undefined4 *)(iVar17 + 0xd8);
  if (*(int *)(iVar17 + 0xd4) == 0) {
    puVar14 = (undefined4 *)0x0;
  }
  uVar1 = *puVar14;
  uVar2 = puVar14[1];
  uVar3 = puVar14[2];
  uVar4 = puVar14[3];
  uVar5 = puVar14[4];
  uVar6 = puVar14[5];
  uVar7 = puVar14[6];
  uVar8 = puVar14[7];
  uVar9 = puVar14[8];
  uVar10 = puVar14[9];
  uVar11 = puVar14[10];
  uVar12 = puVar14[0xb];
  param_3 = (int *)*param_3;
  iVar17 = *param_3;
  iVar15 = FUN_0088cdc0();
  if (iVar17 == iVar15) {
    piVar16 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar16 = (int *)0x0;
    }
    iVar17 = piVar16[1];
    if (iVar17 != 0) {
      LOCK();
      *(int *)(iVar17 + 4) = *(int *)(iVar17 + 4) + 1;
      UNLOCK();
      iVar17 = piVar16[1];
    }
    iVar15 = *piVar16;
    uStack_14 = 0;
    (**(code **)(param_1 + 0x38))(1);
    FUN_00b7cf90(iVar15,iVar17,uVar1,uVar2,uVar3,uVar4,uVar5,uVar6,uVar7,uVar8,uVar9,uVar10,uVar11,
                 uVar12);
    ExceptionList = pvStack_1c;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25047 ; VA 0x00b81720 ; FUN_00b81720 */

void __thiscall FUN_00b81720(int param_1,undefined4 param_2,int *param_3)

{
  undefined uVar1;
  int iVar2;
  undefined *puVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8348;
  pvStack_10 = ExceptionList;
  iVar6 = *param_3;
  iVar4 = *(int *)(iVar6 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088daf0();
  if (iVar4 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar3 = (undefined *)(iVar6 + 0xd8);
  param_3 = (int *)*param_3;
  if (*(int *)(iVar6 + 0xd4) == 0) {
    puVar3 = (undefined *)0x0;
  }
  iVar6 = *param_3;
  uVar1 = *puVar3;
  iVar4 = FUN_0088cdc0();
  if (iVar6 == iVar4) {
    piVar5 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar5 = (int *)0x0;
    }
    iVar6 = piVar5[1];
    if (iVar6 != 0) {
      LOCK();
      *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
      UNLOCK();
      iVar6 = piVar5[1];
    }
    iVar4 = *piVar5;
    uStack_8 = 0;
    (**(code **)(param_1 + 0x38))(1);
    FUN_0089bf10(iVar4,iVar6,CONCAT31((int3)((uint)puVar3 >> 8),uVar1));
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25048 ; VA 0x00b81800 ; FUN_00b81800 */

void FUN_00b81800(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar2 = FUN_0088d730();
  if (iVar1 == iVar2) {
    piVar3 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_00997470(*piVar3,piVar3[1]);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25049 ; VA 0x00b81860 ; FUN_00b81860 */

void FUN_00b81860(undefined4 param_1,int *param_2)

{
  undefined uVar1;
  int iVar2;
  int iVar3;
  undefined *puVar4;
  int iVar5;
  int *piVar6;
  
  iVar2 = *param_2;
  iVar5 = *(int *)(iVar2 + 0xd0);
  iVar3 = FUN_0088daf0();
  if (iVar5 == iVar3) {
    puVar4 = (undefined *)(iVar2 + 0xd8);
    if (*(int *)(iVar2 + 0xd4) == 0) {
      puVar4 = (undefined *)0x0;
    }
    uVar1 = *puVar4;
    param_2 = (int *)*param_2;
    iVar2 = *param_2;
    iVar5 = FUN_0088d730();
    if (iVar2 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
      FUN_0091c070(*piVar6,piVar6[1],uVar1);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25050 ; VA 0x00b81910 ; FUN_00b81910 */

void FUN_00b81910(undefined4 param_1,int *param_2)

{
  undefined uVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  undefined *puVar6;
  undefined4 *puVar7;
  int iVar8;
  int *piVar9;
  
  piVar3 = param_2;
  iVar2 = *param_2;
  iVar8 = *(int *)(iVar2 + 0x1a0);
  iVar5 = FUN_0088daf0();
  if (iVar8 == iVar5) {
    puVar6 = (undefined *)(iVar2 + 0x1a8);
    iVar8 = *param_2;
    if (*(int *)(iVar2 + 0x1a4) == 0) {
      puVar6 = (undefined *)0x0;
    }
    iVar2 = *(int *)(iVar8 + 0xd0);
    uVar1 = *puVar6;
    param_2 = (int *)CONCAT13(uVar1,param_2._0_3_);
    iVar5 = FUN_0088c8c0();
    if (iVar2 == iVar5) {
      puVar7 = (undefined4 *)(iVar8 + 0xd8);
      piVar3 = (int *)*piVar3;
      if (*(int *)(iVar8 + 0xd4) == 0) {
        puVar7 = (undefined4 *)0x0;
      }
      iVar2 = *piVar3;
      uVar4 = *puVar7;
      iVar8 = FUN_00b84860();
      if (iVar2 == iVar8) {
        piVar9 = piVar3 + 2;
        if (piVar3[1] == 0) {
          piVar9 = (int *)0x0;
        }
        param_2 = (int *)CONCAT31(param_2._1_3_,uVar1);
        FUN_00a51eb0(*piVar9,uVar4,param_2);
        return;
      }
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25051 ; VA 0x00b819c0 ; FUN_00b819c0 */

void FUN_00b819c0(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  int iVar14;
  undefined4 *puVar15;
  int iVar16;
  int *piVar17;
  
  iVar1 = *param_2;
  iVar16 = *(int *)(iVar1 + 0xd0);
  iVar14 = FUN_00b00260();
  if (iVar16 == iVar14) {
    puVar15 = (undefined4 *)(iVar1 + 0xd8);
    if (*(int *)(iVar1 + 0xd4) == 0) {
      puVar15 = (undefined4 *)0x0;
    }
    uVar2 = *puVar15;
    uVar3 = puVar15[1];
    uVar4 = puVar15[2];
    uVar5 = puVar15[3];
    uVar6 = puVar15[4];
    uVar7 = puVar15[5];
    uVar8 = puVar15[6];
    uVar9 = puVar15[7];
    uVar10 = puVar15[8];
    uVar11 = puVar15[9];
    uVar12 = puVar15[10];
    uVar13 = puVar15[0xb];
    param_2 = (int *)*param_2;
    iVar1 = *param_2;
    iVar16 = thunk_FUN_00b849a0();
    if (iVar1 == iVar16) {
      piVar17 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar17 = (int *)0x0;
      }
      FUN_00b7d0c0(*piVar17,uVar2,uVar3,uVar4,uVar5,uVar6,uVar7,uVar8,uVar9,uVar10,uVar11,uVar12,
                   uVar13);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25052 ; VA 0x00b81a80 ; FUN_00b81a80 */

void FUN_00b81a80(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar2 = thunk_FUN_00b84a30();
  if (iVar1 == iVar2) {
    piVar3 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_005e6780(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25053 ; VA 0x00b81ad0 ; FUN_00b81ad0 */

uint FUN_00b81ad0(int *param_1)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined8 *puVar6;
  int iVar7;
  uint uVar8;
  int aiStack_3c [5];
  uint uStack_28;
  undefined auStack_24 [8];
  undefined auStack_1c [8];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar4 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f89b0;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  uVar8 = *(uint *)(iVar5 + 0x54);
  if ((((uVar8 < 5) || (uVar8 == 7)) || (uVar8 == 5)) || (ExceptionList = &pvStack_10, uVar8 == 6))
  {
    ExceptionList = &pvStack_10;
    FUN_0054ef60(iVar5 + 0xc0);
    uStack_8 = 0;
    iVar5 = FUN_00b82fc0(aiStack_3c);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_28) {
      uVar8 = uStack_28 + 1;
      iVar7 = aiStack_3c[0];
      if (0xfff < uVar8) {
        iVar7 = *(int *)(aiStack_3c[0] + -4);
        uVar8 = uStack_28 + 0x24;
        if (0x1f < (aiStack_3c[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar7,uVar8);
    }
    puVar6 = (undefined8 *)FUN_00d816e0(auStack_1c);
    *(undefined8 *)(iVar5 + 0x24) = *puVar6;
    *(undefined4 *)(iVar5 + 0x2c) = *(undefined4 *)(puVar6 + 1);
    iVar5 = *piVar4;
  }
  if ((*(int *)(iVar5 + 0x54) == 8) && (0 < *(int *)(iVar5 + 0xb0))) {
    FUN_0054ef60(iVar5 + 0xc0);
    uStack_8 = 1;
    iVar5 = FUN_00b82fc0(aiStack_3c);
    uStack_8 = 0xffffffff;
    uVar8 = FUN_005507b0();
    piVar3 = *(int **)(iVar5 + 0x1c);
    if (piVar3 != (int *)0x0) {
      iVar5 = piVar3[3];
      iVar7 = FUN_00c3ebd0();
      uVar8 = (uint)*(ushort *)(iVar7 + 0x1da);
      if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <= uVar8) {
        uVar8 = (**(code **)(*piVar3 + 0xa4))(auStack_24,piVar4);
        if (piStack_14 != (int *)0x0) {
          LOCK();
          puVar1 = (uint *)(piStack_14 + 2);
          uVar2 = *puVar1;
          uVar8 = *puVar1;
          *puVar1 = uVar2 - 1;
          UNLOCK();
          if (uVar2 - 1 == 0) {
            uVar8 = (**(code **)(*piStack_14 + 4))();
          }
        }
      }
    }
    ExceptionList = pvStack_10;
    return uVar8 & 0xffffff00;
  }
  FUN_00b782e0(piVar4);
  uVar8 = FUN_00b7ef20(piVar4,&param_1);
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 25054 ; VA 0x00b81c70 ; FUN_00b81c70 */

uint FUN_00b81c70(int *param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  uint *puVar7;
  int *piVar8;
  int *piVar9;
  uint auStack_1b0 [50];
  int iStack_e8;
  undefined4 *puStack_e4;
  uint auStack_e0 [50];
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f89de;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005e6780(param_1);
  iVar3 = FUN_00b7c6f0(&param_1);
  piVar8 = *(int **)(iVar3 + 8);
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
    piVar8 = *(int **)(iVar3 + 8);
  }
  piVar1 = *(int **)(iVar3 + 4);
  uStack_8 = 0;
  param_1 = piVar1;
  piStack_18 = piVar1;
  piStack_14 = piVar8;
  thunk_FUN_00896d50();
  auStack_1b0[0] = param_2;
  iVar3 = FUN_00897340();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if ((piVar1 != (int *)0x0) && (piVar9 = (int *)*piVar1, piVar9 != (int *)piVar1[1])) {
    do {
      puVar4 = (undefined4 *)piVar9[1];
      iStack_e8 = *piVar9;
      puStack_e4 = (undefined4 *)0x0;
      if (puVar4 != (undefined4 *)0x0) {
        (*(code *)*puVar4)(piVar9 + 2,auStack_e0);
        puVar4 = (undefined4 *)piVar9[1];
      }
      iVar6 = iStack_e8;
      uStack_8._0_1_ = 2;
      puStack_e4 = puVar4;
      iVar5 = thunk_FUN_00896d50();
      iVar2 = iStack_e8;
      if (iVar6 == iVar5) {
        iVar6 = thunk_FUN_00896d50();
        if (iVar2 != iVar6) {
                    /* WARNING: Subroutine does not return */
          FUN_016757c0("Variant cast failed");
        }
        puVar7 = auStack_e0;
        if (puStack_e4 == (undefined4 *)0x0) {
          puVar7 = (uint *)0x0;
        }
        if (*puVar7 == param_2) {
          uStack_8 = CONCAT31(uStack_8._1_3_,3);
          if (puStack_e4 != (undefined4 *)0x0) {
            (*(code *)puStack_e4[2])(auStack_e0);
          }
          param_2 = CONCAT13(1,(undefined3)param_2);
          goto LAB_00b81de9;
        }
      }
      uStack_8._0_1_ = 4;
      if (puStack_e4 != (undefined4 *)0x0) {
        (*(code *)puStack_e4[2])(auStack_e0);
      }
      piVar9 = piVar9 + 0x34;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
    } while (piVar9 != (int *)param_1[1]);
  }
  param_2 = param_2 & 0xffffff;
LAB_00b81de9:
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (iVar3 != 0) {
    (**(code **)(iVar3 + 8))(auStack_1b0);
  }
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar3 = piVar8[1] + -1;
    piVar8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      piVar1 = piVar8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2 >> 0x18;
}



/* FUNCTION 25055 ; VA 0x00b81e50 ; FUN_00b81e50 */

int FUN_00b81e50(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar1 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8a07;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 <= param_4) {
    ExceptionList = &pvStack_10;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf10c)
       && (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01edf10c), DAT_01edf10c == -1)) {
      uStack_8 = 0;
      FUN_00e35c70();
      FUN_016f3654(&LAB_01880bf0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edf10c);
    }
    cVar2 = FUN_009d1e20(&DAT_01edf0a8,param_1,param_2 + iVar1,&param_3);
    if (cVar2 != '\0') {
      ExceptionList = pvStack_10;
      return param_3;
    }
  }
  if (iVar1 <= param_4) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8 = 1;
    cVar2 = FUN_009d1bf0(param_1,param_2 + iVar1,&uStack_ec,1);
    if (cVar2 != '\0') {
      piVar3 = (int *)thunk_FUN_00e35a40();
      iVar1 = *piVar3;
      uStack_8 = 2;
      if (iStack_e8 == 0) {
        ExceptionList = pvStack_10;
        return iVar1;
      }
      (**(code **)(iStack_e8 + 8))(auStack_e4);
      ExceptionList = pvStack_10;
      return iVar1;
    }
    uStack_8 = 3;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
  }
  if ((int *)*param_5 != (int *)0x0) {
    ExceptionList = pvStack_10;
    return *(int *)*param_5;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 25056 ; VA 0x00b82000 ; FUN_00b82000 */

int FUN_00b82000(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar1 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8a37;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 <= param_4) {
    ExceptionList = &pvStack_10;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1a84)
       && (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ef1a84), DAT_01ef1a84 == -1)) {
      uStack_8 = 0;
      FUN_00baf9b0();
      FUN_016f3654(&LAB_018903c0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ef1a84);
    }
    cVar2 = FUN_009d1e20(&DAT_01ef1a20,param_1,param_2 + iVar1,&param_3);
    if (cVar2 != '\0') {
      ExceptionList = pvStack_10;
      return param_3;
    }
  }
  if (iVar1 <= param_4) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8 = 1;
    cVar2 = FUN_009d1bf0(param_1,param_2 + iVar1,&uStack_ec,1);
    if (cVar2 != '\0') {
      piVar3 = (int *)FUN_00baf470();
      iVar1 = *piVar3;
      uStack_8 = 2;
      if (iStack_e8 == 0) {
        ExceptionList = pvStack_10;
        return iVar1;
      }
      (**(code **)(iStack_e8 + 8))(auStack_e4);
      ExceptionList = pvStack_10;
      return iVar1;
    }
    uStack_8 = 3;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
  }
  if ((int *)*param_5 != (int *)0x0) {
    ExceptionList = pvStack_10;
    return *(int *)*param_5;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 25057 ; VA 0x00b821b0 ; FUN_00b821b0 */

int FUN_00b821b0(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar1 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 <= param_4) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_00b84a30();
    cVar2 = FUN_009d1e20(uVar3,param_1,param_2 + iVar1,&param_3);
    if (cVar2 != '\0') {
      ExceptionList = pvStack_10;
      return param_3;
    }
  }
  if (iVar1 <= param_4) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8 = 0;
    cVar2 = FUN_009d1bf0(param_1,param_2 + iVar1,&uStack_ec,1);
    if (cVar2 != '\0') {
      piVar4 = (int *)FUN_00d7ff60();
      iVar1 = *piVar4;
      uStack_8 = 1;
      if (iStack_e8 == 0) {
        ExceptionList = pvStack_10;
        return iVar1;
      }
      (**(code **)(iStack_e8 + 8))(auStack_e4);
      ExceptionList = pvStack_10;
      return iVar1;
    }
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
  }
  if ((int *)*param_5 != (int *)0x0) {
    ExceptionList = pvStack_10;
    return *(int *)*param_5;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 25058 ; VA 0x00b82300 ; FUN_00b82300 */

void __thiscall FUN_00b82300(int param_1,undefined4 *param_2)

{
  char cVar1;
  int iVar2;
  undefined uVar3;
  undefined auStack_14 [16];
  
  cVar1 = FUN_0097c970(param_1,1);
  if (cVar1 == '\0') {
    FUN_00550130("GetDeviceAcceleration data can only be used from local scripts");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_14,&DAT_01c17198);
  }
  if (DAT_01ef1771 == '\0') {
LAB_00b82331:
    if (*(char *)(param_1 + 0x198) != '\0') {
      if (*(char *)(param_1 + 0x191) == '\0') {
        *(undefined *)(param_1 + 0x191) = 1;
        uVar3 = 0;
        FUN_005542c0("accelerometer",0xd);
        FUN_006ecaa0(uVar3);
      }
      goto LAB_00b82388;
    }
  }
  else {
    cVar1 = FUN_00b82a50();
    if (cVar1 == '\0') goto LAB_00b82331;
  }
  FUN_0086f2f0(2,"Trying to get acceleration data on a device without a accelerometer.");
LAB_00b82388:
  iVar2 = *(int *)(param_1 + 0x180);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar2 != 0) {
    LOCK();
    *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
    UNLOCK();
    iVar2 = *(int *)(param_1 + 0x180);
  }
  *param_2 = *(undefined4 *)(param_1 + 0x17c);
  param_2[1] = iVar2;
  return;
}



/* FUNCTION 25059 ; VA 0x00b82410 ; FUN_00b82410 */

void __thiscall FUN_00b82410(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x118);
  *param_2 = *(undefined4 *)(param_1 + 0x114);
  param_2[1] = uVar1;
  return;
}



/* FUNCTION 25060 ; VA 0x00b82430 ; FUN_00b82430 */

undefined4 FUN_00b82430(undefined4 param_1)

{
  FUN_00e44f30(param_1);
  return param_1;
}



/* FUNCTION 25061 ; VA 0x00b82450 ; FUN_00b82450 */

void __thiscall FUN_00b82450(int param_1,int *param_2)

{
  undefined4 *puVar1;
  undefined4 uStack_e8;
  int iStack_e4;
  undefined4 auStack_e0 [50];
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8a63;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005cac50(&iStack_18);
  iStack_8 = 0;
  if (*(int *)(param_1 + 0x220) == 0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x22c) + *(int *)(param_1 + 0x21c) * 4);
  }
  for (; puVar1 != (undefined4 *)0x0; puVar1 = (undefined4 *)*puVar1) {
    if (*(char *)(puVar1 + 3) != '\0') {
      uStack_e8 = thunk_FUN_00b84a30();
      auStack_e0[0] = puVar1[2];
      iStack_e4 = 0;
      iStack_e4 = FUN_00b84c10();
      iStack_8 = CONCAT31(iStack_8._1_3_,1);
      if (*(int *)(iStack_18 + 8) == *(int *)(iStack_18 + 4)) {
        FUN_005ca4f0(*(int *)(iStack_18 + 4),&uStack_e8);
      }
      else {
        FUN_005caaf0(iStack_18);
        *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 0xd0;
      }
      iStack_8._0_1_ = 2;
      if (iStack_e4 != 0) {
        (**(code **)(iStack_e4 + 8))(auStack_e0);
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
    }
  }
  *param_2 = iStack_18;
  param_2[1] = iStack_14;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25062 ; VA 0x00b82570 ; FUN_00b82570 */

undefined4 FUN_00b82570(undefined4 param_1)

{
  FUN_00e45130(param_1);
  return param_1;
}



/* FUNCTION 25063 ; VA 0x00b82590 ; FUN_00b82590 */

undefined4 FUN_00b82590(undefined4 param_1,undefined4 param_2)

{
  FUN_00e45190(param_1,param_2);
  return param_1;
}



/* FUNCTION 25064 ; VA 0x00b825b0 ; FUN_00b825b0 */

undefined __thiscall FUN_00b825b0(int param_1,undefined4 param_2)

{
  int iVar1;
  int iStack_8;
  
  iVar1 = param_1 + 0x219 + (uint)*(byte *)(param_1 + 0x218);
  iStack_8 = param_1;
  FUN_00606ea0(&iStack_8,param_2,&param_2,-(uint)(iVar1 != 0) & iVar1 + 1U);
  if (iStack_8 != 0) {
    iVar1 = FUN_00b7c8b0(&param_2);
    return *(undefined *)(iVar1 + 4);
  }
  return 0;
}



/* FUNCTION 25065 ; VA 0x00b82610 ; FUN_00b82610 */

undefined __fastcall FUN_00b82610(int param_1)

{
  char cVar1;
  
  if (DAT_01ef1771 != '\0') {
    cVar1 = FUN_00b82a50();
    if (cVar1 != '\0') {
      return 0;
    }
  }
  return *(undefined *)(param_1 + 0x196);
}



/* FUNCTION 25066 ; VA 0x00b82640 ; FUN_00b82640 */

void __thiscall FUN_00b82640(int param_1,int *param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int *piVar5;
  undefined4 uStack_108;
  int iStack_104;
  undefined4 uStack_100;
  int *piStack_fc;
  undefined auStack_38 [4];
  int iStack_34;
  int iStack_30;
  int iStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8a93;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005cac50(&iStack_18);
  uStack_8 = 0;
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0x34);
    if ((iVar2 != 0) && (param_1 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if (((param_1 != 0) &&
        (iVar2 = *(int *)(param_1 + 0xc), iVar1 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
        (uint)*(ushort *)(iVar1 + 0x1da))) && (iVar2 = FUN_008e25a0(), iVar2 != 0)) {
      uVar3 = FUN_00ed3bf0(param_3);
      FUN_00ed3c60(auStack_38,uVar3);
      uStack_8._0_1_ = 1;
      if (iStack_30 == 0) {
        puVar4 = (undefined4 *)0x0;
      }
      else {
        puVar4 = *(undefined4 **)(iStack_24 + iStack_34 * 4);
      }
      for (; puVar4 != (undefined4 *)0x0; puVar4 = (undefined4 *)*puVar4) {
        piVar5 = (int *)puVar4[4];
        if (piVar5 != (int *)0x0) {
          LOCK();
          piVar5[1] = piVar5[1] + 1;
          UNLOCK();
          piVar5 = (int *)puVar4[4];
        }
        uVar3 = puVar4[3];
        uStack_8._0_1_ = 2;
        uStack_20 = uVar3;
        piStack_1c = piVar5;
        uStack_108 = FUN_0088cdc0();
        iStack_104 = 0;
        if (piVar5 != (int *)0x0) {
          LOCK();
          piVar5[1] = piVar5[1] + 1;
          UNLOCK();
        }
        uStack_100 = uVar3;
        piStack_fc = piVar5;
        iStack_104 = FUN_006309e0();
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        if (*(int *)(iStack_18 + 8) == *(int *)(iStack_18 + 4)) {
          FUN_005ca4f0(*(int *)(iStack_18 + 4),&uStack_108);
        }
        else {
          FUN_005caaf0(iStack_18);
          *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 0xd0;
        }
        uStack_8._0_1_ = 4;
        if (iStack_104 != 0) {
          (**(code **)(iStack_104 + 8))(&uStack_100);
        }
        uStack_8._0_1_ = 1;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar2 = piVar5[1] + -1;
          piVar5[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar2 = piVar5[2] + -1;
            piVar5[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
      }
      FUN_006123a0();
    }
  }
  param_2[1] = iStack_14;
  *param_2 = iStack_18;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25067 ; VA 0x00b82830 ; FUN_00b82830 */

void __thiscall FUN_00b82830(int param_1,undefined4 *param_2)

{
  char cVar1;
  int iVar2;
  undefined uVar3;
  undefined auStack_14 [16];
  
  cVar1 = FUN_0097c970(param_1,1);
  if (cVar1 == '\0') {
    FUN_00550130("GetDeviceGravity data can only be used from local scripts");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_14,&DAT_01c17198);
  }
  if (DAT_01ef1771 == '\0') {
LAB_00b82861:
    if (*(char *)(param_1 + 0x198) != '\0') {
      if (*(char *)(param_1 + 0x191) == '\0') {
        *(undefined *)(param_1 + 0x191) = 1;
        uVar3 = 0;
        FUN_005542c0("accelerometer",0xd);
        FUN_006ecaa0(uVar3);
      }
      goto LAB_00b828b8;
    }
  }
  else {
    cVar1 = FUN_00b82a50();
    if (cVar1 == '\0') goto LAB_00b82861;
  }
  FUN_0086f2f0(2,"Trying to get gravity data on a device without a accelerometer.");
LAB_00b828b8:
  iVar2 = *(int *)(param_1 + 0x188);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar2 != 0) {
    LOCK();
    *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
    UNLOCK();
    iVar2 = *(int *)(param_1 + 0x188);
  }
  *param_2 = *(undefined4 *)(param_1 + 0x184);
  param_2[1] = iVar2;
  return;
}



/* FUNCTION 25068 ; VA 0x00b82940 ; FUN_00b82940 */

int __fastcall FUN_00b82940(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  
  uVar2 = FUN_01255560();
  cVar1 = FUN_01255580(uVar2,5);
  return param_1 + 0x94 + (uint)(cVar1 != '\0') * 4;
}



/* FUNCTION 25069 ; VA 0x00b82970 ; FUN_00b82970 */

int __fastcall FUN_00b82970(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  
  uVar2 = FUN_01255560();
  cVar1 = FUN_01255580(uVar2,5);
  return param_1 + 0x9c + (uint)(cVar1 != '\0') * 4;
}



/* FUNCTION 25070 ; VA 0x00b829a0 ; FUN_00b829a0 */

int __fastcall FUN_00b829a0(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  
  uVar2 = FUN_01255560();
  cVar1 = FUN_01255580(uVar2,5);
  return param_1 + 0xa4 + (uint)(cVar1 != '\0') * 4;
}



/* FUNCTION 25071 ; VA 0x00b829d0 ; FUN_00b829d0 */

uint __thiscall FUN_00b829d0(uint param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  uint in_EAX;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  
  if (param_1 != 0) {
    uVar4 = *(uint *)(param_1 + 0x34);
    if ((uVar4 != 0) && (param_1 = uVar4, *(int *)(uVar4 + 0x34) != 0)) {
      in_EAX = FUN_005c8ac0();
      param_1 = in_EAX;
    }
    if (param_1 != 0) {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_008a8c30();
      in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
      if (((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <= in_EAX) &&
         (in_EAX = FUN_008e25a0(), in_EAX != 0)) {
        uVar3 = FUN_00ed3bf0(param_2,param_3);
        uVar4 = FUN_00ed3e80(uVar3,param_3);
        return uVar4;
      }
    }
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 25072 ; VA 0x00b82a50 ; FUN_00b82a50 */

uint __fastcall FUN_00b82a50(undefined4 param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  
  uVar1 = FUN_008f78c0(param_1);
  uVar3 = uVar1;
  if (uVar1 != 0) {
    uVar2 = FUN_00606cd0(param_1);
    uVar3 = uVar2;
    if (uVar2 != 0) {
      uVar3 = FUN_00585a40();
      if (((char)uVar3 != '\0') && (*(int *)(uVar2 + 0x68) == 1)) {
        iVar4 = FUN_008fbd40();
        if (iVar4 == 1) {
          return (uint)(*(char *)(uVar1 + 0x448) == '\0');
        }
        uVar3 = iVar4 - 2;
        if (uVar3 == 0) {
          return 1;
        }
      }
    }
  }
  return uVar3 & 0xffffff00;
}



/* FUNCTION 25073 ; VA 0x00b82ab0 ; FUN_00b82ab0 */

undefined __fastcall FUN_00b82ab0(int param_1)

{
  char cVar1;
  
  if (DAT_01ef1771 != '\0') {
    cVar1 = FUN_00b82a50();
    if (cVar1 != '\0') {
      return 0;
    }
  }
  return *(undefined *)(param_1 + 0x194);
}



/* FUNCTION 25074 ; VA 0x00b82ae0 ; FUN_00b82ae0 */

undefined4 FUN_00b82ae0(undefined4 param_1,undefined4 param_2)

{
  FUN_00e451f0(param_1,param_2);
  return param_1;
}



/* FUNCTION 25075 ; VA 0x00b82b00 ; FUN_00b82b00 */

undefined4 __fastcall FUN_00b82b00(int param_1)

{
  char cVar1;
  
  if ((DAT_01ef1771 != '\0') && (cVar1 = FUN_00b82a50(), cVar1 != '\0')) {
    return 7;
  }
  return *(undefined4 *)(param_1 + 0x19c);
}



/* FUNCTION 25076 ; VA 0x00b82b30 ; FUN_00b82b30 */

undefined4 FUN_00b82b30(undefined4 param_1)

{
  FUN_00e45360(param_1);
  return param_1;
}



/* FUNCTION 25077 ; VA 0x00b82b60 ; FUN_00b82b60 */

undefined4 FUN_00b82b60(undefined4 param_1)

{
  FUN_00b78860(param_1);
  return param_1;
}



/* FUNCTION 25078 ; VA 0x00b82b90 ; FUN_00b82b90 */

undefined __fastcall FUN_00b82b90(int param_1)

{
  char cVar1;
  
  if (DAT_01ef1771 != '\0') {
    cVar1 = FUN_00b82a50();
    if (cVar1 != '\0') {
      return 0;
    }
  }
  return *(undefined *)(param_1 + 0x195);
}



/* FUNCTION 25079 ; VA 0x00b82bd0 ; FUN_00b82bd0 */

undefined4 FUN_00b82bd0(undefined4 param_1)

{
  FUN_00b788e0(param_1);
  return param_1;
}



/* FUNCTION 25080 ; VA 0x00b82c00 ; FUN_00b82c00 */

void __thiscall FUN_00b82c00(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x110);
  *param_2 = *(undefined4 *)(param_1 + 0x10c);
  param_2[1] = uVar1;
  return;
}



/* FUNCTION 25081 ; VA 0x00b82c20 ; FUN_00b82c20 */

void __thiscall FUN_00b82c20(int param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uStack_100;
  int iStack_fc;
  undefined4 auStack_f8 [51];
  int iStack_2c;
  int iStack_28;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8abb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005cac50(&iStack_18);
  uStack_8 = 0;
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0x34);
    if ((iVar2 != 0) && (param_1 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if (((param_1 != 0) &&
        (iVar2 = *(int *)(param_1 + 0xc), iVar1 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
        (uint)*(ushort *)(iVar1 + 0x1da))) && (iVar2 = FUN_008e25a0(), iVar2 != 0)) {
      FUN_00b7b9c0(iVar2 + 0x7c);
      if (iStack_28 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
      else {
        puVar3 = *(undefined4 **)(iStack_1c + iStack_2c * 4);
      }
      for (; puVar3 != (undefined4 *)0x0; puVar3 = (undefined4 *)*puVar3) {
        uStack_8._0_1_ = 1;
        if (*(char *)(puVar3 + 3) != '\0') {
          uStack_100 = thunk_FUN_00b84a30();
          auStack_f8[0] = puVar3[2];
          iStack_fc = 0;
          iStack_fc = FUN_00b84c10();
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          if (*(int *)(iStack_18 + 8) == *(int *)(iStack_18 + 4)) {
            FUN_005ca4f0(*(int *)(iStack_18 + 4),&uStack_100);
          }
          else {
            FUN_005caaf0(iStack_18);
            *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 0xd0;
          }
          uStack_8._0_1_ = 3;
          if (iStack_fc != 0) {
            (**(code **)(iStack_fc + 8))(auStack_f8);
          }
        }
      }
      uStack_8._0_1_ = 1;
      FUN_00612320();
    }
  }
  *param_2 = iStack_18;
  param_2[1] = iStack_14;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25082 ; VA 0x00b82d90 ; FUN_00b82d90 */

int __thiscall FUN_00b82d90(int param_1,char param_2)

{
  char cVar1;
  undefined uVar2;
  undefined auStack_10 [12];
  
  if ((param_2 != '\0') && (*(char *)(param_1 + 0x191) == '\0')) {
    cVar1 = FUN_0097c970(param_1,1);
    if (cVar1 == '\0') {
      FUN_00550130("DeviceAccelerationChanged event can only be used from local scripts");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_10,&DAT_01c17198);
    }
    *(undefined *)(param_1 + 0x191) = 1;
    uVar2 = 0;
    FUN_005542c0("accelerometer",0xd);
    FUN_006ecaa0(uVar2);
  }
  return param_1 + 0xb4;
}



/* FUNCTION 25083 ; VA 0x00b82e20 ; FUN_00b82e20 */

int __thiscall FUN_00b82e20(int param_1,char param_2)

{
  char cVar1;
  undefined uVar2;
  undefined auStack_10 [12];
  
  if ((param_2 != '\0') && (*(char *)(param_1 + 0x191) == '\0')) {
    cVar1 = FUN_0097c970(param_1,1);
    if (cVar1 == '\0') {
      FUN_00550130("DeviceGravityChanged event can only be used from local scripts");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_10,&DAT_01c17198);
    }
    if (DAT_01ef1771 != '\0') {
      cVar1 = FUN_00b82a50();
      if (cVar1 != '\0') goto LAB_00b82e69;
    }
    if (*(char *)(param_1 + 0x197) == '\0') {
LAB_00b82e69:
      FUN_0086f2f0(2,"Trying to listen to acceleration events on a device without a accelerometer.")
      ;
      return param_1 + 0xb8;
    }
    *(undefined *)(param_1 + 0x191) = 1;
    uVar2 = 0;
    FUN_005542c0("accelerometer",0xd);
    FUN_006ecaa0(uVar2);
  }
  return param_1 + 0xb8;
}



/* FUNCTION 25084 ; VA 0x00b82e86 ; FUN_00b82e86 */

int FUN_00b82e86(void)

{
  int unaff_EDI;
  undefined uVar1;
  
  *(undefined *)(unaff_EDI + 0x191) = 1;
  uVar1 = 0;
  FUN_005542c0("accelerometer",0xd);
  FUN_006ecaa0(uVar1);
  return unaff_EDI + 0xb8;
}



/* FUNCTION 25085 ; VA 0x00b82ef0 ; FUN_00b82ef0 */

int __thiscall FUN_00b82ef0(int param_1,char param_2)

{
  char cVar1;
  undefined uVar2;
  undefined auStack_10 [12];
  
  if ((param_2 != '\0') && (*(char *)(param_1 + 400) == '\0')) {
    cVar1 = FUN_0097c970(param_1,1);
    if (cVar1 == '\0') {
      FUN_00550130("DeviceRotationChanged event can only be used from local scripts");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_10,&DAT_01c17198);
    }
    if (DAT_01ef1771 != '\0') {
      cVar1 = FUN_00b82a50();
      if (cVar1 != '\0') goto LAB_00b82f39;
    }
    if (*(char *)(param_1 + 0x198) == '\0') {
LAB_00b82f39:
      FUN_0086f2f0(2,"Trying to listen to rotation events on a device without a gyroscope.");
      return param_1 + 0xb0;
    }
    *(undefined *)(param_1 + 400) = 1;
    uVar2 = 0;
    FUN_005542c0(&DAT_019588f4,4);
    FUN_006ecaa0(uVar2);
  }
  return param_1 + 0xb0;
}



/* FUNCTION 25086 ; VA 0x00b82f56 ; FUN_00b82f56 */

int FUN_00b82f56(void)

{
  int unaff_EDI;
  undefined uVar1;
  
  *(undefined *)(unaff_EDI + 400) = 1;
  uVar1 = 0;
  FUN_005542c0(&DAT_019588f4,4);
  FUN_006ecaa0(uVar1);
  return unaff_EDI + 0xb0;
}



/* FUNCTION 25087 ; VA 0x00b82fc0 ; FUN_00b82fc0 */

undefined * __thiscall FUN_00b82fc0(int param_1,undefined *param_2)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  undefined *puVar4;
  undefined4 uVar5;
  int iVar6;
  undefined *puVar7;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar7 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8ad8;
  pvStack_10 = ExceptionList;
  piVar2 = (int *)(param_1 + 0x134);
  ExceptionList = &pvStack_10;
  FUN_00718820(&puStack_14,param_2);
  puVar4 = (undefined *)*piVar2;
  if (puStack_14 == puVar4) {
LAB_00b8300e:
    puStack_14 = puVar4;
  }
  else {
    cVar3 = FUN_00570370(puVar7,puStack_14 + 0x10);
    puVar4 = (undefined *)*piVar2;
    if (cVar3 != '\0') goto LAB_00b8300e;
  }
  if (puStack_14 != puVar4) {
    ExceptionList = pvStack_10;
    return *(undefined **)(puStack_14 + 0x28);
  }
  puVar4 = (undefined *)FUN_01674e20(0x30);
  puStack_14 = puVar4;
  if (puVar4 == (undefined *)0x0) {
    puVar4 = (undefined *)0x0;
  }
  else {
    *puVar4 = 0;
    uVar5 = FUN_00588320(0xb);
    *(undefined4 *)(puVar4 + 4) = uVar5;
    *(undefined4 *)(puVar4 + 8) = 0;
    *(undefined4 *)(puVar4 + 0xc) = 0x3f800000;
    *(undefined4 *)(puVar4 + 0x10) = 0;
    *(undefined4 *)(puVar4 + 0x14) = 0;
    puVar4[0x18] = 0;
    *(undefined4 *)(puVar4 + 0x1c) = 0;
    *(undefined4 *)(puVar4 + 0x20) = 0;
    *(undefined4 *)(puVar4 + 0x24) = 0;
    *(undefined4 *)(puVar4 + 0x28) = 0;
    *(undefined4 *)(puVar4 + 0x2c) = 0;
  }
  FUN_00b7a230(puVar4,param_2);
  uStack_8 = 0;
  FUN_00718820(&puStack_14,param_2);
  puVar7 = puStack_14;
  if (puStack_14 != (undefined *)*piVar2) {
    cVar3 = FUN_00570370(param_2,puStack_14 + 0x10);
    if (cVar3 == '\0') goto LAB_00b8310a;
  }
  puStack_14 = param_2;
  iVar6 = FUN_00559280(&DAT_018bdeda,&puStack_14,(int)&param_2 + 3);
  FUN_007745f0(&param_2,puVar7,iVar6 + 0x10,iVar6);
  puVar7 = param_2;
LAB_00b8310a:
  *(undefined4 *)(puVar7 + 0x28) = 0;
  piVar2 = *(int **)(puVar7 + 0x2c);
  *(undefined4 *)(puVar7 + 0x2c) = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 25088 ; VA 0x00b83170 ; FUN_00b83170 */

undefined4 FUN_00b83170(undefined4 param_1)

{
  FUN_00e455e0(param_1);
  return param_1;
}



/* FUNCTION 25089 ; VA 0x00b83190 ; FUN_00b83190 */

int FUN_00b83190(void)

{
  int iVar1;
  
  iVar1 = 0;
  if (DAT_01d67770 != 0x13) {
    iVar1 = DAT_01d67770;
  }
  return iVar1;
}



/* FUNCTION 25090 ; VA 0x00b831b0 ; FUN_00b831b0 */

undefined4 FUN_00b831b0(undefined4 param_1)

{
  FUN_00b78930(param_1);
  return param_1;
}



/* FUNCTION 25091 ; VA 0x00b831d0 ; FUN_00b831d0 */

void __thiscall FUN_00b831d0(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x120);
  *param_2 = *(undefined4 *)(param_1 + 0x11c);
  param_2[1] = uVar1;
  return;
}



/* FUNCTION 25092 ; VA 0x00b831f0 ; FUN_00b831f0 */

void __thiscall FUN_00b831f0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  char cVar6;
  int iVar7;
  undefined4 uVar8;
  undefined uVar9;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8b07;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar6 = FUN_0097c970(param_1,1);
  if (cVar6 == '\0') {
    FUN_00550130("GetDeviceRotation data can only be used from local scripts");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  }
  if (DAT_01ef1771 == '\0') {
LAB_00b83236:
    if (*(char *)(param_1 + 0x198) != '\0') {
      if (*(char *)(param_1 + 400) == '\0') {
        *(undefined *)(param_1 + 400) = 1;
        uVar9 = 0;
        FUN_005542c0(&DAT_019588f4,4);
        FUN_006ecaa0(uVar9);
      }
      goto LAB_00b8328d;
    }
  }
  else {
    cVar6 = FUN_00b82a50();
    if (cVar6 == '\0') goto LAB_00b83236;
  }
  FUN_0086f2f0(2,"Trying to get rotation data on a device without a gyroscope.");
LAB_00b8328d:
  iVar7 = FUN_01674e20(0xc);
  uStack_8 = 0;
  iStack_18 = iVar7;
  if (iVar7 == 0) {
    iVar7 = 0;
  }
  else {
    FUN_00569550(2,&uStack_11);
  }
  uStack_8 = 0xffffffff;
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  FUN_0055ba30(iVar7,param_2);
  uStack_8 = 1;
  puVar1 = (undefined4 *)*piStack_20;
  uVar8 = FUN_0088cdc0();
  *puVar1 = uVar8;
  iStack_18 = FUN_006309e0();
  iVar7 = puVar1[1];
  if (iVar7 == iStack_18) {
    iVar7 = *(int *)(param_1 + 0x148);
    if (iVar7 != 0) {
      LOCK();
      *(int *)(iVar7 + 4) = *(int *)(iVar7 + 4) + 1;
      UNLOCK();
      iVar7 = *(int *)(param_1 + 0x148);
    }
    puVar1[2] = *(undefined4 *)(param_1 + 0x144);
    piVar2 = (int *)puVar1[3];
    puVar1[3] = iVar7;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar7 = piVar2[1] + -1;
      piVar2[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar7 = piVar2[2] + -1;
        piVar2[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  else {
    if (iVar7 != 0) {
      (**(code **)(iVar7 + 8))(puVar1 + 2);
      puVar1[1] = 0;
    }
    puVar1[2] = 0;
    puVar1[3] = 0;
    if (*(int *)(param_1 + 0x148) != 0) {
      LOCK();
      piVar2 = (int *)(*(int *)(param_1 + 0x148) + 4);
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    puVar1[2] = *(undefined4 *)(param_1 + 0x144);
    puVar1[3] = *(undefined4 *)(param_1 + 0x148);
    puVar1[1] = iStack_18;
  }
  iVar7 = *piStack_20;
  uVar8 = FUN_00b00260();
  *(undefined4 *)(iVar7 + 0xd0) = uVar8;
  iStack_18 = FUN_00630d60();
  iVar3 = *(int *)(iVar7 + 0xd4);
  if (iVar3 == iStack_18) {
    uVar8 = *(undefined4 *)(param_1 + 0x150);
    uVar4 = *(undefined4 *)(param_1 + 0x154);
    uVar5 = *(undefined4 *)(param_1 + 0x158);
    *(undefined4 *)(iVar7 + 0xd8) = *(undefined4 *)(param_1 + 0x14c);
    *(undefined4 *)(iVar7 + 0xdc) = uVar8;
    *(undefined4 *)(iVar7 + 0xe0) = uVar4;
    *(undefined4 *)(iVar7 + 0xe4) = uVar5;
    uVar8 = *(undefined4 *)(param_1 + 0x160);
    uVar4 = *(undefined4 *)(param_1 + 0x164);
    uVar5 = *(undefined4 *)(param_1 + 0x168);
    *(undefined4 *)(iVar7 + 0xe8) = *(undefined4 *)(param_1 + 0x15c);
    *(undefined4 *)(iVar7 + 0xec) = uVar8;
    *(undefined4 *)(iVar7 + 0xf0) = uVar4;
    *(undefined4 *)(iVar7 + 0xf4) = uVar5;
    uVar8 = *(undefined4 *)(param_1 + 0x170);
    uVar4 = *(undefined4 *)(param_1 + 0x174);
    uVar5 = *(undefined4 *)(param_1 + 0x178);
    *(undefined4 *)(iVar7 + 0xf8) = *(undefined4 *)(param_1 + 0x16c);
    *(undefined4 *)(iVar7 + 0xfc) = uVar8;
    *(undefined4 *)(iVar7 + 0x100) = uVar4;
    *(undefined4 *)(iVar7 + 0x104) = uVar5;
  }
  else {
    if (iVar3 != 0) {
      (**(code **)(iVar3 + 8))(iVar7 + 0xd8);
      *(undefined4 *)(iVar7 + 0xd4) = 0;
    }
    uVar8 = *(undefined4 *)(param_1 + 0x150);
    uVar4 = *(undefined4 *)(param_1 + 0x154);
    uVar5 = *(undefined4 *)(param_1 + 0x158);
    *(undefined4 *)(iVar7 + 0xd8) = *(undefined4 *)(param_1 + 0x14c);
    *(undefined4 *)(iVar7 + 0xdc) = uVar8;
    *(undefined4 *)(iVar7 + 0xe0) = uVar4;
    *(undefined4 *)(iVar7 + 0xe4) = uVar5;
    uVar8 = *(undefined4 *)(param_1 + 0x160);
    uVar4 = *(undefined4 *)(param_1 + 0x164);
    uVar5 = *(undefined4 *)(param_1 + 0x168);
    *(undefined4 *)(iVar7 + 0xe8) = *(undefined4 *)(param_1 + 0x15c);
    *(undefined4 *)(iVar7 + 0xec) = uVar8;
    *(undefined4 *)(iVar7 + 0xf0) = uVar4;
    *(undefined4 *)(iVar7 + 0xf4) = uVar5;
    uVar8 = *(undefined4 *)(param_1 + 0x170);
    uVar4 = *(undefined4 *)(param_1 + 0x174);
    uVar5 = *(undefined4 *)(param_1 + 0x178);
    *(undefined4 *)(iVar7 + 0xf8) = *(undefined4 *)(param_1 + 0x16c);
    *(undefined4 *)(iVar7 + 0xfc) = uVar8;
    *(undefined4 *)(iVar7 + 0x100) = uVar4;
    *(undefined4 *)(iVar7 + 0x104) = uVar5;
    *(int *)(iVar7 + 0xd4) = iStack_18;
  }
  *param_2 = piStack_20;
  param_2[1] = uStack_1c;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25093 ; VA 0x00b83470 ; FUN_00b83470 */

undefined4 FUN_00b83470(undefined4 param_1)

{
  FUN_00e456b0(param_1);
  return param_1;
}



/* FUNCTION 25094 ; VA 0x00b83490 ; FUN_00b83490 */

undefined4 FUN_00b83490(undefined4 param_1)

{
  FUN_00e456d0(param_1);
  return param_1;
}



/* FUNCTION 25095 ; VA 0x00b834c0 ; FUN_00b834c0 */

void __thiscall FUN_00b834c0(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x108);
  *param_2 = *(undefined4 *)(param_1 + 0x104);
  param_2[1] = uVar1;
  return;
}



/* FUNCTION 25096 ; VA 0x00b834e0 ; FUN_00b834e0 */

undefined * FUN_00b834e0(undefined *param_1,int param_2)

{
  if (param_2 - 1000U < 0x12) {
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    return param_1;
  }
  FUN_00e44fe0(param_1,param_2);
  return param_1;
}



/* FUNCTION 25097 ; VA 0x00b83530 ; FUN_00b83530 */

undefined4 FUN_00b83530(int param_1)

{
  char cVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar2 = FUN_0085ff70(param_1 + 0xc);
    if ((iVar2 != 0) && (DAT_01ef1771 != '\0')) {
      cVar1 = FUN_00b82a50();
      if (cVar1 != '\0') {
        return 1;
      }
    }
  }
  return 0;
}



/* FUNCTION 25098 ; VA 0x00b83570 ; FUN_00b83570 */

void FUN_00b83570(undefined4 *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  
  FUN_005e6780(param_2);
  iVar1 = FUN_00b7c6f0(&param_2);
  iVar2 = *(int *)(iVar1 + 8);
  *param_1 = 0;
  param_1[1] = 0;
  if (iVar2 != 0) {
    LOCK();
    *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
    UNLOCK();
    iVar2 = *(int *)(iVar1 + 8);
  }
  *param_1 = *(undefined4 *)(iVar1 + 4);
  param_1[1] = iVar2;
  return;
}



/* FUNCTION 25099 ; VA 0x00b835c0 ; FUN_00b835c0 */

int __fastcall FUN_00b835c0(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  
  uVar2 = FUN_01255560();
  cVar1 = FUN_01255580(uVar2,5);
  return param_1 + 0x7c + (uint)(cVar1 != '\0') * 4;
}



/* FUNCTION 25100 ; VA 0x00b835f0 ; FUN_00b835f0 */

int __fastcall FUN_00b835f0(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  
  uVar2 = FUN_01255560();
  cVar1 = FUN_01255580(uVar2,5);
  return param_1 + 0x8c + (uint)(cVar1 != '\0') * 4;
}



/* FUNCTION 25101 ; VA 0x00b83620 ; FUN_00b83620 */

undefined __fastcall FUN_00b83620(int param_1)

{
  char cVar1;
  
  if ((DAT_01ef1771 != '\0') && (cVar1 = FUN_00b82a50(), cVar1 != '\0')) {
    return 1;
  }
  return *(undefined *)(param_1 + 0x193);
}



/* FUNCTION 25102 ; VA 0x00b83640 ; FUN_00b83640 */

int __fastcall FUN_00b83640(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  
  uVar2 = FUN_01255560();
  cVar1 = FUN_01255580(uVar2,5);
  return param_1 + 0x84 + (uint)(cVar1 != '\0') * 4;
}



/* FUNCTION 25103 ; VA 0x00b83670 ; FUN_00b83670 */

undefined4 * __thiscall FUN_00b83670(int param_1,undefined4 *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  
  if (param_1 != 0) {
    iVar6 = *(int *)(param_1 + 0x34);
    if ((iVar6 != 0) && (param_1 = iVar6, *(int *)(iVar6 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if (((param_1 != 0) &&
        (iVar6 = *(int *)(param_1 + 0xc), iVar5 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
        (uint)*(ushort *)(iVar5 + 0x1da))) && (iVar6 = FUN_008e3680(), iVar6 != 0)) {
      puVar1 = (undefined4 *)(iVar6 + 0x70 + param_3 * 0x30);
      uVar2 = puVar1[1];
      uVar3 = puVar1[2];
      uVar4 = puVar1[3];
      *param_2 = *puVar1;
      param_2[1] = uVar2;
      param_2[2] = uVar3;
      param_2[3] = uVar4;
      puVar1 = (undefined4 *)(iVar6 + 0x80 + param_3 * 0x30);
      uVar2 = puVar1[1];
      uVar3 = puVar1[2];
      uVar4 = puVar1[3];
      param_2[4] = *puVar1;
      param_2[5] = uVar2;
      param_2[6] = uVar3;
      param_2[7] = uVar4;
      puVar1 = (undefined4 *)(iVar6 + 0x90 + param_3 * 0x30);
      uVar2 = puVar1[1];
      uVar3 = puVar1[2];
      uVar4 = puVar1[3];
      param_2[8] = *puVar1;
      param_2[9] = uVar2;
      param_2[10] = uVar3;
      param_2[0xb] = uVar4;
      return param_2;
    }
  }
  FUN_0060efa0();
  return param_2;
}



/* FUNCTION 25104 ; VA 0x00b83710 ; FUN_00b83710 */

void __thiscall FUN_00b83710(int param_1,undefined4 *param_2,int param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  param_1 = param_1 + param_3 * 0x30;
  uVar1 = *(undefined4 *)(param_1 + 0x74);
  uVar2 = *(undefined4 *)(param_1 + 0x78);
  uVar3 = *(undefined4 *)(param_1 + 0x7c);
  *param_2 = *(undefined4 *)(param_1 + 0x70);
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  uVar1 = *(undefined4 *)(param_1 + 0x84);
  uVar2 = *(undefined4 *)(param_1 + 0x88);
  uVar3 = *(undefined4 *)(param_1 + 0x8c);
  param_2[4] = *(undefined4 *)(param_1 + 0x80);
  param_2[5] = uVar1;
  param_2[6] = uVar2;
  param_2[7] = uVar3;
  uVar1 = *(undefined4 *)(param_1 + 0x94);
  uVar2 = *(undefined4 *)(param_1 + 0x98);
  uVar3 = *(undefined4 *)(param_1 + 0x9c);
  param_2[8] = *(undefined4 *)(param_1 + 0x90);
  param_2[9] = uVar1;
  param_2[10] = uVar2;
  param_2[0xb] = uVar3;
  return;
}



/* FUNCTION 25105 ; VA 0x00b83750 ; FUN_00b83750 */

undefined4 * __thiscall FUN_00b83750(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  
  if (param_1 != 0) {
    iVar5 = *(int *)(param_1 + 0x34);
    if ((iVar5 != 0) && (param_1 = iVar5, *(int *)(iVar5 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if (((param_1 != 0) &&
        (iVar5 = *(int *)(param_1 + 0xc), iVar4 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da))) && (iVar5 = FUN_008e3680(), iVar5 != 0)) {
      uVar1 = *(undefined4 *)(iVar5 + 0x74);
      uVar2 = *(undefined4 *)(iVar5 + 0x78);
      uVar3 = *(undefined4 *)(iVar5 + 0x7c);
      *param_2 = *(undefined4 *)(iVar5 + 0x70);
      param_2[1] = uVar1;
      param_2[2] = uVar2;
      param_2[3] = uVar3;
      uVar1 = *(undefined4 *)(iVar5 + 0x84);
      uVar2 = *(undefined4 *)(iVar5 + 0x88);
      uVar3 = *(undefined4 *)(iVar5 + 0x8c);
      param_2[4] = *(undefined4 *)(iVar5 + 0x80);
      param_2[5] = uVar1;
      param_2[6] = uVar2;
      param_2[7] = uVar3;
      uVar1 = *(undefined4 *)(iVar5 + 0x94);
      uVar2 = *(undefined4 *)(iVar5 + 0x98);
      uVar3 = *(undefined4 *)(iVar5 + 0x9c);
      param_2[8] = *(undefined4 *)(iVar5 + 0x90);
      param_2[9] = uVar1;
      param_2[10] = uVar2;
      param_2[0xb] = uVar3;
      return param_2;
    }
  }
  FUN_0060efa0();
  return param_2;
}



/* FUNCTION 25106 ; VA 0x00b837e0 ; FUN_00b837e0 */

undefined __fastcall FUN_00b837e0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0x34);
    if ((iVar2 != 0) && (param_1 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if (param_1 != 0) {
      iVar2 = *(int *)(param_1 + 0xc);
      iVar1 = FUN_008a8c30();
      if (((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
           (uint)*(ushort *)(iVar1 + 0x1da)) && (iVar2 = FUN_008e3680(), iVar2 != 0)) {
        return *(undefined *)(iVar2 + 0x6c);
      }
    }
  }
  return 0;
}



/* FUNCTION 25107 ; VA 0x00b83840 ; FUN_00b83840 */

undefined4 * __thiscall FUN_00b83840(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined auStack_c [8];
  
  puVar1 = (undefined4 *)(**(code **)(param_1 + 8))(auStack_c);
  *param_2 = *puVar1;
  param_2[1] = puVar1[1];
  return param_2;
}



/* FUNCTION 25108 ; VA 0x00b83870 ; FUN_00b83870 */

void __thiscall FUN_00b83870(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_c [8];
  
  puVar2 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_c,param_2);
  uVar3 = FUN_0088d730();
  *param_3 = uVar3;
  iVar4 = FUN_006314d0();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = *puVar2;
    param_3[3] = puVar2[1];
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
    param_3[1] = 0;
  }
  param_3[2] = *puVar2;
  param_3[3] = puVar2[1];
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 25109 ; VA 0x00b838f0 ; FUN_00b838f0 */

void __thiscall FUN_00b838f0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00b798a0();
  *param_3 = uVar3;
  iVar4 = FUN_00b79a00();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 25110 ; VA 0x00b83950 ; FUN_00b83950 */

void __thiscall FUN_00b83950(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00b79950();
  *param_3 = uVar3;
  iVar4 = FUN_00b79a70();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 25111 ; VA 0x00b839b0 ; FUN_00b839b0 */

bool __fastcall FUN_00b839b0(int param_1)

{
  return 0 < *(int *)(param_1 + 0x234);
}



/* FUNCTION 25112 ; VA 0x00b839c0 ; FUN_00b839c0 */

void __thiscall FUN_00b839c0(int param_1,int param_2)

{
  param_2 = param_2 + *(int *)(param_1 + 0x234);
  if (param_2 < 1) {
    param_2 = 0;
  }
  *(int *)(param_1 + 0x234) = param_2;
  return;
}



/* FUNCTION 25113 ; VA 0x00b839e0 ; FUN_00b839e0 */

void FUN_00b839e0(void)

{
  FUN_00e45700();
  return;
}



/* FUNCTION 25114 ; VA 0x00b839f0 ; FUN_00b839f0 */

void FUN_00b839f0(void)

{
  FUN_00b78b60();
  return;
}



/* FUNCTION 25115 ; VA 0x00b83a00 ; FUN_00b83a00 */

uint __fastcall FUN_00b83a00(uint param_1)

{
  int iVar1;
  uint in_EAX;
  int iVar2;
  uint uVar3;
  
  if (param_1 != 0) {
    uVar3 = *(uint *)(param_1 + 0x34);
    if ((uVar3 != 0) && (param_1 = uVar3, *(int *)(uVar3 + 0x34) != 0)) {
      in_EAX = FUN_005c8ac0();
      param_1 = in_EAX;
    }
    if (param_1 != 0) {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_008a8c30();
      in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
      if (((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <= in_EAX) &&
         (in_EAX = FUN_008e25a0(), in_EAX != 0)) {
        uVar3 = FUN_00ed41d0();
        return uVar3;
      }
    }
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 25116 ; VA 0x00b83a70 ; FUN_00b83a70 */

int __fastcall FUN_00b83a70(int param_1)

{
  uint uVar1;
  uint3 uVar2;
  
  uVar1 = *(uint *)(param_1 + 0x54);
  uVar2 = (uint3)(uVar1 >> 8);
  if ((((4 < uVar1) && (uVar1 != 7)) && (uVar1 != 5)) && (uVar1 != 6)) {
    return (uint)uVar2 << 8;
  }
  return CONCAT31(uVar2,1);
}



/* FUNCTION 25117 ; VA 0x00b83a90 ; FUN_00b83a90 */

uint FUN_00b83a90(void)

{
  int iVar1;
  
  iVar1 = FUN_00b7a090();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 25118 ; VA 0x00b83ab0 ; FUN_00b83ab0 */

uint FUN_00b83ab0(void)

{
  int iVar1;
  
  iVar1 = FUN_00b7a090();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 25119 ; VA 0x00b83ad0 ; FUN_00b83ad0 */

undefined4 FUN_00b83ad0(void)

{
  if (((DAT_01ef1772 == '\0') && (DAT_01ef1770 == '\0')) &&
     ((DAT_01d67770 == 0x13 ||
      (((((DAT_01d67770 != 4 && (DAT_01d67770 != 5)) && (DAT_01d67770 != 6)) &&
        ((DAT_01d67770 != 7 && (DAT_01d67770 != 8)))) &&
       ((DAT_01d67770 != 10 && ((DAT_01d67770 != 0xb && (DAT_01d67770 != 0xe)))))))))) {
    return 0;
  }
  return 1;
}



/* FUNCTION 25120 ; VA 0x00b83b20 ; FUN_00b83b20 */

void FUN_00b83b20(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00b847d0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25121 ; VA 0x00b83b60 ; FUN_00b83b60 */

void FUN_00b83b60(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b84860();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25122 ; VA 0x00b83ba0 ; FUN_00b83ba0 */

void FUN_00b83ba0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00b84910();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25123 ; VA 0x00b83be0 ; FUN_00b83be0 */

void FUN_00b83be0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00b849a0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25124 ; VA 0x00b83c20 ; FUN_00b83c20 */

void FUN_00b83c20(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00b84a30();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25125 ; VA 0x00b83c60 ; FUN_00b83c60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b83c60(int param_1,int param_2,int param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  int iVar8;
  int iVar9;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined auStack_18 [4];
  int *piStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  iVar9 = param_2;
  if (param_2 != 0) {
    FUN_01679490();
    FUN_01679490();
  }
  iVar8 = param_3;
  FUN_008a4210(iVar9,param_3);
  if (iVar8 != 0) {
    uVar6 = FUN_00b7a570();
    *(undefined4 *)(param_1 + 300) = uVar6;
    uVar6 = FUN_00b7a700();
    *(undefined4 *)(param_1 + 0x130) = uVar6;
    param_2 = FUN_008f7870(iVar8);
    uStack_8 = 0;
    uStack_20 = 0;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
    uStack_c = 1;
    uStack_10 = 0xb;
    puVar7 = (undefined4 *)
             FUN_00b775b0(auStack_18,&uStack_10,&uStack_c,&uStack_2c,&uStack_8,&param_2);
    uVar6 = *puVar7;
    uVar2 = puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    *(undefined4 *)(param_1 + 0x144) = uVar6;
    piVar3 = *(int **)(param_1 + 0x148);
    *(undefined4 *)(param_1 + 0x148) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar9 = piVar3[1] + -1;
      piVar3[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar9 = piVar3[2] + -1;
        piVar3[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_14[1] + -1;
      piStack_14[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar9 = *piVar1 + -1;
        *piVar1 = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    param_2 = FUN_008f7870(param_3);
    uStack_10 = 0;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
    uStack_c = 1;
    uStack_8 = 10;
    puVar7 = (undefined4 *)
             FUN_00b775b0(auStack_18,&uStack_8,&uStack_c,&uStack_2c,&uStack_10,&param_2);
    uVar6 = *puVar7;
    uVar2 = puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    *(undefined4 *)(param_1 + 0x17c) = uVar6;
    piVar3 = *(int **)(param_1 + 0x180);
    *(undefined4 *)(param_1 + 0x180) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar9 = piVar3[1] + -1;
      piVar3[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar9 = piVar3[2] + -1;
        piVar3[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    piVar3 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_14[1] + -1;
      piStack_14[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar9 = *piVar1 + -1;
        *piVar1 = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    param_3 = FUN_008f7870(param_3);
    param_2 = 0;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
    uStack_10 = 1;
    uStack_c = 10;
    puVar7 = (undefined4 *)
             FUN_00b775b0(auStack_18,&uStack_c,&uStack_10,&uStack_2c,&param_2,&param_3);
    uVar6 = *puVar7;
    uVar2 = puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    *(undefined4 *)(param_1 + 0x184) = uVar6;
    piVar3 = *(int **)(param_1 + 0x188);
    *(undefined4 *)(param_1 + 0x188) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar9 = piVar3[1] + -1;
      piVar3[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar9 = piVar3[2] + -1;
        piVar3[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_14[1] + -1;
      piStack_14[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar3 = piStack_14 + 2;
        iVar9 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar9 == 1) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    uVar5 = _UNK_018e3fbc;
    uVar4 = _UNK_018e3fb8;
    uVar2 = _UNK_018e3fb4;
    uVar6 = _DAT_018e3fb0;
    iVar9 = 0xc;
    uStack_24 = 0;
    *(undefined4 *)(param_1 + 0x14c) = _DAT_018e3fb0;
    *(undefined4 *)(param_1 + 0x150) = uVar2;
    *(undefined4 *)(param_1 + 0x154) = uVar4;
    *(undefined4 *)(param_1 + 0x158) = uVar5;
    *(undefined4 *)(param_1 + 0x15c) = uVar6;
    *(undefined4 *)(param_1 + 0x160) = uVar2;
    *(undefined4 *)(param_1 + 0x164) = uVar4;
    *(undefined4 *)(param_1 + 0x168) = uVar5;
    *(undefined4 *)(param_1 + 0x16c) = 0x3f800000;
    *(int *)(param_1 + 0x170) = (int)uStack_20;
    *(int *)(param_1 + 0x174) = (int)uStack_20;
    *(undefined4 *)(param_1 + 0x178) = 0;
    do {
      param_3 = iVar9;
      iVar8 = FUN_00b7c8b0(&param_3);
      iVar9 = iVar9 + 1;
      *(undefined *)(iVar8 + 4) = 0;
    } while (iVar9 < 0x14);
  }
  return;
}



/* FUNCTION 25126 ; VA 0x00b83f80 ; FUN_00b83f80 */

void FUN_00b83f80(void)

{
  FUN_008a4940(&DAT_0212e5e0);
  return;
}



/* FUNCTION 25127 ; VA 0x00b83ff0 ; FUN_00b83ff0 */

void __thiscall
FUN_00b83ff0(int param_1,float *param_2,float *param_3,float *param_4,float *param_5)

{
  float fVar1;
  bool bVar2;
  bool bVar3;
  bool bVar4;
  bool bVar5;
  
  fVar1 = *param_2;
  if (((NAN(fVar1) || NAN(*(float *)(param_1 + 0x104))) == (fVar1 == *(float *)(param_1 + 0x104)))
     || (bVar4 = false,
        (NAN(param_2[1]) || NAN(*(float *)(param_1 + 0x108))) ==
        (param_2[1] == *(float *)(param_1 + 0x108)))) {
    bVar4 = true;
  }
  if (((NAN(*param_3) || NAN(*(float *)(param_1 + 0x10c))) ==
       (*param_3 == *(float *)(param_1 + 0x10c))) ||
     ((NAN(param_3[1]) || NAN(*(float *)(param_1 + 0x110))) ==
      (param_3[1] == *(float *)(param_1 + 0x110)))) {
    bVar2 = true;
  }
  else {
    bVar2 = false;
  }
  if (((NAN(*param_4) || NAN(*(float *)(param_1 + 0x114))) ==
       (*param_4 == *(float *)(param_1 + 0x114))) ||
     (bVar5 = false,
     (NAN(param_4[1]) || NAN(*(float *)(param_1 + 0x118))) ==
     (param_4[1] == *(float *)(param_1 + 0x118)))) {
    bVar5 = true;
  }
  if (((NAN(*param_5) || NAN(*(float *)(param_1 + 0x11c))) ==
       (*param_5 == *(float *)(param_1 + 0x11c))) ||
     ((NAN(param_5[1]) || NAN(*(float *)(param_1 + 0x120))) ==
      (param_5[1] == *(float *)(param_1 + 0x120)))) {
    bVar3 = true;
  }
  else {
    bVar3 = false;
  }
  *(float *)(param_1 + 0x104) = fVar1;
  *(float *)(param_1 + 0x108) = param_2[1];
  *(float *)(param_1 + 0x10c) = *param_3;
  *(float *)(param_1 + 0x110) = param_3[1];
  *(float *)(param_1 + 0x114) = *param_4;
  *(float *)(param_1 + 0x118) = param_4[1];
  *(float *)(param_1 + 0x11c) = *param_5;
  *(float *)(param_1 + 0x120) = param_5[1];
  if (bVar4) {
    FUN_008a4940(&DAT_0212e7b8);
  }
  if (bVar2) {
    FUN_008a4940(&DAT_0212e7f0);
  }
  if (bVar5) {
    FUN_008a4940(&DAT_0212e828);
  }
  if (bVar3) {
    FUN_008a4940(&DAT_0212e860);
  }
  return;
}



/* FUNCTION 25128 ; VA 0x00b84150 ; FUN_00b84150 */

void __thiscall FUN_00b84150(int param_1,undefined4 param_2,undefined param_3)

{
  int iVar1;
  undefined4 *puVar2;
  
  iVar1 = FUN_00b7c8b0(&param_2);
  *(undefined *)(iVar1 + 4) = param_3;
  if (*(int *)(param_1 + 0x220) == 0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    puVar2 = *(undefined4 **)(*(int *)(param_1 + 0x22c) + *(int *)(param_1 + 0x21c) * 4);
  }
  while( true ) {
    if (puVar2 == (undefined4 *)0x0) {
      if (*(char *)(param_1 + 0x196) != '\0') {
        *(undefined *)(param_1 + 0x196) = 0;
        FUN_008a4940(&DAT_0212d890);
      }
      return;
    }
    if (*(char *)(puVar2 + 3) != '\0') break;
    puVar2 = (undefined4 *)*puVar2;
  }
  if (*(char *)(param_1 + 0x196) == '\x01') {
    return;
  }
  *(undefined *)(param_1 + 0x196) = 1;
  FUN_008a4940(&DAT_0212d890);
  return;
}



/* FUNCTION 25129 ; VA 0x00b841e0 ; FUN_00b841e0 */

int FUN_00b841e0(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f8b28;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00e45770(param_1,param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 25130 ; VA 0x00b84280 ; FUN_00b84280 */

void __thiscall FUN_00b84280(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0x1fc)) {
    *(char *)(param_1 + 0x1fc) = param_2;
  }
  return;
}



/* FUNCTION 25131 ; VA 0x00b842a0 ; FUN_00b842a0 */

void __thiscall FUN_00b842a0(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0x192)) {
    *(char *)(param_1 + 0x192) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25132 ; VA 0x00b842d0 ; FUN_00b842d0 */

void __thiscall FUN_00b842d0(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x1a0) != param_2) {
    *(char *)(param_1 + 0x1a0) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25133 ; VA 0x00b84300 ; FUN_00b84300 */

void FUN_00b84300(undefined4 param_1)

{
  FUN_00b79650(param_1);
  return;
}



/* FUNCTION 25134 ; VA 0x00b84320 ; FUN_00b84320 */

void FUN_00b84320(void)

{
  FUN_00b796b0();
  return;
}



/* FUNCTION 25135 ; VA 0x00b84330 ; FUN_00b84330 */

void FUN_00b84330(void)

{
  FUN_00b79700();
  return;
}



/* FUNCTION 25136 ; VA 0x00b84340 ; FUN_00b84340 */

void __fastcall FUN_00b84340(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0x34);
    if ((iVar2 != 0) && (param_1 = iVar2, *(int *)(iVar2 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if (((param_1 != 0) &&
        (iVar2 = *(int *)(param_1 + 0xc), iVar1 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
        (uint)*(ushort *)(iVar1 + 0x1da))) && (iVar2 = FUN_008e25a0(), iVar2 != 0)) {
      FUN_00ed4e20();
      return;
    }
  }
  return;
}



/* FUNCTION 25137 ; VA 0x00b843b0 ; FUN_00b843b0 */

void FUN_00b843b0(void)

{
  FUN_00b79860();
  return;
}



/* FUNCTION 25138 ; VA 0x00b843c0 ; FUN_00b843c0 */

void __thiscall FUN_00b843c0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  undefined auStack_e4 [200];
  code *pcStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc5bb;
  pvStack_10 = ExceptionList;
  iVar1 = *param_3;
  pcStack_1c = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088d730();
  if (iVar1 == iVar2) {
    iVar1 = *param_3;
    iVar2 = FUN_0088d730();
    if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar4 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar4 = (int *)0x0;
    }
    iStack_18 = *piVar4;
    iStack_14 = piVar4[1];
  }
  else {
    puVar3 = (undefined4 *)param_3[1];
    if (puVar3 != (undefined4 *)0x0) {
      (*(code *)*puVar3)(param_3 + 2,auStack_e4);
      puVar3 = (undefined4 *)param_3[1];
    }
    uStack_8 = 0;
    piVar4 = (int *)FUN_0088b680();
    iStack_18 = *piVar4;
    iStack_14 = piVar4[1];
    uStack_8 = 1;
    if (puVar3 != (undefined4 *)0x0) {
      (*(code *)puVar3[2])(auStack_e4);
    }
    uStack_8 = 0xffffffff;
  }
  (*pcStack_1c)(param_2,&iStack_18);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25139 ; VA 0x00b844d0 ; FUN_00b844d0 */

void __thiscall FUN_00b844d0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00b798a0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25140 ; VA 0x00b84520 ; FUN_00b84520 */

void __thiscall FUN_00b84520(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00b79950();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25141 ; VA 0x00b84570 ; FUN_00b84570 */

void __thiscall
FUN_00b84570(int param_1,int *param_2,undefined4 param_3,undefined4 param_4,char param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int in_stack_ffffffe4;
  int in_stack_ffffffe8;
  undefined4 uVar4;
  
  if (*param_2 != 0) {
    if (*(int *)(*param_2 + 0x5c) == 2) {
      if (param_2[1] != 0) {
        LOCK();
        piVar1 = (int *)(param_2[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      in_stack_ffffffe4 = *param_2;
      in_stack_ffffffe8 = param_2[1];
      FUN_0089bf10(in_stack_ffffffe4,in_stack_ffffffe8,param_4);
    }
    cVar3 = FUN_008ff170();
    if (cVar3 != '\0') {
      cVar3 = FUN_00d81cb0();
      if (cVar3 != '\0') {
        iVar2 = *(int *)(*param_2 + 0x5c);
        if (iVar2 == 0) {
          uVar4 = param_4;
          FUN_00557fc0(param_2);
          FUN_0089bf10(in_stack_ffffffe4,in_stack_ffffffe8,uVar4);
          if (param_5 == '\0') {
            uVar4 = param_4;
            FUN_00557fc0(param_2);
            FUN_0089bf10(in_stack_ffffffe4,in_stack_ffffffe8,uVar4);
          }
          if (*(int *)(*param_2 + 0x54) == 7) {
            uVar4 = param_4;
            FUN_00557fc0(param_2);
            FUN_0089bf10(in_stack_ffffffe4,in_stack_ffffffe8,uVar4);
            if (param_5 == '\0') {
              FUN_00557fc0(param_2);
              FUN_0089bf10(in_stack_ffffffe4,in_stack_ffffffe8,param_4);
              return;
            }
          }
          else if (*(int *)(*param_2 + 0x54) == 9) {
            *(undefined *)(param_1 + 0x230) = 1;
            FUN_006eccd0();
          }
        }
        else if (iVar2 == 1) {
          uVar4 = param_4;
          FUN_00557fc0(param_2);
          FUN_0089bf10(in_stack_ffffffe4,in_stack_ffffffe8,uVar4);
          if (param_5 == '\0') {
            uVar4 = param_4;
            FUN_00557fc0(param_2);
            FUN_0089bf10(in_stack_ffffffe4,in_stack_ffffffe8,uVar4);
          }
          if (*(int *)(*param_2 + 0x54) == 7) {
            uVar4 = param_4;
            FUN_00557fc0(param_2);
            FUN_0089bf10(in_stack_ffffffe4,in_stack_ffffffe8,uVar4);
            if (param_5 == '\0') {
              FUN_00557fc0(param_2);
              FUN_0089bf10(in_stack_ffffffe4,in_stack_ffffffe8,param_4);
              return;
            }
          }
        }
        else if (iVar2 == 2) {
          uVar4 = param_4;
          FUN_00557fc0(param_2);
          FUN_0089bf10(in_stack_ffffffe4,in_stack_ffffffe8,uVar4);
          if (param_5 == '\0') {
            uVar4 = param_4;
            FUN_00557fc0(param_2);
            FUN_0089bf10(in_stack_ffffffe4,in_stack_ffffffe8,uVar4);
          }
          if (*(int *)(*param_2 + 0x54) == 7) {
            uVar4 = param_4;
            FUN_00557fc0(param_2);
            FUN_0089bf10(in_stack_ffffffe4,in_stack_ffffffe8,uVar4);
            if (param_5 == '\0') {
              FUN_00557fc0(param_2);
              FUN_0089bf10(in_stack_ffffffe4,in_stack_ffffffe8,param_4);
              return;
            }
          }
          else if (*(int *)(*param_2 + 0x54) == 9) {
            *(undefined *)(param_1 + 0x230) = 0;
            FUN_006eccd0();
            return;
          }
        }
      }
    }
  }
  return;
}



/* FUNCTION 25142 ; VA 0x00b847d0 ; FUN_00b847d0 */

undefined * FUN_00b847d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f894c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1b54) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef1b54);
    if (DAT_01ef1b54 == -1) {
      uStack_8 = 0;
      FUN_00e034e0();
      FUN_016f3654(&LAB_01890360);
      FUN_016f37bf(&DAT_01ef1b54);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef1af0;
}



/* FUNCTION 25143 ; VA 0x00b84860 ; FUN_00b84860 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b84860(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8b56;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1a1c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef1a1c);
    if (DAT_01ef1a1c == -1) {
      uStack_8 = 0;
      FUN_009ca470("SwipeDirection");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef19b8 = RBX::Reflection::EnumDesc<enum_RBX::GuiSwipeDirection>::vftable;
      FUN_009caf20(&DAT_01d6778c,5);
      FUN_016f3654(&LAB_01890380);
      FUN_016f37bf(&DAT_01ef1a1c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef19b8;
}



/* FUNCTION 25144 ; VA 0x00b84910 ; FUN_00b84910 */

undefined * FUN_00b84910(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f896c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1bbc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef1bbc);
    if (DAT_01ef1bbc == -1) {
      uStack_8 = 0;
      FUN_00e03540();
      FUN_016f3654(&LAB_018903a0);
      FUN_016f37bf(&DAT_01ef1bbc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef1b58;
}



/* FUNCTION 25145 ; VA 0x00b849a0 ; FUN_00b849a0 */

undefined * FUN_00b849a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8b6c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1a84) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef1a84);
    if (DAT_01ef1a84 == -1) {
      uStack_8 = 0;
      FUN_00baf9b0();
      FUN_016f3654(&LAB_018903c0);
      FUN_016f37bf(&DAT_01ef1a84);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef1a20;
}



/* FUNCTION 25146 ; VA 0x00b84a30 ; FUN_00b84a30 */

undefined * FUN_00b84a30(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8b8c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1aec) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef1aec);
    if (DAT_01ef1aec == -1) {
      uStack_8 = 0;
      FUN_00d806a0();
      FUN_016f3654(&LAB_018903e0);
      FUN_016f37bf(&DAT_01ef1aec);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef1a88;
}



/* FUNCTION 25147 ; VA 0x00b84ac0 ; FUN_00b84ac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b84ac0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1bdc) {
    FUN_016f3809(&DAT_01ef1bdc);
    if (DAT_01ef1bdc == -1) {
      _DAT_01ef1bd0 = FUN_005c65e0;
      _DAT_01ef1bd4 = FUN_005c65e0;
      _DAT_01ef1bd8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef1bdc);
    }
  }
  return &DAT_01ef1bd0;
}



/* FUNCTION 25148 ; VA 0x00b84b30 ; FUN_00b84b30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b84b30(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1bcc) {
    FUN_016f3809(&DAT_01ef1bcc);
    if (DAT_01ef1bcc == -1) {
      _DAT_01ef1bc0 = FUN_005c65e0;
      _DAT_01ef1bc4 = FUN_005c65e0;
      _DAT_01ef1bc8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef1bcc);
    }
  }
  return &DAT_01ef1bc0;
}



/* FUNCTION 25149 ; VA 0x00b84ba0 ; FUN_00b84ba0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b84ba0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1c2c) {
    FUN_016f3809(&DAT_01ef1c2c);
    if (DAT_01ef1c2c == -1) {
      _DAT_01ef1c20 = FUN_005c65e0;
      _DAT_01ef1c24 = FUN_005c65e0;
      _DAT_01ef1c28 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef1c2c);
    }
  }
  return &DAT_01ef1c20;
}



/* FUNCTION 25150 ; VA 0x00b84c10 ; FUN_00b84c10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b84c10(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1bec) {
    FUN_016f3809(&DAT_01ef1bec);
    if (DAT_01ef1bec == -1) {
      _DAT_01ef1be0 = FUN_005c65e0;
      _DAT_01ef1be4 = FUN_005c65e0;
      _DAT_01ef1be8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef1bec);
    }
  }
  return &DAT_01ef1be0;
}



/* FUNCTION 25151 ; VA 0x00b84c80 ; FUN_00b84c80 */

undefined * FUN_00b84c80(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8bac;
  pvStack_10 = ExceptionList;
  if (DAT_01ef1c30 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1e40) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef1e40);
      if (DAT_01ef1e40 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"CookiesService",1,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01890620);
        FUN_016f37bf(&DAT_01ef1e40);
      }
    }
    DAT_01ef1c30 = &DAT_01ef1c38;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef1c30;
}



/* FUNCTION 25152 ; VA 0x00b84d60 ; FUN_00b84d60 */

void FUN_00b84d60(void)

{
  int iVar1;
  
  if (DAT_01ef1e44 == 0) {
    iVar1 = FUN_00b84c80();
    DAT_01ef1e44 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 25153 ; VA 0x00b84d80 ; FUN_00b84d80 */

undefined4 * __fastcall FUN_00b84d80(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  int aiStack_44 [5];
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8beb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::CookiesService,class_RBX::ServiceInstance>::vftable;
  uVar5 = FUN_00b84c80();
  param_1[3] = uVar5;
  puVar1 = param_1 + 0x16;
  *param_1 = RBX::CookiesService::vftable;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0xf;
  *(undefined *)puVar1 = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  FUN_0054eff0("CookiesService");
  uStack_8._0_1_ = 3;
  FUN_008a6520(auStack_2c);
  uStack_8._0_1_ = 2;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_18) {
    uVar8 = uStack_18 + 1;
    uVar9 = auStack_2c[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_2c[0] - 4);
      uVar8 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar9) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  uVar5 = FUN_0153f4c0(aiStack_44);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  puVar6 = (undefined4 *)FUN_0153f740(auStack_2c,uVar5);
  if (puVar1 != puVar6) {
    FUN_005507b0();
    uVar5 = puVar6[1];
    uVar2 = puVar6[2];
    uVar3 = puVar6[3];
    *puVar1 = *puVar6;
    param_1[0x17] = uVar5;
    param_1[0x18] = uVar2;
    param_1[0x19] = uVar3;
    *(undefined8 *)(param_1 + 0x1a) = *(undefined8 *)(puVar6 + 4);
    puVar6[4] = 0;
    puVar6[5] = 0xf;
    *(undefined *)puVar6 = 0;
  }
  if (0xf < uStack_18) {
    uVar8 = uStack_18 + 1;
    uVar9 = auStack_2c[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_2c[0] - 4);
      uVar8 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  if (7 < uStack_30) {
    uVar9 = uStack_30 * 2 + 2;
    iVar7 = aiStack_44[0];
    if (0xfff < uVar9) {
      iVar7 = *(int *)(aiStack_44[0] + -4);
      uVar9 = uStack_30 * 2 + 0x25;
      if (0x1f < (aiStack_44[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar9);
  }
  ExceptionList = pvStack_10;
  return puStack_14;
}



/* FUNCTION 25154 ; VA 0x00b84f20 ; FUN_00b84f20 */

int __thiscall FUN_00b84f20(int param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x6c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x58);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x68) = 0;
  *(undefined4 *)(param_1 + 0x6c) = 0xf;
  *(undefined *)(param_1 + 0x58) = 0;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x70);
  }
  return param_1;
}



/* FUNCTION 25155 ; VA 0x00b84f90 ; FUN_00b84f90 */

int * __thiscall
FUN_00b84f90(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baf8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b85410();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::InsertService,bool>::
              GetSetImpl<bool_(__thiscall_RBX::InsertService::*)(void)const_,void_(__thiscall_RBX::InsertService::*)(bool)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::InsertService,bool>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::InsertService,bool>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25156 ; VA 0x00b85090 ; FUN_00b85090 */

undefined4 * __thiscall
FUN_00b85090(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined **ppuVar3;
  undefined4 auStack_a0 [2];
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f8c18;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_40 = param_2;
  uStack_38 = 0;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_74 = 0;
      puStack_78 = &uStack_30;
      uStack_80 = CONCAT44(&param_6,0xb850fd);
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = CONCAT44(param_11,param_10);
    }
  }
  uVar1 = uStack_40;
  uStack_8._0_1_ = 1;
  puVar2 = param_1 + 2;
  uStack_60 = 0;
  if (uStack_38 != 0) {
    uStack_60 = uStack_38;
    if ((uStack_38 & 1) == 0) {
      puStack_78 = &uStack_58;
      uStack_74 = 0;
      uStack_80 = CONCAT44(&uStack_30,0xb85149);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    else {
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
      uStack_48 = uStack_20;
    }
  }
  uStack_74 = param_11;
  uStack_8._0_1_ = 2;
  puStack_18 = (undefined *)auStack_a0;
  uStack_98 = 0;
  auStack_a0[0] = uVar1;
  puStack_78 = puVar2;
  puVar2 = auStack_a0;
  if (uStack_60 != 0) {
    uStack_98 = uStack_60;
    if ((uStack_60 & 1) == 0) {
      (**(code **)(uStack_60 & 0xfffffffe))(&uStack_58,&uStack_90,0);
      puVar2 = (undefined4 *)puStack_18;
    }
    else {
      uStack_90 = uStack_58;
      uStack_8c = uStack_54;
      uStack_88 = uStack_50;
      uStack_84 = uStack_4c;
      uStack_80 = uStack_48;
      puVar2 = auStack_a0;
    }
  }
  puStack_18 = (undefined *)puVar2;
  ppuVar3 = &PTR_FUN_01959318;
  cStack_11 = FUN_00b85530();
  uStack_8._0_1_ = 3;
  if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
     (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_58;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0xb851d3);
    (**(code **)(uStack_60 & 0xfffffffe))();
  }
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_38 != 0) {
    if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_30;
      uStack_74 = 2;
      uStack_80 = CONCAT44(puStack_78,0xb8520e);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    uStack_38 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_6;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0xb8523c);
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25157 ; VA 0x00b85260 ; FUN_00b85260 */

int * __thiscall FUN_00b85260(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  char cVar4;
  int *piVar5;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  int iStack_108;
  int *piStack_104;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f8c69;
  pvStack_10 = ExceptionList;
  param_1 = (int *)*param_1;
  piVar5 = (int *)param_2[1];
  ExceptionList = &pvStack_10;
  if (piVar5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = (int *)param_2[1];
  }
  iVar2 = *param_2;
  uStack_8 = 0;
  iStack_38 = iVar2;
  piStack_34 = piVar5;
  piStack_14 = param_1;
  if ((iVar2 != 0) &&
     ((param_1 == *(int **)(iVar2 + 0x34) ||
      ((*(int **)(iVar2 + 0x34) != (int *)0x0 &&
       (param_1 = (int *)FUN_00620ec0(param_1), (char)param_1 != '\0')))))) {
    cVar4 = FUN_00971ce0(piStack_14,1);
    if (cVar4 == '\0') {
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
      }
      uStack_30 = 0;
      uStack_2c = 0;
      uStack_40 = 0;
      uStack_3c = 0;
      uStack_8._0_1_ = 2;
      pcVar3 = *(code **)(*piStack_14 + 8);
      iStack_1c = iVar2;
      piStack_18 = piVar5;
      uStack_110 = FUN_0088cdc0();
      uStack_10c = 0;
      iStack_1c = 0;
      piStack_18 = (int *)0x0;
      iStack_108 = iVar2;
      piStack_104 = piVar5;
      uStack_10c = FUN_006309e0();
      uStack_8._0_1_ = 3;
      uStack_28 = 0;
      uStack_24 = 0;
      uStack_20 = 0;
      FUN_00687980(&uStack_110,&uStack_40,iVar2);
      uStack_8._0_1_ = 4;
      (*pcVar3)(&DAT_0212f018,&uStack_28,&uStack_30);
      uStack_8._0_1_ = 5;
      FUN_00577b20();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      param_1 = (int *)FUN_016f32d1(&uStack_110,0xd0,1,FUN_0056e5b0);
    }
    else {
      param_1 = (int *)FUN_008a65e0(0,0);
    }
  }
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar1 = piVar5 + 1;
    iVar2 = *piVar1;
    param_1 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_1 = (int *)(**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_1 = (int *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25158 ; VA 0x00b85410 ; FUN_00b85410 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b85410(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8ca0;
  pvStack_10 = ExceptionList;
  if (DAT_01ef1e60 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef2078) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef2078);
      if (DAT_01ef2078 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"InsertService",1,uStack_20,0,0,0xb,0,0);
        _DAT_01ef2070 = RBX::Creator<class_RBX::InsertService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef1e68,&DAT_01ef2070);
        FUN_016f3654(FUN_018908d0);
        FUN_016f37bf(&DAT_01ef2078);
      }
    }
    DAT_01ef1e60 = &DAT_01ef1e68;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef1e60;
}



/* FUNCTION 25159 ; VA 0x00b85510 ; FUN_00b85510 */

void FUN_00b85510(void)

{
  int iVar1;
  
  if (DAT_01ef207c == 0) {
    iVar1 = FUN_00b85410();
    DAT_01ef207c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 25160 ; VA 0x00b85530 ; FUN_00b85530 */

undefined FUN_00b85530(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined8 param_9,int *param_10)

{
  undefined4 uVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f8ccf;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00585a40(&param_1);
  uVar1 = param_1;
  if (cVar2 == '\0') {
    uStack_34 = 0;
    if (param_3 != 0) {
      uStack_34 = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_2c,0);
      }
      else {
        uStack_2c = param_5;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
      }
    }
    uStack_8._0_1_ = 1;
    puVar4 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 2;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[2] = 0;
      if (uStack_34 != 0) {
        puVar4[2] = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,puVar4 + 4,0);
        }
        else {
          puVar4[4] = uStack_2c;
          puVar4[5] = uStack_28;
          puVar4[6] = uStack_24;
          puVar4[7] = uStack_20;
          *(undefined8 *)(puVar4 + 8) = uStack_1c;
        }
      }
    }
    *param_10 = (int)puVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
       (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  uStack_8 = 4;
  param_10._3_1_ = uVar3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_10._3_1_;
}



/* FUNCTION 25161 ; VA 0x00b85690 ; FUN_00b85690 */

/* WARNING: Restarted to delay deadcode elimination for space: ram */

code * FUN_00b85690(code *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 in_stack_00000024;
  int *in_stack_00000028;
  undefined4 uStack_1bc;
  code **ppcStack_1b8;
  undefined auStack_1b4 [184];
  undefined4 uStack_fc;
  undefined *puStack_f8;
  undefined *puStack_f4;
  int *piStack_f0;
  undefined4 uStack_dc;
  int *piStack_d8;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c664b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  piStack_f0 = (int *)0xb856bc;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_008882f0();
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    in_stack_00000028[1] = in_stack_00000028[1] + 1;
    UNLOCK();
  }
  uStack_dc = in_stack_00000024;
  piStack_d8 = in_stack_00000028;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c38) {
    piStack_f0 = &DAT_01ea8c38;
    puStack_f4 = (undefined *)0xb857fc;
    FUN_016f3809();
    if (DAT_01ea8c38 == -1) {
      piStack_f0 = &DAT_01ea8c38;
      DAT_01ea8c2c = FUN_0057bbb0;
      DAT_01ea8c30 = FUN_005880a0;
      DAT_01ea8c34 = FUN_0057d5e0;
      puStack_f4 = (undefined *)0xb85834;
      FUN_016f37bf();
    }
  }
  puStack_14 = (undefined *)&uStack_1bc;
  uStack_8._0_1_ = 2;
  ppcStack_1b8 = (code **)0x0;
  uStack_1bc = uVar4;
  (*DAT_01ea8c2c)(&uStack_dc,auStack_1b4);
  ppcStack_1b8 = &DAT_01ea8c2c;
  FUN_008c6ce0();
  uStack_8._0_1_ = 3;
  piStack_f0 = &uStack_dc;
  puStack_f4 = (undefined *)0xb8578c;
  (*DAT_01ea8c34)();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_1 != (code *)0x0) && (((uint)param_1 & 1) == 0)) &&
     (param_1 = *(code **)((uint)param_1 & 0xfffffffe), param_1 != (code *)0x0)) {
    puStack_f8 = &stack0x0000000c;
    piStack_f0 = (int *)0x2;
    uStack_fc = 0xb857b0;
    puStack_f4 = puStack_f8;
    param_1 = (code *)(*param_1)();
  }
  piVar3 = in_stack_00000028;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000028 + 1;
    iVar2 = *piVar1;
    param_1 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_f0 = (int *)0xb857d3;
      param_1 = (code *)(**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_f0 = (int *)0xb857e2;
        param_1 = (code *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25162 ; VA 0x00b85840 ; FUN_00b85840 */

void FUN_00b85840(uint param_1)

{
  undefined *puVar1;
  undefined auStack_1b8 [4];
  undefined4 uStack_1b4;
  undefined auStack_1b0 [184];
  undefined4 uStack_f8;
  undefined *puStack_f4;
  undefined *puStack_f0;
  undefined *puStack_ec;
  undefined4 *puStack_e0;
  undefined auStack_dc [200];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017be3c3;
  pvStack_10 = ExceptionList;
  puStack_ec = &stack0x00000024;
  uStack_8 = 0;
  puStack_f0 = (undefined *)0xb85875;
  ExceptionList = &pvStack_10;
  FUN_005c1470();
  puStack_14 = auStack_1b8;
  uStack_8._0_1_ = 1;
  uStack_1b4 = 0;
  puVar1 = auStack_1b8;
  if (puStack_e0 != (undefined4 *)0x0) {
    (*(code *)*puStack_e0)(auStack_dc,auStack_1b0);
    puVar1 = puStack_14;
  }
  puStack_14 = puVar1;
  FUN_008c6ce0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puStack_e0 != (undefined4 *)0x0) {
    puStack_ec = auStack_dc;
    puStack_f0 = (undefined *)0xb858da;
    (*(code *)puStack_e0[2])();
  }
  uStack_8 = 3;
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    puStack_f4 = &stack0x0000000c;
    puStack_ec = (undefined *)0x2;
    uStack_f8 = 0xb85901;
    puStack_f0 = puStack_f4;
    (**(code **)(param_1 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25163 ; VA 0x00b85920 ; FUN_00b85920 */

undefined4 * __thiscall FUN_00b85920(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8ceb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[2] = 0;
  uVar1 = param_2[2];
  if (uVar1 != 0) {
    param_1[2] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar2 = param_2[5];
      uVar3 = param_2[6];
      uVar4 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar2;
      param_1[6] = uVar3;
      param_1[7] = uVar4;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  uVar1 = param_2[10];
  uStack_8 = 0;
  if (uVar1 != 0) {
    param_1[10] = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = param_2[0xd];
      uVar3 = param_2[0xe];
      uVar4 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar2;
      param_1[0xe] = uVar3;
      param_1[0xf] = uVar4;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25164 ; VA 0x00b859f0 ; FUN_00b859f0 */

undefined4 * __thiscall FUN_00b859f0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f8d13;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar2 = param_2[2];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  uVar2 = param_2[10];
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (uVar2 != 0) {
    param_1[10] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0xd];
      uVar4 = param_2[0xe];
      uVar5 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar3;
      param_1[0xe] = uVar4;
      param_1[0xf] = uVar5;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25165 ; VA 0x00b85af0 ; FUN_00b85af0 */

undefined4 * __thiscall FUN_00b85af0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017f8d3e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = 0;
  uVar2 = param_2[4];
  uStack_8 = 1;
  uStack_7 = 0;
  if (uVar2 != 0) {
    param_1[4] = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 6,param_1 + 6,0);
    }
    else {
      uVar3 = param_2[7];
      uVar4 = param_2[8];
      uVar5 = param_2[9];
      param_1[6] = param_2[6];
      param_1[7] = uVar3;
      param_1[8] = uVar4;
      param_1[9] = uVar5;
      *(undefined8 *)(param_1 + 10) = *(undefined8 *)(param_2 + 10);
    }
  }
  param_1[0xc] = 0;
  uVar2 = param_2[0xc];
  _uStack_8 = CONCAT31(uStack_7,2);
  if (uVar2 != 0) {
    param_1[0xc] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[0xf];
      uVar4 = param_2[0x10];
      uVar5 = param_2[0x11];
      param_1[0xe] = param_2[0xe];
      param_1[0xf] = uVar3;
      param_1[0x10] = uVar4;
      param_1[0x11] = uVar5;
      *(undefined8 *)(param_1 + 0x12) = *(undefined8 *)(param_2 + 0x12);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 0xe,param_1 + 0xe,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25166 ; VA 0x00b85c10 ; FUN_00b85c10 */

undefined4 * __thiscall
FUN_00b85c10(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 *param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8d9b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_00b85410();
  FUN_009cb790(uVar1,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::BoundFuncDesc<class_RBX::InsertService,void___cdecl(__int64),1>::
             vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar1 = FUN_00888530();
  param_1[9] = uVar1;
  if (param_1[0x10] == 0) {
    uStack_e8 = FUN_00888530();
    iStack_e4 = 0;
    param_6 = &uStack_e8;
    uStack_8 = 3;
    uVar3 = 2;
  }
  else {
    param_6 = (undefined4 *)FUN_005c1470(param_1[0x10]);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar3 = 1;
  }
  uStack_14 = uVar3;
  uVar1 = FUN_0088da50();
  uVar2 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar2,uVar1,param_6);
  if ((uVar3 & 2) != 0) {
    uVar3 = uVar3 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar3;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  if ((uVar3 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25167 ; VA 0x00b85d70 ; FUN_00b85d70 */

undefined4 * __thiscall
FUN_00b85d70(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 *param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8dfb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_00b85410();
  FUN_009cb820(uVar1,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundYieldFuncDesc<class_RBX::InsertService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(__int64),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar1 = FUN_008882f0();
  param_1[9] = uVar1;
  if (param_1[0x10] == 0) {
    uStack_e8 = FUN_00888530();
    iStack_e4 = 0;
    param_6 = &uStack_e8;
    uStack_8 = 3;
    uVar3 = 2;
  }
  else {
    param_6 = (undefined4 *)FUN_005c1470(param_1[0x10]);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar3 = 1;
  }
  uStack_14 = uVar3;
  uVar1 = FUN_0088da50();
  uVar2 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar2,uVar1,param_6);
  if ((uVar3 & 2) != 0) {
    uVar3 = uVar3 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar3;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  if ((uVar3 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25168 ; VA 0x00b85ed0 ; FUN_00b85ed0 */

undefined4 * __thiscall
FUN_00b85ed0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 *param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8dfb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_00b85410();
  FUN_009cb820(uVar1,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundYieldFuncDesc<class_RBX::InsertService,class_std::shared_ptr<class_RBX::Instance>___cdecl(__int64),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar1 = FUN_0088cdc0();
  param_1[9] = uVar1;
  if (param_1[0x10] == 0) {
    uStack_e8 = FUN_00888530();
    iStack_e4 = 0;
    param_6 = &uStack_e8;
    uStack_8 = 3;
    uVar3 = 2;
  }
  else {
    param_6 = (undefined4 *)FUN_005c1470(param_1[0x10]);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar3 = 1;
  }
  uStack_14 = uVar3;
  uVar1 = FUN_0088da50();
  uVar2 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar2,uVar1,param_6);
  if ((uVar3 & 2) != 0) {
    uVar3 = uVar3 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar3;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  if ((uVar3 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25169 ; VA 0x00b86030 ; FUN_00b86030 */

undefined4 * __fastcall FUN_00b86030(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8e5f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::InsertService,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_00b85410();
  param_1[3] = uVar1;
  *param_1 = RBX::InsertService::vftable;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  *(undefined2 *)(param_1 + 0x1d) = 0;
  *(undefined *)((int)param_1 + 0x76) = 0;
  param_1[0x1e] = 0;
  uStack_8._0_1_ = 6;
  uStack_8._1_3_ = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("InsertService",0xd);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25170 ; VA 0x00b86140 ; FUN_00b86140 */

void __fastcall FUN_00b86140(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::InsertService>::vftable;
  uVar1 = FUN_00b85410(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25171 ; VA 0x00b86180 ; FUN_00b86180 */

int FUN_00b86180(undefined4 param_1,int *param_2,int *param_3,int param_4,int *param_5)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  char cVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined **ppuVar7;
  int iVar8;
  uint uVar9;
  int *piVar10;
  int aiStack_244 [5];
  undefined4 uStack_230;
  undefined4 uStack_22c;
  undefined *puStack_228;
  undefined auStack_21c [80];
  undefined auStack_1cc [80];
  undefined auStack_17c [80];
  undefined auStack_12c [80];
  undefined auStack_dc [80];
  int iStack_8c;
  int *piStack_88;
  undefined4 uStack_84;
  int *piStack_80;
  uint uStack_7c;
  int iStack_74;
  int iStack_70;
  int iStack_6c;
  int iStack_68;
  undefined8 uStack_64;
  uint uStack_5c;
  int iStack_54;
  int iStack_50;
  int iStack_4c;
  int iStack_48;
  undefined8 uStack_44;
  undefined auStack_3c [4];
  int *piStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  int iStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f8eff;
  pvStack_10 = ExceptionList;
  puStack_228 = auStack_3c;
  uStack_8 = 1;
  uStack_22c = 0xb861b3;
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_00942ec0();
  uStack_34 = *puVar5;
  piVar10 = (int *)puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  piStack_24 = piStack_38;
  piStack_30 = piVar10;
  piStack_20 = piVar10;
  uStack_18 = uStack_34;
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_38[1] + -1;
    piStack_38[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      puStack_228 = (undefined *)0xb861f2;
      (**(code **)*piStack_38)();
      LOCK();
      iVar8 = piStack_24[2] + -1;
      piStack_24[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        puStack_228 = (undefined *)0xb86203;
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  uVar2 = uStack_18;
  iVar8 = *param_2;
  if (iVar8 != param_2[1]) {
    do {
      puStack_228 = (undefined *)0x0;
      uStack_22c = uVar2;
      uStack_230 = 0xb8621a;
      FUN_008a65e0();
      iVar8 = iVar8 + 8;
      piVar10 = piStack_20;
    } while (iVar8 != param_2[1]);
  }
  uVar9 = 0;
  if (param_2[1] - *param_2 >> 3 != 0) {
    do {
      puStack_228 = *(undefined **)(*param_2 + uVar9 * 8);
      uStack_22c = 0xb86240;
      FUN_00b03d60();
      uVar9 = uVar9 + 1;
    } while (uVar9 < (uint)(param_2[1] - *param_2 >> 3));
  }
  iStack_2c = 0;
  piStack_28 = (int *)0x0;
  iVar8 = piStack_1c[1];
  if (iVar8 != 0) {
    piVar1 = (int *)(iVar8 + 4);
    iVar8 = *(int *)(iVar8 + 4);
    while (piVar10 = piStack_30, iVar8 != 0) {
      LOCK();
      iVar6 = *piVar1;
      if (iVar8 == iVar6) {
        *piVar1 = iVar8 + 1;
        iVar6 = iVar8;
      }
      UNLOCK();
      if (iVar6 == iVar8) {
        uStack_18 = uStack_34;
        iStack_2c = *piStack_1c;
        piStack_28 = (int *)piStack_1c[1];
        goto LAB_00b862b4;
      }
      iVar8 = *piVar1;
    }
    uStack_18 = uStack_34;
  }
LAB_00b862b4:
  piVar1 = piStack_28;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  iVar8 = iStack_2c;
  if (iStack_2c != 0) {
    piStack_38 = &iStack_8c;
    piStack_20 = aiStack_244;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    piStack_24 = param_5;
    iStack_8c = param_4;
    piStack_88 = param_5;
    if (piVar10 != (int *)0x0) {
      LOCK();
      piVar10[1] = piVar10[1] + 1;
      UNLOCK();
    }
    uVar9 = piStack_1c[2];
    uStack_8._0_1_ = 5;
    uStack_7c = 0;
    uStack_84 = uStack_18;
    piStack_80 = piVar10;
    piVar3 = aiStack_244;
    if (uVar9 != 0) {
      uStack_7c = uVar9;
      if ((uVar9 & 1) == 0) {
        (**(code **)(uVar9 & 0xfffffffe))(piStack_1c + 4,&iStack_74,0);
        piVar3 = piStack_20;
      }
      else {
        iStack_74 = piStack_1c[4];
        iStack_70 = piStack_1c[5];
        iStack_6c = piStack_1c[6];
        iStack_68 = piStack_1c[7];
        uStack_64 = *(undefined8 *)(piStack_1c + 8);
        piVar3 = aiStack_244;
      }
    }
    piStack_20 = piVar3;
    uVar9 = piStack_1c[10];
    uStack_8._0_1_ = 6;
    uStack_5c = 0;
    if (uVar9 != 0) {
      uStack_5c = uVar9;
      if ((uVar9 & 1) == 0) {
        (**(code **)(uVar9 & 0xfffffffe))(piStack_1c + 0xc,&iStack_54,0);
      }
      else {
        iStack_54 = piStack_1c[0xc];
        iStack_50 = piStack_1c[0xd];
        iStack_4c = piStack_1c[0xe];
        iStack_48 = piStack_1c[0xf];
        uStack_44 = *(undefined8 *)(piStack_1c + 0x10);
      }
    }
    uStack_8._0_1_ = 7;
    FUN_00b85af0(&iStack_8c);
    uStack_8._0_1_ = 8;
    *piStack_20 = 0;
    FUN_00b85af0(auStack_21c);
    uStack_8._0_1_ = 9;
    FUN_00b85af0(auStack_1cc);
    uStack_8._0_1_ = 10;
    FUN_00b85af0(auStack_17c);
    uStack_8._0_1_ = 0xb;
    cVar4 = FUN_00585a40(auStack_dc);
    if (cVar4 == '\0') {
      FUN_00b85af0(auStack_dc);
      uStack_8._0_1_ = 0xc;
      piStack_38 = (int *)FUN_01674e20(0x50);
      uStack_8._0_1_ = 0xd;
      if (piStack_38 == (int *)0x0) {
        iVar8 = 0;
      }
      else {
        iVar8 = FUN_00b85af0(auStack_12c);
      }
      piStack_20[2] = iVar8;
      FUN_008e9ac0();
      FUN_008e9ac0();
      cStack_11 = '\x01';
    }
    else {
      FUN_008e9ac0();
      cStack_11 = '\0';
    }
    FUN_008e9ac0();
    ppuVar7 = &PTR_FUN_01959320;
    if (cStack_11 == '\0') {
      ppuVar7 = (undefined **)0x0;
    }
    *piStack_20 = (int)ppuVar7;
    FUN_008e9ac0();
    FUN_008e9ac0();
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_008e9ac0();
    if (piVar1 != (int *)0x0) {
      LOCK();
      piVar1[1] = piVar1[1] + 1;
      UNLOCK();
    }
    iVar8 = FUN_00ae4d60(iStack_2c,piVar1,uStack_18,3);
  }
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar3 = piVar1 + 1;
    iVar6 = *piVar3;
    iVar8 = *piVar3;
    *piVar3 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      puStack_228 = (undefined *)0xb86518;
      (**(code **)*piVar1)();
      LOCK();
      piVar3 = piVar1 + 2;
      iVar6 = *piVar3;
      iVar8 = *piVar3;
      *piVar3 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        puStack_228 = (undefined *)0xb86529;
        iVar8 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (piVar10 != (int *)0x0) {
    LOCK();
    piVar1 = piVar10 + 1;
    iVar6 = *piVar1;
    iVar8 = *piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      puStack_228 = (undefined *)0xb8653d;
      (**(code **)*piVar10)();
      LOCK();
      piVar1 = piVar10 + 2;
      iVar6 = *piVar1;
      iVar8 = *piVar1;
      *piVar1 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        puStack_228 = (undefined *)0xb8654e;
        iVar8 = (**(code **)(*piVar10 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar10 = param_3 + 1;
    iVar6 = *piVar10;
    iVar8 = *piVar10;
    *piVar10 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      puStack_228 = (undefined *)0xb86567;
      (**(code **)*param_3)();
      LOCK();
      piVar10 = param_3 + 2;
      iVar6 = *piVar10;
      iVar8 = *piVar10;
      *piVar10 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        puStack_228 = (undefined *)0xb86577;
        iVar8 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar10 = param_5 + 1;
    iVar6 = *piVar10;
    iVar8 = *piVar10;
    *piVar10 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      puStack_228 = (undefined *)0xb8658d;
      iVar8 = (**(code **)*param_5)();
      LOCK();
      piVar10 = param_5 + 2;
      iVar6 = *piVar10;
      *piVar10 = *piVar10 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        puStack_228 = (undefined *)0xb8659c;
        iVar8 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 25172 ; VA 0x00b865b0 ; FUN_00b865b0 */

void __fastcall FUN_00b865b0(int *param_1)

{
  char cVar1;
  char *pcVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  char *pcVar7;
  undefined uVar8;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8f30;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = 2;
    uVar3 = (**(code **)(*(int *)*param_1 + 4))();
    FUN_0151f850("Exception",uVar3);
    uVar3 = DAT_01ef1e50;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("InsertServiceFailure",0x14);
    uStack_8._0_1_ = 3;
    FUN_01520d20(auStack_34,uVar3,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (0xf < uStack_20) {
      uVar6 = uStack_20 + 1;
      uVar4 = auStack_34[0];
      if (0xfff < uVar6) {
        uVar4 = *(uint *)(auStack_34[0] - 4);
        uVar6 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar4,uVar6);
    }
    pcVar2 = (char *)(**(code **)(*(int *)*param_1 + 4))();
    uVar8 = 0;
    pcVar7 = pcVar2;
    do {
      cVar1 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(pcVar2,(int)pcVar7 - (int)(pcVar2 + 1));
    FUN_005e65e0(uVar8);
    FUN_0151f7f0();
    ExceptionList = pvStack_10;
    return;
  }
  iVar5 = param_1[3];
  ExceptionList = &pvStack_10;
  if (iVar5 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
    UNLOCK();
    iVar5 = param_1[3];
  }
  uStack_8 = 0;
  if (param_1[4] != 0) {
    iStack_1c = 0;
    iStack_18 = 0;
    (**(code **)((param_1[4] & 0xfffffffeU) + 4))(param_1 + 6,param_1[2],iVar5);
    ExceptionList = pvStack_10;
    return;
  }
  iStack_1c = param_1[2];
  iStack_18 = iVar5;
  uVar3 = FUN_0054fda0();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar3);
}



/* FUNCTION 25173 ; VA 0x00b86740 ; FUN_00b86740 */

int __thiscall FUN_00b86740(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  FUN_0056cee0();
  FUN_009cb8d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 25174 ; VA 0x00b867a0 ; FUN_00b867a0 */

int __thiscall FUN_00b867a0(int param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)(param_1 + 0x78);
  ExceptionList = &pvStack_10;
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x70);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x7c);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25175 ; VA 0x00b86870 ; FUN_00b86870 */

void FUN_00b86870(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 *param_4,
                 uint *param_5,uint *param_6)

{
  undefined4 uVar1;
  uint uVar2;
  uint *puVar3;
  uint *puVar4;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  undefined8 uStack_9c;
  undefined4 uStack_94;
  undefined4 uStack_80;
  uint *puStack_7c;
  uint *puStack_78;
  undefined4 uStack_74;
  uint auStack_70 [2];
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined8 uStack_58;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined8 uStack_28;
  undefined *puStack_20;
  undefined *puStack_1c;
  code *pcStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f9180;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)auStack_70;
  puStack_20 = (undefined *)auStack_70;
  pcStack_18 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ef1e5d);
  uStack_14 = *param_4;
  uVar1 = param_4[1];
  auStack_70[0] = 0;
  uVar2 = *param_6;
  ExceptionList = &pvStack_10;
  puVar3 = auStack_70;
  puVar4 = auStack_70;
  if (uVar2 != 0) {
    auStack_70[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_78 = &uStack_68;
      uStack_74 = 0;
      puStack_7c = param_6 + 2;
      uStack_80 = 0xb868f5;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
      puVar3 = (uint *)puStack_20;
      puVar4 = (uint *)puStack_1c;
    }
    else {
      uStack_68 = param_6[2];
      uStack_64 = param_6[3];
      uStack_60 = param_6[4];
      uStack_5c = param_6[5];
      uStack_58 = *(undefined8 *)(param_6 + 6);
      ExceptionList = &pvStack_10;
      puVar3 = auStack_70;
      puVar4 = auStack_70;
    }
  }
  puStack_1c = (undefined *)puVar4;
  puStack_20 = (undefined *)puVar3;
  uStack_8 = 0;
  uStack_94 = param_1;
  uVar2 = *param_5;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_5 + 2);
    }
    else {
      uStack_ac = param_5[2];
      uStack_a8 = param_5[3];
      uStack_a4 = param_5[4];
      uStack_a0 = param_5[5];
      uStack_9c = *(undefined8 *)(param_5 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_94 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_40 != 0) {
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_ac,0);
    }
    else {
      uStack_ac = uStack_38;
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
    }
  }
  FUN_00960800();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    uStack_94 = 2;
    uStack_9c = CONCAT44(&uStack_38,&uStack_38);
    uStack_a0 = 0xb869d7;
    (**(code **)(uStack_40 & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_9c = CONCAT44(uStack_14,0xb869f7);
  uStack_94 = uVar1;
  (*pcStack_18)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25176 ; VA 0x00b86a10 ; FUN_00b86a10 */

void FUN_00b86a10(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 *param_5,uint *param_6,uint *param_7)

{
  undefined4 uVar1;
  uint uVar2;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined auStack_94 [8];
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_6c;
  undefined4 uStack_58;
  uint *puStack_54;
  uint *puStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f91a0;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ef1e5d);
  uVar1 = *param_5;
  uStack_48 = 0;
  uVar2 = *param_7;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_48 = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_50 = &uStack_40;
      uStack_4c = 0;
      puStack_54 = param_7 + 2;
      uStack_58 = 0xb86a92;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_7[2];
      uStack_3c = param_7[3];
      uStack_38 = param_7[4];
      uStack_34 = param_7[5];
      uStack_30 = *(undefined8 *)(param_7 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_6c = 0;
  uStack_98 = param_1;
  uVar2 = *param_6;
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_6 + 2,&uStack_b0,0);
    }
    else {
      uStack_b0 = param_6[2];
      uStack_ac = param_6[3];
      uStack_a8 = param_6[4];
      uStack_a4 = param_6[5];
      uStack_a0 = *(undefined8 *)(param_6 + 6);
    }
  }
  FUN_008bfbf0(auStack_94,FUN_00b85690);
  uStack_98 = 0xb86b09;
  FUN_00912f20();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_88 = param_4;
  uStack_8c = 0xb86b1d;
  uStack_6c = uVar1;
  FUN_0054ef60();
  uStack_8 = 0xffffffff;
  uStack_88 = 0xb86b2a;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25177 ; VA 0x00b86b40 ; FUN_00b86b40 */

void FUN_00b86b40(undefined4 param_1,code *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 *param_5,undefined4 *param_6,uint *param_7,uint *param_8)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uStack_b0;
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined8 uStack_a0;
  undefined4 uStack_98;
  undefined auStack_94 [4];
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_58;
  uint *puStack_54;
  uint *puStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f91c0;
  pvStack_10 = ExceptionList;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ef1e5d);
  uVar1 = *param_6;
  uVar2 = *param_5;
  uStack_48 = 0;
  uVar3 = *param_8;
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    uStack_48 = uVar3;
    if ((uVar3 & 1) == 0) {
      puStack_50 = &uStack_40;
      uStack_4c = 0;
      puStack_54 = param_8 + 2;
      uStack_58 = 0xb86bca;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_40 = param_8[2];
      uStack_3c = param_8[3];
      uStack_38 = param_8[4];
      uStack_34 = param_8[5];
      uStack_30 = *(undefined8 *)(param_8 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uStack_6c = 0;
  uStack_98 = param_1;
  uVar3 = *param_7;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(param_7 + 2,&uStack_b0,0);
    }
    else {
      uStack_b0 = param_7[2];
      uStack_ac = param_7[3];
      uStack_a8 = param_7[4];
      uStack_a4 = param_7[5];
      uStack_a0 = *(undefined8 *)(param_7 + 6);
    }
  }
  FUN_008bfbf0(auStack_94,FUN_00966b00);
  uStack_98 = 0xb86c41;
  FUN_00960740();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_8c = param_4;
  uStack_90 = 0xb86c5b;
  uStack_70 = uVar2;
  uStack_6c = uVar1;
  FUN_0054ef60();
  uStack_8 = 0xffffffff;
  uStack_8c = 0xb86c68;
  (*param_2)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25178 ; VA 0x00b86c80 ; FUN_00b86c80 */

undefined4 * FUN_00b86c80(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00634a80(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 25179 ; VA 0x00b86cf0 ; FUN_00b86cf0 */

void __thiscall FUN_00b86cf0(int param_1,uint param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 *in_stack_00000038;
  ulonglong in_stack_0000003c;
  uint in_stack_00000044;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined8 in_stack_0000005c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f91f0;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x34);
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if (iVar1 != 0) {
    iVar2 = *(int *)(iVar1 + 0xc);
    uStack_28 = CONCAT44(0xb86d27,(undefined4)uStack_28);
    ExceptionList = &pvStack_10;
    iVar3 = FUN_008dcf60();
    if (((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
         (uint)*(ushort *)(iVar3 + 0x1da)) && (iVar1 + -0xc != 0)) {
      uStack_40 = 0;
      if (in_stack_00000044 != 0) {
        uStack_40 = in_stack_00000044;
        if ((in_stack_00000044 & 1) == 0) {
          uStack_48 = ZEXT48(&uStack_38);
          puStack_4c = &stack0x0000004c;
          uStack_50 = 0xb86d93;
          (**(code **)(in_stack_00000044 & 0xfffffffe))();
        }
        else {
          uStack_38 = in_stack_0000004c;
          uStack_34 = in_stack_00000050;
          uStack_30 = in_stack_00000054;
          puStack_2c = (undefined4 *)in_stack_00000058;
          uStack_28 = in_stack_0000005c;
        }
      }
      uStack_8._0_1_ = 3;
      if (in_stack_00000024 != 0) {
        if ((in_stack_00000024 & 1) == 0) {
          (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&uStack_58,0);
        }
        else {
          uStack_58 = in_stack_0000002c;
          uStack_54 = in_stack_00000030;
          uStack_50 = in_stack_00000034;
          puStack_4c = in_stack_00000038;
          uStack_48 = in_stack_0000003c;
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_00cfc8c0(iVar1 + -0xc,&param_2,in_stack_0000001c,in_stack_00000020);
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    uVar5 = in_stack_00000018 + 1;
    uVar4 = param_2;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(param_2 - 4);
      uVar5 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - uVar4) - 4) {
        uStack_28 = CONCAT44(&UNK_00b86ea8,(undefined4)uStack_28);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_28 = CONCAT44(uVar5,uVar4);
    puStack_2c = (undefined4 *)0xb86e2a;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (in_stack_00000024 != 0) {
    if (((in_stack_00000024 & 1) == 0) &&
       (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
      puStack_2c = &stack0x0000002c;
      uStack_28 = CONCAT44(2,puStack_2c);
      uStack_30 = 0xb86e60;
      (**(code **)(in_stack_00000024 & 0xfffffffe))();
    }
    in_stack_00000024 = 0;
  }
  uStack_8 = 5;
  if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
     (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
    puStack_2c = &stack0x0000004c;
    uStack_28 = CONCAT44(2,puStack_2c);
    uStack_30 = 0xb86e8e;
    (**(code **)(in_stack_00000044 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25180 ; VA 0x00b86eb0 ; FUN_00b86eb0 */

void __thiscall FUN_00b86eb0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd560;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_008882f0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar4 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_005c13e0(iVar1);
    uVar4 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar4;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar5 = &uStack_28c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    puStack_e8 = (undefined4 *)0x0;
    auStack_e4[0] = *puVar5;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c18)
       && (FUN_016f3809(&DAT_01ea8c18), DAT_01ea8c18 == -1)) {
      DAT_01ea8c0c = FUN_005c65e0;
      DAT_01ea8c10 = FUN_005c65e0;
      DAT_01ea8c14 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8c18);
    }
    puStack_e8 = &DAT_01ea8c0c;
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088c8c0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, puStack_e8 != (undefined4 *)0x0)) {
    (*(code *)puStack_e8[2])(auStack_e4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25181 ; VA 0x00b87120 ; FUN_00b87120 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b87120(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined *puStack_e8;
  undefined4 auStack_e4 [50];
  int iStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798aa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  puStack_18 = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088cdc0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 1;
    uVar5 = 2;
  }
  else {
    uStack_ec = thunk_FUN_0088d190();
    puStack_e8 = (undefined *)0x0;
    FUN_0054ef60(iVar1);
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef208c)
       && (FUN_016f3809(&DAT_01ef208c), DAT_01ef208c == -1)) {
      _DAT_01ef2080 = FUN_005c65f0;
      _DAT_01ef2084 = FUN_005c93a0;
      DAT_01ef2088 = FUN_005c77b0;
      FUN_016f37bf(&DAT_01ef208c);
    }
    puStack_e8 = &DAT_01ef2080;
    puVar4 = &uStack_ec;
    uStack_8 = 0;
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = thunk_FUN_0088d190();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (puStack_e8 != (undefined *)0x0) {
      (**(code **)(puStack_e8 + 8))(auStack_e4);
    }
  }
  iVar1 = iStack_1c;
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(iStack_1c + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = thunk_FUN_00b0f580();
    puStack_e8 = (undefined *)0x0;
    auStack_e4[0] = *puVar4;
    puStack_e8 = (undefined *)FUN_00b0f8e0();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = thunk_FUN_00b0f580();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (puStack_e8 != (undefined *)0x0) {
      (**(code **)(puStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(iVar1 + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    uStack_28c = thunk_FUN_00b0f830();
    iStack_288 = 0;
    auStack_284[0] = *puVar4;
    iStack_288 = FUN_00b0faa0();
    puVar4 = &uStack_28c;
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = thunk_FUN_00b0f830();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 0x10) != 0) && (uStack_8 = 0xb, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25182 ; VA 0x00b874a0 ; FUN_00b874a0 */

void __thiscall
FUN_00b874a0(int param_1,undefined4 param_2,uint param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 *param_8,ulonglong param_9,
            char *param_10,undefined4 param_11,uint param_12,undefined4 param_13,undefined4 param_14
            ,undefined4 param_15,undefined8 param_16)

{
  int iVar1;
  int iVar2;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 *puStack_54;
  undefined8 uStack_50;
  char *pcStack_48;
  undefined4 uStack_44;
  uint uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 *puStack_34;
  undefined8 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9218;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    if ((iVar2 != 0) && (param_1 = iVar2, ExceptionList = &pvStack_10, *(int *)(iVar2 + 0x34) != 0))
    {
      uStack_30 = CONCAT44(0xb874e3,(undefined4)uStack_30);
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
    }
    if (param_1 != 0) {
      iVar2 = *(int *)(param_1 + 0xc);
      uStack_30 = CONCAT44(0xb874f9,(undefined4)uStack_30);
      iVar1 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
          (uint)*(ushort *)(iVar1 + 0x1da)) {
        uStack_30 = CONCAT44(0xb8751f,(undefined4)uStack_30);
        iVar2 = FUN_00916350();
        if (iVar2 != 0) {
          uStack_8._0_1_ = 2;
          pcStack_48 = (char *)0x0;
          if (param_10 != (char *)0x0) {
            pcStack_48 = param_10;
            if (((uint)param_10 & 1) == 0) {
              uStack_50 = ZEXT48(&uStack_40);
              puStack_54 = &param_12;
              uStack_58 = 0xb87571;
              (**(code **)((uint)param_10 & 0xfffffffe))();
            }
            else {
              uStack_40 = param_12;
              uStack_3c = param_13;
              uStack_38 = param_14;
              puStack_34 = (undefined4 *)param_15;
              uStack_30 = param_16;
            }
          }
          uStack_8._0_1_ = 3;
          if (param_3 != 0) {
            if ((param_3 & 1) == 0) {
              (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_60,0);
            }
            else {
              uStack_60 = param_5;
              uStack_5c = param_6;
              uStack_58 = param_7;
              puStack_54 = param_8;
              uStack_50 = param_9;
            }
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          FUN_00e50e10(param_2,0x42480000,6);
          uStack_8 = 0;
          goto LAB_00b87637;
        }
      }
    }
  }
  uStack_44 = 0xd;
  uStack_30 = 0xf00000000;
  pcStack_48 = "Shutting down";
  uStack_40 = uStack_40 & 0xffffff00;
  uStack_50 = CONCAT44(0xb8762f,(undefined4)uStack_50);
  FUN_005542c0();
  uStack_44 = 0xb87637;
  FUN_005e65e0();
LAB_00b87637:
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    puStack_34 = &param_5;
    uStack_30 = CONCAT44(2,puStack_34);
    uStack_38 = 0xb87658;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  uStack_8 = 6;
  if (((param_10 != (char *)0x0) && (((uint)param_10 & 1) == 0)) &&
     (*(code **)((uint)param_10 & 0xfffffffe) != (code *)0x0)) {
    puStack_34 = &param_12;
    uStack_30 = CONCAT44(2,puStack_34);
    uStack_38 = 0xb87686;
    (**(code **)((uint)param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25183 ; VA 0x00b875dd ; Catch@00b875dd */

undefined4 Catch_00b875dd(void)

{
  undefined uVar1;
  
  uVar1 = 0;
  FUN_005542c0("Error during dispatch",0x15);
  FUN_005e65e0(uVar1);
  return 0xb875d4;
}



/* FUNCTION 25184 ; VA 0x00b876a0 ; FUN_00b876a0 */

int FUN_00b876a0(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00b85260(&param_2);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 25185 ; VA 0x00b87710 ; FUN_00b87710 */

void __thiscall FUN_00b87710(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  undefined uVar2;
  char cVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  uint in_stack_0000002c;
  undefined4 uStack_110;
  int iStack_10c;
  undefined auStack_108 [200];
  int aiStack_40 [5];
  uint uStack_2c;
  undefined uStack_28;
  undefined auStack_1c [4];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_3;
  puStack_c = &LAB_017f9266;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  uVar4 = (**(code **)*param_3)();
  if (uVar4 < 2) {
LAB_00b877d3:
    if (*(undefined4 **)(param_1 + 0x44) == (undefined4 *)0x0) {
      uVar7 = 2;
      goto LAB_00b87979;
    }
    param_3 = (int *)**(undefined4 **)(param_1 + 0x44);
  }
  else {
    uStack_110 = FUN_00888530();
    iStack_10c = 0;
    uStack_8._0_1_ = 2;
    cVar3 = (**(code **)(*piVar1 + 4))(2,&uStack_110);
    if (cVar3 == '\0') {
      uStack_8._0_1_ = 4;
      if (iStack_10c != 0) {
        (**(code **)(iStack_10c + 8))(auStack_108);
      }
      uStack_8._0_1_ = 1;
      goto LAB_00b877d3;
    }
    puVar5 = (undefined4 *)FUN_00889220();
    param_3 = (int *)*puVar5;
    uStack_8._0_1_ = 3;
    if (iStack_10c != 0) {
      (**(code **)(iStack_10c + 8))(auStack_108);
    }
    uStack_8._0_1_ = 1;
  }
  iVar6 = (**(code **)*piVar1)();
  if (iVar6 != 0) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    uStack_28 = 0;
    uStack_8._0_1_ = 5;
    uStack_110 = FUN_00888530();
    iStack_10c = 0;
    uStack_8._0_1_ = 6;
    cVar3 = (**(code **)(*piVar1 + 4))(1,&uStack_110);
    if (cVar3 != '\0') {
      uVar7 = FUN_008898b0();
      FUN_0054ef60(uVar7);
      uStack_8._0_1_ = 7;
      if (iStack_10c != 0) {
        (**(code **)(iStack_10c + 8))(auStack_108);
      }
      FUN_005507b0();
      goto LAB_00b878b1;
    }
    uStack_8._0_1_ = 8;
    if (iStack_10c != 0) {
      (**(code **)(iStack_10c + 8))(auStack_108);
    }
    uStack_8._0_1_ = 1;
    FUN_005507b0();
  }
  if (*(int *)(param_1 + 0x40) == 0) {
    uVar7 = 1;
LAB_00b87979:
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",uVar7);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  FUN_0054ef60(*(int *)(param_1 + 0x40));
LAB_00b878b1:
  uStack_8._0_1_ = 9;
  FUN_00b86a10(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),aiStack_40,
               &param_3,&param_4,&stack0x0000002c);
  uStack_8._0_1_ = 1;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    iVar6 = aiStack_40[0];
    if (0xfff < uVar4) {
      iVar6 = *(int *)(aiStack_40[0] + -4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar6) - 4U) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar4);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 0xb;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25186 ; VA 0x00b879a0 ; FUN_00b879a0 */

void __thiscall
FUN_00b879a0(int param_1,undefined4 param_2,undefined4 param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10,uint param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  code *pcVar1;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined8 uStack_b8;
  undefined4 uStack_b0;
  undefined auStack_ac [28];
  undefined4 uStack_90;
  undefined4 *puStack_8c;
  undefined4 *puStack_88;
  undefined4 uStack_84;
  undefined4 uStack_70;
  undefined4 *puStack_6c;
  undefined4 *puStack_68;
  undefined4 uStack_64;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_24;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_18 = &LAB_017c862e;
  pvStack_1c = ExceptionList;
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_14 = 1;
  uStack_24 = CONCAT31(uStack_24._1_3_,DAT_01ef1e5d);
  uStack_60 = 0;
  ExceptionList = &pvStack_1c;
  if (param_11 != 0) {
    uStack_60 = param_11;
    if ((param_11 & 1) == 0) {
      puStack_68 = &uStack_58;
      uStack_64 = 0;
      puStack_6c = &param_13;
      uStack_70 = 0xb87a35;
      ExceptionList = &pvStack_1c;
      (**(code **)(param_11 & 0xfffffffe))();
    }
    else {
      uStack_58 = param_13;
      uStack_54 = param_14;
      uStack_50 = param_15;
      uStack_4c = param_16;
      uStack_48 = param_17;
      ExceptionList = &pvStack_1c;
    }
  }
  uStack_14._0_1_ = 2;
  uStack_84 = 0;
  uStack_b0 = uStack_24;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_c8,0);
    }
    else {
      uStack_c8 = param_6;
      uStack_c4 = param_7;
      uStack_c0 = param_8;
      uStack_bc = param_9;
      uStack_b8 = param_10;
    }
  }
  FUN_008bfbf0(auStack_ac,FUN_00b85690);
  uStack_b0 = 0xb87aa4;
  FUN_00912f20();
  uStack_14._0_1_ = 1;
  uStack_84 = 0xb87aae;
  (*pcVar1)();
  uStack_14 = CONCAT31(uStack_14._1_3_,3);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_8c = &param_6;
    uStack_84 = 2;
    uStack_90 = 0xb87acf;
    puStack_88 = puStack_8c;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_14 = 4;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_8c = &param_13;
    uStack_84 = 2;
    uStack_90 = 0xb87afd;
    puStack_88 = puStack_8c;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 25187 ; VA 0x00b87b20 ; FUN_00b87b20 */

void __thiscall
FUN_00b87b20(int param_1,undefined4 param_2,undefined4 param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10,uint param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  code *pcVar1;
  undefined8 uVar2;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined8 uStack_c0;
  undefined4 uStack_b8;
  undefined auStack_b4 [20];
  undefined4 uStack_a0;
  undefined4 *puStack_9c;
  undefined4 *puStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  undefined4 uStack_78;
  undefined4 *puStack_74;
  undefined4 *puStack_70;
  undefined4 uStack_6c;
  uint uStack_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined4 uStack_24;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_18 = &LAB_017c865e;
  pvStack_1c = ExceptionList;
  uStack_14 = 1;
  uStack_50 = CONCAT44(param_1 + 0x40,param_3);
  uStack_54 = 0xb87b66;
  ExceptionList = &pvStack_1c;
  uVar2 = FUN_009269c0();
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_24 = CONCAT31(uStack_24._1_3_,DAT_01ef1e5d);
  uStack_68 = 0;
  if (param_11 != 0) {
    uStack_68 = param_11;
    if ((param_11 & 1) == 0) {
      puStack_70 = &uStack_60;
      uStack_6c = 0;
      puStack_74 = &param_13;
      uStack_78 = 0xb87bc8;
      (**(code **)(param_11 & 0xfffffffe))();
    }
    else {
      uStack_60 = param_13;
      uStack_5c = param_14;
      uStack_58 = param_15;
      uStack_54 = param_16;
      uStack_50 = param_17;
    }
  }
  uStack_14._0_1_ = 2;
  uStack_90._4_4_ = 0;
  uStack_b8 = uStack_24;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_d0,0);
    }
    else {
      uStack_d0 = param_6;
      uStack_cc = param_7;
      uStack_c8 = param_8;
      uStack_c4 = param_9;
      uStack_c0 = param_10;
    }
  }
  FUN_008bfbf0(auStack_b4,FUN_00b85690);
  uStack_b8 = 0xb87c37;
  FUN_00912f20();
  uStack_14._0_1_ = 1;
  uStack_94 = 0xb87c47;
  uStack_90 = uVar2;
  (*pcVar1)();
  uStack_14 = CONCAT31(uStack_14._1_3_,3);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_9c = &param_6;
    uStack_94 = 2;
    uStack_a0 = 0xb87c68;
    puStack_98 = puStack_9c;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_14 = 4;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_9c = &param_13;
    uStack_94 = 2;
    uStack_a0 = 0xb87c96;
    puStack_98 = puStack_9c;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 25188 ; VA 0x00b87cb0 ; FUN_00b87cb0 */

void __thiscall FUN_00b87cb0(int param_1,undefined4 param_2,code *param_3,uint param_4)

{
  code *pcVar1;
  code *pcVar2;
  undefined uVar3;
  char cVar4;
  uint uVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uVar8;
  uint in_stack_0000002c;
  undefined4 uStack_118;
  int iStack_114;
  undefined auStack_110 [200];
  int aiStack_48 [5];
  uint uStack_34;
  undefined uStack_30;
  undefined auStack_24 [4];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pcVar2 = param_3;
  puStack_c = &LAB_017f92c9;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar5 = (*(code *)**(undefined4 **)param_3)();
  if (uVar5 < 3) {
LAB_00b87db4:
    if (*(undefined4 **)(param_1 + 0x48) == (undefined4 *)0x0) {
      uVar8 = 3;
      goto LAB_00b880e6;
    }
    uStack_18 = **(undefined4 **)(param_1 + 0x48);
  }
  else {
    param_3 = *(code **)(*(int *)pcVar2 + 0x38);
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eedfc4)
       && (FUN_016f3809(&DAT_01eedfc4), DAT_01eedfc4 == -1)) {
      uStack_8._0_1_ = 2;
      FUN_00b00c10();
      FUN_016f3654(&LAB_0188d200);
      uStack_8._0_1_ = 1;
      FUN_016f37bf(&DAT_01eedfc4);
    }
    cVar4 = (*param_3)(3,&DAT_01eedf60,&uStack_18);
    if (cVar4 == '\0') {
      uStack_118 = FUN_00888530();
      iStack_114 = 0;
      uStack_8._0_1_ = 3;
      cVar4 = (**(code **)(*(int *)pcVar2 + 4))(3,&uStack_118);
      if (cVar4 == '\0') {
        uStack_8._0_1_ = 5;
        if (iStack_114 != 0) {
          (**(code **)(iStack_114 + 8))(auStack_110);
        }
        uStack_8._0_1_ = 1;
        goto LAB_00b87db4;
      }
      puVar6 = (undefined4 *)FUN_00b00190();
      uStack_18 = *puVar6;
      uStack_8._0_1_ = 4;
      if (iStack_114 != 0) {
        (**(code **)(iStack_114 + 8))(auStack_110);
      }
      uStack_8._0_1_ = 1;
    }
  }
  uVar5 = (*(code *)**(undefined4 **)pcVar2)();
  if (uVar5 < 2) {
LAB_00b87e95:
    if (*(undefined4 **)(iStack_14 + 0x44) == (undefined4 *)0x0) {
      uVar8 = 2;
      goto LAB_00b880e6;
    }
    param_3 = (code *)**(undefined4 **)(iStack_14 + 0x44);
  }
  else {
    pcVar1 = *(code **)(*(int *)pcVar2 + 0x38);
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee02c)
       && (FUN_016f3809(&DAT_01eee02c), DAT_01eee02c == -1)) {
      uStack_8._0_1_ = 6;
      FUN_00b00b40();
      FUN_016f3654(&LAB_0188d180);
      uStack_8._0_1_ = 1;
      FUN_016f37bf(&DAT_01eee02c);
    }
    cVar4 = (*pcVar1)(2,&DAT_01eedfc8,&param_3);
    if (cVar4 == '\0') {
      uStack_118 = FUN_00888530();
      iStack_114 = 0;
      uStack_8._0_1_ = 7;
      cVar4 = (**(code **)(*(int *)pcVar2 + 4))(2,&uStack_118);
      if (cVar4 == '\0') {
        uStack_8._0_1_ = 9;
        if (iStack_114 != 0) {
          (**(code **)(iStack_114 + 8))(auStack_110);
        }
        uStack_8._0_1_ = 1;
        goto LAB_00b87e95;
      }
      puVar6 = (undefined4 *)FUN_00affff0();
      pcVar1 = (code *)*puVar6;
      uStack_8._0_1_ = 8;
      if (iStack_114 != 0) {
        (**(code **)(iStack_114 + 8))(auStack_110);
      }
      uStack_8._0_1_ = 1;
      param_3 = pcVar1;
    }
  }
  iVar7 = (*(code *)**(undefined4 **)pcVar2)();
  if (iVar7 != 0) {
    uStack_20 = 0;
    uStack_1c = 0xf;
    uStack_30 = 0;
    uStack_8._0_1_ = 10;
    uStack_118 = FUN_00888530();
    iStack_114 = 0;
    uStack_8._0_1_ = 0xb;
    cVar4 = (**(code **)(*(int *)pcVar2 + 4))(1,&uStack_118);
    if (cVar4 != '\0') {
      uVar8 = FUN_00e35d50();
      FUN_0054ef60(uVar8);
      uStack_8._0_1_ = 0xc;
      if (iStack_114 != 0) {
        (**(code **)(iStack_114 + 8))(auStack_110);
      }
      FUN_005507b0();
      goto LAB_00b87f79;
    }
    uStack_8._0_1_ = 0xd;
    if (iStack_114 != 0) {
      (**(code **)(iStack_114 + 8))(auStack_110);
    }
    uStack_8._0_1_ = 1;
    FUN_005507b0();
  }
  if (*(int *)(iStack_14 + 0x40) == 0) {
    uVar8 = 1;
LAB_00b880e6:
    FUN_016756b0(auStack_24,"Argument %d missing or nil",uVar8);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  }
  FUN_0054ef60(*(int *)(iStack_14 + 0x40));
LAB_00b87f79:
  uStack_8._0_1_ = 0xe;
  FUN_00b86b40(param_2,*(undefined4 *)(iStack_14 + 0x38),*(undefined4 *)(iStack_14 + 0x3c),
               aiStack_48,&param_3,&uStack_18,&param_4,&stack0x0000002c);
  uStack_8._0_1_ = 1;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_34) {
    uVar5 = uStack_34 + 1;
    iVar7 = aiStack_48[0];
    if (0xfff < uVar5) {
      iVar7 = *(int *)(aiStack_48[0] + -4);
      uVar5 = uStack_34 + 0x24;
      if (0x1f < (aiStack_48[0] - iVar7) - 4U) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar5);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 0x10;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25189 ; VA 0x00b88110 ; FUN_00b88110 */

void __thiscall
FUN_00b88110(int param_1,undefined4 param_2,undefined4 param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10,uint param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  code *pcVar1;
  undefined8 uVar2;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined8 uStack_c0;
  undefined4 uStack_b8;
  undefined auStack_b4 [20];
  undefined4 uStack_a0;
  undefined4 *puStack_9c;
  undefined4 *puStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  undefined4 uStack_78;
  undefined4 *puStack_74;
  undefined4 *puStack_70;
  undefined4 uStack_6c;
  uint uStack_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined4 uStack_24;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_18 = &LAB_017c865e;
  pvStack_1c = ExceptionList;
  uStack_14 = 1;
  uStack_50 = CONCAT44(param_1 + 0x40,param_3);
  uStack_54 = 0xb88156;
  ExceptionList = &pvStack_1c;
  uVar2 = FUN_009269c0();
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_24 = CONCAT31(uStack_24._1_3_,DAT_01ef1e5d);
  uStack_68 = 0;
  if (param_11 != 0) {
    uStack_68 = param_11;
    if ((param_11 & 1) == 0) {
      puStack_70 = &uStack_60;
      uStack_6c = 0;
      puStack_74 = &param_13;
      uStack_78 = 0xb881b8;
      (**(code **)(param_11 & 0xfffffffe))();
    }
    else {
      uStack_60 = param_13;
      uStack_5c = param_14;
      uStack_58 = param_15;
      uStack_54 = param_16;
      uStack_50 = param_17;
    }
  }
  uStack_14._0_1_ = 2;
  uStack_90._4_4_ = 0;
  uStack_b8 = uStack_24;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_d0,0);
    }
    else {
      uStack_d0 = param_6;
      uStack_cc = param_7;
      uStack_c8 = param_8;
      uStack_c4 = param_9;
      uStack_c0 = param_10;
    }
  }
  FUN_008bfbf0(auStack_b4,FUN_00966b00);
  uStack_b8 = 0xb88227;
  FUN_00960740();
  uStack_14._0_1_ = 1;
  uStack_94 = 0xb88237;
  uStack_90 = uVar2;
  (*pcVar1)();
  uStack_14 = CONCAT31(uStack_14._1_3_,3);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_9c = &param_6;
    uStack_94 = 2;
    uStack_a0 = 0xb88258;
    puStack_98 = puStack_9c;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_14 = 4;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_9c = &param_13;
    uStack_94 = 2;
    uStack_a0 = 0xb88286;
    puStack_98 = puStack_9c;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 25190 ; VA 0x00b882a0 ; FUN_00b882a0 */

void __thiscall FUN_00b882a0(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint in_stack_0000002c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uStack_18 = FUN_009269c0(param_3,param_1 + 0x40);
  FUN_00b86870(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_18,
               &param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25191 ; VA 0x00b88360 ; FUN_00b88360 */

undefined4 __thiscall FUN_00b88360(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined8 uVar2;
  
  iVar1 = FUN_01256300(param_3);
  uVar2 = FUN_009d1940(param_3,param_4,1,iVar1 - param_4,param_1 + 0x40);
  (**(code **)(param_1 + 0x38))(uVar2);
  return 0;
}



/* FUNCTION 25192 ; VA 0x00b883c0 ; FUN_00b883c0 */

void FUN_00b883c0(uint param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 *param_6,ulonglong param_7,uint param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined8 param_14)

{
  undefined uVar1;
  uint *puVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_78 [2];
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 *puStack_64;
  ulonglong uStack_60;
  uint auStack_58 [2];
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 *puStack_44;
  undefined8 uStack_40;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9300;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_40 = CONCAT44(auStack_30,0xb883ef);
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01006820();
  puStack_14 = (undefined *)auStack_58;
  puStack_18 = (undefined *)auStack_58;
  uStack_8._0_1_ = 2;
  auStack_58[0] = 0;
  puVar2 = auStack_58;
  if (param_8 != 0) {
    auStack_58[0] = param_8;
    if ((param_8 & 1) == 0) {
      uStack_60 = ZEXT48(&uStack_50);
      puStack_64 = &param_10;
      uStack_68 = 0xb88439;
      (**(code **)(param_8 & 0xfffffffe))();
      puVar2 = (uint *)puStack_14;
    }
    else {
      uStack_50 = param_10;
      uStack_4c = param_11;
      uStack_48 = param_12;
      puStack_44 = (undefined4 *)param_13;
      uStack_40 = param_14;
      puVar2 = auStack_58;
    }
  }
  puStack_14 = (undefined *)puVar2;
  puStack_18 = (undefined *)auStack_78;
  uStack_8._0_1_ = 3;
  auStack_78[0] = 0;
  puVar2 = auStack_78;
  if (param_1 != 0) {
    auStack_78[0] = param_1;
    if ((param_1 & 1) == 0) {
      (**(code **)(param_1 & 0xfffffffe))(&param_3,&uStack_70,0);
      puVar2 = (uint *)puStack_18;
    }
    else {
      uStack_70 = param_3;
      uStack_6c = param_4;
      uStack_68 = param_5;
      puStack_64 = param_6;
      uStack_60 = param_7;
      puVar2 = auStack_78;
    }
  }
  puStack_18 = (undefined *)puVar2;
  uStack_8._0_1_ = 2;
  FUN_00b874a0(uVar3);
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_1c) {
    uVar5 = uStack_1c + 1;
    uVar4 = auStack_30[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_30[0] - 4);
      uVar5 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar4) - 4) {
        uStack_40 = CONCAT44(&UNK_00b88543,(undefined4)uStack_40);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_40 = CONCAT44(uVar5,uVar4);
    puStack_44 = (undefined4 *)0xb884c5;
    FUN_01674ea0();
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    puStack_44 = &param_3;
    uStack_40 = CONCAT44(2,puStack_44);
    uStack_48 = 0xb884fb;
    (**(code **)(param_1 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_8 != 0) && ((param_8 & 1) == 0)) && (*(code **)(param_8 & 0xfffffffe) != (code *)0x0))
  {
    puStack_44 = &param_10;
    uStack_40 = CONCAT44(2,puStack_44);
    uStack_48 = 0xb88529;
    (**(code **)(param_8 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25193 ; VA 0x00b88550 ; FUN_00b88550 */

void FUN_00b88550(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 *param_8,
                 ulonglong param_9,uint param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined4 param_14,uint *param_15,undefined8 param_16)

{
  undefined uVar1;
  uint *puVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_74 [2];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 *puStack_60;
  ulonglong uStack_5c;
  uint auStack_54 [2];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  uint *puStack_40;
  undefined8 uStack_3c;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9330;
  pvStack_10 = ExceptionList;
  puStack_40 = auStack_2c;
  uStack_8 = 1;
  uStack_3c = CONCAT44(param_2,param_1);
  uStack_44 = 0xb88585;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01006a50();
  puStack_14 = (undefined *)auStack_54;
  uStack_8._0_1_ = 2;
  auStack_54[0] = 0;
  if (param_10 != 0) {
    auStack_54[0] = param_10;
    if ((param_10 & 1) == 0) {
      uStack_5c = ZEXT48(&uStack_4c);
      puStack_60 = &param_12;
      uStack_64 = 0xb885cf;
      (**(code **)(param_10 & 0xfffffffe))();
    }
    else {
      uStack_4c = param_12;
      uStack_48 = param_13;
      uStack_44 = param_14;
      puStack_40 = param_15;
      uStack_3c = param_16;
    }
  }
  puStack_14 = (undefined *)auStack_74;
  uStack_8._0_1_ = 3;
  auStack_74[0] = 0;
  puVar2 = auStack_74;
  if (param_3 != 0) {
    auStack_74[0] = param_3;
    if ((param_3 & 1) == 0) {
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_6c,0);
      puVar2 = (uint *)puStack_14;
    }
    else {
      uStack_6c = param_5;
      uStack_68 = param_6;
      uStack_64 = param_7;
      puStack_60 = param_8;
      uStack_5c = param_9;
      puVar2 = auStack_74;
    }
  }
  puStack_14 = (undefined *)puVar2;
  uStack_8._0_1_ = 2;
  FUN_00b874a0(uVar3);
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_18) {
    uVar5 = uStack_18 + 1;
    uVar4 = auStack_2c[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_2c[0] - 4);
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar4) - 4) {
        uStack_3c = CONCAT44(&UNK_00b886d9,(undefined4)uStack_3c);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_3c = CONCAT44(uVar5,uVar4);
    puStack_40 = (uint *)0xb8865b;
    FUN_01674ea0();
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    puStack_40 = &param_5;
    uStack_3c = CONCAT44(2,puStack_40);
    uStack_44 = 0xb88691;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    puStack_40 = &param_12;
    uStack_3c = CONCAT44(2,puStack_40);
    uStack_44 = 0xb886bf;
    (**(code **)(param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25194 ; VA 0x00b886e0 ; FUN_00b886e0 */

void FUN_00b886e0(uint param_1)

{
  undefined uVar1;
  uint *puVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint *in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 *in_stack_00000034;
  ulonglong in_stack_00000038;
  uint in_stack_00000040;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  longlong in_stack_00000058;
  uint auStack_74 [2];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 *puStack_60;
  undefined8 uStack_5c;
  uint auStack_54 [2];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 *puStack_40;
  undefined8 uStack_3c;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9368;
  pvStack_10 = ExceptionList;
  uStack_3c = (longlong)(int)in_stack_0000001c;
  uStack_8 = 2;
  uStack_5c = CONCAT44(&param_1,0xb8871a);
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_5c = CONCAT44(auStack_2c,0xb88723);
  uVar3 = FUN_01006d80();
  in_stack_0000001c = auStack_54;
  puStack_14 = (undefined *)auStack_54;
  uStack_8._0_1_ = 3;
  auStack_54[0] = 0;
  puVar2 = auStack_54;
  if (in_stack_00000040 != 0) {
    auStack_54[0] = in_stack_00000040;
    if ((in_stack_00000040 & 1) == 0) {
      uStack_5c = ZEXT48(&uStack_4c);
      puStack_60 = &stack0x00000048;
      uStack_64 = 0xb8876d;
      (**(code **)(in_stack_00000040 & 0xfffffffe))();
      puVar2 = in_stack_0000001c;
    }
    else {
      uStack_4c = in_stack_00000048;
      uStack_48 = in_stack_0000004c;
      uStack_44 = in_stack_00000050;
      puStack_40 = (undefined4 *)in_stack_00000054;
      uStack_3c = in_stack_00000058;
      puVar2 = auStack_54;
    }
  }
  in_stack_0000001c = puVar2;
  puStack_14 = (undefined *)auStack_74;
  uStack_8._0_1_ = 4;
  auStack_74[0] = 0;
  puVar2 = auStack_74;
  if (in_stack_00000020 != 0) {
    auStack_74[0] = in_stack_00000020;
    if ((in_stack_00000020 & 1) == 0) {
      (**(code **)(in_stack_00000020 & 0xfffffffe))(&stack0x00000028,&uStack_6c,0);
      puVar2 = (uint *)puStack_14;
    }
    else {
      uStack_6c = in_stack_00000028;
      uStack_68 = in_stack_0000002c;
      uStack_64 = in_stack_00000030;
      puStack_60 = in_stack_00000034;
      uStack_5c = in_stack_00000038;
      puVar2 = auStack_74;
    }
  }
  puStack_14 = (undefined *)puVar2;
  uStack_8._0_1_ = 3;
  FUN_00b874a0(uVar3);
  uStack_8._0_1_ = 2;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_18) {
    uVar5 = uStack_18 + 1;
    uVar4 = auStack_2c[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_2c[0] - 4);
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar4) - 4) {
        uStack_3c = CONCAT44(0xb888c1,(undefined4)uStack_3c);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_3c = CONCAT44(uVar5,uVar4);
    puStack_40 = (undefined4 *)0xb887f9;
    FUN_01674ea0();
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    uVar5 = in_stack_00000018 + 1;
    uVar4 = param_1;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(param_1 - 4);
      uVar5 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - uVar4) - 4) {
        uStack_3c = CONCAT44(&UNK_00b888c6,(undefined4)uStack_3c);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_3c = CONCAT44(uVar5,uVar4);
    puStack_40 = (undefined4 *)0xb88843;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (in_stack_00000020 != 0) {
    if (((in_stack_00000020 & 1) == 0) &&
       (*(code **)(in_stack_00000020 & 0xfffffffe) != (code *)0x0)) {
      puStack_40 = &stack0x00000028;
      uStack_3c = CONCAT44(2,puStack_40);
      uStack_44 = 0xb88879;
      (**(code **)(in_stack_00000020 & 0xfffffffe))();
    }
    in_stack_00000020 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_00000040 != 0) && ((in_stack_00000040 & 1) == 0)) &&
     (*(code **)(in_stack_00000040 & 0xfffffffe) != (code *)0x0)) {
    puStack_40 = &stack0x00000048;
    uStack_3c = CONCAT44(2,puStack_40);
    uStack_44 = 0xb888a7;
    (**(code **)(in_stack_00000040 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25195 ; VA 0x00b888d0 ; FUN_00b888d0 */

void FUN_00b888d0(uint param_1)

{
  undefined uVar1;
  uint *puVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint *in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 *in_stack_00000034;
  ulonglong in_stack_00000038;
  uint in_stack_00000040;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  longlong in_stack_00000058;
  uint auStack_74 [2];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 *puStack_60;
  undefined8 uStack_5c;
  uint auStack_54 [2];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 *puStack_40;
  undefined8 uStack_3c;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9368;
  pvStack_10 = ExceptionList;
  uStack_3c = (longlong)(int)in_stack_0000001c;
  uStack_8 = 2;
  uStack_5c = CONCAT44(&param_1,0xb8890a);
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_5c = CONCAT44(auStack_2c,0xb88913);
  uVar3 = FUN_010071a0();
  in_stack_0000001c = auStack_54;
  puStack_14 = (undefined *)auStack_54;
  uStack_8._0_1_ = 3;
  auStack_54[0] = 0;
  puVar2 = auStack_54;
  if (in_stack_00000040 != 0) {
    auStack_54[0] = in_stack_00000040;
    if ((in_stack_00000040 & 1) == 0) {
      uStack_5c = ZEXT48(&uStack_4c);
      puStack_60 = &stack0x00000048;
      uStack_64 = 0xb8895d;
      (**(code **)(in_stack_00000040 & 0xfffffffe))();
      puVar2 = in_stack_0000001c;
    }
    else {
      uStack_4c = in_stack_00000048;
      uStack_48 = in_stack_0000004c;
      uStack_44 = in_stack_00000050;
      puStack_40 = (undefined4 *)in_stack_00000054;
      uStack_3c = in_stack_00000058;
      puVar2 = auStack_54;
    }
  }
  in_stack_0000001c = puVar2;
  puStack_14 = (undefined *)auStack_74;
  uStack_8._0_1_ = 4;
  auStack_74[0] = 0;
  puVar2 = auStack_74;
  if (in_stack_00000020 != 0) {
    auStack_74[0] = in_stack_00000020;
    if ((in_stack_00000020 & 1) == 0) {
      (**(code **)(in_stack_00000020 & 0xfffffffe))(&stack0x00000028,&uStack_6c,0);
      puVar2 = (uint *)puStack_14;
    }
    else {
      uStack_6c = in_stack_00000028;
      uStack_68 = in_stack_0000002c;
      uStack_64 = in_stack_00000030;
      puStack_60 = in_stack_00000034;
      uStack_5c = in_stack_00000038;
      puVar2 = auStack_74;
    }
  }
  puStack_14 = (undefined *)puVar2;
  uStack_8._0_1_ = 3;
  FUN_00b874a0(uVar3);
  uStack_8._0_1_ = 2;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_18) {
    uVar5 = uStack_18 + 1;
    uVar4 = auStack_2c[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_2c[0] - 4);
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar4) - 4) {
        uStack_3c = CONCAT44(0xb88ab1,(undefined4)uStack_3c);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_3c = CONCAT44(uVar5,uVar4);
    puStack_40 = (undefined4 *)0xb889e9;
    FUN_01674ea0();
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    uVar5 = in_stack_00000018 + 1;
    uVar4 = param_1;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(param_1 - 4);
      uVar5 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - uVar4) - 4) {
        uStack_3c = CONCAT44(&UNK_00b88ab6,(undefined4)uStack_3c);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_3c = CONCAT44(uVar5,uVar4);
    puStack_40 = (undefined4 *)0xb88a33;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (in_stack_00000020 != 0) {
    if (((in_stack_00000020 & 1) == 0) &&
       (*(code **)(in_stack_00000020 & 0xfffffffe) != (code *)0x0)) {
      puStack_40 = &stack0x00000028;
      uStack_3c = CONCAT44(2,puStack_40);
      uStack_44 = 0xb88a69;
      (**(code **)(in_stack_00000020 & 0xfffffffe))();
    }
    in_stack_00000020 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_00000040 != 0) && ((in_stack_00000040 & 1) == 0)) &&
     (*(code **)(in_stack_00000040 & 0xfffffffe) != (code *)0x0)) {
    puStack_40 = &stack0x00000048;
    uStack_3c = CONCAT44(2,puStack_40);
    uStack_44 = 0xb88a97;
    (**(code **)(in_stack_00000040 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25196 ; VA 0x00b88ac0 ; FUN_00b88ac0 */

void __thiscall
FUN_00b88ac0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10,uint param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
            undefined8 param_17)

{
  undefined4 *puVar1;
  int iVar2;
  undefined *puVar3;
  undefined ***pppuVar4;
  undefined4 **ppuVar5;
  char cVar6;
  int iVar7;
  int *piVar8;
  undefined auStack_270 [4];
  undefined4 uStack_26c;
  undefined4 *puStack_268;
  undefined4 *puStack_264;
  undefined4 uStack_260;
  undefined4 *puStack_25c;
  undefined4 *puStack_258;
  undefined4 **ppuStack_254;
  undefined **ppuStack_250;
  undefined4 uStack_24c;
  undefined4 uStack_248;
  undefined4 uStack_244;
  undefined4 uStack_240;
  undefined8 uStack_23c;
  undefined4 uStack_234;
  undefined auStack_230 [16];
  undefined4 uStack_220;
  undefined4 *puStack_21c;
  undefined4 *puStack_218;
  undefined4 *puStack_214;
  undefined auStack_208 [72];
  undefined auStack_1c0 [72];
  undefined auStack_178 [72];
  undefined auStack_130 [72];
  undefined auStack_e8 [72];
  undefined4 *apuStack_a0 [2];
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  uint uStack_78;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined8 uStack_60;
  undefined auStack_58 [4];
  int *piStack_54;
  undefined *puStack_50;
  undefined4 *puStack_4c;
  uint uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined4 **ppuStack_24;
  undefined *puStack_20;
  undefined4 *puStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9404;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  puStack_1c = param_1;
  if (param_1 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)param_1[0xd];
    ExceptionList = &pvStack_10;
    if ((puVar1 != (undefined4 *)0x0) &&
       (param_1 = puVar1, ExceptionList = &pvStack_10, puVar1[0xd] != 0)) {
      puStack_214 = (undefined4 *)0xb88b07;
      ExceptionList = &pvStack_10;
      param_1 = (undefined4 *)FUN_005c8ac0();
    }
    if (param_1 != (undefined4 *)0x0) {
      iVar2 = param_1[3];
      puStack_214 = (undefined4 *)0xb88b19;
      iVar7 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
          (uint)*(ushort *)(iVar7 + 0x1da)) {
        puStack_214 = (undefined4 *)&LAB_0064e290;
        puStack_218 = (undefined4 *)&DAT_01eadc4c;
        puStack_21c = (undefined4 *)0xb88b47;
        FUN_005789c0();
        puStack_214 = (undefined4 *)0xb88b4f;
        puStack_214 = (undefined4 *)FUN_0064e320();
        puStack_218 = (undefined4 *)0xb88b57;
        piStack_18 = (int *)FUN_008aa140();
        if (*piStack_18 == 0) {
          puStack_214 = (undefined4 *)0xb88b64;
          puStack_214 = (undefined4 *)FUN_00bc47d0();
          puStack_218 = (undefined4 *)auStack_58;
          puStack_21c = (undefined4 *)0xb88b70;
          piVar8 = (int *)FUN_008a9ba0();
          iVar2 = *piVar8;
          iVar7 = piVar8[1];
          *piVar8 = 0;
          piVar8[1] = 0;
          *piStack_18 = iVar2;
          piVar8 = (int *)piStack_18[1];
          piStack_18[1] = iVar7;
          if (piVar8 != (int *)0x0) {
            LOCK();
            iVar2 = piVar8[1] + -1;
            piVar8[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              puStack_214 = (undefined4 *)0xb88ba3;
              (**(code **)*piVar8)();
              LOCK();
              iVar2 = piVar8[2] + -1;
              piVar8[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                puStack_214 = (undefined4 *)0xb88bb3;
                (**(code **)(*piVar8 + 4))();
              }
            }
          }
          if (piStack_54 != (int *)0x0) {
            LOCK();
            iVar2 = piStack_54[1] + -1;
            piStack_54[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              puStack_214 = (undefined4 *)0xb88bc9;
              (**(code **)*piStack_54)();
              LOCK();
              piVar8 = piStack_54 + 2;
              iVar2 = *piVar8;
              *piVar8 = *piVar8 + -1;
              UNLOCK();
              if (iVar2 == 1) {
                puStack_214 = (undefined4 *)0xb88bd8;
                (**(code **)(*piStack_54 + 4))();
              }
            }
          }
        }
        puVar1 = puStack_1c;
        piStack_18 = (int *)*piStack_18;
        if (piStack_18 != (int *)0x0) {
          puStack_214 = puStack_1c;
          puStack_218 = (undefined4 *)0xb88bf1;
          puStack_1c = (undefined4 *)FUN_008f7870();
          if (puStack_1c != (undefined4 *)0x0) {
            puStack_50 = auStack_230;
            puStack_4c = puVar1;
            uStack_44 = 0;
            puVar3 = auStack_230;
            if (param_11 != 0) {
              uStack_44 = param_11;
              if ((param_11 & 1) == 0) {
                uStack_234 = 0;
                uStack_23c = CONCAT44(&uStack_3c,&param_13);
                uStack_240 = 0xb88c46;
                (**(code **)(param_11 & 0xfffffffe))();
                puVar3 = puStack_50;
              }
              else {
                uStack_3c = param_13;
                uStack_38 = param_14;
                uStack_34 = param_15;
                uStack_30 = param_16;
                uStack_2c = param_17;
                puVar3 = auStack_230;
              }
            }
            puStack_50 = puVar3;
            uStack_234 = 0;
            puStack_20 = (undefined *)&puStack_25c;
            uStack_8._0_1_ = 2;
            ppuStack_254 = (undefined4 **)0x0;
            puStack_25c = puStack_4c;
            ppuVar5 = &puStack_25c;
            if (uStack_44 != 0) {
              ppuStack_254 = (undefined4 **)uStack_44;
              if ((uStack_44 & 1) == 0) {
                puStack_264 = &uStack_24c;
                uStack_260 = 0;
                puStack_268 = &uStack_3c;
                uStack_26c = 0xb88c97;
                (**(code **)(uStack_44 & 0xfffffffe))();
                ppuVar5 = (undefined4 **)puStack_20;
              }
              else {
                uStack_24c = uStack_3c;
                uStack_248 = uStack_38;
                uStack_244 = uStack_34;
                uStack_240 = uStack_30;
                uStack_23c = uStack_2c;
                ppuVar5 = &puStack_25c;
              }
            }
            puStack_20 = (undefined *)ppuVar5;
            uStack_260 = 0xb88ca1;
            FUN_00b85090();
            uStack_8._0_1_ = 3;
            if (uStack_44 != 0) {
              if (((uStack_44 & 1) == 0) && (*(code **)(uStack_44 & 0xfffffffe) != (code *)0x0)) {
                uStack_234 = 2;
                uStack_23c = CONCAT44(&uStack_3c,&uStack_3c);
                uStack_240 = 0xb88cc6;
                (**(code **)(uStack_44 & 0xfffffffe))();
              }
              uStack_44 = 0;
            }
            ppuStack_24 = apuStack_a0;
            uStack_8._0_1_ = 4;
            puStack_20 = (undefined *)&ppuStack_250;
            apuStack_a0[0] = puVar1;
            uStack_98 = 0;
            pppuVar4 = &ppuStack_250;
            if (param_4 != 0) {
              uStack_98 = param_4;
              if ((param_4 & 1) == 0) {
                puStack_258 = &uStack_90;
                ppuStack_254 = (undefined4 **)0x0;
                puStack_25c = &param_6;
                uStack_260 = 0xb88d31;
                (**(code **)(param_4 & 0xfffffffe))();
                pppuVar4 = (undefined ***)puStack_20;
              }
              else {
                uStack_90 = param_6;
                uStack_8c = param_7;
                uStack_88 = param_8;
                uStack_84 = param_9;
                uStack_80 = param_10;
                pppuVar4 = &ppuStack_250;
              }
            }
            puStack_20 = (undefined *)pppuVar4;
            uStack_8._0_1_ = 5;
            uStack_78 = 0;
            if (param_11 != 0) {
              uStack_78 = param_11;
              if ((param_11 & 1) == 0) {
                puStack_258 = &uStack_70;
                ppuStack_254 = (undefined4 **)0x0;
                puStack_25c = &param_13;
                uStack_260 = 0xb88d72;
                (**(code **)(param_11 & 0xfffffffe))();
              }
              else {
                uStack_70 = param_13;
                uStack_6c = param_14;
                uStack_68 = param_15;
                uStack_64 = param_16;
                uStack_60 = param_17;
              }
            }
            ppuStack_254 = apuStack_a0;
            uStack_8._0_1_ = 6;
            puStack_258 = (undefined4 *)0xb88d8b;
            FUN_00b85920();
            ppuStack_254 = (undefined4 **)auStack_208;
            uStack_8._0_1_ = 7;
            ppuStack_250 = (undefined **)0x0;
            puStack_258 = (undefined4 *)0xb88da7;
            FUN_00b85920();
            ppuStack_254 = (undefined4 **)auStack_1c0;
            uStack_8._0_1_ = 8;
            puStack_258 = (undefined4 *)0xb88dbd;
            FUN_00b85920();
            ppuStack_254 = (undefined4 **)auStack_178;
            uStack_8._0_1_ = 9;
            puStack_258 = (undefined4 *)0xb88dd3;
            FUN_00b85920();
            ppuStack_254 = (undefined4 **)auStack_e8;
            uStack_8._0_1_ = 10;
            puStack_258 = (undefined4 *)0xb88de3;
            cVar6 = FUN_00585a40();
            if (cVar6 == '\0') {
              ppuStack_254 = (undefined4 **)auStack_e8;
              puStack_258 = (undefined4 *)0xb88dfc;
              FUN_00b85920();
              ppuStack_254 = (undefined4 **)0x48;
              uStack_8._0_1_ = 0xb;
              puStack_258 = (undefined4 *)0xb88e07;
              ppuStack_24 = (undefined4 **)FUN_01674e20();
              uStack_8._0_1_ = 0xc;
              if (ppuStack_24 == (undefined4 **)0x0) {
                uStack_248 = 0;
              }
              else {
                ppuStack_254 = (undefined4 **)auStack_130;
                puStack_258 = (undefined4 *)0xb88e23;
                uStack_248 = FUN_00b85920();
              }
              ppuStack_254 = (undefined4 **)0xb88e35;
              FUN_0096ca80();
              ppuStack_254 = (undefined4 **)0xb88e40;
              FUN_0096ca80();
              cStack_11 = '\x01';
            }
            else {
              ppuStack_254 = (undefined4 **)0xb88e51;
              FUN_0096ca80();
              cStack_11 = '\0';
            }
            ppuStack_254 = (undefined4 **)0xb88e60;
            FUN_0096ca80();
            ppuStack_250 = &PTR_FUN_01959310;
            if (cStack_11 == '\0') {
              ppuStack_250 = (undefined **)0x0;
            }
            ppuStack_254 = (undefined4 **)0xb88e7a;
            FUN_0096ca80();
            ppuStack_254 = (undefined4 **)0xb88e85;
            FUN_0096ca80();
            ppuStack_254 = (undefined4 **)0xb88e90;
            FUN_0096ca80();
            ppuStack_254 = (undefined4 **)0x6;
            puStack_258 = (undefined4 *)0x0;
            uStack_8._0_1_ = 0xd;
            piVar8 = (int *)puStack_1c[0x10f];
            FUN_00f87290(auStack_270,param_2,param_3,*piVar8 - (int)piVar8,piVar8[1] - (int)piVar8);
            uStack_8 = CONCAT31(uStack_8._1_3_,1);
            FUN_00bcb3b0();
          }
        }
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_21c = &param_6;
    puStack_214 = (undefined4 *)0x2;
    uStack_220 = 0xb88eed;
    puStack_218 = puStack_21c;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 0xf;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_21c = &param_13;
    puStack_214 = (undefined4 *)0x2;
    uStack_220 = 0xb88f1b;
    puStack_218 = puStack_21c;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25197 ; VA 0x00b88f30 ; FUN_00b88f30 */

void FUN_00b88f30(undefined4 *param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  longlong lVar5;
  int in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_0000003c;
  undefined uVar6;
  undefined auStack_38 [16];
  undefined auStack_28 [8];
  undefined auStack_20 [4];
  undefined auStack_1c [4];
  undefined auStack_18 [4];
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9438;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (in_stack_00000014 == 0) {
    ExceptionList = &pvStack_10;
    if (DAT_01ef1e4c != '\0') {
      ExceptionList = &pvStack_10;
      FUN_016774b0(DAT_01ef1e4c,"Empty result string",0);
    }
    uVar6 = 0;
    FUN_005542c0("Invalid response received",0x19);
    FUN_005e65e0(uVar6);
    goto LAB_00b891ea;
  }
  ExceptionList = &pvStack_10;
  FUN_016819e0(auStack_38,&param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  cVar1 = FUN_016816d0();
  if (cVar1 == '\0') {
    cVar1 = FUN_01681870();
    if (cVar1 == '\0') goto LAB_00b89009;
    FUN_0167eea0(auStack_20,&DAT_018be4a0);
    cVar1 = FUN_01682670();
    if (cVar1 == '\0') goto LAB_00b89009;
    FUN_0167eea0(auStack_20,&DAT_018be4a0);
    cVar1 = FUN_01681830();
    if (cVar1 == '\0') goto LAB_00b89009;
  }
  else {
LAB_00b89009:
    if (DAT_01d84e8e != '\0') {
      puVar3 = &param_1;
      if (0xf < in_stack_00000018) {
        puVar3 = param_1;
      }
      FUN_01677520(DAT_01d84e8e,
                   "InsertService::getLatestAssetVersionSuccess Parse Error 1. Json = %s",puVar3);
    }
    uVar6 = 0;
    FUN_005542c0("getLatestAssetVersion error occurred",0x24);
    FUN_005e65e0(uVar6);
  }
  FUN_0167eea0(auStack_20,&DAT_018be4a0);
  FUN_016810c0(auStack_18);
  FUN_01680ea0(auStack_14);
  FUN_0167eea0(auStack_28,&DAT_018be4a0);
  FUN_016810c0(auStack_18);
  uVar2 = FUN_01681140(auStack_1c);
  cVar1 = FUN_00a33d60(uVar2);
  if (cVar1 == '\0') {
    FUN_0167efb0(auStack_28);
    cVar1 = FUN_01681870();
    if (cVar1 == '\0') goto LAB_00b890f3;
    FUN_0167efb0(auStack_28);
    FUN_0167eea0(auStack_20,&DAT_01940c14);
    cVar1 = FUN_01681850();
    if (cVar1 == '\0') goto LAB_00b890f3;
  }
  else {
LAB_00b890f3:
    if (DAT_01d84e8e != '\0') {
      puVar3 = &param_1;
      if (0xf < in_stack_00000018) {
        puVar3 = param_1;
      }
      FUN_01677520(DAT_01d84e8e,
                   "InsertService::getLatestAssetVersionSuccess Parse Error 2. Json = %s",puVar3);
    }
    uVar6 = 0;
    FUN_005542c0("getLatestAssetVersion error occurred",0x24);
    FUN_005e65e0(uVar6);
  }
  FUN_0167efb0(auStack_28);
  FUN_0167eea0(auStack_20,&DAT_01940c14);
  lVar5 = FUN_0167e380(0,0);
  if (lVar5 == 0) {
    if (DAT_01d84e8e != '\0') {
      puVar3 = &param_1;
      if (0xf < in_stack_00000018) {
        puVar3 = param_1;
      }
      FUN_01677520(DAT_01d84e8e,
                   "InsertService::getLatestAssetVersionSuccess Parse Error 3. Json = %s",puVar3);
    }
    uVar6 = 0;
    FUN_005542c0("getLatestAssetVersion error occurred",0x24);
    FUN_005e65e0(uVar6);
  }
  if (in_stack_0000001c == 0) {
    uVar2 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar2);
  }
  (**(code **)((in_stack_0000001c & 0xfffffffe) + 4))(&stack0x00000024,lVar5);
  FUN_0167ec40();
LAB_00b891ea:
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    uVar4 = in_stack_00000018 + 1;
    puVar3 = param_1;
    if (0xfff < uVar4) {
      puVar3 = (undefined4 *)param_1[-1];
      uVar4 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar3,uVar4);
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = (undefined4 *)((uint)param_1 & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (in_stack_0000001c != 0) {
    if (((in_stack_0000001c & 1) == 0) &&
       (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000001c & 0xfffffffe))(&stack0x00000024,&stack0x00000024,2);
    }
    in_stack_0000001c = 0;
  }
  uStack_8 = 6;
  if (((in_stack_0000003c != 0) && ((in_stack_0000003c & 1) == 0)) &&
     (*(code **)(in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000003c & 0xfffffffe))(&stack0x00000044,&stack0x00000044,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25198 ; VA 0x00b892b0 ; FUN_00b892b0 */

void FUN_00b892b0(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 *param_8,
                 ulonglong param_9,uint param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined4 param_14,uint *param_15,undefined8 param_16)

{
  undefined uVar1;
  uint *puVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_74 [2];
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 *puStack_60;
  ulonglong uStack_5c;
  uint auStack_54 [2];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  uint *puStack_40;
  undefined8 uStack_3c;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9330;
  pvStack_10 = ExceptionList;
  puStack_40 = auStack_2c;
  uStack_8 = 1;
  uStack_3c = CONCAT44(param_2,param_1);
  uStack_44 = 0xb892e5;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_010075c0();
  puStack_14 = (undefined *)auStack_54;
  uStack_8._0_1_ = 2;
  auStack_54[0] = 0;
  if (param_10 != 0) {
    auStack_54[0] = param_10;
    if ((param_10 & 1) == 0) {
      uStack_5c = ZEXT48(&uStack_4c);
      puStack_60 = &param_12;
      uStack_64 = 0xb8932f;
      (**(code **)(param_10 & 0xfffffffe))();
    }
    else {
      uStack_4c = param_12;
      uStack_48 = param_13;
      uStack_44 = param_14;
      puStack_40 = param_15;
      uStack_3c = param_16;
    }
  }
  puStack_14 = (undefined *)auStack_74;
  uStack_8._0_1_ = 3;
  auStack_74[0] = 0;
  puVar2 = auStack_74;
  if (param_3 != 0) {
    auStack_74[0] = param_3;
    if ((param_3 & 1) == 0) {
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_6c,0);
      puVar2 = (uint *)puStack_14;
    }
    else {
      uStack_6c = param_5;
      uStack_68 = param_6;
      uStack_64 = param_7;
      puStack_60 = param_8;
      uStack_5c = param_9;
      puVar2 = auStack_74;
    }
  }
  puStack_14 = (undefined *)puVar2;
  uStack_8._0_1_ = 2;
  FUN_00b874a0(uVar3);
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_18) {
    uVar5 = uStack_18 + 1;
    uVar4 = auStack_2c[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_2c[0] - 4);
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar4) - 4) {
        uStack_3c = CONCAT44(&UNK_00b89439,(undefined4)uStack_3c);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_3c = CONCAT44(uVar5,uVar4);
    puStack_40 = (uint *)0xb893bb;
    FUN_01674ea0();
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    puStack_40 = &param_5;
    uStack_3c = CONCAT44(2,puStack_40);
    uStack_44 = 0xb893f1;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    puStack_40 = &param_12;
    uStack_3c = CONCAT44(2,puStack_40);
    uStack_44 = 0xb8941f;
    (**(code **)(param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25199 ; VA 0x00b89440 ; FUN_00b89440 */

void * __thiscall FUN_00b89440(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvVar5;
  undefined4 uVar6;
  uint uVar7;
  int iVar8;
  undefined auStack_34 [12];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9468;
  pvStack_10 = ExceptionList;
  iVar8 = *(int *)(param_1 + 0x34);
  uStack_8 = 0;
  pvVar5 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (iVar8 != 0) {
    iVar2 = *(int *)(iVar8 + 0xc);
    ExceptionList = &pvStack_10;
    iVar4 = FUN_008dcf60();
    pvVar5 = (void *)(uint)*(ushort *)(iVar4 + 0x1da);
    if (((void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) <= pvVar5) &&
       (iVar8 != 0xc)) {
      if (param_2 == 0) {
        FUN_00550130("instance must be non-nil");
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_34,&DAT_01c17198);
      }
      uVar6 = FUN_01255560();
      if ((*(int *)(*(int *)(param_2 + 0xc) + 0x1d0) != 0) || (*(char *)(param_2 + 0x24) != '\0')) {
        FUN_008a5680(uVar6);
      }
      uStack_28 = 0;
      uStack_24 = 0;
      uStack_20 = 0;
      uStack_8._0_1_ = 1;
      FUN_005c1970(0,&param_2);
      iStack_1c = 0;
      iStack_18 = 0;
      iStack_14 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_00a9d670(&uStack_28,0,*(undefined4 *)(iVar8 + 0x1ac),&iStack_1c,0,0);
      iVar2 = iStack_18;
      iVar8 = iStack_1c;
      if (iStack_1c != 0) {
        for (; iVar8 != iVar2; iVar8 = iVar8 + 8) {
          piVar3 = *(int **)(iVar8 + 4);
          if (piVar3 != (int *)0x0) {
            LOCK();
            iVar4 = piVar3[2] + -1;
            piVar3[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        uVar7 = iStack_14 - iStack_1c & 0xfffffff8;
        iVar8 = iStack_1c;
        if (0xfff < uVar7) {
          iVar8 = *(int *)(iStack_1c + -4);
          uVar7 = uVar7 + 0x23;
          if (0x1f < (iStack_1c - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar8,uVar7);
        iStack_1c = 0;
        iStack_18 = 0;
        iStack_14 = 0;
      }
      pvVar5 = (void *)thunk_FUN_00577ac0();
    }
  }
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar8 = *piVar1;
    pvVar5 = (void *)*piVar1;
    *piVar1 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      pvVar5 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar8 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        pvVar5 = (void *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 25200 ; VA 0x00b89600 ; FUN_00b89600 */

void FUN_00b89600(void)

{
  FUN_00b865b0();
  return;
}



/* FUNCTION 25201 ; VA 0x00b89610 ; FUN_00b89610 */

void FUN_00b89610(int *param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint in_stack_0000001c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  int iStack_4c;
  ulonglong uStack_48;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017f9498;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  iVar1 = *param_1;
  uStack_40 = 0;
  uVar2 = *(uint *)(iVar1 + 0x28);
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_40 = uVar2;
    if ((uVar2 & 1) == 0) {
      uStack_48 = ZEXT48(&uStack_38);
      iStack_4c = iVar1 + 0x30;
      uStack_50 = 0xb8967f;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_38 = *(undefined4 *)(iVar1 + 0x30);
      uStack_34 = *(undefined4 *)(iVar1 + 0x34);
      uStack_30 = *(undefined4 *)(iVar1 + 0x38);
      uStack_2c = *(undefined4 *)(iVar1 + 0x3c);
      uStack_28 = *(undefined8 *)(iVar1 + 0x40);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8._0_1_ = 1;
  uVar2 = *(uint *)(iVar1 + 8);
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(iVar1 + 0x10,&uStack_58,0);
    }
    else {
      uStack_58 = *(undefined4 *)(iVar1 + 0x10);
      uStack_54 = *(undefined4 *)(iVar1 + 0x14);
      uStack_50 = *(undefined4 *)(iVar1 + 0x18);
      iStack_4c = *(int *)(iVar1 + 0x1c);
      uStack_48 = *(ulonglong *)(iVar1 + 0x20);
    }
  }
  iStack_8._0_1_ = 2;
  FUN_0054ef60(&param_2);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00b88f30();
  if (0xf < in_stack_0000001c) {
    uVar2 = in_stack_0000001c + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
        uStack_28 = CONCAT44(&UNK_00b8972f,(undefined4)uStack_28);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_28 = CONCAT44(uVar2,iVar1);
    uStack_2c = 0xb89717;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25202 ; VA 0x00b89730 ; FUN_00b89730 */

void FUN_00b89730(int *param_1,int param_2)

{
  uint uVar1;
  undefined uVar2;
  undefined4 ****ppppuVar3;
  int iVar4;
  uint in_stack_0000001c;
  undefined auStack_60 [8];
  undefined4 uStack_58;
  undefined4 ***pppuStack_54;
  undefined4 ***pppuStack_50;
  undefined4 *puStack_4c;
  uint uStack_48;
  undefined4 **ppuStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f4d70;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_48 = 0;
  iVar4 = *param_1;
  uVar1 = *(uint *)(iVar4 + 8);
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    uStack_48 = uVar1;
    if ((uVar1 & 1) == 0) {
      pppuStack_50 = &ppuStack_40;
      puStack_4c = (undefined4 *)0x0;
      pppuStack_54 = (undefined4 ***)(iVar4 + 0x10);
      uStack_58 = 0xb89792;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))();
    }
    else {
      ppuStack_40 = *(undefined4 ***)(iVar4 + 0x10);
      uStack_3c = *(undefined4 *)(iVar4 + 0x14);
      uStack_38 = *(undefined4 *)(iVar4 + 0x18);
      uStack_34 = *(undefined4 *)(iVar4 + 0x1c);
      uStack_30 = *(undefined8 *)(iVar4 + 0x20);
      ExceptionList = &pvStack_10;
    }
  }
  puStack_4c = &param_2;
  uStack_8._0_1_ = 1;
  pppuStack_50 = (undefined4 ****)0xb897a5;
  FUN_0054ef60();
  uStack_8._0_1_ = 3;
  ppppuVar3 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar3 = (undefined4 ****)apppuStack_28[0];
  }
  FUN_01675640(auStack_60,"InsertService getLatestAssetVersion : Request Failed because %s",
               ppppuVar3);
  FUN_005e65e0();
  uStack_8._0_1_ = 2;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_14) {
    puStack_4c = (undefined4 *)(uStack_14 + 1);
    ppppuVar3 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < puStack_4c) {
      ppppuVar3 = (undefined4 ****)apppuStack_28[0][-1];
      puStack_4c = (undefined4 *)(uStack_14 + 0x24);
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        puStack_4c = (undefined4 *)0xb8987d;
        uStack_8._0_1_ = uVar2;
        FUN_017167a3();
      }
    }
    pppuStack_54 = (undefined4 ****)0xb89801;
    pppuStack_50 = ppppuVar3;
    FUN_01674ea0();
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((uStack_48 != 0) && ((uStack_48 & 1) == 0)) &&
     (*(code **)(uStack_48 & 0xfffffffe) != (code *)0x0)) {
    pppuStack_54 = &ppuStack_40;
    puStack_4c = (undefined4 *)0x2;
    uStack_58 = 0xb89837;
    pppuStack_50 = pppuStack_54;
    (**(code **)(uStack_48 & 0xfffffffe))();
  }
  if (0xf < in_stack_0000001c) {
    puStack_4c = (undefined4 *)(in_stack_0000001c + 1);
    iVar4 = param_2;
    if (0xfff < puStack_4c) {
      iVar4 = *(int *)(param_2 + -4);
      puStack_4c = (undefined4 *)(in_stack_0000001c + 0x24);
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_4c = (undefined4 *)&UNK_00b89882;
        FUN_017167a3();
      }
    }
    pppuStack_54 = (undefined4 ***)0xb89867;
    pppuStack_50 = (undefined4 ***)iVar4;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25203 ; VA 0x00b89890 ; FUN_00b89890 */

/* WARNING: Removing unreachable block (ram,0x00b89920) */
/* WARNING: Removing unreachable block (ram,0x00b89929) */
/* WARNING: Removing unreachable block (ram,0x00b89938) */
/* WARNING: Removing unreachable block (ram,0x00b89946) */
/* WARNING: Removing unreachable block (ram,0x00b8994f) */
/* WARNING: Removing unreachable block (ram,0x00b8995d) */

undefined4
FUN_00b89890(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bfa90;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b86180(param_2,param_3,param_4,param_5,param_6);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 25204 ; VA 0x00b89980 ; FUN_00b89980 */

bool FUN_00b89980(undefined *param_1)

{
  return param_1 == &DAT_0212f508;
}



/* FUNCTION 25205 ; VA 0x00b899a0 ; FUN_00b899a0 */

uint FUN_00b899a0(void)

{
  int iVar1;
  
  iVar1 = FUN_00b85410();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 25206 ; VA 0x00b899c0 ; FUN_00b899c0 */

uint FUN_00b899c0(void)

{
  int iVar1;
  
  iVar1 = FUN_00b85410();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 25207 ; VA 0x00b899e0 ; FUN_00b899e0 */

void __thiscall FUN_00b899e0(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  uint in_stack_0000002c;
  uint in_stack_ffffffa0;
  undefined4 in_stack_ffffffa4;
  undefined4 in_stack_ffffffa8;
  undefined4 in_stack_ffffffac;
  undefined4 uVar5;
  undefined auStack_40 [24];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f94d8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008f7870(param_1);
  if (iVar2 == 0) {
LAB_00b89a90:
    uVar3 = 0;
    uVar5 = 0xf;
    in_stack_ffffffa0 = in_stack_ffffffa0 & 0xffffff00;
    FUN_005542c0("InsertService cannot be used to load assets from the client",0x3b);
    FUN_005e65e0(in_stack_ffffffa0,in_stack_ffffffa4,in_stack_ffffffa8,in_stack_ffffffac,uVar3,uVar5
                );
  }
  else {
    if (*(int *)(iVar2 + 0x4a0) == 1) {
      cVar1 = FUN_00983210(iVar2 + 0xc);
      if (cVar1 == '\0') goto LAB_00b89a90;
    }
    uVar4 = FUN_005ea010();
    uVar3 = FUN_00f87ea0(auStack_40,param_2,param_3,uVar4);
    uStack_8._0_1_ = 2;
    FUN_0054ef60(uVar3);
    uStack_8._0_1_ = 3;
    FUN_009cbbb0(auStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_00b89c60(iVar2,auStack_28,&param_4,&stack0x0000002c);
    FUN_005507b0();
    FUN_005507b0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25208 ; VA 0x00b89b20 ; FUN_00b89b20 */

void __thiscall FUN_00b89b20(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  uint in_stack_0000002c;
  uint in_stack_ffffffa0;
  undefined4 in_stack_ffffffa4;
  undefined4 in_stack_ffffffa8;
  undefined4 in_stack_ffffffac;
  undefined4 uVar5;
  undefined auStack_40 [24];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f94d8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008f7870(param_1);
  if (iVar2 == 0) {
LAB_00b89bd0:
    uVar3 = 0;
    uVar5 = 0xf;
    in_stack_ffffffa0 = in_stack_ffffffa0 & 0xffffff00;
    FUN_005542c0("InsertService cannot be used to load assets from the client",0x3b);
    FUN_005e65e0(in_stack_ffffffa0,in_stack_ffffffa4,in_stack_ffffffa8,in_stack_ffffffac,uVar3,uVar5
                );
  }
  else {
    if (*(int *)(iVar2 + 0x4a0) == 1) {
      cVar1 = FUN_00983210(iVar2 + 0xc);
      if (cVar1 == '\0') goto LAB_00b89bd0;
    }
    uVar4 = FUN_005ea010();
    uVar3 = FUN_00f880e0(auStack_40,param_2,param_3,uVar4);
    uStack_8._0_1_ = 2;
    FUN_0054ef60(uVar3);
    uStack_8._0_1_ = 3;
    FUN_009cbbb0(auStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_00b89c60(iVar2,auStack_28,&param_4,&stack0x0000002c);
    FUN_005507b0();
    FUN_005507b0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25209 ; VA 0x00b89c60 ; FUN_00b89c60 */

int FUN_00b89c60(undefined4 param_1,undefined4 param_2,uint *param_3,uint *param_4)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  bool bVar4;
  char cVar5;
  int iVar6;
  undefined **ppuVar7;
  undefined4 uVar8;
  undefined auStack_1cc [72];
  undefined auStack_184 [72];
  undefined auStack_13c [72];
  undefined auStack_f4 [72];
  undefined auStack_ac [72];
  undefined4 uStack_64;
  int *piStack_60;
  uint uStack_5c;
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  undefined8 uStack_44;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f9559;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_14 = FUN_005c2760();
  FUN_0060e0c0(&uStack_1c,uStack_14);
  iStack_8 = 0;
  FUN_008ccd70();
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piStack_18[2] = piStack_18[2] + 1;
    UNLOCK();
  }
  uStack_64 = uStack_1c;
  piStack_60 = piStack_18;
  iStack_8._0_1_ = 1;
  uStack_5c = 0;
  uVar3 = *param_3;
  if (uVar3 != 0) {
    uStack_5c = uVar3;
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(param_3 + 2,&uStack_54,0);
    }
    else {
      uStack_54 = param_3[2];
      uStack_50 = param_3[3];
      uStack_4c = param_3[4];
      uStack_48 = param_3[5];
      uStack_44 = *(undefined8 *)(param_3 + 6);
    }
  }
  iStack_8._0_1_ = 2;
  uStack_3c = 0;
  uVar3 = *param_4;
  if (uVar3 != 0) {
    uStack_3c = uVar3;
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(param_4 + 2,&uStack_34,0);
    }
    else {
      uStack_34 = param_4[2];
      uStack_30 = param_4[3];
      uStack_2c = param_4[4];
      uStack_28 = param_4[5];
      uStack_24 = *(undefined8 *)(param_4 + 6);
    }
  }
  iStack_8._0_1_ = 3;
  FUN_00b859f0(&uStack_64);
  iStack_8._0_1_ = 4;
  uVar8 = 0;
  FUN_00b859f0(auStack_1cc);
  iStack_8._0_1_ = 5;
  FUN_00b859f0(auStack_184);
  iStack_8._0_1_ = 6;
  FUN_00b859f0(auStack_13c);
  iStack_8._0_1_ = 7;
  cVar5 = FUN_00585a40(auStack_ac,uVar8);
  if (cVar5 == '\0') {
    FUN_00b859f0(auStack_ac);
    iStack_8._0_1_ = 8;
    iVar6 = FUN_01674e20(0x48);
    iStack_8._0_1_ = 9;
    if (iVar6 != 0) {
      FUN_00b859f0(auStack_f4);
    }
    FUN_008e9ba0();
    FUN_008e9ba0();
    bVar4 = true;
  }
  else {
    FUN_008e9ba0();
    bVar4 = false;
  }
  FUN_008e9ba0();
  ppuVar7 = &PTR_FUN_01959328;
  if (!bVar4) {
    ppuVar7 = (undefined **)0x0;
  }
  FUN_008e9ba0(ppuVar7);
  FUN_008e9ba0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_008e9ba0();
  iVar6 = FUN_008d0b40(param_2,0x41f00000,ppuVar7);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 2;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)(*piStack_18 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 25210 ; VA 0x00b89ec0 ; FUN_00b89ec0 */

undefined4 * __thiscall FUN_00b89ec0(int param_1,undefined4 *param_2,int param_3)

{
  undefined4 uVar1;
  undefined3 uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  uint in_stack_0000001c;
  int aiStack_34 [5];
  uint uStack_20;
  undefined4 *puStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017f9590;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined4 *)0x0;
  iStack_18 = 0;
  uStack_14 = 0;
  uStack_7 = 0;
  uVar2 = uStack_7;
  uStack_8 = 1;
  uStack_7 = 0;
  puVar6 = (undefined4 *)0x0;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar4 = *(int *)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    if ((iVar4 != 0) && (param_1 = iVar4, ExceptionList = &pvStack_10, *(int *)(iVar4 + 0x34) != 0))
    {
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
    }
    uVar2 = uStack_7;
    if (((param_1 != 0) &&
        (iVar4 = *(int *)(param_1 + 0xc), iVar3 = FUN_008a8c30(), puVar6 = puStack_1c,
        uVar2 = uStack_7,
        (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da))) &&
       (iVar4 = FUN_005c2760(), puVar6 = puStack_1c, uVar2 = uStack_7, iVar4 != 0)) {
      FUN_0054ef60(&param_3);
      uStack_8 = 2;
      FUN_009cbbb0(aiStack_34);
      uStack_8 = 3;
      FUN_008c8540(aiStack_34,&puStack_1c,&DAT_01d62f20);
      puVar6 = puStack_1c;
      uVar2 = uStack_7;
      if (0xf < uStack_20) {
        uVar5 = uStack_20 + 1;
        iVar4 = aiStack_34[0];
        if (0xfff < uVar5) {
          iVar4 = *(int *)(aiStack_34[0] + -4);
          uVar5 = uStack_20 + 0x24;
          if (0x1f < (aiStack_34[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar5);
        puVar6 = puStack_1c;
        uVar2 = uStack_7;
      }
    }
  }
  uStack_7 = uVar2;
  if (iStack_18 - (int)puVar6 >> 3 == 0) {
    *param_2 = 0;
    param_2[1] = 0;
    thunk_FUN_00577ac0();
    if (0xf < in_stack_0000001c) {
      uVar5 = in_stack_0000001c + 1;
      iVar4 = param_3;
      if (0xfff < uVar5) {
        iVar4 = *(int *)(param_3 + -4);
        uVar5 = in_stack_0000001c + 0x24;
        if (0x1f < (param_3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar5);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar4 = puVar6[1];
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar4 != 0) {
    LOCK();
    *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
    UNLOCK();
    iVar4 = puVar6[1];
  }
  uVar1 = *puVar6;
  param_2[1] = iVar4;
  *param_2 = uVar1;
  thunk_FUN_00577ac0();
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar4 = param_3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_3 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25211 ; VA 0x00b8a0a0 ; FUN_00b8a0a0 */

void __fastcall FUN_00b8a0a0(int param_1)

{
  *(undefined *)(param_1 + 0x76) = 1;
  return;
}



/* FUNCTION 25212 ; VA 0x00b8a0b0 ; FUN_00b8a0b0 */

void FUN_00b8a0b0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffcf;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x48);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00b85920(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0096ca80();
        FUN_01674ea0(iVar2,0x48);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1ded4fc);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_08d80c64a9b86da927ad6d54a032358b>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 25213 ; VA 0x00b8a200 ; FUN_00b8a200 */

void FUN_00b8a200(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008c1ba0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 8);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x10,iVar3 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar3 + 8) = 0;
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1ded4c4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_2988e3501af800731888be47e4e85332>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 25214 ; VA 0x00b8a370 ; FUN_00b8a370 */

void FUN_00b8a370(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffcf;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x48);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00b859f0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008e9ba0();
        FUN_01674ea0(iVar2,0x48);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1ded454);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_4417d9ce833c0173e69857d9fe4ef8ee>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 25215 ; VA 0x00b8a4c0 ; FUN_00b8a4c0 */

void FUN_00b8a4c0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a13f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x50);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00b85af0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008e9ac0();
        FUN_01674ea0(iVar2,0x50);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1ded48c);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_48c042fde71008d75b422ac47bafbdb9>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 25216 ; VA 0x00b8a610 ; FUN_00b8a610 */

void __thiscall FUN_00b8a610(int param_1,undefined4 *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar2 = (int)param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f95c9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != (undefined4 *)0x0) {
    ExceptionList = &pvStack_10;
    cVar4 = FUN_00971ce0(param_2,1);
    if (cVar4 != '\0') {
      FUN_01679490();
    }
  }
  iVar3 = param_3;
  FUN_008a4210(iVar2,param_3);
  if (iVar3 != 0) {
    cVar4 = FUN_00971ce0(iVar3,1);
    if (cVar4 != '\0') {
      FUN_006eccd0();
      uStack_8 = 0;
      uVar5 = FUN_01675290(DAT_02110da8);
      uStack_8 = 1;
      param_3 = uVar5;
      puVar6 = (undefined4 *)FUN_01674e20(0x1c);
      if (puVar6 == (undefined4 *)0x0) {
        puVar6 = (undefined4 *)0x0;
      }
      else {
        *puVar6 = 0;
        puVar6[1] = 1;
        puVar6[2] = FUN_00b876a0;
        puVar6[3] = _guard_check_icall;
        puVar6[4] = 0;
        puVar6[5] = param_1 + 0x68;
        puVar6[6] = param_1;
      }
      FUN_016797d0(puVar6);
      if (puVar6 != (undefined4 *)0x0) {
        LOCK();
        puVar6[1] = puVar6[1] + 1;
        UNLOCK();
      }
      uStack_8 = 2;
      param_2 = puVar6;
      FUN_01675290(uVar5);
      uStack_8 = 3;
      cVar4 = FUN_01679300(&param_2);
      if (cVar4 != '\0') {
        FUN_01679490();
        FUN_016791c0(&param_2);
      }
      if (param_2 != (undefined4 *)0x0) {
        piVar1 = param_2 + 1;
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(param_2);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25217 ; VA 0x00b8a780 ; FUN_00b8a780 */

void __thiscall
FUN_00b8a780(undefined4 param_1,undefined *param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  
  if ((param_2 == &DAT_0212f018) && (cVar1 = FUN_00983210(param_1), cVar1 != '\0')) {
    return;
  }
  FUN_009cba80(param_2,param_3,param_4);
  return;
}



/* FUNCTION 25218 ; VA 0x00b8a7c0 ; FUN_00b8a7c0 */

void __thiscall FUN_00b8a7c0(int param_1,char param_2)

{
  char cVar1;
  
  if (*(char *)(param_1 + 0x75) != param_2) {
    cVar1 = FUN_00983210(param_1);
    if ((cVar1 != '\0') || (*(char *)(param_1 + 0x76) == '\0')) {
      *(char *)(param_1 + 0x75) = param_2;
      FUN_008a4940(&DAT_0212f508);
    }
  }
  return;
}



/* FUNCTION 25219 ; VA 0x00b8a800 ; FUN_00b8a800 */

void __thiscall FUN_00b8a800(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x74) != param_2) {
    *(char *)(param_1 + 0x74) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25220 ; VA 0x00b8a820 ; FUN_00b8a820 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b8a820(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef208c) {
    FUN_016f3809(&DAT_01ef208c);
    if (DAT_01ef208c == -1) {
      _DAT_01ef2080 = FUN_005c65f0;
      _DAT_01ef2084 = FUN_005c93a0;
      DAT_01ef2088 = FUN_005c77b0;
      FUN_016f37bf(&DAT_01ef208c);
    }
  }
  return &DAT_01ef2080;
}



/* FUNCTION 25221 ; VA 0x00b8a890 ; FUN_00b8a890 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b8a890(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f9600;
  pvStack_10 = ExceptionList;
  if (DAT_01ef2094 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef22a8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef22a8);
      if (DAT_01ef22a8 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Visit",1,uStack_20,0,0,1,0,0);
        _DAT_01ef22a0 = RBX::Creator<class_RBX::Visit>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef2098,&DAT_01ef22a0);
        FUN_016f3654(FUN_01890930);
        FUN_016f37bf(&DAT_01ef22a8);
      }
    }
    DAT_01ef2094 = &DAT_01ef2098;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef2094;
}



/* FUNCTION 25222 ; VA 0x00b8a990 ; FUN_00b8a990 */

undefined4 * __fastcall FUN_00b8a990(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f963e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a7a0();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::Visit,class_RBX::ServiceInstance>::vftable;
  uVar1 = FUN_00b8a890();
  param_1[3] = uVar1;
  *param_1 = RBX::Visit::vftable;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0xf;
  uStack_8 = 1;
  *(undefined *)(param_1 + 0x16) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  param_1[0x1c] = 0;
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("Visit",5);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25223 ; VA 0x00b8aa80 ; FUN_00b8aa80 */

void __fastcall FUN_00b8aa80(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Visit>::vftable;
  uVar1 = FUN_00b8a890(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25224 ; VA 0x00b8aac0 ; FUN_00b8aac0 */

undefined4 * __thiscall FUN_00b8aac0(undefined4 *param_1,byte param_2)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = RBX::Visit::vftable;
  iVar1 = param_1[0x1c];
  if (iVar1 != 0) {
    FUN_01519bf0();
    FUN_01674ea0(iVar1,8);
  }
  uVar2 = param_1[0x1b];
  if (0xf < uVar2) {
    iVar1 = param_1[0x16];
    uVar4 = uVar2 + 1;
    iVar3 = iVar1;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar4 = uVar2 + 0x24;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x1a] = 0;
  param_1[0x1b] = 0xf;
  *(undefined *)(param_1 + 0x16) = 0;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x74);
  }
  return param_1;
}



/* FUNCTION 25225 ; VA 0x00b8ab50 ; FUN_00b8ab50 */

undefined4 * FUN_00b8ab50(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00634f20(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 25226 ; VA 0x00b8abc0 ; FUN_00b8abc0 */

void FUN_00b8abc0(void)

{
  int iVar1;
  
  if (DAT_01ef22ac == 0) {
    iVar1 = FUN_00b8a890();
    DAT_01ef22ac = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 25227 ; VA 0x00b8abe0 ; FUN_00b8abe0 */

int * FUN_00b8abe0(int *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  char cVar3;
  uint *puVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  bool bVar10;
  undefined auStack_14 [8];
  int iStack_c;
  undefined4 uStack_8;
  
  puVar4 = (uint *)FUN_00b43730(auStack_14,0,0);
  uVar9 = *param_2;
  uVar1 = param_2[1];
  if ((((uVar9 != 0) || (uVar1 != 0x80000000)) && ((uVar9 != 0xffffffff || (uVar1 != 0x7fffffff))))
     && ((uVar9 != 0xfffffffe || (uVar1 != 0x7fffffff)))) {
    uVar9 = *puVar4;
    uVar1 = puVar4[1];
    if (((uVar9 != 0) || (uVar1 != 0x80000000)) &&
       (((uVar9 != 0xffffffff || (uVar1 != 0x7fffffff)) &&
        ((uVar9 != 0xfffffffe || (uVar1 != 0x7fffffff)))))) {
      FUN_005ef640(0,0,0,*param_2 - *puVar4,(param_2[1] - puVar4[1]) - (uint)(*param_2 < *puVar4));
      iVar5 = iStack_c;
      goto LAB_00b8add6;
    }
  }
  uVar9 = *param_2;
  uVar1 = *puVar4;
  uVar8 = param_2[1];
  uVar2 = puVar4[1];
  if ((((uVar9 == 0) && (uVar8 == 0x80000000)) ||
      (((uVar9 == 0xffffffff && (uVar8 == 0x7fffffff)) ||
       ((uVar9 == 0xfffffffe && (uVar8 == 0x7fffffff)))))) ||
     (((uVar1 == 0 && (uVar2 == 0x80000000)) ||
      (((uVar1 == 0xffffffff && (uVar2 == 0x7fffffff)) ||
       ((uVar1 == 0xfffffffe && (uVar2 == 0x7fffffff)))))))) {
    if (((uVar9 == 0xfffffffe) && (uVar8 == 0x7fffffff)) ||
       ((uVar1 == 0xfffffffe && (uVar2 == 0x7fffffff)))) goto LAB_00b8ad62;
    if ((uVar9 != 0xffffffff) || (uVar8 != 0x7fffffff)) {
      if ((uVar9 != 0) || (uVar8 != 0x80000000)) goto LAB_00b8acee;
      if ((uVar1 == 0) && (uVar2 == 0x80000000)) {
        iVar5 = 0;
        goto LAB_00b8ad78;
      }
      goto LAB_00b8ad55;
    }
    if ((uVar1 == 0xffffffff) && (uVar2 == 0x7fffffff)) goto LAB_00b8ad62;
LAB_00b8acee:
    if ((uVar9 == 0xffffffff) && (uVar8 == 0x7fffffff)) goto LAB_00b8ad55;
    if ((uVar1 == 0xffffffff) && (uVar2 == 0x7fffffff)) {
      uVar9 = 0;
      uVar8 = 0x80000000;
    }
    else {
      cVar3 = FUN_00586330(uVar1,uVar2);
      if (cVar3 == '\0') goto LAB_00b8ad51;
      uVar9 = 0xffffffff;
      uVar8 = 0x7fffffff;
    }
  }
  else {
LAB_00b8ad51:
    bVar10 = uVar9 < uVar1;
    uVar9 = uVar9 - uVar1;
    uVar8 = (uVar8 - uVar2) - (uint)bVar10;
LAB_00b8ad55:
    if ((uVar9 == 0xfffffffe) && (uVar8 == 0x7fffffff)) {
LAB_00b8ad62:
      iVar5 = 0;
      goto LAB_00b8ad78;
    }
  }
  if ((uVar9 == 0) && (uVar8 == 0x80000000)) {
    iVar5 = 1;
  }
  else {
    if ((uVar9 != 0xffffffff) || (uVar8 != 0x7fffffff)) {
      uStack_8 = 0x7fffffff;
      iVar5 = -2;
LAB_00b8add6:
      iVar7 = FUN_016f3900(iVar5,uStack_8,1000000,0);
      *param_1 = iVar7;
      param_1[1] = iVar7 >> 0x1f;
      param_1[2] = (iVar5 + iVar7 * -1000000) * 1000;
      return param_1;
    }
    iVar5 = 2;
  }
LAB_00b8ad78:
                    /* WARNING: Could not recover jumptable at 0x00b8ad78. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  piVar6 = (int *)(*(code *)(&DAT_00b8ae0c)[iVar5])();
  return piVar6;
}



/* FUNCTION 25228 ; VA 0x00b8ae20 ; FUN_00b8ae20 */

uint FUN_00b8ae20(void)

{
  int iVar1;
  
  iVar1 = FUN_00b8a890();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 25229 ; VA 0x00b8ae40 ; FUN_00b8ae40 */

uint FUN_00b8ae40(void)

{
  int iVar1;
  
  iVar1 = FUN_00b8a890();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 25230 ; VA 0x00b8ae60 ; FUN_00b8ae60 */

undefined4 FUN_00b8ae60(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined auStack_1c [16];
  undefined auStack_c [8];
  
  if (param_2 == 1) {
    FUN_005f0a90(auStack_c,FUN_005f1e70);
    puVar4 = (undefined4 *)FUN_00b8abe0(auStack_1c,auStack_c);
    uVar1 = puVar4[1];
    uVar2 = puVar4[2];
    uVar3 = puVar4[3];
    *param_1 = *puVar4;
    param_1[1] = uVar1;
    param_1[2] = uVar2;
    param_1[3] = uVar3;
    return 1;
  }
  return 0;
}



/* FUNCTION 25231 ; VA 0x00b8aeb0 ; FUN_00b8aeb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __thiscall
FUN_00b8aeb0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f966f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef268c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef268c);
    if (DAT_01ef268c == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01ef2668 = RBX::Reflection::RefType<class_RBX::Folder*>::vftable;
      FUN_016f3654(&LAB_01891390);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ef268c);
    }
  }
  uVar2 = FUN_00b8c330();
  FUN_009ca670(uVar2,&DAT_01ef2668,param_2,param_3,param_8,param_9,param_10,param_11,param_12,
               param_12,0);
  param_1[0xd] = (int)RBX::IIDREF::vftable;
  uStack_8 = 1;
  *param_1 = (int)RBX::Reflection::RefPropDescriptor<class_RBX::GuiService,class_RBX::Folder>::
                  vftable;
  param_1[0xd] = (int)RBX::Reflection::RefPropDescriptor<class_RBX::GuiService,class_RBX::Folder>::
                      vftable;
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::GuiService,class_RBX::Folder*>::
              GetSetImpl<class_RBX::Folder*_(__thiscall_RBX::GuiService::*)(void)const_,void_(__thiscall_RBX::GuiService::*)(class_RBX::Folder*)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  param_1[0xe] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (**(code **)(*param_1 + 0xc))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar1 = (**(code **)(*param_1 + 8))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25232 ; VA 0x00b8b010 ; FUN_00b8b010 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __thiscall
FUN_00b8b010(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f969f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eefe7c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eefe7c);
    if (DAT_01eefe7c == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01eefe58 = RBX::Reflection::RefType<class_RBX::GuiObject*>::vftable;
      FUN_016f3654(&LAB_0188e490);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eefe7c);
    }
  }
  uVar2 = FUN_00b8c330();
  FUN_009ca670(uVar2,&DAT_01eefe58,param_2,param_3,param_8,param_9,param_10,param_11,param_12,
               param_12,0);
  param_1[0xd] = (int)RBX::IIDREF::vftable;
  uStack_8 = 1;
  *param_1 = (int)RBX::Reflection::RefPropDescriptor<class_RBX::GuiService,class_RBX::GuiObject>::
                  vftable;
  param_1[0xd] = (int)RBX::Reflection::RefPropDescriptor<class_RBX::GuiService,class_RBX::GuiObject>
                      ::vftable;
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::GuiService,class_RBX::GuiObject*>::
              GetSetImpl<class_RBX::GuiObject*_(__thiscall_RBX::GuiService::*)(void)const_,void_(__thiscall_RBX::GuiService::*)(class_RBX::GuiObject*)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  param_1[0xe] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (**(code **)(*param_1 + 0xc))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar1 = (**(code **)(*param_1 + 8))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25233 ; VA 0x00b8b170 ; FUN_00b8b170 */

undefined4 * __thiscall
FUN_00b8b170(undefined4 *param_1,uint param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8)

{
  uint *puVar1;
  char cVar2;
  undefined **ppuVar3;
  uint auStack_98 [2];
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 *puStack_74;
  undefined4 *puStack_70;
  uint uStack_64;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined8 uStack_4c;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f96c8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_3c = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_2 != 0) {
    uStack_3c = param_2;
    if ((param_2 & 1) == 0) {
      puStack_70 = (undefined4 *)0x0;
      puStack_74 = &uStack_34;
      puStack_78 = &param_4;
      uStack_80 = CONCAT44(0xb8b1d4,(undefined4)uStack_80);
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))();
    }
    else {
      uStack_34 = param_4;
      uStack_30 = param_5;
      uStack_2c = param_6;
      uStack_28 = param_7;
      uStack_24 = param_8;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  uStack_64 = 0;
  if (uStack_3c != 0) {
    uStack_64 = uStack_3c;
    if ((uStack_3c & 1) == 0) {
      puStack_74 = &uStack_5c;
      puStack_70 = (undefined4 *)0x0;
      puStack_78 = &uStack_34;
      uStack_80 = CONCAT44(0xb8b21d,(undefined4)uStack_80);
      (**(code **)(uStack_3c & 0xfffffffe))();
    }
    else {
      uStack_5c = uStack_34;
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
    }
  }
  puStack_70 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = auStack_98;
  auStack_98[0] = 0;
  puVar1 = auStack_98;
  if (uStack_64 != 0) {
    auStack_98[0] = uStack_64;
    if ((uStack_64 & 1) == 0) {
      (**(code **)(uStack_64 & 0xfffffffe))(&uStack_5c,&uStack_90,0);
      puVar1 = puStack_14;
    }
    else {
      uStack_90 = uStack_5c;
      uStack_8c = uStack_58;
      uStack_88 = uStack_54;
      uStack_84 = uStack_50;
      uStack_80 = uStack_4c;
      puVar1 = auStack_98;
    }
  }
  puStack_14 = puVar1;
  ppuVar3 = &PTR_FUN_0195a314;
  cVar2 = FUN_00b8d200();
  if (cVar2 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8._0_1_ = 3;
  if (((uStack_64 != 0) && ((uStack_64 & 1) == 0)) &&
     (*(code **)(uStack_64 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_5c;
    puStack_70 = (undefined4 *)0x2;
    uStack_80 = CONCAT44(0xb8b2a6,(undefined4)uStack_80);
    puStack_74 = puStack_78;
    (**(code **)(uStack_64 & 0xfffffffe))();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_3c != 0) {
    if (((uStack_3c & 1) == 0) && (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_34;
      puStack_70 = (undefined4 *)0x2;
      uStack_80 = CONCAT44(0xb8b2d5,(undefined4)uStack_80);
      puStack_74 = puStack_78;
      (**(code **)(uStack_3c & 0xfffffffe))();
    }
    uStack_3c = 0;
  }
  uStack_8 = 5;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_4;
    puStack_70 = (undefined4 *)0x2;
    uStack_80 = CONCAT44(0xb8b303,(undefined4)uStack_80);
    puStack_74 = puStack_78;
    (**(code **)(param_2 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25234 ; VA 0x00b8b320 ; FUN_00b8b320 */

undefined4 * __thiscall
FUN_00b8b320(undefined4 *param_1,uint param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined8 param_8)

{
  uint *puVar1;
  char cVar2;
  undefined **ppuVar3;
  uint auStack_98 [2];
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 *puStack_74;
  undefined4 *puStack_70;
  uint uStack_64;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined8 uStack_4c;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f96c8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_3c = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_2 != 0) {
    uStack_3c = param_2;
    if ((param_2 & 1) == 0) {
      puStack_70 = (undefined4 *)0x0;
      puStack_74 = &uStack_34;
      puStack_78 = &param_4;
      uStack_80 = CONCAT44(0xb8b384,(undefined4)uStack_80);
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))();
    }
    else {
      uStack_34 = param_4;
      uStack_30 = param_5;
      uStack_2c = param_6;
      uStack_28 = param_7;
      uStack_24 = param_8;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  uStack_64 = 0;
  if (uStack_3c != 0) {
    uStack_64 = uStack_3c;
    if ((uStack_3c & 1) == 0) {
      puStack_74 = &uStack_5c;
      puStack_70 = (undefined4 *)0x0;
      puStack_78 = &uStack_34;
      uStack_80 = CONCAT44(0xb8b3cd,(undefined4)uStack_80);
      (**(code **)(uStack_3c & 0xfffffffe))();
    }
    else {
      uStack_5c = uStack_34;
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
    }
  }
  puStack_70 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = auStack_98;
  auStack_98[0] = 0;
  puVar1 = auStack_98;
  if (uStack_64 != 0) {
    auStack_98[0] = uStack_64;
    if ((uStack_64 & 1) == 0) {
      (**(code **)(uStack_64 & 0xfffffffe))(&uStack_5c,&uStack_90,0);
      puVar1 = puStack_14;
    }
    else {
      uStack_90 = uStack_5c;
      uStack_8c = uStack_58;
      uStack_88 = uStack_54;
      uStack_84 = uStack_50;
      uStack_80 = uStack_4c;
      puVar1 = auStack_98;
    }
  }
  puStack_14 = puVar1;
  ppuVar3 = &PTR_FUN_0195a2f8;
  cVar2 = FUN_00b8d200();
  if (cVar2 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8._0_1_ = 3;
  if (((uStack_64 != 0) && ((uStack_64 & 1) == 0)) &&
     (*(code **)(uStack_64 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_5c;
    puStack_70 = (undefined4 *)0x2;
    uStack_80 = CONCAT44(0xb8b456,(undefined4)uStack_80);
    puStack_74 = puStack_78;
    (**(code **)(uStack_64 & 0xfffffffe))();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_3c != 0) {
    if (((uStack_3c & 1) == 0) && (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_34;
      puStack_70 = (undefined4 *)0x2;
      uStack_80 = CONCAT44(0xb8b485,(undefined4)uStack_80);
      puStack_74 = puStack_78;
      (**(code **)(uStack_3c & 0xfffffffe))();
    }
    uStack_3c = 0;
  }
  uStack_8 = 5;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_4;
    puStack_70 = (undefined4 *)0x2;
    uStack_80 = CONCAT44(0xb8b4b3,(undefined4)uStack_80);
    puStack_74 = puStack_78;
    (**(code **)(param_2 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25235 ; VA 0x00b8b4d0 ; FUN_00b8b4d0 */

undefined4 * __thiscall
FUN_00b8b4d0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined **ppuVar3;
  undefined4 auStack_a0 [2];
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f96f8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_40 = param_2;
  uStack_38 = 0;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_74 = 0;
      puStack_78 = &uStack_30;
      uStack_80 = CONCAT44(&param_6,0xb8b53d);
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = CONCAT44(param_11,param_10);
    }
  }
  uVar1 = uStack_40;
  uStack_8._0_1_ = 1;
  puVar2 = param_1 + 2;
  uStack_60 = 0;
  if (uStack_38 != 0) {
    uStack_60 = uStack_38;
    if ((uStack_38 & 1) == 0) {
      puStack_78 = &uStack_58;
      uStack_74 = 0;
      uStack_80 = CONCAT44(&uStack_30,0xb8b589);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    else {
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
      uStack_48 = uStack_20;
    }
  }
  uStack_74 = param_11;
  uStack_8._0_1_ = 2;
  puStack_18 = (undefined *)auStack_a0;
  uStack_98 = 0;
  auStack_a0[0] = uVar1;
  puStack_78 = puVar2;
  puVar2 = auStack_a0;
  if (uStack_60 != 0) {
    uStack_98 = uStack_60;
    if ((uStack_60 & 1) == 0) {
      (**(code **)(uStack_60 & 0xfffffffe))(&uStack_58,&uStack_90,0);
      puVar2 = (undefined4 *)puStack_18;
    }
    else {
      uStack_90 = uStack_58;
      uStack_8c = uStack_54;
      uStack_88 = uStack_50;
      uStack_84 = uStack_4c;
      uStack_80 = uStack_48;
      puVar2 = auStack_a0;
    }
  }
  puStack_18 = (undefined *)puVar2;
  ppuVar3 = &PTR_FUN_0195a33c;
  cStack_11 = FUN_00b8d410();
  uStack_8._0_1_ = 3;
  if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
     (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_58;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0xb8b613);
    (**(code **)(uStack_60 & 0xfffffffe))();
  }
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_38 != 0) {
    if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_30;
      uStack_74 = 2;
      uStack_80 = CONCAT44(puStack_78,0xb8b64e);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    uStack_38 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_6;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0xb8b67c);
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25236 ; VA 0x00b8b6a0 ; FUN_00b8b6a0 */

undefined4 * __thiscall
FUN_00b8b6a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_0195a34c;
  cVar3 = FUN_005918b0(param_2,param_3,param_4,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 25237 ; VA 0x00b8b790 ; FUN_00b8b790 */

undefined4 * __thiscall
FUN_00b8b790(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined in_stack_00000030;
  undefined4 uStack_ac;
  int *piStack_a8;
  undefined4 uStack_84;
  undefined4 *puStack_80;
  undefined4 uStack_70;
  int *piStack_6c;
  undefined auStack_68 [32];
  undefined uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int *piStack_3c;
  undefined auStack_38 [32];
  undefined uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017f9740;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_70;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_70 = param_3;
  piStack_6c = param_4;
  puStack_80 = (undefined4 *)&stack0x00000010;
  uStack_8 = 1;
  uStack_7 = 0;
  uStack_84 = 0xb8b7fa;
  FUN_00d88580();
  uStack_48 = in_stack_00000030;
  uStack_44 = param_2;
  puStack_14 = &uStack_40;
  *param_1 = 0;
  if (piStack_6c != (int *)0x0) {
    LOCK();
    piStack_6c[2] = piStack_6c[2] + 1;
    UNLOCK();
  }
  uStack_40 = uStack_70;
  piStack_3c = piStack_6c;
  puStack_80 = (undefined4 *)auStack_68;
  uStack_8 = 3;
  uStack_84 = 0xb8b847;
  FUN_00d88580();
  uStack_18 = uStack_48;
  puStack_80 = param_1 + 2;
  puStack_14 = &uStack_ac;
  if (piStack_3c != (int *)0x0) {
    LOCK();
    piStack_3c[2] = piStack_3c[2] + 1;
    UNLOCK();
  }
  uStack_ac = uStack_40;
  piStack_a8 = piStack_3c;
  uStack_8 = 5;
  FUN_00d88580(auStack_38);
  uStack_84 = CONCAT31(uStack_84._1_3_,uStack_18);
  ppuVar4 = &PTR_FUN_0195a344;
  _uStack_8 = CONCAT31(uStack_7,4);
  cVar3 = FUN_00b8d570();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  puStack_80 = (undefined4 *)0xb8b8be;
  FUN_00d88a30();
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_3c[2] + -1;
    piStack_3c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_80 = (undefined4 *)0xb8b8d6;
      (**(code **)(*piStack_3c + 4))();
    }
  }
  puStack_80 = (undefined4 *)0xb8b8de;
  FUN_00d88a30();
  if (piStack_6c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_6c[2] + -1;
    piStack_6c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_80 = (undefined4 *)0xb8b8f3;
      (**(code **)(*piStack_6c + 4))();
    }
  }
  puStack_80 = (undefined4 *)0xb8b8fb;
  FUN_00d88a30();
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_80 = (undefined4 *)0xb8b90f;
      (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25238 ; VA 0x00b8b930 ; FUN_00b8b930 */

undefined4 * __thiscall
FUN_00b8b930(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_0195a2e8;
  cVar3 = FUN_00b8d740(param_2,param_3,param_4,param_5,param_6);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        iVar2 = param_5[2] + -1;
        param_5[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 25239 ; VA 0x00b8ba30 ; FUN_00b8ba30 */

undefined4 * __thiscall FUN_00b8ba30(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined auStack_fc [40];
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined auStack_cc [40];
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined auStack_9c [40];
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined auStack_6c [40];
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined auStack_3c [40];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9798;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00b902d0(&stack0x0000000c);
  uStack_d4 = param_2;
  uStack_d0 = param_3;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_00b902d0(auStack_fc);
  uStack_a4 = uStack_d4;
  uStack_a0 = uStack_d0;
  uStack_8._0_1_ = 2;
  FUN_00b902d0(auStack_cc);
  uStack_44 = uStack_a4;
  uStack_40 = uStack_a0;
  uStack_8._0_1_ = 3;
  FUN_00b902d0(auStack_9c);
  uStack_8._0_1_ = 4;
  cVar2 = FUN_00585a40(&uStack_44);
  if (cVar2 == '\0') {
    uStack_74 = uStack_44;
    uStack_70 = uStack_40;
    FUN_00b902d0(auStack_3c);
    uStack_8._0_1_ = 5;
    puVar3 = (undefined4 *)FUN_01674e20(0x30);
    uStack_8._0_1_ = 6;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uStack_74;
      puVar3[1] = uStack_70;
      FUN_00b902d0(auStack_6c);
    }
    param_1[2] = puVar3;
    FUN_00a7c840();
    FUN_00a7c840();
    bVar1 = true;
  }
  else {
    FUN_00a7c840();
    bVar1 = false;
  }
  FUN_00a7c840();
  ppuVar4 = &PTR_FUN_0195a31c;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_00a7c840();
  FUN_00a7c840();
  FUN_00a7c840();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25240 ; VA 0x00b8bbe0 ; FUN_00b8bbe0 */

int __thiscall FUN_00b8bbe0(int param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int iVar1;
  undefined in_stack_00000030;
  undefined4 uStack_8c;
  int *piStack_88;
  undefined4 uStack_6c;
  undefined *puStack_68;
  undefined *puStack_64;
  uint *puStack_60;
  uint uStack_54;
  undefined auStack_4c [24];
  uint auStack_34 [2];
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017f97d0;
  pvStack_10 = ExceptionList;
  puStack_60 = (uint *)0x0;
  puStack_14 = &uStack_8c;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_8c = param_3;
  piStack_88 = param_4;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_00d88580(&stack0x00000010);
  uStack_8 = 0;
  puStack_64 = (undefined *)CONCAT31(puStack_64._1_3_,in_stack_00000030);
  puStack_60 = (uint *)FUN_00b8b790();
  if ((uint *)param_1 != puStack_60) {
    auStack_34[0] = 0;
    uStack_8 = 3;
    puStack_64 = (undefined *)0xb8bc7a;
    FUN_005880d0();
    puStack_64 = (undefined *)0xb8bc82;
    puStack_60 = (uint *)param_1;
    FUN_005880d0();
    puStack_60 = auStack_34;
    puStack_64 = (undefined *)0xb8bc8d;
    FUN_005880d0();
    uStack_8 = 4;
    if (((auStack_34[0] != 0) && ((auStack_34[0] & 1) == 0)) &&
       (*(code **)(auStack_34[0] & 0xfffffffe) != (code *)0x0)) {
      puStack_68 = auStack_2c;
      puStack_60 = (uint *)0x2;
      uStack_6c = 0xb8bcae;
      puStack_64 = puStack_68;
      (**(code **)(auStack_34[0] & 0xfffffffe))();
    }
  }
  _uStack_8 = CONCAT31(uStack_7,5);
  if (((uStack_54 != 0) && ((uStack_54 & 1) == 0)) &&
     (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
    puStack_68 = auStack_4c;
    puStack_60 = (uint *)0x2;
    uStack_6c = 0xb8bcd2;
    puStack_64 = puStack_68;
    (**(code **)(uStack_54 & 0xfffffffe))();
  }
  puStack_60 = (uint *)0xb8bcdd;
  FUN_00d88a30();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar1 = param_4[2] + -1;
    param_4[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      puStack_60 = (uint *)0xb8bcf3;
      (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25241 ; VA 0x00b8bd10 ; FUN_00b8bd10 */

int * __thiscall FUN_00b8bd10(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00b9dc40();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 25242 ; VA 0x00b8bd60 ; FUN_00b8bd60 */

int * __thiscall FUN_00b8bd60(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00b9dcb0();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 25243 ; VA 0x00b8bdb0 ; FUN_00b8bdb0 */

int * __thiscall FUN_00b8bdb0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00b9dd20();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 25244 ; VA 0x00b8be00 ; FUN_00b8be00 */

void FUN_00b8be00(int *param_1,int *param_2,undefined param_3)

{
  undefined *puVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  int iVar9;
  
  uVar2 = param_2[5];
  uVar6 = param_2[4];
  if (uVar6 < uVar2) {
    param_2[4] = uVar6 + 1;
    piVar7 = param_2;
    if (0xf < uVar2) {
      piVar7 = (int *)*param_2;
    }
    *(undefined *)((int)piVar7 + uVar6) = param_3;
    *(undefined *)((int)piVar7 + uVar6 + 1) = 0;
  }
  else {
    if (uVar6 == 0x7fffffff) {
      FUN_00554040();
LAB_00b8bf2c:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    uVar8 = uVar6 + 1 | 0xf;
    if (uVar8 < 0x80000000) {
      if (0x7fffffff - (uVar2 >> 1) < uVar2) {
        uVar8 = 0x7fffffff;
      }
      else {
        uVar4 = (uVar2 >> 1) + uVar2;
        if (uVar8 < uVar4) {
          uVar8 = uVar4;
        }
      }
    }
    else {
      uVar8 = 0x7fffffff;
    }
    iVar5 = FUN_00554060(uVar8 + 1);
    param_2[5] = uVar8;
    puVar1 = (undefined *)(iVar5 + uVar6);
    param_2[4] = uVar6 + 1;
    if (uVar2 < 0x10) {
      FUN_0170c6f0(iVar5,param_2,uVar6);
      *puVar1 = param_3;
      puVar1[1] = 0;
    }
    else {
      iVar3 = *param_2;
      FUN_0170c6f0(iVar5,iVar3,uVar6);
      *puVar1 = param_3;
      puVar1[1] = 0;
      uVar6 = uVar2 + 1;
      iVar9 = iVar3;
      if (0xfff < uVar6) {
        iVar9 = *(int *)(iVar3 + -4);
        uVar6 = uVar2 + 0x24;
        if (0x1f < (iVar3 - iVar9) - 4U) goto LAB_00b8bf2c;
      }
      FUN_01674ea0(iVar9,uVar6);
    }
    *param_2 = iVar5;
  }
  param_1[4] = 0;
  param_1[5] = 0;
  iVar5 = param_2[1];
  iVar3 = param_2[2];
  iVar9 = param_2[3];
  *param_1 = *param_2;
  param_1[1] = iVar5;
  param_1[2] = iVar3;
  param_1[3] = iVar9;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return;
}



/* FUNCTION 25245 ; VA 0x00b8bf40 ; FUN_00b8bf40 */

void __thiscall
FUN_00b8bf40(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4)

{
  int *piVar1;
  code *pcVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f97f8;
  pvStack_10 = ExceptionList;
  pcVar2 = (code *)*param_3;
  uVar3 = *(uint *)param_4[3];
  ExceptionList = &pvStack_10;
  if ((uVar3 != 0) && (ExceptionList = &pvStack_10, (uVar3 & 1) == 0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(uVar3 & 0xfffffffe))();
  }
  uStack_8 = 0;
  uVar3 = *(uint *)param_4[2];
  if ((uVar3 != 0) && ((uVar3 & 1) == 0)) {
    (**(code **)(uVar3 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 1;
  FUN_0054ef60(param_4[1]);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0054ef60(*param_4);
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  (*pcVar2)(*param_1,param_1[1]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25246 ; VA 0x00b8c070 ; FUN_00b8c070 */

void __thiscall FUN_00b8c070(int param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4)

{
  code *pcVar1;
  int iVar2;
  uint uVar3;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  undefined4 uStack_60;
  int iStack_5c;
  undefined4 *puStack_58;
  undefined4 uStack_54;
  uint uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f9830;
  pvStack_10 = ExceptionList;
  uStack_54 = *param_4;
  puStack_58 = (undefined4 *)0xb8c09c;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uVar3 = *(uint *)(param_1 + 8);
  uStack_8 = 0;
  uStack_48 = 0;
  if (uVar3 != 0) {
    uStack_48 = uVar3;
    if ((uVar3 & 1) == 0) {
      puStack_58 = &uStack_40;
      uStack_54 = 0;
      iStack_5c = param_1 + 0x10;
      uStack_60 = 0xb8c0de;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_40 = *(undefined4 *)(param_1 + 0x10);
      uStack_3c = *(undefined4 *)(param_1 + 0x14);
      uStack_38 = *(undefined4 *)(param_1 + 0x18);
      uStack_34 = *(undefined4 *)(param_1 + 0x1c);
      uStack_30 = *(undefined8 *)(param_1 + 0x20);
    }
  }
  uStack_8 = 2;
  pcVar1 = (code *)*param_3;
  uStack_70 = CONCAT44(aiStack_28,0xb8c103);
  FUN_0054ef60();
  uStack_8._0_1_ = 3;
  if (uStack_48 != 0) {
    if ((uStack_48 & 1) == 0) {
      (**(code **)(uStack_48 & 0xfffffffe))(&uStack_40,&uStack_80,0);
    }
    else {
      uStack_80 = uStack_40;
      uStack_7c = uStack_3c;
      uStack_78 = uStack_38;
      uStack_74 = uStack_34;
      uStack_70 = uStack_30;
    }
  }
  uStack_8._0_1_ = 2;
  (*pcVar1)();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((uStack_48 != 0) && ((uStack_48 & 1) == 0)) &&
     (*(code **)(uStack_48 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_48 & 0xfffffffe))(&uStack_40,&uStack_40,2);
  }
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25247 ; VA 0x00b8c1d0 ; FUN_00b8c1d0 */

void __thiscall
FUN_00b8c1d0(undefined4 *param_1,undefined4 param_2,uint param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined8 param_9,uint param_10)

{
  code *pcVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 in_stack_00000038;
  uint in_stack_0000003c;
  int in_stack_00000040;
  uint in_stack_00000054;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_40;
  undefined4 *puStack_3c;
  undefined auStack_38 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9868;
  pvStack_10 = ExceptionList;
  param_2 = auStack_38;
  pcVar1 = (code *)*param_1;
  puStack_3c = &stack0x00000040;
  uStack_8 = 2;
  uStack_40 = 0xb8c20f;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8._0_1_ = 3;
  uStack_58 = CONCAT44(&param_10,0xb8c224);
  FUN_0054ef60();
  uStack_8._0_1_ = 4;
  if (param_3 != 0) {
    if ((param_3 & 1) == 0) {
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_68,0);
    }
    else {
      uStack_68 = param_5;
      uStack_64 = param_6;
      uStack_60 = param_7;
      uStack_5c = param_8;
      uStack_58 = param_9;
    }
  }
  uStack_8._0_1_ = 2;
  (*pcVar1)();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  if (0xf < in_stack_0000003c) {
    uVar3 = in_stack_0000003c + 1;
    uVar4 = param_10;
    if (0xfff < uVar3) {
      uVar4 = *(uint *)(param_10 - 4);
      uVar3 = in_stack_0000003c + 0x24;
      if (0x1f < (param_10 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar3);
  }
  in_stack_00000038 = 0;
  in_stack_0000003c = 0xf;
  param_10 = param_10 & 0xffffff00;
  if (0xf < in_stack_00000054) {
    uVar4 = in_stack_00000054 + 1;
    iVar2 = in_stack_00000040;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(in_stack_00000040 + -4);
      uVar4 = in_stack_00000054 + 0x24;
      if (0x1f < (in_stack_00000040 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25248 ; VA 0x00b8c330 ; FUN_00b8c330 */

undefined * FUN_00b8c330(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f988c;
  pvStack_10 = ExceptionList;
  if (DAT_01ef2304 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef2510) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef2510);
      if (DAT_01ef2510 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"GuiService",1,uStack_20,0,0,1,0,0);
        FUN_016f3654(&LAB_01891380);
        FUN_016f37bf(&DAT_01ef2510);
      }
    }
    DAT_01ef2304 = &DAT_01ef2308;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef2304;
}



/* FUNCTION 25249 ; VA 0x00b8c410 ; FUN_00b8c410 */

void FUN_00b8c410(void)

{
  int iVar1;
  
  if (DAT_01ef2514 == 0) {
    iVar1 = FUN_00b8c330();
    DAT_01ef2514 = *(int *)(iVar1 + 4);
  }
  return;
}


