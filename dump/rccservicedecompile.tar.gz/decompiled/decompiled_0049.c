/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 12250 ; VA 0x007fa2f0 ; FUN_007fa2f0 */

void FUN_007fa2f0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b4874;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb3648) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eb3648);
    if (DAT_01eb3648 == -1) {
      uStack_8 = 0;
      uVar3 = FUN_0152dab0("Render","render3D",0xffffffff);
      DAT_01eb3644 = (undefined4)((ulonglong)uVar3 >> 0x20);
      DAT_01eb3640 = (undefined4)uVar3;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb3648);
    }
  }
  uVar2 = DAT_01eb3644;
  uVar1 = DAT_01eb3640;
  uVar3 = FUN_0152d930(DAT_01eb3640,DAT_01eb3644,DAT_01eb3640,DAT_01eb3644);
  uStack_8 = 1;
  FUN_007fa700(param_1,0,param_2,param_3,0xffffffff);
  FUN_007fa700(param_1,4,param_2,param_3,0xffffffff);
  uStack_8 = 2;
  FUN_0152dda0(uVar1,uVar2,uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12251 ; VA 0x007fa410 ; FUN_007fa410 */

void FUN_007fa410(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_007fa700(param_1,2,param_2,param_3,param_4);
  return;
}



/* FUNCTION 12252 ; VA 0x007fa430 ; FUN_007fa430 */

void __thiscall FUN_007fa430(int param_1,int *param_2,int *param_3,int param_4,int *param_5)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  undefined *puVar6;
  undefined auStack_fc [64];
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  uint uStack_18;
  int *piStack_14;
  int iStack_10;
  int iStack_c;
  char cStack_5;
  
  piStack_14 = (int *)(*(int *)(param_1 + 4) + 0x16c);
  iStack_c = param_1;
  if (param_4 != 0) {
    do {
      iVar5 = *param_3;
      iStack_10 = 0;
      cVar1 = '\0';
      uStack_7c = *(undefined4 *)(iVar5 + 0x48);
      uStack_78 = *(undefined4 *)(iVar5 + 0x4c);
      uStack_74 = *(undefined4 *)(iVar5 + 0x50);
      uStack_70 = 0;
      cStack_5 = '\x02';
      iStack_1c = iVar5;
      if (*(char *)(iVar5 + 0x55) == '\0') {
        puVar3 = (undefined4 *)FUN_011640a0(auStack_fc);
      }
      else {
        puVar2 = (undefined4 *)FUN_01165df0();
        uStack_bc = *puVar2;
        uStack_b8 = puVar2[1];
        uStack_b4 = puVar2[2];
        uStack_b0 = puVar2[3];
        uStack_ac = puVar2[4];
        uStack_a8 = puVar2[5];
        uStack_a4 = puVar2[6];
        uStack_a0 = puVar2[7];
        uStack_9c = puVar2[8];
        uStack_98 = puVar2[9];
        uStack_94 = puVar2[10];
        uStack_90 = puVar2[0xb];
        puVar3 = &uStack_bc;
        uStack_8c = puVar2[0xc];
        uStack_88 = puVar2[0xd];
        uStack_84 = puVar2[0xe];
        uStack_80 = puVar2[0xf];
      }
      uStack_6c = *puVar3;
      uStack_68 = puVar3[1];
      uStack_64 = puVar3[2];
      uStack_60 = puVar3[3];
      uStack_5c = puVar3[4];
      uStack_58 = puVar3[5];
      uStack_54 = puVar3[6];
      uStack_50 = puVar3[7];
      uStack_4c = puVar3[8];
      uStack_48 = puVar3[9];
      uStack_44 = puVar3[10];
      uStack_40 = puVar3[0xb];
      uStack_3c = puVar3[0xc];
      uStack_38 = puVar3[0xd];
      uStack_34 = puVar3[0xe];
      uStack_30 = puVar3[0xf];
      uStack_24 = *(undefined4 *)(iVar5 + 0x44);
      uStack_2c = *(undefined4 *)(*(int *)(iStack_c + 4) + 0x174);
      uStack_28 = 0;
      uStack_20 = 0;
      (**(code **)(*param_2 + 0x30))(1,&uStack_7c,0x50);
      param_5[2] = param_5[2] + 0x50;
      uStack_18 = 0;
      if (*(int *)(iVar5 + 0xc) != 0) {
        do {
          piVar4 = (int *)((*(int *)(iVar5 + 8) + uStack_18) * 0x40 +
                          *(int *)(*(int *)(iStack_c + 4) + 0x44));
          iVar5 = *piVar4;
          if (((iVar5 != iStack_10) || (cVar1 != *(char *)((int)piVar4 + 0x1d))) || (uStack_18 == 0)
             ) {
            cVar1 = *(char *)((int)piVar4 + 0x1d);
            iStack_10 = iVar5;
            if (cStack_5 != *(char *)((int)piVar4 + 0x1e)) {
              uStack_28 = 0x3f800000;
              if (*(char *)((int)piVar4 + 0x1e) != '\x01') {
                uStack_28 = 0;
              }
              (**(code **)(*param_2 + 0x30))(2,&uStack_2c,0x10);
              param_5[2] = param_5[2] + 0x10;
              cStack_5 = *(char *)((int)piVar4 + 0x1e);
            }
            if (*(char *)((int)piVar4 + 0x1d) == '\0') {
              if (iVar5 == 0) {
                iVar5 = *piStack_14;
              }
              puVar6 = &DAT_01d61e7c;
            }
            else {
              if (iVar5 == 0) {
                iVar5 = *piStack_14;
              }
              puVar6 = &DAT_01d61e88;
            }
            (**(code **)(*param_2 + 0x34))(0,iVar5,puVar6);
          }
          (**(code **)(*param_2 + 0x30))(3,piVar4 + 8,0x20);
          param_5[2] = param_5[2] + 0x20;
          (**(code **)(*param_2 + 0x40))
                    (*(undefined4 *)(*(int *)(iStack_c + 4) + 0x11c),piVar4[2],piVar4[4],piVar4[3],
                     piVar4[5],0);
          *param_5 = *param_5 + 1;
          param_5[1] = param_5[1] + piVar4[5];
          uStack_18 = uStack_18 + 1;
          iVar5 = iStack_1c;
        } while (uStack_18 < *(uint *)(iStack_1c + 0xc));
      }
      param_3 = param_3 + 6;
      param_4 = param_4 + -1;
    } while (param_4 != 0);
  }
  return;
}



/* FUNCTION 12253 ; VA 0x007fa660 ; FUN_007fa660 */

void __fastcall FUN_007fa660(int param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  
  iVar1 = 5;
  *(undefined *)(param_1 + 6) = 1;
  puVar2 = (undefined4 *)(param_1 + 8);
  do {
    FUN_007f6c50(*puVar2,puVar2[1],puVar2);
    puVar2[1] = *puVar2;
    puVar2 = puVar2 + 3;
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  for (puVar2 = (undefined4 *)(param_1 + 0x80); puVar2 != (undefined4 *)(param_1 + 0x104);
      puVar2 = puVar2 + 3) {
    puVar2[1] = *puVar2;
  }
  puVar2 = (undefined4 *)(param_1 + 0x44);
  FUN_007f6c50(*puVar2,*(undefined4 *)(param_1 + 0x48),puVar2);
  *(undefined4 *)(param_1 + 0x48) = *puVar2;
  puVar2 = *(undefined4 **)(param_1 + 0x54);
  puVar3 = *(undefined4 **)(param_1 + 0x50);
  if (puVar3 != puVar2) {
    do {
      (**(code **)*puVar3)(0);
      puVar3 = puVar3 + 0x1e;
    } while (puVar3 != puVar2);
    puVar3 = *(undefined4 **)(param_1 + 0x50);
  }
  *(undefined4 **)(param_1 + 0x54) = puVar3;
  *(undefined4 *)(param_1 + 0x78) = *(undefined4 *)(param_1 + 0x74);
  *(undefined4 *)(param_1 + 0x6c) = *(undefined4 *)(param_1 + 0x68);
  *(undefined4 *)(param_1 + 100) = 0;
  return;
}



/* FUNCTION 12254 ; VA 0x007fa700 ; FUN_007fa700 */

uint __thiscall
FUN_007fa700(int *param_1,int *param_2,int param_3,undefined4 param_4,int *param_5,int param_6)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  char cVar4;
  uint uVar5;
  char *pcVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined4 *****pppppuVar9;
  char *pcVar10;
  undefined4 *puVar11;
  int *piVar12;
  undefined *puVar13;
  undefined4 auStack_3e0 [212];
  undefined4 ****appppuStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  int aiStack_78 [5];
  int *piStack_64;
  undefined4 ****appppuStack_60 [4];
  uint uStack_50;
  uint uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined uStack_40;
  undefined4 ****ppppuStack_3c;
  undefined4 uStack_38;
  undefined4 ****ppppuStack_34;
  uint uStack_30;
  int iStack_2c;
  uint uStack_28;
  int iStack_24;
  int iStack_20;
  char cStack_1c;
  undefined uStack_1b;
  undefined uStack_1a;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b489b;
  pvStack_10 = ExceptionList;
  uVar5 = param_1[param_3 * 3 + 3] - param_1[param_3 * 3 + 2];
  if ((0x3f < uVar5) &&
     ((param_3 != 2 ||
      (uVar5 = param_1[param_6 * 3 + 0x21] - param_1[param_6 * 3 + 0x20], 3 < uVar5)))) {
    if ((param_3 == 0) || (param_3 == 4)) {
      cStack_11 = '\x01';
    }
    else {
      cStack_11 = '\0';
    }
    uStack_80 = 0;
    pcVar10 = "UIFogVS";
    uStack_7c = 0xf;
    if (cStack_11 == '\0') {
      pcVar10 = "UIVS";
    }
    appppuStack_90[0] = (undefined4 ****)((uint)appppuStack_90[0] & 0xffffff00);
    pcVar6 = pcVar10;
    do {
      cVar4 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar4 != '\0');
    ExceptionList = &pvStack_10;
    piStack_18 = param_1;
    FUN_005542c0(pcVar10,(int)pcVar6 - (int)(pcVar10 + 1));
    pcVar10 = "UIFogFS";
    uStack_8 = 0;
    if (cStack_11 == '\0') {
      pcVar10 = "UIFS";
    }
    uStack_50 = 0;
    uStack_4c = 0xf;
    appppuStack_60[0] = (undefined4 ****)((uint)appppuStack_60[0] & 0xffffff00);
    pcVar6 = pcVar10;
    do {
      cVar4 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar4 != '\0');
    FUN_005542c0(pcVar10,(int)pcVar6 - (int)(pcVar10 + 1));
    uStack_8._0_1_ = 1;
    if ((*(char *)(*(int *)(*param_1 + 0x4f8) + 0x490) != '\0') && (param_3 == 1)) {
      FUN_005542c0("UIFSMdr",7);
    }
    ppppuStack_34 = appppuStack_60;
    if (0xf < uStack_4c) {
      ppppuStack_34 = appppuStack_60[0];
    }
    ppppuStack_3c = appppuStack_90;
    if (0xf < uStack_7c) {
      ppppuStack_3c = appppuStack_90[0];
    }
    uStack_38 = uStack_80;
    uStack_30 = uStack_50;
    uVar5 = FUN_00790e00(aiStack_78 + 4,&ppppuStack_3c,2);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (aiStack_78[4] != 0) {
      puVar11 = (undefined4 *)(*(int *)(*param_1 + 0x4f8) + 0x54);
      puVar8 = auStack_3e0;
      for (iVar7 = 0xd4; iVar7 != 0; iVar7 = iVar7 + -1) {
        *puVar8 = *puVar11;
        puVar11 = puVar11 + 1;
        puVar8 = puVar8 + 1;
      }
      FUN_007ce460(param_4);
      (**(code **)(*param_2 + 0x30))(0,auStack_3e0,0x350);
      (**(code **)(*param_2 + 0x24))(aiStack_78[4]);
      cStack_1c = cStack_11 << 2;
      uStack_1b = param_3 == 4;
      uStack_44 = 0x60403;
      uStack_48 = 0xf;
      uStack_40 = 0;
      uStack_1a = 0;
      uStack_38 = CONCAT22(uStack_38._2_2_,1);
      ppppuStack_34 = (undefined4 *****)0x0;
      uStack_30 = uStack_30 & 0xffffff00;
      (**(code **)(*param_2 + 0x3c))(&uStack_38,&uStack_48,&cStack_1c);
      puVar11 = *(undefined4 **)(*(int *)(*(int *)(*piStack_18 + 0x4f8) + 0x44c) + 0x84);
      puVar8 = (undefined4 *)&DAT_01eb1b04;
      if (puVar11 != (undefined4 *)0x0) {
        puVar8 = puVar11;
      }
      (**(code **)(*param_2 + 0x34))(0xf,*puVar8,&DAT_01d61e94);
      iStack_20 = 0;
      cVar4 = '\0';
      param_5[3] = param_5[3] + 1;
      param_5[2] = param_5[2] + 0x350;
      aiStack_78[0] = piStack_18[0x5d];
      param_2._3_1_ = '\x02';
      aiStack_78[1] = 0;
      aiStack_78[2] = 0;
      aiStack_78[3] = 0;
      if (param_3 == 2) {
        iStack_2c = piStack_18[param_6 * 3 + 0x21] - piStack_18[param_6 * 3 + 0x20] >> 2;
        iVar7 = param_6;
      }
      else {
        iStack_2c = piStack_18[param_3 * 3 + 3] - piStack_18[param_3 * 3 + 2] >> 6;
        iVar7 = param_3;
      }
      uVar5 = iVar7 * 3;
      iStack_24 = 0;
      if (0 < iStack_2c) {
        uStack_28 = 0;
        do {
          if (param_3 == 2) {
            piVar12 = *(int **)(piStack_18[param_6 * 3 + 0x20] + iStack_24 * 4);
          }
          else {
            piVar12 = (int *)(piStack_18[param_3 * 3 + 2] + uStack_28);
          }
          iVar7 = *piVar12;
          if (((iVar7 != iStack_20) || (cVar4 != *(char *)((int)piVar12 + 0x1d))) ||
             (iStack_24 == 0)) {
            cVar4 = *(char *)((int)piVar12 + 0x1d);
            iStack_20 = iVar7;
            if (param_2._3_1_ != *(char *)((int)piVar12 + 0x1e)) {
              aiStack_78[1] = 0x3f800000;
              if (*(char *)((int)piVar12 + 0x1e) != '\x01') {
                aiStack_78[1] = 0;
              }
              (**(code **)(*piVar2 + 0x30))(2,aiStack_78,0x10);
              param_5[2] = param_5[2] + 0x10;
              param_2._3_1_ = *(char *)((int)piVar12 + 0x1e);
            }
            if (*(char *)((int)piVar12 + 0x1d) == '\0') {
              if (iVar7 == 0) {
                iVar7 = piStack_18[0x5b];
              }
              puVar13 = &DAT_01d61e94;
            }
            else {
              if (iVar7 == 0) {
                iVar7 = piStack_18[0x5b];
              }
              puVar13 = &DAT_01d61ea0;
            }
            (**(code **)(*piVar2 + 0x34))(0,iVar7,puVar13);
          }
          (**(code **)(*piVar2 + 0x30))(3,piVar12 + 8,0x20);
          param_5[2] = param_5[2] + 0x20;
          (**(code **)(*piVar2 + 0x40))
                    (piStack_18[0x47],piVar12[2],piVar12[4],piVar12[3],piVar12[5],0);
          *param_5 = *param_5 + 1;
          param_5[1] = param_5[1] + piVar12[5];
          iStack_24 = iStack_24 + 1;
          uVar5 = uStack_28 + 0x40;
          uStack_28 = uVar5;
        } while (iStack_24 < iStack_2c);
      }
    }
    if (piStack_64 != (int *)0x0) {
      LOCK();
      puVar1 = (uint *)(piStack_64 + 1);
      uVar3 = *puVar1;
      uVar5 = *puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        uVar5 = (**(code **)*piStack_64)();
        LOCK();
        piVar2 = piStack_64 + 2;
        iVar7 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          uVar5 = (**(code **)(*piStack_64 + 4))();
        }
      }
    }
    if (0xf < uStack_4c) {
      uVar5 = uStack_4c + 1;
      pppppuVar9 = (undefined4 *****)appppuStack_60[0];
      if (0xfff < uVar5) {
        pppppuVar9 = (undefined4 *****)appppuStack_60[0][-1];
        uVar5 = uStack_4c + 0x24;
        if (0x1f < (uint)((int)appppuStack_60[0] + (-4 - (int)pppppuVar9))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uVar5 = FUN_01674ea0(pppppuVar9,uVar5);
    }
    uStack_50 = 0;
    uStack_4c = 0xf;
    appppuStack_60[0] = (undefined4 ****)((uint)appppuStack_60[0] & 0xffffff00);
    if (0xf < uStack_7c) {
      uVar5 = uStack_7c + 1;
      pppppuVar9 = (undefined4 *****)appppuStack_90[0];
      if (0xfff < uVar5) {
        pppppuVar9 = (undefined4 *****)appppuStack_90[0][-1];
        uVar5 = uStack_7c + 0x24;
        if (0x1f < (uint)((int)appppuStack_90[0] + (-4 - (int)pppppuVar9))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uVar5 = FUN_01674ea0(pppppuVar9,uVar5);
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 12255 ; VA 0x007fab80 ; FUN_007fab80 */

void __thiscall FUN_007fab80(int *param_1,int param_2)

{
  int iVar1;
  float *pfVar2;
  undefined4 *puVar3;
  bool bVar4;
  char cVar5;
  int *piVar6;
  undefined4 uVar7;
  uint uVar8;
  int iVar9;
  int *piVar10;
  float10 fVar11;
  undefined8 uVar12;
  undefined8 uVar13;
  int *piStack_58;
  int iStack_54;
  int *piStack_50;
  int *piStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b48d8;
  pvStack_10 = ExceptionList;
  piStack_30 = *(int **)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  piStack_28 = param_1;
  if ((*(int *)((int)piStack_30 + 0x34) < DAT_01eb3628) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb3628), DAT_01eb3628 == -1)) {
    uStack_8 = 0;
    uVar12 = FUN_0152dab0("Render","VertexStreamer::renderPrepare",0xffffffff);
    DAT_01eb3624 = (undefined4)((ulonglong)uVar12 >> 0x20);
    DAT_01eb3620 = (undefined4)uVar12;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb3628);
  }
  uStack_40 = DAT_01eb3620;
  uStack_3c = DAT_01eb3624;
  uVar12 = FUN_0152d930(DAT_01eb3620,DAT_01eb3624);
  *(undefined *)((int)param_1 + 6) = 0;
  piVar10 = (int *)&DAT_00000020;
  uStack_8 = 1;
  piVar6 = (int *)((param_1[0x1e] - param_1[0x1d]) / 0x18);
  piStack_18 = (int *)&DAT_00000020;
  if (&DAT_00000020 < piVar6) {
    do {
      piVar10 = (int *)((int)piVar10 + ((uint)piVar10 >> 1));
    } while (piVar10 < piVar6);
    param_1 = piStack_28;
    piStack_18 = piVar10;
    if ((int *)0x80000 < piVar10) {
      piStack_18 = (int *)0x80000;
    }
  }
  piVar6 = (int *)&DAT_00000020;
  piVar10 = (int *)(param_1[0x1b] - param_1[0x1a] >> 1);
  piStack_24 = (int *)&DAT_00000020;
  if (&DAT_00000020 < piVar10) {
    do {
      piVar6 = (int *)((int)piVar6 * 2);
    } while (piVar6 < piVar10);
    piStack_24 = piVar6;
    if ((int *)0x80000 < piVar6) {
      piStack_24 = (int *)0x80000;
    }
  }
  piStack_2c = param_1 + 0x43;
  if ((*piStack_2c != 0) && (*(uint *)(*piStack_2c + 0x2c) < (uint)((int)piStack_18 * 0x18))) {
    uStack_38 = 0;
    piStack_34 = (int *)0x0;
    FUN_005587e0(&uStack_38);
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_34[1] + -1;
      piStack_34[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        iVar9 = piStack_34[2] + -1;
        piStack_34[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_34 + 4))();
        }
      }
    }
  }
  piStack_34 = param_1 + 0x41;
  if ((param_1[0x41] != 0) && (*(uint *)(param_1[0x41] + 0x2c) < (uint)((int)piStack_24 * 2))) {
    uStack_20 = 0;
    piStack_1c = (int *)0x0;
    FUN_005587e0(&uStack_20);
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar9 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar9 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  if ((param_1[0x43] == 0) || (param_1[0x41] == 0)) {
    piStack_1c = *(int **)(*param_1 + 0x3c);
    if (param_1[0x43] == 0) {
      piVar6 = (int *)(**(code **)(*piStack_1c + 0x3c))(&uStack_48,0,(int)piStack_18 * 0x18,0x18,1);
      iVar9 = *piVar6;
      iVar1 = piVar6[1];
      *piVar6 = 0;
      piVar6[1] = 0;
      param_1[0x43] = iVar9;
      piStack_18 = (int *)param_1[0x44];
      param_1[0x44] = iVar1;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar9 = piStack_18[1] + -1;
        piStack_18[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          iVar9 = piStack_18[2] + -1;
          piStack_18[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
      piStack_18 = uStack_48._4_4_;
      if (uStack_48._4_4_ != (int *)0x0) {
        LOCK();
        iVar9 = uStack_48._4_4_[1] + -1;
        uStack_48._4_4_[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*uStack_48._4_4_)();
          LOCK();
          iVar9 = piStack_18[2] + -1;
          piStack_18[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
    if (param_1[0x41] == 0) {
      piVar6 = (int *)(**(code **)(*piStack_1c + 0x3c))(&uStack_48,1,(int)piStack_24 * 2,2,1);
      iVar9 = *piVar6;
      iVar1 = piVar6[1];
      *piVar6 = 0;
      piVar6[1] = 0;
      param_1[0x41] = iVar9;
      piStack_24 = (int *)param_1[0x42];
      param_1[0x42] = iVar1;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar9 = piStack_24[1] + -1;
        piStack_24[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          iVar9 = piStack_24[2] + -1;
          piStack_24[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piStack_24 + 4))();
          }
        }
      }
      piStack_24 = uStack_48._4_4_;
      if (uStack_48._4_4_ != (int *)0x0) {
        LOCK();
        iVar9 = uStack_48._4_4_[1] + -1;
        uStack_48._4_4_[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*uStack_48._4_4_)();
          LOCK();
          iVar9 = piStack_24[2] + -1;
          piStack_24[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piStack_24 + 4))();
          }
        }
      }
    }
    piVar6 = (int *)FUN_0147c0e0(&uStack_48,param_1 + 0x45,param_1 + 0x43,param_1 + 0x41);
    iVar9 = *piVar6;
    iVar1 = piVar6[1];
    *piVar6 = 0;
    piVar6[1] = 0;
    param_1[0x47] = iVar9;
    piStack_24 = (int *)param_1[0x48];
    param_1[0x48] = iVar1;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_24[1] + -1;
      piStack_24[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar9 = piStack_24[2] + -1;
        piStack_24[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    piStack_24 = uStack_48._4_4_;
    if (uStack_48._4_4_ != (int *)0x0) {
      LOCK();
      iVar9 = uStack_48._4_4_[1] + -1;
      uStack_48._4_4_[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*uStack_48._4_4_)();
        LOCK();
        piVar6 = piStack_24 + 2;
        iVar9 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar9 == 1) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
  }
  iVar9 = param_1[0x1e] - param_1[0x1d] >> 0x1f;
  if ((param_1[0x1e] - param_1[0x1d]) / 0x18 + iVar9 != iVar9) {
    if ((*(int *)((int)piStack_30 + 0x34) < DAT_01eb3638) &&
       (FUN_016f3809(&DAT_01eb3638), DAT_01eb3638 == -1)) {
      uStack_8._0_1_ = 2;
      uVar13 = FUN_0152dab0("Render","upload",0xffffffff);
      DAT_01eb3634 = (int *)((ulonglong)uVar13 >> 0x20);
      DAT_01eb3630 = (int *)uVar13;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb3638);
    }
    piStack_1c = DAT_01eb3630;
    piStack_50 = DAT_01eb3630;
    piStack_24 = DAT_01eb3634;
    piStack_4c = DAT_01eb3634;
    uStack_48 = FUN_0152d930(DAT_01eb3630,DAT_01eb3634);
    uStack_8._0_1_ = 3;
    uVar7 = (**(code **)(*(int *)*piStack_2c + 0x10))();
    uVar8 = (piStack_28[0x1e] - piStack_28[0x1d]) / 0x18;
    piStack_30 = (int *)0x80000;
    if (0x80000 < uVar8) {
      uVar8 = 0x80000;
    }
    FUN_0170c6f0(uVar7,piStack_28[0x1d],uVar8 * 0x18);
    (**(code **)(*(int *)*piStack_2c + 0x14))();
    piVar6 = piStack_34;
    uVar7 = (**(code **)(*(int *)*piStack_34 + 0x10))();
    param_1 = piStack_28;
    piVar10 = (int *)(piStack_28[0x1b] - piStack_28[0x1a] >> 1);
    if (0x80000 < piVar10) {
      piVar10 = piStack_30;
    }
    FUN_0170c6f0(uVar7,piStack_28[0x1a],(int)piVar10 * 2);
    (**(code **)(*(int *)*piVar6 + 0x14))();
    uStack_8._0_1_ = 4;
    FUN_0152dda0(piStack_1c,piStack_24,(undefined4)uStack_48,uStack_48._4_4_);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
  }
  piStack_30 = (int *)param_1[9];
  piVar6 = (int *)param_1[8];
  if (((int)piStack_30 - (int)piVar6 >> 6 != 0) && (piVar6 != piStack_30)) {
    do {
      iVar9 = piVar6[6] * 3;
      pfVar2 = (float *)param_1[iVar9 + 0x21];
      piStack_34 = piVar6;
      if ((float *)param_1[iVar9 + 0x22] == pfVar2) {
        FUN_006030d0(pfVar2,&piStack_34);
      }
      else {
        *pfVar2 = (float)piVar6;
        param_1[iVar9 + 0x21] = param_1[iVar9 + 0x21] + 4;
      }
      piVar6 = piVar6 + 0x10;
    } while (piVar6 != piStack_30);
  }
  if (param_2 != 0) {
    piVar6 = (int *)param_1[0x15];
    piVar10 = (int *)param_1[0x14];
    iVar9 = (int)piVar6 - (int)piVar10 >> 0x1f;
    piStack_28 = piVar6;
    if ((((int)piVar6 - (int)piVar10) / 0x78 + iVar9 != iVar9) && (piVar10 != piVar6)) {
      do {
        if (piVar10[3] != 0) {
          if (*(char *)((int)piVar10 + 0x55) == '\0') {
            piStack_30 = (int *)((float)piVar10[0x10] * (float)piVar10[0x10]);
            piStack_2c = *(int **)(*param_1 + 0x4fc);
            fVar11 = (float10)FUN_01156fe0(*(undefined4 *)(*param_1 + 0x5c4));
            piStack_34 = (int *)(float)fVar11;
            if ((float)piStack_34 <= (float)piStack_30) {
LAB_007fb140:
              cStack_11 = '\0';
            }
            else {
              cVar5 = FUN_0078b7c0();
              cStack_11 = '\x01';
              if (cVar5 == '\0') goto LAB_007fb140;
            }
            piStack_30 = (int *)((float)piVar10[0x10] * (float)piVar10[0x10]);
            fVar11 = (float10)FUN_01156fe0(*(undefined4 *)(*param_1 + 0x5c4));
            piStack_34 = (int *)(float)fVar11;
            if (((float)piStack_34 <= (float)piStack_30) || (cVar5 = FUN_0078bd20(), cVar5 == '\0'))
            {
              bVar4 = false;
            }
            else {
              bVar4 = true;
            }
            if (*(char *)(piVar10 + 0x15) == '\0') {
              if (bVar4) {
                if (cStack_11 == '\0') {
                  iStack_54 = param_1[0x57];
                }
                else {
                  iStack_54 = param_1[0x59];
                }
              }
              else {
                iStack_54 = param_1[0x49];
              }
            }
            else {
              if (*(char *)((int)piVar10 + 0x57) == '\0') {
                iStack_54 = param_1[0x4f];
              }
              else {
                iStack_54 = param_1[0x4d];
              }
              if ((DAT_01d61e74 == '\0') && (DAT_018ce2f0 < (float)piVar10[0x11])) {
                iStack_54 = param_1[0x4b];
              }
            }
            iVar9 = 9;
            if (*(char *)(piVar10 + 0x15) != '\0') {
              iVar9 = 0xc;
            }
          }
          else {
            if ((*(char *)((int)piVar10 + 0x56) == '\0') &&
               (*(char *)(*(int *)(*param_1 + 0x4f8) + 0x490) != '\0')) {
              bVar4 = true;
            }
            else {
              bVar4 = false;
            }
            if (*(char *)((int)piVar10 + 0x57) == '\0') {
              iStack_54 = param_1[0x51];
            }
            else {
              iStack_54 = param_1[0x53];
            }
            if (bVar4) {
              iStack_54 = param_1[0x55];
            }
            iVar9 = (*(char *)((int)piVar10 + 0x56) != '\0') + 0xd;
          }
          piStack_4c = (int *)piVar10[0x10];
          iVar9 = param_2 + iVar9 * 0xc;
          puVar3 = *(undefined4 **)(iVar9 + 4);
          piStack_50 = (int *)0x0;
          uStack_48 = 0;
          piStack_58 = piVar10;
          if (*(undefined4 **)(iVar9 + 8) == puVar3) {
            FUN_006c6730(puVar3,&piStack_58);
            piVar6 = piStack_28;
          }
          else {
            *puVar3 = piVar10;
            puVar3[1] = iStack_54;
            puVar3[2] = 0;
            puVar3[3] = piStack_4c;
            *(undefined8 *)(puVar3 + 4) = 0;
            *(int *)(iVar9 + 4) = *(int *)(iVar9 + 4) + 0x18;
            piVar6 = piStack_28;
          }
        }
        piVar10 = piVar10 + 0x1e;
      } while (piVar10 != piVar6);
    }
  }
  param_1[0x5d] =
       (int)((*(float *)(*param_1 + 200) / (DAT_018ce2f8 - *(float *)(*param_1 + 0xc4))) *
            DAT_01900e74);
  uStack_8 = 5;
  FUN_0152dda0(uStack_40,uStack_3c,uVar12);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12256 ; VA 0x007fb350 ; FUN_007fb350 */

float * FUN_007fb350(float *param_1,float *param_2,int param_3,int param_4,int param_5,uint param_6,
                    float *param_7,uint param_8,uint param_9)

{
  int *piVar1;
  float fVar2;
  undefined8 *puVar3;
  int *piVar4;
  ushort uVar5;
  uint uVar6;
  float *pfVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  bool bVar12;
  float fVar13;
  float fVar14;
  float fStack_2c;
  int *piStack_28;
  float fStack_24;
  float fStack_20;
  int *piStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b4922;
  pvStack_10 = ExceptionList;
  if (DAT_01d6d140 == '\0') {
    iVar8 = ((uint)param_7 & 0xff) << 2;
    fStack_20 = 0.0;
    piStack_1c = (int *)0x0;
    uVar6 = 0xffffffff;
    bVar12 = false;
    uVar10 = 2;
    uStack_8 = 1;
    pfVar7 = &fStack_20;
  }
  else {
    if ((char)param_9 == '\0') {
      iVar8 = 0;
      if ((char)param_7 != '\0') {
        iVar8 = 4;
      }
    }
    else {
      iVar8 = 2;
    }
    fStack_2c = 0.0;
    piStack_28 = (int *)0x0;
    bVar12 = param_8 != 0;
    uVar10 = 1;
    uVar6 = param_9 & 0xff;
    uStack_8 = 0;
    pfVar7 = &fStack_2c;
  }
  ExceptionList = &pvStack_10;
  uStack_14 = uVar10;
  param_7 = (float *)FUN_007f9a80(pfVar7,0,param_6,param_4,iVar8,0,bVar12,uVar6,0,0);
  piVar4 = piStack_1c;
  pfVar7 = param_7;
  if (((uVar10 & 2) != 0) && (uVar10 = uVar10 & 0xfffffffd, piStack_1c != (int *)0x0)) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar8 = *piVar1;
    pfVar7 = (float *)*piVar1;
    *piVar1 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar8 = *piVar1;
      pfVar7 = (float *)*piVar1;
      *piVar1 = iVar8 + -1;
      UNLOCK();
      if (iVar8 + -1 == 0) {
        pfVar7 = (float *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_28;
  uStack_8 = 0xffffffff;
  if (((uVar10 & 1) != 0) && (piStack_28 != (int *)0x0)) {
    LOCK();
    piVar1 = piStack_28 + 1;
    iVar8 = *piVar1;
    pfVar7 = (float *)*piVar1;
    *piVar1 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      pfVar7 = (float *)(**(code **)*piStack_28)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar8 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        pfVar7 = (float *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  uVar6 = param_6;
  if (param_7 != (float *)0x0) {
    fVar2 = 0.0;
    if (0.0 <= *param_1) {
      fVar2 = *param_1;
    }
    fVar13 = DAT_018ce2f8;
    if (fVar2 <= DAT_018ce2f8) {
      fVar13 = fVar2;
    }
    fVar2 = 0.0;
    if (0.0 <= param_1[1]) {
      fVar2 = param_1[1];
    }
    uVar10 = (uint)(fVar13 * DAT_018f9000 + DAT_018ce2f4);
    fVar13 = DAT_018ce2f8;
    if (fVar2 <= DAT_018ce2f8) {
      fVar13 = fVar2;
    }
    fVar2 = 0.0;
    if (0.0 <= param_1[2]) {
      fVar2 = param_1[2];
    }
    uVar9 = (uint)(fVar13 * DAT_018f9000 + DAT_018ce2f4);
    fVar13 = DAT_018ce2f8;
    if (fVar2 <= DAT_018ce2f8) {
      fVar13 = fVar2;
    }
    fVar2 = 0.0;
    if (0.0 <= param_1[3]) {
      fVar2 = param_1[3];
    }
    fVar14 = DAT_018ce2f8;
    if (fVar2 <= DAT_018ce2f8) {
      fVar14 = fVar2;
    }
    param_9 = (uint)(fVar13 * DAT_018f9000 + DAT_018ce2f4);
    uVar11 = (int)(fVar14 * DAT_018f9000 + DAT_018ce2f4) << 8;
    if (*(char *)(iStack_18 + 4) == '\0') {
      param_9 = ((uVar11 | param_9) << 8 | uVar9) << 8 | uVar10;
    }
    else {
      param_9 = ((uVar11 | uVar10) << 8 | uVar9) << 8 | param_9;
    }
    iVar8 = (*(int *)(iStack_18 + 0x78) - *(int *)(iStack_18 + 0x74)) / 0x18;
    uVar5 = (short)iVar8 - *(short *)(param_7 + 3);
    pfVar7 = (float *)CONCAT22((short)((uint)iVar8 >> 0x10),uVar5);
    iVar8 = 0;
    param_8 = (uint)uVar5;
    uVar10 = param_9;
    param_7 = (float *)param_9;
    if (0 < (int)param_6) {
      do {
        uVar5 = *(short *)(param_5 + iVar8 * 2) + (short)param_8;
        param_6 = (uint)uVar5;
        pfVar7 = *(float **)(iStack_18 + 0x6c);
        if (*(float **)(iStack_18 + 0x70) == pfVar7) {
          pfVar7 = (float *)FUN_00725750(pfVar7,&param_6);
        }
        else {
          *(ushort *)pfVar7 = uVar5;
          *(int *)(iStack_18 + 0x6c) = *(int *)(iStack_18 + 0x6c) + 2;
        }
        iVar8 = iVar8 + 1;
        uVar10 = (uint)param_7;
      } while (iVar8 < (int)uVar6);
    }
    if (0 < param_4) {
      pfVar7 = (float *)(param_3 + 8);
      do {
        fVar2 = pfVar7[-1];
        fVar13 = pfVar7[-2];
        fVar14 = *pfVar7;
        puVar3 = *(undefined8 **)(iStack_18 + 0x78);
        fStack_2c = 0.0;
        piStack_28 = (int *)0x0;
        fStack_24 = fVar13 * *param_2 + fVar2 * param_2[1] + fVar14 * param_2[2] + param_2[9];
        fStack_20 = fVar13 * param_2[3] + fVar2 * param_2[4] + param_2[5] * fVar14 + param_2[10];
        piStack_1c = (int *)(param_2[6] * fVar13 + param_2[7] * fVar2 + fVar14 * param_2[8] +
                            param_2[0xb]);
        param_7 = pfVar7;
        if (*(undefined8 **)(iStack_18 + 0x7c) == puVar3) {
          FUN_007f6fa0(puVar3,&fStack_24,&param_9,&fStack_2c);
          uVar10 = param_9;
        }
        else {
          *puVar3 = CONCAT44(fStack_20,fStack_24);
          *(int **)(puVar3 + 1) = piStack_1c;
          *(uint *)((int)puVar3 + 0xc) = uVar10;
          *(undefined4 *)(puVar3 + 2) = 0;
          *(undefined4 *)((int)puVar3 + 0x14) = 0;
          *(int *)(iStack_18 + 0x78) = *(int *)(iStack_18 + 0x78) + 0x18;
        }
        pfVar7 = param_7 + 3;
        param_4 = param_4 + -1;
      } while (param_4 != 0);
    }
  }
  ExceptionList = pvStack_10;
  return pfVar7;
}



/* FUNCTION 12257 ; VA 0x007fb6d0 ; FUN_007fb6d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_007fb6d0(int *param_1,undefined4 param_2,float *param_3,float *param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7)

{
  float *pfVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined2 *puVar4;
  float fVar5;
  undefined8 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  int *piVar11;
  int *piVar12;
  ushort uVar13;
  int iVar14;
  uint uVar15;
  uint uVar16;
  char cVar17;
  int *piVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  float fVar24;
  float fVar25;
  float fStack_7c;
  float fStack_78;
  float fStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  float fStack_48;
  float fStack_44;
  int iStack_40;
  int *piStack_3c;
  float fStack_38;
  int *piStack_34;
  float *pfStack_30;
  undefined8 *puStack_2c;
  int *piStack_28;
  float *pfStack_24;
  float fStack_20;
  uint uStack_1c;
  int *piStack_18;
  char cStack_12;
  undefined uStack_11;
  
  puStack_2c = (undefined8 *)
               ((((int)param_4[5] - (int)param_4[4]) / 0xc +
                (((int)param_4[8] - (int)param_4[7]) / 0xc) * -2) * 3);
  if (puStack_2c == (undefined8 *)0x0) {
    return;
  }
  iVar14 = param_1[0x15];
  pfStack_30 = (float *)*param_4;
  fStack_38 = (float)(param_1[0x12] - param_1[0x11] >> 6);
  uStack_11 = pfStack_30 != (float *)0x0;
  piStack_18 = param_1;
  if ((*(char *)(iVar14 + -0x23) == '\0') && (*(char *)(iVar14 + -0x24) == '\0')) {
    cVar17 = '\0';
  }
  else {
    cStack_12 = '\x01';
    cVar17 = '\x01';
    if ((*(char *)(iVar14 + -0x21) != uStack_11) && (*(float *)(iVar14 + -0x70) != fStack_38)) {
      *(int *)(iVar14 + -0x6c) = (int)fStack_38 - *(int *)(iVar14 + -0x70);
      piStack_3c = (int *)0x0;
      piStack_34 = param_1;
      FUN_007f7640(&piStack_34,&fStack_38,&piStack_3c,iVar14 + -0x68,iVar14 + -0x38,iVar14 + -0x34,
                   iVar14 + -0x30,iVar14 + -0x24,iVar14 + -0x23,iVar14 + -0x22);
      iVar14 = param_1[0x15];
      cVar17 = cStack_12;
    }
  }
  uVar10 = _UNK_018e3fcc;
  uVar9 = _UNK_018e3fc8;
  uVar8 = _UNK_018e3fc4;
  uVar7 = _DAT_018e3fc0;
  if (pfStack_30 == (float *)0x0) {
    if (cVar17 != '\0') goto LAB_007fb8c2;
    *(undefined4 *)(iVar14 + -0x20) = 0;
    *(undefined4 *)(iVar14 + -0x1c) = 0;
    *(undefined4 *)(iVar14 + -0x18) = 0;
    *(undefined4 *)(iVar14 + -0x14) = 0;
    *(undefined4 *)(iVar14 + -0x10) = uVar7;
    *(undefined4 *)(iVar14 + -0xc) = uVar8;
    *(undefined4 *)(iVar14 + -8) = uVar9;
    *(undefined4 *)(iVar14 + -4) = uVar10;
  }
  else {
    if ((*(char *)(iVar14 + -0x24) != '\0') ||
       (piStack_28 = (int *)DAT_018ce2f8, *(char *)(iVar14 + -0x23) != '\0')) {
      piStack_28 = (int *)*(float *)(*piStack_18 + 0x594);
    }
    pfVar1 = (float *)*param_4;
    piStack_3c = (int *)*pfVar1;
    fStack_38 = pfVar1[1];
    piStack_34 = (int *)pfVar1[2];
    pfStack_30 = (float *)pfVar1[3];
    fStack_44 = pfVar1[5] * (float)piStack_28;
    fStack_48 = pfVar1[4] * (float)piStack_28;
    FUN_01165780(&fStack_48,pfVar1[6] * (float)piStack_28,0);
    fStack_7c = fStack_38 * (float)piStack_28;
    fStack_78 = (float)piStack_34 * (float)piStack_28;
    fStack_74 = (float)pfStack_30 * (float)piStack_28;
    *(float *)(iVar14 + -0x20) = (float)piStack_3c * (float)piStack_28;
    *(float *)(iVar14 + -0x1c) = fStack_7c;
    *(float *)(iVar14 + -0x18) = fStack_78;
    *(float *)(iVar14 + -0x14) = fStack_74;
    *(undefined4 *)(iVar14 + -0x10) = uStack_70;
    *(undefined4 *)(iVar14 + -0xc) = uStack_6c;
    *(undefined4 *)(iVar14 + -8) = uStack_68;
    *(undefined4 *)(iVar14 + -4) = uStack_64;
  }
  *(undefined *)(iVar14 + -0x21) = 1;
LAB_007fb8c2:
  piVar18 = piStack_18;
  iStack_40 = FUN_007f9a80(param_2,0,puStack_2c,((int)param_4[5] - (int)param_4[4]) / 0xc,
                           piStack_18[0x18],param_5,param_6,0xffffffff,0,param_7);
  if (iStack_40 != 0) {
    fStack_44 = param_4[8];
    fStack_20 = param_4[7];
    if (fStack_20 != fStack_44) {
      piVar18 = piVar18 + 0x1d;
      fVar23 = DAT_018ce2f8;
      fVar24 = DAT_018f9000;
      fVar25 = DAT_018ce2f4;
      piStack_34 = piVar18;
      do {
        puVar2 = (undefined8 *)piVar18[1];
        iVar14 = (int)puVar2 - *piVar18;
        uVar13 = (((short)(iVar14 / 0x18) + (short)(iVar14 >> 0x1f)) -
                 (short)((longlong)iVar14 * 0x2aaaaaab >> 0x3f)) - *(short *)(iStack_40 + 0xc);
        piStack_3c = (int *)(uint)uVar13;
        fStack_38 = (float)(uint)uVar13;
        puVar3 = (undefined8 *)**(undefined4 **)((int)fStack_20 + 8);
        piStack_28 = (int *)(*(undefined4 **)((int)fStack_20 + 8))[2];
        fVar19 = *(float *)((int)puVar3 + 0xc) * param_3[1];
        fVar5 = 0.0;
        if (0.0 <= *(float *)(puVar3 + 1) * *param_3) {
          fVar5 = *(float *)(puVar3 + 1) * *param_3;
        }
        fVar21 = *(float *)((int)puVar3 + 0x14) * param_3[3];
        fVar20 = fVar23;
        if (fVar5 <= fVar23) {
          fVar20 = fVar5;
        }
        fVar5 = 0.0;
        if (0.0 <= fVar19) {
          fVar5 = fVar19;
        }
        puStack_2c = (undefined8 *)(int)(fVar20 * fVar24 + fVar25);
        fVar19 = fVar23;
        if (fVar5 <= fVar23) {
          fVar19 = fVar5;
        }
        fVar5 = 0.0;
        if (0.0 <= *(float *)(puVar3 + 2) * param_3[2]) {
          fVar5 = *(float *)(puVar3 + 2) * param_3[2];
        }
        uVar15 = (uint)(fVar19 * fVar24 + fVar25);
        fVar19 = fVar23;
        if (fVar5 <= fVar23) {
          fVar19 = fVar5;
        }
        fVar5 = 0.0;
        if (0.0 <= fVar21) {
          fVar5 = fVar21;
        }
        pfStack_24 = (float *)(int)(fVar19 * fVar24 + fVar25);
        fVar19 = fVar23;
        if (fVar5 <= fVar23) {
          fVar19 = fVar5;
        }
        uVar16 = (int)(fVar19 * fVar24 + fVar25) << 8;
        if (*(char *)(piStack_18 + 1) == '\0') {
          uStack_1c = ((uVar16 | (uint)pfStack_24) << 8 | uVar15) << 8 | (uint)puStack_2c;
        }
        else {
          uStack_1c = ((uVar16 | (uint)puStack_2c) << 8 | uVar15) << 8 | (uint)pfStack_24;
        }
        uStack_54 = *(undefined4 *)puVar3;
        uStack_50 = *(undefined4 *)((int)puVar3 + 4);
        uStack_4c = 0;
        if ((undefined8 *)piVar18[2] == puVar2) {
          FUN_007f6fa0(puVar2,&uStack_54,&uStack_1c,puVar3 + 3);
          fVar23 = DAT_018ce2f8;
          fVar24 = DAT_018f9000;
          fVar25 = DAT_018ce2f4;
        }
        else {
          *puVar2 = *puVar3;
          *(undefined4 *)(puVar2 + 1) = 0;
          *(uint *)((int)puVar2 + 0xc) = uStack_1c;
          *(undefined4 *)(puVar2 + 2) = *(undefined4 *)(puVar3 + 3);
          *(undefined4 *)((int)puVar2 + 0x14) = *(undefined4 *)((int)puVar3 + 0x1c);
          piVar18[1] = piVar18[1] + 0x18;
        }
        piVar11 = piStack_28;
        puVar2 = (undefined8 *)piVar18[1];
        pfStack_30 = (float *)((int)piStack_3c + 1U & 0xffff);
        iVar14 = *piStack_28;
        fVar19 = *(float *)(iVar14 + 8) * *param_3;
        fVar5 = 0.0;
        if (0.0 <= fVar19) {
          fVar5 = fVar19;
        }
        fVar20 = *(float *)(iVar14 + 0xc) * param_3[1];
        fVar21 = *(float *)(iVar14 + 0x10) * param_3[2];
        fVar19 = fVar23;
        if (fVar5 <= fVar23) {
          fVar19 = fVar5;
        }
        fVar22 = *(float *)(iVar14 + 0x14) * param_3[3];
        fVar5 = 0.0;
        if (0.0 <= fVar20) {
          fVar5 = fVar20;
        }
        uVar15 = (uint)(fVar19 * fVar24 + fVar25);
        fVar19 = fVar23;
        if (fVar5 <= fVar23) {
          fVar19 = fVar5;
        }
        fVar5 = 0.0;
        if (0.0 <= fVar21) {
          fVar5 = fVar21;
        }
        pfStack_24 = (float *)(int)(fVar19 * fVar24 + fVar25);
        fVar19 = fVar23;
        if (fVar5 <= fVar23) {
          fVar19 = fVar5;
        }
        fVar5 = 0.0;
        if (0.0 <= fVar22) {
          fVar5 = fVar22;
        }
        uStack_1c = (uint)(fVar19 * fVar24 + fVar25);
        fVar19 = fVar23;
        if (fVar5 <= fVar23) {
          fVar19 = fVar5;
        }
        uVar16 = (int)(fVar19 * fVar24 + fVar25) << 8;
        if (*(char *)(piStack_18 + 1) == '\0') {
          uStack_1c = ((uVar16 | uStack_1c) << 8 | (uint)pfStack_24) << 8 | uVar15;
        }
        else {
          uStack_1c = ((uVar16 | uVar15) << 8 | (uint)pfStack_24) << 8 | uStack_1c;
        }
        uStack_64 = 0;
        puVar3 = (undefined8 *)*piStack_28;
        uStack_6c = *(undefined4 *)puVar3;
        puStack_2c = puVar3 + 3;
        uStack_68 = *(undefined4 *)((int)puVar3 + 4);
        uVar6 = *puVar3;
        if ((undefined8 *)piStack_34[2] == puVar2) {
          FUN_007f6fa0(puVar2,&uStack_6c,&uStack_1c,puStack_2c);
          fVar23 = DAT_018ce2f8;
          fVar24 = DAT_018f9000;
          fVar25 = DAT_018ce2f4;
        }
        else {
          *(uint *)((int)puVar2 + 0xc) = uStack_1c;
          *puVar2 = uVar6;
          *(undefined4 *)(puVar2 + 1) = 0;
          *(undefined4 *)(puVar2 + 2) = *(undefined4 *)puStack_2c;
          *(undefined4 *)((int)puVar2 + 0x14) = *(undefined4 *)((int)puVar3 + 0x1c);
          piStack_34[1] = piStack_34[1] + 0x18;
        }
        piVar12 = piStack_18;
        piVar18 = piStack_34;
        pfStack_24 = (float *)(((uint)pfStack_30 & 0xffff) + 1 & 0xffff);
        piStack_3c = piVar11 + 2;
        pfVar1 = pfStack_24;
        if (*piStack_3c != *(int *)((int)fStack_20 + 8)) {
          do {
            pfStack_30 = pfVar1;
            puVar4 = (undefined2 *)piVar12[0x1b];
            if ((undefined2 *)piVar12[0x1c] == puVar4) {
              FUN_00725750(puVar4,&fStack_38);
            }
            else {
              *puVar4 = SUB42(fStack_38,0);
              piVar12[0x1b] = piVar12[0x1b] + 2;
            }
            puVar4 = (undefined2 *)piVar12[0x1b];
            uVar15 = (int)pfStack_30 - 1;
            pfStack_30 = (float *)(uVar15 & 0xffff);
            if ((undefined2 *)piVar12[0x1c] == puVar4) {
              FUN_00725750(puVar4,&pfStack_30);
            }
            else {
              *puVar4 = (short)uVar15;
              piVar12[0x1b] = piVar12[0x1b] + 2;
            }
            puVar4 = (undefined2 *)piVar12[0x1b];
            if ((undefined2 *)piVar12[0x1c] == puVar4) {
              FUN_00725750(puVar4,&pfStack_24);
            }
            else {
              *puVar4 = (short)pfStack_24;
              piVar12[0x1b] = piVar12[0x1b] + 2;
            }
            fVar24 = DAT_018f9000;
            fVar23 = DAT_018ce2f8;
            fVar25 = DAT_018ce2f4;
            pfVar1 = (float *)piStack_28[1];
            fVar5 = 0.0;
            if (0.0 <= *param_3 * pfVar1[2]) {
              fVar5 = *param_3 * pfVar1[2];
            }
            fVar19 = DAT_018ce2f8;
            if (fVar5 <= DAT_018ce2f8) {
              fVar19 = fVar5;
            }
            fVar5 = 0.0;
            if (0.0 <= pfVar1[3] * param_3[1]) {
              fVar5 = pfVar1[3] * param_3[1];
            }
            piStack_28 = (int *)(int)(fVar19 * DAT_018f9000 + DAT_018ce2f4);
            fVar19 = DAT_018ce2f8;
            if (fVar5 <= DAT_018ce2f8) {
              fVar19 = fVar5;
            }
            fVar5 = 0.0;
            if (0.0 <= pfVar1[4] * param_3[2]) {
              fVar5 = pfVar1[4] * param_3[2];
            }
            puStack_2c = (undefined8 *)(int)(fVar19 * DAT_018f9000 + DAT_018ce2f4);
            fVar19 = DAT_018ce2f8;
            if (fVar5 <= DAT_018ce2f8) {
              fVar19 = fVar5;
            }
            fVar5 = 0.0;
            if (0.0 <= pfVar1[5] * param_3[3]) {
              fVar5 = pfVar1[5] * param_3[3];
            }
            uStack_1c = (uint)(fVar19 * DAT_018f9000 + DAT_018ce2f4);
            fVar19 = DAT_018ce2f8;
            if (fVar5 <= DAT_018ce2f8) {
              fVar19 = fVar5;
            }
            uVar15 = (int)(fVar19 * DAT_018f9000 + DAT_018ce2f4) << 8;
            if (*(char *)(piStack_18 + 1) == '\0') {
              uStack_1c = ((uVar15 | uStack_1c) << 8 | (uint)puStack_2c) << 8 | (uint)piStack_28;
            }
            else {
              uStack_1c = ((uVar15 | (uint)piStack_28) << 8 | (uint)puStack_2c) << 8 | uStack_1c;
            }
            fStack_7c = *pfVar1;
            pfStack_30 = pfVar1 + 6;
            fStack_78 = pfVar1[1];
            uVar6 = *(undefined8 *)pfVar1;
            puVar2 = (undefined8 *)piVar18[1];
            fStack_74 = 0.0;
            if ((undefined8 *)piVar18[2] == puVar2) {
              FUN_007f6fa0(puVar2,&fStack_7c,&uStack_1c,pfStack_30);
              fVar23 = DAT_018ce2f8;
              fVar24 = DAT_018f9000;
              fVar25 = DAT_018ce2f4;
            }
            else {
              *(uint *)((int)puVar2 + 0xc) = uStack_1c;
              *puVar2 = uVar6;
              *(undefined4 *)(puVar2 + 1) = 0;
              *(float *)(puVar2 + 2) = *pfStack_30;
              *(float *)((int)puVar2 + 0x14) = pfVar1[7];
              piVar18[1] = piVar18[1] + 0x18;
            }
            pfStack_24 = (float *)((int)pfStack_24 + 1);
            pfStack_30 = (float *)((uint)pfStack_24 & 0xffff);
            piStack_28 = (int *)*piStack_3c;
            piStack_3c = piStack_28 + 2;
            pfVar1 = pfStack_30;
          } while (*piStack_3c != *(int *)((int)fStack_20 + 8));
        }
        fStack_20 = (float)((int)fStack_20 + 0xc);
      } while (fStack_20 != fStack_44);
    }
  }
  return;
}



/* FUNCTION 12258 ; VA 0x007fbe60 ; FUN_007fbe60 */

int __thiscall FUN_007fbe60(uint *param_1,uint param_2,undefined4 param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  
  uVar6 = *param_1;
  iVar3 = (int)(param_1[1] - *param_1) / 0x70;
  if (iVar3 == 0x2492492) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar5 = (int)(param_1[2] - *param_1) / 0x70;
  uVar8 = uVar1;
  if ((uVar5 <= 0x2492492 - (uVar5 >> 1)) && (uVar8 = (uVar5 >> 1) + uVar5, uVar8 < uVar1)) {
    uVar8 = uVar1;
  }
  uVar5 = uVar8 * 0x70;
  if (uVar8 < 0x2492493) {
    uVar8 = uVar5;
    if (0xfff < uVar5) goto LAB_007fbefc;
    if (uVar5 == 0) {
      uVar8 = 0;
    }
    else {
      uVar8 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_007fbefc:
    uVar2 = uVar8 + 0x23;
    if (uVar2 <= uVar8) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_007fc004;
    uVar8 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar8 - 4) = iVar3;
  }
  iVar4 = ((int)(param_2 - uVar6) / 0x70) * 0x70;
  iVar3 = iVar4 + uVar8;
  FUN_007fc520(param_1,iVar3,param_3);
  uVar2 = param_1[1];
  uVar6 = *param_1;
  uVar7 = uVar8;
  if (param_2 != uVar2) {
    FUN_007fc450(uVar6,param_2,uVar8,param_1);
    uVar2 = param_1[1];
    uVar6 = param_2;
    uVar7 = iVar3 + 0x70;
  }
  FUN_007fc450(uVar6,uVar2,uVar7,param_1);
  puVar9 = (undefined4 *)*param_1;
  if (puVar9 != (undefined4 *)0x0) {
    puVar10 = (undefined4 *)param_1[1];
    if (puVar9 != puVar10) {
      do {
        (**(code **)*puVar9)(0);
        puVar9 = puVar9 + 0x1c;
      } while (puVar9 != puVar10);
      puVar9 = (undefined4 *)*param_1;
    }
    uVar6 = ((int)(param_1[2] - (int)puVar9) / 0x70) * 0x70;
    puVar10 = puVar9;
    if (0xfff < uVar6) {
      puVar10 = (undefined4 *)puVar9[-1];
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uint)((int)puVar9 + (-4 - (int)puVar10))) {
LAB_007fc004:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar10,uVar6);
  }
  *param_1 = uVar8;
  param_1[1] = uVar1 * 0x70 + uVar8;
  param_1[2] = uVar5 + uVar8;
  return *param_1 + iVar4;
}



/* FUNCTION 12259 ; VA 0x007fc010 ; FUN_007fc010 */

int __thiscall FUN_007fc010(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  uint uVar11;
  undefined4 *puVar12;
  undefined4 *puVar13;
  
  iVar1 = *param_1;
  iVar5 = param_1[1] - iVar1 >> 5;
  if (iVar5 == 0x7ffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar6 = iVar5 + 1;
  uVar11 = param_1[2] - iVar1 >> 5;
  uVar7 = uVar6;
  if ((uVar11 <= 0x7ffffff - (uVar11 >> 1)) && (uVar7 = (uVar11 >> 1) + uVar11, uVar7 < uVar6)) {
    uVar7 = uVar6;
  }
  puVar8 = (undefined4 *)FUN_00577f40(uVar7);
  uVar11 = (int)param_2 - iVar1 & 0xffffffe0;
  puVar9 = (undefined4 *)((int)puVar8 + uVar11);
  uVar2 = param_3[1];
  uVar3 = param_3[2];
  uVar4 = param_3[3];
  *puVar9 = *param_3;
  puVar9[1] = uVar2;
  puVar9[2] = uVar3;
  puVar9[3] = uVar4;
  uVar2 = param_3[5];
  uVar3 = param_3[6];
  uVar4 = param_3[7];
  puVar9[4] = param_3[4];
  puVar9[5] = uVar2;
  puVar9[6] = uVar3;
  puVar9[7] = uVar4;
  puVar13 = (undefined4 *)param_1[1];
  puVar10 = (undefined4 *)*param_1;
  puVar12 = puVar8;
  if (param_2 == puVar13) {
    for (; puVar10 != puVar13; puVar10 = puVar10 + 8) {
      uVar2 = puVar10[1];
      uVar3 = puVar10[2];
      uVar4 = puVar10[3];
      *puVar12 = *puVar10;
      puVar12[1] = uVar2;
      puVar12[2] = uVar3;
      puVar12[3] = uVar4;
      uVar2 = puVar10[5];
      uVar3 = puVar10[6];
      uVar4 = puVar10[7];
      puVar12[4] = puVar10[4];
      puVar12[5] = uVar2;
      puVar12[6] = uVar3;
      puVar12[7] = uVar4;
      puVar12 = puVar12 + 8;
    }
  }
  else {
    if (puVar10 != param_2) {
      do {
        uVar2 = puVar10[1];
        uVar3 = puVar10[2];
        uVar4 = puVar10[3];
        *puVar12 = *puVar10;
        puVar12[1] = uVar2;
        puVar12[2] = uVar3;
        puVar12[3] = uVar4;
        puVar13 = puVar10 + 4;
        uVar2 = puVar10[5];
        uVar3 = puVar10[6];
        uVar4 = puVar10[7];
        puVar10 = puVar10 + 8;
        puVar12[4] = *puVar13;
        puVar12[5] = uVar2;
        puVar12[6] = uVar3;
        puVar12[7] = uVar4;
        puVar12 = puVar12 + 8;
      } while (puVar10 != param_2);
      puVar13 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar13) {
      do {
        uVar2 = param_2[1];
        uVar3 = param_2[2];
        uVar4 = param_2[3];
        puVar9[8] = *param_2;
        puVar9[9] = uVar2;
        puVar9[10] = uVar3;
        puVar9[0xb] = uVar4;
        puVar10 = param_2 + 4;
        uVar2 = param_2[5];
        uVar3 = param_2[6];
        uVar4 = param_2[7];
        param_2 = param_2 + 8;
        puVar9[0xc] = *puVar10;
        puVar9[0xd] = uVar2;
        puVar9[0xe] = uVar3;
        puVar9[0xf] = uVar4;
        puVar9 = puVar9 + 8;
      } while (param_2 != puVar13);
    }
  }
  FUN_007fdb40(puVar8,uVar6,uVar7);
  return *param_1 + uVar11;
}



/* FUNCTION 12260 ; VA 0x007fc130 ; FUN_007fc130 */

int __thiscall FUN_007fc130(int *param_1,undefined8 *param_2,undefined8 *param_3)

{
  int iVar1;
  uint uVar2;
  undefined8 *puVar3;
  int iVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  uint uVar8;
  undefined8 *puVar9;
  
  iVar4 = *param_1;
  iVar1 = (param_1[1] - *param_1) / 0xc;
  if (iVar1 == 0x15555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar2 = (param_1[2] - *param_1) / 0xc;
  uVar8 = iVar1 + 1;
  if (uVar2 <= 0x15555555 - (uVar2 >> 1)) {
    uVar8 = (uVar2 >> 1) + uVar2;
    if (uVar8 < iVar1 + 1U) {
      uVar8 = iVar1 + 1U;
    }
  }
  puVar3 = (undefined8 *)FUN_00618050(uVar8);
  iVar4 = (((int)param_2 - iVar4) / 0xc) * 0xc;
  puVar5 = (undefined8 *)(iVar4 + (int)puVar3);
  *puVar5 = *param_3;
  *(undefined4 *)(puVar5 + 1) = *(undefined4 *)(param_3 + 1);
  puVar9 = (undefined8 *)param_1[1];
  puVar6 = (undefined8 *)*param_1;
  puVar7 = puVar3;
  if (param_2 == puVar9) {
    for (; puVar6 != puVar9; puVar6 = (undefined8 *)((int)puVar6 + 0xc)) {
      *puVar7 = *puVar6;
      *(undefined4 *)(puVar7 + 1) = *(undefined4 *)(puVar6 + 1);
      puVar7 = (undefined8 *)((int)puVar7 + 0xc);
    }
  }
  else {
    if (puVar6 != param_2) {
      do {
        *puVar7 = *puVar6;
        puVar9 = puVar6 + 1;
        puVar6 = (undefined8 *)((int)puVar6 + 0xc);
        *(undefined4 *)(puVar7 + 1) = *(undefined4 *)puVar9;
        puVar7 = (undefined8 *)((int)puVar7 + 0xc);
      } while (puVar6 != param_2);
      puVar9 = (undefined8 *)param_1[1];
    }
    if (param_2 != puVar9) {
      do {
        *(undefined8 *)((int)puVar5 + 0xc) = *param_2;
        puVar6 = param_2 + 1;
        param_2 = (undefined8 *)((int)param_2 + 0xc);
        *(undefined4 *)((int)puVar5 + 0x14) = *(undefined4 *)puVar6;
        puVar5 = (undefined8 *)((int)puVar5 + 0xc);
      } while (param_2 != puVar9);
    }
  }
  FUN_006bf950(puVar3,iVar1 + 1,uVar8);
  return *param_1 + iVar4;
}



/* FUNCTION 12261 ; VA 0x007fc280 ; FUN_007fc280 */

int __thiscall
FUN_007fc280(int *param_1,undefined4 *param_2,undefined8 *param_3,undefined4 *param_4,
            undefined8 *param_5)

{
  undefined8 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  uint uVar11;
  undefined4 *puVar12;
  undefined4 *puVar13;
  
  iVar2 = *param_1;
  iVar6 = param_1[1] - iVar2 >> 5;
  if (iVar6 == 0x7ffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar7 = iVar6 + 1;
  uVar11 = param_1[2] - iVar2 >> 5;
  uVar8 = uVar7;
  if ((uVar11 <= 0x7ffffff - (uVar11 >> 1)) && (uVar8 = (uVar11 >> 1) + uVar11, uVar8 < uVar7)) {
    uVar8 = uVar7;
  }
  puVar9 = (undefined4 *)FUN_00577f40(uVar8);
  uVar11 = (int)param_2 - iVar2 & 0xffffffe0;
  puVar1 = (undefined8 *)(uVar11 + (int)puVar9);
  *puVar1 = *param_3;
  *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_3 + 1);
  *(undefined4 *)((int)puVar1 + 0xc) = *param_4;
  *(undefined4 *)(puVar1 + 2) = param_4[1];
  *(undefined8 *)((int)puVar1 + 0x14) = *param_5;
  *(undefined4 *)((int)puVar1 + 0x1c) = *(undefined4 *)(param_5 + 1);
  puVar13 = (undefined4 *)param_1[1];
  puVar10 = (undefined4 *)*param_1;
  puVar12 = puVar9;
  if (param_2 == puVar13) {
    for (; puVar10 != puVar13; puVar10 = puVar10 + 8) {
      uVar3 = puVar10[1];
      uVar4 = puVar10[2];
      uVar5 = puVar10[3];
      *puVar12 = *puVar10;
      puVar12[1] = uVar3;
      puVar12[2] = uVar4;
      puVar12[3] = uVar5;
      uVar3 = puVar10[5];
      uVar4 = puVar10[6];
      uVar5 = puVar10[7];
      puVar12[4] = puVar10[4];
      puVar12[5] = uVar3;
      puVar12[6] = uVar4;
      puVar12[7] = uVar5;
      puVar12 = puVar12 + 8;
    }
  }
  else {
    if (puVar10 != param_2) {
      do {
        uVar3 = puVar10[1];
        uVar4 = puVar10[2];
        uVar5 = puVar10[3];
        *puVar12 = *puVar10;
        puVar12[1] = uVar3;
        puVar12[2] = uVar4;
        puVar12[3] = uVar5;
        puVar13 = puVar10 + 4;
        uVar3 = puVar10[5];
        uVar4 = puVar10[6];
        uVar5 = puVar10[7];
        puVar10 = puVar10 + 8;
        puVar12[4] = *puVar13;
        puVar12[5] = uVar3;
        puVar12[6] = uVar4;
        puVar12[7] = uVar5;
        puVar12 = puVar12 + 8;
      } while (puVar10 != param_2);
      puVar13 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar13) {
      do {
        uVar3 = param_2[1];
        uVar4 = param_2[2];
        uVar5 = param_2[3];
        *(undefined4 *)(puVar1 + 4) = *param_2;
        *(undefined4 *)((int)puVar1 + 0x24) = uVar3;
        *(undefined4 *)(puVar1 + 5) = uVar4;
        *(undefined4 *)((int)puVar1 + 0x2c) = uVar5;
        puVar10 = param_2 + 4;
        uVar3 = param_2[5];
        uVar4 = param_2[6];
        uVar5 = param_2[7];
        param_2 = param_2 + 8;
        *(undefined4 *)(puVar1 + 6) = *puVar10;
        *(undefined4 *)((int)puVar1 + 0x34) = uVar3;
        *(undefined4 *)(puVar1 + 7) = uVar4;
        *(undefined4 *)((int)puVar1 + 0x3c) = uVar5;
        puVar1 = puVar1 + 4;
      } while (param_2 != puVar13);
    }
  }
  FUN_007fdb40(puVar9,uVar7,uVar8);
  return *param_1 + uVar11;
}



/* FUNCTION 12262 ; VA 0x007fc3c0 ; FUN_007fc3c0 */

void __thiscall FUN_007fc3c0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b4930;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Graphics::TextureProxy>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12263 ; VA 0x007fc42e ; Catch_All@007fc42e */

void Catch_All_007fc42e(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 12264 ; VA 0x007fc450 ; FUN_007fc450 */

undefined4 * FUN_007fc450(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  
  puVar6 = param_3;
  if (param_1 != param_2) {
    puVar7 = param_1 + 0x1b;
    do {
      *puVar6 = RBX::Graphics::AdornMesh::vftable;
      puVar1 = puVar7 + 0x1c;
      puVar2 = puVar7 + 1;
      puVar6[1] = puVar7[-0x1a];
      puVar6[2] = puVar7[-0x19];
      puVar6[3] = puVar7[-0x18];
      puVar6[4] = puVar7[-0x17];
      uVar3 = puVar7[-0x15];
      uVar4 = puVar7[-0x14];
      uVar5 = puVar7[-0x13];
      puVar6[5] = puVar7[-0x16];
      puVar6[6] = uVar3;
      puVar6[7] = uVar4;
      puVar6[8] = uVar5;
      puVar6[9] = puVar7[-0x12];
      uVar3 = puVar7[-0x10];
      uVar4 = puVar7[-0xf];
      uVar5 = puVar7[-0xe];
      puVar6[10] = puVar7[-0x11];
      puVar6[0xb] = uVar3;
      puVar6[0xc] = uVar4;
      puVar6[0xd] = uVar5;
      uVar3 = puVar7[-0xc];
      uVar4 = puVar7[-0xb];
      uVar5 = puVar7[-10];
      puVar6[0xe] = puVar7[-0xd];
      puVar6[0xf] = uVar3;
      puVar6[0x10] = uVar4;
      puVar6[0x11] = uVar5;
      uVar3 = puVar7[-8];
      uVar4 = puVar7[-7];
      uVar5 = puVar7[-6];
      puVar6[0x12] = puVar7[-9];
      puVar6[0x13] = uVar3;
      puVar6[0x14] = uVar4;
      puVar6[0x15] = uVar5;
      uVar3 = puVar7[-4];
      uVar4 = puVar7[-3];
      uVar5 = puVar7[-2];
      puVar6[0x16] = puVar7[-5];
      puVar6[0x17] = uVar3;
      puVar6[0x18] = uVar4;
      puVar6[0x19] = uVar5;
      puVar6[0x1a] = 0;
      *(undefined4 *)((int)param_3 + (-0x70 - (int)param_1) + (int)puVar1) = 0;
      puVar6[0x1a] = puVar7[-1];
      puVar6 = puVar6 + 0x1c;
      *(undefined4 *)((int)param_3 + (-0x70 - (int)param_1) + (int)puVar1) = *puVar7;
      puVar7[-1] = 0;
      *puVar7 = 0;
      puVar7 = puVar1;
    } while (puVar2 != param_2);
  }
  return puVar6;
}



/* FUNCTION 12265 ; VA 0x007fc520 ; FUN_007fc520 */

void FUN_007fc520(undefined4 param_1,undefined4 *param_2,int param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  *param_2 = RBX::Graphics::AdornMesh::vftable;
  param_2[1] = *(undefined4 *)(param_3 + 4);
  param_2[2] = *(undefined4 *)(param_3 + 8);
  param_2[3] = *(undefined4 *)(param_3 + 0xc);
  param_2[4] = *(undefined4 *)(param_3 + 0x10);
  uVar2 = *(undefined4 *)(param_3 + 0x18);
  uVar3 = *(undefined4 *)(param_3 + 0x1c);
  uVar4 = *(undefined4 *)(param_3 + 0x20);
  param_2[5] = *(undefined4 *)(param_3 + 0x14);
  param_2[6] = uVar2;
  param_2[7] = uVar3;
  param_2[8] = uVar4;
  param_2[9] = *(undefined4 *)(param_3 + 0x24);
  uVar2 = *(undefined4 *)(param_3 + 0x2c);
  uVar3 = *(undefined4 *)(param_3 + 0x30);
  uVar4 = *(undefined4 *)(param_3 + 0x34);
  param_2[10] = *(undefined4 *)(param_3 + 0x28);
  param_2[0xb] = uVar2;
  param_2[0xc] = uVar3;
  param_2[0xd] = uVar4;
  uVar2 = *(undefined4 *)(param_3 + 0x3c);
  uVar3 = *(undefined4 *)(param_3 + 0x40);
  uVar4 = *(undefined4 *)(param_3 + 0x44);
  param_2[0xe] = *(undefined4 *)(param_3 + 0x38);
  param_2[0xf] = uVar2;
  param_2[0x10] = uVar3;
  param_2[0x11] = uVar4;
  uVar2 = *(undefined4 *)(param_3 + 0x4c);
  uVar3 = *(undefined4 *)(param_3 + 0x50);
  uVar4 = *(undefined4 *)(param_3 + 0x54);
  param_2[0x12] = *(undefined4 *)(param_3 + 0x48);
  param_2[0x13] = uVar2;
  param_2[0x14] = uVar3;
  param_2[0x15] = uVar4;
  uVar2 = *(undefined4 *)(param_3 + 0x5c);
  uVar3 = *(undefined4 *)(param_3 + 0x60);
  uVar4 = *(undefined4 *)(param_3 + 100);
  param_2[0x16] = *(undefined4 *)(param_3 + 0x58);
  param_2[0x17] = uVar2;
  param_2[0x18] = uVar3;
  param_2[0x19] = uVar4;
  param_2[0x1a] = 0;
  param_2[0x1b] = 0;
  if (*(int *)(param_3 + 0x6c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_3 + 0x6c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[0x1a] = *(undefined4 *)(param_3 + 0x68);
  param_2[0x1b] = *(undefined4 *)(param_3 + 0x6c);
  return;
}



/* FUNCTION 12266 ; VA 0x007fc5a0 ; FUN_007fc5a0 */

void __thiscall
FUN_007fc5a0(int param_1,undefined8 *param_2,undefined4 *param_3,undefined8 *param_4)

{
  undefined8 *puVar1;
  
  puVar1 = *(undefined8 **)(param_1 + 4);
  if (*(undefined8 **)(param_1 + 8) != puVar1) {
    *puVar1 = *param_2;
    *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_2 + 1);
    *(undefined4 *)((int)puVar1 + 0xc) = *param_3;
    *(undefined4 *)(puVar1 + 2) = param_3[1];
    *(undefined8 *)((int)puVar1 + 0x14) = *param_4;
    *(undefined4 *)((int)puVar1 + 0x1c) = *(undefined4 *)(param_4 + 1);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x20;
    return;
  }
  FUN_007fc280(puVar1,param_2,param_3,param_4);
  return;
}



/* FUNCTION 12267 ; VA 0x007fc610 ; FUN_007fc610 */

undefined4 * __thiscall
FUN_007fc610(undefined4 *param_1,int param_2,int *param_3,undefined4 param_4,undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  char *pcStack_38;
  undefined4 uStack_34;
  char *pcStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b4a6e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  *(undefined2 *)(param_1 + 5) = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  uStack_8 = 0;
  *param_1 = RBX::Graphics::AdornRender::vftable;
  param_1[0xd] = param_2;
  param_1[0xe] = param_3;
  puStack_18 = param_1;
  FUN_0054ef60(param_5);
  param_1[0x15] = param_4;
  param_1[0x16] = 0;
  param_1[0x18] = 0x3f800000;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0x3f800000;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0x3f800000;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  uStack_8._0_1_ = 3;
  *(undefined2 *)(param_1 + 0x26) = 0;
  *(undefined *)((int)param_1 + 0x9a) = 1;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  FUN_016f4053(param_1 + 0x29,0xc,5,FUN_00569440,FUN_007fd3a0);
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  uStack_8._0_1_ = 0xe;
  param_3 = param_1 + 0x42;
  FUN_016f4053(param_3,4,0x10,FUN_00550050,FUN_00793250);
  uStack_8._0_1_ = 0xf;
  FUN_016f4053(param_1 + 0x52,8,0x37,FUN_005502b0,FUN_00550b30);
  puStack_14 = param_1 + 0xc0;
  uStack_8._0_1_ = 0x10;
  FUN_016f4053(puStack_14,8,0xb,FUN_005502b0,FUN_00550b30);
  uStack_8._0_1_ = 0x11;
  FUN_00860ec0();
  uStack_8._0_1_ = 0x12;
  FUN_0147c1b0(auStack_20,&DAT_01eb366c,3,0x20);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
  uVar5 = FUN_00800620(*(undefined4 *)(param_2 + 0x3c),auStack_20,0);
  iVar2 = param_1[0x38];
  param_1[0x38] = uVar5;
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar6 = piVar3[1] + -1;
      piVar3[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar6 = piVar3[2] + -1;
        piVar3[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,0x18);
  }
  uVar5 = FUN_00800620(*(undefined4 *)(param_2 + 0x3c),auStack_20,1);
  iVar2 = param_1[0x39];
  param_1[0x39] = uVar5;
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar6 = piVar3[1] + -1;
      piVar3[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar6 = piVar3[2] + -1;
        piVar3[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,0x18);
  }
  uVar5 = FUN_007ff190(*(undefined4 *)(param_2 + 0x3c),auStack_20);
  iVar2 = param_1[0x3a];
  param_1[0x3a] = uVar5;
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar6 = piVar3[1] + -1;
      piVar3[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar6 = piVar3[2] + -1;
        piVar3[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,0x18);
  }
  uVar5 = 0xc;
  if (DAT_01d61ed4 != '\0') {
    uVar5 = 0x18;
  }
  uVar5 = FUN_007ffe40(*(undefined4 *)(param_2 + 0x3c),auStack_20,uVar5,0);
  iVar2 = param_1[0x3b];
  param_1[0x3b] = uVar5;
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar6 = piVar3[1] + -1;
      piVar3[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar6 = piVar3[2] + -1;
        piVar3[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,0x18);
  }
  uVar5 = FUN_008010f0(*(undefined4 *)(param_2 + 0x3c),auStack_20);
  iVar2 = param_1[0x3c];
  param_1[0x3c] = uVar5;
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar6 = piVar3[1] + -1;
      piVar3[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar6 = piVar3[2] + -1;
        piVar3[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,0x18);
  }
  uVar5 = FUN_00801600(*(undefined4 *)(param_2 + 0x3c),auStack_20,0x42700000);
  iVar2 = param_1[0x3d];
  param_1[0x3d] = uVar5;
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar6 = piVar3[1] + -1;
      piVar3[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar6 = piVar3[2] + -1;
        piVar3[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,0x18);
  }
  uVar5 = FUN_007ff620(*(undefined4 *)(param_2 + 0x3c),auStack_20,0);
  iVar2 = param_1[0x3e];
  param_1[0x3e] = uVar5;
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar6 = piVar3[1] + -1;
      piVar3[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar6 = piVar3[2] + -1;
        piVar3[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,0x18);
  }
  uVar5 = FUN_007ff620(*(undefined4 *)(param_2 + 0x3c),auStack_20,1);
  iVar2 = param_1[0x3f];
  param_1[0x3f] = uVar5;
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar6 = piVar3[1] + -1;
      piVar3[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar6 = piVar3[2] + -1;
        piVar3[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,0x18);
  }
  uVar5 = 0xc;
  if (DAT_01d61ed4 != '\0') {
    uVar5 = 0x18;
  }
  uVar5 = FUN_007ffe40(*(undefined4 *)(param_2 + 0x3c),auStack_20,uVar5,1);
  iVar2 = param_1[0x41];
  param_1[0x41] = uVar5;
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar6 = piVar3[1] + -1;
      piVar3[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar6 = piVar3[2] + -1;
        piVar3[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,0x18);
  }
  uVar7 = 0;
  do {
    uVar5 = 0xc;
    if (DAT_01d61ed4 != '\0') {
      uVar5 = 0x18;
    }
    iVar6 = FUN_00800980(*(undefined4 *)(param_2 + 0x3c),auStack_20,uVar5,uVar7 * 4 + 4);
    iVar2 = *param_3;
    *param_3 = iVar6;
    if (iVar2 != 0) {
      piVar3 = *(int **)(iVar2 + 4);
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar6 = piVar3[1] + -1;
        piVar3[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar6 = piVar3[2] + -1;
          piVar3[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      FUN_01674ea0(iVar2,0x18);
    }
    uVar7 = uVar7 + 1;
    param_3 = param_3 + 1;
  } while (uVar7 < 0x10);
  pcStack_38 = "AdornLightingVS";
  uStack_34 = 0xf;
  pcStack_30 = "AdornFS";
  uStack_2c = 7;
  FUN_00790e00(&uStack_28,&pcStack_38,2);
  puVar4 = puStack_18;
  uVar5 = uStack_28;
  uStack_28 = 0;
  *puStack_14 = uVar5;
  piVar3 = (int *)puStack_14[1];
  puStack_14[1] = piStack_24;
  piStack_24 = (int *)0x0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    piVar3 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1 + -1;
        *piVar1 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  pcStack_38 = "AdornVS";
  uStack_34 = 7;
  pcStack_30 = "AdornFS";
  uStack_2c = 7;
  FUN_00790e00(&uStack_28,&pcStack_38,2);
  piVar1 = piStack_24;
  puVar4[0xc2] = uStack_28;
  piVar3 = (int *)puVar4[0xc3];
  uStack_28 = 0;
  piStack_24 = (int *)0x0;
  puVar4[0xc3] = piVar1;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    piVar3 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1 + -1;
        *piVar1 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  pcStack_38 = "AdornSelfLitVS";
  uStack_34 = 0xe;
  pcStack_30 = "AdornFS";
  uStack_2c = 7;
  FUN_00790e00(&uStack_28,&pcStack_38,2);
  piVar1 = piStack_24;
  puVar4[0xc4] = uStack_28;
  piVar3 = (int *)puVar4[0xc5];
  uStack_28 = 0;
  piStack_24 = (int *)0x0;
  puVar4[0xc5] = piVar1;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    piVar3 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1 + -1;
        *piVar1 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  pcStack_38 = "AdornSelfLitHighlightVS";
  uStack_34 = 0x17;
  pcStack_30 = "AdornFS";
  uStack_2c = 7;
  FUN_00790e00(&uStack_28,&pcStack_38,2);
  piVar1 = piStack_24;
  puVar4[0xc6] = uStack_28;
  piVar3 = (int *)puVar4[199];
  uStack_28 = 0;
  piStack_24 = (int *)0x0;
  puVar4[199] = piVar1;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    piVar3 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1 + -1;
        *piVar1 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  pcStack_38 = "AdornAALineVS";
  uStack_34 = 0xd;
  pcStack_30 = "AdornAALineFS";
  uStack_2c = 0xd;
  FUN_00790e00(&uStack_28,&pcStack_38,2);
  piVar1 = piStack_24;
  puVar4[200] = uStack_28;
  piVar3 = (int *)puVar4[0xc9];
  uStack_28 = 0;
  piStack_24 = (int *)0x0;
  puVar4[0xc9] = piVar1;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    piVar3 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1 + -1;
        *piVar1 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  pcStack_38 = "AdornOutlineVS";
  uStack_34 = 0xe;
  pcStack_30 = "AdornOutlineFS";
  uStack_2c = 0xe;
  FUN_00790e00(&uStack_28,&pcStack_38,2);
  piVar1 = piStack_24;
  puVar4[0xca] = uStack_28;
  piVar3 = (int *)puVar4[0xcb];
  uStack_28 = 0;
  piStack_24 = (int *)0x0;
  puVar4[0xcb] = piVar1;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    piVar3 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1 + -1;
        *piVar1 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  pcStack_38 = "AdornVS";
  uStack_34 = 7;
  pcStack_30 = "AdornOnTopFS";
  uStack_2c = 0xc;
  FUN_00790e00(&uStack_28,&pcStack_38,2);
  piVar1 = piStack_24;
  puVar4[0xcc] = uStack_28;
  piVar3 = (int *)puVar4[0xcd];
  uStack_28 = 0;
  piStack_24 = (int *)0x0;
  puVar4[0xcd] = piVar1;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    piVar3 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1 + -1;
        *piVar1 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  pcStack_38 = "AdornObjectVS";
  uStack_34 = 0xd;
  pcStack_30 = "AdornObjectFS";
  uStack_2c = 0xd;
  FUN_00790e00(&uStack_28,&pcStack_38,2);
  piVar1 = piStack_24;
  puVar4[0xce] = uStack_28;
  piVar3 = (int *)puVar4[0xcf];
  uStack_28 = 0;
  piStack_24 = (int *)0x0;
  puVar4[0xcf] = piVar1;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    piVar3 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1 + -1;
        *piVar1 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  pcStack_38 = "AdornObjectRopeVS";
  uStack_34 = 0x11;
  pcStack_30 = "AdornObjectFS";
  uStack_2c = 0xd;
  FUN_00790e00(&uStack_28,&pcStack_38,2);
  piVar1 = piStack_24;
  puVar4[0xd2] = uStack_28;
  piVar3 = (int *)puVar4[0xd3];
  uStack_28 = 0;
  piStack_24 = (int *)0x0;
  puVar4[0xd3] = piVar1;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    piVar3 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1 + -1;
        *piVar1 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  pcStack_38 = "AdornObjectSpringVS";
  uStack_34 = 0x13;
  pcStack_30 = "AdornObjectFS";
  uStack_2c = 0xd;
  FUN_00790e00(&uStack_28,&pcStack_38,2);
  piVar1 = piStack_24;
  puVar4[0xd0] = uStack_28;
  piVar3 = (int *)puVar4[0xd1];
  uStack_28 = 0;
  piStack_24 = (int *)0x0;
  puVar4[0xd1] = piVar1;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    piVar3 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1 + -1;
        *piVar1 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  pcStack_38 = "AdornObjectParabolaVS";
  uStack_34 = 0x15;
  pcStack_30 = "AdornUnlitFS";
  uStack_2c = 0xc;
  FUN_00790e00(&uStack_28,&pcStack_38,2);
  piVar1 = piStack_24;
  puVar4[0xd4] = uStack_28;
  piVar3 = (int *)puVar4[0xd5];
  uStack_28 = 0;
  piStack_24 = (int *)0x0;
  puVar4[0xd5] = piVar1;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar2 = piVar3[2] + -1;
      piVar3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    piVar3 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1 + -1;
        *piVar1 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar3 = piStack_1c + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 12268 ; VA 0x007fd3a0 ; FUN_007fd3a0 */

void __fastcall FUN_007fd3a0(int *param_1)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  
  puVar2 = (undefined4 *)*param_1;
  if (puVar2 != (undefined4 *)0x0) {
    puVar3 = (undefined4 *)param_1[1];
    if (puVar2 != puVar3) {
      do {
        (**(code **)*puVar2)(0);
        puVar2 = puVar2 + 0x1c;
      } while (puVar2 != puVar3);
      puVar2 = (undefined4 *)*param_1;
    }
    uVar1 = ((param_1[2] - (int)puVar2) / 0x70) * 0x70;
    puVar3 = puVar2;
    if (0xfff < uVar1) {
      puVar3 = (undefined4 *)puVar2[-1];
      uVar1 = uVar1 + 0x23;
      if (0x1f < (uint)((int)puVar2 + (-4 - (int)puVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 12269 ; VA 0x007fd420 ; FUN_007fd420 */

int __fastcall FUN_007fd420(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  *param_1 = RBX::Adorn::vftable;
  iVar4 = FUN_00612c70();
  piVar3 = (int *)param_1[9];
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x007fd459. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar4 = (**(code **)(*piVar3 + 4))();
        return iVar4;
      }
    }
  }
  return iVar4;
}



/* FUNCTION 12270 ; VA 0x007fd460 ; FUN_007fd460 */

void __fastcall FUN_007fd460(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x6c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_007f6360();
  return;
}



/* FUNCTION 12271 ; VA 0x007fd4a0 ; FUN_007fd4a0 */

int __fastcall FUN_007fd4a0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::AdornRender::vftable;
  FUN_006eccd0();
  FUN_007fd880();
  FUN_016f32d1(param_1 + 0xc0,8,0xb,FUN_00550b30);
  FUN_016f32d1(param_1 + 0x52,8,0x37,FUN_00550b30);
  FUN_016f32d1(param_1 + 0x42,4,0x10,FUN_00793250);
  iVar5 = param_1[0x41];
  if (iVar5 != 0) {
    piVar2 = *(int **)(iVar5 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar5,0x18);
  }
  iVar5 = param_1[0x40];
  if (iVar5 != 0) {
    piVar2 = *(int **)(iVar5 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar5,0x18);
  }
  iVar5 = param_1[0x3f];
  if (iVar5 != 0) {
    piVar2 = *(int **)(iVar5 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar5,0x18);
  }
  iVar5 = param_1[0x3e];
  if (iVar5 != 0) {
    piVar2 = *(int **)(iVar5 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar5,0x18);
  }
  iVar5 = param_1[0x3d];
  if (iVar5 != 0) {
    piVar2 = *(int **)(iVar5 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar5,0x18);
  }
  iVar5 = param_1[0x3c];
  if (iVar5 != 0) {
    piVar2 = *(int **)(iVar5 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar5,0x18);
  }
  iVar5 = param_1[0x3b];
  if (iVar5 != 0) {
    piVar2 = *(int **)(iVar5 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar5,0x18);
  }
  iVar5 = param_1[0x3a];
  if (iVar5 != 0) {
    piVar2 = *(int **)(iVar5 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar5,0x18);
  }
  iVar5 = param_1[0x39];
  if (iVar5 != 0) {
    piVar2 = *(int **)(iVar5 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar5,0x18);
  }
  iVar5 = param_1[0x38];
  if (iVar5 != 0) {
    piVar2 = *(int **)(iVar5 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar5,0x18);
  }
  FUN_016f32d1(param_1 + 0x29,0xc,5,FUN_007fd3a0);
  piVar2 = (int *)param_1[0x25];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar5 = piVar2[1] + -1;
    piVar2[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar5 = piVar2[2] + -1;
      piVar2[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_016790b0();
  uVar3 = param_1[0x14];
  if (0xf < uVar3) {
    iVar5 = param_1[0xf];
    uVar6 = uVar3 + 1;
    iVar4 = iVar5;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar5 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar5 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  param_1[0x13] = 0;
  param_1[0x14] = 0xf;
  *(undefined *)(param_1 + 0xf) = 0;
  *param_1 = RBX::Adorn::vftable;
  iVar5 = FUN_00612c70();
  piVar2 = (int *)param_1[9];
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar4 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar5 = (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar5 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 12272 ; VA 0x007fd870 ; FUN_007fd870 */

void __fastcall FUN_007fd870(undefined4 *param_1)

{
  *param_1 = RBX::IndexBox::vftable;
  return;
}



/* FUNCTION 12273 ; VA 0x007fd880 ; FUN_007fd880 */

void __fastcall FUN_007fd880(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = param_1[7];
  if (iVar1 != 0) {
    uVar3 = ((param_1[9] - iVar1) / 0xc) * 0xc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_007fd99a;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[7] = 0;
    param_1[8] = 0;
    param_1[9] = 0;
  }
  iVar1 = param_1[4];
  if (iVar1 != 0) {
    uVar3 = ((param_1[6] - iVar1) / 0xc) * 0xc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_007fd99a;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[4] = 0;
    param_1[5] = 0;
    param_1[6] = 0;
  }
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    uVar3 = param_1[3] - iVar1 & 0xffffffe0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_007fd99a:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
  }
  if (*param_1 != 0) {
    FUN_01674ea0(*param_1,0x1c);
  }
  return;
}



/* FUNCTION 12274 ; VA 0x007fd9a0 ; FUN_007fd9a0 */

undefined4 * __thiscall FUN_007fd9a0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *param_1 = RBX::Adorn::vftable;
  FUN_00612c70();
  piVar2 = (int *)param_1[9];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x34);
  }
  return param_1;
}



/* FUNCTION 12275 ; VA 0x007fda00 ; FUN_007fda00 */

int __thiscall FUN_007fda00(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x6c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_007f6360();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x70);
  }
  return param_1;
}



/* FUNCTION 12276 ; VA 0x007fda60 ; FUN_007fda60 */

undefined4 __thiscall FUN_007fda60(undefined4 param_1,byte param_2)

{
  FUN_007fd4a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x380);
  }
  return param_1;
}



/* FUNCTION 12277 ; VA 0x007fda90 ; FUN_007fda90 */

undefined4 * __thiscall FUN_007fda90(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::IndexBox::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 12278 ; VA 0x007fdac0 ; FUN_007fdac0 */

undefined4 * __thiscall FUN_007fdac0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = (int *)param_1[2];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *param_1 = RBX::TextureProxyBase::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc);
  }
  return param_1;
}



/* FUNCTION 12279 ; VA 0x007fdb10 ; FUN_007fdb10 */

undefined4 * __thiscall FUN_007fdb10(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::TextureProxyBase::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 12280 ; VA 0x007fdb40 ; FUN_007fdb40 */

void __thiscall FUN_007fdb40(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1 & 0xffffffe0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  *param_1 = param_2;
  param_1[1] = param_3 * 0x20 + param_2;
  param_1[2] = param_4 * 0x20 + param_2;
  return;
}



/* FUNCTION 12281 ; VA 0x007fdba0 ; FUN_007fdba0 */

void __thiscall FUN_007fdba0(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined8 *puVar3;
  int iVar4;
  undefined8 *puVar5;
  int iVar6;
  
  iVar1 = param_1[1];
  iVar2 = *param_1;
  iVar4 = FUN_00618050(param_2);
  puVar5 = (undefined8 *)*param_1;
  puVar3 = (undefined8 *)param_1[1];
  if (puVar5 != puVar3) {
    iVar6 = iVar4 - (int)puVar5;
    do {
      *(undefined8 *)(iVar6 + (int)puVar5) = *puVar5;
      *(undefined4 *)(iVar6 + 8 + (int)puVar5) = *(undefined4 *)(puVar5 + 1);
      puVar5 = (undefined8 *)((int)puVar5 + 0xc);
    } while (puVar5 != puVar3);
  }
  FUN_006bf950(iVar4,(iVar1 - iVar2) / 0xc,param_2);
  return;
}



/* FUNCTION 12282 ; VA 0x007fdc10 ; FUN_007fdc10 */

void FUN_007fdc10(undefined8 *param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  
  if (param_1 != param_2) {
    do {
      *param_3 = *param_1;
      puVar1 = param_1 + 1;
      param_1 = (undefined8 *)((int)param_1 + 0xc);
      *(undefined4 *)(param_3 + 1) = *(undefined4 *)puVar1;
      param_3 = (undefined8 *)((int)param_3 + 0xc);
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 12283 ; VA 0x007fdc40 ; FUN_007fdc40 */

void FUN_007fdc40(undefined8 *param_1,undefined8 *param_2,int param_3)

{
  if (param_1 != param_2) {
    param_3 = param_3 - (int)param_1;
    do {
      *(undefined8 *)(param_3 + (int)param_1) = *param_1;
      *(undefined4 *)(param_3 + 8 + (int)param_1) = *(undefined4 *)(param_1 + 1);
      param_1 = (undefined8 *)((int)param_1 + 0xc);
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 12284 ; VA 0x007fdc70 ; FUN_007fdc70 */

void FUN_007fdc70(void)

{
  FUN_007f91e0();
  return;
}



/* FUNCTION 12285 ; VA 0x007fdc80 ; FUN_007fdc80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_007fdc80(int param_1,float *param_2,undefined4 param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  fVar1 = (*param_2 + param_2[3]) * DAT_018ce2f4;
  fVar3 = (param_2[1] + param_2[4]) * DAT_018ce2f4;
  fVar2 = (param_2[2] + param_2[5]) * DAT_018ce2f4;
  fStack_10 = *(float *)(param_1 + 100) * fVar3 + fVar1 * *(float *)(param_1 + 0x60) +
              *(float *)(param_1 + 0x68) * fVar2 + *(float *)(param_1 + 0x84);
  fStack_18 = param_2[4] - param_2[1];
  fStack_c = *(float *)(param_1 + 0x6c) * fVar1 + *(float *)(param_1 + 0x70) * fVar3 +
             *(float *)(param_1 + 0x74) * fVar2 + *(float *)(param_1 + 0x88);
  fStack_14 = param_2[5] - param_2[2];
  fStack_1c = param_2[3] - *param_2;
  uStack_3c = 0;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  fStack_24 = *(float *)(param_1 + 0x78) * fVar1 + *(float *)(param_1 + 0x7c) * fVar3 +
              *(float *)(param_1 + 0x80) * fVar2 + *(float *)(param_1 + 0x8c);
  fVar1 = fStack_1c;
  if (fStack_1c < fStack_18) {
    fVar1 = fStack_18;
  }
  if (fVar1 < fStack_14) {
    fVar1 = fStack_14;
  }
  uStack_2c = CONCAT44(fStack_c,fStack_10);
  fStack_1c = fStack_1c * DAT_018ce2f4;
  fStack_20 = fVar1 * DAT_018ce2f4 * _DAT_019011b8;
  fStack_18 = fStack_18 * DAT_018ce2f4;
  fStack_14 = fStack_14 * DAT_018ce2f4;
  fStack_8 = fStack_24;
  FUN_00804740(*(undefined4 *)(param_1 + 0xe8),*(undefined4 *)(param_1 + 0x18),&fStack_10,
               (float *)(param_1 + 0x60),&fStack_1c,param_3,&uStack_2c,&uStack_3c,0xffffffff,1);
  return;
}



/* FUNCTION 12286 ; VA 0x007fddf0 ; FUN_007fddf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_007fddf0(int param_1,int param_2,float *param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6)

{
  float fVar1;
  float fVar2;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined8 uStack_14;
  undefined4 uStack_c;
  float fStack_8;
  
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  fVar1 = param_3[1];
  if (param_3[1] <= *param_3) {
    fVar1 = *param_3;
  }
  fVar2 = param_3[2];
  if (param_3[2] <= fVar1) {
    fVar2 = fVar1;
  }
  uStack_c = *(undefined4 *)(param_2 + 0x2c);
  uStack_14 = *(undefined8 *)(param_2 + 0x24);
  fStack_8 = fVar2 * DAT_018ce2f4 * _DAT_019011b8;
  FUN_00804740(*(undefined4 *)(param_1 + 0xe8),*(undefined4 *)(param_1 + 0x18),
               (undefined8 *)(param_2 + 0x24),param_2,param_3,param_4,&uStack_14,&uStack_24,param_5,
               param_6);
  return;
}



/* FUNCTION 12287 ; VA 0x007fde80 ; FUN_007fde80 */

void __thiscall
FUN_007fde80(int *param_1,undefined4 param_2,float param_3,float param_4,float param_5,float param_6
            ,int param_7,int param_8,int param_9)

{
  ulonglong *puVar1;
  int iVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined2 *puVar5;
  undefined2 *puVar6;
  double dVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fStack_d0;
  float fStack_cc;
  float fStack_c8;
  float fStack_c4;
  float fStack_c0;
  float fStack_bc;
  float fStack_b8;
  float fStack_b4;
  float fStack_b0;
  float fStack_ac;
  float fStack_a8;
  float fStack_a4;
  int *piStack_a0;
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  float fStack_90;
  float fStack_8c;
  uint uStack_88;
  int iStack_84;
  int iStack_80;
  int iStack_7c;
  float fStack_78;
  float fStack_74;
  float fStack_70;
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  short sStack_54;
  short sStack_52;
  short sStack_50;
  undefined2 uStack_4e;
  byte bStack_49;
  int iStack_48;
  ulonglong *puStack_44;
  ulonglong *puStack_40;
  ulonglong *puStack_3c;
  byte bStack_35;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  ulonglong *puStack_24;
  byte bStack_1d;
  int iStack_1c;
  undefined2 *puStack_18;
  undefined2 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b4a90;
  pvStack_10 = ExceptionList;
  bStack_1d = 0.0 < param_5;
  bStack_35 = param_6 < DAT_019011e0;
  piStack_a0 = param_1;
  if ((!(bool)bStack_1d) && (!(bool)bStack_35)) {
    ExceptionList = &pvStack_10;
    (**(code **)(*param_1 + 0x70))(param_2,param_3,param_4,param_7,param_8,param_9);
    ExceptionList = pvStack_10;
    return;
  }
  iVar2 = 0xc;
  if (DAT_01d61ed4 != '\0') {
    iVar2 = 0x18;
  }
  fStack_78 = DAT_019011e0 / (float)iVar2;
  uVar3 = -(int)(param_6 / (DAT_019011e4 / (float)iVar2));
  dVar7 = (double)(fStack_78 * DAT_0190119c);
  sStack_54 = SUB82(dVar7,0);
  sStack_52 = (short)((ulonglong)dVar7 >> 0x10);
  sStack_50 = (short)((ulonglong)dVar7 >> 0x20);
  uStack_4e = (undefined2)((ulonglong)dVar7 >> 0x30);
  ExceptionList = &pvStack_10;
  FUN_01728390();
  fStack_94 = (float)dVar7;
  dVar7 = (double)CONCAT26(uStack_4e,CONCAT24(sStack_50,CONCAT22(sStack_52,sStack_54)));
  FUN_017279f0();
  fStack_98 = (float)dVar7;
  param_6 = param_6 - (float)(int)uVar3 * fStack_78;
  dVar7 = (double)(param_6 * DAT_0190119c);
  sStack_54 = SUB82(dVar7,0);
  sStack_52 = (short)((ulonglong)dVar7 >> 0x10);
  sStack_50 = (short)((ulonglong)dVar7 >> 0x20);
  uStack_4e = (undefined2)((ulonglong)dVar7 >> 0x30);
  uStack_88 = uVar3;
  FUN_01728390();
  fStack_8c = (float)dVar7;
  dVar7 = (double)CONCAT26(uStack_4e,CONCAT24(sStack_50,CONCAT22(sStack_52,sStack_54)));
  FUN_017279f0();
  iStack_7c = uVar3 + 2;
  bStack_49 = bStack_1d ^ 1;
  fStack_90 = (float)dVar7;
  iStack_48 = 0;
  fStack_64 = 0.0;
  fStack_60 = DAT_018ce2f8;
  fStack_5c = (float)(((bStack_1d + 1) * iStack_7c + (uint)bStack_49) * 2);
  puStack_24 = (ulonglong *)0x0;
  puStack_44 = (ulonglong *)0x0;
  fStack_68 = (float)(((bStack_1d + 1) * (uVar3 + 1) + (uint)bStack_35) * 0xc);
  puStack_3c = (ulonglong *)0x0;
  puStack_40 = (ulonglong *)0x0;
  iStack_1c = 0;
  puStack_18 = (undefined2 *)0x0;
  puStack_14 = (undefined2 *)0x0;
  uStack_8 = 1;
  if (fStack_5c != 0.0) {
    if (0x15555555 < (uint)fStack_5c) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_007fdba0(fStack_5c);
    puStack_3c = puStack_40;
    puStack_24 = puStack_44;
  }
  puVar5 = (undefined2 *)0x0;
  puVar6 = (undefined2 *)0x0;
  puStack_44 = puStack_24;
  puStack_40 = puStack_3c;
  if (fStack_68 != 0.0) {
    if (0x7fffffff < (uint)fStack_68) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_0072e0d0(fStack_68);
    puVar5 = puStack_18;
    puVar6 = puStack_14;
  }
  fVar8 = param_4;
  if (bStack_1d == 0) {
    fStack_5c = param_4 * DAT_018ce2f4;
    sStack_54 = 0;
    sStack_52 = 0;
    sStack_50 = 0;
    uStack_4e = 0;
    fStack_58 = (float)((uint)fStack_5c ^ DAT_018c4ea0);
    if (puStack_3c == puStack_24) {
      FUN_007fc130(puStack_24,&fStack_58);
      puStack_3c = puStack_40;
    }
    else {
      *puStack_24 = (ulonglong)(uint)fStack_58;
      *(undefined4 *)(puStack_24 + 1) = 0;
      puStack_44 = (ulonglong *)((int)puStack_24 + 0xc);
    }
    fStack_58 = fStack_5c;
    sStack_54 = 0;
    sStack_52 = 0;
    sStack_50 = 0;
    uStack_4e = 0;
    if (puStack_3c == puStack_44) {
      FUN_007fc130(puStack_44,&fStack_58);
      puStack_3c = puStack_40;
      fVar8 = param_4;
      puStack_24 = puStack_44;
    }
    else {
      *puStack_44 = (ulonglong)(uint)fStack_5c;
      *(undefined4 *)(puStack_44 + 1) = 0;
      puStack_44 = (ulonglong *)((int)puStack_44 + 0xc);
      fVar8 = param_4;
      puStack_24 = puStack_44;
    }
  }
  param_4 = 0.0;
  if (0 < iStack_7c) {
    fVar10 = 0.0;
    fStack_5c = 0.0 - fVar8 * DAT_018ce2f4;
    iStack_80 = CONCAT22(iStack_80._2_2_,(bStack_1d + 1) * 2);
    fStack_70 = fVar8 * DAT_018ce2f4 + 0.0;
    fVar8 = 0.0;
    iStack_84 = CONCAT22(iStack_84._2_2_,(ushort)bStack_49 * 2);
    do {
      fVar9 = fVar10 * param_3;
      fStack_6c = fStack_60 * param_3;
      fStack_74 = fVar10 * param_5;
      fStack_68 = fStack_60 * param_5;
      fStack_a8 = fVar9 - 0.0;
      fStack_a4 = fStack_6c - 0.0;
      fStack_ac = fStack_5c;
      fStack_9c = fVar8;
      if (puStack_3c == puStack_24) {
        puVar1 = puStack_24;
        puStack_24 = (ulonglong *)fVar9;
        FUN_007fc130(puVar1,&fStack_ac);
        puStack_3c = puStack_40;
      }
      else {
        *puStack_24 = CONCAT44(fStack_a8,fStack_5c);
        *(float *)(puStack_24 + 1) = fStack_a4;
        puStack_44 = (ulonglong *)((int)puStack_24 + 0xc);
        puStack_24 = (ulonglong *)fVar9;
      }
      fStack_b4 = (float)puStack_24 + 0.0;
      fStack_b8 = fStack_70;
      fStack_b0 = fStack_6c + 0.0;
      if (puStack_3c == puStack_44) {
        FUN_007fc130(puStack_44,&fStack_b8);
        puStack_3c = puStack_40;
      }
      else {
        *puStack_44 = CONCAT44(fStack_b4,fStack_70);
        *(float *)(puStack_44 + 1) = fStack_b0;
        puStack_44 = (ulonglong *)((int)puStack_44 + 0xc);
      }
      if (bStack_1d != 0) {
        fStack_c4 = fStack_5c;
        fStack_c0 = fStack_74 - 0.0;
        fStack_bc = fStack_68 - 0.0;
        puStack_24 = puStack_44;
        if (puStack_3c == puStack_44) {
          FUN_007fc130(puStack_44,&fStack_c4);
          puStack_3c = puStack_40;
        }
        else {
          *puStack_44 = CONCAT44(fStack_c0,fStack_5c);
          *(float *)(puStack_44 + 1) = fStack_bc;
          puStack_44 = (ulonglong *)((int)puStack_44 + 0xc);
        }
        fStack_d0 = fStack_70;
        fStack_cc = fStack_74 + 0.0;
        fStack_c8 = fStack_68 + 0.0;
        if (puStack_3c == puStack_44) {
          FUN_007fc130(puStack_44,&fStack_d0);
          puStack_3c = puStack_40;
        }
        else {
          *puStack_44 = CONCAT44(fStack_cc,fStack_70);
          *(float *)(puStack_44 + 1) = fStack_c8;
          puStack_44 = (ulonglong *)((int)puStack_44 + 0xc);
        }
      }
      uVar3 = iStack_80 * (int)param_4 + iStack_84;
      sStack_50 = (short)uVar3;
      if (bStack_1d == 0) {
        sStack_54 = 0;
        sStack_52 = 1;
      }
      else {
        sStack_54 = sStack_50 + 2;
        sStack_52 = sStack_50 + 3;
      }
      fStack_6c = (float)((uVar3 & 0xffff) + 1);
      uStack_4e = SUB42(fStack_6c,0);
      uStack_2c = CONCAT22(sStack_52,sStack_54);
      uStack_28 = CONCAT22(uStack_4e,sStack_50);
      puStack_24 = puStack_44;
      if (0 < (int)param_4) {
        if (puVar6 == puVar5) {
          FUN_00725750(puVar5,&uStack_30);
          puVar6 = puStack_14;
        }
        else {
          *puVar5 = (undefined2)uStack_30;
          puStack_18 = puVar5 + 1;
        }
        if (puVar6 == puStack_18) {
          FUN_00725750(puStack_18,(int)&uStack_30 + 2);
          puVar6 = puStack_14;
        }
        else {
          *puStack_18 = uStack_30._2_2_;
          puStack_18 = puStack_18 + 1;
        }
        if (puVar6 == puStack_18) {
          FUN_00725750(puStack_18,(int)&uStack_28 + 2);
          puVar6 = puStack_14;
        }
        else {
          *puStack_18 = SUB42(fStack_6c,0);
          puStack_18 = puStack_18 + 1;
        }
        if (puVar6 == puStack_18) {
          FUN_00725750(puStack_18,&uStack_30);
          puVar6 = puStack_14;
        }
        else {
          *puStack_18 = (undefined2)uStack_30;
          puStack_18 = puStack_18 + 1;
        }
        if (puVar6 == puStack_18) {
          FUN_00725750(puStack_18,(int)&uStack_28 + 2);
          puVar6 = puStack_14;
        }
        else {
          *puStack_18 = uStack_28._2_2_;
          puStack_18 = puStack_18 + 1;
        }
        if (puVar6 == puStack_18) {
          FUN_00725750(puStack_18,&uStack_28);
          puVar6 = puStack_14;
        }
        else {
          *puStack_18 = (undefined2)uStack_28;
          puStack_18 = puStack_18 + 1;
        }
        if (puVar6 == puStack_18) {
          FUN_00725750(puStack_18,&uStack_34);
          puVar6 = puStack_14;
        }
        else {
          *puStack_18 = (undefined2)uStack_34;
          puStack_18 = puStack_18 + 1;
        }
        if (puVar6 == puStack_18) {
          FUN_00725750(puStack_18,&uStack_30);
          puVar6 = puStack_14;
        }
        else {
          *puStack_18 = (undefined2)uStack_30;
          puStack_18 = puStack_18 + 1;
        }
        if (puVar6 == puStack_18) {
          FUN_00725750(puStack_18,&uStack_28);
          puVar6 = puStack_14;
        }
        else {
          *puStack_18 = (undefined2)uStack_28;
          puStack_18 = puStack_18 + 1;
        }
        if (puVar6 == puStack_18) {
          FUN_00725750(puStack_18,(int)&uStack_34 + 2);
          puVar6 = puStack_14;
        }
        else {
          *puStack_18 = uStack_34._2_2_;
          puStack_18 = puStack_18 + 1;
        }
        if (puVar6 == puStack_18) {
          FUN_00725750(puStack_18,(int)&uStack_28 + 2);
          puVar6 = puStack_14;
        }
        else {
          *puStack_18 = uStack_28._2_2_;
          puStack_18 = puStack_18 + 1;
        }
        if (puVar6 == puStack_18) {
          FUN_00725750(puStack_18,(int)&uStack_30 + 2);
          puVar6 = puStack_14;
        }
        else {
          *puStack_18 = uStack_30._2_2_;
          puStack_18 = puStack_18 + 1;
        }
        puVar5 = puStack_18;
        if (bStack_1d != 0) {
          if (puVar6 == puStack_18) {
            FUN_00725750(puStack_18,&uStack_34);
            puVar6 = puStack_14;
          }
          else {
            *puStack_18 = (undefined2)uStack_34;
            puStack_18 = puStack_18 + 1;
          }
          if (puVar6 == puStack_18) {
            FUN_00725750(puStack_18,(int)&uStack_2c + 2);
            puVar6 = puStack_14;
          }
          else {
            *puStack_18 = uStack_2c._2_2_;
            puStack_18 = puStack_18 + 1;
          }
          if (puVar6 == puStack_18) {
            FUN_00725750(puStack_18,(int)&uStack_34 + 2);
            puVar6 = puStack_14;
          }
          else {
            *puStack_18 = uStack_34._2_2_;
            puStack_18 = puStack_18 + 1;
          }
          if (puVar6 == puStack_18) {
            FUN_00725750(puStack_18,&uStack_34);
            puVar6 = puStack_14;
          }
          else {
            *puStack_18 = (undefined2)uStack_34;
            puStack_18 = puStack_18 + 1;
          }
          if (puVar6 == puStack_18) {
            FUN_00725750(puStack_18,&uStack_2c);
            puVar6 = puStack_14;
          }
          else {
            *puStack_18 = (undefined2)uStack_2c;
            puStack_18 = puStack_18 + 1;
          }
          if (puVar6 == puStack_18) {
            FUN_00725750(puStack_18,(int)&uStack_2c + 2);
            puVar6 = puStack_14;
          }
          else {
            *puStack_18 = uStack_2c._2_2_;
            puStack_18 = puStack_18 + 1;
          }
          if (puVar6 == puStack_18) {
            FUN_00725750(puStack_18,&uStack_34);
            puVar6 = puStack_14;
          }
          else {
            *puStack_18 = (undefined2)uStack_34;
            puStack_18 = puStack_18 + 1;
          }
          if (puVar6 == puStack_18) {
            FUN_00725750(puStack_18,&uStack_28);
            puVar6 = puStack_14;
          }
          else {
            *puStack_18 = (undefined2)uStack_28;
            puStack_18 = puStack_18 + 1;
          }
          if (puVar6 == puStack_18) {
            FUN_00725750(puStack_18,&uStack_2c);
            puVar6 = puStack_14;
          }
          else {
            *puStack_18 = (undefined2)uStack_2c;
            puStack_18 = puStack_18 + 1;
          }
          if (puVar6 == puStack_18) {
            FUN_00725750(puStack_18,(int)&uStack_34 + 2);
            puVar6 = puStack_14;
          }
          else {
            *puStack_18 = uStack_34._2_2_;
            puStack_18 = puStack_18 + 1;
          }
          if (puVar6 == puStack_18) {
            FUN_00725750(puStack_18,(int)&uStack_2c + 2);
            puVar6 = puStack_14;
          }
          else {
            *puStack_18 = uStack_2c._2_2_;
            puStack_18 = puStack_18 + 1;
          }
          if (puVar6 == puStack_18) {
            FUN_00725750(puStack_18,(int)&uStack_28 + 2);
            puVar5 = puStack_18;
            puVar6 = puStack_14;
          }
          else {
            *puStack_18 = uStack_28._2_2_;
            puStack_18 = puStack_18 + 1;
            puVar5 = puStack_18;
          }
        }
      }
      uStack_34 = uStack_2c;
      uStack_30 = uStack_28;
      if (param_4 == (float)uStack_88) {
        fVar10 = fStack_8c * fStack_60 + fStack_90 * fStack_64;
        fStack_60 = fStack_90 * fStack_60 - fStack_8c * fStack_64;
        fVar8 = param_6;
      }
      else {
        fVar10 = fStack_94 * fStack_60 + fStack_98 * fStack_64;
        fStack_60 = fStack_98 * fStack_60 - fStack_94 * fStack_64;
        fVar8 = fStack_78;
      }
      param_4 = (float)((int)param_4 + 1);
      fVar8 = fStack_9c + fVar8;
      fStack_64 = fVar10;
    } while ((int)param_4 < iStack_7c);
  }
  if (bStack_35 != 0) {
    param_4 = 0.0;
    if (bStack_1d == 0) {
      if (puVar6 == puVar5) {
        FUN_00725750(puVar5,&param_4);
        puVar6 = puStack_14;
      }
      else {
        *puVar5 = 0;
        puStack_18 = puVar5 + 1;
      }
      param_4 = 4.2039e-45;
      if (puVar6 == puStack_18) {
        FUN_00725750(puStack_18,&param_4);
        puVar6 = puStack_14;
      }
      else {
        *puStack_18 = 3;
        puStack_18 = puStack_18 + 1;
      }
      param_4 = 2.8026e-45;
      if (puVar6 == puStack_18) {
        FUN_00725750(puStack_18,&param_4);
        puVar6 = puStack_14;
      }
      else {
        *puStack_18 = 2;
        puStack_18 = puStack_18 + 1;
      }
      param_4 = 0.0;
      if (puVar6 == puStack_18) {
        FUN_00725750(puStack_18,&param_4);
        puVar6 = puStack_14;
      }
      else {
        *puStack_18 = 0;
        puStack_18 = puStack_18 + 1;
      }
      param_4 = 1.4013e-45;
      if (puVar6 == puStack_18) {
        FUN_00725750(puStack_18,&param_4);
        puVar6 = puStack_14;
      }
      else {
        *puStack_18 = 1;
        puStack_18 = puStack_18 + 1;
      }
      param_4 = 4.2039e-45;
      if (puVar6 == puStack_18) {
        FUN_00725750(puStack_18,&param_4);
        puVar6 = puStack_14;
      }
      else {
        *puStack_18 = 3;
        puStack_18 = puStack_18 + 1;
      }
      param_4 = 0.0;
      if (puVar6 == puStack_18) {
        FUN_00725750(puStack_18,&param_4);
        puVar6 = puStack_14;
      }
      else {
        *puStack_18 = 0;
        puStack_18 = puStack_18 + 1;
      }
      param_4 = (float)(((int)puStack_24 - iStack_48) / 0xc & 0xffff);
      param_6 = (float)((int)param_4 - 1U & 0xffff);
      if (puVar6 == puStack_18) {
        FUN_00725750(puStack_18,&param_6);
        puVar6 = puStack_14;
      }
      else {
        *puStack_18 = (short)((int)param_4 - 1U);
        puStack_18 = puStack_18 + 1;
      }
      param_6 = 1.4013e-45;
      if (puVar6 == puStack_18) {
        FUN_00725750(puStack_18,&param_6);
        puVar6 = puStack_14;
      }
      else {
        *puStack_18 = 1;
        puStack_18 = puStack_18 + 1;
      }
      param_6 = 0.0;
      if (puVar6 == puStack_18) {
        FUN_00725750(puStack_18,&param_6);
        puVar6 = puStack_14;
      }
      else {
        *puStack_18 = 0;
        puStack_18 = puStack_18 + 1;
      }
      param_6 = (float)((int)param_4 - 2U & 0xffff);
      if (puVar6 == puStack_18) {
        FUN_00725750(puStack_18,&param_6);
        puVar6 = puStack_14;
      }
      else {
        *puStack_18 = (short)((int)param_4 - 2U);
        puStack_18 = puStack_18 + 1;
      }
    }
    else {
      if (puVar6 == puVar5) {
        FUN_00725750(puVar5,&param_4);
        puVar6 = puStack_14;
      }
      else {
        *puVar5 = 0;
        puStack_18 = puVar5 + 1;
      }
      param_4 = 2.8026e-45;
      if (puVar6 == puStack_18) {
        FUN_00725750(puStack_18,&param_4);
        puVar6 = puStack_14;
      }
      else {
        *puStack_18 = 2;
        puStack_18 = puStack_18 + 1;
      }
      param_4 = 4.2039e-45;
      if (puVar6 == puStack_18) {
        FUN_00725750(puStack_18,&param_4);
        puVar6 = puStack_14;
      }
      else {
        *puStack_18 = 3;
        puStack_18 = puStack_18 + 1;
      }
      param_4 = 0.0;
      if (puVar6 == puStack_18) {
        FUN_00725750(puStack_18,&param_4);
        puVar6 = puStack_14;
      }
      else {
        *puStack_18 = 0;
        puStack_18 = puStack_18 + 1;
      }
      param_4 = 4.2039e-45;
      if (puVar6 == puStack_18) {
        FUN_00725750(puStack_18,&param_4);
        puVar6 = puStack_14;
      }
      else {
        *puStack_18 = 3;
        puStack_18 = puStack_18 + 1;
      }
      param_4 = 1.4013e-45;
      if (puVar6 == puStack_18) {
        FUN_00725750(puStack_18,&param_4);
        puVar6 = puStack_14;
      }
      else {
        *puStack_18 = 1;
        puStack_18 = puStack_18 + 1;
      }
      param_4 = (float)(((int)puStack_24 - iStack_48) / 0xc & 0xffff);
      param_6 = (float)((int)param_4 - 4U & 0xffff);
      if (puVar6 == puStack_18) {
        FUN_00725750(puStack_18,&param_6);
        puVar6 = puStack_14;
      }
      else {
        *puStack_18 = (short)((int)param_4 - 4U);
        puStack_18 = puStack_18 + 1;
      }
      param_6 = (float)((int)param_4 - 1U & 0xffff);
      if (puVar6 == puStack_18) {
        FUN_00725750(puStack_18,&param_6);
        puVar6 = puStack_14;
      }
      else {
        *puStack_18 = (short)((int)param_4 - 1U);
        puStack_18 = puStack_18 + 1;
      }
      param_6 = (float)((int)param_4 - 2U & 0xffff);
      if (puVar6 == puStack_18) {
        FUN_00725750(puStack_18,&param_6);
        puVar6 = puStack_14;
      }
      else {
        *puStack_18 = (short)((int)param_4 - 2U);
        puStack_18 = puStack_18 + 1;
      }
      param_6 = (float)((int)param_4 - 4U & 0xffff);
      if (puVar6 == puStack_18) {
        FUN_00725750(puStack_18,&param_6);
        puVar6 = puStack_14;
      }
      else {
        *puStack_18 = (short)((int)param_4 - 4U);
        puStack_18 = puStack_18 + 1;
      }
      param_6 = (float)((int)param_4 - 3U & 0xffff);
      if (puVar6 == puStack_18) {
        FUN_00725750(puStack_18,&param_6);
        puVar6 = puStack_14;
      }
      else {
        *puStack_18 = (short)((int)param_4 - 3U);
        puStack_18 = puStack_18 + 1;
      }
    }
    uVar3 = (int)param_4 - 1;
    param_4 = (float)(uVar3 & 0xffff);
    if (puVar6 == puStack_18) {
      FUN_00725750(puStack_18,&param_4);
      puVar5 = puStack_18;
      puVar6 = puStack_14;
    }
    else {
      *puStack_18 = (short)uVar3;
      puStack_18 = puStack_18 + 1;
      puVar5 = puStack_18;
    }
  }
  iVar2 = iStack_48;
  if ((param_9 == 4) || (param_4 = (float)((uint)param_4 & 0xffffff00), param_9 == 3)) {
    param_4 = (float)CONCAT31(param_4._1_3_,1);
  }
  param_6 = 0.0;
  if (param_8 < 0xb) {
    puVar4 = &param_6;
    if (-1 < param_8) {
      puVar4 = &param_8;
    }
  }
  else {
    puVar4 = &DAT_01900ed4;
  }
  FUN_007fb350(param_7,param_2,iStack_48,((int)puStack_24 - iStack_48) / 0xc,iStack_1c,
               (int)puVar5 - iStack_1c >> 1,DAT_018ce2f8 <= *(float *)(param_7 + 0xc),*puVar4,
               param_4);
  if (iStack_1c != 0) {
    FUN_00554a60(iStack_1c,(int)puVar6 - iStack_1c >> 1);
  }
  if (iVar2 != 0) {
    FUN_0061a4e0(iVar2,((int)puStack_3c - iVar2) / 0xc);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12288 ; VA 0x007fedc0 ; FUN_007fedc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_007fedc0(int param_1,int param_2,float param_3,float param_4,char param_5,undefined4 param_6,
            undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined4 uStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  fStack_14 = param_3;
  if (param_5 == '\0') {
    if (param_3 < param_4) {
      fStack_14 = param_4;
    }
    uStack_18 = *(undefined4 *)(param_2 + 0x2c);
    uVar2 = *(undefined4 *)(param_1 + 0x18);
    uVar1 = *(undefined4 *)(param_1 + 0xf8);
  }
  else {
    if (param_3 < param_4) {
      fStack_14 = param_4;
    }
    uStack_18 = *(undefined4 *)(param_2 + 0x2c);
    uVar2 = *(undefined4 *)(param_1 + 0x18);
    uVar1 = *(undefined4 *)(param_1 + 0xfc);
  }
  fStack_14 = fStack_14 * _DAT_019011b8;
  uStack_20 = *(undefined8 *)(param_2 + 0x24);
  fStack_10 = param_4;
  fStack_c = param_3;
  fStack_8 = param_3;
  FUN_00804740(uVar1,uVar2,(undefined8 *)(param_2 + 0x24),param_2,&fStack_10,param_6,&uStack_20,
               &uStack_30,param_7,param_8);
  return;
}



/* FUNCTION 12289 ; VA 0x007fee90 ; FUN_007fee90 */

/* WARNING: Function: __alloca_probe_16 replaced with injection: alloca_probe */
/* WARNING: Unable to track spacebase fully for stack */

void __thiscall FUN_007fee90(int param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  short sVar2;
  int iVar3;
  int iVar4;
  int aiStack_3c [5];
  undefined auStack_28 [4];
  int aiStack_24 [4];
  
  aiStack_24[3] = 0x7feeaa;
  iVar1 = (param_3 + -2) * -6;
  iVar4 = 0;
  iVar3 = 1;
  if (1 < param_3 + -1) {
    do {
      *(undefined2 *)(&stack0xffffffec + iVar4 * 2 + iVar1) = 0;
      sVar2 = (short)iVar3;
      iVar3 = iVar3 + 1;
      *(short *)(&stack0xffffffee + iVar4 * 2 + iVar1) = sVar2;
      *(short *)(&stack0xfffffff0 + iVar4 * 2 + iVar1) = sVar2 + 1;
      iVar4 = iVar4 + 3;
    } while (iVar3 < param_3 + -1);
  }
  *(undefined4 *)((int)aiStack_24 + iVar1 + 0xc) = 0;
  *(undefined4 *)((int)aiStack_24 + iVar1 + 8) = 0xffffffff;
  *(undefined4 *)((int)aiStack_24 + iVar1 + 4) = 0;
  *(int *)((int)aiStack_24 + iVar1) = iVar4;
  *(undefined **)(auStack_28 + iVar1) = &stack0xffffffec + iVar1;
  *(int *)(auStack_28 + iVar1 + -4) = param_3;
  *(undefined4 *)(auStack_28 + iVar1 + -8) = param_2;
  *(int *)((int)aiStack_3c + iVar1 + 8) = param_1 + 0x60;
  *(undefined4 *)((int)aiStack_3c + iVar1 + 4) = param_4;
  *(undefined4 *)((int)aiStack_3c + iVar1) = 0x7feefa;
  FUN_007fb350();
  return;
}



/* FUNCTION 12290 ; VA 0x007fef10 ; FUN_007fef10 */

/* WARNING: Function: __alloca_probe_16 replaced with injection: alloca_probe */
/* WARNING: Unable to track spacebase fully for stack */

void __thiscall FUN_007fef10(int param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  short sVar2;
  short *psVar3;
  int iVar4;
  int aiStack_3c [5];
  undefined auStack_28 [4];
  int aiStack_24 [4];
  
  aiStack_24[3] = 0x7fef27;
  iVar1 = param_3 * -6;
  iVar4 = 0;
  if (0 < param_3) {
    psVar3 = (short *)(&stack0xfffffff0 + iVar1);
    do {
      sVar2 = (short)iVar4 * 3;
      iVar4 = iVar4 + 1;
      psVar3[-2] = sVar2;
      psVar3[-1] = sVar2 + 1;
      *psVar3 = sVar2 + 2;
      psVar3 = psVar3 + 3;
    } while (iVar4 < param_3);
  }
  *(undefined4 *)((int)aiStack_24 + iVar1 + 0xc) = 0;
  *(undefined4 *)((int)aiStack_24 + iVar1 + 8) = 0xffffffff;
  *(undefined4 *)((int)aiStack_24 + iVar1 + 4) = 1;
  *(int *)((int)aiStack_24 + iVar1) = param_3 * 3;
  *(undefined **)(auStack_28 + iVar1) = &stack0xffffffec + iVar1;
  *(int *)(auStack_28 + iVar1 + -4) = param_3 * 3;
  *(undefined4 *)(auStack_28 + iVar1 + -8) = param_2;
  *(int *)((int)aiStack_3c + iVar1 + 8) = param_1 + 0x60;
  *(undefined4 *)((int)aiStack_3c + iVar1 + 4) = param_4;
  *(undefined4 *)((int)aiStack_3c + iVar1) = 0x7fef6f;
  FUN_007fb350();
  return;
}



/* FUNCTION 12291 ; VA 0x007fef80 ; FUN_007fef80 */

undefined4 * __thiscall FUN_007fef80(undefined4 *param_1,undefined4 *param_2,uint param_3)

{
  switch(param_3 & 3) {
  case 0:
    *param_2 = *param_1;
    param_2[1] = param_1[1];
    return param_2;
  case 1:
    *param_2 = param_1[2];
    param_2[1] = param_1[1];
    return param_2;
  case 2:
    *param_2 = param_1[2];
    param_2[1] = param_1[3];
    return param_2;
  case 3:
    *param_2 = *param_1;
    param_2[1] = param_1[3];
    return param_2;
  }
}



/* FUNCTION 12292 ; VA 0x007ff000 ; FUN_007ff000 */

undefined4 FUN_007ff000(int *param_1,undefined4 param_2,int *param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  int iVar4;
  undefined4 uVar5;
  undefined auStack_2c [4];
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b4ad8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  (**(code **)(*param_1 + 0x3c))(&piStack_24,0,param_3[1] - *param_3 & 0xffffffe0,0x20,0);
  uStack_8 = 0;
  (**(code **)(*piStack_24 + 0x18))(0,*param_3,param_3[1] - *param_3 & 0xffffffe0);
  (**(code **)(*param_1 + 0x3c))(&piStack_1c,1,(param_4[1] - *param_4 >> 1) * 2,2,0);
  uStack_8._0_1_ = 1;
  (**(code **)(*piStack_1c + 0x18))(0,*param_4,(param_4[1] - *param_4 >> 1) * 2);
  iVar4 = FUN_01674e20(0x18);
  uStack_8._0_1_ = 2;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (iVar4 == 0) {
    uVar5 = 0;
    uStack_8._0_1_ = uVar3;
  }
  else {
    iVar4 = param_4[1];
    iVar2 = *param_4;
    uVar5 = FUN_0147c0e0(auStack_2c,param_2,&piStack_24,&piStack_1c);
    uStack_14 = 1;
    uStack_8._0_1_ = 3;
    uVar5 = FUN_0147c720(uVar5,0,0,0,iVar4 - iVar2 >> 1);
  }
  if (((uStack_14 & 1) != 0) && (piStack_28 != (int *)0x0)) {
    LOCK();
    iVar4 = piStack_28[1] + -1;
    piStack_28[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      iVar4 = piStack_28[2] + -1;
      piStack_28[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_18[1] + -1;
    piStack_18[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar4 = piStack_18[2] + -1;
      piStack_18[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_20[1] + -1;
    piStack_20[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 12293 ; VA 0x007ff190 ; FUN_007ff190 */

undefined4 FUN_007ff190(undefined4 param_1,undefined4 param_2)

{
  ulonglong uVar1;
  short *psVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  undefined *puVar6;
  undefined4 *puVar7;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 *puStack_60;
  undefined8 uStack_5c;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  int iStack_3c;
  undefined8 uStack_38;
  uint uStack_30;
  uint uStack_2c;
  undefined *puStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  int iStack_1c;
  short *psStack_18;
  short *psStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b4b0b;
  pvStack_10 = ExceptionList;
  uStack_6c = 0x3f800000;
  uStack_68 = 0x3f800000;
  uStack_64 = 0x3f800000;
  puStack_28 = &DAT_bf800000;
  puStack_24 = (undefined4 *)&DAT_bf800000;
  puStack_20 = (undefined4 *)&DAT_bf800000;
  ExceptionList = &pvStack_10;
  FUN_00d54e20(&puStack_28,&uStack_6c);
  puVar7 = (undefined4 *)0x0;
  puStack_28 = (undefined *)0x0;
  puStack_24 = (undefined4 *)0x0;
  puStack_20 = (undefined4 *)0x0;
  iStack_1c = 0;
  psStack_18 = (short *)0x0;
  psStack_14 = (short *)0x0;
  uStack_8 = 2;
  iStack_3c = 0;
  puStack_60 = &DAT_019843f4;
  do {
    psVar2 = psStack_18;
    uStack_38 = (ulonglong)(uint)puStack_60[-1];
    uStack_30 = *puStack_60;
    uStack_64 = puStack_60[1];
    uStack_78 = 0;
    uStack_74 = 0;
    uStack_70 = 0;
    uStack_84 = 0;
    uStack_80 = 0;
    uStack_7c = 0;
    uStack_90 = 0;
    uStack_8c = 0;
    uStack_88 = 0;
    uStack_9c = 0;
    uStack_98 = 0;
    uStack_94 = 0;
    FUN_00d54ef0(iStack_3c,&uStack_78,&uStack_84,&uStack_90,&uStack_9c);
    uStack_5c = CONCAT44(uStack_74,uStack_78);
    uStack_48 = CONCAT44(uStack_30,(int)uStack_38);
    uStack_54 = uStack_70;
    uStack_50 = 0;
    uStack_4c = 0;
    uStack_40 = uStack_64;
    if (puStack_20 == puVar7) {
      uStack_38 = uStack_48;
      FUN_007fc010(puVar7,&uStack_5c);
    }
    else {
      *puVar7 = uStack_78;
      puVar7[1] = uStack_74;
      puVar7[2] = uStack_70;
      puVar7[3] = 0;
      puVar7[4] = 0;
      puVar7[5] = (int)uStack_38;
      puVar7[6] = uStack_30;
      puVar7[7] = uStack_64;
      puStack_24 = puVar7 + 8;
      uStack_38 = uStack_48;
    }
    uStack_5c = CONCAT44(uStack_80,uStack_84);
    uStack_54 = uStack_7c;
    uStack_50 = 0;
    uStack_4c = 0;
    uStack_40 = uStack_64;
    if (puStack_20 == puStack_24) {
      uStack_48 = uStack_38;
      FUN_007fc010(puStack_24,&uStack_5c);
    }
    else {
      *puStack_24 = uStack_84;
      puStack_24[1] = uStack_80;
      puStack_24[2] = uStack_7c;
      puStack_24[3] = 0;
      uStack_48._0_4_ = (undefined4)uStack_38;
      uStack_48._4_4_ = (undefined4)(uStack_38 >> 0x20);
      puStack_24[4] = 0;
      puStack_24[5] = (undefined4)uStack_48;
      puStack_24[6] = uStack_48._4_4_;
      puStack_24[7] = uStack_64;
      puStack_24 = puStack_24 + 8;
    }
    uStack_5c = CONCAT44(uStack_8c,uStack_90);
    uStack_54 = uStack_88;
    uStack_50 = 0;
    uStack_4c = 0;
    uStack_40 = uStack_64;
    if (puStack_20 == puStack_24) {
      uStack_48 = uStack_38;
      FUN_007fc010(puStack_24,&uStack_5c);
    }
    else {
      *puStack_24 = uStack_90;
      puStack_24[1] = uStack_8c;
      puStack_24[2] = uStack_88;
      puStack_24[3] = 0;
      uStack_48._0_4_ = (undefined4)uStack_38;
      uStack_48._4_4_ = (undefined4)(uStack_38 >> 0x20);
      puStack_24[4] = 0;
      puStack_24[5] = (undefined4)uStack_48;
      puStack_24[6] = uStack_48._4_4_;
      puStack_24[7] = uStack_64;
      puStack_24 = puStack_24 + 8;
    }
    uStack_5c = CONCAT44(uStack_98,uStack_9c);
    uStack_54 = uStack_94;
    uStack_50 = 0;
    uStack_4c = 0;
    uStack_40 = uStack_64;
    uStack_48 = uStack_38;
    if (puStack_20 == puStack_24) {
      FUN_007fc010(puStack_24,&uStack_5c);
    }
    else {
      *puStack_24 = uStack_9c;
      puStack_24[1] = uStack_98;
      puStack_24[2] = uStack_94;
      puStack_24[3] = 0;
      uStack_48._0_4_ = (undefined4)uStack_38;
      uStack_48._4_4_ = (undefined4)(uStack_38 >> 0x20);
      puStack_24[4] = 0;
      puStack_24[5] = (undefined4)uStack_48;
      puStack_24[6] = uStack_48._4_4_;
      puStack_24[7] = uStack_64;
      puStack_24 = puStack_24 + 8;
    }
    puVar7 = puStack_24;
    uStack_30 = iStack_3c << 2;
    uStack_2c = uStack_30 & 0xffff;
    if (psStack_14 == psVar2) {
      FUN_00725750(psVar2,&uStack_2c);
    }
    else {
      *psVar2 = (short)uStack_30;
      psStack_18 = psVar2 + 1;
    }
    uStack_2c = uStack_30 + 1 & 0xffff;
    if (psStack_14 == psStack_18) {
      FUN_00725750(psStack_18,&uStack_2c);
    }
    else {
      *psStack_18 = (short)uStack_30 + 1;
      psStack_18 = psStack_18 + 1;
    }
    uStack_38 = CONCAT44(uStack_30 + 2,(undefined4)uStack_38);
    uStack_2c = uStack_30 + 2 & 0xffff;
    if (psStack_14 == psStack_18) {
      FUN_00725750(psStack_18,&uStack_2c);
    }
    else {
      *psStack_18 = (short)uStack_30 + 2;
      psStack_18 = psStack_18 + 1;
    }
    uStack_2c = uStack_30 & 0xffff;
    if (psStack_14 == psStack_18) {
      FUN_00725750(psStack_18,&uStack_2c);
    }
    else {
      *psStack_18 = (short)uStack_30;
      psStack_18 = psStack_18 + 1;
    }
    uVar1 = uStack_38;
    uStack_38 = uStack_38 & 0xffffffffffff;
    if (psStack_14 == psStack_18) {
      FUN_00725750(psStack_18,(int)&uStack_38 + 4);
    }
    else {
      *psStack_18 = (short)(uVar1 >> 0x20);
      psStack_18 = psStack_18 + 1;
    }
    iVar5 = iStack_3c * 4 + 3;
    uStack_38 = CONCAT44(iVar5,(undefined4)uStack_38) & 0xffffffffffff;
    if (psStack_14 == psStack_18) {
      FUN_00725750(psStack_18,(int)&uStack_38 + 4);
    }
    else {
      *psStack_18 = (short)iVar5;
      psStack_18 = psStack_18 + 1;
    }
    puStack_60 = puStack_60 + 3;
    iStack_3c = iStack_3c + 1;
  } while ((int)puStack_60 < 0x198443c);
  uVar3 = FUN_007ff000(param_1,param_2,&puStack_28,&iStack_1c);
  if (iStack_1c != 0) {
    uVar4 = (int)psStack_14 - iStack_1c & 0xfffffffe;
    iVar5 = iStack_1c;
    if (0xfff < uVar4) {
      iVar5 = *(int *)(iStack_1c + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iStack_1c - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar4);
  }
  if (puStack_28 != (undefined *)0x0) {
    uVar4 = (int)puStack_20 - (int)puStack_28 & 0xffffffe0;
    puVar6 = puStack_28;
    if (0xfff < uVar4) {
      puVar6 = *(undefined **)(puStack_28 + -4);
      uVar4 = uVar4 + 0x23;
      if ((undefined *)0x1f < puStack_28 + (-4 - (int)puVar6)) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar6,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 12294 ; VA 0x007ff620 ; FUN_007ff620 */

undefined4 FUN_007ff620(undefined4 param_1,undefined4 param_2,char param_3)

{
  float *pfVar1;
  undefined8 uVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  short *psVar6;
  undefined4 *puVar7;
  double dVar8;
  float fVar9;
  uint uVar10;
  float fStack_e8;
  float fStack_e4;
  float fStack_e0;
  undefined8 uStack_dc;
  float fStack_d4;
  undefined8 uStack_d0;
  float fStack_c8;
  float afStack_c4 [3];
  undefined8 uStack_b8;
  float fStack_ac;
  float fStack_a8;
  float fStack_a4;
  undefined4 uStack_a0;
  float fStack_9c;
  float fStack_98;
  undefined4 uStack_94;
  float fStack_90;
  float fStack_8c;
  undefined4 uStack_88;
  float fStack_84;
  float fStack_80;
  int iStack_7c;
  float fStack_78;
  float fStack_74;
  float fStack_70;
  float *pfStack_6c;
  float fStack_68;
  float fStack_64;
  uint uStack_60;
  undefined8 uStack_5c;
  float fStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  float fStack_40;
  int iStack_3c;
  undefined4 *puStack_38;
  undefined4 *puStack_34;
  undefined4 uStack_30;
  short *psStack_2c;
  short *psStack_28;
  float fStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  puStack_18 = &LAB_017b4b30;
  pvStack_1c = ExceptionList;
  iStack_7c = 0xc;
  iStack_3c = 0;
  if (DAT_01d61ed4 != '\0') {
    iStack_7c = 0x18;
  }
  puStack_38 = (undefined4 *)0x0;
  puStack_34 = (undefined4 *)0x0;
  uStack_30 = 0;
  psStack_2c = (short *)0x0;
  psStack_28 = (short *)0x0;
  uStack_14 = 1;
  fStack_a4 = DAT_019011e0 / (float)iStack_7c;
  dVar8 = (double)(fStack_a4 * DAT_0190119c);
  ExceptionList = &pvStack_1c;
  uStack_b8 = dVar8;
  FUN_01728390();
  fStack_a8 = (float)dVar8;
  dVar8 = uStack_b8;
  FUN_017279f0();
  fStack_ac = (float)dVar8;
  afStack_c4[2] = 0.0;
  fStack_54 = 0.0;
  fStack_40 = 0.0;
  fStack_c8 = 0.0;
  uStack_50 = 0;
  fStack_68 = 0.0;
  uStack_5c = 0;
  uStack_48 = (ulonglong)DAT_018f7864;
  pfStack_6c = (float *)0x0;
  fStack_64 = DAT_018ce2f8;
  uStack_4c = 0;
  FUN_007fc010(0,&uStack_5c);
  uStack_88 = 0;
  uStack_94 = 0;
  uStack_a0 = 0x3f800000;
  fStack_9c = 0.0;
  fStack_98 = 0.0;
  iVar3 = 0;
  psVar6 = (short *)0x0;
  puVar7 = puStack_38;
  while( true ) {
    uStack_b8 = (double)CONCAT44(iVar3 + 1,(undefined4)uStack_b8);
    if (iVar3 + 1 < iStack_7c) {
      fStack_e8 = (float)pfStack_6c + fStack_a4;
      pfStack_6c = &fStack_e8;
      fStack_e4 = fStack_64 * fStack_a8 + fStack_68 * fStack_ac;
      fStack_e0 = fStack_64 * fStack_ac - fStack_68 * fStack_a8;
    }
    else {
      afStack_c4[0] = 0.0;
      pfStack_6c = afStack_c4;
      afStack_c4[1] = 0.0;
      afStack_c4[2] = 1.0;
    }
    uVar2 = *(undefined8 *)pfStack_6c;
    fStack_c8 = pfStack_6c[2];
    uStack_d0._4_4_ = (float)((ulonglong)uVar2 >> 0x20);
    fStack_74 = uStack_d0._4_4_;
    fStack_90 = uStack_d0._4_4_;
    uStack_60 = (int)puVar7 - iStack_3c >> 5 & 0xffff;
    uStack_5c = CONCAT44(fStack_68,uStack_88);
    uStack_50 = 0;
    uStack_4c = 0;
    uStack_d0 = uVar2;
    fStack_8c = fStack_c8;
    fStack_84 = fStack_68;
    fStack_80 = fStack_64;
    fStack_78 = fStack_c8;
    if (puStack_34 == puVar7) {
      fStack_54 = fStack_64;
      uStack_48 = uStack_5c;
      fStack_40 = fStack_64;
      FUN_007fc010(puVar7,&uStack_5c);
    }
    else {
      *puVar7 = uStack_88;
      puVar7[1] = fStack_68;
      puVar7[2] = fStack_64;
      puVar7[3] = 0;
      puVar7[4] = 0;
      puVar7[5] = uStack_88;
      puVar7[6] = fStack_68;
      puVar7[7] = fStack_64;
      puStack_38 = puVar7 + 8;
    }
    uStack_5c = CONCAT44(fStack_90,uStack_94);
    fStack_54 = fStack_8c;
    uStack_50 = 0;
    uStack_4c = 0;
    fStack_40 = fStack_8c;
    if (puStack_34 == puStack_38) {
      uStack_48 = uStack_5c;
      FUN_007fc010(puStack_38,&uStack_5c);
    }
    else {
      *puStack_38 = uStack_94;
      puStack_38[1] = fStack_90;
      puStack_38[2] = fStack_8c;
      puStack_38[3] = 0;
      puStack_38[4] = 0;
      puStack_38[5] = uStack_94;
      puStack_38[6] = fStack_90;
      puStack_38[7] = fStack_8c;
      puStack_38 = puStack_38 + 8;
      uStack_48 = uStack_5c;
    }
    puVar7 = puStack_38;
    fStack_70 = fStack_74 + fStack_68;
    fStack_24 = fStack_78 + fStack_64;
    dVar8 = (double)(fStack_70 * fStack_70 + DAT_018ce2f0 + fStack_24 * fStack_24);
    FUN_017267a0();
    fStack_54 = fStack_98;
    uStack_50 = 0;
    uStack_4c = 0;
    fVar9 = DAT_018ce2f8 / (float)dVar8;
    fStack_40 = fVar9 * fStack_24;
    fStack_70 = fVar9 * fStack_70;
    fVar9 = fVar9 * 0.0;
    uStack_5c = CONCAT44(fStack_9c,uStack_a0);
    uStack_48 = CONCAT44(fStack_70,fVar9);
    fStack_24 = fStack_40;
    if (puStack_34 == puVar7) {
      FUN_007fc010(puVar7,&uStack_5c);
    }
    else {
      *puVar7 = uStack_a0;
      puVar7[1] = fStack_9c;
      puVar7[2] = fStack_98;
      puVar7[3] = 0;
      puVar7[4] = 0;
      puVar7[5] = fVar9;
      puVar7[6] = fStack_70;
      puVar7[7] = fStack_40;
      puStack_38 = puVar7 + 8;
    }
    uVar4 = DAT_018f9988;
    uVar10 = DAT_018f7864;
    uVar5 = DAT_018c4ea0;
    uStack_50 = 0;
    uStack_4c = 0;
    fStack_54 = fStack_80;
    if (param_3 == '\0') {
      uStack_5c = CONCAT44(fStack_84,uStack_88);
      uStack_48 = (ulonglong)DAT_018f7864;
      fStack_40 = 0.0;
      if (puStack_34 == puStack_38) {
        FUN_007fc010(puStack_38,&uStack_5c);
      }
      else {
        *puStack_38 = uStack_88;
        puStack_38[1] = fStack_84;
        puStack_38[2] = fStack_80;
        puStack_38[3] = 0;
        puStack_38[4] = 0;
        puStack_38[5] = uVar10;
        puStack_38[6] = 0;
        puStack_38[7] = 0;
        puStack_38 = puStack_38 + 8;
      }
      uStack_5c._0_4_ = uStack_94;
      uStack_5c._4_4_ = fStack_90;
      fStack_54 = fStack_8c;
      fStack_40 = 0.0;
      uStack_48._4_4_ = 0;
      uStack_48._0_4_ = DAT_018f7864;
    }
    else {
      fStack_40 = (float)((uint)fStack_64 ^ DAT_018c4ea0);
      uVar10 = (uint)fStack_68 ^ DAT_018c4ea0;
      uStack_5c = CONCAT44(fStack_84,uStack_88);
      uStack_48 = CONCAT44(uVar10,DAT_018f9988);
      if (puStack_34 == puStack_38) {
        FUN_007fc010(puStack_38,&uStack_5c);
        uVar5 = DAT_018c4ea0;
      }
      else {
        *puStack_38 = uStack_88;
        puStack_38[1] = fStack_84;
        puStack_38[2] = fStack_80;
        puStack_38[3] = 0;
        puStack_38[4] = 0;
        puStack_38[5] = uVar4;
        puStack_38[6] = uVar10;
        puStack_38[7] = fStack_40;
        puStack_38 = puStack_38 + 8;
      }
      uVar4 = DAT_018f9988;
      fStack_40 = (float)((uint)fStack_78 ^ uVar5);
      uStack_5c = CONCAT44(fStack_90,uStack_94);
      fStack_54 = fStack_8c;
      uStack_48 = CONCAT44((uint)fStack_74 ^ uVar5,DAT_018f9988);
      uStack_50 = 0;
      uStack_4c = 0;
      if (puStack_34 == puStack_38) {
        FUN_007fc010(puStack_38,&uStack_5c);
        uVar5 = DAT_018c4ea0;
      }
      else {
        *puStack_38 = uStack_94;
        puStack_38[1] = fStack_90;
        puStack_38[2] = fStack_8c;
        puStack_38[3] = 0;
        puStack_38[4] = 0;
        puStack_38[5] = uVar4;
        puStack_38[6] = (uint)fStack_74 ^ uVar5;
        puStack_38[7] = fStack_40;
        puStack_38 = puStack_38 + 8;
      }
      fStack_40 = (float)((uint)fStack_24 ^ uVar5);
      uStack_48._0_4_ = (uint)fVar9 ^ uVar5;
      uStack_48._4_4_ = (uint)fStack_70 ^ uVar5;
      fStack_54 = fStack_98;
      uStack_5c._0_4_ = uStack_a0;
      uStack_5c._4_4_ = fStack_9c;
    }
    uStack_4c = 0;
    uStack_50 = 0;
    if (puStack_34 == puStack_38) {
      FUN_007fc010(puStack_38,&uStack_5c);
    }
    else {
      *puStack_38 = (undefined4)uStack_5c;
      puStack_38[1] = uStack_5c._4_4_;
      puStack_38[2] = fStack_54;
      puStack_38[3] = 0;
      puStack_38[4] = 0;
      puStack_38[5] = (uint)uStack_48;
      puStack_38[6] = uStack_48._4_4_;
      puStack_38[7] = fStack_40;
      puStack_38 = puStack_38 + 8;
    }
    puVar7 = puStack_38;
    fStack_24 = (float)(uStack_60 & 0xffff);
    if (psStack_28 == psVar6) {
      FUN_00725750(psVar6,&fStack_24);
    }
    else {
      *psVar6 = (short)uStack_60;
      psStack_2c = psVar6 + 1;
    }
    fStack_24 = (float)(uStack_60 + 2 & 0xffff);
    if (psStack_28 == psStack_2c) {
      FUN_00725750(psStack_2c,&fStack_24);
    }
    else {
      *psStack_2c = (short)uStack_60 + 2;
      psStack_2c = psStack_2c + 1;
    }
    fStack_24 = (float)(uStack_60 + 1 & 0xffff);
    if (psStack_28 == psStack_2c) {
      FUN_00725750(psStack_2c,&fStack_24);
    }
    else {
      *psStack_2c = (short)uStack_60 + 1;
      psStack_2c = psStack_2c + 1;
    }
    if (param_3 == '\0') {
      fStack_24 = 0.0;
      if (psStack_28 == psStack_2c) {
        FUN_00725750(psStack_2c,&fStack_24);
      }
      else {
        *psStack_2c = 0;
        psStack_2c = psStack_2c + 1;
      }
      fStack_24 = (float)(uStack_60 + 3 & 0xffff);
      if (psStack_28 == psStack_2c) {
        FUN_00725750(psStack_2c,&fStack_24);
        uVar5 = uStack_60 + 4;
      }
      else {
        *psStack_2c = (short)(uStack_60 + 3);
        psStack_2c = psStack_2c + 1;
        uVar5 = uStack_60 + 4;
      }
    }
    else {
      fStack_24 = (float)(uStack_60 + 3 & 0xffff);
      if (psStack_28 == psStack_2c) {
        FUN_00725750(psStack_2c,&fStack_24);
      }
      else {
        *psStack_2c = (short)uStack_60 + 3;
        psStack_2c = psStack_2c + 1;
      }
      fStack_24 = (float)(uStack_60 + 4 & 0xffff);
      if (psStack_28 == psStack_2c) {
        FUN_00725750(psStack_2c,&fStack_24);
      }
      else {
        *psStack_2c = (short)uStack_60 + 4;
        psStack_2c = psStack_2c + 1;
      }
      uVar5 = uStack_60 + 5;
    }
    fStack_24 = (float)(uVar5 & 0xffff);
    if (psStack_28 == psStack_2c) {
      FUN_00725750(psStack_2c,&fStack_24);
    }
    else {
      *psStack_2c = (short)uVar5;
      psStack_2c = psStack_2c + 1;
    }
    uVar2 = *(undefined8 *)pfStack_6c;
    pfVar1 = pfStack_6c + 2;
    fStack_d4 = *pfVar1;
    uStack_dc = uVar2;
    uVar2 = uStack_dc;
    if (iStack_7c <= uStack_b8._4_4_) break;
    uStack_dc._4_4_ = (float)((ulonglong)uVar2 >> 0x20);
    fStack_68 = uStack_dc._4_4_;
    uStack_dc._0_4_ = (float)uVar2;
    iVar3 = uStack_b8._4_4_;
    psVar6 = psStack_2c;
    pfStack_6c = (float *)(float)uStack_dc;
    uStack_dc = uVar2;
    fStack_64 = *pfVar1;
  }
  uVar4 = FUN_007ff000(param_1,param_2,&iStack_3c,&uStack_30);
  FUN_0072a160();
  FUN_007a4f50();
  ExceptionList = pvStack_1c;
  return uVar4;
}



/* FUNCTION 12295 ; VA 0x007ffe40 ; FUN_007ffe40 */

undefined4 FUN_007ffe40(undefined4 param_1,undefined4 param_2,float param_3,uint param_4)

{
  undefined8 uVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined **ppuVar4;
  ulonglong *puVar5;
  undefined2 *puVar6;
  undefined2 *puVar7;
  double dVar8;
  float fVar9;
  float fVar10;
  undefined8 uStack_e8;
  float fStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined *puStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined *puStack_c4;
  float fStack_c0;
  float fStack_bc;
  float fStack_b8;
  float fStack_b4;
  float fStack_b0;
  undefined *puStack_ac;
  float fStack_a8;
  float fStack_a4;
  float fStack_a0;
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  ulonglong uStack_90;
  float fStack_88;
  undefined8 uStack_84;
  float fStack_7c;
  float fStack_78;
  float fStack_74;
  float fStack_70;
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  uint uStack_60;
  ulonglong uStack_5c;
  float fStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined *puStack_40;
  undefined *puStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  int iStack_2c;
  float *pfStack_28;
  float *pfStack_24;
  undefined4 uStack_20;
  undefined2 *puStack_1c;
  undefined2 *puStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b4b50;
  pvStack_10 = ExceptionList;
  iStack_2c = 0;
  pfStack_28 = (float *)0x0;
  pfStack_24 = (float *)0x0;
  puVar7 = (undefined2 *)0x0;
  uStack_20 = 0;
  puStack_1c = (undefined2 *)0x0;
  puStack_18 = (undefined2 *)0x0;
  fStack_6c = (float)((uint)param_3 & 0xffff);
  uStack_8 = 1;
  fStack_70 = DAT_019011e0 / (float)(int)fStack_6c;
  dVar8 = (double)(fStack_70 * DAT_0190119c);
  ExceptionList = &pvStack_10;
  uStack_84 = dVar8;
  FUN_01728390();
  fStack_14 = (float)dVar8;
  dVar8 = uStack_84;
  FUN_017279f0();
  fStack_38 = 0.0;
  fStack_34 = 0.0;
  puStack_3c = (undefined *)0x0;
  uStack_84 = (double)CONCAT44((float)dVar8,(undefined4)uStack_84);
  fStack_68 = 0.0;
  fStack_30 = DAT_018ce2f8;
  fStack_64 = 0.0;
  if ((char)param_4 == '\0') {
    puStack_3c = &DAT_bf800000;
  }
  fStack_88 = 0.0;
  fStack_54 = 0.0;
  uStack_5c = (ulonglong)DAT_018f7864;
  puStack_40 = (undefined *)0x0;
  uStack_48 = ZEXT48(puStack_3c);
  uStack_50 = 0;
  uStack_4c = 0;
  FUN_007fc010(0,&uStack_5c);
  fVar9 = DAT_018ce2f8;
  fStack_38 = 0.0;
  fStack_34 = 0.0;
  puStack_3c = (undefined *)0x0;
  if ((char)param_4 == '\0') {
    puStack_3c = (undefined *)0x3f800000;
  }
  uStack_5c = (ulonglong)(uint)DAT_018ce2f8;
  fStack_88 = 0.0;
  uStack_48 = ZEXT48(puStack_3c);
  fStack_54 = 0.0;
  uStack_50 = 0;
  uStack_4c = 0;
  puStack_40 = (undefined *)0x0;
  if (pfStack_24 == pfStack_28) {
    FUN_007fc010(pfStack_28,&uStack_5c);
    fVar9 = DAT_018ce2f8;
  }
  else {
    *pfStack_28 = DAT_018ce2f8;
    pfStack_28[1] = 0.0;
    pfStack_28[2] = 0.0;
    pfStack_28[3] = 0.0;
    pfStack_28[4] = 0.0;
    pfStack_28[5] = (float)puStack_3c;
    pfStack_28[6] = 0.0;
    pfStack_28[7] = 0.0;
    pfStack_28 = pfStack_28 + 8;
  }
  uStack_60 = (int)pfStack_28 - iStack_2c >> 5 & 0xffff;
  if (param_3._0_2_ != 0) {
    fStack_7c = 0.0;
    puStack_ac = &DAT_bf800000;
    fStack_b8 = 1.0;
    puStack_c4 = &DAT_bf800000;
    puStack_3c = (undefined *)0x3f800000;
    param_3 = fStack_6c;
    do {
      fStack_94 = fStack_68 - 0.0;
      uStack_50 = 0;
      uStack_4c = 0;
      fStack_a8 = fStack_94;
      fStack_54 = fVar9 - 0.0;
      uVar1 = CONCAT44(fStack_68,fStack_7c);
      fStack_a4 = fStack_54;
      fStack_98 = fStack_54;
      uStack_5c = CONCAT44(fStack_94,puStack_ac);
      fStack_78 = fStack_68;
      fStack_74 = fVar9;
      if (pfStack_24 == pfStack_28) {
        uStack_48 = uVar1;
        puStack_40 = (undefined *)fVar9;
        FUN_007fc010(pfStack_28,&uStack_5c);
        uVar1 = CONCAT44(fStack_78,fStack_7c);
      }
      else {
        *pfStack_28 = (float)puStack_ac;
        pfStack_28[1] = fStack_94;
        pfStack_28[2] = fStack_54;
        pfStack_28[3] = 0.0;
        pfStack_28[4] = 0.0;
        pfStack_28[5] = fStack_7c;
        pfStack_28[6] = fStack_68;
        pfStack_28[7] = fVar9;
        pfStack_28 = pfStack_28 + 8;
      }
      fStack_9c = fStack_68 + 0.0;
      uStack_50 = 0;
      uStack_4c = 0;
      fStack_b4 = fStack_9c;
      fStack_54 = fStack_30 + 0.0;
      fStack_b0 = fStack_54;
      fStack_a0 = fStack_54;
      uStack_5c = CONCAT44(fStack_9c,fStack_b8);
      puStack_40 = (undefined *)fStack_74;
      if (pfStack_24 == pfStack_28) {
        uStack_48 = uVar1;
        FUN_007fc010(pfStack_28,&uStack_5c);
        uVar1 = CONCAT44(fStack_78,fStack_7c);
      }
      else {
        *pfStack_28 = fStack_b8;
        pfStack_28[1] = fStack_9c;
        pfStack_28[2] = fStack_54;
        pfStack_28[3] = 0.0;
        uStack_48._0_4_ = (float)uVar1;
        uStack_48._4_4_ = (float)((ulonglong)uVar1 >> 0x20);
        pfStack_28[4] = 0.0;
        pfStack_28[5] = (float)uStack_48;
        pfStack_28[6] = uStack_48._4_4_;
        pfStack_28[7] = fStack_74;
        pfStack_28 = pfStack_28 + 8;
      }
      if ((char)param_4 == '\0') {
        puStack_d0 = &DAT_bf800000;
        ppuVar4 = &puStack_d0;
        uStack_cc = 0;
        uStack_c8 = 0;
      }
      else {
        uStack_e8 = uVar1;
        ppuVar4 = (undefined **)&uStack_e8;
        fStack_e0 = fStack_74;
      }
      fStack_c0 = fStack_94;
      fStack_bc = fStack_98;
      uStack_5c = CONCAT44(fStack_94,puStack_c4);
      uStack_48 = *(ulonglong *)ppuVar4;
      fStack_54 = fStack_98;
      puStack_40 = ppuVar4[2];
      uStack_50 = 0;
      uStack_4c = 0;
      if (pfStack_24 == pfStack_28) {
        FUN_007fc010(pfStack_28,&uStack_5c);
      }
      else {
        *pfStack_28 = (float)puStack_c4;
        pfStack_28[1] = fStack_94;
        pfStack_28[2] = fStack_98;
        pfStack_28[3] = 0.0;
        uStack_48._4_4_ = (float)(uStack_48 >> 0x20);
        pfStack_28[4] = 0.0;
        pfStack_28[5] = (float)uStack_48;
        pfStack_28[6] = uStack_48._4_4_;
        pfStack_28[7] = (float)puStack_40;
        pfStack_28 = pfStack_28 + 8;
      }
      if ((char)param_4 == '\0') {
        uStack_dc = 0x3f800000;
        puVar5 = (ulonglong *)&uStack_dc;
        uStack_d8 = 0;
        uStack_d4 = 0;
      }
      else {
        puVar5 = &uStack_90;
        uStack_90 = CONCAT44(fStack_78,fStack_7c);
        fStack_88 = fStack_74;
      }
      fStack_38 = fStack_9c;
      fStack_34 = fStack_a0;
      uStack_5c = CONCAT44(fStack_9c,puStack_3c);
      uStack_48 = *puVar5;
      fStack_54 = fStack_a0;
      puStack_40 = *(undefined **)(puVar5 + 1);
      uStack_50 = 0;
      uStack_4c = 0;
      if (pfStack_24 == pfStack_28) {
        FUN_007fc010(pfStack_28,&uStack_5c);
      }
      else {
        *pfStack_28 = (float)puStack_3c;
        pfStack_28[1] = fStack_9c;
        pfStack_28[2] = fStack_a0;
        pfStack_28[3] = 0.0;
        uStack_48._4_4_ = (float)(uStack_48 >> 0x20);
        pfStack_28[4] = 0.0;
        pfStack_28[5] = (float)uStack_48;
        pfStack_28[6] = uStack_48._4_4_;
        pfStack_28[7] = (float)puStack_40;
        pfStack_28 = pfStack_28 + 8;
      }
      param_3 = (float)((int)param_3 - 1);
      fStack_64 = fStack_64 + fStack_70;
      fVar10 = uStack_84._4_4_ * fStack_68 + fStack_14 * fStack_30;
      fVar9 = uStack_84._4_4_ * fStack_30 - fStack_14 * fStack_68;
      fStack_68 = fVar10;
      fStack_30 = fVar9;
    } while (param_3 != 0.0);
    fStack_64 = 1.4013e-45;
    param_4 = uStack_60 + 2 & 0xffff;
    fStack_30 = fStack_6c;
    puVar6 = (undefined2 *)0x0;
    do {
      param_3 = (float)((uint)fStack_64 % (uint)fStack_6c & 0xffff);
      uVar3 = param_4 - 2;
      fStack_14 = (float)(uVar3 & 0xffff);
      uStack_84 = (double)CONCAT44(uVar3,(undefined4)uStack_84);
      if (puVar7 == puVar6) {
        FUN_00725750(puVar6,&fStack_14);
        puVar7 = puStack_18;
      }
      else {
        *puVar6 = (short)uVar3;
        puStack_1c = puVar6 + 1;
      }
      fStack_14 = (float)(param_4 - 1 & 0xffff);
      if (puVar7 == puStack_1c) {
        FUN_00725750(puStack_1c,&fStack_14);
        puVar7 = puStack_18;
      }
      else {
        *puStack_1c = (short)(param_4 - 1);
        puStack_1c = puStack_1c + 1;
      }
      fStack_70 = (float)(uStack_60 + (int)param_3 * 4 + 1);
      fStack_14 = (float)((uint)fStack_70 & 0xffff);
      if (puVar7 == puStack_1c) {
        FUN_00725750(puStack_1c,&fStack_14);
        puVar7 = puStack_18;
      }
      else {
        *puStack_1c = SUB42(fStack_70,0);
        puStack_1c = puStack_1c + 1;
      }
      fStack_14 = (float)((uint)uStack_84._4_4_ & 0xffff);
      if (puVar7 == puStack_1c) {
        FUN_00725750(puStack_1c,&fStack_14);
        puVar7 = puStack_18;
      }
      else {
        *puStack_1c = (short)((ulonglong)uStack_84 >> 0x20);
        puStack_1c = puStack_1c + 1;
      }
      fStack_14 = (float)((uint)fStack_70 & 0xffff);
      if (puVar7 == puStack_1c) {
        FUN_00725750(puStack_1c,&fStack_14);
        puVar7 = puStack_18;
      }
      else {
        *puStack_1c = SUB42(fStack_70,0);
        puStack_1c = puStack_1c + 1;
      }
      uVar3 = uStack_60 + (int)param_3 * 4;
      fStack_14 = (float)(uVar3 & 0xffff);
      if (puVar7 == puStack_1c) {
        FUN_00725750(puStack_1c,&fStack_14);
        puVar7 = puStack_18;
      }
      else {
        *puStack_1c = (short)uVar3;
        puStack_1c = puStack_1c + 1;
      }
      fStack_14 = 0.0;
      if (puVar7 == puStack_1c) {
        FUN_00725750(puStack_1c,&fStack_14);
        puVar7 = puStack_18;
      }
      else {
        *puStack_1c = 0;
        puStack_1c = puStack_1c + 1;
      }
      fStack_14 = (float)(param_4 & 0xffff);
      if (puVar7 == puStack_1c) {
        FUN_00725750(puStack_1c,&fStack_14);
        puVar7 = puStack_18;
      }
      else {
        *puStack_1c = (short)param_4;
        puStack_1c = puStack_1c + 1;
      }
      uVar3 = uStack_60 + (int)param_3 * 4 + 2;
      fStack_14 = (float)(uVar3 & 0xffff);
      if (puVar7 == puStack_1c) {
        FUN_00725750(puStack_1c,&fStack_14);
        puVar7 = puStack_18;
      }
      else {
        *puStack_1c = (short)uVar3;
        puStack_1c = puStack_1c + 1;
      }
      fStack_14 = 1.4013e-45;
      if (puVar7 == puStack_1c) {
        FUN_00725750(puStack_1c,&fStack_14);
        puVar7 = puStack_18;
      }
      else {
        *puStack_1c = 1;
        puStack_1c = puStack_1c + 1;
      }
      uVar3 = uStack_60 + (int)param_3 * 4 + 3;
      param_3 = (float)(uVar3 & 0xffff);
      if (puVar7 == puStack_1c) {
        FUN_00725750(puStack_1c,&param_3);
        puVar7 = puStack_18;
      }
      else {
        *puStack_1c = (short)uVar3;
        puStack_1c = puStack_1c + 1;
      }
      param_3 = (float)(param_4 + 1 & 0xffff);
      if (puVar7 == puStack_1c) {
        FUN_00725750(puStack_1c,&param_3);
        puVar7 = puStack_18;
      }
      else {
        *puStack_1c = (short)(param_4 + 1);
        puStack_1c = puStack_1c + 1;
      }
      param_4 = param_4 + 4;
      fStack_64 = (float)((int)fStack_64 + 1);
      fStack_30 = (float)((int)fStack_30 - 1);
      puVar6 = puStack_1c;
    } while (fStack_30 != 0.0);
  }
  uVar2 = FUN_007ff000(param_1,param_2,&iStack_2c,&uStack_20);
  FUN_0072a160();
  FUN_007a4f50();
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 12296 ; VA 0x00800620 ; FUN_00800620 */

undefined4 FUN_00800620(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  uint uVar2;
  int iVar3;
  undefined *puStack_48;
  undefined *puStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int aiStack_30 [4];
  undefined2 *puStack_20;
  undefined2 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b4b30;
  pvStack_10 = ExceptionList;
  aiStack_30[0] = 0;
  aiStack_30[1] = 0;
  aiStack_30[2] = 0;
  aiStack_30[3] = 0;
  puStack_20 = (undefined2 *)0x0;
  puStack_1c = (undefined2 *)0x0;
  uStack_8 = 1;
  uStack_3c = 0;
  uStack_38 = 0;
  uStack_34 = 0x3f800000;
  uStack_18 = 0x3f800000;
  puStack_48 = &DAT_bf800000;
  puStack_44 = (undefined *)0x3f800000;
  uStack_40 = 0;
  if ((char)param_3 == '\0') {
    uStack_14 = 0;
    ExceptionList = &pvStack_10;
    FUN_007fc5a0(&puStack_48,&uStack_18,&uStack_3c);
    uStack_18 = 0;
    uStack_14 = 0x3f800000;
    puStack_48 = (undefined *)0x3f800000;
    puStack_44 = &DAT_bf800000;
    uStack_40 = 0;
    FUN_007fc5a0(&puStack_48,&uStack_18,&uStack_3c);
    uStack_18 = 0x3f800000;
    uStack_14 = 0x3f800000;
    puStack_48 = &DAT_bf800000;
    puStack_44 = &DAT_bf800000;
    uStack_40 = 0;
    FUN_007fc5a0(&puStack_48,&uStack_18,&uStack_3c);
    uStack_14 = 0;
  }
  else {
    uStack_14 = 0x3f800000;
    ExceptionList = &pvStack_10;
    FUN_007fc5a0(&puStack_48,&uStack_18,&uStack_3c);
    uStack_18 = 0;
    uStack_14 = 0;
    puStack_48 = (undefined *)0x3f800000;
    puStack_44 = &DAT_bf800000;
    uStack_40 = 0;
    FUN_007fc5a0(&puStack_48,&uStack_18,&uStack_3c);
    uStack_18 = 0x3f800000;
    uStack_14 = 0;
    puStack_48 = &DAT_bf800000;
    puStack_44 = &DAT_bf800000;
    uStack_40 = 0;
    FUN_007fc5a0(&puStack_48,&uStack_18,&uStack_3c);
    uStack_14 = 0x3f800000;
  }
  uStack_18 = 0;
  puStack_48 = (undefined *)0x3f800000;
  puStack_44 = (undefined *)0x3f800000;
  uStack_40 = 0;
  FUN_007fc5a0(&puStack_48,&uStack_18,&uStack_3c);
  param_3 = 0;
  FUN_00725750(0,&param_3);
  param_3 = 1;
  if (puStack_1c == puStack_20) {
    FUN_00725750(puStack_20,&param_3);
  }
  else {
    *puStack_20 = 1;
    puStack_20 = puStack_20 + 1;
  }
  param_3 = 2;
  if (puStack_1c == puStack_20) {
    FUN_00725750(puStack_20,&param_3);
  }
  else {
    *puStack_20 = 2;
    puStack_20 = puStack_20 + 1;
  }
  param_3 = 0;
  if (puStack_1c == puStack_20) {
    FUN_00725750(puStack_20,&param_3);
  }
  else {
    *puStack_20 = 0;
    puStack_20 = puStack_20 + 1;
  }
  param_3 = 3;
  if (puStack_1c == puStack_20) {
    FUN_00725750(puStack_20,&param_3);
  }
  else {
    *puStack_20 = 3;
    puStack_20 = puStack_20 + 1;
  }
  param_3 = 1;
  if (puStack_1c == puStack_20) {
    FUN_00725750(puStack_20,&param_3);
  }
  else {
    *puStack_20 = 1;
    puStack_20 = puStack_20 + 1;
  }
  uVar1 = FUN_007ff000(param_1,param_2,aiStack_30,aiStack_30 + 3);
  if (aiStack_30[3] != 0) {
    uVar2 = (int)puStack_1c - aiStack_30[3] & 0xfffffffe;
    iVar3 = aiStack_30[3];
    if (0xfff < uVar2) {
      iVar3 = *(int *)(aiStack_30[3] + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (aiStack_30[3] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  if (aiStack_30[0] != 0) {
    uVar2 = aiStack_30[2] - aiStack_30[0] & 0xffffffe0;
    iVar3 = aiStack_30[0];
    if (0xfff < uVar2) {
      iVar3 = *(int *)(aiStack_30[0] + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (aiStack_30[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 12297 ; VA 0x00800980 ; FUN_00800980 */

undefined4 FUN_00800980(undefined4 param_1,undefined4 param_2,uint param_3,uint param_4)

{
  float fVar1;
  float fVar2;
  uint uVar3;
  uint uVar4;
  float fVar5;
  int iVar6;
  undefined4 uVar7;
  uint uVar8;
  undefined2 *puVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  double dVar13;
  double dVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  ulonglong uStack_68;
  float fStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  ulonglong uStack_54;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  int iStack_34;
  float *pfStack_30;
  float *pfStack_2c;
  undefined8 uStack_28;
  float fStack_20;
  undefined4 uStack_1c;
  undefined2 *puStack_18;
  undefined2 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b4b70;
  pvStack_10 = ExceptionList;
  iStack_34 = 0;
  pfStack_30 = (float *)0x0;
  pfStack_2c = (float *)0x0;
  uStack_1c = 0;
  puStack_18 = (undefined2 *)0x0;
  puStack_14 = (undefined2 *)0x0;
  fVar2 = (float)(param_3 & 0xffff);
  uStack_8 = 1;
  dVar13 = (double)((DAT_019011e0 / (float)(int)fVar2) * DAT_0190119c);
  ExceptionList = &pvStack_10;
  uStack_28 = dVar13;
  FUN_01728390();
  dVar14 = uStack_28;
  FUN_017279f0();
  fStack_60 = 0.0;
  fStack_4c = 0.0;
  fStack_20 = DAT_018ce2f8;
  uStack_28 = (double)CONCAT44((float)dVar14,(undefined4)uStack_28);
  uStack_68 = (ulonglong)DAT_018f7864;
  fStack_40 = 0.0;
  uStack_5c = 0;
  uStack_58 = 0;
  uStack_54 = (ulonglong)DAT_018f7864;
  FUN_007fc010(0,&uStack_68);
  fVar17 = DAT_018ce2f8;
  uStack_68 = (ulonglong)(uint)DAT_018ce2f8;
  uStack_54 = (ulonglong)(uint)DAT_018ce2f8;
  fStack_60 = 0.0;
  uStack_5c = 0;
  uStack_58 = 0;
  fStack_4c = 0.0;
  if (pfStack_2c == pfStack_30) {
    FUN_007fc010(pfStack_30,&uStack_68);
    fVar17 = DAT_018ce2f8;
  }
  else {
    *pfStack_30 = DAT_018ce2f8;
    pfStack_30[1] = 0.0;
    pfStack_30[2] = 0.0;
    pfStack_30[3] = 0.0;
    pfStack_30[4] = 0.0;
    pfStack_30[5] = fVar17;
    pfStack_30[6] = 0.0;
    pfStack_30[7] = 0.0;
    pfStack_30 = pfStack_30 + 8;
  }
  uVar3 = (int)pfStack_30 - iStack_34 >> 5 & 0xffff;
  uVar4 = param_4 + 3 & 0xffff;
  if ((short)param_3 != 0) {
    fVar16 = 0.0;
    fVar5 = (float)(param_4 & 0xffff);
    fStack_48 = (float)(int)fVar5;
    fStack_44 = fVar2;
    do {
      fVar1 = fStack_20;
      fVar10 = fVar16 + 0.0;
      param_3 = 0;
      fVar11 = fStack_20 + 0.0;
      fVar15 = fStack_48;
      fStack_3c = fVar10;
      fStack_38 = fVar11;
      do {
        uStack_5c = 0;
        uStack_58 = 0;
        fVar12 = (((float)(int)param_3 / fVar15 + (float)(int)param_3 / fVar15) - fVar17) + 0.0;
        uStack_68 = CONCAT44(fVar10,fVar12);
        uStack_54 = (ulonglong)(uint)fVar16 << 0x20;
        if (pfStack_2c == pfStack_30) {
          fStack_60 = fVar11;
          fStack_4c = fVar1;
          FUN_007fc010(pfStack_30,&uStack_68);
          fVar17 = DAT_018ce2f8;
          fVar15 = fStack_48;
        }
        else {
          *pfStack_30 = fVar12;
          pfStack_30[1] = fVar10;
          pfStack_30[2] = fVar11;
          pfStack_30[3] = 0.0;
          pfStack_30[4] = 0.0;
          pfStack_30[5] = 0.0;
          pfStack_30[6] = fVar16;
          pfStack_30[7] = fVar1;
          pfStack_30 = pfStack_30 + 8;
        }
        param_3 = param_3 + 1;
      } while ((int)param_3 <= (int)fVar5);
      uStack_68 = CONCAT44(fStack_3c,&DAT_bf800000);
      uStack_54 = 0xbf800000;
      fStack_60 = fStack_38;
      uStack_5c = 0;
      uStack_58 = 0;
      fStack_4c = 0.0;
      if (pfStack_2c == pfStack_30) {
        FUN_007fc010(pfStack_30,&uStack_68);
      }
      else {
        *pfStack_30 = (float)&DAT_bf800000;
        pfStack_30[1] = fStack_3c;
        pfStack_30[2] = fStack_38;
        pfStack_30[3] = 0.0;
        pfStack_30[4] = 0.0;
        pfStack_30[5] = (float)&DAT_bf800000;
        pfStack_30[6] = 0.0;
        pfStack_30[7] = 0.0;
        pfStack_30 = pfStack_30 + 8;
      }
      uStack_68 = CONCAT44(fStack_3c,0x3f800000);
      uStack_54 = 0x3f800000;
      fStack_60 = fStack_38;
      uStack_5c = 0;
      uStack_58 = 0;
      fStack_4c = 0.0;
      if (pfStack_2c == pfStack_30) {
        FUN_007fc010(pfStack_30,&uStack_68);
      }
      else {
        *pfStack_30 = 1.0;
        pfStack_30[1] = fStack_3c;
        pfStack_30[2] = fStack_38;
        pfStack_30[3] = 0.0;
        pfStack_30[4] = 0.0;
        pfStack_30[5] = 1.0;
        pfStack_30[6] = 0.0;
        pfStack_30[7] = 0.0;
        pfStack_30 = pfStack_30 + 8;
      }
      fStack_44 = (float)((int)fStack_44 - 1);
      fVar16 = uStack_28._4_4_ * fStack_40 + (float)dVar13 * fStack_20;
      fStack_20 = uStack_28._4_4_ * fStack_20 - (float)dVar13 * fStack_40;
      fVar17 = DAT_018ce2f8;
      fStack_40 = fVar16;
    } while (fStack_44 != 0.0);
    fStack_20 = (float)(uVar3 + 2 + param_4 & 0xffff);
    iVar6 = 0xfffe - param_4;
    fStack_44 = 1.4013e-45;
    puVar9 = puStack_14;
    fStack_40 = fVar2;
    do {
      fStack_3c = (float)((uint)fStack_44 % (uint)fVar2);
      if ((short)param_4 != 0) {
        fStack_38 = (float)((int)fStack_20 + iVar6 & 0xffff);
        param_3 = (int)fStack_3c * uVar4 + uVar3 + 1 & 0xffff;
        fStack_48 = fVar5;
        do {
          uStack_28 = (double)CONCAT44(fStack_38,(undefined4)uStack_28);
          if (puVar9 == puStack_18) {
            FUN_00725750(puStack_18,(int)&uStack_28 + 4);
            puVar9 = puStack_14;
          }
          else {
            *puStack_18 = SUB42(fStack_38,0);
            puStack_18 = puStack_18 + 1;
          }
          uVar8 = (int)fStack_38 + 1;
          uStack_28 = (double)(CONCAT44(uVar8,(undefined4)uStack_28) & 0xffffffffffff);
          if (puVar9 == puStack_18) {
            FUN_00725750(puStack_18,(int)&uStack_28 + 4);
            puVar9 = puStack_14;
          }
          else {
            *puStack_18 = (short)uVar8;
            puStack_18 = puStack_18 + 1;
          }
          uStack_28 = (double)(CONCAT44(param_3,(undefined4)uStack_28) & 0xffffffffffff);
          if (puVar9 == puStack_18) {
            FUN_00725750(puStack_18,(int)&uStack_28 + 4);
            puVar9 = puStack_14;
          }
          else {
            *puStack_18 = (short)param_3;
            puStack_18 = puStack_18 + 1;
          }
          uStack_28 = (double)(CONCAT44(fStack_38,(undefined4)uStack_28) & 0xffffffffffff);
          if (puVar9 == puStack_18) {
            FUN_00725750(puStack_18,(int)&uStack_28 + 4);
            puVar9 = puStack_14;
          }
          else {
            *puStack_18 = SUB42(fStack_38,0);
            puStack_18 = puStack_18 + 1;
          }
          uStack_28 = (double)(CONCAT44(param_3,(undefined4)uStack_28) & 0xffffffffffff);
          if (puVar9 == puStack_18) {
            FUN_00725750(puStack_18,(int)&uStack_28 + 4);
            puVar9 = puStack_14;
          }
          else {
            *puStack_18 = (short)param_3;
            puStack_18 = puStack_18 + 1;
          }
          uStack_28 = (double)(CONCAT44(param_3 - 1,(undefined4)uStack_28) & 0xffffffffffff);
          if (puVar9 == puStack_18) {
            FUN_00725750(puStack_18,(int)&uStack_28 + 4);
            puVar9 = puStack_14;
          }
          else {
            *puStack_18 = (short)(param_3 - 1);
            puStack_18 = puStack_18 + 1;
          }
          param_3 = param_3 + 1;
          fStack_48 = (float)((int)fStack_48 - 1);
          fStack_38 = (float)(uVar8 & 0xffff);
        } while (fStack_48 != 0.0);
      }
      param_3 = 0;
      if (puVar9 == puStack_18) {
        FUN_00725750(puStack_18,&param_3);
        puVar9 = puStack_14;
      }
      else {
        *puStack_18 = 0;
        puStack_18 = puStack_18 + 1;
      }
      param_3 = (int)fStack_20 - 1U & 0xffff;
      if (puVar9 == puStack_18) {
        FUN_00725750(puStack_18,&param_3);
        puVar9 = puStack_14;
      }
      else {
        *puStack_18 = (short)((int)fStack_20 - 1U);
        puStack_18 = puStack_18 + 1;
      }
      fStack_3c = (float)((int)fStack_3c * uVar4 + uVar3);
      uVar8 = param_4 + 1 + (int)fStack_3c;
      param_3 = uVar8 & 0xffff;
      if (puVar9 == puStack_18) {
        FUN_00725750(puStack_18,&param_3);
        puVar9 = puStack_14;
      }
      else {
        *puStack_18 = (short)uVar8;
        puStack_18 = puStack_18 + 1;
      }
      param_3 = 1;
      if (puVar9 == puStack_18) {
        FUN_00725750(puStack_18,&param_3);
        puVar9 = puStack_14;
      }
      else {
        *puStack_18 = 1;
        puStack_18 = puStack_18 + 1;
      }
      uVar8 = (int)fStack_3c + param_4 + 2;
      param_3 = uVar8 & 0xffff;
      if (puVar9 == puStack_18) {
        FUN_00725750(puStack_18,&param_3);
        puVar9 = puStack_14;
      }
      else {
        *puStack_18 = (short)uVar8;
        puStack_18 = puStack_18 + 1;
      }
      param_3 = (uint)fStack_20 & 0xffff;
      if (puVar9 == puStack_18) {
        FUN_00725750(puStack_18,&param_3);
        puVar9 = puStack_14;
      }
      else {
        *puStack_18 = SUB42(fStack_20,0);
        puStack_18 = puStack_18 + 1;
      }
      fStack_20 = (float)((int)fStack_20 + uVar4);
      fStack_44 = (float)((int)fStack_44 + 1);
      fStack_40 = (float)((int)fStack_40 - 1);
    } while (fStack_40 != 0.0);
  }
  uVar7 = FUN_007ff000(param_1,param_2,&iStack_34,&uStack_1c);
  FUN_0072a160();
  FUN_007a4f50();
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 12298 ; VA 0x008010f0 ; FUN_008010f0 */

undefined4 FUN_008010f0(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  uint uVar2;
  float *pfVar3;
  int iVar4;
  undefined2 *puVar5;
  undefined4 uVar7;
  double dVar6;
  float fVar8;
  float fVar9;
  float fVar10;
  undefined8 uStack_9c;
  float fStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined8 uStack_88;
  float fStack_80;
  float fStack_74;
  float fStack_68;
  int iStack_64;
  float *pfStack_60;
  float *pfStack_5c;
  int iStack_58;
  undefined2 *puStack_54;
  undefined2 *puStack_50;
  float fStack_4c;
  uint uStack_48;
  float fStack_44;
  uint uStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  puStack_18 = &LAB_017b4b90;
  pvStack_1c = ExceptionList;
  iStack_64 = 0;
  pfStack_60 = (float *)0x0;
  pfStack_5c = (float *)0x0;
  puVar5 = (undefined2 *)0x0;
  iStack_58 = 0;
  puStack_54 = (undefined2 *)0x0;
  puStack_50 = (undefined2 *)0x0;
  uVar1 = (undefined4)DAT_019011b0;
  uVar7 = (undefined4)((ulonglong)DAT_019011b0 >> 0x20);
  uStack_14 = 1;
  ExceptionList = &pvStack_1c;
  FUN_01728390();
  fStack_34 = (float)(double)CONCAT44(uVar7,uVar1);
  uVar1 = (undefined4)DAT_019011b0;
  uVar7 = (undefined4)((ulonglong)DAT_019011b0 >> 0x20);
  FUN_017279f0();
  fStack_4c = (float)(double)CONCAT44(uVar7,uVar1);
  fVar10 = (fStack_4c * fStack_34 + fStack_34 + fStack_4c * 0.0 + 0.0) * DAT_018e1340;
  fVar9 = (fStack_34 * fStack_34 + fStack_34 * 0.0 + fStack_34 * 0.0 + 0.0) * DAT_018e1340;
  fVar8 = (fStack_4c + fStack_4c + DAT_018daf58) * DAT_018e1340;
  dVar6 = (double)(fVar9 * fVar9 + fVar10 * fVar10 + fVar8 * fVar8);
  FUN_017267a0();
  uStack_48 = 0x12;
  fStack_44 = 0.0;
  fStack_24 = DAT_018ce2f8 / (float)dVar6;
  fStack_2c = 0.0;
  pfVar3 = pfStack_5c;
  fStack_28 = DAT_018ce2f8;
  do {
    fStack_30 = 0.0;
    fStack_3c = 0.0;
    uStack_40 = 10;
    fStack_38 = DAT_018ce2f8;
    do {
      fVar9 = fStack_3c * fStack_28;
      uStack_90 = 0;
      fVar8 = fStack_3c * fStack_2c;
      uStack_8c = 0;
      fStack_94 = fStack_38 * fStack_24;
      uStack_9c = CONCAT44(fVar8 * fStack_24,fVar9 * fStack_24);
      uStack_88 = CONCAT44(fVar8,fVar9);
      fStack_80 = fStack_38;
      fStack_74 = fStack_38;
      fStack_68 = fStack_94;
      if (pfVar3 == pfStack_60) {
        FUN_007fc010(pfStack_60,&uStack_9c);
        pfVar3 = pfStack_5c;
      }
      else {
        *pfStack_60 = fVar9 * fStack_24;
        pfStack_60[1] = fVar8 * fStack_24;
        pfStack_60[2] = fStack_94;
        pfStack_60[3] = 0.0;
        pfStack_60[4] = 0.0;
        pfStack_60[5] = fVar9;
        pfStack_60[6] = fVar8;
        pfStack_60[7] = fStack_38;
        pfStack_60 = pfStack_60 + 8;
      }
      uStack_40 = uStack_40 - 1;
      fStack_30 = fStack_30 + DAT_019011dc;
      fVar8 = fStack_34 * fStack_38;
      fStack_38 = fStack_38 * fStack_4c - fStack_34 * fStack_3c;
      fStack_3c = fStack_4c * fStack_3c + fVar8;
    } while (uStack_40 != 0);
    uStack_48 = uStack_48 + -1;
    fStack_44 = fStack_44 + DAT_019011dc;
    fVar8 = fStack_34 * fStack_28;
    fStack_28 = fStack_28 * fStack_4c - fStack_34 * fStack_2c;
    fStack_2c = fVar8 + fStack_4c * fStack_2c;
  } while (uStack_48 != 0);
  fStack_28 = 0.0;
  fStack_4c = 2.52234e-44;
  do {
    fStack_44 = (float)((int)fStack_28 * 10);
    uStack_48 = (((int)fStack_28 + 1) % (int)fStack_4c) * 10 & 0xffff;
    fStack_2c = 0.0;
    fStack_28 = (float)((int)fStack_28 + 1);
    do {
      fStack_3c = (float)((uint)fStack_2c & 0xffff);
      uVar2 = (int)fStack_44 + (int)fStack_3c;
      uStack_40 = uVar2 & 0xffff;
      fStack_38 = (float)(uVar2 & 0xffff);
      if (puVar5 == puStack_54) {
        FUN_00725750(puStack_54,&uStack_40);
        puVar5 = puStack_50;
      }
      else {
        *puStack_54 = (short)uVar2;
        puStack_54 = puStack_54 + 1;
      }
      fStack_2c = (float)((int)fStack_2c + 1);
      fStack_34 = (float)((uint)fStack_2c & 0xffff);
      uVar2 = uStack_48 + (int)fStack_34;
      uStack_40 = uVar2 & 0xffff;
      fStack_30 = (float)(uVar2 & 0xffff);
      if (puVar5 == puStack_54) {
        FUN_00725750(puStack_54,&uStack_40);
        puVar5 = puStack_50;
      }
      else {
        *puStack_54 = (short)uVar2;
        puStack_54 = puStack_54 + 1;
      }
      uStack_40 = uStack_48 + (int)fStack_3c & 0xffff;
      if (puVar5 == puStack_54) {
        FUN_00725750(puStack_54,&uStack_40);
        puVar5 = puStack_50;
      }
      else {
        *puStack_54 = (short)(uStack_48 + (int)fStack_3c);
        puStack_54 = puStack_54 + 1;
      }
      uStack_40 = (uint)fStack_38 & 0xffff;
      if (puVar5 == puStack_54) {
        FUN_00725750(puStack_54,&uStack_40);
        puVar5 = puStack_50;
      }
      else {
        *puStack_54 = SUB42(fStack_38,0);
        puStack_54 = puStack_54 + 1;
      }
      uStack_40 = (int)fStack_44 + (int)fStack_34 & 0xffff;
      if (puVar5 == puStack_54) {
        FUN_00725750(puStack_54,&uStack_40);
        puVar5 = puStack_50;
      }
      else {
        *puStack_54 = (short)((int)fStack_44 + (int)fStack_34);
        puStack_54 = puStack_54 + 1;
      }
      uStack_40 = (uint)fStack_30 & 0xffff;
      if (puVar5 == puStack_54) {
        FUN_00725750(puStack_54,&uStack_40);
        puVar5 = puStack_50;
      }
      else {
        *puStack_54 = SUB42(fStack_30,0);
        puStack_54 = puStack_54 + 1;
      }
    } while ((int)fStack_2c < 9);
  } while ((int)fStack_28 < 0x12);
  uVar1 = FUN_007ff000(param_1,param_2,&iStack_64,&iStack_58);
  if (iStack_58 != 0) {
    uVar2 = (int)puStack_50 - iStack_58 & 0xfffffffe;
    iVar4 = iStack_58;
    if (0xfff < uVar2) {
      iVar4 = *(int *)(iStack_58 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iStack_58 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar2);
  }
  if (iStack_64 != 0) {
    uVar2 = (int)pfStack_5c - iStack_64 & 0xffffffe0;
    iVar4 = iStack_64;
    if (0xfff < uVar2) {
      iVar4 = *(int *)(iStack_64 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iStack_64 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar2);
  }
  ExceptionList = pvStack_1c;
  return uVar1;
}



/* FUNCTION 12299 ; VA 0x00801600 ; FUN_00801600 */

undefined4 FUN_00801600(undefined4 param_1,undefined4 param_2,float param_3)

{
  ulonglong uVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined2 *puVar7;
  double dVar8;
  double dVar9;
  undefined auVar10 [16];
  undefined auVar11 [16];
  undefined auVar12 [16];
  undefined auVar13 [16];
  undefined auVar14 [16];
  undefined auVar15 [16];
  float fVar16;
  float fVar17;
  undefined8 uStack_8c;
  float fStack_84;
  uint uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined *puStack_74;
  undefined8 uStack_70;
  float fStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined8 uStack_5c;
  undefined *puStack_54;
  float fStack_50;
  float fStack_4c;
  undefined8 uStack_44;
  float fStack_3c;
  int iStack_38;
  undefined4 *puStack_34;
  undefined4 *puStack_30;
  undefined8 uStack_2c;
  uint uStack_24;
  float fStack_20;
  undefined4 uStack_1c;
  undefined2 *puStack_18;
  undefined2 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b4bb0;
  pvStack_10 = ExceptionList;
  fStack_50 = param_3 * DAT_0190119c;
  iStack_38 = 0;
  puStack_34 = (undefined4 *)0x0;
  puStack_30 = (undefined4 *)0x0;
  fVar17 = (DAT_01900a20 - param_3) * DAT_018ce2f4 * DAT_0190119c;
  fStack_4c = (float)(int)((fStack_50 / DAT_019011d8) * DAT_018fabec);
  uStack_1c = 0;
  puStack_18 = (undefined2 *)0x0;
  puStack_14 = (undefined2 *)0x0;
  uStack_8 = 1;
  uStack_24 = 0;
  ExceptionList = &pvStack_10;
  if (-1 < (int)fStack_4c) {
    fStack_84 = (float)(int)fStack_4c;
    ExceptionList = &pvStack_10;
    do {
      puVar5 = puStack_34;
      dVar8 = (double)(((float)(int)uStack_24 * fStack_50) / fStack_84 + fVar17);
      uStack_2c = dVar8;
      FUN_017279f0();
      fStack_3c = (float)dVar8;
      FUN_01728390();
      fStack_20 = (float)uStack_2c;
      iVar6 = 0;
      uStack_8c = CONCAT44(fStack_3c,(undefined4)uStack_8c);
      puStack_74 = (undefined *)fStack_3c;
      do {
        auVar10._0_8_ = (double)(((float)iVar6 * DAT_019011d8) / DAT_018fabec);
        auVar10._8_8_ = 0;
        uStack_2c = auVar10._0_8_;
        FUN_017279f0();
        auVar11._4_12_ = auVar10._4_12_;
        auVar11._0_4_ = (float)auVar10._0_8_ * fStack_20;
        uStack_44 = auVar11._0_8_;
        dVar8 = uStack_2c;
        FUN_01728390();
        fStack_68 = (float)puStack_74;
        uStack_64 = 0;
        uStack_60 = 0;
        puStack_54 = (undefined *)uStack_8c._4_4_;
        fVar16 = (float)dVar8 * fStack_20;
        uVar2 = SUB84(uStack_44,0);
        uStack_5c = CONCAT44(fVar16,uVar2);
        uStack_70 = CONCAT44(fVar16,uVar2);
        if (puStack_30 == puVar5) {
          FUN_007fc010(puVar5,&uStack_70);
        }
        else {
          *puVar5 = uVar2;
          puVar5[1] = fVar16;
          puVar5[2] = puStack_74;
          puVar5[3] = 0;
          puVar5[4] = 0;
          puVar5[5] = uVar2;
          puVar5[6] = fVar16;
          puVar5[7] = uStack_8c._4_4_;
          puStack_34 = puVar5 + 8;
        }
        iVar6 = iVar6 + 1;
        puVar5 = puStack_34;
      } while (iVar6 < 0x12);
      uStack_24 = uStack_24 + 1;
    } while ((int)uStack_24 <= (int)fStack_4c);
  }
  fStack_3c = 0.0;
  if (0 < (int)fStack_4c) {
    fStack_20 = 2.52234e-44;
    do {
      fStack_84 = (float)((int)fStack_3c * 0x12);
      uVar3 = 0;
      do {
        uStack_2c = (double)CONCAT44(uVar3 + 1,(undefined4)uStack_2c);
        uStack_24 = (int)(uVar3 + 1) % 0x12;
        uVar4 = (int)fStack_84 + (uVar3 & 0xffff);
        uStack_8c = CONCAT44(uVar3,(undefined4)uStack_8c) & 0xffffffffffff;
        uStack_80 = uVar4 & 0xffff;
        uStack_44 = (double)(CONCAT44(uVar4,(undefined4)uStack_44) & 0xffffffffffff);
        if (puStack_14 == puStack_18) {
          FUN_00725750(puStack_18,&uStack_80);
        }
        else {
          *puStack_18 = (short)uVar4;
          puStack_18 = puStack_18 + 1;
        }
        uStack_80 = (uint)fStack_20 & 0xffff;
        iVar6 = uStack_8c._4_4_ + uStack_80;
        uStack_8c = CONCAT44(iVar6,(undefined4)uStack_8c) & 0xffffffffffff;
        if (puStack_14 == puStack_18) {
          FUN_00725750(puStack_18,(int)&uStack_8c + 4);
        }
        else {
          *puStack_18 = (short)iVar6;
          puStack_18 = puStack_18 + 1;
        }
        iVar6 = (uStack_24 & 0xffff) + uStack_80;
        uStack_8c = CONCAT44(iVar6,(undefined4)uStack_8c) & 0xffffffffffff;
        if (puStack_14 == puStack_18) {
          FUN_00725750(puStack_18,(int)&uStack_8c + 4);
        }
        else {
          *puStack_18 = (short)iVar6;
          puStack_18 = puStack_18 + 1;
        }
        uVar1 = (ulonglong)uStack_44;
        uStack_44 = (double)((ulonglong)uStack_44 & 0xffffffffffff);
        if (puStack_14 == puStack_18) {
          FUN_00725750(puStack_18,(int)&uStack_44 + 4);
        }
        else {
          *puStack_18 = (short)(uVar1 >> 0x20);
          puStack_18 = puStack_18 + 1;
        }
        iVar6 = (uStack_24 & 0xffff) + uStack_80;
        uStack_44 = (double)(CONCAT44(iVar6,(undefined4)uStack_44) & 0xffffffffffff);
        if (puStack_14 == puStack_18) {
          FUN_00725750(puStack_18,(int)&uStack_44 + 4);
        }
        else {
          *puStack_18 = (short)iVar6;
          puStack_18 = puStack_18 + 1;
        }
        iVar6 = (int)fStack_84 + (uStack_24 & 0xffff);
        uStack_44 = (double)(CONCAT44(iVar6,(undefined4)uStack_44) & 0xffffffffffff);
        if (puStack_14 == puStack_18) {
          FUN_00725750(puStack_18,(int)&uStack_44 + 4);
        }
        else {
          *puStack_18 = (short)iVar6;
          puStack_18 = puStack_18 + 1;
        }
        uVar3 = uStack_2c._4_4_;
      } while ((int)uStack_2c._4_4_ < 0x12);
      fStack_20 = (float)((int)fStack_20 + 0x12);
      fStack_3c = (float)((int)fStack_3c + 1);
    } while ((int)fStack_3c < (int)fStack_4c);
  }
  puVar5 = puStack_34;
  dVar8 = (double)fVar17;
  uStack_2c = (double)CONCAT44((int)puStack_34 - iStack_38 >> 5,(undefined4)uStack_2c);
  FUN_017279f0();
  fStack_4c = (float)dVar8;
  dVar8 = (double)fVar17;
  FUN_01728390();
  fStack_3c = (float)dVar8;
  uStack_44 = (double)CONCAT44(0x3f800000,(undefined4)uStack_44);
  uStack_64 = 0;
  uStack_60 = 0;
  puStack_74 = (undefined *)fStack_4c;
  uStack_70 = 0;
  fStack_68 = fStack_4c;
  uStack_5c = 0;
  puStack_54 = (undefined *)0x3f800000;
  if (puStack_30 == puVar5) {
    FUN_007fc010(puVar5,&uStack_70);
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 0;
    puVar5[2] = fStack_4c;
    puVar5[3] = 0;
    puVar5[4] = 0;
    puVar5[5] = 0;
    puVar5[6] = 0;
    puVar5[7] = 0x3f800000;
    puStack_34 = puVar5 + 8;
  }
  fVar16 = fStack_4c;
  iVar6 = 0;
  uStack_7c = 0;
  uStack_78 = 0;
  puStack_74 = (undefined *)0x3f800000;
  do {
    puVar5 = puStack_34;
    auVar12._0_8_ = (double)(((float)iVar6 * DAT_019011d8) / DAT_018fabec);
    auVar12._8_8_ = 0;
    uStack_44 = auVar12._0_8_;
    FUN_017279f0();
    auVar13._4_12_ = auVar12._4_12_;
    auVar13._0_4_ = (float)auVar12._0_8_ * fStack_3c;
    uStack_8c = auVar13._0_8_;
    dVar8 = (double)((ulonglong)uStack_44 >> 0x20);
    FUN_01728390();
    fStack_68 = fVar16;
    uStack_64 = 0;
    uStack_60 = 0;
    puStack_54 = puStack_74;
    uStack_70 = CONCAT44((float)dVar8 * fStack_3c,(undefined4)uStack_8c);
    uStack_5c = CONCAT44(uStack_78,uStack_7c);
    if (puStack_30 == puVar5) {
      FUN_007fc010(puVar5,&uStack_70);
    }
    else {
      *puVar5 = (undefined4)uStack_8c;
      puVar5[1] = (float)dVar8 * fStack_3c;
      puVar5[2] = fVar16;
      puVar5[3] = 0;
      puVar5[4] = 0;
      puVar5[5] = uStack_7c;
      puVar5[6] = uStack_78;
      puVar5[7] = puStack_74;
      puStack_34 = puVar5 + 8;
    }
    iVar6 = iVar6 + -1;
  } while (-0x12 < iVar6);
  fStack_20 = (float)(uStack_2c._4_4_ & 0xffff);
  uStack_24 = 0;
  puVar7 = puStack_14;
  do {
    uStack_2c = (double)(CONCAT44(fStack_20,(undefined4)uStack_2c) & 0xffffffffffff);
    if (puVar7 == puStack_18) {
      FUN_00725750(puStack_18,(int)&uStack_2c + 4);
      puVar7 = puStack_14;
    }
    else {
      *puStack_18 = SUB42(fStack_20,0);
      puStack_18 = puStack_18 + 1;
    }
    uStack_44 = (double)CONCAT44(uStack_24 + 1,(undefined4)uStack_44);
    iVar6 = (int)fStack_20 + 1U + (int)(uStack_24 + 1) % 0x12;
    uStack_2c = (double)(CONCAT44(iVar6,(undefined4)uStack_2c) & 0xffffffffffff);
    if (puVar7 == puStack_18) {
      FUN_00725750(puStack_18,(int)&uStack_2c + 4);
      puVar7 = puStack_14;
    }
    else {
      *puStack_18 = (short)iVar6;
      puStack_18 = puStack_18 + 1;
    }
    iVar6 = uStack_24 + 1 + (int)fStack_20;
    uStack_2c = (double)(CONCAT44(iVar6,(undefined4)uStack_2c) & 0xffffffffffff);
    if (puVar7 == puStack_18) {
      FUN_00725750(puStack_18,(int)&uStack_2c + 4);
      puVar7 = puStack_14;
    }
    else {
      *puStack_18 = (short)iVar6;
      puStack_18 = puStack_18 + 1;
    }
    puVar5 = puStack_34;
    uStack_24 = uStack_44._4_4_;
  } while (uStack_44._4_4_ < 0x12);
  fVar17 = fVar17 + fStack_50;
  uStack_2c = (double)CONCAT44((int)puStack_34 - iStack_38 >> 5,(undefined4)uStack_2c);
  dVar8 = (double)fVar17;
  FUN_017279f0();
  fStack_50 = (float)dVar8;
  dVar8 = (double)fVar17;
  FUN_01728390();
  puStack_74 = &DAT_bf800000;
  uStack_64 = 0;
  uStack_60 = 0;
  uStack_70 = 0;
  fStack_68 = fStack_50;
  uStack_5c = 0;
  puStack_54 = &DAT_bf800000;
  if (puStack_30 == puVar5) {
    FUN_007fc010(puVar5,&uStack_70);
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 0;
    puVar5[2] = fStack_50;
    puVar5[3] = 0;
    puVar5[4] = 0;
    puVar5[5] = 0;
    puVar5[6] = 0;
    puVar5[7] = &DAT_bf800000;
    puStack_34 = puVar5 + 8;
  }
  fVar17 = fStack_50;
  iVar6 = 0;
  uStack_7c = 0;
  uStack_78 = 0;
  puStack_74 = &DAT_bf800000;
  do {
    puVar5 = puStack_34;
    auVar14._0_8_ = (double)(((float)iVar6 * DAT_019011d8) / DAT_018fabec);
    auVar14._8_8_ = 0;
    auVar10 = auVar14;
    FUN_017279f0();
    auVar15._4_12_ = auVar10._4_12_;
    auVar15._0_4_ = (float)auVar10._0_8_ * (float)dVar8;
    uStack_44 = auVar15._0_8_;
    dVar9 = (double)((ulonglong)auVar14._0_8_ >> 0x20);
    FUN_01728390();
    fStack_68 = fVar17;
    uStack_64 = 0;
    uStack_60 = 0;
    puStack_54 = puStack_74;
    fVar16 = (float)dVar9 * (float)dVar8;
    uStack_70 = CONCAT44(fVar16,SUB84(uStack_44,0));
    uStack_5c = CONCAT44(uStack_78,uStack_7c);
    if (puStack_30 == puVar5) {
      FUN_007fc010(puVar5,&uStack_70);
    }
    else {
      *puVar5 = SUB84(uStack_44,0);
      puVar5[1] = fVar16;
      puVar5[2] = fVar17;
      puVar5[3] = 0;
      puVar5[4] = 0;
      puVar5[5] = uStack_7c;
      puVar5[6] = uStack_78;
      puVar5[7] = puStack_74;
      puStack_34 = puVar5 + 8;
    }
    uVar1 = (ulonglong)uStack_2c;
    iVar6 = iVar6 + 1;
  } while (iVar6 < 0x12);
  uVar3 = uStack_2c._4_4_;
  uVar4 = uStack_2c._4_4_ & 0xffff;
  fStack_20 = 0.0;
  puVar7 = puStack_14;
  do {
    uStack_2c = (double)(CONCAT44(uVar3,(undefined4)uStack_2c) & 0xffffffffffff);
    if (puVar7 == puStack_18) {
      FUN_00725750(puStack_18,(int)&uStack_2c + 4);
      puVar7 = puStack_14;
    }
    else {
      *puStack_18 = (short)(uVar1 >> 0x20);
      puStack_18 = puStack_18 + 1;
    }
    uStack_44 = (double)CONCAT44((int)fStack_20 + 1,(undefined4)uStack_44);
    iVar6 = uVar4 + 1 + ((int)fStack_20 + 1) % 0x12;
    uStack_2c = (double)(CONCAT44(iVar6,(undefined4)uStack_2c) & 0xffffffffffff);
    if (puVar7 == puStack_18) {
      FUN_00725750(puStack_18,(int)&uStack_2c + 4);
      puVar7 = puStack_14;
    }
    else {
      *puStack_18 = (short)iVar6;
      puStack_18 = puStack_18 + 1;
    }
    iVar6 = (int)fStack_20 + 1 + uVar4;
    uStack_2c = (double)(CONCAT44(iVar6,(undefined4)uStack_2c) & 0xffffffffffff);
    if (puVar7 == puStack_18) {
      FUN_00725750(puStack_18,(int)&uStack_2c + 4);
      puVar7 = puStack_14;
    }
    else {
      *puStack_18 = (short)iVar6;
      puStack_18 = puStack_18 + 1;
    }
    fStack_20 = (float)uStack_44._4_4_;
  } while (uStack_44._4_4_ < 0x12);
  uVar2 = FUN_007ff000(param_1,param_2,&iStack_38,&uStack_1c);
  FUN_0072a160();
  FUN_007a4f50();
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 12300 ; VA 0x00801e90 ; FUN_00801e90 */

undefined4 *
FUN_00801e90(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b4bc8;
  pvStack_10 = ExceptionList;
  piStack_14 = (int *)(CONCAT31(piStack_14._1_3_,-(DAT_01d61edc != '\0')) & 0xffffff04);
  ExceptionList = &pvStack_10;
  FUN_00782550(&iStack_18,param_2,piStack_14,4,param_4,0x425c0000,0);
  uStack_8 = 0;
  if (iStack_18 == 0) {
    iVar3 = 0;
  }
  else {
    iVar3 = *(int *)(iStack_18 + 8);
  }
  *(bool *)param_3 = iVar3 == 1;
  puVar4 = (undefined4 *)FUN_01674e20(0xc);
  if (puVar4 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Graphics::TextureProxy::vftable;
    puVar4[1] = 0;
    puVar4[2] = 0;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
    }
    puVar4[1] = iStack_18;
    puVar4[2] = piStack_14;
    puVar5 = puVar4;
  }
  *param_1 = 0;
  param_1[1] = 0;
  FUN_007fc3c0(puVar5,puVar4);
  piVar2 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12301 ; VA 0x00801fc0 ; FUN_00801fc0 */

undefined4 * FUN_00801fc0(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b4bc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0078af30(&uStack_18,param_2);
  uStack_8 = 0;
  puVar3 = (undefined4 *)FUN_01674e20(0xc);
  if (puVar3 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Graphics::TextureProxy::vftable;
    puVar3[1] = 0;
    puVar3[2] = 0;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
    }
    puVar3[1] = uStack_18;
    puVar3[2] = piStack_14;
    puVar4 = puVar3;
  }
  *param_1 = 0;
  param_1[1] = 0;
  FUN_007fc3c0(puVar4,puVar3);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12302 ; VA 0x008020b0 ; FUN_008020b0 */

undefined4 * __thiscall FUN_008020b0(int param_1,undefined4 *param_2,int param_3,int *param_4)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017b4bf0;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    param_2[1] = 0;
  }
  else {
    uVar2 = *(undefined4 *)(*(int *)(param_1 + 0x34) + 0x3c);
    ExceptionList = &pvStack_10;
    if (param_4 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    FUN_007d6c40(&uStack_20,param_3,param_4,uVar2);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    puVar4 = (undefined4 *)FUN_01674e20(0xc);
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = RBX::Graphics::TextureProxy::vftable;
      puVar4[1] = 0;
      puVar4[2] = 0;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[1] = piStack_1c[1] + 1;
        UNLOCK();
      }
      puVar4[1] = uStack_20;
      puVar4[2] = piStack_1c;
    }
    uStack_18 = 0;
    uStack_14 = 0;
    FUN_007fc3c0(puVar4,param_2);
    *param_2 = uStack_18;
    param_2[1] = uStack_14;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar3 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[1] + -1;
    param_4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 12303 ; VA 0x00802210 ; FUN_00802210 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_00802210(int param_1,int param_2,float param_3,float param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7)

{
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined4 uStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  fStack_10 = param_4 * DAT_018ce2f4;
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  fStack_14 = param_3;
  if (param_3 < fStack_10) {
    fStack_14 = fStack_10;
  }
  uStack_18 = *(undefined4 *)(param_2 + 0x2c);
  fStack_14 = fStack_14 * _DAT_019011b8;
  uStack_20 = *(undefined8 *)(param_2 + 0x24);
  fStack_c = param_3;
  fStack_8 = param_3;
  FUN_00804740(*(undefined4 *)(param_1 + 0xec),*(undefined4 *)(param_1 + 0x18),
               (undefined8 *)(param_2 + 0x24),param_2,&fStack_10,param_5,&uStack_20,&uStack_30,
               param_6,param_7);
  return;
}



/* FUNCTION 12304 ; VA 0x008022a0 ; FUN_008022a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_008022a0(int param_1,float param_2,float param_3,undefined4 param_4)

{
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_24;
  float fStack_20;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  uStack_1c = *(undefined8 *)(param_1 + 0x84);
  fStack_10 = param_3 * DAT_018ce2f4;
  uStack_24 = *(undefined4 *)(param_1 + 0x8c);
  uStack_3c = 0;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  fStack_20 = param_2;
  if (param_2 < fStack_10) {
    fStack_20 = fStack_10;
  }
  fStack_20 = fStack_20 * _DAT_019011b8;
  uStack_2c = *(undefined8 *)(param_1 + 0x84);
  fStack_c = param_2;
  fStack_8 = param_2;
  uStack_14 = uStack_24;
  FUN_00804740(*(undefined4 *)(param_1 + 0xec),*(undefined4 *)(param_1 + 0x18),&uStack_1c,
               param_1 + 0x60,&fStack_10,param_4,&uStack_2c,&uStack_3c,0xffffffff,1);
  return;
}



/* FUNCTION 12305 ; VA 0x00802340 ; FUN_00802340 */

undefined4 * __thiscall FUN_00802340(int param_1,undefined4 *param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 extraout_ECX;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b4808;
  pvStack_10 = ExceptionList;
  if ((-(uint)(*(int *)(param_1 + 0x38) != 0) & *(int *)(param_1 + 0x38) + 0xcU) != 0) {
    ExceptionList = &pvStack_10;
    iVar4 = FUN_007878b0();
    if (iVar4 != 0) {
      iVar4 = FUN_00d2af10(*(undefined4 *)(param_4 + 0x34),
                           CONCAT31((int3)((uint)iVar4 >> 8),*(byte *)(param_4 + 0xbe)) & 0xffffff01
                           ,CONCAT31((int3)((uint)extraout_ECX >> 8),*(byte *)(param_4 + 0xbe) >> 1)
                            & 0xffffff01);
      if (iVar4 == 0) {
        *param_2 = 0;
        param_2[1] = 0;
        ExceptionList = pvStack_10;
        return param_2;
      }
      iVar4 = *(int *)(param_1 + 0x94);
      if (iVar4 != 0) {
        LOCK();
        *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
        UNLOCK();
        iVar4 = *(int *)(param_1 + 0x94);
      }
      uVar2 = *(undefined4 *)(param_1 + 0x90);
      uStack_8 = 0;
      FUN_00d48ae0(&uStack_18,param_3,param_4);
      *(undefined2 *)(param_1 + 0x98) = 0;
      *(undefined4 *)(param_1 + 0x90) = uVar2;
      piVar3 = *(int **)(param_1 + 0x94);
      *(int *)(param_1 + 0x94) = iVar4;
      *param_2 = uStack_18;
      param_2[1] = uStack_14;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar4 = piVar3[1] + -1;
        piVar3[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  *param_2 = 0;
  param_2[1] = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 12306 ; VA 0x00802490 ; FUN_00802490 */

void FUN_00802490(void)

{
  FUN_007f92c0();
  return;
}



/* FUNCTION 12307 ; VA 0x008024a0 ; FUN_008024a0 */

void __thiscall
FUN_008024a0(int param_1,undefined4 *param_2,int param_3,undefined4 *param_4,undefined4 param_5,
            undefined4 param_6,char param_7,undefined4 param_8,undefined4 param_9)

{
  float fVar1;
  float *pfVar2;
  int iVar3;
  float fVar4;
  double dVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float *pfVar10;
  float fStack_d8;
  float fStack_d4;
  float fStack_cc;
  float fStack_c8;
  float fStack_c4;
  float fStack_c0;
  float fStack_bc;
  float fStack_b8;
  float fStack_b4;
  float fStack_b0;
  float fStack_ac;
  float fStack_a8;
  float fStack_a4;
  float fStack_a0;
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  undefined8 uStack_90;
  float fStack_88;
  float fStack_84;
  float fStack_80;
  float fStack_7c;
  ulonglong uStack_78;
  undefined8 uStack_6c;
  float fStack_64;
  float fStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined auStack_4c [36];
  undefined auStack_28 [4];
  undefined auStack_24 [32];
  
  pfVar10 = &fStack_88;
  pfVar2 = (float *)(**(code **)*param_4)(pfVar10,0);
  dVar5 = (double)(*pfVar2 * *pfVar2 + pfVar2[1] * pfVar2[1] + pfVar2[2] * pfVar2[2]);
  FUN_017267a0();
  iVar3 = 0;
  fStack_80 = (float)dVar5;
  if (0 < param_3) {
    uStack_5c = 0;
    uStack_58 = 0;
    uStack_54 = 0;
    uStack_50 = 0;
    fStack_7c = fStack_80;
    do {
      pfVar2 = (float *)(**(code **)*param_2)(auStack_28,(float)iVar3 / (float)param_3);
      iVar3 = iVar3 + 1;
      fVar8 = pfVar2[1];
      fVar4 = *pfVar2;
      fVar9 = pfVar2[2];
      fVar6 = *(float *)(param_1 + 0x60) * fVar4 + *(float *)(param_1 + 100) * fVar8 +
              *(float *)(param_1 + 0x68) * fVar9 + *(float *)(param_1 + 0x84);
      fVar7 = *(float *)(param_1 + 0x70) * fVar8 + fVar4 * *(float *)(param_1 + 0x6c) +
              *(float *)(param_1 + 0x74) * fVar9 + *(float *)(param_1 + 0x88);
      fVar8 = *(float *)(param_1 + 0x78) * fVar4 + *(float *)(param_1 + 0x7c) * fVar8 +
              fVar9 * *(float *)(param_1 + 0x80) + *(float *)(param_1 + 0x8c);
      if ((iVar3 == param_3) && (param_7 != '\0')) {
        fVar4 = 0.0;
      }
      else {
        fVar4 = (float)iVar3 / fStack_d8;
      }
      pfVar2 = (float *)(**(code **)*param_2)(auStack_24,fVar4);
      fVar4 = pfVar2[1];
      fVar9 = *pfVar2;
      fVar1 = pfVar2[2];
      fStack_b4 = *(float *)(param_1 + 0x60) * fVar9 + fVar4 * *(float *)(param_1 + 100) +
                  *(float *)(param_1 + 0x68) * fVar1 + *(float *)(param_1 + 0x84);
      uStack_78 = (ulonglong)(uint)fStack_b4;
      fStack_b4 = fStack_b4 - fVar8;
      fStack_a8 = *(float *)(param_1 + 0x70) * fVar4 + fVar9 * *(float *)(param_1 + 0x6c) +
                  *(float *)(param_1 + 0x74) * fVar1 + *(float *)(param_1 + 0x88);
      fStack_a4 = *(float *)(param_1 + 0x78) * fVar9 + fVar4 * *(float *)(param_1 + 0x7c) +
                  fVar1 * *(float *)(param_1 + 0x80) + *(float *)(param_1 + 0x8c);
      fStack_b0 = fStack_a8 - fStack_d8;
      fStack_ac = fStack_a4 - fStack_d4;
      dVar5 = (double)(fStack_b0 * fStack_b0 + fStack_b4 * fStack_b4 + fStack_ac * fStack_ac);
      FUN_017267a0(pfVar10,fVar6,fVar7);
      fStack_a0 = (float)dVar5;
      fStack_b8 = DAT_018ce2f8 / fStack_a0;
      fStack_bc = fStack_b0 * fStack_b8;
      fStack_c0 = fStack_b8 * fStack_b4;
      fStack_b8 = fStack_ac * fStack_b8;
      if (DAT_019011c0 <=
          (double)CONCAT44((uint)((ulonglong)(double)fStack_bc >> 0x20) & DAT_018c0da0._4_4_,
                           SUB84((double)fStack_bc,0) & (uint)DAT_018c0da0)) {
        fVar4 = 0.0;
        fVar9 = DAT_018ce2f8;
      }
      else {
        fVar4 = DAT_018ce2f8;
        fVar9 = 0.0;
      }
      fStack_cc = fVar4 * fStack_b8 - fStack_bc * 0.0;
      fStack_c4 = fStack_bc * fVar9 - fVar4 * fStack_c0;
      fStack_c8 = fStack_c0 * 0.0 - fVar9 * fStack_b8;
      FUN_01165610(0x358637bd);
      fStack_9c = fStack_c4 * fStack_bc - fStack_c8 * fStack_b8;
      fStack_98 = fStack_cc * fStack_b8 - fStack_c4 * fStack_c0;
      fStack_94 = fStack_c8 * fStack_c0 - fStack_cc * fStack_bc;
      FUN_01165610(0x358637bd);
      FUN_01162b00(0,&fStack_c0);
      FUN_01162b00(1,&fStack_cc);
      FUN_01162b00(2,&fStack_9c);
      fStack_88 = (fStack_d4 + fStack_a4) * DAT_018ce2f4;
      uStack_90 = CONCAT44((fStack_d8 + fStack_a8) * DAT_018ce2f4,
                           ((float)uStack_78 + fVar8) * DAT_018ce2f4);
      fStack_84 = fStack_a0 * DAT_018ce2f4;
      uStack_6c = uStack_90;
      fStack_64 = fStack_88;
      fStack_60 = fStack_84;
      FUN_00804740(*(undefined4 *)(param_1 + 0xec),*(undefined4 *)(param_1 + 0x18),&uStack_90,
                   auStack_4c,&fStack_84,param_6,&uStack_6c,&uStack_5c,0,param_9);
    } while (iVar3 < param_3);
  }
  return;
}



/* FUNCTION 12308 ; VA 0x00802950 ; FUN_00802950 */

void __thiscall FUN_00802950(int param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  int iStack_8;
  
  iVar2 = *(int *)(param_1 + 0xa8 + param_3 * 0xc);
  for (iVar5 = *(int *)(param_1 + 0xa4 + param_3 * 0xc); iVar5 != iVar2; iVar5 = iVar5 + 0x70) {
    iVar4 = FUN_00802ae0(param_3,*(undefined4 *)(iVar5 + 4));
    if (iVar4 != 0) {
      iStack_10 = *(int *)(iVar5 + 0xc);
      iStack_14 = *(int *)(iVar5 + 8);
      iStack_8 = *(int *)(iVar5 + 0x24);
      iStack_c = *(int *)(iVar5 + 0x10);
      iVar1 = param_2 + param_4 * 0xc;
      piVar3 = *(int **)(iVar1 + 4);
      iStack_1c = iVar5;
      iStack_18 = iVar4;
      if (*(int **)(iVar1 + 8) == piVar3) {
        FUN_006c6730(piVar3,&iStack_1c);
      }
      else {
        *piVar3 = iVar5;
        piVar3[1] = iVar4;
        piVar3[2] = iStack_14;
        piVar3[3] = iStack_10;
        piVar3[4] = iStack_c;
        piVar3[5] = iStack_8;
        *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 0x18;
      }
    }
  }
  return;
}



/* FUNCTION 12309 ; VA 0x008029f0 ; FUN_008029f0 */

void __fastcall FUN_008029f0(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iStack_8;
  
  FUN_00616fc0(*(undefined4 *)(param_1 + 0x28),*(undefined4 *)(param_1 + 0x2c));
  puVar3 = (undefined4 *)(param_1 + 0xa4);
  *(undefined4 *)(param_1 + 0x2c) = *(undefined4 *)(param_1 + 0x28);
  iStack_8 = 5;
  do {
    puVar1 = (undefined4 *)puVar3[1];
    for (puVar2 = (undefined4 *)*puVar3; puVar2 != puVar1; puVar2 = puVar2 + 0x1c) {
      (**(code **)*puVar2)(0);
    }
    puVar3[1] = *puVar3;
    puVar3 = puVar3 + 3;
    iStack_8 = iStack_8 + -1;
  } while (iStack_8 != 0);
  FUN_007f9200();
  return;
}



/* FUNCTION 12310 ; VA 0x00802a60 ; FUN_00802a60 */

void __fastcall FUN_00802a60(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00802a75. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(int *)(*(int *)(*(int *)(param_1 + 0x38) + 0x1b8) + 0x144) + 8))();
  return;
}



/* FUNCTION 12311 ; VA 0x00802a80 ; FUN_00802a80 */

void __thiscall FUN_00802a80(int param_1,float *param_2)

{
  int iVar1;
  int *piVar2;
  
  piVar2 = (int *)(*(int *)(param_1 + 4) + 0xc);
  if (*(int *)(param_1 + 4) == 0) {
    piVar2 = &DAT_01eb1b0c;
  }
  iVar1 = piVar2[1];
  *param_2 = (float)((double)*piVar2 + (double)(&DAT_018c0d90)[-(*piVar2 >> 0x1f)]);
  param_2[1] = (float)((double)iVar1 + (double)(&DAT_018c0d90)[-(iVar1 >> 0x1f)]);
  return;
}



/* FUNCTION 12312 ; VA 0x00802ae0 ; FUN_00802ae0 */

int __thiscall FUN_00802ae0(int param_1,uint param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined2 auStack_38 [2];
  undefined4 uStack_34;
  undefined2 uStack_30;
  undefined2 auStack_2c [2];
  undefined4 uStack_28;
  undefined2 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b4c17;
  pvStack_10 = ExceptionList;
  piVar2 = (int *)(param_1 + (param_2 * 0xb + 0x29 + param_3) * 8);
  if (*piVar2 != 0) {
    return *piVar2;
  }
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  param_3 = FUN_01674e20(0x50);
  uStack_8 = 0;
  if (param_3 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_0078ded0(param_1 + (iVar4 + 0x60) * 8,0,0);
  }
  uStack_8 = 0xffffffff;
  iStack_1c = 0;
  piStack_18 = (int *)0x0;
  FUN_007f73a0(uVar5,param_2);
  *piVar2 = iStack_1c;
  piVar3 = (int *)piVar2[1];
  piVar2[1] = (int)piStack_18;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  switch(param_2) {
  case 0:
  case 1:
  case 3:
    param_2._0_3_ = CONCAT21(0x104,(byte)param_2);
    param_2 = (uint)(uint3)param_2;
    FUN_0078e510((int)&param_2 + 1);
    iStack_1c = 0x1000100;
    goto LAB_00802bf0;
  case 2:
    param_2._0_3_ = CONCAT21(4,(byte)param_2);
    break;
  case 4:
    param_2._0_3_ = (uint3)(byte)param_2;
    break;
  default:
    goto switchD_00802ba7_caseD_5;
  }
  param_2 = (uint)(uint3)param_2;
  FUN_0078e510((int)&param_2 + 1);
  iStack_1c = 0x60403;
LAB_00802bf0:
  uStack_20 = 0xf;
  piStack_18 = (int *)((uint)piStack_18 & 0xffffff00);
  FUN_0078e480(&uStack_20);
switchD_00802ba7_caseD_5:
  auStack_2c[0] = 1;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_007735a0(*(int *)(*(int *)(iStack_14 + 0x34) + 0x4ec) + 0x24,3);
  uStack_8 = 1;
  FUN_0078e550(0,&iStack_1c,auStack_2c);
  piVar3 = piStack_18;
  uStack_8 = 0xffffffff;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_18[1] + -1;
    piStack_18[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  auStack_38[0] = 0x101;
  uStack_34 = 0;
  uStack_30 = 0;
  FUN_0078e550(0xf,*(int *)(*(int *)(*(int *)(iStack_14 + 0x34) + 0x4f8) + 0x44c) + 0x84,auStack_38)
  ;
  ExceptionList = pvStack_10;
  return *piVar2;
}



/* FUNCTION 12313 ; VA 0x00802ce0 ; FUN_00802ce0 */

undefined4 * FUN_00802ce0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined auStack_c [8];
  
  puVar2 = (undefined4 *)(**(code **)(*(int *)*param_2 + 4))(auStack_c);
  *param_1 = 0;
  param_1[1] = 0;
  uVar1 = puVar2[1];
  param_1[2] = *puVar2;
  param_1[3] = uVar1;
  return param_1;
}



/* FUNCTION 12314 ; VA 0x00802d20 ; FUN_00802d20 */

int __fastcall FUN_00802d20(int param_1)

{
  return param_1 + 0x58;
}



/* FUNCTION 12315 ; VA 0x00802d30 ; FUN_00802d30 */

void __thiscall FUN_00802d30(int param_1,float *param_2)

{
  int iVar1;
  int iVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  
  iVar1 = *(int *)(param_1 + 0x9c);
  iVar2 = *(int *)(param_1 + 0xa0);
  param_2[3] = 0.0;
  fVar5 = (float)iVar1 + 0.0;
  fVar4 = (float)iVar2 + 0.0;
  fVar3 = fVar5;
  if (0.0 <= fVar5) {
    fVar3 = 0.0;
  }
  *param_2 = fVar3;
  fVar3 = fVar4;
  if (0.0 <= fVar4) {
    fVar3 = 0.0;
  }
  param_2[1] = fVar3;
  if (fVar5 <= 0.0) {
    fVar5 = 0.0;
  }
  param_2[2] = fVar5;
  if (fVar4 <= 0.0) {
    fVar4 = 0.0;
  }
  param_2[3] = fVar4;
  return;
}



/* FUNCTION 12316 ; VA 0x00802da0 ; FUN_00802da0 */

void __thiscall
FUN_00802da0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,byte *param_7,undefined4 param_8)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined auStack_34 [16];
  undefined auStack_24 [8];
  undefined auStack_1c [12];
  undefined4 uStack_10;
  int iStack_c;
  int *piStack_8;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0x34) + 0x53c);
  if (*(int *)(*(int *)(*(int *)(param_1 + 0x34) + 0x530) + (uint)*param_7 * 8) != 0) {
    iStack_c = param_1;
    cVar3 = FUN_007f6940();
    if ((cVar3 != '\0') && (iVar1 != 0)) {
      piVar2 = *(int **)(iVar1 + 0x34);
      piStack_8 = (int *)&DAT_01eb1b04;
      if (piVar2 != (int *)0x0) {
        piStack_8 = piVar2;
      }
      if (*piStack_8 != 0) {
        FUN_007f67a0(auStack_34,*(undefined4 *)(param_7 + 4),*(undefined4 *)(param_7 + 8),
                     *(undefined2 *)(param_7 + 0xc),*(undefined2 *)(param_7 + 0xe),
                     param_7[0x10] != 0);
        uStack_10 = 0;
        if (param_7[0x11] != 0) {
          uStack_10 = 0x3e611f5d;
        }
        uVar4 = FUN_007fef80(auStack_1c,2);
        uVar5 = FUN_007fef80(auStack_24,0);
        FUN_00804ba0(param_3,param_6,piStack_8,1,uVar5,uVar4,param_4,param_5,param_8,uStack_10);
      }
    }
  }
  return;
}



/* FUNCTION 12317 ; VA 0x00802e80 ; FUN_00802e80 */

void __thiscall FUN_00802e80(float *param_1,float *param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  
  fVar3 = *param_1;
  fVar8 = param_3[2];
  if (fVar3 < fVar8) {
    fVar4 = param_1[1];
    fVar7 = param_3[3];
    if (fVar4 < fVar7) {
      fVar5 = param_1[2];
      fVar1 = *param_3;
      if (fVar1 < fVar5) {
        fVar6 = param_1[3];
        fVar2 = param_3[1];
        if (fVar2 < fVar6) {
          if (fVar7 <= fVar6) {
            fVar6 = fVar7;
          }
          if (fVar8 <= fVar5) {
            fVar5 = fVar8;
          }
          if (fVar4 <= fVar2) {
            fVar4 = fVar2;
          }
          if (fVar3 <= fVar1) {
            fVar3 = fVar1;
          }
          fVar8 = fVar6;
          if (fVar4 < fVar6) {
            fVar8 = fVar4;
          }
          fVar7 = fVar5;
          if (fVar3 < fVar5) {
            fVar7 = fVar3;
          }
          *param_2 = fVar7;
          param_2[1] = fVar8;
          if (fVar4 <= fVar6) {
            fVar4 = fVar6;
          }
          if (fVar3 <= fVar5) {
            fVar3 = fVar5;
          }
          param_2[2] = fVar3;
          param_2[3] = fVar4;
          return;
        }
      }
    }
  }
  param_2[3] = 0.0;
  *param_2 = 0.0;
  param_2[1] = 0.0;
  param_2[2] = 0.0;
  param_2[3] = 0.0;
  return;
}



/* FUNCTION 12318 ; VA 0x00802f60 ; FUN_00802f60 */

undefined4 __fastcall FUN_00802f60(int param_1)

{
  int iVar1;
  
  if (*(int *)(param_1 + 4) != 0) {
    iVar1 = *(int *)(*(int *)(param_1 + 4) + 8);
    return CONCAT31((int3)((uint)iVar1 >> 8),iVar1 == 3);
  }
  return 0;
}



/* FUNCTION 12319 ; VA 0x00802f80 ; FUN_00802f80 */

undefined4 __thiscall FUN_00802f80(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  float fVar3;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  
  FUN_00c9f550(&fStack_28,param_3);
  uVar2 = FUN_007ccd20(&fStack_28);
  if ((char)uVar2 == '\0') {
    return uVar2;
  }
  iVar1 = *(int *)(*(int *)(param_1 + 0x34) + 0x4f8);
  fStack_10 = (float)*(undefined8 *)(iVar1 + 4);
  fStack_c = (float)((ulonglong)*(undefined8 *)(iVar1 + 4) >> 0x20);
  fStack_10 = fStack_10 - (fStack_1c + fStack_28) * DAT_018ce2f4;
  fStack_c = fStack_c - (fStack_18 + fStack_24) * DAT_018ce2f4;
  fVar3 = *(float *)(iVar1 + 0xc) - (fStack_14 + fStack_20) * DAT_018ce2f4;
  return CONCAT31((int3)((uint)*(float *)(iVar1 + 0xc) >> 8),
                  fStack_10 * fStack_10 + fStack_c * fStack_c + fVar3 * fVar3 <
                  *(float *)(iVar1 + 0x14));
}



/* FUNCTION 12320 ; VA 0x00803050 ; FUN_00803050 */

void __thiscall
FUN_00803050(int param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_14 = *param_4;
  uStack_10 = param_4[1];
  uStack_c = param_4[2];
  uStack_8 = param_4[3];
  FUN_007f9580(*param_2,*(float *)(param_1 + 0x5c) - (float)param_2[1],*param_3,
               *(float *)(param_1 + 0x5c) - (float)param_3[1],&uStack_14);
  return;
}



/* FUNCTION 12321 ; VA 0x008030b0 ; FUN_008030b0 */

void __thiscall FUN_008030b0(int param_1,float *param_2,float *param_3,undefined4 *param_4)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  float fStack_8;
  
  fVar1 = param_2[1];
  fVar2 = *param_2;
  fVar3 = param_2[2];
  fVar4 = *param_3;
  fStack_8 = *(float *)(param_1 + 0x84) +
             *(float *)(param_1 + 0x60) * fVar2 + *(float *)(param_1 + 100) * fVar1 +
             *(float *)(param_1 + 0x68) * fVar3;
  fVar5 = param_3[2];
  fVar6 = param_3[1];
  uStack_18 = *param_4;
  uStack_14 = param_4[1];
  uStack_10 = param_4[2];
  uStack_c = param_4[3];
  FUN_007f92d0(fStack_8,*(float *)(param_1 + 0x88) +
                        *(float *)(param_1 + 0x6c) * fVar2 + *(float *)(param_1 + 0x70) * fVar1 +
                        *(float *)(param_1 + 0x74) * fVar3,
               *(float *)(param_1 + 0x8c) +
               *(float *)(param_1 + 0x7c) * fVar1 + *(float *)(param_1 + 0x78) * fVar2 +
               *(float *)(param_1 + 0x80) * fVar3,
               *(float *)(param_1 + 0x84) +
               fVar4 * *(float *)(param_1 + 0x60) + *(float *)(param_1 + 100) * fVar6 +
               *(float *)(param_1 + 0x68) * fVar5,
               *(float *)(param_1 + 0x88) +
               fVar4 * *(float *)(param_1 + 0x6c) + *(float *)(param_1 + 0x70) * fVar6 +
               *(float *)(param_1 + 0x74) * fVar5,
               *(float *)(param_1 + 0x8c) +
               fVar4 * *(float *)(param_1 + 0x78) + *(float *)(param_1 + 0x7c) * fVar6 +
               *(float *)(param_1 + 0x80) * fVar5,&uStack_18);
  return;
}



/* FUNCTION 12322 ; VA 0x00803250 ; FUN_00803250 */

void __thiscall
FUN_00803250(int param_1,float *param_2,float *param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,char param_7)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  double dVar5;
  uint uVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fStack_2d0;
  float fStack_2cc;
  float fStack_2c8;
  float afStack_2c4 [4];
  float fStack_2b4;
  float fStack_2b0;
  undefined4 uStack_2ac;
  undefined8 uStack_2a8;
  float fStack_2a0;
  float fStack_29c;
  undefined4 uStack_298;
  undefined4 uStack_294;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined4 uStack_27c;
  undefined4 uStack_278;
  undefined4 auStack_250 [28];
  float fStack_1e0;
  
  fVar8 = *param_3 - *param_2;
  fVar9 = param_3[1] - param_2[1];
  fVar10 = param_3[2] - param_2[2];
  puVar1 = (undefined4 *)(*(int *)(param_1 + 0x34) + 0x40);
  puVar4 = auStack_250;
  for (iVar3 = 0x91; iVar3 != 0; iVar3 = iVar3 + -1) {
    *puVar4 = *puVar1;
    puVar1 = puVar1 + 1;
    puVar4 = puVar4 + 1;
  }
  fStack_2d0 = fVar8 * DAT_018ce2f4 + *param_2;
  fStack_2cc = fVar9 * DAT_018ce2f4 + param_2[1];
  fStack_2c8 = fVar10 * DAT_018ce2f4 + param_2[2];
  dVar5 = (double)(fVar9 * fVar9 + fVar8 * fVar8 + fVar10 * fVar10);
  FUN_017267a0();
  afStack_2c4[1] = 1.0;
  afStack_2c4[2] = 1.0;
  fStack_29c = (float)dVar5 * DAT_018ce2f4;
  fVar7 = DAT_018ce2f8 / (float)dVar5;
  fVar8 = fVar7 * fVar8;
  fVar9 = fVar7 * fVar9;
  fVar7 = fVar7 * fVar10;
  if (fVar8 < 0.0) {
    fVar8 = fVar8 * DAT_018f7864;
    fVar9 = fVar9 * DAT_018f7864;
    fVar7 = fVar7 * DAT_018f7864;
  }
  fVar10 = fVar8 + DAT_018ce2f8;
  uVar6 = (uint)((fVar9 * fVar7) / fVar10) ^ DAT_018c4ea0;
  afStack_2c4[0] = fStack_29c;
  puVar1 = (undefined4 *)
           FUN_01160a40(fVar8,(uint)fVar9 ^ DAT_018c4ea0,(uint)fVar7 ^ DAT_018c4ea0,fVar9,
                        (fVar7 * fVar7) / fVar10 + fVar8,uVar6,fVar7,uVar6,
                        (fVar9 * fVar9) / fVar10 + fVar8);
  uStack_298 = *puVar1;
  uStack_294 = puVar1[1];
  uStack_290 = puVar1[2];
  uStack_28c = puVar1[3];
  uStack_288 = puVar1[4];
  uStack_284 = puVar1[5];
  uStack_280 = puVar1[6];
  uStack_27c = puVar1[7];
  uStack_278 = puVar1[8];
  fStack_2b4 = (float)*(int *)(param_1 + 0x9c);
  fStack_2a0 = fStack_2c8;
  uVar2 = 1;
  if (param_7 != '\0') {
    uVar2 = 4;
  }
  afStack_2c4[3] = DAT_018ce2f8 / ((float)*(int *)(param_1 + 0xa0) * fStack_1e0);
  fStack_2b0 = fStack_2b4 / (float)*(int *)(param_1 + 0xa0);
  uStack_2ac = param_5;
  uStack_2a8 = CONCAT44(fStack_2cc,fStack_2d0);
  FUN_00804740(*(undefined4 *)(param_1 + 0x104),4,&fStack_2d0,&uStack_298,afStack_2c4,param_4,
               &uStack_2a8,afStack_2c4 + 3,param_6,uVar2);
  return;
}



/* FUNCTION 12323 ; VA 0x008034d0 ; FUN_008034d0 */

void FUN_008034d0(void)

{
  return;
}



/* FUNCTION 12324 ; VA 0x008034e0 ; FUN_008034e0 */

void __thiscall
FUN_008034e0(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,int param_8,undefined4 param_9,undefined4 param_10
            )

{
  uint uVar1;
  
  switch(param_7) {
  case 0:
    FUN_00804740(*(undefined4 *)(param_1 + 0xe8),param_9,param_2 + 0x24,param_2,param_3,param_5,
                 param_4,param_6,0xffffffff,param_10);
    return;
  case 1:
    FUN_00804740(*(undefined4 *)(param_1 + 0xf0),param_9,param_2 + 0x24,param_2,param_3,param_5,
                 param_4,param_6,0xffffffff,param_10);
    return;
  case 2:
    FUN_00804740(*(undefined4 *)(param_1 + 0xec),param_9,param_2 + 0x24,param_2,param_3,param_5,
                 param_4,param_6,0xffffffff,param_10);
    return;
  case 3:
    uVar1 = param_8 + 3U >> 2;
    if (0xf < uVar1) {
      uVar1 = 0xf;
    }
    FUN_00804740(*(undefined4 *)(param_1 + 0x108 + uVar1 * 4),param_9,param_2 + 0x24,param_2,param_3
                 ,param_5,param_4,param_6,0xffffffff,param_10);
  }
  return;
}



/* FUNCTION 12325 ; VA 0x008035d0 ; FUN_008035d0 */

/* WARNING: Function: __alloca_probe_16 replaced with injection: alloca_probe */

void __thiscall FUN_008035d0(int param_1,undefined *param_2,undefined4 param_3,int param_4)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  undefined *puVar8;
  char cVar9;
  undefined *puVar10;
  float *pfVar11;
  undefined8 *puVar12;
  
  puVar8 = param_2;
  if (1 < param_4) {
    cVar9 = FUN_01163aa0();
    puVar10 = param_2;
    if (cVar9 == '\0') {
      puVar12 = (undefined8 *)&stack0xffffffe4;
      puVar10 = &stack0xffffffe4;
      if (0 < param_4) {
        param_2 = (undefined *)param_4;
        pfVar11 = (float *)(puVar8 + 8);
        do {
          fVar1 = pfVar11[-1];
          fVar2 = pfVar11[-2];
          fVar3 = *pfVar11;
          pfVar11 = pfVar11 + 3;
          fVar4 = *(float *)(param_1 + 0x78);
          fVar5 = *(float *)(param_1 + 0x7c);
          fVar6 = *(float *)(param_1 + 0x80);
          fVar7 = *(float *)(param_1 + 0x8c);
          *puVar12 = CONCAT44(fVar2 * *(float *)(param_1 + 0x6c) +
                              *(float *)(param_1 + 0x70) * fVar1 +
                              *(float *)(param_1 + 0x74) * fVar3 + *(float *)(param_1 + 0x88),
                              fVar2 * *(float *)(param_1 + 0x60) + fVar1 * *(float *)(param_1 + 100)
                              + *(float *)(param_1 + 0x68) * fVar3 + *(float *)(param_1 + 0x84));
          *(float *)(puVar12 + 1) = fVar7 + fVar2 * fVar4 + fVar5 * fVar1 + fVar6 * fVar3;
          puVar12 = (undefined8 *)((int)puVar12 + 0xc);
          param_2 = (undefined *)((int)param_2 + -1);
          puVar10 = &stack0xffffffe4;
        } while (param_2 != (undefined *)0x0);
      }
    }
    FUN_007f9820(puVar10,param_3,param_4);
  }
  return;
}



/* FUNCTION 12326 ; VA 0x00803700 ; FUN_00803700 */

void __fastcall FUN_00803700(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *(undefined4 *)(param_1 + 0x90) = 0;
  piVar2 = *(int **)(param_1 + 0x94);
  *(undefined4 *)(param_1 + 0x94) = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00803740. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 12327 ; VA 0x00803750 ; FUN_00803750 */

void __fastcall FUN_00803750(int param_1)

{
  int iVar1;
  
  *(float *)(param_1 + 0x5c) = (float)*(int *)(param_1 + 0xa0);
  iVar1 = (**(code **)(**(int **)(*(int *)(param_1 + 0x34) + 0x3c) + 0x24))();
  *(bool *)(param_1 + 0x14) = iVar1 != 0;
  return;
}



/* FUNCTION 12328 ; VA 0x00803780 ; thunk_FUN_00804390 */

void __fastcall thunk_FUN_00804390(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined *puVar4;
  int iVar5;
  char cVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int iVar9;
  undefined *puVar10;
  undefined2 *puVar11;
  undefined8 uVar12;
  undefined auStack_84 [16];
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined auStack_64 [8];
  undefined auStack_5c [12];
  undefined4 uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b4c58;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if ((*(int *)(iVar3 + 0x34) < DAT_01eb36c0) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb36c0), DAT_01eb36c0 == -1)) {
    uStack_8 = 0;
    uVar12 = FUN_0152dab0(&DAT_018fdbdc,"fillGuiVertices",0xffffffff);
    DAT_01eb36bc = (undefined4)((ulonglong)uVar12 >> 0x20);
    DAT_01eb36b8 = (undefined4)uVar12;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb36c0);
  }
  uStack_34 = DAT_01eb36b8;
  uStack_74 = DAT_01eb36b8;
  uStack_30 = DAT_01eb36bc;
  uStack_70 = DAT_01eb36bc;
  uStack_6c = FUN_0152d930(DAT_01eb36b8,DAT_01eb36bc);
  uStack_8 = 1;
  if (*(int *)(iVar3 + 0x34) < DAT_01eb36d0) {
    FUN_016f3809(&DAT_01eb36d0);
    if (DAT_01eb36d0 == -1) {
      uStack_8._0_1_ = 2;
      uVar12 = FUN_0152da50(&DAT_018fdbdc);
      DAT_01eb36cc = (undefined4)((ulonglong)uVar12 >> 0x20);
      DAT_01eb36c8 = (undefined4)uVar12;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb36d0);
    }
  }
  FUN_0152d760(DAT_01eb36c8,DAT_01eb36cc,"gui count: %d",
               *(int *)(param_1 + 0x2c) - *(int *)(param_1 + 0x28) >> 3);
  piStack_1c = *(int **)(param_1 + 0x28);
  piStack_2c = *(int **)(param_1 + 0x2c);
  if (piStack_1c != piStack_2c) {
    do {
      iVar3 = *piStack_1c;
      iVar9 = *(int *)(iVar3 + 0x68) - *(int *)(iVar3 + 100);
      iVar5 = iVar9 >> 0x1f;
      if (iVar9 / 0x78 + iVar5 != iVar5) {
        *(undefined *)(param_1 + 0x9a) = *(undefined *)(iVar3 + 0x52);
        FUN_007f8fd0(piStack_1c);
        iStack_18 = *(int *)(iVar3 + 100);
        iStack_28 = *(int *)(iVar3 + 0x68);
        if (iStack_18 != iStack_28) {
          puVar11 = (undefined2 *)(iStack_18 + 0x6e);
          do {
            if (*(char *)((int)puVar11 + -0x11) == '\0') {
              if (*(int *)(puVar11 + -0x15) == 0) {
                uStack_50 = 0;
                uStack_3c = 0;
                piStack_38 = (int *)0x0;
                uStack_8._0_1_ = 3;
                FUN_00804ba0(iStack_18,puVar11 + -0x2f,&uStack_3c,*(undefined *)(puVar11 + -9),
                             puVar11 + -0x11,puVar11 + -0xd,puVar11 + -0x27,puVar11 + -0x1f,
                             *(undefined4 *)(puVar11 + 3),0);
                piVar1 = piStack_38;
                uStack_8 = CONCAT31(uStack_8._1_3_,1);
                param_1 = iStack_14;
                if (piStack_38 != (int *)0x0) {
                  LOCK();
                  iVar3 = piStack_38[1] + -1;
                  piStack_38[1] = iVar3;
                  UNLOCK();
                  if (iVar3 == 0) {
                    (**(code **)*piStack_38)();
                    LOCK();
                    piVar2 = piVar1 + 2;
                    iVar3 = *piVar2 + -1;
                    *piVar2 = iVar3;
                    UNLOCK();
                    param_1 = iStack_14;
                    if (iVar3 == 0) {
                      (**(code **)(*piVar1 + 4))();
                      param_1 = iStack_14;
                    }
                  }
                }
              }
              else {
                puVar4 = *(undefined **)(*(int *)(puVar11 + -0x15) + 4);
                uStack_48 = 0;
                puVar10 = &DAT_01eb1b04;
                if (puVar4 != (undefined *)0x0) {
                  puVar10 = puVar4;
                }
                FUN_00804ba0(iStack_18,puVar11 + -0x2f,puVar10,*(undefined *)(puVar11 + -9),
                             puVar11 + -0x11,puVar11 + -0xd,puVar11 + -0x27,puVar11 + -0x1f,
                             *(undefined4 *)(puVar11 + 3),0);
              }
            }
            else {
              piVar1 = (int *)(param_1 + 0x34);
              uStack_24 = *(undefined4 *)(puVar11 + 3);
              piStack_20 = *(int **)(*piVar1 + 0x53c);
              param_1 = iStack_14;
              if (*(int *)(*(int *)(*piVar1 + 0x530) + (uint)*(byte *)(puVar11 + -7) * 8) != 0) {
                cVar6 = FUN_007f6940();
                param_1 = iStack_14;
                if ((cVar6 != '\0') && (piStack_20 != (int *)0x0)) {
                  piVar1 = piStack_20 + 0xd;
                  piStack_20 = (int *)&DAT_01eb1b04;
                  if ((int *)*piVar1 != (int *)0x0) {
                    piStack_20 = (int *)*piVar1;
                  }
                  if (*piStack_20 != 0) {
                    FUN_007f67a0(auStack_84,*(undefined4 *)(puVar11 + -5),
                                 *(undefined4 *)(puVar11 + -3),puVar11[-1],*puVar11,
                                 *(char *)(puVar11 + 1) != '\0');
                    uStack_40 = 0;
                    if (*(char *)((int)puVar11 + 3) != '\0') {
                      uStack_40 = 0x3e611f5d;
                    }
                    uVar7 = FUN_007fef80(auStack_5c,2);
                    uVar8 = FUN_007fef80(auStack_64,0);
                    param_1 = iStack_14;
                    FUN_00804ba0(iStack_18,puVar11 + -0x2f,piStack_20,1,uVar8,uVar7,puVar11 + -0x27,
                                 puVar11 + -0x1f,uStack_24,uStack_40);
                  }
                }
              }
            }
            puVar11 = puVar11 + 0x3c;
            iStack_18 = iStack_18 + 0x78;
          } while (iStack_18 != iStack_28);
        }
        FUN_007f92a0();
        *(undefined *)(param_1 + 0x9a) = 1;
      }
      piStack_1c = piStack_1c + 2;
    } while (piStack_1c != piStack_2c);
  }
  uStack_8 = 4;
  FUN_0152dda0(uStack_34,uStack_30,uStack_6c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12329 ; VA 0x00803790 ; FUN_00803790 */

void __thiscall FUN_00803790(int param_1,undefined4 param_2)

{
  if (*(int *)(param_1 + 8) != *(int *)(param_1 + 4)) {
    FUN_007fc520(param_1);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x70;
    return;
  }
  FUN_007fbe60(*(int *)(param_1 + 4),param_2);
  return;
}



/* FUNCTION 12330 ; VA 0x008037c0 ; FUN_008037c0 */

void __thiscall FUN_008037c0(int param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  
  puVar1 = *(undefined8 **)(param_1 + 4);
  if (*(undefined8 **)(param_1 + 8) != puVar1) {
    *puVar1 = *param_2;
    *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_2 + 1);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0xc;
    return;
  }
  FUN_007fc130(puVar1,param_2);
  return;
}



/* FUNCTION 12331 ; VA 0x00803800 ; FUN_00803800 */

void __thiscall
FUN_00803800(int param_1,char param_2,int param_3,float *param_4,undefined4 param_5,
            undefined4 param_6,byte param_7)

{
  undefined4 uVar1;
  undefined4 uVar2;
  double dVar3;
  float fStack_34;
  float fStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_20;
  float fStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  uStack_28 = *(undefined8 *)(param_3 + 0x24);
  uStack_20 = *(undefined4 *)(param_3 + 0x2c);
  dVar3 = (double)(*param_4 * *param_4 + param_4[1] * param_4[1]);
  FUN_017267a0();
  fStack_1c = (float)dVar3 * DAT_018ce2f4;
  if (param_2 == '\0') {
    uVar2 = *(undefined4 *)(param_1 + 0xe0);
  }
  else {
    uVar2 = *(undefined4 *)(param_1 + 0xe4);
  }
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_10 = 0;
  uStack_c = 0;
  uStack_2c = 0;
  fStack_34 = *param_4 * DAT_018ce2f4;
  fStack_30 = param_4[1] * DAT_018ce2f4;
  uVar1 = 1;
  if (param_7 != 0) {
    uVar1 = 6;
  }
  FUN_00804740(uVar2,uVar1,(undefined8 *)(param_3 + 0x24),param_3,&fStack_34,param_5,&uStack_28,
               &uStack_18,param_6,(uint)param_7 * 2 + 2);
  return;
}



/* FUNCTION 12332 ; VA 0x008038f0 ; FUN_008038f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_008038f0(int param_1,float *param_2,undefined4 param_3)

{
  double dVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  float fStack_90;
  float fStack_8c;
  float fStack_88;
  float fStack_84;
  float fStack_80;
  float fStack_7c;
  float fStack_78;
  float fStack_74;
  float fStack_70;
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  undefined8 uStack_4c;
  float fStack_44;
  float fStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined auStack_2c [40];
  
  fStack_78 = param_2[4] * param_2[4];
  fStack_74 = param_2[5] * param_2[5];
  dVar1 = (double)(param_2[3] * param_2[3] + fStack_78 + fStack_74);
  FUN_017267a0();
  fVar9 = param_2[1] + param_2[4] * DAT_018ce2f4;
  fVar3 = *param_2 + param_2[3] * DAT_018ce2f4;
  fVar6 = param_2[2] + param_2[5] * DAT_018ce2f4;
  fStack_68 = *(float *)(param_1 + 0x8c);
  fStack_44 = *(float *)(param_1 + 0x78) * fVar3 + *(float *)(param_1 + 0x7c) * fVar9 +
              *(float *)(param_1 + 0x80) * fVar6 + fStack_68;
  uStack_4c = CONCAT44(*(float *)(param_1 + 0x6c) * fVar3 + *(float *)(param_1 + 0x70) * fVar9 +
                       *(float *)(param_1 + 0x74) * fVar6 + *(float *)(param_1 + 0x88),
                       *(float *)(param_1 + 0x60) * fVar3 + *(float *)(param_1 + 100) * fVar9 +
                       *(float *)(param_1 + 0x68) * fVar6 + *(float *)(param_1 + 0x84));
  fVar9 = (float)dVar1 / DAT_018fabe4;
  fStack_40 = (float)dVar1 * DAT_018ce2f4;
  fVar6 = param_2[4] * DAT_018ce2f4 * DAT_019011a8 + param_2[1];
  fVar7 = param_2[3] * DAT_018ce2f4 * DAT_019011a8 + *param_2;
  fVar4 = param_2[5] * DAT_018ce2f4 * DAT_019011a8 + param_2[2];
  fVar3 = param_2[3];
  fStack_58 = fVar7 * *(float *)(param_1 + 0x60) + fVar6 * *(float *)(param_1 + 100) +
              fVar4 * *(float *)(param_1 + 0x68) + *(float *)(param_1 + 0x84);
  fStack_54 = fVar6 * *(float *)(param_1 + 0x70) + fVar7 * *(float *)(param_1 + 0x6c) +
              *(float *)(param_1 + 0x74) * fVar4 + *(float *)(param_1 + 0x88);
  fVar2 = param_2[4] * DAT_019011a8 + param_2[1];
  fVar8 = fVar3 * DAT_019011a8 + *param_2;
  fVar5 = param_2[5] * DAT_019011a8 + param_2[2];
  fStack_50 = *(float *)(param_1 + 0x78) * fVar7 + *(float *)(param_1 + 0x7c) * fVar6 +
              *(float *)(param_1 + 0x80) * fVar4 + fStack_68;
  fVar4 = fVar9 * DAT_018ce2f4;
  fVar6 = fVar9 * DAT_019011a0;
  fStack_70 = fVar8 * *(float *)(param_1 + 0x60) + fVar2 * *(float *)(param_1 + 100) +
              fVar5 * *(float *)(param_1 + 0x68) + *(float *)(param_1 + 0x84);
  fStack_6c = fVar8 * *(float *)(param_1 + 0x6c) + fVar2 * *(float *)(param_1 + 0x70) +
              fVar5 * *(float *)(param_1 + 0x74) + *(float *)(param_1 + 0x88);
  fStack_68 = fVar8 * *(float *)(param_1 + 0x78) + fVar2 * *(float *)(param_1 + 0x7c) +
              fVar5 * *(float *)(param_1 + 0x80) + fStack_68;
  fVar2 = fVar9 * DAT_018fde64;
  fVar9 = fVar9 * _DAT_019011a4;
  dVar1 = (double)(fVar3 * fVar3 + fStack_78 + fStack_74);
  FUN_017267a0();
  fVar5 = DAT_018ce2f8 / (float)dVar1;
  fVar7 = fVar5 * param_2[3];
  fVar3 = fVar5 * param_2[4];
  fVar5 = fVar5 * param_2[5];
  fStack_84 = fVar7 * *(float *)(param_1 + 0x60) + fVar3 * *(float *)(param_1 + 100) +
              fVar5 * *(float *)(param_1 + 0x68);
  fStack_80 = fVar7 * *(float *)(param_1 + 0x6c) + fVar3 * *(float *)(param_1 + 0x70) +
              fVar5 * *(float *)(param_1 + 0x74);
  fStack_7c = fVar7 * *(float *)(param_1 + 0x78) + fVar3 * *(float *)(param_1 + 0x7c) +
              fVar5 * *(float *)(param_1 + 0x80);
  if (DAT_019011c0 <=
      (double)CONCAT44((uint)((ulonglong)(double)fStack_80 >> 0x20) & DAT_018c0da0._4_4_,
                       SUB84((double)fStack_80,0) & (uint)DAT_018c0da0)) {
    fVar5 = 0.0;
    fVar3 = DAT_018ce2f8;
  }
  else {
    fVar3 = 0.0;
    fVar5 = DAT_018ce2f8;
  }
  fStack_9c = fVar5 * fStack_7c - fStack_80 * 0.0;
  fStack_94 = fVar3 * fStack_80 - fVar5 * fStack_84;
  fStack_98 = fStack_84 * 0.0 - fVar3 * fStack_7c;
  FUN_01165610(0x358637bd);
  fStack_64 = fStack_94 * fStack_80 - fStack_98 * fStack_7c;
  fStack_60 = fStack_9c * fStack_7c - fStack_94 * fStack_84;
  fStack_5c = fStack_98 * fStack_84 - fStack_9c * fStack_80;
  FUN_01165610(0x358637bd);
  FUN_01162b00(0,&fStack_84);
  FUN_01162b00(1,&fStack_9c);
  FUN_01162b00(2,&fStack_64);
  uStack_3c = 0;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  fStack_90 = fVar4;
  fStack_8c = fVar6;
  fStack_88 = fVar6;
  FUN_00804740(*(undefined4 *)(param_1 + 0xec),*(undefined4 *)(param_1 + 0x18),&fStack_58,auStack_2c
               ,&fStack_90,param_3,&uStack_4c,&uStack_3c,0xffffffff,1);
  uStack_3c = 0;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  fStack_90 = fVar2;
  fStack_8c = fVar9;
  fStack_88 = fVar9;
  FUN_00804740(*(undefined4 *)(param_1 + 0xf8),*(undefined4 *)(param_1 + 0x18),&fStack_70,auStack_2c
               ,&fStack_90,param_3,&uStack_4c,&uStack_3c,0xffffffff,1);
  return;
}



/* FUNCTION 12333 ; VA 0x00803eb0 ; FUN_00803eb0 */

void __thiscall
FUN_00803eb0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7)

{
  FUN_00804ba0(param_2,param_3,param_1 + 0x90,*(undefined *)(param_1 + 0x99),param_4,param_5,param_6
               ,param_7,0,0);
  return;
}



/* FUNCTION 12334 ; VA 0x00803ef0 ; FUN_00803ef0 */

void __thiscall FUN_00803ef0(int param_1,int *param_2,int *param_3,int param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined2 auStack_18 [2];
  undefined4 uStack_14;
  undefined2 uStack_10;
  int iStack_c;
  int iStack_8;
  
  iStack_c = param_1;
  if (param_4 != 0) {
    iStack_8 = param_4;
    do {
      iVar1 = *param_3;
      FUN_01165910(iVar1 + 0x38);
      uStack_b8 = uStack_58;
      uStack_b4 = uStack_54;
      uStack_b0 = uStack_50;
      uStack_ac = uStack_4c;
      uStack_a8 = uStack_48;
      uStack_a4 = uStack_44;
      uStack_a0 = uStack_40;
      uStack_9c = uStack_3c;
      uStack_98 = uStack_38;
      uStack_94 = uStack_34;
      uStack_90 = uStack_30;
      uStack_8c = uStack_2c;
      uStack_88 = uStack_28;
      uStack_84 = uStack_24;
      uStack_80 = uStack_20;
      uStack_7c = uStack_1c;
      uStack_78 = *(undefined4 *)(iVar1 + 0x28);
      uStack_74 = *(undefined4 *)(iVar1 + 0x2c);
      uStack_70 = *(undefined4 *)(iVar1 + 0x30);
      uStack_6c = *(undefined4 *)(iVar1 + 0x34);
      uStack_68 = *(undefined4 *)(iVar1 + 0x14);
      uStack_64 = *(undefined4 *)(iVar1 + 0x18);
      uStack_60 = *(undefined4 *)(iVar1 + 0x1c);
      uStack_5c = *(undefined4 *)(iVar1 + 0x20);
      (**(code **)(*param_2 + 0x30))(1,&uStack_b8,0x60);
      auStack_18[0] = 1;
      uStack_14 = 0;
      uStack_10 = 0;
      (**(code **)(*param_2 + 0x34))(0,*(undefined4 *)(param_1 + 0x68),auStack_18);
      puVar2 = *(undefined4 **)(param_1 + 8);
      (**(code **)(*param_2 + 0x40))(*puVar2,puVar2[2],puVar2[3],puVar2[4],puVar2[5],0);
      param_3 = param_3 + 6;
      iStack_8 = iStack_8 + -1;
    } while (iStack_8 != 0);
  }
  *param_5 = *param_5 + param_4;
  param_5[1] = param_5[1] + *(int *)(*(int *)(iStack_c + 8) + 0x14) * param_4;
  param_5[2] = param_5[2] + param_4 * 0x60;
  return;
}



/* FUNCTION 12335 ; VA 0x00803ff0 ; FUN_00803ff0 */

void FUN_00803ff0(undefined4 param_1)

{
  FUN_00802950(param_1,0,0);
  FUN_00802950(param_1,1,4);
  FUN_00802950(param_1,2,9);
  FUN_00802950(param_1,3,0xb);
  FUN_00802950(param_1,4,0xc);
  return;
}



/* FUNCTION 12336 ; VA 0x00804040 ; FUN_00804040 */

void __thiscall FUN_00804040(float *param_1,float *param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  
  if ((NAN(*param_1) || NAN(DAT_018ce2f0)) != (*param_1 == DAT_018ce2f0)) {
    *param_2 = *param_3;
    param_2[1] = param_3[1];
    return;
  }
  fVar1 = *param_3;
  fVar2 = param_3[1];
  fVar3 = param_1[3];
  fVar4 = param_1[4];
  fVar5 = param_1[1];
  fVar6 = param_1[2];
  fVar7 = param_1[4];
  *param_2 = ((fVar1 - fVar3) * param_1[2] - (fVar2 - fVar4) * param_1[1]) + param_1[3];
  param_2[1] = (fVar1 - fVar3) * fVar5 + (fVar2 - fVar4) * fVar6 + fVar7;
  return;
}



/* FUNCTION 12337 ; VA 0x008040c0 ; FUN_008040c0 */

void __thiscall FUN_008040c0(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *(undefined4 *)(param_1 + 0x60) = *param_2;
  *(undefined4 *)(param_1 + 100) = uVar1;
  *(undefined4 *)(param_1 + 0x68) = uVar2;
  *(undefined4 *)(param_1 + 0x6c) = uVar3;
  uVar1 = param_2[5];
  uVar2 = param_2[6];
  uVar3 = param_2[7];
  *(undefined4 *)(param_1 + 0x70) = param_2[4];
  *(undefined4 *)(param_1 + 0x74) = uVar1;
  *(undefined4 *)(param_1 + 0x78) = uVar2;
  *(undefined4 *)(param_1 + 0x7c) = uVar3;
  uVar1 = param_2[9];
  uVar2 = param_2[10];
  uVar3 = param_2[0xb];
  *(undefined4 *)(param_1 + 0x80) = param_2[8];
  *(undefined4 *)(param_1 + 0x84) = uVar1;
  *(undefined4 *)(param_1 + 0x88) = uVar2;
  *(undefined4 *)(param_1 + 0x8c) = uVar3;
  return;
}



/* FUNCTION 12338 ; VA 0x008040f0 ; FUN_008040f0 */

void __thiscall FUN_008040f0(int param_1,undefined4 param_2,int *param_3,undefined param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  
  if (*param_3 == 0) {
    *(undefined4 *)(param_1 + 0x90) = 0;
    piVar5 = *(int **)(param_1 + 0x94);
    *(undefined4 *)(param_1 + 0x94) = 0;
  }
  else {
    puVar2 = *(undefined4 **)(*param_3 + 4);
    puVar3 = (undefined4 *)&DAT_01eb1b04;
    if (puVar2 != (undefined4 *)0x0) {
      puVar3 = puVar2;
    }
    iVar4 = puVar3[1];
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
      UNLOCK();
      iVar4 = puVar3[1];
    }
    *(undefined4 *)(param_1 + 0x90) = *puVar3;
    piVar5 = *(int **)(param_1 + 0x94);
    *(int *)(param_1 + 0x94) = iVar4;
  }
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar4 = piVar5[1] + -1;
    piVar5[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  *(undefined *)(param_1 + 0x99) = param_4;
  *(undefined *)(param_1 + 0x98) = 0;
  return;
}



/* FUNCTION 12339 ; VA 0x00804190 ; FUN_00804190 */

void __thiscall FUN_00804190(int param_1,undefined4 param_2,undefined4 param_3)

{
  *(undefined4 *)(param_1 + 0x9c) = param_2;
  *(undefined4 *)(param_1 + 0xa0) = param_3;
  return;
}



/* FUNCTION 12340 ; VA 0x008041b0 ; FUN_008041b0 */

void __thiscall
FUN_008041b0(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6)

{
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_18 = *(undefined4 *)(param_2 + 0x2c);
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_20 = *(undefined8 *)(param_2 + 0x24);
  uStack_14 = param_3;
  uStack_10 = param_3;
  uStack_c = param_3;
  uStack_8 = param_3;
  FUN_00804740(*(undefined4 *)(param_1 + 0xf0),*(undefined4 *)(param_1 + 0x18),
               (undefined8 *)(param_2 + 0x24),param_2,&uStack_10,param_4,&uStack_20,&uStack_30,
               param_5,param_6);
  return;
}



/* FUNCTION 12341 ; VA 0x00804220 ; FUN_00804220 */

void __thiscall FUN_00804220(int param_1,float *param_2,undefined4 param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  float fStack_24;
  float fStack_20;
  undefined8 uStack_1c;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  fVar1 = *param_2;
  fVar2 = param_2[1];
  fVar3 = param_2[2];
  fVar5 = *(float *)(param_1 + 100) * fVar2 + fVar1 * *(float *)(param_1 + 0x60) +
          *(float *)(param_1 + 0x68) * fVar3 + *(float *)(param_1 + 0x84);
  fVar4 = *(float *)(param_1 + 0x6c) * fVar1 + *(float *)(param_1 + 0x70) * fVar2 +
          *(float *)(param_1 + 0x74) * fVar3 + *(float *)(param_1 + 0x88);
  uStack_3c = 0;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_1c = CONCAT44(fVar4,fVar5);
  fStack_24 = *(float *)(param_1 + 0x78) * fVar1 + *(float *)(param_1 + 0x7c) * fVar2 +
              *(float *)(param_1 + 0x80) * fVar3 + *(float *)(param_1 + 0x8c);
  uStack_2c = CONCAT44(fVar4,fVar5);
  fStack_20 = param_2[3];
  fStack_14 = fStack_24;
  fStack_10 = fStack_20;
  fStack_c = fStack_20;
  fStack_8 = fStack_20;
  FUN_00804740(*(undefined4 *)(param_1 + 0xf0),*(undefined4 *)(param_1 + 0x18),&uStack_1c,
               (float *)(param_1 + 0x60),&fStack_10,param_3,&uStack_2c,&uStack_3c,0xffffffff,1);
  return;
}



/* FUNCTION 12342 ; VA 0x00804320 ; FUN_00804320 */

void __thiscall
FUN_00804320(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6)

{
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_18 = *(undefined4 *)(param_2 + 0x2c);
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_20 = *(undefined8 *)(param_2 + 0x24);
  uStack_14 = param_3;
  uStack_10 = param_3;
  uStack_c = param_3;
  uStack_8 = param_3;
  FUN_00804740(*(undefined4 *)(param_1 + 0xf4),*(undefined4 *)(param_1 + 0x18),
               (undefined8 *)(param_2 + 0x24),param_2,&uStack_10,param_4,&uStack_20,&uStack_30,
               param_5,param_6);
  return;
}



/* FUNCTION 12343 ; VA 0x00804390 ; FUN_00804390 */

void __fastcall FUN_00804390(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined *puVar4;
  int iVar5;
  char cVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int iVar9;
  undefined *puVar10;
  undefined2 *puVar11;
  undefined8 uVar12;
  undefined auStack_84 [16];
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined auStack_64 [8];
  undefined auStack_5c [12];
  undefined4 uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b4c58;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if ((*(int *)(iVar3 + 0x34) < DAT_01eb36c0) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb36c0), DAT_01eb36c0 == -1)) {
    uStack_8 = 0;
    uVar12 = FUN_0152dab0(&DAT_018fdbdc,"fillGuiVertices",0xffffffff);
    DAT_01eb36bc = (undefined4)((ulonglong)uVar12 >> 0x20);
    DAT_01eb36b8 = (undefined4)uVar12;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb36c0);
  }
  uStack_34 = DAT_01eb36b8;
  uStack_74 = DAT_01eb36b8;
  uStack_30 = DAT_01eb36bc;
  uStack_70 = DAT_01eb36bc;
  uStack_6c = FUN_0152d930(DAT_01eb36b8,DAT_01eb36bc);
  uStack_8 = 1;
  if (*(int *)(iVar3 + 0x34) < DAT_01eb36d0) {
    FUN_016f3809(&DAT_01eb36d0);
    if (DAT_01eb36d0 == -1) {
      uStack_8._0_1_ = 2;
      uVar12 = FUN_0152da50(&DAT_018fdbdc);
      DAT_01eb36cc = (undefined4)((ulonglong)uVar12 >> 0x20);
      DAT_01eb36c8 = (undefined4)uVar12;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eb36d0);
    }
  }
  FUN_0152d760(DAT_01eb36c8,DAT_01eb36cc,"gui count: %d",
               *(int *)(param_1 + 0x2c) - *(int *)(param_1 + 0x28) >> 3);
  piStack_1c = *(int **)(param_1 + 0x28);
  piStack_2c = *(int **)(param_1 + 0x2c);
  if (piStack_1c != piStack_2c) {
    do {
      iVar3 = *piStack_1c;
      iVar9 = *(int *)(iVar3 + 0x68) - *(int *)(iVar3 + 100);
      iVar5 = iVar9 >> 0x1f;
      if (iVar9 / 0x78 + iVar5 != iVar5) {
        *(undefined *)(param_1 + 0x9a) = *(undefined *)(iVar3 + 0x52);
        FUN_007f8fd0(piStack_1c);
        iStack_18 = *(int *)(iVar3 + 100);
        iStack_28 = *(int *)(iVar3 + 0x68);
        if (iStack_18 != iStack_28) {
          puVar11 = (undefined2 *)(iStack_18 + 0x6e);
          do {
            if (*(char *)((int)puVar11 + -0x11) == '\0') {
              if (*(int *)(puVar11 + -0x15) == 0) {
                uStack_50 = 0;
                uStack_3c = 0;
                piStack_38 = (int *)0x0;
                uStack_8._0_1_ = 3;
                FUN_00804ba0(iStack_18,puVar11 + -0x2f,&uStack_3c,*(undefined *)(puVar11 + -9),
                             puVar11 + -0x11,puVar11 + -0xd,puVar11 + -0x27,puVar11 + -0x1f,
                             *(undefined4 *)(puVar11 + 3),0);
                piVar1 = piStack_38;
                uStack_8 = CONCAT31(uStack_8._1_3_,1);
                param_1 = iStack_14;
                if (piStack_38 != (int *)0x0) {
                  LOCK();
                  iVar3 = piStack_38[1] + -1;
                  piStack_38[1] = iVar3;
                  UNLOCK();
                  if (iVar3 == 0) {
                    (**(code **)*piStack_38)();
                    LOCK();
                    piVar2 = piVar1 + 2;
                    iVar3 = *piVar2 + -1;
                    *piVar2 = iVar3;
                    UNLOCK();
                    param_1 = iStack_14;
                    if (iVar3 == 0) {
                      (**(code **)(*piVar1 + 4))();
                      param_1 = iStack_14;
                    }
                  }
                }
              }
              else {
                puVar4 = *(undefined **)(*(int *)(puVar11 + -0x15) + 4);
                uStack_48 = 0;
                puVar10 = &DAT_01eb1b04;
                if (puVar4 != (undefined *)0x0) {
                  puVar10 = puVar4;
                }
                FUN_00804ba0(iStack_18,puVar11 + -0x2f,puVar10,*(undefined *)(puVar11 + -9),
                             puVar11 + -0x11,puVar11 + -0xd,puVar11 + -0x27,puVar11 + -0x1f,
                             *(undefined4 *)(puVar11 + 3),0);
              }
            }
            else {
              piVar1 = (int *)(param_1 + 0x34);
              uStack_24 = *(undefined4 *)(puVar11 + 3);
              piStack_20 = *(int **)(*piVar1 + 0x53c);
              param_1 = iStack_14;
              if (*(int *)(*(int *)(*piVar1 + 0x530) + (uint)*(byte *)(puVar11 + -7) * 8) != 0) {
                cVar6 = FUN_007f6940();
                param_1 = iStack_14;
                if ((cVar6 != '\0') && (piStack_20 != (int *)0x0)) {
                  piVar1 = piStack_20 + 0xd;
                  piStack_20 = (int *)&DAT_01eb1b04;
                  if ((int *)*piVar1 != (int *)0x0) {
                    piStack_20 = (int *)*piVar1;
                  }
                  if (*piStack_20 != 0) {
                    FUN_007f67a0(auStack_84,*(undefined4 *)(puVar11 + -5),
                                 *(undefined4 *)(puVar11 + -3),puVar11[-1],*puVar11,
                                 *(char *)(puVar11 + 1) != '\0');
                    uStack_40 = 0;
                    if (*(char *)((int)puVar11 + 3) != '\0') {
                      uStack_40 = 0x3e611f5d;
                    }
                    uVar7 = FUN_007fef80(auStack_5c,2);
                    uVar8 = FUN_007fef80(auStack_64,0);
                    param_1 = iStack_14;
                    FUN_00804ba0(iStack_18,puVar11 + -0x2f,piStack_20,1,uVar8,uVar7,puVar11 + -0x27,
                                 puVar11 + -0x1f,uStack_24,uStack_40);
                  }
                }
              }
            }
            puVar11 = puVar11 + 0x3c;
            iStack_18 = iStack_18 + 0x78;
          } while (iStack_18 != iStack_28);
        }
        FUN_007f92a0();
        *(undefined *)(param_1 + 0x9a) = 1;
      }
      piStack_1c = piStack_1c + 2;
    } while (piStack_1c != piStack_2c);
  }
  uStack_8 = 4;
  FUN_0152dda0(uStack_34,uStack_30,uStack_6c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12344 ; VA 0x00804740 ; FUN_00804740 */

int __thiscall
FUN_00804740(int param_1,undefined4 param_2,int param_3,float *param_4,undefined4 param_5,
            undefined4 *param_6,undefined4 *param_7,float *param_8,undefined4 *param_9,uint param_10
            ,int param_11)

{
  int *piVar1;
  int iVar2;
  undefined8 uVar3;
  bool bVar4;
  int iVar5;
  undefined4 *puVar6;
  int *piVar7;
  int *piVar8;
  float10 fVar9;
  double dVar10;
  undefined auStack_114 [48];
  undefined auStack_e4 [20];
  undefined4 uStack_d0;
  undefined8 uStack_cc;
  float fStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined **ppuStack_b0;
  int iStack_ac;
  undefined4 uStack_a8;
  float fStack_a4;
  float fStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  uint uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  float fStack_4c;
  int iStack_48;
  int *piStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  float fStack_34;
  float fStack_30;
  int iStack_2c;
  int *piStack_28;
  float fStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017b4c83;
  pvStack_1c = ExceptionList;
  fStack_24 = (float)(*(int *)(param_1 + 0x34) + 0x40);
  if ((param_11 == 4) && (param_3 == 1)) {
    param_3 = 6;
  }
  if (*(int *)(param_1 + 0x300 + param_3 * 8) == 0) {
    return param_3;
  }
  ExceptionList = &pvStack_1c;
  iVar5 = FUN_007ccf30(param_8);
  if ((char)iVar5 == '\0') {
    ExceptionList = pvStack_1c;
    return iVar5;
  }
  iVar5 = *(int *)(*(int *)(param_1 + 0x34) + 0x4f8);
  uVar3 = *(undefined8 *)(iVar5 + 4);
  fStack_34 = *(float *)(iVar5 + 0xc);
  uStack_3c._0_4_ = (float)uVar3;
  uStack_3c._4_4_ = (float)((ulonglong)uVar3 >> 0x20);
  piStack_28 = *(int **)(iVar5 + 0x14);
  fStack_30 = (uStack_3c._4_4_ - param_8[1]) * (uStack_3c._4_4_ - param_8[1]) +
              ((float)uStack_3c - *param_8) * ((float)uStack_3c - *param_8) +
              (fStack_34 - param_8[2]) * (fStack_34 - param_8[2]);
  uStack_3c = uVar3;
  iVar5 = FUN_01155a30(1,fStack_30,0);
  if ((*(int *)(param_1 + 0x1c) == 0) && ((float)piStack_28 < fStack_30)) {
    ExceptionList = pvStack_1c;
    return iVar5;
  }
  FUN_01160a40(*param_6,0,0,0,param_6[1],0,0,0,param_6[2]);
  puVar6 = (undefined4 *)FUN_01160c20(auStack_e4,auStack_114);
  uStack_40 = *puVar6;
  uStack_3c._0_4_ = (float)puVar6[1];
  uStack_3c._4_4_ = (float)puVar6[2];
  fStack_34 = (float)puVar6[3];
  uStack_c0 = puVar6[4];
  uStack_bc = puVar6[5];
  uStack_b8 = puVar6[6];
  uStack_b4 = puVar6[7];
  uStack_d0 = puVar6[8];
  fStack_c4 = param_4[2];
  uStack_cc = *(undefined8 *)param_4;
  fVar9 = (float10)FUN_00841650(fStack_24,param_4,0);
  fStack_a0 = param_8[3];
  piVar7 = (int *)(param_1 + 0x90);
  fStack_a4 = (float)fVar9;
  if (*piVar7 == 0) {
    piVar7 = (int *)(*(int *)(*(int *)(param_1 + 0x34) + 0x4ec) + 0x24);
  }
  piVar8 = (int *)piVar7[1];
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
    piVar8 = (int *)piVar7[1];
  }
  iStack_48 = *piVar7;
  uStack_14 = 0;
  piVar7 = piVar8 + 1;
  if (piVar8 != (int *)0x0) {
    LOCK();
    *piVar7 = *piVar7 + 1;
    UNLOCK();
  }
  uStack_a8 = param_2;
  ppuStack_b0 = RBX::Graphics::AdornMesh::vftable;
  iStack_ac = param_3;
  uStack_9c = *param_9;
  uStack_98 = param_9[1];
  uStack_94 = param_9[2];
  uStack_90 = param_9[3];
  uStack_8c = param_10;
  uStack_88 = *param_7;
  uStack_84 = param_7[1];
  uStack_80 = param_7[2];
  uStack_7c = param_7[3];
  uStack_78 = uStack_40;
  uStack_74 = (float)uStack_3c;
  uStack_70 = uStack_3c._4_4_;
  uStack_6c = fStack_34;
  uStack_68 = uStack_c0;
  uStack_64 = uStack_bc;
  uStack_60 = uStack_b8;
  uStack_5c = uStack_b4;
  uStack_58 = uStack_d0;
  uStack_54 = (undefined4)uStack_cc;
  uStack_50 = uStack_cc._4_4_;
  fStack_4c = fStack_c4;
  piStack_44 = piVar8;
  iStack_2c = iStack_48;
  piStack_28 = piVar8;
  fStack_24 = fStack_a4;
  if (piVar8 != (int *)0x0) {
    LOCK();
    *piVar7 = *piVar7 + 1;
    UNLOCK();
    LOCK();
    iVar5 = *piVar7;
    *piVar7 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      iVar5 = piVar8[2] + -1;
      piVar8[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  if (((((float)param_7[3] < DAT_018ce2f8) || (param_3 == 4)) || (param_3 == 5)) || (param_3 == 10))
  {
    bVar4 = false;
  }
  else {
    bVar4 = true;
  }
  switch(param_11) {
  case 0:
    break;
  case 1:
switchD_00804a24_caseD_1:
    if (!bVar4) goto switchD_00804a24_caseD_2;
    break;
  case 2:
switchD_00804a24_caseD_2:
    fVar9 = (float10)FUN_00841650(*(int *)(param_1 + 0x34) + 0x40,param_4,0);
    fStack_a4 = (float)fVar9;
    if (DAT_01d60f98 == '\0') {
      fStack_a0 = 0.0;
    }
    else {
      dVar10 = (double)((param_8[1] - param_4[1]) * (param_8[1] - param_4[1]) +
                        (*param_8 - *param_4) * (*param_8 - *param_4) +
                       (param_8[2] - param_4[2]) * (param_8[2] - param_4[2]));
      FUN_017267a0();
      fStack_a0 = (float)dVar10 + param_8[3];
    }
    break;
  case 3:
    break;
  case 4:
    if (10 < param_10) goto switchD_00804a24_caseD_1;
    fVar9 = (float10)FUN_00841650(*(int *)(param_1 + 0x34) + 0x40,param_4,0);
    fStack_a4 = (float)fVar9;
    break;
  default:
    goto switchD_00804a24_caseD_5;
  }
  FUN_00803790(&ppuStack_b0);
switchD_00804a24_caseD_5:
  piVar7 = piStack_44;
  if (piStack_44 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_44[1] + -1;
    piStack_44[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_44)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  iVar5 = FUN_007f6360();
  if (piVar8 != (int *)0x0) {
    piVar7 = piVar8 + 1;
    LOCK();
    iVar2 = *piVar7;
    iVar5 = *piVar7;
    *piVar7 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piVar8)();
      LOCK();
      piVar7 = piVar8 + 2;
      iVar2 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return iVar5;
}



/* FUNCTION 12345 ; VA 0x00804ba0 ; FUN_00804ba0 */

void __thiscall
FUN_00804ba0(int param_1,float *param_2,float *param_3,int *param_4,undefined4 param_5,
            float *param_6,float *param_7,undefined4 param_8,float *param_9,undefined4 *param_10,
            float param_11)

{
  float fVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  int iVar6;
  float *pfVar7;
  float *pfVar8;
  undefined4 uVar9;
  int *piVar10;
  int iVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  undefined8 uVar17;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  int iStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  undefined4 uStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pfVar8 = param_9;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b4ca4;
  pvStack_10 = ExceptionList;
  fStack_44 = 0.0;
  fStack_3c = 0.0;
  fStack_34 = 0.0;
  fStack_68 = *param_2;
  fStack_64 = param_2[1];
  fStack_60 = param_2[2];
  fStack_5c = param_2[3];
  fStack_2c = 0.0;
  fStack_50 = *param_7;
  fStack_4c = param_7[1];
  fStack_58 = *param_6;
  fStack_54 = param_6[1];
  iVar6 = *(int *)(*(int *)(param_1 + 0x34) + 0x53c);
  if (iVar6 == 0) {
    iVar6 = 0;
  }
  else {
    piVar2 = *(int **)(iVar6 + 0x34);
    piVar10 = (int *)&DAT_01eb1b04;
    if (piVar2 != (int *)0x0) {
      piVar10 = piVar2;
    }
    iVar6 = *piVar10;
  }
  if ((iVar6 == 0) || (*param_4 != iVar6)) {
    cVar5 = '\0';
  }
  else {
    cVar5 = '\x01';
  }
  uStack_18 = CONCAT31(uStack_18._1_3_,cVar5);
  iStack_28 = param_1;
  if (NAN(*param_9) == (*param_9 == 0.0)) {
    ExceptionList = &pvStack_10;
    pfVar7 = (float *)FUN_0114ea70(&uStack_78,param_2);
    fStack_20 = *param_9;
    fStack_68 = *pfVar7;
    fStack_64 = pfVar7[1];
    fStack_60 = pfVar7[2];
    fStack_5c = pfVar7[3];
    fVar12 = fStack_64 + 0.0;
    fStack_1c = (fStack_5c - fStack_64) * param_11;
    fStack_48 = fStack_68 + fStack_1c;
    fStack_44 = fVar12;
    if (NAN(fStack_20) == (fStack_20 == 0.0)) {
      fVar15 = fStack_48 - param_9[3];
      fStack_14 = fVar15 * param_9[2] - (fVar12 - param_9[4]) * param_9[1];
      fStack_48 = fStack_14 + param_9[3];
      fStack_44 = (fVar12 - param_9[4]) * param_9[2] + fVar15 * param_9[1] + param_9[4];
    }
    fStack_40 = fStack_1c + fStack_60;
    if (NAN(fStack_20) == (fStack_20 == 0.0)) {
      fVar15 = fStack_40 - param_9[3];
      fStack_1c = param_9[2] * fVar15;
      fStack_40 = (fStack_1c - param_9[1] * (fVar12 - param_9[4])) + param_9[3];
      fVar12 = param_9[2] * (fVar12 - param_9[4]) + param_9[1] * fVar15 + param_9[4];
    }
    param_9 = (float *)fVar12;
    fStack_38 = fStack_68;
    fStack_34 = fStack_5c;
    if (NAN(fStack_20) == (fStack_20 == 0.0)) {
      fStack_38 = (pfVar8[2] * (fStack_68 - pfVar8[3]) - pfVar8[1] * (fStack_5c - pfVar8[4])) +
                  pfVar8[3];
      fStack_34 = pfVar8[2] * (fStack_5c - pfVar8[4]) + pfVar8[1] * (fStack_68 - pfVar8[3]) +
                  pfVar8[4];
    }
    fStack_2c = fStack_5c;
    fStack_3c = (float)param_9;
    fStack_30 = fStack_60;
    fStack_24 = fStack_68;
    if (NAN(fStack_20) == (fStack_20 == 0.0)) {
      fStack_2c = (fStack_60 - pfVar8[3]) * pfVar8[1] + (fStack_5c - pfVar8[4]) * pfVar8[2] +
                  pfVar8[4];
      fStack_30 = ((fStack_60 - pfVar8[3]) * pfVar8[2] - (fStack_5c - pfVar8[4]) * pfVar8[1]) +
                  pfVar8[3];
    }
    goto LAB_008050fa;
  }
  fVar12 = *param_2;
  fVar15 = *param_3;
  if (((NAN(fVar15) || NAN(fVar12)) == (fVar15 == fVar12)) ||
     ((NAN(param_3[1]) || NAN(param_2[1])) == (param_3[1] == param_2[1]))) {
    fVar16 = param_2[2];
LAB_00804f0b:
    if ((fVar16 <= fVar15) ||
       ((fStack_5c = param_3[1], param_2[3] <= fStack_5c || (fVar13 = param_3[2], fVar13 <= fVar12))
       )) {
LAB_00804f8c:
      fStack_68 = 0.0;
      fStack_64 = 0.0;
      fStack_5c = 0.0;
      fStack_60 = 0.0;
    }
    else {
      fVar14 = param_3[3];
      fVar1 = param_2[1];
      if (fVar14 <= fVar1) goto LAB_00804f8c;
      if (param_2[3] <= fVar14) {
        fVar14 = param_2[3];
      }
      if (fVar16 <= fVar13) {
        fVar13 = fVar16;
      }
      if (fStack_5c <= fVar1) {
        fStack_5c = fVar1;
      }
      if (fVar15 <= fVar12) {
        fVar15 = fVar12;
      }
      fStack_64 = fVar14;
      if (fStack_5c < fVar14) {
        fStack_64 = fStack_5c;
      }
      fStack_68 = fVar13;
      if (fVar15 < fVar13) {
        fStack_68 = fVar15;
      }
      if (fStack_5c <= fVar14) {
        fStack_5c = fVar14;
      }
      fStack_60 = fVar15;
      if (fVar15 <= fVar13) {
        fStack_60 = fVar13;
      }
    }
    fVar12 = fVar16 - *param_2;
    if (NAN(fVar12) == (fVar12 == 0.0)) {
      fStack_58 = ((fStack_68 - *param_2) * (*param_7 - *param_6)) / fVar12 + *param_6;
      fStack_50 = ((fStack_60 - fVar16) * (*param_7 - *param_6)) / fVar12 + *param_7;
    }
    fVar12 = param_2[3] - param_2[1];
    if (NAN(fVar12) == (fVar12 == 0.0)) {
      fStack_54 = ((fStack_64 - param_2[1]) * (param_7[1] - param_6[1])) / fVar12 + param_6[1];
      fStack_4c = ((fStack_5c - param_2[3]) * (param_7[1] - param_6[1])) / fVar12 + param_7[1];
    }
  }
  else {
    fVar16 = param_2[2];
    if (((NAN(param_3[2]) || NAN(fVar16)) == (param_3[2] == fVar16)) ||
       ((NAN(param_3[3]) || NAN(param_2[3])) == (param_3[3] == param_2[3]))) goto LAB_00804f0b;
  }
  if ((DAT_01d61ee4 == '\0') || (ExceptionList = &pvStack_10, cVar5 != '\x01')) {
    ExceptionList = &pvStack_10;
    pfVar8 = (float *)FUN_0114ea70(&uStack_78,&fStack_68);
    fStack_68 = *pfVar8;
    fStack_64 = pfVar8[1];
    fStack_60 = pfVar8[2];
    fStack_5c = pfVar8[3];
  }
  fStack_44 = fStack_64 + 0.0;
  fStack_40 = (param_2[3] - fStack_64) * param_11;
  param_11 = (param_2[3] - fStack_5c) * param_11;
  fStack_48 = fStack_68 + fStack_40;
  fStack_38 = fStack_68 + param_11;
  fStack_40 = fStack_60 + fStack_40;
  fStack_30 = fStack_60 + param_11;
  fStack_34 = fStack_5c + 0.0;
  fStack_2c = fStack_34;
  fStack_3c = fStack_44;
LAB_008050fa:
  if (param_10 == (undefined4 *)0x0) {
    if (*(char *)(iStack_28 + 0x9a) == '\0') {
      fStack_44 = fStack_44 * DAT_018f7864;
      fStack_3c = fStack_3c * DAT_018f7864;
      fStack_34 = fStack_34 * DAT_018f7864;
      fStack_2c = fStack_2c * DAT_018f7864;
    }
    else {
      fVar12 = *(float *)(iStack_28 + 0x5c);
      fStack_44 = fVar12 - fStack_44;
      fStack_3c = fVar12 - fStack_3c;
      fStack_34 = fVar12 - fStack_34;
      fStack_2c = fVar12 - fStack_2c;
    }
    FUN_007f9ce0(param_4,param_8,&fStack_48,&fStack_40,&fStack_38,&fStack_30,&fStack_58,&fStack_50,
                 uStack_18,0,param_5);
    ExceptionList = pvStack_10;
    return;
  }
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb36b0) &&
     (FUN_016f3809(&DAT_01eb36b0), DAT_01eb36b0 == -1)) {
    uStack_8 = 0;
    uVar17 = FUN_0152dab0(&DAT_018fdbdc,"Process GuiEffect",0xffffffff);
    DAT_01eb36ac = (undefined4)((ulonglong)uVar17 >> 0x20);
    DAT_01eb36a8 = (undefined4)uVar17;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb36b0);
  }
  uVar4 = DAT_01eb36ac;
  uVar3 = DAT_01eb36a8;
  uStack_78 = DAT_01eb36a8;
  uStack_74 = DAT_01eb36ac;
  uStack_70 = FUN_0152d930(DAT_01eb36a8,DAT_01eb36ac);
  iVar6 = iStack_28;
  uStack_8 = 1;
  if (*(char *)(iStack_28 + 0x9a) == '\0') {
    iVar11 = -1;
  }
  else {
    iVar11 = (int)*(float *)(iStack_28 + 0x5c);
  }
  FUN_008616b0(&fStack_48,&fStack_40,&fStack_38,&fStack_30,&fStack_58,&fStack_50,*param_10,iVar11);
  if ((char)uStack_18 == '\x01') {
    uVar9 = 0xffffffff;
  }
  else {
    uVar9 = param_10[1];
  }
  FUN_008610e0(uVar9,param_2,param_6,param_7);
  FUN_007fb6d0(param_4,param_8,iVar6 + 0x358,uStack_18,0,param_5);
  uStack_8 = 2;
  FUN_0152dda0(uVar3,uVar4,uStack_70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12346 ; VA 0x00805310 ; FUN_00805310 */

void FUN_00805310(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  
  if (param_1 != param_2) {
    do {
      piVar1 = *(int **)(param_1 + 4);
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      param_1 = param_1 + 0xc;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 12347 ; VA 0x00805360 ; FUN_00805360 */

void FUN_00805360(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (param_1 != param_2) {
    piVar3 = param_1 + 6;
    ExceptionList = &pvStack_10;
    do {
      uStack_8 = 0;
      FUN_016f32d1(piVar3 + 1,0x34,3,&LAB_00808320);
      piVar1 = (int *)*piVar3;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      piVar1 = piVar3 + 0x28;
      piVar3 = piVar3 + 0x2e;
    } while (piVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12348 ; VA 0x00805400 ; FUN_00805400 */

int __thiscall FUN_00805400(uint *param_1,uint param_2,undefined4 *param_3)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  
  uVar4 = *param_1;
  iVar3 = (int)(param_1[1] - uVar4) / 0xc;
  if (iVar3 == 0x15555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar7 = iVar3 + 1;
  uVar5 = (int)(param_1[2] - uVar4) / 0xc;
  uVar8 = uVar7;
  if ((uVar5 <= 0x15555555 - (uVar5 >> 1)) && (uVar8 = (uVar5 >> 1) + uVar5, uVar8 < uVar7)) {
    uVar8 = uVar7;
  }
  uVar5 = uVar8 * 0xc;
  if (uVar8 < 0x15555556) {
    uVar8 = uVar5;
    if (0xfff < uVar5) goto LAB_00805497;
    if (uVar5 == 0) {
      uVar8 = 0;
    }
    else {
      uVar8 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_00805497:
    uVar2 = uVar8 + 0x23;
    if (uVar2 <= uVar8) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_008055bb;
    uVar8 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar8 - 4) = iVar3;
  }
  iVar3 = ((int)(param_2 - uVar4) / 0xc) * 0xc;
  *(undefined4 *)(iVar3 + uVar8) = 0;
  *(undefined4 *)(iVar3 + 4 + uVar8) = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar3 + uVar8) = *param_3;
  *(undefined4 *)(iVar3 + 4 + uVar8) = param_3[1];
  *(undefined4 *)(iVar3 + 8 + uVar8) = param_3[2];
  uVar2 = param_1[1];
  uVar4 = *param_1;
  uVar6 = uVar8;
  if (param_2 != uVar2) {
    FUN_00806ab0(uVar4,param_2,uVar8,param_1);
    uVar2 = param_1[1];
    uVar4 = param_2;
    uVar6 = iVar3 + 0xc + uVar8;
  }
  FUN_00806ab0(uVar4,uVar2,uVar6,param_1);
  if (*param_1 != 0) {
    FUN_00805310(*param_1,param_1[1],param_1);
    uVar4 = *param_1;
    uVar6 = ((int)(param_1[2] - uVar4) / 0xc) * 0xc;
    uVar2 = uVar4;
    if (0xfff < uVar6) {
      uVar2 = *(uint *)(uVar4 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar4 - uVar2) - 4) {
LAB_008055bb:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar6);
  }
  *param_1 = uVar8;
  param_1[1] = uVar8 + uVar7 * 0xc;
  param_1[2] = uVar5 + uVar8;
  return *param_1 + iVar3;
}



/* FUNCTION 12349 ; VA 0x008055d0 ; FUN_008055d0 */

int __thiscall FUN_008055d0(uint *param_1,uint param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b4cb0;
  pvStack_10 = ExceptionList;
  uVar8 = *param_1;
  iVar1 = (int)(param_1[1] - *param_1) / 0xb8;
  if (iVar1 == 0x1642c85) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar5 = iVar1 + 1;
  uVar2 = (int)(param_1[2] - *param_1) / 0xb8;
  uVar7 = uVar5;
  if ((uVar2 <= 0x1642c85 - (uVar2 >> 1)) && (uVar7 = (uVar2 >> 1) + uVar2, uVar7 < uVar5)) {
    uVar7 = uVar5;
  }
  uVar5 = uVar7 * 0xb8;
  if (uVar7 < 0x1642c86) {
    uVar7 = uVar5;
    if (0xfff < uVar5) goto LAB_00805690;
    if (uVar5 == 0) {
      uVar7 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar7 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_00805690:
    uVar2 = uVar7 + 0x23;
    if (uVar2 <= uVar7) {
      uVar2 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_008057ee;
    uVar7 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar3;
  }
  iVar4 = ((int)(param_2 - uVar8) / 0xb8) * 0xb8;
  uStack_8 = 0;
  iVar3 = iVar4 + uVar7;
  FUN_00806c10(param_1,iVar3,param_3);
  uVar8 = param_1[1];
  if (param_2 == uVar8) {
    param_2 = *param_1;
    uVar2 = uVar7;
  }
  else {
    FUN_00806b20(*param_1,param_2,uVar7,param_1);
    uVar2 = iVar3 + 0xb8;
    uVar8 = param_1[1];
  }
  FUN_00806b20(param_2,uVar8,uVar2,param_1);
  uStack_8 = 0xffffffff;
  if (*param_1 != 0) {
    FUN_00805360(*param_1,param_1[1],param_1);
    uVar8 = *param_1;
    uVar6 = ((int)(param_1[2] - uVar8) / 0xb8) * 0xb8;
    uVar2 = uVar8;
    if (0xfff < uVar6) {
      uVar2 = *(uint *)(uVar8 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar8 - uVar2) - 4) {
LAB_008057ee:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar6);
  }
  *param_1 = uVar7;
  param_1[1] = (iVar1 + 1) * 0xb8 + uVar7;
  param_1[2] = uVar5 + uVar7;
  ExceptionList = pvStack_10;
  return *param_1 + iVar4;
}



/* FUNCTION 12350 ; VA 0x008057c4 ; Catch_All@008057c4 */

void Catch_All_008057c4(void)

{
  int unaff_EBP;
  
  FUN_00808530(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x2c));
  FUN_00808880(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 12351 ; VA 0x00805800 ; FUN_00805800 */

int __thiscall FUN_00805800(uint *param_1,uint param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  
  uVar7 = *param_1;
  iVar8 = param_2 - uVar7;
  iVar2 = (int)(param_1[1] - uVar7) >> 3;
  if (iVar2 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar5 = (int)(param_1[2] - uVar7) >> 3;
  uVar7 = uVar1;
  if ((uVar5 <= 0x1fffffff - (uVar5 >> 1)) && (uVar7 = (uVar5 >> 1) + uVar5, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  uVar5 = uVar7 * 8;
  if (uVar7 < 0x20000000) {
    uVar7 = uVar5;
    if (0xfff < uVar5) goto LAB_0080586f;
    if (uVar5 == 0) {
      uVar7 = 0;
    }
    else {
      uVar7 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_0080586f:
    uVar3 = uVar7 + 0x23;
    if (uVar3 <= uVar7) {
      uVar3 = 0xffffffff;
    }
    iVar2 = FUN_01674e20(uVar3);
    if (iVar2 == 0) goto LAB_0080598b;
    uVar7 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar2;
  }
  iVar2 = (iVar8 >> 3) * 8;
  *(undefined4 *)(iVar2 + uVar7) = *param_3;
  *(undefined4 *)(iVar2 + 4 + uVar7) = param_3[1];
  uVar3 = param_1[1];
  if (param_2 == uVar3) {
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(uVar7,*param_1,uVar3 - *param_1);
  }
  else {
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(uVar7,*param_1,param_2 - *param_1);
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(iVar2 + 8 + uVar7,param_2,param_1[1] - param_2);
  }
  uVar3 = *param_1;
  if (uVar3 != 0) {
    uVar6 = param_1[2] - uVar3 & 0xfffffff8;
    uVar4 = uVar3;
    if (0xfff < uVar6) {
      uVar4 = *(uint *)(uVar3 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar3 - uVar4) - 4) {
LAB_0080598b:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar6);
  }
  *param_1 = uVar7;
  param_1[1] = uVar7 + uVar1 * 8;
  param_1[2] = uVar5 + uVar7;
  return *param_1 + iVar2;
}



/* FUNCTION 12352 ; VA 0x008059a0 ; FUN_008059a0 */

int __thiscall FUN_008059a0(uint *param_1,uint param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  
  uVar9 = *param_1;
  iVar7 = param_2 - uVar9;
  iVar2 = (int)(param_1[1] - uVar9) / 0xc;
  if (iVar2 == 0x15555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar5 = iVar2 + 1;
  uVar3 = (int)(param_1[2] - uVar9) / 0xc;
  uVar9 = uVar5;
  if ((uVar3 <= 0x15555555 - (uVar3 >> 1)) && (uVar9 = (uVar3 >> 1) + uVar3, uVar9 < uVar5)) {
    uVar9 = uVar5;
  }
  uVar5 = uVar9 * 0xc;
  if (uVar9 < 0x15555556) {
    uVar9 = uVar5;
    if (0xfff < uVar5) goto LAB_00805a38;
    if (uVar5 == 0) {
      uVar9 = 0;
    }
    else {
      uVar9 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar9 = 0xffffffff;
LAB_00805a38:
    uVar3 = uVar9 + 0x23;
    if (uVar3 <= uVar9) {
      uVar3 = 0xffffffff;
    }
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) goto LAB_00805b75;
    uVar9 = iVar4 + 0x23U & 0xffffffe0;
    *(int *)(uVar9 - 4) = iVar4;
  }
  iVar7 = (iVar7 / 0xc) * 0xc;
  puVar1 = (undefined8 *)(iVar7 + uVar9);
  *puVar1 = *param_3;
  *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_3 + 1);
  uVar3 = param_1[1];
  if (param_2 == uVar3) {
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(uVar9,*param_1,uVar3 - *param_1);
  }
  else {
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(uVar9,*param_1,param_2 - *param_1);
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70((int)puVar1 + 0xc,param_2,param_1[1] - param_2);
  }
  uVar3 = *param_1;
  if (uVar3 != 0) {
    uVar6 = ((int)(param_1[2] - uVar3) / 0xc) * 0xc;
    uVar8 = uVar3;
    if (0xfff < uVar6) {
      uVar8 = *(uint *)(uVar3 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar3 - uVar8) - 4) {
LAB_00805b75:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar6);
  }
  *param_1 = uVar9;
  param_1[1] = uVar9 + (iVar2 * 3 + 3) * 4;
  param_1[2] = uVar5 + uVar9;
  return *param_1 + iVar7;
}



/* FUNCTION 12353 ; VA 0x00805b80 ; FUN_00805b80 */

void FUN_00805b80(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  float fVar6;
  
  iVar3 = (int)param_3 - (int)param_1 >> 3;
  if (iVar3 < 0x29) {
    fVar6 = (float)param_2[1];
    if (fVar6 < (float)param_1[1]) {
      uVar1 = *param_2;
      uVar2 = param_2[1];
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      *param_1 = uVar1;
      param_1[1] = uVar2;
      fVar6 = (float)param_2[1];
    }
    if ((float)param_3[1] <= fVar6 && fVar6 != (float)param_3[1]) {
      uVar1 = *param_3;
      uVar2 = param_3[1];
      *param_3 = *param_2;
      param_3[1] = param_2[1];
      param_2[1] = uVar2;
      *param_2 = uVar1;
      if ((float)param_2[1] <= (float)param_1[1] && (float)param_1[1] != (float)param_2[1]) {
        *param_2 = *param_1;
        param_2[1] = param_1[1];
        *param_1 = uVar1;
        param_1[1] = uVar2;
      }
    }
  }
  else {
    iVar3 = iVar3 + 1 >> 3;
    fVar6 = (float)param_1[iVar3 * 2 + 1];
    if (fVar6 < (float)param_1[1]) {
      uVar1 = param_1[iVar3 * 2];
      uVar2 = param_1[iVar3 * 2 + 1];
      param_1[iVar3 * 2] = *param_1;
      param_1[iVar3 * 2 + 1] = param_1[1];
      *param_1 = uVar1;
      param_1[1] = uVar2;
      fVar6 = (float)param_1[iVar3 * 2 + 1];
    }
    if ((float)param_1[iVar3 * 4 + 1] <= fVar6 && fVar6 != (float)param_1[iVar3 * 4 + 1]) {
      uVar1 = param_1[iVar3 * 4];
      uVar2 = param_1[iVar3 * 4 + 1];
      param_1[iVar3 * 4] = param_1[iVar3 * 2];
      param_1[iVar3 * 4 + 1] = param_1[iVar3 * 2 + 1];
      param_1[iVar3 * 2 + 1] = uVar2;
      param_1[iVar3 * 2] = uVar1;
      if ((float)param_1[iVar3 * 2 + 1] <= (float)param_1[1] &&
          (float)param_1[1] != (float)param_1[iVar3 * 2 + 1]) {
        param_1[iVar3 * 2] = *param_1;
        param_1[iVar3 * 2 + 1] = param_1[1];
        *param_1 = uVar1;
        param_1[1] = uVar2;
      }
    }
    puVar4 = param_2 + iVar3 * -2;
    fVar6 = (float)param_2[1];
    if (fVar6 < (float)puVar4[1]) {
      uVar1 = *param_2;
      uVar2 = param_2[1];
      *param_2 = *puVar4;
      param_2[1] = puVar4[1];
      *puVar4 = uVar1;
      puVar4[1] = uVar2;
      fVar6 = (float)param_2[1];
    }
    if ((float)param_2[iVar3 * 2 + 1] <= fVar6 && fVar6 != (float)param_2[iVar3 * 2 + 1]) {
      uVar1 = param_2[iVar3 * 2 + 1];
      uVar2 = param_2[iVar3 * 2];
      param_2[iVar3 * 2] = *param_2;
      param_2[iVar3 * 2 + 1] = param_2[1];
      param_2[1] = uVar1;
      *param_2 = uVar2;
      if ((float)param_2[1] <= (float)puVar4[1] && (float)puVar4[1] != (float)param_2[1]) {
        *param_2 = *puVar4;
        param_2[1] = puVar4[1];
        *puVar4 = uVar2;
        puVar4[1] = uVar1;
      }
    }
    puVar5 = param_3 + iVar3 * -2;
    puVar4 = param_3 + iVar3 * -4;
    fVar6 = (float)puVar5[1];
    if (fVar6 < (float)puVar4[1]) {
      uVar1 = *puVar5;
      uVar2 = puVar5[1];
      *puVar5 = *puVar4;
      puVar5[1] = puVar4[1];
      puVar4[1] = uVar2;
      *puVar4 = uVar1;
      fVar6 = (float)puVar5[1];
    }
    if ((float)param_3[1] <= fVar6 && fVar6 != (float)param_3[1]) {
      uVar1 = *param_3;
      uVar2 = param_3[1];
      *param_3 = *puVar5;
      param_3[1] = puVar5[1];
      *puVar5 = uVar1;
      puVar5[1] = uVar2;
      if ((float)puVar5[1] <= (float)puVar4[1] && (float)puVar4[1] != (float)puVar5[1]) {
        *puVar5 = *puVar4;
        puVar5[1] = puVar4[1];
        *puVar4 = uVar1;
        puVar4[1] = uVar2;
      }
    }
    fVar6 = (float)param_2[1];
    if (fVar6 < (float)param_1[iVar3 * 2 + 1]) {
      uVar1 = *param_2;
      uVar2 = param_2[1];
      *param_2 = param_1[iVar3 * 2];
      param_2[1] = param_1[iVar3 * 2 + 1];
      param_1[iVar3 * 2] = uVar1;
      param_1[iVar3 * 2 + 1] = uVar2;
      fVar6 = (float)param_2[1];
    }
    if ((float)puVar5[1] <= fVar6 && fVar6 != (float)puVar5[1]) {
      uVar1 = puVar5[1];
      uVar2 = *puVar5;
      *puVar5 = *param_2;
      puVar5[1] = param_2[1];
      param_2[1] = uVar1;
      *param_2 = uVar2;
      if ((float)param_2[1] <= (float)param_1[iVar3 * 2 + 1] &&
          (float)param_1[iVar3 * 2 + 1] != (float)param_2[1]) {
        *param_2 = param_1[iVar3 * 2];
        param_2[1] = param_1[iVar3 * 2 + 1];
        param_1[iVar3 * 2] = uVar2;
        param_1[iVar3 * 2 + 1] = uVar1;
        return;
      }
    }
  }
  return;
}



/* FUNCTION 12354 ; VA 0x00805e10 ; FUN_00805e10 */

void FUN_00805e10(undefined8 *param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 uVar1;
  undefined4 uVar2;
  byte bVar3;
  
  bVar3 = *(byte *)(param_2 + 1);
  if (*(byte *)(param_1 + 1) < bVar3) {
    uVar1 = *param_2;
    uVar2 = *(undefined4 *)(param_2 + 1);
    *param_2 = *param_1;
    *(undefined4 *)(param_2 + 1) = *(undefined4 *)(param_1 + 1);
    *param_1 = uVar1;
    *(undefined4 *)(param_1 + 1) = uVar2;
    bVar3 = *(byte *)(param_2 + 1);
  }
  if (bVar3 < *(byte *)(param_3 + 1)) {
    uVar1 = *param_3;
    uVar2 = *(undefined4 *)(param_3 + 1);
    *param_3 = *param_2;
    *(undefined4 *)(param_3 + 1) = *(undefined4 *)(param_2 + 1);
    *param_2 = uVar1;
    *(undefined4 *)(param_2 + 1) = uVar2;
    if (*(byte *)(param_1 + 1) < *(byte *)(param_2 + 1)) {
      *param_2 = *param_1;
      *(undefined4 *)(param_2 + 1) = *(undefined4 *)(param_1 + 1);
      *param_1 = uVar1;
      *(undefined4 *)(param_1 + 1) = uVar2;
    }
  }
  return;
}



/* FUNCTION 12355 ; VA 0x00805e90 ; FUN_00805e90 */

void FUN_00805e90(undefined4 *param_1,undefined8 *param_2,undefined8 *param_3,undefined4 param_4)

{
  int iVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  int iVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  int iVar10;
  undefined8 *puVar11;
  undefined8 *puVar12;
  undefined8 *puStack_c;
  undefined8 *puStack_8;
  
  iVar1 = (int)param_3 + -0xc;
  puStack_8 = (undefined8 *)((int)param_2 + (((int)param_3 - (int)param_2) / 0xc >> 1) * 0xc);
  iVar4 = (iVar1 - (int)param_2) / 0xc;
  if (iVar4 < 0x29) {
    FUN_00805e10(param_2,puStack_8,(int)param_3 + -0xc,param_4);
  }
  else {
    iVar4 = iVar4 + 1 >> 3;
    iVar10 = iVar4 * 0xc;
    FUN_00805e10(param_2,iVar10 + (int)param_2,param_2 + iVar4 * 3,param_4);
    FUN_00805e10((int)puStack_8 + iVar4 * -0xc,puStack_8,iVar10 + (int)puStack_8,param_4);
    iVar7 = iVar1 + iVar4 * -0xc;
    FUN_00805e10(iVar1 + iVar4 * -0x18,iVar7,iVar1,param_4);
    FUN_00805e10(iVar10 + (int)param_2,puStack_8,iVar7,param_4);
  }
  puVar11 = (undefined8 *)((int)puStack_8 + 0xc);
  for (; param_2 < puStack_8; puStack_8 = (undefined8 *)((int)puStack_8 + -0xc)) {
    if ((*(byte *)(puStack_8 + 1) < *(byte *)((int)puStack_8 + -4)) ||
       (*(byte *)((int)puStack_8 + -4) < *(byte *)(puStack_8 + 1))) break;
  }
  puVar12 = puVar11;
  puStack_c = puVar11;
  puVar8 = puStack_8;
  if (puVar11 < param_3) {
    do {
      puVar12 = puVar11;
      puStack_c = puVar11;
      if ((*(byte *)(puStack_8 + 1) < *(byte *)(puVar11 + 1)) ||
         (*(byte *)(puVar11 + 1) < *(byte *)(puStack_8 + 1))) break;
      puVar11 = (undefined8 *)((int)puVar11 + 0xc);
      puVar12 = puVar11;
      puStack_c = puVar11;
    } while (puVar11 < param_3);
  }
joined_r0x00805fa2:
  do {
    puVar5 = puStack_8;
    if (param_3 <= puVar11) {
joined_r0x00805fe7:
      for (; param_2 < puStack_8; puStack_8 = (undefined8 *)((int)puStack_8 + -0xc)) {
        puVar6 = (undefined8 *)((int)puVar5 + -0xc);
        puVar9 = puVar8;
        puVar11 = puStack_c;
        if (*(byte *)((int)puVar5 + -4) <= *(byte *)(puVar8 + 1)) {
          if (*(byte *)((int)puVar5 + -4) < *(byte *)(puVar8 + 1)) break;
          puVar9 = (undefined8 *)((int)puVar8 + -0xc);
          if (puVar9 != puVar6) {
            uVar2 = *puVar9;
            uVar3 = *(undefined4 *)((int)puVar8 + -4);
            *puVar9 = *puVar6;
            *(undefined4 *)((int)puVar8 + -4) = *(undefined4 *)((int)puVar5 + -4);
            *puVar6 = uVar2;
            *(undefined4 *)((int)puVar5 + -4) = uVar3;
          }
        }
        puVar8 = puVar9;
        puVar5 = puVar6;
      }
      if (puStack_8 == param_2) {
        if (puVar11 == param_3) {
          param_1[1] = puVar12;
          *param_1 = puVar8;
          return;
        }
        if (puVar12 != puVar11) {
          uVar2 = *puVar8;
          uVar3 = *(undefined4 *)(puVar8 + 1);
          *puVar8 = *puVar12;
          *(undefined4 *)(puVar8 + 1) = *(undefined4 *)(puVar12 + 1);
          *puVar12 = uVar2;
          *(undefined4 *)(puVar12 + 1) = uVar3;
        }
        uVar2 = *puVar8;
        uVar3 = *(undefined4 *)(puVar8 + 1);
        *puVar8 = *puVar11;
        *(undefined4 *)(puVar8 + 1) = *(undefined4 *)(puVar11 + 1);
        *puVar11 = uVar2;
        *(undefined4 *)(puVar11 + 1) = uVar3;
        puVar11 = (undefined8 *)((int)puVar11 + 0xc);
        puVar12 = (undefined8 *)((int)puVar12 + 0xc);
        puStack_c = puVar11;
        puVar8 = (undefined8 *)((int)puVar8 + 0xc);
      }
      else {
        puVar5 = (undefined8 *)((int)puStack_8 + -0xc);
        if (puVar11 == param_3) {
          puVar9 = (undefined8 *)((int)puVar8 + -0xc);
          if (puVar5 != puVar9) {
            uVar2 = *puVar5;
            uVar3 = *(undefined4 *)((int)puStack_8 + -4);
            *puVar5 = *puVar9;
            *(undefined4 *)((int)puStack_8 + -4) = *(undefined4 *)((int)puVar8 + -4);
            *puVar9 = uVar2;
            *(undefined4 *)((int)puVar8 + -4) = uVar3;
          }
          uVar2 = *puVar9;
          uVar3 = *(undefined4 *)((int)puVar8 + -4);
          *puVar9 = *(undefined8 *)((int)puVar12 - 0xc);
          *(undefined4 *)((int)puVar8 + -4) = *(undefined4 *)((int)puVar12 - 4);
          *(undefined8 *)((int)puVar12 - 0xcU) = uVar2;
          *(undefined4 *)((int)puVar12 - 4) = uVar3;
          puVar12 = (undefined8 *)((int)puVar12 - 0xcU);
          puStack_8 = puVar5;
          puVar8 = puVar9;
        }
        else {
          uVar2 = *puVar11;
          uVar3 = *(undefined4 *)(puVar11 + 1);
          *puVar11 = *puVar5;
          *(undefined4 *)(puVar11 + 1) = *(undefined4 *)((int)puStack_8 + -4);
          puVar11 = (undefined8 *)((int)puVar11 + 0xc);
          *puVar5 = uVar2;
          *(undefined4 *)((int)puStack_8 + -4) = uVar3;
          puStack_c = puVar11;
          puStack_8 = puVar5;
        }
      }
      goto joined_r0x00805fa2;
    }
    if (*(byte *)(puVar8 + 1) <= *(byte *)(puVar11 + 1)) {
      puStack_c = puVar11;
      if (*(byte *)(puVar8 + 1) < *(byte *)(puVar11 + 1)) goto joined_r0x00805fe7;
      if (puVar12 != puVar11) {
        uVar2 = *puVar12;
        uVar3 = *(undefined4 *)(puVar12 + 1);
        *puVar12 = *puVar11;
        *(undefined4 *)(puVar12 + 1) = *(undefined4 *)(puVar11 + 1);
        *puVar11 = uVar2;
        *(undefined4 *)(puVar11 + 1) = uVar3;
      }
      puVar12 = (undefined8 *)((int)puVar12 + 0xc);
    }
    puVar11 = (undefined8 *)((int)puVar11 + 0xc);
    puStack_c = puVar11;
  } while( true );
}



/* FUNCTION 12356 ; VA 0x00806130 ; FUN_00806130 */

void FUN_00806130(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puStack_c;
  undefined4 *puStack_8;
  
  puStack_8 = param_2 + ((int)param_3 - (int)param_2 >> 4) * 2;
  FUN_00805b80(param_2,puStack_8,param_3 + -2,param_4);
  puVar4 = puStack_8 + 2;
  for (; param_2 < puStack_8; puStack_8 = puStack_8 + -2) {
    if (((float)puStack_8[-1] < (float)puStack_8[1]) || ((float)puStack_8[1] < (float)puStack_8[-1])
       ) break;
  }
  puVar6 = puVar4;
  puStack_c = puVar4;
  puVar5 = puStack_8;
  if (puVar4 < param_3) {
    do {
      puVar6 = puVar4;
      puStack_c = puVar4;
      if (((float)puVar4[1] < (float)puStack_8[1]) || ((float)puStack_8[1] < (float)puVar4[1]))
      break;
      puVar4 = puVar4 + 2;
      puVar6 = puVar4;
      puStack_c = puVar4;
    } while (puVar4 < param_3);
  }
joined_r0x008061c2:
  do {
    puVar3 = puStack_8;
    if (param_3 <= puVar6) {
joined_r0x00806214:
      for (; puVar8 = puVar6, param_2 < puStack_8; puStack_8 = puStack_8 + -2) {
        puVar7 = puVar3 + -2;
        puVar6 = puVar5;
        if ((float)puVar5[1] <= (float)puVar3[-1]) {
          puVar8 = puStack_c;
          if ((float)puVar5[1] < (float)puVar3[-1]) break;
          puVar6 = puVar5 + -2;
          if (puVar6 != puVar7) {
            uVar1 = *puVar6;
            uVar2 = puVar5[-1];
            *puVar6 = *puVar7;
            puVar5[-1] = puVar3[-1];
            puVar3[-1] = uVar2;
            *puVar7 = uVar1;
          }
        }
        puVar5 = puVar6;
        puVar6 = puStack_c;
        puVar3 = puVar7;
      }
      if (puStack_8 == param_2) {
        if (puVar8 == param_3) {
          *param_1 = puVar5;
          param_1[1] = puVar4;
          return;
        }
        if (puVar4 != puVar8) {
          uVar1 = *puVar5;
          uVar2 = puVar5[1];
          *puVar5 = *puVar4;
          puVar5[1] = puVar4[1];
          *puVar4 = uVar1;
          puVar4[1] = uVar2;
        }
        uVar1 = *puVar5;
        puVar4 = puVar4 + 2;
        uVar2 = puVar5[1];
        *puVar5 = *puVar8;
        puVar5[1] = puVar8[1];
        *puVar8 = uVar1;
        puVar8[1] = uVar2;
        puVar6 = puVar8 + 2;
        puStack_c = puVar8 + 2;
        puVar5 = puVar5 + 2;
      }
      else {
        puVar3 = puStack_8 + -2;
        if (puVar8 == param_3) {
          puVar7 = puVar5 + -2;
          if (puVar3 != puVar7) {
            uVar1 = *puVar3;
            uVar2 = puStack_8[-1];
            *puVar3 = *puVar7;
            puStack_8[-1] = puVar5[-1];
            *puVar7 = uVar1;
            puVar5[-1] = uVar2;
            puVar8 = puStack_c;
          }
          uVar1 = *puVar7;
          puVar6 = puVar4 + -2;
          uVar2 = puVar5[-1];
          *puVar7 = *puVar6;
          puVar5[-1] = puVar4[-1];
          *puVar6 = uVar1;
          puVar4[-1] = uVar2;
          puVar4 = puVar6;
          puVar6 = puVar8;
          puStack_8 = puVar3;
          puVar5 = puVar7;
        }
        else {
          uVar1 = *puVar8;
          uVar2 = puVar8[1];
          *puVar8 = *puVar3;
          puVar8[1] = puStack_8[-1];
          *puVar3 = uVar1;
          puStack_8[-1] = uVar2;
          puVar6 = puVar8 + 2;
          puStack_c = puVar8 + 2;
          puStack_8 = puVar3;
        }
      }
      goto joined_r0x008061c2;
    }
    if ((float)puVar6[1] <= (float)puVar5[1]) {
      puStack_c = puVar6;
      if ((float)puVar6[1] < (float)puVar5[1]) goto joined_r0x00806214;
      if (puVar4 != puVar6) {
        uVar1 = *puVar4;
        uVar2 = puVar4[1];
        *puVar4 = *puVar6;
        puVar4[1] = puVar6[1];
        *puVar6 = uVar1;
        puVar6[1] = uVar2;
      }
      puVar4 = puVar4 + 2;
    }
    puVar6 = puVar6 + 2;
    puStack_c = puVar6;
  } while( true );
}



/* FUNCTION 12357 ; VA 0x00806350 ; FUN_00806350 */

void FUN_00806350(int param_1,int param_2,uint param_3,undefined8 *param_4)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  iVar3 = (int)(param_3 - 1) >> 1;
  iVar4 = param_2;
  iVar5 = param_2;
  if (param_2 < iVar3) {
    do {
      iVar5 = param_1 + iVar4 * 0x18;
      iVar5 = (iVar4 * 2 + 2) - (uint)(*(byte *)(iVar5 + 0x14) < *(byte *)(iVar5 + 0x20));
      puVar1 = (undefined8 *)(param_1 + iVar4 * 0xc);
      *puVar1 = *(undefined8 *)(param_1 + iVar5 * 0xc);
      *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_1 + iVar5 * 0xc + 8);
      iVar4 = iVar5;
    } while (iVar5 < iVar3);
  }
  if ((iVar5 == iVar3) && ((param_3 & 1) == 0)) {
    puVar1 = (undefined8 *)(param_1 + iVar5 * 0xc);
    *puVar1 = *(undefined8 *)(param_1 + -0xc + param_3 * 0xc);
    *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_1 + param_3 * 0xc + -4);
    iVar5 = param_3 - 1;
  }
  while (param_2 < iVar5) {
    iVar4 = iVar5 + -1 >> 1;
    puVar1 = (undefined8 *)(param_1 + iVar4 * 0xc);
    if (*(byte *)(puVar1 + 1) <= *(byte *)(param_4 + 1)) break;
    puVar2 = (undefined8 *)(param_1 + iVar5 * 0xc);
    *puVar2 = *puVar1;
    *(undefined4 *)(puVar2 + 1) = *(undefined4 *)(puVar1 + 1);
    iVar5 = iVar4;
  }
  puVar1 = (undefined8 *)(param_1 + iVar5 * 0xc);
  *puVar1 = *param_4;
  *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_4 + 1);
  return;
}



/* FUNCTION 12358 ; VA 0x00806430 ; FUN_00806430 */

void FUN_00806430(int param_1,int param_2,uint param_3,undefined4 *param_4)

{
  float *pfVar1;
  float fVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  iVar5 = (int)(param_3 - 1) >> 1;
  iVar4 = param_2;
  iVar3 = param_2;
  if (param_2 < iVar5) {
    do {
      fVar2 = *(float *)(param_1 + 0xc + iVar4 * 0x10);
      pfVar1 = (float *)(param_1 + 0x14 + iVar4 * 0x10);
      iVar3 = iVar4 * 2 + ((*pfVar1 <= fVar2 && fVar2 != *pfVar1) ^ 1) + 1;
      *(undefined4 *)(param_1 + iVar4 * 8) = *(undefined4 *)(param_1 + iVar3 * 8);
      *(undefined4 *)(param_1 + 4 + iVar4 * 8) = *(undefined4 *)(param_1 + 4 + iVar3 * 8);
      iVar4 = iVar3;
    } while (iVar3 < iVar5);
  }
  if ((iVar3 == iVar5) && ((param_3 & 1) == 0)) {
    *(undefined4 *)(param_1 + iVar3 * 8) = *(undefined4 *)(param_1 + -8 + param_3 * 8);
    *(undefined4 *)(param_1 + 4 + iVar3 * 8) = *(undefined4 *)(param_1 + -4 + param_3 * 8);
    iVar3 = param_3 - 1;
  }
  while ((param_2 < iVar3 &&
         (iVar4 = iVar3 + -1 >> 1, pfVar1 = (float *)(param_1 + 4 + iVar4 * 8),
         *pfVar1 <= (float)param_4[1] && (float)param_4[1] != *pfVar1))) {
    *(undefined4 *)(param_1 + iVar3 * 8) = *(undefined4 *)(param_1 + iVar4 * 8);
    *(undefined4 *)(param_1 + 4 + iVar3 * 8) = *(undefined4 *)(param_1 + 4 + iVar4 * 8);
    iVar3 = iVar4;
  }
  *(undefined4 *)(param_1 + iVar3 * 8) = *param_4;
  *(undefined4 *)(param_1 + 4 + iVar3 * 8) = param_4[1];
  return;
}



/* FUNCTION 12359 ; VA 0x008064e0 ; FUN_008064e0 */

void FUN_008064e0(undefined8 *param_1,undefined8 *param_2,int param_3,undefined4 param_4)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  byte bVar3;
  undefined4 uVar4;
  int iVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  int iVar11;
  undefined8 *puVar12;
  undefined8 *puVar13;
  byte bStack_28;
  undefined8 uStack_24;
  undefined8 *puStack_1c;
  undefined8 uStack_18;
  int iStack_10;
  int iStack_c;
  int iStack_8;
  
  iVar9 = (int)param_2 - (int)param_1;
  puVar12 = param_1;
  do {
    iVar9 = iVar9 / 0xc;
    if (iVar9 < 0x21) {
LAB_008065a8:
      if (((1 < iVar9) && (puVar12 != param_2)) &&
         (puVar13 = (undefined8 *)((int)puVar12 + 0xc), puVar13 != param_2)) {
        param_1 = (undefined8 *)0xc;
        do {
          iStack_c = *(int *)(puVar13 + 1);
          uStack_18 = *puVar13;
          puStack_1c = (undefined8 *)((int)puVar12 + (int)param_1 + 0xc);
          bStack_28 = (byte)iStack_c;
          if (*(byte *)(puVar12 + 1) < bStack_28) {
            FUN_0170cc70((int)puVar12 + 0xc,puVar12,param_1);
            *puVar12 = uStack_18;
            *(int *)(puVar12 + 1) = iStack_c;
          }
          else {
            bVar3 = *(byte *)((int)puStack_1c + -0x10);
            puVar7 = (undefined8 *)((int)param_1 + -0xc + (int)puVar12);
            puVar1 = puVar13;
            while (puVar6 = puVar7, bVar3 < bStack_28) {
              *puVar1 = *puVar6;
              *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(puVar6 + 1);
              puVar7 = (undefined8 *)((int)puVar6 + -0xc);
              puVar1 = puVar6;
              bVar3 = *(byte *)((int)puVar6 + -4);
            }
            *puVar1 = uStack_18;
            *(int *)(puVar1 + 1) = iStack_c;
          }
          puVar13 = (undefined8 *)((int)puVar13 + 0xc);
          param_1 = (undefined8 *)((int)param_1 + 0xc);
        } while (puVar13 != param_2);
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < iVar9) {
        uVar10 = ((int)param_2 - (int)puVar12) / 0xc;
        iVar9 = (int)uVar10 >> 1;
        if (0 < iVar9) {
          iStack_10 = uVar10 - 1;
          iStack_c = iStack_10 >> 1;
          iVar8 = (int)puVar12 + iVar9 * 0xc;
          do {
            uVar2 = *(undefined8 *)(iVar8 + -0xc);
            iVar9 = iVar9 + -1;
            uVar4 = *(undefined4 *)(iVar8 + -4);
            uStack_18 = CONCAT44(uVar4,(undefined4)uStack_18);
            iVar5 = iVar9;
            while (iVar5 < iStack_c) {
              iVar11 = (iVar5 * 2 + 2) -
                       (uint)(*(byte *)((int)puVar12 + iVar5 * 0x18 + 0x14) <
                             *(byte *)(puVar12 + iVar5 * 3 + 4));
              puVar13 = (undefined8 *)((int)puVar12 + iVar5 * 0xc);
              *puVar13 = *(undefined8 *)((int)puVar12 + iVar11 * 0xc);
              *(undefined4 *)(puVar13 + 1) = *(undefined4 *)((int)puVar12 + iVar11 * 0xc + 8);
              iVar5 = iVar11;
            }
            if ((iVar5 == iStack_c) && ((uVar10 & 1) == 0)) {
              puVar13 = (undefined8 *)((int)puVar12 + iVar5 * 0xc);
              *puVar13 = *(undefined8 *)((int)puVar12 + uVar10 * 0xc + -0xc);
              *(undefined4 *)(puVar13 + 1) = *(undefined4 *)((int)puVar12 + uVar10 * 0xc + -4);
              iVar5 = iStack_10;
            }
            while (iVar9 < iVar5) {
              iVar11 = iVar5 + -1 >> 1;
              puVar13 = (undefined8 *)((int)puVar12 + iVar11 * 0xc);
              bStack_28 = (byte)uVar4;
              if (*(byte *)(puVar13 + 1) <= bStack_28) break;
              puVar1 = (undefined8 *)((int)puVar12 + iVar5 * 0xc);
              *puVar1 = *puVar13;
              *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(puVar13 + 1);
              iVar5 = iVar11;
            }
            *(undefined8 *)((int)puVar12 + iVar5 * 0xc) = uVar2;
            *(undefined4 *)((int)puVar12 + iVar5 * 0xc + 8) = uVar4;
            iVar8 = iVar8 + -0xc;
            iStack_8 = iVar9;
          } while (0 < iVar9);
        }
        if ((int)uVar10 < 2) {
          return;
        }
        param_2 = (undefined8 *)((int)param_2 + -0xc);
        do {
          if (1 < (int)uVar10) {
            uStack_24 = *param_2;
            puStack_1c = *(undefined8 **)(param_2 + 1);
            *param_2 = *puVar12;
            *(undefined4 *)(param_2 + 1) = *(undefined4 *)(puVar12 + 1);
            FUN_00806350(puVar12,0,((int)param_2 - (int)puVar12) / 0xc,&uStack_24,param_4);
          }
          param_2 = (undefined8 *)((int)param_2 + -0xc);
          uVar10 = ((int)param_2 + (0xc - (int)puVar12)) / 0xc;
        } while (1 < (int)uVar10);
        return;
      }
      goto LAB_008065a8;
    }
    FUN_00805e90((int)&uStack_24 + 4,puVar12,param_2,param_4);
    param_3 = (param_3 >> 1) + (param_3 >> 2);
    if (((int)uStack_24._4_4_ - (int)puVar12) / 0xc < ((int)param_2 - (int)puStack_1c) / 0xc) {
      FUN_008064e0(puVar12,uStack_24._4_4_,param_3,param_4);
      puVar12 = puStack_1c;
    }
    else {
      FUN_008064e0(puStack_1c,param_2,param_3,param_4);
      param_2 = uStack_24._4_4_;
    }
    iVar9 = (int)param_2 - (int)puVar12;
  } while( true );
}



/* FUNCTION 12360 ; VA 0x00806820 ; FUN_00806820 */

void FUN_00806820(undefined4 *param_1,undefined4 *param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  float fVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int iVar7;
  int iVar8;
  undefined4 *puVar9;
  int iVar10;
  uint uVar11;
  undefined4 *puVar12;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  float fStack_10;
  undefined4 uStack_c;
  float fStack_8;
  
  iVar7 = (int)param_2 - (int)param_1;
  puVar9 = param_2;
  do {
    iVar7 = iVar7 >> 3;
    if (iVar7 < 0x21) {
LAB_008068aa:
      if (((1 < iVar7) && (param_1 != puVar9)) && (puVar12 = param_1 + 2, puVar12 != puVar9)) {
        param_2 = (undefined4 *)0x8;
        do {
          uVar3 = *puVar12;
          fStack_8 = (float)puVar12[1];
          if ((float)param_1[1] <= fStack_8) {
            fVar2 = *(float *)((int)param_1 + (int)param_2 + -4);
            puVar6 = (undefined4 *)((int)param_2 + -8 + (int)param_1);
            puVar5 = puVar12;
            while (puVar4 = puVar6, fStack_8 < fVar2) {
              *puVar5 = *puVar4;
              puVar5[1] = puVar4[1];
              puVar6 = puVar4 + -2;
              puVar5 = puVar4;
              fVar2 = (float)puVar4[-1];
            }
            *puVar5 = uVar3;
            puVar5[1] = fStack_8;
          }
          else {
            FUN_0170cc70(param_1 + 2,param_1,param_2);
            *param_1 = uVar3;
            param_1[1] = fStack_8;
          }
          puVar12 = puVar12 + 2;
          param_2 = (undefined4 *)((int)param_2 + 8);
        } while (puVar12 != puVar9);
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < iVar7) {
        uVar11 = (int)puVar9 - (int)param_1 >> 3;
        iVar7 = (int)puVar9 - (int)param_1 >> 4;
        if (0 < iVar7) {
          iVar8 = (int)(uVar11 - 1) >> 1;
          puVar9 = param_1 + iVar7 * 2;
          do {
            uStack_c = puVar9[-2];
            iVar7 = iVar7 + -1;
            fStack_10 = (float)puVar9[-1];
            iVar1 = iVar7;
            while (iVar1 < iVar8) {
              iVar10 = iVar1 * 2 +
                       (((float)param_1[iVar1 * 4 + 5] <= (float)param_1[iVar1 * 4 + 3] &&
                        (float)param_1[iVar1 * 4 + 3] != (float)param_1[iVar1 * 4 + 5]) ^ 1) + 1;
              param_1[iVar1 * 2] = param_1[iVar10 * 2];
              param_1[iVar1 * 2 + 1] = param_1[iVar10 * 2 + 1];
              iVar1 = iVar10;
            }
            if ((iVar1 == iVar8) && ((uVar11 & 1) == 0)) {
              param_1[iVar1 * 2] = param_1[uVar11 * 2 + -2];
              param_1[iVar1 * 2 + 1] = param_1[uVar11 * 2 + -1];
              iVar1 = uVar11 - 1;
            }
            while ((iVar7 < iVar1 &&
                   (iVar10 = iVar1 + -1 >> 1,
                   (float)param_1[iVar10 * 2 + 1] <= fStack_10 &&
                   fStack_10 != (float)param_1[iVar10 * 2 + 1]))) {
              param_1[iVar1 * 2] = param_1[iVar10 * 2];
              param_1[iVar1 * 2 + 1] = param_1[iVar10 * 2 + 1];
              iVar1 = iVar10;
            }
            param_1[iVar1 * 2] = uStack_c;
            param_1[iVar1 * 2 + 1] = fStack_10;
            puVar9 = puVar9 + -2;
          } while (0 < iVar7);
        }
        if ((int)uVar11 < 2) {
          return;
        }
        param_2 = param_2 + -2;
        fStack_8 = (float)uVar11;
        do {
          if (1 < (int)uVar11) {
            puStack_18 = (undefined4 *)*param_2;
            puStack_14 = (undefined4 *)param_2[1];
            *param_2 = *param_1;
            param_2[1] = param_1[1];
            FUN_00806430(param_1,0,(int)param_2 - (int)param_1 >> 3,&puStack_18,param_4);
          }
          param_2 = param_2 + -2;
          uVar11 = (int)param_2 + (8 - (int)param_1) >> 3;
        } while (1 < (int)uVar11);
        return;
      }
      goto LAB_008068aa;
    }
    FUN_00806130(&puStack_18,param_1,puVar9,param_4);
    param_3 = (param_3 >> 1) + (param_3 >> 2);
    if ((int)((int)puStack_18 - (int)param_1 & 0xfffffff8U) <
        (int)((int)puVar9 - (int)puStack_14 & 0xfffffff8U)) {
      FUN_00806820(param_1,puStack_18,param_3,param_4);
      param_1 = puStack_14;
    }
    else {
      FUN_00806820(puStack_14,puVar9,param_3,param_4);
      param_2 = puStack_18;
      puVar9 = puStack_18;
    }
    iVar7 = (int)puVar9 - (int)param_1;
  } while( true );
}



/* FUNCTION 12361 ; VA 0x00806ab0 ; FUN_00806ab0 */

undefined4 *
FUN_00806ab0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar4 = param_3;
  if (param_1 != param_2) {
    puVar3 = param_1 + 1;
    do {
      *puVar4 = 0;
      puVar1 = puVar3 + 3;
      *(undefined4 *)((int)param_3 + (-0xc - (int)param_1) + (int)puVar1) = 0;
      *puVar4 = puVar3[-1];
      *(undefined4 *)((int)param_3 + (-0xc - (int)param_1) + (int)puVar1) = *puVar3;
      puVar3[-1] = 0;
      *puVar3 = 0;
      puVar4[2] = puVar3[1];
      puVar2 = puVar3 + 2;
      puVar4 = puVar4 + 3;
      puVar3 = puVar1;
    } while (puVar2 != param_2);
  }
  FUN_00805310(puVar4,puVar4,param_4);
  return puVar4;
}



/* FUNCTION 12362 ; VA 0x00806b20 ; FUN_00806b20 */

undefined4 *
FUN_00806b20(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    puVar4 = param_3 + 3;
    iVar2 = (int)param_3 - (int)param_1;
    puVar3 = param_1 + 6;
    ExceptionList = &pvStack_10;
    do {
      *param_3 = puVar3[-6];
      puVar4[-2] = puVar3[-5];
      puVar4[-1] = puVar3[-4];
      *puVar4 = puVar3[-3];
      puVar4[1] = puVar3[-2];
      puVar4[2] = 0;
      *(undefined4 *)(iVar2 + (int)puVar3) = 0;
      puVar4[2] = puVar3[-1];
      *(undefined4 *)(iVar2 + (int)puVar3) = *puVar3;
      uStack_8 = 0;
      puVar3[-1] = 0;
      *puVar3 = 0;
      FUN_016f40fd(puVar4 + 4,puVar3 + 1,0x34,3,FUN_00807990,&LAB_00808320);
      puVar1 = puVar3 + 0x28;
      param_3 = param_3 + 0x2e;
      puVar4 = puVar4 + 0x2e;
      puVar3 = puVar3 + 0x2e;
    } while (puVar1 != param_2);
  }
  uStack_8 = 1;
  FUN_00805360(param_3,param_3,param_4);
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 12363 ; VA 0x00806c10 ; FUN_00806c10 */

void FUN_00806c10(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_2 = *param_3;
  param_2[1] = param_3[1];
  param_2[2] = param_3[2];
  param_2[3] = param_3[3];
  param_2[4] = param_3[4];
  param_2[5] = 0;
  param_2[6] = 0;
  if (param_3[6] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[6] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_2[5] = param_3[5];
  param_2[6] = param_3[6];
  FUN_016f40fd(param_2 + 7,param_3 + 7,0x34,3,FUN_00807a00,&LAB_00808320);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12364 ; VA 0x00806ca0 ; FUN_00806ca0 */

void FUN_00806ca0(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined2 uVar1;
  undefined2 *puVar2;
  undefined2 *puVar3;
  uint uVar4;
  uint uVar5;
  
  puVar2 = (undefined2 *)(**(code **)(*param_1 + 0x10))();
  uVar4 = 0;
  puVar3 = (undefined2 *)*param_2;
  uVar5 = (uint)((int)param_2[1] + (3 - (int)puVar3)) >> 2;
  if ((undefined2 *)param_2[1] < puVar3) {
    uVar5 = 0;
  }
  if (uVar5 != 0) {
    do {
      uVar1 = *puVar3;
      puVar3 = puVar3 + 2;
      *puVar2 = uVar1;
      uVar4 = uVar4 + 1;
      puVar2 = puVar2 + 1;
    } while (uVar4 != uVar5);
  }
  uVar4 = 0;
  puVar3 = (undefined2 *)*param_3;
  uVar5 = (uint)((int)param_3[1] + (3 - (int)puVar3)) >> 2;
  if ((undefined2 *)param_3[1] < puVar3) {
    uVar5 = 0;
  }
  if (uVar5 != 0) {
    do {
      uVar4 = uVar4 + 1;
      *puVar2 = *puVar3;
      puVar3 = puVar3 + 2;
      puVar2 = puVar2 + 1;
    } while (uVar4 != uVar5);
  }
                    /* WARNING: Could not recover jumptable at 0x00806d1a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x14))();
  return;
}



/* FUNCTION 12365 ; VA 0x00806d20 ; FUN_00806d20 */

void FUN_00806d20(int *param_1,uint *param_2,uint *param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint uVar5;
  
  puVar2 = (undefined4 *)(**(code **)(*param_1 + 0x10))();
  uVar4 = 0;
  puVar3 = (undefined4 *)*param_2;
  uVar5 = (uint)((int)param_2[1] + (3 - (int)puVar3)) >> 2;
  if ((undefined4 *)param_2[1] < puVar3) {
    uVar5 = 0;
  }
  if (uVar5 != 0) {
    do {
      uVar1 = *puVar3;
      puVar3 = puVar3 + 1;
      *puVar2 = uVar1;
      uVar4 = uVar4 + 1;
      puVar2 = puVar2 + 1;
    } while (uVar4 != uVar5);
  }
  uVar4 = 0;
  puVar3 = (undefined4 *)*param_3;
  uVar5 = (uint)((int)param_3[1] + (3 - (int)puVar3)) >> 2;
  if ((undefined4 *)param_3[1] < puVar3) {
    uVar5 = 0;
  }
  if (uVar5 != 0) {
    do {
      uVar4 = uVar4 + 1;
      *puVar2 = *puVar3;
      puVar3 = puVar3 + 1;
      puVar2 = puVar2 + 1;
    } while (uVar4 != uVar5);
  }
                    /* WARNING: Could not recover jumptable at 0x00806d98. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x14))();
  return;
}



/* FUNCTION 12366 ; VA 0x00806da0 ; FUN_00806da0 */

uint * __thiscall FUN_00806da0(uint *param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined auStack_10 [4];
  uint *puStack_c;
  undefined uStack_5;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar3 = (param_2[1] - *param_2) / 0xc;
  if (uVar3 != 0) {
    puStack_c = param_1;
    if (0x15555555 < uVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar3 = uVar3 * 0xc;
    if (uVar3 < 0x1000) {
      if (uVar3 == 0) {
        uVar1 = 0;
      }
      else {
        uVar1 = FUN_01674e20(uVar3);
      }
    }
    else {
      uVar1 = uVar3 + 0x23;
      if (uVar1 <= uVar3) {
        uVar1 = 0xffffffff;
      }
      iVar2 = FUN_01674e20(uVar1);
      if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar1 = iVar2 + 0x23U & 0xffffffe0;
      *(int *)(uVar1 - 4) = iVar2;
    }
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + uVar3;
    iVar2 = *param_2;
    uVar3 = *param_1;
    FUN_0055b6b0(&uStack_5,auStack_10,auStack_10);
    iVar4 = param_2[1] - iVar2;
    FUN_0170cc70(uVar3,iVar2,iVar4);
    puStack_c[1] = uVar3 + iVar4;
    param_1 = puStack_c;
  }
  return param_1;
}



/* FUNCTION 12367 ; VA 0x00806e90 ; FUN_00806e90 */

uint * __thiscall FUN_00806e90(uint *param_1,uint param_2,undefined8 *param_3)

{
  uint uVar1;
  int iVar2;
  undefined8 *puVar3;
  uint uVar4;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x15555555 < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar4 = param_2 * 0xc;
    if (uVar4 < 0x1000) {
      if (uVar4 == 0) {
        uVar1 = 0;
      }
      else {
        uVar1 = FUN_01674e20(uVar4);
      }
    }
    else {
      uVar1 = uVar4 + 0x23;
      if (uVar1 <= uVar4) {
        uVar1 = 0xffffffff;
      }
      iVar2 = FUN_01674e20(uVar1);
      if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar1 = iVar2 + 0x23U & 0xffffffe0;
      *(int *)(uVar1 - 4) = iVar2;
    }
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + uVar4;
    puVar3 = (undefined8 *)*param_1;
    if (param_2 != 0) {
      do {
        *puVar3 = *param_3;
        *(undefined4 *)(puVar3 + 1) = *(undefined4 *)(param_3 + 1);
        puVar3 = (undefined8 *)((int)puVar3 + 0xc);
        param_2 = param_2 - 1;
      } while (param_2 != 0);
    }
    param_1[1] = (uint)puVar3;
  }
  return param_1;
}



/* FUNCTION 12368 ; VA 0x00806f50 ; FUN_00806f50 */

undefined2 * __fastcall FUN_00806f50(undefined2 *param_1)

{
  *param_1 = 0;
  return param_1;
}



/* FUNCTION 12369 ; VA 0x00806f60 ; FUN_00806f60 */

int * __thiscall FUN_00806f60(int *param_1,undefined8 *param_2,byte param_3,undefined param_4)

{
  byte bVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  int iStack_50;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  undefined8 uStack_38;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b4cf7;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined8 *)param_1 = *param_2;
  param_1[2] = *(int *)(param_2 + 1);
  *(byte *)(param_1 + 3) = param_3;
  *(undefined *)((int)param_1 + 0xd) = param_4;
  *(undefined4 *)((int)param_1 + 0x11) = 0;
  param_1[6] = 0;
  piStack_14 = param_1;
  FUN_016f4053(param_1 + 7,4,8,FUN_00550050,&LAB_00807ab0);
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = param_1[0x1a] | 0xffffff;
  *(undefined *)((int)param_1 + 0x6b) = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0x7f7fffff;
  param_1[0x20] = 0x7f7fffff;
  param_1[0x21] = 0x7f7fffff;
  param_1[0x22] = -0x800001;
  param_1[0x23] = -0x800001;
  param_1[0x24] = -0x800001;
  param_1[0x25] = 0x7f7fffff;
  param_1[0x26] = 0x7f7fffff;
  param_1[0x27] = 0x7f7fffff;
  param_1[0x28] = -0x800001;
  param_1[0x29] = -0x800001;
  param_1[0x2a] = -0x800001;
  *(undefined2 *)((int)param_1 + 0xf) = 0x505;
  *(undefined *)((int)param_1 + 0xe) = 5;
  bVar1 = *(char *)(param_1 + 3) + 4;
  iStack_20 = *param_1 << (bVar1 & 0x1f);
  iStack_1c = param_1[1] << (bVar1 & 0x1f);
  uStack_38 = CONCAT44(iStack_1c,iStack_20);
  iStack_24 = 1 << (bVar1 & 0x1f);
  iStack_2c = iStack_20 + iStack_24;
  iStack_30 = param_1[2] << (bVar1 & 0x1f);
  iStack_28 = iStack_1c + iStack_24;
  uStack_8 = 3;
  iStack_24 = iStack_30 + iStack_24;
  FUN_00a70570(&iStack_50,1 << (param_3 & 0x1f));
  fVar5 = (float)iStack_50 * DAT_018e3f8c;
  fVar7 = (float)iStack_44 * DAT_018e3f8c;
  fVar3 = (float)iStack_4c * DAT_018e3f8c;
  fVar6 = (float)iStack_40 * DAT_018e3f8c;
  fVar4 = (float)iStack_3c * DAT_018e3f8c;
  fVar2 = (float)iStack_48 * DAT_018e3f8c;
  piStack_14[0x25] = (int)fVar5;
  piStack_14[0x26] = (int)fVar3;
  piStack_14[0x27] = (int)fVar2;
  piStack_14[0x28] = (int)fVar7;
  *(ulonglong *)(piStack_14 + 0x29) = CONCAT44(fVar4,fVar6);
  piStack_14[0x1f] = (int)fVar5;
  piStack_14[0x20] = (int)fVar3;
  piStack_14[0x21] = (int)fVar2;
  piStack_14[0x22] = (int)fVar7;
  *(ulonglong *)(piStack_14 + 0x23) = CONCAT44(fVar4,fVar6);
  ExceptionList = pvStack_10;
  return piStack_14;
}



/* FUNCTION 12370 ; VA 0x008071f0 ; FUN_008071f0 */

undefined4 * __thiscall
FUN_008071f0(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4,
            undefined4 param_5,undefined4 *param_6,undefined4 *param_7,undefined4 param_8,
            undefined4 param_9,undefined4 *param_10,undefined4 param_11)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  FUN_00841220(0,param_3,param_4,param_8,param_9,0xff,param_11);
  param_1[0x13] = param_2;
  *param_1 = RBX::Graphics::SmoothCluster::ChunkRenderEntity::vftable;
  uVar2 = *param_10;
  uVar3 = param_10[1];
  uVar4 = param_10[2];
  uVar5 = param_10[3];
  param_1[0x18] = param_5;
  param_1[0x14] = uVar2;
  param_1[0x15] = uVar3;
  param_1[0x16] = uVar4;
  param_1[0x17] = uVar5;
  uVar2 = param_6[1];
  uVar3 = param_6[2];
  uVar4 = param_6[3];
  param_1[0x19] = *param_6;
  param_1[0x1a] = uVar2;
  param_1[0x1b] = uVar3;
  param_1[0x1c] = uVar4;
  uVar2 = param_7[1];
  uVar3 = param_7[2];
  uVar4 = param_7[3];
  param_1[0x1d] = *param_7;
  param_1[0x1e] = uVar2;
  param_1[0x1f] = uVar3;
  param_1[0x20] = uVar4;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x21] = *param_3;
  param_1[0x22] = param_3[1];
  param_1[0x23] = param_3[2];
  param_1[0x24] = param_3[3];
  param_1[0x25] = param_3[4];
  param_1[0x26] = param_3[5];
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  if (param_4[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0x27] = *param_4;
  param_1[0x28] = param_4[1];
  param_1[0x29] = param_4[2];
  param_1[0x2a] = param_4[3];
  param_1[0x2b] = param_4[4];
  param_1[0x2c] = param_4[5];
  return param_1;
}



/* FUNCTION 12371 ; VA 0x00807300 ; FUN_00807300 */

undefined4 * __thiscall FUN_00807300(undefined4 *param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  double dVar8;
  float fVar9;
  float fVar10;
  undefined auStack_78 [24];
  undefined8 uStack_60;
  undefined4 *puStack_58;
  int iStack_54;
  int iStack_50;
  undefined4 *puStack_4c;
  undefined8 *puStack_48;
  undefined8 uStack_44;
  undefined4 *puStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_28;
  int iStack_24;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b4e5d;
  pvStack_10 = ExceptionList;
  iStack_14 = 0;
  ExceptionList = &pvStack_10;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0xffffffff;
  param_1[7] = RBX::Voxel2::GridListener::vftable;
  *param_1 = RBX::Graphics::SmoothCluster::vftable;
  param_1[7] = RBX::Graphics::SmoothCluster::vftable;
  param_1[8] = param_2;
  param_1[10] = 0;
  *(undefined *)((int)param_1 + 0x2d) = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  uStack_8._0_1_ = 0xd;
  uStack_8._1_3_ = 0;
  *(undefined *)(param_1 + 0x33) = 0;
  puStack_18 = param_1;
  FUN_016f4053(param_1 + 0x34,4,8,FUN_00550050,&LAB_00807ab0);
  iStack_28 = -0x80000000;
  iStack_24 = -0x80000000;
  uStack_44 = 0x8000000080000000;
  uStack_8._0_1_ = 0xe;
  puStack_3c = (undefined4 *)&DAT_80000000;
  FUN_00806e90(0,&uStack_44,(int)&param_2 + 3);
  *(ulonglong *)(param_1 + 0x40) = CONCAT44(iStack_24,iStack_28);
  param_1[0x3f] = 0;
  param_1[0x42] = 0x80000000;
  param_1[0x44] = 0;
  param_1[0x45] = 0;
  param_1[0x46] = 0;
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  param_1[0x49] = 0;
  param_1[0x4a] = 0;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  param_1[0x4d] = 0;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  param_1[0x50] = 0;
  param_1[0x51] = 0;
  param_1[0x52] = 0;
  uStack_8._0_1_ = 0x14;
  FUN_016f4053(param_1 + 0x53,8,0x19,FUN_0075dc70,FUN_00550b30);
  param_1[0x85] = 0;
  param_1[0x86] = 0;
  param_1[0x87] = 0;
  param_1[0x88] = 0;
  param_1[0x89] = 0;
  param_1[0x8a] = 0;
  param_1[0x8b] = 0;
  param_1[0x8c] = 0;
  param_1[0x8d] = 0;
  param_1[0x8e] = 0;
  param_1[0x8f] = 0;
  param_1[0x90] = 0;
  *(undefined *)(param_1 + 0x91) = 0;
  *(undefined8 *)(param_1 + 0x92) = 0;
  param_1[0x94] = 2;
  iVar7 = param_3[1];
  uStack_8._0_1_ = 0x15;
  if (iVar7 != 0) {
    LOCK();
    *(int *)(iVar7 + 4) = *(int *)(iVar7 + 4) + 1;
    UNLOCK();
    iVar7 = param_3[1];
  }
  param_1[1] = *param_3;
  piVar1 = (int *)param_1[2];
  param_1[2] = iVar7;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar7 = piVar1[1] + -1;
    piVar1[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar7 = piVar1[2] + -1;
      piVar1[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = param_3;
  *(undefined4 **)(param_1[1] + 0xb0) = param_1;
  iVar7 = *param_3;
  param_1[9] = iVar7;
  param_1[10] = *(undefined4 *)(iVar7 + 0x134);
  FUN_00a6e300(param_1 + 7);
  param_3 = (int *)(*piVar1 + 0x48);
  uStack_8._0_1_ = 0x16;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 0x17;
  uStack_1c = uVar4;
  param_2 = (undefined4 *)FUN_01674e20(0x20);
  if (param_2 == (undefined4 *)0x0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    *param_2 = 0;
    param_2[1] = 1;
    param_2[2] = FUN_00808f30;
    param_2[3] = _guard_check_icall;
    param_2[4] = 0;
    param_2[5] = param_3;
    param_2[6] = &LAB_008083f1;
    param_2[7] = param_1;
    puVar6 = param_2;
  }
  FUN_016797d0(puVar6);
  if (puVar6 != (undefined4 *)0x0) {
    LOCK();
    puVar6[1] = puVar6[1] + 1;
    UNLOCK();
  }
  iStack_14 = 1;
  uStack_8._0_1_ = 0x18;
  param_2 = puVar6;
  FUN_01675290(uVar4);
  puVar2 = (undefined4 *)param_1[4];
  uStack_8._0_1_ = 0x16;
  if ((undefined4 *)param_1[5] == puVar2) {
    FUN_006335f0(puVar2,&param_2);
    puVar6 = param_2;
  }
  else {
    *puVar2 = puVar6;
    param_1[4] = param_1[4] + 4;
    puVar6 = (undefined4 *)0x0;
  }
  uStack_8._0_1_ = 0x15;
  if (puVar6 != (undefined4 *)0x0) {
    piVar1 = puVar6 + 1;
    LOCK();
    iVar7 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar7 == 1) {
      FUN_01674ea0(puVar6);
    }
  }
  *(undefined *)(param_1 + 0xb) = 3;
  param_1[0x21] = *(undefined4 *)(param_1[9] + 0x13c);
  FUN_0080ec90();
  FUN_0080e610();
  FUN_00862cb0();
  FUN_00a70e60(&iStack_38);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
  iStack_14 = iStack_34;
  param_3 = (int *)iStack_38;
  if (iStack_38 != iStack_34) {
    do {
      FUN_00a70570(auStack_78,2);
      FUN_00a70da0(&uStack_60,4);
      puStack_48 = &uStack_60;
      uStack_44 = uStack_60;
      puStack_3c = puStack_58;
      iStack_28 = iStack_54;
      iStack_24 = iStack_50;
      param_2 = puStack_4c;
      while ((((int)uStack_44 != iStack_28 || (uStack_44._4_4_ != iStack_24)) ||
             (puStack_3c != param_2))) {
        iVar5 = FUN_008093c0(&uStack_44,0);
        for (iVar7 = iVar5; (iVar7 != 0 && (*(byte *)(iVar7 + 0xc) < 5));
            iVar7 = *(int *)(iVar7 + 0x18)) {
          *(undefined *)(iVar7 + 0x11) = 1;
        }
        if ((DAT_01d61f54 == '\0') || (*(char *)(iVar5 + 0xc) == '\0')) {
          uVar4 = FUN_008096e0(auStack_78);
          uVar3 = FUN_00a70880(uVar4);
          *(undefined *)(iVar5 + 0xd) = uVar3;
        }
        for (iVar7 = *(int *)(iVar5 + 0x18); (iVar7 != 0 && (*(byte *)(iVar7 + 0xc) < 5));
            iVar7 = *(int *)(iVar7 + 0x18)) {
          FUN_0080c1d0(iVar7);
        }
        FUN_00a6e100();
      }
      param_3 = (int *)((int)param_3 + 0x18);
    } while (param_3 != (int *)iStack_14);
  }
  iVar7 = 0;
  do {
    dVar8 = DAT_01900c48;
    FUN_01726ab0();
    fVar9 = (((float)dVar8 - DAT_018ce2f8) * DAT_01901960) / DAT_01901940;
    fVar10 = fVar9 * DAT_0190193c;
    fVar9 = fVar9 * DAT_01901940;
    (&DAT_01eb3704)[iVar7] = fVar10 * fVar10;
    (&DAT_01eb3718)[iVar7] = fVar9 * fVar9;
    iVar7 = iVar7 + 1;
  } while (iVar7 < 5);
  FUN_00612d60();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12372 ; VA 0x00807990 ; FUN_00807990 */

undefined4 * __thiscall FUN_00807990(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *param_1 = *param_2;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(param_2 + 4);
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_2[10] = 0;
  param_2[0xb] = 0;
  param_1[0xc] = param_2[0xc];
  return param_1;
}



/* FUNCTION 12373 ; VA 0x00807a00 ; FUN_00807a00 */

undefined4 * __thiscall FUN_00807a00(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  uVar2 = param_2[1];
  uVar3 = param_2[2];
  uVar4 = param_2[3];
  *param_1 = *param_2;
  param_1[1] = uVar2;
  param_1[2] = uVar3;
  param_1[3] = uVar4;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(param_2 + 4);
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  param_1[10] = 0;
  param_1[0xb] = 0;
  if (param_2[0xb] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[0xb] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = param_2[0xc];
  return param_1;
}



/* FUNCTION 12374 ; VA 0x00807a60 ; FUN_00807a60 */

undefined4 * __fastcall FUN_00807a60(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  FUN_00a6dc10();
  return param_1;
}



/* FUNCTION 12375 ; VA 0x00807ac0 ; FUN_00807ac0 */

void __fastcall FUN_00807ac0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_00805310(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0xc) * 0xc;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 12376 ; VA 0x00807b40 ; FUN_00807b40 */

void __fastcall FUN_00807b40(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_00805360(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0xb8) * 0xb8;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12377 ; VA 0x00807be0 ; FUN_00807be0 */

void __fastcall FUN_00807be0(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = param_1[6];
  if (iVar1 != 0) {
    uVar3 = param_1[8] - iVar1;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00807cbc;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[6] = 0;
    param_1[7] = 0;
    param_1[8] = 0;
  }
  iVar1 = param_1[3];
  if (iVar1 != 0) {
    uVar3 = param_1[5] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00807cbc;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[5] = 0;
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1 & 0xfffffff0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_00807cbc:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 12378 ; VA 0x00807cd0 ; FUN_00807cd0 */

void __fastcall FUN_00807cd0(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0x3c);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x44) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00807e0b;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x3c) = 0;
    *(undefined4 *)(param_1 + 0x40) = 0;
    *(undefined4 *)(param_1 + 0x44) = 0;
  }
  iVar1 = *(int *)(param_1 + 0x30);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x38) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00807e0b;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x30) = 0;
    *(undefined4 *)(param_1 + 0x34) = 0;
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  iVar1 = *(int *)(param_1 + 0x24);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x2c) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00807e0b;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x24) = 0;
    *(undefined4 *)(param_1 + 0x28) = 0;
    *(undefined4 *)(param_1 + 0x2c) = 0;
  }
  iVar1 = *(int *)(param_1 + 0x18);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x20) - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_00807e0b:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x18) = 0;
    *(undefined4 *)(param_1 + 0x1c) = 0;
    *(undefined4 *)(param_1 + 0x20) = 0;
  }
  FUN_00617bc0();
  FUN_00617bc0();
  return;
}



/* FUNCTION 12379 ; VA 0x00807e20 ; FUN_00807e20 */

void __fastcall FUN_00807e20(int param_1)

{
  if (*(undefined4 **)(param_1 + 0x10) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0x10))(1);
  }
  if (*(undefined4 **)(param_1 + 0xc) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 0xc))(1);
  }
  if (*(undefined4 **)(param_1 + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 8))(1);
  }
  if (*(undefined4 **)(param_1 + 4) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(param_1 + 4))(1);
  }
  return;
}



/* FUNCTION 12380 ; VA 0x00807e60 ; FUN_00807e60 */

void __fastcall FUN_00807e60(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[7] = RBX::Graphics::SmoothCluster::vftable;
  *param_1 = RBX::Graphics::SmoothCluster::vftable;
  FUN_011590c0();
  if (param_1[10] != 0) {
    FUN_00a6f530(param_1 + 7);
    param_1[10] = 0;
  }
  param_1[9] = 0;
  FUN_007c78a0(param_1,0xffffffff);
  uVar6 = 0;
  do {
    iVar3 = param_1[((int)uVar6 >> 2 & 1U) + (((int)uVar6 >> 1 & 1U) + 0x1a + (uVar6 & 1) * 2) * 2];
    param_1[((int)uVar6 >> 2 & 1U) + (((int)uVar6 >> 1 & 1U) + 0x1a + (uVar6 & 1) * 2) * 2] = 0;
    if (iVar3 != 0) {
      FUN_00808350(iVar3);
    }
    uVar6 = uVar6 + 1;
  } while ((int)uVar6 < 8);
  puVar2 = param_1 + 0x50;
  FUN_00805310(*puVar2,param_1[0x51],puVar2);
  param_1[0x51] = *puVar2;
  FUN_016f32d1(param_1 + 0x53,8,0x19,FUN_00550b30);
  FUN_00807ac0();
  iVar3 = param_1[0x4d];
  if (iVar3 != 0) {
    uVar6 = param_1[0x4f] - iVar3 & 0xfffffff0;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_008082a5;
    }
    FUN_01674ea0(iVar5,uVar6);
    param_1[0x4d] = 0;
    param_1[0x4e] = 0;
    param_1[0x4f] = 0;
  }
  FUN_00617ad0();
  FUN_00807b40();
  iVar3 = param_1[0x44];
  if (iVar3 != 0) {
    uVar6 = param_1[0x46] - iVar3 & 0xfffffff8;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_008082a5;
    }
    FUN_01674ea0(iVar5,uVar6);
    param_1[0x44] = 0;
    param_1[0x45] = 0;
    param_1[0x46] = 0;
  }
  FUN_00617ad0();
  FUN_016f32d1(param_1 + 0x34,4,8,&LAB_00807ab0);
  iVar3 = param_1[0x28];
  if (iVar3 != 0) {
    uVar6 = param_1[0x2a] - iVar3 & 0xfffffff0;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_008082a5;
    }
    FUN_01674ea0(iVar5,uVar6);
    param_1[0x28] = 0;
    param_1[0x29] = 0;
    param_1[0x2a] = 0;
  }
  iVar3 = param_1[0x25];
  if (iVar3 != 0) {
    uVar6 = param_1[0x27] - iVar3 & 0xfffffffc;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_008082a5;
    }
    FUN_01674ea0(iVar5,uVar6);
    param_1[0x25] = 0;
    param_1[0x26] = 0;
    param_1[0x27] = 0;
  }
  iVar3 = param_1[0x22];
  if (iVar3 != 0) {
    uVar6 = param_1[0x24] - iVar3 & 0xfffffffc;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_008082a5;
    }
    FUN_01674ea0(iVar5,uVar6);
    param_1[0x22] = 0;
    param_1[0x23] = 0;
    param_1[0x24] = 0;
  }
  piVar4 = (int *)param_1[0x1f];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar3 = piVar4[2] + -1;
      piVar4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = (int *)param_1[0x1d];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar3 = piVar4[2] + -1;
      piVar4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = (int *)param_1[0x1b];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar3 = piVar4[2] + -1;
      piVar4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = (int *)param_1[0x19];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar3 = piVar4[2] + -1;
      piVar4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = (int *)param_1[0x17];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar3 = piVar4[2] + -1;
      piVar4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = (int *)param_1[0x15];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar3 = piVar4[2] + -1;
      piVar4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = (int *)param_1[0x13];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_00617ad0();
  iVar3 = param_1[0xc];
  if (iVar3 != 0) {
    uVar6 = param_1[0xe] - iVar3 & 0xfffffffc;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar3 - iVar5) - 4U) {
LAB_008082a5:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    param_1[0xc] = 0;
    param_1[0xd] = 0;
    param_1[0xe] = 0;
  }
  param_1[7] = RBX::Voxel2::GridListener::vftable;
  FUN_01158110();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12381 ; VA 0x008082b0 ; FUN_008082b0 */

int __fastcall FUN_008082b0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_016f32d1(param_1 + 0x1c,0x34,3,&LAB_00808320);
  piVar3 = *(int **)(param_1 + 0x18);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 12382 ; VA 0x00808350 ; FUN_00808350 */

void FUN_00808350(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    if (*(undefined4 **)(param_1 + 0x78) != (undefined4 *)0x0) {
      ExceptionList = &pvStack_10;
      (**(code **)**(undefined4 **)(param_1 + 0x78))(1);
    }
    if (*(undefined4 **)(param_1 + 0x74) != (undefined4 *)0x0) {
      (**(code **)**(undefined4 **)(param_1 + 0x74))(1);
    }
    if (*(undefined4 **)(param_1 + 0x70) != (undefined4 *)0x0) {
      (**(code **)**(undefined4 **)(param_1 + 0x70))(1);
    }
    if (*(undefined4 **)(param_1 + 0x6c) != (undefined4 *)0x0) {
      (**(code **)**(undefined4 **)(param_1 + 0x6c))(1);
    }
    FUN_00617ad0();
    if (*(undefined4 **)(param_1 + 0x3c) != (undefined4 *)0x0) {
      (**(code **)**(undefined4 **)(param_1 + 0x3c))(1);
    }
    FUN_016f32d1(param_1 + 0x1c,4,8,&LAB_00807ab0);
    FUN_01674ea0(param_1,0xb0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12383 ; VA 0x008083f6 ; FUN_008083f6 */

void FUN_008083f6(void)

{
  FUN_00808500();
  return;
}



/* FUNCTION 12384 ; VA 0x00808400 ; FUN_00808400 */

undefined4 * __thiscall FUN_00808400(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::SmoothCluster::ChunkRenderEntity::vftable;
  FUN_0080a8e0(param_1 + 5);
  FUN_0080a8e0(param_1 + 0xb);
  piVar2 = (int *)param_1[0x28];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x22];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00841390();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xb4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12385 ; VA 0x008084d0 ; FUN_008084d0 */

undefined4 __thiscall FUN_008084d0(undefined4 param_1,byte param_2)

{
  FUN_00841090();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x3c);
  }
  return param_1;
}



/* FUNCTION 12386 ; VA 0x00808500 ; FUN_00808500 */

undefined4 __thiscall FUN_00808500(undefined4 param_1,byte param_2)

{
  FUN_00807e60();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,600);
  }
  return param_1;
}



/* FUNCTION 12387 ; VA 0x00808530 ; FUN_00808530 */

void __thiscall FUN_00808530(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00805360(param_2,param_3,param_1);
  return;
}



/* FUNCTION 12388 ; VA 0x00808550 ; FUN_00808550 */

void __thiscall FUN_00808550(int *param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  
  piVar3 = (int *)*param_1;
  iVar1 = param_1[1] - (int)piVar3 >> 0x1f;
  iVar2 = (param_1[1] - (int)piVar3) / 0xc + iVar1;
  uVar4 = 0;
  if (iVar2 != iVar1) {
    do {
      if (((*piVar3 != param_1[4]) || (piVar3[1] != param_1[5])) || (piVar3[2] != param_1[6]))
      break;
      uVar4 = uVar4 + 1;
      piVar3 = piVar3 + 3;
    } while (uVar4 < (uint)(iVar2 - iVar1));
  }
  param_2[1] = uVar4;
  *param_2 = param_1;
  return;
}



/* FUNCTION 12389 ; VA 0x008085a0 ; FUN_008085a0 */

uint __thiscall FUN_008085a0(int param_1,longlong *param_2)

{
  byte bVar1;
  int iVar2;
  uint uVar3;
  byte bVar4;
  int iVar5;
  int iVar6;
  uint *puVar7;
  undefined8 uStack_18;
  int iStack_10;
  int iStack_c;
  int iStack_8;
  
  iStack_8 = 0;
  bVar1 = *(byte *)((int)param_2 + 0xc);
  iStack_c = param_1;
  do {
    iVar2 = iStack_c;
    iStack_10 = *(int *)(param_2 + 1);
    uStack_18 = *param_2;
    uVar3 = *(uint *)((int)&uStack_18 + iStack_8 * 4);
    *(uint *)((int)&uStack_18 + iStack_8 * 4) = (uVar3 & 1) * 2 + -1 + uVar3;
    iVar6 = 0xd0;
    if ((int)uStack_18 < 0) {
      iVar6 = 0xe0;
    }
    iVar5 = 0;
    if (uStack_18 < 0) {
      iVar5 = 8;
    }
    uVar3 = 0;
    if (iStack_10 < 0) {
      uVar3 = 4;
    }
    puVar7 = *(uint **)(uVar3 + iVar5 + iVar2 + iVar6);
    if ((puVar7 != (uint *)0x0) && (bVar1 <= *(byte *)(puVar7 + 3))) {
      bVar4 = *(byte *)(puVar7 + 3) - bVar1;
      uVar3 = (int)uStack_18 >> (bVar4 & 0x1f);
      if ((uVar3 == *puVar7) &&
         ((uStack_18._4_4_ >> (bVar4 & 0x1f) == puVar7[1] &&
          (iStack_10 >> (bVar4 & 0x1f) == puVar7[2])))) {
        do {
          if (*(byte *)(puVar7 + 3) == bVar1) break;
          if (*(char *)((int)puVar7 + 0x12) != '\0') {
            return uVar3 & 0xffffff00;
          }
          bVar4 = (*(byte *)(puVar7 + 3) - bVar1) - 1;
          uVar3 = (iStack_10 >> (bVar4 & 0x1f) & 1U) +
                  ((uStack_18._4_4_ >> (bVar4 & 0x1f) & 1U) +
                  ((int)uStack_18 >> (bVar4 & 0x1f) & 1U) * 2) * 2;
          puVar7 = (uint *)puVar7[uVar3 + 7];
        } while (puVar7 != (uint *)0x0);
      }
    }
    iStack_8 = iStack_8 + 1;
    if (2 < iStack_8) {
      return CONCAT31((int3)(uVar3 >> 8),1);
    }
  } while( true );
}



/* FUNCTION 12390 ; VA 0x008086b0 ; FUN_008086b0 */

void FUN_008086b0(int param_1)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = 0;
  do {
    iVar1 = *(int *)(param_1 + 0x1c +
                    (((int)uVar2 >> 2 & 1U) + (((int)uVar2 >> 1 & 1U) + (uVar2 & 1) * 2) * 2) * 4);
    if (iVar1 != 0) {
      if (*(char *)(param_1 + 0x12) == '\0') {
        FUN_008086b0(iVar1);
      }
      FUN_0080a660(iVar1,0);
    }
    uVar2 = uVar2 + 1;
  } while ((int)uVar2 < 8);
  return;
}



/* FUNCTION 12391 ; VA 0x00808710 ; FUN_00808710 */

float * FUN_00808710(float *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  float fVar2;
  double dVar3;
  float fVar4;
  float fVar5;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  double dStack_c;
  
  uVar1 = FUN_0115e8a0(param_2);
  FUN_0115eba0(&fStack_28,uVar1);
  uVar1 = FUN_0115e8a0(param_3);
  FUN_0115eba0(&fStack_1c,uVar1);
  fVar5 = DAT_018daf58;
  fVar2 = 0.0;
  if (0.0 <= fStack_14 / fStack_20) {
    fVar2 = fStack_14 / fStack_20;
  }
  fVar4 = DAT_018daf58;
  if (fVar2 <= DAT_018daf58) {
    fVar4 = fVar2;
  }
  fVar2 = (fStack_1c - fStack_28) * DAT_019011e0;
  *param_1 = fVar4;
  dVar3 = (double)(fVar2 * DAT_0190119c);
  fVar2 = 0.0;
  if (0.0 <= fStack_18 / fStack_24) {
    fVar2 = fStack_18 / fStack_24;
  }
  if (fVar2 <= fVar5) {
    fVar5 = fVar2;
  }
  dStack_c = dVar3;
  FUN_017279f0();
  param_1[1] = (float)dVar3 * fVar5 * fVar4;
  FUN_01728390();
  param_1[3] = 0.0;
  param_1[2] = (float)dStack_c * fVar5 * fVar4;
  return param_1;
}



/* FUNCTION 12392 ; VA 0x008087f0 ; FUN_008087f0 */

void __thiscall FUN_008087f0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  float fStack_24;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined8 uStack_c;
  
  puVar1 = &uStack_1c;
  if (DAT_01d61f3c == '\0') {
    puVar1 = (undefined4 *)FUN_00809230(puVar1);
  }
  else {
    uStack_1c = *(undefined4 *)(param_1 + 0x7c);
    uStack_18 = *(undefined4 *)(param_1 + 0x80);
    uStack_14 = *(undefined4 *)(param_1 + 0x84);
    uStack_10 = *(undefined4 *)(param_1 + 0x88);
    uStack_c = *(undefined8 *)(param_1 + 0x8c);
  }
  uStack_10 = *param_2;
  fStack_24 = (float)*(undefined8 *)(puVar1 + 4);
  uStack_c = CONCAT44(param_2[2],(fStack_24 + (float)puVar1[1]) * DAT_018ce2f4);
  FUN_00c9ed90(&uStack_10);
  return;
}



/* FUNCTION 12393 ; VA 0x00808880 ; FUN_00808880 */

void FUN_00808880(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0xb8;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 12394 ; VA 0x008088c0 ; FUN_008088c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_008088c0(undefined4 param_1,int param_2)

{
  int iVar1;
  undefined8 *puVar2;
  uint uVar3;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  int iStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b4e7c;
  pvStack_10 = ExceptionList;
  if (DAT_01d61f3c == '\0') {
    ExceptionList = &pvStack_10;
    FUN_00809230(&uStack_68);
  }
  else {
    uStack_68 = *(undefined4 *)(param_2 + 0x7c);
    uStack_64 = *(undefined4 *)(param_2 + 0x80);
    uStack_60 = *(undefined4 *)(param_2 + 0x84);
    uStack_5c = *(undefined4 *)(param_2 + 0x88);
    uStack_58 = *(undefined8 *)(param_2 + 0x8c);
    ExceptionList = &pvStack_10;
  }
  uVar3 = 1;
  iStack_50 = 0;
  do {
    if ((uVar3 & (int)*(char *)(param_2 + 0x6b)) != 0) {
      uStack_40 = 0;
      uStack_3c = 0;
      uStack_38 = 0;
      uStack_28 = 0;
      iVar1 = 3;
      uStack_24 = 0;
      if ((*(byte *)(param_2 + iStack_50 * 4) & 1) != 0) {
        iVar1 = 0;
      }
      uStack_20 = 0;
      uStack_34 = 0;
      uStack_30 = 0;
      uStack_2c = 0;
      uStack_4c = 0;
      uStack_48 = 0;
      uStack_44 = 0;
      FUN_00c9f280(iVar1 + iStack_50,&uStack_40,&uStack_28,&uStack_34,&uStack_4c);
      if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb37a8)
      {
        FUN_016f3809(&DAT_01eb37a8);
        if (DAT_01eb37a8 == -1) {
          uStack_8 = 0;
          puVar2 = (undefined8 *)FUN_0115eb90();
          _DAT_01eb376c = *puVar2;
          _DAT_01eb3774 = *(undefined4 *)(puVar2 + 1);
          puVar2 = (undefined8 *)FUN_0115eb50();
          _DAT_01eb3778 = *puVar2;
          _DAT_01eb3780 = *(undefined4 *)(puVar2 + 1);
          puVar2 = (undefined8 *)FUN_0115e920();
          _DAT_01eb3784 = *puVar2;
          _DAT_01eb378c = *(undefined4 *)(puVar2 + 1);
          puVar2 = (undefined8 *)FUN_0115ee80();
          _DAT_01eb3790 = *puVar2;
          _DAT_01eb3798 = *(undefined4 *)(puVar2 + 1);
          puVar2 = (undefined8 *)FUN_0115eb80();
          uStack_8 = 0xffffffff;
          _DAT_01eb379c = *puVar2;
          _DAT_01eb37a4 = *(undefined4 *)(puVar2 + 1);
          FUN_016f37bf(&DAT_01eb37a8);
        }
      }
      uStack_1c = *(undefined8 *)(&DAT_01eb376c + (uint)*(byte *)(param_2 + 0xc) * 0xc);
      uStack_14 = *(undefined4 *)(&DAT_01eb3774 + (uint)*(byte *)(param_2 + 0xc) * 0xc);
      FUN_0078af00();
      uStack_78 = (undefined4)uStack_1c;
      uStack_74 = uStack_1c._4_4_;
      uStack_70 = uStack_14;
      uStack_6c = 0x3f800000;
      FUN_007f92d0(uStack_40,uStack_3c,uStack_38,uStack_28,uStack_24,uStack_20,&uStack_78);
      uStack_88 = (undefined4)uStack_1c;
      uStack_84 = uStack_1c._4_4_;
      uStack_80 = uStack_14;
      uStack_7c = 0x3f800000;
      FUN_007f92d0(uStack_28,uStack_24,uStack_20,uStack_34,uStack_30,uStack_2c,&uStack_88);
      uStack_98 = (undefined4)uStack_1c;
      uStack_94 = uStack_1c._4_4_;
      uStack_90 = uStack_14;
      uStack_8c = 0x3f800000;
      FUN_007f92d0(uStack_34,uStack_30,uStack_2c,uStack_4c,uStack_48,uStack_44,&uStack_98);
      uStack_60 = (undefined4)uStack_1c;
      uStack_5c = uStack_1c._4_4_;
      uStack_58 = CONCAT44(0x3f800000,uStack_14);
      FUN_007f92d0(uStack_4c,uStack_48,uStack_44,uStack_40,uStack_3c,uStack_38,&uStack_60);
    }
    iStack_50 = iStack_50 + 1;
    uVar3 = uVar3 << 1 | (uint)((int)uVar3 < 0);
  } while (iStack_50 < 3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12395 ; VA 0x00808cd0 ; FUN_00808cd0 */

void __fastcall FUN_00808cd0(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  uint uVar11;
  undefined4 *puVar12;
  undefined8 uVar13;
  undefined8 uVar14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b4eb0;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if ((*(int *)(iVar2 + 0x34) < DAT_01eb38c8) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb38c8), DAT_01eb38c8 == -1)) {
    uStack_8 = 0;
    uVar13 = FUN_0152dab0("Render","destroyGeometry",0xffffffff);
    DAT_01eb38c4 = (undefined4)((ulonglong)uVar13 >> 0x20);
    DAT_01eb38c0 = (undefined4)uVar13;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb38c8);
  }
  uVar8 = DAT_01eb38c4;
  uVar7 = DAT_01eb38c0;
  uVar13 = FUN_0152d930(DAT_01eb38c0,DAT_01eb38c4);
  puVar10 = *(undefined4 **)(param_1 + 0x144);
  piVar1 = (int *)(param_1 + 0x140);
  puVar12 = (undefined4 *)*piVar1;
  uStack_8 = 1;
  puVar9 = puVar12;
  for (uVar11 = 0;
      ((puVar9 != puVar10 && (2 < (uint)puVar9[2])) && ((0x1d < (uint)puVar9[2] || (uVar11 < 0x20)))
      ); uVar11 = uVar11 + 1) {
    puVar9 = puVar9 + 3;
  }
  puVar9 = puVar12 + uVar11 * 3;
  if (puVar12 == puVar9) {
    puVar12 = *(undefined4 **)(param_1 + 0x144);
  }
  else {
    for (; puVar9 != puVar10; puVar9 = puVar9 + 3) {
      uVar3 = *puVar9;
      uVar4 = puVar9[1];
      *puVar9 = 0;
      puVar9[1] = 0;
      *puVar12 = uVar3;
      piVar5 = (int *)puVar12[1];
      puVar12[1] = uVar4;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar6 = piVar5[1] + -1;
        piVar5[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar6 = piVar5[2] + -1;
          piVar5[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      puVar12[2] = puVar9[2];
      puVar12 = puVar12 + 3;
    }
    FUN_00805310(puVar12,*(undefined4 *)(param_1 + 0x144),piVar1);
    *(undefined4 **)(param_1 + 0x144) = puVar12;
  }
  for (puVar10 = (undefined4 *)*piVar1; puVar10 != puVar12; puVar10 = puVar10 + 3) {
    puVar10[2] = puVar10[2] + 1;
  }
  if ((*(int *)(iVar2 + 0x34) < DAT_01eb38d8) && (FUN_016f3809(&DAT_01eb38d8), DAT_01eb38d8 == -1))
  {
    uStack_8._0_1_ = 2;
    uVar14 = FUN_0152da50("Render");
    DAT_01eb38d4 = (undefined4)((ulonglong)uVar14 >> 0x20);
    DAT_01eb38d0 = (undefined4)uVar14;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_016f37bf(&DAT_01eb38d8);
  }
  FUN_0152d760(DAT_01eb38d0,DAT_01eb38d4,"Destroyed %d queued %d",uVar11,
               (*(int *)(param_1 + 0x144) - *piVar1) / 0xc);
  uStack_8 = 3;
  FUN_0152dda0(uVar7,uVar8,uVar13);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12396 ; VA 0x00808f30 ; FUN_00808f30 */

int FUN_00808f30(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b4ed0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iVar3 = (**(code **)(param_1 + 0x18))();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 12397 ; VA 0x00808fc0 ; FUN_00808fc0 */

int * __thiscall FUN_00808fc0(int param_1,longlong *param_2,int param_3)

{
  uint *puVar1;
  byte bVar2;
  int iVar3;
  byte bVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  undefined8 uStack_10;
  int iStack_8;
  
  iVar6 = 0xd0;
  iStack_8 = *(int *)(param_2 + 1);
  puVar1 = (uint *)((int)&uStack_10 + param_3 * 4);
  uStack_10 = *param_2;
  bVar2 = *(byte *)((int)param_2 + 0xc);
  *puVar1 = *puVar1 + (*puVar1 & 1) * 2 + -1;
  if ((int)uStack_10 < 0) {
    iVar6 = 0xe0;
  }
  iVar5 = 0;
  if (uStack_10 < 0) {
    iVar5 = 8;
  }
  iVar3 = 0;
  if (iStack_8 < 0) {
    iVar3 = 4;
  }
  piVar7 = *(int **)(iVar3 + iVar5 + param_1 + iVar6);
  if ((piVar7 != (int *)0x0) && (bVar2 <= *(byte *)(piVar7 + 3))) {
    bVar4 = *(byte *)(piVar7 + 3) - bVar2;
    if (((int)uStack_10 >> (bVar4 & 0x1f) == *piVar7) &&
       ((uStack_10._4_4_ >> (bVar4 & 0x1f) == piVar7[1] && (iStack_8 >> (bVar4 & 0x1f) == piVar7[2])
        ))) {
      do {
        if (*(char *)((int)piVar7 + 0x12) != '\0') {
          return piVar7;
        }
        if (*(byte *)(piVar7 + 3) == bVar2) {
          return (int *)0x0;
        }
        bVar4 = (*(byte *)(piVar7 + 3) - bVar2) - 1;
        piVar7 = (int *)piVar7[(iStack_8 >> (bVar4 & 0x1f) & 1U) +
                               ((uStack_10._4_4_ >> (bVar4 & 0x1f) & 1U) +
                               ((int)uStack_10 >> (bVar4 & 0x1f) & 1U) * 2) * 2 + 7];
      } while (piVar7 != (int *)0x0);
    }
  }
  return (int *)0x0;
}



/* FUNCTION 12398 ; VA 0x008090b0 ; FUN_008090b0 */

int * __thiscall FUN_008090b0(int param_1,int *param_2,uint param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  byte bVar4;
  int *piVar5;
  
  iVar1 = param_2[1];
  iVar2 = *param_2;
  iVar3 = param_2[2];
  piVar5 = *(int **)(param_1 +
                    (((0x1a - (iVar1 >> 0x1f)) + (iVar2 >> 0x1f) * -2) * 2 - (iVar3 >> 0x1f)) * 4);
  if (piVar5 != (int *)0x0) {
    if ((int)param_3 <= (int)(uint)*(byte *)(piVar5 + 3)) {
      bVar4 = *(byte *)(piVar5 + 3) - (char)param_3;
      if (((iVar2 >> (bVar4 & 0x1f) == *piVar5) && (iVar1 >> (bVar4 & 0x1f) == piVar5[1])) &&
         (iVar3 >> (bVar4 & 0x1f) == piVar5[2])) {
        do {
          if (*(byte *)(piVar5 + 3) == param_3) {
            return piVar5;
          }
          bVar4 = (*(byte *)(piVar5 + 3) - (char)param_3) - 1;
          piVar5 = (int *)piVar5[(iVar3 >> (bVar4 & 0x1f) & 1U) +
                                 ((iVar1 >> (bVar4 & 0x1f) & 1U) +
                                 (iVar2 >> (bVar4 & 0x1f) & 1U) * 2) * 2 + 7];
        } while (piVar5 != (int *)0x0);
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 12399 ; VA 0x00809160 ; FUN_00809160 */

byte __fastcall FUN_00809160(int param_1)

{
  byte bVar1;
  byte bVar2;
  
  bVar1 = *(byte *)(param_1 + 0xc);
  if (*(int *)(param_1 + 0x18) != 0) {
    bVar2 = *(byte *)(*(int *)(param_1 + 0x18) + 0xd);
    if (bVar2 <= bVar1) {
      bVar2 = bVar1;
    }
    return bVar2;
  }
  bVar2 = *(byte *)(param_1 + 0xd);
  if (*(byte *)(param_1 + 0xd) <= bVar1) {
    bVar2 = bVar1;
  }
  return bVar2;
}



/* FUNCTION 12400 ; VA 0x00809190 ; FUN_00809190 */

undefined4 __thiscall FUN_00809190(int param_1,undefined4 param_2)

{
  byte bVar1;
  
  if (*(int *)(param_1 + 0x18) == 0) {
    bVar1 = *(byte *)(param_1 + 0xd);
  }
  else {
    bVar1 = *(byte *)(*(int *)(param_1 + 0x18) + 0xd);
  }
  if (bVar1 <= *(byte *)(param_1 + 0xc)) {
    bVar1 = *(byte *)(param_1 + 0xc);
  }
  FUN_00a70570(param_2,2 << (bVar1 & 0x1f));
  return param_2;
}



/* FUNCTION 12401 ; VA 0x00809230 ; FUN_00809230 */

undefined8 * __thiscall FUN_00809230(int *param_1,undefined8 *param_2)

{
  byte bVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  
  bVar1 = *(char *)(param_1 + 3) + 4;
  iVar4 = *param_1 << (bVar1 & 0x1f);
  iVar5 = param_1[1] << (bVar1 & 0x1f);
  iVar3 = param_1[2] << (bVar1 & 0x1f);
  iVar2 = 1 << (bVar1 & 0x1f);
  fVar6 = (float)(iVar3 + iVar2) * DAT_018e3f8c;
  fVar9 = (float)(iVar4 + iVar2) * DAT_018e3f8c;
  fVar8 = (float)(iVar5 + iVar2) * DAT_018e3f8c;
  fVar7 = (float)iVar3 * DAT_018e3f8c;
  *param_2 = CONCAT44((float)iVar5 * DAT_018e3f8c,(float)iVar4 * DAT_018e3f8c);
  *(float *)(param_2 + 1) = fVar7;
  *(ulonglong *)((int)param_2 + 0xc) = CONCAT44(fVar8,fVar9);
  *(float *)((int)param_2 + 0x14) = fVar6;
  return param_2;
}



/* FUNCTION 12402 ; VA 0x008092e0 ; FUN_008092e0 */

undefined4 *
FUN_008092e0(undefined4 *param_1,int param_2,undefined param_3,undefined param_4,undefined param_5,
            undefined param_6)

{
  code *pcVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar3 = param_2;
  puStack_c = &LAB_017b4ef9;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = (**(code **)(**(int **)(param_2 + 0x3c) + 0x40))();
  iVar3 = (**(code **)(**(int **)(iVar3 + 0x3c) + 0x40))();
  uVar4 = 0;
  if (*(char *)(iVar3 + 0x19) != '\0') {
    uVar4 = 3;
  }
  FUN_0147c150(param_1,uVar4,3,1,1,1,1,1,5);
  param_2._0_3_ = CONCAT12(param_5,CONCAT11(param_4,param_3));
  param_2 = CONCAT13(param_6,(undefined3)param_2);
  uStack_8 = 0;
  if (*(char *)(iVar2 + 0x38) != '\0') {
    param_2 = CONCAT31(param_2._1_3_,param_5);
    param_2._0_3_ = CONCAT12(param_3,(undefined2)param_2);
    param_2 = CONCAT13(param_6,(undefined3)param_2);
  }
  pcVar1 = *(code **)(*(int *)*param_1 + 0x10);
  uVar4 = FUN_0147ce60(0,0,1,1);
  (*pcVar1)(0,0,uVar4,&param_2,4);
  (**(code **)(*(int *)*param_1 + 0x2c))();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12403 ; VA 0x008093c0 ; FUN_008093c0 */

int * __thiscall FUN_008093c0(int param_1,int *param_2,int param_3)

{
  int iVar1;
  uint *puVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  byte bVar7;
  byte bVar8;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b4f46;
  pvStack_10 = ExceptionList;
  piVar6 = (int *)(param_1 +
                  (((0x1a - (param_2[1] >> 0x1f)) + (*param_2 >> 0x1f) * -2) * 2 -
                  (param_2[2] >> 0x1f)) * 4);
  piVar4 = (int *)*piVar6;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  piStack_14 = piVar4;
  if (piVar4 == (int *)0x0) {
    ExceptionList = &pvStack_10;
    iStack_1c = FUN_01674e20(0xb0);
    uStack_8 = 0;
    if (iStack_1c == 0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4 = (int *)FUN_00806f60(param_2,param_3,*(undefined *)(iStack_18 + 0x2c));
    }
    iVar1 = *piVar6;
    uStack_8 = 0xffffffff;
    *piVar6 = (int)piVar4;
    piStack_14 = piVar4;
    if (iVar1 != 0) {
      FUN_00808350(iVar1);
      piVar4 = (int *)*piVar6;
      piStack_14 = piVar4;
    }
  }
  do {
    if (param_3 <= (int)(uint)*(byte *)(piVar4 + 3)) {
      bVar7 = *(byte *)(piVar4 + 3) - (char)param_3;
      if (((*param_2 >> (bVar7 & 0x1f) == *piVar4) && (param_2[1] >> (bVar7 & 0x1f) == piVar4[1]))
         && (param_2[2] >> (bVar7 & 0x1f) == piVar4[2])) {
        if ((DAT_01d61f54 != '\0') && (piStack_14 != piVar4)) {
          FUN_0080d9b0(piStack_14);
          piVar4 = (int *)*piVar6;
        }
        bVar7 = *(byte *)(piVar4 + 3);
        while (param_3 < (int)(uint)bVar7) {
          bVar8 = (char)(bVar7 - 1) - (char)param_3;
          uStack_28 = *param_2 >> (bVar8 & 0x1f);
          uStack_24 = param_2[1] >> (bVar8 & 0x1f);
          uStack_20 = param_2[2] >> (bVar8 & 0x1f);
          iVar1 = (uStack_20 & 1) + ((uStack_24 & 1) + (uStack_28 & 1) * 2) * 2;
          piVar6 = (int *)piVar4[iVar1 + 7];
          if (piVar6 == (int *)0x0) {
            iStack_1c = FUN_01674e20(0xb0);
            uStack_8 = 2;
            if (iStack_1c == 0) {
              iVar5 = 0;
            }
            else {
              iVar5 = FUN_00806f60(&uStack_28,bVar7 - 1,*(undefined *)(iStack_18 + 0x2c));
            }
            iVar3 = piVar4[iVar1 + 7];
            uStack_8 = 0xffffffff;
            piVar4[iVar1 + 7] = iVar5;
            if (iVar3 != 0) {
              FUN_00808350(iVar3);
              iVar5 = piVar4[iVar1 + 7];
            }
            *(int **)(iVar5 + 0x18) = piVar4;
            piVar6 = (int *)piVar4[iVar1 + 7];
          }
          piVar4 = piVar6;
          bVar7 = *(byte *)(piVar6 + 3);
        }
        ExceptionList = pvStack_10;
        return piVar4;
      }
    }
    iStack_1c = FUN_01674e20(0xb0);
    uStack_8 = 1;
    if (iStack_1c == 0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4 = (int *)*piVar6;
      uStack_28 = *piVar4 >> 1;
      uStack_24 = piVar4[1] >> 1;
      uStack_20 = piVar4[2] >> 1;
      piVar4 = (int *)FUN_00806f60(&uStack_28,*(byte *)(piVar4 + 3) + 1,
                                   *(undefined *)(iStack_18 + 0x2c));
    }
    uStack_8 = 0xffffffff;
    *(int **)(*piVar6 + 0x18) = piVar4;
    puVar2 = (uint *)*piVar6;
    iVar1 = (puVar2[2] & 1) + ((puVar2[1] & 1) + (*puVar2 & 1) * 2) * 2;
    iVar5 = piVar4[iVar1 + 7];
    piVar4[iVar1 + 7] = (int)puVar2;
    *piVar6 = (int)piVar4;
    if (iVar5 != 0) {
      FUN_00808350(iVar5);
      piVar4 = (int *)*piVar6;
    }
  } while( true );
}



/* FUNCTION 12404 ; VA 0x00809610 ; FUN_00809610 */

undefined4 * __fastcall FUN_00809610(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa8df;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x68) == 0) {
    ExceptionList = &pvStack_10;
    iVar3 = FUN_01674e20(0x28);
    uStack_8 = 0;
    if (iVar3 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_0078dea0();
    }
    uStack_8 = 0xffffffff;
    FUN_0075cd20(uVar4,0);
    *(undefined4 *)(param_1 + 0x68) = 0;
    piVar2 = *(int **)(param_1 + 0x6c);
    *(undefined4 *)(param_1 + 0x6c) = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_00810240();
    FUN_0080e610();
  }
  ExceptionList = pvStack_10;
  return (undefined4 *)(param_1 + 0x68);
}



/* FUNCTION 12405 ; VA 0x008096e0 ; FUN_008096e0 */

undefined4 __thiscall FUN_008096e0(int param_1,undefined4 param_2)

{
  FUN_00a70570(param_2,2 << (*(byte *)(param_1 + 0xc) & 0x1f));
  return param_2;
}



/* FUNCTION 12406 ; VA 0x00809760 ; FUN_00809760 */

int __thiscall FUN_00809760(int param_1,byte param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (*(int *)(param_1 + 0x50) == 0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb3810) {
      FUN_016f3809(&DAT_01eb3810);
      if (DAT_01eb3810 == -1) {
        FUN_0147c5c0(0,0,5,0,0);
        FUN_0147c5c0(0,8,6,1,0);
        FUN_0147c5c0(0,0xc,6,3,0);
        FUN_0147c5c0(0,0x10,6,3,1);
        FUN_016f37bf(&DAT_01eb3810);
      }
    }
    puVar6 = (undefined4 *)FUN_0147c1b0(auStack_c,&DAT_01eb37c0,4,0x14);
    uVar2 = *puVar6;
    uVar3 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x50) = uVar2;
    piVar4 = *(int **)(param_1 + 0x54);
    *(undefined4 *)(param_1 + 0x54) = uVar3;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    piVar4 = piStack_8;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_8[1] + -1;
      piStack_8[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  if (*(int *)(param_1 + 0x60) == 0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb3828) {
      FUN_016f3809(&DAT_01eb3828);
      if (DAT_01eb3828 == -1) {
        FUN_0147c5c0(0,0,5,0,0);
        FUN_016f37bf(&DAT_01eb3828);
      }
    }
    puVar6 = (undefined4 *)FUN_0147c1b0(auStack_c,&DAT_01eb3814,1,8);
    uVar2 = *puVar6;
    uVar3 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x60) = uVar2;
    piVar4 = *(int **)(param_1 + 100);
    *(undefined4 *)(param_1 + 100) = uVar3;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_8[1] + -1;
      piStack_8[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar4 = piStack_8 + 2;
        iVar5 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  return (param_2 + 5) * 0x10 + param_1;
}



/* FUNCTION 12407 ; VA 0x00809990 ; FUN_00809990 */

void FUN_00809990(undefined4 param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined auStack_10 [12];
  
  uVar2 = 0;
  uVar1 = FUN_011658d0(auStack_10);
  FUN_00841650(param_1,uVar1,uVar2);
  return;
}



/* FUNCTION 12408 ; VA 0x008099c0 ; FUN_008099c0 */

void __thiscall FUN_008099c0(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x148);
  *param_2 = *(undefined8 *)(param_1 + 0x140);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 12409 ; VA 0x008099e0 ; FUN_008099e0 */

int __fastcall FUN_008099e0(int param_1)

{
  int iVar1;
  int iVar2;
  void **ppvVar3;
  char cVar4;
  undefined4 *puVar5;
  int *piVar6;
  undefined4 uVar7;
  char *pcVar8;
  uint uVar9;
  uint uVar10;
  int *piVar11;
  char acStack_19c [256];
  uint auStack_9c [4];
  undefined4 uStack_8c;
  uint uStack_88;
  undefined auStack_84 [4];
  uint auStack_80 [4];
  undefined4 uStack_70;
  uint uStack_6c;
  uint uStack_68;
  undefined4 uStack_58;
  uint uStack_54;
  uint uStack_50;
  undefined4 uStack_40;
  uint uStack_3c;
  int iStack_34;
  int *piStack_30;
  char *pcStack_2c;
  undefined4 uStack_28;
  char *pcStack_24;
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b4fed;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x70) == 0) {
    piVar11 = (int *)(param_1 + 0x150);
    piStack_14 = (int *)0x0;
    ExceptionList = &pvStack_10;
    do {
      puVar5 = &DAT_01d61f64;
      if (0xf < DAT_01d61f78) {
        puVar5 = DAT_01d61f64;
      }
      piStack_14 = (int *)((int)piStack_14 + 1);
      piStack_30 = piVar11;
      FUN_005bde90(acStack_19c,"rbxasset://textures/water/normal_%02d%s",piStack_14,puVar5);
      iStack_1c = *(int *)(*(int *)(param_1 + 0x20) + 0x4ec);
      uStack_70 = 0;
      uStack_6c = 0xf;
      auStack_80[0] = auStack_80[0] & 0xffffff00;
      uStack_58 = 0;
      uStack_54 = 0xf;
      uStack_68 = uStack_68 & 0xffffff00;
      uStack_40 = 0;
      uStack_3c = 0xf;
      uStack_50 = uStack_50 & 0xffffff00;
      pcVar8 = acStack_19c;
      uStack_8 = 0;
      uStack_8c = 0;
      uStack_88 = 0xf;
      auStack_9c[0] = auStack_9c[0] & 0xffffff00;
      do {
        cVar4 = *pcVar8;
        pcVar8 = pcVar8 + 1;
      } while (cVar4 != '\0');
      FUN_005542c0(acStack_19c,(int)pcVar8 - (int)(acStack_19c + 1));
      uStack_8._0_1_ = 1;
      FUN_009cbbb0(auStack_9c);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      piVar6 = (int *)FUN_00782480(&pcStack_24,auStack_9c,5,auStack_80,0x425c0000,0);
      iVar1 = *piVar6;
      iVar2 = piVar6[1];
      *piVar6 = 0;
      piVar6[1] = 0;
      piVar11[-1] = iVar1;
      piVar11 = (int *)*piVar11;
      *piStack_30 = iVar2;
      if (piVar11 != (int *)0x0) {
        LOCK();
        iVar1 = piVar11[1] + -1;
        piVar11[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar11)();
          LOCK();
          iVar1 = piVar11[2] + -1;
          piVar11[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar11 + 4))();
          }
        }
      }
      piVar11 = piStack_20;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_20[1] + -1;
        piStack_20[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar6 = piVar11 + 2;
          iVar1 = *piVar6 + -1;
          *piVar6 = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar11 + 4))();
          }
        }
      }
      uStack_8 = uStack_8 & 0xffffff00;
      if (0xf < uStack_88) {
        uVar10 = uStack_88 + 1;
        uVar9 = auStack_9c[0];
        if (0xfff < uVar10) {
          uVar9 = *(uint *)(auStack_9c[0] - 4);
          uVar10 = uStack_88 + 0x24;
          if (0x1f < (auStack_9c[0] - uVar9) - 4) goto LAB_0080a397;
        }
        FUN_01674ea0(uVar9,uVar10);
      }
      uStack_8c = 0;
      uStack_88 = 0xf;
      auStack_9c[0] = auStack_9c[0] & 0xffffff00;
      uStack_8 = 0xffffffff;
      if (0xf < uStack_3c) {
        uVar10 = uStack_3c + 1;
        uVar9 = uStack_50;
        if (0xfff < uVar10) {
          uVar9 = *(uint *)(uStack_50 - 4);
          uVar10 = uStack_3c + 0x24;
          if (0x1f < (uStack_50 - uVar9) - 4) goto LAB_0080a397;
        }
        FUN_01674ea0(uVar9,uVar10);
      }
      uStack_40 = 0;
      uStack_3c = 0xf;
      uStack_50 = uStack_50 & 0xffffff00;
      if (0xf < uStack_54) {
        uVar10 = uStack_54 + 1;
        uVar9 = uStack_68;
        if (0xfff < uVar10) {
          uVar9 = *(uint *)(uStack_68 - 4);
          uVar10 = uStack_54 + 0x24;
          if (0x1f < (uStack_68 - uVar9) - 4) goto LAB_0080a397;
        }
        FUN_01674ea0(uVar9,uVar10);
      }
      uStack_58 = 0;
      uStack_54 = 0xf;
      uStack_68 = uStack_68 & 0xffffff00;
      if (0xf < uStack_6c) {
        uVar10 = uStack_6c + 1;
        uVar9 = auStack_80[0];
        if (0xfff < uVar10) {
          uVar9 = *(uint *)(auStack_80[0] - 4);
          uVar10 = uStack_6c + 0x24;
          if (0x1f < (auStack_80[0] - uVar9) - 4) {
LAB_0080a397:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar9,uVar10);
      }
      piVar11 = piStack_30 + 2;
    } while (piStack_14 < 0x19);
    piStack_30 = piVar11;
    piStack_14 = (int *)FUN_01674e20(0x28);
    uStack_8 = 3;
    if (piStack_14 == (int *)0x0) {
      uVar7 = 0;
    }
    else {
      uVar7 = FUN_0078dea0();
    }
    piStack_14 = (int *)0x0;
    uStack_8 = 0xffffffff;
    iStack_18 = 0;
    FUN_0075cd20(uVar7,0);
    *(int *)(param_1 + 0x70) = iStack_18;
    piVar11 = *(int **)(param_1 + 0x74);
    *(int **)(param_1 + 0x74) = piStack_14;
    ppvVar3 = (void **)ExceptionList;
    if (piVar11 != (int *)0x0) {
      LOCK();
      iVar1 = piVar11[1] + -1;
      piVar11[1] = iVar1;
      UNLOCK();
      ppvVar3 = (void **)ExceptionList;
      if (iVar1 == 0) {
        (**(code **)*piVar11)();
        LOCK();
        iVar1 = piVar11[2] + -1;
        piVar11[2] = iVar1;
        UNLOCK();
        ppvVar3 = (void **)ExceptionList;
        if (iVar1 == 0) {
          (**(code **)(*piVar11 + 4))();
          ppvVar3 = (void **)ExceptionList;
        }
      }
    }
  }
  else {
    ppvVar3 = &pvStack_10;
    if (*(int *)(param_1 + 0x250) == *(int *)(*(int *)(param_1 + 0x20) + 0x5c4)) {
      return param_1 + 0x70;
    }
  }
  ExceptionList = ppvVar3;
  FUN_0078e420();
  if (DAT_01d61f4c != '\0') {
    piVar11 = *(int **)(param_1 + 0x70);
    piStack_30 = piVar11;
    if (DAT_01d60bc0 == '\0') {
      iVar1 = param_1 + 0x14c;
      FUN_00812db0(piVar11,*(undefined4 *)(param_1 + 0x20),iVar1,0,0);
      FUN_00812db0(piVar11,*(undefined4 *)(param_1 + 0x20),iVar1,0,1);
      FUN_00812db0(piVar11,*(undefined4 *)(param_1 + 0x20),iVar1,1,0);
      FUN_00812db0(piVar11,*(undefined4 *)(param_1 + 0x20),iVar1,1,1);
      cVar4 = FUN_0078ba00();
      if (cVar4 != '\0') {
        FUN_00812db0(piVar11,*(undefined4 *)(param_1 + 0x20),iVar1,2,0);
        FUN_00812db0(piVar11,*(undefined4 *)(param_1 + 0x20),iVar1,2,1);
      }
    }
    else {
      uVar7 = FUN_0078e450(*(undefined4 *)(*(int *)(param_1 + 0x20) + 0x5c4));
      FUN_00812db0(piStack_30,*(undefined4 *)(param_1 + 0x20),param_1 + 0x14c,uVar7,0);
      piVar11 = piStack_30;
      FUN_00812db0(piStack_30,*(undefined4 *)(param_1 + 0x20),param_1 + 0x14c,uVar7,1);
    }
    FUN_00812db0(piVar11,*(undefined4 *)(param_1 + 0x20),param_1 + 0x14c,0,2);
    goto LAB_0080a37c;
  }
  pcStack_2c = "SmoothWaterHQVS";
  uStack_28 = 0xf;
  pcStack_24 = "SmoothWaterSuperHQFS";
  piStack_20 = (int *)0x14;
  FUN_00790e00(&iStack_18,&pcStack_2c,2);
  uStack_8 = 4;
  if (iStack_18 != 0) {
    FUN_0078ded0(&iStack_18,0,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_0080bb60(*(undefined4 *)(param_1 + 0x20),auStack_84,param_1 + 0x14c,param_1 + 0x154,0);
    FUN_0078e040(auStack_84,0);
    FUN_0075e0c0();
  }
  piVar11 = piStack_14;
  uStack_8 = 0xffffffff;
  if (piStack_14 != (int *)0x0) {
    iStack_1c = param_1 + 0x154;
    LOCK();
    iVar1 = piStack_14[1] + -1;
    piStack_14[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_14)();
      iStack_1c = param_1 + 0x154;
      LOCK();
      piVar6 = piVar11 + 2;
      iVar1 = *piVar6 + -1;
      *piVar6 = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar11 + 4))();
      }
    }
  }
  iStack_1c = param_1 + 0x154;
  pcStack_2c = "SmoothWaterHQVS";
  uStack_28 = 0xf;
  pcStack_24 = "SmoothWaterHQFS";
  piStack_20 = (int *)0xf;
  FUN_00790e00(&iStack_18,&pcStack_2c,2);
  uStack_8 = 6;
  if (iStack_18 != 0) {
    FUN_0078ded0(&iStack_18,1,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_0080bb60(*(undefined4 *)(param_1 + 0x20),auStack_84,param_1 + 0x14c,param_1 + 0x154,0);
    FUN_0078e040(auStack_84,0);
    FUN_0075e0c0();
  }
  piVar11 = piStack_14;
  uStack_8 = 0xffffffff;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_14[1] + -1;
    piStack_14[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar6 = piVar11 + 2;
      iVar1 = *piVar6 + -1;
      *piVar6 = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar11 + 4))();
      }
    }
  }
  pcStack_2c = "SmoothWaterHQVSShadowed";
  uStack_28 = 0x17;
  pcStack_24 = "SmoothWaterSuperHQFSShadowed";
  piStack_20 = (int *)0x1c;
  FUN_00790e00(&iStack_18,&pcStack_2c,2);
  uStack_8 = 8;
  if (iStack_18 != 0) {
    FUN_0078ded0(&iStack_18,0,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_0080bb60(*(undefined4 *)(param_1 + 0x20),auStack_84,param_1 + 0x14c,iStack_1c,1);
    FUN_0078e040(auStack_84,1);
    FUN_0075e0c0();
  }
  piVar11 = piStack_14;
  uStack_8 = 0xffffffff;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_14[1] + -1;
    piStack_14[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar6 = piVar11 + 2;
      iVar1 = *piVar6 + -1;
      *piVar6 = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar11 + 4))();
      }
    }
  }
  pcStack_2c = "SmoothWaterHQVSShadowed";
  uStack_28 = 0x17;
  pcStack_24 = "SmoothWaterHQFSShadowed";
  piStack_20 = (int *)0x17;
  FUN_00790e00(&iStack_18,&pcStack_2c,2);
  uStack_8 = 10;
  if (iStack_18 == 0) {
    iStack_1c = param_1 + 0x154;
  }
  else {
    FUN_0078ded0(&iStack_18,1,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    FUN_0080bb60(*(undefined4 *)(param_1 + 0x20),auStack_84,param_1 + 0x14c,iStack_1c,1);
    FUN_0078e040(auStack_84,1);
    FUN_0075e0c0();
  }
  piVar11 = piStack_14;
  uStack_8 = 0xffffffff;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_14[1] + -1;
    piStack_14[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar6 = piVar11 + 2;
      iVar1 = *piVar6 + -1;
      *piVar6 = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar11 + 4))();
      }
    }
  }
  cVar4 = FUN_0078ba00();
  if (cVar4 != '\0') {
    pcStack_2c = "SmoothWaterHQVSShadowedFSM";
    uStack_28 = 0x1a;
    pcStack_24 = "SmoothWaterSuperHQFSShadowed";
    piStack_20 = (int *)0x1c;
    FUN_00790e00(&iStack_18,&pcStack_2c,2);
    uStack_8 = 0xc;
    if (iStack_18 != 0) {
      FUN_0078ded0(&iStack_18,0,0);
      uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
      FUN_0080bb60(*(undefined4 *)(param_1 + 0x20),auStack_84,param_1 + 0x14c,param_1 + 0x154,2);
      FUN_0078e040(auStack_84,2);
      FUN_0075e0c0();
    }
    piVar11 = piStack_14;
    uStack_8 = 0xffffffff;
    if (piStack_14 == (int *)0x0) {
LAB_0080a21a:
      piStack_30 = (int *)(param_1 + 0x14c);
    }
    else {
      piStack_30 = (int *)(param_1 + 0x14c);
      LOCK();
      iVar1 = piStack_14[1] + -1;
      piStack_14[1] = iVar1;
      UNLOCK();
      if (iVar1 != 0) goto LAB_0080a21a;
      (**(code **)*piStack_14)();
      piStack_30 = (int *)(param_1 + 0x14c);
      LOCK();
      piVar6 = piVar11 + 2;
      iVar1 = *piVar6 + -1;
      *piVar6 = iVar1;
      UNLOCK();
      if (iVar1 != 0) goto LAB_0080a21a;
      (**(code **)(*piVar11 + 4))();
    }
    pcStack_2c = "SmoothWaterHQVSShadowedFSM";
    uStack_28 = 0x1a;
    pcStack_24 = "SmoothWaterHQFSShadowedFSM";
    piStack_20 = (int *)0x1a;
    FUN_00790e00(&iStack_18,&pcStack_2c,2);
    uStack_8 = 0xe;
    if (iStack_18 != 0) {
      FUN_0078ded0(&iStack_18,1,0);
      uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
      FUN_0080bb60(*(undefined4 *)(param_1 + 0x20),auStack_84,param_1 + 0x14c,iStack_1c,2);
      FUN_0078e040(auStack_84,2);
      FUN_0075e0c0();
    }
    piVar11 = piStack_14;
    uStack_8 = 0xffffffff;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_14[1] + -1;
      piStack_14[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar6 = piVar11 + 2;
        iVar1 = *piVar6 + -1;
        *piVar6 = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar11 + 4))();
        }
      }
    }
  }
  pcStack_2c = "SmoothWaterVS";
  uStack_28 = 0xd;
  pcStack_24 = "SmoothWaterFS";
  piStack_20 = (int *)&DAT_0000000d;
  FUN_00790e00(&iStack_34,&pcStack_2c,2);
  uStack_8 = 0x10;
  if (iStack_34 != 0) {
    FUN_0078ded0(&iStack_34,2,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
    FUN_0080bb60(*(undefined4 *)(param_1 + 0x20),auStack_84,param_1 + 0x14c,iStack_1c,0);
    FUN_0078e040(auStack_84,0);
    FUN_0075e0c0();
  }
  piVar11 = piStack_30;
  uStack_8 = 0xffffffff;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_30[1] + -1;
    piStack_30[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar6 = piVar11 + 2;
      iVar1 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*piVar11 + 4))();
      }
    }
  }
LAB_0080a37c:
  FUN_0080e610();
  ExceptionList = pvStack_10;
  return param_1 + 0x70;
}



/* FUNCTION 12410 ; VA 0x0080a3c0 ; FUN_0080a3c0 */

float10 __fastcall FUN_0080a3c0(int param_1)

{
  return (float10)*(float *)(param_1 + 0x154);
}



/* FUNCTION 12411 ; VA 0x0080a3e0 ; FUN_0080a3e0 */

undefined4 FUN_0080a3e0(int param_1)

{
  int iVar1;
  char cVar2;
  uint uVar3;
  
  uVar3 = 0;
  do {
    iVar1 = *(int *)(param_1 + 0x1c +
                    (((int)uVar3 >> 2 & 1U) + (((int)uVar3 >> 1 & 1U) + (uVar3 & 1) * 2) * 2) * 4);
    if (iVar1 != 0) {
      if (*(char *)(iVar1 + 0x12) == '\0') {
        cVar2 = FUN_0080a3e0(iVar1);
        if (cVar2 != '\0') {
          return 1;
        }
      }
      else if ((*(uint *)(iVar1 + 0x68) & 0x800000) == 0) {
        return 1;
      }
    }
    uVar3 = uVar3 + 1;
  } while ((int)uVar3 < 8);
  return 0;
}



/* FUNCTION 12412 ; VA 0x0080a450 ; FUN_0080a450 */

int * __thiscall FUN_0080a450(int *param_1,int *param_2)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  
  uVar3 = (param_1[1] - *param_1) / 0xc - 1;
  uVar2 = FUN_00a6ce70(param_2);
  uVar5 = 0;
  while( true ) {
    uVar2 = uVar2 & uVar3;
    iVar4 = *(int *)(*param_1 + uVar2 * 0xc);
    piVar1 = (int *)(*param_1 + uVar2 * 0xc);
    if (((iVar4 == param_1[4]) && (piVar1[1] == param_1[5])) &&
       (iVar4 = *piVar1, piVar1[2] == param_1[6])) {
      *(undefined8 *)piVar1 = *(undefined8 *)param_2;
      piVar1[2] = param_2[2];
      param_1[3] = param_1[3] + 1;
      return piVar1;
    }
    if (((iVar4 == *param_2) && (piVar1[1] == param_2[1])) && (piVar1[2] == param_2[2])) break;
    uVar2 = uVar2 + 1 + uVar5;
    uVar5 = uVar5 + 1;
    if (uVar3 < uVar5) {
      return (int *)0x0;
    }
  }
  return piVar1;
}



/* FUNCTION 12413 ; VA 0x0080a510 ; FUN_0080a510 */

undefined FUN_0080a510(float *param_1,int param_2,float param_3,float param_4,float param_5)

{
  char cVar1;
  int iVar2;
  int iVar3;
  float fVar4;
  double dVar5;
  float fVar6;
  float fVar7;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  fVar6 = param_1[2];
  fStack_c = (*param_1 - 0.0) * DAT_018e1340;
  dVar5 = (double)((fVar6 - *param_1) * param_3 - param_4);
  FUN_01728390();
  fStack_8 = (float)dVar5;
  dVar5 = (double)((*param_1 + fVar6) * param_3 + param_4);
  FUN_01728390();
  iVar3 = -1;
  fVar7 = (param_1[1] - (fStack_8 + (float)dVar5) * param_5) * DAT_018e1340;
  fVar6 = (fVar6 - 0.0) * DAT_018e1340;
  do {
    iVar2 = -1;
    fVar4 = (float)iVar3 * DAT_018ce2f4 + fStack_c;
    do {
      fStack_10 = (float)iVar2 * DAT_018ce2f4 + fVar6;
      fStack_18 = fVar4;
      fStack_14 = fVar7;
      cVar1 = FUN_00afc990(&fStack_18,*(undefined4 *)(param_2 + 0x134),&param_5);
      if (cVar1 != '\0') {
        return 1;
      }
      iVar2 = iVar2 + 1;
    } while (iVar2 < 2);
    iVar3 = iVar3 + 1;
  } while (iVar3 < 2);
  return 0;
}



/* FUNCTION 12414 ; VA 0x0080a660 ; FUN_0080a660 */

void __thiscall FUN_0080a660(int param_1,int param_2,char param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b500f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(char *)(param_2 + 0x12) = param_3;
  if (param_3 != '\0') {
    if (*(int *)(param_2 + 0x3c) == 0) {
      puVar2 = (undefined4 *)FUN_01674e20(0x3c);
      uStack_8 = 0;
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        FUN_00841020(*(undefined4 *)(param_1 + 0x20),4);
        *puVar2 = RBX::Graphics::SmoothCluster::ChunkRenderNode::vftable;
        puVar2[0xe] = param_2;
      }
      puVar1 = *(undefined4 **)(param_2 + 0x3c);
      uStack_8 = 0xffffffff;
      *(undefined4 **)(param_2 + 0x3c) = puVar2;
      if (puVar1 != (undefined4 *)0x0) {
        (**(code **)*puVar1)(1);
      }
    }
    FUN_008411b0(param_2 + 0x94,*(undefined4 *)(*(int *)(*(int *)(param_1 + 0x20) + 0x4e4) + 0x24));
    ExceptionList = pvStack_10;
    return;
  }
  puVar2 = *(undefined4 **)(param_2 + 0x3c);
  *(undefined4 *)(param_2 + 0x3c) = 0;
  if (puVar2 != (undefined4 *)0x0) {
    (**(code **)*puVar2)(1);
  }
  puVar2 = (undefined4 *)(param_2 + 0x40);
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  if (&uStack_1c != puVar2) {
    uStack_1c = *puVar2;
    *puVar2 = 0;
    uStack_18 = *(undefined4 *)(param_2 + 0x44);
    *(undefined4 *)(param_2 + 0x44) = 0;
    uStack_14 = *(undefined4 *)(param_2 + 0x48);
    *(undefined4 *)(param_2 + 0x48) = 0;
  }
  FUN_00617ad0();
  *(uint *)(param_2 + 0x68) = *(uint *)(param_2 + 0x68) | 0xffffff;
  puVar2 = *(undefined4 **)(param_2 + 0x6c);
  *(undefined4 *)(param_2 + 0x6c) = 0;
  if (puVar2 != (undefined4 *)0x0) {
    (**(code **)*puVar2)(1);
  }
  puVar2 = *(undefined4 **)(param_2 + 0x70);
  *(undefined4 *)(param_2 + 0x70) = 0;
  if (puVar2 != (undefined4 *)0x0) {
    (**(code **)*puVar2)(1);
  }
  puVar2 = *(undefined4 **)(param_2 + 0x74);
  *(undefined4 *)(param_2 + 0x74) = 0;
  if (puVar2 != (undefined4 *)0x0) {
    (**(code **)*puVar2)(1);
  }
  puVar2 = *(undefined4 **)(param_2 + 0x78);
  *(undefined4 *)(param_2 + 0x78) = 0;
  if (puVar2 != (undefined4 *)0x0) {
    (**(code **)*puVar2)(1);
  }
  *(undefined *)(param_2 + 0x6b) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12415 ; VA 0x0080a7e0 ; FUN_0080a7e0 */

void __fastcall FUN_0080a7e0(int param_1)

{
  undefined8 uVar1;
  int iVar2;
  undefined8 uStack_48;
  int iStack_40;
  undefined8 uStack_3c;
  int iStack_34;
  undefined auStack_30 [12];
  undefined8 uStack_24;
  undefined8 *puStack_18;
  undefined8 uStack_14;
  int iStack_c;
  int iStack_8;
  
  iStack_8 = param_1;
  FUN_00a70570(auStack_30,2);
  FUN_00a70da0(&uStack_48,4);
  puStack_18 = &uStack_48;
  uStack_14 = uStack_48;
  uStack_24 = uStack_3c;
  uVar1 = uStack_24;
  uStack_24._4_4_ = (int)((ulonglong)uStack_3c >> 0x20);
  iVar2 = uStack_24._4_4_;
  iStack_c = iStack_40;
  uStack_24 = uVar1;
  while ((((int)uStack_14 != (int)uStack_24 || (uStack_14._4_4_ != iVar2)) ||
         (iStack_c != iStack_34))) {
    if ((uint)(((*(int *)(param_1 + 0xd8) - *(int *)(param_1 + 0xd4)) / 0xc) * 3) >> 2 <=
        *(uint *)(param_1 + 0xe0)) {
      FUN_0080ae60();
    }
    FUN_0080a450(&uStack_14);
    FUN_00a6e100();
    param_1 = iStack_8;
  }
  return;
}



/* FUNCTION 12416 ; VA 0x0080a8a0 ; FUN_0080a8a0 */

void __thiscall FUN_0080a8a0(int param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  
  puVar1 = *(undefined8 **)(param_1 + 4);
  if (*(undefined8 **)(param_1 + 8) != puVar1) {
    *puVar1 = *param_2;
    *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_2 + 1);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0xc;
    return;
  }
  FUN_008059a0(puVar1,param_2);
  return;
}



/* FUNCTION 12417 ; VA 0x0080a8e0 ; FUN_0080a8e0 */

undefined4 * __thiscall FUN_0080a8e0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5028;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)param_2[1];
  ExceptionList = &pvStack_10;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piStack_18[1] = piStack_18[1] + 1;
    UNLOCK();
    piStack_18 = (int *)param_2[1];
  }
  uStack_1c = *param_2;
  uStack_14 = 0;
  puVar4 = *(undefined4 **)(param_1 + 0x144);
  uStack_8 = 0;
  if (*(undefined4 **)(param_1 + 0x148) == puVar4) {
    puVar4 = (undefined4 *)FUN_00805400(puVar4,&uStack_1c);
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    *puVar4 = uStack_1c;
    puVar4[1] = piStack_18;
    puVar4[2] = 0;
    *(int *)(param_1 + 0x144) = *(int *)(param_1 + 0x144) + 0xc;
  }
  piVar3 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    puVar4 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puVar4 = (undefined4 *)(**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puVar4 = (undefined4 *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 12418 ; VA 0x0080a9a0 ; FUN_0080a9a0 */

void __thiscall FUN_0080a9a0(int param_1,int param_2,float param_3)

{
  int *piVar1;
  uint uVar2;
  undefined uVar3;
  int iStack_c;
  float fStack_8;
  
  if ((*(uint *)(param_2 + 0x68) & 0x800000) != 0) {
    iStack_c = param_2;
    piVar1 = *(int **)(param_1 + 0x114);
    fStack_8 = param_3 - (float)*(byte *)(param_2 + 0x14) * DAT_018fde94;
    if (*(int **)(param_1 + 0x118) == piVar1) {
      FUN_00805800(piVar1,&iStack_c);
    }
    else {
      *piVar1 = param_2;
      piVar1[1] = (int)fStack_8;
      *(int *)(param_1 + 0x114) = *(int *)(param_1 + 0x114) + 8;
    }
    uVar2 = *(byte *)(param_2 + 0x14) + 1;
    uVar3 = (undefined)uVar2;
    if (0xff < uVar2) {
      uVar3 = 0xff;
    }
    *(undefined *)(param_2 + 0x14) = uVar3;
  }
  return;
}



/* FUNCTION 12419 ; VA 0x0080aa20 ; FUN_0080aa20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0080aa20(int param_1,float param_2,float param_3)

{
  int iVar1;
  int iVar2;
  float *pfVar3;
  char cVar4;
  uint uVar5;
  undefined uVar6;
  double dVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  undefined8 uStack_14;
  float fStack_c;
  
  if ((*(uint *)((int)param_2 + 0x68) & 0x800000) != 0) {
    dVar7 = (double)param_3;
    FUN_017267a0();
    iVar1 = *(int *)(param_1 + 0x20);
    fStack_18 = (float)dVar7;
    cVar4 = FUN_007ccd20((int)param_2 + 0x94);
    if (cVar4 == '\0') {
      fStack_c = *(float *)(iVar1 + 0x58);
      uStack_14 = *(undefined8 *)(iVar1 + 0x50);
      iVar2 = *(int *)(param_1 + 0x20);
      fVar10 = (*(float *)((int)param_2 + 0x7c) + *(float *)((int)param_2 + 0x88)) * DAT_018ce2f4 -
               (*(float *)(iVar1 + 0x40) - *(float *)(iVar2 + 0x50) * DAT_01900a1c);
      fVar9 = (*(float *)((int)param_2 + 0x80) + *(float *)((int)param_2 + 0x8c)) * DAT_018ce2f4 -
              (*(float *)(iVar1 + 0x44) - *(float *)(iVar2 + 0x54) * DAT_01900a1c);
      fStack_20 = (*(float *)((int)param_2 + 0x84) + *(float *)((int)param_2 + 0x90)) * DAT_018ce2f4
                  - (*(float *)(iVar1 + 0x48) - *(float *)(iVar2 + 0x58) * DAT_01900a1c);
      dVar7 = (double)(fVar9 * fVar9 + fVar10 * fVar10 + fStack_20 * fStack_20);
      FUN_017267a0();
      fVar8 = DAT_018ce2f8 / (float)dVar7;
      fStack_1c = (float)(DAT_018c0d60 -
                         ((double)((uStack_14._4_4_ * fVar8 * fVar9 +
                                    (float)uStack_14 * fVar8 * fVar10 + fStack_c * fVar8 * fStack_20
                                   ) * DAT_018ce2f4) + _PTR_018cf0f8)) * _DAT_01901964;
    }
    else {
      fStack_1c = 0.0;
    }
    pfVar3 = *(float **)(param_1 + 0x114);
    fStack_20 = param_2;
    fStack_1c = (fStack_18 - (float)*(byte *)((int)param_2 + 0x14) * DAT_018fde94) + fStack_1c;
    if (*(float **)(param_1 + 0x118) == pfVar3) {
      FUN_00805800(pfVar3,&fStack_20);
    }
    else {
      *pfVar3 = param_2;
      pfVar3[1] = fStack_1c;
      *(int *)(param_1 + 0x114) = *(int *)(param_1 + 0x114) + 8;
    }
    uVar5 = *(byte *)((int)param_2 + 0x14) + 1;
    uVar6 = (undefined)uVar5;
    if (0xff < uVar5) {
      uVar6 = 0xff;
    }
    *(undefined *)((int)param_2 + 0x14) = uVar6;
  }
  return;
}



/* FUNCTION 12420 ; VA 0x0080ac40 ; FUN_0080ac40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0080ac40(int param_1,float param_2,float param_3)

{
  int iVar1;
  int iVar2;
  float *pfVar3;
  char cVar4;
  uint uVar5;
  undefined uVar6;
  double dVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  undefined8 uStack_14;
  float fStack_c;
  
  if (*(char *)((int)param_2 + 0x11) != '\0') {
    dVar7 = (double)param_3;
    FUN_017267a0();
    iVar1 = *(int *)(param_1 + 0x20);
    fStack_18 = (float)dVar7;
    cVar4 = FUN_007ccd20((int)param_2 + 0x94);
    if (cVar4 == '\0') {
      fStack_c = *(float *)(iVar1 + 0x58);
      uStack_14 = *(undefined8 *)(iVar1 + 0x50);
      iVar2 = *(int *)(param_1 + 0x20);
      fVar10 = (*(float *)((int)param_2 + 0x7c) + *(float *)((int)param_2 + 0x88)) * DAT_018ce2f4 -
               (*(float *)(iVar1 + 0x40) - *(float *)(iVar2 + 0x50) * DAT_01900a1c);
      fVar9 = (*(float *)((int)param_2 + 0x80) + *(float *)((int)param_2 + 0x8c)) * DAT_018ce2f4 -
              (*(float *)(iVar1 + 0x44) - *(float *)(iVar2 + 0x54) * DAT_01900a1c);
      fStack_20 = (*(float *)((int)param_2 + 0x84) + *(float *)((int)param_2 + 0x90)) * DAT_018ce2f4
                  - (*(float *)(iVar1 + 0x48) - *(float *)(iVar2 + 0x58) * DAT_01900a1c);
      dVar7 = (double)(fVar9 * fVar9 + fVar10 * fVar10 + fStack_20 * fStack_20);
      FUN_017267a0();
      fVar8 = DAT_018ce2f8 / (float)dVar7;
      fStack_1c = (float)(DAT_018c0d60 -
                         ((double)((uStack_14._4_4_ * fVar8 * fVar9 +
                                    (float)uStack_14 * fVar8 * fVar10 + fStack_c * fVar8 * fStack_20
                                   ) * DAT_018ce2f4) + _PTR_018cf0f8)) * _DAT_01901964;
    }
    else {
      fStack_1c = 0.0;
    }
    pfVar3 = *(float **)(param_1 + 0x114);
    fStack_20 = param_2;
    fStack_1c = (fStack_18 - (float)*(byte *)((int)param_2 + 0x13) * DAT_019011dc) + fStack_1c;
    if (*(float **)(param_1 + 0x118) == pfVar3) {
      FUN_00805800(pfVar3,&fStack_20);
    }
    else {
      *pfVar3 = param_2;
      pfVar3[1] = fStack_1c;
      *(int *)(param_1 + 0x114) = *(int *)(param_1 + 0x114) + 8;
    }
    uVar5 = *(byte *)((int)param_2 + 0x13) + 1;
    uVar6 = (undefined)uVar5;
    if (0xff < uVar5) {
      uVar6 = 0xff;
    }
    *(undefined *)((int)param_2 + 0x13) = uVar6;
  }
  return;
}



/* FUNCTION 12421 ; VA 0x0080ae60 ; FUN_0080ae60 */

void __fastcall FUN_0080ae60(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  int iStack_70;
  int iStack_6c;
  int iStack_68;
  int iStack_64;
  undefined8 uStack_60;
  int iStack_58;
  undefined8 uStack_50;
  int iStack_48;
  int iStack_40;
  uint uStack_38;
  int iStack_34;
  int iStack_30;
  uint uStack_2c;
  int *piStack_28;
  undefined uStack_21;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017b5048;
  pvStack_1c = ExceptionList;
  if (*param_1 == param_1[1]) {
    iVar6 = 0x10;
  }
  else {
    iVar6 = ((param_1[1] - *param_1) / 0xc) * 2;
  }
  iStack_48 = param_1[6];
  uStack_50 = *(undefined8 *)(param_1 + 4);
  ExceptionList = &pvStack_1c;
  piStack_28 = param_1;
  FUN_00806e90(iVar6,&uStack_50,&uStack_21);
  uStack_60 = *(undefined8 *)(param_1 + 4);
  iStack_58 = param_1[6];
  iStack_64 = 0;
  iVar6 = *param_1;
  uStack_2c = 0;
  uStack_14 = 0;
  iVar2 = param_1[1] - iVar6 >> 0x1f;
  iStack_34 = iStack_58;
  if ((param_1[1] - iVar6) / 0xc + iVar2 != iVar2) {
    iStack_30 = 0;
    do {
      piVar1 = (int *)(iStack_30 + iVar6);
      if (((*piVar1 != piStack_28[4]) || (piVar1[1] != piStack_28[5])) ||
         (piVar1[2] != piStack_28[6])) {
        iStack_40 = piVar1[2];
        uStack_50 = *(undefined8 *)piVar1;
        uVar7 = (iStack_6c - iStack_70) / 0xc - 1;
        uStack_38 = uVar7;
        uVar4 = FUN_00a6ce70(piVar1);
        uVar4 = uVar4 & uVar7;
        uVar7 = 0;
        do {
          piVar5 = (int *)(iStack_70 + uVar4 * 0xc);
          iVar6 = *piVar5;
          if (iVar6 == (int)uStack_60) {
            iVar6 = *piVar5;
            if ((piVar5[1] == uStack_60._4_4_) && (iVar6 = *piVar5, piVar5[2] == iStack_34)) {
              iStack_64 = iStack_64 + 1;
              *(undefined8 *)piVar5 = *(undefined8 *)piVar1;
              piVar5[2] = piVar1[2];
              goto LAB_0080afca;
            }
          }
          if (((iVar6 == *piVar1) && (piVar5[1] == piVar1[1])) && (piVar5[2] == piVar1[2]))
          goto LAB_0080afca;
          uVar4 = uVar4 + 1 + uVar7;
          uVar7 = uVar7 + 1;
          uVar4 = uVar4 & uStack_38;
        } while (uVar7 <= uStack_38);
        piVar5 = (int *)0x0;
LAB_0080afca:
        *(undefined8 *)piVar5 = uStack_50;
        piVar5[2] = iStack_40;
        iVar6 = *piStack_28;
      }
      iStack_30 = iStack_30 + 0xc;
      uStack_2c = uStack_2c + 1;
      param_1 = piStack_28;
    } while (uStack_2c < (uint)((piStack_28[1] - iVar6) / 0xc));
  }
  if (param_1 != &iStack_70) {
    *param_1 = iStack_70;
    iVar2 = param_1[1];
    param_1[1] = iStack_6c;
    iVar3 = param_1[2];
    param_1[2] = iStack_68;
    iStack_70 = iVar6;
    iStack_6c = iVar2;
    iStack_68 = iVar3;
  }
  FUN_00617ad0();
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 12422 ; VA 0x0080b070 ; FUN_0080b070 */

void __fastcall FUN_0080b070(int param_1)

{
  *(undefined4 *)(param_1 + 0x84) = *(undefined4 *)(*(int *)(param_1 + 4) + 0x13c);
  FUN_0080e610();
  return;
}



/* FUNCTION 12423 ; VA 0x0080b090 ; FUN_0080b090 */

void __thiscall FUN_0080b090(int param_1,int *param_2,int param_3,undefined4 param_4,int *param_5)

{
  undefined4 *puVar1;
  
  (**(code **)(*param_2 + 0x30))(1,param_1 + 0x50,0x10);
  puVar1 = *(undefined4 **)(param_3 + 8);
  (**(code **)(*param_2 + 0x40))(*puVar1,puVar1[2],puVar1[3],puVar1[4],puVar1[5],0);
  *param_5 = *param_5 + 1;
  param_5[1] = param_5[1] + *(int *)(*(int *)(param_3 + 8) + 0x14);
  param_5[2] = param_5[2] + 0x10;
  return;
}



/* FUNCTION 12424 ; VA 0x0080b0e0 ; FUN_0080b0e0 */

void __thiscall FUN_0080b0e0(uint *param_1,char param_2)

{
  undefined4 *puVar1;
  
  *param_1 = *param_1 | 0xffffff;
  puVar1 = (undefined4 *)param_1[1];
  param_1[1] = 0;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  puVar1 = (undefined4 *)param_1[2];
  param_1[2] = 0;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  if (param_2 != '\0') {
    puVar1 = (undefined4 *)param_1[3];
    param_1[3] = 0;
    if (puVar1 != (undefined4 *)0x0) {
      (**(code **)*puVar1)(1);
    }
    puVar1 = (undefined4 *)param_1[4];
    param_1[4] = 0;
    if (puVar1 != (undefined4 *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0080b147. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)*puVar1)();
      return;
    }
  }
  return;
}



/* FUNCTION 12425 ; VA 0x0080b150 ; FUN_0080b150 */

void __thiscall FUN_0080b150(int *param_1,int param_2,int param_3,int param_4,undefined2 *param_5)

{
  int iVar1;
  
  iVar1 = param_1[4];
  if (iVar1 == 0) {
    FUN_00a6e270();
    iVar1 = param_1[4];
  }
  *(undefined2 *)(iVar1 + (*param_1 * param_4 + param_1[3] * param_3 + param_2) * 2) = *param_5;
  return;
}



/* FUNCTION 12426 ; VA 0x0080b190 ; FUN_0080b190 */

void FUN_0080b190(void)

{
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined uStack_c;
  undefined2 uStack_7;
  undefined uStack_5;
  
  uStack_10 = 0x1000100;
  uStack_14 = 0;
  uStack_c = 0;
  FUN_0078e480(&uStack_14);
  uStack_7 = 0x104;
  uStack_5 = 0;
  FUN_0078e510(&uStack_7);
  return;
}



/* FUNCTION 12427 ; VA 0x0080b1d0 ; FUN_0080b1d0 */

int FUN_0080b1d0(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  undefined uVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 ****ppppuVar7;
  int iVar8;
  char *pcVar9;
  uint uVar10;
  uint uVar11;
  undefined auStack_150 [16];
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined uStack_138;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined uStack_120;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  uint uStack_104;
  undefined4 uStack_f4;
  uint uStack_f0;
  undefined auStack_ec [4];
  int *piStack_e8;
  undefined auStack_e4 [16];
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined uStack_cc;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined uStack_b4;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  uint uStack_98;
  undefined4 uStack_88;
  uint uStack_84;
  undefined auStack_80 [4];
  int *piStack_7c;
  undefined4 ***apppuStack_78 [4];
  int iStack_68;
  uint uStack_64;
  char acStack_60 [4];
  undefined4 uStack_5c;
  undefined2 uStack_58;
  int iStack_54;
  undefined auStack_50 [4];
  int *piStack_4c;
  undefined4 uStack_48;
  char acStack_44 [4];
  undefined4 uStack_40;
  int *piStack_3c;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  char acStack_1c [4];
  undefined4 uStack_18;
  undefined2 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b513a;
  pvStack_10 = ExceptionList;
  iStack_54 = *(int *)(param_1 + 0x4f8);
  uStack_48 = *(undefined4 *)(param_1 + 0x4ec);
  uStack_20 = 0x10400;
  ExceptionList = &pvStack_10;
  FUN_0078e510((int)&uStack_20 + 1);
  iVar8 = *param_2;
  iVar4 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
  pcVar9 = "array";
  if (*(char *)(iVar4 + 0x19) == '\0') {
    pcVar9 = "";
  }
  FUN_00558df0(apppuStack_78,pcVar9,&DAT_01d61f64);
  acStack_60[0] = '\x01';
  acStack_60[1] = '\x01';
  uStack_5c = 0;
  uStack_58 = 0;
  uStack_140 = 0;
  uStack_13c = 0xf;
  auStack_150[0] = 0;
  uStack_128 = 0;
  uStack_124 = 0xf;
  uStack_138 = 0;
  uStack_110 = 0;
  uStack_10c = 0xf;
  uStack_120 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar5 = FUN_008092e0(auStack_ec,param_1,0x7f,0xff,0x7f,0xff);
  uStack_8._0_1_ = 3;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  uStack_20 = 1;
  FUN_0058a190(iStack_68 + 0x1a);
  FUN_00554150("rbxasset://terrain/diffuse",0x1a);
  ppppuVar7 = apppuStack_78;
  if (0xf < uStack_64) {
    ppppuVar7 = (undefined4 ****)apppuStack_78[0];
  }
  FUN_00554150(ppppuVar7,iStack_68);
  uVar6 = FUN_005c4600(auStack_38);
  uStack_8._0_1_ = 4;
  FUN_007823b0(auStack_80,uVar6,uVar5,auStack_150,0x425c0000,0);
  uStack_8._0_1_ = 6;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 6;
  if (0xf < uStack_f0) {
    uVar10 = uStack_f0 + 1;
    uVar11 = uStack_104;
    if (0xfff < uVar10) {
      uVar11 = *(uint *)(uStack_104 - 4);
      uVar10 = uStack_f0 + 0x24;
      if (0x1f < (uStack_104 - uVar11) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar10);
  }
  uStack_f4 = 0;
  uStack_f0 = 0xf;
  uStack_104 = uStack_104 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (0xf < uStack_24) {
    uVar10 = uStack_24 + 1;
    uVar11 = auStack_38[0];
    if (0xfff < uVar10) {
      uVar11 = *(uint *)(auStack_38[0] - 4);
      uVar10 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar10);
  }
  if (piStack_e8 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_e8[1] + -1;
    piStack_e8[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_e8)();
      LOCK();
      iVar4 = piStack_e8[2] + -1;
      piStack_e8[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_e8 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 9;
  FUN_00637950();
  if (DAT_01d61f24 == '\0') {
LAB_0080b451:
    acStack_44[1] = 0;
    uStack_40 = 0;
    acStack_44[0] = (iVar8 < 2) + '\x01';
    piStack_3c = (int *)((uint)piStack_3c & 0xffff0000);
    pcVar9 = acStack_44;
  }
  else {
    iVar4 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
    if (*(char *)(iVar4 + 0x19) != '\0') goto LAB_0080b451;
    pcVar9 = acStack_60;
  }
  FUN_0078e550(0,auStack_80,pcVar9);
  if (iVar8 < 1) {
    FUN_008092e0(&uStack_40,param_1,0x80,0x80,0xff,0xff);
    uStack_d4 = 0;
    uStack_d0 = 0xf;
    auStack_e4[0] = 0;
    uStack_bc = 0;
    uStack_b8 = 0xf;
    uStack_cc = 0;
    uStack_a4 = 0;
    uStack_a0 = 0xf;
    uStack_b4 = 0;
    uStack_8._0_1_ = 0xc;
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    uStack_20 = 2;
    FUN_0058a190(iStack_68 + 0x19);
    FUN_00554150("rbxasset://terrain/normal",0x19);
    ppppuVar7 = apppuStack_78;
    if (0xf < uStack_64) {
      ppppuVar7 = (undefined4 ****)apppuStack_78[0];
    }
    FUN_00554150(ppppuVar7,iStack_68);
    uVar5 = FUN_005c4600(auStack_38);
    uStack_8._0_1_ = 0xd;
    FUN_007823b0(auStack_50,uVar5,&uStack_40,auStack_e4,0x425c0000,0);
    uStack_8._0_1_ = 0xf;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xf;
    if (0xf < uStack_84) {
      uVar10 = uStack_84 + 1;
      uVar11 = uStack_98;
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(uStack_98 - 4);
        uVar10 = uStack_84 + 0x24;
        if (0x1f < (uStack_98 - uVar11) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar10);
    }
    uStack_88 = 0;
    uStack_84 = 0xf;
    uStack_98 = uStack_98 & 0xffffff00;
    uStack_8._0_1_ = 0x10;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x10;
    if (0xf < uStack_24) {
      uVar10 = uStack_24 + 1;
      uVar11 = auStack_38[0];
      if (0xfff < uVar10) {
        uVar11 = *(uint *)(auStack_38[0] - 4);
        uVar10 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar11) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar10);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
    FUN_00637950();
    if (DAT_01d61f24 == '\0') {
LAB_0080b639:
      acStack_1c[0] = '\x01';
      acStack_1c[1] = '\0';
      pcVar9 = acStack_1c;
      uStack_18 = 0;
      uStack_14 = 0;
    }
    else {
      iVar4 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
      if (*(char *)(iVar4 + 0x19) != '\0') goto LAB_0080b639;
      pcVar9 = acStack_60;
    }
    FUN_0078e550(4,auStack_50,pcVar9);
    piVar2 = piStack_4c;
    if (piStack_4c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_4c[1] + -1;
      piStack_4c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_4c)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_3c;
    uStack_8._0_1_ = 9;
    if (piStack_3c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_3c[1] + -1;
      piStack_3c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_3c)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  if (1 < iVar8) goto LAB_0080b8b1;
  uStack_d4 = 0;
  uStack_d0 = 0xf;
  auStack_e4[0] = 0;
  uStack_bc = 0;
  uStack_b8 = 0xf;
  uStack_cc = 0;
  uStack_a4 = 0;
  uStack_a0 = 0xf;
  uStack_b4 = 0;
  uStack_8._0_1_ = 0x12;
  uVar5 = FUN_008092e0(&uStack_40,param_1,0,0,0,0xff);
  uStack_8._0_1_ = 0x13;
  uVar6 = FUN_00558df0(auStack_38,"rbxasset://terrain/reflection",apppuStack_78);
  uStack_8._0_1_ = 0x14;
  uVar6 = FUN_005c4600(uVar6);
  uStack_8._0_1_ = 0x15;
  FUN_007823b0(auStack_50,uVar6,uVar5,auStack_e4,0x425c0000,0);
  uStack_8._0_1_ = 0x17;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x17;
  if (0xf < uStack_84) {
    uVar10 = uStack_84 + 1;
    uVar11 = uStack_98;
    if (0xfff < uVar10) {
      uVar11 = *(uint *)(uStack_98 - 4);
      uVar10 = uStack_84 + 0x24;
      if (0x1f < (uStack_98 - uVar11) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar10);
  }
  uStack_88 = 0;
  uStack_84 = 0xf;
  uStack_98 = uStack_98 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
  if (0xf < uStack_24) {
    uVar10 = uStack_24 + 1;
    uVar11 = auStack_38[0];
    if (0xfff < uVar10) {
      uVar11 = *(uint *)(auStack_38[0] - 4);
      uVar10 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar10);
  }
  piVar2 = piStack_3c;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar8 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar8 = *piVar1 + -1;
      *piVar1 = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x1a);
  FUN_00637950();
  if (DAT_01d61f24 == '\0') {
LAB_0080b863:
    acStack_1c[0] = '\x01';
    acStack_1c[1] = '\0';
    pcVar9 = acStack_1c;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  else {
    iVar8 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x40))();
    if (*(char *)(iVar8 + 0x19) != '\0') goto LAB_0080b863;
    pcVar9 = acStack_60;
  }
  FUN_0078e550(2,auStack_50,pcVar9);
  uStack_8._0_1_ = 9;
  if (piStack_4c != (int *)0x0) {
    LOCK();
    iVar8 = piStack_4c[1] + -1;
    piStack_4c[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_4c)();
      LOCK();
      iVar8 = piStack_4c[2] + -1;
      piStack_4c[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piStack_4c + 4))();
      }
    }
  }
LAB_0080b8b1:
  iVar8 = iStack_54;
  if ((param_3 == 1) || (iVar4 = 0x46c, param_3 == 2)) {
    iVar4 = 0x474;
  }
  acStack_1c[0] = '\x01';
  acStack_1c[1] = '\x01';
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_0078e550(1,iVar4 + iStack_54,acStack_1c);
  acStack_1c[0] = '\x01';
  acStack_1c[1] = '\0';
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_0078e550(3,*(int *)(iVar8 + 0x44c) + 0x118,acStack_1c);
  acStack_1c[0] = '\x01';
  acStack_1c[1] = '\x01';
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_d4 = 0;
  uStack_d0 = 0xf;
  auStack_e4[0] = 0;
  uStack_bc = 0;
  uStack_b8 = 0xf;
  uStack_cc = 0;
  uStack_a4 = 0;
  uStack_a0 = 0xf;
  uStack_b4 = 0;
  uStack_8._0_1_ = 0x1b;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  FUN_005542c0("rbxasset://textures/brdfLUT.dds",0x1f);
  uStack_8._0_1_ = 0x1c;
  FUN_009cbbb0(auStack_38);
  uStack_8._0_1_ = 0x1d;
  uVar5 = FUN_00782480(&uStack_40,auStack_38,1,auStack_e4,0x425c0000,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x1e);
  FUN_0078e550(0xb,uVar5,acStack_1c);
  piVar2 = piStack_3c;
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar8 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar8 = *piVar1 + -1;
      *piVar1 = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 0x1b;
  if (0xf < uStack_24) {
    uVar10 = uStack_24 + 1;
    uVar11 = auStack_38[0];
    if (0xfff < uVar10) {
      uVar11 = *(uint *)(auStack_38[0] - 4);
      uVar10 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar10);
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  FUN_00637950();
  iVar8 = iStack_54;
  acStack_1c[0] = '\x01';
  acStack_1c[1] = '\x01';
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_0078e550(0xe,*(int *)(iStack_54 + 0x44c) + 0x94,acStack_1c);
  acStack_1c[0] = '\x01';
  acStack_1c[1] = '\x01';
  uStack_18 = 0;
  uStack_14 = 0;
  iVar8 = FUN_0078e550(0xf,*(int *)(iVar8 + 0x44c) + 0x84,acStack_1c);
  if (piStack_7c != (int *)0x0) {
    LOCK();
    piVar2 = piStack_7c + 1;
    iVar4 = *piVar2;
    iVar8 = *piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar8 = (**(code **)*piStack_7c)();
      LOCK();
      piVar2 = piStack_7c + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar8 = (**(code **)(*piStack_7c + 4))();
      }
    }
  }
  if (0xf < uStack_64) {
    uVar11 = uStack_64 + 1;
    ppppuVar7 = (undefined4 ****)apppuStack_78[0];
    if (0xfff < uVar11) {
      ppppuVar7 = (undefined4 ****)apppuStack_78[0][-1];
      uVar11 = uStack_64 + 0x24;
      if (0x1f < (uint)((int)apppuStack_78[0] + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar8 = FUN_01674ea0(ppppuVar7,uVar11);
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 12428 ; VA 0x0080bb60 ; FUN_0080bb60 */

void FUN_0080bb60(int param_1,int *param_2,undefined4 param_3,undefined4 param_4,int param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  undefined auStack_a0 [16];
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined uStack_88;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined uStack_70;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  uint auStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  undefined2 auStack_3c [2];
  undefined4 uStack_38;
  undefined2 uStack_34;
  undefined2 auStack_30 [2];
  undefined4 uStack_2c;
  undefined2 uStack_28;
  int iStack_24;
  undefined2 uStack_1f;
  undefined uStack_1d;
  undefined2 auStack_1c [2];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b5173;
  pvStack_10 = ExceptionList;
  iVar7 = *(int *)(param_1 + 0x4f8);
  uStack_1f = 0x104;
  uStack_1d = 0;
  ExceptionList = &pvStack_10;
  iStack_24 = iVar7;
  FUN_0078e510(&uStack_1f);
  iVar2 = *param_2;
  auStack_1c[0] = 1;
  uStack_18 = 0;
  uStack_14._0_2_ = 0;
  FUN_0078e550(0,param_3,auStack_1c);
  auStack_1c[0] = 1;
  uStack_18 = 0;
  uStack_14._0_2_ = 0;
  FUN_0078e550(2,param_4,auStack_1c);
  if (iVar2 < 1) {
    auStack_1c[0] = 0x101;
    uStack_18 = 0;
    uStack_14._0_2_ = 0;
    uVar4 = FUN_00798be0();
    FUN_0078e550(4,uVar4,auStack_1c);
    auStack_1c[0] = 0x100;
    uStack_18 = 0;
    uStack_14._0_2_ = 0;
    uVar4 = FUN_00798fd0();
    FUN_0078e550(5,uVar4,auStack_1c);
  }
  if ((param_5 == 1) || (param_5 == 2)) {
    auStack_1c[0] = 0x101;
    uStack_18 = 0;
    uStack_14._0_2_ = 0;
    FUN_0078e550(1,iVar7 + 0x474,auStack_1c);
  }
  auStack_1c[0] = 0x101;
  uStack_18 = 0;
  uStack_14 = (int *)((uint)uStack_14._2_2_ << 0x10);
  FUN_0078e550(3,*(int *)(*(int *)(param_1 + 0x4f8) + 0x44c) + 0x118,auStack_1c);
  auStack_30[0] = 0x101;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_90 = 0;
  uStack_8c = 0xf;
  auStack_a0[0] = 0;
  uStack_78 = 0;
  uStack_74 = 0xf;
  uStack_88 = 0;
  uStack_60 = 0;
  uStack_5c = 0xf;
  uStack_70 = 0;
  uStack_8 = 0;
  uStack_44 = 0;
  uStack_40 = 0xf;
  auStack_54[0] = auStack_54[0] & 0xffffff00;
  FUN_005542c0("rbxasset://textures/brdfLUT.dds",0x1f);
  uStack_8._0_1_ = 1;
  FUN_009cbbb0(auStack_54);
  uStack_8._0_1_ = 2;
  uVar4 = FUN_00782480(&uStack_18,auStack_54,1,auStack_a0,0x425c0000,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0078e550(0xb,uVar4,auStack_30);
  piVar3 = uStack_14;
  if (uStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = uStack_14[1] + -1;
    uStack_14[1] = iVar2;
    UNLOCK();
    iVar7 = iStack_24;
    if (iVar2 == 0) {
      (**(code **)*uStack_14)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      iVar7 = iStack_24;
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
        iVar7 = iStack_24;
      }
    }
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_40) {
    uVar6 = uStack_40 + 1;
    uVar5 = auStack_54[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_54[0] - 4);
      uVar6 = uStack_40 + 0x24;
      if (0x1f < (auStack_54[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_44 = 0;
  uStack_40 = 0xf;
  auStack_54[0] = auStack_54[0] & 0xffffff00;
  uStack_8 = 0xffffffff;
  FUN_00637950();
  auStack_30[0] = 0x101;
  uStack_2c = 0;
  uStack_28 = 0;
  FUN_0078e550(0xe,*(int *)(iVar7 + 0x44c) + 0x94,auStack_30);
  auStack_3c[0] = 0x101;
  uStack_38 = 0;
  uStack_34 = 0;
  FUN_0078e550(0xf,*(int *)(iVar7 + 0x44c) + 0x84,auStack_3c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12429 ; VA 0x0080be70 ; FUN_0080be70 */

undefined4 FUN_0080be70(undefined4 param_1,undefined4 param_2,int param_3,int param_4,uint param_5)

{
  int *piVar1;
  char cVar2;
  char *pcVar3;
  int *piVar4;
  uint uVar5;
  char *pcVar6;
  int iVar7;
  char *pcVar8;
  int iVar9;
  undefined auStack_80 [80];
  char *apcStack_30 [4];
  char *apcStack_20 [3];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b5190;
  pvStack_10 = ExceptionList;
  apcStack_30[0] = "SmoothClusterSuperHQVS_";
  apcStack_30[1] = "SmoothClusterHQVS_";
  apcStack_30[2] = "SmoothClusterVS_";
  apcStack_30[3] = "SmoothClusterLQVS_";
  apcStack_20[0] = "SmoothClusterSuperHQFS_";
  apcStack_20[1] = "SmoothClusterHQFS_";
  apcStack_20[2] = "SmoothClusterFS_";
  piStack_14 = &DAT_019016d0;
  if ((param_4 < 2) && (DAT_01d60bd8 != '\0')) {
    uVar5 = 0x200;
  }
  else {
    uVar5 = 0;
  }
  pcVar3 = apcStack_20[param_4];
  param_5 = *(uint *)(&DAT_01901630 + param_3 * 4) | uVar5 | param_5;
  if (pcVar3 == (char *)0x0) {
    iVar7 = 0;
  }
  else {
    pcVar6 = pcVar3;
    do {
      cVar2 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar2 != '\0');
    iVar7 = (int)pcVar6 - (int)(pcVar3 + 1);
  }
  pcVar6 = apcStack_30[param_4];
  if (pcVar6 == (char *)0x0) {
    iVar9 = 0;
  }
  else {
    pcVar8 = pcVar6;
    do {
      cVar2 = *pcVar8;
      pcVar8 = pcVar8 + 1;
    } while (cVar2 != '\0');
    iVar9 = (int)pcVar8 - (int)(pcVar6 + 1);
  }
  ExceptionList = &pvStack_10;
  FUN_007910b0(apcStack_20 + 2,pcVar6,iVar9,param_5,pcVar3,iVar7,param_5);
  piVar4 = piStack_14;
  uStack_8 = 0;
  if (apcStack_20[2] != (char *)0x0) {
    FUN_0078ded0(apcStack_20 + 2,param_4,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_0080b1d0(param_2,auStack_80,param_3);
    FUN_0078e040(auStack_80,param_3);
    FUN_0075e0c0();
    piVar4 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar7 = piStack_14[1] + -1;
      piStack_14[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar7 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_14[1] + -1;
    piStack_14[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 12430 ; VA 0x0080c020 ; FUN_0080c020 */

void FUN_0080c020(int param_1,undefined4 param_2)

{
  char cVar1;
  
  if ((*(uint *)(param_1 + 0x68) & 0x800000) != 0) {
    cVar1 = FUN_0080a3e0(param_1);
    if (cVar1 != '\0') {
      if (DAT_01d61f3c != '\0') {
        FUN_0080aa20(param_1,param_2);
        return;
      }
      FUN_0080a9a0(param_1,param_2);
      return;
    }
  }
  FUN_008086b0(param_1);
  FUN_0080a660(param_1,1);
  FUN_0080d910(param_1);
  FUN_0080ee50(param_1);
  return;
}



/* FUNCTION 12431 ; VA 0x0080c0a0 ; FUN_0080c0a0 */

void FUN_0080c0a0(int param_1,undefined4 param_2)

{
  int iVar1;
  uint uVar2;
  
  if ((*(uint *)(param_1 + 0x68) & 0x800000) == 0) {
    uVar2 = 0;
    do {
      iVar1 = *(int *)(param_1 + 0x1c +
                      (((int)uVar2 >> 2 & 1U) + (((int)uVar2 >> 1 & 1U) + (uVar2 & 1) * 2) * 2) * 4)
      ;
      if ((iVar1 != 0) && ((*(uint *)(iVar1 + 0x68) & 0x800000) != 0)) {
        uVar2 = 0;
        do {
          iVar1 = *(int *)(param_1 + 0x1c +
                          (((int)uVar2 >> 2 & 1U) + (((int)uVar2 >> 1 & 1U) + (uVar2 & 1) * 2) * 2)
                          * 4);
          if (iVar1 != 0) {
            if (DAT_01d61f3c == '\0') {
              FUN_0080a9a0(iVar1,param_2);
            }
            else {
              FUN_0080aa20(iVar1,param_2);
            }
          }
          uVar2 = uVar2 + 1;
        } while ((int)uVar2 < 8);
        return;
      }
      uVar2 = uVar2 + 1;
    } while ((int)uVar2 < 8);
  }
  FUN_0080a660(param_1,0);
  uVar2 = 0;
  do {
    iVar1 = *(int *)(param_1 + 0x1c +
                    (((int)uVar2 >> 2 & 1U) + (((int)uVar2 >> 1 & 1U) + (uVar2 & 1) * 2) * 2) * 4);
    if (iVar1 != 0) {
      FUN_0080a660(iVar1,1);
      FUN_0080d910(iVar1);
    }
    uVar2 = uVar2 + 1;
  } while ((int)uVar2 < 8);
  FUN_0080ee50(param_1);
  return;
}



/* FUNCTION 12432 ; VA 0x0080c1a0 ; FUN_0080c1a0 */

void __fastcall FUN_0080c1a0(int param_1)

{
  FUN_011590c0();
  if (*(int *)(param_1 + 0x28) != 0) {
    FUN_00a6f530(param_1 + 0x1c);
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  *(undefined4 *)(param_1 + 0x24) = 0;
  return;
}



/* FUNCTION 12433 ; VA 0x0080c1d0 ; FUN_0080c1d0 */

void FUN_0080c1d0(int param_1)

{
  byte bVar1;
  byte bVar2;
  
  bVar1 = 0;
  if (*(int *)(param_1 + 0x1c) != 0) {
    bVar1 = *(byte *)(*(int *)(param_1 + 0x1c) + 0xd);
    bVar1 = -(bVar1 != 0) & bVar1;
  }
  bVar2 = bVar1;
  if ((*(int *)(param_1 + 0x2c) != 0) &&
     (bVar2 = *(byte *)(*(int *)(param_1 + 0x2c) + 0xd), bVar2 <= bVar1)) {
    bVar2 = bVar1;
  }
  bVar1 = bVar2;
  if ((*(int *)(param_1 + 0x24) != 0) &&
     (bVar1 = *(byte *)(*(int *)(param_1 + 0x24) + 0xd), bVar1 <= bVar2)) {
    bVar1 = bVar2;
  }
  bVar2 = bVar1;
  if ((*(int *)(param_1 + 0x34) != 0) &&
     (bVar2 = *(byte *)(*(int *)(param_1 + 0x34) + 0xd), bVar2 <= bVar1)) {
    bVar2 = bVar1;
  }
  bVar1 = bVar2;
  if ((*(int *)(param_1 + 0x20) != 0) &&
     (bVar1 = *(byte *)(*(int *)(param_1 + 0x20) + 0xd), bVar1 <= bVar2)) {
    bVar1 = bVar2;
  }
  bVar2 = bVar1;
  if ((*(int *)(param_1 + 0x30) != 0) &&
     (bVar2 = *(byte *)(*(int *)(param_1 + 0x30) + 0xd), bVar2 <= bVar1)) {
    bVar2 = bVar1;
  }
  bVar1 = bVar2;
  if ((*(int *)(param_1 + 0x28) != 0) &&
     (bVar1 = *(byte *)(*(int *)(param_1 + 0x28) + 0xd), bVar1 <= bVar2)) {
    bVar1 = bVar2;
  }
  bVar2 = bVar1;
  if ((*(int *)(param_1 + 0x38) != 0) &&
     (bVar2 = *(byte *)(*(int *)(param_1 + 0x38) + 0xd), bVar2 <= bVar1)) {
    bVar2 = bVar1;
  }
  if (*(byte *)(param_1 + 0xd) != bVar2) {
    *(undefined *)(param_1 + 0x11) = 1;
    *(byte *)(param_1 + 0xd) = bVar2;
    if (*(int *)(param_1 + 0x1c) != 0) {
      *(undefined *)(*(int *)(param_1 + 0x1c) + 0x11) = 1;
    }
    if (*(int *)(param_1 + 0x2c) != 0) {
      *(undefined *)(*(int *)(param_1 + 0x2c) + 0x11) = 1;
    }
    if (*(int *)(param_1 + 0x24) != 0) {
      *(undefined *)(*(int *)(param_1 + 0x24) + 0x11) = 1;
    }
    if (*(int *)(param_1 + 0x34) != 0) {
      *(undefined *)(*(int *)(param_1 + 0x34) + 0x11) = 1;
    }
    if (*(int *)(param_1 + 0x20) != 0) {
      *(undefined *)(*(int *)(param_1 + 0x20) + 0x11) = 1;
    }
    if (*(int *)(param_1 + 0x30) != 0) {
      *(undefined *)(*(int *)(param_1 + 0x30) + 0x11) = 1;
    }
    if (*(int *)(param_1 + 0x28) != 0) {
      *(undefined *)(*(int *)(param_1 + 0x28) + 0x11) = 1;
    }
    if (*(int *)(param_1 + 0x38) != 0) {
      *(undefined *)(*(int *)(param_1 + 0x38) + 0x11) = 1;
    }
  }
  return;
}



/* FUNCTION 12434 ; VA 0x0080c300 ; FUN_0080c300 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0080c300(int param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint *puVar5;
  char cVar6;
  int *piVar7;
  int iVar8;
  float fVar9;
  uint uVar10;
  uint uVar11;
  int iVar12;
  float10 fVar13;
  undefined8 uVar14;
  float fStack_d4;
  float fStack_d0;
  float fStack_cc;
  undefined4 uStack_c8;
  float fStack_c4;
  float fStack_c0;
  float fStack_bc;
  undefined4 uStack_b8;
  float fStack_ac;
  float fStack_a8;
  float fStack_a4;
  int iStack_a0;
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  uint *puStack_90;
  float fStack_8c;
  int iStack_88;
  int iStack_84;
  undefined4 uStack_80;
  int iStack_7c;
  int iStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  int iStack_64;
  int iStack_60;
  undefined4 uStack_5c;
  int iStack_58;
  int iStack_54;
  undefined4 uStack_50;
  int iStack_4c;
  int iStack_48;
  undefined4 uStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  int iStack_34;
  int iStack_30;
  uint uStack_2c;
  int iStack_28;
  int iStack_24;
  undefined8 uStack_20;
  int iStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b51ab;
  pvStack_10 = ExceptionList;
  puStack_90 = (uint *)(param_1 + 0x68);
  iStack_30 = CONCAT31(iStack_30._1_3_,*(int *)(param_1 + 0x74) != 0);
  ExceptionList = &pvStack_10;
  *(undefined *)(param_1 + 0x11) = 0;
  *(undefined2 *)(param_1 + 0x13) = 0;
  uStack_2c = CONCAT31(uStack_2c._1_3_,*(int *)(param_1 + 0x78) != 0);
  *puStack_90 = *puStack_90 | 0xffffff;
  puVar1 = *(undefined4 **)(param_1 + 0x6c);
  *(undefined4 *)(param_1 + 0x6c) = 0;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)();
  }
  puVar1 = *(undefined4 **)(param_1 + 0x70);
  *(undefined4 *)(param_1 + 0x70) = 0;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)();
  }
  piVar7 = (int *)FUN_00809190();
  fStack_9c = (float)piVar7[2] * DAT_018e3f8c;
  fStack_8c = (float)*piVar7 * DAT_018e3f8c;
  fStack_14 = (float)piVar7[1] * DAT_018e3f8c;
  uStack_20 = (double)(fStack_9c * _DAT_01901968);
  fVar13 = (float10)FUN_01725280(uStack_20);
  fStack_98 = (float)fVar13;
  uStack_20 = (double)(fStack_14 * _DAT_01901968);
  fVar13 = (float10)FUN_01725280(uStack_20);
  fStack_94 = (float)fVar13;
  uStack_20 = (double)(fStack_8c * _DAT_01901968);
  fVar13 = (float10)FUN_01725280(uStack_20);
  uVar4 = _UNK_018c4ebc;
  uVar3 = _UNK_018c4eb8;
  uVar2 = _UNK_018c4eb4;
  fStack_ac = fStack_8c;
  fStack_a8 = fStack_14;
  fStack_a4 = fStack_9c;
  fStack_d4 = (float)fVar13;
  fStack_3c = fStack_94;
  fStack_38 = fStack_98;
  iStack_34 = 0x42800000;
  iStack_a0 = 0x3d800000;
  fStack_d0 = fStack_94;
  fStack_cc = fStack_98;
  uStack_c8 = 0x42800000;
  fStack_c4 = fStack_8c;
  fStack_c0 = fStack_14;
  fStack_bc = fStack_9c;
  uStack_b8 = 0x3d800000;
  if (DAT_01d61f2c != '\0') {
    uVar14 = CONCAT44(DAT_018c45d0,DAT_018c45d0);
    *(undefined4 *)(param_1 + 0x94) = _DAT_018c4eb0;
    *(undefined4 *)(param_1 + 0x98) = uVar2;
    *(undefined4 *)(param_1 + 0x9c) = uVar3;
    *(undefined4 *)(param_1 + 0xa0) = uVar4;
    *(undefined8 *)(param_1 + 0xa4) = uVar14;
  }
  iStack_48 = 0;
  iStack_88 = 0;
  iStack_84 = 0;
  uStack_80 = 0;
  iStack_7c = 0;
  uStack_44 = 0;
  iStack_78 = 0;
  uStack_74 = 0;
  uStack_70 = 0;
  uStack_6c = 0;
  uStack_68 = 0;
  iStack_64 = 0;
  iStack_60 = 0;
  uStack_5c = 0;
  iStack_58 = 0;
  iStack_54 = 0;
  uStack_50 = 0;
  iStack_4c = 0;
  uStack_8 = 0;
  fStack_40 = fStack_d4;
  uStack_20._4_4_ = fStack_d4;
  FUN_0080cd70(param_1,param_2,0,&fStack_d4,&iStack_88);
  if (DAT_01d6d15c == '\0') {
    fStack_40 = (float)(iStack_60 - iStack_64 >> 2);
    iStack_28 = iStack_54 - iStack_58 >> 2;
  }
  else {
    fStack_40 = (float)((iStack_84 - iStack_88) / 0x14);
    iStack_28 = (iStack_78 - iStack_7c) / 0x14;
  }
  fStack_ac = (float)(iStack_48 - iStack_4c >> 2);
  FUN_0080c940(param_1,param_2,&fStack_d4,&iStack_88,iStack_30,uStack_2c);
  if (DAT_01d6d15c == '\0') {
    fStack_14 = (float)(iStack_60 - iStack_64 >> 2);
    iStack_24 = iStack_54 - iStack_58 >> 2;
  }
  else {
    fStack_14 = (float)((iStack_84 - iStack_88) / 0x14);
    iStack_24 = (iStack_78 - iStack_7c) / 0x14;
  }
  fStack_a8 = (float)(iStack_48 - iStack_4c >> 2);
  fStack_3c = fStack_14;
  if ((fStack_14 == fStack_40) && (iStack_24 == iStack_28)) {
    *puStack_90 = *puStack_90 & 0xff000000;
  }
  else {
    FUN_0080cd70(param_1,param_2,2,&fStack_d4,&iStack_88);
    iVar12 = iStack_18;
    if (DAT_01d6d15c == '\0') {
      fStack_38 = (float)(iStack_60 - iStack_64 >> 2);
      iVar8 = iStack_54 - iStack_58 >> 2;
    }
    else {
      fStack_38 = (float)((iStack_84 - iStack_88) / 0x14);
      iVar8 = (iStack_78 - iStack_7c) / 0x14;
    }
    uStack_20 = (double)CONCAT44(uStack_20._4_4_,iVar8);
    fStack_a4 = (float)(iStack_48 - iStack_4c >> 2);
    FUN_0080cd70(param_1,param_2,1,&fStack_d4,&iStack_88);
    if (DAT_01d6d15c == '\0') {
      iStack_34 = iStack_60 - iStack_64 >> 2;
      fVar9 = (float)(iStack_54 - iStack_58 >> 2);
    }
    else {
      iStack_34 = (iStack_84 - iStack_88) / 0x14;
      fVar9 = (float)((iStack_78 - iStack_7c) / 0x14);
    }
    iStack_a0 = iStack_48 - iStack_4c >> 2;
    uStack_20._4_4_ = fVar9;
    if (*(char *)(iVar12 + 0x2d) != '\0') {
      iStack_30 = (*(int *)(*(int *)(iVar12 + 0x84) + 0x24) -
                  *(int *)(*(int *)(iVar12 + 0x84) + 0x20)) / 0x1c;
      param_2 = 0;
      iVar8 = iStack_84 - iStack_88 >> 0x1f;
      if ((iStack_84 - iStack_88) / 0x14 + iVar8 != iVar8) {
        fStack_14 = 0.0;
        iVar8 = iStack_88;
        do {
          uVar10 = (uint)*(short *)((int)fStack_14 + 6 + iVar8);
          iVar12 = (int)fStack_14 + iVar8;
          uVar11 = (int)uVar10 >> 0x1f;
          uStack_2c = (uint)*(byte *)(((uVar10 ^ uVar11) - uVar11) + 0xb + iVar12);
          if (((int)uStack_2c < iStack_30) &&
             (cVar6 = FUN_00863610(), iVar8 = iStack_88, cVar6 != '\0')) {
            *(ushort *)(iVar12 + 6) =
                 (ushort)(0 < *(short *)(iVar12 + 6)) * 8 + -4 + *(short *)(iVar12 + 6);
          }
          param_2 = param_2 + 1;
          fStack_14 = (float)((int)fStack_14 + 0x14);
          iVar12 = iStack_18;
        } while (param_2 < (uint)((iStack_84 - iVar8) / 0x14));
      }
    }
    puVar5 = puStack_90;
    FUN_00812190(puStack_90,&fStack_c4,0x14,&iStack_88,&fStack_40,&iStack_28,&fStack_ac);
    if (DAT_01d6d15c == '\0') {
      uVar10 = (iStack_54 - iStack_58 >> 2) + (iStack_60 - iStack_64 >> 2);
    }
    else {
      uVar10 = (iStack_78 - iStack_7c) / 0x14 + (iStack_84 - iStack_88) / 0x14;
      iVar12 = iStack_18;
    }
    uVar10 = uVar10 / 0xc0;
    if (uVar10 == 0) {
      uVar10 = 1;
    }
    *puVar5 = *puVar5 ^ (*puVar5 ^ uVar10) & 0xffffff;
    if (*(int *)(param_1 + 0x3c) != 0) {
      *(int *)(*(int *)(param_1 + 0x3c) + 0x10) = (int)(*puVar5 << 8) >> 8;
      iVar12 = *(int *)(*(int *)(iVar12 + 0x20) + 0x4e4);
      if (DAT_01d61f2c == '\0') {
        *(int *)(*(int *)(param_1 + 0x3c) + 0x34) = *(int *)(iVar12 + 0x24) + 1;
        FUN_00816ee0();
      }
      else {
        FUN_008411b0(param_1 + 0x94,*(int *)(iVar12 + 0x24) + 1);
      }
    }
  }
  FUN_00807cd0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12435 ; VA 0x0080c940 ; FUN_0080c940 */

void __thiscall
FUN_0080c940(int param_1,int param_2,int param_3,undefined4 param_4,undefined4 param_5)

{
  byte bVar1;
  byte bVar2;
  int iVar3;
  float *pfVar4;
  float fVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  int *piVar8;
  bool bVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  int *piVar14;
  int *piVar15;
  undefined8 uVar16;
  undefined auStack_c4 [24];
  undefined auStack_ac [24];
  undefined4 uStack_94;
  float *pfStack_90;
  float *pfStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  int *piStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined8 uStack_4c;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int iStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_20;
  undefined2 uStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b51f2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_3c = param_1;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb38a8) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb38a8), DAT_01eb38a8 == -1)) {
    uStack_8 = 0;
    uVar16 = FUN_0152dab0("Render",&DAT_01901900,0xffffffff);
    DAT_01eb38a4 = (undefined4)((ulonglong)uVar16 >> 0x20);
    DAT_01eb38a0 = (undefined4)uVar16;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb38a8);
  }
  uStack_44 = DAT_01eb38a0;
  uStack_54 = DAT_01eb38a0;
  uStack_40 = DAT_01eb38a4;
  uStack_50 = DAT_01eb38a4;
  uStack_4c = FUN_0152d930(DAT_01eb38a0,DAT_01eb38a4);
  uStack_8 = 1;
  if (*(int *)(param_2 + 0x18) == 0) {
    bVar1 = *(byte *)(param_2 + 0xd);
    bVar2 = *(byte *)(param_2 + 0xc);
    bVar9 = bVar2 < *(byte *)(param_2 + 0xd);
  }
  else {
    bVar1 = *(byte *)(*(int *)(param_2 + 0x18) + 0xd);
    bVar9 = *(byte *)(param_2 + 0xc) < bVar1;
    bVar2 = *(byte *)(param_2 + 0xc);
  }
  if (!bVar9) {
    bVar1 = bVar2;
  }
  uStack_14 = (uint)bVar1;
  FUN_00809190(auStack_ac);
  uStack_6c = *(undefined4 *)(param_3 + 4);
  piVar8 = *(int **)(param_3 + 0x18);
  uStack_68 = *(undefined4 *)(param_3 + 8);
  uStack_64 = *(undefined4 *)(param_3 + 0xc);
  uStack_60 = *(undefined4 *)(param_3 + 0x10);
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
    piVar8 = *(int **)(param_3 + 0x18);
  }
  uStack_5c = *(undefined4 *)(param_3 + 0x14);
  uStack_20 = *(undefined4 *)(param_1 + 0x84);
  uStack_1c = 1;
  uStack_18 = 0;
  pfStack_90 = (float *)0x0;
  pfStack_8c = (float *)0x0;
  uStack_88 = 0;
  uStack_84 = 0;
  uStack_70 = 0;
  uStack_80 = 0;
  uStack_7c = 0;
  uStack_78 = 0;
  uStack_74 = 0;
  uStack_8._0_1_ = 3;
  piStack_58 = piVar8;
  FUN_00d55590(&pfStack_90,(undefined4 *)(param_3 + 4),auStack_ac,uStack_14,&uStack_20);
  if (*(char *)(param_1 + 0x2d) == '\0') {
    iVar3 = *(int *)(param_2 + 0x40);
    if (iVar3 != *(int *)(param_2 + 0x44)) {
      iStack_2c = 0;
      uStack_28 = 0;
      if (&iStack_2c != (int *)(param_2 + 0x40)) {
        *(int *)(param_2 + 0x40) = 0;
        uVar6 = *(undefined4 *)(param_2 + 0x44);
        *(undefined4 *)(param_2 + 0x44) = 0;
        uStack_28 = CONCAT44(*(undefined4 *)(param_2 + 0x48),uVar6);
        *(undefined4 *)(param_2 + 0x48) = 0;
        iStack_2c = iVar3;
      }
      FUN_00617ad0();
    }
  }
  else {
    uVar6 = FUN_01675290(DAT_01eb36e0);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    uStack_94 = uVar6;
    uStack_14 = FUN_00a6ce70(param_2);
    if (DAT_01d61f3c == '\0') {
      puVar7 = (undefined4 *)FUN_00809230(auStack_c4);
    }
    else {
      uStack_38 = *(undefined4 *)(param_2 + 0x7c);
      uStack_34 = *(undefined4 *)(param_2 + 0x80);
      uStack_30 = *(undefined4 *)(param_2 + 0x84);
      iStack_2c = *(int *)(param_2 + 0x88);
      puVar7 = &uStack_38;
      uStack_28 = *(undefined8 *)(param_2 + 0x8c);
    }
    uVar16 = FUN_008623b0(&pfStack_90,puVar7,param_2 + 0x40,uStack_14,0);
    *(undefined8 *)(param_2 + 0x50) = uVar16;
    uStack_8._0_1_ = 5;
    FUN_01675290(uVar6);
    uStack_8._0_1_ = 3;
  }
  if (*(int *)(param_2 + 0x40) == *(int *)(param_2 + 0x44)) {
    puVar7 = *(undefined4 **)(param_2 + 0x74);
    *(undefined4 *)(param_2 + 0x74) = 0;
    if (puVar7 != (undefined4 *)0x0) {
      (**(code **)*puVar7)(1);
    }
    puVar7 = *(undefined4 **)(param_2 + 0x78);
    *(undefined4 *)(param_2 + 0x78) = 0;
    if (puVar7 != (undefined4 *)0x0) {
      (**(code **)*puVar7)(1);
    }
  }
  FUN_00d57870(param_5,&pfStack_90,param_4,&uStack_20);
  FUN_00d566e0(param_5,&pfStack_90,param_4,&uStack_20);
  fVar5 = DAT_018e3f8c;
  pfVar4 = pfStack_90;
  if (DAT_01d61f2c != '\0') {
    for (; pfVar4 != pfStack_8c; pfVar4 = pfVar4 + 4) {
      piVar14 = (int *)(pfVar4[2] * fVar5);
      fVar11 = *pfVar4 * fVar5;
      fVar10 = pfVar4[1] * fVar5;
      piVar15 = *(int **)(param_2 + 0x9c);
      if ((float)piVar14 <= (float)*(int **)(param_2 + 0x9c)) {
        piVar15 = piVar14;
      }
      fVar13 = *(float *)(param_2 + 0x98);
      if (fVar10 <= *(float *)(param_2 + 0x98)) {
        fVar13 = fVar10;
      }
      fVar12 = *(float *)(param_2 + 0x94);
      if (fVar11 <= *(float *)(param_2 + 0x94)) {
        fVar12 = fVar11;
      }
      uStack_28 = CONCAT44(piVar15,(undefined4)uStack_28);
      *(ulonglong *)(param_2 + 0x94) = CONCAT44(fVar13,fVar12);
      *(int **)(param_2 + 0x9c) = piVar15;
      piStack_58 = *(int **)(param_2 + 0xa8);
      if ((float)*(int **)(param_2 + 0xa8) <= (float)piVar14) {
        piStack_58 = piVar14;
      }
      fVar13 = *(float *)(param_2 + 0xa4);
      if (*(float *)(param_2 + 0xa4) <= fVar10) {
        fVar13 = fVar10;
      }
      fVar10 = *(float *)(param_2 + 0xa0);
      if (*(float *)(param_2 + 0xa0) <= fVar11) {
        fVar10 = fVar11;
      }
      *(ulonglong *)(param_2 + 0xa0) = CONCAT44(fVar13,fVar10);
      *(int **)(param_2 + 0xa8) = piStack_58;
    }
  }
  FUN_00807be0();
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar3 = piVar8[1] + -1;
    piVar8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      piVar15 = piVar8 + 2;
      iVar3 = *piVar15;
      *piVar15 = *piVar15 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  uStack_8 = 6;
  FUN_0152dda0(uStack_44,uStack_40,uStack_4c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12436 ; VA 0x0080cd70 ; FUN_0080cd70 */

void FUN_0080cd70(int param_1,int param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  undefined8 uVar8;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined8 uStack_84;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  int iStack_48;
  undefined uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  undefined2 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b5224;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb38b8) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb38b8), DAT_01eb38b8 == -1)) {
    uStack_8 = 0;
    uVar8 = FUN_0152dab0("Render","Border",0xffffffff);
    DAT_01eb38b4 = (undefined4)((ulonglong)uVar8 >> 0x20);
    DAT_01eb38b0 = (undefined4)uVar8;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb38b8);
  }
  uStack_28 = DAT_01eb38b0;
  uStack_58 = DAT_01eb38b0;
  uStack_24 = DAT_01eb38b4;
  uStack_54 = DAT_01eb38b4;
  uStack_50 = FUN_0152d930(DAT_01eb38b0,DAT_01eb38b4);
  iVar7 = param_3 * 0x34;
  uVar3 = *(undefined4 *)(iVar7 + 0x4c + param_2);
  puVar2 = (undefined4 *)(iVar7 + 0x1c + param_2);
  uStack_94 = *puVar2;
  uStack_90 = puVar2[1];
  uStack_8c = puVar2[2];
  uStack_88 = puVar2[3];
  piStack_2c = *(int **)(iVar7 + 0x48 + param_2);
  uStack_40 = *(undefined4 *)(iVar7 + 0x34 + param_2);
  uStack_3c = *(undefined4 *)(iVar7 + 0x38 + param_2);
  uStack_38 = *(undefined4 *)(iVar7 + 0x3c + param_2);
  uStack_34 = *(undefined4 *)(iVar7 + 0x40 + param_2);
  uStack_84 = *(undefined8 *)(iVar7 + 0x2c + param_2);
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piStack_2c[1] = piStack_2c[1] + 1;
    UNLOCK();
    piStack_2c = *(int **)(iVar7 + 0x48 + param_2);
  }
  uStack_30 = *(undefined4 *)(iVar7 + 0x44 + param_2);
  iStack_48 = param_3;
  uStack_18 = 0x101;
  uStack_7c = 0;
  uStack_78 = 0;
  uStack_74 = 0;
  uStack_70 = 0;
  uStack_44 = (*(byte *)(param_1 + param_3 * 4) & 1) != 0;
  uStack_6c = 0;
  uStack_68 = 0;
  uStack_64 = 0;
  uStack_60 = 0;
  uStack_5c = 0;
  uStack_1c = *(undefined4 *)(iStack_20 + 0x84);
  piStack_14 = &iStack_48;
  uStack_8 = 3;
  FUN_00d55590(&uStack_7c,&uStack_40,&uStack_94,uVar3,&uStack_1c);
  uVar6 = (param_5[1] - *param_5) / 0x14;
  uVar5 = param_5[7] - param_5[6] >> 3;
  FUN_00d566e0(param_5,&uStack_7c,param_4,&uStack_1c);
  FUN_00d57870(param_5,&uStack_7c,param_4,&uStack_1c);
  if (uVar6 < (uint)((param_5[1] - *param_5) / 0x14)) {
    iVar7 = uVar6 * 0x14;
    do {
      iVar7 = iVar7 + 0x14;
      uVar6 = uVar6 + 1;
      *(short *)(*param_5 + -0xe + iVar7) = -*(short *)(*param_5 + -0xe + iVar7);
    } while (uVar6 < (uint)((param_5[1] - *param_5) / 0x14));
  }
  if (uVar5 < (uint)(param_5[7] - param_5[6] >> 3)) {
    do {
      *(undefined2 *)(param_5[6] + 6 + uVar5 * 8) = 0xffff;
      uVar5 = uVar5 + 1;
    } while (uVar5 < (uint)(param_5[7] - param_5[6] >> 3));
  }
  FUN_00807be0();
  piVar4 = piStack_2c;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar7 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uStack_8 = 4;
  FUN_0152dda0(uStack_28,uStack_24,uStack_50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12437 ; VA 0x0080d030 ; FUN_0080d030 */

undefined4 * FUN_0080d030(undefined8 *param_1)

{
  int *piVar1;
  int *piVar2;
  byte bVar3;
  byte bVar4;
  undefined4 *puVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  undefined *puVar9;
  bool bVar10;
  undefined auStack_110 [24];
  undefined8 *puStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  int *piStack_e0;
  undefined auStack_dc [156];
  undefined8 uStack_40;
  undefined4 uStack_38;
  uint uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int *piStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b524e;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 3) == 0) {
    bVar3 = *(byte *)((int)param_1 + 0xd);
    bVar4 = *(byte *)((int)param_1 + 0xc);
    bVar10 = bVar4 < *(byte *)((int)param_1 + 0xd);
  }
  else {
    bVar3 = *(byte *)(*(int *)(param_1 + 3) + 0xd);
    bVar10 = *(byte *)((int)param_1 + 0xc) < bVar3;
    bVar4 = *(byte *)((int)param_1 + 0xc);
  }
  uStack_18 = (uint)bVar3;
  uVar6 = uStack_18;
  if (!bVar10) {
    uVar6 = (uint)bVar4;
  }
  ExceptionList = &pvStack_10;
  FUN_00809190(auStack_110);
  iVar8 = iStack_14;
  FUN_00a71760(&uStack_30,auStack_110,uVar6,1);
  uStack_8 = 0;
  if (iStack_20 == 0) {
    uStack_38 = *(undefined4 *)(param_1 + 1);
    uStack_40 = *param_1;
    uStack_34 = (uint)*(byte *)((int)param_1 + 0xc);
    puVar5 = *(undefined4 **)(iVar8 + 0x138);
    if (*(undefined4 **)(iVar8 + 0x13c) == puVar5) {
      puVar5 = (undefined4 *)FUN_006038a0(puVar5,&uStack_40);
    }
    else {
      uStack_40._4_4_ = (undefined4)((ulonglong)uStack_40 >> 0x20);
      *puVar5 = (undefined4)uStack_40;
      puVar5[1] = uStack_40._4_4_;
      puVar5[2] = uStack_38;
      puVar5[3] = uStack_34;
      *(int *)(iVar8 + 0x138) = *(int *)(iVar8 + 0x138) + 0x10;
    }
  }
  else {
    uStack_f4 = uStack_30;
    uStack_f0 = uStack_2c;
    uStack_ec = uStack_28;
    uStack_e8 = uStack_24;
    puStack_f8 = param_1;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    piStack_e0 = piStack_1c;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    FUN_0170d1f0(auStack_dc,0,0x9c);
    FUN_016f4053(auStack_dc,0x34,3,FUN_00807a60,&LAB_00808320);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (*(byte *)((int)param_1 + 0xc) + 1 < 5) {
      iVar7 = 0;
      puVar9 = auStack_dc;
      do {
        FUN_0080d290(param_1,iVar7,puVar9);
        iVar7 = iVar7 + 1;
        puVar9 = puVar9 + 0x34;
        iVar8 = iStack_14;
      } while (iVar7 < 3);
    }
    if (*(int *)(iVar8 + 0x124) == *(int *)(iVar8 + 0x120)) {
      FUN_008055d0(*(int *)(iVar8 + 0x120),&puStack_f8);
    }
    else {
      FUN_00806c10(iVar8 + 0x11c);
      *(int *)(iVar8 + 0x120) = *(int *)(iVar8 + 0x120) + 0xb8;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    puVar5 = (undefined4 *)FUN_016f32d1(auStack_dc,0x34,3,&LAB_00808320);
    piVar1 = piStack_e0;
    if (piStack_e0 != (int *)0x0) {
      LOCK();
      piVar2 = piStack_e0 + 1;
      iVar8 = *piVar2;
      puVar5 = (undefined4 *)*piVar2;
      *piVar2 = iVar8 + -1;
      UNLOCK();
      if (iVar8 + -1 == 0) {
        (**(code **)*piStack_e0)();
        LOCK();
        piVar2 = piVar1 + 2;
        iVar8 = *piVar2;
        puVar5 = (undefined4 *)*piVar2;
        *piVar2 = iVar8 + -1;
        UNLOCK();
        if (iVar8 + -1 == 0) {
          puVar5 = (undefined4 *)(**(code **)(*piVar1 + 4))();
        }
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar8 = *piVar1;
    puVar5 = (undefined4 *)*piVar1;
    *piVar1 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      puVar5 = (undefined4 *)(**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar8 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        puVar5 = (undefined4 *)(**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 12438 ; VA 0x0080d290 ; FUN_0080d290 */

int * FUN_0080d290(int *param_1,int param_2,int *param_3)

{
  int *piVar1;
  byte bVar2;
  undefined8 uVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  byte *pbVar7;
  byte bVar8;
  int iVar9;
  int iVar10;
  int *piVar11;
  bool bVar12;
  int aiStack_98 [4];
  int iStack_88;
  int iStack_84;
  int iStack_80;
  int iStack_7c;
  int iStack_78;
  int iStack_6c;
  undefined8 uStack_68;
  int iStack_60;
  undefined8 uStack_5c;
  int iStack_54;
  undefined8 uStack_50;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  uint uStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  int *piStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b5268;
  pvStack_10 = ExceptionList;
  uStack_38 = *(byte *)(param_1 + 3) + 1;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00808fc0(param_1,param_2);
  if (iVar4 == 0) goto LAB_0080d317;
  if (*(int *)(iVar4 + 0x18) == 0) {
    bVar8 = *(byte *)(iVar4 + 0xc);
    bVar2 = *(byte *)(iVar4 + 0xd);
    bVar12 = bVar8 < bVar2;
LAB_0080d304:
    if (!bVar12) {
      bVar2 = bVar8;
    }
  }
  else {
    bVar2 = *(byte *)(*(int *)(iVar4 + 0x18) + 0xd);
    if (bVar2 != 0) {
      bVar8 = *(byte *)(iVar4 + 0xc);
      bVar12 = bVar8 < bVar2;
      goto LAB_0080d304;
    }
    bVar2 = *(byte *)(iVar4 + 0xd);
  }
  if (uStack_38 <= bVar2) {
    uStack_38 = (uint)bVar2;
  }
LAB_0080d317:
  uStack_18 = param_1[param_2] & 1;
  bVar8 = *(byte *)(param_1 + 3);
  if ((DAT_01d61f5c == '\0') || ((int)(uStack_38 - bVar8) < 2)) {
    aiStack_98[0] = 3;
  }
  else {
    aiStack_98[0] = 1;
  }
  aiStack_98[0] = aiStack_98[0] << ((byte)uStack_38 & 0x1f);
  iVar4 = param_1[1];
  aiStack_98[1] = aiStack_98[0];
  aiStack_98[2] = aiStack_98[0];
  aiStack_98[param_2] = 1 << ((byte)uStack_38 & 0x1f);
  bVar8 = bVar8 + 4;
  iStack_60 = param_1[2] << (bVar8 & 0x1f);
  iVar5 = *param_1 << (bVar8 & 0x1f);
  iVar10 = 1 << (bVar8 & 0x1f);
  iVar4 = iVar4 << (bVar8 & 0x1f);
  iVar9 = iStack_60 + iVar10;
  iStack_3c = iVar9;
  uStack_50 = CONCAT44(iVar4,iVar5);
  uVar3 = CONCAT44(iVar4 + iVar10,iVar5 + iVar10);
  uStack_68 = uStack_50;
  uStack_50 = uVar3;
  iStack_48 = iVar9;
  if (uStack_18 == 0) {
    *(undefined4 *)((int)&uStack_50 + param_2 * 4) = *(undefined4 *)((int)&uStack_68 + param_2 * 4);
    iStack_3c = iStack_48;
  }
  else {
    *(undefined4 *)((int)&uStack_68 + param_2 * 4) = *(undefined4 *)((int)&uStack_50 + param_2 * 4);
  }
  uStack_5c = uStack_68;
  iStack_54 = iStack_60;
  FUN_00a70500(aiStack_98 + 3,aiStack_98);
  uStack_68 = 0;
  iStack_34 = (DAT_01d61f5c == '\0') + 2;
  iStack_60 = 0;
  bVar12 = uStack_18 == 0;
  *(int *)((int)&uStack_68 + param_2 * 4) = iStack_34 << ((byte)uStack_38 & 0x1f);
  if (bVar12) {
    iStack_78 = iStack_60 + iStack_78;
    iStack_7c = iStack_7c + uStack_68._4_4_;
    iStack_80 = iStack_80 + (int)uStack_68;
    uStack_50 = CONCAT44(iStack_7c,iStack_80);
    uStack_68 = uStack_50;
    iStack_6c = iStack_84;
    iStack_60 = iStack_78;
  }
  else {
    iStack_84 = iStack_84 - iStack_60;
    iStack_88 = iStack_88 - uStack_68._4_4_;
    aiStack_98[3] = aiStack_98[3] - (int)uStack_68;
    uStack_50 = CONCAT44(iStack_88,aiStack_98[3]);
    uStack_5c = uStack_50;
    uStack_50 = CONCAT44(iStack_7c,iStack_80);
    iStack_48 = iStack_78;
    iStack_54 = iStack_84;
  }
  *(char *)((int)param_1 + param_2 + 0xe) = (char)uStack_38;
  piVar6 = (int *)FUN_00a71760(&iStack_30,aiStack_98 + 3,uStack_38,1);
  uStack_8 = 0;
  piVar11 = piStack_1c;
  if (iStack_20 != 0) {
    if (uStack_18 != 0) {
      iStack_34 = 0;
    }
    uStack_18 = iStack_34 + 1;
    iStack_3c = iStack_30;
    iStack_40 = iStack_2c;
    iStack_44 = iStack_28;
    iVar4 = iStack_30;
    iVar5 = iStack_20;
    if (param_2 == 0) {
      iStack_14 = param_2;
      iVar9 = iStack_28;
      if (0 < iStack_2c) {
        do {
          iVar10 = 0;
          if (0 < iVar9) {
            do {
              if (iVar5 == 0) {
                pbVar7 = &DAT_01eea940;
              }
              else {
                pbVar7 = (byte *)(iVar5 + (iVar4 * iVar10 + iStack_24 * iStack_14 + iStack_34) * 2);
              }
              if ((1 < *pbVar7) && (pbVar7[1] != 0xff)) {
                if (iVar5 == 0) {
                  FUN_00a6e270();
                  iVar4 = iStack_30;
                  iVar5 = iStack_20;
                }
                *(undefined2 *)(iVar5 + (iVar4 * iVar10 + iStack_24 * iStack_14 + iStack_34) * 2) =
                     0;
                iVar4 = iStack_30;
                iVar5 = iStack_20;
              }
              if (iVar5 == 0) {
                pbVar7 = &DAT_01eea940;
              }
              else {
                pbVar7 = (byte *)(iVar5 + (iVar4 * iVar10 + iStack_24 * iStack_14 + uStack_18) * 2);
              }
              if ((1 < *pbVar7) && (pbVar7[1] != 0xff)) {
                if (iVar5 == 0) {
                  FUN_00a6e270();
                  iVar4 = iStack_30;
                  iVar5 = iStack_20;
                }
                *(undefined2 *)(iVar5 + (iVar4 * iVar10 + iStack_24 * iStack_14 + uStack_18) * 2) =
                     0;
                iVar4 = iStack_30;
                iVar5 = iStack_20;
              }
              iVar10 = iVar10 + 1;
              iVar9 = iStack_44;
            } while (iVar10 < iStack_44);
          }
          iStack_14 = iStack_14 + 1;
        } while (iStack_14 < iStack_40);
      }
    }
    else if (param_2 == 1) {
      iStack_14 = 0;
      iVar9 = iStack_28;
      if (0 < iStack_30) {
        do {
          iVar10 = 0;
          if (0 < iVar9) {
            do {
              if (iVar5 == 0) {
                pbVar7 = &DAT_01eea940;
              }
              else {
                pbVar7 = (byte *)(iVar5 + (iStack_24 * iStack_34 + iVar4 * iVar10 + iStack_14) * 2);
              }
              if ((1 < *pbVar7) && (pbVar7[1] != 0xff)) {
                if (iVar5 == 0) {
                  FUN_00a6e270();
                  iVar4 = iStack_30;
                  iVar5 = iStack_20;
                }
                *(undefined2 *)(iVar5 + (iStack_24 * iStack_34 + iVar4 * iVar10 + iStack_14) * 2) =
                     0;
                iVar4 = iStack_30;
                iVar5 = iStack_20;
              }
              if (iVar5 == 0) {
                pbVar7 = &DAT_01eea940;
              }
              else {
                pbVar7 = (byte *)(iVar5 + (iStack_24 * uStack_18 + iVar4 * iVar10 + iStack_14) * 2);
              }
              if ((1 < *pbVar7) && (pbVar7[1] != 0xff)) {
                if (iVar5 == 0) {
                  FUN_00a6e270();
                  iVar4 = iStack_30;
                  iVar5 = iStack_20;
                }
                *(undefined2 *)(iVar5 + (iStack_24 * uStack_18 + iVar4 * iVar10 + iStack_14) * 2) =
                     0;
                iVar4 = iStack_30;
                iVar5 = iStack_20;
              }
              iVar10 = iVar10 + 1;
              iVar9 = iStack_44;
            } while (iVar10 < iStack_44);
          }
          iStack_14 = iStack_14 + 1;
        } while (iStack_14 < iStack_3c);
      }
    }
    else {
      iStack_14 = 0;
      iVar9 = iStack_2c;
      if (0 < iStack_30) {
        do {
          iVar10 = 0;
          if (0 < iVar9) {
            do {
              if (iVar5 == 0) {
                pbVar7 = &DAT_01eea940;
              }
              else {
                pbVar7 = (byte *)(iVar5 + (iVar4 * iStack_34 + iStack_24 * iVar10 + iStack_14) * 2);
              }
              if ((1 < *pbVar7) && (pbVar7[1] != 0xff)) {
                if (iVar5 == 0) {
                  FUN_00a6e270();
                  iVar4 = iStack_30;
                  iVar5 = iStack_20;
                }
                *(undefined2 *)(iVar5 + (iVar4 * iStack_34 + iStack_24 * iVar10 + iStack_14) * 2) =
                     0;
                iVar4 = iStack_30;
                iVar5 = iStack_20;
              }
              if (iVar5 == 0) {
                pbVar7 = &DAT_01eea940;
              }
              else {
                pbVar7 = (byte *)(iVar5 + (iVar4 * uStack_18 + iStack_24 * iVar10 + iStack_14) * 2);
              }
              if ((1 < *pbVar7) && (pbVar7[1] != 0xff)) {
                if (iVar5 == 0) {
                  FUN_00a6e270();
                  iVar4 = iStack_30;
                  iVar5 = iStack_20;
                }
                *(undefined2 *)(iVar5 + (iVar4 * uStack_18 + iStack_24 * iVar10 + iStack_14) * 2) =
                     0;
                iVar4 = iStack_30;
                iVar5 = iStack_20;
              }
              iVar10 = iVar10 + 1;
              iVar9 = iStack_40;
            } while (iVar10 < iStack_40);
          }
          iStack_14 = iStack_14 + 1;
        } while (iStack_14 < iStack_3c);
      }
    }
    *param_3 = aiStack_98[3];
    param_3[1] = iStack_88;
    param_3[2] = iStack_84;
    param_3[3] = iStack_80;
    *(ulonglong *)(param_3 + 4) = CONCAT44(iStack_78,iStack_7c);
    param_3[7] = iStack_2c;
    param_3[8] = iStack_28;
    param_3[6] = iVar4;
    param_3[9] = iStack_24;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
      iVar5 = iStack_20;
    }
    param_3[10] = iVar5;
    piVar6 = (int *)param_3[0xb];
    param_3[0xb] = (int)piStack_1c;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar4 = piVar6[1] + -1;
      piVar6[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        iVar4 = piVar6[2] + -1;
        piVar6[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    param_3[0xc] = uStack_38;
    piVar6 = param_3;
    piVar11 = piStack_1c;
  }
  if (piVar11 != (int *)0x0) {
    LOCK();
    piVar1 = piVar11 + 1;
    iVar4 = *piVar1;
    piVar6 = (int *)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      piVar6 = (int *)(**(code **)*piVar11)();
      LOCK();
      piVar1 = piVar11 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        piVar6 = (int *)(**(code **)(*piVar11 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar6;
}



/* FUNCTION 12439 ; VA 0x0080d910 ; FUN_0080d910 */

undefined4 __thiscall FUN_0080d910(undefined4 param_1,int param_2)

{
  byte bVar1;
  int iVar2;
  byte bVar3;
  uint uVar4;
  
  uVar4 = 0;
  *(undefined *)(param_2 + 0x6b) = 0;
  do {
    iVar2 = FUN_00808fc0(param_2,uVar4);
    if (iVar2 != 0) {
      bVar1 = FUN_00809160();
      if (*(int *)(iVar2 + 0x18) == 0) {
        bVar3 = *(byte *)(iVar2 + 0xd);
      }
      else {
        bVar3 = *(byte *)(*(int *)(iVar2 + 0x18) + 0xd);
      }
      if (bVar3 <= *(byte *)(iVar2 + 0xc)) {
        bVar3 = *(byte *)(iVar2 + 0xc);
      }
      if (bVar1 < bVar3) {
        *(byte *)(param_2 + 0x6b) = *(byte *)(param_2 + 0x6b) | (byte)(1 << (uVar4 & 0x1f));
        if (*(int *)(iVar2 + 0x18) == 0) {
          bVar1 = *(byte *)(iVar2 + 0xd);
        }
        else {
          bVar1 = *(byte *)(*(int *)(iVar2 + 0x18) + 0xd);
        }
        if (bVar1 <= *(byte *)(iVar2 + 0xc)) {
          bVar1 = *(byte *)(iVar2 + 0xc);
        }
        if (bVar1 != *(byte *)(uVar4 + 0xe + param_2)) {
          *(undefined *)(param_2 + 0x11) = 1;
        }
      }
    }
    uVar4 = uVar4 + 1;
  } while ((int)uVar4 < 3);
  return param_1;
}



/* FUNCTION 12440 ; VA 0x0080d9b0 ; FUN_0080d9b0 */

void FUN_0080d9b0(int param_1)

{
  int iVar1;
  undefined uVar2;
  undefined4 uVar3;
  undefined auStack_1c [24];
  
  if ((DAT_01d61f54 == '\0') || (*(char *)(param_1 + 0xc) == '\0')) {
    uVar3 = FUN_008096e0(auStack_1c);
    uVar2 = FUN_00a70880(uVar3);
    *(undefined *)(param_1 + 0xd) = uVar2;
  }
  for (iVar1 = *(int *)(param_1 + 0x18); (iVar1 != 0 && (*(byte *)(iVar1 + 0xc) < 5));
      iVar1 = *(int *)(iVar1 + 0x18)) {
    FUN_0080c1d0(iVar1);
  }
  return;
}



/* FUNCTION 12441 ; VA 0x0080da10 ; FUN_0080da10 */

void __thiscall FUN_0080da10(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined8 *puVar2;
  float *pfVar3;
  undefined *puVar4;
  char cVar5;
  int *piVar6;
  int iVar7;
  byte bVar8;
  undefined4 *puVar9;
  uint uVar10;
  int iVar11;
  int *piVar12;
  int iVar13;
  float10 fVar14;
  double dVar15;
  float fVar16;
  undefined8 uVar17;
  int iStack_124;
  int iStack_120;
  int iStack_11c;
  int iStack_118;
  undefined8 uStack_114;
  int iStack_10c;
  float fStack_108;
  int iStack_104;
  int iStack_100;
  undefined8 uStack_fc;
  float fStack_ec;
  float fStack_e0;
  float fStack_d4;
  float fStack_c8;
  float fStack_bc;
  float fStack_b0;
  undefined4 uStack_ac;
  float fStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined8 uStack_98;
  float fStack_90;
  float fStack_8c;
  undefined8 uStack_88;
  int *piStack_7c;
  int *piStack_78;
  undefined4 uStack_74;
  int *piStack_70;
  int *piStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 *puStack_5c;
  int iStack_58;
  undefined8 uStack_54;
  float fStack_4c;
  undefined8 uStack_48;
  float fStack_40;
  int iStack_3c;
  int iStack_38;
  int *piStack_34;
  int *piStack_30;
  float fStack_2c;
  char cStack_25;
  float fStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017b52ba;
  pvStack_1c = ExceptionList;
  iStack_58 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_1c;
  iStack_3c = param_1;
  puVar4 = &stack0xfffffffc;
  if ((*(int *)(iStack_58 + 0x34) < DAT_01eb3888) &&
     (ExceptionList = &pvStack_1c, FUN_016f3809(&DAT_01eb3888), puVar4 = puStack_20,
     DAT_01eb3888 == -1)) {
    uStack_14 = 0;
    uVar17 = FUN_0152dab0("Render","updateLod",0xffffffff);
    DAT_01eb3884 = (undefined4)((ulonglong)uVar17 >> 0x20);
    DAT_01eb3880 = (undefined4)uVar17;
    uStack_14 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb3888);
    puVar4 = puStack_20;
  }
  puStack_20 = puVar4;
  uStack_64 = DAT_01eb3880;
  uStack_a0 = DAT_01eb3880;
  uStack_60 = DAT_01eb3884;
  uStack_9c = DAT_01eb3884;
  uStack_98 = FUN_0152d930(DAT_01eb3880,DAT_01eb3884);
  piVar6 = (int *)(param_1 + 0x30);
  uStack_14 = 1;
  uVar10 = 0;
  *(undefined4 *)(param_1 + 0x34) = *(undefined4 *)(param_1 + 0x30);
  piStack_34 = piVar6;
  do {
    iStack_38 = *(int *)(param_1 +
                        (((int)uVar10 >> 2 & 1U) +
                        (((int)uVar10 >> 1 & 1U) + 0x1a + (uVar10 & 1) * 2) * 2) * 4);
    if (iStack_38 != 0) {
      piVar12 = (int *)piVar6[1];
      if ((int *)piVar6[2] == piVar12) {
        FUN_006030d0(piVar12,&iStack_38);
        piVar6 = piStack_34;
      }
      else {
        *piVar12 = iStack_38;
        piVar6[1] = piVar6[1] + 4;
      }
    }
    uVar10 = uVar10 + 1;
  } while ((int)uVar10 < 8);
  iVar7 = *piVar6;
  iStack_38 = 0;
  if (3 < (uint)(piVar6[1] - iVar7)) {
    do {
      piVar12 = *(int **)(iVar7 + iStack_38 * 4);
      iStack_38 = iStack_38 + 1;
      bVar8 = *(byte *)(piVar12 + 3);
      piStack_30 = piVar12;
      if (bVar8 < 5) {
        if (bVar8 == 0) {
          if (*(char *)((int)piVar12 + 0x12) == '\0') {
            if (*(int *)(iStack_58 + 0x34) < DAT_01eb3898) {
              FUN_016f3809(&DAT_01eb3898);
              if (DAT_01eb3898 == -1) {
                uStack_14._0_1_ = 2;
                uVar17 = FUN_0152dab0("Render","updateChunkStitchMask",0xffffffff);
                DAT_01eb3894 = (float)((ulonglong)uVar17 >> 0x20);
                DAT_01eb3890 = (float)uVar17;
                uStack_14 = CONCAT31(uStack_14._1_3_,1);
                FUN_016f37bf(&DAT_01eb3898);
              }
            }
            fStack_2c = DAT_01eb3890;
            fStack_90 = DAT_01eb3890;
            fStack_24 = DAT_01eb3894;
            fStack_8c = DAT_01eb3894;
            uVar17 = FUN_0152d930(DAT_01eb3890,DAT_01eb3894);
            *(undefined *)((int)piVar12 + 0x12) = 1;
            uStack_14._0_1_ = 3;
            uStack_88 = uVar17;
            if (piVar12[0xf] == 0) {
              puStack_5c = (undefined4 *)FUN_01674e20(0x3c);
              uStack_14._0_1_ = 4;
              if (puStack_5c == (undefined4 *)0x0) {
                puVar9 = (undefined4 *)0x0;
              }
              else {
                FUN_00841020(*(undefined4 *)(param_1 + 0x20),4);
                *puStack_5c = RBX::Graphics::SmoothCluster::ChunkRenderNode::vftable;
                puStack_5c[0xe] = piVar12;
                puVar9 = puStack_5c;
              }
              puVar1 = (undefined4 *)piVar12[0xf];
              uStack_14._0_1_ = 3;
              piVar12[0xf] = (int)puVar9;
              if (puVar1 != (undefined4 *)0x0) {
                (**(code **)*puVar1)(1);
              }
            }
            FUN_008411b0(piVar12 + 0x25,
                         *(undefined4 *)(*(int *)(*(int *)(param_1 + 0x20) + 0x4e4) + 0x24));
            FUN_0080d910(piVar12);
            uStack_14._0_1_ = 5;
            FUN_0152dda0(fStack_2c,fStack_24,uStack_88);
            uStack_14 = CONCAT31(uStack_14._1_3_,1);
            goto LAB_0080de37;
          }
        }
        else {
          if (DAT_01d61f3c == '\0') {
            bVar8 = bVar8 + 4;
            iVar7 = 1 << (bVar8 & 0x1f);
            fStack_24 = (float)(piVar12[2] << (bVar8 & 0x1f));
            iVar13 = piVar12[1] << (bVar8 & 0x1f);
            iVar11 = *piVar12 << (bVar8 & 0x1f);
            fStack_40 = (float)((int)fStack_24 + iVar7) * DAT_018e3f8c;
            fStack_bc = fStack_40;
            fStack_b0 = (float)(int)fStack_24 * DAT_018e3f8c;
            fStack_4c = (float)(int)fStack_24 * DAT_018e3f8c;
            piVar6 = (int *)&uStack_54;
            uStack_54 = CONCAT44((float)iVar13 * DAT_018e3f8c,(float)iVar11 * DAT_018e3f8c);
            uStack_48 = CONCAT44((float)(iVar13 + iVar7) * DAT_018e3f8c,
                                 (float)(iVar7 + iVar11) * DAT_018e3f8c);
            param_1 = iStack_3c;
          }
          else {
            piVar6 = &iStack_124;
            iStack_124 = piVar12[0x1f];
            iStack_120 = piVar12[0x20];
            iStack_11c = piVar12[0x21];
            iStack_118 = piVar12[0x22];
            uStack_114 = *(undefined8 *)(piVar12 + 0x23);
          }
          iStack_10c = *piVar6;
          fStack_108 = (float)piVar6[1];
          iStack_104 = piVar6[2];
          iStack_100 = piVar6[3];
          uStack_fc = *(undefined8 *)(piVar6 + 4);
          uStack_a4 = param_2[2];
          uStack_ac = *param_2;
          fStack_a8 = ((float)uStack_fc + fStack_108) * DAT_018ce2f4;
          fVar14 = (float10)FUN_00c9ed90(&uStack_ac);
          fStack_24 = (float)fVar14;
          if (*(char *)((int)piVar12 + 0x12) != '\0') {
            if (fStack_24 < (float)(&DAT_01eb3704)[*(byte *)(piVar12 + 3)]) {
              cVar5 = FUN_008085a0(piVar12);
              if (cVar5 != '\0') {
                FUN_0080c0a0(piVar12,fStack_24);
                goto LAB_0080de37;
              }
            }
            if (*(char *)((int)piVar12 + 0x12) != '\0') goto LAB_0080de37;
          }
          if ((float)(&DAT_01eb3718)[*(byte *)(piVar12 + 3)] * DAT_01901940 < fStack_24) {
            if ((piVar12[0x1a] & 0x800000U) == 0) {
LAB_0080dd23:
              FUN_008086b0(piVar12);
              FUN_0080a660(piVar12,1);
              FUN_0080d910(piVar12);
              FUN_0080ee50(piVar12);
            }
            else {
              cVar5 = FUN_0080a3e0(piVar12);
              if (cVar5 == '\0') goto LAB_0080dd23;
              if (DAT_01d61f3c == '\0') {
                FUN_0080a9a0(piVar12,fStack_24);
              }
              else {
                FUN_0080aa20(piVar12,fStack_24);
              }
            }
            if (*(char *)((int)piVar12 + 0x12) != '\0') goto LAB_0080de37;
            goto LAB_0080e1a2;
          }
LAB_0080de37:
          piVar6 = piStack_34;
          if (*(char *)((int)piVar12 + 0x12) == '\0') goto LAB_0080e153;
        }
        if (*(char *)((int)piVar12 + 0x11) != '\0') {
          if (DAT_01d61f3c == '\0') {
            bVar8 = *(char *)(piVar12 + 3) + 4;
            iVar7 = 1 << (bVar8 & 0x1f);
            fStack_2c = (float)(piVar12[2] << (bVar8 & 0x1f));
            iVar13 = piVar12[1] << (bVar8 & 0x1f);
            iVar11 = *piVar12 << (bVar8 & 0x1f);
            fStack_d4 = (float)((int)fStack_2c + iVar7) * DAT_018e3f8c;
            fStack_c8 = (float)(int)fStack_2c * DAT_018e3f8c;
            uStack_48 = CONCAT44((float)(iVar13 + iVar7) * DAT_018e3f8c,
                                 (float)(iVar7 + iVar11) * DAT_018e3f8c);
            uStack_54 = CONCAT44((float)iVar13 * DAT_018e3f8c,(float)iVar11 * DAT_018e3f8c);
            fStack_4c = fStack_c8;
            fStack_40 = fStack_d4;
            fVar14 = (float10)FUN_00c9ed90(param_2);
            piVar12 = piStack_30;
            param_1 = iStack_3c;
          }
          else {
            fVar14 = (float10)FUN_00c9ed90(param_2);
          }
          fStack_24 = (float)fVar14;
          FUN_0080d910(piVar12);
          FUN_0080ee50(piVar12);
          FUN_0080ac40(piVar12,fStack_24);
        }
        if (piVar12[0x10] != piVar12[0x11]) {
          if (DAT_01d61f3c == '\0') {
            bVar8 = *(char *)(piVar12 + 3) + 4;
            iVar7 = 1 << (bVar8 & 0x1f);
            fStack_2c = (float)(piVar12[2] << (bVar8 & 0x1f));
            iVar13 = piVar12[1] << (bVar8 & 0x1f);
            iVar11 = *piVar12 << (bVar8 & 0x1f);
            fStack_ec = (float)((int)fStack_2c + iVar7) * DAT_018e3f8c;
            fStack_e0 = (float)(int)fStack_2c * DAT_018e3f8c;
            uStack_54 = CONCAT44((float)iVar13 * DAT_018e3f8c,(float)iVar11 * DAT_018e3f8c);
            uStack_48 = CONCAT44((float)(iVar13 + iVar7) * DAT_018e3f8c,
                                 (float)(iVar7 + iVar11) * DAT_018e3f8c);
            fStack_4c = fStack_e0;
            fStack_40 = fStack_ec;
            fVar14 = (float10)FUN_00c9ed90(param_2);
            piVar12 = piStack_30;
            param_1 = iStack_3c;
          }
          else {
            fVar14 = (float10)FUN_00c9ed90(param_2);
          }
          fStack_24 = (float)fVar14;
          dVar15 = (double)fStack_24;
          FUN_017267a0();
          piStack_30 = (int *)(float)dVar15;
          fVar14 = (float10)FUN_01156580();
          fStack_2c = (float)fVar14;
          if ((piVar12[0x14] == piVar12[0x16]) && (piVar12[0x15] == piVar12[0x17])) {
            cVar5 = '\0';
          }
          else {
            cVar5 = '\x01';
          }
          if ((piVar12[0x14] != piVar12[0x18]) || (cStack_25 = '\0', piVar12[0x15] != piVar12[0x19])
             ) {
            cStack_25 = '\x01';
          }
          fStack_24 = fStack_2c;
          if (fStack_2c <= (float)piStack_30) {
            puVar9 = (undefined4 *)piVar12[0x1d];
            piVar12[0x1d] = 0;
            if (puVar9 != (undefined4 *)0x0) {
              (**(code **)*puVar9)(1);
            }
          }
          else if ((piVar12[0x1d] == 0) || (cVar5 != '\0')) {
            piStack_6c = piVar12 + 0x1d;
            puVar2 = *(undefined8 **)(param_1 + 300);
            piStack_70 = piVar12;
            uStack_68 = CONCAT31(uStack_68._1_3_,cVar5);
            if (*(undefined8 **)(param_1 + 0x130) == puVar2) {
              FUN_008059a0(puVar2,&piStack_70);
            }
            else {
              *puVar2 = CONCAT44(piVar12 + 0x1d,piVar12);
              *(undefined4 *)(puVar2 + 1) = uStack_68;
              *(int *)(param_1 + 300) = *(int *)(param_1 + 300) + 0xc;
            }
          }
          fVar16 = fStack_24;
          if (DAT_018df584 <= fStack_24) {
            fVar16 = DAT_018df584;
          }
          if (fVar16 <= (float)piStack_30) {
            puVar9 = (undefined4 *)piVar12[0x1e];
            piVar12[0x1e] = 0;
            if (puVar9 != (undefined4 *)0x0) {
              (**(code **)*puVar9)(1);
            }
          }
          else if ((piVar12[0x1e] == 0) || (cStack_25 != '\0')) {
            piStack_78 = piVar12 + 0x1e;
            puVar2 = *(undefined8 **)(param_1 + 300);
            piStack_7c = piVar12;
            uStack_74 = CONCAT31(uStack_74._1_3_,cStack_25);
            if (*(undefined8 **)(param_1 + 0x130) == puVar2) {
              FUN_008059a0(puVar2,&piStack_7c);
            }
            else {
              *puVar2 = CONCAT44(piVar12 + 0x1e,piVar12);
              *(undefined4 *)(puVar2 + 1) = uStack_74;
              *(int *)(param_1 + 300) = *(int *)(param_1 + 300) + 0xc;
            }
          }
        }
      }
      else {
LAB_0080e153:
        uVar10 = 0;
        do {
          fStack_2c = (float)piVar12[((int)uVar10 >> 2 & 1U) +
                                     (((int)uVar10 >> 1 & 1U) + (uVar10 & 1) * 2) * 2 + 7];
          if (fStack_2c != 0.0) {
            pfVar3 = (float *)piVar6[1];
            if ((float *)piVar6[2] == pfVar3) {
              FUN_006030d0(pfVar3,&fStack_2c);
            }
            else {
              *pfVar3 = fStack_2c;
              piVar6[1] = piVar6[1] + 4;
            }
          }
          uVar10 = uVar10 + 1;
          piVar6 = piStack_34;
          param_1 = iStack_3c;
        } while ((int)uVar10 < 8);
      }
LAB_0080e1a2:
      iVar7 = *piStack_34;
      piVar6 = piStack_34;
    } while (iStack_38 != piStack_34[1] - iVar7 >> 2);
  }
  uStack_14 = 6;
  FUN_0152dda0(uStack_64,uStack_60,uStack_98);
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 12442 ; VA 0x0080e2a0 ; FUN_0080e2a0 */

void __thiscall FUN_0080e2a0(int param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  char cVar4;
  undefined uVar5;
  uint uVar6;
  float10 fVar7;
  float fVar8;
  float fVar9;
  double dVar10;
  char cStack_2d;
  undefined8 uStack_28;
  int iStack_20;
  int *piStack_1c;
  char cStack_18;
  
  if (4 < *(byte *)(param_3 + 0xc)) {
    uVar6 = 0;
    do {
      iVar1 = *(int *)(param_3 + 0x1c +
                      (((int)uVar6 >> 2 & 1U) + (((int)uVar6 >> 1 & 1U) + (uVar6 & 1) * 2) * 2) * 4)
      ;
      if (iVar1 != 0) {
        FUN_0080e2a0(param_2,iVar1);
      }
      uVar6 = uVar6 + 1;
    } while ((int)uVar6 < 8);
    return;
  }
  if (*(byte *)(param_3 + 0xc) == 0) {
    if (*(char *)(param_3 + 0x12) == '\0') {
      FUN_0080a660(param_3,1);
      FUN_0080d910(param_3);
      goto LAB_0080e3fe;
    }
  }
  else {
    fVar7 = (float10)FUN_008087f0(param_2);
    dVar10 = (double)fVar7;
    uStack_28 = dVar10;
    FUN_017267a0();
    fVar8 = (float)dVar10;
    dVar10 = DAT_01900c48;
    FUN_01726ab0();
    fVar9 = (((float)dVar10 - DAT_018ce2f8) * DAT_01901960) / DAT_01901940;
    uStack_28 = (double)CONCAT44(uStack_28._4_4_,fVar9);
    if (*(char *)(param_3 + 0x12) == '\0') {
LAB_0080e3be:
      if ((fVar9 * DAT_01901940 < fVar8) &&
         (FUN_0080c020(param_3,fVar8), *(char *)(param_3 + 0x12) == '\0')) {
        return;
      }
    }
    else if ((fVar9 * DAT_0190193c <= fVar8) || (cVar4 = FUN_008085a0(param_3), cVar4 == '\0')) {
      fVar9 = (float)uStack_28;
      if (*(char *)(param_3 + 0x12) == '\0') goto LAB_0080e3be;
    }
    else {
      FUN_0080c0a0(param_3,fVar8);
    }
LAB_0080e3fe:
    if (*(char *)(param_3 + 0x12) == '\0') {
      uVar6 = 0;
      do {
        iVar1 = *(int *)(param_3 + 0x1c +
                        (((int)uVar6 >> 2 & 1U) + (((int)uVar6 >> 1 & 1U) + (uVar6 & 1) * 2) * 2) *
                        4);
        if (iVar1 != 0) {
          FUN_0080e2a0(param_2,iVar1);
        }
        uVar6 = uVar6 + 1;
      } while ((int)uVar6 < 8);
      return;
    }
  }
  if (DAT_01d61f3c == '\0') {
    FUN_00809230(&iStack_20);
  }
  fVar7 = (float10)FUN_00c9ed90(param_2);
  uStack_28 = (double)CONCAT44(uStack_28._4_4_,(float)fVar7);
  dVar10 = (double)(float)fVar7;
  FUN_017267a0();
  fVar9 = (float)dVar10;
  if (*(char *)(param_3 + 0x11) != '\0') {
    FUN_0080d910(param_3);
    FUN_0080ee50(param_3);
    if (*(char *)(param_3 + 0x11) != '\0') {
      piVar2 = *(int **)(param_1 + 0x114);
      fVar8 = fVar9 - (float)*(byte *)(param_3 + 0x13) * DAT_019011dc;
      uStack_28 = (double)CONCAT44(fVar8,param_3);
      if (*(int **)(param_1 + 0x118) == piVar2) {
        FUN_00805800(piVar2,&uStack_28);
      }
      else {
        *piVar2 = param_3;
        piVar2[1] = (int)fVar8;
        *(int *)(param_1 + 0x114) = *(int *)(param_1 + 0x114) + 8;
      }
      uVar6 = *(byte *)(param_3 + 0x13) + 1;
      uVar5 = (undefined)uVar6;
      if (0xff < uVar6) {
        uVar5 = 0xff;
      }
      *(undefined *)(param_3 + 0x13) = uVar5;
    }
  }
  if (*(int *)(param_3 + 0x40) == *(int *)(param_3 + 0x44)) {
    return;
  }
  fVar7 = (float10)FUN_01156580();
  fVar8 = (float)fVar7;
  uStack_28 = (double)CONCAT44(uStack_28._4_4_,fVar8);
  if ((*(int *)(param_3 + 0x50) == *(int *)(param_3 + 0x58)) &&
     (*(int *)(param_3 + 0x54) == *(int *)(param_3 + 0x5c))) {
    cVar4 = '\0';
  }
  else {
    cVar4 = '\x01';
  }
  if ((*(int *)(param_3 + 0x50) != *(int *)(param_3 + 0x60)) ||
     (cStack_2d = '\0', *(int *)(param_3 + 0x54) != *(int *)(param_3 + 100))) {
    cStack_2d = '\x01';
  }
  piVar2 = (int *)(param_3 + 0x74);
  puVar3 = (undefined4 *)*piVar2;
  if (fVar8 <= fVar9) {
    *piVar2 = 0;
    if (puVar3 == (undefined4 *)0x0) goto LAB_0080e56c;
    (**(code **)*puVar3)(1);
  }
  else {
    if ((puVar3 != (undefined4 *)0x0) && (cVar4 == '\0')) goto LAB_0080e56c;
    iStack_20 = param_3;
    piStack_1c = piVar2;
    cStack_18 = cVar4;
    FUN_0080a8a0(&iStack_20);
  }
  fVar8 = (float)uStack_28;
LAB_0080e56c:
  if (DAT_018df584 <= fVar8) {
    fVar8 = DAT_018df584;
  }
  puVar3 = *(undefined4 **)(param_3 + 0x78);
  if (fVar8 <= fVar9) {
    *(undefined4 *)(param_3 + 0x78) = 0;
    if (puVar3 != (undefined4 *)0x0) {
      (**(code **)*puVar3)(1);
      return;
    }
  }
  else if ((puVar3 == (undefined4 *)0x0) || (cStack_2d != '\0')) {
    cStack_18 = cStack_2d;
    iStack_20 = param_3;
    piStack_1c = (undefined4 *)(param_3 + 0x78);
    FUN_0080a8a0(&iStack_20);
    return;
  }
  return;
}



/* FUNCTION 12443 ; VA 0x0080e610 ; FUN_0080e610 */

void __fastcall FUN_0080e610(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  float *pfVar4;
  float *pfVar5;
  int *piVar6;
  int *piVar7;
  uint *puVar8;
  float fVar9;
  uint **ppuVar10;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  undefined4 uStack_34;
  uint *puStack_30;
  int *piStack_2c;
  uint *puStack_28;
  uint *puStack_24;
  int iStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  float *pfStack_10;
  int iStack_c;
  char cStack_5;
  
  *(undefined4 *)(param_1 + 0x8c) = *(undefined4 *)(param_1 + 0x88);
  piVar7 = (int *)(param_1 + 0x88);
  *(undefined4 *)(param_1 + 0x98) = *(undefined4 *)(param_1 + 0x94);
  piStack_18 = *(int **)(param_1 + 0x84);
  iStack_20 = piStack_18[2] + piStack_18[4] * 2;
  piStack_2c = piVar7;
  iStack_c = param_1;
  puVar1 = (undefined4 *)FUN_00d58760();
  puStack_14 = puVar1 + 0x36;
  if (puVar1 != puStack_14) {
    puVar1 = puVar1 + 2;
    do {
      puVar2 = *(undefined4 **)(param_1 + 0x8c);
      pfStack_10 = (float *)puVar1;
      if (*(undefined4 **)(param_1 + 0x90) == puVar2) {
        FUN_007d74c0(puVar2,puVar1 + -2);
        puVar2 = *(undefined4 **)(param_1 + 0x8c);
      }
      else {
        *puVar2 = puVar1[-2];
        puVar2 = puVar2 + 1;
        *(undefined4 **)(param_1 + 0x8c) = puVar2;
      }
      if (*(undefined4 **)(param_1 + 0x90) == puVar2) {
        FUN_007d74c0(puVar2,pfStack_10 + -1);
        puVar2 = *(undefined4 **)(param_1 + 0x8c);
      }
      else {
        *puVar2 = pfStack_10[-1];
        puVar2 = puVar2 + 1;
        *(undefined4 **)(param_1 + 0x8c) = puVar2;
      }
      if (*(undefined4 **)(param_1 + 0x90) == puVar2) {
        FUN_007d74c0(puVar2,pfStack_10);
        puVar2 = *(undefined4 **)(param_1 + 0x8c);
      }
      else {
        *puVar2 = *pfStack_10;
        puVar2 = puVar2 + 1;
        *(undefined4 **)(param_1 + 0x8c) = puVar2;
      }
      iStack_1c = 0;
      if (*(undefined4 **)(param_1 + 0x90) == puVar2) {
        FUN_007d74c0(puVar2,&iStack_1c);
      }
      else {
        *puVar2 = 0;
        *(undefined4 **)(param_1 + 0x8c) = puVar2 + 1;
      }
      puVar1 = pfStack_10 + 3;
      puVar2 = pfStack_10 + 1;
      pfStack_10 = (float *)puVar1;
    } while (puVar2 != puStack_14);
  }
  puVar1 = (undefined4 *)FUN_00d58770();
  puStack_14 = puVar1 + 0x36;
  if (puVar1 != puStack_14) {
    puVar1 = puVar1 + 2;
    do {
      puVar2 = *(undefined4 **)(param_1 + 0x8c);
      pfStack_10 = (float *)puVar1;
      if (*(undefined4 **)(param_1 + 0x90) == puVar2) {
        FUN_007d74c0(puVar2,puVar1 + -2);
        puVar2 = *(undefined4 **)(param_1 + 0x8c);
      }
      else {
        *puVar2 = puVar1[-2];
        puVar2 = puVar2 + 1;
        *(undefined4 **)(param_1 + 0x8c) = puVar2;
      }
      if (*(undefined4 **)(param_1 + 0x90) == puVar2) {
        FUN_007d74c0(puVar2,pfStack_10 + -1);
        puVar2 = *(undefined4 **)(param_1 + 0x8c);
      }
      else {
        *puVar2 = pfStack_10[-1];
        puVar2 = puVar2 + 1;
        *(undefined4 **)(param_1 + 0x8c) = puVar2;
      }
      if (*(undefined4 **)(param_1 + 0x90) == puVar2) {
        FUN_007d74c0(puVar2,pfStack_10);
        puVar2 = *(undefined4 **)(param_1 + 0x8c);
      }
      else {
        *puVar2 = *pfStack_10;
        puVar2 = puVar2 + 1;
        *(undefined4 **)(param_1 + 0x8c) = puVar2;
      }
      iStack_1c = 0;
      if (*(undefined4 **)(param_1 + 0x90) == puVar2) {
        FUN_007d74c0(puVar2,&iStack_1c);
      }
      else {
        *puVar2 = 0;
        *(undefined4 **)(param_1 + 0x8c) = puVar2 + 1;
      }
      puVar1 = pfStack_10 + 3;
    } while (pfStack_10 + 1 != (float *)puStack_14);
  }
  puStack_14 = (undefined4 *)0x0;
  pfStack_10 = *(float **)(iStack_c + 0x84);
  iVar3 = ((int *)pfStack_10)[9] - ((int *)pfStack_10)[8] >> 0x1f;
  if ((((int *)pfStack_10)[9] - ((int *)pfStack_10)[8]) / 0x1c + iVar3 != iVar3) {
    iStack_1c = 0;
    do {
      pfStack_10 = (float *)(((int *)pfStack_10)[8] + iStack_1c);
      puStack_24 = (uint *)(*pfStack_10 * DAT_018e1340);
      pfVar4 = (float *)piVar7[1];
      if (DAT_01d6d168 == '\0') {
        if ((float *)piVar7[2] == pfVar4) {
          FUN_007d74c0(pfVar4,&puStack_24);
          pfVar5 = (float *)piVar7[1];
        }
        else {
          pfVar5 = pfVar4 + 1;
          *pfVar4 = (float)puStack_24;
          piVar7[1] = (int)pfVar5;
        }
        if ((float *)piVar7[2] == pfVar5) {
          FUN_007d74c0(pfVar5,pfStack_10 + 1);
        }
        else {
          *pfVar5 = pfStack_10[1];
          piVar7[1] = (int)(pfVar5 + 1);
        }
      }
      else {
        if ((float *)piVar7[2] == pfVar4) {
          FUN_007d74c0(pfVar4,&puStack_24);
          pfVar4 = (float *)piVar7[1];
        }
        else {
          *pfVar4 = (float)puStack_24;
          pfVar4 = pfVar4 + 1;
          piVar7[1] = (int)pfVar4;
        }
        puStack_24 = (uint *)(DAT_018ce2f8 / pfStack_10[1]);
        if ((float *)piVar7[2] == pfVar4) {
          FUN_007d74c0(pfVar4,&puStack_24);
        }
        else {
          *pfVar4 = (float)puStack_24;
          piVar7[1] = (int)(pfVar4 + 1);
        }
      }
      iVar3 = (**(code **)(**(int **)(*(int *)(iStack_c + 0x20) + 0x3c) + 0x40))();
      if (*(char *)(iVar3 + 0x19) == '\0') {
        puStack_28 = (uint *)(piStack_18 + 3);
        iVar3 = ((uint)puStack_14 % *puStack_28) * iStack_20 + piStack_18[4];
        pfVar4 = (float *)piVar7[1];
        puStack_24 = (uint *)((float)((double)iVar3 + (double)(&DAT_018c0d90)[-(iVar3 >> 0x1f)]) /
                             (float)*piStack_18);
        if ((float *)piVar7[2] == pfVar4) {
          FUN_007d74c0(pfVar4,&puStack_24);
          pfVar5 = (float *)piVar7[1];
        }
        else {
          pfVar5 = pfVar4 + 1;
          *pfVar4 = (float)puStack_24;
          piVar7[1] = (int)pfVar5;
        }
        iVar3 = ((uint)puStack_14 / *puStack_28) * iStack_20 + piStack_18[4];
        puStack_28 = (uint *)((float)((double)iVar3 + (double)(&DAT_018c0d90)[-(iVar3 >> 0x1f)]) /
                             (float)piStack_18[1]);
        piVar7 = piStack_2c;
        if ((float *)piStack_2c[2] == pfVar5) {
          ppuVar10 = &puStack_28;
          goto LAB_0080e9e9;
        }
        *pfVar5 = (float)puStack_28;
        piStack_2c[1] = (int)(pfVar5 + 1);
      }
      else {
        pfVar5 = (float *)piVar7[1];
        if ((float *)piVar7[2] == pfVar5) {
          FUN_007d74c0(pfVar5,pfStack_10 + 2);
          pfVar5 = (float *)piVar7[1];
        }
        else {
          *pfVar5 = pfStack_10[2];
          pfVar5 = pfVar5 + 1;
          piVar7[1] = (int)pfVar5;
        }
        puStack_24 = (uint *)0x0;
        if ((float *)piVar7[2] == pfVar5) {
          ppuVar10 = &puStack_24;
LAB_0080e9e9:
          FUN_007d74c0(pfVar5,ppuVar10);
        }
        else {
          *pfVar5 = 0.0;
          piVar7[1] = (int)(pfVar5 + 1);
        }
      }
      fVar9 = pfStack_10[5] - pfStack_10[4];
      pfVar4 = *(float **)(param_1 + 0x98);
      puStack_28 = (uint *)(DAT_018ce2f8 / fVar9);
      puStack_30 = (uint *)((uint)(pfStack_10[4] / fVar9) ^ DAT_018c4ea0);
      puStack_24 = puStack_30;
      if (*(float **)(param_1 + 0x9c) == pfVar4) {
        FUN_007d74c0(pfVar4,&puStack_28);
        pfVar4 = *(float **)(param_1 + 0x98);
      }
      else {
        *pfVar4 = (float)puStack_28;
        pfVar4 = pfVar4 + 1;
        *(float **)(param_1 + 0x98) = pfVar4;
      }
      if (*(float **)(param_1 + 0x9c) == pfVar4) {
        FUN_007d74c0(pfVar4,&puStack_30);
        pfVar5 = *(float **)(param_1 + 0x98);
      }
      else {
        pfVar5 = pfVar4 + 1;
        *pfVar4 = (float)puStack_24;
        *(float **)(param_1 + 0x98) = pfVar5;
      }
      if (*(float **)(param_1 + 0x9c) == pfVar5) {
        FUN_007d74c0(pfVar5,pfStack_10 + 6);
        pfVar5 = *(float **)(param_1 + 0x98);
      }
      else {
        *pfVar5 = pfStack_10[6];
        pfVar5 = pfVar5 + 1;
        *(float **)(param_1 + 0x98) = pfVar5;
      }
      puStack_30 = (uint *)0x0;
      if (*(float **)(param_1 + 0x9c) == pfVar5) {
        FUN_007d74c0(pfVar5,&puStack_30);
      }
      else {
        *pfVar5 = 0.0;
        *(float **)(param_1 + 0x98) = pfVar5 + 1;
      }
      puStack_14 = (undefined4 *)((int)puStack_14 + 1);
      iStack_1c = iStack_1c + 0x1c;
      pfStack_10 = *(float **)(iStack_c + 0x84);
    } while (puStack_14 < (uint)((((int *)pfStack_10)[9] - ((int *)pfStack_10)[8]) / 0x1c));
  }
  if (*(int *)(iStack_c + 0x68) != 0) {
    iStack_1c = 0;
    do {
      iVar3 = iStack_c;
      fStack_38 = 0.0;
      if (DAT_01d61f34 != '\0') {
        fStack_38 = DAT_018ce2f8 / *(float *)(*(int *)(iStack_c + 0x20) + 0xb0);
      }
      uStack_34 = 0;
      fStack_40 = (float)(int)pfStack_10[2] / (float)(int)*pfStack_10;
      fStack_3c = (float)(int)pfStack_10[2] / (float)(int)pfStack_10[1];
      cStack_5 = FUN_00afc8d0();
      piVar6 = (int *)(*(int *)(iVar3 + 0x68) + iStack_1c);
      puStack_30 = (uint *)piVar6[1];
      puVar8 = (uint *)*piVar6;
      if (puVar8 != puStack_30) {
        do {
          FUN_0078e4a0(2,*piVar7,piVar7[1] - *piVar7 & 0xfffffffc);
          FUN_0078e4a0(3,&fStack_40,0x10);
          if (cStack_5 != '\0') {
            FUN_0078e4a0(4,*(int *)(iStack_c + 0xa0),
                         *(int *)(iStack_c + 0xa4) - *(int *)(iStack_c + 0xa0) & 0xfffffff0);
          }
          iVar3 = (**(code **)(**(int **)(*(int *)(iStack_c + 0x20) + 0x3c) + 0x40))();
          if (*(char *)(iVar3 + 0x19) != '\0') {
            FUN_0078e4a0(5,*(int *)(iStack_c + 0x94),
                         *(int *)(iStack_c + 0x98) - *(int *)(iStack_c + 0x94) & 0xfffffffc);
          }
          puVar8 = puVar8 + 0x14;
        } while (puVar8 != puStack_30);
      }
      iStack_1c = iStack_1c + 0xc;
    } while (iStack_1c < 0x24);
  }
  if (*(int *)(iStack_c + 0x70) != 0) {
    iStack_20 = 0;
    do {
      puVar8 = *(uint **)(*(int *)(iStack_c + 0x70) + iStack_20);
      puStack_30 = *(uint **)(*(int *)(iStack_c + 0x70) + iStack_20 + 4);
      if (puVar8 != puStack_30) {
        do {
          FUN_0078e4a0(2,*piVar7,piVar7[1] - *piVar7 & 0xfffffffc);
          puVar8 = puVar8 + 0x14;
        } while (puVar8 != puStack_30);
      }
      iStack_20 = iStack_20 + 0xc;
    } while (iStack_20 < 0x24);
  }
  return;
}



/* FUNCTION 12444 ; VA 0x0080ec90 ; FUN_0080ec90 */

void __fastcall FUN_0080ec90(int param_1)

{
  int iVar1;
  float *pfVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  float fVar8;
  double dVar9;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  undefined4 uStack_4c;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  double dStack_18;
  float fStack_10;
  int iStack_c;
  uint uStack_8;
  
  *(undefined4 *)(param_1 + 0xa4) = *(undefined4 *)(param_1 + 0xa0);
  iVar6 = *(int *)(param_1 + 0x84);
  uStack_8 = 0;
  iVar5 = *(int *)(iVar6 + 0x24) - *(int *)(iVar6 + 0x20);
  iVar1 = iVar5 >> 0x1f;
  if (iVar5 / 0x1c + iVar1 != iVar1) {
    iStack_c = 0;
    do {
      iVar1 = *(int *)(*(int *)(param_1 + 0x24) + 0x160);
      iVar6 = *(int *)(*(int *)(iVar6 + 0x20) + 0xc + iStack_c) * 3;
      uVar4 = FUN_0115e8a0(*(int *)(*(int *)(param_1 + 0x24) + 0x16c) + iVar6);
      FUN_0115eba0(&fStack_30,uVar4);
      uVar4 = FUN_0115e8a0(iVar1 + iVar6);
      FUN_0115eba0(&fStack_24,uVar4);
      fVar8 = 0.0;
      if (0.0 <= fStack_1c / fStack_28) {
        fVar8 = fStack_1c / fStack_28;
      }
      fStack_58 = DAT_018daf58;
      if (fVar8 <= DAT_018daf58) {
        fStack_58 = fVar8;
      }
      dVar9 = (double)((fStack_24 - fStack_30) * DAT_019011e0 * DAT_0190119c);
      fVar8 = 0.0;
      if (0.0 <= fStack_20 / fStack_2c) {
        fVar8 = fStack_20 / fStack_2c;
      }
      fStack_10 = DAT_018daf58;
      if (fVar8 <= DAT_018daf58) {
        fStack_10 = fVar8;
      }
      fStack_10 = fStack_10 * fStack_58;
      dStack_18 = dVar9;
      FUN_017279f0();
      uVar4 = SUB84(dStack_18,0);
      uVar7 = (undefined4)((ulonglong)dStack_18 >> 0x20);
      fStack_54 = (float)dVar9 * fStack_10;
      FUN_01728390();
      pfVar2 = *(float **)(param_1 + 0xa4);
      uStack_4c = 0;
      fStack_50 = (float)(double)CONCAT44(uVar7,uVar4) * fStack_10;
      if (*(float **)(param_1 + 0xa8) == pfVar2) {
        FUN_006038a0(pfVar2,&fStack_58);
      }
      else {
        *pfVar2 = fStack_58;
        pfVar2[1] = fStack_54;
        pfVar2[2] = fStack_50;
        pfVar2[3] = 0.0;
        *(int *)(param_1 + 0xa4) = *(int *)(param_1 + 0xa4) + 0x10;
      }
      iVar6 = *(int *)(param_1 + 0x84);
      uStack_8 = uStack_8 + 1;
      iStack_c = iStack_c + 0x1c;
    } while (uStack_8 < (uint)((*(int *)(iVar6 + 0x24) - *(int *)(iVar6 + 0x20)) / 0x1c));
  }
  cVar3 = FUN_00afc8d0();
  if ((*(char *)(param_1 + 0xcc) != cVar3) &&
     (*(char *)(param_1 + 0xcc) = cVar3, *(int *)(param_1 + 0x68) != 0)) {
    FUN_00810240();
  }
  return;
}



/* FUNCTION 12445 ; VA 0x0080ee50 ; FUN_0080ee50 */

void FUN_0080ee50(undefined8 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined8 uStack_10;
  undefined4 uStack_8;
  
  uVar3 = 0;
  do {
    uStack_10 = *param_1;
    uStack_8 = *(undefined4 *)(param_1 + 1);
    piVar1 = (int *)((int)&uStack_10 + (uVar3 % 3) * 4);
    *piVar1 = *piVar1 + (uint)((int)uVar3 < 3) * 2 + -1;
    iVar2 = FUN_008090b0(&uStack_10,*(undefined *)((int)param_1 + 0xc));
    if (iVar2 != 0) {
      FUN_0080eed0(iVar2,uVar3 % 3,2 < (int)uVar3);
    }
    uVar3 = uVar3 + 1;
  } while ((int)uVar3 < 6);
  return;
}



/* FUNCTION 12446 ; VA 0x0080eed0 ; FUN_0080eed0 */

void FUN_0080eed0(int param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar1 = param_1;
  if (*(char *)(param_1 + 0x12) != '\0') {
    FUN_0080d910(param_1);
  }
  param_1 = 0;
  iVar3 = param_3 * 2;
  do {
    iVar4 = 0;
    do {
      if (param_2 == 0) {
        iVar2 = iVar4 + (param_3 * 2 + param_1) * 2;
      }
      else if (param_2 == 1) {
        iVar2 = iVar3 + iVar4;
      }
      else {
        iVar2 = param_3 + (iVar4 + param_1 * 2) * 2;
      }
      iVar2 = *(int *)(iVar1 + 0x1c + iVar2 * 4);
      if (iVar2 != 0) {
        if (*(char *)(iVar2 + 0x12) == '\0') {
          FUN_0080eed0(iVar2,param_2,param_3);
        }
        else {
          FUN_0080d910(iVar2);
        }
      }
      iVar4 = iVar4 + 1;
    } while (iVar4 < 2);
    param_1 = param_1 + 1;
    iVar3 = iVar3 + 4;
  } while (param_1 < 2);
  return;
}



/* FUNCTION 12447 ; VA 0x0080ef80 ; FUN_0080ef80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_0080ef80(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  undefined uVar4;
  double *pdVar5;
  undefined4 uVar6;
  int iVar7;
  uint *puVar8;
  byte bVar9;
  uint uVar10;
  undefined4 *puVar11;
  int iVar12;
  uint *puVar13;
  int *piVar14;
  uint *puVar15;
  int iVar16;
  float10 fVar17;
  undefined8 uVar18;
  undefined4 uVar19;
  undefined8 uStack_a8;
  float fStack_a0;
  undefined8 uStack_9c;
  float fStack_94;
  double dStack_90;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  undefined4 uStack_68;
  undefined4 uStack_64;
  int *piStack_60;
  undefined uStack_5c;
  undefined uStack_5b;
  undefined4 uStack_58;
  float fStack_54;
  undefined2 auStack_50 [2];
  undefined4 uStack_4c;
  undefined2 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  uint *puStack_38;
  undefined4 uStack_34;
  undefined2 auStack_30 [2];
  double dStack_2c;
  uint uStack_24;
  int *piStack_20;
  uint uStack_1c;
  int iStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b530b;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x28) != 0) {
    piStack_20 = *(int **)((int)ThreadLocalStoragePointer + _tls_index * 4);
    ExceptionList = &pvStack_10;
    iStack_18 = param_1;
    if ((piStack_20[0xd] < DAT_01eb3858) &&
       (ExceptionList = &pvStack_10, FUN_016f3809(), DAT_01eb3858 == -1)) {
      uStack_8 = 0;
      uVar18 = FUN_0152dab0("Render","updateTerrainPerform",0xffffffff);
      DAT_01eb3854 = (undefined4)((ulonglong)uVar18 >> 0x20);
      DAT_01eb3850 = (undefined4)uVar18;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb3858);
    }
    uStack_44 = DAT_01eb3850;
    uStack_88 = DAT_01eb3850;
    uStack_68 = DAT_01eb3854;
    uStack_84 = DAT_01eb3854;
    uStack_80 = FUN_0152d930(DAT_01eb3850,DAT_01eb3854);
    uStack_8 = 1;
    uStack_34 = FUN_01675290(DAT_01eb36d8);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_016827e0(&dStack_90);
    puVar1 = *(undefined4 **)(param_1 + 0x120);
    for (puVar11 = *(undefined4 **)(param_1 + 0x11c); puVar11 != puVar1; puVar11 = puVar11 + 0x2e) {
      FUN_0080c300(*puVar11,puVar11);
      if (*(char *)(*(int *)(*(int *)(param_1 + 0x20) + 0x510) + 0x2c) == '\0') {
        pdVar5 = (double *)FUN_016827e0();
        if (_PTR_018dad08 < (*pdVar5 - dStack_90) * DAT_018c0d70) break;
      }
    }
    if (*(int *)(param_1 + 0x128) != *(int *)(param_1 + 300)) {
      FUN_016827e0();
      uVar6 = FUN_01675290(DAT_01eb36dc);
      uStack_8._0_1_ = 3;
      uStack_64 = uVar6;
      if (piStack_20[0xd] < DAT_01eb3868) {
        FUN_016f3809();
        if (DAT_01eb3868 == -1) {
          uStack_8._0_1_ = 4;
          uVar18 = FUN_0152dab0("Render","plantGrass",0xffffffff);
          DAT_01eb3864 = (undefined4)((ulonglong)uVar18 >> 0x20);
          DAT_01eb3860 = (undefined4)uVar18;
          uStack_8._0_1_ = 3;
          FUN_016f37bf(&DAT_01eb3868);
        }
      }
      uVar18 = CONCAT44(DAT_01eb3864,DAT_01eb3860);
      uStack_40 = (double)CONCAT44(DAT_01eb3860,(undefined4)uStack_40);
      uStack_78 = DAT_01eb3860;
      puStack_38 = (uint *)DAT_01eb3864;
      uStack_74 = DAT_01eb3864;
      uStack_70 = FUN_0152d930(DAT_01eb3860,DAT_01eb3864);
      iVar3 = iStack_18;
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      iVar16 = (*(int *)(iStack_18 + 300) - *(int *)(iStack_18 + 0x128)) / 0xc;
      uVar19 = uStack_44;
      FUN_008064e0(*(undefined4 *)(iStack_18 + 0x128),*(int *)(iStack_18 + 300),iVar16,uStack_44);
      piStack_60 = *(int **)(iVar3 + 300);
      piVar14 = *(int **)(iVar3 + 0x128);
      if (piVar14 != piStack_60) {
        do {
          piVar2 = (int *)*piVar14;
          piStack_20 = (int *)piVar14[1];
          uStack_24 = CONCAT31(uStack_24._1_3_,piStack_20 == piVar2 + 0x1e);
          bVar9 = *(char *)(piVar2 + 3) + 4;
          puStack_14 = (uint *)(piVar2[1] << (bVar9 & 0x1f));
          iVar7 = 1 << (bVar9 & 0x1f);
          uStack_1c = piVar2[2] << (bVar9 & 0x1f);
          uVar18 = CONCAT44(uStack_24,(int)uVar18);
          iVar12 = *piVar2 << (bVar9 & 0x1f);
          fStack_94 = (float)(int)(uStack_1c + iVar7) * DAT_018e3f8c;
          fStack_a0 = (float)(int)uStack_1c * DAT_018e3f8c;
          uStack_9c = CONCAT44((float)((int)puStack_14 + iVar7) * DAT_018e3f8c,
                               (float)(iVar7 + iVar12) * DAT_018e3f8c);
          uStack_a8 = CONCAT44((float)(int)puStack_14 * DAT_018e3f8c,(float)iVar12 * DAT_018e3f8c);
          fStack_54 = fStack_a0;
          FUN_00806da0(*piVar14 + 0x40);
          FUN_00863ec0(piStack_20,&uStack_a8,iVar16,uVar19,uVar18);
          iVar7 = *piVar14;
          *(undefined4 *)(iVar7 + 0x58 + (uStack_24 & 0xff) * 8) = *(undefined4 *)(iVar7 + 0x50);
          *(undefined4 *)(iVar7 + 0x5c + (uStack_24 & 0xff) * 8) = *(undefined4 *)(iVar7 + 0x54);
          if (*(char *)(*(int *)(*(int *)(iVar3 + 0x20) + 0x510) + 0x2c) == '\0') {
            uVar18 = 0x80f259;
            pdVar5 = (double *)FUN_016827e0();
            uVar6 = uStack_64;
            if (_PTR_018dad08 < (*pdVar5 - dStack_2c) * DAT_018c0d70) break;
          }
          piVar14 = piVar14 + 3;
          uVar6 = uStack_64;
        } while (piVar14 != piStack_60);
      }
      uStack_8._0_1_ = 6;
      FUN_0152dda0(uStack_40._4_4_,puStack_38,uStack_70);
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      FUN_01675290(uVar6);
      param_1 = iStack_18;
    }
    puVar11 = (undefined4 *)(param_1 + 0x11c);
    uStack_8._0_1_ = 8;
    FUN_00805360(*puVar11,*(undefined4 *)(param_1 + 0x120),puVar11);
    *(undefined4 *)(param_1 + 0x120) = *puVar11;
    *(undefined4 *)(param_1 + 300) = *(undefined4 *)(param_1 + 0x128);
    puStack_38 = *(uint **)(param_1 + 0x138);
    puVar15 = *(uint **)(param_1 + 0x134);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_40._4_4_ = puVar15;
    if (puVar15 != puStack_38) {
      do {
        puVar8 = (uint *)FUN_008090b0(puVar15,puVar15[3]);
        if (puVar8 != (uint *)0x0) {
          uVar10 = puVar8[6];
          while (uVar10 != 0) {
            puStack_14 = (uint *)puVar8[6];
            uStack_40._4_4_ =
                 puStack_14 + (puVar8[2] & 1) + ((puVar8[1] & 1) + (*puVar8 & 1) * 2) * 2 + 7;
            if (*(char *)((int)puVar8 + 0x12) != '\0') {
              FUN_0080a660(puVar8,0);
              FUN_0080ee50();
            }
            uVar10 = *uStack_40._4_4_;
            *uStack_40._4_4_ = 0;
            if (uVar10 != 0) {
              FUN_00808350();
            }
            puVar13 = puStack_14;
            if (*(byte *)(puStack_14 + 3) < 5) {
              if (DAT_01d61f54 == '\0') {
                FUN_0080c1d0();
              }
              else {
                if (*(char *)(puVar8 + 3) == '\0') {
                  FUN_008096e0();
                  uVar4 = FUN_00a70880();
                  *(undefined *)((int)puVar8 + 0xd) = uVar4;
                }
                param_1 = iStack_18;
                puVar13 = puStack_14;
                for (uVar10 = puVar8[6];
                    (puStack_14 = puVar13, uVar10 != 0 && (*(byte *)(uVar10 + 0xc) < 5));
                    uVar10 = *(uint *)(uVar10 + 0x18)) {
                  FUN_0080c1d0();
                  puVar13 = puStack_14;
                }
              }
            }
            uVar10 = 0;
            do {
              if (puVar13[((int)uVar10 >> 2 & 1U) + (((int)uVar10 >> 1 & 1U) + (uVar10 & 1) * 2) * 2
                          + 7] != 0) goto LAB_0080f444;
              uVar10 = uVar10 + 1;
            } while ((int)uVar10 < 8);
            puVar8 = puVar13;
            uVar10 = puStack_14[6];
          }
          piVar14 = (int *)(param_1 +
                           (((0x1a - ((int)puVar8[1] >> 0x1f)) + ((int)*puVar8 >> 0x1f) * -2) * 2 -
                           ((int)puVar8[2] >> 0x1f)) * 4);
          iVar16 = *piVar14;
          *piVar14 = 0;
          if (iVar16 != 0) {
            FUN_00808350();
          }
        }
LAB_0080f444:
        puVar15 = puVar15 + 4;
      } while (puVar15 != puStack_38);
    }
    *(undefined4 *)(param_1 + 0x138) = *(undefined4 *)(param_1 + 0x134);
    FUN_00808cd0();
    if (*(int *)(param_1 + 0x70) != 0) {
      dStack_2c = *(double *)(param_1 + 0x248) / DAT_018d8a10;
      fVar17 = (float10)FUN_01728560();
      uStack_40 = (double)fVar17 * _PTR_018cf0f8 * _DAT_01901950;
      dStack_2c = uStack_40;
      fVar17 = (float10)FUN_01725280(uStack_40);
      dStack_2c = (double)fVar17;
      *(float *)(param_1 + 0x220) = (float)(uStack_40 - dStack_2c);
      uStack_1c = FUN_016f3eb1();
      uStack_1c = uStack_1c % 0x19;
      iVar16 = 0;
      uStack_40._4_4_ = (uint *)((uStack_1c + 1) % 0x19);
      do {
        iVar7 = iStack_18;
        piStack_20 = *(int **)(param_1 + 0x70);
        puStack_14 = (uint *)0x0;
        iVar12 = *(int *)((int)piStack_20 + iVar16 + 4) - *(int *)((int)piStack_20 + iVar16);
        iVar3 = iVar12 >> 0x1f;
        if (iVar12 / 0x50 + iVar3 != iVar3) {
          uStack_24 = 0;
          do {
            uStack_5b = 0;
            uStack_58 = 0;
            uStack_5c = *(char *)(iVar7 + 0x244) == '\0';
            fStack_54 = (float)((uint)fStack_54 & 0xffffff00);
            FUN_0078e530();
            auStack_50[0] = 1;
            uStack_4c = 0;
            uStack_48 = 0;
            FUN_0078e550(0,uStack_1c * 8 + 0x14c + iVar7,auStack_50);
            auStack_30[0] = 1;
            dStack_2c = (double)((ulonglong)dStack_2c & 0xffff000000000000);
            FUN_0078e550(2,(int)uStack_40._4_4_ * 8 + 0x14c + iVar7,auStack_30);
            FUN_0078e4a0(3,iVar7 + 0x214,0x30);
            puStack_14 = (uint *)((int)puStack_14 + 1);
            uStack_24 = uStack_24 + 0x50;
            param_1 = iVar7;
          } while (puStack_14 <
                   (uint *)((*(int *)((int)piStack_20 + iVar16 + 4) -
                            *(int *)((int)piStack_20 + iVar16)) / 0x50));
        }
        iVar16 = iVar16 + 0xc;
      } while (iVar16 < 0x24);
    }
    FUN_0080e610();
    FUN_00864720();
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    FUN_01675290();
    uStack_8 = 10;
    FUN_0152dda0(uStack_44,uStack_68,uStack_80);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12448 ; VA 0x0080f700 ; FUN_0080f700 */

void __fastcall FUN_0080f700(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined uVar6;
  int iVar7;
  undefined4 uVar8;
  int iVar9;
  double *pdVar10;
  int *piVar11;
  uint uVar12;
  undefined4 *puVar13;
  undefined8 uVar14;
  int iStack_b0;
  int iStack_ac;
  undefined auStack_a4 [24];
  undefined8 uStack_8c;
  int iStack_84;
  undefined8 uStack_80;
  int iStack_78;
  double dStack_74;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined8 uStack_64;
  char cStack_5c;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 *puStack_40;
  undefined8 uStack_3c;
  int iStack_34;
  undefined auStack_30 [4];
  undefined4 *puStack_2c;
  undefined8 *puStack_28;
  int iStack_24;
  uint uStack_20;
  uint uStack_1c;
  char cStack_15;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b5358;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x28) == 0) {
    return;
  }
  puStack_2c = *(undefined4 **)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  iStack_24 = param_1;
  if ((*(int *)((int)puStack_2c + 0x34) < DAT_01eb3848) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb3848), cVar3 = DAT_01d7ad48,
     DAT_01eb3848 == -1)) {
    uStack_8 = 0;
    uVar14 = FUN_0152dab0("Render","updateTerrainPrepare",0xffffffff);
    if ((cVar3 != '\0') && (DAT_01d7ad40 != '\0')) {
      FUN_01532a30(uVar14);
    }
    uStack_8 = 0xffffffff;
    DAT_01eb3840 = (int)uVar14;
    DAT_01eb3844 = (int)((ulonglong)uVar14 >> 0x20);
    FUN_016f37bf(&DAT_01eb3848);
    param_1 = iStack_24;
  }
  cStack_15 = DAT_01d7ad48;
  uStack_44 = DAT_01eb3840;
  uStack_6c = DAT_01eb3840;
  uStack_54 = DAT_01eb3844;
  uStack_68 = DAT_01eb3844;
  uStack_64 = FUN_01532c80(DAT_01eb3840,DAT_01eb3844);
  cStack_5c = cStack_15;
  uStack_8 = 1;
  iVar7 = FUN_01675290(DAT_01eb36d8);
  iVar9 = *(int *)(param_1 + 0x24);
  uStack_8._0_1_ = 2;
  iStack_24 = iVar7;
  if (*(char *)(param_1 + 0x2d) != *(char *)(iVar9 + 0x15c)) {
    FUN_00a70e60(&uStack_50);
    uStack_8._0_1_ = 3;
    uStack_1c = uStack_50._4_4_;
    uStack_20 = (uint)uStack_50;
    if ((uint)uStack_50 != uStack_50._4_4_) {
LAB_0080f7e0:
      FUN_00a70570(auStack_a4,2);
      FUN_00a70da0(&uStack_8c,4);
      iVar9 = iStack_78;
      uVar14 = uStack_80;
      puStack_40 = &uStack_8c;
      uStack_3c = uStack_8c;
      iStack_34 = iStack_84;
      do {
        iStack_b0 = (int)uVar14;
        if ((int)uStack_3c == iStack_b0) {
          iStack_ac = (int)((ulonglong)uVar14 >> 0x20);
          if ((uStack_3c._4_4_ == iStack_ac) && (iStack_34 == iVar9)) goto LAB_0080f8d5;
        }
        uStack_14 = FUN_008093c0(&uStack_3c,0);
        for (iVar7 = uStack_14; (iVar7 != 0 && (*(byte *)(iVar7 + 0xc) < 5));
            iVar7 = *(int *)(iVar7 + 0x18)) {
          *(undefined *)(iVar7 + 0x11) = 1;
        }
        if ((DAT_01d61f54 == '\0') || (*(char *)(uStack_14 + 0xc) == '\0')) {
          uVar8 = FUN_008096e0(auStack_a4);
          uVar6 = FUN_00a70880(uVar8);
          *(undefined *)(uStack_14 + 0xd) = uVar6;
        }
        for (iVar7 = *(int *)(uStack_14 + 0x18); (iVar7 != 0 && (*(byte *)(iVar7 + 0xc) < 5));
            iVar7 = *(int *)(iVar7 + 0x18)) {
          FUN_0080c1d0(iVar7);
        }
        FUN_00a6e100();
      } while( true );
    }
LAB_0080f8ea:
    uStack_8._0_1_ = 2;
    FUN_00612d60();
    iVar9 = *(int *)(param_1 + 0x24);
  }
  uVar12 = 0;
  *(undefined *)(param_1 + 0x2d) = *(undefined *)(iVar9 + 0x15c);
  uStack_20 = 0;
  uStack_14 = (*(int *)(param_1 + 0xf4) - *(int *)(param_1 + 0xf0)) / 0xc;
  if (uStack_14 != 0) {
    piVar11 = *(int **)(param_1 + 0xf0);
    do {
      uStack_20 = uVar12;
      if (((*piVar11 != *(int *)(param_1 + 0x100)) || (piVar11[1] != *(int *)(param_1 + 0x104))) ||
         (piVar11[2] != *(int *)(param_1 + 0x108))) break;
      uVar12 = uVar12 + 1;
      piVar11 = piVar11 + 3;
      uStack_20 = uVar12;
    } while (uVar12 < uStack_14);
  }
LAB_0080f961:
  if (uStack_20 != uStack_14) {
    puStack_28 = (undefined8 *)(uStack_20 * 0xc);
    uStack_1c = FUN_008093c0(*(int *)(param_1 + 0xf0) + (int)puStack_28,0);
    for (iVar9 = uStack_1c; (iVar9 != 0 && (*(byte *)(iVar9 + 0xc) < 5));
        iVar9 = *(int *)(iVar9 + 0x18)) {
      *(undefined *)(iVar9 + 0x11) = 1;
    }
    if ((DAT_01d61f54 == '\0') || (*(char *)(uStack_1c + 0xc) == '\0')) {
      uVar8 = FUN_008096e0(auStack_a4);
      uVar6 = FUN_00a70880(uVar8);
      *(undefined *)(uStack_1c + 0xd) = uVar6;
    }
    for (iVar9 = *(int *)(uStack_1c + 0x18); (iVar9 != 0 && (*(byte *)(iVar9 + 0xc) < 5));
        iVar9 = *(int *)(iVar9 + 0x18)) {
      FUN_0080c1d0(iVar9);
    }
    uStack_1c = (*(int *)(param_1 + 0xf4) - *(int *)(param_1 + 0xf0)) / 0xc;
    piVar11 = (int *)((int)puStack_28 + *(int *)(param_1 + 0xf0));
    do {
      uStack_20 = uStack_20 + 1;
      if (((uStack_1c <= uStack_20) || (piVar11[3] != *(int *)(param_1 + 0x100))) ||
         (piVar11[4] != *(int *)(param_1 + 0x104))) break;
      piVar1 = piVar11 + 5;
      piVar11 = piVar11 + 3;
    } while (*piVar1 == *(int *)(param_1 + 0x108));
    goto LAB_0080f961;
  }
  *(int *)(param_1 + 0xf4) = *(int *)(param_1 + 0xf0);
  *(undefined4 *)(param_1 + 0xfc) = 0;
  iVar9 = *(int *)(param_1 + 0x20);
  if (*(int **)(iVar9 + 0x578) != (int *)0x0) {
    iVar9 = (**(code **)(**(int **)(iVar9 + 0x578) + 0x1c))();
    if (*(char *)(iVar9 + 0x51) != '\0') goto LAB_0080fb52;
    iVar9 = *(int *)(param_1 + 0x20);
  }
  uStack_50 = *(undefined8 *)(*(int *)(iVar9 + 0x4f8) + 4);
  uStack_48 = *(undefined4 *)(*(int *)(iVar9 + 0x4f8) + 0xc);
  if (DAT_01d61f3c == '\0') {
    if (*(int *)((int)puStack_2c + 0x34) < DAT_01eb3878) {
      FUN_016f3809(&DAT_01eb3878);
      if (DAT_01eb3878 == -1) {
        uStack_8._0_1_ = 4;
        uVar14 = FUN_0152dab0("Render","updateLod",0xffffffff);
        DAT_01eb3874 = (int)((ulonglong)uVar14 >> 0x20);
        DAT_01eb3870 = (undefined8 *)uVar14;
        uStack_8._0_1_ = 2;
        FUN_016f37bf(&DAT_01eb3878);
      }
    }
    puStack_28 = DAT_01eb3870;
    puStack_40 = DAT_01eb3870;
    puStack_2c = (undefined4 *)DAT_01eb3874;
    uStack_3c = CONCAT44(uStack_3c._4_4_,DAT_01eb3874);
    uVar14 = FUN_0152d930(DAT_01eb3870,DAT_01eb3874);
    iStack_34 = (int)((ulonglong)uVar14 >> 0x20);
    uStack_3c = CONCAT44((int)uVar14,(int)uStack_3c);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    uVar12 = 0;
    do {
      iVar9 = *(int *)(param_1 +
                      (((int)uVar12 >> 2 & 1U) +
                      (((int)uVar12 >> 1 & 1U) + 0x1a + (uVar12 & 1) * 2) * 2) * 4);
      if (iVar9 != 0) {
        FUN_0080e2a0(&uStack_50,iVar9);
      }
      uVar12 = uVar12 + 1;
    } while ((int)uVar12 < 8);
    uStack_8._0_1_ = 6;
    FUN_0152dda0(puStack_28,puStack_2c,uStack_3c._4_4_,iStack_34);
    uStack_8._0_1_ = 2;
  }
  else {
    FUN_0080da10(&uStack_50);
  }
LAB_0080fb52:
  FUN_00806820(*(int *)(param_1 + 0x110),*(int *)(param_1 + 0x114),
               *(int *)(param_1 + 0x114) - *(int *)(param_1 + 0x110) >> 3,uStack_44);
  FUN_016827e0(&dStack_74);
  puVar2 = *(undefined4 **)(param_1 + 0x114);
  puStack_2c = puVar2;
  for (puVar13 = *(undefined4 **)(param_1 + 0x110); puVar13 != puVar2; puVar13 = puVar13 + 2) {
    FUN_0080d030(*puVar13);
    if (*(char *)(*(int *)(*(int *)(param_1 + 0x20) + 0x510) + 0x2c) == '\0') {
      pdVar10 = (double *)FUN_016827e0(auStack_30);
      iVar7 = iStack_24;
      if ((DAT_018c0d60 < (*pdVar10 - dStack_74) * DAT_018c0d70) ||
         (7 < (uint)((*(int *)(param_1 + 0x120) - *(int *)(param_1 + 0x11c)) / 0xb8))) break;
    }
    iVar7 = iStack_24;
  }
  *(undefined4 *)(param_1 + 0x114) = *(undefined4 *)(param_1 + 0x110);
  iVar9 = *(int *)(param_1 + 0x20);
  if ((*(char *)(*(int *)(iVar9 + 0x510) + 0x2c) != '\0') &&
     (*(int *)(param_1 + 0x11c) != *(int *)(param_1 + 0x120))) {
    FUN_00809610();
    FUN_008099e0();
    iVar9 = *(int *)(param_1 + 0x20);
  }
  if (*(int *)(param_1 + 0x250) != *(int *)(iVar9 + 0x5c4)) {
    FUN_008099e0();
    if (DAT_01d60bc0 != '\0') {
      if (*(int *)(param_1 + 0x68) != 0) {
        FUN_00810240();
        FUN_0080e610();
      }
      if (*(int *)(param_1 + 0x78) != 0) {
        FUN_00864690();
        FUN_00864720();
      }
    }
  }
  FUN_00811c00();
  FUN_0080ec90();
  *(undefined4 *)(param_1 + 0x250) = *(undefined4 *)(*(int *)(param_1 + 0x20) + 0x5c4);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_01675290(iVar7);
  uVar5 = uStack_44;
  uVar4 = uStack_54;
  uVar8 = (undefined4)uStack_64;
  uStack_8 = 8;
  FUN_0152dda0(uStack_44,uStack_54,uStack_64);
  if ((cStack_15 != '\0') && (DAT_01d7ad40 != '\0')) {
    FUN_01532d10(uVar5,uVar4,uVar8,uStack_64._4_4_);
  }
  ExceptionList = pvStack_10;
  return;
LAB_0080f8d5:
  uStack_20 = uStack_20 + 0x18;
  iVar7 = iStack_24;
  if (uStack_20 == uStack_1c) goto LAB_0080f8ea;
  goto LAB_0080f7e0;
}



/* FUNCTION 12449 ; VA 0x0080fdd0 ; FUN_0080fdd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0080fdd0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  char cVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  undefined8 *puVar6;
  float10 fVar7;
  undefined auStack_7c [24];
  undefined auStack_64 [24];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  int iStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b537c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00841130();
  if (cVar2 == '\0') {
    fStack_14 = *(float *)(param_1 + 0x14);
    iVar1 = *(int *)(param_1 + 8);
    iStack_18 = *(undefined4 *)(iVar1 + 0x4fc);
    cVar2 = FUN_01156450();
    if ((cVar2 == '\0') || (cVar2 = FUN_00795ec0(), cVar2 == '\0')) {
      fVar7 = (float10)FUN_01156fe0(*(undefined4 *)(iVar1 + 0x5c4));
      fStack_14 = (float)(((float)fVar7 <= fStack_14) + 1);
    }
    else {
      fStack_14 = 0.0;
    }
    iVar4 = *(int *)(param_1 + 0x38);
    iStack_18 = (int)*(char *)(iVar4 + 0x6b);
    if (*(int *)(iVar4 + 0x6c) != 0) {
      FUN_008100e0(param_2,param_3,fStack_14,param_4,iStack_18,*(undefined4 *)(iVar1 + 0x5c4));
      iVar4 = *(int *)(param_1 + 0x38);
    }
    if (*(int *)(iVar4 + 0x70) != 0) {
      FUN_008100e0(param_2,param_3,fStack_14,param_4,iStack_18,*(undefined4 *)(iVar1 + 0x5c4));
    }
    if (param_4 == 0) {
      iVar4 = *(int *)(param_1 + 0x38);
      if (*(int *)(iVar4 + 0x74) != 0) {
        uStack_1c = *(undefined4 *)(iVar1 + 0x5c4);
        if (DAT_01d61f3c == '\0') {
          puVar3 = (undefined4 *)FUN_00809230(auStack_64);
        }
        else {
          uStack_34 = *(undefined4 *)(iVar4 + 0x7c);
          uStack_30 = *(undefined4 *)(iVar4 + 0x80);
          uStack_2c = *(undefined4 *)(iVar4 + 0x84);
          uStack_28 = *(undefined4 *)(iVar4 + 0x88);
          uStack_24 = *(undefined8 *)(iVar4 + 0x8c);
          puVar3 = &uStack_34;
        }
        FUN_008648e0(param_2,param_3,fStack_14,0,puVar3,uStack_1c);
      }
      iVar4 = *(int *)(param_1 + 0x38);
      if (*(int *)(iVar4 + 0x78) != 0) {
        uStack_1c = *(undefined4 *)(iVar1 + 0x5c4);
        if (DAT_01d61f3c == '\0') {
          puVar3 = (undefined4 *)FUN_00809230(auStack_7c);
        }
        else {
          uStack_4c = *(undefined4 *)(iVar4 + 0x7c);
          uStack_48 = *(undefined4 *)(iVar4 + 0x80);
          uStack_44 = *(undefined4 *)(iVar4 + 0x84);
          uStack_40 = *(undefined4 *)(iVar4 + 0x88);
          uStack_3c = *(undefined8 *)(iVar4 + 0x8c);
          puVar3 = &uStack_4c;
        }
        FUN_008648e0(param_2,param_3,fStack_14,0,puVar3,uStack_1c);
      }
    }
    if (*(char *)(*(int *)(iVar1 + 0x510) + 0x20) != '\0') {
      if ((*(int **)(iVar1 + 0x578) == (int *)0x0) ||
         (iVar4 = (**(code **)(**(int **)(iVar1 + 0x578) + 0x1c))(), *(char *)(iVar4 + 0x53) == '\0'
         )) {
        FUN_008416d0(iVar1,*(int *)(param_1 + 0x38) + 0x94);
      }
      else {
        if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
             DAT_01eb3768) && (FUN_016f3809(&DAT_01eb3768), DAT_01eb3768 == -1)) {
          uStack_8 = 0;
          puVar6 = (undefined8 *)FUN_0115eb90();
          _DAT_01eb372c = *puVar6;
          _DAT_01eb3734 = *(undefined4 *)(puVar6 + 1);
          puVar6 = (undefined8 *)FUN_0115eb50();
          _DAT_01eb3738 = *puVar6;
          _DAT_01eb3740 = *(undefined4 *)(puVar6 + 1);
          puVar6 = (undefined8 *)FUN_0115e920();
          _DAT_01eb3744 = *puVar6;
          _DAT_01eb374c = *(undefined4 *)(puVar6 + 1);
          puVar6 = (undefined8 *)FUN_0115ee80();
          _DAT_01eb3750 = *puVar6;
          _DAT_01eb3758 = *(undefined4 *)(puVar6 + 1);
          puVar6 = (undefined8 *)FUN_0115eb80();
          uStack_8 = 0xffffffff;
          _DAT_01eb375c = *puVar6;
          _DAT_01eb3764 = *(undefined4 *)(puVar6 + 1);
          FUN_016f37bf(&DAT_01eb3768);
        }
        iVar4 = (**(code **)(**(int **)(iVar1 + 0x578) + 0x1c))();
        if (*(char *)(iVar4 + 0x52) == '\0') {
          uVar5 = (uint)*(byte *)(*(int *)(param_1 + 0x38) + 0xc);
        }
        else {
          uVar5 = FUN_00809160();
        }
        FUN_008417d0(iVar1,*(int *)(param_1 + 0x38) + 0x94,&DAT_01eb372c + (uVar5 & 0xff) * 0xc);
      }
      FUN_008088c0(iVar1,*(undefined4 *)(param_1 + 0x38));
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12450 ; VA 0x008100e0 ; FUN_008100e0 */

void __thiscall
FUN_008100e0(int param_1,int param_2,undefined4 param_3,undefined4 param_4,int param_5,uint param_6,
            undefined4 param_7)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  iVar3 = param_5;
  if ((param_5 == 5) || (param_5 == 4)) {
    param_5._3_1_ = 1;
  }
  else {
    param_5._3_1_ = 0;
  }
  uVar2 = FUN_0078e450(param_7);
  iVar3 = FUN_0078e270(param_4,iVar3,uVar2);
  if (iVar3 != 0) {
    iVar6 = (uint)param_5._3_1_ * 0x10 + param_1;
    if ((param_6 & 1) == 0) {
      iVar4 = *(int *)(iVar6 + 100);
    }
    else {
      iVar4 = 0;
    }
    if ((param_6 & 4) == 0) {
      iVar5 = *(int *)(iVar6 + 0x68);
    }
    else {
      iVar5 = *(int *)(iVar6 + 0x6c);
    }
    if (iVar4 != iVar5) {
      iStack_14 = 0x2c;
      if (param_5._3_1_ == 0) {
        iStack_14 = 0x14;
      }
      iStack_14 = iStack_14 + param_1;
      *(int *)(iStack_14 + 0xc) = *(int *)(param_1 + 0x60) + iVar4;
      *(int *)(iStack_14 + 0x14) = iVar5 - iVar4;
      uStack_10 = 0;
      uStack_c = 0;
      uStack_8 = 0;
      iVar4 = param_2 + *(int *)(param_1 + 8) * 0xc;
      piVar1 = *(int **)(iVar4 + 4);
      if (*(int **)(iVar4 + 8) == piVar1) {
        iStack_1c = param_1;
        iStack_18 = iVar3;
        FUN_006c6730(piVar1,&iStack_1c);
      }
      else {
        *piVar1 = param_1;
        piVar1[1] = iVar3;
        piVar1[2] = iStack_14;
        piVar1[3] = 0;
        piVar1[4] = 0;
        piVar1[5] = 0;
        *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 0x18;
      }
    }
    if (((param_6 & 2) != 0) && (*(uint *)(param_1 + 0x6c) < *(uint *)(param_1 + 0x70))) {
      iStack_14 = 0x9c;
      if (param_5._3_1_ == 0) {
        iStack_14 = 0x84;
      }
      iStack_14 = iStack_14 + param_1;
      uStack_10 = 0;
      uStack_c = 0;
      *(int *)(iStack_14 + 0xc) = *(int *)(param_1 + 0x60) + *(int *)(iVar6 + 0x6c);
      iVar6 = *(int *)(iVar6 + 0x70) - *(int *)(iVar6 + 0x6c);
      *(int *)(iStack_14 + 0x14) = iVar6;
      uStack_8 = 0;
      if (iVar6 != 0) {
        iStack_1c = param_1;
        iStack_18 = iVar3;
        FUN_007b4d60(&iStack_1c);
      }
    }
    *(uint *)(param_2 + 0xb4) = *(uint *)(param_2 + 0xb4) | *(uint *)(param_1 + 0x10);
  }
  return;
}



/* FUNCTION 12451 ; VA 0x00810240 ; FUN_00810240 */

void FUN_00810240(void)

{
  undefined4 *puVar1;
  undefined8 uVar2;
  int ***pppiVar3;
  int ***pppiVar4;
  undefined uVar5;
  char cVar6;
  int *piVar7;
  undefined4 *****pppppuVar8;
  undefined4 uVar9;
  int iVar10;
  char *pcVar11;
  int ****ppppiVar12;
  char *pcVar13;
  uint uVar14;
  undefined auStack_150 [24];
  undefined auStack_138 [16];
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined auStack_120 [24];
  undefined auStack_108 [80];
  undefined4 ****appppuStack_b8 [4];
  int iStack_a8;
  uint uStack_a4;
  undefined auStack_a0 [8];
  undefined4 *puStack_98;
  undefined4 uStack_94;
  undefined4 *puStack_90;
  int ***pppiStack_8c;
  undefined4 ****ppppuStack_88;
  int iStack_84;
  int iStack_80;
  int iStack_7c;
  undefined8 uStack_78;
  int ****ppppiStack_70;
  int iStack_6c;
  int iStack_68;
  int iStack_64;
  undefined8 uStack_60;
  int ****ppppiStack_58;
  int iStack_54;
  int iStack_50;
  int iStack_4c;
  undefined8 uStack_48;
  undefined4 ****ppppuStack_40;
  int iStack_3c;
  char *pcStack_38;
  int iStack_34;
  undefined8 uStack_30;
  int ****ppppiStack_28;
  int ***pppiStack_24;
  int ****ppppiStack_20;
  int ***pppiStack_1c;
  int ***pppiStack_18;
  int ****ppppiStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b5661;
  pvStack_10 = ExceptionList;
  pppiStack_18 = (int ***)0x0;
  if (DAT_01d61f4c != '\0') {
    ExceptionList = &pvStack_10;
    FUN_008117e0();
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_0078e420();
  cVar6 = FUN_00afc8d0();
  iStack_a8 = 0;
  uStack_a4 = 0xf;
  pcVar13 = "Colored";
  appppuStack_b8[0] = (undefined4 ****)((uint)appppuStack_b8[0] & 0xffffff00);
  if (cVar6 == '\0') {
    pcVar13 = "";
  }
  pcVar11 = pcVar13;
  do {
    cVar6 = *pcVar11;
    pcVar11 = pcVar11 + 1;
  } while (cVar6 != '\0');
  FUN_005542c0(pcVar13,(int)pcVar11 - (int)(pcVar13 + 1));
  uStack_8 = 0;
  if (((DAT_01d60f70 != '\0') && (DAT_01d60f78 != '\0')) && (cVar6 = FUN_0078ba00(), cVar6 != '\0'))
  {
    cVar6 = FUN_0078bbb0();
    pcVar13 = "AO";
    if (cVar6 != '\0') goto LAB_00810321;
  }
  pcVar13 = "";
LAB_00810321:
  uStack_128 = 0;
  uStack_124 = 0xf;
  auStack_138[0] = 0;
  pcVar11 = pcVar13;
  do {
    cVar6 = *pcVar11;
    pcVar11 = pcVar11 + 1;
  } while (cVar6 != '\0');
  FUN_005542c0(pcVar13,(int)pcVar11 - (int)(pcVar13 + 1));
  iVar10 = iStack_a8;
  uStack_8._0_1_ = 2;
  uStack_48 = 0xf00000000;
  ppppiStack_58 = (int ****)((uint)ppppiStack_58 & 0xffffff00);
  pppiStack_18 = (int ***)0x1;
  FUN_0058a190(iStack_a8 + 0xd);
  FUN_00554150("SmoothCluster",0xd);
  pppppuVar8 = appppuStack_b8;
  if (0xf < uStack_a4) {
    pppppuVar8 = (undefined4 *****)appppuStack_b8[0];
  }
  FUN_00554150(pppppuVar8,iVar10);
  piVar7 = (int *)FUN_00554150("SuperHQFS",9);
  iVar10 = iStack_a8;
  ppppuStack_88 = (undefined4 ****)*piVar7;
  iStack_84 = piVar7[1];
  iStack_80 = piVar7[2];
  iStack_7c = piVar7[3];
  uStack_78 = *(undefined8 *)(piVar7 + 4);
  piVar7[4] = 0;
  piVar7[5] = 0xf;
  *(undefined *)piVar7 = 0;
  uStack_8._0_1_ = 4;
  uStack_60 = 0xf00000000;
  ppppiStack_70 = (int ****)((uint)ppppiStack_70 & 0xffffff00);
  pppiStack_18 = (int ***)0x7;
  FUN_0058a190(iStack_a8 + 0xd);
  FUN_00554150("SmoothCluster",0xd);
  pppppuVar8 = appppuStack_b8;
  if (0xf < uStack_a4) {
    pppppuVar8 = (undefined4 *****)appppuStack_b8[0];
  }
  FUN_00554150(pppppuVar8,iVar10);
  piVar7 = (int *)FUN_00554150("SuperHQVS",9);
  pppiStack_18 = (int ***)0xf;
  ppppuStack_40 = (undefined4 ****)*piVar7;
  iStack_3c = piVar7[1];
  pcStack_38 = (char *)piVar7[2];
  iStack_34 = piVar7[3];
  uVar2 = *(undefined8 *)(piVar7 + 4);
  piVar7[4] = 0;
  piVar7[5] = 0xf;
  *(undefined *)piVar7 = 0;
  uStack_30._0_4_ = (undefined4)uVar2;
  ppppiStack_20 = (int ****)&ppppuStack_88;
  if (0xf < uStack_78._4_4_) {
    ppppiStack_20 = ppppuStack_88;
  }
  uStack_30._4_4_ = (uint)((ulonglong)uVar2 >> 0x20);
  ppppiStack_28 = (int ****)&ppppuStack_40;
  if (0xf < uStack_30._4_4_) {
    ppppiStack_28 = ppppuStack_40;
  }
  pppiStack_24 = (int ***)(undefined4)uStack_30;
  uStack_8._0_1_ = 5;
  pppiStack_1c = (int ***)(undefined4)uStack_78;
  uStack_30 = uVar2;
  FUN_00790e00(&puStack_90,&ppppiStack_28,2);
  uStack_8._0_1_ = 7;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 7;
  if (0xf < uStack_30._4_4_) {
    uVar14 = uStack_30._4_4_ + 1;
    pppppuVar8 = (undefined4 *****)ppppuStack_40;
    if (0xfff < uVar14) {
      pppppuVar8 = (undefined4 *****)ppppuStack_40[-1];
      uVar14 = uStack_30._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppuStack_40 + (-4 - (int)pppppuVar8))) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar8,uVar14);
  }
  uStack_30 = 0xf00000000;
  ppppuStack_40 = (undefined4 ****)((uint)ppppuStack_40 & 0xffffff00);
  uStack_8._0_1_ = 8;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  if (0xf < uStack_60._4_4_) {
    uVar14 = uStack_60._4_4_ + 1;
    ppppiVar12 = ppppiStack_70;
    if (0xfff < uVar14) {
      ppppiVar12 = (int ****)ppppiStack_70[-1];
      uVar14 = uStack_60._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppiStack_70 + (-4 - (int)ppppiVar12))) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppiVar12,uVar14);
  }
  uStack_60 = 0xf00000000;
  ppppiStack_70 = (int ****)((uint)ppppiStack_70 & 0xffffff00);
  uStack_8._0_1_ = 9;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 9;
  if (0xf < uStack_78._4_4_) {
    uVar14 = uStack_78._4_4_ + 1;
    pppppuVar8 = (undefined4 *****)ppppuStack_88;
    if (0xfff < uVar14) {
      pppppuVar8 = (undefined4 *****)ppppuStack_88[-1];
      uVar14 = uStack_78._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppuStack_88 + (-4 - (int)pppppuVar8))) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar8,uVar14);
  }
  uStack_78 = 0xf00000000;
  ppppuStack_88 = (undefined4 ****)((uint)ppppuStack_88 & 0xffffff00);
  uStack_8._0_1_ = 10;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 10;
  if (0xf < uStack_48._4_4_) {
    uVar14 = uStack_48._4_4_ + 1;
    ppppiVar12 = ppppiStack_58;
    if (0xfff < uVar14) {
      ppppiVar12 = (int ****)ppppiStack_58[-1];
      uVar14 = uStack_48._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppiStack_58 + (-4 - (int)ppppiVar12))) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppiVar12,uVar14);
  }
  uStack_48 = 0xf00000000;
  ppppiStack_58 = (int ****)((uint)ppppiStack_58 & 0xffffff00);
  if (puStack_90 != (undefined4 *)0x0) {
    FUN_0078ded0(&puStack_90,0,0);
    uStack_8._0_1_ = 0xb;
    FUN_0080b1d0(*(undefined4 *)((int)ppppiStack_14 + 0x20),auStack_108,0);
    FUN_0078e040(auStack_108,0);
    FUN_0075e0c0();
  }
  pppiStack_18 = pppiStack_8c;
  if ((int ****)pppiStack_8c != (int ****)0x0) {
    LOCK();
    pppiVar3 = (int ***)((int)pppiStack_8c[1] + -1);
    pppiStack_8c[1] = (int **)pppiVar3;
    UNLOCK();
    if (pppiVar3 == (int ***)0x0) {
      (*(code *)**pppiStack_8c)();
      LOCK();
      pppiVar3 = (int ***)((int)pppiStack_18[2] + -1);
      pppiStack_18[2] = (int **)pppiVar3;
      UNLOCK();
      if (pppiVar3 == (int ***)0x0) {
        (*(code *)(*pppiStack_18)[1])();
      }
    }
  }
  iVar10 = iStack_a8;
  uStack_8._0_1_ = 0xc;
  uStack_60 = 0xf00000000;
  ppppiStack_70 = (int ****)((uint)ppppiStack_70 & 0xffffff00);
  pppiStack_18 = (int ***)0x3a;
  FUN_0058a190(iStack_a8 + 0xd);
  FUN_00554150("SmoothCluster",0xd);
  pppppuVar8 = appppuStack_b8;
  if (0xf < uStack_a4) {
    pppppuVar8 = (undefined4 *****)appppuStack_b8[0];
  }
  FUN_00554150(pppppuVar8,iVar10);
  piVar7 = (int *)FUN_00554150(&DAT_01901780,4);
  iVar10 = iStack_a8;
  ppppuStack_40 = (undefined4 ****)*piVar7;
  iStack_3c = piVar7[1];
  pcStack_38 = (char *)piVar7[2];
  iStack_34 = piVar7[3];
  uStack_30 = *(undefined8 *)(piVar7 + 4);
  piVar7[4] = 0;
  piVar7[5] = 0xf;
  *(undefined *)piVar7 = 0;
  uStack_8._0_1_ = 0xe;
  uStack_48 = 0xf00000000;
  ppppiStack_58 = (int ****)((uint)ppppiStack_58 & 0xffffff00);
  pppiStack_18 = (int ***)0xfa;
  FUN_0058a190(iStack_a8 + 0xd);
  FUN_00554150("SmoothCluster",0xd);
  pppppuVar8 = appppuStack_b8;
  if (0xf < uStack_a4) {
    pppppuVar8 = (undefined4 *****)appppuStack_b8[0];
  }
  FUN_00554150(pppppuVar8,iVar10);
  piVar7 = (int *)FUN_00554150(&DAT_01901788,4);
  pppiStack_18 = (int ***)0x1fa;
  ppppuStack_88 = (undefined4 ****)*piVar7;
  iStack_84 = piVar7[1];
  iStack_80 = piVar7[2];
  iStack_7c = piVar7[3];
  uVar2 = *(undefined8 *)(piVar7 + 4);
  piVar7[4] = 0;
  piVar7[5] = 0xf;
  *(undefined *)piVar7 = 0;
  ppppiStack_20 = (int ****)&ppppuStack_40;
  if (0xf < uStack_30._4_4_) {
    ppppiStack_20 = ppppuStack_40;
  }
  uStack_8._0_1_ = 0xf;
  uStack_78._0_4_ = (undefined4)uVar2;
  uStack_78._4_4_ = (uint)((ulonglong)uVar2 >> 0x20);
  pppiStack_24 = (int ***)(undefined4)uStack_78;
  ppppiStack_28 = (int ****)&ppppuStack_88;
  if (0xf < uStack_78._4_4_) {
    ppppiStack_28 = ppppuStack_88;
  }
  pppiStack_1c = (int ***)(undefined4)uStack_30;
  uStack_78 = uVar2;
  FUN_00790e00(&puStack_90,&ppppiStack_28,2);
  uStack_8._0_1_ = 0x11;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x11;
  if (0xf < uStack_78._4_4_) {
    uVar14 = uStack_78._4_4_ + 1;
    pppppuVar8 = (undefined4 *****)ppppuStack_88;
    if (0xfff < uVar14) {
      pppppuVar8 = (undefined4 *****)ppppuStack_88[-1];
      uVar14 = uStack_78._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppuStack_88 + (-4 - (int)pppppuVar8))) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar8,uVar14);
  }
  uStack_78 = 0xf00000000;
  ppppuStack_88 = (undefined4 ****)((uint)ppppuStack_88 & 0xffffff00);
  uStack_8._0_1_ = 0x12;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x12;
  if (0xf < uStack_48._4_4_) {
    uVar14 = uStack_48._4_4_ + 1;
    ppppiVar12 = ppppiStack_58;
    if (0xfff < uVar14) {
      ppppiVar12 = (int ****)ppppiStack_58[-1];
      uVar14 = uStack_48._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppiStack_58 + (-4 - (int)ppppiVar12))) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppiVar12,uVar14);
  }
  uStack_48 = 0xf00000000;
  ppppiStack_58 = (int ****)((uint)ppppiStack_58 & 0xffffff00);
  uStack_8._0_1_ = 0x13;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x13;
  if (0xf < uStack_30._4_4_) {
    uVar14 = uStack_30._4_4_ + 1;
    pppppuVar8 = (undefined4 *****)ppppuStack_40;
    if (0xfff < uVar14) {
      pppppuVar8 = (undefined4 *****)ppppuStack_40[-1];
      uVar14 = uStack_30._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppuStack_40 + (-4 - (int)pppppuVar8))) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar8,uVar14);
  }
  uStack_30 = 0xf00000000;
  ppppuStack_40 = (undefined4 ****)((uint)ppppuStack_40 & 0xffffff00);
  uStack_8._0_1_ = 0x14;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x14;
  if (0xf < uStack_60._4_4_) {
    uVar14 = uStack_60._4_4_ + 1;
    ppppiVar12 = ppppiStack_70;
    if (0xfff < uVar14) {
      ppppiVar12 = (int ****)ppppiStack_70[-1];
      uVar14 = uStack_60._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppiStack_70 + (-4 - (int)ppppiVar12))) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppiVar12,uVar14);
  }
  uStack_60 = 0xf00000000;
  ppppiStack_70 = (int ****)((uint)ppppiStack_70 & 0xffffff00);
  if (puStack_90 != (undefined4 *)0x0) {
    FUN_0078ded0(&puStack_90,1,0);
    uStack_8._0_1_ = 0x15;
    FUN_0080b1d0(*(undefined4 *)((int)ppppiStack_14 + 0x20),auStack_108,0);
    FUN_0078e040(auStack_108,0);
    FUN_0075e0c0();
  }
  pppiStack_18 = pppiStack_8c;
  if ((int ****)pppiStack_8c != (int ****)0x0) {
    LOCK();
    pppiVar3 = (int ***)((int)pppiStack_8c[1] + -1);
    pppiStack_8c[1] = (int **)pppiVar3;
    UNLOCK();
    if (pppiVar3 == (int ***)0x0) {
      (*(code *)**pppiStack_8c)();
      LOCK();
      pppiVar3 = (int ***)((int)pppiStack_18[2] + -1);
      pppiStack_18[2] = (int **)pppiVar3;
      UNLOCK();
      if (pppiVar3 == (int ***)0x0) {
        (*(code *)(*pppiStack_18)[1])();
      }
    }
  }
  iVar10 = iStack_a8;
  uStack_8._0_1_ = 0x16;
  uStack_60 = 0xf00000000;
  ppppiStack_70 = (int ****)((uint)ppppiStack_70 & 0xffffff00);
  pppiStack_18 = (int ***)0x75a;
  FUN_0058a190(iStack_a8 + 0xd);
  FUN_00554150("SmoothCluster",0xd);
  pppppuVar8 = appppuStack_b8;
  if (0xf < uStack_a4) {
    pppppuVar8 = (undefined4 *****)appppuStack_b8[0];
  }
  FUN_00554150(pppppuVar8,iVar10);
  piVar7 = (int *)FUN_00554150("SuperHQFSShadowed",0x11);
  iVar10 = iStack_a8;
  ppppuStack_40 = (undefined4 ****)*piVar7;
  iStack_3c = piVar7[1];
  pcStack_38 = (char *)piVar7[2];
  iStack_34 = piVar7[3];
  uStack_30 = *(undefined8 *)(piVar7 + 4);
  piVar7[4] = 0;
  piVar7[5] = 0xf;
  *(undefined *)piVar7 = 0;
  uStack_8._0_1_ = 0x18;
  uStack_48 = 0xf00000000;
  ppppiStack_58 = (int ****)((uint)ppppiStack_58 & 0xffffff00);
  pppiStack_18 = (int ***)0x1f5a;
  FUN_0058a190(iStack_a8 + 0xd);
  FUN_00554150("SmoothCluster",0xd);
  pppppuVar8 = appppuStack_b8;
  if (0xf < uStack_a4) {
    pppppuVar8 = (undefined4 *****)appppuStack_b8[0];
  }
  FUN_00554150(pppppuVar8,iVar10);
  piVar7 = (int *)FUN_00554150("SuperHQVSShadowed",0x11);
  pppiStack_18 = (int ***)0x3f5a;
  ppppuStack_88 = (undefined4 ****)*piVar7;
  iStack_84 = piVar7[1];
  iStack_80 = piVar7[2];
  iStack_7c = piVar7[3];
  uVar2 = *(undefined8 *)(piVar7 + 4);
  piVar7[4] = 0;
  piVar7[5] = 0xf;
  *(undefined *)piVar7 = 0;
  ppppiStack_20 = (int ****)&ppppuStack_40;
  if (0xf < uStack_30._4_4_) {
    ppppiStack_20 = ppppuStack_40;
  }
  uStack_8._0_1_ = 0x19;
  uStack_78._0_4_ = (undefined4)uVar2;
  uStack_78._4_4_ = (uint)((ulonglong)uVar2 >> 0x20);
  pppiStack_24 = (int ***)(undefined4)uStack_78;
  ppppiStack_28 = (int ****)&ppppuStack_88;
  if (0xf < uStack_78._4_4_) {
    ppppiStack_28 = ppppuStack_88;
  }
  pppiStack_1c = (int ***)(undefined4)uStack_30;
  uStack_78 = uVar2;
  FUN_00790e00(&puStack_90,&ppppiStack_28,2);
  uStack_8._0_1_ = 0x1b;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x1b;
  if (0xf < uStack_78._4_4_) {
    uVar14 = uStack_78._4_4_ + 1;
    pppppuVar8 = (undefined4 *****)ppppuStack_88;
    if (0xfff < uVar14) {
      pppppuVar8 = (undefined4 *****)ppppuStack_88[-1];
      uVar14 = uStack_78._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppuStack_88 + (-4 - (int)pppppuVar8))) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar8,uVar14);
  }
  uStack_78 = 0xf00000000;
  ppppuStack_88 = (undefined4 ****)((uint)ppppuStack_88 & 0xffffff00);
  uStack_8._0_1_ = 0x1c;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x1c;
  if (0xf < uStack_48._4_4_) {
    uVar14 = uStack_48._4_4_ + 1;
    ppppiVar12 = ppppiStack_58;
    if (0xfff < uVar14) {
      ppppiVar12 = (int ****)ppppiStack_58[-1];
      uVar14 = uStack_48._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppiStack_58 + (-4 - (int)ppppiVar12))) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppiVar12,uVar14);
  }
  uStack_48 = 0xf00000000;
  ppppiStack_58 = (int ****)((uint)ppppiStack_58 & 0xffffff00);
  uStack_8._0_1_ = 0x1d;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x1d;
  if (0xf < uStack_30._4_4_) {
    uVar14 = uStack_30._4_4_ + 1;
    pppppuVar8 = (undefined4 *****)ppppuStack_40;
    if (0xfff < uVar14) {
      pppppuVar8 = (undefined4 *****)ppppuStack_40[-1];
      uVar14 = uStack_30._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppuStack_40 + (-4 - (int)pppppuVar8))) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar8,uVar14);
  }
  uStack_30 = 0xf00000000;
  ppppuStack_40 = (undefined4 ****)((uint)ppppuStack_40 & 0xffffff00);
  uStack_8._0_1_ = 0x1e;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x1e;
  if (0xf < uStack_60._4_4_) {
    uVar14 = uStack_60._4_4_ + 1;
    ppppiVar12 = ppppiStack_70;
    if (0xfff < uVar14) {
      ppppiVar12 = (int ****)ppppiStack_70[-1];
      uVar14 = uStack_60._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppiStack_70 + (-4 - (int)ppppiVar12))) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppiVar12,uVar14);
  }
  uStack_60 = 0xf00000000;
  ppppiStack_70 = (int ****)((uint)ppppiStack_70 & 0xffffff00);
  if (puStack_90 != (undefined4 *)0x0) {
    FUN_0078ded0(&puStack_90,0,0);
    uStack_8._0_1_ = 0x1f;
    FUN_0080b1d0(*(undefined4 *)((int)ppppiStack_14 + 0x20),auStack_108,1);
    FUN_0078e040(auStack_108,1);
    FUN_0075e0c0();
  }
  uStack_8._0_1_ = 1;
  pppiStack_18 = pppiStack_8c;
  if ((int ****)pppiStack_8c != (int ****)0x0) {
    LOCK();
    pppiVar3 = (int ***)((int)pppiStack_8c[1] + -1);
    pppiStack_8c[1] = (int **)pppiVar3;
    UNLOCK();
    if (pppiVar3 == (int ***)0x0) {
      (*(code *)**pppiStack_8c)();
      LOCK();
      pppiVar3 = (int ***)((int)pppiStack_18[2] + -1);
      pppiStack_18[2] = (int **)pppiVar3;
      UNLOCK();
      if (pppiVar3 == (int ***)0x0) {
        (*(code *)(*pppiStack_18)[1])();
      }
    }
  }
  FUN_00558df0(&ppppuStack_40,"SmoothCluster",appppuStack_b8);
  uStack_8._0_1_ = 0x20;
  piVar7 = (int *)FUN_00554150("HQFSShadowed",0xc);
  ppppiStack_70 = (int ****)*piVar7;
  iStack_6c = piVar7[1];
  iStack_68 = piVar7[2];
  iStack_64 = piVar7[3];
  uStack_60 = *(undefined8 *)(piVar7 + 4);
  piVar7[4] = 0;
  piVar7[5] = 0xf;
  *(undefined *)piVar7 = 0;
  uStack_8._0_1_ = 0x21;
  FUN_00558df0(&ppppuStack_88,"SmoothCluster",appppuStack_b8);
  uStack_8._0_1_ = 0x22;
  piVar7 = (int *)FUN_00554150("HQVSShadowed",0xc);
  ppppiStack_58 = (int ****)*piVar7;
  iStack_54 = piVar7[1];
  iStack_50 = piVar7[2];
  iStack_4c = piVar7[3];
  uVar2 = *(undefined8 *)(piVar7 + 4);
  piVar7[4] = 0;
  piVar7[5] = 0xf;
  *(undefined *)piVar7 = 0;
  uStack_48._0_4_ = (int ****)uVar2;
  ppppiStack_20 = (int ****)&ppppiStack_70;
  if (0xf < uStack_60._4_4_) {
    ppppiStack_20 = ppppiStack_70;
  }
  uStack_48._4_4_ = (uint)((ulonglong)uVar2 >> 0x20);
  ppppiStack_28 = (int ****)&ppppiStack_58;
  if (0xf < uStack_48._4_4_) {
    ppppiStack_28 = ppppiStack_58;
  }
  pppiStack_24 = (int ***)(int ****)uStack_48;
  uStack_8._0_1_ = 0x23;
  pppiStack_1c = (int ***)(int ****)uStack_60;
  uStack_48 = uVar2;
  FUN_00790e00(&puStack_90,&ppppiStack_28,2);
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  uStack_8._0_1_ = 0x28;
  FUN_005507b0();
  ppppiVar12 = ppppiStack_14;
  if (puStack_90 != (undefined4 *)0x0) {
    FUN_0078ded0(&puStack_90,1,0);
    uStack_8._0_1_ = 0x29;
    FUN_0080b1d0(*(undefined4 *)((int)ppppiStack_14 + 0x20),auStack_108,1);
    FUN_0078e040(auStack_108,1);
    FUN_0075e0c0();
    ppppiVar12 = ppppiStack_14;
  }
  uStack_8._0_1_ = 1;
  ppppiStack_14 = (int ****)pppiStack_8c;
  if ((int ****)pppiStack_8c != (int ****)0x0) {
    LOCK();
    pppiVar3 = (int ***)((int)pppiStack_8c[1] + -1);
    pppiStack_8c[1] = (int **)pppiVar3;
    UNLOCK();
    if (pppiVar3 == (int ***)0x0) {
      (*(code *)**pppiStack_8c)();
      LOCK();
      pppiVar3 = (int ***)((int)ppppiStack_14[2] + -1);
      ppppiStack_14[2] = pppiVar3;
      UNLOCK();
      if (pppiVar3 == (int ***)0x0) {
        (*(code *)(*ppppiStack_14)[1])();
      }
    }
  }
  cVar6 = FUN_0078ba00();
  if (cVar6 != '\0') {
    pppiStack_18 = *(int ****)(*(int *)((int)ppppiVar12 + 0x20) + 0x4f4);
    uVar9 = FUN_00558df0(auStack_120,"SmoothCluster",appppuStack_b8);
    uStack_8._0_1_ = 0x2a;
    uVar9 = FUN_00558c80(&ppppuStack_40,uVar9,"SuperHQFSShadowedFSM");
    uStack_8._0_1_ = 0x2b;
    ppppiStack_14 = (int ****)FUN_00558c20(&ppppuStack_88,uVar9,auStack_138);
    uStack_8._0_1_ = 0x2c;
    uVar9 = FUN_00558df0(&ppppiStack_70,"SmoothCluster",appppuStack_b8);
    uStack_8._0_1_ = 0x2d;
    ppppiStack_28 = (int ****)FUN_00558c80(&ppppiStack_58,uVar9,"SuperHQVSShadowedFSM");
    uStack_8._0_1_ = 0x2e;
    pppiStack_1c = ppppiStack_14[4];
    if ((int ***)0xf < ppppiStack_14[5]) {
      ppppiStack_14 = (int ****)*ppppiStack_14;
    }
    pppiStack_24 = ppppiStack_28[4];
    if ((int ***)0xf < ppppiStack_28[5]) {
      ppppiStack_28 = (int ****)*ppppiStack_28;
    }
    ppppiStack_20 = ppppiStack_14;
    ppppiStack_14 = (int ****)pppiStack_1c;
    FUN_00790e00(&puStack_90,&ppppiStack_28,2);
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    uStack_8._0_1_ = 0x34;
    FUN_005507b0();
    if (puStack_90 != (undefined4 *)0x0) {
      FUN_0078ded0(&puStack_90,0,0);
      uStack_8._0_1_ = 0x35;
      FUN_0080b1d0(*(undefined4 *)((int)ppppiVar12 + 0x20),auStack_108,2);
      FUN_0078e040(auStack_108,2);
      FUN_0075e0c0();
    }
    uStack_8._0_1_ = 1;
    FUN_00550b30();
    pppiStack_18 = *(int ****)(*(int *)((int)ppppiVar12 + 0x20) + 0x4f4);
    uVar9 = FUN_00558df0(&ppppuStack_40,"SmoothCluster",appppuStack_b8);
    uStack_8._0_1_ = 0x36;
    uVar9 = FUN_00558c80(&ppppuStack_88,uVar9,"HQFSShadowedFSM");
    uStack_8._0_1_ = 0x37;
    ppppiStack_14 = (int ****)FUN_00558c20(&ppppiStack_70,uVar9,auStack_138);
    uStack_8._0_1_ = 0x38;
    uVar9 = FUN_00558df0(&ppppiStack_58,"SmoothCluster",appppuStack_b8);
    uStack_8._0_1_ = 0x39;
    ppppiStack_28 = (int ****)FUN_00558c80(auStack_120,uVar9,"HQVSShadowedFSM");
    uStack_8._0_1_ = 0x3a;
    pppiStack_1c = ppppiStack_14[4];
    if ((int ****)0xf < ppppiStack_14[5]) {
      ppppiStack_14 = (int ****)*ppppiStack_14;
    }
    pppiStack_24 = (int ***)((int *****)ppppiStack_28)[4];
    if ((int ****)0xf < ((int *****)ppppiStack_28)[5]) {
      ppppiStack_28 = (int ****)*ppppiStack_28;
    }
    ppppiStack_20 = ppppiStack_14;
    ppppiStack_14 = (int ****)pppiStack_1c;
    FUN_00790e00(&puStack_90,&ppppiStack_28,2);
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    FUN_005507b0();
    uStack_8._0_1_ = 0x40;
    FUN_005507b0();
    if (puStack_90 != (undefined4 *)0x0) {
      FUN_0078ded0(&puStack_90,1,0);
      uStack_8._0_1_ = 0x41;
      FUN_0080b1d0(*(undefined4 *)((int)ppppiVar12 + 0x20),auStack_108,2);
      FUN_0078e040(auStack_108,2);
      FUN_0075e0c0();
    }
    uStack_8._0_1_ = 1;
    FUN_00550b30();
  }
  pppiStack_18 = *(int ****)(*(int *)((int)ppppiVar12 + 0x20) + 0x4f4);
  uVar9 = FUN_00558df0(&ppppuStack_88,"SmoothCluster",appppuStack_b8);
  uStack_8._0_1_ = 0x42;
  ppppiStack_14 = (int ****)FUN_00558c80(&ppppiStack_70,uVar9,&DAT_018fd764);
  uStack_8._0_1_ = 0x43;
  uVar9 = FUN_00558df0(&ppppiStack_58,"SmoothCluster",appppuStack_b8);
  uStack_8._0_1_ = 0x44;
  puStack_98 = (undefined4 *)FUN_00558c80(auStack_120,uVar9,&DAT_01901828);
  uStack_8._0_1_ = 0x45;
  pppiStack_8c = ppppiStack_14[4];
  if (0xf < ppppiStack_14[5]) {
    ppppiStack_14 = (int ****)*ppppiStack_14;
  }
  uStack_94 = puStack_98[4];
  if (0xf < (uint)puStack_98[5]) {
    puStack_98 = (undefined4 *)*puStack_98;
  }
  puStack_90 = ppppiStack_14;
  ppppiStack_14 = (int ****)pppiStack_8c;
  FUN_00790e00(&ppppiStack_20,&puStack_98,2);
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  uStack_8._0_1_ = 0x4a;
  FUN_005507b0();
  if ((int *****)ppppiStack_20 == (int *****)0x0) {
    pcStack_38 = "SmoothClusterVS";
    iStack_34 = 0xf;
    uStack_30 = 0xf0190182c;
    FUN_00790e00(&puStack_90,&pcStack_38,2);
    uStack_8._0_1_ = 0x4c;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x4c;
    if (puStack_90 != (undefined4 *)0x0) {
      FUN_0078ded0(&puStack_90,2,0);
      uStack_8._0_1_ = 0x4d;
      FUN_0080b1d0(*(undefined4 *)((int)ppppiVar12 + 0x20),auStack_108,0);
      FUN_0078e040(auStack_108,0);
      FUN_0075e0c0();
      uVar5 = (undefined)uStack_8;
    }
    uStack_8._0_1_ = uVar5;
    FUN_00550b30();
  }
  else {
    FUN_0078ded0(&ppppiStack_20,2,0);
    uStack_8._0_1_ = 0x4b;
    FUN_0080b1d0(*(undefined4 *)((int)ppppiVar12 + 0x20),auStack_108,0);
    FUN_0078e040(auStack_108,0);
    FUN_0075e0c0();
  }
  uStack_8._0_1_ = 1;
  ppppiStack_14 = (int ****)pppiStack_1c;
  if ((int ****)pppiStack_1c != (int ****)0x0) {
    LOCK();
    pppiVar3 = (int ***)((int)pppiStack_1c[1] + -1);
    pppiStack_1c[1] = (int **)pppiVar3;
    UNLOCK();
    if (pppiVar3 == (int ***)0x0) {
      (*(code *)**pppiStack_1c)();
      LOCK();
      pppiVar3 = (int ***)((int)ppppiStack_14[2] + -1);
      ppppiStack_14[2] = pppiVar3;
      UNLOCK();
      if (pppiVar3 == (int ***)0x0) {
        (*(code *)(*ppppiStack_14)[1])();
      }
    }
  }
  if (DAT_01d60f78 != '\0') {
    pcStack_38 = "SmoothClusterDepthVS";
    iStack_34 = 0x14;
    uStack_30 = 0x14019016e4;
    FUN_00790e00(&ppppiStack_20,&pcStack_38,2);
    uStack_8._0_1_ = 0x4e;
    if ((int *****)ppppiStack_20 != (int *****)0x0) {
      FUN_0078ded0(&ppppiStack_20,0,3);
      uStack_8._0_1_ = 0x4f;
      FUN_0080b190(auStack_108);
      FUN_0078e040(auStack_108,0);
      FUN_0075e0c0();
    }
    uStack_8._0_1_ = 1;
    FUN_00550b30();
  }
  cVar6 = FUN_007ab8c0();
  uStack_48 = 0xf00000000;
  pcVar13 = "SmoothClusterNewShadowMSAA";
  ppppiStack_58 = (int ****)((uint)ppppiStack_58 & 0xffffff00);
  if (cVar6 == '\0') {
    pcVar13 = "SmoothClusterNewShadow";
  }
  ppppiStack_14 = (int ****)(pcVar13 + 1);
  pcVar11 = pcVar13;
  do {
    cVar6 = *pcVar11;
    pcVar11 = pcVar11 + 1;
  } while (cVar6 != '\0');
  FUN_005542c0(pcVar13,(int)pcVar11 - (int)ppppiStack_14);
  uStack_8._0_1_ = 0x50;
  iVar10 = (**(code **)(**(int **)(*(int *)((int)ppppiVar12 + 0x20) + 0x3c) + 0x40))();
  pcVar13 = "";
  uStack_60 = 0xf00000000;
  ppppiStack_70 = (int ****)((uint)ppppiStack_70 & 0xffffff00);
  if (*(char *)(iVar10 + 10) == '\0') {
    pcVar13 = "PancakingFallback";
  }
  ppppiStack_14 = (int ****)(pcVar13 + 1);
  pcVar11 = pcVar13;
  do {
    cVar6 = *pcVar11;
    pcVar11 = pcVar11 + 1;
  } while (cVar6 != '\0');
  FUN_005542c0(pcVar13,(int)pcVar11 - (int)ppppiStack_14);
  uStack_8._0_1_ = 0x51;
  pppiStack_18 = *(int ****)(*(int *)((int)ppppiVar12 + 0x20) + 0x4f4);
  uVar9 = FUN_005f3cd0(auStack_150,&ppppiStack_58,&ppppiStack_70);
  uStack_8._0_1_ = 0x52;
  ppppiStack_14 = (int ****)FUN_00558c80(auStack_a0,uVar9,&DAT_018fd764);
  uStack_8._0_1_ = 0x53;
  uVar9 = FUN_005f3cd0(&ppppuStack_88,&ppppiStack_58,&ppppiStack_70);
  uStack_8._0_1_ = 0x54;
  pcStack_38 = (char *)FUN_00558c80(auStack_120,uVar9,&DAT_01901828);
  uStack_8._0_1_ = 0x55;
  puVar1 = ppppiStack_14 + 4;
  if (0xf < ppppiStack_14[5]) {
    ppppiStack_14 = (int ****)*ppppiStack_14;
  }
  iStack_34 = *(int *)(pcStack_38 + 0x10);
  if (0xf < *(uint *)(pcStack_38 + 0x14)) {
    pcStack_38 = *(char **)pcStack_38;
  }
  uStack_30 = CONCAT44(*puVar1,ppppiStack_14);
  ppppiStack_14 = (int ****)*puVar1;
  FUN_00790e00(&ppppiStack_20,&pcStack_38,2);
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  uStack_8._0_1_ = 0x5a;
  FUN_005507b0();
  if ((int *****)ppppiStack_20 != (int *****)0x0) {
    FUN_0078ded0(&ppppiStack_20,0,4);
    uStack_8._0_1_ = 0x5b;
    uStack_94 = CONCAT22(uStack_94._2_2_,2);
    puStack_90 = (undefined4 *)0x0;
    pppiStack_8c = (int ***)((uint)pppiStack_8c & 0xffffff00);
    FUN_0078e530(&uStack_94);
    FUN_0078e040(auStack_108,0);
    FUN_0075e0c0();
  }
  uStack_8._0_1_ = 0x51;
  ppppiStack_14 = (int ****)pppiStack_1c;
  if ((int ****)pppiStack_1c != (int ****)0x0) {
    LOCK();
    pppiVar3 = (int ***)((int)pppiStack_1c[1] + -1);
    pppiStack_1c[1] = (int **)pppiVar3;
    UNLOCK();
    if (pppiVar3 == (int ***)0x0) {
      (*(code *)**pppiStack_1c)();
      LOCK();
      pppiVar3 = (int ***)((int)ppppiStack_14[2] + -1);
      ppppiStack_14[2] = pppiVar3;
      UNLOCK();
      if (pppiVar3 == (int ***)0x0) {
        (*(code *)(*ppppiStack_14)[1])();
      }
    }
  }
  pppiStack_18 = *(int ****)(*(int *)((int)ppppiVar12 + 0x20) + 0x4f4);
  ppppiStack_14 = (int ****)FUN_00558ce0(auStack_120,&ppppiStack_58,&DAT_018fd764);
  uStack_8._0_1_ = 0x5c;
  pcStack_38 = (char *)FUN_00558ce0(auStack_150,&ppppiStack_58,&DAT_01901828);
  uStack_8._0_1_ = 0x5d;
  puVar1 = ppppiStack_14 + 4;
  if (0xf < ppppiStack_14[5]) {
    ppppiStack_14 = (int ****)*ppppiStack_14;
  }
  iStack_34 = *(int *)(pcStack_38 + 0x10);
  if (0xf < *(uint *)(pcStack_38 + 0x14)) {
    pcStack_38 = *(char **)pcStack_38;
  }
  uStack_30 = CONCAT44(*puVar1,ppppiStack_14);
  ppppiStack_14 = (int ****)*puVar1;
  FUN_00790e00(&ppppiStack_20,&pcStack_38,2);
  FUN_005507b0();
  uStack_8._0_1_ = 0x60;
  FUN_005507b0();
  if ((int *****)ppppiStack_20 != (int *****)0x0) {
    FUN_0078ded0(&ppppiStack_20,0,5);
    uStack_8._0_1_ = 0x61;
    uStack_94 = CONCAT22(uStack_94._2_2_,2);
    puStack_90 = (undefined4 *)0x0;
    pppiStack_8c = (int ***)((uint)pppiStack_8c & 0xffffff00);
    FUN_0078e530(&uStack_94);
    FUN_0078e040(auStack_108,0);
    FUN_0075e0c0();
  }
  pppiVar3 = pppiStack_1c;
  if ((int ****)pppiStack_1c != (int ****)0x0) {
    LOCK();
    pppiVar4 = (int ***)((int)pppiStack_1c[1] + -1);
    pppiStack_1c[1] = (int **)pppiVar4;
    UNLOCK();
    if (pppiVar4 == (int ***)0x0) {
      (*(code *)**pppiStack_1c)();
      LOCK();
      ppppiVar12 = (int ****)(pppiVar3 + 2);
      pppiVar4 = *ppppiVar12;
      *ppppiVar12 = (int ***)((int)*ppppiVar12 + -1);
      UNLOCK();
      if (pppiVar4 == (int ***)0x1) {
        (*(code *)(*pppiVar3)[1])();
      }
    }
  }
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12452 ; VA 0x008117e0 ; FUN_008117e0 */

int __fastcall FUN_008117e0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  char cVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  undefined auStack_9c [80];
  char *pcStack_4c;
  undefined4 uStack_48;
  char *pcStack_44;
  undefined4 uStack_40;
  undefined2 auStack_3c [2];
  undefined4 uStack_38;
  undefined uStack_34;
  int iStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  int *piStack_20;
  uint uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b56a9;
  pvStack_10 = ExceptionList;
  uVar4 = *(undefined4 *)(param_1 + 0x68);
  ExceptionList = &pvStack_10;
  FUN_0078e420();
  cVar5 = FUN_00afc8d0();
  uVar7 = -(uint)(cVar5 != '\0') & 0x100;
  uStack_18 = FUN_0078e450(*(undefined4 *)(*(int *)(param_1 + 0x20) + 0x5c4));
  if (DAT_01d60bc0 == '\0') {
    FUN_0080be70(uVar4,*(undefined4 *)(param_1 + 0x20),0,0,uVar7);
    FUN_0080be70(uVar4,*(undefined4 *)(param_1 + 0x20),0,1,uVar7);
    FUN_0080be70(uVar4,*(undefined4 *)(param_1 + 0x20),1,0,uVar7);
    FUN_0080be70(uVar4,*(undefined4 *)(param_1 + 0x20),1,1,uVar7);
    cVar5 = FUN_0078ba00();
    if (cVar5 == '\0') goto LAB_008118f4;
    if ((DAT_01d60f70 == '\0') || (DAT_01d60f78 == '\0')) {
LAB_008118cc:
      uStack_1c = 0;
    }
    else {
      cVar5 = FUN_0078ba00();
      if (cVar5 == '\0') goto LAB_008118cc;
      cVar5 = FUN_0078bbb0();
      if (cVar5 == '\0') goto LAB_008118cc;
      uStack_1c = 0x400;
    }
    uStack_1c = uStack_1c | uVar7;
    FUN_0080be70(uVar4,*(undefined4 *)(param_1 + 0x20),2,0,uStack_1c);
    uVar8 = 2;
    uVar9 = uStack_1c;
  }
  else {
    FUN_0080be70(uVar4,*(undefined4 *)(param_1 + 0x20),uStack_18,0,uVar7);
    uVar8 = uStack_18;
    uVar9 = uVar7;
  }
  FUN_0080be70(uVar4,*(undefined4 *)(param_1 + 0x20),uVar8,1,uVar9);
LAB_008118f4:
  cVar5 = FUN_0080be70(uVar4,*(undefined4 *)(param_1 + 0x20),0,2,uVar7);
  if (cVar5 == '\0') {
    FUN_0080be70(uVar4,*(undefined4 *)(param_1 + 0x20),0,2,0);
  }
  iVar6 = 0;
  if (DAT_01d60bc0 != '\0') {
    iVar6 = 3;
  }
  uStack_1c = iVar6;
  if (DAT_01d60f78 != '\0') {
    pcStack_4c = "SmoothClusterDepthVS";
    uStack_48 = 0x14;
    pcStack_44 = "SmoothClusterDepthFS";
    uStack_40 = 0x14;
    iVar6 = FUN_00790e00(&iStack_30,&pcStack_4c,2);
    uStack_8 = 0;
    if (iStack_30 != 0) {
      FUN_0078ded0(&iStack_30,uStack_1c,3);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      iStack_24 = 0x1000100;
      uStack_28 = 0;
      piStack_20 = (int *)((uint)piStack_20 & 0xffffff00);
      FUN_0078e480(&uStack_28);
      uStack_14 = (int *)(uint)CONCAT21(0x104,(undefined)uStack_14);
      FUN_0078e510((int)&uStack_14 + 1);
      FUN_0078e040(auStack_9c,0);
      iVar6 = FUN_0075e0c0();
    }
    uStack_8 = 0xffffffff;
    uStack_14 = piStack_2c;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_2c + 1;
      iVar3 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar1 = uStack_14 + 2;
        iVar3 = *piVar1;
        iVar6 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          iVar6 = (**(code **)(*uStack_14 + 4))();
        }
      }
    }
  }
  if ((DAT_01d60bc0 == '\0') || (uStack_18 != 0)) {
    cVar5 = FUN_007ab8c0();
    uStack_18 = -(uint)(cVar5 != '\0') & 0x20;
    iVar6 = (**(code **)(**(int **)(*(int *)(param_1 + 0x20) + 0x3c) + 0x40))();
    uVar7 = 0;
    if (*(char *)(iVar6 + 10) != '\0') {
      uVar7 = 0x40;
    }
    FUN_007910b0(&iStack_30,"SmoothClusterNewShadowVS_",0x19,uVar7 | uStack_18,
                 "SmoothClusterNewShadowFS_",0x19,uVar7 | uStack_18);
    uStack_8 = 2;
    if (iStack_30 != 0) {
      FUN_0078ded0(&iStack_30,uStack_1c,4);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      uStack_28 = CONCAT22(uStack_28._2_2_,2);
      iStack_24 = 0;
      piStack_20 = (int *)((uint)piStack_20 & 0xffffff00);
      FUN_0078e530(&uStack_28);
      FUN_0078e040(auStack_9c,0);
      FUN_0075e0c0();
    }
    uStack_8 = 0xffffffff;
    uStack_14 = piStack_2c;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar6 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        iVar6 = uStack_14[2] + -1;
        uStack_14[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*uStack_14 + 4))();
        }
      }
    }
    iVar6 = FUN_007910b0(&iStack_24,"SmoothClusterNewShadowVS_",0x19,uStack_18,
                         "SmoothClusterNewShadowFS_",0x19,uStack_18);
    uStack_8 = 4;
    if (iStack_24 != 0) {
      FUN_0078ded0(&iStack_24,uStack_1c,5);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      auStack_3c[0] = 2;
      uStack_38 = 0;
      uStack_34 = 0;
      FUN_0078e530(auStack_3c);
      FUN_0078e040(auStack_9c,0);
      iVar6 = FUN_0075e0c0();
    }
    piVar1 = piStack_20;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piVar2 = piStack_20 + 1;
      iVar3 = *piVar2;
      iVar6 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar6 = (**(code **)*piStack_20)();
        LOCK();
        piVar2 = piVar1 + 2;
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          iVar6 = (**(code **)(*piVar1 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 12453 ; VA 0x00811c00 ; FUN_00811c00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00811c00(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  float fVar5;
  undefined *puVar6;
  char cVar7;
  undefined uVar8;
  float *pfVar9;
  float10 fVar10;
  double dVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  undefined8 uVar15;
  undefined auStack_e8 [64];
  undefined auStack_a8 [12];
  float fStack_9c;
  float fStack_98;
  float fStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  double dStack_58;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  undefined8 uStack_40;
  float fStack_38;
  uint uStack_34;
  float fStack_30;
  undefined8 uStack_2c;
  float fStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017b56d4;
  pvStack_1c = ExceptionList;
  if (*(int *)(param_1 + 0x24) != 0) {
    ExceptionList = &pvStack_1c;
    uStack_34 = param_1;
    puVar6 = &stack0xfffffffc;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb3838)
       && (ExceptionList = &pvStack_1c, FUN_016f3809(&DAT_01eb3838), puVar6 = puStack_20,
          DAT_01eb3838 == -1)) {
      uStack_14 = 0;
      uVar15 = FUN_0152dab0("Render","updateWater",0xffffffff);
      DAT_01eb3834 = (undefined4)((ulonglong)uVar15 >> 0x20);
      DAT_01eb3830 = (undefined4)uVar15;
      uStack_14 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb3838);
      puVar6 = puStack_20;
    }
    puStack_20 = puVar6;
    uStack_74 = DAT_01eb3830;
    uStack_88 = DAT_01eb3830;
    uStack_70 = DAT_01eb3834;
    uStack_84 = DAT_01eb3834;
    uStack_80 = FUN_0152d930(DAT_01eb3830,DAT_01eb3834);
    iVar1 = *(int *)(param_1 + 0x20);
    iVar2 = *(int *)(param_1 + 0x24);
    uStack_14 = 1;
    uVar15 = *(undefined8 *)(iVar2 + 0x140);
    uStack_40._4_4_ = (float)((ulonglong)uVar15 >> 0x20);
    uStack_40._0_4_ = (float)uVar15;
    fStack_5c = (float)uStack_40 * (float)uStack_40;
    fStack_38 = *(float *)(iVar2 + 0x148);
    fStack_64 = uStack_40._4_4_ * uStack_40._4_4_;
    fStack_60 = DAT_018ce2f8 - *(float *)(iVar2 + 0x14c);
    fStack_4c = *(float *)(iVar2 + 0x14c) * _DAT_0190195c + DAT_018fde94;
    fStack_48 = *(float *)(iVar2 + 0x154);
    fStack_68 = fStack_38 * fStack_38;
    uStack_6c = *(undefined4 *)(iVar2 + 0x158);
    dStack_58 = (double)(*(float *)(iVar2 + 0x150) * (float)*(double *)(iVar1 + 0x18)) +
                *(double *)(uStack_34 + 0x248);
    *(double *)(uStack_34 + 0x248) = dStack_58;
    dVar11 = (double)fStack_48;
    uStack_40 = uVar15;
    fStack_24 = fStack_68;
    uStack_2c._0_4_ = fStack_5c;
    uStack_2c._4_4_ = fStack_64;
    FUN_017267a0();
    fStack_44 = DAT_018f784c;
    if (DAT_018f784c <= (float)dVar11 * _DAT_01901958) {
      fStack_44 = (float)dVar11 * _DAT_01901958;
    }
    fStack_44 = DAT_019011d8 / fStack_44;
    dStack_58 = (double)((float)dStack_58 * fStack_44);
    fVar10 = (float10)FUN_01728560();
    dStack_58 = (double)fVar10;
    fStack_50 = *(float *)(*(int *)(iVar1 + 0x4fc) + 0x14);
    cVar7 = FUN_0080a510(iVar1 + 0x40,iVar2,fStack_44,(float)fVar10,fStack_48);
    fVar5 = uStack_2c._4_4_;
    if ((cVar7 != '\0') && (fStack_50 != 0.0)) {
      fVar12 = (fStack_4c * fStack_60) / (fStack_60 - DAT_018ce2f8);
      fVar13 = 0.0;
      if (0.0 <= fVar12) {
        fVar13 = fVar12;
      }
      iVar1 = *(int *)(*(int *)(uStack_34 + 0x20) + 0x51c);
      fVar12 = *(float *)(iVar1 + 0x10c);
      fStack_50 = fStack_4c;
      if (fVar13 <= fStack_4c) {
        fStack_50 = fVar13;
      }
      uVar15 = *(undefined8 *)(iVar1 + 0x104);
      uStack_2c._0_4_ = (float)uVar15;
      uStack_2c._4_4_ = (float)((ulonglong)uVar15 >> 0x20);
      fStack_38 = fVar12 * fVar12;
      if (fVar12 * fVar12 <= *(float *)(iVar1 + 0x60)) {
        fStack_38 = *(float *)(iVar1 + 0x60);
      }
      fVar13 = uStack_2c._4_4_ * uStack_2c._4_4_;
      if (uStack_2c._4_4_ * uStack_2c._4_4_ <= *(float *)(iVar1 + 0x5c)) {
        fVar13 = *(float *)(iVar1 + 0x5c);
      }
      fVar14 = (float)uStack_2c * (float)uStack_2c;
      if ((float)uStack_2c * (float)uStack_2c <= *(float *)(iVar1 + 0x58)) {
        fVar14 = *(float *)(iVar1 + 0x58);
      }
      fStack_38 = fStack_38 * fStack_24;
      uStack_40 = CONCAT44(fVar5 * fVar13,fStack_5c * fVar14);
      fStack_50 = fStack_4c * DAT_018f993c + fStack_50;
      uStack_2c = uVar15;
      fStack_24 = fVar12;
      FUN_007a0bd0(0);
      fStack_30 = (float)uStack_40;
      uStack_2c._0_4_ = uStack_40._4_4_;
      uStack_2c._4_4_ = fStack_38;
      fStack_24 = 1.0;
      FUN_007a0430(&fStack_30);
      FUN_007a0600(&uStack_40,fStack_50,fStack_4c);
    }
    uVar4 = uStack_34;
    uVar3 = *(undefined4 *)(uStack_34 + 0x24);
    FUN_01165e00(auStack_e8);
    uStack_34 = 0;
    do {
      fStack_94 = DAT_018f7864;
      if ((uStack_34 & 2) != 0) {
        fStack_94 = DAT_018ce2f8;
      }
      fStack_98 = DAT_018f7864;
      if ((uStack_34 & 1) != 0) {
        fStack_98 = DAT_018ce2f8;
      }
      uStack_90 = 0x3f800000;
      uStack_8c = 0x3f800000;
      FUN_01165b90(auStack_a8,&fStack_98);
      pfVar9 = (float *)FUN_011658d0(&uStack_40);
      uStack_2c._4_4_ = DAT_018ce2f8 / fStack_9c;
      fStack_24 = pfVar9[2] * uStack_2c._4_4_;
      uStack_2c._0_4_ = *pfVar9 * uStack_2c._4_4_;
      uStack_2c._4_4_ = pfVar9[1] * uStack_2c._4_4_;
      cVar7 = FUN_0080a510(&uStack_2c,uVar3,fStack_44,(float)dStack_58,fStack_48);
      if (cVar7 != '\0') {
        uVar8 = 1;
        goto LAB_00812062;
      }
      uStack_34 = uStack_34 + 1;
    } while ((int)uStack_34 < 4);
    uVar8 = 0;
LAB_00812062:
    *(undefined *)(uVar4 + 0x244) = uVar8;
    *(float *)(uVar4 + 0x214) = fStack_44;
    *(float *)(uVar4 + 0x218) = (float)dStack_58;
    *(float *)(uVar4 + 0x21c) = fStack_48;
    *(undefined4 *)(uVar4 + 0x220) = 0;
    fStack_24 = 0.0;
    *(float *)(uVar4 + 0x224) = fStack_5c;
    *(float *)(uVar4 + 0x228) = fStack_64;
    *(float *)(uVar4 + 0x22c) = fStack_68;
    *(undefined4 *)(uVar4 + 0x230) = 0x3f800000;
    fStack_30 = (DAT_018ce2f8 - fStack_60) / fStack_4c;
    uStack_2c = CONCAT44(uStack_6c,fStack_60);
    *(float *)(uVar4 + 0x234) = fStack_30;
    *(float *)(uVar4 + 0x238) = fStack_60;
    *(undefined4 *)(uVar4 + 0x23c) = uStack_6c;
    *(undefined4 *)(uVar4 + 0x240) = 0;
    uStack_14 = 2;
    FUN_0152dda0(uStack_74,uStack_70,uStack_80);
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 12454 ; VA 0x00812190 ; FUN_00812190 */

undefined4 __thiscall
FUN_00812190(int param_1,uint *param_2,undefined4 param_3,int param_4,int *param_5,
            undefined4 param_6,undefined4 param_7,uint param_8)

{
  uint *puVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  uint uVar5;
  undefined *puVar6;
  undefined uVar7;
  uint uVar8;
  int iVar9;
  undefined4 uVar10;
  int iVar11;
  undefined4 *puVar12;
  undefined4 *puVar13;
  undefined8 uVar14;
  undefined auStack_c0 [4];
  int *piStack_bc;
  undefined auStack_a8 [4];
  int *piStack_a4;
  int *piStack_8c;
  undefined4 uStack_84;
  undefined4 uStack_80;
  int *piStack_7c;
  undefined auStack_78 [4];
  int *piStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 uStack_68;
  undefined4 uStack_60;
  int *piStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  int iStack_50;
  int *piStack_4c;
  int *piStack_48;
  int *piStack_44;
  int *piStack_40;
  int *piStack_3c;
  int *piStack_38;
  int *piStack_34;
  int *piStack_30;
  undefined4 *puStack_2c;
  uint uStack_28;
  int *piStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar4 = param_5;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b57fb;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff18;
  piStack_38 = (int *)*param_5;
  piStack_5c = (int *)param_5[3];
  uStack_28 = (param_5[1] - (int)piStack_38) / 0x14;
  puVar1 = (uint *)(param_5 + 0xf);
  puStack_2c = (undefined4 *)param_5[6];
  iStack_50 = (param_5[4] - (int)piStack_5c) / 0x14;
  piStack_34 = param_5 + 9;
  piStack_30 = param_5 + 0xc;
  uVar8 = param_5[7] - (int)puStack_2c >> 3;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  puVar6 = &stack0xffffff18;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb37b8) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb37b8), puVar6 = puStack_14,
     DAT_01eb37b8 == -1)) {
    uStack_8 = 0;
    uVar14 = FUN_0152dab0("Render","uploadGeometry",0xffffffff);
    DAT_01eb37b4 = (undefined4)((ulonglong)uVar14 >> 0x20);
    DAT_01eb37b0 = (undefined4)uVar14;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb37b8);
    puVar6 = puStack_14;
  }
  puStack_14 = puVar6;
  uStack_58 = DAT_01eb37b0;
  uStack_70 = DAT_01eb37b0;
  uStack_54 = DAT_01eb37b4;
  uStack_6c = DAT_01eb37b4;
  uStack_68 = FUN_0152d930(DAT_01eb37b0,DAT_01eb37b4);
  uStack_8 = 1;
  piVar3 = *(int **)(*(int *)(param_1 + 0x20) + 0x3c);
  iVar9 = (**(code **)(*piVar3 + 0x40))();
  uVar5 = uStack_28;
  if (((0xfffe < uStack_28) || (0xfffe < uVar8)) && (*(char *)(iVar9 + 0xc) == '\0')) {
    *param_2 = *param_2 | 0xffffff;
    puVar13 = (undefined4 *)param_2[1];
    param_2[1] = 0;
    if (puVar13 != (undefined4 *)0x0) {
      (**(code **)*puVar13)(1);
    }
    puVar13 = (undefined4 *)param_2[2];
    param_2[2] = 0;
    if (puVar13 != (undefined4 *)0x0) {
      (**(code **)*puVar13)(1);
    }
    puVar13 = (undefined4 *)param_2[3];
    param_2[3] = 0;
    if (puVar13 != (undefined4 *)0x0) {
      (**(code **)*puVar13)(1);
    }
    puVar13 = (undefined4 *)param_2[4];
    param_2[4] = 0;
    if (puVar13 != (undefined4 *)0x0) {
      (**(code **)*puVar13)(1);
    }
    uStack_8 = 2;
    FUN_0152dda0(uStack_58,uStack_54,uStack_68);
    ExceptionList = pvStack_10;
    return 0;
  }
  uStack_8._0_1_ = 3;
  if (DAT_01d6d15c != '\0') {
    if (uStack_28 != 0) {
      iVar9 = uStack_28 * param_4;
      (**(code **)(*piVar3 + 0x3c))(&piStack_44,0,iVar9,param_4,0);
      uStack_8._0_1_ = 0x11;
      (**(code **)(*piStack_44 + 0x18))(0,piStack_38,iVar9);
      piStack_24 = (int *)0x0;
      piStack_20 = (int *)0x0;
      uStack_8._0_1_ = 0x12;
      uVar10 = FUN_00809760(0);
      FUN_0147c0e0(&uStack_80,uVar10,&piStack_44,&piStack_24);
      uStack_8._0_1_ = 0x14;
      piStack_18 = piStack_20;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar9 = piStack_20[1] + -1;
        piStack_20[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          iVar9 = piStack_18[2] + -1;
          piStack_18[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
      FUN_0147c720(&uStack_80,0,0,0,uStack_28);
      uStack_8._0_1_ = 0x15;
      FUN_0147c770();
      uStack_8._0_1_ = 0x16;
      uVar7 = (undefined)uStack_8;
      uStack_8._0_1_ = 0x16;
      if (*puVar1 != param_5[0x10]) {
        piStack_18 = (int *)(uVar8 << 3);
        (**(code **)(*piVar3 + 0x3c))(&piStack_24,0,piStack_18,8,0);
        uStack_8._0_1_ = 0x17;
        (**(code **)(*piStack_24 + 0x18))(0,puStack_2c,piStack_18);
        iVar9 = (-(uint)(0xfffe < uVar8) & 2) + 2;
        (**(code **)(*piVar3 + 0x3c))
                  (&piStack_4c,1,((int)(param_5[0x10] - *puVar1) >> 2) * iVar9,iVar9,0);
        uStack_8._0_1_ = 0x18;
        piStack_38 = piStack_4c;
        puStack_2c = (undefined4 *)(**(code **)(*piStack_4c + 0x10))();
        puVar13 = (undefined4 *)*puVar1;
        piStack_18 = (int *)((param_5[0x10] - (int)puVar13) + 3U >> 2);
        if (uVar8 < 0xffff) {
          if ((undefined4 *)param_5[0x10] < puVar13) {
            piStack_18 = (int *)0x0;
          }
          param_5 = (int *)0x0;
          puVar12 = puStack_2c;
          if (piStack_18 != (int *)0x0) {
            do {
              *(short *)puVar12 = (short)*puVar13;
              puVar13 = puVar13 + 1;
              param_5 = (int *)((int)param_5 + 1);
              puVar12 = (undefined4 *)((int)puVar12 + 2);
            } while (param_5 != piStack_18);
          }
        }
        else {
          if ((undefined4 *)param_5[0x10] < puVar13) {
            piStack_18 = (int *)0x0;
          }
          param_5 = (int *)0x0;
          puVar12 = puStack_2c;
          if (piStack_18 != (int *)0x0) {
            do {
              *puVar12 = *puVar13;
              puVar13 = puVar13 + 1;
              param_5 = (int *)((int)param_5 + 1);
              puVar12 = puVar12 + 1;
            } while (param_5 != piStack_18);
          }
        }
        (**(code **)(*piStack_38 + 0x14))();
        uVar10 = FUN_00809760(1);
        FUN_0147c0e0(auStack_78,uVar10,&piStack_24,&piStack_4c);
        uStack_8._0_1_ = 0x19;
        uVar10 = FUN_0147c720(auStack_78,0,0,0,(int)(piVar4[0x10] - *puVar1) >> 2);
        FUN_0076b300(uVar10);
        FUN_00550b30();
        FUN_00550b30();
        FUN_00550b30();
        uStack_8._0_1_ = 0x16;
        FUN_00550b30();
        uVar7 = (undefined)uStack_8;
      }
      uStack_8._0_1_ = uVar7;
      piStack_18 = (int *)FUN_01674e20(0xb4);
      iVar9 = iStack_1c;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x1a);
      if (piStack_18 == (int *)0x0) {
        uVar8 = 0;
      }
      else {
        uVar10 = FUN_00809610();
        uVar8 = FUN_008071f0(iVar9,auStack_c0,auStack_a8,0,param_6,param_8,uVar10,1,param_3,0);
      }
      puVar13 = (undefined4 *)param_2[1];
      param_2[1] = uVar8;
      if (puVar13 != (undefined4 *)0x0) {
        (**(code **)*puVar13)(1);
      }
      piVar4 = piStack_a4;
      if (piStack_a4 != (int *)0x0) {
        LOCK();
        iVar9 = piStack_a4[1] + -1;
        piStack_a4[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piStack_a4)();
          LOCK();
          piVar2 = piVar4 + 2;
          iVar9 = *piVar2 + -1;
          *piVar2 = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      if (piStack_bc != (int *)0x0) {
        LOCK();
        iVar9 = piStack_bc[1] + -1;
        piStack_bc[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piStack_bc)();
          LOCK();
          iVar9 = piStack_bc[2] + -1;
          piStack_bc[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piStack_bc + 4))();
          }
        }
      }
      piVar4 = piStack_7c;
      if (piStack_7c != (int *)0x0) {
        LOCK();
        iVar9 = piStack_7c[1] + -1;
        piStack_7c[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piStack_7c)();
          LOCK();
          piVar2 = piVar4 + 2;
          iVar9 = *piVar2 + -1;
          *piVar2 = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      piVar4 = piStack_40;
      uStack_8._0_1_ = 3;
      if (piStack_40 != (int *)0x0) {
        LOCK();
        iVar9 = piStack_40[1] + -1;
        piStack_40[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piStack_40)();
          LOCK();
          piVar2 = piVar4 + 2;
          iVar9 = *piVar2 + -1;
          *piVar2 = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
    }
    if (iStack_50 != 0) {
      iVar9 = iStack_50 * param_4;
      (**(code **)(*piVar3 + 0x3c))(&piStack_24,0,iVar9,param_4,0);
      uStack_8._0_1_ = 0x1b;
      (**(code **)(*piStack_24 + 0x18))(0,piStack_5c,iVar9);
      iVar9 = iStack_1c;
      piStack_44 = (int *)0x0;
      piStack_40 = (int *)0x0;
      uStack_8._0_1_ = 0x1c;
      uVar10 = FUN_00809760(0);
      FUN_0147c0e0(&uStack_80,uVar10,&piStack_24,&piStack_44);
      piVar4 = piStack_40;
      uStack_8._0_1_ = 0x1e;
      if (piStack_40 != (int *)0x0) {
        LOCK();
        iVar11 = piStack_40[1] + -1;
        piStack_40[1] = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          (**(code **)*piStack_40)();
          LOCK();
          piVar3 = piVar4 + 2;
          iVar11 = *piVar3 + -1;
          *piVar3 = iVar11;
          UNLOCK();
          if (iVar11 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      FUN_0147c720(&uStack_80,0,0,0,iStack_50);
      uStack_8._0_1_ = 0x1f;
      iVar11 = FUN_01674e20(0xb4);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x20);
      if (iVar11 == 0) {
        uVar8 = 0;
      }
      else {
        uVar10 = FUN_008099e0();
        uVar8 = FUN_008071f0(iVar9,auStack_a8,auStack_a8,0,param_7,param_7,uVar10,6,param_3,6);
      }
      puVar13 = (undefined4 *)param_2[2];
      param_2[2] = uVar8;
      if (puVar13 != (undefined4 *)0x0) {
        (**(code **)*puVar13)(1);
      }
      if (piStack_a4 != (int *)0x0) {
        LOCK();
        iVar9 = piStack_a4[1] + -1;
        piStack_a4[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piStack_a4)();
          LOCK();
          iVar9 = piStack_a4[2] + -1;
          piStack_a4[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piStack_a4 + 4))();
          }
        }
      }
      piVar4 = piStack_7c;
      if (piStack_7c != (int *)0x0) {
        LOCK();
        iVar9 = piStack_7c[1] + -1;
        piStack_7c[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piStack_7c)();
          LOCK();
          piVar3 = piVar4 + 2;
          iVar9 = *piVar3 + -1;
          *piVar3 = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      piVar4 = piStack_20;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar9 = piStack_20[1] + -1;
        piStack_20[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar3 = piVar4 + 2;
          iVar9 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar9 == 1) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
    }
    uStack_8 = 0x21;
    goto LAB_00812c51;
  }
  piStack_18 = (int *)(uStack_28 * param_4);
  (**(code **)(*piVar3 + 0x3c))(&piStack_24,0,piStack_18,param_4,0);
  uStack_8._0_1_ = 4;
  (**(code **)(*piStack_24 + 0x18))(0,piStack_38,piStack_18);
  iVar9 = (-(uint)(0xfffe < uVar5) & 2) + 2;
  piStack_18 = (int *)((piStack_34[1] - *piStack_34 >> 2) + (piStack_30[1] - *piStack_30 >> 2));
  (**(code **)(*piVar3 + 0x3c))(&piStack_4c,1,(int)piStack_18 * iVar9,iVar9,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (uStack_28 < 0xffff) {
    FUN_00806ca0(piStack_4c,piStack_34,piStack_30);
  }
  else {
    FUN_00806d20();
  }
  uVar10 = FUN_00809760(0);
  FUN_0147c0e0(auStack_78,uVar10,&piStack_24,&piStack_4c);
  uStack_8._0_1_ = 6;
  FUN_0147c720(auStack_78,0,0,0,piStack_18);
  uStack_8._0_1_ = 7;
  FUN_0147c770();
  uStack_8._0_1_ = 8;
  uVar7 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  if (*puVar1 != param_5[0x10]) {
    piStack_18 = (int *)(uVar8 << 3);
    (**(code **)(*piVar3 + 0x3c))(&piStack_3c,0,piStack_18,8,0);
    uStack_8._0_1_ = 9;
    (**(code **)(*piStack_3c + 0x18))(0,puStack_2c,piStack_18);
    iVar9 = (-(uint)(0xfffe < uVar8) & 2) + 2;
    (**(code **)(*piVar3 + 0x3c))
              (&uStack_60,1,((int)(param_5[0x10] - *puVar1) >> 2) * iVar9,iVar9,0);
    uStack_84 = 0;
    uStack_80 = 0;
    piStack_7c = (int *)0x0;
    if (uVar8 < 0xffff) {
      uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
      FUN_00806ca0(uStack_60,puVar1,&uStack_84);
    }
    else {
      uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
      FUN_00806d20(uStack_60,puVar1,&uStack_84);
    }
    uStack_8._0_1_ = 10;
    FUN_0056d320();
    uVar10 = FUN_00809760(1);
    FUN_0147c0e0(&piStack_44,uVar10,&piStack_3c,&uStack_60);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
    uVar10 = FUN_0147c720(&piStack_44,0,0,0,(int)(param_5[0x10] - *puVar1) >> 2);
    FUN_0076b300(uVar10);
    if (piStack_8c != (int *)0x0) {
      LOCK();
      iVar9 = piStack_8c[1] + -1;
      piStack_8c[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_8c)();
        LOCK();
        iVar9 = piStack_8c[2] + -1;
        piStack_8c[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_8c + 4))();
        }
      }
    }
    piVar4 = piStack_40;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_40[1] + -1;
      piStack_40[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_40)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar9 = *piVar3 + -1;
        *piVar3 = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    piVar4 = piStack_5c;
    if (piStack_5c != (int *)0x0) {
      LOCK();
      iVar9 = piStack_5c[1] + -1;
      piStack_5c[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_5c)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar9 = *piVar3 + -1;
        *piVar3 = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    piVar4 = piStack_38;
    uStack_8._0_1_ = 8;
    uVar7 = (undefined)uStack_8;
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_38[1] + -1;
      piStack_38[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_38)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar9 = *piVar3 + -1;
        *piVar3 = iVar9;
        UNLOCK();
        uVar7 = (undefined)uStack_8;
        if (iVar9 == 0) {
          (**(code **)(*piVar4 + 4))();
          uVar7 = (undefined)uStack_8;
        }
      }
    }
  }
  uStack_8._0_1_ = uVar7;
  piVar4 = piStack_34;
  if (*piStack_34 == piStack_34[1]) {
    param_8 = 0;
  }
  else {
    piStack_5c = (int *)FUN_01674e20(0xb4);
    iVar9 = iStack_1c;
    uStack_8._0_1_ = 0xe;
    if (piStack_5c == (int *)0x0) {
      param_8 = 0;
    }
    else {
      uVar10 = FUN_00809610();
      param_8 = FUN_008071f0(iVar9,auStack_c0,auStack_a8,0,param_6,param_8,uVar10,1,param_3,0);
    }
    uStack_8._0_1_ = 8;
  }
  if (*piStack_30 == piStack_30[1]) {
LAB_0081268a:
    uVar8 = 0;
  }
  else {
    iVar11 = FUN_01674e20(0xb4);
    iVar9 = iStack_1c;
    uStack_8._0_1_ = 0xf;
    if (iVar11 == 0) goto LAB_0081268a;
    uVar10 = FUN_008099e0();
    uVar8 = FUN_008071f0(iVar9,auStack_c0,auStack_c0,piVar4[1] - *piVar4 >> 2,param_7,param_7,uVar10
                         ,6,param_3,6);
  }
  puVar13 = (undefined4 *)param_2[1];
  param_2[1] = param_8;
  if (puVar13 != (undefined4 *)0x0) {
    (**(code **)*puVar13)(1);
  }
  puVar13 = (undefined4 *)param_2[2];
  param_2[2] = uVar8;
  if (puVar13 != (undefined4 *)0x0) {
    (**(code **)*puVar13)(1);
  }
  if (piStack_a4 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_a4[1] + -1;
    piStack_a4[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_a4)();
      LOCK();
      iVar9 = piStack_a4[2] + -1;
      piStack_a4[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piStack_a4 + 4))();
      }
    }
  }
  if (piStack_bc != (int *)0x0) {
    LOCK();
    iVar9 = piStack_bc[1] + -1;
    piStack_bc[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_bc)();
      LOCK();
      iVar9 = piStack_bc[2] + -1;
      piStack_bc[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piStack_bc + 4))();
      }
    }
  }
  if (piStack_74 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_74[1] + -1;
    piStack_74[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_74)();
      LOCK();
      iVar9 = piStack_74[2] + -1;
      piStack_74[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piStack_74 + 4))();
      }
    }
  }
  if (piStack_48 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_48[1] + -1;
    piStack_48[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_48)();
      LOCK();
      iVar9 = piStack_48[2] + -1;
      piStack_48[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piStack_48 + 4))();
      }
    }
  }
  piVar4 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_20[1] + -1;
    piStack_20[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar9 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uStack_8 = 0x10;
LAB_00812c51:
  FUN_0152dda0(uStack_58,uStack_54,uStack_68);
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 12455 ; VA 0x00812c7a ; Catch@00812c7a */

undefined * Catch_00812c7a(void)

{
  undefined4 uVar1;
  int iVar2;
  int unaff_EBP;
  char *pcVar3;
  int iVar4;
  
  if (DAT_01f6dcc0 != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0xc0) + 4))();
    FUN_01677650(DAT_01f6dcc0,"Error creating terrain geometry buffers: %s",uVar1);
  }
  if (DAT_01d6d15c == '\0') {
    if (DAT_01f6dcc0 == '\0') goto LAB_00812cf7;
    iVar4 = (*(int **)(unaff_EBP + -0x2c))[1] - **(int **)(unaff_EBP + -0x2c) >> 2;
    iVar2 = (*(int **)(unaff_EBP + -0x30))[1] - **(int **)(unaff_EBP + -0x30) >> 2;
    uVar1 = *(undefined4 *)(unaff_EBP + -0x24);
    pcVar3 = "Geometry: %d vertices, %d solid indices, %d water indices";
  }
  else {
    if (DAT_01f6dcc0 == '\0') goto LAB_00812cf7;
    iVar4 = 0;
    iVar2 = *(int *)(unaff_EBP + -0x4c);
    uVar1 = *(undefined4 *)(unaff_EBP + -0x24);
    pcVar3 = "Geometry: %d solid vertices, %d water vertices";
  }
  FUN_01677490(DAT_01f6dcc0,pcVar3,uVar1,iVar2,iVar4);
LAB_00812cf7:
  FUN_0086f2f0(3,"Out of VRAM while uploading %d Mb of terrain render data",
               *(int *)(unaff_EBP + -0x24) * *(int *)(unaff_EBP + 0x10));
  FUN_0080b0e0(1);
  return &LAB_00812d1e;
}



/* FUNCTION 12456 ; VA 0x00812db0 ; FUN_00812db0 */

undefined4 FUN_00812db0(undefined4 param_1,int param_2,int param_3,int param_4,int param_5)

{
  int *piVar1;
  char cVar2;
  char *pcVar3;
  char *pcVar4;
  int iVar5;
  char *pcVar6;
  int iVar7;
  undefined auStack_6c [80];
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b5820;
  pvStack_10 = ExceptionList;
  uStack_14 = *(undefined4 *)(param_2 + 0x4f4);
  pcVar3 = (&PTR_s_SmoothWaterSuperHQFS__01d61f88)[param_5];
  if (pcVar3 == (char *)0x0) {
    iVar5 = 0;
  }
  else {
    pcVar4 = pcVar3;
    do {
      cVar2 = *pcVar4;
      pcVar4 = pcVar4 + 1;
    } while (cVar2 != '\0');
    iVar5 = (int)pcVar4 - (int)(pcVar3 + 1);
  }
  pcVar4 = (&PTR_s_SmoothWaterHQVS__01d61f7c)[param_5];
  if (pcVar4 == (char *)0x0) {
    iVar7 = 0;
  }
  else {
    pcVar6 = pcVar4;
    do {
      cVar2 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar2 != '\0');
    iVar7 = (int)pcVar6 - (int)(pcVar4 + 1);
  }
  ExceptionList = &pvStack_10;
  FUN_007910b0(&iStack_1c,pcVar4,iVar7,*(undefined4 *)(&DAT_019014dc + param_4 * 4),pcVar3,iVar5,
               *(undefined4 *)(&DAT_019014dc + param_4 * 4));
  uStack_8 = 0;
  if (iStack_1c != 0) {
    FUN_0078ded0(&iStack_1c,param_5,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_0080bb60(param_2,auStack_6c,param_3,param_3 + 8,param_4);
    FUN_0078e040(auStack_6c,param_4);
    FUN_0075e0c0();
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_18[1] + -1;
      piStack_18[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piStack_18 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_18[1] + -1;
    piStack_18[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 12457 ; VA 0x00812f20 ; FUN_00812f20 */

void __thiscall FUN_00812f20(int *param_1,uint param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  
  uVar3 = param_2;
  puVar5 = (undefined4 *)param_1[1];
  iVar7 = *param_1;
  uVar8 = (int)puVar5 - iVar7 >> 3;
  uVar6 = param_1[2] - iVar7 >> 3;
  if (uVar6 < param_2) {
    if (0x1fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar1 = param_2;
    if ((uVar6 <= 0x1fffffff - (uVar6 >> 1)) && (uVar1 = (uVar6 >> 1) + uVar6, uVar1 < param_2)) {
      uVar1 = param_2;
    }
    param_2 = uVar1;
    iVar4 = FUN_00578020(param_2);
    puVar5 = (undefined4 *)(iVar4 + uVar8 * 8);
    for (iVar7 = uVar3 - uVar8; iVar7 != 0; iVar7 = iVar7 + -1) {
      *puVar5 = 0;
      puVar5[1] = 0;
      puVar5 = puVar5 + 2;
    }
    puVar5 = (undefined4 *)*param_1;
    puVar2 = (undefined4 *)param_1[1];
    if (puVar5 != puVar2) {
      iVar7 = iVar4 - (int)puVar5;
      do {
        *(undefined4 *)(iVar7 + (int)puVar5) = *puVar5;
        *(undefined4 *)(iVar7 + 4 + (int)puVar5) = puVar5[1];
        puVar5 = puVar5 + 2;
      } while (puVar5 != puVar2);
    }
    FUN_00654980(iVar4,uVar3,param_2);
    return;
  }
  if (uVar8 < param_2) {
    iVar7 = param_2 - uVar8;
    if (iVar7 != 0) {
      do {
        *puVar5 = 0;
        puVar5[1] = 0;
        puVar5 = puVar5 + 2;
        iVar7 = iVar7 + -1;
      } while (iVar7 != 0);
      param_1[1] = (int)puVar5;
      return;
    }
  }
  else {
    if (param_2 == uVar8) {
      return;
    }
    puVar5 = (undefined4 *)(iVar7 + param_2 * 8);
  }
  param_1[1] = (int)puVar5;
  return;
}



/* FUNCTION 12458 ; VA 0x00813030 ; FUN_00813030 */

undefined4 * __thiscall
FUN_00813030(undefined4 *param_1,int param_2,undefined4 param_3,int param_4,int param_5)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b5861;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0147cac0(*(undefined4 *)(param_2 + 0x3c));
  *param_1 = RBX::Graphics::TextureAtlas::vftable;
  *(undefined *)(param_1 + 10) = 0;
  uStack_8 = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = param_3;
  param_1[0x10] = param_4;
  *(undefined *)(param_1 + 0x11) = 0;
  uVar4 = FUN_00588320(0xb);
  param_1[0x12] = uVar4;
  param_1[0x13] = 0;
  param_1[0x14] = 0x3f800000;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0x7fff7fff;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1c] = 0xffffffff;
  param_1[0x1d] = 0;
  param_1[0x1b] = param_4 + -1;
  uStack_8._0_1_ = 3;
  param_1[0x1f] = param_5;
  uVar4 = FUN_01674e20(param_1[0xf] * param_5 * 2);
  param_1[0xc] = uVar4;
  uVar4 = FUN_0147c180(auStack_24,0,0,param_1[0xf],param_1[0x10],0xd);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_007735a0(uVar4,3);
  piVar1 = piStack_18;
  param_1[0xd] = uStack_1c;
  piVar2 = (int *)param_1[0xe];
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  param_1[0xe] = piVar1;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    piVar2 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_18[1] + -1;
      piStack_18[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar2 = piStack_20 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  FUN_00813c00();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 12459 ; VA 0x008131e0 ; FUN_008131e0 */

int * __thiscall FUN_008131e0(byte *param_1,int *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b5878;
  pvStack_10 = ExceptionList;
  uVar4 = param_2[1];
  iVar5 = *param_2;
  uVar8 = (uVar4 >> 2) + uVar4 * 0x40 + iVar5 ^ uVar4;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&param_2,uVar8,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (int *)0x0) {
    uStack_8 = 0;
    piVar3 = (int *)FUN_01674e20(0x28);
    *piVar3 = 0;
    piVar3[1] = 0;
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[6] = 0;
    piVar3[7] = 0;
    piVar3[8] = 0;
    piVar3[9] = 0;
    piVar3[2] = iVar5;
    piVar3[3] = uVar4;
    FUN_0060f290();
    uVar1 = *(uint *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar4 = FUN_005d6bb0(uVar4);
      if (uVar4 <= *(uint *)(param_1 + 4)) {
        uVar4 = *(uint *)(param_1 + 4);
      }
      FUN_00780ee0(uVar4);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar4) {
      param_2 = (int *)0x1;
      uVar6 = uVar1 >> 1;
      if (uVar1 + (uVar1 >> 1) <= uVar4) {
        uVar6 = 1;
      }
      iVar5 = FUN_005d6bb0(uVar6 + uVar1);
      if (iVar5 != *(int *)(param_1 + 4)) {
        FUN_00780ee0(iVar5);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar9;
        while (puVar2 != (undefined4 *)0x0) {
          piVar7 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar7 = (int)puVar9;
            puVar9 = puVar2;
          }
          else {
            *puVar9 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar7;
            *(undefined4 **)*piVar7 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar9;
        }
      }
    }
    piVar3[1] = uVar8;
    uVar8 = uVar8 % *(uint *)(param_1 + 4);
    piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (piVar7 == (int *)0x0) {
      piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar7 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar3;
      }
      *puVar9 = piVar7;
      *piVar3 = *piVar7;
    }
    else {
      *piVar3 = *piVar7;
      piVar7 = (int *)*puVar9;
    }
    *piVar7 = (int)piVar3;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar3 + 2;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 12460 ; VA 0x008133d0 ; FUN_008133d0 */

undefined4 * __thiscall FUN_008133d0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  
  *param_1 = RBX::Graphics::TextureAtlas::vftable;
  FUN_01674ea0(param_1[0xc]);
  iVar2 = param_1[0x18];
  if (iVar2 != 0) {
    uVar5 = param_1[0x1a] - iVar2 & 0xfffffff8;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[0x18] = 0;
    param_1[0x19] = 0;
    param_1[0x1a] = 0;
  }
  FUN_0072a0c0();
  piVar3 = (int *)param_1[0xe];
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_0147cba0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x80);
  }
  return param_1;
}



/* FUNCTION 12461 ; VA 0x00813490 ; FUN_00813490 */

uint __thiscall FUN_00813490(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  
  iVar3 = param_1 + 0x45 + (uint)*(byte *)(param_1 + 0x44);
  uVar2 = param_2[1];
  FUN_00606ff0(&param_2,(uVar2 >> 2) + uVar2 * 0x40 + *param_2 ^ uVar2,param_2,
               -(uint)(iVar3 != 0) & iVar3 + 1U);
  if (param_2 != (int *)0x0) {
    *param_3 = (int)(param_2 + 4);
    piVar1 = param_2 + 5;
    param_2 = (int *)(*(int *)(param_1 + 0x40) - *(int *)(param_1 + 0x7c));
    if (*(int *)(param_1 + 0x78) - *piVar1 <= (int)param_2) {
      return CONCAT31((int3)((uint)param_2 >> 8),1);
    }
  }
  return (uint)param_2 & 0xffffff00;
}



/* FUNCTION 12462 ; VA 0x00813510 ; FUN_00813510 */

uint __thiscall
FUN_00813510(int param_1,int *param_2,uint *param_3,int param_4,int param_5,int *param_6)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  ushort uVar6;
  uint *puVar7;
  uint uVar8;
  uint uVar9;
  undefined4 *puVar10;
  uint uVar11;
  uint **ppuVar12;
  uint *puVar13;
  uint *puVar14;
  int iVar15;
  int iVar16;
  undefined8 uStack_50;
  uint *puStack_48;
  int iStack_44;
  int iStack_40;
  uint *puStack_3c;
  uint *puStack_38;
  uint *puStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint *puStack_28;
  int iStack_24;
  uint uStack_20;
  uint *puStack_1c;
  uint *puStack_18;
  int iStack_14;
  
  iVar16 = param_1 + 0x45 + (uint)*(byte *)(param_1 + 0x44);
  uVar9 = param_2[1];
  iStack_14 = param_1;
  FUN_00606ff0(&iStack_44,(uVar9 >> 2) + uVar9 * 0x40 + *param_2 ^ uVar9,param_2,
               -(uint)(iVar16 != 0) & iVar16 + 1U);
  if (iStack_44 != 0) {
    *param_6 = iStack_44 + 0x10;
    iVar16 = *(int *)(param_1 + 0x40) - *(int *)(param_1 + 0x7c);
    if (*(int *)(param_1 + 0x78) - *(int *)(iStack_44 + 0x14) <= iVar16) goto LAB_00813bdc;
  }
  puStack_38 = (uint *)(param_1 + 0x60);
  uVar9 = *puStack_38;
  uStack_2c = 0xffffffff;
  uVar6 = *(short *)param_3 + 2;
  uStack_30 = 0;
  uStack_20 = (uint)uVar6;
  puStack_48 = (uint *)(uint)*(ushort *)((int)param_3 + 2);
  puVar13 = (uint *)((int)(*(int *)(param_1 + 100) - uVar9) >> 3);
  puVar7 = (uint *)0x1;
  puStack_18 = (uint *)0x0;
  puStack_1c = (uint *)0x0;
LAB_008135d8:
  do {
    if (((puVar13 == (uint *)0x0) &&
        (*(uint *)((int)puStack_1c + uVar9) < *(int *)(iStack_14 + 0x3c) - 1U)) ||
       (puVar13 <= puVar7)) break;
    uVar11 = 0;
    piVar1 = (int *)(uVar9 + (int)puStack_1c);
    puVar14 = puVar7;
    do {
      if ((int)(short)uVar6 <= *(int *)(uVar9 + (int)puVar14 * 8) - *piVar1) {
        uVar8 = *(int *)((int)puStack_1c + 4 + uVar9) + uVar11;
        if (uVar8 < uStack_2c) {
          puStack_18 = (uint *)((int)puVar7 - 1);
          puVar7 = (uint *)((int)puVar7 + 1);
          puStack_1c = (uint *)((int)puStack_1c + 8);
          uStack_30 = uVar11;
          uStack_2c = uVar8;
          goto LAB_008135d8;
        }
        break;
      }
      uVar8 = *(uint *)(uVar9 + 4 + (int)puVar14 * 8);
      uVar9 = *(uint *)(uVar9 + 4 + (int)puStack_1c);
      if ((uVar9 < uVar8) && (uVar8 = uVar8 - uVar9, uVar11 < uVar8)) {
        uVar11 = uVar8;
      }
      uVar9 = *puStack_38;
      puVar14 = (uint *)((int)puVar14 + 1);
    } while (puVar14 < puVar13);
    puVar7 = (uint *)((int)puVar7 + 1);
    puStack_1c = (uint *)((int)puStack_1c + 8);
  } while( true );
  puStack_3c = (uint *)((int)puStack_18 * 8);
  puStack_1c = *(uint **)((int)puStack_3c + uVar9);
  puStack_34 = (uint *)((int)puStack_3c + uVar9);
  uStack_2c = puStack_34[1] + uStack_30;
  uStack_50 = CONCAT44(uStack_50._4_4_,puStack_1c);
  iStack_40 = puStack_34[1] + uStack_30 + 1;
  iStack_44 = (int)puStack_1c + 1;
  iStack_24 = (short)*(ushort *)((int)param_3 + 2) + 2;
  if ((uint)(*(int *)(iStack_14 + 0x78) + *(int *)(iStack_14 + 0x7c) + -1) <
      puStack_34[1] + iStack_24 + uStack_30) {
    uVar9 = *param_3;
    *(uint *)(iStack_14 + 0x5c) = uVar9;
    return uVar9 & 0xffffff00;
  }
  puStack_28 = puStack_18;
  puVar7 = puStack_38;
  if (puStack_18 < puVar13) {
    puStack_48 = (uint *)((int)(short)uVar6 + (int)puStack_1c);
    puVar14 = puStack_34;
    do {
      puVar7 = (uint *)(iStack_14 + 0x60);
      if (puStack_48 <= (uint *)*puVar14) break;
      puStack_28 = (uint *)((int)puStack_28 + 1);
      puVar14 = puVar14 + 2;
    } while (puStack_28 < puVar13);
  }
  puStack_18 = (uint *)((int)puStack_18 + (2 - (int)puStack_28));
  if (0 < (int)puStack_18) {
    FUN_00812f20((int)puStack_18 + (int)puVar13,puVar7);
    iVar16 = (((int)(puVar7[1] - *puVar7) >> 3) - (int)puStack_18) + -1;
    if ((int)puStack_28 <= iVar16) {
      uStack_30 = ((int)puStack_18 + iVar16) * 8;
      do {
        uVar9 = *puVar7;
        iVar15 = iVar16 * 8;
        uVar2 = *(undefined4 *)(uVar9 + 4 + iVar16 * 8);
        iVar16 = iVar16 + -1;
        *(undefined4 *)(uStack_30 + uVar9) = *(undefined4 *)(uVar9 + iVar15);
        *(undefined4 *)(uStack_30 + 4 + uVar9) = uVar2;
        uStack_30 = uStack_30 - 8;
        puVar7 = puStack_38;
      } while ((int)puStack_28 <= iVar16);
    }
  }
  if ((int)puStack_18 < 0) {
    puStack_48 = (uint *)((int)puStack_18 + (int)puStack_28);
    if (puStack_48 < (uint *)(((int)(puVar7[1] - *puVar7) >> 3) + (int)puStack_18)) {
      puVar13 = puStack_48;
      puStack_28 = (uint *)((int)puStack_28 * 8);
      do {
        uVar9 = *puVar7;
        puVar14 = puStack_28 + 2;
        uVar2 = *(undefined4 *)((int)puStack_28 + uVar9 + 4);
        *(undefined4 *)(uVar9 + (int)puVar13 * 8) = *(undefined4 *)((int)puStack_28 + uVar9);
        *(undefined4 *)(uVar9 + 4 + (int)puVar13 * 8) = uVar2;
        puVar13 = (uint *)((int)puVar13 + 1);
        uVar9 = puVar7[1];
        uVar11 = *puVar7;
        puStack_28 = puVar14;
      } while (puVar13 < (uint *)(((int)(uVar9 - uVar11) >> 3) + (int)puStack_18));
    }
    else {
      uVar9 = puVar7[1];
      uVar11 = *puVar7;
    }
    FUN_00812f20(((int)(uVar9 - uVar11) >> 3) + (int)puStack_18,puVar7);
  }
  iVar16 = iStack_14;
  uStack_30 = iStack_24 + uStack_2c;
  uVar9 = *puVar7;
  *(uint **)(uVar9 + (int)puStack_3c) = puStack_1c;
  *(uint *)(uVar9 + 4 + (int)puStack_3c) = iStack_24 + uStack_2c;
  uVar9 = *puVar7;
  *(int *)(uVar9 + 8 + (int)puStack_3c) = (int)puStack_1c + (int)(short)uStack_20;
  *(uint *)(uVar9 + 0xc + (int)puStack_3c) = uStack_2c;
  uVar9 = *puVar7;
  iVar15 = (int)(puVar7[1] - uVar9) >> 3;
  if (*(int *)((uVar9 - 8) + iVar15 * 8) == *(int *)((uVar9 - 0x10) + iVar15 * 8)) {
    FUN_00812f20(iVar15 + -1,puVar7);
  }
  iVar15 = iStack_14;
  uStack_50 = CONCAT44(uStack_2c,(undefined4)uStack_50);
  puStack_18 = (uint *)(uStack_2c - *(int *)(iVar16 + 0x2c));
  puStack_3c = (uint *)((int)puStack_18 - 1);
  puStack_34 = puStack_1c;
  puStack_48 = (uint *)(*(int *)(iVar16 + 0x7c) * 2 + -1);
  ppuVar12 = &puStack_48;
  if ((int)puStack_3c < (int)puStack_48) {
    ppuVar12 = &puStack_3c;
  }
  puStack_38 = (uint *)(*(int *)(iVar16 + 0x3c) + -1);
  puVar7 = *ppuVar12;
  ppuVar12 = &puStack_38;
  if ((int)puStack_1c <= (int)puStack_38) {
    ppuVar12 = &puStack_34;
  }
  puVar13 = *ppuVar12;
  if ((int)puVar7 < 1) {
    puVar7 = (uint *)0x0;
  }
  if ((int)puVar13 < 1) {
    puVar13 = (uint *)0x0;
  }
  FUN_0170d1f0((int)puVar13 + (int)puVar7 * *(int *)(iVar16 + 0x3c) + *(int *)(iStack_14 + 0x30),0,
               (int)(short)uStack_20);
  puStack_34 = puStack_1c;
  puStack_3c = puStack_18;
  puStack_48 = (uint *)(*(int *)(iVar15 + 0x7c) * 2 + -1);
  ppuVar12 = &puStack_48;
  if ((int)puStack_18 < (int)puStack_48) {
    ppuVar12 = &puStack_3c;
  }
  iVar16 = *(int *)(iVar15 + 0x3c);
  puStack_38 = (uint *)(iVar16 + -1);
  puVar7 = *ppuVar12;
  ppuVar12 = &puStack_38;
  if ((int)puStack_1c <= (int)puStack_38) {
    ppuVar12 = &puStack_34;
  }
  puVar13 = *ppuVar12;
  if ((int)puVar7 < 1) {
    puVar7 = (uint *)0x0;
  }
  if ((int)puVar13 < 1) {
    puVar13 = (uint *)0x0;
  }
  FUN_0170d1f0((int)puVar13 + (int)puVar7 * iVar16 + *(int *)(iStack_14 + 0x30),0,
               (int)(short)uStack_20);
  puStack_34 = puStack_1c;
  puStack_3c = (uint *)((int)puStack_18 + iStack_24);
  puStack_48 = (uint *)(*(int *)(iStack_14 + 0x7c) * 2 + -1);
  ppuVar12 = &puStack_48;
  if ((int)puStack_18 + iStack_24 < (int)puStack_48) {
    ppuVar12 = &puStack_3c;
  }
  puStack_38 = (uint *)(*(int *)(iStack_14 + 0x3c) + -1);
  puVar7 = *ppuVar12;
  ppuVar12 = &puStack_38;
  if ((int)puStack_1c <= (int)puStack_38) {
    ppuVar12 = &puStack_34;
  }
  puVar13 = *ppuVar12;
  if ((int)puVar7 < 1) {
    puVar7 = (uint *)0x0;
  }
  if ((int)puVar13 < 1) {
    puVar13 = (uint *)0x0;
  }
  FUN_0170d1f0((int)puVar13 + (int)puVar7 * *(int *)(iStack_14 + 0x3c) + *(int *)(iStack_14 + 0x30),
               0,(int)(short)uStack_20);
  iVar16 = iStack_14;
  puStack_34 = puStack_1c;
  puStack_3c = (uint *)((int)puStack_3c + -1);
  puStack_48 = (uint *)(*(int *)(iStack_14 + 0x7c) * 2 + -1);
  ppuVar12 = &puStack_48;
  if ((int)puStack_3c < (int)puStack_48) {
    ppuVar12 = &puStack_3c;
  }
  puStack_38 = (uint *)(*(int *)(iStack_14 + 0x3c) + -1);
  puVar7 = *ppuVar12;
  ppuVar12 = &puStack_38;
  if ((int)puStack_1c <= (int)puStack_38) {
    ppuVar12 = &puStack_34;
  }
  puVar13 = *ppuVar12;
  if ((int)puVar7 < 1) {
    puVar7 = (uint *)0x0;
  }
  if ((int)puVar13 < 1) {
    puVar13 = (uint *)0x0;
  }
  FUN_0170d1f0((int)puVar13 + (int)puVar7 * *(int *)(iStack_14 + 0x3c) + *(int *)(iStack_14 + 0x30),
               0,(int)(short)uStack_20);
  if (0 < iStack_24) {
    uStack_50 = CONCAT44(puStack_1c,(undefined4)uStack_50);
    puStack_34 = (uint *)((int)puStack_1c + -1);
    puStack_38 = (uint *)((int)puStack_1c + (int)(short)uStack_20);
    puStack_3c = (uint *)((int)puStack_34 + (int)(short)uStack_20);
    puVar7 = puStack_34;
    do {
      puStack_48 = puVar7;
      puVar7 = (uint *)(*(int *)(iVar16 + 0x7c) * 2 - 1);
      puStack_28 = (uint *)(*(int *)(iVar16 + 0x3c) + -1);
      ppuVar12 = &puStack_48;
      if ((int)puStack_28 < (int)puStack_34) {
        ppuVar12 = &puStack_28;
      }
      puVar13 = puStack_18;
      if ((int)puVar7 <= (int)puStack_18) {
        puVar13 = puVar7;
      }
      puVar7 = (uint *)0x0;
      if (0 < (int)puVar13) {
        puVar7 = puVar13;
      }
      puVar13 = *ppuVar12;
      if ((int)puVar13 < 1) {
        puVar13 = (uint *)0x0;
      }
      *(undefined *)
       ((int)puVar13 + (int)puVar7 * *(int *)(iVar16 + 0x3c) + *(int *)(iStack_14 + 0x30)) = 0;
      puStack_28 = puStack_18;
      puStack_48 = (uint *)(*(int *)(iStack_14 + 0x7c) * 2 + -1);
      ppuVar12 = &puStack_48;
      if ((int)puStack_18 < (int)puStack_48) {
        ppuVar12 = &puStack_28;
      }
      uStack_20 = *(int *)(iStack_14 + 0x3c) - 1;
      puVar7 = &uStack_20;
      if ((int)puStack_1c <= (int)uStack_20) {
        puVar7 = (uint *)((int)&uStack_50 + 4);
      }
      puVar13 = (uint *)0x0;
      if (0 < (int)*ppuVar12) {
        puVar13 = *ppuVar12;
      }
      uVar9 = *puVar7;
      if ((int)uVar9 < 1) {
        uVar9 = 0;
      }
      *(undefined *)(*(int *)(iStack_14 + 0x3c) * (int)puVar13 + uVar9 + *(int *)(iStack_14 + 0x30))
           = 0;
      puVar7 = (uint *)(*(int *)(iStack_14 + 0x7c) * 2 - 1);
      puStack_48 = (uint *)(*(int *)(iStack_14 + 0x3c) + -1);
      ppuVar12 = &puStack_3c;
      if ((int)puStack_48 < (int)puStack_3c) {
        ppuVar12 = &puStack_48;
      }
      puVar13 = puStack_18;
      if ((int)puVar7 <= (int)puStack_18) {
        puVar13 = puVar7;
      }
      puVar7 = (uint *)0x0;
      if (0 < (int)puVar13) {
        puVar7 = puVar13;
      }
      puVar13 = *ppuVar12;
      if ((int)puVar13 < 1) {
        puVar13 = (uint *)0x0;
      }
      *(undefined *)
       ((int)puVar13 + *(int *)(iStack_14 + 0x3c) * (int)puVar7 + *(int *)(iStack_14 + 0x30)) = 0;
      puVar7 = (uint *)(*(int *)(iStack_14 + 0x7c) * 2 - 1);
      puStack_48 = (uint *)(*(int *)(iStack_14 + 0x3c) + -1);
      ppuVar12 = &puStack_38;
      if ((int)puStack_48 < (int)puStack_38) {
        ppuVar12 = &puStack_48;
      }
      puVar13 = puStack_18;
      if ((int)puVar7 <= (int)puStack_18) {
        puVar13 = puVar7;
      }
      puVar7 = (uint *)0x0;
      if (0 < (int)puVar13) {
        puVar7 = puVar13;
      }
      puVar13 = *ppuVar12;
      if ((int)puVar13 < 1) {
        puVar13 = (uint *)0x0;
      }
      puStack_18 = (uint *)((int)puStack_18 + 1);
      iStack_24 = iStack_24 + -1;
      *(undefined *)
       ((int)puVar13 + (int)puVar7 * *(int *)(iStack_14 + 0x3c) + *(int *)(iStack_14 + 0x30)) = 0;
      puVar7 = puStack_34;
      iVar16 = iStack_14;
    } while (iStack_24 != 0);
  }
  iVar15 = 0;
  if (0 < *(short *)((int)param_3 + 2)) {
    do {
      FUN_0170c6f0(((iVar15 - *(int *)(iVar16 + 0x2c)) + iStack_40) * *(int *)(iVar16 + 0x3c) +
                   *(int *)(iVar16 + 0x30) + iStack_44,param_5,(int)*(short *)param_3);
      iVar15 = iVar15 + 1;
      param_5 = param_5 + param_4;
    } while (iVar15 < *(short *)((int)param_3 + 2));
  }
  uVar9 = *(uint *)(iVar16 + 0x70);
  if (uStack_2c < *(uint *)(iVar16 + 0x70)) {
    uVar9 = uStack_2c;
  }
  *(uint *)(iVar16 + 0x70) = uVar9;
  uVar9 = uStack_30 + 1;
  if (uStack_30 + 1 <= *(uint *)(iVar16 + 0x74)) {
    uVar9 = *(uint *)(iVar16 + 0x74);
  }
  *(uint *)(iVar16 + 0x74) = uVar9;
  puVar10 = (undefined4 *)
            FUN_0147ce60(iStack_44,iStack_40,(int)*(short *)param_3,
                         (int)*(short *)((int)param_3 + 2));
  uVar2 = *puVar10;
  uVar3 = puVar10[1];
  uVar4 = puVar10[2];
  uVar5 = puVar10[3];
  uStack_50 = *(undefined8 *)(puVar10 + 4);
  iVar16 = FUN_008131e0(param_2);
  *(undefined4 *)(iVar16 + 8) = uVar2;
  *(undefined4 *)(iVar16 + 0xc) = uVar3;
  *(undefined4 *)(iVar16 + 0x10) = uVar4;
  *(undefined4 *)(iVar16 + 0x14) = uVar5;
  *(undefined8 *)(iVar16 + 0x18) = uStack_50;
  iVar16 = FUN_008131e0(param_2);
  iVar16 = iVar16 + 8;
  *param_6 = iVar16;
LAB_00813bdc:
  return CONCAT31((int3)((uint)iVar16 >> 8),1);
}



/* FUNCTION 12463 ; VA 0x00813bf0 ; thunk_FUN_00813c00 */

void __fastcall thunk_FUN_00813c00(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  int aiStack_c [2];
  
  aiStack_c[1] = 0;
  aiStack_c[0] = 0;
  puVar1 = *(undefined4 **)(param_1 + 0x60);
  *(undefined4 **)(param_1 + 100) = puVar1;
  if (*(undefined4 **)(param_1 + 0x68) == puVar1) {
    FUN_007be720(puVar1,aiStack_c);
  }
  else {
    *puVar1 = 0;
    puVar1[1] = 0;
    *(int *)(param_1 + 100) = *(int *)(param_1 + 100) + 8;
  }
  piVar2 = *(int **)(param_1 + 100);
  aiStack_c[0] = *(int *)(param_1 + 0x3c) + -1;
  aiStack_c[1] = 0;
  if (*(int **)(param_1 + 0x68) == piVar2) {
    FUN_007be720(piVar2,aiStack_c);
  }
  else {
    *piVar2 = aiStack_c[0];
    piVar2[1] = 0;
    *(int *)(param_1 + 100) = *(int *)(param_1 + 100) + 8;
  }
  if (*(int *)(param_1 + 0x4c) != 0) {
    puVar1 = (undefined4 *)(*(int *)(param_1 + 0x58) + *(int *)(param_1 + 0x48) * 4);
    puVar3 = (undefined4 *)*puVar1;
    do {
      *puVar1 = *puVar3;
      FUN_01674ea0(puVar3,0x28);
      *(int *)(param_1 + 0x4c) = *(int *)(param_1 + 0x4c) + -1;
      puVar3 = (undefined4 *)*puVar1;
    } while (puVar3 != (undefined4 *)0x0);
    puVar3 = *(undefined4 **)(param_1 + 0x58);
    puVar1 = puVar3 + *(int *)(param_1 + 0x48);
    for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
      *puVar3 = 0;
    }
  }
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x78) = 0;
  *(undefined *)(param_1 + 0x28) = 1;
  return;
}



/* FUNCTION 12464 ; VA 0x00813c00 ; FUN_00813c00 */

void __fastcall FUN_00813c00(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  int aiStack_c [2];
  
  aiStack_c[1] = 0;
  aiStack_c[0] = 0;
  puVar1 = *(undefined4 **)(param_1 + 0x60);
  *(undefined4 **)(param_1 + 100) = puVar1;
  if (*(undefined4 **)(param_1 + 0x68) == puVar1) {
    FUN_007be720(puVar1,aiStack_c);
  }
  else {
    *puVar1 = 0;
    puVar1[1] = 0;
    *(int *)(param_1 + 100) = *(int *)(param_1 + 100) + 8;
  }
  piVar2 = *(int **)(param_1 + 100);
  aiStack_c[0] = *(int *)(param_1 + 0x3c) + -1;
  aiStack_c[1] = 0;
  if (*(int **)(param_1 + 0x68) == piVar2) {
    FUN_007be720(piVar2,aiStack_c);
  }
  else {
    *piVar2 = aiStack_c[0];
    piVar2[1] = 0;
    *(int *)(param_1 + 100) = *(int *)(param_1 + 100) + 8;
  }
  if (*(int *)(param_1 + 0x4c) != 0) {
    puVar1 = (undefined4 *)(*(int *)(param_1 + 0x58) + *(int *)(param_1 + 0x48) * 4);
    puVar3 = (undefined4 *)*puVar1;
    do {
      *puVar1 = *puVar3;
      FUN_01674ea0(puVar3,0x28);
      *(int *)(param_1 + 0x4c) = *(int *)(param_1 + 0x4c) + -1;
      puVar3 = (undefined4 *)*puVar1;
    } while (puVar3 != (undefined4 *)0x0);
    puVar3 = *(undefined4 **)(param_1 + 0x58);
    puVar1 = puVar3 + *(int *)(param_1 + 0x48);
    for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
      *puVar3 = 0;
    }
  }
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x78) = 0;
  *(undefined *)(param_1 + 0x28) = 1;
  return;
}



/* FUNCTION 12465 ; VA 0x00813cd0 ; FUN_00813cd0 */

void __fastcall FUN_00813cd0(int param_1)

{
  undefined4 uVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  int iVar8;
  uint uVar9;
  int iVar10;
  int iVar11;
  uint uVar12;
  int iVar13;
  uint uVar14;
  uint uVar15;
  undefined8 uVar16;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b58a4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb38f0) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb38f0), DAT_01eb38f0 == -1)) {
    uStack_8 = 0;
    uVar16 = FUN_0152dab0("Render","TextureAtlas::upload",0xffffffff);
    DAT_01eb38ec = (undefined4)((ulonglong)uVar16 >> 0x20);
    DAT_01eb38e8 = (undefined4)uVar16;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb38f0);
  }
  uVar4 = DAT_01eb38ec;
  uVar3 = DAT_01eb38e8;
  uVar16 = FUN_0152d930(DAT_01eb38e8,DAT_01eb38ec);
  uStack_8 = 1;
  if (*(char *)(param_1 + 0x28) != '\0') {
    uVar5 = FUN_01674e20(*(undefined4 *)(param_1 + 0x3c));
    FUN_0170d1f0(uVar5,0,*(undefined4 *)(param_1 + 0x3c));
    puVar6 = (undefined4 *)&DAT_01eb1b04;
    if (*(undefined4 **)(param_1 + 0x34) != (undefined4 *)0x0) {
      puVar6 = *(undefined4 **)(param_1 + 0x34);
    }
    uVar1 = *(undefined4 *)(param_1 + 0x3c);
    pcVar2 = *(code **)(*(int *)*puVar6 + 0x10);
    uVar7 = FUN_0147ce60(0,*(int *)(param_1 + 0x40) + -1,uVar1,1);
    (*pcVar2)(0,0,uVar7,uVar5,uVar1);
    FUN_01674ea0(uVar5);
    *(undefined *)(param_1 + 0x28) = 0;
  }
  uVar14 = 0xffffffff;
  uVar12 = *(uint *)(*(int *)(param_1 + 0x60) + 4);
  *(uint *)(param_1 + 0x78) = uVar12;
  iVar8 = *(int *)(param_1 + 0x60);
  iVar10 = *(int *)(param_1 + 100);
  if (iVar8 != iVar10) {
    uVar9 = 0xffffffff;
    uVar15 = uVar12;
    do {
      uVar12 = *(uint *)(iVar8 + 4);
      if (*(uint *)(iVar8 + 4) <= uVar15) {
        uVar12 = uVar15;
      }
      *(uint *)(param_1 + 0x78) = uVar12;
      uVar14 = *(uint *)(iVar8 + 4);
      if (uVar9 <= *(uint *)(iVar8 + 4)) {
        uVar14 = uVar9;
      }
      iVar10 = *(int *)(param_1 + 100);
      iVar8 = iVar8 + 8;
      uVar9 = uVar14;
      uVar15 = uVar12;
    } while (iVar8 != iVar10);
    iVar8 = *(int *)(param_1 + 0x60);
  }
  uVar12 = uVar12 - *(int *)(param_1 + 0x7c);
  if ((int)uVar14 <= (int)uVar12) {
    uVar14 = uVar12;
  }
  if (iVar8 != iVar10) {
    do {
      uVar12 = uVar14;
      if (uVar14 <= *(uint *)(iVar8 + 4)) {
        uVar12 = *(uint *)(iVar8 + 4);
      }
      *(uint *)(iVar8 + 4) = uVar12;
      iVar8 = iVar8 + 8;
      iVar10 = *(int *)(param_1 + 100);
    } while (iVar8 != iVar10);
  }
  *(uint *)(*(int *)(param_1 + 0x60) + -4 + (iVar10 - *(int *)(param_1 + 0x60) >> 3) * 8) = uVar14;
  uVar12 = *(uint *)(param_1 + 0x70);
  if (uVar12 < *(uint *)(param_1 + 0x74)) {
    uVar9 = *(uint *)(param_1 + 0x6c) & *(uint *)(param_1 + 0x74);
    uVar15 = *(uint *)(param_1 + 0x6c) & uVar12;
    iVar8 = *(int *)(param_1 + 0x3c);
    iVar11 = (uVar12 - *(int *)(param_1 + 0x2c)) * iVar8;
    iVar10 = *(int *)(param_1 + 0x30);
    uVar12 = uVar9;
    if (uVar9 <= uVar15) {
      uVar12 = *(uint *)(param_1 + 0x40);
    }
    iVar13 = uVar12 - uVar15;
    puVar6 = (undefined4 *)&DAT_01eb1b04;
    if (*(undefined4 **)(param_1 + 0x34) != (undefined4 *)0x0) {
      puVar6 = *(undefined4 **)(param_1 + 0x34);
    }
    pcVar2 = *(code **)(*(int *)*puVar6 + 0x10);
    uVar5 = FUN_0147ce60(0,uVar15,iVar8,iVar13);
    (*pcVar2)(0,0,uVar5,iVar10 + iVar11,iVar8 * iVar13);
    if ((uVar9 < uVar15) && (uVar9 != 0)) {
      iVar8 = *(int *)(param_1 + 0x3c);
      iVar10 = *(int *)(param_1 + 0x30);
      puVar6 = (undefined4 *)&DAT_01eb1b04;
      if (*(undefined4 **)(param_1 + 0x34) != (undefined4 *)0x0) {
        puVar6 = *(undefined4 **)(param_1 + 0x34);
      }
      pcVar2 = *(code **)(*(int *)*puVar6 + 0x10);
      uVar5 = FUN_0147ce60(0,0,iVar8,uVar9);
      (*pcVar2)(0,0,uVar5,iVar11 + iVar8 * iVar13 + iVar10,iVar8 * uVar9);
    }
  }
  if (uVar14 != *(uint *)(param_1 + 0x2c)) {
    iVar8 = uVar14 - *(uint *)(param_1 + 0x2c);
    FUN_0170cc70(*(int *)(param_1 + 0x30),
                 *(int *)(param_1 + 0x30) + *(int *)(param_1 + 0x3c) * iVar8,
                 ((*(int *)(param_1 + 0x7c) * 2 - iVar8) + -1) * *(int *)(param_1 + 0x3c));
    *(uint *)(param_1 + 0x2c) = uVar14;
  }
  *(undefined4 *)(param_1 + 0x70) = 0xffffffff;
  *(undefined4 *)(param_1 + 0x74) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0x7fff7fff;
  puVar6 = (undefined4 *)&DAT_01eb1b04;
  if (*(undefined4 **)(param_1 + 0x34) != (undefined4 *)0x0) {
    puVar6 = *(undefined4 **)(param_1 + 0x34);
  }
  (**(code **)(*(int *)*puVar6 + 0x2c))();
  if (~*(uint *)(param_1 + 0x7c) <= *(uint *)(param_1 + 0x78)) {
    FUN_00813c00();
  }
  uStack_8 = 2;
  FUN_0152dda0(uVar3,uVar4,uVar16);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12466 ; VA 0x00813ff0 ; FUN_00813ff0 */

undefined FUN_00813ff0(int *param_1,uint param_2,undefined4 param_3,uint param_4,undefined4 param_5,
                      char param_6)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  uint3 uVar4;
  char *pcVar5;
  undefined8 uVar6;
  undefined uStack0000001b;
  undefined auStack_d0 [16];
  undefined4 uStack_c0;
  uint uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 *puStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  undefined4 uStack_20;
  uint auStack_1c [3];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b58d4;
  pvStack_10 = ExceptionList;
  uVar2 = *(undefined4 *)(param_2 + 0x30);
  uStack_28 = *(undefined4 *)(param_2 + 0x34);
  ExceptionList = &pvStack_10;
  FUN_00829a50(uVar2,uStack_28);
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb3988) {
    FUN_016f3809(&DAT_01eb3988);
    if (DAT_01eb3988 == -1) {
      uStack_8 = 0;
      uVar6 = FUN_0152dab0(&DAT_018fb928,"Bokeh Blur",0xffffffff);
      DAT_01eb3984 = (undefined4)((ulonglong)uVar6 >> 0x20);
      DAT_01eb3980 = (undefined4)uVar6;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eb3988);
    }
  }
  uStack_38 = DAT_01eb3980;
  uStack_50 = DAT_01eb3980;
  uStack_34 = DAT_01eb3984;
  uStack_4c = DAT_01eb3984;
  uStack_48 = FUN_0152d930(DAT_01eb3980,DAT_01eb3984);
  auStack_1c[0] = param_4;
  uStack_20 = 0;
  auStack_1c[1] = 0;
  auStack_1c[2] = 0;
  uStack_8 = 1;
  uStack_c0 = 0;
  uStack_bc = param_4;
  uStack_b8 = 0;
  uStack_b4 = 0;
  FUN_00799920(&puStack_40,uVar2,uStack_28,8);
  uStack_8._0_1_ = 2;
  FUN_00799920(&puStack_30,uVar2,uStack_28,8);
  piVar1 = param_1;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if ((puStack_40 == (undefined4 *)0x0) || (puStack_30 == (undefined4 *)0x0)) {
    uStack0000001b = 0;
  }
  else {
    param_4 = (uint)(DAT_01d61fac == '\0');
    iVar3 = **(int **)(iStack_24 + 0x40);
    iStack_24 = iVar3;
    (**(code **)(*param_1 + 0x14))(puStack_40[2],param_4,1,0,0);
    auStack_1c[0]._0_2_ = 0x100;
    auStack_1c[1] = 0;
    auStack_1c[2] = auStack_1c[2] & 0xffff0000;
    (**(code **)(*piVar1 + 0x34))(0,param_2,auStack_1c);
    uVar2 = param_5;
    auStack_1c[0] = CONCAT22(auStack_1c[0]._2_2_,0x100);
    auStack_1c[1] = 0;
    auStack_1c[2] = auStack_1c[2] & 0xffff0000;
    (**(code **)(*piVar1 + 0x34))(1,param_5,auStack_1c);
    piVar1 = param_1;
    param_2._0_3_ = (uint3)param_2 & 0xff;
    param_2 = (uint)(uint3)param_2;
    auStack_1c[1] = 0x1000100;
    auStack_1c[0] = 0xf;
    auStack_1c[2] = auStack_1c[2] & 0xffffff00;
    FUN_0082a430(param_1,iVar3,"PassThroughVS","FixUpCoCFS",auStack_d0,auStack_1c,(int)&param_2 + 1)
    ;
    (**(code **)(*piVar1 + 0x18))();
    (**(code **)(*piVar1 + 0x14))(puStack_30[2],param_4,1,0,0);
    auStack_1c[0]._0_2_ = 0x101;
    auStack_1c[1] = 0;
    auStack_1c[2] = auStack_1c[2] & 0xffff0000;
    (**(code **)(*param_1 + 0x34))(0,*puStack_40,auStack_1c);
    auStack_1c[0] = CONCAT22(auStack_1c[0]._2_2_,0x101);
    auStack_1c[1] = 0;
    auStack_1c[2] = auStack_1c[2] & 0xffff0000;
    (**(code **)(*param_1 + 0x34))(1,uVar2,auStack_1c);
    iVar3 = iStack_24;
    param_2._0_3_ = (uint3)param_2 & 0xff;
    param_2 = (uint)(uint3)param_2;
    pcVar5 = "BokehNearCoCFS";
    auStack_1c[1] = 0x1000100;
    if (param_6 == '\0') {
      pcVar5 = "BokehFarCoCFS";
    }
    auStack_1c[0] = 0xf;
    auStack_1c[2] = auStack_1c[2] & 0xffffff00;
    FUN_0082a430(param_1,iStack_24,"PassThroughVS",pcVar5,auStack_d0,auStack_1c,(int)&param_2 + 1);
    (**(code **)(*param_1 + 0x18))();
    piVar1 = param_1;
    (**(code **)(*param_1 + 0x14))(param_3,param_4,1,0,0);
    auStack_1c[0] = CONCAT22(auStack_1c[0]._2_2_,0x101);
    auStack_1c[1] = 0;
    auStack_1c[2] = auStack_1c[2] & 0xffff0000;
    (**(code **)(*piVar1 + 0x34))(0,*puStack_30,auStack_1c);
    uVar4 = (uint3)param_1;
    param_1 = (int *)(uint)(uVar4 & 0xff);
    auStack_1c[1] = 0x1000100;
    auStack_1c[0] = 0xf;
    auStack_1c[2] = auStack_1c[2] & 0xffffff00;
    FUN_0082a430(piVar1,iVar3,"PassThroughVS","TentFilterFS",auStack_d0,auStack_1c,(int)&param_1 + 1
                );
    (**(code **)(*piVar1 + 0x18))();
    uStack0000001b = 1;
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar3 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piStack_3c + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
  }
  uStack_8 = 5;
  FUN_0152dda0(uStack_38,uStack_34,uStack_48);
  ExceptionList = pvStack_10;
  return uStack0000001b;
}



/* FUNCTION 12467 ; VA 0x008143d0 ; FUN_008143d0 */

undefined __thiscall
FUN_008143d0(int param_1,int *param_2,int param_3,undefined4 param_4,undefined4 param_5,int param_6,
            undefined4 param_7)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined uVar6;
  uint uVar7;
  char *pcVar8;
  uint uVar9;
  undefined8 uVar10;
  undefined auStack_154 [16];
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined auStack_d4 [128];
  int iStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  int *piStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 uStack_38;
  uint uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b5910;
  pvStack_10 = ExceptionList;
  uStack_2c = *(undefined4 *)(param_3 + 0x34);
  uVar2 = *(uint *)(param_3 + 0x30);
  if (param_6 == 1) {
    uVar7 = (uVar2 & 1) + uVar2 >> 1;
    uVar9 = 1;
    if (uVar7 != 0) {
      uVar9 = uVar7;
    }
  }
  else {
    uVar9 = (uVar2 & 1) + uVar2 >> 2;
    if (uVar9 == 0) {
      uVar9 = 1;
    }
  }
  uStack_24 = **(undefined4 **)(param_1 + 0x40);
  ExceptionList = &pvStack_10;
  iStack_28 = param_1;
  FUN_00799920(&puStack_48,uVar9,uStack_2c,8);
  iStack_8 = 0;
  if (puStack_48 == (undefined4 *)0x0) {
    param_7._3_1_ = 0;
  }
  else {
    uStack_30 = (uint)(DAT_01d61fac == '\0');
    FUN_00829b90(uVar2,uStack_2c,iStack_28);
    iStack_54 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    if ((*(int *)(iStack_54 + 0x34) < DAT_01eb3908) &&
       (FUN_016f3809(&DAT_01eb3908), DAT_01eb3908 == -1)) {
      iStack_8._0_1_ = 1;
      uVar10 = FUN_0152dab0(&DAT_018fb928,"Downsample & mask 1/4th or 1/2 width",0xffffffff);
      DAT_01eb3904 = (undefined4)((ulonglong)uVar10 >> 0x20);
      DAT_01eb3900 = (undefined4)uVar10;
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_016f37bf(&DAT_01eb3908);
    }
    uStack_50 = DAT_01eb3900;
    uStack_40 = DAT_01eb3900;
    uStack_4c = DAT_01eb3904;
    uStack_3c = DAT_01eb3904;
    uStack_38 = FUN_0152d930(DAT_01eb3900,DAT_01eb3904);
    iStack_8._0_1_ = 2;
    (**(code **)(*param_2 + 0x14))(puStack_48[2],uStack_30,1,0,0);
    (**(code **)(*param_2 + 0x30))(0,*(int *)(iStack_28 + 0x40) + 0x54,0x350);
    uStack_1c._0_2_ = 0x100;
    uStack_18 = 0;
    uStack_14._0_2_ = 0;
    (**(code **)(*param_2 + 0x34))(0,param_3,&uStack_1c);
    uStack_1c = CONCAT22(uStack_1c._2_2_,0x101);
    uStack_18 = 0;
    uStack_14 = (uint)uStack_14._2_2_ << 0x10;
    (**(code **)(*param_2 + 0x34))(1,param_4,&uStack_1c);
    param_7._1_2_ = 0;
    param_7._3_1_ = 0;
    uStack_18 = 0x1000100;
    uStack_1c = 0xf;
    uStack_14 = uStack_14 & 0xffffff00;
    if ((char)param_7 == '\0') {
      pcVar8 = "DOFDownSampleAndMaskFarFieldColorHorizontal2xFS";
    }
    else {
      pcVar8 = "DOFDownSampleAndMaskNearFieldColorHorizontal2xFS";
      if (param_6 != 1) {
        pcVar8 = "DOFDownSampleAndMaskNearFieldColorHorizontal4xFS";
      }
    }
    FUN_0082a430(param_2,uStack_24,"PassThroughVS",pcVar8,auStack_d4,&uStack_1c,(int)&param_7 + 1);
    (**(code **)(*param_2 + 0x18))();
    iStack_8._0_1_ = 3;
    FUN_0152dda0(uStack_50,uStack_4c,uStack_38);
    iStack_8._0_1_ = 0;
    uVar6 = (undefined)iStack_8;
    iStack_8._0_1_ = 0;
    if (*(int *)(iStack_54 + 0x34) < DAT_01eb3918) {
      iStack_8._0_1_ = uVar6;
      FUN_016f3809(&DAT_01eb3918);
      if (DAT_01eb3918 == -1) {
        iStack_8._0_1_ = 4;
        uVar10 = FUN_0152dab0(&DAT_018fb928,"Downsample & mask 1/4th or 1/2 ",0xffffffff);
        DAT_01eb3914 = (undefined4)((ulonglong)uVar10 >> 0x20);
        DAT_01eb3910 = (undefined4)uVar10;
        iStack_8._0_1_ = 0;
        FUN_016f37bf(&DAT_01eb3918);
      }
    }
    uVar5 = DAT_01eb3914;
    uVar4 = DAT_01eb3910;
    uStack_40 = DAT_01eb3910;
    uStack_3c = DAT_01eb3914;
    uVar10 = FUN_0152d930(DAT_01eb3910,DAT_01eb3914);
    iStack_8._0_1_ = 5;
    uStack_38 = uVar10;
    FUN_00829a50(uVar9,uStack_2c);
    uStack_140 = DAT_018ce2f8;
    if (param_6 == 1) {
      uStack_140 = DAT_018ce2f4;
    }
    uStack_20 = 0;
    uStack_18 = 0;
    uStack_14 = 0;
    uStack_144 = 0;
    uStack_13c = 0;
    uStack_138 = 0;
    uStack_1c = uStack_140;
    (**(code **)(*param_2 + 0x14))(param_5,uStack_30,1,0,0);
    uStack_1c = CONCAT22(uStack_1c._2_2_,0x101);
    uStack_18 = 0;
    uStack_14 = uStack_14 & 0xffff0000;
    (**(code **)(*param_2 + 0x34))(0,*puStack_48,&uStack_1c);
    param_7._1_2_ = 0;
    param_7._3_1_ = 0;
    uStack_18 = 0x1000100;
    uStack_1c = 0xf;
    uStack_14 = uStack_14 & 0xffffff00;
    FUN_0082a430(param_2,uStack_24,"PassThroughVS","DOFDownSampleColor2xFS",auStack_154,&uStack_1c,
                 (int)&param_7 + 1);
    (**(code **)(*param_2 + 0x18))();
    iStack_8 = CONCAT31(iStack_8._1_3_,6);
    FUN_0152dda0(uVar4,uVar5,uStack_38);
    param_7._3_1_ = 1;
  }
  if (piStack_44 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_44[1] + -1;
    piStack_44[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_44)();
      LOCK();
      piVar1 = piStack_44 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_44 + 4))();
      }
      ExceptionList = pvStack_10;
      return param_7._3_1_;
    }
  }
  ExceptionList = pvStack_10;
  return param_7._3_1_;
}



/* FUNCTION 12468 ; VA 0x008147f0 ; FUN_008147f0 */

undefined __thiscall
FUN_008147f0(int param_1,int *param_2,uint param_3,int param_4,undefined4 param_5)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  char *pcVar5;
  int iVar6;
  undefined uVar7;
  undefined8 uVar8;
  undefined auStack_168 [12];
  undefined4 uStack_15c;
  undefined4 uStack_158;
  undefined auStack_e8 [8];
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_68;
  undefined4 *puStack_64;
  int *piStack_60;
  undefined4 uStack_5c;
  undefined4 *puStack_58;
  int *piStack_54;
  uint uStack_50;
  undefined4 *puStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  uint uStack_40;
  int iStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  ushort uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b59b0;
  pvStack_10 = ExceptionList;
  iStack_20 = *(int *)(param_3 + 0x30);
  uVar2 = *(undefined4 *)(param_3 + 0x34);
  uVar3 = *(undefined4 *)(param_4 + 0x28);
  uStack_24 = *(undefined4 *)(param_4 + 0x2c);
  uStack_28 = **(undefined4 **)(param_1 + 0x40);
  uStack_5c = (*(undefined4 **)(param_1 + 0x40))[0x10c];
  ExceptionList = &pvStack_10;
  uStack_68 = uVar2;
  uStack_44 = uVar3;
  iStack_3c = param_1;
  FUN_00799920(&puStack_64,uVar3,uVar2,6);
  uStack_8 = 0;
  FUN_00799920(&puStack_58,uVar3,uStack_24,6);
  uStack_8._0_1_ = 1;
  if ((puStack_58 == (undefined4 *)0x0) || (puStack_64 == (undefined4 *)0x0)) {
    uVar7 = 0;
  }
  else {
    uStack_40 = (uint)(DAT_01d61fac == '\0');
    FUN_00829b90(iStack_20,uVar2,param_1);
    iStack_20 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    if ((*(int *)(iStack_20 + 0x34) < DAT_01eb3928) &&
       (FUN_016f3809(&DAT_01eb3928), DAT_01eb3928 == -1)) {
      uStack_8._0_1_ = 2;
      uVar8 = FUN_0152dab0(&DAT_018fb928,"Extract Alpha and spread width wise",0xffffffff);
      DAT_01eb3924 = (undefined4)((ulonglong)uVar8 >> 0x20);
      DAT_01eb3920 = (undefined4)uVar8;
      uStack_8._0_1_ = 1;
      FUN_016f37bf(&DAT_01eb3928);
    }
    uStack_48 = DAT_01eb3920;
    uStack_38 = DAT_01eb3920;
    uStack_50 = DAT_01eb3924;
    uStack_34 = DAT_01eb3924;
    uStack_30 = FUN_0152d930(DAT_01eb3920,DAT_01eb3924);
    uVar4 = uStack_40;
    uStack_15c = 0;
    uStack_158 = 0x3f800000;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    (**(code **)(*param_2 + 0x14))(puStack_64[2],uStack_40,1,0,0);
    uStack_1c = CONCAT22(uStack_1c._2_2_,0x100);
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*param_2 + 0x34))(0,param_3,&uStack_1c);
    if ((char)param_5 == '\0') {
      (**(code **)(*param_2 + 0x30))(0,*(int *)(iStack_3c + 0x40) + 0x54,0x350);
    }
    param_3._0_3_ = (uint3)param_3 & 0xff;
    param_3 = (uint)(uint3)param_3;
    uStack_18 = 0x1000100;
    pcVar5 = "DOFDownSampleCoCExtractAlphaMax4xFS";
    uStack_1c = 0xf;
    if ((char)param_5 == '\0') {
      pcVar5 = "DOFDownSampleAndComputeFarCoCHorizontal4xFS";
    }
    uStack_14 = uStack_14 & 0xff00;
    FUN_0082a430(param_2,uStack_28,"PassThroughVS",pcVar5,auStack_168,&uStack_1c,(int)&param_3 + 1);
    (**(code **)(*param_2 + 0x18))();
    uStack_8._0_1_ = 4;
    FUN_0152dda0(uStack_48,uStack_50,uStack_30);
    uStack_8._0_1_ = 1;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (*(int *)(iStack_20 + 0x34) < DAT_01eb3938) {
      uStack_8._0_1_ = uVar7;
      FUN_016f3809(&DAT_01eb3938);
      if (DAT_01eb3938 == -1) {
        uStack_8._0_1_ = 5;
        uVar8 = FUN_0152dab0(&DAT_018fb928,"Spread vertical ",0xffffffff);
        DAT_01eb3934 = (undefined4)((ulonglong)uVar8 >> 0x20);
        DAT_01eb3930 = (uint)uVar8;
        uStack_8._0_1_ = 1;
        FUN_016f37bf(&DAT_01eb3938);
      }
    }
    uStack_50 = DAT_01eb3930;
    uStack_38 = DAT_01eb3930;
    uStack_48 = DAT_01eb3934;
    uStack_34 = DAT_01eb3934;
    uVar8 = FUN_0152d930(DAT_01eb3930,DAT_01eb3934);
    uStack_8._0_1_ = 6;
    uStack_30 = uVar8;
    FUN_00829a50(uVar3,uStack_68);
    uStack_e0 = 0;
    uStack_d8 = 0x3f800000;
    iVar6 = param_4;
    if ((char)param_5 != '\0') {
      iVar6 = puStack_58[2];
    }
    (**(code **)(*param_2 + 0x14))(iVar6,uVar4,1,0,0);
    uStack_1c = CONCAT22(uStack_1c._2_2_,0x100);
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*param_2 + 0x34))(0,*puStack_64,&uStack_1c);
    param_3._0_3_ = (uint3)param_3 & 0xff;
    param_3 = (uint)(uint3)param_3;
    uStack_18 = 0x1000100;
    pcVar5 = "DOFDownSampleCoCMax4xFS";
    uStack_1c = 0xf;
    if ((char)param_5 == '\0') {
      pcVar5 = "DOFDownSampleCoCMin4xFS";
    }
    uStack_14 = uStack_14 & 0xff00;
    FUN_0082a430(param_2,uStack_28,"PassThroughVS",pcVar5,auStack_e8,&uStack_1c,(int)&param_3 + 1);
    (**(code **)(*param_2 + 0x18))();
    uStack_8._0_1_ = 7;
    FUN_0152dda0(uStack_50,uStack_48,uStack_30);
    uStack_8._0_1_ = 1;
    uVar7 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if ((char)param_5 != '\0') {
      FUN_00799920(&puStack_4c,uVar3,uStack_24,6);
      uStack_8._0_1_ = 8;
      uVar7 = (undefined)uStack_8;
      uStack_8._0_1_ = 8;
      if (*(int *)(iStack_20 + 0x34) < DAT_01eb3948) {
        uStack_8._0_1_ = uVar7;
        FUN_016f3809(&DAT_01eb3948);
        if (DAT_01eb3948 == -1) {
          uStack_8._0_1_ = 9;
          uVar8 = FUN_0152dab0(&DAT_018fb928,"Spread tiles",0xffffffff);
          DAT_01eb3944 = (undefined4)((ulonglong)uVar8 >> 0x20);
          DAT_01eb3940 = (undefined4)uVar8;
          uStack_8._0_1_ = 8;
          FUN_016f37bf(&DAT_01eb3948);
        }
      }
      uVar2 = DAT_01eb3944;
      param_3 = DAT_01eb3940;
      uStack_38 = DAT_01eb3940;
      uStack_34 = DAT_01eb3944;
      uVar8 = FUN_0152d930(DAT_01eb3940,DAT_01eb3944);
      uStack_8._0_1_ = 10;
      uStack_30 = uVar8;
      FUN_00829a50(uStack_44,uStack_24);
      uStack_d8 = *(undefined4 *)(iStack_3c + 0x50);
      uStack_dc = 0;
      (**(code **)(*param_2 + 0x14))(puStack_4c[2],uStack_40,1,0,0);
      uStack_1c = CONCAT22(uStack_1c._2_2_,0x100);
      uStack_18 = 0;
      uStack_14 = 0;
      (**(code **)(*param_2 + 0x34))(0,*puStack_58,&uStack_1c);
      param_5._1_2_ = 0;
      param_5._3_1_ = 0;
      uStack_18 = 0x1000100;
      uStack_1c = 0xf;
      uStack_14 = uStack_14 & 0xff00;
      FUN_0082a430(param_2,uStack_28,"PassThroughVS","DOFDownSampleCoCMax4xFS",auStack_e8,&uStack_1c
                   ,(int)&param_5 + 1);
      (**(code **)(*param_2 + 0x18))();
      uStack_8._0_1_ = 0xb;
      FUN_0152dda0(param_3,uVar2,uVar8);
      uStack_8._0_1_ = 8;
      uVar7 = (undefined)uStack_8;
      uStack_8._0_1_ = 8;
      if (*(int *)(iStack_20 + 0x34) < DAT_01eb3958) {
        uStack_8._0_1_ = uVar7;
        FUN_016f3809(&DAT_01eb3958);
        if (DAT_01eb3958 == -1) {
          uStack_8._0_1_ = 0xc;
          uVar8 = FUN_0152dab0(&DAT_018fb928,"Spread tiles",0xffffffff);
          DAT_01eb3954 = (undefined4)((ulonglong)uVar8 >> 0x20);
          DAT_01eb3950 = (undefined4)uVar8;
          uStack_8._0_1_ = 8;
          FUN_016f37bf(&DAT_01eb3958);
        }
      }
      uVar2 = DAT_01eb3954;
      param_3 = DAT_01eb3950;
      uStack_38 = DAT_01eb3950;
      uStack_34 = DAT_01eb3954;
      uVar8 = FUN_0152d930(DAT_01eb3950,DAT_01eb3954);
      uStack_8._0_1_ = 0xd;
      uStack_30 = uVar8;
      FUN_00829a50(uStack_44,uStack_24);
      uStack_d8 = *(undefined4 *)(iStack_3c + 0x50);
      uStack_e0 = 0;
      (**(code **)(*param_2 + 0x14))(puStack_58[2],uStack_40,1,0,0);
      uStack_1c = CONCAT22(uStack_1c._2_2_,0x100);
      uStack_18 = 0;
      uStack_14 = 0;
      (**(code **)(*param_2 + 0x34))(0,*puStack_4c,&uStack_1c);
      param_5._1_2_ = 0;
      param_5._3_1_ = 0;
      uStack_18 = 0x1000100;
      uStack_1c = 0xf;
      uStack_14 = uStack_14 & 0xff00;
      FUN_0082a430(param_2,uStack_28,"PassThroughVS","DOFDownSampleCoCMax4xFS",auStack_e8,&uStack_1c
                   ,(int)&param_5 + 1);
      (**(code **)(*param_2 + 0x18))();
      uStack_8._0_1_ = 0xe;
      FUN_0152dda0(param_3,uVar2,uVar8);
      uStack_8._0_1_ = 8;
      uVar7 = (undefined)uStack_8;
      uStack_8._0_1_ = 8;
      if (*(int *)(iStack_20 + 0x34) < DAT_01eb3968) {
        uStack_8._0_1_ = uVar7;
        FUN_016f3809(&DAT_01eb3968);
        if (DAT_01eb3968 == -1) {
          uStack_8._0_1_ = 0xf;
          uVar8 = FUN_0152dab0(&DAT_018fb928,"Average tiles",0xffffffff);
          DAT_01eb3964 = (undefined4)((ulonglong)uVar8 >> 0x20);
          DAT_01eb3960 = (undefined4)uVar8;
          uStack_8._0_1_ = 8;
          FUN_016f37bf(&DAT_01eb3968);
        }
      }
      uVar2 = DAT_01eb3964;
      param_3 = DAT_01eb3960;
      uStack_38 = DAT_01eb3960;
      uStack_34 = DAT_01eb3964;
      uVar8 = FUN_0152d930(DAT_01eb3960,DAT_01eb3964);
      uStack_8._0_1_ = 0x10;
      uStack_30 = uVar8;
      FUN_00829a50(uStack_44,uStack_24);
      uStack_d8 = *(undefined4 *)(iStack_3c + 0x50);
      uStack_dc = 0;
      (**(code **)(*param_2 + 0x14))(puStack_4c[2],uStack_40,1,0,0);
      uStack_1c = CONCAT22(uStack_1c._2_2_,0x101);
      uStack_18 = 0;
      uStack_14 = 0;
      (**(code **)(*param_2 + 0x34))(0,*puStack_58,&uStack_1c);
      param_5._1_2_ = 0;
      param_5._3_1_ = 0;
      uStack_18 = 0x1000100;
      uStack_1c = 0xf;
      uStack_14 = uStack_14 & 0xff00;
      FUN_0082a430(param_2,uStack_28,"PassThroughVS","DOFDownSampleCoCAvg4xFS",auStack_e8,&uStack_1c
                   ,(int)&param_5 + 1);
      (**(code **)(*param_2 + 0x18))();
      uStack_8._0_1_ = 0x11;
      FUN_0152dda0(param_3,uVar2,uVar8);
      uStack_8._0_1_ = 8;
      uVar7 = (undefined)uStack_8;
      uStack_8._0_1_ = 8;
      if (*(int *)(iStack_20 + 0x34) < DAT_01eb3978) {
        uStack_8._0_1_ = uVar7;
        FUN_016f3809(&DAT_01eb3978);
        if (DAT_01eb3978 == -1) {
          uStack_8._0_1_ = 0x12;
          uVar8 = FUN_0152dab0(&DAT_018fb928,"Average tiles",0xffffffff);
          DAT_01eb3974 = (undefined4)((ulonglong)uVar8 >> 0x20);
          DAT_01eb3970 = (uint)uVar8;
          uStack_8._0_1_ = 8;
          FUN_016f37bf(&DAT_01eb3978);
        }
      }
      uVar2 = DAT_01eb3974;
      param_3 = DAT_01eb3970;
      uStack_38 = DAT_01eb3970;
      uStack_34 = DAT_01eb3974;
      uVar8 = FUN_0152d930(DAT_01eb3970,DAT_01eb3974);
      uStack_8._0_1_ = 0x13;
      uStack_30 = uVar8;
      FUN_00829a50(uStack_44,uStack_24);
      uStack_d8 = *(undefined4 *)(iStack_3c + 0x50);
      uStack_e0 = 0;
      (**(code **)(*param_2 + 0x14))(param_4,uStack_40,1,0,0);
      uStack_1c = CONCAT22(uStack_1c._2_2_,0x101);
      uStack_18 = 0;
      uStack_14 = 0;
      (**(code **)(*param_2 + 0x34))(0,*puStack_4c,&uStack_1c);
      param_5._1_2_ = 0;
      param_5._3_1_ = 0;
      uStack_18 = 0x1000100;
      uStack_1c = 0xf;
      uStack_14 = uStack_14 & 0xff00;
      FUN_0082a430(param_2,uStack_28,"PassThroughVS","DOFDownSampleCoCAvg4xFS",auStack_e8,&uStack_1c
                   ,(int)&param_5 + 1);
      (**(code **)(*param_2 + 0x18))();
      uStack_8._0_1_ = 0x14;
      FUN_0152dda0(param_3,uVar2,uVar8);
      FUN_00550b30();
      uVar7 = (undefined)uStack_8;
    }
    uStack_8._0_1_ = uVar7;
    uVar7 = 1;
  }
  if (piStack_54 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_54[1] + -1;
    piStack_54[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_54)();
      LOCK();
      iVar6 = piStack_54[2] + -1;
      piStack_54[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_54 + 4))();
      }
    }
  }
  if (piStack_60 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_60[1] + -1;
    piStack_60[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_60)();
      LOCK();
      piVar1 = piStack_60 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piStack_60 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 12469 ; VA 0x008151a0 ; FUN_008151a0 */

undefined4 FUN_008151a0(undefined4 param_1)

{
  switch(param_1) {
  case 0:
    return 1;
  case 1:
    return 2;
  case 2:
  case 3:
    return 4;
  default:
    return param_1;
  }
}



/* FUNCTION 12470 ; VA 0x008151f0 ; FUN_008151f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 __thiscall FUN_008151f0(int param_1,char param_2)

{
  double dVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  undefined4 uStack_c;
  
  fVar3 = *(float *)(param_1 + 0x44);
  if (param_2 != '\0') {
    return (float10)fVar3;
  }
  if (DAT_01d61fa4 == '\0') {
    fVar4 = 0.0;
    fVar2 = (fVar3 * DAT_0190193c * *(float *)(param_1 + 0x54)) / _DAT_01901d40;
    if (0.0 < fVar2) {
      dVar1 = (double)((*(float *)(param_1 + 0x54) * fVar3) / fVar2);
      FUN_017267a0();
      fVar4 = (float)dVar1;
    }
    return (float10)fVar4;
  }
  fVar2 = fVar3 / DAT_01901d3c + DAT_018f784c;
  fVar3 = DAT_018ce2f8;
  if (fVar2 <= DAT_018ce2f8) {
    fVar3 = fVar2;
  }
  dVar1 = (double)fVar3;
  FUN_017267a0();
  uStack_c = (float)dVar1 * _DAT_01901d38 * DAT_01901d3c;
  if (*(float *)(param_1 + 0x54) <= 0.0) {
    uStack_c = 0.0;
  }
  return (float10)uStack_c;
}



/* FUNCTION 12471 ; VA 0x008152d0 ; FUN_008152d0 */

float10 __fastcall FUN_008152d0(int param_1)

{
  float fVar1;
  float fVar2;
  
  fVar2 = *(float *)(param_1 + 0x44) / DAT_01901d3c + DAT_018f784c;
  fVar1 = DAT_018ce2f8;
  if (fVar2 <= DAT_018ce2f8) {
    fVar1 = fVar2;
  }
  return (float10)fVar1;
}



/* FUNCTION 12472 ; VA 0x00815310 ; FUN_00815310 */

float10 __fastcall FUN_00815310(int param_1)

{
  return (float10)*(float *)(param_1 + 0x48) / (float10)DAT_01901d3c + (float10)DAT_018f784c;
}



/* FUNCTION 12473 ; VA 0x00815320 ; FUN_00815320 */

undefined __thiscall
FUN_00815320(int param_1,int *param_2,int param_3,int *param_4,undefined4 param_5,int *param_6)

{
  int *piVar1;
  float fVar2;
  int iVar3;
  int *piVar4;
  undefined uVar5;
  char cVar6;
  uint uVar7;
  uint uVar8;
  undefined8 uVar9;
  undefined auStack_24c [128];
  undefined auStack_1cc [128];
  undefined auStack_14c [128];
  undefined auStack_cc [16];
  undefined auStack_bc [8];
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined8 uStack_a4;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined4 auStack_8c [2];
  undefined4 *puStack_84;
  int *piStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 *puStack_70;
  int *piStack_6c;
  undefined4 *puStack_68;
  int *piStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined8 uStack_58;
  undefined4 *puStack_50;
  int *piStack_4c;
  uint uStack_48;
  int iStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  ushort uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017b5a7b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_7 = 0;
  uStack_2c = **(undefined4 **)(param_1 + 0x40);
  uStack_24 = *(uint *)(param_3 + 0x30);
  uStack_20 = *(uint *)(param_3 + 0x34);
  ExceptionList = &pvStack_10;
  iStack_28 = param_1;
  FUN_00829b90(uStack_24,uStack_20,param_1);
  if (*(char *)(param_1 + 0x58) != '\0') {
    fVar2 = *(float *)(param_1 + 0x54);
    if ((NAN(fVar2) || NAN(DAT_018ce2f0)) == (fVar2 == DAT_018ce2f0)) {
      if (fVar2 < DAT_01901d2c) {
        if (param_6 != (int *)0x0) {
          LOCK();
          param_6[1] = param_6[1] + 1;
          UNLOCK();
        }
        if (param_4 != (int *)0x0) {
          LOCK();
          param_4[1] = param_4[1] + 1;
          UNLOCK();
        }
        param_2._3_1_ = FUN_00816510(param_2,param_3,param_4,param_5,param_6,fVar2,0);
        goto LAB_00815ad0;
      }
      FUN_00799920(&puStack_70,uStack_24,uStack_20,0x1b);
      uStack_8 = 2;
      uVar7 = FUN_008151a0(1);
      uVar8 = ((uStack_24 & 1) + uStack_24) / uVar7;
      if (uVar8 == 0) {
        uVar8 = 1;
      }
      uStack_24 = ((uStack_20 & 1) + uStack_20) / uVar7;
      if (uStack_24 == 0) {
        uStack_24 = 1;
      }
      uStack_48 = uVar8;
      FUN_00829b90(uVar8,uStack_24,param_1);
      FUN_00799920(&puStack_50,uVar8,uStack_24,8);
      uStack_8 = 3;
      FUN_00799920(&puStack_84,uVar8,uStack_24,8);
      uStack_8 = 4;
      FUN_00799920(&puStack_68,uVar8,uStack_24,6);
      uStack_8 = 5;
      uVar5 = uStack_8;
      uStack_8 = 5;
      if (((puStack_70 == (undefined4 *)0x0) || (puStack_50 == (undefined4 *)0x0)) ||
         (puStack_68 == (undefined4 *)0x0)) {
        param_2._3_1_ = 0;
        uStack_8 = uVar5;
      }
      else {
        FUN_0147d4b0();
        uStack_8 = 6;
        uStack_b0 = 0;
        uStack_b4 = 0;
        uStack_40 = 0;
        uStack_3c = 0;
        FUN_005587e0(&uStack_40);
        FUN_00550b30();
        FUN_0147d420(&param_5);
        uStack_8 = 7;
        FUN_0147bf30(auStack_8c,auStack_cc,auStack_bc);
        uStack_8 = 9;
        FUN_00550b30();
        iVar3 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
        iStack_44 = iVar3;
        if (*(int *)(iVar3 + 0x34) < DAT_01eb3998) {
          FUN_016f3809(&DAT_01eb3998);
          if (DAT_01eb3998 == -1) {
            uStack_8 = 10;
            uVar9 = FUN_0152dab0("Render",&DAT_01901c14,0xffffffff);
            DAT_01eb3994 = (undefined4)((ulonglong)uVar9 >> 0x20);
            DAT_01eb3990 = (undefined4)uVar9;
            uStack_8 = 9;
            FUN_016f37bf(&DAT_01eb3998);
          }
        }
        uStack_3c = DAT_01eb3990;
        uStack_ac = DAT_01eb3990;
        uStack_7c = DAT_01eb3994;
        uStack_a8 = DAT_01eb3994;
        uStack_a4 = FUN_0152d930(DAT_01eb3990,DAT_01eb3994);
        uStack_8 = 0xb;
        if (*(int *)(iVar3 + 0x34) < DAT_01eb39a8) {
          FUN_016f3809(&DAT_01eb39a8);
          if (DAT_01eb39a8 == -1) {
            uStack_8 = 0xc;
            uVar9 = FUN_0152dab0(&DAT_018fb928,&DAT_01901c14,0xffffffff);
            DAT_01eb39a4 = (undefined4)((ulonglong)uVar9 >> 0x20);
            DAT_01eb39a0 = (undefined4)uVar9;
            uStack_8 = 0xb;
            FUN_016f37bf(&DAT_01eb39a8);
          }
        }
        uStack_78 = DAT_01eb39a0;
        uStack_9c = DAT_01eb39a0;
        uStack_74 = DAT_01eb39a4;
        uStack_98 = DAT_01eb39a4;
        uStack_94 = FUN_0152d930(DAT_01eb39a0,DAT_01eb39a4);
        uStack_8 = 0xd;
        uVar5 = uStack_8;
        uStack_8 = 0xd;
        if (*(int *)(iVar3 + 0x34) < DAT_01eb39b8) {
          uStack_8 = uVar5;
          FUN_016f3809(&DAT_01eb39b8);
          if (DAT_01eb39b8 == -1) {
            uStack_8 = 0xe;
            uVar9 = FUN_0152dab0(&DAT_018fb928,"Copy Color Full Resolution",0xffffffff);
            DAT_01eb39b4 = (uint)((ulonglong)uVar9 >> 0x20);
            DAT_01eb39b0 = (uint)uVar9;
            uStack_8 = 0xd;
            FUN_016f37bf(&DAT_01eb39b8);
          }
        }
        uStack_34 = DAT_01eb39b0;
        uStack_60 = DAT_01eb39b0;
        uStack_30 = DAT_01eb39b4;
        uStack_5c = DAT_01eb39b4;
        uVar9 = FUN_0152d930(DAT_01eb39b0,DAT_01eb39b4);
        uStack_8 = 0xf;
        uStack_58 = uVar9;
        (**(code **)(*param_2 + 0x14))(puStack_70[2],0,1,0,0);
        iVar3 = iStack_28;
        FUN_007a04c0(1,0);
        (**(code **)(*param_2 + 0x30))(0,*(int *)(iVar3 + 0x40) + 0x54,0x350);
        uStack_1c = CONCAT22(uStack_1c._2_2_,0x100);
        uStack_18 = 0;
        uStack_14 = 0;
        (**(code **)(*param_2 + 0x34))(0,param_5,&uStack_1c);
        uStack_20._0_3_ = (uint3)uStack_20 & 0xff;
        uStack_20 = (uint)(uint3)uStack_20;
        uStack_18 = 0x1000100;
        uStack_1c = 0xf;
        uStack_14 = uStack_14 & 0xff00;
        FUN_0082a430(param_2,uStack_2c,"PassThroughVS","PassThroughFS",auStack_14c,&uStack_1c,
                     (int)&uStack_20 + 1);
        (**(code **)(*param_2 + 0x18))();
        uStack_8 = 0x10;
        FUN_0152dda0(uStack_34,uStack_30,uVar9);
        uStack_8 = 0xd;
        cVar6 = FUN_008143d0(param_2,param_3,param_5,puStack_84[2],1,0);
        if (cVar6 == '\0') {
LAB_008159d6:
          param_2._3_1_ = 0;
        }
        else {
          cVar6 = FUN_008147f0(param_2,param_3,puStack_68[2],0);
          if (cVar6 == '\0') goto LAB_008159d6;
          uStack_30 = (uint)(DAT_01d61fac == '\0');
          if (*(int *)(iStack_44 + 0x34) < DAT_01eb39c8) {
            FUN_016f3809(&DAT_01eb39c8);
            if (DAT_01eb39c8 == -1) {
              uStack_8 = 0x15;
              uVar9 = FUN_0152dab0(&DAT_018fb928,"Edge Fatten",0xffffffff);
              DAT_01eb39c4 = (uint)((ulonglong)uVar9 >> 0x20);
              DAT_01eb39c0 = (uint)uVar9;
              uStack_8 = 0xd;
              FUN_016f37bf(&DAT_01eb39c8);
            }
          }
          uStack_38 = DAT_01eb39c0;
          uStack_60 = DAT_01eb39c0;
          uStack_34 = DAT_01eb39c4;
          uStack_5c = DAT_01eb39c4;
          uVar9 = FUN_0152d930(DAT_01eb39c0,DAT_01eb39c4);
          uStack_8 = 0x16;
          uStack_58 = uVar9;
          (**(code **)(*param_2 + 0x14))(puStack_50[2],uStack_30,1,0,0);
          uStack_1c = CONCAT22(uStack_1c._2_2_,0x100);
          uStack_18 = 0;
          uStack_14 = 0;
          (**(code **)(*param_2 + 0x34))(1,*puStack_84,&uStack_1c);
          uStack_20._0_3_ = (uint3)uStack_20 & 0xff;
          uStack_20 = (uint)(uint3)uStack_20;
          uStack_18 = 0x1000100;
          uStack_1c = 0xf;
          uStack_14 = uStack_14 & 0xff00;
          FUN_0082a430(param_2,uStack_2c,"PassThroughVS","DOFEdgeFattenFS",auStack_1cc,&uStack_1c,
                       (int)&uStack_20 + 1);
          (**(code **)(*param_2 + 0x18))();
          uStack_8 = 0x17;
          FUN_0152dda0(uStack_38,uStack_34,uVar9);
          uStack_8 = 0xd;
          cVar6 = FUN_00813ff0(param_2,*puStack_50,puStack_50[2],*(undefined4 *)(iStack_28 + 0x54),
                               *puStack_68,0);
          if (cVar6 == '\0') goto LAB_008159d6;
          if (*(int *)(iStack_44 + 0x34) < DAT_01eb39d8) {
            FUN_016f3809(&DAT_01eb39d8);
            if (DAT_01eb39d8 == -1) {
              uStack_8 = 0x1a;
              uVar9 = FUN_0152dab0(&DAT_018fb928,"Resolve Depth of Field Full Resolution",0xffffffff
                                  );
              DAT_01eb39d4 = (uint)((ulonglong)uVar9 >> 0x20);
              DAT_01eb39d0 = (uint)uVar9;
              uStack_8 = 0xd;
              FUN_016f37bf(&DAT_01eb39d8);
            }
          }
          uVar7 = DAT_01eb39d4;
          uStack_38 = DAT_01eb39d0;
          uStack_60 = DAT_01eb39d0;
          uStack_5c = DAT_01eb39d4;
          uVar9 = FUN_0152d930(DAT_01eb39d0,DAT_01eb39d4);
          uStack_8 = 0x1b;
          uStack_58 = uVar9;
          FUN_00829b90(uStack_48,uStack_24,iStack_28);
          (**(code **)(*param_2 + 0x14))(auStack_8c[0],uStack_30,1,0,0);
          uStack_1c._0_2_ = 0x101;
          uStack_18 = 0;
          uStack_14 = 0;
          (**(code **)(*param_2 + 0x34))(0,param_3,&uStack_1c);
          uStack_1c._0_2_ = 0x100;
          uStack_18 = 0;
          uStack_14 = 0;
          (**(code **)(*param_2 + 0x34))(1,*puStack_70,&uStack_1c);
          uStack_1c = CONCAT22(uStack_1c._2_2_,0x101);
          uStack_18 = 0;
          uStack_14 = 0;
          (**(code **)(*param_2 + 0x34))(2,*puStack_50,&uStack_1c);
          (**(code **)(*param_2 + 0x30))(0,*(int *)(iStack_28 + 0x40) + 0x54,0x350);
          uStack_20._0_3_ = (uint3)uStack_20 & 0xff;
          uStack_20 = (uint)(uint3)uStack_20;
          uStack_18 = 0x1000100;
          uStack_1c = 0xf;
          uStack_14 = uStack_14 & 0xff00;
          FUN_0082a430(param_2,uStack_2c,"PassThroughVS","DOFResolveFarFS",auStack_24c,&uStack_1c,
                       (int)&uStack_20 + 1);
          (**(code **)(*param_2 + 0x18))();
          uStack_8 = 0x1c;
          FUN_0152dda0(uStack_38,uVar7,uVar9);
          param_2._3_1_ = 1;
        }
        uStack_8 = 0x1d;
        FUN_0152dda0(uStack_78,uStack_74,uStack_94);
        uStack_8 = 0x1e;
        FUN_0152dda0(uStack_3c,uStack_7c,uStack_a4);
        FUN_00550b30();
        FUN_00550b30();
      }
      if (piStack_64 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_64[1] + -1;
        piStack_64[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_64)();
          LOCK();
          iVar3 = piStack_64[2] + -1;
          piStack_64[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_64 + 4))();
          }
        }
      }
      if (piStack_80 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_80[1] + -1;
        piStack_80[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_80)();
          LOCK();
          iVar3 = piStack_80[2] + -1;
          piStack_80[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_80 + 4))();
          }
        }
      }
      if (piStack_4c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_4c[1] + -1;
        piStack_4c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_4c)();
          LOCK();
          iVar3 = piStack_4c[2] + -1;
          piStack_4c[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_4c + 4))();
          }
        }
      }
      if (piStack_6c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_6c[1] + -1;
        piStack_6c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_6c)();
          LOCK();
          iVar3 = piStack_6c[2] + -1;
          piStack_6c[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_6c + 4))();
          }
        }
      }
      goto LAB_00815ad0;
    }
  }
  param_2._3_1_ = 1;
LAB_00815ad0:
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[1] + -1;
    param_4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar3 = param_4[2] + -1;
      param_4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  piVar4 = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar3 = param_6[1] + -1;
    param_6[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2._3_1_;
}



/* FUNCTION 12474 ; VA 0x00815cd0 ; FUN_00815cd0 */

undefined __thiscall
FUN_00815cd0(int param_1,int *param_2,int param_3,int *param_4,undefined4 param_5,int *param_6)

{
  int *piVar1;
  float fVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  undefined uVar6;
  char cVar7;
  uint uVar8;
  uint uVar9;
  undefined8 uVar10;
  undefined auStack_13c [128];
  undefined auStack_bc [16];
  undefined auStack_ac [8];
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined8 uStack_84;
  undefined4 auStack_7c [2];
  int iStack_74;
  uint uStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  int iStack_58;
  undefined4 *puStack_54;
  int *piStack_50;
  undefined4 *puStack_4c;
  int *piStack_48;
  int iStack_44;
  undefined4 *puStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int iStack_30;
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  ushort uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017b5b2c;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_7 = 0;
  uStack_28 = **(undefined4 **)(param_1 + 0x40);
  uVar9 = *(uint *)(param_3 + 0x34);
  uStack_20 = *(uint *)(param_3 + 0x30);
  ExceptionList = &pvStack_10;
  iStack_44 = param_1;
  uStack_2c = uVar9;
  FUN_00829b90(uStack_20,uVar9,param_1);
  uVar5 = uStack_20;
  if (*(char *)(param_1 + 0x58) != '\0') {
    fVar2 = *(float *)(param_1 + 0x50);
    if ((NAN(fVar2) || NAN(DAT_018ce2f0)) == (fVar2 == DAT_018ce2f0)) {
      if (fVar2 < DAT_01901d2c) {
        if (param_6 != (int *)0x0) {
          LOCK();
          param_6[1] = param_6[1] + 1;
          UNLOCK();
        }
        if (param_4 != (int *)0x0) {
          LOCK();
          param_4[1] = param_4[1] + 1;
          UNLOCK();
        }
        param_2._3_1_ = FUN_00816510(param_2,param_3,param_4,param_5,param_6,fVar2,1);
        goto LAB_00816368;
      }
      if (((int)uVar9 < 0x21d) || (fVar2 < DAT_01901d30)) {
        uStack_24 = 1;
      }
      else if (((int)uVar9 < 0x439) || (fVar2 < DAT_018ce2f4)) {
        uStack_24 = 2;
      }
      else {
        uStack_24 = 3;
      }
      FUN_00799920(&puStack_54,uStack_20,uVar9,0x1b);
      uStack_8 = 2;
      uVar8 = FUN_008151a0(uStack_24);
      uVar9 = ((uVar5 & 1) + uVar5) / uVar8;
      if (uVar9 == 0) {
        uVar9 = 1;
      }
      uVar8 = ((uStack_2c & 1) + uStack_2c) / uVar8;
      if (uVar8 == 0) {
        uVar8 = 1;
      }
      FUN_00799920(&puStack_40,uVar9,uVar8,8);
      uStack_8 = 3;
      FUN_00799920(&puStack_4c,uVar9,uVar8,6);
      uStack_8 = 4;
      uVar6 = uStack_8;
      uStack_8 = 4;
      if (((puStack_54 == (undefined4 *)0x0) || (puStack_40 == (undefined4 *)0x0)) ||
         (puStack_4c == (undefined4 *)0x0)) {
        param_2._3_1_ = 0;
        uStack_8 = uVar6;
      }
      else {
        FUN_0147d4b0();
        uStack_8 = 5;
        uStack_a0 = 0;
        uStack_a4 = 0;
        uStack_38 = 0;
        uStack_34 = 0;
        FUN_005587e0(&uStack_38);
        FUN_00550b30();
        FUN_0147d420(&param_5);
        uStack_8 = 6;
        FUN_0147bf30(auStack_7c,auStack_bc,auStack_ac);
        uStack_8 = 8;
        FUN_00550b30();
        iVar3 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
        iStack_30 = iVar3;
        if (*(int *)(iVar3 + 0x34) < DAT_01eb3a28) {
          FUN_016f3809(&DAT_01eb3a28);
          if (DAT_01eb3a28 == -1) {
            uStack_8 = 9;
            uVar10 = FUN_0152dab0("Render",&DAT_01901c14,0xffffffff);
            DAT_01eb3a24 = (undefined4)((ulonglong)uVar10 >> 0x20);
            DAT_01eb3a20 = (undefined4)uVar10;
            uStack_8 = 8;
            FUN_016f37bf(&DAT_01eb3a28);
          }
        }
        uStack_34 = DAT_01eb3a20;
        uStack_9c = DAT_01eb3a20;
        uStack_64 = DAT_01eb3a24;
        uStack_98 = DAT_01eb3a24;
        uStack_94 = FUN_0152d930(DAT_01eb3a20,DAT_01eb3a24);
        uStack_8 = 10;
        if (*(int *)(iVar3 + 0x34) < DAT_01eb3a38) {
          FUN_016f3809(&DAT_01eb3a38);
          if (DAT_01eb3a38 == -1) {
            uStack_8 = 0xb;
            uVar10 = FUN_0152dab0(&DAT_018fb928,&DAT_01901c14,0xffffffff);
            DAT_01eb3a34 = (undefined4)((ulonglong)uVar10 >> 0x20);
            DAT_01eb3a30 = (undefined4)uVar10;
            uStack_8 = 10;
            FUN_016f37bf(&DAT_01eb3a38);
          }
        }
        uStack_60 = DAT_01eb3a30;
        uStack_8c = DAT_01eb3a30;
        uStack_5c = DAT_01eb3a34;
        uStack_88 = DAT_01eb3a34;
        uStack_84 = FUN_0152d930(DAT_01eb3a30,DAT_01eb3a34);
        uStack_8 = 0xc;
        uVar6 = uStack_8;
        uStack_8 = 0xc;
        if (*(int *)(iVar3 + 0x34) < DAT_01eb3a48) {
          uStack_8 = uVar6;
          FUN_016f3809(&DAT_01eb3a48);
          if (DAT_01eb3a48 == -1) {
            uStack_8 = 0xd;
            uVar10 = FUN_0152dab0(&DAT_018fb928,"Copy Color Full Resolution",0xffffffff);
            DAT_01eb3a44 = (uint)((ulonglong)uVar10 >> 0x20);
            DAT_01eb3a40 = (int)uVar10;
            uStack_8 = 0xc;
            FUN_016f37bf(&DAT_01eb3a48);
          }
        }
        iStack_58 = DAT_01eb3a40;
        iStack_74 = DAT_01eb3a40;
        uStack_2c = DAT_01eb3a44;
        uStack_70 = DAT_01eb3a44;
        uVar10 = FUN_0152d930(DAT_01eb3a40,DAT_01eb3a44);
        uStack_8 = 0xe;
        uStack_6c = uVar10;
        (**(code **)(*param_2 + 0x14))(puStack_54[2],0,1,0,0);
        iVar3 = iStack_44;
        FUN_007a04c0(1,2);
        (**(code **)(*param_2 + 0x30))(0,*(int *)(iVar3 + 0x40) + 0x54,0x350);
        uStack_1c = CONCAT22(uStack_1c._2_2_,0x100);
        uStack_18 = 0;
        uStack_14 = 0;
        (**(code **)(*param_2 + 0x34))(0,param_5,&uStack_1c);
        uStack_20._0_3_ = (uint3)uStack_20 & 0xff;
        uStack_20 = (uint)(uint3)uStack_20;
        uStack_18 = 0x1000100;
        uStack_1c = 0xf;
        uStack_14 = uStack_14 & 0xff00;
        FUN_0082a430(param_2,uStack_28,"PassThroughVS","PassThroughFS",auStack_13c,&uStack_1c,
                     (int)&uStack_20 + 1);
        (**(code **)(*param_2 + 0x18))();
        uStack_8 = 0xf;
        FUN_0152dda0(iStack_58,uStack_2c,uVar10);
        uStack_8 = 0xc;
        cVar7 = FUN_008143d0(param_2,param_3,param_5,puStack_40[2],uStack_24,1);
        if (cVar7 == '\0') {
LAB_0081622e:
          param_2._3_1_ = 0;
        }
        else {
          cVar7 = FUN_008147f0(param_2,*puStack_40,puStack_4c[2],1);
          if (cVar7 == '\0') goto LAB_0081622e;
          cVar7 = FUN_00813ff0(param_2,*puStack_40,puStack_40[2],*(undefined4 *)(iVar3 + 0x50),
                               *puStack_4c,1);
          if (cVar7 == '\0') goto LAB_0081622e;
          if (*(int *)(iStack_30 + 0x34) < DAT_01eb3a58) {
            FUN_016f3809(&DAT_01eb3a58);
            if (DAT_01eb3a58 == -1) {
              uStack_8 = 0x16;
              uVar10 = FUN_0152dab0(&DAT_018fb928,"Resolve Depth of Field Full Resolution",
                                    0xffffffff);
              DAT_01eb3a54 = (uint)((ulonglong)uVar10 >> 0x20);
              DAT_01eb3a50 = (int)uVar10;
              uStack_8 = 0xc;
              FUN_016f37bf(&DAT_01eb3a58);
            }
          }
          uVar9 = DAT_01eb3a54;
          iStack_30 = DAT_01eb3a50;
          iStack_74 = DAT_01eb3a50;
          uStack_70 = DAT_01eb3a54;
          uVar10 = FUN_0152d930(DAT_01eb3a50,DAT_01eb3a54);
          uStack_8 = 0x17;
          uStack_6c = uVar10;
          (**(code **)(*param_2 + 0x14))(auStack_7c[0],DAT_01d61fac == '\0',1,0,0);
          uStack_1c._0_2_ = 0x100;
          uStack_18 = 0;
          uStack_14 = 0;
          (**(code **)(*param_2 + 0x34))(0,param_3,&uStack_1c);
          uStack_1c._0_2_ = 0x100;
          uStack_18 = 0;
          uStack_14 = 0;
          (**(code **)(*param_2 + 0x34))(1,*puStack_54,&uStack_1c);
          uStack_1c = CONCAT22(uStack_1c._2_2_,0x101);
          uStack_18 = 0;
          uStack_14 = 0;
          (**(code **)(*param_2 + 0x34))(2,*puStack_40,&uStack_1c);
          (**(code **)(*param_2 + 0x30))(0,*(int *)(iStack_44 + 0x40) + 0x54,0x350);
          uStack_20._0_3_ = (uint3)uStack_20 & 0xff;
          uStack_20 = (uint)(uint3)uStack_20;
          uStack_18 = 0x1000100;
          uStack_1c = 0xf;
          uStack_14 = uStack_14 & 0xff00;
          FUN_0082a430(param_2,uStack_28,"PassThroughVS","DOFResolveNearFS",auStack_13c,&uStack_1c,
                       (int)&uStack_20 + 1);
          (**(code **)(*param_2 + 0x18))();
          uStack_8 = 0x18;
          FUN_0152dda0(iStack_30,uVar9,uVar10);
          param_2._3_1_ = 1;
        }
        uStack_8 = 0x19;
        FUN_0152dda0(uStack_60,uStack_5c,uStack_84);
        uStack_8 = 0x1a;
        FUN_0152dda0(uStack_34,uStack_64,uStack_94);
        FUN_00550b30();
        FUN_00550b30();
      }
      if (piStack_48 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_48[1] + -1;
        piStack_48[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_48)();
          LOCK();
          iVar3 = piStack_48[2] + -1;
          piStack_48[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_48 + 4))();
          }
        }
      }
      if (piStack_3c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_3c[1] + -1;
        piStack_3c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_3c)();
          LOCK();
          iVar3 = piStack_3c[2] + -1;
          piStack_3c[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_3c + 4))();
          }
        }
      }
      if (piStack_50 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_50[1] + -1;
        piStack_50[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_50)();
          LOCK();
          iVar3 = piStack_50[2] + -1;
          piStack_50[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piStack_50 + 4))();
          }
        }
      }
      goto LAB_00816368;
    }
  }
  param_2._3_1_ = 1;
LAB_00816368:
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[1] + -1;
    param_4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar3 = param_4[2] + -1;
      param_4[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  piVar4 = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar3 = param_6[1] + -1;
    param_6[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2._3_1_;
}



/* FUNCTION 12475 ; VA 0x00816510 ; FUN_00816510 */

undefined __thiscall
FUN_00816510(int param_1,int *param_2,int param_3,int *param_4,undefined4 param_5,int *param_6,
            float param_7,undefined4 param_8)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  uint3 uVar5;
  ulonglong uVar6;
  int *piVar7;
  undefined uVar8;
  char *pcVar9;
  undefined8 uVar10;
  undefined auStack_120 [16];
  undefined4 uStack_110;
  float fStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined auStack_a0 [4];
  int *piStack_9c;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined8 uStack_88;
  undefined4 uStack_80;
  int *piStack_7c;
  undefined4 uStack_78;
  int *piStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  float fStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  float fStack_4c;
  undefined8 uStack_48;
  undefined4 *puStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  float fStack_34;
  undefined8 uStack_30;
  int iStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  ushort uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5bc6;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_24 = **(undefined4 **)(param_1 + 0x40);
  uVar2 = *(undefined4 *)(param_3 + 0x34);
  uVar3 = *(undefined4 *)(param_3 + 0x30);
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  FUN_00829b90(uVar3,uVar2,param_1);
  fStack_10c = param_7 * DAT_01901d34;
  uStack_38 = 0;
  uStack_30._0_4_ = 0;
  uStack_30._4_4_ = 0;
  uStack_110 = 0;
  uStack_108 = 0;
  uStack_104 = 0;
  fStack_34 = fStack_10c;
  FUN_00799920(&puStack_40,uVar3,uVar2,8);
  uStack_8._0_1_ = 2;
  if (puStack_40 == (undefined4 *)0x0) {
    param_8._3_1_ = 0;
  }
  else {
    FUN_0147d4b0();
    piVar7 = piStack_74;
    uStack_8._0_1_ = 3;
    uStack_6c = 0;
    uStack_70 = 0;
    uStack_78 = 0;
    piStack_74 = (int *)0x0;
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar4 = piVar7[1] + -1;
      piVar7[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar7)();
        LOCK();
        iVar4 = piVar7[2] + -1;
        piVar7[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
    FUN_0147d420(&param_5);
    uStack_8._0_1_ = 4;
    FUN_0147bf30(&uStack_80,auStack_a0,&uStack_78);
    uStack_8._0_1_ = 6;
    if (piStack_9c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_9c[1] + -1;
      piStack_9c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_9c)();
        LOCK();
        iVar4 = piStack_9c[2] + -1;
        piStack_9c[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_9c + 4))();
        }
      }
    }
    iVar4 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    iStack_28 = iVar4;
    if (*(int *)(iVar4 + 0x34) < DAT_01eb39e8) {
      FUN_016f3809(&DAT_01eb39e8);
      if (DAT_01eb39e8 == -1) {
        uStack_8._0_1_ = 7;
        uVar10 = FUN_0152dab0("Render",&DAT_01901c14,0xffffffff);
        DAT_01eb39e4 = (float)((ulonglong)uVar10 >> 0x20);
        DAT_01eb39e0 = (undefined4)uVar10;
        uStack_8._0_1_ = 6;
        FUN_016f37bf(&DAT_01eb39e8);
      }
    }
    uStack_68 = DAT_01eb39e0;
    uStack_38 = DAT_01eb39e0;
    fStack_64 = DAT_01eb39e4;
    fStack_34 = DAT_01eb39e4;
    uStack_30 = FUN_0152d930(DAT_01eb39e0,DAT_01eb39e4);
    uStack_8._0_1_ = 8;
    if (*(int *)(iVar4 + 0x34) < DAT_01eb39f8) {
      FUN_016f3809(&DAT_01eb39f8);
      if (DAT_01eb39f8 == -1) {
        uStack_8._0_1_ = 9;
        uVar10 = FUN_0152dab0(&DAT_018fb928,&DAT_01901c14,0xffffffff);
        DAT_01eb39f4 = (undefined4)((ulonglong)uVar10 >> 0x20);
        DAT_01eb39f0 = (undefined4)uVar10;
        uStack_8._0_1_ = 8;
        FUN_016f37bf(&DAT_01eb39f8);
      }
    }
    uStack_60 = DAT_01eb39f0;
    uStack_90 = DAT_01eb39f0;
    uStack_5c = DAT_01eb39f4;
    uStack_8c = DAT_01eb39f4;
    uStack_88 = FUN_0152d930(DAT_01eb39f0,DAT_01eb39f4);
    uStack_8._0_1_ = 10;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 10;
    if (*(int *)(iVar4 + 0x34) < DAT_01eb3a08) {
      uStack_8._0_1_ = uVar8;
      FUN_016f3809(&DAT_01eb3a08);
      if (DAT_01eb3a08 == -1) {
        uStack_8._0_1_ = 0xb;
        uVar10 = FUN_0152dab0(&DAT_018fb928,"Copy and Compute CoC Full Resolution",0xffffffff);
        DAT_01eb3a04 = (undefined4)((ulonglong)uVar10 >> 0x20);
        DAT_01eb3a00 = (undefined4)uVar10;
        uStack_8._0_1_ = 10;
        FUN_016f37bf(&DAT_01eb3a08);
      }
    }
    uStack_58 = DAT_01eb3a00;
    uStack_50 = DAT_01eb3a00;
    uStack_54 = DAT_01eb3a04;
    fStack_4c = (float)DAT_01eb3a04;
    uStack_48 = FUN_0152d930(DAT_01eb3a00,DAT_01eb3a04);
    uVar6 = (ulonglong)uStack_48 >> 0x20;
    uStack_8._0_1_ = 0xc;
    (**(code **)(*param_2 + 0x14))(puStack_40[2],0,1,0,0);
    iVar4 = iStack_20;
    FUN_007a04c0(1,(uint)(byte)param_8 * 2);
    (**(code **)(*param_2 + 0x30))(0,*(int *)(iVar4 + 0x40) + 0x54,0x350);
    uStack_1c._0_2_ = 0x100;
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*param_2 + 0x34))(0,param_3,&uStack_1c);
    uStack_1c = CONCAT22(uStack_1c._2_2_,0x100);
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*param_2 + 0x34))(1,param_5,&uStack_1c);
    uVar5 = SUB43(param_7,0);
    param_7 = (float)(uint)(uVar5 & 0xff);
    pcVar9 = "DOFFullscreenNearFieldCoCFS";
    uStack_18 = 0x1000100;
    uStack_1c = 0xf;
    if ((byte)param_8 == 0) {
      pcVar9 = "DOFFullscreenFarFieldCoCFS";
    }
    uStack_14 = uStack_14 & 0xff00;
    FUN_0082a430(param_2,uStack_24,"PassThroughVS",pcVar9,auStack_120,&uStack_1c,(int)&param_7 + 1);
    (**(code **)(*param_2 + 0x18))();
    uStack_8._0_1_ = 0xd;
    FUN_0152dda0(uStack_58,uStack_54,(undefined4)uStack_48,(int)uVar6);
    uStack_8._0_1_ = 10;
    uVar8 = (undefined)uStack_8;
    uStack_8._0_1_ = 10;
    if (*(int *)(iStack_28 + 0x34) < DAT_01eb3a18) {
      uStack_8._0_1_ = uVar8;
      FUN_016f3809(&DAT_01eb3a18);
      if (DAT_01eb3a18 == -1) {
        uStack_8._0_1_ = 0xe;
        uVar10 = FUN_0152dab0(&DAT_018fb928,"Optimized Bokeh Full Resolution",0xffffffff);
        DAT_01eb3a14 = (float)((ulonglong)uVar10 >> 0x20);
        DAT_01eb3a10 = (undefined4)uVar10;
        uStack_8._0_1_ = 10;
        FUN_016f37bf(&DAT_01eb3a18);
      }
    }
    iStack_28 = DAT_01eb3a10;
    uStack_50 = DAT_01eb3a10;
    param_7 = DAT_01eb3a14;
    fStack_4c = DAT_01eb3a14;
    uVar10 = FUN_0152d930(DAT_01eb3a10,DAT_01eb3a14);
    uStack_8._0_1_ = 0xf;
    uStack_48 = uVar10;
    (**(code **)(*param_2 + 0x14))(uStack_80,DAT_01d61fac == '\0',1,0,0);
    (**(code **)(*param_2 + 0x30))(0,*(int *)(iStack_20 + 0x40) + 0x54,0x350);
    uStack_1c = CONCAT22(uStack_1c._2_2_,0x101);
    uStack_18 = 0;
    uStack_14 = 0;
    (**(code **)(*param_2 + 0x34))(0,*puStack_40,&uStack_1c);
    param_8._1_2_ = 0;
    param_8._3_1_ = 0;
    uStack_18 = 0x1000100;
    uStack_1c = 0xf;
    uStack_14 = uStack_14 & 0xff00;
    FUN_0082a430(param_2,uStack_24,"PassThroughVS","CheapBokehFS",auStack_120,&uStack_1c,
                 (int)&param_8 + 1);
    (**(code **)(*param_2 + 0x18))();
    uStack_8._0_1_ = 0x10;
    FUN_0152dda0(iStack_28,param_7,uVar10);
    param_8._3_1_ = 1;
    uStack_8._0_1_ = 0x11;
    FUN_0152dda0(uStack_60,uStack_5c,uStack_88);
    uStack_8._0_1_ = 0x12;
    FUN_0152dda0(uStack_68,fStack_64,uStack_30);
    if (piStack_7c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_7c[1] + -1;
      piStack_7c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_7c)();
        LOCK();
        iVar4 = piStack_7c[2] + -1;
        piStack_7c[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_7c + 4))();
        }
      }
    }
    piVar7 = piStack_74;
    if (piStack_74 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_74[1] + -1;
      piStack_74[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_74)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar7 + 4))();
        }
      }
    }
  }
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      iVar4 = piStack_3c[2] + -1;
      piStack_3c[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar4 = param_4[1] + -1;
    param_4[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar4 = param_4[2] + -1;
      param_4[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  piVar7 = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar4 = param_6[1] + -1;
    param_6[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_8._3_1_;
}



/* FUNCTION 12476 ; VA 0x00816b90 ; FUN_00816b90 */

void __thiscall
FUN_00816b90(int param_1,undefined param_2,undefined4 param_3,undefined4 param_4,float param_5,
            float param_6)

{
  float fVar1;
  float fVar2;
  
  fVar1 = DAT_018f784c;
  *(undefined *)(param_1 + 0x58) = param_2;
  fVar2 = param_5 + param_6;
  if (param_5 + param_6 <= fVar1) {
    fVar2 = fVar1;
  }
  param_5 = param_5 - param_6;
  *(float *)(param_1 + 0x44) = fVar2;
  *(float *)(param_1 + 0x4c) = fVar2;
  if ((param_5 <= fVar1) || (fVar1 = param_5, fVar2 = DAT_01901960, param_5 <= DAT_01901960)) {
    fVar2 = fVar1;
  }
  *(undefined4 *)(param_1 + 0x50) = param_3;
  *(float *)(param_1 + 0x48) = fVar2;
  *(undefined4 *)(param_1 + 0x54) = param_4;
  return;
}



/* FUNCTION 12477 ; VA 0x00816c00 ; FUN_00816c00 */

void __thiscall FUN_00816c00(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *param_1 = *param_2;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  uVar1 = param_2[5];
  uVar2 = param_2[6];
  uVar3 = param_2[7];
  param_1[4] = param_2[4];
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  uVar1 = param_2[9];
  uVar2 = param_2[10];
  uVar3 = param_2[0xb];
  param_1[8] = param_2[8];
  param_1[9] = uVar1;
  param_1[10] = uVar2;
  param_1[0xb] = uVar3;
  uVar1 = param_2[0xd];
  uVar2 = param_2[0xe];
  uVar3 = param_2[0xf];
  param_1[0xc] = param_2[0xc];
  param_1[0xd] = uVar1;
  param_1[0xe] = uVar2;
  param_1[0xf] = uVar3;
  return;
}



/* FUNCTION 12478 ; VA 0x00816c30 ; FUN_00816c30 */

undefined4 * __fastcall FUN_00816c30(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  return param_1;
}



/* FUNCTION 12479 ; VA 0x00816c90 ; FUN_00816c90 */

void __fastcall FUN_00816c90(int param_1)

{
  FUN_017168b0(*(undefined4 *)(param_1 + 4));
  return;
}



/* FUNCTION 12480 ; VA 0x00816ca0 ; FUN_00816ca0 */

void __fastcall FUN_00816ca0(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = param_1[9];
  if (iVar1 != 0) {
    uVar3 = param_1[0xb] - iVar1 & 0xfffffffe;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00816d84;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[9] = 0;
    param_1[10] = 0;
    param_1[0xb] = 0;
  }
  FUN_00612d60();
  iVar1 = param_1[3];
  if (iVar1 != 0) {
    uVar3 = param_1[5] - iVar1;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00816d84;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[5] = 0;
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_00816d84:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 12481 ; VA 0x00816d90 ; FUN_00816d90 */

float10 FUN_00816d90(float param_1,float param_2)

{
  float fVar1;
  
  fVar1 = param_1 * DAT_01901d98 + DAT_01901d9c;
  if (param_2 <= fVar1) {
    fVar1 = param_2;
  }
  return (float10)fVar1;
}



/* FUNCTION 12482 ; VA 0x00816dc0 ; FUN_00816dc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00816dc0(float *param_1)

{
  uint *puVar1;
  float fVar2;
  float *pfVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  int iStack_8;
  
  iStack_8 = 0;
  pfVar3 = param_1 + 0x19;
  do {
    puVar1 = (uint *)FUN_007ccac0(iStack_8);
    fVar2 = 4.2039e-45;
    fVar4 = (float)(puVar1[1] ^ _UNK_018c4ea4);
    fVar5 = (float)(puVar1[2] ^ _UNK_018c4ea8);
    fVar6 = (float)(puVar1[3] ^ _UNK_018c4eac);
    *param_1 = (float)(*puVar1 ^ DAT_018c4ea0);
    param_1[1] = fVar4;
    param_1[2] = fVar5;
    param_1[3] = fVar6;
    if (0.0 < *param_1) {
      fVar2 = 0.0;
    }
    pfVar3[-1] = fVar2;
    fVar2 = 5.60519e-45;
    if (0.0 < param_1[1]) {
      fVar2 = 1.4013e-45;
    }
    *pfVar3 = fVar2;
    fVar2 = 7.00649e-45;
    if (0.0 < param_1[2]) {
      fVar2 = 2.8026e-45;
    }
    pfVar3[1] = fVar2;
    iStack_8 = iStack_8 + 1;
    param_1 = param_1 + 4;
    pfVar3 = pfVar3 + 3;
  } while (iStack_8 < 6);
  return;
}



/* FUNCTION 12483 ; VA 0x00816e60 ; FUN_00816e60 */

void __thiscall FUN_00816e60(int *param_1,int param_2)

{
  undefined4 *puVar1;
  undefined8 uVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  
  iVar3 = *(int *)(param_2 + 0x30);
  if (-1 < iVar3) {
    *(undefined4 *)(param_2 + 0x30) = 0xffffffff;
    iVar8 = param_1[1];
    iVar4 = *(int *)(iVar8 + -4);
    if (iVar4 != param_2) {
      *(int *)(iVar4 + 0x30) = iVar3;
      *(int *)(*param_1 + iVar3 * 4) = iVar4;
      *(undefined *)(iVar3 + param_1[3]) = *(undefined *)(param_1[4] + -1);
      iVar8 = param_1[7];
      uVar5 = *(undefined4 *)(iVar8 + -0x14);
      uVar6 = *(undefined4 *)(iVar8 + -0x10);
      uVar7 = *(undefined4 *)(iVar8 + -0xc);
      uVar2 = *(undefined8 *)(iVar8 + -8);
      iVar4 = param_1[6];
      puVar1 = (undefined4 *)(iVar4 + iVar3 * 0x18);
      *puVar1 = *(undefined4 *)(iVar8 + -0x18);
      puVar1[1] = uVar5;
      puVar1[2] = uVar6;
      puVar1[3] = uVar7;
      *(undefined8 *)(iVar4 + 0x10 + iVar3 * 0x18) = uVar2;
      *(undefined2 *)(param_1[9] + iVar3 * 2) = *(undefined2 *)(param_1[10] + -2);
      iVar8 = param_1[1];
    }
    param_1[1] = iVar8 + -4;
    param_1[4] = param_1[4] + -1;
    param_1[7] = param_1[7] + -0x18;
    param_1[10] = param_1[10] + -2;
  }
  return;
}



/* FUNCTION 12484 ; VA 0x00816ee0 ; FUN_00816ee0 */

void __thiscall FUN_00816ee0(int *param_1,int param_2)

{
  undefined4 *puVar1;
  undefined8 uVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  undefined *puVar6;
  undefined2 *puVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  uint auStack_20 [2];
  uint uStack_18;
  undefined auStack_12 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b5bd8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar11 = FUN_01675290(DAT_01eb3a5c);
  uStack_8 = 0;
  auStack_20[0] = 0xffff;
  if ((int)*(uint *)(param_2 + 0x10) < 0x10000) {
    auStack_20[0] = *(uint *)(param_2 + 0x10) & 0xffff;
  }
  uStack_18 = auStack_20[0];
  if (*(int *)(param_2 + 0x30) < 0) {
    *(int *)(param_2 + 0x30) = param_1[1] - *param_1 >> 2;
    piVar5 = (int *)param_1[1];
    if ((int *)param_1[2] == piVar5) {
      FUN_0063d9b0(piVar5,&param_2);
    }
    else {
      *piVar5 = param_2;
      param_1[1] = param_1[1] + 4;
    }
    auStack_12[0] = *(undefined *)(param_2 + 0xc);
    puVar6 = (undefined *)param_1[4];
    if ((undefined *)param_1[5] == puVar6) {
      FUN_007d7340(puVar6,auStack_12);
    }
    else {
      *puVar6 = *(undefined *)(param_2 + 0xc);
      param_1[4] = param_1[4] + 1;
    }
    puVar1 = (undefined4 *)param_1[7];
    if ((undefined4 *)param_1[8] == puVar1) {
      FUN_00603350(puVar1,(undefined4 *)(param_2 + 0x18));
    }
    else {
      uVar8 = *(undefined4 *)(param_2 + 0x1c);
      uVar9 = *(undefined4 *)(param_2 + 0x20);
      uVar10 = *(undefined4 *)(param_2 + 0x24);
      *puVar1 = *(undefined4 *)(param_2 + 0x18);
      puVar1[1] = uVar8;
      puVar1[2] = uVar9;
      puVar1[3] = uVar10;
      *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(param_2 + 0x28);
      param_1[7] = param_1[7] + 0x18;
    }
    puVar7 = (undefined2 *)param_1[10];
    if ((undefined2 *)param_1[0xb] == puVar7) {
      FUN_00725750(puVar7,auStack_20);
    }
    else {
      *puVar7 = (short)uStack_18;
      param_1[10] = param_1[10] + 2;
    }
  }
  else {
    *(undefined *)(*(int *)(param_2 + 0x30) + param_1[3]) = *(undefined *)(param_2 + 0xc);
    iVar3 = *(int *)(param_2 + 0x30);
    uVar8 = *(undefined4 *)(param_2 + 0x1c);
    uVar9 = *(undefined4 *)(param_2 + 0x20);
    uVar10 = *(undefined4 *)(param_2 + 0x24);
    uVar2 = *(undefined8 *)(param_2 + 0x28);
    iVar4 = param_1[6];
    puVar1 = (undefined4 *)(iVar4 + iVar3 * 0x18);
    *puVar1 = *(undefined4 *)(param_2 + 0x18);
    puVar1[1] = uVar8;
    puVar1[2] = uVar9;
    puVar1[3] = uVar10;
    *(undefined8 *)(iVar4 + 0x10 + iVar3 * 0x18) = uVar2;
    *(short *)(param_1[9] + *(int *)(param_2 + 0x30) * 2) = (short)auStack_20[0];
  }
  uStack_8 = 1;
  FUN_01675290(uVar11);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12485 ; VA 0x00817040 ; FUN_00817040 */

int FUN_00817040(float *param_1,int param_2)

{
  uint3 uVar1;
  int iVar2;
  float *pfVar3;
  
  iVar2 = 0;
  pfVar3 = param_1 + 0x19;
  do {
    uVar1 = (uint3)((uint)pfVar3[1] >> 8);
    if (0.0 < *(float *)(param_2 + (int)pfVar3[-1] * 4) * *param_1 +
              *(float *)(param_2 + (int)*pfVar3 * 4) * param_1[1] +
              *(float *)(param_2 + (int)pfVar3[1] * 4) * param_1[2] + param_1[3]) {
      return (uint)uVar1 << 8;
    }
    iVar2 = iVar2 + 1;
    pfVar3 = pfVar3 + 3;
    param_1 = param_1 + 4;
  } while (iVar2 < 6);
  return CONCAT31(uVar1,1);
}



/* FUNCTION 12486 ; VA 0x008170c0 ; FUN_008170c0 */

void __thiscall FUN_008170c0(int *param_1,int param_2,float *param_3,uint param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  float *pfVar6;
  uint uVar7;
  undefined8 uVar8;
  int iStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b5c04;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb3aa8) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb3aa8), DAT_01eb3aa8 == -1)) {
    uStack_8 = 0;
    uVar8 = FUN_0152dab0("Render","queryExtents",0xffffffff);
    DAT_01eb3aa4 = (undefined4)((ulonglong)uVar8 >> 0x20);
    DAT_01eb3aa0 = (undefined4)uVar8;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb3aa8);
  }
  uVar4 = DAT_01eb3aa4;
  uVar3 = DAT_01eb3aa0;
  uVar8 = FUN_0152d930(DAT_01eb3aa0,DAT_01eb3aa4);
  uVar7 = 0;
  uStack_8 = 1;
  uVar5 = param_1[1] - *param_1 >> 2;
  if (uVar5 != 0) {
    iStack_18 = 0;
    do {
      if (((((*(byte *)(param_1[3] + uVar7) & param_4) == param_4) &&
           (pfVar6 = (float *)(param_1[6] + iStack_18),
           *param_3 < pfVar6[3] || *param_3 == pfVar6[3])) &&
          (param_3[1] < pfVar6[4] || param_3[1] == pfVar6[4])) &&
         (((param_3[2] < pfVar6[5] || param_3[2] == pfVar6[5] &&
           (pfVar6[1] < param_3[4] || pfVar6[1] == param_3[4])) &&
          ((*pfVar6 < param_3[3] || *pfVar6 == param_3[3] &&
           (pfVar6[2] < param_3[5] || pfVar6[2] == param_3[5])))))) {
        puVar2 = *(undefined4 **)(param_2 + 4);
        puVar1 = (undefined4 *)(*param_1 + uVar7 * 4);
        if (*(undefined4 **)(param_2 + 8) == puVar2) {
          FUN_0063d9b0(puVar2,puVar1);
        }
        else {
          *puVar2 = *puVar1;
          *(int *)(param_2 + 4) = *(int *)(param_2 + 4) + 4;
        }
      }
      uVar7 = uVar7 + 1;
      iStack_18 = iStack_18 + 0x18;
    } while (uVar7 < uVar5);
  }
  uStack_8 = 2;
  FUN_0152dda0(uVar3,uVar4,uVar8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12487 ; VA 0x00817260 ; FUN_00817260 */

void __thiscall FUN_00817260(int *param_1,int param_2,undefined4 param_3,uint param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  undefined8 uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b5c24;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb3a88) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb3a88), DAT_01eb3a88 == -1)) {
    uStack_8 = 0;
    uVar9 = FUN_0152dab0("Render","queryFrustum",0xffffffff);
    DAT_01eb3a84 = (undefined4)((ulonglong)uVar9 >> 0x20);
    DAT_01eb3a80 = (undefined4)uVar9;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb3a88);
  }
  uVar4 = DAT_01eb3a84;
  uVar3 = DAT_01eb3a80;
  uVar9 = FUN_0152d930(DAT_01eb3a80,DAT_01eb3a84);
  uVar8 = 0;
  uStack_8 = 1;
  uVar6 = param_1[1] - *param_1 >> 2;
  if (uVar6 != 0) {
    iVar7 = 0;
    do {
      if (((*(byte *)(param_1[3] + uVar8) & param_4) == param_4) &&
         (cVar5 = FUN_007ccd20(param_1[6] + iVar7), cVar5 != '\0')) {
        puVar2 = *(undefined4 **)(param_2 + 4);
        puVar1 = (undefined4 *)(*param_1 + uVar8 * 4);
        if (*(undefined4 **)(param_2 + 8) == puVar2) {
          FUN_0063d9b0(puVar2,puVar1);
        }
        else {
          *puVar2 = *puVar1;
          *(int *)(param_2 + 4) = *(int *)(param_2 + 4) + 4;
        }
      }
      uVar8 = uVar8 + 1;
      iVar7 = iVar7 + 0x18;
    } while (uVar8 < uVar6);
  }
  uStack_8 = 2;
  FUN_0152dda0(uVar3,uVar4,uVar9);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12488 ; VA 0x008173d0 ; FUN_008173d0 */

void __thiscall
FUN_008173d0(int *param_1,int param_2,undefined4 param_3,float *param_4,float param_5,float param_6,
            int param_7)

{
  undefined4 *puVar1;
  byte bVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  int iVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  undefined8 uVar14;
  undefined auStack_10c [172];
  int iStack_60;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined8 uStack_4c;
  undefined4 uStack_44;
  undefined4 uStack_40;
  uint uStack_3c;
  uint uStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b5c5c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb3a78) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb3a78), DAT_01eb3a78 == -1)) {
    uStack_8 = 0;
    uVar14 = FUN_0152dab0("Render","queryFrustumOrdered",0xffffffff);
    DAT_01eb3a74 = (undefined4)((ulonglong)uVar14 >> 0x20);
    DAT_01eb3a70 = (undefined4)uVar14;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb3a78);
  }
  uStack_44 = DAT_01eb3a70;
  uStack_54 = DAT_01eb3a70;
  uStack_40 = DAT_01eb3a74;
  uStack_50 = DAT_01eb3a74;
  uStack_4c = FUN_0152d930(DAT_01eb3a70,DAT_01eb3a74);
  uStack_8 = 1;
  iVar8 = 6;
  do {
    FUN_0060f2c0();
    iVar8 = iVar8 + -1;
  } while (iVar8 != 0);
  FUN_00816dc0(auStack_10c,param_3);
  uVar7 = param_1[1] - *piStack_18 >> 2;
  uStack_24 = uVar7;
  if (uVar7 != 0) {
    uStack_8._0_1_ = 3;
    iStack_30 = iVar8;
    iStack_2c = iVar8;
    iStack_28 = iVar8;
    FUN_005f86c0(uVar7,&iStack_30);
    uStack_38 = uVar7;
    iStack_34 = FUN_0171e1f2((uVar7 + 0x1f >> 5) << 2);
    uStack_8._0_1_ = 4;
    uStack_20 = 0;
    iStack_14 = 0;
    uStack_1c = 0;
    iVar8 = 0;
    if (uVar7 != 0) {
      fVar13 = 0.0;
      uStack_3c = 1;
      fVar10 = param_6;
      do {
        uVar7 = uStack_20;
        fVar11 = *(float *)(piStack_18[6] + uStack_1c * 0x18);
        iVar3 = piStack_18[6] + uStack_1c * 0x18;
        fVar9 = *param_4;
        fVar12 = fVar13;
        if (fVar9 < fVar11) {
          fVar11 = fVar11 - fVar9;
          fVar12 = fVar11 * fVar11 + fVar13;
        }
        if (*(float *)(iVar3 + 0xc) < fVar9) {
          fVar9 = fVar9 - *(float *)(iVar3 + 0xc);
          fVar12 = fVar12 + fVar9 * fVar9;
        }
        fVar11 = param_4[1];
        if (fVar11 < *(float *)(iVar3 + 4)) {
          fVar9 = *(float *)(iVar3 + 4) - fVar11;
          fVar12 = fVar12 + fVar9 * fVar9;
        }
        if (*(float *)(iVar3 + 0x10) < fVar11) {
          fVar11 = fVar11 - *(float *)(iVar3 + 0x10);
          fVar12 = fVar12 + fVar11 * fVar11;
        }
        fVar11 = param_4[2];
        if (fVar11 < *(float *)(iVar3 + 8)) {
          fVar9 = *(float *)(iVar3 + 8) - fVar11;
          fVar12 = fVar12 + fVar9 * fVar9;
        }
        if (*(float *)(iVar3 + 0x14) < fVar11) {
          fVar11 = fVar11 - *(float *)(iVar3 + 0x14);
          fVar12 = fVar12 + fVar11 * fVar11;
        }
        bVar2 = FUN_00817040(auStack_10c,iVar3);
        uVar5 = (uint)*(ushort *)(piStack_18[9] + uStack_1c * 2);
        if (fVar10 <= fVar12) {
LAB_008175be:
          if (bVar2 != 0) {
            fVar11 = (float)piStack_18[0xc];
            if (fVar12 < (float)piStack_18[0xc]) {
              fVar11 = fVar12;
            }
            piStack_18[0xc] = (int)fVar11;
          }
        }
        else {
          iStack_14 = iStack_14 + uVar5;
          uStack_20 = uVar7 + 1;
          if (bVar2 != 0) {
            iVar8 = iVar8 + uVar5;
            goto LAB_008175be;
          }
        }
        *(float *)(iStack_30 + uStack_1c * 4) = fVar12;
        *(uint *)(iStack_34 + (uStack_1c >> 5) * 4) =
             -(uint)bVar2 & uStack_3c | ~uStack_3c & *(uint *)(iStack_34 + (uStack_1c >> 5) * 4);
        uStack_1c = uStack_1c + 1;
        uStack_3c = uStack_3c << 1 | (uint)((int)uStack_3c < 0);
        uVar7 = uStack_24;
      } while (uStack_1c < uStack_24);
    }
    uVar5 = uStack_20;
    if (((uStack_20 < uVar7) && (iStack_14 < param_7 * 4)) && (iVar8 < param_7)) {
      FUN_008650c0(uVar7);
      uStack_8._0_1_ = 5;
      FUN_00865140(iStack_30,iStack_2c - iStack_30 >> 2);
      while( true ) {
        uVar7 = *(uint *)(iStack_60 + uVar5 * 4);
        uVar5 = (uint)*(ushort *)(piStack_18[9] + uVar7 * 2);
        iStack_14 = iStack_14 + uVar5;
        iVar3 = uVar5 + iVar8;
        if ((*(uint *)(iStack_34 + (uVar7 >> 5) * 4) & 1 << ((byte)uVar7 & 0x1f)) == 0) {
          iVar3 = iVar8;
        }
        if (((param_7 * 4 <= iStack_14) || (param_7 <= iVar3)) || (uStack_20 == uStack_24 - 1))
        break;
        uVar5 = uStack_20 + 1;
        iVar8 = iVar3;
        uStack_20 = uVar5;
      }
      uStack_8._0_1_ = 4;
      param_6 = *(float *)(iStack_30 + uVar7 * 4);
      FUN_00865120();
      uVar7 = uStack_24;
    }
    uVar5 = 0;
    piStack_18[0xd] = (int)param_6;
    fVar10 = param_6 * DAT_01901d98 + DAT_01901d9c;
    if (param_5 <= fVar10) {
      fVar10 = param_5;
    }
    if (uVar7 != 0) {
      uVar7 = 1;
      iVar8 = iStack_34;
      piVar6 = piStack_18;
      do {
        if ((*(uint *)(iVar8 + (uVar5 >> 5) * 4) & uVar7) != 0) {
          fVar13 = *(float *)(iStack_30 + uVar5 * 4);
          iVar8 = iStack_34;
          if (fVar13 < fVar10) {
            puVar4 = (undefined4 *)(*piVar6 + uVar5 * 4);
            puVar1 = *(undefined4 **)(param_2 + 4);
            if (*(undefined4 **)(param_2 + 8) == puVar1) {
              FUN_0063d9b0(puVar1,puVar4);
              piVar6 = piStack_18;
            }
            else {
              *puVar1 = *puVar4;
              *(int *)(param_2 + 4) = *(int *)(param_2 + 4) + 4;
            }
            *(float *)(*(int *)(*piVar6 + uVar5 * 4) + 0x14) = fVar13;
            iVar8 = iStack_34;
          }
        }
        uVar5 = uVar5 + 1;
        uVar7 = uVar7 << 1 | (uint)((int)uVar7 < 0);
      } while (uVar5 < uStack_24);
    }
    FUN_017168b0(iStack_34);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (iStack_30 != 0) {
      uVar7 = (iStack_28 - iStack_30 >> 2) * 4;
      iVar8 = iStack_30;
      if (0xfff < uVar7) {
        iVar8 = *(int *)(iStack_30 + -4);
        uVar7 = uVar7 + 0x23;
        if (0x1f < (iStack_30 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar8,uVar7);
      iStack_30 = 0;
      iStack_2c = 0;
      iStack_28 = 0;
    }
  }
  uStack_8 = 6;
  FUN_0152dda0(uStack_44,uStack_40,uStack_4c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12489 ; VA 0x00817870 ; FUN_00817870 */

void FUN_00817870(int *param_1,float *param_2,float *param_3,float param_4)

{
  undefined uVar1;
  int iVar2;
  float *pfVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  undefined4 *puVar7;
  float *pfVar8;
  float *pfVar9;
  undefined4 *puVar10;
  float fVar11;
  float fVar12;
  undefined8 uVar13;
  float afStack_11c [25];
  int aiStack_b8 [18];
  int *piStack_70;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined8 uStack_5c;
  undefined4 uStack_54;
  undefined4 uStack_50;
  int iStack_4c;
  int iStack_48;
  float *pfStack_44;
  float *pfStack_40;
  float *pfStack_3c;
  undefined4 *puStack_38;
  undefined4 *puStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined4 *puStack_28;
  float *pfStack_24;
  int *piStack_20;
  float *pfStack_1c;
  undefined4 *puStack_18;
  float *pfStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b5c9c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb3a68) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb3a68), DAT_01eb3a68 == -1)) {
    uStack_8 = 0;
    uVar13 = FUN_0152dab0("Render","queryFrustumOrdered",0xffffffff);
    DAT_01eb3a64 = (undefined4)((ulonglong)uVar13 >> 0x20);
    DAT_01eb3a60 = (undefined4)uVar13;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb3a68);
  }
  uStack_54 = DAT_01eb3a60;
  uStack_64 = DAT_01eb3a60;
  uStack_50 = DAT_01eb3a64;
  uStack_60 = DAT_01eb3a64;
  uStack_5c = FUN_0152d930(DAT_01eb3a60,DAT_01eb3a64);
  uStack_8 = 1;
  puVar10 = (undefined4 *)&DAT_00000006;
  do {
    FUN_0060f2c0();
    puVar10 = (undefined4 *)((int)puVar10 + -1);
  } while (puVar10 != (undefined4 *)0x0);
  FUN_00816dc0(afStack_11c,param_2);
  puStack_18 = puVar10;
  puStack_38 = puVar10;
  uVar5 = piStack_20[1] - *piStack_20 >> 2;
  uStack_30 = uVar5;
  pfStack_14 = (float *)0x0;
  pfStack_3c = (float *)0x0;
  puStack_28 = (undefined4 *)0x0;
  puStack_34 = (undefined4 *)0x0;
  uStack_8._0_1_ = 2;
  if (uVar5 != 0) {
    if (0x3fffffff < uVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_007cfd20(uVar5);
    puStack_28 = puStack_34;
    puStack_18 = puStack_38;
    pfStack_14 = pfStack_3c;
  }
  puVar10 = puStack_38;
  iStack_48 = 0;
  pfStack_1c = (float *)0x0;
  pfStack_44 = (float *)0x0;
  pfStack_24 = (float *)0x0;
  pfStack_40 = (float *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  pfStack_3c = pfStack_14;
  puStack_34 = puStack_28;
  puStack_18 = puStack_38;
  if (uVar5 != 0) {
    if (0x3fffffff < uVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_007cfd20(uVar5);
    pfStack_24 = pfStack_40;
    pfStack_1c = pfStack_44;
  }
  uStack_2c = 0;
  pfStack_44 = pfStack_1c;
  pfStack_40 = pfStack_24;
  if (uVar5 != 0) {
    iStack_4c = 0;
    do {
      pfVar8 = afStack_11c;
      piVar4 = aiStack_b8;
      pfStack_14 = (float *)(piStack_20[6] + iStack_4c);
      iVar2 = 0;
      do {
        puVar10 = puStack_18;
        if (0.0 < pfStack_14[piVar4[-1]] * *pfVar8 + pfStack_14[*piVar4] * pfVar8[1] +
                  pfStack_14[piVar4[1]] * pfVar8[2] + pfVar8[3]) goto LAB_00817b6e;
        iVar2 = iVar2 + 1;
        piVar4 = piVar4 + 3;
        pfVar8 = pfVar8 + 4;
      } while (iVar2 < 6);
      param_2 = (float *)0x0;
      fVar12 = *param_3;
      if (fVar12 < *pfStack_14) {
        fVar11 = *pfStack_14 - fVar12;
        param_2 = (float *)(fVar11 * fVar11 + 0.0);
      }
      if (pfStack_14[3] < fVar12) {
        fVar12 = fVar12 - pfStack_14[3];
        param_2 = (float *)((float)param_2 + fVar12 * fVar12);
      }
      fVar12 = param_3[1];
      if (fVar12 < pfStack_14[1]) {
        fVar11 = pfStack_14[1] - fVar12;
        param_2 = (float *)((float)param_2 + fVar11 * fVar11);
      }
      if (pfStack_14[4] < fVar12) {
        fVar12 = fVar12 - pfStack_14[4];
        param_2 = (float *)((float)param_2 + fVar12 * fVar12);
      }
      fVar12 = param_3[2];
      if (fVar12 < pfStack_14[2]) {
        fVar11 = pfStack_14[2] - fVar12;
        param_2 = (float *)((float)param_2 + fVar11 * fVar11);
      }
      if (pfStack_14[5] < fVar12) {
        fVar12 = fVar12 - pfStack_14[5];
        param_2 = (float *)((float)param_2 + fVar12 * fVar12);
      }
      if ((float)param_2 <= param_4) {
        puVar10 = (undefined4 *)(*piStack_20 + uStack_2c * 4);
        pfStack_14 = param_2;
        if (puStack_28 == puStack_18) {
          FUN_0063d9b0(puStack_18,puVar10);
          puStack_28 = puStack_34;
        }
        else {
          *puStack_18 = *puVar10;
          puStack_38 = puStack_18 + 1;
        }
        puVar10 = puStack_38;
        puStack_18 = puStack_38;
        if (pfStack_24 == pfStack_1c) {
          FUN_007d74c0(pfStack_1c,&pfStack_14);
          pfStack_24 = pfStack_40;
        }
        else {
          *pfStack_1c = (float)param_2;
          pfStack_44 = pfStack_1c + 1;
        }
        pfStack_1c = pfStack_44;
      }
LAB_00817b6e:
      uStack_2c = uStack_2c + 1;
      iStack_4c = iStack_4c + 0x18;
    } while (uStack_2c < uStack_30);
    pfStack_14 = pfStack_3c;
  }
  iVar2 = iStack_48;
  iVar6 = (int)pfStack_1c - iStack_48 >> 2;
  FUN_008650c0(iVar6);
  uStack_8._0_1_ = 4;
  FUN_00865140(iVar2,iVar6);
  pfVar8 = pfStack_14;
  puVar10 = (undefined4 *)((int)puVar10 - (int)pfStack_14 >> 2);
  puStack_18 = puVar10;
  FUN_005f86c0(puVar10,param_1);
  uVar5 = 0;
  if (puVar10 != (undefined4 *)0x0) {
    do {
      *(float *)(*param_1 + uVar5 * 4) = pfVar8[piStack_70[uVar5]];
      uVar5 = uVar5 + 1;
    } while (uVar5 < puVar10);
  }
  uVar5 = 0;
  pfVar9 = pfVar8;
  if (3 < puVar10) {
    iVar6 = ((int)puVar10 - 4U >> 2) + 1;
    uVar5 = iVar6 * 4;
    pfVar3 = pfVar8 + 1;
    puVar7 = (undefined4 *)(iVar2 + 0xc);
    do {
      *(undefined4 *)((int)pfVar3[-1] + 0x14) = puVar7[-3];
      *(undefined4 *)((int)*pfVar3 + 0x14) =
           *(undefined4 *)((iVar2 - (int)pfVar8) + -0x10 + (int)(pfVar3 + 4));
      *(undefined4 *)((int)pfVar3[1] + 0x14) = puVar7[-1];
      *(undefined4 *)((int)pfVar3[2] + 0x14) = *puVar7;
      iVar6 = iVar6 + -1;
      pfVar3 = pfVar3 + 4;
      pfVar9 = pfStack_14;
      puVar7 = puVar7 + 4;
      puVar10 = puStack_18;
      uStack_30 = uVar5;
    } while (iVar6 != 0);
  }
  pfVar8 = pfVar9;
  if (uVar5 < puVar10) {
    iVar6 = (int)puVar10 - uVar5;
    pfVar3 = pfVar9 + uVar5;
    do {
      *(undefined4 *)((int)*pfVar3 + 0x14) = *(undefined4 *)((int)pfVar3 + (iVar2 - (int)pfVar9));
      iVar6 = iVar6 + -1;
      pfVar3 = pfVar3 + 1;
      pfVar8 = pfStack_14;
    } while (iVar6 != 0);
  }
  iVar6 = DAT_018c45c4;
  if (puVar10 != (undefined4 *)0x0) {
    iVar6 = *(int *)(iVar2 + *piStack_70 * 4);
  }
  piStack_20[0xc] = iVar6;
  FUN_00865120();
  uStack_8._0_1_ = 2;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (iVar2 != 0) {
    uVar5 = ((int)pfStack_24 - iVar2 >> 2) * 4;
    iVar6 = iVar2;
    if (0xfff < uVar5) {
      iVar6 = *(int *)(iVar2 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar2 - iVar6) - 4U) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar5);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (pfVar8 != (float *)0x0) {
    uVar5 = ((int)puStack_28 - (int)pfVar8 >> 2) * 4;
    pfVar9 = pfVar8;
    if (0xfff < uVar5) {
      pfVar9 = (float *)pfVar8[-1];
      uVar5 = uVar5 + 0x23;
      if (0x1f < (uint)((int)pfVar8 + (-4 - (int)pfVar9))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pfVar9,uVar5);
  }
  uStack_8 = 5;
  FUN_0152dda0(uStack_54,uStack_50,uStack_5c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12490 ; VA 0x00817dd0 ; FUN_00817dd0 */

void __thiscall FUN_00817dd0(int *param_1,int param_2,undefined4 param_3,float param_4,uint param_5)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  float10 fVar7;
  undefined8 uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b5cc4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eb3a98) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eb3a98), DAT_01eb3a98 == -1)) {
    uStack_8 = 0;
    uVar8 = FUN_0152dab0("Render","querySphere",0xffffffff);
    DAT_01eb3a94 = (undefined4)((ulonglong)uVar8 >> 0x20);
    DAT_01eb3a90 = (undefined4)uVar8;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eb3a98);
  }
  uVar4 = DAT_01eb3a94;
  uVar3 = DAT_01eb3a90;
  uVar8 = FUN_0152d930(DAT_01eb3a90,DAT_01eb3a94);
  uVar6 = 0;
  uStack_8 = 1;
  uVar5 = param_1[1] - *param_1 >> 2;
  if (uVar5 != 0) {
    do {
      if (((*(byte *)(param_1[3] + uVar6) & param_5) == param_5) &&
         (fVar7 = (float10)FUN_00c9ed90(param_3), (float)fVar7 <= param_4 * param_4)) {
        puVar2 = *(undefined4 **)(param_2 + 4);
        puVar1 = (undefined4 *)(*param_1 + uVar6 * 4);
        if (*(undefined4 **)(param_2 + 8) == puVar2) {
          FUN_0063d9b0(puVar2,puVar1);
        }
        else {
          *puVar2 = *puVar1;
          *(int *)(param_2 + 4) = *(int *)(param_2 + 4) + 4;
        }
      }
      uVar6 = uVar6 + 1;
    } while (uVar6 < uVar5);
  }
  uStack_8 = 2;
  FUN_0152dda0(uVar3,uVar4,uVar8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12491 ; VA 0x00817f60 ; FUN_00817f60 */

int FUN_00817f60(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00d5e4a0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 12492 ; VA 0x00817fa0 ; FUN_00817fa0 */

int __fastcall FUN_00817fa0(int param_1)

{
  int iVar1;
  int iVar2;
  
  do {
    param_1 = *(int *)(param_1 + 0x34);
    if (param_1 == 0) {
      return 0;
    }
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00d5e4a0();
  } while ((uint)*(ushort *)(iVar2 + 0x1da) <
           (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8));
  return param_1;
}



/* FUNCTION 12493 ; VA 0x00817fe0 ; FUN_00817fe0 */

void FUN_00817fe0(undefined4 *param_1,int *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  
  if (param_2 != param_3) {
    do {
      if (*param_2 == *param_4) break;
      param_2 = param_2 + 1;
    } while (param_2 != param_3);
    if (param_2 != param_3) {
      piVar1 = param_2 + 1;
      uVar2 = 0;
      uVar3 = (uint)((int)param_3 + (3 - (int)piVar1)) >> 2;
      if (param_3 < piVar1) {
        uVar3 = 0;
      }
      if (uVar3 != 0) {
        do {
          if (*piVar1 != *param_4) {
            *param_2 = *piVar1;
            param_2 = param_2 + 1;
          }
          uVar2 = uVar2 + 1;
          piVar1 = piVar1 + 1;
        } while (uVar2 != uVar3);
      }
      *param_1 = param_2;
      return;
    }
  }
  *param_1 = param_2;
  return;
}



/* FUNCTION 12494 ; VA 0x00818050 ; FUN_00818050 */

void * __thiscall FUN_00818050(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  int *piVar5;
  int *piVar6;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined4 *puStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017b5ce8;
  puStack_28 = *(undefined4 **)(param_1 + 0x2c);
  pvVar4 = ExceptionList;
  if (puStack_28 != (undefined4 *)0x0) {
    piStack_24 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piStack_24[1] = piStack_24[1] + 1;
      UNLOCK();
      piStack_24 = *(int **)(param_1 + 0x30);
      puStack_28 = *(undefined4 **)(param_1 + 0x2c);
    }
    piVar1 = (int *)puStack_28[1];
    piVar6 = (int *)*puStack_28;
    iStack_8 = 0;
    piVar5 = piStack_24;
    for (; piStack_14 = piVar5, piVar6 != piVar1; piVar6 = piVar6 + 2) {
      piVar5 = (int *)piVar6[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
        piVar5 = (int *)piVar6[1];
      }
      iStack_20 = *piVar6;
      iStack_8._1_3_ = (uint3)((uint)iStack_8 >> 8);
      iStack_8._0_1_ = 1;
      piStack_1c = piVar5;
      if (iStack_20 != 0) {
        piStack_18 = *(int **)(iStack_20 + 0xc);
        iVar2 = FUN_00aff8c0();
        if ((uint)*(ushort *)(piStack_18 + 0x76) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
            (uint)*(ushort *)(iVar2 + 0x1da)) {
          FUN_00c3e2a0();
          piStack_18 = *(int **)(*(int *)(*param_2 + 0x2c) + 0x4e4);
          uVar3 = FUN_0060dcd0(auStack_30,iStack_20);
          iStack_8._0_1_ = 2;
          FUN_007c8e00(uVar3);
          piStack_18 = piStack_2c;
          if (piStack_2c != (int *)0x0) {
            LOCK();
            iVar2 = piStack_2c[1] + -1;
            piStack_2c[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piStack_2c)();
              LOCK();
              iVar2 = piStack_18[2] + -1;
              piStack_18[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piStack_18 + 4))();
              }
            }
          }
        }
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar2 = piVar5[1] + -1;
        piVar5[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar2 = piVar5[2] + -1;
          piVar5[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      FUN_00818050(param_2);
      piVar5 = piStack_14;
    }
    pvVar4 = (void *)0xffffffff;
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar1 = piVar5 + 1;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        pvVar4 = (void *)(iVar2 + -1);
        if (pvVar4 == (void *)0x0) {
          pvVar4 = (void *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 12495 ; VA 0x008181e0 ; FUN_008181e0 */

undefined4 * __thiscall FUN_008181e0(undefined4 *param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined uVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  uint auStack_40 [2];
  code *pcStack_38;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  uint uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar5 = (int)param_2;
  puStack_c = &LAB_017b5ddf;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::ISuperCluster::vftable;
  uStack_8 = 0;
  puStack_14 = param_1;
  FUN_0147cac0(*(undefined4 *)((int)param_2 + 0x3c));
  param_1[1] = RBX::Graphics::GuiCluster::vftable;
  *puStack_14 = RBX::Graphics::GuiCluster::vftable;
  puStack_14[0xb] = iVar5;
  puStack_14[0xc] = 0;
  puStack_14[0xd] = 0;
  puStack_14[0xe] = 0;
  puStack_14[0xf] = 0;
  puStack_14[0x10] = 0;
  puStack_14[0x11] = 0;
  puStack_14[0x12] = 0;
  puStack_14[0x13] = 0;
  puStack_14[0x14] = 0;
  puStack_14[0x15] = 0;
  uStack_8._0_1_ = 3;
  FUN_0060dcd0(puStack_14 + 0x16,param_3);
  puVar8 = puStack_14 + 0x18;
  uStack_8._0_1_ = 4;
  *puVar8 = 0;
  puStack_14[0x19] = 0;
  param_2 = puVar8;
  uVar4 = FUN_00601dc0();
  puVar9 = puStack_14;
  *puVar8 = uVar4;
  puStack_14[0x1a] = 0;
  puStack_14[0x1b] = 0;
  puStack_14[0x1c] = 0;
  uStack_8._0_1_ = 6;
  *(undefined *)(puStack_14 + 0x1d) = 1;
  *(undefined2 *)((int)puStack_14 + 0x76) = 0x100;
  puStack_14[0x1f] = 0xffffffff;
  FUN_007cc9d0();
  puVar9[0xb1] = 0;
  puVar9[0xb2] = 0;
  puVar9[0xb3] = 0;
  puVar9[0xb4] = 0;
  puVar9[0xb5] = 0x3f800000;
  puVar9[0xb6] = 0;
  puVar9[0xb7] = 0;
  puVar9[0xb8] = 0;
  puVar9[0xb9] = 0;
  puVar9[0xba] = 0;
  puVar9[0xbb] = 0;
  puVar9[0xbc] = 0;
  puVar9[0xbd] = 0;
  puVar9[0xbe] = 0;
  puVar9[0xbf] = 0;
  puVar9[0xc0] = 0;
  puVar9[0xc1] = 0;
  puVar9[0xc2] = 0;
  puVar9[0xc3] = 0;
  puVar9[0xc4] = 0;
  uStack_8._0_1_ = 9;
  puVar9[0xc5] = 1;
  puStack_30 = (undefined4 *)0x0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0("GuiCluster",10);
  uStack_8._0_1_ = 10;
  FUN_0147cd70(auStack_40);
  uStack_8._0_1_ = 9;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 9;
  if (0xf < uStack_2c) {
    uVar7 = uStack_2c + 1;
    uVar6 = auStack_40[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_40[0] - 4);
      uVar7 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar6) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  pcStack_38 = FUN_00819330;
  *(undefined2 *)((int)puVar9 + 0x36) = 6;
  *(undefined2 *)((int)puVar9 + 0x3e) = 4;
  param_2 = (undefined4 *)((int)param_3 + 0x50);
  uStack_34 = 0;
  puStack_30 = puVar9;
  uStack_8._0_1_ = 0xb;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 0xc;
  piStack_24 = (int *)uVar4;
  puStack_1c = (undefined4 *)FUN_01674e20(0x28);
  if (puStack_1c == (undefined4 *)0x0) {
    puVar9 = (undefined4 *)0x0;
  }
  else {
    *puStack_1c = 0;
    puStack_1c[1] = 1;
    puStack_1c[2] = FUN_00819150;
    puStack_1c[3] = _guard_check_icall;
    puStack_1c[4] = 0;
    puStack_1c[5] = param_2;
    puStack_1c[6] = pcStack_38;
    puStack_1c[7] = uStack_34;
    puStack_1c[8] = puStack_30;
    puStack_1c[9] = uStack_2c;
    puVar9 = puStack_1c;
  }
  FUN_016797d0(puVar9);
  if (puVar9 != (undefined4 *)0x0) {
    LOCK();
    puVar9[1] = puVar9[1] + 1;
    UNLOCK();
  }
  uStack_18 = 1;
  uStack_8._0_1_ = 0xd;
  puStack_1c = puVar9;
  FUN_01675290(uVar4);
  puVar2 = puStack_14;
  puVar8 = (undefined4 *)puStack_14[0x1b];
  uStack_8._0_1_ = 0xb;
  if ((undefined4 *)puStack_14[0x1c] == puVar8) {
    FUN_006335f0(puVar8,&puStack_1c);
    puVar9 = puStack_1c;
  }
  else {
    *puVar8 = puVar9;
    puStack_14[0x1b] = puStack_14[0x1b] + 4;
    puVar9 = (undefined4 *)0x0;
  }
  uStack_18 = 0;
  uStack_8._0_1_ = 9;
  if (puVar9 != (undefined4 *)0x0) {
    piVar1 = puVar9 + 1;
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(puVar9);
    }
  }
  puStack_20 = puVar2;
  FUN_00818050(&puStack_20);
  iVar5 = FUN_008a4100();
  param_2 = (undefined4 *)(iVar5 + 0x10);
  uStack_8._0_1_ = 0xe;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 0xf;
  piStack_24 = (int *)uVar4;
  puStack_1c = (undefined4 *)FUN_01674e20(0x1c);
  if (puStack_1c == (undefined4 *)0x0) {
    puVar9 = (undefined4 *)0x0;
  }
  else {
    *puStack_1c = 0;
    puStack_1c[1] = 1;
    puStack_1c[2] = FUN_00818fe0;
    puStack_1c[3] = _guard_check_icall;
    puStack_1c[4] = 0;
    puStack_1c[5] = param_2;
    puStack_1c[6] = puStack_20;
    puVar9 = puStack_1c;
  }
  FUN_016797d0(puVar9);
  if (puVar9 != (undefined4 *)0x0) {
    LOCK();
    puVar9[1] = puVar9[1] + 1;
    UNLOCK();
  }
  uStack_18 = 2;
  uStack_8._0_1_ = 0x10;
  puStack_1c = puVar9;
  FUN_01675290(uVar4);
  uStack_8._0_1_ = 0xe;
  puVar8 = (undefined4 *)puStack_14[0x1b];
  if ((undefined4 *)puStack_14[0x1c] == puVar8) {
    FUN_006335f0(puVar8,&puStack_1c);
    puVar9 = puStack_1c;
  }
  else {
    *puVar8 = puVar9;
    puStack_14[0x1b] = puStack_14[0x1b] + 4;
    puVar9 = (undefined4 *)0x0;
  }
  uStack_18 = 0;
  uStack_8._0_1_ = 9;
  if (puVar9 != (undefined4 *)0x0) {
    piVar1 = puVar9 + 1;
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(puVar9);
    }
  }
  iVar5 = FUN_008a4100();
  param_3 = (int *)(iVar5 + 0x14);
  uStack_8._0_1_ = 0x11;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 0x12;
  piStack_24 = (int *)uVar4;
  param_2 = (undefined4 *)FUN_01674e20(0x1c);
  if (param_2 == (undefined4 *)0x0) {
    puVar9 = (undefined4 *)0x0;
  }
  else {
    *param_2 = 0;
    param_2[1] = 1;
    param_2[2] = FUN_00819070;
    param_2[3] = _guard_check_icall;
    param_2[4] = 0;
    param_2[5] = param_3;
    param_2[6] = puStack_14;
    puVar9 = param_2;
  }
  FUN_016797d0(puVar9);
  if (puVar9 != (undefined4 *)0x0) {
    LOCK();
    puVar9[1] = puVar9[1] + 1;
    UNLOCK();
  }
  uStack_18 = 4;
  uStack_8._0_1_ = 0x13;
  param_2 = puVar9;
  FUN_01675290(uVar4);
  puVar2 = puStack_14;
  puVar8 = (undefined4 *)puStack_14[0x1b];
  uStack_8._0_1_ = 0x11;
  if ((undefined4 *)puStack_14[0x1c] == puVar8) {
    FUN_006335f0(puVar8,&param_2);
    puVar9 = param_2;
  }
  else {
    *puVar8 = puVar9;
    puStack_14[0x1b] = puStack_14[0x1b] + 4;
    puVar9 = (undefined4 *)0x0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (puVar9 != (undefined4 *)0x0) {
    piVar1 = puVar9 + 1;
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(puVar9);
    }
  }
  iVar5 = FUN_006bf290();
  *(bool *)(puVar2 + 0x1e) = iVar5 != 0;
  FUN_007735a0(*(int *)(puVar2[0xb] + 0x4ec) + 0x3c,3);
  piVar1 = piStack_24;
  puVar2[0xc3] = uStack_28;
  param_3 = (int *)puVar2[0xc4];
  uStack_28 = 0;
  piStack_24 = (int *)0x0;
  puVar2[0xc4] = piVar1;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar5 = param_3[1] + -1;
    param_3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar5 = param_3[2] + -1;
      param_3[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
    param_3 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_24[1] + -1;
      piStack_24[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = param_3 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
  }
  FUN_00819900();
  ExceptionList = pvStack_10;
  return puVar2;
}



/* FUNCTION 12496 ; VA 0x00818760 ; FUN_00818760 */

void __fastcall FUN_00818760(undefined4 *param_1)

{
  undefined4 *puStack_8;
  
  puStack_8 = param_1;
  FUN_006a9630(&puStack_8,*(undefined4 *)*param_1,(undefined4 *)*param_1);
  FUN_01674ea0(*param_1,0x18);
  return;
}



/* FUNCTION 12497 ; VA 0x00818790 ; FUN_00818790 */

void __fastcall FUN_00818790(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 *puVar5;
  int *piVar6;
  int iVar7;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  puVar5 = (undefined4 *)0x0;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Graphics::GuiCluster::vftable;
  param_1[1] = RBX::Graphics::GuiCluster::vftable;
  piVar6 = (int *)param_1[0x10];
  puVar3 = (undefined4 *)((param_1[0x11] - (int)piVar6) + 3U >> 2);
  if ((int *)param_1[0x11] < piVar6) {
    puVar3 = (undefined4 *)0x0;
  }
  puStack_14 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    do {
      if ((undefined4 *)*piVar6 != (undefined4 *)0x0) {
        (*(code *)**(undefined4 **)*piVar6)(1);
        puVar3 = puStack_14;
      }
      puVar5 = (undefined4 *)((int)puVar5 + 1);
      piVar6 = piVar6 + 1;
    } while (puVar5 != puVar3);
  }
  param_1[0x11] = param_1[0x10];
  puVar5 = (undefined4 *)0x0;
  piVar6 = (int *)param_1[0x13];
  puVar3 = (undefined4 *)((param_1[0x14] - (int)piVar6) + 3U >> 2);
  if ((int *)param_1[0x14] < piVar6) {
    puVar3 = (undefined4 *)0x0;
  }
  puStack_14 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    do {
      if ((undefined4 *)*piVar6 != (undefined4 *)0x0) {
        (*(code *)**(undefined4 **)*piVar6)(1);
        puVar3 = puStack_14;
      }
      puVar5 = (undefined4 *)((int)puVar5 + 1);
      piVar6 = piVar6 + 1;
    } while (puVar5 != puVar3);
  }
  param_1[0x14] = param_1[0x13];
  puVar3 = (undefined4 *)param_1[0x18];
  puStack_14 = (undefined4 *)*puVar3;
  while (puStack_14 != puVar3) {
    if ((undefined4 *)puStack_14[5] != (undefined4 *)0x0) {
      (*(code *)**(undefined4 **)puStack_14[5])(1);
    }
    FUN_00551320();
  }
  FUN_00601ea0();
  iVar2 = param_1[0x1b];
  for (iVar7 = param_1[0x1a]; iVar7 != iVar2; iVar7 = iVar7 + 4) {
    FUN_01679490();
  }
  FUN_008193e0();
  piVar6 = (int *)param_1[0xc4];
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar2 = piVar6[1] + -1;
    piVar6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      iVar2 = piVar6[2] + -1;
      piVar6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  piVar6 = (int *)param_1[0xc2];
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar2 = piVar6[1] + -1;
    piVar6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      iVar2 = piVar6[2] + -1;
      piVar6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  piVar6 = (int *)param_1[0xc0];
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar2 = piVar6[1] + -1;
    piVar6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      iVar2 = piVar6[2] + -1;
      piVar6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  FUN_006378f0();
  FUN_006a9630(&puStack_14,*(undefined4 *)param_1[0x18],(undefined4 *)param_1[0x18]);
  FUN_01674ea0(param_1[0x18],0x18);
  piVar6 = (int *)param_1[0x17];
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar2 = piVar6[1] + -1;
    piVar6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  iVar2 = param_1[0x13];
  if (iVar2 != 0) {
    uVar4 = param_1[0x15] - iVar2 & 0xfffffffc;
    iVar7 = iVar2;
    if (0xfff < uVar4) {
      iVar7 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar7) - 4U) goto LAB_00818a12;
    }
    FUN_01674ea0(iVar7,uVar4);
    param_1[0x13] = 0;
    param_1[0x14] = 0;
    param_1[0x15] = 0;
  }
  iVar2 = param_1[0x10];
  if (iVar2 != 0) {
    uVar4 = param_1[0x12] - iVar2 & 0xfffffffc;
    iVar7 = iVar2;
    if (0xfff < uVar4) {
      iVar7 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar7) - 4U) {
LAB_00818a12:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar4);
    param_1[0x10] = 0;
    param_1[0x11] = 0;
    param_1[0x12] = 0;
  }
  FUN_0147cba0();
  *param_1 = RBX::Graphics::ISuperCluster::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 12498 ; VA 0x00818a20 ; FUN_00818a20 */

void __fastcall FUN_00818a20(undefined4 *param_1)

{
  *param_1 = RBX::Graphics::ISuperCluster::vftable;
  return;
}



/* FUNCTION 12499 ; VA 0x00818a30 ; FUN_00818a30 */

void * FUN_00818a30(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvVar4;
  undefined4 uVar5;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5e00;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar2 = *(int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00aff8c0();
    pvVar4 = (void *)(uint)*(ushort *)(iVar3 + 0x1da);
    if ((void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) <= pvVar4) {
      FUN_00c3e2a0();
      uVar5 = FUN_0060dcd0(auStack_18,param_1);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      pvVar4 = (void *)FUN_007c8e00(uVar5);
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_14 + 1;
        iVar2 = *piVar1;
        pvVar4 = (void *)*piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)*piStack_14)();
          LOCK();
          piVar1 = piStack_14 + 2;
          iVar2 = *piVar1;
          pvVar4 = (void *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            pvVar4 = (void *)(**(code **)(*piStack_14 + 4))();
          }
        }
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}


