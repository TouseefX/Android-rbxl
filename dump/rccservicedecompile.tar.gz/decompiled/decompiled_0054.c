/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 13500 ; VA 0x00878500 ; FUN_00878500 */

/* WARNING: Removing unreachable block (ram,0x0087881c) */
/* WARNING: Removing unreachable block (ram,0x0087872b) */
/* WARNING: Removing unreachable block (ram,0x00878739) */
/* WARNING: Removing unreachable block (ram,0x0087874d) */
/* WARNING: Removing unreachable block (ram,0x0087882a) */
/* WARNING: Removing unreachable block (ram,0x0087888c) */
/* WARNING: Removing unreachable block (ram,0x0087883a) */

void __thiscall FUN_00878500(char *param_1,undefined4 *param_2)

{
  code *pcVar1;
  undefined4 *puVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined auStack_44 [4];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  undefined2 uStack_24;
  char *pcStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9570;
  pvStack_10 = ExceptionList;
  if (*param_1 != '\0') {
    ExceptionList = &pvStack_10;
    pcStack_1c = param_1;
    if (DAT_01ede471 != '\0') {
      ExceptionList = &pvStack_10;
      FUN_01677520();
    }
    auStack_44[0] = 0;
    uStack_40 = FUN_00588320();
    uStack_3c = 0;
    uStack_38 = 0x3f800000;
    uStack_34 = 0;
    uStack_30 = 0;
    uVar6 = 0;
    uStack_8 = 0;
    if (DAT_01d7a800 == '\0') {
      do {
        param_2 = puVar2;
        if (0xf < (uint)puVar2[5]) {
          param_2 = (undefined4 *)*puVar2;
        }
        if (uVar6 < (uint)puVar2[4]) {
          iStack_14 = puVar2[4] - uVar6;
          iVar4 = FUN_0170db20();
          if (iVar4 == 0) goto LAB_008787b1;
          iVar4 = iVar4 - (int)param_2;
        }
        else {
LAB_008787b1:
          iVar4 = -1;
        }
        iStack_18 = iVar4;
        if ((uint)puVar2[4] < uVar6) goto LAB_00878891;
        FUN_005542c0();
        uStack_8._0_1_ = 3;
        puVar5 = (undefined4 *)FUN_005d1a60();
        uStack_8 = (uint)uStack_8._1_3_ << 8;
        *puVar5 = 1;
        uVar6 = iVar4 + 1;
      } while (iVar4 != -1);
    }
    else {
      uVar3 = param_2[4];
      if (uVar3 != 0) {
        do {
          param_2 = puVar2;
          if (0xf < (uint)puVar2[5]) {
            param_2 = (undefined4 *)*puVar2;
          }
          if (uVar6 < uVar3) {
            iStack_14 = uVar3 - uVar6;
            iVar4 = FUN_0170db20();
            if (iVar4 == 0) goto LAB_008785db;
            iVar4 = iVar4 - (int)param_2;
          }
          else {
LAB_008785db:
            iVar4 = -1;
          }
          uStack_5c = uStack_5c & 0xffffff00;
          iStack_14 = iVar4;
          if ((uint)puVar2[4] < uVar6) {
LAB_00878891:
            FUN_00554050();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
          }
          FUN_005542c0();
          FUN_0055c740();
          FUN_005d40e0();
          if (iStack_18 == 0) {
            puStack_2c = &uStack_40;
            puStack_28 = (undefined4 *)0x0;
            uStack_8 = CONCAT31(uStack_8._1_3_,2);
            uStack_24 = 0;
            puStack_28 = (undefined4 *)FUN_01674e20();
            uStack_24 = 0x101;
            *puStack_28 = 0;
            puStack_28[1] = 0;
            puStack_28[2] = 0;
            puStack_28[3] = 0;
            puStack_28[4] = 0;
            puStack_28[5] = 0;
            *(undefined8 *)(puStack_28 + 6) = 0;
            puStack_28[8] = 0;
            puStack_28[6] = 0;
            puStack_28[7] = 0;
            puStack_28[2] = uStack_5c;
            puStack_28[3] = uStack_58;
            puStack_28[4] = uStack_54;
            puStack_28[5] = uStack_50;
            puStack_28[6] = 0;
            puStack_28[7] = 0xf;
            puStack_28[8] = 1;
            FUN_005d99d0();
            FUN_005c5550();
            if (puStack_28 != (undefined4 *)0x0) {
              if (uStack_24._1_1_ != '\0') {
                FUN_005cf430();
              }
              FUN_01674ea0();
            }
          }
          uStack_8 = uStack_8 & 0xffffff00;
          if (iVar4 == -1) break;
          uVar3 = puVar2[4];
          uVar6 = iVar4 + 1;
        } while (uVar6 < uVar3);
      }
    }
    FUN_00871920(auStack_44);
    FUN_00874780();
    FUN_005d1280();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13501 ; VA 0x008788a0 ; FUN_008788a0 */

int FUN_008788a0(undefined4 param_1,undefined4 param_2,undefined8 param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 unaff_ESI;
  undefined4 unaff_EDI;
  undefined8 uVar4;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9148;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00876700();
  uStack_8 = 0;
  if ((iStack_18 != 0) && (DAT_01d62764 != '\0')) {
    iVar3 = FUN_00877fb0(param_1,param_2,param_3);
  }
  if (piStack_14 != (int *)0x0) {
    uVar4 = CONCAT44(unaff_ESI,unaff_EDI);
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))(uVar4);
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 13502 ; VA 0x00878940 ; FUN_00878940 */

void FUN_00878940(void)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a810;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_01678790();
  if (cVar1 != '\0') {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("Badly-formed-FInt-value",0x17);
    uStack_8 = 0;
    FUN_008783f0(auStack_28,1,0);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      uVar2 = auStack_28[0];
      if (0xfff < uVar3) {
        uVar2 = *(uint *)(auStack_28[0] - 4);
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar2,uVar3);
    }
  }
  cVar1 = FUN_016787a0();
  if (cVar1 != '\0') {
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_005542c0("Badly-formed-FFlag-value",0x18);
    uStack_8 = 1;
    FUN_008783f0(auStack_40,1,0);
    if (0xf < uStack_2c) {
      uVar3 = uStack_2c + 1;
      uVar2 = auStack_40[0];
      if (0xfff < uVar3) {
        uVar2 = *(uint *)(auStack_40[0] - 4);
        uVar3 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar2,uVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13503 ; VA 0x00878a70 ; FUN_00878a70 */

void __thiscall
FUN_00878a70(undefined4 *param_1,undefined4 *param_2,undefined8 param_3,undefined4 param_4)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  char cVar6;
  uint *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 uVar11;
  int iVar12;
  int iVar13;
  undefined8 uVar14;
  undefined auStack_3c [24];
  uint *puStack_24;
  char cStack_20;
  int *piStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9590;
  pvStack_10 = ExceptionList;
  cStack_20 = '\0';
  puStack_24 = (uint *)*param_1;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00587410();
  iStack_8 = 0;
  FUN_0087b760();
  piStack_1c = param_1 + 0xe;
  if ((param_1[0xe] == param_1[0xf]) && (param_1[0x13] == 0)) {
    iVar12 = DAT_01d6255c >> 0x1f;
    iStack_18 = DAT_01d6255c;
    puVar7 = (uint *)FUN_0168ea80();
    uVar14 = FUN_016f39b0(iStack_18,iVar12,1000000000,0);
    uVar1 = *puVar7;
    uVar2 = puVar7[1];
    puStack_14[4] = (uint)uVar14 + *puVar7;
    puStack_14[5] = (int)((ulonglong)uVar14 >> 0x20) + uVar2 + (uint)CARRY4((uint)uVar14,uVar1);
    FUN_00588350();
  }
  piVar5 = piStack_1c;
  if ((DAT_020c0b1c != '\0') && (DAT_01d6272c != '\0')) {
    cVar6 = FUN_0087b090();
    if (cVar6 != '\0') {
      puVar8 = (undefined4 *)FUN_00876ad0();
      if (DAT_01ede471 != '\0') {
        puVar10 = puVar8;
        if (0xf < (uint)puVar8[5]) {
          puVar10 = (undefined4 *)*puVar8;
        }
        puVar9 = param_2;
        if (0xf < (uint)param_2[5]) {
          puVar9 = (undefined4 *)*param_2;
        }
        FUN_01677520(DAT_01ede471,"Adding stat %s%s = %f",puVar9,puVar10,param_3);
      }
      puVar10 = (undefined4 *)FUN_005f3cd0(auStack_3c,param_2,puVar8);
      puVar8 = (undefined4 *)piVar5[1];
      iStack_8._0_1_ = 1;
      if ((undefined4 *)piVar5[2] == puVar8) {
        FUN_00633500(puVar8,puVar10,&param_3);
      }
      else {
        puVar8[4] = 0;
        puVar8[5] = 0;
        uVar11 = puVar10[1];
        uVar3 = puVar10[2];
        uVar4 = puVar10[3];
        *puVar8 = *puVar10;
        puVar8[1] = uVar11;
        puVar8[2] = uVar3;
        puVar8[3] = uVar4;
        *(undefined8 *)(puVar8 + 4) = *(undefined8 *)(puVar10 + 4);
        puVar10[4] = 0;
        puVar10[5] = 0xf;
        *(undefined *)puVar10 = 0;
        piVar5[1] = piVar5[1] + 0x20;
        *(undefined8 *)(puVar8 + 6) = param_3;
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_005507b0();
    }
  }
  if (DAT_01ede471 != '\0') {
    puVar8 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar8 = (undefined4 *)*param_2;
    }
    FUN_01677520(DAT_01ede471,"Adding stat %s = %f",puVar8,param_3);
  }
  iVar12 = piVar5[1];
  if (piVar5[2] == iVar12) {
    FUN_0086fa90(iVar12,param_2,&param_3);
    iVar13 = puStack_14[0xf];
  }
  else {
    FUN_0054ef60();
    piVar5[1] = piVar5[1] + 0x20;
    iVar13 = piVar5[1];
    *(undefined8 *)(iVar12 + 0x18) = param_3;
  }
  if ((DAT_01d62564 <= (uint)(puStack_14[0x13] + (iVar13 - *piVar5 >> 5))) ||
     ((char)param_4 != '\0')) {
    FUN_0087b650();
    FUN_00872190();
  }
  iStack_8 = 2;
  if (cStack_20 != '\0') {
    LOCK();
    uVar1 = *puStack_24;
    *puStack_24 = *puStack_24 + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puStack_24;
      *puStack_24 = *puStack_24 | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar11 = FUN_00554e40();
        SetEvent(uVar11);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13504 ; VA 0x00878cf0 ; FUN_00878cf0 */

int FUN_00878cf0(undefined4 param_1,undefined8 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char *pcStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9148;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00876700(&pcStack_18);
  uStack_8 = 0;
  if ((pcStack_18 != (char *)0x0) && (*pcStack_18 != '\0')) {
    iVar3 = FUN_00878a70(param_1,param_2,param_3);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 13505 ; VA 0x00878d80 ; FUN_00878d80 */

void __fastcall FUN_00878d80(int *param_1)

{
  uint uVar1;
  int iVar2;
  char cVar3;
  uint *puVar4;
  undefined4 uVar5;
  int iVar6;
  undefined8 uVar7;
  int iStack_54;
  int iStack_50;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int *piStack_3c;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  uint *puStack_1c;
  char cStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b95b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  if (DAT_01ede471 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ede471,"Request shutdown starting",0);
  }
  puStack_1c = (uint *)*param_1;
  cStack_18 = '\0';
  FUN_00587410();
  uStack_8 = 0;
  if (*(char *)(*param_1 + 8) == '\0') {
    *(undefined *)(*param_1 + 8) = 1;
    FUN_00588350();
    FUN_0087b650(&iStack_34,&puStack_1c,0);
    iVar2 = DAT_01d62574;
    iVar6 = DAT_01d62574 >> 0x1f;
    uStack_8._0_1_ = 1;
    puVar4 = (uint *)FUN_0168ea80(&iStack_24);
    uVar7 = FUN_016f39b0(iVar2,iVar6,1000000,0);
    iStack_24 = (uint)uVar7 + *puVar4;
    iStack_20 = (int)((ulonglong)uVar7 >> 0x20) + puVar4[1] + (uint)CARRY4((uint)uVar7,*puVar4);
    if ((DAT_020c0b1c == '\0') || (DAT_01d62724 == '\0')) {
      cVar3 = FUN_0168a370();
      if (cVar3 != '\0') {
        FUN_008714e0(&iStack_24);
      }
      if (iStack_34 != 0) {
        FUN_008716c0(&iStack_24);
      }
      if (iStack_2c != 0) {
        FUN_008716c0(&iStack_24);
      }
      if (DAT_01ede471 != '\0') {
        FUN_016774b0(DAT_01ede471,"Request shutdown returning",0);
      }
    }
    else {
      iStack_54 = iStack_34;
      iStack_50 = iStack_30;
      if (iStack_30 != 0) {
        LOCK();
        *(int *)(iStack_30 + 4) = *(int *)(iStack_30 + 4) + 1;
        UNLOCK();
      }
      iStack_4c = iStack_2c;
      iStack_48 = iStack_28;
      if (iStack_28 != 0) {
        LOCK();
        *(int *)(iStack_28 + 4) = *(int *)(iStack_28 + 4) + 1;
        UNLOCK();
      }
      piStack_3c = piStack_14;
      uStack_8._0_1_ = 2;
      iStack_44 = iStack_24;
      iStack_40 = iStack_20;
      FUN_0086f630(&iStack_54);
      FUN_00872190();
    }
    FUN_00872190();
  }
  else if (DAT_01ede471 != '\0') {
    FUN_016774b0(DAT_01ede471,"Request shutdown early return because already requested",0);
  }
  uStack_8 = 5;
  if (cStack_18 != '\0') {
    LOCK();
    uVar1 = *puStack_1c;
    *puStack_1c = *puStack_1c + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puStack_1c;
      *puStack_1c = *puStack_1c | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar5 = FUN_00554e40();
        SetEvent(uVar5);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13506 ; VA 0x00878f70 ; FUN_00878f70 */

int __fastcall FUN_00878f70(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  code *pcVar4;
  int iVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b95d8;
  pvStack_10 = ExceptionList;
  piVar6 = *(int **)(param_1 + 0x48);
  ExceptionList = &pvStack_10;
  if (piVar6 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar6[1] = piVar6[1] + 1;
    UNLOCK();
    piVar6 = *(int **)(param_1 + 0x48);
  }
  uVar3 = *(undefined4 *)(param_1 + 0x44);
  pcVar4 = *(code **)(param_1 + 0x3c);
  piVar1 = piVar6 + 1;
  uStack_8 = 0;
  if (piVar6 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar5 = (*pcVar4)(uVar3,piVar6);
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piVar6)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 13507 ; VA 0x00879010 ; FUN_00879010 */

undefined4 FUN_00879010(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int aiStack_34 [5];
  uint uStack_20;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9600;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_014c9d60(&iStack_1c,0);
  iStack_8 = 0;
  puVar2 = param_3 + 4;
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  FUN_014cbbc0(param_3,*puVar2);
  *(undefined4 *)(iStack_1c + 0xb0) = 0x17;
  FUN_014cbab0();
  FUN_014cba60();
  FUN_014cb780(param_2,0);
  puVar2 = &DAT_01d79f50;
  if (0xf < DAT_01d79f64) {
    puVar2 = DAT_01d79f50;
  }
  puVar3 = &DAT_01d79d70;
  if (0xf < DAT_01d79d84) {
    puVar3 = DAT_01d79d70;
  }
  FUN_014cb8a0(puVar3,DAT_01d79d80,puVar2,DAT_01d79f60);
  if (DAT_01d7a7f0 != '\0') {
    puVar3 = (undefined4 *)FUN_01682c00(aiStack_34);
    puVar2 = puVar3 + 4;
    iStack_8._0_1_ = 1;
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    puVar4 = &DAT_01d7a010;
    if (0xf < DAT_01d7a024) {
      puVar4 = DAT_01d7a010;
    }
    FUN_014cb8a0(puVar4,DAT_01d7a020,puVar3,*puVar2);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_20) {
      uVar6 = uStack_20 + 1;
      iVar5 = aiStack_34[0];
      if (0xfff < uVar6) {
        iVar5 = *(int *)(aiStack_34[0] + -4);
        uVar6 = uStack_20 + 0x24;
        if (0x1f < (aiStack_34[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar6);
    }
  }
  FUN_014cb340(param_1);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_18[1] + -1;
    piStack_18[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13508 ; VA 0x008791c0 ; FUN_008791c0 */

undefined4 * __thiscall FUN_008791c0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined uVar4;
  char cVar5;
  undefined4 ****ppppuVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  int *piVar12;
  int *piStack_a4;
  uint uStack_a0;
  uint uStack_8c;
  undefined auStack_84 [4];
  int *piStack_80;
  uint auStack_7c [4];
  undefined4 uStack_6c;
  uint uStack_68;
  undefined4 ***apppuStack_64 [5];
  uint uStack_50;
  undefined auStack_4c [4];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined uStack_2c;
  int iStack_28;
  int iStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b9654;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  piStack_1c = (int *)(param_1 + 0x44);
  uStack_14 = 1;
  iStack_18 = **(int **)(param_1 + 0x44);
  iStack_24 = param_1;
  if ((int *)iStack_18 != *(int **)(param_1 + 0x44)) {
    do {
      iVar9 = iStack_18;
      piVar12 = (int *)(iStack_18 + 0x10);
      uStack_6c = 0;
      iStack_28 = iStack_18 + 0x28;
      uStack_68 = 0xf;
      auStack_7c[0] = auStack_7c[0] & 0xffffff00;
      uStack_8 = 1;
      FUN_008775b0(iStack_28,auStack_7c);
      uStack_20 = FUN_014d9fd0(auStack_7c,&DAT_01d79f98,0);
      uStack_8._0_1_ = 2;
      FUN_00d82b80(apppuStack_64,piVar12);
      uStack_14 = uStack_14 | 2;
      ppppuVar6 = apppuStack_64;
      if (0xf < uStack_50) {
        ppppuVar6 = (undefined4 ****)apppuStack_64[0];
      }
      uStack_8._0_1_ = 3;
      cVar5 = FUN_014cd610(ppppuVar6,0);
      if (cVar5 != '\0') {
        auStack_4c[0] = 0;
        uStack_48 = FUN_00588320(0xb);
        uStack_44 = 0;
        uStack_40 = 0x3f800000;
        uStack_3c = 0;
        uStack_38 = 0;
        uStack_34 = 0;
        uStack_30 = 0;
        uStack_2c = 0;
        uStack_8._0_1_ = 4;
        uVar7 = FUN_014da4f0(auStack_84,apppuStack_64,uStack_20,auStack_4c);
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
        if (param_2[2] == param_2[1]) {
          FUN_0086fd50(param_2[1],uVar7);
        }
        else {
          FUN_00871850(uVar7);
          param_2[1] = param_2[1] + 8;
        }
        piVar3 = piStack_80;
        uStack_8._0_1_ = 6;
        if (piStack_80 != (int *)0x0) {
          LOCK();
          iVar2 = piStack_80[1] + -1;
          piStack_80[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piStack_80 + 4))();
            LOCK();
            piVar1 = piVar3 + 2;
            iVar2 = *piVar1 + -1;
            *piVar1 = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar3 + 8))();
            }
          }
        }
        FUN_0056cfd0();
      }
      uStack_8._0_1_ = 2;
      uVar4 = (undefined)uStack_8;
      uStack_8._0_1_ = 2;
      if (0xf < uStack_50) {
        uVar10 = uStack_50 + 1;
        ppppuVar6 = (undefined4 ****)apppuStack_64[0];
        if (0xfff < uVar10) {
          ppppuVar6 = (undefined4 ****)apppuStack_64[0][-1];
          uVar10 = uStack_50 + 0x24;
          if (0x1f < (uint)((int)apppuStack_64[0] + (-4 - (int)ppppuVar6))) goto LAB_008794e1;
        }
        FUN_01674ea0(ppppuVar6,uVar10);
      }
      uStack_8._0_1_ = 1;
      if (0xf < uStack_8c) {
        uVar11 = uStack_8c + 1;
        uVar10 = uStack_a0;
        if (0xfff < uVar11) {
          uVar10 = *(uint *)(uStack_a0 - 4);
          uVar11 = uStack_8c + 0x24;
          uVar4 = (undefined)uStack_8;
          if (0x1f < (uStack_a0 - uVar10) - 4) goto LAB_008794e1;
        }
        FUN_01674ea0(uVar10,uVar11);
      }
      uStack_8c = 0xf;
      uStack_a0 = uStack_a0 & 0xffffff00;
      if (piStack_a4 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_a4[1] + -1;
        piStack_a4[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_a4)();
          LOCK();
          iVar2 = piStack_a4[2] + -1;
          piStack_a4[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piStack_a4 + 4))();
          }
        }
      }
      if (DAT_01ede472 != '\0') {
        if (0xf < *(uint *)(iVar9 + 0x24)) {
          piVar12 = (int *)*piVar12;
        }
        puVar8 = (undefined4 *)(iStack_24 + 8);
        if (0xf < *(uint *)(iStack_24 + 0x1c)) {
          puVar8 = (undefined4 *)*puVar8;
        }
        FUN_01677490(DAT_01ede472,"%s sent queued events to target: %s",puVar8,piVar12,0);
      }
      if (*(int *)(iStack_28 + 0x10) == 0) {
        FUN_00551320();
        piVar12 = piStack_1c;
        iVar9 = FUN_00553830(iVar9);
        FUN_00870c10(piVar12,iVar9 + 0x10);
        FUN_01674ea0(iVar9,0x3c);
      }
      else {
        FUN_00551320();
        piVar12 = piStack_1c;
      }
      uStack_8._0_1_ = 0;
      if (0xf < uStack_68) {
        uVar11 = uStack_68 + 1;
        uVar10 = auStack_7c[0];
        if (0xfff < uVar11) {
          uVar10 = *(uint *)(auStack_7c[0] - 4);
          uVar11 = uStack_68 + 0x24;
          uVar4 = (undefined)uStack_8;
          if (0x1f < (auStack_7c[0] - uVar10) - 4) {
LAB_008794e1:
            uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar10,uVar11);
      }
    } while (iStack_18 != *piVar12);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 13509 ; VA 0x008794f0 ; FUN_008794f0 */

int FUN_008794f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9068;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00876840(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_00874130(param_1,param_2,param_3,param_4);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 13510 ; VA 0x00879580 ; FUN_00879580 */

int FUN_00879580(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9068;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00876840(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    iVar3 = FUN_00879600(param_1,param_2,param_3,param_4);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 13511 ; VA 0x00879600 ; FUN_00879600 */

void FUN_00879600(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 ****ppppuVar5;
  uint uVar6;
  uint uVar7;
  undefined auStack_98 [4];
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined uStack_78;
  undefined auStack_74 [4];
  int *piStack_70;
  undefined4 ***apppuStack_6c [5];
  uint uStack_58;
  uint auStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017b9696;
  pvStack_10 = ExceptionList;
  uStack_44 = 0;
  uStack_40 = 0xf;
  auStack_54[0] = auStack_54[0] & 0xffffff00;
  uStack_8 = 0;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  cVar3 = FUN_00874fb0(param_1,param_2,param_3,param_4,auStack_54);
  if (cVar3 != '\0') {
    piStack_24 = (int *)0x0;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
    piStack_24 = (int *)FUN_01674e20(8);
    *piStack_24 = 0;
    piStack_24[1] = 0;
    *piStack_24 = (int)&piStack_24;
    uStack_8 = 1;
    FUN_008777f0(auStack_54);
    _guard_check_icall(param_1,auStack_54);
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = auStack_3c[0] & 0xffffff00;
    uStack_8 = 2;
    FUN_008775b0(&piStack_24,auStack_3c);
    uVar4 = FUN_014d9fd0(auStack_3c,&DAT_01d79f98,0);
    uStack_8 = 3;
    FUN_00d82b80(apppuStack_6c,param_1);
    ppppuVar5 = apppuStack_6c;
    if (0xf < uStack_58) {
      ppppuVar5 = (undefined4 ****)apppuStack_6c[0];
    }
    uStack_8 = 4;
    cVar3 = FUN_014cd610(ppppuVar5,0);
    if (cVar3 != '\0') {
      auStack_98[0] = 0;
      uStack_94 = FUN_00588320(0xb);
      uStack_90 = 0;
      uStack_8c = 0x3f800000;
      uStack_88 = 0;
      uStack_84 = 0;
      uStack_80 = 0;
      uStack_7c = 0;
      uStack_78 = 0;
      uStack_8 = 5;
      FUN_014da4f0(auStack_74,apppuStack_6c,uVar4,auStack_98);
      uStack_8 = 6;
      if (piStack_70 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_70[1] + -1;
        piStack_70[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_70 + 4))();
          LOCK();
          piVar1 = piStack_70 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piStack_70 + 8))();
          }
        }
      }
      FUN_0056cfd0();
    }
    if (0xf < uStack_58) {
      uVar6 = uStack_58 + 1;
      ppppuVar5 = (undefined4 ****)apppuStack_6c[0];
      if (0xfff < uVar6) {
        ppppuVar5 = (undefined4 ****)apppuStack_6c[0][-1];
        uVar6 = uStack_58 + 0x24;
        if (0x1f < (uint)((int)apppuStack_6c[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar5,uVar6);
    }
    FUN_006511a0();
    if (0xf < uStack_28) {
      uVar7 = uStack_28 + 1;
      uVar6 = auStack_3c[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_3c[0] - 4);
        uVar7 = uStack_28 + 0x24;
        if (0x1f < (auStack_3c[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = auStack_3c[0] & 0xffffff00;
    FUN_00592290();
  }
  if (0xf < uStack_40) {
    uVar7 = uStack_40 + 1;
    uVar6 = auStack_54[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_54[0] - 4);
      uVar7 = uStack_40 + 0x24;
      if (0x1f < (auStack_54[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13512 ; VA 0x00879890 ; FUN_00879890 */

void __fastcall FUN_00879890(undefined4 **param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint uVar6;
  undefined4 uVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 **ppuVar10;
  char *pcVar11;
  undefined *puVar12;
  uint auStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  undefined4 *apuStack_3c [2];
  undefined auStack_34 [8];
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  int *piStack_20;
  int *piStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b96e7;
  pvStack_10 = ExceptionList;
  puStack_2c = (undefined4 *)0x0;
  puStack_28 = (undefined4 *)0x0;
  puStack_24 = (undefined4 *)0x0;
  ppuVar10 = param_1 + 3;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_016dee6d(ppuVar10);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  if (param_1[0xf] == (undefined4 *)0x0) {
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar3 = FUN_016deec8(ppuVar10);
    if (iVar3 != 0) {
      FUN_016df3c9(iVar3);
    }
    goto LAB_00879b5f;
  }
  piStack_1c = (int *)(((int)param_1[1] - (int)*param_1) / 0x18 + (int)param_1[0xf]);
  puVar9 = (undefined4 *)0x0;
  puStack_14 = (undefined4 *)0x0;
  if (&puStack_2c != param_1) {
    puVar9 = *param_1;
    *param_1 = (undefined4 *)0x0;
    puStack_28 = param_1[1];
    param_1[1] = (undefined4 *)0x0;
    puStack_24 = param_1[2];
    param_1[2] = (undefined4 *)0x0;
    puStack_2c = puVar9;
    puStack_14 = puStack_28;
  }
  param_1[0xf] = (undefined4 *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iVar3 = FUN_016deec8(ppuVar10);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  uStack_58 = 0;
  uStack_54 = 0xf;
  auStack_68[0] = auStack_68[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0058a190(piStack_1c);
  puVar2 = puStack_14;
  for (; puVar9 != puVar2; puVar9 = puVar9 + 6) {
    puVar4 = puVar9;
    if (0xf < (uint)puVar9[5]) {
      puVar4 = (undefined4 *)*puVar9;
    }
    FUN_00554150(puVar4,puVar9[4]);
    FUN_00554150(&DAT_018bcfa8,1);
  }
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede558) &&
     (FUN_016f3809(&DAT_01ede558), DAT_01ede558 == -1)) {
    uStack_8._0_1_ = 4;
    uVar6 = FUN_01679ce0();
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    DAT_01ede554 = uVar6 % 10000;
    FUN_016f37bf(&DAT_01ede558);
  }
  if ((int)DAT_01ede554 < DAT_01ede47c) {
    puVar12 = &DAT_01d627bc;
    if (DAT_01d627d4 != '\0') goto LAB_00879b14;
    FUN_00879010(apuStack_3c,auStack_68,&DAT_01d627bc);
    uStack_8._0_1_ = 5;
    FUN_00879010(auStack_34,auStack_68,&DAT_01d627a4);
    ppuVar10 = apuStack_3c;
    do {
      piVar1 = ppuVar10[1];
      piStack_20 = *ppuVar10;
      if (piVar1 != (int *)0x0) {
        LOCK();
        piVar1[1] = piVar1[1] + 1;
        UNLOCK();
      }
      uStack_8._0_1_ = 7;
      piStack_1c = piVar1;
      if (piStack_20 == (int *)0x0) {
        uVar7 = FUN_0056acb0();
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
        FUN_00564940(uVar7);
        goto LAB_00879bd2;
      }
      piVar5 = (int *)(**(code **)(*piStack_20 + 0x14))();
      iVar3 = *(int *)(*piVar5 + 0x70);
      if (iVar3 == 0) {
        iVar3 = *(int *)(*piVar5 + 0xc);
        if (((iVar3 != 200) && (iVar3 != 0xcc)) && (DAT_01ede471 != '\0')) {
          pcVar11 = "PointsList::send failed with HTTP status code %d";
          goto LAB_00879ab5;
        }
      }
      else if (DAT_01ede471 != '\0') {
        pcVar11 = "PointsList::send failed with error %d";
LAB_00879ab5:
        FUN_016774b0(DAT_01ede471,pcVar11,iVar3);
      }
      uStack_8._0_1_ = 9;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar3 = piVar1[1] + -1;
        piVar1[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar1 + 4))();
          LOCK();
          iVar3 = piVar1[2] + -1;
          piVar1[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar1 + 8))();
          }
        }
      }
      ppuVar10 = ppuVar10 + 2;
    } while (ppuVar10 != &puStack_2c);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_016f32d1(apuStack_3c,8,2,FUN_00550ad0);
  }
  else {
    puVar12 = &DAT_01d627a4;
LAB_00879b14:
    FUN_00870fb0(auStack_68,puVar12);
  }
  if (0xf < uStack_54) {
    uVar8 = uStack_54 + 1;
    uVar6 = auStack_68[0];
    if (0xfff < uVar8) {
      uVar6 = *(uint *)(auStack_68[0] - 4);
      uVar8 = uStack_54 + 0x24;
      if (0x1f < (auStack_68[0] - uVar6) - 4) {
LAB_00879bd2:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar8);
  }
  uStack_58 = 0;
  uStack_54 = 0xf;
  auStack_68[0] = auStack_68[0] & 0xffffff00;
LAB_00879b5f:
  FUN_00577a40();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13513 ; VA 0x00879be0 ; FUN_00879be0 */

undefined4 * FUN_00879be0(undefined4 *param_1,int *param_2,int param_3,char param_4)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  int *piVar8;
  char *pcVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  int iVar13;
  undefined4 *puVar14;
  uint uVar15;
  int aiStack_f4 [5];
  uint uStack_e0;
  undefined auStack_a4 [4];
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined uStack_84;
  uint auStack_80 [4];
  undefined4 uStack_70;
  uint uStack_6c;
  uint auStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017b97be;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01ede471 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_01677520(DAT_01ede471,"SendNow, # stats = %zu, # counters = %zu",param_2[1] - *param_2 >> 5,
                 *(undefined4 *)(param_3 + 8));
  }
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  uVar15 = 1;
  iStack_8 = 0;
  uStack_20 = 1;
  if (*param_2 != param_2[1]) {
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    pcVar9 = PTR_DAT_01d62804;
    do {
      cVar2 = *pcVar9;
      pcVar9 = pcVar9 + 1;
    } while (cVar2 != '\0');
    FUN_005542c0(PTR_DAT_01d62804,(int)pcVar9 - (int)(PTR_DAT_01d62804 + 1));
    iStack_8 = 1;
    FUN_00d82e30(auStack_68,auStack_38);
    iStack_8._0_1_ = 3;
    if (0xf < uStack_24) {
      uVar11 = uStack_24 + 1;
      uVar15 = auStack_38[0];
      if (0xfff < uVar11) {
        uVar15 = *(uint *)(auStack_38[0] - 4);
        uVar11 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar15) - 4) {
LAB_0087a3af:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar11);
    }
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    FUN_0167e9f0();
    iStack_8 = CONCAT31(iStack_8._1_3_,4);
    FUN_01681c10();
    iVar10 = param_2[1];
    for (iVar13 = *param_2; iVar13 != iVar10; iVar13 = iVar13 + 0x20) {
      FUN_01681c30();
      FUN_01681e50(&DAT_0191c248,iVar13);
      FUN_01681020(&DAT_0191c24c,*(undefined8 *)(iVar13 + 0x18));
      FUN_01681200();
    }
    FUN_016811a0();
    uVar5 = FUN_01681c00();
    uVar6 = FUN_01680fc0();
    uStack_70 = 0;
    uStack_6c = 0xf;
    auStack_80[0] = auStack_80[0] & 0xffffff00;
    FUN_005542c0(uVar6,uVar5);
    uVar15 = 3;
    uStack_20 = 3;
    FUN_0167ec80();
    iStack_8._0_1_ = 5;
    if (DAT_01d6270c != '\0') {
      puVar3 = (undefined4 *)param_2[1];
      uVar15 = uStack_20;
      for (puVar14 = (undefined4 *)*param_2; uStack_20 = uVar15, puVar14 != puVar3;
          puVar14 = puVar14 + 8) {
        FUN_0151f6f0(DAT_01ede46c,4,DAT_01d6254c);
        iStack_8._0_1_ = 6;
        puVar7 = puVar14;
        if (0xf < (uint)puVar14[5]) {
          puVar7 = (undefined4 *)*puVar14;
        }
        FUN_0151fb00(puVar7,*(undefined8 *)(puVar14 + 6));
        uVar5 = DAT_01ede46c;
        uStack_40 = 0;
        uStack_3c = 0xf;
        auStack_50[0] = auStack_50[0] & 0xffffff00;
        FUN_005542c0("Telemetry",9);
        iStack_8._0_1_ = 7;
        FUN_01520d20(auStack_50,uVar5,0);
        iStack_8._0_1_ = 6;
        if (0xf < uStack_3c) {
          if ((0xfff < uStack_3c + 1) && (0x1f < (auStack_50[0] - *(int *)(auStack_50[0] - 4)) - 4))
          goto LAB_0087a3af;
          FUN_01674ea0();
        }
        iStack_8._0_1_ = 5;
        FUN_0151f7f0();
        uVar15 = uStack_20;
      }
    }
    if (param_4 == '\0') {
      auStack_a4[0] = 0;
      uStack_a0 = FUN_00588320();
      uStack_9c = 0;
      uStack_98 = 0x3f800000;
      uStack_94 = 0;
      uStack_90 = 0;
      uStack_8c = 0;
      uStack_88 = 0;
      uStack_84 = 0;
      iStack_8._0_1_ = 8;
      uVar5 = FUN_014d9fd0(auStack_80,&DAT_01d79f98,1);
      iStack_8._0_1_ = 9;
      FUN_014da4f0(auStack_18,auStack_68,uVar5,auStack_a4);
      iStack_8._0_1_ = 10;
      FUN_00872b10();
      piVar8 = piStack_14;
      iStack_8._0_1_ = 0xb;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar10 = piStack_14[1] + -1;
        piStack_14[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)(*piStack_14 + 4))();
          LOCK();
          piVar1 = piVar8 + 2;
          iVar10 = *piVar1 + -1;
          *piVar1 = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piVar8 + 8))();
          }
        }
      }
      FUN_006511a0();
      FUN_0056cfd0();
    }
    else {
      FUN_00d82750(auStack_68,auStack_80,&DAT_01d79f98,0,0);
    }
    iStack_8._0_1_ = 3;
    uVar4 = (undefined)iStack_8;
    iStack_8._0_1_ = 3;
    if (0xf < uStack_6c) {
      uVar12 = uStack_6c + 1;
      uVar11 = auStack_80[0];
      if (0xfff < uVar12) {
        uVar11 = *(uint *)(auStack_80[0] - 4);
        uVar12 = uStack_6c + 0x24;
        if (0x1f < (auStack_80[0] - uVar11) - 4) {
          iStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar12);
    }
    uStack_70 = 0;
    uStack_6c = 0xf;
    auStack_80[0] = auStack_80[0] & 0xffffff00;
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_54) {
      uVar12 = uStack_54 + 1;
      uVar11 = auStack_68[0];
      if (0xfff < uVar12) {
        uVar11 = *(uint *)(auStack_68[0] - 4);
        uVar12 = uStack_54 + 0x24;
        if (0x1f < (auStack_68[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar12);
    }
    uStack_58 = 0;
    uStack_54 = 0xf;
    auStack_68[0] = auStack_68[0] & 0xffffff00;
  }
  if (*(int *)(param_3 + 8) != 0) {
    uStack_40 = 0;
    uStack_3c = 0xf;
    auStack_50[0] = auStack_50[0] & 0xffffff00;
    pcVar9 = PTR_DAT_01d62804;
    do {
      cVar2 = *pcVar9;
      pcVar9 = pcVar9 + 1;
    } while (cVar2 != '\0');
    FUN_005542c0(PTR_DAT_01d62804,(int)pcVar9 - (int)(PTR_DAT_01d62804 + 1));
    iStack_8 = 0xc;
    FUN_00d83130(aiStack_f4,auStack_50);
    iStack_8._0_1_ = 0xe;
    if (0xf < uStack_3c) {
      uVar12 = uStack_3c + 1;
      uVar11 = auStack_50[0];
      if (0xfff < uVar12) {
        uVar11 = *(uint *)(auStack_50[0] - 4);
        uVar12 = uStack_3c + 0x24;
        if (0x1f < (auStack_50[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar11,uVar12);
    }
    uStack_40 = 0;
    uStack_3c = 0xf;
    auStack_50[0] = auStack_50[0] & 0xffffff00;
    FUN_0167e9f0();
    iStack_8 = CONCAT31(iStack_8._1_3_,0xf);
    FUN_01681c30();
    if (*(int *)(param_3 + 8) == 0) {
      puVar14 = (undefined4 *)0x0;
    }
    else {
      puVar14 = *(undefined4 **)(*(int *)(param_3 + 0x14) + *(int *)(param_3 + 4) * 4);
    }
    for (; puVar14 != (undefined4 *)0x0; puVar14 = (undefined4 *)*puVar14) {
      FUN_01681760(puVar14 + 2,puVar14[8]);
    }
    FUN_01681200();
    uVar5 = FUN_01681c00();
    uVar6 = FUN_01680fc0();
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    FUN_005542c0(uVar6,uVar5);
    uStack_20 = uVar15 | 4;
    FUN_0167ec80();
    iStack_8._0_1_ = 0x10;
    if ((DAT_020c0b1c != '\0') && (DAT_01d62704 != '\0')) {
      FUN_0151f6f0(DAT_01ede468,5,DAT_01d6253c);
      iStack_8._0_1_ = 0x11;
      uVar5 = DAT_01ede468;
      if (*(int *)(param_3 + 8) == 0) {
        puVar14 = (undefined4 *)0x0;
      }
      else {
        puVar14 = *(undefined4 **)(*(int *)(param_3 + 0x14) + *(int *)(param_3 + 4) * 4);
      }
      for (; DAT_01ede468 = uVar5, puVar14 != (undefined4 *)0x0; puVar14 = (undefined4 *)*puVar14) {
        piVar8 = puVar14 + 2;
        if (0xf < (uint)puVar14[7]) {
          piVar8 = (int *)*piVar8;
        }
        FUN_0151f9c0(piVar8,puVar14[8]);
        uVar5 = DAT_01ede468;
      }
      uStack_58 = 0;
      uStack_54 = 0xf;
      auStack_68[0] = auStack_68[0] & 0xffffff00;
      FUN_005542c0("Telemetry",9);
      iStack_8._0_1_ = 0x12;
      FUN_01520d20(auStack_68,uVar5,0);
      iStack_8._0_1_ = 0x11;
      uVar4 = (undefined)iStack_8;
      iStack_8._0_1_ = 0x11;
      if (0xf < uStack_54) {
        uVar11 = uStack_54 + 1;
        uVar15 = auStack_68[0];
        if (0xfff < uVar11) {
          uVar15 = *(uint *)(auStack_68[0] - 4);
          uVar11 = uStack_54 + 0x24;
          if (0x1f < (auStack_68[0] - uVar15) - 4) {
            iStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar15,uVar11);
      }
      iStack_8._0_1_ = 0x10;
      FUN_0151f7f0();
    }
    if (param_4 == '\0') {
      auStack_a4[0] = 0;
      uStack_a0 = FUN_00588320();
      uStack_9c = 0;
      uStack_98 = 0x3f800000;
      uStack_94 = 0;
      uStack_90 = 0;
      uStack_8c = 0;
      uStack_88 = 0;
      uStack_84 = 0;
      iStack_8._0_1_ = 0x13;
      uVar5 = FUN_014d9fd0(auStack_38,&DAT_01d79f98,1);
      iStack_8._0_1_ = 0x14;
      FUN_014da4f0(auStack_18,aiStack_f4,uVar5,auStack_a4);
      iStack_8._0_1_ = 0x15;
      FUN_00872b10();
      iStack_8._0_1_ = 0x16;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar10 = piStack_14[1] + -1;
        piStack_14[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)(*piStack_14 + 4))();
          LOCK();
          piVar8 = piStack_14 + 2;
          iVar10 = *piVar8;
          *piVar8 = *piVar8 + -1;
          UNLOCK();
          if (iVar10 == 1) {
            (**(code **)(*piStack_14 + 8))();
          }
        }
      }
      FUN_006511a0();
      FUN_0056cfd0();
    }
    else {
      FUN_00d82750(aiStack_f4,auStack_38,&DAT_01d79f98,0,0);
    }
    if (0xf < uStack_24) {
      uVar11 = uStack_24 + 1;
      uVar15 = auStack_38[0];
      if (0xfff < uVar11) {
        uVar15 = *(uint *)(auStack_38[0] - 4);
        uVar11 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar15) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar15,uVar11);
    }
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    if (0xf < uStack_e0) {
      uVar15 = uStack_e0 + 1;
      iVar10 = aiStack_f4[0];
      if (0xfff < uVar15) {
        iVar10 = *(int *)(aiStack_f4[0] + -4);
        uVar15 = uStack_e0 + 0x24;
        if (0x1f < (aiStack_f4[0] - iVar10) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar10,uVar15);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13514 ; VA 0x0087a3e0 ; FUN_0087a3e0 */

void FUN_0087a3e0(undefined4 param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000030;
  uint in_stack_00000034;
  undefined auStack_5c [16];
  undefined4 uStack_4c;
  undefined *puStack_48;
  undefined auStack_44 [12];
  undefined4 uStack_38;
  uint uStack_34;
  int *piStack_30;
  int iStack_24;
  int *piStack_20;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b9800;
  pvStack_10 = ExceptionList;
  piStack_30 = &iStack_24;
  uStack_8 = 2;
  uStack_34 = 0x87a40d;
  ExceptionList = &pvStack_10;
  FUN_00876840();
  uStack_8._0_1_ = 3;
  if (iStack_24 != 0) {
    puStack_14 = auStack_44;
    puStack_18 = auStack_44;
    puStack_48 = &stack0x00000038;
    uStack_4c = 0x87a42f;
    FUN_0060e660();
    puStack_18 = auStack_5c;
    uStack_8._0_1_ = 4;
    FUN_0054ef60(&stack0x00000020);
    uStack_8._0_1_ = 5;
    FUN_0054ef60(&param_2);
    uStack_8._0_1_ = 3;
    FUN_0087a6f0(param_1);
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_20[1] + -1;
    piStack_20[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      piStack_30 = (int *)0x87a47d;
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_30 = (int *)0x87a48c;
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  if (0xf < in_stack_0000001c) {
    piStack_30 = (int *)(in_stack_0000001c + 1);
    uVar3 = param_2;
    if (0xfff < piStack_30) {
      uVar3 = *(uint *)(param_2 - 4);
      piStack_30 = (int *)(in_stack_0000001c + 0x24);
      if (0x1f < (param_2 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        piStack_30 = (int *)0x87a52d;
        FUN_017167a3();
      }
    }
    uStack_38 = 0x87a4b9;
    uStack_34 = uVar3;
    FUN_01674ea0();
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (0xf < in_stack_00000034) {
    piStack_30 = (int *)(in_stack_00000034 + 1);
    uVar3 = in_stack_00000020;
    if (0xfff < piStack_30) {
      uVar3 = *(uint *)(in_stack_00000020 - 4);
      piStack_30 = (int *)(in_stack_00000034 + 0x24);
      if (0x1f < (in_stack_00000020 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        piStack_30 = (int *)&UNK_0087a532;
        FUN_017167a3();
      }
    }
    uStack_38 = 0x87a4fb;
    uStack_34 = uVar3;
    FUN_01674ea0();
  }
  in_stack_00000030 = 0;
  in_stack_00000034 = 0xf;
  in_stack_00000020 = in_stack_00000020 & 0xffffff00;
  piStack_30 = (int *)0x87a518;
  FUN_0056cfd0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13515 ; VA 0x0087a540 ; FUN_0087a540 */

void FUN_0087a540(uint param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_0000002c;
  uint in_stack_00000030;
  uint in_stack_00000034;
  undefined4 in_stack_00000044;
  uint in_stack_00000048;
  undefined auStack_78 [16];
  undefined4 uStack_68;
  undefined4 *puStack_64;
  undefined auStack_60 [16];
  undefined4 uStack_50;
  undefined *puStack_4c;
  undefined auStack_48 [12];
  undefined4 uStack_3c;
  uint uStack_38;
  int *piStack_34;
  int iStack_28;
  int *piStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b9850;
  pvStack_10 = ExceptionList;
  piStack_34 = &iStack_28;
  uStack_8 = 3;
  uStack_38 = 0x87a56d;
  ExceptionList = &pvStack_10;
  FUN_00876840();
  uStack_8._0_1_ = 4;
  if (iStack_28 != 0) {
    puStack_14 = auStack_48;
    puStack_18 = auStack_48;
    puStack_4c = &stack0x0000004c;
    uStack_50 = 0x87a58f;
    FUN_0060e660();
    puStack_18 = auStack_60;
    uStack_8._0_1_ = 5;
    puStack_64 = &stack0x00000034;
    uStack_68 = 0x87a5a4;
    FUN_0054ef60();
    puStack_1c = auStack_78;
    uStack_8._0_1_ = 6;
    FUN_0054ef60(&stack0x0000001c);
    uStack_8._0_1_ = 7;
    FUN_0054ef60(&param_1);
    uStack_8._0_1_ = 4;
    FUN_0087a9a0();
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_24[1] + -1;
    piStack_24[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      piStack_34 = (int *)0x87a5ef;
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piStack_24 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_34 = (int *)0x87a5fe;
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000018) {
    piStack_34 = (int *)(in_stack_00000018 + 1);
    uVar3 = param_1;
    if (0xfff < piStack_34) {
      uVar3 = *(uint *)(param_1 - 4);
      piStack_34 = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_1 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        piStack_34 = (int *)0x87a6e5;
        FUN_017167a3();
      }
    }
    uStack_3c = 0x87a62f;
    uStack_38 = uVar3;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  if (0xf < in_stack_00000030) {
    piStack_34 = (int *)(in_stack_00000030 + 1);
    uVar3 = in_stack_0000001c;
    if (0xfff < piStack_34) {
      uVar3 = *(uint *)(in_stack_0000001c - 4);
      piStack_34 = (int *)(in_stack_00000030 + 0x24);
      if (0x1f < (in_stack_0000001c - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        piStack_34 = (int *)0x87a6ea;
        FUN_017167a3();
      }
    }
    uStack_3c = 0x87a671;
    uStack_38 = uVar3;
    FUN_01674ea0();
  }
  in_stack_0000002c = 0;
  in_stack_00000030 = 0xf;
  in_stack_0000001c = in_stack_0000001c & 0xffffff00;
  if (0xf < in_stack_00000048) {
    piStack_34 = (int *)(in_stack_00000048 + 1);
    uVar3 = in_stack_00000034;
    if (0xfff < piStack_34) {
      uVar3 = *(uint *)(in_stack_00000034 - 4);
      piStack_34 = (int *)(in_stack_00000048 + 0x24);
      if (0x1f < (in_stack_00000034 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        piStack_34 = (int *)&UNK_0087a6ef;
        FUN_017167a3();
      }
    }
    uStack_3c = 0x87a6b3;
    uStack_38 = uVar3;
    FUN_01674ea0();
  }
  in_stack_00000044 = 0;
  in_stack_00000048 = 0xf;
  in_stack_00000034 = in_stack_00000034 & 0xffffff00;
  piStack_34 = (int *)0x87a6d0;
  FUN_0056cfd0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13516 ; VA 0x0087a6f0 ; FUN_0087a6f0 */

void __thiscall FUN_0087a6f0(int param_1,char *param_2,uint param_3)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  undefined4 ***pppuVar5;
  char *pcVar6;
  uint uVar7;
  char *pcVar8;
  char *pcVar9;
  int in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_00000020;
  int in_stack_00000030;
  uint in_stack_00000034;
  undefined uVar10;
  undefined auStack_134 [16];
  undefined4 uStack_124;
  undefined4 *puStack_120;
  undefined auStack_11c [16];
  undefined4 uStack_10c;
  int iStack_108;
  undefined auStack_104 [4];
  undefined4 uStack_100;
  undefined4 *puStack_fc;
  undefined *puStack_f8;
  undefined4 uStack_f4;
  undefined *puStack_f0;
  undefined auStack_ec [8];
  undefined4 uStack_e4;
  undefined4 **ppuStack_e0;
  undefined *puStack_dc;
  undefined4 **ppuStack_d8;
  undefined auStack_60 [24];
  undefined *puStack_48;
  undefined *puStack_44;
  undefined *puStack_40;
  undefined *puStack_3c;
  undefined4 **appuStack_38 [5];
  uint uStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017b98b3;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000018 != 0) && (ExceptionList = &pvStack_10, in_stack_00000030 != 0)) {
    ppuStack_d8 = (undefined4 **)param_2;
    puStack_dc = (undefined *)0x87a736;
    ExceptionList = &pvStack_10;
    iVar4 = FUN_008f7870();
    if (iVar4 != 0) {
      piVar1 = *(int **)(iVar4 + 0x454);
      piVar2 = *(int **)(iVar4 + 0x43c);
      puStack_3c = auStack_ec;
      param_2 = auStack_ec;
      iStack_18 = *piVar1 - (int)piVar1;
      iStack_14 = piVar1[1] - (int)piVar1;
      iStack_20 = *piVar2 - (int)piVar2;
      iStack_1c = piVar2[1] - (int)piVar2;
      puStack_f0 = &stack0x00000038;
      uStack_f4 = 0x87a782;
      FUN_0060e660();
      puStack_40 = auStack_104;
      param_2 = auStack_104;
      uStack_8 = 3;
      iStack_108 = param_1 + 0x18;
      uStack_10c = 0x87a79a;
      FUN_0060e660();
      puStack_44 = auStack_11c;
      uStack_8 = 4;
      puStack_120 = &stack0x00000020;
      uStack_124 = 0x87a7af;
      FUN_0054ef60();
      puStack_48 = auStack_134;
      uStack_8 = 5;
      FUN_0054ef60(&param_3);
      uStack_8 = 6;
      cVar3 = FUN_0097c970(iVar4 + 0xc,1);
      pcVar9 = "client";
      pcVar8 = "client";
      if (cVar3 == '\0') {
        pcVar8 = "RCC";
      }
      param_2 = pcVar8 + 1;
      uVar10 = 0;
      pcVar6 = pcVar8;
      do {
        cVar3 = *pcVar6;
        pcVar6 = pcVar6 + 1;
      } while (cVar3 != '\0');
      FUN_005542c0(pcVar8,(int)pcVar6 - (int)param_2);
      uStack_8 = 2;
      FUN_00d83bf0(appuStack_38,iStack_20,iStack_1c,iStack_18,iStack_14,uVar10);
      pppuVar5 = appuStack_38;
      if (0xf < uStack_24) {
        pppuVar5 = (undefined4 ***)appuStack_38[0];
      }
      uStack_8 = 7;
      cVar3 = FUN_014cd610(pppuVar5,0);
      if (cVar3 != '\0') {
        ppuStack_d8 = (undefined4 **)0x1;
        ppuStack_e0 = (undefined4 **)0x87a859;
        puStack_dc = (undefined *)(iVar4 + 0xc);
        cVar3 = FUN_0097c970();
        if (cVar3 == '\0') {
          pcVar9 = "RCC";
        }
        puStack_dc = (undefined *)0x87a86f;
        ppuStack_d8 = (undefined4 **)pcVar9;
        FUN_0054eff0();
        ppuStack_d8 = appuStack_38;
        uStack_8 = 8;
        puStack_dc = auStack_60;
        ppuStack_e0 = (undefined4 **)0x87a880;
        _guard_check_icall();
        uStack_8 = 7;
        ppuStack_d8 = (undefined4 **)0x87a88f;
        FUN_005507b0();
        ppuStack_d8 = (undefined4 **)0x0;
        puStack_dc = (undefined *)0x17;
        ppuStack_e0 = appuStack_38;
        uStack_e4 = 0x87a8a2;
        FUN_014cc090();
        ppuStack_d8 = (undefined4 **)0x0;
        uStack_8 = 9;
        puStack_fc = &param_2;
        param_2 = (char *)((uint)param_2 & 0xffffff00);
        uStack_100 = 0x87a8ba;
        cVar3 = FUN_00585a40();
        if (cVar3 == '\0') {
          puStack_f8 = &DAT_0191c665;
        }
        else {
          puStack_f8 = (undefined *)0x0;
        }
        puStack_fc = (undefined4 *)0x87a8de;
        FUN_014ccc70();
        ppuStack_d8 = (undefined4 **)0x87a8e9;
        FUN_0056db40();
      }
      ppuStack_d8 = (undefined4 **)0x87a8f1;
      FUN_005507b0();
    }
  }
  if (0xf < in_stack_0000001c) {
    ppuStack_d8 = (undefined4 **)(in_stack_0000001c + 1);
    uVar7 = param_3;
    if (0xfff < ppuStack_d8) {
      uVar7 = *(uint *)(param_3 - 4);
      ppuStack_d8 = (undefined4 **)(in_stack_0000001c + 0x24);
      if (0x1f < (param_3 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        ppuStack_d8 = (undefined4 **)0x87a995;
        FUN_017167a3();
      }
    }
    ppuStack_e0 = (undefined4 ***)0x87a91e;
    puStack_dc = (undefined *)uVar7;
    FUN_01674ea0();
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (0xf < in_stack_00000034) {
    ppuStack_d8 = (undefined4 **)(in_stack_00000034 + 1);
    uVar7 = in_stack_00000020;
    if (0xfff < ppuStack_d8) {
      uVar7 = *(uint *)(in_stack_00000020 - 4);
      ppuStack_d8 = (undefined4 **)(in_stack_00000034 + 0x24);
      if (0x1f < (in_stack_00000020 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        ppuStack_d8 = (undefined4 **)&UNK_0087a99a;
        FUN_017167a3();
      }
    }
    ppuStack_e0 = (undefined4 ***)0x87a960;
    puStack_dc = (undefined *)uVar7;
    FUN_01674ea0();
  }
  in_stack_00000030 = 0;
  in_stack_00000034 = 0xf;
  in_stack_00000020 = in_stack_00000020 & 0xffffff00;
  ppuStack_d8 = (undefined4 **)0x87a97d;
  FUN_0056cfd0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13517 ; VA 0x0087a9a0 ; FUN_0087a9a0 */

void __thiscall FUN_0087a9a0(int param_1,uint param_2)

{
  char cVar1;
  undefined4 ***pppuVar2;
  uint uVar3;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  int in_stack_0000002c;
  uint in_stack_00000030;
  uint in_stack_00000034;
  int in_stack_00000044;
  uint in_stack_00000048;
  undefined auStack_10c [16];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined auStack_f4 [4];
  undefined4 uStack_f0;
  undefined *puStack_ec;
  undefined *puStack_e8;
  undefined4 uStack_e4;
  undefined *puStack_e0;
  undefined auStack_dc [8];
  undefined4 uStack_d4;
  undefined4 **ppuStack_d0;
  undefined4 *puStack_cc;
  undefined4 **ppuStack_c8;
  undefined4 **appuStack_50 [4];
  uint uStack_40;
  uint uStack_3c;
  undefined4 **appuStack_38 [5];
  uint uStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017b991b;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if ((in_stack_0000002c != 0) && (ExceptionList = &pvStack_10, in_stack_00000044 != 0)) {
    ppuStack_c8 = (undefined4 **)0x87a9e1;
    ExceptionList = &pvStack_10;
    ppuStack_c8 = (undefined4 **)FUN_0151b370();
    puStack_cc = (undefined4 *)0x87a9ea;
    FUN_0054ef60();
    uStack_8 = 4;
    if (uStack_40 != 0) {
      if (uStack_40 <= uStack_40 - 1) {
        ppuStack_c8 = (undefined4 **)0x87ac17;
        FUN_00554050();
        goto LAB_0087ac17;
      }
      pppuVar2 = appuStack_50;
      if (0xf < uStack_3c) {
        pppuVar2 = (undefined4 ***)appuStack_50[0];
      }
      if (*(char *)((int)pppuVar2 + (uStack_40 - 1)) != '/') {
        ppuStack_c8 = (undefined4 **)0x2f;
        puStack_cc = (undefined4 *)0x87aa1b;
        FUN_005558a0();
      }
    }
    puStack_18 = auStack_dc;
    puStack_e0 = &stack0x0000004c;
    uStack_e4 = 0x87aa2f;
    FUN_0060e660();
    puStack_18 = auStack_f4;
    puStack_1c = auStack_f4;
    uStack_8 = 5;
    iStack_f8 = param_1 + 0x18;
    uStack_fc = 0x87aa47;
    FUN_0060e660();
    puStack_1c = auStack_10c;
    uStack_8 = 6;
    FUN_0054ef60();
    uStack_8 = 7;
    FUN_0054ef60(&stack0x0000001c);
    uStack_8 = 8;
    FUN_0054ef60(&param_2);
    uStack_8 = 4;
    FUN_00d84980(appuStack_38);
    pppuVar2 = appuStack_38;
    if (0xf < uStack_24) {
      pppuVar2 = (undefined4 ***)appuStack_38[0];
    }
    uStack_8 = 9;
    cVar1 = FUN_014cd610(pppuVar2,0);
    if (cVar1 != '\0') {
      ppuStack_c8 = appuStack_38;
      puStack_cc = &param_2;
      ppuStack_d0 = (undefined4 **)0x87aabe;
      _guard_check_icall();
      ppuStack_d0 = appuStack_38;
      ppuStack_c8 = (undefined4 **)0x0;
      puStack_cc = (undefined4 *)0x17;
      uStack_d4 = 0x87aad4;
      FUN_014cc090();
      ppuStack_c8 = (undefined4 **)0x0;
      uStack_8 = 10;
      puStack_ec = auStack_14;
      auStack_14[0] = 0;
      uStack_f0 = 0x87aaec;
      cVar1 = FUN_00585a40();
      if (cVar1 == '\0') {
        puStack_e8 = &DAT_0191c65d;
      }
      else {
        puStack_e8 = (undefined *)0x0;
      }
      puStack_ec = (undefined *)0x87ab10;
      FUN_014ccc70();
      ppuStack_c8 = (undefined4 **)0x87ab1b;
      FUN_0056db40();
    }
    ppuStack_c8 = (undefined4 **)0x87ab23;
    FUN_005507b0();
    ppuStack_c8 = (undefined4 **)0x87ab2b;
    FUN_005507b0();
  }
  if (0xf < in_stack_00000018) {
    ppuStack_c8 = (undefined4 **)(in_stack_00000018 + 1);
    uVar3 = param_2;
    if (0xfff < ppuStack_c8) {
      uVar3 = *(uint *)(param_2 - 4);
      ppuStack_c8 = (undefined4 **)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - uVar3) - 4) {
LAB_0087ac17:
                    /* WARNING: Subroutine does not return */
        ppuStack_c8 = (undefined4 **)0x87ac1c;
        FUN_017167a3();
      }
    }
    ppuStack_d0 = (undefined4 ***)0x87ab5c;
    puStack_cc = (undefined4 *)uVar3;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (0xf < in_stack_00000030) {
    ppuStack_c8 = (undefined4 **)(in_stack_00000030 + 1);
    uVar3 = in_stack_0000001c;
    if (0xfff < ppuStack_c8) {
      uVar3 = *(uint *)(in_stack_0000001c - 4);
      ppuStack_c8 = (undefined4 **)(in_stack_00000030 + 0x24);
      if (0x1f < (in_stack_0000001c - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        ppuStack_c8 = (undefined4 **)0x87ac21;
        FUN_017167a3();
      }
    }
    ppuStack_d0 = (undefined4 ***)0x87aba2;
    puStack_cc = (undefined4 *)uVar3;
    FUN_01674ea0();
  }
  in_stack_0000002c = 0;
  in_stack_00000030 = 0xf;
  in_stack_0000001c = in_stack_0000001c & 0xffffff00;
  if (0xf < in_stack_00000048) {
    ppuStack_c8 = (undefined4 **)(in_stack_00000048 + 1);
    uVar3 = in_stack_00000034;
    if (0xfff < ppuStack_c8) {
      uVar3 = *(uint *)(in_stack_00000034 - 4);
      ppuStack_c8 = (undefined4 **)(in_stack_00000048 + 0x24);
      if (0x1f < (in_stack_00000034 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        ppuStack_c8 = (undefined4 **)&UNK_0087ac26;
        FUN_017167a3();
      }
    }
    ppuStack_d0 = (undefined4 ***)0x87abe4;
    puStack_cc = (undefined4 *)uVar3;
    FUN_01674ea0();
  }
  in_stack_00000044 = 0;
  in_stack_00000048 = 0xf;
  in_stack_00000034 = in_stack_00000034 & 0xffffff00;
  ppuStack_c8 = (undefined4 **)0x87ac01;
  FUN_0056cfd0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13518 ; VA 0x0087ac30 ; FUN_0087ac30 */

void FUN_0087ac30(uint param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_0000002c;
  uint in_stack_00000030;
  uint in_stack_00000034;
  undefined4 in_stack_00000044;
  uint in_stack_00000048;
  undefined auStack_78 [16];
  undefined4 uStack_68;
  undefined4 *puStack_64;
  undefined auStack_60 [16];
  undefined4 uStack_50;
  undefined *puStack_4c;
  undefined auStack_48 [12];
  undefined4 uStack_3c;
  uint uStack_38;
  int *piStack_34;
  int iStack_28;
  int *piStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b9850;
  pvStack_10 = ExceptionList;
  piStack_34 = &iStack_28;
  uStack_8 = 3;
  uStack_38 = 0x87ac5d;
  ExceptionList = &pvStack_10;
  FUN_00876840();
  uStack_8._0_1_ = 4;
  if (iStack_28 != 0) {
    puStack_14 = auStack_48;
    puStack_18 = auStack_48;
    puStack_4c = &stack0x0000004c;
    uStack_50 = 0x87ac7f;
    FUN_0060e660();
    puStack_18 = auStack_60;
    uStack_8._0_1_ = 5;
    puStack_64 = &stack0x00000034;
    uStack_68 = 0x87ac94;
    FUN_0054ef60();
    puStack_1c = auStack_78;
    uStack_8._0_1_ = 6;
    FUN_0054ef60(&stack0x0000001c);
    uStack_8._0_1_ = 7;
    FUN_0054ef60(&param_1);
    uStack_8._0_1_ = 4;
    FUN_0087ade0();
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_24[1] + -1;
    piStack_24[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      piStack_34 = (int *)0x87acdf;
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piStack_24 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_34 = (int *)0x87acee;
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000018) {
    piStack_34 = (int *)(in_stack_00000018 + 1);
    uVar3 = param_1;
    if (0xfff < piStack_34) {
      uVar3 = *(uint *)(param_1 - 4);
      piStack_34 = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_1 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        piStack_34 = (int *)0x87add5;
        FUN_017167a3();
      }
    }
    uStack_3c = 0x87ad1f;
    uStack_38 = uVar3;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  if (0xf < in_stack_00000030) {
    piStack_34 = (int *)(in_stack_00000030 + 1);
    uVar3 = in_stack_0000001c;
    if (0xfff < piStack_34) {
      uVar3 = *(uint *)(in_stack_0000001c - 4);
      piStack_34 = (int *)(in_stack_00000030 + 0x24);
      if (0x1f < (in_stack_0000001c - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        piStack_34 = (int *)0x87adda;
        FUN_017167a3();
      }
    }
    uStack_3c = 0x87ad61;
    uStack_38 = uVar3;
    FUN_01674ea0();
  }
  in_stack_0000002c = 0;
  in_stack_00000030 = 0xf;
  in_stack_0000001c = in_stack_0000001c & 0xffffff00;
  if (0xf < in_stack_00000048) {
    piStack_34 = (int *)(in_stack_00000048 + 1);
    uVar3 = in_stack_00000034;
    if (0xfff < piStack_34) {
      uVar3 = *(uint *)(in_stack_00000034 - 4);
      piStack_34 = (int *)(in_stack_00000048 + 0x24);
      if (0x1f < (in_stack_00000034 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        piStack_34 = (int *)&UNK_0087addf;
        FUN_017167a3();
      }
    }
    uStack_3c = 0x87ada3;
    uStack_38 = uVar3;
    FUN_01674ea0();
  }
  in_stack_00000044 = 0;
  in_stack_00000048 = 0xf;
  in_stack_00000034 = in_stack_00000034 & 0xffffff00;
  piStack_34 = (int *)0x87adc0;
  FUN_0056cfd0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13519 ; VA 0x0087ade0 ; FUN_0087ade0 */

void FUN_0087ade0(uint param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_0000002c;
  uint in_stack_00000030;
  uint in_stack_00000034;
  undefined4 in_stack_00000044;
  uint in_stack_00000048;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 uVar9;
  undefined4 *puVar10;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b9958;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_8 = 4;
  puVar8 = &stack0x00000034;
  puVar7 = &stack0x0000001c;
  puVar6 = &param_1;
  uVar5 = 0x87ae34;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00874fb0(puVar6,puVar7,puVar8,&stack0x0000004c,auStack_2c);
  if (cVar1 != '\0') {
    FUN_00872d70(&param_1);
    FUN_008777f0(auStack_2c);
    puVar8 = (undefined4 *)0x87ae5c;
    _guard_check_icall(&param_1,auStack_2c);
  }
  if (0 < (int)DAT_01d62594) {
    puVar10 = &param_1;
    uVar9 = 0x87ae73;
    iVar2 = FUN_00872d70(puVar10);
    if (DAT_01d62594 <= *(uint *)(iVar2 + 0x28)) {
      FUN_0054ef60(&param_1);
      FUN_008779e0(uVar5,puVar6,puVar7,puVar8,uVar9,puVar10);
    }
  }
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    uVar3 = auStack_2c[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_2c[0] - 4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  if (0xf < in_stack_00000018) {
    uVar4 = in_stack_00000018 + 1;
    uVar3 = param_1;
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(param_1 - 4);
      uVar4 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  if (0xf < in_stack_00000030) {
    uVar4 = in_stack_00000030 + 1;
    uVar3 = in_stack_0000001c;
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(in_stack_0000001c - 4);
      uVar4 = in_stack_00000030 + 0x24;
      if (0x1f < (in_stack_0000001c - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  in_stack_0000002c = 0;
  in_stack_00000030 = 0xf;
  in_stack_0000001c = in_stack_0000001c & 0xffffff00;
  if (0xf < in_stack_00000048) {
    uVar4 = in_stack_00000048 + 1;
    uVar3 = in_stack_00000034;
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(in_stack_00000034 - 4);
      uVar4 = in_stack_00000048 + 0x24;
      if (0x1f < (in_stack_00000034 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  in_stack_00000044 = 0;
  in_stack_00000048 = 0xf;
  in_stack_00000034 = in_stack_00000034 & 0xffffff00;
  FUN_0056cfd0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13520 ; VA 0x0087afe0 ; FUN_0087afe0 */

void __fastcall FUN_0087afe0(int *param_1)

{
  uint uVar1;
  code *pcVar2;
  undefined4 uVar3;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b8fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00876cb0();
  puStack_18 = (uint *)(*param_1 + 0x24);
  cStack_14 = '\0';
  FUN_00587410();
  uStack_8 = 0;
  if (*(char *)(*param_1 + 0x18) == '\0') {
    FUN_00587e20(&puStack_18);
    uStack_8 = 2;
    if (cStack_14 != '\0') {
      LOCK();
      uVar1 = *puStack_18;
      *puStack_18 = *puStack_18 + 0x80000000;
      UNLOCK();
      if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
        LOCK();
        uVar1 = *puStack_18;
        *puStack_18 = *puStack_18 | 0x40000000;
        UNLOCK();
        if ((uVar1 >> 0x1e & 1) == 0) {
          uVar3 = FUN_00554e40();
          SetEvent(uVar3);
        }
      }
    }
    ExceptionList = pvStack_10;
    return;
  }
  uVar3 = FUN_0056b140();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_005649e0(uVar3);
  pcVar2 = (code *)swi(3);
  (*pcVar2)();
  return;
}



/* FUNCTION 13521 ; VA 0x0087b090 ; FUN_0087b090 */

bool __thiscall FUN_0087b090(int param_1,undefined4 *param_2)

{
  byte *pbVar1;
  byte bVar2;
  int iVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int *piVar7;
  undefined4 ****ppppuVar8;
  undefined4 *puVar9;
  uint uVar10;
  undefined4 *puVar11;
  uint uVar12;
  undefined4 *puVar13;
  undefined auStack_100 [168];
  undefined auStack_58 [24];
  undefined auStack_40 [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 *puStack_34;
  undefined4 ***apppuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar3 = DAT_01d62744;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b99a4;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  puVar5 = &DAT_01d62734;
  if (0xf < DAT_01d62748) {
    puVar5 = DAT_01d62734;
  }
  ExceptionList = &pvStack_10;
  cVar4 = FUN_0055c360(puVar5,DAT_01d62744,&DAT_018bc9b8,0);
  if (cVar4 != '\0') {
    puVar5 = &DAT_01d627ec;
    if (0xf < DAT_01d62800) {
      puVar5 = DAT_01d627ec;
    }
    cVar4 = FUN_0055c360(puVar5,DAT_01d627fc,&DAT_018bc9b8,0);
    if (cVar4 != '\0') {
      ExceptionList = pvStack_10;
      return false;
    }
  }
  if (*(int *)(param_1 + 100) == 0) {
    uStack_8 = 0;
    uStack_20 = 0;
    uStack_1c = 0xf;
    apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
    uStack_18 = 1;
    FUN_0058a190(iVar3 + 1);
    puVar5 = &DAT_01d62734;
    if (0xf < DAT_01d62748) {
      puVar5 = DAT_01d62734;
    }
    FUN_00554150(puVar5,DAT_01d62744);
    FUN_00554150(&DAT_018bf378,1);
    uVar6 = FUN_00558c20(auStack_58,apppuStack_30,&DAT_01d627ec);
    uStack_8._0_1_ = 1;
    FUN_00565000(uVar6,1,1);
    FUN_005507b0();
    FUN_005507b0();
    uStack_20 = 0;
    uStack_1c = 0xf;
    apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    piVar7 = (int *)FUN_00591ab0(auStack_100,apppuStack_30,0x2c);
    bVar2 = *(byte *)(*(int *)(*piVar7 + 4) + 0xc + (int)piVar7);
    while ((bVar2 & 6) == 0) {
      ppppuVar8 = apppuStack_30;
      if (0xf < uStack_1c) {
        ppppuVar8 = (undefined4 ****)apppuStack_30[0];
      }
      cVar4 = FUN_0055c360(ppppuVar8,uStack_20,&DAT_018bc9b8,0);
      if (cVar4 == '\0') {
        FUN_00870280(auStack_40,apppuStack_30,param_2);
      }
      piVar7 = (int *)FUN_00591ab0(auStack_100,apppuStack_30,0x2c);
      bVar2 = *(byte *)(*(int *)(*piVar7 + 4) + 0xc + (int)piVar7);
    }
    FUN_005507b0();
    FUN_005703e0();
  }
  puStack_14 = param_2;
  uStack_18 = param_2[4];
  if (0xf < (uint)param_2[5]) {
    puStack_14 = (undefined4 *)*param_2;
  }
  uVar10 = 0;
  uVar12 = 0x811c9dc5;
  if (uStack_18 != 0) {
    do {
      pbVar1 = (byte *)(uVar10 + (int)puStack_14);
      uVar10 = uVar10 + 1;
      uVar12 = (*pbVar1 ^ uVar12) * 0x1000193;
    } while (uVar10 < uStack_18);
  }
  uVar12 = *(uint *)(param_1 + 0x74) & uVar12;
  puVar5 = *(undefined4 **)(param_1 + 0x60);
  puVar13 = *(undefined4 **)(*(int *)(param_1 + 0x68) + uVar12 * 8);
  puStack_34 = (undefined4 *)(uVar12 * 8 + 4 + *(int *)(param_1 + 0x68));
  puStack_14 = puVar13;
  while( true ) {
    puVar9 = puVar5;
    if (puStack_14 != puVar5) {
      puVar9 = *(undefined4 **)*puStack_34;
    }
    puVar11 = puVar5;
    if (puVar13 == puVar9) goto LAB_0087b340;
    piVar7 = puVar13 + 2;
    puVar9 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar9 = (undefined4 *)*param_2;
    }
    uStack_38 = puVar13[7];
    uStack_3c = puVar13[6];
    if (0xf < uStack_38) {
      piVar7 = (int *)*piVar7;
    }
    cVar4 = FUN_0055c360(piVar7,uStack_3c,puVar9,uStack_18);
    if (cVar4 != '\0') break;
    puVar13 = (undefined4 *)*puVar13;
  }
  piVar7 = puVar13 + 2;
  if (0xf < uStack_38) {
    piVar7 = (int *)*piVar7;
  }
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  cVar4 = FUN_0055c360(param_2,uStack_18,piVar7,uStack_3c);
  if (cVar4 != '\0') {
    puVar11 = puVar13;
  }
LAB_0087b340:
  ExceptionList = pvStack_10;
  return puVar11 != puVar5;
}



/* FUNCTION 13522 ; VA 0x0087b360 ; FUN_0087b360 */

int FUN_0087b360(void)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b99c0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((DAT_020c0b1c != '\0') && (ExceptionList = &pvStack_10, DAT_01d6271c != '\0')) {
    ExceptionList = &pvStack_10;
    FUN_014d27d0();
  }
  FUN_00876700(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    FUN_0087b440();
  }
  uStack_8 = 0xffffffff;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar3 = piStack_14[2] + -1;
      piStack_14[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  iVar3 = FUN_00876840(&iStack_20);
  uStack_8 = 1;
  if (iStack_20 != 0) {
    iVar3 = FUN_0087b530();
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 13523 ; VA 0x0087b440 ; FUN_0087b440 */

void __fastcall FUN_0087b440(int param_1)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179de58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00878d80();
  if (DAT_01d62764 != '\0') {
    iVar3 = FUN_016dee6d(param_1 + 0xb0);
    if (iVar3 != 0) {
      FUN_016df3c9(iVar3);
    }
    uStack_8 = 0;
    cVar2 = FUN_0056f530();
    if (cVar2 != '\0') {
      FUN_01534c60();
      uVar4 = FUN_0075dc70();
      FUN_0056ecd0(uVar4);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_18[1] + -1;
        piStack_18[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar1 = piStack_18 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
    uStack_8 = 1;
    iVar3 = FUN_016deec8(param_1 + 0xb0);
    if (iVar3 != 0) {
      FUN_016df3c9(iVar3);
    }
    uStack_8 = 0xffffffff;
    FUN_00875af0(0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13524 ; VA 0x0087b530 ; FUN_0087b530 */

/* WARNING: Removing unreachable block (ram,0x0087b5ec) */
/* WARNING: Removing unreachable block (ram,0x0087b5ff) */
/* WARNING: Removing unreachable block (ram,0x0087b606) */
/* WARNING: Removing unreachable block (ram,0x0087b60d) */

void __fastcall FUN_0087b530(int param_1)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined auStack_18 [4];
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b99e0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  if (*(char *)(*(int *)(param_1 + 0x48) + 8) == '\0') {
    *(undefined *)(*(int *)(param_1 + 0x48) + 8) = 1;
    FUN_0058c660();
    FUN_00588350();
    cVar1 = FUN_0168a370();
    if (cVar1 != '\0') {
      piVar2 = (int *)FUN_01689dd0(auStack_14);
      piVar3 = (int *)FUN_01689df0(auStack_18);
      if (*piVar2 == *piVar3) {
        uVar4 = FUN_0056b4a0(0x24,"boost thread: trying joining itself");
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
        FUN_0054e630(uVar4);
      }
      FUN_0168a200();
    }
  }
  else if (DAT_01ede472 != '\0') {
    FUN_016774b0(DAT_01ede472,"Request shutdown early return because already requested",0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13525 ; VA 0x0087b650 ; FUN_0087b650 */

undefined4 __thiscall
FUN_0087b650(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined auStack_34 [4];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b9a00;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  puVar1 = (undefined4 *)(param_1 + 0x38);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (puVar1 != &uStack_1c) {
    uStack_1c = *puVar1;
    ExceptionList = &pvStack_10;
    *puVar1 = 0;
    uStack_18 = *(undefined4 *)(param_1 + 0x3c);
    *(undefined4 *)(param_1 + 0x3c) = 0;
    uStack_14 = *(undefined4 *)(param_1 + 0x40);
    *(undefined4 *)(param_1 + 0x40) = 0;
  }
  auStack_34[0] = 0;
  uVar2 = FUN_00588320(0xb);
  uStack_20 = *(undefined4 *)(param_1 + 0x58);
  *(undefined4 *)(param_1 + 0x58) = 0;
  uStack_30 = *(undefined4 *)(param_1 + 0x48);
  *(undefined4 *)(param_1 + 0x48) = uVar2;
  uStack_2c = *(undefined4 *)(param_1 + 0x4c);
  *(undefined4 *)(param_1 + 0x4c) = 0;
  uStack_28 = *(undefined4 *)(param_1 + 0x50);
  *(undefined4 *)(param_1 + 0x50) = 0x3f800000;
  uStack_24 = *(undefined4 *)(param_1 + 0x54);
  *(undefined4 *)(param_1 + 0x54) = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *(undefined4 *)(param_1 + 0x10) = 0xffffffff;
  *(undefined4 *)(param_1 + 0x14) = 0x7fffffff;
  FUN_0058c660();
  FUN_00879be0(param_2,&uStack_1c,auStack_34,param_4);
  FUN_005d1280();
  FUN_0056d3e0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 13526 ; VA 0x0087b760 ; FUN_0087b760 */

void __fastcall FUN_0087b760(int *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  char cVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined auStack_34 [12];
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9a30;
  pvStack_10 = ExceptionList;
  if (*(char *)(*param_1 + 8) == '\0') {
    piStack_18 = param_1 + 2;
    ExceptionList = &pvStack_10;
    piVar4 = (int *)FUN_01689df0(&uStack_1c);
    if (*piVar4 == 0) {
      if (DAT_01ede471 != '\0') {
        FUN_016774b0(DAT_01ede471,"Starting DeferredEphemeral timer thread",0);
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[1] = piVar4[1] + 1;
        UNLOCK();
        piVar4 = (int *)param_1[1];
      }
      iStack_24 = *param_1;
      uStack_8 = 0;
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[1] = piVar4[1] + 1;
        UNLOCK();
      }
      piStack_20 = piVar4;
      uVar5 = FUN_00870b20(auStack_34,uStack_1c,FUN_0087ba80,param_1,iStack_24,piVar4);
      uStack_8._0_1_ = 1;
      puStack_14 = (undefined4 *)FUN_00870da0(uVar5);
      if (puStack_14 != (undefined4 *)0x0) {
        LOCK();
        puStack_14[1] = puStack_14[1] + 1;
        UNLOCK();
      }
      uStack_8._0_1_ = 3;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_28[1] + -1;
        piStack_28[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          iVar1 = piStack_28[2] + -1;
          piStack_28[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piStack_28 + 4))();
          }
        }
      }
      cVar3 = FUN_0168a8f0();
      if (cVar3 == '\0') {
        uVar5 = FUN_005503c0();
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
        FUN_0054e630(uVar5);
      }
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar1 = piVar4[1] + -1;
        piVar4[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar1 = piVar4[2] + -1;
          piVar4[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      FUN_005e0cb0(&puStack_14);
      uStack_8 = 5;
      FUN_016899e0();
      puVar2 = puStack_14;
      if (puStack_14 != (undefined4 *)0x0) {
        LOCK();
        piVar4 = puStack_14 + 1;
        iVar1 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)*puStack_14)(0);
          uVar5 = GetProcessHeap(0,puVar2);
          HeapFree(uVar5);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13527 ; VA 0x0087b8f0 ; FUN_0087b8f0 */

void __fastcall FUN_0087b8f0(int *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  char cVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined auStack_34 [12];
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9a60;
  pvStack_10 = ExceptionList;
  if (*(char *)(*param_1 + 8) == '\0') {
    piStack_18 = param_1 + 8;
    ExceptionList = &pvStack_10;
    piVar4 = (int *)FUN_01689df0(&uStack_1c);
    if (*piVar4 == 0) {
      if (DAT_01ede472 != '\0') {
        FUN_016774b0(DAT_01ede472,"Starting DeferredReporter timer thread",0);
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[1] = piVar4[1] + 1;
        UNLOCK();
        piVar4 = (int *)param_1[1];
      }
      iStack_24 = *param_1;
      uStack_8 = 0;
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[1] = piVar4[1] + 1;
        UNLOCK();
      }
      piStack_20 = piVar4;
      uVar5 = FUN_00870b20(auStack_34,uStack_1c,FUN_0087c1d0,param_1,iStack_24,piVar4);
      uStack_8._0_1_ = 1;
      puStack_14 = (undefined4 *)FUN_00870e70(uVar5);
      if (puStack_14 != (undefined4 *)0x0) {
        LOCK();
        puStack_14[1] = puStack_14[1] + 1;
        UNLOCK();
      }
      uStack_8._0_1_ = 3;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_28[1] + -1;
        piStack_28[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          iVar1 = piStack_28[2] + -1;
          piStack_28[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piStack_28 + 4))();
          }
        }
      }
      cVar3 = FUN_0168a8f0();
      if (cVar3 == '\0') {
        uVar5 = FUN_005503c0();
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
        FUN_0054e630(uVar5);
      }
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar1 = piVar4[1] + -1;
        piVar4[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar1 = piVar4[2] + -1;
          piVar4[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      FUN_005e0cb0(&puStack_14);
      uStack_8 = 5;
      FUN_016899e0();
      puVar2 = puStack_14;
      if (puStack_14 != (undefined4 *)0x0) {
        LOCK();
        piVar4 = puStack_14 + 1;
        iVar1 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)*puStack_14)(0);
          uVar5 = GetProcessHeap(0,puVar2);
          HeapFree(uVar5);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13528 ; VA 0x0087ba80 ; FUN_0087ba80 */

/* WARNING: Removing unreachable block (ram,0x0087bd66) */
/* WARNING: Removing unreachable block (ram,0x0087bfc0) */
/* WARNING: Removing unreachable block (ram,0x0087bbed) */

uint __thiscall FUN_0087ba80(int param_1,uint *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  undefined uVar4;
  longlong *plVar5;
  uint *puVar6;
  uint uVar7;
  uint uVar8;
  undefined ***pppuVar9;
  longlong lVar10;
  undefined8 uVar11;
  undefined4 in_stack_fffffed4;
  undefined4 in_stack_fffffed8;
  uint in_stack_fffffedc;
  undefined4 in_stack_fffffee0;
  int iVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined auStack_104 [8];
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined auStack_f0 [48];
  undefined4 uStack_c0;
  undefined **ppuStack_b8;
  undefined4 *puStack_b4;
  undefined ***pppuStack_94;
  undefined auStack_90 [4];
  int *piStack_8c;
  undefined auStack_88 [4];
  int *piStack_84;
  undefined **ppuStack_80;
  int *piStack_7c;
  int *piStack_74;
  undefined8 uStack_64;
  uint uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  uint uStack_44;
  int iStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined auStack_34 [4];
  uint uStack_30;
  undefined8 uStack_2c;
  uint uStack_24;
  uint *puStack_20;
  char cStack_1c;
  uint *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017b9ae2;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0151a220("DeferredEphemeral TimerThread");
  if ((DAT_020c0b1c == '\0') || (DAT_01d7a7b0 == '\0')) {
    puStack_18 = param_2;
    uStack_14 = uStack_14 & 0xffffff00;
    FUN_00587410();
    iStack_8._0_1_ = 0xd;
    while (*(char *)(param_2 + 2) == '\0') {
      do {
        puVar6 = (uint *)FUN_0168ea80(auStack_104);
        if ((*(int *)(param_1 + 0x14) < (int)puVar6[1]) ||
           ((*(int *)(param_1 + 0x14) <= (int)puVar6[1] && (*(uint *)(param_1 + 0x10) <= *puVar6))))
        break;
        if (DAT_01ede471 != 0) {
          FUN_016774b0(DAT_01ede471,"timerThreadImpl waiting",0);
        }
        if ((*(int *)(param_1 + 0x10) == -1) && (*(int *)(param_1 + 0x14) == 0x7fffffff)) {
          uStack_5c = 0xffffffff;
          uStack_64 = 0;
          uStack_58 = 0xffffffff;
          uStack_54 = CONCAT31(uStack_54._1_3_,1);
          uStack_3c = 0xfffffffe;
          uStack_38 = 0x7fffffff;
          uVar13 = FUN_0056a9c0(0);
          FUN_005672c0(uVar13,&uStack_3c);
          in_stack_fffffed4 = (undefined4)uStack_64;
          in_stack_fffffed8 = uStack_64._4_4_;
          in_stack_fffffedc = uStack_5c;
          FUN_00560fc0(&puStack_18,(undefined4)uStack_64,uStack_64._4_4_,uStack_5c,uStack_58,
                       uStack_54,uStack_50,uStack_4c,uStack_48);
        }
        else {
          FUN_0168ea80(&uStack_44);
          if ((iStack_40 <= *(int *)(param_1 + 0x14)) &&
             ((iStack_40 < *(int *)(param_1 + 0x14) || (uStack_44 < *(uint *)(param_1 + 0x10))))) {
            uStack_2c._4_4_ = *(uint *)(param_1 + 0x10) - uStack_44;
            iVar12 = (*(int *)(param_1 + 0x14) - iStack_40) -
                     (uint)(*(uint *)(param_1 + 0x10) < uStack_44);
            uVar11 = FUN_016f3900(uStack_2c._4_4_,iVar12,1000000,0);
            uStack_24 = (uint)((ulonglong)uVar11 >> 0x20);
            uStack_30 = (uint)uVar11;
            uVar15 = 0;
            uVar14 = 1000000;
            uVar13 = 0x87bfba;
            lVar10 = FUN_016f39b0(uVar11,1000000,0);
            uVar7 = uStack_30;
            uVar8 = uStack_24;
            if (lVar10 < CONCAT44(iVar12,uStack_2c._4_4_)) {
              uVar7 = uStack_30 + 1;
              uVar8 = uStack_24 + (0xfffffffe < uStack_30);
            }
            FUN_005ef740(uVar7,uVar8);
            FUN_00560fc0(&puStack_18,in_stack_fffffed4,in_stack_fffffed8,in_stack_fffffedc,uVar13,
                         uVar11,uVar14,uVar15);
            FUN_0168ea80(auStack_88);
          }
        }
      } while (*(char *)(param_2 + 2) == '\0');
      if (*(char *)(param_2 + 2) != '\0') break;
      if (DAT_01ede471 != 0) {
        FUN_016774b0(DAT_01ede471,"timerThreadImpl sending",0);
      }
      FUN_0087b650(&ppuStack_80,&puStack_18,1);
      piVar2 = piStack_74;
      iStack_8._0_1_ = 0xe;
      if (piStack_74 != (int *)0x0) {
        LOCK();
        iVar12 = piStack_74[1] + -1;
        piStack_74[1] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          (**(code **)(*piStack_74 + 4))();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar12 = *piVar1 + -1;
          *piVar1 = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            (**(code **)(*piVar2 + 8))();
          }
        }
      }
      piVar2 = piStack_7c;
      iStack_8._0_1_ = 0xf;
      if (piStack_7c != (int *)0x0) {
        LOCK();
        iVar12 = piStack_7c[1] + -1;
        piStack_7c[1] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          (**(code **)(*piStack_7c + 4))();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar12 = *piVar1 + -1;
          *piVar1 = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            (**(code **)(*piVar2 + 8))();
          }
        }
      }
      iStack_8._0_1_ = 0xd;
      uVar4 = (undefined)iStack_8;
      iStack_8._0_1_ = 0xd;
      if (puStack_18 == (uint *)0x0) {
        iStack_8._0_1_ = uVar4;
        uVar13 = FUN_0056aeb0(1,"boost unique_lock has no mutex");
        iStack_8 = CONCAT31(iStack_8._1_3_,0x10);
                    /* WARNING: Subroutine does not return */
        FUN_00564990(uVar13);
      }
      if ((char)uStack_14 != '\0') {
        uVar13 = FUN_0056aeb0(0x24,"boost unique_lock owns already the mutex");
        iStack_8 = CONCAT31(iStack_8._1_3_,0x11);
                    /* WARNING: Subroutine does not return */
        FUN_00564990(uVar13);
      }
      FUN_005874f0();
      uStack_14 = CONCAT31(uStack_14._1_3_,1);
    }
    iStack_8._0_1_ = 0x12;
    uStack_2c = CONCAT44(uStack_2c._4_4_,(undefined4)uStack_2c);
    if ((char)uStack_14 != '\0') {
      LOCK();
      uVar7 = *puStack_18;
      *puStack_18 = *puStack_18 + 0x80000000;
      UNLOCK();
      uStack_2c = CONCAT44(uStack_2c._4_4_,(undefined4)uStack_2c);
      if (((uVar7 & 0x40000000) == 0) &&
         (uStack_2c = CONCAT44(uStack_2c._4_4_,(undefined4)uStack_2c), -0x80000000 < (int)uVar7)) {
        LOCK();
        uVar7 = *puStack_18;
        *puStack_18 = *puStack_18 | 0x40000000;
        UNLOCK();
        uStack_2c = CONCAT44(uStack_2c._4_4_,(undefined4)uStack_2c);
        if ((uVar7 >> 0x1e & 1) == 0) {
          uVar13 = FUN_00554e40();
          SetEvent(uVar13);
        }
      }
    }
  }
  else {
    uStack_fc = 0;
    uStack_f8 = 0;
    uStack_f4 = 0;
    FUN_016dee4c(auStack_f0,2);
    puStack_b4 = &uStack_fc;
    uStack_c0 = 0;
    pppuVar9 = &ppuStack_b8;
    ppuStack_b8 = std::
                  _Func_impl_no_alloc<class_<lambda_452f6d49855ace27422a33bc8b4a02f8>,bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&>
                  ::vftable;
    iStack_8 = CONCAT31(iStack_8._1_3_,3);
    iVar12 = 0x87bb32;
    pppuStack_94 = pppuVar9;
    FUN_01521eb0(pppuVar9);
    if (pppuStack_94 != (undefined ***)0x0) {
      (*(code *)(*pppuStack_94)[4])
                (CONCAT31((int3)((uint)&ppuStack_b8 >> 8),pppuStack_94 != &ppuStack_b8));
      pppuStack_94 = (undefined ***)0x0;
    }
    iStack_8._0_1_ = 4;
    FUN_0168ea80(&uStack_2c);
    puStack_20 = param_2;
    cStack_1c = '\0';
    FUN_00587410();
    iStack_8._0_1_ = 5;
    cVar3 = *(char *)(param_2 + 2);
    while (cVar3 == '\0') {
      puVar6 = &uStack_44;
      uVar13 = 0x87bb9b;
      FUN_0168ea80(puVar6);
      FUN_005ef740(1000,0);
      FUN_00560fc0(&puStack_20,in_stack_fffffed4,in_stack_fffffed8,in_stack_fffffedc,
                   in_stack_fffffee0,iVar12,pppuVar9,uVar13,puVar6);
      FUN_0168ea80(&uStack_3c);
      if (*(char *)(param_2 + 2) != '\0') break;
      FUN_0168ea80(&puStack_18);
      if (CONCAT44(uStack_14,puStack_18) < uStack_2c) {
        if ((*(int *)(param_1 + 0x14) <= (int)uStack_14) &&
           ((*(int *)(param_1 + 0x14) < (int)uStack_14 || (*(uint **)(param_1 + 0x10) <= puStack_18)
            ))) {
          if (DAT_01ede471 != 0) {
            FUN_016774b0(DAT_01ede471,"timerThreadImpl sending",0);
          }
          pppuVar9 = &ppuStack_80;
          iVar12 = 0x87be72;
          FUN_0087b650(pppuVar9,&puStack_20,1);
          FUN_00872190();
          FUN_00587410();
        }
      }
      else {
        if (DAT_01ede471 != 0) {
          FUN_016774b0(DAT_01ede471,"timerThreadImpl sending SessionCount",0);
        }
        uStack_4c = 0;
        uStack_48 = 0xf;
        uStack_5c = uStack_5c & 0xffffff00;
        FUN_005542c0("SessionCount",0xc);
        iStack_8._0_1_ = 6;
        FUN_00874030(&puStack_20,&uStack_5c,1);
        iStack_8._0_1_ = 5;
        uVar4 = (undefined)iStack_8;
        iStack_8._0_1_ = 5;
        if (0xf < uStack_48) {
          uVar8 = uStack_48 + 1;
          uVar7 = uStack_5c;
          if (0xfff < uVar8) {
            uVar7 = *(uint *)(uStack_5c - 4);
            uVar8 = uStack_48 + 0x24;
            if (0x1f < (uStack_5c - uVar7) - 4) {
              iStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar7,uVar8);
        }
        FUN_0087b650(auStack_90,&puStack_20,1);
        piVar2 = piStack_84;
        iStack_8._0_1_ = 7;
        if (piStack_84 != (int *)0x0) {
          LOCK();
          iVar12 = piStack_84[1] + -1;
          piStack_84[1] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            (**(code **)(*piStack_84 + 4))();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar12 = *piVar1 + -1;
            *piVar1 = iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              (**(code **)(*piVar2 + 8))();
            }
          }
        }
        piVar2 = piStack_8c;
        iStack_8._0_1_ = 8;
        if (piStack_8c != (int *)0x0) {
          LOCK();
          iVar12 = piStack_8c[1] + -1;
          piStack_8c[1] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            (**(code **)(*piStack_8c + 4))();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar12 = *piVar1 + -1;
            *piVar1 = iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              (**(code **)(*piVar2 + 8))();
            }
          }
        }
        iStack_8._0_1_ = 5;
        FUN_00879890();
        if (puStack_20 == (uint *)0x0) {
          uVar13 = FUN_0056aeb0(1,"boost unique_lock has no mutex");
          iStack_8 = CONCAT31(iStack_8._1_3_,9);
                    /* WARNING: Subroutine does not return */
          FUN_00564990(uVar13);
        }
        if (cStack_1c != '\0') {
          uVar13 = FUN_0056aeb0(0x24,"boost unique_lock owns already the mutex");
          iStack_8 = CONCAT31(iStack_8._1_3_,10);
                    /* WARNING: Subroutine does not return */
          FUN_00564990(uVar13);
        }
        FUN_005874f0();
        pppuVar9 = (undefined ***)(DAT_01d625f0 >> 0x1f);
        cStack_1c = '\x01';
        in_stack_fffffee0 = 0x87bd34;
        iVar12 = DAT_01d625f0;
        lVar10 = FUN_016f39b0(DAT_01d625f0,pppuVar9,1000000000,0);
        uStack_2c = lVar10 + CONCAT44(uStack_14,puStack_18);
        plVar5 = (longlong *)FUN_0168ea80(auStack_34);
        puStack_18 = *(uint **)plVar5;
        uStack_24 = *(uint *)((int)plVar5 + 4);
        uStack_14 = uStack_24;
        if (uStack_2c <= *plVar5) {
          if (DAT_01ede471 != 0) {
            FUN_016774b0(DAT_01ede471,"timerThreadImpl adjusting sessionCountTimeout",0);
          }
          puVar6 = puStack_18;
          pppuVar9 = (undefined ***)(DAT_01d625f0 >> 0x1f);
          in_stack_fffffee0 = 0x87bda4;
          iVar12 = DAT_01d625f0;
          uStack_24 = uStack_14;
          lVar10 = FUN_016f39b0(DAT_01d625f0,pppuVar9,1000000000,0);
          uStack_2c = lVar10 + CONCAT44(uStack_24,puVar6);
        }
      }
      cVar3 = *(char *)(param_2 + 2);
    }
    FUN_0058c660();
    FUN_00879890();
    iStack_8._0_1_ = 0xb;
    if (cStack_1c != '\0') {
      LOCK();
      uVar7 = *puStack_20;
      *puStack_20 = *puStack_20 + 0x80000000;
      UNLOCK();
      if (((uVar7 & 0x40000000) == 0) && (-0x80000000 < (int)uVar7)) {
        LOCK();
        uVar7 = *puStack_20;
        *puStack_20 = *puStack_20 | 0x40000000;
        UNLOCK();
        if ((uVar7 >> 0x1e & 1) == 0) {
          uVar13 = FUN_00554e40();
          SetEvent(uVar13);
        }
      }
    }
    iStack_8._0_1_ = 0xc;
    FUN_01521ff0();
    FUN_016dedfb(auStack_f0);
    FUN_00577a40();
  }
  uVar7 = (uint)DAT_01ede471;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (DAT_01ede471 != 0) {
    uVar7 = FUN_016774b0(DAT_01ede471,"Exiting DeferredEphemeral timer thread",0);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar6 = (uint *)(param_3 + 1);
    uVar8 = *puVar6;
    uVar7 = *puVar6;
    *puVar6 = uVar8 - 1;
    UNLOCK();
    if (uVar8 - 1 == 0) {
      uVar7 = (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar12 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar12 == 1) {
        uVar7 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 13529 ; VA 0x0087c1d0 ; FUN_0087c1d0 */

uint * __thiscall FUN_0087c1d0(int param_1,uint *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined8 uVar7;
  int iStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  undefined auStack_30 [8];
  undefined auStack_28 [8];
  uint *puStack_20;
  char cStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b9b00;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)(param_1 + 8);
  uStack_8 = 0;
  piVar2 = piVar1;
  if (0xf < *(uint *)(param_1 + 0x1c)) {
    piVar2 = (int *)*piVar1;
  }
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_0151a220(piVar2);
  puStack_20 = param_2;
  cStack_1c = '\0';
  FUN_00587410();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (DAT_01ede472 != '\0') {
    piVar2 = piVar1;
    if (0xf < *(uint *)(param_1 + 0x1c)) {
      piVar2 = (int *)*piVar1;
    }
    FUN_016774b0(DAT_01ede472,"%s starting send/wait loop",piVar2);
  }
  if (*(char *)(param_2 + 2) == '\0') {
    iStack_14 = param_1 + 0x24;
    do {
      if (DAT_01ede472 != '\0') {
        piVar2 = piVar1;
        if (0xf < *(uint *)(param_1 + 0x1c)) {
          piVar2 = (int *)*piVar1;
        }
        FUN_016774b0(DAT_01ede472,"%s waiting...",piVar2);
      }
      iVar4 = DAT_01d62580;
      iVar5 = DAT_01d62580 >> 0x1f;
      if ((-1 < iVar5) && ((DAT_01d62580 < 0 && -1 < iVar5 || (DAT_01d62580 != 0)))) {
        FUN_0168ea80(auStack_28);
        uVar7 = FUN_016f39b0(iVar4,iVar5,1000,0);
        FUN_005ef740(uVar7);
        FUN_00560fc0(&puStack_20);
        FUN_0168ea80(auStack_30);
      }
      if (DAT_01ede472 != '\0') {
        piVar2 = piVar1;
        if (0xf < *(uint *)(param_1 + 0x1c)) {
          piVar2 = (int *)*piVar1;
        }
        FUN_016774b0(DAT_01ede472,"%s sending events...",piVar2);
      }
      FUN_008791c0(&iStack_3c);
      uStack_8._0_1_ = 2;
      if (iStack_3c != 0) {
        FUN_00559650(iStack_3c,uStack_38,&iStack_3c);
        uVar6 = (iStack_34 - iStack_3c >> 3) * 8;
        iVar4 = iStack_3c;
        if (0xfff < uVar6) {
          iVar4 = *(int *)(iStack_3c + -4);
          uVar6 = uVar6 + 0x23;
          if (0x1f < (iStack_3c - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar6);
        iStack_3c = 0;
        uStack_38 = 0;
        iStack_34 = 0;
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
    } while (*(char *)(param_2 + 2) == '\0');
  }
  if (DAT_01ede472 != '\0') {
    param_2 = (uint *)FUN_016774b0(DAT_01ede472,"Exiting DeferredReporter timer thread",0);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (cStack_1c != '\0') {
    LOCK();
    param_2 = (uint *)*puStack_20;
    *puStack_20 = *puStack_20 + 0x80000000;
    UNLOCK();
    if ((((uint)param_2 & 0x40000000) == 0) && (-0x80000000 < (int)param_2)) {
      LOCK();
      uVar6 = *puStack_20;
      *puStack_20 = *puStack_20 | 0x40000000;
      UNLOCK();
      if ((uVar6 >> 0x1e & 1) == 0) {
        uVar3 = FUN_00554e40();
        param_2 = (uint *)SetEvent(uVar3);
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar4 = *piVar1;
    param_2 = (uint *)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      param_2 = (uint *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        param_2 = (uint *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 13530 ; VA 0x0087c420 ; FUN_0087c420 */

undefined4 __thiscall
FUN_0087c420(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_008710d0(param_2,param_3,param_4,param_1);
  return param_2;
}



/* FUNCTION 13531 ; VA 0x0087c450 ; FUN_0087c450 */

int * FUN_0087c450(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9468;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00876980(&piStack_18);
  uStack_8 = 0;
  if (piStack_18 != (int *)0x0) {
    if (*(int *)(piStack_18[1] + *piStack_18 * 4) == 0) {
      piStack_18 = (int *)CONCAT31((int3)((uint)piStack_18[1] >> 8),DAT_01ede470);
      if (DAT_01ede470 != '\0') {
        piStack_18 = (int *)FUN_016774b0(DAT_01ede470,"Google analytics not initialized!",0);
      }
    }
    else {
      piStack_18 = (int *)FUN_00991700(param_1,param_2,param_3,param_4,param_5,param_6,0);
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    piStack_18 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_18 = (int *)(**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_18 = (int *)(**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piStack_18;
}



/* FUNCTION 13532 ; VA 0x0087c510 ; FUN_0087c510 */

void FUN_0087c510(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  uint in_stack_00000028;
  char *in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined auStack_60 [20];
  undefined4 uStack_4c;
  uint uStack_48;
  char *pcStack_44;
  int **ppiStack_40;
  undefined auStack_34 [24];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b9b28;
  pvStack_10 = ExceptionList;
  ppiStack_40 = &piStack_1c;
  uStack_8 = 0;
  pcStack_44 = (char *)0x87c53d;
  ExceptionList = &pvStack_10;
  FUN_00876980();
  uStack_8._0_1_ = 1;
  if (piStack_1c != (int *)0x0) {
    ppiStack_40 = (int **)&stack0x00000010;
    pcStack_44 = (char *)0x87c557;
    FUN_0060e660();
    uStack_8._0_1_ = 2;
    ppiStack_40 = *(int ***)(piStack_1c[1] + *piStack_1c * 4);
    if (ppiStack_40 == (int **)0x0) {
      if (DAT_01ede470 != 0) {
        uStack_48 = (uint)DAT_01ede470;
        pcStack_44 = "Google analytics not initialized!";
        uStack_4c = 0x87c57f;
        FUN_016774b0();
      }
    }
    else {
      ppiStack_40 = (int **)in_stack_00000030;
      pcStack_44 = in_stack_0000002c;
      uStack_48 = in_stack_00000028;
      puStack_14 = auStack_60;
      FUN_0060e660(auStack_34);
      FUN_009940a0(param_1,param_2,param_3);
    }
    ppiStack_40 = (int **)0x87c5b6;
    FUN_0056cfd0();
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      ppiStack_40 = (int **)0x87c5cf;
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        ppiStack_40 = (int **)0x87c5de;
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ppiStack_40 = (int **)0x87c5e6;
  FUN_0056cfd0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13533 ; VA 0x0087c600 ; FUN_0087c600 */

void FUN_0087c600(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 in_stack_00000028;
  uint in_stack_0000002c;
  char *in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined auStack_64 [24];
  undefined4 uStack_4c;
  uint uStack_48;
  char *pcStack_44;
  int **ppiStack_40;
  undefined auStack_34 [24];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b9b28;
  pvStack_10 = ExceptionList;
  ppiStack_40 = &piStack_1c;
  uStack_8 = 0;
  pcStack_44 = (char *)0x87c62d;
  ExceptionList = &pvStack_10;
  FUN_00876980();
  uStack_8._0_1_ = 1;
  if (piStack_1c != (int *)0x0) {
    ppiStack_40 = (int **)&stack0x00000010;
    pcStack_44 = (char *)0x87c647;
    FUN_0060e660();
    uStack_8._0_1_ = 2;
    ppiStack_40 = *(int ***)(piStack_1c[1] + *piStack_1c * 4);
    if (ppiStack_40 == (int **)0x0) {
      if (DAT_01ede470 != 0) {
        uStack_48 = (uint)DAT_01ede470;
        pcStack_44 = "Google analytics not initialized!";
        uStack_4c = 0x87c66f;
        FUN_016774b0();
      }
    }
    else {
      ppiStack_40 = (int **)in_stack_00000034;
      pcStack_44 = in_stack_00000030;
      uStack_48 = in_stack_0000002c;
      uStack_4c = in_stack_00000028;
      puStack_14 = auStack_64;
      FUN_0060e660(auStack_34);
      FUN_00994140(param_1,param_2,param_3);
    }
    ppiStack_40 = (int **)0x87c6a9;
    FUN_0056cfd0();
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      ppiStack_40 = (int **)0x87c6c2;
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        ppiStack_40 = (int **)0x87c6d1;
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ppiStack_40 = (int **)0x87c6d9;
  FUN_0056cfd0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13534 ; VA 0x0087c6f0 ; FUN_0087c6f0 */

int * FUN_0087c6f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9468;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00876980(&piStack_18);
  uStack_8 = 0;
  if (piStack_18 != (int *)0x0) {
    if (*(int *)(piStack_18[1] + *piStack_18 * 4) == 0) {
      piStack_18 = (int *)CONCAT31((int3)((uint)piStack_18[1] >> 8),DAT_01ede470);
      if (DAT_01ede470 != '\0') {
        piStack_18 = (int *)FUN_016774b0(DAT_01ede470,"Google analytics not initialized!",0);
      }
    }
    else {
      piStack_18 = (int *)FUN_009941f0(param_1,param_2,param_3,param_4,param_5,param_6,param_7,0);
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    piStack_18 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_18 = (int *)(**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_18 = (int *)(**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piStack_18;
}



/* FUNCTION 13535 ; VA 0x0087c7b0 ; FUN_0087c7b0 */

int * FUN_0087c7b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9468;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00876980(&piStack_18);
  uStack_8 = 0;
  if (piStack_18 != (int *)0x0) {
    if (*(int *)(piStack_18[1] + *piStack_18 * 4) == 0) {
      piStack_18 = (int *)CONCAT31((int3)((uint)piStack_18[1] >> 8),DAT_01ede470);
      if (DAT_01ede470 != '\0') {
        piStack_18 = (int *)FUN_016774b0(DAT_01ede470,"Google analytics not initialized!",0);
      }
    }
    else {
      piStack_18 = (int *)FUN_00994250(param_1,param_2,param_3,param_4,param_5);
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    piStack_18 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_18 = (int *)(**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_18 = (int *)(**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piStack_18;
}



/* FUNCTION 13536 ; VA 0x0087c860 ; FUN_0087c860 */

int __fastcall FUN_0087c860(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint *puVar5;
  undefined8 uVar6;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017b9b58;
  pvStack_10 = ExceptionList;
  iStack_20 = 0;
  piStack_1c = (int *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  iStack_14 = param_1;
  iVar4 = FUN_016dee6d(param_1);
  if (iVar4 != 0) {
    FUN_016df3c9(iVar4);
  }
  iStack_28 = *(int *)(param_1 + 0x44);
  piStack_24 = *(int **)(param_1 + 0x48);
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piStack_24[1] = piStack_24[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 0x44) = 0;
  piVar3 = *(int **)(param_1 + 0x48);
  *(undefined4 *)(param_1 + 0x48) = 0;
  uStack_8._0_1_ = 2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar3 + 4))();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 8))();
      }
    }
  }
  *(undefined4 *)(param_1 + 0x44) = 0;
  piVar3 = *(int **)(param_1 + 0x48);
  *(undefined4 *)(param_1 + 0x48) = 0;
  uStack_8._0_1_ = 3;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar3 + 4))();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 8))();
      }
    }
  }
  uStack_8._0_1_ = 4;
  FUN_00872b10(&iStack_20);
  FUN_00872b10(&iStack_28);
  piVar3 = piStack_24;
  uStack_8._0_1_ = 5;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piStack_24 + 4))();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1 + -1;
      *piVar1 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 8))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  iVar4 = FUN_016deec8(iStack_14);
  if (iVar4 != 0) {
    iVar4 = FUN_016df3c9(iVar4);
  }
  iVar2 = DAT_01d62574;
  uStack_8 = uStack_8 & 0xffffff00;
  if (iStack_20 != 0) {
    iVar4 = DAT_01d62574 >> 0x1f;
    puVar5 = (uint *)FUN_0168ea80(&iStack_28);
    uVar6 = FUN_016f39b0(iVar2,iVar4,1000000,0);
    iStack_28 = (uint)uVar6 + *puVar5;
    piStack_24 = (int *)((int)((ulonglong)uVar6 >> 0x20) + puVar5[1] +
                        (uint)CARRY4((uint)uVar6,*puVar5));
    iVar4 = FUN_008716c0(&iStack_28);
  }
  piVar3 = piStack_1c;
  uStack_8 = 8;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)(*piStack_1c + 4))();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 13537 ; VA 0x0087ca30 ; FUN_0087ca30 */

bool __fastcall FUN_0087ca30(int param_1)

{
  return *(int *)(param_1 + 4) == 2;
}



/* FUNCTION 13538 ; VA 0x0087ca40 ; FUN_0087ca40 */

bool __fastcall FUN_0087ca40(int param_1)

{
  return *(int *)(param_1 + 4) == 3;
}



/* FUNCTION 13539 ; VA 0x0087ca50 ; FUN_0087ca50 */

void __thiscall FUN_0087ca50(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  puVar2 = param_1 + 4;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  FUN_0055c360(param_1,*puVar2,param_2,*puVar1);
  return;
}



/* FUNCTION 13540 ; VA 0x0087ca80 ; FUN_0087ca80 */

int * __thiscall FUN_0087ca80(byte *param_1,uint *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  int aiStack_40 [5];
  uint uStack_2c;
  uint uStack_28;
  int *piStack_24;
  undefined2 uStack_20;
  int *piStack_1c;
  uint uStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar4 = (int)param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9b80;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pbStack_14 = param_1;
  uStack_18 = FUN_005702d0(param_2);
  FUN_00562fc0(&param_2,uStack_18,iVar4,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (uint *)0x0) {
    ExceptionList = pvStack_10;
    return (int *)((int)param_2 + 8);
  }
  piStack_24 = (int *)0x0;
  uStack_20 = 0;
  uStack_28 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar4);
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  piVar3 = (int *)FUN_01674e20(0x28);
  uStack_20 = CONCAT11(uStack_20._1_1_,1);
  piStack_1c = piVar3 + 2;
  *piVar3 = 0;
  piVar3[1] = 0;
  *piStack_1c = 0;
  piVar3[3] = 0;
  piVar3[4] = 0;
  piVar3[5] = 0;
  piVar3[6] = 0;
  piVar3[7] = 0;
  piVar3[8] = 0;
  piVar3[9] = 0;
  piStack_24 = piVar3;
  FUN_0054ef60(aiStack_40);
  piVar3[8] = 0;
  piVar3[9] = 0;
  uStack_20 = CONCAT11(1,(undefined)uStack_20);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_2c) {
    uVar7 = uStack_2c + 1;
    iVar4 = aiStack_40[0];
    if (0xfff < uVar7) {
      iVar4 = *(int *)(aiStack_40[0] + -4);
      uVar7 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar7);
  }
  uVar1 = *(uint *)(param_1 + 8);
  uVar7 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_0087d540(uVar7);
    if (uVar7 <= *(uint *)(param_1 + 4)) {
      uVar7 = *(uint *)(param_1 + 4);
    }
    FUN_00780ee0(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    param_2 = (uint *)0x1;
    uVar5 = uVar1 >> 1;
    if (uVar1 + (uVar1 >> 1) <= uVar7) {
      uVar5 = 1;
    }
    uVar7 = FUN_0087d540(uVar5 + *(int *)(param_1 + 8));
    param_2 = (uint *)(param_1 + 4);
    if (uVar7 != *param_2) {
      FUN_00780ee0(uVar7);
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_2 * 4);
      puVar2 = (undefined4 *)*puVar8;
      while (piVar3 = piStack_24, puVar2 != (undefined4 *)0x0) {
        piVar3 = (int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar2[1] % *param_2) * 4);
        if (*(int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar2[1] % *param_2) * 4) == 0) {
          *piVar3 = (int)puVar8;
          puVar8 = puVar2;
        }
        else {
          *puVar8 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar3;
          *(undefined4 **)*piVar3 = puVar2;
        }
        param_1 = pbStack_14;
        puVar2 = (undefined4 *)*puVar8;
      }
    }
  }
  piVar3[1] = uStack_18;
  uVar7 = *(uint *)(param_1 + 4);
  piVar3 = (int *)(*(int *)(param_1 + 0x14) + (uStack_18 % uVar7) * 4);
  if ((int *)*piVar3 == (int *)0x0) {
    piVar6 = (int *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (*piVar6 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar6 + 4) % uVar7) * 4) = piStack_24;
    }
    *piVar3 = (int)piVar6;
    *piStack_24 = *piVar6;
  }
  else {
    *piStack_24 = *(int *)*piVar3;
    piVar6 = (int *)*piVar3;
  }
  *piVar6 = (int)piStack_24;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_1c;
}



/* FUNCTION 13541 ; VA 0x0087ccc0 ; FUN_0087ccc0 */

void __fastcall FUN_0087ccc0(int param_1)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 == 2) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00571be0(1);
    }
  }
  else if (iVar1 == 3) {
    piVar2 = *(int **)(param_1 + 8);
    if (piVar2 != (int *)0x0) {
      uVar3 = piVar2[5];
      if (0xf < uVar3) {
        iVar1 = *piVar2;
        uVar5 = uVar3 + 1;
        iVar4 = iVar1;
        if (0xfff < uVar5) {
          iVar4 = *(int *)(iVar1 + -4);
          uVar5 = uVar3 + 0x24;
          if (0x1f < (iVar1 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar5);
      }
      piVar2[4] = 0;
      piVar2[5] = 0xf;
      *(undefined *)piVar2 = 0;
      FUN_01674ea0(piVar2,0x18);
      *(undefined4 *)(param_1 + 4) = 0;
      return;
    }
  }
  else if ((iVar1 == 8) && (iVar1 = *(int *)(param_1 + 8), iVar1 != 0)) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
    *(undefined4 *)(param_1 + 4) = 0;
    return;
  }
  *(undefined4 *)(param_1 + 4) = 0;
  return;
}



/* FUNCTION 13542 ; VA 0x0087cdb0 ; FUN_0087cdb0 */

undefined4 * __thiscall FUN_0087cdb0(int param_1,int param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 0x20);
  while( true ) {
    if (puVar1 == (undefined4 *)0x0) {
      return (undefined4 *)0x0;
    }
    if (puVar1[2] == param_2) break;
    puVar1 = (undefined4 *)*puVar1;
  }
  return puVar1;
}



/* FUNCTION 13543 ; VA 0x0087cde0 ; FUN_0087cde0 */

undefined4 * __thiscall FUN_0087cde0(int param_1,int param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  while( true ) {
    if (puVar1 == (undefined4 *)0x0) {
      return (undefined4 *)0x0;
    }
    if (puVar1[4] == param_2) break;
    puVar1 = (undefined4 *)*puVar1;
  }
  return puVar1;
}



/* FUNCTION 13544 ; VA 0x0087ce10 ; FUN_0087ce10 */

int * FUN_0087ce10(int *param_1)

{
  int *piVar1;
  
  piVar1 = (int *)*param_1;
  if (piVar1 != (int *)0x0) {
    do {
      if (piVar1[4] == param_1[4]) {
        return piVar1;
      }
      piVar1 = (int *)*piVar1;
    } while (piVar1 != (int *)0x0);
  }
  return (int *)0x0;
}



/* FUNCTION 13545 ; VA 0x0087ce40 ; FUN_0087ce40 */

undefined4 __thiscall FUN_0087ce40(int param_1,undefined *param_2)

{
  if (*(int *)(param_1 + 4) == 6) {
    *param_2 = *(undefined *)(param_1 + 8);
    return 1;
  }
  return 0;
}



/* FUNCTION 13546 ; VA 0x0087ce60 ; FUN_0087ce60 */

undefined4 __thiscall FUN_0087ce60(int param_1,undefined4 *param_2)

{
  char cVar1;
  
  if (*(int *)(param_1 + 4) == 5) {
    *param_2 = *(undefined4 *)(param_1 + 8);
    return 1;
  }
  if (*(int *)(param_1 + 4) == 2) {
    cVar1 = FUN_009ee5c0(*(undefined4 *)(param_1 + 8),param_2);
    if (cVar1 != '\0') {
      FUN_0087ccc0();
      *(undefined4 *)(param_1 + 8) = *param_2;
      *(undefined4 *)(param_1 + 4) = 5;
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 13547 ; VA 0x0087cec0 ; FUN_0087cec0 */

undefined4 __thiscall FUN_0087cec0(int param_1,undefined4 *param_2)

{
  char cVar1;
  
  if (*(int *)(param_1 + 4) == 6) {
    *param_2 = *(undefined4 *)(param_1 + 8);
    return 1;
  }
  if (*(int *)(param_1 + 4) == 2) {
    cVar1 = FUN_009ee600(*(undefined4 *)(param_1 + 8),param_2);
    if (cVar1 != '\0') {
      FUN_0087ccc0();
      *(undefined4 *)(param_1 + 8) = *param_2;
      *(undefined4 *)(param_1 + 4) = 6;
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 13548 ; VA 0x0087cf20 ; FUN_0087cf20 */

undefined4 __thiscall FUN_0087cf20(int param_1,undefined4 *param_2)

{
  char cVar1;
  
  if (*(int *)(param_1 + 4) == 7) {
    *param_2 = *(undefined4 *)(param_1 + 8);
    return 1;
  }
  if (*(int *)(param_1 + 4) == 2) {
    cVar1 = FUN_009ee6c0(*(undefined4 *)(param_1 + 8),param_2);
    if (cVar1 != '\0') {
      FUN_0087ccc0();
      *(undefined4 *)(param_1 + 8) = *param_2;
      *(undefined4 *)(param_1 + 4) = 7;
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 13549 ; VA 0x0087cf80 ; FUN_0087cf80 */

undefined4 __thiscall FUN_0087cf80(int param_1,double *param_2)

{
  int iVar1;
  char cVar2;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 == 9) {
    *param_2 = *(double *)(param_1 + 8);
    return 1;
  }
  if (iVar1 == 7) {
    *param_2 = (double)*(float *)(param_1 + 8);
  }
  else if ((iVar1 != 2) ||
          (cVar2 = FUN_009ee7a0(*(undefined4 *)(param_1 + 8),param_2), cVar2 == '\0')) {
    return 0;
  }
  FUN_0087ccc0();
  *(double *)(param_1 + 8) = *param_2;
  *(undefined4 *)(param_1 + 4) = 9;
  return 1;
}



/* FUNCTION 13550 ; VA 0x0087d000 ; FUN_0087d000 */

undefined4 __thiscall FUN_0087d000(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  
  if (*(int *)(param_1 + 4) == 1) {
    *param_2 = *(undefined4 *)(param_1 + 8);
    return 1;
  }
  if (*(int *)(param_1 + 4) == 2) {
    piVar1 = *(int **)(param_1 + 8);
    if (0xf < (uint)piVar1[5]) {
      piVar1 = (int *)*piVar1;
    }
    uVar2 = FUN_0086e3d0(piVar1);
    *param_2 = uVar2;
    FUN_0087ccc0();
    *(undefined4 *)(param_1 + 8) = *param_2;
    *(undefined4 *)(param_1 + 4) = 1;
    return 1;
  }
  return 0;
}



/* FUNCTION 13551 ; VA 0x0087d060 ; FUN_0087d060 */

undefined4 __thiscall FUN_0087d060(int param_1,int param_2)

{
  int *piVar1;
  char cVar2;
  int *piVar3;
  char *pcVar4;
  char *pcVar5;
  
  if (*(int *)(param_1 + 4) == 2) {
    piVar3 = *(int **)(param_1 + 8);
    if ((int *)param_2 != piVar3) {
      piVar1 = piVar3 + 4;
      if (0xf < (uint)piVar3[5]) {
        piVar3 = (int *)*piVar3;
      }
      FUN_005542c0(piVar3,*piVar1);
    }
    return 1;
  }
  if (*(int *)(param_1 + 4) == 1) {
    pcVar5 = *(char **)(param_1 + 8);
    if (pcVar5 == (char *)0x0) {
      pcVar5 = "";
    }
    else if (0xf < *(uint *)(pcVar5 + 0x14)) {
      pcVar5 = *(char **)pcVar5;
    }
    pcVar4 = pcVar5;
    do {
      cVar2 = *pcVar4;
      pcVar4 = pcVar4 + 1;
    } while (cVar2 != '\0');
    FUN_005542c0(pcVar5,(int)pcVar4 - (int)(pcVar5 + 1));
    return 1;
  }
  return 0;
}



/* FUNCTION 13552 ; VA 0x0087d0d0 ; FUN_0087d0d0 */

undefined4 __thiscall FUN_0087d0d0(int param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint *puVar3;
  int iVar4;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9ba7;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 4) == 3) {
    puVar3 = *(uint **)(param_1 + 8);
    if (param_2 != puVar3) {
      puVar1 = puVar3 + 4;
      if (0xf < puVar3[5]) {
        puVar3 = (uint *)*puVar3;
      }
      ExceptionList = &pvStack_10;
      FUN_005542c0(puVar3,*puVar1);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  if (*(int *)(param_1 + 4) == 2) {
    ExceptionList = &pvStack_10;
    FUN_0054ef60(*(undefined4 *)(param_1 + 8));
    uStack_8 = 0;
    FUN_009cbbb0(&uStack_2c);
    uStack_8 = 0xffffffff;
    if (param_2 != &uStack_2c) {
      FUN_005507b0();
      uVar2 = uStack_2c;
      uStack_2c = uStack_2c & 0xffffff00;
      *param_2 = uVar2;
      param_2[1] = uStack_28;
      param_2[2] = uStack_24;
      param_2[3] = uStack_20;
      *(ulonglong *)(param_2 + 4) = CONCAT44(uStack_18,uStack_1c);
      uStack_1c = 0;
      uStack_18 = 0xf;
    }
    FUN_005507b0();
    FUN_0087ccc0();
    iVar4 = FUN_01674e20(0x18);
    uStack_8 = 1;
    if (iVar4 != 0) {
      iStack_14 = iVar4;
      FUN_0054ef60(param_2);
      *(int *)(param_1 + 8) = iVar4;
      *(undefined4 *)(param_1 + 4) = 3;
      ExceptionList = pvStack_10;
      return 1;
    }
    *(undefined4 *)(param_1 + 4) = 3;
    *(undefined4 *)(param_1 + 8) = 0;
    ExceptionList = pvStack_10;
    return 1;
  }
  return 0;
}



/* FUNCTION 13553 ; VA 0x0087d210 ; FUN_0087d210 */

undefined4 __fastcall FUN_0087d210(int param_1)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9bed;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)(param_1 + 4);
  if (iVar3 == 1) {
    ExceptionList = &pvStack_10;
    if (*(undefined4 **)(param_1 + 8) == DAT_01ede580) {
      ExceptionList = &pvStack_10;
      FUN_0087ccc0();
      iVar3 = FUN_01674e20(8);
      uStack_8 = 0;
      goto LAB_0087d261;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    if (iVar3 != 2) goto LAB_0087d360;
    piVar5 = *(int **)(param_1 + 8);
    piVar1 = piVar5 + 4;
    if (0xf < (uint)piVar5[5]) {
      piVar5 = (int *)*piVar5;
    }
    puVar6 = DAT_01ede580;
    if (0xf < (uint)DAT_01ede580[5]) {
      puVar6 = (undefined4 *)*DAT_01ede580;
    }
    ExceptionList = &pvStack_10;
    cVar2 = FUN_0055c360(puVar6,DAT_01ede580[4],piVar5,*piVar1);
    if (cVar2 != '\0') {
      FUN_0087ccc0();
      iVar3 = FUN_01674e20(8);
      uStack_8 = 1;
      goto LAB_0087d261;
    }
  }
  if (iVar3 == 2) {
    piVar5 = *(int **)(param_1 + 8);
    piVar1 = piVar5 + 4;
    if (0xf < (uint)piVar5[5]) {
      piVar5 = (int *)*piVar5;
    }
    cVar2 = FUN_0055c360(piVar5,*piVar1,&DAT_018bc9b8,0);
    if (cVar2 == '\0') {
      ExceptionList = pvStack_10;
      return 0;
    }
    FUN_0087ccc0();
    iVar3 = FUN_01674e20(8);
    uStack_8 = 2;
LAB_0087d261:
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 8) = 0;
      *(undefined4 *)(param_1 + 4) = 8;
      FUN_0056ecd0(0);
      ExceptionList = pvStack_10;
      return 1;
    }
    uVar4 = FUN_00d85940(0);
    *(undefined4 *)(param_1 + 8) = uVar4;
    *(undefined4 *)(param_1 + 4) = 8;
    FUN_0056ecd0(uVar4);
    ExceptionList = pvStack_10;
    return 1;
  }
LAB_0087d360:
  if (iVar3 != 8) {
    ExceptionList = pvStack_10;
    return 0;
  }
  FUN_0056ecd0(*(undefined4 *)(param_1 + 8));
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 13554 ; VA 0x0087d3a0 ; FUN_0087d3a0 */

uint __thiscall FUN_0087d3a0(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  uint uVar2;
  
  uVar2 = *(uint *)(param_1 + 4);
  if (uVar2 == 10) {
    *param_2 = *(undefined4 *)(param_1 + 8);
    uVar1 = *(undefined4 *)(param_1 + 0xc);
    param_2[1] = uVar1;
    return CONCAT31((int3)((uint)uVar1 >> 8),1);
  }
  if (uVar2 == 2) {
    uVar2 = FUN_009ee890(*(undefined4 *)(param_1 + 8),param_2);
    if ((char)uVar2 != '\0') {
      FUN_0087ccc0();
      *(undefined4 *)(param_1 + 8) = *param_2;
      uVar1 = param_2[1];
      *(undefined4 *)(param_1 + 0xc) = uVar1;
      *(undefined4 *)(param_1 + 4) = 10;
      return CONCAT31((int3)((uint)uVar1 >> 8),1);
    }
  }
  return uVar2 & 0xffffff00;
}



/* FUNCTION 13555 ; VA 0x0087d410 ; FUN_0087d410 */

undefined4 __thiscall FUN_0087d410(int param_1,undefined *param_2)

{
  char cVar1;
  
  if (*(int *)(param_1 + 4) == 4) {
    *param_2 = *(undefined *)(param_1 + 8);
    return 1;
  }
  if (*(int *)(param_1 + 4) == 2) {
    cVar1 = FUN_009ee8e0(*(undefined4 *)(param_1 + 8),param_2);
    if (cVar1 != '\0') {
      FUN_0087ccc0();
      *(undefined *)(param_1 + 8) = *param_2;
      *(undefined4 *)(param_1 + 4) = 4;
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 13556 ; VA 0x0087d470 ; FUN_0087d470 */

bool __thiscall FUN_0087d470(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined uVar3;
  int *piVar4;
  
  if (*(int *)(param_1 + 4) == 1) {
    return param_2 == *(undefined4 **)(param_1 + 8);
  }
  if (*(int *)(param_1 + 4) != 2) {
    return false;
  }
  piVar4 = *(int **)(param_1 + 8);
  piVar1 = piVar4 + 4;
  if (0xf < (uint)piVar4[5]) {
    piVar4 = (int *)*piVar4;
  }
  puVar2 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  uVar3 = FUN_0055c360(param_2,*puVar2,piVar4,*piVar1);
  return (bool)uVar3;
}



/* FUNCTION 13557 ; VA 0x0087d4d0 ; FUN_0087d4d0 */

uint __fastcall FUN_0087d4d0(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uStack_8;
  
  puVar1 = *(undefined4 **)(param_1 + 0x20);
  do {
    puVar2 = puVar1;
    if (puVar1 == (undefined4 *)0x0) {
LAB_0087d4ed:
      return (uint)puVar2 & 0xffffff00;
    }
    if (puVar1[2] == DAT_01ede588) {
      puVar2 = (undefined4 *)puVar1[3];
      if (puVar2 == (undefined4 *)&DAT_00000004) {
        puVar2 = (undefined4 *)(uint)*(byte *)(puVar1 + 4);
      }
      else {
        if ((puVar2 != (undefined4 *)0x2) ||
           (uStack_8 = param_1, puVar2 = (undefined4 *)FUN_009ee8e0(puVar1[4],(int)&uStack_8 + 3),
           (char)puVar2 == '\0')) goto LAB_0087d4ed;
        uVar3 = FUN_0087ccc0();
        *(undefined *)(puVar1 + 4) = uStack_8._3_1_;
        puVar1[3] = 4;
        puVar2 = (undefined4 *)CONCAT31((int3)((uint)uVar3 >> 8),uStack_8._3_1_);
      }
      if ((char)puVar2 != '\0') {
        return CONCAT31((int3)((uint)puVar2 >> 8),1);
      }
      goto LAB_0087d4ed;
    }
    puVar1 = (undefined4 *)*puVar1;
  } while( true );
}



/* FUNCTION 13558 ; VA 0x0087d540 ; FUN_0087d540 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __thiscall FUN_0087d540(int param_1,int param_2)

{
  undefined **ppuVar1;
  int iVar2;
  int iVar3;
  undefined **ppuVar4;
  undefined *puVar5;
  float10 fVar6;
  
  fVar6 = (float10)FUN_01725280(((double)param_2 + (double)(&DAT_018c0d90)[-(param_2 >> 0x1f)]) /
                                (double)*(float *)(param_1 + 0xc));
  if ((double)fVar6 + DAT_018c0d60 < _DAT_018c4e98) {
    puVar5 = (undefined *)FUN_016f3eb1();
  }
  else {
    puVar5 = (undefined *)0xffffffff;
  }
  ppuVar4 = (undefined **)&DAT_018be100;
  iVar3 = 0x26;
  do {
    iVar2 = iVar3 >> 1;
    if (ppuVar4[iVar2] < puVar5) {
      ppuVar4 = ppuVar4 + iVar2 + 1;
      iVar2 = iVar3 + (-1 - iVar2);
    }
    iVar3 = iVar2;
  } while (0 < iVar2);
  ppuVar1 = ppuVar4 + -1;
  if (ppuVar4 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar1 = ppuVar4;
  }
  return *ppuVar1;
}



/* FUNCTION 13559 ; VA 0x0087d5f0 ; FUN_0087d5f0 */

int * __thiscall FUN_0087d5f0(int param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 ****ppppuVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  int *piVar10;
  undefined4 ***apppuStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  int aiStack_2c [2];
  int *piStack_24;
  int iStack_20;
  int iStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9c1f;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  switch(*(undefined4 *)(param_1 + 4)) {
  default:
    ExceptionList = &pvStack_10;
    param_2[4] = 0;
    param_2[5] = 0xf;
    *(undefined *)param_2 = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    ExceptionList = pvStack_10;
    return param_2;
  case 1:
  case 2:
  case 3:
    ExceptionList = &pvStack_10;
    FUN_0054ef60(*(undefined4 *)(param_1 + 8));
    ExceptionList = pvStack_10;
    return param_2;
  case 4:
    ExceptionList = &pvStack_10;
    FUN_009ee570(param_2,param_1 + 8);
    ExceptionList = pvStack_10;
    return param_2;
  case 5:
    ExceptionList = &pvStack_10;
    FUN_009ee270(param_2,param_1 + 8);
    ExceptionList = pvStack_10;
    return param_2;
  case 6:
    ExceptionList = &pvStack_10;
    FUN_009ee2d0(param_2,param_1 + 8);
    ExceptionList = pvStack_10;
    return param_2;
  case 7:
    ExceptionList = &pvStack_10;
    FUN_009ee330(param_2,param_1 + 8);
    ExceptionList = pvStack_10;
    return param_2;
  case 8:
    break;
  case 9:
    ExceptionList = &pvStack_10;
    FUN_009ee440(param_2,param_1 + 8);
    ExceptionList = pvStack_10;
    return param_2;
  case 10:
    ExceptionList = &pvStack_10;
    FUN_009ee550(param_2,param_1 + 8);
    ExceptionList = pvStack_10;
    return param_2;
  }
  ExceptionList = &pvStack_10;
  piVar2 = (int *)FUN_005c9430(aiStack_2c);
  iVar9 = *piVar2;
  FUN_00550b30();
  if (iVar9 == 0) {
    FUN_0054ef60(DAT_01ede580);
    ExceptionList = pvStack_10;
    return param_2;
  }
  FUN_005c9430(aiStack_2c);
  iStack_8 = 0;
  iStack_1c = *(int *)(aiStack_2c[0] + 0x10);
  if (iStack_1c != 0) {
    piStack_24 = *(int **)(param_1 + 8);
    iVar9 = param_3 + 0xd + (uint)*(byte *)(param_3 + 0xc);
    uVar3 = FUN_005702d0(iStack_1c);
    FUN_00562fc0(&iStack_20,uVar3,iStack_1c,-(uint)(iVar9 != 0) & iVar9 + 1U);
    uVar7 = uStack_18;
    piVar2 = param_2;
    piVar10 = param_2;
    if (iStack_20 == 0) {
LAB_0087d7fc:
      cStack_11 = '\x01';
    }
    else {
      piVar2 = (int *)piStack_24[1];
      if (piVar2 != (int *)0x0) {
        LOCK();
        piVar2[1] = piVar2[1] + 1;
        UNLOCK();
        piVar2 = (int *)piStack_24[1];
      }
      piVar10 = *(int **)(iStack_20 + 0x24);
      iVar9 = *piStack_24;
      if (piVar10 != (int *)0x0) {
        LOCK();
        piVar10[1] = piVar10[1] + 1;
        UNLOCK();
        piVar10 = *(int **)(iStack_20 + 0x24);
      }
      uVar7 = 6;
      if (*(int *)(iStack_20 + 0x20) == iVar9) goto LAB_0087d7fc;
      cStack_11 = '\0';
    }
    if (((uVar7 & 4) != 0) &&
       (uStack_18 = uVar7 & 0xfffffffb, uVar7 = uStack_18, piVar10 != (int *)0x0)) {
      LOCK();
      iVar9 = piVar10[1] + -1;
      piVar10[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piVar10)();
        LOCK();
        iVar9 = piVar10[2] + -1;
        piVar10[2] = iVar9;
        UNLOCK();
        uVar7 = uStack_18;
        if (iVar9 == 0) {
          (**(code **)(*piVar10 + 4))();
          uVar7 = uStack_18;
        }
      }
    }
    if (((uVar7 & 2) != 0) && (piVar2 != (int *)0x0)) {
      LOCK();
      iVar9 = piVar2[1] + -1;
      piVar2[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar9 = piVar2[2] + -1;
        piVar2[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (cStack_11 != '\0') goto LAB_0087d94d;
  }
  uStack_34 = 0;
  uStack_30 = 0xf;
  apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0] & 0xffffff00);
  iStack_8._0_1_ = 1;
  FUN_01531ce0(apppuStack_44);
  if (*(undefined4 *****)(aiStack_2c[0] + 0x10) == (undefined4 ****)0x0) {
    piStack_24 = (int *)FUN_01674e20(0x18);
    iStack_8._0_1_ = 2;
    if (piStack_24 == (int *)0x0) {
      uVar3 = 0;
    }
    else {
      uVar3 = FUN_0054ef60(apppuStack_44);
    }
    iStack_8._0_1_ = 1;
    piVar2 = *(int **)(aiStack_2c[0] + 0x10);
    *(undefined4 *)(aiStack_2c[0] + 0x10) = uVar3;
    if (piVar2 != (int *)0x0) {
      uVar7 = piVar2[5];
      if (0xf < uVar7) {
        iVar9 = *piVar2;
        uVar8 = uVar7 + 1;
        iVar4 = iVar9;
        if (0xfff < uVar8) {
          iVar4 = *(int *)(iVar9 + -4);
          uVar8 = uVar7 + 0x24;
          if (0x1f < (iVar9 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar8);
      }
      piVar2[4] = 0;
      piVar2[5] = 0xf;
      *(undefined *)piVar2 = 0;
      FUN_01674ea0(piVar2,0x18);
    }
  }
  else if (*(undefined4 *****)(aiStack_2c[0] + 0x10) != apppuStack_44) {
    ppppuVar5 = apppuStack_44;
    if (0xf < uStack_30) {
      ppppuVar5 = (undefined4 ****)apppuStack_44[0];
    }
    FUN_005542c0(ppppuVar5,uStack_34);
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  iStack_1c = *(int *)(aiStack_2c[0] + 0x10);
  FUN_005507b0();
LAB_0087d94d:
  iVar4 = iStack_1c;
  puVar1 = *(undefined4 **)(param_1 + 8);
  iVar6 = FUN_0087ca80(iStack_1c);
  iVar9 = puVar1[1];
  if (iVar9 != 0) {
    LOCK();
    *(int *)(iVar9 + 4) = *(int *)(iVar9 + 4) + 1;
    UNLOCK();
    iVar9 = puVar1[1];
  }
  *(undefined4 *)(iVar6 + 0x18) = *puVar1;
  piVar2 = *(int **)(iVar6 + 0x1c);
  *(int *)(iVar6 + 0x1c) = iVar9;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar9 = piVar2[1] + -1;
    piVar2[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar10 = piVar2 + 2;
      iVar9 = *piVar10;
      *piVar10 = *piVar10 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_0054ef60(iVar4);
  FUN_00550b30();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 13560 ; VA 0x0087da30 ; FUN_0087da30 */

void __fastcall FUN_0087da30(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  int *piVar6;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar5 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar3 = iVar1;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  piVar4 = *(int **)(param_1 + 4);
  piVar6 = (int *)*piVar4;
  *piVar4 = (int)piVar4;
  *(int *)(*(int *)(param_1 + 4) + 4) = *(int *)(param_1 + 4);
  *(undefined4 *)(param_1 + 8) = 0;
  piVar4 = *(int **)(param_1 + 4);
  if (piVar6 != piVar4) {
    do {
      piVar2 = (int *)*piVar6;
      FUN_01674ea0(piVar6,0xc);
      piVar4 = *(int **)(param_1 + 4);
      piVar6 = piVar2;
    } while (piVar2 != piVar4);
  }
  FUN_01674ea0(piVar4,0xc);
  return;
}



/* FUNCTION 13561 ; VA 0x0087dad0 ; FUN_0087dad0 */

void __fastcall FUN_0087dad0(undefined4 *param_1)

{
  int iVar1;
  int *piVar2;
  
  piVar2 = (int *)*param_1;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if ((iVar1 == 1) && (piVar2 != (int *)0x0)) {
      FUN_00d889a0();
      FUN_01674ea0(piVar2,8);
    }
  }
  return;
}



/* FUNCTION 13562 ; VA 0x0087db00 ; FUN_0087db00 */

void __fastcall FUN_0087db00(int *param_1)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  
  iVar1 = param_1[0x16];
  if (iVar1 != 0) {
    uVar5 = param_1[0x18] - iVar1 & 0xfffffffc;
    iVar4 = iVar1;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar1 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar1 - iVar4) - 4U) goto LAB_0087dc5c;
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[0x16] = 0;
    param_1[0x17] = 0;
    param_1[0x18] = 0;
  }
  piVar3 = (int *)param_1[0x14];
  piVar6 = (int *)*piVar3;
  *piVar3 = (int)piVar3;
  *(int *)(param_1[0x14] + 4) = param_1[0x14];
  param_1[0x15] = 0;
  piVar3 = (int *)param_1[0x14];
  if (piVar6 != piVar3) {
    do {
      piVar2 = (int *)*piVar6;
      FUN_01674ea0(piVar6,0xc);
      piVar3 = (int *)param_1[0x14];
      piVar6 = piVar2;
    } while (piVar2 != piVar3);
  }
  FUN_01674ea0(piVar3,0xc);
  iVar1 = param_1[0xe];
  if (iVar1 != 0) {
    uVar5 = param_1[0x10] - iVar1 & 0xfffffffc;
    iVar4 = iVar1;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar1 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar1 - iVar4) - 4U) goto LAB_0087dc5c;
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[0xe] = 0;
    param_1[0xf] = 0;
    param_1[0x10] = 0;
  }
  piVar3 = (int *)param_1[0xc];
  piVar6 = (int *)*piVar3;
  *piVar3 = (int)piVar3;
  *(int *)(param_1[0xc] + 4) = param_1[0xc];
  param_1[0xd] = 0;
  piVar3 = (int *)param_1[0xc];
  if (piVar6 != piVar3) {
    do {
      piVar2 = (int *)*piVar6;
      FUN_01674ea0(piVar6,0xc);
      piVar3 = (int *)param_1[0xc];
      piVar6 = piVar2;
    } while (piVar2 != piVar3);
  }
  FUN_01674ea0(piVar3,0xc);
  uVar5 = param_1[5];
  if (0xf < uVar5) {
    iVar1 = *param_1;
    uVar7 = uVar5 + 1;
    iVar4 = iVar1;
    if (0xfff < uVar7) {
      iVar4 = *(int *)(iVar1 + -4);
      uVar7 = uVar5 + 0x24;
      if (0x1f < (iVar1 - iVar4) - 4U) {
LAB_0087dc5c:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar7);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 13563 ; VA 0x0087dc70 ; FUN_0087dc70 */

void __fastcall FUN_0087dc70(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x10);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0087dcb0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 13564 ; VA 0x0087dcc0 ; FUN_0087dcc0 */

void __fastcall FUN_0087dcc0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x24);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x10);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0xf;
  *(undefined *)(param_1 + 0x10) = 0;
  piVar4 = *(int **)(param_1 + 0xc);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0087dd2d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar4 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 13565 ; VA 0x0087dd40 ; FUN_0087dd40 */

void __fastcall FUN_0087dd40(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x24);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0087dd69. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 13566 ; VA 0x0087dd70 ; FUN_0087dd70 */

undefined __thiscall FUN_0087dd70(int param_1,int param_2)

{
  char cVar1;
  
  if ((((NAN(*(float *)(param_1 + 0x24)) || NAN(*(float *)(param_2 + 0x24))) !=
        (*(float *)(param_1 + 0x24) == *(float *)(param_2 + 0x24))) &&
      ((NAN(*(float *)(param_1 + 0x28)) || NAN(*(float *)(param_2 + 0x28))) !=
       (*(float *)(param_1 + 0x28) == *(float *)(param_2 + 0x28)))) &&
     ((NAN(*(float *)(param_1 + 0x2c)) || NAN(*(float *)(param_2 + 0x2c))) !=
      (*(float *)(param_1 + 0x2c) == *(float *)(param_2 + 0x2c)))) {
    cVar1 = FUN_01160ab0(param_2);
    if (cVar1 != '\0') {
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 13567 ; VA 0x0087ddc0 ; FUN_0087ddc0 */

undefined4 FUN_0087ddc0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  
  uVar1 = FUN_01256620(param_1,param_3,param_4);
  FUN_012561a0(param_1,0xffffd8f0,param_2);
  FUN_012570b0(param_1,0xfffffffe);
  return uVar1;
}



/* FUNCTION 13568 ; VA 0x0087de00 ; FUN_0087de00 */

void __fastcall FUN_0087de00(int *param_1)

{
  int *piVar1;
  int *piVar2;
  
  piVar1 = (int *)*param_1;
  piVar2 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar2 != (int *)*param_1) {
    do {
      piVar1 = (int *)*piVar2;
      FUN_01674ea0(piVar2,0xc);
      piVar2 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 13569 ; VA 0x0087de40 ; FUN_0087de40 */

void FUN_0087de40(void)

{
  DAT_01ede6b4 = DAT_01ede6b4 + 1;
  return;
}



/* FUNCTION 13570 ; VA 0x0087de50 ; FUN_0087de50 */

void FUN_0087de50(undefined4 param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  FUN_01256930(param_1,param_2,*puVar1);
  return;
}



/* FUNCTION 13571 ; VA 0x0087de70 ; FUN_0087de70 */

undefined4 FUN_0087de70(undefined4 param_1)

{
  code *pcVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  
  piVar2 = (int *)FUN_01257810(param_1,1,DAT_01ede68c);
  if (piVar2 == (int *)0x0) {
    FUN_012582e0(param_1,1,PTR_s_Enums_01d6d314);
  }
  else {
    piVar3 = (int *)FUN_01257810(param_1,2,DAT_01ede68c);
    if (piVar3 != (int *)0x0) {
      FUN_01256800(param_1,*piVar2 == *piVar3);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_s_Enums_01d6d314);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13572 ; VA 0x0087dee0 ; FUN_0087dee0 */

undefined4 FUN_0087dee0(undefined4 param_1)

{
  code *pcVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  
  piVar2 = (int *)FUN_01257810(param_1,1,DAT_01ede690);
  if (piVar2 == (int *)0x0) {
    FUN_012582e0(param_1,1,PTR_DAT_01d6d318);
  }
  else {
    piVar3 = (int *)FUN_01257810(param_1,2,DAT_01ede690);
    if (piVar3 != (int *)0x0) {
      FUN_01256800(param_1,*piVar2 == *piVar3);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_DAT_01d6d318);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13573 ; VA 0x0087df50 ; FUN_0087df50 */

undefined4 FUN_0087df50(undefined4 param_1)

{
  code *pcVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  
  piVar2 = (int *)FUN_01257810(param_1,1,DAT_01e90cd0);
  if (piVar2 == (int *)0x0) {
    FUN_012582e0(param_1,1,PTR_s_EnumItem_01d6d31c);
  }
  else {
    piVar3 = (int *)FUN_01257810(param_1,2,DAT_01e90cd0);
    if (piVar3 != (int *)0x0) {
      FUN_01256800(param_1,*piVar2 == *piVar3);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_s_EnumItem_01d6d31c);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13574 ; VA 0x0087dfc0 ; FUN_0087dfc0 */

undefined4 FUN_0087dfc0(undefined4 param_1)

{
  code *pcVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  bool bVar5;
  int aiStack_14 [2];
  int aiStack_c [2];
  
  piVar2 = (int *)FUN_01257810(param_1,1,DAT_01ede6a8);
  if (piVar2 == (int *)0x0) {
    FUN_012582e0(param_1,1,PTR_s_RBXScriptSignal_01d6d3e0);
LAB_0087e095:
    FUN_012582e0(param_1,2,PTR_s_RBXScriptSignal_01d6d3e0);
    pcVar1 = (code *)swi(3);
    uVar4 = (*pcVar1)();
    return uVar4;
  }
  piVar3 = (int *)FUN_01257810(param_1,2,DAT_01ede6a8);
  if (piVar3 == (int *)0x0) goto LAB_0087e095;
  if ((((*piVar2 == *piVar3) && (piVar2[5] == piVar3[5])) && (piVar2[6] == piVar3[6])) &&
     ((*(char *)(piVar2 + 7) == *(char *)(piVar3 + 7) && (piVar2[8] == piVar3[8])))) {
    FUN_00587490(aiStack_c);
    if (aiStack_c[0] != 0) {
      FUN_00587490(aiStack_14);
      FUN_00550b30();
      FUN_00550b30();
      bVar5 = false;
      if (aiStack_14[0] != 0) {
        bVar5 = aiStack_c[0] == aiStack_14[0];
      }
      goto LAB_0087e045;
    }
    FUN_00550b30();
  }
  bVar5 = false;
LAB_0087e045:
  FUN_01256800(param_1,bVar5);
  return 1;
}



/* FUNCTION 13575 ; VA 0x0087e0b0 ; FUN_0087e0b0 */

undefined4 FUN_0087e0b0(undefined4 param_1)

{
  code *pcVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  
  piVar2 = (int *)FUN_01257810(param_1,2,DAT_01ede6a0);
  if (piVar2 == (int *)0x0) {
    FUN_012582e0(param_1,2,PTR_s_WeakThreadRef_Node_01d6d32c);
  }
  else {
    piVar3 = (int *)FUN_01257810(param_1,1,DAT_01ede6a0);
    if (piVar3 != (int *)0x0) {
      FUN_01256800(param_1,*piVar3 == *piVar2);
      return 1;
    }
  }
  FUN_012582e0(param_1,1,PTR_s_WeakThreadRef_Node_01d6d32c);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13576 ; VA 0x0087e120 ; FUN_0087e120 */

undefined4 FUN_0087e120(undefined4 param_1)

{
  code *pcVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  
  piVar2 = (int *)FUN_01257810(param_1,2,DAT_01ede6a4);
  if (piVar2 == (int *)0x0) {
    FUN_012582e0(param_1,2,PTR_s_GenericFunction_01d6d330);
  }
  else {
    piVar3 = (int *)FUN_01257810(param_1,1,DAT_01ede6a4);
    if (piVar3 != (int *)0x0) {
      FUN_01256800(param_1,*piVar3 == *piVar2);
      return 1;
    }
  }
  FUN_012582e0(param_1,1,PTR_s_GenericFunction_01d6d330);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13577 ; VA 0x0087e190 ; FUN_0087e190 */

undefined4 FUN_0087e190(undefined4 param_1)

{
  code *pcVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  
  piVar2 = (int *)FUN_01257810(param_1,2,DAT_01ede6ac);
  if (piVar2 == (int *)0x0) {
    FUN_012582e0(param_1,2,PTR_DAT_01d6d3e8);
  }
  else {
    piVar3 = (int *)FUN_01257810(param_1,1,DAT_01ede6ac);
    if (piVar3 != (int *)0x0) {
      FUN_01256800(param_1,*piVar3 == *piVar2);
      return 1;
    }
  }
  FUN_012582e0(param_1,1,PTR_DAT_01d6d3e8);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13578 ; VA 0x0087e200 ; FUN_0087e200 */

undefined4 FUN_0087e200(undefined4 param_1)

{
  code *pcVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  
  piVar2 = (int *)FUN_01257810(param_1,1,DAT_01ede6dc);
  if (piVar2 == (int *)0x0) {
    FUN_012582e0(param_1,1,PTR_DAT_01d6d3a0);
  }
  else {
    piVar3 = (int *)FUN_01257810(param_1,2,DAT_01ede6dc);
    if (piVar3 != (int *)0x0) {
      FUN_01256800(param_1,*piVar2 == *piVar3);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_DAT_01d6d3a0);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13579 ; VA 0x0087e270 ; FUN_0087e270 */

undefined4 FUN_0087e270(undefined4 param_1)

{
  code *pcVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  
  piVar2 = (int *)FUN_01257810(param_1,1,DAT_01ede6d0);
  if (piVar2 == (int *)0x0) {
    FUN_012582e0(param_1,1,PTR_s_BrickColor_01d6d3a4);
  }
  else {
    piVar3 = (int *)FUN_01257810(param_1,2,DAT_01ede6d0);
    if (piVar3 != (int *)0x0) {
      FUN_01256800(param_1,*piVar2 == *piVar3);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_s_BrickColor_01d6d3a4);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13580 ; VA 0x0087e2e0 ; FUN_0087e2e0 */

undefined4 FUN_0087e2e0(undefined4 param_1)

{
  code *pcVar1;
  undefined uVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  
  iVar3 = FUN_01257810(param_1,2,DAT_01ede6b0);
  if (iVar3 == 0) {
    FUN_012582e0(param_1,2,PTR_s_CatalogSearchParams_01d6d360);
  }
  else {
    iVar4 = FUN_01257810(param_1,1,DAT_01ede6b0);
    if (iVar4 != 0) {
      uVar2 = FUN_00da4bd0(iVar4,iVar3);
      FUN_01256800(param_1,uVar2);
      return 1;
    }
  }
  FUN_012582e0(param_1,1,PTR_s_CatalogSearchParams_01d6d360);
  pcVar1 = (code *)swi(3);
  uVar5 = (*pcVar1)();
  return uVar5;
}



/* FUNCTION 13581 ; VA 0x0087e350 ; FUN_0087e350 */

undefined4 FUN_0087e350(undefined4 param_1)

{
  code *pcVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  
  iVar3 = FUN_01257810(param_1,1,DAT_01ede6e0);
  if (iVar3 == 0) {
    FUN_012582e0(param_1,1,PTR_s_CellId_01d6d3a8);
  }
  else {
    iVar3 = FUN_01257810(param_1,2,DAT_01ede6e0);
    if (iVar3 != 0) {
      uVar2 = FUN_00d89750(iVar3);
      FUN_01256800(param_1,uVar2);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_s_CellId_01d6d3a8);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13582 ; VA 0x0087e3c0 ; FUN_0087e3c0 */

undefined4 FUN_0087e3c0(undefined4 param_1)

{
  code *pcVar1;
  float *pfVar2;
  float *pfVar3;
  undefined4 uVar4;
  
  pfVar2 = (float *)FUN_01257810(param_1,1,DAT_01ea8be8);
  if (pfVar2 == (float *)0x0) {
    FUN_012582e0(param_1,1,PTR_s_Color3_01d6d38c);
  }
  else {
    pfVar3 = (float *)FUN_01257810(param_1,2,DAT_01ea8be8);
    if (pfVar3 != (float *)0x0) {
      if ((((NAN(*pfVar2) || NAN(*pfVar3)) != (*pfVar2 == *pfVar3)) &&
          ((NAN(pfVar2[1]) || NAN(pfVar3[1])) != (pfVar2[1] == pfVar3[1]))) &&
         ((NAN(pfVar2[2]) || NAN(pfVar3[2])) != (pfVar2[2] == pfVar3[2]))) {
        FUN_01256800(param_1,1);
        return 1;
      }
      FUN_01256800(param_1,0);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_s_Color3_01d6d38c);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13583 ; VA 0x0087e470 ; FUN_0087e470 */

undefined4 FUN_0087e470(undefined4 param_1)

{
  code *pcVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  
  iVar3 = FUN_01257810(param_1,1,DAT_01ede708);
  if (iVar3 == 0) {
    FUN_012582e0(param_1,1,PTR_s_ColorSequence_01d6d3b0);
  }
  else {
    iVar3 = FUN_01257810(param_1,2,DAT_01ede708);
    if (iVar3 != 0) {
      uVar2 = FUN_00a8e650(iVar3);
      FUN_01256800(param_1,uVar2);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_s_ColorSequence_01d6d3b0);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13584 ; VA 0x0087e4e0 ; FUN_0087e4e0 */

undefined4 FUN_0087e4e0(undefined4 param_1)

{
  code *pcVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  
  iVar3 = FUN_01257810(param_1,1,DAT_01ede700);
  if (iVar3 == 0) {
    FUN_012582e0(param_1,1,PTR_s_ColorSequenceKeypoint_01d6d3b8);
  }
  else {
    iVar3 = FUN_01257810(param_1,2,DAT_01ede700);
    if (iVar3 != 0) {
      uVar2 = FUN_00a8e6e0(iVar3);
      FUN_01256800(param_1,uVar2);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_s_ColorSequenceKeypoint_01d6d3b8);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13585 ; VA 0x0087e550 ; FUN_0087e550 */

undefined4 FUN_0087e550(undefined4 param_1)

{
  code *pcVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  
  piVar2 = (int *)FUN_01257810(param_1,1,DAT_01ede6e4);
  if (piVar2 == (int *)0x0) {
    FUN_012582e0(param_1,1,PTR_s_DateTime_01d6d368);
  }
  else {
    piVar3 = (int *)FUN_01257810(param_1,2,DAT_01ede6e4);
    if (piVar3 != (int *)0x0) {
      if ((*piVar2 == *piVar3) && (piVar2[1] == piVar3[1])) {
        FUN_01256800(param_1,1);
        return 1;
      }
      FUN_01256800(param_1,0);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_s_DateTime_01d6d368);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13586 ; VA 0x0087e5e0 ; FUN_0087e5e0 */

undefined4 FUN_0087e5e0(undefined4 param_1)

{
  code *pcVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  
  piVar2 = (int *)FUN_01257810(param_1,1,DAT_01ede714);
  if (piVar2 == (int *)0x0) {
    FUN_012582e0(param_1,1,PTR_s_DockWidgetPluginGuiInfo_01d6d3c4);
  }
  else {
    piVar3 = (int *)FUN_01257810(param_1,2,DAT_01ede714);
    if (piVar3 != (int *)0x0) {
      if ((((*piVar2 == *piVar3) && (*(char *)(piVar2 + 1) == *(char *)(piVar3 + 1))) &&
          (*(char *)((int)piVar2 + 5) == *(char *)((int)piVar3 + 5))) &&
         (((piVar2[2] == piVar3[2] && (piVar2[3] == piVar3[3])) &&
          ((piVar2[4] == piVar3[4] && (piVar2[5] == piVar3[5])))))) {
        FUN_01256800(param_1,1);
        return 1;
      }
      FUN_01256800(param_1,0);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_s_DockWidgetPluginGuiInfo_01d6d3c4);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13587 ; VA 0x0087e6a0 ; FUN_0087e6a0 */

undefined4 FUN_0087e6a0(undefined4 param_1)

{
  code *pcVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  
  piVar2 = (int *)FUN_01257810(param_1,1,DAT_01ede6d8);
  if (piVar2 == (int *)0x0) {
    FUN_012582e0(param_1,1,PTR_s_Faces_01d6d39c);
  }
  else {
    piVar3 = (int *)FUN_01257810(param_1,2,DAT_01ede6d8);
    if (piVar3 != (int *)0x0) {
      FUN_01256800(param_1,*piVar2 == *piVar3);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_s_Faces_01d6d39c);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13588 ; VA 0x0087e710 ; FUN_0087e710 */

undefined4 FUN_0087e710(undefined4 param_1)

{
  code *pcVar1;
  undefined uVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  
  iVar3 = FUN_01257810(param_1,2,DAT_01ede698);
  if (iVar3 == 0) {
    FUN_012582e0(param_1,2,PTR_s_RaycastParams_01d6d394);
  }
  else {
    iVar4 = FUN_01257810(param_1,1,DAT_01ede698);
    if (iVar4 != 0) {
      uVar2 = FUN_00d89ba0(iVar4,iVar3);
      FUN_01256800(param_1,uVar2);
      return 1;
    }
  }
  FUN_012582e0(param_1,1,PTR_s_RaycastParams_01d6d394);
  pcVar1 = (code *)swi(3);
  uVar5 = (*pcVar1)();
  return uVar5;
}



/* FUNCTION 13589 ; VA 0x0087e780 ; FUN_0087e780 */

undefined4 FUN_0087e780(undefined4 param_1)

{
  code *pcVar1;
  undefined uVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  
  iVar3 = FUN_01257810(param_1,2,DAT_01ede720);
  if (iVar3 == 0) {
    FUN_012582e0(param_1,2,PTR_s_RaycastResult_01d6d3d4);
  }
  else {
    iVar4 = FUN_01257810(param_1,1,DAT_01ede720);
    if (iVar4 != 0) {
      uVar2 = FUN_00d99db0(iVar4,iVar3);
      FUN_01256800(param_1,uVar2);
      return 1;
    }
  }
  FUN_012582e0(param_1,1,PTR_s_RaycastResult_01d6d3d4);
  pcVar1 = (code *)swi(3);
  uVar5 = (*pcVar1)();
  return uVar5;
}



/* FUNCTION 13590 ; VA 0x0087e7f0 ; FUN_0087e7f0 */

undefined4 FUN_0087e7f0(undefined4 param_1)

{
  code *pcVar1;
  float *pfVar2;
  float *pfVar3;
  undefined4 uVar4;
  
  pfVar2 = (float *)FUN_01257810(param_1,1,DAT_01ede70c);
  if (pfVar2 == (float *)0x0) {
    FUN_012582e0(param_1,1,PTR_s_NumberRange_01d6d3bc);
  }
  else {
    pfVar3 = (float *)FUN_01257810(param_1,2,DAT_01ede70c);
    if (pfVar3 != (float *)0x0) {
      if (((NAN(*pfVar2) || NAN(*pfVar3)) != (*pfVar2 == *pfVar3)) &&
         ((NAN(pfVar2[1]) || NAN(pfVar3[1])) != (pfVar2[1] == pfVar3[1]))) {
        FUN_01256800(param_1,1);
        return 1;
      }
      FUN_01256800(param_1,0);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_s_NumberRange_01d6d3bc);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13591 ; VA 0x0087e890 ; FUN_0087e890 */

undefined4 FUN_0087e890(undefined4 param_1)

{
  code *pcVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  
  iVar3 = FUN_01257810(param_1,1,DAT_01ede704);
  if (iVar3 == 0) {
    FUN_012582e0(param_1,1,PTR_s_NumberSequence_01d6d3ac);
  }
  else {
    iVar3 = FUN_01257810(param_1,2,DAT_01ede704);
    if (iVar3 != 0) {
      uVar2 = FUN_00a92f70(iVar3);
      FUN_01256800(param_1,uVar2);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_s_NumberSequence_01d6d3ac);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13592 ; VA 0x0087e900 ; FUN_0087e900 */

undefined4 FUN_0087e900(undefined4 param_1)

{
  code *pcVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  
  iVar3 = FUN_01257810(param_1,1,DAT_01ede6fc);
  if (iVar3 == 0) {
    FUN_012582e0(param_1,1,PTR_s_NumberSequenceKeypoint_01d6d3b4);
  }
  else {
    iVar3 = FUN_01257810(param_1,2,DAT_01ede6fc);
    if (iVar3 != 0) {
      uVar2 = FUN_006e28e0(iVar3);
      FUN_01256800(param_1,uVar2);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_s_NumberSequenceKeypoint_01d6d3b4);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13593 ; VA 0x0087e970 ; FUN_0087e970 */

undefined4 FUN_0087e970(undefined4 param_1)

{
  code *pcVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  
  iVar3 = FUN_01257810(param_1,1,DAT_01ede71c);
  if (iVar3 == 0) {
    FUN_012582e0(param_1,1,PTR_s_PathWaypoint_01d6d3d0);
  }
  else {
    iVar3 = FUN_01257810(param_1,2,DAT_01ede71c);
    if (iVar3 != 0) {
      uVar2 = FUN_00aa1590(iVar3);
      FUN_01256800(param_1,uVar2);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_s_PathWaypoint_01d6d3d0);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13594 ; VA 0x0087e9e0 ; FUN_0087e9e0 */

undefined4 FUN_0087e9e0(undefined4 param_1)

{
  code *pcVar1;
  char *pcVar2;
  char *pcVar3;
  undefined4 uVar4;
  
  pcVar2 = (char *)FUN_01257810(param_1,1,DAT_01ede6cc);
  if (pcVar2 == (char *)0x0) {
    FUN_012582e0(param_1,1,PTR_s_PhysicalProperties_01d6d36c);
  }
  else {
    pcVar3 = (char *)FUN_01257810(param_1,2,DAT_01ede6cc);
    if (pcVar3 != (char *)0x0) {
      if ((((*pcVar2 == *pcVar3) &&
           ((NAN(*(float *)(pcVar2 + 4)) || NAN(*(float *)(pcVar3 + 4))) !=
            (*(float *)(pcVar2 + 4) == *(float *)(pcVar3 + 4)))) &&
          ((NAN(*(float *)(pcVar2 + 0xc)) || NAN(*(float *)(pcVar3 + 0xc))) !=
           (*(float *)(pcVar2 + 0xc) == *(float *)(pcVar3 + 0xc)))) &&
         ((((NAN(*(float *)(pcVar2 + 8)) || NAN(*(float *)(pcVar3 + 8))) !=
            (*(float *)(pcVar2 + 8) == *(float *)(pcVar3 + 8)) &&
           ((NAN(*(float *)(pcVar2 + 0x10)) || NAN(*(float *)(pcVar3 + 0x10))) !=
            (*(float *)(pcVar2 + 0x10) == *(float *)(pcVar3 + 0x10)))) &&
          ((NAN(*(float *)(pcVar2 + 0x14)) || NAN(*(float *)(pcVar3 + 0x14))) !=
           (*(float *)(pcVar2 + 0x14) == *(float *)(pcVar3 + 0x14)))))) {
        FUN_01256800(param_1,1);
        return 1;
      }
      FUN_01256800(param_1,0);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_s_PhysicalProperties_01d6d36c);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13595 ; VA 0x0087eac0 ; FUN_0087eac0 */

undefined4 FUN_0087eac0(undefined4 param_1)

{
  code *pcVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  
  iVar3 = FUN_01257810(param_1,1,DAT_01ede718);
  if (iVar3 == 0) {
    FUN_012582e0(param_1,1,PTR_s_PluginDrag_01d6d3c8);
  }
  else {
    iVar3 = FUN_01257810(param_1,2,DAT_01ede718);
    if (iVar3 != 0) {
      uVar2 = FUN_00da72d0(iVar3);
      FUN_01256800(param_1,uVar2);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_s_PluginDrag_01d6d3c8);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13596 ; VA 0x0087eb30 ; FUN_0087eb30 */

undefined4 FUN_0087eb30(undefined4 param_1)

{
  code *pcVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  
  piVar2 = (int *)FUN_01257810(param_1,1,DAT_01ede6f4);
  if (piVar2 == (int *)0x0) {
    FUN_012582e0(param_1,1,PTR_DAT_01d6d3cc);
  }
  else {
    piVar3 = (int *)FUN_01257810(param_1,2,DAT_01ede6f4);
    if (piVar3 != (int *)0x0) {
      if ((*piVar2 == *piVar3) && (piVar2[1] == piVar3[1])) {
        FUN_01256800(param_1,1);
        return 1;
      }
      FUN_01256800(param_1,0);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_DAT_01d6d3cc);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13597 ; VA 0x0087ebc0 ; FUN_0087ebc0 */

undefined4 FUN_0087ebc0(undefined4 param_1)

{
  code *pcVar1;
  float *pfVar2;
  float *pfVar3;
  undefined4 uVar4;
  
  pfVar2 = (float *)FUN_01257810(param_1,1,DAT_01ede6c8);
  if (pfVar2 == (float *)0x0) {
    FUN_012582e0(param_1,1,PTR_DAT_01d6d370);
  }
  else {
    pfVar3 = (float *)FUN_01257810(param_1,2,DAT_01ede6c8);
    if (pfVar3 != (float *)0x0) {
      if (((((NAN(*pfVar2) || NAN(*pfVar3)) != (*pfVar2 == *pfVar3)) &&
           ((NAN(pfVar2[1]) || NAN(pfVar3[1])) != (pfVar2[1] == pfVar3[1]))) &&
          ((NAN(pfVar2[2]) || NAN(pfVar3[2])) != (pfVar2[2] == pfVar3[2]))) &&
         ((NAN(pfVar2[3]) || NAN(pfVar3[3])) != (pfVar2[3] == pfVar3[3]))) {
        FUN_01256800(param_1,1);
        return 1;
      }
      FUN_01256800(param_1,0);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_DAT_01d6d370);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13598 ; VA 0x0087ec80 ; FUN_0087ec80 */

undefined4 FUN_0087ec80(undefined4 param_1)

{
  code *pcVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  
  iVar3 = FUN_01257810(param_1,1,DAT_01ede6f0);
  if (iVar3 == 0) {
    FUN_012582e0(param_1,1,PTR_s_Region3_01d6d374);
  }
  else {
    iVar4 = FUN_01257810(param_1,2,DAT_01ede6f0);
    if (iVar4 != 0) {
      if (((((NAN(*(float *)(iVar3 + 0x30)) || NAN(*(float *)(iVar4 + 0x30))) !=
             (*(float *)(iVar3 + 0x30) == *(float *)(iVar4 + 0x30))) &&
           ((NAN(*(float *)(iVar3 + 0x34)) || NAN(*(float *)(iVar4 + 0x34))) !=
            (*(float *)(iVar3 + 0x34) == *(float *)(iVar4 + 0x34)))) &&
          ((NAN(*(float *)(iVar3 + 0x38)) || NAN(*(float *)(iVar4 + 0x38))) !=
           (*(float *)(iVar3 + 0x38) == *(float *)(iVar4 + 0x38)))) &&
         ((((NAN(*(float *)(iVar3 + 0x24)) || NAN(*(float *)(iVar4 + 0x24))) !=
            (*(float *)(iVar3 + 0x24) == *(float *)(iVar4 + 0x24)) &&
           ((NAN(*(float *)(iVar3 + 0x28)) || NAN(*(float *)(iVar4 + 0x28))) !=
            (*(float *)(iVar3 + 0x28) == *(float *)(iVar4 + 0x28)))) &&
          ((NAN(*(float *)(iVar3 + 0x2c)) || NAN(*(float *)(iVar4 + 0x2c))) !=
           (*(float *)(iVar3 + 0x2c) == *(float *)(iVar4 + 0x2c)))))) {
        cVar2 = FUN_01160ab0(iVar4);
        if (cVar2 != '\0') {
          FUN_01256800(param_1,1);
          return 1;
        }
      }
      FUN_01256800(param_1,0);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_s_Region3_01d6d374);
  pcVar1 = (code *)swi(3);
  uVar5 = (*pcVar1)();
  return uVar5;
}



/* FUNCTION 13599 ; VA 0x0087ed70 ; FUN_0087ed70 */

undefined4 FUN_0087ed70(undefined4 param_1)

{
  code *pcVar1;
  short *psVar2;
  short *psVar3;
  undefined4 uVar4;
  
  psVar2 = (short *)FUN_01257810(param_1,1,DAT_01ede6f8);
  if (psVar2 == (short *)0x0) {
    FUN_012582e0(param_1,1,PTR_s_Region3int16_01d6d378);
  }
  else {
    psVar3 = (short *)FUN_01257810(param_1,2,DAT_01ede6f8);
    if (psVar3 != (short *)0x0) {
      if ((((*psVar2 == *psVar3) && (psVar2[1] == psVar3[1])) && (psVar2[2] == psVar3[2])) &&
         (((psVar2[3] == psVar3[3] && (psVar2[4] == psVar3[4])) && (psVar2[5] == psVar3[5])))) {
        FUN_01256800(param_1,1);
        return 1;
      }
      FUN_01256800(param_1,0);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_s_Region3int16_01d6d378);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13600 ; VA 0x0087ee30 ; FUN_0087ee30 */

undefined4 FUN_0087ee30(undefined4 param_1)

{
  code *pcVar1;
  float *pfVar2;
  float *pfVar3;
  undefined4 uVar4;
  
  pfVar2 = (float *)FUN_01257810(param_1,1,DAT_01ede710);
  if (pfVar2 == (float *)0x0) {
    FUN_012582e0(param_1,1,PTR_s_TweenInfo_01d6d3c0);
  }
  else {
    pfVar3 = (float *)FUN_01257810(param_1,2,DAT_01ede710);
    if (pfVar3 != (float *)0x0) {
      if (((((NAN(*pfVar2) || NAN(*pfVar3)) != (*pfVar2 == *pfVar3)) &&
           ((NAN(pfVar2[1]) || NAN(pfVar3[1])) != (pfVar2[1] == pfVar3[1]))) &&
          (pfVar2[2] == pfVar3[2])) &&
         (((*(char *)(pfVar2 + 3) == *(char *)(pfVar3 + 3) &&
           ((NAN(pfVar2[4]) || NAN(pfVar3[4])) != (pfVar2[4] == pfVar3[4]))) &&
          ((pfVar2[5] == pfVar3[5] && (pfVar2[6] == pfVar3[6])))))) {
        FUN_01256800(param_1,1);
        return 1;
      }
      FUN_01256800(param_1,0);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_s_TweenInfo_01d6d3c0);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13601 ; VA 0x0087ef10 ; FUN_0087ef10 */

undefined4 FUN_0087ef10(undefined4 param_1)

{
  code *pcVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  
  iVar3 = FUN_01257810(param_1,1,DAT_01ede69c);
  if (iVar3 == 0) {
    FUN_012582e0(param_1,1,PTR_s_RBXScriptConnection_01d6d3e4);
  }
  else {
    iVar3 = FUN_01257810(param_1,2,DAT_01ede69c);
    if (iVar3 != 0) {
      uVar2 = FUN_01679210(iVar3);
      FUN_01256800(param_1,uVar2);
      return 1;
    }
  }
  FUN_012582e0(param_1,2,PTR_s_RBXScriptConnection_01d6d3e4);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 13602 ; VA 0x0087ef80 ; FUN_0087ef80 */

void FUN_0087ef80(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x10);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = *(int **)(param_1 + 8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0087efc5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 13603 ; VA 0x0087efd0 ; FUN_0087efd0 */

void FUN_0087efd0(undefined4 *param_1)

{
  int iVar1;
  int *piVar2;
  
  piVar2 = (int *)*param_1;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if ((iVar1 == 1) && (piVar2 != (int *)0x0)) {
      FUN_00d889a0();
      FUN_01674ea0(piVar2,8);
    }
  }
  return;
}



/* FUNCTION 13604 ; VA 0x0087f010 ; FUN_0087f010 */

void FUN_0087f010(void)

{
  FUN_0087db00();
  return;
}



/* FUNCTION 13605 ; VA 0x0087f020 ; FUN_0087f020 */

int FUN_0087f020(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    param_1 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      param_1 = (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0087f050. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar3 = (**(code **)(*piVar2 + 4))();
        return iVar3;
      }
    }
  }
  return param_1;
}



/* FUNCTION 13606 ; VA 0x0087f060 ; FUN_0087f060 */

void FUN_0087f060(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x14) * 0x14;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 13607 ; VA 0x0087f0d0 ; FUN_0087f0d0 */

void FUN_0087f0d0(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x24);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x10);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0xf;
  *(undefined *)(param_1 + 0x10) = 0;
  piVar4 = *(int **)(param_1 + 0xc);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0087f142. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar4 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 13608 ; VA 0x0087f150 ; FUN_0087f150 */

void FUN_0087f150(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0xc) * 0xc;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 13609 ; VA 0x0087f1c0 ; FUN_0087f1c0 */

void FUN_0087f1c0(int *param_1)

{
  int *piVar1;
  int iVar2;
  
  if (*param_1 != 0) {
    piVar1 = (int *)(*param_1 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0();
      return;
    }
  }
  return;
}



/* FUNCTION 13610 ; VA 0x0087f1f0 ; FUN_0087f1f0 */

void FUN_0087f1f0(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = FUN_01257ce0(param_1,2,0);
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("%s cannot be assigned to",uVar1);
}



/* FUNCTION 13611 ; VA 0x0087f210 ; FUN_0087f210 */

undefined4 FUN_0087f210(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede6dc);
  if (iVar1 != 0) {
    FUN_00aa5450(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0087f2bf;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_DAT_01d6d3a0);
LAB_0087f2bf:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13612 ; VA 0x0087f2d0 ; FUN_0087f2d0 */

undefined4 FUN_0087f2d0(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede6d0);
  if (iVar1 != 0) {
    FUN_00d859e0(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0087f37f;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_BrickColor_01d6d3a4);
LAB_0087f37f:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13613 ; VA 0x0087f390 ; FUN_0087f390 */

undefined4 FUN_0087f390(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede6b0);
  if (iVar1 != 0) {
    FUN_00da4f60(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0087f43f;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_CatalogSearchParams_01d6d360);
LAB_0087f43f:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13614 ; VA 0x0087f450 ; FUN_0087f450 */

undefined4 FUN_0087f450(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede6e0);
  if (iVar1 != 0) {
    FUN_00d85a00(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0087f4ff;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_CellId_01d6d3a8);
LAB_0087f4ff:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13615 ; VA 0x0087f510 ; FUN_0087f510 */

undefined4 FUN_0087f510(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ea8be8);
  if (iVar1 != 0) {
    FUN_00d85d20(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0087f5bf;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_Color3_01d6d38c);
LAB_0087f5bf:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13616 ; VA 0x0087f5d0 ; FUN_0087f5d0 */

undefined4 FUN_0087f5d0(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede708);
  if (iVar1 != 0) {
    FUN_00a905f0(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0087f67f;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_ColorSequence_01d6d3b0);
LAB_0087f67f:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13617 ; VA 0x0087f690 ; FUN_0087f690 */

undefined4 FUN_0087f690(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede700);
  if (iVar1 != 0) {
    FUN_00a90610(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0087f73f;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_ColorSequenceKeypoint_01d6d3b8);
LAB_0087f73f:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13618 ; VA 0x0087f750 ; FUN_0087f750 */

undefined4 FUN_0087f750(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede6d4);
  if (iVar1 != 0) {
    FUN_00d85e30(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0087f7ff;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_DAT_01d6d364);
LAB_0087f7ff:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13619 ; VA 0x0087f810 ; FUN_0087f810 */

undefined4 FUN_0087f810(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede6e4);
  if (iVar1 != 0) {
    FUN_00b418c0(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0087f8bf;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_DateTime_01d6d368);
LAB_0087f8bf:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13620 ; VA 0x0087f8d0 ; FUN_0087f8d0 */

undefined4 FUN_0087f8d0(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede714);
  if (iVar1 != 0) {
    FUN_00da9ef0(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0087f97f;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_DockWidgetPluginGuiInfo_01d6d3c4);
LAB_0087f97f:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13621 ; VA 0x0087f990 ; FUN_0087f990 */

undefined4 FUN_0087f990(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede6d8);
  if (iVar1 != 0) {
    FUN_00a922c0(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0087fa3f;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_Faces_01d6d39c);
LAB_0087fa3f:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13622 ; VA 0x0087fa50 ; FUN_0087fa50 */

undefined4 FUN_0087fa50(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede698);
  if (iVar1 != 0) {
    FUN_00d89d00(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0087faff;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_RaycastParams_01d6d394);
LAB_0087faff:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13623 ; VA 0x0087fb10 ; FUN_0087fb10 */

undefined4 FUN_0087fb10(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede720);
  if (iVar1 != 0) {
    FUN_00d99de0(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0087fbbf;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_RaycastResult_01d6d3d4);
LAB_0087fbbf:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13624 ; VA 0x0087fbd0 ; FUN_0087fbd0 */

undefined4 FUN_0087fbd0(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede70c);
  if (iVar1 != 0) {
    FUN_00b333e0(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0087fc7f;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_NumberRange_01d6d3bc);
LAB_0087fc7f:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13625 ; VA 0x0087fc90 ; FUN_0087fc90 */

undefined4 FUN_0087fc90(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede704);
  if (iVar1 != 0) {
    FUN_00a92ff0(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0087fd3f;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_NumberSequence_01d6d3ac);
LAB_0087fd3f:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13626 ; VA 0x0087fd50 ; FUN_0087fd50 */

undefined4 FUN_0087fd50(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede6fc);
  if (iVar1 != 0) {
    FUN_00a93010(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0087fdff;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_NumberSequenceKeypoint_01d6d3b4);
LAB_0087fdff:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13627 ; VA 0x0087fe10 ; FUN_0087fe10 */

undefined4 FUN_0087fe10(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede71c);
  if (iVar1 != 0) {
    FUN_00aa3850(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0087febf;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_PathWaypoint_01d6d3d0);
LAB_0087febf:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13628 ; VA 0x0087fed0 ; FUN_0087fed0 */

undefined4 FUN_0087fed0(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede6cc);
  if (iVar1 != 0) {
    FUN_00d85f30(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0087ff7f;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_PhysicalProperties_01d6d36c);
LAB_0087ff7f:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13629 ; VA 0x0087ff90 ; FUN_0087ff90 */

undefined4 FUN_0087ff90(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede718);
  if (iVar1 != 0) {
    FUN_00da73b0(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0088003f;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_PluginDrag_01d6d3c8);
LAB_0088003f:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13630 ; VA 0x00880050 ; FUN_00880050 */

undefined4 FUN_00880050(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede6f4);
  if (iVar1 != 0) {
    FUN_00da8940(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_008800ff;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_DAT_01d6d3cc);
LAB_008800ff:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13631 ; VA 0x00880110 ; FUN_00880110 */

undefined4 FUN_00880110(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede6b8);
  if (iVar1 != 0) {
    FUN_00d861e0(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_008801bf;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_DAT_01d6d380);
LAB_008801bf:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13632 ; VA 0x008801d0 ; FUN_008801d0 */

undefined4 FUN_008801d0(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede6c8);
  if (iVar1 != 0) {
    FUN_00d864e0(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0088027f;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_DAT_01d6d370);
LAB_0088027f:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13633 ; VA 0x00880290 ; FUN_00880290 */

undefined4 FUN_00880290(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede6f0);
  if (iVar1 != 0) {
    FUN_00d866c0(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0088033f;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_Region3_01d6d374);
LAB_0088033f:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13634 ; VA 0x00880350 ; FUN_00880350 */

undefined4 FUN_00880350(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede6f8);
  if (iVar1 != 0) {
    FUN_00d86840(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_008803ff;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_Region3int16_01d6d378);
LAB_008803ff:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13635 ; VA 0x00880410 ; FUN_00880410 */

undefined4 FUN_00880410(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede710);
  if (iVar1 != 0) {
    FUN_00da9180(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_008804bf;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_TweenInfo_01d6d3c0);
LAB_008804bf:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13636 ; VA 0x008804d0 ; FUN_008804d0 */

undefined4 FUN_008804d0(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede6ec);
  if (iVar1 != 0) {
    FUN_00da8050(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0088057f;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_UDim2_01d6d398);
LAB_0088057f:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13637 ; VA 0x00880590 ; FUN_00880590 */

undefined4 FUN_00880590(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede6e8);
  if (iVar1 != 0) {
    FUN_00da8350(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0088063f;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_DAT_01d6d390);
LAB_0088063f:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13638 ; VA 0x00880650 ; FUN_00880650 */

undefined4 FUN_00880650(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede6c4);
  if (iVar1 != 0) {
    FUN_00d86910(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_008806ff;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_Vector2_01d6d384);
LAB_008806ff:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13639 ; VA 0x00880710 ; FUN_00880710 */

undefined4 FUN_00880710(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede6c0);
  if (iVar1 != 0) {
    FUN_00d869e0(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_008807bf;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_Vector2int16_01d6d388);
LAB_008807bf:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13640 ; VA 0x008807d0 ; FUN_008807d0 */

undefined4 FUN_008807d0(undefined4 param_1)

{
  int iVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01257810(param_1,1,DAT_01ede6bc);
  if (iVar1 != 0) {
    FUN_00d86c00(apppuStack_28,iVar1);
    ppppuVar2 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    }
    uStack_8 = 0;
    FUN_01256930(param_1,ppppuVar2,uStack_18);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      ppppuVar2 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar3) {
        ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) goto LAB_0088087f;
      }
      FUN_01674ea0(ppppuVar2,uVar3);
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_012582e0(param_1,1,PTR_s_Vector3int16_01d6d37c);
LAB_0088087f:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13641 ; VA 0x00880890 ; FUN_00880890 */

void FUN_00880890(undefined4 param_1,int param_2)

{
  FUN_012569c0(param_1,"The metatable is locked");
  FUN_01257030(param_1,param_2 + -1,"__metatable");
  return;
}



/* FUNCTION 13642 ; VA 0x008808c0 ; FUN_008808c0 */

void FUN_008808c0(undefined4 param_1,undefined4 param_2)

{
  undefined *puVar1;
  int iVar2;
  undefined4 *puVar3;
  
  FUN_01256910(param_1,FUN_008808c0);
  FUN_01256be0(param_1,0xffffd8f0);
  FUN_01256910(param_1,param_2);
  FUN_01256be0(param_1,0xfffffffe);
  iVar2 = FUN_012578b0(param_1,0xffffffff);
  if (iVar2 == 0) {
    FUN_01257280(param_1,0xfffffffe);
    puVar1 = PTR_s_Enums_01d6d314;
    puVar3 = (undefined4 *)FUN_01256620(param_1,4,DAT_01ede68c);
    FUN_012561a0(param_1,0xffffd8f0,puVar1);
    FUN_012570b0(param_1,0xfffffffe);
    *puVar3 = param_2;
    FUN_01256910(param_1,param_2);
    FUN_01256aa0(param_1,0xfffffffe);
    FUN_01256d00(param_1,0xfffffffc);
  }
  FUN_01256e40(param_1,0xfffffffe);
  return;
}



/* FUNCTION 13643 ; VA 0x00880960 ; FUN_00880960 */

void FUN_00880960(undefined4 param_1,undefined4 param_2)

{
  undefined *puVar1;
  int iVar2;
  undefined4 *puVar3;
  
  FUN_01256910(param_1,FUN_00880960);
  FUN_01256be0(param_1,0xffffd8f0);
  FUN_01256910(param_1,param_2);
  FUN_01256be0(param_1,0xfffffffe);
  iVar2 = FUN_012578b0(param_1,0xffffffff);
  if (iVar2 == 0) {
    FUN_01257280(param_1,0xfffffffe);
    puVar1 = PTR_DAT_01d6d318;
    puVar3 = (undefined4 *)FUN_01256620(param_1,4,DAT_01ede690);
    FUN_012561a0(param_1,0xffffd8f0,puVar1);
    FUN_012570b0(param_1,0xfffffffe);
    *puVar3 = param_2;
    FUN_01256910(param_1,param_2);
    FUN_01256aa0(param_1,0xfffffffe);
    FUN_01256d00(param_1,0xfffffffc);
  }
  FUN_01256e40(param_1,0xfffffffe);
  return;
}



/* FUNCTION 13644 ; VA 0x00880a00 ; FUN_00880a00 */

void FUN_00880a00(undefined4 param_1,undefined4 param_2)

{
  undefined *puVar1;
  int iVar2;
  undefined4 *puVar3;
  
  FUN_01256910(param_1,FUN_00880a00);
  FUN_01256be0(param_1,0xffffd8f0);
  FUN_01256910(param_1,param_2);
  FUN_01256be0(param_1,0xfffffffe);
  iVar2 = FUN_012578b0(param_1,0xffffffff);
  if (iVar2 == 0) {
    FUN_01257280(param_1,0xfffffffe);
    puVar1 = PTR_s_EnumItem_01d6d31c;
    puVar3 = (undefined4 *)FUN_01256620(param_1,4,DAT_01e90cd0);
    FUN_012561a0(param_1,0xffffd8f0,puVar1);
    FUN_012570b0(param_1,0xfffffffe);
    *puVar3 = param_2;
    FUN_01256910(param_1,param_2);
    FUN_01256aa0(param_1,0xfffffffe);
    FUN_01256d00(param_1,0xfffffffc);
  }
  FUN_01256e40(param_1,0xfffffffe);
  return;
}



/* FUNCTION 13645 ; VA 0x00880aa0 ; FUN_00880aa0 */

void FUN_00880aa0(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  code *pcStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d9d040;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087dfc0;
  pcStack_24 = FUN_00d9d3b0;
  pcStack_5c = FUN_00d9d040;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087dfc0;
  pcStack_50 = FUN_00d9d3b0;
  pcStack_34 = FUN_0087ef80;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_RBXScriptSignal_01d6d3e0,DAT_01ede6a8,&pcStack_5c);
  return;
}



/* FUNCTION 13646 ; VA 0x00880b20 ; FUN_00880b20 */

void FUN_00880b20(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  code *pcStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d893b0;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087e0b0;
  pcStack_24 = FUN_00d9e1a0;
  pcStack_5c = FUN_00d893b0;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087e0b0;
  pcStack_50 = FUN_00d9e1a0;
  pcStack_34 = FUN_0087efd0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_WeakThreadRef_Node_01d6d32c,DAT_01ede6a0,&pcStack_5c);
  return;
}



/* FUNCTION 13647 ; VA 0x00880ba0 ; FUN_00880ba0 */

void FUN_00880ba0(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  code *pcStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d893b0;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087e120;
  pcStack_24 = FUN_00d9e1c0;
  pcStack_5c = FUN_00d893b0;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087e120;
  pcStack_50 = FUN_00d9e1c0;
  pcStack_34 = FUN_0057d5e0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_GenericFunction_01d6d330,DAT_01ede6a4,&pcStack_5c);
  return;
}



/* FUNCTION 13648 ; VA 0x00880c20 ; FUN_00880c20 */

void FUN_00880c20(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d93440;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087e200;
  pcStack_24 = FUN_0087f210;
  pcStack_5c = FUN_00d93440;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087e200;
  pcStack_50 = FUN_0087f210;
  uStack_34 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_DAT_01d6d3a0,DAT_01ede6dc,&pcStack_5c);
  return;
}



/* FUNCTION 13649 ; VA 0x00880ca0 ; FUN_00880ca0 */

void FUN_00880ca0(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d93700;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087e270;
  pcStack_24 = FUN_0087f2d0;
  pcStack_5c = FUN_00d93700;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087e270;
  pcStack_50 = FUN_0087f2d0;
  uStack_34 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_BrickColor_01d6d3a4,DAT_01ede6d0,&pcStack_5c);
  return;
}



/* FUNCTION 13650 ; VA 0x00880d20 ; FUN_00880d20 */

void FUN_00880d20(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  code *pcStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d939d0;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_00d97660;
  pcStack_28 = FUN_0087e2e0;
  pcStack_24 = FUN_0087f390;
  pcStack_5c = FUN_00d939d0;
  pcStack_58 = FUN_00d97660;
  pcStack_54 = FUN_0087e2e0;
  pcStack_50 = FUN_0087f390;
  pcStack_34 = FUN_0087f010;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_CatalogSearchParams_01d6d360,DAT_01ede6b0,&pcStack_5c);
  return;
}



/* FUNCTION 13651 ; VA 0x00880da0 ; FUN_00880da0 */

void FUN_00880da0(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  code *pcStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d93df0;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087e350;
  pcStack_24 = FUN_0087f450;
  pcStack_5c = FUN_00d93df0;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087e350;
  pcStack_50 = FUN_0087f450;
  pcStack_34 = FUN_0087f020;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_CellId_01d6d3a8,DAT_01ede6e0,&pcStack_5c);
  return;
}



/* FUNCTION 13652 ; VA 0x00880e20 ; FUN_00880e20 */

void FUN_00880e20(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  code *pcStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d94180;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087e470;
  pcStack_24 = FUN_0087f5d0;
  pcStack_5c = FUN_00d94180;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087e470;
  pcStack_50 = FUN_0087f5d0;
  pcStack_34 = FUN_0087f060;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_ColorSequence_01d6d3b0,DAT_01ede708,&pcStack_5c);
  return;
}



/* FUNCTION 13653 ; VA 0x00880ea0 ; FUN_00880ea0 */

void FUN_00880ea0(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d942c0;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087e4e0;
  pcStack_24 = FUN_0087f690;
  pcStack_5c = FUN_00d942c0;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087e4e0;
  pcStack_50 = FUN_0087f690;
  uStack_34 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_ColorSequenceKeypoint_01d6d3b8,DAT_01ede700,&pcStack_5c);
  return;
}



/* FUNCTION 13654 ; VA 0x00880f20 ; FUN_00880f20 */

void FUN_00880f20(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d94970;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087e5e0;
  pcStack_24 = FUN_0087f8d0;
  pcStack_5c = FUN_00d94970;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087e5e0;
  pcStack_50 = FUN_0087f8d0;
  uStack_34 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_DockWidgetPluginGuiInfo_01d6d3c4,DAT_01ede714,&pcStack_5c);
  return;
}



/* FUNCTION 13655 ; VA 0x00880fa0 ; FUN_00880fa0 */

void FUN_00880fa0(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d94bc0;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087e6a0;
  pcStack_24 = FUN_0087f990;
  pcStack_5c = FUN_00d94bc0;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087e6a0;
  pcStack_50 = FUN_0087f990;
  uStack_34 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_Faces_01d6d39c,DAT_01ede6d8,&pcStack_5c);
  return;
}



/* FUNCTION 13656 ; VA 0x00881020 ; FUN_00881020 */

void FUN_00881020(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  code *pcStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d94da0;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_00d979f0;
  pcStack_28 = FUN_0087e710;
  pcStack_24 = FUN_0087fa50;
  pcStack_5c = FUN_00d94da0;
  pcStack_58 = FUN_00d979f0;
  pcStack_54 = FUN_0087e710;
  pcStack_50 = FUN_0087fa50;
  pcStack_34 = FUN_0087f0d0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_RaycastParams_01d6d394,DAT_01ede698,&pcStack_5c);
  return;
}



/* FUNCTION 13657 ; VA 0x008810a0 ; FUN_008810a0 */

void FUN_008810a0(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  code *pcStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d94f40;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087e780;
  pcStack_24 = FUN_0087fb10;
  pcStack_5c = FUN_00d94f40;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087e780;
  pcStack_50 = FUN_0087fb10;
  pcStack_34 = FUN_0057e0b0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_RaycastResult_01d6d3d4,DAT_01ede720,&pcStack_5c);
  return;
}



/* FUNCTION 13658 ; VA 0x00881120 ; FUN_00881120 */

void FUN_00881120(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d951c0;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087e7f0;
  pcStack_24 = FUN_0087fbd0;
  pcStack_5c = FUN_00d951c0;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087e7f0;
  pcStack_50 = FUN_0087fbd0;
  uStack_34 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_NumberRange_01d6d3bc,DAT_01ede70c,&pcStack_5c);
  return;
}



/* FUNCTION 13659 ; VA 0x008811a0 ; FUN_008811a0 */

void FUN_008811a0(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  code *pcStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d952b0;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087e890;
  pcStack_24 = FUN_0087fc90;
  pcStack_5c = FUN_00d952b0;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087e890;
  pcStack_50 = FUN_0087fc90;
  pcStack_34 = FUN_0087f150;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_NumberSequence_01d6d3ac,DAT_01ede704,&pcStack_5c);
  return;
}



/* FUNCTION 13660 ; VA 0x00881220 ; FUN_00881220 */

void FUN_00881220(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d953f0;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087e900;
  pcStack_24 = FUN_0087fd50;
  pcStack_5c = FUN_00d953f0;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087e900;
  pcStack_50 = FUN_0087fd50;
  uStack_34 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_NumberSequenceKeypoint_01d6d3b4,DAT_01ede6fc,&pcStack_5c);
  return;
}



/* FUNCTION 13661 ; VA 0x008812a0 ; FUN_008812a0 */

void FUN_008812a0(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d95520;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087e970;
  pcStack_24 = FUN_0087fe10;
  pcStack_5c = FUN_00d95520;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087e970;
  pcStack_50 = FUN_0087fe10;
  uStack_34 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_PathWaypoint_01d6d3d0,DAT_01ede71c,&pcStack_5c);
  return;
}



/* FUNCTION 13662 ; VA 0x00881320 ; FUN_00881320 */

void FUN_00881320(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d956b0;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087e9e0;
  pcStack_24 = FUN_0087fed0;
  pcStack_5c = FUN_00d956b0;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087e9e0;
  pcStack_50 = FUN_0087fed0;
  uStack_34 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_PhysicalProperties_01d6d36c,DAT_01ede6cc,&pcStack_5c);
  return;
}



/* FUNCTION 13663 ; VA 0x008813a0 ; FUN_008813a0 */

void FUN_008813a0(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  code *pcStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d95850;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087eac0;
  pcStack_24 = FUN_0087ff90;
  pcStack_5c = FUN_00d95850;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087eac0;
  pcStack_50 = FUN_0087ff90;
  pcStack_34 = FUN_0057d5e0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_PluginDrag_01d6d3c8,DAT_01ede718,&pcStack_5c);
  return;
}



/* FUNCTION 13664 ; VA 0x00881420 ; FUN_00881420 */

void FUN_00881420(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d95d70;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087ebc0;
  pcStack_24 = FUN_008801d0;
  pcStack_5c = FUN_00d95d70;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087ebc0;
  pcStack_50 = FUN_008801d0;
  uStack_34 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_DAT_01d6d370,DAT_01ede6c8,&pcStack_5c);
  return;
}



/* FUNCTION 13665 ; VA 0x008814a0 ; FUN_008814a0 */

void FUN_008814a0(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d96080;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087ed70;
  pcStack_24 = FUN_00880350;
  pcStack_5c = FUN_00d96080;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087ed70;
  pcStack_50 = FUN_00880350;
  uStack_34 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_Region3int16_01d6d378,DAT_01ede6f8,&pcStack_5c);
  return;
}



/* FUNCTION 13666 ; VA 0x00881520 ; FUN_00881520 */

void FUN_00881520(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d96170;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087ee30;
  pcStack_24 = FUN_00880410;
  pcStack_5c = FUN_00d96170;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087ee30;
  pcStack_50 = FUN_00880410;
  uStack_34 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_TweenInfo_01d6d3c0,DAT_01ede710,&pcStack_5c);
  return;
}



/* FUNCTION 13667 ; VA 0x008815a0 ; FUN_008815a0 */

void FUN_008815a0(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  code *pcStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  code *pcStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d9d240;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087ef10;
  pcStack_24 = FUN_00d9e1e0;
  pcStack_5c = FUN_00d9d240;
  pcStack_58 = FUN_0087f1f0;
  pcStack_54 = FUN_0087ef10;
  pcStack_50 = FUN_00d9e1e0;
  pcStack_34 = FUN_0087f1c0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_RBXScriptConnection_01d6d3e4,DAT_01ede69c,&pcStack_5c);
  return;
}



/* FUNCTION 13668 ; VA 0x00881620 ; FUN_00881620 */

void FUN_00881620(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  undefined4 uStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d87c70;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087de70;
  pcStack_24 = FUN_00d87f70;
  pcStack_5c = FUN_00d87c70;
  pcStack_58 = FUN_0087f1f0;
  pcStack_50 = FUN_00d87f70;
  uStack_34 = 0;
  uStack_54 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_Enums_01d6d314,DAT_01ede68c,&pcStack_5c);
  return;
}



/* FUNCTION 13669 ; VA 0x008816a0 ; FUN_008816a0 */

void FUN_008816a0(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  undefined4 uStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d87d10;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087dee0;
  pcStack_24 = FUN_00d87f90;
  pcStack_5c = FUN_00d87d10;
  pcStack_58 = FUN_0087f1f0;
  pcStack_50 = FUN_00d87f90;
  uStack_34 = 0;
  uStack_54 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_DAT_01d6d318,DAT_01ede690,&pcStack_5c);
  return;
}



/* FUNCTION 13670 ; VA 0x00881720 ; FUN_00881720 */

void FUN_00881720(undefined4 param_1)

{
  code *pcStack_5c;
  code *pcStack_58;
  undefined4 uStack_54;
  code *pcStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_34;
  code *pcStack_30;
  code *pcStack_2c;
  code *pcStack_28;
  code *pcStack_24;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  pcStack_30 = FUN_00d87de0;
  uStack_20 = 0;
  uStack_18 = 0;
  uStack_10 = 0;
  pcStack_2c = FUN_0087f1f0;
  pcStack_28 = FUN_0087df50;
  pcStack_24 = FUN_00d87ff0;
  pcStack_5c = FUN_00d87de0;
  pcStack_58 = FUN_0087f1f0;
  pcStack_50 = FUN_00d87ff0;
  uStack_34 = 0;
  uStack_54 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_3c = 0;
  FUN_00881830(param_1,PTR_s_EnumItem_01d6d31c,DAT_01e90cd0,&pcStack_5c);
  return;
}



/* FUNCTION 13671 ; VA 0x008817a0 ; FUN_008817a0 */

void FUN_008817a0(undefined4 param_1)

{
  FUN_01256910(param_1,FUN_008808c0);
  FUN_01255f00(param_1,0,0);
  FUN_01256d00(param_1,0xffffd8f0);
  return;
}



/* FUNCTION 13672 ; VA 0x008817d0 ; FUN_008817d0 */

void FUN_008817d0(undefined4 param_1)

{
  FUN_01256910(param_1,FUN_00880960);
  FUN_01255f00(param_1,0,0);
  FUN_01256d00(param_1,0xffffd8f0);
  return;
}



/* FUNCTION 13673 ; VA 0x00881800 ; FUN_00881800 */

void FUN_00881800(undefined4 param_1)

{
  FUN_01256910(param_1,FUN_00880a00);
  FUN_01255f00(param_1,0,0);
  FUN_01256d00(param_1,0xffffd8f0);
  return;
}



/* FUNCTION 13674 ; VA 0x00881830 ; FUN_00881830 */

void FUN_00881830(int param_1,undefined4 param_2,int param_3,int *param_4)

{
  FUN_01257f40(param_1,param_2);
  FUN_012569c0(param_1,"The metatable is locked");
  FUN_01257030(param_1,0xfffffffe,"__metatable");
  FUN_012569c0(param_1,"__type");
  FUN_012569c0(param_1,param_2);
  FUN_01257230(param_1,0xfffffffd);
  if (*param_4 != 0) {
    FUN_012569c0(param_1,&DAT_0191c860);
    FUN_01256820(param_1,*param_4,0,0,0);
    FUN_01257230(param_1,0xfffffffd);
  }
  if (param_4[1] != 0) {
    FUN_012569c0(param_1,"__newindex");
    FUN_01256820(param_1,param_4[1],0,0,0);
    FUN_01257230(param_1,0xfffffffd);
  }
  if (param_4[2] != 0) {
    FUN_012569c0(param_1,&DAT_0191c874);
    FUN_01256820(param_1,param_4[2],0,0,0);
    FUN_01257230(param_1,0xfffffffd);
  }
  if (param_4[3] != 0) {
    FUN_012569c0(param_1,"__tostring");
    FUN_01256820(param_1,param_4[3],0,0,0);
    FUN_01257230(param_1,0xfffffffd);
  }
  if (param_4[4] != 0) {
    FUN_012569c0(param_1,&DAT_0191c888);
    FUN_01256820(param_1,param_4[4],0,0,0);
    FUN_01257230(param_1,0xfffffffd);
  }
  if (param_4[5] != 0) {
    FUN_012569c0(param_1,"__add");
    FUN_01256820(param_1,param_4[5],0,0,0);
    FUN_01257230(param_1,0xfffffffd);
  }
  if (param_4[6] != 0) {
    FUN_012569c0(param_1,"__sub");
    FUN_01256820(param_1,param_4[6],0,0,0);
    FUN_01257230(param_1,0xfffffffd);
  }
  if (param_4[7] != 0) {
    FUN_012569c0(param_1,"__mul");
    FUN_01256820(param_1,param_4[7],0,0,0);
    FUN_01257230(param_1,0xfffffffd);
  }
  if (param_4[8] != 0) {
    FUN_012569c0(param_1,"__div");
    FUN_01256820(param_1,param_4[8],0,0,0);
    FUN_01257230(param_1,0xfffffffd);
  }
  if (param_4[9] != 0) {
    FUN_012569c0(param_1,"__unm");
    FUN_01256820(param_1,param_4[9],0,0,0);
    FUN_01257230(param_1,0xfffffffd);
  }
  FUN_01257190(param_1,0xffffffff,1);
  FUN_01257280(param_1,0xfffffffe);
  if (param_4[10] != 0) {
    *(int *)(*(int *)(param_1 + 0x10) + 0x1b0 + param_3 * 4) = param_4[10];
  }
  return;
}



/* FUNCTION 13675 ; VA 0x00881a60 ; FUN_00881a60 */

undefined * FUN_00881a60(undefined4 param_1,undefined4 param_2)

{
  undefined *puVar1;
  undefined *puVar2;
  
  puVar1 = (undefined *)FUN_01257440(param_1,param_2,0);
  puVar2 = PTR_DAT_01d62820;
  if (puVar1 != (undefined *)0x0) {
    puVar2 = puVar1;
  }
  return puVar2;
}



/* FUNCTION 13676 ; VA 0x00881a90 ; FUN_00881a90 */

void FUN_00881a90(undefined4 param_1,undefined4 param_2)

{
  uint uStack_8;
  
  FUN_01257ce0(param_1,param_2,&uStack_8);
  if (uStack_8 < 200000) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("String too long");
}



/* FUNCTION 13677 ; VA 0x00881ac0 ; FUN_00881ac0 */

void FUN_00881ac0(int param_1,int param_2,int param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar2 = param_3 - param_1 >> 2;
  if (iVar2 < 0x29) {
    cVar1 = FUN_00a33d80(param_1);
    if (cVar1 != '\0') {
      FUN_00882590(param_2,param_1);
    }
    cVar1 = FUN_00a33d80(param_2);
    if (cVar1 != '\0') {
      FUN_00882590(param_3,param_2);
      cVar1 = FUN_00a33d80(param_1);
      if (cVar1 != '\0') {
        FUN_00882590(param_2,param_1);
      }
    }
  }
  else {
    iVar3 = iVar2 + 1 >> 3;
    iVar2 = iVar3 * 4 + param_1;
    cVar1 = FUN_00a33d80(param_1);
    if (cVar1 != '\0') {
      FUN_00882590(iVar2,param_1);
    }
    cVar1 = FUN_00a33d80(iVar2);
    if (cVar1 != '\0') {
      FUN_00882590(iVar3 * 8 + param_1,iVar2);
      cVar1 = FUN_00a33d80(param_1);
      if (cVar1 != '\0') {
        FUN_00882590(iVar2,param_1);
      }
    }
    iVar4 = param_2 + iVar3 * -4;
    cVar1 = FUN_00a33d80(iVar4);
    if (cVar1 != '\0') {
      FUN_00882590(param_2,iVar4);
    }
    cVar1 = FUN_00a33d80(param_2);
    if (cVar1 != '\0') {
      FUN_00882590(iVar3 * 4 + param_2,param_2);
      cVar1 = FUN_00a33d80(iVar4);
      if (cVar1 != '\0') {
        FUN_00882590(param_2,iVar4);
      }
    }
    iVar4 = param_3 + iVar3 * -8;
    iVar3 = param_3 + iVar3 * -4;
    cVar1 = FUN_00a33d80(iVar4);
    if (cVar1 != '\0') {
      FUN_00882590(iVar3,iVar4);
    }
    cVar1 = FUN_00a33d80(iVar3);
    if (cVar1 != '\0') {
      FUN_00882590(param_3,iVar3);
      cVar1 = FUN_00a33d80(iVar4);
      if (cVar1 != '\0') {
        FUN_00882590(iVar3,iVar4);
      }
    }
    cVar1 = FUN_00a33d80(iVar2);
    if (cVar1 != '\0') {
      FUN_00882590(param_2,iVar2);
    }
    cVar1 = FUN_00a33d80(param_2);
    if (cVar1 != '\0') {
      FUN_00882590(iVar3,param_2);
      cVar1 = FUN_00a33d80(iVar2);
      if (cVar1 != '\0') {
        FUN_00882590(param_2,iVar2);
        return;
      }
    }
  }
  return;
}



/* FUNCTION 13678 ; VA 0x00881c90 ; FUN_00881c90 */

void FUN_00881c90(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b9c38;
  pvStack_10 = ExceptionList;
  uVar5 = param_2 - param_1 >> 2;
  iVar6 = param_2 - param_1 >> 3;
  if (0 < iVar6) {
    iVar7 = (int)(uVar5 - 1) >> 1;
    ExceptionList = &pvStack_10;
    do {
      iStack_14 = *(int *)(param_1 + -4 + iVar6 * 4);
      iVar6 = iVar6 + -1;
      LOCK();
      *(int *)(iStack_14 + 0x28) = *(int *)(iStack_14 + 0x28) + 1;
      UNLOCK();
      uStack_8 = 0;
      iVar3 = iVar6;
      while (iVar3 < iVar7) {
        iVar8 = iVar3 * 2 + 2;
        cVar4 = FUN_00a33d80(param_1 + iVar8 * 4 + -4);
        if (cVar4 != '\0') {
          iVar8 = iVar3 * 2 + 1;
        }
        iVar2 = *(int *)(param_1 + iVar8 * 4);
        LOCK();
        piVar1 = (int *)(iVar2 + 0x28);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
        *(int *)(param_1 + iVar3 * 4) = iVar2;
        FUN_0056cd30();
        iVar3 = iVar8;
      }
      if ((iVar3 == iVar7) && ((uVar5 & 1) == 0)) {
        iVar8 = *(int *)(param_1 + -4 + uVar5 * 4);
        LOCK();
        piVar1 = (int *)(iVar8 + 0x28);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
        *(int *)(param_1 + iVar3 * 4) = iVar8;
        FUN_0056cd30();
        iVar3 = uVar5 - 1;
      }
      while (iVar6 < iVar3) {
        iVar8 = iVar3 + -1 >> 1;
        cVar4 = FUN_00a33d80(&iStack_14);
        if (cVar4 == '\0') break;
        iVar2 = *(int *)(param_1 + iVar8 * 4);
        LOCK();
        piVar1 = (int *)(iVar2 + 0x28);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
        *(int *)(param_1 + iVar3 * 4) = iVar2;
        FUN_0056cd30();
        iVar3 = iVar8;
      }
      LOCK();
      *(int *)(iStack_14 + 0x28) = *(int *)(iStack_14 + 0x28) + 1;
      UNLOCK();
      *(int *)(param_1 + iVar3 * 4) = iStack_14;
      FUN_0056cd30();
      uStack_8 = 0xffffffff;
      FUN_0056cd30();
    } while (0 < iVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13679 ; VA 0x00881df0 ; FUN_00881df0 */

void FUN_00881df0(undefined4 *param_1,int *param_2,int *param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  int *piStack_10;
  int *piStack_c;
  int *piStack_8;
  
  piVar4 = param_2 + ((int)param_3 - (int)param_2 >> 3);
  FUN_00881ac0(param_2,piVar4,param_3 + -1,param_4);
  piVar5 = piVar4;
  while (piStack_8 = piVar5, param_2 < piStack_8) {
    cVar3 = FUN_00a33d80(piStack_8);
    if ((cVar3 != '\0') ||
       (cVar3 = FUN_00a33d80(piStack_8 + -1), piVar5 = piStack_8 + -1, cVar3 != '\0')) break;
  }
  do {
    piVar4 = piVar4 + 1;
    piVar5 = piVar4;
    piStack_10 = piVar4;
    piStack_c = piVar4;
    piVar8 = piStack_8;
    if (param_3 <= piVar4) break;
    cVar3 = FUN_00a33d80(piStack_8);
    if ((cVar3 != '\0') || (cVar3 = FUN_00a33d80(piVar4), cVar3 != '\0')) break;
  } while( true );
joined_r0x00881e93:
  piVar6 = piStack_8;
  if (param_3 <= piVar5) {
joined_r0x00881f12:
    for (; piVar7 = piVar5, param_2 < piStack_8; piStack_8 = piStack_8 + -1) {
      piVar6 = piVar6 + -1;
      cVar3 = FUN_00a33d80(piVar8);
      piVar4 = piStack_c;
      if (cVar3 == '\0') {
        cVar3 = FUN_00a33d80(piVar6);
        piVar7 = piStack_10;
        if (cVar3 != '\0') break;
        piVar8 = piVar8 + -1;
        if (piVar8 != piVar6) {
          iVar1 = *piVar8;
          LOCK();
          *(int *)(iVar1 + 0x28) = *(int *)(iVar1 + 0x28) + 1;
          UNLOCK();
          iVar2 = *piVar6;
          LOCK();
          piVar5 = (int *)(iVar2 + 0x28);
          *piVar5 = *piVar5 + 1;
          UNLOCK();
          *piVar8 = iVar2;
          FUN_0056cd30();
          LOCK();
          *(int *)(iVar1 + 0x28) = *(int *)(iVar1 + 0x28) + 1;
          UNLOCK();
          *piVar6 = iVar1;
          FUN_0056cd30();
          FUN_0056cd30();
        }
      }
      piVar5 = piStack_10;
    }
    if (piStack_8 == param_2) {
      if (piVar7 == param_3) {
        *param_1 = piVar8;
        param_1[1] = piVar4;
        return;
      }
      if (piVar4 != piVar7) {
        iVar1 = *piVar8;
        LOCK();
        *(int *)(iVar1 + 0x28) = *(int *)(iVar1 + 0x28) + 1;
        UNLOCK();
        iVar2 = *piVar4;
        LOCK();
        piVar5 = (int *)(iVar2 + 0x28);
        *piVar5 = *piVar5 + 1;
        UNLOCK();
        *piVar8 = iVar2;
        FUN_0056cd30();
        LOCK();
        *(int *)(iVar1 + 0x28) = *(int *)(iVar1 + 0x28) + 1;
        UNLOCK();
        *piVar4 = iVar1;
        FUN_0056cd30();
        FUN_0056cd30();
      }
      iVar1 = *piVar8;
      piVar4 = piVar4 + 1;
      LOCK();
      *(int *)(iVar1 + 0x28) = *(int *)(iVar1 + 0x28) + 1;
      UNLOCK();
      iVar2 = *piVar7;
      LOCK();
      piVar5 = (int *)(iVar2 + 0x28);
      *piVar5 = *piVar5 + 1;
      UNLOCK();
      *piVar8 = iVar2;
      FUN_0056cd30();
      LOCK();
      *(int *)(iVar1 + 0x28) = *(int *)(iVar1 + 0x28) + 1;
      UNLOCK();
      *piVar7 = iVar1;
      FUN_0056cd30();
      FUN_0056cd30();
      piVar5 = piVar7 + 1;
      piStack_10 = piVar7 + 1;
      piStack_c = piVar4;
      piVar8 = piVar8 + 1;
    }
    else {
      piStack_8 = piStack_8 + -1;
      if (piVar7 == param_3) {
        piVar8 = piVar8 + -1;
        if (piStack_8 != piVar8) {
          iVar1 = *piStack_8;
          LOCK();
          *(int *)(iVar1 + 0x28) = *(int *)(iVar1 + 0x28) + 1;
          UNLOCK();
          iVar2 = *piVar8;
          LOCK();
          piVar5 = (int *)(iVar2 + 0x28);
          *piVar5 = *piVar5 + 1;
          UNLOCK();
          *piStack_8 = iVar2;
          FUN_0056cd30();
          LOCK();
          *(int *)(iVar1 + 0x28) = *(int *)(iVar1 + 0x28) + 1;
          UNLOCK();
          *piVar8 = iVar1;
          FUN_0056cd30();
          FUN_0056cd30();
        }
        iVar1 = *piVar8;
        piVar4 = piVar4 + -1;
        LOCK();
        *(int *)(iVar1 + 0x28) = *(int *)(iVar1 + 0x28) + 1;
        UNLOCK();
        iVar2 = *piVar4;
        LOCK();
        piVar5 = (int *)(iVar2 + 0x28);
        *piVar5 = *piVar5 + 1;
        UNLOCK();
        *piVar8 = iVar2;
        FUN_0056cd30();
        LOCK();
        *(int *)(iVar1 + 0x28) = *(int *)(iVar1 + 0x28) + 1;
        UNLOCK();
        *piVar4 = iVar1;
        FUN_0056cd30();
        FUN_0056cd30();
        piVar5 = piVar7;
        piStack_c = piVar4;
      }
      else {
        iVar1 = *piVar7;
        LOCK();
        *(int *)(iVar1 + 0x28) = *(int *)(iVar1 + 0x28) + 1;
        UNLOCK();
        iVar2 = *piStack_8;
        LOCK();
        piVar5 = (int *)(iVar2 + 0x28);
        *piVar5 = *piVar5 + 1;
        UNLOCK();
        *piVar7 = iVar2;
        FUN_0056cd30();
        LOCK();
        *(int *)(iVar1 + 0x28) = *(int *)(iVar1 + 0x28) + 1;
        UNLOCK();
        *piStack_8 = iVar1;
        FUN_0056cd30();
        FUN_0056cd30();
        piVar5 = piVar7 + 1;
        piStack_10 = piVar7 + 1;
      }
    }
    goto joined_r0x00881e93;
  }
  cVar3 = FUN_00a33d80(piVar5);
  if (cVar3 == '\0') {
    cVar3 = FUN_00a33d80(piVar8);
    piStack_c = piVar4;
    piStack_10 = piVar5;
    if (cVar3 != '\0') goto joined_r0x00881f12;
    if (piVar4 != piVar5) {
      iVar1 = *piVar4;
      LOCK();
      *(int *)(iVar1 + 0x28) = *(int *)(iVar1 + 0x28) + 1;
      UNLOCK();
      iVar2 = *piVar5;
      LOCK();
      piVar6 = (int *)(iVar2 + 0x28);
      *piVar6 = *piVar6 + 1;
      UNLOCK();
      *piVar4 = iVar2;
      FUN_0056cd30();
      LOCK();
      *(int *)(iVar1 + 0x28) = *(int *)(iVar1 + 0x28) + 1;
      UNLOCK();
      *piVar5 = iVar1;
      FUN_0056cd30();
      FUN_0056cd30();
    }
    piVar4 = piVar4 + 1;
  }
  piVar5 = piVar5 + 1;
  piStack_10 = piVar5;
  piStack_c = piVar4;
  goto joined_r0x00881e93;
}



/* FUNCTION 13680 ; VA 0x00882180 ; FUN_00882180 */

void FUN_00882180(int param_1,int param_2,uint param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  
  iVar4 = (int)(param_3 - 1) >> 1;
  iVar6 = param_2;
  iVar5 = param_2;
  if (param_2 < iVar4) {
    do {
      iVar5 = iVar6 * 2 + 2;
      cVar3 = FUN_00a33d80(param_1 + iVar5 * 4 + -4);
      if (cVar3 != '\0') {
        iVar5 = iVar6 * 2 + 1;
      }
      iVar2 = *(int *)(param_1 + iVar5 * 4);
      LOCK();
      piVar1 = (int *)(iVar2 + 0x28);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      *(int *)(param_1 + iVar6 * 4) = iVar2;
      FUN_0056cd30();
      iVar6 = iVar5;
    } while (iVar5 < iVar4);
  }
  if ((iVar5 == iVar4) && ((param_3 & 1) == 0)) {
    iVar6 = *(int *)(param_1 + -4 + param_3 * 4);
    LOCK();
    piVar1 = (int *)(iVar6 + 0x28);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    *(int *)(param_1 + iVar5 * 4) = iVar6;
    FUN_0056cd30();
    iVar5 = param_3 - 1;
  }
  while (param_2 < iVar5) {
    iVar6 = iVar5 + -1 >> 1;
    cVar3 = FUN_00a33d80(param_4);
    if (cVar3 == '\0') break;
    iVar4 = *(int *)(param_1 + iVar6 * 4);
    LOCK();
    piVar1 = (int *)(iVar4 + 0x28);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    *(int *)(param_1 + iVar5 * 4) = iVar4;
    FUN_0056cd30();
    iVar5 = iVar6;
  }
  iVar6 = *param_4;
  LOCK();
  piVar1 = (int *)(iVar6 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  *(int *)(param_1 + iVar5 * 4) = iVar6;
  FUN_0056cd30();
  return;
}



/* FUNCTION 13681 ; VA 0x00882290 ; FUN_00882290 */

void __thiscall FUN_00882290(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b9c50;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_XmlElement>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13682 ; VA 0x008822fe ; Catch_All@008822fe */

void Catch_All_008822fe(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00882a40(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 13683 ; VA 0x00882320 ; FUN_00882320 */

void FUN_00882320(int *param_1,int *param_2,int param_3,undefined4 param_4)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  int *piVar7;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9c70;
  iVar2 = (int)param_2 - (int)param_1;
  pvStack_10 = ExceptionList;
  piVar4 = param_2;
  piVar7 = param_1;
  iVar6 = param_3;
  ExceptionList = &pvStack_10;
  do {
    iVar2 = iVar2 >> 2;
    if (iVar2 < 0x21) {
LAB_008823bf:
      if (((1 < iVar2) && (piVar7 != piVar4)) &&
         (piVar3 = piVar7 + 1, piVar5 = piVar7, piVar3 != piVar4)) {
        do {
          param_1 = (int *)*piVar3;
          LOCK();
          *(int *)((int)param_1 + 0x28) = *(int *)((int)param_1 + 0x28) + 1;
          UNLOCK();
          uStack_8 = 1;
          piStack_1c = piVar5;
          piStack_18 = piVar3;
          cVar1 = FUN_00a33d80(piVar7);
          if (cVar1 == '\0') {
            cVar1 = FUN_00a33d80(piStack_1c);
            while (cVar1 != '\0') {
              iVar2 = *piVar5;
              LOCK();
              piVar4 = (int *)(iVar2 + 0x28);
              *piVar4 = *piVar4 + 1;
              UNLOCK();
              iStack_14 = *piVar3;
              *piVar3 = iVar2;
              FUN_0056cd30();
              cVar1 = FUN_00a33d80(piVar5 + -1);
              piVar3 = piVar5;
              piVar5 = piVar5 + -1;
            }
            LOCK();
            *(int *)((int)param_1 + 0x28) = *(int *)((int)param_1 + 0x28) + 1;
            UNLOCK();
            iStack_14 = *piVar3;
            *piVar3 = (int)param_1;
          }
          else {
            piVar4 = piVar5 + 2;
            if (piStack_18 != piVar7) {
              piVar5 = piVar5 + 1;
              do {
                iVar2 = piVar5[-1];
                piVar4 = piVar4 + -1;
                piVar5 = piVar5 + -1;
                LOCK();
                piVar3 = (int *)(iVar2 + 0x28);
                *piVar3 = *piVar3 + 1;
                UNLOCK();
                iStack_14 = *piVar4;
                *piVar4 = iVar2;
                FUN_0056cd30();
              } while (piVar5 != piVar7);
            }
            LOCK();
            *(int *)((int)param_1 + 0x28) = *(int *)((int)param_1 + 0x28) + 1;
            UNLOCK();
            iStack_14 = *piVar7;
            *piVar7 = (int)param_1;
          }
          FUN_0056cd30();
          uStack_8 = 0xffffffff;
          FUN_0056cd30();
          piVar3 = piStack_18 + 1;
          piVar5 = piStack_1c + 1;
        } while (piVar3 != param_2);
      }
      ExceptionList = pvStack_10;
      return;
    }
    if (iVar6 < 1) {
      if (0x20 < iVar2) {
        FUN_00881c90(piVar7,piVar4,param_4);
        iVar2 = (int)piVar4 - (int)piVar7 >> 2;
        if (iVar2 < 2) {
          ExceptionList = pvStack_10;
          return;
        }
        piVar4 = piVar4 + -1;
        if (iVar2 < 2) goto LAB_008824d5;
        do {
          param_1 = (int *)*piVar4;
          LOCK();
          *(int *)((int)param_1 + 0x28) = *(int *)((int)param_1 + 0x28) + 1;
          UNLOCK();
          iVar2 = *piVar7;
          uStack_8 = 0;
          LOCK();
          piVar3 = (int *)(iVar2 + 0x28);
          *piVar3 = *piVar3 + 1;
          UNLOCK();
          param_2 = (int *)*piVar4;
          *piVar4 = iVar2;
          FUN_0056cd30();
          FUN_00882180(piVar7,0,(int)piVar4 + -(int)piVar7 >> 2,&param_1,param_4);
          uStack_8 = 0xffffffff;
          FUN_0056cd30();
LAB_008824d5:
          piVar4 = piVar4 + -1;
        } while (1 < -(int)piVar7 + 4 + (int)piVar4 >> 2);
        ExceptionList = pvStack_10;
        return;
      }
      goto LAB_008823bf;
    }
    FUN_00881df0(&piStack_20,piVar7,piVar4,param_4);
    iVar6 = (iVar6 >> 1) + (iVar6 >> 2);
    if ((int)((int)piStack_20 - (int)piVar7 & 0xfffffffcU) <
        (int)((int)piVar4 - (int)piStack_1c & 0xfffffffcU)) {
      FUN_00882320(piVar7,piStack_20,iVar6,param_4);
      piVar7 = piStack_1c;
    }
    else {
      FUN_00882320(piStack_1c,piVar4,iVar6,param_4);
      param_2 = piStack_20;
      piVar4 = piStack_20;
    }
    iVar2 = (int)piVar4 - (int)piVar7;
  } while( true );
}



/* FUNCTION 13684 ; VA 0x00882590 ; FUN_00882590 */

void FUN_00882590(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  LOCK();
  *(int *)(iVar2 + 0x28) = *(int *)(iVar2 + 0x28) + 1;
  UNLOCK();
  iVar3 = *param_2;
  LOCK();
  piVar1 = (int *)(iVar3 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  *param_1 = iVar3;
  FUN_0056cd30();
  LOCK();
  *(int *)(iVar2 + 0x28) = *(int *)(iVar2 + 0x28) + 1;
  UNLOCK();
  *param_2 = iVar2;
  FUN_0056cd30();
  FUN_0056cd30();
  return;
}



/* FUNCTION 13685 ; VA 0x008825f0 ; FUN_008825f0 */

byte * FUN_008825f0(byte *param_1,byte *param_2,undefined4 param_3,int *param_4)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  int iVar4;
  undefined *puVar5;
  byte *pbVar6;
  int iVar7;
  undefined uVar8;
  
  iVar7 = 0;
  pbVar6 = param_1;
  if (param_1 != param_2) {
    while( true ) {
      bVar1 = *param_1;
      pbVar6 = param_1 + 1;
      if (pbVar6 == param_2) break;
      bVar2 = *pbVar6;
      pbVar6 = param_1 + 2;
      if (pbVar6 == param_2) {
        FUN_0056ec80((&DAT_01d62828)[(uint)(bVar1 >> 2) * 4]);
        FUN_0056ec80((&DAT_01d62828)[((uint)(bVar2 >> 4) + (bVar1 & 3) * 0x10) * 4]);
        uVar8 = (&DAT_01d62828)[(bVar2 & 0xf) * 0x10];
        goto LAB_0088288e;
      }
      bVar3 = *pbVar6;
      param_1 = param_1 + 3;
      if (param_4 != (int *)0x0) {
        uVar8 = (&DAT_01d62828)[(uint)(bVar1 >> 2) * 4];
        if (*(int *)param_4[8] != 0) {
          iVar4 = *(int *)param_4[0xc];
          if (0 < iVar4) {
            *(int *)param_4[0xc] = iVar4 + -1;
            puVar5 = *(undefined **)param_4[8];
            *(undefined **)param_4[8] = puVar5 + 1;
            *puVar5 = uVar8;
            goto LAB_00882688;
          }
        }
        (**(code **)(*param_4 + 0xc))(uVar8);
      }
LAB_00882688:
      if (param_4 != (int *)0x0) {
        uVar8 = (&DAT_01d62828)[((bVar1 & 3) * 0x10 + (uint)(bVar2 >> 4)) * 4];
        if (*(int *)param_4[8] != 0) {
          iVar4 = *(int *)param_4[0xc];
          if (0 < iVar4) {
            *(int *)param_4[0xc] = iVar4 + -1;
            puVar5 = *(undefined **)param_4[8];
            *(undefined **)param_4[8] = puVar5 + 1;
            *puVar5 = uVar8;
            goto LAB_008826eb;
          }
        }
        (**(code **)(*param_4 + 0xc))(uVar8);
      }
LAB_008826eb:
      if (param_4 != (int *)0x0) {
        uVar8 = (&DAT_01d62828)[((uint)(bVar3 >> 6) + (bVar2 & 0xf) * 4) * 4];
        if (*(int *)param_4[8] != 0) {
          iVar4 = *(int *)param_4[0xc];
          if (0 < iVar4) {
            *(int *)param_4[0xc] = iVar4 + -1;
            puVar5 = *(undefined **)param_4[8];
            *(undefined **)param_4[8] = puVar5 + 1;
            *puVar5 = uVar8;
            goto LAB_0088274c;
          }
        }
        (**(code **)(*param_4 + 0xc))(uVar8);
      }
LAB_0088274c:
      if (param_4 != (int *)0x0) {
        uVar8 = (&DAT_01d62828)[(bVar3 & 0x3f) * 4];
        if (*(int *)param_4[8] != 0) {
          iVar4 = *(int *)param_4[0xc];
          if (0 < iVar4) {
            *(int *)param_4[0xc] = iVar4 + -1;
            puVar5 = *(undefined **)param_4[8];
            *(undefined **)param_4[8] = puVar5 + 1;
            *puVar5 = uVar8;
            goto LAB_008827a2;
          }
        }
        (**(code **)(*param_4 + 0xc))(uVar8);
      }
LAB_008827a2:
      if (iVar7 == 0x11) {
        if (param_4 != (int *)0x0) {
          if (*(int *)param_4[8] != 0) {
            iVar7 = *(int *)param_4[0xc];
            if (0 < iVar7) {
              *(int *)param_4[0xc] = iVar7 + -1;
              puVar5 = *(undefined **)param_4[8];
              *(undefined **)param_4[8] = puVar5 + 1;
              *puVar5 = 10;
              iVar7 = 0;
              goto LAB_008827fc;
            }
          }
          (**(code **)(*param_4 + 0xc))(10);
        }
        iVar7 = 0;
      }
      else {
        iVar7 = iVar7 + 1;
      }
LAB_008827fc:
      if (param_1 == param_2) {
        return param_1;
      }
    }
    FUN_0056ec80((&DAT_01d62828)[(uint)(bVar1 >> 2) * 4]);
    FUN_0056ec80((&DAT_01d62828)[(bVar1 & 3) * 0x40]);
    uVar8 = 0x3d;
LAB_0088288e:
    FUN_0056ec80(uVar8);
    FUN_0056ec80(0x3d);
  }
  return pbVar6;
}



/* FUNCTION 13686 ; VA 0x008828b0 ; FUN_008828b0 */

undefined4 * __thiscall FUN_008828b0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  puVar1 = param_1 + 2;
  *param_1 = XmlParser::vftable;
  param_1[1] = param_2;
  *puVar1 = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  puVar2 = (undefined4 *)FUN_01674e20(8);
  *puVar1 = puVar2;
  *puVar2 = 0;
  puVar2[1] = 0;
  *(undefined4 **)*puVar1 = puVar1;
  return param_1;
}



/* FUNCTION 13687 ; VA 0x00882920 ; FUN_00882920 */

undefined4 * __thiscall FUN_00882920(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined **ppuVar3;
  undefined **ppuVar4;
  undefined4 *puStack_8;
  
  puVar1 = param_1 + 1;
  *param_1 = XmlWriter::vftable;
  *puVar1 = 0;
  param_1[2] = 0;
  puStack_8 = puVar1;
  uVar2 = FUN_00575ad0();
  *puVar1 = uVar2;
  *(undefined *)(param_1 + 3) = 0;
  puStack_8 = (undefined4 *)0xb;
  ppuVar3 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&puStack_8);
  ppuVar4 = ppuVar3 + -1;
  if (ppuVar3 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar4 = ppuVar3;
  }
  param_1[4] = *ppuVar4;
  param_1[5] = 0;
  param_1[6] = 0x3f800000;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = param_2;
  return param_1;
}



/* FUNCTION 13688 ; VA 0x008829b0 ; FUN_008829b0 */

void __fastcall FUN_008829b0(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  void **ppvVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  ppvVar3 = &pvStack_10;
  puVar2 = *(undefined4 **)(param_1 + 0x20);
  pvStack_10 = ExceptionList;
  while (ExceptionList = ppvVar3, puVar2 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*puVar2;
    uStack_8 = 0;
    FUN_0087ccc0();
    FUN_01674ea0(puVar2,0x18);
    ppvVar3 = (void **)ExceptionList;
    puVar2 = puVar1;
  }
  puVar2 = *(undefined4 **)(param_1 + 4);
  while (puVar2 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*puVar2;
    FUN_008829b0();
    FUN_01674ea0(puVar2,0x28);
    puVar2 = puVar1;
  }
  uStack_8 = 1;
  FUN_0087ccc0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13689 ; VA 0x00882a40 ; FUN_00882a40 */

undefined4 __thiscall FUN_00882a40(undefined4 param_1,byte param_2)

{
  FUN_008829b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 13690 ; VA 0x00882a70 ; FUN_00882a70 */

void __fastcall FUN_00882a70(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_008829b0();
    FUN_01674ea0(iVar1,0x28);
  }
  return;
}



/* FUNCTION 13691 ; VA 0x00882a90 ; FUN_00882a90 */

undefined4 __thiscall FUN_00882a90(undefined4 param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  
  cVar1 = *(char *)((int)param_2 + 0xd);
  while (cVar1 == '\0') {
    FUN_00882a90(param_2[2]);
    piVar2 = (int *)param_2[5];
    piVar3 = (int *)*param_2;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(param_2,0x1c);
    param_2 = piVar3;
    cVar1 = *(char *)((int)piVar3 + 0xd);
  }
  return param_1;
}



/* FUNCTION 13692 ; VA 0x00882b10 ; FUN_00882b10 */

undefined4 * __thiscall FUN_00882b10(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[4] = param_2;
    puVar1[5] = 0;
    puVar1[8] = 0;
    puVar1[9] = 0;
  }
  if (*(undefined4 **)(param_1 + 8) == (undefined4 *)0x0) {
    *(undefined4 **)(param_1 + 4) = puVar1;
    *(undefined4 **)(param_1 + 8) = puVar1;
    return puVar1;
  }
  **(undefined4 **)(param_1 + 8) = puVar1;
  *(undefined4 **)(param_1 + 8) = puVar1;
  return puVar1;
}



/* FUNCTION 13693 ; VA 0x00882b90 ; FUN_00882b90 */

void __thiscall FUN_00882b90(int param_1,undefined4 param_2)

{
  if (*(undefined4 **)(param_1 + 8) == (undefined4 *)0x0) {
    *(undefined4 *)(param_1 + 4) = param_2;
    *(undefined4 *)(param_1 + 8) = param_2;
    return;
  }
  **(undefined4 **)(param_1 + 8) = param_2;
  *(undefined4 *)(param_1 + 8) = param_2;
  return;
}



/* FUNCTION 13694 ; VA 0x00882bb0 ; FUN_00882bb0 */

uint * FUN_00882bb0(uint *param_1,undefined4 *param_2)

{
  undefined8 uVar1;
  char ****ppppcVar2;
  char cVar3;
  char *****pppppcVar4;
  char ****ppppcVar5;
  uint *puVar6;
  char *****pppppcVar7;
  undefined4 *puVar8;
  undefined4 uVar9;
  int *piVar10;
  int iVar11;
  uint uVar12;
  undefined4 *****pppppuVar13;
  uint uVar14;
  uint uVar15;
  uint uVar16;
  char *pcVar17;
  undefined4 ****ppppuStack_84;
  int iStack_80;
  int iStack_7c;
  int iStack_78;
  undefined8 uStack_74;
  char ****appppcStack_6c [4];
  uint uStack_5c;
  uint uStack_58;
  undefined auStack_54 [12];
  undefined auStack_48 [4];
  undefined4 uStack_44;
  undefined4 uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  char ****ppppcStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017b9cca;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  uStack_28 = 0;
  uStack_8 = 0;
  uStack_30 = 1;
  uStack_24 = 1;
  uVar16 = param_2[4];
  if (uVar16 != 0) {
    uStack_38 = 0xffffffff;
    do {
      puVar8 = param_2;
      if (0xf < (uint)param_2[5]) {
        puVar8 = (undefined4 *)*param_2;
      }
      cStack_11 = *(char *)((int)puVar8 + uStack_28);
      uStack_28 = uStack_28 + 1;
      uStack_3c = uStack_30;
      if (cStack_11 == '&') {
        uStack_18 = 0;
        uStack_5c = 0;
        uStack_58 = 0xf;
        appppcStack_6c[0] = (char ****)((uint)appppcStack_6c[0] & 0xffffff00);
        uStack_8 = 1;
        uVar12 = 0xf;
        uVar15 = 0xf;
        if (uStack_28 < uVar16) {
          do {
            ppppcVar2 = appppcStack_6c[0];
            puVar8 = param_2;
            if (0xf < (uint)param_2[5]) {
              puVar8 = (undefined4 *)*param_2;
            }
            cStack_11 = *(char *)((int)puVar8 + uStack_28);
            uStack_28 = uStack_28 + 1;
            uVar15 = uVar12;
            if (cStack_11 == ';') break;
            if (uStack_18 < uVar12) {
              uStack_5c = uStack_18 + 1;
              pppppcVar4 = appppcStack_6c;
              if (0xf < uVar12) {
                pppppcVar4 = (char *****)appppcStack_6c[0];
              }
              *(char *)((int)pppppcVar4 + uStack_18) = cStack_11;
              *(char *)((int)pppppcVar4 + uStack_18 + 1) = '\0';
              uStack_18 = uStack_5c;
              uVar15 = uStack_58;
            }
            else {
              uStack_20 = uStack_18;
              if (uStack_18 == 0x7fffffff) goto LAB_00883402;
              uStack_18 = uStack_18 + 1;
              uVar15 = uStack_18 | 0xf;
              if (uVar15 < 0x80000000) {
                uStack_2c = uVar12 >> 1;
                if (0x7fffffff - uStack_2c < uVar12) {
                  uVar15 = 0x7fffffff;
                }
                else if (uVar15 < uStack_2c + uVar12) {
                  uVar15 = uStack_2c + uVar12;
                }
              }
              else {
                uVar15 = 0x7fffffff;
              }
              uVar16 = uVar15 + 1;
              uStack_34 = uVar12;
              if (uVar16 < 0x1000) {
                if (uVar16 == 0) {
                  ppppcStack_1c = (char ****)0x0;
                }
                else {
                  ppppcStack_1c = (char ****)FUN_01674e20(uVar16);
                }
              }
              else {
                uVar12 = uVar15 + 0x24;
                if (uVar15 + 0x24 <= uVar16) {
                  uVar12 = uStack_38;
                }
                ppppcVar5 = (char ****)FUN_01674e20(uVar12);
                if (ppppcVar5 == (char ****)0x0) goto LAB_008833fd;
                ppppcStack_1c = (char ****)((int)ppppcVar5 + 0x23U & 0xffffffe0);
                ((char *****)ppppcStack_1c)[-1] = ppppcVar5;
              }
              uStack_5c = uStack_18;
              uStack_58 = uVar15;
              if (uStack_34 < 0x10) {
                FUN_0170c6f0(ppppcStack_1c,appppcStack_6c,uStack_20);
                *(char *)((int)ppppcStack_1c + uStack_20) = cStack_11;
                *(char *)((int)ppppcStack_1c + uStack_20 + 1) = '\0';
              }
              else {
                FUN_0170c6f0(ppppcStack_1c,ppppcVar2,uStack_20);
                uVar16 = uStack_34 + 1;
                *(char *)((int)ppppcStack_1c + uStack_20) = cStack_11;
                ((char *)((int)ppppcStack_1c + uStack_20))[1] = '\0';
                pppppcVar4 = (char *****)ppppcVar2;
                if (0xfff < uVar16) {
                  pppppcVar4 = (char *****)ppppcVar2[-1];
                  uVar16 = uStack_34 + 0x24;
                  if ((char *)0x1f < (char *)((int)ppppcVar2 + (-4 - (int)pppppcVar4)))
                  goto LAB_008833fd;
                }
                FUN_01674ea0(pppppcVar4,uVar16);
              }
              appppcStack_6c[0] = ppppcStack_1c;
            }
            uVar12 = uVar15;
          } while (uStack_28 < (uint)param_2[4]);
        }
        pppppcVar4 = (char *****)appppcStack_6c[0];
        pppppcVar7 = appppcStack_6c;
        if (0xf < uVar15) {
          pppppcVar7 = (char *****)appppcStack_6c[0];
        }
        cVar3 = FUN_0055c360(pppppcVar7,uStack_18,&DAT_018c2f3c,2);
        if (cVar3 == '\0') {
          pppppcVar7 = appppcStack_6c;
          if (0xf < uVar15) {
            pppppcVar7 = pppppcVar4;
          }
          cVar3 = FUN_0055c360(pppppcVar7,uStack_18,&DAT_018c2f40,2);
          if (cVar3 == '\0') {
            pppppcVar7 = appppcStack_6c;
            if (0xf < uVar15) {
              pppppcVar7 = pppppcVar4;
            }
            cVar3 = FUN_0055c360(pppppcVar7,uStack_18,&DAT_018c2f44,3);
            if (cVar3 == '\0') {
              pppppcVar7 = appppcStack_6c;
              if (0xf < uVar15) {
                pppppcVar7 = pppppcVar4;
              }
              cVar3 = FUN_0055c360(pppppcVar7,uStack_18,&DAT_018c2f48,4);
              if (cVar3 == '\0') {
                pppppcVar7 = appppcStack_6c;
                if (0xf < uVar15) {
                  pppppcVar7 = pppppcVar4;
                }
                cVar3 = FUN_0055c360(pppppcVar7,uStack_18,&DAT_018c2f50,4);
                if (cVar3 == '\0') {
                  pppppcVar7 = appppcStack_6c;
                  if (0xf < uVar15) {
                    pppppcVar7 = pppppcVar4;
                  }
                  cVar3 = FUN_0055c360(pppppcVar7,uStack_18,&DAT_018c2928,4);
                  if (cVar3 == '\0') {
                    pppppcVar7 = appppcStack_6c;
                    if (0xf < uVar15) {
                      pppppcVar7 = pppppcVar4;
                    }
                    if (*(char *)pppppcVar7 == '#') {
                      if (uStack_18 < 2) {
                        pcVar17 = "bad XML. No character code following #";
                        goto LAB_0088340c;
                      }
                      pppppcVar7 = appppcStack_6c;
                      if (0xf < uVar15) {
                        pppppcVar7 = pppppcVar4;
                      }
                      if (*(char *)((int)pppppcVar7 + 1) == 'x') goto LAB_00883407;
                      puVar8 = (undefined4 *)FUN_0058c540(auStack_54,1,0xffffffff);
                      uStack_8 = CONCAT31(uStack_8._1_3_,2);
                      if (0xf < (uint)puVar8[5]) {
                        puVar8 = (undefined4 *)*puVar8;
                      }
                      uVar9 = FUN_01717832(puVar8);
                      FUN_00592760(uVar9);
                    }
                    else {
                      uStack_24 = uStack_30 | 2;
                      uStack_8._0_1_ = 3;
                      uStack_44 = 0;
                      uStack_40 = 0xf;
                      auStack_54[0] = 0;
                      FUN_0058a190(uStack_18 + 1);
                      FUN_00554150(&DAT_0191bfa0,1);
                      pppppcVar7 = appppcStack_6c;
                      if (0xf < uVar15) {
                        pppppcVar7 = pppppcVar4;
                      }
                      FUN_00554150(pppppcVar7,uStack_18);
                      piVar10 = (int *)FUN_00554150(&DAT_018d1b9c,1);
                      uVar16 = uStack_3c | 6;
                      ppppuStack_84 = (undefined4 ****)*piVar10;
                      iStack_80 = piVar10[1];
                      iStack_7c = piVar10[2];
                      iStack_78 = piVar10[3];
                      uVar1 = *(undefined8 *)(piVar10 + 4);
                      piVar10[4] = 0;
                      piVar10[5] = 0xf;
                      *(undefined *)piVar10 = 0;
                      uStack_74._4_4_ = (uint)((ulonglong)uVar1 >> 0x20);
                      uStack_74._0_4_ = (undefined4)uVar1;
                      uStack_8 = CONCAT31(uStack_8._1_3_,4);
                      pppppuVar13 = &ppppuStack_84;
                      if (0xf < uStack_74._4_4_) {
                        pppppuVar13 = (undefined4 *****)ppppuStack_84;
                      }
                      uVar9 = (undefined4)uStack_74;
                      uStack_74 = uVar1;
                      uStack_24 = uVar16;
                      FUN_00554150(pppppuVar13,uVar9);
                      FUN_005507b0();
                      uStack_30 = uVar16 & 0xfffffffd;
                      uStack_24 = uStack_30;
                    }
                    FUN_005507b0();
                    pppppcVar4 = (char *****)appppcStack_6c[0];
                    uVar15 = uStack_58;
                  }
                  else {
                    FUN_00592760(0x20);
                  }
                }
                else {
                  FUN_00592760(0x27);
                }
              }
              else {
                FUN_00592760(0x22);
              }
            }
            else {
              FUN_00592760(0x26);
            }
          }
          else {
            uStack_20 = param_1[4];
            uStack_18 = param_1[5];
            if (uStack_20 < uStack_18) {
              param_1[4] = uStack_20 + 1;
              puVar6 = param_1;
              if (0xf < uStack_18) {
                puVar6 = (uint *)*param_1;
              }
              *(undefined2 *)((int)puVar6 + uStack_20) = 0x3e;
            }
            else {
              if (uStack_20 == 0x7fffffff) goto LAB_00883402;
              uStack_3c = uStack_20 + 1;
              uStack_2c = uStack_3c | 0xf;
              if (uStack_2c < 0x80000000) {
                uStack_34 = uStack_18 >> 1;
                if (0x7fffffff - uStack_34 < uStack_18) {
                  uStack_2c = 0x7fffffff;
                }
                else if (uStack_2c < uStack_18 + uStack_34) {
                  uStack_2c = uStack_18 + uStack_34;
                }
              }
              else {
                uStack_2c = 0x7fffffff;
              }
              ppppcStack_1c = (char ****)FUN_00554060(uStack_2c + 1);
              param_1[4] = uStack_3c;
              param_1[5] = uStack_2c;
              if (uStack_18 < 0x10) {
                FUN_0170c6f0(ppppcStack_1c,param_1,uStack_20);
                ((char *)((int)ppppcStack_1c + uStack_20))[0] = '>';
                ((char *)((int)ppppcStack_1c + uStack_20))[1] = '\0';
                *param_1 = (uint)ppppcStack_1c;
              }
              else {
                uStack_34 = *param_1;
                FUN_0170c6f0(ppppcStack_1c,uStack_34,uStack_20);
                ((char *)((int)ppppcStack_1c + uStack_20))[0] = '>';
                ((char *)((int)ppppcStack_1c + uStack_20))[1] = '\0';
                uVar12 = uStack_18 + 1;
                uVar16 = uStack_34;
                if (0xfff < uVar12) {
                  uVar16 = *(uint *)(uStack_34 - 4);
                  uVar12 = uStack_18 + 0x24;
                  if (0x1f < (uStack_34 - uVar16) - 4) goto LAB_008833fd;
                }
                FUN_01674ea0(uVar16,uVar12);
                *param_1 = (uint)ppppcStack_1c;
              }
            }
          }
        }
        else {
          uStack_20 = param_1[4];
          uStack_18 = param_1[5];
          if (uStack_20 < uStack_18) {
            param_1[4] = uStack_20 + 1;
            puVar6 = param_1;
            if (0xf < uStack_18) {
              puVar6 = (uint *)*param_1;
            }
            *(undefined2 *)((int)puVar6 + uStack_20) = 0x3c;
          }
          else {
            if (uStack_20 == 0x7fffffff) goto LAB_00883402;
            uStack_3c = uStack_20 + 1;
            uStack_2c = uStack_3c | 0xf;
            if (uStack_2c < 0x80000000) {
              uStack_34 = uStack_18 >> 1;
              if (0x7fffffff - uStack_34 < uStack_18) {
                uStack_2c = 0x7fffffff;
              }
              else if (uStack_2c < uStack_18 + uStack_34) {
                uStack_2c = uStack_18 + uStack_34;
              }
            }
            else {
              uStack_2c = 0x7fffffff;
            }
            ppppcStack_1c = (char ****)FUN_00554060(uStack_2c + 1);
            param_1[4] = uStack_3c;
            param_1[5] = uStack_2c;
            if (uStack_18 < 0x10) {
              FUN_0170c6f0(ppppcStack_1c,param_1,uStack_20);
              ((char *)((int)ppppcStack_1c + uStack_20))[0] = '<';
              ((char *)((int)ppppcStack_1c + uStack_20))[1] = '\0';
              *param_1 = (uint)ppppcStack_1c;
            }
            else {
              uStack_34 = *param_1;
              FUN_0170c6f0(ppppcStack_1c,uStack_34,uStack_20);
              ((char *)((int)ppppcStack_1c + uStack_20))[0] = '<';
              ((char *)((int)ppppcStack_1c + uStack_20))[1] = '\0';
              uVar12 = uStack_18 + 1;
              uVar16 = uStack_34;
              if (0xfff < uVar12) {
                uVar16 = *(uint *)(uStack_34 - 4);
                uVar12 = uStack_18 + 0x24;
                if (0x1f < (uStack_34 - uVar16) - 4) goto LAB_008833fd;
              }
              FUN_01674ea0(uVar16,uVar12);
              *param_1 = (uint)ppppcStack_1c;
            }
          }
        }
        uStack_8 = uStack_8 & 0xffffff00;
        if (0xf < uVar15) {
          uVar16 = uVar15 + 1;
          pppppcVar7 = pppppcVar4;
          if (0xfff < uVar16) {
            pppppcVar7 = (char *****)pppppcVar4[-1];
            uVar16 = uVar15 + 0x24;
            if ((char *)0x1f < (char *)((int)pppppcVar4 + (-4 - (int)pppppcVar7))) {
LAB_008833fd:
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(pppppcVar7,uVar16);
        }
      }
      else {
        uStack_20 = param_1[4];
        uStack_2c = param_1[5];
        if (uStack_20 < uStack_2c) {
          param_1[4] = uStack_20 + 1;
          puVar6 = param_1;
          if (0xf < uStack_2c) {
            puVar6 = (uint *)*param_1;
          }
          ((char *)((int)puVar6 + uStack_20))[1] = '\0';
          *(char *)((int)puVar6 + uStack_20) = cStack_11;
        }
        else {
          if (uStack_20 == 0x7fffffff) {
LAB_00883402:
            FUN_00554040();
LAB_00883407:
            pcVar17 = "Unable to parse hexidecimal character code";
LAB_0088340c:
            FUN_00550130(pcVar17);
                    /* WARNING: Subroutine does not return */
            FUN_0170c2a8(auStack_48,&DAT_01c17198);
          }
          uVar16 = uStack_20 + 1 | 0xf;
          if (uVar16 < 0x80000000) {
            uStack_34 = uStack_2c >> 1;
            if (0x7fffffff - uStack_34 < uStack_2c) {
              uVar16 = 0x7fffffff;
            }
            else if (uVar16 < uStack_34 + uStack_2c) {
              uVar16 = uStack_34 + uStack_2c;
            }
          }
          else {
            uVar16 = 0x7fffffff;
          }
          uVar15 = uVar16 + 1;
          if (uVar15 < 0x1000) {
            if (uVar15 == 0) {
              uVar15 = 0;
            }
            else {
              uVar15 = FUN_01674e20(uVar15);
            }
          }
          else {
            uVar12 = uVar16 + 0x24;
            if (uVar16 + 0x24 <= uVar15) {
              uVar12 = uStack_38;
            }
            iVar11 = FUN_01674e20(uVar12);
            if (iVar11 == 0) goto LAB_008833fd;
            uVar15 = iVar11 + 0x23U & 0xffffffe0;
            *(int *)(uVar15 - 4) = iVar11;
          }
          param_1[4] = uStack_20 + 1;
          param_1[5] = uVar16;
          if (uStack_2c < 0x10) {
            FUN_0170c6f0(uVar15,param_1,uStack_20);
            *(char *)(uStack_20 + uVar15) = cStack_11;
            *(undefined *)(uStack_20 + 1 + uVar15) = 0;
          }
          else {
            uVar16 = *param_1;
            FUN_0170c6f0(uVar15,uVar16,uStack_20);
            *(char *)(uStack_20 + uVar15) = cStack_11;
            uVar14 = uStack_2c + 1;
            *(undefined *)(uStack_20 + 1 + uVar15) = 0;
            uVar12 = uVar16;
            if (0xfff < uVar14) {
              uVar12 = *(uint *)(uVar16 - 4);
              uVar14 = uStack_2c + 0x24;
              if (0x1f < (uVar16 - uVar12) - 4) goto LAB_008833fd;
            }
            FUN_01674ea0(uVar12,uVar14);
          }
          *param_1 = uVar15;
        }
      }
      uVar16 = param_2[4];
    } while (uStack_28 < uVar16);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13695 ; VA 0x00883430 ; FUN_00883430 */

/* WARNING: Type propagation algorithm not settling */

void FUN_00883430(undefined4 param_1,undefined4 *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  uint *******pppppppuVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  uint *****pppppuVar8;
  undefined4 *puVar9;
  uint uVar10;
  uint ******ppppppuVar11;
  uint ******ppppppuVar12;
  int iStack_144;
  undefined4 auStack_10c [26];
  uint uStack_a4;
  int iStack_9c;
  int iStack_98;
  int aiStack_94 [5];
  uint uStack_80;
  int iStack_7c;
  uint *******pppppppuStack_78;
  uint ******ppppppuStack_74;
  uint ******ppppppuStack_70;
  uint ******ppppppuStack_6c;
  uint ******ppppppuStack_68;
  uint ******ppppppuStack_64;
  uint *******apppppppuStack_60 [4];
  uint ******ppppppuStack_50;
  uint uStack_4c;
  uint ******ppppppuStack_48;
  int iStack_44;
  int iStack_40;
  undefined4 uStack_3c;
  uint ******ppppppuStack_38;
  uint ******ppppppuStack_34;
  uint ******ppppppuStack_30;
  uint ******ppppppuStack_2c;
  uint ******ppppppuStack_28;
  undefined4 *puStack_24;
  uint *******pppppppuStack_20;
  uint *******pppppppuStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  uVar1 = (uint)param_2;
  puStack_c = &LAB_017b9d51;
  pvStack_10 = ExceptionList;
  uVar10 = *(uint *)((int)param_2 + 8);
  if (uVar10 == 0) {
    return;
  }
  iStack_44 = 0;
  iStack_40 = 0;
  uStack_3c = 0;
  uStack_8 = 0;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if (uVar10 != 0) {
    if (0x3fffffff < uVar10) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    ExceptionList = &pvStack_10;
    FUN_006c8e30(uVar10);
    if (*(int *)(uVar1 + 8) != 0) {
      uVar6 = *(undefined4 *)(*(int *)(uVar1 + 0x14) + *(int *)(uVar1 + 4) * 4);
      goto LAB_0088349f;
    }
  }
  uVar6 = 0;
LAB_0088349f:
  param_2 = (undefined4 *)((uint)param_2 & 0xffffff00);
  FUN_006c6bf0(iStack_40,uVar6,0,param_2);
  iVar2 = iStack_40;
  iVar3 = iStack_44;
  iStack_18 = iStack_44;
  FUN_00882320(iStack_44,iStack_40,iStack_40 - iStack_44 >> 2,param_2);
  iStack_7c = FUN_00882b10(DAT_01ede67c);
  if (iVar3 != iVar2) {
    do {
      ppppppuStack_68 = (uint ******)0x0;
      ppppppuStack_64 = (uint ******)0xf;
      pppppppuStack_78 = (uint *******)((uint)pppppppuStack_78 & 0xffffff00);
      uStack_8 = 1;
      iVar3 = FUN_00a33fa0();
      iVar3 = *(int *)(iVar3 + 0x10);
      puVar4 = (undefined4 *)FUN_00a33fa0();
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      FUN_00565940(3,1);
      uStack_a4 = uStack_a4 & 0xffffff00;
      uStack_8 = 2;
      FUN_008825f0(puVar4,(int)puVar4 + iVar3,uStack_a4,
                   *(undefined4 *)((int)auStack_10c + *(int *)(iStack_144 + 4)),&param_2,param_2);
      pppppppuVar5 = (uint *******)FUN_0058c4d0(aiStack_94);
      if (&pppppppuStack_78 != (uint ********)pppppppuVar5) {
        pppppppuStack_78 = (uint *******)*pppppppuVar5;
        ppppppuStack_74 = pppppppuVar5[1];
        ppppppuStack_70 = pppppppuVar5[2];
        ppppppuStack_6c = pppppppuVar5[3];
        ppppppuStack_68 = pppppppuVar5[4];
        ppppppuStack_64 = pppppppuVar5[5];
        pppppppuVar5[4] = (uint ******)0x0;
        pppppppuVar5[5] = (uint ******)0xf;
        *(undefined *)pppppppuVar5 = 0;
      }
      if (0xf < uStack_80) {
        uVar10 = uStack_80 + 1;
        iVar3 = aiStack_94[0];
        if (0xfff < uVar10) {
          iVar3 = *(int *)(aiStack_94[0] + -4);
          uVar10 = uStack_80 + 0x24;
          if (0x1f < (aiStack_94[0] - iVar3) - 4U) goto LAB_008839ff;
        }
        FUN_01674ea0(iVar3,uVar10);
      }
      FUN_005705c0();
      ppppppuStack_50 = (uint ******)0x0;
      uStack_4c = 0xf;
      apppppppuStack_60[0] = (uint *******)((uint)apppppppuStack_60[0] & 0xffffff00);
      uStack_8 = 3;
      FUN_00a33e40(apppppppuStack_60);
      uVar6 = DAT_01ede680;
      puVar4 = (undefined4 *)FUN_01674e20(0x28);
      if (puVar4 == (undefined4 *)0x0) {
        puVar4 = (undefined4 *)0x0;
      }
      else {
        *puVar4 = 0;
        puVar4[1] = 0;
        puVar4[2] = 0;
        puVar4[4] = uVar6;
        puVar4[5] = 0;
        puVar4[8] = 0;
        puVar4[9] = 0;
      }
      if (*(undefined4 **)(iStack_7c + 8) == (undefined4 *)0x0) {
        *(undefined4 **)(iStack_7c + 4) = puVar4;
      }
      else {
        **(undefined4 **)(iStack_7c + 8) = puVar4;
      }
      *(undefined4 **)(iStack_7c + 8) = puVar4;
      pppppppuStack_1c = (uint *******)apppppppuStack_60;
      if (0xf < uStack_4c) {
        pppppppuStack_1c = apppppppuStack_60[0];
      }
      pppppppuStack_20 = DAT_01ede684;
      ppppppuStack_28 = (uint ******)0x0;
      puStack_24 = (undefined4 *)0x0;
      ppppppuStack_48 = ppppppuStack_50;
      if (ppppppuStack_50 < (uint ******)0x10) {
        ppppppuVar11 = *pppppppuStack_1c;
        ppppppuStack_34 = pppppppuStack_1c[1];
        ppppppuStack_30 = pppppppuStack_1c[2];
        ppppppuStack_2c = pppppppuStack_1c[3];
        ppppppuStack_28 = ppppppuStack_50;
        param_2 = (undefined4 *)&DAT_0000000f;
        ppppppuStack_38 = ppppppuVar11;
      }
      else {
        param_2 = (undefined4 *)((uint)ppppppuStack_50 | 0xf);
        if ((undefined4 *)0x7fffffff < param_2) {
          param_2 = (undefined4 *)0x7fffffff;
        }
        puVar9 = (undefined4 *)((int)param_2 + 1);
        if (puVar9 < &DAT_00001000) {
          if (puVar9 == (undefined4 *)0x0) {
            ppppppuVar11 = (uint ******)0x0;
          }
          else {
            ppppppuVar11 = (uint ******)FUN_01674e20(puVar9);
          }
        }
        else {
          puVar7 = param_2 + 9;
          if (puVar7 <= puVar9) {
            puVar7 = (undefined4 *)0xffffffff;
          }
          pppppuVar8 = (uint *****)FUN_01674e20(puVar7);
          if (pppppuVar8 == (uint *****)0x0) goto LAB_008839ff;
          ppppppuVar11 = (uint ******)((int)pppppuVar8 + 0x23U & 0xffffffe0);
          ppppppuVar11[-1] = pppppuVar8;
        }
        ppppppuStack_38 = ppppppuVar11;
        FUN_0170c6f0(ppppppuVar11,pppppppuStack_1c,(int)ppppppuStack_48 + 1);
        ppppppuStack_28 = ppppppuStack_48;
      }
      uStack_8 = 4;
      ppppppuStack_48 = ppppppuStack_28;
      puStack_24 = param_2;
      puStack_14 = (undefined4 *)FUN_01674e20(0x18);
      uStack_8 = 5;
      if (puStack_14 == (undefined4 *)0x0) {
        puVar9 = (undefined4 *)0x0;
        puVar7 = param_2;
      }
      else {
        FUN_0054ef60(&ppppppuStack_38);
        uStack_8 = 6;
        *puStack_14 = 0;
        puStack_14[2] = pppppppuStack_20;
        puStack_14[3] = 2;
        iStack_98 = FUN_01674e20(0x18);
        uStack_8 = 7;
        if (iStack_98 == 0) {
          uVar6 = 0;
        }
        else {
          uVar6 = FUN_0054ef60(aiStack_94);
        }
        uStack_8 = 5;
        puStack_14[4] = uVar6;
        puVar9 = puStack_14;
        puVar7 = puStack_24;
        ppppppuVar11 = ppppppuStack_38;
        if (0xf < uStack_80) {
          uVar10 = uStack_80 + 1;
          iVar3 = aiStack_94[0];
          if (0xfff < uVar10) {
            iVar3 = *(int *)(aiStack_94[0] + -4);
            uVar10 = uStack_80 + 0x24;
            if (0x1f < (aiStack_94[0] - iVar3) - 4U) goto LAB_008839ff;
          }
          FUN_01674ea0(iVar3,uVar10);
          puVar9 = puStack_14;
          puVar7 = puStack_24;
          ppppppuVar11 = ppppppuStack_38;
        }
      }
      if ((undefined4 *)puVar4[9] == (undefined4 *)0x0) {
        puVar4[8] = puVar9;
      }
      else {
        *(undefined4 *)puVar4[9] = puVar9;
      }
      puVar4[9] = puVar9;
      uStack_8 = 3;
      if (&DAT_0000000f < puVar7) {
        puVar9 = (undefined4 *)((int)puVar7 + 1);
        ppppppuVar12 = ppppppuVar11;
        if ((undefined4 *)0xfff < puVar9) {
          ppppppuVar12 = (uint ******)ppppppuVar11[-1];
          puVar9 = puVar7 + 9;
          if (0x1f < (uint)((int)ppppppuVar11 + (-4 - (int)ppppppuVar12))) goto LAB_008839ff;
        }
        FUN_01674ea0(ppppppuVar12,puVar9);
      }
      param_2 = puVar4 + 4;
      pppppppuStack_20 = (uint *******)&pppppppuStack_78;
      if ((uint ******)0xf < ppppppuStack_64) {
        pppppppuStack_20 = pppppppuStack_78;
      }
      ppppppuStack_28 = (uint ******)0x0;
      puStack_24 = (undefined4 *)0x0;
      pppppppuStack_1c = pppppppuStack_78;
      if (ppppppuStack_68 < (uint ******)0x10) {
        ppppppuVar11 = *pppppppuStack_20;
        ppppppuStack_34 = pppppppuStack_20[1];
        ppppppuStack_30 = pppppppuStack_20[2];
        ppppppuStack_2c = pppppppuStack_20[3];
        puVar4 = (undefined4 *)&DAT_0000000f;
        ppppppuStack_38 = ppppppuVar11;
      }
      else {
        puVar4 = (undefined4 *)((uint)ppppppuStack_68 | 0xf);
        if ((undefined4 *)0x7fffffff < puVar4) {
          puVar4 = (undefined4 *)0x7fffffff;
        }
        puVar9 = (undefined4 *)((int)puVar4 + 1);
        if (puVar9 < &DAT_00001000) {
          if (puVar9 == (undefined4 *)0x0) {
            ppppppuVar11 = (uint ******)0x0;
          }
          else {
            ppppppuVar11 = (uint ******)FUN_01674e20(puVar9);
          }
        }
        else {
          puVar7 = puVar4 + 9;
          if (puVar7 <= puVar9) {
            puVar7 = (undefined4 *)0xffffffff;
          }
          pppppuVar8 = (uint *****)FUN_01674e20(puVar7);
          if (pppppuVar8 == (uint *****)0x0) goto LAB_008839ff;
          ppppppuVar11 = (uint ******)((int)pppppuVar8 + 0x23U & 0xffffffe0);
          ppppppuVar11[-1] = pppppuVar8;
        }
        ppppppuStack_38 = ppppppuVar11;
        FUN_0170c6f0(ppppppuVar11,pppppppuStack_20,(int)ppppppuStack_68 + 1);
      }
      uStack_8 = 8;
      ppppppuStack_28 = ppppppuStack_68;
      puStack_24 = puVar4;
      FUN_0087ccc0();
      iStack_9c = FUN_01674e20(0x18);
      uStack_8 = 9;
      if (iStack_9c == 0) {
        uVar6 = 0;
      }
      else {
        uVar6 = FUN_0054ef60(&ppppppuStack_38);
        ppppppuVar11 = ppppppuStack_38;
        puVar4 = puStack_24;
      }
      uStack_8 = 3;
      param_2[2] = uVar6;
      param_2[1] = 2;
      if (&DAT_0000000f < puVar4) {
        puVar9 = (undefined4 *)((int)puVar4 + 1);
        ppppppuVar12 = ppppppuVar11;
        if ((undefined4 *)0xfff < puVar9) {
          ppppppuVar12 = (uint ******)ppppppuVar11[-1];
          puVar9 = puVar4 + 9;
          if (0x1f < (uint)((int)ppppppuVar11 + (-4 - (int)ppppppuVar12))) goto LAB_008839ff;
        }
        FUN_01674ea0(ppppppuVar12,puVar9);
      }
      uStack_8 = 1;
      if (0xf < uStack_4c) {
        uVar10 = uStack_4c + 1;
        pppppppuVar5 = apppppppuStack_60[0];
        if (0xfff < uVar10) {
          pppppppuVar5 = (uint *******)apppppppuStack_60[0][-1];
          uVar10 = uStack_4c + 0x24;
          if (0x1f < (uint)((int)apppppppuStack_60[0] + (-4 - (int)pppppppuVar5)))
          goto LAB_008839ff;
        }
        FUN_01674ea0(pppppppuVar5,uVar10);
      }
      ppppppuStack_50 = (uint ******)0x0;
      uStack_4c = 0xf;
      apppppppuStack_60[0] = (uint *******)((uint)apppppppuStack_60[0] & 0xffffff00);
      uStack_8 = 0;
      if ((uint ******)0xf < ppppppuStack_64) {
        ppppppuVar11 = (uint ******)((int)ppppppuStack_64 + 1);
        pppppppuVar5 = pppppppuStack_1c;
        if ((uint ******)0xfff < ppppppuVar11) {
          pppppppuVar5 = (uint *******)pppppppuStack_1c[-1];
          ppppppuVar11 = ppppppuStack_64 + 9;
          if (0x1f < (uint)((int)pppppppuStack_1c + (-4 - (int)pppppppuVar5))) {
LAB_008839ff:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(pppppppuVar5,ppppppuVar11);
      }
      iStack_18 = iStack_18 + 4;
    } while (iStack_18 != iStack_40);
  }
  FUN_00612dd0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13696 ; VA 0x00883a10 ; FUN_00883a10 */

undefined4 * __thiscall FUN_00883a10(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int ***pppiVar2;
  char cVar3;
  uint uVar4;
  int ****ppppiVar5;
  int *piVar6;
  int iVar7;
  undefined4 uVar8;
  int iVar9;
  undefined4 ****ppppuVar10;
  char *pcVar11;
  int ****ppppiVar12;
  int *piVar13;
  char *pcVar14;
  int iVar15;
  bool bVar16;
  undefined auStack_e0 [4];
  undefined4 uStack_dc;
  int ***pppiStack_d8;
  int **ppiStack_d4;
  int ***pppiStack_d0;
  int ***pppiStack_cc;
  undefined auStack_c0 [24];
  undefined4 ***apppuStack_a8 [4];
  int iStack_98;
  uint uStack_94;
  undefined *puStack_90;
  int ***apppiStack_8c [5];
  uint uStack_78;
  undefined4 ***apppuStack_74 [3];
  undefined auStack_68 [4];
  undefined4 uStack_64;
  uint uStack_60;
  int iStack_5c;
  uint uStack_58;
  int ***apppiStack_54 [3];
  undefined auStack_48 [4];
  int **ppiStack_44;
  uint uStack_40;
  int iStack_3c;
  int iStack_38;
  int ***pppiStack_34;
  int **ppiStack_30;
  int **ppiStack_2c;
  int **ppiStack_28;
  int **ppiStack_24;
  int **ppiStack_20;
  char cStack_19;
  char *pcStack_18;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8._0_1_ = 0xff;
  uStack_8._1_3_ = 0xffffff;
  puStack_c = &LAB_017b9daf;
  pvStack_10 = ExceptionList;
  uStack_58 = 0;
  piVar13 = *(int **)(param_1 + 4);
  if ((*(byte **)piVar13[7] == (byte *)0x0) || (*(int *)piVar13[0xb] < 1)) {
    pppiStack_cc = (int ***)0x883a59;
    ExceptionList = &pvStack_10;
    uVar4 = (**(code **)(*piVar13 + 0x18))();
  }
  else {
    uVar4 = (uint)**(byte **)piVar13[7];
    ExceptionList = &pvStack_10;
  }
  if (uVar4 == 0xffffffff) {
LAB_00884186:
    pppiStack_cc = (int ***)0x191ca8c;
    pppiStack_d0 = (int ***)0x884193;
    FUN_00550130();
    pppiStack_cc = (int ***)&DAT_01c17198;
    pppiStack_d0 = (int ***)auStack_68;
                    /* WARNING: Subroutine does not return */
    ppiStack_d4 = (int **)0x8841a1;
    FUN_0170c2a8();
  }
  cStack_11 = '\x01';
  do {
    while( true ) {
      ppiStack_24 = (int **)0x0;
      ppiStack_20 = (int **)0xf;
      pppiStack_34 = (int ***)((uint)pppiStack_34 & 0xffffff00);
      uStack_8 = 0;
      pppiStack_cc = (int ***)apppiStack_8c;
      if (cStack_11 == '\0') break;
      cStack_11 = '\0';
      pppiStack_d0 = (int ***)0x883aa3;
      ppppiVar5 = (int ****)FUN_008848a0();
      if (&pppiStack_34 != ppppiVar5) {
        if ((int ***)0xf < ppiStack_20) {
          pppiStack_cc = (int ***)((int)ppiStack_20 + 1);
          ppppiVar12 = (int ****)pppiStack_34;
          if ((int ***)0xfff < pppiStack_cc) {
            ppppiVar12 = (int ****)pppiStack_34[-1];
            pppiStack_cc = (int ***)(ppiStack_20 + 9);
            if ((char *)0x1f < (char *)((int)pppiStack_34 + (-4 - (int)ppppiVar12)))
            goto LAB_008841a1;
          }
          ppiStack_d4 = (int **)0x883add;
          pppiStack_d0 = (int ***)ppppiVar12;
          FUN_01674ea0();
        }
        pppiStack_34 = *ppppiVar5;
        ppiStack_30 = (int **)ppppiVar5[1];
        ppiStack_2c = (int **)ppppiVar5[2];
        ppiStack_28 = (int **)ppppiVar5[3];
        ppiStack_24 = (int **)ppppiVar5[4];
        ppiStack_20 = (int **)ppppiVar5[5];
        ppppiVar5[4] = (int ***)0x0;
        ppppiVar5[5] = (int ***)0xf;
        *(undefined *)ppppiVar5 = 0;
      }
      if (0xf < uStack_78) {
        pppiStack_cc = (int ***)(uStack_78 + 1);
        ppppiVar5 = (int ****)apppiStack_8c[0];
        if (0xfff < pppiStack_cc) {
          ppppiVar5 = (int ****)apppiStack_8c[0][-1];
          pppiStack_cc = (int ***)(uStack_78 + 0x24);
          if ((char *)0x1f < (char *)((int)apppiStack_8c[0] + (-4 - (int)ppppiVar5)))
          goto LAB_008841a1;
        }
        ppiStack_d4 = (int **)0x883b48;
        pppiStack_d0 = (int ***)ppppiVar5;
        FUN_01674ea0();
      }
      ppiStack_44 = (int **)0x0;
      uStack_40 = 0xf;
      pppiStack_cc = (int ***)0x2;
      if (ppiStack_24 < (int ***)0x2) {
        pppiStack_cc = (int ***)ppiStack_24;
      }
      pppiStack_d0 = (int ***)&pppiStack_34;
      if ((int ***)0xf < ppiStack_20) {
        pppiStack_d0 = pppiStack_34;
      }
      apppiStack_54[0] = (int ***)((uint)apppiStack_54[0] & 0xffffff00);
      ppiStack_d4 = (int **)0x883b7e;
      FUN_005542c0();
      pppiVar2 = apppiStack_54[0];
      uStack_58 = uStack_58 | 2;
      pppiStack_cc = (int ***)0x2;
      pppiStack_d0 = (int ***)&DAT_0191caac;
      ppiStack_d4 = ppiStack_44;
      pppiStack_d8 = (int ***)apppiStack_54;
      if (0xf < uStack_40) {
        pppiStack_d8 = apppiStack_54[0];
      }
      uStack_dc = 0x883b9f;
      cStack_12 = FUN_0055c360();
      if (0xf < uStack_40) {
        pppiStack_cc = (int ***)(uStack_40 + 1);
        ppppiVar5 = (int ****)pppiVar2;
        if (0xfff < pppiStack_cc) {
          ppppiVar5 = (int ****)pppiVar2[-1];
          pppiStack_cc = (int ***)(uStack_40 + 0x24);
          if ((char *)0x1f < (char *)((int)pppiVar2 + (-4 - (int)ppppiVar5))) goto LAB_008841a1;
        }
        ppiStack_d4 = (int **)0x883bd5;
        pppiStack_d0 = (int ***)ppppiVar5;
        FUN_01674ea0();
      }
      if (cStack_12 == '\0') goto LAB_00883cd9;
      uStack_8 = 0xffffffff;
      if ((int ***)0xf < ppiStack_20) {
        pppiStack_cc = (int ***)((int)ppiStack_20 + 1);
        ppppiVar5 = (int ****)pppiStack_34;
        if ((int ***)0xfff < pppiStack_cc) {
          ppppiVar5 = (int ****)pppiStack_34[-1];
          pppiStack_cc = (int ***)(ppiStack_20 + 9);
          if ((char *)0x1f < (char *)((int)pppiStack_34 + (-4 - (int)ppppiVar5))) goto LAB_008841a1;
        }
        ppiStack_d4 = (int **)0x883c21;
        pppiStack_d0 = (int ***)ppppiVar5;
        FUN_01674ea0();
      }
    }
    pppiStack_d0 = (int ***)0x883c31;
    ppppiVar5 = (int ****)FUN_00884b70();
    if (&pppiStack_34 != ppppiVar5) {
      if ((int ***)0xf < ppiStack_20) {
        pppiStack_cc = (int ***)((int)ppiStack_20 + 1);
        ppppiVar12 = (int ****)pppiStack_34;
        if ((int ***)0xfff < pppiStack_cc) {
          ppppiVar12 = (int ****)pppiStack_34[-1];
          pppiStack_cc = (int ***)(ppiStack_20 + 9);
          if ((char *)0x1f < (char *)((int)pppiStack_34 + (-4 - (int)ppppiVar12))) {
LAB_008841a1:
                    /* WARNING: Subroutine does not return */
            pppiStack_cc = (int ***)0x8841a6;
            FUN_017167a3();
          }
        }
        ppiStack_d4 = (int **)0x883c6b;
        pppiStack_d0 = (int ***)ppppiVar12;
        FUN_01674ea0();
      }
      pppiStack_34 = *ppppiVar5;
      ppiStack_30 = (int **)ppppiVar5[1];
      ppiStack_2c = (int **)ppppiVar5[2];
      ppiStack_28 = (int **)ppppiVar5[3];
      ppiStack_24 = (int **)ppppiVar5[4];
      ppiStack_20 = (int **)ppppiVar5[5];
      ppppiVar5[4] = (int ***)0x0;
      ppppiVar5[5] = (int ***)0xf;
      *(undefined *)ppppiVar5 = 0;
    }
    if (0xf < uStack_78) {
      pppiStack_cc = (int ***)(uStack_78 + 1);
      ppppiVar5 = (int ****)apppiStack_8c[0];
      if (0xfff < pppiStack_cc) {
        ppppiVar5 = (int ****)apppiStack_8c[0][-1];
        pppiStack_cc = (int ***)(uStack_78 + 0x24);
        if ((char *)0x1f < (char *)((int)apppiStack_8c[0] + (-4 - (int)ppppiVar5)))
        goto LAB_008841a1;
      }
      ppiStack_d4 = (int **)0x883cd6;
      pppiStack_d0 = (int ***)ppppiVar5;
      FUN_01674ea0();
    }
LAB_00883cd9:
    if (*(int *)(param_1 + 0x18) == 0) {
      iStack_3c = 0;
    }
    else {
      piVar13 = (int *)0x0;
      if ((*(int **)(param_1 + 8) != (int *)0x0) &&
         (puVar1 = (undefined4 *)**(int **)(param_1 + 8), puVar1 != (undefined4 *)0x0)) {
        piVar13 = (int *)*puVar1;
      }
      uVar4 = (*(int *)(param_1 + 0x14) + *(int *)(param_1 + 0x18)) - 1;
      piVar6 = (int *)0x0;
      if ((piVar13 != (int *)0x0) && ((undefined4 *)*piVar13 != (undefined4 *)0x0)) {
        piVar6 = *(int **)*piVar13;
      }
      if (piVar6 == (int *)0x0) {
        iVar7 = 0;
      }
      else {
        iVar7 = *piVar6;
      }
      iStack_3c = *(int *)(*(int *)(*(int *)(iVar7 + 4) +
                                   (*(int *)(iVar7 + 8) - 1U & uVar4 >> 2) * 4) + (uVar4 & 3) * 4);
    }
    ppppiVar5 = &pppiStack_34;
    if ((int ***)0xf < ppiStack_20) {
      ppppiVar5 = (int ****)pppiStack_34;
    }
    if ((*(char *)ppppiVar5 == '<') && (*(char *)((int)ppppiVar5 + 1) == '/')) {
      if (iStack_3c == 0) {
        pppiStack_cc = (int ***)0x8841ae;
        pppiStack_cc = (int ***)FUN_005543f0();
        ppiStack_d4 = (int **)auStack_68;
        pppiStack_d0 = (int ***)0x191cab0;
        pppiStack_d8 = (int ***)0x8841bd;
        FUN_016756b0();
        pppiStack_d0 = (int ***)auStack_68;
        pppiStack_cc = (int ***)&DAT_01c17198;
                    /* WARNING: Subroutine does not return */
        ppiStack_d4 = (int **)0x8841ce;
        FUN_0170c2a8();
      }
      iVar7 = *(int *)(param_1 + 0x18) + -1;
      *(int *)(param_1 + 0x18) = iVar7;
      if (iVar7 == 0) {
        *(undefined4 *)(param_1 + 0x14) = 0;
        pppiStack_cc = (int ***)param_2;
        *param_2 = 0;
        param_2[1] = 0;
        ppiStack_d4 = (int **)0x883d80;
        pppiStack_d0 = (int ***)iStack_3c;
        FUN_00882290();
        pppiStack_cc = (int ***)0x883d88;
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    else {
      pppiStack_cc = (int ***)&pppiStack_34;
      pppiStack_d0 = (int ***)0x883da7;
      iStack_38 = FUN_00884250();
      uVar4 = *(uint *)(param_1 + 0x14);
      if (((*(int *)(param_1 + 0x18) + uVar4 & 3) == 0) &&
         (*(uint *)(param_1 + 0x10) <= *(int *)(param_1 + 0x18) + 4U >> 2)) {
        pppiStack_cc = (int ***)0x1;
        pppiStack_d0 = (int ***)0x883dcd;
        FUN_006a2af0();
        uVar4 = *(uint *)(param_1 + 0x14);
      }
      uVar4 = *(int *)(param_1 + 0x10) * 4 - 1U & uVar4;
      *(uint *)(param_1 + 0x14) = uVar4;
      pcStack_18 = (char *)(*(int *)(param_1 + 0x18) + uVar4);
      iStack_5c = ((uint)pcStack_18 >> 2 & *(int *)(param_1 + 0x10) - 1U) * 4;
      iVar7 = *(int *)(param_1 + 0xc);
      if (*(int *)(iStack_5c + iVar7) == 0) {
        pppiStack_cc = (int ***)0x10;
        pppiStack_d0 = (int ***)0x883e0c;
        uVar8 = FUN_01674e20();
        *(undefined4 *)(iStack_5c + *(int *)(param_1 + 0xc)) = uVar8;
        iVar7 = *(int *)(param_1 + 0xc);
      }
      *(int *)(*(int *)(iVar7 + iStack_5c) + ((uint)pcStack_18 & 3) * 4) = iStack_38;
      *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 1;
      iVar7 = *(int *)(iStack_38 + 0x10);
      pppiStack_cc = (int ***)0x883e38;
      iVar9 = FUN_0088d190();
      iVar15 = iStack_38;
      if (iVar7 == *(int *)(iVar9 + 0x18)) {
        pppiStack_cc = (int ***)DAT_01ede588;
        pppiStack_d0 = (int ***)0x883e53;
        iVar7 = FUN_0087cdb0();
        if (iVar7 != 0) {
          pppiStack_cc = (int ***)&cStack_19;
          pppiStack_d0 = (int ***)0x883e63;
          cVar3 = FUN_0087d410();
          if ((cVar3 != '\0') && (cStack_19 != '\0')) goto LAB_008840f7;
        }
        pppiStack_cc = (int ***)0x0;
        pppiStack_d0 = (int ***)apppiStack_8c;
        ppiStack_d4 = (int **)0x883e81;
        pppiStack_d8 = (int ***)FUN_00884dd0();
        ppiStack_d4 = (int **)((int ****)pppiStack_d8)[4];
        if ((int ***)0xf < ((int ****)pppiStack_d8)[5]) {
          pppiStack_d8 = (int ***)*pppiStack_d8;
        }
        pppiStack_cc = (int ***)0x0;
        pppiStack_d0 = (int ***)&DAT_018bc9b8;
        uStack_dc = 0x883e9a;
        cStack_12 = FUN_0055c360();
        if (0xf < uStack_78) {
          pppiStack_cc = (int ***)(uStack_78 + 1);
          ppppiVar5 = (int ****)apppiStack_8c[0];
          if (0xfff < pppiStack_cc) {
            ppppiVar5 = (int ****)apppiStack_8c[0][-1];
            pppiStack_cc = (int ***)(uStack_78 + 0x24);
            if ((char *)0x1f < (char *)((int)apppiStack_8c[0] + (-4 - (int)ppppiVar5)))
            goto LAB_008841a1;
          }
          ppiStack_d4 = (int **)0x883ed4;
          pppiStack_d0 = (int ***)ppppiVar5;
          FUN_01674ea0();
        }
        if (cStack_12 != '\0') {
          pppiStack_cc = (int ***)apppuStack_a8;
          pppiStack_d0 = (int ***)0x883ef0;
          FUN_00884b70();
          uStack_8._0_1_ = 1;
          uStack_64 = 0;
          uStack_60 = 0xf;
          apppuStack_74[0] = (undefined4 ***)((uint)apppuStack_74[0] & 0xffffff00);
          if (iStack_98 == 0) {
            pppiStack_cc = (int ***)0x884186;
            FUN_00554050();
            goto LAB_00884186;
          }
          pppiStack_cc = (int ***)(iStack_98 - (2 - (uint)(iStack_98 - 1U < iStack_98 - 2U)));
          ppppuVar10 = apppuStack_a8;
          if (0xf < uStack_94) {
            ppppuVar10 = (undefined4 ****)apppuStack_a8[0];
          }
          pppiStack_d0 = (int ***)((int)ppppuVar10 + 1);
          ppiStack_d4 = (int **)0x883f43;
          FUN_005542c0();
          pppiStack_cc = (int ***)0x18c2ef4;
          pppiStack_d0 = (int ***)0x6;
          ppiStack_d4 = (int **)0x0;
          uStack_8._0_1_ = 2;
          pppiStack_d8 = (int ***)0x883f58;
          iVar7 = FUN_00780cc0();
          if (iVar7 == 0) {
            pppiStack_cc = (int ***)0x191caec;
            pppiStack_d0 = (int ***)0x2;
            ppiStack_d4 = (int **)0x883f68;
            FUN_0086f2f0();
LAB_00883f6b:
            pppiStack_cc = (int ***)0x0;
            pppiStack_d0 = (int ***)apppiStack_54;
            ppiStack_d4 = (int **)0x883f78;
            FUN_00884dd0();
            pppiStack_cc = (int ***)0x883f80;
            FUN_005507b0();
LAB_00884064:
            pppiStack_d0 = (int ***)0x0;
            pppiStack_cc = (int ***)0xf;
            auStack_e0[0] = 0;
            FUN_00885fd0();
          }
          else {
            pppiStack_d0 = (int ***)apppuStack_74;
            if (0xf < uStack_60) {
              pppiStack_d0 = apppuStack_74[0];
            }
            ppiStack_d4 = (int **)DAT_01ede60c[4];
            pppiStack_d8 = (int ***)DAT_01ede60c;
            if ((int ***)0xf < DAT_01ede60c[5]) {
              pppiStack_d8 = *DAT_01ede60c;
            }
            pppiStack_cc = (int ***)uStack_64;
            uStack_dc = 0x883fab;
            cVar3 = FUN_0055c360();
            if (cVar3 != '\0') goto LAB_00883f6b;
            pppiStack_cc = (int ***)&DAT_018e4848;
            pppiStack_d0 = (int ***)0x3;
            ppiStack_d4 = (int **)0x0;
            pppiStack_d8 = (int ***)0x883fc3;
            iVar7 = FUN_00780cc0();
            if (iVar7 != 0) {
              pppiStack_cc = (int ***)apppuStack_74;
              pppiStack_d0 = (int ***)0x88405c;
              cVar3 = FUN_0087ca50();
              if (cVar3 == '\0') {
                pppiStack_cc = (int ***)0x20;
                pppiStack_d0 = (int ***)0x0;
                ppiStack_d4 = (int **)auStack_c0;
                pppiStack_d8 = (int ***)0x88421c;
                FUN_0058c540();
                uStack_8 = CONCAT31(uStack_8._1_3_,5);
                pppiStack_cc = (int ***)0x884227;
                pppiStack_cc = (int ***)FUN_005543f0();
                ppiStack_d4 = (int **)auStack_48;
                pppiStack_d0 = (int ***)0x191cb04;
                pppiStack_d8 = (int ***)0x884236;
                FUN_016756b0();
                pppiStack_d0 = (int ***)auStack_48;
                pppiStack_cc = (int ***)&DAT_01c17198;
                    /* WARNING: Subroutine does not return */
                ppiStack_d4 = (int **)&UNK_00884247;
                FUN_0170c2a8();
              }
              goto LAB_00884064;
            }
            pppiStack_cc = (int ***)0x1;
            pppiStack_d0 = (int ***)apppiStack_54;
            ppiStack_d4 = (int **)0x883fd8;
            pcVar11 = (char *)FUN_00884dd0();
            uStack_8._0_1_ = 3;
            if (0xf < *(uint *)(pcVar11 + 0x14)) {
              pcVar11 = *(char **)pcVar11;
            }
            puStack_90 = auStack_e0;
            pcStack_18 = pcVar11 + 1;
            pppiStack_d0 = (int ***)0x0;
            pppiStack_cc = (int ***)0xf;
            auStack_e0[0] = 0;
            pcVar14 = pcVar11;
            do {
              cVar3 = *pcVar14;
              pcVar14 = pcVar14 + 1;
            } while (cVar3 != '\0');
            FUN_005542c0(pcVar11,(int)pcVar14 - (int)pcStack_18);
            uStack_8._0_1_ = 4;
            FUN_009cbbb0(auStack_e0);
            iVar15 = iStack_38;
            uStack_8._0_1_ = 3;
            FUN_00885fd0();
            uStack_8._0_1_ = 2;
            pppiStack_cc = (int ***)0x88404b;
            FUN_005507b0();
          }
          pppiStack_cc = (int ***)apppiStack_8c;
          pppiStack_d0 = (int ***)0x884090;
          FUN_00884b70();
          uStack_8._0_1_ = 6;
          ppppiVar5 = apppiStack_8c;
          if (0xf < uStack_78) {
            ppppiVar5 = (int ****)apppiStack_8c[0];
          }
          if (*(char *)ppppiVar5 == '<') {
            bVar16 = *(char *)((int)ppppiVar5 + 1) == '/';
          }
          else {
            bVar16 = false;
          }
          if (!bVar16) {
            pppiStack_cc = (int ***)0x20;
            pppiStack_d0 = (int ***)0x0;
            ppiStack_d4 = (int **)auStack_c0;
            pppiStack_d8 = (int ***)0x8841de;
            FUN_0058c540();
            uStack_8 = CONCAT31(uStack_8._1_3_,7);
            pppiStack_cc = (int ***)0x8841e9;
            pppiStack_cc = (int ***)FUN_005543f0();
            ppiStack_d4 = (int **)auStack_48;
            pppiStack_d0 = (int ***)0x191cb30;
            pppiStack_d8 = (int ***)0x8841f8;
            FUN_016756b0();
            pppiStack_d0 = (int ***)auStack_48;
            pppiStack_cc = (int ***)&DAT_01c17198;
                    /* WARNING: Subroutine does not return */
            ppiStack_d4 = (int **)0x884209;
            FUN_0170c2a8();
          }
          pppiStack_cc = (int ***)0x8840c8;
          FUN_005507b0();
          pppiStack_cc = (int ***)0x8840d0;
          FUN_005507b0();
          pppiStack_cc = (int ***)0x8840db;
          FUN_005507b0();
        }
      }
      else {
        FUN_00884dd0(auStack_e0,1);
        iVar15 = iStack_38;
        FUN_00885f30();
      }
LAB_008840f7:
      if (iStack_3c != 0) {
        if (*(int **)(iStack_3c + 8) == (int *)0x0) {
          *(int *)(iStack_3c + 4) = iVar15;
        }
        else {
          **(int **)(iStack_3c + 8) = iVar15;
        }
        *(int *)(iStack_3c + 8) = iVar15;
      }
      if ((int ***)0x1 < ppiStack_24) {
        ppppiVar5 = &pppiStack_34;
        if ((int ***)0xf < ppiStack_20) {
          ppppiVar5 = (int ****)pppiStack_34;
        }
        if ((*(char *)((int)ppiStack_24 + -2 + (int)ppppiVar5) == '/') &&
           (*(char *)((int)ppiStack_24 + -1 + (int)ppppiVar5) == '>')) {
          piVar13 = (int *)(param_1 + 0x18);
          *piVar13 = *piVar13 + -1;
          if (*piVar13 == 0) {
            *(undefined4 *)(param_1 + 0x14) = 0;
          }
        }
      }
    }
    uStack_8 = 0xffffffff;
    if ((int ***)0xf < ppiStack_20) {
      pppiStack_cc = (int ***)((int)ppiStack_20 + 1);
      ppppiVar5 = (int ****)pppiStack_34;
      if ((int ***)0xfff < pppiStack_cc) {
        ppppiVar5 = (int ****)pppiStack_34[-1];
        pppiStack_cc = (int ***)(ppiStack_20 + 9);
        if ((char *)0x1f < (char *)((int)pppiStack_34 + (-4 - (int)ppppiVar5))) goto LAB_008841a1;
      }
      ppiStack_d4 = (int **)0x884176;
      pppiStack_d0 = (int ***)ppppiVar5;
      FUN_01674ea0();
    }
  } while( true );
}



/* FUNCTION 13697 ; VA 0x00884250 ; FUN_00884250 */

undefined4 * FUN_00884250(uint *****param_1)

{
  byte *pbVar1;
  byte bVar2;
  bool bVar3;
  undefined4 uVar4;
  int iVar5;
  uint ****ppppuVar6;
  uint *****pppppuVar7;
  uint ***pppuVar8;
  undefined4 *puVar9;
  byte *pbVar10;
  uint ****ppppuVar11;
  uint uVar12;
  uint *****pppppuVar13;
  uint uVar14;
  uint *****pppppuVar15;
  char *pcVar16;
  undefined auStack_a8 [16];
  undefined4 uStack_98;
  undefined4 uStack_94;
  int iStack_90;
  int aiStack_8c [5];
  uint uStack_78;
  uint auStack_74 [4];
  undefined4 uStack_64;
  uint uStack_60;
  uint ****ppppuStack_5c;
  uint ***pppuStack_58;
  uint ***pppuStack_54;
  uint ***pppuStack_50;
  uint ***pppuStack_4c;
  uint ***pppuStack_48;
  uint ****ppppuStack_44;
  uint ****ppppuStack_40;
  uint ***pppuStack_3c;
  uint ***pppuStack_38;
  uint ***pppuStack_34;
  uint ***pppuStack_30;
  uint ***pppuStack_2c;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  uint ***pppuStack_1c;
  uint ****ppppuStack_18;
  uint ****ppppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  ppppuStack_18 = (uint ****)0x1;
  uStack_8._0_1_ = 0xff;
  uStack_8._1_3_ = 0xffffff;
  puStack_c = &LAB_017b9e1e;
  pvStack_10 = ExceptionList;
  while( true ) {
    pppppuVar7 = param_1;
    if ((uint ****)0xf < param_1[5]) {
      pppppuVar7 = (uint *****)*param_1;
    }
    ppppuStack_14 = param_1[4];
    pppppuVar15 = (uint *****)ppppuStack_18;
    if (((&DAT_01d62930)[*(byte *)((int)pppppuVar7 + (int)ppppuStack_18)] == '\0') ||
       ((int)ppppuStack_14 <= (int)ppppuStack_18)) break;
    ppppuStack_18 = (uint ****)((int)ppppuStack_18 + 1);
  }
  while( true ) {
    pppppuVar7 = param_1;
    if ((uint ****)0xf < param_1[5]) {
      pppppuVar7 = (uint *****)*param_1;
    }
    ppppuVar11 = param_1[5];
    if ((&DAT_01d62930)[*(byte *)((int)pppppuVar7 + (int)pppppuVar15)] != '\0') goto LAB_008842db;
    pppppuVar7 = param_1;
    if (&DAT_0000000f < ppppuVar11) {
      pppppuVar7 = (uint *****)*param_1;
    }
    if (*(char *)((int)pppppuVar7 + (int)pppppuVar15) == '>') goto LAB_008842db;
    if ((int)ppppuStack_14 <= (int)pppppuVar15) break;
    pppppuVar15 = (uint *****)((int)pppppuVar15 + 1);
  }
  ppppuVar11 = param_1[5];
LAB_008842db:
  pppuStack_1c = (uint ***)((int)pppppuVar15 - (int)ppppuStack_18);
  uStack_98 = 0;
  uStack_94 = 0xf;
  auStack_a8[0] = 0;
  ExceptionList = &pvStack_10;
  if (ppppuStack_18 <= ppppuStack_14) {
    if ((uint ****)((int)ppppuStack_14 - (int)ppppuStack_18) < pppuStack_1c) {
      pppuStack_1c = (uint ***)((int)ppppuStack_14 - (int)ppppuStack_18);
    }
    pppppuVar7 = param_1;
    if ((uint ****)0xf < ppppuVar11) {
      pppppuVar7 = (uint *****)*param_1;
    }
    ExceptionList = &pvStack_10;
    FUN_005542c0((undefined *)((int)pppppuVar7 + (int)ppppuStack_18),pppuStack_1c);
    uStack_8 = 0;
    puStack_24 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 1;
    if (puStack_24 == (undefined4 *)0x0) {
      puStack_20 = (undefined4 *)0x0;
    }
    else {
      puStack_20 = puStack_24;
      uVar4 = FUN_0086e830(auStack_a8);
      *puStack_20 = 0;
      puStack_20[1] = 0;
      puStack_20[2] = 0;
      puStack_20[4] = uVar4;
      puStack_20[5] = 0;
      puStack_20[8] = 0;
      puStack_20[9] = 0;
    }
    uStack_8._0_1_ = 0;
    do {
      pppppuVar7 = param_1;
      if ((uint ****)0xf < param_1[5]) {
        pppppuVar7 = (uint *****)*param_1;
      }
      pbVar10 = (byte *)((int)pppppuVar7 + (int)pppppuVar15);
      bVar2 = *pbVar10;
      while ((bVar2 != 0x3e && (bVar2 != 0))) {
        if ((&DAT_01d62930)[bVar2] == '\0') {
          bVar3 = true;
          goto LAB_008843d0;
        }
        pbVar1 = pbVar10 + 1;
        pbVar10 = pbVar10 + 1;
        pppppuVar15 = (uint *****)((int)pppppuVar15 + 1);
        bVar2 = *pbVar1;
      }
      bVar3 = false;
LAB_008843d0:
      if (!bVar3) {
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return puStack_20;
      }
      pppppuVar7 = (uint *****)param_1[4];
      ppppuStack_14 = (uint ****)param_1;
      if ((uint ****)0xf < param_1[5]) {
        ppppuStack_14 = *param_1;
      }
      if (pppppuVar15 < pppppuVar7) {
        ppppuStack_18 = (uint ****)((int)pppppuVar7 - (int)pppppuVar15);
        iVar5 = FUN_0170db20((undefined *)((int)ppppuStack_14 + (int)pppppuVar15),0x3d,ppppuStack_18
                            );
        pppppuVar7 = (uint *****)ppppuStack_18;
        if (iVar5 == 0) goto LAB_00884416;
        ppppuStack_14 = (uint ****)(iVar5 - (int)ppppuStack_14);
      }
      else {
        pppppuVar7 = (uint *****)((int)pppppuVar7 - (int)pppppuVar15);
LAB_00884416:
        ppppuStack_14 = (uint ****)0xffffffff;
      }
      uStack_64 = 0;
      uStack_60 = 0xf;
      auStack_74[0] = auStack_74[0] & 0xffffff00;
      if (param_1[4] < pppppuVar15) break;
      pppppuVar13 = (uint *****)((int)ppppuStack_14 - (int)pppppuVar15);
      if (pppppuVar7 < (uint *****)((int)ppppuStack_14 - (int)pppppuVar15)) {
        pppppuVar13 = pppppuVar7;
      }
      pppppuVar7 = param_1;
      if ((uint ****)0xf < param_1[5]) {
        pppppuVar7 = (uint *****)*param_1;
      }
      FUN_005542c0((undefined *)((int)pppppuVar7 + (int)pppppuVar15),pppppuVar13);
      uStack_8._0_1_ = 2;
      if ((uint *****)ppppuStack_14 == (uint *****)0xffffffff) {
        pcVar16 = "Unable to parse XML attributes. \'=\' not found";
        goto LAB_0088487c;
      }
      ppppuStack_18 = (uint ****)((int)ppppuStack_14 + 1);
      ppppuVar11 = (uint ****)((int)ppppuStack_14 + 2);
      ppppuStack_14 = (uint ****)param_1;
      if ((uint ****)0xf < param_1[5]) {
        ppppuStack_14 = *param_1;
      }
      if (param_1[4] <= ppppuVar11) {
LAB_00884877:
        pcVar16 = "Unable to parse XML attributes. \'\"\' not found";
LAB_0088487c:
        FUN_00550130(pcVar16);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(&pppuStack_4c,&DAT_01c17198);
      }
      pppuStack_1c = (uint ***)((int)param_1[4] - (int)ppppuVar11);
      iVar5 = FUN_0170db20((undefined *)((int)ppppuStack_14 + (int)ppppuVar11),0x22,pppuStack_1c);
      if ((iVar5 == 0) ||
         (ppppuStack_14 = (uint ****)(iVar5 - (int)ppppuStack_14),
         (uint *****)ppppuStack_14 == (uint *****)0xffffffff)) goto LAB_00884877;
      pppuStack_30 = (uint ***)0x0;
      pppuStack_2c = (uint ***)0xf;
      ppppuStack_40 = (uint ****)((uint)ppppuStack_40 & 0xffffff00);
      if (param_1[4] < ppppuVar11) break;
      ppppuVar6 = (uint ****)((int)ppppuStack_14 + (-1 - (int)ppppuStack_18));
      if (pppuStack_1c < ppppuVar6) {
        ppppuVar6 = (uint ****)pppuStack_1c;
      }
      pppppuVar7 = param_1;
      if ((uint ****)0xf < param_1[5]) {
        pppppuVar7 = (uint *****)*param_1;
      }
      FUN_005542c0((undefined *)((int)pppppuVar7 + (int)ppppuVar11),ppppuVar6);
      pppppuVar7 = &ppppuStack_40;
      if ((uint ****)0xf < pppuStack_2c) {
        pppppuVar7 = (uint *****)ppppuStack_40;
      }
      ppppuStack_18 = ppppuStack_40;
      uStack_8._0_1_ = 3;
      if (((uint ****)pppuStack_30 == (uint ****)0x0) ||
         (iVar5 = FUN_0170db20(pppppuVar7,0x26,pppuStack_30), iVar5 == 0)) {
        iVar5 = -1;
      }
      else {
        iVar5 = iVar5 - (int)pppppuVar7;
      }
      if (iVar5 != -1) {
        pppppuVar7 = (uint *****)FUN_00882bb0(aiStack_8c,&ppppuStack_40);
        if (&ppppuStack_40 != pppppuVar7) {
          if ((uint ****)0xf < pppuStack_2c) {
            ppppuVar11 = (uint ****)((int)pppuStack_2c + 1);
            pppppuVar15 = (uint *****)ppppuStack_40;
            if ((uint ****)0xfff < ppppuVar11) {
              pppppuVar15 = (uint *****)ppppuStack_40[-1];
              ppppuVar11 = (uint ****)(pppuStack_2c + 9);
              if ((undefined *)0x1f < (undefined *)((int)ppppuStack_40 + (-4 - (int)pppppuVar15)))
              goto LAB_00884872;
            }
            FUN_01674ea0(pppppuVar15,ppppuVar11);
          }
          ppppuStack_40 = *pppppuVar7;
          pppuStack_3c = (uint ***)pppppuVar7[1];
          pppuStack_38 = (uint ***)pppppuVar7[2];
          pppuStack_34 = (uint ***)pppppuVar7[3];
          pppuStack_30 = (uint ***)pppppuVar7[4];
          pppuStack_2c = (uint ***)pppppuVar7[5];
          pppppuVar7[4] = (uint ****)0x0;
          pppppuVar7[5] = (uint ****)0xf;
          *(undefined *)pppppuVar7 = 0;
        }
        if (0xf < uStack_78) {
          uVar12 = uStack_78 + 1;
          iVar5 = aiStack_8c[0];
          if (0xfff < uVar12) {
            iVar5 = *(int *)(aiStack_8c[0] + -4);
            uVar12 = uStack_78 + 0x24;
            if (0x1f < (aiStack_8c[0] - iVar5) - 4U) goto LAB_00884872;
          }
          FUN_01674ea0(iVar5,uVar12);
        }
        ppppuStack_18 = ppppuStack_40;
      }
      pppppuVar15 = (uint *****)((int)ppppuStack_14 + 1);
      puStack_24 = (undefined4 *)FUN_0086e830(auStack_74);
      ppppuStack_5c = (uint ****)&ppppuStack_40;
      if ((uint ****)0xf < pppuStack_2c) {
        ppppuStack_5c = ppppuStack_18;
      }
      pppuStack_48 = (uint ***)0x0;
      ppppuStack_44 = (uint ****)0x0;
      if (pppuStack_30 < (uint ****)0x10) {
        pppuStack_58 = *ppppuStack_5c;
        pppuStack_54 = (uint ***)((uint *****)ppppuStack_5c)[1];
        pppuStack_50 = (uint ***)((uint *****)ppppuStack_5c)[2];
        pppuStack_4c = (uint ***)((uint *****)ppppuStack_5c)[3];
        ppppuStack_14 = (uint ****)&DAT_0000000f;
        pppuStack_1c = pppuStack_58;
      }
      else {
        ppppuStack_14 = (uint ****)((uint)pppuStack_30 | 0xf);
        if ((uint *****)0x7fffffff < ppppuStack_14) {
          ppppuStack_14 = (uint ****)0x7fffffff;
        }
        pppppuVar7 = (uint *****)((int)ppppuStack_14 + 1);
        if (pppppuVar7 < &DAT_00001000) {
          if (pppppuVar7 == (uint *****)0x0) {
            pppuStack_58 = (uint ***)0x0;
          }
          else {
            pppuStack_58 = (uint ***)FUN_01674e20(pppppuVar7);
          }
        }
        else {
          pppppuVar13 = (uint *****)ppppuStack_14 + 9;
          if (pppppuVar13 <= pppppuVar7) {
            pppppuVar13 = (uint *****)0xffffffff;
          }
          pppuVar8 = (uint ***)FUN_01674e20(pppppuVar13);
          if (pppuVar8 == (uint ***)0x0) goto LAB_00884872;
          pppuStack_58 = (uint ***)((int)pppuVar8 + 0x23U & 0xffffffe0);
          ((uint ****)pppuStack_58)[-1] = pppuVar8;
        }
        pppuStack_1c = pppuStack_58;
        FUN_0170c6f0(pppuStack_58,ppppuStack_5c,(int)pppuStack_30 + 1);
      }
      uStack_8._0_1_ = 4;
      pppuStack_48 = pppuStack_30;
      ppppuStack_44 = ppppuStack_14;
      puStack_28 = (undefined4 *)FUN_01674e20(0x18);
      uStack_8._0_1_ = 5;
      if (puStack_28 == (undefined4 *)0x0) {
        puVar9 = (undefined4 *)0x0;
        ppppuVar11 = (uint ****)pppuStack_1c;
        pppppuVar7 = (uint *****)ppppuStack_14;
      }
      else {
        FUN_0054ef60(&pppuStack_58);
        uStack_8._0_1_ = 6;
        *puStack_28 = 0;
        puStack_28[2] = puStack_24;
        puStack_28[3] = 2;
        iStack_90 = FUN_01674e20(0x18);
        uStack_8._0_1_ = 7;
        if (iStack_90 == 0) {
          uVar4 = 0;
        }
        else {
          uVar4 = FUN_0054ef60(aiStack_8c);
        }
        uStack_8._0_1_ = 5;
        puStack_28[4] = uVar4;
        puVar9 = puStack_28;
        ppppuVar11 = (uint ****)pppuStack_58;
        pppppuVar7 = (uint *****)ppppuStack_44;
        if (0xf < uStack_78) {
          uVar12 = uStack_78 + 1;
          iVar5 = aiStack_8c[0];
          if (0xfff < uVar12) {
            iVar5 = *(int *)(aiStack_8c[0] + -4);
            uVar12 = uStack_78 + 0x24;
            if (0x1f < (aiStack_8c[0] - iVar5) - 4U) goto LAB_00884872;
          }
          FUN_01674ea0(iVar5,uVar12);
          puVar9 = puStack_28;
          ppppuVar11 = (uint ****)pppuStack_58;
          pppppuVar7 = (uint *****)ppppuStack_44;
        }
      }
      puStack_24 = (undefined4 *)puStack_20[9];
      if (puStack_24 == (undefined4 *)0x0) {
        puStack_20[8] = puVar9;
      }
      else {
        *puStack_24 = puVar9;
      }
      uStack_8._0_1_ = 3;
      puStack_20[9] = puVar9;
      if (&DAT_0000000f < pppppuVar7) {
        pppppuVar13 = (uint *****)((int)pppppuVar7 + 1);
        ppppuVar6 = ppppuVar11;
        if ((uint *****)0xfff < pppppuVar13) {
          ppppuVar6 = (uint ****)ppppuVar11[-1];
          pppppuVar13 = pppppuVar7 + 9;
          if ((undefined *)0x1f < (undefined *)((int)ppppuVar11 + (-4 - (int)ppppuVar6)))
          goto LAB_00884872;
        }
        FUN_01674ea0(ppppuVar6,pppppuVar13);
      }
      uStack_8._0_1_ = 2;
      if ((uint ****)0xf < pppuStack_2c) {
        ppppuVar11 = (uint ****)((int)pppuStack_2c + 1);
        pppppuVar7 = (uint *****)ppppuStack_18;
        if ((uint ****)0xfff < ppppuVar11) {
          pppppuVar7 = (uint *****)ppppuStack_18[-1];
          ppppuVar11 = (uint ****)(pppuStack_2c + 9);
          if ((undefined *)0x1f < (undefined *)((int)ppppuStack_18 + (-4 - (int)pppppuVar7)))
          goto LAB_00884872;
        }
        FUN_01674ea0(pppppuVar7,ppppuVar11);
      }
      uStack_8._0_1_ = 0;
      if (0xf < uStack_60) {
        uVar14 = uStack_60 + 1;
        uVar12 = auStack_74[0];
        if (0xfff < uVar14) {
          uVar12 = *(uint *)(auStack_74[0] - 4);
          uVar14 = uStack_60 + 0x24;
          if (0x1f < (auStack_74[0] - uVar12) - 4) goto LAB_00884872;
        }
        FUN_01674ea0(uVar12,uVar14);
      }
      uStack_64 = 0;
      uStack_60 = 0xf;
      auStack_74[0] = auStack_74[0] & 0xffffff00;
    } while( true );
  }
  FUN_00554050();
LAB_00884872:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 13698 ; VA 0x008848a0 ; FUN_008848a0 */

uint * __thiscall FUN_008848a0(int param_1,uint *param_2)

{
  int *piVar1;
  int iVar2;
  byte *pbVar3;
  char cVar4;
  uint uVar5;
  uint *puVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  char *pcVar11;
  undefined auStack_48 [24];
  undefined auStack_30 [12];
  undefined4 uStack_24;
  int iStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b9e51;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_24 = 0;
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  FUN_00886080();
  iVar8 = 0;
  do {
    piVar1 = *(int **)(param_1 + 4);
    if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
      uVar5 = (**(code **)(*piVar1 + 0x18))();
    }
    else {
      uVar5 = (uint)**(byte **)piVar1[7];
    }
    if (uVar5 == 0xffffffff) {
      pcVar11 = "Expected \'<\' but got EOF in Xml stream";
      goto LAB_00884b21;
    }
    if (4 < iVar8) {
      FUN_0054eff0("tag expected after Byte-Order-Mark");
      uStack_8 = 1;
      FUN_005500e0(auStack_48);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_30,&DAT_01c17198);
    }
    piVar1 = *(int **)(param_1 + 4);
    if (*(int *)piVar1[7] == 0) {
LAB_00884931:
      cVar4 = (**(code **)(*piVar1 + 0x1c))();
    }
    else {
      iVar2 = *(int *)piVar1[0xb];
      if (iVar2 < 1) goto LAB_00884931;
      *(int *)piVar1[0xb] = iVar2 + -1;
      pcVar11 = *(char **)piVar1[7];
      *(char **)piVar1[7] = pcVar11 + 1;
      cVar4 = *pcVar11;
    }
    iVar8 = iVar8 + 1;
  } while (cVar4 != '<');
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  uStack_8 = 0;
  uStack_24 = 1;
  FUN_00592760(0x3c);
  do {
    piVar1 = *(int **)(param_1 + 4);
    if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
      uVar5 = (**(code **)(*piVar1 + 0x18))();
    }
    else {
      uVar5 = (uint)**(byte **)piVar1[7];
    }
    if (uVar5 == 0xffffffff) goto LAB_00884b1c;
    piVar1 = *(int **)(param_1 + 4);
    if (*(int *)piVar1[7] == 0) {
LAB_008849b2:
      uStack_14 = (**(code **)(*piVar1 + 0x1c))();
    }
    else {
      iVar8 = *(int *)piVar1[0xb];
      if (iVar8 < 1) goto LAB_008849b2;
      *(int *)piVar1[0xb] = iVar8 + -1;
      pbVar3 = *(byte **)piVar1[7];
      *(byte **)piVar1[7] = pbVar3 + 1;
      uStack_14 = (uint)*pbVar3;
    }
    uStack_18 = param_2[4];
    uStack_1c = param_2[5];
    if (uStack_18 < uStack_1c) {
      param_2[4] = uStack_18 + 1;
      puVar6 = param_2;
      if (0xf < uStack_1c) {
        puVar6 = (uint *)*param_2;
      }
      cVar4 = (char)uStack_14;
      *(char *)((int)puVar6 + uStack_18) = cVar4;
      *(undefined *)((int)puVar6 + uStack_18 + 1) = 0;
    }
    else {
      if (uStack_18 == 0x7fffffff) {
        FUN_00554040();
LAB_00884b1c:
        pcVar11 = "Expected \'>\' but got EOF in Xml stream";
LAB_00884b21:
        FUN_00550130(pcVar11);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_30,&DAT_01c17198);
      }
      uVar5 = uStack_18 + 1 | 0xf;
      if (uVar5 < 0x80000000) {
        if (0x7fffffff - (uStack_1c >> 1) < uStack_1c) {
          uVar5 = 0x7fffffff;
        }
        else {
          uVar10 = (uStack_1c >> 1) + uStack_1c;
          if (uVar5 < uVar10) {
            uVar5 = uVar10;
          }
        }
      }
      else {
        uVar5 = 0x7fffffff;
      }
      uVar10 = uVar5 + 1;
      if (uVar10 < 0x1000) {
        if (uVar10 == 0) {
          uVar10 = 0;
        }
        else {
          uVar10 = FUN_01674e20(uVar10);
        }
      }
      else {
        uVar7 = uVar5 + 0x24;
        if (uVar7 <= uVar10) {
          uVar7 = 0xffffffff;
        }
        iVar8 = FUN_01674e20(uVar7);
        if (iVar8 == 0) goto LAB_00884b12;
        uVar10 = iVar8 + 0x23U & 0xffffffe0;
        *(int *)(uVar10 - 4) = iVar8;
      }
      param_2[4] = uStack_18 + 1;
      param_2[5] = uVar5;
      if (uStack_1c < 0x10) {
        FUN_0170c6f0(uVar10,param_2,uStack_18);
        cVar4 = (char)uStack_14;
        *(char *)(uVar10 + uStack_18) = cVar4;
        *(undefined *)(uVar10 + 1 + uStack_18) = 0;
      }
      else {
        uVar5 = *param_2;
        FUN_0170c6f0(uVar10,uVar5,uStack_18);
        *(char *)(uVar10 + uStack_18) = (char)uStack_14;
        uVar9 = uStack_1c + 1;
        *(undefined *)(uVar10 + 1 + uStack_18) = 0;
        uVar7 = uVar5;
        if (0xfff < uVar9) {
          uVar7 = *(uint *)(uVar5 - 4);
          uVar9 = uStack_1c + 0x24;
          if (0x1f < (uVar5 - uVar7) - 4) {
LAB_00884b12:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar7,uVar9);
        cVar4 = (char)uStack_14;
      }
      *param_2 = uVar10;
      param_1 = iStack_20;
    }
    if (cVar4 == '>') {
      ExceptionList = pvStack_10;
      return param_2;
    }
  } while( true );
}



/* FUNCTION 13699 ; VA 0x00884b70 ; FUN_00884b70 */

int * __thiscall FUN_00884b70(int param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  byte *pbVar3;
  code *pcVar4;
  char cVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  int iVar9;
  char *pcVar10;
  undefined auStack_30 [12];
  undefined4 uStack_24;
  int iStack_20;
  uint uStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b9e79;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_24 = 0;
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  FUN_00886080();
  piVar7 = *(int **)(param_1 + 4);
  if ((*(byte **)piVar7[7] == (byte *)0x0) || (*(int *)piVar7[0xb] < 1)) {
    uVar6 = (**(code **)(*piVar7 + 0x18))();
  }
  else {
    uVar6 = (uint)**(byte **)piVar7[7];
  }
  if (uVar6 == 0xffffffff) {
    pcVar10 = "EOF encountered while reading Tag start";
    goto LAB_00884da4;
  }
  piVar7 = *(int **)(param_1 + 4);
  if (*(int *)piVar7[7] == 0) {
LAB_00884bf3:
    cVar5 = (**(code **)(*piVar7 + 0x1c))();
  }
  else {
    iVar2 = *(int *)piVar7[0xb];
    if (iVar2 < 1) goto LAB_00884bf3;
    *(int *)piVar7[0xb] = iVar2 + -1;
    pcVar10 = *(char **)piVar7[7];
    *(char **)piVar7[7] = pcVar10 + 1;
    cVar5 = *pcVar10;
  }
  if (cVar5 == '<') {
    param_2[4] = 0;
    param_2[5] = 0xf;
    *(undefined *)param_2 = 0;
    uStack_8 = 0;
    uStack_24 = 1;
    FUN_00592760(0x3c);
    while( true ) {
      piVar7 = *(int **)(param_1 + 4);
      if ((*(byte **)piVar7[7] == (byte *)0x0) || (*(int *)piVar7[0xb] < 1)) {
        uVar6 = (**(code **)(*piVar7 + 0x18))();
      }
      else {
        uVar6 = (uint)**(byte **)piVar7[7];
      }
      if (uVar6 == 0xffffffff) break;
      piVar7 = *(int **)(param_1 + 4);
      if (*(int *)piVar7[7] == 0) {
LAB_00884c7e:
        uStack_14 = (**(code **)(*piVar7 + 0x1c))();
      }
      else {
        iVar2 = *(int *)piVar7[0xb];
        if (iVar2 < 1) goto LAB_00884c7e;
        *(int *)piVar7[0xb] = iVar2 + -1;
        pbVar3 = *(byte **)piVar7[7];
        *(byte **)piVar7[7] = pbVar3 + 1;
        uStack_14 = (uint)*pbVar3;
      }
      uStack_1c = param_2[5];
      uVar6 = param_2[4];
      if (uVar6 < uStack_1c) {
        param_2[4] = uVar6 + 1;
        piVar7 = param_2;
        if (0xf < uStack_1c) {
          piVar7 = (int *)*param_2;
        }
        cVar5 = (char)uStack_14;
        *(char *)((int)piVar7 + uVar6) = cVar5;
        *(undefined *)((int)piVar7 + uVar6 + 1) = 0;
      }
      else {
        if (uVar6 == 0x7fffffff) {
          FUN_00554040();
          pcVar4 = (code *)swi(3);
          piVar7 = (int *)(*pcVar4)();
          return piVar7;
        }
        uVar8 = uVar6 + 1 | 0xf;
        if (uVar8 < 0x80000000) {
          if (0x7fffffff - (uStack_1c >> 1) < uStack_1c) {
            uVar8 = 0x7fffffff;
          }
          else {
            uVar1 = (uStack_1c >> 1) + uStack_1c;
            if (uVar8 < uVar1) {
              uVar8 = uVar1;
            }
          }
        }
        else {
          uVar8 = 0x7fffffff;
        }
        iStack_18 = FUN_00554060(uVar8 + 1);
        param_2[4] = uVar6 + 1;
        param_2[5] = uVar8;
        if (uStack_1c < 0x10) {
          FUN_0170c6f0(iStack_18,param_2,uVar6);
          cVar5 = (char)uStack_14;
          *(char *)(iStack_18 + uVar6) = cVar5;
          *(undefined *)(iStack_18 + 1 + uVar6) = 0;
        }
        else {
          iVar2 = *param_2;
          FUN_0170c6f0(iStack_18,iVar2,uVar6);
          *(char *)(iStack_18 + uVar6) = (char)uStack_14;
          uVar8 = uStack_1c + 1;
          *(undefined *)(iStack_18 + 1 + uVar6) = 0;
          iVar9 = iVar2;
          if (0xfff < uVar8) {
            iVar9 = *(int *)(iVar2 + -4);
            uVar8 = uStack_1c + 0x24;
            if (0x1f < (iVar2 - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar9,uVar8);
          cVar5 = (char)uStack_14;
        }
        *param_2 = iStack_18;
        param_1 = iStack_20;
      }
      if (cVar5 == '>') {
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    pcVar10 = "EOF encountered while reading Tag";
  }
  else {
    pcVar10 = "tag expected";
  }
LAB_00884da4:
  FUN_00550130(pcVar10);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c17198);
}



/* FUNCTION 13700 ; VA 0x00884dd0 ; FUN_00884dd0 */

/* WARNING: Type propagation algorithm not settling */

undefined4 * __thiscall FUN_00884dd0(int param_1,undefined4 *param_2,char param_3)

{
  uint uVar1;
  byte bVar2;
  int *piVar3;
  undefined *puVar4;
  byte *pbVar5;
  code *pcVar6;
  undefined uVar7;
  uint uVar8;
  undefined4 *******pppppppuVar9;
  int iVar10;
  undefined4 *puVar11;
  uint uVar12;
  undefined4 ******ppppppuVar13;
  undefined4 *******pppppppuVar14;
  char cStack0000000a;
  undefined auStack_150 [156];
  int aiStack_b4 [4];
  uint auStack_a4 [3];
  undefined **appuStack_98 [8];
  int aiStack_78 [10];
  undefined8 uStack_50;
  char cStack_48;
  int iStack_44;
  int *piStack_40;
  byte *pbStack_3c;
  uint uStack_38;
  undefined4 *******pppppppuStack_34;
  undefined4 *******pppppppuStack_30;
  int iStack_2c;
  uint uStack_28;
  int iStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9ece;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_44 = param_1;
  FUN_0054edc0(*(undefined4 *)(param_1 + 4),0,1);
  uStack_8 = 0;
  piStack_40 = aiStack_b4 + 1;
  piVar3 = *(int **)((int)aiStack_78 + *(int *)(aiStack_b4[1] + 4));
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 4))();
  }
  uStack_8._0_1_ = 1;
  uVar7 = FUN_00593b40(1);
  pbStack_3c = (byte *)CONCAT31(pbStack_3c._1_3_,uVar7);
  uStack_8._0_1_ = 2;
  if ((*(byte *)((int)auStack_a4 + *(int *)(aiStack_b4[1] + 4)) & 6) == 0) {
    (**(code **)(**(int **)((int)aiStack_78 + *(int *)(aiStack_b4[1] + 4)) + 0x28))
              (&pppppppuStack_30,0,0,1,1);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
  }
  else {
    pppppppuStack_30 = (undefined4 *******)0xffffffff;
    iStack_2c = -1;
    uStack_28 = 0;
    iStack_24 = 0;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
  }
  piVar3 = *(int **)((int)aiStack_78 + *(int *)(aiStack_b4[1] + 4));
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 8))();
  }
  ppppppuVar13 = (undefined4 ******)((int)pppppppuStack_30 + uStack_28);
  uStack_50 = 0;
  cStack_48 = '\0';
  uStack_8 = uStack_8 & 0xffffff00;
  (**(code **)(**(int **)(param_1 + 4) + 0x20))(&uStack_50,9,0);
  if ((((int)uStack_50 != *(int *)PTR_DAT_01d62928) ||
      (uStack_50._4_4_ != *(int *)(PTR_DAT_01d62928 + 4))) || (cStack_48 != PTR_DAT_01d62928[8])) {
    pppppppuStack_30 = (undefined4 *******)ppppppuVar13;
    iStack_2c = 0;
    uStack_28 = 0;
    iStack_24 = 0;
    uStack_20 = 0;
    uStack_1c = 0;
    uVar12 = *(uint *)((int)auStack_a4 + *(int *)(aiStack_b4[1] + 4)) & 0xfffffffe;
    uVar8 = uVar12 | 4;
    if (*(int *)((int)aiStack_78 + *(int *)(aiStack_b4[1] + 4)) != 0) {
      uVar8 = uVar12;
    }
    FUN_00554460(uVar8,0);
    piStack_40 = aiStack_b4 + 1;
    piVar3 = *(int **)((int)aiStack_78 + *(int *)(aiStack_b4[1] + 4));
    if (piVar3 != (int *)0x0) {
      (**(code **)(*piVar3 + 4))();
    }
    uStack_8._0_1_ = 7;
    uVar7 = FUN_00593b40(1);
    pbStack_3c = (byte *)CONCAT31(pbStack_3c._1_3_,uVar7);
    uStack_8._0_1_ = 8;
    if (((*(byte *)((int)auStack_a4 + *(int *)(aiStack_b4[1] + 4)) & 6) == 0) &&
       ((**(code **)(**(int **)((int)aiStack_78 + *(int *)(aiStack_b4[1] + 4)) + 0x2c))
                  (&pppppppuStack_30,pppppppuStack_30,iStack_2c,uStack_28,iStack_24,uStack_20,
                   uStack_1c,1),
       ((int)pppppppuStack_30 + uStack_28 &
       iStack_2c + iStack_24 + (uint)CARRY4((uint)pppppppuStack_30,uStack_28)) == 0xffffffff)) {
      FUN_00554460((uint)(*(int *)((int)aiStack_78 + *(int *)(aiStack_b4[1] + 4)) == 0) * 4 + 2 |
                   *(uint *)((int)auStack_a4 + *(int *)(aiStack_b4[1] + 4)),0);
    }
    uStack_8._0_1_ = 9;
    piVar3 = *(int **)((int)aiStack_78 + *(int *)(aiStack_b4[1] + 4));
    if (piVar3 != (int *)0x0) {
      (**(code **)(*piVar3 + 8))();
    }
    uStack_8._0_1_ = 0;
    FUN_00886080();
    uStack_20 = 0;
    uStack_1c = 0xf;
    pppppppuStack_30 = (undefined4 *******)((uint)pppppppuStack_30 & 0xffffff00);
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    uVar8 = uStack_1c;
    uStack_38 = uStack_20;
LAB_0088522b:
    do {
      pppppppuVar14 = pppppppuStack_30;
      piVar3 = *(int **)(iStack_44 + 4);
      pbStack_3c = *(byte **)piVar3[7];
      pppppppuStack_34 = pppppppuStack_30;
      if ((pbStack_3c == (byte *)0x0) || (*(int *)piVar3[0xb] < 1)) {
        uVar12 = (**(code **)(*piVar3 + 0x18))();
      }
      else {
        uVar12 = (uint)*pbStack_3c;
      }
      if ((uVar12 == 0xffffffff) || ((char)uVar12 == '<')) {
        if (param_3 != '\0') {
          pppppppuVar9 = &pppppppuStack_30;
          if (0xf < uVar8) {
            pppppppuVar9 = pppppppuVar14;
          }
          if (((uStack_38 != 0) && (iVar10 = FUN_0170db20(pppppppuVar9,0x26,uStack_38), iVar10 != 0)
              ) && (iVar10 - (int)pppppppuVar9 != -1)) {
            FUN_00882bb0(param_2,&pppppppuStack_30);
            FUN_005507b0();
            FUN_00551680();
            ExceptionList = pvStack_10;
            return param_2;
          }
        }
        pppppppuVar14 = pppppppuStack_30;
        pppppppuStack_30 = (undefined4 *******)((uint)pppppppuStack_30 & 0xffffff00);
        param_2[4] = 0;
        param_2[5] = 0;
        *param_2 = pppppppuVar14;
        param_2[1] = iStack_2c;
        param_2[2] = uStack_28;
        param_2[3] = iStack_24;
        *(ulonglong *)(param_2 + 4) = CONCAT44(uStack_1c,uStack_20);
        uStack_20 = 0;
        uStack_1c = 0xf;
        FUN_005507b0();
        *(undefined ***)((int)aiStack_b4 + *(int *)(aiStack_b4[1] + 4) + 4U) =
             std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
        *(int *)((int)aiStack_b4 + *(int *)(aiStack_b4[1] + 4)) =
             *(int *)(aiStack_b4[1] + 4) + -0x18;
        uStack_8 = 0xb;
        goto LAB_008854c1;
      }
      piVar3 = *(int **)(iStack_44 + 4);
      if (*(int *)piVar3[7] == 0) {
LAB_00885293:
        uStack_18 = (**(code **)(*piVar3 + 0x1c))();
      }
      else {
        iVar10 = *(int *)piVar3[0xb];
        if (iVar10 < 1) goto LAB_00885293;
        *(int *)piVar3[0xb] = iVar10 + -1;
        pbVar5 = *(byte **)piVar3[7];
        *(byte **)piVar3[7] = pbVar5 + 1;
        uStack_18 = (uint)*pbVar5;
      }
      if (uStack_38 < uVar8) {
        uStack_20 = uStack_38 + 1;
        pppppppuVar9 = &pppppppuStack_30;
        if (0xf < uVar8) {
          pppppppuVar9 = pppppppuVar14;
        }
        *(char *)((int)pppppppuVar9 + uStack_38) = (char)uStack_18;
        *(undefined *)((int)pppppppuVar9 + uStack_38 + 1) = 0;
        uVar8 = uStack_1c;
        uStack_38 = uStack_20;
        goto LAB_0088522b;
      }
      uStack_14 = uStack_38;
      if (uStack_38 == 0x7fffffff) {
        FUN_00554040();
        pcVar6 = (code *)swi(3);
        puVar11 = (undefined4 *)(*pcVar6)();
        return puVar11;
      }
      uStack_38 = uStack_38 + 1;
      uVar12 = uStack_38 | 0xf;
      if (uVar12 < 0x80000000) {
        if (0x7fffffff - (uVar8 >> 1) < uVar8) {
          uVar12 = 0x7fffffff;
        }
        else {
          uVar1 = uVar8 + (uVar8 >> 1);
          if (uVar12 < uVar1) {
            uVar12 = uVar1;
          }
        }
      }
      else {
        uVar12 = 0x7fffffff;
      }
      uVar1 = uVar12 + 1;
      pbStack_3c = (byte *)uVar8;
      if (uVar1 < 0x1000) {
        if (uVar1 == 0) {
          pppppppuVar14 = (undefined4 *******)0x0;
        }
        else {
          pppppppuVar14 = (undefined4 *******)FUN_01674e20(uVar1);
        }
      }
      else {
        uVar8 = uVar12 + 0x24;
        if (uVar8 <= uVar1) {
          uVar8 = 0xffffffff;
        }
        ppppppuVar13 = (undefined4 ******)FUN_01674e20(uVar8);
        if (ppppppuVar13 == (undefined4 ******)0x0) {
LAB_008854ee:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
        pppppppuVar14 = (undefined4 *******)((int)ppppppuVar13 + 0x23U & 0xffffffe0);
        pppppppuVar14[-1] = ppppppuVar13;
      }
      uStack_20 = uStack_38;
      uVar8 = uVar12;
      uStack_1c = uVar12;
      if (pbStack_3c < 0x10) {
        FUN_0170c6f0(pppppppuVar14,&pppppppuStack_30,uStack_14);
        *(char *)(uStack_14 + (int)pppppppuVar14) = (char)uStack_18;
        *(undefined *)(uStack_14 + 1 + (int)pppppppuVar14) = 0;
        pppppppuStack_30 = pppppppuVar14;
      }
      else {
        FUN_0170c6f0(pppppppuVar14,pppppppuStack_34,uStack_14);
        uVar12 = (int)pbStack_3c + 1;
        *(char *)(uStack_14 + (int)pppppppuVar14) = (char)uStack_18;
        *(undefined *)(uStack_14 + 1 + (int)pppppppuVar14) = 0;
        pppppppuVar9 = pppppppuStack_34;
        if (0xfff < uVar12) {
          pppppppuVar9 = (undefined4 *******)pppppppuStack_34[-1];
          uVar12 = (int)pbStack_3c + 0x24;
          if (0x1f < (uint)((int)pppppppuStack_34 + (-4 - (int)pppppppuVar9))) goto LAB_008854ee;
        }
        FUN_01674ea0(pppppppuVar9,uVar12);
        pppppppuStack_30 = pppppppuVar14;
      }
    } while( true );
  }
  piVar3 = *(int **)(param_1 + 4);
  if (*(int *)piVar3[7] == 0) {
LAB_00884f1a:
    uVar7 = (**(code **)(*piVar3 + 0x1c))();
  }
  else {
    iVar10 = *(int *)piVar3[0xb];
    if (iVar10 < 1) goto LAB_00884f1a;
    *(int *)piVar3[0xb] = iVar10 + -1;
    puVar4 = *(undefined **)piVar3[7];
    *(undefined **)piVar3[7] = puVar4 + 1;
    uVar7 = *puVar4;
  }
  piVar3 = *(int **)(param_1 + 4);
  if (*(int *)piVar3[7] == 0) {
LAB_00884f4a:
    uStack_18 = (**(code **)(*piVar3 + 0x1c))();
  }
  else {
    iVar10 = *(int *)piVar3[0xb];
    if (iVar10 < 1) goto LAB_00884f4a;
    *(int *)piVar3[0xb] = iVar10 + -1;
    pbVar5 = *(byte **)piVar3[7];
    *(byte **)piVar3[7] = pbVar5 + 1;
    uStack_18 = (uint)*pbVar5;
  }
  piVar3 = *(int **)(param_1 + 4);
  _param_3 = CONCAT11((char)uStack_18,uVar7);
  if (*(int *)piVar3[7] != 0) {
    iVar10 = *(int *)piVar3[0xb];
    if (0 < iVar10) {
      *(int *)piVar3[0xb] = iVar10 + -1;
      pbVar5 = *(byte **)piVar3[7];
      *(byte **)piVar3[7] = pbVar5 + 1;
      uStack_14 = (uint)*pbVar5;
      goto LAB_00884f86;
    }
  }
  uStack_14 = (**(code **)(*piVar3 + 0x1c))();
LAB_00884f86:
  _param_3 = CONCAT12((char)uStack_14,_param_3);
  _param_3 = (uint)_param_3;
  FUN_00565940(3,1);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  while( true ) {
    piVar3 = *(int **)(param_1 + 4);
    if ((*(byte **)piVar3[7] == (byte *)0x0) || (*(int *)piVar3[0xb] < 1)) {
      uVar8 = (**(code **)(*piVar3 + 0x18))();
    }
    else {
      uVar8 = (uint)**(byte **)piVar3[7];
    }
    if ((uVar8 == 0xffffffff) ||
       ((_param_3 == *(short *)PTR_DAT_01d6292c && (cStack0000000a == PTR_DAT_01d6292c[2])))) break;
    FUN_005ed940(auStack_150,_param_3);
    piVar3 = *(int **)(param_1 + 4);
    uVar7 = (undefined)uStack_18;
    uStack_18 = CONCAT31((int3)(uStack_18 >> 8),(undefined)uStack_14);
    _param_3 = CONCAT11((undefined)uStack_14,uVar7);
    if (*(int *)piVar3[7] == 0) {
LAB_0088502f:
      uStack_14 = (**(code **)(*piVar3 + 0x1c))();
      _param_3 = CONCAT12((char)uStack_14,_param_3);
      _param_3 = (uint)_param_3;
    }
    else {
      iVar10 = *(int *)piVar3[0xb];
      if (iVar10 < 1) goto LAB_0088502f;
      *(int *)piVar3[0xb] = iVar10 + -1;
      pbVar5 = *(byte **)piVar3[7];
      *(byte **)piVar3[7] = pbVar5 + 1;
      bVar2 = *pbVar5;
      uStack_14 = (uint)bVar2;
      _param_3 = CONCAT12(bVar2,_param_3);
      _param_3 = (uint)_param_3;
    }
  }
  while( true ) {
    piVar3 = *(int **)(param_1 + 4);
    if ((*(byte **)piVar3[7] == (byte *)0x0) || (*(int *)piVar3[0xb] < 1)) {
      uVar8 = (**(code **)(*piVar3 + 0x18))();
    }
    else {
      uVar8 = (uint)**(byte **)piVar3[7];
    }
    if (uVar8 == 0x3c) break;
    piVar3 = *(int **)(param_1 + 4);
    if ((*(byte **)piVar3[7] == (byte *)0x0) || (*(int *)piVar3[0xb] < 1)) {
      uVar8 = (**(code **)(*piVar3 + 0x18))();
    }
    else {
      uVar8 = (uint)**(byte **)piVar3[7];
    }
    if (uVar8 == 0xffffffff) break;
    piVar3 = *(int **)(param_1 + 4);
    if (*(int *)piVar3[7] == 0) {
LAB_008850a9:
      (**(code **)(*piVar3 + 0x1c))();
    }
    else {
      iVar10 = *(int *)piVar3[0xb];
      if (iVar10 < 1) goto LAB_008850a9;
      *(int *)piVar3[0xb] = iVar10 + -1;
      *(int *)piVar3[7] = *(int *)piVar3[7] + 1;
    }
  }
  FUN_0058c4d0(param_2);
  FUN_005705c0();
  *(undefined ***)((int)aiStack_b4 + *(int *)(aiStack_b4[1] + 4) + 4U) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)((int)aiStack_b4 + *(int *)(aiStack_b4[1] + 4)) = *(int *)(aiStack_b4[1] + 4) + -0x18;
  uStack_8 = 6;
LAB_008854c1:
  appuStack_98[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_98);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 13701 ; VA 0x00885500 ; FUN_00885500 */

void __thiscall FUN_00885500(int param_1,int param_2,int param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  
  if (param_2 != 0) {
    FUN_008855b0(param_2,param_3);
    piVar1 = *(int **)(param_2 + 4);
    if (piVar1 == (int *)0x0) {
      iVar2 = 0;
    }
    else {
      do {
        FUN_005ed940(*(undefined4 *)(param_1 + 0x24),10);
        FUN_00885500(piVar1,param_3 + 1,0);
        piVar1 = (int *)*piVar1;
      } while (piVar1 != (int *)0x0);
      FUN_005ed940(*(undefined4 *)(param_1 + 0x24),10);
      iVar2 = param_3;
    }
    if ((param_3 == 0) && (param_4 != 0)) {
      FUN_008858c0(param_4);
    }
    FUN_008860e0(param_2,iVar2);
  }
  return;
}



/* FUNCTION 13702 ; VA 0x00885590 ; FUN_00885590 */

void FUN_00885590(undefined4 param_1,undefined4 param_2)

{
  FUN_00885500(param_1,0,param_2);
  return;
}



/* FUNCTION 13703 ; VA 0x008855b0 ; FUN_008855b0 */

/* WARNING: Type propagation algorithm not settling */

void __thiscall FUN_008855b0(int param_1,undefined4 param_2,undefined4 param_3)

{
  uint uVar1;
  byte *pbVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  byte *pbVar6;
  undefined4 uVar7;
  char *******pppppppcVar8;
  undefined4 *puVar9;
  char *******pppppppcVar10;
  uint uVar11;
  byte *pbVar12;
  uint uVar13;
  bool bVar14;
  char *pcVar15;
  char *******apppppppcStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  char *******apppppppcStack_34 [4];
  int iStack_24;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9ef8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar3 = FUN_0087ca40();
  if (cVar3 != '\0') {
    iStack_24 = 0;
    uStack_20 = 0xf;
    apppppppcStack_34[0] = (char *******)((uint)apppppppcStack_34[0] & 0xffffff00);
    iStack_8 = 0;
    FUN_0087d0d0(apppppppcStack_34);
    FUN_00886140(param_2,param_3);
    iVar4 = FUN_0087cdb0(DAT_01ede588);
    if (iVar4 == 0) {
      if (iStack_24 == 0) {
        pcVar15 = "<null></null>";
      }
      else {
        FUN_00558890(*(undefined4 *)(param_1 + 0x24),"<url>");
        uStack_3c = 0;
        uStack_38 = 0xf;
        pppppppcVar10 = (char *******)apppppppcStack_34;
        if (0xf < uStack_20) {
          pppppppcVar10 = apppppppcStack_34[0];
        }
        apppppppcStack_4c[0] = (char *******)((uint)apppppppcStack_4c[0] & 0xffffff00);
        pppppppcVar8 = pppppppcVar10;
        do {
          cVar3 = *(char *)pppppppcVar8;
          pppppppcVar8 = (char *******)((int)pppppppcVar8 + 1);
        } while (cVar3 != '\0');
        FUN_005542c0(pppppppcVar10,(int)pppppppcVar8 - (int)((int)pppppppcVar10 + 1));
        iStack_8._0_1_ = 1;
        FUN_00886290(*(undefined4 *)(param_1 + 0x24),apppppppcStack_4c);
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_005507b0();
        pcVar15 = "</url>";
      }
      FUN_00558890(*(undefined4 *)(param_1 + 0x24),pcVar15);
    }
    if (uStack_20 < 0x10) {
      ExceptionList = pvStack_10;
      return;
    }
    uVar11 = uStack_20 + 1;
    pppppppcVar10 = apppppppcStack_34[0];
    if (0xfff < uVar11) {
      pppppppcVar10 = (char *******)apppppppcStack_34[0][-1];
      uVar11 = uStack_20 + 0x24;
      if ((char *)0x1f < (char *)((int)apppppppcStack_34[0] + (-4 - (int)pppppppcVar10))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    goto LAB_00885892;
  }
  FUN_00886140(param_2,param_3);
  puVar5 = (undefined4 *)FUN_0087d5f0(apppppppcStack_4c,param_1);
  uStack_14 = *(undefined4 *)(param_1 + 0x24);
  uVar11 = puVar5[4];
  iStack_8 = 2;
  puVar9 = puVar5;
  if (0xf < (uint)puVar5[5]) {
    puVar9 = (undefined4 *)*puVar5;
  }
  if (((uVar11 == 0) ||
      (iVar4 = FUN_0170db20(puVar9,10,uVar11), pbVar12 = PTR_DAT_01d6292c, iVar4 == 0)) ||
     (iVar4 - (int)puVar9 == -1)) {
LAB_00885860:
    FUN_00886290(uStack_14,puVar5);
  }
  else {
    pcVar15 = PTR_DAT_01d6292c;
    do {
      cVar3 = *pcVar15;
      pcVar15 = pcVar15 + 1;
    } while (cVar3 != '\0');
    uVar13 = (int)pcVar15 - (int)(PTR_DAT_01d6292c + 1);
    puVar9 = puVar5;
    if (0xf < (uint)puVar5[5]) {
      puVar9 = (undefined4 *)*puVar5;
    }
    if (uVar13 <= uVar11) {
      if (uVar13 == 0) goto LAB_00885860;
      iStack_18 = (uVar11 - uVar13) + 1 + (int)puVar9;
      iStack_1c = (int)(char)*PTR_DAT_01d6292c;
      pbVar6 = (byte *)FUN_0170db20(puVar9,iStack_1c,iStack_18 - (int)puVar9);
      while (pbVar2 = pbVar6, uVar11 = uVar13, pbVar6 != (byte *)0x0) {
        while (uVar1 = uVar11 - 4, 3 < uVar11) {
          if (*(int *)pbVar2 != *(int *)pbVar12) goto LAB_008857c6;
          pbVar12 = pbVar12 + 4;
          pbVar2 = pbVar2 + 4;
          uVar11 = uVar1;
        }
        if (uVar1 == 0xfffffffc) {
LAB_008857fa:
          uVar11 = 0;
        }
        else {
LAB_008857c6:
          bVar14 = *pbVar2 < *pbVar12;
          if ((*pbVar2 == *pbVar12) &&
             ((uVar1 == 0xfffffffd ||
              ((bVar14 = pbVar2[1] < pbVar12[1], pbVar2[1] == pbVar12[1] &&
               ((uVar1 == 0xfffffffe ||
                ((bVar14 = pbVar2[2] < pbVar12[2], pbVar2[2] == pbVar12[2] &&
                 ((uVar1 == 0xffffffff || (bVar14 = pbVar2[3] < pbVar12[3], pbVar2[3] == pbVar12[3])
                  ))))))))))) goto LAB_008857fa;
          uVar11 = -(uint)bVar14 | 1;
        }
        if (uVar11 == 0) {
          if ((int)pbVar6 - (int)puVar9 != -1) goto LAB_00885860;
          break;
        }
        pbVar6 = (byte *)FUN_0170db20(pbVar6 + 1,iStack_1c,iStack_18 - (int)(pbVar6 + 1));
        pbVar12 = PTR_DAT_01d6292c;
      }
    }
    uVar7 = FUN_00558890(uStack_14,PTR_DAT_01d62928);
    if (0xf < (uint)puVar5[5]) {
      puVar5 = (undefined4 *)*puVar5;
    }
    uVar7 = FUN_00558890(uVar7,puVar5);
    FUN_00558890(uVar7,PTR_DAT_01d6292c);
  }
  if (uStack_38 < 0x10) {
    ExceptionList = pvStack_10;
    return;
  }
  uVar11 = uStack_38 + 1;
  pppppppcVar10 = apppppppcStack_4c[0];
  if (0xfff < uVar11) {
    pppppppcVar10 = (char *******)apppppppcStack_4c[0][-1];
    uVar11 = uStack_38 + 0x24;
    if ((char *)0x1f < (char *)((int)apppppppcStack_4c[0] + (-4 - (int)pppppppcVar10))) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
LAB_00885892:
  FUN_01674ea0(pppppppcVar10,uVar11);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13704 ; VA 0x008858c0 ; FUN_008858c0 */

/* WARNING: Type propagation algorithm not settling */

void __thiscall FUN_008858c0(int param_1,uint param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *******pppppppuVar4;
  uint uVar5;
  uint *****pppppuVar6;
  undefined4 uVar7;
  undefined4 *******pppppppuVar8;
  uint uVar9;
  uint *******pppppppuVar10;
  undefined4 ******ppppppuVar11;
  uint uVar12;
  uint ******ppppppuVar13;
  uint ******ppppppuVar14;
  int iStack_190;
  undefined4 auStack_158 [26];
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 *puStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  uint uStack_c8;
  int iStack_c0;
  undefined4 *puStack_bc;
  int aiStack_b8 [5];
  uint uStack_a4;
  undefined4 uStack_a0;
  undefined4 *puStack_9c;
  undefined4 uStack_98;
  undefined4 *puStack_90;
  undefined4 uStack_8c;
  undefined4 *puStack_80;
  undefined4 *puStack_7c;
  uint ******ppppppuStack_78;
  uint ******ppppppuStack_74;
  uint ******ppppppuStack_70;
  uint ******ppppppuStack_6c;
  uint uStack_68;
  uint uStack_64;
  undefined4 uStack_60;
  uint *******pppppppuStack_5c;
  uint *******apppppppuStack_58 [4];
  uint uStack_48;
  uint uStack_44;
  undefined4 *******pppppppuStack_40;
  undefined4 ******ppppppuStack_3c;
  undefined4 ******ppppppuStack_38;
  undefined4 ******ppppppuStack_34;
  undefined4 ******ppppppuStack_30;
  undefined4 ******ppppppuStack_2c;
  int iStack_28;
  uint uStack_24;
  int iStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar9 = param_2;
  puStack_c = &LAB_017b9f80;
  pvStack_10 = ExceptionList;
  uVar12 = *(uint *)(param_2 + 8);
  if (uVar12 == 0) {
    return;
  }
  iStack_20 = 0;
  iStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_28 = param_1;
  if (uVar12 != 0) {
    if (0x3fffffff < uVar12) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    ExceptionList = &pvStack_10;
    FUN_006c8e30(uVar12);
    if (*(int *)(uVar9 + 8) != 0) {
      uVar7 = *(undefined4 *)(*(int *)(uVar9 + 0x14) + *(int *)(uVar9 + 4) * 4);
      goto LAB_00885934;
    }
  }
  uVar7 = 0;
LAB_00885934:
  param_2 = param_2 & 0xffffff00;
  FUN_006c6bf0(iStack_1c,uVar7,0,param_2);
  iVar2 = iStack_20;
  iStack_14 = iStack_20;
  FUN_00882320(iStack_20,iStack_1c,iStack_1c - iStack_20 >> 2,param_2);
  uStack_f0 = 0;
  uStack_ec = 0;
  uStack_e8 = 0;
  puStack_e0 = DAT_01ede67c;
  uStack_dc = 0;
  uStack_d0 = 0;
  uStack_cc = 0;
  uStack_8._0_1_ = 1;
  FUN_00886140(&uStack_f0,1);
  FUN_005ed940(*(undefined4 *)(param_1 + 0x24),10);
  if (iVar2 != iStack_1c) {
    do {
      ppppppuStack_30 = (undefined4 ******)0x0;
      ppppppuStack_2c = (undefined4 ******)0xf;
      pppppppuStack_40 = (undefined4 *******)((uint)pppppppuStack_40 & 0xffffff00);
      uStack_8._0_1_ = 2;
      iVar2 = FUN_00a33fa0();
      iVar2 = *(int *)(iVar2 + 0x10);
      puVar3 = (undefined4 *)FUN_00a33fa0();
      if (0xf < (uint)puVar3[5]) {
        puVar3 = (undefined4 *)*puVar3;
      }
      FUN_00565940(3,1);
      uStack_c8 = uStack_c8 & 0xffffff00;
      uStack_8._0_1_ = 3;
      FUN_008825f0(puVar3,(int)puVar3 + iVar2,uStack_c8,
                   *(undefined4 *)((int)auStack_158 + *(int *)(iStack_190 + 4)),&param_2,param_2);
      pppppppuVar4 = (undefined4 *******)FUN_0058c4d0(aiStack_b8);
      if (&pppppppuStack_40 != (undefined4 ********)pppppppuVar4) {
        if ((undefined4 ******)0xf < ppppppuStack_2c) {
          ppppppuVar11 = (undefined4 ******)((int)ppppppuStack_2c + 1);
          pppppppuVar8 = pppppppuStack_40;
          if ((undefined4 ******)0xfff < ppppppuVar11) {
            pppppppuVar8 = (undefined4 *******)pppppppuStack_40[-1];
            ppppppuVar11 = ppppppuStack_2c + 9;
            if (0x1f < (uint)((int)pppppppuStack_40 + (-4 - (int)pppppppuVar8))) goto LAB_00885f20;
          }
          FUN_01674ea0(pppppppuVar8,ppppppuVar11);
        }
        pppppppuStack_40 = (undefined4 *******)*pppppppuVar4;
        ppppppuStack_3c = pppppppuVar4[1];
        ppppppuStack_38 = pppppppuVar4[2];
        ppppppuStack_34 = pppppppuVar4[3];
        ppppppuStack_30 = pppppppuVar4[4];
        ppppppuStack_2c = pppppppuVar4[5];
        pppppppuVar4[4] = (undefined4 ******)0x0;
        pppppppuVar4[5] = (undefined4 ******)0xf;
        *(undefined *)pppppppuVar4 = 0;
      }
      if (0xf < uStack_a4) {
        uVar12 = uStack_a4 + 1;
        iVar2 = aiStack_b8[0];
        if (0xfff < uVar12) {
          iVar2 = *(int *)(aiStack_b8[0] + -4);
          uVar12 = uStack_a4 + 0x24;
          if (0x1f < (aiStack_b8[0] - iVar2) - 4U) goto LAB_00885f20;
        }
        FUN_01674ea0(iVar2,uVar12);
      }
      FUN_005705c0();
      uStack_48 = 0;
      uStack_44 = 0xf;
      apppppppuStack_58[0] = (uint *******)((uint)apppppppuStack_58[0] & 0xffffff00);
      uStack_8._0_1_ = 4;
      FUN_00a33e40(apppppppuStack_58);
      uStack_a0 = 0;
      puStack_9c = (undefined4 *)0x0;
      uStack_98 = 0;
      puStack_90 = DAT_01ede680;
      uStack_8c = 0;
      puStack_80 = (undefined4 *)0x0;
      puStack_7c = (undefined4 *)0x0;
      uStack_60 = DAT_01ede684;
      pppppppuStack_5c = (uint *******)apppppppuStack_58;
      if (0xf < uStack_44) {
        pppppppuStack_5c = apppppppuStack_58[0];
      }
      uStack_8._0_1_ = 5;
      uStack_68 = 0;
      uStack_64 = 0;
      param_2 = uStack_48;
      if (uStack_48 < 0x10) {
        ppppppuVar13 = *pppppppuStack_5c;
        ppppppuStack_74 = pppppppuStack_5c[1];
        ppppppuStack_70 = pppppppuStack_5c[2];
        ppppppuStack_6c = pppppppuStack_5c[3];
        uStack_68 = uStack_48;
        uStack_24 = 0xf;
        uStack_64 = 0xf;
        ppppppuStack_78 = ppppppuVar13;
      }
      else {
        uVar12 = uStack_48 | 0xf;
        if (0x7fffffff < uVar12) {
          uVar12 = 0x7fffffff;
        }
        uVar9 = uVar12 + 1;
        uStack_24 = uVar12;
        if (uVar9 < 0x1000) {
          if (uVar9 == 0) {
            ppppppuVar13 = (uint ******)0x0;
          }
          else {
            ppppppuVar13 = (uint ******)FUN_01674e20(uVar9);
          }
        }
        else {
          uVar5 = uVar12 + 0x24;
          if (uVar5 <= uVar9) {
            uVar5 = 0xffffffff;
          }
          pppppuVar6 = (uint *****)FUN_01674e20(uVar5);
          if (pppppuVar6 == (uint *****)0x0) goto LAB_00885f20;
          ppppppuVar13 = (uint ******)((int)pppppuVar6 + 0x23U & 0xffffffe0);
          ppppppuVar13[-1] = pppppuVar6;
        }
        ppppppuStack_78 = ppppppuVar13;
        FUN_0170c6f0(ppppppuVar13,pppppppuStack_5c,param_2 + 1);
        uStack_68 = param_2;
        uStack_64 = uVar12;
      }
      uStack_8._0_1_ = 6;
      param_2 = uStack_68;
      puVar3 = (undefined4 *)FUN_01674e20(0x18);
      uStack_8._0_1_ = 7;
      puStack_bc = puVar3;
      if (puVar3 == (undefined4 *)0x0) {
        uVar12 = uStack_24;
        puVar3 = (undefined4 *)0x0;
      }
      else {
        FUN_0054ef60(&ppppppuStack_78);
        *puVar3 = 0;
        uStack_8._0_1_ = 8;
        puVar3[2] = uStack_60;
        puVar3[3] = 2;
        iStack_c0 = FUN_01674e20(0x18);
        uStack_8._0_1_ = 9;
        if (iStack_c0 == 0) {
          uVar7 = 0;
        }
        else {
          uVar7 = FUN_0054ef60(aiStack_b8);
        }
        puVar3[4] = uVar7;
        uStack_8._0_1_ = 7;
        uVar12 = uStack_64;
        ppppppuVar13 = ppppppuStack_78;
        if (0xf < uStack_a4) {
          uVar12 = uStack_a4 + 1;
          iVar2 = aiStack_b8[0];
          if (0xfff < uVar12) {
            iVar2 = *(int *)(aiStack_b8[0] + -4);
            uVar12 = uStack_a4 + 0x24;
            if (0x1f < (aiStack_b8[0] - iVar2) - 4U) goto LAB_00885f20;
          }
          FUN_01674ea0(iVar2,uVar12);
          uVar12 = uStack_64;
          ppppppuVar13 = ppppppuStack_78;
        }
      }
      puVar1 = puVar3;
      if (puStack_7c != (undefined4 *)0x0) {
        *puStack_7c = puVar3;
        puVar1 = puStack_80;
      }
      puStack_80 = puVar1;
      uStack_8._0_1_ = 5;
      puStack_7c = puVar3;
      if (0xf < uVar12) {
        uVar9 = uVar12 + 1;
        ppppppuVar14 = ppppppuVar13;
        if (0xfff < uVar9) {
          ppppppuVar14 = (uint ******)ppppppuVar13[-1];
          uVar9 = uVar12 + 0x24;
          if (0x1f < (uint)((int)ppppppuVar13 + (-4 - (int)ppppppuVar14))) goto LAB_00885f20;
        }
        FUN_01674ea0(ppppppuVar14,uVar9);
      }
      iVar2 = iStack_28;
      FUN_00886140(&uStack_a0,2);
      pppppppuVar4 = &pppppppuStack_40;
      if ((undefined4 ******)0xf < ppppppuStack_2c) {
        pppppppuVar4 = pppppppuStack_40;
      }
      FUN_0055b3b0(*(undefined4 *)(iVar2 + 0x24),pppppppuVar4,ppppppuStack_30);
      uVar7 = FUN_00558890(*(undefined4 *)(iVar2 + 0x24),&DAT_018c35e0);
      puVar3 = puStack_90;
      if (0xf < (uint)puStack_90[5]) {
        puVar3 = (undefined4 *)*puStack_90;
      }
      uVar7 = FUN_0055b3b0(uVar7,puVar3,puStack_90[4],0x3e);
      FUN_005ed940(uVar7);
      FUN_005ed940(*(undefined4 *)(iVar2 + 0x24),10);
      puVar3 = puStack_80;
      while (puVar1 = puStack_9c, puVar3 != (undefined4 *)0x0) {
        puVar1 = (undefined4 *)*puVar3;
        uStack_8._0_1_ = 10;
        FUN_0087ccc0();
        FUN_01674ea0(puVar3,0x18);
        puVar3 = puVar1;
      }
      while (puVar1 != (undefined4 *)0x0) {
        puVar3 = (undefined4 *)*puVar1;
        FUN_008829b0();
        FUN_01674ea0(puVar1,0x28);
        puVar1 = puVar3;
      }
      uStack_8._0_1_ = 0xb;
      FUN_0087ccc0();
      uStack_8._0_1_ = 2;
      if (0xf < uStack_44) {
        uVar12 = uStack_44 + 1;
        pppppppuVar10 = apppppppuStack_58[0];
        if (0xfff < uVar12) {
          pppppppuVar10 = (uint *******)apppppppuStack_58[0][-1];
          uVar12 = uStack_44 + 0x24;
          if (0x1f < (uint)((int)apppppppuStack_58[0] + (-4 - (int)pppppppuVar10)))
          goto LAB_00885f20;
        }
        FUN_01674ea0(pppppppuVar10,uVar12);
      }
      uStack_48 = 0;
      uStack_44 = 0xf;
      apppppppuStack_58[0] = (uint *******)((uint)apppppppuStack_58[0] & 0xffffff00);
      uStack_8._0_1_ = 1;
      if ((undefined4 ******)0xf < ppppppuStack_2c) {
        ppppppuVar11 = (undefined4 ******)((int)ppppppuStack_2c + 1);
        pppppppuVar4 = pppppppuStack_40;
        if ((undefined4 ******)0xfff < ppppppuVar11) {
          pppppppuVar4 = (undefined4 *******)pppppppuStack_40[-1];
          ppppppuVar11 = ppppppuStack_2c + 9;
          if (0x1f < (uint)((int)pppppppuStack_40 + (-4 - (int)pppppppuVar4))) {
LAB_00885f20:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(pppppppuVar4,ppppppuVar11);
      }
      iStack_14 = iStack_14 + 4;
      param_1 = iStack_28;
    } while (iStack_14 != iStack_1c);
  }
  FUN_005ed940(*(undefined4 *)(param_1 + 0x24),9);
  uVar7 = FUN_00558890(*(undefined4 *)(param_1 + 0x24),&DAT_018c35e0);
  puVar3 = puStack_e0;
  if (0xf < (uint)puStack_e0[5]) {
    puVar3 = (undefined4 *)*puStack_e0;
  }
  uVar7 = FUN_0055b3b0(uVar7,puVar3,puStack_e0[4],0x3e);
  FUN_005ed940(uVar7);
  FUN_005ed940(*(undefined4 *)(param_1 + 0x24),10);
  FUN_008829b0();
  FUN_00612dd0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13705 ; VA 0x00885f30 ; FUN_00885f30 */

void __thiscall FUN_00885f30(int param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b9fa7;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0087ccc0();
  iVar1 = FUN_01674e20(0x18);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_0054ef60(&param_2);
  }
  *(undefined4 *)(param_1 + 8) = uVar2;
  *(undefined4 *)(param_1 + 4) = 2;
  if (0xf < in_stack_00000018) {
    uVar4 = in_stack_00000018 + 1;
    iVar3 = param_2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(param_2 + -4);
      uVar4 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3(iVar1);
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13706 ; VA 0x00885fd0 ; FUN_00885fd0 */

void __thiscall FUN_00885fd0(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint in_stack_00000018;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b9fd7;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0087ccc0();
  iVar1 = FUN_01674e20(0x18);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iVar1 == 0) {
    iVar3 = 0;
  }
  else {
    iVar4 = iVar1;
    FUN_0054ef60(&param_2);
    iVar3 = iVar1;
    iVar1 = iVar4;
  }
  *(int *)(param_1 + 8) = iVar3;
  *(undefined4 *)(param_1 + 4) = 3;
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    iVar3 = param_2;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(param_2 + -4);
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3(iVar1);
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13707 ; VA 0x00886080 ; FUN_00886080 */

void __fastcall FUN_00886080(int param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  
LAB_00886083:
  do {
    piVar1 = *(int **)(param_1 + 4);
    if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
      uVar3 = (**(code **)(*piVar1 + 0x18))();
    }
    else {
      uVar3 = (uint)**(byte **)piVar1[7];
    }
    if ((uVar3 == 0xffffffff) || ((&DAT_01d62930)[uVar3 & 0xff] == '\0')) {
      return;
    }
    piVar1 = *(int **)(param_1 + 4);
    if (*(int *)piVar1[7] != 0) {
      iVar2 = *(int *)piVar1[0xb];
      if (0 < iVar2) {
        *(int *)piVar1[0xb] = iVar2 + -1;
        *(int *)piVar1[7] = *(int *)piVar1[7] + 1;
        goto LAB_00886083;
      }
    }
    (**(code **)(*piVar1 + 0x1c))();
  } while( true );
}



/* FUNCTION 13708 ; VA 0x008860e0 ; FUN_008860e0 */

void __thiscall FUN_008860e0(int param_1,int param_2,int param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  
  if (0 < param_3) {
    do {
      FUN_005ed940(*(undefined4 *)(param_1 + 0x24),9);
      param_3 = param_3 + -1;
    } while (param_3 != 0);
  }
  uVar2 = FUN_00558890(*(undefined4 *)(param_1 + 0x24),&DAT_018c35e0);
  piVar3 = *(int **)(param_2 + 0x10);
  piVar1 = piVar3 + 4;
  if (0xf < (uint)piVar3[5]) {
    piVar3 = (int *)*piVar3;
  }
  uVar2 = FUN_0055b3b0(uVar2,piVar3,*piVar1,0x3e);
  FUN_005ed940(uVar2);
  return;
}



/* FUNCTION 13709 ; VA 0x00886140 ; FUN_00886140 */

void __thiscall FUN_00886140(int param_1,int param_2,int param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  void **ppvVar3;
  undefined4 uVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (0 < param_3) {
    do {
      FUN_005ed940(*(undefined4 *)(param_1 + 0x24),9);
      param_3 = param_3 + -1;
      ppvVar3 = (void **)ExceptionList;
    } while (param_3 != 0);
  }
  ExceptionList = ppvVar3;
  uVar4 = FUN_005ed940(*(undefined4 *)(param_1 + 0x24),0x3c);
  piVar5 = *(int **)(param_2 + 0x10);
  piVar1 = piVar5 + 4;
  if (0xf < (uint)piVar5[5]) {
    piVar5 = (int *)*piVar5;
  }
  FUN_0055b3b0(uVar4,piVar5,*piVar1);
  puVar2 = *(undefined4 **)(param_2 + 0x20);
  do {
    if (puVar2 == (undefined4 *)0x0) {
      FUN_005ed940(*(undefined4 *)(param_1 + 0x24),0x3e);
      ExceptionList = pvStack_10;
      return;
    }
    uVar4 = FUN_005ed940(*(undefined4 *)(param_1 + 0x24),0x20);
    piVar5 = (int *)puVar2[2];
    piVar1 = piVar5 + 4;
    if (0xf < (uint)piVar5[5]) {
      piVar5 = (int *)*piVar5;
    }
    uVar4 = FUN_0055b3b0(uVar4,piVar5,*piVar1,&DAT_018c35d4);
    FUN_00558890(uVar4);
    uVar4 = FUN_0087d5f0(auStack_28,param_1);
    uStack_8 = 0;
    FUN_00886290(*(undefined4 *)(param_1 + 0x24),uVar4);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar7 = uStack_14 + 1;
      uVar6 = auStack_28[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_28[0] - 4);
        uVar7 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005ed940(*(undefined4 *)(param_1 + 0x24),0x22);
    puVar2 = (undefined4 *)*puVar2;
  } while( true );
}



/* FUNCTION 13710 ; VA 0x00886290 ; FUN_00886290 */

void FUN_00886290(undefined4 param_1,byte *param_2)

{
  byte bVar1;
  int iVar2;
  byte *pbVar3;
  undefined auStack_c [8];
  
  pbVar3 = param_2;
  if (0xf < *(uint *)(param_2 + 0x14)) {
    pbVar3 = *(byte **)param_2;
  }
  for (iVar2 = *(int *)(param_2 + 0x10); iVar2 != 0; iVar2 = iVar2 + -1) {
    bVar1 = *pbVar3;
    pbVar3 = pbVar3 + 1;
    if (bVar1 == 0x3c) {
      FUN_00558890(param_1,&DAT_018c36e4);
    }
    else if (bVar1 == 0x3e) {
      FUN_00558890(param_1,&DAT_018c36ec);
    }
    else if (bVar1 == 0x26) {
      FUN_00558890(param_1,"&amp;");
    }
    else if (bVar1 == 0x22) {
      FUN_00558890(param_1,"&quot;");
    }
    else if (bVar1 == 0x27) {
      FUN_00558890(param_1,"&apos;");
    }
    else if ((((bVar1 < 0x20) && (bVar1 != 10)) && (bVar1 != 0xd)) || (0x7e < bVar1)) {
      FUN_005bde90(auStack_c,"&#%d;",bVar1);
      FUN_00558890(param_1,auStack_c);
    }
    else {
      FUN_005ed940(param_1,bVar1);
    }
  }
  return;
}



/* FUNCTION 13711 ; VA 0x00886360 ; FUN_00886360 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00886360(int *param_1)

{
  int *piVar1;
  undefined *puVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  
  iVar4 = *param_1;
  iVar3 = FUN_0088cb40();
  if (iVar4 == iVar3) {
    iVar4 = *param_1;
    iVar3 = FUN_0088cb40();
    if (iVar4 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar1 = param_1 + 2;
    piVar5 = piVar1;
    if (param_1[1] == 0) {
      piVar5 = (int *)0x0;
    }
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c48) {
      FUN_016f3809(&DAT_01ea8c48);
      if (DAT_01ea8c48 == -1) {
        _DAT_01ea8c3c = FUN_005c65f0;
        _DAT_01ea8c40 = FUN_005c93a0;
        DAT_01ea8c44 = FUN_005c77b0;
        FUN_016f37bf(&DAT_01ea8c48);
      }
    }
    puVar2 = (undefined *)param_1[1];
    if (puVar2 == &DAT_01ea8c3c) {
      if (piVar1 != piVar5) {
        piVar1 = piVar5 + 4;
        if (0xf < (uint)piVar5[5]) {
          piVar5 = (int *)*piVar5;
        }
        FUN_005542c0(piVar5,*piVar1);
        iVar4 = FUN_00886600();
        *param_1 = iVar4;
        FUN_00886470();
        return;
      }
    }
    else {
      if (puVar2 != (undefined *)0x0) {
        (**(code **)(puVar2 + 8))(piVar1);
        param_1[1] = 0;
      }
      FUN_0054ef60(piVar5);
      param_1[1] = (int)&DAT_01ea8c3c;
    }
    iVar4 = FUN_00886600();
    *param_1 = iVar4;
  }
  FUN_00886470();
  return;
}



/* FUNCTION 13712 ; VA 0x00886470 ; FUN_00886470 */

int * __fastcall FUN_00886470(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9ff8;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00886600();
  if (iVar5 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    if (piVar3 != (int *)0x0) {
      ExceptionList = pvStack_10;
      return piVar3;
    }
  }
  iVar5 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar5 == iVar2) {
    FUN_008866d0();
    iVar5 = *param_1;
    uStack_8 = 0;
    iVar2 = FUN_0088cb40();
    if (iVar5 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_1 + 2;
    piVar4 = piVar3;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    cVar1 = FUN_00886940(piVar4,&iStack_1c);
    if (cVar1 != '\0') {
      iVar2 = FUN_006310e0();
      iVar5 = param_1[1];
      if (iVar5 == iVar2) {
        LOCK();
        *(int *)(iStack_1c + 0x28) = *(int *)(iStack_1c + 0x28) + 1;
        UNLOCK();
        iStack_14 = *piVar3;
        *piVar3 = iStack_1c;
        FUN_0056cd30();
        LOCK();
        *(int *)(iStack_18 + 0x28) = *(int *)(iStack_18 + 0x28) + 1;
        UNLOCK();
        iStack_14 = param_1[3];
        param_1[3] = iStack_18;
        FUN_0056cd30();
      }
      else {
        if (iVar5 != 0) {
          (**(code **)(iVar5 + 8))(piVar3);
          param_1[1] = 0;
        }
        param_1[2] = iStack_1c;
        LOCK();
        *(int *)(iStack_1c + 0x28) = *(int *)(iStack_1c + 0x28) + 1;
        UNLOCK();
        param_1[3] = iStack_18;
        LOCK();
        *(int *)(iStack_18 + 0x28) = *(int *)(iStack_18 + 0x28) + 1;
        UNLOCK();
        param_1[1] = iVar2;
      }
      iVar5 = FUN_00886600();
      *param_1 = iVar5;
      iVar2 = FUN_00886600();
      if (iVar5 == iVar2) {
        if (param_1[1] == 0) {
          piVar3 = (int *)0x0;
        }
        FUN_0056cd30();
        FUN_0056cd30();
        ExceptionList = pvStack_10;
        return piVar3;
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    uStack_8 = 0xffffffff;
    FUN_0056dd20();
  }
  thunk_FUN_00886600();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 13713 ; VA 0x00886600 ; FUN_00886600 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00886600(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba01c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede75c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede75c);
    if (DAT_01ede75c == -1) {
      uStack_8 = 0;
      FUN_00888860("ProtectedString",7,0,0,0);
      _DAT_01ede738 = RBX::Reflection::TType<class_RBX::ProtectedString>::vftable;
      FUN_016f3654(&LAB_01880840);
      FUN_016f37bf(&DAT_01ede75c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede738;
}



/* FUNCTION 13714 ; VA 0x008866a0 ; FUN_008866a0 */

int * __thiscall FUN_008866a0(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = *param_2;
  *param_1 = iVar2;
  LOCK();
  piVar1 = (int *)(iVar2 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  iVar2 = param_2[1];
  param_1[1] = iVar2;
  LOCK();
  piVar1 = (int *)(iVar2 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  return param_1;
}



/* FUNCTION 13715 ; VA 0x008866d0 ; FUN_008866d0 */

undefined4 __fastcall FUN_008866d0(undefined4 param_1)

{
  uint uVar1;
  uint uVar2;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba053;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  FUN_00a33c70();
  uStack_8 = 0;
  FUN_00a33c70();
  uStack_8._0_1_ = 1;
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00887230(auStack_2c,auStack_44);
  if (0xf < uStack_18) {
    uVar2 = uStack_18 + 1;
    uVar1 = auStack_2c[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_2c[0] - 4);
      uVar2 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  if (0xf < uStack_30) {
    uVar2 = uStack_30 + 1;
    uVar1 = auStack_44[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_44[0] - 4);
      uVar2 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13716 ; VA 0x008867e0 ; FUN_008867e0 */

void __fastcall FUN_008867e0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  if (*(char *)(param_1 + 7) != '\0') {
    uVar1 = param_1[5];
    if (0xf < uVar1) {
      iVar2 = *param_1;
      uVar4 = uVar1 + 1;
      iVar3 = iVar2;
      if (0xfff < uVar4) {
        iVar3 = *(int *)(iVar2 + -4);
        uVar4 = uVar1 + 0x24;
        if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar4);
    }
    param_1[4] = 0;
    param_1[5] = 0xf;
    *(undefined *)param_1 = 0;
  }
  return;
}



/* FUNCTION 13717 ; VA 0x00886840 ; FUN_00886840 */

int * __thiscall FUN_00886840(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = *param_2;
  LOCK();
  piVar1 = (int *)(iVar2 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  *param_1 = iVar2;
  FUN_0056cd30();
  iVar2 = param_2[1];
  LOCK();
  piVar1 = (int *)(iVar2 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  param_1[1] = iVar2;
  FUN_0056cd30();
  return param_1;
}



/* FUNCTION 13718 ; VA 0x00886890 ; FUN_00886890 */

undefined4 FUN_00886890(int param_1)

{
  char cVar1;
  
  cVar1 = FUN_00a33d60(param_1);
  if (cVar1 != '\0') {
    cVar1 = FUN_00a33d60(param_1 + 4);
    if (cVar1 != '\0') {
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 13719 ; VA 0x008868d0 ; FUN_008868d0 */

undefined4 FUN_008868d0(int param_1)

{
  char cVar1;
  
  cVar1 = FUN_00a33d60(param_1);
  if (cVar1 != '\0') {
    cVar1 = FUN_00a33d60(param_1 + 4);
    if (cVar1 != '\0') {
      return 0;
    }
  }
  return 1;
}



/* FUNCTION 13720 ; VA 0x00886910 ; FUN_00886910 */

undefined4 __thiscall FUN_00886910(undefined4 param_1,byte param_2)

{
  FUN_00888900();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x24);
  }
  return param_1;
}



/* FUNCTION 13721 ; VA 0x00886940 ; FUN_00886940 */

undefined4 FUN_00886940(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined auStack_10 [8];
  int iStack_8;
  
  piVar3 = (int *)FUN_00886c00(auStack_10,param_1);
  iVar2 = *piVar3;
  LOCK();
  piVar1 = (int *)(iVar2 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  iStack_8 = *param_2;
  *param_2 = iVar2;
  FUN_0056cd30();
  iVar2 = piVar3[1];
  LOCK();
  piVar1 = (int *)(iVar2 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  param_2[1] = iVar2;
  FUN_0056cd30();
  FUN_0056cd30();
  FUN_0056cd30();
  return 1;
}



/* FUNCTION 13722 ; VA 0x008869b0 ; FUN_008869b0 */

undefined4 FUN_008869b0(undefined4 param_1,undefined4 param_2)

{
  uint uVar1;
  uint uVar2;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ba081;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_008866d0();
  uStack_8 = 0;
  uStack_14 = 1;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 1;
  FUN_00887230(auStack_2c,param_2);
  if (0xf < uStack_18) {
    uVar2 = uStack_18 + 1;
    uVar1 = auStack_2c[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_2c[0] - 4);
      uVar2 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13723 ; VA 0x00886a70 ; FUN_00886a70 */

int * FUN_00886a70(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ba0b1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_008866d0();
  uStack_8 = 0;
  piVar4 = (int *)FUN_00a33c70();
  iVar2 = *piVar4;
  uStack_8 = 1;
  LOCK();
  piVar1 = (int *)(iVar2 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  *param_1 = iVar2;
  FUN_0056cd30();
  iVar2 = *param_2;
  LOCK();
  piVar1 = (int *)(iVar2 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  param_1[1] = iVar2;
  FUN_0056cd30();
  cVar3 = FUN_005e0cd0(piVar4);
  if (cVar3 != '\0') {
    DAT_01ee04b4 = DAT_01ee04b4 | 0x200;
  }
  FUN_0056cd30();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13724 ; VA 0x00886b30 ; FUN_00886b30 */

int * FUN_00886b30(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ba0e1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_008866d0();
  uStack_8 = 0;
  piVar4 = (int *)FUN_00a33c70();
  uStack_8 = 1;
  iVar2 = *param_2;
  LOCK();
  piVar1 = (int *)(iVar2 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  *param_1 = iVar2;
  FUN_0056cd30();
  iVar2 = *piVar4;
  LOCK();
  piVar1 = (int *)(iVar2 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  param_1[1] = iVar2;
  FUN_0056cd30();
  cVar3 = FUN_005e0cd0(param_2);
  if (cVar3 != '\0') {
    DAT_01ee04b4 = DAT_01ee04b4 | 0x200;
  }
  FUN_0056cd30();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13725 ; VA 0x00886c00 ; FUN_00886c00 */

undefined4 FUN_00886c00(undefined4 param_1,undefined4 param_2)

{
  uint uVar1;
  uint uVar2;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ba081;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_008866d0();
  uStack_8 = 0;
  uStack_14 = 1;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 1;
  FUN_00887230(param_2,auStack_2c);
  if (0xf < uStack_18) {
    uVar2 = uStack_18 + 1;
    uVar1 = auStack_2c[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_2c[0] - 4);
      uVar2 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13726 ; VA 0x00886cc0 ; FUN_00886cc0 */

int __thiscall FUN_00886cc0(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0ca8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_18,param_2);
  uStack_8 = 0;
  iVar1 = FUN_00a33fa0();
  iVar1 = *(int *)(iVar1 + 0x10);
  FUN_0056cd30();
  FUN_0056cd30();
  ExceptionList = pvStack_10;
  return iVar1 + 8;
}



/* FUNCTION 13727 ; VA 0x00886d30 ; FUN_00886d30 */

undefined * FUN_00886d30(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba0fc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede734) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede734);
    if (DAT_01ede734 == -1) {
      uStack_8 = 0;
      FUN_008866d0();
      FUN_016f3654(&LAB_01880820);
      FUN_016f37bf(&DAT_01ede734);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede72c;
}



/* FUNCTION 13728 ; VA 0x00886dc0 ; FUN_00886dc0 */

undefined4 __thiscall FUN_00886dc0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0ca8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_18,param_3);
  uStack_8 = 0;
  uVar1 = FUN_00a33fa0();
  FUN_0054ef60(uVar1);
  FUN_0056cd30();
  FUN_0056cd30();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 13729 ; VA 0x00886e30 ; FUN_00886e30 */

undefined4 FUN_00886e30(void)

{
  undefined4 uVar1;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  uVar1 = FUN_00a33fa0();
  FUN_006077f0(&uStack_8,uVar1);
  uVar1 = FUN_00a33fa0();
  FUN_006077f0(&uStack_8,uVar1);
  return uStack_8;
}



/* FUNCTION 13730 ; VA 0x00886e70 ; FUN_00886e70 */

void __thiscall FUN_00886e70(int param_1,undefined4 param_2)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined auStack_24 [8];
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba120;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_0087d4d0();
  if (cVar2 == '\0') {
    FUN_008866d0();
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = auStack_3c[0] & 0xffffff00;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    cVar2 = FUN_0087d060(auStack_3c);
    if (cVar2 == '\0') {
      if (0xf < uStack_28) {
        uVar5 = uStack_28 + 1;
        uVar4 = auStack_3c[0];
        if (0xfff < uVar5) {
          uVar4 = *(uint *)(auStack_3c[0] - 4);
          uVar5 = uStack_28 + 0x24;
          if (0x1f < (auStack_3c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar4,uVar5);
      }
    }
    else {
      piVar3 = (int *)FUN_00886c00(auStack_24,auStack_3c);
      iStack_1c = *piVar3;
      LOCK();
      *(int *)(iStack_1c + 0x28) = *(int *)(iStack_1c + 0x28) + 1;
      UNLOCK();
      FUN_0056cd30();
      iVar1 = piVar3[1];
      LOCK();
      piVar3 = (int *)(iVar1 + 0x28);
      *piVar3 = *piVar3 + 1;
      UNLOCK();
      iStack_14 = iStack_18;
      iStack_18 = iVar1;
      FUN_0056cd30();
      FUN_0056cd30();
      FUN_0056cd30();
      uStack_8._0_1_ = 0;
      if (0xf < uStack_28) {
        uVar5 = uStack_28 + 1;
        uVar4 = auStack_3c[0];
        if (0xfff < uVar5) {
          uVar4 = *(uint *)(auStack_3c[0] - 4);
          uVar5 = uStack_28 + 0x24;
          if (0x1f < (auStack_3c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar4,uVar5);
      }
      (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&iStack_1c);
    }
    FUN_0056cd30();
    FUN_0056cd30();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13731 ; VA 0x00886ff0 ; FUN_00886ff0 */

undefined4 * FUN_00886ff0(undefined4 *param_1,char *param_2,uint param_3)

{
  code *pcVar1;
  undefined8 uVar2;
  byte *pbVar3;
  undefined4 *****pppppuVar4;
  int iVar5;
  undefined4 *****pppppuVar6;
  byte *pbVar7;
  uint uVar8;
  undefined4 *puVar9;
  int iVar10;
  char *pcVar11;
  int iVar12;
  bool bVar13;
  undefined4 ****ppppuStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  byte *pbStack_24;
  uint uStack_20;
  undefined4 ****ppppuStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795d48;
  pvStack_10 = ExceptionList;
  if (((DAT_01d62a38 == '\0') || (param_3 < 3)) ||
     (ExceptionList = &pvStack_10, pppppuVar4 = (undefined4 *****)FUN_01683580(&DAT_0191cbb0,3,0),
     pppppuVar4 == (undefined4 *****)0xffffffff)) {
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[5] = 0;
    param_1[6] = 0;
    param_1[7] = 0;
    *(undefined *)(param_1 + 7) = 0;
    *(undefined *)param_1 = 0;
    ExceptionList = pvStack_10;
    return param_1;
  }
  iVar10 = 0;
  iVar12 = 0;
  iStack_14 = (int)(param_2 + (int)pppppuVar4) - (int)param_2;
  iVar5 = iStack_14;
  if (param_2 + (int)pppppuVar4 < param_2) {
    iVar5 = 0;
  }
  iStack_18 = iVar10;
  pcVar11 = param_2;
  if (iVar5 != 0) {
    do {
      iStack_18 = iVar10 + 1;
      if (*pcVar11 != '\n') {
        iStack_18 = iVar10;
      }
      iVar12 = iVar12 + 1;
      iVar10 = iStack_18;
      pcVar11 = pcVar11 + 1;
    } while (iVar12 != iVar5);
  }
  iStack_18 = iStack_18 + 1;
  ppppuStack_1c = pppppuVar4;
  if (param_2 == (char *)0x0) {
    pbStack_24 = (byte *)0x0;
    uStack_20 = 0xf;
    ppppuStack_34 = (undefined4 ****)((uint)ppppuStack_34._1_3_ << 8);
  }
  else {
    pbStack_24 = (byte *)0x0;
    uStack_20 = 0xf;
    ppppuStack_34 = (undefined4 ****)((uint)ppppuStack_34._1_3_ << 8);
    FUN_005542c0(param_2,param_3);
  }
  uStack_8 = 0;
  do {
    if (pbStack_24 <= (byte *)((int)pppppuVar4 + 2U)) {
      FUN_00554050();
      pcVar1 = (code *)swi(3);
      puVar9 = (undefined4 *)(*pcVar1)();
      return puVar9;
    }
    pppppuVar6 = &ppppuStack_34;
    if (0xf < uStack_20) {
      pppppuVar6 = (undefined4 *****)ppppuStack_34;
    }
    *(byte *)((int)pppppuVar6 + (int)((int)pppppuVar4 + 2U)) = 0xbd;
    pbVar3 = pbStack_24;
    pppppuVar6 = &ppppuStack_34;
    if (0xf < uStack_20) {
      pppppuVar6 = (undefined4 *****)ppppuStack_34;
    }
    ppppuStack_1c = pppppuVar6;
    if ((pbStack_24 < (byte *)0x3) || (pbStack_24 + -3 < pppppuVar4)) {
      pppppuVar4 = (undefined4 *****)0xffffffff;
    }
    else {
      pbVar7 = (byte *)FUN_0170db20((byte *)((int)pppppuVar6 + (int)pppppuVar4),0xffffffef,
                                    (byte *)((int)pppppuVar6 +
                                            (int)(pbStack_24 +
                                                 (-2 - ((int)pppppuVar6 + (int)pppppuVar4)))));
      while( true ) {
        if (pbVar7 == (byte *)0x0) goto LAB_0088717d;
        bVar13 = *pbVar7 < 0xef;
        if (((*pbVar7 == 0xef) && (bVar13 = pbVar7[1] < 0xbf, pbVar7[1] == 0xbf)) &&
           (bVar13 = pbVar7[2] < 0xbc, pbVar7[2] == 0xbc)) {
          uVar8 = 0;
        }
        else {
          uVar8 = -(uint)bVar13 | 1;
        }
        if (uVar8 == 0) break;
        pbVar7 = (byte *)FUN_0170db20(pbVar7 + 1,0xffffffef,
                                      (byte *)((int)pppppuVar6 +
                                              (int)(pbVar3 + (-2 - (int)(pbVar7 + 1)))));
      }
      pppppuVar4 = (undefined4 *****)(pbVar7 + -(int)ppppuStack_1c);
    }
  } while ((pppppuVar4 != (undefined4 *****)0x0) && (pppppuVar4 != (undefined4 *****)0xffffffff));
LAB_0088717d:
  uVar2 = CONCAT44(uStack_20,pbStack_24);
  param_1[4] = 0;
  param_1[5] = 0;
  *param_1 = ppppuStack_34;
  param_1[1] = uStack_30;
  param_1[2] = uStack_2c;
  param_1[3] = uStack_28;
  pbStack_24 = (byte *)0x0;
  *(undefined8 *)(param_1 + 4) = uVar2;
  param_1[6] = iStack_18;
  uStack_20 = 0xf;
  ppppuStack_34 = (undefined4 ****)((uint)ppppuStack_34 & 0xffffff00);
  *(undefined *)(param_1 + 7) = 1;
  FUN_005507b0();
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 13732 ; VA 0x00887230 ; FUN_00887230 */

void __thiscall FUN_00887230(int *param_1,byte *param_2,int param_3)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  undefined4 uVar4;
  byte *pbVar5;
  uint uVar6;
  int iVar7;
  bool bVar8;
  int iStack_44;
  uint uStack_30;
  int iStack_2c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8a00;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_2 + 0x10) == 0) {
    ExceptionList = &pvStack_10;
    piVar3 = (int *)FUN_00a33c70();
    iVar7 = *piVar3;
    LOCK();
    piVar3 = (int *)(iVar7 + 0x28);
    *piVar3 = *piVar3 + 1;
    UNLOCK();
    *param_1 = iVar7;
    FUN_0056cd30();
    FUN_0056cd30();
  }
  else {
    ExceptionList = &pvStack_10;
    uVar4 = FUN_0054ef60(param_2);
    uStack_8 = 0;
    FUN_00a34170(uVar4);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_30) {
      uVar6 = uStack_30 + 1;
      iVar7 = iStack_44;
      if (0xfff < uVar6) {
        iVar7 = *(int *)(iStack_44 + -4);
        uVar6 = uStack_30 + 0x24;
        if (0x1f < (iStack_44 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar7,uVar6);
    }
  }
  if (*(int *)(param_3 + 0x10) == 0) {
    piVar3 = (int *)FUN_00a33c70();
    iVar7 = *piVar3;
    LOCK();
    piVar3 = (int *)(iVar7 + 0x28);
    *piVar3 = *piVar3 + 1;
    UNLOCK();
    param_1[1] = iVar7;
    FUN_0056cd30();
    FUN_0056cd30();
  }
  else {
    uVar4 = FUN_0054ef60(param_3);
    uStack_8 = 1;
    FUN_00a34170(uVar4);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_18) {
      uVar6 = uStack_18 + 1;
      iVar7 = iStack_2c;
      if (0xfff < uVar6) {
        iVar7 = *(int *)(iStack_2c + -4);
        uVar6 = uStack_18 + 0x24;
        if (0x1f < (iStack_2c - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar7,uVar6);
    }
  }
  pbVar5 = (byte *)FUN_00a33fa0();
  puVar1 = (uint *)(param_2 + 0x10);
  if (0xf < *(uint *)(param_2 + 0x14)) {
    param_2 = *(byte **)param_2;
  }
  uVar6 = *(uint *)(pbVar5 + 0x10);
  if (0xf < *(uint *)(pbVar5 + 0x14)) {
    pbVar5 = *(byte **)pbVar5;
  }
  if (uVar6 != *puVar1) goto LAB_008873f0;
  while (uVar2 = uVar6 - 4, 3 < uVar6) {
    if (*(int *)pbVar5 != *(int *)param_2) goto LAB_008873b6;
    pbVar5 = pbVar5 + 4;
    param_2 = param_2 + 4;
    uVar6 = uVar2;
  }
  if (uVar2 == 0xfffffffc) {
LAB_008873ea:
    uVar6 = 0;
  }
  else {
LAB_008873b6:
    bVar8 = *pbVar5 < *param_2;
    if ((*pbVar5 == *param_2) &&
       ((uVar2 == 0xfffffffd ||
        ((bVar8 = pbVar5[1] < param_2[1], pbVar5[1] == param_2[1] &&
         ((uVar2 == 0xfffffffe ||
          ((bVar8 = pbVar5[2] < param_2[2], pbVar5[2] == param_2[2] &&
           ((uVar2 == 0xffffffff || (bVar8 = pbVar5[3] < param_2[3], pbVar5[3] == param_2[3]))))))))
        )))) goto LAB_008873ea;
    uVar6 = -(uint)bVar8 | 1;
  }
  if (uVar6 == 0) {
    ExceptionList = pvStack_10;
    return;
  }
LAB_008873f0:
  DAT_01ee04b4 = DAT_01ee04b4 | 0x200;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13733 ; VA 0x00887420 ; FUN_00887420 */

bool __thiscall FUN_00887420(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0ca8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008866d0();
  uStack_8 = 0;
  cVar1 = FUN_00886940(param_3,auStack_18);
  if (cVar1 != '\0') {
    (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,auStack_18);
  }
  FUN_0056cd30();
  FUN_0056cd30();
  ExceptionList = pvStack_10;
  return cVar1 != '\0';
}



/* FUNCTION 13734 ; VA 0x008874a0 ; FUN_008874a0 */

void FUN_008874a0(int *param_1,undefined4 param_2,char param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  char *pcVar6;
  char ****ppppcVar7;
  uint uVar8;
  char ****ppppcVar9;
  uint uVar10;
  undefined auStack_88 [24];
  char ***apppcStack_70 [5];
  uint uStack_5c;
  char ***apppcStack_58 [5];
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba16b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00585a40();
  if (cVar1 != '\0') {
    iVar2 = FUN_00ae4420();
    if (*(int *)(iVar2 + 0x10) != 0) {
      uVar3 = FUN_00ae4420(param_2,0);
      FUN_00d10cd0(apppcStack_70,uVar3);
      uStack_8 = 0;
      puVar4 = (undefined4 *)FUN_008a2380(auStack_88);
      uStack_8._0_1_ = 1;
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      puVar5 = (undefined4 *)(**(code **)(*param_1 + 0x10))();
      if (0xf < (uint)puVar5[5]) {
        puVar5 = (undefined4 *)*puVar5;
      }
      pcVar6 = "draft";
      if (param_3 == '\0') {
        pcVar6 = "";
      }
      FUN_01675640(apppcStack_58,
                   "Potentially malicious %s %s %s has had U+FFFC characters replaced.  ",pcVar6,
                   puVar5,puVar4);
      uStack_8._0_1_ = 3;
      FUN_005507b0();
      uStack_30 = 0;
      ppppcVar9 = apppcStack_70;
      if (0xf < uStack_5c) {
        ppppcVar9 = (char ****)apppcStack_70[0];
      }
      uStack_2c = 0xf;
      auStack_40[0] = auStack_40[0] & 0xffffff00;
      ppppcVar7 = ppppcVar9;
      do {
        cVar1 = *(char *)ppppcVar7;
        ppppcVar7 = (char ****)((int)ppppcVar7 + 1);
      } while (cVar1 != '\0');
      FUN_005542c0(ppppcVar9,(int)ppppcVar7 - (int)((int)ppppcVar9 + 1));
      uStack_8._0_1_ = 4;
      ppppcVar9 = apppcStack_58;
      if (0xf < uStack_44) {
        ppppcVar9 = (char ****)apppcStack_58[0];
      }
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = auStack_28[0] & 0xffffff00;
      ppppcVar7 = ppppcVar9;
      do {
        cVar1 = *(char *)ppppcVar7;
        ppppcVar7 = (char ****)((int)ppppcVar7 + 1);
      } while (cVar1 != '\0');
      FUN_005542c0(ppppcVar9,(int)ppppcVar7 - (int)((int)ppppcVar9 + 1));
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      FUN_0086f010(2,auStack_28,auStack_40,6);
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return;
    }
  }
  puVar4 = (undefined4 *)FUN_008a2380(auStack_28);
  uStack_8 = 6;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  puVar5 = (undefined4 *)(**(code **)(*param_1 + 0x10))();
  if (0xf < (uint)puVar5[5]) {
    puVar5 = (undefined4 *)*puVar5;
  }
  uVar3 = FUN_01675640(auStack_40,
                       "Potentially malicious %s %s:%d has had U+FFFC characters replaced.",puVar5,
                       puVar4,param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_0086ed30(2,uVar3,6);
  if (0xf < uStack_2c) {
    uVar10 = uStack_2c + 1;
    uVar8 = auStack_40[0];
    if (0xfff < uVar10) {
      uVar8 = *(uint *)(auStack_40[0] - 4);
      uVar10 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar10);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  if (0xf < uStack_14) {
    uVar10 = uStack_14 + 1;
    uVar8 = auStack_28[0];
    if (0xfff < uVar10) {
      uVar8 = *(uint *)(auStack_28[0] - 4);
      uVar10 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar10);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13735 ; VA 0x00887700 ; FUN_00887700 */

void __thiscall FUN_00887700(int param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba19f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_18,param_2);
  uStack_8 = 0;
  uVar1 = FUN_00a33fa0();
  FUN_0054ef60(uVar1);
  uStack_8._0_1_ = 1;
  FUN_0087ccc0();
  iVar2 = FUN_01674e20(0x18);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iVar2 == 0) {
    uVar1 = 0;
  }
  else {
    uVar1 = FUN_0054ef60(aiStack_30);
  }
  *(undefined4 *)(param_3 + 0x18) = uVar1;
  *(undefined4 *)(param_3 + 0x14) = 2;
  if (0xf < uStack_1c) {
    uVar3 = uStack_1c + 1;
    iVar2 = aiStack_30[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_30[0] + -4);
      uVar3 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  FUN_0056cd30();
  FUN_0056cd30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 13736 ; VA 0x008877e0 ; FUN_008877e0 */

int __thiscall FUN_008877e0(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  undefined *puVar3;
  undefined *puVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  int iVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba1b8;
  pvStack_10 = ExceptionList;
  iVar6 = *param_1;
  iVar2 = ((int)param_2 - iVar6) / 0xd8;
  puVar3 = (undefined *)((param_1[1] - iVar6) / 0xd8);
  if (puVar3 == &DAT_012f684b) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  puVar3 = puVar3 + 1;
  uVar7 = (param_1[2] - iVar6) / 0xd8;
  puVar4 = puVar3;
  if ((uVar7 <= (int)&DAT_012f684b - (uVar7 >> 1)) &&
     (puVar4 = (undefined *)((uVar7 >> 1) + uVar7), puVar4 < puVar3)) {
    puVar4 = puVar3;
  }
  uVar7 = (int)puVar4 * 0xd8;
  if (puVar4 < &UNK_012f684c) {
    if (0xfff < uVar7) goto LAB_00887897;
    if (uVar7 == 0) {
      puVar8 = (undefined4 *)0x0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      puVar8 = (undefined4 *)FUN_01674e20(uVar7);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_00887897:
    uVar5 = uVar7 + 0x23;
    if (uVar5 <= uVar7) {
      uVar5 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar6 = FUN_01674e20(uVar5);
    if (iVar6 == 0) goto LAB_00887a83;
    puVar8 = (undefined4 *)(iVar6 + 0x23U & 0xffffffe0);
    puVar8[-1] = iVar6;
  }
  puVar10 = puVar8 + iVar2 * 0x36;
  uStack_8 = 0;
  *puVar10 = *param_3;
  puVar10[1] = param_3[1];
  puVar10[2] = param_3[2];
  puVar10[3] = 0;
  if ((undefined4 *)param_3[3] != (undefined4 *)0x0) {
    (**(code **)param_3[3])(param_3 + 4,puVar10 + 4);
  }
  puVar10[3] = param_3[3];
  puVar1 = (undefined4 *)param_1[1];
  if (param_2 == puVar1) {
    puVar10 = (undefined4 *)*param_1;
    uStack_8._0_1_ = 1;
    puVar9 = puVar8;
    for (; puVar10 != puVar1; puVar10 = puVar10 + 0x36) {
      *puVar9 = *puVar10;
      puVar9[1] = puVar10[1];
      puVar9[2] = puVar10[2];
      puVar9[3] = 0;
      if ((undefined4 *)puVar10[3] != (undefined4 *)0x0) {
        (**(code **)puVar10[3])(puVar10 + 4,puVar9 + 4);
      }
      puVar9[3] = puVar10[3];
      puVar9 = puVar9 + 0x36;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00687590(puVar9,puVar9,param_1);
  }
  else {
    FUN_008889e0(*param_1,param_2,puVar8);
    FUN_008889e0(param_2,param_1[1],puVar10 + 0x36);
  }
  uStack_8 = 0xffffffff;
  if (*param_1 != 0) {
    FUN_00687590(*param_1,param_1[1],param_1);
    iVar6 = *param_1;
    uVar7 = ((param_1[2] - iVar6) / 0xd8) * 0xd8;
    iVar11 = iVar6;
    if (0xfff < uVar7) {
      iVar11 = *(int *)(iVar6 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar6 - iVar11) - 4U) {
LAB_00887a83:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar11,uVar7);
  }
  *param_1 = (int)puVar8;
  param_1[1] = (int)(puVar8 + (int)puVar3 * 0x36);
  param_1[2] = (int)(puVar8 + (int)puVar4 * 0x36);
  ExceptionList = pvStack_10;
  return *param_1 + iVar2 * 0xd8;
}



/* FUNCTION 13737 ; VA 0x00887a59 ; Catch_All@00887a59 */

void Catch_All_00887a59(void)

{
  int unaff_EBP;
  
  FUN_0068a6d0(*(undefined4 *)(unaff_EBP + -0x1c),*(undefined4 *)(unaff_EBP + -0x24));
  FUN_0061a420(*(undefined4 *)(unaff_EBP + -0x30),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 13738 ; VA 0x00887a90 ; FUN_00887a90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00887a90(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba1e6;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined *)*param_1;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede7fc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede7fc);
    if (DAT_01ede7fc == -1) {
      uStack_8 = 0;
      uVar2 = FUN_00554ed0();
      uStack_20 = uStack_20 & 0xffffff00;
      uStack_1c = 0;
      _DAT_01ede7d8 = RBX::Reflection::Descriptor::vftable;
      _DAT_01ede7dc = FUN_0086e3d0(&DAT_0191cce8);
      _DAT_01ede7e0 = CONCAT44(uStack_1c,uStack_20);
      _DAT_01ede7e8 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ede7d8 = RBX::Reflection::Type::vftable;
      _DAT_01ede7f4 = 0x25;
      _DAT_01ede7f8 = 0;
      DAT_01ede7fa = 0;
      _DAT_01ede7ec = uVar2;
      _DAT_01ede7f0 = _DAT_01ede7dc;
      FUN_00888bf0();
      _DAT_01ede7d8 =
           RBX::Reflection::
           TType<class_std::shared_ptr<class_std::map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_std::less<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>_>
           ::vftable;
      FUN_016f3654(&LAB_01880850);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ede7fc);
    }
  }
  if (puStack_14 == &DAT_01ede7d8) {
    puVar1 = param_1 + 2;
    if (param_1[1] == 0) {
      puVar1 = (undefined4 *)0x0;
    }
    if (puVar1 != (undefined4 *)0x0) {
      ExceptionList = pvStack_10;
      return;
    }
  }
  FUN_00550130("Unable to cast to Map");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(&uStack_20,&DAT_01c17198);
}



/* FUNCTION 13739 ; VA 0x00887bf0 ; FUN_00887bf0 */

int * __fastcall FUN_00887bf0(int *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined **ppuVar5;
  int iVar6;
  int *piVar7;
  undefined **ppuVar8;
  undefined auStack_2c [12];
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba200;
  pvStack_10 = ExceptionList;
  iVar6 = *param_1;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  iVar3 = FUN_008881d0();
  if (((iVar6 != iVar3) || (param_1[1] == 0)) || (piVar7 = param_1 + 2, piVar7 == (int *)0x0)) {
    iVar6 = *param_1;
    iVar3 = FUN_008882f0();
    if (((iVar6 != iVar3) || (param_1[1] == 0)) ||
       ((piVar7 = param_1 + 2, piVar7 == (int *)0x0 ||
        (iVar3 = ((int *)*piVar7)[1] - *(int *)*piVar7, iVar6 = iVar3 >> 0x1f,
        iVar3 / 0xd0 + iVar6 != iVar6)))) {
      FUN_00550130("Unable to cast to Dictionary");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_2c,&DAT_01c17198);
    }
    puVar4 = (undefined4 *)FUN_01674e20(0x24);
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      puVar4[1] = 1;
      ppuVar8 = (undefined **)&DAT_018be100;
      puVar4[2] = 1;
      *puVar4 = std::
                _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>
                ::vftable;
      *(undefined *)(puVar4 + 3) = 0;
      iVar6 = 0x26;
      do {
        iVar3 = iVar6 >> 1;
        if (ppuVar8[iVar3] < &DAT_0000000b) {
          ppuVar8 = ppuVar8 + iVar3 + 1;
          iVar3 = iVar6 + (-1 - iVar3);
        }
        iVar6 = iVar3;
      } while (0 < iVar3);
      ppuVar5 = ppuVar8 + -1;
      if (ppuVar8 != &boost::lock_error::vftable_meta_ptr) {
        ppuVar5 = ppuVar8;
      }
      piVar7 = piStack_14 + 2;
      puVar4[4] = *ppuVar5;
      puVar4[5] = 0;
      puVar4[6] = 0x3f800000;
      puVar4[7] = 0;
      puVar4[8] = 0;
      param_1 = piStack_14;
    }
    puStack_20 = puVar4 + 3;
    uStack_18 = 0;
    piStack_14 = (int *)0x0;
    uStack_8 = 1;
    puStack_1c = puVar4;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8a9c)
       && (FUN_016f3809(&DAT_01ea8a9c), DAT_01ea8a9c == -1)) {
      DAT_01ea8a90 = FUN_0057bbb0;
      DAT_01ea8a94 = FUN_005880a0;
      DAT_01ea8a98 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ea8a9c);
    }
    puVar2 = (undefined4 *)param_1[1];
    if ((code **)puVar2 == &DAT_01ea8a90) {
      param_1[2] = (int)(puVar4 + 3);
      piVar7 = (int *)param_1[3];
      puStack_20 = (undefined4 *)0x0;
      puStack_1c = (undefined4 *)0x0;
      param_1[3] = (int)puVar4;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar6 = piVar7[1] + -1;
        piVar7[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar6 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar6 == 1) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
    }
    else {
      if (puVar2 != (undefined4 *)0x0) {
        (*(code *)puVar2[2])(piVar7);
      }
      param_1[3] = (int)puVar4;
      param_1[2] = (int)(puVar4 + 3);
      puStack_20 = (undefined4 *)0x0;
      puStack_1c = (undefined4 *)0x0;
      param_1[1] = (int)&DAT_01ea8a90;
    }
    FUN_00550b30();
    uStack_8 = 0xffffffff;
    FUN_00550b30();
    iVar6 = FUN_008881d0();
    *param_1 = iVar6;
    iVar3 = FUN_008881d0();
    if (iVar6 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar7 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar7 = (int *)0x0;
    }
  }
  ExceptionList = pvStack_10;
  return piVar7;
}



/* FUNCTION 13740 ; VA 0x00887e80 ; FUN_00887e80 */

int * __fastcall FUN_00887e80(int *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined auStack_2c [12];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba220;
  pvStack_10 = ExceptionList;
  iVar6 = *param_1;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_008882f0();
  if (iVar6 == iVar3) {
    piVar4 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    if (piVar4 != (int *)0x0) {
      ExceptionList = pvStack_10;
      return piVar4;
    }
  }
  iVar6 = *param_1;
  iVar3 = FUN_008881d0();
  if (iVar6 == iVar3) {
    piVar4 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    if ((piVar4 != (int *)0x0) && (*(int *)(*piVar4 + 8) == 0)) {
      puVar5 = (undefined4 *)FUN_01674e20(0x18);
      if (puVar5 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)0x0;
      }
      else {
        puVar5[1] = 1;
        puVar5[2] = 1;
        *puVar5 = std::
                  _Ref_count_obj<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_>
                  ::vftable;
        puVar5[3] = 0;
        puVar5[4] = 0;
        puVar5[5] = 0;
      }
      puStack_18 = puVar5 + 3;
      uStack_20 = 0;
      uStack_1c = 0;
      uStack_8 = 1;
      puStack_14 = puVar5;
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c38
          ) && (FUN_016f3809(&DAT_01ea8c38), DAT_01ea8c38 == -1)) {
        DAT_01ea8c2c = FUN_0057bbb0;
        DAT_01ea8c30 = FUN_005880a0;
        DAT_01ea8c34 = FUN_0057d5e0;
        FUN_016f37bf(&DAT_01ea8c38);
      }
      puVar2 = (undefined4 *)param_1[1];
      if ((code **)puVar2 == &DAT_01ea8c2c) {
        param_1[2] = (int)(puVar5 + 3);
        piVar4 = (int *)param_1[3];
        puStack_18 = (undefined4 *)0x0;
        puStack_14 = (undefined4 *)0x0;
        param_1[3] = (int)puVar5;
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar6 = piVar4[1] + -1;
          piVar4[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            piVar1 = piVar4 + 2;
            iVar6 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar6 == 1) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
      }
      else {
        if (puVar2 != (undefined4 *)0x0) {
          (*(code *)puVar2[2])(param_1 + 2);
        }
        param_1[3] = (int)puVar5;
        param_1[2] = (int)(puVar5 + 3);
        puStack_18 = (undefined4 *)0x0;
        puStack_14 = (undefined4 *)0x0;
        param_1[1] = (int)&DAT_01ea8c2c;
      }
      piVar4 = param_1 + 2;
      FUN_00550b30();
      uStack_8 = 0xffffffff;
      FUN_00550b30();
      iVar6 = FUN_008882f0();
      *param_1 = iVar6;
      iVar3 = FUN_008882f0();
      if (iVar6 == iVar3) {
        if (param_1[1] == 0) {
          piVar4 = (int *)0x0;
        }
        ExceptionList = pvStack_10;
        return piVar4;
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
  }
  FUN_00550130("Unable to cast to Array");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_2c,&DAT_01c17198);
}



/* FUNCTION 13741 ; VA 0x008880b0 ; FUN_008880b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_008880b0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba1e6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede7fc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede7fc);
    if (DAT_01ede7fc == -1) {
      uStack_8 = 0;
      uVar1 = FUN_00554ed0();
      uStack_1c = uStack_1c & 0xffffff00;
      _DAT_01ede7d8 = RBX::Reflection::Descriptor::vftable;
      _DAT_01ede7dc = FUN_0086e3d0(&DAT_0191cce8);
      _DAT_01ede7e0 = (ulonglong)uStack_1c;
      _DAT_01ede7e8 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ede7d8 = RBX::Reflection::Type::vftable;
      _DAT_01ede7f4 = 0x25;
      _DAT_01ede7f8 = 0;
      DAT_01ede7fa = 0;
      _DAT_01ede7ec = uVar1;
      _DAT_01ede7f0 = _DAT_01ede7dc;
      FUN_00888bf0();
      _DAT_01ede7d8 =
           RBX::Reflection::
           TType<class_std::shared_ptr<class_std::map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_std::less<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>_>
           ::vftable;
      FUN_016f3654(&LAB_01880850);
      FUN_016f37bf(&DAT_01ede7fc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede7d8;
}



/* FUNCTION 13742 ; VA 0x008881d0 ; FUN_008881d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_008881d0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba246;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede7d4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede7d4);
    if (DAT_01ede7d4 == -1) {
      uStack_8 = 0;
      uVar1 = FUN_00554ed0();
      uStack_1c = uStack_1c & 0xffffff00;
      _DAT_01ede7b0 = RBX::Reflection::Descriptor::vftable;
      _DAT_01ede7b4 = FUN_0086e3d0("Dictionary");
      _DAT_01ede7b8 = (ulonglong)uStack_1c;
      _DAT_01ede7c0 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ede7b0 = RBX::Reflection::Type::vftable;
      _DAT_01ede7cc = 0x24;
      _DAT_01ede7d0 = 0;
      DAT_01ede7d2 = 0;
      _DAT_01ede7c4 = uVar1;
      _DAT_01ede7c8 = _DAT_01ede7b4;
      FUN_00888bf0();
      _DAT_01ede7b0 =
           RBX::Reflection::
           TType<class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>_>
           ::vftable;
      FUN_016f3654(&LAB_01880860);
      FUN_016f37bf(&DAT_01ede7d4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede7b0;
}



/* FUNCTION 13743 ; VA 0x008882f0 ; FUN_008882f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_008882f0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba266;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede784) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede784);
    if (DAT_01ede784 == -1) {
      uStack_8 = 0;
      uVar1 = FUN_00554ed0();
      uStack_1c = uStack_1c & 0xffffff00;
      _DAT_01ede760 = RBX::Reflection::Descriptor::vftable;
      _DAT_01ede764 = FUN_0086e3d0("Array");
      _DAT_01ede768 = (ulonglong)uStack_1c;
      _DAT_01ede770 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ede760 = RBX::Reflection::Type::vftable;
      _DAT_01ede77c = 0x23;
      _DAT_01ede780 = 0;
      DAT_01ede782 = 0;
      _DAT_01ede774 = uVar1;
      _DAT_01ede778 = _DAT_01ede764;
      FUN_00888bf0();
      _DAT_01ede760 =
           RBX::Reflection::
           TType<class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>_>
           ::vftable;
      FUN_016f3654(&LAB_01880870);
      FUN_016f37bf(&DAT_01ede784);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede760;
}



/* FUNCTION 13744 ; VA 0x00888410 ; FUN_00888410 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00888410(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba286;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede7ac) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede7ac);
    if (DAT_01ede7ac == -1) {
      uStack_8 = 0;
      uVar1 = FUN_00554ed0();
      uStack_1c = uStack_1c & 0xffffff00;
      _DAT_01ede788 = RBX::Reflection::Descriptor::vftable;
      _DAT_01ede78c = FUN_0086e3d0("Variant");
      _DAT_01ede790 = (ulonglong)uStack_1c;
      _DAT_01ede798 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ede788 = RBX::Reflection::Type::vftable;
      _DAT_01ede7a4 = 0x26;
      _DAT_01ede7a8 = 0;
      DAT_01ede7aa = 0;
      _DAT_01ede79c = uVar1;
      _DAT_01ede7a0 = _DAT_01ede78c;
      FUN_00888bf0();
      _DAT_01ede788 = RBX::Reflection::TType<class_RBX::Reflection::Variant>::vftable;
      FUN_016f3654(&LAB_01880880);
      FUN_016f37bf(&DAT_01ede7ac);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede788;
}



/* FUNCTION 13745 ; VA 0x00888530 ; FUN_00888530 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00888530(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba2a6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede824) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede824);
    if (DAT_01ede824 == -1) {
      uStack_8 = 0;
      uVar1 = FUN_00554ed0();
      uStack_1c = uStack_1c & 0xffffff00;
      _DAT_01ede800 = RBX::Reflection::Descriptor::vftable;
      _DAT_01ede804 = FUN_0086e3d0(&DAT_0191cd0c);
      _DAT_01ede808 = (ulonglong)uStack_1c;
      _DAT_01ede810 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ede800 = RBX::Reflection::Type::vftable;
      _DAT_01ede81c = 0;
      _DAT_01ede820 = 0;
      DAT_01ede822 = 0;
      _DAT_01ede814 = uVar1;
      _DAT_01ede818 = _DAT_01ede804;
      FUN_00888bf0();
      _DAT_01ede800 = RBX::Reflection::TType<void>::vftable;
      FUN_016f3654(&LAB_01880890);
      FUN_016f37bf(&DAT_01ede824);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede800;
}



/* FUNCTION 13746 ; VA 0x00888650 ; FUN_00888650 */

void __thiscall FUN_00888650(undefined4 param_1,int *param_2)

{
  undefined4 *puVar1;
  undefined **ppuVar2;
  int iVar3;
  int iVar4;
  undefined **ppuVar5;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x24,param_1);
  if (puVar1 == (undefined4 *)0x0) {
    param_2[1] = 0;
    *param_2 = 0xc;
    return;
  }
  puVar1[1] = 1;
  ppuVar5 = (undefined **)&DAT_018be100;
  puVar1[2] = 1;
  *puVar1 = std::
            _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>
            ::vftable;
  *(undefined *)(puVar1 + 3) = 0;
  iVar3 = 0x26;
  do {
    iVar4 = iVar3 >> 1;
    if (ppuVar5[iVar4] < &DAT_0000000b) {
      ppuVar5 = ppuVar5 + iVar4 + 1;
      iVar4 = iVar3 + (-1 - iVar4);
    }
    iVar3 = iVar4;
  } while (0 < iVar4);
  ppuVar2 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar2 = ppuVar5;
  }
  puVar1[4] = *ppuVar2;
  puVar1[5] = 0;
  puVar1[6] = 0x3f800000;
  puVar1[7] = 0;
  puVar1[8] = 0;
  *param_2 = (int)(puVar1 + 3);
  param_2[1] = (int)puVar1;
  return;
}



/* FUNCTION 13747 ; VA 0x00888700 ; FUN_00888700 */

undefined4 * __thiscall
FUN_00888700(undefined4 *param_1,undefined4 param_2,undefined8 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  
  *param_1 = RBX::Reflection::Descriptor::vftable;
  uVar1 = FUN_0086e3d0(param_2);
  param_1[1] = uVar1;
  *(undefined8 *)(param_1 + 2) = param_3;
  param_1[4] = param_4;
  param_1[5] = param_5;
  return param_1;
}



/* FUNCTION 13748 ; VA 0x00888740 ; FUN_00888740 */

undefined4 * __thiscall FUN_00888740(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  
  *param_1 = param_2;
  param_1[1] = param_3;
  uVar1 = thunk_FUN_00888530();
  param_1[2] = uVar1;
  param_1[3] = 0;
  return param_1;
}



/* FUNCTION 13749 ; VA 0x00888780 ; FUN_00888780 */

undefined4 * __fastcall FUN_00888780(undefined4 *param_1)

{
  undefined4 uVar1;
  
  uVar1 = thunk_FUN_00888530();
  *param_1 = uVar1;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  return param_1;
}


