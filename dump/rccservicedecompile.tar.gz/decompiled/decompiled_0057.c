/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 14250 ; VA 0x0089e470 ; FUN_0089e470 */

undefined4 * __thiscall
FUN_0089e470(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbbb1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  ExceptionList = &pvStack_10;
  uVar3 = (**(code **)(param_1 + 0x38))(1);
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_0089f8b0;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = uVar3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14251 ; VA 0x0089e620 ; FUN_0089e620 */

undefined4 * __thiscall
FUN_0089e620(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbbf1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_0089f9f0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14252 ; VA 0x0089e7c0 ; FUN_0089e7c0 */

undefined4 * __thiscall
FUN_0089e7c0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbc31;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  ExceptionList = &pvStack_10;
  uVar3 = (**(code **)(param_1 + 0x38))(1);
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_0089fb30;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = uVar3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14253 ; VA 0x0089e970 ; FUN_0089e970 */

undefined4 * __thiscall FUN_0089e970(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  int *piVar6;
  int iStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbc71;
  pvStack_10 = ExceptionList;
  piVar6 = (int *)0x0;
  iVar1 = *(int *)(param_1 + 8);
  iStack_24 = 0;
  ExceptionList = &pvStack_10;
  if (iVar1 != 0) {
    piVar6 = (int *)(iVar1 + 4);
    iVar1 = *(int *)(iVar1 + 4);
    ExceptionList = &pvStack_10;
    while (iVar1 != 0) {
      LOCK();
      iVar3 = *piVar6;
      if (iVar1 == iVar3) {
        *piVar6 = iVar1 + 1;
        iVar3 = iVar1;
      }
      UNLOCK();
      if (iVar3 == iVar1) {
        iStack_24 = *(int *)(param_1 + 4);
        piVar6 = *(int **)(param_1 + 8);
        goto LAB_0089e9cb;
      }
      iVar1 = *piVar6;
    }
    piVar6 = (int *)0x0;
  }
LAB_0089e9cb:
  uStack_8 = 0;
  if (iStack_24 == 0) {
    *param_2 = 0;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar1 = piVar6[1] + -1;
      piVar6[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        piVar5 = piVar6 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar5 = (int *)param_3[1];
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = (int *)param_3[1];
  }
  uVar2 = *param_3;
  uStack_8 = 2;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  param_3 = (undefined4 *)FUN_01674e20(0x20);
  if (param_3 == (undefined4 *)0x0) {
    param_3 = (undefined4 *)0x0;
  }
  else {
    *param_3 = 0;
    param_3[1] = 1;
    param_3[2] = FUN_007037b0;
    param_3[3] = FUN_0068b170;
    param_3[4] = 0;
    param_3[5] = iStack_24;
    param_3[6] = 0;
    param_3[7] = 0;
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
    }
    param_3[6] = uVar2;
    param_3[7] = piVar5;
  }
  FUN_016797d0(param_3);
  *param_2 = param_3;
  if (param_3 != (undefined4 *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar1 = piVar5[1] + -1;
    piVar5[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      iVar1 = piVar5[2] + -1;
      piVar5[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar1 = piVar6[1] + -1;
    piVar6[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      piVar5 = piVar6 + 2;
      iVar1 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14254 ; VA 0x0089eb50 ; FUN_0089eb50 */

undefined4 __thiscall FUN_0089eb50(int param_1,int param_2)

{
  if (param_2 != 0) {
    do {
      if (param_2 == param_1) {
        return 1;
      }
      param_2 = *(int *)(param_2 + 0x34);
    } while (param_2 != 0);
  }
  return 0;
}



/* FUNCTION 14255 ; VA 0x0089eb80 ; FUN_0089eb80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0089eb80(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_008a7680();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01edf8cc) {
      FUN_016f3809(&DAT_01edf8cc);
      if (DAT_01edf8cc == -1) {
        _DAT_01edf8c0 = FUN_005c65e0;
        _DAT_01edf8c4 = FUN_005c65e0;
        _DAT_01edf8c8 = _guard_check_icall;
        FUN_016f37bf(&DAT_01edf8cc);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01edf8c0) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01edf8c0;
  }
  return;
}



/* FUNCTION 14256 ; VA 0x0089ec40 ; FUN_0089ec40 */

void FUN_0089ec40(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_008a7680();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14257 ; VA 0x0089ec80 ; FUN_0089ec80 */

void __thiscall FUN_0089ec80(int param_1,undefined4 param_2,undefined4 param_3)

{
  param_2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_3,&param_2);
  return;
}



/* FUNCTION 14258 ; VA 0x0089ecb0 ; FUN_0089ecb0 */

void __thiscall FUN_0089ecb0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba918;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(aiStack_28,param_2);
  uStack_8 = 0;
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,aiStack_28);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    iVar1 = aiStack_28[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_28[0] + -4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14259 ; VA 0x0089ed40 ; FUN_0089ed40 */

void __thiscall FUN_0089ed40(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined8 uStack_c;
  
  uStack_c = (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(param_2);
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,&uStack_c);
  return;
}



/* FUNCTION 14260 ; VA 0x0089ed80 ; FUN_0089ed80 */

undefined4 FUN_0089ed80(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_0061a170(param_1,param_2,param_3);
  return param_1;
}



/* FUNCTION 14261 ; VA 0x0089eda0 ; FUN_0089eda0 */

void FUN_0089eda0(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x40;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 14262 ; VA 0x0089ede0 ; FUN_0089ede0 */

void __thiscall FUN_0089ede0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_0088cdc0();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar2 = *(undefined **)(param_1 + 0x44);
  if (puVar2 == (undefined *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar6 = &uStack_35c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_1bc = FUN_0088daf0();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar2;
    iStack_1b8 = FUN_005c9ef0();
    puVar6 = &uStack_1bc;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14263 ; VA 0x0089f000 ; FUN_0089f000 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0089f000(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined8 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  undefined *puStack_1b8;
  undefined8 auStack_1b4 [25];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_0088cdc0();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar2 = *(undefined8 **)(param_1 + 0x44);
  if (puVar2 == (undefined8 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar6 = &uStack_35c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_1bc = FUN_0088ca00();
    puStack_1b8 = (undefined *)0x0;
    auStack_1b4[0] = *puVar2;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead488)
       && (FUN_016f3809(&DAT_01ead488), DAT_01ead488 == -1)) {
      _DAT_01ead47c = FUN_00619e80;
      _DAT_01ead480 = FUN_00619e80;
      DAT_01ead484 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead488);
    }
    puStack_1b8 = &DAT_01ead47c;
    puVar6 = &uStack_1bc;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_0088ca00();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, puStack_1b8 != (undefined *)0x0)) {
    (**(code **)(puStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14264 ; VA 0x0089f290 ; FUN_0089f290 */

void __thiscall FUN_0089f290(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  undefined4 *puStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar1);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(param_1 + 0x44);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar6 = &uStack_35c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_1bc = *puVar6;
    puStack_1b8 = (undefined4 *)0x0;
    puVar4 = (undefined4 *)puVar6[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(puVar6 + 2,auStack_1b4);
      puVar4 = (undefined4 *)puVar6[1];
    }
    puVar6 = &uStack_1bc;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
    puStack_1b8 = puVar4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_00888410();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar6);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, puStack_1b8 != (undefined4 *)0x0)) {
    (*(code *)puStack_1b8[2])(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14265 ; VA 0x0089f4c0 ; FUN_0089f4c0 */

undefined4 * __fastcall FUN_0089f4c0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint uVar6;
  int *piVar7;
  undefined4 *puVar8;
  undefined auStack_44 [24];
  undefined auStack_2c [4];
  undefined auStack_28 [4];
  int *piStack_24;
  undefined4 *puStack_20;
  int *piStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbc98;
  pvStack_10 = ExceptionList;
  if ((*(char *)(param_1 + 0x22) != '\0') && (*(int *)(param_1 + 0x34) != 0)) {
    ExceptionList = &pvStack_10;
    FUN_008a2380(auStack_44);
    uStack_8 = 0;
    uVar5 = FUN_005543f0();
    FUN_016756b0(auStack_2c,"The Parent property of %s is locked",uVar5);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_2c,&DAT_01c17198);
  }
  piVar7 = *(int **)(param_1 + 0x30);
  ExceptionList = &pvStack_10;
  if (piVar7 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar7[1] = piVar7[1] + 1;
    UNLOCK();
    piVar7 = *(int **)(param_1 + 0x30);
  }
  puVar8 = *(undefined4 **)(param_1 + 0x2c);
  uStack_8 = 1;
  puStack_20 = puVar8;
  piStack_1c = piVar7;
  piStack_14 = piVar7;
  FUN_0060dcd0(auStack_28,param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_008a5700(0);
  if (puVar8 != (undefined4 *)0x0) {
    puVar4 = (undefined4 *)puVar8[1];
    for (puVar8 = (undefined4 *)*puVar8; puVar8 != puVar4; puVar8 = puVar8 + 2) {
      (**(code **)(*(int *)*puVar8 + 0x2c))();
      piVar7 = piStack_14;
    }
  }
  puVar8 = *(undefined4 **)(*(int *)(param_1 + 0xc) + 0x70);
  puVar4 = *(undefined4 **)(*(int *)(param_1 + 0xc) + 0x74);
  uStack_18 = (uint)((int)puVar4 + (3 - (int)puVar8)) >> 2;
  if (puVar4 < puVar8) {
    uStack_18 = 0;
  }
  if (uStack_18 != 0) {
    uVar6 = 0;
    do {
      puVar4 = (undefined4 *)(**(code **)(*(int *)*puVar8 + 0x18))(param_1);
      uVar6 = uVar6 + 1;
      puVar8 = puVar8 + 1;
      piVar7 = piStack_14;
    } while (uVar6 != uStack_18);
  }
  iVar3 = *(int *)(param_1 + 0x44);
  if (iVar3 != 0) {
    if (*(int *)(iVar3 + 0x30) == 0) {
      puVar8 = (undefined4 *)0x0;
    }
    else {
      puVar4 = *(undefined4 **)(iVar3 + 0x2c);
      puVar8 = *(undefined4 **)(*(int *)(iVar3 + 0x3c) + (int)puVar4 * 4);
    }
    for (; puVar8 != (undefined4 *)0x0; puVar8 = (undefined4 *)*puVar8) {
      puVar4 = (undefined4 *)FUN_016795b0();
    }
    if (*(int *)(iVar3 + 0x48) == 0) {
      puVar8 = (undefined4 *)0x0;
    }
    else {
      puVar4 = *(undefined4 **)(iVar3 + 0x44);
      puVar8 = *(undefined4 **)(*(int *)(iVar3 + 0x54) + (int)puVar4 * 4);
    }
    for (; puVar8 != (undefined4 *)0x0; puVar8 = (undefined4 *)*puVar8) {
      puVar4 = (undefined4 *)FUN_016795b0();
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_24 + 1);
    uVar6 = *puVar1;
    puVar4 = (undefined4 *)*puVar1;
    *puVar1 = uVar6 - 1;
    UNLOCK();
    if (uVar6 - 1 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      puVar1 = (uint *)(piStack_24 + 2);
      uVar6 = *puVar1;
      puVar4 = (undefined4 *)*puVar1;
      *puVar1 = uVar6 - 1;
      UNLOCK();
      if (uVar6 - 1 == 0) {
        puVar4 = (undefined4 *)(**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (piVar7 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar7 + 1);
    uVar6 = *puVar1;
    puVar4 = (undefined4 *)*puVar1;
    *puVar1 = uVar6 - 1;
    UNLOCK();
    if (uVar6 - 1 == 0) {
      puVar4 = (undefined4 *)(**(code **)*piVar7)();
      LOCK();
      piVar2 = piVar7 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        puVar4 = (undefined4 *)(**(code **)(*piVar7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 14266 ; VA 0x0089f680 ; FUN_0089f680 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_0089f680(int param_1)

{
  int iVar1;
  void **ppvVar2;
  int *piVar3;
  int unaff_retaddr;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbcb8;
  if ((*(ushort *)(unaff_retaddr + -2) | 0x700) != 0xd7ff) {
    _DAT_01f6ab40 = _DAT_01f6ab40 | 0x2000;
    _DAT_01f6ab38 = _DAT_01f6ab38 | 0x2000;
  }
  iVar1 = *(int *)(param_1 + 0x2c);
  ppvVar2 = &pvStack_10;
  pvStack_10 = ExceptionList;
  while (ExceptionList = ppvVar2, iVar1 != 0) {
    iVar1 = *(int *)(iVar1 + 4);
    piVar3 = *(int **)(iVar1 + -4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
      piVar3 = *(int **)(iVar1 + -4);
    }
    uStack_8 = 3;
    (**(code **)(**(int **)(iVar1 + -8) + 0x2c))();
    uStack_8 = 0xffffffff;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar1 = piVar3[1] + -1;
      piVar3[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar1 = piVar3[2] + -1;
        piVar3[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    ppvVar2 = (void **)ExceptionList;
    iVar1 = *(int *)(param_1 + 0x2c);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14267 ; VA 0x0089f750 ; FUN_0089f750 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0089f750(int param_1,undefined4 param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uStack_f0;
  undefined *puStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbcf9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_02110da8);
  iStack_8 = 0;
  pcVar1 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar2;
  uStack_f0 = FUN_009ca3d0();
  uStack_e8 = param_2;
  puStack_ec = (undefined *)0x0;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf8dc) {
    FUN_016f3809(&DAT_01edf8dc);
    if (DAT_01edf8dc == -1) {
      _DAT_01edf8d0 = FUN_005c65e0;
      _DAT_01edf8d4 = FUN_005c65e0;
      _DAT_01edf8d8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01edf8dc);
    }
  }
  puStack_ec = &DAT_01edf8d0;
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,pcVar1);
  iStack_8._0_1_ = 2;
  (*pcVar1)(&uStack_1c);
  iStack_8._0_1_ = 3;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  iStack_8 = 4;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14268 ; VA 0x0089f8b0 ; FUN_0089f8b0 */

void FUN_0089f8b0(int param_1,int param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_0000001c;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbd41;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_f0 = FUN_0088cb40();
  uStack_ec = 0;
  FUN_0054ef60(&param_2);
  uStack_ec = FUN_005c9d30();
  uStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,piVar1);
  uStack_8._0_1_ = 3;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 4;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_01675290(uVar3);
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar4 = param_2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_2 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14269 ; VA 0x0089f9f0 ; FUN_0089f9f0 */

int FUN_0089f9f0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  code *pcVar4;
  undefined4 uVar5;
  int iVar6;
  undefined auStack_1c0 [416];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbd94;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290(DAT_02110da8);
  piVar3 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 2;
  pcVar4 = *(code **)(*piVar3 + 4);
  uStack_20 = uVar5;
  FUN_006874f0(&param_2);
  uStack_8._0_1_ = 3;
  FUN_006874f0(&param_4);
  uStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(auStack_1c0,&uStack_20,piVar3);
  uStack_8._0_1_ = 5;
  (*pcVar4)(&uStack_1c);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8._0_1_ = 2;
  FUN_016f32d1(auStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  iVar6 = FUN_01675290(uVar5);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_5)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 14270 ; VA 0x0089fb30 ; FUN_0089fb30 */

int FUN_0089fb30(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  code *pcVar4;
  undefined4 uVar5;
  int iVar6;
  undefined auStack_f0 [208];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbdd1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290(DAT_02110da8);
  piVar3 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar4 = *(code **)(*piVar3 + 4);
  uStack_20 = uVar5;
  FUN_006874f0(&param_2);
  uStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(auStack_f0,&uStack_20,piVar3);
  uStack_8._0_1_ = 3;
  (*pcVar4)(&uStack_1c);
  uStack_8._0_1_ = 4;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(auStack_f0,0xd0,1,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  iVar6 = FUN_01675290(uVar5);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 14271 ; VA 0x0089fc40 ; FUN_0089fc40 */

void __fastcall FUN_0089fc40(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar1 = (**(code **)(param_1 + 8))();
  uVar2 = (**(code **)(param_1 + 8))();
  FUN_00558b30(uVar2,uVar1);
  return;
}



/* FUNCTION 14272 ; VA 0x0089fc70 ; FUN_0089fc70 */

undefined __fastcall FUN_0089fc70(int param_1)

{
  undefined uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int aiStack_40 [5];
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba4b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = (**(code **)(param_1 + 8))(aiStack_40);
  uStack_8 = 0;
  uVar3 = (**(code **)(param_1 + 8))(auStack_28);
  uVar1 = FUN_00558b30(uVar2,uVar3);
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    uVar6 = auStack_28[0];
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(auStack_28[0] - 4);
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar5);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar6 = uStack_2c + 1;
    iVar4 = aiStack_40[0];
    if (0xfff < uVar6) {
      iVar4 = *(int *)(aiStack_40[0] + -4);
      uVar6 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 14273 ; VA 0x0089fd60 ; FUN_0089fd60 */

undefined4 __fastcall FUN_0089fd60(int param_1)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar1 = (**(code **)(param_1 + 8))();
  lVar2 = (**(code **)(param_1 + 8))();
  if (lVar1 != lVar2) {
    return 0;
  }
  return 1;
}



/* FUNCTION 14274 ; VA 0x0089fda0 ; FUN_0089fda0 */

bool __thiscall FUN_0089fda0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  
  iVar1 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  iVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_3);
  return iVar1 == iVar2;
}



/* FUNCTION 14275 ; VA 0x0089fdd0 ; FUN_0089fdd0 */

void __thiscall FUN_0089fdd0(uint param_1,int *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  int *piVar8;
  
  piVar8 = (int *)(-(uint)(param_2 != (int *)0x0) & (uint)(param_2 + 8));
  piVar6 = (int *)((-(uint)(param_1 != 0xfffffff4) & param_1) + 0x28);
  *piVar6 = *piVar6 + -1;
  puVar1 = (undefined4 *)piVar8[1];
  piVar6 = *(int **)(*piVar8 + 4);
  piVar2 = (int *)*puVar1;
  if (piVar6 == piVar8) {
    *(undefined4 **)(*piVar8 + 4) = puVar1;
    piVar6 = (int *)piVar8[1];
    if (piVar2 != piVar8) {
      piVar6 = (int *)*piVar6;
    }
  }
  else if (piVar2 == piVar8) {
    *piVar6 = (int)puVar1;
    piVar6 = (int *)piVar8[1];
  }
  else {
    *piVar6 = 0;
    *(int *)(*piVar8 + 4) = piVar8[1];
    piVar6 = *(int **)piVar8[1];
  }
  *piVar6 = *piVar8;
  uVar3 = param_2[5];
  if (0xf < uVar3) {
    iVar4 = *param_2;
    uVar7 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar7 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar7);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  FUN_01674ea0(param_2,0x28);
  return;
}



/* FUNCTION 14276 ; VA 0x0089fe90 ; FUN_0089fe90 */

undefined4 __thiscall FUN_0089fe90(int param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  uint uVar7;
  
  if (*(int *)(param_1 + 8) == 0) {
    return 0;
  }
  uVar4 = FUN_00563b90(param_2);
  uVar7 = uVar4 % *(uint *)(param_1 + 4);
  piVar1 = *(int **)(uVar7 * 4 + *(int *)(param_1 + 0x14));
  if (piVar1 != (int *)0x0) {
    piVar2 = (int *)*piVar1;
    while( true ) {
      if ((piVar2 == (int *)0x0) || ((uint)piVar2[1] % *(uint *)(param_1 + 4) != uVar7)) {
        return 0;
      }
      if ((piVar2[1] == uVar4) && (cVar3 = FUN_00558b30(param_2,piVar2 + 2), cVar3 != '\0')) break;
      piVar1 = piVar2;
      piVar2 = (int *)*piVar2;
    }
    uVar5 = FUN_0057d4d0(piVar1,*piVar2);
    if (*piVar1 != 0) {
      uVar4 = *(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 4);
      if (uVar7 == uVar4) {
        return uVar5;
      }
      *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4) = piVar1;
    }
    puVar6 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if ((int *)*puVar6 == piVar1) {
      *puVar6 = 0;
    }
    return uVar5;
  }
  return 0;
}



/* FUNCTION 14277 ; VA 0x0089ff70 ; FUN_0089ff70 */

undefined4 * __thiscall FUN_0089ff70(int param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  uint uVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  int *piVar10;
  
  if (param_3 != param_4) {
    piVar8 = *(int **)(param_1 + 4);
    piVar10 = param_3;
    piVar7 = param_3;
    if (param_4 != piVar8) {
      piVar7 = param_3 + 0xe;
      piVar9 = param_4 + 0xe;
      do {
        if (piVar10 != piVar9 + -0xe) {
          uVar1 = piVar7[-9];
          if (0xf < uVar1) {
            iVar2 = *piVar10;
            uVar6 = uVar1 + 1;
            iVar5 = iVar2;
            if (0xfff < uVar6) {
              iVar5 = *(int *)(iVar2 + -4);
              uVar6 = uVar1 + 0x24;
              if (0x1f < (iVar2 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(iVar5,uVar6);
          }
          piVar7[-10] = 0;
          piVar7[-9] = 0xf;
          *(undefined *)piVar10 = 0;
          iVar2 = piVar9[-0xd];
          iVar5 = piVar9[-0xc];
          iVar4 = piVar9[-0xb];
          *piVar10 = piVar9[-0xe];
          piVar10[1] = iVar2;
          piVar10[2] = iVar5;
          piVar10[3] = iVar4;
          iVar2 = piVar9[-9];
          piVar10[4] = piVar9[-10];
          piVar10[5] = iVar2;
          piVar9[-10] = 0;
          piVar9[-9] = 0xf;
          *(undefined *)(piVar9 + -0xe) = 0;
        }
        FUN_00d88cd0(piVar9 + -8);
        iVar2 = piVar9[-1];
        iVar5 = *piVar9;
        piVar9[-1] = 0;
        *piVar9 = 0;
        piVar7[-1] = iVar2;
        piVar3 = (int *)*piVar7;
        *piVar7 = iVar5;
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar2 = piVar3[2] + -1;
          piVar3[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
        piVar10 = piVar10 + 0x10;
        piVar7[1] = piVar9[1];
        piVar7 = piVar7 + 0x10;
        piVar3 = piVar9 + 2;
        piVar9 = piVar9 + 0x10;
      } while (piVar3 != piVar8);
      piVar8 = *(int **)(param_1 + 4);
      piVar7 = piVar10;
    }
    for (; piVar10 != piVar8; piVar10 = piVar10 + 0x10) {
      FUN_0089b470();
    }
    *(int **)(param_1 + 4) = piVar7;
  }
  *param_2 = param_3;
  return param_2;
}



/* FUNCTION 14278 ; VA 0x008a00a0 ; FUN_008a00a0 */

void __thiscall FUN_008a00a0(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  
  piVar6 = (int *)(param_3 + 8);
  piVar4 = *(int **)(param_1 + 4);
  if (piVar6 != piVar4) {
    piVar5 = (int *)(param_3 + 4);
    do {
      iVar1 = *piVar6;
      iVar2 = piVar6[1];
      *piVar6 = 0;
      piVar6[1] = 0;
      piVar5[-1] = iVar1;
      piVar3 = (int *)*piVar5;
      *piVar5 = iVar2;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar1 = piVar3[1] + -1;
        piVar3[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar1 = piVar3[2] + -1;
          piVar3[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      piVar6 = piVar6 + 2;
      piVar5 = piVar5 + 2;
    } while (piVar6 != piVar4);
    piVar4 = *(int **)(param_1 + 4);
  }
  piVar6 = (int *)piVar4[-1];
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar1 = piVar6[1] + -1;
    piVar6[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      piVar4 = piVar6 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + -8;
  *param_2 = param_3;
  return;
}



/* FUNCTION 14279 ; VA 0x008a0160 ; FUN_008a0160 */

void __thiscall FUN_008a0160(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(param_1 + 0x40))(param_3);
  return;
}



/* FUNCTION 14280 ; VA 0x008a0180 ; FUN_008a0180 */

void __thiscall FUN_008a0180(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(param_1 + 0x48))(param_3);
  return;
}



/* FUNCTION 14281 ; VA 0x008a01a0 ; FUN_008a01a0 */

undefined4 __thiscall FUN_008a01a0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined auStack_4c [8];
  int *piStack_44;
  int *piStack_3c;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbdf0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_3);
  uVar3 = FUN_009d09d0(aiStack_28,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  uStack_8 = 0;
  uVar3 = (**(code **)(param_1 + 0x38))(auStack_4c,uVar3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar3 = FUN_009d56e0(param_3,uVar3);
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_3c[2] + -1;
    piStack_3c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_3c + 4))();
    }
  }
  if (piStack_44 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_44[1] + -1;
    piStack_44[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_44)();
      LOCK();
      piVar1 = piStack_44 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_44 + 4))();
      }
    }
  }
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 14282 ; VA 0x008a02a0 ; FUN_008a02a0 */

undefined4 __thiscall FUN_008a02a0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01256300(param_3);
  uVar2 = FUN_009d05b0(param_3,param_4,1,iVar1 - param_4,param_1 + 0x40);
  uVar2 = (**(code **)(param_1 + 0x38))(aiStack_28,uVar2);
  uStack_8 = 0;
  uVar2 = FUN_009d5710(param_3,uVar2);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar1 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar1 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 14283 ; VA 0x008a0350 ; FUN_008a0350 */

undefined4 __thiscall FUN_008a0350(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = (**(code **)(param_1 + 0x38))(aiStack_28);
  uStack_8 = 0;
  uVar1 = FUN_009d5710(param_3,uVar1);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 14284 ; VA 0x008a03e0 ; FUN_008a03e0 */

undefined4 __thiscall FUN_008a03e0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbe08;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = (**(code **)(param_1 + 0x38))(auStack_18);
  uStack_8 = 0;
  uVar2 = FUN_009d5920(param_3,uVar2);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_14[1] + -1;
    piStack_14[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar1 = piStack_14[2] + -1;
      piStack_14[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 14285 ; VA 0x008a0460 ; FUN_008a0460 */

undefined4 __thiscall FUN_008a0460(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795998;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = (**(code **)(param_1 + 0x38))(auStack_18);
  uStack_8 = 0;
  uVar2 = FUN_009d5950(param_3,uVar2);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_14[1] + -1;
    piStack_14[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar1 = piStack_14[2] + -1;
      piStack_14[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 14286 ; VA 0x008a04e0 ; FUN_008a04e0 */

undefined4 __thiscall FUN_008a04e0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798e40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_3);
  uVar3 = FUN_009d09d0(aiStack_30,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  uStack_8 = 0;
  uVar3 = (**(code **)(param_1 + 0x38))(auStack_18,uVar3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar3 = FUN_009d5980(param_3,uVar3);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (0xf < uStack_1c) {
    uVar4 = uStack_1c + 1;
    iVar2 = aiStack_30[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_30[0] + -4);
      uVar4 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 14287 ; VA 0x008a05d0 ; FUN_008a05d0 */

undefined4 FUN_008a05d0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  int aiStack_34 [5];
  uint uStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbe30;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300(param_2);
  uVar2 = FUN_009d1aa0(param_2,param_3,2,iVar3 - param_3,iStack_14 + 0x44);
  uVar4 = FUN_009d09d0(aiStack_34,param_2,param_3,1,iVar3 - param_3,iStack_14 + 0x40);
  uStack_8 = 0;
  uVar4 = (**(code **)(iStack_14 + 0x38))(auStack_1c,uVar4,uVar2);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar4 = FUN_009d5980(param_2,uVar4);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (0xf < uStack_20) {
    uVar5 = uStack_20 + 1;
    iVar3 = aiStack_34[0];
    if (0xfff < uVar5) {
      iVar3 = *(int *)(aiStack_34[0] + -4);
      uVar5 = uStack_20 + 0x24;
      if (0x1f < (aiStack_34[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 14288 ; VA 0x008a06e0 ; FUN_008a06e0 */

undefined4 FUN_008a06e0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  float10 fVar6;
  int aiStack_3c [5];
  uint uStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  double dStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbe50;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300();
  fVar6 = (float10)FUN_009d0880(param_2,param_3,2,iVar3 - param_3,iStack_14 + 0x44);
  dStack_1c = (double)fVar6;
  uVar4 = FUN_009d09d0(aiStack_3c,param_2,param_3,1,iVar3 - param_3,iStack_14 + 0x40);
  uStack_8 = 0;
  pcVar2 = *(code **)(iStack_14 + 0x38);
  FUN_0054ef60(uVar4);
  uVar4 = (*pcVar2)(auStack_24);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar4 = FUN_009d5980(param_2,uVar4);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_20[1] + -1;
    piStack_20[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  if (0xf < uStack_28) {
    uVar5 = uStack_28 + 1;
    iVar3 = aiStack_3c[0];
    if (0xfff < uVar5) {
      iVar3 = *(int *)(aiStack_3c[0] + -4);
      uVar5 = uStack_28 + 0x24;
      if (0x1f < (aiStack_3c[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 14289 ; VA 0x008a0800 ; FUN_008a0800 */

undefined4 FUN_008a0800(int param_1,undefined4 param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uVar6;
  undefined4 uStack_200;
  undefined4 *puStack_1fc;
  undefined auStack_1f8 [144];
  undefined4 uStack_168;
  uint *puStack_164;
  undefined4 uStack_160;
  int iStack_15c;
  undefined4 uStack_158;
  int iStack_154;
  int iStack_150;
  undefined *puStack_14c;
  undefined4 uStack_148;
  int iStack_144;
  undefined4 uStack_140;
  int iStack_13c;
  int iStack_138;
  undefined4 uStack_134;
  undefined auStack_124 [4];
  int iStack_120;
  undefined auStack_11c [200];
  uint auStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  undefined *puStack_3c;
  code *pcStack_38;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017bbe73;
  pvStack_1c = ExceptionList;
  uStack_134 = param_2;
  iStack_138 = 0x8a083f;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_01256300();
  puStack_14c = auStack_124;
  iStack_138 = iStack_24 + 0x44;
  uStack_140 = 2;
  iStack_144 = param_3;
  uStack_148 = param_2;
  iStack_150 = 0x8a0860;
  iStack_13c = iVar3 - param_3;
  puStack_28 = (undefined4 *)FUN_009d1540();
  puStack_164 = auStack_54;
  iStack_150 = iStack_24 + 0x40;
  iStack_14 = 0;
  uStack_158 = 1;
  iStack_15c = param_3;
  uStack_160 = param_2;
  uStack_168 = 0x8a0881;
  iStack_154 = iVar3 - param_3;
  uStack_2c = FUN_009d09d0();
  puVar1 = puStack_28;
  puStack_3c = (undefined *)&uStack_200;
  iStack_14._0_1_ = 1;
  pcStack_38 = *(code **)(iStack_24 + 0x38);
  iStack_24 = *(int *)(iStack_24 + 0x3c) + param_1;
  uStack_200 = *puStack_28;
  puStack_1fc = (undefined4 *)0x0;
  puVar4 = (undefined4 *)puStack_28[1];
  puVar2 = &uStack_200;
  if (puVar4 != (undefined4 *)0x0) {
    (*(code *)*puVar4)(puStack_28 + 2,auStack_1f8);
    puVar4 = (undefined4 *)puVar1[1];
    puVar2 = (undefined4 *)puStack_3c;
  }
  puStack_3c = (undefined *)puVar2;
  puStack_1fc = puVar4;
  (*pcStack_38)(uStack_2c);
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  if (0xf < uStack_40) {
    uVar6 = uStack_40 + 1;
    uVar5 = auStack_54[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_54[0] - 4);
      uVar6 = uStack_40 + 0x24;
      if (0x1f < (auStack_54[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_44 = 0;
  uStack_40 = 0xf;
  auStack_54[0] = auStack_54[0] & 0xffffff00;
  iStack_14 = 2;
  if (iStack_120 != 0) {
    (**(code **)(iStack_120 + 8))(auStack_11c);
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 14290 ; VA 0x008a0960 ; FUN_008a0960 */

undefined4 __fastcall FUN_008a0960(int param_1)

{
  (**(code **)(param_1 + 0x38))();
  return 0;
}



/* FUNCTION 14291 ; VA 0x008a0980 ; FUN_008a0980 */

undefined4 __thiscall FUN_008a0980(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01256300(param_3);
  uVar2 = FUN_009d09d0(aiStack_28,param_3,param_4,1,iVar1 - param_4,param_1 + 0x40);
  uStack_8 = 0;
  uVar2 = (**(code **)(param_1 + 0x38))(uVar2);
  uVar2 = FUN_009d5ac0(param_3,uVar2);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar1 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar1 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 14292 ; VA 0x008a0a30 ; FUN_008a0a30 */

undefined4 __thiscall FUN_008a0a30(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined auStack_34 [4];
  int *piStack_30;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017bbe88;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300(param_3);
  puVar3 = (undefined4 *)FUN_009d1340(auStack_34,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  pcStack_28 = *(code **)(param_1 + 0x38);
  uStack_14 = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar4 = (*pcStack_28)(*puVar3,puVar3[1]);
  uVar4 = FUN_009d5ac0(param_3,uVar4);
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_30[1] + -1;
    piStack_30[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      iVar2 = piStack_30[2] + -1;
      piStack_30[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return uVar4;
}



/* FUNCTION 14293 ; VA 0x008a0b10 ; FUN_008a0b10 */

undefined4 __thiscall FUN_008a0b10(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa178;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = (**(code **)(param_1 + 0x38))(auStack_18);
  uStack_8 = 0;
  uVar2 = FUN_009d5870(param_3,uVar2);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_14[1] + -1;
    piStack_14[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar1 = piStack_14[2] + -1;
      piStack_14[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 14294 ; VA 0x008a0b90 ; FUN_008a0b90 */

undefined4 __thiscall FUN_008a0b90(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined auStack_f8 [4];
  int iStack_f4;
  undefined auStack_f0 [200];
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbeb3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01256300(param_3);
  uVar2 = FUN_009d09d0(aiStack_28,param_3,param_4,1,iVar1 - param_4,param_1 + 0x40);
  uStack_8 = 0;
  uVar2 = (**(code **)(param_1 + 0x38))(auStack_f8,uVar2);
  uStack_8._0_1_ = 1;
  uVar2 = FUN_009d5a20(param_3,uVar2);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iStack_f4 != 0) {
    (**(code **)(iStack_f4 + 8))(auStack_f0);
  }
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar1 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar1 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 14295 ; VA 0x008a0c70 ; FUN_008a0c70 */

undefined4 __thiscall FUN_008a0c70(byte *param_1,undefined4 param_2,undefined4 param_3)

{
  byte bVar1;
  undefined4 uVar2;
  
  bVar1 = *param_1;
  uVar2 = FUN_00563b90(param_3);
  FUN_00562fc0(param_2,uVar2,param_3,
               -(uint)(param_1 + bVar1 + 1 != (byte *)0x0) & (uint)(param_1 + bVar1 + 1 + 1));
  return param_2;
}



/* FUNCTION 14296 ; VA 0x008a0cb0 ; FUN_008a0cb0 */

int __thiscall FUN_008a0cb0(int param_1,byte *param_2)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  byte *pbVar4;
  uint uVar5;
  byte *pbVar6;
  int *piVar7;
  uint uVar8;
  bool bVar9;
  
  piVar7 = *(int **)(param_1 + 0x2c);
  if (piVar7 != (int *)0x0) {
    piVar1 = (int *)*piVar7;
    uVar8 = 0;
    uVar3 = piVar7[1] - (int)piVar1 >> 3;
    piVar7 = piVar1;
    if (uVar3 != 0) {
      do {
        pbVar4 = *(byte **)(*piVar7 + 0x28);
        pbVar6 = param_2;
        if (0xf < *(uint *)(param_2 + 0x14)) {
          pbVar6 = *(byte **)param_2;
        }
        uVar5 = *(uint *)(pbVar4 + 0x10);
        if (0xf < *(uint *)(pbVar4 + 0x14)) {
          pbVar4 = *(byte **)pbVar4;
        }
        if (uVar5 == *(uint *)(param_2 + 0x10)) {
          while (uVar2 = uVar5 - 4, 3 < uVar5) {
            if (*(int *)pbVar4 != *(int *)pbVar6) goto LAB_008a0d1d;
            pbVar4 = pbVar4 + 4;
            pbVar6 = pbVar6 + 4;
            uVar5 = uVar2;
          }
          if (uVar2 == 0xfffffffc) {
LAB_008a0d51:
            uVar5 = 0;
          }
          else {
LAB_008a0d1d:
            bVar9 = *pbVar4 < *pbVar6;
            if ((*pbVar4 == *pbVar6) &&
               ((uVar2 == 0xfffffffd ||
                ((bVar9 = pbVar4[1] < pbVar6[1], pbVar4[1] == pbVar6[1] &&
                 ((uVar2 == 0xfffffffe ||
                  ((bVar9 = pbVar4[2] < pbVar6[2], pbVar4[2] == pbVar6[2] &&
                   ((uVar2 == 0xffffffff || (bVar9 = pbVar4[3] < pbVar6[3], pbVar4[3] == pbVar6[3]))
                   )))))))))) goto LAB_008a0d51;
            uVar5 = -(uint)bVar9 | 1;
          }
          if (uVar5 == 0) {
            return piVar1[uVar8 * 2];
          }
        }
        uVar8 = uVar8 + 1;
        piVar7 = piVar7 + 2;
      } while (uVar8 < uVar3);
    }
  }
  return 0;
}



/* FUNCTION 14297 ; VA 0x008a0d80 ; FUN_008a0d80 */

int * __thiscall FUN_008a0d80(int param_1,int *param_2,undefined4 *param_3,char param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void **ppvVar5;
  char cVar6;
  undefined4 *puVar7;
  int iVar8;
  int *piVar9;
  undefined4 *puVar10;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbed0;
  pvStack_10 = ExceptionList;
  piVar9 = *(int **)(param_1 + 0x2c);
  if (piVar9 != (int *)0x0) {
    puVar10 = (undefined4 *)*piVar9;
    puStack_14 = (undefined4 *)piVar9[1];
    ExceptionList = &pvStack_10;
    ppvVar5 = &pvStack_10;
    iStack_18 = param_1;
    if (puVar10 != puStack_14) {
      do {
        piVar9 = (int *)puVar10[1];
        if (piVar9 != (int *)0x0) {
          LOCK();
          piVar9[1] = piVar9[1] + 1;
          UNLOCK();
          piVar9 = (int *)puVar10[1];
        }
        piStack_1c = (int *)*puVar10;
        uStack_8 = 0;
        puVar7 = param_3;
        if (0xf < (uint)param_3[5]) {
          puVar7 = (undefined4 *)*param_3;
        }
        cVar6 = FUN_008931b0(puVar7);
        if (cVar6 != '\0') {
          param_2[1] = (int)piVar9;
          *param_2 = (int)piStack_1c;
          ExceptionList = pvStack_10;
          return param_2;
        }
        uStack_8 = 0xffffffff;
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar8 = piVar9[1] + -1;
          piVar9[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piVar9)();
            LOCK();
            iVar8 = piVar9[2] + -1;
            piVar9[2] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
        puVar10 = puVar10 + 2;
        ppvVar5 = (void **)ExceptionList;
      } while (puVar10 != puStack_14);
    }
    ExceptionList = ppvVar5;
    if (param_4 != '\0') {
      iVar3 = (*(int **)(iStack_18 + 0x2c))[1];
      for (iVar8 = **(int **)(iStack_18 + 0x2c); iVar8 != iVar3; iVar8 = iVar8 + 8) {
        piVar9 = *(int **)(iVar8 + 4);
        if (piVar9 != (int *)0x0) {
          LOCK();
          piVar9[1] = piVar9[1] + 1;
          UNLOCK();
          piVar9 = *(int **)(iVar8 + 4);
        }
        uStack_8 = 1;
        FUN_008a0d80(&iStack_20,param_3,1);
        piVar2 = piStack_1c;
        iVar4 = iStack_20;
        if (iStack_20 != 0) {
          iStack_20 = 0;
          *param_2 = iVar4;
          param_2[1] = (int)piStack_1c;
          piStack_1c = (int *)0x0;
          if (piVar9 != (int *)0x0) {
            LOCK();
            iVar8 = piVar9[1] + -1;
            piVar9[1] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)*piVar9)();
              LOCK();
              piVar2 = piVar9 + 2;
              iVar8 = *piVar2;
              *piVar2 = *piVar2 + -1;
              UNLOCK();
              if (iVar8 == 1) {
                (**(code **)(*piVar9 + 4))();
              }
            }
          }
          ExceptionList = pvStack_10;
          return param_2;
        }
        if (piStack_1c != (int *)0x0) {
          LOCK();
          iVar4 = piStack_1c[1] + -1;
          piStack_1c[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piStack_1c)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar4 = *piVar1 + -1;
            *piVar1 = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        uStack_8 = 0xffffffff;
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar4 = piVar9[1] + -1;
          piVar9[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar9)();
            LOCK();
            iVar4 = piVar9[2] + -1;
            piVar9[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
      }
    }
  }
  *param_2 = 0;
  param_2[1] = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14298 ; VA 0x008a0f90 ; FUN_008a0f90 */

undefined4 * __thiscall FUN_008a0f90(int param_1,undefined4 *param_2,byte *param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  byte *pbVar4;
  uint uVar5;
  byte *pbVar6;
  bool bVar7;
  undefined4 uStack_c;
  int *piStack_8;
  
  iVar2 = *(int *)(param_1 + 0x34);
  do {
    if (iVar2 == 0) {
      uStack_c = 0;
      piStack_8 = (int *)0x0;
LAB_008a1020:
      *param_2 = 0;
      param_2[1] = 0;
      if (piStack_8 != (int *)0x0) {
        LOCK();
        piStack_8[1] = piStack_8[1] + 1;
        UNLOCK();
      }
      *param_2 = uStack_c;
      param_2[1] = piStack_8;
      if (piStack_8 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_8[1] + -1;
        piStack_8[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_8)();
          LOCK();
          piVar1 = piStack_8 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piStack_8 + 4))();
          }
        }
      }
      return param_2;
    }
    pbVar4 = *(byte **)(iVar2 + 0x28);
    pbVar6 = param_3;
    if (0xf < *(uint *)(param_3 + 0x14)) {
      pbVar6 = *(byte **)param_3;
    }
    uVar5 = *(uint *)(pbVar4 + 0x10);
    if (0xf < *(uint *)(pbVar4 + 0x14)) {
      pbVar4 = *(byte **)pbVar4;
    }
    if (uVar5 == *(uint *)(param_3 + 0x10)) {
      while (uVar3 = uVar5 - 4, 3 < uVar5) {
        if (*(int *)pbVar4 != *(int *)pbVar6) goto LAB_008a0fdb;
        pbVar4 = pbVar4 + 4;
        pbVar6 = pbVar6 + 4;
        uVar5 = uVar3;
      }
      if (uVar3 == 0xfffffffc) {
LAB_008a100f:
        uVar5 = 0;
      }
      else {
LAB_008a0fdb:
        bVar7 = *pbVar4 < *pbVar6;
        if ((*pbVar4 == *pbVar6) &&
           ((uVar3 == 0xfffffffd ||
            ((bVar7 = pbVar4[1] < pbVar6[1], pbVar4[1] == pbVar6[1] &&
             ((uVar3 == 0xfffffffe ||
              ((bVar7 = pbVar4[2] < pbVar6[2], pbVar4[2] == pbVar6[2] &&
               ((uVar3 == 0xffffffff || (bVar7 = pbVar4[3] < pbVar6[3], pbVar4[3] == pbVar6[3]))))))
             )))))) goto LAB_008a100f;
        uVar5 = -(uint)bVar7 | 1;
      }
      if (uVar5 == 0) {
        FUN_0060dcd0(&uStack_c,iVar2);
        goto LAB_008a1020;
      }
    }
    iVar2 = *(int *)(iVar2 + 0x34);
  } while( true );
}



/* FUNCTION 14299 ; VA 0x008a1090 ; FUN_008a1090 */

undefined4 * __thiscall FUN_008a1090(int param_1,undefined4 *param_2,byte *param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  byte *pbVar4;
  uint uVar5;
  byte *pbVar6;
  bool bVar7;
  undefined4 uStack_c;
  int *piStack_8;
  
  piVar1 = *(int **)(param_1 + 0x34);
  do {
    if (piVar1 == (int *)0x0) {
      uStack_c = 0;
      piStack_8 = (int *)0x0;
LAB_008a112b:
      *param_2 = 0;
      param_2[1] = 0;
      if (piStack_8 != (int *)0x0) {
        LOCK();
        piStack_8[1] = piStack_8[1] + 1;
        UNLOCK();
      }
      *param_2 = uStack_c;
      param_2[1] = piStack_8;
      if (piStack_8 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_8[1] + -1;
        piStack_8[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_8)();
          LOCK();
          piVar1 = piStack_8 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piStack_8 + 4))();
          }
        }
      }
      return param_2;
    }
    pbVar4 = (byte *)(**(code **)(*piVar1 + 0x10))();
    pbVar6 = param_3;
    if (0xf < *(uint *)(param_3 + 0x14)) {
      pbVar6 = *(byte **)param_3;
    }
    uVar5 = *(uint *)(pbVar4 + 0x10);
    if (0xf < *(uint *)(pbVar4 + 0x14)) {
      pbVar4 = *(byte **)pbVar4;
    }
    if (uVar5 == *(uint *)(param_3 + 0x10)) {
      while (uVar3 = uVar5 - 4, 3 < uVar5) {
        if (*(int *)pbVar4 != *(int *)pbVar6) goto LAB_008a10e6;
        pbVar4 = pbVar4 + 4;
        pbVar6 = pbVar6 + 4;
        uVar5 = uVar3;
      }
      if (uVar3 == 0xfffffffc) {
LAB_008a111a:
        uVar5 = 0;
      }
      else {
LAB_008a10e6:
        bVar7 = *pbVar4 < *pbVar6;
        if ((*pbVar4 == *pbVar6) &&
           ((uVar3 == 0xfffffffd ||
            ((bVar7 = pbVar4[1] < pbVar6[1], pbVar4[1] == pbVar6[1] &&
             ((uVar3 == 0xfffffffe ||
              ((bVar7 = pbVar4[2] < pbVar6[2], pbVar4[2] == pbVar6[2] &&
               ((uVar3 == 0xffffffff || (bVar7 = pbVar4[3] < pbVar6[3], pbVar4[3] == pbVar6[3]))))))
             )))))) goto LAB_008a111a;
        uVar5 = -(uint)bVar7 | 1;
      }
      if (uVar5 == 0) {
        FUN_0060dcd0(&uStack_c,piVar1);
        goto LAB_008a112b;
      }
    }
    piVar1 = (int *)piVar1[0xd];
  } while( true );
}



/* FUNCTION 14300 ; VA 0x008a1190 ; FUN_008a1190 */

undefined4 * __thiscall FUN_008a1190(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 uStack_c;
  int *piStack_8;
  
  iVar2 = *(int *)(param_1 + 0x34);
  do {
    if (iVar2 == 0) {
      uStack_c = 0;
      piStack_8 = (int *)0x0;
LAB_008a11c4:
      *param_2 = 0;
      param_2[1] = 0;
      if (piStack_8 != (int *)0x0) {
        LOCK();
        piStack_8[1] = piStack_8[1] + 1;
        UNLOCK();
      }
      *param_2 = uStack_c;
      param_2[1] = piStack_8;
      if (piStack_8 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_8[1] + -1;
        piStack_8[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_8)();
          LOCK();
          piVar1 = piStack_8 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piStack_8 + 4))();
          }
        }
        return param_2;
      }
      return param_2;
    }
    puVar4 = param_3;
    if (0xf < (uint)param_3[5]) {
      puVar4 = (undefined4 *)*param_3;
    }
    cVar3 = FUN_008931b0(puVar4);
    if (cVar3 != '\0') {
      FUN_0060dcd0(&uStack_c,iVar2);
      goto LAB_008a11c4;
    }
    iVar2 = *(int *)(iVar2 + 0x34);
  } while( true );
}



/* FUNCTION 14301 ; VA 0x008a1240 ; FUN_008a1240 */

uint __thiscall FUN_008a1240(int param_1,byte *param_2)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  byte *pbVar7;
  byte *pbVar8;
  int *piVar9;
  int iVar10;
  uint uVar11;
  bool bVar12;
  
  uVar11 = 0;
  piVar9 = *(int **)(param_1 + 0x2c);
  if (piVar9 != (int *)0x0) {
    piVar1 = (int *)*piVar9;
    uVar3 = piVar9[1] - (int)piVar1 >> 3;
    if (uVar3 != 0) {
      piVar9 = piVar1;
      do {
        pbVar7 = *(byte **)(*piVar9 + 0x28);
        pbVar8 = param_2;
        if (0xf < *(uint *)(param_2 + 0x14)) {
          pbVar8 = *(byte **)param_2;
        }
        uVar4 = *(uint *)(pbVar7 + 0x10);
        if (0xf < *(uint *)(pbVar7 + 0x14)) {
          pbVar7 = *(byte **)pbVar7;
        }
        if (uVar4 == *(uint *)(param_2 + 0x10)) {
          while (uVar2 = uVar4 - 4, 3 < uVar4) {
            if (*(int *)pbVar7 != *(int *)pbVar8) goto LAB_008a12ba;
            pbVar7 = pbVar7 + 4;
            pbVar8 = pbVar8 + 4;
            uVar4 = uVar2;
          }
          if (uVar2 == 0xfffffffc) {
LAB_008a12ee:
            uVar4 = 0;
          }
          else {
LAB_008a12ba:
            bVar12 = *pbVar7 < *pbVar8;
            if ((*pbVar7 == *pbVar8) &&
               ((uVar2 == 0xfffffffd ||
                ((bVar12 = pbVar7[1] < pbVar8[1], pbVar7[1] == pbVar8[1] &&
                 ((uVar2 == 0xfffffffe ||
                  ((bVar12 = pbVar7[2] < pbVar8[2], pbVar7[2] == pbVar8[2] &&
                   ((uVar2 == 0xffffffff || (bVar12 = pbVar7[3] < pbVar8[3], pbVar7[3] == pbVar8[3])
                    ))))))))))) goto LAB_008a12ee;
            uVar4 = -(uint)bVar12 | 1;
          }
          if (uVar4 == 0) {
            uVar11 = piVar1[uVar11 * 2];
            goto LAB_008a130f;
          }
        }
        uVar11 = uVar11 + 1;
        piVar9 = piVar9 + 2;
      } while (uVar11 < uVar3);
    }
    uVar11 = 0;
  }
LAB_008a130f:
  if (((DAT_01d62be0 != '\0') && (uVar11 != 0)) &&
     (iVar10 = *(int *)(uVar11 + 0xc), iVar5 = FUN_00c91ca0(),
     (uint)*(ushort *)(iVar10 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
     (uint)*(ushort *)(iVar5 + 0x1da))) {
    param_2 = (byte *)FUN_0097bfc0(param_1);
    iVar10 = *(int *)(uVar11 + 0x34);
    if ((iVar10 == 0) ||
       (iVar5 = *(int *)(iVar10 + 0xc), iVar6 = FUN_00913630(),
       (uint)*(ushort *)(iVar6 + 0x1da) <
       (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
      iVar10 = 0;
    }
    if (((param_2 != (byte *)0x0) && (iVar10 != 0)) && (param_2 != (byte *)iVar10)) {
      FUN_00898c50(&DAT_01edf5c4,&param_2);
    }
  }
  return uVar11;
}



/* FUNCTION 14302 ; VA 0x008a13b0 ; FUN_008a13b0 */

int __thiscall FUN_008a13b0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  
  iVar2 = FUN_008a1240(param_2);
  if (iVar2 == 0) {
    piVar1 = *(int **)(param_1 + 0x2c);
    if ((piVar1 != (int *)0x0) && (uVar3 = 0, piVar1[1] - *piVar1 >> 3 != 0)) {
      do {
        iVar2 = FUN_008a13b0(param_2);
        if (iVar2 != 0) {
          return iVar2;
        }
        uVar3 = uVar3 + 1;
      } while (uVar3 < (uint)(piVar1[1] - *piVar1 >> 3));
    }
    iVar2 = 0;
  }
  return iVar2;
}



/* FUNCTION 14303 ; VA 0x008a1410 ; FUN_008a1410 */

undefined4 __thiscall FUN_008a1410(int param_1,undefined4 param_2,byte *param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  byte *pbVar3;
  uint uVar4;
  undefined4 uVar5;
  byte *pbVar6;
  undefined4 *puVar7;
  bool bVar8;
  
  puVar7 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar7 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)puVar7[1];
    for (puVar7 = (undefined4 *)*puVar7; puVar7 != puVar1; puVar7 = puVar7 + 2) {
      pbVar3 = (byte *)(**(code **)(*(int *)*puVar7 + 0x10))();
      pbVar6 = param_3;
      if (0xf < *(uint *)(param_3 + 0x14)) {
        pbVar6 = *(byte **)param_3;
      }
      uVar4 = *(uint *)(pbVar3 + 0x10);
      if (0xf < *(uint *)(pbVar3 + 0x14)) {
        pbVar3 = *(byte **)pbVar3;
      }
      if (uVar4 == *(uint *)(param_3 + 0x10)) {
        while (uVar2 = uVar4 - 4, 3 < uVar4) {
          if (*(int *)pbVar3 != *(int *)pbVar6) goto LAB_008a1476;
          pbVar3 = pbVar3 + 4;
          pbVar6 = pbVar6 + 4;
          uVar4 = uVar2;
        }
        if (uVar2 == 0xfffffffc) {
LAB_008a14aa:
          uVar4 = 0;
        }
        else {
LAB_008a1476:
          bVar8 = *pbVar3 < *pbVar6;
          if ((*pbVar3 == *pbVar6) &&
             ((uVar2 == 0xfffffffd ||
              ((bVar8 = pbVar3[1] < pbVar6[1], pbVar3[1] == pbVar6[1] &&
               ((uVar2 == 0xfffffffe ||
                ((bVar8 = pbVar3[2] < pbVar6[2], pbVar3[2] == pbVar6[2] &&
                 ((uVar2 == 0xffffffff || (bVar8 = pbVar3[3] < pbVar6[3], pbVar3[3] == pbVar6[3]))))
                )))))))) goto LAB_008a14aa;
          uVar4 = -(uint)bVar8 | 1;
        }
        if (uVar4 == 0) {
          uVar5 = *puVar7;
          goto LAB_008a14bd;
        }
      }
    }
  }
  uVar5 = 0;
LAB_008a14bd:
  FUN_0060dcd0(param_2,uVar5);
  return param_2;
}



/* FUNCTION 14304 ; VA 0x008a14e0 ; FUN_008a14e0 */

undefined4 __thiscall FUN_008a14e0(int param_1,byte *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  byte *pbVar3;
  uint uVar4;
  byte *pbVar5;
  undefined4 *puVar6;
  bool bVar7;
  
  puVar6 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar6 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)puVar6[1];
    for (puVar6 = (undefined4 *)*puVar6; puVar6 != puVar1; puVar6 = puVar6 + 2) {
      pbVar3 = (byte *)(**(code **)(*(int *)*puVar6 + 0x10))();
      pbVar5 = param_2;
      if (0xf < *(uint *)(param_2 + 0x14)) {
        pbVar5 = *(byte **)param_2;
      }
      uVar4 = *(uint *)(pbVar3 + 0x10);
      if (0xf < *(uint *)(pbVar3 + 0x14)) {
        pbVar3 = *(byte **)pbVar3;
      }
      if (uVar4 == *(uint *)(param_2 + 0x10)) {
        while (uVar2 = uVar4 - 4, 3 < uVar4) {
          if (*(int *)pbVar3 != *(int *)pbVar5) goto LAB_008a1546;
          pbVar3 = pbVar3 + 4;
          pbVar5 = pbVar5 + 4;
          uVar4 = uVar2;
        }
        if (uVar2 == 0xfffffffc) {
LAB_008a157a:
          uVar4 = 0;
        }
        else {
LAB_008a1546:
          bVar7 = *pbVar3 < *pbVar5;
          if ((*pbVar3 == *pbVar5) &&
             ((uVar2 == 0xfffffffd ||
              ((bVar7 = pbVar3[1] < pbVar5[1], pbVar3[1] == pbVar5[1] &&
               ((uVar2 == 0xfffffffe ||
                ((bVar7 = pbVar3[2] < pbVar5[2], pbVar3[2] == pbVar5[2] &&
                 ((uVar2 == 0xffffffff || (bVar7 = pbVar3[3] < pbVar5[3], pbVar3[3] == pbVar5[3]))))
                )))))))) goto LAB_008a157a;
          uVar4 = -(uint)bVar7 | 1;
        }
        if (uVar4 == 0) {
          return *puVar6;
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 14305 ; VA 0x008a15a0 ; FUN_008a15a0 */

undefined4 * FUN_008a15a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_008a0d80(auStack_c,param_2,param_3);
  uVar2 = *puVar4;
  *param_1 = 0;
  param_1[1] = 0;
  if (puVar4[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = uVar2;
  param_1[1] = puVar4[1];
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 14306 ; VA 0x008a1620 ; FUN_008a1620 */

void FUN_008a1620(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar2 = FUN_009ca3d0();
  if (iVar1 == iVar2) {
    piVar3 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_005e6780(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14307 ; VA 0x008a1670 ; FUN_008a1670 */

/* WARNING: Removing unreachable block (ram,0x008a1714) */
/* WARNING: Removing unreachable block (ram,0x008a1722) */
/* WARNING: Removing unreachable block (ram,0x008a1758) */
/* WARNING: Removing unreachable block (ram,0x008a1732) */

void __thiscall FUN_008a1670(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  param_3 = (int *)*param_3;
  iVar1 = *param_3;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088cb40();
  if (iVar1 == iVar2) {
    piVar3 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_0054ef60(piVar3);
    uStack_8 = 0;
    (**(code **)(param_1 + 0x38))(1);
    FUN_006ecaa0(uStack_2c,uStack_28,uStack_24,uStack_20,CONCAT44(uStack_18,uStack_1c));
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14308 ; VA 0x008a1760 ; FUN_008a1760 */

void FUN_008a1760(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbef8;
  pvStack_10 = ExceptionList;
  iVar6 = *param_2;
  iVar5 = *(int *)(iVar6 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088cdc0();
  if (iVar5 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar3 = (undefined4 *)(iVar6 + 0xd8);
  if (*(int *)(iVar6 + 0xd4) == 0) {
    puVar3 = (undefined4 *)0x0;
  }
  iVar6 = puVar3[1];
  if (iVar6 != 0) {
    LOCK();
    *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
    UNLOCK();
    iVar6 = puVar3[1];
  }
  uVar1 = *puVar3;
  param_2 = (int *)*param_2;
  uStack_8 = 0;
  iVar5 = *param_2;
  iVar2 = FUN_0088cdc0();
  if (iVar5 == iVar2) {
    piVar4 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar4 = (int *)0x0;
    }
    iVar5 = piVar4[1];
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
      iVar5 = piVar4[1];
    }
    uStack_8 = 2;
    FUN_0089bce0(*piVar4,iVar5,uVar1,iVar6);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14309 ; VA 0x008a1870 ; FUN_008a1870 */

void __thiscall FUN_008a1870(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  param_3 = (int *)*param_3;
  iVar3 = *param_3;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0088cdc0();
  if (iVar3 == iVar1) {
    piVar2 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar2 = (int *)0x0;
    }
    iVar3 = piVar2[1];
    if (iVar3 != 0) {
      LOCK();
      *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
      UNLOCK();
      iVar3 = piVar2[1];
    }
    iVar1 = *piVar2;
    uStack_8 = 0;
    (**(code **)(param_1 + 0x38))(1);
    FUN_0089be10(iVar1,iVar3);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14310 ; VA 0x008a1920 ; FUN_008a1920 */

undefined4 * __thiscall FUN_008a1920(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  iVar2 = *(int *)(param_1 + 0xc);
  iVar3 = FUN_00e70750();
  if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
      (uint)*(ushort *)(iVar3 + 0x1da)) {
    FUN_0060dcd0(param_2,param_1);
    return param_2;
  }
  uVar4 = FUN_00899290();
  puVar5 = (undefined4 *)FUN_0060dcd0(auStack_c,uVar4);
  uVar4 = *puVar5;
  *param_2 = 0;
  param_2[1] = 0;
  if (puVar5[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_2 = uVar4;
  param_2[1] = puVar5[1];
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_8[1] + -1;
    piStack_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  return param_2;
}



/* FUNCTION 14311 ; VA 0x008a19e0 ; FUN_008a19e0 */

undefined4 * __thiscall FUN_008a19e0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined auStack_10 [4];
  undefined auStack_c [4];
  int *piStack_8;
  
  if (DAT_01d644e8 == '\0') {
    FUN_016756b0(auStack_10,"Actors are not currently enabled");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_10,&DAT_01c17198);
  }
  iVar2 = *(int *)(param_1 + 0xc);
  iVar3 = FUN_00e70750();
  if ((uint)*(ushort *)(iVar3 + 0x1da) <
      (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
    uVar4 = FUN_00899290();
    puVar5 = (undefined4 *)FUN_0060dcd0(auStack_c,uVar4);
    uVar4 = *puVar5;
    *param_2 = 0;
    param_2[1] = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *param_2 = uVar4;
    param_2[1] = puVar5[1];
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_8[1] + -1;
      piStack_8[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piStack_8 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return param_2;
  }
  FUN_0060dcd0(param_2,param_1);
  return param_2;
}



/* FUNCTION 14312 ; VA 0x008a1ac0 ; FUN_008a1ac0 */

undefined4 * __thiscall FUN_008a1ac0(int param_1,undefined4 *param_2,int param_3)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  byte *pbVar4;
  undefined auStack_10 [12];
  
  if (DAT_01d62c08 == '\0') {
    if (DAT_01d62c18 != '\0') {
      uVar3 = FUN_01255560();
      cVar2 = FUN_01255580(uVar3,5);
      if (cVar2 != '\0') goto LAB_008a1af4;
    }
    FUN_016756b0(auStack_10,"Attributes are not currently enabled");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_10,&DAT_01c17198);
  }
LAB_008a1af4:
  iVar1 = param_3;
  if (*(int *)(param_1 + 0x44) != 0) {
    pbVar4 = *(byte **)(*(int *)(param_1 + 0x44) + 0x5c);
    pbVar4 = pbVar4 + *pbVar4 + 1;
    uVar3 = FUN_00563b90(param_3);
    FUN_00562fc0(&param_3,uVar3,iVar1,-(uint)(pbVar4 != (byte *)0x0) & (uint)(pbVar4 + 1));
    if (param_3 != 0) {
      FUN_0056a440(param_3 + 0x20);
      return param_2;
    }
  }
  uVar3 = FUN_00888530();
  *param_2 = uVar3;
  param_2[1] = 0;
  return param_2;
}



/* FUNCTION 14313 ; VA 0x008a1b90 ; FUN_008a1b90 */

undefined4 __thiscall FUN_008a1b90(int *param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  char cVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  uint uVar9;
  undefined auStack_6c [4];
  undefined4 uStack_68;
  undefined4 *puStack_64;
  int iStack_60;
  char *pcStack_5c;
  uint *puStack_58;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined auStack_28 [4];
  undefined4 uStack_24;
  int *piStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbf39;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  piStack_1c = param_1;
  if (DAT_01d62c08 == '\0') {
    ExceptionList = &pvStack_10;
    if (DAT_01d62c18 != '\0') {
      puStack_58 = (uint *)0x8a1bd5;
      ExceptionList = &pvStack_10;
      pcStack_5c = (char *)FUN_01255560();
      puStack_58 = (uint *)0x5;
      iStack_60 = 0x8a1bdd;
      cVar5 = FUN_01255580();
      if (cVar5 != '\0') goto LAB_008a1be8;
    }
    pcStack_5c = auStack_28;
    puStack_58 = (uint *)0x191e4a4;
    iStack_60 = 0x8a1e33;
    FUN_016756b0();
    pcStack_5c = auStack_28;
    puStack_58 = (uint *)&DAT_01c17198;
                    /* WARNING: Subroutine does not return */
    iStack_60 = 0x8a1e44;
    FUN_0170c2a8();
  }
LAB_008a1be8:
  iVar6 = param_1[0x11];
  if (iVar6 == 0) {
    puStack_58 = (uint *)0x8a1bf6;
    iVar6 = (**(code **)(*param_1 + 0x14))();
    puVar8 = (undefined4 *)param_1[0x11];
    param_1[0x11] = iVar6;
    if (puVar8 != (undefined4 *)0x0) {
      puStack_58 = (uint *)0x1;
      pcStack_5c = (char *)0x8a1c06;
      (**(code **)*puVar8)();
      iVar6 = param_1[0x11];
    }
  }
  puVar8 = param_3;
  iStack_14 = iVar6 + 0x40;
  puStack_58 = param_3;
  iVar6 = *(byte *)(iVar6 + 0x40) + 1 + iStack_14;
  pcStack_5c = (char *)0x8a1c1f;
  iStack_60 = FUN_00563b90();
  puStack_58 = (uint *)(-(uint)(iVar6 != 0) & iVar6 + 1U);
  pcStack_5c = (char *)puVar8;
  puStack_64 = &param_3;
  uStack_68 = 0x8a1c39;
  FUN_008992d0();
  uStack_24 = 0;
  piStack_20 = (int *)0x0;
  uStack_8 = 0;
  if (param_3 == (undefined4 *)0x0) {
    puStack_58 = (uint *)auStack_30;
    pcStack_5c = (char *)0x8a1c61;
    puVar7 = (undefined4 *)FUN_00899790();
    piVar4 = piStack_2c;
    uStack_24 = *puVar7;
    piStack_20 = (int *)puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar6 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        puStack_58 = (uint *)0x8a1c92;
        (**(code **)*piStack_2c)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar6 = *piVar1 + -1;
        *piVar1 = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          puStack_58 = (uint *)0x8a1ca2;
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    puStack_58 = &uStack_24;
    pcStack_5c = (char *)puVar8;
    iStack_60 = 0x8a1caf;
    FUN_0089b6f0();
  }
  else {
    puStack_58 = param_3 + 8;
  }
  pcStack_5c = (char *)0x8a1cc0;
  FUN_0056ecd0();
  if (DAT_01edf7dc == 0) {
    puStack_58 = (uint *)0x8a1ccf;
    iVar6 = FUN_00897b90();
    DAT_01edf7dc = *(int *)(iVar6 + 4);
  }
  iVar6 = DAT_01edf7dc;
  puStack_58 = (uint *)(puVar8[4] + 0x10);
  uStack_8._0_1_ = 1;
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  uStack_18 = 2;
  pcStack_5c = (char *)0x8a1d04;
  FUN_0058a190();
  puStack_58 = (uint *)puVar8[4];
  if (0xf < (uint)puVar8[5]) {
    puVar8 = (undefined4 *)*puVar8;
  }
  iStack_60 = 0x8a1d19;
  pcStack_5c = (char *)puVar8;
  FUN_00554150();
  puStack_58 = (uint *)0x10;
  pcStack_5c = "AttributeChanged";
  iStack_60 = 0x8a1d28;
  FUN_00554150();
  puStack_58 = auStack_48;
  pcStack_5c = (char *)0x8a1d31;
  puStack_64 = (undefined4 *)FUN_0086e270();
  puStack_58 = (uint *)0x0;
  pcStack_5c = (char *)0x1;
  param_3 = (undefined4 *)auStack_6c;
  iStack_60 = iVar6;
  FUN_0060e0c0(auStack_6c,piStack_1c);
  uStack_8._0_1_ = 2;
  puVar8 = (undefined4 *)FUN_00899710(auStack_30,&uStack_24);
  uVar2 = *puVar8;
  uVar3 = puVar8[1];
  *puVar8 = 0;
  puVar8[1] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0089a590(uVar2,uVar3);
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      puStack_58 = (uint *)0x8a1dab;
      (**(code **)*piStack_2c)();
      LOCK();
      iVar6 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        puStack_58 = (uint *)0x8a1dbb;
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (0xf < uStack_34) {
    puStack_58 = (uint *)(uStack_34 + 1);
    uVar9 = auStack_48[0];
    if (0xfff < puStack_58) {
      uVar9 = *(uint *)(auStack_48[0] - 4);
      puStack_58 = (uint *)(uStack_34 + 0x24);
      if (0x1f < (auStack_48[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_58 = (uint *)&UNK_008a1e49;
        FUN_017167a3();
      }
    }
    iStack_60 = 0x8a1de8;
    pcStack_5c = (char *)uVar9;
    FUN_01674ea0();
  }
  piVar4 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_20[1] + -1;
    piStack_20[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      puStack_58 = (uint *)0x8a1e01;
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        puStack_58 = (uint *)0x8a1e10;
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14314 ; VA 0x008a1e50 ; FUN_008a1e50 */

undefined4 __thiscall FUN_008a1e50(undefined4 param_1,undefined4 param_2,char *param_3)

{
  char *pcVar1;
  char *pcVar2;
  char cVar3;
  char *pcVar4;
  uint uVar5;
  undefined auStack_d0 [12];
  undefined4 uStack_c4;
  undefined1 *puStack_c0;
  undefined4 uStack_bc;
  undefined auStack_b8 [16];
  undefined4 uStack_a8;
  uint *puStack_a4;
  undefined *puStack_a0;
  uint *puStack_9c;
  undefined4 uStack_98;
  int iStack_94;
  int iStack_90;
  int iStack_8c;
  undefined auStack_88 [4];
  undefined4 uStack_84;
  undefined *puStack_80;
  undefined4 uStack_7c;
  char *pcStack_78;
  code *pcStack_74;
  undefined auStack_68 [16];
  undefined4 uStack_58;
  undefined4 uStack_54;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  char *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  pcVar2 = param_3;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbf8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01d62c00 != '\0') {
    pcStack_74 = (code *)0xc;
    pcStack_78 = "GetAttribute";
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    uStack_7c = 0x8a1ea0;
    ExceptionList = &pvStack_10;
    FUN_005542c0();
    pcStack_74 = (code *)0xd;
    pcStack_78 = "attributeName";
    iStack_8 = 0;
    uStack_58 = 0;
    uStack_54 = 0xf;
    auStack_68[0] = 0;
    uStack_7c = 0x8a1ec8;
    FUN_005542c0();
    pcStack_74 = (code *)pcVar2;
    iStack_8._0_1_ = 1;
    pcStack_78 = (char *)0x8a1ed5;
    FUN_0054ef60();
    puStack_18 = auStack_88;
    iStack_8._0_1_ = 2;
    iStack_8c = (int)&param_3 + 3;
    puStack_9c = auStack_38;
    iStack_90 = (int)&param_3 + 3;
    iStack_94 = (int)&param_3 + 3;
    uStack_98 = 0xb;
    puStack_a0 = auStack_68;
    puStack_a4 = (uint *)0x8a1efc;
    FUN_006370e0();
    puStack_1c = (undefined *)&puStack_a0;
    iStack_8._0_1_ = 3;
    puStack_a4 = auStack_38;
    uStack_a8 = 0x8a1f11;
    FUN_0054ef60();
    puStack_20 = auStack_b8;
    iStack_8._0_1_ = 4;
    uStack_bc = 3;
    uStack_a8 = 0;
    puStack_a4 = (uint *)0xf;
    puStack_c0 = &DAT_0191e450;
    auStack_b8[0] = 0;
    uStack_c4 = 0x8a1f3a;
    FUN_005542c0();
    param_3 = auStack_d0;
    iStack_8._0_1_ = 5;
    cVar3 = FUN_0097c970(param_1,1);
    pcVar4 = "client";
    if (cVar3 == '\0') {
      pcVar4 = "RCC";
    }
    pcStack_14 = pcVar4;
    *(undefined4 *)(param_3 + 0x10) = 0;
    pcVar1 = pcVar4 + 1;
    *(undefined4 *)(param_3 + 0x14) = 0xf;
    *param_3 = 0;
    do {
      cVar3 = *pcVar4;
      pcVar4 = pcVar4 + 1;
    } while (cVar3 != '\0');
    param_3 = pcVar1;
    FUN_005542c0(pcStack_14,(int)pcVar4 - (int)pcVar1);
    iStack_8._0_1_ = 2;
    FUN_0087a540();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    puStack_80 = auStack_68;
    pcStack_74 = FUN_005509f0;
    pcStack_78 = (char *)0x1;
    uStack_7c = 0x30;
    uStack_84 = 0x8a1fb7;
    FUN_016f32d1();
    iStack_8 = 0xffffffff;
    if (0xf < uStack_24) {
      pcStack_74 = (code *)(uStack_24 + 1);
      uVar5 = auStack_38[0];
      if (0xfff < pcStack_74) {
        uVar5 = *(uint *)(auStack_38[0] - 4);
        pcStack_74 = (code *)(uStack_24 + 0x24);
        if (0x1f < (auStack_38[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          pcStack_74 = (code *)&UNK_008a2013;
          FUN_017167a3();
        }
      }
      uStack_7c = 0x8a1feb;
      pcStack_78 = (char *)uVar5;
      FUN_01674ea0();
    }
  }
  pcStack_74 = (code *)pcVar2;
  pcStack_78 = (char *)param_2;
  uStack_7c = 0x8a1ffa;
  FUN_008a1ac0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14315 ; VA 0x008a2020 ; FUN_008a2020 */

void __thiscall FUN_008a2020(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined **ppuVar6;
  undefined **ppuVar7;
  undefined auStack_14 [12];
  undefined4 uStack_8;
  
  if (DAT_01d62c08 == '\0') {
    if (DAT_01d62c18 != '\0') {
      uVar4 = FUN_01255560();
      cVar3 = FUN_01255580(uVar4,5);
      if (cVar3 != '\0') goto LAB_008a2057;
    }
    FUN_016756b0(auStack_14,"Attributes are not currently enabled");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_14,&DAT_01c17198);
  }
LAB_008a2057:
  iVar2 = *(int *)(param_1 + 0x44);
  if (iVar2 != 0) {
    *param_2 = 0;
    param_2[1] = 0;
    if (*(int *)(iVar2 + 0x60) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(iVar2 + 0x60) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *param_2 = *(int *)(iVar2 + 0x5c);
    param_2[1] = *(int *)(iVar2 + 0x60);
    return;
  }
  puVar5 = (undefined4 *)FUN_01674e20(0x24);
  if (puVar5 != (undefined4 *)0x0) {
    puVar5[1] = 1;
    puVar5[2] = 1;
    *puVar5 = std::
              _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>
              ::vftable;
    *(undefined *)(puVar5 + 3) = 0;
    uStack_8 = 0xb;
    ppuVar6 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_8);
    ppuVar7 = ppuVar6 + -1;
    if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar7 = ppuVar6;
    }
    puVar5[4] = *ppuVar7;
    puVar5[5] = 0;
    puVar5[6] = 0x3f800000;
    puVar5[7] = 0;
    puVar5[8] = 0;
    param_2[1] = (int)puVar5;
    *param_2 = (int)(puVar5 + 3);
    return;
  }
  param_2[1] = 0;
  *param_2 = 0xc;
  return;
}



/* FUNCTION 14316 ; VA 0x008a2150 ; FUN_008a2150 */

undefined * __thiscall FUN_008a2150(int *param_1,undefined *param_2)

{
  int iVar1;
  char cVar2;
  undefined auStack_b0 [160];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c07b;
  pvStack_10 = ExceptionList;
  iVar1 = param_1[0x11];
  if ((iVar1 != 0) && (*(int *)(*(int *)(iVar1 + 0x5c) + 8) != 0)) {
    ExceptionList = &pvStack_10;
    cVar2 = (**(code **)(*param_1 + 0x44))();
    if (cVar2 != '\0') {
      FUN_00565940(3,1);
      uStack_8 = 0;
      FUN_00cb57f0(auStack_b0,*(undefined4 *)(iVar1 + 0x5c),0);
      FUN_0058c4d0(param_2);
      FUN_005705c0();
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0xf;
  *param_2 = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14317 ; VA 0x008a2210 ; FUN_008a2210 */

uint * __thiscall FUN_008a2210(int *param_1,uint *param_2)

{
  int iVar1;
  uint uVar2;
  char cVar3;
  undefined auStack_c8 [160];
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbfab;
  pvStack_10 = ExceptionList;
  iVar1 = param_1[0x11];
  if ((iVar1 != 0) && (*(int *)(*(int *)(iVar1 + 0x5c) + 8) != 0)) {
    ExceptionList = &pvStack_10;
    cVar3 = (**(code **)(*param_1 + 0x44))();
    if (cVar3 != '\0') {
      FUN_00565940(3,1);
      uStack_8 = 0;
      FUN_00cb57f0(auStack_c8,*(undefined4 *)(iVar1 + 0x5c),0);
      FUN_0058c4d0(&uStack_28);
      uVar2 = uStack_28;
      uStack_28 = uStack_28 & 0xffffff00;
      param_2[4] = 0;
      param_2[5] = 0;
      *param_2 = uVar2;
      param_2[1] = uStack_24;
      param_2[2] = uStack_20;
      param_2[3] = uStack_1c;
      *(ulonglong *)(param_2 + 4) = CONCAT44(uStack_14,uStack_18);
      uStack_18 = 0;
      uStack_14 = 0xf;
      FUN_005705c0();
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14318 ; VA 0x008a2310 ; FUN_008a2310 */

void FUN_008a2310(void)

{
  int iVar1;
  
  if (DAT_01edf7dc == 0) {
    iVar1 = FUN_00897b90();
    DAT_01edf7dc = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 14319 ; VA 0x008a2330 ; FUN_008a2330 */

undefined4 __thiscall FUN_008a2330(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iStack_8;
  
  piVar1 = *(int **)(param_1 + 0x2c);
  if (piVar1 == (int *)0x0) {
    iVar2 = 0;
  }
  else {
    iVar2 = piVar1[1] - *piVar1 >> 3;
  }
  iStack_8 = param_1;
  FUN_01255f00(param_2,iVar2,0);
  iStack_8 = 0;
  FUN_008a4ea0(param_2,&iStack_8,param_1);
  return 1;
}



/* FUNCTION 14320 ; VA 0x008a2380 ; FUN_008a2380 */

undefined4 __thiscall FUN_008a2380(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_40 [24];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ee70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x34) != 0) {
    iVar1 = *(int *)(*(int *)(param_1 + 0x34) + 0xc);
    ExceptionList = &pvStack_10;
    iVar3 = FUN_008a8c30();
    if ((uint)*(ushort *)(iVar3 + 0x1da) <
        (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
      uVar2 = *(undefined4 *)(param_1 + 0x28);
      FUN_008a2380(auStack_40);
      uStack_8 = 0;
      puVar4 = (undefined4 *)FUN_00554150(&DAT_018c1030,1);
      uStack_28 = *puVar4;
      uStack_24 = puVar4[1];
      uStack_20 = puVar4[2];
      uStack_1c = puVar4[3];
      uStack_18 = *(undefined8 *)(puVar4 + 4);
      puVar4[4] = 0;
      puVar4[5] = 0xf;
      *(undefined *)puVar4 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_00558c20(param_2,&uStack_28,uVar2);
      FUN_005507b0();
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  FUN_0054ef60(*(undefined4 *)(param_1 + 0x28));
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14321 ; VA 0x008a2480 ; FUN_008a2480 */

undefined4 FUN_008a2480(undefined4 param_1)

{
  FUN_008a2380(param_1);
  return param_1;
}



/* FUNCTION 14322 ; VA 0x008a24b0 ; FUN_008a24b0 */

int __thiscall FUN_008a24b0(int *param_1,char param_2)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = param_1[0x11];
  if (iVar2 == 0) {
    if (param_2 == '\0') {
      return iVar2;
    }
    iVar2 = (**(code **)(*param_1 + 0x14))();
    puVar1 = (undefined4 *)param_1[0x11];
    param_1[0x11] = iVar2;
    if (puVar1 != (undefined4 *)0x0) {
      (**(code **)*puVar1)(1);
      iVar2 = param_1[0x11];
    }
  }
  return iVar2 + 0x20;
}



/* FUNCTION 14323 ; VA 0x008a24f0 ; FUN_008a24f0 */

int __thiscall FUN_008a24f0(int *param_1,char param_2)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = param_1[0x11];
  if (iVar2 == 0) {
    if (param_2 == '\0') {
      return iVar2;
    }
    iVar2 = (**(code **)(*param_1 + 0x14))();
    puVar1 = (undefined4 *)param_1[0x11];
    param_1[0x11] = iVar2;
    if (puVar1 != (undefined4 *)0x0) {
      (**(code **)*puVar1)(1);
      iVar2 = param_1[0x11];
    }
  }
  return iVar2 + 8;
}



/* FUNCTION 14324 ; VA 0x008a2530 ; FUN_008a2530 */

int __thiscall FUN_008a2530(int *param_1,char param_2)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = param_1[0x11];
  if (iVar2 == 0) {
    if (param_2 == '\0') {
      return iVar2;
    }
    iVar2 = (**(code **)(*param_1 + 0x14))();
    puVar1 = (undefined4 *)param_1[0x11];
    param_1[0x11] = iVar2;
    if (puVar1 != (undefined4 *)0x0) {
      (**(code **)*puVar1)(1);
      iVar2 = param_1[0x11];
    }
  }
  return iVar2 + 0xc;
}



/* FUNCTION 14325 ; VA 0x008a2570 ; FUN_008a2570 */

int __thiscall FUN_008a2570(int *param_1,char param_2)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = param_1[0x11];
  if (iVar2 == 0) {
    if (param_2 == '\0') {
      return iVar2;
    }
    iVar2 = (**(code **)(*param_1 + 0x14))();
    puVar1 = (undefined4 *)param_1[0x11];
    param_1[0x11] = iVar2;
    if (puVar1 != (undefined4 *)0x0) {
      (**(code **)*puVar1)(1);
      iVar2 = param_1[0x11];
    }
  }
  return iVar2 + 0x14;
}



/* FUNCTION 14326 ; VA 0x008a25b0 ; FUN_008a25b0 */

undefined * FUN_008a25b0(undefined *param_1)

{
  undefined *puVar1;
  undefined **ppuVar2;
  undefined **ppuVar3;
  
  puVar1 = param_1;
  *param_1 = 0;
  param_1 = (undefined *)0xb;
  ppuVar2 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_1);
  ppuVar3 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar3 = ppuVar2;
  }
  *(undefined **)(puVar1 + 4) = *ppuVar3;
  *(undefined4 *)(puVar1 + 8) = 0;
  *(undefined4 *)(puVar1 + 0xc) = 0x3f800000;
  *(undefined4 *)(puVar1 + 0x10) = 0;
  *(undefined4 *)(puVar1 + 0x14) = 0;
  return puVar1;
}



/* FUNCTION 14327 ; VA 0x008a2610 ; FUN_008a2610 */

undefined4 __fastcall FUN_008a2610(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a9308;
  puVar6 = *(undefined4 **)(param_1 + 0x2c);
  uStack_14 = 4;
  uVar4 = 4;
  if (puVar6 != (undefined4 *)0x0) {
    piVar5 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar5 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
      puVar6 = *(undefined4 **)(param_1 + 0x2c);
      piVar5 = *(int **)(param_1 + 0x30);
    }
    puVar2 = (undefined4 *)puVar6[1];
    puVar6 = (undefined4 *)*puVar6;
    uStack_8 = 0;
    for (; puVar6 != puVar2; puVar6 = puVar6 + 2) {
      if (puVar6[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar6[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_0089e260(*puVar6,puVar6[1],&uStack_14);
    }
    uVar4 = uStack_14;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar3 = piVar5[1] + -1;
      piVar5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        uVar4 = uStack_14;
        if (iVar3 == 1) {
          (**(code **)(*piVar5 + 4))();
          uVar4 = uStack_14;
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 14328 ; VA 0x008a26f0 ; FUN_008a26f0 */

undefined4 __thiscall FUN_008a26f0(int *param_1,undefined4 param_2,int *param_3)

{
  undefined4 *puVar1;
  char cVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  byte *pbVar7;
  undefined4 *puVar8;
  undefined auStack_c8 [4];
  undefined4 uStack_c4;
  int *piStack_c0;
  undefined *puStack_bc;
  uint *puStack_b8;
  undefined4 *puStack_b4;
  undefined auStack_a4 [36];
  undefined auStack_80 [12];
  undefined auStack_74 [24];
  undefined auStack_5c [16];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined auStack_44 [12];
  undefined auStack_38 [4];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar8 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc01a;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  if (0xf < (uint)param_3[5]) {
    param_3 = (int *)*param_3;
  }
  puStack_b8 = (uint *)0x8a2733;
  ExceptionList = &pvStack_10;
  puStack_b4 = param_3;
  uVar3 = FUN_00892d20();
  uStack_1c = uVar3;
  if (uVar3 == 0) {
    puStack_b4 = (undefined4 *)0x8a2a88;
    puStack_b4 = (undefined4 *)FUN_005543f0();
    puStack_bc = auStack_74;
    puStack_b8 = (uint *)0x191e628;
    piStack_c0 = (int *)0x8a2a97;
    puStack_b4 = (undefined4 *)FUN_01675640();
    uStack_8 = 0;
  }
  else {
    if ((*(uint *)(uVar3 + 0x24) >> 5 & 1) != 0) {
      puStack_b4 = (undefined4 *)0x8a2774;
      iStack_14 = FUN_01255560();
      puStack_b4 = *(undefined4 **)(uVar3 + 0x20);
      iStack_18 = (int)puStack_b4;
      if (puStack_b4 != (undefined4 *)0x0) {
        param_3 = *(int **)(uVar3 + 4);
        if (0xf < (uint)param_3[5]) {
          param_3 = (int *)*param_3;
        }
        puStack_bc = (undefined *)0x8a279b;
        puStack_b8 = (uint *)iStack_14;
        cVar2 = FUN_01255580();
        if (cVar2 == '\0') {
          puStack_b4 = param_3;
          puStack_b8 = (uint *)iStack_18;
          puStack_bc = (undefined *)0x8a27b0;
          FUN_01255600();
        }
      }
      iVar4 = param_1[0x11];
      if (iVar4 == 0) {
        puStack_b4 = (undefined4 *)0x8a27be;
        iVar4 = (**(code **)(*param_1 + 0x14))();
        puVar1 = (undefined4 *)param_1[0x11];
        param_1[0x11] = iVar4;
        if (puVar1 != (undefined4 *)0x0) {
          puStack_b4 = (undefined4 *)0x1;
          puStack_b8 = (uint *)0x8a27ce;
          (**(code **)*puVar1)();
          iVar4 = param_1[0x11];
        }
      }
      pbVar7 = (byte *)(iVar4 + 0x28) + *(byte *)(iVar4 + 0x28) + 1;
      puStack_bc = (undefined *)((uVar3 >> 3) + uVar3);
      puStack_b4 = (undefined4 *)(-(uint)(pbVar7 != (byte *)0x0) & (uint)(pbVar7 + 1));
      puStack_b8 = &uStack_1c;
      piStack_c0 = &iStack_14;
      uStack_c4 = 0x8a2801;
      FUN_00606ea0();
      if (iStack_14 == 0) {
        puStack_b4 = &iStack_28;
        puStack_b8 = (uint *)0x8a292b;
        FUN_00899790();
        puStack_b4 = &iStack_28;
        uStack_8 = 4;
        puStack_b8 = &uStack_1c;
        puStack_bc = (undefined *)0x8a2944;
        FUN_0089b930();
        puStack_b8 = (uint *)0x8a294c;
        FUN_0056ecd0();
        puStack_b4 = &iStack_28;
        puStack_b8 = &uStack_34;
        puStack_bc = (undefined *)0x8a2959;
        piVar5 = (int *)FUN_00899710();
        iStack_20 = *piVar5;
        uVar3 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
        puStack_b4 = (undefined4 *)0x8a2986;
        uStack_1c = uVar3;
        iStack_14 = iStack_20;
        FUN_00550b30();
        if (DAT_01edf7dc == 0) {
          puStack_b4 = (undefined4 *)0x8a2995;
          iVar4 = FUN_00897b90();
          DAT_01edf7dc = *(int *)(iVar4 + 4);
        }
        iVar4 = DAT_01edf7dc;
        puStack_b4 = (undefined4 *)(puVar8[4] + 7);
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
        uStack_4c = 0;
        uStack_48 = 0xf;
        auStack_5c[0] = 0;
        uStack_2c = 4;
        puStack_b8 = (uint *)0x8a29ca;
        FUN_0058a190();
        puStack_b4 = (undefined4 *)puVar8[4];
        if (0xf < (uint)puVar8[5]) {
          puVar8 = (undefined4 *)*puVar8;
        }
        puStack_bc = (undefined *)0x8a29df;
        puStack_b8 = puVar8;
        FUN_00554150();
        puStack_b4 = (undefined4 *)0x7;
        puStack_b8 = (uint *)0x191e670;
        puStack_bc = (undefined *)0x8a29ee;
        FUN_00554150();
        puStack_b4 = (undefined4 *)auStack_5c;
        puStack_b8 = (uint *)0x8a29f7;
        piStack_c0 = (int *)FUN_0086e270();
        puStack_b4 = (undefined4 *)0x0;
        puStack_b8 = (uint *)0x1;
        puStack_bc = (undefined *)iVar4;
        FUN_0060e0c0(auStack_c8,param_1);
        if (uVar3 != 0) {
          LOCK();
          *(int *)(uVar3 + 4) = *(int *)(uVar3 + 4) + 1;
          UNLOCK();
        }
        FUN_0089a590(iStack_14,uVar3);
        puStack_b4 = (undefined4 *)0x8a2a41;
        FUN_005507b0();
        puStack_b4 = (undefined4 *)auStack_a4;
        puStack_b8 = (uint *)0x8a2a50;
        FUN_0088dd10();
        puStack_b4 = (undefined4 *)0x8a2a5b;
        FUN_0087dc70();
        puStack_b4 = (undefined4 *)0x8a2a63;
        FUN_00550b30();
        puStack_b4 = (undefined4 *)0x8a2a6b;
        FUN_00550b30();
      }
      else {
        puStack_b4 = (undefined4 *)(iStack_14 + 0xc);
        puStack_b8 = (uint *)&iStack_20;
        puStack_bc = (undefined *)0x8a2819;
        piVar5 = (int *)FUN_00899710();
        iStack_28 = *piVar5;
        iVar4 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        uStack_8 = 2;
        puStack_b4 = (undefined4 *)0x8a2849;
        iStack_24 = iVar4;
        iStack_14 = iStack_28;
        FUN_00550b30();
        if (DAT_01edf7dc == 0) {
          puStack_b4 = (undefined4 *)0x8a2858;
          iVar6 = FUN_00897b90();
          DAT_01edf7dc = *(int *)(iVar6 + 4);
        }
        iVar6 = DAT_01edf7dc;
        puStack_b4 = (undefined4 *)(puVar8[4] + 7);
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        uStack_34 = 0;
        uStack_30 = 0xf;
        auStack_44[0] = 0;
        uStack_2c = 2;
        puStack_b8 = (uint *)0x8a288d;
        FUN_0058a190();
        puStack_b4 = (undefined4 *)puVar8[4];
        if (0xf < (uint)puVar8[5]) {
          puVar8 = (undefined4 *)*puVar8;
        }
        puStack_bc = (undefined *)0x8a28a2;
        puStack_b8 = puVar8;
        FUN_00554150();
        puStack_b4 = (undefined4 *)0x7;
        puStack_b8 = (uint *)0x191e670;
        puStack_bc = (undefined *)0x8a28b1;
        FUN_00554150();
        puStack_b4 = (undefined4 *)auStack_44;
        puStack_b8 = (uint *)0x8a28ba;
        piStack_c0 = (int *)FUN_0086e270();
        puStack_b4 = (undefined4 *)0x0;
        puStack_b8 = (uint *)0x1;
        puStack_bc = (undefined *)iVar6;
        FUN_0060e0c0(auStack_c8,param_1);
        if (iVar4 != 0) {
          LOCK();
          *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
          UNLOCK();
        }
        FUN_0089a590(iStack_14,iVar4);
        puStack_b4 = (undefined4 *)0x8a2901;
        FUN_005507b0();
        puStack_b4 = (undefined4 *)auStack_80;
        puStack_b8 = (uint *)0x8a290d;
        FUN_0088dd10();
        puStack_b4 = (undefined4 *)0x8a2915;
        FUN_0087dc70();
        puStack_b4 = (undefined4 *)0x8a291d;
        FUN_00550b30();
      }
      ExceptionList = pvStack_10;
      return param_2;
    }
    puStack_b4 = (undefined4 *)0x8a2751;
    puStack_b4 = (undefined4 *)FUN_005543f0();
    puStack_bc = auStack_74;
    puStack_b8 = (uint *)0x191e64c;
    piStack_c0 = (int *)0x8a2760;
    puStack_b4 = (undefined4 *)FUN_01675640();
    uStack_8 = 1;
  }
  puStack_b8 = (uint *)0x8a2aaa;
  FUN_005500e0();
  puStack_b4 = (undefined4 *)&DAT_01c17198;
  puStack_b8 = (uint *)auStack_38;
                    /* WARNING: Subroutine does not return */
  puStack_bc = &UNK_008a2ab8;
  FUN_0170c2a8();
}



/* FUNCTION 14329 ; VA 0x008a2ac0 ; FUN_008a2ac0 */

undefined4 FUN_008a2ac0(undefined4 param_1,undefined4 param_2)

{
  FUN_009c93d0(param_1,param_2);
  return param_1;
}



/* FUNCTION 14330 ; VA 0x008a2ae0 ; FUN_008a2ae0 */

void __fastcall FUN_008a2ae0(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x008a2ae9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 0x38) + 0xc))();
  return;
}



/* FUNCTION 14331 ; VA 0x008a2af0 ; FUN_008a2af0 */

undefined8 __fastcall FUN_008a2af0(int param_1)

{
  if (*(int *)(param_1 + 0x44) != 0) {
    return *(undefined8 *)(*(int *)(param_1 + 0x44) + 0x68);
  }
  return 0xffffffffffffffff;
}



/* FUNCTION 14332 ; VA 0x008a2b10 ; FUN_008a2b10 */

void __thiscall FUN_008a2b10(int param_1,undefined4 *param_2)

{
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined8 uStack_c;
  
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_0054ef60(*(undefined4 *)(*(int *)(param_1 + 0x44) + 0x58));
    param_2[4] = 0;
    param_2[5] = 0;
    *param_2 = uStack_1c;
    param_2[1] = uStack_18;
    param_2[2] = uStack_14;
    param_2[3] = uStack_10;
    *(undefined8 *)(param_2 + 4) = uStack_c;
    return;
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return;
}



/* FUNCTION 14333 ; VA 0x008a2b70 ; FUN_008a2b70 */

undefined4 __thiscall FUN_008a2b70(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  uVar1 = (**(code **)(param_1 + 8))();
  FUN_0054ef60(uVar1);
  return param_2;
}



/* FUNCTION 14334 ; VA 0x008a2b90 ; FUN_008a2b90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __thiscall FUN_008a2b90(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  int *piVar2;
  undefined *puVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  int iVar7;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bba58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar5 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  piVar6 = (int *)FUN_0060dcd0(auStack_20,uVar5);
  iVar7 = *piVar6;
  piVar2 = (int *)piVar6[1];
  *piVar6 = 0;
  piVar6[1] = 0;
  uStack_8 = 0;
  iStack_18 = iVar7;
  piStack_14 = piVar2;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar4 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uVar5 = FUN_0088cd20();
  iVar4 = _tls_index;
  *param_3 = uVar5;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar4 * 4) + 0x34) < DAT_01eded64) &&
     (FUN_016f3809(&DAT_01eded64), DAT_01eded64 == -1)) {
    _DAT_01eded58 = FUN_0057bbb0;
    _DAT_01eded5c = FUN_005880a0;
    _DAT_01eded60 = FUN_0057d5e0;
    FUN_016f37bf(&DAT_01eded64);
  }
  puVar3 = (undefined *)param_3[1];
  if (puVar3 == &DAT_01eded58) {
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar2[1] = piVar2[1] + 1;
      UNLOCK();
    }
    param_3[2] = iVar7;
    piVar6 = (int *)param_3[3];
    param_3[3] = piVar2;
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar1 = piVar6 + 1;
      iVar4 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar4 = *piVar1;
        iVar7 = *piVar1;
        *piVar1 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          iVar7 = (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  else {
    if (puVar3 != (undefined *)0x0) {
      (**(code **)(puVar3 + 8))(param_3 + 2);
      param_3[1] = 0;
    }
    param_3[2] = 0;
    param_3[3] = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar2[1] = piVar2[1] + 1;
      UNLOCK();
    }
    param_3[2] = iVar7;
    param_3[3] = piVar2;
    param_3[1] = &DAT_01eded58;
  }
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar6 = piVar2 + 1;
    iVar4 = *piVar6;
    iVar7 = *piVar6;
    *piVar6 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar7 = (**(code **)*piVar2)();
      LOCK();
      piVar6 = piVar2 + 2;
      iVar4 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar7 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 14335 ; VA 0x008a2d50 ; FUN_008a2d50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_008a2d50(int param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba918;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(aiStack_28,param_2);
  uStack_8 = 0;
  uVar5 = FUN_0088cf00();
  iVar6 = _tls_index;
  *param_3 = uVar5;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar6 * 4) + 0x34) < DAT_01ead2d8) {
    FUN_016f3809(&DAT_01ead2d8);
    if (DAT_01ead2d8 == -1) {
      _DAT_01ead2cc = FUN_005c65f0;
      _DAT_01ead2d0 = FUN_005c93a0;
      _DAT_01ead2d4 = FUN_005c77b0;
      FUN_016f37bf(&DAT_01ead2d8);
    }
  }
  puVar1 = (undefined *)param_3[1];
  if (puVar1 == &DAT_01ead2cc) {
    if (param_3 + 2 != puVar4) {
      FUN_005507b0();
      uVar5 = puVar4[1];
      uVar2 = puVar4[2];
      uVar3 = puVar4[3];
      param_3[2] = *puVar4;
      param_3[3] = uVar5;
      param_3[4] = uVar2;
      param_3[5] = uVar3;
      *(undefined8 *)(param_3 + 6) = *(undefined8 *)(puVar4 + 4);
      puVar4[4] = 0;
      puVar4[5] = 0xf;
      *(undefined *)puVar4 = 0;
    }
  }
  else {
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_3 + 2);
      param_3[1] = 0;
    }
    param_3[6] = 0;
    param_3[7] = 0;
    uVar5 = puVar4[1];
    uVar2 = puVar4[2];
    uVar3 = puVar4[3];
    param_3[2] = *puVar4;
    param_3[3] = uVar5;
    param_3[4] = uVar2;
    param_3[5] = uVar3;
    *(undefined8 *)(param_3 + 6) = *(undefined8 *)(puVar4 + 4);
    puVar4[4] = 0;
    puVar4[5] = 0xf;
    *(undefined *)puVar4 = 0;
    param_3[1] = &DAT_01ead2cc;
  }
  if (0xf < uStack_14) {
    uVar7 = uStack_14 + 1;
    iVar6 = aiStack_28[0];
    if (0xfff < uVar7) {
      iVar6 = *(int *)(aiStack_28[0] + -4);
      uVar7 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14336 ; VA 0x008a2ed0 ; FUN_008a2ed0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_008a2ed0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  
  uVar4 = (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(param_2);
  uVar3 = FUN_0088da50();
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  *param_3 = uVar3;
  if (*(int *)(iVar1 + 0x34) < DAT_01ea8c28) {
    FUN_016f3809(&DAT_01ea8c28);
    if (DAT_01ea8c28 == -1) {
      DAT_01ea8c1c = FUN_005c6620;
      _DAT_01ea8c20 = FUN_005c6620;
      DAT_01ea8c24 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ea8c28);
    }
  }
  puVar2 = (undefined4 *)param_3[1];
  if ((code **)puVar2 == &DAT_01ea8c1c) {
    *(undefined8 *)(param_3 + 2) = uVar4;
    return;
  }
  if (puVar2 != (undefined4 *)0x0) {
    (*(code *)puVar2[2])(param_3 + 2);
  }
  *(undefined8 *)(param_3 + 2) = uVar4;
  param_3[1] = &DAT_01ea8c1c;
  return;
}



/* FUNCTION 14337 ; VA 0x008a2fa0 ; FUN_008a2fa0 */

uint FUN_008a2fa0(uint *param_1)

{
  uint uVar1;
  
  uVar1 = (*param_1 >> 3) + *param_1;
  return (uVar1 >> 2) + 0x9e3779b9 + uVar1 * 0x40 + param_1[1] + (param_1[1] >> 3) ^ uVar1;
}



/* FUNCTION 14338 ; VA 0x008a2fd0 ; FUN_008a2fd0 */

void FUN_008a2fd0(void)

{
  undefined **ppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc038;
  pvStack_10 = ExceptionList;
  ppuStack_14 = RBX::Instance::HumanoidChangedSignalData::vftable;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_006150c0(8,&ppuStack_14);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14339 ; VA 0x008a3020 ; FUN_008a3020 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_008a3020(void)

{
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc067;
  pvStack_10 = ExceptionList;
  if (DAT_01edf5bc == '\0') {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf8bc) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01edf8bc);
      if (DAT_01edf8bc == -1) {
        uStack_8 = 0;
        _DAT_01edf87c = FUN_01674e20(0x28,&DAT_01edf878);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_005ef390(&uStack_11,-(uint)(_DAT_01edf87c != 0) & _DAT_01edf87c + 0x20U,0);
        _DAT_01edf898 = 0x3f800000;
        _DAT_01edf89c = 0xffffffff;
        if ((float)((double)*(int *)(&DAT_018be080 + DAT_01edf888 * 4) +
                   (double)(&DAT_018c0d90)[-(*(int *)(&DAT_018be080 + DAT_01edf888 * 4) >> 0x1f)]) <
            DAT_018c0d80) {
          _DAT_01edf89c = FUN_016f3cd0();
        }
        _DAT_01edf8a0 = 0;
        InitializeCriticalSection(&DAT_01edf8a4);
        FUN_016f3654(&LAB_01880dd0);
        FUN_016f37bf(&DAT_01edf8bc);
      }
    }
    DAT_01ea8be4 = &DAT_01edf878;
    DAT_01edf5c0 = &DAT_01edf8a4;
    DAT_01edf5bc = '\x01';
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 14340 ; VA 0x008a3160 ; FUN_008a3160 */

undefined4 __fastcall FUN_008a3160(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc092;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(0x80,param_1);
  uStack_8 = 0;
  if (iVar1 != 0) {
    uVar2 = FUN_0089a8e0(iVar1);
    ExceptionList = pvStack_10;
    return uVar2;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 14341 ; VA 0x008a31c0 ; FUN_008a31c0 */

undefined4 FUN_008a31c0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  puVar4 = (undefined4 *)FUN_01674e20(0x28);
  *param_2 = puVar4;
  puVar4[4] = 0;
  puVar4[5] = 0;
  uVar1 = param_1[1];
  uVar2 = param_1[2];
  uVar3 = param_1[3];
  *puVar4 = *param_1;
  puVar4[1] = uVar1;
  puVar4[2] = uVar2;
  puVar4[3] = uVar3;
  *(undefined8 *)(puVar4 + 4) = *(undefined8 *)(param_1 + 4);
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  puVar4[6] = 0;
  puVar4[7] = 0;
  return *param_2;
}



/* FUNCTION 14342 ; VA 0x008a3220 ; FUN_008a3220 */

int * FUN_008a3220(int *param_1,int *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int aiStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc0b0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008a3020();
  uStack_20 = 0;
  uStack_1c = 0;
  iStack_38 = *param_2;
  iStack_34 = param_2[1];
  iStack_30 = param_2[2];
  iStack_2c = param_2[3];
  uStack_28 = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  uVar2 = DAT_01edf5c0;
  uStack_8 = 0;
  EnterCriticalSection(DAT_01edf5c0);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_008995b0(aiStack_18,&iStack_38,uVar2);
  *param_1 = aiStack_18[0];
  LOCK();
  piVar1 = (int *)(aiStack_18[0] + 0x18);
  iVar3 = *piVar1;
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  if (iVar3 == 0) {
    *(int *)(*param_1 + 0x1c) = *(int *)(*param_1 + 0x1c) + 1;
  }
  LeaveCriticalSection(uVar2);
  if (0xf < uStack_28._4_4_) {
    uVar4 = uStack_28._4_4_ + 1;
    iVar3 = iStack_38;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iStack_38 + -4);
      uVar4 = uStack_28._4_4_ + 0x24;
      if (0x1f < (iStack_38 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14343 ; VA 0x008a3320 ; FUN_008a3320 */

int * FUN_008a3320(int *param_1,int *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int aiStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc0b0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008a3020();
  uStack_20 = 0;
  uStack_1c = 0;
  iStack_38 = *param_2;
  iStack_34 = param_2[1];
  iStack_30 = param_2[2];
  iStack_2c = param_2[3];
  uStack_28 = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  uVar2 = DAT_01edf5c0;
  uStack_8 = 0;
  EnterCriticalSection(DAT_01edf5c0);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_008995b0(aiStack_18,&iStack_38,uVar2);
  *param_1 = aiStack_18[0];
  LOCK();
  piVar1 = (int *)(aiStack_18[0] + 0x18);
  iVar3 = *piVar1;
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  if (iVar3 == 0) {
    *(int *)(*param_1 + 0x1c) = *(int *)(*param_1 + 0x1c) + 1;
  }
  LeaveCriticalSection(uVar2);
  if (0xf < uStack_28._4_4_) {
    uVar4 = uStack_28._4_4_ + 1;
    iVar3 = iStack_38;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iStack_38 + -4);
      uVar4 = uStack_28._4_4_ + 0x24;
      if (0x1f < (iStack_38 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14344 ; VA 0x008a3420 ; FUN_008a3420 */

int * FUN_008a3420(int *param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int iStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  int aiStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc0d0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008a3020();
  FUN_0054ef60(param_2);
  uVar2 = DAT_01edf5c0;
  uStack_38 = 0;
  uStack_34 = 0;
  iStack_50 = iStack_30;
  uStack_4c = uStack_2c;
  uStack_48 = uStack_28;
  uStack_44 = uStack_24;
  uStack_40 = uStack_20;
  uStack_8 = 0;
  EnterCriticalSection(DAT_01edf5c0);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_008995b0(aiStack_18,&iStack_50,uVar2);
  *param_1 = aiStack_18[0];
  LOCK();
  piVar1 = (int *)(aiStack_18[0] + 0x18);
  iVar3 = *piVar1;
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  if (iVar3 == 0) {
    *(int *)(*param_1 + 0x1c) = *(int *)(*param_1 + 0x1c) + 1;
  }
  LeaveCriticalSection(uVar2);
  if (0xf < uStack_40._4_4_) {
    uVar4 = uStack_40._4_4_ + 1;
    iVar3 = iStack_50;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iStack_50 + -4);
      uVar4 = uStack_40._4_4_ + 0x24;
      if (0x1f < (iStack_50 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14345 ; VA 0x008a3520 ; FUN_008a3520 */

void FUN_008a3520(undefined4 *param_1,undefined4 param_2)

{
  (*(code *)*param_1)(param_1[1],param_2);
  return;
}



/* FUNCTION 14346 ; VA 0x008a3540 ; FUN_008a3540 */

int FUN_008a3540(int *param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc0e8;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  piVar2 = (int *)(iVar1 + 0x1c);
  if (0xf < *(uint *)(iVar1 + 0x30)) {
    piVar2 = (int *)*piVar2;
  }
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0086edd0(2,piVar2,6);
  piVar2 = *(int **)(iVar1 + 0x14);
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  uStack_8 = 0;
  if (piVar2 != (int *)0x0) {
    if (piVar2[2] != 0) {
      FUN_0094fc20(piVar2[2]);
      FUN_009556b0(piVar2[2],0,0,0);
    }
    LOCK();
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    iVar3 = iVar3 + -1;
    if (iVar3 == 0) {
      FUN_00d88950();
      iVar3 = FUN_01674ea0(piVar2,0x10);
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 14347 ; VA 0x008a35f0 ; FUN_008a35f0 */

void FUN_008a35f0(void)

{
  FUN_0089bb40();
  return;
}



/* FUNCTION 14348 ; VA 0x008a3600 ; FUN_008a3600 */

undefined __thiscall FUN_008a3600(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  if (param_2 == 0) {
    uVar3 = 0;
    ExceptionList = &pvStack_10;
  }
  else if (*(int *)(param_2 + 0x34) == param_1) {
    uVar3 = 1;
    ExceptionList = &pvStack_10;
  }
  else {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_008a3680(*(int *)(param_2 + 0x34));
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 14349 ; VA 0x008a3680 ; FUN_008a3680 */

uint __thiscall FUN_008a3680(uint param_1,uint param_2)

{
  if (param_2 != 0) {
    do {
      param_2 = *(uint *)(param_2 + 0x34);
      if (param_2 == param_1) {
        return CONCAT31((int3)(param_2 >> 8),1);
      }
    } while (param_2 != 0);
  }
  return param_2 & 0xffffff00;
}



/* FUNCTION 14350 ; VA 0x008a36b0 ; FUN_008a36b0 */

undefined4 FUN_008a36b0(int param_1)

{
  switch(*(undefined4 *)(param_1 + 0x1c)) {
  case 0:
  case 1:
  case 4:
  case 5:
  case 6:
  case 0xb:
  case 0xc:
  case 0xf:
  case 0x11:
  case 0x13:
  case 0x14:
  case 0x1c:
  case 0x29:
  case 0x2b:
  case 0x2c:
    return 1;
  default:
    return 0;
  }
}



/* FUNCTION 14351 ; VA 0x008a3710 ; FUN_008a3710 */

undefined __thiscall FUN_008a3710(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  if (param_2 == *(int *)(param_1 + 0x34)) {
    uVar3 = 1;
    ExceptionList = &pvStack_10;
  }
  else if (*(int *)(param_1 + 0x34) == 0) {
    uVar3 = 0;
    ExceptionList = &pvStack_10;
  }
  else {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_00620ec0(param_2);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 14352 ; VA 0x008a3790 ; FUN_008a3790 */

undefined4 FUN_008a3790(int param_1,int param_2)

{
  undefined4 uVar1;
  
  if (param_1 != param_2) {
    if (param_2 == 0) {
      return 0;
    }
    if (*(int *)(param_2 + 0x34) != param_1) {
      uVar1 = FUN_008a3680(*(int *)(param_2 + 0x34));
      return uVar1;
    }
  }
  return 1;
}



/* FUNCTION 14353 ; VA 0x008a37c0 ; FUN_008a37c0 */

void __fastcall FUN_008a37c0(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x008a37c8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 0x38) + 4))();
  return;
}



/* FUNCTION 14354 ; VA 0x008a37d0 ; FUN_008a37d0 */

void __fastcall FUN_008a37d0(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x008a37d8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 0x38) + 8))();
  return;
}



/* FUNCTION 14355 ; VA 0x008a37e0 ; FUN_008a37e0 */

void FUN_008a37e0(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  
  if ((int *)*param_2 == (int *)0x0) {
    iVar1 = *param_3;
    *param_1 = iVar1;
    param_1[1] = *(int *)(*param_3 + 4);
    *(int **)(iVar1 + 4) = param_2;
    *param_2 = (int)param_1;
    *param_3 = (int)param_1;
    return;
  }
  *param_1 = *(int *)*param_2;
  param_1[1] = *param_2;
  *param_2 = (int)param_1;
  *(int **)param_1[1] = param_1;
  return;
}



/* FUNCTION 14356 ; VA 0x008a3820 ; FUN_008a3820 */

void FUN_008a3820(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_008a7680();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14357 ; VA 0x008a3860 ; FUN_008a3860 */

undefined4 * __thiscall FUN_008a3860(undefined4 param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017bc120;
  pvStack_10 = ExceptionList;
  puStack_2c = (undefined4 *)0x0;
  iStack_28 = 0;
  uStack_24 = 0;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_0060dcd0(auStack_20,param_1);
  uStack_8 = 2;
  FUN_00603a30(0,uVar3);
  uStack_8 = 1;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  piStack_18 = (int *)0x0;
  uStack_14 = 0;
  piStack_18 = (int *)FUN_00575ad0();
  uStack_8 = 3;
  FUN_0089dad0(&puStack_2c,&piStack_18,&uStack_38,2,0,0);
  piVar1 = piStack_18;
  uStack_8 = 4;
  FUN_0089c760(piStack_18[1]);
  _uStack_8 = CONCAT31(uStack_7,1);
  piStack_18[1] = (int)piVar1;
  *piStack_18 = (int)piVar1;
  piStack_18[2] = (int)piVar1;
  uStack_14 = 0;
  FUN_01674ea0(piStack_18,0x1c);
  if (iStack_28 - (int)puStack_2c >> 3 == 0) {
    FUN_0060dcd0(param_2,0);
  }
  else {
    *param_2 = 0;
    param_2[1] = 0;
    if (puStack_2c[1] != 0) {
      LOCK();
      piVar1 = (int *)(puStack_2c[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *param_2 = *puStack_2c;
    param_2[1] = puStack_2c[1];
  }
  FUN_00577ac0();
  FUN_00577ac0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14358 ; VA 0x008a39e0 ; FUN_008a39e0 */

undefined4 FUN_008a39e0(undefined4 param_1)

{
  undefined4 uVar1;
  undefined uVar2;
  int iVar3;
  undefined4 ****ppppuVar4;
  uint uVar5;
  undefined4 ***apppuStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc140;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01257640(param_1,2);
  if ((iVar3 == 0) || (*(short *)(iVar3 + 6) < 0)) {
    iVar3 = FUN_01256300(uVar1);
    param_1 = 0;
    uStack_8 = 0;
    FUN_009d09d0(apppuStack_28,uVar1,1,1,iVar3 + -1,&param_1);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_005c4ac0();
    ppppuVar4 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar4 = (undefined4 ****)apppuStack_28[0];
    }
    uVar2 = FUN_008931b0(ppppuVar4);
    FUN_01256800(uVar1,uVar2);
    if (0xf < uStack_14) {
      uVar5 = uStack_14 + 1;
      ppppuVar4 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar5) {
        ppppuVar4 = (undefined4 ****)apppuStack_28[0][-1];
        uVar5 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar4,uVar5);
    }
  }
  else {
    uVar2 = FUN_00893180(*(undefined4 *)(&DAT_01ece3c0 + *(short *)(iVar3 + 6) * 4));
    FUN_01256800(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 14359 ; VA 0x008a3ae0 ; FUN_008a3ae0 */

void FUN_008a3ae0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1da366c);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&TypeDescriptor_01da3668;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 14360 ; VA 0x008a3b60 ; FUN_008a3b60 */

void FUN_008a3b60(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc167;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x34);
      uStack_8 = 0;
      if (iVar2 == 0) {
        *param_2 = 0;
        ExceptionList = pvStack_10;
        return;
      }
      FUN_00d88710(iVar4);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_0054ef60(iVar4 + 0x1c);
      *param_2 = iVar2;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        uVar1 = *(uint *)(iVar4 + 0x30);
        ExceptionList = &pvStack_10;
        if (0xf < uVar1) {
          iVar2 = *(int *)(iVar4 + 0x1c);
          uVar5 = uVar1 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar1 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) {
              ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          ExceptionList = &pvStack_10;
          FUN_01674ea0(iVar3,uVar5);
        }
        *(undefined4 *)(iVar4 + 0x2c) = 0;
        *(undefined4 *)(iVar4 + 0x30) = 0xf;
        *(undefined *)(iVar4 + 0x1c) = 0;
        FUN_00d88aa0();
        FUN_01674ea0(iVar4,0x34);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1da35fc);
      if (iVar4 != 0) {
        *param_2 = 0;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = *param_1;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_e0eb0da7dbf1c4b6d6891b5ba2dd4246>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 14361 ; VA 0x008a3d00 ; FUN_008a3d00 */

void FUN_008a3d00(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0462;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x88);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_00899aa0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0089b470();
        FUN_0089b470();
        piVar1 = *(int **)(iVar3 + 4);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        FUN_01674ea0(iVar3,0x88);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1da3634);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_fa5e7c5ae46e7e7f62577e0ed7502320>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 14362 ; VA 0x008a3e70 ; FUN_008a3e70 */

void FUN_008a3e70(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1da3574);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<bool,bool_(__cdecl*)(class_RBX::Instance*,class_RBX::Instance*),class_boost::_bi::list2<class_boost::_bi::value<class_RBX::Instance*>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 14363 ; VA 0x008a3ee0 ; FUN_008a3ee0 */

int __thiscall FUN_008a3ee0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  undefined4 *puVar5;
  int **ppiStack_54;
  undefined4 uStack_50;
  int *piStack_4c;
  undefined ***pppuStack_48;
  undefined **ppuStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc1a0;
  pvStack_10 = ExceptionList;
  piVar4 = *(int **)(param_1 + 0x2c);
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)param_1;
  if (piVar4 != (int *)0x0) {
    piStack_20 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piStack_20[1] = piStack_20[1] + 1;
      UNLOCK();
      piStack_20 = *(int **)(param_1 + 0x30);
      piVar4 = *(int **)(param_1 + 0x2c);
    }
    puVar5 = (undefined4 *)*piVar4;
    uStack_8 = 0;
    piStack_24 = piVar4;
    piStack_14 = piStack_20;
    if (puVar5 != (undefined4 *)piVar4[1]) {
      do {
        pppuStack_48 = (undefined ***)param_2;
        piStack_4c = (int *)0x8a3f40;
        param_1 = (**(code **)(*(int *)*puVar5 + 0x7c))();
        puVar5 = puVar5 + 2;
      } while (puVar5 != (undefined4 *)piVar4[1]);
    }
    piVar4 = piStack_14;
    uStack_8 = 0xffffffff;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar2 = *piVar1;
      param_1 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pppuStack_48 = (undefined ***)0x8a3f68;
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar2 = *piVar1;
        param_1 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          pppuStack_48 = (undefined ***)0x8a3f78;
          param_1 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  puVar5 = puStack_1c;
  if (*(int *)((int)puStack_1c + 0x50) != 0) {
    piStack_4c = (int *)auStack_18;
    pppuStack_48 = (undefined ***)param_2[2];
    uStack_50 = 0x8a3f99;
    puStack_1c = (undefined4 *)FUN_0060dcd0();
    uStack_50 = *param_2;
    ppiStack_54 = &piStack_24;
    uStack_8 = 1;
    puVar3 = (undefined4 *)FUN_0060dcd0();
    piVar4 = piStack_20;
    ppuStack_38 = RBX::Instance::AncestryChangedSignalData::vftable;
    if (puVar3[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar3[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_34 = *puVar3;
    uStack_30 = puVar3[1];
    if (puStack_1c[1] != 0) {
      LOCK();
      piVar1 = (int *)(puStack_1c[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_2c = *puStack_1c;
    uStack_28 = puStack_1c[1];
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_20[1] + -1;
      piStack_20[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        pppuStack_48 = (undefined ***)0x8a401b;
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar2 = *piVar1 + -1;
        *piVar1 = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          pppuStack_48 = (undefined ***)0x8a402b;
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    piVar4 = piStack_14;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[1] + -1;
      piStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        pppuStack_48 = (undefined ***)0x8a4045;
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pppuStack_48 = (undefined ***)0x8a4054;
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    pppuStack_48 = &ppuStack_38;
    piStack_4c = (int *)0x5;
    uStack_50 = 0x8a4062;
    FUN_006150c0();
    uStack_8 = 0xffffffff;
    pppuStack_48 = (undefined ***)0x8a4071;
    param_1 = FUN_0089b130();
  }
  if (*(int *)((int)puVar5 + 0x48) != 0) {
    puStack_1c = &piStack_4c;
    ppiStack_54 = &piStack_4c;
    uStack_50 = param_2[2];
    FUN_0060dcd0();
    uStack_8 = 4;
    FUN_0060dcd0(&ppiStack_54,*param_2);
    uStack_8 = 0xffffffff;
    param_1 = FUN_0089bce0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14364 ; VA 0x008a40d0 ; FUN_008a40d0 */

void __fastcall FUN_008a40d0(int param_1)

{
  if (*(int **)(param_1 + 0x34) != (int *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x008a40dd. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(**(int **)(param_1 + 0x34) + 0x94))();
    return;
  }
  return;
}



/* FUNCTION 14365 ; VA 0x008a40f0 ; FUN_008a40f0 */

undefined4 __fastcall FUN_008a40f0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x44);
}



/* FUNCTION 14366 ; VA 0x008a4100 ; FUN_008a4100 */

int __fastcall FUN_008a4100(int *param_1)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = param_1[0x11];
  if (iVar2 == 0) {
    iVar2 = (**(code **)(*param_1 + 0x14))();
    puVar1 = (undefined4 *)param_1[0x11];
    param_1[0x11] = iVar2;
    if (puVar1 != (undefined4 *)0x0) {
      (**(code **)*puVar1)(1);
      iVar2 = param_1[0x11];
    }
  }
  return iVar2;
}



/* FUNCTION 14367 ; VA 0x008a4130 ; FUN_008a4130 */

void __thiscall FUN_008a4130(int param_1,undefined4 param_2)

{
  undefined auStack_14 [8];
  
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_0060dcd0(auStack_14,param_2);
    FUN_0089be10();
  }
  return;
}



/* FUNCTION 14368 ; VA 0x008a4160 ; FUN_008a4160 */

void __thiscall FUN_008a4160(int param_1,undefined4 *param_2,undefined4 param_3)

{
  int *piVar1;
  
  if (*(int *)(param_1 + 0x44) != 0) {
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_0089bf10(*param_2,param_2[1],param_3);
  }
  if (*(int **)(param_1 + 0x34) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0x34) + 0x98))(param_2,param_3);
  }
  return;
}



/* FUNCTION 14369 ; VA 0x008a41c0 ; FUN_008a41c0 */

void __thiscall FUN_008a41c0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  
  if (*(int *)(param_1 + 0x44) != 0) {
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_0089be10(*param_2,param_2[1]);
  }
  return;
}



/* FUNCTION 14370 ; VA 0x008a4210 ; FUN_008a4210 */

void __thiscall FUN_008a4210(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  
  if ((*(int *)(param_1 + 0x44) != 0) &&
     (*(int *)(*(int *)(*(int *)(param_1 + 0x44) + 0x58) + 0x10) != 0)) {
    iVar1 = FUN_008991d0(param_1);
    if (iVar1 != 0) {
      FUN_00d13d80(param_1,param_2,param_3);
    }
  }
  return;
}



/* FUNCTION 14371 ; VA 0x008a4250 ; FUN_008a4250 */

uint FUN_008a4250(uint param_1,undefined4 param_2)

{
  switch(param_2) {
  case 1:
    return param_1 % 0x61;
  case 2:
    return param_1 % 0xc1;
  case 3:
    return param_1 % 0x185;
  case 4:
    return param_1 % 0x301;
  case 5:
    return param_1 % 0x607;
  case 6:
    return param_1 % 0xc07;
  case 7:
    return param_1 % 0x1807;
  case 8:
    return param_1 % 0x3001;
  case 9:
    return param_1 % 0x6011;
  case 10:
    return param_1 % 0xc005;
  case 0xb:
    return param_1 % 0x1800d;
  case 0xc:
    return param_1 % 0x30005;
  case 0xd:
    return param_1 % 0x60019;
  case 0xe:
    return param_1 % 0xc0001;
  case 0xf:
    return param_1 % 0x180005;
  case 0x10:
    return param_1 % 0x30000b;
  case 0x11:
    return param_1 % 0x60000d;
  case 0x12:
    return param_1 % 0xc00005;
  case 0x13:
    return param_1 % 0x1800013;
  case 0x14:
    return param_1 % 0x3000005;
  case 0x15:
    return param_1 % 0x6000017;
  case 0x16:
    return param_1 % 0xc000013;
  case 0x17:
    return param_1 % 0x18000005;
  case 0x18:
    return param_1 % 0x30000059;
  case 0x19:
    return param_1 + (uint)((ulonglong)param_1 * 0x55555551 >> 0x3d) * -0x60000005;
  case 0x1a:
    return (uint)((ulonglong)param_1 * 0x55555555 >> 0x3e) * 0x3fffffff + param_1;
  case 0x1b:
    return param_1 + (int)((longlong)((ulonglong)param_1 * 0x80000003) >> 0x3f) * -5;
  default:
    return param_1 % 0x35;
  }
}



/* FUNCTION 14372 ; VA 0x008a45f0 ; FUN_008a45f0 */

void FUN_008a45f0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar4 = (int *)*puVar1; piVar4 != piVar2; piVar4 = piVar4 + 2) {
      *(undefined4 *)(*piVar4 + 0x34) = 0;
    }
    *(undefined4 *)(param_1 + 0x2c) = 0;
    piVar2 = *(int **)(param_1 + 0x30);
    *(undefined4 *)(param_1 + 0x30) = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        piVar4 = piVar2 + 2;
        iVar3 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x008a4657. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          (**(code **)(*piVar2 + 4))();
          return;
        }
      }
    }
  }
  return;
}



/* FUNCTION 14373 ; VA 0x008a4660 ; FUN_008a4660 */

void __thiscall FUN_008a4660(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    *puVar1 = 0;
    puVar1[1] = 0;
    *puVar1 = *param_2;
    puVar1[1] = param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 8;
    return;
  }
  FUN_00603a30(puVar1,param_2);
  return;
}



/* FUNCTION 14374 ; VA 0x008a46b0 ; FUN_008a46b0 */

void __thiscall FUN_008a46b0(int param_1,undefined4 param_2,char param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined **ppuStack_30;
  int iStack_2c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc1c0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x34) != 0) {
    if ((DAT_020c0b1c == '\0') || (DAT_01d62bc8 == '\0')) {
      ExceptionList = &pvStack_10;
      FUN_008f7870(param_1);
    }
    else {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_008f7870(param_1);
      if ((iVar2 == 0) || (*(char *)(iVar2 + 0xd0) == '\0')) {
        cVar1 = FUN_008f2050(param_1);
        if (cVar1 == '\0') {
          FUN_01675310("InvalidAccess",&DAT_018bc9b8);
        }
      }
    }
  }
  uStack_8 = 0;
  ppuStack_30 = RBX::Instance::AttributeChangedSignalData::vftable;
  FUN_0054ef60(param_2);
  uStack_8 = 1;
  FUN_006150c0(9,&ppuStack_30);
  if ((DAT_01d62c28 != '\0') && (param_3 != '\0')) {
    FUN_008a4940(&DAT_0211a590);
  }
  iVar2 = *(int *)(param_1 + 0x44);
  if (iVar2 != 0) {
    FUN_0054ef60(param_2);
    FUN_006ecaa0();
    iVar2 = iVar2 + 0x41 + (uint)*(byte *)(iVar2 + 0x40);
    uVar3 = FUN_00563b90(param_2);
    FUN_008992d0(&iStack_14,uVar3,param_2,-(uint)(iVar2 != 0) & iVar2 + 1U);
    if (iStack_14 != 0) {
      FUN_006eccd0();
    }
  }
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    iVar2 = iStack_2c;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(iStack_2c + -4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (iStack_2c - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14375 ; VA 0x008a4810 ; FUN_008a4810 */

int __thiscall FUN_008a4810(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  undefined **ppuStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc1ef;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x34) != 0) {
    if ((DAT_020c0b1c == '\0') || (DAT_01d62bc8 == '\0')) {
      ExceptionList = &pvStack_10;
      FUN_008f7870(param_1);
    }
    else {
      ExceptionList = &pvStack_10;
      iVar5 = FUN_008f7870(param_1);
      if (((iVar5 == 0) || (*(char *)(iVar5 + 0xd0) == '\0')) &&
         (cVar4 = FUN_008f2050(param_1), cVar4 == '\0')) {
        FUN_01675310("InvalidAccess",&DAT_018bc9b8);
      }
    }
  }
  iStack_8 = 0;
  ppuStack_28 = RBX::Instance::EventInvocationSignalData::vftable;
  uStack_24 = param_2;
  iVar5 = FUN_01674e20(0xc);
  iStack_8._0_1_ = 1;
  if (iVar5 == 0) {
    uVar6 = 0;
  }
  else {
    uVar6 = FUN_006d07c0(param_3);
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  uStack_20 = 0;
  piStack_1c = (int *)0x0;
  FUN_006047e0(uVar6,iVar5);
  uStack_18 = *param_4;
  uStack_14 = param_4[1];
  iStack_8 = 2;
  iVar5 = FUN_006150c0(3,&ppuStack_28);
  piVar3 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 14376 ; VA 0x008a4940 ; FUN_008a4940 */

int __thiscall FUN_008a4940(int *param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined **ppuStack_20;
  uint uStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc210;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(*param_1 + 0x9c))(param_2);
  if (param_1[0xd] != 0) {
    if ((DAT_020c0b1c == '\0') || (DAT_01d62bc8 == '\0')) {
      FUN_008f7870(param_1);
    }
    else {
      iVar5 = FUN_008f7870(param_1);
      if ((iVar5 == 0) || (*(char *)(iVar5 + 0xd0) == '\0')) {
        cVar4 = FUN_008f2050(param_1);
        if (cVar4 == '\0') {
          FUN_01675310("InvalidAccess",&DAT_018bc9b8);
        }
      }
    }
  }
  ppuStack_20 = RBX::Instance::PropertyChangedSignalData::vftable;
  uStack_1c = param_2;
  uStack_8 = 0;
  FUN_006150c0(2,&ppuStack_20);
  iVar5 = FUN_005e6780(param_2);
  iVar2 = param_1[0x11];
  if (iVar2 != 0) {
    uStack_14 = param_2;
    iVar5 = iVar2 + 0x29 + (uint)*(byte *)(iVar2 + 0x28);
    FUN_00606ea0(&iStack_18,(param_2 >> 3) + param_2,&uStack_14,-(uint)(iVar5 != 0) & iVar5 + 1U);
    iVar5 = iStack_18;
    if (iStack_18 != 0) {
      iVar5 = FUN_006eccd0();
    }
  }
  if ((int *)param_1[0xd] != (int *)0x0) {
    (**(code **)(*(int *)param_1[0xd] + 0x94))(param_1,param_2);
    pcVar3 = *(code **)(*(int *)param_1[0xd] + 0x98);
    uVar6 = FUN_0060dcd0(auStack_28,param_1);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar5 = (*pcVar3)(uVar6,param_2);
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_24 + 1;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piStack_24 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar5 = (**(code **)(*piStack_24 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 14377 ; VA 0x008a4ab0 ; FUN_008a4ab0 */

void __thiscall FUN_008a4ab0(int *param_1,int param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = FUN_0087cdb0(DAT_01ede59c);
  if (iVar2 != 0) {
    (**(code **)*param_3)(iVar2 + 8,param_1);
  }
  if (*(int *)(param_2 + 0x10) != DAT_01ede600) {
    (**(code **)(*param_1 + 0xa0))(param_2,param_3);
    return;
  }
  iVar2 = FUN_0087cde0(DAT_01ede604);
  if (iVar2 != 0) {
    for (puVar1 = *(undefined4 **)(iVar2 + 4); puVar1 != (undefined4 *)0x0;
        puVar1 = (undefined4 *)*puVar1) {
      (**(code **)(*param_1 + 0xa0))(puVar1,param_3);
    }
  }
  for (iVar2 = FUN_0087cde0(DAT_01ede600); iVar2 != 0; iVar2 = FUN_0087ce10(iVar2)) {
    FUN_008a4b60(iVar2,param_3,param_4);
  }
  return;
}



/* FUNCTION 14378 ; VA 0x008a4b60 ; FUN_008a4b60 */

int __thiscall FUN_008a4b60(int *param_1,int param_2,undefined4 *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc228;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  iVar4 = FUN_0087cdb0(DAT_01ede5fc);
  if ((iVar4 != 0) && (iVar4 = FUN_0087d000(&uStack_14), (char)iVar4 != '\0')) {
    (**(code **)(*param_1 + 0x50))(&piStack_20,uStack_14,param_4);
    piVar1 = piStack_20;
    uStack_8 = 0;
    iVar4 = FUN_0087cdb0(DAT_01ede59c);
    if (piVar1 == (int *)0x0) {
      if (iVar4 != 0) {
        iVar4 = (**(code **)*param_3)(iVar4 + 8,0);
      }
    }
    else {
      if (iVar4 != 0) {
        (**(code **)*param_3)(iVar4 + 8,piVar1);
      }
      if (*(int *)(param_2 + 0x10) == DAT_01ede600) {
        iVar4 = FUN_0087cde0(DAT_01ede604);
        if (iVar4 != 0) {
          for (puVar3 = *(undefined4 **)(iVar4 + 4); puVar3 != (undefined4 *)0x0;
              puVar3 = (undefined4 *)*puVar3) {
            (**(code **)(*piVar1 + 0xa0))(puVar3,param_3);
          }
        }
        iVar4 = FUN_0087cde0(DAT_01ede600);
        if (iVar4 != 0) {
          do {
            FUN_008a4b60(iVar4,param_3,param_4);
            iVar4 = FUN_0087ce10(iVar4);
          } while (iVar4 != 0);
          iVar4 = 0;
        }
      }
      else {
        iVar4 = (**(code **)(*piVar1 + 0xa0))(param_2,param_3);
      }
      if (piStack_20 != (int *)0x0) {
        iVar4 = FUN_008a65e0(piStack_18,0);
      }
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_1c + 1;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piStack_1c + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar4 = (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 14379 ; VA 0x008a4ce0 ; FUN_008a4ce0 */

void FUN_008a4ce0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  
  if (param_1 != 0) {
    for (iVar1 = FUN_0087cde0(DAT_01ede600); iVar1 != 0; iVar1 = FUN_0087ce10(iVar1)) {
      FUN_008a4b60(iVar1,param_2,param_3);
    }
  }
  return;
}



/* FUNCTION 14380 ; VA 0x008a4d30 ; FUN_008a4d30 */

void __thiscall FUN_008a4d30(int *param_1,int param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  
  for (puVar1 = *(undefined4 **)(param_2 + 4); puVar1 != (undefined4 *)0x0;
      puVar1 = (undefined4 *)*puVar1) {
    (**(code **)(*param_1 + 0xa0))(puVar1,param_3);
  }
  return;
}



/* FUNCTION 14381 ; VA 0x008a4d60 ; FUN_008a4d60 */

void __thiscall FUN_008a4d60(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  undefined4 ****ppppuVar3;
  int *piVar4;
  uint uVar5;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0087cdb0(DAT_01ede5b8);
  if ((iVar2 != 0) && (cVar1 = FUN_0087d060(apppuStack_28), cVar1 != '\0')) {
    ppppuVar3 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar3 = (undefined4 ****)apppuStack_28[0];
    }
    piVar4 = (int *)FUN_00892d20(ppppuVar3);
    if ((piVar4 != (int *)0x0) && (cVar1 = (**(code **)(*piVar4 + 8))(), cVar1 == '\0')) {
      (**(code **)(*piVar4 + 0x38))(param_1,param_2,param_3);
    }
  }
  if (0xf < uStack_14) {
    uVar5 = uStack_14 + 1;
    ppppuVar3 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar5) {
      ppppuVar3 = (undefined4 ****)apppuStack_28[0][-1];
      uVar5 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14382 ; VA 0x008a4e40 ; FUN_008a4e40 */

void __thiscall FUN_008a4e40(int param_1,undefined4 param_2,int param_3,int *param_4)

{
  (**(code **)(*param_4 + 4))
            (-(uint)(param_3 != 0) & param_3 + 0x10U,param_2,-(uint)(param_1 != 0) & param_1 + 0x34U
            );
  return;
}



/* FUNCTION 14383 ; VA 0x008a4e70 ; FUN_008a4e70 */

void FUN_008a4e70(undefined4 param_1,undefined4 *param_2)

{
  undefined auStack_c [8];
  
  param_2 = (undefined4 *)*param_2;
  FUN_00898570(auStack_c,0,&param_2,param_2);
  return;
}



/* FUNCTION 14384 ; VA 0x008a4ea0 ; FUN_008a4ea0 */

void FUN_008a4ea0(undefined4 param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  puVar2 = *(undefined4 **)(param_3 + 0x2c);
  if (puVar2 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)puVar2[1];
    for (puVar2 = (undefined4 *)*puVar2; puVar2 != puVar1; puVar2 = puVar2 + 2) {
      FUN_00da3620(param_1,puVar2);
      *param_2 = *param_2 + 1;
      FUN_01256da0(param_1,0xfffffffe,*param_2);
      FUN_008a4ea0(param_1,param_2,*puVar2);
    }
  }
  return;
}



/* FUNCTION 14385 ; VA 0x008a4ef0 ; FUN_008a4ef0 */

void FUN_008a4ef0(int *param_1,uint *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int *piVar6;
  int *piVar7;
  int iVar8;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9308;
  puVar1 = (undefined4 *)*param_1;
  uVar2 = *param_2;
  puVar4 = (undefined4 *)puVar1[1];
  puStack_14 = puVar1;
  if (*(char *)((int)puVar1[1] + 0xd) == '\0') {
    do {
      if ((uint)puVar4[4] < uVar2) {
        puVar5 = (undefined4 *)puVar4[2];
      }
      else {
        puVar5 = (undefined4 *)*puVar4;
        puStack_14 = puVar4;
      }
      puVar4 = puVar5;
    } while (*(char *)((int)puVar5 + 0xd) == '\0');
    if ((puStack_14 != puVar1) && ((uint)puStack_14[4] <= uVar2)) goto LAB_008a4f46;
  }
  puStack_14 = puVar1;
LAB_008a4f46:
  if (puStack_14 != puVar1) {
    piVar7 = *(int **)(uVar2 + 0x2c);
    ExceptionList = &pvStack_10;
    if (piVar7 != (int *)0x0) {
      piVar6 = *(int **)(uVar2 + 0x30);
      ExceptionList = &pvStack_10;
      if (piVar6 != (int *)0x0) {
        LOCK();
        ExceptionList = &pvStack_10;
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
        piVar6 = *(int **)(uVar2 + 0x30);
        piVar7 = *(int **)(uVar2 + 0x2c);
      }
      iVar3 = piVar7[1];
      iVar8 = *piVar7;
      uStack_8 = 0;
      for (; piStack_18 = piVar6, iVar8 != iVar3; iVar8 = iVar8 + 8) {
        FUN_008a4ef0(param_1,iVar8);
        piVar6 = piStack_18;
      }
      uStack_8 = 0xffffffff;
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar3 = piVar6[1] + -1;
        piVar6[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          piVar7 = piVar6 + 2;
          iVar3 = *piVar7;
          *piVar7 = *piVar7 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
    }
    param_2 = *(uint **)(*param_2 + 0x34);
    FUN_00601f20(&piStack_18,&param_2);
    if (piStack_18 != (int *)*param_1) {
      FUN_008a65e0(piStack_18[5],0);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14386 ; VA 0x008a5010 ; FUN_008a5010 */

int __fastcall FUN_008a5010(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbe08;
  pvStack_10 = ExceptionList;
  piVar5 = *(int **)(param_1 + 0x30);
  ExceptionList = &pvStack_10;
  if (piVar5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = *(int **)(param_1 + 0x30);
  }
  piVar1 = *(int **)(param_1 + 0x2c);
  uStack_8 = 0;
  iVar3 = FUN_008a65e0(0,0);
  if (piVar1 != (int *)0x0) {
    iVar2 = piVar1[1];
    for (iVar4 = *piVar1; iVar4 != iVar2; iVar4 = iVar4 + 8) {
      iVar3 = FUN_008a5010();
    }
  }
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar1 = piVar5 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 14387 ; VA 0x008a50b0 ; FUN_008a50b0 */

void __fastcall FUN_008a50b0(int param_1)

{
  int iVar1;
  void **ppvVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179e158;
  iVar1 = *(int *)(param_1 + 0x2c);
  ppvVar2 = &pvStack_10;
  pvStack_10 = ExceptionList;
  while (ExceptionList = ppvVar2, iVar1 != 0) {
    iVar1 = *(int *)(iVar1 + 4);
    piVar3 = *(int **)(iVar1 + -4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
      piVar3 = *(int **)(iVar1 + -4);
    }
    uStack_8 = 0;
    FUN_008a5010();
    uStack_8 = 0xffffffff;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar1 = piVar3[1] + -1;
      piVar3[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar1 = piVar3[2] + -1;
        piVar3[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    ppvVar2 = (void **)ExceptionList;
    iVar1 = *(int *)(param_1 + 0x2c);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14388 ; VA 0x008a5140 ; FUN_008a5140 */

void FUN_008a5140(undefined4 param_1,undefined **param_2,undefined *param_3)

{
  int *piVar1;
  char cVar2;
  char *pcVar3;
  int iVar4;
  char *pcVar5;
  char *pcVar6;
  undefined auStack_228 [12];
  undefined4 uStack_21c;
  char *pcStack_218;
  int iStack_214;
  undefined auStack_210 [12];
  undefined4 uStack_204;
  char *pcStack_200;
  undefined4 uStack_1fc;
  undefined *puStack_1f8;
  int *piStack_1f4;
  undefined4 uStack_1f0;
  int iStack_1ec;
  int iStack_1e8;
  int iStack_1e4;
  undefined4 uStack_1dc;
  undefined *puStack_1d8;
  undefined4 uStack_1d4;
  int *piStack_1d0;
  code *pcStack_1cc;
  int iStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined auStack_f0 [16];
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined uStack_c0;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined uStack_90;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined uStack_78;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined uStack_60;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined uStack_48;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = (int *)param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc2cb;
  pvStack_10 = ExceptionList;
  pcStack_1cc = *(code **)((int)*param_2 + 4);
  piStack_1d0 = (int *)0x8a5173;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  piStack_1d0 = &iStack_1c0;
  pcStack_1cc = (code *)param_1;
  uStack_8 = 0;
  uStack_1d4 = 0x8a518d;
  FUN_008a1ac0();
  pcStack_1cc = (code *)0xd;
  piStack_1d0 = (int *)&DAT_0191e440;
  iVar4 = *(int *)(iStack_1c0 + 0x1c);
  uStack_8._0_1_ = 1;
  uStack_e0 = 0;
  uStack_dc = 0xf;
  auStack_f0[0] = 0;
  uStack_1d4 = 0x8a51d0;
  param_2._3_1_ = iStack_1c0 != *piVar1;
  FUN_005542c0();
  pcStack_1cc = (code *)param_1;
  uStack_8._0_1_ = 2;
  piStack_1d0 = (int *)0x8a51e0;
  FUN_0054ef60();
  pcStack_1cc = (code *)0xd;
  piStack_1d0 = (int *)0x191e454;
  uStack_8._0_1_ = 3;
  uStack_b0 = 0;
  uStack_ac = 0xf;
  uStack_c0 = 0;
  uStack_1d4 = 0x8a5211;
  FUN_005542c0();
  pcStack_1cc = (code *)aiStack_30;
  uStack_8._0_1_ = 4;
  piStack_1d0 = (int *)0x8a5224;
  FUN_0054ef60();
  pcVar5 = "true";
  uStack_8._0_1_ = 5;
  pcStack_1cc = (code *)0xe;
  uStack_80 = 0;
  pcVar6 = "true";
  uStack_7c = 0xf;
  piStack_1d0 = (int *)0x191e464;
  if (param_2._3_1_ == '\0') {
    pcVar6 = "false";
  }
  uStack_90 = 0;
  uStack_1d4 = 0x8a5262;
  FUN_005542c0();
  uStack_8._0_1_ = 6;
  uStack_68 = 0;
  uStack_64 = 0xf;
  uStack_78 = 0;
  pcVar3 = pcVar6;
  do {
    cVar2 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar2 != '\0');
  pcStack_1cc = (code *)((int)pcVar3 - (int)(pcVar6 + 1));
  uStack_1d4 = 0x8a5293;
  piStack_1d0 = (int *)pcVar6;
  FUN_005542c0();
  pcStack_1cc = (code *)0x10;
  uStack_8._0_1_ = 7;
  piStack_1d0 = (int *)0x191e474;
  if (iVar4 != 0) {
    pcVar5 = "false";
  }
  uStack_50 = 0;
  uStack_4c = 0xf;
  uStack_60 = 0;
  uStack_1d4 = 0x8a52c4;
  FUN_005542c0();
  uStack_8._0_1_ = 8;
  uStack_38 = 0;
  uStack_34 = 0xf;
  uStack_48 = 0;
  pcVar6 = pcVar5;
  do {
    cVar2 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar2 != '\0');
  pcStack_1cc = (code *)((int)pcVar6 - (int)(pcVar5 + 1));
  uStack_1d4 = 0x8a52f3;
  piStack_1d0 = (int *)pcVar5;
  FUN_005542c0();
  uStack_8._0_1_ = 9;
  iStack_1e4 = (int)&param_2 + 3;
  piStack_1f4 = aiStack_30;
  iStack_1e8 = (int)&param_2 + 3;
  iStack_1ec = (int)&param_2 + 3;
  uStack_1f0 = 0xb;
  puStack_1f8 = auStack_f0;
  uStack_1fc = 0x8a531d;
  FUN_006370e0();
  param_2 = &puStack_1f8;
  uStack_8._0_1_ = 10;
  uStack_1fc = 0xc;
  iStack_1e8 = 0;
  iStack_1e4 = 0xf;
  pcStack_200 = "SetAttribute";
  puStack_1f8 = (undefined *)((uint)puStack_1f8 & 0xffffff00);
  uStack_204 = 0x8a5346;
  FUN_005542c0();
  pcStack_218 = "Properties ";
  uStack_8._0_1_ = 0xb;
  if ((char)param_3 == '\0') {
    pcStack_218 = "Lua";
  }
  param_3 = auStack_210;
  pcStack_200 = (char *)0x0;
  uStack_1fc = 0xf;
  auStack_210[0] = 0;
  pcVar5 = pcStack_218;
  do {
    cVar2 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar2 != '\0');
  iStack_214 = (int)pcVar5 - (int)(pcStack_218 + 1);
  uStack_21c = 0x8a5392;
  FUN_005542c0();
  puStack_18 = auStack_228;
  uStack_8._0_1_ = 0xc;
  cVar2 = FUN_0097c970(uStack_14,1);
  pcStack_218 = (char *)0x0;
  iStack_214 = 0xf;
  auStack_228[0] = 0;
  pcVar5 = "client";
  if (cVar2 == '\0') {
    pcVar5 = "RCC";
  }
  pcVar6 = pcVar5;
  do {
    cVar2 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(pcVar5,(int)pcVar6 - (int)(pcVar5 + 1));
  uStack_8._0_1_ = 9;
  FUN_0087a540();
  uStack_8._0_1_ = 1;
  puStack_1d8 = auStack_f0;
  pcStack_1cc = FUN_005509f0;
  piStack_1d0 = (int *)0x4;
  uStack_1d4 = 0x30;
  uStack_1dc = 0x8a5407;
  FUN_016f32d1();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  if (iStack_1bc != 0) {
    pcStack_1cc = (code *)auStack_1b8;
    piStack_1d0 = (int *)0x8a5421;
    (**(code **)(iStack_1bc + 8))();
  }
  if (0xf < uStack_1c) {
    pcStack_1cc = (code *)(uStack_1c + 1);
    iVar4 = aiStack_30[0];
    if (0xfff < pcStack_1cc) {
      iVar4 = *(int *)(aiStack_30[0] + -4);
      pcStack_1cc = (code *)(uStack_1c + 0x24);
      if (0x1f < (aiStack_30[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        pcStack_1cc = (code *)&UNK_008a546b;
        FUN_017167a3();
      }
    }
    uStack_1d4 = 0x8a5451;
    piStack_1d0 = (int *)iVar4;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14389 ; VA 0x008a5470 ; FUN_008a5470 */

int FUN_008a5470(void)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined3 uVar6;
  undefined4 *puVar7;
  int iVar8;
  int *in_stack_00000018;
  int *in_stack_00000024;
  undefined auStack_f0 [4];
  int iStack_ec;
  undefined auStack_e8 [200];
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017bc30b;
  pvStack_10 = ExceptionList;
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  piStack_18 = in_stack_00000018;
  ExceptionList = &pvStack_10;
  if (in_stack_00000018 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *in_stack_00000018 = *in_stack_00000018 + 1;
    UNLOCK();
  }
  uStack_7 = 0;
  uVar6 = uStack_7;
  uStack_8 = 2;
  uStack_7 = 0;
  if (in_stack_00000018 != (int *)0x0) {
    if (in_stack_00000018[2] != 0) {
      FUN_0094fc20(in_stack_00000018[2]);
      FUN_006874f0(&stack0x00000020);
      uStack_8 = 3;
      puVar7 = (undefined4 *)FUN_009d0450(auStack_20,auStack_f0);
      _uStack_8 = CONCAT31(uStack_7,4);
      uVar3 = *puVar7;
      uVar4 = puVar7[1];
      *puVar7 = 0;
      puVar7[1] = 0;
      LOCK();
      *in_stack_00000018 = *in_stack_00000018 + 1;
      UNLOCK();
      FUN_0095c220(in_stack_00000018,uVar3,uVar4);
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar8 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          iVar8 = piStack_1c[2] + -1;
          piStack_1c[2] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
      uStack_8 = 5;
      uVar6 = uStack_7;
      if (iStack_ec != 0) {
        (**(code **)(iStack_ec + 8))(auStack_e8);
        uVar6 = uStack_7;
      }
    }
    uStack_7 = uVar6;
    LOCK();
    iVar8 = *in_stack_00000018;
    *in_stack_00000018 = *in_stack_00000018 + -1;
    UNLOCK();
    uVar6 = uStack_7;
    if (iVar8 == 1) {
      FUN_00d88950();
      FUN_01674ea0(in_stack_00000018,0x10);
      uVar6 = uStack_7;
    }
  }
  uStack_7 = uVar6;
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  iVar8 = FUN_00d88aa0();
  piVar5 = in_stack_00000024;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000024 + 1;
    iVar2 = *piVar1;
    iVar8 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar8 = (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar8 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 14390 ; VA 0x008a55f0 ; FUN_008a55f0 */

void __thiscall FUN_008a55f0(int param_1,undefined4 param_2)

{
  char cVar1;
  uint uVar2;
  int iVar3;
  
  iVar3 = *(int *)(*(int *)(param_1 + 0xc) + 0x1d0);
  if ((iVar3 != 0) || (*(char *)(param_1 + 0x24) != '\0')) {
    if ((iVar3 != 0) && (cVar1 = FUN_01255580(param_2,iVar3), cVar1 == '\0')) {
      FUN_01255600(iVar3,"Class security check");
    }
    if (*(char *)(param_1 + 0x24) != '\0') {
      iVar3 = 0;
      uVar2 = 1;
      do {
        if (((*(byte *)(param_1 + 0x24) & (byte)uVar2) != 0) &&
           (cVar1 = FUN_01255580(param_2,iVar3), cVar1 == '\0')) {
          FUN_01255600(iVar3,"Class security check");
        }
        iVar3 = iVar3 + 1;
        uVar2 = uVar2 << 1 | (uint)((int)uVar2 < 0);
      } while (iVar3 < 8);
    }
  }
  return;
}



/* FUNCTION 14391 ; VA 0x008a5680 ; FUN_008a5680 */

void __thiscall FUN_008a5680(int param_1,undefined4 param_2)

{
  char cVar1;
  uint uVar2;
  int iVar3;
  
  iVar3 = *(int *)(*(int *)(param_1 + 0xc) + 0x1d0);
  if ((iVar3 != 0) && (cVar1 = FUN_01255580(param_2,iVar3), cVar1 == '\0')) {
    FUN_01255600(iVar3,"Class security check");
  }
  if (*(char *)(param_1 + 0x24) != '\0') {
    iVar3 = 0;
    uVar2 = 1;
    do {
      if (((*(byte *)(param_1 + 0x24) & (byte)uVar2) != 0) &&
         (cVar1 = FUN_01255580(param_2,iVar3), cVar1 == '\0')) {
        FUN_01255600(iVar3,"Class security check");
      }
      iVar3 = iVar3 + 1;
      uVar2 = uVar2 << 1 | (uint)((int)uVar2 < 0);
    } while (iVar3 < 8);
  }
  return;
}



/* FUNCTION 14392 ; VA 0x008a5700 ; FUN_008a5700 */

void __thiscall FUN_008a5700(int param_1,undefined4 param_2)

{
  char cVar1;
  char cVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc320;
  pvStack_10 = ExceptionList;
  cVar1 = *(char *)(param_1 + 0x22);
  ExceptionList = &pvStack_10;
  *(undefined *)(param_1 + 0x22) = 1;
  uStack_8 = 0;
  cVar2 = FUN_008a65e0(param_2,1);
  if ((cVar2 == '\0') && (cVar1 == '\0')) {
    *(undefined *)(param_1 + 0x22) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14393 ; VA 0x008a575f ; Catch@008a575f */

void Catch_008a575f(void)

{
  int unaff_EBP;
  
  if (*(char *)(unaff_EBP + -0x11) == '\0') {
    FUN_00631dd0();
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14394 ; VA 0x008a5780 ; FUN_008a5780 */

void FUN_008a5780(byte *param_1,int param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined3 uVar3;
  char cVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  byte *pbVar9;
  byte *pbVar10;
  uint uVar11;
  uint uVar12;
  bool bVar13;
  int *piVar14;
  undefined auStack_1dc [4];
  int iStack_1d8;
  undefined auStack_1d4 [200];
  int iStack_10c;
  int iStack_108;
  undefined auStack_104 [200];
  undefined auStack_3c [16];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017bc367;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01d62c08 == '\0') {
    ExceptionList = &pvStack_10;
    if (DAT_01d62c18 == '\0') {
LAB_008a5a3c:
      FUN_016756b0(auStack_1c,"Attributes are not currently enabled");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = &pvStack_10;
    uVar5 = FUN_01255560();
    cVar4 = FUN_01255580(uVar5,5);
    if (cVar4 == '\0') goto LAB_008a5a3c;
  }
  uVar11 = 3;
  if (*(uint *)(param_1 + 0x10) < 3) {
    uVar11 = *(uint *)(param_1 + 0x10);
  }
  pbVar9 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pbVar9 = *(byte **)param_1;
  }
  uVar12 = uVar11;
  if (3 < uVar11) {
    uVar12 = 3;
  }
  pbVar10 = &DAT_0191e43c;
  while (uVar2 = uVar12 - 4, 3 < uVar12) {
    if (*(int *)pbVar9 != *(int *)pbVar10) goto LAB_008a5826;
    pbVar9 = pbVar9 + 4;
    pbVar10 = pbVar10 + 4;
    uVar12 = uVar2;
  }
  if (uVar2 == 0xfffffffc) {
LAB_008a585a:
    uVar12 = 0;
  }
  else {
LAB_008a5826:
    bVar13 = *pbVar9 < *pbVar10;
    if ((*pbVar9 == *pbVar10) &&
       ((uVar2 == 0xfffffffd ||
        ((bVar13 = pbVar9[1] < pbVar10[1], pbVar9[1] == pbVar10[1] &&
         ((uVar2 == 0xfffffffe ||
          ((bVar13 = pbVar9[2] < pbVar10[2], pbVar9[2] == pbVar10[2] &&
           ((uVar2 == 0xffffffff || (bVar13 = pbVar9[3] < pbVar10[3], pbVar9[3] == pbVar10[3])))))))
         ))))) goto LAB_008a585a;
    uVar12 = -(uint)bVar13 | 1;
  }
  if (((uVar12 == 0) && (2 < uVar11)) && (uVar11 < 4)) {
    uVar5 = FUN_01255560();
    cVar4 = FUN_01255580(uVar5,5);
    if (cVar4 == '\0') {
      uVar5 = FUN_005543f0();
      FUN_016756b0(auStack_1c,"Attempt to assign attribute %s. CoreScript permission required",uVar5
                  );
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
  }
  iVar7 = param_2;
  if (DAT_01d62c20 == '\0') {
    if (*(uint *)(param_1 + 0x10) == 0) {
      FUN_016756b0(auStack_1c,"Attribute names cannot be empty");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    if (100 < *(uint *)(param_1 + 0x10)) {
      FUN_016756b0(auStack_1c,"Attribute names are limited to 100 characters");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
  }
  else {
    iVar6 = FUN_00888530();
    if (iVar7 != iVar6) {
      uStack_2c = 0;
      uStack_28 = 0xf;
      auStack_3c[0] = 0;
      iStack_8._0_1_ = 1;
      iVar7 = FUN_008a7bf0(param_1,auStack_3c);
      if (iVar7 != 0) {
        uVar5 = FUN_005543f0();
        uVar8 = FUN_005543f0();
        FUN_016756b0(auStack_1c,"%s (\"%s\")",uVar8,uVar5);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_1c,&DAT_01c17198);
      }
      cVar4 = FUN_008a36b0(param_2);
      if (cVar4 == '\0') {
        FUN_0054db20();
        uVar5 = FUN_005543f0();
        FUN_016756b0(auStack_1c,"%s is not a supported attribute type",uVar5);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_1c,&DAT_01c17198);
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_005507b0();
    }
  }
  cVar4 = FUN_00cb4450(&param_2);
  if (cVar4 == '\0') {
    FUN_0054db20();
    uVar5 = FUN_005543f0();
    FUN_016756b0(auStack_1c,"%s is not a serializable attribute type",uVar5);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  FUN_0056a440(&param_2);
  iStack_8._0_1_ = 2;
  if (DAT_01d62c10 != '\0') {
    uVar5 = FUN_008a1ac0(auStack_1dc,param_1);
    iStack_8 = CONCAT31(iStack_8._1_3_,3);
    uStack_24 = 1;
    cVar4 = FUN_0089c960(&iStack_10c,uVar5);
    if (cVar4 != '\0') {
      bVar13 = true;
      goto LAB_008a595d;
    }
  }
  bVar13 = false;
LAB_008a595d:
  iStack_8._1_3_ = 0;
  uVar3 = iStack_8._1_3_;
  if ((uStack_24 & 1) != 0) {
    iStack_8._1_3_ = 0;
    uVar3 = iStack_8._1_3_;
    iStack_8._0_1_ = 4;
    iStack_8._1_3_ = 0;
    if (iStack_1d8 != 0) {
      (**(code **)(iStack_1d8 + 8))(auStack_1d4);
      uVar3 = iStack_8._1_3_;
    }
  }
  iStack_8._1_3_ = uVar3;
  iStack_8._0_1_ = 2;
  if (bVar13) {
    iStack_8 = CONCAT31(iStack_8._1_3_,5);
  }
  else {
    if (piStack_20[0x11] == 0) {
      iVar7 = (**(code **)(*piStack_20 + 0x14))();
      puVar1 = (undefined4 *)piStack_20[0x11];
      piStack_20[0x11] = iVar7;
      if (puVar1 != (undefined4 *)0x0) {
        (**(code **)*puVar1)(1);
      }
    }
    iVar7 = FUN_00888530();
    if (iStack_10c == iVar7) {
      FUN_0089fe90(param_1);
    }
    else {
      piVar14 = &iStack_10c;
      FUN_005c4c00(param_1);
      FUN_0056ee80(piVar14);
    }
    FUN_008a46b0(param_1,1);
    iStack_8 = CONCAT31(iStack_8._1_3_,6);
  }
  if (iStack_108 != 0) {
    (**(code **)(iStack_108 + 8))(auStack_104);
  }
  iStack_8 = 7;
  if (param_3 != 0) {
    (**(code **)(param_3 + 8))(&stack0x00000010);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14395 ; VA 0x008a5b60 ; FUN_008a5b60 */

void __thiscall FUN_008a5b60(int *param_1,undefined4 param_2,int param_3,int param_4)

{
  uint3 uVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  bool bVar6;
  undefined4 *puVar7;
  undefined auStack_e8 [4];
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017bc3a4;
  pvStack_10 = ExceptionList;
  bVar6 = false;
  uStack_18 = 0;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01d62c10 != '\0') {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_008a1ac0(auStack_e8,param_2);
    iStack_8 = CONCAT31(iStack_8._1_3_,1);
    bVar6 = true;
    uStack_18 = 1;
    cVar2 = FUN_0089c960(&param_3,uVar3);
    cStack_11 = '\x01';
    if (cVar2 != '\0') goto LAB_008a5bc5;
  }
  cStack_11 = '\0';
LAB_008a5bc5:
  iStack_8 = 0;
  if (bVar6) {
    iStack_8._1_3_ = 0;
    uVar1 = iStack_8._1_3_;
    iStack_8._0_1_ = 2;
    iStack_8._1_3_ = 0;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
      uVar1 = iStack_8._1_3_;
    }
    iStack_8._1_3_ = uVar1;
    iStack_8 = (uint)iStack_8._1_3_ << 8;
  }
  if (cStack_11 == '\0') {
    if (param_1[0x11] == 0) {
      iVar4 = (**(code **)(*param_1 + 0x14))();
      puVar7 = (undefined4 *)param_1[0x11];
      param_1[0x11] = iVar4;
      if (puVar7 != (undefined4 *)0x0) {
        (**(code **)*puVar7)(1);
      }
    }
    iVar4 = param_3;
    iVar5 = FUN_00888530();
    if (iVar4 == iVar5) {
      FUN_0089fe90(param_2);
    }
    else {
      puVar7 = &param_3;
      FUN_005c4c00(param_2);
      FUN_0056ee80(puVar7);
    }
    FUN_008a46b0(param_2,1);
  }
  iStack_8 = 3;
  if (param_4 != 0) {
    (**(code **)(param_4 + 8))(&stack0x00000010);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14396 ; VA 0x008a5c80 ; FUN_008a5c80 */

void FUN_008a5c80(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined auStack_e4 [184];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_24;
  undefined *puStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc3b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01d62c00 != '\0') {
    puStack_20 = (undefined *)0x0;
    puStack_24 = &param_2;
    uStack_28 = param_1;
    uStack_2c = 0x8a5cbb;
    ExceptionList = &pvStack_10;
    FUN_008a5140();
  }
  if (param_3 != (undefined4 *)0x0) {
    (*(code *)*param_3)(&stack0x00000010,auStack_e4);
  }
  FUN_008a5780(param_1);
  uStack_8 = 1;
  if (param_3 != (undefined4 *)0x0) {
    puStack_20 = &stack0x00000010;
    puStack_24 = (undefined4 *)0x8a5d0f;
    (*(code *)param_3[2])();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14397 ; VA 0x008a5d30 ; FUN_008a5d30 */

int __thiscall FUN_008a5d30(int *param_1,byte *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  byte bVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  undefined4 *puVar8;
  int *piVar9;
  undefined auStack_104 [4];
  int iStack_100;
  undefined auStack_fc [200];
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  char cStack_15;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc3eb;
  pvStack_10 = ExceptionList;
  iStack_20 = param_1[0x11];
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_30 = param_1;
  if (iStack_20 == 0) {
    ExceptionList = &pvStack_10;
    iStack_20 = (**(code **)(*param_1 + 0x14))();
    puVar8 = (undefined4 *)param_1[0x11];
    param_1[0x11] = iStack_20;
    if (puVar8 != (undefined4 *)0x0) {
      (**(code **)*puVar8)(1);
      iStack_20 = param_1[0x11];
    }
  }
  piVar7 = (int *)0x0;
  piStack_14 = (int *)0x0;
  piStack_28 = (int *)0x0;
  piStack_1c = (int *)0x0;
  piStack_24 = (int *)0x0;
  iVar5 = *(int *)(iStack_20 + 0x5c);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  piStack_2c = piStack_14;
  if (*(int *)(iVar5 + 8) == 0) {
    puVar8 = (undefined4 *)0x0;
  }
  else {
    puVar8 = *(undefined4 **)(*(int *)(iVar5 + 0x14) + *(int *)(iVar5 + 4) * 4);
  }
  for (; piVar9 = piStack_2c, piVar1 = piStack_2c, puVar8 != (undefined4 *)0x0;
      puVar8 = (undefined4 *)*puVar8) {
    bVar3 = *param_2;
    uVar4 = FUN_00563b90(puVar8 + 2);
    FUN_00562fc0(&piStack_14,uVar4,puVar8 + 2,
                 -(uint)(param_2 + bVar3 + 1 != (byte *)0x0) & (uint)(param_2 + bVar3 + 1 + 1));
    if (piStack_14 == (int *)0x0) {
      if (piStack_1c == piVar7) {
        FUN_00559960(piVar7,puVar8 + 2);
        piStack_1c = piStack_24;
        piVar7 = piStack_28;
      }
      else {
        FUN_0054ef60(puVar8 + 2);
        piStack_28 = piVar7 + 6;
        piVar7 = piStack_28;
      }
    }
  }
  for (; piStack_14 = piVar1, piVar9 != piVar7; piVar9 = piVar9 + 6) {
    FUN_0089fe90(piVar9);
    piVar1 = piStack_14;
  }
  if (*(int *)(param_2 + 8) == 0) {
    piVar9 = (int *)0x0;
  }
  else {
    piVar9 = *(int **)(*(int *)(param_2 + 0x14) + *(int *)(param_2 + 4) * 4);
  }
  if (piVar9 != (int *)0x0) {
    do {
      piVar1 = piVar9 + 2;
      uVar4 = FUN_008a1ac0(auStack_104,piVar1);
      piStack_34 = piVar9 + 8;
      uStack_8._0_1_ = 2;
      cStack_15 = FUN_0089c960(uVar4,piStack_34);
      uStack_8._0_1_ = 3;
      if (iStack_100 != 0) {
        (**(code **)(iStack_100 + 8))(auStack_fc);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (cStack_15 == '\0') {
        if (piStack_1c == piVar7) {
          FUN_00559960(piVar7,piVar1);
          piStack_1c = piStack_24;
        }
        else {
          FUN_0054ef60(piVar1);
          piStack_28 = piVar7 + 6;
        }
        piVar7 = piStack_28;
        iVar5 = FUN_005c4c00(piVar1);
        piStack_14 = piVar9 + 9;
        piVar1 = (int *)(iVar5 + 0x1c);
        *(int *)(iVar5 + 0x18) = piVar9[8];
        if (piStack_14 != piVar1) {
          if (*piVar1 != 0) {
            (**(code **)(*piVar1 + 8))(iVar5 + 0x20);
            *piVar1 = 0;
          }
          if ((undefined4 *)*piStack_14 != (undefined4 *)0x0) {
            (**(code **)*piStack_14)(piStack_14 + 1,iVar5 + 0x20);
            *piVar1 = piStack_34[1];
          }
        }
      }
      piVar9 = (int *)*piVar9;
    } while (piVar9 != (int *)0x0);
    piStack_14 = piStack_2c;
  }
  piVar9 = piStack_14;
  iVar5 = FUN_008a4940(&DAT_0211a590);
  piVar1 = piVar9;
  for (; piVar9 != piVar7; piVar9 = piVar9 + 6) {
    iVar5 = FUN_008a46b0(piVar9,0);
    piVar1 = piStack_14;
  }
  if (piVar1 != (int *)0x0) {
    FUN_00559570(piVar1,piVar7,&piStack_2c);
    uVar6 = (((int)piStack_1c - (int)piVar1) / 0x18) * 0x18;
    piVar7 = piVar1;
    if (0xfff < uVar6) {
      piVar7 = (int *)piVar1[-1];
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uint)((int)piVar1 + (-4 - (int)piVar7))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(piVar7,uVar6);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar7 = param_3 + 1;
    iVar2 = *piVar7;
    iVar5 = *piVar7;
    *piVar7 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar7 = param_3 + 2;
      iVar2 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 14398 ; VA 0x008a6020 ; FUN_008a6020 */

void __thiscall FUN_008a6020(int *param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined *puVar4;
  int iVar5;
  undefined auStack_dc [192];
  undefined4 uStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc413;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff18;
  if (*(int *)(param_2 + 0x10) == 0) {
    if (param_1[0x11] != 0) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffff18;
      FUN_0089d910();
    }
    ExceptionList = pvStack_10;
    return;
  }
  iVar5 = param_1[0x11];
  ExceptionList = &pvStack_10;
  puVar4 = &stack0xffffff18;
  if (iVar5 == 0) {
    ExceptionList = &pvStack_10;
    iVar5 = (**(code **)(*param_1 + 0x14))();
    puVar2 = (undefined4 *)param_1[0x11];
    param_1[0x11] = iVar5;
    puVar4 = puStack_14;
    if (puVar2 != (undefined4 *)0x0) {
      (**(code **)*puVar2)(1);
      iVar5 = param_1[0x11];
      puVar4 = puStack_14;
    }
  }
  puStack_14 = puVar4;
  FUN_00565940(3,1);
  uStack_8 = 0;
  FUN_006f6810(param_2);
  uStack_8._0_1_ = 1;
  FUN_00888650(&uStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00cb40d0(auStack_dc,uStack_1c,0);
  piVar1 = piStack_18;
  *(undefined4 *)(iVar5 + 0x5c) = uStack_1c;
  piVar3 = *(int **)(iVar5 + 0x60);
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  *(int **)(iVar5 + 0x60) = piVar1;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[1] + -1;
    piVar3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar5 = piVar3[2] + -1;
      piVar3[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    piVar3 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_18[1] + -1;
      piStack_18[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14399 ; VA 0x008a6162 ; Catch@008a6162 */

void Catch_008a6162(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))();
  FUN_016756b0(unaff_EBP + -0x28,"Failed to read Attributes: %s",uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -0x28,&DAT_01c17198);
}



/* FUNCTION 14400 ; VA 0x008a6190 ; FUN_008a6190 */

void __thiscall FUN_008a6190(int *param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  int in_stack_00000014;
  uint in_stack_00000018;
  undefined auStack_ec [192];
  int *piStack_2c;
  int iStack_28;
  uint uStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc43b;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff08;
  uStack_8 = 0;
  if (in_stack_00000014 == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffff08;
    if (param_1[0x11] != 0) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffff08;
      FUN_0089d910();
    }
  }
  else {
    iStack_28 = param_1[0x11];
    ExceptionList = &pvStack_10;
    puVar3 = &stack0xffffff08;
    if (iStack_28 == 0) {
      ExceptionList = &pvStack_10;
      iStack_28 = (**(code **)(*param_1 + 0x14))();
      puVar2 = (undefined4 *)param_1[0x11];
      param_1[0x11] = iStack_28;
      puVar3 = puStack_14;
      if (puVar2 != (undefined4 *)0x0) {
        (**(code **)*puVar2)(1);
        iStack_28 = param_1[0x11];
        puVar3 = puStack_14;
      }
    }
    puStack_14 = puVar3;
    iVar4 = iStack_28;
    FUN_00565940(3,1);
    uStack_8._0_1_ = 1;
    FUN_006f6810(&param_2);
    uStack_8._0_1_ = 2;
    FUN_00888650(&iStack_20);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_00cb40d0(auStack_ec,iStack_20,0);
    iVar5 = iStack_20;
    if (DAT_01d62c20 != '\0') {
      iStack_18 = iStack_20;
      if (*(int *)(iStack_20 + 8) == 0) {
        piVar8 = (int *)0x0;
      }
      else {
        piVar8 = *(int **)(*(int *)(iStack_20 + 0x14) + *(int *)(iStack_20 + 4) * 4);
      }
LAB_008a6280:
      do {
        iVar4 = iStack_28;
        if (piVar8 == (int *)0x0) break;
        uVar6 = piVar8[6];
        piVar9 = piVar8 + 2;
        if ((uVar6 != 0) && (uVar6 < 0x65)) {
          if (0xf < (uint)piVar8[7]) {
            piVar9 = (int *)*piVar9;
          }
          piVar1 = (int *)((int)piVar9 + uVar6);
          if (piVar9 != piVar1) {
            do {
              iVar4 = FUN_0171dac9((int)*(char *)piVar9);
              iVar5 = iStack_20;
              if ((iVar4 == 0) && (*(char *)piVar9 != '_')) {
                iStack_18 = iStack_20;
                goto switchD_008a62e2_caseD_2;
              }
              piVar9 = (int *)((int)piVar9 + 1);
            } while (piVar9 != piVar1);
            iStack_18 = iStack_20;
          }
          switch(*(undefined4 *)(piVar8[8] + 0x1c)) {
          case 0:
          case 1:
          case 4:
          case 5:
          case 6:
          case 0xb:
          case 0xc:
          case 0xf:
          case 0x11:
          case 0x13:
          case 0x14:
          case 0x1c:
          case 0x29:
          case 0x2b:
          case 0x2c:
            piVar8 = (int *)*piVar8;
            goto LAB_008a6280;
          }
        }
switchD_008a62e2_caseD_2:
        uStack_24 = (uint)piVar8[1] % *(uint *)(iVar5 + 4);
        piVar9 = (int *)*piVar8;
        piVar1 = *(int **)(*(int *)(iVar5 + 0x14) + uStack_24 * 4);
        for (piVar7 = (int *)*piVar1; piStack_2c = piVar1, piVar7 != piVar8; piVar7 = (int *)*piVar7
            ) {
          piVar1 = piVar7;
        }
        do {
          *piVar1 = *piVar7;
          FUN_00560ab0(-(uint)(iVar5 != -3) & iVar5 + 4U,piVar7 + 2);
          FUN_01674ea0(piVar7,0xf0);
          *(int *)(iStack_18 + 8) = *(int *)(iStack_18 + 8) + -1;
          uVar6 = uStack_24;
          if (*piVar1 == 0) {
LAB_008a636e:
            if (*(int **)(*(int *)(iStack_18 + 0x14) + uStack_24 * 4) == piVar1) {
              *(undefined4 *)(*(int *)(iStack_18 + 0x14) + uStack_24 * 4) = 0;
            }
          }
          else {
            uVar6 = *(uint *)(*piVar1 + 4) % *(uint *)(iStack_18 + 4);
            if (uStack_24 != uVar6) {
              *(int **)(*(int *)(iStack_18 + 0x14) + uVar6 * 4) = piVar1;
              goto LAB_008a636e;
            }
          }
          piVar7 = (int *)*piVar1;
          iVar5 = iStack_18;
          uStack_24 = uVar6;
        } while (piVar7 != piVar9);
        iStack_18 = iStack_20;
        iVar5 = iStack_20;
        piVar8 = piVar9;
      } while( true );
    }
    piVar9 = piStack_1c;
    *(int *)(iVar4 + 0x5c) = iVar5;
    piVar8 = *(int **)(iVar4 + 0x60);
    iStack_20 = 0;
    piStack_1c = (int *)0x0;
    *(int **)(iVar4 + 0x60) = piVar9;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar4 = piVar8[1] + -1;
      piVar8[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar8)();
        LOCK();
        iVar4 = piVar8[2] + -1;
        piVar8[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
      piVar8 = piStack_1c;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar4 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar9 = piVar8 + 2;
          iVar4 = *piVar9;
          *piVar9 = *piVar9 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
    }
    FUN_005705c0();
  }
  if (0xf < in_stack_00000018) {
    uVar6 = in_stack_00000018 + 1;
    iVar4 = param_2;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(param_2 + -4);
      uVar6 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14401 ; VA 0x008a6450 ; Catch@008a6450 */

void Catch_008a6450(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x2c) + 4))();
  FUN_016756b0(unaff_EBP + -0x38,"Failed to read Attributes: %s",uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -0x38,&DAT_01c17198);
}



/* FUNCTION 14402 ; VA 0x008a64c0 ; FUN_008a64c0 */

void __thiscall FUN_008a64c0(int *param_1,undefined param_2)

{
  undefined4 *puVar1;
  int iVar2;
  
  if (param_1[0x11] == 0) {
    iVar2 = (**(code **)(*param_1 + 0x14))();
    puVar1 = (undefined4 *)param_1[0x11];
    param_1[0x11] = iVar2;
    if (puVar1 != (undefined4 *)0x0) {
      (**(code **)*puVar1)(1);
      iVar2 = param_1[0x11];
    }
    *(undefined *)(iVar2 + 0x24) = param_2;
    return;
  }
  *(undefined *)(param_1[0x11] + 0x24) = param_2;
  return;
}



/* FUNCTION 14403 ; VA 0x008a6500 ; FUN_008a6500 */

void __thiscall FUN_008a6500(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x21) != param_2) {
    *(char *)(param_1 + 0x21) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 14404 ; VA 0x008a6520 ; FUN_008a6520 */

void __thiscall FUN_008a6520(int param_1,undefined4 *param_2)

{
  char cVar1;
  char acStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00558b30(*(undefined4 *)(param_1 + 0x28),param_2);
  if (cVar1 == '\0') {
    if ((uint)param_2[4] < 0x65) {
      FUN_0089b610(param_2);
    }
    else {
      uStack_18 = 0;
      uStack_14 = 0xf;
      if (0xf < (uint)param_2[5]) {
        param_2 = (undefined4 *)*param_2;
      }
      acStack_28[0] = cVar1;
      FUN_005542c0(param_2,100);
      uStack_8 = 0;
      FUN_0089b4e0(acStack_28);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
    FUN_008a4940(&DAT_0211a3a0);
    FUN_0089d5d0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14405 ; VA 0x008a65d0 ; FUN_008a65d0 */

void __thiscall FUN_008a65d0(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x3c) = param_2;
  return;
}



/* FUNCTION 14406 ; VA 0x008a65e0 ; FUN_008a65e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall FUN_008a65e0(int *param_1,int *param_2,char param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined *puVar4;
  int *piVar5;
  undefined4 ****ppppuVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 uVar9;
  byte bVar10;
  byte bVar11;
  undefined4 ****ppppuVar12;
  int *piVar13;
  uint uVar14;
  int *piVar15;
  undefined4 *puVar16;
  int unaff_retaddr;
  int **ppiVar17;
  undefined auStack_1ac [24];
  undefined auStack_194 [24];
  undefined auStack_17c [24];
  undefined auStack_164 [24];
  undefined auStack_14c [24];
  undefined auStack_134 [24];
  undefined auStack_11c [24];
  undefined auStack_104 [12];
  undefined auStack_f8 [12];
  undefined auStack_ec [12];
  undefined4 ***apppuStack_e0 [5];
  uint uStack_cc;
  undefined4 ***apppuStack_c8 [5];
  uint uStack_b4;
  undefined4 ***apppuStack_b0 [5];
  uint uStack_9c;
  undefined auStack_98 [16];
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined auStack_80 [16];
  undefined4 uStack_70;
  undefined4 uStack_6c;
  int *piStack_68;
  int *piStack_64;
  int *piStack_60;
  int *piStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  int *piStack_50;
  undefined auStack_4c [4];
  int *piStack_48;
  undefined **ppuStack_44;
  int iStack_40;
  int iStack_3c;
  undefined **ppuStack_38;
  int iStack_34;
  int iStack_30;
  int *apiStack_2c [2];
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc55b;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined4 *)0x0;
  piVar5 = (int *)param_1[0xd];
  if (param_2 != piVar5) {
    piStack_50 = param_1;
    if ((param_3 == '\0') && (*(char *)((int)param_1 + 0x22) != '\0')) {
      if (param_2 == (int *)0x0) {
        puVar16 = (undefined4 *)&DAT_018de934;
      }
      else {
        puVar16 = (undefined4 *)param_2[10];
        if (0xf < (uint)puVar16[5]) {
          puVar16 = (undefined4 *)*puVar16;
        }
      }
      if (piVar5 == (int *)0x0) {
        puVar4 = &DAT_018de934;
        ExceptionList = &pvStack_10;
      }
      else {
        ExceptionList = &pvStack_10;
        FUN_005c8aa0();
        puVar4 = (undefined *)FUN_005543f0();
      }
      FUN_008a2380(auStack_11c);
      uStack_8 = 0;
      uVar7 = FUN_005543f0(puVar4,puVar16);
      FUN_01675640(auStack_134,
                   "The Parent property of %s is locked, current parent: %s, new parent %s",uVar7);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_005507b0();
      FUN_005500e0(auStack_134);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_ec,&DAT_01c17198);
    }
    if (param_1 == param_2) {
      ExceptionList = &pvStack_10;
      FUN_008a2380(auStack_14c);
      uStack_8 = 3;
      uVar7 = FUN_005543f0();
      FUN_01675640(auStack_164,"Attempt to set %s as its own parent",uVar7);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      FUN_005507b0();
      FUN_005500e0(auStack_164);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_f8,&DAT_01c17198);
    }
    ExceptionList = &pvStack_10;
    if ((param_2 != (int *)0x0) &&
       ((ExceptionList = &pvStack_10, (int *)param_2[0xd] == param_1 ||
        (ExceptionList = &pvStack_10, cVar3 = FUN_008a3680((int *)param_2[0xd]), cVar3 != '\0')))) {
      FUN_008a2380(auStack_194);
      uStack_8 = 6;
      uVar7 = FUN_005543f0();
      FUN_008a2380(auStack_17c);
      uStack_8._0_1_ = 7;
      uVar9 = FUN_005543f0();
      FUN_01675640(auStack_1ac,
                   "Attempt to set parent of %s to %s would result in circular reference",uVar9,
                   uVar7);
      FUN_005507b0();
      uStack_8 = CONCAT31(uStack_8._1_3_,10);
      FUN_005507b0();
      FUN_005500e0(auStack_1ac);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_104,&DAT_01c17198);
    }
    if (DAT_01edf568 != '\0') {
      FUN_01677490(DAT_01edf568,"Instance %p: Setting parent to: %p. Old parent: %p",param_1,param_2
                   ,piVar5);
    }
    if (*(char *)((int)param_1 + 0x23) == '\0') {
      ppiVar17 = apiStack_2c;
      FUN_0060dcd0(ppiVar17,param_1[0xd]);
      uStack_8 = 0x16;
      FUN_0060dcd0(&iStack_1c,param_1);
      uStack_58 = 0;
      uStack_54 = 0;
      uStack_8._0_1_ = 0x18;
      if (param_2 == (int *)0x0) {
        if (DAT_01d62bf0 != '\0') {
          uVar7 = 0x8a68ba;
          iVar8 = FUN_01255560();
          if (*(int *)(iVar8 + 0x10) != 0) {
            FUN_00557fc0(&iStack_1c);
            FUN_0094cda0(ppiVar17,uVar7);
          }
        }
      }
      else {
        uVar7 = FUN_0060dcd0(auStack_4c,param_2);
        FUN_005587e0(uVar7);
        FUN_00550b30();
      }
      *(undefined *)((int)param_1 + 0x23) = 1;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
      piStack_68 = param_1;
      (**(code **)(*param_1 + 0x58))(param_2);
      (**(code **)(*param_1 + 0x5c))(param_2);
      if (param_2 != (int *)0x0) {
        (**(code **)(*param_2 + 100))(param_1);
        (**(code **)(*param_2 + 0x68))(param_2,param_1);
      }
      piVar5 = apiStack_2c[0];
      if (apiStack_2c[0] != (int *)0x0) {
        cVar3 = FUN_0089eb50(param_2);
        if (cVar3 == '\0') {
          FUN_008a7590(&iStack_1c,piVar5,param_2);
        }
        (**(code **)(*piVar5 + 0x8c))(param_1);
        piStack_20 = (int *)FUN_008a86c0();
        puStack_14 = (undefined4 *)*piStack_20;
        piVar5 = (int *)puStack_14[1];
        piVar15 = (int *)*puStack_14;
        uVar14 = (int)piVar5 - (int)piVar15 >> 3;
        piStack_48 = piVar5;
        if (uVar14 == 1) {
          FUN_005596d0(piVar15,piVar5,puStack_14);
          puStack_14[1] = *puStack_14;
          FUN_0058a2b0();
        }
        else if (piVar15 != piVar5) {
          do {
            if (*piVar15 == iStack_1c) break;
            piVar15 = piVar15 + 2;
          } while (piVar15 != piVar5);
          if (piVar15 != piVar5) {
            if (uVar14 < 0x15) {
              if (piVar15 + 2 != piVar5) {
                iStack_24 = (int)piVar15 - (int)(piVar15 + 2);
                piVar13 = piVar15 + 3;
                do {
                  iVar8 = piVar13[-1];
                  iVar2 = *piVar13;
                  piVar13[-1] = 0;
                  *piVar13 = 0;
                  *piVar15 = iVar8;
                  piStack_20 = *(int **)((int)piVar13 + iStack_24);
                  *(int *)((int)piVar13 + iStack_24) = iVar2;
                  if (piStack_20 != (int *)0x0) {
                    LOCK();
                    iVar8 = piStack_20[1] + -1;
                    piStack_20[1] = iVar8;
                    UNLOCK();
                    if (iVar8 == 0) {
                      (**(code **)*piStack_20)();
                      LOCK();
                      iVar8 = piStack_20[2] + -1;
                      piStack_20[2] = iVar8;
                      UNLOCK();
                      if (iVar8 == 0) {
                        (**(code **)(*piStack_20 + 4))();
                      }
                    }
                  }
                  piVar15 = piVar15 + 2;
                  piVar1 = piVar13 + 1;
                  piVar13 = piVar13 + 2;
                  param_1 = piStack_50;
                } while (piVar1 != piVar5);
              }
              piVar5 = *(int **)(puStack_14[1] + -4);
              puVar16 = puStack_14;
              if (piVar5 != (int *)0x0) {
                LOCK();
                iVar8 = piVar5[1] + -1;
                piVar5[1] = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)*piVar5)();
                  LOCK();
                  piVar15 = piVar5 + 2;
                  iVar8 = *piVar15;
                  *piVar15 = *piVar15 + -1;
                  UNLOCK();
                  puVar16 = puStack_14;
                  if (iVar8 == 1) {
                    (**(code **)(*piVar5 + 4))();
                    puVar16 = puStack_14;
                  }
                }
              }
            }
            else {
              FUN_0056ecd0(piVar5 + -2);
              puVar16 = (undefined4 *)*piStack_20;
              piVar5 = *(int **)(puVar16[1] + -4);
              if (piVar5 != (int *)0x0) {
                LOCK();
                iVar8 = piVar5[1] + -1;
                piVar5[1] = iVar8;
                UNLOCK();
                if (iVar8 == 0) {
                  (**(code **)*piVar5)();
                  LOCK();
                  piVar15 = piVar5 + 2;
                  iVar8 = *piVar15;
                  *piVar15 = *piVar15 + -1;
                  UNLOCK();
                  if (iVar8 == 1) {
                    (**(code **)(*piVar5 + 4))();
                  }
                }
              }
            }
            puVar16[1] = puVar16[1] + -8;
          }
        }
        param_1[0xd] = 0;
      }
      piVar5 = apiStack_2c[0];
      if (param_2 != (int *)0x0) {
        FUN_008a86c0();
        FUN_005c93e0(&iStack_1c);
      }
      param_1[0xd] = (int)param_2;
      if (piVar5 == (int *)0x0) {
        bVar11 = 0;
      }
      else {
        bVar11 = -(*(int *)(piVar5[3] + 0x1d0) != 0) &
                 '\x01' << ((byte)*(int *)(piVar5[3] + 0x1d0) & 0x1f) | *(byte *)(piVar5 + 9);
      }
      if ((param_2 != (int *)0x0) &&
         (bVar10 = -(*(int *)(param_2[3] + 0x1d0) != 0) &
                   '\x01' << ((byte)*(int *)(param_2[3] + 0x1d0) & 0x1f) | *(byte *)(param_2 + 9),
         bVar11 != bVar10)) {
        FUN_008a7ba0(bVar10);
      }
      if (piVar5 != (int *)0x0) {
        ppuStack_38 = RBX::Instance::ChildRemovedSignalData::vftable;
        if (iStack_18 != 0) {
          LOCK();
          *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 1;
          UNLOCK();
        }
        iStack_34 = iStack_1c;
        iStack_30 = iStack_18;
        uStack_8._0_1_ = 0x1a;
        FUN_006150c0(1,&ppuStack_38);
        uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
        FUN_0089b1f0();
      }
      if (param_2 != (int *)0x0) {
        ppuStack_44 = RBX::Instance::ChildAddedSignalData::vftable;
        if (iStack_18 != 0) {
          LOCK();
          *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 1;
          UNLOCK();
        }
        iStack_40 = iStack_1c;
        iStack_3c = iStack_18;
        uStack_8._0_1_ = 0x1b;
        FUN_006150c0(0,&ppuStack_44);
        uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
        FUN_0089b1f0();
      }
      if (piVar5 != (int *)0x0) {
        if (piVar5[0x11] != 0) {
          if (iStack_18 != 0) {
            LOCK();
            *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 1;
            UNLOCK();
          }
          FUN_0089be10(iStack_1c,iStack_18);
        }
        (**(code **)(*piVar5 + 0x90))(param_1);
      }
      if (*(int *)(unaff_retaddr + -4) != (int)FUN_008a65e0 - unaff_retaddr) {
        _DAT_01f6ab40 = _DAT_01f6ab40 | 0x8000000;
        _DAT_01f6ab38 = _DAT_01f6ab38 | 0x8000000;
      }
      if (param_2 != (int *)0x0) {
        (**(code **)(*param_2 + 0x88))(param_1);
        cVar3 = FUN_0089eb50(apiStack_2c[0]);
        if (cVar3 == '\0') {
          FUN_008a74a0(param_1,param_2,apiStack_2c[0]);
        }
        if (param_2[0x11] != 0) {
          if (iStack_18 != 0) {
            LOCK();
            *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 1;
            UNLOCK();
          }
          FUN_0089be10(iStack_1c,iStack_18);
        }
        FUN_0089d5d0();
      }
      piStack_60 = apiStack_2c[0];
      piStack_64 = param_1;
      piStack_5c = param_2;
      (**(code **)(*param_1 + 0x7c))(&piStack_64);
      FUN_008a4940(&DAT_0211a3d8);
      *(undefined *)((int)param_1 + 0x23) = 0;
      FUN_00550b30();
      FUN_00550b30();
      FUN_00550b30();
    }
    else {
      piVar5 = (int *)param_1[0xd];
      if (piVar5 != param_2) {
        if (piVar5 == (int *)0x0) {
          uStack_70 = 0;
          uStack_6c = 0xf;
          auStack_80[0] = 0;
          FUN_005542c0(&DAT_018de934,4);
          puVar4 = auStack_80;
          uStack_8 = 0xc;
          uVar14 = 2;
        }
        else {
          puVar4 = (undefined *)FUN_0054ef60(piVar5[10]);
          uStack_8 = 0xb;
          uVar14 = 1;
        }
        puStack_14 = (undefined4 *)uVar14;
        FUN_0054ef60(puVar4);
        uStack_8 = 0xd;
        if ((uVar14 & 2) != 0) {
          uVar14 = uVar14 & 0xfffffffd;
          puStack_14 = (undefined4 *)uVar14;
          FUN_005507b0();
        }
        uStack_8._0_1_ = 0xf;
        if ((uVar14 & 1) != 0) {
          uVar14 = uVar14 & 0xfffffffe;
          puStack_14 = (undefined4 *)uVar14;
          FUN_005507b0();
        }
        if (param_2 == (int *)0x0) {
          uStack_88 = 0;
          uStack_84 = 0xf;
          auStack_98[0] = 0;
          FUN_005542c0(&DAT_018de934,4);
          puVar4 = auStack_98;
          uStack_8 = 0x11;
          uVar14 = uVar14 | 8;
        }
        else {
          puVar4 = (undefined *)FUN_0054ef60(param_2[10]);
          uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
          uVar14 = uVar14 | 4;
        }
        puStack_14 = (undefined4 *)uVar14;
        FUN_0054ef60(puVar4);
        uStack_8 = 0x12;
        if ((uVar14 & 8) != 0) {
          uVar14 = uVar14 & 0xfffffff7;
          FUN_005507b0();
        }
        uStack_8._0_1_ = 0x14;
        if ((uVar14 & 4) != 0) {
          FUN_005507b0();
        }
        piVar5 = (int *)param_1[10];
        ppppuVar6 = apppuStack_e0;
        if (0xf < uStack_cc) {
          ppppuVar6 = (undefined4 ****)apppuStack_e0[0];
        }
        piVar15 = piVar5;
        if (0xf < (uint)piVar5[5]) {
          piVar15 = (int *)*piVar5;
        }
        ppppuVar12 = apppuStack_c8;
        if (0xf < uStack_b4) {
          ppppuVar12 = (undefined4 ****)apppuStack_c8[0];
        }
        if (0xf < (uint)piVar5[5]) {
          piVar5 = (int *)*piVar5;
        }
        FUN_01675640(apppuStack_b0,
                     "Something unexpectedly tried to set the parent of %s to %s while trying to set the parent of %s. Current parent is %s."
                     ,piVar5,ppppuVar12,piVar15,ppppuVar6);
        ppppuVar6 = apppuStack_b0;
        if (0xf < uStack_9c) {
          ppppuVar6 = (undefined4 ****)apppuStack_b0[0];
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
        FUN_0086edd0(2,ppppuVar6,6);
        FUN_005507b0();
        FUN_005507b0();
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return 0;
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 14407 ; VA 0x008a6e60 ; FUN_008a6e60 */

void __thiscall FUN_008a6e60(int param_1,int param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_01255560();
  FUN_008a55f0(uVar1);
  if ((*(uint *)(*(int *)(param_1 + 0xc) + 0x1d4) >> 3 & 1) != 0) {
    if ((*(int *)(param_1 + 0x34) != param_2) && (param_2 != 0)) {
      FUN_008a55f0(uVar1);
    }
    FUN_008a65e0(param_2,0);
    return;
  }
  FUN_005817e0();
  uVar1 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Cannot change Parent of type %s",uVar1);
}



/* FUNCTION 14408 ; VA 0x008a6ed0 ; FUN_008a6ed0 */

void __thiscall FUN_008a6ed0(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  
  piVar2 = param_3;
  if ((param_3 != (int *)0x0) &&
     (iVar1 = param_3[3], iVar3 = FUN_00897b90(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    piVar6 = (int *)param_1[1];
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    if (param_2 == (int *)0x0) {
      param_2 = (int *)&DAT_018e3e8c;
    }
    else {
      (**(code **)(*param_2 + 0x10))();
      param_2 = (int *)FUN_005543f0();
    }
    (**(code **)(*piVar2 + 0x10))();
    uVar4 = FUN_005543f0();
    (**(code **)(*param_1 + 0x4c))();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Expected %s got %s for %s:%s.",uVar5,uVar4,param_2,piVar6);
  }
  param_3 = piVar2;
  (**(code **)(*(int *)param_1[0xe] + 0x10))(param_2,&param_3);
  return;
}



/* FUNCTION 14409 ; VA 0x008a6f80 ; FUN_008a6f80 */

void __thiscall FUN_008a6f80(int *param_1,int param_2,int param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = param_1[0x11];
  if (iVar2 == 0) {
    iVar2 = (**(code **)(*param_1 + 0x14))();
    puVar1 = (undefined4 *)param_1[0x11];
    param_1[0x11] = iVar2;
    if (puVar1 != (undefined4 *)0x0) {
      (**(code **)*puVar1)(1);
      iVar2 = param_1[0x11];
    }
  }
  if ((*(int *)(iVar2 + 0x68) != param_2) || (*(int *)(iVar2 + 0x6c) != param_3)) {
    *(int *)(iVar2 + 0x6c) = param_3;
    *(int *)(iVar2 + 0x68) = param_2;
    FUN_008a4940(&DAT_0211a318);
  }
  return;
}



/* FUNCTION 14410 ; VA 0x008a6fd0 ; FUN_008a6fd0 */

void __thiscall FUN_008a6fd0(int *param_1,int param_2)

{
  undefined4 *puVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  int in_stack_00000014;
  uint in_stack_00000018;
  int *piVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc580;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piVar5 = param_1;
  if ((in_stack_00000014 != 0) || (ExceptionList = &pvStack_10, param_1[0x11] != 0)) {
    iVar3 = param_1[0x11];
    ExceptionList = &pvStack_10;
    if (iVar3 == 0) {
      ExceptionList = &pvStack_10;
      iVar3 = (**(code **)(*param_1 + 0x14))();
      puVar1 = (undefined4 *)param_1[0x11];
      param_1[0x11] = iVar3;
      if (puVar1 != (undefined4 *)0x0) {
        (**(code **)*puVar1)(1);
        iVar3 = param_1[0x11];
      }
    }
    piVar6 = *(int **)(iVar3 + 0x58);
    cVar2 = FUN_00558b30(&param_2,piVar6);
    if (cVar2 == '\0') {
      LOCK();
      piVar6[6] = piVar6[6] + 1;
      UNLOCK();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_0089b610(&param_2);
      iVar3 = FUN_008991d0(param_1);
      if (iVar3 != 0) {
        FUN_00d14020(param_1,piVar6,&param_2);
      }
      FUN_008a4940(&DAT_0211a484);
      FUN_0089ae70();
      piVar5 = piVar6;
    }
  }
  if (0xf < in_stack_00000018) {
    uVar4 = in_stack_00000018 + 1;
    iVar3 = param_2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(param_2 + -4);
      uVar4 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3(piVar5);
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14411 ; VA 0x008a70d0 ; FUN_008a70d0 */

void __thiscall FUN_008a70d0(int *param_1,int param_2)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1[0x11] == 0) {
    ExceptionList = &pvStack_10;
    iVar2 = (**(code **)(*param_1 + 0x14))();
    puVar1 = (undefined4 *)param_1[0x11];
    param_1[0x11] = iVar2;
    if (puVar1 != (undefined4 *)0x0) {
      (**(code **)*puVar1)(1);
    }
  }
  FUN_0089b4e0(&param_2);
  FUN_008a4940(&DAT_0211a484);
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14412 ; VA 0x008a7170 ; FUN_008a7170 */

void __thiscall FUN_008a7170(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(param_1 + 0x10))(param_3);
  return;
}



/* FUNCTION 14413 ; VA 0x008a7190 ; FUN_008a7190 */

void __thiscall FUN_008a7190(int param_1,undefined4 param_2,undefined4 param_3)

{
  code *pcVar1;
  undefined auStack_24 [24];
  
  pcVar1 = *(code **)(param_1 + 0x10);
  param_2 = auStack_24;
  FUN_0054ef60(param_3);
  (*pcVar1)();
  return;
}



/* FUNCTION 14414 ; VA 0x008a71c0 ; FUN_008a71c0 */

void __thiscall FUN_008a71c0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  (**(code **)(param_1 + 0x10))(*param_3,param_3[1]);
  return;
}



/* FUNCTION 14415 ; VA 0x008a71e0 ; FUN_008a71e0 */

int * __thiscall FUN_008a71e0(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc598;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0087ccc0();
  puVar3 = (undefined4 *)FUN_01674e20(8);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
    piVar4 = (int *)0x0;
  }
  else {
    *puVar3 = 0;
    puVar3[1] = 0;
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    *puVar3 = param_2;
    puVar3[1] = param_3;
    piVar4 = param_3;
  }
  *(undefined4 **)(param_1 + 8) = puVar3;
  *(undefined4 *)(param_1 + 4) = 8;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    piVar4 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piVar4 = (int *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piVar4 = (int *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 14416 ; VA 0x008a7290 ; FUN_008a7290 */

int __thiscall FUN_008a7290(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bba58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00899370(&uStack_18);
  uStack_8 = 0;
  iVar3 = (**(code **)(*param_1 + 0x48))(param_2,uStack_18);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 14417 ; VA 0x008a7310 ; FUN_008a7310 */

void __thiscall FUN_008a7310(int param_1,undefined4 param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba918;
  pvStack_10 = ExceptionList;
  pcVar1 = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008994a0(aiStack_28);
  uStack_8 = 0;
  (*pcVar1)(param_2,uVar2);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    iVar3 = aiStack_28[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_28[0] + -4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14418 ; VA 0x008a73a0 ; FUN_008a73a0 */

void __thiscall FUN_008a73a0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined auStack_e4 [200];
  int iStack_1c;
  int iStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc5bb;
  pvStack_10 = ExceptionList;
  iVar1 = *param_3;
  pcStack_14 = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088da50();
  if (iVar1 == iVar2) {
    iVar1 = *param_3;
    iVar2 = FUN_0088da50();
    if (iVar1 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar3 = (int *)0x0;
    }
    iStack_1c = *piVar3;
    iStack_18 = piVar3[1];
  }
  else {
    puVar4 = (undefined4 *)param_3[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_3 + 2,auStack_e4);
      puVar4 = (undefined4 *)param_3[1];
    }
    uStack_8 = 0;
    piVar3 = (int *)FUN_0088baa0();
    iStack_1c = *piVar3;
    iStack_18 = piVar3[1];
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_e4);
    }
    uStack_8 = 0xffffffff;
  }
  (*pcStack_14)(param_2,&iStack_1c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14419 ; VA 0x008a74a0 ; FUN_008a74a0 */

int * FUN_008a74a0(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  void **ppvVar3;
  char cVar4;
  int *piVar5;
  int *piVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0698;
  pvStack_10 = ExceptionList;
  piVar6 = param_2;
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (param_2 != (int *)0x0) {
    do {
      ppvVar3 = (void **)ExceptionList;
      if ((piVar6 == param_3) ||
         ((param_3 != (int *)0x0 &&
          (((int *)param_3[0xd] == piVar6 ||
           (cVar4 = FUN_008a3680((int *)param_3[0xd]), ppvVar3 = (void **)ExceptionList,
           cVar4 != '\0')))))) break;
      (**(code **)(*piVar6 + 0x80))(param_1);
      piVar5 = piVar6 + 0xd;
      piVar6 = (int *)*piVar5;
      ppvVar3 = (void **)ExceptionList;
    } while ((int *)*piVar5 != (int *)0x0);
  }
  ExceptionList = ppvVar3;
  piVar6 = *(int **)(param_1 + 0x30);
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar6[1] = piVar6[1] + 1;
    UNLOCK();
    piVar6 = *(int **)(param_1 + 0x30);
  }
  piVar2 = *(int **)(param_1 + 0x2c);
  uStack_8 = 0;
  piVar5 = piVar2;
  if ((piVar2 != (int *)0x0) && (puVar7 = (undefined4 *)*piVar2, puVar7 != (undefined4 *)piVar2[1]))
  {
    do {
      piVar5 = (int *)FUN_008a74a0(*puVar7,param_2,param_3);
      puVar7 = puVar7 + 2;
    } while (puVar7 != (undefined4 *)piVar2[1]);
  }
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar2 = piVar6 + 1;
    iVar1 = *piVar2;
    piVar5 = (int *)*piVar2;
    *piVar2 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      piVar5 = (int *)(**(code **)*piVar6)();
      LOCK();
      piVar2 = piVar6 + 2;
      iVar1 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        piVar5 = (int *)(**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 14420 ; VA 0x008a7590 ; FUN_008a7590 */

int * FUN_008a7590(int *param_1,int *param_2,int *param_3)

{
  int *piVar1;
  void **ppvVar2;
  char cVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0698;
  pvStack_10 = ExceptionList;
  piVar5 = param_2;
  ExceptionList = &pvStack_10;
  ppvVar2 = &pvStack_10;
  if (param_2 != (int *)0x0) {
    do {
      ppvVar2 = (void **)ExceptionList;
      if ((piVar5 == param_3) ||
         ((param_3 != (int *)0x0 &&
          (((int *)param_3[0xd] == piVar5 ||
           (cVar3 = FUN_008a3680((int *)param_3[0xd]), ppvVar2 = (void **)ExceptionList,
           cVar3 != '\0')))))) break;
      (**(code **)(*piVar5 + 0x84))(param_1);
      piVar5 = (int *)piVar5[0xd];
      ppvVar2 = (void **)ExceptionList;
    } while (piVar5 != (int *)0x0);
  }
  ExceptionList = ppvVar2;
  iVar6 = *param_1;
  piVar5 = *(int **)(iVar6 + 0x30);
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = *(int **)(iVar6 + 0x30);
  }
  piVar1 = *(int **)(iVar6 + 0x2c);
  uStack_8 = 0;
  piVar4 = piVar1;
  if ((piVar1 != (int *)0x0) && (iVar6 = *piVar1, iVar6 != piVar1[1])) {
    do {
      piVar4 = (int *)FUN_008a7590(iVar6,param_2,param_3);
      iVar6 = iVar6 + 8;
    } while (iVar6 != piVar1[1]);
  }
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar1 = piVar5 + 1;
    iVar6 = *piVar1;
    piVar4 = (int *)*piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      piVar4 = (int *)(**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        piVar4 = (int *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 14421 ; VA 0x008a7680 ; FUN_008a7680 */

undefined * FUN_008a7680(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc5dc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf84c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf84c);
    if (DAT_01edf84c == -1) {
      uStack_8 = 0;
      FUN_008e7070();
      FUN_016f3654(&LAB_018812b0);
      FUN_016f37bf(&DAT_01edf84c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01edf7e8;
}



/* FUNCTION 14422 ; VA 0x008a7710 ; FUN_008a7710 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_008a7710(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf8cc) {
    FUN_016f3809(&DAT_01edf8cc);
    if (DAT_01edf8cc == -1) {
      _DAT_01edf8c0 = FUN_005c65e0;
      _DAT_01edf8c4 = FUN_005c65e0;
      _DAT_01edf8c8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01edf8cc);
    }
  }
  return &DAT_01edf8c0;
}



/* FUNCTION 14423 ; VA 0x008a7780 ; FUN_008a7780 */

int __fastcall FUN_008a7780(int param_1)

{
  int iVar1;
  
  iVar1 = FUN_01256300(*(undefined4 *)(param_1 + 0xd8));
  return iVar1 - *(int *)(param_1 + 0xd4);
}



/* FUNCTION 14424 ; VA 0x008a77a0 ; FUN_008a77a0 */

int FUN_008a77a0(int *param_1,undefined4 param_2,undefined4 param_3)

{
  code *pcVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  uint auStack_38 [2];
  code *pcStack_30;
  int *piStack_2c;
  code *pcStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc5f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00f27310();
  pcStack_18 = FUN_008a3790;
  piStack_14 = param_1;
  pcVar1 = *(code **)(*param_1 + 0x54);
  cVar2 = FUN_00585a40(&pcStack_18);
  if (cVar2 == '\0') {
    pcStack_30 = pcStack_18;
    piStack_2c = piStack_14;
    auStack_38[0] = 0x191e891;
  }
  else {
    auStack_38[0] = 0;
  }
  uStack_8 = 0;
  iVar4 = (*pcVar1)(auStack_38,param_2,param_3);
  uStack_8 = 1;
  if (((auStack_38[0] != 0) && ((auStack_38[0] & 1) == 0)) &&
     (*(code **)(auStack_38[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_38[0] & 0xfffffffe))(&pcStack_30,&pcStack_30,2);
  }
  if (iVar4 != 0) {
    if (*(int **)(iVar3 + 8) == (int *)0x0) {
      *(int *)(iVar3 + 4) = iVar4;
    }
    else {
      **(int **)(iVar3 + 8) = iVar4;
    }
    *(int *)(iVar3 + 8) = iVar4;
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 14425 ; VA 0x008a7870 ; FUN_008a7870 */

void __thiscall FUN_008a7870(int param_1,undefined4 *param_2)

{
  int ****ppppiVar1;
  int iVar2;
  int iVar3;
  float fVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  undefined4 uVar10;
  uint uVar11;
  undefined4 *puVar12;
  int ***pppiVar13;
  int *****pppppiVar14;
  int *****pppppiVar15;
  undefined4 uStack_50;
  undefined4 uStack_48;
  int iStack_44;
  int ****ppppiStack_34;
  int ***pppiStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc628;
  pvStack_10 = ExceptionList;
  piVar5 = (int *)(param_1 + -8);
  if (param_1 == 0) {
    piVar5 = (int *)&DAT_00000004;
  }
  pppppiVar15 = (int *****)(-(uint)(*piVar5 != 0) & *piVar5 + 0x20U);
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  FUN_005ef390((int)&param_2 + 3,&ppppiStack_34,param_2);
  uStack_8 = 0;
  uVar6 = param_1 - 0xc;
  if (param_1 == 0) {
    uVar6 = 0xfffffff4;
  }
  uVar6 = -(uint)(param_1 != 0) & uVar6;
  uStack_2c = *(uint *)(uVar6 + 0x28);
  if (uStack_2c != 0) {
    uVar11 = uStack_2c * 4;
    if (uStack_2c < 0x40000000) {
      if (0xfff < uVar11) goto LAB_008a7908;
      if (uVar11 == 0) {
        uVar11 = 0;
      }
      else {
        uVar11 = FUN_01674e20(uVar11);
      }
    }
    else {
      uVar11 = 0xffffffff;
LAB_008a7908:
      uVar7 = uVar11 + 0x23;
      if (uVar7 <= uVar11) {
        uVar7 = 0xffffffff;
      }
      iVar8 = FUN_01674e20(uVar7);
      if (iVar8 == 0) goto LAB_008a7b88;
      uVar11 = iVar8 + 0x23U & 0xffffffe0;
      *(int *)(uVar11 - 4) = iVar8;
    }
    uStack_28 = *(uint *)(uVar6 + 0x28);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    uStack_18 = uVar11;
    if (uStack_28 == 0) {
      puVar12 = (undefined4 *)0x0;
      iStack_14 = 0;
    }
    else {
      uVar7 = uStack_28 * 4;
      if (uStack_28 < 0x40000000) {
        if (uVar7 < 0x1000) {
          if (uVar7 == 0) {
            iStack_14 = *(int *)(uVar6 + 0x28);
            puVar12 = (undefined4 *)0x0;
          }
          else {
            puVar12 = (undefined4 *)FUN_01674e20(uVar7);
            iStack_14 = *(int *)(uVar6 + 0x28);
          }
          goto LAB_008a79b8;
        }
      }
      else {
        uVar7 = 0xffffffff;
      }
      uVar9 = uVar7 + 0x23;
      if (uVar9 <= uVar7) {
        uVar9 = 0xffffffff;
      }
      iVar8 = FUN_01674e20(uVar9);
      if (iVar8 == 0) goto LAB_008a7b88;
      puVar12 = (undefined4 *)(iVar8 + 0x23U & 0xffffffe0);
      puVar12[-1] = iVar8;
      iStack_14 = *(int *)(uVar6 + 0x28);
    }
LAB_008a79b8:
    param_2 = puVar12;
    if (iStack_14 != 0) {
      iStack_20 = uVar11 - (int)puVar12;
      do {
        pppppiVar14 = (int *****)*pppppiVar15;
        uStack_24 = FUN_00563b90(-(uint)(pppppiVar14 != (int *****)0x0) & (uint)(pppppiVar14 + -8));
        *(undefined4 *)(iStack_20 + (int)puVar12) = uStack_24;
        *puVar12 = pppppiVar14;
        ppppiVar1 = *pppppiVar15;
        pppiVar13 = *ppppiVar1;
        if ((int ****)pppiVar13[1] != ppppiVar1) {
          *pppiVar13[1] = (int *)0x0;
          pppiVar13 = *ppppiVar1;
        }
        pppiVar13[1] = (int **)ppppiVar1[1];
        *pppppiVar15 = (int ****)*ppppiVar1;
        iVar8 = FUN_008a4250(uStack_24,uStack_50);
        pppiVar13 = (int ***)(iStack_44 + iVar8 * 4);
        if (*pppiVar13 == (int **)0x0) {
          *pppppiVar14 = ppppiStack_34;
          pppppiVar14[1] = (int ****)ppppiStack_34[1];
          (*pppppiVar14)[1] = pppiVar13;
          *pppiVar13 = (int **)pppppiVar14;
          ppppiStack_34 = (int ****)pppppiVar14;
        }
        else {
          *pppppiVar14 = (int ****)**pppiVar13;
          pppppiVar14[1] = (int ****)*pppiVar13;
          *pppiVar13 = (int **)pppppiVar14;
          *pppppiVar14[1] = (int ***)pppppiVar14;
        }
        puVar12 = puVar12 + 1;
        iStack_14 = iStack_14 + -1;
      } while (iStack_14 != 0);
      iStack_14 = 0;
      uVar11 = uStack_18;
    }
    if (uStack_28 != 0) {
      uVar6 = uStack_28 * 4;
      puVar12 = param_2;
      if (0xfff < uVar6) {
        puVar12 = (undefined4 *)param_2[-1];
        uVar6 = uVar6 + 0x23;
        if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar12))) goto LAB_008a7b88;
      }
      FUN_01674ea0(puVar12,uVar6);
    }
    param_1 = iStack_1c;
    if (uStack_2c != 0) {
      uVar7 = uStack_2c * 4;
      uVar6 = uVar11;
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(uVar11 - 4);
        uVar7 = uVar7 + 0x23;
        if (0x1f < (uVar11 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
      param_1 = iStack_1c;
    }
  }
  fVar4 = DAT_018c0d80;
  pppppiVar14 = pppppiVar15;
  if ((int *****)ppppiStack_34 != &ppppiStack_34) {
    pppppiVar14 = (int *****)ppppiStack_34;
  }
  *pppppiVar15 = (int ****)pppppiVar14;
  pppppiVar15[1] = (int ****)pppiStack_30;
  **pppiStack_30 = (int *)pppppiVar15;
  *(*pppppiVar15)[1] = (int **)pppppiVar15;
  *(undefined4 *)(param_1 + 4) = uStack_50;
  iVar8 = *(int *)(param_1 + 0xc);
  *(undefined4 *)(param_1 + 0xc) = uStack_48;
  iVar2 = *(int *)(param_1 + 0x10);
  *(int *)(param_1 + 0x10) = iStack_44;
  iVar3 = *(int *)(&DAT_018be080 + *(int *)(param_1 + 4) * 4);
  *(undefined4 *)(param_1 + 0x18) = 0xffffffff;
  if ((float)((double)iVar3 + (double)(&DAT_018c0d90)[-(iVar3 >> 0x1f)]) *
      *(float *)(param_1 + 0x14) < fVar4) {
    uVar10 = FUN_016f3cd0();
    *(undefined4 *)(param_1 + 0x18) = uVar10;
  }
  if (iVar8 != 0) {
    uVar6 = iVar8 * 4;
    iVar8 = iVar2;
    if (0xfff < uVar6) {
      iVar8 = *(int *)(iVar2 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar2 - iVar8) - 4U) {
LAB_008a7b88:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14426 ; VA 0x008a7ba0 ; FUN_008a7ba0 */

void __thiscall FUN_008a7ba0(int param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  piVar1 = *(int **)(param_1 + 0x2c);
  *(byte *)(param_1 + 0x24) = param_2;
  if (piVar1 != (int *)0x0) {
    iVar2 = piVar1[1];
    iVar3 = *(int *)(*(int *)(param_1 + 0xc) + 0x1d0);
    for (iVar4 = *piVar1; iVar4 != iVar2; iVar4 = iVar4 + 8) {
      FUN_008a7ba0(param_2 | -(iVar3 != 0) & '\x01' << ((byte)iVar3 & 0x1f));
    }
  }
  return;
}



/* FUNCTION 14427 ; VA 0x008a7bf0 ; FUN_008a7bf0 */

undefined4 FUN_008a7bf0(char *param_1,undefined4 *param_2)

{
  char *pcVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined auStack_1c [24];
  
  uVar2 = *(uint *)(param_1 + 0x10);
  if (uVar2 == 0) {
    if (param_2 != (undefined4 *)0x0) {
      FUN_005542c0("Attribute name cannot be empty",0x1e);
    }
    return 1;
  }
  if (100 < uVar2) {
    if (param_2 != (undefined4 *)0x0) {
      uVar5 = FUN_01675640(auStack_1c,"Attribute name exceeds %d character limit",100);
      FUN_005511f0(uVar5);
      FUN_005507b0();
    }
    return 2;
  }
  if (0xf < *(uint *)(param_1 + 0x14)) {
    param_1 = *(char **)param_1;
  }
  pcVar1 = param_1 + uVar2;
  while( true ) {
    if (param_1 == pcVar1) {
      return 0;
    }
    iVar6 = FUN_0171dac9((int)*param_1);
    if ((iVar6 == 0) && (*param_1 != '_')) break;
    param_1 = param_1 + 1;
  }
  if (param_2 != (undefined4 *)0x0) {
    puVar7 = (undefined4 *)
             FUN_01675640(auStack_1c,"Attribute name contains illegal character \'%c\'",
                          (int)*param_1);
    if (param_2 != puVar7) {
      FUN_005507b0();
      uVar5 = puVar7[1];
      uVar3 = puVar7[2];
      uVar4 = puVar7[3];
      *param_2 = *puVar7;
      param_2[1] = uVar5;
      param_2[2] = uVar3;
      param_2[3] = uVar4;
      *(undefined8 *)(param_2 + 4) = *(undefined8 *)(puVar7 + 4);
      puVar7[4] = 0;
      puVar7[5] = 0xf;
      *(undefined *)puVar7 = 0;
    }
    FUN_005507b0();
  }
  return 3;
}



/* FUNCTION 14428 ; VA 0x008a7cf0 ; FUN_008a7cf0 */

void __thiscall FUN_008a7cf0(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  
  piVar1 = *(int **)(param_1 + 0x34);
  if (((piVar1 != (int *)0x0) && (piVar2 = *(int **)(param_3 + 0x34), piVar1 != piVar2)) &&
     ((piVar2 == (int *)0x0 ||
      (((int *)piVar2[0xd] != piVar1 && (cVar3 = FUN_008a3680((int *)piVar2[0xd]), cVar3 == '\0'))))
     )) {
    (**(code **)(*piVar1 + 0x68))(piVar1,param_3);
  }
  return;
}



/* FUNCTION 14429 ; VA 0x008a7d30 ; FUN_008a7d30 */

undefined4 * __thiscall FUN_008a7d30(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int *piVar5;
  int *piVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017bc650;
  puVar4 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar4 != (undefined4 *)0x0) {
    piVar5 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar5 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
      piVar5 = *(int **)(param_1 + 0x30);
      puVar4 = *(undefined4 **)(param_1 + 0x2c);
    }
    puVar7 = (undefined4 *)*puVar4;
    puVar3 = (undefined4 *)puVar4[1];
    iStack_8 = 0;
    puVar4 = puVar3;
    for (; puVar7 != puVar3; puVar7 = puVar7 + 2) {
      piVar6 = (int *)puVar7[1];
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
        piVar6 = (int *)puVar7[1];
      }
      iStack_8._1_3_ = (uint3)((uint)iStack_8 >> 8);
      iStack_8._0_1_ = 1;
      puVar4 = (undefined4 *)(**(code **)(*(int *)*puVar7 + 0x5c))(param_2);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar1 = piVar6 + 1;
        iVar2 = *piVar1;
        puVar4 = (undefined4 *)*piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          piVar1 = piVar6 + 2;
          iVar2 = *piVar1;
          puVar4 = (undefined4 *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            puVar4 = (undefined4 *)(**(code **)(*piVar6 + 4))();
          }
        }
      }
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar6 = piVar5 + 1;
      iVar2 = *piVar6;
      puVar4 = (undefined4 *)*piVar6;
      *piVar6 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        puVar4 = (undefined4 *)(**(code **)*piVar5)();
        LOCK();
        piVar6 = piVar5 + 2;
        iVar2 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          puVar4 = (undefined4 *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 14430 ; VA 0x008a7e20 ; FUN_008a7e20 */

undefined4 __thiscall FUN_008a7e20(int *param_1,uint param_2)

{
  undefined4 ****ppppuVar1;
  int *piVar2;
  int *piVar3;
  undefined *puVar4;
  uint *puVar5;
  uint uVar6;
  char cVar7;
  short sVar8;
  undefined4 ****ppppuVar9;
  int iVar10;
  undefined4 uVar11;
  undefined *puVar12;
  int iVar13;
  undefined4 *puVar14;
  int iStack_3dc;
  undefined *puStack_3d8;
  undefined4 uStack_3d4;
  undefined *puStack_3d0;
  undefined *puStack_3cc;
  undefined4 uStack_3c8;
  undefined4 ***pppuStack_3c4;
  undefined *puStack_3c0;
  undefined8 uStack_3bc;
  undefined4 uStack_3ac;
  int iStack_3a8;
  undefined auStack_3a4 [64];
  undefined auStack_364 [4];
  int *piStack_360;
  undefined **ppuStack_2dc;
  undefined4 uStack_2d8;
  int iStack_2d4;
  undefined auStack_2d0 [200];
  undefined4 uStack_208;
  uint uStack_204;
  undefined auStack_200 [52];
  undefined auStack_1cc [24];
  undefined auStack_1b4 [24];
  undefined auStack_19c [28];
  undefined auStack_180 [24];
  uint uStack_168;
  int *piStack_164;
  undefined auStack_160 [52];
  uint uStack_12c;
  uint uStack_128;
  uint uStack_124;
  undefined auStack_120 [52];
  uint uStack_ec;
  uint uStack_e8;
  uint uStack_e4;
  uint auStack_e0 [6];
  undefined auStack_c8 [28];
  uint uStack_ac;
  uint uStack_a8;
  uint uStack_a4;
  undefined4 ***apppuStack_a0 [4];
  undefined4 uStack_90;
  uint uStack_8c;
  uint uStack_88;
  uint uStack_84;
  uint uStack_80;
  uint uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined **ppuStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  double dStack_48;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  int iStack_28;
  undefined *puStack_24;
  undefined4 uStack_20;
  uint *puStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc745;
  pvStack_10 = ExceptionList;
  ppuStack_2dc = RBX::Reflection::FunctionDescriptor::Arguments::vftable;
  uStack_3bc = (double)CONCAT44(0x8a7e54,(undefined4)uStack_3bc);
  ExceptionList = &pvStack_10;
  piStack_18 = param_1;
  uStack_2d8 = FUN_00888530();
  iStack_2d4 = 0;
  ppuStack_2dc = RBX::Lua::LuaArguments::vftable;
  uStack_208 = 1;
  uStack_204 = param_2;
  uStack_90 = 0;
  uStack_8c = 0xf;
  apppuStack_a0[0] = (undefined4 ***)((uint)apppuStack_a0[0] & 0xffffff00);
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uStack_3bc = (double)CONCAT44(apppuStack_a0,1);
  puStack_3c0 = (undefined *)0x8a7ebb;
  cVar7 = FUN_009d2a90();
  if (cVar7 == '\0') {
    uStack_3bc = (double)CONCAT44(0x8a7ec8,(undefined4)uStack_3bc);
    uStack_3ac = FUN_00888530();
    iStack_3a8 = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_3bc = (double)CONCAT44(&uStack_3ac,1);
    puStack_3c0 = (undefined *)0x8a7ef0;
    cVar7 = FUN_009d54a0();
    if (cVar7 == '\0') {
      uStack_3bc = (double)CONCAT44("Argument 1 missing or nil",&uStack_34);
      puStack_3c0 = (undefined *)0x8a86ae;
      FUN_016756b0();
      uStack_3bc = (double)CONCAT44(&DAT_01c17198,&uStack_34);
                    /* WARNING: Subroutine does not return */
      puStack_3c0 = &UNK_008a86bf;
      FUN_0170c2a8();
    }
    uStack_3bc = (double)CONCAT44(0x8a7f03,(undefined4)uStack_3bc);
    ppppuVar9 = (undefined4 ****)FUN_008898b0();
    if (apppuStack_a0 != ppppuVar9) {
      ppppuVar1 = ppppuVar9 + 4;
      if ((undefined4 ***)0xf < ppppuVar9[5]) {
        ppppuVar9 = (undefined4 ****)*ppppuVar9;
      }
      uStack_3bc = (double)CONCAT44(*ppppuVar1,ppppuVar9);
      puStack_3c0 = (undefined *)0x8a7f25;
      FUN_005542c0();
    }
    uStack_8._0_1_ = 3;
    if (iStack_3a8 != 0) {
      uStack_3bc = (double)CONCAT44(auStack_3a4,0x8a7f3f);
      (**(code **)(iStack_3a8 + 8))();
    }
    uStack_8._0_1_ = 1;
  }
  uStack_3bc = (double)CONCAT44(&dStack_48,2);
  dStack_48 = 0.0;
  puStack_3c0 = (undefined *)0x8a7f5f;
  cStack_11 = FUN_009d1d10();
  if (cStack_11 == '\0') {
LAB_008a7f93:
    uStack_3bc = (double)CONCAT44(apppuStack_a0,0x8a7fa1);
    iVar10 = FUN_008a1240();
    if (iVar10 == 0) {
      uStack_3bc = (double)CONCAT44(param_2,0x8a8031);
      puStack_24 = (undefined *)FUN_0094fc20();
      iStack_28 = param_1[0x11];
      if (iStack_28 == 0) {
        uStack_3bc = (double)CONCAT44(0x8a804a,(undefined4)uStack_3bc);
        iStack_28 = (**(code **)(*param_1 + 0x14))();
        puVar14 = (undefined4 *)param_1[0x11];
        param_1[0x11] = iStack_28;
        if (puVar14 != (undefined4 *)0x0) {
          uStack_3bc = 2.12648034034735e-314;
          (**(code **)*puVar14)();
          iStack_28 = param_1[0x11];
        }
      }
      uStack_78 = 0;
      uStack_74 = 0xf;
      uStack_88 = uStack_88 & 0xffffff00;
      uStack_6c = 0;
      LOCK();
      DAT_01e90cd8 = DAT_01e90cd8 + 1;
      UNLOCK();
      ppuStack_70 = RBX::Lua::WeakThreadRef::vftable;
      uStack_64 = 0;
      uStack_60 = 0;
      uStack_5c = 0;
      uStack_58 = 0;
      uStack_54 = 0;
      uStack_50 = 0;
      uStack_4c = 0;
      ppppuVar9 = apppuStack_a0;
      if (0xf < uStack_8c) {
        ppppuVar9 = (undefined4 ****)apppuStack_a0[0];
      }
      uStack_3bc = (double)CONCAT44(uStack_90,ppppuVar9);
      uStack_8._0_1_ = 6;
      puStack_3c0 = (undefined *)0x8a80d3;
      FUN_005542c0();
      uStack_3bc = (double)CONCAT44(param_2,0x8a80e1);
      uVar11 = FUN_00d887b0();
      uStack_8._0_1_ = 7;
      uStack_3bc = (double)CONCAT44(uVar11,0x8a80ee);
      FUN_00d88cd0();
      uStack_8._0_1_ = 6;
      uStack_3bc = (double)CONCAT44(0x8a80fd,(undefined4)uStack_3bc);
      FUN_00d88aa0();
      puStack_1c = auStack_e0;
      uStack_3bc = (double)CONCAT44(&uStack_88,0x8a8118);
      FUN_0054ef60();
      uStack_8._0_1_ = 8;
      uStack_3bc = (double)CONCAT44(&ppuStack_70,0x8a812b);
      FUN_00d88710();
      if (uStack_50 != 0) {
        LOCK();
        *(int *)(uStack_50 + 8) = *(int *)(uStack_50 + 8) + 1;
        UNLOCK();
      }
      uStack_ac = uStack_54;
      uStack_a8 = uStack_50;
      uStack_a4 = uStack_4c;
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      uStack_30 = dStack_48;
      uStack_3bc = (double)CONCAT44(&uStack_30,0x8a817c);
      sVar8 = FUN_017265ed();
      if ((sVar8 < 1) && (puStack_24 != (undefined *)0x0)) {
        puVar4 = *(undefined **)(puStack_24 + 0x34);
        puVar12 = puStack_24;
        if ((puVar4 != (undefined *)0x0) && (puVar12 = puVar4, *(int *)(puVar4 + 0x34) != 0)) {
          uStack_3bc = (double)CONCAT44(0x8a81a6,(undefined4)uStack_3bc);
          puVar12 = (undefined *)FUN_005c8ac0();
        }
        if (puVar12 != (undefined *)0x0) {
          iVar10 = *(int *)(puVar12 + 0xc);
          uStack_3bc = (double)CONCAT44(0x8a81b8,(undefined4)uStack_3bc);
          iVar13 = FUN_008a8c30();
          if ((uint)*(ushort *)(iVar10 + 0x1d8) - (uint)*(ushort *)(iVar13 + 0x1d8) <=
              (uint)*(ushort *)(iVar13 + 0x1da)) {
            uStack_3bc = (double)CONCAT44(0x8a81de,(undefined4)uStack_3bc);
            iVar10 = FUN_005cf2a0();
            if (iVar10 != 0) {
              uStack_3bc = (double)CONCAT44(iVar10,&uStack_30);
              puStack_3c0 = (undefined *)0x8a81f2;
              puVar14 = (undefined4 *)FUN_0060dcd0();
              puStack_1c = (uint *)puVar14[1];
              if (puStack_1c != (uint *)0x0) {
                LOCK();
                puStack_1c[2] = puStack_1c[2] + 1;
                UNLOCK();
                puStack_1c = (uint *)puVar14[1];
              }
              uStack_20 = *puVar14;
              uStack_3bc = (double)CONCAT44(&uStack_20,0x8a8217);
              FUN_0072a430();
              if (puStack_1c != (uint *)0x0) {
                LOCK();
                uVar6 = puStack_1c[2] - 1;
                puStack_1c[2] = uVar6;
                UNLOCK();
                if (uVar6 == 0) {
                  uStack_3bc = (double)CONCAT44(0x8a822f,(undefined4)uStack_3bc);
                  (**(code **)(*puStack_1c + 4))();
                }
              }
              uStack_3bc = (double)CONCAT44(0x8a8237,(undefined4)uStack_3bc);
              FUN_00550b30();
              if (cStack_11 == '\0') {
                uStack_3bc = (double)CONCAT44(auStack_180,0x8a8443);
                FUN_008a2380();
                uStack_3bc = 5.94288947136219e-313;
                puStack_3c0 = (undefined *)0x0;
                uStack_8._0_1_ = 0x11;
                pppuStack_3c4 = (undefined4 ***)0x8a8457;
                puVar14 = (undefined4 *)FUN_00585d40();
                uStack_40 = *puVar14;
                uStack_3c = puVar14[1];
                uStack_38 = puVar14[2];
                uStack_34 = puVar14[3];
                uStack_30 = *(double *)(puVar14 + 4);
                puVar14[4] = 0;
                puVar14[5] = 0xf;
                *(undefined *)puVar14 = 0;
                uStack_8._0_1_ = 0x12;
                uStack_3bc = (double)CONCAT44(":WaitForChild(\"",&uStack_40);
                puStack_3c0 = auStack_1cc;
                pppuStack_3c4 = (undefined4 ***)0x8a84a0;
                uStack_3c8 = FUN_00558c80();
                pppuStack_3c4 = apppuStack_a0;
                uStack_8._0_1_ = 0x13;
                puStack_3cc = auStack_1b4;
                puStack_3d0 = (undefined *)0x8a84b8;
                uStack_3d4 = FUN_00558c20();
                puStack_3d0 = &DAT_0191e1ac;
                puStack_3d8 = auStack_19c;
                uStack_8._0_1_ = 0x14;
                iStack_3dc = 0x8a84ce;
                FUN_00558c80();
                uStack_3bc = (double)CONCAT44(0x8a84dc,(undefined4)uStack_3bc);
                FUN_005507b0();
                uStack_3bc = (double)CONCAT44(0x8a84e7,(undefined4)uStack_3bc);
                FUN_005507b0();
                uStack_3bc = (double)CONCAT44(0x8a84ef,(undefined4)uStack_3bc);
                FUN_005507b0();
                uStack_8._0_1_ = 0x19;
                uStack_3bc = (double)CONCAT44(0x8a84fe,(undefined4)uStack_3bc);
                FUN_005507b0();
                uStack_3bc = (double)CONCAT44(&ppuStack_70,0x8a850d);
                FUN_00d88710();
                uStack_8._0_1_ = 0x1a;
                uStack_3bc = (double)CONCAT44(auStack_19c,0x8a8523);
                FUN_0054ef60();
                uStack_8._0_1_ = 0x1b;
                uStack_3bc = (double)DAT_01d62b94;
                FUN_00899a50(auStack_200);
                FUN_008977e0();
                uStack_4c = FUN_009eef30();
                uStack_3bc = (double)CONCAT44(0x8a856d,(undefined4)uStack_3bc);
                FUN_0089ab50();
                uStack_8 = CONCAT31(uStack_8._1_3_,9);
                uStack_3bc = (double)CONCAT44(0x8a857c,(undefined4)uStack_3bc);
                FUN_005507b0();
              }
              else {
                uStack_3bc = (double)CONCAT44(piStack_18,&uStack_30);
                puStack_3c0 = (undefined *)0x8a824d;
                FUN_0060e0c0();
                puStack_1c = &uStack_168;
                uStack_3bc = dStack_48;
                piStack_18 = &iStack_3dc;
                if (uStack_30._4_4_ != (int *)0x0) {
                  LOCK();
                  uStack_30._4_4_[2] = uStack_30._4_4_[2] + 1;
                  UNLOCK();
                }
                uStack_168 = (uint)uStack_30;
                piStack_164 = uStack_30._4_4_;
                puStack_24 = auStack_160;
                uStack_8._0_1_ = 0xb;
                FUN_0054ef60(&uStack_88);
                uStack_8._0_1_ = 0xc;
                FUN_00d88710(&ppuStack_70);
                if (uStack_50 != 0) {
                  LOCK();
                  *(int *)(uStack_50 + 8) = *(int *)(uStack_50 + 8) + 1;
                  UNLOCK();
                }
                uStack_12c = uStack_54;
                uStack_128 = uStack_50;
                uStack_124 = uStack_4c;
                puStack_24 = auStack_120;
                uStack_8._0_1_ = 0xd;
                FUN_0054ef60(auStack_e0);
                uStack_8._0_1_ = 0xe;
                FUN_00d88710(auStack_c8);
                if (uStack_a8 != 0) {
                  LOCK();
                  *(int *)(uStack_a8 + 8) = *(int *)(uStack_a8 + 8) + 1;
                  UNLOCK();
                }
                uStack_ec = uStack_ac;
                uStack_e8 = uStack_a8;
                uStack_e4 = uStack_a4;
                uStack_8._0_1_ = 0xf;
                FUN_00899aa0(&uStack_168);
                uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
                *piStack_18 = 0;
                FUN_00899aa0(auStack_364);
                FUN_00898aa0();
                FUN_0089b470();
                FUN_0089b470();
                if (piStack_360 != (int *)0x0) {
                  LOCK();
                  iVar10 = piStack_360[2] + -1;
                  piStack_360[2] = iVar10;
                  UNLOCK();
                  if (iVar10 == 0) {
                    (**(code **)(*piStack_360 + 4))();
                  }
                }
                uStack_8 = CONCAT31(uStack_8._1_3_,10);
                FUN_0089b470();
                FUN_0089b470();
                if (piStack_164 != (int *)0x0) {
                  LOCK();
                  piVar3 = piStack_164 + 2;
                  iVar10 = *piVar3;
                  *piVar3 = *piVar3 + -1;
                  UNLOCK();
                  if (iVar10 == 1) {
                    (**(code **)(*piStack_164 + 4))();
                  }
                }
                uStack_4c = FUN_009eef30();
                uStack_8 = CONCAT31(uStack_8._1_3_,9);
                uStack_3bc = (double)CONCAT44(0x8a842f,(undefined4)uStack_3bc);
                FUN_0056c200();
              }
            }
          }
        }
      }
      iVar10 = iStack_28;
      puVar5 = *(uint **)(iStack_28 + 0x74);
      if (*(uint **)(iStack_28 + 0x78) == puVar5) {
        uStack_3bc = (double)CONCAT44(&uStack_88,puVar5);
        puStack_3c0 = (undefined *)0x8a861d;
        FUN_00897ce0();
      }
      else {
        puVar5[4] = 0;
        puVar5[5] = 0;
        *puVar5 = uStack_88;
        puVar5[1] = uStack_84;
        puVar5[2] = uStack_80;
        puVar5[3] = uStack_7c;
        *(ulonglong *)(puVar5 + 4) = CONCAT44(uStack_74,uStack_78);
        uStack_78 = 0;
        uStack_74 = 0xf;
        uStack_88 = uStack_88 & 0xffffff00;
        uStack_8._0_1_ = 0x1c;
        uStack_3bc = (double)CONCAT44(&ppuStack_70,0x8a85d5);
        puStack_1c = puVar5;
        FUN_00d88710();
        puVar5[0xd] = 0;
        puVar5[0xe] = 0;
        puVar5[0xd] = uStack_54;
        puVar5[0xe] = uStack_50;
        uStack_54 = 0;
        uStack_50 = 0;
        puVar5[0xf] = uStack_4c;
        *(int *)(iVar10 + 0x74) = *(int *)(iVar10 + 0x74) + 0x40;
        uStack_8 = CONCAT31(uStack_8._1_3_,9);
      }
      uStack_3bc = (double)(ulonglong)param_2;
      puStack_3c0 = (undefined *)0x8a8627;
      uVar11 = FUN_01258cc0();
      uStack_3bc = (double)CONCAT44(0x8a8637,(undefined4)uStack_3bc);
      FUN_0089b470();
      uStack_3bc = (double)CONCAT44(0x8a8642,(undefined4)uStack_3bc);
      FUN_0089b470();
      uStack_3bc = (double)CONCAT44(0x8a864d,(undefined4)uStack_3bc);
      FUN_005507b0();
      uStack_8 = 0x1d;
      if (iStack_2d4 != 0) {
        uStack_3bc = (double)CONCAT44(auStack_2d0,0x8a866a);
        (**(code **)(iStack_2d4 + 8))();
      }
      ExceptionList = pvStack_10;
      return uVar11;
    }
    uStack_3bc = (double)CONCAT44(iVar10,&uStack_30);
    puStack_3c0 = (undefined *)0x8a7fb3;
    puStack_3c0 = (undefined *)FUN_0060dcd0();
    pppuStack_3c4 = (undefined4 ***)param_2;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    uStack_3c8 = 0x8a7fbe;
    FUN_00da3620();
    piVar3 = uStack_30._4_4_;
    if (uStack_30._4_4_ != (int *)0x0) {
      LOCK();
      iVar10 = uStack_30._4_4_[1] + -1;
      uStack_30._4_4_[1] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        uStack_3bc = (double)CONCAT44(0x8a7fda,(undefined4)uStack_3bc);
        (**(code **)*uStack_30._4_4_)();
        LOCK();
        piVar2 = piVar3 + 2;
        iVar10 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar10 == 1) {
          uStack_3bc = (double)CONCAT44(0x8a7fe9,(undefined4)uStack_3bc);
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    uStack_3bc = (double)CONCAT44(0x8a7ff4,(undefined4)uStack_3bc);
    FUN_005507b0();
    uStack_8 = 5;
    if (iStack_2d4 != 0) {
      uStack_3bc = (double)CONCAT44(auStack_2d0,0x8a8011);
      (**(code **)(iStack_2d4 + 8))();
    }
    ExceptionList = pvStack_10;
    return 1;
  }
  if (0.0 < dStack_48) {
    uStack_30 = dStack_48;
    uStack_3bc = (double)CONCAT44(&uStack_30,0x8a7f86);
    sVar8 = FUN_017265ed();
    if (sVar8 != 2) goto LAB_008a7f93;
  }
  uStack_3bc = (double)CONCAT44("illegal argument #2 (timeOut must be greater than 0)",&uStack_34);
  puStack_3c0 = (undefined *)0x8a868f;
  FUN_016756b0();
  uStack_3bc = (double)CONCAT44(&DAT_01c17198,&uStack_34);
                    /* WARNING: Subroutine does not return */
  puStack_3c0 = (undefined *)0x8a86a0;
  FUN_0170c2a8();
}



/* FUNCTION 14431 ; VA 0x008a86c0 ; FUN_008a86c0 */

int * __fastcall FUN_008a86c0(int *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a655f;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  if (iVar2 == 0) {
    ExceptionList = &pvStack_10;
    piStack_14 = (int *)FUN_01674e20(0x18);
    if (piStack_14 == (int *)0x0) {
      *param_1 = 0xc;
      piVar3 = (int *)param_1[1];
      param_1[1] = 0;
    }
    else {
      piStack_14[1] = 1;
      piStack_14[2] = 1;
      *piStack_14 = (int)std::
                         _Ref_count_obj<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>
                         ::vftable;
      piStack_14[3] = 0;
      piStack_14[4] = 0;
      piStack_14[5] = 0;
      *param_1 = (int)(piStack_14 + 3);
      piVar3 = (int *)param_1[1];
      param_1[1] = (int)piStack_14;
    }
  }
  else {
    if (param_1[1] == 0) {
      return param_1;
    }
    if (*(int *)(param_1[1] + 4) < 2) {
      return param_1;
    }
    ExceptionList = &pvStack_10;
    piVar3 = (int *)FUN_01674e20(0x18);
    uStack_8 = 0;
    if (piVar3 == (int *)0x0) {
      piVar3 = (int *)0x0;
    }
    else {
      piVar3[1] = 1;
      piVar3[2] = 1;
      *piVar3 = (int)std::
                     _Ref_count_obj<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>
                     ::vftable;
      piStack_14 = piVar3;
      FUN_00569460(iVar2);
    }
    piStack_18 = piVar3 + 3;
    piStack_14 = piVar3;
    FUN_005587e0(&piStack_18);
    piVar3 = piStack_14;
  }
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14432 ; VA 0x008a87d0 ; FUN_008a87d0 */

void __thiscall
FUN_008a87d0(int param_1,int param_2,uint *param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 *puVar1;
  int *piVar2;
  void **ppvVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4f98;
  pvStack_10 = ExceptionList;
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    ppvVar3 = &pvStack_10;
    for (piVar7 = (int *)*puVar1; ExceptionList = ppvVar3, piVar7 != piVar2; piVar7 = piVar7 + 2) {
      if (*param_3 == 0) {
        uVar6 = FUN_0054fda0();
        uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
        FUN_0054e5e0(uVar6);
      }
      cVar4 = (**(code **)((*param_3 & 0xfffffffe) + 4))(param_3 + 2,*piVar7);
      if (((cVar4 != '\0') && (*(char *)(*piVar7 + 0x21) != '\0')) &&
         (iVar5 = (**(code **)(*(int *)*piVar7 + 0x54))(param_3,param_4,param_5), iVar5 != 0)) {
        if (*(int **)(param_2 + 8) == (int *)0x0) {
          *(int *)(param_2 + 4) = iVar5;
        }
        else {
          **(int **)(param_2 + 8) = iVar5;
        }
        *(int *)(param_2 + 8) = iVar5;
      }
      ppvVar3 = (void **)ExceptionList;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14433 ; VA 0x008a8880 ; FUN_008a8880 */

void FUN_008a8880(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  uint auStack_30 [2];
  code *apcStack_28 [6];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc758;
  pvStack_10 = ExceptionList;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_008a3ae0(apcStack_28,apcStack_28,2);
  apcStack_28[0] = FUN_00554b40;
  auStack_30[0] = 0x191e879;
  uStack_8 = 0;
  FUN_008a87d0(param_1,auStack_30,param_2,param_3);
  uStack_8 = 1;
  if (((auStack_30[0] != 0) && ((auStack_30[0] & 1) == 0)) &&
     (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_30[0] & 0xfffffffe))(apcStack_28,apcStack_28,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14434 ; VA 0x008a8920 ; FUN_008a8920 */

int * __thiscall FUN_008a8920(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int *piVar5;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc778;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  FUN_00d85940(uVar3);
  uStack_8 = 0;
  FUN_0087ccc0();
  puVar4 = (undefined4 *)FUN_01674e20(8);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
    piVar5 = (int *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 0;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
    }
    *puVar4 = uStack_18;
    puVar4[1] = piStack_14;
    piVar5 = piStack_14;
  }
  *(undefined4 **)(param_3 + 0x18) = puVar4;
  *(undefined4 *)(param_3 + 0x14) = 8;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    piVar5 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piVar5 = (int *)(**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piVar5 = (int *)(**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 14435 ; VA 0x008a89f0 ; FUN_008a89f0 */

undefined4 * __thiscall FUN_008a89f0(int *param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined auStack_28 [8];
  int *piStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9c38;
  pvStack_10 = ExceptionList;
  if (*(char *)((int)param_1 + 0x21) != '\0') {
    ExceptionList = &pvStack_10;
    piStack_20 = param_1;
    iVar1 = (**(code **)(*param_1 + 0x10))();
    iVar2 = FUN_0086e640();
    if (iVar1 == iVar2) {
      ExceptionList = pvStack_10;
      return (undefined4 *)0x0;
    }
    if (param_3 == 1) {
      uVar3 = *(uint *)(param_1[3] + 0x1d4) >> 2;
    }
    else {
      if (param_3 != 2) goto LAB_008a8a6b;
      uVar3 = *(uint *)(param_1[3] + 0x1d4) >> 3;
    }
    if ((uVar3 & 1) != 0) {
LAB_008a8a6b:
      puStack_18 = (undefined4 *)FUN_01674e20(0x28);
      uVar4 = DAT_01ede600;
      if (puStack_18 == (undefined4 *)0x0) {
        puStack_18 = (undefined4 *)0x0;
      }
      else {
        *puStack_18 = 0;
        puStack_18[1] = 0;
        puStack_18[2] = 0;
        puStack_18[4] = uVar4;
        puStack_18[5] = 0;
        puStack_18[8] = 0;
        puStack_18[9] = 0;
      }
      puVar6 = puStack_18;
      uVar4 = (**(code **)(*param_1 + 0x10))();
      uVar8 = 0x18;
      puStack_1c = (undefined4 *)DAT_01ede5fc;
      uVar7 = 0x8a8ace;
      puStack_14 = (undefined4 *)FUN_01674e20(0x18);
      if (puStack_14 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)0x0;
      }
      else {
        *puStack_14 = 0;
        puStack_14[2] = puStack_1c;
        puStack_14[3] = 1;
        puStack_14[4] = uVar4;
        puVar5 = puStack_14;
      }
      if ((undefined4 *)puVar6[9] == (undefined4 *)0x0) {
        puVar6[8] = puVar5;
      }
      else {
        *(undefined4 *)puVar6[9] = puVar5;
      }
      puVar6[9] = puVar5;
      uVar4 = DAT_01ede59c;
      FUN_00d85940(param_1);
      FUN_008987b0(uVar4,uVar7,uVar8);
      uVar4 = DAT_01ede604;
      puStack_1c = (undefined4 *)FUN_01674e20(0x28);
      if (puStack_1c == (undefined4 *)0x0) {
        puVar6 = (undefined4 *)0x0;
      }
      else {
        *puStack_1c = 0;
        puStack_1c[1] = 0;
        puStack_1c[2] = 0;
        puStack_1c[4] = uVar4;
        puStack_1c[5] = 0;
        puStack_1c[8] = 0;
        puStack_1c[9] = 0;
        puVar6 = puStack_1c;
      }
      if ((undefined4 *)puStack_18[2] == (undefined4 *)0x0) {
        puStack_18[1] = puVar6;
      }
      else {
        *(undefined4 *)puStack_18[2] = puVar6;
      }
      puStack_18[2] = puVar6;
      puVar5 = *(undefined4 **)(param_1[3] + 0x18);
      if (puVar5 != *(undefined4 **)(param_1[3] + 0x1c)) {
        do {
          puStack_1c = (undefined4 *)*puVar5;
          iVar1 = FUN_009cb6b0(param_1,0);
          if (iVar1 != 0) {
            if ((int *)puVar6[2] == (int *)0x0) {
              puVar6[1] = iVar1;
            }
            else {
              *(int *)puVar6[2] = iVar1;
            }
            puVar6[2] = iVar1;
            iVar1 = puStack_1c[10];
            iVar2 = FUN_0088d4b0();
            param_1 = piStack_20;
            if (iVar1 == iVar2) {
              (**(code **)(*(int *)puStack_1c[0xd] + 0xc))(&puStack_14,piStack_20);
              uStack_8 = 0;
              FUN_00606470(auStack_28,&puStack_14,&puStack_14);
              uStack_8 = 0xffffffff;
              FUN_0056cd30();
            }
          }
          puVar5 = puVar5 + 1;
        } while (puVar5 != *(undefined4 **)(param_1[3] + 0x1c));
      }
      puVar6 = puStack_18;
      FUN_008a87d0(puStack_18,param_2,param_3,param_4);
      ExceptionList = pvStack_10;
      return puVar6;
    }
  }
  ExceptionList = pvStack_10;
  return (undefined4 *)0x0;
}



/* FUNCTION 14436 ; VA 0x008a8c30 ; FUN_008a8c30 */

undefined * FUN_008a8c30(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc79c;
  pvStack_10 = ExceptionList;
  if (DAT_01edf8e0 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edfaf0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01edfaf0);
      if (DAT_01edfaf0 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ServiceProvider",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01881490);
        FUN_016f37bf(&DAT_01edfaf0);
      }
    }
    DAT_01edf8e0 = &DAT_01edf8e8;
  }
  ExceptionList = pvStack_10;
  return DAT_01edf8e0;
}



/* FUNCTION 14437 ; VA 0x008a8d10 ; FUN_008a8d10 */

undefined4 * __thiscall
FUN_008a8d10(int *param_1,undefined4 *param_2,int *param_3,uint *param_4,undefined4 param_5)

{
  undefined *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  bool bVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc7b0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_00897fa0(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar2 = (int *)*param_1;
  if (param_3 == (int *)*piVar2) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*param_4 < (uint)param_3[4]) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_00897fa0(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar2) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*(uint *)(piVar2[2] + 0x10) < *param_4) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_00897fa0(param_2,0,piVar2[2],param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    bVar4 = (uint)param_3[4] < *param_4;
    ExceptionList = &pvStack_10;
    puVar1 = &stack0xffffffd4;
    if (*param_4 < (uint)param_3[4]) {
      piStack_18 = param_3;
      ExceptionList = &pvStack_10;
      piVar2 = (int *)FUN_0056f560();
      if (*(uint *)(*piVar2 + 0x10) < *param_4) {
        if (*(char *)(piStack_18[2] + 0xd) != '\0') {
          FUN_00897fa0(param_2,0,piStack_18,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00897fa0(param_2,1,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
      bVar4 = (uint)param_3[4] < *param_4;
      puVar1 = puStack_14;
    }
    puStack_14 = puVar1;
    if (bVar4) {
      piStack_18 = param_3;
      piVar2 = (int *)FUN_00551320();
      if ((*piVar2 == *param_1) || (*param_4 < (uint)piStack_18[4])) {
        if (*(char *)(param_3[2] + 0xd) != '\0') {
          FUN_00897fa0(param_2,0,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00897fa0(param_2,1,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = (undefined4 *)FUN_00898460(auStack_20,0,param_4,param_5);
  *param_2 = *puVar3;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14438 ; VA 0x008a8efd ; Catch_All@008a8efd */

void Catch_All_008a8efd(void)

{
  int unaff_EBP;
  
  FUN_0089c710(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14439 ; VA 0x008a8f20 ; FUN_008a8f20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall
FUN_008a8f20(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  undefined *puStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc80b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_008a8c30();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::ServiceProvider,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8 = 1;
  uVar2 = FUN_0088cdc0();
  param_1[9] = uVar2;
  iVar1 = param_1[0x10];
  if (iVar1 == 0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088cb40();
    puStack_e4 = (undefined *)0x0;
    FUN_0054ef60(iVar1);
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c48) {
      FUN_016f3809(&DAT_01ea8c48);
      if (DAT_01ea8c48 == -1) {
        _DAT_01ea8c3c = FUN_005c65f0;
        _DAT_01ea8c40 = FUN_005c93a0;
        DAT_01ea8c44 = FUN_005c77b0;
        FUN_016f37bf(&DAT_01ea8c48);
      }
    }
    puStack_e4 = &DAT_01ea8c3c;
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_e4 != (undefined *)0x0) {
      (**(code **)(puStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14440 ; VA 0x008a9110 ; FUN_008a9110 */

undefined4 * __thiscall
FUN_008a9110(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc841;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  uVar1 = FUN_008a8c30();
  FUN_009cb970(uVar1,param_3,0,CONCAT44(uStack_28,uStack_2c),0);
  param_1[0xd] = param_2;
  iStack_8 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::ServiceProvider,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::ServiceProvider::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,param_3);
  iStack_8._0_1_ = 2;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = uStack_1c;
    param_1[0xb] = uStack_18;
    param_1[0xc] = uStack_14;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::ServiceProvider,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::ServiceProvider::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14441 ; VA 0x008a9250 ; FUN_008a9250 */

undefined4 * __thiscall
FUN_008a9250(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined8 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  uVar1 = FUN_008a8c30();
  FUN_009cb970(uVar1,param_3,param_4,param_5,param_6);
  param_1[0xd] = param_2;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::ServiceProvider,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::ServiceProvider::*>
             ::vftable;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  if (param_1 + 10 != &uStack_20) {
    FUN_0068a760();
    param_1[10] = 0;
    param_1[0xb] = 0;
    param_1[0xc] = 0;
  }
  uStack_8 = 1;
  FUN_0068a760();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14442 ; VA 0x008a9310 ; FUN_008a9310 */

undefined4 * __thiscall FUN_008a9310(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc86b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a650(param_2);
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::ServiceProvider,class_RBX::Instance>::vftable;
  uVar1 = FUN_008a8c30();
  param_1[3] = uVar1;
  *param_1 = RBX::ServiceProvider::vftable;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  uStack_8 = 2;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  uVar1 = FUN_00575ad0();
  param_1[0x18] = uVar1;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14443 ; VA 0x008a93c0 ; FUN_008a93c0 */

undefined4 * __fastcall FUN_008a93c0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc86b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::ServiceProvider,class_RBX::Instance>::vftable;
  uVar1 = FUN_008a8c30();
  param_1[3] = uVar1;
  *param_1 = RBX::ServiceProvider::vftable;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  uStack_8 = 2;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  uVar1 = FUN_00575ad0();
  param_1[0x18] = uVar1;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14444 ; VA 0x008a9470 ; FUN_008a9470 */

void __fastcall FUN_008a9470(undefined4 *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::ServiceProvider::vftable;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  iVar1 = param_1[0x18];
  uStack_8 = 0;
  FUN_0089c760(*(undefined4 *)(iVar1 + 4));
  *(int *)(param_1[0x18] + 4) = iVar1;
  *(int *)param_1[0x18] = iVar1;
  *(int *)(param_1[0x18] + 8) = iVar1;
  param_1[0x19] = 0;
  FUN_01674ea0(param_1[0x18],0x1c);
  thunk_FUN_00577ac0();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14445 ; VA 0x008a9510 ; FUN_008a9510 */

undefined4 * __thiscall FUN_008a9510(undefined4 *param_1,byte param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::ServiceProvider::vftable;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  iVar1 = param_1[0x18];
  uStack_8 = 0;
  FUN_0089c760(*(undefined4 *)(iVar1 + 4));
  *(int *)(param_1[0x18] + 4) = iVar1;
  *(int *)param_1[0x18] = iVar1;
  *(int *)(param_1[0x18] + 8) = iVar1;
  param_1[0x19] = 0;
  FUN_01674ea0(param_1[0x18],0x1c);
  thunk_FUN_00577ac0();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x78);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14446 ; VA 0x008a95d0 ; FUN_008a95d0 */

bool FUN_008a95d0(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_0170d75d(param_1,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::Service::RTTI_Type_Descriptor,0);
  return iVar1 != 0;
}



/* FUNCTION 14447 ; VA 0x008a9600 ; FUN_008a9600 */

undefined4 FUN_008a9600(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_008dcf60();
    if (((uint)*(ushort *)(iVar2 + 0x1da) <
         (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) || (param_1 == 0xc)) {
      return 0;
    }
  }
  return 1;
}



/* FUNCTION 14448 ; VA 0x008a9650 ; FUN_008a9650 */

uint FUN_008a9650(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_008dcf60();
    uVar3 = (uint)*(ushort *)(iVar2 + 0x1da);
    if ((uVar3 < (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) ||
       (uVar3 = param_1 - 0xc, uVar3 == 0)) {
      return uVar3 & 0xffffff00;
    }
  }
  uVar3 = FUN_005c92d0(param_1);
  return uVar3;
}



/* FUNCTION 14449 ; VA 0x008a96a0 ; FUN_008a96a0 */

void __fastcall FUN_008a96a0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  puVar1 = (undefined4 *)(param_1 + 0x54);
  ExceptionList = &pvStack_10;
  FUN_005596d0(*puVar1,*(undefined4 *)(param_1 + 0x58),puVar1);
  *(undefined4 *)(param_1 + 0x58) = *puVar1;
  iVar2 = *(int *)(param_1 + 0x60);
  uStack_8 = 0;
  FUN_0089c760(*(undefined4 *)(iVar2 + 4));
  *(int *)(*(int *)(param_1 + 0x60) + 4) = iVar2;
  **(int **)(param_1 + 0x60) = iVar2;
  *(int *)(*(int *)(param_1 + 0x60) + 8) = iVar2;
  *(undefined4 *)(param_1 + 100) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14450 ; VA 0x008a9710 ; FUN_008a9710 */

undefined4 * __thiscall
FUN_008a9710(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbc31;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_0089fb30;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14451 ; VA 0x008a98b0 ; FUN_008a98b0 */

undefined4 * FUN_008a98b0(undefined4 *param_1,int *param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    do {
      iVar2 = param_2[3];
      iVar1 = FUN_008a8c30();
      piVar3 = (int *)0x0;
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
          (uint)*(ushort *)(iVar1 + 0x1da)) {
        piVar3 = param_2;
      }
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 0x50))(&uStack_18,param_3,3);
        uStack_8 = 0;
        iVar2 = FUN_0170d75d(uStack_18,0,&RBX::Instance::RTTI_Type_Descriptor,
                             &RBX::Service::RTTI_Type_Descriptor,0);
        if (iVar2 == 0) {
          *param_1 = 0;
          param_1[1] = 0;
          if (piStack_14 != (int *)0x0) {
            LOCK();
            iVar2 = piStack_14[1] + -1;
            piStack_14[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piStack_14)();
              LOCK();
              piVar3 = piStack_14 + 2;
              iVar2 = *piVar3;
              *piVar3 = *piVar3 + -1;
              UNLOCK();
              if (iVar2 == 1) {
                (**(code **)(*piStack_14 + 4))();
              }
            }
          }
          ExceptionList = pvStack_10;
          return param_1;
        }
        FUN_008a65e0(piVar3,0);
        *param_1 = uStack_18;
        param_1[1] = piStack_14;
        ExceptionList = pvStack_10;
        return param_1;
      }
      param_2 = (int *)param_2[0xd];
    } while (param_2 != (int *)0x0);
  }
  *param_1 = 0;
  param_1[1] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14452 ; VA 0x008a99d0 ; FUN_008a99d0 */

int * FUN_008a99d0(int *param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008a9ba0(&iStack_18,param_2);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    *param_1 = iStack_18;
    param_1[1] = (int)piStack_14;
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_0089ed80(param_1,param_2,param_3);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14453 ; VA 0x008a9a80 ; FUN_008a9a80 */

undefined4 * FUN_008a9a80(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  char *pcVar3;
  undefined4 uVar4;
  undefined auStack_1c [4];
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0086e830(param_2);
  if (*(int *)(iVar2 + 0x10) == 0) {
    uVar4 = FUN_005543f0();
    FUN_016756b0(auStack_1c,"\'%s\' is not a valid Service name",uVar4);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  FUN_008a9ba0(&uStack_18,iVar2);
  uVar4 = uStack_18;
  uStack_8 = 0;
  pcVar3 = (char *)FUN_0170d75d(uStack_18,0,&RBX::Instance::RTTI_Type_Descriptor,
                                &RBX::Service::RTTI_Type_Descriptor,0);
  piVar1 = piStack_14;
  if ((pcVar3 != (char *)0x0) && (*pcVar3 != '\0')) {
    uStack_18 = 0;
    piStack_14 = (int *)0x0;
    param_1[1] = piVar1;
    *param_1 = uVar4;
    FUN_00550b30();
    ExceptionList = pvStack_10;
    return param_1;
  }
  *param_1 = 0;
  param_1[1] = 0;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14454 ; VA 0x008a9ba0 ; FUN_008a9ba0 */

undefined4 * __thiscall FUN_008a9ba0(int param_1,undefined4 *param_2,uint param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x60);
  puVar3 = puVar1;
  puVar5 = (undefined4 *)puVar1[1];
  if (*(char *)((int)puVar1[1] + 0xd) == '\0') {
    do {
      puVar4 = puVar5;
      if ((uint)puVar4[4] < param_3) {
        puVar5 = (undefined4 *)puVar4[2];
        puVar4 = puVar3;
      }
      else {
        puVar5 = (undefined4 *)*puVar4;
      }
      puVar3 = puVar4;
    } while (*(char *)((int)puVar5 + 0xd) == '\0');
    if ((puVar4 != puVar1) && ((uint)puVar4[4] <= param_3)) goto LAB_008a9bd4;
  }
  puVar4 = puVar1;
LAB_008a9bd4:
  if (puVar4 == puVar1) {
    *param_2 = 0;
    param_2[1] = 0;
    return param_2;
  }
  iVar6 = puVar4[6];
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar6 != 0) {
    LOCK();
    *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
    UNLOCK();
    iVar6 = puVar4[6];
  }
  uVar2 = puVar4[5];
  param_2[1] = iVar6;
  *param_2 = uVar2;
  return param_2;
}



/* FUNCTION 14455 ; VA 0x008a9c20 ; FUN_008a9c20 */

void FUN_008a9c20(undefined4 param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  param_2 = (int *)*param_2;
  iVar3 = *param_2;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0088cdc0();
  if (iVar3 == iVar1) {
    piVar2 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar2 = (int *)0x0;
    }
    iVar3 = piVar2[1];
    if (iVar3 != 0) {
      LOCK();
      *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
      UNLOCK();
      iVar3 = piVar2[1];
    }
    uStack_8 = 0;
    FUN_0089be10(*piVar2,iVar3);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 14456 ; VA 0x008a9cc0 ; FUN_008a9cc0 */

void FUN_008a9cc0(void)

{
  int iVar1;
  
  if (DAT_01edfaf4 == 0) {
    iVar1 = FUN_008a8c30();
    DAT_01edfaf4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 14457 ; VA 0x008a9ce0 ; FUN_008a9ce0 */

undefined4 * __thiscall FUN_008a9ce0(int *param_1,undefined4 *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  char *pcVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined4 uStack_24;
  int *piStack_20;
  undefined auStack_1c [4];
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc890;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0086e830(param_3);
  if (*(int *)(iVar3 + 0x10) == 0) {
    uVar7 = FUN_005543f0();
    FUN_016756b0(auStack_1c,"\'%s\' is not a valid Service name",uVar7);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  if (param_1 != (int *)0x0) {
    do {
      iVar1 = param_1[3];
      iVar4 = FUN_008a8c30();
      piVar6 = (int *)0x0;
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
          (uint)*(ushort *)(iVar4 + 0x1da)) {
        piVar6 = param_1;
      }
      if (piVar6 != (int *)0x0) {
        (**(code **)(*piVar6 + 0x50))(&uStack_24,iVar3,3);
        uStack_8 = 0;
        iVar3 = FUN_0170d75d(uStack_24,0,&RBX::Instance::RTTI_Type_Descriptor,
                             &RBX::Service::RTTI_Type_Descriptor,0);
        piVar2 = piStack_20;
        if (iVar3 == 0) {
          uStack_18 = 0;
          piStack_14 = (int *)0x0;
          if (piStack_20 != (int *)0x0) {
            LOCK();
            iVar3 = piStack_20[1] + -1;
            piStack_20[1] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)*piStack_20)();
              LOCK();
              piVar6 = piVar2 + 2;
              iVar3 = *piVar6 + -1;
              *piVar6 = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)(*piVar2 + 4))();
              }
            }
          }
          uVar7 = 0;
          param_3 = (int *)0x0;
        }
        else {
          FUN_008a65e0(piVar6,0);
          uVar7 = uStack_24;
          param_3 = piStack_20;
          uStack_24 = 0;
          piStack_20 = (int *)0x0;
          uStack_18 = uVar7;
          piStack_14 = param_3;
        }
        goto LAB_008a9d60;
      }
      param_1 = (int *)param_1[0xd];
    } while (param_1 != (int *)0x0);
  }
  uVar7 = 0;
  param_3 = (int *)0x0;
  uStack_18 = uVar7;
  piStack_14 = param_3;
LAB_008a9d60:
  uStack_8 = 1;
  pcVar5 = (char *)FUN_0170d75d(uVar7,0,&RBX::Instance::RTTI_Type_Descriptor,
                                &RBX::Service::RTTI_Type_Descriptor,0);
  if ((pcVar5 != (char *)0x0) && (*pcVar5 != '\0')) {
    uStack_18 = 0;
    piStack_14 = (int *)0x0;
    *param_2 = uVar7;
    param_2[1] = param_3;
    FUN_00550b30();
    ExceptionList = pvStack_10;
    return param_2;
  }
  *param_2 = 0;
  param_2[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar6 = param_3 + 2;
      iVar3 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14458 ; VA 0x008a9ed0 ; FUN_008a9ed0 */

int FUN_008a9ed0(void)

{
  int iVar1;
  
  iVar1 = DAT_01d62c34;
  LOCK();
  DAT_01d62c34 = DAT_01d62c34 + 1;
  UNLOCK();
  return iVar1 + 1;
}



/* FUNCTION 14459 ; VA 0x008a9ee0 ; FUN_008a9ee0 */

int FUN_008a9ee0(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  int iStack_24;
  int *piStack_20;
  uint *puStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9558;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0170d75d(param_1,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::Service::RTTI_Type_Descriptor,0);
  if (iVar2 == 0) {
    ExceptionList = pvStack_10;
    return 0;
  }
  FUN_0060dcd0(&iStack_24,piVar1);
  uStack_8 = 0;
  iVar2 = (**(code **)(*piVar1 + 0x10))();
  iVar3 = FUN_0086e640();
  if (iVar2 == iVar3) goto LAB_008aa004;
  param_1 = (int *)(iStack_14 + 0x60);
  *(undefined *)((int)piVar1 + 0x22) = 1;
  uStack_18 = (**(code **)(*piVar1 + 0x10))();
  piVar1 = (int *)*param_1;
  piVar4 = (int *)piVar1[1];
  piVar6 = piVar1;
  if (*(char *)(piVar1[1] + 0xd) == '\0') {
    do {
      if ((uint)piVar4[4] < uStack_18) {
        piVar5 = (int *)piVar4[2];
      }
      else {
        piVar5 = (int *)*piVar4;
        piVar6 = piVar4;
      }
      piVar4 = piVar5;
    } while (*(char *)((int)piVar5 + 0xd) == '\0');
    if ((piVar6 == piVar1) || (uStack_18 < (uint)piVar6[4])) goto LAB_008a9f94;
  }
  else {
LAB_008a9f94:
    puStack_1c = &uStack_18;
    iVar2 = FUN_00559250(&DAT_018bdeda,&puStack_1c,(int)&param_1 + 3);
    FUN_008a8d10(&param_1,piVar6,iVar2 + 0x10,iVar2);
    piVar6 = param_1;
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piStack_20[1] = piStack_20[1] + 1;
    UNLOCK();
  }
  piVar6[5] = iStack_24;
  piVar1 = (int *)piVar6[6];
  piVar6[6] = (int)piStack_20;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
LAB_008aa004:
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piStack_20[1] = piStack_20[1] + 1;
    UNLOCK();
  }
  iVar2 = FUN_0089be10(iStack_24,piStack_20);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_20 + 1;
    iVar3 = *piVar1;
    iVar2 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar2 = (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar2 = (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 14460 ; VA 0x008aa070 ; FUN_008aa070 */

void __thiscall FUN_008aa070(int param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  
  uVar3 = (**(code **)(*param_2 + 0x10))();
  puVar2 = *(undefined4 **)(param_1 + 0x60);
  puVar4 = (undefined4 *)puVar2[1];
  puVar6 = puVar2;
  if (*(char *)((int)puVar2[1] + 0xd) == '\0') {
    do {
      if ((uint)puVar4[4] < uVar3) {
        puVar5 = (undefined4 *)puVar4[2];
      }
      else {
        puVar5 = (undefined4 *)*puVar4;
        puVar6 = puVar4;
      }
      puVar4 = puVar5;
    } while (*(char *)((int)puVar5 + 0xd) == '\0');
    if ((puVar6 != puVar2) && ((uint)puVar6[4] <= uVar3)) goto LAB_008aa0af;
  }
  puVar6 = puVar2;
LAB_008aa0af:
  if (puVar6 != puVar2) {
    if (puVar6[6] != 0) {
      LOCK();
      piVar1 = (int *)(puVar6[6] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_0089be10(puVar6[5],puVar6[6]);
  }
  return;
}



/* FUNCTION 14461 ; VA 0x008aa0f0 ; FUN_008aa0f0 */

void __thiscall FUN_008aa0f0(undefined4 param_1,int *param_2)

{
  FUN_008a4130(param_2);
  (**(code **)(*param_2 + 0x4c))(0,param_1);
  return;
}



/* FUNCTION 14462 ; VA 0x008aa110 ; FUN_008aa110 */

void __thiscall FUN_008aa110(undefined4 param_1,undefined4 *param_2)

{
  (**(code **)(*(int *)*param_2 + 0x4c))(param_1,0);
  FUN_008a41c0(param_2);
  return;
}



/* FUNCTION 14463 ; VA 0x008aa140 ; FUN_008aa140 */

int __thiscall FUN_008aa140(int param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  if ((uint)(*(int *)(param_1 + 0x58) - *(int *)(param_1 + 0x54) >> 3) <= param_2) {
    uStack_18 = 0;
    piStack_14 = (int *)0x0;
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_00791bc0(param_2 + 1,(int *)(param_1 + 0x54),&uStack_18);
    piVar3 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[1] + -1;
      piStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return *(int *)(param_1 + 0x54) + param_2 * 8;
}



/* FUNCTION 14464 ; VA 0x008aa1e0 ; FUN_008aa1e0 */

void FUN_008aa1e0(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_38 [24];
  undefined auStack_20 [12];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5279;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  if (param_2 != 0) {
    iVar1 = *(int *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar2 = FUN_008dcf60();
    if (((uint)*(ushort *)(iVar2 + 0x1da) <
         (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) || (param_2 == 0xc)) {
      FUN_008a2380(auStack_38);
      uStack_8 = 0;
      uStack_14 = 1;
      uVar3 = FUN_005543f0();
      (**(code **)(*param_1 + 0x10))(uVar3);
      uVar3 = FUN_005543f0();
      FUN_016756b0(auStack_20,"Invalid parent for Service. %s cannot be parented to %s .",uVar3);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_20,&DAT_01c17198);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14465 ; VA 0x008aa2a0 ; FUN_008aa2a0 */

void __thiscall FUN_008aa2a0(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_38 [24];
  undefined auStack_20 [12];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5279;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  if (param_2 != 0) {
    iVar1 = *(int *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar2 = FUN_008dcf60();
    if (((uint)*(ushort *)(iVar2 + 0x1da) <
         (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) || (param_2 == 0xc)) {
      FUN_008a2380(auStack_38);
      uStack_8 = 0;
      uStack_14 = 1;
      uVar3 = FUN_005543f0();
      (**(code **)(*param_1 + 0x10))(uVar3);
      uVar3 = FUN_005543f0();
      FUN_016756b0(auStack_20,"Invalid parent for Service. %s cannot be parented to %s .",uVar3);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_20,&DAT_01c17198);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14466 ; VA 0x008aa360 ; FUN_008aa360 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_008aa360(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  
  uVar3 = FUN_0088cc80();
  *param_1 = uVar3;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = *param_2;
  iVar2 = _tls_index;
  param_1[3] = param_2[1];
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01eded74) {
    FUN_016f3809(&DAT_01eded74);
    if (DAT_01eded74 == -1) {
      DAT_01eded68 = FUN_0057bbb0;
      _DAT_01eded6c = FUN_005880a0;
      DAT_01eded70 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01eded74);
    }
  }
  param_1[1] = &DAT_01eded68;
  return param_1;
}



/* FUNCTION 14467 ; VA 0x008aa410 ; FUN_008aa410 */

int * __thiscall
FUN_008aa410(int *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc8b3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008bbce0();
  uVar3 = FUN_008aa870();
  FUN_009ca670(uVar3,iVar2,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,1);
  param_1[0xd] = iVar2;
  uStack_8 = 0;
  *param_1 = (int)RBX::Reflection::
                  EnumPropDescriptor<class_RBX::Workspace,enum_RBX::PhysicsSimulationRate>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::PropDescriptor<class_RBX::Workspace,enum_RBX::PhysicsSimulationRate>
              ::
              GetSetImpl<enum_RBX::PhysicsSimulationRate_(__thiscall_RBX::Workspace::*)(void)const_,void_(__thiscall_RBX::Workspace::*)(enum_RBX::PhysicsSimulationRate)>
              ::vftable;
    *(undefined8 *)(puVar4 + 2) = param_4;
    puVar4[4] = param_5;
    *(undefined8 *)(puVar4 + 6) = param_6;
    puVar4[8] = param_7;
  }
  param_1[0xe] = (int)puVar4;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar2 = FUN_008bbce0();
  param_1[0xf] = iVar2;
  cVar1 = (**(code **)(*param_1 + 0xc))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar1 = (**(code **)(*param_1 + 8))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14468 ; VA 0x008aa4f0 ; FUN_008aa4f0 */

int * __thiscall
FUN_008aa4f0(int *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc8db;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008aa870();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Workspace,int>::
              GetSetImpl<int_(__thiscall_RBX::Workspace::*)(void)const_,void_(__thiscall_RBX::Workspace::*)(int)>
              ::vftable;
    *(undefined8 *)(puVar3 + 2) = param_4;
    puVar3[4] = param_5;
    *(undefined8 *)(puVar3 + 6) = param_6;
    puVar3[8] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Workspace,int>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Workspace,int>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14469 ; VA 0x008aa600 ; FUN_008aa600 */

int * __thiscall
FUN_008aa600(int *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baf8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008aa870();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Workspace,bool>::
              GetSetImpl<bool_(__thiscall_RBX::Workspace::*)(void)const_,void_(__thiscall_RBX::Workspace::*)(bool)>
              ::vftable;
    *(undefined8 *)(puVar3 + 2) = param_4;
    puVar3[4] = param_5;
    *(undefined8 *)(puVar3 + 6) = param_6;
    puVar3[8] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_13,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Workspace,bool>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::Workspace,bool>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 14470 ; VA 0x008aa710 ; FUN_008aa710 */

undefined4 * __thiscall
FUN_008aa710(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  
  uVar1 = FUN_008aa870();
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar2 != (undefined4 *)0x0) {
    *puVar2 = RBX::Reflection::PropDescriptor<class_RBX::Workspace,bool>::
              GetSetImpl<bool_(__thiscall_RBX::Workspace::*)(void)const_,void_(__thiscall_RBX::Workspace::*)(bool)>
              ::vftable;
    *(undefined8 *)(puVar2 + 2) = param_4;
    puVar2[4] = param_5;
    *(undefined8 *)(puVar2 + 6) = param_6;
    puVar2[8] = param_7;
  }
  FUN_00684820(uVar1,param_2,param_3);
  *param_1 = RBX::Reflection::PropDescriptor<class_RBX::Workspace,bool>::vftable;
  return param_1;
}



/* FUNCTION 14471 ; VA 0x008aa7a0 ; FUN_008aa7a0 */

int * __thiscall FUN_008aa7a0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_008bbe40();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 14472 ; VA 0x008aa7f0 ; FUN_008aa7f0 */

int * __thiscall FUN_008aa7f0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_008bbf20();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 14473 ; VA 0x008aa840 ; FUN_008aa840 */

void __fastcall FUN_008aa840(undefined4 *param_1)

{
  (*(code *)*param_1)(param_1 + 3);
  return;
}



/* FUNCTION 14474 ; VA 0x008aa870 ; FUN_008aa870 */

undefined * FUN_008aa870(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc8fc;
  pvStack_10 = ExceptionList;
  if (DAT_01edfc24 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edfe30) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01edfe30);
      if (DAT_01edfe30 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00a93fd0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Workspace",1,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01881950);
        FUN_016f37bf(&DAT_01edfe30);
      }
    }
    DAT_01edfc24 = &DAT_01edfc28;
  }
  ExceptionList = pvStack_10;
  return DAT_01edfc24;
}



/* FUNCTION 14475 ; VA 0x008aa950 ; FUN_008aa950 */

void FUN_008aa950(void)

{
  int iVar1;
  
  if (DAT_01edfe34 == 0) {
    iVar1 = FUN_008aa870();
    DAT_01edfe34 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 14476 ; VA 0x008aa970 ; FUN_008aa970 */

undefined4 FUN_008aa970(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc910;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0087c450("Studio","InterpolationThrottlingMode","Default",0,0,0);
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 14477 ; VA 0x008aa9cd ; Catch_All@008aa9cd */

undefined * Catch_All_008aa9cd(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  uVar1 = **(undefined4 **)(unaff_EBP + 0xc);
  uVar2 = FUN_005de200(unaff_EBP + -0x18);
  *(undefined *)(unaff_EBP + -4) = 2;
  FUN_016dfd2b(uVar1,uVar2);
  *(undefined *)(unaff_EBP + -4) = 3;
  FUN_016dfdcc(unaff_EBP + -0x18);
  return &LAB_008aa9fc;
}



/* FUNCTION 14478 ; VA 0x008aaa20 ; FUN_008aaa20 */

undefined4 FUN_008aaa20(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc920;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0087c450("Studio","InterpolationThrottlingMode","Disabled",0,0,0);
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 14479 ; VA 0x008aaa7d ; Catch_All@008aaa7d */

undefined * Catch_All_008aaa7d(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  uVar1 = **(undefined4 **)(unaff_EBP + 0xc);
  uVar2 = FUN_005de200(unaff_EBP + -0x18);
  *(undefined *)(unaff_EBP + -4) = 2;
  FUN_016dfd2b(uVar1,uVar2);
  *(undefined *)(unaff_EBP + -4) = 3;
  FUN_016dfdcc(unaff_EBP + -0x18);
  return &LAB_008aaaac;
}



/* FUNCTION 14480 ; VA 0x008aaad0 ; FUN_008aaad0 */

undefined4 FUN_008aaad0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc930;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0087c450("Studio","InterpolationThrottlingMode","Enabled",0,0,0);
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 14481 ; VA 0x008aab2d ; Catch_All@008aab2d */

undefined * Catch_All_008aab2d(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  uVar1 = **(undefined4 **)(unaff_EBP + 0xc);
  uVar2 = FUN_005de200(unaff_EBP + -0x18);
  *(undefined *)(unaff_EBP + -4) = 2;
  FUN_016dfd2b(uVar1,uVar2);
  *(undefined *)(unaff_EBP + -4) = 3;
  FUN_016dfdcc(unaff_EBP + -0x18);
  return &LAB_008aab5c;
}



/* FUNCTION 14482 ; VA 0x008aab80 ; FUN_008aab80 */

void FUN_008aab80(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  
  if (param_1 != param_2) {
    piVar5 = param_1 + 0xc;
    do {
      iVar2 = piVar5[-2];
      if (iVar2 != 0) {
        uVar4 = *piVar5 - iVar2 & 0xfffffffc;
        iVar3 = iVar2;
        if (0xfff < uVar4) {
          iVar3 = *(int *)(iVar2 + -4);
          uVar4 = uVar4 + 0x23;
          if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_008aac82;
        }
        FUN_01674ea0(iVar3,uVar4);
        piVar5[-2] = 0;
        piVar5[-1] = 0;
        *piVar5 = 0;
      }
      iVar2 = piVar5[-5];
      if (iVar2 != 0) {
        uVar4 = piVar5[-3] - iVar2 & 0xfffffffc;
        iVar3 = iVar2;
        if (0xfff < uVar4) {
          iVar3 = *(int *)(iVar2 + -4);
          uVar4 = uVar4 + 0x23;
          if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_008aac82;
        }
        FUN_01674ea0(iVar3,uVar4);
        piVar5[-5] = 0;
        piVar5[-4] = 0;
        piVar5[-3] = 0;
      }
      iVar2 = piVar5[-8];
      if (iVar2 != 0) {
        uVar4 = piVar5[-6] - iVar2 & 0xfffffffc;
        iVar3 = iVar2;
        if (0xfff < uVar4) {
          iVar3 = *(int *)(iVar2 + -4);
          uVar4 = uVar4 + 0x23;
          if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_008aac82:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar3,uVar4);
        piVar5[-8] = 0;
        piVar5[-7] = 0;
        piVar5[-6] = 0;
      }
      piVar1 = piVar5 + 1;
      piVar5 = piVar5 + 0xd;
    } while (piVar1 != param_2);
  }
  return;
}



/* FUNCTION 14483 ; VA 0x008aac90 ; FUN_008aac90 */

void FUN_008aac90(uint *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  
  if (param_1 != param_2) {
    puVar6 = param_1 + 0x14;
    do {
      uVar2 = *puVar6;
      if (0xf < uVar2) {
        uVar3 = puVar6[-5];
        uVar5 = uVar2 + 1;
        uVar4 = uVar3;
        if (0xfff < uVar5) {
          uVar4 = *(uint *)(uVar3 - 4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (uVar3 - uVar4) - 4) goto LAB_008aad3a;
        }
        FUN_01674ea0(uVar4,uVar5);
      }
      puVar6[-1] = 0;
      *puVar6 = 0xf;
      *(undefined *)(puVar6 + -5) = 0;
      uVar2 = puVar6[-6];
      if (0xf < uVar2) {
        uVar3 = puVar6[-0xb];
        uVar5 = uVar2 + 1;
        uVar4 = uVar3;
        if (0xfff < uVar5) {
          uVar4 = *(uint *)(uVar3 - 4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (uVar3 - uVar4) - 4) {
LAB_008aad3a:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar4,uVar5);
      }
      puVar6[-7] = 0;
      puVar6[-6] = 0xf;
      *(undefined *)(puVar6 + -0xb) = 0;
      puVar1 = puVar6 + 1;
      puVar6 = puVar6 + 0x15;
    } while (puVar1 != param_2);
  }
  return;
}



/* FUNCTION 14484 ; VA 0x008aad40 ; FUN_008aad40 */

void __thiscall FUN_008aad40(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  
  uVar3 = (int)(param_1[1] - *param_1) / 0x18;
  uVar4 = (int)(param_1[2] - *param_1) / 0x18;
  if (param_2 <= uVar4) {
    if (uVar3 < param_2) {
      uVar3 = FUN_008aefc0(param_1[1],param_2 - uVar3);
      param_1[1] = uVar3;
      return;
    }
    if (param_2 != uVar3) {
      uVar3 = *param_1 + param_2 * 0x18;
      FUN_00602f40(uVar3,param_1[1],param_1);
      param_1[1] = uVar3;
    }
    return;
  }
  if (0xaaaaaaa < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar5 = param_2;
  if ((uVar4 <= 0xaaaaaaa - (uVar4 >> 1)) && (uVar5 = (uVar4 >> 1) + uVar4, uVar5 < param_2)) {
    uVar5 = param_2;
  }
  uVar4 = uVar5 * 0x18;
  if (uVar5 < 0xaaaaaab) {
    uVar5 = uVar4;
    if (0xfff < uVar4) goto LAB_008aadd2;
    if (uVar4 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_01674e20(uVar4);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_008aadd2:
    uVar1 = uVar5 + 0x23;
    if (uVar1 <= uVar5) {
      uVar1 = 0xffffffff;
    }
    iVar2 = FUN_01674e20(uVar1);
    if (iVar2 == 0) goto LAB_008aaf15;
    uVar5 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar5 - 4) = iVar2;
  }
  FUN_008aefc0(uVar5 + uVar3 * 0x18,param_2 - uVar3);
  uVar3 = param_1[1];
  uVar6 = uVar5;
  for (uVar1 = *param_1; uVar1 != uVar3; uVar1 = uVar1 + 0x18) {
    FUN_00703ee0(uVar1);
    uVar6 = uVar6 + 0x18;
  }
  FUN_00602f40(uVar6,uVar6,param_1);
  if (*param_1 != 0) {
    FUN_00602f40(*param_1,param_1[1],param_1);
    uVar3 = *param_1;
    uVar6 = ((int)(param_1[2] - uVar3) / 0x18) * 0x18;
    uVar1 = uVar3;
    if (0xfff < uVar6) {
      uVar1 = *(uint *)(uVar3 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar3 - uVar1) - 4) {
LAB_008aaf15:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar6);
  }
  *param_1 = uVar5;
  param_1[1] = uVar5 + param_2 * 0x18;
  param_1[2] = uVar4 + uVar5;
  return;
}



/* FUNCTION 14485 ; VA 0x008aaf20 ; FUN_008aaf20 */

void __thiscall FUN_008aaf20(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc940;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::
              _Ref_count<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14486 ; VA 0x008aaf8e ; Catch_All@008aaf8e */

void Catch_All_008aaf8e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_0088df00(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14487 ; VA 0x008aafb0 ; FUN_008aafb0 */

void __thiscall FUN_008aafb0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc950;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::IAdornableCollector>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 14488 ; VA 0x008ab01e ; Catch_All@008ab01e */

void Catch_All_008ab01e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_008afc10(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14489 ; VA 0x008ab040 ; FUN_008ab040 */

int __thiscall FUN_008ab040(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc960;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::AdvArrowTool*,class_RBX::Creatable<class_RBX::MouseCommand>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0x20) == 0 || (*(int *)(*(int *)(param_2 + 0x20) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 0x1c) = param_2;
    piVar3 = *(int **)(param_2 + 0x20);
    *(int **)(param_2 + 0x20) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14490 ; VA 0x008ab112 ; Catch_All@008ab112 */

void Catch_All_008ab112(void)

{
  int unaff_EBP;
  
  FUN_008af4d0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14491 ; VA 0x008ab130 ; FUN_008ab130 */

int __thiscall FUN_008ab130(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc970;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Camera*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14492 ; VA 0x008ab202 ; Catch_All@008ab202 */

void Catch_All_008ab202(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14493 ; VA 0x008ab220 ; FUN_008ab220 */

int __thiscall FUN_008ab220(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc980;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::InputObject*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14494 ; VA 0x008ab2f2 ; Catch_All@008ab2f2 */

void Catch_All_008ab2f2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14495 ; VA 0x008ab310 ; FUN_008ab310 */

int __thiscall FUN_008ab310(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc990;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::MegaClusterInstance*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14496 ; VA 0x008ab3e2 ; Catch_All@008ab3e2 */

void Catch_All_008ab3e2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14497 ; VA 0x008ab400 ; FUN_008ab400 */

int __thiscall FUN_008ab400(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc9a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::NewNullTool*,class_RBX::Creatable<class_RBX::MouseCommand>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0x20) == 0 || (*(int *)(*(int *)(param_2 + 0x20) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 0x1c) = param_2;
    piVar3 = *(int **)(param_2 + 0x20);
    *(int **)(param_2 + 0x20) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 14498 ; VA 0x008ab4d2 ; Catch_All@008ab4d2 */

void Catch_All_008ab4d2(void)

{
  int unaff_EBP;
  
  FUN_008af4d0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 14499 ; VA 0x008ab4f0 ; FUN_008ab4f0 */

int __thiscall FUN_008ab4f0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc9b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::WorkspaceStatsItem*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}


