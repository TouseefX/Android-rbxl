/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 9250 ; VA 0x006d3910 ; FUN_006d3910 */

int __thiscall FUN_006d3910(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x148);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x140);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x138);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 300);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x150);
  }
  return param_1;
}



/* FUNCTION 9251 ; VA 0x006d39e0 ; FUN_006d39e0 */

int __thiscall FUN_006d39e0(int param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 300);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x138);
  }
  return param_1;
}



/* FUNCTION 9252 ; VA 0x006d3a30 ; FUN_006d3a30 */

undefined4 * __thiscall FUN_006d3a30(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Instance::ICombinedSignalData::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  return param_1;
}



/* FUNCTION 9253 ; VA 0x006d3a60 ; FUN_006d3a60 */

undefined4 * __thiscall FUN_006d3a60(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  *param_1 = RBX::Network::SharedChangeAttributeItem::vftable;
  piVar2 = (int *)param_1[0x11];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = param_1[0xf];
  if (0xf < uVar3) {
    iVar4 = param_1[10];
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[0xe] = 0;
  param_1[0xf] = 0xf;
  *(undefined *)(param_1 + 10) = 0;
  FUN_006cd9d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 9254 ; VA 0x006d3b00 ; FUN_006d3b00 */

undefined4 * __thiscall FUN_006d3b00(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *param_1 = RBX::Network::SharedChangePropertyItem::vftable;
  piVar2 = (int *)param_1[0xd];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_006cd9d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x38);
  }
  return param_1;
}



/* FUNCTION 9255 ; VA 0x006d3b60 ; FUN_006d3b60 */

undefined4 * __thiscall FUN_006d3b60(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Network::SharedDeleteInstanceItem::vftable;
  FUN_006d1810();
  FUN_006cd9d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 9256 ; VA 0x006d3ba0 ; FUN_006d3ba0 */

undefined4 * __thiscall FUN_006d3ba0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Network::SharedEventInvocationItem::vftable;
  uStack_8 = 0;
  FUN_00577b20();
  piVar2 = (int *)param_1[0xb];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_006cd9d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9257 ; VA 0x006d3c30 ; FUN_006d3c30 */

undefined4 * __thiscall FUN_006d3c30(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *param_1 = RBX::Network::SharedNewInstanceItem::vftable;
  piVar2 = (int *)param_1[0x10];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0xc];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_006cd9d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 9258 ; VA 0x006d3cb0 ; FUN_006d3cb0 */

void FUN_006d3cb0(void)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(0x24);
  *(int *)iVar1 = iVar1;
  *(int *)(iVar1 + 4) = iVar1;
  *(int *)(iVar1 + 8) = iVar1;
  *(undefined2 *)(iVar1 + 0xc) = 0x101;
  return;
}



/* FUNCTION 9259 ; VA 0x006d3cd0 ; FUN_006d3cd0 */

void FUN_006d3cd0(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_01674e20(0x18);
  if (param_1 == 0) {
    *piVar1 = (int)piVar1;
    piVar1[1] = (int)piVar1;
    return;
  }
  *piVar1 = param_1;
  piVar1[1] = param_2;
  return;
}



/* FUNCTION 9260 ; VA 0x006d3d00 ; FUN_006d3d00 */

void __fastcall FUN_006d3d00(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x24);
  *puVar1 = *param_1;
  puVar1[1] = *param_1;
  puVar1[2] = *param_1;
  return;
}



/* FUNCTION 9261 ; VA 0x006d3d20 ; FUN_006d3d20 */

void __thiscall FUN_006d3d20(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (*param_1 != 0) {
    FUN_006ce110(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar3 = param_1[2] - iVar1 & 0xffffffe0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  *param_1 = param_2;
  param_1[1] = param_3 * 0x20 + param_2;
  param_1[2] = param_4 * 0x20 + param_2;
  return;
}



/* FUNCTION 9262 ; VA 0x006d3d90 ; FUN_006d3d90 */

void __thiscall FUN_006d3d90(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_6c319e5b132248b503a755bba19ab1fb>,bool,class_std::shared_ptr<class_RBX::Instance>_>
             ::vftable;
  *(undefined8 *)(param_2 + 1) = *(undefined8 *)(param_1 + 4);
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  return;
}



/* FUNCTION 9263 ; VA 0x006d3db0 ; FUN_006d3db0 */

void __thiscall FUN_006d3db0(undefined4 param_1,char param_2)

{
  if (param_2 != '\0') {
    FUN_01674ea0(param_1,0x10);
  }
  return;
}



/* FUNCTION 9264 ; VA 0x006d3dd0 ; FUN_006d3dd0 */

void __fastcall FUN_006d3dd0(int param_1)

{
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_006d37b0(1);
  }
  return;
}



/* FUNCTION 9265 ; VA 0x006d3de0 ; FUN_006d3de0 */

void FUN_006d3de0(void)

{
  FUN_006d37b0(0);
  return;
}



/* FUNCTION 9266 ; VA 0x006d3df0 ; FUN_006d3df0 */

void __thiscall FUN_006d3df0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_006ce0c0(param_2,param_3,param_1);
  return;
}



/* FUNCTION 9267 ; VA 0x006d3e10 ; FUN_006d3e10 */

void __thiscall FUN_006d3e10(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_006ce110(param_2,param_3,param_1);
  return;
}



/* FUNCTION 9268 ; VA 0x006d3e30 ; FUN_006d3e30 */

void FUN_006d3e30(undefined4 param_1)

{
  FUN_0061ac80();
  FUN_01674ea0(param_1,0x30);
  return;
}



/* FUNCTION 9269 ; VA 0x006d3e50 ; FUN_006d3e50 */

void FUN_006d3e50(undefined4 param_1)

{
  thunk_FUN_00617ad0();
  FUN_01674ea0(param_1,0x24);
  return;
}



/* FUNCTION 9270 ; VA 0x006d3e70 ; FUN_006d3e70 */

void __thiscall FUN_006d3e70(int param_1,undefined4 param_2)

{
  FUN_006cdf40(param_1 + 4,param_2);
  return;
}



/* FUNCTION 9271 ; VA 0x006d3e90 ; FUN_006d3e90 */

void FUN_006d3e90(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_006d3e90(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_0061ac80();
    FUN_01674ea0(param_1,0x30);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 9272 ; VA 0x006d3ee0 ; FUN_006d3ee0 */

void FUN_006d3ee0(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_006d3ee0(param_1[2]);
    piVar2 = (int *)*param_1;
    thunk_FUN_00617ad0();
    FUN_01674ea0(param_1,0x24);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 9273 ; VA 0x006d3f30 ; FUN_006d3f30 */

TypeDescriptor * FUN_006d3f30(void)

{
  return &<lambda_6c319e5b132248b503a755bba19ab1fb>::RTTI_Type_Descriptor;
}



/* FUNCTION 9274 ; VA 0x006d3f40 ; FUN_006d3f40 */

void __fastcall FUN_006d3f40(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  
  iVar5 = *param_1;
  if (iVar5 != 0) {
    iVar6 = param_1[1];
    if (iVar5 != iVar6) {
      piVar4 = (int *)(iVar5 + 0x2c);
      do {
        iVar1 = piVar4[-2];
        if (iVar1 != 0) {
          uVar3 = *piVar4 - iVar1 & 0xfffffff8;
          iVar2 = iVar1;
          if (0xfff < uVar3) {
            iVar2 = *(int *)(iVar1 + -4);
            uVar3 = uVar3 + 0x23;
            if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006d406c;
          }
          FUN_01674ea0(iVar2,uVar3);
          piVar4[-2] = 0;
          piVar4[-1] = 0;
          *piVar4 = 0;
        }
        iVar1 = piVar4[-8];
        if (iVar1 != 0) {
          uVar3 = piVar4[-6] - iVar1 & 0xfffffff8;
          iVar2 = iVar1;
          if (0xfff < uVar3) {
            iVar2 = *(int *)(iVar1 + -4);
            uVar3 = uVar3 + 0x23;
            if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006d406c;
          }
          FUN_01674ea0(iVar2,uVar3);
          piVar4[-8] = 0;
          piVar4[-7] = 0;
          piVar4[-6] = 0;
        }
        iVar5 = iVar5 + 0x3c;
        piVar4 = piVar4 + 0xf;
      } while (iVar5 != iVar6);
      iVar5 = *param_1;
    }
    uVar3 = ((param_1[2] - iVar5) / 0x3c) * 0x3c;
    iVar6 = iVar5;
    if (0xfff < uVar3) {
      iVar6 = *(int *)(iVar5 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar5 - iVar6) - 4U) {
LAB_006d406c:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 9275 ; VA 0x006d4080 ; FUN_006d4080 */

undefined4 * __thiscall FUN_006d4080(undefined4 param_1,int param_2,int param_3,undefined4 *param_4)

{
  void **ppvVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a8848;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  if (param_2 != param_3) {
    do {
      *param_4 = 0;
      FUN_005880d0(param_2);
      param_4 = param_4 + 8;
      param_2 = param_2 + 0x20;
      ppvVar1 = (void **)ExceptionList;
    } while (param_2 != param_3);
  }
  ExceptionList = ppvVar1;
  uStack_8 = 1;
  FUN_006ce110(param_4,param_4,param_1);
  ExceptionList = pvStack_10;
  return param_4;
}



/* FUNCTION 9276 ; VA 0x006d4110 ; FUN_006d4110 */

void __thiscall FUN_006d4110(undefined4 param_1,uint *param_2,uint *param_3,uint *param_4)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  void **ppvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a8848;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  ppvVar4 = &pvStack_10;
  if (param_2 != param_3) {
    do {
      *param_4 = 0;
      uVar1 = *param_2;
      if (uVar1 != 0) {
        *param_4 = uVar1;
        if ((uVar1 & 1) == 0) {
          (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,param_4 + 2,0);
        }
        else {
          uVar1 = param_2[3];
          uVar2 = param_2[4];
          uVar3 = param_2[5];
          param_4[2] = param_2[2];
          param_4[3] = uVar1;
          param_4[4] = uVar2;
          param_4[5] = uVar3;
          uVar1 = param_2[7];
          param_4[6] = param_2[6];
          param_4[7] = uVar1;
        }
      }
      param_4 = param_4 + 8;
      param_2 = param_2 + 8;
      ppvVar4 = (void **)ExceptionList;
    } while (param_2 != param_3);
  }
  ExceptionList = ppvVar4;
  uStack_8 = 1;
  FUN_006ce110(param_4,param_4,param_1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9277 ; VA 0x006d41d0 ; FUN_006d41d0 */

int __thiscall FUN_006d41d0(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8868;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)(param_1 + 0x234);
  iVar6 = *piVar1;
  uVar5 = *(int *)(param_1 + 0x1c0) - *(int *)(param_1 + 0x1bc) >> 2;
  ExceptionList = &pvStack_10;
  if ((uint)((*(int *)(param_1 + 0x238) - iVar6) / 0xc) < uVar5) {
    ExceptionList = &pvStack_10;
    FUN_006cf150(uVar5,piVar1);
    iVar6 = *piVar1;
  }
  iVar6 = iVar6 + param_3 * 0xc;
  puVar3 = (undefined4 *)FUN_0068f9a0(auStack_18,param_2);
  puVar2 = *(undefined4 **)(iVar6 + 4);
  uStack_8 = 0;
  if (*(undefined4 **)(iVar6 + 8) == puVar2) {
    iVar4 = FUN_006ce750(puVar2,puVar3);
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 0;
    *puVar2 = *puVar3;
    iVar4 = puVar3[1];
    puVar2[1] = iVar4;
    *puVar3 = 0;
    puVar3[1] = 0;
    *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 8;
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 2;
    iVar6 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      iVar4 = (**(code **)(*piStack_14 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 9278 ; VA 0x006d42b0 ; FUN_006d42b0 */

void __thiscall FUN_006d42b0(int param_1,int *param_2)

{
  undefined8 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  byte *pbVar4;
  char cVar5;
  int *piVar6;
  int iVar7;
  int *piVar8;
  undefined4 *puVar9;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  uint uStack_3c;
  undefined4 *puStack_38;
  undefined2 uStack_34;
  undefined auStack_30 [4];
  int iStack_2c;
  int iStack_28;
  byte *pbStack_24;
  uint uStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8894;
  pvStack_10 = ExceptionList;
  iStack_2c = param_1 + 0x254;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  piVar6 = (int *)FUN_006d2ac0(*param_2 + 0x18);
  puVar9 = *(undefined4 **)(*(int *)(*param_2 + 0xc) + 0x18);
  puVar2 = *(undefined4 **)(*(int *)(*param_2 + 0xc) + 0x1c);
  piStack_1c = piVar6;
  if (puVar9 != puVar2) {
    piVar8 = (int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    piStack_14 = piVar8;
    do {
      if ((undefined4 *)*puVar9 != &DAT_0211a3d8) {
        uStack_20 = ((undefined4 *)*puVar9)[10];
        if ((*(int *)(*piVar8 + 0x34) < DAT_01ead028) &&
           (FUN_016f3809(&DAT_01ead028), DAT_01ead028 == -1)) {
          uStack_8 = 0;
          DAT_01ead024 = FUN_0086e8f0("Object");
          uStack_8 = 0xffffffff;
          FUN_016f37bf(&DAT_01ead028);
        }
        piVar8 = piStack_14;
        if (((*(int *)(uStack_20 + 4) == DAT_01ead024) &&
            (cVar5 = FUN_00618b80(*(undefined *)(iStack_18 + 0x26c),*puVar9), piVar8 = piStack_14,
            cVar5 != '\0')) &&
           (iVar7 = (**(code **)(*(int *)*puVar9 + 0x44))(*param_2), piVar8 = piStack_14, iVar7 != 0
           )) {
          uStack_48 = *(undefined4 *)(iVar7 + 0x18);
          pbStack_24 = (byte *)(iVar7 + 0x18);
          uStack_44 = *(undefined4 *)(iVar7 + 0x1c);
          uStack_40 = *puVar9;
          puVar3 = (undefined4 *)piVar6[1];
          uStack_20 = uStack_40;
          if ((undefined4 *)piVar6[2] == puVar3) {
            FUN_006ce3a0(puVar3,&uStack_48);
          }
          else {
            *puVar3 = uStack_48;
            puVar3[1] = uStack_44;
            puVar3[2] = uStack_40;
            piVar6[1] = piVar6[1] + 0xc;
          }
          pbStack_24 = (byte *)FUN_006d2a20(pbStack_24);
          puStack_38 = (undefined4 *)0x0;
          iVar7 = *param_2;
          uStack_3c = -(uint)(pbStack_24 != (byte *)0xfffffffd) & (uint)(pbStack_24 + 4);
          uStack_8 = 1;
          uStack_34 = 0;
          puStack_38 = (undefined4 *)FUN_01674e20(0x14);
          uStack_34 = 0x101;
          puVar1 = (undefined8 *)(puStack_38 + 2);
          *puStack_38 = 0;
          puStack_38[1] = 0;
          *puVar1 = 0;
          puStack_38[4] = 0;
          *(undefined4 *)puVar1 = *(undefined4 *)(iVar7 + 0x18);
          puStack_38[3] = *(undefined4 *)(iVar7 + 0x1c);
          puStack_38[4] = *puVar9;
          iVar7 = FUN_009c91f0(puVar1);
          pbVar4 = pbStack_24;
          uStack_20 = iVar7 + 0x9e3779b9;
          uStack_20 = ((uint)puStack_38[4] >> 3) + uStack_20 * 0x40 + puStack_38[4] +
                      (uStack_20 >> 2) + 0x9e3779b9 ^ uStack_20;
          FUN_006d0350(&iStack_28,uStack_20,puStack_38 + 2,
                       -(uint)(pbStack_24 + *pbStack_24 + 1 != (byte *)0x0) &
                       (uint)(pbStack_24 + *pbStack_24 + 1 + 1));
          if (iStack_28 == 0) {
            FUN_0062b610(*(int *)(pbVar4 + 8) + 1);
            FUN_005c5550(auStack_30,&uStack_3c,uStack_20);
          }
          uStack_8 = 0xffffffff;
          piVar8 = piStack_14;
          piVar6 = piStack_1c;
          if (puStack_38 != (undefined4 *)0x0) {
            FUN_01674ea0(puStack_38,0x14);
            piVar8 = piStack_14;
            piVar6 = piStack_1c;
          }
        }
      }
      puVar9 = puVar9 + 1;
    } while (puVar9 != puVar2);
  }
  iVar7 = piVar6[1] - *piVar6 >> 0x1f;
  if ((piVar6[1] - *piVar6) / 0xc + iVar7 == iVar7) {
    FUN_006d80e0(*param_2 + 0x18);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9279 ; VA 0x006d4570 ; FUN_006d4570 */

int * FUN_006d4570(undefined4 param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar3 = param_4;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a88b0;
  pvStack_10 = ExceptionList;
  uStack_24 = param_1;
  piVar5 = (int *)(param_4 + 0x191c);
  uStack_1c = param_2;
  piStack_18 = param_3;
  puVar4 = *(undefined4 **)(param_4 + 0x1920);
  if (*(undefined4 **)(param_4 + 0x1924) == puVar4) {
    ExceptionList = &pvStack_10;
    FUN_006038a0(puVar4,&uStack_24);
  }
  else {
    ExceptionList = &pvStack_10;
    *puVar4 = param_1;
    puVar4[1] = uStack_20;
    puVar4[2] = param_2;
    puVar4[3] = param_3;
    *(int *)(param_4 + 0x1920) = *(int *)(param_4 + 0x1920) + 0x10;
  }
  piStack_14 = (int *)(*(int *)(iVar3 + 0x1920) - *piVar5 >> 4);
  if (piStack_14 == (int *)0x1) {
    puVar4 = (undefined4 *)FUN_0060dcd0(&param_2,iVar3);
    piVar2 = param_3;
    piVar5 = (int *)puVar4[1];
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar5[2] = piVar5[2] + 1;
      UNLOCK();
      piVar5 = (int *)puVar4[1];
    }
    param_4 = *puVar4;
    uStack_8 = 0;
    uStack_1c = param_4;
    piStack_18 = piVar5;
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar3 = param_3[1] + -1;
      param_3[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_3)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piVar5 + 2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    param_2 = param_4;
    param_3 = piVar5;
    if (piStack_14[0x8c] == piStack_14[0x8b]) {
      piStack_14 = (int *)FUN_006ce4f0(piStack_14[0x8b],&param_2);
      if (param_3 != (int *)0x0) {
        LOCK();
        piVar2 = param_3 + 2;
        iVar3 = *piVar2;
        piStack_14 = (int *)*piVar2;
        *piVar2 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          piStack_14 = (int *)(**(code **)(*param_3 + 4))();
        }
      }
    }
    else {
      if (piVar5 != (int *)0x0) {
        LOCK();
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      FUN_006cdca0(param_4,piVar5,0);
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar3 = piVar5[2] + -1;
        piVar5[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
      piStack_14[0x8b] = piStack_14[0x8b] + 0x20;
    }
    if (piVar5 != (int *)0x0) {
      piStack_14 = piVar5 + 2;
      LOCK();
      iVar3 = *piStack_14;
      *piStack_14 = *piStack_14 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        piStack_14 = (int *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piStack_14;
}



/* FUNCTION 9280 ; VA 0x006d4700 ; FUN_006d4700 */

void __thiscall FUN_006d4700(uint param_1,undefined4 *param_2,int param_3,undefined4 *param_4)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  char cVar6;
  uint uVar7;
  uint *puVar8;
  uint uVar9;
  uint uVar10;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 *puStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8901;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uVar2 = *(uint *)(param_3 + 4);
  iVar3 = *(int *)((int)param_4 + 0x1c);
  uStack_1c = *(uint *)(iVar3 + 0xc);
  if (uStack_1c == *(uint *)(iVar3 + 0x10)) {
    puVar8 = (uint *)0x0;
  }
  else if (uVar2 == *(uint *)(iVar3 + 0x1c)) {
    puVar8 = (uint *)0x0;
  }
  else {
    uVar10 = ((int)(*(uint *)(iVar3 + 0x10) - uStack_1c) >> 3) - 1;
    uVar7 = (uVar2 >> 3) + uVar2;
    uVar9 = 0;
    do {
      uVar7 = uVar7 & uVar10;
      puVar8 = (uint *)(uStack_1c + uVar7 * 8);
      if (*puVar8 == uVar2) goto LAB_006d4792;
      if (*puVar8 == *(uint *)(*(int *)((int)param_4 + 0x1c) + 0x1c)) break;
      uVar7 = uVar7 + 1 + uVar9;
      uVar9 = uVar9 + 1;
    } while (uVar9 <= uVar10);
    puVar8 = (uint *)0x0;
  }
LAB_006d4792:
  uVar10 = (uint)*(ushort *)(-(uint)(puVar8 != (uint *)0x0) & (uint)(puVar8 + 1));
  if (uVar10 < (uint)((*(int *)(param_1 + 0x130) - *(int *)(param_1 + 300)) / 0x14)) {
    param_3 = *(int *)(param_1 + 300) + uVar10 * 0x14;
  }
  else {
    param_3 = 0;
  }
  ExceptionList = &pvStack_10;
  uStack_18 = param_1;
  cVar6 = FUN_00620ff0(uVar2);
  if (cVar6 == '\0') {
    if (DAT_01eaf007 != '\0') {
      FUN_01677520(DAT_01eaf007,"Adding propertyChange for %zu peers with nextCommonId=%llu",
                   param_2[3],*(undefined4 *)(param_1 + 0x1f8),*(undefined4 *)(param_1 + 0x1fc));
    }
    puStack_20 = (undefined4 *)FUN_01674e20(0x38);
    if (puStack_20 == (undefined4 *)0x0) {
      param_4 = (undefined4 *)0x0;
    }
    else {
      uStack_1c = *(uint *)(param_1 + 0x1f8);
      uStack_18 = *(uint *)(param_1 + 0x1fc);
      *(uint *)(param_1 + 0x1f8) = uStack_1c + 1;
      *(uint *)(param_1 + 0x1fc) = uStack_18 + (0xfffffffe < uStack_1c);
      piStack_24 = *(int **)((int)param_4 + 8);
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piStack_24[1] = piStack_24[1] + 1;
        UNLOCK();
        piStack_24 = *(int **)((int)param_4 + 8);
      }
      uStack_28 = *(undefined4 *)((int)param_4 + 4);
      uStack_14 = 2;
      *puStack_20 = RBX::Network::SharedQueueItem::vftable;
      puStack_20[2] = 0;
      puStack_20[3] = 0;
      puStack_20[4] = 0;
      puStack_20[2] = *param_2;
      puStack_20[3] = param_2[1];
      puStack_20[4] = param_2[2];
      *param_2 = 0;
      param_2[1] = 0;
      param_2[2] = 0;
      puStack_20[5] = param_2[3];
      puStack_20[6] = param_2[4];
      puStack_20[8] = uStack_1c;
      puStack_20[9] = uStack_18;
      *puStack_20 = RBX::Network::SharedChangePropertyItem::vftable;
      puStack_20[10] = uVar2;
      puStack_20[0xb] = param_3;
      uStack_8 = 3;
      puStack_20[0xc] = 0;
      puStack_20[0xd] = 0;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piStack_24[1] = piStack_24[1] + 1;
        UNLOCK();
      }
      puStack_20[0xc] = uStack_28;
      puStack_20[0xd] = piStack_24;
      param_4 = puStack_20;
    }
    piVar5 = piStack_24;
    puVar4 = *(undefined4 **)(param_1 + 0x1ec);
    if (*(undefined4 **)(param_1 + 0x1f0) == puVar4) {
      FUN_006030d0(puVar4,&param_4);
    }
    else {
      *puVar4 = param_4;
      *(int *)(param_1 + 0x1ec) = *(int *)(param_1 + 0x1ec) + 4;
    }
    uVar2 = uStack_14 & 2;
  }
  else {
    if (DAT_01eaf007 != '\0') {
      FUN_01677520(DAT_01eaf007,"Adding refPropertyChange for %zu peers with nextCommonId=%llu",
                   param_2[3],*(undefined4 *)(param_1 + 0x1f8),*(undefined4 *)(param_1 + 0x1fc));
    }
    puStack_20 = (undefined4 *)FUN_01674e20(0x40);
    if (puStack_20 == (undefined4 *)0x0) {
      param_4 = (undefined4 *)0x0;
    }
    else {
      uStack_18 = *(uint *)(param_1 + 0x1f8);
      uStack_1c = *(uint *)(param_1 + 0x1fc);
      *(uint *)(param_1 + 0x1f8) = uStack_18 + 1;
      *(uint *)(param_1 + 0x1fc) = uStack_1c + (0xfffffffe < uStack_18);
      piStack_24 = *(int **)((int)param_4 + 8);
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piStack_24[1] = piStack_24[1] + 1;
        UNLOCK();
        piStack_24 = *(int **)((int)param_4 + 8);
      }
      uStack_28 = *(undefined4 *)((int)param_4 + 4);
      uStack_8 = 1;
      uStack_14 = 1;
      param_4 = (undefined4 *)FUN_006cd8a0(uVar2,param_3,&uStack_28,param_2,uStack_18,uStack_1c);
    }
    puVar4 = *(undefined4 **)(param_1 + 0x1ec);
    uStack_8 = 2;
    if (*(undefined4 **)(param_1 + 0x1f0) == puVar4) {
      FUN_006030d0(puVar4,&param_4);
    }
    else {
      *puVar4 = param_4;
      *(int *)(param_1 + 0x1ec) = *(int *)(param_1 + 0x1ec) + 4;
    }
    uVar2 = uStack_14 & 1;
    piVar5 = piStack_24;
  }
  uStack_8 = 0xffffffff;
  if ((uVar2 != 0) && (uStack_8 = 0xffffffff, piVar5 != (int *)0x0)) {
    LOCK();
    iVar3 = piVar5[1] + -1;
    piVar5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  if ((*(uint *)(param_1 + 0x1f8) & *(uint *)(param_1 + 0x1fc)) == 0xffffffff) {
    FUN_01675310("CommonId exceeded limit",&DAT_018bc9b8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9281 ; VA 0x006d4ab0 ; FUN_006d4ab0 */

void __thiscall
FUN_006d4ab0(byte *param_1,undefined4 param_2,undefined4 param_3,uint *param_4,undefined param_5,
            undefined param_6,undefined4 param_7,undefined4 param_8,char param_9)

{
  int iVar1;
  byte bVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  uint uVar8;
  uint uVar9;
  int *piVar10;
  int *piVar11;
  int *piVar12;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  uint uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8949;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  piVar10 = (int *)*param_4;
  ExceptionList = &pvStack_10;
  piStack_18 = piVar10;
  pbStack_14 = param_1;
  FUN_00606ea0(&piStack_1c,((uint)piVar10 >> 3) + (int)piVar10,&piStack_18,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (piStack_1c == (int *)0x0) {
    piStack_1c = piVar10;
    iVar5 = FUN_006d2d20(&piStack_1c);
    piVar10 = (int *)(iVar5 + 4);
    piStack_18 = (int *)(*param_4 + 0x50);
    uStack_8 = 0;
    piStack_1c = piVar10;
    uVar6 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 1;
    uStack_24 = uVar6;
    piStack_28 = (int *)FUN_01674e20(0x20);
    if (piStack_28 == (int *)0x0) {
      piVar11 = (int *)0x0;
    }
    else {
      *piStack_28 = 0;
      piStack_28[1] = 1;
      piStack_28[2] = (int)FUN_006d7a50;
      piStack_28[3] = (int)_guard_check_icall;
      piStack_28[4] = 0;
      piStack_28[5] = (int)piStack_18;
      piStack_28[6] = (int)pbStack_14;
      piStack_28[7] = (int)piVar10;
      piVar11 = piStack_28;
    }
    FUN_016797d0(piVar11);
    if (piVar11 != (int *)0x0) {
      LOCK();
      piVar11[1] = piVar11[1] + 1;
      UNLOCK();
    }
    uStack_20 = 1;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    piStack_28 = piVar11;
    FUN_01675290(uVar6);
    iVar3 = *piVar10;
    *piVar10 = (int)piVar11;
    uStack_8 = 0xffffffff;
    if (iVar3 != 0) {
      piVar11 = (int *)(iVar3 + 4);
      LOCK();
      iVar1 = *piVar11;
      *piVar11 = *piVar11 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        FUN_01674ea0(iVar3);
      }
    }
    FUN_0056ecd0(param_4);
    if (pbStack_14[0x18] != 0) {
      uStack_20 = 0;
      uVar6 = FUN_006d03f0(&uStack_2c,&uStack_20);
      FUN_005587e0(uVar6);
      piVar11 = piStack_28;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_28[1] + -1;
        piStack_28[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          piVar4 = piVar11 + 2;
          iVar3 = *piVar4 + -1;
          *piVar4 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar11 + 4))();
          }
        }
      }
      uStack_20 = 1;
      uVar6 = FUN_006d03f0(&uStack_2c,&uStack_20);
      FUN_005587e0(uVar6);
      piVar11 = piStack_28;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_28[1] + -1;
        piStack_28[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          piVar4 = piVar11 + 2;
          iVar3 = *piVar4 + -1;
          *piVar4 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar11 + 4))();
          }
        }
      }
    }
    *(undefined4 *)(iVar5 + 0x20) = param_3;
    *(undefined *)(iVar5 + 0x35) = param_5;
    *(undefined4 *)(iVar5 + 0x30) = 0;
    *(undefined *)(iVar5 + 0x36) = param_6;
    if ((DAT_01d5b840 != '\0') && (param_9 != '\0')) {
      *(char *)(iVar5 + 0x37) = param_9;
    }
    if ((DAT_01d5b278 != '\0') && (*(int *)(pbStack_14 + 0x1c) != 0)) {
      uVar8 = *param_4;
      piVar4 = *(int **)(uVar8 + 0x2c);
      piVar11 = (int *)(uVar8 + 0x2c);
      if (piVar4 == (int *)0x0) {
        *(uint *)(uVar8 + 0x40) = *(uint *)(uVar8 + 0x40) & 0xff000000;
        *(undefined4 *)(*param_4 + 0x38) = 0;
      }
      else {
        piVar12 = (int *)*piVar4;
        uVar9 = 0;
        piVar4 = (int *)piVar4[1];
        _param_5 = 0;
        if (piVar12 != piVar4) {
          do {
            if (DAT_01eaf004 != '\0') {
              piVar10 = *(int **)(*piVar12 + 0x28);
              bVar2 = *(byte *)(*(int *)(*piVar12 + 0xc) + 0x1d4);
              if (0xf < (uint)piVar10[5]) {
                piVar10 = (int *)*piVar10;
              }
              puVar7 = (undefined4 *)FUN_009c9510(auStack_44);
              uStack_8 = 3;
              if (0xf < (uint)puVar7[5]) {
                puVar7 = (undefined4 *)*puVar7;
              }
              FUN_01677520(DAT_01eaf004,"   child %s(%s) replicates=%d",puVar7,piVar10,
                           (bVar2 & 3) != 0);
              uStack_8 = 0xffffffff;
              if (0xf < uStack_30) {
                uVar9 = uStack_30 + 1;
                uVar8 = auStack_44[0];
                if (0xfff < uVar9) {
                  uVar8 = *(uint *)(auStack_44[0] - 4);
                  uVar9 = uStack_30 + 0x24;
                  if (0x1f < (auStack_44[0] - uVar8) - 4) goto LAB_006d4f37;
                }
                FUN_01674ea0(uVar8,uVar9);
              }
              uStack_34 = 0;
              uStack_30 = 0xf;
              auStack_44[0] = auStack_44[0] & 0xffffff00;
            }
            uVar9 = _param_5 + 1;
            if ((*(byte *)(*(int *)(*piVar12 + 0xc) + 0x1d4) & 3) == 0) {
              uVar9 = _param_5;
            }
            piVar12 = piVar12 + 2;
            _param_5 = uVar9;
          } while (piVar12 != piVar4);
          uVar8 = *param_4;
          piVar10 = piStack_1c;
        }
        *(uint *)(uVar8 + 0x40) =
             *(uint *)(uVar8 + 0x40) ^ (*(uint *)(uVar8 + 0x40) ^ uVar9) & 0xffffff;
        *(uint *)(*param_4 + 0x38) = *(uint *)(uVar8 + 0x40) & 0xffffff;
      }
      if (DAT_01eaf004 != '\0') {
        piVar11 = (int *)*piVar11;
        if (piVar11 == (int *)0x0) {
          iVar5 = 0;
        }
        else {
          iVar5 = piVar11[1] - *piVar11 >> 3;
        }
        piVar11 = *(int **)(*param_4 + 0x28);
        uVar6 = *(undefined4 *)(*param_4 + 0x38);
        if (0xf < (uint)piVar11[5]) {
          piVar11 = (int *)*piVar11;
        }
        puVar7 = (undefined4 *)FUN_009c9510(auStack_44);
        uStack_8 = 4;
        if (0xf < (uint)puVar7[5]) {
          puVar7 = (undefined4 *)*puVar7;
        }
        FUN_01677520(DAT_01eaf004,"%s(%s) computed local replicated %d out of %d",puVar7,piVar11,
                     uVar6,iVar5);
        uStack_8 = 0xffffffff;
        if (0xf < uStack_30) {
          uVar9 = uStack_30 + 1;
          uVar8 = auStack_44[0];
          if (0xfff < uVar9) {
            uVar8 = *(uint *)(auStack_44[0] - 4);
            uVar9 = uStack_30 + 0x24;
            if (0x1f < (auStack_44[0] - uVar8) - 4) {
LAB_006d4f37:
              uStack_8 = 0xffffffff;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar8,uVar9);
        }
      }
    }
    piVar11 = (int *)param_4[1];
    if (piVar11 != (int *)0x0) {
      LOCK();
      piVar11[1] = piVar11[1] + 1;
      UNLOCK();
      piVar11 = (int *)param_4[1];
    }
    uStack_2c = *param_4;
    uStack_8 = 5;
    piStack_28 = piVar11;
    FUN_006d42b0(&uStack_2c);
    uStack_8 = 0xffffffff;
    if (piVar11 != (int *)0x0) {
      LOCK();
      iVar5 = piVar11[1] + -1;
      piVar11[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar11)();
        LOCK();
        iVar5 = piVar11[2] + -1;
        piVar11[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar11 + 4))();
        }
      }
    }
  }
  else {
    piVar10 = piStack_1c + 3;
  }
  FUN_006d9390(piVar10,param_2,param_4,param_7,param_8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9282 ; VA 0x006d4f40 ; FUN_006d4f40 */

int FUN_006d4f40(int *param_1,uint param_2,int *param_3,undefined4 *param_4,int *param_5,
                int *param_6)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  ushort *puVar8;
  undefined4 *puVar9;
  uint uVar10;
  uint uVar11;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a897f;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar6 = (**(code **)(*param_1 + 0x114))(param_2);
  if ((char)iVar6 != '\0') {
    FUN_006209c0(param_2);
    iVar3 = iStack_18;
    piVar2 = param_6;
    iVar6 = *param_6;
    if (iVar6 == param_6[1]) {
      iVar6 = 0;
    }
    else if (param_2 == param_6[4]) {
      iVar6 = 0;
    }
    else {
      uVar7 = (param_2 >> 3) + param_2;
      uVar11 = (param_6[1] - iVar6 >> 3) - 1;
      uVar10 = 0;
      do {
        uVar7 = uVar7 & uVar11;
        uVar4 = *(uint *)(iVar6 + uVar7 * 8);
        iVar6 = iVar6 + uVar7 * 8;
        if (uVar4 == param_2) goto LAB_006d4fe4;
        if (uVar4 == param_6[4]) break;
        iVar6 = *param_6;
        uVar7 = uVar7 + 1 + uVar10;
        uVar10 = uVar10 + 1;
      } while (uVar10 <= uVar11);
      iVar6 = 0;
    }
LAB_006d4fe4:
    puVar9 = (undefined4 *)(-(uint)(iVar6 != 0) & iVar6 + 4U);
    if (puVar9 == (undefined4 *)0x0) {
      puVar8 = (ushort *)FUN_006193f0(*(undefined4 *)(param_2 + 0xc));
      if ((uint)*puVar8 < (uint)((*(int *)(iVar3 + 0x124) - *(int *)(iVar3 + 0x120)) / 0x3c)) {
        iStack_14 = *(int *)(iVar3 + 0x120) + (uint)*puVar8 * 0x3c;
      }
      else {
        iStack_14 = 0;
      }
      puVar9 = (undefined4 *)FUN_01674e20(0x48);
      if (puVar9 == (undefined4 *)0x0) {
        puVar9 = (undefined4 *)0x0;
        iStack_18 = iVar3;
      }
      else {
        uVar7 = *(uint *)(iVar3 + 0x1f8);
        iVar6 = *(int *)(iVar3 + 0x1fc);
        *(uint *)(iVar3 + 0x1f8) = uVar7 + 1;
        *(uint *)(iVar3 + 0x1fc) = iVar6 + (uint)(0xfffffffe < uVar7);
        if (param_3 != (int *)0x0) {
          LOCK();
          param_3[1] = param_3[1] + 1;
          UNLOCK();
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        uStack_1c = 0;
        FUN_0060e810(0,&uStack_1c,(int)&param_6 + 3);
        puVar9[2] = uStack_4c;
        puVar9[3] = uStack_48;
        puVar9[4] = uStack_44;
        puVar9[5] = 0;
        puVar9[6] = 0;
        puVar9[8] = uVar7;
        puVar9[9] = iVar6;
        *puVar9 = RBX::Network::SharedNewInstanceItem::vftable;
        puVar9[10] = iStack_14;
        puVar9[0xb] = 0;
        puVar9[0xc] = 0;
        if (param_3 != (int *)0x0) {
          LOCK();
          param_3[1] = param_3[1] + 1;
          UNLOCK();
        }
        puVar9[0xb] = param_2;
        puVar9[0xc] = param_3;
        iVar6 = *(int *)(param_2 + 0x34);
        puVar9[0xd] = *(undefined4 *)(iVar6 + 0x18);
        puVar9[0xe] = *(undefined4 *)(iVar6 + 0x1c);
        puVar9[0xf] = 0;
        puVar9[0x10] = 0;
        if (param_4[1] != 0) {
          LOCK();
          piVar1 = (int *)(param_4[1] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        puVar9[0xf] = *param_4;
        puVar9[0x10] = param_4[1];
        *(undefined *)(puVar9 + 0x11) = param_5._0_1_;
        if (param_3 != (int *)0x0) {
          LOCK();
          iVar6 = param_3[1] + -1;
          param_3[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*param_3)();
            LOCK();
            iVar6 = param_3[2] + -1;
            param_3[2] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*param_3 + 4))();
            }
          }
        }
      }
      puVar5 = *(undefined4 **)(iStack_18 + 0x1ec);
      uStack_8 = uStack_8 & 0xffffff00;
      if (*(undefined4 **)(iStack_18 + 0x1f0) == puVar5) {
        param_5 = puVar9;
        FUN_006030d0(puVar5,&param_5);
      }
      else {
        *puVar5 = puVar9;
        *(int *)(iStack_18 + 0x1ec) = *(int *)(iStack_18 + 0x1ec) + 4;
      }
      param_5 = (int *)param_2;
      if ((uint)((piVar2[1] - *piVar2 >> 3) * 3) >> 2 <= (uint)piVar2[3]) {
        FUN_006ddc30();
      }
      iVar6 = FUN_00620bc0(&param_5);
      *(undefined4 **)(iVar6 + 4) = puVar9;
    }
    else {
      puVar9 = (undefined4 *)*puVar9;
    }
    param_5 = param_1;
    if ((uint)(((int)(puVar9[3] - puVar9[2]) >> 2) * 3) >> 2 <= (uint)puVar9[5]) {
      FUN_006286d0();
    }
    iVar6 = FUN_00620c30(&param_5);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar3 = *piVar2;
    iVar6 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar6 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 9283 ; VA 0x006d5250 ; FUN_006d5250 */

void FUN_006d5250(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
                 undefined4 param_5,undefined4 param_6,uint param_7)

{
  undefined8 uStack_40;
  undefined4 uStack_38;
  uint uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017a8998;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined4 *)param_7;
  uStack_1c = param_6;
  uStack_20 = param_5;
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_34 = param_4;
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  if ((param_4 & 0xfffffff8) != 0) {
    if (((int)param_4 >> 1 & 1U) == 0) {
      uStack_40 = CONCAT44(param_2,param_1);
      uStack_38 = param_3;
      ExceptionList = &pvStack_10;
    }
    else if ((~(byte)((int)param_4 >> 2) & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)((param_4 & 0xfffffff8) + 4))(&uStack_40,&param_1);
    }
    else {
      uStack_40 = CONCAT44(param_2,param_1);
      uStack_38 = param_3;
      ExceptionList = &pvStack_10;
    }
    param_4 = 0;
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_01539550();
  iStack_8 = 2;
  if ((param_4 & 0xfffffff8) != 0) {
    param_7 = CONCAT31((int3)((int)param_4 >> 9),(char)((int)param_4 >> 1)) & 0xffffff01;
    if ((~(byte)((int)param_4 >> 2) & 1) == 0) {
      puStack_18 = &param_1;
      if ((char)param_7 == '\0') {
        puStack_18 = param_1;
      }
      uStack_1c = 0x6d5343;
      (**(code **)((param_4 & 0xfffffff8) + 8))();
    }
    if ((char)param_7 == '\0') {
      puStack_18 = param_1;
      uStack_1c = 0x6d5355;
      FUN_01674ee0();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9284 ; VA 0x006d5370 ; FUN_006d5370 */

void __thiscall
FUN_006d5370(byte *param_1,uint *param_2,uint param_3,undefined4 param_4,uint *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  ushort *puVar8;
  uint *puVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint *puStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  byte *pbStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a89e2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pbStack_18 = param_1;
  uVar7 = FUN_01675290(DAT_01eaf02c);
  uStack_8 = 0;
  uStack_28 = uVar7;
  puVar8 = (ushort *)FUN_006193f0(*(undefined4 *)(*param_2 + 0xc));
  if (((puVar8 != (ushort *)0x0) &&
      ((uint)*puVar8 < (uint)((*(int *)(param_1 + 0x124) - *(int *)(param_1 + 0x120)) / 0x3c))) &&
     (iVar2 = *(int *)(param_1 + 0x120) + (uint)*puVar8 * 0x3c, iVar2 != 0)) {
    iVar3 = *(int *)(iVar2 + 0x24);
    if (iVar3 == *(int *)(iVar2 + 0x28)) {
      iVar10 = 0;
    }
    else if (param_3 == *(uint *)(iVar2 + 0x34)) {
      iVar10 = 0;
    }
    else {
      uVar13 = (*(int *)(iVar2 + 0x28) - iVar3 >> 3) - 1;
      uVar12 = (param_3 >> 3) + param_3;
      uVar11 = 0;
      do {
        uVar12 = uVar12 & uVar13;
        uVar4 = *(uint *)(iVar3 + uVar12 * 8);
        iVar10 = iVar3 + uVar12 * 8;
        param_1 = pbStack_18;
        if (uVar4 == param_3) goto LAB_006d5465;
        if (uVar4 == *(uint *)(iVar2 + 0x34)) break;
        uVar12 = uVar12 + 1 + uVar11;
        uVar11 = uVar11 + 1;
      } while (uVar11 <= uVar13);
      iVar10 = 0;
    }
LAB_006d5465:
    puVar8 = (ushort *)(-(uint)(iVar10 != 0) & iVar10 + 4U);
    if ((puVar8 != (ushort *)0x0) &&
       (uVar13 = (uint)*puVar8,
       uVar13 < (uint)((*(int *)(param_1 + 0x13c) - *(int *)(param_1 + 0x138)) / 0x14))) {
      uStack_24 = *(int *)(param_1 + 0x138) + uVar13 * 0x14;
      goto LAB_006d54ae;
    }
  }
  uStack_24 = 0;
LAB_006d54ae:
  uStack_20 = 0;
  FUN_0060e810(0,&uStack_20,&uStack_11);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_20 = *param_2;
  FUN_00606ea0(&uStack_1c,(uStack_20 >> 3) + uStack_20,&uStack_20,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  uVar13 = uStack_1c;
  if (uStack_1c != 0) {
    puVar9 = *(uint **)(param_1 + 0x1bc);
    uStack_20 = 0;
    uVar12 = (uint)((int)*(uint **)(param_1 + 0x1c0) + (3 - (int)puVar9)) >> 2;
    if (*(uint **)(param_1 + 0x1c0) < puVar9) {
      uVar12 = 0;
    }
    puStack_2c = puVar9;
    uStack_1c = uVar12;
    if (uVar12 != 0) {
      do {
        puStack_2c = (uint *)*puVar9;
        if ((puStack_2c != param_5) &&
           (((DAT_01d5b840 != '\0' && (*(char *)(uVar13 + 0x3f) != '\0')) ||
            ((uVar12 = uStack_1c,
             puStack_2c[0x63a] < (uint)((*(int *)(uVar13 + 0x44) - *(int *)(uVar13 + 0x40)) / 0xc)
             && (*(char *)(*(int *)(uVar13 + 0x40) + 8 + puStack_2c[0x63a] * 0xc) != '\0')))))) {
          if ((uint)(((int)(uStack_40 - uStack_44) >> 2) * 3) >> 2 == 0) {
            FUN_006286d0();
          }
          FUN_00620c30(&puStack_2c);
          uVar12 = uStack_1c;
        }
        uStack_20 = uStack_20 + 1;
        puVar9 = puVar9 + 1;
        uVar7 = uStack_28;
      } while (uStack_20 != uVar12);
    }
    puVar9 = (uint *)FUN_01674e20(0x48);
    uVar6 = uStack_28;
    param_5 = puVar9;
    if (puVar9 == (uint *)0x0) {
      puVar9 = (uint *)0x0;
    }
    else {
      uVar13 = *(uint *)(pbStack_18 + 0x1f8);
      uVar12 = *(uint *)(pbStack_18 + 0x1fc);
      *(uint *)(pbStack_18 + 0x1f8) = uVar13 + 1;
      *(uint *)(pbStack_18 + 0x1fc) = uVar12 + (0xfffffffe < uVar13);
      puVar9[2] = uStack_44;
      puVar9[3] = uStack_40;
      puVar9[4] = uStack_3c;
      puVar9[5] = 0;
      puVar9[6] = 0;
      uStack_3c = 0;
      puVar9[8] = uVar13;
      puVar9[9] = uVar12;
      *puVar9 = (uint)RBX::Network::SharedEventInvocationItem::vftable;
      puVar9[10] = 0;
      puVar9[0xb] = 0;
      if (param_2[1] != 0) {
        LOCK();
        piVar1 = (int *)(param_2[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      puVar9[10] = *param_2;
      puVar9[0xb] = param_2[1];
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      puVar9[0xc] = param_3;
      FUN_006d07c0(param_4);
      uStack_44 = 0;
      puVar9[0x10] = uStack_24;
      uVar7 = uVar6;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if ((*(uint *)(pbStack_18 + 0x1f8) & *(uint *)(pbStack_18 + 0x1fc)) == 0xffffffff) {
      FUN_01675310("CommonId exceeded limit",&DAT_018bc9b8);
    }
    puVar5 = *(undefined4 **)(pbStack_18 + 0x1ec);
    param_2 = puVar9;
    if (*(undefined4 **)(pbStack_18 + 0x1f0) == puVar5) {
      FUN_006030d0(puVar5,&param_2);
    }
    else {
      *puVar5 = puVar9;
      *(int *)(pbStack_18 + 0x1ec) = *(int *)(pbStack_18 + 0x1ec) + 4;
    }
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (uStack_44 != 0) {
    uVar13 = ((int)(uStack_3c - uStack_44) >> 2) * 4;
    uVar12 = uStack_44;
    if (0xfff < uVar13) {
      uVar12 = *(uint *)(uStack_44 - 4);
      uVar13 = uVar13 + 0x23;
      if (0x1f < (uStack_44 - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar12,uVar13);
  }
  uStack_8 = 6;
  FUN_01675290(uVar7);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9285 ; VA 0x006d5760 ; FUN_006d5760 */

void __thiscall
FUN_006d5760(byte *param_1,uint param_2,undefined4 param_3,undefined4 param_4,char param_5)

{
  undefined4 *puVar1;
  uint uVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  undefined auStack_44 [24];
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar6 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8a00;
  pvStack_10 = ExceptionList;
  if ((param_2 != 0) &&
     (ExceptionList = &pvStack_10,
     FUN_00606ea0(&uStack_14,(param_2 >> 3) + param_2,&param_2,
                  -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) &
                  (uint)(param_1 + *param_1 + 1 + 1)), uVar2 = uStack_14, uStack_14 != 0)) {
    uStack_14 = uStack_14 & 0xffffff00;
    if ((param_5 == '\0') || (cVar3 = FUN_006de120(uVar6,param_3,param_4), cVar3 == '\0')) {
      if (DAT_01ee420d != '\0') {
        puVar4 = (undefined4 *)FUN_008a2380(auStack_2c);
        uStack_8 = 1;
        if (0xf < (uint)puVar4[5]) {
          puVar4 = (undefined4 *)*puVar4;
        }
        FUN_016774b0(DAT_01ee420d,
                     "adjustSubTreeForJoinCache()::Removing instance MRD for instance %s from BlobCacheMRDMap"
                     ,puVar4);
        uStack_8 = 0xffffffff;
        if (0xf < uStack_18) {
          uVar7 = uStack_18 + 1;
          uVar6 = auStack_2c[0];
          if (0xfff < uVar7) {
            uVar6 = *(uint *)(auStack_2c[0] - 4);
            uVar7 = uStack_18 + 0x24;
            if (0x1f < (auStack_2c[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar6,uVar7);
        }
        uStack_1c = 0;
        uStack_18 = 0xf;
        auStack_2c[0] = auStack_2c[0] & 0xffffff00;
      }
      FUN_006cc9d0(uVar2 + 0xc);
    }
    else {
      if (DAT_01ee420d != '\0') {
        puVar4 = (undefined4 *)FUN_008a2380(auStack_44);
        uStack_8 = 0;
        if (0xf < (uint)puVar4[5]) {
          puVar4 = (undefined4 *)*puVar4;
        }
        FUN_016774b0(DAT_01ee420d,
                     "adjustSubTreeForJoinCache()::Adding instance MRD for instance %s to BlobCacheMRDMap"
                     ,puVar4);
        uStack_8 = 0xffffffff;
        FUN_005507b0();
      }
      uVar5 = FUN_006d9e30(param_2);
      FUN_006c90c0(uVar2 + 0xc,1,1,uVar5);
      uStack_14 = CONCAT31(uStack_14._1_3_,1);
    }
    puVar4 = *(undefined4 **)(*(int *)(uVar2 + 0x10) + 0x2c);
    if (puVar4 != (undefined4 *)0x0) {
      puVar1 = (undefined4 *)puVar4[1];
      for (puVar4 = (undefined4 *)*puVar4; puVar4 != puVar1; puVar4 = puVar4 + 2) {
        FUN_006d5760(*puVar4,param_3,param_4,uStack_14);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9286 ; VA 0x006d5930 ; FUN_006d5930 */

void __thiscall FUN_006d5930(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  undefined8 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8a24;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0x85) != '\0') {
    if (*(int *)(*(int *)(param_2 + 0x1b8) + 0x1b4) != 0) {
      ExceptionList = &pvStack_10;
      cVar3 = FUN_00bbe9d0();
      if (cVar3 == '\0') {
        if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
            DAT_01eaf0b8) {
          FUN_016f3809(&DAT_01eaf0b8);
          if (DAT_01eaf0b8 == -1) {
            uStack_8 = 0;
            uVar4 = FUN_0152dab0(&DAT_018c5904,"Force World Assemble",0xffffffff);
            DAT_01eaf0b4 = (undefined4)((ulonglong)uVar4 >> 0x20);
            DAT_01eaf0b0 = (undefined4)uVar4;
            uStack_8 = 0xffffffff;
            FUN_016f37bf(&DAT_01eaf0b8);
          }
        }
        uVar2 = DAT_01eaf0b4;
        uVar1 = DAT_01eaf0b0;
        uVar4 = FUN_0152d930(DAT_01eaf0b0,DAT_01eaf0b4);
        uStack_8 = 1;
        FUN_00bbbe60();
        uStack_8 = 2;
        FUN_0152dda0(uVar1,uVar2,uVar4);
      }
    }
    *(undefined *)(param_1 + 0x85) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9287 ; VA 0x006d5a60 ; FUN_006d5a60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_006d5a60(int param_1,int param_2)

{
  float fVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  float10 fVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8a38;
  pvStack_10 = ExceptionList;
  fVar1 = *(float *)(param_2 + 0xc);
  puVar7 = *(undefined4 **)(param_1 + 0x14);
  ExceptionList = &pvStack_10;
  *(float *)(param_1 + 0xc) = fVar1;
  if (puVar7 == (undefined4 *)0x0) {
    uVar4 = 0;
  }
  else {
    fVar8 = (float10)FUN_01725160(((double)*(int *)(param_1 + 4) +
                                  (double)(&DAT_018c0d90)[-(*(int *)(param_1 + 4) >> 0x1f)]) *
                                  (double)fVar1);
    if ((double)fVar8 < _DAT_018c4e98) {
      uVar4 = FUN_016f3eb1();
    }
    else {
      uVar4 = 0xffffffff;
    }
  }
  *(uint *)(param_1 + 0x10) = uVar4;
  if ((*(int *)(param_1 + 8) != 0) || (*(int *)(param_2 + 8) != 0)) {
    if (*(uint *)(param_2 + 8) < uVar4) {
      puVar6 = puVar7 + *(int *)(param_1 + 4);
      for (; puVar7 != puVar6; puVar7 = puVar7 + 1) {
        *puVar7 = 0;
      }
    }
    else {
      FUN_005c9310();
      FUN_005d2b00();
    }
    puVar7 = (undefined4 *)0x0;
    if (*(int *)(param_1 + 8) != 0) {
      puVar7 = *(undefined4 **)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      *(undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4) = 0;
      *(undefined4 *)(param_1 + 8) = 0;
    }
    uStack_8 = 0;
    if (*(int *)(param_2 + 8) == 0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6 = *(undefined4 **)(*(int *)(param_2 + 0x14) + *(int *)(param_2 + 4) * 4);
    }
    puVar3 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
    while (puVar6 != (undefined4 *)0x0) {
      if (puVar7 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)FUN_01674e20(0x14);
        *puVar5 = 0;
        puVar5[1] = 0;
        *(undefined8 *)(puVar5 + 2) = 0;
        puVar5[4] = 0;
        *(undefined8 *)(puVar5 + 2) = *(undefined8 *)(puVar6 + 2);
      }
      else {
        puVar2 = (undefined4 *)*puVar7;
        *puVar7 = 0;
        puVar7[2] = puVar6[2];
        puVar7[3] = puVar6[3];
        puVar5 = puVar7;
        puVar7 = puVar2;
      }
      puVar5[4] = puVar6[4];
      puVar5[1] = puVar6[1];
      *puVar3 = puVar5;
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      puVar2 = (undefined4 *)*puVar3;
      puVar6 = (undefined4 *)*puVar6;
      uVar4 = (uint)puVar2[1] % *(uint *)(param_1 + 4);
      puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
      if (*(int *)(*(int *)(param_1 + 0x14) + uVar4 * 4) == 0) {
        *puVar5 = puVar3;
        puVar3 = puVar2;
      }
      else {
        *puVar3 = *puVar2;
        *puVar2 = *(undefined4 *)*puVar5;
        *(undefined4 **)*puVar5 = puVar2;
      }
    }
    while (puVar7 != (undefined4 *)0x0) {
      puVar6 = (undefined4 *)*puVar7;
      FUN_01674ea0(puVar7,0x14);
      puVar7 = puVar6;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9288 ; VA 0x006d5ca0 ; FUN_006d5ca0 */

uint __thiscall FUN_006d5ca0(int param_1,int param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  
  piVar5 = (int *)(param_2 + 0x34);
  uVar4 = *(int *)(param_1 + 0x1c0) - *(int *)(param_1 + 0x1bc) >> 2;
  iVar2 = *(int *)(param_2 + 0x38) - *piVar5;
  uVar1 = iVar2 * 0x2aaaaaab;
  uVar3 = iVar2 / 0xc;
  if (uVar3 < uVar4) {
    FUN_006b2d20(uVar4,piVar5);
    uVar1 = (*(int *)(param_2 + 0x38) - *piVar5) / 0xc;
    if (uVar3 < uVar1) {
      iVar2 = uVar3 * 0xc;
      do {
        uVar3 = uVar3 + 1;
        *(undefined *)(iVar2 + 8 + *piVar5) = 0;
        *(undefined *)(iVar2 + 9 + *piVar5) = 0;
        *(undefined *)(iVar2 + 10 + *piVar5) = 0;
        *(undefined4 *)(iVar2 + *piVar5) = 0;
        *(undefined4 *)(iVar2 + 4 + *piVar5) = 0;
        uVar1 = (*(int *)(param_2 + 0x38) - *piVar5) / 0xc;
        iVar2 = iVar2 + 0xc;
      } while (uVar3 < uVar1);
    }
  }
  return uVar1;
}



/* FUNCTION 9289 ; VA 0x006d5d50 ; FUN_006d5d50 */

void __thiscall
FUN_006d5d50(byte *param_1,uint param_2,int param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 *puVar1;
  uint *puVar2;
  bool bVar3;
  int iVar4;
  char cVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  uint *puVar9;
  
  iVar4 = param_2;
  if ((*(char *)(param_2 + 0x33) != '\0') || (*(char *)(param_3 + 0x33) != '\0')) {
    if ((*(char *)(param_3 + 0x33) == '\0') ||
       (cVar5 = FUN_006de120(*(undefined4 *)(param_2 + 4),param_4,param_5), cVar5 == '\0')) {
      bVar3 = false;
    }
    else {
      bVar3 = true;
    }
    if (*(char *)(iVar4 + 0x33) == '\0') {
      if (bVar3) {
        iVar6 = *(int *)(iVar4 + 0x38) - *(int *)(iVar4 + 0x34);
        iVar8 = iVar6 >> 0x1f;
        if (iVar6 / 0xc + iVar8 != iVar8) {
          uVar7 = 0;
          iVar8 = 0;
          do {
            uVar7 = uVar7 + 1;
            *(undefined *)(iVar8 + 8 + *(int *)(iVar4 + 0x34)) = 0;
            iVar8 = iVar8 + 0xc;
          } while (uVar7 < (uint)((*(int *)(iVar4 + 0x38) - *(int *)(iVar4 + 0x34)) / 0xc));
        }
        *(undefined4 *)(iVar4 + 0x2c) = 0;
        *(undefined *)(iVar4 + 0x33) = 1;
      }
    }
    else if (!bVar3) {
      FUN_006d7ab0(iVar4);
    }
    puVar1 = *(undefined4 **)(*(int *)(iVar4 + 4) + 0x2c);
    if (puVar1 != (undefined4 *)0x0) {
      puVar2 = (uint *)puVar1[1];
      for (puVar9 = (uint *)*puVar1; puVar9 != puVar2; puVar9 = puVar9 + 2) {
        param_2 = *puVar9;
        FUN_00606ea0(&param_3,(param_2 >> 3) + param_2,&param_2,
                     -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) &
                     (uint)(param_1 + *param_1 + 1 + 1));
        if (param_3 != 0) {
          FUN_006d5d50(param_3 + 0xc,iVar4,param_4,param_5);
        }
      }
    }
  }
  return;
}



/* FUNCTION 9290 ; VA 0x006d5e80 ; FUN_006d5e80 */

void __thiscall FUN_006d5e80(undefined4 param_1,int param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  int *piVar4;
  uint uVar5;
  int *piStack_5c;
  int **ppiStack_58;
  int *apiStack_48 [5];
  uint uStack_34;
  int *apiStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  byte bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar1 = (int)param_3;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8a68;
  pvStack_10 = ExceptionList;
  bStack_11 = *(byte *)(param_2 + 0x43) & 1;
  ExceptionList = &pvStack_10;
  uStack_18 = param_1;
  if (DAT_01eaf005 != '\0') {
    piVar3 = *(int **)((int)param_3 + 0x28);
    if (0xf < (uint)piVar3[5]) {
      piVar3 = (int *)*piVar3;
    }
    ppiStack_58 = apiStack_48;
    piStack_5c = (int *)0x6d5ed3;
    ExceptionList = &pvStack_10;
    param_3 = (undefined4 *)FUN_009c9510();
    iStack_8 = 0;
    if (0xf < (uint)param_3[5]) {
      param_3 = (undefined4 *)*param_3;
    }
    piVar4 = *(int **)(param_2 + 0x28);
    if (0xf < (uint)piVar4[5]) {
      piVar4 = (int *)*piVar4;
    }
    ppiStack_58 = apiStack_30;
    piStack_5c = (int *)0x6d5f02;
    puVar2 = (undefined4 *)FUN_009c9510();
    iStack_8._0_1_ = 1;
    if (0xf < (uint)puVar2[5]) {
      puVar2 = (undefined4 *)*puVar2;
    }
    ppiStack_58 = (int **)(uint)bStack_11;
    piStack_5c = piVar3;
    FUN_01677520(DAT_01eaf005,"%s(%s) reparent to %s(%s), complete: %d",puVar2,piVar4,param_3);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_1c) {
      ppiStack_58 = (int **)(uStack_1c + 1);
      piVar3 = apiStack_30[0];
      if (0xfff < ppiStack_58) {
        piVar3 = (int *)apiStack_30[0][-1];
        ppiStack_58 = (int **)(uStack_1c + 0x24);
        if (0x1f < (uint)((int)apiStack_30[0] + (-4 - (int)piVar3))) {
                    /* WARNING: Subroutine does not return */
          ppiStack_58 = (int **)0x6d6086;
          FUN_017167a3();
        }
      }
      piStack_5c = piVar3;
      FUN_01674ea0();
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    apiStack_30[0] = (int *)((uint)apiStack_30[0] & 0xffffff00);
    iStack_8 = 0xffffffff;
    if (0xf < uStack_34) {
      ppiStack_58 = (int **)(uStack_34 + 1);
      piVar3 = apiStack_48[0];
      if (0xfff < ppiStack_58) {
        piVar3 = (int *)apiStack_48[0][-1];
        ppiStack_58 = (int **)(uStack_34 + 0x24);
        if (0x1f < (uint)((int)apiStack_48[0] + (-4 - (int)piVar3))) {
                    /* WARNING: Subroutine does not return */
          ppiStack_58 = (int **)0x6d608b;
          FUN_017167a3();
        }
      }
      piStack_5c = piVar3;
      FUN_01674ea0();
    }
  }
  if (bStack_11 != 0) {
    uVar5 = *(uint *)(iVar1 + 0x40);
    uVar5 = (uVar5 + 1 ^ uVar5) & 0xffffff ^ uVar5;
    *(uint *)(iVar1 + 0x40) = uVar5;
    if (DAT_01eaf005 != '\0') {
      piVar3 = *(int **)(iVar1 + 0x28);
      if (0xf < (uint)piVar3[5]) {
        piVar3 = (int *)*piVar3;
      }
      ppiStack_58 = apiStack_48;
      piStack_5c = (int *)0x6d5ff9;
      puVar2 = (undefined4 *)FUN_009c9510();
      iStack_8 = 3;
      if (0xf < (uint)puVar2[5]) {
        puVar2 = (undefined4 *)*puVar2;
      }
      piStack_5c = piVar3;
      ppiStack_58 = (int **)(uVar5 & 0xffffff);
      FUN_01677520(DAT_01eaf005,"%s(%s) inc computed: %d",puVar2);
      iStack_8 = 0xffffffff;
      if (0xf < uStack_34) {
        ppiStack_58 = (int **)(uStack_34 + 1);
        piVar3 = apiStack_48[0];
        if (0xfff < ppiStack_58) {
          piVar3 = (int *)apiStack_48[0][-1];
          ppiStack_58 = (int **)(uStack_34 + 0x24);
          if (0x1f < (uint)((int)apiStack_48[0] + (-4 - (int)piVar3))) {
                    /* WARNING: Subroutine does not return */
            ppiStack_58 = (int **)&UNK_006d6090;
            FUN_017167a3();
          }
        }
        piStack_5c = piVar3;
        FUN_01674ea0();
      }
    }
    FUN_0060dcd0(&piStack_5c,iVar1);
    FUN_006d7b90();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9291 ; VA 0x006d60a0 ; FUN_006d60a0 */

void __thiscall FUN_006d60a0(undefined4 param_1,undefined4 *param_2,int *param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int *piVar6;
  int *piVar7;
  int aiStack_48 [5];
  uint uStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8a90;
  pvStack_10 = ExceptionList;
  if ((*(uint *)((int)param_2 + 0x40) & 0x1000000) != 0) {
    uVar5 = *(uint *)(*param_3 + 0x40);
    ExceptionList = &pvStack_10;
    *(uint *)(*param_3 + 0x40) = (uVar5 - 1 ^ uVar5) & 0xffffff ^ uVar5;
    uStack_14 = param_1;
    if (DAT_01eaf005 != '\0') {
      piVar6 = *(int **)((int)param_2 + 0x28);
      uVar1 = *(undefined4 *)(*param_3 + 0x3c);
      uStack_18 = *(uint *)(*param_3 + 0x40) & 0xffffff;
      if (0xf < (uint)piVar6[5]) {
        piVar6 = (int *)*piVar6;
      }
      param_2 = (undefined4 *)FUN_009c9510(aiStack_48);
      iStack_8 = 0;
      if (0xf < (uint)param_2[5]) {
        param_2 = (undefined4 *)*param_2;
      }
      piVar7 = *(int **)(*param_3 + 0x28);
      if (0xf < (uint)piVar7[5]) {
        piVar7 = (int *)*piVar7;
      }
      puVar2 = (undefined4 *)FUN_009c9510(auStack_30);
      iStack_8._0_1_ = 1;
      if (0xf < (uint)puVar2[5]) {
        puVar2 = (undefined4 *)*puVar2;
      }
      FUN_01677520(DAT_01eaf005,"%s(%s) remove %s(%s) dec computed:%d expected:%d",puVar2,piVar7,
                   param_2,piVar6,uStack_18,uVar1);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (0xf < uStack_1c) {
        uVar4 = uStack_1c + 1;
        uVar5 = auStack_30[0];
        if (0xfff < uVar4) {
          uVar5 = *(uint *)(auStack_30[0] - 4);
          uVar4 = uStack_1c + 0x24;
          if (0x1f < (auStack_30[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar5,uVar4);
      }
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = auStack_30[0] & 0xffffff00;
      iStack_8 = 0xffffffff;
      if (0xf < uStack_34) {
        uVar5 = uStack_34 + 1;
        iVar3 = aiStack_48[0];
        if (0xfff < uVar5) {
          iVar3 = *(int *)(aiStack_48[0] + -4);
          uVar5 = uStack_34 + 0x24;
          if (0x1f < (aiStack_48[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar3,uVar5);
      }
    }
    if (param_3[1] != 0) {
      LOCK();
      piVar6 = (int *)(param_3[1] + 4);
      *piVar6 = *piVar6 + 1;
      UNLOCK();
    }
    FUN_006d7b90(*param_3,param_3[1]);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9292 ; VA 0x006d6250 ; FUN_006d6250 */

void __fastcall FUN_006d6250(int param_1)

{
  uint uVar1;
  undefined4 *puVar2;
  bool bVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int *piVar7;
  int iVar8;
  undefined *puVar9;
  undefined4 uVar10;
  uint uVar11;
  uint uVar12;
  int iVar13;
  undefined4 uVar14;
  uint uVar15;
  undefined8 uVar16;
  undefined8 uVar17;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8ac0;
  pvStack_10 = ExceptionList;
  iVar8 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if ((*(int *)(iVar8 + 0x34) < DAT_01eaf128) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eaf128), DAT_01eaf128 == -1)) {
    uStack_8 = 0;
    uVar16 = FUN_0152dab0(&DAT_018c5904,"SharedQCleanUp",0xffffffff);
    DAT_01eaf124 = (undefined4)((ulonglong)uVar16 >> 0x20);
    DAT_01eaf120 = (undefined4)uVar16;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eaf128);
  }
  uVar5 = DAT_01eaf124;
  uVar4 = DAT_01eaf120;
  uVar16 = FUN_0152d930(DAT_01eaf120,DAT_01eaf124);
  iVar6 = *(int *)(param_1 + 0x1ec) - *(int *)(param_1 + 0x1e8) >> 2;
  uStack_8 = 1;
  bVar3 = false;
  if (iVar6 != 0) {
    piVar7 = *(int **)(param_1 + 0x1bc);
    uVar12 = *(uint *)(param_1 + 0x1f8);
    uVar11 = *(uint *)(param_1 + 0x1fc);
    if (piVar7 != *(int **)(param_1 + 0x1c0)) {
      do {
        iVar13 = *piVar7;
        uVar15 = *(uint *)(iVar13 + 0x3810);
        if (((*(int *)(iVar13 + 0x3814) != 0) || (uVar15 != 0)) &&
           (*(char *)(iVar13 + 0x1db8) == '\0')) {
          uVar1 = *(uint *)(iVar13 + 0x3814);
          bVar3 = true;
          if ((uVar1 < uVar11) || ((uVar1 <= uVar11 && (uVar15 <= uVar12)))) {
            uVar12 = uVar15;
            uVar11 = uVar1;
          }
        }
        piVar7 = piVar7 + 1;
      } while (piVar7 != *(int **)(param_1 + 0x1c0));
      if (bVar3) {
        uVar15 = uVar12 - *(int *)(param_1 + 0x200);
        if (DAT_01eaf007 != '\0') {
          FUN_01677520(DAT_01eaf007,
                       "Cleaning SharedRebroadcastQueue - Size : %zu  Deleting #%llu items, Will delete up to id : %llu"
                       ,iVar6,uVar15,0,uVar12,uVar11);
        }
        if ((*(int *)(iVar8 + 0x34) < DAT_01eaf138) &&
           (FUN_016f3809(&DAT_01eaf138), DAT_01eaf138 == -1)) {
          uStack_8._0_1_ = 3;
          uVar17 = FUN_0152da50(&DAT_018c5904);
          DAT_01eaf134 = (undefined4)((ulonglong)uVar17 >> 0x20);
          DAT_01eaf130 = (undefined4)uVar17;
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_016f37bf(&DAT_01eaf138);
        }
        FUN_0152d760(DAT_01eaf130,DAT_01eaf134,
                     "SharedRebroadcastQueue : %zu  (will clean up : %llu)",
                     *(int *)(param_1 + 0x1ec) - *(int *)(param_1 + 0x1e8) >> 2,uVar15,0);
        if (uVar15 != 0) {
          uVar12 = 0;
          do {
            puVar2 = *(undefined4 **)(*(int *)(param_1 + 0x1e8) + uVar12 * 4);
            if (puVar2 != (undefined4 *)0x0) {
              (**(code **)*puVar2)(1);
            }
            uVar12 = uVar12 + 1;
          } while (uVar12 < uVar15);
          iVar6 = *(int *)(param_1 + 0x1e8);
          iVar8 = iVar6 + uVar15 * 4;
          if (iVar6 != iVar8) {
            iVar13 = *(int *)(param_1 + 0x1ec) - iVar8;
            FUN_0170cc70(iVar6,iVar8,iVar13);
            *(int *)(param_1 + 0x1ec) = iVar6 + iVar13;
          }
          uVar12 = *(uint *)(param_1 + 0x200);
          iVar8 = uVar12 + uVar15;
          *(int *)(param_1 + 0x200) = iVar8;
          iVar6 = *(int *)(param_1 + 0x204) + (uint)CARRY4(uVar12,uVar15);
          *(int *)(param_1 + 0x204) = iVar6;
          if (DAT_01eaf007 != '\0') {
            uVar12 = *(int *)(param_1 + 0x1ec) - (int)*(int **)(param_1 + 0x1e8);
            if (((int)uVar12 >> 2 == 0) || (iVar13 = **(int **)(param_1 + 0x1e8), iVar13 == 0)) {
              uVar14 = 0xffffffff;
              uVar10 = 0xffffffff;
            }
            else {
              uVar14 = *(undefined4 *)(iVar13 + 0x20);
              uVar10 = *(undefined4 *)(iVar13 + 0x24);
            }
            puVar9 = &DAT_018cec6c;
            if (3 < uVar12) {
              puVar9 = &DAT_018cec70;
            }
            FUN_01677520(DAT_01eaf007,
                         "Cleaning SharedRebroadcastQueue - after clean, lowestValidCommonId = %llu  first item has commonId (empty? %s) %llu"
                         ,iVar8,iVar6,puVar9,uVar14,uVar10);
          }
        }
      }
    }
  }
  uStack_8 = 4;
  FUN_0152dda0(uVar4,uVar5,uVar16);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9293 ; VA 0x006d6570 ; FUN_006d6570 */

void __thiscall FUN_006d6570(int param_1,int param_2)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined8 *puVar7;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined8 *puStack_14;
  undefined4 *puStack_10;
  int iStack_8;
  
  puStack_10 = (undefined4 *)(param_2 + 0x18);
  piStack_18 = (int *)(param_1 + 0x254);
  FUN_006d8510(&iStack_8,puStack_10);
  if (iStack_8 != *(int *)(param_1 + 0x254)) {
    puStack_14 = *(undefined8 **)(iStack_8 + 0x1c);
    puVar7 = *(undefined8 **)(iStack_8 + 0x18);
    if (puVar7 != puStack_14) {
      piVar4 = (int *)(param_1 + 0x24c);
      do {
        puVar2 = (undefined4 *)*piVar4;
        uStack_24 = *puVar7;
        uStack_1c = *(undefined4 *)(puVar7 + 1);
        puVar5 = (undefined4 *)puVar2[1];
        puVar6 = puVar2;
        if (*(char *)((int)puVar2[1] + 0xd) == '\0') {
          do {
            cVar1 = FUN_009c8f70(&uStack_24);
            if (cVar1 == '\0') {
              puVar2 = (undefined4 *)*puVar5;
              puVar6 = puVar5;
            }
            else {
              puVar2 = (undefined4 *)puVar5[2];
            }
            puVar5 = puVar2;
          } while (*(char *)((int)puVar2 + 0xd) == '\0');
          puVar2 = (undefined4 *)*piVar4;
        }
        if (puVar6 == puVar2) {
LAB_006d661f:
          puVar6 = puVar2;
        }
        else {
          cVar1 = FUN_009c8f70(puVar6 + 4);
          puVar2 = (undefined4 *)*piVar4;
          if (cVar1 != '\0') goto LAB_006d661f;
        }
        if (puVar6 != puVar2) {
          uStack_30 = *puStack_10;
          uStack_2c = puStack_10[1];
          uStack_28 = uStack_1c;
          FUN_006d8310(&uStack_30);
          if (puVar6[8] == 0) {
            uVar3 = FUN_00553830(puVar6);
            FUN_0061ac80();
            FUN_01674ea0(uVar3,0x30);
          }
        }
        puVar7 = (undefined8 *)((int)puVar7 + 0xc);
      } while (puVar7 != puStack_14);
    }
    uVar3 = FUN_00553830(iStack_8);
    thunk_FUN_00617ad0();
    FUN_01674ea0(uVar3,0x24);
  }
  return;
}



/* FUNCTION 9294 ; VA 0x006d66a0 ; FUN_006d66a0 */

void __thiscall FUN_006d66a0(byte *param_1,int param_2,uint *param_3)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  int iStack_c;
  uint uStack_8;
  
  uStack_8 = *param_3;
  FUN_00606ea0(&iStack_c,(uStack_8 >> 3) + uStack_8,&uStack_8,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  iVar4 = iStack_c;
  if (iStack_c != 0) {
    iVar1 = iStack_c + 0xc;
    uVar3 = *(uint *)(param_2 + 0x18e8);
    if ((uVar3 < (uint)((*(int *)(iStack_c + 0x44) - *(int *)(iStack_c + 0x40)) / 0xc)) &&
       (piVar2 = (int *)(iStack_c + 0x40), iStack_c = *piVar2 + uVar3 * 0xc,
       *(char *)(*piVar2 + 8 + uVar3 * 0xc) != '\0')) {
      uVar5 = uStack_8;
      if (DAT_01d5b7f8 == '\0') {
        FUN_006e0210(iVar1,uVar3);
        uVar5 = *param_3;
      }
      FUN_006da720(param_2,uVar5,iVar1);
      FUN_006da6e0(iStack_c);
    }
    if (*(int *)(iVar4 + 0x38) < 1) {
      if ((DAT_01d5b820 != '\0') && (*(int *)(param_1 + 0x1c) != 0)) {
        FUN_006cc9d0(iVar1);
      }
      FUN_006dc8d0();
      FUN_006d6570(*(undefined4 *)(iVar4 + 8));
      FUN_006d8250(&param_3,iVar4);
    }
  }
  return;
}



/* FUNCTION 9295 ; VA 0x006d67a0 ; FUN_006d67a0 */

void FUN_006d67a0(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x90;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 9296 ; VA 0x006d67e0 ; FUN_006d67e0 */

undefined4 __thiscall FUN_006d67e0(byte *param_1,int param_2,uint param_3)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int iStack_8;
  
  iVar4 = param_3 + (param_3 >> 3);
  FUN_00606ea0(&iStack_8,iVar4,&param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (iStack_8 != 0) {
    uVar2 = *(uint *)(param_2 + 0x18e8);
    if (((DAT_01d5b808 == '\0') || (DAT_01d5b7f8 == '\0')) && (DAT_01d5b800 == '\0')) {
      if ((uVar2 < (uint)((*(int *)(iStack_8 + 0x44) - *(int *)(iStack_8 + 0x40)) / 0xc)) &&
         (((iVar3 = *(int *)(iStack_8 + 0x40) + uVar2 * 0xc, DAT_01d5b840 != '\0' &&
           (*(char *)(iStack_8 + 0x3f) != '\0')) || (*(char *)(iVar3 + 8) != '\0')))) {
        if (*(int *)(iVar3 + 4) == 0) {
          return 0;
        }
        *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + -1;
        return 1;
      }
    }
    else if (((DAT_01d5b840 != '\0') && (*(char *)(iStack_8 + 0x3f) != '\0')) ||
            ((uVar2 < (uint)((*(int *)(iStack_8 + 0x44) - *(int *)(iStack_8 + 0x40)) / 0xc) &&
             (*(char *)(*(int *)(iStack_8 + 0x40) + 8 + uVar2 * 0xc) != '\0')))) {
      if ((uint)((*(int *)(iStack_8 + 0x44) - *(int *)(iStack_8 + 0x40)) / 0xc) <= uVar2) {
        return 0;
      }
      iVar4 = *(int *)(iStack_8 + 0x40) + uVar2 * 0xc;
      iVar3 = *(int *)(iVar4 + 4);
      if (iVar3 == 0) {
        return 0;
      }
      *(int *)(iVar4 + 4) = iVar3 + -1;
      return 1;
    }
  }
  iVar3 = param_2 + 0x1e81 + (uint)*(byte *)(param_2 + 0x1e80);
  FUN_00606ea0(&param_2,iVar4,&param_3,-(uint)(iVar3 != 0) & iVar3 + 1U);
  if (param_2 == 0) {
    return 0;
  }
  piVar1 = (int *)(param_2 + 0xc);
  *piVar1 = *piVar1 + -1;
  if (*piVar1 == 0) {
    FUN_006d81b0(&param_3,param_2);
  }
  return 1;
}



/* FUNCTION 9297 ; VA 0x006d6980 ; FUN_006d6980 */

int __thiscall FUN_006d6980(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_006cffc0(-(uint)(param_1 != -3) & param_1 + 4U,puVar1 + 2);
    FUN_01674ea0(puVar1,0x4c);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    iVar2 = iVar2 + 1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 9298 ; VA 0x006d69e0 ; FUN_006d69e0 */

void __thiscall FUN_006d69e0(byte *param_1,int param_2)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  char cVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  int *piVar10;
  int *piVar11;
  int aiStack_70 [5];
  uint uStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  int *piStack_40;
  int iStack_3c;
  int *piStack_38;
  int *piStack_34;
  int iStack_30;
  uint uStack_2c;
  byte *pbStack_28;
  int iStack_24;
  uint uStack_20;
  int iStack_1c;
  int *piStack_18;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8ae0;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0xac) == 0) {
    return;
  }
  iVar9 = *(int *)(*(int *)(param_2 + 4) + 0xc);
  ExceptionList = &pvStack_10;
  pbStack_28 = param_1;
  iVar2 = FUN_00b63e30();
  if ((uint)*(ushort *)(iVar9 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar9 = *(int *)(*(int *)(param_2 + 4) + 0xc);
    iVar2 = FUN_008aa870();
    cStack_11 = '\x01';
    if ((uint)*(ushort *)(iVar2 + 0x1da) <
        (uint)*(ushort *)(iVar9 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) goto LAB_006d6a66;
  }
  cStack_11 = '\0';
LAB_006d6a66:
  piStack_34 = *(int **)(param_2 + 4);
  piVar3 = (int *)piStack_34[0xb];
  if (piVar3 == (int *)0x0) {
    iStack_30 = 0;
  }
  else {
    iStack_30 = piVar3[1] - *piVar3 >> 3;
  }
  piStack_18 = (int *)piStack_34[0xd];
  if ((piStack_18 == (int *)0x0) || (piVar3 = (int *)piStack_18[0xb], piVar3 == (int *)0x0)) {
    iStack_24 = 0;
  }
  else {
    iStack_24 = piVar3[1] - *piVar3 >> 3;
  }
  if (piStack_34 != (int *)0x0) {
    while( true ) {
      uStack_2c = (uint)piVar3 & 0xffffff00;
      uStack_20 = 0;
      piStack_40 = *(int **)(param_2 + 0x38);
      piVar3 = *(int **)(param_2 + 0x34);
      if (piVar3 == piStack_40) break;
      iVar9 = 0;
      cStack_12 = '\0';
      iStack_1c = 0;
      piVar11 = piStack_18;
      piStack_38 = piStack_18;
      do {
        cVar6 = *(char *)((int)piVar3 + 9);
        if ((((DAT_01d5b840 == '\0') || (*(char *)(param_2 + 0x33) == '\0')) &&
            (*(char *)(piVar3 + 2) == '\0')) || (*piVar3 != iStack_30)) {
          cVar1 = '\0';
        }
        else {
          cVar1 = '\x01';
        }
        *(char *)((int)piVar3 + 9) = cVar1;
        if (cVar1 != cVar6) {
          if (cStack_11 != '\0') {
            FUN_006d41d0(piStack_34,uStack_20);
          }
          if ((cStack_12 == '\0') && (piVar11 != (int *)0x0)) {
            cStack_12 = '\x01';
            FUN_00606ea0(&iStack_3c,((uint)piVar11 >> 3) + (int)piVar11,&piStack_38,
                         -(uint)(pbStack_28 + *pbStack_28 + 1 != (byte *)0x0) &
                         (uint)(pbStack_28 + *pbStack_28 + 1 + 1));
            if (iStack_3c != 0) {
              iVar9 = iStack_3c + 0xc;
            }
          }
          if ((((iVar9 != 0) &&
               (piVar11 = piStack_18,
               uStack_20 < (uint)((*(int *)(iVar9 + 0x38) - *(int *)(iVar9 + 0x34)) / 0xc))) &&
              (piVar10 = (int *)(*(int *)(iVar9 + 0x34) + iStack_1c), piVar10 != (int *)0x0)) &&
             ((DAT_01d5b820 == '\0' ||
              (((DAT_01d5b840 != '\0' && (*(char *)(iVar9 + 0x33) != '\0')) ||
               (*(char *)(piVar10 + 2) != '\0')))))) {
            if (*(char *)((int)piVar3 + 9) == '\0') {
              if (DAT_01ee420d != '\0') {
                puVar4 = (undefined4 *)FUN_008a2380(auStack_58);
                uStack_8 = 1;
                if (0xf < (uint)puVar4[5]) {
                  puVar4 = (undefined4 *)*puVar4;
                }
                FUN_01677490(DAT_01ee420d,
                             "determineCompletenessAllReplicators():: numCompleteChildren-- for %s[%d]"
                             ,puVar4,uStack_20,0);
                uStack_8 = 0xffffffff;
                if (0xf < uStack_44) {
                  uVar8 = uStack_44 + 1;
                  uVar7 = auStack_58[0];
                  if (0xfff < uVar8) {
                    uVar7 = *(uint *)(auStack_58[0] - 4);
                    uVar8 = uStack_44 + 0x24;
                    if (0x1f < (auStack_58[0] - uVar7) - 4) goto LAB_006d6ded;
                  }
                  FUN_01674ea0(uVar7,uVar8);
                }
                uStack_48 = 0;
                uStack_44 = 0xf;
                auStack_58[0] = auStack_58[0] & 0xffffff00;
              }
              *piVar10 = *piVar10 + -1;
            }
            else {
              if (DAT_01ee420d != '\0') {
                puVar4 = (undefined4 *)FUN_008a2380(aiStack_70);
                uStack_8 = 0;
                if (0xf < (uint)puVar4[5]) {
                  puVar4 = (undefined4 *)*puVar4;
                }
                FUN_01677490(DAT_01ee420d,
                             "determineCompletenessAllReplicators():: numCompleteChildren++ for %s[%d]"
                             ,puVar4,uStack_20,0);
                uStack_8 = 0xffffffff;
                if (0xf < uStack_5c) {
                  uVar7 = uStack_5c + 1;
                  iVar2 = aiStack_70[0];
                  if (0xfff < uVar7) {
                    iVar2 = *(int *)(aiStack_70[0] + -4);
                    uVar7 = uStack_5c + 0x24;
                    if (0x1f < (aiStack_70[0] - iVar2) - 4U) {
LAB_006d6ded:
                      uStack_8 = 0xffffffff;
                    /* WARNING: Subroutine does not return */
                      FUN_017167a3();
                    }
                  }
                  FUN_01674ea0(iVar2,uVar7);
                }
              }
              *piVar10 = *piVar10 + 1;
            }
            if ((*piVar10 == iStack_24) &&
               (((DAT_01d5b840 != '\0' && (*(char *)(iVar9 + 0x33) != '\0')) ||
                (*(char *)(piVar10 + 2) != '\0')))) {
              cVar6 = '\x01';
            }
            else {
              cVar6 = '\0';
            }
            uStack_2c = uStack_2c & 0xff;
            piVar11 = piStack_18;
            if (cVar6 != *(char *)((int)piVar10 + 9)) {
              uStack_2c = 1;
            }
          }
        }
        uStack_20 = uStack_20 + 1;
        iStack_1c = iStack_1c + 0xc;
        piVar3 = piVar3 + 3;
      } while (piVar3 != piStack_40);
      if ((char)uStack_2c == '\0') {
        ExceptionList = pvStack_10;
        return;
      }
      iVar2 = piVar11[3];
      iStack_30 = iStack_24;
      piStack_34 = piVar11;
      iVar5 = FUN_00b63e30();
      piVar3 = piStack_18;
      if ((uint)*(ushort *)(iVar5 + 0x1da) <
          (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
LAB_006d6d98:
        cStack_11 = '\0';
      }
      else {
        iVar2 = piStack_18[3];
        iVar5 = FUN_008aa870();
        cStack_11 = '\x01';
        if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
            (uint)*(ushort *)(iVar5 + 0x1da)) goto LAB_006d6d98;
      }
      piStack_18 = (int *)piVar3[0xd];
      piVar3 = piStack_18;
      param_2 = iVar9;
      if (piStack_18 != (int *)0x0) {
        piVar3 = (int *)piStack_18[0xb];
        if (piVar3 == (int *)0x0) {
          iStack_24 = 0;
        }
        else {
          iStack_24 = piVar3[1] - *piVar3 >> 3;
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9299 ; VA 0x006d6e00 ; FUN_006d6e00 */

void * __thiscall FUN_006d6e00(byte *param_1,int param_2,uint param_3)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  void *pvVar4;
  undefined4 *puVar5;
  undefined *puVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  int iVar10;
  int iVar11;
  int *piVar12;
  byte *pbVar13;
  int aiStack_44 [5];
  uint uStack_30;
  int iStack_2c;
  uint uStack_28;
  int iStack_24;
  int iStack_20;
  byte *pbStack_1c;
  void *pvStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8af8;
  pvStack_10 = ExceptionList;
  pvVar4 = ExceptionList;
  if (*(int *)(param_1 + 0xac) != 0) {
    pvVar4 = (void *)0x0;
    pvStack_18 = (void *)0x0;
    iVar10 = param_2;
    ExceptionList = &pvStack_10;
    pbStack_1c = param_1;
    if (param_2 != 0) {
      do {
        if (DAT_01d5b870 != '\0') {
          iVar8 = *(int *)(iVar10 + 0x38) - *(int *)(iVar10 + 0x34);
          uVar9 = iVar8 / 0xc;
          if (uVar9 <= param_3) {
            if (DAT_01eaf006 == '\0') {
              ExceptionList = pvStack_10;
              return (void *)(iVar8 * 0x2aaaaaab);
            }
            piVar12 = *(int **)(*(int *)(param_2 + 4) + 0x28);
            if (0xf < (uint)piVar12[5]) {
              piVar12 = (int *)*piVar12;
            }
            pvVar4 = (void *)FUN_01677520(DAT_01eaf006,
                                          "determineCompleteness_deprecated indexing past end of conn data vector, instance %s, index %d, connData size: %zu"
                                          ,piVar12,param_3,uVar9);
            ExceptionList = pvStack_10;
            return pvVar4;
          }
        }
        iStack_2c = param_3 * 0xc;
        piVar12 = (int *)(*(int *)(iVar10 + 0x34) + iStack_2c);
        cStack_11 = *(char *)((int)piVar12 + 9);
        pvVar4 = pvStack_18;
        if ((pvStack_18 != (void *)0x0) && (DAT_01ee420d != '\0')) {
          puVar5 = (undefined4 *)FUN_008a2380(aiStack_44);
          pvVar4 = pvStack_18;
          uStack_8 = 0;
          if (0xf < (uint)puVar5[5]) {
            puVar5 = (undefined4 *)*puVar5;
          }
          puVar6 = &DAT_018decbc;
          if (pvStack_18 != (void *)0x1) {
            puVar6 = &DAT_018c3938;
          }
          FUN_01677520(DAT_01ee420d,"determineCompleteness():: numCompleteChildren%s for %s[%d]",
                       puVar6,puVar5,param_3);
          uStack_8 = 0xffffffff;
          if (0xf < uStack_30) {
            uVar9 = uStack_30 + 1;
            iVar8 = aiStack_44[0];
            if (0xfff < uVar9) {
              iVar8 = *(int *)(aiStack_44[0] + -4);
              uVar9 = uStack_30 + 0x24;
              if (0x1f < (aiStack_44[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(iVar8,uVar9);
          }
        }
        iVar8 = *piVar12;
        piVar1 = (int *)(iVar10 + 4);
        *piVar12 = iVar8 + (int)pvVar4;
        piVar2 = *(int **)(*piVar1 + 0x2c);
        if (piVar2 == (int *)0x0) {
          iVar7 = 0;
        }
        else {
          iVar7 = piVar2[1] - *piVar2 >> 3;
        }
        if ((((DAT_01d5b840 == '\0') || (*(char *)(iVar10 + 0x33) == '\0')) &&
            (*(char *)(piVar12 + 2) == '\0')) || (iVar7 != iVar8 + (int)pvVar4)) {
          cVar3 = '\0';
        }
        else {
          cVar3 = '\x01';
        }
        iVar10 = 0;
        *(char *)((int)piVar12 + 9) = cVar3;
        iStack_20 = 0;
        if (cStack_11 != cVar3) {
          iVar8 = *(int *)(*piVar1 + 0xc);
          iVar7 = FUN_00b63e30();
          pbVar13 = pbStack_1c;
          if (((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
               (uint)*(ushort *)(iVar7 + 0x1da)) &&
             (iVar8 = *(int *)(*piVar1 + 0xc), iVar7 = FUN_008aa870(), pbVar13 = pbStack_1c,
             (uint)*(ushort *)(iVar7 + 0x1da) <
             (uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8))) {
            FUN_006d41d0(*piVar1,param_3);
          }
          uVar9 = *(uint *)(*piVar1 + 0x34);
          if ((uVar9 != 0) &&
             (uStack_28 = uVar9,
             FUN_00606ea0(&iStack_24,(uVar9 >> 3) + uVar9,&uStack_28,
                          -(uint)(pbVar13 + *pbVar13 + 1 != (byte *)0x0) &
                          (uint)(pbVar13 + *pbVar13 + 1 + 1)), iVar8 = iStack_24, iStack_24 != 0)) {
            iVar7 = iVar8;
            if ((DAT_01d5b840 != '\0') && (*(char *)(iStack_24 + 0x3f) != '\0')) {
              piVar12 = (int *)(iStack_24 + 0x40);
              uVar9 = (*(int *)(iStack_24 + 0x44) - *piVar12) / 0xc;
              iVar10 = iStack_20;
              if ((uVar9 <= param_3) &&
                 (FUN_006b2d20(param_3 + 1,piVar12), iVar10 = iStack_20,
                 uVar9 < (uint)((*(int *)(iVar8 + 0x44) - *piVar12) / 0xc))) {
                iVar11 = uVar9 * 0xc;
                do {
                  uVar9 = uVar9 + 1;
                  *(undefined *)(iVar11 + 8 + *piVar12) = 0;
                  *(undefined *)(iVar11 + 9 + *piVar12) = 0;
                  *(undefined *)(iVar11 + 10 + *piVar12) = 0;
                  *(undefined4 *)(iVar11 + *piVar12) = 0;
                  *(undefined4 *)(iVar11 + 4 + *piVar12) = 0;
                  iVar11 = iVar11 + 0xc;
                  iVar7 = iStack_24;
                } while (uVar9 < (uint)((*(int *)(iVar8 + 0x44) - *piVar12) / 0xc));
              }
            }
            if ((param_3 < (uint)((*(int *)(iVar7 + 0x44) - *(int *)(iVar7 + 0x40)) / 0xc)) &&
               ((DAT_01d5b820 == '\0' ||
                (((DAT_01d5b840 != '\0' && (*(char *)(iVar7 + 0x3f) != '\0')) ||
                 (*(char *)(iStack_2c + 8 + *(int *)(iVar7 + 0x40)) != '\0')))))) {
              iVar10 = iVar7 + 0xc;
              pvStack_18 = (void *)((uint)(cStack_11 == '\0') * 2 + -1);
            }
          }
        }
        pvVar4 = pvStack_18;
      } while (iVar10 != 0);
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 9300 ; VA 0x006d7180 ; FUN_006d7180 */

void __thiscall FUN_006d7180(int param_1,uint param_2,int param_3,int *param_4)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint *puVar7;
  uint uVar8;
  undefined **ppuStack_68;
  undefined8 uStack_64;
  int iStack_5c;
  undefined ***pppuStack_44;
  int *piStack_40;
  int *piStack_3c;
  int iStack_34;
  uint *puStack_30;
  uint *puStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar3 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8b20;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  iVar2 = FUN_006bf290();
  if (((iVar2 != 0) && (*(char *)(iVar2 + 0x300) != '\0')) && (*(char *)(param_1 + 0x26c) == '\0'))
  {
    uStack_18 = *(int *)(iVar3 + 4);
    do {
      uStack_24 = *(uint *)(param_1 + 0xe4);
      uVar4 = *(uint *)(uStack_18 + 0xc);
      if (uStack_24 == *(uint *)(param_1 + 0xe8)) {
        iVar3 = 0;
      }
      else if (uVar4 == *(uint *)(param_1 + 0xf4)) {
        iVar3 = 0;
      }
      else {
        uVar6 = (uVar4 >> 3) + uVar4;
        uVar8 = ((int)(*(uint *)(param_1 + 0xe8) - uStack_24) >> 3) - 1;
        uVar5 = 0;
        do {
          uVar6 = uVar6 & uVar8;
          uVar1 = *(uint *)(uStack_24 + uVar6 * 8);
          iVar3 = uStack_24 + uVar6 * 8;
          if (uVar1 == uVar4) goto LAB_006d7247;
          if (uVar1 == *(uint *)(iStack_14 + 0xf4)) break;
          uVar6 = uVar6 + 1 + uVar5;
          uVar5 = uVar5 + 1;
        } while (uVar5 <= uVar8);
        iVar3 = 0;
      }
LAB_006d7247:
      if ((iVar3 + 4U & -(uint)(iVar3 != 0)) == 0) {
        ExceptionList = pvStack_10;
        return;
      }
      uStack_18 = *(int *)(uStack_18 + 0x34);
      iVar3 = *(int *)(uStack_18 + 0xc);
      iVar2 = FUN_008aa870();
      param_1 = iStack_14;
    } while ((uint)*(ushort *)(iVar2 + 0x1da) <
             (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8));
    iVar3 = *(int *)(*(int *)(param_3 + 4) + 0xc);
    iVar2 = FUN_00aff8c0();
    uVar4 = param_2;
    puVar7 = (uint *)0x0;
    uStack_20 = (uint)*(ushort *)(iVar2 + 0x1da);
    uVar6 = (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8);
    iStack_34 = 0;
    puStack_30 = (uint *)0x0;
    puStack_2c = (uint *)0x0;
    uStack_8 = 0;
    uStack_18 = uVar6;
    if (((DAT_01d5b808 == '\0') || (DAT_01d5b7f8 == '\0')) && (DAT_01d5b800 == '\0')) {
      uStack_1c = param_4[1] - *param_4 >> 3;
      uVar5 = (*(int *)(param_2 + 0x38) - *(int *)(param_2 + 0x34)) / 0xc;
      if (uVar5 <= uStack_1c) {
        uStack_1c = uVar5;
      }
      param_2 = 0;
      if (uStack_1c != 0) {
        do {
          if ((((DAT_01d5b840 != '\0') && (*(char *)(uVar4 + 0x33) != '\0')) ||
              (*(char *)(*(int *)(uVar4 + 0x34) + 8 + param_2 * 0xc) != '\0')) &&
             (*(int *)(*param_4 + 4 + param_2 * 8) != 0)) {
            if (uStack_20 < uVar6) {
              if (puStack_2c == puVar7) {
                FUN_00595d30(puVar7,&param_2);
                puVar7 = puStack_30;
              }
              else {
                *puVar7 = param_2;
                puStack_30 = puStack_30 + 1;
                puVar7 = puStack_30;
              }
            }
            else {
              *(undefined4 *)(*param_4 + 4 + param_2 * 8) = 2;
              puVar7 = puStack_30;
            }
          }
          param_2 = param_2 + 1;
        } while (param_2 < uStack_1c);
      }
    }
    else {
      uStack_1c = 0;
      uStack_28 = *(int *)(iStack_14 + 0x1c0) - *(int *)(iStack_14 + 0x1bc) >> 2;
      if (uStack_28 != 0) {
        do {
          if ((((DAT_01d5b840 != '\0') && (*(char *)(param_2 + 0x33) != '\0')) ||
              ((uStack_1c < (uint)((*(int *)(param_2 + 0x38) - *(int *)(param_2 + 0x34)) / 0xc) &&
               (*(char *)(*(int *)(param_2 + 0x34) + 8 + uStack_1c * 0xc) != '\0')))) &&
             (*(int *)(*param_4 + 4 + uStack_1c * 8) != 0)) {
            if (uStack_20 < uStack_18) {
              if (puStack_2c == puVar7) {
                uStack_24 = uStack_1c;
                FUN_00595d30(puVar7,&uStack_1c);
                puVar7 = puStack_30;
              }
              else {
                *puVar7 = uStack_1c;
                puStack_30 = puStack_30 + 1;
                puVar7 = puStack_30;
              }
            }
            else {
              *(undefined4 *)(*param_4 + 4 + uStack_1c * 8) = 2;
              puVar7 = puStack_30;
            }
          }
          uStack_24 = uStack_1c + 1;
          uStack_1c = uStack_24;
        } while (uStack_24 < uStack_28);
      }
    }
    if (uStack_20 < uStack_18) {
      piStack_40 = &iStack_34;
      ppuStack_68 = std::
                    _Func_impl_no_alloc<class_<lambda_6c319e5b132248b503a755bba19ab1fb>,bool,class_std::shared_ptr<class_RBX::Instance>_>
                    ::vftable;
      piStack_3c = param_4;
      pppuStack_44 = &ppuStack_68;
      uStack_64 = CONCAT44(param_4,piStack_40);
      iStack_5c = iStack_14;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_006e09c0(pppuStack_44);
      if (pppuStack_44 != (undefined ***)0x0) {
        (*(code *)(*pppuStack_44)[4])(pppuStack_44 != &ppuStack_68);
      }
    }
    if (iStack_34 != 0) {
      uVar4 = (int)puStack_2c - iStack_34 & 0xfffffffc;
      iVar3 = iStack_34;
      if (0xfff < uVar4) {
        iVar3 = *(int *)(iStack_34 + -4);
        uVar4 = uVar4 + 0x23;
        if (0x1f < (iStack_34 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar4);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9301 ; VA 0x006d74f0 ; FUN_006d74f0 */

void __thiscall FUN_006d74f0(undefined4 *param_1,int param_2)

{
  int iVar1;
  uint *puVar2;
  uint **ppuVar3;
  undefined4 *puVar4;
  int *piVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  int iVar9;
  uint *puVar10;
  int iVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined auStack_88 [48];
  uint *puStack_58;
  uint *puStack_54;
  int iStack_50;
  undefined4 *puStack_4c;
  int iStack_48;
  uint *puStack_44;
  undefined4 *puStack_40;
  uint uStack_3c;
  undefined *puStack_38;
  uint **ppuStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined4 *puStack_24;
  uint *puStack_20;
  int *piStack_1c;
  uint *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a8b4b;
  pvStack_10 = ExceptionList;
  puStack_58 = (uint *)0x0;
  puStack_54 = (uint *)0x0;
  iStack_50 = 0;
  uStack_8 = 0;
  uStack_14 = *(uint *)(param_2 + 0x18e8);
  ExceptionList = &pvStack_10;
  puStack_24 = param_1;
  if (param_1[0x2f] != 0) {
    ExceptionList = &pvStack_10;
    FUN_0071d750(param_1 + 0x99,uStack_14);
  }
  if ((DAT_01d5b840 != '\0') && (*(char *)(param_2 + 0x3894) != '\0')) {
    param_1[0x86] = param_1[0x86] + -1;
  }
  if (DAT_01d5b880 != '\0') {
    param_1[0x87] = param_1[0x87] + -1;
  }
  FUN_016dee4c(auStack_88,2);
  puStack_20 = param_1 + 1;
  uVar13 = 0;
  uVar7 = *puStack_20;
  uStack_3c = uStack_14;
  puStack_38 = auStack_88;
  ppuStack_34 = &puStack_58;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar12 = DAT_01d5b770;
  puStack_40 = param_1;
  puStack_4c = (undefined4 *)FUN_01674fa0(0x10,4);
  iStack_48 = 0x10;
  *puStack_4c = puStack_40;
  puStack_4c[1] = uStack_3c;
  puStack_4c[2] = puStack_38;
  puStack_4c[3] = ppuStack_34;
  FUN_006d5250(CONCAT44(0x10,puStack_4c),4,&PTR_FUN_01d5b888,uVar7,uVar12,uVar13);
  puVar4 = puStack_24;
  FUN_0153a600(1);
  puStack_44 = puStack_54;
  puStack_18 = puStack_58;
  if (puStack_58 != puStack_54) {
    do {
      FUN_006d6570(*puStack_18);
      if (puVar4[2] != 0) {
        uStack_30 = *puStack_18;
        uStack_2c = (uStack_30 >> 3) + uStack_30;
        uStack_28 = *puStack_20;
        puStack_24 = (undefined4 *)(uStack_2c % uStack_28);
        ppuStack_34 = (uint **)((int)puStack_24 * 4);
        piStack_1c = *(int **)((int)ppuStack_34 + puVar4[5]);
        if ((piStack_1c != (int *)0x0) &&
           (piVar5 = (int *)*piStack_1c, (int *)*piStack_1c != (int *)0x0)) {
          while (piVar6 = piVar5, piVar5 = piStack_1c,
                (undefined4 *)((uint)piVar6[1] % uStack_28) == puStack_24) {
            if ((piVar6[1] == uStack_2c) && (uStack_30 == piVar6[2])) {
              FUN_006d6980(piStack_1c,*piVar6);
              if (*piVar5 != 0) {
                puVar8 = (undefined4 *)(*(uint *)(*piVar5 + 4) % *puStack_20);
                if (puStack_24 == puVar8) break;
                *(int **)(puVar4[5] + (int)puVar8 * 4) = piVar5;
              }
              if (*(int **)(puVar4[5] + (int)ppuStack_34) == piVar5) {
                *(undefined4 *)(puVar4[5] + (int)ppuStack_34) = 0;
              }
              break;
            }
            piVar5 = (int *)*piVar6;
            piStack_1c = piVar6;
            if ((int *)*piVar6 == (int *)0x0) break;
          }
        }
      }
      puStack_18 = puStack_18 + 1;
    } while (puStack_18 != puStack_44);
  }
  iVar9 = puVar4[0x70];
  iVar11 = puVar4[0x6f];
  puStack_54 = puStack_58;
  uVar7 = uStack_14 + 1;
  if (uVar7 < (uint)(iVar9 - iVar11 >> 2)) {
    do {
      iVar11 = uVar7 * 4;
      uVar7 = uVar7 + 1;
      piVar5 = (int *)(*(int *)(puVar4[0x6f] + iVar11) + 0x18e8);
      *piVar5 = *piVar5 + -1;
      iVar9 = puVar4[0x70];
      iVar11 = puVar4[0x6f];
    } while (uVar7 < (uint)(iVar9 - iVar11 >> 2));
  }
  iVar11 = iVar11 + uStack_14 * 4;
  iVar1 = iVar11 + 4;
  FUN_0170cc70(iVar11,iVar1,iVar9 - iVar1);
  puVar4[0x70] = puVar4[0x70] + -4;
  if (DAT_01d5b7f8 == '\0') {
    puStack_20 = (uint *)puVar4[0x8e];
    if (uStack_14 < (uint)(((int)puStack_20 - puVar4[0x8d]) / 0xc)) {
      puVar8 = (undefined4 *)(puVar4[0x8d] + uStack_14 * 0xc);
      if (puVar8 + 3 != puStack_20) {
        puStack_24 = puVar8 + 5;
        puVar10 = (uint *)((int)(puVar8 + 3) - (int)puVar8);
        puStack_44 = puVar10;
        do {
          if (puVar8 != (undefined4 *)((int)puVar10 + (int)puVar8)) {
            FUN_005e6280();
            *puVar8 = *(undefined4 *)((int)puStack_44 + (int)puVar8);
            puVar8[1] = puStack_24[-1];
            puVar8[2] = *puStack_24;
            *(undefined4 *)((int)puStack_44 + (int)puVar8) = 0;
            puStack_24[-1] = 0;
            *puStack_24 = 0;
            puVar10 = puStack_44;
          }
          puVar8 = puVar8 + 3;
          puStack_24 = puStack_24 + 3;
        } while ((uint *)((int)puVar10 + (int)puVar8) != puStack_20);
      }
      FUN_005e6280();
      puVar4[0x8e] = puVar4[0x8e] + -0xc;
    }
  }
  if (puVar4[7] != 0) {
    piVar5 = (int *)FUN_0097c020(&puStack_38,param_2 + 0x94,puVar4[7]);
    ppuVar3 = ppuStack_34;
    iVar11 = *piVar5;
    puVar10 = (uint *)piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    iStack_48 = iVar11;
    puStack_44 = puVar10;
    if (ppuStack_34 != (uint **)0x0) {
      LOCK();
      puVar2 = (uint *)((int)ppuStack_34[1] + -1);
      ppuStack_34[1] = puVar2;
      UNLOCK();
      if (puVar2 == (uint *)0x0) {
        (*(code *)**ppuVar3)();
        LOCK();
        puVar2 = (uint *)((int)ppuVar3[2] + -1);
        ppuVar3[2] = puVar2;
        UNLOCK();
        if (puVar2 == (uint *)0x0) {
          (*(code *)(*ppuVar3)[1])();
        }
      }
    }
    if (iVar11 != 0) {
      FUN_008a65e0(0,0);
    }
    if (puVar10 != (uint *)0x0) {
      LOCK();
      uVar7 = puVar10[1] - 1;
      puVar10[1] = uVar7;
      UNLOCK();
      if (uVar7 == 0) {
        (**(code **)*puVar10)();
        LOCK();
        puVar2 = puVar10 + 2;
        uVar7 = *puVar2;
        *puVar2 = *puVar2 - 1;
        UNLOCK();
        if (uVar7 == 1) {
          (**(code **)(*puVar10 + 4))();
        }
      }
    }
  }
  FUN_016dedfb(auStack_88);
  if (puStack_58 != (uint *)0x0) {
    uVar7 = iStack_50 - (int)puStack_58 & 0xfffffffc;
    puVar10 = puStack_58;
    if (0xfff < uVar7) {
      puVar10 = (uint *)puStack_58[-1];
      uVar7 = uVar7 + 0x23;
      if (0x1f < (uint)((int)puStack_58 + (-4 - (int)puVar10))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar10,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9302 ; VA 0x006d7910 ; FUN_006d7910 */

undefined4 __thiscall FUN_006d7910(byte *param_1,int param_2,uint *param_3)

{
  uint uVar1;
  int iVar2;
  int iStack_c;
  uint uStack_8;
  
  uStack_8 = *param_3;
  FUN_00606ea0(&iStack_c,(uStack_8 >> 3) + uStack_8,&uStack_8,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (iStack_c == 0) {
    return 0;
  }
  if ((DAT_01d5b840 != '\0') && (*(char *)(iStack_c + 0x3f) != '\0')) {
    FUN_006d7ab0(iStack_c + 0xc);
  }
  uVar1 = *(uint *)(param_2 + 0x18e8);
  if ((DAT_01d5b840 == '\0') || (*(char *)(iStack_c + 0x3f) == '\0')) {
    if ((uint)((*(int *)(iStack_c + 0x44) - *(int *)(iStack_c + 0x40)) / 0xc) <= uVar1) {
      return 0;
    }
    if (*(char *)(*(int *)(iStack_c + 0x40) + 8 + uVar1 * 0xc) == '\0') {
      return 0;
    }
  }
  if (DAT_01d5b7f8 == '\0') {
    FUN_006e0210(iStack_c + 0xc,uVar1);
  }
  FUN_006da720(param_2,*param_3,iStack_c + 0xc);
  iVar2 = *(int *)(iStack_c + 0x40);
  *(undefined *)(iVar2 + 8 + uVar1 * 0xc) = 0;
  if ((DAT_01d5b840 == '\0') || (*(char *)(iStack_c + 0x3f) == '\0')) {
    *(int *)(iStack_c + 0x38) = *(int *)(iStack_c + 0x38) + -1;
  }
  if (DAT_01d5b7f8 == '\0') {
    *(undefined2 *)(iVar2 + 9 + uVar1 * 0xc) = 0;
    *(undefined4 *)(iVar2 + uVar1 * 0xc) = 0;
  }
  FUN_006dd330(iStack_c,param_2,uVar1);
  return 1;
}



/* FUNCTION 9303 ; VA 0x006d7a30 ; FUN_006d7a30 */

void FUN_006d7a30(int param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_006dc2b0(*(undefined4 *)(param_1 + 0x1c),param_2,param_3);
  return;
}



/* FUNCTION 9304 ; VA 0x006d7a50 ; FUN_006d7a50 */

void FUN_006d7a50(int param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_006dac70(*(undefined4 *)(param_1 + 0x1c),param_2,param_3);
  return;
}



/* FUNCTION 9305 ; VA 0x006d7a70 ; FUN_006d7a70 */

void FUN_006d7a70(int param_1,undefined4 param_2)

{
  (**(code **)(param_1 + 0x18))(param_2);
  return;
}



/* FUNCTION 9306 ; VA 0x006d7a90 ; FUN_006d7a90 */

void FUN_006d7a90(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(param_1 + 0x18))(param_2,param_3);
  return;
}



/* FUNCTION 9307 ; VA 0x006d7ab0 ; FUN_006d7ab0 */

int __thiscall FUN_006d7ab0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  int *piVar7;
  
  iVar4 = *(int *)(param_1 + 0x218);
  *(int *)(param_2 + 0x2c) = iVar4;
  if (((DAT_01d5b808 != '\0') && (DAT_01d5b7f8 != '\0')) || (DAT_01d5b800 != '\0')) {
    iVar4 = FUN_006d5ca0(param_2);
  }
  piVar1 = *(int **)(param_1 + 0x1c0);
  piVar7 = *(int **)(param_1 + 0x1bc);
  do {
    if (piVar7 == piVar1) {
      *(undefined *)(param_2 + 0x33) = 0;
      return iVar4;
    }
    iVar2 = *piVar7;
    if (*(char *)(iVar2 + 0x3894) != '\0') {
      if (DAT_01d5b870 != '\0') {
        iVar6 = *(int *)(param_2 + 0x38) - *(int *)(param_2 + 0x34);
        iVar4 = iVar6 * 0x2aaaaaab;
        uVar3 = iVar6 / 0xc;
        if (uVar3 <= *(uint *)(iVar2 + 0x18e8)) {
          if (DAT_01eaf006 != '\0') {
            piVar5 = *(int **)(*(int *)(param_2 + 4) + 0x28);
            if (0xf < (uint)piVar5[5]) {
              piVar5 = (int *)*piVar5;
            }
            iVar4 = FUN_01677520(DAT_01eaf006,
                                 "downgradeAliveForAllReplicators indexing past end of conn data vector, instance %s, index %d, connData size: %zu"
                                 ,piVar5,*(uint *)(iVar2 + 0x18e8),uVar3);
          }
          goto LAB_006d7b66;
        }
      }
      iVar4 = *(int *)(param_2 + 0x34);
      *(undefined *)(iVar4 + 8 + *(int *)(iVar2 + 0x18e8) * 0xc) = 1;
    }
LAB_006d7b66:
    piVar7 = piVar7 + 1;
  } while( true );
}



/* FUNCTION 9308 ; VA 0x006d7b90 ; FUN_006d7b90 */

int * __thiscall FUN_006d7b90(uint *param_1,int *param_2,int *param_3)

{
  uint *puVar1;
  uint uVar2;
  undefined uVar3;
  int *piVar4;
  undefined4 *puVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  uint uVar10;
  int aiStack_3c [5];
  uint uStack_28;
  int *piStack_24;
  uint uStack_20;
  int *piStack_1c;
  int *piStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017a8b70;
  pvStack_10 = ExceptionList;
  uVar10 = 0;
  uStack_8 = 0;
  uStack_7 = 0;
  piStack_24 = param_2;
  uVar8 = param_2[0x10];
  uStack_20 = uVar8 >> 0x19;
  if ((int *)param_2[0xf] == (int *)(uVar8 & 0xffffff)) {
    uVar10 = 0x2000000;
  }
  ExceptionList = &pvStack_10;
  param_2[0x10] = uVar10 | uVar8 & 0xfdffffff;
  piVar4 = (int *)(uVar8 & 0xffffff);
  if ((uVar8 & 0x8000000) == 0) {
    piVar9 = (int *)(uVar10 >> 0x19);
    piStack_18 = (int *)((uVar8 & 0x1000000) >> 0x18);
    if ((piVar9 != piStack_18) || (piVar4 = (int *)(uVar8 >> 0x1a & 1), piVar9 != piVar4)) {
      if (DAT_01eaf005 != '\0') {
        puStack_14 = (uint *)param_2[10];
        if (0xf < puStack_14[5]) {
          puStack_14 = (uint *)*puStack_14;
        }
        puVar5 = (undefined4 *)FUN_009c9510(aiStack_3c);
        uStack_8 = 1;
        if (0xf < (uint)puVar5[5]) {
          puVar5 = (undefined4 *)*puVar5;
        }
        FUN_01677520(DAT_01eaf005,"%s(%s) new:%d->%d != is:%d (ack:%d)",puVar5,puStack_14,
                     uStack_20 & 1,piVar9,piStack_18,uVar8 >> 0x1a & 1);
        uStack_8 = 0;
        uVar3 = uStack_8;
        uStack_8 = 0;
        if (0xf < uStack_28) {
          uVar8 = uStack_28 + 1;
          iVar7 = aiStack_3c[0];
          if (0xfff < uVar8) {
            iVar7 = *(int *)(aiStack_3c[0] + -4);
            uVar8 = uStack_28 + 0x24;
            if (0x1f < (aiStack_3c[0] - iVar7) - 4U) {
              uStack_8 = uVar3;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar7,uVar8);
        }
      }
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[2] = param_3[2] + 1;
        UNLOCK();
      }
      uVar8 = *param_1;
      piStack_18 = param_3;
      uVar10 = param_1[2];
      piStack_1c = param_2;
      if (uVar8 < uVar10 + 1) {
        uStack_8 = 2;
        do {
          uVar8 = uVar8 * 3 >> 1;
        } while (uVar8 < uVar10 + 1);
        uStack_20 = uVar8;
        puStack_14 = (uint *)FUN_01674f30(uVar8 * 8);
        uVar10 = 0;
        if (param_1[2] != 0) {
          do {
            uVar8 = param_1[1];
            uVar6 = *param_1;
            uVar2 = param_1[3];
            puStack_14[uVar10 * 2] = 0;
            puStack_14[uVar10 * 2 + 1] = 0;
            puVar1 = (uint *)(uVar2 + ((uVar8 + uVar10) % uVar6) * 8);
            puStack_14[uVar10 * 2] = *puVar1;
            puStack_14[uVar10 * 2 + 1] = puVar1[1];
            uVar10 = uVar10 + 1;
            *puVar1 = 0;
            puVar1[1] = 0;
            uVar8 = uStack_20;
          } while (uVar10 < param_1[2]);
        }
        FUN_01674ea0(param_1[3]);
        uVar10 = param_1[2];
        param_1[3] = (uint)puStack_14;
        uVar6 = 0;
        param_1[1] = 0;
        *param_1 = uVar8;
      }
      else {
        uVar6 = param_1[1];
      }
      uVar8 = (uVar6 + uVar10) % uVar8;
      uVar10 = param_1[3];
      *(undefined4 *)(uVar10 + uVar8 * 8) = 0;
      *(undefined4 *)(uVar10 + 4 + uVar8 * 8) = 0;
      puVar5 = (undefined4 *)(uVar10 + uVar8 * 8);
      *puVar5 = piStack_1c;
      puVar5[1] = piStack_18;
      param_1[2] = param_1[2] + 1;
      piStack_24[0x10] = piStack_24[0x10] | 0x8000000;
      piVar4 = piStack_24;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar9 = param_3 + 1;
    iVar7 = *piVar9;
    piVar4 = (int *)*piVar9;
    *piVar9 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      piVar4 = (int *)(**(code **)*param_3)();
      LOCK();
      piVar9 = param_3 + 2;
      iVar7 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        piVar4 = (int *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 9309 ; VA 0x006d7df0 ; FUN_006d7df0 */

void * FUN_006d7df0(int *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  void *pvVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  int aiStack_34 [5];
  uint uStack_20;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8b90;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  pvVar3 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01eaf004 != '\0') {
    uVar5 = *(uint *)(iVar1 + 0x40);
    piVar6 = *(int **)(iVar1 + 0x28);
    piStack_18 = *(int **)(iVar1 + 0x38);
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    ExceptionList = &pvStack_10;
    puVar2 = (undefined4 *)FUN_009c9510(aiStack_34);
    uStack_8 = 0;
    if (0xf < (uint)puVar2[5]) {
      puVar2 = (undefined4 *)*puVar2;
    }
    pvVar3 = (void *)FUN_01677520(DAT_01eaf004,"parent %s(%s) expected: %d (prev: %d)",puVar2,piVar6
                                  ,piStack_18,uVar5 & 0xffffff);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_20) {
      uVar5 = uStack_20 + 1;
      iVar4 = aiStack_34[0];
      if (0xfff < uVar5) {
        iVar4 = *(int *)(aiStack_34[0] + -4);
        uVar5 = uStack_20 + 0x24;
        if (0x1f < (aiStack_34[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      pvVar3 = (void *)FUN_01674ea0(iVar4,uVar5);
    }
  }
  uVar5 = *(uint *)(iVar1 + 0x40);
  if (((uVar5 & 0x8000000) == 0) &&
     (pvVar3 = (void *)(uVar5 & 0xffffff), pvVar3 != *(void **)(iVar1 + 0x38))) {
    *(uint *)(iVar1 + 0x40) = uVar5 | 0x8000000;
    piStack_18 = (int *)param_1[1];
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
      piStack_18 = (int *)param_1[1];
    }
    iStack_1c = *param_1;
    uStack_8 = 1;
    pvVar3 = (void *)FUN_006d00d0(&iStack_1c);
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piVar6 = piStack_18 + 2;
      iVar1 = *piVar6;
      pvVar3 = (void *)*piVar6;
      *piVar6 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        pvVar3 = (void *)(**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 9310 ; VA 0x006d7f40 ; FUN_006d7f40 */

void __thiscall FUN_006d7f40(int *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  void **ppvVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  ppvVar2 = &pvStack_10;
  if ((param_3 == (int *)*piVar1) && (ppvVar2 = &pvStack_10, param_4 == piVar1)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_006d3e90(piVar1[1]);
    *(int **)(*param_1 + 4) = piVar1;
    *(int **)*param_1 = piVar1;
    *(int **)(*param_1 + 8) = piVar1;
    param_1[1] = 0;
    *param_2 = *(undefined4 *)*param_1;
    ExceptionList = pvStack_10;
    return;
  }
  while (ExceptionList = ppvVar2, param_3 != param_4) {
    FUN_00551320();
    FUN_00551320();
    uVar3 = FUN_00553830(param_3);
    FUN_0061ac80();
    FUN_01674ea0(uVar3,0x30);
    ppvVar2 = (void **)ExceptionList;
  }
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9311 ; VA 0x006d8010 ; FUN_006d8010 */

void __thiscall FUN_006d8010(int *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  void **ppvVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  ppvVar2 = &pvStack_10;
  if ((param_3 == (int *)*piVar1) && (ppvVar2 = &pvStack_10, param_4 == piVar1)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_006d3ee0(piVar1[1]);
    *(int **)(*param_1 + 4) = piVar1;
    *(int **)*param_1 = piVar1;
    *(int **)(*param_1 + 8) = piVar1;
    param_1[1] = 0;
    *param_2 = *(undefined4 *)*param_1;
    ExceptionList = pvStack_10;
    return;
  }
  while (ExceptionList = ppvVar2, param_3 != param_4) {
    FUN_00551320();
    FUN_00551320();
    uVar3 = FUN_00553830(param_3);
    thunk_FUN_00617ad0();
    FUN_01674ea0(uVar3,0x24);
    ppvVar2 = (void **)ExceptionList;
  }
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9312 ; VA 0x006d80e0 ; FUN_006d80e0 */

int __thiscall FUN_006d80e0(int *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puStack_8;
  
  puVar6 = (undefined4 *)*param_1;
  cVar2 = *(char *)((int)puVar6[1] + 0xd);
  puVar1 = puVar6;
  puStack_8 = (undefined4 *)puVar6[1];
  while (cVar2 == '\0') {
    cVar2 = FUN_009c8f70(param_2);
    if (cVar2 == '\0') {
      if ((*(char *)((int)puVar6 + 0xd) != '\0') &&
         (cVar2 = FUN_009c8f70(puStack_8 + 4), cVar2 != '\0')) {
        puVar6 = puStack_8;
      }
      puVar3 = (undefined4 *)*puStack_8;
    }
    else {
      puVar3 = (undefined4 *)puStack_8[2];
      puStack_8 = puVar1;
    }
    puVar1 = puStack_8;
    puStack_8 = puVar3;
    cVar2 = *(char *)((int)puVar3 + 0xd);
  }
  puVar3 = puVar6;
  if (*(char *)((int)puVar6 + 0xd) != '\0') {
    puVar3 = (undefined4 *)(*param_1 + 4);
  }
  cVar2 = *(char *)((int)*puVar3 + 0xd);
  puVar3 = (undefined4 *)*puVar3;
  while (cVar2 == '\0') {
    cVar2 = FUN_009c8f70(puVar3 + 4);
    if (cVar2 == '\0') {
      puVar4 = (undefined4 *)puVar3[2];
    }
    else {
      puVar4 = (undefined4 *)*puVar3;
      puVar6 = puVar3;
    }
    puVar3 = puVar4;
    cVar2 = *(char *)((int)puVar4 + 0xd);
  }
  iVar5 = 0;
  param_2 = puVar1;
  while (param_2 != puVar6) {
    iVar5 = iVar5 + 1;
    FUN_00551320();
  }
  FUN_006d8010(&param_2,puVar1,puVar6);
  return iVar5;
}



/* FUNCTION 9313 ; VA 0x006d81b0 ; FUN_006d81b0 */

int * __thiscall FUN_006d81b0(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  uint uVar5;
  
  piVar1 = (int *)*param_3;
  *param_2 = (int)piVar1;
  uVar4 = (uint)param_3[1] % *(uint *)(param_1 + 4);
  piVar2 = *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
  for (piVar3 = (int *)*piVar2; piVar3 != param_3; piVar3 = (int *)*piVar3) {
    piVar2 = piVar3;
  }
  do {
    *piVar2 = *piVar3;
    FUN_01674ea0(piVar3,0x10);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    uVar5 = uVar4;
    if (*piVar2 == 0) {
LAB_006d821f:
      if (*(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4) == piVar2) {
        *(undefined4 *)(*(int *)(param_1 + 0x14) + uVar4 * 4) = 0;
      }
    }
    else {
      uVar5 = *(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 4);
      if (uVar4 != uVar5) {
        *(int **)(*(int *)(param_1 + 0x14) + uVar5 * 4) = piVar2;
        goto LAB_006d821f;
      }
    }
    piVar3 = (int *)*piVar2;
    uVar4 = uVar5;
    if (piVar3 == piVar1) {
      return param_2;
    }
  } while( true );
}



/* FUNCTION 9314 ; VA 0x006d8250 ; FUN_006d8250 */

int * __thiscall FUN_006d8250(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  
  piVar1 = (int *)*param_3;
  *param_2 = (int)piVar1;
  uVar3 = (uint)param_3[1] % *(uint *)(param_1 + 4);
  piVar2 = *(int **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  for (piVar5 = (int *)*piVar2; piVar5 != param_3; piVar5 = (int *)*piVar5) {
    piVar2 = piVar5;
  }
  do {
    *piVar2 = *piVar5;
    FUN_006cffc0(-(uint)(param_1 != -3) & param_1 + 4U,piVar5 + 2);
    FUN_01674ea0(piVar5,0x4c);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    uVar4 = uVar3;
    if (*piVar2 == 0) {
LAB_006d82d9:
      if (*(int **)(*(int *)(param_1 + 0x14) + uVar3 * 4) == piVar2) {
        *(undefined4 *)(*(int *)(param_1 + 0x14) + uVar3 * 4) = 0;
      }
    }
    else {
      uVar4 = *(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 4);
      if (uVar3 != uVar4) {
        *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4) = piVar2;
        goto LAB_006d82d9;
      }
    }
    piVar5 = (int *)*piVar2;
    uVar3 = uVar4;
    if (piVar5 == piVar1) {
      return param_2;
    }
  } while( true );
}



/* FUNCTION 9315 ; VA 0x006d8310 ; FUN_006d8310 */

undefined4 __thiscall FUN_006d8310(int param_1,int param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  uint uVar7;
  
  if (*(int *)(param_1 + 8) == 0) {
    return 0;
  }
  iVar3 = FUN_009c91f0(param_2);
  uVar4 = iVar3 + 0x9e3779b9;
  uVar4 = (uVar4 >> 2) +
          uVar4 * 0x40 + *(uint *)(param_2 + 8) + (*(uint *)(param_2 + 8) >> 3) + 0x9e3779b9 ^ uVar4
  ;
  uVar7 = uVar4 % *(uint *)(param_1 + 4);
  piVar1 = *(int **)(uVar7 * 4 + *(int *)(param_1 + 0x14));
  if (piVar1 != (int *)0x0) {
    iVar3 = *piVar1;
    while ((iVar3 != 0 && (*(uint *)(iVar3 + 4) % *(uint *)(param_1 + 4) == uVar7))) {
      if ((*(uint *)(iVar3 + 4) == uVar4) &&
         ((cVar2 = FUN_009c8f50(iVar3 + 8), cVar2 != '\0' &&
          (*(int *)(param_2 + 8) == *(int *)(iVar3 + 0x10))))) {
        uVar5 = FUN_0061ae50(piVar1,*(undefined4 *)*piVar1);
        if (*piVar1 != 0) {
          uVar4 = *(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 4);
          if (uVar7 == uVar4) {
            return uVar5;
          }
          *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4) = piVar1;
        }
        puVar6 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
        if ((int *)*puVar6 == piVar1) {
          *puVar6 = 0;
        }
        return uVar5;
      }
      piVar1 = (int *)*piVar1;
      iVar3 = *piVar1;
    }
  }
  return 0;
}



/* FUNCTION 9316 ; VA 0x006d8410 ; FUN_006d8410 */

void FUN_006d8410(int *param_1)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  int aiStack_2c [5];
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01eaf005 != '\0') {
    piVar5 = *(int **)(*param_1 + 0x28);
    uVar1 = *(undefined4 *)(*param_1 + 0x3c);
    if (0xf < (uint)piVar5[5]) {
      piVar5 = (int *)*piVar5;
    }
    ExceptionList = &pvStack_10;
    puVar2 = (undefined4 *)FUN_009c9510(aiStack_2c);
    uStack_8 = 0;
    if (0xf < (uint)puVar2[5]) {
      puVar2 = (undefined4 *)*puVar2;
    }
    FUN_01677520(DAT_01eaf005,"%s(%s) upd expected: %d",puVar2,piVar5,uVar1);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_18) {
      uVar4 = uStack_18 + 1;
      iVar3 = aiStack_2c[0];
      if (0xfff < uVar4) {
        iVar3 = *(int *)(aiStack_2c[0] + -4);
        uVar4 = uStack_18 + 0x24;
        if (0x1f < (aiStack_2c[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar4);
    }
  }
  if (param_1[1] != 0) {
    LOCK();
    piVar5 = (int *)(param_1[1] + 4);
    *piVar5 = *piVar5 + 1;
    UNLOCK();
  }
  FUN_006d7b90(*param_1,param_1[1]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9317 ; VA 0x006d8510 ; FUN_006d8510 */

void __thiscall FUN_006d8510(int *param_1,int *param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar2 = (undefined4 *)*param_1;
  puVar3 = (undefined4 *)puVar2[1];
  puVar4 = puVar2;
  if (*(char *)((int)puVar2[1] + 0xd) == '\0') {
    do {
      cVar1 = FUN_009c8f70(param_3);
      if (cVar1 == '\0') {
        puVar2 = (undefined4 *)*puVar3;
        puVar4 = puVar3;
      }
      else {
        puVar2 = (undefined4 *)puVar3[2];
      }
      puVar3 = puVar2;
    } while (*(char *)((int)puVar2 + 0xd) == '\0');
    puVar2 = (undefined4 *)*param_1;
  }
  if ((puVar4 != puVar2) && (cVar1 = FUN_009c8f70(puVar4 + 4), cVar1 == '\0')) {
    *param_2 = (int)puVar4;
    return;
  }
  *param_2 = *param_1;
  return;
}



/* FUNCTION 9318 ; VA 0x006d8590 ; FUN_006d8590 */

int __fastcall FUN_006d8590(byte *param_1)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  uint *puVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  undefined4 uVar8;
  int iVar9;
  uint *puVar10;
  int *piVar11;
  undefined **ppuStack_78;
  undefined *puStack_74;
  undefined4 uStack_70;
  int *piStack_6c;
  int iStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  uint uStack_54;
  int *piStack_50;
  uint uStack_4c;
  int *piStack_48;
  int iStack_44;
  int *piStack_40;
  uint *puStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int *piStack_2c;
  uint *puStack_28;
  uint uStack_24;
  int iStack_20;
  int iStack_1c;
  uint uStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a8bd7;
  pvStack_10 = ExceptionList;
  piStack_40 = *(int **)(param_1 + 0x238);
  piVar11 = *(int **)(param_1 + 0x234);
  iStack_20 = 0;
  uStack_18 = 0;
  iVar9 = 0;
  if (piVar11 != piStack_40) {
    iStack_1c = 0;
    ExceptionList = &pvStack_10;
    pbStack_14 = param_1;
    do {
      if ((uint)(*(int *)(pbStack_14 + 0x1c0) - *(int *)(pbStack_14 + 0x1bc) >> 2) <= uStack_18) {
        ExceptionList = pvStack_10;
        return iStack_20;
      }
      puVar10 = (uint *)*piVar11;
      puStack_3c = (uint *)piVar11[1];
      piStack_2c = piVar11;
      if (puVar10 != puStack_3c) {
        do {
          piVar11 = (int *)puVar10[1];
          if (piVar11 != (int *)0x0) {
            LOCK();
            piVar11[2] = piVar11[2] + 1;
            UNLOCK();
            piVar11 = (int *)puVar10[1];
          }
          uStack_54 = *puVar10;
          uStack_8 = 0;
          uStack_4c = 0;
          piStack_48 = (int *)0x0;
          uVar6 = uStack_4c;
          piVar5 = piStack_48;
          if (piVar11 != (int *)0x0) {
            piVar1 = piVar11 + 1;
            iVar9 = piVar11[1];
            while (uVar6 = uStack_4c, piVar5 = piStack_48, iVar9 != 0) {
              LOCK();
              iVar7 = *piVar1;
              if (iVar9 == iVar7) {
                *piVar1 = iVar9 + 1;
                iVar7 = iVar9;
              }
              UNLOCK();
              uVar6 = uStack_54;
              piVar5 = piVar11;
              if (iVar7 == iVar9) break;
              iVar9 = *piVar1;
            }
          }
          piStack_48 = piVar5;
          uStack_4c = uVar6;
          piVar5 = piStack_48;
          piStack_50 = piVar11;
          puStack_28 = puVar10;
          if ((((uStack_4c != 0) &&
               (uStack_24 = uStack_4c,
               FUN_00606ea0(&iStack_30,(uStack_4c >> 3) + uStack_4c,&uStack_24,
                            -(uint)(pbStack_14 + *pbStack_14 + 1 != (byte *)0x0) &
                            (uint)(pbStack_14 + *pbStack_14 + 1 + 1)), iVar9 = iStack_30,
               iStack_30 != 0)) && (iStack_30 != -0xc)) &&
             ((uStack_24 = *(uint *)(iStack_30 + 0x40),
              uStack_18 < (uint)((int)(*(int *)(iStack_30 + 0x44) - uStack_24) / 0xc) &&
              (cVar3 = *(char *)(uStack_24 + 9 + iStack_1c),
              cVar3 != *(char *)(uStack_24 + 10 + iStack_1c))))) {
            uStack_60 = 0;
            uStack_5c = 0;
            uStack_58 = 0;
            iStack_38 = *(int *)(*(int *)(pbStack_14 + 0x1bc) + uStack_18 * 4);
            iStack_34 = iStack_38 + 0x94;
            puStack_74 = &DAT_0212d228;
            if (cVar3 == '\0') {
              puStack_74 = &DAT_0212d270;
            }
            uStack_8._0_1_ = 3;
            ppuStack_78 = RBX::Instance::EventInvocationSignalData::vftable;
            iStack_44 = FUN_01674e20(0xc);
            uStack_8._0_1_ = 4;
            if (iStack_44 == 0) {
              uVar8 = 0;
            }
            else {
              uVar8 = FUN_006d07c0(&uStack_60);
            }
            uStack_8._0_1_ = 3;
            uStack_70 = 0;
            piStack_6c = (int *)0x0;
            FUN_006047e0(uVar8,iStack_44);
            iStack_68 = iStack_34;
            uStack_64 = 0;
            uStack_8 = CONCAT31(uStack_8._1_3_,5);
            FUN_006224b0(iVar9 + 0x10,*(undefined4 *)(iVar9 + 0x28),&ppuStack_78);
            piVar1 = piStack_6c;
            iStack_20 = iStack_20 + 1;
            *(undefined *)(uStack_24 + 10 + iStack_1c) = *(undefined *)(uStack_24 + 9 + iStack_1c);
            if (piStack_6c != (int *)0x0) {
              LOCK();
              iVar9 = piStack_6c[1] + -1;
              piStack_6c[1] = iVar9;
              UNLOCK();
              if (iVar9 == 0) {
                (**(code **)*piStack_6c)();
                LOCK();
                piVar2 = piVar1 + 2;
                iVar9 = *piVar2 + -1;
                *piVar2 = iVar9;
                UNLOCK();
                if (iVar9 == 0) {
                  (**(code **)(*piVar1 + 4))();
                }
              }
            }
            ppuStack_78 = RBX::Instance::ICombinedSignalData::vftable;
            uStack_8 = CONCAT31(uStack_8._1_3_,6);
            FUN_00577b20();
          }
          if (piVar5 != (int *)0x0) {
            LOCK();
            iVar9 = piVar5[1] + -1;
            piVar5[1] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)*piVar5)();
              LOCK();
              iVar9 = piVar5[2] + -1;
              piVar5[2] = iVar9;
              UNLOCK();
              if (iVar9 == 0) {
                (**(code **)(*piVar5 + 4))();
              }
            }
          }
          uStack_8 = 0xffffffff;
          if (piVar11 != (int *)0x0) {
            LOCK();
            iVar9 = piVar11[2] + -1;
            piVar11[2] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piVar11 + 4))();
            }
          }
          piVar11 = piStack_2c;
          puStack_28 = puStack_28 + 2;
          puVar10 = puStack_28;
        } while (puStack_28 != puStack_3c);
        puVar4 = (uint *)piStack_2c[1];
        puVar10 = (uint *)*piStack_2c;
        if (puVar10 != puVar4) {
          do {
            piVar5 = (int *)puVar10[1];
            if (piVar5 != (int *)0x0) {
              LOCK();
              iVar9 = piVar5[2] + -1;
              piVar5[2] = iVar9;
              UNLOCK();
              if (iVar9 == 0) {
                (**(code **)(*piVar5 + 4))();
              }
            }
            puVar10 = puVar10 + 2;
          } while (puVar10 != puVar4);
          puVar10 = (uint *)*piVar11;
        }
      }
      iStack_1c = iStack_1c + 0xc;
      uStack_18 = uStack_18 + 1;
      piVar11[1] = (int)puVar10;
      piVar11 = piVar11 + 3;
      iVar9 = iStack_20;
    } while (piVar11 != piStack_40);
  }
  ExceptionList = pvStack_10;
  return iVar9;
}



/* FUNCTION 9319 ; VA 0x006d88d0 ; FUN_006d88d0 */

undefined4 * __thiscall FUN_006d88d0(byte *param_1,undefined4 *param_2,uint param_3)

{
  int *piVar1;
  undefined4 uVar2;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8bff;
  pvStack_10 = ExceptionList;
  if (param_1[0x18] == 0) {
    *param_2 = 0;
    param_2[1] = 0;
    return param_2;
  }
  ExceptionList = &pvStack_10;
  pbStack_14 = param_1;
  FUN_00606ea0(&pbStack_14,(param_3 >> 3) + param_3,&param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (pbStack_14 != (byte *)0x0) {
    *param_2 = 0;
    param_2[1] = 0;
    if (*(int *)(pbStack_14 + 0x1c) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(pbStack_14 + 0x1c) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *param_2 = *(undefined4 *)(pbStack_14 + 0x18);
    param_2[1] = *(undefined4 *)(pbStack_14 + 0x1c);
    ExceptionList = pvStack_10;
    return param_2;
  }
  param_3 = FUN_01674e20(0x44);
  uStack_8 = 0;
  if (param_3 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_0060edf0(1);
  }
  uStack_8 = 0xffffffff;
  *param_2 = 0;
  param_2[1] = 0;
  FUN_006cf510(uVar2,param_2);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9320 ; VA 0x006d89e0 ; FUN_006d89e0 */

void __thiscall FUN_006d89e0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined8 uStack_34;
  int iStack_2c;
  int iStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8c48;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  if (*(char *)(param_1 + 0x18) == '\0') {
    *param_2 = 0;
    param_2[1] = 0;
    return;
  }
  iVar4 = param_1 + 0x18d + (uint)*(byte *)(param_1 + 0x18c);
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_00606ea0(&iStack_14,((uint)param_3 >> 3) + (int)param_3,&param_3,
               -(uint)(iVar4 != 0) & iVar4 + 1U);
  iVar4 = iStack_14;
  if (iStack_14 == 0) {
    uStack_34 = 0;
    iStack_2c = iStack_14;
    iStack_8 = iStack_14;
    FUN_006d0130(&iStack_28,&param_3,&param_3,&uStack_34);
    iVar4 = iStack_28;
    iStack_8 = 0xffffffff;
    FUN_006d27f0();
    iStack_14 = FUN_01674e20(0x44);
    iStack_8 = 1;
    if (iStack_14 == 0) {
      uVar3 = 0;
    }
    else {
      uVar3 = FUN_0060edf0(1);
    }
    iStack_8 = 0xffffffff;
    iStack_28 = 0;
    puStack_24 = (undefined4 *)0x0;
    FUN_006cf510(uVar3,param_3);
    *(int *)(iVar4 + 0x10) = iStack_28;
    piVar2 = *(int **)(iVar4 + 0x14);
    *(undefined4 **)(iVar4 + 0x14) = puStack_24;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar5 = piVar2[1] + -1;
      piVar2[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar5 = piVar2[2] + -1;
        piVar2[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    iStack_14 = (int)param_3 + 0x50;
    iStack_8 = 2;
    uVar3 = FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 3;
    uStack_20 = uVar3;
    puStack_24 = (undefined4 *)FUN_01674e20(0x20);
    if (puStack_24 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      *puStack_24 = 0;
      puStack_24[1] = 1;
      puStack_24[2] = FUN_006d7a30;
      puStack_24[3] = _guard_check_icall;
      puStack_24[4] = 0;
      puStack_24[6] = iStack_18;
      puStack_24[5] = iStack_14;
      puStack_24[7] = param_3;
      puVar6 = puStack_24;
    }
    FUN_016797d0(puVar6);
    if (puVar6 != (undefined4 *)0x0) {
      LOCK();
      puVar6[1] = puVar6[1] + 1;
      UNLOCK();
    }
    uStack_1c = 2;
    iStack_8 = CONCAT31(iStack_8._1_3_,4);
    param_3 = puVar6;
    FUN_01675290(uVar3);
    iVar5 = *(int *)(iVar4 + 0xc);
    *(undefined4 **)(iVar4 + 0xc) = puVar6;
    if (iVar5 != 0) {
      piVar2 = (int *)(iVar5 + 4);
      LOCK();
      iVar1 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        FUN_01674ea0(iVar5);
      }
    }
  }
  iVar5 = *(int *)(iVar4 + 0x14);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar5 != 0) {
    LOCK();
    *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
    UNLOCK();
    iVar5 = *(int *)(iVar4 + 0x14);
  }
  *param_2 = *(undefined4 *)(iVar4 + 0x10);
  param_2[1] = iVar5;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9321 ; VA 0x006d8c20 ; FUN_006d8c20 */

int __thiscall FUN_006d8c20(int param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 *puVar5;
  char cVar6;
  int iVar7;
  undefined4 uVar8;
  int iVar9;
  int iVar10;
  int *piVar11;
  int *piVar12;
  undefined8 uVar13;
  undefined8 uVar14;
  int iStack_50;
  int *piStack_4c;
  int iStack_48;
  undefined uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8c9b;
  pvStack_10 = ExceptionList;
  iVar10 = param_1 + 0x74;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  FUN_006d05f0(iVar10);
  if (*(char *)(param_1 + 0x84) == '\0') {
    FUN_006d1a70();
    uStack_44 = 0;
    iStack_48 = iVar10;
    if (iVar10 == 0) {
      uVar8 = FUN_0056aeb0(1,"boost unique_lock has no mutex");
      uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
      FUN_00564990(uVar8);
    }
    uStack_40 = 0xffffffff;
    uStack_3c = 0x7fffffff;
    iStack_2c = -1;
    FUN_005672c0(&iStack_2c,&uStack_40);
    FUN_006dfad0(&iStack_50);
    uStack_44 = 1;
    uStack_8 = 2;
    if (*(char *)(param_1 + 0x84) == '\0') {
      iStack_34 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
      if ((*(int *)(iStack_34 + 0x34) < DAT_01eaf0e8) &&
         (FUN_016f3809(&DAT_01eaf0e8), DAT_01eaf0e8 == -1)) {
        uStack_8._0_1_ = 3;
        uVar13 = FUN_0152dab0(&DAT_018c5904,"MegaPhysics Collecting",0xffffffff);
        DAT_01eaf0e4 = (undefined4)((ulonglong)uVar13 >> 0x20);
        DAT_01eaf0e0 = (undefined4)uVar13;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_016f37bf(&DAT_01eaf0e8);
      }
      uStack_3c = DAT_01eaf0e0;
      uStack_38 = DAT_01eaf0e4;
      uVar13 = FUN_0152d930(DAT_01eaf0e0,DAT_01eaf0e4);
      FUN_00587490(&iStack_50);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      if (iStack_50 != 0) {
        piVar11 = (int *)(param_1 + 0x68);
        iVar10 = *(int *)(*(int *)(*(int *)(iStack_50 + 0x1b8) + 0x1b4) + 0x6d0);
        iStack_30 = iVar10;
        FUN_006ce0c0(*piVar11,*(undefined4 *)(param_1 + 0x6c),piVar11);
        iVar9 = 0;
        *(int *)(param_1 + 0x6c) = *piVar11;
        iStack_28 = 0;
        iStack_18 = 0;
        iStack_2c = 0;
        do {
          uStack_11 = 1 < iStack_2c;
          if (iStack_2c == 2) {
            iVar9 = iVar9 + *(int *)(iVar10 + 0x54);
            iStack_28 = iVar9;
          }
          else {
            iStack_18 = iStack_18 + *(int *)(iVar10 + 0x44 + iStack_2c * 8);
          }
          puVar1 = *(undefined4 **)(iVar10 + 0x40 + iStack_2c * 8);
          puVar2 = (undefined4 *)*puVar1;
          iVar10 = iStack_30;
          iVar4 = iStack_1c;
          while (iStack_30 = iVar10, iStack_1c = iVar4, puVar2 != puVar1) {
            iStack_20 = puVar2[4];
            uStack_24 = FUN_00b06610(iStack_20);
            cVar6 = FUN_00b07c90();
            if (cVar6 == '\0') {
              if (*(int *)(param_1 + 0x70) == *(int *)(param_1 + 0x6c)) {
                FUN_006ce180(*(int *)(param_1 + 0x6c),&uStack_24,&iStack_20,&uStack_11);
              }
              else {
                FUN_006cfe30(piVar11);
                *(int *)(param_1 + 0x6c) = *(int *)(param_1 + 0x6c) + 0x90;
              }
            }
            puVar3 = (undefined4 *)puVar2[2];
            iVar9 = iStack_28;
            iVar10 = iStack_30;
            iVar4 = iStack_1c;
            if (*(char *)((int)puVar3 + 0xd) == '\0') {
              cVar6 = *(char *)((int)*puVar3 + 0xd);
              puVar2 = puVar3;
              puVar3 = (undefined4 *)*puVar3;
              while (cVar6 == '\0') {
                cVar6 = *(char *)((int)*puVar3 + 0xd);
                puVar2 = puVar3;
                puVar3 = (undefined4 *)*puVar3;
              }
            }
            else {
              cVar6 = *(char *)((int)puVar2[1] + 0xd);
              puVar5 = (undefined4 *)puVar2[1];
              puVar3 = puVar2;
              while ((puVar2 = puVar5, cVar6 == '\0' && (puVar3 == (undefined4 *)puVar2[2]))) {
                cVar6 = *(char *)((int)puVar2[1] + 0xd);
                puVar5 = (undefined4 *)puVar2[1];
                puVar3 = puVar2;
              }
            }
          }
          iStack_2c = iStack_2c + 1;
          iVar7 = 7;
          if (*(int *)(iVar4 + 0x1c) == 0) {
            iVar7 = 2;
          }
        } while (iStack_2c <= iVar7);
        *(int *)(param_2 + 0x3ad8) = iVar9;
        *(int *)(param_2 + 0x3ad4) = iStack_18 + iVar9;
        if ((*(int *)(iStack_34 + 0x34) < DAT_01eaf0f8) &&
           (FUN_016f3809(&DAT_01eaf0f8), DAT_01eaf0f8 == -1)) {
          uStack_8._0_1_ = 6;
          uVar14 = FUN_0152da50(&DAT_018c5904);
          DAT_01eaf0f4 = (undefined4)((ulonglong)uVar14 >> 0x20);
          DAT_01eaf0f0 = (undefined4)uVar14;
          uStack_8 = CONCAT31(uStack_8._1_3_,5);
          FUN_016f37bf(&DAT_01eaf0f8);
        }
        FUN_0152d760(DAT_01eaf0f0,DAT_01eaf0f4,"Amount gathered: %zu",
                     (*(int *)(param_1 + 0x6c) - *piVar11) / 0x90);
        piVar11 = *(int **)(param_1 + 0x6c);
        param_1 = iStack_1c;
        for (piVar12 = *(int **)(iVar4 + 0x68); iStack_1c = param_1, piVar12 != piVar11;
            piVar12 = piVar12 + 0x24) {
          FUN_00c1a000(*(undefined4 *)(*piVar12 + 0xa8));
          iVar9 = FUN_00c1a0f0();
          iVar10 = 0;
          if (iVar9 != -0xc) {
            iVar10 = iVar9;
          }
          FUN_006d3730(iVar10);
          FUN_006d0470(piVar12);
          param_1 = iStack_1c;
        }
      }
      if (piStack_4c != (int *)0x0) {
        LOCK();
        iVar10 = piStack_4c[1] + -1;
        piStack_4c[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piStack_4c)();
          LOCK();
          piVar11 = piStack_4c + 2;
          iVar10 = *piVar11;
          *piVar11 = *piVar11 + -1;
          UNLOCK();
          if (iVar10 == 1) {
            (**(code **)(*piStack_4c + 4))();
          }
        }
      }
      *(undefined *)(param_1 + 0x84) = 1;
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      FUN_0152dda0(uStack_3c,uStack_38,uVar13);
    }
    FUN_006e00b0();
  }
  else {
    FUN_006d1a70();
  }
  ExceptionList = pvStack_10;
  return param_1 + 0x68;
}



/* FUNCTION 9322 ; VA 0x006d9010 ; FUN_006d9010 */

undefined4 __thiscall FUN_006d9010(int param_1,int param_2,int param_3)

{
  if (param_2 != 0) {
    FUN_006d8510(&param_2,param_2 + 0x18);
    if (param_2 != *(int *)(param_1 + 0x24c)) {
      if (param_3 != param_2 + 0x18) {
        FUN_006d5a60(param_2 + 0x18,param_2);
      }
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 9323 ; VA 0x006d9060 ; FUN_006d9060 */

undefined4 __fastcall FUN_006d9060(int param_1)

{
  return *(undefined4 *)(param_1 + 0x1e4);
}



/* FUNCTION 9324 ; VA 0x006d9070 ; FUN_006d9070 */

int __fastcall FUN_006d9070(int param_1)

{
  return param_1 + 200;
}



/* FUNCTION 9325 ; VA 0x006d9080 ; FUN_006d9080 */

undefined4 __fastcall FUN_006d9080(int param_1)

{
  return *(undefined4 *)(param_1 + 0xbc);
}



/* FUNCTION 9326 ; VA 0x006d9090 ; FUN_006d9090 */

int FUN_006d9090(uint *param_1)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  undefined4 uVar5;
  int iVar6;
  undefined auStack_1c [8];
  uint uStack_14;
  uint uStack_10;
  uint uStack_c;
  int iStack_8;
  
  if ((*param_1 == 0xffffffff) && (param_1[1] == 0x7fffffff)) {
    return -1;
  }
  FUN_005f0a90(&uStack_c,FUN_005f1e70);
  if (((int)param_1[1] <= iStack_8) && (((int)param_1[1] < iStack_8 || (*param_1 <= uStack_c)))) {
    return 0;
  }
  uVar1 = *param_1;
  uVar2 = param_1[1];
  if (((((uVar1 == 0) && (uVar2 == 0x80000000)) ||
       ((((uVar1 == 0xffffffff && (uVar2 == 0x7fffffff)) ||
         ((uVar1 == 0xfffffffe && (uVar2 == 0x7fffffff)))) ||
        ((uStack_c == 0 && (iStack_8 == -0x80000000)))))) ||
      ((uStack_c == 0xffffffff && (iStack_8 == 0x7fffffff)))) ||
     ((uStack_c == 0xfffffffe && (iStack_8 == 0x7fffffff)))) {
    uStack_10 = param_1[1];
    uStack_14 = uVar1;
    piVar4 = (int *)FUN_00602640(auStack_1c,&uStack_c);
    iVar6 = *piVar4;
    iVar3 = piVar4[1];
    if ((iVar6 == -2) && (iVar3 == 0x7fffffff)) {
      FUN_0056b510(0);
    }
    else if ((iVar6 == 0) && (iVar3 == -0x80000000)) {
      FUN_0056b510(1);
    }
    else {
      if ((iVar6 != -1) || (uVar5 = 2, iVar3 != 0x7fffffff)) {
        uVar5 = 5;
      }
      FUN_0056b510(uVar5);
    }
  }
  else {
    FUN_005ef640(0,0,0,uVar1 - uStack_c,(uVar2 - iStack_8) - (uint)(uVar1 < uStack_c));
  }
  iVar6 = FUN_016f3900(uStack_c,iStack_8,1000,0);
  return iVar6 + 1;
}



/* FUNCTION 9327 ; VA 0x006d91e0 ; FUN_006d91e0 */

bool __thiscall FUN_006d91e0(byte *param_1,uint *param_2)

{
  byte *pbStack_8;
  
  param_2 = (uint *)*param_2;
  pbStack_8 = param_1;
  FUN_00606ea0(&pbStack_8,((uint)param_2 >> 3) + (int)param_2,&param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  return pbStack_8 != (byte *)0x0;
}



/* FUNCTION 9328 ; VA 0x006d9230 ; FUN_006d9230 */

void __thiscall FUN_006d9230(byte *param_1,int param_2,uint param_3)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iStack_8;
  
  FUN_00606ea0(&iStack_8,(param_3 >> 3) + param_3,&param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (iStack_8 == 0) goto LAB_006d9369;
  uVar2 = *(uint *)(param_2 + 0x18e8);
  if (((DAT_01d5b808 == '\0') || (DAT_01d5b7f8 == '\0')) && (DAT_01d5b800 == '\0')) {
    iVar3 = *(int *)(iStack_8 + 0x40);
    if (((uint)((*(int *)(iStack_8 + 0x44) - iVar3) / 0xc) <= uVar2) ||
       (((DAT_01d5b840 == '\0' || (*(char *)(iStack_8 + 0x3f) == '\0')) &&
        (*(char *)(iVar3 + 8 + uVar2 * 0xc) == '\0')))) goto LAB_006d9369;
    goto LAB_006d9327;
  }
  if (DAT_01d5b840 == '\0') {
LAB_006d92e2:
    if (((uint)((*(int *)(iStack_8 + 0x44) - *(int *)(iStack_8 + 0x40)) / 0xc) <= uVar2) ||
       (*(char *)(*(int *)(iStack_8 + 0x40) + 8 + uVar2 * 0xc) == '\0')) {
LAB_006d9369:
      iVar3 = FUN_006d2b60(&param_3);
      *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
      return;
    }
  }
  else {
    if ((*(char *)(iStack_8 + 0x3f) != '\0') &&
       ((uint)((*(int *)(iStack_8 + 0x44) - *(int *)(iStack_8 + 0x40)) / 0xc) <= uVar2)) {
      FUN_006d5ca0(iStack_8 + 0xc);
    }
    if ((DAT_01d5b840 == '\0') || (*(char *)(iStack_8 + 0x3f) == '\0')) goto LAB_006d92e2;
  }
  iVar3 = *(int *)(iStack_8 + 0x40);
  if ((uint)((*(int *)(iStack_8 + 0x44) - iVar3) / 0xc) <= uVar2) {
    return;
  }
LAB_006d9327:
  piVar1 = (int *)(iVar3 + 4 + uVar2 * 0xc);
  *piVar1 = *piVar1 + 1;
  return;
}



/* FUNCTION 9329 ; VA 0x006d9390 ; FUN_006d9390 */

int __thiscall
FUN_006d9390(byte *param_1,int param_2,int param_3,uint *param_4,int param_5,int *param_6)

{
  uint *puVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  undefined4 *puVar8;
  int *piVar9;
  int *piVar10;
  undefined auStack_4c [24];
  undefined auStack_34 [4];
  int *piStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  byte *pbStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar6 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8cd1;
  pvStack_10 = ExceptionList;
  piStack_24 = (int *)0x0;
  puStack_1c = (undefined4 *)0x0;
  if (param_2 == 0) {
    return 0;
  }
  piVar9 = (int *)(param_2 + 0x34);
  piVar10 = (int *)((*(int *)(param_2 + 0x38) - *piVar9) / 0xc);
  piVar4 = (int *)(*(int *)(param_1 + 0x1c0) - *(int *)(param_1 + 0x1bc) >> 2);
  ExceptionList = &pvStack_10;
  pbStack_18 = param_1;
  if ((piVar10 < piVar4) &&
     (ExceptionList = &pvStack_10, FUN_006b2d20(piVar4,piVar9),
     piVar10 < (int *)((*(int *)(iVar6 + 0x38) - *piVar9) / 0xc))) {
    do {
      piStack_20 = piVar10;
      if ((DAT_01d5b840 != '\0') &&
         (((*(char *)(iVar6 + 0x33) != '\0' && (param_5 == 1)) &&
          (piVar10 != *(int **)(param_3 + 0x18e8))))) {
        piStack_24 = (int *)*param_4;
        iVar5 = FUN_006d2fb0(&piStack_24);
        puVar1 = *(uint **)(iVar5 + 8);
        if (*(uint **)(iVar5 + 0xc) == puVar1) {
          FUN_00595d30(puVar1,&piStack_20);
        }
        else {
          *puVar1 = (uint)piVar10;
          *(int *)(iVar5 + 8) = *(int *)(iVar5 + 8) + 4;
          piStack_20 = piVar10;
        }
      }
      *(undefined *)(*piVar9 + 8 + (int)piStack_20 * 0xc) = 0;
      *(undefined4 *)(*piVar9 + 4 + (int)piStack_20 * 0xc) = 0;
      if (DAT_01d5b7f8 == '\0') {
        *(undefined *)(*piVar9 + 9 + (int)piStack_20 * 0xc) = 0;
        *(undefined *)(*piVar9 + 10 + (int)piStack_20 * 0xc) = 0;
        *(undefined4 *)(*piVar9 + (int)piStack_20 * 0xc) = 0;
      }
      piVar10 = (int *)((int)piStack_20 + 1);
    } while (piVar10 < (int *)((*(int *)(iVar6 + 0x38) - *piVar9) / 0xc));
  }
  piStack_20 = (int *)(*piVar9 + *(int *)(param_3 + 0x18e8) * 0xc);
  if (((*(char *)(*piVar9 + 8 + *(int *)(param_3 + 0x18e8) * 0xc) != '\0') ||
      ((piStack_20[1] = 0, DAT_01d5b840 != '\0' && (*(char *)(iVar6 + 0x33) != '\0')))) ||
     (*(int *)(iVar6 + 0x2c) = *(int *)(iVar6 + 0x2c) + 1, DAT_01d5b7f8 != '\0')) goto LAB_006d9712;
  puVar8 = puStack_1c;
  if ((DAT_01d5b820 == '\0') || (*(int *)(pbStack_18 + 0x1c) == 0)) {
LAB_006d9573:
    cStack_11 = '\0';
  }
  else {
    piVar10 = (int *)(**(code **)(**(int **)(iVar6 + 4) + 0x40))(auStack_2c);
    uStack_8 = 0;
    piStack_24 = (int *)0x1;
    puVar8 = (undefined4 *)0x1;
    if (*piVar10 == 0) goto LAB_006d9573;
    piVar10 = (int *)(**(code **)(**(int **)(iVar6 + 4) + 0x40))(auStack_34);
    puVar8 = (undefined4 *)0x3;
    if (*(int *)*piVar10 == ((int *)*piVar10)[1]) goto LAB_006d9573;
    cStack_11 = '\x01';
  }
  if (((uint)puVar8 & 2) != 0) {
    puStack_1c = (undefined4 *)((uint)puVar8 & 0xfffffffd);
    piStack_24 = piStack_30;
    puVar8 = puStack_1c;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_30[1] + -1;
      piStack_30[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        iVar5 = piStack_24[2] + -1;
        piStack_24[2] = iVar5;
        UNLOCK();
        puVar8 = puStack_1c;
        if (iVar5 == 0) {
          (**(code **)(*piStack_24 + 4))();
          puVar8 = puStack_1c;
        }
      }
    }
  }
  uStack_8 = 0xffffffff;
  if ((((uint)puVar8 & 1) != 0) && (piStack_24 = piStack_28, piStack_28 != (int *)0x0)) {
    LOCK();
    iVar5 = piStack_28[1] + -1;
    piStack_28[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      iVar5 = piStack_24[2] + -1;
      piStack_24[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (cStack_11 != '\0') {
    puStack_1c = (undefined4 *)(**(code **)(**(int **)(iVar6 + 4) + 0x40))(auStack_34);
    piStack_24 = piStack_30;
    puStack_1c = (undefined4 *)*puStack_1c;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_30[1] + -1;
      piStack_30[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        iVar5 = piStack_24[2] + -1;
        piStack_24[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    piVar4 = piStack_20;
    iVar5 = param_3;
    piVar10 = (int *)*puStack_1c;
    piStack_30 = (int *)puStack_1c[1];
    if (piVar10 != piStack_30) {
      do {
        piStack_24 = (int *)*piVar10;
        FUN_00606ea0(&puStack_1c,((uint)piStack_24 >> 3) + *piVar10,&piStack_24,
                     -(uint)(pbStack_18 + *pbStack_18 + 1 != (byte *)0x0) &
                     (uint)(pbStack_18 + *pbStack_18 + 1 + 1));
        if (puStack_1c != (undefined4 *)0x0) {
          piStack_24 = (int *)puStack_1c[0x10];
          piStack_28 = *(int **)(iVar5 + 0x18e8);
          if ((piStack_28 < (int *)((puStack_1c[0x11] - (int)piStack_24) / 0xc)) &&
             (*(char *)((int)piStack_24 + (int)piStack_28 * 0xc + 9) != '\0')) {
            if (DAT_01ee420d != '\0') {
              puVar8 = (undefined4 *)FUN_008a2380(auStack_4c);
              uStack_8 = 1;
              if (0xf < (uint)puVar8[5]) {
                puVar8 = (undefined4 *)*puVar8;
              }
              FUN_01677490(DAT_01ee420d,
                           "initializeMegaReplicationDataForReplicator():: numCompleteChildren++ for %s[%d]"
                           ,puVar8,piStack_28,0);
              uStack_8 = 0xffffffff;
              FUN_005507b0();
            }
            *piVar4 = *piVar4 + 1;
          }
        }
        piVar10 = piVar10 + 2;
      } while (piVar10 != piStack_30);
      piVar9 = (int *)(param_2 + 0x34);
      iVar6 = param_2;
    }
  }
LAB_006d9712:
  iVar5 = param_3;
  if ((DAT_01d5b840 == '\0') || (*(char *)(iVar6 + 0x33) == '\0')) {
    *(undefined *)(piStack_20 + 2) = 1;
  }
  param_4 = (uint *)*param_4;
  if (((DAT_01d5b808 == '\0') || (DAT_01d5b7f8 == '\0')) && (DAT_01d5b800 == '\0')) {
    iVar2 = *(int *)(param_3 + 0x18e8);
    iVar3 = *piVar9;
    if ((*(int *)(param_3 + 0x1e88) != 0) &&
       (iVar7 = param_3 + 0x1e81 + (uint)*(byte *)(param_3 + 0x1e80),
       FUN_00606ea0(&param_2,((uint)param_4 >> 3) + (int)param_4,&param_4,
                    -(uint)(iVar7 != 0) & iVar7 + 1U), param_2 != 0)) {
      *(undefined4 *)(iVar3 + iVar2 * 0xc + 4) = *(undefined4 *)(param_2 + 0xc);
      FUN_006d81b0(&param_2,param_2);
    }
  }
  else if (*(int *)(param_3 + 0x1e88) != 0) {
    piStack_28 = (int *)(param_3 + 0x1e80);
    iVar5 = param_3 + 0x1e81 + (uint)*(byte *)(param_3 + 0x1e80);
    FUN_00606ea0(&piStack_30,((uint)param_4 >> 3) + (int)param_4,&param_4,
                 -(uint)(iVar5 != 0) & iVar5 + 1U);
    piVar10 = piStack_30;
    iVar5 = param_3;
    if (piStack_30 != (int *)0x0) {
      FUN_006d5ca0(iVar6);
      *(int *)(*piVar9 + 4 + *(int *)(param_3 + 0x18e8) * 0xc) = piVar10[3];
      FUN_006d81b0(&param_4,piVar10);
      iVar5 = param_3;
      iVar6 = param_2;
    }
  }
  if (DAT_01d5b7f8 == '\0') {
    FUN_006d6e00(iVar6,*(undefined4 *)(iVar5 + 0x18e8));
  }
  if (param_5 == 0) {
    iVar5 = *(int *)(iVar6 + 0x18);
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
      iVar5 = *(int *)(iVar6 + 0x18);
    }
    iVar6 = *(int *)(iVar6 + 0x14);
  }
  else {
    if (param_5 + -1 != 0) {
      ExceptionList = pvStack_10;
      return param_5 + -1;
    }
    iVar5 = *(int *)(iVar6 + 0x10);
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
      iVar5 = *(int *)(iVar6 + 0x10);
    }
    iVar6 = *(int *)(iVar6 + 0xc);
  }
  *param_6 = iVar6;
  piVar9 = (int *)param_6[1];
  param_6[1] = iVar5;
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar10 = piVar9 + 1;
    iVar5 = *piVar10;
    iVar6 = *piVar10;
    *piVar10 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar6 = (**(code **)*piVar9)();
      LOCK();
      piVar10 = piVar9 + 2;
      iVar5 = *piVar10;
      *piVar10 = *piVar10 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        iVar6 = (**(code **)(*piVar9 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 9330 ; VA 0x006d98e0 ; FUN_006d98e0 */

void __thiscall FUN_006d98e0(int param_1,undefined4 param_2)

{
  FUN_006b5f90(param_2,*(undefined *)(param_1 + 0x26c));
  return;
}



/* FUNCTION 9331 ; VA 0x006d9900 ; FUN_006d9900 */

void __thiscall FUN_006d9900(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a847f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0xbc) != 0) {
    ExceptionList = &pvStack_10;
    FUN_0071dda0();
  }
  iVar1 = FUN_01674e20(0x50);
  uStack_8 = 0;
  if (iVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_0071b510(param_2,param_1);
  }
  iVar1 = *(int *)(param_1 + 0xbc);
  uStack_8 = 0xffffffff;
  *(undefined4 *)(param_1 + 0xbc) = uVar2;
  if (iVar1 != 0) {
    (*(code *)**(undefined4 **)(iVar1 + 8))(1);
  }
  FUN_0071be90();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9332 ; VA 0x006d99a0 ; FUN_006d99a0 */

void FUN_006d99a0(void)

{
  FUN_006e3c50();
  return;
}



/* FUNCTION 9333 ; VA 0x006d99c0 ; FUN_006d99c0 */

void __thiscall FUN_006d99c0(undefined4 param_1,undefined4 *param_2)

{
  int *piVar1;
  
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_0061c1a0(*param_2,param_2[1],param_1);
  return;
}



/* FUNCTION 9334 ; VA 0x006d9a00 ; FUN_006d9a00 */

void FUN_006d9a00(int *param_1)

{
  if ((*(int *)(*param_1 + 0x1de4) != 0) && (*(char *)(*(int *)(*param_1 + 0x1de4) + 0x1d4) != '\0')
     ) {
    FUN_006bbdd0(*(undefined8 *)(param_1[1] + 8));
  }
  return;
}



/* FUNCTION 9335 ; VA 0x006d9a40 ; FUN_006d9a40 */

void FUN_006d9a40(int *param_1)

{
  (**(code **)(**(int **)(*param_1 + 0x1dcc) + 8))(param_1[1]);
  return;
}



/* FUNCTION 9336 ; VA 0x006d9a60 ; FUN_006d9a60 */

void FUN_006d9a60(int *param_1)

{
  if (*(char *)(*param_1 + 0x1db9) == '\0') {
    FUN_006bb920(*(undefined8 *)(param_1[1] + 8));
  }
  return;
}



/* FUNCTION 9337 ; VA 0x006d9a90 ; FUN_006d9a90 */

void FUN_006d9a90(int *param_1)

{
  undefined4 uVar1;
  undefined8 uVar2;
  undefined1 *puVar3;
  char *pcVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8cf4;
  pvStack_10 = ExceptionList;
  if ((*(int *)(*param_1 + 0x1de4) != 0) && (*(char *)(*(int *)(*param_1 + 0x1de4) + 0x1d4) != '\0')
     ) {
    ExceptionList = &pvStack_10;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaf108) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eaf108);
      if (DAT_01eaf108 == -1) {
        uVar5 = 0xffffffff;
        pcVar4 = "Replicator Stream";
        uStack_8 = 0;
        puVar3 = &DAT_018c5904;
        uVar2 = FUN_0152dab0();
        DAT_01eaf104 = (undefined4)((ulonglong)uVar2 >> 0x20);
        DAT_01eaf100 = (undefined4)uVar2;
        uStack_8 = 0xffffffff;
        FUN_016f37bf(&DAT_01eaf108,puVar3,pcVar4,uVar5);
      }
    }
    uVar1 = DAT_01eaf104;
    uVar5 = DAT_01eaf100;
    uVar2 = FUN_0152d930(DAT_01eaf100,DAT_01eaf104);
    uStack_8 = 1;
    FUN_006e8ca0(*(undefined8 *)(param_1[1] + 8));
    uStack_8 = 2;
    FUN_0152dda0(uVar5,uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9338 ; VA 0x006d9bc0 ; FUN_006d9bc0 */

undefined4 __thiscall FUN_006d9bc0(byte *param_1,uint param_2)

{
  byte *pbStack_8;
  
  pbStack_8 = param_1;
  FUN_00606ea0(&pbStack_8,(param_2 >> 3) + param_2,&param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (((pbStack_8 != (byte *)0x0) && (DAT_01d5b840 != '\0')) && (pbStack_8[0x3f] != 0)) {
    return 1;
  }
  return 0;
}



/* FUNCTION 9339 ; VA 0x006d9c20 ; FUN_006d9c20 */

undefined4 FUN_006d9c20(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined4 uVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  
  uVar1 = param_2;
  iVar4 = param_1;
  if (param_1 == 0) {
    if (DAT_01d5b848 == '\0') {
      return 1;
    }
  }
  else {
    while (iVar2 = param_4, cVar3 = FUN_006de120(iVar4,uVar1,param_3), cVar3 != '\0') {
      if (DAT_01d5b848 != '\0') {
        if ((*(uint *)(*(int *)(iVar4 + 0xc) + 0x1d4) >> 4 & 1) != 0) {
          return 1;
        }
        if (iVar2 == 0) {
          return 0;
        }
        if ((*(uint *)(*(int *)(iVar2 + 0xc) + 0x1d4) >> 4 & 1) != 0) {
          return 1;
        }
        FUN_006c9df0(&param_1,&param_4);
        iVar4 = param_1;
        if (DAT_01d5b720 == '\0') {
          if (param_1 == 0) {
            return 0;
          }
          if (*(int *)(param_1 + 0x2c) != 0) {
            return 1;
          }
        }
        else {
          if (param_1 == 0) {
            return 0;
          }
          if ((*(undefined4 **)(param_1 + 0x30) != (undefined4 *)0x0) &&
             (cVar3 = (**(code **)**(undefined4 **)(param_1 + 0x30))(), cVar3 != '\0')) {
            return 1;
          }
        }
        cVar3 = FUN_006cbfb0(iVar4 + 0xc);
        if (cVar3 == '\0') {
          return 0;
        }
        return 1;
      }
      if (iVar2 == 0) {
        return 1;
      }
      param_4 = *(int *)(iVar2 + 0x34);
      iVar4 = iVar2;
    }
  }
  return 0;
}



/* FUNCTION 9340 ; VA 0x006d9d30 ; FUN_006d9d30 */

bool FUN_006d9d30(int param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  int iVar2;
  char cVar3;
  undefined uVar4;
  
  iVar2 = param_1;
  if (param_1 == 0) {
    return DAT_01d5b848 == '\0';
  }
  iVar1 = *(int *)(param_1 + 0x34);
  param_1 = iVar1;
  cVar3 = FUN_006de120(iVar2,param_2,param_3);
  if (cVar3 == '\0') {
    return false;
  }
  if (DAT_01d5b848 == '\0') {
    uVar4 = FUN_006d9d30(iVar1,param_2,param_3);
    return (bool)uVar4;
  }
  if ((*(uint *)(*(int *)(iVar2 + 0xc) + 0x1d4) >> 4 & 1) == 0) {
    if (iVar1 == 0) {
      return false;
    }
    if ((*(uint *)(*(int *)(iVar1 + 0xc) + 0x1d4) >> 4 & 1) == 0) {
      FUN_006c9df0(&param_3,&param_1);
      iVar2 = param_3;
      if (DAT_01d5b720 == '\0') {
        if (param_3 == 0) {
          return false;
        }
        if (*(int *)(param_3 + 0x2c) != 0) {
          return true;
        }
      }
      else {
        if (param_3 == 0) {
          return false;
        }
        if ((*(undefined4 **)(param_3 + 0x30) != (undefined4 *)0x0) &&
           (cVar3 = (**(code **)**(undefined4 **)(param_3 + 0x30))(), cVar3 != '\0')) {
          return true;
        }
      }
      cVar3 = FUN_006cbfb0(iVar2 + 0xc);
      if (cVar3 == '\0') {
        return false;
      }
    }
  }
  return true;
}



/* FUNCTION 9341 ; VA 0x006d9e30 ; FUN_006d9e30 */

undefined FUN_006d9e30(int param_1)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  undefined uVar10;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8d08;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006448b0(&iStack_1c);
  uStack_8 = 0;
  iStack_14 = *(int *)(iStack_1c + 0x50);
  uVar2 = *(uint *)(param_1 + 0xc);
  if ((iStack_14 != *(int *)(iStack_1c + 0x54)) && (uVar2 != *(uint *)(iStack_1c + 0x60))) {
    uVar4 = (uVar2 >> 3) + uVar2;
    uVar9 = (*(int *)(iStack_1c + 0x54) - iStack_14 >> 2) - 1;
    uVar7 = 0;
    do {
      uVar4 = uVar4 & uVar9;
      uVar3 = *(uint *)(iStack_14 + uVar4 * 4);
      if (uVar3 == uVar2) goto LAB_006d9f00;
      if (uVar3 == *(uint *)(iStack_1c + 0x60)) break;
      uVar4 = uVar4 + 1 + uVar7;
      uVar7 = uVar7 + 1;
    } while (uVar7 <= uVar9);
  }
  iVar5 = FUN_00add460();
  iVar8 = 0;
  if ((uint)*(ushort *)(uVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
      (uint)*(ushort *)(iVar5 + 0x1da)) {
    iVar8 = param_1;
  }
  if (iVar8 == 0) {
    iVar8 = *(int *)(param_1 + 0xc);
    iVar6 = FUN_00c31b40();
    iVar5 = 0;
    if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
        (uint)*(ushort *)(iVar6 + 0x1da)) {
      iVar5 = param_1;
    }
    if (iVar5 == 0) {
      uVar10 = 1;
      goto LAB_006d9f02;
    }
  }
LAB_006d9f00:
  uVar10 = 0;
LAB_006d9f02:
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_18[1] + -1;
    piStack_18[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar8 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar10;
}



/* FUNCTION 9342 ; VA 0x006d9f40 ; FUN_006d9f40 */

bool __thiscall FUN_006d9f40(byte *param_1,int param_2,uint param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iStack_8;
  
  iVar2 = param_3 + (param_3 >> 3);
  FUN_00606ea0(&iStack_8,iVar2,&param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (iStack_8 != 0) {
    uVar1 = *(uint *)(param_2 + 0x18e8);
    if (((DAT_01d5b808 != '\0') && (DAT_01d5b7f8 != '\0')) || (DAT_01d5b800 != '\0')) {
      if ((DAT_01d5b840 == '\0') || (*(char *)(iStack_8 + 0x3f) == '\0')) {
        if (((uint)((*(int *)(iStack_8 + 0x44) - *(int *)(iStack_8 + 0x40)) / 0xc) <= uVar1) ||
           (*(char *)(*(int *)(iStack_8 + 0x40) + 8 + uVar1 * 0xc) == '\0')) goto LAB_006da064;
      }
      if ((uVar1 < (uint)((*(int *)(iStack_8 + 0x44) - *(int *)(iStack_8 + 0x40)) / 0xc)) &&
         (*(int *)(*(int *)(iStack_8 + 0x40) + 4 + uVar1 * 0xc) != 0)) {
        return true;
      }
      return false;
    }
    iVar3 = *(int *)(iStack_8 + 0x40);
    if ((uVar1 < (uint)((*(int *)(iStack_8 + 0x44) - iVar3) / 0xc)) &&
       (((DAT_01d5b840 != '\0' && (*(char *)(iStack_8 + 0x3f) != '\0')) ||
        (*(char *)(iVar3 + 8 + uVar1 * 0xc) != '\0')))) {
      return *(int *)(iVar3 + 4 + uVar1 * 0xc) != 0;
    }
  }
LAB_006da064:
  iVar3 = param_2 + 0x1e81 + (uint)*(byte *)(param_2 + 0x1e80);
  FUN_00606ea0(&param_2,iVar2,&param_3,-(uint)(iVar3 != 0) & iVar3 + 1U);
  return param_2 != 0;
}



/* FUNCTION 9343 ; VA 0x006da0a0 ; FUN_006da0a0 */

bool __thiscall FUN_006da0a0(int param_1,int param_2,int param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  undefined8 *puVar5;
  undefined8 uStack_24;
  int iStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  if ((uint)(*(int *)(param_1 + 0x1c0) - *(int *)(param_1 + 0x1bc) >> 2) <= param_4) {
    return false;
  }
  ExceptionList = &pvStack_10;
  FUN_006d8510(&param_4,param_2 + 0x18);
  if (param_4 != *(uint *)(param_1 + 0x254)) {
    for (puVar5 = *(undefined8 **)(param_4 + 0x18); puVar5 != *(undefined8 **)(param_4 + 0x1c);
        puVar5 = (undefined8 *)((int)puVar5 + 0xc)) {
      iStack_1c = *(int *)(puVar5 + 1);
      uStack_24 = *puVar5;
      if (iStack_1c == param_3) {
        uStack_18 = 0;
        piStack_14 = (int *)0x0;
        uStack_8 = 0;
        cVar4 = FUN_00621ac0(&uStack_24,&uStack_18);
        piVar3 = piStack_14;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          iVar2 = piStack_14[1] + -1;
          piStack_14[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_14)();
            LOCK();
            piVar1 = piVar3 + 2;
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        ExceptionList = pvStack_10;
        return cVar4 == '\0';
      }
    }
  }
  ExceptionList = pvStack_10;
  return false;
}



/* FUNCTION 9344 ; VA 0x006da1c0 ; FUN_006da1c0 */

undefined4 __thiscall FUN_006da1c0(byte *param_1,int param_2,uint param_3)

{
  byte *pbStack_8;
  
  pbStack_8 = param_1;
  FUN_00606ea0(&pbStack_8,(param_3 >> 3) + param_3,&param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (pbStack_8 == (byte *)0x0) {
    return 0;
  }
  if (((DAT_01d5b840 == '\0') || (pbStack_8[0x3f] == 0)) || (*(char *)(param_2 + 0x3894) == '\0')) {
    if (((uint)((*(int *)(pbStack_8 + 0x44) - *(int *)(pbStack_8 + 0x40)) / 0xc) <=
         *(uint *)(param_2 + 0x18e8)) ||
       (*(char *)(*(int *)(pbStack_8 + 0x40) + 8 + *(uint *)(param_2 + 0x18e8) * 0xc) == '\0')) {
      return 0;
    }
  }
  return 1;
}



/* FUNCTION 9345 ; VA 0x006da260 ; FUN_006da260 */

void __fastcall FUN_006da260(undefined4 *param_1)

{
  uint *puVar1;
  uint uVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8d40;
  pvStack_10 = ExceptionList;
  puVar1 = (uint *)*param_1;
  if (puVar1 == (uint *)0x0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_0056aeb0(1,"boost shared_lock has no mutex");
    uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
    FUN_00564990(uVar3);
  }
  ExceptionList = &pvStack_10;
  if (*(char *)(param_1 + 1) != '\0') {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_0056aeb0(0x24,"boost upgrade_lock owns already the mutex");
    uStack_8 = 1;
                    /* WARNING: Subroutine does not return */
    FUN_00564990(uVar3);
  }
  while( true ) {
    uVar2 = *puVar1;
    do {
      uVar5 = uVar2;
      if ((((uVar5 & 0x400000) == 0) && (-1 < (int)uVar5)) && ((uVar5 & 0x800000) == 0)) {
        uVar4 = (uVar5 + 1 ^ uVar5) & 0x7ff ^ uVar5;
        if ((uVar4 & 0x7ff) == 0) {
          uVar3 = FUN_006d1620();
          uStack_8 = 3;
                    /* WARNING: Subroutine does not return */
          FUN_00564990(uVar3);
        }
        uVar4 = uVar4 | 0x800000;
      }
      else {
        uVar4 = ((uVar5 & 0xfffff800) + 0x800 ^ uVar5) & 0x3ff800 ^ uVar5;
        if ((uVar4 & 0x3ff800) == 0) {
          uVar3 = FUN_006d1620();
          uStack_8 = 2;
                    /* WARNING: Subroutine does not return */
          FUN_00564990(uVar3);
        }
      }
      LOCK();
      uVar2 = *puVar1;
      if (uVar5 == uVar2) {
        *puVar1 = uVar4;
        uVar2 = uVar5;
      }
      UNLOCK();
    } while (uVar2 != uVar5);
    if ((((uVar5 & 0x400000) == 0) && (-1 < (int)uVar5)) && ((uVar5 & 0x800000) == 0)) break;
    WaitForSingleObjectEx(puVar1[1],0xffffffff,0);
  }
  *(undefined *)(param_1 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9346 ; VA 0x006da3a0 ; FUN_006da3a0 */

void FUN_006da3a0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d9b834);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_00731d26427b6abbce69a452f8a1305b>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 9347 ; VA 0x006da400 ; FUN_006da400 */

int * FUN_006da400(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x006da4ab. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x006da43e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1d9b8dc);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_06d931a7354a273dbafd517ddba8deb4>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 9348 ; VA 0x006da4c0 ; FUN_006da4c0 */

void FUN_006da4c0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d9b7fc);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_2db68d563c01082dc13403b13eb14cbb>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 9349 ; VA 0x006da530 ; FUN_006da530 */

void FUN_006da530(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d9b86c);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_3928476477fb4732eaca21d3e401287e>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 9350 ; VA 0x006da5a0 ; FUN_006da5a0 */

void FUN_006da5a0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d9b78c);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_4a58c3036f38b08e9f2ce03c99289e36>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 9351 ; VA 0x006da610 ; FUN_006da610 */

void FUN_006da610(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d9b8a4);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_8e53013ffe28743c4b9d2955efe9e0c2>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 9352 ; VA 0x006da680 ; FUN_006da680 */

void FUN_006da680(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1d9b7c4);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_e232ca3cb5feee39a6a0e9ca375cca1c>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 9353 ; VA 0x006da6e0 ; FUN_006da6e0 */

void __thiscall FUN_006da6e0(int param_1,undefined4 *param_2)

{
  *(undefined *)(param_2 + 2) = 0;
  if ((DAT_01d5b840 == '\0') || (*(char *)(param_1 + 0x33) == '\0')) {
    *(int *)(param_1 + 0x2c) = *(int *)(param_1 + 0x2c) + -1;
  }
  if (DAT_01d5b7f8 == '\0') {
    *(undefined2 *)((int)param_2 + 9) = 0;
    *param_2 = 0;
  }
  return;
}



/* FUNCTION 9354 ; VA 0x006da720 ; FUN_006da720 */

void FUN_006da720(int param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  if (((DAT_01d5b808 == '\0') || (DAT_01d5b7f8 == '\0')) && (DAT_01d5b800 == '\0')) {
    uVar4 = *(uint *)(param_1 + 0x18e8);
    iVar3 = *(int *)(param_3 + 0x34);
  }
  else {
    iVar3 = *(int *)(param_3 + 0x34);
    uVar4 = *(uint *)(param_1 + 0x18e8);
    if ((uint)((*(int *)(param_3 + 0x38) - iVar3) / 0xc) <= uVar4) {
      return;
    }
  }
  iVar3 = iVar3 + uVar4 * 0xc;
  iVar1 = *(int *)(iVar3 + 4);
  if (iVar1 != 0) {
    iVar2 = FUN_006d2b60(&param_2);
    *(int *)(iVar2 + 4) = iVar1;
  }
  *(undefined4 *)(iVar3 + 4) = 0;
  return;
}



/* FUNCTION 9355 ; VA 0x006da7b0 ; FUN_006da7b0 */

void FUN_006da7b0(int *param_1)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  uint uVar5;
  int aiStack_30 [5];
  uint uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  uVar3 = *(uint *)(iVar2 + 0x40);
  uStack_14 = *(uint *)(iVar2 + 0x3c);
  uVar5 = 0;
  if (uStack_14 == (uVar3 & 0xffffff)) {
    uVar5 = 0x2000000;
  }
  ExceptionList = &pvStack_10;
  *(uint *)(iVar2 + 0x40) = uVar5 | uVar3 & 0xf8ffffff;
  if (DAT_01eaf005 != '\0') {
    piVar4 = *(int **)(*param_1 + 0x28);
    if (0xf < (uint)piVar4[5]) {
      piVar4 = (int *)*piVar4;
    }
    puVar1 = (undefined4 *)FUN_009c9510(aiStack_30);
    uStack_8 = 0;
    if (0xf < (uint)puVar1[5]) {
      puVar1 = (undefined4 *)*puVar1;
    }
    FUN_01677520(DAT_01eaf005,"%s(%s) new:%d expected:%d computed:%d",puVar1,piVar4,uVar5 >> 0x19,
                 uStack_14,uVar3 & 0xffffff);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_1c) {
      uVar3 = uStack_1c + 1;
      iVar2 = aiStack_30[0];
      if (0xfff < uVar3) {
        iVar2 = *(int *)(aiStack_30[0] + -4);
        uVar3 = uStack_1c + 0x24;
        if (0x1f < (aiStack_30[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
  }
  if (param_1[1] != 0) {
    LOCK();
    piVar4 = (int *)(param_1[1] + 4);
    *piVar4 = *piVar4 + 1;
    UNLOCK();
  }
  FUN_006d7b90(*param_1,param_1[1]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9356 ; VA 0x006da8f0 ; FUN_006da8f0 */

int * __thiscall FUN_006da8f0(int param_1,int *param_2,undefined4 *param_3)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int *piVar7;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  int iStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  int iStack_34;
  undefined4 uStack_30;
  int iStack_28;
  int *piStack_24;
  undefined4 *puStack_20;
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8d90;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if ((undefined4 *)param_2[5] != (undefined4 *)0x0) {
    ExceptionList = &pvStack_10;
    *(undefined4 *)param_2[5] = 0;
    FUN_006ab670();
  }
  piVar2 = (int *)piVar1[3];
  if (piVar2 != (int *)0x0) {
    *piVar2 = 0;
    piVar2 = (int *)FUN_006ab670();
  }
  if (*(char *)((int)piVar1 + 0x31) != '\0') {
    iStack_1c = 0;
    FUN_0060e810(0,&iStack_1c,(int)&param_2 + 3);
    puVar3 = param_3;
    iStack_34 = 0;
    uStack_30 = 0;
    uStack_8 = 0;
    if ((DAT_01d5b840 == '\0') || (*(char *)((int)piVar1 + 0x33) == '\0')) {
      *(undefined *)(piVar1 + 0xc) = 1;
      uVar4 = 0;
      iVar6 = piVar1[0xd];
      piVar2 = (int *)((piVar1[0xe] - iVar6) / 0xc);
      if (piVar2 != (int *)0x0) {
        param_2 = (int *)0x0;
        do {
          if (*(char *)((int)param_2 + iVar6 + 8) != '\0') {
            FUN_006222f0(piVar1 + 1,param_3,&iStack_40);
          }
          piVar2 = param_2 + 3;
          iVar6 = piVar1[0xd];
          uVar4 = uVar4 + 1;
          param_2 = piVar2;
        } while (uVar4 < (uint)((piVar1[0xe] - iVar6) / 0xc));
      }
      *(undefined *)(piVar1 + 0xc) = 0;
    }
    else {
      piVar2 = *(int **)(param_1 + 0x1c0);
      piVar7 = *(int **)(param_1 + 0x1bc);
      param_2 = piVar2;
      if (piVar7 != piVar2) {
        do {
          if (*(char *)(*piVar7 + 0x3894) != '\0') {
            FUN_006222f0(piVar1 + 1,puVar3,&iStack_40);
            piVar2 = param_2;
          }
          piVar7 = piVar7 + 1;
        } while (piVar7 != piVar2);
      }
    }
    if ((DAT_01d5b810 != '\0') && (iStack_34 != 0)) {
      puVar3 = (undefined4 *)FUN_01674e20(0x48);
      puStack_20 = puVar3;
      if (puVar3 == (undefined4 *)0x0) {
        param_3 = (undefined4 *)0x0;
        piVar7 = piStack_24;
      }
      else {
        param_2 = *(int **)(iStack_14 + 0x1f8);
        iStack_1c = *(int *)(iStack_14 + 0x1fc);
        *(int *)(iStack_14 + 0x1f8) = (int)param_2 + 1;
        *(uint *)(iStack_14 + 0x1fc) = iStack_1c + (uint)((int *)0xfffffffe < param_2);
        piVar7 = (int *)piVar1[2];
        if (piVar7 != (int *)0x0) {
          LOCK();
          piVar7[1] = piVar7[1] + 1;
          UNLOCK();
          piVar7 = (int *)piVar1[2];
        }
        iVar6 = piVar1[1];
        uStack_18 = 1;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        iStack_28 = iVar6;
        piStack_24 = piVar7;
        FUN_0054ef60(param_3 + 1);
        *puVar3 = RBX::Network::SharedQueueItem::vftable;
        puVar3[2] = 0;
        puVar3[3] = 0;
        puVar3[4] = 0;
        puVar3[2] = iStack_40;
        puVar3[3] = uStack_3c;
        puVar3[4] = iStack_38;
        iStack_40 = 0;
        uStack_3c = 0;
        iStack_38 = 0;
        puVar3[5] = iStack_34;
        puVar3[6] = uStack_30;
        puVar3[8] = param_2;
        puVar3[9] = iStack_1c;
        uStack_8._0_1_ = 4;
        uStack_8._1_3_ = 0;
        *puVar3 = RBX::Network::SharedChangeAttributeItem::vftable;
        FUN_0054ef60(auStack_58);
        puVar3[0x10] = 0;
        puVar3[0x11] = 0;
        if (piVar7 != (int *)0x0) {
          LOCK();
          piVar7[1] = piVar7[1] + 1;
          UNLOCK();
        }
        puVar3[0x10] = iVar6;
        puVar3[0x11] = piVar7;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        if (0xf < uStack_44) {
          uVar5 = uStack_44 + 1;
          uVar4 = auStack_58[0];
          if (0xfff < uVar5) {
            uVar4 = *(uint *)(auStack_58[0] - 4);
            uVar5 = uStack_44 + 0x24;
            if (0x1f < (auStack_58[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar4,uVar5);
        }
        uStack_48 = 0;
        uStack_44 = 0xf;
        auStack_58[0] = auStack_58[0] & 0xffffff00;
        param_3 = puVar3;
      }
      uStack_8 = 5;
      piVar2 = *(int **)(iStack_14 + 0x1ec);
      if (*(int **)(iStack_14 + 0x1f0) == piVar2) {
        piVar2 = (int *)FUN_006030d0(piVar2,&param_3);
      }
      else {
        *piVar2 = (int)param_3;
        *(int *)(iStack_14 + 0x1ec) = *(int *)(iStack_14 + 0x1ec) + 4;
      }
      if (((uStack_18 & 1) != 0) && (piVar7 != (int *)0x0)) {
        LOCK();
        piVar1 = piVar7 + 1;
        iVar6 = *piVar1;
        piVar2 = (int *)*piVar1;
        *piVar1 = iVar6 + -1;
        UNLOCK();
        if (iVar6 + -1 == 0) {
          piVar2 = (int *)(**(code **)*piVar7)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar6 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar6 == 1) {
            piVar2 = (int *)(**(code **)(*piVar7 + 4))();
          }
        }
      }
    }
    if (iStack_40 != 0) {
      uVar4 = iStack_38 - iStack_40 & 0xfffffffc;
      iVar6 = iStack_40;
      if (0xfff < uVar4) {
        iVar6 = *(int *)(iStack_40 + -4);
        uVar4 = uVar4 + 0x23;
        if (0x1f < (iStack_40 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      piVar2 = (int *)FUN_01674ea0(iVar6,uVar4);
    }
  }
  ExceptionList = pvStack_10;
  return piVar2;
}



/* FUNCTION 9357 ; VA 0x006dac70 ; FUN_006dac70 */

void __thiscall FUN_006dac70(int param_1,uint param_2,int param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6248;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_01eadc98);
  uStack_8 = 0;
  if (DAT_01d5b810 != '\0') {
    *(int *)(param_1 + 0xa0) = *(int *)(param_1 + 0xa0) + 1;
  }
  switch(param_3) {
  case 0:
    FUN_006dae70(param_2,param_4);
    break;
  case 1:
    FUN_006db4c0(param_2,param_4);
    break;
  case 2:
    FUN_006dc430(param_2,param_4);
    break;
  case 3:
    if (*(char *)(param_2 + 0x31) != '\0') {
      if ((DAT_01d5b840 == '\0') || (*(char *)(param_2 + 0x33) == '\0')) {
        *(undefined *)(param_2 + 0x30) = 1;
        iVar4 = *(int *)(param_2 + 0x38) - *(int *)(param_2 + 0x34);
        param_2 = 0;
        iVar5 = iVar4 >> 0x1f;
        if (iVar4 / 0xc + iVar5 != iVar5) {
          iVar5 = *(int *)(iVar2 + 0x34);
          param_3 = 0;
          do {
            if (*(char *)(param_3 + 8 + iVar5) != '\0') {
              FUN_006224b0(iVar2 + 4,*(undefined4 *)(iVar2 + 0x1c),param_4);
            }
            iVar5 = *(int *)(iVar2 + 0x34);
            param_3 = param_3 + 0xc;
            param_2 = param_2 + 1;
          } while (param_2 < (uint)((*(int *)(iVar2 + 0x38) - iVar5) / 0xc));
        }
        *(undefined *)(iVar2 + 0x30) = 0;
      }
      else {
        piVar1 = *(int **)(param_1 + 0x1c0);
        for (piVar6 = *(int **)(param_1 + 0x1bc); piVar6 != piVar1; piVar6 = piVar6 + 1) {
          if (*(char *)(*piVar6 + 0x3894) != '\0') {
            FUN_006224b0(param_2 + 4,*(undefined4 *)(param_2 + 0x1c),param_4);
          }
        }
      }
    }
    break;
  case 9:
    FUN_006da8f0(param_2,param_4);
  }
  if (DAT_01d5b810 != '\0') {
    piVar1 = (int *)(param_1 + 0xa0);
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      *(undefined4 *)(param_1 + 0x8c) = *(undefined4 *)(param_1 + 0x88);
      *(undefined4 *)(param_1 + 0x94) = 0;
    }
  }
  uStack_8 = 1;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9358 ; VA 0x006dae70 ; FUN_006dae70 */

void __thiscall FUN_006dae70(byte *param_1,int param_2,int param_3)

{
  int *piVar1;
  uint *puVar2;
  int iVar3;
  undefined uVar4;
  uint uVar5;
  uint uVar6;
  uint *puVar7;
  int iVar8;
  uint uVar9;
  byte *pbVar10;
  uint uStack_5c;
  uint uStack_58;
  uint uStack_54;
  uint uStack_50;
  undefined auStack_4c [4];
  uint *puStack_48;
  uint *puStack_44;
  uint uStack_40;
  uint *puStack_3c;
  uint *puStack_38;
  uint uStack_34;
  int iStack_30;
  uint uStack_2c;
  undefined4 uStack_28;
  byte *pbStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint *puStack_18;
  undefined uStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8dc1;
  pvStack_10 = ExceptionList;
  puStack_38 = (uint *)0x0;
  ExceptionList = &pvStack_10;
  pbStack_24 = param_1;
  iStack_30 = FUN_006bf290();
  uStack_28 = CONCAT31(uStack_28._1_3_,iStack_30 != 0);
  if (*(char *)(param_2 + 0x32) == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  if ((*(int *)(param_1 + 0x1c) == 0) &&
     ((*(uint *)(**(int **)(param_1 + 0x1bc) + 0x380c) & 1) != 0)) {
    FUN_006d5e80(*(int *)(param_3 + 4),*(undefined4 *)(*(int *)(param_3 + 4) + 0x34));
  }
  uStack_34 = uStack_34 & 0xffffff00;
  if ((DAT_01d5b820 != '\0') && ((DAT_01d5b848 == '\0' || (*(int *)(param_1 + 0x1c) != 0)))) {
    if ((iStack_30 == 0) || (*(char *)(iStack_30 + 0x300) == '\0')) {
LAB_006daf26:
      uStack_2c = uStack_2c & 0xffffff00;
    }
    else {
      uStack_2c = CONCAT31(uStack_2c._1_3_,1);
      if (param_1[0x26c] != 0) goto LAB_006daf26;
    }
    uVar4 = FUN_006d9d30(*(undefined4 *)(param_2 + 4),uStack_28,uStack_2c);
    uStack_34 = CONCAT31(uStack_34._1_3_,uVar4);
  }
  uStack_40 = *(uint *)(param_3 + 4);
  FUN_00606ea0(&uStack_2c,(uStack_40 >> 3) + uStack_40,&uStack_40,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  uVar6 = uStack_2c;
  uStack_1c = 0;
  uStack_5c = 0;
  uStack_58 = 0;
  uStack_40 = 0;
  uStack_54 = 0;
  uStack_20 = 0;
  uStack_50 = 0;
  uStack_8 = 0;
  if (DAT_01d5b840 == '\0') goto LAB_006db2c9;
  if (((DAT_01d5b808 == '\0') || (DAT_01d5b7f8 == '\0')) && (DAT_01d5b800 == '\0')) {
    cStack_11 = '\x01';
    puStack_3c = (uint *)FUN_006d08c0((*(int *)(param_2 + 0x38) - *(int *)(param_2 + 0x34)) / 0xc,
                                      &cStack_11,&uStack_12);
    puStack_38 = (uint *)0x2;
  }
  else {
    cStack_11 = '\x01';
    puStack_3c = (uint *)FUN_006d08c0(*(int *)(param_1 + 0x1c0) - *(int *)(param_1 + 0x1bc) >> 2,
                                      &cStack_11,&uStack_12);
    puStack_38 = (uint *)0x1;
  }
  puStack_18 = puStack_38;
  if (&uStack_5c != puStack_3c) {
    uStack_8 = 2;
    FUN_0065a9d0(auStack_4c,0,0,0,0);
    FUN_0056d320();
    uStack_5c = *puStack_3c;
    uStack_58 = puStack_3c[1];
    uStack_54 = puStack_3c[2];
    *puStack_3c = 0;
    puStack_3c[1] = 0;
    puStack_3c[2] = 0;
    uStack_50 = puStack_3c[3];
    puStack_3c[3] = 0;
    uStack_40 = uStack_54;
    uStack_20 = uStack_50;
    uStack_1c = uStack_5c;
  }
  if (((uint)puStack_18 & 2) != 0) {
    puStack_18 = (uint *)((uint)puStack_18 & 0xfffffffd);
    FUN_0056d320();
  }
  uStack_8 = 0;
  if (((uint)puStack_18 & 1) != 0) {
    FUN_0056d320();
  }
  pbVar10 = pbStack_24;
  if (uVar6 == 0) goto LAB_006db2c9;
  uVar9 = (*(int *)(uVar6 + 0x44) - *(int *)(uVar6 + 0x40)) / 0xc;
  if (uVar9 < uStack_20) {
    uStack_20 = uVar9;
  }
  if (uStack_20 != 0) {
    uVar9 = 0;
    puStack_3c = (uint *)0x0;
    do {
      if ((*(char *)(uVar6 + 0x3f) != '\0') ||
         (cStack_11 = '\x01', *(byte *)(*(int *)(uVar6 + 0x40) + 8 + (int)puStack_3c) != 0)) {
        cStack_11 = '\0';
      }
      puVar7 = (uint *)(uStack_1c + (uVar9 >> 5) * 4);
      uVar5 = *puVar7;
      if (cStack_11 == '\0') {
        uVar5 = uVar5 & ~(1 << (uVar9 & 0x1f));
      }
      else {
        uVar5 = uVar5 | 1 << (uVar9 & 0x1f);
      }
      *puVar7 = uVar5;
      uVar9 = uVar9 + 1;
      puStack_3c = puStack_3c + 3;
      param_1 = pbStack_24;
    } while (uVar9 < uStack_20);
  }
  puVar7 = (uint *)(uVar6 + 8);
  FUN_00606ea0(&puStack_3c,(*puVar7 >> 3) + *puVar7,puVar7,
               -(uint)(param_1 + param_1[0x1a4] + 0x1a5 != (byte *)0x0) &
               (uint)(param_1 + param_1[0x1a4] + 0x1a5 + 1));
  if (puStack_3c != (uint *)0x0) {
    puVar7 = (uint *)puStack_3c[3];
    uVar6 = (uint)((int)puStack_3c[4] + (3 - (int)puVar7)) >> 2;
    if ((uint *)puStack_3c[4] < puVar7) {
      uVar6 = 0;
    }
    if (uVar6 != 0) {
      uVar9 = 0;
      do {
        uVar5 = *puVar7;
        puVar7 = puVar7 + 1;
        puVar2 = (uint *)(uStack_1c + (uVar5 >> 5) * 4);
        uVar9 = uVar9 + 1;
        *puVar2 = *puVar2 | 1 << (uVar5 & 0x1f);
        pbVar10 = pbStack_24;
      } while (uVar9 != uVar6);
    }
    puStack_44 = (uint *)*puStack_3c;
    puStack_38 = (uint *)(pbVar10 + 0x1a8);
    puVar7 = puStack_3c + 1;
    puVar2 = *(uint **)(*(int *)(pbVar10 + 0x1b8) + (*puVar7 % *puStack_38) * 4);
    for (puStack_18 = (uint *)*puVar2; puStack_18 != puStack_3c; puStack_18 = (uint *)*puStack_18) {
      puVar2 = puStack_18;
    }
    puStack_48 = (uint *)(-(uint)(pbVar10 != (byte *)0xfffffe59) & (uint)(pbVar10 + 0x1a8));
    puStack_3c = puVar2;
    uStack_20 = *puVar7 % *puStack_38;
    do {
      *puVar2 = *puStack_18;
      FUN_006d0070(puStack_48,puStack_18 + 2);
      FUN_01674ea0(puStack_18,0x18);
      *(int *)(pbVar10 + 0x1ac) = *(int *)(pbVar10 + 0x1ac) + -1;
      uVar9 = uStack_20;
      if (*puVar2 == 0) {
LAB_006db26c:
        if (*(uint **)(*(int *)(pbVar10 + 0x1b8) + uStack_20 * 4) == puVar2) {
          *(undefined4 *)(*(int *)(pbVar10 + 0x1b8) + uStack_20 * 4) = 0;
        }
      }
      else {
        uVar9 = *(uint *)(*puVar2 + 4) % *puStack_38;
        pbVar10 = pbStack_24;
        if (uStack_20 != uVar9) {
          *(uint **)(*(int *)(pbStack_24 + 0x1b8) + uVar9 * 4) = puVar2;
          goto LAB_006db26c;
        }
      }
      puStack_18 = (uint *)*puVar2;
      uVar6 = uStack_2c;
      uStack_20 = uVar9;
    } while (puStack_18 != puStack_44);
  }
  if ((iStack_30 == 0) || (*(char *)(iStack_30 + 0x300) == '\0')) {
LAB_006db2b0:
    puStack_3c = (uint *)((uint)puStack_3c & 0xffffff00);
  }
  else {
    puStack_3c = (uint *)CONCAT31(puStack_3c._1_3_,1);
    if (pbVar10[0x26c] != 0) goto LAB_006db2b0;
  }
  FUN_006d5d50(uVar6 + 0xc,param_2,uStack_28,puStack_3c);
  param_1 = pbVar10;
LAB_006db2c9:
  if ((((DAT_01d5b278 != '\0') && (*(int *)(param_1 + 0x1c) != 0)) &&
      ((*(byte *)(*(int *)(*(int *)(param_3 + 4) + 0xc) + 0x1d4) & 3) != 0)) && (uVar6 == 0)) {
    piVar1 = (int *)(*(int *)(param_2 + 4) + 0x38);
    *piVar1 = *piVar1 + 1;
    FUN_006d7df0((int *)(param_2 + 4));
  }
  if ((DAT_01d5b840 == '\0') || (*(char *)(param_2 + 0x33) == '\0')) {
    *(undefined *)(param_2 + 0x30) = 1;
    uVar6 = 0;
    iVar8 = *(int *)(param_2 + 0x38) - *(int *)(param_2 + 0x34);
    iVar3 = iVar8 >> 0x1f;
    if (iVar8 / 0xc + iVar3 != iVar3) {
      iStack_30 = 0;
      do {
        if (*(char *)(*(int *)(param_2 + 0x34) + 8 + iStack_30) != '\0') {
          puStack_48 = *(uint **)(*(int *)(param_1 + 0x1bc) + uVar6 * 4);
          puVar7 = puStack_48;
          if ((DAT_01d5b840 == '\0') ||
             (puVar7 = (uint *)(uVar6 >> 5),
             (*(uint *)(uStack_1c + (int)puVar7 * 4) & 1 << ((byte)uVar6 & 0x1f)) == 0)) {
            uVar9 = (uint)puVar7 & 0xffffff00;
          }
          else {
            uVar9 = CONCAT31((uint3)(uVar6 >> 0xd),1);
          }
          FUN_00622330(param_2 + 4,param_3,uStack_28,uStack_34,param_1 + 0x88,uVar9,0);
        }
        iStack_30 = iStack_30 + 0xc;
        uVar6 = uVar6 + 1;
      } while (uVar6 < (uint)((*(int *)(param_2 + 0x38) - *(int *)(param_2 + 0x34)) / 0xc));
    }
    *(undefined *)(param_2 + 0x30) = 0;
  }
  else {
    puStack_48 = *(uint **)(param_1 + 0x1c0);
    puVar7 = *(uint **)(param_1 + 0x1bc);
    if (puVar7 != puStack_48) {
      do {
        uVar6 = *puVar7;
        if (*(char *)(uVar6 + 0x3894) != '\0') {
          if ((DAT_01d5b840 == '\0') ||
             (puVar2 = (uint *)(uVar6 + 0x18e8), uVar6 = 1 << ((byte)*puVar2 & 0x1f),
             (*(uint *)(uStack_1c + (*puVar2 >> 5) * 4) & uVar6) == 0)) {
            uVar6 = uVar6 & 0xffffff00;
          }
          else {
            uVar6 = CONCAT31((int3)(uVar6 >> 8),1);
          }
          FUN_00622330(param_2 + 4,param_3,uStack_28,uStack_34,param_1 + 0x88,uVar6,1);
        }
        puVar7 = puVar7 + 1;
      } while (puVar7 != puStack_48);
    }
  }
  if (DAT_01d5b7f8 == '\0') {
    FUN_006d69e0(param_2);
  }
  if (uStack_1c != 0) {
    uVar9 = uStack_40 - uStack_1c & 0xfffffffc;
    uVar6 = uStack_1c;
    if (0xfff < uVar9) {
      uVar6 = *(uint *)(uStack_1c - 4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (uStack_1c - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar9);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9359 ; VA 0x006db4c0 ; FUN_006db4c0 */

void __thiscall FUN_006db4c0(byte *param_1,int *param_2,undefined4 *param_3)

{
  uint *puVar1;
  uint *puVar2;
  undefined uVar3;
  char cVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  uint *puVar9;
  uint *puVar10;
  int iVar11;
  int *piVar12;
  uint uVar13;
  uint uVar14;
  int *piVar15;
  byte *pbVar16;
  int *piVar17;
  undefined auStack_98 [12];
  int iStack_8c;
  undefined4 uStack_88;
  int aiStack_80 [5];
  uint uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  int iStack_5c;
  undefined4 uStack_58;
  uint auStack_50 [3];
  undefined4 uStack_44;
  undefined4 uStack_40;
  uint uStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  byte *pbStack_2c;
  uint uStack_28;
  int iStack_24;
  undefined4 uStack_20;
  uint *puStack_1c;
  uint *puStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar15 = param_2;
  puStack_c = &LAB_017a8e99;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  iStack_38 = 0;
  iStack_34 = 0;
  iStack_30 = 0;
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  if (((DAT_01d5b808 == '\0') || (DAT_01d5b7f8 == '\0')) && (DAT_01d5b800 == '\0')) {
    iVar5 = (param_2[0xe] - param_2[0xd]) / 0xc;
  }
  else {
    iVar5 = *(int *)(param_1 + 0x1c0) - *(int *)(param_1 + 0x1bc) >> 2;
  }
  ExceptionList = &pvStack_10;
  pbStack_2c = param_1;
  FUN_006cf370(iVar5,&iStack_38);
  if (DAT_01ee420d != '\0') {
    if (piVar15[1] == 0) {
      puVar6 = (undefined4 *)&DAT_018de934;
    }
    else {
      puVar6 = (undefined4 *)FUN_008a2380(aiStack_80);
      uStack_28 = 1;
      uStack_8._0_1_ = 1;
      if (0xf < (uint)puVar6[5]) {
        puVar6 = (undefined4 *)*puVar6;
      }
    }
    puVar7 = (undefined4 *)FUN_008a2380(auStack_50);
    uStack_8 = 2;
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    FUN_01677490(DAT_01ee420d,"onCombinedSignalChildRemoved()::child=%s, oldParent=%s",puVar7,puVar6
                 ,0);
    uStack_8._0_1_ = 1;
    if (0xf < uStack_3c) {
      uVar13 = uStack_3c + 1;
      uVar14 = auStack_50[0];
      if (0xfff < uVar13) {
        uVar14 = *(uint *)(auStack_50[0] - 4);
        uVar13 = uStack_3c + 0x24;
        if (0x1f < (auStack_50[0] - uVar14) - 4) {
LAB_006dc28c:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar14,uVar13);
    }
    uStack_40 = 0;
    uStack_3c = 0xf;
    auStack_50[0] = auStack_50[0] & 0xffffff00;
    uStack_8._0_1_ = 0;
    uStack_8._1_3_ = 0;
    if (((uStack_28 & 1) != 0) && (uStack_28 = uStack_28 & 0xfffffffe, 0xf < uStack_6c)) {
      uVar14 = uStack_6c + 1;
      iVar5 = aiStack_80[0];
      if (0xfff < uVar14) {
        iVar5 = *(int *)(aiStack_80[0] + -4);
        uVar14 = uStack_6c + 0x24;
        if (0x1f < (aiStack_80[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar14);
    }
  }
  if ((*(int *)(param_1 + 0x1c) == 0) &&
     ((*(uint *)(**(int **)(param_1 + 0x1bc) + 0x380c) & 1) != 0)) {
    FUN_006d60a0(param_3[1],piVar15 + 1);
  }
  puStack_1c = (uint *)param_3[1];
  FUN_00606ea0(&puStack_14,((uint)puStack_1c >> 3) + (int)puStack_1c,&puStack_1c,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  puVar1 = puStack_14;
  puVar6 = param_3;
  if (puStack_14 == (uint *)0x0) goto LAB_006db831;
  if (((DAT_01d5b808 == '\0') || (DAT_01d5b7f8 == '\0')) && (DAT_01d5b800 == '\0')) {
    puStack_1c = (uint *)(iStack_34 - iStack_38 >> 3);
    puVar10 = (uint *)((int)(puStack_14[0x11] - puStack_14[0x10]) / 0xc);
    if (puVar10 <= puStack_1c) {
      puStack_1c = puVar10;
    }
    puVar10 = (uint *)0x0;
    if (puStack_1c != (uint *)0x0) {
      iVar5 = 0;
      do {
        if (((DAT_01d5b840 == '\0') || (*(char *)((int)puStack_14 + 0x3f) == '\0')) &&
           (*(char *)(iVar5 + 8 + puStack_14[0x10]) == '\0')) {
          uVar3 = 0;
        }
        else {
          uVar3 = 1;
        }
        iVar5 = iVar5 + 0xc;
        *(undefined *)(iStack_38 + (int)puVar10 * 8) = uVar3;
        puVar10 = (uint *)((int)puVar10 + 1);
      } while (puVar10 < puStack_1c);
    }
  }
  else {
    uVar14 = 0;
    if (*(int *)(param_1 + 0x1c0) - *(int *)(param_1 + 0x1bc) >> 2 != 0) {
      puStack_1c = (uint *)0x0;
      do {
        if (((DAT_01d5b840 == '\0') || (*(char *)((int)puStack_14 + 0x3f) == '\0')) &&
           (((uint)((int)(puStack_14[0x11] - puStack_14[0x10]) / 0xc) <= uVar14 ||
            (*(char *)((int)puStack_1c + puStack_14[0x10] + 8) == '\0')))) {
          uVar3 = 0;
        }
        else {
          uVar3 = 1;
        }
        puStack_1c = puStack_1c + 3;
        *(undefined *)(iStack_38 + uVar14 * 8) = uVar3;
        uVar14 = uVar14 + 1;
      } while (uVar14 < (uint)(*(int *)(param_1 + 0x1c0) - *(int *)(param_1 + 0x1bc) >> 2));
    }
  }
  if ((DAT_01d5b820 == '\0') || (*(int *)(param_1 + 0x1c) == 0)) goto LAB_006db831;
  iVar5 = FUN_006bf290();
  if ((iVar5 == 0) || (*(char *)(iVar5 + 0x300) == '\0')) {
LAB_006db7f4:
    puStack_1c = (uint *)((uint)puStack_1c & 0xffffff00);
  }
  else {
    puStack_1c = (uint *)CONCAT31(puStack_1c._1_3_,1);
    if (param_1[0x26c] != 0) goto LAB_006db7f4;
  }
  puVar10 = puStack_1c;
  puStack_14 = (uint *)CONCAT31(puStack_14._1_3_,iVar5 != 0);
  puVar2 = puStack_14;
  uVar3 = FUN_006d9d30(param_3[1],puStack_14,puStack_1c);
  param_1 = pbStack_2c;
  puVar6 = param_3;
  puStack_1c = (uint *)CONCAT31(puStack_1c._1_3_,uVar3);
  FUN_006d5760(param_3[1],puVar2,puVar10,puStack_1c);
LAB_006db831:
  if (DAT_01d5b278 != '\0') {
    if ((*(int *)(param_1 + 0x1c) != 0) && ((*(uint *)(*(int *)(puVar6[1] + 0xc) + 0x1d4) & 3) != 0)
       ) {
      piVar15 = param_2;
      if (DAT_01eaf004 != '\0') {
        puStack_1c = *(uint **)(puVar6[1] + 0x28);
        if (0xf < puStack_1c[5]) {
          puStack_1c = (uint *)*puStack_1c;
        }
        puStack_14 = (uint *)FUN_009c9510(aiStack_80);
        piVar15 = param_2;
        uStack_8._0_1_ = 3;
        if (0xf < puStack_14[5]) {
          puStack_14 = (uint *)*puStack_14;
        }
        puStack_18 = *(uint **)(param_2[1] + 0x28);
        if (0xf < puStack_18[5]) {
          puStack_18 = (uint *)*puStack_18;
        }
        puVar6 = (undefined4 *)FUN_009c9510(auStack_50);
        uStack_8._0_1_ = 4;
        if (0xf < (uint)puVar6[5]) {
          puVar6 = (undefined4 *)*puVar6;
        }
        FUN_01677520(DAT_01eaf004,"parent %s(%s) removes child %s(%s)",puVar6,puStack_18,puStack_14,
                     puStack_1c);
        uStack_8._0_1_ = 3;
        uVar3 = (undefined)uStack_8;
        uStack_8._0_1_ = 3;
        if (0xf < uStack_3c) {
          uVar13 = uStack_3c + 1;
          uVar14 = auStack_50[0];
          if (0xfff < uVar13) {
            uVar14 = *(uint *)(auStack_50[0] - 4);
            uVar13 = uStack_3c + 0x24;
            if (0x1f < (auStack_50[0] - uVar14) - 4) {
              uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar14,uVar13);
        }
        uStack_40 = 0;
        uStack_3c = 0xf;
        auStack_50[0] = auStack_50[0] & 0xffffff00;
        uStack_8._0_1_ = 0;
        uVar3 = (undefined)uStack_8;
        uStack_8._0_1_ = 0;
        if (0xf < uStack_6c) {
          uVar14 = uStack_6c + 1;
          iVar5 = aiStack_80[0];
          if (0xfff < uVar14) {
            iVar5 = *(int *)(aiStack_80[0] + -4);
            uVar14 = uStack_6c + 0x24;
            if (0x1f < (aiStack_80[0] - iVar5) - 4U) {
              uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar5,uVar14);
        }
      }
      *(int *)(piVar15[1] + 0x38) = *(int *)(piVar15[1] + 0x38) + -1;
      FUN_006d7df0(piVar15 + 1);
      iVar5 = *(int *)(param_3[1] + 0x34);
      if ((iVar5 != 0) && (puVar1 != (uint *)0x0)) {
        if (DAT_01eaf004 != '\0') {
          puStack_1c = *(uint **)(param_3[1] + 0x28);
          if (0xf < puStack_1c[5]) {
            puStack_1c = (uint *)*puStack_1c;
          }
          puStack_14 = (uint *)FUN_009c9510(aiStack_80);
          uStack_8._0_1_ = 6;
          if (0xf < puStack_14[5]) {
            puStack_14 = (uint *)*puStack_14;
          }
          puStack_18 = *(uint **)(iVar5 + 0x28);
          if (0xf < puStack_18[5]) {
            puStack_18 = (uint *)*puStack_18;
          }
          puVar6 = (undefined4 *)FUN_009c9510(auStack_50);
          uStack_8._0_1_ = 7;
          if (0xf < (uint)puVar6[5]) {
            puVar6 = (undefined4 *)*puVar6;
          }
          FUN_01677520(DAT_01eaf004,"newParent %s(%s) adds child %s(%s)",puVar6,puStack_18,
                       puStack_14,puStack_1c);
          uStack_8._0_1_ = 6;
          uVar3 = (undefined)uStack_8;
          uStack_8._0_1_ = 6;
          if (0xf < uStack_3c) {
            uVar13 = uStack_3c + 1;
            uVar14 = auStack_50[0];
            if (0xfff < uVar13) {
              uVar14 = *(uint *)(auStack_50[0] - 4);
              uVar13 = uStack_3c + 0x24;
              if (0x1f < (auStack_50[0] - uVar14) - 4) {
                uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(uVar14,uVar13);
          }
          uStack_40 = 0;
          uStack_3c = 0xf;
          auStack_50[0] = auStack_50[0] & 0xffffff00;
          uStack_8._0_1_ = 0;
          if (0xf < uStack_6c) {
            uVar14 = uStack_6c + 1;
            iVar11 = aiStack_80[0];
            if (0xfff < uVar14) {
              iVar11 = *(int *)(aiStack_80[0] + -4);
              uVar14 = uStack_6c + 0x24;
              if (0x1f < (aiStack_80[0] - iVar11) - 4U) {
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(iVar11,uVar14);
          }
        }
        *(int *)(iVar5 + 0x38) = *(int *)(iVar5 + 0x38) + 1;
        uVar8 = FUN_0060dcd0(&uStack_20,iVar5);
        uStack_8._0_1_ = 9;
        FUN_006d7df0(uVar8);
        uStack_8._0_1_ = 0;
        FUN_00550b30();
      }
    }
  }
  puStack_1c = *(uint **)(param_3[1] + 0x34);
  FUN_00606ea0(&puStack_14,((uint)puStack_1c >> 3) + (int)puStack_1c,&puStack_1c,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  puVar10 = puStack_14;
  if (puStack_14 != (uint *)0x0) {
    if (((DAT_01d5b808 == '\0') || (DAT_01d5b7f8 == '\0')) && (DAT_01d5b800 == '\0')) {
      puVar9 = (uint *)(iStack_34 - iStack_38 >> 3);
      puVar2 = (uint *)((int)(puStack_14[0x11] - puStack_14[0x10]) / 0xc);
      puStack_14 = puVar9;
      if (puVar2 <= puVar9) {
        puStack_14 = puVar2;
      }
    }
    else {
      puStack_14 = (uint *)(*(int *)(param_1 + 0x1c0) - *(int *)(param_1 + 0x1bc) >> 2);
    }
    puStack_18 = (uint *)0x0;
    if (puStack_14 != (uint *)0x0) {
      iStack_24 = 0;
      do {
        if (((DAT_01d5b840 != '\0') && (*(char *)((int)puVar10 + 0x3f) != '\0')) ||
           (((cVar4 = FUN_00621710(), cVar4 == '\0' ||
             (puStack_18 < (uint *)((int)(puVar10[0x11] - puVar10[0x10]) / 0xc))) &&
            (*(char *)(iStack_24 + 8 + puVar10[0x10]) != '\0')))) {
          *(undefined4 *)(iStack_38 + 4 + (int)puStack_18 * 8) = 0;
        }
        cVar4 = FUN_006216f0();
        if (((cVar4 == '\0') && (DAT_01d5b7f8 == '\0')) &&
           ((puVar1 != (uint *)0x0 &&
            ((puStack_18 < (uint *)((int)(puVar1[0x11] - puVar1[0x10]) / 0xc) &&
             (*(char *)(iStack_24 + 9 + puVar1[0x10]) != '\0')))))) {
          if (DAT_01ee420d != '\0') {
            puVar6 = (undefined4 *)FUN_008a2380(aiStack_80);
            uStack_8._0_1_ = 10;
            if (0xf < (uint)puVar6[5]) {
              puVar6 = (undefined4 *)*puVar6;
            }
            FUN_01677490(DAT_01ee420d,
                         "onCombinedSignalChildRemoved():: numCompleteChildren++ for %s[%d]",puVar6,
                         puStack_18,0);
            uStack_8._0_1_ = 0;
            if (0xf < uStack_6c) {
              uVar14 = uStack_6c + 1;
              iVar5 = aiStack_80[0];
              if (0xfff < uVar14) {
                iVar5 = *(int *)(aiStack_80[0] + -4);
                uVar14 = uStack_6c + 0x24;
                if (0x1f < (aiStack_80[0] - iVar5) - 4U) goto LAB_006dc28c;
              }
              FUN_01674ea0(iVar5,uVar14);
            }
          }
          if ((DAT_01d5b820 == '\0') ||
             (((DAT_01d5b840 != '\0' && (*(char *)((int)puVar10 + 0x3f) != '\0')) ||
              (*(char *)(iStack_24 + 8 + puVar10[0x10]) != '\0')))) {
            *(int *)(iStack_24 + puVar10[0x10]) = *(int *)(iStack_24 + puVar10[0x10]) + 1;
          }
        }
        iStack_24 = iStack_24 + 0xc;
        puStack_18 = (uint *)((int)puStack_18 + 1);
      } while (puStack_18 < puStack_14);
    }
  }
  piVar15 = param_2;
  if (DAT_01d5b7f8 == '\0') {
    if (puVar1 != (uint *)0x0) {
      puStack_1c = (uint *)puVar1[0x10];
      puVar10 = (uint *)puVar1[0x11];
      puStack_18 = (uint *)0x0;
      puStack_14 = puVar10;
      if (puStack_1c != puVar10) {
        iStack_24 = 0;
        do {
          piVar15 = param_2;
          if (((*(char *)((int)puStack_1c + 9) != '\0') &&
              (puVar10 = puStack_14, puStack_18 < (uint *)((param_2[0xe] - param_2[0xd]) / 0xc))) &&
             (((DAT_01d5b840 != '\0' && (*(char *)((int)param_2 + 0x33) != '\0')) ||
              (*(char *)(param_2[0xd] + 8 + iStack_24) != '\0')))) {
            if (DAT_01ee420d != '\0') {
              puVar6 = (undefined4 *)FUN_008a2380(aiStack_80);
              uStack_8._0_1_ = 0xb;
              if (0xf < (uint)puVar6[5]) {
                puVar6 = (undefined4 *)*puVar6;
              }
              FUN_01677490(DAT_01ee420d,
                           "onCombinedSignalChildRemoved():: numCompleteChildren-- for %s[%d]",
                           puVar6,puStack_18,0);
              uStack_8._0_1_ = 0;
              if (0xf < uStack_6c) {
                uVar14 = uStack_6c + 1;
                iVar5 = aiStack_80[0];
                if (0xfff < uVar14) {
                  iVar5 = *(int *)(aiStack_80[0] + -4);
                  uVar14 = uStack_6c + 0x24;
                  if (0x1f < (aiStack_80[0] - iVar5) - 4U) goto LAB_006dc28c;
                }
                FUN_01674ea0(iVar5,uVar14);
              }
            }
            *(int *)(piVar15[0xd] + iStack_24) = *(int *)(piVar15[0xd] + iStack_24) + -1;
            puVar10 = puStack_14;
          }
          puStack_1c = puStack_1c + 3;
          puStack_18 = (uint *)((int)puStack_18 + 1);
          iStack_24 = iStack_24 + 0xc;
        } while (puStack_1c != puVar10);
      }
    }
    piVar15 = param_2;
    FUN_006d69e0(param_2);
  }
  if ((DAT_01d5b860 != '\0') && (puVar1 != (uint *)0x0)) {
    FUN_006d7180(puVar1 + 3,param_3,&iStack_38);
  }
  puStack_1c = (uint *)0x0;
  FUN_0060e810(0,&puStack_1c,(int)&param_2 + 3);
  iStack_5c = 0;
  uStack_58 = 0;
  uStack_8._0_1_ = 0xc;
  puStack_1c = (uint *)0x0;
  FUN_0060e810(0,&puStack_1c,(int)&param_2 + 3);
  puVar6 = param_3;
  iStack_8c = 0;
  uStack_88 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  if ((DAT_01d5b840 == '\0') || (*(char *)((int)piVar15 + 0x33) == '\0')) {
    *(undefined *)(piVar15 + 0xc) = 1;
    uVar14 = 0;
    iVar5 = piVar15[0xe] - piVar15[0xd] >> 0x1f;
    if ((piVar15[0xe] - piVar15[0xd]) / 0xc + iVar5 != iVar5) {
      param_2 = (int *)0x0;
      do {
        if (*(char *)(piVar15[0xd] + 8 + (int)param_2) != '\0') {
          FUN_00622400(piVar15 + 1,param_3,iStack_38 + uVar14 * 8,&uStack_68,auStack_98);
        }
        param_2 = param_2 + 3;
        uVar14 = uVar14 + 1;
      } while (uVar14 < (uint)((piVar15[0xe] - piVar15[0xd]) / 0xc));
    }
    *(undefined *)(piVar15 + 0xc) = 0;
  }
  else {
    piVar12 = *(int **)(param_1 + 0x1c0);
    piVar17 = *(int **)(param_1 + 0x1bc);
    param_2 = piVar12;
    if (piVar17 != piVar12) {
      do {
        if (*(char *)(*piVar17 + 0x3894) != '\0') {
          FUN_00622400(piVar15 + 1,puVar6,iStack_38 + *(int *)(*piVar17 + 0x18e8) * 8,&uStack_68,
                       auStack_98);
          piVar12 = param_2;
        }
        piVar17 = piVar17 + 1;
        param_1 = pbStack_2c;
      } while (piVar17 != piVar12);
    }
  }
  if (DAT_01d5b810 != '\0') {
    if (iStack_8c != 0) {
      if (DAT_01eaf007 != '\0') {
        FUN_01677520(DAT_01eaf007,"Adding RefPropertyChange for %zu peers with nextCommonId=%llu",
                     iStack_8c,*(undefined4 *)(param_1 + 0x1f8),*(undefined4 *)(param_1 + 0x1fc));
      }
      pbStack_2c = (byte *)FUN_01674e20(0x40);
      if (pbStack_2c == (byte *)0x0) {
        param_2 = (int *)0x0;
      }
      else {
        param_2 = *(int **)(param_1 + 0x1f8);
        iVar5 = *(int *)(param_1 + 0x1fc);
        *(uint *)(param_1 + 0x1f8) = (int)param_2 + 1;
        *(uint *)(param_1 + 0x1fc) = iVar5 + (uint)(0xfffffffe < param_2);
        puStack_1c = (uint *)param_3[2];
        if (puStack_1c != (uint *)0x0) {
          LOCK();
          puStack_1c[1] = puStack_1c[1] + 1;
          UNLOCK();
          puStack_1c = (uint *)param_3[2];
        }
        uStack_20 = param_3[1];
        uStack_28 = uStack_28 | 2;
        uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
        param_2 = (int *)FUN_006cd8a0(&DAT_0211a3d8,
                                      *(int *)(param_1 + 300) +
                                      (uint)*(ushort *)(param_1 + 0x144) * 0x14,&uStack_20,
                                      auStack_98,param_2,iVar5);
      }
      piVar15 = *(int **)(param_1 + 0x1ec);
      uStack_8 = 0x10;
      if (*(int **)(param_1 + 0x1f0) == piVar15) {
        FUN_006030d0(piVar15,&param_2);
      }
      else {
        *piVar15 = (int)param_2;
        *(int *)(param_1 + 0x1ec) = *(int *)(param_1 + 0x1ec) + 4;
      }
      puVar1 = puStack_1c;
      uStack_8 = 0xd;
      if (((uStack_28 & 2) != 0) && (puStack_1c != (uint *)0x0)) {
        LOCK();
        uVar14 = puStack_1c[1] - 1;
        puStack_1c[1] = uVar14;
        UNLOCK();
        if (uVar14 == 0) {
          (**(code **)*puStack_1c)();
          LOCK();
          puVar10 = puVar1 + 2;
          uVar14 = *puVar10;
          *puVar10 = *puVar10 - 1;
          UNLOCK();
          if (uVar14 == 1) {
            (**(code **)(*puVar1 + 4))();
          }
        }
      }
    }
    if (iStack_5c != 0) {
      if (DAT_01eaf007 != '\0') {
        FUN_01677520(DAT_01eaf007,"Adding DeleteInstance for %zu peers with nextCommonId=%llu",
                     iStack_5c,*(undefined4 *)(param_1 + 0x1f8),*(undefined4 *)(param_1 + 0x1fc));
      }
      pbVar16 = param_1 + 0x1e8;
      uStack_44 = CONCAT31(uStack_44._1_3_,1);
      uStack_40 = *(undefined4 *)(param_3[1] + 0x18);
      param_2 = *(int **)(param_3[1] + 0x1c);
      pbStack_2c = pbVar16;
      puVar6 = (undefined4 *)FUN_01674e20(0x58);
      if (puVar6 == (undefined4 *)0x0) {
        puVar6 = (undefined4 *)0x0;
      }
      else {
        uVar14 = *(uint *)(param_1 + 0x1f8);
        iVar5 = *(int *)(param_1 + 0x1fc);
        *(uint *)(param_1 + 0x1f8) = uVar14 + 1;
        *(uint *)(param_1 + 0x1fc) = iVar5 + (uint)(0xfffffffe < uVar14);
        *puVar6 = RBX::Network::SharedQueueItem::vftable;
        puVar6[2] = 0;
        puVar6[3] = 0;
        puVar6[4] = 0;
        puVar6[2] = uStack_68;
        puVar6[3] = uStack_64;
        puVar6[4] = uStack_60;
        uStack_68 = 0;
        uStack_64 = 0;
        uStack_60 = 0;
        puVar6[5] = iStack_5c;
        puVar6[6] = uStack_58;
        puVar6[8] = uVar14;
        puVar6[9] = iVar5;
        puVar1 = puVar6 + 10;
        *puVar6 = RBX::Network::SharedDeleteInstanceItem::vftable;
        *puVar1 = 0;
        uStack_8._0_1_ = 0x12;
        puVar6[0xb] = 0;
        puVar6[0xc] = 0;
        param_3 = puVar6;
        puStack_1c = puVar1;
        uVar8 = FUN_006d3cd0(0,0);
        puVar6[0xb] = uVar8;
        puVar6[0xd] = 0;
        puVar6[0xe] = 0;
        puVar6[0xf] = 0;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
        *puVar1 = 0x3f800000;
        FUN_005cb500(8);
        *(ulonglong *)(puVar6 + 0x12) = CONCAT44(uStack_40,uStack_44);
        puVar6[0x14] = param_2;
        pbVar16 = pbStack_2c;
      }
      puVar7 = *(undefined4 **)(pbVar16 + 4);
      uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
      param_3 = puVar6;
      if (*(undefined4 **)(pbVar16 + 8) == puVar7) {
        FUN_006030d0(puVar7,&param_3);
      }
      else {
        *puVar7 = puVar6;
        *(int *)(pbVar16 + 4) = *(int *)(pbVar16 + 4) + 4;
      }
    }
  }
  FUN_0056d320();
  FUN_0056d320();
  if (iStack_38 != 0) {
    FUN_0057d330(iStack_38,iStack_30 - iStack_38 >> 3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9360 ; VA 0x006dc2b0 ; FUN_006dc2b0 */

void __thiscall FUN_006dc2b0(int param_1,uint param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  
  piVar3 = param_3;
  uVar5 = param_2;
  if ((param_3 == (int *)0x2) || (param_3 == (int *)&DAT_00000005)) {
    iVar4 = param_1 + 0x18d + (uint)*(byte *)(param_1 + 0x18c);
    FUN_00606ea0(&param_3,(param_2 >> 3) + param_2,&param_2,-(uint)(iVar4 != 0) & iVar4 + 1U);
    if (piVar3 == (int *)0x2) {
      *(undefined4 *)param_3[4] = 0;
      FUN_006ab670();
      return;
    }
    iVar4 = FUN_008f7870(uVar5);
    piVar3 = param_3;
    if (iVar4 == 0) {
      FUN_01679490();
      param_3 = (int *)*piVar3;
      param_2 = (uint)piVar3[1] % *(uint *)(param_1 + 400);
      piVar2 = *(int **)(*(int *)(param_1 + 0x1a0) + param_2 * 4);
      for (piVar6 = (int *)*piVar2; piVar6 != piVar3; piVar6 = (int *)*piVar6) {
        piVar2 = piVar6;
      }
      do {
        *piVar2 = *piVar6;
        piVar3 = (int *)piVar6[5];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[1] + -1;
          piVar3[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar4 = piVar3[2] + -1;
            piVar3[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        iVar4 = piVar6[3];
        if (iVar4 != 0) {
          piVar3 = (int *)(iVar4 + 4);
          LOCK();
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            FUN_01674ea0(iVar4);
          }
        }
        FUN_01674ea0(piVar6,0x18);
        *(int *)(param_1 + 0x194) = *(int *)(param_1 + 0x194) + -1;
        uVar5 = param_2;
        if (*piVar2 == 0) {
LAB_006dc3fc:
          if (*(int **)(*(int *)(param_1 + 0x1a0) + param_2 * 4) == piVar2) {
            *(undefined4 *)(*(int *)(param_1 + 0x1a0) + param_2 * 4) = 0;
          }
        }
        else {
          uVar5 = *(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 400);
          if (param_2 != uVar5) {
            *(int **)(*(int *)(param_1 + 0x1a0) + uVar5 * 4) = piVar2;
            goto LAB_006dc3fc;
          }
        }
        piVar6 = (int *)*piVar2;
        param_2 = uVar5;
      } while (piVar6 != param_3);
    }
  }
  return;
}



/* FUNCTION 9361 ; VA 0x006dc430 ; FUN_006dc430 */

void __thiscall FUN_006dc430(int param_1,int *param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 uVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  undefined auStack_48 [24];
  int aiStack_30 [2];
  int iStack_28;
  int iStack_24;
  undefined4 uStack_20;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar8 = (uint)param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8ec8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  if (*(undefined4 **)((int)param_2 + 0x14) != (undefined4 *)0x0) {
    ExceptionList = &pvStack_10;
    **(undefined4 **)((int)param_2 + 0x14) = 0;
    FUN_006ab670();
  }
  if (*(undefined4 **)(uVar8 + 0xc) != (undefined4 *)0x0) {
    **(undefined4 **)(uVar8 + 0xc) = 0;
    FUN_006ab670();
  }
  cVar1 = FUN_00620ff0(*(undefined4 *)(param_3 + 4));
  if ((cVar1 != '\0') &&
     (cVar1 = FUN_00618b80(*(undefined *)(param_1 + 0x26c),*(undefined4 *)(param_3 + 4)),
     cVar1 != '\0')) {
    iVar2 = (**(code **)(**(int **)(param_3 + 4) + 0x44))(*(undefined4 *)(uVar8 + 4));
    param_2 = *(int **)(param_3 + 4);
    if (iVar2 == 0) {
      uVar4 = 0xffffffff;
      uVar6 = 0;
    }
    else {
      uVar4 = *(undefined4 *)(iVar2 + 0x18);
      uVar6 = *(undefined4 *)(iVar2 + 0x1c);
    }
    FUN_006e0360(*(undefined4 *)(*(int *)(uVar8 + 4) + 0x18),
                 *(undefined4 *)(*(int *)(uVar8 + 4) + 0x1c),uVar4,uVar6,param_2);
  }
  if (*(undefined4 **)(param_3 + 4) == &DAT_0211a3d8) {
    ExceptionList = pvStack_10;
    return;
  }
  if ((DAT_01d5b278 != '\0') && (*(char *)(uVar8 + 0x31) == '\0')) {
    ExceptionList = pvStack_10;
    return;
  }
  if ((DAT_01d5b820 == '\0') || (*(int *)(param_1 + 0x1c) == 0)) goto LAB_006dc621;
  iVar2 = FUN_006bf290();
  if ((iVar2 == 0) || (*(char *)(iVar2 + 0x300) == '\0')) {
LAB_006dc54e:
    param_2 = (int *)((uint)param_2 & 0xffffff00);
  }
  else {
    param_2 = (int *)CONCAT31(param_2._1_3_,1);
    if (*(char *)(param_1 + 0x26c) != '\0') goto LAB_006dc54e;
  }
  iStack_14 = CONCAT31(iStack_14._1_3_,iVar2 != 0);
  cVar1 = FUN_006d9d30(*(undefined4 *)(uVar8 + 4),iStack_14,param_2);
  if (cVar1 == '\0') {
    if (DAT_01ee420d != '\0') {
      puVar3 = (undefined4 *)FUN_008a2380(auStack_48);
      uStack_8 = 1;
      if (0xf < (uint)puVar3[5]) {
        puVar3 = (undefined4 *)*puVar3;
      }
      FUN_016774b0(DAT_01ee420d,
                   "onCombinedSignalProperty():: instance MRD for instance %s must not exist in mrdCache"
                   ,puVar3);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
  }
  else {
    if (DAT_01ee420d != '\0') {
      puVar3 = (undefined4 *)FUN_008a2380(auStack_48);
      uStack_8 = 0;
      if (0xf < (uint)puVar3[5]) {
        puVar3 = (undefined4 *)*puVar3;
      }
      FUN_016774b0(DAT_01ee420d,
                   "onCombinedSignalProperty()::Adding instance MRD for instance %s to BlobCacheMRPMap"
                   ,puVar3);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
    uVar4 = FUN_006d9e30(*(undefined4 *)(uVar8 + 4));
    FUN_006c90c0(uVar8,1,1,uVar4);
    param_1 = iStack_18;
  }
LAB_006dc621:
  if (*(char *)(uVar8 + 0x31) != '\0') {
    iStack_14 = 0;
    FUN_0060e810(0,&iStack_14,(int)&param_2 + 3);
    iStack_24 = 0;
    uStack_20 = 0;
    uStack_8 = 2;
    if ((DAT_01d5b840 == '\0') || (*(char *)(uVar8 + 0x33) == '\0')) {
      *(undefined *)(uVar8 + 0x30) = 1;
      iVar7 = *(int *)(uVar8 + 0x38) - *(int *)(uVar8 + 0x34);
      param_2 = (int *)0x0;
      iVar2 = iVar7 >> 0x1f;
      if (iVar7 / 0xc + iVar2 != iVar2) {
        iStack_14 = 0;
        do {
          if (*(char *)(*(int *)(uVar8 + 0x34) + 8 + iStack_14) != '\0') {
            FUN_00622630(uVar8 + 4,*(undefined4 *)(uVar8 + 0x1c),param_3,aiStack_30);
          }
          param_2 = (int *)((int)param_2 + 1);
          iStack_14 = iStack_14 + 0xc;
        } while (param_2 < (int *)((*(int *)(uVar8 + 0x38) - *(int *)(uVar8 + 0x34)) / 0xc));
      }
      *(undefined *)(uVar8 + 0x30) = 0;
    }
    else {
      piVar5 = *(int **)(param_1 + 0x1c0);
      piVar9 = *(int **)(param_1 + 0x1bc);
      param_2 = piVar5;
      if (piVar9 != piVar5) {
        do {
          if (*(char *)(*piVar9 + 0x3894) != '\0') {
            FUN_00622630(uVar8 + 4,*(undefined4 *)(uVar8 + 0x1c),param_3,aiStack_30);
            piVar5 = param_2;
          }
          piVar9 = piVar9 + 1;
        } while (piVar9 != piVar5);
      }
    }
    if ((DAT_01d5b810 != '\0') && (iStack_24 != 0)) {
      FUN_006d4700(aiStack_30,param_3,uVar8);
    }
    if (aiStack_30[0] != 0) {
      uVar8 = iStack_28 - aiStack_30[0] & 0xfffffffc;
      iVar2 = aiStack_30[0];
      if (0xfff < uVar8) {
        iVar2 = *(int *)(aiStack_30[0] + -4);
        uVar8 = uVar8 + 0x23;
        if (0x1f < (aiStack_30[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar8);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9362 ; VA 0x006dc7a0 ; FUN_006dc7a0 */

void __thiscall FUN_006dc7a0(int param_1,undefined4 param_2,char param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (((DAT_01d5b9c0 != '\0') && (param_3 == '\0')) && (*(int *)(param_1 + 0xbc) != 0)) {
    FUN_0071d6f0(param_2);
    piVar1 = *(int **)(param_1 + 0x1c0);
    for (piVar3 = *(int **)(param_1 + 0x1bc); piVar3 != piVar1; piVar3 = piVar3 + 1) {
      iVar2 = *piVar3;
      if (((*(char *)(iVar2 + 0x1db9) == '\0') && (*(char *)(iVar2 + 0x37f8) != '\0')) &&
         (*(int *)(iVar2 + 0x1de4) != 0)) {
        FUN_006e6a20(param_2);
      }
    }
  }
  return;
}



/* FUNCTION 9363 ; VA 0x006dc820 ; FUN_006dc820 */

void __fastcall FUN_006dc820(int param_1)

{
  if ((DAT_01d5b9c0 != '\0') && (*(int *)(param_1 + 0xbc) != 0)) {
    FUN_0071c600();
    return;
  }
  return;
}



/* FUNCTION 9364 ; VA 0x006dc840 ; FUN_006dc840 */

void __thiscall FUN_006dc840(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (DAT_01d5b9b8 != '\0') {
    piVar1 = *(int **)(param_1 + 0x1c0);
    for (piVar3 = *(int **)(param_1 + 0x1bc); piVar3 != piVar1; piVar3 = piVar3 + 1) {
      iVar2 = *piVar3;
      if (((*(char *)(iVar2 + 0x1db9) == '\0') && (*(char *)(iVar2 + 0x37f8) != '\0')) &&
         (*(int *)(iVar2 + 0x1de4) != 0)) {
        FUN_006e6a40(param_2,param_3);
      }
    }
    if ((((char)param_3 == '\0') && (DAT_01d5b9c0 != '\0')) && (*(int *)(param_1 + 0xbc) != 0)) {
      FUN_0071c670(param_2);
    }
  }
  *(undefined *)(param_1 + 0x85) = 1;
  return;
}



/* FUNCTION 9365 ; VA 0x006dc8d0 ; FUN_006dc8d0 */

void __fastcall FUN_006dc8d0(int param_1)

{
  FUN_01679490();
  if ((DAT_01d5b878 != '\0') && (DAT_01eaf006 != '\0')) {
    FUN_01677520(DAT_01eaf006,"prepareForRemoval MRD[%p]",param_1);
  }
  if (*(undefined4 **)(param_1 + 0xc) != (undefined4 *)0x0) {
    **(undefined4 **)(param_1 + 0xc) = 2;
    FUN_006ab670();
  }
  if (*(undefined4 **)(param_1 + 0x14) != (undefined4 *)0x0) {
    **(undefined4 **)(param_1 + 0x14) = 2;
    FUN_006ab670();
    return;
  }
  return;
}



/* FUNCTION 9366 ; VA 0x006dc930 ; FUN_006dc930 */

bool FUN_006dc930(int param_1,int param_2,int *param_3,char param_4)

{
  float fVar1;
  float fVar2;
  
  fVar1 = *(float *)(*param_3 + param_1 * 4);
  fVar2 = *(float *)(*param_3 + param_2 * 4);
  if (param_4 == '\0') {
    return fVar2 < fVar1;
  }
  return fVar1 < fVar2;
}



/* FUNCTION 9367 ; VA 0x006dc960 ; FUN_006dc960 */

void __fastcall FUN_006dc960(uint *param_1)

{
  uint *******pppppppuVar1;
  uint ******ppppppuVar2;
  uint *****pppppuVar3;
  int iVar4;
  undefined4 *puVar5;
  uint *******pppppppuVar6;
  uint uVar7;
  uint *****pppppuVar8;
  uint *****pppppuVar9;
  uint *******pppppppuVar10;
  uint *puVar11;
  uint ******ppppppuVar12;
  uint *******pppppppuVar13;
  undefined8 uVar14;
  undefined8 uStack_12c;
  uint ******appppppuStack_118 [5];
  uint uStack_104;
  uint ******appppppuStack_100 [5];
  uint uStack_ec;
  uint ******appppppuStack_e8 [5];
  uint uStack_d4;
  uint ******appppppuStack_d0 [5];
  uint uStack_bc;
  uint ******appppppuStack_b8 [4];
  undefined4 uStack_a8;
  uint uStack_a4;
  uint *****pppppuStack_a0;
  int *piStack_9c;
  uint uStack_98;
  uint uStack_94;
  uint uStack_90;
  uint uStack_8c;
  uint ******ppppppuStack_88;
  uint ******ppppppuStack_84;
  undefined8 uStack_80;
  uint ******ppppppuStack_78;
  uint *puStack_74;
  undefined8 uStack_70;
  uint uStack_68;
  uint uStack_64;
  uint *****pppppuStack_60;
  uint uStack_5c;
  uint uStack_58;
  uint ******ppppppuStack_54;
  uint ******ppppppuStack_50;
  uint ******ppppppuStack_4c;
  uint *****pppppuStack_48;
  uint *****pppppuStack_44;
  uint ******ppppppuStack_40;
  uint ******ppppppuStack_3c;
  uint ******ppppppuStack_38;
  uint ******ppppppuStack_34;
  uint ******ppppppuStack_30;
  uint ******ppppppuStack_2c;
  uint ******ppppppuStack_28;
  uint ******ppppppuStack_24;
  uint ******ppppppuStack_20;
  uint *puStack_1c;
  uint ******ppppppuStack_18;
  uint ******ppppppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8f7e;
  pvStack_10 = ExceptionList;
  ppppppuStack_24 = (uint ******)0x0;
  ppppppuStack_2c = *(uint *******)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  puStack_1c = param_1;
  if ((int)((uint *******)ppppppuStack_2c)[0xd] < DAT_01eaf1d8) {
    uStack_12c._4_4_ = (uint *******)&DAT_01eaf1d8;
    uStack_12c._0_4_ = (char *)0x6dd284;
    ExceptionList = &pvStack_10;
    FUN_016f3809();
    if (DAT_01eaf1d8 == -1) {
      uStack_12c._4_4_ = (uint *******)0xffffffff;
      uStack_12c._0_4_ = "CompletenessPropagation";
      uStack_8 = 0;
      uVar14 = FUN_0152dab0(&DAT_018c5904);
      DAT_01eaf1d4 = (uint *******)((ulonglong)uVar14 >> 0x20);
      DAT_01eaf1d0 = (uint *******)uVar14;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eaf1d8);
    }
  }
  uStack_12c._4_4_ = DAT_01eaf1d4;
  uStack_12c._0_4_ = (char *)DAT_01eaf1d0;
  ppppppuStack_88 = (uint ******)DAT_01eaf1d0;
  ppppppuStack_84 = (uint ******)DAT_01eaf1d4;
  uStack_80 = FUN_0152d930();
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  if (DAT_01eaf005 != '\0') {
    uStack_12c._4_4_ = (uint *******)param_1[2];
    uStack_12c._0_4_ = "propagate: %d";
    FUN_01677520(DAT_01eaf005);
  }
  ppppppuStack_14 = (uint ******)0x0;
  ppppppuStack_54 = (uint ******)0x0;
  ppppppuStack_50 = (uint ******)0x0;
  ppppppuStack_4c = (uint ******)0x0;
  pppppppuVar13 = (uint *******)0x0;
  ppppppuStack_18 = (uint ******)0x0;
  ppppppuStack_38 = (uint ******)0x0;
  ppppppuStack_34 = (uint ******)0x0;
  ppppppuStack_30 = (uint ******)0x0;
  if (puStack_1c[2] != 0) {
    do {
      puVar5 = (undefined4 *)(puStack_1c[3] + (puStack_1c[1] % *puStack_1c) * 8);
      ppppppuStack_3c = (uint ******)0x0;
      puStack_1c[1] = (puStack_1c[1] + 1) % *puStack_1c;
      ppppppuStack_18 = (uint ******)*puVar5;
      ppppppuStack_14 = (uint ******)puVar5[1];
      *puVar5 = 0;
      puVar5[1] = 0;
      puStack_1c[2] = puStack_1c[2] - 1;
      ppppppuStack_40 = (uint ******)0x0;
      pppppppuVar10 = (uint *******)ppppppuStack_40;
      pppppppuVar6 = (uint *******)ppppppuStack_3c;
      if ((uint *******)ppppppuStack_14 != (uint *******)0x0) {
        pppppppuVar1 = (uint *******)ppppppuStack_14 + 1;
        ppppppuVar2 = ((uint *******)ppppppuStack_14)[1];
        while (pppppppuVar13 = (uint *******)ppppppuStack_34,
              pppppppuVar10 = (uint *******)ppppppuStack_40,
              pppppppuVar6 = (uint *******)ppppppuStack_3c, ppppppuVar2 != (uint ******)0x0) {
          LOCK();
          ppppppuVar12 = *pppppppuVar1;
          if (ppppppuVar2 == ppppppuVar12) {
            *pppppppuVar1 = (uint ******)((int)ppppppuVar2 + 1);
            ppppppuVar12 = ppppppuVar2;
          }
          UNLOCK();
          pppppppuVar10 = (uint *******)ppppppuStack_18;
          pppppppuVar6 = (uint *******)ppppppuStack_14;
          if (ppppppuVar12 == ppppppuVar2) break;
          ppppppuVar2 = *pppppppuVar1;
        }
      }
      ppppppuStack_3c = (uint ******)pppppppuVar6;
      ppppppuStack_40 = (uint ******)pppppppuVar10;
      ppppppuVar2 = ppppppuStack_3c;
      pppppppuVar10 = (uint *******)ppppppuStack_40;
      uStack_8._0_1_ = 4;
      if ((uint *******)ppppppuStack_14 != (uint *******)0x0) {
        LOCK();
        ppppppuVar12 = (uint ******)((int)((uint *******)ppppppuStack_14)[2] - 1);
        ((uint *******)ppppppuStack_14)[2] = ppppppuVar12;
        UNLOCK();
        if (ppppppuVar12 == (uint ******)0x0) {
          uStack_12c._4_4_ = (uint *******)0x6dcaae;
          (*(code *)(*ppppppuStack_14)[1])();
        }
      }
      if (pppppppuVar10 != (uint *******)0x0) {
        ppppppuStack_20 = (uint ******)pppppppuVar10;
        if (DAT_01eaf005 != '\0') {
          if (pppppppuVar10[0xd] == (uint ******)0x0) {
            ppppppuStack_14 = (uint ******)0x0;
          }
          else {
            uStack_12c._4_4_ = appppppuStack_d0;
            uStack_12c._0_4_ = (char *)0x6dcadc;
            ppppppuStack_14 = (uint ******)FUN_009c9510();
            ppppppuStack_24 = (uint ******)((uint)ppppppuStack_24 | 1);
            uStack_8._0_1_ = 5;
            if ((uint ******)0xf < ((uint *******)ppppppuStack_14)[5]) {
              ppppppuStack_14 = (uint ******)*ppppppuStack_14;
            }
          }
          ppppppuVar12 = pppppppuVar10[0x10];
          ppppppuStack_18 = (uint ******)((uint)ppppppuVar12 >> 0x1c & 1);
          uStack_58 = (uint)ppppppuVar12 >> 0x1b & 1;
          uStack_5c = (uint)ppppppuVar12 & 0xffffff;
          pppppuStack_60 = (uint *****)pppppppuVar10[0xf];
          uStack_64 = (uint)ppppppuVar12 >> 0x19 & 1;
          ppppppuStack_28 = (uint ******)((uint)ppppppuVar12 >> 0x18 & 1);
          uStack_68 = (uint)ppppppuVar12 >> 0x1a & 1;
          uStack_12c._4_4_ = appppppuStack_b8;
          uStack_12c._0_4_ = (char *)0x6dcb63;
          puVar5 = (undefined4 *)FUN_009c9510();
          uStack_8 = 6;
          if (0xf < (uint)puVar5[5]) {
            puVar5 = (undefined4 *)*puVar5;
          }
          uStack_12c._4_4_ = (uint *******)ppppppuStack_14;
          uStack_12c._0_4_ = (char *)ppppppuStack_18;
          FUN_01677520(DAT_01eaf005,
                       "   %s is:%d ack:%d new:%d expected:%d computed:%d enq:%d fenq:%d parent:%s",
                       puVar5,ppppppuStack_28,uStack_68,uStack_64,pppppuStack_60,uStack_5c,uStack_58
                      );
          uStack_8._0_1_ = 5;
          if (0xf < uStack_a4) {
            uStack_12c._4_4_ = (uint *******)(uStack_a4 + 1);
            pppppppuVar6 = (uint *******)appppppuStack_b8[0];
            if ((uint *******)0xfff < uStack_12c._4_4_) {
              pppppppuVar6 = (uint *******)appppppuStack_b8[0][-1];
              uStack_12c._4_4_ = (uint *******)(uStack_a4 + 0x24);
              if (0x1f < (uint)((int)appppppuStack_b8[0] + (-4 - (int)pppppppuVar6)))
              goto LAB_006dd320;
            }
            uStack_12c._0_4_ = (char *)pppppppuVar6;
            FUN_01674ea0();
          }
          uStack_a8 = 0;
          uStack_a4 = 0xf;
          appppppuStack_b8[0] = (uint ******)((uint)appppppuStack_b8[0] & 0xffffff00);
          uStack_8._0_1_ = 4;
          uStack_8._1_3_ = 0;
          if ((((uint)ppppppuStack_24 & 1) != 0) &&
             (ppppppuStack_24 = (uint ******)((uint)ppppppuStack_24 & 0xfffffffe), 0xf < uStack_bc))
          {
            uStack_12c._4_4_ = (uint *******)(uStack_bc + 1);
            pppppppuVar6 = (uint *******)appppppuStack_d0[0];
            if ((uint *******)0xfff < uStack_12c._4_4_) {
              pppppppuVar6 = (uint *******)appppppuStack_d0[0][-1];
              uStack_12c._4_4_ = (uint *******)(uStack_bc + 0x24);
              if (0x1f < (uint)((int)appppppuStack_d0[0] + (-4 - (int)pppppppuVar6)))
              goto LAB_006dd320;
            }
            uStack_12c._0_4_ = (char *)pppppppuVar6;
            FUN_01674ea0();
          }
        }
        ppppppuStack_14 = (uint ******)(pppppppuVar10 + 0x10);
        ppppppuVar12 = (uint ******)((uint)pppppppuVar10[0x10] & 0xf7ffffff);
        *ppppppuStack_14 = (uint *****)ppppppuVar12;
        if ((((uint)ppppppuVar12 >> 1 ^ (uint)ppppppuVar12) & 0x2000000) != 0) {
          ppppppuVar12 = (uint ******)
                         (((int)ppppppuVar12 * 2 ^ (uint)ppppppuVar12) & 0x4000000 ^
                         (uint)ppppppuVar12);
          *ppppppuStack_14 = (uint *****)ppppppuVar12;
          if (((((uint)ppppppuVar12 >> 2 ^ (uint)ppppppuVar12) & 0x1000000) != 0) &&
             (((uint)ppppppuVar12 & 0x10000000) == 0)) {
            *ppppppuStack_14 = (uint *****)((uint)ppppppuVar12 | 0x10000000);
            if (DAT_01d5b858 == '\0') {
              if (ppppppuStack_4c == ppppppuStack_50) {
                uStack_12c._4_4_ = &ppppppuStack_20;
                uStack_12c._0_4_ = (char *)ppppppuStack_50;
                FUN_006030d0();
                pppppppuVar10 = (uint *******)ppppppuStack_20;
              }
              else {
                *ppppppuStack_50 = (uint *****)pppppppuVar10;
                ppppppuStack_50 = ppppppuStack_50 + 1;
              }
            }
            else {
              uStack_12c._0_4_ = (char *)&pppppuStack_a0;
              uStack_12c._4_4_ = pppppppuVar10;
              pppppppuVar6 = (uint *******)FUN_0060e0c0();
              uStack_8._0_1_ = 8;
              if ((uint *******)ppppppuStack_30 == pppppppuVar13) {
                uStack_12c._0_4_ = (char *)pppppppuVar13;
                uStack_12c._4_4_ = pppppppuVar6;
                FUN_006ce750();
              }
              else {
                *pppppppuVar13 = (uint ******)0x0;
                pppppppuVar13[1] = (uint ******)0x0;
                *pppppppuVar13 = *pppppppuVar6;
                pppppppuVar13[1] = pppppppuVar6[1];
                ppppppuStack_34 = (uint ******)(pppppppuVar13 + 2);
                *pppppppuVar6 = (uint ******)0x0;
                pppppppuVar6[1] = (uint ******)0x0;
              }
              pppppppuVar13 = (uint *******)ppppppuStack_34;
              uStack_8._0_1_ = 4;
              if (piStack_9c != (int *)0x0) {
                LOCK();
                iVar4 = piStack_9c[2] + -1;
                piStack_9c[2] = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  uStack_12c._4_4_ = (uint *******)0x6dcd1b;
                  (**(code **)(*piStack_9c + 4))();
                }
              }
            }
          }
          ppppppuStack_20 = pppppppuVar10[0xd];
          if ((uint *******)ppppppuStack_20 != (uint *******)0x0) {
            ppppppuVar12 = ((uint *******)ppppppuStack_20)[0x10];
            ppppppuVar12 = (uint ******)
                           ((((-(uint)(((uint)*ppppppuStack_14 & 0x4000000) != 0) & 2) - 1) +
                             (int)ppppppuVar12 ^ (uint)ppppppuVar12) & 0xffffff ^ (uint)ppppppuVar12
                           );
            ((uint *******)ppppppuStack_20)[0x10] = ppppppuVar12;
            if (DAT_01eaf005 != '\0') {
              ppppppuStack_28 = ((uint *******)ppppppuStack_20)[0xf];
              uStack_12c._4_4_ = appppppuStack_e8;
              uStack_12c._0_4_ = (char *)0x6dcd9a;
              puVar5 = (undefined4 *)FUN_009c9510();
              uStack_8._0_1_ = 9;
              if (0xf < (uint)puVar5[5]) {
                puVar5 = (undefined4 *)*puVar5;
              }
              uStack_12c._4_4_ = (uint *******)ppppppuStack_28;
              uStack_12c._0_4_ = (char *)((uint)ppppppuVar12 & 0xffffff);
              FUN_01677520(DAT_01eaf005,"    parent %s upd computed:%d expected:%d",puVar5);
              uStack_8._0_1_ = 4;
              if (0xf < uStack_d4) {
                uStack_12c._4_4_ = (uint *******)(uStack_d4 + 1);
                pppppppuVar10 = (uint *******)appppppuStack_e8[0];
                if ((uint *******)0xfff < uStack_12c._4_4_) {
                  pppppppuVar10 = (uint *******)appppppuStack_e8[0][-1];
                  uStack_12c._4_4_ = (uint *******)(uStack_d4 + 0x24);
                  if (0x1f < (uint)((int)appppppuStack_e8[0] + (-4 - (int)pppppppuVar10)))
                  goto LAB_006dd320;
                }
                uStack_12c._0_4_ = (char *)pppppppuVar10;
                FUN_01674ea0();
              }
            }
            FUN_0060dcd0(&uStack_12c,ppppppuStack_20);
            FUN_006d7b90();
          }
        }
      }
      if ((uint *******)ppppppuVar2 != (uint *******)0x0) {
        LOCK();
        ppppppuVar12 = (uint ******)((int)ppppppuVar2[1] - 1);
        ppppppuVar2[1] = (uint *****)ppppppuVar12;
        UNLOCK();
        if (ppppppuVar12 == (uint ******)0x0) {
          uStack_12c._4_4_ = (uint *******)0x6dce2c;
          (*(code *)**ppppppuVar2)();
          LOCK();
          ppppppuVar12 = (uint ******)((int)ppppppuVar2[2] - 1);
          ppppppuVar2[2] = (uint *****)ppppppuVar12;
          UNLOCK();
          if (ppppppuVar12 == (uint ******)0x0) {
            uStack_12c._4_4_ = (uint *******)0x6dce3d;
            (*(code *)(*ppppppuVar2)[1])();
          }
        }
      }
    } while (puStack_1c[2] != 0);
    ppppppuStack_14 = ppppppuStack_54;
    ppppppuStack_18 = ppppppuStack_38;
  }
  ppppppuVar12 = ppppppuStack_18;
  ppppppuVar2 = ppppppuStack_50;
  uStack_12c._4_4_ = (uint *******)0x40;
  uStack_8._0_1_ = 10;
  uStack_12c._0_4_ = (char *)0x6dce64;
  ppppppuStack_54 = ppppppuStack_14;
  ppppppuStack_38 = ppppppuStack_18;
  uVar7 = FUN_01674f30();
  uStack_8._0_1_ = 3;
  uStack_98 = *puStack_1c;
  *puStack_1c = 8;
  uStack_94 = puStack_1c[1];
  puStack_1c[1] = 0;
  uStack_90 = puStack_1c[2];
  puStack_1c[2] = 0;
  uStack_8c = puStack_1c[3];
  puStack_1c[3] = uVar7;
  uStack_12c._4_4_ = (uint *******)0x6dceb8;
  FUN_006d1780();
  if ((int)ppppppuStack_2c[0xd] < DAT_01eaf1e8) {
    uStack_12c._4_4_ = (uint *******)&DAT_01eaf1e8;
    uStack_12c._0_4_ = (char *)0x6dd2da;
    FUN_016f3809();
    if (DAT_01eaf1e8 == -1) {
      uStack_12c._4_4_ = (uint *******)0xffffffff;
      uStack_12c._0_4_ = "CompletenessFinalization";
      uStack_8._0_1_ = 0xb;
      uVar14 = FUN_0152dab0(&DAT_018c5904);
      DAT_01eaf1e4 = (uint *)((ulonglong)uVar14 >> 0x20);
      DAT_01eaf1e0 = (uint *******)uVar14;
      uStack_8._0_1_ = 3;
      FUN_016f37bf(&DAT_01eaf1e8);
    }
  }
  uStack_12c._4_4_ = (uint *******)DAT_01eaf1e4;
  uStack_12c._0_4_ = (char *)DAT_01eaf1e0;
  ppppppuStack_24 = (uint ******)DAT_01eaf1e0;
  ppppppuStack_78 = (uint ******)DAT_01eaf1e0;
  puStack_1c = DAT_01eaf1e4;
  puStack_74 = DAT_01eaf1e4;
  uStack_70 = FUN_0152d930();
  pppppppuVar10 = (uint *******)ppppppuStack_14;
  uStack_8._0_1_ = 0xc;
  if (DAT_01d5b858 == '\0') {
    pppppppuVar6 = (uint *******)ppppppuStack_24;
    puVar11 = puStack_1c;
    if (DAT_01eaf005 != '\0') {
      uStack_12c._4_4_ = (uint *******)((int)ppppppuVar2 - (int)ppppppuStack_14 >> 2);
      uStack_12c._0_4_ = "propagation finalize queue: %d";
      FUN_01677520(DAT_01eaf005);
      goto LAB_006dcf2a;
    }
  }
  else {
    if (DAT_01eaf005 != '\0') {
      uStack_12c._4_4_ = (uint *******)((int)pppppppuVar13 - (int)ppppppuVar12 >> 3);
      uStack_12c._0_4_ = "propagation finalize queue: %d";
      FUN_01677520(DAT_01eaf005);
      pppppppuVar10 = (uint *******)ppppppuStack_14;
    }
LAB_006dcf2a:
    pppppppuVar6 = (uint *******)ppppppuStack_24;
    puVar11 = puStack_1c;
    if (DAT_01d5b858 != '\0') {
      if ((uint *******)ppppppuStack_18 != pppppppuVar13) {
        do {
          pppppuStack_48 = (uint *****)0x0;
          pppppuStack_44 = (uint *****)0x0;
          if ((uint ******)ppppppuStack_18[1] != (uint ******)0x0) {
            ppppppuVar2 = (uint ******)(ppppppuStack_18[1] + 1);
            pppppuVar3 = *ppppppuVar2;
            while (pppppppuVar13 = (uint *******)ppppppuStack_34, pppppuVar3 != (uint *****)0x0) {
              LOCK();
              pppppuVar8 = *ppppppuVar2;
              if (pppppuVar3 == pppppuVar8) {
                *ppppppuVar2 = (uint *****)((int)pppppuVar3 + 1);
                pppppuVar8 = pppppuVar3;
              }
              UNLOCK();
              if (pppppuVar8 == pppppuVar3) {
                pppppuStack_48 = *ppppppuStack_18;
                pppppuStack_44 = ppppppuStack_18[1];
                break;
              }
              pppppuVar3 = *ppppppuVar2;
            }
          }
          pppppuVar8 = pppppuStack_44;
          pppppuVar3 = pppppuStack_48;
          uStack_8._0_1_ = 0xd;
          if ((uint ******)pppppuStack_48 != (uint ******)0x0) {
            pppppuVar9 = (uint *****)((uint)pppppuStack_48[0x10] & 0xefffffff);
            pppppuStack_48[0x10] = (uint ****)pppppuVar9;
            ppppppuStack_2c = (uint ******)((uint)pppppuVar9 >> 0x1a & 1);
            ppppppuStack_28 = (uint ******)((uint)pppppuVar9 >> 0x18 & 1);
            if (ppppppuStack_28 != ppppppuStack_2c) {
              if (DAT_01eaf005 != '\0') {
                ppppppuStack_20 = (uint ******)pppppuStack_48[10];
                if ((uint ******)0xf < ((uint *******)ppppppuStack_20)[5]) {
                  ppppppuStack_20 = (uint ******)*ppppppuStack_20;
                }
                uStack_12c._4_4_ = appppppuStack_100;
                uStack_12c._0_4_ = (char *)0x6dd024;
                puVar5 = (undefined4 *)FUN_009c9510();
                uStack_8._0_1_ = 0xe;
                if (0xf < (uint)puVar5[5]) {
                  puVar5 = (undefined4 *)*puVar5;
                }
                uStack_12c._4_4_ = (uint *******)ppppppuStack_2c;
                uStack_12c._0_4_ = (char *)ppppppuStack_28;
                FUN_01677520(DAT_01eaf005,"  %s(%s) is:%d->%d, signaling",puVar5,ppppppuStack_20);
                uStack_8._0_1_ = 0xd;
                if (0xf < uStack_ec) {
                  uStack_12c._4_4_ = (uint *******)(uStack_ec + 1);
                  pppppppuVar10 = (uint *******)appppppuStack_100[0];
                  if (0xfff < uStack_12c._4_4_) {
                    pppppppuVar10 = (uint *******)appppppuStack_100[0][-1];
                    uStack_12c._4_4_ = (uint *******)(uStack_ec + 0x24);
                    if (0x1f < (uint)((int)appppppuStack_100[0] + (-4 - (int)pppppppuVar10)))
                    goto LAB_006dd320;
                  }
                  uStack_12c._0_4_ = (char *)pppppppuVar10;
                  FUN_01674ea0();
                }
                pppppuVar9 = (uint *****)pppppuVar3[0x10];
              }
              pppppuVar3[0x10] =
                   (uint ****)
                   (((uint)pppppuVar9 >> 2 ^ (uint)pppppuVar9) & 0x1000000 ^ (uint)pppppuVar9);
              uStack_12c._4_4_ = (uint *******)0x6dd0a8;
              (*(code *)(*pppppuVar3)[0x18])();
            }
          }
          if ((uint ******)pppppuVar8 != (uint ******)0x0) {
            LOCK();
            pppppuVar3 = (uint *****)((int)pppppuVar8[1] + -1);
            pppppuVar8[1] = (uint ****)pppppuVar3;
            UNLOCK();
            if (pppppuVar3 == (uint *****)0x0) {
              uStack_12c._4_4_ = (uint *******)0x6dd0bc;
              (*(code *)**pppppuVar8)();
              LOCK();
              pppppuVar3 = (uint *****)((int)pppppuVar8[2] + -1);
              pppppuVar8[2] = (uint ****)pppppuVar3;
              UNLOCK();
              if (pppppuVar3 == (uint *****)0x0) {
                uStack_12c._4_4_ = (uint *******)0x6dd0cd;
                (*(code *)(*pppppuVar8)[1])();
              }
            }
          }
          ppppppuStack_18 = (uint ******)((uint *******)ppppppuStack_18 + 2);
        } while ((uint *******)ppppppuStack_18 != pppppppuVar13);
        ppppppuStack_14 = ppppppuStack_54;
        pppppppuVar6 = (uint *******)ppppppuStack_78;
        puVar11 = puStack_74;
      }
      goto LAB_006dd1ed;
    }
  }
  for (; ppppppuStack_24 = (uint ******)pppppppuVar6, puStack_1c = puVar11,
      pppppppuVar10 != (uint *******)ppppppuVar2; pppppppuVar10 = pppppppuVar10 + 1) {
    ppppppuStack_18 = *pppppppuVar10;
    ppppppuVar12 = (uint ******)((uint)((uint *******)ppppppuStack_18)[0x10] & 0xefffffff);
    ((uint *******)ppppppuStack_18)[0x10] = ppppppuVar12;
    pppppppuVar13 = (uint *******)((uint)ppppppuVar12 >> 0x1a & 1);
    ppppppuStack_2c = (uint ******)((uint)ppppppuVar12 >> 0x18 & 1);
    if ((uint *******)ppppppuStack_2c != pppppppuVar13) {
      if (DAT_01eaf005 != '\0') {
        ppppppuStack_20 = (uint ******)(*pppppppuVar10)[10];
        if ((uint ******)0xf < ((uint *******)ppppppuStack_20)[5]) {
          ppppppuStack_20 = (uint ******)*ppppppuStack_20;
        }
        uStack_12c._4_4_ = appppppuStack_118;
        uStack_12c._0_4_ = (char *)0x6dd152;
        puVar5 = (undefined4 *)FUN_009c9510();
        uStack_8._0_1_ = 0xf;
        if (0xf < (uint)puVar5[5]) {
          puVar5 = (undefined4 *)*puVar5;
        }
        uStack_12c._0_4_ = (char *)ppppppuStack_2c;
        uStack_12c._4_4_ = pppppppuVar13;
        FUN_01677520(DAT_01eaf005,"  %s(%s) is:%d->%d, signaling",puVar5,ppppppuStack_20);
        uStack_8._0_1_ = 0xc;
        if (0xf < uStack_104) {
          uStack_12c._4_4_ = (uint *******)(uStack_104 + 1);
          pppppppuVar13 = (uint *******)appppppuStack_118[0];
          if (0xfff < uStack_12c._4_4_) {
            pppppppuVar13 = (uint *******)appppppuStack_118[0][-1];
            uStack_12c._4_4_ = (uint *******)(uStack_104 + 0x24);
            if (0x1f < (uint)((int)appppppuStack_118[0] + (-4 - (int)pppppppuVar13)))
            goto LAB_006dd320;
          }
          uStack_12c._0_4_ = (char *)pppppppuVar13;
          FUN_01674ea0();
        }
        ppppppuVar12 = (uint ******)ppppppuStack_18[0x10];
      }
      ppppppuStack_18[0x10] =
           (uint *****)
           (((uint)ppppppuVar12 >> 2 ^ (uint)ppppppuVar12) & 0x1000000 ^ (uint)ppppppuVar12);
      uStack_12c._4_4_ = (uint *******)0x6dd1dc;
      (*(code *)(**pppppppuVar10)[0x18])();
    }
    pppppppuVar6 = (uint *******)ppppppuStack_24;
    puVar11 = puStack_1c;
  }
LAB_006dd1ed:
  uStack_8._0_1_ = 0x10;
  uStack_12c = uStack_70;
  FUN_0152dda0(pppppppuVar6,puVar11);
  uStack_12c._4_4_ = (uint *******)0x6dd209;
  FUN_005e6280();
  uStack_8._0_1_ = 1;
  if ((uint *******)ppppppuStack_14 != (uint *******)0x0) {
    uStack_12c._4_4_ = (uint *******)(((int)ppppppuStack_4c - (int)ppppppuStack_14 >> 2) * 4);
    pppppppuVar13 = (uint *******)ppppppuStack_14;
    if (0xfff < uStack_12c._4_4_) {
      pppppppuVar13 = (uint *******)ppppppuStack_14[-1];
      uStack_12c._4_4_ = (uint *******)((int)uStack_12c._4_4_ + 0x23);
      if (0x1f < (uint)((int)ppppppuStack_14 + (-4 - (int)pppppppuVar13))) {
LAB_006dd320:
                    /* WARNING: Subroutine does not return */
        uStack_12c._4_4_ = (uint *******)&UNK_006dd325;
        FUN_017167a3();
      }
    }
    uStack_12c._0_4_ = (char *)pppppppuVar13;
    FUN_01674ea0();
  }
  uStack_8 = 0x11;
  uStack_12c = uStack_80;
  FUN_0152dda0(ppppppuStack_88,ppppppuStack_84);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9368 ; VA 0x006dd330 ; FUN_006dd330 */

uint * __thiscall FUN_006dd330(byte *param_1,uint *param_2,undefined4 param_3,uint param_4)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  uint *puVar5;
  uint *puStack_34;
  int *piStack_30;
  uint *puStack_2c;
  uint uStack_28;
  int iStack_24;
  uint *puStack_20;
  uint *puStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8f98;
  pvStack_10 = ExceptionList;
  if (param_2 != (uint *)0x0) {
    puVar5 = param_2 + 3;
    ExceptionList = &pvStack_10;
    puStack_1c = puVar5;
    (**(code **)(*(int *)param_2[4] + 0x40))(&puStack_34);
    uStack_8 = 0;
    if (puStack_34 != (uint *)0x0) {
      puStack_2c = (uint *)puStack_34[1];
      puStack_34 = (uint *)*puStack_34;
      puStack_20 = puStack_34;
      if (puStack_34 != puStack_2c) {
        do {
          uStack_18 = *puStack_34;
          puStack_20 = puStack_34;
          FUN_00606ea0(&iStack_24,(uStack_18 >> 3) + uStack_18,&uStack_18,
                       -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) &
                       (uint)(param_1 + *param_1 + 1 + 1));
          iVar3 = iStack_24;
          if (iStack_24 != 0) {
            iVar1 = iStack_24 + 0xc;
            if (((DAT_01d5b840 != '\0') && (*(char *)(iStack_24 + 0x3f) != '\0')) &&
               (*(char *)((int)puStack_1c + 0x33) == '\0')) {
              FUN_006d7ab0(iVar1);
            }
            uStack_18 = *(uint *)(iVar3 + 0x40);
            if (((param_4 < (uint)((int)(*(int *)(iVar3 + 0x44) - uStack_18) / 0xc)) &&
                (iStack_14 = param_4 * 0xc, *(char *)(iStack_14 + 8 + uStack_18) != '\0')) &&
               ((uStack_28 = puStack_1c[0xd],
                (uint)((int)(puStack_1c[0xe] - uStack_28) / 0xc) <= param_4 ||
                (*(char *)(uStack_28 + 8 + iStack_14) == '\0')))) {
              FUN_006da720(param_3,*(undefined4 *)(iVar3 + 0x10),iVar1);
              puVar4 = (undefined4 *)(iStack_14 + uStack_18);
              if (DAT_01d5b850 == '\0') {
                *(undefined *)(puVar4 + 2) = 0;
                *(int *)(iVar3 + 0x38) = *(int *)(iVar3 + 0x38) + -1;
                if (DAT_01d5b7f8 != '\0') goto LAB_006dd4b3;
                *(undefined2 *)((int)puVar4 + 9) = 0;
                *puVar4 = 0;
              }
              else {
                FUN_006da6e0(puVar4);
              }
              if (DAT_01d5b7f8 == '\0') {
                FUN_006d6e00(iVar1,param_4);
              }
            }
LAB_006dd4b3:
            FUN_006dd330(iVar3,param_3,param_4);
          }
          puStack_34 = puStack_20 + 2;
          puVar5 = puStack_1c;
          puStack_20 = puStack_34;
        } while (puStack_34 != puStack_2c);
      }
    }
    if (((DAT_01d5b840 == '\0') || (*(char *)((int)puVar5 + 0x33) == '\0')) &&
       ((int)puVar5[0xb] < 1)) {
      FUN_006dc8d0();
      FUN_006d6570(param_2[2]);
      if ((DAT_01d5b820 != '\0') && (*(int *)(param_1 + 0x1c) != 0)) {
        FUN_006cc9d0(puVar5);
      }
      puStack_34 = (uint *)FUN_006d8250(&param_4,param_2);
    }
    param_2 = puStack_34;
    if (piStack_30 != (int *)0x0) {
      LOCK();
      piVar2 = piStack_30 + 1;
      iVar3 = *piVar2;
      param_2 = (uint *)*piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        param_2 = (uint *)(**(code **)*piStack_30)();
        LOCK();
        piVar2 = piStack_30 + 2;
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          param_2 = (uint *)(**(code **)(*piStack_30 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9369 ; VA 0x006dd570 ; FUN_006dd570 */

void __thiscall FUN_006dd570(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    *puVar1 = *param_2;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 4;
    return;
  }
  FUN_00595d30(puVar1,param_2);
  return;
}



/* FUNCTION 9370 ; VA 0x006dd5a0 ; FUN_006dd5a0 */

void __fastcall FUN_006dd5a0(byte *param_1)

{
  byte *pbVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  uint *puVar5;
  uint uVar6;
  int iVar7;
  int *piVar8;
  int iVar9;
  undefined8 uVar10;
  int aiStack_70 [5];
  uint uStack_5c;
  uint uStack_58;
  int iStack_54;
  undefined8 uStack_50;
  undefined **ppuStack_48;
  undefined *puStack_44;
  uint uStack_40;
  int *piStack_3c;
  int iStack_38;
  uint uStack_34;
  uint uStack_30;
  int iStack_2c;
  uint uStack_28;
  int iStack_24;
  int iStack_20;
  byte *pbStack_1c;
  uint *puStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8ff0;
  pvStack_10 = ExceptionList;
  iStack_38 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  pbStack_1c = param_1;
  if ((*(int *)(iStack_38 + 0x34) < DAT_01eaf0c8) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eaf0c8), DAT_01eaf0c8 == -1)) {
    uStack_8 = 0;
    uVar10 = FUN_0152dab0(&DAT_018c5904,"RaiseCompleteness",0xffffffff);
    DAT_01eaf0c4 = (int)((ulonglong)uVar10 >> 0x20);
    DAT_01eaf0c0 = (uint)uVar10;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eaf0c8);
  }
  uStack_28 = DAT_01eaf0c0;
  uStack_58 = DAT_01eaf0c0;
  iStack_24 = DAT_01eaf0c4;
  iStack_54 = DAT_01eaf0c4;
  uStack_50 = FUN_0152d930(DAT_01eaf0c0,DAT_01eaf0c4);
  puStack_18 = *(uint **)(param_1 + 0x240);
  iVar7 = 0;
  puVar5 = *(uint **)(param_1 + 0x244);
  uStack_8 = 1;
  iStack_20 = 0;
  puStack_14 = puVar5;
  if (puStack_18 != puVar5) {
    do {
      uVar6 = puStack_18[1];
      uStack_40 = 0;
      piStack_3c = (int *)0x0;
      if (uVar6 != 0) {
        piVar8 = (int *)(uVar6 + 4);
        iVar7 = *(int *)(uVar6 + 4);
        while (puVar5 = puStack_14, iVar7 != 0) {
          LOCK();
          iVar9 = *piVar8;
          if (iVar7 == iVar9) {
            *piVar8 = iVar7 + 1;
            iVar9 = iVar7;
          }
          UNLOCK();
          if (iVar9 == iVar7) {
            uStack_40 = *puStack_18;
            piStack_3c = (int *)puStack_18[1];
            break;
          }
          iVar7 = *piVar8;
        }
      }
      piVar8 = piStack_3c;
      uVar6 = uStack_40;
      uStack_8._0_1_ = 2;
      if (uStack_40 == 0) {
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        param_1 = pbStack_1c;
        iVar7 = iStack_20;
        if (piStack_3c != (int *)0x0) {
          LOCK();
          iVar9 = piStack_3c[1] + -1;
          piStack_3c[1] = iVar9;
          UNLOCK();
joined_r0x006dd7c1:
          iStack_20 = iVar7;
          pbStack_1c = param_1;
          if (iVar9 == 0) {
            (**(code **)*piVar8)();
            LOCK();
            iVar9 = piVar8[2] + -1;
            piVar8[2] = iVar9;
            UNLOCK();
            puVar5 = puStack_14;
            param_1 = pbStack_1c;
            iVar7 = iStack_20;
            if (iVar9 == 0) {
              (**(code **)(*piVar8 + 4))();
              puVar5 = puStack_14;
              param_1 = pbStack_1c;
              iVar7 = iStack_20;
            }
          }
        }
      }
      else {
        *(uint *)(uStack_40 + 0x40) = *(uint *)(uStack_40 + 0x40) & 0xf7ffffff;
        uVar2 = *(uint *)(uStack_40 + 0x40);
        uStack_34 = *(uint *)(uStack_40 + 0x38);
        uStack_30 = uVar2 & 0xffffff;
        if (uStack_30 != uStack_34) {
          *(uint *)(uStack_40 + 0x40) = (uVar2 ^ uStack_34) & 0xffffff ^ uVar2;
          uStack_28 = uStack_40;
          FUN_00606ea0(&iStack_2c,(uStack_40 >> 3) + uStack_40,&uStack_28,
                       -(uint)(pbStack_1c + *pbStack_1c + 1 != (byte *)0x0) &
                       (uint)(pbStack_1c + *pbStack_1c + 1 + 1));
          iVar7 = iStack_2c;
          if (iStack_2c != 0) {
            if (DAT_01eaf004 != '\0') {
              iStack_24 = *(undefined4 *)(uVar6 + 0x28);
              if (0xf < *(uint *)(iStack_24 + 0x14)) {
                iStack_24 = *(int *)iStack_24;
              }
              puVar4 = (undefined4 *)FUN_009c9510(aiStack_70);
              uStack_8._0_1_ = 3;
              if (0xf < (uint)puVar4[5]) {
                puVar4 = (undefined4 *)*puVar4;
              }
              FUN_01677520(DAT_01eaf004,"%s(%s) raising expected change to %d from %d",puVar4,
                           iStack_24,uStack_34,uStack_30);
              uStack_8._0_1_ = 2;
              if (0xf < uStack_5c) {
                uVar6 = uStack_5c + 1;
                iVar9 = aiStack_70[0];
                if (0xfff < uVar6) {
                  iVar9 = *(int *)(aiStack_70[0] + -4);
                  uVar6 = uStack_5c + 0x24;
                  if (0x1f < (aiStack_70[0] - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
                    FUN_017167a3();
                  }
                }
                FUN_01674ea0(iVar9,uVar6);
              }
            }
            ppuStack_48 = RBX::Instance::PropertyChangedSignalData::vftable;
            puStack_44 = &DAT_0211a44c;
            uStack_34 = iVar7 + 0xc;
            uStack_8._0_1_ = 4;
            uVar6 = FUN_01675290(DAT_01eadc98);
            param_1 = pbStack_1c;
            uStack_8._0_1_ = 5;
            if (DAT_01d5b810 != '\0') {
              *(int *)(pbStack_1c + 0xa0) = *(int *)(pbStack_1c + 0xa0) + 1;
            }
            uStack_30 = uVar6;
            FUN_006dc430(uStack_34,&ppuStack_48);
            if (DAT_01d5b810 != '\0') {
              pbVar1 = param_1 + 0xa0;
              *(int *)pbVar1 = *(int *)pbVar1 + -1;
              if (*(int *)pbVar1 == 0) {
                *(undefined4 *)(param_1 + 0x8c) = *(undefined4 *)(param_1 + 0x88);
                param_1[0x94] = 0;
                param_1[0x95] = 0;
                param_1[0x96] = 0;
                param_1[0x97] = 0;
              }
            }
            uStack_8._0_1_ = 6;
            FUN_01675290(uVar6);
            iVar7 = iStack_20 + 1;
            ppuStack_48 = RBX::Instance::ICombinedSignalData::vftable;
            uStack_8 = CONCAT31(uStack_8._1_3_,1);
            puVar5 = puStack_14;
            iStack_20 = iVar7;
            if (piVar8 != (int *)0x0) {
              LOCK();
              iVar9 = piVar8[1] + -1;
              piVar8[1] = iVar9;
              UNLOCK();
              if (iVar9 == 0) {
                (**(code **)*piVar8)();
                LOCK();
                iVar9 = piVar8[2] + -1;
                piVar8[2] = iVar9;
                UNLOCK();
                puVar5 = puStack_14;
                if (iVar9 == 0) {
                  (**(code **)(*piVar8 + 4))();
                  puVar5 = puStack_14;
                }
              }
            }
            goto LAB_006dd6bc;
          }
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        puVar5 = puStack_14;
        param_1 = pbStack_1c;
        iVar7 = iStack_20;
        if (piVar8 != (int *)0x0) {
          LOCK();
          iVar9 = piVar8[1] + -1;
          piVar8[1] = iVar9;
          UNLOCK();
          goto joined_r0x006dd7c1;
        }
      }
LAB_006dd6bc:
      puStack_18 = puStack_18 + 2;
    } while (puStack_18 != puVar5);
    iStack_24 = iStack_54;
    uStack_28 = uStack_58;
  }
  if (*(int *)(iStack_38 + 0x34) < DAT_01eaf0d8) {
    FUN_016f3809(&DAT_01eaf0d8);
    if (DAT_01eaf0d8 == -1) {
      uStack_8._0_1_ = 7;
      uVar10 = FUN_0152da50(&DAT_018c5904);
      DAT_01eaf0d4 = (undefined4)((ulonglong)uVar10 >> 0x20);
      DAT_01eaf0d0 = (undefined4)uVar10;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eaf0d8);
    }
  }
  FUN_0152d760(DAT_01eaf0d0,DAT_01eaf0d4,"Completeness expected raised %d/%d",iVar7,
               *(int *)(param_1 + 0x244) - *(int *)(param_1 + 0x240) >> 3);
  iVar7 = *(int *)(param_1 + 0x244);
  iVar9 = *(int *)(param_1 + 0x240);
  if (iVar9 != iVar7) {
    do {
      piVar8 = *(int **)(iVar9 + 4);
      if (piVar8 != (int *)0x0) {
        LOCK();
        iVar3 = piVar8[2] + -1;
        piVar8[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
      iVar9 = iVar9 + 8;
    } while (iVar9 != iVar7);
    iVar9 = *(int *)(param_1 + 0x240);
  }
  *(int *)(param_1 + 0x244) = iVar9;
  uStack_8 = 8;
  FUN_0152dda0(uStack_28,iStack_24,uStack_50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9371 ; VA 0x006dda40 ; FUN_006dda40 */

void __thiscall FUN_006dda40(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  
  puVar2 = (undefined4 *)*param_1;
  puVar7 = (undefined4 *)FUN_01674f30(param_1[2] * 0x1c);
  *param_1 = puVar7;
  if ((int)param_1[2] < param_2) {
    param_2 = param_1[2];
  }
  puVar1 = puVar7 + param_2 * 7;
  puVar6 = puVar2;
  for (; puVar7 < puVar1; puVar7 = puVar7 + 7) {
    uVar3 = puVar6[1];
    uVar4 = puVar6[2];
    uVar5 = puVar6[3];
    *puVar7 = *puVar6;
    puVar7[1] = uVar3;
    puVar7[2] = uVar4;
    puVar7[3] = uVar5;
    *(undefined8 *)(puVar7 + 4) = *(undefined8 *)(puVar6 + 4);
    puVar7[6] = puVar6[6];
    puVar6 = puVar6 + 7;
  }
  FUN_01674ea0(puVar2);
  return;
}



/* FUNCTION 9372 ; VA 0x006ddab0 ; FUN_006ddab0 */

void FUN_006ddab0(undefined8 *param_1,float *param_2)

{
  byte bVar1;
  float10 fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  
  fVar2 = (float10)FUN_01725280((double)param_2[2]);
  fVar3 = (float)fVar2;
  if (fVar3 < 0.0) {
    fVar3 = fVar3 - DAT_018ce2f4;
  }
  else {
    fVar3 = fVar3 + DAT_018ce2f4;
  }
  fVar2 = (float10)FUN_01725280((double)param_2[1]);
  fVar4 = (float)fVar2;
  if (fVar4 < 0.0) {
    fVar4 = fVar4 - DAT_018ce2f4;
  }
  else {
    fVar4 = fVar4 + DAT_018ce2f4;
  }
  fVar2 = (float10)FUN_01725280((double)*param_2);
  fVar5 = (float)fVar2;
  if (fVar5 < 0.0) {
    fVar5 = fVar5 - DAT_018ce2f4;
  }
  else {
    fVar5 = fVar5 + DAT_018ce2f4;
  }
  bVar1 = (byte)DAT_01d5b7cc;
  *param_1 = CONCAT44((int)fVar4 >> ((byte)DAT_01d5b7c8 & 0x1f),
                      (int)fVar5 >> ((byte)DAT_01d5b7c4 & 0x1f));
  *(int *)(param_1 + 1) = (int)fVar3 >> (bVar1 & 0x1f);
  return;
}



/* FUNCTION 9373 ; VA 0x006ddbd0 ; FUN_006ddbd0 */

void __thiscall FUN_006ddbd0(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = *(int **)(param_1 + 0x1c0);
  if (*(int **)(param_1 + 0x1c4) != piVar1) {
    *piVar1 = param_2;
    *(int *)(param_1 + 0x1c0) = *(int *)(param_1 + 0x1c0) + 4;
    *(int *)(param_2 + 0x18e8) = (*(int *)(param_1 + 0x1c0) - *(int *)(param_1 + 0x1bc) >> 2) + -1;
    return;
  }
  FUN_006030d0(piVar1,&param_2);
  *(int *)(param_2 + 0x18e8) = (*(int *)(param_1 + 0x1c0) - *(int *)(param_1 + 0x1bc) >> 2) + -1;
  return;
}



/* FUNCTION 9374 ; VA 0x006ddc30 ; FUN_006ddc30 */

void __fastcall FUN_006ddc30(int *param_1)

{
  int iVar1;
  uint uVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int *piStack_1c;
  int iStack_18;
  uint uStack_14;
  uint uStack_10;
  uint *puStack_c;
  undefined uStack_5;
  
  if (*param_1 == param_1[1]) {
    iVar5 = 0x10;
  }
  else {
    iVar5 = (param_1[1] - *param_1 >> 3) * 2;
  }
  iStack_18 = param_1[4];
  uStack_14 = 0;
  piStack_1c = param_1;
  FUN_0060e9d0(iVar5,&iStack_18,&uStack_5);
  uStack_14 = param_1[4];
  iVar5 = *param_1;
  uStack_10 = 0;
  if (param_1[1] - iVar5 >> 3 != 0) {
    do {
      uVar4 = *(uint *)(iVar5 + uStack_10 * 8);
      puStack_c = (uint *)(iVar5 + uStack_10 * 8);
      if (uVar4 != param_1[4]) {
        uVar2 = (uVar4 >> 3) + uVar4;
        uVar7 = (iStack_30 - iStack_34 >> 3) - 1;
        uVar6 = 0;
        do {
          uVar2 = uVar2 & uVar7;
          puVar3 = (uint *)(iStack_34 + uVar2 * 8);
          if (*puVar3 == uStack_14) {
            *puVar3 = uVar4;
            uVar4 = *puStack_c;
            goto LAB_006ddcdb;
          }
          if (*puVar3 == uVar4) goto LAB_006ddcdb;
          uVar2 = uVar2 + 1 + uVar6;
          uVar6 = uVar6 + 1;
        } while (uVar6 <= uVar7);
        puVar3 = (uint *)0x0;
LAB_006ddcdb:
        *puVar3 = uVar4;
        puVar3[1] = puStack_c[1];
        iVar5 = *piStack_1c;
        param_1 = piStack_1c;
      }
      uStack_10 = uStack_10 + 1;
    } while (uStack_10 < (uint)(param_1[1] - iVar5 >> 3));
  }
  if (param_1 != &iStack_34) {
    *param_1 = iStack_34;
    param_1[1] = iStack_30;
    iVar1 = param_1[2];
    param_1[2] = iStack_2c;
    iStack_2c = iVar1;
    iStack_34 = iVar5;
  }
  if (iStack_34 != 0) {
    uVar4 = iStack_2c - iStack_34 & 0xfffffff8;
    iVar5 = iStack_34;
    if (0xfff < uVar4) {
      iVar5 = *(int *)(iStack_34 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iStack_34 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar4);
  }
  return;
}



/* FUNCTION 9375 ; VA 0x006ddd60 ; FUN_006ddd60 */

void FUN_006ddd60(undefined4 param_1,undefined4 param_2)

{
  ReleaseSemaphore(param_1,param_2,0);
  return;
}



/* FUNCTION 9376 ; VA 0x006ddd80 ; FUN_006ddd80 */

void __thiscall FUN_006ddd80(int param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  
  uVar2 = param_2 & 0x7f000000;
  if (uVar2 != 0) {
    ReleaseSemaphore(*(undefined4 *)(param_1 + 8),1,0);
  }
  uVar1 = param_2 >> 0xb & 0x7ff;
  if ((uVar1 != 0) || (uVar2 != 0)) {
    ReleaseSemaphore(*(undefined4 *)(param_1 + 4),(uVar2 != 0) + uVar1,0);
  }
  return;
}



/* FUNCTION 9377 ; VA 0x006ddde0 ; FUN_006ddde0 */

void __fastcall FUN_006ddde0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0xa4) != 0) {
    if (*(int *)(param_1 + 0xa8) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_1 + 0xa8) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_00628870(*(undefined4 *)(param_1 + 0xa4),*(undefined4 *)(param_1 + 0xa8));
    *(undefined4 *)(param_1 + 0xa4) = 0;
    piVar1 = *(int **)(param_1 + 0xa8);
    *(undefined4 *)(param_1 + 0xa8) = 0;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar3 = piVar1[1] + -1;
      piVar1[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar3 = piVar1[2] + -1;
        piVar1[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
  }
  if (*(int *)(param_1 + 0xac) != 0) {
    if (*(int *)(param_1 + 0xb0) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_1 + 0xb0) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_00628870(*(undefined4 *)(param_1 + 0xac),*(undefined4 *)(param_1 + 0xb0));
    *(undefined4 *)(param_1 + 0xac) = 0;
    piVar1 = *(int **)(param_1 + 0xb0);
    *(undefined4 *)(param_1 + 0xb0) = 0;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar3 = piVar1[1] + -1;
      piVar1[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar3 = piVar1[2] + -1;
        piVar1[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
  }
  if ((*(int *)(param_1 + 0xb4) != 0) && (DAT_01d5b838 != '\0')) {
    if (*(int *)(param_1 + 0xb8) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_1 + 0xb8) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_00628870(*(undefined4 *)(param_1 + 0xb4),*(undefined4 *)(param_1 + 0xb8));
    *(undefined4 *)(param_1 + 0xb4) = 0;
    piVar1 = *(int **)(param_1 + 0xb8);
    *(undefined4 *)(param_1 + 0xb8) = 0;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar3 = piVar1[1] + -1;
      piVar1[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar3 = piVar1[2] + -1;
        piVar1[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
  }
  if (*(int *)(param_1 + 0xc0) != 0) {
    if (*(int *)(param_1 + 0xc4) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_1 + 0xc4) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_00628870(*(undefined4 *)(param_1 + 0xc0),*(undefined4 *)(param_1 + 0xc4));
    *(undefined4 *)(param_1 + 0xc0) = 0;
    piVar1 = *(int **)(param_1 + 0xc4);
    *(undefined4 *)(param_1 + 0xc4) = 0;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar3 = piVar1[1] + -1;
      piVar1[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        piVar2 = piVar1 + 2;
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
  }
  return;
}



/* FUNCTION 9378 ; VA 0x006de000 ; FUN_006de000 */

void __thiscall FUN_006de000(int *param_1,int param_2,char param_3)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  float fVar4;
  
  iVar3 = param_1[1];
  if (iVar3 == param_2) {
    return;
  }
  iVar2 = param_1[2];
  param_1[1] = param_2;
  if (iVar2 < param_2) {
    if (iVar2 == 0) {
      param_1[2] = param_2;
      param_2 = iVar3;
    }
    else {
      if (9 < param_2) {
        fVar4 = DAT_018df57c;
        if ((iVar2 * 0x1c < 0x61a81) && (fVar4 = DAT_018df580, 64000 < iVar2 * 0x1c)) {
          fVar4 = DAT_018daf58;
        }
        iVar2 = ((int)((float)iVar2 * fVar4) - iVar2) + param_2;
        param_1[2] = iVar2;
        param_2 = iVar3;
        if (9 < iVar2) goto LAB_006de0ad;
      }
      param_1[2] = 10;
      param_2 = iVar3;
    }
  }
  else {
    if (((iVar2 / 3 < param_2) || (param_3 == '\0')) || (param_2 < 0xb)) goto LAB_006de0b4;
    if (iVar3 <= param_2) {
      param_2 = iVar3;
    }
  }
LAB_006de0ad:
  FUN_006dda40(param_2);
LAB_006de0b4:
  if (iVar3 < param_1[1]) {
    iVar2 = iVar3 * 0x1c;
    do {
      iVar3 = iVar3 + 1;
      puVar1 = (undefined4 *)(*param_1 + iVar2);
      iVar2 = iVar2 + 0x1c;
      *puVar1 = 0;
      puVar1[1] = 0;
      puVar1[2] = 0;
      puVar1[3] = 0;
      puVar1[4] = 0;
      puVar1[5] = 0;
      puVar1[6] = 0;
    } while (iVar3 < param_1[1]);
  }
  return;
}



/* FUNCTION 9379 ; VA 0x006de110 ; FUN_006de110 */

void __fastcall FUN_006de110(int param_1)

{
  *(undefined *)(param_1 + 0x26c) = 1;
  return;
}



/* FUNCTION 9380 ; VA 0x006de120 ; FUN_006de120 */

uint FUN_006de120(int param_1,char param_2,char param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  
  iVar1 = *(int *)(param_1 + 0xc);
  uVar4 = *(uint *)(iVar1 + 0x1d4);
  uVar2 = uVar4 >> 4;
  if (((uVar2 & 1) == 0) && ((uVar4 = uVar4 & 3, uVar4 == 0 || (uVar4 == 2)))) {
LAB_006de193:
    return uVar2 & 0xffffff00;
  }
  if (param_3 != '\0') {
    iVar3 = FUN_00aff8c0();
    uVar2 = (uint)*(ushort *)(iVar3 + 0x1da);
    if (((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <= uVar2) &&
       (param_2 != '\0')) {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar3 = FUN_00af0010();
      uVar2 = (uint)*(ushort *)(iVar3 + 0x1da);
      if (uVar2 < (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))
      goto LAB_006de193;
    }
  }
  return CONCAT31((int3)(uVar2 >> 8),1);
}



/* FUNCTION 9381 ; VA 0x006de1a0 ; FUN_006de1a0 */

code * __thiscall FUN_006de1a0(int param_1,code *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined4 uVar5;
  code *pcVar6;
  code *pcStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  code *pcStack_1c;
  code *pcStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017a9091;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0xa4) == 0) {
    ExceptionList = &pvStack_10;
    pcStack_1c = (code *)FUN_01674e20(0x150);
    uStack_8._0_1_ = 1;
    if (pcStack_1c == (code *)0x0) {
      uVar5 = 0;
    }
    else {
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      uVar5 = FUN_006d12a0(param_2,param_3,param_1);
    }
    uStack_8 = (uint)uStack_8._1_3_ << 8;
    pcStack_28 = (code *)0x0;
    piStack_24 = (int *)0x0;
    FUN_006cf780(uVar5,param_3);
    *(code **)(param_1 + 0xa4) = pcStack_28;
    piVar2 = *(int **)(param_1 + 0xa8);
    *(int **)(param_1 + 0xa8) = piStack_24;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (*(int *)(param_1 + 0xa8) != 0) {
      LOCK();
      piVar2 = (int *)(*(int *)(param_1 + 0xa8) + 4);
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    FUN_0151d950(*(undefined4 *)(param_1 + 0xa4),*(undefined4 *)(param_1 + 0xa8));
  }
  if ((*(int *)(param_1 + 0xac) == 0) && (*(int *)(param_2 + 0x4a0) == 2)) {
    pcStack_1c = (code *)FUN_01674e20(0x138);
    uStack_8._0_1_ = 2;
    if (pcStack_1c == (code *)0x0) {
      uVar5 = 0;
    }
    else {
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      uVar5 = FUN_00724370(param_2,param_3,param_1);
    }
    uStack_8 = (uint)uStack_8._1_3_ << 8;
    pcStack_28 = (code *)0x0;
    piStack_24 = (int *)0x0;
    FUN_006cf5a0(uVar5,param_3);
    *(code **)(param_1 + 0xac) = pcStack_28;
    piVar2 = *(int **)(param_1 + 0xb0);
    *(int **)(param_1 + 0xb0) = piStack_24;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (*(int *)(param_1 + 0xb0) != 0) {
      LOCK();
      piVar2 = (int *)(*(int *)(param_1 + 0xb0) + 4);
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    FUN_0151d950(*(undefined4 *)(param_1 + 0xac),*(undefined4 *)(param_1 + 0xb0));
  }
  if (DAT_01d5b838 != '\0') {
    pcStack_14 = (code *)FUN_01674e20(0x130);
    if (pcStack_14 == (code *)0x0) {
      pcVar6 = (code *)0x0;
    }
    else {
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      pcStack_28 = param_2;
      piStack_24 = param_3;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      FUN_00a360a0("receive physics Mega Job",1,0,param_2,param_3,3);
      *(undefined ***)pcStack_14 = RBX::Network::NetworkPhysicsParallelReceiveJob::vftable;
      *(int *)(pcStack_14 + 0x128) = param_1;
      pcVar6 = pcStack_14;
      if (param_3 != (int *)0x0) {
        LOCK();
        iVar3 = param_3[1] + -1;
        param_3[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*param_3)();
          LOCK();
          iVar3 = param_3[2] + -1;
          param_3[2] = iVar3;
          UNLOCK();
          pcVar6 = pcStack_14;
          if (iVar3 == 0) {
            (**(code **)(*param_3 + 4))();
            pcVar6 = pcStack_14;
          }
        }
      }
    }
    uStack_8 = uStack_8 & 0xffffff00;
    pcStack_28 = (code *)0x0;
    piStack_24 = (int *)0x0;
    FUN_006cf690(pcVar6,param_3);
    *(code **)(param_1 + 0xb4) = pcStack_28;
    piVar2 = *(int **)(param_1 + 0xb8);
    *(int **)(param_1 + 0xb8) = piStack_24;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (*(int *)(param_1 + 0xb8) != 0) {
      LOCK();
      piVar2 = (int *)(*(int *)(param_1 + 0xb8) + 4);
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    FUN_0151d950(*(undefined4 *)(param_1 + 0xb4),*(undefined4 *)(param_1 + 0xb8));
  }
  if (*(int *)(param_1 + 0xc0) == 0) {
    pcStack_14 = (code *)FUN_01674e20(0x138);
    if (pcStack_14 == (code *)0x0) {
      pcVar6 = (code *)0x0;
    }
    else {
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      pcStack_1c = param_2;
      pcStack_28 = param_2;
      piStack_24 = param_3;
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      FUN_00a360a0("Allocate Bandwidth and Run Senders",1,0,param_2,param_3,7);
      *(undefined ***)pcStack_14 = RBX::Network::NetworkSenderScheduleJob::vftable;
      *(undefined4 *)(pcStack_14 + 0x128) = 0;
      *(undefined4 *)(pcStack_14 + 300) = 0;
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[2] = param_3[2] + 1;
        UNLOCK();
      }
      *(code **)(pcStack_14 + 0x128) = pcStack_1c;
      *(int **)(pcStack_14 + 300) = param_3;
      *(int *)(pcStack_14 + 0x130) = param_1;
      pcVar6 = pcStack_14;
      if (param_3 != (int *)0x0) {
        LOCK();
        iVar3 = param_3[1] + -1;
        param_3[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*param_3)();
          LOCK();
          iVar3 = param_3[2] + -1;
          param_3[2] = iVar3;
          UNLOCK();
          pcVar6 = pcStack_14;
          if (iVar3 == 0) {
            (**(code **)(*param_3 + 4))();
            pcVar6 = pcStack_14;
          }
        }
      }
    }
    uStack_8 = uStack_8 & 0xffffff00;
    pcStack_28 = (code *)0x0;
    piStack_24 = (int *)0x0;
    FUN_006cf870(pcVar6,param_3);
    *(code **)(param_1 + 0xc0) = pcStack_28;
    piVar2 = *(int **)(param_1 + 0xc4);
    *(int **)(param_1 + 0xc4) = piStack_24;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (*(int *)(param_1 + 0xc4) != 0) {
      LOCK();
      piVar2 = (int *)(*(int *)(param_1 + 0xc4) + 4);
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    FUN_0151d950(*(undefined4 *)(param_1 + 0xc0),*(undefined4 *)(param_1 + 0xc4));
  }
  if (DAT_01d5b868 != '\0') {
    pcStack_28 = FUN_006dc7a0;
    pcStack_14 = *(code **)(param_2 + 0x1b8);
    piStack_24 = (int *)param_1;
    pcStack_1c = (code *)FUN_006cfd60(&pcStack_18,&pcStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    cVar4 = FUN_01679300(pcStack_1c);
    if (cVar4 != '\0') {
      FUN_01679490();
      FUN_016791c0(pcStack_1c);
    }
    uStack_8 = uStack_8 & 0xffffff00;
    if (pcStack_18 != (code *)0x0) {
      pcVar6 = pcStack_18 + 4;
      LOCK();
      iVar3 = *(int *)pcVar6;
      *(int *)pcVar6 = *(int *)pcVar6 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        FUN_01674ea0(pcStack_18);
      }
    }
    pcStack_18 = pcStack_14 + 0x1f8;
    pcStack_28 = FUN_006dc840;
    piStack_24 = (int *)param_1;
    pcStack_1c = (code *)FUN_006cfd60(&pcStack_14,&pcStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    cVar4 = FUN_01679300(pcStack_1c);
    if (cVar4 != '\0') {
      FUN_01679490();
      FUN_016791c0(pcStack_1c);
    }
    if (pcStack_14 != (code *)0x0) {
      pcVar6 = pcStack_14 + 4;
      LOCK();
      iVar3 = *(int *)pcVar6;
      *(int *)pcVar6 = *(int *)pcVar6 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        FUN_01674ea0(pcStack_14);
      }
    }
    uStack_8._0_1_ = 9;
    uVar5 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 10;
    piStack_24 = (int *)uVar5;
    pcStack_1c = (code *)FUN_01674e20(0x20);
    if (pcStack_1c == (code *)0x0) {
      pcStack_1c = (code *)0x0;
    }
    else {
      *(undefined4 *)pcStack_1c = 0;
      *(undefined4 *)(pcStack_1c + 4) = 1;
      *(code **)(pcStack_1c + 8) = FUN_006d7a70;
      *(code **)(pcStack_1c + 0xc) = _guard_check_icall;
      *(undefined4 *)(pcStack_1c + 0x10) = 0;
      *(code **)(pcStack_1c + 0x14) = pcStack_18;
      *(code **)(pcStack_1c + 0x18) = FUN_006dc820;
      *(int *)(pcStack_1c + 0x1c) = param_1;
    }
    FUN_016797d0(pcStack_1c);
    pcStack_14 = pcStack_1c;
    if (pcStack_1c != (code *)0x0) {
      LOCK();
      *(int *)(pcStack_1c + 4) = *(int *)(pcStack_1c + 4) + 1;
      UNLOCK();
    }
    uStack_20 = 1;
    uStack_8._0_1_ = 0xb;
    FUN_01675290(uVar5);
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    cVar4 = FUN_01679300(&pcStack_14);
    if (cVar4 != '\0') {
      FUN_01679490();
      FUN_016791c0(&pcStack_14);
    }
    if (pcStack_14 != (code *)0x0) {
      pcVar6 = pcStack_14 + 4;
      LOCK();
      iVar3 = *(int *)pcVar6;
      *(int *)pcVar6 = *(int *)pcVar6 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        FUN_01674ea0(pcStack_14);
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *(code **)(param_1 + 0x60) = param_2;
  piVar2 = *(int **)(param_1 + 100);
  *(int **)(param_1 + 100) = param_3;
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    param_2 = (code *)*piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      param_2 = (code *)(**(code **)(*piVar2 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar3 = *piVar2;
    param_2 = (code *)*piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      param_2 = (code *)(**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        param_2 = (code *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9382 ; VA 0x006de8b0 ; FUN_006de8b0 */

undefined4 __fastcall FUN_006de8b0(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 uVar9;
  int iVar10;
  int iVar11;
  int *piVar12;
  int *piVar13;
  undefined8 uVar14;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a90c4;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffa4;
  if (DAT_01d5b828 != '\0') {
    iVar8 = *(int *)(param_1 + 0x128);
    piVar12 = (int *)(iVar8 + 0x228);
    if (0x1f < (uint)(*(int *)(iVar8 + 0x22c) - *piVar12)) {
      ExceptionList = &pvStack_10;
      FUN_006cfb50(*piVar12,*(int *)(iVar8 + 0x22c));
      uStack_8 = 0;
      FUN_006ce110(*piVar12,*(undefined4 *)(iVar8 + 0x22c),piVar12);
      *(int *)(iVar8 + 0x22c) = *piVar12;
      uStack_8 = 0xffffffff;
      FUN_0153a600(1);
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaf148
          ) && (FUN_016f3809(&DAT_01eaf148), DAT_01eaf148 == -1)) {
        uStack_8 = 1;
        uVar14 = FUN_0152dab0(&DAT_018c5904,"Deferred MotorAngles update",0xffffffff);
        DAT_01eaf144 = (undefined4)((ulonglong)uVar14 >> 0x20);
        DAT_01eaf140 = (undefined4)uVar14;
        uStack_8 = 0xffffffff;
        FUN_016f37bf(&DAT_01eaf148);
      }
      uVar7 = DAT_01eaf144;
      uVar6 = DAT_01eaf140;
      uVar14 = FUN_0152d930(DAT_01eaf140,DAT_01eaf144);
      uStack_8 = 2;
      FUN_008e9840(-(uint)(*(int *)(param_1 + 0x11c) != 0) & *(int *)(param_1 + 0x11c) + 0xcU);
      piStack_28 = *(int **)(*(int *)(param_1 + 0x128) + 0x1c0);
      for (piStack_20 = *(int **)(*(int *)(param_1 + 0x128) + 0x1bc); uStack_8._0_1_ = 3,
          piStack_20 != piStack_28; piStack_20 = piStack_20 + 1) {
        iStack_1c = *piStack_20;
        piVar13 = *(int **)(iStack_1c + 0x192c);
        piStack_18 = piVar13;
        for (piVar12 = *(int **)(iStack_1c + 0x1928); uStack_8._0_1_ = 3, piStack_24 = piVar12,
            piVar12 != piVar13; piVar12 = piVar12 + 4) {
          iVar8 = *piVar12;
          iVar11 = piVar12[2];
          iStack_38 = 0;
          iStack_34 = 0;
          iStack_3c = 0;
          if (iVar11 < 1) {
            iStack_3c = 0;
          }
          else {
            iStack_38 = iVar11;
            iStack_34 = iVar11;
            FUN_006dda40(0);
            iVar11 = 0;
            if (0 < iStack_38) {
              iVar10 = 0;
              do {
                iVar10 = iVar10 + 0x1c;
                iVar11 = iVar11 + 1;
                *(undefined4 *)(iStack_3c + -0x1c + iVar10) = 0;
                *(undefined4 *)(iStack_3c + -0x18 + iVar10) = 0;
                *(undefined4 *)(iStack_3c + -0x14 + iVar10) = 0;
                *(undefined4 *)(iStack_3c + -0x10 + iVar10) = 0;
                *(undefined4 *)(iStack_3c + -0xc + iVar10) = 0;
                *(undefined4 *)(iStack_3c + -8 + iVar10) = 0;
                *(undefined4 *)(iStack_3c + -4 + iVar10) = 0;
              } while (iVar11 < iStack_38);
            }
          }
          iVar11 = 0;
          if (0 < iStack_38) {
            iVar10 = 0;
            do {
              iVar3 = piVar12[1];
              iVar10 = iVar10 + 0x1c;
              iVar11 = iVar11 + 1;
              puVar1 = (undefined4 *)(iVar3 + -0x1c + iVar10);
              uVar9 = puVar1[1];
              uVar4 = puVar1[2];
              uVar5 = puVar1[3];
              puVar2 = (undefined4 *)(iStack_3c + -0x1c + iVar10);
              *puVar2 = *puVar1;
              puVar2[1] = uVar9;
              puVar2[2] = uVar4;
              puVar2[3] = uVar5;
              puVar1 = (undefined4 *)(iVar3 + -0xc + iVar10);
              uVar9 = puVar1[1];
              puVar2 = (undefined4 *)(iStack_3c + -0xc + iVar10);
              *puVar2 = *puVar1;
              puVar2[1] = uVar9;
              *(undefined4 *)(iStack_3c + -4 + iVar10) = *(undefined4 *)(iVar3 + -4 + iVar10);
            } while (iVar11 < iStack_38);
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          if (DAT_01d5b830 == '\0') {
            FUN_00c155c0();
            uVar9 = FUN_00c157b0();
            FUN_00ca1fa0(&iStack_3c,uVar9);
          }
          else {
            uStack_8 = CONCAT31(uStack_8._1_3_,5);
            if ((*(int *)(iVar8 + 0x1a8) != 0) && (iVar8 = FUN_00c155c0(), iVar8 != 0)) {
              FUN_00c155c0();
              uVar9 = FUN_00c157b0();
              FUN_00ca1fa0(&iStack_3c,uVar9);
            }
            uStack_8 = 0;
          }
          piVar13 = piStack_18;
          uStack_8._0_1_ = 7;
          FUN_01674ea0(iStack_3c);
          iStack_3c = 0;
          iStack_38 = 0;
          iStack_34 = 0;
        }
        iVar8 = *(int *)(iStack_1c + 0x192c);
        iVar11 = *(int *)(iStack_1c + 0x1928);
        if (iVar11 != iVar8) {
          do {
            uStack_8._0_1_ = 8;
            FUN_01674ea0(*(undefined4 *)(iVar11 + 4));
            *(undefined4 *)(iVar11 + 4) = 0;
            *(undefined4 *)(iVar11 + 8) = 0;
            *(undefined4 *)(iVar11 + 0xc) = 0;
            iVar11 = iVar11 + 0x10;
          } while (iVar11 != iVar8);
          iVar11 = *(int *)(iStack_1c + 0x1928);
        }
        *(int *)(iStack_1c + 0x192c) = iVar11;
      }
      FUN_008eb130();
      uStack_8 = 9;
      FUN_0152dda0(uVar6,uVar7,uVar14);
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 9383 ; VA 0x006deaed ; Catch@006deaed */

undefined * Catch_006deaed(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01ee420a != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x2c) + 4))();
    FUN_01677520(DAT_01ee420a,"Error while processing deferredMotorAngles (ignored): %s\n",uVar1);
  }
  return &DAT_006deb1c;
}



/* FUNCTION 9384 ; VA 0x006dec70 ; FUN_006dec70 */

undefined4 __thiscall FUN_006dec70(int param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  undefined8 uVar6;
  uint auStack_64 [2];
  int aiStack_5c [6];
  uint auStack_44 [2];
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  undefined8 uStack_2c;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a90fc;
  pvStack_10 = ExceptionList;
  if (DAT_01d5b818 == '\0') {
    ExceptionList = &pvStack_10;
    if (DAT_01d5b9c8 != '\0') {
      ExceptionList = &pvStack_10;
      FUN_006d5930(*(undefined4 *)(param_1 + 0x11c));
    }
    cStack_11 = '\0';
    iVar4 = *(int *)(*(int *)(param_1 + 0x130) + 0x1c0);
    if (iVar4 != *(int *)(*(int *)(param_1 + 0x130) + 0x1bc)) {
      do {
        iVar1 = *(int *)(iVar4 + -4);
        iVar4 = iVar4 + -4;
        if (*(char *)(iVar1 + 0x1db9) == '\0') {
          if ((*(int *)(iVar1 + 0x1de4) != 0) && (*(char *)(iVar1 + 0x37f8) != '\0')) {
            iStack_20 = param_2;
            iStack_24 = iVar1;
            cVar3 = FUN_00585a40(&iStack_24);
            if (cVar3 == '\0') {
              iStack_3c = iStack_24;
              iStack_38 = iStack_20;
              auStack_44[0] = 0x18df545;
            }
            else {
              auStack_44[0] = 0;
            }
            uStack_8 = 0;
            FUN_006c74e0(auStack_44,&iStack_24);
            uStack_8 = 1;
            if (((auStack_44[0] != 0) && ((auStack_44[0] & 1) == 0)) &&
               (*(code **)(auStack_44[0] & 0xfffffffe) != (code *)0x0)) {
              (**(code **)(auStack_44[0] & 0xfffffffe))(&iStack_3c,&iStack_3c,2);
            }
            cStack_11 = '\x01';
          }
          iStack_18 = param_2;
          iStack_1c = iVar1;
          cVar3 = FUN_00585a40(&iStack_1c);
          if (cVar3 == '\0') {
            iStack_3c = iStack_1c;
            iStack_38 = iStack_18;
            auStack_44[0] = 0x18df54d;
          }
          else {
            auStack_44[0] = 0;
          }
          uStack_8 = 2;
          FUN_006c74e0(auStack_44,&iStack_24);
          uStack_8 = 3;
          if (((auStack_44[0] != 0) && ((auStack_44[0] & 1) == 0)) &&
             (*(code **)(auStack_44[0] & 0xfffffffe) != (code *)0x0)) {
            (**(code **)(auStack_44[0] & 0xfffffffe))(&iStack_3c,&iStack_3c,2);
          }
          uStack_8 = 0xffffffff;
        }
      } while (iVar4 != *(int *)(*(int *)(param_1 + 0x130) + 0x1bc));
      if (cStack_11 != '\0') {
        LOCK();
        *(undefined *)(*(int *)(param_1 + 0x130) + 0x38) = 0;
        UNLOCK();
        FUN_0153a600(1);
        if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
             DAT_01eaf118) && (FUN_016f3809(&DAT_01eaf118), DAT_01eaf118 == -1)) {
          uStack_8 = 4;
          uVar6 = FUN_0152dab0(&DAT_018c5904,"Resolve Metadata",0xffffffff);
          DAT_01eaf114 = (int)((ulonglong)uVar6 >> 0x20);
          DAT_01eaf110 = (int)uVar6;
          uStack_8 = 0xffffffff;
          FUN_016f37bf(&DAT_01eaf118);
        }
        iStack_20 = DAT_01eaf110;
        iStack_34 = DAT_01eaf110;
        iStack_18 = DAT_01eaf114;
        iStack_30 = DAT_01eaf114;
        uStack_2c = FUN_0152d930(DAT_01eaf110,DAT_01eaf114);
        uStack_8 = 5;
        piVar2 = *(int **)(*(int *)(param_1 + 0x130) + 0x1c0);
        for (piVar5 = *(int **)(*(int *)(param_1 + 0x130) + 0x1bc); piVar5 != piVar2;
            piVar5 = piVar5 + 1) {
          if ((*(char *)(*piVar5 + 0x1db9) == '\0') && (*(int *)(*piVar5 + 0x1de4) != 0)) {
            cVar3 = FUN_006e83a0();
            if (cVar3 != '\0') {
              param_2 = *piVar5;
              cVar3 = FUN_00585a40(&param_2);
              if (cVar3 == '\0') {
                aiStack_5c[0] = param_2;
                auStack_64[0] = 0x18df555;
              }
              else {
                auStack_64[0] = 0;
              }
              uStack_8._0_1_ = 6;
              FUN_006c74e0(auStack_64,auStack_44);
              uStack_8._0_1_ = 7;
              if (auStack_64[0] != 0) {
                if (((auStack_64[0] & 1) == 0) &&
                   (*(code **)(auStack_64[0] & 0xfffffffe) != (code *)0x0)) {
                  (**(code **)(auStack_64[0] & 0xfffffffe))(aiStack_5c,aiStack_5c,2);
                }
                auStack_64[0] = 0;
              }
              uStack_8 = CONCAT31(uStack_8._1_3_,5);
            }
          }
        }
        FUN_0153a600(1);
        uStack_8 = 8;
        FUN_0152dda0(iStack_20,iStack_18,uStack_2c);
        uStack_8 = 0xffffffff;
      }
    }
    FUN_0153a600(1);
    FUN_006d6250();
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 9385 ; VA 0x006df000 ; FUN_006df000 */

undefined4 __thiscall FUN_006df000(int param_1,undefined4 param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  bool bVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined4 uVar7;
  char cVar8;
  int *piVar9;
  uint uVar10;
  int iVar11;
  int iVar12;
  uint uVar13;
  int *piVar14;
  undefined8 uVar15;
  uint auStack_a0 [2];
  int aiStack_98 [6];
  undefined4 uStack_80;
  int *piStack_7c;
  undefined8 uStack_78;
  undefined4 uStack_70;
  uint auStack_6c [2];
  int iStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined8 uStack_54;
  undefined auStack_4c [4];
  int *piStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  int iStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined8 uStack_28;
  int iStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar12 = _tls_index;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a91db;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_38 = param_1;
  if (DAT_01d5b880 != '\0') {
    iVar11 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
    ExceptionList = &pvStack_10;
    if ((*(int *)(iVar11 + 0x34) < DAT_01eaf158) &&
       (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eaf158), DAT_01eaf158 == -1)) {
      uStack_8 = 0;
      uVar15 = FUN_0152da50(&DAT_018c5904);
      DAT_01eaf154 = (undefined4)((ulonglong)uVar15 >> 0x20);
      DAT_01eaf150 = (undefined4)uVar15;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eaf158);
    }
    FUN_0152d760(DAT_01eaf150,DAT_01eaf154,"Connected Players : %d",
                 *(undefined4 *)(*(int *)(param_1 + 0x130) + 0x21c));
    if ((*(int *)(iVar11 + 0x34) < DAT_01eaf168) &&
       (FUN_016f3809(&DAT_01eaf168), DAT_01eaf168 == -1)) {
      uStack_8 = 1;
      uVar15 = FUN_0152da50(&DAT_018c5904);
      DAT_01eaf164 = (undefined4)((ulonglong)uVar15 >> 0x20);
      DAT_01eaf160 = (undefined4)uVar15;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eaf168);
    }
    iVar11 = *(int *)(param_1 + 0x130);
    FUN_0152d760(DAT_01eaf160,DAT_01eaf164,"Pending Players : %zu",
                 (*(int *)(iVar11 + 0x1c0) - *(int *)(iVar11 + 0x1bc) >> 2) -
                 *(int *)(iVar11 + 0x21c));
  }
  piVar9 = (int *)FUN_00587490(auStack_4c);
  uStack_8 = 2;
  FUN_008e9840(-(uint)(*piVar9 != 0) & *piVar9 + 0xcU);
  piVar9 = piStack_48;
  uStack_8._0_1_ = 4;
  if (piStack_48 != (int *)0x0) {
    LOCK();
    iVar11 = piStack_48[1] + -1;
    piStack_48[1] = iVar11;
    UNLOCK();
    if (iVar11 == 0) {
      (**(code **)*piStack_48)();
      LOCK();
      piVar14 = piVar9 + 2;
      iVar11 = *piVar14 + -1;
      *piVar14 = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)(*piVar9 + 4))();
      }
    }
  }
  iStack_14 = *(int *)((int)ThreadLocalStoragePointer + iVar12 * 4);
  if ((*(int *)(iStack_14 + 0x34) < DAT_01eaf178) &&
     (FUN_016f3809(&DAT_01eaf178), DAT_01eaf178 == -1)) {
    uStack_8._0_1_ = 5;
    uVar15 = FUN_0152dab0(&DAT_018c5904,"Update and allocate bandwidth",0xffffffff);
    DAT_01eaf174 = (int *)((ulonglong)uVar15 >> 0x20);
    DAT_01eaf170 = (undefined4)uVar15;
    uStack_8._0_1_ = 4;
    FUN_016f37bf(&DAT_01eaf178);
  }
  uStack_3c = DAT_01eaf170;
  uStack_80 = DAT_01eaf170;
  piStack_18 = DAT_01eaf174;
  piStack_7c = DAT_01eaf174;
  uStack_78 = FUN_0152d930(DAT_01eaf170,DAT_01eaf174);
  uVar13 = 0;
  uStack_8._0_1_ = 6;
  uVar1 = *(uint *)(*(int *)(param_1 + 0x130) + 0x1bc);
  uVar2 = *(uint *)(*(int *)(param_1 + 0x130) + 0x1c0);
  uVar10 = (uVar2 - uVar1) + 3 >> 2;
  if (uVar2 < uVar1) {
    uVar10 = 0;
  }
  if (uVar10 != 0) {
    do {
      FUN_006bc1a0();
      uVar13 = uVar13 + 1;
      param_1 = iStack_38;
    } while (uVar13 != uVar10);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_0152dda0(uStack_3c,piStack_18,uStack_78);
  uStack_8 = 0xffffffff;
  FUN_008eb130();
  *(undefined *)(*(int *)(param_1 + 0x130) + 0x84) = 0;
  if (DAT_01d5b818 != '\0') {
    if (*(int *)(iStack_14 + 0x34) < DAT_01eaf188) {
      FUN_016f3809(&DAT_01eaf188);
      if (DAT_01eaf188 == -1) {
        uStack_8 = 8;
        uVar15 = FUN_0152dab0(&DAT_018c5904,"Dispatch StreamJob",0xffffffff);
        DAT_01eaf184 = (undefined4)((ulonglong)uVar15 >> 0x20);
        DAT_01eaf180 = (undefined4)uVar15;
        uStack_8 = 0xffffffff;
        FUN_016f37bf(&DAT_01eaf188);
      }
    }
    piStack_48 = (int *)DAT_01eaf180;
    uStack_30 = DAT_01eaf180;
    uStack_44 = DAT_01eaf184;
    piStack_2c = (int *)DAT_01eaf184;
    uStack_28 = FUN_0152d930(DAT_01eaf180,DAT_01eaf184);
    iVar11 = *(int *)(param_1 + 0x130);
    bVar4 = false;
    uStack_8 = 9;
    iVar12 = *(int *)(iVar11 + 0x1c0);
    if (iVar12 != *(int *)(iVar11 + 0x1bc)) {
      do {
        iVar3 = *(int *)(iVar12 + -4);
        iVar12 = iVar12 + -4;
        if (((*(char *)(iVar3 + 0x1db9) == '\0') && (*(int *)(iVar3 + 0x1de4) != 0)) &&
           (*(char *)(iVar3 + 0x37f8) != '\0')) {
          uStack_1c = param_2;
          iStack_20 = iVar3;
          cVar8 = FUN_00585a40(&iStack_20);
          if (cVar8 == '\0') {
            iStack_64 = iStack_20;
            uStack_60 = uStack_1c;
            auStack_6c[0] = 0x18df55d;
          }
          else {
            auStack_6c[0] = 0;
          }
          uStack_8._0_1_ = 10;
          FUN_006c74e0(auStack_6c,auStack_4c);
          uStack_8._0_1_ = 0xb;
          if (((auStack_6c[0] != 0) && ((auStack_6c[0] & 1) == 0)) &&
             (*(code **)(auStack_6c[0] & 0xfffffffe) != (code *)0x0)) {
            (**(code **)(auStack_6c[0] & 0xfffffffe))(&iStack_64,&iStack_64,2);
          }
          iVar11 = *(int *)(param_1 + 0x130);
          bVar4 = true;
          uStack_8 = CONCAT31(uStack_8._1_3_,9);
        }
      } while (iVar12 != *(int *)(iVar11 + 0x1bc));
      if (bVar4) {
        LOCK();
        *(undefined *)(iVar11 + 0x38) = 0;
        UNLOCK();
        if (DAT_01d5b9c8 != '\0') {
          FUN_006d5930(*(undefined4 *)(param_1 + 0x11c));
        }
        FUN_0153a600(1);
        if (*(int *)(iStack_14 + 0x34) < DAT_01eaf198) {
          FUN_016f3809(&DAT_01eaf198);
          if (DAT_01eaf198 == -1) {
            uStack_8._0_1_ = 0xc;
            uVar15 = FUN_0152dab0(&DAT_018c5904,"Resolve Metadata",0xffffffff);
            DAT_01eaf194 = (undefined4)((ulonglong)uVar15 >> 0x20);
            DAT_01eaf190 = (undefined4)uVar15;
            uStack_8 = CONCAT31(uStack_8._1_3_,9);
            FUN_016f37bf(&DAT_01eaf198);
          }
        }
        uStack_1c = DAT_01eaf190;
        uStack_5c = DAT_01eaf190;
        uStack_70 = DAT_01eaf194;
        uStack_58 = DAT_01eaf194;
        uStack_54 = FUN_0152d930(DAT_01eaf190,DAT_01eaf194);
        piVar9 = (int *)FUN_00587490(&uStack_78);
        uStack_8._0_1_ = 0xe;
        FUN_008e9840(-(uint)(*piVar9 != 0) & *piVar9 + 0xcU);
        piVar9 = uStack_78._4_4_;
        uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
        if (uStack_78._4_4_ != (int *)0x0) {
          LOCK();
          iVar12 = uStack_78._4_4_[1] + -1;
          uStack_78._4_4_[1] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            (**(code **)*uStack_78._4_4_)();
            LOCK();
            piVar14 = piVar9 + 2;
            iVar12 = *piVar14;
            *piVar14 = *piVar14 + -1;
            UNLOCK();
            if (iVar12 == 1) {
              (**(code **)(*piVar9 + 4))();
            }
          }
        }
        piVar9 = *(int **)(*(int *)(param_1 + 0x130) + 0x1c0);
        piVar14 = *(int **)(*(int *)(param_1 + 0x130) + 0x1bc);
        piStack_18 = piVar9;
        if (piVar14 != piVar9) {
          do {
            iVar12 = *piVar14;
            if ((*(char *)(iVar12 + 0x1db9) == '\0') && (*(int *)(iVar12 + 0x1de4) != 0)) {
              cVar8 = FUN_006e83a0();
              piVar9 = piStack_18;
              if (cVar8 != '\0') {
                uStack_40 = *(undefined4 *)(*(int *)(param_1 + 0x130) + 0x264);
                iStack_34 = iVar12;
                cVar8 = FUN_00585a40(&iStack_34);
                if (cVar8 == '\0') {
                  aiStack_98[0] = iStack_34;
                  auStack_a0[0] = 0x18df565;
                }
                else {
                  auStack_a0[0] = 0;
                }
                uStack_8._0_1_ = 0x11;
                FUN_006c74e0(auStack_a0,&uStack_80);
                uStack_8._0_1_ = 0x12;
                if (((auStack_a0[0] != 0) && ((auStack_a0[0] & 1) == 0)) &&
                   (*(code **)(auStack_a0[0] & 0xfffffffe) != (code *)0x0)) {
                  (**(code **)(auStack_a0[0] & 0xfffffffe))(aiStack_98,aiStack_98,2);
                }
                uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
                piVar9 = piStack_18;
              }
            }
            piVar14 = piVar14 + 1;
          } while (piVar14 != piVar9);
        }
        uStack_8._0_1_ = 0xd;
        FUN_008eb130();
        FUN_0153a600(1);
        uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
        FUN_0152dda0(uStack_1c,uStack_70,uStack_54);
      }
    }
    uStack_8 = 0x14;
    FUN_0152dda0(piStack_48,uStack_44,uStack_28);
    uStack_8 = 0xffffffff;
    if (*(int *)(iStack_14 + 0x34) < DAT_01eaf1a8) {
      FUN_016f3809(&DAT_01eaf1a8);
      if (DAT_01eaf1a8 == -1) {
        uStack_8 = 0x15;
        uVar15 = FUN_0152dab0(&DAT_018c5904,"Dispatch Data Senders",0xffffffff);
        DAT_01eaf1a4 = (int *)((ulonglong)uVar15 >> 0x20);
        DAT_01eaf1a0 = (undefined4)uVar15;
        uStack_8 = 0xffffffff;
        FUN_016f37bf(&DAT_01eaf1a8);
      }
    }
    uStack_44 = DAT_01eaf1a0;
    uStack_30 = DAT_01eaf1a0;
    piStack_48 = DAT_01eaf1a4;
    piStack_2c = DAT_01eaf1a4;
    uVar15 = FUN_0152d930(DAT_01eaf1a0,DAT_01eaf1a4);
    uStack_8._1_3_ = 0;
    iVar12 = *(int *)(*(int *)(param_1 + 0x130) + 0x1c0);
    if (iVar12 != *(int *)(*(int *)(param_1 + 0x130) + 0x1bc)) {
      do {
        uStack_8._0_1_ = 0x16;
        iStack_20 = *(int *)(iVar12 + -4);
        iVar12 = iVar12 + -4;
        uStack_1c = param_2;
        uStack_28 = uVar15;
        cVar8 = FUN_00585a40(&iStack_20);
        if (cVar8 == '\0') {
          iStack_64 = iStack_20;
          uStack_60 = uStack_1c;
          auStack_6c[0] = 0x18df56d;
        }
        else {
          auStack_6c[0] = 0;
        }
        uStack_8._0_1_ = 0x17;
        FUN_006c74e0(auStack_6c,auStack_4c);
        uStack_8._0_1_ = 0x18;
        uVar15 = uStack_28;
        if (((auStack_6c[0] != 0) && ((auStack_6c[0] & 1) == 0)) &&
           (*(code **)(auStack_6c[0] & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(auStack_6c[0] & 0xfffffffe))(&iStack_64,&iStack_64,2);
          uVar15 = uStack_28;
        }
      } while (iVar12 != *(int *)(*(int *)(param_1 + 0x130) + 0x1bc));
    }
    uStack_8._0_1_ = 0x16;
    uStack_28 = uVar15;
    FUN_0153a600(1);
    FUN_006d6250();
    uStack_8 = 0x19;
    FUN_0152dda0(uStack_44,piStack_48,uStack_28);
    uStack_8 = 0xffffffff;
  }
  piVar9 = *(int **)(*(int *)(param_1 + 0x130) + 0x1c0);
  for (piVar14 = *(int **)(*(int *)(param_1 + 0x130) + 0x1bc); piVar14 != piVar9;
      piVar14 = piVar14 + 1) {
    if (*(int *)(iStack_14 + 0x34) < DAT_01eaf1b8) {
      FUN_016f3809(&DAT_01eaf1b8);
      if (DAT_01eaf1b8 == -1) {
        uStack_8 = 0x1a;
        uVar15 = FUN_0152dab0(&DAT_018c5904,"Send clusters",0xffffffff);
        DAT_01eaf1b4 = (int *)((ulonglong)uVar15 >> 0x20);
        DAT_01eaf1b0 = (undefined4)uVar15;
        uStack_8 = 0xffffffff;
        FUN_016f37bf(&DAT_01eaf1b8);
      }
    }
    piVar6 = DAT_01eaf1b4;
    uVar5 = DAT_01eaf1b0;
    uStack_30 = DAT_01eaf1b0;
    piStack_2c = DAT_01eaf1b4;
    uVar15 = FUN_0152d930(DAT_01eaf1b0,DAT_01eaf1b4);
    uStack_8 = 0x1b;
    uStack_28 = uVar15;
    if (*(char *)(*piVar14 + 0x1db9) == '\0') {
      cVar8 = FUN_006264a0(*piVar14,2,1);
      if (cVar8 != '\0') {
        FUN_006bb6a0();
      }
    }
    uStack_8 = 0x1c;
    FUN_0152dda0(uVar5,piVar6,uStack_28);
    uStack_8 = 0xffffffff;
    param_1 = iStack_38;
  }
  FUN_006d5250(param_1);
  FUN_006d5250(param_1);
  if (*(int *)(iStack_14 + 0x34) < DAT_01eaf1c8) {
    FUN_016f3809(&DAT_01eaf1c8);
    if (DAT_01eaf1c8 == -1) {
      uStack_8 = 0x1d;
      uVar15 = FUN_0152dab0(&DAT_018c5904,"Dispatch PhysicsSenders and TouchSenders",0xffffffff);
      DAT_01eaf1c4 = (undefined4)((ulonglong)uVar15 >> 0x20);
      DAT_01eaf1c0 = (undefined4)uVar15;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eaf1c8);
    }
  }
  uVar7 = DAT_01eaf1c4;
  uVar5 = DAT_01eaf1c0;
  uStack_30 = DAT_01eaf1c0;
  piStack_2c = (int *)DAT_01eaf1c4;
  uVar15 = FUN_0152d930(DAT_01eaf1c0,DAT_01eaf1c4);
  uStack_8 = 0x1e;
  uStack_28 = uVar15;
  FUN_0153a600(1);
  uStack_8 = 0x1f;
  FUN_0152dda0(uVar5,uVar7,uVar15);
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 9386 ; VA 0x006dfa90 ; FUN_006dfa90 */

void __fastcall FUN_006dfa90(int param_1)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0xbc) != 0) {
    FUN_0071dda0();
    iVar1 = *(int *)(param_1 + 0xbc);
    *(undefined4 *)(param_1 + 0xbc) = 0;
    if (iVar1 != 0) {
      (*(code *)**(undefined4 **)(iVar1 + 8))(1);
    }
  }
  return;
}



/* FUNCTION 9387 ; VA 0x006dfad0 ; FUN_006dfad0 */

bool __thiscall FUN_006dfad0(uint *param_1,uint *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  bool bVar9;
  longlong lVar10;
  undefined8 uVar11;
  undefined auStack_44 [8];
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  int iStack_30;
  uint uStack_2c;
  int iStack_28;
  undefined8 uStack_24;
  uint *puStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a91f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_1c = param_1;
  while( true ) {
    uVar6 = *param_1;
    do {
      uVar7 = uVar6;
      if ((uVar7 & 0x4007ff) == 0) {
        uVar5 = uVar7 | 0x400000;
      }
      else {
        uVar5 = ((uVar7 & 0xff000000) + 0x1000000 ^ uVar7) & 0x7f000000 ^ uVar7;
        if ((uVar5 & 0x7f000000) == 0) {
          uVar4 = FUN_006d1620();
          uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
          FUN_00564990(uVar4);
        }
        uVar5 = uVar5 | 0x80000000;
      }
      LOCK();
      uVar6 = *param_1;
      if (uVar7 == uVar6) {
        *param_1 = uVar5;
        uVar6 = uVar7;
      }
      UNLOCK();
    } while (uVar6 != uVar7);
    if ((uVar7 & 0x4007ff) == 0) break;
    if ((*param_2 == 0xffffffff) && (param_2[1] == 0x7fffffff)) {
      iVar2 = -1;
    }
    else {
      FUN_005f0a90(&uStack_2c,FUN_005f1e70);
      if ((iStack_28 < (int)param_2[1]) ||
         ((iStack_28 <= (int)param_2[1] && (uStack_2c < *param_2)))) {
        uVar6 = *param_2;
        uVar5 = param_2[1];
        if (((((uVar6 == 0) && (uVar5 == 0x80000000)) ||
             ((((uVar6 == 0xffffffff && (uVar5 == 0x7fffffff)) ||
               ((uVar6 == 0xfffffffe && (uVar5 == 0x7fffffff)))) ||
              ((uStack_2c == 0 && (iStack_28 == -0x80000000)))))) ||
            ((uStack_2c == 0xffffffff && (iStack_28 == 0x7fffffff)))) ||
           ((uStack_2c == 0xfffffffe && (iStack_28 == 0x7fffffff)))) {
          uStack_34 = uStack_2c;
          uStack_38 = param_2[1];
          iStack_30 = iStack_28;
          uStack_3c = uVar6;
          piVar3 = (int *)FUN_00602640(auStack_44,&uStack_34);
          iVar2 = *piVar3;
          iVar1 = piVar3[1];
          if ((iVar2 == -2) && (iVar1 == 0x7fffffff)) {
            FUN_0056b510(0);
          }
          else if ((iVar2 == 0) && (iVar1 == -0x80000000)) {
            FUN_0056b510(1);
          }
          else {
            if ((iVar2 != -1) || (uVar4 = 2, iVar1 != 0x7fffffff)) {
              uVar4 = 5;
            }
            FUN_0056b510(uVar4);
          }
        }
        else {
          uStack_18 = uVar6 - uStack_2c;
          uVar6 = (uVar5 - iStack_28) - (uint)(uVar6 < uStack_2c);
          if ((int)uVar6 < 0) {
            uVar5 = (int)uVar6 >> 0x1f;
            uVar8 = uStack_18 ^ uVar5;
            uStack_18 = uVar8 - uVar5;
            uVar11 = FUN_016f39b0(0,1000000,0);
            uStack_14 = -(int)uVar11;
            uStack_24 = CONCAT44(((-(uint)((int)uVar11 != 0) - (int)((ulonglong)uVar11 >> 0x20)) -
                                 (((uVar6 ^ uVar5) - uVar5) - (uint)(uVar8 < uVar5))) -
                                 (uint)(uStack_14 < uStack_18),uStack_14 - uStack_18);
          }
          else {
            lVar10 = FUN_016f39b0(0,1000000,0);
            uStack_14 = (uint)((ulonglong)lVar10 >> 0x20);
            uStack_24 = lVar10 + CONCAT44(uVar6,uStack_18);
          }
        }
        iVar2 = FUN_016f3900(uStack_24,1000,0);
        iVar2 = iVar2 + 1;
      }
      else {
        iVar2 = 0;
      }
    }
    param_1 = puStack_1c;
    iVar2 = WaitForMultipleObjectsEx(2,puStack_1c + 1,1,iVar2,0);
    if (iVar2 == 0x102) {
      do {
        bVar9 = false;
        puStack_1c = (uint *)(uVar7 & 0x4007ff);
        if (puStack_1c == (uint *)0x0) {
          uVar6 = uVar7 | 0x400000;
        }
        else {
          uVar6 = uVar7;
          if (((uVar7 >> 0x18 & 0x7f) != 0) &&
             (uVar6 = (((uVar7 >> 0x18) - 1) * 0x1000000 ^ uVar7) & 0x7f000000 ^ uVar7,
             (uVar6 & 0x7f000000) == 0)) {
            uVar6 = uVar6 & 0x7fffffff;
            bVar9 = true;
          }
        }
        LOCK();
        uVar5 = *param_1;
        if (uVar7 == uVar5) {
          *param_1 = uVar6;
          uVar5 = uVar7;
        }
        UNLOCK();
        if (bVar9) {
          ReleaseSemaphore();
        }
        bVar9 = uVar5 != uVar7;
        uVar7 = uVar5;
      } while (bVar9);
      ExceptionList = pvStack_10;
      return puStack_1c == (uint *)0x0;
    }
  }
  ExceptionList = pvStack_10;
  return true;
}



/* FUNCTION 9388 ; VA 0x006dfe10 ; FUN_006dfe10 */

uint __thiscall FUN_006dfe10(uint *param_1,uint *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  undefined auStack_3c [8];
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  int iStack_28;
  uint uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9220;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  while( true ) {
    uVar5 = *param_1;
    do {
      uVar7 = uVar5;
      if (((uVar7 & 0x400000) == 0) && (-1 < (int)uVar7)) {
        uVar6 = (uVar7 + 1 ^ uVar7) & 0x7ff ^ uVar7;
        if ((uVar6 & 0x7ff) == 0) {
          uVar4 = FUN_006d1620();
          uStack_8 = 1;
                    /* WARNING: Subroutine does not return */
          FUN_00564990(uVar4);
        }
      }
      else {
        uVar6 = ((uVar7 & 0xfffff800) + 0x800 ^ uVar7) & 0x3ff800 ^ uVar7;
        if ((uVar6 & 0x3ff800) == 0) {
          uVar4 = FUN_006d1620();
          uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
          FUN_00564990(uVar4);
        }
      }
      LOCK();
      uVar5 = *param_1;
      if (uVar7 == uVar5) {
        *param_1 = uVar6;
        uVar5 = uVar7;
      }
      UNLOCK();
    } while (uVar5 != uVar7);
    if ((uVar7 & 0x80400000) == 0) break;
    if ((*param_2 == 0xffffffff) && (param_2[1] == 0x7fffffff)) {
      iVar2 = -1;
    }
    else {
      FUN_005f0a90(&uStack_24,FUN_005f1e70);
      if ((iStack_20 < (int)param_2[1]) ||
         ((iStack_20 <= (int)param_2[1] && (uStack_24 < *param_2)))) {
        uVar5 = *param_2;
        uVar6 = param_2[1];
        if (((((uVar5 == 0) && (uVar6 == 0x80000000)) ||
             ((((uVar5 == 0xffffffff && (uVar6 == 0x7fffffff)) ||
               ((uVar5 == 0xfffffffe && (uVar6 == 0x7fffffff)))) ||
              ((uStack_24 == 0 && (iStack_20 == -0x80000000)))))) ||
            ((uStack_24 == 0xffffffff && (iStack_20 == 0x7fffffff)))) ||
           ((uStack_24 == 0xfffffffe && (iStack_20 == 0x7fffffff)))) {
          uStack_2c = uStack_24;
          uStack_30 = param_2[1];
          iStack_28 = iStack_20;
          uStack_34 = uVar5;
          piVar3 = (int *)FUN_00602640(auStack_3c,&uStack_2c);
          iVar2 = *piVar3;
          iVar1 = piVar3[1];
          if ((iVar2 == -2) && (iVar1 == 0x7fffffff)) {
            FUN_0056b510(0);
          }
          else if ((iVar2 == 0) && (iVar1 == -0x80000000)) {
            FUN_0056b510(1);
          }
          else {
            if ((iVar2 != -1) || (uVar4 = 2, iVar1 != 0x7fffffff)) {
              uVar4 = 5;
            }
            FUN_0056b510(uVar4);
          }
        }
        else {
          FUN_005ef640(0,0,0,uVar5 - uStack_24,(uVar6 - iStack_20) - (uint)(uVar5 < uStack_24));
        }
        iVar2 = FUN_016f3900(uStack_1c,uStack_18,1000,0);
        iVar2 = iVar2 + 1;
        param_1 = puStack_14;
      }
      else {
        iVar2 = 0;
        param_1 = puStack_14;
      }
    }
    iVar2 = WaitForSingleObjectEx(param_1[1],iVar2,0);
    if (iVar2 == 0x102) {
      uVar5 = 0x102;
      do {
        uVar6 = uVar7;
        if (((uVar6 & 0x400000) == 0) && (-1 < (int)uVar6)) {
          uVar7 = (uVar6 + 1 ^ uVar6) & 0x7ff ^ uVar6;
          if ((uVar7 & 0x7ff) == 0) {
            ExceptionList = pvStack_10;
            return uVar5 & 0xffffff00;
          }
        }
        else {
          uVar7 = uVar6;
          if ((uVar6 >> 0xb & 0x7ff) != 0) {
            uVar7 = (((uVar6 >> 0xb) - 1) * 0x800 ^ uVar6) & 0x3ff800 ^ uVar6;
          }
        }
        LOCK();
        uVar5 = *param_1;
        if (uVar6 == uVar5) {
          *param_1 = uVar7;
          uVar5 = uVar6;
        }
        UNLOCK();
        uVar7 = uVar5;
      } while (uVar5 != uVar6);
      ExceptionList = pvStack_10;
      return CONCAT31((int3)(uVar5 >> 8),(uVar6 & 0x80400000) == 0);
    }
  }
  ExceptionList = pvStack_10;
  return CONCAT31((int3)(uVar5 >> 8),1);
}



/* FUNCTION 9389 ; VA 0x006e00b0 ; FUN_006e00b0 */

void __fastcall FUN_006e00b0(uint *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  
  uVar2 = *param_1;
  do {
    uVar3 = uVar2;
    uVar1 = uVar3 & 0xffbfffff;
    if ((uVar3 >> 0x18 & 0x7f) != 0) {
      uVar1 = uVar3 & 0xbfffff | ((uVar3 >> 0x18) - 1 & 0x7f) << 0x18;
    }
    LOCK();
    uVar2 = *param_1;
    if (uVar3 == uVar2) {
      *param_1 = uVar1 & 0xffc007ff;
      uVar2 = uVar3;
    }
    UNLOCK();
  } while (uVar2 != uVar3);
  uVar2 = uVar3 & 0x7f000000;
  if (uVar2 != 0) {
    ReleaseSemaphore(param_1[2],1,0);
  }
  uVar1 = uVar3 >> 0xb & 0x7ff;
  if ((uVar1 != 0) || (uVar2 != 0)) {
    ReleaseSemaphore(param_1[1],(uVar2 != 0) + uVar1,0);
  }
  return;
}



/* FUNCTION 9390 ; VA 0x006e0140 ; FUN_006e0140 */

void __fastcall FUN_006e0140(uint *param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  
  uVar4 = *param_1;
  do {
    uVar3 = uVar4;
    uVar2 = (uVar3 - 1 ^ uVar3) & 0x7ff ^ uVar3;
    uVar1 = uVar2 & 0x7ff;
    if (uVar1 == 0) {
      if ((uVar2 & 0x800000) == 0) {
        if ((uVar3 >> 0x18 & 0x7f) != 0) {
          uVar2 = uVar2 & 0xffffff | ((uVar3 >> 0x18) - 1 & 0x7f) << 0x18;
        }
        uVar2 = uVar2 & 0xffc007ff;
      }
      else {
        uVar2 = uVar2 & 0xff7fffff | 0x400000;
      }
    }
    LOCK();
    uVar4 = *param_1;
    if (uVar3 == uVar4) {
      *param_1 = uVar2;
      uVar4 = uVar3;
    }
    UNLOCK();
  } while (uVar4 != uVar3);
  if (uVar1 == 0) {
    if ((uVar3 & 0x800000) != 0) {
      ReleaseSemaphore(param_1[3],1,0);
      return;
    }
    uVar4 = uVar3 & 0x7f000000;
    if (uVar4 != 0) {
      ReleaseSemaphore(param_1[2],1,0);
    }
    uVar1 = uVar3 >> 0xb & 0x7ff;
    if ((uVar1 != 0) || (uVar4 != 0)) {
      ReleaseSemaphore(param_1[1],(uVar4 != 0) + uVar1,0);
    }
  }
  return;
}



/* FUNCTION 9391 ; VA 0x006e0210 ; FUN_006e0210 */

void __thiscall FUN_006e0210(byte *param_1,uint param_2,uint param_3)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined auStack_30 [24];
  uint uStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar2 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  if (((((param_3 < (uint)((*(int *)(param_2 + 0x38) - *(int *)(param_2 + 0x34)) / 0xc)) &&
        (*(char *)(*(int *)(param_2 + 0x34) + 9 + param_3 * 0xc) != '\0')) &&
       (param_2 = *(uint *)(*(int *)(param_2 + 4) + 0x34), param_2 != 0)) &&
      ((ExceptionList = &pvStack_10, uStack_18 = param_2, pbStack_14 = param_1,
       FUN_00606ea0(&param_3,(param_2 >> 3) + param_2,&param_2,
                    -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) &
                    (uint)(param_1 + *param_1 + 1 + 1)), uVar3 = param_3, param_3 != 0 &&
       (iVar5 = *(int *)(param_3 + 0x40), uVar2 < (uint)((*(int *)(param_3 + 0x44) - iVar5) / 0xc)))
      )) && (((DAT_01d5b840 != '\0' && (*(char *)(param_3 + 0x3f) != '\0')) ||
             (*(char *)(iVar5 + 8 + uVar2 * 0xc) != '\0')))) {
    param_2 = iVar5;
    if (DAT_01ee420d != '\0') {
      puVar4 = (undefined4 *)FUN_008a2380(auStack_30);
      uStack_8 = 0;
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      FUN_01677490(DAT_01ee420d,
                   "updateCompletenessForParentOfChildBeingMarkedDead():: numCompleteChildren-- for %s[%d]"
                   ,puVar4,uVar2,0);
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      iVar5 = *(int *)(uVar3 + 0x40);
    }
    piVar1 = (int *)(iVar5 + uVar2 * 0xc);
    *piVar1 = *piVar1 + -1;
    FUN_006d6e00(uVar3 + 0xc,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9392 ; VA 0x006e0360 ; FUN_006e0360 */

void __thiscall
FUN_006e0360(int param_1,uint param_2,uint param_3,uint param_4,uint param_5,undefined4 *param_6)

{
  uint *puVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  byte *pbVar5;
  uint *puVar6;
  uint *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  uint uVar11;
  uint uStack_3c;
  uint uStack_38;
  undefined4 *puStack_34;
  uint uStack_30;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  int iStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar8 = param_6;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9238;
  pvStack_10 = ExceptionList;
  if (param_6 == &DAT_0211a3d8) {
    return;
  }
  iStack_24 = param_1 + 0x254;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  piVar3 = (int *)FUN_006d2ac0(&param_2);
  puVar7 = (uint *)piVar3[1];
  puVar6 = (uint *)*piVar3;
  piStack_20 = piVar3;
  if (puVar6 != puVar7) {
    do {
      uStack_3c = *puVar6;
      uStack_38 = puVar6[1];
      if ((undefined4 *)puVar6[2] == puVar8) break;
      puVar6 = puVar6 + 3;
    } while (puVar6 != puVar7);
    if (puVar6 != puVar7) {
      if (*(int *)(iStack_18 + 0x25c) == -1) {
LAB_006e0400:
        if ((param_4 == 0xffffffff) && (cVar2 = FUN_009c8f50(&param_4), cVar2 != '\0'))
        goto LAB_006e0509;
      }
      else if (param_4 == 0xffffffff) {
        cVar2 = FUN_009c8f50((int *)(iStack_18 + 0x25c));
        if (cVar2 != '\0') {
          ExceptionList = pvStack_10;
          return;
        }
        goto LAB_006e0400;
      }
      piStack_14 = (int *)(iStack_18 + 0x24c);
      iVar4 = FUN_006d2a20(puVar6);
      uStack_30 = param_2;
      puStack_28 = param_6;
      puStack_2c = (undefined4 *)param_3;
      FUN_006d8310(&uStack_30);
      puVar8 = param_6;
      if (*(int *)(iVar4 + 8) == 0) {
        puVar8 = (undefined4 *)*piStack_14;
        cVar2 = *(char *)((int)puVar8[1] + 0xd);
        puStack_1c = puVar8;
        puVar9 = (undefined4 *)puVar8[1];
        while (cVar2 == '\0') {
          cVar2 = FUN_009c8f70(puVar6);
          if (cVar2 == '\0') {
            if ((*(char *)((int)puVar8 + 0xd) != '\0') &&
               (cVar2 = FUN_009c8f70(puVar9 + 4), cVar2 != '\0')) {
              puVar8 = puVar9;
            }
            puVar10 = (undefined4 *)*puVar9;
            puStack_1c = puVar9;
          }
          else {
            puVar10 = (undefined4 *)puVar9[2];
          }
          puVar9 = puVar10;
          cVar2 = *(char *)((int)puVar10 + 0xd);
        }
        puVar9 = puVar8;
        if (*(char *)((int)puVar8 + 0xd) != '\0') {
          puVar9 = (undefined4 *)(*piStack_14 + 4);
        }
        cVar2 = *(char *)((int)*puVar9 + 0xd);
        puVar9 = (undefined4 *)*puVar9;
        puVar10 = puStack_1c;
        while (puStack_1c = puVar10, cVar2 == '\0') {
          cVar2 = FUN_009c8f70(puVar9 + 4);
          if (cVar2 == '\0') {
            puVar10 = (undefined4 *)puVar9[2];
          }
          else {
            puVar10 = (undefined4 *)*puVar9;
            puVar8 = puVar9;
          }
          cVar2 = *(char *)((int)puVar10 + 0xd);
          puVar9 = puVar10;
          puVar10 = puStack_1c;
        }
        while (puStack_1c != puVar8) {
          FUN_00551320();
        }
        FUN_006d7f40(&puStack_1c,puVar10,puVar8);
        piVar3 = piStack_20;
        puVar8 = param_6;
      }
      goto LAB_006e0509;
    }
  }
  uStack_30 = param_4;
  puStack_2c = (undefined4 *)param_5;
  puStack_28 = puVar8;
  if ((uint *)piVar3[2] == puVar7) {
    puVar6 = (uint *)FUN_006bea10(puVar6,&uStack_30);
  }
  else {
    *(ulonglong *)puVar7 = CONCAT44(param_5,param_4);
    puVar7[2] = (uint)puVar8;
    piVar3[1] = piVar3[1] + 0xc;
    puStack_28 = puVar8;
  }
LAB_006e0509:
  if (param_4 == 0xffffffff) {
    puVar1 = (uint *)piVar3[1];
    puVar7 = puVar6 + 3;
    if (puVar7 != puVar1) {
      puVar6 = puVar6 + 2;
      do {
        puVar6[-2] = *puVar7;
        puVar7 = puVar7 + 3;
        puVar6[-1] = puVar6[2];
        *puVar6 = puVar6[3];
        puVar6 = puVar6 + 3;
      } while (puVar7 != puVar1);
    }
    piVar3[1] = piVar3[1] + -0xc;
    if (*piVar3 == piVar3[1]) {
      FUN_006d80e0(&param_2);
    }
  }
  else {
    *puVar6 = param_4;
    puVar6[1] = param_5;
    pbVar5 = (byte *)FUN_006d2a20(&param_4);
    uStack_3c = param_2;
    uStack_38 = param_3;
    puStack_34 = puVar8;
    iVar4 = FUN_009c91f0(&uStack_3c);
    uVar11 = iVar4 + 0x9e3779b9;
    uVar11 = (int)puStack_34 + (uVar11 >> 2) + 0x9e3779b9 + ((uint)puStack_34 >> 3) + uVar11 * 0x40
             ^ uVar11;
    FUN_006d0350(&param_6,uVar11,&uStack_3c,
                 -(uint)(pbVar5 + *pbVar5 + 1 != (byte *)0x0) & (uint)(pbVar5 + *pbVar5 + 1 + 1));
    if (param_6 == (undefined4 *)0x0) {
      puStack_2c = (undefined4 *)0x0;
      uStack_30 = -(uint)(pbVar5 != (byte *)0xfffffffd) & (uint)(pbVar5 + 4);
      uStack_8 = 0;
      puStack_28 = (undefined4 *)((uint)puStack_28 & 0xffff0000);
      puStack_2c = (undefined4 *)FUN_01674e20(0x14);
      puStack_28 = (undefined4 *)CONCAT22(puStack_28._2_2_,0x101);
      *puStack_2c = 0;
      puStack_2c[1] = 0;
      *(undefined8 *)(puStack_2c + 2) = 0;
      puStack_2c[4] = 0;
      *(ulonglong *)(puStack_2c + 2) = CONCAT44(uStack_38,uStack_3c);
      puStack_2c[4] = puStack_34;
      FUN_0062b610(*(int *)(pbVar5 + 8) + 1);
      FUN_005c5550(&piStack_20,&uStack_30,uVar11);
      if (puStack_2c != (undefined4 *)0x0) {
        FUN_01674ea0(puStack_2c,0x14);
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9393 ; VA 0x006e06e0 ; FUN_006e06e0 */

void __thiscall FUN_006e06e0(byte *param_1,uint param_2,uint param_3)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  uVar6 = -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1);
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&iStack_14,(param_2 >> 3) + param_2,&param_2,uVar6);
  FUN_00606ea0(&iStack_18,(param_3 >> 3) + param_3,&param_3,uVar6);
  if (((iStack_14 != 0) && (iStack_18 != 0)) &&
     (iVar3 = *(int *)(iStack_18 + 0x44) - *(int *)(iStack_18 + 0x40), param_3 = 0,
     iVar5 = iVar3 >> 0x1f, iVar3 / 0xc + iVar5 != iVar5)) {
    iVar5 = 0;
    do {
      if (*(char *)(*(int *)(iStack_18 + 0x40) + 9 + iVar5) != '\0') {
        if ((DAT_01d5b870 != '\0') &&
           ((uint)((*(int *)(iStack_14 + 0x44) - *(int *)(iStack_14 + 0x40)) / 0xc) <= param_3)) {
          if (DAT_01eaf006 == '\0') {
            ExceptionList = pvStack_10;
            return;
          }
          piVar2 = *(int **)(param_2 + 0x28);
          if (0xf < (uint)piVar2[5]) {
            piVar2 = (int *)*piVar2;
          }
          FUN_01677520(DAT_01eaf006,
                       "updateParentCompletenessCount_deprecated indexing past end of conn data vector, instance %s, index %d, connData size: %zu"
                       ,piVar2,param_3,
                       (*(int *)(iStack_14 + 0x44) - *(int *)(iStack_14 + 0x40)) / 0xc);
          ExceptionList = pvStack_10;
          return;
        }
        if (((DAT_01d5b820 == '\0') ||
            ((DAT_01d5b840 != '\0' && (*(char *)(iStack_14 + 0x3f) != '\0')))) ||
           (*(char *)(*(int *)(iStack_14 + 0x40) + 8 + iVar5) != '\0')) {
          if (DAT_01ee420d != '\0') {
            puVar1 = (undefined4 *)FUN_008a2380(auStack_30);
            uStack_8 = 0;
            if (0xf < (uint)puVar1[5]) {
              puVar1 = (undefined4 *)*puVar1;
            }
            FUN_01677490(DAT_01ee420d,
                         "updateParentCompletenessCount():: numCompleteChildren++ for %s[%d]",puVar1
                         ,param_3,0);
            uStack_8 = 0xffffffff;
            if (0xf < uStack_1c) {
              uVar4 = uStack_1c + 1;
              uVar6 = auStack_30[0];
              if (0xfff < uVar4) {
                uVar6 = *(uint *)(auStack_30[0] - 4);
                uVar4 = uStack_1c + 0x24;
                if (0x1f < (auStack_30[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
                  FUN_017167a3();
                }
              }
              FUN_01674ea0(uVar6,uVar4);
            }
            uStack_20 = 0;
            uStack_1c = 0xf;
            auStack_30[0] = auStack_30[0] & 0xffffff00;
          }
          piVar2 = (int *)(*(int *)(iStack_14 + 0x40) + iVar5);
          *piVar2 = *piVar2 + 1;
        }
      }
      iVar5 = iVar5 + 0xc;
      param_3 = param_3 + 1;
    } while (param_3 < (uint)((*(int *)(iStack_18 + 0x44) - *(int *)(iStack_18 + 0x40)) / 0xc));
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9394 ; VA 0x006e0910 ; FUN_006e0910 */

undefined4 __thiscall
FUN_006e0910(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,uint param_6)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_14;
  undefined4 uStack_10;
  uint uStack_c;
  uint uStack_8;
  
  FUN_006d8510(&uStack_8,&param_4);
  if (uStack_8 != *(uint *)(param_1 + 0x24c)) {
    uStack_14 = param_2;
    uStack_10 = param_3;
    uStack_c = param_6;
    iVar3 = uStack_8 + 0x19 + (uint)*(byte *)(uStack_8 + 0x18);
    iVar2 = FUN_009c91f0(&uStack_14);
    uVar1 = iVar2 + 0x9e3779b9;
    FUN_006d0350(&param_6,(uStack_c >> 3) + 0x9e3779b9 + (uVar1 >> 2) + uStack_c + uVar1 * 0x40 ^
                          uVar1,&uStack_14,-(uint)(iVar3 != 0) & iVar3 + 1U);
    if (param_6 != 0) {
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 9395 ; VA 0x006e09c0 ; FUN_006e09c0 */

void * __thiscall FUN_006e09c0(int param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a9260;
  puVar6 = *(undefined4 **)(param_1 + 0x2c);
  pvVar4 = ExceptionList;
  if (puVar6 != (undefined4 *)0x0) {
    piVar5 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar5 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
      piVar5 = *(int **)(param_1 + 0x30);
      puVar6 = *(undefined4 **)(param_1 + 0x2c);
    }
    puVar2 = (undefined4 *)puVar6[1];
    puVar6 = (undefined4 *)*puVar6;
    iStack_8 = 0;
    pvVar4 = pvStack_10;
    for (; piStack_18 = piVar5, puVar6 != puVar2; puVar6 = puVar6 + 2) {
      piStack_1c = (int *)puVar6[1];
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[1] = piStack_1c[1] + 1;
        UNLOCK();
        piStack_1c = (int *)puVar6[1];
      }
      uStack_20 = *puVar6;
      iStack_8._1_3_ = (uint3)((uint)iStack_8 >> 8);
      iStack_8._0_1_ = 1;
      if (*(int **)(param_2 + 0x24) == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
        FUN_016ddc9c();
      }
      pvVar4 = (void *)(**(code **)(**(int **)(param_2 + 0x24) + 8))(&uStack_20);
      piVar5 = piStack_1c;
      cStack_11 = (char)pvVar4;
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar3 = *piVar1;
          pvVar4 = (void *)*piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            pvVar4 = (void *)(**(code **)(*piVar5 + 4))();
          }
        }
      }
      if (cStack_11 != '\0') {
        pvVar4 = (void *)FUN_006e09c0(param_2);
      }
      piVar5 = piStack_18;
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar1 = piVar5 + 1;
      iVar3 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        pvVar4 = (void *)(**(code **)*piVar5)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          pvVar4 = (void *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 9396 ; VA 0x006e0af0 ; FUN_006e0af0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_006e0af0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaf0a8) {
    FUN_016f3809(&DAT_01eaf0a8);
    if (DAT_01eaf0a8 == -1) {
      _DAT_01eaf098 = 0;
      _DAT_01eaf090 = 0;
      _DAT_01eaf09c = 0;
      DAT_01eaf0a0._4_4_ = 0;
      FUN_016f37bf(&DAT_01eaf0a8);
    }
  }
  return &DAT_01eaf090;
}



/* FUNCTION 9397 ; VA 0x006e0b80 ; FUN_006e0b80 */

undefined4
FUN_006e0b80(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 *param_4,
            undefined8 *param_5,uint *param_6,undefined4 *param_7)

{
  undefined8 uVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 uVar5;
  uint uStack_7c;
  uint uStack_78;
  uint uStack_74;
  uint uStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017a9270;
  pvStack_1c = ExceptionList;
  uStack_64 = param_2;
  uStack_6c = CONCAT44(param_1,0x6e0bc4);
  ExceptionList = &pvStack_1c;
  uVar5 = FUN_006e3070();
  uStack_14 = 0;
  uStack_64 = *param_7;
  uVar1 = *param_5;
  uVar2 = *param_4;
  uVar3 = *(undefined4 *)(param_4 + 1);
  uVar4 = *param_6;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      (**(code **)(uVar4 & 0xfffffffe))(param_6 + 2,&uStack_7c,0);
    }
    else {
      uStack_7c = param_6[2];
      uStack_78 = param_6[3];
      uStack_74 = param_6[4];
      uStack_70 = param_6[5];
      uStack_6c = *(undefined8 *)(param_6 + 6);
    }
  }
  FUN_006e1a80(param_3,uVar2,uVar3,uVar1);
  ExceptionList = pvStack_1c;
  return uVar5;
}



/* FUNCTION 9398 ; VA 0x006e0c7c ; Catch_All@006e0c7c */

void Catch_All_006e0c7c(void)

{
  int unaff_EBP;
  
  FUN_006e4e60(*(undefined4 *)(unaff_EBP + -0x24),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9399 ; VA 0x006e0ca0 ; FUN_006e0ca0 */

undefined4 FUN_006e0ca0(undefined4 *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  char cVar7;
  int iVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  iVar2 = *param_2;
  piVar3 = (int *)param_2[1];
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  param_2[1] = 0;
  iVar4 = *(int *)(iVar2 + 0xc);
  uStack_8 = 0;
  iVar8 = FUN_00aff8c0();
  if ((uint)*(ushort *)(iVar8 + 0x1da) <
      (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8)) {
    cVar7 = FUN_006e6340(iVar2);
    if (cVar7 == '\0') {
      uVar5 = *param_1;
      piVar1 = piVar3 + 1;
      uVar6 = param_1[1];
      if (piVar3 != (int *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_006e3af0(iVar2,piVar3,uVar6,uVar5);
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return 1;
    }
  }
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 9400 ; VA 0x006e0dc0 ; FUN_006e0dc0 */

void FUN_006e0dc0(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (param_1 != param_2) {
    piVar3 = param_1 + 1;
    do {
      piVar1 = (int *)piVar3[4];
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      piVar1 = (int *)*piVar3;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      piVar1 = piVar3 + 5;
      piVar3 = piVar3 + 6;
    } while (piVar1 != param_2);
  }
  return;
}



/* FUNCTION 9401 ; VA 0x006e0e40 ; FUN_006e0e40 */

int __thiscall
FUN_006e0e40(uint *param_1,uint param_2,undefined4 *param_3,undefined4 *param_4,undefined4 *param_5)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  
  uVar7 = *param_1;
  iVar5 = (int)(param_1[1] - uVar7) / 0x18;
  if (iVar5 == 0xaaaaaaa) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar9 = iVar5 + 1;
  uVar6 = (int)(param_1[2] - uVar7) / 0x18;
  uVar10 = uVar9;
  if ((uVar6 <= 0xaaaaaaa - (uVar6 >> 1)) && (uVar10 = (uVar6 >> 1) + uVar6, uVar10 < uVar9)) {
    uVar10 = uVar9;
  }
  uVar6 = uVar10 * 0x18;
  if (uVar10 < 0xaaaaaab) {
    uVar10 = uVar6;
    if (0xfff < uVar6) goto LAB_006e0eda;
    if (uVar6 == 0) {
      uVar10 = 0;
    }
    else {
      uVar10 = FUN_01674e20(uVar6);
    }
  }
  else {
    uVar10 = 0xffffffff;
LAB_006e0eda:
    uVar4 = uVar10 + 0x23;
    if (uVar4 <= uVar10) {
      uVar4 = 0xffffffff;
    }
    iVar5 = FUN_01674e20(uVar4);
    if (iVar5 == 0) goto LAB_006e1026;
    uVar10 = iVar5 + 0x23U & 0xffffffe0;
    *(int *)(uVar10 - 4) = iVar5;
  }
  iVar5 = ((int)(param_2 - uVar7) / 0x18) * 0x18;
  uVar2 = *param_5;
  uVar3 = *param_4;
  *(undefined4 *)(iVar5 + uVar10) = 0;
  *(undefined4 *)(iVar5 + 4 + uVar10) = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar5 + uVar10) = *param_3;
  *(undefined4 *)(iVar5 + 4 + uVar10) = param_3[1];
  *(undefined4 *)(iVar5 + 8 + uVar10) = uVar3;
  *(undefined4 *)(iVar5 + 0xc + uVar10) = uVar2;
  *(undefined4 *)(iVar5 + 0x10 + uVar10) = 0;
  *(undefined4 *)(iVar5 + 0x14 + uVar10) = 0;
  uVar4 = param_1[1];
  uVar7 = *param_1;
  uVar8 = uVar10;
  if (param_2 != uVar4) {
    FUN_006e1280(uVar7,param_2,uVar10,param_1);
    uVar4 = param_1[1];
    uVar8 = iVar5 + 0x18 + uVar10;
    uVar7 = param_2;
  }
  FUN_006e1280(uVar7,uVar4,uVar8,param_1);
  if (*param_1 != 0) {
    FUN_006e0dc0(*param_1,param_1[1],param_1);
    uVar7 = *param_1;
    uVar8 = ((int)(param_1[2] - uVar7) / 0x18) * 0x18;
    uVar4 = uVar7;
    if (0xfff < uVar8) {
      uVar4 = *(uint *)(uVar7 - 4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (uVar7 - uVar4) - 4) {
LAB_006e1026:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar8);
  }
  *param_1 = uVar10;
  param_1[1] = uVar10 + uVar9 * 0x18;
  param_1[2] = uVar6 + uVar10;
  return *param_1 + iVar5;
}



/* FUNCTION 9402 ; VA 0x006e1040 ; FUN_006e1040 */

void __thiscall FUN_006e1040(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a9280;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedStreamDataInfoItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9403 ; VA 0x006e10ae ; Catch_All@006e10ae */

void Catch_All_006e10ae(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9404 ; VA 0x006e10d0 ; FUN_006e10d0 */

void __thiscall FUN_006e10d0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a9290;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedStreamDataItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9405 ; VA 0x006e113e ; Catch_All@006e113e */

void Catch_All_006e113e(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9406 ; VA 0x006e1160 ; FUN_006e1160 */

void __thiscall FUN_006e1160(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a92a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedStreamPrefetchDataInfoItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9407 ; VA 0x006e11ce ; Catch_All@006e11ce */

void Catch_All_006e11ce(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9408 ; VA 0x006e11f0 ; FUN_006e11f0 */

void __thiscall FUN_006e11f0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a92b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Network::DeserializedStreamPrefetchRequestItem>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9409 ; VA 0x006e125e ; Catch_All@006e125e */

void Catch_All_006e125e(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9410 ; VA 0x006e1280 ; FUN_006e1280 */

int * FUN_006e1280(int *param_1,int *param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  
  if (param_1 != param_2) {
    piVar3 = param_3 + 5;
    iVar4 = (int)param_3 - (int)param_1;
    piVar2 = param_1 + 1;
    do {
      *param_3 = 0;
      *(undefined4 *)(iVar4 + (int)piVar2) = 0;
      if (*piVar2 != 0) {
        LOCK();
        piVar1 = (int *)(*piVar2 + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      *param_3 = piVar2[-1];
      param_3 = param_3 + 6;
      *(int *)(iVar4 + (int)piVar2) = *piVar2;
      piVar3[-3] = piVar2[1];
      piVar3[-2] = piVar2[2];
      piVar3[-1] = 0;
      *piVar3 = 0;
      piVar3[-1] = piVar2[3];
      *piVar3 = piVar2[4];
      piVar3 = piVar3 + 6;
      piVar2[3] = 0;
      piVar2[4] = 0;
      piVar1 = piVar2 + 5;
      piVar2 = piVar2 + 6;
    } while (piVar1 != param_2);
  }
  FUN_006e0dc0(param_3,param_3,param_4);
  return param_3;
}



/* FUNCTION 9411 ; VA 0x006e1320 ; FUN_006e1320 */

undefined4 * __thiscall FUN_006e1320(byte *param_1,undefined4 *param_2,uint *param_3,int *param_4)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a92c8;
  pvStack_10 = ExceptionList;
  uVar7 = (*param_3 >> 3) + *param_3;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_3,uVar7,param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_3 == (uint *)0x0) {
    uStack_8 = 0;
    piVar4 = (int *)FUN_01674e20(0xc);
    *piVar4 = 0;
    piVar4[1] = 0;
    piVar4[2] = 0;
    piVar4[2] = *param_4;
    uVar1 = *(uint *)(param_1 + 8);
    uVar5 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005d6bb0(uVar5);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar5) {
      param_3 = (uint *)0x1;
      uVar8 = uVar1 >> 1;
      if ((uVar1 >> 1) + uVar1 <= uVar5) {
        uVar8 = 1;
      }
      iVar6 = FUN_005d6bb0(uVar8 + uVar1);
      if (iVar6 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar6);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar9;
        while (puVar2 != (undefined4 *)0x0) {
          piVar3 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar3 = (int)puVar9;
            puVar9 = puVar2;
          }
          else {
            *puVar9 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar3;
            *(undefined4 **)*piVar3 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar9;
        }
      }
    }
    piVar4[1] = uVar7;
    uVar7 = uVar7 % *(uint *)(param_1 + 4);
    piVar3 = *(int **)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (piVar3 == (int *)0x0) {
      piVar3 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar3 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar3 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar4;
      }
      *puVar9 = piVar3;
      *piVar4 = *piVar3;
      *piVar3 = (int)piVar4;
    }
    else {
      *piVar4 = *piVar3;
      *(int **)*puVar9 = piVar4;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *param_2 = piVar4;
    *(undefined *)(param_2 + 1) = 1;
    ExceptionList = pvStack_10;
    return param_2;
  }
  *param_2 = param_3;
  *(undefined *)(param_2 + 1) = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9412 ; VA 0x006e14e0 ; FUN_006e14e0 */

undefined4 * __thiscall FUN_006e14e0(byte *param_1,undefined4 *param_2,uint *param_3,int *param_4)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a92e8;
  pvStack_10 = ExceptionList;
  uVar7 = (*param_3 >> 3) + *param_3;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_3,uVar7,param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_3 == (uint *)0x0) {
    uStack_8 = 0;
    piVar4 = (int *)FUN_01674e20(0xc);
    *piVar4 = 0;
    piVar4[1] = 0;
    piVar4[2] = 0;
    piVar4[2] = *param_4;
    uVar1 = *(uint *)(param_1 + 8);
    uVar5 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005d6bb0(uVar5);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar5) {
      param_3 = (uint *)0x1;
      uVar8 = uVar1 >> 1;
      if ((uVar1 >> 1) + uVar1 <= uVar5) {
        uVar8 = 1;
      }
      iVar6 = FUN_005d6bb0(uVar8 + uVar1);
      if (iVar6 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar6);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar9;
        while (puVar2 != (undefined4 *)0x0) {
          piVar3 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar3 = (int)puVar9;
            puVar9 = puVar2;
          }
          else {
            *puVar9 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar3;
            *(undefined4 **)*piVar3 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar9;
        }
      }
    }
    piVar4[1] = uVar7;
    uVar7 = uVar7 % *(uint *)(param_1 + 4);
    piVar3 = *(int **)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (piVar3 == (int *)0x0) {
      piVar3 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar3 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar3 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar4;
      }
      *puVar9 = piVar3;
      *piVar4 = *piVar3;
      *piVar3 = (int)piVar4;
    }
    else {
      *piVar4 = *piVar3;
      *(int **)*puVar9 = piVar4;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *param_2 = piVar4;
    *(undefined *)(param_2 + 1) = 1;
    ExceptionList = pvStack_10;
    return param_2;
  }
  *param_2 = param_3;
  *(undefined *)(param_2 + 1) = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9413 ; VA 0x006e16a0 ; FUN_006e16a0 */

int FUN_006e16a0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00aff8c0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1;
    }
  }
  return 0;
}



/* FUNCTION 9414 ; VA 0x006e16e0 ; FUN_006e16e0 */

void __thiscall FUN_006e16e0(int param_1,undefined4 *param_2,uint param_3,int *param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  
  uVar3 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar2 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar2 = (int *)0x0;
    }
    else {
      piVar2 = (int *)*puVar1;
    }
    if (piVar2 != (int *)0x0) {
      do {
        if (param_3 == piVar2[1]) {
          if (((*param_4 == piVar2[2]) && (param_4[1] == piVar2[3])) && (param_4[2] == piVar2[4]))
          break;
        }
        else if ((uint)piVar2[1] % *(uint *)(param_1 + 4) != uVar3) {
          *param_2 = 0;
          return;
        }
        piVar2 = (int *)*piVar2;
        if (piVar2 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar2;
  return;
}



/* FUNCTION 9415 ; VA 0x006e1780 ; FUN_006e1780 */

void * __thiscall FUN_006e1780(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  void *pvVar4;
  int *piVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a0698;
  puVar6 = *(undefined4 **)(param_1 + 0x2c);
  pvVar4 = ExceptionList;
  if (puVar6 != (undefined4 *)0x0) {
    piVar5 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar5 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
      piVar5 = *(int **)(param_1 + 0x30);
      puVar6 = *(undefined4 **)(param_1 + 0x2c);
    }
    puVar3 = (undefined4 *)puVar6[1];
    puVar6 = (undefined4 *)*puVar6;
    uStack_8 = 0;
    pvVar4 = pvStack_10;
    for (; puVar6 != puVar3; puVar6 = puVar6 + 2) {
      FUN_006e7be0(*puVar6);
      pvVar4 = (void *)FUN_006e1780(param_2);
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar1 = piVar5 + 1;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)*piVar5)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar4 = (void *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 9416 ; VA 0x006e1830 ; FUN_006e1830 */

void * __thiscall FUN_006e1830(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvVar4;
  int *piVar5;
  undefined4 *puVar6;
  int *piVar7;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a9308;
  puVar6 = *(undefined4 **)(param_1 + 0x2c);
  pvVar4 = ExceptionList;
  if (puVar6 != (undefined4 *)0x0) {
    piVar5 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar5 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
      piVar5 = *(int **)(param_1 + 0x30);
      puVar6 = *(undefined4 **)(param_1 + 0x2c);
    }
    piVar1 = (int *)puVar6[1];
    piVar7 = (int *)*puVar6;
    uStack_8 = 0;
    pvVar4 = pvStack_10;
    for (; piVar7 != piVar1; piVar7 = piVar7 + 2) {
      iStack_14 = *piVar7;
      if ((iStack_14 != 0) &&
         (iVar2 = *(int *)(iStack_14 + 0xc), iVar3 = FUN_00aff8c0(),
         (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
         (uint)*(ushort *)(iVar3 + 0x1da))) {
        FUN_006e5160(&iStack_14);
        FUN_006e5160(&iStack_14);
      }
      pvVar4 = (void *)FUN_006e1830(param_2);
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar1 = piVar5 + 1;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)*piVar5)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar4 = (void *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 9417 ; VA 0x006e1930 ; FUN_006e1930 */

void * __thiscall FUN_006e1930(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  code *pcVar5;
  int iVar6;
  void *pvVar7;
  int *piVar8;
  int *piVar9;
  undefined4 *puVar10;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a4510;
  puVar10 = *(undefined4 **)(param_1 + 0x2c);
  pvVar7 = ExceptionList;
  if (puVar10 != (undefined4 *)0x0) {
    piVar8 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar8 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
      piVar8 = *(int **)(param_1 + 0x30);
      puVar10 = *(undefined4 **)(param_1 + 0x2c);
    }
    puVar1 = (undefined4 *)puVar10[1];
    puVar10 = (undefined4 *)*puVar10;
    iStack_8 = 0;
    pvVar7 = pvStack_10;
    for (; puVar10 != puVar1; puVar10 = puVar10 + 2) {
      piVar9 = (int *)puVar10[1];
      uVar2 = param_2[3];
      uVar3 = param_2[4];
      if (piVar9 != (int *)0x0) {
        LOCK();
        piVar9[1] = piVar9[1] + 1;
        UNLOCK();
        piVar9 = (int *)puVar10[1];
      }
      uVar4 = *puVar10;
      pcVar5 = (code *)*param_2;
      iStack_8._1_3_ = (uint3)((uint)iStack_8 >> 8);
      iStack_8._0_1_ = 1;
      if (piVar9 != (int *)0x0) {
        LOCK();
        piVar9[1] = piVar9[1] + 1;
        UNLOCK();
      }
      (*pcVar5)(uVar4,piVar9,uVar2,uVar3);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar9 != (int *)0x0) {
        LOCK();
        iVar6 = piVar9[1] + -1;
        piVar9[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar9)();
          LOCK();
          iVar6 = piVar9[2] + -1;
          piVar9[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
      pvVar7 = (void *)FUN_006e1930(param_2);
    }
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar9 = piVar8 + 1;
      iVar6 = *piVar9;
      pvVar7 = (void *)*piVar9;
      *piVar9 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        pvVar7 = (void *)(**(code **)*piVar8)();
        LOCK();
        piVar9 = piVar8 + 2;
        iVar6 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          pvVar7 = (void *)(**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar7;
}



/* FUNCTION 9418 ; VA 0x006e1a80 ; FUN_006e1a80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_006e1a80(undefined4 *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  double *pdVar4;
  int *piVar5;
  double dVar6;
  double in_stack_00000014;
  uint in_stack_0000001c;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined8 in_stack_00000034;
  int *in_stack_0000003c;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a935c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uStack_30 = 0x7fffffff;
  param_1[3] = 0;
  param_1[4] = &DAT_c61c4000;
  param_1[5] = 0;
  *(undefined8 *)(param_1 + 6) = 0x7fffffff7fffffff;
  param_1[8] = 0x7fffffff;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0x7fff;
  param_1[0xd] = 1;
  param_1[0xe] = 1;
  param_1[0xf] = 0;
  *(undefined *)(param_1 + 0x10) = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  *(undefined2 *)(param_1 + 0x14) = 0x100;
  param_1[0x15] = in_stack_0000003c;
  param_1[0x17] = param_2;
  puStack_18 = param_1;
  puStack_14 = param_1;
  iVar1 = FUN_005c3ac0(param_2);
  param_1[0x16] = iVar1;
  if (iVar1 != 0) {
    iVar1 = (int)(*(int *)(iVar1 + 0x308) + (*(int *)(iVar1 + 0x308) >> 0x1f & 0x3fU)) >> 6;
    if (DAT_01d62d8c == '\0') {
      if (iVar1 < 2) {
        iVar1 = 1;
      }
      else if (0x7ffe < iVar1) {
        iVar1 = 0x7fff;
      }
    }
    param_1[0xd] = iVar1;
    param_1[0xe] = iVar1;
  }
  *(undefined8 *)(param_1 + 0x18) = 0;
  uStack_8._0_1_ = 2;
  param_1[0x1a] = 0;
  if (in_stack_0000001c != 0) {
    param_1[0x1a] = in_stack_0000001c;
    if ((in_stack_0000001c & 1) == 0) {
      (**(code **)(in_stack_0000001c & 0xfffffffe))(&stack0x00000024,param_1 + 0x1c,0);
    }
    else {
      param_1[0x1c] = in_stack_00000024;
      param_1[0x1d] = in_stack_00000028;
      param_1[0x1e] = in_stack_0000002c;
      param_1[0x1f] = in_stack_00000030;
      *(undefined8 *)(param_1 + 0x20) = in_stack_00000034;
    }
  }
  param_1[0x22] = in_stack_0000003c;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  uStack_8._0_1_ = 4;
  FUN_006e7f60(&stack0x00000008,1);
  in_stack_0000003c = (int *)FUN_0061f420(&uStack_30);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if ((*in_stack_0000003c == 0) ||
     (iVar1 = *(int *)(*in_stack_0000003c + 0xc), iVar2 = FUN_00913630(),
     (uint)*(ushort *)(iVar2 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) {
    piStack_1c = (int *)0x0;
    puVar3 = &uStack_20;
    piVar5 = (int *)&DAT_00000006;
    param_2 = 0;
  }
  else {
    piStack_24 = (int *)in_stack_0000003c[1];
    param_2 = *in_stack_0000003c;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[1] = piStack_24[1] + 1;
      UNLOCK();
      piStack_24 = (int *)in_stack_0000003c[1];
    }
    piVar5 = (int *)&DAT_00000005;
    puVar3 = &uStack_28;
  }
  puStack_14 = (undefined4 *)puVar3[1];
  *puVar3 = 0;
  puVar3[1] = 0;
  if ((((uint)piVar5 & 2) != 0) &&
     (in_stack_0000003c = (int *)((uint)piVar5 & 0xfffffffd), piVar5 = in_stack_0000003c,
     piStack_1c != (int *)0x0)) {
    LOCK();
    iVar1 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar1 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar1;
      UNLOCK();
      piVar5 = in_stack_0000003c;
      if (iVar1 == 0) {
        (**(code **)(*piStack_1c + 4))();
        piVar5 = in_stack_0000003c;
      }
    }
  }
  if ((((uint)piVar5 & 1) != 0) && (piStack_24 != (int *)0x0)) {
    LOCK();
    iVar1 = piStack_24[1] + -1;
    piStack_24[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar1 = piStack_24[2] + -1;
      piStack_24[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  param_1[0x23] = param_2;
  in_stack_0000003c = (int *)param_1[0x24];
  param_1[0x24] = puStack_14;
  if (in_stack_0000003c != (int *)0x0) {
    LOCK();
    iVar1 = in_stack_0000003c[1] + -1;
    in_stack_0000003c[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*in_stack_0000003c)();
      LOCK();
      iVar1 = in_stack_0000003c[2] + -1;
      in_stack_0000003c[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*in_stack_0000003c + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  in_stack_0000003c = piStack_2c;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar1 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar5 = in_stack_0000003c + 2;
      iVar1 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*in_stack_0000003c + 4))();
      }
    }
  }
  dVar6 = DAT_018c45c8;
  if (_PTR_018c6f48 < in_stack_00000014) {
    pdVar4 = (double *)FUN_01682800(&uStack_30);
    dVar6 = *pdVar4 + in_stack_00000014;
  }
  *(double *)(param_1 + 0x18) = dVar6;
  uStack_8 = 6;
  if (((in_stack_0000001c != 0) && ((in_stack_0000001c & 1) == 0)) &&
     (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000001c & 0xfffffffe))(&stack0x00000024,&stack0x00000024,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9419 ; VA 0x006e1de0 ; FUN_006e1de0 */

undefined4 * __thiscall
FUN_006e1de0(undefined4 *param_1,undefined4 param_2,undefined8 *param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int aiStack_34 [5];
  uint uStack_20;
  undefined auStack_1c [8];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a93a4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_006b1a30(param_2);
  *param_1 = RBX::Network::Replicator::JoinDataItem::vftable;
  uStack_8 = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  uVar3 = FUN_00616d10(0,0);
  param_1[0xc] = uVar3;
  uStack_8._0_1_ = 1;
  param_1[0xe] = 0xffffffff;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  FUN_006ab2f0(0);
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0xf;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  *(undefined *)(param_1 + 0x24) = 0;
  FUN_005542c0("JoinDataItem",0xc);
  *(undefined *)(param_1 + 0x2a) = 1;
  *param_1 = RBX::Network::Replicator::StreamJob::StreamDataItem::vftable;
  uStack_8 = 4;
  *(undefined8 *)(param_1 + 0x2c) = *param_3;
  param_1[0x2e] = *(undefined4 *)(param_3 + 1);
  param_1[0x2f] = param_4;
  param_1[0x30] = 0;
  *(undefined *)(param_1 + 0x31) = 0;
  if (DAT_01ee4213 == '\0') {
    FUN_005542c0("StreamDataItem",0xe);
  }
  else {
    puVar4 = (undefined4 *)
             FUN_01675640(aiStack_34,"StreamDataItem for (%d,%d,%d)",param_1[0x2c],param_1[0x2d],
                          param_1[0x2e]);
    if (param_1 + 0x24 != puVar4) {
      FUN_005507b0();
      uVar3 = puVar4[1];
      uVar1 = puVar4[2];
      uVar2 = puVar4[3];
      param_1[0x24] = *puVar4;
      param_1[0x25] = uVar3;
      param_1[0x26] = uVar1;
      param_1[0x27] = uVar2;
      *(undefined8 *)(param_1 + 0x28) = *(undefined8 *)(puVar4 + 4);
      puVar4[4] = 0;
      puVar4[5] = 0xf;
      *(undefined *)puVar4 = 0;
    }
    if (0xf < uStack_20) {
      uVar6 = uStack_20 + 1;
      iVar5 = aiStack_34[0];
      if (0xfff < uVar6) {
        iVar5 = *(int *)(aiStack_34[0] + -4);
        uVar6 = uStack_20 + 0x24;
        if (0x1f < (aiStack_34[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar6);
    }
  }
  puVar4 = (undefined4 *)FUN_016830f0(auStack_1c);
  param_1[10] = *puVar4;
  param_1[0xb] = puVar4[1];
  *(undefined *)(param_1 + 0x2a) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9420 ; VA 0x006e2000 ; FUN_006e2000 */

undefined4 * __thiscall FUN_006e2000(undefined4 *param_1,undefined4 param_2)

{
  undefined8 uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a946b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00610b20("Replicator StreamData",param_2,4,8);
  param_1[0x4c] = RBX::Network::StreamingInterface::vftable;
  *param_1 = RBX::Network::Replicator::StreamJob::vftable;
  param_1[0x4c] = RBX::Network::Replicator::StreamJob::vftable;
  uStack_8 = 0;
  *(undefined *)(param_1 + 0x4d) = 0;
  uVar2 = FUN_00588320(0xb);
  param_1[0x4e] = uVar2;
  param_1[0x4f] = 0;
  param_1[0x50] = 0x3f800000;
  param_1[0x51] = 0;
  param_1[0x52] = 0;
  param_1[0x53] = 0;
  param_1[0x54] = 0;
  param_1[0x55] = 0;
  param_1[0x56] = param_1 + 0x107c0056;
  param_1[0x57] = 2;
  param_1[0x58] = 0;
  param_1[0x59] = 0;
  param_1[0x5a] = 0;
  param_1[0x5b] = 0;
  param_1[0x5c] = 0;
  param_1[0x5d] = 0;
  param_1[0x5e] = 0;
  param_1[0x5f] = &DAT_c61c4000;
  param_1[0x60] = 0;
  *(undefined8 *)(param_1 + 0x61) = 0x7fffffff7fffffff;
  param_1[99] = 0x7fffffff;
  param_1[100] = 0;
  param_1[0x65] = 0;
  param_1[0x66] = 0;
  param_1[0x67] = 0x7fff;
  param_1[0x68] = DAT_01d5b8ac;
  param_1[0x69] = 1;
  param_1[0x6a] = 0;
  *(undefined *)(param_1 + 0x6b) = 0;
  param_1[0x6c] = 0;
  param_1[0x6d] = 0;
  param_1[0x6e] = 0;
  uStack_8._0_1_ = 3;
  *(undefined2 *)(param_1 + 0x6f) = 0;
  param_1[0x70] = 0;
  param_1[0x72] = param_2;
  iVar3 = FUN_005c3ac0(param_2);
  param_1[0x71] = iVar3;
  if (iVar3 != 0) {
    iVar4 = *(int *)(iVar3 + 0x308);
    uVar5 = iVar4 >> 0x1f & 0x3f;
    if (DAT_01d62d8c == '\0') {
      iVar4 = (int)(uVar5 + iVar4) >> 6;
      if (iVar4 < 2) {
        iVar4 = 1;
      }
      else if (0x7ffe < iVar4) {
        iVar4 = 0x7fff;
      }
      param_1[0x69] = iVar4;
      iVar3 = (int)(*(int *)(iVar3 + 0x304) + (*(int *)(iVar3 + 0x304) >> 0x1f & 0x3fU)) >> 6;
      if ((iVar4 < iVar3) && (iVar4 = iVar3, 0x7ffe < iVar3)) {
        iVar4 = 0x7fff;
      }
      param_1[0x68] = iVar4;
    }
    else {
      param_1[0x69] = (int)(iVar4 + uVar5) >> 6;
      param_1[0x68] =
           (int)(*(int *)(iVar3 + 0x304) + (*(int *)(iVar3 + 0x304) >> 0x1f & 0x3fU)) >> 6;
    }
  }
  uStack_8._0_1_ = 4;
  param_1[0x73] = 0;
  param_1[0x74] = 0;
  uVar2 = FUN_006e3070(0,0);
  param_1[0x73] = uVar2;
  *(undefined *)(param_1 + 0x75) = 0;
  param_1[0x76] = 0;
  param_1[0x77] = 0;
  param_1[0x78] = 0;
  param_1[0x79] = DAT_01d5b8a4;
  uStack_8._0_1_ = 5;
  FUN_01682800(param_1 + 0x7a);
  param_1[0x7c] = 0;
  *(undefined *)(param_1 + 0x7d) = 0;
  uVar2 = FUN_00588320(0xb);
  param_1[0x7e] = uVar2;
  param_1[0x7f] = 0;
  param_1[0x80] = 0x3f800000;
  param_1[0x81] = 0;
  param_1[0x82] = 0;
  *(undefined *)(param_1 + 0x83) = 0;
  uVar2 = FUN_00588320(0xb);
  param_1[0x84] = uVar2;
  param_1[0x85] = 0;
  param_1[0x86] = 0x3f800000;
  param_1[0x87] = 0;
  param_1[0x88] = 0;
  *(undefined *)(param_1 + 0x89) = 0;
  uVar2 = FUN_00588320(0xb);
  param_1[0x8a] = uVar2;
  param_1[0x8b] = 0;
  param_1[0x8c] = 0x3f800000;
  param_1[0x8d] = 0;
  param_1[0x8e] = 0;
  *(undefined *)(param_1 + 0x8f) = 0;
  uVar2 = FUN_00588320(0xb);
  param_1[0x90] = uVar2;
  param_1[0x91] = 0;
  param_1[0x92] = 0x3f800000;
  param_1[0x93] = 0;
  param_1[0x94] = 0;
  *(undefined *)(param_1 + 0x95) = 0;
  uVar2 = FUN_00588320(0xb);
  param_1[0x96] = uVar2;
  param_1[0x97] = 0;
  param_1[0x98] = 0x3f800000;
  param_1[0x99] = 0;
  param_1[0x9a] = 0;
  *(undefined *)(param_1 + 0x9b) = 0;
  uVar2 = FUN_00588320(0xb);
  param_1[0x9c] = uVar2;
  param_1[0x9d] = 0;
  param_1[0x9e] = 0x3f800000;
  param_1[0x9f] = 0;
  param_1[0xa0] = 0;
  *(undefined *)(param_1 + 0xa1) = 0;
  uVar2 = FUN_00588320(0xb);
  param_1[0xa2] = uVar2;
  param_1[0xa3] = 0;
  param_1[0xa4] = 0x3f800000;
  param_1[0xa5] = 0;
  param_1[0xa6] = 0;
  param_1[0xa7] = 0;
  param_1[0xa8] = 0;
  param_1[0xa9] = 0;
  param_1[0xaa] = 0;
  param_1[0xab] = 0;
  param_1[0xac] = 0;
  param_1[0xad] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  FUN_016827a0(param_1 + 0xae);
  uVar1 = DAT_018ce300;
  *(undefined *)(param_1 + 0xb0) = 1;
  *(undefined8 *)(param_1 + 0xb2) = uVar1;
  param_1[0xb4] = 0;
  param_1[0xb5] = 0;
  param_1[0xb6] = 0;
  param_1[0xb7] = 0;
  *(undefined *)(param_1 + 0xba) = 1;
  *(undefined8 *)(param_1 + 0xb8) = 0;
  param_1[0xbc] = 0;
  *(undefined8 *)(param_1 + 0xbe) = uVar1;
  param_1[0xc0] = 0;
  param_1[0xc2] = 0;
  param_1[0xc3] = 0;
  param_1[0xc4] = 0;
  param_1[0xc5] = 0;
  *(undefined *)(param_1 + 0xc6) = 1;
  *(undefined8 *)(param_1 + 200) = uVar1;
  param_1[0xca] = 0;
  param_1[0xcc] = 0;
  param_1[0xcd] = 0;
  param_1[0xce] = 0;
  param_1[0xcf] = 0;
  *(undefined *)(param_1 + 0xd0) = 1;
  param_1[0xd2] = 0;
  param_1[0xd3] = 0;
  param_1[0xd4] = 0;
  param_1[0xd5] = 0;
  param_1[0xd6] = 0x1fffffff;
  param_1[0xd7] = 0x1fffffff;
  param_1[0xd8] = 0x1fffffff;
  param_1[0xd9] = 0x1fffffff;
  param_1[0xda] = 0x1fffffff;
  param_1[0xdb] = 0x1fffffff;
  param_1[0xdc] = 0xffffffff;
  *(undefined8 *)(param_1 + 0xde) = 0;
  param_1[0xe0] = 0;
  *(undefined8 *)(param_1 + 0xe2) = 0;
  param_1[0xe4] = 0;
  param_1[0xe6] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9421 ; VA 0x006e25a0 ; FUN_006e25a0 */

undefined4 * __thiscall
FUN_006e25a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined8 *param_4,
            undefined param_5,undefined4 param_6)

{
  FUN_006b1a30(param_2);
  param_1[0xc] = param_3;
  *param_1 = RBX::Network::Replicator::StreamJob::StreamTerrainItem::vftable;
  *(undefined8 *)(param_1 + 0xd) = *param_4;
  param_1[0xf] = *(undefined4 *)(param_4 + 1);
  *(undefined *)(param_1 + 0x10) = param_5;
  param_1[0x11] = param_6;
  return param_1;
}



/* FUNCTION 9422 ; VA 0x006e25f0 ; FUN_006e25f0 */

void __fastcall FUN_006e25f0(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar4 = (int *)*param_1;
  piVar5 = (int *)*piVar4;
  ExceptionList = &pvStack_10;
  *piVar4 = (int)piVar4;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar4 = (int *)*param_1;
  if (piVar5 != piVar4) {
    do {
      piVar4 = (int *)piVar5[0x26];
      piVar1 = (int *)*piVar5;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar3 = piVar4[1] + -1;
        piVar4[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar3 = piVar4[2] + -1;
          piVar4[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      uVar2 = piVar5[0x1c];
      uStack_8 = 0;
      if (uVar2 != 0) {
        if ((uVar2 & 1) == 0) {
          if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
            (**(code **)(uVar2 & 0xfffffffe))(piVar5 + 0x1e,piVar5 + 0x1e,2);
          }
        }
        piVar5[0x1c] = 0;
      }
      piVar4 = (int *)piVar5[0xc];
      uStack_8 = 0xffffffff;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar3 = piVar4[2] + -1;
        piVar4[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
      FUN_01674ea0(piVar5,0xa0);
      piVar4 = (int *)*param_1;
      piVar5 = piVar1;
    } while (piVar1 != piVar4);
  }
  FUN_01674ea0(piVar4,0xa0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9423 ; VA 0x006e26f0 ; FUN_006e26f0 */

void __fastcall FUN_006e26f0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_006e27a0();
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,0x24);
  }
  return;
}



/* FUNCTION 9424 ; VA 0x006e2720 ; FUN_006e2720 */

void __fastcall FUN_006e2720(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_006e4ea0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 9425 ; VA 0x006e27a0 ; FUN_006e27a0 */

void __fastcall FUN_006e27a0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar3;
        FUN_01674ea0(puVar3,0xc);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar3 = (undefined4 *)*puVar1;
      } while (puVar3 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 9426 ; VA 0x006e2820 ; FUN_006e2820 */

void __fastcall FUN_006e2820(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_006e4ea0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 9427 ; VA 0x006e2830 ; FUN_006e2830 */

void __fastcall FUN_006e2830(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar3;
        FUN_01674ea0(puVar3,0xc);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar3 = (undefined4 *)*puVar1;
      } while (puVar3 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 9428 ; VA 0x006e2840 ; FUN_006e2840 */

void __fastcall FUN_006e2840(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_006e0dc0(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x18) * 0x18;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 9429 ; VA 0x006e28c0 ; FUN_006e28c0 */

void __fastcall FUN_006e28c0(int param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0x28);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
                    /* WARNING: Could not recover jumptable at 0x006e28d3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar1 + 4))();
      return;
    }
  }
  return;
}



/* FUNCTION 9430 ; VA 0x006e28e0 ; FUN_006e28e0 */

uint __thiscall FUN_006e28e0(uint *param_1,uint *param_2)

{
  uint uVar1;
  
  uVar1 = *param_1;
  if (((uVar1 == *param_2) && (uVar1 = param_1[1], uVar1 == param_2[1])) &&
     (uVar1 = param_1[2], uVar1 == param_2[2])) {
    return CONCAT31((int3)(uVar1 >> 8),1);
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 9431 ; VA 0x006e2910 ; FUN_006e2910 */

undefined __thiscall FUN_006e2910(float *param_1,float *param_2)

{
  if ((((NAN(*param_1) || NAN(*param_2)) != (*param_1 == *param_2)) &&
      ((NAN(param_1[1]) || NAN(param_2[1])) != (param_1[1] == param_2[1]))) &&
     ((NAN(param_1[2]) || NAN(param_2[2])) != (param_1[2] == param_2[2]))) {
    return 0;
  }
  return 1;
}



/* FUNCTION 9432 ; VA 0x006e2950 ; FUN_006e2950 */

int * __thiscall FUN_006e2950(byte *param_1,undefined8 *param_2)

{
  undefined8 uVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined8 *puVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  int *piVar10;
  undefined4 *puVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar4 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9488;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_00ca2680(param_2);
  FUN_006e16e0(&param_2,uVar5,puVar4,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (undefined8 *)0x0) {
    uVar1 = *puVar4;
    iVar8 = *(int *)(puVar4 + 1);
    uStack_8 = 0;
    piVar6 = (int *)FUN_01674e20(0x18);
    *piVar6 = 0;
    piVar6[1] = 0;
    piVar6[5] = 0;
    *(undefined8 *)(piVar6 + 2) = uVar1;
    piVar6[4] = iVar8;
    if (piVar6 + 5 != (int *)0x0) {
      piVar6[5] = 0;
    }
    uVar2 = *(uint *)(param_1 + 8);
    uVar7 = uVar2 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar7 = FUN_005d6bb0(uVar7);
      if (uVar7 <= *(uint *)(param_1 + 4)) {
        uVar7 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar7);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar7) {
      param_2 = (undefined8 *)0x1;
      uVar9 = uVar2 >> 1;
      if ((uVar2 >> 1) + uVar2 <= uVar7) {
        uVar9 = 1;
      }
      iVar8 = FUN_005d6bb0(uVar9 + uVar2);
      if (iVar8 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar8);
        puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar3 = (undefined4 *)*puVar11;
        while (puVar3 != (undefined4 *)0x0) {
          piVar10 = (int *)(*(int *)(param_1 + 0x14) +
                           ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4);
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar10 = (int)puVar11;
            puVar11 = puVar3;
          }
          else {
            *puVar11 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar10;
            *(undefined4 **)*piVar10 = puVar3;
          }
          puVar3 = (undefined4 *)*puVar11;
        }
      }
    }
    piVar6[1] = uVar5;
    uVar5 = uVar5 % *(uint *)(param_1 + 4);
    piVar10 = *(int **)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    if (piVar10 == (int *)0x0) {
      piVar10 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar10 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar10 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar6;
      }
      *puVar11 = piVar10;
      *piVar6 = *piVar10;
    }
    else {
      *piVar6 = *piVar10;
      piVar10 = (int *)*puVar11;
    }
    *piVar10 = (int)piVar6;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar6 + 2;
  }
  ExceptionList = pvStack_10;
  return (int *)(param_2 + 1);
}



/* FUNCTION 9433 ; VA 0x006e2b20 ; FUN_006e2b20 */

uint * __thiscall FUN_006e2b20(byte *param_1,uint *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a94a8;
  pvStack_10 = ExceptionList;
  uVar5 = *param_2;
  uVar8 = (uVar5 >> 3) + uVar5;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_2,uVar8,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (uint *)0x0) {
    uStack_8 = 0;
    piVar3 = (int *)FUN_01674e20(0x24);
    *piVar3 = 0;
    piVar3[1] = 0;
    piVar3[3] = 0;
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[6] = 0;
    piVar3[7] = 0;
    piVar3[8] = 0;
    piVar3[2] = uVar5;
    *(undefined *)(piVar3 + 3) = 0;
    iVar4 = FUN_00588320(0xb);
    piVar3[4] = iVar4;
    piVar3[5] = 0;
    piVar3[6] = 0x3f800000;
    piVar3[7] = 0;
    piVar3[8] = 0;
    uVar1 = *(uint *)(param_1 + 8);
    uVar5 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005d6bb0(uVar5);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar5) {
      param_2 = (uint *)0x1;
      uVar6 = uVar1 >> 1;
      if (uVar1 + (uVar1 >> 1) <= uVar5) {
        uVar6 = 1;
      }
      iVar4 = FUN_005d6bb0(uVar6 + uVar1);
      if (iVar4 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar4);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar9;
        while (puVar2 != (undefined4 *)0x0) {
          piVar7 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar7 = (int)puVar9;
            puVar9 = puVar2;
          }
          else {
            *puVar9 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar7;
            *(undefined4 **)*piVar7 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar9;
        }
      }
    }
    piVar3[1] = uVar8;
    uVar8 = uVar8 % *(uint *)(param_1 + 4);
    piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (piVar7 == (int *)0x0) {
      piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar7 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar3;
      }
      *puVar9 = piVar7;
      *piVar3 = *piVar7;
    }
    else {
      *piVar3 = *piVar7;
      piVar7 = (int *)*puVar9;
    }
    *piVar7 = (int)piVar3;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return (uint *)(piVar3 + 2);
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 9434 ; VA 0x006e2d20 ; FUN_006e2d20 */

void __thiscall FUN_006e2d20(float *param_1,float *param_2,float param_3)

{
  *param_2 = *param_1 * param_3;
  param_2[1] = param_1[1] * param_3;
  param_2[2] = param_1[2] * param_3;
  return;
}



/* FUNCTION 9435 ; VA 0x006e2d60 ; FUN_006e2d60 */

undefined4 * __thiscall FUN_006e2d60(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Network::DeserializedItem::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  return param_1;
}



/* FUNCTION 9436 ; VA 0x006e2d90 ; FUN_006e2d90 */

undefined4 * __thiscall FUN_006e2d90(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *param_1 = RBX::Network::DeserializedStreamDataItem::vftable;
  piVar2 = (int *)param_1[8];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *param_1 = RBX::Network::DeserializedItem::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 9437 ; VA 0x006e2df0 ; FUN_006e2df0 */

undefined4 * __thiscall FUN_006e2df0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Network::DeserializedItem::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x24);
  }
  return param_1;
}



/* FUNCTION 9438 ; VA 0x006e2e20 ; FUN_006e2e20 */

undefined4 * __thiscall FUN_006e2e20(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Network::DeserializedItem::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x30);
  }
  return param_1;
}



/* FUNCTION 9439 ; VA 0x006e2e50 ; FUN_006e2e50 */

undefined4 * __thiscall FUN_006e2e50(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Network::Replicator::StreamJob::StreamDataItem::vftable;
  FUN_006c2bb0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,200);
  }
  return param_1;
}



/* FUNCTION 9440 ; VA 0x006e2e80 ; FUN_006e2e80 */

undefined4 * __thiscall FUN_006e2e80(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Network::Replicator::StreamJob::vftable;
  param_1[0x4c] = RBX::Network::Replicator::StreamJob::vftable;
  uStack_8 = 0;
  FUN_01679490();
  iVar4 = param_1[0xad];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  FUN_006e27a0();
  FUN_006e27a0();
  FUN_006e27a0();
  FUN_006e2720();
  FUN_006e27a0();
  FUN_006e27a0();
  FUN_0056d250();
  FUN_006e25f0();
  piVar1 = (int *)param_1[0x65];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[2] + -1;
    piVar1[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_006e2840();
  FUN_006e27a0();
  piVar1 = (int *)param_1[0x4b];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x3a0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9441 ; VA 0x006e2fd0 ; FUN_006e2fd0 */

undefined4 * __thiscall FUN_006e2fd0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Network::Item::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 9442 ; VA 0x006e3000 ; FUN_006e3000 */

undefined4 * __thiscall FUN_006e3000(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Network::Item::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 9443 ; VA 0x006e3030 ; FUN_006e3030 */

undefined4 * __thiscall FUN_006e3030(undefined4 *param_1,uint param_2)

{
  int *piVar1;
  
  *param_1 = RBX::Network::Item::vftable;
  if ((param_2 & 1) != 0) {
    if ((param_2 & 4) == 0) {
      piVar1 = *(int **)param_1[-1];
      param_1[-1] = *piVar1;
      *piVar1 = (int)(param_1 + -1);
      return param_1;
    }
    _guard_check_icall(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 9444 ; VA 0x006e3070 ; FUN_006e3070 */

void FUN_006e3070(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_01674e20(0xa0);
  if (param_1 == 0) {
    *piVar1 = (int)piVar1;
    piVar1[1] = (int)piVar1;
    return;
  }
  *piVar1 = param_1;
  piVar1[1] = param_2;
  return;
}



/* FUNCTION 9445 ; VA 0x006e30a0 ; FUN_006e30a0 */

void __thiscall FUN_006e30a0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_b932aabb98db0a8fac80cb37d05072c8>,bool,class_std::shared_ptr<class_RBX::Instance>_>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 9446 ; VA 0x006e30c0 ; FUN_006e30c0 */

void __thiscall FUN_006e30c0(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_f01493cee41eb905bb82d67a0226f6f5>,bool,class_std::shared_ptr<class_RBX::Instance>_>
             ::vftable;
  *(undefined8 *)(param_2 + 1) = *(undefined8 *)(param_1 + 4);
  param_2[3] = *(undefined4 *)(param_1 + 0xc);
  return;
}



/* FUNCTION 9447 ; VA 0x006e30e0 ; FUN_006e30e0 */

undefined4 FUN_006e30e0(int *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  char cVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a8348;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  piVar3 = (int *)param_1[1];
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  iVar4 = *(int *)(iVar2 + 0xc);
  uStack_8 = 0;
  iVar6 = FUN_00aff8c0();
  if ((uint)*(ushort *)(iVar6 + 0x1da) <
      (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) {
    cVar5 = FUN_006e6340(iVar2);
    if (cVar5 == '\0') {
      piVar1 = piVar3 + 1;
      if (piVar3 != (int *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_006e3980(iVar2,piVar3);
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return 1;
    }
  }
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 9448 ; VA 0x006e3200 ; FUN_006e3200 */

void __thiscall FUN_006e3200(int param_1,undefined4 param_2)

{
  FUN_006e0ca0(param_1 + 4,param_2);
  return;
}



/* FUNCTION 9449 ; VA 0x006e3220 ; FUN_006e3220 */

void FUN_006e3220(int param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar2 = *(int **)(param_1 + 0x98);
  ExceptionList = &pvStack_10;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    ExceptionList = &pvStack_10;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(param_1 + 0x70);
  uStack_8 = 0;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x78,param_1 + 0x78,2);
      }
    }
    *(undefined4 *)(param_1 + 0x70) = 0;
  }
  piVar2 = *(int **)(param_1 + 0x30);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_01674ea0(param_1,0xa0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9450 ; VA 0x006e32d0 ; FUN_006e32d0 */

TypeDescriptor * FUN_006e32d0(void)

{
  return &<lambda_b932aabb98db0a8fac80cb37d05072c8>::RTTI_Type_Descriptor;
}



/* FUNCTION 9451 ; VA 0x006e32e0 ; FUN_006e32e0 */

TypeDescriptor * FUN_006e32e0(void)

{
  return &<lambda_f01493cee41eb905bb82d67a0226f6f5>::RTTI_Type_Descriptor;
}



/* FUNCTION 9452 ; VA 0x006e32f0 ; FUN_006e32f0 */

int FUN_006e32f0(uint param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  uint *puVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  byte *pbVar8;
  uint uVar9;
  uint uStack_6c;
  undefined4 *puStack_68;
  undefined2 uStack_64;
  uint *puStack_60;
  uint *puStack_5c;
  int iStack_58;
  undefined auStack_54 [4];
  int *piStack_50;
  uint uStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  undefined auStack_3c [4];
  uint *puStack_38;
  int iStack_34;
  byte *pbStack_30;
  int iStack_2c;
  int *piStack_28;
  uint uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar9 = param_1;
  puStack_c = &LAB_017a94e0;
  pvStack_10 = ExceptionList;
  puStack_60 = (uint *)0x0;
  puStack_5c = (uint *)0x0;
  iStack_58 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uStack_1c = FUN_008b3830(param_1,&puStack_60);
  puVar4 = (uint *)FUN_0060dcd0(auStack_54,uVar9);
  uStack_4c = *puVar4;
  piVar2 = (int *)puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  piStack_48 = piVar2;
  piStack_28 = piVar2;
  uStack_24 = uStack_4c;
  if (piStack_50 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_50[1] + -1;
    piStack_50[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_50)();
      LOCK();
      iVar7 = piStack_50[2] + -1;
      piStack_50[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piStack_50 + 4))();
      }
    }
  }
  iVar7 = iStack_14;
  iVar5 = FUN_006e3e20(&uStack_4c,param_2);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar2[1] = piVar2[1] + 1;
    UNLOCK();
  }
  iVar6 = FUN_006e3890(uStack_24,piVar2,param_2);
  iVar5 = iVar5 + iVar6;
  iStack_18 = iVar5;
  if (DAT_01d5b9c8 != '\0') {
    FUN_006e2b20(&uStack_1c);
    FUN_006e6200(&uStack_44,&param_1);
    FUN_006e5160(&param_1);
  }
  puStack_38 = puStack_5c;
  if (puStack_60 != puStack_5c) {
    pbVar8 = (byte *)(iVar7 + 0x134);
    puVar4 = puStack_60;
    pbStack_30 = pbVar8;
    do {
      uVar9 = *puVar4;
      if (((DAT_01d5b9c8 != '\0') && (uVar9 != 0)) &&
         (iVar7 = *(int *)(uVar9 + 0xc), iVar6 = FUN_00aff8c0(), iVar5 = iStack_14,
         pbVar8 = pbStack_30,
         (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
         (uint)*(ushort *)(iVar6 + 0x1da))) {
        uStack_24 = uVar9;
        iVar7 = FUN_006e2b20(&uStack_1c);
        param_1 = iVar7 + 4;
        iVar7 = *(byte *)(iVar7 + 4) + 1 + param_1;
        iStack_20 = (uVar9 >> 3) + uVar9;
        FUN_00606ea0(&iStack_2c,iStack_20,&uStack_24,-(uint)(iVar7 != 0) & iVar7 + 1U);
        if (iStack_2c == 0) {
          puStack_68 = (undefined4 *)0x0;
          uStack_6c = -(uint)(param_1 != -3) & param_1 + 4;
          uStack_8._0_1_ = 2;
          uStack_64 = 0;
          puStack_68 = (undefined4 *)FUN_01674e20(0xc);
          uStack_64 = 0x101;
          *puStack_68 = 0;
          puStack_68[1] = 0;
          puStack_68[2] = uVar9;
          FUN_005d99d0(*(int *)(param_1 + 8) + 1);
          FUN_005c5550(auStack_3c,&uStack_6c,iStack_20);
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          if (puStack_68 != (undefined4 *)0x0) {
            FUN_01674ea0(puStack_68,0xc);
          }
        }
        FUN_006e5160(&uStack_24);
        pbVar8 = (byte *)(iVar5 + 0x134);
      }
      param_1 = uVar9;
      FUN_00606ea0(&iStack_34,(uVar9 >> 3) + uVar9,&param_1,
                   -(uint)(pbVar8 + *pbVar8 + 1 != (byte *)0x0) & (uint)(pbVar8 + *pbVar8 + 1 + 1));
      iVar5 = iStack_18;
      if ((iStack_34 == 0) && (cVar3 = FUN_00621090(uVar9), iVar5 = iStack_18, cVar3 == '\0')) {
        FUN_0060dcd0(&uStack_44,uVar9);
        uStack_8._0_1_ = 3;
        iVar5 = FUN_006e3e20(&uStack_44,param_2);
        piVar2 = piStack_40;
        iVar5 = iStack_18 + iVar5;
        if (piStack_40 != (int *)0x0) {
          LOCK();
          piStack_40[1] = piStack_40[1] + 1;
          UNLOCK();
        }
        iVar7 = FUN_006e3890(uStack_44,piStack_40,param_2);
        iVar5 = iVar5 + iVar7;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        iStack_18 = iVar5;
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar7 = piVar2[1] + -1;
          piVar2[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            iVar7 = piVar2[2] + -1;
            piVar2[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
      }
      puVar4 = puVar4 + 1;
      pbVar8 = (byte *)(iStack_14 + 0x134);
    } while (puVar4 != puStack_38);
  }
  piVar2 = piStack_28;
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_28[1] + -1;
    piStack_28[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (puStack_60 != (uint *)0x0) {
    uVar9 = iStack_58 - (int)puStack_60 & 0xfffffffc;
    puVar4 = puStack_60;
    if (0xfff < uVar9) {
      puVar4 = (uint *)puStack_60[-1];
      uVar9 = uVar9 + 0x23;
      if (0x1f < (uint)((int)puStack_60 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar4,uVar9);
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 9453 ; VA 0x006e36c0 ; FUN_006e36c0 */

undefined4 __thiscall
FUN_006e36c0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  code *pcStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 *puStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar2 = param_4;
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_006e3af0(param_2,param_3,param_4,&uStack_14);
  if (DAT_01d5b990 != '\0') {
    param_4 = param_2;
    FUN_006e5160(&param_4);
  }
  puStack_28 = &uStack_14;
  uStack_1c = uVar2;
  uStack_30 = CONCAT44(uVar2,param_1);
  pcStack_38 = FUN_006e3af0;
  uStack_34 = 0;
  uStack_20 = param_1;
  FUN_006e1930(&pcStack_38);
  uVar2 = uStack_14;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 9454 ; VA 0x006e37c0 ; FUN_006e37c0 */

int FUN_006e37c0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined **appuStack_3c [9];
  undefined ***pppuStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a9500;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  FUN_006e3980(param_1,param_2);
  pppuStack_18 = appuStack_3c;
  appuStack_3c[0] =
       std::
       _Func_impl_no_alloc<class_<lambda_b932aabb98db0a8fac80cb37d05072c8>,bool,class_std::shared_ptr<class_RBX::Instance>_>
       ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar3 = FUN_006e09c0(pppuStack_18);
  if (pppuStack_18 != (undefined ***)0x0) {
    iVar3 = (*(code *)(*pppuStack_18)[4])(pppuStack_18 != appuStack_3c);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 9455 ; VA 0x006e3890 ; FUN_006e3890 */

undefined4 FUN_006e3890(undefined4 param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined **ppuStack_48;
  undefined8 uStack_44;
  undefined ***pppuStack_24;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a9520;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  FUN_006e3af0(param_1,param_2,param_3,&uStack_14);
  puStack_20 = &uStack_14;
  uStack_1c = param_3;
  pppuStack_24 = &ppuStack_48;
  uStack_44 = CONCAT44(param_3,puStack_20);
  ppuStack_48 = std::
                _Func_impl_no_alloc<class_<lambda_f01493cee41eb905bb82d67a0226f6f5>,bool,class_std::shared_ptr<class_RBX::Instance>_>
                ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_006e09c0(pppuStack_24);
  if (pppuStack_24 != (undefined ***)0x0) {
    (*(code *)(*pppuStack_24)[4])(pppuStack_24 != &ppuStack_48);
  }
  uVar3 = uStack_14;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 9456 ; VA 0x006e3980 ; FUN_006e3980 */

ushort * __thiscall FUN_006e3980(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  ushort *puVar3;
  int iVar4;
  undefined4 uStack_24;
  int *piStack_20;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a9540;
  pvStack_10 = ExceptionList;
  iStack_14 = *(int *)(param_1 + 0x128);
  uStack_8 = 0;
  iVar4 = *(int *)(iStack_14 + 0x19f4);
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  puVar3 = (ushort *)FUN_006193f0(*(undefined4 *)(param_2 + 0xc));
  if (puVar3 != (ushort *)0x0) {
    if ((uint)*puVar3 < (uint)((*(int *)(iVar4 + 0x5c) - *(int *)(iVar4 + 0x58)) / 0x3c)) {
      iVar4 = *(int *)(iVar4 + 0x58) + (uint)*puVar3 * 0x3c;
    }
    else {
      iVar4 = 0;
    }
    uStack_24 = 0;
    piStack_20 = (int *)0x0;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    FUN_00617d00(iVar4,param_2,param_3,1,1,1,&uStack_24,0);
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    puVar3 = (ushort *)FUN_00617ec0(param_2,param_3,iVar4,&uStack_24,0);
    piVar2 = piStack_20;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_20 + 1;
      iVar4 = *piVar1;
      puVar3 = (ushort *)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1;
        puVar3 = (ushort *)*piVar1;
        *piVar1 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          puVar3 = (ushort *)(**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar4 = *piVar2;
    puVar3 = (ushort *)*piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      puVar3 = (ushort *)(**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        puVar3 = (ushort *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar3;
}



/* FUNCTION 9457 ; VA 0x006e3af0 ; FUN_006e3af0 */

ushort * __thiscall FUN_006e3af0(int param_1,int param_2,int *param_3,int param_4,ushort *param_5)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  ushort *puVar4;
  int iVar5;
  undefined auStack_20 [8];
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar4 = (ushort *)FUN_006e6340(param_2);
  if ((char)puVar4 == '\0') {
    iVar5 = *(int *)(*(int *)(param_1 + 0x128) + 0x19f4);
    puVar4 = (ushort *)FUN_006193f0(*(undefined4 *)(param_2 + 0xc));
    iVar3 = param_4;
    if (puVar4 != (ushort *)0x0) {
      if ((uint)*puVar4 < (uint)((*(int *)(iVar5 + 0x5c) - *(int *)(iVar5 + 0x58)) / 0x3c)) {
        iVar5 = *(int *)(iVar5 + 0x58) + (uint)*puVar4 * 0x3c;
      }
      else {
        iVar5 = 0;
      }
      param_4 = param_2;
      iStack_18 = iVar3;
      iStack_14 = iVar5;
      FUN_006e14e0(auStack_20,&param_4,&param_4);
      piVar2 = *(int **)(param_1 + 0x150);
      if (*(int **)(param_1 + 0x154) == piVar2) {
        FUN_006e0e40(piVar2,&param_2,&iStack_18,&iStack_14);
      }
      else {
        *piVar2 = 0;
        piVar2[1] = 0;
        if (param_3 != (int *)0x0) {
          LOCK();
          param_3[1] = param_3[1] + 1;
          UNLOCK();
        }
        *piVar2 = param_2;
        piVar2[1] = (int)param_3;
        piVar2[2] = iVar3;
        piVar2[3] = iVar5;
        piVar2[4] = 0;
        piVar2[5] = 0;
        *(int *)(param_1 + 0x150) = *(int *)(param_1 + 0x150) + 0x18;
      }
      *(int *)param_5 = *(int *)param_5 + 1;
      puVar4 = param_5;
    }
  }
  piVar2 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar5 = *piVar1;
    puVar4 = (ushort *)*piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      puVar4 = (ushort *)(**(code **)*param_3)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        puVar4 = (ushort *)(**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 9458 ; VA 0x006e3c50 ; FUN_006e3c50 */

void __fastcall FUN_006e3c50(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  
  iVar3 = *(int *)(param_1 + 0x150);
  iVar4 = *(int *)(param_1 + 0x14c);
  if (iVar4 != iVar3) {
    do {
      FUN_006c2f30(iVar4,*(undefined4 *)(iVar4 + 0xc),iVar4 + 0x10,0);
      iVar4 = iVar4 + 0x18;
    } while (iVar4 != iVar3);
    iVar3 = *(int *)(param_1 + 0x150);
  }
  FUN_006e0dc0(*(undefined4 *)(param_1 + 0x14c),iVar3,(undefined4 *)(param_1 + 0x14c));
  *(undefined4 *)(param_1 + 0x150) = *(undefined4 *)(param_1 + 0x14c);
  if (*(int *)(param_1 + 0x13c) != 0) {
    puVar1 = (undefined4 *)(*(int *)(param_1 + 0x148) + *(int *)(param_1 + 0x138) * 4);
    puVar2 = (undefined4 *)*puVar1;
    do {
      *puVar1 = *puVar2;
      FUN_01674ea0(puVar2,0xc);
      *(int *)(param_1 + 0x13c) = *(int *)(param_1 + 0x13c) + -1;
      puVar2 = (undefined4 *)*puVar1;
    } while (puVar2 != (undefined4 *)0x0);
    puVar2 = *(undefined4 **)(param_1 + 0x148);
    puVar1 = puVar2 + *(int *)(param_1 + 0x138);
    for (; puVar2 != puVar1; puVar2 = puVar2 + 1) {
      *puVar2 = 0;
    }
  }
  return;
}



/* FUNCTION 9459 ; VA 0x006e3d10 ; FUN_006e3d10 */

int FUN_006e3d10(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_20 [8];
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  iVar4 = *(int *)(iVar2 + 0x34);
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    param_1 = (int *)iVar4;
    iVar2 = FUN_006e6340(iVar4);
    if ((char)iVar2 == '\0') {
      FUN_0060dcd0(&uStack_18,iVar4);
      uStack_8 = 0;
      FUN_006e3d10(&uStack_18);
      if (DAT_01d5b998 == '\0') {
        FUN_006e1320(auStack_20,&param_1,&param_1);
        if (piStack_14 != (int *)0x0) {
          LOCK();
          piStack_14[1] = piStack_14[1] + 1;
          UNLOCK();
        }
        iVar2 = FUN_006e3980(uStack_18,piStack_14);
      }
      else {
        uVar3 = 0x6e3d80;
        iVar2 = FUN_006e6340(iVar4);
        if ((char)iVar2 == '\0') {
          FUN_00557fc0(&uStack_18);
          iVar2 = FUN_006e37c0(uVar3,iVar4);
        }
      }
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_14 + 1;
        iVar4 = *piVar1;
        iVar2 = *piVar1;
        *piVar1 = iVar4 + -1;
        UNLOCK();
        if (iVar4 + -1 == 0) {
          iVar2 = (**(code **)*piStack_14)();
          LOCK();
          piVar1 = piStack_14 + 2;
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            iVar2 = (**(code **)(*piStack_14 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 9460 ; VA 0x006e3e20 ; FUN_006e3e20 */

int FUN_006e3e20(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined auStack_2c [8];
  undefined4 uStack_24;
  int *piStack_20;
  undefined auStack_1c [4];
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9558;
  pvStack_10 = ExceptionList;
  iVar6 = *(int *)(*param_1 + 0x34);
  if ((iVar6 == 0) ||
     (ExceptionList = &pvStack_10, param_1 = (int *)iVar6, iStack_14 = iVar6,
     cVar3 = FUN_006e6340(iVar6), cVar3 != '\0')) {
    ExceptionList = pvStack_10;
    return 0;
  }
  FUN_0060dcd0(&uStack_24,iVar6);
  uStack_8 = 0;
  uVar8 = 0x6e3e86;
  iVar4 = FUN_006e3e20(&uStack_24,param_2);
  iStack_18 = iVar4;
  if ((DAT_01d5b9b8 == '\0') ||
     (iVar2 = *(int *)(iVar6 + 0xc), iVar5 = FUN_00aff8c0(), iVar6 = (int)param_1,
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    if (DAT_01d5b998 == '\0') {
      FUN_006e1320(auStack_2c,&iStack_14,&iStack_14);
      if (piStack_20 != (int *)0x0) {
        LOCK();
        piStack_20[1] = piStack_20[1] + 1;
        UNLOCK();
      }
      FUN_006e3af0(uStack_24,piStack_20,param_2,&iStack_18);
      iVar4 = iStack_18;
      goto LAB_006e3fce;
    }
    uVar7 = 0x6e3f5f;
    cVar3 = FUN_006e6340(iVar6);
    if (cVar3 != '\0') goto LAB_006e3fce;
  }
  else {
    iVar6 = FUN_006e16a0(param_1);
    param_1 = *(int **)(iVar6 + 0xa8);
    FUN_00c155c0();
    cVar3 = FUN_00ca0f40();
    if (cVar3 != '\0') {
      iVar6 = FUN_006e32f0(iVar6,param_2);
      iVar4 = iVar4 + iVar6;
      goto LAB_006e3fce;
    }
    uVar7 = FUN_00c15700();
    param_1 = (int *)FUN_00b06640(uVar7);
    uVar7 = 0x6e3f1f;
    iVar6 = FUN_006e4e20(&param_1);
    if (iVar6 == 0) {
      FUN_006e6200(auStack_1c,&param_1);
      iVar6 = FUN_006e4020(param_1,param_2);
      iVar4 = iVar4 + iVar6;
      goto LAB_006e3fce;
    }
  }
  uVar9 = param_2;
  FUN_00557fc0(&uStack_24);
  iVar6 = FUN_006e3890(uVar8,uVar7,uVar9);
  iVar4 = iVar4 + iVar6;
LAB_006e3fce:
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_20[1] + -1;
    piStack_20[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 9461 ; VA 0x006e4020 ; FUN_006e4020 */

uint __thiscall FUN_006e4020(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  uint *puVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  undefined4 *puVar7;
  byte *pbVar8;
  uint uVar9;
  uint uVar10;
  int aiStack_40 [7];
  int *piStack_24;
  uint *puStack_20;
  int iStack_1c;
  uint *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a9590;
  pvStack_10 = ExceptionList;
  uVar10 = 0;
  uStack_14 = 0;
  aiStack_40[0] = 0;
  aiStack_40[1] = 0;
  aiStack_40[2] = 0;
  aiStack_40[3] = 0;
  aiStack_40[4] = 0;
  aiStack_40[5] = 0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (DAT_01d5b9c8 == '\0') {
    ExceptionList = &pvStack_10;
    FUN_008b3b70(param_2,aiStack_40);
    FUN_008b3a50(param_2,aiStack_40 + 3);
    if (DAT_01d5b9c8 == '\0') {
      piVar6 = aiStack_40;
      goto LAB_006e40aa;
    }
  }
  FUN_006d9080();
  piVar6 = (int *)FUN_0071bd70(param_2);
LAB_006e40aa:
  puStack_18 = (uint *)*piVar6;
  puStack_20 = (uint *)piVar6[1];
  if (puStack_18 != (uint *)piVar6[1]) {
    do {
      uVar9 = *puStack_18;
      if ((uVar9 != 0) &&
         (iVar5 = *(int *)(uVar9 + 0xc), uStack_14 = uVar9, iVar4 = FUN_00aff8c0(),
         uVar9 = uStack_14,
         (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
         (uint)*(ushort *)(iVar4 + 0x1da))) {
        FUN_006e5160(&uStack_14);
        FUN_006e5160(&uStack_14);
      }
      pbVar8 = (byte *)(param_1 + 0x134) + *(byte *)(param_1 + 0x134) + 1;
      uStack_14 = uVar9;
      FUN_00606ea0(&iStack_1c,(uVar9 >> 3) + uVar9,&uStack_14,
                   -(uint)(pbVar8 != (byte *)0x0) & (uint)(pbVar8 + 1));
      if ((iStack_1c == 0) && (cVar3 = FUN_00621090(uVar9), cVar3 == '\0')) {
        FUN_0060dcd0(aiStack_40 + 6,uVar9);
        uStack_8._0_1_ = 2;
        iVar5 = FUN_006e3e20(aiStack_40 + 6,param_3);
        if (piStack_24 != (int *)0x0) {
          LOCK();
          piStack_24[1] = piStack_24[1] + 1;
          UNLOCK();
        }
        iVar4 = FUN_006e3890(aiStack_40[6],piStack_24,param_3);
        piVar6 = piStack_24;
        uVar10 = uVar10 + iVar5 + iVar4;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        if (piStack_24 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_24[1] + -1;
          piStack_24[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            piVar1 = piVar6 + 2;
            iVar5 = *piVar1 + -1;
            *piVar1 = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
      }
      puStack_18 = puStack_18 + 1;
    } while (puStack_18 != puStack_20);
    uStack_14 = uVar10;
  }
  if (DAT_01d5b9c8 == '\0') {
    piVar6 = aiStack_40 + 3;
  }
  else {
    FUN_006d9080();
    piVar6 = (int *)FUN_0071bd30(param_2);
  }
  puVar7 = (undefined4 *)*piVar6;
  puStack_18 = (uint *)piVar6[1];
  if (puVar7 != puStack_18) {
    do {
      puVar2 = (uint *)*puVar7;
      pbVar8 = (byte *)(param_1 + 0x134) + *(byte *)(param_1 + 0x134) + 1;
      puStack_20 = puVar2;
      FUN_00606ea0(&iStack_1c,((uint)puVar2 >> 3) + (int)puVar2,&puStack_20,
                   -(uint)(pbVar8 != (byte *)0x0) & (uint)(pbVar8 + 1));
      uVar10 = uStack_14;
      if ((iStack_1c == 0) && (cVar3 = FUN_00621090(puVar2), uVar10 = uStack_14, cVar3 == '\0')) {
        if ((puVar2 == (uint *)0x0) ||
           (uVar10 = puVar2[3], iVar5 = FUN_00aff8c0(),
           (uint)*(ushort *)(iVar5 + 0x1da) <
           (uint)*(ushort *)(uVar10 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
          FUN_0060dcd0(aiStack_40 + 6,puVar2);
          uStack_8._0_1_ = 3;
          iVar5 = FUN_006e3e20(aiStack_40 + 6,param_3);
          iVar5 = uStack_14 + iVar5;
          if (piStack_24 != (int *)0x0) {
            LOCK();
            piStack_24[1] = piStack_24[1] + 1;
            UNLOCK();
          }
          iVar4 = FUN_006e3890(aiStack_40[6],piStack_24,param_3);
          piVar6 = piStack_24;
          uVar10 = iVar5 + iVar4;
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          uStack_14 = uVar10;
          if (piStack_24 != (int *)0x0) {
            LOCK();
            iVar5 = piStack_24[1] + -1;
            piStack_24[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*piStack_24)();
              LOCK();
              piVar1 = piVar6 + 2;
              iVar5 = *piVar1 + -1;
              *piVar1 = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)(*piVar6 + 4))();
              }
            }
          }
        }
        else {
          iVar5 = FUN_006e32f0(puVar2,param_3);
          uVar10 = uStack_14 + iVar5;
          uStack_14 = uVar10;
        }
      }
      puVar7 = puVar7 + 1;
    } while (puVar7 != puStack_18);
  }
  if (aiStack_40[3] != 0) {
    uVar9 = aiStack_40[5] - aiStack_40[3] & 0xfffffffc;
    iVar5 = aiStack_40[3];
    if (0xfff < uVar9) {
      iVar5 = *(int *)(aiStack_40[3] + -4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (aiStack_40[3] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar9);
    aiStack_40[3] = 0;
    aiStack_40[4] = 0;
    aiStack_40[5] = 0;
  }
  if (aiStack_40[0] != 0) {
    uVar9 = aiStack_40[2] - aiStack_40[0] & 0xfffffffc;
    iVar5 = aiStack_40[0];
    if (0xfff < uVar9) {
      iVar5 = *(int *)(aiStack_40[0] + -4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (aiStack_40[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar9);
  }
  ExceptionList = pvStack_10;
  return uVar10;
}



/* FUNCTION 9462 ; VA 0x006e4440 ; FUN_006e4440 */

void __fastcall FUN_006e4440(int param_1)

{
  bool bVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a95af;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x364) == *(int *)(param_1 + 0x184)) {
    if (((*(int *)(param_1 + 0x368) == *(int *)(param_1 + 0x188)) &&
        (*(int *)(param_1 + 0x36c) == *(int *)(param_1 + 0x18c))) &&
       (*(int *)(param_1 + 0x370) == *(int *)(param_1 + 0x198) + -1)) {
      return;
    }
    if (((*(int *)(param_1 + 0x364) != *(int *)(param_1 + 0x184)) ||
        (*(int *)(param_1 + 0x368) != *(int *)(param_1 + 0x188))) ||
       (*(int *)(param_1 + 0x36c) != *(int *)(param_1 + 0x18c))) goto LAB_006e44d4;
    iVar2 = *(int *)(param_1 + 0x1a4);
    if (*(int *)(param_1 + 0x370) < iVar2) goto LAB_006e44da;
    iVar4 = *(int *)(param_1 + 0x198);
  }
  else {
LAB_006e44d4:
    iVar2 = *(int *)(param_1 + 0x1a4);
LAB_006e44da:
    iVar4 = *(int *)(param_1 + 0x198);
    bVar1 = true;
    if (iVar2 < iVar4) goto LAB_006e44ec;
  }
  bVar1 = false;
LAB_006e44ec:
  ExceptionList = &pvStack_10;
  *(undefined8 *)(param_1 + 0x364) = *(undefined8 *)(param_1 + 0x184);
  *(undefined4 *)(param_1 + 0x36c) = *(undefined4 *)(param_1 + 0x18c);
  uVar5 = -(uint)(iVar4 != 0) & iVar4 - 1U;
  *(uint *)(param_1 + 0x370) = uVar5;
  if (DAT_01eaf1fc != '\0') {
    FUN_01677520(DAT_01eaf1fc,"Sending meta update center: (%d,%d,%d) radius: %d",
                 *(undefined4 *)(param_1 + 0x364),*(undefined4 *)(param_1 + 0x368),
                 *(undefined4 *)(param_1 + 0x36c),uVar5);
    uVar5 = *(uint *)(param_1 + 0x370);
  }
  (**(code **)(**(int **)(param_1 + 0x128) + 0xd0))
            (*(undefined8 *)(param_1 + 0x364),*(undefined4 *)(param_1 + 0x36c),uVar5);
  if (bVar1) {
    iVar2 = FUN_01674e20(0x58);
    uStack_8 = 0;
    if (iVar2 == 0) {
      uVar3 = 0;
    }
    else {
      uVar3 = FUN_00703220(*(undefined4 *)(param_1 + 0x128),0xf,0);
    }
    uStack_8 = 0xffffffff;
    FUN_006b1f50(uVar3);
    *(int *)(param_1 + 0x1f0) = *(int *)(param_1 + 0x1f0) + 1;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9463 ; VA 0x006e45f0 ; FUN_006e45f0 */

void __thiscall FUN_006e45f0(int param_1,int param_2)

{
  undefined8 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017a95cf;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  if (DAT_01eaf1fc != '\0') {
    ExceptionList = &pvStack_1c;
    FUN_01677520(DAT_01eaf1fc,
                 "Sending Prefetch meta update center: (%d,%d,%d) radius: %d for prefetch %u",
                 *(undefined4 *)(param_2 + 0x18),*(undefined4 *)(param_2 + 0x1c),
                 *(undefined4 *)(param_2 + 0x20),*(undefined4 *)(param_2 + 0x2c),
                 *(undefined4 *)(param_2 + 0x54));
  }
  puVar5 = (undefined4 *)FUN_01674e20(0x48);
  uStack_14 = 0;
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    uVar2 = *(undefined4 *)(param_2 + 0x54);
    uVar1 = *(undefined8 *)(param_2 + 0x18);
    uVar3 = *(undefined4 *)(param_2 + 0x2c);
    uVar4 = *(undefined4 *)(param_2 + 0x20);
    FUN_006b1a30(*(undefined4 *)(param_1 + 0x128));
    *(undefined8 *)(puVar5 + 0xc) = uVar1;
    *puVar5 = RBX::Network::Replicator::StreamJob::StreamPrefetchDataInfoItem::vftable;
    puVar5[0xe] = uVar4;
    puVar5[0xf] = uVar3;
    puVar5[0x10] = uVar2;
  }
  uStack_14 = 0xffffffff;
  FUN_006b1f50(puVar5);
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 9464 ; VA 0x006e46f0 ; FUN_006e46f0 */

void __fastcall FUN_006e46f0(int param_1)

{
  int *piVar1;
  int *piVar2;
  double dStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0cf0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_01682800(&dStack_1c);
  piVar1 = (int *)**(int **)(param_1 + 0x1cc);
  if (piVar1 != *(int **)(param_1 + 0x1cc)) {
    do {
      if (dStack_1c < *(double *)(piVar1 + 0x1a) || dStack_1c == *(double *)(piVar1 + 0x1a)) {
        piVar2 = (int *)*piVar1;
      }
      else {
        FUN_006e45f0(piVar1 + 2);
        if (piVar1[0x1c] != 0) {
          (**(code **)((piVar1[0x1c] & 0xfffffffeU) + 4))(piVar1 + 0x1e);
        }
        piVar2 = (int *)*piVar1;
        *(int **)piVar1[1] = piVar2;
        *(int *)(*piVar1 + 4) = piVar1[1];
        *(int *)(param_1 + 0x1d0) = *(int *)(param_1 + 0x1d0) + -1;
        FUN_006e3220(piVar1);
      }
      piVar1 = piVar2;
    } while (piVar2 != *(int **)(param_1 + 0x1cc));
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9465 ; VA 0x006e47a0 ; FUN_006e47a0 */

undefined __thiscall FUN_006e47a0(int param_1,int param_2)

{
  uint *puVar1;
  undefined4 *puVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  int iVar9;
  int *piVar10;
  undefined uVar11;
  uint uVar12;
  int *piVar13;
  undefined *puVar14;
  int iStack_6c;
  int iStack_64;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined auStack_48 [8];
  undefined auStack_40 [8];
  undefined auStack_38 [4];
  undefined4 *puStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int *piStack_18;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a963c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_01eaf294);
  uStack_8 = 0;
  piStack_18 = (int *)0x0;
  uStack_20 = uVar4;
  FUN_0060e810(0,&piStack_18,&cStack_11);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  piStack_18 = (int *)0x0;
  uStack_54 = 0;
  uStack_50 = 0;
  uStack_4c = 0;
  if (DAT_01d5a508 != '\0') {
    *(undefined *)(*(int *)(param_1 + 0x128) + 0x18ec) = 1;
  }
  iVar5 = *(int *)(param_1 + 0x128);
  iStack_1c = 0;
  cStack_12 = '\0';
  if ((iVar5 != 0) && (*(char *)(iVar5 + 0x1db8) == '\0')) {
    if (DAT_01eaf208 == 0) {
      uStack_30 = 0;
    }
    else {
      uStack_30 = *(undefined8 *)(iVar5 + 0x980);
    }
    uVar12 = 0;
    cStack_11 = '\0';
    do {
      cVar3 = FUN_006e5be0(&uStack_54,&uStack_30);
      if (cVar3 == '\0') break;
      FUN_006d9080();
      cStack_11 = FUN_0071df50(*(undefined4 *)(param_1 + 0x128),&uStack_54,&iStack_1c,&cStack_12);
      uVar12 = uVar12 + 1;
    } while (cStack_11 == '\0');
    uVar4 = uStack_20;
    if ((1 < uVar12) && (DAT_01eaf35c != '\0')) {
      FUN_016774b0(DAT_01eaf35c,"Checked %u regions before finding uncollected region.",uVar12);
    }
    if (cStack_11 != '\0') {
      if (*(char *)(param_2 + 0x51) == '\0') {
        FUN_006e4440();
      }
      if (cStack_12 != '\0') {
        piStack_18 = (int *)0x1;
        iVar5 = FUN_006e2950(&uStack_54);
        *(int *)(iVar5 + 0xc) = *(int *)(iVar5 + 0xc) + 1;
        puVar2 = *(undefined4 **)(*(int *)(param_1 + 0x128) + 0x196c);
        uStack_30 = CONCAT44(puVar2,(undefined4)uStack_30);
        puVar8 = (undefined4 *)*puVar2;
        puVar6 = (undefined4 *)*puVar8;
        if ((*(uint *)(*(int *)(param_1 + 0x128) + 0x380c) & 2) == 0) {
          if (puVar6 == (undefined4 *)0x0) {
            puVar6 = (undefined4 *)FUN_00621d50();
          }
          else {
            *puVar8 = *puVar6;
          }
          *puVar6 = puVar2;
          piStack_24 = puVar6 + 1;
          uStack_8._0_1_ = 4;
          if (piStack_24 == (int *)0x0) {
            uVar7 = 0;
          }
          else {
            uVar7 = FUN_006e25a0(*(undefined4 *)(param_1 + 0x128),param_1,&uStack_54,3,0xffffffff);
          }
        }
        else {
          if (puVar6 == (undefined4 *)0x0) {
            puVar6 = (undefined4 *)FUN_00621d50();
          }
          else {
            *puVar8 = *puVar6;
          }
          *puVar6 = puVar2;
          piStack_24 = puVar6 + 1;
          uStack_8._0_1_ = 3;
          if (piStack_24 == (int *)0x0) {
            uVar7 = 0;
          }
          else {
            uVar7 = FUN_006e25a0(*(undefined4 *)(param_1 + 0x128),param_1,&uStack_54,3,0xffffffff);
          }
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_006b1f50(uVar7);
      }
      if ((iStack_1c != 0) && (*(int *)(iStack_1c + 8) != 0)) {
        iVar5 = FUN_01674e20(200);
        uStack_8._0_1_ = 5;
        if (iVar5 == 0) {
          param_2 = 0;
        }
        else {
          param_2 = FUN_006e1de0(*(undefined4 *)(param_1 + 0x128),&uStack_54,param_1);
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        if (DAT_01d5b9b8 == '\0') {
          FUN_00618a80((int)&uStack_30 + 4);
          piVar13 = piStack_18;
          for (puVar2 = uStack_30._4_4_; puVar2 != (undefined4 *)0x0; puVar2 = (undefined4 *)*puVar2
              ) {
            piStack_18 = (int *)FUN_00b06640(puVar2[2]);
            puVar1 = (uint *)(param_1 + 0x350);
            uVar12 = *puVar1;
            *puVar1 = *puVar1 + 1;
            *(int *)(param_1 + 0x354) = *(int *)(param_1 + 0x354) + (uint)(0xfffffffe < uVar12);
            if (DAT_01d5b990 == '\0') {
              if ((piStack_18[0xd] == 0) || (cVar3 = FUN_006e6340(piStack_18[0xd]), cVar3 != '\0'))
              {
                if (DAT_01d5b9a0 == '\0') {
                  puVar14 = auStack_48;
                  piVar10 = piStack_18;
                  uVar4 = param_2;
                  uVar7 = FUN_0060dcd0(puVar14,piStack_18,param_2);
                  uStack_8 = CONCAT31(uStack_8._1_3_,8);
                  FUN_00557f90(uVar7);
                  iVar5 = FUN_006e36c0(puVar14,piVar10,uVar4);
                }
                else {
                  puVar14 = auStack_40;
                  piVar10 = piStack_18;
                  uVar4 = param_2;
                  uVar7 = FUN_0060dcd0(puVar14);
                  uStack_8 = CONCAT31(uStack_8._1_3_,7);
                  FUN_00557f90(uVar7);
                  iVar5 = FUN_006e3890(puVar14,piVar10,uVar4);
                }
                uStack_8 = CONCAT31(uStack_8._1_3_,1);
                piVar13 = (int *)((int)piVar13 + iVar5);
                FUN_00550b30();
              }
              else {
                puVar1 = (uint *)(param_1 + 0x348);
                uVar12 = *puVar1;
                *puVar1 = *puVar1 + 1;
                *(int *)(param_1 + 0x34c) = *(int *)(param_1 + 0x34c) + (uint)(0xfffffffe < uVar12);
                if (DAT_01eaf1fc != '\0') {
                  piVar10 = (int *)piStack_18[10];
                  if (0xf < (uint)piVar10[5]) {
                    piVar10 = (int *)*piVar10;
                  }
                  FUN_01677650(DAT_01eaf1fc,"Skipping part %s because parent not replicated",piVar10
                              );
                }
              }
            }
            else {
              puVar8 = (undefined4 *)FUN_0060dcd0(auStack_38,piStack_18);
              uStack_28 = *puVar8;
              piStack_24 = (int *)puVar8[1];
              *puVar8 = 0;
              puVar8[1] = 0;
              uStack_8 = CONCAT31(uStack_8._1_3_,6);
              uStack_30 = CONCAT44(puStack_34,(undefined4)uStack_30);
              piStack_18 = piStack_24;
              if (puStack_34 != (undefined4 *)0x0) {
                LOCK();
                iVar5 = puStack_34[1] + -1;
                puStack_34[1] = iVar5;
                UNLOCK();
                if (iVar5 == 0) {
                  (**(code **)*puStack_34)();
                  LOCK();
                  iVar5 = uStack_30._4_4_[2] + -1;
                  uStack_30._4_4_[2] = iVar5;
                  UNLOCK();
                  if (iVar5 == 0) {
                    (**(code **)(*uStack_30._4_4_ + 4))();
                  }
                }
              }
              puVar8 = &uStack_28;
              uVar4 = 0x6e4bfd;
              iVar5 = FUN_006e3e20(puVar8,param_2);
              if (DAT_01d5b9a0 == '\0') {
                uVar7 = param_2;
                FUN_00557fc0(&uStack_28);
                iVar9 = FUN_006e36c0(uVar4,puVar8,uVar7);
              }
              else {
                uVar7 = param_2;
                FUN_00557fc0(&uStack_28);
                iVar9 = FUN_006e3890(uVar4,puVar8,uVar7);
              }
              piVar13 = (int *)((int)piVar13 + iVar9 + iVar5);
              uStack_8 = CONCAT31(uStack_8._1_3_,1);
              if (piStack_18 != (int *)0x0) {
                LOCK();
                iVar5 = piStack_18[1] + -1;
                piStack_18[1] = iVar5;
                UNLOCK();
                if (iVar5 == 0) {
                  (**(code **)*piStack_18)();
                  LOCK();
                  iVar5 = piStack_18[2] + -1;
                  piStack_18[2] = iVar5;
                  UNLOCK();
                  if (iVar5 == 0) {
                    (**(code **)(*piStack_18 + 4))();
                  }
                }
              }
            }
            uVar4 = uStack_20;
          }
        }
        else {
          FUN_00618a80(&piStack_24);
          piVar13 = piStack_18;
          for (piVar10 = piStack_24; piVar10 != (int *)0x0; piVar10 = (int *)*piVar10) {
            piStack_18 = (int *)FUN_00b06640(piVar10[2]);
            puVar1 = (uint *)(param_1 + 0x350);
            uVar12 = *puVar1;
            *puVar1 = *puVar1 + 1;
            *(int *)(param_1 + 0x354) = *(int *)(param_1 + 0x354) + (uint)(0xfffffffe < uVar12);
            FUN_00c155c0();
            cVar3 = FUN_00ca0f40();
            if (cVar3 == '\0') {
              uVar4 = FUN_00c15700();
              piStack_18 = (int *)FUN_00b06640(uVar4);
              iVar5 = (uint)*(byte *)(param_1 + 0x224) + param_1 + 0x225;
              FUN_00606ea0((int)&uStack_30 + 4,((uint)piStack_18 >> 3) + (int)piStack_18,&piStack_18
                           ,-(uint)(iVar5 != 0) & iVar5 + 1U);
              if (uStack_30._4_4_ != (int *)0x0) {
                piStack_24 = piStack_18;
                iVar5 = FUN_006e4e20(&piStack_24);
                if (iVar5 == 0) goto LAB_006e4b4a;
              }
              FUN_006e6200(auStack_48,&piStack_18);
              iVar5 = FUN_006e4020(piStack_18,param_2);
LAB_006e4b48:
              piVar13 = (int *)((int)piVar13 + iVar5);
            }
            else {
              cVar3 = FUN_006e6340(piStack_18);
              if (cVar3 == '\0') {
LAB_006e4aae:
                iVar5 = FUN_006e32f0(piStack_18,param_2);
                goto LAB_006e4b48;
              }
              piStack_24 = piStack_18;
              iVar5 = FUN_006e4e20(&piStack_24);
              if (iVar5 != 0) goto LAB_006e4aae;
            }
LAB_006e4b4a:
            uVar4 = uStack_20;
          }
        }
        piStack_18 = piVar13;
        if (DAT_01eaf1fc != '\0') {
          FUN_01677520(DAT_01eaf1fc,"Sending region (%d,%d,%d) with %u instances",uStack_54,
                       uStack_50,uStack_4c,piStack_18);
        }
        FUN_006b1f50(param_2);
        *(int *)(param_1 + 0x168) = *(int *)(param_1 + 0x168) + 1;
      }
      if ((piStack_18 != (int *)0x0) && (DAT_01eaf35c != '\0')) {
        FUN_016774b0(DAT_01eaf35c,"Collected %u instances",piStack_18);
      }
      *(int *)(param_1 + 0x164) = *(int *)(param_1 + 0x164) + (int)piStack_18;
      uVar11 = 1;
      goto LAB_006e4db6;
    }
  }
  if (*(char *)(param_2 + 0x51) == '\0') {
    FUN_006e4440();
  }
  else {
    FUN_006e45f0(param_2);
  }
  uVar11 = 0;
LAB_006e4db6:
  uStack_8 = uStack_8 & 0xffffff00;
  if (iStack_6c != 0) {
    uVar12 = (iStack_64 - iStack_6c >> 2) * 4;
    iVar5 = iStack_6c;
    if (0xfff < uVar12) {
      iVar5 = *(int *)(iStack_6c + -4);
      uVar12 = uVar12 + 0x23;
      if (0x1f < (iStack_6c - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar12);
  }
  uStack_8 = 9;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return uVar11;
}



/* FUNCTION 9466 ; VA 0x006e4e20 ; FUN_006e4e20 */

bool __thiscall FUN_006e4e20(byte *param_1,uint *param_2)

{
  FUN_00606ea0(&param_2,(*param_2 >> 3) + *param_2,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  return param_2 != (uint *)0x0;
}



/* FUNCTION 9467 ; VA 0x006e4e60 ; FUN_006e4e60 */

void FUN_006e4e60(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0xa0;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 9468 ; VA 0x006e4ea0 ; FUN_006e4ea0 */

int __thiscall FUN_006e4ea0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_006e27a0();
    FUN_01674ea0(puVar1,0x24);
    iVar2 = iVar2 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 9469 ; VA 0x006e4ef0 ; FUN_006e4ef0 */

int __thiscall FUN_006e4ef0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_01674ea0(puVar1,0xc);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar1 = (undefined4 *)*param_2;
    iVar2 = iVar2 + 1;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 9470 ; VA 0x006e4f30 ; FUN_006e4f30 */

void __thiscall FUN_006e4f30(float *param_1,float *param_2)

{
  double dVar1;
  float fVar2;
  
  dVar1 = (double)(*param_1 * *param_1 + param_1[1] * param_1[1] + param_1[2] * param_1[2]);
  FUN_017267a0();
  fVar2 = DAT_018ce2f8 / (float)dVar1;
  *param_2 = *param_1 * fVar2;
  param_2[1] = param_1[1] * fVar2;
  param_2[2] = param_1[2] * fVar2;
  return;
}



/* FUNCTION 9471 ; VA 0x006e4fb0 ; FUN_006e4fb0 */

float10 __thiscall FUN_006e4fb0(float *param_1,float *param_2)

{
  return (float10)param_2[2] * (float10)param_1[2] +
         (float10)*param_2 * (float10)*param_1 + (float10)param_2[1] * (float10)param_1[1];
}



/* FUNCTION 9472 ; VA 0x006e4fd0 ; FUN_006e4fd0 */

void __thiscall FUN_006e4fd0(int param_1,int *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x14);
  *(ulonglong *)(param_2 + 1) = CONCAT44(*(int *)(param_1 + 0x10) + 1,*(int *)(param_1 + 0xc) + 1);
  *param_2 = param_1;
  param_2[3] = iVar1 + 1;
  return;
}



/* FUNCTION 9473 ; VA 0x006e5000 ; FUN_006e5000 */

void __fastcall FUN_006e5000(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0cf0;
  pvStack_10 = ExceptionList;
  if (*(uint *)(param_1 + 0x68) != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)((*(uint *)(param_1 + 0x68) & 0xfffffffe) + 4))(param_1 + 0x70);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9474 ; VA 0x006e5040 ; FUN_006e5040 */

void __thiscall FUN_006e5040(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  
  iVar1 = *param_3;
  *(int *)param_3[1] = *param_3;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + -1;
  FUN_006e3220(param_3);
  *param_2 = iVar1;
  return;
}



/* FUNCTION 9475 ; VA 0x006e5080 ; FUN_006e5080 */

undefined4 __thiscall FUN_006e5080(int param_1,uint *param_2)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  
  if (*(int *)(param_1 + 8) == 0) {
    return 0;
  }
  uVar7 = *param_2;
  uVar3 = (uVar7 >> 3) + uVar7;
  uVar6 = uVar3 % *(uint *)(param_1 + 4);
  piVar1 = *(int **)(uVar6 * 4 + *(int *)(param_1 + 0x14));
  if (piVar1 != (int *)0x0) {
    piVar2 = (int *)*piVar1;
    while( true ) {
      if ((piVar2 == (int *)0x0) || ((uint)piVar2[1] % *(uint *)(param_1 + 4) != uVar6)) {
        return 0;
      }
      if ((piVar2[1] == uVar3) && (uVar7 == piVar2[2])) break;
      piVar1 = piVar2;
      piVar2 = (int *)*piVar2;
    }
    uVar4 = FUN_006e4ea0(piVar1,*piVar2);
    if (*piVar1 != 0) {
      uVar7 = *(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 4);
      if (uVar6 == uVar7) {
        return uVar4;
      }
      *(int **)(*(int *)(param_1 + 0x14) + uVar7 * 4) = piVar1;
    }
    puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    if ((int *)*puVar5 == piVar1) {
      *puVar5 = 0;
    }
    return uVar4;
  }
  return 0;
}



/* FUNCTION 9476 ; VA 0x006e5160 ; FUN_006e5160 */

undefined4 __thiscall FUN_006e5160(int param_1,uint *param_2)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  
  if (*(int *)(param_1 + 8) == 0) {
    return 0;
  }
  uVar7 = *param_2;
  uVar3 = (uVar7 >> 3) + uVar7;
  uVar6 = uVar3 % *(uint *)(param_1 + 4);
  piVar1 = *(int **)(uVar6 * 4 + *(int *)(param_1 + 0x14));
  if (piVar1 != (int *)0x0) {
    piVar2 = (int *)*piVar1;
    while( true ) {
      if ((piVar2 == (int *)0x0) || ((uint)piVar2[1] % *(uint *)(param_1 + 4) != uVar6)) {
        return 0;
      }
      if ((piVar2[1] == uVar3) && (uVar7 == piVar2[2])) break;
      piVar1 = piVar2;
      piVar2 = (int *)*piVar2;
    }
    uVar4 = FUN_006e4ef0(piVar1,*piVar2);
    if (*piVar1 != 0) {
      uVar7 = *(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 4);
      if (uVar6 == uVar7) {
        return uVar4;
      }
      *(int **)(*(int *)(param_1 + 0x14) + uVar7 * 4) = piVar1;
    }
    puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    if ((int *)*puVar5 == piVar1) {
      *puVar5 = 0;
    }
    return uVar4;
  }
  return 0;
}



/* FUNCTION 9477 ; VA 0x006e5240 ; FUN_006e5240 */

void __thiscall FUN_006e5240(int param_1,int param_2,double param_3)

{
  undefined8 uVar1;
  undefined4 *puVar2;
  char cVar3;
  double *pdVar4;
  undefined4 uVar5;
  int *piVar6;
  int iVar7;
  undefined auStack_94 [24];
  undefined auStack_7c [8];
  undefined auStack_74 [8];
  int iStack_6c;
  int iStack_68;
  int iStack_64;
  int iStack_60;
  undefined8 uStack_5c;
  undefined8 uStack_54;
  int iStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 *puStack_8;
  
  puStack_8 = (undefined4 *)0xffffffff;
  puStack_c = &LAB_017a9662;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x274) != 0) {
    puStack_18 = (undefined4 *)0x0;
    iStack_44 = *(int *)(param_1 + 0x164);
    ExceptionList = &pvStack_10;
    uStack_2c = FUN_006d9080();
    if (*(int *)(param_1 + 0x274) == 0) {
      iVar7 = 0;
    }
    else {
      iVar7 = *(int *)(*(int *)(param_1 + 0x280) + *(int *)(param_1 + 0x270) * 4);
    }
    if (iVar7 != 0) {
      do {
        if ((param_2 <= *(int *)(param_1 + 0x164)) ||
           (pdVar4 = (double *)FUN_01682800(auStack_74), param_3 < *pdVar4)) break;
        iVar7 = *(int *)(iVar7 + 8);
        iStack_40 = iVar7;
        iStack_38 = iVar7;
        cVar3 = FUN_006e6340(iVar7);
        if (cVar3 == '\0') {
          uStack_14 = *(uint *)(iVar7 + 0xa8);
          uVar5 = FUN_00c15960();
          piVar6 = (int *)FUN_006e77c0(auStack_94,uVar5);
          iStack_6c = *piVar6;
          iStack_68 = piVar6[1];
          iStack_64 = piVar6[2];
          iStack_60 = piVar6[3];
          uVar1 = *(undefined8 *)(piVar6 + 4);
          piStack_28 = &iStack_6c;
          uStack_5c._4_4_ = (int)((ulonglong)uVar1 >> 0x20);
          uStack_5c._0_4_ = (int)uVar1;
          iVar7 = uStack_5c._4_4_ + 1;
          iStack_30 = (int)uStack_5c + 1;
          iStack_34 = iStack_60 + 1;
          uStack_5c = uVar1;
          iStack_24 = iStack_6c;
          iStack_20 = iStack_68;
          iStack_1c = iStack_64;
          while( true ) {
            if (((iStack_24 == iStack_34) && (iStack_20 == iStack_30)) && (iStack_1c == iVar7))
            goto LAB_006e548b;
            cVar3 = FUN_0071c520(*(undefined4 *)(param_1 + 0x128),&iStack_24);
            puVar2 = puStack_18;
            if (cVar3 != '\0') break;
            FUN_00ca2620();
          }
          if (puStack_18 == (undefined4 *)0x0) {
            iStack_48 = FUN_01674e20(200);
            puStack_8 = puVar2;
            if (iStack_48 == 0) {
              puStack_18 = (undefined4 *)0x0;
            }
            else {
              uStack_54 = CONCAT44(iStack_20,iStack_24);
              iStack_4c = iStack_1c;
              puStack_18 = (undefined4 *)
                           FUN_006e1de0(*(undefined4 *)(param_1 + 0x128),&uStack_54,param_1);
            }
            puStack_8 = (undefined4 *)0xffffffff;
          }
          puVar2 = puStack_18;
          FUN_00c155c0();
          cVar3 = FUN_00ca0f40();
          if (cVar3 == '\0') {
            uVar5 = FUN_00c15700();
            uStack_14 = FUN_00b06640(uVar5);
            iVar7 = param_1 + 0x225 + (uint)*(byte *)(param_1 + 0x224);
            FUN_00606ea0(&iStack_3c,(uStack_14 >> 3) + uStack_14,&uStack_14,
                         -(uint)(iVar7 != 0) & iVar7 + 1U);
            if (iStack_3c != 0) goto LAB_006e548b;
            FUN_006e6200(auStack_7c,&uStack_14);
            iVar7 = FUN_006e4020(uStack_14,puStack_18);
          }
          else {
            iVar7 = FUN_006e32f0(iStack_38,puVar2);
          }
          *(int *)(param_1 + 0x164) = *(int *)(param_1 + 0x164) + iVar7;
        }
LAB_006e548b:
        FUN_006e5160(&iStack_40);
        if (*(int *)(param_1 + 0x274) == 0) {
          iVar7 = 0;
        }
        else {
          iVar7 = *(int *)(*(int *)(param_1 + 0x280) + *(int *)(param_1 + 0x270) * 4);
        }
      } while (iVar7 != 0);
      puVar2 = puStack_18;
      if (puStack_18 != (undefined4 *)0x0) {
        if (iStack_44 < *(int *)(param_1 + 0x164)) {
          if (DAT_01eaf1fc != '\0') {
            FUN_01677520(DAT_01eaf1fc,"Sending item with %i instances from evaluating moved parts",
                         *(int *)(param_1 + 0x164) - iStack_44);
          }
          FUN_006b1f50(puVar2);
          *(int *)(param_1 + 0x168) = *(int *)(param_1 + 0x168) + 1;
          ExceptionList = pvStack_10;
          return;
        }
        (**(code **)*puStack_18)(1);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9478 ; VA 0x006e5540 ; FUN_006e5540 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

double * __thiscall FUN_006e5540(int param_1,double *param_2,double param_3)

{
  undefined auVar1 [16];
  undefined auVar2 [16];
  undefined auVar3 [16];
  char cVar4;
  double *pdVar5;
  undefined (*pauVar6) [12];
  undefined4 *puVar7;
  undefined *puVar8;
  int *piVar9;
  uint *puVar10;
  uint *puVar11;
  int *piVar12;
  undefined auVar13 [16];
  int iVar14;
  int iVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar22;
  float fVar23;
  float fVar24;
  undefined auVar21 [16];
  float fVar25;
  uint uVar26;
  float fVar28;
  uint uVar29;
  float fVar30;
  uint uVar31;
  undefined in_XMM7 [16];
  undefined auVar27 [16];
  float fVar32;
  uint uVar33;
  int iStack_bc;
  int *piStack_b8;
  uint *puStack_b4;
  undefined4 uStack_b0;
  int iStack_ac;
  uint *puStack_a8;
  undefined auStack_a4 [8];
  undefined auStack_9c [8];
  undefined auStack_94 [8];
  int iStack_8c;
  int iStack_88;
  int iStack_80;
  int iStack_7c;
  int iStack_78;
  int *piStack_74;
  uint *puStack_70;
  int *piStack_6c;
  int iStack_68;
  int *piStack_64;
  uint *puStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  int iStack_4c;
  int *piStack_48;
  uint *puStack_44;
  uint *puStack_40;
  int *piStack_3c;
  int iStack_38;
  int *piStack_34;
  uint *puStack_30;
  undefined8 uStack_2c;
  uint *puStack_24;
  int iStack_20;
  uint *puStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9694;
  pvStack_10 = ExceptionList;
  iStack_14 = 0;
  iStack_5c = *(int *)(param_1 + 0x164);
  if (*(int *)(param_1 + 0x28c) == 0) {
    piVar12 = (int *)0x0;
    pdVar5 = (double *)ExceptionList;
  }
  else {
    piVar12 = *(int **)(*(int *)(param_1 + 0x298) + (int)*(double **)(param_1 + 0x288) * 4);
    pdVar5 = *(double **)(param_1 + 0x288);
  }
  ExceptionList = &pvStack_10;
  iStack_20 = param_1;
  if (piVar12 != (int *)0x0) {
    do {
      pdVar5 = param_2;
      if (((int)param_2 <= *(int *)(param_1 + 0x164)) ||
         (pdVar5 = (double *)FUN_01682800(auStack_94), param_3 < *pdVar5)) break;
      FUN_006d9080();
      pauVar6 = (undefined (*) [12])FUN_0071bd50(piVar12[2]);
      fVar20 = SUB164(_DAT_018e0060,0);
      fVar22 = SUB164(_DAT_018e0060,4);
      fVar23 = SUB164(_DAT_018e0060,8);
      fVar24 = SUB164(_DAT_018e0060,0xc);
      auVar27 = rcpps(in_XMM7,_DAT_018e0060);
      fVar25 = auVar27._0_4_;
      fVar28 = auVar27._4_4_;
      fVar30 = auVar27._8_4_;
      fVar32 = auVar27._12_4_;
      fVar16 = fVar25 * (_DAT_018e0050 - fVar25 * fVar20);
      fVar17 = fVar28 * (_UNK_018e0054 - fVar28 * fVar22);
      fVar18 = fVar30 * (_UNK_018e0058 - fVar30 * fVar23);
      fVar19 = fVar32 * (_UNK_018e005c - fVar32 * fVar24);
      uVar26 = (uint)fVar25 ^
               -(uint)((float)(~DAT_018c4ea0 & (uint)fVar16) < _DAT_018e0080) &
               ((uint)fVar16 ^ (uint)fVar25);
      uVar29 = (uint)fVar28 ^
               -(uint)((float)(~_UNK_018c4ea4 & (uint)fVar17) < _UNK_018e0084) &
               ((uint)fVar17 ^ (uint)fVar28);
      uVar31 = (uint)fVar30 ^
               -(uint)((float)(~_UNK_018c4ea8 & (uint)fVar18) < _UNK_018e0088) &
               ((uint)fVar18 ^ (uint)fVar30);
      uVar33 = (uint)fVar32 ^
               -(uint)((float)(~_UNK_018c4eac & (uint)fVar19) < _UNK_018e008c) &
               ((uint)fVar19 ^ (uint)fVar32);
      auVar21._0_8_ = CONCAT44(0.0 - _UNK_018e0074,0.0 - _DAT_018e0070);
      auVar21._8_4_ = 0.0 - _UNK_018e0078;
      auVar21._12_4_ = 0.0 - _UNK_018e007c;
      in_XMM7._0_4_ =
           (float)(uVar26 ^ -(uint)((float)(~DAT_018c4ea0 & (uint)fVar20) == _DAT_018e0080) &
                            ((uint)fVar20 & DAT_018c4ea0 ^ uVar26));
      in_XMM7._4_4_ =
           (float)(uVar29 ^ -(uint)((float)(~_UNK_018c4ea4 & (uint)fVar22) == _UNK_018e0084) &
                            ((uint)fVar22 & _UNK_018c4ea4 ^ uVar29));
      in_XMM7._8_4_ =
           (float)(uVar31 ^ -(uint)((float)(~_UNK_018c4ea8 & (uint)fVar23) == _UNK_018e0088) &
                            ((uint)fVar23 & _UNK_018c4ea8 ^ uVar31));
      in_XMM7._12_4_ =
           uVar33 ^ -(uint)((float)(~_UNK_018c4eac & (uint)fVar24) == _UNK_018e008c) &
                    ((uint)fVar24 & _UNK_018c4eac ^ uVar33);
      auVar13._8_4_ = auVar21._8_4_;
      auVar13._0_8_ = auVar21._0_8_;
      auVar13._12_4_ = auVar21._12_4_;
      auVar2._4_4_ = _UNK_018e0074;
      auVar2._0_4_ = _DAT_018e0070;
      auVar2._8_4_ = _UNK_018e0078;
      auVar2._12_4_ = _UNK_018e007c;
      auVar27._12_4_ = 0;
      auVar27._0_12_ = *pauVar6;
      auVar27 = maxps(auVar13,auVar27);
      auVar27 = minps(auVar2,auVar27);
      fVar19 = auVar27._0_4_ * in_XMM7._0_4_;
      fVar20 = auVar27._4_4_ * in_XMM7._4_4_;
      fVar22 = auVar27._8_4_ * in_XMM7._8_4_;
      fVar16 = (float)(int)fVar19;
      fVar17 = (float)(int)fVar20;
      fVar18 = (float)(int)fVar22;
      iStack_bc = (int)(fVar16 - (float)(_DAT_018e0040 & -(uint)(fVar19 < fVar16)));
      piStack_b8 = (int *)(int)(fVar17 - (float)(_UNK_018e0044 & -(uint)(fVar20 < fVar17)));
      puStack_b4 = (uint *)(int)(fVar18 - (float)(_UNK_018e0048 & -(uint)(fVar22 < fVar18)));
      auVar3._4_4_ = _UNK_018e0074;
      auVar3._0_4_ = _DAT_018e0070;
      auVar3._8_4_ = _UNK_018e0078;
      auVar3._12_4_ = _UNK_018e007c;
      auVar1._4_4_ = *(undefined4 *)(pauVar6[1] + 4);
      auVar1._0_4_ = *(undefined4 *)pauVar6[1];
      auVar1._8_4_ = *(undefined4 *)(pauVar6[1] + 8);
      auVar1._12_4_ = 0;
      auVar27 = maxps(auVar21,auVar1);
      auVar27 = minps(auVar3,auVar27);
      fVar19 = auVar27._0_4_ * in_XMM7._0_4_;
      fVar20 = auVar27._4_4_ * in_XMM7._4_4_;
      fVar22 = auVar27._8_4_ * in_XMM7._8_4_;
      fVar16 = (float)(int)fVar19;
      fVar17 = (float)(int)fVar20;
      fVar18 = (float)(int)fVar22;
      iVar14 = (int)(fVar16 + (float)(_DAT_018e0040 & -(uint)(fVar16 < fVar19)));
      iVar15 = (int)(fVar17 + (float)(_UNK_018e0044 & -(uint)(fVar17 < fVar20)));
      puStack_24 = (uint *)(int)(fVar18 + (float)(_UNK_018e0048 & -(uint)(fVar18 < fVar22)));
      uStack_2c = CONCAT44(iVar15,iVar14);
      if ((iStack_bc < iVar14) &&
         (((int)piStack_b8 < iVar15 && ((int)puStack_b4 < (int)puStack_24)))) {
        puStack_24 = (uint *)((int)puStack_24 + -1);
        iStack_88 = iVar15 + -1;
        iStack_8c = iVar14 + -1;
        uStack_2c = CONCAT44(iStack_88,iStack_8c);
        puStack_1c = puStack_24;
      }
      iStack_4c = 0;
      uStack_b0 = (int)uStack_2c;
      piStack_48 = (int *)0x0;
      iStack_ac = uStack_2c._4_4_;
      puStack_a8 = puStack_24;
      puStack_44 = (uint *)0x0;
      iStack_38 = iStack_bc;
      piStack_34 = piStack_b8;
      puStack_30 = puStack_b4;
      if (*(char *)(*(int *)(param_1 + 0x128) + 0x1db8) == '\0') {
        piStack_6c = &iStack_bc;
        puStack_1c = (uint *)((int)puStack_24 + 1);
        piStack_18 = (int *)(uStack_2c._4_4_ + 1);
        iStack_68 = iStack_bc;
        piStack_64 = piStack_b8;
        puStack_60 = puStack_b4;
        while( true ) {
          param_1 = iStack_20;
          if (((iStack_68 == (int)uStack_2c + 1) && (piStack_64 == piStack_18)) &&
             (puStack_60 == puStack_1c)) goto LAB_006e58d5;
          iStack_78 = iStack_68;
          piStack_74 = piStack_64;
          puStack_70 = puStack_60;
          FUN_006d9080();
          cVar4 = FUN_0071c520(*(undefined4 *)(param_1 + 0x128),&iStack_78);
          if (cVar4 != '\0') break;
          FUN_00ca2620();
        }
        iStack_4c = iStack_78;
        piStack_48 = piStack_74;
        puStack_44 = puStack_70;
        if (iStack_14 == 0) {
          iStack_7c = FUN_01674e20(200);
          uStack_8 = 0;
          if (iStack_7c == 0) {
            iStack_14 = 0;
          }
          else {
            iStack_14 = FUN_006e1de0(*(undefined4 *)(param_1 + 0x128),&iStack_4c,param_1);
          }
          uStack_8 = 0xffffffff;
        }
        iVar14 = param_1 + 0x225 + (uint)*(byte *)(param_1 + 0x224);
        FUN_00606ea0(&iStack_50,((uint)piVar12[2] >> 3) + piVar12[2],piVar12 + 2,
                     -(uint)(iVar14 != 0) & iVar14 + 1U);
        if (iStack_50 == 0) {
          puVar8 = auStack_9c;
LAB_006e5a27:
          FUN_006e6200(puVar8,piVar12 + 2);
          iVar14 = FUN_006e4020(piVar12[2],iStack_14);
          *(int *)(param_1 + 0x164) = *(int *)(param_1 + 0x164) + iVar14;
        }
      }
      else {
LAB_006e58d5:
        FUN_006d9080();
        puVar7 = (undefined4 *)FUN_0071bd70(piVar12[2]);
        puStack_1c = (uint *)*puVar7;
        puStack_40 = (uint *)puVar7[1];
        if (puStack_1c != puStack_40) {
          do {
            piStack_18 = (int *)*puStack_1c;
            iVar14 = piStack_18[3];
            iVar15 = FUN_00aff8c0();
            param_1 = iStack_20;
            if ((uint)*(ushort *)(iVar14 + 0x1d8) - (uint)*(ushort *)(iVar15 + 0x1d8) <=
                (uint)*(ushort *)(iVar15 + 0x1da)) {
              piStack_3c = piStack_18;
              iVar14 = iStack_20 + 0x135 + (uint)*(byte *)(iStack_20 + 0x134);
              FUN_00606ea0(&iStack_54,((uint)piStack_18 >> 3) + (int)piStack_18,&piStack_3c,
                           -(uint)(iVar14 != 0) & iVar14 + 1U);
              param_1 = iStack_20;
              if ((iStack_54 != 0) || (cVar4 = FUN_00621090(piStack_18), cVar4 != '\0')) {
                if (iStack_14 == 0) {
                  iStack_80 = FUN_01674e20(200);
                  uStack_8 = 1;
                  if (iStack_80 == 0) {
                    iStack_14 = 0;
                  }
                  else {
                    iStack_14 = FUN_006e1de0(*(undefined4 *)(param_1 + 0x128),&iStack_4c,param_1);
                  }
                  uStack_8 = 0xffffffff;
                }
                iVar14 = param_1 + *(byte *)(param_1 + 0x224) + 0x225;
                FUN_00606ea0(&iStack_58,((uint)piVar12[2] >> 3) + piVar12[2],piVar12 + 2,
                             -(uint)(iVar14 != 0) & iVar14 + 1U);
                if (iStack_58 == 0) {
                  puVar8 = auStack_a4;
                  goto LAB_006e5a27;
                }
                break;
              }
            }
            puStack_1c = puStack_1c + 1;
          } while (puStack_1c != puStack_40);
        }
      }
      piStack_3c = (int *)*piVar12;
      puStack_1c = (uint *)(param_1 + 0x288);
      puVar10 = (uint *)((uint)piVar12[1] % *puStack_1c);
      piStack_18 = *(int **)(*(int *)(param_1 + 0x298) + (int)puVar10 * 4);
      for (piVar9 = (int *)*piStack_18; puStack_40 = puVar10, piVar9 != piVar12;
          piVar9 = (int *)*piVar9) {
        piStack_18 = piVar9;
      }
      do {
        *piStack_18 = *piVar9;
        FUN_01674ea0(piVar9,0xc);
        *(int *)(param_1 + 0x28c) = *(int *)(param_1 + 0x28c) + -1;
        puVar11 = puVar10;
        if (*piStack_18 == 0) {
LAB_006e5aba:
          pdVar5 = *(double **)(param_1 + 0x298);
          if (*(int **)((int)pdVar5 + (int)puVar10 * 4) == piStack_18) {
            *(undefined4 *)((int)pdVar5 + (int)puVar10 * 4) = 0;
          }
        }
        else {
          uVar26 = *(uint *)(*piStack_18 + 4);
          pdVar5 = (double *)(uVar26 / *puStack_1c);
          puVar11 = (uint *)(uVar26 % *puStack_1c);
          param_1 = iStack_20;
          if (puVar10 != puVar11) {
            *(int **)(*(int *)(iStack_20 + 0x298) + (int)puVar11 * 4) = piStack_18;
            goto LAB_006e5aba;
          }
        }
        piVar9 = (int *)*piStack_18;
        puVar10 = puVar11;
      } while (piVar9 != piStack_3c);
      if (*(int *)(param_1 + 0x28c) == 0) {
        piVar12 = (int *)0x0;
      }
      else {
        pdVar5 = (double *)*puStack_1c;
        piVar12 = *(int **)(*(int *)(param_1 + 0x298) + (int)pdVar5 * 4);
      }
    } while (piVar12 != (int *)0x0);
    iVar14 = iStack_14;
    if (iStack_14 != 0) {
      if (DAT_01eaf1fc != '\0') {
        FUN_01677520(DAT_01eaf1fc,"Sending item with %i instances from evaluating newly added NOUs",
                     *(int *)(param_1 + 0x164) - iStack_5c);
      }
      pdVar5 = (double *)FUN_006b1f50(iVar14);
      *(int *)(param_1 + 0x168) = *(int *)(param_1 + 0x168) + 1;
    }
  }
  ExceptionList = pvStack_10;
  return pdVar5;
}



/* FUNCTION 9479 ; VA 0x006e5b60 ; FUN_006e5b60 */

int FUN_006e5b60(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  if (param_1 == 0) {
    return param_2;
  }
  do {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00aff8c0();
    iVar3 = param_1;
    if ((uint)*(ushort *)(iVar2 + 0x1da) <
        (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) {
      iVar3 = 0;
    }
    param_1 = *(int *)(param_1 + 0x34);
    if (iVar3 != 0) {
      param_2 = iVar3;
    }
  } while (param_1 != 0);
  return param_2;
}



/* FUNCTION 9480 ; VA 0x006e5bc0 ; FUN_006e5bc0 */

void __thiscall FUN_006e5bc0(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x19c);
  *param_2 = *(undefined8 *)(param_1 + 0x194);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 9481 ; VA 0x006e5be0 ; FUN_006e5be0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall FUN_006e5be0(undefined8 *param_1,undefined8 *param_2,double *param_3)

{
  int iVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  char cVar4;
  int iVar5;
  undefined8 *puVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  undefined4 uVar10;
  int iVar11;
  int iVar12;
  int *piVar13;
  float fVar14;
  double dVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  int iStack_5c;
  float fStack_4c;
  float fStack_48;
  float fStack_40;
  undefined8 uStack_2c;
  float fStack_20;
  float fStack_1c;
  undefined8 uStack_14;
  
  fStack_40 = 0.0;
  fStack_4c = 0.0;
  uStack_2c = *param_1;
  iStack_5c = *(int *)(param_1 + 1);
  fStack_48 = 0.0;
  if ((DAT_01eaf208 != 0) && (*(int *)(param_1 + 5) != 0)) {
    LOCK();
    piVar13 = (int *)(*(int *)(param_1 + 5) + 8);
    *piVar13 = *piVar13 + 1;
    UNLOCK();
    piVar13 = *(int **)(param_1 + 5);
    if (piVar13 != (int *)0x0) {
      iVar7 = piVar13[1];
      LOCK();
      iVar5 = piVar13[2] + -1;
      piVar13[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar13 + 4))();
      }
      if (iVar7 != 0) {
        piVar13 = *(int **)(param_1 + 5);
        if (piVar13 != (int *)0x0) {
          LOCK();
          piVar13[2] = piVar13[2] + 1;
          UNLOCK();
          piVar13 = *(int **)(param_1 + 5);
        }
        if (piVar13 != (int *)0x0) {
          iVar7 = piVar13[1];
          while (iVar7 != 0) {
            LOCK();
            iVar5 = piVar13[1];
            if (iVar7 == iVar5) {
              piVar13[1] = iVar7 + 1;
              iVar5 = iVar7;
            }
            UNLOCK();
            if (iVar5 == iVar7) {
              LOCK();
              iVar7 = piVar13[1] + -1;
              piVar13[1] = iVar7;
              UNLOCK();
              if (iVar7 == 0) {
                (**(code **)*piVar13)();
                LOCK();
                iVar7 = piVar13[2] + -1;
                piVar13[2] = iVar7;
                UNLOCK();
                if (iVar7 == 0) {
                  (**(code **)(*piVar13 + 4))();
                }
              }
              break;
            }
            iVar7 = piVar13[1];
          }
          LOCK();
          iVar7 = piVar13[2] + -1;
          piVar13[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            (**(code **)(*piVar13 + 4))();
          }
        }
        puVar6 = (undefined8 *)FUN_00b07b60();
        uVar2 = *puVar6;
        fVar20 = *(float *)(puVar6 + 1);
        iVar7 = FUN_00b077e0();
        fStack_20 = (float)uVar2;
        uVar3 = *(undefined8 *)(iVar7 + 0x24);
        fStack_1c = (float)((ulonglong)uVar2 >> 0x20);
        fStack_48 = *(float *)(iVar7 + 0x2c);
        dVar15 = (double)(fStack_20 * fStack_20 + fStack_1c * fStack_1c + fVar20 * fVar20);
        FUN_017267a0();
        cVar4 = *(char *)(param_1 + 8);
        fVar17 = (float)dVar15;
        if (cVar4 != '\0') {
          dVar15 = (double)(*(float *)((int)param_1 + 0x44) * *(float *)((int)param_1 + 0x44) +
                            *(float *)(param_1 + 9) * *(float *)(param_1 + 9) +
                           *(float *)((int)param_1 + 0x4c) * *(float *)((int)param_1 + 0x4c));
          FUN_017267a0();
          fVar16 = DAT_018ce2f8 / (float)dVar15;
          fVar14 = DAT_018ce2f8 / fVar17;
          if (fStack_20 * fVar14 * *(float *)((int)param_1 + 0x44) * fVar16 +
              fStack_1c * fVar14 * *(float *)(param_1 + 9) * fVar16 +
              fVar20 * fVar14 * *(float *)((int)param_1 + 0x4c) * fVar16 < DAT_018e0010) {
            *(float *)((int)param_1 + 0x44) = fStack_20;
            *(float *)(param_1 + 9) = fStack_1c;
            *(float *)((int)param_1 + 0x4c) = fVar20;
            *(undefined4 *)((int)param_1 + 0x3c) = *(undefined4 *)((int)param_1 + 0x2c);
          }
        }
        fVar14 = (float)(DAT_018e0020 / *param_3 + _DAT_018e0018 + (double)DAT_01eaf208);
        if ((cVar4 != '\0') || (fVar17 < fVar14)) {
LAB_006e5ea5:
          if ((*(int *)((int)param_1 + 0x2c) <= *(int *)(param_1 + 7)) || (fVar17 < fVar14)) {
            *(undefined *)(param_1 + 8) = 0;
            cVar4 = '\0';
          }
        }
        else {
          iVar7 = *(int *)((int)param_1 + 0x2c);
          iVar5 = *(int *)(param_1 + 7);
          if (iVar7 <= iVar5) goto LAB_006e5ea5;
          iVar8 = *(int *)((int)param_1 + 0x34);
          if (*(int *)(param_1 + 6) <= *(int *)((int)param_1 + 0x34)) {
            iVar8 = *(int *)(param_1 + 6);
          }
          if (iVar5 <= iVar8) {
            iVar5 = iVar8;
          }
          if (iVar5 + -1 <= iVar7) goto LAB_006e5ea5;
          *(float *)((int)param_1 + 0x44) = fStack_20;
          *(float *)(param_1 + 9) = fStack_1c;
          *(float *)((int)param_1 + 0x4c) = fVar20;
          cVar4 = '\x01';
          *(undefined *)(param_1 + 8) = 1;
          *(int *)((int)param_1 + 0x3c) = iVar7;
        }
        uStack_14._4_4_ = (float)((ulonglong)uVar3 >> 0x20);
        uStack_14._0_4_ = (float)uVar3;
        fStack_4c = uStack_14._4_4_;
        fStack_40 = (float)uStack_14;
        goto LAB_006e5ee9;
      }
    }
  }
  cVar4 = '\0';
  *(undefined *)(param_1 + 8) = 0;
LAB_006e5ee9:
  iVar7 = 0x3c;
  if (cVar4 == '\0') {
    iVar7 = 0x2c;
  }
  piVar13 = (int *)(iVar7 + (int)param_1);
  fVar20 = DAT_018df584;
  do {
    iVar7 = uStack_2c._4_4_;
LAB_006e5f10:
    uVar2 = uStack_2c;
    iVar5 = *(int *)((int)param_1 + 0x34);
    if (*(int *)(param_1 + 6) <= *(int *)((int)param_1 + 0x34)) {
      iVar5 = *(int *)(param_1 + 6);
    }
    iVar8 = *(int *)(param_1 + 7);
    if (*(int *)(param_1 + 7) <= iVar5) {
      iVar8 = iVar5;
    }
    if (iVar8 < *piVar13) {
      uVar10 = 0;
LAB_006e6171:
      *param_1 = uStack_2c;
      *(int *)(param_1 + 1) = iStack_5c;
      return uVar10;
    }
    iVar5 = *piVar13;
    iVar8 = *(int *)((int)param_1 + 0x1c) - *piVar13;
    iVar9 = *(int *)(param_1 + 4) + iVar5;
    iVar1 = *(int *)(param_1 + 4) - *piVar13;
    iVar11 = *piVar13 + *(int *)(param_1 + 3);
    iVar12 = *(int *)((int)param_1 + 0x1c) + iVar5;
    if (iVar7 <= iVar12) {
      if (((((*(int *)(param_1 + 3) - *piVar13 < (int)uStack_2c) && ((int)uStack_2c < iVar11)) &&
           (iVar8 < iVar7)) && ((iVar7 < iVar12 && (iVar1 < iStack_5c)))) && (iStack_5c < iVar9)) {
        iVar7 = iVar12 + 1;
        if (iVar12 <= iVar12 + 1) {
          iVar7 = iVar12;
        }
        uStack_2c = CONCAT44(iVar7,(int)uStack_2c);
        goto LAB_006e5f10;
      }
      iVar7 = iVar7 + 1;
      uStack_2c = CONCAT44(iVar7,(int)uStack_2c);
      *param_2 = uVar2;
      *(int *)(param_2 + 1) = iStack_5c;
      if (*(char *)(param_1 + 8) != '\0') {
        fVar17 = (float)iVar7 * fVar20 - fStack_4c;
        fVar19 = (float)(int)uStack_2c * fVar20 - fStack_40;
        fVar18 = (float)iStack_5c * fVar20 - fStack_48;
        dVar15 = (double)(fVar17 * fVar17 + fVar19 * fVar19 + fVar18 * fVar18);
        FUN_017267a0();
        fVar14 = DAT_018ce2f8 / (float)dVar15;
        dVar15 = (double)(*(float *)((int)param_1 + 0x44) * *(float *)((int)param_1 + 0x44) +
                          *(float *)(param_1 + 9) * *(float *)(param_1 + 9) +
                         *(float *)((int)param_1 + 0x4c) * *(float *)((int)param_1 + 0x4c));
        FUN_017267a0();
        fVar16 = DAT_018ce2f8 / (float)dVar15;
        fVar20 = DAT_018df584;
        if (fVar19 * fVar14 * fVar16 * *(float *)((int)param_1 + 0x44) +
            fVar17 * fVar14 * fVar16 * *(float *)(param_1 + 9) +
            fVar18 * fVar14 * fVar16 * *(float *)((int)param_1 + 0x4c) < DAT_018e0010)
        goto LAB_006e5f10;
      }
      uVar10 = 1;
      goto LAB_006e6171;
    }
    iStack_5c = iStack_5c + 1;
    uStack_2c = CONCAT44(iVar8,(int)uStack_2c);
    iVar7 = iVar8;
    if ((iStack_5c <= iVar9) ||
       (uStack_2c._0_4_ = (int)uStack_2c + 1, uStack_2c = CONCAT44(iVar8,(int)uStack_2c),
       iStack_5c = iVar1, (int)uStack_2c <= iVar11)) goto LAB_006e5f10;
    iVar5 = iVar5 + 1;
    *piVar13 = iVar5;
    iStack_5c = *(int *)(param_1 + 4) - iVar5;
    uStack_14 = CONCAT44(*(int *)((int)param_1 + 0x1c) - iVar5,*(int *)(param_1 + 3) - iVar5);
    uStack_2c = uStack_14;
  } while( true );
}



/* FUNCTION 9482 ; VA 0x006e6190 ; FUN_006e6190 */

int FUN_006e6190(int param_1,int param_2,int param_3,int param_4,int param_5,int param_6)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  uVar3 = param_2 - param_5 >> 0x1f;
  iVar4 = (param_2 - param_5 ^ uVar3) - uVar3;
  uVar3 = param_3 - param_6 >> 0x1f;
  iVar2 = (param_3 - param_6 ^ uVar3) - uVar3;
  uVar3 = param_1 - param_4 >> 0x1f;
  iVar1 = (param_1 - param_4 ^ uVar3) - uVar3;
  if (iVar4 <= iVar1) {
    iVar4 = iVar1;
  }
  if (iVar2 <= iVar4) {
    iVar2 = iVar4;
  }
  return iVar2;
}



/* FUNCTION 9483 ; VA 0x006e61e0 ; FUN_006e61e0 */

int __fastcall FUN_006e61e0(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar2 = *(int *)(param_1 + 0x34);
  if (*(int *)(param_1 + 0x30) <= *(int *)(param_1 + 0x34)) {
    iVar2 = *(int *)(param_1 + 0x30);
  }
  iVar1 = *(int *)(param_1 + 0x38);
  if (*(int *)(param_1 + 0x38) <= iVar2) {
    iVar1 = iVar2;
  }
  return iVar1;
}



/* FUNCTION 9484 ; VA 0x006e6200 ; FUN_006e6200 */

void __thiscall FUN_006e6200(byte *param_1,int *param_2,uint *param_3)

{
  int *piVar1;
  undefined uVar2;
  int iVar3;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined2 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a96a8;
  pvStack_10 = ExceptionList;
  iVar3 = (*param_3 >> 3) + *param_3;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&iStack_14,iVar3,param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (iStack_14 == 0) {
    puStack_1c = (undefined4 *)0x0;
    uStack_20 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
    uStack_8 = 0;
    uStack_18 = 0;
    puStack_1c = (undefined4 *)FUN_01674e20(0xc);
    uStack_18 = 0x101;
    *puStack_1c = 0;
    puStack_1c[1] = 0;
    puStack_1c[2] = 0;
    puStack_1c[2] = *param_3;
    FUN_005d99d0(*(int *)(param_1 + 8) + 1);
    piVar1 = (int *)FUN_005c5550(&param_3,&uStack_20,iVar3);
    uVar2 = 1;
    iStack_14 = *piVar1;
    if (puStack_1c != (undefined4 *)0x0) {
      FUN_01674ea0(puStack_1c,0xc);
    }
  }
  else {
    uVar2 = 0;
  }
  *param_2 = iStack_14;
  *(undefined *)(param_2 + 1) = uVar2;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9485 ; VA 0x006e6300 ; FUN_006e6300 */

uint __thiscall FUN_006e6300(int param_1,undefined4 param_2)

{
  uint in_EAX;
  uint uVar1;
  
  if (*(char *)(*(int *)(param_1 + 0x128) + 0x1db8) == '\0') {
    FUN_006d9080();
    uVar1 = FUN_0071c520(*(undefined4 *)(param_1 + 0x128),param_2);
    return uVar1;
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 9486 ; VA 0x006e6340 ; FUN_006e6340 */

undefined __thiscall FUN_006e6340(int param_1,uint param_2)

{
  uint uVar1;
  char cVar2;
  int iVar3;
  int iStack_8;
  
  uVar1 = param_2;
  iVar3 = param_1 + 0x135 + (uint)*(byte *)(param_1 + 0x134);
  iStack_8 = param_1;
  FUN_00606ea0(&iStack_8,(param_2 >> 3) + param_2,&param_2,-(uint)(iVar3 != 0) & iVar3 + 1U);
  if (iStack_8 == 0) {
    cVar2 = FUN_00621090(uVar1);
    if (cVar2 == '\0') {
      return 0;
    }
  }
  return 1;
}



/* FUNCTION 9487 ; VA 0x006e63b0 ; FUN_006e63b0 */

float10 __fastcall FUN_006e63b0(float *param_1)

{
  double dVar1;
  
  dVar1 = (double)(*param_1 * *param_1 + param_1[1] * param_1[1] + param_1[2] * param_1[2]);
  FUN_017267a0();
  return (float10)(float)dVar1;
}



/* FUNCTION 9488 ; VA 0x006e6400 ; FUN_006e6400 */

void __thiscall FUN_006e6400(int param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iStack_8;
  
  if (*(char *)(param_1 + 0x1d4) != '\0') {
    iVar3 = *param_2;
    if ((iVar3 == 0) ||
       (iVar1 = *(int *)(iVar3 + 0xc), iStack_8 = param_1, iVar2 = FUN_00aff8c0(),
       (uint)*(ushort *)(iVar2 + 0x1da) <
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) {
      iVar3 = 0;
    }
    if (iVar3 != 0) {
      iStack_8 = iVar3;
      FUN_006e5160(&iStack_8);
      FUN_006e5160(&iStack_8);
    }
    iStack_8 = param_1;
    FUN_006e1830(&iStack_8);
    return;
  }
  return;
}



/* FUNCTION 9489 ; VA 0x006e6480 ; FUN_006e6480 */

undefined4 * __thiscall FUN_006e6480(int *param_1,int *param_2)

{
  int *piVar1;
  byte *pbVar2;
  char cVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  int *piVar10;
  int iStack_6c;
  undefined8 uStack_68;
  undefined4 *puStack_60;
  undefined8 *puStack_5c;
  undefined8 uStack_58;
  undefined4 *puStack_50;
  undefined8 uStack_4c;
  int iStack_44;
  code *pcStack_40;
  uint uStack_3c;
  int *piStack_38;
  uint uStack_34;
  int *piStack_30;
  int *piStack_2c;
  byte *pbStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a96ea;
  pvStack_10 = ExceptionList;
  piVar4 = (int *)ExceptionList;
  if (*(char *)(param_1 + 0x75) != '\0') {
    ExceptionList = &pvStack_10;
    uStack_18 = FUN_006d9080();
    piVar4 = *(int **)((int)param_2 + 4);
    piStack_30 = *(int **)((int)param_2 + 8);
    piStack_14 = piVar4;
    if (piVar4 != piStack_30) {
      do {
        iStack_24 = piVar4[2];
        pbStack_28 = (byte *)piVar4[1];
        iStack_20 = *piVar4;
        uVar7 = iStack_20 - param_1[0x61] >> 0x1f;
        iStack_1c = (iStack_20 - param_1[0x61] ^ uVar7) - uVar7;
        uVar7 = (int)pbStack_28 - param_1[0x62] >> 0x1f;
        iVar6 = ((int)pbStack_28 - param_1[0x62] ^ uVar7) - uVar7;
        uVar7 = iStack_24 - param_1[99] >> 0x1f;
        iVar9 = param_1[0x66];
        iVar8 = (iStack_24 - param_1[99] ^ uVar7) - uVar7;
        if (iStack_1c < iVar9) {
          if (iVar6 < iVar9) {
            if (iVar9 <= iVar8) goto LAB_006e653a;
LAB_006e657f:
            piStack_14 = piVar4;
            FUN_0071db40(param_1[0x4a],piVar4,1);
            uStack_34 = FUN_01674e20(200);
            uStack_8 = 0;
            if (uStack_34 == 0) {
              iStack_1c = 0;
            }
            else {
              iStack_44 = piVar4[2];
              uStack_4c = *(undefined8 *)piVar4;
              iStack_1c = FUN_006e1de0(param_1[0x4a],&uStack_4c,param_1);
            }
            uStack_8 = 0xffffffff;
            if (DAT_01eaf1fc != '\0') {
              FUN_01677520(DAT_01eaf1fc,
                           "Sending region (%d,%d,%d) with 0 instances (primitive callback entered close region)"
                           ,*piVar4,piVar4[1],piVar4[2]);
            }
            FUN_006b1f50(iStack_1c);
            param_1[0x5a] = param_1[0x5a] + 1;
          }
          else {
LAB_006e653e:
            piStack_14 = piVar4;
            if (iVar6 == iVar9) goto LAB_006e6544;
          }
        }
        else {
          piStack_14 = piVar4;
          if (iStack_1c == iVar9) {
LAB_006e653a:
            if (iVar9 <= iVar6) goto LAB_006e653e;
LAB_006e6544:
            if (((iVar8 < iVar9) || (piStack_14 = piVar4, iVar8 == iVar9)) &&
               ((iStack_20 < param_1[0x5b] ||
                ((piStack_14 = piVar4, iStack_20 == param_1[0x5b] &&
                 ((iStack_24 < param_1[0x5d] ||
                  ((iStack_24 == param_1[0x5d] && ((int)pbStack_28 <= param_1[0x5c]))))))))))
            goto LAB_006e657f;
          }
        }
        piVar4 = piStack_14 + 3;
        piStack_14 = piVar4;
      } while (piVar4 != piStack_30);
    }
    iVar9 = (int)param_2;
    piVar4 = *(int **)((int)param_2 + 0x10);
    if (DAT_01d5b9c8 == '\0') {
      if ((piVar4 != (int *)0x0) && (piVar4[0xd] != 0)) {
        puVar5 = (undefined4 *)FUN_00621090(piVar4);
        if ((char)puVar5 != '\0') {
          if (DAT_01d5b990 == '\0') {
            ExceptionList = pvStack_10;
            return puVar5;
          }
          piStack_30 = *(int **)(iVar9 + 0x10);
          iVar6 = FUN_006e4e20(&piStack_30);
          if (iVar6 == 0) {
            ExceptionList = pvStack_10;
            return (undefined4 *)0x0;
          }
        }
        iVar6 = (int)param_2;
        uStack_68 = *(undefined8 *)(iVar9 + 0x18);
        iStack_6c = iVar9 + 0x18;
        puStack_60 = *(undefined4 **)(iVar9 + 0x20);
        pbStack_28 = (byte *)(*(int *)(iVar9 + 0x2c) + 1);
        piStack_30 = (int *)(*(int *)(iVar9 + 0x28) + 1);
        iStack_24 = *(int *)(iVar9 + 0x24) + 1;
        while( true ) {
          if ((((int)uStack_68 == iStack_24) && (uStack_68._4_4_ == piStack_30)) &&
             ((byte *)puStack_60 == pbStack_28)) {
            ExceptionList = pvStack_10;
            return piStack_30;
          }
          uStack_4c = uStack_68;
          iStack_44 = (int)puStack_60;
          cVar3 = FUN_0071c520(param_1[0x4a],&uStack_4c);
          if (cVar3 != '\0') break;
          FUN_00ca2620();
        }
        if ((DAT_01d5b990 != '\0') &&
           (iVar9 = FUN_008f7870(*(undefined4 *)(iVar6 + 0x10)), iVar9 != 0)) {
          uStack_34 = *(uint *)(iVar6 + 0x14);
          if (uStack_34 != 0) {
            LOCK();
            *(int *)(uStack_34 + 4) = *(int *)(uStack_34 + 4) + 1;
            UNLOCK();
            uStack_34 = *(uint *)(iVar6 + 0x14);
          }
          piStack_38 = *(int **)(iVar6 + 0x10);
          uStack_8 = 2;
          FUN_006e3d10(&piStack_38);
          uStack_8 = 0xffffffff;
          FUN_00550b30();
        }
        if (DAT_01d5b9a0 != '\0') {
          if (*(int *)(iVar6 + 0x14) != 0) {
            LOCK();
            piVar4 = (int *)(*(int *)(iVar6 + 0x14) + 4);
            *piVar4 = *piVar4 + 1;
            UNLOCK();
          }
          puVar5 = (undefined4 *)
                   FUN_006e37c0(*(undefined4 *)(iVar6 + 0x10),*(undefined4 *)(iVar6 + 0x14));
          ExceptionList = pvStack_10;
          return puVar5;
        }
        if (*(int *)(iVar6 + 0x14) == 0) {
          piVar10 = (int *)0x0;
        }
        else {
          LOCK();
          piVar4 = (int *)(*(int *)(iVar6 + 0x14) + 4);
          *piVar4 = *piVar4 + 1;
          UNLOCK();
          piVar10 = *(int **)((int)param_2 + 0x14);
        }
        param_2 = *(int **)((int)param_2 + 0x10);
        uStack_8 = 3;
        if (piVar10 != (int *)0x0) {
          LOCK();
          piVar10[1] = piVar10[1] + 1;
          UNLOCK();
        }
        piStack_2c = param_2;
        pbStack_28 = (byte *)piVar10;
        FUN_006e3980(param_2,piVar10);
        if (DAT_01d5b990 != '\0') {
          piStack_30 = param_2;
          FUN_006e5160(&piStack_30);
        }
        pcStack_40 = FUN_006e3980;
        uStack_3c = 0;
        piStack_38 = param_1;
        piVar4 = (int *)FUN_00677470(&pcStack_40);
        if (piVar10 != (int *)0x0) {
          LOCK();
          piVar1 = piVar10 + 1;
          iVar9 = *piVar1;
          piVar4 = (int *)*piVar1;
          *piVar1 = iVar9 + -1;
          UNLOCK();
          if (iVar9 + -1 == 0) {
            piVar4 = (int *)(**(code **)*piVar10)();
            LOCK();
            piVar1 = piVar10 + 2;
            iVar9 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar9 == 1) {
              piVar4 = (int *)(**(code **)(*piVar10 + 4))();
            }
          }
        }
      }
    }
    else if (((piVar4 != (int *)0x0) && (piVar4[0xd] != 0)) &&
            (piVar4 = (int *)FUN_00621090(piVar4), (char)piVar4 == '\0')) {
      pbStack_28 = (byte *)(param_1 + 0x9b);
      param_2 = *(int **)(iVar9 + 0x10);
      iVar6 = (int)param_1 + *(byte *)(param_1 + 0x9b) + 0x26d;
      piVar4 = (int *)FUN_00606ea0(&piStack_30,((uint)param_2 >> 3) + *(int *)(iVar9 + 0x10),
                                   &param_2,-(uint)(iVar6 != 0) & iVar6 + 1U);
      if ((piStack_30 == (int *)0x0) &&
         (piVar4 = (int *)FUN_008f7870(*(undefined4 *)(iVar9 + 0x10)), piVar4 != (int *)0x0)) {
        puStack_50 = *(undefined4 **)(iVar9 + 0x20);
        puStack_5c = (undefined8 *)(iVar9 + 0x18);
        uStack_58 = *puStack_5c;
        FUN_006e4fd0(&iStack_6c);
        while( true ) {
          if ((int)uStack_58 == (int)uStack_68) {
            if (((int *)uStack_58._4_4_ == uStack_68._4_4_) && (puStack_50 == puStack_60)) {
              ExceptionList = pvStack_10;
              return puStack_60;
            }
          }
          cVar3 = FUN_0071c520(param_1[0x4a],&uStack_58);
          pbVar2 = pbStack_28;
          if (cVar3 != '\0') break;
          FUN_00ca2620();
        }
        param_2 = *(int **)(iVar9 + 0x10);
        iVar9 = ((uint)param_2 >> 3) + (int)param_2;
        piVar4 = (int *)FUN_00606ea0(&piStack_30,iVar9,&param_2,
                                     -(uint)(pbStack_28 + *pbStack_28 + 1 != (byte *)0x0) &
                                     (uint)(pbStack_28 + *pbStack_28 + 1 + 1));
        if (piStack_30 == (int *)0x0) {
          piStack_38 = (int *)0x0;
          uStack_3c = -(uint)(pbVar2 != (byte *)0xfffffffd) & (uint)(pbVar2 + 4);
          uStack_8 = 1;
          uStack_34 = uStack_34 & 0xffff0000;
          piStack_38 = (int *)FUN_01674e20(0xc);
          uStack_34 = CONCAT22(uStack_34._2_2_,0x101);
          *piStack_38 = 0;
          piStack_38[1] = 0;
          piStack_38[2] = (int)param_2;
          FUN_005d99d0(*(int *)(pbVar2 + 8) + 1);
          FUN_005c5550(&param_2,&uStack_3c,iVar9);
          piVar4 = piStack_38;
          if (piStack_38 != (int *)0x0) {
            puVar5 = (undefined4 *)FUN_01674ea0(piStack_38,0xc);
            ExceptionList = pvStack_10;
            return puVar5;
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 9490 ; VA 0x006e6a10 ; FUN_006e6a10 */

void __fastcall FUN_006e6a10(int param_1)

{
  *(int *)(param_1 + 0x1f0) = *(int *)(param_1 + 0x1f0) + -1;
  return;
}



/* FUNCTION 9491 ; VA 0x006e6a20 ; FUN_006e6a20 */

void FUN_006e6a20(void)

{
  undefined auStack_c [8];
  
  FUN_006e6200(auStack_c,&stack0x00000004);
  return;
}



/* FUNCTION 9492 ; VA 0x006e6a40 ; FUN_006e6a40 */

void __thiscall FUN_006e6a40(int param_1,uint param_2,int *param_3)

{
  int iVar1;
  char cVar2;
  uint *puVar3;
  int iVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined auStack_1c [8];
  undefined auStack_14 [4];
  uint uStack_10;
  int iStack_c;
  uint uStack_8;
  
  if ((char)param_3 == '\0') {
    if (DAT_01d5b9c0 != '\0') {
      FUN_006d9080();
      puVar3 = (uint *)FUN_0071bd70(param_2);
      uStack_8 = 0;
      param_3 = (int *)*puVar3;
      uStack_10 = (uint)((int)puVar3[1] + (3 - (int)param_3)) >> 2;
      if ((int *)puVar3[1] < param_3) {
        uStack_10 = 0;
      }
      if (uStack_10 != 0) {
        do {
          iVar5 = *param_3;
          if ((iVar5 == 0) ||
             (iVar1 = *(int *)(iVar5 + 0xc), iVar4 = FUN_00aff8c0(),
             (uint)*(ushort *)(iVar4 + 0x1da) <
             (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
            iVar5 = 0;
          }
          iStack_c = iVar5;
          if ((iVar5 != 0) && (cVar2 = FUN_00621090(iVar5), cVar2 != '\0')) {
            FUN_006e6200(auStack_1c,&iStack_c);
          }
          uStack_8 = uStack_8 + 1;
          param_3 = param_3 + 1;
        } while (uStack_8 != uStack_10);
      }
      FUN_006e5160(&param_2);
    }
    FUN_006e5160(&param_2);
  }
  else if ((DAT_01d5b9c0 != '\0') &&
          (iVar5 = param_1 + 0x23d + (uint)*(byte *)(param_1 + 0x23c),
          FUN_00606ea0(&param_3,(param_2 >> 3) + param_2,&param_2,-(uint)(iVar5 != 0) & iVar5 + 1U),
          param_3 != (int *)0x0)) {
    if (param_3[5] == 0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6 = *(undefined4 **)(param_3[8] + param_3[4] * 4);
    }
    for (; puVar6 != (undefined4 *)0x0; puVar6 = (undefined4 *)*puVar6) {
      param_3 = (int *)puVar6[2];
      cVar2 = FUN_00621090(param_3);
      if (cVar2 != '\0') {
        FUN_006e6200(auStack_14,&param_3);
      }
    }
    FUN_006e5080(&param_2);
    return;
  }
  return;
}



/* FUNCTION 9493 ; VA 0x006e6bf0 ; FUN_006e6bf0 */

undefined4 __thiscall FUN_006e6bf0(undefined4 param_1,int param_2)

{
  int iVar1;
  int iVar2;
  
  if (param_2 != 0) {
    iVar1 = *(int *)(param_2 + 0xc);
    iVar2 = FUN_005edd10();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      FUN_006f3290(param_1);
    }
  }
  return 1;
}



/* FUNCTION 9494 ; VA 0x006e6c40 ; FUN_006e6c40 */

undefined4 __thiscall FUN_006e6c40(undefined4 param_1,int param_2)

{
  int iVar1;
  int iVar2;
  
  if (param_2 != 0) {
    iVar1 = *(int *)(param_2 + 0xc);
    iVar2 = FUN_005edd10();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      FUN_006f32c0(param_1);
    }
  }
  return 1;
}



/* FUNCTION 9495 ; VA 0x006e6c90 ; FUN_006e6c90 */

undefined4 __thiscall FUN_006e6c90(undefined4 param_1,int param_2)

{
  int iVar1;
  int iVar2;
  
  if (param_2 != 0) {
    iVar1 = *(int *)(param_2 + 0xc);
    iVar2 = FUN_005edd10();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      FUN_006f3550(param_1);
    }
  }
  return 1;
}



/* FUNCTION 9496 ; VA 0x006e6ce0 ; FUN_006e6ce0 */

undefined4 __thiscall FUN_006e6ce0(undefined4 param_1,int param_2)

{
  int iVar1;
  int iVar2;
  
  if (param_2 != 0) {
    iVar1 = *(int *)(param_2 + 0xc);
    iVar2 = FUN_005edd10();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      FUN_006f3580(param_1);
    }
  }
  return 1;
}



/* FUNCTION 9497 ; VA 0x006e6d30 ; FUN_006e6d30 */

int * FUN_006e6d30(int *param_1)

{
  int iVar1;
  undefined8 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined auStack_24 [12];
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a9719;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = (undefined4 *)FUN_01674e20(0x20);
  if (puStack_18 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    puStack_18[1] = 0x14;
    puStack_18[2] = 1;
    puStack_18[3] = 0;
    *puStack_18 = RBX::Network::DeserializedStreamDataInfoItem::vftable;
    puStack_18[4] = 0;
    puStack_18[5] = 0;
    puStack_18[6] = 0;
    puStack_18[7] = 0;
    puVar4 = puStack_18;
  }
  *param_1 = 0;
  param_1[1] = 0;
  FUN_006e1040(puVar4,param_1);
  uStack_8 = 0;
  uStack_14 = 1;
  puVar2 = (undefined8 *)FUN_006acb50(auStack_24);
  iVar1 = *param_1;
  uVar3 = *(undefined4 *)(puVar2 + 1);
  *(undefined8 *)(iVar1 + 0x10) = *puVar2;
  *(undefined4 *)(iVar1 + 0x18) = uVar3;
  uVar3 = FUN_006ac4d0();
  *(undefined4 *)(*param_1 + 0x1c) = uVar3;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9498 ; VA 0x006e6e20 ; FUN_006e6e20 */

int * FUN_006e6e20(int *param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  undefined8 *puVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined auStack_24 [4];
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  byte bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a9749;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  piStack_1c = (int *)FUN_01674e20(0x28);
  if (piStack_1c == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piStack_1c[1] = 0xd;
    piStack_1c[2] = 1;
    piStack_1c[3] = 0;
    *piStack_1c = (int)RBX::Network::DeserializedStreamDataItem::vftable;
    piStack_1c[4] = 0;
    piStack_1c[5] = 0;
    piStack_1c[6] = 0;
    piStack_1c[7] = 0;
    piStack_1c[8] = 0;
    piVar4 = piStack_1c;
  }
  *param_1 = 0;
  param_1[1] = 0;
  FUN_006e10d0(piVar4,param_1);
  uStack_8 = 0;
  uStack_18 = 1;
  bStack_11 = FUN_006abd90();
  uVar5 = FUN_006abd90();
  *(uint *)(*param_1 + 0x24) = (uint)bStack_11 + (uVar5 & 0xff) * 2;
  if (*(int *)(*param_1 + 0x24) == 0) {
    puVar6 = (undefined8 *)FUN_006acb50(auStack_24);
    uVar2 = *(undefined4 *)(puVar6 + 1);
    iVar8 = *param_1;
    *(undefined8 *)(iVar8 + 0x10) = *puVar6;
    *(undefined4 *)(iVar8 + 0x18) = uVar2;
  }
  puVar7 = (undefined4 *)FUN_006c30d0(auStack_20,param_2,param_3);
  iVar8 = puVar7[1];
  uVar2 = *puVar7;
  if (iVar8 != 0) {
    LOCK();
    *(int *)(iVar8 + 4) = *(int *)(iVar8 + 4) + 1;
    UNLOCK();
    iVar8 = puVar7[1];
  }
  iVar3 = *param_1;
  *(undefined4 *)(iVar3 + 0x1c) = uVar2;
  piVar4 = *(int **)(iVar3 + 0x20);
  *(int *)(iVar3 + 0x20) = iVar8;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar8 = piVar4[1] + -1;
    piVar4[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar8 = piVar4[2] + -1;
      piVar4[2] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar8 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar8 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9499 ; VA 0x006e6fa0 ; FUN_006e6fa0 */

int * FUN_006e6fa0(int *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined8 *puVar3;
  undefined4 uVar4;
  undefined auStack_24 [12];
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a9779;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = (undefined4 *)FUN_01674e20(0x24);
  if (puStack_18 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    puStack_18[1] = 0x18;
    puStack_18[2] = 1;
    puStack_18[3] = 0;
    *puStack_18 = RBX::Network::DeserializedStreamPrefetchDataInfoItem::vftable;
    puStack_18[4] = 0;
    puStack_18[5] = 0;
    puStack_18[6] = 0;
    puStack_18[7] = 0;
    puStack_18[8] = 0;
    puVar2 = puStack_18;
  }
  *param_1 = 0;
  param_1[1] = 0;
  FUN_006e1160(puVar2,param_1);
  uStack_8 = 0;
  uStack_14 = 1;
  puVar3 = (undefined8 *)FUN_006acb50(auStack_24);
  uVar4 = *(undefined4 *)(puVar3 + 1);
  iVar1 = *param_1;
  *(undefined8 *)(iVar1 + 0x10) = *puVar3;
  *(undefined4 *)(iVar1 + 0x18) = uVar4;
  uVar4 = FUN_006ac4d0();
  *(undefined4 *)(*param_1 + 0x1c) = uVar4;
  uVar4 = FUN_006ac4d0();
  *(undefined4 *)(*param_1 + 0x20) = uVar4;
  ExceptionList = pvStack_10;
  return param_1;
}


