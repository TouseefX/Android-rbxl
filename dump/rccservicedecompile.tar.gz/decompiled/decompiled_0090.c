/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 22500 ; VA 0x00ae0ac0 ; FUN_00ae0ac0 */

void __thiscall FUN_00ae0ac0(int param_1,int param_2)

{
  bool bVar1;
  
  if (*(int *)(param_1 + 0x118) != param_2) {
    if ((param_2 == 5) || (*(int *)(param_1 + 0x118) == 5)) {
      bVar1 = true;
    }
    else {
      bVar1 = false;
    }
    *(int *)(param_1 + 0x118) = param_2;
    if ((DAT_01d668e4 != '\0') && (bVar1)) {
      FUN_008a4940();
      return;
    }
  }
  return;
}



/* FUNCTION 22501 ; VA 0x00ae0b10 ; FUN_00ae0b10 */

void __thiscall FUN_00ae0b10(int param_1,undefined4 param_2)

{
  if (*(char *)(param_1 + 0xb0) != (char)param_2) {
    FUN_00fe9af0(param_2);
    FUN_008a4940(&DAT_021287a0);
  }
  return;
}



/* FUNCTION 22502 ; VA 0x00ae0b40 ; FUN_00ae0b40 */

void __thiscall FUN_00ae0b40(int param_1,float param_2)

{
  float fVar1;
  double dVar2;
  
  fVar1 = 0.0;
  if (0.0 <= param_2) {
    fVar1 = param_2;
  }
  dVar2 = (double)fVar1;
  if ((NAN(*(double *)(param_1 + 0x130)) || NAN(dVar2)) == (*(double *)(param_1 + 0x130) == dVar2))
  {
    *(double *)(param_1 + 0x130) = dVar2;
    FUN_00fe9b50(dVar2);
    FUN_008a4940();
    FUN_008a4940();
  }
  return;
}



/* FUNCTION 22503 ; VA 0x00ae0ba0 ; FUN_00ae0ba0 */

void __thiscall FUN_00ae0ba0(int param_1,float param_2)

{
  float fVar1;
  
  fVar1 = 0.0;
  if (0.0 <= param_2) {
    fVar1 = param_2;
  }
  if ((NAN((float)*(double *)(param_1 + 0xa0)) || NAN(fVar1)) ==
      ((float)*(double *)(param_1 + 0xa0) == fVar1)) {
    FUN_00fe9bc0((double)fVar1);
    FUN_008a4940();
    FUN_008a4940();
  }
  return;
}



/* FUNCTION 22504 ; VA 0x00ae0c00 ; FUN_00ae0c00 */

void __thiscall FUN_00ae0c00(int param_1,float param_2)

{
  float fVar1;
  float fVar2;
  
  fVar1 = 0.0;
  if (0.0 <= param_2) {
    fVar1 = param_2;
  }
  fVar2 = DAT_019011dc;
  if (fVar1 <= DAT_019011dc) {
    fVar2 = fVar1;
  }
  if ((NAN((float)*(double *)(param_1 + 0x98)) || NAN(fVar2)) ==
      ((float)*(double *)(param_1 + 0x98) == fVar2)) {
    FUN_00fe9c30((double)fVar2);
    FUN_008a4940();
    FUN_008a4940();
  }
  return;
}



/* FUNCTION 22505 ; VA 0x00ae0c60 ; FUN_00ae0c60 */

void __thiscall FUN_00ae0c60(int param_1,undefined4 param_2)

{
  int iVar1;
  uint3 uVar2;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined *puStack_10;
  
  if ((char)param_2 != *(char *)(param_1 + 0x78)) {
    uStack_14 = param_2;
    uStack_18 = 0xae0c79;
    puStack_10 = (undefined *)param_1;
    FUN_00fe9c90();
    puStack_10 = &DAT_02128980;
    uStack_14 = 0xae0c85;
    FUN_008a4940();
    puStack_10 = (undefined *)0xae0c8d;
    iVar1 = FUN_005f7790();
    if (iVar1 != 0) {
      uVar2 = (uint3)((uint)iVar1 >> 8);
      if ((*(char *)(param_1 + 0x78) == '\0') && (*(char *)(param_1 + 0xce) == '\0')) {
        puStack_10 = (undefined *)((uint)uVar2 << 8);
      }
      else {
        puStack_10 = (undefined *)CONCAT31(uVar2,1);
      }
      FUN_0060dcd0(&uStack_18,param_1);
      FUN_00c26170();
    }
  }
  return;
}



/* FUNCTION 22506 ; VA 0x00ae0cd0 ; FUN_00ae0cd0 */

void __thiscall FUN_00ae0cd0(int param_1,undefined4 param_2)

{
  undefined uVar1;
  int iVar2;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  if ((char)param_2 != *(char *)(param_1 + 0x78)) {
    FUN_00ae0c60(param_2);
    iVar2 = *(int *)(param_1 + 0x11c);
    if (iVar2 == 4) {
      uVar1 = *(undefined *)(param_1 + 0x78);
      uStack_c = 0;
      uStack_8 = 0;
      FUN_005e6780(uVar1);
      FUN_0098a470(param_1,uVar1,&uStack_c);
      iVar2 = *(int *)(param_1 + 0x11c);
    }
    if ((iVar2 == 3) || ((iVar2 == 5 && (*(char *)(param_1 + 0x1a9) != '\0')))) {
      uVar1 = *(undefined *)(param_1 + 0x78);
      uStack_c = 0;
      uStack_8 = 0;
      FUN_005e6780(uVar1);
      FUN_0098a470(param_1,uVar1,&uStack_c);
    }
  }
  return;
}



/* FUNCTION 22507 ; VA 0x00ae0d90 ; FUN_00ae0d90 */

void __thiscall FUN_00ae0d90(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  
  piVar2 = param_3;
  if ((param_3 != (int *)0x0) &&
     (iVar1 = param_3[3], iVar3 = FUN_00ee4f90(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    piVar6 = (int *)param_1[1];
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    if (param_2 == (int *)0x0) {
      param_2 = (int *)&DAT_018e3e8c;
    }
    else {
      (**(code **)(*param_2 + 0x10))();
      param_2 = (int *)FUN_005543f0();
    }
    (**(code **)(*piVar2 + 0x10))();
    uVar4 = FUN_005543f0();
    (**(code **)(*param_1 + 0x4c))();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Expected %s got %s for %s:%s.",uVar5,uVar4,param_2,piVar6);
  }
  param_3 = piVar2;
  (**(code **)(*(int *)param_1[0xe] + 0x10))(param_2,&param_3);
  return;
}



/* FUNCTION 22508 ; VA 0x00ae0e40 ; FUN_00ae0e40 */

void __thiscall FUN_00ae0e40(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0x148) != param_2) {
    *(int *)(param_1 + 0x148) = param_2;
    FUN_00fe9cf0(param_2);
    FUN_008a4940(&DAT_02128680);
  }
  return;
}



/* FUNCTION 22509 ; VA 0x00ae0e80 ; FUN_00ae0e80 */

void __thiscall FUN_00ae0e80(int param_1,undefined4 *param_2,undefined4 param_3)

{
  int iVar1;
  char cVar2;
  
  cVar2 = FUN_00684460(param_1 + 0xac,param_2);
  if ((cVar2 == '\0') && (*(int *)(param_1 + 0xc4) == 4)) {
    *(undefined8 *)(param_1 + 0x2c) = 0;
    iVar1 = *(int *)(param_1 + 0xc4);
    if ((iVar1 != 6) &&
       ((*(undefined4 *)(param_1 + 0xc4) = 6, DAT_01d668e4 != '\0' && (iVar1 == 5)))) {
      FUN_008a4940(&DAT_021289f0);
    }
    FUN_008a4940(&DAT_021286c0);
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_0086f2f0(3,"Failed to load sound %s: %s",param_2,param_3);
  }
  return;
}



/* FUNCTION 22510 ; VA 0x00ae0f10 ; FUN_00ae0f10 */

int __thiscall FUN_00ae0f10(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  int *piVar8;
  int *piStack_30;
  int *piStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eacf9;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  iVar5 = FUN_00587490(&piStack_30);
  piVar8 = param_2;
  uStack_8 = 0;
  if (param_2 != piStack_30) {
    puVar6 = (undefined4 *)FUN_0060dcd0(auStack_28,param_2);
    iVar5 = puVar6[1];
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 8) = *(int *)(iVar5 + 8) + 1;
      UNLOCK();
      iVar5 = puVar6[1];
    }
    *(undefined4 *)(param_1 + 0x14c) = *puVar6;
    piVar3 = *(int **)(param_1 + 0x150);
    *(int *)(param_1 + 0x150) = iVar5;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar5 = piVar3[2] + -1;
      piVar3[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    piVar3 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_24[1] + -1;
      piStack_24[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (piVar8 == (int *)0x0) {
      FUN_01679490();
    }
    else {
      piStack_18 = piVar8 + 0x12;
      uStack_8._0_1_ = 1;
      uVar7 = FUN_01675290(DAT_02110da8);
      uStack_8._0_1_ = 2;
      uStack_20 = uVar7;
      piStack_24 = (int *)FUN_01674e20(0x1c);
      if (piStack_24 == (int *)0x0) {
        piVar8 = (int *)0x0;
      }
      else {
        *piStack_24 = 0;
        piStack_24[1] = 1;
        piStack_24[2] = (int)FUN_00adee70;
        piStack_24[3] = (int)_guard_check_icall;
        piStack_24[4] = 0;
        piStack_24[5] = (int)piStack_18;
        piStack_24[6] = iStack_14;
        piVar8 = piStack_24;
      }
      FUN_016797d0(piVar8);
      if (piVar8 != (int *)0x0) {
        LOCK();
        piVar8[1] = piVar8[1] + 1;
        UNLOCK();
      }
      uStack_1c = 1;
      uStack_8._0_1_ = 3;
      param_2 = piVar8;
      FUN_01675290(uVar7);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      cVar4 = FUN_01679300(&param_2);
      if (cVar4 != '\0') {
        FUN_01679490();
        FUN_016791c0(&param_2);
      }
      uStack_8 = uStack_8 & 0xffffff00;
      if (param_2 != (int *)0x0) {
        piVar8 = param_2 + 1;
        LOCK();
        iVar5 = *piVar8;
        *piVar8 = *piVar8 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          FUN_01674ea0(param_2);
        }
      }
    }
    FUN_00ae1900();
    iVar5 = FUN_008a4940(&DAT_02128bb0);
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piVar8 = piStack_2c + 1;
    iVar2 = *piVar8;
    iVar5 = *piVar8;
    *piVar8 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piStack_2c)();
      LOCK();
      piVar8 = piStack_2c + 2;
      iVar2 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 22511 ; VA 0x00ae1110 ; FUN_00ae1110 */

void __thiscall FUN_00ae1110(int param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017ead28;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar3 = FUN_00684460(&param_2,(undefined4 *)(param_1 + 0x100));
  if (cVar3 == '\0') goto LAB_00ae1261;
  if ((undefined4 **)(param_1 + 0x100) != &param_2) {
    puVar4 = &param_2;
    if (0xf < in_stack_00000018) {
      puVar4 = param_2;
    }
    FUN_005542c0(puVar4,in_stack_00000014);
  }
  *(undefined4 *)(param_1 + 0x120) = 0;
  FUN_00fe9720();
  iVar1 = *(int *)(param_1 + 0x118);
  iVar2 = *(int *)(param_1 + 0x110);
  switch(iVar1) {
  case 0:
    if (iVar2 != 0) {
      uVar5 = 2;
LAB_00ae124e:
      FUN_00ae0ac0(uVar5);
    }
    break;
  case 1:
  case 3:
  case 4:
  case 5:
  case 6:
    if (iVar2 == 0) {
      if (((iVar1 != 1) && (*(undefined4 *)(param_1 + 0x118) = 1, DAT_01d668e4 != '\0')) &&
         (iVar1 == 5)) {
        FUN_008a4940(&DAT_021289f0);
      }
    }
    else {
      if (((iVar1 != 3) && (*(undefined4 *)(param_1 + 0x118) = 3, DAT_01d668e4 != '\0')) &&
         (iVar1 == 5)) {
        FUN_008a4940(&DAT_021289f0);
      }
      puVar4 = DAT_0212848c;
      if (0xf < (uint)DAT_0212848c[5]) {
        puVar4 = (undefined4 *)*DAT_0212848c;
      }
      FUN_0054eff0(puVar4);
      iStack_8._0_1_ = 1;
      uVar5 = FUN_00d10320(param_1,auStack_28);
      iStack_8._0_1_ = 2;
      FUN_00adf860(uVar5);
      FUN_00637950();
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_005507b0();
    }
    break;
  case 2:
    if (iVar2 == 0) {
      uVar5 = 0;
      goto LAB_00ae124e;
    }
  }
  FUN_008a4940(&DAT_02128488);
LAB_00ae1261:
  if (0xf < in_stack_00000018) {
    uVar6 = in_stack_00000018 + 1;
    puVar4 = param_2;
    if (0xfff < uVar6) {
      puVar4 = (undefined4 *)param_2[-1];
      uVar6 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar4,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22512 ; VA 0x00ae12d0 ; FUN_00ae12d0 */

void __thiscall FUN_00ae12d0(int param_1,int param_2,undefined4 param_3,undefined4 *param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 in_stack_ffffffd8;
  uint in_stack_ffffffdc;
  char *pcVar4;
  undefined4 uVar5;
  undefined *puVar6;
  
  cVar3 = FUN_00684460(param_1 + 0xac,param_3);
  if ((cVar3 == '\0') && (*(int *)(param_1 + 0xc4) == 4)) {
    if (param_4[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    pcVar4 = (char *)0xae1334;
    FUN_00fe99b0(param_2,*param_4,param_4[1]);
    if (DAT_01ef8f4b != 0) {
      param_2 = param_1 + -0x54;
      in_stack_ffffffdc = (uint)DAT_01ef8f4b;
      pcVar4 = "Sound::setSuccessfullyLoadedSound(%p) fmodChannel(%p)";
      in_stack_ffffffd8 = 0xae1355;
      FUN_01677490(in_stack_ffffffdc,"Sound::setSuccessfullyLoadedSound(%p) fmodChannel(%p)",param_2
                   ,*(undefined4 *)(param_1 + 0x1c),0);
    }
    iVar2 = *(int *)(param_1 + 0x1c);
    if ((*(int *)(param_1 + 0xc4) != 5) &&
       (*(undefined4 *)(param_1 + 0xc4) = 5, DAT_01d668e4 != '\0')) {
      FUN_008a4940(&DAT_021289f0);
    }
    puVar6 = &DAT_021286c0;
    uVar5 = 0xae1394;
    FUN_008a4940(&DAT_021286c0);
    FUN_0054ef60(param_1 + 0xac);
    FUN_006ecaa0(in_stack_ffffffd8,in_stack_ffffffdc,pcVar4,param_2,uVar5,puVar6);
    if (iVar2 != 0) {
      FUN_00ae1830();
      FUN_00ae1900();
    }
  }
  return;
}



/* FUNCTION 22513 ; VA 0x00ae13d0 ; FUN_00ae13d0 */

void __thiscall FUN_00ae13d0(int param_1,double param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  *(double *)(param_1 + 0x128) = param_2;
  uVar4 = SUB84(param_2,0);
  uVar6 = (undefined4)((ulonglong)param_2 >> 0x20);
  if ((NAN(*(double *)(param_1 + 0x88)) || NAN(param_2)) == (*(double *)(param_1 + 0x88) == param_2)
     ) {
    FUN_00fe9d60(uVar4,uVar6);
    FUN_008a4940(&DAT_021286f8);
  }
  iVar1 = *(int *)(param_1 + 0x11c);
  if (iVar1 == 4) {
    uVar5 = (undefined4)*(undefined8 *)(param_1 + 0x128);
    uVar7 = (undefined4)((ulonglong)*(undefined8 *)(param_1 + 0x128) >> 0x20);
    uStack_c = 0;
    uStack_8 = 0;
    uVar2 = (undefined4)*(undefined8 *)(param_1 + 0x88);
    uVar3 = (undefined4)((ulonglong)*(undefined8 *)(param_1 + 0x88) >> 0x20);
    FUN_00997390(uVar2,uVar3,uVar5,uVar7);
    FUN_00ae0980(param_1,uVar2,uVar3,uVar5,uVar7,&uStack_c);
    iVar1 = *(int *)(param_1 + 0x11c);
  }
  if ((iVar1 == 3) || ((iVar1 == 5 && (*(char *)(param_1 + 0x1a9) != '\0')))) {
    uStack_c = 0;
    uVar2 = (undefined4)*(undefined8 *)(param_1 + 0x128);
    uVar3 = (undefined4)((ulonglong)*(undefined8 *)(param_1 + 0x128) >> 0x20);
    uStack_8 = 0;
    FUN_00997390(uVar4,uVar6,uVar2,uVar3);
    FUN_00ae0980(param_1,uVar4,uVar6,uVar2,uVar3,&uStack_c);
  }
  return;
}



/* FUNCTION 22514 ; VA 0x00ae1510 ; FUN_00ae1510 */

void __thiscall FUN_00ae1510(int param_1,undefined4 param_2,undefined8 *param_3)

{
  (**(code **)(param_1 + 0x10))(*param_3);
  return;
}



/* FUNCTION 22515 ; VA 0x00ae1540 ; FUN_00ae1540 */

void __thiscall FUN_00ae1540(int param_1,undefined4 param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eab78;
  pvStack_10 = ExceptionList;
  pcVar1 = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00add960(aiStack_28);
  uStack_8 = 0;
  (*pcVar1)(param_2,uVar2);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    iVar3 = aiStack_28[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_28[0] + -4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22516 ; VA 0x00ae15d0 ; FUN_00ae15d0 */

void __thiscall FUN_00ae15d0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00ae1680();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22517 ; VA 0x00ae1620 ; FUN_00ae1620 */

void __thiscall FUN_00ae1620(int param_1,float param_2)

{
  float fVar1;
  float fVar2;
  
  fVar1 = 0.0;
  if (0.0 <= param_2) {
    fVar1 = param_2;
  }
  fVar2 = DAT_018fde94;
  if (fVar1 <= DAT_018fde94) {
    fVar2 = fVar1;
  }
  if ((NAN((float)*(double *)(param_1 + 0x90)) || NAN(fVar2)) ==
      ((float)*(double *)(param_1 + 0x90) == fVar2)) {
    FUN_00fe9e70((double)fVar2);
    FUN_008a4940();
  }
  return;
}



/* FUNCTION 22518 ; VA 0x00ae1680 ; FUN_00ae1680 */

undefined * FUN_00ae1680(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ead4c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eebd74) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eebd74);
    if (DAT_01eebd74 == -1) {
      uStack_8 = 0;
      FUN_00fe8ba0();
      FUN_016f3654(&LAB_0188b810);
      FUN_016f37bf(&DAT_01eebd74);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eebd10;
}



/* FUNCTION 22519 ; VA 0x00ae1710 ; FUN_00ae1710 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00ae1710(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eebd94) {
    FUN_016f3809(&DAT_01eebd94);
    if (DAT_01eebd94 == -1) {
      _DAT_01eebd88 = FUN_005c65f0;
      _DAT_01eebd8c = FUN_005c93a0;
      _DAT_01eebd90 = FUN_005c77b0;
      FUN_016f37bf(&DAT_01eebd94);
    }
  }
  return &DAT_01eebd88;
}



/* FUNCTION 22520 ; VA 0x00ae1780 ; FUN_00ae1780 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00ae1780(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eebd84) {
    FUN_016f3809(&DAT_01eebd84);
    if (DAT_01eebd84 == -1) {
      _DAT_01eebd78 = FUN_005c65e0;
      _DAT_01eebd7c = FUN_005c65e0;
      _DAT_01eebd80 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eebd84);
    }
  }
  return &DAT_01eebd78;
}



/* FUNCTION 22521 ; VA 0x00ae17f0 ; FUN_00ae17f0 */

void __fastcall FUN_00ae17f0(int param_1)

{
  if (*(char *)(param_1 + 0x78) != '\0') {
    *(undefined4 *)(param_1 + 0x120) = 0;
    FUN_00adf0e0(param_1,3);
    FUN_00ae0cd0();
    FUN_00ae13d0(0);
  }
  return;
}



/* FUNCTION 22522 ; VA 0x00ae1830 ; FUN_00ae1830 */

void __fastcall FUN_00ae1830(undefined4 param_1)

{
  uint uVar1;
  int iVar2;
  int iStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ead68;
  pvStack_10 = ExceptionList;
  iStack_1c = 0;
  uStack_18 = 0;
  iStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00ade570(param_1,0,&iStack_1c);
  FUN_00fe9970(&iStack_1c);
  if (iStack_1c != 0) {
    FUN_00602e00(iStack_1c,uStack_18,&iStack_1c);
    uVar1 = ((iStack_14 - iStack_1c) / 0xc) * 0xc;
    iVar2 = iStack_1c;
    if (0xfff < uVar1) {
      iVar2 = *(int *)(iStack_1c + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iStack_1c - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22523 ; VA 0x00ae1900 ; FUN_00ae1900 */

int __fastcall FUN_00ae1900(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_30;
  int *piStack_2c;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ead88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 == 0) {
LAB_00ae196f:
    iVar3 = 0;
  }
  else {
    iVar3 = *(int *)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    if ((iVar3 != 0) && (param_1 = iVar3, ExceptionList = &pvStack_10, *(int *)(iVar3 + 0x34) != 0))
    {
      piStack_2c = (int *)0xae1937;
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
    }
    if (param_1 == 0) goto LAB_00ae196f;
    iVar3 = *(int *)(param_1 + 0xc);
    piStack_2c = (int *)0xae1949;
    iVar2 = FUN_008a8c30();
    if ((uint)*(ushort *)(iVar2 + 0x1da) <
        (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8)) goto LAB_00ae196f;
    piStack_2c = (int *)0xae196b;
    iVar3 = FUN_0068f660();
  }
  piStack_2c = &iStack_1c;
  uStack_30 = 0xae1980;
  FUN_00587490();
  uStack_8 = 0;
  if (iStack_1c == 0) {
    iVar2 = 0;
    if (iVar3 == 0) goto LAB_00ae19f2;
    if (*(int *)(iVar3 + 0x140) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(iVar3 + 0x140) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_30 = *(undefined4 *)(iVar3 + 0x13c);
    piStack_2c = *(int **)(iVar3 + 0x140);
  }
  else {
    piStack_2c = (int *)iStack_1c;
    uStack_30 = 0xae19c6;
    iVar2 = FUN_0068f720();
    if (iVar2 == iVar3) {
      FUN_00ee5560(&uStack_30);
    }
    else {
      if (iVar3 == 0) goto LAB_00ae19f2;
      FUN_00adf320(&uStack_30);
    }
  }
  iVar2 = FUN_00fe9890();
LAB_00ae19f2:
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar3 = *piVar1;
    iVar2 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      piStack_2c = (int *)0xae1a0b;
      iVar2 = (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        piStack_2c = (int *)0xae1a1a;
        iVar2 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 22524 ; VA 0x00ae1a30 ; FUN_00ae1a30 */

void __thiscall FUN_00ae1a30(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  uint3 uVar6;
  int *piVar5;
  undefined4 extraout_EDX;
  undefined4 in_stack_ffffff8c;
  undefined4 uVar7;
  undefined8 in_stack_ffffff90;
  undefined4 in_stack_ffffff98;
  undefined4 uStack_64;
  undefined *puStack_60;
  int iStack_5c;
  undefined auStack_50 [56];
  undefined4 uStack_18;
  undefined4 uStack_c;
  int iStack_8;
  
  if ((DAT_01d668ec != '\0') && (*(char *)(param_1 + 0x146) == '\0')) {
    puStack_60 = (undefined *)0xae1a52;
    iStack_5c = param_1;
    cVar1 = FUN_00fea670();
    if (cVar1 == '\0') {
      return;
    }
  }
  if (*(char *)(param_1 + 0xce) != '\0') {
    iStack_8 = *(int *)(param_1 + 0x34);
    if (iStack_8 != 0) {
      iVar4 = *(int *)(iStack_8 + 0xc);
      iStack_5c = 0xae1a80;
      iVar3 = FUN_00aff8c0();
      uVar7 = (undefined4)in_stack_ffffff90;
      if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) {
        iStack_5c = param_2;
        puStack_60 = (undefined *)0xae1aa7;
        iVar4 = FUN_00b077e0();
        puStack_60 = *(undefined **)(iVar4 + 0x2c);
        in_stack_ffffff98 = (undefined4)*(undefined8 *)(iVar4 + 0x24);
        uStack_64 = (undefined4)((ulonglong)*(undefined8 *)(iVar4 + 0x24) >> 0x20);
        in_stack_ffffff90 = CONCAT44(0xae1ac2,uVar7);
        FUN_00ae1ca0(in_stack_ffffff98);
        goto LAB_00ae1b41;
      }
    }
    uVar7 = (undefined4)in_stack_ffffff90;
    iStack_5c = *(undefined4 *)(param_1 + 0x34);
    puStack_60 = (undefined *)0xae1acc;
    iVar4 = FUN_00836510();
    if (iVar4 == 0) {
      uStack_c = 0;
      uStack_18 = 0;
      uStack_64 = 0;
      puStack_60 = (undefined *)0x0;
      iStack_5c = 0;
      in_stack_ffffff90 = 0;
      in_stack_ffffff8c = 0;
      in_stack_ffffff98 = 0;
      FUN_00fe9780(0,0,0);
    }
    else {
      iStack_5c = param_2;
      puStack_60 = auStack_50;
      uStack_64 = 0xae1adf;
      iVar4 = FUN_00d6c6c0();
      puStack_60 = *(undefined **)(iVar4 + 0x2c);
      in_stack_ffffff98 = (undefined4)*(undefined8 *)(iVar4 + 0x24);
      uStack_64 = (undefined4)((ulonglong)*(undefined8 *)(iVar4 + 0x24) >> 0x20);
      in_stack_ffffff90 = CONCAT44(0xae1afa,uVar7);
      FUN_00ae1ca0(in_stack_ffffff98);
    }
  }
LAB_00ae1b41:
  if (*(char *)(param_1 + 0x78) != '\0') {
    if (*(int *)(param_1 + 0x118) == 5) {
      puStack_60 = (undefined *)param_2;
      uStack_64 = 0xae1b63;
      iStack_5c = param_1;
      FUN_00fea2e0();
      cVar1 = *(char *)(param_1 + 0xcc);
      *(undefined *)(param_1 + 0xcc) = 0;
      cVar2 = *(char *)(param_1 + 0xcd);
      *(undefined *)(param_1 + 0xcd) = 0;
      if (cVar2 != '\0') {
        *(int *)(param_1 + 0x120) = *(int *)(param_1 + 0x120) + 1;
      }
      if (cVar1 != '\0') {
        piVar5 = (int *)(param_1 + 0x100);
        if (0xf < *(uint *)(param_1 + 0x114)) {
          piVar5 = (int *)*piVar5;
        }
        FUN_0054eff0(piVar5);
        in_stack_ffffff8c = 0xae1bb5;
        FUN_006ecaa0(in_stack_ffffff90,in_stack_ffffff98);
        iStack_5c = 0xae1bbd;
        iVar4 = FUN_005f7790();
        if (iVar4 != 0) {
          uVar6 = (uint3)((uint)iVar4 >> 8);
          if ((*(char *)(param_1 + 0x78) == '\0') && (*(char *)(param_1 + 0xce) == '\0')) {
            iStack_5c = (uint)uVar6 << 8;
          }
          else {
            iStack_5c = CONCAT31(uVar6,1);
          }
          in_stack_ffffff90 = CONCAT44(&uStack_64,0xae1be5);
          FUN_0060dcd0();
          in_stack_ffffff98 = 0xae1bef;
          FUN_00c26170();
        }
      }
      if (cVar2 != '\0') {
        piVar5 = (int *)(param_1 + 0x100);
        iStack_5c = *(undefined4 *)(param_1 + 0x120);
        if (0xf < *(uint *)(param_1 + 0x114)) {
          piVar5 = (int *)*piVar5;
        }
        FUN_0054eff0(piVar5);
        FUN_009f1b60(in_stack_ffffff8c,in_stack_ffffff90,in_stack_ffffff98);
      }
    }
    iStack_5c = param_3;
    puStack_60 = (undefined *)0x1;
    uStack_64 = 0xae1c2f;
    cVar2 = FUN_00adf410();
    puStack_60 = (undefined *)CONCAT31((int3)((uint)extraout_EDX >> 8),cVar2);
    cVar1 = *(char *)(param_1 + 0xce);
    uStack_64 = 0xae1c47;
    iStack_5c = param_1;
    FUN_00fe9d20();
    if (cVar2 != cVar1) {
      iStack_5c = 0xae1c57;
      iVar4 = FUN_005f7790();
      if (iVar4 != 0) {
        uVar6 = (uint3)((uint)iVar4 >> 8);
        if ((*(char *)(param_1 + 0x78) == '\0') && (*(char *)(param_1 + 0xce) == '\0')) {
          iStack_5c = (uint)uVar6 << 8;
        }
        else {
          iStack_5c = CONCAT31(uVar6,1);
        }
        FUN_0060dcd0();
        FUN_00c26170();
      }
    }
  }
  return;
}



/* FUNCTION 22525 ; VA 0x00ae1ca0 ; FUN_00ae1ca0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00ae1ca0(int param_1,float param_2,float param_3,float param_4,double *param_5)

{
  float fVar1;
  undefined8 uVar2;
  undefined4 uStack_8;
  
  uStack_8 = 0.0;
  if (*(char *)(param_1 + 0x144) == '\0') {
    uVar2 = 0;
  }
  else {
    fVar1 = (float)((DAT_018c0d60 / *param_5) * _DAT_0194be00);
    uStack_8 = (param_4 - *(float *)(param_1 + 0x140)) * fVar1;
    uVar2 = CONCAT44((param_3 - *(float *)(param_1 + 0x13c)) * fVar1,
                     (param_2 - *(float *)(param_1 + 0x138)) * fVar1);
  }
  *(ulonglong *)(param_1 + 0x138) = CONCAT44(param_3,param_2);
  *(float *)(param_1 + 0x140) = param_4;
  *(undefined *)(param_1 + 0x144) = 1;
  FUN_00fe9780(1,CONCAT44(param_3,param_2),param_4,uVar2,uStack_8);
  return;
}



/* FUNCTION 22526 ; VA 0x00ae1d70 ; FUN_00ae1d70 */

int * __thiscall
FUN_00ae1d70(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baf8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ae2430();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::LuaSourceContainer,bool>::
              GetSetImpl<bool_(__thiscall_RBX::LuaSourceContainer::*)(void)const_,void_(__thiscall_RBX::LuaSourceContainer::*)(bool)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::LuaSourceContainer,bool>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::LuaSourceContainer,bool>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22527 ; VA 0x00ae1e70 ; FUN_00ae1e70 */

undefined4 * __thiscall
FUN_00ae1e70(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined **ppuVar3;
  undefined4 auStack_a0 [2];
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eadb8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_40 = param_2;
  uStack_38 = 0;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_74 = 0;
      puStack_78 = &uStack_30;
      uStack_80 = CONCAT44(&param_6,0xae1edd);
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = CONCAT44(param_11,param_10);
    }
  }
  uVar1 = uStack_40;
  uStack_8._0_1_ = 1;
  puVar2 = param_1 + 2;
  uStack_60 = 0;
  if (uStack_38 != 0) {
    uStack_60 = uStack_38;
    if ((uStack_38 & 1) == 0) {
      puStack_78 = &uStack_58;
      uStack_74 = 0;
      uStack_80 = CONCAT44(&uStack_30,0xae1f29);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    else {
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
      uStack_48 = uStack_20;
    }
  }
  uStack_74 = param_11;
  uStack_8._0_1_ = 2;
  puStack_18 = (undefined *)auStack_a0;
  uStack_98 = 0;
  auStack_a0[0] = uVar1;
  puStack_78 = puVar2;
  puVar2 = auStack_a0;
  if (uStack_60 != 0) {
    uStack_98 = uStack_60;
    if ((uStack_60 & 1) == 0) {
      (**(code **)(uStack_60 & 0xfffffffe))(&uStack_58,&uStack_90,0);
      puVar2 = (undefined4 *)puStack_18;
    }
    else {
      uStack_90 = uStack_58;
      uStack_8c = uStack_54;
      uStack_88 = uStack_50;
      uStack_84 = uStack_4c;
      uStack_80 = uStack_48;
      puVar2 = auStack_a0;
    }
  }
  puStack_18 = (undefined *)puVar2;
  ppuVar3 = &PTR_FUN_0194c4c4;
  cStack_11 = FUN_00ae2780();
  uStack_8._0_1_ = 3;
  if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
     (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_58;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0xae1fb3);
    (**(code **)(uStack_60 & 0xfffffffe))();
  }
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_38 != 0) {
    if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_30;
      uStack_74 = 2;
      uStack_80 = CONCAT44(puStack_78,0xae1fee);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    uStack_38 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_6;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0xae201c);
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22528 ; VA 0x00ae2040 ; FUN_00ae2040 */

undefined4 __thiscall
FUN_00ae2040(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10)

{
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eadd8;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_34,0);
    }
    else {
      uStack_34 = param_6;
      uStack_30 = param_7;
      uStack_2c = param_8;
      uStack_28 = param_9;
      uStack_24 = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  FUN_00ae1e70();
  uStack_8 = 1;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    uStack_1c = 2;
    uStack_24 = CONCAT44(&param_6,&param_6);
    uStack_28 = 0xae20de;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22529 ; VA 0x00ae2100 ; FUN_00ae2100 */

undefined4 * __thiscall
FUN_00ae2100(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_0194c4e4;
  cVar3 = FUN_005918b0(param_2,param_3,param_4,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 22530 ; VA 0x00ae21f0 ; FUN_00ae21f0 */

undefined4 * __thiscall
FUN_00ae21f0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined4 param_6,int *param_7)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined **ppuVar5;
  undefined auStack_38 [8];
  int *piStack_30;
  int *piStack_24;
  undefined auStack_20 [8];
  int *piStack_18;
  int *piStack_c;
  undefined4 *puStack_8;
  
  puStack_8 = param_1;
  FUN_00ae3670(&param_2);
  *param_1 = 0;
  FUN_00ae3670(auStack_38);
  FUN_00ae3670(auStack_20);
  ppuVar5 = &PTR_FUN_0194c4dc;
  cVar4 = FUN_00ae28e0();
  if (cVar4 == '\0') {
    ppuVar5 = (undefined **)0x0;
  }
  *param_1 = ppuVar5;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_c[1] + -1;
    piStack_c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      iVar3 = piStack_c[2] + -1;
      piStack_c[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[2] + -1;
    piStack_18[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piStack_18 + 4))();
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_24[1] + -1;
    piStack_24[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar3 = piStack_24[2] + -1;
      piStack_24[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_30[2] + -1;
    piStack_30[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piStack_30 + 4))();
    }
  }
  piVar2 = param_7;
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar3 = param_7[1] + -1;
    param_7[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_7)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar2 = param_4 + 2;
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 22531 ; VA 0x00ae2310 ; FUN_00ae2310 */

undefined4 * __thiscall
FUN_00ae2310(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  *param_1 = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_0194c4ec;
  cVar3 = FUN_00ae2a30(param_2,param_3,param_4,param_5,param_6,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 22532 ; VA 0x00ae2430 ; FUN_00ae2430 */

undefined * FUN_00ae2430(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eadfc;
  pvStack_10 = ExceptionList;
  if (DAT_01eec048 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eec258) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eec258);
      if (DAT_01eec258 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"LuaSourceContainer",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_0188bdb0);
        FUN_016f37bf(&DAT_01eec258);
      }
    }
    DAT_01eec048 = &DAT_01eec050;
  }
  ExceptionList = pvStack_10;
  return DAT_01eec048;
}



/* FUNCTION 22533 ; VA 0x00ae2510 ; FUN_00ae2510 */

int __thiscall FUN_00ae2510(int *param_1,uint *param_2,undefined4 param_3)

{
  uint uVar1;
  int iVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint *puVar10;
  uint *puVar11;
  uint *puVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eae18;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  iVar5 = (int)param_2 - iVar2 >> 5;
  iVar6 = param_1[1] - iVar2 >> 5;
  if (iVar6 == 0x7ffffff) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar6 + 1;
  uVar9 = param_1[2] - iVar2 >> 5;
  uVar7 = uVar1;
  if ((uVar9 <= 0x7ffffff - (uVar9 >> 1)) && (uVar7 = (uVar9 >> 1) + uVar9, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  uVar9 = uVar7 << 5;
  if (uVar7 < 0x8000000) {
    if (0xfff < uVar9) goto LAB_00ae25a1;
    if (uVar9 == 0) {
      puVar11 = (uint *)0x0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      puVar11 = (uint *)FUN_01674e20(uVar9);
    }
  }
  else {
    uVar9 = 0xffffffff;
LAB_00ae25a1:
    uVar8 = uVar9 + 0x23;
    if (uVar8 <= uVar9) {
      uVar8 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    uVar9 = FUN_01674e20(uVar8);
    if (uVar9 == 0) goto LAB_00ae2772;
    puVar11 = (uint *)(uVar9 + 0x23 & 0xffffffe0);
    puVar11[-1] = uVar9;
  }
  uStack_8 = 0;
  puVar11[iVar5 * 8] = 0;
  FUN_005880d0(param_3);
  puVar3 = (uint *)param_1[1];
  if (param_2 == puVar3) {
    puVar12 = (uint *)*param_1;
    uStack_8._0_1_ = 1;
    puVar10 = puVar11;
    while (puVar12 != puVar3) {
      *puVar10 = 0;
      uVar9 = *puVar12;
      if (uVar9 == 0) {
LAB_00ae268b:
        puVar10 = puVar10 + 8;
        puVar12 = puVar12 + 8;
      }
      else {
        *puVar10 = uVar9;
        if ((uVar9 & 1) == 0) {
          (**(code **)(uVar9 & 0xfffffffe))(puVar12 + 2,puVar10 + 2,0);
          goto LAB_00ae268b;
        }
        uVar9 = puVar12[3];
        uVar8 = puVar12[4];
        uVar4 = puVar12[5];
        puVar10[2] = puVar12[2];
        puVar10[3] = uVar9;
        puVar10[4] = uVar8;
        puVar10[5] = uVar4;
        uVar9 = puVar12[7];
        puVar10[6] = puVar12[6];
        puVar10[7] = uVar9;
        puVar10 = puVar10 + 8;
        puVar12 = puVar12 + 8;
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_006ce110(puVar10,puVar10,param_1);
  }
  else {
    FUN_006d4080(*param_1,param_2,puVar11);
    FUN_006d4080(param_2,param_1[1],puVar11 + iVar5 * 8 + 8);
  }
  uStack_8 = 0xffffffff;
  if (*param_1 != 0) {
    FUN_006ce110(*param_1,param_1[1],param_1);
    iVar2 = *param_1;
    uVar9 = param_1[2] - iVar2 & 0xffffffe0;
    iVar6 = iVar2;
    if (0xfff < uVar9) {
      iVar6 = *(int *)(iVar2 + -4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (iVar2 - iVar6) - 4U) {
LAB_00ae2772:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar9);
  }
  *param_1 = (int)puVar11;
  param_1[1] = (int)(puVar11 + uVar1 * 8);
  param_1[2] = (int)(puVar11 + uVar7 * 8);
  ExceptionList = pvStack_10;
  return *param_1 + iVar5 * 0x20;
}



/* FUNCTION 22534 ; VA 0x00ae2748 ; Catch_All@00ae2748 */

void Catch_All_00ae2748(void)

{
  int unaff_EBP;
  
  FUN_006d3e10(*(undefined4 *)(unaff_EBP + -0x20),*(undefined4 *)(unaff_EBP + -0x28));
  FUN_0057d2b0(*(undefined4 *)(unaff_EBP + -0x30),*(undefined4 *)(unaff_EBP + -0x24));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 22535 ; VA 0x00ae2780 ; FUN_00ae2780 */

undefined FUN_00ae2780(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined8 param_9,int *param_10)

{
  undefined4 uVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eae4f;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00585a40(&param_1);
  uVar1 = param_1;
  if (cVar2 == '\0') {
    uStack_34 = 0;
    if (param_3 != 0) {
      uStack_34 = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_2c,0);
      }
      else {
        uStack_2c = param_5;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
      }
    }
    uStack_8._0_1_ = 1;
    puVar4 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 2;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[2] = 0;
      if (uStack_34 != 0) {
        puVar4[2] = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,puVar4 + 4,0);
        }
        else {
          puVar4[4] = uStack_2c;
          puVar4[5] = uStack_28;
          puVar4[6] = uStack_24;
          puVar4[7] = uStack_20;
          *(undefined8 *)(puVar4 + 8) = uStack_1c;
        }
      }
    }
    *param_10 = (int)puVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
       (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  uStack_8 = 4;
  param_10._3_1_ = uVar3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_10._3_1_;
}



/* FUNCTION 22536 ; VA 0x00ae28e0 ; FUN_00ae28e0 */

undefined FUN_00ae28e0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
                      undefined4 param_5,int *param_6)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined uVar5;
  undefined auStack_34 [8];
  int *piStack_2c;
  int *piStack_20;
  undefined auStack_1c [8];
  int *piStack_14;
  int *piStack_8;
  
  FUN_00ae3670(&param_1);
  cVar4 = FUN_00585a40(auStack_1c);
  if (cVar4 == '\0') {
    FUN_00ae3670(auStack_1c);
    FUN_00ae3670(auStack_34);
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_20[1] + -1;
      piStack_20[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar3 = piStack_20[2] + -1;
        piStack_20[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        iVar3 = piStack_8[2] + -1;
        piStack_8[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[2] + -1;
      piStack_14[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
    uVar5 = 1;
  }
  else {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        iVar3 = piStack_8[2] + -1;
        piStack_8[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[2] + -1;
      piStack_14[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
    uVar5 = 0;
  }
  piVar2 = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar3 = param_6[1] + -1;
    param_6[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1 + -1;
      *piVar1 = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 2;
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return uVar5;
}



/* FUNCTION 22537 ; VA 0x00ae2a30 ; FUN_00ae2a30 */

undefined FUN_00ae2a30(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
                      int *param_5,undefined4 *param_6)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined uVar5;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  int *piStack_10;
  undefined4 uStack_c;
  int *piStack_8;
  
  uStack_18 = param_1;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_c = param_4;
  piStack_8 = param_5;
  cVar4 = FUN_00585a40(&uStack_18);
  piVar2 = piStack_8;
  if (cVar4 == '\0') {
    FUN_00ae36d0(&uStack_18);
    *param_6 = uStack_2c;
    param_6[1] = 0;
    param_6[2] = 0;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[2] = piStack_24[2] + 1;
      UNLOCK();
    }
    param_6[1] = uStack_28;
    param_6[2] = piStack_24;
    param_6[3] = 0;
    param_6[4] = 0;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    param_6[3] = uStack_20;
    param_6[4] = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar3 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_24[2] + -1;
      piStack_24[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
    piVar2 = piStack_8;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_10[2] + -1;
      piStack_10[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    uVar5 = 1;
  }
  else {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_10[2] + -1;
      piStack_10[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    uVar5 = 0;
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar3 = param_5[2] + -1;
      param_5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 2;
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return uVar5;
}



/* FUNCTION 22538 ; VA 0x00ae2be0 ; FUN_00ae2be0 */

undefined4 *
FUN_00ae2be0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10)

{
  uint uStack_74;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined8 uStack_5c;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eae80;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    uStack_34 = param_4;
    if ((param_4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_2c,0);
    }
    else {
      uStack_2c = param_6;
      uStack_28 = param_7;
      uStack_24 = param_8;
      uStack_20 = param_9;
      uStack_1c = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 1;
  uStack_74 = 0;
  if (uStack_34 != 0) {
    uStack_74 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_6c,0);
    }
    else {
      uStack_6c = uStack_2c;
      uStack_68 = uStack_28;
      uStack_64 = uStack_24;
      uStack_60 = uStack_20;
      uStack_5c = uStack_1c;
    }
  }
  uStack_8._0_1_ = 2;
  uStack_54 = 0;
  if (uStack_74 != 0) {
    uStack_54 = uStack_74;
    if ((uStack_74 & 1) == 0) {
      (**(code **)(uStack_74 & 0xfffffffe))(&uStack_6c,&uStack_4c,0);
    }
    else {
      uStack_4c = uStack_6c;
      uStack_48 = uStack_68;
      uStack_44 = uStack_64;
      uStack_40 = uStack_60;
      uStack_3c = uStack_5c;
    }
  }
  uStack_8._0_1_ = 3;
  if (((uStack_74 != 0) && ((uStack_74 & 1) == 0)) &&
     (*(code **)(uStack_74 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_74 & 0xfffffffe))(&uStack_6c,&uStack_6c,2);
  }
  uStack_8._0_1_ = 4;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uStack_34 = 0;
  }
  uStack_8._0_1_ = 5;
  *param_1 = param_2;
  param_1[2] = 0;
  if (uStack_54 != 0) {
    param_1[2] = uStack_54;
    if ((uStack_54 & 1) == 0) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,param_1 + 4,0);
    }
    else {
      param_1[4] = uStack_4c;
      param_1[5] = uStack_48;
      param_1[6] = uStack_44;
      param_1[7] = uStack_40;
      *(undefined8 *)(param_1 + 8) = uStack_3c;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (uStack_54 != 0) {
    if (((uStack_54 & 1) == 0) && (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_4c,2);
    }
    uStack_54 = 0;
  }
  uStack_8 = 7;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_4 & 0xfffffffe))(&param_6,&param_6,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22539 ; VA 0x00ae2df0 ; FUN_00ae2df0 */

undefined4 *
FUN_00ae2df0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  int iStack_c;
  
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  piVar1 = param_5 + 1;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00ae39a0(param_3,param_4,param_5,param_6,param_7,param_8);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      iVar2 = param_8[2] + -1;
      param_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (iStack_18 != 0) {
    LOCK();
    *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + 1;
    UNLOCK();
  }
  param_1[1] = uStack_1c;
  param_1[2] = iStack_18;
  param_1[3] = uStack_14;
  param_1[4] = 0;
  param_1[5] = 0;
  if (iStack_c != 0) {
    LOCK();
    *(int *)(iStack_c + 4) = *(int *)(iStack_c + 4) + 1;
    UNLOCK();
  }
  param_1[5] = iStack_c;
  param_1[4] = uStack_10;
  FUN_00a7c8d0();
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 22540 ; VA 0x00ae2f70 ; FUN_00ae2f70 */

undefined4 *
FUN_00ae2f70(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_c;
  int *piStack_8;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  piVar1 = param_4 + 2;
  if (param_4 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_008e7b50(param_3,param_4,param_5);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    piStack_8[2] = piStack_8[2] + 1;
    UNLOCK();
  }
  param_1[1] = uStack_c;
  param_1[2] = piStack_8;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_8[2] + -1;
    piStack_8[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_8 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 22541 ; VA 0x00ae3030 ; FUN_00ae3030 */

undefined4 *
FUN_00ae3030(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined4 param_6,int *param_7)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piStack_18;
  int *piStack_c;
  
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  puVar3 = (undefined4 *)FUN_00ae3730(param_3,param_4,param_5);
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = *puVar3;
  param_1[2] = puVar3[1];
  param_1[3] = puVar3[2];
  param_1[4] = 0;
  param_1[5] = 0;
  if (puVar3[4] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[4] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[4] = puVar3[3];
  param_1[5] = puVar3[4];
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[1] + -1;
    piStack_c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[2] + -1;
    piStack_18[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_18 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 22542 ; VA 0x00ae3180 ; FUN_00ae3180 */

undefined4 *
FUN_00ae3180(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,int *param_8)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piStack_14;
  int *piStack_c;
  
  if (param_8 != (int *)0x0) {
    LOCK();
    param_8[1] = param_8[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  puVar3 = (undefined4 *)FUN_00ae3870(param_3,param_4,param_5,param_6,param_7,param_8);
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = *puVar3;
  param_1[2] = puVar3[1];
  param_1[3] = 0;
  param_1[4] = 0;
  if (puVar3[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[3] = puVar3[2];
  param_1[4] = puVar3[3];
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[1] + -1;
    piStack_c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[2] + -1;
    piStack_14[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_14 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    iVar2 = param_8[1] + -1;
    param_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_8 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 22543 ; VA 0x00ae32c0 ; FUN_00ae32c0 */

undefined4 * __thiscall FUN_00ae32c0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c3f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  puVar3 = (undefined4 *)FUN_01674e20(0x24);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = 0;
    puVar3[1] = 1;
    puVar3[2] = FUN_00ae4280;
    puVar3[3] = FUN_0057e090;
    puVar3[4] = 0;
    puVar3[5] = param_1;
    puVar3[6] = *param_3;
    puVar3[7] = 0;
    puVar3[8] = 0;
    if (param_3[2] != 0) {
      LOCK();
      piVar1 = (int *)(param_3[2] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puVar3[7] = param_3[1];
    puVar3[8] = param_3[2];
  }
  FUN_016797d0(puVar3);
  *param_2 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    LOCK();
    puVar3[1] = puVar3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 22544 ; VA 0x00ae33b0 ; FUN_00ae33b0 */

void FUN_00ae33b0(int *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x58);
  if (puVar1 != (undefined4 *)0x0) {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count_obj<struct_RBX::LuaSourceContainer::LinkedScriptLoadData>::vftable;
    FUN_0170d1f0(puVar1 + 4,0,0x48);
    puVar1[4] = 0;
    puVar1[6] = 0;
    puVar1[0xe] = 0;
    puVar1[0xf] = 0;
    puVar1[0x11] = 0;
    puVar1[0x12] = 0;
    puVar1[0x13] = 0;
    puVar1[0x14] = 0;
    puVar1[0x15] = 0;
    param_1[1] = (int)puVar1;
    *param_1 = (int)(puVar1 + 4);
    return;
  }
  param_1[1] = 0;
  *param_1 = 0x10;
  return;
}



/* FUNCTION 22545 ; VA 0x00ae3450 ; FUN_00ae3450 */

void * __thiscall FUN_00ae3450(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  code *pcVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  void *pvVar10;
  int *piVar11;
  undefined4 *puVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a9308;
  puVar12 = *(undefined4 **)(param_1 + 0x2c);
  pvVar10 = ExceptionList;
  if (puVar12 != (undefined4 *)0x0) {
    piVar11 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar11 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar11[1] = piVar11[1] + 1;
      UNLOCK();
      piVar11 = *(int **)(param_1 + 0x30);
      puVar12 = *(undefined4 **)(param_1 + 0x2c);
    }
    puVar3 = (undefined4 *)puVar12[1];
    puVar12 = (undefined4 *)*puVar12;
    uStack_8 = 0;
    pvVar10 = pvStack_10;
    for (; puVar12 != puVar3; puVar12 = puVar12 + 2) {
      pcVar4 = (code *)*param_2;
      uVar5 = param_2[3];
      if (param_2[5] != 0) {
        LOCK();
        piVar1 = (int *)(param_2[5] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uVar6 = param_2[4];
      uVar7 = param_2[5];
      if (param_2[2] != 0) {
        LOCK();
        piVar1 = (int *)(param_2[2] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uVar8 = param_2[1];
      uVar9 = param_2[2];
      if (puVar12[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar12[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      (*pcVar4)(*puVar12,puVar12[1],uVar8,uVar9,uVar5,uVar6,uVar7);
      pvVar10 = (void *)FUN_00ae3450(param_2);
    }
    if (piVar11 != (int *)0x0) {
      LOCK();
      piVar1 = piVar11 + 1;
      iVar2 = *piVar1;
      pvVar10 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar10 = (void *)(**(code **)*piVar11)();
        LOCK();
        piVar1 = piVar11 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar10 = (void *)(**(code **)(*piVar11 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar10;
}



/* FUNCTION 22546 ; VA 0x00ae3590 ; FUN_00ae3590 */

undefined4 * __thiscall
FUN_00ae3590(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined8 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uStack_18 = param_5;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00ae2430();
  FUN_009cb970(uVar1,param_3,param_4,uStack_18,param_6);
  param_1[0xd] = param_2;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::LuaSourceContainer,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::LuaSourceContainer::*>
             ::vftable;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = 0;
    param_1[0xb] = 0;
    param_1[0xc] = 0;
  }
  uStack_8 = 1;
  FUN_0068a760();
  param_1[0xe] = param_8;
  param_1[0xf] = param_7;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::LuaSourceContainer,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::LuaSourceContainer::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22547 ; VA 0x00ae3670 ; FUN_00ae3670 */

undefined4 * __thiscall FUN_00ae3670(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = 0;
  param_1[5] = 0;
  if (param_2[5] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[5] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[4] = param_2[4];
  param_1[5] = param_2[5];
  return param_1;
}



/* FUNCTION 22548 ; VA 0x00ae36d0 ; FUN_00ae36d0 */

undefined4 * __thiscall FUN_00ae36d0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_2[4] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[4] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  return param_1;
}



/* FUNCTION 22549 ; VA 0x00ae3730 ; FUN_00ae3730 */

undefined4 * __thiscall
FUN_00ae3730(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    piVar1 = param_3 + 2;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_3 + 2;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  param_1[2] = param_4;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  param_1[3] = param_5;
  param_1[4] = param_6;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 22550 ; VA 0x00ae3870 ; FUN_00ae3870 */

int __thiscall
FUN_00ae3870(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,int *param_7)

{
  int *piVar1;
  int iVar2;
  
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piVar1 = param_3 + 2;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_008e7b50(param_2,param_3,param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  *(undefined4 *)(param_1 + 8) = param_6;
  *(int **)(param_1 + 0xc) = param_7;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_7)();
      LOCK();
      iVar2 = param_7[2] + -1;
      param_7[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 22551 ; VA 0x00ae39a0 ; FUN_00ae39a0 */

undefined4 * __thiscall
FUN_00ae39a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined4 param_6,int *param_7)

{
  int *piVar1;
  int iVar2;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  piVar1 = param_4 + 1;
  param_1[1] = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_3;
  param_1[1] = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  param_1[2] = param_5;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_7 != (int *)0x0) {
    LOCK();
    param_7[1] = param_7[1] + 1;
    UNLOCK();
  }
  param_1[3] = param_6;
  param_1[4] = param_7;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar2 = param_7[1] + -1;
    param_7[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 22552 ; VA 0x00ae3ac0 ; FUN_00ae3ac0 */

undefined4 * __fastcall FUN_00ae3ac0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eaef0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::LuaSourceContainer,class_RBX::Instance>::vftable;
  uVar1 = FUN_00ae2430();
  param_1[3] = uVar1;
  *param_1 = RBX::LuaSourceContainer::vftable;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  uStack_8._0_1_ = 6;
  uStack_8._1_3_ = 0;
  FUN_0054ef60(&DAT_01d66904);
  param_1[0x29] = 0;
  param_1[0x2a] = 0xf;
  *(undefined *)(param_1 + 0x25) = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  FUN_008866d0();
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  *(undefined2 *)(param_1 + 0x31) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22553 ; VA 0x00ae3bd0 ; FUN_00ae3bd0 */

void FUN_00ae3bd0(void)

{
  FUN_00a7c8d0();
  return;
}



/* FUNCTION 22554 ; VA 0x00ae3be0 ; FUN_00ae3be0 */

int __thiscall FUN_00ae3be0(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 22555 ; VA 0x00ae3c40 ; FUN_00ae3c40 */

int __thiscall FUN_00ae3c40(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x10);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  return param_1;
}



/* FUNCTION 22556 ; VA 0x00ae3ca0 ; FUN_00ae3ca0 */

void __fastcall FUN_00ae3ca0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006d2070();
  LOCK();
  iVar2 = *(int *)(param_1 + 0x48);
  *(int *)(param_1 + 0x48) = 0;
  UNLOCK();
  if (iVar2 != 0) {
    CloseHandle(iVar2);
  }
  piVar3 = *(int **)(param_1 + 0x3c);
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uVar4 = *(uint *)(param_1 + 0x18);
  uStack_8 = 0;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      if (*(code **)(uVar4 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar4 & 0xfffffffe))(param_1 + 0x20,param_1 + 0x20,2);
      }
    }
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22557 ; VA 0x00ae3d40 ; FUN_00ae3d40 */

int FUN_00ae3d40(undefined4 param_1,int *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  int aiStack_b4 [5];
  uint uStack_a0;
  uint uStack_9c;
  undefined4 uStack_8c;
  uint uStack_88;
  uint uStack_84;
  undefined4 uStack_74;
  uint uStack_70;
  undefined auStack_68 [16];
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined auStack_50 [16];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined auStack_38 [16];
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eb063;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00587490(&iStack_20);
  uStack_8._0_1_ = 2;
  if (iStack_20 != 0) {
    if (param_3 == 1) {
      if (*(int *)(iStack_20 + 0xb4) != 1) {
        *(undefined4 *)(iStack_20 + 0xb4) = 1;
        FUN_008a4940(&DAT_01eebde0);
      }
      uVar5 = FUN_00886c00(auStack_18,param_4);
      uStack_8._0_1_ = 3;
      cVar3 = FUN_008868d0(iStack_20 + 0xac);
      if (cVar3 != '\0') {
        FUN_00886840(uVar5);
        FUN_008a4940(&DAT_01eebda8);
      }
      FUN_0056e380();
      iVar4 = FUN_0056e380();
    }
    else {
      if (*(int *)(iStack_20 + 0xb4) != 2) {
        *(undefined4 *)(iStack_20 + 0xb4) = 2;
        FUN_008a4940(&DAT_01eebde0);
      }
      uStack_28 = 0;
      uStack_24 = 0xf;
      auStack_38[0] = 0;
      FUN_005542c0("LinkedSource",0xc);
      uStack_8._0_1_ = 4;
      FUN_00d10320(iStack_20,auStack_38);
      uStack_8._0_1_ = 6;
      FUN_005507b0();
      uStack_58 = 0;
      uStack_54 = 0xf;
      auStack_68[0] = 0;
      FUN_005542c0("Script doesn\'t exist.",0x15);
      uStack_8._0_1_ = 7;
      uStack_40 = 0;
      uStack_3c = 0xf;
      auStack_50[0] = 0;
      FUN_005542c0("Script",6);
      uStack_8._0_1_ = 8;
      FUN_008d2350(auStack_50,aiStack_b4,iStack_20 + 0x94,auStack_68);
      FUN_005507b0();
      iVar4 = FUN_005507b0();
      if (0xf < uStack_70) {
        uVar6 = uStack_70 + 1;
        uVar7 = uStack_84;
        if (0xfff < uVar6) {
          uVar7 = *(uint *)(uStack_84 - 4);
          uVar6 = uStack_70 + 0x24;
          if (0x1f < (uStack_84 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        iVar4 = FUN_01674ea0(uVar7,uVar6);
      }
      uStack_74 = 0;
      uStack_70 = 0xf;
      uStack_84 = uStack_84 & 0xffffff00;
      if (0xf < uStack_88) {
        uVar6 = uStack_88 + 1;
        uVar7 = uStack_9c;
        if (0xfff < uVar6) {
          uVar7 = *(uint *)(uStack_9c - 4);
          uVar6 = uStack_88 + 0x24;
          if (0x1f < (uStack_9c - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        iVar4 = FUN_01674ea0(uVar7,uVar6);
      }
      uStack_8c = 0;
      uStack_88 = 0xf;
      uStack_9c = uStack_9c & 0xffffff00;
      if (0xf < uStack_a0) {
        uVar7 = uStack_a0 + 1;
        iVar4 = aiStack_b4[0];
        if (0xfff < uVar7) {
          iVar4 = *(int *)(aiStack_b4[0] + -4);
          uVar7 = uStack_a0 + 0x24;
          if (0x1f < (aiStack_b4[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        iVar4 = FUN_01674ea0(iVar4,uVar7);
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)(*param_2 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 22558 ; VA 0x00ae4030 ; FUN_00ae4030 */

void FUN_00ae4030(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  undefined auStack_50 [8];
  undefined4 uStack_48;
  undefined **ppuStack_44;
  undefined *puStack_40;
  undefined *puStack_38;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017eb080;
  pvStack_10 = ExceptionList;
  uStack_24 = 1;
  uStack_28 = 0xae4056;
  ExceptionList = &pvStack_10;
  FUN_0151f360();
  iStack_8 = 0;
  puStack_18 = auStack_14;
  ppuStack_44 = &puStack_18;
  uStack_48 = 0xae4074;
  cVar1 = FUN_00585a40();
  if (cVar1 == '\0') {
    puStack_38 = puStack_18;
    puStack_40 = &DAT_0194c4cd;
  }
  else {
    puStack_40 = (undefined *)0x0;
  }
  ppuStack_44 = (undefined **)0x0;
  uStack_48 = param_2;
  iStack_8._0_1_ = 1;
  FUN_0060dcd0(auStack_50,param_1);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00ae4d60();
  uStack_24 = 0xae40c1;
  FUN_0151f430();
  uStack_24 = 0xae40c9;
  FUN_0151f390();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22559 ; VA 0x00ae40e0 ; FUN_00ae40e0 */

void FUN_00ae40e0(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  undefined auStack_50 [8];
  undefined4 uStack_48;
  undefined **ppuStack_44;
  undefined *puStack_40;
  undefined *puStack_38;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017eb080;
  pvStack_10 = ExceptionList;
  uStack_24 = 1;
  uStack_28 = 0xae4106;
  ExceptionList = &pvStack_10;
  FUN_0151f360();
  iStack_8 = 0;
  puStack_18 = auStack_14;
  ppuStack_44 = &puStack_18;
  uStack_48 = 0xae4124;
  cVar1 = FUN_00585a40();
  if (cVar1 == '\0') {
    puStack_38 = puStack_18;
    puStack_40 = &DAT_0194c4d5;
  }
  else {
    puStack_40 = (undefined *)0x0;
  }
  ppuStack_44 = (undefined **)0x0;
  uStack_48 = param_2;
  iStack_8._0_1_ = 1;
  FUN_0060dcd0(auStack_50,param_1);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_00ae4ff0();
  uStack_24 = 0xae4171;
  FUN_0151f430();
  uStack_24 = 0xae4179;
  FUN_0151f390();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22560 ; VA 0x00ae4190 ; FUN_00ae4190 */

void FUN_00ae4190(undefined4 param_1)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  int *piVar6;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (((DAT_01d680c8 != '\0') && (cVar2 = FUN_00585a40(), cVar2 != '\0')) &&
     (iVar3 = FUN_008f78c0(param_1), iVar3 != 0)) {
    FUN_005789c0(&DAT_01eaddf4,&LAB_00670c60);
    uVar4 = FUN_00675bb0();
    piVar5 = (int *)FUN_008aa140(uVar4);
    if (*piVar5 == 0) {
      uVar4 = FUN_00bfb200();
      piVar6 = (int *)FUN_008a9ba0(auStack_c,uVar4);
      iVar3 = *piVar6;
      iVar1 = piVar6[1];
      *piVar6 = 0;
      piVar6[1] = 0;
      *piVar5 = iVar3;
      piVar6 = (int *)piVar5[1];
      piVar5[1] = iVar1;
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar3 = piVar6[1] + -1;
        piVar6[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          iVar3 = piVar6[2] + -1;
          piVar6[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      if (piStack_8 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_8[1] + -1;
        piStack_8[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_8)();
          LOCK();
          piVar6 = piStack_8 + 2;
          iVar3 = *piVar6;
          *piVar6 = *piVar6 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piStack_8 + 4))();
          }
        }
      }
    }
    if (*piVar5 != 0) {
      FUN_00bfd140();
    }
  }
  return;
}



/* FUNCTION 22561 ; VA 0x00ae4280 ; FUN_00ae4280 */

int FUN_00ae4280(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pcVar3 = *(code **)(param_1 + 0x18);
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  if (*(int *)(param_1 + 0x20) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x20) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar4 = (*pcVar3)(*(undefined4 *)(param_1 + 0x1c),*(undefined4 *)(param_1 + 0x20),param_2,param_3)
  ;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 22562 ; VA 0x00ae4340 ; FUN_00ae4340 */

void __fastcall FUN_00ae4340(int param_1)

{
  undefined4 uVar1;
  
  (**(code **)(param_1 + 8))();
  uVar1 = (**(code **)(param_1 + 8))();
  FUN_00886890(uVar1);
  return;
}



/* FUNCTION 22563 ; VA 0x00ae4370 ; FUN_00ae4370 */

int __fastcall FUN_00ae4370(int param_1)

{
  return param_1 + 0xac;
}



/* FUNCTION 22564 ; VA 0x00ae4380 ; FUN_00ae4380 */

void FUN_00ae4380(void)

{
  int iVar1;
  
  if (DAT_01eec25c == 0) {
    iVar1 = FUN_00ae2430();
    DAT_01eec25c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 22565 ; VA 0x00ae43a0 ; FUN_00ae43a0 */

undefined4 FUN_00ae43a0(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00587490(auStack_c);
  uVar2 = *puVar4;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return uVar2;
  }
  return uVar2;
}



/* FUNCTION 22566 ; VA 0x00ae4410 ; thunk_FUN_00886d30 */

undefined * thunk_FUN_00886d30(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba0fc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ede734) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ede734);
    if (DAT_01ede734 == -1) {
      uStack_8 = 0;
      FUN_008866d0();
      FUN_016f3654(&LAB_01880820);
      FUN_016f37bf(&DAT_01ede734);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ede72c;
}



/* FUNCTION 22567 ; VA 0x00ae4420 ; FUN_00ae4420 */

int __fastcall FUN_00ae4420(int param_1)

{
  return param_1 + 0x7c;
}



/* FUNCTION 22568 ; VA 0x00ae4430 ; FUN_00ae4430 */

int __fastcall FUN_00ae4430(int param_1)

{
  return param_1 + 0x94;
}



/* FUNCTION 22569 ; VA 0x00ae4440 ; FUN_00ae4440 */

undefined4 __thiscall FUN_00ae4440(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  uVar1 = (**(code **)(param_1 + 8))();
  FUN_008866a0(uVar1);
  return param_2;
}



/* FUNCTION 22570 ; VA 0x00ae4460 ; FUN_00ae4460 */

void FUN_00ae4460(void)

{
  FUN_0151f3f0();
  return;
}



/* FUNCTION 22571 ; VA 0x00ae4470 ; FUN_00ae4470 */

void FUN_00ae4470(undefined4 *param_1)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  pcVar2 = (code *)*param_1;
  uVar3 = param_1[3];
  if (param_1[5] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[5] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar4 = param_1[4];
  uVar5 = param_1[5];
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(param_1[1],param_1[2],uVar3,uVar4,uVar5);
  return;
}



/* FUNCTION 22572 ; VA 0x00ae44e0 ; FUN_00ae44e0 */

void FUN_00ae44e0(undefined4 *param_1,undefined4 param_2)

{
  int *piVar1;
  code *pcVar2;
  
  pcVar2 = (code *)*param_1;
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(param_2,param_1[1],param_1[2]);
  return;
}



/* FUNCTION 22573 ; VA 0x00ae4520 ; FUN_00ae4520 */

int FUN_00ae4520(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eb0a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  pcVar3 = (code *)*param_1;
  ExceptionList = &pvStack_10;
  if (param_1[4] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[4] + 4);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar4 = param_1[3];
  uVar5 = param_1[4];
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar6 = (*pcVar3)(param_1[1],param_1[2],param_2,param_3,param_4,uVar4,uVar5);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar6 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 22574 ; VA 0x00ae4630 ; FUN_00ae4630 */

int FUN_00ae4630(int param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    iVar2 = FUN_00ae2430();
    if (((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
         (uint)*(ushort *)(iVar2 + 0x1da)) && (*(int *)(param_1 + 0xa4) != 0)) {
      piVar3 = (int *)(param_1 + 0x94);
      if ((int *)param_3 != piVar3) {
        if (0xf < *(uint *)(param_1 + 0xa8)) {
          piVar3 = (int *)*piVar3;
        }
        FUN_005542c0(piVar3,*(undefined4 *)(param_1 + 0xa4));
      }
      goto LAB_00ae46a8;
    }
  }
  param_1 = 0;
LAB_00ae46a8:
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar1 = param_2[1] + -1;
    param_2[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar3 = param_2 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22575 ; VA 0x00ae46f0 ; FUN_00ae46f0 */

int * FUN_00ae46f0(undefined4 param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eb0c0;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  piVar3 = (int *)FUN_00ae4630(param_1,param_2,auStack_2c);
  if (piVar3 != (int *)0x0) {
    *param_3 = *param_3 + 1;
    piVar3 = param_3;
  }
  if (0xf < uStack_18) {
    uVar5 = uStack_18 + 1;
    uVar4 = auStack_2c[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_2c[0] - 4);
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    piVar3 = (int *)FUN_01674ea0(uVar4,uVar5);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    piVar3 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piVar3 = (int *)(**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piVar3 = (int *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar3;
}



/* FUNCTION 22576 ; VA 0x00ae47e0 ; FUN_00ae47e0 */

int ** FUN_00ae47e0(undefined4 param_1,int ***param_2,undefined *param_3,int *param_4,
                   undefined4 param_5,int ***param_6,int *param_7)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int **ppiVar4;
  int **ppiVar5;
  int ***pppiVar6;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  int *piStack_b0;
  undefined4 uStack_ac;
  int ***pppiStack_a8;
  int *piStack_a4;
  undefined4 uStack_9c;
  undefined *puStack_98;
  int *piStack_94;
  undefined auStack_90 [8];
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  int ***pppiStack_7c;
  int ***pppiStack_78;
  undefined auStack_68 [16];
  undefined4 uStack_58;
  undefined4 uStack_54;
  int **appiStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int **ppiStack_28;
  code *pcStack_24;
  int *piStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eb110;
  pvStack_10 = ExceptionList;
  uStack_40 = 0;
  uStack_3c = 0xf;
  appiStack_50[0] = (int **)((uint)appiStack_50[0] & 0xffffff00);
  pppiStack_78 = appiStack_50;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  if (param_2 != (int ***)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_2[1] = (int **)((int)param_2[1] + 1);
    UNLOCK();
  }
  uStack_80 = param_1;
  pppiStack_7c = param_2;
  uStack_84 = 0xae484c;
  ppiVar4 = (int **)FUN_00ae4630();
  ppiVar5 = ppiVar4;
  if (ppiVar4 != (int **)0x0) {
    pppiStack_78 = (int ***)param_3;
    pppiStack_7c = (int ***)0xae4864;
    ppiVar5 = (int **)FUN_008f7870();
    if (ppiVar5 != (int **)0x0) {
      pppiStack_78 = (int ***)0xae4879;
      cVar3 = FUN_009cc920();
      if (cVar3 != '\0') {
        pppiStack_78 = (int ***)&pcStack_24;
        pcStack_24 = FUN_00ae60c0;
        pppiStack_7c = (int ***)&DAT_01eec040;
        uStack_80 = 0xae4895;
        piStack_20 = (int *)ppiVar5;
        FUN_0075d260();
      }
      uStack_58 = 0;
      uStack_54 = 0xf;
      auStack_68[0] = 0;
      pppiStack_78 = (int ***)auStack_68;
      pppiStack_7c = appiStack_50;
      uStack_8._0_1_ = 4;
      uStack_80 = 0xae48be;
      cVar3 = FUN_008cc2f0();
      if (cVar3 == '\0') {
        puStack_1c = (undefined *)&pppiStack_7c;
        if (param_7 != (int *)0x0) {
          LOCK();
          param_7[1] = param_7[1] + 1;
          UNLOCK();
        }
        pppiStack_7c = param_6;
        pppiStack_78 = (int ***)param_7;
        puStack_18 = (undefined *)&uStack_84;
        uStack_84 = 0;
        uStack_80 = 0;
        uStack_88 = 2;
        puStack_98 = auStack_90;
        uStack_8._0_1_ = 6;
        uStack_9c = 0xae4914;
        piStack_94 = (int *)ppiVar4;
        FUN_0060e0c0();
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        piStack_94 = (int *)0xae4920;
        FUN_00ae4b40();
        pppiStack_78 = (int ***)0xae492b;
        FUN_005507b0();
        pppiStack_78 = (int ***)0xae4933;
        ppiVar5 = (int **)FUN_005507b0();
        goto LAB_00ae4ab4;
      }
      puStack_1c = param_3;
      pppiStack_78 = (int ***)0xae4943;
      uStack_80 = FUN_008ccd40();
      pppiStack_78 = (int ***)0x1;
      pppiStack_7c = (int ***)0x0;
      uStack_14 = CONCAT31(uStack_14._1_3_,DAT_01eebd9b);
      piStack_20 = (int *)&pppiStack_a8;
      puStack_18 = (undefined *)CONCAT31(puStack_18._1_3_,DAT_01eebd9a);
      if (param_7 != (int *)0x0) {
        LOCK();
        param_7[1] = param_7[1] + 1;
        UNLOCK();
      }
      pppiStack_a8 = param_6;
      piStack_a4 = param_7;
      uStack_ac = uStack_14;
      uStack_8._0_1_ = 7;
      piStack_b0 = (int *)puStack_18;
      FUN_0060e0c0(&uStack_b8,ppiVar4);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_00ae3180(&uStack_38,FUN_00ae4b40);
      piStack_a4 = (int *)0x0;
      uStack_b8 = uStack_38;
      if (piStack_30 != (int *)0x0) {
        LOCK();
        piStack_30[2] = piStack_30[2] + 1;
        UNLOCK();
      }
      uStack_b4 = uStack_34;
      piStack_b0 = piStack_30;
      if ((int ***)ppiStack_28 != (int ***)0x0) {
        LOCK();
        ppiStack_28[1] = (int *)((int)ppiStack_28[1] + 1);
        UNLOCK();
      }
      uStack_ac = uStack_2c;
      pppiStack_a8 = (int ***)ppiStack_28;
      FUN_00ae2310();
      if ((int ***)ppiStack_28 != (int ***)0x0) {
        LOCK();
        ppiVar5 = (int **)((int)ppiStack_28[1] + -1);
        ppiStack_28[1] = (int *)ppiVar5;
        UNLOCK();
        if (ppiVar5 == (int **)0x0) {
          piStack_a4 = (int *)0xae4a2d;
          (*(code *)**ppiStack_28)();
          LOCK();
          ppiVar5 = (int **)((int)ppiStack_28[2] + -1);
          ppiStack_28[2] = (int *)ppiVar5;
          UNLOCK();
          if (ppiVar5 == (int **)0x0) {
            piStack_a4 = (int *)0xae4a3d;
            (*(code *)(*ppiStack_28)[1])();
          }
        }
      }
      if (piStack_30 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_30[2] + -1;
        piStack_30[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          piStack_a4 = (int *)0xae4a52;
          (**(code **)(*piStack_30 + 4))();
        }
      }
      pppiStack_a8 = appiStack_50;
      piStack_a4 = (int *)0x41200000;
      uStack_ac = 0xae4a66;
      FUN_008d1f10();
      pppiStack_78 = (int ***)0xae4a6e;
      ppiVar5 = (int **)FUN_005507b0();
    }
  }
  if (0xf < uStack_3c) {
    pppiStack_78 = (int ***)(uStack_3c + 1);
    pppiVar6 = (int ***)appiStack_50[0];
    if (0xfff < pppiStack_78) {
      pppiVar6 = (int ***)appiStack_50[0][-1];
      pppiStack_78 = (int ***)(uStack_3c + 0x24);
      if (0x1f < (uint)((int)appiStack_50[0] + (-4 - (int)pppiVar6))) {
                    /* WARNING: Subroutine does not return */
        pppiStack_78 = (int ***)&UNK_00ae4b3b;
        FUN_017167a3();
      }
    }
    uStack_80 = 0xae4a9f;
    pppiStack_7c = pppiVar6;
    ppiVar5 = (int **)FUN_01674ea0();
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  appiStack_50[0] = (int **)((uint)appiStack_50[0] & 0xffffff00);
LAB_00ae4ab4:
  if (param_2 != (int ***)0x0) {
    LOCK();
    pppiVar6 = param_2 + 1;
    ppiVar4 = *pppiVar6;
    ppiVar5 = *pppiVar6;
    *pppiVar6 = (int **)((int)ppiVar4 + -1);
    UNLOCK();
    if ((int **)((int)ppiVar4 + -1) == (int **)0x0) {
      pppiStack_78 = (int ***)0xae4aca;
      (*(code *)**param_2)();
      LOCK();
      pppiVar6 = param_2 + 2;
      ppiVar4 = *pppiVar6;
      ppiVar5 = *pppiVar6;
      *pppiVar6 = (int **)((int)ppiVar4 + -1);
      UNLOCK();
      if ((int **)((int)ppiVar4 + -1) == (int **)0x0) {
        pppiStack_78 = (int ***)0xae4ada;
        ppiVar5 = (int **)(*(code *)(*param_2)[1])();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    ppiVar5 = (int **)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pppiStack_78 = (int ***)0xae4af0;
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      ppiVar5 = (int **)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pppiStack_78 = (int ***)0xae4b00;
        ppiVar5 = (int **)(**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    piVar1 = param_7 + 1;
    iVar2 = *piVar1;
    ppiVar5 = (int **)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pppiStack_78 = (int ***)0xae4b16;
      ppiVar5 = (int **)(**(code **)*param_7)();
      LOCK();
      piVar1 = param_7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pppiStack_78 = (int ***)0xae4b25;
        ppiVar5 = (int **)(**(code **)(*param_7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return ppiVar5;
}



/* FUNCTION 22577 ; VA 0x00ae4b40 ; FUN_00ae4b40 */

code * FUN_00ae4b40(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4,
                   int *param_5,int *param_6,int *param_7)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  undefined uVar6;
  undefined *puStack_7c;
  code *pcStack_78;
  undefined4 uStack_74;
  int *piStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  int *piStack_64;
  undefined auStack_60 [12];
  undefined4 uStack_54;
  undefined4 *puStack_50;
  undefined4 *puStack_4c;
  code **ppcStack_48;
  code *apcStack_3c [2];
  undefined4 auStack_34 [6];
  uint *puStack_1c;
  char cStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eb148;
  pvStack_10 = ExceptionList;
  puStack_1c = (uint *)(param_6 + 0xd);
  uStack_8 = 2;
  cStack_18 = '\0';
  ppcStack_48 = (code **)0xae4b79;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  ppcStack_48 = (code **)0x0;
  puStack_7c = auStack_60;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_6c = param_3;
  uStack_68 = param_4;
  piStack_64 = param_5;
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[2] = param_2[2] + 1;
    UNLOCK();
  }
  uStack_74 = param_1;
  pcStack_78 = FUN_00ae3d40;
  piStack_70 = param_2;
  FUN_00ae3030();
  piStack_64 = (int *)0xae4be9;
  FUN_00ae21f0();
  ppcStack_48 = apcStack_3c;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  puStack_4c = (undefined4 *)param_6[0x10];
  if ((undefined4 *)param_6[0x11] == puStack_4c) {
    puStack_50 = (undefined4 *)0xae4c18;
    FUN_00ae2510();
  }
  else {
    *puStack_4c = 0;
    puStack_4c = (undefined4 *)0xae4c09;
    FUN_005880d0();
    param_6[0x10] = param_6[0x10] + 0x20;
  }
  uStack_8._0_1_ = 5;
  if (((apcStack_3c[0] != (code *)0x0) && (((uint)apcStack_3c[0] & 1) == 0)) &&
     (apcStack_3c[0] = *(code **)((uint)apcStack_3c[0] & 0xfffffffe), apcStack_3c[0] != (code *)0x0)
     ) {
    puStack_50 = auStack_34;
    ppcStack_48 = (code **)0x2;
    uStack_54 = 0xae4c39;
    puStack_4c = puStack_50;
    apcStack_3c[0] = (code *)(*apcStack_3c[0])();
  }
  iVar4 = param_6[0x10];
  iVar5 = param_6[0xf];
  uStack_8._0_1_ = 6;
  if (cStack_18 != '\0') {
    LOCK();
    apcStack_3c[0] = (code *)*puStack_1c;
    *puStack_1c = *puStack_1c + 0x80000000;
    UNLOCK();
    if ((((uint)apcStack_3c[0] & 0x40000000) == 0) && (-0x80000000 < (int)apcStack_3c[0])) {
      LOCK();
      uVar3 = *puStack_1c;
      *puStack_1c = *puStack_1c | 0x40000000;
      UNLOCK();
      if ((uVar3 >> 0x1e & 1) == 0) {
        ppcStack_48 = (code **)0xae4c78;
        ppcStack_48 = (code **)FUN_00554e40();
        puStack_4c = (undefined4 *)0xae4c7f;
        apcStack_3c[0] = (code *)SetEvent();
      }
    }
  }
  uVar6 = DAT_01eebd9a;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iVar4 - iVar5 >> 5 == *param_6) {
    ppcStack_48 = (code **)param_6[0xc];
    puStack_4c = (undefined4 *)param_6[10];
    piStack_70 = (int *)0x0;
    if (param_7 != (int *)0x0) {
      LOCK();
      param_7[1] = param_7[1] + 1;
      UNLOCK();
    }
    FUN_00889110(&puStack_7c,FUN_00ae67f0,uVar6,param_6,param_7);
    FUN_00ae2100();
    piStack_70 = (int *)0xae4ce9;
    apcStack_3c[0] = (code *)FUN_00d1bff0();
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_2 + 2);
    uVar3 = *puVar1;
    apcStack_3c[0] = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      ppcStack_48 = (code **)0xae4d04;
      apcStack_3c[0] = (code *)(**(code **)(*param_2 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_5 + 1);
    uVar3 = *puVar1;
    apcStack_3c[0] = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      ppcStack_48 = (code **)0xae4d1a;
      (**(code **)*param_5)();
      LOCK();
      puVar1 = (uint *)(param_5 + 2);
      uVar3 = *puVar1;
      apcStack_3c[0] = (code *)*puVar1;
      *puVar1 = uVar3 - 1;
      UNLOCK();
      if (uVar3 - 1 == 0) {
        ppcStack_48 = (code **)0xae4d2a;
        apcStack_3c[0] = (code *)(**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_7 + 1);
    uVar3 = *puVar1;
    apcStack_3c[0] = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      ppcStack_48 = (code **)0xae4d40;
      apcStack_3c[0] = (code *)(**(code **)*param_7)();
      LOCK();
      piVar2 = param_7 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        ppcStack_48 = (code **)0xae4d4f;
        apcStack_3c[0] = (code *)(**(code **)(*param_7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return apcStack_3c[0];
}



/* FUNCTION 22578 ; VA 0x00ae4d60 ; FUN_00ae4d60 */

void FUN_00ae4d60(uint param_1,int *param_2,undefined4 param_3,int *param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
                 undefined4 param_10,undefined8 param_11)

{
  int iVar1;
  uint *puVar2;
  undefined *puVar3;
  int *piVar4;
  uint auStack_c4 [2];
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined8 uStack_ac;
  int aiStack_a4 [10];
  undefined4 uStack_7c;
  undefined auStack_78 [4];
  undefined4 uStack_74;
  undefined *puStack_70;
  code *pcStack_6c;
  undefined4 uStack_68;
  uint uStack_64;
  int *piStack_60;
  int *piStack_5c;
  char *pcStack_58;
  code **ppcStack_54;
  undefined auStack_48 [24];
  int *piStack_30;
  int *piStack_2c;
  code *pcStack_28;
  int *piStack_24;
  undefined *puStack_20;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eb180;
  pvStack_10 = ExceptionList;
  ppcStack_54 = (code **)&piStack_30;
  uStack_8 = 1;
  pcStack_58 = (char *)0xae4d8d;
  ExceptionList = &pvStack_10;
  FUN_00ae33b0();
  piVar4 = piStack_30;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (DAT_01eebd98 != 0) {
    ppcStack_54 = (code **)piStack_30;
    piStack_5c = (int *)(uint)DAT_01eebd98;
    pcStack_58 = "Starting to preload linked scripts id=%p";
    piStack_60 = (int *)0xae4daf;
    FUN_016774b0();
  }
  piStack_24 = &iStack_14;
  ppcStack_54 = &pcStack_28;
  iStack_14 = 0;
  pcStack_28 = FUN_00ae46f0;
  pcStack_58 = (char *)0xae4dd2;
  FUN_00917910();
  if (DAT_01eebd98 != 0) {
    ppcStack_54 = (code **)0x0;
    pcStack_58 = (char *)iStack_14;
    uStack_64 = (uint)DAT_01eebd98;
    piStack_5c = piVar4;
    piStack_60 = (int *)0x194c2a8;
    uStack_68 = 0xae4def;
    FUN_01677490();
  }
  if (iStack_14 < 1) {
    ppcStack_54 = (code **)param_4;
    pcStack_58 = (char *)param_1;
    piStack_1c = (int *)CONCAT31(piStack_1c._1_3_,DAT_01eebd9a);
    puStack_20 = auStack_78;
    uStack_7c = 0;
    piStack_18 = aiStack_a4;
    piStack_24 = (int *)auStack_c4;
    auStack_c4[0] = 0;
    puVar2 = auStack_c4;
    puVar3 = auStack_78;
    piVar4 = aiStack_a4;
    if (param_5 != 0) {
      auStack_c4[0] = param_5;
      if ((param_5 & 1) == 0) {
        (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_bc,0);
        puVar2 = (uint *)piStack_24;
        puVar3 = puStack_20;
        piVar4 = piStack_18;
      }
      else {
        uStack_bc = param_7;
        uStack_b8 = param_8;
        uStack_b4 = param_9;
        uStack_b0 = param_10;
        uStack_ac = param_11;
        puVar2 = auStack_c4;
        puVar3 = auStack_78;
        piVar4 = aiStack_a4;
      }
    }
    piStack_18 = piVar4;
    puStack_20 = puVar3;
    piStack_24 = (int *)puVar2;
    FUN_00ae2be0(piStack_18,FUN_00ae6a70,piStack_1c);
    uStack_ac = CONCAT44(0xae4f63,(undefined4)uStack_ac);
    FUN_00ae2040();
    uStack_7c = 0xae4f68;
    FUN_00d1bff0();
  }
  else {
    *piStack_30 = iStack_14;
    ppcStack_54 = (code **)&param_5;
    pcStack_58 = (char *)0xae4e14;
    FUN_005e0b90();
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    piStack_18 = param_2;
    piStack_30[10] = param_1;
    piStack_1c = (int *)piStack_30[0xb];
    piStack_30[0xb] = (int)param_2;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar1 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        ppcStack_54 = (code **)0xae4e50;
        (**(code **)*piStack_1c)();
        LOCK();
        iVar1 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          ppcStack_54 = (code **)0xae4e61;
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    piStack_30[0xc] = (int)param_4;
    piStack_1c = (int *)CONCAT31(piStack_1c._1_3_,DAT_01eebd9a);
    if (piStack_2c != (int *)0x0) {
      LOCK();
      piStack_2c[1] = piStack_2c[1] + 1;
      UNLOCK();
    }
    piStack_5c = param_4;
    ppcStack_54 = (code **)piStack_2c;
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    uStack_68 = piStack_1c;
    uStack_64 = param_1;
    piStack_60 = param_2;
    puStack_70 = auStack_48;
    pcStack_6c = FUN_00ae47e0;
    uStack_74 = 0xae4ecb;
    ppcStack_54 = (code **)FUN_00ae2df0();
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    pcStack_58 = (char *)0xae4edb;
    FUN_00ae3450();
    ppcStack_54 = (code **)0xae4ee3;
    FUN_00a7c8d0();
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar1 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      ppcStack_54 = (code **)0xae4f7e;
      (**(code **)*piStack_2c)();
      LOCK();
      iVar1 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        ppcStack_54 = (code **)0xae4f8e;
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar1 = param_2[1] + -1;
    param_2[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      ppcStack_54 = (code **)0xae4fa4;
      (**(code **)*param_2)();
      LOCK();
      piVar4 = param_2 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        ppcStack_54 = (code **)0xae4fb3;
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8 = 4;
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    piStack_5c = &param_7;
    ppcStack_54 = (code **)0x2;
    piStack_60 = (int *)0xae4fd7;
    pcStack_58 = (char *)piStack_5c;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22579 ; VA 0x00ae4ff0 ; FUN_00ae4ff0 */

void FUN_00ae4ff0(int *param_1,int *param_2,int *param_3,int *param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
                 undefined4 param_10,undefined8 param_11)

{
  int iVar1;
  uint *puVar2;
  undefined uVar3;
  code *pcVar4;
  uint *puVar5;
  int *piVar6;
  undefined4 *puVar7;
  int *piVar8;
  uint auStack_d8 [2];
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined8 uStack_c0;
  undefined auStack_b8 [40];
  undefined4 uStack_90;
  undefined4 uStack_88;
  undefined *puStack_84;
  code *pcStack_80;
  undefined4 uStack_7c;
  int *piStack_78;
  int *piStack_74;
  int *piStack_70;
  int *piStack_6c;
  code **ppcStack_68;
  undefined auStack_5c [24];
  int *piStack_44;
  code *pcStack_40;
  int *piStack_3c;
  int *piStack_38;
  code *pcStack_34;
  int *piStack_30;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  code *pcStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  code *pcStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eb1c0;
  pvStack_10 = ExceptionList;
  ppcStack_68 = (code **)&piStack_3c;
  uStack_8 = 1;
  piStack_6c = (int *)0xae501d;
  ExceptionList = &pvStack_10;
  FUN_00ae33b0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (DAT_01eebd98 != 0) {
    ppcStack_68 = (code **)piStack_3c;
    piStack_70 = (int *)(uint)DAT_01eebd98;
    piStack_6c = (int *)0x194c27c;
    piStack_74 = (int *)0xae5040;
    FUN_016774b0();
  }
  iStack_1c = 0;
  piStack_14 = (int *)*param_3;
  if (piStack_14 != (int *)param_3[1]) {
    do {
      iVar1 = *piStack_14;
      piStack_30 = &iStack_1c;
      pcStack_34 = FUN_00ae46f0;
      puVar7 = *(undefined4 **)(iVar1 + 0x2c);
      if (puVar7 != (undefined4 *)0x0) {
        pcStack_24 = *(code **)(iVar1 + 0x30);
        if (pcStack_24 != (code *)0x0) {
          LOCK();
          *(int *)(pcStack_24 + 4) = *(int *)(pcStack_24 + 4) + 1;
          UNLOCK();
          pcStack_24 = *(code **)(iVar1 + 0x30);
          puVar7 = *(undefined4 **)(iVar1 + 0x2c);
        }
        puVar2 = (uint *)puVar7[1];
        puVar5 = (uint *)*puVar7;
        uStack_8._0_1_ = 3;
        pcStack_18 = pcStack_24;
        puStack_28 = puVar7;
        for (; puVar5 != puVar2; puVar5 = puVar5 + 2) {
          if (puVar5[1] != 0) {
            LOCK();
            piVar8 = (int *)(puVar5[1] + 4);
            *piVar8 = *piVar8 + 1;
            UNLOCK();
          }
          piStack_70 = (int *)*puVar5;
          piStack_6c = (int *)puVar5[1];
          piStack_74 = (int *)0xae50d5;
          ppcStack_68 = (code **)piStack_30;
          (*pcStack_34)();
          ppcStack_68 = &pcStack_34;
          piStack_6c = (int *)0xae50e3;
          FUN_00917910();
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        if (pcStack_18 != (code *)0x0) {
          LOCK();
          iVar1 = *(int *)(pcStack_18 + 4) + -1;
          *(int *)(pcStack_18 + 4) = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            ppcStack_68 = (code **)0xae510a;
            (*(code *)**(undefined4 **)pcStack_18)();
            LOCK();
            iVar1 = *(int *)(pcStack_18 + 8) + -1;
            *(int *)(pcStack_18 + 8) = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              ppcStack_68 = (code **)0xae511b;
              (**(code **)(*(int *)pcStack_18 + 4))();
            }
          }
        }
      }
      piStack_14 = piStack_14 + 2;
    } while (piStack_14 != (int *)param_3[1]);
  }
  piVar8 = piStack_3c;
  if (DAT_01eebd98 != 0) {
    ppcStack_68 = (code **)0x0;
    piStack_70 = piStack_3c;
    piStack_78 = (int *)(uint)DAT_01eebd98;
    piStack_74 = (int *)0x194c2a8;
    uStack_7c = 0xae5152;
    piStack_6c = (int *)iStack_1c;
    FUN_01677490();
  }
  uVar3 = DAT_01eebd9a;
  if (iStack_1c < 1) {
    ppcStack_68 = (code **)param_4;
    piStack_6c = param_1;
    uStack_90 = 0;
    piStack_30 = (int *)auStack_d8;
    auStack_d8[0] = 0;
    puVar2 = auStack_d8;
    if (param_5 != 0) {
      auStack_d8[0] = param_5;
      if ((param_5 & 1) == 0) {
        (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_d0,0);
        puVar2 = (uint *)piStack_30;
      }
      else {
        uStack_d0 = param_7;
        uStack_cc = param_8;
        uStack_c8 = param_9;
        uStack_c4 = param_10;
        uStack_c0 = param_11;
        puVar2 = auStack_d8;
      }
    }
    piStack_30 = (int *)puVar2;
    FUN_00ae2be0(auStack_b8,FUN_00ae6a70,uVar3);
    uStack_c0 = CONCAT44(0xae53dd,(undefined4)uStack_c0);
    FUN_00ae2040();
    uStack_90 = 0xae53e2;
    FUN_00d1bff0();
  }
  else {
    ppcStack_68 = (code **)&param_5;
    *piVar8 = iStack_1c;
    piStack_6c = (int *)0xae516e;
    FUN_005e0b90();
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    piVar8[10] = (int)param_1;
    piVar8 = (int *)piVar8[0xb];
    piStack_3c[0xb] = (int)param_2;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar1 = piVar8[1] + -1;
      piVar8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        ppcStack_68 = (code **)0xae519e;
        (**(code **)*piVar8)();
        LOCK();
        iVar1 = piVar8[2] + -1;
        piVar8[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          ppcStack_68 = (code **)0xae51ae;
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    piStack_3c[0xc] = (int)param_4;
    piVar8 = (int *)*param_3;
    piStack_14 = piVar8;
    if (piVar8 != (int *)param_3[1]) {
      do {
        pcStack_18 = (code *)*piVar8;
        uStack_20 = CONCAT31(uStack_20._1_3_,DAT_01eebd9a);
        if (piStack_38 != (int *)0x0) {
          LOCK();
          piStack_38[1] = piStack_38[1] + 1;
          UNLOCK();
        }
        ppcStack_68 = (code **)piStack_38;
        piStack_6c = piStack_3c;
        if (param_2 != (int *)0x0) {
          LOCK();
          param_2[1] = param_2[1] + 1;
          UNLOCK();
        }
        uStack_7c = uStack_20;
        piStack_78 = param_1;
        piStack_74 = param_2;
        puStack_84 = auStack_5c;
        pcStack_80 = FUN_00ae47e0;
        uStack_88 = 0xae5231;
        piStack_70 = param_4;
        piStack_14 = piVar8;
        pcVar4 = (code *)FUN_00ae2df0();
        piVar6 = *(int **)(pcStack_18 + 0x2c);
        pcStack_24 = pcVar4;
        if (piVar6 != (int *)0x0) {
          pcStack_40 = *(code **)(pcStack_18 + 0x30);
          if (pcStack_40 != (code *)0x0) {
            LOCK();
            *(int *)(pcStack_40 + 4) = *(int *)(pcStack_40 + 4) + 1;
            UNLOCK();
            pcStack_40 = *(code **)(pcStack_18 + 0x30);
            piVar6 = *(int **)(pcStack_18 + 0x2c);
          }
          puStack_2c = (undefined4 *)piVar6[1];
          puVar7 = (undefined4 *)*piVar6;
          uStack_8 = CONCAT31(uStack_8._1_3_,5);
          piStack_44 = piVar6;
          pcStack_18 = pcStack_40;
          if (puVar7 != puStack_2c) {
            do {
              pcStack_24 = *(code **)pcVar4;
              piStack_70 = *(int **)(pcVar4 + 0xc);
              if (*(int *)(pcVar4 + 0x14) != 0) {
                LOCK();
                piVar8 = (int *)(*(int *)(pcVar4 + 0x14) + 4);
                *piVar8 = *piVar8 + 1;
                UNLOCK();
              }
              piStack_6c = *(int **)(pcVar4 + 0x10);
              ppcStack_68 = *(code ***)(pcVar4 + 0x14);
              if (*(int *)(pcVar4 + 8) != 0) {
                LOCK();
                piVar8 = (int *)(*(int *)(pcVar4 + 8) + 4);
                *piVar8 = *piVar8 + 1;
                UNLOCK();
              }
              piStack_78 = *(int **)(pcVar4 + 4);
              piStack_74 = *(int **)(pcVar4 + 8);
              if (puVar7[1] != 0) {
                LOCK();
                piVar8 = (int *)(puVar7[1] + 4);
                *piVar8 = *piVar8 + 1;
                UNLOCK();
              }
              pcStack_80 = (code *)*puVar7;
              uStack_7c = puVar7[1];
              puStack_84 = (undefined *)0xae5303;
              (*pcStack_24)();
              piStack_6c = (int *)0xae530e;
              ppcStack_68 = (code **)pcVar4;
              FUN_00ae3450();
              puVar7 = puVar7 + 2;
              piVar8 = piStack_14;
            } while (puVar7 != puStack_2c);
          }
          if (pcStack_18 != (code *)0x0) {
            LOCK();
            iVar1 = *(int *)(pcStack_18 + 4) + -1;
            *(int *)(pcStack_18 + 4) = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              ppcStack_68 = (code **)0xae5334;
              (*(code *)**(undefined4 **)pcStack_18)();
              LOCK();
              iVar1 = *(int *)(pcStack_18 + 8) + -1;
              *(int *)(pcStack_18 + 8) = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                ppcStack_68 = (code **)0xae5345;
                (**(code **)(*(int *)pcStack_18 + 4))();
              }
            }
          }
        }
        ppcStack_68 = (code **)0xae534d;
        FUN_00a7c8d0();
        piVar8 = piVar8 + 2;
        piStack_14 = piVar8;
      } while (piVar8 != (int *)param_3[1]);
    }
  }
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_38[1] + -1;
    piStack_38[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      ppcStack_68 = (code **)0xae53fe;
      (**(code **)*piStack_38)();
      LOCK();
      iVar1 = piStack_38[2] + -1;
      piStack_38[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        ppcStack_68 = (code **)0xae540e;
        (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar1 = param_2[1] + -1;
    param_2[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      ppcStack_68 = (code **)0xae5424;
      (**(code **)*param_2)();
      LOCK();
      piVar8 = param_2 + 2;
      iVar1 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        ppcStack_68 = (code **)0xae5433;
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8 = 6;
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    piStack_70 = &param_7;
    ppcStack_68 = (code **)0x2;
    piStack_74 = (int *)0xae5457;
    piStack_6c = piStack_70;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22580 ; VA 0x00ae5470 ; FUN_00ae5470 */

void FUN_00ae5470(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1dd83f4);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_01d1bd99687611b7f378c6728df2881c>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 22581 ; VA 0x00ae54d0 ; FUN_00ae54d0 */

void FUN_00ae54d0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1dd842c);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_34f60a97b3712c8df987760da72c5cbd>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 22582 ; VA 0x00ae5530 ; FUN_00ae5530 */

void FUN_00ae5530(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008c1ba0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 8);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x10,iVar3 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar3 + 8) = 0;
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dd8464);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_RBX::DataModel*,class_boost::function<void___cdecl(void)>),class_boost::_bi::list2<struct_boost::arg<1>,class_boost::_bi::value<class_boost::function<void___cdecl(void)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 22583 ; VA 0x00ae56a0 ; FUN_00ae56a0 */

int * FUN_00ae56a0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (param_1[2] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[2] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[2];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00ae5782. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[2];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00ae56f6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dd815c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_RBX::DataModel*,class_std::shared_ptr<struct_RBX::LuaSourceContainer::LinkedScriptLoadData>),class_boost::_bi::list2<struct_boost::arg<1>,class_boost::_bi::value<class_std::shared_ptr<struct_RBX::LuaSourceContainer::LinkedScriptLoadData>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 22584 ; VA 0x00ae57a0 ; FUN_00ae57a0 */

int * FUN_00ae57a0(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      piVar3 = (int *)FUN_00ae3670(param_1);
      if (param_3 == 1) {
        piVar2 = *(int **)(param_1 + 0x14);
        if (piVar2 != (int *)0x0) {
          LOCK();
          piVar1 = piVar2 + 1;
          iVar4 = *piVar1;
          piVar3 = (int *)*piVar1;
          *piVar1 = iVar4 + -1;
          UNLOCK();
          if (iVar4 + -1 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar4 = *piVar1;
            piVar3 = (int *)*piVar1;
            *piVar1 = iVar4 + -1;
            UNLOCK();
            if (iVar4 + -1 == 0) {
              piVar3 = (int *)(**(code **)(*piVar2 + 4))();
            }
          }
        }
        piVar2 = *(int **)(param_1 + 8);
        if (piVar2 != (int *)0x0) {
          LOCK();
          piVar1 = piVar2 + 2;
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00ae5845. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            piVar3 = (int *)(**(code **)(*piVar2 + 4))();
            return piVar3;
          }
        }
      }
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)FUN_00ae3be0(0);
      return piVar3;
    }
    if (param_3 == 3) {
      piVar3 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dd8254);
      iVar4 = 0;
      if (piVar3 == (int *)0x0) {
        iVar4 = param_1;
      }
      *param_2 = iVar4;
      return piVar3;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::LuaSourceContainer>,enum_RBX::HttpRequestResult,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>),class_boost::_bi::list3<class_boost::_bi::value<class_std::weak_ptr<class_RBX::LuaSourceContainer>_>,class_boost::_bi::value<enum_RBX::HttpRequestResult>,class_boost::_bi::value<class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 22585 ; VA 0x00ae5860 ; FUN_00ae5860 */

int * FUN_00ae5860(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      piVar3 = (int *)FUN_00ae36d0(param_1);
      if (param_3 == 1) {
        piVar2 = *(int **)(param_1 + 0x10);
        if (piVar2 != (int *)0x0) {
          LOCK();
          piVar1 = piVar2 + 1;
          iVar4 = *piVar1;
          piVar3 = (int *)*piVar1;
          *piVar1 = iVar4 + -1;
          UNLOCK();
          if (iVar4 + -1 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar4 = *piVar1;
            piVar3 = (int *)*piVar1;
            *piVar1 = iVar4 + -1;
            UNLOCK();
            if (iVar4 + -1 == 0) {
              piVar3 = (int *)(**(code **)(*piVar2 + 4))();
            }
          }
        }
        piVar2 = *(int **)(param_1 + 8);
        if (piVar2 != (int *)0x0) {
          LOCK();
          piVar1 = piVar2 + 2;
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00ae5905. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            piVar3 = (int *)(**(code **)(*piVar2 + 4))();
            return piVar3;
          }
        }
      }
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)FUN_00ae3c40(0);
      return piVar3;
    }
    if (param_3 == 3) {
      piVar3 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dd7f9c);
      iVar4 = 0;
      if (piVar3 == (int *)0x0) {
        iVar4 = param_1;
      }
      *param_2 = iVar4;
      return piVar3;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::LuaSourceContainer>,enum_RBX::HttpRequestResult,class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_>,class_std::shared_ptr<struct_RBX::LuaSourceContainer::LinkedScriptLoadData>),class_boost::_bi::list4<class_boost::_bi::value<class_std::weak_ptr<class_RBX::LuaSourceContainer>_>,struct_boost::arg<1>,struct_boost::arg<2>,class_boost::_bi::value<class_std::shared_ptr<struct_RBX::LuaSourceContainer::LinkedScriptLoadData>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 22586 ; VA 0x00ae5920 ; FUN_00ae5920 */

int FUN_00ae5920(undefined4 param_1,int *param_2,int param_3,int *param_4)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eb1e8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00587490(&iStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iStack_1c != 0) {
    piVar3 = (int *)FUN_00587490(auStack_24);
    iStack_14 = *piVar3;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_20[1] + -1;
      piStack_20[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar2 = piStack_20[2] + -1;
        piStack_20[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar2 = iStack_14;
    if (iStack_14 == param_3) {
      iVar2 = FUN_00ae6250(0);
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_18 + 1;
    iVar1 = *piVar3;
    iVar2 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar3 = piStack_18 + 2;
      iVar1 = *piVar3;
      iVar2 = *piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar2 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar3 = param_2 + 2;
    iVar1 = *piVar3;
    iVar2 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar2 = (**(code **)(*param_2 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar3 = param_4 + 1;
    iVar1 = *piVar3;
    iVar2 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar2 = (**(code **)*param_4)();
      LOCK();
      piVar3 = param_4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar2 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 22587 ; VA 0x00ae5a20 ; FUN_00ae5a20 */

int * __thiscall FUN_00ae5a20(uint *param_1,uint *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  bool bVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  uint *puStack_38;
  uint *puStack_34;
  uint *puStack_30;
  undefined auStack_20 [4];
  undefined auStack_1c [4];
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eb229;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (uint *)0x0) {
    puStack_30 = (uint *)0x0;
    puStack_34 = (uint *)0xae5a55;
    ExceptionList = &pvStack_10;
    FUN_00ae6250();
  }
  if ((param_1[0x23] != 0) && (param_2 != (uint *)0x0)) {
    puStack_30 = param_2;
    puStack_34 = (uint *)0xae5a6b;
    iVar4 = FUN_008f7870();
    if (iVar4 != 0) {
      puStack_34 = (uint *)0xae5a7a;
      puStack_30 = param_1 + 0x1f;
      FUN_008f3450();
    }
  }
  puStack_30 = (uint *)param_3;
  puStack_34 = param_2;
  puStack_38 = (uint *)0xae5a86;
  piVar5 = (int *)FUN_008a4210();
  if (param_3 != (int *)0x0) {
    puStack_30 = (uint *)auStack_1c;
    puStack_34 = (uint *)0xae5a99;
    piVar5 = (int *)FUN_00587490();
    uStack_14 = 1;
    uStack_8 = 0;
    if (*piVar5 != 0) {
      puStack_30 = (uint *)0x1;
      puStack_38 = (uint *)0xae5ab4;
      puStack_34 = param_1;
      piVar5 = (int *)FUN_00971ce0();
      bVar3 = true;
      if ((char)piVar5 != '\0') goto LAB_00ae5ac3;
    }
  }
  bVar3 = false;
LAB_00ae5ac3:
  piVar2 = piStack_18;
  uStack_8 = 0xffffffff;
  if (((uStack_14 & 1) != 0) && (piStack_18 != (int *)0x0)) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar4 = *piVar1;
    piVar5 = (int *)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      puStack_30 = (uint *)0xae5ae9;
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      piVar5 = (int *)*piVar1;
      *piVar1 = iVar4 + -1;
      UNLOCK();
      if (iVar4 + -1 == 0) {
        puStack_30 = (uint *)0xae5af9;
        piVar5 = (int *)(**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (bVar3) {
    puStack_34 = (uint *)0xae5b09;
    puStack_30 = param_1;
    piVar5 = (int *)FUN_0064e810();
    if (piVar5 != (int *)0x0) {
      puStack_30 = (uint *)(uint)DAT_01eebd9a;
      FUN_0060e0c0(&puStack_38,param_1);
      puStack_30 = (uint *)FUN_00ae2f70(auStack_20,FUN_00ae5920);
      puStack_34 = &uStack_14;
      uStack_8 = 1;
      puStack_38 = (uint *)0xae5b55;
      uVar6 = FUN_00ae32c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      puStack_34 = (uint *)0xae5b68;
      puStack_30 = (uint *)uVar6;
      piVar5 = (int *)FUN_01679300();
      if ((char)piVar5 != '\0') {
        puStack_30 = (uint *)0xae5b77;
        FUN_01679490();
        puStack_34 = (uint *)0xae5b85;
        puStack_30 = (uint *)uVar6;
        piVar5 = (int *)FUN_016791c0();
      }
      if (uStack_14 != 0) {
        piVar5 = (int *)(uStack_14 + 4);
        LOCK();
        iVar4 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        piVar5 = (int *)(iVar4 + -1);
        if (piVar5 == (int *)0x0) {
          puStack_30 = (uint *)uStack_14;
          puStack_34 = (uint *)0xae5ba2;
          piVar5 = (int *)FUN_01674ea0();
        }
      }
      uStack_8 = 0xffffffff;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piVar2 = piStack_18 + 2;
        iVar4 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          puStack_30 = (uint *)0xae5bc0;
          piVar5 = (int *)(**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  if ((param_1[0x23] != 0) && (piVar5 = param_3, param_3 != (int *)0x0)) {
    puStack_30 = (uint *)param_3;
    puStack_34 = (uint *)0xae5bd6;
    piVar5 = (int *)FUN_008f7870();
    if (piVar5 != (int *)0x0) {
      puStack_38 = param_1;
      FUN_0060dcd0(&puStack_34);
      puStack_38 = param_1 + 0x1f;
      piVar5 = (int *)FUN_00907ef0();
    }
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 22588 ; VA 0x00ae5c10 ; FUN_00ae5c10 */

int __thiscall FUN_00ae5c10(int *param_1,undefined *param_2,int param_3,undefined4 *param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  bool bVar4;
  bool bVar5;
  char cVar6;
  int *piVar7;
  int iVar8;
  int iVar9;
  undefined4 *puVar10;
  uint uVar11;
  undefined4 **ppuVar12;
  uint uVar13;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  uint uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  int iStack_6c;
  int *piStack_68;
  undefined auStack_64 [16];
  undefined4 uStack_54;
  undefined4 uStack_50;
  int iStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int *piStack_3c;
  int *piStack_38;
  uint uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eb2b2;
  pvStack_10 = ExceptionList;
  piStack_38 = (int *)0x0;
  piStack_14 = param_1;
  if (param_2 == &DAT_01eebe18) {
    ExceptionList = &pvStack_10;
    FUN_0097c020(&iStack_4c,param_4,param_1);
    uStack_8 = 0;
    piVar7 = (int *)FUN_00587490(&uStack_40);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if ((*piVar7 == 0) ||
       (iVar9 = *(int *)(*piVar7 + 0xc), iVar8 = FUN_00913630(),
       (uint)*(ushort *)(iVar8 + 0x1da) <
       (uint)*(ushort *)(iVar9 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8))) {
      piStack_20 = (int *)0x0;
      ppuVar12 = &puStack_24;
      param_3 = 0;
      bVar5 = false;
      bVar4 = true;
    }
    else {
      piStack_18 = (int *)piVar7[1];
      param_3 = *piVar7;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
        piStack_18 = (int *)piVar7[1];
      }
      ppuVar12 = &puStack_1c;
      bVar5 = true;
      bVar4 = false;
    }
    iVar9 = param_3;
    piStack_68 = ppuVar12[1];
    *ppuVar12 = (undefined4 *)0x0;
    ppuVar12[1] = (undefined4 *)0x0;
    iStack_6c = param_3;
    piStack_38 = piStack_68;
    if ((bVar4) && (piStack_20 != (int *)0x0)) {
      LOCK();
      iVar8 = piStack_20[1] + -1;
      piStack_20[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar8 = piStack_20[2] + -1;
        piStack_20[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    if ((bVar5) && (piStack_18 != (int *)0x0)) {
      LOCK();
      iVar8 = piStack_18[1] + -1;
      piStack_18[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        iVar8 = piStack_18[2] + -1;
        piStack_18[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    uStack_8._0_1_ = 3;
    if (piStack_3c != (int *)0x0) {
      LOCK();
      iVar8 = piStack_3c[1] + -1;
      piStack_3c[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_3c)();
        LOCK();
        iVar8 = piStack_3c[2] + -1;
        piStack_3c[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piStack_3c + 4))();
        }
      }
    }
    piVar7 = piStack_14;
    if ((iStack_4c == 0) ||
       (((iVar9 != 0 && (iVar9 != iStack_4c)) && (*(char *)(iVar9 + 0xab) != '\0')))) {
      param_2._3_1_ = 0;
    }
    else {
      param_2._3_1_ = 1;
      if ((iVar9 != iStack_4c) && (FUN_00ae6250(iStack_4c), param_3 != 0)) {
        FUN_00927d30(&param_3);
        piStack_18 = (int *)0x0;
        puStack_1c = &param_3;
        uStack_28 = 0;
        puStack_24 = (undefined4 *)0x0;
        piStack_20 = (int *)0x0;
        uStack_8._0_1_ = 4;
        (**(code **)(*piVar7 + 8))(&DAT_01eebe98,&uStack_28,&puStack_1c);
        uStack_8._0_1_ = 5;
        FUN_00577b20();
        uStack_8._0_1_ = 3;
        piVar7 = piStack_14;
        param_2._3_1_ = 1;
      }
    }
    puStack_1c = param_4;
    piStack_18 = (int *)0x0;
    pcVar3 = *(code **)(*piVar7 + 8);
    uStack_13c = FUN_0088daf0();
    uStack_138 = 0;
    uStack_134 = CONCAT31(uStack_134._1_3_,param_2._3_1_);
    uStack_138 = FUN_005c9ef0();
    uStack_8._0_1_ = 6;
    uStack_28 = 0;
    puStack_24 = (undefined4 *)0x0;
    piStack_20 = (int *)0x0;
    FUN_00687980(&uStack_13c,&iStack_6c,param_4);
    uStack_8._0_1_ = 7;
    (*pcVar3)(&DAT_01eebe58,&uStack_28,&puStack_1c);
    uStack_8._0_1_ = 8;
    FUN_00577b20();
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    iVar9 = FUN_016f32d1(&uStack_13c,0xd0,1,FUN_0056e5b0);
    piVar7 = piStack_38;
    if (piStack_38 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_38 + 1;
      iVar8 = *piVar1;
      iVar9 = *piVar1;
      *piVar1 = iVar8 + -1;
      UNLOCK();
      if (iVar8 + -1 == 0) {
        (**(code **)*piStack_38)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar8 = *piVar1;
        iVar9 = *piVar1;
        *piVar1 = iVar8 + -1;
        UNLOCK();
        if (iVar8 + -1 == 0) {
          iVar9 = (**(code **)(*piVar7 + 4))();
        }
      }
    }
    if (piStack_48 != (int *)0x0) {
      LOCK();
      piVar7 = piStack_48 + 1;
      iVar8 = *piVar7;
      iVar9 = *piVar7;
      *piVar7 = iVar8 + -1;
      UNLOCK();
      if (iVar8 + -1 == 0) {
        iVar9 = (**(code **)*piStack_48)();
        LOCK();
        piVar7 = piStack_48 + 2;
        iVar8 = *piVar7;
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          iVar9 = (**(code **)(*piStack_48 + 4))();
          ExceptionList = pvStack_10;
          return iVar9;
        }
      }
    }
  }
  else {
    if (param_2 == &DAT_01eebf50) {
      uStack_54 = 0;
      uStack_50 = 0xf;
      auStack_64[0] = 0;
      uStack_8 = 9;
      ExceptionList = &pvStack_10;
      cVar6 = FUN_00983210(param_1);
      if ((cVar6 != '\0') &&
         (puVar10 = (undefined4 *)(**(code **)(*param_1 + 0xac))(),
         (undefined4 *)auStack_64 != puVar10)) {
        puVar2 = puVar10 + 4;
        if (0xf < (uint)puVar10[5]) {
          puVar10 = (undefined4 *)*puVar10;
        }
        FUN_005542c0(puVar10,*puVar2);
      }
      puStack_1c = param_4;
      piStack_18 = (int *)0x0;
      FUN_0054ef60(auStack_64);
      uStack_8._0_1_ = 10;
      pcVar3 = *(code **)(*param_1 + 8);
      uStack_13c = FUN_0088cb40();
      uStack_138 = 0;
      uStack_134 = uStack_34;
      uStack_130 = uStack_30;
      uStack_12c = uStack_2c;
      uStack_128 = uStack_28;
      uStack_34 = uStack_34 & 0xffffff00;
      puStack_24 = (undefined4 *)0x0;
      piStack_20 = (int *)0xf;
      uStack_138 = FUN_005c9d30();
      uStack_8._0_1_ = 0xb;
      uStack_44 = 0;
      uStack_40 = 0;
      piStack_3c = (int *)0x0;
      FUN_00687980(&uStack_13c,&iStack_6c,param_4);
      uStack_8._0_1_ = 0xc;
      (*pcVar3)(&DAT_01eebf90,&uStack_44,&puStack_1c);
      uStack_8._0_1_ = 0xd;
      FUN_00577b20();
      uStack_8 = CONCAT31(uStack_8._1_3_,10);
      FUN_016f32d1(&uStack_13c,0xd0,1,FUN_0056e5b0);
      if (0xf < piStack_20) {
        uVar13 = (int)piStack_20 + 1;
        uVar11 = uStack_34;
        if (0xfff < uVar13) {
          uVar11 = *(uint *)(uStack_34 - 4);
          uVar13 = (int)piStack_20 + 0x24;
          if (0x1f < (uStack_34 - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar11,uVar13);
      }
      iVar9 = FUN_005507b0();
      ExceptionList = pvStack_10;
      return iVar9;
    }
    ExceptionList = &pvStack_10;
    iVar9 = FUN_009cba80(param_2,param_3,param_4);
  }
  ExceptionList = pvStack_10;
  return iVar9;
}



/* FUNCTION 22589 ; VA 0x00ae60c0 ; FUN_00ae60c0 */

void FUN_00ae60c0(int param_1)

{
  int *piVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 ***apppuStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(param_1 + 0x43c);
  ExceptionList = &pvStack_10;
  FUN_01675640(apppuStack_28,&DAT_018bed48,*piVar1 - (int)piVar1,piVar1[1] - (int)piVar1);
  ppppuVar2 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar2 = (undefined4 ****)apppuStack_28[0];
  }
  uStack_8 = 0;
  FUN_0087c450(&DAT_018c5f98,"Load Named LinkedSource",ppppuVar2,0,0,0);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar3) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22590 ; VA 0x00ae6170 ; FUN_00ae6170 */

undefined * FUN_00ae6170(void)

{
  return &DAT_01d66924;
}



/* FUNCTION 22591 ; VA 0x00ae6180 ; FUN_00ae6180 */

int __fastcall FUN_00ae6180(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  
  iVar1 = param_1 + 0x7c;
  if (*(int *)(param_1 + 0x8c) == 0) {
    uStack_1c = 0xae619b;
    puStack_18 = (undefined4 *)param_1;
    iVar2 = FUN_008f7870();
    if (iVar2 == 0) {
      uStack_1c = 0xae61c3;
      puStack_18 = (undefined4 *)iVar1;
      FUN_01531f50();
    }
    else {
      FUN_0060dcd0(&uStack_1c,param_1);
      FUN_00907ef0(iVar1);
    }
    puStack_18 = &DAT_01eebf14;
    uStack_1c = 0xae61d2;
    FUN_008a4940();
  }
  return iVar1;
}



/* FUNCTION 22592 ; VA 0x00ae61e0 ; FUN_00ae61e0 */

void __thiscall FUN_00ae61e0(int param_1,undefined4 param_2)

{
  char cVar1;
  
  cVar1 = FUN_008868d0(param_1 + 0xac);
  if (cVar1 != '\0') {
    FUN_00886840(param_2);
    FUN_008a4940(&DAT_01eebda8);
  }
  return;
}



/* FUNCTION 22593 ; VA 0x00ae6220 ; FUN_00ae6220 */

void __thiscall FUN_00ae6220(int param_1,int param_2)

{
  if (param_2 != *(int *)(param_1 + 0xb4)) {
    *(int *)(param_1 + 0xb4) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 22594 ; VA 0x00ae6250 ; FUN_00ae6250 */

int __thiscall FUN_00ae6250(int *param_1,int param_2)

{
  int *piVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  char *pcStack_48;
  int **ppiStack_44;
  int *piStack_40;
  undefined auStack_30 [8];
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eb2d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01eebd99 != 0) {
    if (param_2 == 0) {
      piStack_40 = (int *)&DAT_018de934;
    }
    else {
      piStack_40 = *(int **)(param_2 + 0x28);
      if (0xf < (uint)piStack_40[5]) {
        piStack_40 = (int *)*piStack_40;
      }
    }
    ppiStack_44 = (int **)param_1[10];
    if (0xf < (uint)((int *)ppiStack_44)[5]) {
      ppiStack_44 = (int **)*ppiStack_44;
    }
    pcStack_48 = "New editor for Script %s: %s";
    ExceptionList = &pvStack_10;
    FUN_01677520(DAT_01eebd99);
  }
  piStack_40 = &iStack_24;
  ppiStack_44 = (int **)0xae62c0;
  FUN_00587490();
  uStack_8 = 0;
  if (iStack_24 == param_2) goto LAB_00ae65a8;
  if (DAT_01eebd99 != 0) {
    if (param_2 == 0) {
      piStack_40 = (int *)&DAT_018de934;
    }
    else {
      piStack_40 = *(int **)(param_2 + 0x28);
      if (0xf < (uint)piStack_40[5]) {
        piStack_40 = (int *)*piStack_40;
      }
    }
    if (iStack_24 == 0) {
      ppiStack_44 = (int **)&DAT_018de934;
    }
    else {
      ppiStack_44 = *(int ***)(iStack_24 + 0x28);
      if (0xf < ppiStack_44[5]) {
        ppiStack_44 = (int **)*ppiStack_44;
      }
    }
    pcStack_48 = "Current editor %s is different than new editor %s";
    FUN_01677520(DAT_01eebd99);
  }
  piStack_40 = (int *)0x0;
  pcStack_48 = (char *)0xae632c;
  ppiStack_44 = (int **)param_1;
  cVar2 = FUN_00971ce0();
  if (cVar2 != '\0') {
    if (DAT_01eebd99 != 0) {
      if (param_1 == (int *)0x0) {
LAB_00ae6446:
        iVar5 = 0;
      }
      else {
        piStack_14 = (int *)param_1[0xd];
        piVar3 = param_1;
        if ((piStack_14 != (int *)0x0) && (piVar3 = piStack_14, piStack_14[0xd] != 0)) {
          piStack_40 = (int *)0xae6362;
          piVar3 = (int *)FUN_005c8ac0();
        }
        piStack_14 = piVar3;
        if (piStack_14 == (int *)0x0) goto LAB_00ae6446;
        iVar5 = piStack_14[3];
        piStack_40 = (int *)0xae637c;
        iVar4 = FUN_008a8c30();
        if ((uint)*(ushort *)(iVar4 + 0x1da) <
            (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) goto LAB_00ae6446;
        piStack_40 = (int *)&LAB_0055d570;
        ppiStack_44 = (int **)&DAT_01ea8a70;
        pcStack_48 = (char *)0xae63aa;
        FUN_005789c0();
        piStack_40 = (int *)0xae63b2;
        piStack_40 = (int *)FUN_00560c40();
        ppiStack_44 = (int **)0xae63bd;
        piStack_14 = (int *)FUN_008aa140();
        if (*piStack_14 == 0) {
          piStack_40 = (int *)0xae63ca;
          piStack_40 = (int *)FUN_00961660();
          ppiStack_44 = (int **)auStack_1c;
          pcStack_48 = (char *)0xae63d6;
          piVar3 = (int *)FUN_008a9ba0();
          iVar5 = *piVar3;
          iVar4 = piVar3[1];
          *piVar3 = 0;
          piVar3[1] = 0;
          *piStack_14 = iVar5;
          piVar3 = (int *)piStack_14[1];
          piStack_14[1] = iVar4;
          if (piVar3 != (int *)0x0) {
            LOCK();
            iVar5 = piVar3[1] + -1;
            piVar3[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              piStack_40 = (int *)0xae6406;
              (**(code **)*piVar3)();
              LOCK();
              iVar5 = piVar3[2] + -1;
              piVar3[2] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                piStack_40 = (int *)0xae6416;
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
          piVar3 = piStack_18;
          if (piStack_18 != (int *)0x0) {
            LOCK();
            iVar5 = piStack_18[1] + -1;
            piStack_18[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              piStack_40 = (int *)0xae642f;
              (**(code **)*piStack_18)();
              LOCK();
              piVar1 = piVar3 + 2;
              iVar5 = *piVar1 + -1;
              *piVar1 = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                piStack_40 = (int *)0xae643f;
                (**(code **)(*piVar3 + 4))();
              }
            }
          }
        }
        iVar5 = *piStack_14;
      }
      piStack_40 = (int *)&DAT_018bf8dc;
      if (iVar5 == 0) {
        piStack_40 = (int *)&DAT_018c7824;
      }
      pcStack_48 = (char *)(uint)DAT_01eebd99;
      ppiStack_44 = (int **)0x194c380;
      FUN_01677520();
    }
    if (iStack_24 != 0) {
      piStack_40 = (int *)0xae647e;
      FUN_01679490();
    }
    if (param_2 != 0) {
      ppiStack_44 = (int **)0xae648f;
      piStack_40 = param_1;
      iVar5 = FUN_0064e810();
      if (iVar5 != 0) {
        piStack_40 = (int *)(uint)DAT_01eebd9a;
        FUN_0060e0c0(&pcStack_48,param_1);
        piStack_40 = (int *)FUN_00ae2f70(auStack_30,FUN_00ae5920);
        ppiStack_44 = &piStack_18;
        uStack_8._0_1_ = 1;
        pcStack_48 = (char *)0xae64d8;
        piStack_40 = (int *)FUN_00ae32c0();
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        ppiStack_44 = (int **)0xae64eb;
        piStack_14 = piStack_40;
        cVar2 = FUN_01679300();
        if (cVar2 != '\0') {
          piStack_40 = (int *)0xae64fa;
          FUN_01679490();
          piStack_40 = piStack_14;
          ppiStack_44 = (int **)0xae6508;
          FUN_016791c0();
        }
        if (piStack_18 != (int *)0x0) {
          piVar3 = piStack_18 + 1;
          LOCK();
          iVar5 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar5 == 1) {
            piStack_40 = piStack_18;
            ppiStack_44 = (int **)0xae6525;
            FUN_01674ea0();
          }
        }
        uStack_8 = uStack_8 & 0xffffff00;
        if (piStack_28 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_28[2] + -1;
          piStack_28[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            piStack_40 = (int *)0xae6541;
            (**(code **)(*piStack_28 + 4))();
          }
        }
      }
    }
  }
  ppiStack_44 = (int **)auStack_1c;
  piStack_40 = (int *)param_2;
  pcStack_48 = (char *)0xae654e;
  piVar3 = (int *)FUN_0060e0c0();
  iVar5 = *piVar3;
  iVar4 = piVar3[1];
  *piVar3 = 0;
  piVar3[1] = 0;
  param_1[0x2e] = iVar5;
  piVar3 = (int *)param_1[0x2f];
  param_1[0x2f] = iVar4;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[2] + -1;
    piVar3[2] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      piStack_40 = (int *)0xae6587;
      (**(code **)(*piVar3 + 4))();
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_18[2] + -1;
    piStack_18[2] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      piStack_40 = (int *)0xae659c;
      (**(code **)(*piStack_18 + 4))();
    }
  }
  piStack_40 = &DAT_01eebed8;
  ppiStack_44 = (int **)0xae65a8;
  param_2 = FUN_008a4940();
LAB_00ae65a8:
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_20 + 1;
    iVar5 = *piVar3;
    param_2 = *piVar3;
    *piVar3 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      piStack_40 = (int *)0xae65be;
      param_2 = (**(code **)*piStack_20)();
      LOCK();
      piVar3 = piStack_20 + 2;
      iVar5 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        piStack_40 = (int *)0xae65cd;
        param_2 = (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 22595 ; VA 0x00ae65e0 ; FUN_00ae65e0 */

void __thiscall FUN_00ae65e0(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0xc4) != param_2) {
    *(char *)(param_1 + 0xc4) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 22596 ; VA 0x00ae6610 ; FUN_00ae6610 */

void __thiscall FUN_00ae6610(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0xc5) = param_2;
  FUN_008a4940();
  return;
}



/* FUNCTION 22597 ; VA 0x00ae6630 ; FUN_00ae6630 */

void __thiscall FUN_00ae6630(int ***param_1,int ***param_2)

{
  int ***pppiVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  int **ppiVar5;
  int **ppiStack_54;
  int **ppiStack_50;
  undefined auStack_40 [24];
  int **appiStack_28 [4];
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017aa5a0;
  pvStack_10 = ExceptionList;
  ppiStack_50 = (int **)param_2;
  if ((int **)0xf < param_2[5]) {
    ppiStack_50 = *param_2;
  }
  ppiStack_54 = (int **)0x194c2d4;
  ExceptionList = &pvStack_10;
  _guard_check_icall();
  pppiVar1 = param_1 + 0x1f;
  cVar2 = FUN_00558b30(pppiVar1,param_2);
  if (cVar2 != '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  ppiStack_54 = (int **)0xae6686;
  ppiStack_50 = (int **)pppiVar1;
  FUN_0054ef60();
  iStack_8 = 0;
  if (DAT_01d6691c != '\0') {
    ppiStack_50 = (int **)param_2;
    ppiStack_54 = (int **)0xae669c;
    cVar2 = FUN_009c9250();
    if ((cVar2 == '\0') && (param_2[4] != (int **)0x0)) {
      ppiStack_54 = (int **)0xae66af;
      ppiStack_50 = (int **)pppiVar1;
      FUN_01531f50();
      ppiStack_50 = (int **)pppiVar1;
      if ((int **)0xf < param_1[0x24]) {
        ppiStack_50 = *pppiVar1;
      }
      if ((int **)0xf < param_2[5]) {
        param_2 = (int ***)*param_2;
      }
      ppiStack_54 = (int **)param_2;
      uVar3 = FUN_01675640(auStack_40,"ScriptGuid \"%s\" invalid.  Replaced with \"%s\".");
      iStack_8._0_1_ = 1;
      FUN_0086ed30(1,uVar3,6);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      ppiStack_50 = (int **)0xae66f1;
      FUN_005507b0();
      goto LAB_00ae670b;
    }
  }
  if (pppiVar1 != param_2) {
    ppiStack_50 = param_2[4];
    if ((int **)0xf < param_2[5]) {
      param_2 = (int ***)*param_2;
    }
    ppiStack_54 = (int **)param_2;
    FUN_005542c0();
  }
LAB_00ae670b:
  ppiStack_50 = (int **)&DAT_01eebf14;
  ppiStack_54 = (int **)0xae6717;
  FUN_008a4940();
  ppiStack_54 = (int **)0xae671d;
  ppiStack_50 = (int **)param_1;
  iVar4 = FUN_008f7870();
  if (iVar4 != 0) {
    if (iStack_18 != 0) {
      ppiStack_50 = (int **)appiStack_28;
      ppiStack_54 = (int **)0xae6737;
      FUN_008f3450();
    }
    if (param_1[0x23] != (int **)0x0) {
      FUN_0060dcd0(&ppiStack_54,param_1);
      FUN_00907ef0(pppiVar1);
    }
  }
  if (0xf < uStack_14) {
    ppiStack_50 = (int **)(uStack_14 + 1);
    ppiVar5 = appiStack_28[0];
    if (0xfff < ppiStack_50) {
      ppiVar5 = (int **)appiStack_28[0][-1];
      ppiStack_50 = (int **)(uStack_14 + 0x24);
      if (0x1f < (uint)((int)appiStack_28[0] + (-4 - (int)ppiVar5))) {
                    /* WARNING: Subroutine does not return */
        ppiStack_50 = (int **)&UNK_00ae679f;
        FUN_017167a3();
      }
    }
    ppiStack_54 = ppiVar5;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22598 ; VA 0x00ae67a0 ; FUN_00ae67a0 */

void __thiscall FUN_00ae67a0(int *param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  
  cVar2 = FUN_00684460(param_2,param_1 + 0x25);
  if (cVar2 != '\0') {
    if (param_1 + 0x25 != param_2) {
      piVar1 = param_2 + 4;
      if (0xf < (uint)param_2[5]) {
        param_2 = (int *)*param_2;
      }
      FUN_005542c0(param_2,*piVar1);
    }
    (**(code **)(*param_1 + 0xb0))();
  }
  return;
}



/* FUNCTION 22599 ; VA 0x00ae67f0 ; FUN_00ae67f0 */

int FUN_00ae67f0(undefined4 param_1,int param_2,int *param_3)

{
  int *piVar1;
  uint uVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  uint *puVar7;
  uint uStack_50;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint *puStack_24;
  char cStack_20;
  uint *puStack_1c;
  int iStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eb32f;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01eebd98 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01eebd98,"Done preloading linked scripts id=%p",param_2);
  }
  iVar4 = FUN_008f7870(*(undefined4 *)(param_2 + 0x28));
  iVar6 = 0;
  iStack_18 = 0;
  uStack_8._0_1_ = 1;
  cVar3 = FUN_008f2030();
  if (cVar3 == '\0') {
    puStack_1c = (uint *)FUN_01674e20(8);
    uStack_8._0_1_ = 2;
    if (puStack_1c == (uint *)0x0) {
      iVar6 = 0;
    }
    else if (iVar4 == 0) {
      iVar6 = FUN_008e9960(0);
    }
    else {
      iVar6 = FUN_008e9960(iVar4 + 0xc);
    }
    uStack_8._0_1_ = 1;
    iStack_18 = iVar6;
  }
  puStack_24 = (uint *)(param_2 + 0x34);
  cStack_20 = '\0';
  FUN_00587410();
  puStack_14 = *(uint **)(param_2 + 0x3c);
  puStack_1c = *(uint **)(param_2 + 0x40);
  if (puStack_14 != puStack_1c) {
    puVar7 = puStack_14 + 2;
    do {
      uStack_8._0_1_ = 3;
      uVar2 = *puStack_14;
      uStack_50 = 0;
      if (uVar2 != 0) {
        uStack_50 = uVar2;
        if ((uVar2 & 1) == 0) {
          (**(code **)(uVar2 & 0xfffffffe))(puVar7,&uStack_48,0);
        }
        else {
          uStack_48 = *puVar7;
          uStack_44 = puVar7[1];
          uStack_40 = puVar7[2];
          uStack_3c = puVar7[3];
          uStack_38 = puVar7[4];
          uStack_34 = puVar7[5];
        }
      }
      uStack_8._0_1_ = 4;
      if (uStack_50 == 0) {
        uVar5 = FUN_0054fda0();
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
                    /* WARNING: Subroutine does not return */
        FUN_0054e5e0(uVar5);
      }
      (**(code **)((uStack_50 & 0xfffffffe) + 4))(&uStack_48);
      uStack_8._0_1_ = 6;
      if (((uStack_50 != 0) && ((uStack_50 & 1) == 0)) &&
         (*(code **)(uStack_50 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_50 & 0xfffffffe))(&uStack_48,&uStack_48,2);
      }
      puVar7 = puVar7 + 8;
      puStack_14 = puStack_14 + 8;
    } while (puStack_14 != puStack_1c);
  }
  uStack_8._0_1_ = 7;
  if (cStack_20 != '\0') {
    LOCK();
    uVar2 = *puStack_24;
    *puStack_24 = *puStack_24 + 0x80000000;
    UNLOCK();
    if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
      LOCK();
      uVar2 = *puStack_24;
      *puStack_24 = *puStack_24 | 0x40000000;
      UNLOCK();
      if ((uVar2 >> 0x1e & 1) == 0) {
        uVar5 = FUN_00554e40();
        SetEvent(uVar5);
      }
    }
  }
  uStack_8._0_1_ = 1;
  if (*(uint *)(param_2 + 8) != 0) {
    iVar4 = (**(code **)((*(uint *)(param_2 + 8) & 0xfffffffe) + 4))(param_2 + 0x10);
    if (iVar6 != 0) {
      FUN_008eb200();
      iVar4 = FUN_01674ea0(iVar6,8);
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      piVar1 = param_3 + 1;
      iVar6 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar4 = (**(code **)*param_3)();
        LOCK();
        piVar1 = param_3 + 2;
        iVar6 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          iVar4 = (**(code **)(*param_3 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return iVar4;
  }
  uVar5 = FUN_0054fda0();
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar5);
}



/* FUNCTION 22600 ; VA 0x00ae6a30 ; FUN_00ae6a30 */

void FUN_00ae6a30(undefined4 param_1)

{
  FUN_008a7d30(param_1);
  FUN_00ae4190(param_1);
  return;
}



/* FUNCTION 22601 ; VA 0x00ae6a50 ; FUN_00ae6a50 */

void FUN_00ae6a50(undefined4 param_1)

{
  FUN_00ae4190(param_1);
  return;
}



/* FUNCTION 22602 ; VA 0x00ae6a70 ; FUN_00ae6a70 */

void FUN_00ae6a70(undefined4 param_1,uint param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eb350;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)((param_2 & 0xfffffffe) + 4))(&stack0x00000010);
    uStack_8 = 2;
    if (((param_2 != 0) && ((param_2 & 1) == 0)) &&
       (*(code **)(param_2 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_2 & 0xfffffffe))(&stack0x00000010,&stack0x00000010,2);
    }
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0054fda0();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar1);
}



/* FUNCTION 22603 ; VA 0x00ae6af0 ; FUN_00ae6af0 */

void FUN_00ae6af0(undefined4 param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1);
  FUN_00aee810(param_2);
  return;
}



/* FUNCTION 22604 ; VA 0x00ae6b40 ; FUN_00ae6b40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00ae6b40(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eb380;
  pvStack_10 = ExceptionList;
  if (DAT_01eec2ac == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eec4c0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eec4c0);
      if (DAT_01eec4c0 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Animator",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01eec4b8 = RBX::Creator<class_RBX::Animator>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01eec2b0,&DAT_01eec4b8);
        FUN_016f3654(FUN_0188bef0);
        FUN_016f37bf(&DAT_01eec4c0);
      }
    }
    DAT_01eec2ac = &DAT_01eec2b0;
  }
  ExceptionList = pvStack_10;
  return DAT_01eec2ac;
}



/* FUNCTION 22605 ; VA 0x00ae6c40 ; FUN_00ae6c40 */

void FUN_00ae6c40(undefined4 param_1,undefined4 param_2)

{
  FUN_00ae7ed0(param_2);
  return;
}



/* FUNCTION 22606 ; VA 0x00ae6c50 ; FUN_00ae6c50 */

int __thiscall FUN_00ae6c50(int *param_1,int param_2,undefined4 *param_3)

{
  uint uVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  uint uVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  
  iVar9 = *param_1;
  iVar5 = param_2 - iVar9 >> 4;
  iVar6 = param_1[1] - iVar9 >> 4;
  if (iVar6 == 0xfffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar6 + 1;
  uVar10 = param_1[2] - iVar9 >> 4;
  uVar7 = uVar1;
  if ((uVar10 <= 0xfffffff - (uVar10 >> 1)) && (uVar7 = (uVar10 >> 1) + uVar10, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  uVar10 = uVar7 * 0x10;
  if (uVar7 < 0x10000000) {
    if (0xfff < uVar10) goto LAB_00ae6cc2;
    if (uVar10 == 0) {
      puVar11 = (undefined4 *)0x0;
    }
    else {
      puVar11 = (undefined4 *)FUN_01674e20(uVar10);
    }
  }
  else {
    uVar10 = 0xffffffff;
LAB_00ae6cc2:
    uVar8 = uVar10 + 0x23;
    if (uVar8 <= uVar10) {
      uVar8 = 0xffffffff;
    }
    iVar9 = FUN_01674e20(uVar8);
    if (iVar9 == 0) goto LAB_00ae6df1;
    puVar11 = (undefined4 *)(iVar9 + 0x23U & 0xffffffe0);
    puVar11[-1] = iVar9;
  }
  puVar3 = puVar11 + iVar5 * 4;
  *puVar3 = 0;
  puVar3[1] = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar2 = (int *)(param_3[1] + 8);
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  *puVar3 = *param_3;
  puVar3[1] = param_3[1];
  puVar3[2] = param_3[2];
  puVar3[3] = param_3[3];
  iVar6 = param_1[1];
  iVar9 = *param_1;
  puVar12 = puVar11;
  if (param_2 != iVar6) {
    FUN_00ae7720(iVar9,param_2,puVar11,param_1);
    iVar6 = param_1[1];
    iVar9 = param_2;
    puVar12 = puVar3 + 4;
  }
  FUN_00ae7720(iVar9,iVar6,puVar12,param_1);
  iVar9 = *param_1;
  if (iVar9 != 0) {
    iVar6 = param_1[1];
    if (iVar9 != iVar6) {
      do {
        piVar2 = *(int **)(iVar9 + 4);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar4 = piVar2[2] + -1;
          piVar2[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        iVar9 = iVar9 + 0x10;
      } while (iVar9 != iVar6);
      iVar9 = *param_1;
    }
    uVar10 = param_1[2] - iVar9 & 0xfffffff0;
    iVar6 = iVar9;
    if (0xfff < uVar10) {
      iVar6 = *(int *)(iVar9 + -4);
      uVar10 = uVar10 + 0x23;
      if (0x1f < (iVar9 - iVar6) - 4U) {
LAB_00ae6df1:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar10);
  }
  *param_1 = (int)puVar11;
  param_1[1] = (int)(puVar11 + uVar1 * 4);
  param_1[2] = (int)(puVar11 + uVar7 * 4);
  return *param_1 + iVar5 * 0x10;
}



/* FUNCTION 22607 ; VA 0x00ae6e00 ; FUN_00ae6e00 */

int __thiscall FUN_00ae6e00(uint *param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  int iVar11;
  
  uVar3 = *param_1;
  iVar11 = (int)((int)param_2 - uVar3) >> 2;
  iVar1 = (int)(param_1[1] - uVar3) >> 2;
  if (iVar1 == 0x3fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar2 = iVar1 + 1;
  uVar5 = (int)(param_1[2] - uVar3) >> 2;
  uVar3 = uVar2;
  if ((uVar5 <= 0x3fffffff - (uVar5 >> 1)) && (uVar3 = (uVar5 >> 1) + uVar5, uVar3 < uVar2)) {
    uVar3 = uVar2;
  }
  uVar5 = uVar3 * 4;
  if (uVar3 < 0x40000000) {
    if (0xfff < uVar5) goto LAB_00ae6e72;
    if (uVar5 == 0) {
      puVar8 = (undefined4 *)0x0;
    }
    else {
      puVar8 = (undefined4 *)FUN_01674e20(uVar5);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_00ae6e72:
    uVar4 = uVar5 + 0x23;
    if (uVar4 <= uVar5) {
      uVar4 = 0xffffffff;
    }
    iVar1 = FUN_01674e20(uVar4);
    if (iVar1 == 0) goto LAB_00ae6fa7;
    puVar8 = (undefined4 *)(iVar1 + 0x23U & 0xffffffe0);
    puVar8[-1] = iVar1;
  }
  puVar9 = puVar8 + iVar11;
  uVar5 = 0;
  *puVar9 = *param_3;
  puVar10 = (undefined4 *)param_1[1];
  puVar6 = (undefined4 *)*param_1;
  if (param_2 == puVar10) {
    uVar4 = (uint)((int)puVar10 + (3 - (int)puVar6)) >> 2;
    if (puVar10 < puVar6) {
      uVar4 = 0;
    }
    puVar9 = puVar8;
    if (uVar4 != 0) {
      do {
        uVar5 = uVar5 + 1;
        *puVar9 = *puVar6;
        puVar6 = puVar6 + 1;
        puVar9 = puVar9 + 1;
      } while (uVar5 != uVar4);
    }
  }
  else {
    uVar4 = (uint)((int)param_2 + (3 - (int)puVar6)) >> 2;
    if (param_2 < puVar6) {
      uVar4 = 0;
    }
    puVar10 = puVar8;
    if (uVar4 != 0) {
      do {
        uVar5 = uVar5 + 1;
        *puVar10 = *puVar6;
        puVar6 = puVar6 + 1;
        puVar10 = puVar10 + 1;
      } while (uVar5 != uVar4);
    }
    uVar5 = 0;
    uVar4 = (uint)((int)param_1[1] + (3 - (int)param_2)) >> 2;
    if ((undefined4 *)param_1[1] < param_2) {
      uVar4 = 0;
    }
    if (uVar4 != 0) {
      puVar6 = puVar9 + 1;
      do {
        uVar5 = uVar5 + 1;
        *puVar6 = *(undefined4 *)((int)puVar6 + ((int)param_2 - (int)(puVar9 + 1)));
        puVar6 = puVar6 + 1;
      } while (uVar5 != uVar4);
    }
  }
  uVar5 = *param_1;
  if (uVar5 != 0) {
    uVar7 = param_1[2] - uVar5 & 0xfffffffc;
    uVar4 = uVar5;
    if (0xfff < uVar7) {
      uVar4 = *(uint *)(uVar5 - 4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (uVar5 - uVar4) - 4) {
LAB_00ae6fa7:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar7);
  }
  *param_1 = (uint)puVar8;
  param_1[1] = (uint)(puVar8 + uVar2);
  param_1[2] = (uint)(puVar8 + uVar3);
  return *param_1 + iVar11 * 4;
}



/* FUNCTION 22608 ; VA 0x00ae6fc0 ; FUN_00ae6fc0 */

void __thiscall
FUN_00ae6fc0(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 param_4,int param_5)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  int *piVar8;
  int *piVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar7 = param_4;
  puStack_c = &LAB_017eb390;
  pvStack_10 = ExceptionList;
  cVar4 = '\x01';
  uStack_8 = 0;
  piVar8 = (int *)((int *)*param_1)[1];
  piVar9 = (int *)*param_1;
  ExceptionList = &pvStack_10;
  while (*(char *)((int)piVar8 + 0xd) == '\0') {
    if ((char)param_3 == '\0') {
      cVar4 = FUN_00558ea0(uVar7,piVar8 + 4);
    }
    else {
      cVar4 = FUN_00558ea0(piVar8 + 4,uVar7);
      cVar4 = cVar4 == '\0';
    }
    piVar9 = piVar8;
    if (cVar4 == '\0') {
      piVar8 = (int *)piVar8[2];
    }
    else {
      piVar8 = (int *)*piVar8;
    }
  }
  piVar8 = piVar9;
  if (cVar4 != '\0') {
    if (piVar9 == *(int **)*param_1) {
      cVar4 = '\x01';
      goto LAB_00ae705a;
    }
    if (*(char *)((int)piVar9 + 0xd) == '\0') {
      piVar8 = (int *)*piVar9;
      if (*(char *)((int)piVar8 + 0xd) == '\0') {
        cVar5 = *(char *)(piVar8[2] + 0xd);
        piVar1 = (int *)piVar8[2];
        while (cVar5 == '\0') {
          cVar5 = *(char *)(piVar1[2] + 0xd);
          piVar8 = piVar1;
          piVar1 = (int *)piVar1[2];
        }
      }
      else {
        cVar5 = *(char *)(piVar9[1] + 0xd);
        piVar1 = (int *)piVar9[1];
        piVar8 = piVar9;
        while ((piVar2 = piVar1, cVar5 == '\0' &&
               (uVar7 = param_4, param_3 = piVar2, piVar8 == (int *)*piVar2))) {
          cVar5 = *(char *)(piVar2[1] + 0xd);
          piVar1 = (int *)piVar2[1];
          piVar8 = piVar2;
        }
        if (*(char *)((int)piVar8 + 0xd) == '\0') {
          piVar8 = piVar2;
        }
      }
    }
    else {
      piVar8 = (int *)piVar9[2];
    }
  }
  cVar5 = FUN_00558ea0(piVar8 + 4,uVar7);
  iVar3 = param_5;
  if (cVar5 == '\0') {
    FUN_005f53f0(param_1,param_5 + 0x10);
    FUN_01674ea0(iVar3,0x30);
    *param_2 = piVar8;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00ae705a:
  puVar6 = (undefined4 *)FUN_008dd860(&param_3,cVar4,piVar9,uVar7,param_5);
  *param_2 = *puVar6;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22609 ; VA 0x00ae7139 ; Catch_All@00ae7139 */

void Catch_All_00ae7139(void)

{
  int unaff_EBP;
  
  FUN_008edc70(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 22610 ; VA 0x00ae7150 ; FUN_00ae7150 */

void __thiscall FUN_00ae7150(int *param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  int iVar8;
  uint uVar9;
  uint uStack_8;
  
  iVar5 = *param_1;
  uVar9 = param_1[1] - iVar5 >> 5;
  uStack_8 = param_1[2] - iVar5 >> 5;
  if (param_2 <= uStack_8) {
    if (param_2 <= uVar9) {
      if (param_2 != uVar9) {
        param_1[1] = param_2 * 0x20 + iVar5;
      }
      return;
    }
    iVar5 = FUN_00ae8d90(param_1[1],param_2 - uVar9);
    param_1[1] = iVar5;
    return;
  }
  if (0x7ffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  if (0x7ffffff - (uStack_8 >> 1) < uStack_8) {
    uStack_8 = param_2;
  }
  else {
    uStack_8 = (uStack_8 >> 1) + uStack_8;
    if (uStack_8 < param_2) {
      uStack_8 = param_2;
    }
  }
  iVar5 = FUN_00577f40(uStack_8);
  FUN_00ae8d90(uVar9 * 0x20 + iVar5,param_2 - uVar9);
  puVar6 = (undefined4 *)*param_1;
  puVar7 = (undefined4 *)param_1[1];
  if (puVar6 != puVar7) {
    iVar8 = iVar5 - (int)puVar6;
    do {
      uVar2 = puVar6[1];
      uVar3 = puVar6[2];
      uVar4 = puVar6[3];
      puVar1 = (undefined4 *)(iVar8 + (int)puVar6);
      *puVar1 = *puVar6;
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      uVar2 = puVar6[5];
      uVar3 = puVar6[6];
      uVar4 = puVar6[7];
      puVar1 = (undefined4 *)(iVar8 + 0x10 + (int)puVar6);
      *puVar1 = puVar6[4];
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      puVar6 = puVar6 + 8;
    } while (puVar6 != puVar7);
    puVar6 = (undefined4 *)*param_1;
  }
  if (puVar6 != (undefined4 *)0x0) {
    uVar9 = param_1[2] - (int)puVar6 & 0xffffffe0;
    puVar7 = puVar6;
    if (0xfff < uVar9) {
      puVar7 = (undefined4 *)puVar6[-1];
      uVar9 = uVar9 + 0x23;
      if (0x1f < (uint)((int)puVar6 + (-4 - (int)puVar7))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar7,uVar9);
  }
  *param_1 = iVar5;
  param_1[1] = param_2 * 0x20 + iVar5;
  param_1[2] = uStack_8 * 0x20 + iVar5;
  return;
}



/* FUNCTION 22611 ; VA 0x00ae7280 ; FUN_00ae7280 */

void __thiscall FUN_00ae7280(uint *param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  uint uVar11;
  
  uVar7 = (int)(param_1[1] - *param_1) / 0x2c;
  uVar8 = (int)(param_1[2] - *param_1) / 0x2c;
  if (param_2 <= uVar8) {
    if (param_2 <= uVar7) {
      if (param_2 != uVar7) {
        param_1[1] = param_2 * 0x2c + *param_1;
      }
      return;
    }
    uVar7 = FUN_00ae8a70(param_1[1],param_2 - uVar7);
    param_1[1] = uVar7;
    return;
  }
  if (0x5d1745d < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar11 = param_2;
  if ((uVar8 <= 0x5d1745d - (uVar8 >> 1)) && (uVar11 = (uVar8 >> 1) + uVar8, uVar11 < param_2)) {
    uVar11 = param_2;
  }
  uVar8 = uVar11 * 0x2c;
  if (uVar11 < 0x5d1745e) {
    uVar11 = uVar8;
    if (0xfff < uVar8) goto LAB_00ae730c;
    if (uVar8 == 0) {
      uVar11 = 0;
    }
    else {
      uVar11 = FUN_01674e20(uVar8);
    }
  }
  else {
    uVar11 = 0xffffffff;
LAB_00ae730c:
    uVar5 = uVar11 + 0x23;
    if (uVar5 <= uVar11) {
      uVar5 = 0xffffffff;
    }
    iVar6 = FUN_01674e20(uVar5);
    if (iVar6 == 0) goto LAB_00ae742f;
    uVar11 = iVar6 + 0x23U & 0xffffffe0;
    *(int *)(uVar11 - 4) = iVar6;
  }
  FUN_00ae8a70(uVar7 * 0x2c + uVar11,param_2 - uVar7);
  puVar9 = (undefined4 *)*param_1;
  puVar10 = (undefined4 *)param_1[1];
  if (puVar9 != puVar10) {
    iVar6 = uVar11 - (int)puVar9;
    do {
      uVar2 = puVar9[1];
      uVar3 = puVar9[2];
      uVar4 = puVar9[3];
      puVar1 = (undefined4 *)(iVar6 + (int)puVar9);
      *puVar1 = *puVar9;
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      uVar2 = puVar9[5];
      uVar3 = puVar9[6];
      uVar4 = puVar9[7];
      puVar1 = (undefined4 *)(iVar6 + 0x10 + (int)puVar9);
      *puVar1 = puVar9[4];
      puVar1[1] = uVar2;
      puVar1[2] = uVar3;
      puVar1[3] = uVar4;
      *(undefined8 *)(iVar6 + 0x20 + (int)puVar9) = *(undefined8 *)(puVar9 + 8);
      *(undefined4 *)(iVar6 + 0x28 + (int)puVar9) = puVar9[10];
      puVar9 = puVar9 + 0xb;
    } while (puVar9 != puVar10);
    puVar9 = (undefined4 *)*param_1;
  }
  if (puVar9 != (undefined4 *)0x0) {
    uVar7 = ((int)(param_1[2] - (int)puVar9) / 0x2c) * 0x2c;
    puVar10 = puVar9;
    if (0xfff < uVar7) {
      puVar10 = (undefined4 *)puVar9[-1];
      uVar7 = uVar7 + 0x23;
      if (0x1f < (uint)((int)puVar9 + (-4 - (int)puVar10))) {
LAB_00ae742f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar10,uVar7);
  }
  *param_1 = uVar11;
  param_1[1] = param_2 * 0x2c + uVar11;
  param_1[2] = uVar8 + uVar11;
  return;
}



/* FUNCTION 22612 ; VA 0x00ae7440 ; FUN_00ae7440 */

void __thiscall FUN_00ae7440(int *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  
  uVar4 = param_2;
  uVar2 = (param_1[1] - *param_1) / 0xc;
  uVar3 = (param_1[2] - *param_1) / 0xc;
  if (param_2 <= uVar3) {
    if (param_2 <= uVar2) {
      if (param_2 != uVar2) {
        iVar5 = *param_1 + param_2 * 0xc;
        FUN_00a1ba80(iVar5,param_1[1],param_1);
        param_1[1] = iVar5;
      }
      return;
    }
    iVar5 = FUN_00a1ffe0(param_1[1],param_2 - uVar2);
    param_1[1] = iVar5;
    return;
  }
  if (0x15555555 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = param_2;
  if ((uVar3 <= 0x15555555 - (uVar3 >> 1)) && (uVar1 = (uVar3 >> 1) + uVar3, uVar1 < param_2)) {
    uVar1 = param_2;
  }
  param_2 = uVar1;
  iVar5 = FUN_00618050(param_2);
  FUN_00a1ffe0(iVar5 + uVar2 * 0xc,uVar4 - uVar2);
  FUN_00ae8df0(*param_1,param_1[1],iVar5);
  FUN_00ae8cb0(iVar5,uVar4,param_2);
  return;
}



/* FUNCTION 22613 ; VA 0x00ae7540 ; FUN_00ae7540 */

int __thiscall FUN_00ae7540(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eb3a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Animation*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 22614 ; VA 0x00ae7612 ; Catch_All@00ae7612 */

void Catch_All_00ae7612(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 22615 ; VA 0x00ae7630 ; FUN_00ae7630 */

int __thiscall FUN_00ae7630(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eb3b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::AnimationTrack*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 22616 ; VA 0x00ae7702 ; Catch_All@00ae7702 */

void Catch_All_00ae7702(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 22617 ; VA 0x00ae7720 ; FUN_00ae7720 */

undefined4 * FUN_00ae7720(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar4 = param_3;
  if (param_1 != param_2) {
    puVar3 = param_1 + 1;
    do {
      *puVar4 = 0;
      puVar1 = puVar3 + 4;
      *(undefined4 *)((int)param_3 + (-0x10 - (int)param_1) + (int)puVar1) = 0;
      *puVar4 = puVar3[-1];
      *(undefined4 *)((int)param_3 + (-0x10 - (int)param_1) + (int)puVar1) = *puVar3;
      puVar3[-1] = 0;
      *puVar3 = 0;
      puVar4[2] = puVar3[1];
      puVar4[3] = puVar3[2];
      puVar2 = puVar3 + 3;
      puVar4 = puVar4 + 4;
      puVar3 = puVar1;
    } while (puVar2 != param_2);
  }
  return puVar4;
}



/* FUNCTION 22618 ; VA 0x00ae7790 ; FUN_00ae7790 */

undefined4 * __thiscall FUN_00ae7790(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6248;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  puVar5 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00aeba60;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = param_1;
    uVar1 = param_3[1];
    uVar2 = param_3[2];
    uVar3 = param_3[3];
    puVar5[6] = *param_3;
    puVar5[7] = uVar1;
    puVar5[8] = uVar2;
    puVar5[9] = uVar3;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 22619 ; VA 0x00ae7850 ; FUN_00ae7850 */

undefined4 * FUN_00ae7850(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eb3f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00e63280();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x6c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00e63480();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00ae7540(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22620 ; VA 0x00ae7910 ; FUN_00ae7910 */

undefined4 *
FUN_00ae7910(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eb433;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00e643e0();
  uVar6 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar5 + 0x1dc) != (undefined4 *)0x0) {
    uVar6 = **(undefined4 **)(iVar5 + 0x1dc);
  }
  uVar6 = FUN_01675290(uVar6);
  uStack_8 = 1;
  iVar5 = FUN_01674e20(0xac);
  uStack_8._0_1_ = 2;
  if (iVar5 == 0) {
    uVar7 = 0;
  }
  else {
    if (param_4[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uVar7 = *param_4;
    uVar2 = param_4[1];
    if (param_3[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_3[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uVar3 = *param_3;
    uVar4 = param_3[1];
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uVar7 = FUN_00e64870(*param_2,param_2[1],uVar3,uVar4,uVar7,uVar2);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00ae7630(uVar7,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar6);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22621 ; VA 0x00ae7a60 ; FUN_00ae7a60 */

void __thiscall FUN_00ae7a60(int param_1,undefined4 *param_2,uint *param_3,int *param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eb448;
  pvStack_10 = ExceptionList;
  uVar3 = *param_3;
  uVar8 = (uVar3 >> 3) + uVar3;
  uVar7 = uVar8 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar5 = (int *)0x0;
  }
  else {
    puVar9 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (puVar9 == (undefined4 *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      piVar5 = (int *)*puVar9;
    }
    if (piVar5 == (int *)0x0) goto LAB_00ae7afe;
    do {
      if (uVar8 == piVar5[1]) {
        if (uVar3 == piVar5[2]) break;
      }
      else if ((uint)piVar5[1] % *(uint *)(param_1 + 4) != uVar7) goto LAB_00ae7afe;
      piVar5 = (int *)*piVar5;
    } while (piVar5 != (int *)0x0);
  }
  if (piVar5 != (int *)0x0) {
    *param_2 = piVar5;
    *(undefined *)(param_2 + 1) = 0;
    return;
  }
LAB_00ae7afe:
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar5 = (int *)FUN_01674e20(0xc);
  *piVar5 = 0;
  piVar5[1] = 0;
  piVar5[2] = 0;
  piVar5[2] = *param_4;
  uVar7 = *(uint *)(param_1 + 8);
  uVar3 = uVar7 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar3 = FUN_005d6bb0(uVar3);
    if (uVar3 <= *(uint *)(param_1 + 4)) {
      uVar3 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar3);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar3) {
    uVar6 = uVar7 >> 1;
    if (uVar7 + (uVar7 >> 1) <= uVar3) {
      uVar6 = 1;
    }
    iVar4 = FUN_005d6bb0(uVar6 + uVar7);
    if (iVar4 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar4);
      puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)*puVar9;
      while (puVar1 != (undefined4 *)0x0) {
        uVar3 = (uint)puVar1[1] % *(uint *)(param_1 + 4);
        piVar2 = (int *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar3 * 4) == 0) {
          *piVar2 = (int)puVar9;
          puVar9 = puVar1;
        }
        else {
          *puVar9 = *puVar1;
          *puVar1 = *(undefined4 *)*piVar2;
          *(undefined4 **)*piVar2 = puVar1;
        }
        puVar1 = (undefined4 *)*puVar9;
      }
    }
  }
  piVar5[1] = uVar8;
  uVar8 = uVar8 % *(uint *)(param_1 + 4);
  piVar2 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
  puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
  if (piVar2 == (int *)0x0) {
    piVar2 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar2 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar5;
    }
    *puVar9 = piVar2;
    *piVar5 = *piVar2;
    *piVar2 = (int)piVar5;
  }
  else {
    *piVar5 = *piVar2;
    *(int **)*puVar9 = piVar5;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = piVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22622 ; VA 0x00ae7c50 ; FUN_00ae7c50 */

void FUN_00ae7c50(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined uVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined *puVar10;
  int iVar11;
  int *piVar12;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eb468;
  pvStack_10 = ExceptionList;
  iVar11 = *param_2;
  iVar6 = *(int *)(iVar11 + 0x4e0);
  ExceptionList = &pvStack_10;
  iVar8 = FUN_0088c8c0();
  if (iVar6 != iVar8) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar9 = (undefined4 *)(iVar11 + 0x4e8);
  if (*(int *)(iVar11 + 0x4e4) == 0) {
    puVar9 = (undefined4 *)0x0;
  }
  uVar7 = *puVar9;
  iVar11 = *param_2;
  iVar6 = *(int *)(iVar11 + 0x410);
  iVar8 = FUN_0088c960();
  if (iVar6 != iVar8) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar9 = (undefined4 *)(iVar11 + 0x418);
  if (*(int *)(iVar11 + 0x414) == 0) {
    puVar9 = (undefined4 *)0x0;
  }
  uVar1 = *puVar9;
  iVar11 = *param_2;
  iVar6 = *(int *)(iVar11 + 0x340);
  iVar8 = FUN_0088c960();
  if (iVar6 != iVar8) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar9 = (undefined4 *)(iVar11 + 0x348);
  if (*(int *)(iVar11 + 0x344) == 0) {
    puVar9 = (undefined4 *)0x0;
  }
  uVar2 = *puVar9;
  iVar11 = *param_2;
  iVar6 = *(int *)(iVar11 + 0x270);
  iVar8 = FUN_0088c960();
  if (iVar6 == iVar8) {
    puVar9 = (undefined4 *)(iVar11 + 0x278);
    if (*(int *)(iVar11 + 0x274) == 0) {
      puVar9 = (undefined4 *)0x0;
    }
    uVar3 = *puVar9;
    iVar11 = *param_2;
    iVar6 = *(int *)(iVar11 + 0x1a0);
    iVar8 = FUN_0088c960();
    if (iVar6 != iVar8) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar9 = (undefined4 *)(iVar11 + 0x1a8);
    if (*(int *)(iVar11 + 0x1a4) == 0) {
      puVar9 = (undefined4 *)0x0;
    }
    uVar4 = *puVar9;
    iVar11 = *param_2;
    iVar6 = *(int *)(iVar11 + 0xd0);
    iVar8 = FUN_0088daf0();
    if (iVar6 == iVar8) {
      param_2 = (int *)*param_2;
      puVar10 = (undefined *)(iVar11 + 0xd8);
      iVar6 = *param_2;
      if (*(int *)(iVar11 + 0xd4) == 0) {
        puVar10 = (undefined *)0x0;
      }
      uVar5 = *puVar10;
      iVar11 = FUN_0088d190();
      if (iVar6 == iVar11) {
        piVar12 = param_2 + 2;
        if (param_2[1] == 0) {
          piVar12 = (int *)0x0;
        }
        FUN_0054ef60(piVar12);
        uStack_8 = 0;
        FUN_00ae8ae0(uStack_44,uStack_40,uStack_3c,uStack_38,CONCAT44(uStack_30,uStack_34),
                     CONCAT31((int3)((uint)puVar10 >> 8),uVar5),uVar4,uVar3,uVar2,uVar1,uVar7);
        ExceptionList = pvStack_10;
        return;
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22623 ; VA 0x00ae7e80 ; FUN_00ae7e80 */

undefined4 FUN_00ae7e80(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00587490(auStack_c);
  uVar2 = *puVar4;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return uVar2;
  }
  return uVar2;
}



/* FUNCTION 22624 ; VA 0x00ae7ed0 ; FUN_00ae7ed0 */

undefined4 * __thiscall FUN_00ae7ed0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  param_1[4] = 0;
  param_1[5] = 0;
  uVar1 = param_2[1];
  uVar2 = param_2[2];
  uVar3 = param_2[3];
  *param_1 = *param_2;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(param_2 + 4);
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  *(undefined *)(param_1 + 6) = *(undefined *)(param_2 + 6);
  param_1[7] = param_2[7];
  param_1[8] = param_2[8];
  param_1[9] = param_2[9];
  param_1[10] = param_2[10];
  param_1[0xb] = param_2[0xb];
  param_1[0xc] = param_2[0xc];
  return param_1;
}



/* FUNCTION 22625 ; VA 0x00ae7f40 ; FUN_00ae7f40 */

undefined4 * __thiscall
FUN_00ae7f40(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined8 param_12,
            undefined4 param_13)

{
  undefined4 uVar1;
  undefined auStack_608 [1512];
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017eb4e3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  uVar1 = FUN_00ae6b40();
  FUN_009cb970(uVar1,param_3,param_11,param_12,param_13);
  param_1[0xd] = param_2;
  iStack_8 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::Animator,void___cdecl(class_RBX::ContentId,bool,float,float,float,float,int),class_rbx::remote_signal<void___cdecl(class_RBX::ContentId,bool,float,float,float,float,int)>,class_rbx::remote_signal<void___cdecl(class_RBX::ContentId,bool,float,float,float,float,int)>_RBX::Animator::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088d190();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(param_5);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(param_6);
  FUN_0088c960();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  FUN_0086e3d0(param_7);
  FUN_0088c960();
  FUN_00888740();
  iStack_8._0_1_ = 4;
  FUN_0086e3d0(param_8);
  FUN_0088c960();
  FUN_00888740();
  iStack_8._0_1_ = 5;
  FUN_0086e3d0(param_9);
  FUN_0088c960();
  FUN_00888740();
  iStack_8._0_1_ = 6;
  FUN_0086e3d0(param_10);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 7;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_608,&puStack_20,param_11);
  iStack_8._0_1_ = 8;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = uStack_1c;
    param_1[0xb] = uStack_18;
    param_1[0xc] = uStack_14;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  iStack_8._0_1_ = 9;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_608,0xd8,7,FUN_00688b10);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22626 ; VA 0x00ae8140 ; FUN_00ae8140 */

int * __thiscall FUN_00ae8140(int *param_1,uint param_2)

{
  int iVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x7ffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar1 = FUN_00577f40(param_2);
    *param_1 = iVar1;
    param_1[1] = iVar1;
    param_1[2] = param_2 * 0x20 + *param_1;
    iVar1 = FUN_00ae8d90(*param_1,param_2);
    param_1[1] = iVar1;
  }
  return param_1;
}



/* FUNCTION 22627 ; VA 0x00ae81a0 ; FUN_00ae81a0 */

uint * __thiscall FUN_00ae81a0(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  uint uVar5;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x9249249 < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar5 = param_2 * 0x1c;
    if (uVar5 < 0x1000) {
      if (uVar5 == 0) {
        uVar1 = 0;
      }
      else {
        uVar1 = FUN_01674e20(uVar5);
      }
    }
    else {
      uVar1 = uVar5 + 0x23;
      if (uVar1 <= uVar5) {
        uVar1 = 0xffffffff;
      }
      iVar2 = FUN_01674e20(uVar1);
      if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar1 = iVar2 + 0x23U & 0xffffffe0;
      *(int *)(uVar1 - 4) = iVar2;
    }
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + uVar5;
    puVar4 = (undefined4 *)*param_1;
    if (param_2 != 0) {
      puVar3 = puVar4 + 5;
      do {
        *puVar4 = 0;
        puVar3[-4] = 0;
        puVar4 = puVar4 + 7;
        puVar3[-3] = 0;
        puVar3[-2] = 0;
        puVar3[-1] = 0;
        *puVar3 = 0;
        puVar3[1] = 0;
        param_2 = param_2 - 1;
        puVar3 = puVar3 + 7;
      } while (param_2 != 0);
    }
    param_1[1] = (uint)puVar4;
  }
  return param_1;
}



/* FUNCTION 22628 ; VA 0x00ae82a0 ; FUN_00ae82a0 */

undefined4 * __fastcall FUN_00ae82a0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  uint auStack_3c [2];
  code *pcStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  uint uStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eb600;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = param_1;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::Animator,class_RBX::Instance>::vftable;
  uVar3 = FUN_00ae6b40();
  param_1[3] = uVar3;
  param_1[0x15] = RBX::IStepped::vftable;
  param_1[0x16] = 2;
  param_1[0x17] = 0;
  *param_1 = RBX::Animator::vftable;
  param_1[0x15] = RBX::Animator::vftable;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  FUN_016830f0(param_1 + 0x1c);
  param_1[0x1e] = 0;
  param_1[0x1f] = 0x41200000;
  param_1[0x20] = 0x41300000;
  param_1[0x21] = 0x41200000;
  puVar6 = param_1 + 0x22;
  *puVar6 = 0;
  param_1[0x23] = 0;
  puStack_14 = puVar6;
  uVar3 = FUN_00575b10();
  *puVar6 = uVar3;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  *(undefined *)(param_1 + 0x38) = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  puVar6 = param_1 + 0x3b;
  uStack_8._0_1_ = 0xe;
  *puVar6 = 0;
  param_1[0x3c] = 0;
  puStack_14 = puVar6;
  uVar3 = FUN_005e9aa0(0,0);
  *puVar6 = uVar3;
  puStack_14 = param_1 + 0x3d;
  *puStack_14 = 0;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  uStack_8._0_1_ = 0x11;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  puStack_2c = (undefined4 *)0x0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  FUN_005542c0("Animator",8);
  uStack_8._0_1_ = 0x12;
  FUN_008a6520(auStack_3c);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
  if (0xf < uStack_28) {
    uVar5 = uStack_28 + 1;
    uVar4 = auStack_3c[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_3c[0] - 4);
      uVar5 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  if (DAT_01f754a1 != '\0') {
    FUN_016774b0(DAT_01f754a1,"Animator created - %p",param_1);
  }
  pcStack_34 = FUN_00aecb80;
  uStack_30 = 0;
  puStack_2c = param_1;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0x14;
  uStack_20 = uVar3;
  puStack_24 = (undefined4 *)FUN_01674e20(0x28);
  if (puStack_24 == (undefined4 *)0x0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    *puStack_24 = 0;
    puStack_24[1] = 1;
    puStack_24[2] = FUN_00aebad0;
    puStack_24[3] = _guard_check_icall;
    puStack_24[4] = 0;
    puStack_24[5] = puStack_14;
    puStack_24[6] = pcStack_34;
    puStack_24[7] = uStack_30;
    puStack_24[8] = puStack_2c;
    puStack_24[9] = uStack_28;
    puVar6 = puStack_24;
  }
  FUN_016797d0(puVar6);
  if (puVar6 != (undefined4 *)0x0) {
    LOCK();
    puVar6[1] = puVar6[1] + 1;
    UNLOCK();
  }
  uStack_18 = 2;
  uStack_8 = 0x15;
  puStack_24 = puVar6;
  FUN_01675290(uVar3);
  if (puVar6 != (undefined4 *)0x0) {
    piVar1 = puVar6 + 1;
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(puVar6);
    }
  }
  ExceptionList = pvStack_10;
  return puStack_1c;
}



/* FUNCTION 22629 ; VA 0x00ae8620 ; FUN_00ae8620 */

void __fastcall FUN_00ae8620(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Animator>::vftable;
  uVar1 = FUN_00ae6b40(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22630 ; VA 0x00ae8660 ; FUN_00ae8660 */

void __fastcall FUN_00ae8660(int *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  piVar3 = (int *)*param_1;
  piVar4 = (int *)*piVar3;
  *piVar3 = (int)piVar3;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar3 = (int *)*param_1;
  if (piVar4 != piVar3) {
    do {
      piVar3 = (int *)piVar4[3];
      piVar1 = (int *)*piVar4;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar2 = piVar3[2] + -1;
          piVar3[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      FUN_01674ea0(piVar4,0x10);
      piVar3 = (int *)*param_1;
      piVar4 = piVar1;
    } while (piVar1 != piVar3);
  }
  FUN_01674ea0(piVar3,0x10);
  return;
}



/* FUNCTION 22631 ; VA 0x00ae86e0 ; FUN_00ae86e0 */

void __fastcall FUN_00ae86e0(int *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  iVar4 = *param_1;
  if (iVar4 != 0) {
    iVar5 = param_1[1];
    if (iVar4 != iVar5) {
      do {
        piVar1 = *(int **)(iVar4 + 4);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        iVar4 = iVar4 + 0x10;
      } while (iVar4 != iVar5);
      iVar4 = *param_1;
    }
    uVar3 = param_1[2] - iVar4 & 0xfffffff0;
    iVar5 = iVar4;
    if (0xfff < uVar3) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 22632 ; VA 0x00ae8760 ; thunk_FUN_0072a1c0 */

void __fastcall thunk_FUN_0072a1c0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x1c) * 0x1c;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 22633 ; VA 0x00ae8770 ; FUN_00ae8770 */

void __fastcall FUN_00ae8770(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a950;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Animator::vftable;
  param_1[0x15] = RBX::Animator::vftable;
  if (DAT_01f754a1 != '\0') {
    FUN_016774b0(DAT_01f754a1,"Animator destroyed - %p",param_1);
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_00ae8660();
  uStack_8 = 0;
  FUN_01679490();
  iVar2 = param_1[0x3a];
  if (iVar2 != 0) {
    piVar1 = (int *)(iVar2 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar2);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar2 = param_1[0x39];
  if (iVar2 != 0) {
    piVar1 = (int *)(iVar2 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar2);
    }
  }
  iVar2 = param_1[0x35];
  uStack_8 = 0xffffffff;
  if (iVar2 != 0) {
    uVar4 = param_1[0x37] - iVar2 & 0xffffffe0;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00ae8a61;
    }
    FUN_01674ea0(iVar3,uVar4);
    param_1[0x35] = 0;
    param_1[0x36] = 0;
    param_1[0x37] = 0;
  }
  iVar2 = param_1[0x32];
  if (iVar2 != 0) {
    uVar4 = param_1[0x34] - iVar2 & 0xffffffe0;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00ae8a61;
    }
    FUN_01674ea0(iVar3,uVar4);
    param_1[0x32] = 0;
    param_1[0x33] = 0;
    param_1[0x34] = 0;
  }
  FUN_0072e310();
  FUN_0072e310();
  FUN_00a1ff00();
  FUN_00ae86e0();
  piVar1 = (int *)param_1[0x25];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  iVar2 = param_1[0x22];
  piVar1 = param_1 + 0x22;
  uStack_8 = 2;
  FUN_005f6240(*(undefined4 *)(iVar2 + 4));
  *(int *)(*piVar1 + 4) = iVar2;
  *(int *)*piVar1 = iVar2;
  *(int *)(*piVar1 + 8) = iVar2;
  param_1[0x23] = 0;
  FUN_01674ea0(*piVar1,0x30);
  uStack_8 = 3;
  FUN_01679490();
  iVar2 = param_1[0x1b];
  if (iVar2 != 0) {
    piVar1 = (int *)(iVar2 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar2);
    }
  }
  iVar2 = param_1[0x18];
  uStack_8 = 0xffffffff;
  if (iVar2 != 0) {
    uVar4 = (param_1[0x1a] - iVar2 >> 2) * 4;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00ae8a61:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
    param_1[0x18] = 0;
    param_1[0x19] = 0;
    param_1[0x1a] = 0;
  }
  param_1[0x15] = RBX::IStepped::vftable;
  uStack_8 = 4;
  FUN_01679490();
  iVar2 = param_1[0x17];
  if (iVar2 != 0) {
    piVar1 = (int *)(iVar2 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar2);
    }
  }
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22634 ; VA 0x00ae8a70 ; FUN_00ae8a70 */

void FUN_00ae8a70(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  
  if (param_2 != 0) {
    puVar1 = param_1 + 6;
    do {
      *param_1 = 0;
      puVar1[-5] = 0;
      param_1 = param_1 + 0xb;
      puVar1[-4] = 0;
      puVar1[-3] = 0;
      puVar1[-2] = 0;
      puVar1[-1] = 0;
      *puVar1 = 0;
      puVar1[1] = 0;
      puVar1[2] = 0;
      puVar1[3] = 0x3f800000;
      *(undefined *)(puVar1 + 4) = 0;
      param_2 = param_2 + -1;
      puVar1 = puVar1 + 0xb;
    } while (param_2 != 0);
  }
  return;
}



/* FUNCTION 22635 ; VA 0x00ae8ae0 ; FUN_00ae8ae0 */

/* WARNING: Removing unreachable block (ram,0x00ae8b7e) */
/* WARNING: Removing unreachable block (ram,0x00ae8b8e) */
/* WARNING: Removing unreachable block (ram,0x00ae8b94) */

void __thiscall FUN_00ae8ae0(int *param_1,int param_2)

{
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eb628;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_01675290();
    uStack_8._0_1_ = 3;
    FUN_005e6300();
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_01675290();
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  if (0xf < in_stack_00000018) {
    if ((0xfff < in_stack_00000018 + 1) && (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U)) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22636 ; VA 0x00ae8c16 ; Catch@00ae8c16 */

undefined * Catch_00ae8c16(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00ae8c27;
}



/* FUNCTION 22637 ; VA 0x00ae8c3f ; FUN_00ae8c3f */

void FUN_00ae8c3f(void)

{
  FUN_00ae8c80();
  return;
}



/* FUNCTION 22638 ; VA 0x00ae8c50 ; FUN_00ae8c50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00ae8c50(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::KeyframeSequence::Priority>::vftable;
  _DAT_01f14a50 = _DAT_01f14a50 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 22639 ; VA 0x00ae8c80 ; FUN_00ae8c80 */

undefined4 __thiscall FUN_00ae8c80(undefined4 param_1,byte param_2)

{
  FUN_00ae8770();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x108);
  }
  return param_1;
}



/* FUNCTION 22640 ; VA 0x00ae8cb0 ; FUN_00ae8cb0 */

void __thiscall FUN_00ae8cb0(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_00a1ba80(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0xc) * 0xc;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 0xc;
  param_1[2] = param_2 + param_4 * 0xc;
  return;
}



/* FUNCTION 22641 ; VA 0x00ae8d40 ; FUN_00ae8d40 */

void __thiscall FUN_00ae8d40(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar1 = param_1[1];
  iVar2 = *param_1;
  uVar3 = FUN_00618050(param_2);
  FUN_00ae8df0(*param_1,param_1[1],uVar3);
  FUN_00ae8cb0(uVar3,(iVar1 - iVar2) / 0xc,param_2);
  return;
}



/* FUNCTION 22642 ; VA 0x00ae8d90 ; FUN_00ae8d90 */

void FUN_00ae8d90(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  
  if (param_2 != 0) {
    puVar1 = param_1 + 5;
    do {
      *param_1 = 0;
      puVar1[-4] = 0;
      param_1 = param_1 + 8;
      puVar1[-3] = 0;
      puVar1[-2] = 0;
      puVar1[-1] = 0;
      *puVar1 = 0;
      puVar1[1] = 0;
      *(undefined2 *)(puVar1 + 2) = 0;
      param_2 = param_2 + -1;
      puVar1 = puVar1 + 8;
    } while (param_2 != 0);
  }
  return;
}



/* FUNCTION 22643 ; VA 0x00ae8df0 ; FUN_00ae8df0 */

void __thiscall
FUN_00ae8df0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar4 = param_4;
  if (param_2 != param_3) {
    puVar3 = param_2 + 2;
    do {
      *puVar4 = 0;
      puVar1 = puVar3 + 3;
      puVar4[1] = 0;
      *(undefined4 *)((int)param_4 + (-0xc - (int)param_2) + (int)puVar1) = 0;
      *puVar4 = puVar3[-2];
      puVar4[1] = puVar3[-1];
      puVar4 = puVar4 + 3;
      *(undefined4 *)((int)param_4 + (-0xc - (int)param_2) + (int)puVar1) = *puVar3;
      puVar2 = puVar3 + 1;
      puVar3[-2] = 0;
      puVar3[-1] = 0;
      *puVar3 = 0;
      puVar3 = puVar1;
    } while (puVar2 != param_3);
  }
  FUN_00a1ba80(puVar4,puVar4,param_1);
  return;
}



/* FUNCTION 22644 ; VA 0x00ae8e70 ; FUN_00ae8e70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00ae8e70(int param_1,int param_2)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  uint uVar8;
  char cVar9;
  int iVar10;
  int iVar11;
  float fVar12;
  undefined4 *puVar13;
  float *pfVar14;
  int *piVar15;
  undefined4 *puVar16;
  uint uVar17;
  int *piVar18;
  undefined4 *puVar19;
  float *pfVar20;
  int iVar21;
  float10 fVar22;
  double dVar23;
  double dVar24;
  float fVar25;
  float fVar26;
  float fVar27;
  float fVar28;
  undefined8 uVar29;
  undefined4 uVar30;
  float *pfVar31;
  float *pfVar32;
  undefined4 uVar33;
  float *pfVar34;
  undefined auStack_108 [8];
  uint uStack_100;
  undefined4 uStack_fc;
  float fStack_f8;
  float fStack_f4;
  float fStack_f0;
  float fStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined8 uStack_e0;
  undefined4 *puStack_d8;
  float fStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  float fStack_c0;
  float fStack_bc;
  ulonglong uStack_b8;
  undefined4 uStack_b0;
  float *pfStack_ac;
  int *piStack_a8;
  undefined8 uStack_98;
  undefined4 uStack_90;
  float fStack_8c;
  float fStack_88;
  float fStack_84;
  float *pfStack_80;
  uint uStack_7c;
  undefined8 uStack_78;
  int *piStack_70;
  int *piStack_64;
  float *pfStack_60;
  float fStack_5c;
  float fStack_58;
  float *pfStack_54;
  float *pfStack_50;
  undefined4 uStack_4c;
  float *pfStack_48;
  float *pfStack_44;
  int *piStack_40;
  float *pfStack_3c;
  int iStack_38;
  float *pfStack_34;
  uint uStack_30;
  float *pfStack_2c;
  float *pfStack_28;
  char cStack_21;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017eb819;
  pvStack_1c = ExceptionList;
  uStack_30 = 0;
  ExceptionList = &pvStack_1c;
  iStack_38 = param_1;
  uStack_cc = FUN_01675290(DAT_01f127c8);
  iStack_14 = 0;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eec2a8) &&
     (FUN_016f3809(&DAT_01eec2a8), DAT_01eec2a8 == -1)) {
    iStack_14._0_1_ = 1;
    uVar29 = FUN_0152dab0(&DAT_018cb3fc,"Animator::animatorOnStepped",0xffffffff);
    DAT_01eec2a4 = (undefined4)((ulonglong)uVar29 >> 0x20);
    DAT_01eec2a0 = (undefined4)uVar29;
    iStack_14 = (uint)iStack_14._1_3_ << 8;
    FUN_016f37bf(&DAT_01eec2a8);
  }
  uStack_c8 = DAT_01eec2a0;
  uStack_e8 = DAT_01eec2a0;
  uStack_c4 = DAT_01eec2a4;
  uStack_e4 = DAT_01eec2a4;
  uStack_e0 = FUN_0152d930(DAT_01eec2a0,DAT_01eec2a4);
  iStack_14._0_1_ = 2;
  iVar10 = FUN_00a9d0e0(param_1);
  if (iVar10 == 0) goto LAB_00aea65e;
  pfStack_28 = *(float **)(param_1 + 0x60);
  pfVar14 = *(float **)(param_1 + 100);
  pfStack_2c = pfVar14;
  if (pfStack_28 != pfVar14) {
    do {
      puVar16 = *(undefined4 **)(param_1 + 0xec);
      puVar13 = (undefined4 *)*puVar16;
      param_1 = iStack_38;
      while (iStack_38 = param_1, puVar13 != puVar16) {
        fVar22 = (float10)FUN_00832140();
        pfStack_48 = (float *)(float)fVar22;
        fVar22 = (float10)FUN_00764670();
        pfStack_3c = (float *)(float)fVar22;
        pfStack_60 = *(float **)(puVar13[2] + 0x9c);
        pfStack_34 = *(float **)(puVar13[2] + 0xa0);
        iVar10 = FUN_00e66450();
        uVar33 = 9;
        uVar30 = 1;
        pfVar14 = pfStack_34;
        pfVar20 = pfStack_60;
        pfVar31 = pfStack_3c;
        pfVar32 = pfStack_48;
        pfVar34 = pfStack_28;
        FUN_0054ef60(iVar10 + 0x54);
        fVar26 = fStack_ec;
        fVar12 = fStack_f0;
        uVar17 = uStack_100;
        uStack_30 = uStack_30 | 0x40;
        iStack_14._0_1_ = 5;
        uStack_100 = uStack_100 & 0xffffff00;
        fStack_f0 = 0.0;
        fStack_ec = 2.10195e-44;
        FUN_00aee640(uVar17,uStack_fc,fStack_f8,fStack_f4,fVar12,fVar26,uVar30,pfVar14,pfVar20,
                     pfVar31,pfVar32,uVar33,pfVar34);
        puVar13 = (undefined4 *)*puVar13;
        iStack_14._0_1_ = 2;
        pfVar14 = pfStack_2c;
        param_1 = iStack_38;
      }
      pfStack_28 = pfStack_28 + 1;
    } while (pfStack_28 != pfVar14);
  }
  *(undefined4 *)(param_1 + 100) = *(undefined4 *)(param_1 + 0x60);
  if (*(char *)(param_1 + 0xe0) != '\0') {
    *(undefined4 *)(param_1 + 0x90) = 0;
    piVar15 = *(int **)(param_1 + 0x94);
    *(undefined4 *)(param_1 + 0x94) = 0;
    if (piVar15 != (int *)0x0) {
      LOCK();
      iVar10 = piVar15[2] + -1;
      piVar15[2] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)(*piVar15 + 4))();
      }
    }
    pfVar14 = *(float **)(param_1 + 0x9c);
    pfVar20 = *(float **)(param_1 + 0x98);
    pfStack_28 = pfVar14;
    if (pfVar20 != pfVar14) {
      do {
        piVar15 = (int *)pfVar20[1];
        if (piVar15 != (int *)0x0) {
          LOCK();
          iVar10 = piVar15[2] + -1;
          piVar15[2] = iVar10;
          UNLOCK();
          pfVar14 = pfStack_28;
          if (iVar10 == 0) {
            (**(code **)(*piVar15 + 4))();
            pfVar14 = pfStack_28;
          }
        }
        pfVar20 = pfVar20 + 4;
      } while (pfVar20 != pfVar14);
      pfVar20 = *(float **)(iStack_38 + 0x98);
      param_1 = iStack_38;
    }
    *(float **)(param_1 + 0x9c) = pfVar20;
    if (DAT_01d6699c == '\0') {
      if (*(int *)(param_1 + 0x34) == 0) {
        uVar30 = 0;
      }
      else {
        uVar30 = *(undefined4 *)(*(int *)(param_1 + 0x34) + 0x34);
      }
      FUN_00aeb300(uVar30);
      if ((DAT_01d669ac != '\0') && (DAT_01eec29c == '\0')) {
        iVar10 = FUN_00aec0c0(param_1);
        if (iVar10 != 0) {
          uStack_4c = 0;
          pfStack_48 = (float *)0x0;
          uStack_78 = 0.0;
          piStack_70 = (int *)0x0;
          iStack_14 = CONCAT31(iStack_14._1_3_,7);
          FUN_00aec7c0(iVar10,&uStack_4c,&uStack_78);
          iVar10 = FUN_00ae7e80(param_1 + 0x90);
          iVar11 = FUN_00ae7e80(&uStack_4c);
          if (iVar11 == iVar10) {
            pfStack_2c = *(float **)(param_1 + 0x98);
            if (uStack_78._4_4_ - (int)uStack_78 >> 4 !=
                *(int *)(param_1 + 0x9c) - (int)pfStack_2c >> 4) goto LAB_00ae91e4;
            if ((int)uStack_78 != uStack_78._4_4_) {
              pfVar14 = pfStack_2c + 2;
              iVar10 = (int)uStack_78;
              do {
                if (*(float *)(iVar10 + 8) != *pfVar14) goto LAB_00ae91e4;
                iVar10 = iVar10 + 0x10;
                pfVar14 = pfVar14 + 4;
              } while (iVar10 != uStack_78._4_4_);
            }
          }
          else {
LAB_00ae91e4:
            if (DAT_01d669b4 == '\0') {
              puVar16 = &DAT_01d7a8e8;
              if (0xf < DAT_01d7a8fc) {
                puVar16 = DAT_01d7a8e8;
              }
              FUN_0087c450(&DAT_018c5f98,"AnimatorModelSearchChange",puVar16,0,0,0);
            }
            else {
              puVar16 = &DAT_01d7a8e8;
              if (0xf < DAT_01d7a8fc) {
                puVar16 = DAT_01d7a8e8;
              }
              FUN_0087c6f0(&DAT_018c5f98,"AnimatorModelSearchChange",puVar16,0,0,0,3);
            }
            DAT_01eec29c = '\x01';
          }
          FUN_00ae86e0();
          iStack_14._0_1_ = 2;
          if (pfStack_48 != (float *)0x0) {
            LOCK();
            fVar12 = (float)((int)pfStack_48[2] + -1);
            pfStack_48[2] = fVar12;
            UNLOCK();
            if (fVar12 == 0.0) {
              (**(code **)((int)*pfStack_48 + 4))();
            }
          }
        }
      }
    }
    else {
      iVar10 = FUN_00aec0c0(param_1);
      if (iVar10 != 0) {
        FUN_00aec7c0(iVar10,param_1 + 0x90,param_1 + 0x98);
      }
    }
    piVar15 = (int *)(param_1 + 0x98);
    if (DAT_01d6698c != '\0') {
      FUN_00ae7280(*(int *)(param_1 + 0x9c) - *piVar15 >> 4,param_1 + 0xb0);
      FUN_00ae7280(*(int *)(param_1 + 0x9c) - *piVar15 >> 4,param_1 + 0xbc);
      FUN_00ae7150(*(int *)(param_1 + 0x9c) - *piVar15 >> 4,param_1 + 200);
      FUN_00ae7150(*(int *)(param_1 + 0x9c) - *piVar15 >> 4,param_1 + 0xd4);
      FUN_00aedda0();
    }
    *(undefined *)(param_1 + 0xe0) = 0;
  }
  piVar15 = (int *)(param_1 + 0x98);
  piStack_40 = piVar15;
  if ((0xf < (uint)(*(int *)(param_1 + 0x9c) - *piVar15)) && (*(int *)(param_1 + 0xf0) != 0)) {
    pfStack_50 = (float *)0x0;
    piVar18 = (int *)**(int **)(param_1 + 0xec);
    if (piVar18 != *(int **)(param_1 + 0xec)) {
      fStack_5c = 0.0;
      do {
        cVar9 = FUN_00e66bd0();
        if (cVar9 == '\0') {
          piVar15 = (int *)*piVar18;
          fStack_5c = (float)((int)fStack_5c + 0xc);
        }
        else {
          if (DAT_01d6697c != '\0') {
            cVar9 = FUN_00926d60();
            if (cVar9 != '\0') {
              FUN_00e67c00(0);
            }
          }
          piVar15 = (int *)*piVar18;
          *(int **)piVar18[1] = piVar15;
          *(int *)(*piVar18 + 4) = piVar18[1];
          *(int *)(iStack_38 + 0xf0) = *(int *)(iStack_38 + 0xf0) + -1;
          pfStack_48 = (float *)piVar18[3];
          if (pfStack_48 != (float *)0x0) {
            LOCK();
            fVar12 = (float)((int)pfStack_48[1] + -1);
            pfStack_48[1] = fVar12;
            UNLOCK();
            if (fVar12 == 0.0) {
              (**(code **)*pfStack_48)();
              LOCK();
              fVar12 = (float)((int)pfStack_48[2] + -1);
              pfStack_48[2] = fVar12;
              UNLOCK();
              if (fVar12 == 0.0) {
                (**(code **)((int)*pfStack_48 + 4))();
              }
            }
          }
          FUN_01674ea0(piVar18,0x10);
          param_1 = iStack_38;
          if (DAT_01d6698c != '\0') {
            pfStack_2c = (float *)(*(int *)(iStack_38 + 0xa4) + (int)fStack_5c);
            pfStack_3c = *(float **)(iStack_38 + 0xa8);
            pfStack_48 = pfStack_2c + 3;
            if (pfStack_48 != pfStack_3c) {
              pfStack_28 = (float *)((int)pfStack_2c - (int)pfStack_48);
              pfStack_54 = pfStack_2c + 5;
              do {
                if (pfStack_2c != pfStack_54 + -2) {
                  pfStack_48 = (float *)*pfStack_2c;
                  if (pfStack_48 != (float *)0x0) {
                    uVar17 = (*(int *)((int)pfStack_28 + (int)pfStack_54) - (int)pfStack_48 >> 2) *
                             4;
                    if (0xfff < uVar17) {
                      pfVar14 = (float *)pfStack_48[-1];
                      uVar17 = uVar17 + 0x23;
                      uVar1 = (int)pfStack_48 + (-4 - (int)pfVar14);
                      pfStack_48 = pfVar14;
                      if (0x1f < uVar1) goto LAB_00aea6f9;
                    }
                    FUN_01674ea0(pfStack_48,uVar17);
                    *pfStack_2c = 0.0;
                    pfStack_2c[1] = 0.0;
                    *(undefined4 *)((int)pfStack_28 + (int)pfStack_54) = 0;
                  }
                  *pfStack_2c = pfStack_54[-2];
                  pfStack_2c[1] = pfStack_54[-1];
                  *(float *)((int)pfStack_28 + (int)pfStack_54) = *pfStack_54;
                  pfStack_54[-2] = 0.0;
                  pfStack_54[-1] = 0.0;
                  *pfStack_54 = 0.0;
                  param_1 = iStack_38;
                }
                pfVar20 = pfStack_54 + 3;
                pfStack_2c = pfStack_2c + 3;
                pfVar14 = pfStack_54 + 1;
                pfStack_54 = pfVar20;
              } while (pfVar14 != pfStack_3c);
            }
            pfVar14 = *(float **)(param_1 + 0xa8);
            pfVar20 = (float *)pfVar14[-3];
            pfStack_3c = pfVar14;
            if (pfVar20 != (float *)0x0) {
              uVar17 = ((int)pfVar14[-1] - (int)pfVar20 >> 2) * 4;
              pfVar14 = pfVar20;
              if (0xfff < uVar17) {
                pfVar14 = (float *)pfVar20[-1];
                uVar17 = uVar17 + 0x23;
                pfStack_48 = pfVar14;
                if (0x1f < (uint)((int)pfVar20 + (-4 - (int)pfVar14))) {
LAB_00aea6f9:
                    /* WARNING: Subroutine does not return */
                  FUN_017167a3();
                }
              }
              FUN_01674ea0(pfVar14,uVar17);
              pfStack_3c[-3] = 0.0;
              pfStack_3c[-2] = 0.0;
              pfStack_3c[-1] = 0.0;
              pfVar14 = *(float **)(param_1 + 0xa8);
            }
            *(float **)(param_1 + 0xa8) = pfVar14 + -3;
          }
        }
        piVar18 = piVar15;
      } while (piVar15 != *(int **)(param_1 + 0xec));
      piVar15 = (int *)(param_1 + 0x98);
    }
    if (DAT_01d6698c != '\0') {
      uVar17 = 0;
      if (*(int *)(param_1 + 0xf0) != 0) {
        pfStack_2c = (float *)0x0;
        do {
          piVar15 = (int *)(*(int *)(param_1 + 0xa4) + (int)pfStack_2c);
          if ((uint)(piVar15[1] - *piVar15) < 4) {
            FUN_00aeda10(uVar17);
          }
          uVar17 = uVar17 + 1;
          pfStack_2c = pfStack_2c + 3;
        } while (uVar17 < *(uint *)(param_1 + 0xf0));
      }
      pfStack_48 = *(float **)(param_1 + 0x34);
      pfStack_44 = DAT_018ce2f8;
      pfStack_60 = DAT_018ce2f8;
      if (pfStack_48 != (float *)0x0) {
        iVar10 = *(int *)((int)pfStack_48 + 0xc);
        iVar11 = FUN_0099be20();
        if (((uint)*(ushort *)(iVar10 + 0x1d8) - (uint)*(ushort *)(iVar11 + 0x1d8) <=
             (uint)*(ushort *)(iVar11 + 0x1da)) &&
           (**(char **)((int)pfStack_48 + 0x230) != (char)*(char **)((int)pfStack_48 + 0x230))) {
          pfStack_60 = (float *)((float)(**(uint **)((int)pfStack_48 + 0x218) ^
                                        (uint)*(uint **)((int)pfStack_48 + 0x218)) * DAT_018ce2f4);
        }
      }
      pfStack_2c = (float *)0x0;
      if (*(int *)(param_1 + 0x9c) - *(int *)(param_1 + 0x98) >> 4 != 0) {
        iVar10 = 0;
        pfStack_28 = (float *)0x0;
        do {
          uVar1 = uStack_7c;
          iVar10 = iVar10 + 0x20;
          puVar16 = (undefined4 *)(*(int *)(param_1 + 0xb0) + (int)pfStack_28);
          uVar17 = uStack_7c >> 8;
          uStack_7c = uVar17 << 8;
          uVar8 = uStack_7c;
          uStack_7c = uVar17 << 8;
          uVar17 = uStack_7c;
          *puVar16 = 0;
          puVar16[1] = 0;
          puVar16[2] = 0;
          puVar16[3] = 0;
          puVar16[4] = 0;
          puVar16[5] = 0;
          puVar16[6] = 0;
          puVar16[7] = 0;
          *(ulonglong *)(puVar16 + 8) = CONCAT44(pfStack_44,pfStack_50);
          puVar16[10] = uVar8;
          puVar16 = (undefined4 *)(*(int *)(param_1 + 0xbc) + (int)pfStack_28);
          pfStack_28 = pfStack_28 + 0xb;
          uStack_7c = (uVar1 >> 0x10) << 0x10;
          *puVar16 = 0;
          puVar16[1] = 0;
          puVar16[2] = 0;
          puVar16[3] = 0;
          puVar16[4] = 0;
          puVar16[5] = 0;
          puVar16[6] = 0;
          puVar16[7] = 0;
          *(ulonglong *)(puVar16 + 8) = CONCAT44(pfStack_44,pfStack_50);
          puVar16[10] = uVar17;
          iVar11 = *(int *)(param_1 + 200);
          pfStack_2c = (float *)((int)pfStack_2c + 1);
          puVar16 = (undefined4 *)(iVar11 + -0x20 + iVar10);
          *puVar16 = 0;
          puVar16[1] = 0;
          puVar16[2] = 0;
          puVar16[3] = 0;
          fStack_88 = 0.0;
          fStack_84 = 0.0;
          puVar16 = (undefined4 *)(iVar11 + -0x10 + iVar10);
          *puVar16 = 0;
          puVar16[1] = 0;
          puVar16[2] = 0;
          puVar16[3] = uStack_7c;
          iVar11 = *(int *)(param_1 + 0xd4);
          pfStack_80 = (float *)0x0;
          uStack_7c = (uVar1 >> 0x10) << 0x10;
          puVar16 = (undefined4 *)(iVar11 + -0x20 + iVar10);
          *puVar16 = 0;
          puVar16[1] = 0;
          puVar16[2] = 0;
          puVar16[3] = 0;
          puVar16 = (undefined4 *)(iVar11 + -0x10 + iVar10);
          *puVar16 = 0;
          puVar16[1] = 0;
          puVar16[2] = 0;
          puVar16[3] = uStack_7c;
        } while (pfStack_2c < (uint)(*(int *)(param_1 + 0x9c) - *(int *)(param_1 + 0x98) >> 4));
      }
      uStack_b0 = 0;
      pfStack_48 = (float *)0x0;
      pfStack_ac = (float *)0x0;
      iStack_14._0_1_ = 10;
      if (DAT_01d66994 != '\0') {
        puVar16 = (undefined4 *)FUN_0060dcd0((int)&uStack_78 + 4,param_1);
        uStack_b0 = *puVar16;
        pfStack_ac = (float *)puVar16[1];
        *puVar16 = 0;
        puVar16[1] = 0;
        pfStack_3c = (float *)piStack_70;
        pfStack_48 = pfStack_ac;
        if (piStack_70 != (int *)0x0) {
          LOCK();
          iVar10 = piStack_70[1] + -1;
          piStack_70[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piStack_70)();
            LOCK();
            iVar10 = (int)pfStack_3c[2] + -1;
            pfStack_3c[2] = (float)iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)((int)*pfStack_3c + 4))();
            }
          }
        }
      }
      piVar15 = (int *)(param_1 + 0x98);
      pfStack_3c = *(float **)(param_1 + 0xf0);
      pfStack_54 = (float *)&DAT_0194c510;
LAB_00ae9790:
      puVar16 = *(undefined4 **)(param_1 + 0xec);
      pfStack_2c = (float *)*pfStack_54;
      for (puVar13 = (undefined4 *)*puVar16; puVar13 != puVar16; puVar13 = (undefined4 *)*puVar13) {
        fVar12 = (float)FUN_00e668b0();
        if ((float *)fVar12 == pfStack_2c) {
          piVar15 = *(int **)(iStack_38 + 0xec);
          piVar18 = (int *)*piVar15;
          if (piVar18 == piVar15) goto LAB_00ae9880;
          pfStack_28 = (float *)0x0;
          pfVar14 = (float *)0x0;
          goto LAB_00ae97e0;
        }
        piVar15 = piStack_40;
      }
      goto LAB_00ae9bda;
    }
    FUN_00ae8140(piVar15[1] - *piVar15 >> 4,&cStack_21);
    iStack_14._0_1_ = 0xb;
    FUN_00ae8140(*(int *)(param_1 + 0x9c) - *(int *)(param_1 + 0x98) >> 4,&cStack_21);
    uStack_b0 = 0;
    pfStack_ac = (float *)0x0;
    iStack_14._0_1_ = 0xd;
    if (DAT_01d66994 != '\0') {
      uVar30 = FUN_0060dcd0((int)&uStack_78 + 4,param_1);
      FUN_005587e0(uVar30);
      piVar15 = piStack_70;
      if (piStack_70 != (int *)0x0) {
        LOCK();
        iVar10 = piStack_70[1] + -1;
        piStack_70[1] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)*piStack_70)();
          LOCK();
          piVar18 = piVar15 + 2;
          iVar10 = *piVar18 + -1;
          *piVar18 = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)(*piVar15 + 4))();
          }
        }
      }
    }
    pfStack_60 = (float *)0x0;
    pfStack_3c = (float *)&DAT_0194c500;
    pfVar14 = (float *)&DAT_00000004;
    pfStack_28 = (float *)&DAT_00000004;
    do {
      piVar15 = *(int **)(param_1 + 0xec);
      pfStack_48 = (float *)*pfStack_3c;
      piVar18 = (int *)*piVar15;
      if (piVar18 != piVar15) {
LAB_00aea228:
        pfVar14 = (float *)FUN_00e668b0();
        if (pfVar14 != pfStack_48) goto code_r0x00aea239;
        uVar17 = 0;
        if (piStack_40[1] - *piStack_40 >> 4 != 0) {
          iVar10 = 0;
          do {
            fStack_88 = 0.0;
            fStack_84 = 0.0;
            uVar17 = uVar17 + 1;
            pfStack_80 = (float *)0x0;
            puVar16 = (undefined4 *)(iVar10 + (int)fStack_bc);
            *puVar16 = 0;
            puVar16[1] = 0;
            puVar16[2] = 0;
            puVar16[3] = 0;
            uStack_7c = uStack_7c & 0xffff0000;
            puVar16 = (undefined4 *)(iVar10 + 0x10 + (int)fStack_bc);
            *puVar16 = 0;
            puVar16[1] = 0;
            puVar16[2] = 0;
            puVar16[3] = uStack_7c;
            iVar10 = iVar10 + 0x20;
          } while (uVar17 < (uint)(piStack_40[1] - *piStack_40 >> 4));
        }
        puVar16 = *(undefined4 **)(iStack_38 + 0xec);
        pfStack_34 = *(float **)(iStack_38 + 0xf0);
        puVar13 = (undefined4 *)*puVar16;
        pfVar14 = (float *)0x0;
        puVar19 = puStack_d8;
        while ((puStack_d8 = puVar19, puVar13 != puVar16 && (pfVar14 < pfStack_34))) {
          pfStack_2c = (float *)((int)pfVar14 + 1);
          pfVar14 = (float *)FUN_00e668b0();
          if (pfVar14 == pfStack_48) {
            FUN_00e679b0(piStack_40,&fStack_bc,(float)*(double *)(param_2 + 8),0x3f800000);
          }
          puVar13 = (undefined4 *)*puVar13;
          pfVar14 = pfStack_2c;
          puVar19 = puStack_d8;
        }
        pfStack_48 = (float *)0x0;
        pfVar14 = pfStack_28;
        if (piStack_40[1] - *piStack_40 >> 4 != 0) {
          iVar10 = 0;
          do {
            puVar16 = (undefined4 *)FUN_00dcaa10(&uStack_98,puVar19,(int)fStack_bc + iVar10);
            iVar10 = iVar10 + 0x20;
            pfStack_48 = (float *)((int)pfStack_48 + 1);
            uVar30 = puVar16[1];
            uVar33 = puVar16[2];
            uVar3 = puVar16[3];
            uVar4 = puVar16[4];
            uVar5 = puVar16[5];
            uVar6 = puVar16[6];
            uVar7 = puVar16[7];
            *puVar19 = *puVar16;
            puVar19[1] = uVar30;
            puVar19[2] = uVar33;
            puVar19[3] = uVar3;
            puVar19[4] = uVar4;
            puVar19[5] = uVar5;
            puVar19[6] = uVar6;
            puVar19[7] = uVar7;
            puVar19 = puVar19 + 8;
            pfVar14 = pfStack_28;
          } while (pfStack_48 < (float *)(piStack_40[1] - *piStack_40 >> 4));
        }
      }
LAB_00aea245:
      pfStack_60 = (float *)((int)pfStack_60 + 1);
      pfStack_3c = pfStack_3c + 1;
      param_1 = iStack_38;
    } while (pfStack_60 != pfVar14);
    iVar10 = *piStack_40;
    pfStack_50 = (float *)0x0;
    if (piStack_40[1] - iVar10 >> 4 != 0) {
      pfStack_28 = (float *)(puStack_d8 + 2);
      pfStack_44 = (float *)0x0;
      piVar15 = piStack_40;
      do {
        iVar11 = iStack_38;
        iVar10 = *(int *)((int)pfStack_44 + iVar10 + 4);
        pfVar20 = pfStack_44;
        pfVar14 = pfStack_50;
        if ((iVar10 != 0) && (*(int *)(iVar10 + 4) != 0)) {
          if ((DAT_01d669c4 != '\0') &&
             (pfStack_60 = *(float **)(iStack_38 + 0x34), pfStack_60 != (float *)0x0)) {
            fVar12 = pfStack_60[3];
            iVar10 = FUN_0099be20();
            piVar15 = piStack_40;
            if (((uint)*(ushort *)((int)fVar12 + 0x1d8) - (uint)*(ushort *)(iVar10 + 0x1d8) <=
                 (uint)*(ushort *)(iVar10 + 0x1da)) &&
               (*(char *)pfStack_60[0x8c] != (char)(char *)pfStack_60[0x8c])) {
              piVar15 = (int *)0x0;
              iVar10 = 0;
              if (*(int *)(iVar11 + 0x94) != 0) {
                cVar9 = FUN_00576f40();
                if (cVar9 == '\0') {
                  iVar10 = 0;
                }
                else {
                  piVar15 = *(int **)(iVar11 + 0x94);
                  iVar10 = *(int *)(iVar11 + 0x90);
                }
              }
              uStack_30 = uStack_30 | 8;
              if (iVar10 == 0) {
LAB_00aea4d7:
                cStack_21 = '\0';
              }
              else {
                pfStack_2c = (float *)0x0;
                pfStack_3c = (float *)0x0;
                if (*(int *)(iVar11 + 0x94) != 0) {
                  pfStack_2c = (float *)0x0;
                  cVar9 = FUN_00576f40();
                  if (cVar9 != '\0') {
                    pfStack_3c = *(float **)(iVar11 + 0x94);
                    pfStack_2c = *(float **)(iVar11 + 0x90);
                  }
                }
                pfVar14 = (float *)0x0;
                puVar16 = (undefined4 *)(*(int *)(iVar11 + 0x98) + (int)pfStack_44);
                pfStack_48 = (float *)0x0;
                if (puVar16[1] != 0) {
                  cVar9 = FUN_00576f40();
                  if (cVar9 == '\0') {
                    pfVar14 = (float *)0x0;
                  }
                  else {
                    pfStack_48 = (float *)puVar16[1];
                    pfVar14 = (float *)*puVar16;
                  }
                }
                uStack_30 = uStack_30 | 0x30;
                cStack_21 = '\x01';
                if (pfVar14 != pfStack_2c) goto LAB_00aea4d7;
              }
              pfVar14 = pfStack_48;
              if (((uStack_30 & 0x20) != 0) &&
                 (uStack_30 = uStack_30 & 0xffffffdf, pfStack_48 != (float *)0x0)) {
                LOCK();
                fVar12 = (float)((int)pfStack_48[1] + -1);
                pfStack_48[1] = fVar12;
                UNLOCK();
                if (fVar12 == 0.0) {
                  (**(code **)*pfStack_48)();
                  LOCK();
                  pfVar20 = pfVar14 + 2;
                  fVar12 = (float)((int)*pfVar20 + -1);
                  *pfVar20 = fVar12;
                  UNLOCK();
                  if (fVar12 == 0.0) {
                    (**(code **)((int)*pfVar14 + 4))();
                  }
                }
              }
              pfVar14 = pfStack_3c;
              if (((uStack_30 & 0x10) != 0) &&
                 (uStack_30 = uStack_30 & 0xffffffef, pfStack_3c != (float *)0x0)) {
                LOCK();
                fVar12 = (float)((int)pfStack_3c[1] + -1);
                pfStack_3c[1] = fVar12;
                UNLOCK();
                if (fVar12 == 0.0) {
                  (**(code **)*pfStack_3c)();
                  LOCK();
                  pfVar20 = pfVar14 + 2;
                  fVar12 = (float)((int)*pfVar20 + -1);
                  *pfVar20 = fVar12;
                  UNLOCK();
                  if (fVar12 == 0.0) {
                    (**(code **)((int)*pfVar14 + 4))();
                  }
                }
              }
              uStack_30 = uStack_30 & 0xfffffff7;
              if (piVar15 != (int *)0x0) {
                LOCK();
                iVar10 = piVar15[1] + -1;
                piVar15[1] = iVar10;
                UNLOCK();
                if (iVar10 == 0) {
                  (**(code **)*piVar15)();
                  LOCK();
                  iVar10 = piVar15[2] + -1;
                  piVar15[2] = iVar10;
                  UNLOCK();
                  if (iVar10 == 0) {
                    (**(code **)(*piVar15 + 4))();
                  }
                }
              }
              piVar15 = piStack_40;
              if (cStack_21 != '\0') {
                pfStack_60 = (float *)(*(uint *)pfStack_60[0x86] ^ (uint)pfStack_60[0x86]);
                fVar12 = (float)pfStack_60 * DAT_018ce2f4;
                pfStack_28[-2] = fVar12 * pfStack_28[-2];
                pfStack_28[-1] = fVar12 * pfStack_28[-1];
                *pfStack_28 = fVar12 * *pfStack_28;
              }
            }
          }
          pfVar20 = pfStack_44;
          pfVar14 = pfStack_50;
          (**(code **)(**(int **)((int)pfStack_44 + *piVar15 + 8) + 0x10))(1);
          (**(code **)(**(int **)(*piStack_40 + 8 + (int)pfVar20) + 0xc))(pfStack_28 + -2);
          piVar15 = piStack_40;
        }
        iVar10 = *piVar15;
        pfStack_28 = pfStack_28 + 8;
        pfStack_50 = (float *)((int)pfVar14 + 1);
        pfStack_44 = pfVar20 + 4;
      } while (pfStack_50 < (float *)(piVar15[1] - iVar10 >> 4));
    }
    pfVar14 = pfStack_ac;
    if (pfStack_ac != (float *)0x0) {
      LOCK();
      fVar12 = (float)((int)pfStack_ac[1] + -1);
      pfStack_ac[1] = fVar12;
      UNLOCK();
      if (fVar12 == 0.0) {
        (**(code **)*pfStack_ac)();
        LOCK();
        pfVar20 = pfVar14 + 2;
        fVar12 = *pfVar20;
        *pfVar20 = (float)((int)*pfVar20 + -1);
        UNLOCK();
        if (fVar12 == 1.4013e-45) {
          (**(code **)((int)*pfVar14 + 4))();
        }
      }
    }
    FUN_007a4f50();
    FUN_007a4f50();
  }
LAB_00aea65e:
  iStack_14 = CONCAT31(iStack_14._1_3_,0xe);
  FUN_0152dda0(uStack_c8,uStack_c4,uStack_e0);
  iStack_14 = 0xf;
  FUN_01675290(uStack_cc);
  ExceptionList = pvStack_1c;
  return;
  while( true ) {
    pfStack_34 = (float *)((int)pfVar14 + 1);
    fVar12 = (float)FUN_00e668b0();
    if ((float *)fVar12 == pfStack_2c) {
      iVar10 = FUN_0074a340();
      if (*(char *)(iVar10 + 0x69) == '\0') {
        FUN_00e67520(*(int *)(iStack_38 + 0xa4) + (int)pfStack_28,iStack_38 + 0x98,iStack_38 + 0xb0,
                     iStack_38 + 200,(float)*(double *)(param_2 + 8),0x3f800000);
      }
      else {
        FUN_00e67760(*(int *)(iStack_38 + 0xa4) + (int)pfStack_28,piStack_40,iStack_38 + 0xb0,
                     (float)*(double *)(param_2 + 8),0x3f800000);
      }
    }
    pfStack_28 = pfStack_28 + 3;
    piVar18 = (int *)*piVar18;
    pfVar14 = pfStack_34;
    if (piVar18 == piVar15) break;
LAB_00ae97e0:
    if (pfStack_3c <= pfVar14) break;
  }
LAB_00ae9880:
  iVar11 = iStack_38;
  cStack_21 = '\x01';
  fStack_58 = 0.0;
  iVar10 = piStack_40[1];
  piVar15 = piStack_40;
  if (iVar10 - *piStack_40 >> 4 != 0) {
    iVar21 = 0;
    pfStack_28 = (float *)0x0;
    do {
      iVar10 = *(int *)(iVar11 + 0xbc);
      if (*(char *)(iVar10 + 0x28 + iVar21) == '\0') {
        pfStack_2c = (float *)(*(float *)(iVar10 + 0x20 + iVar21) +
                              *(float *)(iVar10 + 0x1c + iVar21));
        fStack_5c = *(float *)(iVar21 + 0x20 + *(int *)(iVar11 + 0xb0)) +
                    *(float *)(iVar21 + 0x1c + *(int *)(iVar11 + 0xb0));
        if ((float)pfStack_50 < fStack_5c) {
          fVar22 = (float10)FUN_01729cd8(0,(float)pfStack_44 - (float)pfStack_2c);
          pfStack_34 = (float *)(float)fVar22;
          fVar22 = (float10)FUN_01729d34(fStack_5c,pfStack_34);
          iVar10 = *(int *)(iVar11 + 0xb0);
          iVar2 = *(int *)(iVar11 + 0xbc);
          fVar28 = (*(float *)(iVar10 + 0x1c + iVar21) * (float)fVar22) / fStack_5c;
          piStack_64 = (int *)((*(float *)(iVar10 + 0x20 + iVar21) * (float)fVar22) / fStack_5c);
          pfStack_34 = *(float **)(iVar21 + iVar2);
          fVar27 = *(float *)(iVar10 + iVar21) * fVar28;
          fVar12 = *(float *)(iVar10 + 4 + iVar21) * fVar28;
          fVar25 = *(float *)(iVar10 + 8 + iVar21) * fVar28;
          fVar26 = *(float *)(iVar10 + 0xc + iVar21) * fVar28;
          if (*(float *)(iVar21 + 4 + iVar2) * fVar12 + (float)pfStack_34 * fVar27 +
              *(float *)(iVar21 + 8 + iVar2) * fVar25 + *(float *)(iVar21 + 0xc + iVar2) * fVar26 <
              (float)pfStack_50) {
            fVar27 = fVar27 * DAT_018f7864;
            fVar12 = fVar12 * DAT_018f7864;
            fVar25 = fVar25 * DAT_018f7864;
            fVar26 = fVar26 * DAT_018f7864;
          }
          *(float *)(iVar21 + iVar2) = (float)pfStack_34 + fVar27;
          *(float *)(iVar21 + 4 + iVar2) = fVar12 + *(float *)(iVar21 + 4 + iVar2);
          *(float *)(iVar21 + 8 + iVar2) = *(float *)(iVar21 + 8 + iVar2) + fVar25;
          *(float *)(iVar21 + 0xc + iVar2) = fVar26 + *(float *)(iVar21 + 0xc + iVar2);
          fVar12 = *(float *)(iVar10 + 0x14 + iVar21);
          fVar26 = *(float *)(iVar10 + 0x18 + iVar21);
          *(float *)(iVar21 + 0x10 + iVar2) =
               *(float *)(iVar21 + 0x10 + iVar2) + *(float *)(iVar10 + 0x10 + iVar21) * fVar28;
          *(float *)(iVar21 + 0x14 + iVar2) = *(float *)(iVar21 + 0x14 + iVar2) + fVar12 * fVar28;
          *(float *)(iVar21 + 0x18 + iVar2) = *(float *)(iVar21 + 0x18 + iVar2) + fVar26 * fVar28;
          *(float *)(iVar21 + 0x1c + iVar2) = *(float *)(iVar21 + 0x1c + iVar2) + fVar28;
          *(float *)(iVar21 + 0x20 + iVar2) = *(float *)(iVar21 + 0x20 + iVar2) + (float)piStack_64;
          if ((float)pfStack_50 < (float)piStack_64) {
            *(int **)((int)pfStack_28 + *(int *)(iVar11 + 200) + 0x18) = piStack_64;
            puVar13 = (undefined4 *)
                      FUN_00dcaa10(&uStack_98,*(int *)(iVar11 + 0xd4) + (int)pfStack_28,
                                   *(int *)(iVar11 + 200) + (int)pfStack_28);
            uVar30 = puVar13[1];
            uVar33 = puVar13[2];
            uVar3 = puVar13[3];
            uVar4 = puVar13[4];
            uVar5 = puVar13[5];
            uVar6 = puVar13[6];
            uVar7 = puVar13[7];
            iVar10 = *(int *)(iVar11 + 0xd4);
            puVar16 = (undefined4 *)(iVar10 + (int)pfStack_28);
            *puVar16 = *puVar13;
            puVar16[1] = uVar30;
            puVar16[2] = uVar33;
            puVar16[3] = uVar3;
            puVar16 = (undefined4 *)(iVar10 + 0x10 + (int)pfStack_28);
            *puVar16 = uVar4;
            puVar16[1] = uVar5;
            puVar16[2] = uVar6;
            puVar16[3] = uVar7;
          }
          piVar15 = (int *)(iVar11 + 0x98);
        }
        *(bool *)(*(int *)(iVar11 + 0xbc) + 0x28 + iVar21) =
             (float)pfStack_44 <= fStack_5c + (float)pfStack_2c;
      }
      if ((cStack_21 == '\0') ||
         (cStack_21 = '\x01', *(char *)(*(int *)(iVar11 + 0xbc) + 0x28 + iVar21) == '\0')) {
        cStack_21 = '\0';
      }
      iVar10 = piVar15[1];
      iVar21 = iVar21 + 0x2c;
      fStack_58 = (float)((int)fStack_58 + 1);
      pfStack_28 = pfStack_28 + 8;
    } while ((uint)fStack_58 < (uint)(iVar10 - *piVar15 >> 4));
  }
  uVar17 = 0;
  if (iVar10 - *piVar15 >> 4 != 0) {
    pfStack_2c = (float *)0x0;
    fStack_58 = 0.0;
    do {
      uVar1 = uStack_7c;
      puVar16 = (undefined4 *)(*(int *)(iVar11 + 0xb0) + (int)fStack_58);
      fStack_58 = (float)((int)fStack_58 + 0x2c);
      uStack_7c = uStack_7c & 0xffffff00;
      uVar17 = uVar17 + 1;
      fStack_88 = 0.0;
      *puVar16 = 0;
      puVar16[1] = 0;
      puVar16[2] = 0;
      puVar16[3] = 0;
      fStack_84 = 0.0;
      puVar16[4] = 0;
      puVar16[5] = 0;
      puVar16[6] = 0;
      puVar16[7] = 0;
      pfStack_80 = (float *)0x0;
      *(ulonglong *)(puVar16 + 8) = CONCAT44(pfStack_44,pfStack_50);
      puVar16[10] = uStack_7c;
      iVar10 = *(int *)(iVar11 + 200);
      uStack_7c = uVar1 & 0xffff0000;
      puVar16 = (undefined4 *)(iVar10 + (int)pfStack_2c);
      *puVar16 = 0;
      puVar16[1] = 0;
      puVar16[2] = 0;
      puVar16[3] = 0;
      puVar16 = (undefined4 *)(iVar10 + 0x10 + (int)pfStack_2c);
      *puVar16 = 0;
      puVar16[1] = 0;
      puVar16[2] = 0;
      puVar16[3] = uStack_7c;
      pfStack_2c = (float *)((int)pfStack_2c + 0x20);
    } while (uVar17 < (uint)(piVar15[1] - *piVar15 >> 4));
  }
  if (cStack_21 != '\0') goto LAB_00ae9bf1;
LAB_00ae9bda:
  pfStack_54 = pfStack_54 + 1;
  param_1 = iStack_38;
  if (pfStack_54 == (float *)"JoinTime_LocalUserAnimationPriority") goto LAB_00ae9bf1;
  goto LAB_00ae9790;
LAB_00ae9bf1:
  iVar10 = *piVar15;
  pfStack_2c = (float *)0x0;
  if (piVar15[1] - iVar10 >> 4 != 0) {
    pfStack_28 = (float *)0x0;
    fStack_5c = 0.0;
    pfStack_3c = (float *)0x0;
    uStack_78 = DAT_0194cbb0;
    dVar23 = DAT_0194cbb0;
    do {
      iVar11 = iStack_38;
      pfVar14 = pfStack_3c;
      iVar10 = *(int *)((int)fStack_5c + 4 + iVar10);
      if ((iVar10 != 0) && (*(int *)(iVar10 + 4) != 0)) {
        iVar10 = *(int *)(iStack_38 + 0xbc);
        fVar12 = *(float *)((int)pfStack_3c + iVar10 + 0x1c);
        if ((float)pfStack_50 < fVar12) {
          if ((float)pfStack_44 < fVar12) {
            fVar12 = (float)pfStack_44 / fVar12;
            *(float *)((int)pfStack_3c + iVar10 + 0x10) =
                 fVar12 * *(float *)((int)pfStack_3c + iVar10 + 0x10);
            *(float *)((int)pfStack_3c + iVar10 + 0x14) =
                 fVar12 * *(float *)((int)pfStack_3c + iVar10 + 0x14);
            *(float *)((int)pfStack_3c + iVar10 + 0x18) =
                 fVar12 * *(float *)((int)pfStack_3c + iVar10 + 0x18);
          }
          uVar3 = _UNK_018f99ac;
          uVar33 = _UNK_018f99a8;
          uVar30 = _UNK_018f99a4;
          fVar12 = *(float *)((int)pfStack_3c + iVar10 + 4);
          fVar26 = *(float *)((int)pfStack_3c + iVar10 + 8);
          fVar27 = *(float *)((int)pfStack_3c + iVar10 + 0xc);
          fVar12 = *(float *)((int)pfStack_3c + iVar10) * *(float *)((int)pfStack_3c + iVar10) +
                   fVar12 * fVar12 + fVar26 * fVar26 + fVar27 * fVar27;
          if (fVar12 <= (float)pfStack_50) {
            puVar16 = (undefined4 *)((int)pfStack_3c + iVar10);
            *puVar16 = _DAT_018f99a0;
            puVar16[1] = uVar30;
            puVar16[2] = uVar33;
            puVar16[3] = uVar3;
          }
          else {
            dVar23 = (double)fVar12;
            FUN_017267a0();
            fVar25 = (float)pfStack_44 / (float)dVar23;
            pfVar20 = (float *)((int)pfVar14 + *(int *)(iVar11 + 0xbc));
            fVar12 = pfVar20[1];
            fVar26 = pfVar20[2];
            fVar27 = pfVar20[3];
            pfVar31 = (float *)((int)pfVar14 + *(int *)(iVar11 + 0xbc));
            *pfVar31 = fVar25 * *pfVar20;
            pfVar31[1] = fVar25 * fVar12;
            pfVar31[2] = fVar25 * fVar26;
            pfVar31[3] = fVar25 * fVar27;
            dVar23 = uStack_78;
          }
          iVar10 = *(int *)(iVar11 + 0xbc);
          fStack_8c = 0.0;
          fStack_88 = 0.0;
          fStack_84 = 0.0;
          uStack_7c = uStack_7c & 0xffff0000;
          uStack_98 = *(undefined8 *)((int)pfVar14 + iVar10 + 0x10);
          uStack_90 = *(undefined4 *)((int)pfVar14 + iVar10 + 0x18);
          pfStack_80 = *(float **)((int)pfVar14 + iVar10 + 0x1c);
          if ((float)pfStack_44 <= (float)pfStack_80) {
            pfStack_80 = pfStack_44;
          }
          pfVar14 = (float *)((int)pfVar14 + iVar10);
          fStack_c0 = *pfVar14;
          fStack_bc = pfVar14[1];
          fStack_f4 = pfVar14[3];
          uStack_b8 = *(ulonglong *)(pfVar14 + 2);
          if ((float)pfStack_50 <= fStack_f4) {
            pfStack_34 = (float *)(float)uStack_b8;
            fStack_f8 = fStack_f4;
            fStack_58 = fStack_bc;
            pfStack_54 = (float *)fStack_c0;
          }
          else {
            pfStack_54 = (float *)(fStack_c0 * DAT_018f7864);
            fStack_58 = fStack_bc * DAT_018f7864;
            pfStack_34 = (float *)((float)uStack_b8 * DAT_018f7864);
            fStack_f8 = fStack_f4 * DAT_018f7864;
          }
          dVar24 = (double)((float)pfStack_44 - fStack_f8 * fStack_f8);
          fStack_f0 = fStack_f4;
          fStack_ec = fStack_f4;
          if (dVar23 <= dVar24) {
            FUN_017267a0();
            fVar12 = (float)pfStack_44 / (float)dVar24;
            pfVar14 = (float *)(fVar12 * (float)pfStack_54);
            pfStack_54 = (float *)(fVar12 * fStack_58);
            pfStack_34 = (float *)(fVar12 * (float)pfStack_34);
          }
          else {
            pfStack_54 = pfStack_50;
            pfStack_34 = pfStack_50;
            pfVar14 = pfStack_44;
          }
          uStack_b8 = ZEXT48(pfVar14);
          dVar23 = (double)fStack_f8;
          FUN_01729d90();
          pfVar14 = pfStack_28;
          fStack_88 = (float)dVar23 + (float)dVar23;
          fStack_d0 = (float)pfStack_34 * fStack_88;
          fStack_8c = (float)uStack_b8 * fStack_88;
          fStack_88 = (float)pfStack_54 * fStack_88;
          puVar16 = (undefined4 *)(*(int *)(iVar11 + 0xd4) + (int)pfStack_28);
          fStack_84 = fStack_d0;
          if ((float)puVar16[6] <= (float)pfStack_50) {
            *puVar16 = (undefined4)uStack_98;
            puVar16[1] = uStack_98._4_4_;
            puVar16[2] = uStack_90;
            puVar16[3] = fStack_8c;
            puVar16[4] = fStack_88;
            puVar16[5] = fStack_d0;
            puVar16[6] = pfStack_80;
            puVar16[7] = uStack_7c;
          }
          else {
            puVar13 = (undefined4 *)FUN_00dcaa10(auStack_108,puVar16,&uStack_98);
            uVar30 = puVar13[1];
            uVar33 = puVar13[2];
            uVar3 = puVar13[3];
            uVar4 = puVar13[4];
            uVar5 = puVar13[5];
            uVar6 = puVar13[6];
            uVar7 = puVar13[7];
            iVar10 = *(int *)(iVar11 + 0xd4);
            puVar16 = (undefined4 *)(iVar10 + (int)pfVar14);
            *puVar16 = *puVar13;
            puVar16[1] = uVar30;
            puVar16[2] = uVar33;
            puVar16[3] = uVar3;
            puVar16 = (undefined4 *)(iVar10 + 0x10 + (int)pfVar14);
            *puVar16 = uVar4;
            puVar16[1] = uVar5;
            puVar16[2] = uVar6;
            puVar16[3] = uVar7;
          }
        }
        iVar10 = 0;
        pfStack_54 = (float *)0x0;
        if (*(int *)(iVar11 + 0x94) != 0) {
          cVar9 = FUN_00576f40();
          if (cVar9 != '\0') {
            pfStack_54 = *(float **)(iVar11 + 0x94);
            iVar10 = *(int *)(iVar11 + 0x90);
          }
        }
        uStack_30 = uStack_30 | 1;
        if (iVar10 == 0) {
LAB_00ae9fd0:
          cStack_21 = '\0';
        }
        else {
          fStack_58 = 0.0;
          piStack_64 = (int *)0x0;
          if (*(int *)(iVar11 + 0x94) != 0) {
            fStack_58 = 0.0;
            cVar9 = FUN_00576f40();
            if (cVar9 != '\0') {
              piStack_64 = *(int **)(iVar11 + 0x94);
              fStack_58 = *(float *)(iVar11 + 0x90);
            }
          }
          pfStack_34 = (float *)(*(int *)(iVar11 + 0x98) + (int)fStack_5c);
          fVar12 = 0.0;
          piStack_a8 = (int *)0x0;
          if (pfStack_34[1] != 0.0) {
            cVar9 = FUN_00576f40();
            if (cVar9 == '\0') {
              fVar12 = 0.0;
            }
            else {
              piStack_a8 = (int *)pfStack_34[1];
              fVar12 = *pfStack_34;
            }
          }
          uStack_30 = uStack_30 | 6;
          if (fVar12 != fStack_58) goto LAB_00ae9fd0;
          cStack_21 = '\x01';
        }
        if (((uStack_30 & 4) != 0) && (uStack_30 = uStack_30 & 0xfffffffb, piStack_a8 != (int *)0x0)
           ) {
          LOCK();
          iVar10 = piStack_a8[1] + -1;
          piStack_a8[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piStack_a8)();
            LOCK();
            iVar10 = piStack_a8[2] + -1;
            piStack_a8[2] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piStack_a8 + 4))();
            }
          }
        }
        if (((uStack_30 & 2) != 0) && (uStack_30 = uStack_30 & 0xfffffffd, piStack_64 != (int *)0x0)
           ) {
          LOCK();
          iVar10 = piStack_64[1] + -1;
          piStack_64[1] = iVar10;
          UNLOCK();
          if (iVar10 == 0) {
            (**(code **)*piStack_64)();
            LOCK();
            iVar10 = piStack_64[2] + -1;
            piStack_64[2] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)(*piStack_64 + 4))();
            }
          }
        }
        uStack_30 = uStack_30 & 0xfffffffe;
        if (pfStack_54 != (float *)0x0) {
          LOCK();
          fVar12 = (float)((int)pfStack_54[1] + -1);
          pfStack_54[1] = fVar12;
          UNLOCK();
          if (fVar12 == 0.0) {
            (**(code **)*pfStack_54)();
            LOCK();
            fVar12 = (float)((int)pfStack_54[2] + -1);
            pfStack_54[2] = fVar12;
            UNLOCK();
            if (fVar12 == 0.0) {
              (**(code **)((int)*pfStack_54 + 4))();
            }
          }
        }
        if (cStack_21 != '\0') {
          pfVar14 = (float *)(*(int *)(iVar11 + 0xd4) + (int)pfStack_28);
          *pfVar14 = *pfVar14 * (float)pfStack_60;
          pfVar14[1] = pfVar14[1] * (float)pfStack_60;
          pfVar14[2] = pfVar14[2] * (float)pfStack_60;
        }
        (**(code **)(**(int **)(*(int *)(iVar11 + 0x98) + 8 + (int)fStack_5c) + 0x10))(1);
        (**(code **)(**(int **)((int)fStack_5c + 8 + *(int *)(iVar11 + 0x98)) + 0xc))
                  (*(int *)(iVar11 + 0xd4) + (int)pfStack_28);
        piVar15 = piStack_40;
        dVar23 = uStack_78;
      }
      pfStack_3c = pfStack_3c + 0xb;
      iVar10 = *piVar15;
      fStack_5c = (float)((int)fStack_5c + 0x10);
      pfStack_2c = (float *)((int)pfStack_2c + 1);
      pfStack_28 = pfStack_28 + 8;
    } while (pfStack_2c < (float *)(piVar15[1] - iVar10 >> 4));
  }
  pfVar14 = pfStack_48;
  if (pfStack_48 != (float *)0x0) {
    LOCK();
    fVar12 = (float)((int)pfStack_48[1] + -1);
    pfStack_48[1] = fVar12;
    UNLOCK();
    if (fVar12 == 0.0) {
      (**(code **)*pfStack_48)();
      LOCK();
      pfVar20 = pfVar14 + 2;
      fVar12 = *pfVar20;
      *pfVar20 = (float)((int)*pfVar20 + -1);
      UNLOCK();
      if (fVar12 == 1.4013e-45) {
        (**(code **)((int)*pfVar14 + 4))();
      }
    }
  }
  goto LAB_00aea65e;
code_r0x00aea239:
  piVar18 = (int *)*piVar18;
  pfVar14 = pfStack_28;
  if (piVar18 == piVar15) goto LAB_00aea245;
  goto LAB_00aea228;
}



/* FUNCTION 22645 ; VA 0x00aeb300 ; FUN_00aeb300 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00aeb300(int param_1,int param_2)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  int *piVar5;
  undefined4 *puVar6;
  int iVar7;
  int iVar8;
  int *piVar9;
  int *piVar10;
  undefined *puStack_30;
  int *piStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eb888;
  pvStack_10 = ExceptionList;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    iStack_18 = param_1;
    piVar5 = (int *)FUN_00aec170(param_2);
    if (piVar5 != (int *)0x0) {
      puStack_30 = PTR_018bd540;
      piStack_2c = (int *)_UNK_018bd544;
      piStack_28 = (int *)_UNK_018bd548;
      uStack_24 = _UNK_018bd54c;
      uStack_8 = 0;
      puVar6 = (undefined4 *)FUN_0060e0c0(auStack_20,param_2);
      piStack_2c = (int *)puVar6[1];
      puStack_30 = (undefined *)*puVar6;
      *puVar6 = 0;
      puVar6[1] = 0;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
      piStack_28 = piVar5;
      FUN_00aed9b0(&puStack_30);
      piStack_14 = (int *)(**(code **)(*piVar5 + 4))();
      puVar6 = (undefined4 *)(**(code **)(*piVar5 + 8))();
      piVar5 = piStack_14;
      if (0xf < (uint)piStack_14[5]) {
        piVar5 = (int *)*piStack_14;
      }
      cVar4 = FUN_0055c360(piVar5,piStack_14[4],"HumanoidRootPart",0x10);
      if (cVar4 != '\0') {
        puVar1 = puVar6 + 4;
        if (0xf < (uint)puVar6[5]) {
          puVar6 = (undefined4 *)*puVar6;
        }
        cVar4 = FUN_0055c360(puVar6,*puVar1,"LowerTorso",10);
        if (cVar4 != '\0') {
          FUN_0088ddf0(&puStack_30);
        }
      }
      uStack_8 = 0xffffffff;
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_2c + 4))();
        }
      }
    }
    piVar5 = *(int **)(param_2 + 0x2c);
    if (piVar5 != (int *)0x0) {
      piVar9 = (int *)piVar5[1];
      piVar10 = (int *)*piVar5;
      piStack_14 = piVar9;
      if (piVar10 != piVar9) {
        do {
          iVar3 = *piVar10;
          if (iVar3 != *(int *)(param_1 + 0x34)) {
            iVar2 = *(int *)(iVar3 + 0xc);
            iVar7 = FUN_0099be20();
            iVar8 = 0;
            if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
                (uint)*(ushort *)(iVar7 + 0x1da)) {
              iVar8 = iVar3;
            }
            if (iVar8 != 0) {
              ExceptionList = pvStack_10;
              return;
            }
            iVar3 = *piVar10;
            iVar2 = *(int *)(iVar3 + 0xc);
            iVar7 = FUN_00e63c60();
            iVar8 = 0;
            if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
                (uint)*(ushort *)(iVar7 + 0x1da)) {
              iVar8 = iVar3;
            }
            piVar9 = piStack_14;
            param_1 = iStack_18;
            if (iVar8 != 0) {
              ExceptionList = pvStack_10;
              return;
            }
          }
          piVar10 = piVar10 + 2;
        } while (piVar10 != piVar9);
        piVar5 = *(int **)(param_2 + 0x2c);
        piVar10 = (int *)*piVar5;
      }
      piVar5 = (int *)piVar5[1];
      for (; piVar10 != piVar5; piVar10 = piVar10 + 2) {
        FUN_00aeb300(*piVar10);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22646 ; VA 0x00aeb4f0 ; FUN_00aeb4f0 */

undefined4 * __thiscall
FUN_00aeb4f0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eb8d1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00aeb810;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 22647 ; VA 0x00aeb6a0 ; FUN_00aeb6a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00aeb6a0(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = thunk_FUN_00aeea60();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01eec53c) {
      FUN_016f3809(&DAT_01eec53c);
      if (DAT_01eec53c == -1) {
        _DAT_01eec530 = FUN_005c65e0;
        _DAT_01eec534 = FUN_005c65e0;
        _DAT_01eec538 = _guard_check_icall;
        FUN_016f37bf(&DAT_01eec53c);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01eec530) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01eec530;
  }
  return;
}



/* FUNCTION 22648 ; VA 0x00aeb760 ; FUN_00aeb760 */

void FUN_00aeb760(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00aeea60();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22649 ; VA 0x00aeb7a0 ; FUN_00aeb7a0 */

undefined4 * FUN_00aeb7a0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_0099efd0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 22650 ; VA 0x00aeb810 ; FUN_00aeb810 */

void FUN_00aeb810(int param_1,int param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_0000001c;
  undefined in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined4 in_stack_00000034;
  undefined4 uStack_5d0;
  undefined4 uStack_5cc;
  undefined4 uStack_500;
  undefined4 uStack_4fc;
  undefined uStack_4f8;
  undefined4 uStack_430;
  undefined4 uStack_42c;
  undefined4 uStack_428;
  undefined4 uStack_360;
  undefined4 uStack_35c;
  undefined4 uStack_358;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eb953;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_5d0 = FUN_0088d190();
  uStack_5cc = 0;
  FUN_0054ef60(&param_2);
  uStack_5cc = FUN_00630cf0();
  uStack_8._0_1_ = 2;
  uStack_500 = FUN_0088daf0();
  uStack_4fc = 0;
  uStack_4f8 = in_stack_00000020;
  uStack_4fc = FUN_005c9ef0();
  uStack_8._0_1_ = 3;
  uStack_430 = FUN_0088c960();
  uStack_42c = 0;
  uStack_428 = in_stack_00000024;
  uStack_42c = FUN_00630820();
  uStack_8._0_1_ = 4;
  uStack_360 = FUN_0088c960();
  uStack_35c = 0;
  uStack_358 = in_stack_00000028;
  uStack_35c = FUN_00630820();
  uStack_8._0_1_ = 5;
  uStack_290 = FUN_0088c960();
  uStack_28c = 0;
  uStack_288 = in_stack_0000002c;
  uStack_28c = FUN_00630820();
  uStack_8._0_1_ = 6;
  uStack_1c0 = FUN_0088c960();
  uStack_1bc = 0;
  uStack_1b8 = in_stack_00000030;
  uStack_1bc = FUN_00630820();
  uStack_8._0_1_ = 7;
  uStack_f0 = FUN_0088c8c0();
  uStack_ec = 0;
  uStack_e8 = in_stack_00000034;
  uStack_ec = FUN_005c9cc0();
  uStack_8._0_1_ = 8;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_5d0,&uStack_20,piVar1);
  uStack_8._0_1_ = 9;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 10;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_5d0,0xd0,7,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  FUN_01675290(uVar3);
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar4 = param_2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_2 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22651 ; VA 0x00aeba60 ; FUN_00aeba60 */

int FUN_00aeba60(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = (**(code **)(param_1 + 0x18))();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 22652 ; VA 0x00aebad0 ; FUN_00aebad0 */

void FUN_00aebad0(int param_1,int param_2)

{
  code *pcVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_0000001c;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b3430;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  pcVar1 = *(code **)(param_1 + 0x18);
  FUN_0054ef60(aiStack_28);
  (*pcVar1)();
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22653 ; VA 0x00aebbe0 ; FUN_00aebbe0 */

undefined4 __thiscall FUN_00aebbe0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined auStack_e0 [4];
  int iStack_dc;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01256300(param_3);
  uVar2 = FUN_009d1540(auStack_e0,param_3,param_4,1,iVar1 - param_4,param_1 + 0x40);
  uStack_8 = 0;
  (**(code **)(param_1 + 0x38))(uVar2);
  uStack_8 = 1;
  if (iStack_dc != 0) {
    (**(code **)(iStack_dc + 8))(auStack_d8);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 22654 ; VA 0x00aebc70 ; FUN_00aebc70 */

undefined4 __thiscall FUN_00aebc70(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  float10 fVar2;
  
  iVar1 = FUN_01256300(param_3);
  fVar2 = (float10)FUN_009d0730(param_3,param_4,1,iVar1 - param_4,param_1 + 0x40);
  (**(code **)(param_1 + 0x38))((float)fVar2);
  return 0;
}



/* FUNCTION 22655 ; VA 0x00aebcc0 ; FUN_00aebcc0 */

void __thiscall
FUN_00aebcc0(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,uint param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined auStack_44 [16];
  undefined8 uStack_34;
  undefined4 uStack_2c;
  undefined **ppuStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eb980;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if ((DAT_01d6fc28 == '\0') ||
     (((*(char **)(param_1 + 0x100) != (char *)0x0 && (**(char **)(param_1 + 0x100) != '\0')) ||
      (*(int *)(param_1 + 0x104) == 0)))) {
    puVar2 = &param_2;
    if (((int)param_5 >> 1 & 1U) == 0) {
      puVar2 = param_2;
    }
    ExceptionList = &pvStack_10;
    (**(code **)(param_5 & 0xfffffff8))(puVar2,param_1);
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_0060dcd0(&uStack_18,param_1);
    if (iStack_14 != 0) {
      LOCK();
      *(int *)(iStack_14 + 4) = *(int *)(iStack_14 + 4) + 1;
      UNLOCK();
    }
    FUN_006d0690(&param_2);
    uStack_8._0_1_ = 2;
    ppuStack_28 = (undefined **)0x0;
    puStack_24 = (undefined4 *)FUN_01674fa0(0x18,4);
    uStack_2c = 4;
    uStack_20 = 0x18;
    uStack_34 = CONCAT44(0x18,puStack_24);
    *puStack_24 = 0;
    puStack_24[1] = 0;
    *puStack_24 = uStack_18;
    puStack_24[1] = iStack_14;
    FUN_006d0690(auStack_44);
    ppuStack_28 = &PTR_FUN_01d669d4;
    FUN_009a33c0();
    iVar1 = *(int *)(param_1 + 0x104);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (*(int *)(iVar1 + 8) == *(int *)(iVar1 + 4)) {
      FUN_0099c0f0(*(int *)(iVar1 + 4),&uStack_34);
    }
    else {
      FUN_0099e8e0(iVar1);
      *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 0x10;
    }
    FUN_006d1d50();
    FUN_00550b30();
  }
  uStack_8 = 4;
  if ((param_5 & 0xfffffff8) != 0) {
    uVar3 = (int)param_5 >> 1;
    if ((~(byte)((int)param_5 >> 2) & 1) == 0) {
      puVar2 = &param_2;
      if ((uVar3 & 1) == 0) {
        puVar2 = param_2;
      }
      (**(code **)((param_5 & 0xfffffff8) + 8))(puVar2);
    }
    if ((uVar3 & 1) == 0) {
      FUN_01674ee0(param_2);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22656 ; VA 0x00aebe90 ; FUN_00aebe90 */

void __thiscall FUN_00aebe90(int *param_1,int *param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar2 = (undefined4 *)*param_1;
  puVar3 = (undefined4 *)puVar2[1];
  puVar4 = puVar2;
  if (*(char *)((int)puVar2[1] + 0xd) == '\0') {
    do {
      cVar1 = FUN_00558ea0(puVar3 + 4,param_3);
      if (cVar1 == '\0') {
        puVar2 = (undefined4 *)*puVar3;
        puVar4 = puVar3;
      }
      else {
        puVar2 = (undefined4 *)puVar3[2];
      }
      puVar3 = puVar2;
    } while (*(char *)((int)puVar2 + 0xd) == '\0');
    puVar2 = (undefined4 *)*param_1;
  }
  if ((puVar4 != puVar2) && (cVar1 = FUN_00558ea0(param_3,puVar4 + 4), cVar1 == '\0')) {
    *param_2 = (int)puVar4;
    return;
  }
  *param_2 = *param_1;
  return;
}



/* FUNCTION 22657 ; VA 0x00aebf10 ; FUN_00aebf10 */

void FUN_00aebf10(undefined4 param_1,undefined4 param_2)

{
  FUN_00ae7c50(param_1,param_2,param_2);
  return;
}



/* FUNCTION 22658 ; VA 0x00aebf30 ; FUN_00aebf30 */

void FUN_00aebf30(void)

{
  int iVar1;
  
  if (DAT_01eec4c4 == 0) {
    iVar1 = FUN_00ae6b40();
    DAT_01eec4c4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 22659 ; VA 0x00aebf60 ; FUN_00aebf60 */

void __thiscall FUN_00aebf60(int param_1,int *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 uStack_f8;
  int iStack_f4;
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eb9ab;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = (undefined4 *)FUN_01674e20(0x18);
  if (puStack_14 == (undefined4 *)0x0) {
    puStack_14 = (undefined4 *)0x0;
  }
  else {
    puStack_14[1] = 1;
    puStack_14[2] = 1;
    *puStack_14 = std::
                  _Ref_count_obj<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_>
                  ::vftable;
    puStack_14[3] = 0;
    puStack_14[4] = 0;
    puStack_14[5] = 0;
  }
  puVar5 = puStack_14 + 3;
  puVar1 = *(undefined4 **)(param_1 + 0xec);
  uStack_8._1_3_ = 0;
  puStack_28 = puVar5;
  puStack_24 = puStack_14;
  for (puVar2 = (undefined4 *)*puVar1; puVar2 != puVar1; puVar2 = (undefined4 *)*puVar2) {
    iStack_1c = puVar2[3];
    if (iStack_1c != 0) {
      LOCK();
      *(int *)(iStack_1c + 4) = *(int *)(iStack_1c + 4) + 1;
      UNLOCK();
      iStack_1c = puVar2[3];
    }
    uVar3 = puVar2[2];
    uStack_8._0_1_ = 1;
    uStack_20 = uVar3;
    iStack_18 = iStack_1c;
    uStack_f8 = FUN_0088cdc0();
    iStack_f4 = 0;
    iStack_ec = iStack_18;
    uStack_20 = 0;
    iStack_1c = 0;
    uStack_f0 = uVar3;
    iStack_f4 = FUN_006309e0();
    puVar4 = puStack_14;
    puVar5 = puStack_14 + 3;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (puStack_14[5] == puStack_14[4]) {
      FUN_005ca4f0(puStack_14[4],&uStack_f8);
    }
    else {
      FUN_005caaf0(puVar5);
      puVar4[4] = puVar4[4] + 0xd0;
    }
    uStack_8._0_1_ = 3;
    if (iStack_f4 != 0) {
      (**(code **)(iStack_f4 + 8))(&uStack_f0);
    }
  }
  param_2[1] = (int)puStack_14;
  *param_2 = (int)puVar5;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22660 ; VA 0x00aec0c0 ; FUN_00aec0c0 */

int FUN_00aec0c0(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = *(int *)(param_1 + 0x34);
  if (iVar3 == 0) {
    return 0;
  }
  iVar1 = *(int *)(iVar3 + 0xc);
  iVar2 = FUN_0099be20();
  if (((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da)) ||
     (iVar1 = *(int *)(iVar3 + 0xc), iVar2 = FUN_00e63c60(),
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
     (uint)*(ushort *)(iVar2 + 0x1da))) {
    iVar3 = *(int *)(iVar3 + 0x34);
  }
  if ((DAT_01d669a4 == '\0') &&
     (iVar1 = *(int *)(iVar3 + 0xc), iVar2 = FUN_00a93fd0(),
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
     (uint)*(ushort *)(iVar2 + 0x1da))) {
    return 0;
  }
  return iVar3;
}



/* FUNCTION 22661 ; VA 0x00aec170 ; FUN_00aec170 */

uint FUN_00aec170(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00c396b0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1 + 0x94U & -(uint)(param_1 != 0);
    }
  }
  if ((DAT_01d669bc != '\0') && (param_1 != 0)) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00d77b00();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return param_1 + 0x9cU & -(uint)(param_1 != 0);
    }
  }
  return 0;
}



/* FUNCTION 22662 ; VA 0x00aec200 ; FUN_00aec200 */

uint FUN_00aec200(void)

{
  int iVar1;
  
  iVar1 = FUN_00ae6b40();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 22663 ; VA 0x00aec220 ; FUN_00aec220 */

uint FUN_00aec220(void)

{
  int iVar1;
  
  iVar1 = FUN_00ae6b40();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 22664 ; VA 0x00aec240 ; FUN_00aec240 */

undefined4 * FUN_00aec240(undefined4 *param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  undefined4 uVar9;
  undefined auStack_70 [24];
  int iStack_58;
  undefined auStack_4c [4];
  int iStack_48;
  int *piStack_44;
  int iStack_40;
  int iStack_3c;
  int aiStack_38 [2];
  int *piStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  int *piStack_20;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eba09;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_01f127c8);
  uStack_28 = uVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if ((param_2 == 0) ||
     (iVar2 = *(int *)(param_2 + 0xc), iVar4 = FUN_00e63280(),
     (uint)*(ushort *)(iVar4 + 0x1da) <
     (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
    piStack_20 = (int *)0x0;
    piVar6 = &iStack_24;
    iStack_14 = 0;
    uVar7 = 8;
  }
  else {
    iStack_14 = param_2;
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    piStack_44 = param_3;
    piVar6 = &iStack_48;
    uVar7 = 4;
  }
  iStack_3c = piVar6[1];
  uVar8 = uVar7 | 0x10;
  iStack_40 = iStack_14;
  *piVar6 = 0;
  piVar6[1] = 0;
  piVar6 = piStack_20;
  if (((uVar7 & 8) != 0) && (uVar8 = uVar7 & 0xfffffff7 | 0x10, piStack_20 != (int *)0x0)) {
    LOCK();
    iVar2 = piStack_20[1] + -1;
    piStack_20[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  piVar6 = piStack_44;
  if (((uVar8 & 4) != 0) && (uVar8 = uVar8 & 0xfffffffb, piStack_44 != (int *)0x0)) {
    LOCK();
    iVar2 = piStack_44[1] + -1;
    piStack_44[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_44)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  iVar2 = iStack_18;
  uStack_8._0_1_ = 2;
  piStack_20 = (int *)uVar8;
  if (iStack_14 == 0) {
    FUN_016756b0(auStack_4c,"LoadAnimation requires an Animation object");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_4c,&DAT_01c17198);
  }
  iStack_18 = *(int *)(iStack_18 + 0x34);
  uVar9 = DAT_01901d9c;
  if ((((DAT_01d66974 != '\0') && (iStack_18 != 0)) &&
      (iVar4 = FUN_0097bf90(iStack_18), uVar9 = DAT_01901d9c, iVar4 != 0)) &&
     (*(int *)(iStack_18 + 0x34) == iVar4)) {
    uVar9 = DAT_018fabe8;
  }
  FUN_00e63810(aiStack_38,iStack_18,uVar9);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_0054ef60(iStack_14 + 0x54);
  uStack_1c = uVar8 | 0x20;
  if (&DAT_0000000f < piStack_44) {
    piVar6 = (int *)((int)piStack_44 + 1);
    iVar4 = iStack_58;
    if ((int *)0xfff < piVar6) {
      iVar4 = *(int *)(iStack_58 + -4);
      piVar6 = piStack_44 + 9;
      if (0x1f < (iStack_58 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,piVar6);
  }
  if (iStack_48 != 0) {
    if (aiStack_38[0] == 0) {
      if (*(int *)(iVar2 + 0x34) == 0) {
        puVar5 = *(undefined4 **)(iVar2 + 0x28);
        if (0xf < (uint)puVar5[5]) {
          puVar5 = (undefined4 *)*puVar5;
        }
      }
      else {
        puVar5 = (undefined4 *)FUN_008a2380(auStack_70);
        uStack_1c = (uint)piStack_20 | 0x21;
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        if (0xf < (uint)puVar5[5]) {
          puVar5 = (undefined4 *)*puVar5;
        }
        if (*(int *)(iVar2 + 0x34) != 0) {
          FUN_005c8ab0();
        }
      }
      FUN_0065af10();
      uVar3 = FUN_005543f0();
      FUN_016756b0(auStack_4c,
                   "LoadAnimation requires the %s object (%s) to be a descendant of the game object"
                   ,uVar3,puVar5);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_4c,&DAT_01c17198);
    }
    FUN_0060dcd0(&iStack_48,iVar2);
    uStack_8._0_1_ = 5;
    FUN_00ae7910(&piStack_30,&iStack_48,&iStack_40,aiStack_38);
    uStack_8._0_1_ = 6;
    (**(code **)(*piStack_30 + 0x38))(*(undefined4 *)(param_2 + 0x28));
    piVar6 = piStack_30;
    piStack_30 = (int *)0x0;
    *param_1 = piVar6;
    param_1[1] = uStack_2c;
    uStack_2c = 0;
    FUN_00550b30();
    FUN_00550b30();
    FUN_00550b30();
    FUN_00550b30();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_01675290(uVar3);
    FUN_00550b30();
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_4c,"LoadAnimation requires the asset id to not be empty");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_4c,&DAT_01c17198);
}



/* FUNCTION 22665 ; VA 0x00aec590 ; FUN_00aec590 */

void FUN_00aec590(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00aeea60();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 22666 ; VA 0x00aec5d0 ; FUN_00aec5d0 */

/* WARNING: Removing unreachable block (ram,0x00aec73d) */

void __thiscall FUN_00aec5d0(int param_1,float param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined8 uStack_34;
  double dStack_2c;
  undefined auStack_20 [8];
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eba28;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar4 = *(int *)(param_1 + 0x34);
    iVar2 = param_1;
    ExceptionList = &pvStack_10;
    if ((iVar4 != 0) && (iVar2 = iVar4, ExceptionList = &pvStack_10, *(int *)(iVar4 + 0x34) != 0)) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_005c8ac0();
    }
    if ((iVar2 != 0) &&
       (iVar4 = *(int *)(iVar2 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      piVar3 = (int *)FUN_00564130();
      if ((*piVar3 != 0) && (*(int *)(*piVar3 + 0x68) == 1)) {
        FUN_00550130("Animator:StepAnimations() can only be used when the game is not running!");
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8();
      }
    }
  }
  uStack_34 = 0;
  dStack_2c = (double)param_2;
  (*(code *)**(undefined4 **)(param_1 + 0x54))(&uStack_34);
  FUN_00588320();
  iVar4 = *(int *)(param_1 + 0x98);
  uStack_8 = 0;
  uStack_14 = 0;
  if (*(int *)(param_1 + 0x9c) - iVar4 >> 4 != 0) {
    iVar2 = 0;
    do {
      iVar1 = *(int *)(iVar2 + 4 + iVar4);
      if ((((iVar1 != 0) && (*(int *)(iVar1 + 4) != 0)) &&
          (piVar3 = (int *)(**(code **)**(undefined4 **)(iVar2 + 8 + iVar4))(), piVar3 != (int *)0x0
          )) && (((**(code **)(*piVar3 + 0x38))((double)param_2), piVar3[0xb] != 0 &&
                 (iStack_18 = FUN_00ca1730(), iStack_18 != 0)))) {
        FUN_00ae7a60(auStack_20,&iStack_18,&iStack_18);
      }
      iVar2 = iVar2 + 0x10;
      iVar4 = *(int *)(param_1 + 0x98);
      uStack_14 = uStack_14 + 1;
    } while (uStack_14 < (uint)(*(int *)(param_1 + 0x9c) - iVar4 >> 4));
  }
  for (puVar5 = (undefined4 *)0x0; puVar5 != (undefined4 *)0x0; puVar5 = (undefined4 *)*puVar5) {
    FUN_00ca1b70();
    if (DAT_01d66984 != '\0') {
      FUN_00ca1550();
      FUN_00ce6600();
    }
  }
  FUN_006e27a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22667 ; VA 0x00aec7c0 ; FUN_00aec7c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00aec7c0(int param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  int *piVar7;
  undefined *puStack_2c;
  int *piStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eba48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_00aec170(param_1);
  if (piVar3 != (int *)0x0) {
    puStack_2c = PTR_018bd540;
    piStack_28 = (int *)_UNK_018bd544;
    piStack_24 = (int *)_UNK_018bd548;
    uStack_20 = _UNK_018bd54c;
    uStack_8 = 0;
    puVar4 = (undefined4 *)FUN_0060e0c0(auStack_1c,param_1);
    puStack_2c = (undefined *)*puVar4;
    piVar7 = (int *)puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    piStack_28 = piVar7;
    puStack_14 = (undefined4 *)puStack_2c;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_18[2] + -1;
      piStack_18[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    puVar4 = *(undefined4 **)(param_3 + 4);
    piStack_24 = piVar3;
    if (*(undefined4 **)(param_3 + 8) == puVar4) {
      FUN_00ae6c50(puVar4,&puStack_2c);
      piVar7 = piStack_28;
    }
    else {
      *puVar4 = 0;
      puVar4[1] = 0;
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar7[2] = piVar7[2] + 1;
        UNLOCK();
      }
      *puVar4 = puStack_14;
      puVar4[1] = piVar7;
      puVar4[2] = piVar3;
      puVar4[3] = 0xffffffff;
      *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 0x10;
    }
    puStack_14 = (undefined4 *)(**(code **)(*piVar3 + 4))();
    puVar5 = (undefined4 *)(**(code **)(*piVar3 + 8))();
    puVar4 = puStack_14;
    if (0xf < (uint)puStack_14[5]) {
      puVar4 = (undefined4 *)*puStack_14;
    }
    cVar2 = FUN_0055c360(puVar4,puStack_14[4],"HumanoidRootPart",0x10);
    if (cVar2 != '\0') {
      puVar4 = puVar5 + 4;
      if (0xf < (uint)puVar5[5]) {
        puVar5 = (undefined4 *)*puVar5;
      }
      cVar2 = FUN_0055c360(puVar5,*puVar4,"LowerTorso",10);
      if (cVar2 != '\0') {
        FUN_0088ddf0(&puStack_2c);
      }
    }
    uStack_8 = 0xffffffff;
    if (piVar7 != (int *)0x0) {
      LOCK();
      iVar1 = piVar7[2] + -1;
      piVar7[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  puVar4 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar4 != (undefined4 *)0x0) {
    piVar3 = (int *)puVar4[1];
    for (piVar7 = (int *)*puVar4; piVar7 != piVar3; piVar7 = piVar7 + 2) {
      iVar1 = *(int *)(*piVar7 + 0xc);
      iVar6 = FUN_00b63e30();
      if ((uint)*(ushort *)(iVar6 + 0x1da) <
          (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) {
        FUN_00aec7c0(*piVar7,param_2,param_3);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22668 ; VA 0x00aec970 ; FUN_00aec970 */

void __thiscall FUN_00aec970(int param_1,undefined4 param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  code *pcStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d5500;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008a3ee0(param_2);
  *(undefined *)(param_1 + 0xe0) = 1;
  FUN_01679490();
  FUN_01679490();
  if (DAT_01d6699c == '\0') {
    if (*(int *)(param_1 + 0x34) == 0) {
      iVar3 = 0;
    }
    else {
      iVar3 = *(int *)(*(int *)(param_1 + 0x34) + 0x34);
    }
  }
  else {
    iVar3 = FUN_00aec0c0(param_1);
  }
  if (iVar3 != 0) {
    FUN_008a40f0();
    FUN_008a4100();
    pcStack_28 = FUN_0095c5f0;
    uStack_24 = 0;
    iStack_20 = param_1;
    uVar4 = FUN_00ae7790(&iStack_14,&pcStack_28);
    uStack_8 = 0;
    cVar2 = FUN_01679300(uVar4);
    if (cVar2 != '\0') {
      FUN_01679490();
      FUN_016791c0(uVar4);
    }
    uStack_8 = 0xffffffff;
    if (iStack_14 != 0) {
      piVar1 = (int *)(iStack_14 + 4);
      LOCK();
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        FUN_01674ea0(iStack_14);
      }
    }
    FUN_008a40f0();
    FUN_008a4100();
    pcStack_28 = FUN_0095c5f0;
    uStack_24 = 0;
    iStack_20 = param_1;
    uVar4 = FUN_00ae7790(&iStack_18,&pcStack_28);
    uStack_8 = 1;
    cVar2 = FUN_01679300(uVar4);
    if (cVar2 != '\0') {
      FUN_01679490();
      FUN_016791c0(uVar4);
    }
    uStack_8 = 0xffffffff;
    if (iStack_18 != 0) {
      piVar1 = (int *)(iStack_18 + 4);
      LOCK();
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        FUN_01674ea0(iStack_18);
      }
    }
  }
  if (DAT_01d6fc20 != '\0') {
    iVar3 = FUN_00a9d0e0(param_1);
    if (iVar3 != 0) {
      iVar3 = FUN_0063f220(iVar3);
      if ((iVar3 != 0) && (*(int *)(iVar3 + 0xbc) != 0)) {
        if ((*(int *)(param_1 + 0x100) != 0) &&
           (*(int *)(param_1 + 0x100) != *(int *)(iVar3 + 0xbc))) {
          FUN_00f946e0(param_1);
        }
        FUN_00f94530(param_1);
        ExceptionList = pvStack_10;
        return;
      }
    }
    if (*(int *)(param_1 + 0x100) != 0) {
      FUN_00f946e0(param_1);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22669 ; VA 0x00aecb80 ; FUN_00aecb80 */

void __thiscall FUN_00aecb80(int param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  int iVar4;
  undefined4 ****ppppuVar5;
  uint in_stack_00000018;
  char cStack0000001c;
  undefined4 in_stack_00000020;
  undefined4 ****in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  uint in_stack_00000030;
  undefined4 *apuStack_60 [6];
  undefined4 uStack_48;
  undefined4 ***pppuStack_44;
  undefined4 ***pppuStack_40;
  undefined4 ***apppuStack_30 [5];
  uint uStack_1c;
  undefined4 **ppuStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017eba90;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if ((in_stack_00000030 & 4) != 0) {
    pppuStack_40 = (undefined4 ***)&param_2;
    pppuStack_44 = (undefined4 ***)0xaecbc1;
    ExceptionList = &pvStack_10;
    FUN_0054ef60();
    pppuStack_40 = apppuStack_30;
    uStack_8._0_1_ = 1;
    pppuStack_44 = &ppuStack_18;
    uStack_48 = 0xaecbd8;
    FUN_00aebe90();
    if ((undefined4 ***)ppuStack_18 != *(undefined4 ****)(param_1 + 0x88)) {
      pppuStack_40 = (undefined4 ***)in_stack_00000028;
      pppuStack_44 = (undefined4 ****)0xaecbf3;
      cVar3 = FUN_00c94370();
      if (cVar3 != '\0') {
        uStack_8 = (uint)uStack_8._1_3_ << 8;
        pppuStack_40 = (undefined4 ***)0xaecc06;
        FUN_005507b0();
        goto LAB_00aecc56;
      }
      pppuStack_40 = (undefined4 ***)in_stack_00000028;
      pppuStack_44 = (undefined4 ****)0xaecc1b;
      FUN_00e66c60();
    }
    uStack_8 = (uint)uStack_8._1_3_ << 8;
    if (0xf < uStack_1c) {
      pppuStack_40 = (undefined4 ***)(uStack_1c + 1);
      ppppuVar5 = (undefined4 ****)apppuStack_30[0];
      if (0xfff < pppuStack_40) {
        ppppuVar5 = (undefined4 ****)apppuStack_30[0][-1];
        pppuStack_40 = (undefined4 ***)(uStack_1c + 0x24);
        if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar5))) {
LAB_00aecfca:
                    /* WARNING: Subroutine does not return */
          pppuStack_40 = (undefined4 ***)0xaecfcf;
          FUN_017167a3();
        }
      }
      uStack_48 = 0xaecc50;
      pppuStack_44 = ppppuVar5;
      FUN_01674ea0();
    }
  }
LAB_00aecc56:
  if ((in_stack_00000030 & 2) != 0) {
    pppuStack_40 = (undefined4 ***)&param_2;
    pppuStack_44 = (undefined4 ***)0xaecc6a;
    FUN_0054ef60();
    pppuStack_40 = apppuStack_30;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    pppuStack_44 = &ppuStack_18;
    uStack_48 = 0xaecc81;
    FUN_00aebe90();
    if ((undefined4 ***)ppuStack_18 == *(undefined4 ****)(param_1 + 0x88)) {
LAB_00aeccda:
      uStack_8 = uStack_8 & 0xffffff00;
      if (0xf < uStack_1c) {
        pppuStack_40 = (undefined4 ***)(uStack_1c + 1);
        ppppuVar5 = (undefined4 ****)apppuStack_30[0];
        if (0xfff < pppuStack_40) {
          ppppuVar5 = (undefined4 ****)apppuStack_30[0][-1];
          pppuStack_40 = (undefined4 ***)(uStack_1c + 0x24);
          if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
            pppuStack_40 = (undefined4 ***)0xaecfd4;
            FUN_017167a3();
          }
        }
        uStack_48 = 0xaecd1f;
        pppuStack_44 = ppppuVar5;
        FUN_01674ea0();
      }
    }
    else {
      pppuStack_40 = in_stack_00000024;
      pppuStack_44 = (undefined4 ****)0xaecc9c;
      cVar3 = FUN_00c94370();
      if (cVar3 == '\0') {
        pppuStack_40 = (undefined4 ***)in_stack_00000020;
        pppuStack_44 = (undefined4 ****)0xaeccb3;
        cVar3 = FUN_00c94370();
        if (cVar3 == '\0') {
          pppuStack_40 = (undefined4 ***)in_stack_00000020;
          pppuStack_44 = in_stack_00000024;
          uStack_48 = 0xaeccda;
          FUN_00e66c80();
          goto LAB_00aeccda;
        }
      }
      uStack_8 = uStack_8 & 0xffffff00;
      pppuStack_40 = (undefined4 ***)0xaecd16;
      FUN_005507b0();
    }
  }
  if ((in_stack_00000030 & 1) != 0) {
    if (cStack0000001c == '\x01') {
      _cStack0000001c = (undefined4 ***)apuStack_60;
      pppuStack_40 = (undefined4 ***)in_stack_00000028;
      pppuStack_44 = in_stack_00000024;
      uStack_48 = in_stack_00000020;
      FUN_0054ef60(&param_2);
      FUN_00aecff0();
    }
    else {
      puVar1 = *(undefined4 **)(param_1 + 0xec);
      for (puVar2 = (undefined4 *)*puVar1; puVar2 != puVar1; puVar2 = (undefined4 *)*puVar2) {
        pppuStack_40 = (undefined4 ***)0xaecd88;
        iVar4 = FUN_00e66450();
        pppuStack_40 = (undefined4 ***)(iVar4 + 0x54);
        pppuStack_44 = (undefined4 ***)0xaecd94;
        FUN_0054ef60();
        pppuStack_40 = (undefined4 ***)&param_2;
        uStack_8._0_1_ = 3;
        pppuStack_44 = apppuStack_30;
        uStack_48 = 0xaecda5;
        cVar3 = FUN_009cbaa0();
        uStack_8 = (uint)uStack_8._1_3_ << 8;
        if (0xf < uStack_1c) {
          pppuStack_40 = (undefined4 ***)(uStack_1c + 1);
          ppppuVar5 = (undefined4 ****)apppuStack_30[0];
          if (0xfff < pppuStack_40) {
            ppppuVar5 = (undefined4 ****)apppuStack_30[0][-1];
            pppuStack_40 = (undefined4 ***)(uStack_1c + 0x24);
            if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar5))) goto LAB_00aecfca;
          }
          uStack_48 = 0xaecddf;
          pppuStack_44 = ppppuVar5;
          FUN_01674ea0();
        }
        param_1 = iStack_14;
        if (cVar3 != '\0') goto LAB_00aece2a;
      }
      _cStack0000001c = (undefined4 ***)apuStack_60;
      uStack_48 = 0x3dcccccd;
      pppuStack_44 = in_stack_00000024;
      pppuStack_40 = (undefined4 ***)in_stack_00000028;
      FUN_0054ef60(&param_2);
      FUN_00aecff0();
LAB_00aece2a:
      pppuStack_40 = (undefined4 ***)&param_2;
      pppuStack_44 = (undefined4 ***)0xaece36;
      FUN_0054ef60();
      pppuStack_40 = apppuStack_30;
      uStack_8._0_1_ = 4;
      pppuStack_44 = (undefined4 ***)&stack0x0000001c;
      uStack_48 = 0xaece4d;
      FUN_00aebe90();
      if (_cStack0000001c == *(undefined4 ****)(param_1 + 0x88)) {
LAB_00aeceb2:
        uStack_8 = (uint)uStack_8._1_3_ << 8;
        if (uStack_1c < 0x10) goto LAB_00aeceed;
        pppuStack_40 = (undefined4 ***)(uStack_1c + 1);
        ppppuVar5 = (undefined4 ****)apppuStack_30[0];
        if (0xfff < pppuStack_40) {
          ppppuVar5 = (undefined4 ****)apppuStack_30[0][-1];
          pppuStack_40 = (undefined4 ***)(uStack_1c + 0x24);
          if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
            pppuStack_40 = (undefined4 ***)0xaecfde;
            FUN_017167a3();
          }
        }
      }
      else {
        pppuStack_40 = (undefined4 ***)in_stack_00000020;
        pppuStack_44 = (undefined4 ****)0xaece68;
        cVar3 = FUN_00c94370();
        if (cVar3 == '\0') {
          pppuStack_40 = (undefined4 ***)in_stack_00000020;
          pppuStack_44 = (undefined4 ****)0xaeceb2;
          FUN_00e66df0();
          goto LAB_00aeceb2;
        }
        uStack_8 = (uint)uStack_8._1_3_ << 8;
        if (uStack_1c < 0x10) goto LAB_00aeceed;
        pppuStack_40 = (undefined4 ***)(uStack_1c + 1);
        ppppuVar5 = (undefined4 ****)apppuStack_30[0];
        if (0xfff < pppuStack_40) {
          ppppuVar5 = (undefined4 ****)apppuStack_30[0][-1];
          pppuStack_40 = (undefined4 ***)(uStack_1c + 0x24);
          if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
            pppuStack_40 = (undefined4 ***)0xaecfd9;
            FUN_017167a3();
          }
        }
      }
      uStack_48 = 0xaecee7;
      pppuStack_44 = ppppuVar5;
      FUN_01674ea0();
    }
  }
LAB_00aeceed:
  if ((in_stack_00000030 & 8) != 0) {
    pppuStack_40 = (undefined4 ***)&param_2;
    pppuStack_44 = (undefined4 ***)0xaecf01;
    FUN_0054ef60();
    pppuStack_40 = apppuStack_30;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pppuStack_44 = (undefined4 ***)&stack0x0000001c;
    uStack_48 = 0xaecf18;
    FUN_00aebe90();
    if (_cStack0000001c != *(undefined4 ****)(param_1 + 0x88)) {
      pppuStack_40 = (undefined4 ***)in_stack_0000002c;
      pppuStack_44 = (undefined4 ****)0xaecf33;
      cVar3 = FUN_00c94370();
      if (cVar3 != '\0') {
        pppuStack_40 = (undefined4 ***)0xaecf42;
        FUN_005507b0();
        goto LAB_00aecf87;
      }
      pppuStack_40 = (undefined4 ***)in_stack_0000002c;
      pppuStack_44 = (undefined4 ****)0xaecf57;
      FUN_00e66dc0();
    }
    if (0xf < uStack_1c) {
      pppuStack_40 = (undefined4 ***)(uStack_1c + 1);
      ppppuVar5 = (undefined4 ****)apppuStack_30[0];
      if (0xfff < pppuStack_40) {
        ppppuVar5 = (undefined4 ****)apppuStack_30[0][-1];
        pppuStack_40 = (undefined4 ***)(uStack_1c + 0x24);
        if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
          pppuStack_40 = (undefined4 ***)0xaecfe3;
          FUN_017167a3();
        }
      }
      uStack_48 = 0xaecf84;
      pppuStack_44 = ppppuVar5;
      FUN_01674ea0();
    }
  }
LAB_00aecf87:
  if (0xf < in_stack_00000018) {
    pppuStack_40 = (undefined4 ***)(in_stack_00000018 + 1);
    iVar4 = param_2;
    if (0xfff < pppuStack_40) {
      iVar4 = *(int *)(param_2 + -4);
      pppuStack_40 = (undefined4 ***)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        pppuStack_40 = (undefined4 ***)&UNK_00aecfe8;
        FUN_017167a3();
      }
    }
    uStack_48 = 0xaecfb4;
    pppuStack_44 = (undefined4 ***)iVar4;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22670 ; VA 0x00aecff0 ; FUN_00aecff0 */

void __thiscall FUN_00aecff0(int param_1,int param_2)

{
  char cVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  int in_stack_00000020;
  int in_stack_00000024;
  int aiStack_48 [2];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int **ppiStack_38;
  int *piStack_34;
  int *piStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ebab8;
  pvStack_10 = ExceptionList;
  piStack_34 = (int *)DAT_01f127c8;
  uStack_8 = 0;
  ppiStack_38 = (int **)0xaed025;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar2 = FUN_01675290();
  piStack_34 = &param_2;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  piStack_18 = (int *)(param_1 + 0x88);
  ppiStack_38 = &piStack_1c;
  uStack_3c = 0xaed049;
  FUN_00aebe90();
  piVar3 = piStack_1c;
  if (piStack_1c == *(int **)(param_1 + 0x88)) {
    piStack_34 = (int *)0x3f800000;
    ppiStack_38 = (int **)0xaed068;
    cVar1 = FUN_0091e990();
    if (cVar1 != '\0') {
      piStack_1c = aiStack_48;
      FUN_0054ef60(&param_2);
      FUN_00aed6c0();
      piStack_34 = &param_2;
      ppiStack_38 = &piStack_1c;
      uStack_3c = 0xaed0ad;
      piVar3 = (int *)FUN_00aebe90();
      piVar3 = (int *)*piVar3;
      if (piVar3 != (int *)*piStack_18) goto LAB_00aed0ba;
LAB_00aed141:
      piVar6 = (int *)piVar3[0xb];
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
        piVar6 = (int *)piVar3[0xb];
      }
      in_stack_00000020 = piVar3[10];
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
      }
      uStack_3c = 0xaed18e;
      ppiStack_38 = (int **)in_stack_00000020;
      piStack_34 = piVar6;
      piStack_1c = piVar6;
      FUN_0089be10();
      in_stack_00000024 = *(int *)(iStack_14 + 0x34);
      if (in_stack_00000024 != 0) {
        iVar5 = *(int *)(in_stack_00000024 + 0xc);
        piStack_34 = (int *)0xaed1a7;
        iVar4 = FUN_00e63c60();
        if ((uint)*(ushort *)(iVar4 + 0x1da) <
            (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) {
          iVar5 = *(int *)(in_stack_00000024 + 0xc);
          piStack_34 = (int *)0xaed1d5;
          iVar4 = FUN_0099be20();
          if ((uint)*(ushort *)(iVar4 + 0x1da) <
              (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))
          goto LAB_00aed222;
        }
        if (piVar6 != (int *)0x0) {
          LOCK();
          piVar6[1] = piVar6[1] + 1;
          UNLOCK();
        }
        ppiStack_38 = (int **)in_stack_00000020;
        uStack_3c = 0xaed222;
        piStack_34 = piVar6;
        FUN_0089be10();
      }
LAB_00aed222:
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar5 = piVar6[1] + -1;
        piVar6[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          piStack_34 = (int *)0xaed23a;
          (**(code **)*piVar6)();
          LOCK();
          piVar3 = piVar6 + 2;
          iVar5 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar5 == 1) {
            piStack_34 = (int *)0xaed249;
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      goto LAB_00aed24d;
    }
LAB_00aed06d:
    piStack_34 = (int *)0x3f800000;
    ppiStack_38 = (int **)0xaed07b;
    FUN_0091e990();
  }
  else {
LAB_00aed0ba:
    piStack_34 = (int *)0x0;
    ppiStack_38 = (int **)0xaed0c9;
    cVar1 = FUN_0091e990();
    if (cVar1 == '\0') goto LAB_00aed06d;
    piStack_34 = (int *)in_stack_0000001c;
    ppiStack_38 = (int **)0xaed0dd;
    cVar1 = FUN_00c94370();
    if (cVar1 == '\0') {
      piStack_34 = (int *)in_stack_00000020;
      ppiStack_38 = (int **)0xaed0f4;
      cVar1 = FUN_00c94370();
      if (cVar1 == '\0') {
        piStack_34 = (int *)in_stack_00000024;
        ppiStack_38 = (int **)0xaed10b;
        cVar1 = FUN_00c94370();
        if (cVar1 == '\0') {
          piStack_34 = (int *)in_stack_00000024;
          ppiStack_38 = (int **)in_stack_00000020;
          uStack_3c = in_stack_0000001c;
          uStack_40 = 0xaed141;
          FUN_00e66cb0();
          goto LAB_00aed141;
        }
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
LAB_00aed24d:
  ppiStack_38 = (int **)0xaed253;
  piStack_34 = (int *)uVar2;
  FUN_01675290();
  if (0xf < in_stack_00000018) {
    piStack_34 = (int *)(in_stack_00000018 + 1);
    iVar5 = param_2;
    if (0xfff < piStack_34) {
      iVar5 = *(int *)(param_2 + -4);
      piStack_34 = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_34 = (int *)&UNK_00aed29e;
        FUN_017167a3();
      }
    }
    uStack_3c = 0xaed283;
    ppiStack_38 = (int **)iVar5;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22671 ; VA 0x00aed2a0 ; FUN_00aed2a0 */

undefined4 * __thiscall FUN_00aed2a0(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  bool bVar6;
  bool bVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d8fe0;
  pvStack_10 = ExceptionList;
  iStack_18 = param_1;
  iStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    iVar3 = *(int *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar8 = FUN_00913630();
    if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8) <=
        (uint)*(ushort *)(iVar8 + 0x1da)) {
      iStack_14 = param_2;
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      bVar7 = true;
      bVar6 = false;
      piStack_24 = param_3;
      puVar9 = &uStack_28;
      goto LAB_00aed32e;
    }
  }
  piStack_1c = (int *)0x0;
  puVar9 = &uStack_20;
  iStack_14 = 0;
  bVar7 = false;
  bVar6 = true;
LAB_00aed32e:
  piVar4 = (int *)puVar9[1];
  *puVar9 = 0;
  puVar9[1] = 0;
  if (bVar6) {
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_1c + 1;
      iVar3 = *piVar1;
      puVar9 = (undefined4 *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piStack_1c + 2;
        iVar3 = *piVar1;
        puVar9 = (undefined4 *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          puVar9 = (undefined4 *)(**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  piVar1 = piStack_24;
  if ((bVar7) && (piStack_24 != (int *)0x0)) {
    LOCK();
    piVar2 = piStack_24 + 1;
    iVar3 = *piVar2;
    puVar9 = (undefined4 *)*piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      puVar9 = (undefined4 *)*piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        puVar9 = (undefined4 *)(**(code **)(*piVar1 + 4))();
      }
    }
  }
  iVar3 = iStack_18;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_14 != 0) {
    puVar9 = (undefined4 *)FUN_00927d30(&iStack_18);
    puVar5 = *(undefined4 **)(iVar3 + 100);
    if (*(undefined4 **)(iVar3 + 0x68) == puVar5) {
      puVar9 = (undefined4 *)FUN_00ae6e00(puVar5,puVar9);
    }
    else {
      puVar9 = (undefined4 *)*puVar9;
      *puVar5 = puVar9;
      *(int *)(iVar3 + 100) = *(int *)(iVar3 + 100) + 4;
    }
  }
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 1;
    iVar3 = *piVar1;
    puVar9 = (undefined4 *)*piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      puVar9 = (undefined4 *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        puVar9 = (undefined4 *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar4 = param_3 + 1;
    iVar3 = *piVar4;
    puVar9 = (undefined4 *)*piVar4;
    *piVar4 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      puVar9 = (undefined4 *)(**(code **)*param_3)();
      LOCK();
      piVar4 = param_3 + 2;
      iVar3 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        puVar9 = (undefined4 *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar9;
}



/* FUNCTION 22672 ; VA 0x00aed430 ; FUN_00aed430 */

void __thiscall FUN_00aed430(int param_1,int *param_2,int param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined4 uStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  uVar4 = param_3;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ebaf1;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_008a4210(param_2,param_3);
  if (DAT_01d6fc20 == '\0') {
    FUN_00f958f0(param_2,uVar4);
  }
  else {
    FUN_01679490();
  }
  if (param_1 != 0) {
    param_2 = *(int **)(param_1 + 0x34);
    iVar2 = param_1;
    if ((param_2 != (int *)0x0) && (iVar2 = (int)param_2, *(int *)((int)param_2 + 0x34) != 0)) {
      iVar2 = FUN_005c8ac0();
    }
    param_2 = (int *)iVar2;
    if ((param_2 != (int *)0x0) &&
       (iVar2 = *(int *)((int)param_2 + 0xc), iVar3 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
       (uint)*(ushort *)(iVar3 + 0x1da))) {
      FUN_005789c0(&DAT_01ea8a70,&LAB_0055d570);
      uVar4 = FUN_00560c40();
      param_2 = (int *)FUN_008aa140(uVar4);
      if (*param_2 == 0) {
        uVar4 = FUN_00961660();
        piVar5 = (int *)FUN_008a9ba0(auStack_28,uVar4);
        iVar2 = *piVar5;
        iVar3 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *param_2 = iVar2;
        piVar5 = (int *)param_2[1];
        param_2[1] = iVar3;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar2 = piVar5[1] + -1;
          piVar5[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar2 = piVar5[2] + -1;
            piVar5[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_24 != (int *)0x0) {
          LOCK();
          iVar2 = piStack_24[1] + -1;
          piStack_24[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            iVar2 = piStack_24[2] + -1;
            piStack_24[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piStack_24 + 4))();
            }
          }
        }
      }
      iVar2 = *param_2;
      if ((iVar2 != 0) && (cVar1 = FUN_0098c5a0(param_1,1), cVar1 != '\0')) {
        param_3 = iVar2 + 0x2a4;
        iStack_8 = 0;
        uVar4 = FUN_01675290(DAT_02110da8);
        iStack_8._0_1_ = 1;
        uStack_1c = uVar4;
        puStack_20 = (undefined4 *)FUN_01674e20(0x28);
        if (puStack_20 == (undefined4 *)0x0) {
          puVar6 = (undefined4 *)0x0;
        }
        else {
          *puStack_20 = 0;
          puStack_20[1] = 1;
          puStack_20[2] = FUN_00923570;
          puStack_20[3] = _guard_check_icall;
          puStack_20[4] = 0;
          puStack_20[5] = param_3;
          puStack_20[6] = FUN_00aed2a0;
          puStack_20[7] = 0;
          puStack_20[8] = param_1;
          puStack_20[9] = uStack_2c;
          puVar6 = puStack_20;
        }
        FUN_016797d0(puVar6);
        if (puVar6 != (undefined4 *)0x0) {
          LOCK();
          puVar6[1] = puVar6[1] + 1;
          UNLOCK();
        }
        uStack_14 = 1;
        iStack_8._0_1_ = 2;
        param_2 = puVar6;
        FUN_01675290(uVar4);
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        cVar1 = FUN_01679300(&param_2);
        if (cVar1 != '\0') {
          FUN_01679490();
          FUN_016791c0(&param_2);
        }
        if (param_2 != (undefined4 *)0x0) {
          piVar5 = param_2 + 1;
          LOCK();
          iVar2 = *piVar5;
          *piVar5 = *piVar5 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            FUN_01674ea0(param_2);
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22673 ; VA 0x00aed6b0 ; FUN_00aed6b0 */

void FUN_00aed6b0(void)

{
  FUN_00ae8e70();
  return;
}



/* FUNCTION 22674 ; VA 0x00aed6c0 ; FUN_00aed6c0 */

undefined4 * __thiscall FUN_00aed6c0(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  bool bVar4;
  bool bVar5;
  undefined *puVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined **ppuVar9;
  int iVar10;
  uint in_stack_00000018;
  undefined auStack_84 [4];
  undefined4 uStack_80;
  undefined4 *puStack_7c;
  undefined **ppuStack_78;
  undefined **ppuStack_74;
  undefined ***pppuStack_70;
  undefined **appuStack_60 [5];
  uint uStack_4c;
  undefined *puStack_48;
  int *piStack_44;
  undefined *puStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined **ppuStack_28;
  int *piStack_24;
  undefined *puStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017ebb28;
  pvStack_10 = ExceptionList;
  pppuStack_70 = (undefined ***)&param_2;
  uStack_8 = 0;
  uStack_7 = 0;
  ppuStack_74 = &puStack_14;
  ppuStack_78 = (undefined **)0xaed706;
  ExceptionList = &pvStack_10;
  puStack_18 = (undefined4 *)(param_1 + 0x88);
  puVar7 = (undefined4 *)FUN_00aebe90();
  puVar7 = (undefined4 *)*puVar7;
  if (puVar7 != *(undefined4 **)(param_1 + 0x88)) goto LAB_00aed953;
  pppuStack_70 = &ppuStack_28;
  ppuStack_74 = (undefined **)0xaed719;
  FUN_00ae7850();
  puStack_14 = auStack_84;
  uStack_8 = 1;
  FUN_0054ef60(&param_2);
  FUN_00e63b20();
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piStack_24[1] = piStack_24[1] + 1;
    UNLOCK();
  }
  ppuStack_74 = ppuStack_28;
  pppuStack_70 = (undefined ***)piStack_24;
  ppuStack_78 = &puStack_20;
  puStack_7c = (undefined4 *)0xaed76b;
  FUN_00aec240();
  _uStack_8 = CONCAT31(uStack_7,2);
  if (puStack_20 == (undefined *)0x0) {
LAB_00aed7ba:
    piStack_2c = (int *)0x0;
    puVar7 = &uStack_30;
    puStack_14 = (undefined *)0x0;
    bVar5 = false;
    bVar4 = true;
  }
  else {
    iVar10 = *(int *)(puStack_20 + 0xc);
    pppuStack_70 = (undefined ***)0xaed77e;
    iVar8 = FUN_00e643e0();
    if ((uint)*(ushort *)(iVar8 + 0x1da) <
        (uint)*(ushort *)(iVar10 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8)) goto LAB_00aed7ba;
    puStack_14 = puStack_20;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    bVar5 = true;
    bVar4 = false;
    piStack_34 = piStack_1c;
    puVar7 = &uStack_38;
  }
  piVar3 = (int *)puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  puStack_40 = puStack_14;
  piStack_3c = piVar3;
  if (bVar4) {
    if (piStack_2c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_2c + 1;
      iVar10 = *piVar1;
      puVar7 = (undefined4 *)*piVar1;
      *piVar1 = iVar10 + -1;
      UNLOCK();
      if (iVar10 + -1 == 0) {
        pppuStack_70 = (undefined ***)0xaed803;
        (**(code **)*piStack_2c)();
        LOCK();
        piVar1 = piStack_2c + 2;
        iVar10 = *piVar1;
        puVar7 = (undefined4 *)*piVar1;
        *piVar1 = iVar10 + -1;
        UNLOCK();
        if (iVar10 + -1 == 0) {
          pppuStack_70 = (undefined ***)0xaed814;
          puVar7 = (undefined4 *)(**(code **)(*piStack_2c + 4))();
        }
      }
    }
  }
  piVar1 = piStack_34;
  if ((bVar5) && (piStack_34 != (int *)0x0)) {
    LOCK();
    piVar2 = piStack_34 + 1;
    iVar10 = *piVar2;
    puVar7 = (undefined4 *)*piVar2;
    *piVar2 = iVar10 + -1;
    UNLOCK();
    if (iVar10 + -1 == 0) {
      pppuStack_70 = (undefined ***)0xaed82f;
      (**(code **)*piStack_34)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar10 = *piVar2;
      puVar7 = (undefined4 *)*piVar2;
      *piVar2 = iVar10 + -1;
      UNLOCK();
      if (iVar10 + -1 == 0) {
        pppuStack_70 = (undefined ***)0xaed83f;
        puVar7 = (undefined4 *)(**(code **)(*piVar1 + 4))();
      }
    }
  }
  puVar6 = puStack_14;
  uStack_8 = 3;
  if (puStack_14 != (undefined *)0x0) {
    pppuStack_70 = (undefined ***)&param_2;
    ppuStack_74 = (undefined **)0xaed85a;
    FUN_0054ef60();
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar3[1] = piVar3[1] + 1;
      UNLOCK();
    }
    puStack_48 = puVar6;
    pppuStack_70 = appuStack_60;
    uStack_8 = 4;
    ppuStack_74 = (undefined **)0xaed878;
    piStack_44 = piVar3;
    pppuStack_70 = (undefined ***)FUN_008dd0c0();
    ppuStack_74 = (undefined **)((int)pppuStack_70 + 0x10);
    ppuStack_78 = (undefined **)0x0;
    puStack_7c = &uStack_38;
    uStack_80 = 0xaed88b;
    puVar7 = (undefined4 *)FUN_00ae6fc0();
    piVar1 = piStack_44;
    if (piStack_44 != (int *)0x0) {
      LOCK();
      piVar2 = piStack_44 + 1;
      iVar10 = *piVar2;
      puVar7 = (undefined4 *)*piVar2;
      *piVar2 = iVar10 + -1;
      UNLOCK();
      if (iVar10 + -1 == 0) {
        pppuStack_70 = (undefined ***)0xaed8a1;
        (**(code **)*piStack_44)();
        LOCK();
        piVar2 = piVar1 + 2;
        iVar10 = *piVar2;
        puVar7 = (undefined4 *)*piVar2;
        *piVar2 = iVar10 + -1;
        UNLOCK();
        if (iVar10 + -1 == 0) {
          pppuStack_70 = (undefined ***)0xaed8b1;
          puVar7 = (undefined4 *)(**(code **)(*piVar1 + 4))();
        }
      }
    }
    if (0xf < uStack_4c) {
      pppuStack_70 = (undefined ***)(uStack_4c + 1);
      ppuVar9 = appuStack_60[0];
      if (0xfff < pppuStack_70) {
        ppuVar9 = (undefined **)appuStack_60[0][-1];
        pppuStack_70 = (undefined ***)(uStack_4c + 0x24);
        if (0x1f < (uint)((int)appuStack_60[0] + (-4 - (int)ppuVar9))) {
                    /* WARNING: Subroutine does not return */
          pppuStack_70 = (undefined ***)0xaed99b;
          FUN_017167a3();
        }
      }
      ppuStack_78 = (undefined **)0xaed8e2;
      ppuStack_74 = ppuVar9;
      puVar7 = (undefined4 *)FUN_01674ea0();
    }
  }
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar10 = *piVar1;
    puVar7 = (undefined4 *)*piVar1;
    *piVar1 = iVar10 + -1;
    UNLOCK();
    if (iVar10 + -1 == 0) {
      pppuStack_70 = (undefined ***)0xaed8f8;
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar10 = *piVar1;
      puVar7 = (undefined4 *)*piVar1;
      *piVar1 = iVar10 + -1;
      UNLOCK();
      if (iVar10 + -1 == 0) {
        pppuStack_70 = (undefined ***)0xaed908;
        puVar7 = (undefined4 *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar3 = piStack_1c + 1;
    iVar10 = *piVar3;
    puVar7 = (undefined4 *)*piVar3;
    *piVar3 = iVar10 + -1;
    UNLOCK();
    if (iVar10 + -1 == 0) {
      pppuStack_70 = (undefined ***)0xaed91e;
      (**(code **)*piStack_1c)();
      LOCK();
      piVar3 = piStack_1c + 2;
      iVar10 = *piVar3;
      puVar7 = (undefined4 *)*piVar3;
      *piVar3 = iVar10 + -1;
      UNLOCK();
      if (iVar10 + -1 == 0) {
        pppuStack_70 = (undefined ***)0xaed92e;
        puVar7 = (undefined4 *)(**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_24 + 1;
    iVar10 = *piVar3;
    puVar7 = (undefined4 *)*piVar3;
    *piVar3 = iVar10 + -1;
    UNLOCK();
    if (iVar10 + -1 == 0) {
      pppuStack_70 = (undefined ***)0xaed944;
      puVar7 = (undefined4 *)(**(code **)*piStack_24)();
      LOCK();
      piVar3 = piStack_24 + 2;
      iVar10 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar10 == 1) {
        pppuStack_70 = (undefined ***)0xaed953;
        puVar7 = (undefined4 *)(**(code **)(*piStack_24 + 4))();
      }
    }
  }
LAB_00aed953:
  if (0xf < in_stack_00000018) {
    pppuStack_70 = (undefined ***)(in_stack_00000018 + 1);
    iVar10 = param_2;
    if (0xfff < pppuStack_70) {
      iVar10 = *(int *)(param_2 + -4);
      pppuStack_70 = (undefined ***)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - iVar10) - 4U) {
                    /* WARNING: Subroutine does not return */
        pppuStack_70 = (undefined ***)&UNK_00aed9a0;
        FUN_017167a3();
      }
    }
    ppuStack_78 = (undefined **)0xaed980;
    ppuStack_74 = (undefined **)iVar10;
    puVar7 = (undefined4 *)FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return puVar7;
}



/* FUNCTION 22675 ; VA 0x00aed9b0 ; FUN_00aed9b0 */

void __thiscall FUN_00aed9b0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  
  puVar2 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar2) {
    *puVar2 = 0;
    puVar2[1] = 0;
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    *puVar2 = *param_2;
    puVar2[1] = param_2[1];
    puVar2[2] = param_2[2];
    puVar2[3] = param_2[3];
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x10;
    return;
  }
  FUN_00ae6c50(puVar2,param_2);
  return;
}



/* FUNCTION 22676 ; VA 0x00aeda10 ; FUN_00aeda10 */

void __thiscall FUN_00aeda10(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  int aiStack_78 [5];
  uint uStack_64;
  int aiStack_60 [5];
  uint uStack_4c;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = -1;
  puStack_c = &LAB_017ebb60;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)(param_1 + 0xa4);
  ExceptionList = &pvStack_10;
  if ((uint)((*(int *)(param_1 + 0xa8) - *piVar1) / 0xc) < param_2 + 1U) {
    ExceptionList = &pvStack_10;
    FUN_00ae7440(param_2 + 1U,piVar1);
  }
  iVar4 = param_2;
  if (param_2 != 0) {
    do {
      iVar4 = iVar4 + -1;
    } while (iVar4 != 0);
  }
  iVar4 = FUN_0074a340();
  piVar1 = (int *)(*piVar1 + param_2 * 0xc);
  if (*(char *)(iVar4 + 0x69) == '\0') {
    iStack_14 = FUN_00dcba30();
    iVar7 = *(int *)(iStack_14 + 0x30) - *(int *)(iStack_14 + 0x2c);
    iVar4 = iVar7 >> 0x1f;
    if (iVar7 / 0x34 + iVar4 != iVar4) {
      FUN_006b9410(*(int *)(param_1 + 0x9c) - *(int *)(param_1 + 0x98) >> 4,piVar1);
      uVar8 = 0;
      iVar4 = *(int *)(param_1 + 0x98);
      if (*(int *)(param_1 + 0x9c) - iVar4 >> 4 != 0) {
        iVar7 = 0;
        do {
          iVar2 = *(int *)(iVar7 + 4 + iVar4);
          if ((iVar2 == 0) || (*(int *)(iVar2 + 4) == 0)) {
            *(undefined4 *)(*piVar1 + uVar8 * 4) = 0xffffffff;
          }
          else {
            uVar3 = (**(code **)(**(int **)(iVar7 + 8 + iVar4) + 4))();
            FUN_0054ef60(uVar3);
            iStack_8 = 2;
            uVar3 = (**(code **)(**(int **)(iVar7 + 8 + *(int *)(param_1 + 0x98)) + 8))();
            FUN_0054ef60(uVar3);
            iStack_8._0_1_ = 3;
            uVar3 = FUN_00dcb670(aiStack_78,auStack_48,0xffffffff);
            iStack_8 = CONCAT31(iStack_8._1_3_,2);
            *(undefined4 *)(*piVar1 + uVar8 * 4) = uVar3;
            if (0xf < uStack_34) {
              uVar5 = uStack_34 + 1;
              uVar6 = auStack_48[0];
              if (0xfff < uVar5) {
                uVar6 = *(uint *)(auStack_48[0] - 4);
                uVar5 = uStack_34 + 0x24;
                if (0x1f < (auStack_48[0] - uVar6) - 4) goto LAB_00aedd94;
              }
              FUN_01674ea0(uVar6,uVar5);
            }
            uStack_38 = 0;
            uStack_34 = 0xf;
            auStack_48[0] = auStack_48[0] & 0xffffff00;
            iStack_8 = -1;
            if (0xf < uStack_64) {
              uVar6 = uStack_64 + 1;
              iVar4 = aiStack_78[0];
              if (0xfff < uVar6) {
                iVar4 = *(int *)(aiStack_78[0] + -4);
                uVar6 = uStack_64 + 0x24;
                if (0x1f < (aiStack_78[0] - iVar4) - 4U) goto LAB_00aedd94;
              }
              FUN_01674ea0(iVar4,uVar6);
            }
          }
          uVar8 = uVar8 + 1;
          iVar4 = *(int *)(param_1 + 0x98);
          iVar7 = iVar7 + 0x10;
        } while (uVar8 < (uint)(*(int *)(param_1 + 0x9c) - iVar4 >> 4));
      }
    }
  }
  else {
    iStack_14 = FUN_00819220();
    FUN_006b9410(*(int *)(param_1 + 0x9c) - *(int *)(param_1 + 0x98) >> 4,piVar1);
    uVar8 = 0;
    iVar4 = *(int *)(param_1 + 0x98);
    if (*(int *)(param_1 + 0x9c) - iVar4 >> 4 != 0) {
      iVar7 = 0;
      do {
        iVar2 = *(int *)(iVar7 + 4 + iVar4);
        if (((iVar2 == 0) || (*(int *)(iVar2 + 4) == 0)) ||
           ((uint)(*(int *)(iStack_14 + 0x1c) - *(int *)(iStack_14 + 0x18)) < 8)) {
          *(undefined4 *)(*piVar1 + uVar8 * 4) = 0xffffffff;
        }
        else {
          uVar3 = (**(code **)(**(int **)(iVar7 + 8 + iVar4) + 4))();
          FUN_0054ef60(uVar3);
          iStack_8 = 0;
          uVar3 = (**(code **)(**(int **)(iVar7 + 8 + *(int *)(param_1 + 0x98)) + 8))();
          FUN_0054ef60(uVar3);
          iStack_8._0_1_ = 1;
          uVar3 = FUN_00dcb7d0(aiStack_60,auStack_30);
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          *(undefined4 *)(*piVar1 + uVar8 * 4) = uVar3;
          if (0xf < uStack_1c) {
            uVar5 = uStack_1c + 1;
            uVar6 = auStack_30[0];
            if (0xfff < uVar5) {
              uVar6 = *(uint *)(auStack_30[0] - 4);
              uVar5 = uStack_1c + 0x24;
              if (0x1f < (auStack_30[0] - uVar6) - 4) {
LAB_00aedd94:
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(uVar6,uVar5);
          }
          uStack_20 = 0;
          uStack_1c = 0xf;
          auStack_30[0] = auStack_30[0] & 0xffffff00;
          iStack_8 = -1;
          if (0xf < uStack_4c) {
            uVar6 = uStack_4c + 1;
            iVar4 = aiStack_60[0];
            if (0xfff < uVar6) {
              iVar4 = *(int *)(aiStack_60[0] + -4);
              uVar6 = uStack_4c + 0x24;
              if (0x1f < (aiStack_60[0] - iVar4) - 4U) goto LAB_00aedd94;
            }
            FUN_01674ea0(iVar4,uVar6);
          }
        }
        uVar8 = uVar8 + 1;
        iVar4 = *(int *)(param_1 + 0x98);
        iVar7 = iVar7 + 0x10;
        if ((uint)(*(int *)(param_1 + 0x9c) - iVar4 >> 4) <= uVar8) {
          ExceptionList = pvStack_10;
          return;
        }
      } while( true );
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22677 ; VA 0x00aedda0 ; FUN_00aedda0 */

void __fastcall FUN_00aedda0(int param_1)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  
  piVar1 = (int *)(param_1 + 0xa4);
  FUN_00a1ba80(*piVar1,*(undefined4 *)(param_1 + 0xa8),piVar1);
  *(int *)(param_1 + 0xa8) = *piVar1;
  uVar2 = *(uint *)(param_1 + 0xf0);
  if ((uint)((*(int *)(param_1 + 0xac) - *piVar1) / 0xc) < uVar2) {
    if (0x15555555 < uVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_00ae8d40(uVar2);
    uVar2 = *(uint *)(param_1 + 0xf0);
  }
  uVar3 = 0;
  if (uVar2 != 0) {
    do {
      FUN_00aeda10(uVar3);
      uVar3 = uVar3 + 1;
    } while (uVar3 < *(uint *)(param_1 + 0xf0));
  }
  return;
}



/* FUNCTION 22678 ; VA 0x00aede20 ; FUN_00aede20 */

undefined4 * __thiscall FUN_00aede20(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ebb78;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (DAT_01d66968 < *(uint *)(param_1 + 0xf0)) {
    ExceptionList = &pvStack_10;
    puVar5 = (undefined4 *)
             FUN_0086f2f0(2,
                          "AnimationTrack limit of %d tracks for one Animator exceeded, new animations will not be played."
                          ,DAT_01d66968);
  }
  else {
    puVar3 = *(undefined4 **)(param_1 + 0xec);
    for (puVar5 = (undefined4 *)*puVar3; puVar5 != puVar3; puVar5 = (undefined4 *)*puVar5) {
      if (puVar5[2] == param_2) {
        ExceptionList = &pvStack_10;
        if (puVar5 != puVar3) goto LAB_00aeded7;
        break;
      }
    }
    puVar5 = (undefined4 *)puVar3[1];
    ExceptionList = &pvStack_10;
    uVar6 = FUN_009ef760(puVar3,puVar5,&param_2);
    if (*(int *)(param_1 + 0xf0) == 0xffffffe) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    *(int *)(param_1 + 0xf0) = *(int *)(param_1 + 0xf0) + 1;
    puVar3[1] = uVar6;
    *puVar5 = uVar6;
    if (DAT_01d6698c != '\0') {
      puVar5 = (undefined4 *)FUN_00aeda10(*(int *)(param_1 + 0xf0) + -1);
    }
  }
LAB_00aeded7:
  piVar4 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    puVar5 = (undefined4 *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puVar5 = (undefined4 *)(**(code **)*param_3)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puVar5 = (undefined4 *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 22679 ; VA 0x00aedf20 ; FUN_00aedf20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __fastcall FUN_00aedf20(int *param_1)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined uVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  undefined4 *puVar8;
  char *pcVar9;
  undefined4 *puVar10;
  int iVar11;
  undefined1 *puVar12;
  int *piVar13;
  float10 fVar14;
  undefined4 uStack_174;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  undefined auStack_164 [8];
  undefined auStack_15c [8];
  undefined auStack_154 [8];
  undefined auStack_14c [8];
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  uint auStack_104 [4];
  undefined4 uStack_f4;
  uint uStack_f0;
  undefined auStack_ec [16];
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  double dStack_d4;
  double dStack_cc;
  double dStack_c4;
  double dStack_bc;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  uint auStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  float fStack_28;
  float fStack_24;
  int *piStack_20;
  uint uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ebbd0;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  if (param_1[0xd] != 0) {
    iVar11 = *(int *)(param_1[0xd] + 0xc);
    ExceptionList = &pvStack_10;
    piStack_20 = param_1;
    iVar5 = FUN_0099be20();
    param_1 = (int *)(uint)*(ushort *)(iVar5 + 0x1da);
    if (((int *)((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) <= param_1)
       && (param_1 = (int *)FUN_009b7250(), param_1 != (int *)0x0)) {
      piVar7 = (int *)param_1[0xd];
      piVar13 = param_1;
      piStack_14 = param_1;
      if ((piVar7 != (int *)0x0) && (piVar13 = piVar7, piVar7[0xd] != 0)) {
        param_1 = (int *)FUN_005c8ac0();
        piVar13 = param_1;
      }
      if (piVar13 != (int *)0x0) {
        iVar11 = piVar13[3];
        iVar5 = FUN_008a8c30();
        param_1 = (int *)(uint)*(ushort *)(iVar5 + 0x1da);
        if ((int *)((uint)*(ushort *)(iVar11 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) <= param_1
           ) {
          FUN_005789c0();
          uVar6 = FUN_00560f40();
          piVar7 = (int *)FUN_008aa140(uVar6);
          param_1 = piVar7;
          if (*piVar7 == 0) {
            FUN_008aa950();
            param_1 = (int *)FUN_008a9ba0();
            iVar11 = *param_1;
            iVar5 = param_1[1];
            *param_1 = 0;
            param_1[1] = 0;
            *piVar7 = iVar11;
            piVar13 = (int *)piVar7[1];
            piVar7[1] = iVar5;
            if (piVar13 != (int *)0x0) {
              LOCK();
              piVar1 = piVar13 + 1;
              iVar11 = *piVar1;
              param_1 = (int *)*piVar1;
              *piVar1 = iVar11 + -1;
              UNLOCK();
              if (iVar11 + -1 == 0) {
                (**(code **)*piVar13)();
                LOCK();
                piVar1 = piVar13 + 2;
                iVar11 = *piVar1;
                param_1 = (int *)*piVar1;
                *piVar1 = iVar11 + -1;
                UNLOCK();
                if (iVar11 + -1 == 0) {
                  param_1 = (int *)(**(code **)(*piVar13 + 4))();
                }
              }
            }
            piVar13 = piStack_30;
            if (piStack_30 != (int *)0x0) {
              LOCK();
              piVar1 = piStack_30 + 1;
              iVar11 = *piVar1;
              param_1 = (int *)*piVar1;
              *piVar1 = iVar11 + -1;
              UNLOCK();
              if (iVar11 + -1 == 0) {
                param_1 = (int *)(**(code **)*piStack_30)();
                LOCK();
                piVar1 = piVar13 + 2;
                iVar11 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar11 == 1) {
                  param_1 = (int *)(**(code **)(*piVar13 + 4))();
                }
              }
            }
          }
          iVar11 = *piVar7;
          if (iVar11 != 0) {
            iVar5 = FUN_00b077e0();
            uStack_44._4_4_ = (float)((ulonglong)*(undefined8 *)(iVar5 + 0x24) >> 0x20);
            uStack_3c = *(undefined4 *)(iVar5 + 0x2c);
            uStack_44 = CONCAT44(uStack_44._4_4_ + DAT_018df57c,(int)*(undefined8 *)(iVar5 + 0x24));
            (**(code **)(*(int *)(iVar11 + 0x144) + 4))();
            uVar4 = FUN_00d23e50();
            param_1 = (int *)(uint)CONCAT11((fStack_24 == DAT_018e0028) << 6 |
                                            (NAN(fStack_24) || NAN(DAT_018e0028)) << 2 | 2U |
                                            fStack_24 < DAT_018e0028,uVar4);
            if (((NAN(fStack_24) || NAN(DAT_018e0028)) == (fStack_24 == DAT_018e0028)) &&
               (DAT_019011dc <= fStack_24)) {
              piStack_14 = &DAT_0194c500;
              do {
                iStack_18 = *piStack_14;
                iVar11 = 0;
                piVar7 = (int *)piStack_20[0x3b];
                piVar13 = (int *)*piVar7;
                if (piVar13 != piVar7) {
                  do {
                    iVar5 = FUN_00e668b0();
                    if (iVar5 == iStack_18) {
                      iVar11 = iVar11 + 1;
                    }
                    piVar13 = (int *)*piVar13;
                  } while (piVar13 != piVar7);
                  if (iVar11 != 0) {
                    uStack_130 = _DAT_018e3fc0;
                    uStack_12c = _UNK_018e3fc4;
                    uStack_128 = _UNK_018e3fc8;
                    uStack_124 = _UNK_018e3fcc;
                    uStack_120 = 0;
                    uStack_74 = _DAT_018e3fd0;
                    uStack_70 = _UNK_018e3fd4;
                    uStack_6c = _UNK_018e3fd8;
                    uStack_68 = _UNK_018e3fdc;
                    uStack_34 = 0;
                    piStack_30 = (int *)0x0;
                    puVar8 = (undefined4 *)FUN_0115e910();
                    uStack_84 = *puVar8;
                    uStack_80 = puVar8[1];
                    uStack_7c = puVar8[2];
                    uStack_78 = 0x3f800000;
                    puVar8 = (undefined4 *)FUN_0115ee70();
                    uStack_94 = *puVar8;
                    uStack_90 = puVar8[1];
                    uStack_8c = puVar8[2];
                    uStack_88 = 0x3f800000;
                    uVar6 = FUN_01126580(auStack_14c);
                    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34)
                         < DAT_01eec52c) && (FUN_016f3809(&DAT_01eec52c), DAT_01eec52c == -1)) {
                      uStack_8 = 0;
                      FUN_00dc89c0();
                      FUN_016f3654(&LAB_0188bed0);
                      uStack_8 = 0xffffffff;
                      FUN_016f37bf();
                    }
                    FUN_009cb090();
                    uStack_1c = uStack_1c | 1;
                    uStack_8 = 1;
                    pcVar9 = (char *)FUN_01675640();
                    uStack_8._0_1_ = 2;
                    if (0xf < *(uint *)(pcVar9 + 0x14)) {
                      pcVar9 = *(char **)pcVar9;
                    }
                    uStack_dc = 0;
                    uStack_d8 = 0xf;
                    auStack_ec[0] = 0;
                    do {
                      cVar2 = *pcVar9;
                      pcVar9 = pcVar9 + 1;
                    } while (cVar2 != '\0');
                    FUN_005542c0();
                    uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    FUN_0114e430(auStack_154,auStack_ec,uVar6,0x41600000,0,&uStack_94,&uStack_84,3,1
                                 ,0,&uStack_34,&uStack_74,&uStack_130,1);
                    FUN_005507b0();
                    FUN_005507b0();
                    uStack_8 = 0xffffffff;
                    FUN_005507b0();
                    fStack_28 = fStack_28 + DAT_018fabe8;
                    puVar8 = (undefined4 *)piStack_20[0x3b];
                    for (puVar3 = (undefined4 *)*puVar8; puVar3 != puVar8;
                        puVar3 = (undefined4 *)*puVar3) {
                      iVar11 = FUN_00e668b0();
                      if (iVar11 == iStack_18) {
                        uStack_144 = _DAT_018e3fc0;
                        uStack_140 = _UNK_018e3fc4;
                        uStack_13c = _UNK_018e3fc8;
                        uStack_138 = _UNK_018e3fcc;
                        uStack_134 = 0;
                        uStack_174 = _DAT_018e3fd0;
                        uStack_170 = _UNK_018e3fd4;
                        uStack_16c = _UNK_018e3fd8;
                        uStack_168 = _UNK_018e3fdc;
                        uStack_64 = 0;
                        uStack_60 = 0;
                        puVar10 = (undefined4 *)FUN_0115e910();
                        uStack_a4 = *puVar10;
                        uStack_a0 = puVar10[1];
                        uStack_9c = puVar10[2];
                        uStack_98 = 0x3f800000;
                        puVar10 = (undefined4 *)FUN_0115ee70();
                        uStack_b4 = *puVar10;
                        uStack_b0 = puVar10[1];
                        uStack_ac = puVar10[2];
                        uStack_a8 = 0x3f800000;
                        uStack_38 = FUN_01126580(auStack_15c);
                        iVar11 = FUN_0074a340();
                        puVar12 = &DAT_0194cb40;
                        if (*(char *)(iVar11 + 0x60) == '\0') {
                          puVar12 = &DAT_018bc9b8;
                        }
                        fVar14 = (float10)FUN_00764670();
                        dStack_bc = (double)fVar14;
                        fVar14 = (float10)FUN_009d7b60();
                        dStack_c4 = (double)fVar14;
                        fVar14 = (float10)FUN_00e66480();
                        dStack_cc = (double)fVar14;
                        fVar14 = (float10)FUN_00832140();
                        dStack_d4 = (double)fVar14;
                        piVar7 = *(int **)(puVar3[2] + 0x28);
                        if (0xf < (uint)piVar7[5]) {
                          piVar7 = (int *)*piVar7;
                        }
                        pcVar9 = (char *)FUN_01675640(auStack_104,
                                                      "\t%s: %.2f/%.2f weight %.2f speed %.2f %s",
                                                      piVar7,dStack_d4,dStack_cc,dStack_c4,dStack_bc
                                                      ,puVar12);
                        uStack_8 = 4;
                        if (0xf < *(uint *)(pcVar9 + 0x14)) {
                          pcVar9 = *(char **)pcVar9;
                        }
                        uStack_4c = 0;
                        uStack_48 = 0xf;
                        auStack_5c[0] = auStack_5c[0] & 0xffffff00;
                        do {
                          cVar2 = *pcVar9;
                          pcVar9 = pcVar9 + 1;
                        } while (cVar2 != '\0');
                        FUN_005542c0();
                        uStack_8._0_1_ = 5;
                        FUN_0114e430(auStack_164,auStack_5c,uStack_38,0x41600000,0,&uStack_b4,
                                     &uStack_a4,3,1,0,&uStack_64,&uStack_174,&uStack_144,1);
                        uStack_8 = CONCAT31(uStack_8._1_3_,4);
                        if (0xf < uStack_48) {
                          if ((0xfff < uStack_48 + 1) &&
                             (0x1f < (auStack_5c[0] - *(int *)(auStack_5c[0] - 4)) - 4))
                          goto LAB_00aee5ec;
                          FUN_01674ea0();
                        }
                        uStack_4c = 0;
                        uStack_48 = 0xf;
                        auStack_5c[0] = auStack_5c[0] & 0xffffff00;
                        uStack_8 = 0xffffffff;
                        if (0xf < uStack_f0) {
                          if ((0xfff < uStack_f0 + 1) &&
                             (0x1f < (auStack_104[0] - *(int *)(auStack_104[0] - 4)) - 4)) {
LAB_00aee5ec:
                    /* WARNING: Subroutine does not return */
                            FUN_017167a3();
                          }
                          FUN_01674ea0();
                        }
                        fStack_28 = fStack_28 + DAT_018fabe8;
                        uStack_f4 = 0;
                        uStack_f0 = 0xf;
                        auStack_104[0] = auStack_104[0] & 0xffffff00;
                      }
                    }
                  }
                }
                param_1 = piStack_14 + 1;
                piStack_14 = param_1;
              } while (param_1 != &DAT_0194c510);
            }
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22680 ; VA 0x00aee640 ; FUN_00aee640 */

void __thiscall FUN_00aee640(int param_1,int param_2)

{
  int iVar1;
  uint in_stack_00000018;
  undefined uStack0000001c;
  int in_stack_00000020;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined *in_stack_00000034;
  undefined auStack_8c [24];
  undefined4 uStack_74;
  int iStack_70;
  int *piStack_6c;
  undefined8 uStack_68;
  int iStack_60;
  undefined **ppuStack_5c;
  int aiStack_50 [5];
  uint uStack_3c;
  undefined uStack_38;
  int iStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined4 uStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017ebbf0;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  if (((DAT_01d6fc28 == '\0') || (*(int *)(param_1 + 0x100) == 0)) ||
     (*(char *)(*(int *)(param_1 + 0x100) + 1) == '\0')) {
    puStack_18 = in_stack_00000034;
    ppuStack_5c = &puStack_18;
    iStack_60 = in_stack_00000030;
    uStack_14 = 0;
    uStack_68 = CONCAT44(in_stack_0000002c,in_stack_00000028);
    piStack_6c = (int *)in_stack_00000024;
    iStack_70 = in_stack_00000020;
    uStack_74 = _uStack0000001c;
    in_stack_00000034 = auStack_8c;
    ExceptionList = &pvStack_10;
    FUN_0054ef60(&param_2);
    FUN_00aee810(param_1);
  }
  else {
    piStack_6c = &param_2;
    iStack_70 = 0xaee69d;
    ExceptionList = &pvStack_10;
    FUN_0054ef60();
    iStack_34 = in_stack_00000020;
    uStack_30 = in_stack_00000024;
    uStack_38 = uStack0000001c;
    uStack_2c = in_stack_00000028;
    uStack_24 = in_stack_00000030;
    uStack_28 = in_stack_0000002c;
    puStack_20 = in_stack_00000034;
    piStack_6c = (int *)0x4;
    iStack_70 = 0x34;
    iStack_8._0_1_ = 1;
    ppuStack_5c = (undefined **)0x0;
    uStack_74 = 0xaee6eb;
    uStack_1c = FUN_01674fa0();
    piStack_6c = aiStack_50;
    puStack_18 = &DAT_00000034;
    uStack_68 = CONCAT44(0x34,uStack_1c);
    iStack_60 = 4;
    iStack_70 = 0xaee713;
    FUN_00ae7ed0();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    ppuStack_5c = &PTR_FUN_01d669e4;
    if (0xf < uStack_3c) {
      piStack_6c = (int *)(uStack_3c + 1);
      iVar1 = aiStack_50[0];
      if (0xfff < piStack_6c) {
        iVar1 = *(int *)(aiStack_50[0] + -4);
        piStack_6c = (int *)(uStack_3c + 0x24);
        if (0x1f < (aiStack_50[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
          piStack_6c = (int *)0xaee80a;
          FUN_017167a3();
        }
      }
      uStack_74 = 0xaee756;
      iStack_70 = iVar1;
      FUN_01674ea0();
    }
    piStack_6c = (int *)0xaee760;
    FUN_00aebcc0();
  }
  if (0xf < in_stack_00000018) {
    ppuStack_5c = (undefined **)(in_stack_00000018 + 1);
    iVar1 = param_2;
    if (0xfff < ppuStack_5c) {
      iVar1 = *(int *)(param_2 + -4);
      ppuStack_5c = (undefined **)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        ppuStack_5c = (undefined **)&UNK_00aee80f;
        FUN_017167a3();
      }
    }
    uStack_68 = CONCAT44(0xaee7f0,(undefined4)uStack_68);
    iStack_60 = iVar1;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22681 ; VA 0x00aee810 ; FUN_00aee810 */

/* WARNING: Removing unreachable block (ram,0x00aeea1d) */
/* WARNING: Removing unreachable block (ram,0x00aeea2b) */
/* WARNING: Removing unreachable block (ram,0x00aeea55) */
/* WARNING: Removing unreachable block (ram,0x00aeea3b) */

void FUN_00aee810(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined4 param_14)

{
  code *pcVar1;
  undefined4 uStack_5d0;
  undefined4 uStack_5cc;
  undefined4 uStack_5c8;
  undefined4 uStack_5c4;
  undefined4 uStack_5c0;
  undefined4 uStack_5bc;
  undefined8 uStack_5b8;
  undefined4 uStack_500;
  undefined4 uStack_4fc;
  undefined uStack_4f8;
  undefined4 uStack_430;
  undefined4 uStack_42c;
  undefined4 uStack_428;
  undefined4 uStack_360;
  undefined4 uStack_35c;
  undefined4 uStack_358;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017ebc6b;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_5d0 = FUN_0088d190();
  uStack_5cc = 0;
  uStack_5c8 = param_2;
  uStack_5c4 = param_3;
  uStack_5c0 = param_4;
  uStack_5bc = param_5;
  uStack_5b8 = CONCAT44(param_7,param_6);
  uStack_5cc = FUN_00630cf0();
  iStack_8._0_1_ = 1;
  uStack_500 = FUN_0088daf0();
  uStack_4fc = 0;
  uStack_4f8 = (undefined)param_8;
  uStack_4fc = FUN_005c9ef0();
  iStack_8._0_1_ = 2;
  uStack_430 = FUN_0088c960();
  uStack_42c = 0;
  uStack_428 = param_9;
  uStack_42c = FUN_00630820();
  iStack_8._0_1_ = 3;
  uStack_360 = FUN_0088c960();
  uStack_35c = 0;
  uStack_358 = param_10;
  uStack_35c = FUN_00630820();
  iStack_8._0_1_ = 4;
  uStack_290 = FUN_0088c960();
  uStack_28c = 0;
  uStack_288 = param_11;
  uStack_28c = FUN_00630820();
  iStack_8._0_1_ = 5;
  uStack_1c0 = FUN_0088c960();
  uStack_1bc = 0;
  uStack_1b8 = param_12;
  uStack_1bc = FUN_00630820();
  iStack_8._0_1_ = 6;
  uStack_f0 = FUN_0088c8c0();
  uStack_ec = 0;
  uStack_e8 = param_13;
  uStack_ec = FUN_005c9cc0();
  iStack_8._0_1_ = 7;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_5d0,&uStack_20,param_8);
  iStack_8._0_1_ = 8;
  (*pcVar1)(uStack_14,&uStack_20,param_14);
  iStack_8._0_1_ = 9;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_5d0,0xd0,7,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22682 ; VA 0x00aeea60 ; FUN_00aeea60 */

undefined * FUN_00aeea60(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ebc8c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eec52c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eec52c);
    if (DAT_01eec52c == -1) {
      uStack_8 = 0;
      FUN_00dc89c0();
      FUN_016f3654(&LAB_0188bed0);
      FUN_016f37bf(&DAT_01eec52c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eec4c8;
}



/* FUNCTION 22683 ; VA 0x00aeeaf0 ; FUN_00aeeaf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00aeeaf0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eec53c) {
    FUN_016f3809(&DAT_01eec53c);
    if (DAT_01eec53c == -1) {
      _DAT_01eec530 = FUN_005c65e0;
      _DAT_01eec534 = FUN_005c65e0;
      _DAT_01eec538 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eec53c);
    }
  }
  return &DAT_01eec530;
}



/* FUNCTION 22684 ; VA 0x00aeeb60 ; FUN_00aeeb60 */

void __thiscall FUN_00aeeb60(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_0089be10(*param_2,param_2[1]);
  iVar2 = *(int *)(param_1 + 0x34);
  if ((iVar2 != 0) &&
     ((iVar4 = *(int *)(iVar2 + 0xc), iVar3 = FUN_00e63c60(),
      (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
      (uint)*(ushort *)(iVar3 + 0x1da) ||
      (iVar2 = *(int *)(iVar2 + 0xc), iVar4 = FUN_0099be20(),
      (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
      (uint)*(ushort *)(iVar4 + 0x1da))))) {
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_0089be10(*param_2,param_2[1]);
  }
  return;
}



/* FUNCTION 22685 ; VA 0x00aeec30 ; FUN_00aeec30 */

void FUN_00aeec30(int param_1)

{
  int iVar1;
  int iVar2;
  undefined auStack_10 [12];
  
  if (((param_1 != 0) &&
      (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_0099be20(),
      (uint)*(ushort *)(iVar2 + 0x1da) <
      (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) &&
     (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_00e63c60(),
     (uint)*(ushort *)(iVar2 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) {
    FUN_016756b0(auStack_10,"Animator has to be placed under Humanoid or AnimationController!");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_10,&DAT_01c17198);
  }
  return;
}



/* FUNCTION 22686 ; VA 0x00aeecb0 ; FUN_00aeecb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00aeecb0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ebcc0;
  pvStack_10 = ExceptionList;
  if (DAT_01eec54c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eec760) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eec760);
      if (DAT_01eec760 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"TouchTransmitter",0,uStack_20,0,0,3,0,0);
        _DAT_01eec758 = RBX::Creator<class_RBX::TouchTransmitter>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01eec550,&DAT_01eec758);
        FUN_016f3654(FUN_0188bf50);
        FUN_016f37bf(&DAT_01eec760);
      }
    }
    DAT_01eec54c = &DAT_01eec550;
  }
  ExceptionList = pvStack_10;
  return DAT_01eec54c;
}



/* FUNCTION 22687 ; VA 0x00aeedb0 ; FUN_00aeedb0 */

int __thiscall FUN_00aeedb0(int *param_1,int param_2,undefined4 *param_3)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  
  iVar4 = *param_1;
  iVar3 = (param_1[1] - iVar4) / 0x18;
  if (iVar3 == 0xaaaaaaa) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar8 = iVar3 + 1;
  uVar2 = (param_1[2] - iVar4) / 0x18;
  uVar9 = uVar8;
  if ((uVar2 <= 0xaaaaaaa - (uVar2 >> 1)) && (uVar9 = (uVar2 >> 1) + uVar2, uVar9 < uVar8)) {
    uVar9 = uVar8;
  }
  iVar3 = FUN_00577fb0(uVar9);
  iVar4 = ((param_2 - iVar4) / 0x18) * 0x18;
  *(undefined4 *)(iVar4 + iVar3) = 0;
  *(undefined4 *)(iVar4 + 4 + iVar3) = 0;
  if (param_3[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar4 + iVar3) = *param_3;
  *(undefined4 *)(iVar4 + 4 + iVar3) = param_3[1];
  *(undefined4 *)(iVar4 + 8 + iVar3) = param_3[2];
  *(undefined4 *)(iVar4 + 0x10 + iVar3) = param_3[4];
  *(undefined4 *)(iVar4 + 0x14 + iVar3) = param_3[5];
  iVar5 = param_1[1];
  iVar6 = iVar3;
  iVar7 = *param_1;
  if (param_2 != iVar5) {
    FUN_00aef0d0(*param_1,param_2,iVar3,param_1);
    iVar6 = iVar4 + iVar3 + 0x18;
    iVar5 = param_1[1];
    iVar7 = param_2;
  }
  FUN_00aef0d0(iVar7,iVar5,iVar6,param_1);
  FUN_00aef460(iVar3,uVar8,uVar9);
  return *param_1 + iVar4;
}



/* FUNCTION 22688 ; VA 0x00aeeee0 ; FUN_00aeeee0 */

void __thiscall FUN_00aeeee0(int *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  
  uVar4 = param_2;
  uVar2 = (param_1[1] - *param_1) / 0x18;
  uVar3 = (param_1[2] - *param_1) / 0x18;
  if (param_2 <= uVar3) {
    if (param_2 <= uVar2) {
      if (param_2 != uVar2) {
        iVar5 = *param_1 + param_2 * 0x18;
        FUN_00aef500(iVar5,param_1[1]);
        param_1[1] = iVar5;
      }
      return;
    }
    iVar5 = FUN_00aef3c0(param_1[1],param_2 - uVar2);
    param_1[1] = iVar5;
    return;
  }
  if (0xaaaaaaa < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = param_2;
  if ((uVar3 <= 0xaaaaaaa - (uVar3 >> 1)) && (uVar1 = (uVar3 >> 1) + uVar3, uVar1 < param_2)) {
    uVar1 = param_2;
  }
  param_2 = uVar1;
  iVar5 = FUN_00577fb0(param_2);
  FUN_00aef3c0(iVar5 + uVar2 * 0x18,uVar4 - uVar2);
  FUN_00aef0d0(*param_1,param_1[1],iVar5,param_1);
  FUN_00aef460(iVar5,uVar4,param_2);
  return;
}



/* FUNCTION 22689 ; VA 0x00aeefe0 ; FUN_00aeefe0 */

int __thiscall FUN_00aeefe0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ebcd0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::TouchTransmitter*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 22690 ; VA 0x00aef0b2 ; Catch_All@00aef0b2 */

void Catch_All_00aef0b2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 22691 ; VA 0x00aef0d0 ; FUN_00aef0d0 */

undefined4 * FUN_00aef0d0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar4 = param_3;
  if (param_1 != param_2) {
    puVar3 = param_1 + 1;
    do {
      *puVar4 = 0;
      puVar1 = puVar3 + 6;
      *(undefined4 *)((int)param_3 + (-0x18 - (int)param_1) + (int)puVar1) = 0;
      *puVar4 = puVar3[-1];
      *(undefined4 *)((int)param_3 + (-0x18 - (int)param_1) + (int)puVar1) = *puVar3;
      puVar3[-1] = 0;
      *puVar3 = 0;
      puVar4[2] = puVar3[1];
      puVar4[4] = puVar3[3];
      puVar4[5] = puVar3[4];
      puVar2 = puVar3 + 5;
      puVar4 = puVar4 + 6;
      puVar3 = puVar1;
    } while (puVar2 != param_2);
  }
  return puVar4;
}



/* FUNCTION 22692 ; VA 0x00aef140 ; FUN_00aef140 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_00aef140(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ebd3e;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00aeecb0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  uStack_18 = uVar2;
  puVar3 = (undefined4 *)FUN_01674e20(0x68);
  uStack_8._0_1_ = 2;
  puStack_1c = puVar3;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0089a7a0();
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::TouchTransmitter,class_RBX::Instance>::vftable;
    uVar4 = FUN_00aeecb0();
    puVar3[3] = uVar4;
    LOCK();
    _DAT_01eec548 = _DAT_01eec548 + 1;
    UNLOCK();
    *puVar3 = RBX::TouchTransmitter::vftable;
    puVar3[0x15] = 0;
    puVar3[0x16] = 0;
    puVar3[0x17] = 0;
    puVar3[0x18] = 0;
    puVar3[0x19] = 0;
    uStack_8._0_1_ = 6;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_00551260("TouchInterest");
    uStack_8._0_1_ = 7;
    FUN_008a6520(auStack_34);
    uStack_8._0_1_ = 6;
    if (0xf < uStack_20) {
      uVar6 = uStack_20 + 1;
      uVar5 = auStack_34[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_34[0] - 4);
        uVar6 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00aeefe0(puVar3,puStack_1c);
  uStack_14 = 1;
  uStack_8 = 0xb;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22693 ; VA 0x00aef2c0 ; FUN_00aef2c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00aef2c0(void)

{
  LOCK();
  _DAT_01eec548 = _DAT_01eec548 + -1;
  UNLOCK();
  return;
}



/* FUNCTION 22694 ; VA 0x00aef2d0 ; FUN_00aef2d0 */

void __fastcall FUN_00aef2d0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::TouchTransmitter>::vftable;
  uVar1 = FUN_00aeecb0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22695 ; VA 0x00aef310 ; FUN_00aef310 */

void __fastcall FUN_00aef310(int *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  iVar4 = *param_1;
  if (iVar4 != 0) {
    iVar5 = param_1[1];
    if (iVar4 != iVar5) {
      do {
        piVar1 = *(int **)(iVar4 + 4);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        iVar4 = iVar4 + 0x18;
      } while (iVar4 != iVar5);
      iVar4 = *param_1;
    }
    uVar3 = ((param_1[2] - iVar4) / 0x18) * 0x18;
    iVar5 = iVar4;
    if (0xfff < uVar3) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 22696 ; VA 0x00aef3a0 ; FUN_00aef3a0 */

void __fastcall FUN_00aef3a0(int param_1)

{
  int iVar1;
  
  LOCK();
  iVar1 = *(int *)(param_1 + 0x10);
  *(int *)(param_1 + 0x10) = 0;
  UNLOCK();
  if (iVar1 != 0) {
    CloseHandle(iVar1);
  }
  FUN_00aef310();
  return;
}



/* FUNCTION 22697 ; VA 0x00aef3c0 ; FUN_00aef3c0 */

void FUN_00aef3c0(undefined4 *param_1,int param_2)

{
  if (param_2 != 0) {
    do {
      param_1[1] = 0;
      param_1[2] = 0;
      param_1[3] = 0;
      *param_1 = 0;
      param_1[1] = 0;
      *(undefined8 *)(param_1 + 4) = 0;
      param_1 = param_1 + 6;
      param_2 = param_2 + -1;
    } while (param_2 != 0);
  }
  return;
}



/* FUNCTION 22698 ; VA 0x00aef410 ; FUN_00aef410 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __thiscall FUN_00aef410(int param_1,byte param_2)

{
  int iVar1;
  
  LOCK();
  iVar1 = *(int *)(param_1 + 100);
  *(int *)(param_1 + 100) = 0;
  UNLOCK();
  if (iVar1 != 0) {
    CloseHandle(iVar1);
  }
  FUN_00aef310();
  LOCK();
  _DAT_01eec548 = _DAT_01eec548 + -1;
  UNLOCK();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x68);
  }
  return param_1;
}



/* FUNCTION 22699 ; VA 0x00aef460 ; FUN_00aef460 */

void __thiscall FUN_00aef460(int *param_1,int param_2,int param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  iVar4 = *param_1;
  if (iVar4 != 0) {
    iVar5 = param_1[1];
    if (iVar4 != iVar5) {
      do {
        piVar1 = *(int **)(iVar4 + 4);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        iVar4 = iVar4 + 0x18;
      } while (iVar4 != iVar5);
      iVar4 = *param_1;
    }
    uVar3 = ((param_1[2] - iVar4) / 0x18) * 0x18;
    iVar5 = iVar4;
    if (0xfff < uVar3) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar3);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 0x18;
  param_1[2] = param_2 + param_4 * 0x18;
  return;
}



/* FUNCTION 22700 ; VA 0x00aef500 ; FUN_00aef500 */

void FUN_00aef500(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  
  if (param_1 != param_2) {
    do {
      piVar1 = *(int **)(param_1 + 4);
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
      param_1 = param_1 + 0x18;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 22701 ; VA 0x00aef540 ; FUN_00aef540 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined __thiscall FUN_00aef540(int *param_1,int *param_2,int param_3)

{
  double *pdVar1;
  int iVar2;
  int iVar3;
  double dVar4;
  undefined4 uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  int *piVar9;
  int *piVar10;
  uint *puVar11;
  uint uVar12;
  int iVar13;
  int iVar14;
  int iStack_50;
  int *piStack_4c;
  int iStack_48;
  undefined8 uStack_40;
  double dStack_38;
  uint *puStack_30;
  undefined uStack_2c;
  undefined8 uStack_28;
  int iStack_20;
  uint uStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ebd68;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  puVar11 = (uint *)(param_1 + 3);
  puStack_30 = puVar11;
  piStack_18 = param_1;
  if (puVar11 == (uint *)0x0) {
    ExceptionList = &pvStack_10;
    uVar5 = FUN_0056aeb0(1,"boost unique_lock has no mutex");
    uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
    FUN_00564990(uVar5);
  }
  LOCK();
  uVar6 = *puVar11;
  ExceptionList = &pvStack_10;
  *puVar11 = *puVar11 | 0x80000000;
  UNLOCK();
  if ((int)uVar6 < 0) {
    uVar6 = *puVar11;
    do {
      uVar8 = uVar6;
      uStack_28 = (double)CONCAT44(uVar8 >> 0x1f,(undefined4)uStack_28);
      uVar12 = uVar8 + 1;
      if (-1 < (int)uVar8) {
        uVar12 = uVar8 | 0x80000000;
      }
      LOCK();
      uVar6 = *puVar11;
      if (uVar8 == uVar6) {
        *puVar11 = uVar12;
        uVar6 = uVar8;
      }
      UNLOCK();
    } while (uVar6 != uVar8);
    if (-1 < (int)uVar8) {
      uVar12 = uVar8;
    }
    if ((int)uVar12 < 0) {
      uVar5 = FUN_00554e40();
      do {
        WaitForSingleObjectEx(uVar5,0xffffffff,0);
        uVar6 = uVar12 & 0x3fffffff | 0x40000000;
        do {
          uVar12 = uVar6;
          uVar8 = uVar12;
          if (-1 < (int)uVar12) {
            uVar8 = uVar12 - 1 | 0x80000000;
          }
          LOCK();
          uVar6 = *puVar11;
          if (uVar12 == uVar6) {
            *puVar11 = uVar8 & 0xbfffffff;
            uVar6 = uVar12;
          }
          UNLOCK();
        } while (uVar6 != uVar12);
      } while ((int)uVar12 < 0);
    }
  }
  piVar10 = piStack_18;
  uStack_2c = 1;
  uStack_8 = 2;
  FUN_016830f0(&dStack_38);
  piVar9 = (int *)piVar10[1];
  iVar14 = *piVar10;
  uStack_1c = 0;
  iVar13 = (int)piVar9 - iVar14 >> 0x1f;
  if (((int)piVar9 - iVar14) / 0x18 + iVar13 != iVar13) {
    iVar13 = 0;
    do {
      dVar4 = uStack_28;
      iVar2 = *(int *)(iVar13 + 4 + iVar14);
      piVar9 = (int *)0x0;
      uStack_28 = (double)((ulonglong)uStack_28 & 0xffffffff);
      if (iVar2 != 0) {
        piVar9 = (int *)(iVar2 + 4);
        iVar2 = *(int *)(iVar2 + 4);
        while (iVar2 != 0) {
          LOCK();
          iVar7 = *piVar9;
          if (iVar2 == iVar7) {
            *piVar9 = iVar2 + 1;
            iVar7 = iVar2;
          }
          UNLOCK();
          if (iVar7 == iVar2) {
            piVar9 = *(int **)(iVar13 + 4 + iVar14);
            uStack_28._0_4_ = SUB84(dVar4,0);
            uStack_28 = (double)CONCAT44(*(undefined4 *)(iVar13 + iVar14),(undefined4)uStack_28);
            goto LAB_00aef68e;
          }
          iVar2 = *piVar9;
        }
        piVar9 = (int *)0x0;
      }
LAB_00aef68e:
      iStack_20 = *param_2;
      if (piVar9 != (int *)0x0) {
        LOCK();
        iVar2 = piVar9[1] + -1;
        piVar9[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar9)();
          LOCK();
          iVar2 = piVar9[2] + -1;
          piVar9[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
      if (uStack_28._4_4_ == iStack_20) {
        dStack_38 = dStack_38 + _DAT_01d669f0;
        uStack_28._0_4_ = SUB84(dStack_38,0);
        *(undefined4 *)(iVar13 + 0x10 + iVar14) = (undefined4)uStack_28;
        uStack_28._4_4_ = (int)((ulonglong)dStack_38 >> 0x20);
        *(int *)(iVar13 + 0x14 + iVar14) = uStack_28._4_4_;
        puVar11 = puStack_30;
        uStack_28 = dStack_38;
        if (*(int *)(iVar13 + 8 + iVar14) == param_3) {
          param_2._3_1_ = 0;
        }
        else {
          *(int *)(iVar13 + 8 + iVar14) = param_3;
          param_2._3_1_ = 1;
        }
        goto LAB_00aef89a;
      }
      pdVar1 = (double *)(iVar13 + 0x10 + iVar14);
      if (dStack_38 < *pdVar1 || dStack_38 == *pdVar1) {
        uStack_1c = uStack_1c + 1;
        iVar13 = iVar13 + 0x18;
        piVar10 = piStack_18;
      }
      else {
        iVar2 = *piStack_18;
        iVar7 = (piStack_18[1] - iVar2) / 0x18;
        if (uStack_1c < iVar7 - 1U) {
          iStack_20 = iVar7 * 3;
          iVar3 = *(int *)(iVar2 + -0x14 + iVar7 * 0x18);
          if (iVar3 != 0) {
            LOCK();
            *(int *)(iVar3 + 8) = *(int *)(iVar3 + 8) + 1;
            UNLOCK();
            iVar3 = *(int *)(iVar2 + -0x14 + iVar7 * 0x18);
          }
          uStack_28 = (double)CONCAT44(iVar3,(undefined4)uStack_28);
          *(undefined4 *)(iVar13 + iVar14) = *(undefined4 *)(iVar2 + -0x18 + iVar7 * 0x18);
          piVar9 = *(int **)(iVar13 + 4 + iVar14);
          *(int *)(iVar13 + 4 + iVar14) = iVar3;
          if (piVar9 != (int *)0x0) {
            LOCK();
            iVar7 = piVar9[2] + -1;
            piVar9[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)(*piVar9 + 4))();
            }
          }
          *(undefined4 *)(iVar13 + 8 + iVar14) = *(undefined4 *)(iVar2 + -0x10 + iStack_20 * 8);
          *(undefined4 *)(iVar13 + 0x10 + iVar14) = *(undefined4 *)(iVar2 + -8 + iStack_20 * 8);
          *(undefined4 *)(iVar13 + 0x14 + iVar14) = *(undefined4 *)(iVar2 + -4 + iStack_20 * 8);
        }
        piVar10 = piStack_18;
        FUN_00aeeee0((piStack_18[1] - *piStack_18) / 0x18 + -1,piStack_18);
      }
      piVar9 = (int *)piVar10[1];
      iVar14 = *piVar10;
      uStack_28 = (double)CONCAT44(piVar9,(undefined4)uStack_28);
      puVar11 = puStack_30;
    } while (uStack_1c < (uint)(((int)piVar9 - iVar14) / 0x18));
  }
  if (param_2[1] == 0) {
    piStack_4c = (int *)0x0;
  }
  else {
    LOCK();
    piVar9 = (int *)(param_2[1] + 8);
    *piVar9 = *piVar9 + 1;
    UNLOCK();
    piStack_4c = (int *)param_2[1];
    piVar9 = (int *)piStack_18[1];
  }
  dStack_38 = dStack_38 + _DAT_01d669f0;
  iStack_50 = *param_2;
  iStack_48 = param_3;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_40 = dStack_38;
  if ((int *)piStack_18[2] == piVar9) {
    FUN_00aeedb0(piVar9,&iStack_50);
  }
  else {
    *piVar9 = 0;
    piVar9[1] = 0;
    if (piStack_4c != (int *)0x0) {
      LOCK();
      piStack_4c[2] = piStack_4c[2] + 1;
      UNLOCK();
    }
    *piVar9 = iStack_50;
    uStack_40._0_4_ = SUB84(dStack_38,0);
    piVar9[1] = (int)piStack_4c;
    piVar9[4] = (int)uStack_40;
    uStack_40._4_4_ = (int)((ulonglong)dStack_38 >> 0x20);
    piVar9[2] = param_3;
    piVar9[5] = uStack_40._4_4_;
    piStack_18[1] = piStack_18[1] + 0x18;
  }
  param_2._3_1_ = 1;
  if (piStack_4c != (int *)0x0) {
    LOCK();
    piVar9 = piStack_4c + 2;
    iVar14 = *piVar9;
    *piVar9 = *piVar9 + -1;
    UNLOCK();
    if (iVar14 == 1) {
      (**(code **)(*piStack_4c + 4))();
    }
  }
LAB_00aef89a:
  uStack_8 = 4;
  LOCK();
  uVar6 = *puVar11;
  *puVar11 = *puVar11 + 0x80000000;
  UNLOCK();
  if (((uVar6 & 0x40000000) == 0) && (-0x80000000 < (int)uVar6)) {
    LOCK();
    uVar6 = *puVar11;
    *puVar11 = *puVar11 | 0x40000000;
    UNLOCK();
    if ((uVar6 >> 0x1e & 1) == 0) {
      uVar5 = FUN_00554e40();
      SetEvent(uVar5);
    }
  }
  ExceptionList = pvStack_10;
  return param_2._3_1_;
}



/* FUNCTION 22702 ; VA 0x00aef900 ; FUN_00aef900 */

void FUN_00aef900(undefined4 param_1)

{
  FUN_00aef540(param_1,0);
  return;
}



/* FUNCTION 22703 ; VA 0x00aef920 ; FUN_00aef920 */

void FUN_00aef920(undefined4 param_1)

{
  FUN_00aef540(param_1,1);
  return;
}



/* FUNCTION 22704 ; VA 0x00aef940 ; FUN_00aef940 */

undefined4 * FUN_00aef940(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00aef140(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 22705 ; VA 0x00aef9b0 ; FUN_00aef9b0 */

void FUN_00aef9b0(void)

{
  int iVar1;
  
  if (DAT_01eec764 == 0) {
    iVar1 = FUN_00aeecb0();
    DAT_01eec764 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 22706 ; VA 0x00aef9d0 ; FUN_00aef9d0 */

int FUN_00aef9d0(int param_1,int param_2)

{
  return param_1 + param_2;
}



/* FUNCTION 22707 ; VA 0x00aef9e0 ; FUN_00aef9e0 */

int FUN_00aef9e0(uint param_1,int param_2,uint param_3,int param_4)

{
  char *pcVar1;
  uint uVar2;
  char *pcVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint uStack_8;
  
  uVar4 = 0;
  uVar6 = 0;
  uVar2 = 0;
  uVar5 = 0;
  uStack_8 = 0;
  if (param_1 < param_1 + param_2) {
    pcVar3 = (char *)(param_1 + 2);
    iVar7 = (((param_1 + param_2) - param_1) - 1 >> 4) + 1;
    do {
      uVar4 = (uVar6 << 5 | uVar6 >> 0x1b) ^ param_3 - (int)pcVar3[-2];
      uVar6 = (uVar4 << 5 | uVar4 >> 0x1b) + uVar5;
      uVar4 = ~(((int)pcVar3[-1] - param_3) + uStack_8) + uVar2;
      uVar2 = -((uVar2 << 0xf | uVar2 >> 0x11) + ((int)*pcVar3 ^ param_3)) ^ uVar4;
      pcVar1 = pcVar3 + 1;
      pcVar3 = pcVar3 + 0x10;
      uVar5 = ((uVar6 - (int)*pcVar1) + param_3) - (uVar5 << 0xf | uVar5 >> 0x11);
      iVar7 = iVar7 + -1;
      uStack_8 = uVar4;
    } while (iVar7 != 0);
  }
  return (uVar2 + uVar5 ^ uVar4 - uVar6) - param_4;
}



/* FUNCTION 22708 ; VA 0x00aefa80 ; FUN_00aefa80 */

uint FUN_00aefa80(void)

{
  int iVar1;
  
  iVar1 = FUN_00aeecb0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 22709 ; VA 0x00aefaa0 ; FUN_00aefaa0 */

uint FUN_00aefaa0(void)

{
  int iVar1;
  
  iVar1 = FUN_00aeecb0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 22710 ; VA 0x00aefac0 ; FUN_00aefac0 */

int * __thiscall
FUN_00aefac0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined8 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0d8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00af0010();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::MegaClusterInstance,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              SetImpl<void_(__thiscall_RBX::MegaClusterInstance::*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&)>
              ::vftable;
    *(undefined8 *)(puVar3 + 2) = param_5;
    puVar3[4] = param_6;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_7,param_8,param_9,param_10,param_11,param_11,0);
  *param_1 = (int)RBX::Reflection::
                  TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                  ::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::MegaClusterInstance,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                    ::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::MegaClusterInstance,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                    ::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22711 ; VA 0x00aefbc0 ; FUN_00aefbc0 */

undefined4 * __thiscall
FUN_00aefbc0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  
  uVar1 = FUN_00af0010();
  puVar2 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar2 != (undefined4 *)0x0) {
    *puVar2 = RBX::Reflection::
              PropDescriptor<class_RBX::MegaClusterInstance,class_RBX::BinaryString>::
              GetSetImpl<class_RBX::BinaryString_(__thiscall_RBX::MegaClusterInstance::*)(void)const_,void_(__thiscall_RBX::MegaClusterInstance::*)(class_RBX::BinaryString_const&)>
              ::vftable;
    *(undefined8 *)(puVar2 + 2) = param_4;
    puVar2[4] = param_5;
    *(undefined8 *)(puVar2 + 6) = param_6;
    puVar2[8] = param_7;
  }
  FUN_0089a430(uVar1,param_2,param_3);
  *param_1 = RBX::Reflection::PropDescriptor<class_RBX::MegaClusterInstance,class_RBX::BinaryString>
             ::vftable;
  return param_1;
}



/* FUNCTION 22712 ; VA 0x00aefc50 ; FUN_00aefc50 */

int * __thiscall
FUN_00aefc50(int *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d64cb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00af0010();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::MegaClusterInstance,float>::
              GetSetImpl<float_(__thiscall_RBX::MegaClusterInstance::*)(void)const_,void_(__thiscall_RBX::MegaClusterInstance::*)(float)>
              ::vftable;
    *(undefined8 *)(puVar3 + 2) = param_4;
    puVar3[4] = param_5;
    *(undefined8 *)(puVar3 + 6) = param_6;
    puVar3[8] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::MegaClusterInstance,float>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::MegaClusterInstance,float>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22713 ; VA 0x00aefd60 ; FUN_00aefd60 */

undefined4 * __thiscall FUN_00aefd60(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  uVar2 = FUN_00afe380();
  *param_1 = uVar2;
  iVar3 = FUN_00afe6f0();
  iVar1 = param_1[1];
  if (iVar1 == iVar3) {
    param_1[2] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 2);
    param_1[1] = 0;
  }
  param_1[2] = *param_2;
  param_1[1] = iVar3;
  return param_1;
}



/* FUNCTION 22714 ; VA 0x00aefdc0 ; FUN_00aefdc0 */

undefined4 * __thiscall FUN_00aefdc0(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  uVar2 = FUN_00afe4e0();
  *param_1 = uVar2;
  iVar3 = FUN_00afe7d0();
  iVar1 = param_1[1];
  if (iVar1 == iVar3) {
    param_1[2] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 2);
    param_1[1] = 0;
  }
  param_1[2] = *param_2;
  param_1[1] = iVar3;
  return param_1;
}



/* FUNCTION 22715 ; VA 0x00aefe20 ; FUN_00aefe20 */

int * __thiscall FUN_00aefe20(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00afe6f0();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 22716 ; VA 0x00aefe70 ; FUN_00aefe70 */

undefined4 * __thiscall FUN_00aefe70(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  uVar2 = FUN_00afe430();
  *param_1 = uVar2;
  iVar3 = FUN_00afe760();
  iVar1 = param_1[1];
  if (iVar1 == iVar3) {
    param_1[2] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 2);
    param_1[1] = 0;
  }
  param_1[2] = *param_2;
  param_1[1] = iVar3;
  return param_1;
}



/* FUNCTION 22717 ; VA 0x00aefed0 ; FUN_00aefed0 */

int * __thiscall FUN_00aefed0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00afe760();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 22718 ; VA 0x00aeff20 ; FUN_00aeff20 */

int * __thiscall FUN_00aeff20(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00afe7d0();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 22719 ; VA 0x00aeff70 ; FUN_00aeff70 */

int * __thiscall FUN_00aeff70(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00afe840();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 22720 ; VA 0x00aeffc0 ; FUN_00aeffc0 */

int * __thiscall FUN_00aeffc0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00afe8b0();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 22721 ; VA 0x00af0010 ; FUN_00af0010 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00af0010(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ebda0;
  pvStack_10 = ExceptionList;
  if (DAT_01eec7bc == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eec9d0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eec9d0);
      if (DAT_01eec9d0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00aff8c0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Terrain",0,uStack_20,0,0,0xb,0,0);
        _DAT_01eec9c8 = RBX::Creator<class_RBX::MegaClusterInstance>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01eec7c0,&DAT_01eec9c8);
        FUN_016f3654(FUN_0188c940);
        FUN_016f37bf(&DAT_01eec9d0);
      }
    }
    DAT_01eec7bc = &DAT_01eec7c0;
  }
  ExceptionList = pvStack_10;
  return DAT_01eec7bc;
}



/* FUNCTION 22722 ; VA 0x00af0110 ; FUN_00af0110 */

void __thiscall FUN_00af0110(int *param_1,undefined2 *param_2,undefined2 *param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  undefined2 *puVar6;
  undefined2 *puVar7;
  uint uVar8;
  undefined2 *puVar9;
  
  puVar7 = param_2;
  iVar5 = (int)param_3 - (int)param_2;
  uVar1 = iVar5 / 3;
  iVar4 = *param_1;
  uVar2 = (param_1[1] - iVar4) / 3;
  uVar3 = (param_1[2] - iVar4) / 3;
  if (uVar3 < uVar1) {
    param_2 = (undefined2 *)uVar2;
    if (0x55555555 < uVar1) {
LAB_00af0294:
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar8 = uVar1;
    if ((uVar3 <= 0x55555555 - (uVar3 >> 1)) && (uVar8 = (uVar3 >> 1) + uVar3, uVar8 < uVar1)) {
      uVar8 = uVar1;
    }
    if (iVar4 != 0) {
      FUN_00af4390(iVar4,uVar3);
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    if (uVar8 != 0) {
      if (0x55555555 < uVar8) goto LAB_00af0294;
      iVar4 = FUN_00af37c0(uVar8);
      *param_1 = iVar4;
      param_1[1] = iVar4;
      param_1[2] = uVar8 * 3 + *param_1;
    }
    puVar6 = (undefined2 *)*param_1;
    if (puVar7 != param_3) {
      do {
        *puVar6 = *puVar7;
        puVar9 = puVar7 + 1;
        puVar7 = (undefined2 *)((int)puVar7 + 3);
        *(undefined *)(puVar6 + 1) = *(undefined *)puVar9;
        puVar6 = (undefined2 *)((int)puVar6 + 3);
      } while (puVar7 != param_3);
      param_1[1] = (int)puVar6;
      return;
    }
  }
  else {
    if (uVar1 <= uVar2) {
      param_2 = (undefined2 *)uVar2;
      FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
      FUN_0170cc70(iVar4,puVar7,iVar5);
      param_1[1] = iVar4 + uVar1 * 3;
      return;
    }
    puVar9 = (undefined2 *)((int)param_2 + uVar2 * 3);
    param_2 = (undefined2 *)uVar2;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(iVar4,puVar7,(int)puVar9 - (int)puVar7);
    puVar6 = (undefined2 *)param_1[1];
    for (; puVar9 != param_3; puVar9 = (undefined2 *)((int)puVar9 + 3)) {
      *puVar6 = *puVar9;
      *(undefined *)(puVar6 + 1) = *(undefined *)(puVar9 + 1);
      puVar6 = (undefined2 *)((int)puVar6 + 3);
    }
  }
  param_1[1] = (int)puVar6;
  return;
}



/* FUNCTION 22723 ; VA 0x00af02a0 ; FUN_00af02a0 */

int __thiscall FUN_00af02a0(int *param_1,undefined2 *param_2,undefined2 *param_3)

{
  undefined2 *puVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined2 *puVar6;
  undefined2 *puVar7;
  uint uVar8;
  undefined2 *puVar9;
  int iVar10;
  undefined2 *puVar11;
  
  iVar2 = *param_1;
  iVar3 = (param_1[1] - *param_1) / 3;
  if (iVar3 == 0x55555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar4 = iVar3 + 1;
  uVar8 = (param_1[2] - *param_1) / 3;
  uVar5 = uVar4;
  if ((uVar8 <= 0x55555555 - (uVar8 >> 1)) && (uVar5 = (uVar8 >> 1) + uVar8, uVar5 < uVar4)) {
    uVar5 = uVar4;
  }
  puVar6 = (undefined2 *)FUN_00af37c0(uVar5);
  iVar2 = (((int)param_2 - iVar2) / 3) * 3;
  puVar1 = (undefined2 *)(iVar2 + (int)puVar6);
  *puVar1 = *param_3;
  *(undefined *)(puVar1 + 1) = *(undefined *)(param_3 + 1);
  puVar11 = (undefined2 *)param_1[1];
  puVar7 = (undefined2 *)*param_1;
  puVar9 = puVar6;
  if (param_2 == puVar11) {
    for (; puVar7 != puVar11; puVar7 = (undefined2 *)((int)puVar7 + 3)) {
      *puVar9 = *puVar7;
      *(undefined *)(puVar9 + 1) = *(undefined *)(puVar7 + 1);
      puVar9 = (undefined2 *)((int)puVar9 + 3);
    }
  }
  else {
    if (puVar7 != param_2) {
      do {
        *puVar9 = *puVar7;
        puVar11 = puVar7 + 1;
        puVar7 = (undefined2 *)((int)puVar7 + 3);
        *(undefined *)(puVar9 + 1) = *(undefined *)puVar11;
        puVar9 = (undefined2 *)((int)puVar9 + 3);
      } while (puVar7 != param_2);
      puVar11 = (undefined2 *)param_1[1];
    }
    if (param_2 != puVar11) {
      do {
        *(undefined2 *)((int)puVar1 + 3) = *param_2;
        puVar7 = param_2 + 1;
        param_2 = (undefined2 *)((int)param_2 + 3);
        *(undefined *)((int)puVar1 + 5) = *(undefined *)puVar7;
        puVar1 = (undefined2 *)((int)puVar1 + 3);
      } while (param_2 != puVar11);
    }
  }
  iVar3 = *param_1;
  if (iVar3 != 0) {
    uVar8 = ((param_1[2] - iVar3) / 3) * 3;
    iVar10 = iVar3;
    if (0xfff < uVar8) {
      iVar10 = *(int *)(iVar3 + -4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (iVar3 - iVar10) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar10,uVar8);
  }
  *param_1 = (int)puVar6;
  param_1[1] = (int)puVar6 + uVar4 * 3;
  param_1[2] = (int)puVar6 + uVar5 * 3;
  return *param_1 + iVar2;
}



/* FUNCTION 22724 ; VA 0x00af0420 ; FUN_00af0420 */

void FUN_00af0420(undefined8 *param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 uVar1;
  undefined4 uVar2;
  float fVar3;
  
  fVar3 = *(float *)(param_2 + 1);
  if (fVar3 < *(float *)(param_1 + 1)) {
    uVar1 = *param_2;
    uVar2 = *(undefined4 *)(param_2 + 1);
    *param_2 = *param_1;
    *(undefined4 *)(param_2 + 1) = *(undefined4 *)(param_1 + 1);
    *param_1 = uVar1;
    *(undefined4 *)(param_1 + 1) = uVar2;
    fVar3 = *(float *)(param_2 + 1);
  }
  if (*(float *)(param_3 + 1) <= fVar3 && fVar3 != *(float *)(param_3 + 1)) {
    uVar1 = *param_3;
    uVar2 = *(undefined4 *)(param_3 + 1);
    *param_3 = *param_2;
    *(undefined4 *)(param_3 + 1) = *(undefined4 *)(param_2 + 1);
    *param_2 = uVar1;
    *(undefined4 *)(param_2 + 1) = uVar2;
    if (*(float *)(param_2 + 1) <= *(float *)(param_1 + 1) &&
        *(float *)(param_1 + 1) != *(float *)(param_2 + 1)) {
      *param_2 = *param_1;
      *(undefined4 *)(param_2 + 1) = *(undefined4 *)(param_1 + 1);
      *param_1 = uVar1;
      *(undefined4 *)(param_1 + 1) = uVar2;
    }
  }
  return;
}



/* FUNCTION 22725 ; VA 0x00af04b0 ; FUN_00af04b0 */

void FUN_00af04b0(undefined4 *param_1,undefined8 *param_2,undefined8 *param_3,undefined8 *param_4)

{
  int iVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  int iVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  int iVar10;
  undefined8 *puVar11;
  undefined8 *puVar12;
  
  iVar1 = (int)param_3 + -0xc;
  puVar8 = (undefined8 *)((int)param_2 + (((int)param_3 - (int)param_2) / 0xc >> 1) * 0xc);
  iVar4 = (iVar1 - (int)param_2) / 0xc;
  if (iVar4 < 0x29) {
    FUN_00af0420(param_2,puVar8,(int)param_3 + -0xc,param_4);
  }
  else {
    iVar4 = iVar4 + 1 >> 3;
    iVar10 = iVar4 * 0xc;
    FUN_00af0420(param_2,iVar10 + (int)param_2,param_2 + iVar4 * 3,param_4);
    FUN_00af0420((int)puVar8 + iVar4 * -0xc,puVar8,iVar10 + (int)puVar8,param_4);
    iVar7 = iVar1 + iVar4 * -0xc;
    FUN_00af0420(iVar1 + iVar4 * -0x18,iVar7,iVar1,param_4);
    FUN_00af0420((int)param_2 + iVar10,puVar8,iVar7,param_4);
  }
  puVar11 = (undefined8 *)((int)puVar8 + 0xc);
  for (; param_2 < puVar8; puVar8 = (undefined8 *)((int)puVar8 + -0xc)) {
    if ((*(float *)((int)puVar8 + -4) < *(float *)(puVar8 + 1)) ||
       (*(float *)(puVar8 + 1) < *(float *)((int)puVar8 + -4))) break;
  }
  puVar12 = puVar11;
  param_4 = puVar8;
  if (puVar11 < param_3) {
    do {
      puVar12 = puVar11;
      if ((*(float *)(puVar11 + 1) < *(float *)(puVar8 + 1)) ||
         (*(float *)(puVar8 + 1) < *(float *)(puVar11 + 1))) break;
      puVar11 = (undefined8 *)((int)puVar11 + 0xc);
      puVar12 = puVar11;
    } while (puVar11 < param_3);
  }
joined_r0x00af05c3:
  do {
    puVar5 = param_4;
    if (param_3 <= puVar11) {
joined_r0x00af0616:
      for (; param_2 < param_4; param_4 = (undefined8 *)((int)param_4 + -0xc)) {
        puVar6 = (undefined8 *)((int)puVar5 + -0xc);
        puVar9 = puVar8;
        if (*(float *)(puVar8 + 1) <= *(float *)((int)puVar5 + -4)) {
          if (*(float *)(puVar8 + 1) < *(float *)((int)puVar5 + -4)) break;
          puVar9 = (undefined8 *)((int)puVar8 + -0xc);
          if (puVar9 != puVar6) {
            uVar3 = *(undefined4 *)((int)puVar8 + -4);
            uVar2 = *puVar9;
            *puVar9 = *puVar6;
            *(undefined4 *)((int)puVar8 + -4) = *(undefined4 *)((int)puVar5 + -4);
            *puVar6 = uVar2;
            *(undefined4 *)((int)puVar5 + -4) = uVar3;
          }
        }
        puVar8 = puVar9;
        puVar5 = puVar6;
      }
      if (param_4 == param_2) {
        if (puVar11 == param_3) {
          param_1[1] = puVar12;
          *param_1 = puVar8;
          return;
        }
        if (puVar12 != puVar11) {
          uVar2 = *puVar8;
          uVar3 = *(undefined4 *)(puVar8 + 1);
          *puVar8 = *puVar12;
          *(undefined4 *)(puVar8 + 1) = *(undefined4 *)(puVar12 + 1);
          *puVar12 = uVar2;
          *(undefined4 *)(puVar12 + 1) = uVar3;
        }
        uVar3 = *(undefined4 *)(puVar8 + 1);
        uVar2 = *puVar8;
        *puVar8 = *puVar11;
        *(undefined4 *)(puVar8 + 1) = *(undefined4 *)(puVar11 + 1);
        *puVar11 = uVar2;
        *(undefined4 *)(puVar11 + 1) = uVar3;
        puVar11 = (undefined8 *)((int)puVar11 + 0xc);
        puVar12 = (undefined8 *)((int)puVar12 + 0xc);
        puVar8 = (undefined8 *)((int)puVar8 + 0xc);
      }
      else {
        puVar5 = (undefined8 *)((int)param_4 + -0xc);
        if (puVar11 == param_3) {
          puVar9 = (undefined8 *)((int)puVar8 + -0xc);
          if (puVar5 != puVar9) {
            uVar2 = *puVar5;
            uVar3 = *(undefined4 *)((int)param_4 + -4);
            *puVar5 = *puVar9;
            *(undefined4 *)((int)param_4 + -4) = *(undefined4 *)((int)puVar8 + -4);
            *puVar9 = uVar2;
            *(undefined4 *)((int)puVar8 + -4) = uVar3;
          }
          uVar3 = *(undefined4 *)((int)puVar8 + -4);
          puVar6 = (undefined8 *)((int)puVar12 - 0xc);
          uVar2 = *puVar9;
          *puVar9 = *puVar6;
          *(undefined4 *)((int)puVar8 + -4) = *(undefined4 *)((int)puVar12 - 4);
          *puVar6 = uVar2;
          *(undefined4 *)((int)puVar12 - 4) = uVar3;
          puVar12 = puVar6;
          param_4 = puVar5;
          puVar8 = puVar9;
        }
        else {
          uVar3 = *(undefined4 *)(puVar11 + 1);
          uVar2 = *puVar11;
          *puVar11 = *puVar5;
          *(undefined4 *)(puVar11 + 1) = *(undefined4 *)((int)param_4 + -4);
          puVar11 = (undefined8 *)((int)puVar11 + 0xc);
          *puVar5 = uVar2;
          *(undefined4 *)((int)param_4 + -4) = uVar3;
          param_4 = puVar5;
        }
      }
      goto joined_r0x00af05c3;
    }
    if (*(float *)(puVar11 + 1) <= *(float *)(puVar8 + 1)) {
      if (*(float *)(puVar11 + 1) < *(float *)(puVar8 + 1)) goto joined_r0x00af0616;
      if (puVar12 != puVar11) {
        uVar2 = *puVar12;
        uVar3 = *(undefined4 *)(puVar12 + 1);
        *puVar12 = *puVar11;
        *(undefined4 *)(puVar12 + 1) = *(undefined4 *)(puVar11 + 1);
        *puVar11 = uVar2;
        *(undefined4 *)(puVar11 + 1) = uVar3;
      }
      puVar12 = (undefined8 *)((int)puVar12 + 0xc);
    }
    puVar11 = (undefined8 *)((int)puVar11 + 0xc);
  } while( true );
}



/* FUNCTION 22726 ; VA 0x00af0770 ; FUN_00af0770 */

void FUN_00af0770(int param_1,int param_2,uint param_3,undefined8 *param_4)

{
  float *pfVar1;
  float fVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  iVar5 = (int)(param_3 - 1) >> 1;
  iVar4 = param_2;
  iVar3 = param_2;
  if (param_2 < iVar5) {
    do {
      fVar2 = *(float *)(param_1 + 0x14 + iVar4 * 0x18);
      pfVar1 = (float *)(param_1 + 0x20 + iVar4 * 0x18);
      iVar3 = iVar4 * 2 + ((*pfVar1 <= fVar2 && fVar2 != *pfVar1) ^ 1) + 1;
      *(undefined8 *)(param_1 + iVar4 * 0xc) = *(undefined8 *)(param_1 + iVar3 * 0xc);
      *(undefined4 *)(param_1 + 8 + iVar4 * 0xc) = *(undefined4 *)(param_1 + 8 + iVar3 * 0xc);
      iVar4 = iVar3;
    } while (iVar3 < iVar5);
  }
  if ((iVar3 == iVar5) && ((param_3 & 1) == 0)) {
    *(undefined8 *)(param_1 + iVar3 * 0xc) = *(undefined8 *)(param_1 + -0xc + param_3 * 0xc);
    *(undefined4 *)(param_1 + 8 + iVar3 * 0xc) = *(undefined4 *)(param_1 + -4 + param_3 * 0xc);
    iVar3 = param_3 - 1;
  }
  while ((param_2 < iVar3 &&
         (iVar4 = iVar3 + -1 >> 1, pfVar1 = (float *)(param_1 + 8 + iVar4 * 0xc),
         *pfVar1 <= *(float *)(param_4 + 1) && *(float *)(param_4 + 1) != *pfVar1))) {
    *(undefined8 *)(param_1 + iVar3 * 0xc) = *(undefined8 *)(param_1 + iVar4 * 0xc);
    *(undefined4 *)(param_1 + 8 + iVar3 * 0xc) = *(undefined4 *)(param_1 + 8 + iVar4 * 0xc);
    iVar3 = iVar4;
  }
  *(undefined8 *)(param_1 + iVar3 * 0xc) = *param_4;
  *(undefined4 *)(param_1 + 8 + iVar3 * 0xc) = *(undefined4 *)(param_4 + 1);
  return;
}



/* FUNCTION 22727 ; VA 0x00af0850 ; FUN_00af0850 */

void __thiscall FUN_00af0850(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ebdb0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::Voxel2::Grid>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 22728 ; VA 0x00af08be ; Catch_All@00af08be */

void Catch_All_00af08be(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00af3060(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 22729 ; VA 0x00af08e0 ; FUN_00af08e0 */

int __thiscall FUN_00af08e0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ebdc0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::TerrainRegion*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 22730 ; VA 0x00af09b2 ; Catch_All@00af09b2 */

void Catch_All_00af09b2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 22731 ; VA 0x00af09d0 ; FUN_00af09d0 */

undefined8 * FUN_00af09d0(undefined8 *param_1,undefined8 *param_2,int param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  float *pfVar3;
  float fVar4;
  float fVar5;
  undefined8 uVar6;
  undefined4 uVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  int iVar10;
  undefined8 *puVar11;
  int iVar12;
  undefined8 *puVar13;
  undefined8 *puVar14;
  undefined8 *puVar15;
  undefined8 *puVar16;
  undefined8 uStack_24;
  undefined8 *puStack_1c;
  undefined8 uStack_18;
  undefined8 *puStack_10;
  undefined8 *puStack_c;
  undefined8 *puStack_8;
  
  iVar10 = (int)param_2 - (int)param_1;
  puVar14 = param_2;
  puVar16 = param_1;
  iVar12 = param_3;
  do {
    puVar9 = (undefined8 *)(iVar10 / 0xc);
    param_2 = puVar14;
    if ((int)puVar9 < 0x21) {
LAB_00af0a99:
      if (((1 < (int)puVar9) && (puVar16 != puVar14)) &&
         (puVar15 = (undefined8 *)((int)puVar16 + 0xc), puVar9 = puVar14, puVar15 != puVar14)) {
        iVar12 = 0xc;
        do {
          puStack_8 = *(undefined8 **)(puVar15 + 1);
          uStack_18 = *puVar15;
          if (*(float *)(puVar16 + 1) <= (float)puStack_8) {
            fVar5 = *(float *)((int)puVar16 + iVar12 + -4);
            puVar13 = (undefined8 *)(iVar12 + -0xc + (int)puVar16);
            puVar14 = puVar15;
            while (puVar8 = puVar13, (float)puStack_8 < fVar5) {
              *puVar14 = *puVar8;
              *(undefined4 *)(puVar14 + 1) = *(undefined4 *)(puVar8 + 1);
              puVar13 = (undefined8 *)((int)puVar8 + -0xc);
              puVar9 = param_2;
              puVar14 = puVar8;
              fVar5 = *(float *)((int)puVar8 + -4);
            }
            *puVar14 = uStack_18;
            *(undefined8 **)(puVar14 + 1) = puStack_8;
          }
          else {
            FUN_0055b6b0((int)&param_1 + 3,&puStack_1c,&puStack_1c);
            FUN_0170cc70((int)puVar16 + 0xc,puVar16,iVar12);
            *puVar16 = uStack_18;
            *(undefined8 **)(puVar16 + 1) = puStack_8;
            puVar9 = param_2;
          }
          puVar15 = (undefined8 *)((int)puVar15 + 0xc);
          iVar12 = iVar12 + 0xc;
        } while (puVar15 != puVar9);
      }
      return puVar9;
    }
    if (iVar12 < 1) {
      if (0x20 < (int)puVar9) {
        puVar9 = (undefined8 *)(((int)puVar14 - (int)puVar16) * 0x2aaaaaab);
        puVar15 = (undefined8 *)(((int)puVar14 - (int)puVar16) / 0xc);
        puVar13 = (undefined8 *)((int)puVar15 >> 1);
        if (0 < (int)puVar13) {
          puStack_10 = (undefined8 *)((int)puVar15 - 1);
          param_1 = (undefined8 *)((int)puStack_10 >> 1);
          puVar8 = (undefined8 *)((int)puVar16 + (int)puVar13 * 0xc);
          do {
            uVar6 = *(undefined8 *)((int)puVar8 + -0xc);
            puVar9 = (undefined8 *)((int)puVar8 + -0xc);
            puVar13 = (undefined8 *)((int)puVar13 + -1);
            fVar5 = *(float *)((int)puVar8 + -4);
            uStack_18 = CONCAT44(fVar5,(undefined4)uStack_18);
            puVar8 = puVar13;
            while ((int)puVar8 < (int)param_1) {
              fVar4 = *(float *)((int)puVar16 + (int)puVar8 * 0x18 + 0x14);
              puVar11 = (undefined8 *)
                        ((int)puVar8 * 2 +
                        ((*(float *)(puVar16 + (int)puVar8 * 3 + 4) <= fVar4 &&
                         fVar4 != *(float *)(puVar16 + (int)puVar8 * 3 + 4)) ^ 1) + 1);
              puVar1 = (undefined4 *)((int)puVar16 + (int)puVar11 * 0xc);
              uVar7 = puVar1[1];
              puVar2 = (undefined4 *)((int)puVar16 + (int)puVar8 * 0xc);
              *puVar2 = *puVar1;
              puVar2[1] = uVar7;
              *(undefined4 *)((int)puVar16 + (int)puVar8 * 0xc + 8) =
                   *(undefined4 *)((int)puVar16 + (int)puVar11 * 0xc + 8);
              puVar8 = puVar11;
            }
            if ((puVar8 == param_1) && (((uint)puVar15 & 1) == 0)) {
              puVar2 = (undefined4 *)((int)puVar16 + (int)puVar15 * 0xc + -0xc);
              uVar7 = puVar2[1];
              puVar1 = (undefined4 *)((int)puVar16 + (int)puVar8 * 0xc);
              *puVar1 = *puVar2;
              puVar1[1] = uVar7;
              *(undefined4 *)((int)puVar16 + (int)puVar8 * 0xc + 8) =
                   *(undefined4 *)((int)puVar16 + (int)puVar15 * 0xc + -4);
              puVar8 = puStack_10;
            }
            while (((int)puVar13 < (int)puVar8 &&
                   (puVar11 = (undefined8 *)((int)puVar8 + -1 >> 1),
                   pfVar3 = (float *)((int)puVar16 + (int)puVar11 * 0xc + 8),
                   *pfVar3 <= fVar5 && fVar5 != *pfVar3))) {
              puVar1 = (undefined4 *)((int)puVar16 + (int)puVar11 * 0xc);
              uVar7 = puVar1[1];
              puVar2 = (undefined4 *)((int)puVar16 + (int)puVar8 * 0xc);
              *puVar2 = *puVar1;
              puVar2[1] = uVar7;
              *(undefined4 *)((int)puVar16 + (int)puVar8 * 0xc + 8) =
                   *(undefined4 *)((int)puVar16 + (int)puVar11 * 0xc + 8);
              puVar8 = puVar11;
            }
            *(undefined8 *)((int)puVar16 + (int)puVar8 * 0xc) = uVar6;
            *(float *)((int)puVar16 + (int)puVar8 * 0xc + 8) = fVar5;
            puVar8 = puVar9;
            puStack_c = puVar13;
          } while (0 < (int)puVar13);
        }
        if ((int)puVar15 < 2) {
          return puVar9;
        }
        puVar14 = (undefined8 *)((int)puVar14 + -0xc);
        puStack_8 = puVar15;
        do {
          if (1 < (int)puVar15) {
            uStack_24 = *puVar14;
            puStack_1c = *(undefined8 **)(puVar14 + 1);
            *puVar14 = *puVar16;
            *(undefined4 *)(puVar14 + 1) = *(undefined4 *)(puVar16 + 1);
            FUN_00af0770(puVar16,0,((int)puVar14 - (int)puVar16) / 0xc,&uStack_24,param_4);
          }
          puVar14 = (undefined8 *)((int)puVar14 + -0xc);
          puVar15 = (undefined8 *)(((int)puVar14 + (0xc - (int)puVar16)) / 0xc);
        } while (1 < (int)puVar15);
        return puVar15;
      }
      goto LAB_00af0a99;
    }
    FUN_00af04b0((int)&uStack_24 + 4,puVar16,puVar14,param_4);
    iVar12 = (iVar12 >> 1) + (iVar12 >> 2);
    if (((int)uStack_24._4_4_ - (int)puVar16) / 0xc < ((int)puVar14 - (int)puStack_1c) / 0xc) {
      FUN_00af09d0(puVar16,uStack_24._4_4_,iVar12,param_4);
      puVar16 = puStack_1c;
    }
    else {
      FUN_00af09d0(puStack_1c,param_2,iVar12,param_4);
      param_2 = uStack_24._4_4_;
    }
    iVar10 = (int)param_2 - (int)puVar16;
    puVar14 = param_2;
  } while( true );
}



/* FUNCTION 22732 ; VA 0x00af0d20 ; FUN_00af0d20 */

undefined4 * FUN_00af0d20(undefined4 *param_1,undefined4 *param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ebe00;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b629b0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(100);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00b62e70(*param_2,param_3);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00af08e0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22733 ; VA 0x00af0df0 ; FUN_00af0df0 */

int * FUN_00af0df0(int *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4,
                  undefined4 param_5,undefined4 param_6,undefined4 *param_7)

{
  int *piVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  int *piVar17;
  int *piVar18;
  undefined **ppuStack_a0;
  undefined4 uStack_9c;
  int iStack_98;
  undefined4 uStack_80;
  undefined *puStack_7c;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017ebe32;
  pvStack_1c = ExceptionList;
  puStack_7c = (undefined *)0x1a8;
  uStack_80 = 0xaf0e2b;
  ExceptionList = &pvStack_1c;
  piVar17 = (int *)FUN_01674e20();
  iStack_14 = 0;
  if (piVar17 == (int *)0x0) {
    piVar17 = (int *)0x0;
  }
  else {
    puStack_7c = (undefined *)&ppuStack_a0;
    piVar17[1] = 1;
    piVar17[2] = 1;
    *piVar17 = (int)std::_Ref_count_obj<class_RBX::HeightmapImporter>::vftable;
    uVar5 = *param_3;
    uVar6 = param_3[1];
    uVar7 = param_3[2];
    uVar8 = param_3[3];
    uVar9 = param_3[4];
    uVar10 = param_3[5];
    uVar11 = param_3[6];
    uVar12 = param_3[7];
    uVar13 = param_3[8];
    uVar14 = param_3[9];
    uVar15 = param_3[10];
    uVar16 = param_3[0xb];
    uVar2 = *(undefined8 *)(param_3 + 0xc);
    uVar3 = param_3[0xe];
    iStack_98 = param_7[1];
    if (iStack_98 != 0) {
      LOCK();
      *(int *)(iStack_98 + 8) = *(int *)(iStack_98 + 8) + 1;
      UNLOCK();
      iStack_98 = param_7[1];
    }
    uStack_9c = *param_7;
    ppuStack_a0 = std::
                  _Func_impl_no_alloc<class_<lambda_944d125a0d3203046dac3810d4370bf8>,void,bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                  ::vftable;
    iStack_14._0_1_ = 1;
    iStack_14._1_3_ = 0;
    FUN_0054ef60();
    iStack_14._0_1_ = 2;
    FUN_0054ef60(param_4);
    if (param_2[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_2[1] + 8);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    iStack_14 = (uint)iStack_14._1_3_ << 8;
    FUN_00eaabe0(*param_2,param_2[1],uVar5,uVar6,uVar7,uVar8,uVar9,uVar10,uVar11,uVar12,uVar13,
                 uVar14,uVar15,uVar16,uVar2,uVar3);
  }
  piVar1 = piVar17 + 4;
  *param_1 = (int)piVar1;
  param_1[1] = (int)piVar17;
  if ((piVar1 != (int *)0x0) && ((piVar17[5] == 0 || (*(int *)(piVar17[5] + 4) == 0)))) {
    piVar18 = piVar17;
    if (piVar17 != (int *)0x0) {
      LOCK();
      piVar17[1] = piVar17[1] + 1;
      UNLOCK();
      piVar18 = (int *)param_1[1];
      if (piVar18 != (int *)0x0) {
        LOCK();
        piVar18[2] = piVar18[2] + 1;
        UNLOCK();
      }
    }
    *piVar1 = (int)piVar1;
    piVar1 = (int *)piVar17[5];
    piVar17[5] = (int)piVar18;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        puStack_7c = (undefined *)0xaf0f8b;
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piVar18 != (int *)0x0) {
      LOCK();
      iVar4 = piVar18[1] + -1;
      piVar18[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        puStack_7c = (undefined *)0xaf0f9f;
        (**(code **)*piVar18)();
        LOCK();
        piVar17 = piVar18 + 2;
        iVar4 = *piVar17;
        *piVar17 = *piVar17 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          puStack_7c = (undefined *)0xaf0fb1;
          (**(code **)(*piVar18 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_1c;
  return param_1;
}



/* FUNCTION 22734 ; VA 0x00af0fd0 ; thunk_FUN_00afe380 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00afe380(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ece46;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eecb9c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eecb9c);
    if (DAT_01eecb9c == -1) {
      uStack_8 = 0;
      FUN_009ca470("CellBlock");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eecb38 = RBX::Reflection::EnumDesc<enum_RBX::Voxel::CellBlock>::vftable;
      FUN_009caf20(&DAT_01d66af0,5);
      FUN_016f3654(&LAB_0188c860);
      FUN_016f37bf(&DAT_01eecb9c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eecb38;
}



/* FUNCTION 22735 ; VA 0x00af0fe0 ; thunk_FUN_00afe430 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00afe430(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ece66;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eecc04) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eecc04);
    if (DAT_01eecc04 == -1) {
      uStack_8 = 0;
      FUN_009ca470("CellMaterial");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eecba0 = RBX::Reflection::EnumDesc<enum_RBX::Voxel::CellMaterial>::vftable;
      FUN_009caf20(&DAT_01d66a60,0x12);
      FUN_016f3654(&LAB_0188c880);
      FUN_016f37bf(&DAT_01eecc04);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eecba0;
}



/* FUNCTION 22736 ; VA 0x00af0ff0 ; thunk_FUN_00afe4e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00afe4e0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ece86;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eecb34) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eecb34);
    if (DAT_01eecb34 == -1) {
      uStack_8 = 0;
      FUN_009ca470("CellOrientation");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eecad0 = RBX::Reflection::EnumDesc<enum_RBX::Voxel::CellOrientation>::vftable;
      FUN_009caf20(&DAT_01d66b18,4);
      FUN_016f3654(&LAB_0188c8a0);
      FUN_016f37bf(&DAT_01eecb34);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eecad0;
}



/* FUNCTION 22737 ; VA 0x00af1000 ; thunk_FUN_00afe590 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00afe590(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ecea6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeca64) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeca64);
    if (DAT_01eeca64 == -1) {
      uStack_8 = 0;
      FUN_009ca470("WaterDirection");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eeca00 = RBX::Reflection::EnumDesc<enum_RBX::Voxel::WaterCellDirection>::vftable;
      FUN_009caf20(&DAT_01d66b60,6);
      FUN_016f3654(&LAB_0188c8c0);
      FUN_016f37bf(&DAT_01eeca64);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeca00;
}



/* FUNCTION 22738 ; VA 0x00af1010 ; thunk_FUN_00afe640 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00afe640(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ecec6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eecacc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eecacc);
    if (DAT_01eecacc == -1) {
      uStack_8 = 0;
      FUN_009ca470("WaterForce");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eeca68 = RBX::Reflection::EnumDesc<enum_RBX::Voxel::WaterCellForce>::vftable;
      FUN_009caf20(&DAT_01d66b38,5);
      FUN_016f3654(&LAB_0188c8e0);
      FUN_016f37bf(&DAT_01eecacc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeca68;
}



/* FUNCTION 22739 ; VA 0x00af1020 ; FUN_00af1020 */

undefined4 FUN_00af1020(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_00af119d:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_00af119d;
  }
  iVar2 = FUN_00afe380();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_00af1148;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_00afe380();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_00aefe20(&param_3);
      iVar4 = FUN_00afe380();
      iStack_ec = iVar4;
      iVar5 = FUN_00afe380();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_00af1148:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_00afe380();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 22740 ; VA 0x00af1220 ; FUN_00af1220 */

undefined4 FUN_00af1220(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_00af139d:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_00af139d;
  }
  iVar2 = FUN_00afe430();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_00af1348;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_00afe430();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_00aefed0(&param_3);
      iVar4 = FUN_00afe430();
      iStack_ec = iVar4;
      iVar5 = FUN_00afe430();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_00af1348:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_00afe430();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 22741 ; VA 0x00af1420 ; FUN_00af1420 */

undefined4 FUN_00af1420(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_00af159d:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_00af159d;
  }
  iVar2 = FUN_00afe4e0();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_00af1548;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_00afe4e0();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_00aeff20(&param_3);
      iVar4 = FUN_00afe4e0();
      iStack_ec = iVar4;
      iVar5 = FUN_00afe4e0();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_00af1548:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_00afe4e0();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 22742 ; VA 0x00af1620 ; FUN_00af1620 */

undefined4 FUN_00af1620(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_00af179d:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_00af179d;
  }
  iVar2 = FUN_00afe590();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_00af1748;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_00afe590();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_00aeff70(&param_3);
      iVar4 = FUN_00afe590();
      iStack_ec = iVar4;
      iVar5 = FUN_00afe590();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_00af1748:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_00afe590();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 22743 ; VA 0x00af1820 ; FUN_00af1820 */

undefined4 FUN_00af1820(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_00af199d:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_00af199d;
  }
  iVar2 = FUN_00afe640();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_00af1948;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_00afe640();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_00aeffc0(&param_3);
      iVar4 = FUN_00afe640();
      iStack_ec = iVar4;
      iVar5 = FUN_00afe640();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_00af1948:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_00afe640();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 22744 ; VA 0x00af1a20 ; FUN_00af1a20 */

undefined4 * __thiscall
FUN_00af1a20(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 *param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ebe8b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_00af0010();
  FUN_009cb790(uVar1,param_4,param_6,param_7,param_8);
  *(undefined8 *)(param_1 + 0xe) = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::MegaClusterInstance,class_G3D::Vector3___cdecl(class_G3D::Vector3),1>
             ::vftable;
  param_1[0x10] = param_3;
  param_1[0x11] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar1 = FUN_0088d870();
  param_1[9] = uVar1;
  if (param_1[0x11] == 0) {
    uStack_e8 = FUN_00888530();
    iStack_e4 = 0;
    param_6 = &uStack_e8;
    uStack_8 = 3;
    uVar3 = 2;
  }
  else {
    param_6 = (undefined4 *)FUN_00912980(param_1[0x11]);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar3 = 1;
  }
  uStack_14 = uVar3;
  uVar1 = FUN_0088d870();
  uVar2 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar2,uVar1,param_6);
  if ((uVar3 & 2) != 0) {
    uVar3 = uVar3 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar3;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  if ((uVar3 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22745 ; VA 0x00af1b80 ; FUN_00af1b80 */

undefined4 * __thiscall FUN_00af1b80(undefined4 *param_1,int param_2)

{
  int *piVar1;
  undefined2 *puVar2;
  int *piVar3;
  undefined uVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  undefined2 *puVar10;
  bool bVar11;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  uint auStack_30 [3];
  undefined4 uStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ebf8c;
  pvStack_10 = ExceptionList;
  bVar11 = param_2 != 0;
  ExceptionList = &pvStack_10;
  if (bVar11) {
    ExceptionList = &pvStack_10;
    param_1[0x15] = &DAT_0194d2b8;
    param_1[0x26] = &DAT_0194d2c0;
    param_1[0x71] = RBX::IHasLocation::vftable;
    uStack_8 = 0;
  }
  uStack_14 = (uint)bVar11;
  uVar9 = (uint)bVar11;
  uStack_24 = 0x40800000;
  uStack_20 = 0x3f99999a;
  uStack_1c = 0x40000000;
  puStack_18 = param_1;
  FUN_00b00ef0(&uStack_24,0);
  *param_1 = RBX::DescribedCreatable<class_RBX::MegaClusterInstance,class_RBX::PartInstance>::
             vftable;
  param_1[0x16] =
       RBX::DescribedCreatable<class_RBX::MegaClusterInstance,class_RBX::PartInstance>::vftable;
  param_1[0x1e] =
       RBX::DescribedCreatable<class_RBX::MegaClusterInstance,class_RBX::PartInstance>::vftable;
  param_1[0x25] =
       RBX::DescribedCreatable<class_RBX::MegaClusterInstance,class_RBX::PartInstance>::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::DescribedCreatable<class_RBX::MegaClusterInstance,class_RBX::PartInstance>::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xa8;
  uVar5 = FUN_00af0010();
  param_1[3] = uVar5;
  param_1[0x3e] = RBX::Voxel2::GridListener::vftable;
  *param_1 = RBX::MegaClusterInstance::vftable;
  param_1[0x16] = RBX::MegaClusterInstance::vftable;
  param_1[0x1e] = RBX::MegaClusterInstance::vftable;
  param_1[0x25] = RBX::MegaClusterInstance::vftable;
  param_1[0x3e] = RBX::MegaClusterInstance::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::MegaClusterInstance::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0x170
  ;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  param_1[0x41] = 0x3f800000;
  param_1[0x42] = 0;
  param_1[0x43] = 0;
  param_1[0x44] = 0;
  param_1[0x45] = 0x3f800000;
  param_1[0x46] = 0;
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  param_1[0x49] = 0x3f800000;
  param_1[0x4a] = 0;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  param_1[0x4d] = 0;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  param_1[0x50] = 0x3d4ccccd;
  param_1[0x51] = 0x3ea8f5c3;
  param_1[0x52] = 0x3eb851ec;
  param_1[0x53] = 0x3e99999a;
  param_1[0x54] = 0x41200000;
  param_1[0x55] = 0x3e19999a;
  param_1[0x56] = 0x3f800000;
  *(undefined *)(param_1 + 0x57) = 0;
  param_1[0x58] = 0;
  param_1[0x59] = 0;
  param_1[0x5a] = 0;
  param_1[0x5b] = 0;
  param_1[0x5c] = 0;
  param_1[0x5d] = 0;
  param_1[0x5e] = 0;
  param_1[0x5f] = 0;
  param_1[0x60] = 0;
  param_1[0x68] = 0;
  uStack_8._0_1_ = 0xc;
  uStack_8._1_3_ = 0;
  if (DAT_01d6517b != '\0') {
    FUN_016774b0(DAT_01d6517b,"MegaCluster created - %p",param_1);
  }
  uStack_3c = 0x44ff8000;
  uStack_38 = 0x437c0000;
  uStack_34 = 0x44ff8000;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("Terrain",7);
  uStack_8._0_1_ = 0xd;
  FUN_008a6520(&DAT_01d66a1c);
  uStack_8._0_1_ = 0xc;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xc;
  if (0xf < uStack_1c) {
    uVar7 = uStack_1c + 1;
    uVar8 = auStack_30[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_30[0] - 4);
      uVar7 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  FUN_00b0e890(&uStack_3c);
  FUN_00b0ca50(1);
  FUN_00b0e790(1);
  FUN_00b0daf0(0x3e99999a);
  FUN_00b0db40(0x3f000000);
  iVar6 = FUN_01674e20(0x2c);
  uStack_8._0_1_ = 0xe;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xe;
  if (iVar6 == 0) {
    uVar5 = 0;
    uStack_8._0_1_ = uVar4;
  }
  else {
    uVar5 = FUN_008cb670(auStack_30,&DAT_01d66a44);
    uVar9 = uVar9 | 2;
    uStack_8._0_1_ = 0xf;
    uStack_14 = uVar9;
    uVar5 = FUN_00d58eb0(uVar5,0x40);
  }
  iVar6 = param_1[0x4f];
  param_1[0x4f] = uVar5;
  if (iVar6 != 0) {
    FUN_00d59010();
    FUN_01674ea0(iVar6,0x2c);
  }
  uStack_8 = 0xc;
  if ((uVar9 & 2) != 0) {
    uStack_14 = uVar9 & 0xfffffffd;
    if (0xf < uStack_1c) {
      uVar8 = uStack_1c + 1;
      uVar9 = auStack_30[0];
      if (0xfff < uVar8) {
        uVar9 = *(uint *)(auStack_30[0] - 4);
        uVar8 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar8);
    }
  }
  uVar9 = 0;
  param_2 = 0;
  do {
    iVar6 = *(int *)(param_1[0x4f] + 0x14);
    *(undefined4 *)(iVar6 + 0x14 + param_2) = *(undefined4 *)((int)&DAT_0194cdb0 + uVar9);
    puVar10 = (undefined2 *)(iVar6 + 0x1c + param_2);
    *(undefined4 *)(iVar6 + 0x18 + param_2) = *(undefined4 *)((int)&DAT_0194cdb4 + uVar9);
    puVar2 = (undefined2 *)param_1[0x5c];
    if ((undefined2 *)param_1[0x5d] == puVar2) {
      FUN_00af02a0(puVar2,puVar10);
    }
    else {
      *puVar2 = *puVar10;
      *(undefined *)(puVar2 + 1) = *(undefined *)(puVar10 + 1);
      param_1[0x5c] = param_1[0x5c] + 3;
    }
    puVar2 = (undefined2 *)param_1[0x59];
    if ((undefined2 *)param_1[0x5a] == puVar2) {
      FUN_00af02a0(puVar2,puVar10);
    }
    else {
      *puVar2 = *puVar10;
      *(undefined *)(puVar2 + 1) = *(undefined *)(puVar10 + 1);
      param_1[0x59] = param_1[0x59] + 3;
    }
    uVar9 = uVar9 + 8;
    param_2 = param_2 + 0x20;
  } while (uVar9 < 0xb8);
  FUN_00d58780();
  iVar6 = FUN_01674e20(0x28);
  uStack_8._0_1_ = 0x11;
  if (iVar6 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_00a6dc70();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  uStack_20 = 0;
  uStack_1c = 0;
  FUN_00af0850(uVar5,iVar6);
  param_1[0x4d] = uStack_20;
  piVar3 = (int *)param_1[0x4e];
  param_1[0x4e] = uStack_1c;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar6 = piVar3[1] + -1;
    piVar3[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_00c18400(10);
  FUN_00a6e300(param_1 + 0x3e);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 22746 ; VA 0x00af20e0 ; FUN_00af20e0 */

void __fastcall FUN_00af20e0(int param_1)

{
  if (*(int *)(param_1 + 0x58) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x58),4);
  }
  if (*(int *)(param_1 + 0x54) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x54),4);
  }
  if (*(int *)(param_1 + 0x50) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x50),4);
  }
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 22747 ; VA 0x00af2160 ; FUN_00af2160 */

void __fastcall FUN_00af2160(int param_1)

{
  if (*(int *)(param_1 + 0x54) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x54),4);
  }
  if (*(int *)(param_1 + 0x50) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x50),4);
  }
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 22748 ; VA 0x00af21d0 ; FUN_00af21d0 */

void __fastcall FUN_00af21d0(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),1);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),6);
  }
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 22749 ; VA 0x00af2240 ; FUN_00af2240 */

void __fastcall FUN_00af2240(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar2 = *(int *)(param_1 + 0x50);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,8);
  }
  iVar2 = *(int *)(param_1 + 0x4c);
  if (iVar2 != 0) {
    piVar3 = *(int **)(iVar2 + 4);
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar2,8);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0x3c);
  }
  FUN_009cb8b0();
  return;
}


