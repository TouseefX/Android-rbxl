/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 17750 ; VA 0x0097b7a0 ; FUN_0097b7a0 */

code * __thiscall FUN_0097b7a0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017cfad0;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300(param_3);
  puVar3 = (undefined4 *)FUN_009d1340(auStack_38,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  pcStack_28 = *(code **)(param_1 + 0x38);
  uStack_14 = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar4 = (*pcStack_28)(auStack_30,*puVar3,puVar3[1]);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  pcStack_28 = (code *)FUN_009d5980(param_3,uVar4);
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar2 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_34[1] + -1;
    piStack_34[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piStack_34 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return pcStack_28;
}



/* FUNCTION 17751 ; VA 0x0097b8c0 ; FUN_0097b8c0 */

undefined4 __thiscall FUN_0097b8c0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_3);
  uVar4 = FUN_009d1940(param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  uVar3 = (**(code **)(param_1 + 0x38))(auStack_18,uVar4);
  uStack_8 = 0;
  uVar3 = FUN_009d5980(param_3,uVar3);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 17752 ; VA 0x0097b970 ; FUN_0097b970 */

undefined4 FUN_0097b970(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  int aiStack_50 [5];
  uint uStack_3c;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cfb00;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300();
  uVar4 = FUN_009d09d0(aiStack_50);
  uStack_8 = 0;
  uStack_18 = FUN_009d09d0(auStack_38,param_2,param_3,2,iVar3 - param_3,iStack_14 + 0x44);
  uStack_8._0_1_ = 1;
  puVar5 = (undefined4 *)FUN_009d1340(auStack_20,param_2,param_3,1,iVar3 - param_3,iStack_14 + 0x40)
  ;
  uStack_8._0_1_ = 2;
  pcVar2 = *(code **)(iStack_14 + 0x38);
  FUN_0054ef60(uVar4);
  uStack_8._0_1_ = 3;
  FUN_0054ef60(uStack_18);
  if (puVar5[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  (*pcVar2)(*puVar5,puVar5[1]);
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (0xf < uStack_24) {
    uVar6 = uStack_24 + 1;
    uVar7 = auStack_38[0];
    if (0xfff < uVar6) {
      uVar7 = *(uint *)(auStack_38[0] - 4);
      uVar6 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar6);
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  if (0xf < uStack_3c) {
    uVar7 = uStack_3c + 1;
    iVar3 = aiStack_50[0];
    if (0xfff < uVar7) {
      iVar3 = *(int *)(aiStack_50[0] + -4);
      uVar7 = uStack_3c + 0x24;
      if (0x1f < (aiStack_50[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar7);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 17753 ; VA 0x0097bb20 ; FUN_0097bb20 */

undefined4 __thiscall FUN_0097bb20(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  
  uVar1 = param_3;
  iVar3 = FUN_01256300(param_3);
  iVar3 = iVar3 - param_4;
  if (0 < iVar3) {
    uVar4 = FUN_005f3090();
    cVar2 = FUN_009d1e20(uVar4,uVar1,param_4 + 1,&param_3);
    uVar4 = param_3;
    if (cVar2 != '\0') goto LAB_0097bb76;
  }
  uVar4 = FUN_009671f0(uVar1,param_4,1,iVar3,param_1 + 0x40);
LAB_0097bb76:
  (**(code **)(param_1 + 0x38))(uVar4);
  return 0;
}



/* FUNCTION 17754 ; VA 0x0097bb90 ; FUN_0097bb90 */

undefined4 FUN_0097bb90(undefined4 param_1,undefined4 param_2,int param_3)

{
  undefined uVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uVar6;
  undefined8 uVar7;
  int iStack_170;
  int iStack_16c;
  int *piStack_168;
  int iStack_164;
  int iStack_160;
  undefined *puStack_15c;
  char *pcStack_158;
  undefined4 *puStack_154;
  undefined4 uStack_148;
  int iStack_144;
  undefined auStack_140 [200];
  int aiStack_78 [5];
  uint uStack_64;
  undefined auStack_60 [12];
  uint auStack_54 [4];
  undefined4 uStack_44;
  uint uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined *puStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017cfb33;
  pvStack_1c = ExceptionList;
  puStack_154 = (undefined4 *)param_2;
  pcStack_158 = (char *)0x97bbcf;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_01256300();
  pcStack_158 = (char *)((int)pcStack_28 + 0x50);
  iVar3 = iVar3 - param_3;
  iStack_160 = 5;
  iStack_164 = param_3;
  piStack_168 = (int *)param_2;
  iStack_16c = 0x97bbe9;
  puStack_15c = (undefined *)iVar3;
  uVar1 = FUN_009d1aa0();
  puStack_34 = (undefined *)CONCAT31(puStack_34._1_3_,uVar1);
  if (3 < iVar3) {
    puStack_154 = (undefined4 *)0x97bbfd;
    iStack_160 = FUN_005f32d0();
    puStack_154 = &uStack_2c;
    pcStack_158 = (char *)(param_3 + 4);
    puStack_15c = (undefined *)param_2;
    iStack_164 = 0x97bc0e;
    cVar2 = FUN_009d1e20();
    uStack_30 = uStack_2c;
    if (cVar2 != '\0') goto LAB_0097bcd1;
    if (3 < iVar3) {
      puStack_154 = (undefined4 *)0x97bc2b;
      uStack_148 = FUN_00888530();
      iStack_144 = 0;
      puStack_154 = (undefined4 *)0x1;
      pcStack_158 = (char *)&uStack_148;
      uStack_14 = 0;
      puStack_15c = (undefined *)(param_3 + 4);
      iStack_160 = param_2;
      iStack_164 = 0x97bc57;
      cVar2 = FUN_009d1bf0();
      if (cVar2 != '\0') {
        puStack_154 = (undefined4 *)0x97bc69;
        puVar4 = (undefined4 *)FUN_00915df0();
        uStack_30 = *puVar4;
        uStack_14 = 1;
        if (iStack_144 != 0) {
          puStack_154 = (undefined4 *)auStack_140;
          pcStack_158 = (char *)0x97bc8b;
          (**(code **)(iStack_144 + 8))();
        }
        uStack_14 = 0xffffffff;
        goto LAB_0097bcd1;
      }
      uStack_14 = 2;
      if (iStack_144 != 0) {
        puStack_154 = (undefined4 *)auStack_140;
        pcStack_158 = (char *)0x97bcb4;
        (**(code **)(iStack_144 + 8))();
      }
      uStack_14 = 0xffffffff;
    }
  }
  if (*(undefined4 **)((int)pcStack_28 + 0x4c) == (undefined4 *)0x0) {
    puStack_154 = (undefined4 *)0x4;
    puStack_15c = auStack_60;
    pcStack_158 = "Argument %d missing or nil";
    iStack_160 = 0x97be0b;
    FUN_016756b0();
    pcStack_158 = auStack_60;
    puStack_154 = (undefined4 *)&DAT_01c17198;
                    /* WARNING: Subroutine does not return */
    puStack_15c = (undefined *)0x97be1c;
    FUN_0170c2a8();
  }
  uStack_30 = **(undefined4 **)((int)pcStack_28 + 0x4c);
LAB_0097bcd1:
  puStack_154 = (undefined4 *)((int)pcStack_28 + 0x48);
  puStack_15c = (undefined *)0x3;
  iStack_160 = param_3;
  iStack_164 = param_2;
  piStack_168 = aiStack_78;
  iStack_16c = 0x97bce8;
  pcStack_158 = (char *)iVar3;
  uStack_2c = FUN_009d09d0();
  iStack_16c = (int)pcStack_28 + 0x44;
  uStack_14 = 3;
  iStack_170 = iVar3;
  uStack_38 = FUN_009d09d0(auStack_54,param_2,param_3,2);
  uStack_14._0_1_ = 4;
  uVar7 = FUN_009d1940(param_2,param_3,1,iVar3,(int)pcStack_28 + 0x40);
  uStack_3c = (undefined4)uVar7;
  puStack_154 = (undefined4 *)puStack_34;
  pcStack_28 = *(code **)((int)pcStack_28 + 0x38);
  pcStack_158 = (char *)uStack_30;
  puStack_34 = (undefined *)&iStack_170;
  FUN_0054ef60(uStack_2c);
  uStack_14._0_1_ = 5;
  FUN_0054ef60(uStack_38);
  uStack_14 = CONCAT31(uStack_14._1_3_,4);
  (*pcStack_28)(uStack_3c,(int)((ulonglong)uVar7 >> 0x20));
  if (0xf < uStack_40) {
    uVar5 = uStack_40 + 1;
    uVar6 = auStack_54[0];
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(auStack_54[0] - 4);
      uVar5 = uStack_40 + 0x24;
      if (0x1f < (auStack_54[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar5);
  }
  uStack_44 = 0;
  uStack_40 = 0xf;
  auStack_54[0] = auStack_54[0] & 0xffffff00;
  if (0xf < uStack_64) {
    uVar6 = uStack_64 + 1;
    iVar3 = aiStack_78[0];
    if (0xfff < uVar6) {
      iVar3 = *(int *)(aiStack_78[0] + -4);
      uVar6 = uStack_64 + 0x24;
      if (0x1f < (aiStack_78[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar6);
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 17755 ; VA 0x0097be30 ; FUN_0097be30 */

void __thiscall FUN_0097be30(int param_1,int *param_2,undefined4 *param_3)

{
  byte *pbVar1;
  uint uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  char cVar6;
  undefined4 *puVar7;
  int *piVar8;
  uint uVar9;
  uint uVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  
  uVar2 = param_3[4];
  puVar11 = param_3;
  if (0xf < (uint)param_3[5]) {
    puVar11 = (undefined4 *)*param_3;
  }
  uVar9 = 0;
  uVar10 = 0x811c9dc5;
  if (uVar2 != 0) {
    do {
      pbVar1 = (byte *)(uVar9 + (int)puVar11);
      uVar9 = uVar9 + 1;
      uVar10 = (*pbVar1 ^ uVar10) * 0x1000193;
    } while (uVar9 < uVar2);
  }
  iVar3 = *(int *)(param_1 + 0xc);
  uVar10 = *(uint *)(param_1 + 0x18) & uVar10;
  puVar11 = *(undefined4 **)(param_1 + 4);
  puVar4 = *(undefined4 **)(iVar3 + uVar10 * 8);
  puVar12 = puVar4;
  while( true ) {
    puVar7 = puVar11;
    if (puVar4 != puVar11) {
      puVar7 = (undefined4 *)**(undefined4 **)(uVar10 * 8 + 4 + iVar3);
    }
    if (puVar12 == puVar7) goto LAB_0097bf0a;
    piVar8 = puVar12 + 2;
    puVar7 = param_3;
    if (0xf < (uint)param_3[5]) {
      puVar7 = (undefined4 *)*param_3;
    }
    uVar9 = puVar12[7];
    uVar5 = puVar12[6];
    if (0xf < uVar9) {
      piVar8 = (int *)*piVar8;
    }
    cVar6 = FUN_0055c360(piVar8,uVar5,puVar7,uVar2);
    if (cVar6 != '\0') break;
    puVar12 = (undefined4 *)*puVar12;
  }
  piVar8 = puVar12 + 2;
  if (0xf < uVar9) {
    piVar8 = (int *)*piVar8;
  }
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  cVar6 = FUN_0055c360(param_3,uVar2,piVar8,uVar5);
  if (cVar6 != '\0') {
    puVar11 = puVar12;
  }
LAB_0097bf0a:
  *param_2 = (int)puVar11;
  return;
}



/* FUNCTION 17756 ; VA 0x0097bf20 ; FUN_0097bf20 */

int * __thiscall FUN_0097bf20(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  
  uVar4 = FUN_005e6570(param_3);
  iVar1 = (uVar4 & *(uint *)(param_1 + 0x18)) * 8;
  puVar2 = *(undefined4 **)(param_1 + 4);
  puVar3 = *(undefined4 **)(*(int *)(param_1 + 0xc) + iVar1);
  puVar5 = puVar3;
  while( true ) {
    puVar6 = puVar2;
    if (puVar3 != puVar2) {
      puVar6 = (undefined4 *)**(undefined4 **)(iVar1 + *(int *)(param_1 + 0xc) + 4);
    }
    if (puVar5 == puVar6) break;
    if ((puVar5[2] == *param_3) && (puVar5[3] == param_3[1])) {
      *param_2 = (int)puVar5;
      return param_2;
    }
    puVar5 = (undefined4 *)*puVar5;
  }
  *param_2 = (int)puVar2;
  return param_2;
}



/* FUNCTION 17757 ; VA 0x0097bf90 ; FUN_0097bf90 */

undefined4 FUN_0097bf90(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_0064e810(param_1);
  if ((iVar1 != 0) && (*(int *)(iVar1 + 0xf4) != 0)) {
    return *(undefined4 *)(*(int *)(iVar1 + 0xf4) + 100);
  }
  return 0;
}



/* FUNCTION 17758 ; VA 0x0097bfc0 ; FUN_0097bfc0 */

undefined4 FUN_0097bfc0(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_0064e810(param_1);
  if (iVar1 != 0) {
    return *(undefined4 *)(iVar1 + 0xf4);
  }
  return 0;
}



/* FUNCTION 17759 ; VA 0x0097bfe0 ; FUN_0097bfe0 */

undefined4 * FUN_0097bfe0(undefined4 *param_1,undefined4 param_2)

{
  char cVar1;
  
  cVar1 = FUN_0064a9e0(param_2,0);
  if (cVar1 != '\0') {
    *param_1 = 1;
    return param_1;
  }
  FUN_0068b1b0(param_1,param_2);
  return param_1;
}



/* FUNCTION 17760 ; VA 0x0097c020 ; FUN_0097c020 */

int * FUN_0097c020(int *param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  char cVar5;
  int iVar6;
  int iVar7;
  undefined4 *puVar8;
  int *piVar9;
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined auStack_24 [4];
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017cfb50;
  pvStack_10 = ExceptionList;
  bVar3 = false;
  bVar2 = false;
  uStack_20 = 0;
  ExceptionList = &pvStack_10;
  iVar6 = FUN_0064e810(param_3);
  if (iVar6 != 0) {
    piStack_14 = *(int **)(iVar6 + 0xbc);
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = *(int **)(iVar6 + 0xbc);
    }
    piStack_1c = *(int **)(iVar6 + 0xb8);
    piVar9 = (int *)*piStack_1c;
    iStack_8 = 0;
    if (piVar9 != (int *)piStack_1c[1]) {
      do {
        if ((*piVar9 == 0) ||
           (iVar6 = *(int *)(*piVar9 + 0xc), iVar7 = FUN_00913630(),
           (uint)*(ushort *)(iVar7 + 0x1da) <
           (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8))) {
          bVar2 = true;
          piStack_28 = (int *)0x0;
          puVar8 = &uStack_2c;
          iStack_18 = 0;
        }
        else {
          piStack_30 = (int *)piVar9[1];
          iStack_18 = *piVar9;
          if (piStack_30 != (int *)0x0) {
            LOCK();
            piStack_30[1] = piStack_30[1] + 1;
            UNLOCK();
            piStack_30 = (int *)piVar9[1];
          }
          bVar3 = true;
          puVar8 = &uStack_34;
        }
        piVar1 = (int *)puVar8[1];
        *puVar8 = 0;
        puVar8[1] = 0;
        if ((bVar2) && (bVar2 = false, piStack_28 != (int *)0x0)) {
          LOCK();
          iVar6 = piStack_28[1] + -1;
          piStack_28[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piStack_28)();
            LOCK();
            iVar6 = piStack_28[2] + -1;
            piStack_28[2] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*piStack_28 + 4))();
            }
          }
        }
        if ((bVar3) && (bVar3 = false, piStack_30 != (int *)0x0)) {
          LOCK();
          iVar6 = piStack_30[1] + -1;
          piStack_30[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piStack_30)();
            LOCK();
            iVar6 = piStack_30[2] + -1;
            piStack_30[2] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*piStack_30 + 4))();
            }
          }
        }
        iStack_8._0_1_ = 1;
        if (iStack_18 != 0) {
          FUN_00927d30(auStack_24);
          cVar5 = FUN_00a33d60(param_2);
          piVar4 = piStack_14;
          if (cVar5 != '\0') {
            *param_1 = iStack_18;
            param_1[1] = (int)piVar1;
            if (piStack_14 != (int *)0x0) {
              LOCK();
              iVar6 = piStack_14[1] + -1;
              piStack_14[1] = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                (**(code **)*piStack_14)();
                LOCK();
                piVar9 = piVar4 + 2;
                iVar6 = *piVar9;
                *piVar9 = *piVar9 + -1;
                UNLOCK();
                if (iVar6 == 1) {
                  (**(code **)(*piVar4 + 4))();
                }
              }
            }
            ExceptionList = pvStack_10;
            return param_1;
          }
        }
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar6 = piVar1[1] + -1;
          piVar1[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar6 = piVar1[2] + -1;
            piVar1[2] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        piVar9 = piVar9 + 2;
      } while (piVar9 != (int *)piStack_1c[1]);
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_14[1] + -1;
      piStack_14[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar9 = piStack_14 + 2;
        iVar6 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  *param_1 = 0;
  param_1[1] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17761 ; VA 0x0097c260 ; FUN_0097c260 */

/* WARNING: Removing unreachable block (ram,0x0097c35c) */
/* WARNING: Removing unreachable block (ram,0x0097c3bf) */
/* WARNING: Removing unreachable block (ram,0x0097c327) */
/* WARNING: Removing unreachable block (ram,0x0097c330) */
/* WARNING: Removing unreachable block (ram,0x0097c33f) */
/* WARNING: Removing unreachable block (ram,0x0097c34e) */
/* WARNING: Removing unreachable block (ram,0x0097c36c) */
/* WARNING: Removing unreachable block (ram,0x0097c38f) */
/* WARNING: Removing unreachable block (ram,0x0097c398) */
/* WARNING: Removing unreachable block (ram,0x0097c3a6) */

undefined4
FUN_0097c260(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cfb78;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0096ee10(param_2,param_3,param_4,param_5,param_6,param_7,param_8,
                       CONCAT44(param_10,param_9),param_11,param_12);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 17762 ; VA 0x0097c3d0 ; FUN_0097c3d0 */

void FUN_0097c3d0(undefined4 param_1,undefined4 param_2)

{
  FUN_00967040(param_1,param_2,param_2);
  return;
}



/* FUNCTION 17763 ; VA 0x0097c3f0 ; FUN_0097c3f0 */

/* WARNING: Removing unreachable block (ram,0x0097c48b) */
/* WARNING: Removing unreachable block (ram,0x0097c499) */
/* WARNING: Removing unreachable block (ram,0x0097c4cf) */
/* WARNING: Removing unreachable block (ram,0x0097c4a9) */

void FUN_0097c3f0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)*param_2;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088cb40();
  if (iVar1 == iVar2) {
    FUN_0054ef60();
    uStack_8 = 0;
    FUN_006ecaa0(uStack_2c,uStack_28,uStack_24,uStack_20,CONCAT44(uStack_18,uStack_1c));
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 17764 ; VA 0x0097c4e0 ; FUN_0097c4e0 */

void FUN_0097c4e0(undefined4 param_1,undefined4 param_2)

{
  FUN_00966f00(param_1,param_2,param_2);
  return;
}



/* FUNCTION 17765 ; VA 0x0097c500 ; FUN_0097c500 */

/* WARNING: Removing unreachable block (ram,0x0097c5cc) */
/* WARNING: Removing unreachable block (ram,0x0097c5da) */
/* WARNING: Removing unreachable block (ram,0x0097c61a) */
/* WARNING: Removing unreachable block (ram,0x0097c5ea) */

void FUN_0097c500(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_2;
  iVar2 = *piVar1;
  ExceptionList = &pvStack_10;
  iVar3 = thunk_FUN_0086f380();
  if (iVar2 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  piVar4 = piVar1 + 2;
  if (piVar1[1] == 0) {
    piVar4 = (int *)0x0;
  }
  iVar2 = *piVar4;
  iVar3 = *(int *)(*param_2 + 0xd0);
  iVar5 = FUN_0088cb40();
  if (iVar3 != iVar5) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  FUN_0054ef60();
  uStack_8 = 0;
  FUN_006ecd90(iVar2,uStack_30,uStack_2c,uStack_28,uStack_24,CONCAT44(uStack_1c,uStack_20));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17766 ; VA 0x0097c620 ; FUN_0097c620 */

void FUN_0097c620(undefined4 param_1,undefined4 param_2)

{
  FUN_00966da0(param_1,param_2,param_2);
  return;
}



/* FUNCTION 17767 ; VA 0x0097c640 ; FUN_0097c640 */

void FUN_0097c640(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar2 = FUN_0088da50();
  if (iVar1 == iVar2) {
    piVar3 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_006150c0(*piVar3,piVar3[1]);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 17768 ; VA 0x0097c690 ; FUN_0097c690 */

int FUN_0097c690(int param_1,int *param_2,int param_3,int *param_4,undefined4 param_5)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cfba0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0097fc00(&param_1,param_1,param_2);
  uStack_8 = 0;
  iVar5 = FUN_0097fc00(&param_3,param_3,param_4);
  piVar2 = param_4;
  piVar4 = param_2;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if ((param_1 != 0) && (param_3 != 0)) {
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    iVar5 = FUN_0096ebe0(param_1,param_2,param_3,param_4,param_5);
  }
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar5 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar2 = piVar4 + 1;
    iVar3 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar5 = (**(code **)*piVar4)();
      LOCK();
      piVar2 = piVar4 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar5 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 17769 ; VA 0x0097c7a0 ; FUN_0097c7a0 */

int __thiscall
FUN_0097c7a0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cfbc8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_20);
  uStack_8._0_1_ = 1;
  iVar3 = FUN_0097fc00(&iStack_18,param_4,param_5);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if ((iStack_20 != 0) && (iStack_18 != 0)) {
    iVar3 = FUN_00917170(param_1);
    if (iVar3 != 0) {
      iVar3 = FUN_00bf30b0(&iStack_20,&iStack_18,param_6);
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piStack_1c + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iVar3 = (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 17770 ; VA 0x0097c890 ; FUN_0097c890 */

int FUN_0097c890(int param_1,int *param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cfbf0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0097fc00(&iStack_18,param_1,param_2);
  uStack_8 = 0;
  iVar4 = FUN_0097fc00(&param_1,param_3,param_4);
  piVar2 = param_2;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if ((iStack_18 != 0) && (param_1 != 0)) {
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
    iVar4 = FUN_0092ed20(param_1,param_2,param_5);
  }
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_14 + 1;
    iVar3 = *piVar2;
    iVar4 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar4 = (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piStack_14 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar4 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 17771 ; VA 0x0097c970 ; FUN_0097c970 */

bool FUN_0097c970(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  
  if (DAT_01d646e0 == '\0') {
    iVar2 = FUN_005c8880(param_1);
    if ((iVar2 != 0) && (cVar1 = FUN_0064a9e0(param_1,param_2), cVar1 == '\0')) {
      return true;
    }
  }
  else {
    iVar2 = FUN_008f78c0();
    if (iVar2 != 0) {
      if (((char)param_2 == '\0') && (*(int *)(iVar2 + 0x4a0) == 1)) {
        return true;
      }
      cVar1 = FUN_0064a9e0(iVar2 + 0xc,param_2);
      return cVar1 == '\0';
    }
  }
  return false;
}



/* FUNCTION 17772 ; VA 0x0097c9e0 ; FUN_0097c9e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void * __thiscall FUN_0097c9e0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  void *pvVar11;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cfc08;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0xf4) == 0) {
    pvVar11 = ExceptionList;
    if (*(int *)(param_1 + 0xc0) != 0) {
      ExceptionList = &pvStack_10;
      FUN_00607880(&piStack_1c);
      uStack_8 = 0;
      auStack_14[0] = 0x8b;
      FUN_006ad5e0(auStack_14,1);
      FUN_006ae570(param_2);
      uVar10 = (**(code **)(*piStack_1c + 8))();
      FUN_00971460(uVar10);
      uVar9 = uRam01ee2fe4;
      uVar8 = uRam01ee2fe0;
      uVar7 = uRam01ee2fdc;
      uVar6 = _DAT_01ee2fd8;
      uVar5 = uRam01ee2fd4;
      uVar4 = uRam01ee2fd0;
      uVar3 = uRam01ee2fcc;
      uVar10 = _DAT_01ee2fc8;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      pvVar11 = (void *)FUN_006afb30(piStack_1c,piStack_18,1,2,2,uVar10,uVar3,uVar4,uVar5,uVar6,
                                     uVar7,uVar8,uVar9,1,0);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piVar1 = piStack_18 + 1;
        iVar2 = *piVar1;
        pvVar11 = (void *)*piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          pvVar11 = (void *)(**(code **)*piStack_18)();
          LOCK();
          piVar1 = piStack_18 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            pvVar11 = (void *)(**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
    ExceptionList = pvStack_10;
    return pvVar11;
  }
  ExceptionList = &pvStack_10;
  FUN_00550130("Only servers can produce game chat");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_20,&DAT_01c17198);
}



/* FUNCTION 17773 ; VA 0x0097cb00 ; FUN_0097cb00 */

int * FUN_0097cb00(int *param_1,int *param_2)

{
  code *pcVar1;
  int *piVar2;
  char cVar3;
  uint uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  int iVar9;
  undefined4 uVar10;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = (**(code **)*param_1)();
  if (uVar4 < 3) {
LAB_0097cca7:
    if ((undefined4 *)*param_2 != (undefined4 *)0x0) {
      ExceptionList = pvStack_10;
      return *(int **)*param_2;
    }
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",3);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  pcVar1 = *(code **)(*piVar2 + 0x38);
  uVar5 = FUN_005f3480();
  cVar3 = (*pcVar1)(3,uVar5,&param_1);
  if (cVar3 != '\0') {
    ExceptionList = pvStack_10;
    return param_1;
  }
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar3 = (**(code **)(*piVar2 + 4))(3,&iStack_ec);
  iVar9 = iStack_ec;
  if (cVar3 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
    goto LAB_0097cca7;
  }
  iVar6 = thunk_FUN_005f3480();
  iVar8 = iStack_ec;
  if (iVar9 == iVar6) {
    puVar7 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    if (puVar7 != (undefined4 *)0x0) goto LAB_0097cc52;
  }
  iVar6 = FUN_0088cb40();
  iVar9 = iStack_ec;
  if (iVar8 == iVar6) {
    iVar8 = FUN_0088cb40();
    if (iVar9 != iVar8) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar7 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    FUN_005f3480();
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    cVar3 = FUN_009cb180(puVar7,&param_1);
    if (cVar3 != '\0') {
      FUN_005ed7e0(&param_1);
      iVar9 = thunk_FUN_005f3480();
      iStack_ec = iVar9;
      iVar8 = thunk_FUN_005f3480();
      if (iVar9 != iVar8) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar7 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar7 = (undefined4 *)0x0;
      }
LAB_0097cc52:
      piVar2 = (int *)*puVar7;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return piVar2;
    }
  }
  thunk_FUN_005f3480();
  uVar5 = FUN_005543f0();
  uVar10 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar10,uVar5);
}



/* FUNCTION 17774 ; VA 0x0097cd30 ; FUN_0097cd30 */

int * FUN_0097cd30(int *param_1,int *param_2)

{
  code *pcVar1;
  int *piVar2;
  char cVar3;
  uint uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  int iVar9;
  undefined4 uVar10;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = (**(code **)*param_1)();
  if (uVar4 < 2) {
LAB_0097ced7:
    if ((undefined4 *)*param_2 != (undefined4 *)0x0) {
      ExceptionList = pvStack_10;
      return *(int **)*param_2;
    }
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  pcVar1 = *(code **)(*piVar2 + 0x38);
  uVar5 = FUN_005f3510();
  cVar3 = (*pcVar1)(2,uVar5,&param_1);
  if (cVar3 != '\0') {
    ExceptionList = pvStack_10;
    return param_1;
  }
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar3 = (**(code **)(*piVar2 + 4))(2,&iStack_ec);
  iVar9 = iStack_ec;
  if (cVar3 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
    goto LAB_0097ced7;
  }
  iVar6 = thunk_FUN_005f3510();
  iVar8 = iStack_ec;
  if (iVar9 == iVar6) {
    puVar7 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    if (puVar7 != (undefined4 *)0x0) goto LAB_0097ce82;
  }
  iVar6 = FUN_0088cb40();
  iVar9 = iStack_ec;
  if (iVar8 == iVar6) {
    iVar8 = FUN_0088cb40();
    if (iVar9 != iVar8) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar7 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    FUN_005f3510();
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    cVar3 = FUN_009cb180(puVar7,&param_1);
    if (cVar3 != '\0') {
      FUN_005ed890(&param_1);
      iVar9 = thunk_FUN_005f3510();
      iStack_ec = iVar9;
      iVar8 = thunk_FUN_005f3510();
      if (iVar9 != iVar8) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar7 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar7 = (undefined4 *)0x0;
      }
LAB_0097ce82:
      piVar2 = (int *)*puVar7;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return piVar2;
    }
  }
  thunk_FUN_005f3510();
  uVar5 = FUN_005543f0();
  uVar10 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar10,uVar5);
}



/* FUNCTION 17775 ; VA 0x0097cf80 ; FUN_0097cf80 */

undefined4 * FUN_0097cf80(undefined4 *param_1,undefined4 param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cfc39;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  uStack_8 = 0;
  FUN_00621ac0(param_2,param_1);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17776 ; VA 0x0097cfe0 ; FUN_0097cfe0 */

void FUN_0097cfe0(int param_1,int param_2,uint param_3)

{
  int *piVar1;
  undefined uVar2;
  int iVar3;
  uint in_stack_0000002c;
  undefined auStack_100 [24];
  undefined4 uStack_e8;
  undefined4 *puStack_e4;
  undefined auStack_e0 [28];
  undefined4 uStack_c4;
  undefined auStack_c0 [12];
  undefined4 uStack_b4;
  undefined *puStack_b0;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_70;
  char *pcStack_6c;
  undefined4 uStack_68;
  uint uStack_64;
  undefined *puStack_60;
  int iStack_5c;
  undefined *puStack_58;
  undefined *puStack_54;
  int iStack_50;
  undefined auStack_44 [24];
  undefined8 uStack_2c;
  undefined *puStack_24;
  undefined *puStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cfc88;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if ((param_2 < 1) && ((param_2 < 0 || (param_1 == 0)))) {
    uStack_68 = 0x39;
    puStack_54 = (undefined *)0x0;
    iStack_50 = 0xf;
    pcStack_6c = "Players:GetCharacterAppearanceAsync() got negative userId";
    uStack_64 = uStack_64 & 0xffffff00;
    uStack_70 = 0x97d03a;
    ExceptionList = &pvStack_10;
    FUN_005542c0();
    uStack_68 = 0x97d042;
    FUN_005e65e0();
  }
  else {
    puStack_54 = (undefined *)0x97d04d;
    ExceptionList = &pvStack_10;
    iStack_1c = FUN_00965f10();
    if (iStack_1c != 0) {
      iStack_50 = 0x97d062;
      iVar3 = FUN_00b74db0();
      if (*(int *)(iVar3 + 0x10) != 0) {
        uStack_2c = 0;
        puStack_54 = (undefined *)0x97d07a;
        iVar3 = FUN_008f7870();
        if (iVar3 == 0) {
          puStack_54 = (undefined *)(int)uStack_2c;
          iStack_50 = uStack_2c._4_4_;
        }
        else {
          piVar1 = *(int **)(iVar3 + 0x43c);
          puStack_54 = (undefined *)(*piVar1 - (int)piVar1);
          iStack_50 = piVar1[1] - (int)piVar1;
        }
        puStack_58 = (undefined *)param_2;
        puStack_60 = auStack_44;
        iStack_5c = param_1;
        uStack_64 = 0x97d0a7;
        FUN_00f53dc0();
        uVar2 = DAT_01ee2fe9;
        puStack_20 = (undefined *)&pcStack_6c;
        uStack_18 = CONCAT31(uStack_18._1_3_,DAT_01ee2fe9);
        puStack_e4 = &stack0x0000002c;
        uStack_70 = 0;
        uStack_8._0_1_ = 2;
        puStack_24 = auStack_e0;
        uStack_e8 = 0x97d0d6;
        FUN_0054f510();
        uStack_8._0_1_ = 3;
        FUN_0054f510(&param_3);
        uStack_8._0_1_ = 2;
        FUN_00965700(auStack_c0,FUN_0097d200,0,uStack_14,uVar2,0);
        uStack_c4 = 0x97d10b;
        FUN_00960ca0();
        uStack_8._0_1_ = 4;
        uStack_90 = 0;
        uStack_2c = CONCAT44(auStack_100,(int)uStack_2c);
        FUN_0054f510(&stack0x0000002c);
        uStack_8._0_1_ = 5;
        FUN_0054f510(&param_3);
        uStack_8._0_1_ = 4;
        FUN_00965700(auStack_e0,FUN_0097d200,0,uStack_14,uStack_18,1);
        puStack_e4 = (undefined4 *)0x97d164;
        FUN_00960ca0();
        uStack_90 = 7;
        uStack_94 = 0;
        uStack_8._0_1_ = 6;
        puStack_b0 = auStack_44;
        uStack_b4 = 0x97d17a;
        FUN_0054ef60();
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        puStack_b0 = (undefined *)0x97d186;
        FUN_00bcb620();
        iStack_50 = 0x97d18e;
        FUN_005507b0();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      puStack_58 = &stack0x00000014;
      iStack_50 = 2;
      iStack_5c = 0x97d1af;
      puStack_54 = puStack_58;
      (**(code **)(param_3 & 0xfffffffe))();
    }
    param_3 = 0;
  }
  uStack_8 = 8;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    puStack_58 = &stack0x00000034;
    iStack_50 = 2;
    iStack_5c = 0x97d1dd;
    puStack_54 = puStack_58;
    (**(code **)(in_stack_0000002c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17777 ; VA 0x0097d200 ; FUN_0097d200 */

void __thiscall FUN_0097d200(int param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined **ppuVar5;
  int *piVar6;
  int *piVar7;
  int in_stack_00000014;
  uint in_stack_00000018;
  char cStack0000001c;
  char cStack0000001f;
  uint in_stack_00000020;
  uint in_stack_00000040;
  undefined auStack_3a0 [24];
  undefined4 uStack_388;
  undefined4 *puStack_384;
  undefined *puStack_380;
  char *pcStack_37c;
  undefined4 *puStack_378;
  undefined auStack_374 [8];
  undefined4 uStack_36c;
  undefined4 *puStack_368;
  int *piStack_364;
  int *piStack_360;
  int iStack_350;
  int iStack_34c;
  undefined4 auStack_348 [50];
  undefined4 auStack_280 [2];
  undefined auStack_278 [88];
  undefined4 uStack_220;
  undefined auStack_218 [88];
  undefined4 uStack_1c0;
  undefined auStack_1b8 [88];
  undefined4 uStack_160;
  undefined auStack_158 [88];
  undefined4 uStack_100;
  undefined auStack_f8 [88];
  undefined4 auStack_a0 [2];
  undefined auStack_98 [88];
  undefined auStack_40 [4];
  int *piStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 *puStack_30;
  int iStack_2c;
  int *piStack_28;
  undefined4 *puStack_24;
  int *piStack_20;
  int *piStack_1c;
  undefined4 *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cfd3c;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffca4;
  uStack_8 = 2;
  if (cStack0000001c == '\0') {
    if (in_stack_00000014 == 0) {
      puStack_378 = (undefined4 *)0x49;
      piStack_364 = (int *)0x0;
      piStack_360 = (int *)0xf;
      pcStack_37c = "Players:GetCharacterAppearanceAsync() failed because of an unknown error.";
      auStack_374[0] = 0;
      puStack_380 = (undefined *)0x97d6b3;
      ExceptionList = &pvStack_10;
      FUN_005542c0();
    }
    else {
      puStack_378 = &param_2;
      if (0xf < in_stack_00000018) {
        puStack_378 = param_2;
      }
      puStack_380 = auStack_374;
      pcStack_37c = "Players:GetCharacterAppearanceAsync() failed because %s";
      puStack_384 = (undefined4 *)0x97d68c;
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xfffffca4;
      FUN_01675640();
    }
    puStack_378 = (undefined4 *)0x97d6bb;
    FUN_005e65e0();
    goto LAB_0097d6bb;
  }
  piVar7 = (int *)0x0;
  puStack_24 = (undefined4 *)0x0;
  piStack_20 = (int *)0x0;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  piStack_360 = (int *)0x97d24c;
  ExceptionList = &pvStack_10;
  puStack_14 = &stack0xfffffca4;
  iStack_350 = FUN_00888530();
  iStack_34c = 0;
  piStack_360 = (int *)0x0;
  piStack_364 = &iStack_350;
  uStack_8._0_1_ = 4;
  puStack_368 = &param_2;
  uStack_36c = 0x97d26d;
  cVar2 = FUN_0098ef90();
  iVar1 = iStack_350;
  if (cVar2 != '\0') {
    piStack_360 = (int *)0x97d283;
    iVar3 = FUN_008881d0();
    if (iVar1 != iVar3) {
      piStack_360 = (int *)0x18c072c;
                    /* WARNING: Subroutine does not return */
      piStack_364 = (int *)0x97d774;
      FUN_016757c0();
    }
    puStack_24 = auStack_348;
    if (iStack_34c == 0) {
      puStack_24 = (undefined4 *)0x0;
    }
    piVar7 = (int *)puStack_24[1];
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar7[1] = piVar7[1] + 1;
      UNLOCK();
      piVar7 = (int *)puStack_24[1];
    }
    puStack_24 = (undefined4 *)*puStack_24;
    piStack_360 = (int *)auStack_40;
    piStack_364 = (int *)0x97d2be;
    piStack_20 = piVar7;
    puStack_18 = puStack_24;
    FUN_00942ec0();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (*(int *)(param_1 + 0x34) != 0) {
      piStack_360 = (int *)0x97d2d1;
      param_1 = FUN_005c8ac0();
    }
    if (param_1 == 0) {
LAB_0097d2ff:
      piStack_360 = (int *)0x0;
    }
    else {
      iVar1 = *(int *)(param_1 + 0xc);
      piStack_360 = (int *)0x97d2df;
      iVar3 = FUN_008dcf60();
      if ((uint)*(ushort *)(iVar3 + 0x1da) <
          (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) goto LAB_0097d2ff;
      piStack_360 = (int *)(param_1 + -0xc);
    }
    piStack_364 = &iStack_2c;
    puStack_368 = (undefined4 *)0x97d30b;
    puVar4 = (undefined4 *)FUN_005c4330();
    piVar6 = (int *)puVar4[1];
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[2] = piVar6[2] + 1;
      UNLOCK();
      piVar6 = (int *)puVar4[1];
    }
    uStack_38 = *puVar4;
    uStack_8._0_1_ = 6;
    _cStack0000001c = piStack_28;
    piStack_34 = piVar6;
    piStack_1c = piVar6;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_28[1] + -1;
      piStack_28[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        piStack_360 = (int *)0x97d348;
        (**(code **)*piStack_28)();
        LOCK();
        iVar1 = _cStack0000001c[2] + -1;
        _cStack0000001c[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          piStack_360 = (int *)0x97d359;
          (**(code **)(*_cStack0000001c + 4))();
        }
      }
    }
    if (puStack_18 == (undefined4 *)0x0) {
      puStack_378 = (undefined4 *)0x36;
      piStack_364 = (int *)0x0;
      piStack_360 = (int *)0xf;
      pcStack_37c = "Players:GetCharacterAppearanceAsync() unexpected error";
      auStack_374[0] = 0;
      puStack_380 = (undefined *)0x97d5e2;
      FUN_005542c0();
      puStack_378 = (undefined4 *)0x97d5ea;
      FUN_005e65e0();
    }
    else {
      piStack_360 = &iStack_2c;
      piStack_364 = (int *)0x97d36f;
      FUN_00587490();
      if (iStack_2c == 0) {
        piStack_360 = (int *)0x97d5be;
        FUN_00550b30();
      }
      else {
        piStack_360 = (int *)0x1;
        puStack_18 = &puStack_380;
        uStack_8._0_1_ = 8;
        _cStack0000001c = (int *)auStack_3a0;
        FUN_0054f510(&stack0x00000040);
        uStack_8._0_1_ = 9;
        FUN_0054f510(&stack0x00000020);
        FUN_00557fc0(auStack_40);
        FUN_005587b0(&uStack_38);
        FUN_00557fc0(&puStack_24);
        uStack_8._0_1_ = 8;
        FUN_00964f90(auStack_280,FUN_00979080);
        uStack_220 = auStack_280[0];
        puStack_384 = (undefined4 *)auStack_278;
        uStack_8._0_1_ = 10;
        uStack_388 = 0x97d40c;
        FUN_0096a4e0();
        uStack_8._0_1_ = 0xb;
        *puStack_18 = 0;
        uStack_1c0 = uStack_220;
        puStack_384 = (undefined4 *)auStack_218;
        uStack_388 = 0x97d437;
        FUN_0096a4e0();
        uStack_160 = uStack_1c0;
        puStack_384 = (undefined4 *)auStack_1b8;
        uStack_8._0_1_ = 0xc;
        uStack_388 = 0x97d459;
        FUN_0096a4e0();
        auStack_a0[0] = uStack_160;
        puStack_384 = (undefined4 *)auStack_158;
        uStack_8._0_1_ = 0xd;
        uStack_388 = 0x97d47b;
        FUN_0096a4e0();
        puStack_384 = auStack_a0;
        uStack_8._0_1_ = 0xe;
        uStack_388 = 0x97d48b;
        cVar2 = FUN_00585a40();
        if (cVar2 == '\0') {
          uStack_100 = auStack_a0[0];
          puStack_384 = (undefined4 *)auStack_98;
          uStack_388 = 0x97d4b0;
          FUN_0096a4e0();
          puStack_384 = (undefined4 *)0x60;
          uStack_8._0_1_ = 0xf;
          uStack_388 = 0x97d4bb;
          _cStack0000001c = (int *)FUN_01674e20();
          uStack_8._0_1_ = 0x10;
          puStack_30 = _cStack0000001c;
          if (_cStack0000001c == (undefined4 *)0x0) {
            puVar4 = (undefined4 *)0x0;
          }
          else {
            *_cStack0000001c = uStack_100;
            puStack_384 = (undefined4 *)auStack_f8;
            uStack_388 = 0x97d4e3;
            FUN_0096a4e0();
            puVar4 = _cStack0000001c;
          }
          puStack_18[2] = puVar4;
          puStack_384 = (undefined4 *)0x97d4fb;
          FUN_0096cbb0();
          puStack_384 = (undefined4 *)0x97d506;
          FUN_0096cbb0();
          _cStack0000001c = (int *)CONCAT13(1,_cStack0000001c);
        }
        else {
          puStack_384 = (undefined4 *)0x97d517;
          FUN_0096cbb0();
          _cStack0000001c = (int *)((uint)_cStack0000001c & 0xffffff);
        }
        puStack_384 = (undefined4 *)0x97d526;
        FUN_0096cbb0();
        ppuVar5 = &PTR_FUN_01936c4c;
        if (cStack0000001f == '\0') {
          ppuVar5 = (undefined **)0x0;
        }
        *puStack_18 = ppuVar5;
        puStack_384 = (undefined4 *)0x97d543;
        FUN_0096cbb0();
        puStack_384 = (undefined4 *)0x97d54e;
        FUN_0096cbb0();
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
        puStack_384 = (undefined4 *)0x97d55d;
        FUN_0096cbb0();
        puStack_384 = (undefined4 *)0x97d565;
        FUN_0090ca30();
        uStack_8._0_1_ = 7;
        uStack_8._1_3_ = 0;
        piStack_360 = (int *)0x97d574;
        FUN_00550b30();
      }
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar1 = piVar6[2] + -1;
      piVar6[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        piStack_360 = (int *)0x97d5fe;
        (**(code **)(*piVar6 + 4))();
      }
    }
    if (piStack_3c != (int *)0x0) {
      LOCK();
      iVar1 = piStack_3c[1] + -1;
      piStack_3c[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        piStack_360 = (int *)0x97d614;
        (**(code **)*piStack_3c)();
        LOCK();
        iVar1 = piStack_3c[2] + -1;
        piStack_3c[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          piStack_360 = (int *)0x97d624;
          (**(code **)(*piStack_3c + 4))();
        }
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
  if (iStack_34c != 0) {
    piStack_360 = auStack_348;
    piStack_364 = (int *)0x97d643;
    (**(code **)(iStack_34c + 8))();
  }
  if (piVar7 != (int *)0x0) {
    LOCK();
    iVar1 = piVar7[1] + -1;
    piVar7[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      piStack_360 = (int *)0x97d659;
      (**(code **)*piVar7)();
      LOCK();
      piVar6 = piVar7 + 2;
      iVar1 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        piStack_360 = (int *)0x97d668;
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
LAB_0097d6bb:
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    piStack_360 = (int *)(in_stack_00000018 + 1);
    puVar4 = param_2;
    if (0xfff < piStack_360) {
      puVar4 = (undefined4 *)param_2[-1];
      piStack_360 = (int *)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
        piStack_360 = (int *)&UNK_0097d779;
        FUN_017167a3();
      }
    }
    puStack_368 = (undefined4 *)0x97d6f0;
    piStack_364 = puVar4;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = (undefined4 *)((uint)param_2 & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
  if (in_stack_00000020 != 0) {
    if (((in_stack_00000020 & 1) == 0) &&
       (*(code **)(in_stack_00000020 & 0xfffffffe) != (code *)0x0)) {
      puStack_368 = (undefined4 *)&stack0x00000028;
      piStack_360 = (int *)0x2;
      uStack_36c = 0x97d726;
      piStack_364 = puStack_368;
      (**(code **)(in_stack_00000020 & 0xfffffffe))();
    }
    in_stack_00000020 = 0;
  }
  uStack_8 = 0x14;
  if (((in_stack_00000040 != 0) && ((in_stack_00000040 & 1) == 0)) &&
     (*(code **)(in_stack_00000040 & 0xfffffffe) != (code *)0x0)) {
    puStack_368 = (undefined4 *)&stack0x00000048;
    piStack_360 = (int *)0x2;
    uStack_36c = 0x97d754;
    piStack_364 = puStack_368;
    (**(code **)(in_stack_00000040 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17778 ; VA 0x0097d576 ; Catch@0097d576 */

undefined * Catch_0097d576(void)

{
  undefined uVar1;
  
  uVar1 = 0;
  FUN_005542c0("Players:GetCharacterAppearanceAsync() unexpected error",0x36);
  FUN_005e65e0(uVar1);
  return &DAT_0097d5a6;
}



/* FUNCTION 17779 ; VA 0x0097d780 ; FUN_0097d780 */

void __thiscall FUN_0097d780(int param_1,int param_2,int param_3,uint param_4)

{
  bool bVar1;
  undefined uVar2;
  char *pcVar3;
  uint *puVar4;
  char cVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined **ppuVar8;
  int *piVar9;
  int iVar10;
  uint in_stack_0000002c;
  undefined4 in_stack_00000034;
  char *in_stack_00000038;
  undefined4 in_stack_0000003c;
  uint in_stack_00000040;
  undefined8 in_stack_00000044;
  undefined auStack_388 [8];
  undefined4 uStack_380;
  undefined4 *puStack_37c;
  undefined4 *puStack_378;
  undefined4 uStack_374;
  uint uStack_370;
  undefined4 *puStack_36c;
  undefined4 uStack_368;
  char *pcStack_364;
  undefined4 *puStack_360;
  uint uStack_35c;
  undefined8 uStack_358;
  undefined4 **ppuStack_350;
  undefined4 **ppuStack_34c;
  undefined4 *puStack_348;
  undefined4 auStack_2d4 [2];
  undefined auStack_2cc [72];
  undefined4 auStack_284 [2];
  undefined auStack_27c [64];
  undefined4 *apuStack_23c [6];
  int aiStack_224 [6];
  undefined4 auStack_20c [2];
  undefined4 auStack_204 [2];
  undefined auStack_1fc [64];
  undefined4 uStack_1bc;
  undefined4 auStack_1b4 [2];
  undefined auStack_1ac [64];
  undefined4 uStack_16c;
  undefined4 auStack_164 [2];
  undefined auStack_15c [64];
  undefined4 uStack_11c;
  undefined4 auStack_114 [2];
  undefined auStack_10c [64];
  undefined4 uStack_cc;
  undefined4 auStack_c4 [2];
  undefined auStack_bc [64];
  uint auStack_7c [2];
  undefined4 *apuStack_74 [6];
  undefined **appuStack_5c [2];
  undefined4 *apuStack_54 [6];
  char *pcStack_3c;
  int *piStack_38;
  undefined *puStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  char *pcStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cfe53;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  if ((param_3 < 1) && ((param_3 < 0 || (param_2 == 0)))) {
    puStack_360 = (undefined4 *)0x4f;
    ppuStack_34c = (undefined4 **)0x0;
    puStack_348 = (undefined4 *)0xf;
    pcStack_364 = "Players:GetCharacterAppearanceInfoAsync() must be called with a positive userId";
    uStack_35c = uStack_35c & 0xffffff00;
    uStack_368 = 0x97d7d9;
    ExceptionList = &pvStack_10;
    FUN_005542c0();
    puStack_360 = (undefined4 *)0x97d7e1;
    FUN_005e65e0();
  }
  else {
    ppuStack_34c = (undefined4 **)0x97d7ec;
    ExceptionList = &pvStack_10;
    puStack_348 = (undefined4 *)param_1;
    ppuStack_34c = (undefined4 **)FUN_008f7870();
    ppuStack_350 = (undefined4 **)&pcStack_28;
    uStack_358 = CONCAT44(0x97d7f6,(undefined4)uStack_358);
    FUN_005c4330();
    pcVar3 = pcStack_28;
    uStack_8._0_1_ = 2;
    if (pcStack_28 == (char *)0x0) {
      puStack_360 = (undefined4 *)0x3f;
      ppuStack_34c = (undefined4 **)pcStack_28;
      puStack_348 = (undefined4 *)0xf;
      pcStack_364 = "Players:GetCharacterAppearanceInfoAsync() cannot find DataModel";
      uStack_35c = uStack_35c & 0xffffff00;
      uStack_368 = 0x97d822;
      FUN_005542c0();
      puStack_360 = (undefined4 *)0x97d82a;
      FUN_005e65e0();
    }
    else {
      puStack_348 = &uStack_30;
      ppuStack_34c = (undefined4 **)0x97d838;
      FUN_016830f0();
      if ((double)CONCAT44(uStack_2c,uStack_30) - *(double *)(param_1 + 0x138) <= DAT_018cf108) {
        iVar6 = *(int *)(param_1 + 0x120);
      }
      else {
        *(undefined4 *)(param_1 + 0x138) = uStack_30;
        *(undefined4 *)(param_1 + 0x13c) = uStack_2c;
        iVar6 = 0;
        *(undefined4 *)(param_1 + 0x124) = 0;
      }
      piVar9 = *(int **)(param_1 + 0x130);
      puStack_1c = (undefined4 *)(iVar6 + 1);
      *(undefined4 **)(param_1 + 0x120) = puStack_1c;
      iVar6 = *(int *)(param_1 + 0x124);
      if (iVar6 < 1) {
        iVar6 = 0;
      }
      *(int *)(param_1 + 0x124) = iVar6;
      if (piVar9 == (int *)0x0) {
        piVar9 = *(int **)(param_1 + 0x128);
      }
      iVar10 = *piVar9;
      if (*(int **)(param_1 + 300) != (int *)0x0) {
        iVar10 = iVar10 + **(int **)(param_1 + 300) * iVar6;
      }
      if ((int)puStack_1c <= iVar10) {
        if (piStack_24 != (int *)0x0) {
          LOCK();
          piStack_24[2] = piStack_24[2] + 1;
          UNLOCK();
        }
        pcStack_3c = pcVar3;
        piStack_38 = piStack_24;
        puStack_348 = (undefined4 *)(uint)DAT_01ee2fe9;
        puStack_18 = &uStack_368;
        uStack_8._0_1_ = 4;
        puStack_36c = &stack0x0000002c;
        uStack_370 = 0x97d963;
        FUN_0054f510();
        uStack_8._0_1_ = 5;
        FUN_0054f510(&param_4);
        if (piStack_24 != (int *)0x0) {
          LOCK();
          piStack_24[2] = piStack_24[2] + 1;
          UNLOCK();
        }
        uStack_8._0_1_ = 4;
        FUN_009653f0(auStack_2d4,FUN_0097de80,pcVar3,piStack_24);
        uStack_cc = auStack_2d4[0];
        puStack_348 = (undefined4 *)auStack_2cc;
        uStack_8._0_1_ = 6;
        ppuStack_34c = (undefined4 **)0x97d9ce;
        FUN_009684d0();
        uStack_11c = uStack_cc;
        puStack_348 = auStack_c4;
        uStack_8._0_1_ = 7;
        appuStack_5c[0] = (undefined **)0x0;
        ppuStack_34c = (undefined4 **)0x97d9f7;
        FUN_009684d0();
        uStack_16c = uStack_11c;
        puStack_348 = auStack_114;
        uStack_8._0_1_ = 8;
        ppuStack_34c = (undefined4 **)0x97da19;
        FUN_009684d0();
        auStack_20c[0] = uStack_16c;
        puStack_348 = auStack_164;
        uStack_8._0_1_ = 9;
        ppuStack_34c = (undefined4 **)0x97da3b;
        FUN_009684d0();
        puStack_348 = auStack_20c;
        uStack_8._0_1_ = 10;
        ppuStack_34c = (undefined4 **)0x97da4b;
        cVar5 = FUN_00585a40();
        if (cVar5 == '\0') {
          uStack_1bc = auStack_20c[0];
          puStack_348 = auStack_204;
          ppuStack_34c = (undefined4 **)0x97da70;
          FUN_009684d0();
          puStack_348 = (undefined4 *)0x50;
          uStack_8._0_1_ = 0xb;
          ppuStack_34c = (undefined4 **)0x97da7b;
          apuStack_54[0] = (undefined4 *)FUN_01674e20();
          uStack_8._0_1_ = 0xc;
          puStack_18 = apuStack_54[0];
          if (apuStack_54[0] == (undefined4 *)0x0) {
            apuStack_54[0] = (undefined4 *)0x0;
          }
          else {
            puStack_348 = auStack_1b4;
            *apuStack_54[0] = uStack_1bc;
            ppuStack_34c = (undefined4 **)0x97daa2;
            FUN_009684d0();
          }
          puStack_348 = (undefined4 *)0x97dab4;
          FUN_008e9ba0();
          puStack_348 = (undefined4 *)0x97dabf;
          FUN_008e9ba0();
          cStack_11 = '\x01';
        }
        else {
          puStack_348 = (undefined4 *)0x97dad0;
          FUN_008e9ba0();
          cStack_11 = '\0';
        }
        puStack_348 = (undefined4 *)0x97dadf;
        FUN_008e9ba0();
        appuStack_5c[0] = &PTR_FUN_01936ba4;
        if (cStack_11 == '\0') {
          appuStack_5c[0] = (undefined **)0x0;
        }
        puStack_348 = (undefined4 *)0x97dafa;
        FUN_008e9ba0();
        puStack_348 = (undefined4 *)0x97db05;
        FUN_008e9ba0();
        puStack_348 = (undefined4 *)0x97db10;
        FUN_008e9ba0();
        puStack_348 = (undefined4 *)0x0;
        puStack_18 = &uStack_370;
        uStack_8._0_1_ = 0xd;
        uStack_370 = 0;
        puVar4 = &uStack_370;
        if (in_stack_0000002c != 0) {
          uStack_370 = in_stack_0000002c;
          if ((in_stack_0000002c & 1) == 0) {
            puStack_378 = &uStack_368;
            uStack_374 = 0;
            puStack_37c = &stack0x00000034;
            uStack_380 = 0x97db57;
            (**(code **)(in_stack_0000002c & 0xfffffffe))();
            puVar4 = puStack_18;
          }
          else {
            uStack_368 = in_stack_00000034;
            pcStack_364 = in_stack_00000038;
            puStack_360 = (undefined4 *)in_stack_0000003c;
            uStack_35c = in_stack_00000040;
            uStack_358 = in_stack_00000044;
            puVar4 = &uStack_370;
          }
        }
        puStack_18 = puVar4;
        if (piStack_24 != (int *)0x0) {
          LOCK();
          piStack_24[2] = piStack_24[2] + 1;
          UNLOCK();
        }
        ppuStack_350 = (undefined4 **)pcStack_28;
        ppuStack_34c = (undefined4 **)piStack_24;
        uStack_374 = 0x97db81;
        FUN_0095f2e0();
        puStack_348 = (undefined4 *)param_3;
        ppuStack_350 = apuStack_23c;
        uStack_8._0_1_ = 0xe;
        ppuStack_34c = (undefined4 **)param_2;
        uStack_358 = CONCAT44(0x97db97,(undefined4)uStack_358);
        FUN_00f540c0();
        puStack_348 = (undefined4 *)0x0;
        ppuStack_34c = (undefined4 **)0x0;
        ppuStack_350 = apuStack_23c;
        uStack_8._0_1_ = 0xf;
        uStack_358 = CONCAT44(0x97dbb4,(undefined4)uStack_358);
        puStack_18 = (undefined4 *)FUN_014cc090();
        uVar2 = DAT_01ee2fea;
        puStack_348 = (undefined4 *)0x0;
        puStack_1c = &uStack_368;
        puVar7 = &uStack_368;
        puStack_34 = auStack_388;
        uStack_20 = CONCAT31(uStack_20._1_3_,DAT_01ee2fe9);
        uStack_8._0_1_ = 0x10;
        FUN_0054f510(auStack_7c);
        uStack_8._0_1_ = 0x11;
        FUN_0054f510(appuStack_5c);
        uStack_8._0_1_ = 0x10;
        FUN_008e0790(auStack_204,FUN_008ed2f0,uStack_20,uVar2);
        auStack_1b4[0] = auStack_204[0];
        puStack_36c = (undefined4 *)auStack_1fc;
        uStack_8._0_1_ = 0x12;
        uStack_370 = 0x97dc3c;
        FUN_008e7950();
        auStack_164[0] = auStack_1b4[0];
        puStack_36c = (undefined4 *)auStack_1ac;
        uStack_8._0_1_ = 0x13;
        uStack_368 = 0;
        uStack_370 = 0x97dc64;
        FUN_008e7950();
        auStack_114[0] = auStack_164[0];
        puStack_36c = (undefined4 *)auStack_15c;
        uStack_8._0_1_ = 0x14;
        uStack_370 = 0x97dc86;
        FUN_008e7950();
        uStack_8._0_1_ = 0x15;
        auStack_284[0] = auStack_114[0];
        puStack_36c = (undefined4 *)auStack_10c;
        uStack_370 = 0x97dca8;
        FUN_008e7950();
        puStack_36c = auStack_284;
        uStack_8._0_1_ = 0x16;
        uStack_370 = 0x97dcb8;
        cVar5 = FUN_00585a40();
        if (cVar5 == '\0') {
          auStack_c4[0] = auStack_284[0];
          puStack_36c = (undefined4 *)auStack_27c;
          uStack_370 = 0x97dcdd;
          FUN_008e7950();
          puStack_36c = (undefined4 *)0x48;
          uStack_8._0_1_ = 0x17;
          uStack_370 = 0x97dce8;
          puVar7 = (undefined4 *)FUN_01674e20();
          uStack_8._0_1_ = 0x18;
          if (puVar7 == (undefined4 *)0x0) {
            puVar7 = (undefined4 *)0x0;
          }
          else {
            puStack_36c = (undefined4 *)auStack_bc;
            *puVar7 = auStack_c4[0];
            uStack_370 = 0x97dd0f;
            FUN_008e7950();
          }
          puStack_1c[2] = puVar7;
          puStack_36c = (undefined4 *)0x97dd24;
          FUN_008c3510();
          puStack_36c = (undefined4 *)0x97dd2f;
          FUN_008c3510();
          bVar1 = true;
          puVar7 = puStack_1c;
        }
        else {
          puStack_36c = (undefined4 *)0x97dd43;
          FUN_008c3510();
          bVar1 = false;
        }
        puStack_36c = (undefined4 *)0x97dd52;
        FUN_008c3510();
        ppuVar8 = &PTR_FUN_0192d368;
        if (!bVar1) {
          ppuVar8 = (undefined **)0x0;
        }
        *puVar7 = ppuVar8;
        puStack_36c = (undefined4 *)0x97dd6c;
        FUN_008c3510();
        puStack_36c = (undefined4 *)0x97dd77;
        FUN_008c3510();
        uStack_8._0_1_ = 0x10;
        puStack_36c = (undefined4 *)0x97dd86;
        FUN_008c3510();
        puStack_36c = (undefined4 *)0x97dd8e;
        FUN_014ccc70();
        puStack_348 = (undefined4 *)0x97dd99;
        FUN_0056db40();
        puStack_348 = (undefined4 *)0x97dda4;
        FUN_005507b0();
        uStack_8._0_1_ = 0x19;
        if (auStack_7c[0] != 0) {
          if (((auStack_7c[0] & 1) == 0) && (*(code **)(auStack_7c[0] & 0xfffffffe) != (code *)0x0))
          {
            ppuStack_350 = apuStack_74;
            puStack_348 = (undefined4 *)0x2;
            uStack_358 = CONCAT44(0x97ddc5,(undefined4)uStack_358);
            ppuStack_34c = ppuStack_350;
            (**(code **)(auStack_7c[0] & 0xfffffffe))();
          }
          auStack_7c[0] = 0;
        }
        uStack_8._0_1_ = 0x1a;
        if (appuStack_5c[0] != (undefined **)0x0) {
          if ((((uint)appuStack_5c[0] & 1) == 0) &&
             (*(code **)((uint)appuStack_5c[0] & 0xfffffffe) != (code *)0x0)) {
            ppuStack_350 = apuStack_54;
            puStack_348 = (undefined4 *)0x2;
            uStack_358 = CONCAT44(0x97ddf0,(undefined4)uStack_358);
            ppuStack_34c = ppuStack_350;
            (**(code **)((uint)appuStack_5c[0] & 0xfffffffe))();
          }
          appuStack_5c[0] = (undefined **)0x0;
        }
        if (piStack_24 != (int *)0x0) {
          LOCK();
          iVar6 = piStack_24[2] + -1;
          piStack_24[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            puStack_348 = (undefined4 *)0x97de0f;
            (**(code **)(*piStack_24 + 4))();
          }
        }
        puStack_348 = (undefined4 *)0x97de17;
        FUN_00550b30();
        goto LAB_0097de17;
      }
      puStack_348 = (undefined4 *)DAT_01d645a0;
      ppuStack_350 = (undefined4 **)aiStack_224;
      ppuStack_34c = (undefined4 **)0x1935bf8;
      uStack_358 = CONCAT44(0x97d8d4,(undefined4)uStack_358);
      FUN_01675640();
      uStack_8._0_1_ = 3;
      puStack_360 = aiStack_224;
      pcStack_364 = (char *)0x97d8e9;
      FUN_0054ef60();
      puStack_360 = (undefined4 *)0x97d8f1;
      FUN_005e65e0();
      puStack_348 = (undefined4 *)0x97d8fc;
      FUN_005507b0();
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_24[1] + -1;
      piStack_24[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        puStack_348 = (undefined4 *)0x97d91d;
        (**(code **)*piStack_24)();
        LOCK();
        piVar9 = piStack_24 + 2;
        iVar6 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          puStack_348 = (undefined4 *)0x97d930;
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
  }
LAB_0097de17:
  uStack_8 = CONCAT31(uStack_8._1_3_,0x1b);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      ppuStack_350 = (undefined4 **)&stack0x00000014;
      puStack_348 = (undefined4 *)0x2;
      uStack_358 = CONCAT44(0x97de38,(undefined4)uStack_358);
      ppuStack_34c = ppuStack_350;
      (**(code **)(param_4 & 0xfffffffe))();
    }
    param_4 = 0;
  }
  uStack_8 = 0x1c;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    ppuStack_350 = (undefined4 **)&stack0x00000034;
    puStack_348 = (undefined4 *)0x2;
    uStack_358 = CONCAT44(0x97de66,(undefined4)uStack_358);
    ppuStack_34c = ppuStack_350;
    (**(code **)(in_stack_0000002c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17780 ; VA 0x0097de80 ; FUN_0097de80 */

void FUN_0097de80(undefined4 param_1,int *param_2,uint param_3)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  uint in_stack_0000002c;
  int in_stack_0000004c;
  uint in_stack_00000060;
  undefined auStack_1a0 [20];
  undefined4 uStack_18c;
  undefined auStack_188 [12];
  undefined4 uStack_17c;
  undefined4 *puStack_178;
  undefined4 uStack_154;
  int *piStack_150;
  undefined **ppuStack_14c;
  undefined4 uStack_144;
  undefined4 uStack_138;
  char *pcStack_134;
  char *pcStack_130;
  int *piStack_12c;
  undefined auStack_11c [40];
  undefined auStack_f4 [40];
  undefined auStack_cc [40];
  undefined auStack_a4 [40];
  undefined auStack_7c [40];
  undefined auStack_54 [16];
  undefined auStack_44 [16];
  undefined4 uStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  int *piStack_28;
  undefined *puStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cfef3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piStack_12c = &iStack_2c;
  pcStack_130 = (char *)0x97deb4;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  if (iStack_2c != 0) {
    uStack_20 = 0;
    piStack_1c = (int *)0x0;
    piStack_12c = (int *)0x0;
    pcStack_130 = (char *)&uStack_20;
    uStack_8._0_1_ = 5;
    pcStack_134 = (char *)&stack0x0000004c;
    uStack_138 = 0x97dee3;
    cVar3 = FUN_0098f070();
    if (cVar3 == '\0') {
      piStack_12c = (int *)0x47;
      pcStack_130 = "Players:GetCharacterAppearanceInfoAsync() failed to parse JSON response";
      uStack_34 = 0;
      uStack_30 = 0xf;
      auStack_44[0] = 0;
      pcStack_134 = (char *)0x97e076;
      FUN_005542c0();
      piStack_12c = (int *)0x1;
      uStack_8._0_1_ = 0xe;
      piStack_150 = (int *)0x0;
      puStack_18 = auStack_1a0;
      FUN_0054ef60(auStack_44);
      uStack_8._0_1_ = 0xf;
      FUN_0054f510(&stack0x0000002c);
      uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
      FUN_009645a0(auStack_188);
      uStack_18c = 0x97e0bf;
      FUN_0095fcd0();
      piStack_150 = (int *)0x97e0c7;
      FUN_0090ca30();
      piStack_12c = (int *)0x97e0cf;
      FUN_005507b0();
    }
    else {
      piStack_12c = (int *)0x1;
      puStack_24 = (undefined *)&uStack_154;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piStack_1c[1] = piStack_1c[1] + 1;
        UNLOCK();
      }
      uStack_154 = uStack_20;
      piStack_150 = piStack_1c;
      uStack_8._0_1_ = 6;
      puStack_178 = &param_3;
      uStack_17c = 0x97df32;
      FUN_0054f510();
      puStack_178 = (undefined4 *)auStack_11c;
      uStack_8._0_1_ = 5;
      uStack_17c = 0x97df42;
      FUN_009647e0();
      piStack_150 = (int *)auStack_11c;
      uStack_8._0_1_ = 7;
      uStack_154 = 0x97df5b;
      FUN_008c1490();
      piStack_150 = (int *)auStack_f4;
      uStack_8._0_1_ = 8;
      ppuStack_14c = (undefined **)0x0;
      uStack_154 = 0x97df77;
      FUN_008c1490();
      piStack_150 = (int *)auStack_cc;
      uStack_8._0_1_ = 9;
      uStack_154 = 0x97df8d;
      FUN_008c1490();
      piStack_150 = (int *)auStack_a4;
      uStack_8._0_1_ = 10;
      uStack_154 = 0x97dfa0;
      FUN_008c1490();
      piStack_150 = (int *)auStack_54;
      uStack_8._0_1_ = 0xb;
      uStack_154 = 0x97dfad;
      cVar3 = FUN_00585a40();
      if (cVar3 == '\0') {
        piStack_150 = (int *)auStack_54;
        uStack_154 = 0x97dfc0;
        FUN_008c1490();
        piStack_150 = (int *)0x28;
        uStack_8._0_1_ = 0xc;
        uStack_154 = 0x97dfcb;
        puStack_18 = (undefined *)FUN_01674e20();
        uStack_8._0_1_ = 0xd;
        if (puStack_18 == (undefined *)0x0) {
          uStack_144 = 0;
        }
        else {
          piStack_150 = (int *)auStack_7c;
          uStack_154 = 0x97dfe4;
          uStack_144 = FUN_008c1490();
        }
        piStack_150 = (int *)0x97dff3;
        FUN_008c3670();
        piStack_150 = (int *)0x97dffb;
        FUN_008c3670();
        cStack_11 = '\x01';
      }
      else {
        piStack_150 = (int *)0x97e009;
        FUN_008c3670();
        cStack_11 = '\0';
      }
      piStack_150 = (int *)0x97e018;
      FUN_008c3670();
      ppuStack_14c = &PTR_FUN_01936c5c;
      if (cStack_11 == '\0') {
        ppuStack_14c = (undefined **)0x0;
      }
      piStack_150 = (int *)0x97e032;
      FUN_008c3670();
      piStack_150 = (int *)0x97e03d;
      FUN_008c3670();
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      piStack_150 = (int *)0x97e04c;
      FUN_008c3670();
      piStack_150 = (int *)0x97e053;
      FUN_0090ca30();
    }
    piVar2 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        piStack_12c = (int *)0x97e0e5;
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          piStack_12c = (int *)0x97e0f5;
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_28[1] + -1;
    piStack_28[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      piStack_12c = (int *)0x97e10b;
      (**(code **)*piStack_28)();
      LOCK();
      iVar4 = piStack_28[2] + -1;
      piStack_28[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        piStack_12c = (int *)0x97e11b;
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar2 = param_2 + 2;
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      piStack_12c = (int *)0x97e12f;
      (**(code **)(*param_2 + 4))();
    }
  }
  uStack_8._0_1_ = 0x10;
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      pcStack_134 = &stack0x00000014;
      piStack_12c = (int *)0x2;
      uStack_138 = 0x97e150;
      pcStack_130 = pcStack_134;
      (**(code **)(param_3 & 0xfffffffe))();
    }
    param_3 = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
  if (in_stack_0000002c != 0) {
    if (((in_stack_0000002c & 1) == 0) &&
       (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
      pcStack_134 = &stack0x00000034;
      piStack_12c = (int *)0x2;
      uStack_138 = 0x97e17b;
      pcStack_130 = pcStack_134;
      (**(code **)(in_stack_0000002c & 0xfffffffe))();
    }
    in_stack_0000002c = 0;
  }
  if (0xf < in_stack_00000060) {
    piStack_12c = (int *)(in_stack_00000060 + 1);
    iVar4 = in_stack_0000004c;
    if (0xfff < piStack_12c) {
      iVar4 = *(int *)(in_stack_0000004c + -4);
      piStack_12c = (int *)(in_stack_00000060 + 0x24);
      if (0x1f < (in_stack_0000004c - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        piStack_12c = (int *)&UNK_0097e1cb;
        FUN_017167a3();
      }
    }
    pcStack_134 = (char *)0x97e1b2;
    pcStack_130 = (char *)iVar4;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17781 ; VA 0x0097e1d0 ; FUN_0097e1d0 */

void FUN_0097e1d0(int param_1,int param_2,uint param_3)

{
  undefined uVar1;
  int iVar2;
  uint in_stack_0000002c;
  undefined auStack_c4 [28];
  undefined4 uStack_a8;
  undefined auStack_a4 [4];
  undefined4 uStack_a0;
  undefined *puStack_9c;
  int iStack_98;
  int iStack_94;
  undefined auStack_90 [24];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_54;
  char *pcStack_50;
  undefined4 uStack_4c;
  undefined uStack_48;
  undefined4 uStack_40;
  undefined *puStack_3c;
  undefined *puStack_38;
  undefined4 uStack_34;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cff30;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if ((param_2 < 1) && ((param_2 < 0 || (param_1 == 0)))) {
    uStack_4c = 0x42;
    puStack_38 = (undefined *)0x0;
    uStack_34 = 0xf;
    pcStack_50 = "Players:GetHumanoidDescriptionFromOutfitId() got negative outfitId";
    uStack_48 = 0;
    uStack_54 = 0x97e224;
    ExceptionList = &pvStack_10;
    FUN_005542c0();
    uStack_4c = 0x97e22c;
    FUN_005e65e0();
  }
  else {
    puStack_38 = (undefined *)0x97e237;
    ExceptionList = &pvStack_10;
    iVar2 = FUN_00965f10();
    uVar1 = DAT_01ee2fe9;
    if (iVar2 != 0) {
      uStack_54 = 0;
      FUN_0054f510();
      uStack_8._0_1_ = 2;
      FUN_0054f510(&param_3);
      uStack_8._0_1_ = 1;
      FUN_00964e40(auStack_a4,FUN_0097e390,uVar1,0);
      uStack_a8 = 0x97e2a1;
      FUN_0095fed0();
      uStack_8._0_1_ = 3;
      uStack_74 = 0;
      FUN_0054f510(&stack0x0000002c);
      uStack_8._0_1_ = 4;
      FUN_0054f510(&param_3);
      uStack_8._0_1_ = 3;
      FUN_00964e40(auStack_c4,FUN_0097e390,uVar1,1);
      FUN_0095fed0();
      uStack_74 = 7;
      uStack_78 = 0;
      puStack_9c = auStack_90;
      uStack_8._0_1_ = 5;
      iStack_94 = param_2;
      iStack_98 = param_1;
      uStack_a0 = 0x97e30e;
      FUN_00f545b0();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      iStack_94 = 0x97e31d;
      FUN_00bcb620();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      puStack_3c = &stack0x00000014;
      uStack_34 = 2;
      uStack_40 = 0x97e33e;
      puStack_38 = puStack_3c;
      (**(code **)(param_3 & 0xfffffffe))();
    }
    param_3 = 0;
  }
  uStack_8 = 7;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    puStack_3c = &stack0x00000034;
    uStack_34 = 2;
    uStack_40 = 0x97e36c;
    puStack_38 = puStack_3c;
    (**(code **)(in_stack_0000002c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17782 ; VA 0x0097e390 ; FUN_0097e390 */

void FUN_0097e390(undefined4 *param_1)

{
  int iVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  undefined4 *puVar6;
  int in_stack_00000014;
  uint in_stack_00000018;
  char in_stack_0000001c;
  uint in_stack_00000020;
  uint in_stack_00000040;
  undefined auStack_108 [8];
  undefined4 uStack_100;
  undefined4 *puStack_fc;
  int *piStack_f8;
  char *pcStack_f4;
  int iStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cff6b;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  pcStack_f4 = (char *)0x97e3bc;
  ExceptionList = &pvStack_10;
  iStack_e8 = FUN_00888530();
  iStack_e4 = 0;
  uStack_8._0_1_ = 3;
  if (in_stack_0000001c != '\0') {
    pcStack_f4 = (char *)0x0;
    piStack_f8 = &iStack_e8;
    puStack_fc = &param_1;
    uStack_100 = 0x97e3ec;
    cVar3 = FUN_0098ef90();
    iVar1 = iStack_e8;
    if (cVar3 != '\0') {
      pcStack_f4 = (char *)0x97e402;
      iVar4 = FUN_008881d0();
      if (iVar1 != iVar4) {
        pcStack_f4 = "Variant cast failed";
                    /* WARNING: Subroutine does not return */
        piStack_f8 = (int *)0x97e5a7;
        FUN_016757c0();
      }
      pcStack_f4 = auStack_e0;
      if (iStack_e4 == 0) {
        pcStack_f4 = (undefined *)0x0;
      }
      piStack_f8 = (int *)auStack_18;
      puStack_fc = (undefined4 *)0x97e425;
      piVar5 = (int *)FUN_00e2f120();
      uStack_8._0_1_ = 4;
      piStack_f8 = (int *)*piVar5;
      pcStack_f4 = (char *)piVar5[1];
      *piVar5 = 0;
      piVar5[1] = 0;
      puStack_fc = (undefined4 *)0x97e459;
      FUN_0096e490();
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_14[1] + -1;
        piStack_14[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          pcStack_f4 = (char *)0x97e472;
          (**(code **)*piStack_14)();
          LOCK();
          piVar5 = piStack_14 + 2;
          iVar1 = *piVar5;
          *piVar5 = *piVar5 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            pcStack_f4 = (char *)0x97e481;
            (**(code **)(*piStack_14 + 4))();
          }
        }
      }
      goto LAB_0097e4d4;
    }
  }
  if (in_stack_00000014 == 0) {
    piStack_f8 = (int *)0x0;
    pcStack_f4 = (char *)0xf;
    auStack_108[0] = 0;
    FUN_005542c0("Players:GetHumanoidDescriptionFromOutfitId() failed because of an unknown error.",
                 0x50);
  }
  else {
    puVar6 = &param_1;
    if (0xf < in_stack_00000018) {
      puVar6 = param_1;
    }
    FUN_01675640(auStack_108,"Players:GetHumanoidDescriptionFromOutfitId() failed because %s",puVar6
                );
  }
  FUN_005e65e0();
LAB_0097e4d4:
  uStack_8._0_1_ = 5;
  if (iStack_e4 != 0) {
    pcStack_f4 = auStack_e0;
    piStack_f8 = (int *)0x97e4ee;
    (**(code **)(iStack_e4 + 8))();
  }
  uStack_8._0_1_ = 1;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    pcStack_f4 = (char *)(in_stack_00000018 + 1);
    puVar6 = param_1;
    if (0xfff < pcStack_f4) {
      puVar6 = (undefined4 *)param_1[-1];
      pcStack_f4 = (char *)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        pcStack_f4 = &UNK_0097e5ac;
        uStack_8._0_1_ = uVar2;
        FUN_017167a3();
      }
    }
    puStack_fc = (undefined4 *)0x97e526;
    piStack_f8 = puVar6;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = (undefined4 *)((uint)param_1 & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (in_stack_00000020 != 0) {
    if (((in_stack_00000020 & 1) == 0) &&
       (*(code **)(in_stack_00000020 & 0xfffffffe) != (code *)0x0)) {
      puStack_fc = (undefined4 *)&stack0x00000028;
      pcStack_f4 = (char *)0x2;
      uStack_100 = 0x97e55c;
      piStack_f8 = puStack_fc;
      (**(code **)(in_stack_00000020 & 0xfffffffe))();
    }
    in_stack_00000020 = 0;
  }
  uStack_8 = 7;
  if (((in_stack_00000040 != 0) && ((in_stack_00000040 & 1) == 0)) &&
     (*(code **)(in_stack_00000040 & 0xfffffffe) != (code *)0x0)) {
    puStack_fc = (undefined4 *)&stack0x00000048;
    pcStack_f4 = (char *)0x2;
    uStack_100 = 0x97e58a;
    piStack_f8 = puStack_fc;
    (**(code **)(in_stack_00000040 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17783 ; VA 0x0097e5b0 ; FUN_0097e5b0 */

void FUN_0097e5b0(int param_1,int param_2,uint param_3)

{
  undefined uVar1;
  int iVar2;
  uint in_stack_0000002c;
  undefined auStack_c4 [28];
  undefined4 uStack_a8;
  undefined *puStack_a4;
  int iStack_a0;
  int iStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined auStack_90 [24];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_54;
  char *pcStack_50;
  undefined4 uStack_4c;
  undefined uStack_48;
  undefined4 uStack_40;
  undefined *puStack_3c;
  undefined *puStack_38;
  undefined4 uStack_34;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cff30;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if ((param_2 < 1) && ((param_2 < 0 || (param_1 == 0)))) {
    uStack_4c = 0x3d;
    puStack_38 = (undefined *)0x0;
    uStack_34 = 0xf;
    pcStack_50 = "Players:GetHumanoidDescriptionFromUserId() got invalid userId";
    uStack_48 = 0;
    uStack_54 = 0x97e604;
    ExceptionList = &pvStack_10;
    FUN_005542c0();
    uStack_4c = 0x97e60c;
    FUN_005e65e0();
  }
  else {
    puStack_38 = (undefined *)0x97e617;
    ExceptionList = &pvStack_10;
    iVar2 = FUN_00965f10();
    uVar1 = DAT_01ee2fe9;
    if (iVar2 != 0) {
      uStack_54 = 0;
      FUN_0054f510();
      uStack_8._0_1_ = 2;
      FUN_0054f510(&param_3);
      uStack_8._0_1_ = 1;
      FUN_00964e40(&puStack_a4,FUN_0097e770,uVar1,0);
      uStack_a8 = 0x97e681;
      FUN_0095fed0();
      uStack_8._0_1_ = 3;
      uStack_74 = 0;
      FUN_0054f510(&stack0x0000002c);
      uStack_8._0_1_ = 4;
      FUN_0054f510(&param_3);
      uStack_8._0_1_ = 3;
      FUN_00964e40(auStack_c4,FUN_0097e770,uVar1,1);
      FUN_0095fed0();
      uStack_74 = 7;
      uStack_78 = 0;
      puStack_a4 = auStack_90;
      uStack_8._0_1_ = 5;
      uStack_94 = 0;
      uStack_98 = 0;
      iStack_9c = param_2;
      iStack_a0 = param_1;
      uStack_a8 = 0x97e6f2;
      FUN_00f53dc0();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uStack_94 = 0x97e701;
      FUN_00bcb620();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      puStack_3c = &stack0x00000014;
      uStack_34 = 2;
      uStack_40 = 0x97e722;
      puStack_38 = puStack_3c;
      (**(code **)(param_3 & 0xfffffffe))();
    }
    param_3 = 0;
  }
  uStack_8 = 7;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    puStack_3c = &stack0x00000034;
    uStack_34 = 2;
    uStack_40 = 0x97e750;
    puStack_38 = puStack_3c;
    (**(code **)(in_stack_0000002c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17784 ; VA 0x0097e770 ; FUN_0097e770 */

void FUN_0097e770(undefined4 *param_1)

{
  int iVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  undefined4 *puVar6;
  int in_stack_00000014;
  uint in_stack_00000018;
  char in_stack_0000001c;
  uint in_stack_00000020;
  uint in_stack_00000040;
  undefined auStack_108 [8];
  undefined4 uStack_100;
  undefined4 *puStack_fc;
  int *piStack_f8;
  char *pcStack_f4;
  int iStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cff6b;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  pcStack_f4 = (char *)0x97e79c;
  ExceptionList = &pvStack_10;
  iStack_e8 = FUN_00888530();
  iStack_e4 = 0;
  uStack_8._0_1_ = 3;
  if (in_stack_0000001c != '\0') {
    pcStack_f4 = (char *)0x0;
    piStack_f8 = &iStack_e8;
    puStack_fc = &param_1;
    uStack_100 = 0x97e7cc;
    cVar3 = FUN_0098ef90();
    iVar1 = iStack_e8;
    if (cVar3 != '\0') {
      pcStack_f4 = (char *)0x97e7e2;
      iVar4 = FUN_008881d0();
      if (iVar1 != iVar4) {
        pcStack_f4 = "Variant cast failed";
                    /* WARNING: Subroutine does not return */
        piStack_f8 = (int *)0x97e987;
        FUN_016757c0();
      }
      pcStack_f4 = auStack_e0;
      if (iStack_e4 == 0) {
        pcStack_f4 = (undefined *)0x0;
      }
      piStack_f8 = (int *)auStack_18;
      puStack_fc = (undefined4 *)0x97e805;
      piVar5 = (int *)FUN_00e2ef10();
      uStack_8._0_1_ = 4;
      piStack_f8 = (int *)*piVar5;
      pcStack_f4 = (char *)piVar5[1];
      *piVar5 = 0;
      piVar5[1] = 0;
      puStack_fc = (undefined4 *)0x97e839;
      FUN_0096e490();
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_14[1] + -1;
        piStack_14[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          pcStack_f4 = (char *)0x97e852;
          (**(code **)*piStack_14)();
          LOCK();
          piVar5 = piStack_14 + 2;
          iVar1 = *piVar5;
          *piVar5 = *piVar5 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            pcStack_f4 = (char *)0x97e861;
            (**(code **)(*piStack_14 + 4))();
          }
        }
      }
      goto LAB_0097e8b4;
    }
  }
  if (in_stack_00000014 == 0) {
    piStack_f8 = (int *)0x0;
    pcStack_f4 = (char *)0xf;
    auStack_108[0] = 0;
    FUN_005542c0("Players:GetHumanoidDescriptionFromUserId() failed because of an unknown error.",
                 0x4e);
  }
  else {
    puVar6 = &param_1;
    if (0xf < in_stack_00000018) {
      puVar6 = param_1;
    }
    FUN_01675640(auStack_108,"Players:GetHumanoidDescriptionFromUserId() failed because %s",puVar6);
  }
  FUN_005e65e0();
LAB_0097e8b4:
  uStack_8._0_1_ = 5;
  if (iStack_e4 != 0) {
    pcStack_f4 = auStack_e0;
    piStack_f8 = (int *)0x97e8ce;
    (**(code **)(iStack_e4 + 8))();
  }
  uStack_8._0_1_ = 1;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    pcStack_f4 = (char *)(in_stack_00000018 + 1);
    puVar6 = param_1;
    if (0xfff < pcStack_f4) {
      puVar6 = (undefined4 *)param_1[-1];
      pcStack_f4 = (char *)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        pcStack_f4 = &UNK_0097e98c;
        uStack_8._0_1_ = uVar2;
        FUN_017167a3();
      }
    }
    puStack_fc = (undefined4 *)0x97e906;
    piStack_f8 = puVar6;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = (undefined4 *)((uint)param_1 & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (in_stack_00000020 != 0) {
    if (((in_stack_00000020 & 1) == 0) &&
       (*(code **)(in_stack_00000020 & 0xfffffffe) != (code *)0x0)) {
      puStack_fc = (undefined4 *)&stack0x00000028;
      pcStack_f4 = (char *)0x2;
      uStack_100 = 0x97e93c;
      piStack_f8 = puStack_fc;
      (**(code **)(in_stack_00000020 & 0xfffffffe))();
    }
    in_stack_00000020 = 0;
  }
  uStack_8 = 7;
  if (((in_stack_00000040 != 0) && ((in_stack_00000040 & 1) == 0)) &&
     (*(code **)(in_stack_00000040 & 0xfffffffe) != (code *)0x0)) {
    puStack_fc = (undefined4 *)&stack0x00000048;
    pcStack_f4 = (char *)0x2;
    uStack_100 = 0x97e96a;
    piStack_f8 = puStack_fc;
    (**(code **)(in_stack_00000040 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17785 ; VA 0x0097e9b0 ; FUN_0097e9b0 */

void FUN_0097e9b0(uint param_1,int **param_2,uint param_3,undefined4 param_4,int param_5,
                 undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined8 param_9,
                 int *param_10,undefined4 param_11,int *param_12,undefined4 *param_13,int **param_14
                 ,int *param_15,undefined8 param_16)

{
  int *piVar1;
  int **ppiVar2;
  uint *puVar3;
  int **ppiVar4;
  char cVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined **ppuVar8;
  int iVar9;
  uint uVar10;
  int *piVar11;
  undefined8 uVar12;
  uint auStack_194 [2];
  int iStack_18c;
  undefined4 uStack_188;
  undefined4 uStack_184;
  undefined4 uStack_180;
  undefined8 uStack_17c;
  int *piStack_174;
  int *piStack_170;
  undefined4 auStack_16c [4];
  undefined4 uStack_15c;
  undefined4 *puStack_158;
  int **ppiStack_154;
  undefined4 uStack_150;
  int *piStack_14c;
  undefined4 **ppuStack_148;
  int *piStack_144;
  undefined4 *puStack_140;
  undefined8 uStack_13c;
  undefined8 uStack_134;
  undefined auStack_124 [40];
  undefined auStack_fc [40];
  undefined auStack_d4 [40];
  undefined auStack_ac [40];
  undefined auStack_84 [40];
  undefined auStack_5c [16];
  int aiStack_4c [5];
  uint uStack_38;
  code *pcStack_34;
  int iStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  int **ppiStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar11 = (int *)param_2;
  uVar10 = param_1;
  puStack_c = &LAB_017d000b;
  pvStack_10 = ExceptionList;
  piStack_28 = (int *)0x0;
  piStack_24 = (int *)0x0;
  uStack_134 = 100;
  uStack_13c._4_4_ = (int *)param_2;
  uStack_13c._0_4_ = (int **)param_1;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  puStack_140 = (undefined4 *)0x97e9fd;
  ExceptionList = &pvStack_10;
  uStack_13c = FUN_016f3900();
  uStack_134 = 100;
  puStack_140 = (undefined4 *)0x97ea08;
  uVar12 = FUN_016f39b0();
  iVar9 = (int)piVar11 + (-(uint)(uVar10 < (uint)uVar12) - (int)((ulonglong)uVar12 >> 0x20));
  if (((int)DAT_01f1c198 >> 0x1f < iVar9) ||
     (((int)DAT_01f1c198 >> 0x1f <= iVar9 && (DAT_01f1c198 <= uVar10 - (uint)uVar12)))) {
    uStack_134 = CONCAT44(piVar11,param_1);
    uStack_13c._4_4_ = aiStack_4c;
    uStack_13c._0_4_ = (int **)0x97ead1;
    FUN_00f82d70();
    uStack_13c._0_4_ = ppiStack_14;
    uStack_8._0_1_ = 4;
    param_2 = (int **)0x7;
    puStack_140 = (undefined4 *)0x97eae4;
    puStack_140 = (undefined4 *)FUN_008f7870();
    piStack_144 = &iStack_30;
    ppuStack_148 = (undefined4 **)0x97eaee;
    uStack_150 = FUN_005e5de0();
    ppuStack_148 = &param_2;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    piStack_14c = aiStack_4c;
    ppiStack_154 = &piStack_20;
    puStack_158 = (undefined4 *)0x97eb04;
    puVar7 = (undefined4 *)FUN_00965d10();
    piStack_28 = (int *)*puVar7;
    piVar11 = (int *)puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    param_2 = (int **)piStack_1c;
    piStack_24 = piVar11;
    piStack_18 = piStack_28;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar9 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        uStack_134 = CONCAT44(0x97eb3c,(undefined4)uStack_134);
        (**(code **)*piStack_1c)();
        LOCK();
        iVar9 = ((int *)param_2)[2] + -1;
        ((int *)param_2)[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          uStack_134 = CONCAT44(0x97eb4d,(undefined4)uStack_134);
          (**(code **)((int)*param_2 + 4))();
        }
      }
    }
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar9 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        uStack_134 = CONCAT44(0x97eb62,(undefined4)uStack_134);
        (**(code **)(*piStack_2c + 4))();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (0xf < uStack_38) {
      uVar10 = uStack_38 + 1;
      iVar9 = aiStack_4c[0];
      if (0xfff < uVar10) {
        iVar9 = *(int *)(aiStack_4c[0] + -4);
        uVar10 = uStack_38 + 0x24;
        if (0x1f < (aiStack_4c[0] - iVar9) - 4U) {
          uStack_134 = CONCAT44(&UNK_0097ee1a,(undefined4)uStack_134);
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      uStack_134 = CONCAT44(uVar10,iVar9);
      uStack_13c._4_4_ = (int *)0x97eb97;
      FUN_01674ea0();
    }
  }
  else {
    piStack_18 = (int *)0x7;
    uStack_134._4_4_ = ppiStack_14;
    uStack_134._0_4_ = 0x97ea35;
    uVar6 = FUN_008f7870();
    uStack_134 = CONCAT44(uStack_134._4_4_,uVar6);
    uStack_13c._4_4_ = &iStack_30;
    uStack_13c._0_4_ = (int **)0x97ea3f;
    piStack_144 = (int *)FUN_005e5de0();
    uStack_13c._0_4_ = &piStack_18;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    puStack_140 = &param_1;
    ppuStack_148 = &piStack_20;
    piStack_14c = (int *)0x97ea55;
    puVar7 = (undefined4 *)FUN_00965e10();
    piStack_28 = (int *)*puVar7;
    piVar11 = (int *)puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    param_2 = (int **)piStack_1c;
    piStack_24 = piVar11;
    piStack_18 = piStack_28;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar9 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        uStack_134 = CONCAT44(0x97ea8d,(undefined4)uStack_134);
        (**(code **)*piStack_1c)();
        LOCK();
        iVar9 = ((int *)param_2)[2] + -1;
        ((int *)param_2)[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          uStack_134 = CONCAT44(0x97ea9e,(undefined4)uStack_134);
          (**(code **)((int)*param_2 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar9 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        uStack_134 = CONCAT44(0x97eabf,(undefined4)uStack_134);
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  param_2 = &piStack_14c;
  ppiStack_14 = &piStack_14c;
  pcStack_34 = *(code **)(*piStack_18 + 0xa4);
  piStack_14c = (int *)0x0;
  ppiVar2 = &piStack_14c;
  if (param_10 != (int *)0x0) {
    piStack_14c = param_10;
    if (((uint)param_10 & 1) == 0) {
      ppiStack_154 = &piStack_144;
      uStack_150 = 0;
      puStack_158 = &param_12;
      uStack_15c = 0x97ebec;
      (**(code **)((uint)param_10 & 0xfffffffe))();
      ppiVar2 = param_2;
    }
    else {
      piStack_144 = param_12;
      puStack_140 = param_13;
      uStack_13c._0_4_ = param_14;
      uStack_13c._4_4_ = param_15;
      uStack_134 = param_16;
      ppiVar2 = &piStack_14c;
    }
  }
  param_2 = ppiVar2;
  ppiStack_14 = (int **)auStack_16c;
  piStack_2c = (int *)&piStack_174;
  if (piVar11 != (int *)0x0) {
    LOCK();
    piVar11[1] = piVar11[1] + 1;
    UNLOCK();
  }
  piStack_1c = (int *)auStack_194;
  uStack_8._0_1_ = 7;
  auStack_194[0] = 0;
  piStack_174 = piStack_18;
  piStack_170 = piVar11;
  ppiVar2 = &piStack_174;
  puVar3 = auStack_194;
  ppiVar4 = (int **)auStack_16c;
  if (param_3 != 0) {
    auStack_194[0] = param_3;
    if ((param_3 & 1) == 0) {
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&iStack_18c,0);
      ppiVar2 = (int **)piStack_2c;
      puVar3 = (uint *)piStack_1c;
      ppiVar4 = ppiStack_14;
    }
    else {
      iStack_18c = param_5;
      uStack_188 = param_6;
      uStack_184 = param_7;
      uStack_180 = param_8;
      uStack_17c = param_9;
      ppiVar2 = &piStack_174;
      puVar3 = auStack_194;
      ppiVar4 = (int **)auStack_16c;
    }
  }
  ppiStack_14 = ppiVar4;
  piStack_1c = (int *)puVar3;
  piStack_2c = (int *)ppiVar2;
  uStack_8._0_1_ = 6;
  FUN_009649e0(auStack_124);
  piStack_170 = (int *)auStack_124;
  uStack_8._0_1_ = 8;
  piStack_174 = (int *)0x97ec8b;
  FUN_008c1490();
  uStack_8._0_1_ = 9;
  *ppiStack_14 = (int *)0x0;
  piStack_170 = (int *)auStack_fc;
  piStack_174 = (int *)0x97ecaa;
  FUN_008c1490();
  piStack_170 = (int *)auStack_d4;
  uStack_8._0_1_ = 10;
  piStack_174 = (int *)0x97ecc0;
  FUN_008c1490();
  piStack_170 = (int *)auStack_ac;
  uStack_8._0_1_ = 0xb;
  piStack_174 = (int *)0x97ecd3;
  FUN_008c1490();
  piStack_170 = (int *)auStack_5c;
  uStack_8._0_1_ = 0xc;
  piStack_174 = (int *)0x97ece0;
  cVar5 = FUN_00585a40();
  if (cVar5 == '\0') {
    piStack_170 = (int *)auStack_5c;
    piStack_174 = (int *)0x97ecf3;
    FUN_008c1490();
    piStack_170 = (int *)0x28;
    uStack_8._0_1_ = 0xd;
    piStack_174 = (int *)0x97ecfe;
    piStack_1c = (int *)FUN_01674e20();
    uStack_8._0_1_ = 0xe;
    if (piStack_1c == (int *)0x0) {
      uVar6 = 0;
    }
    else {
      piStack_170 = (int *)auStack_84;
      piStack_174 = (int *)0x97ed17;
      uVar6 = FUN_008c1490();
    }
    ppiStack_14[2] = (int *)uVar6;
    piStack_170 = (int *)0x97ed29;
    FUN_008c3670();
    piStack_170 = (int *)0x97ed31;
    FUN_008c3670();
    param_2 = (int **)CONCAT13(1,param_2._0_3_);
  }
  else {
    piStack_170 = (int *)0x97ed3f;
    FUN_008c3670();
    param_2 = (int **)((uint)param_2 & 0xffffff);
  }
  piStack_170 = (int *)0x97ed4e;
  FUN_008c3670();
  ppuVar8 = &PTR_FUN_01936c28;
  if (param_2._3_1_ == '\0') {
    ppuVar8 = (undefined **)0x0;
  }
  *ppiStack_14 = (int *)ppuVar8;
  piStack_170 = (int *)0x97ed6b;
  FUN_008c3670();
  piStack_170 = (int *)0x97ed76;
  FUN_008c3670();
  uStack_8._0_1_ = 6;
  piStack_170 = (int *)0x97ed85;
  FUN_008c3670();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  piStack_170 = (int *)0x97ed8f;
  (*pcStack_34)();
  if (piVar11 != (int *)0x0) {
    LOCK();
    iVar9 = piVar11[1] + -1;
    piVar11[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      piStack_170 = (int *)0x97eda2;
      (**(code **)*piVar11)();
      LOCK();
      piVar1 = piVar11 + 2;
      iVar9 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar9 == 1) {
        piStack_170 = (int *)0x97edb1;
        (**(code **)(*piVar11 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      piStack_174 = &param_5;
      piStack_170 = (int *)0x2;
      uStack_17c = CONCAT44(piStack_174,0x97edd2);
      (**(code **)(param_3 & 0xfffffffe))();
    }
    param_3 = 0;
  }
  uStack_8 = 0x10;
  if (((param_10 != (int *)0x0) && (((uint)param_10 & 1) == 0)) &&
     (*(code **)((uint)param_10 & 0xfffffffe) != (code *)0x0)) {
    piStack_174 = (int *)&param_12;
    piStack_170 = (int *)0x2;
    uStack_17c = CONCAT44(piStack_174,0x97ee00);
    (**(code **)((uint)param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17786 ; VA 0x0097ee20 ; FUN_0097ee20 */

undefined4 FUN_0097ee20(undefined4 param_1)

{
  char cVar1;
  char cVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  
  cVar1 = FUN_0068a900(param_1,1);
  cVar2 = FUN_0064a9e0(param_1,1);
  iVar4 = FUN_0064e810(param_1);
  if (iVar4 == 0) {
    iVar4 = 0;
  }
  else {
    iVar4 = *(int *)(iVar4 + 0xf4);
  }
  iVar5 = FUN_005eef10(param_1);
  if (iVar5 == 0) {
    iVar5 = FUN_0064e920(param_1);
    if (iVar5 == 0) goto LAB_0097ee85;
    cVar3 = *(int *)(iVar5 + 0x124) == 2;
  }
  else {
    cVar3 = FUN_0068ba60();
  }
  if (cVar3 != '\0') {
    return 2;
  }
LAB_0097ee85:
  if (cVar2 != '\0') {
    return 0;
  }
  if ((cVar1 != '\0') && (iVar4 != 0)) {
    return 1;
  }
  return 2;
}



/* FUNCTION 17787 ; VA 0x0097eeb0 ; FUN_0097eeb0 */

undefined4 * __fastcall FUN_0097eeb0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  
  puVar1 = (undefined4 *)(param_1 + 0xac);
  if (*(int *)(param_1 + 0xac) == 0) {
    iVar4 = *(int *)(param_1 + 0x34);
    if ((iVar4 != 0) && (param_1 = iVar4, *(int *)(iVar4 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 == 0) ||
       (iVar4 = *(int *)(param_1 + 0xc), iVar3 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar3 + 0x1da) <
       (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
      iVar4 = 0;
    }
    else {
      iVar4 = FUN_006b8d70();
    }
    piVar2 = *(int **)(iVar4 + 0x58);
    if (piVar2 != (int *)0x0) {
      LOCK();
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    *puVar1 = piVar2;
    FUN_00611620();
  }
  return puVar1;
}



/* FUNCTION 17788 ; VA 0x0097ef40 ; FUN_0097ef40 */

undefined FUN_0097ef40(byte *param_1,int *param_2,char *param_3,undefined param_4)

{
  int *piVar1;
  char cVar2;
  byte bVar3;
  int iVar4;
  undefined uVar5;
  undefined4 uVar6;
  char *pcVar7;
  uint uVar8;
  uint uVar9;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cfa38;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  pcVar7 = param_3;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(param_3,(int)pcVar7 - (int)(param_3 + 1));
  bVar3 = *param_1;
  uVar6 = FUN_005702d0(auStack_28);
  FUN_00562fc0(&param_3,uVar6,auStack_28,
               -(uint)(param_1 + bVar3 + 1 != (byte *)0x0) & (uint)(param_1 + bVar3 + 1 + 1));
  if (0xf < uStack_14) {
    uVar9 = uStack_14 + 1;
    uVar8 = auStack_28[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_28[0] - 4);
      uVar9 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  uVar5 = param_4;
  if (param_3 != (char *)0x0) {
    uVar5 = FUN_00636260();
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar4 = param_2[1] + -1;
    param_2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 17789 ; VA 0x0097f060 ; FUN_0097f060 */

undefined8
FUN_0097f060(byte *param_1,int *param_2,char *param_3,undefined4 param_4,undefined4 param_5)

{
  int *piVar1;
  char cVar2;
  byte bVar3;
  int iVar4;
  undefined4 uVar5;
  char *pcVar6;
  uint uVar7;
  uint uVar8;
  undefined8 uVar9;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cfa38;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  pcVar6 = param_3;
  do {
    cVar2 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar2 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(param_3,(int)pcVar6 - (int)(param_3 + 1));
  bVar3 = *param_1;
  uVar5 = FUN_005702d0(auStack_28);
  FUN_00562fc0(&param_3,uVar5,auStack_28,
               -(uint)(param_1 + bVar3 + 1 != (byte *)0x0) & (uint)(param_1 + bVar3 + 1 + 1));
  if (0xf < uStack_14) {
    uVar8 = uStack_14 + 1;
    uVar7 = auStack_28[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_28[0] - 4);
      uVar8 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (param_3 == (char *)0x0) {
    uVar9 = CONCAT44(param_5,param_4);
  }
  else {
    uVar9 = FUN_00563790();
  }
  param_3 = (char *)((ulonglong)uVar9 >> 0x20);
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar4 = param_2[1] + -1;
    param_2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return CONCAT44(param_3,(int)uVar9);
}



/* FUNCTION 17790 ; VA 0x0097f190 ; FUN_0097f190 */

undefined4 FUN_0097f190(byte *param_1,int *param_2,char *param_3,undefined4 param_4)

{
  int *piVar1;
  char cVar2;
  byte bVar3;
  int iVar4;
  undefined4 uVar5;
  char *pcVar6;
  uint uVar7;
  uint uVar8;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cfa38;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  pcVar6 = param_3;
  do {
    cVar2 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar2 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(param_3,(int)pcVar6 - (int)(param_3 + 1));
  bVar3 = *param_1;
  uVar5 = FUN_005702d0(auStack_28);
  FUN_00562fc0(&param_3,uVar5,auStack_28,
               -(uint)(param_1 + bVar3 + 1 != (byte *)0x0) & (uint)(param_1 + bVar3 + 1 + 1));
  if (0xf < uStack_14) {
    uVar8 = uStack_14 + 1;
    uVar7 = auStack_28[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_28[0] - 4);
      uVar8 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  uVar5 = param_4;
  if (param_3 != (char *)0x0) {
    uVar5 = FUN_00563070();
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar4 = param_2[1] + -1;
    param_2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 17791 ; VA 0x0097f2b0 ; FUN_0097f2b0 */

uint * FUN_0097f2b0(uint *param_1,byte *param_2,int *param_3,char *param_4,uint param_5,uint param_6
                   ,uint param_7,uint param_8,undefined4 param_9,uint param_10)

{
  int *piVar1;
  char cVar2;
  byte bVar3;
  int iVar4;
  undefined4 uVar5;
  char *pcVar6;
  uint uVar7;
  uint uVar8;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179e2d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  pcVar6 = param_4;
  do {
    cVar2 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar2 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(param_4,(int)pcVar6 - (int)(param_4 + 1));
  bVar3 = *param_2;
  uVar5 = FUN_005702d0(auStack_28);
  FUN_00562fc0(&param_4,uVar5,auStack_28,
               -(uint)(param_2 + bVar3 + 1 != (byte *)0x0) & (uint)(param_2 + bVar3 + 1 + 1));
  if (0xf < uStack_14) {
    uVar8 = uStack_14 + 1;
    uVar7 = auStack_28[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_28[0] - 4);
      uVar8 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  uVar7 = param_5;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (param_4 == (char *)0x0) {
    param_5 = param_5 & 0xffffff00;
    param_1[4] = 0;
    param_1[5] = 0;
    *param_1 = uVar7;
    param_1[1] = param_6;
    param_1[2] = param_7;
    param_1[3] = param_8;
    *(ulonglong *)(param_1 + 4) = CONCAT44(param_10,param_9);
    param_9 = 0;
    param_10 = 0xf;
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar4 = param_3[1] + -1;
      param_3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*param_3)();
        LOCK();
        piVar1 = param_3 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*param_3 + 4))();
        }
      }
      if (0xf < param_10) {
        uVar8 = param_10 + 1;
        uVar7 = param_5;
        if (0xfff < uVar8) {
          uVar7 = *(uint *)(param_5 - 4);
          uVar8 = param_10 + 0x24;
          if (0x1f < (param_5 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar7,uVar8);
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_00563690(param_1);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar4 = param_3[1] + -1;
    param_3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < param_10) {
    uVar8 = param_10 + 1;
    uVar7 = param_5;
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(param_5 - 4);
      uVar8 = param_10 + 0x24;
      if (0x1f < (param_5 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17792 ; VA 0x0097f4b0 ; FUN_0097f4b0 */

undefined4 __thiscall
FUN_0097f4b0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  char *pcVar3;
  undefined auStack_10 [12];
  
  iVar2 = FUN_008f78c0(param_1);
  if (iVar2 == 0) {
    pcVar3 = "Could not find DataModel";
  }
  else {
    if (*(int *)(iVar2 + 0x4a0) == 2) {
      piVar1 = *(int **)(iVar2 + 0x43c);
      FUN_00f553f0(param_2,param_3,param_4,*piVar1 - (int)piVar1,piVar1[1] - (int)piVar1);
      return param_2;
    }
    pcVar3 = "No LoadData url set";
  }
  FUN_00550130(pcVar3);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 17793 ; VA 0x0097f530 ; FUN_0097f530 */

undefined4 __fastcall FUN_0097f530(int param_1)

{
  return *(undefined4 *)(param_1 + 0xe4);
}



/* FUNCTION 17794 ; VA 0x0097f540 ; FUN_0097f540 */

void __thiscall FUN_0097f540(int param_1,undefined4 *param_2,int param_3,uint param_4)

{
  int *piVar1;
  bool bVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int *piVar7;
  int *piVar8;
  int iVar9;
  uint in_stack_0000002c;
  undefined4 in_stack_ffffff2c;
  undefined4 in_stack_ffffff30;
  undefined4 in_stack_ffffff34;
  undefined4 in_stack_ffffff38;
  undefined *puStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  int *piStack_b8;
  undefined8 uStack_b4;
  undefined4 *puStack_a0;
  int iStack_9c;
  undefined4 auStack_98 [8];
  undefined4 auStack_78 [8];
  undefined auStack_58 [16];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined auStack_40 [16];
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d0076;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  if ((-1 < param_3) &&
     ((0 < param_3 || (ExceptionList = &pvStack_10, param_2 != (undefined4 *)0x0)))) {
    piStack_b8 = &iStack_18;
    uStack_b4 = (double)CONCAT44(param_3,param_2);
    uStack_bc = 0x97f596;
    ExceptionList = &pvStack_10;
    FUN_0097fc00();
    piVar8 = piStack_14;
    uStack_8._0_1_ = 2;
    if (iStack_18 != 0) {
      FUN_0054ef60(*(undefined4 *)(iStack_18 + 0x28));
      FUN_005e65e0();
      piVar8 = piStack_14;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_14[1] + -1;
        piStack_14[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          uStack_b4 = (double)CONCAT44(0x97f5d7,(undefined4)uStack_b4);
          (**(code **)*piStack_14)();
          LOCK();
          piVar7 = piVar8 + 2;
          iVar4 = *piVar7;
          *piVar7 = *piVar7 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            uStack_b4 = (double)CONCAT44(0x97f5ea,(undefined4)uStack_b4);
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      goto LAB_0097f9ca;
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_14[1] + -1;
      piStack_14[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        uStack_b4 = (double)CONCAT44(0x97f605,(undefined4)uStack_b4);
        (**(code **)*piStack_14)();
        LOCK();
        piVar7 = piVar8 + 2;
        iVar4 = *piVar7 + -1;
        *piVar7 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          uStack_b4 = (double)CONCAT44(0x97f615,(undefined4)uStack_b4);
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
  iStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = 0;
  uStack_8._0_1_ = 3;
  uStack_b4 = (double)CONCAT44(auStack_40,param_3);
  piStack_b8 = param_2;
  uStack_bc = 0x97f640;
  cVar3 = FUN_00f89590();
  if (cVar3 == '\0') {
    uStack_b4 = (double)CONCAT44(param_1,0x97f6bc);
    iVar4 = FUN_0064e700();
    if (iVar4 != 0) {
      auStack_98[0] = 0;
      auStack_78[0] = 0;
      puStack_a0 = param_2;
      iStack_9c = param_3;
      uStack_8._0_1_ = 5;
      uStack_b4 = (double)CONCAT44(&param_4,0x97f6fd);
      FUN_008c4480();
      uStack_b4 = (double)CONCAT44(&stack0x0000002c,0x97f709);
      FUN_008c4480();
      piVar8 = *(int **)(param_1 + 0x1c8);
      piVar7 = (int *)(param_1 + 0x1c8);
      bVar2 = false;
      if (piVar8 == (int *)0x0) {
        uStack_b4 = 2.54688699941159e-313;
        puVar5 = (undefined4 *)FUN_01674e20();
        if (puVar5 == (undefined4 *)0x0) {
          puVar5 = (undefined4 *)0x0;
        }
        else {
          *puVar5 = 0;
          puVar5[1] = 0;
          puVar5[2] = 0;
        }
        uStack_b4 = (double)ZEXT48(puVar5);
        piStack_b8 = (undefined4 *)0x97f755;
        FUN_00962d90();
        *piVar7 = 0;
        piVar8 = *(int **)(param_1 + 0x1cc);
        *(undefined4 *)(param_1 + 0x1cc) = 0;
        if (piVar8 != (int *)0x0) {
          LOCK();
          iVar4 = piVar8[1] + -1;
          piVar8[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            uStack_b4 = (double)CONCAT44(0x97f776,(undefined4)uStack_b4);
            (**(code **)*piVar8)();
            LOCK();
            iVar4 = piVar8[2] + -1;
            piVar8[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              uStack_b4 = (double)CONCAT44(0x97f786,(undefined4)uStack_b4);
              (**(code **)(*piVar8 + 4))();
            }
          }
        }
        piVar8 = (int *)*piVar7;
        if ((uint)((piVar8[2] - *piVar8) / 0x48) < DAT_01d64614) {
          if (0x38e38e3 < DAT_01d64614) {
            uStack_b4 = (double)CONCAT44(&UNK_0097fa34,(undefined4)uStack_b4);
                    /* WARNING: Subroutine does not return */
            FUN_00577c30();
          }
          uStack_b4 = (double)CONCAT44(DAT_01d64614,0x97f7bc);
          FUN_00970f80();
          piVar8 = (int *)*piVar7;
        }
        bVar2 = true;
      }
      piStack_24 = (int *)piVar8[1];
      if ((int *)piVar8[2] == piStack_24) {
        uStack_b4 = (double)CONCAT44(&puStack_a0,piStack_24);
        piStack_b8 = (undefined4 *)0x97f828;
        FUN_00961df0();
      }
      else {
        *piStack_24 = (int)puStack_a0;
        piStack_24[1] = iStack_9c;
        piStack_24[2] = 0;
        uStack_b4 = (double)CONCAT44(auStack_98,0x97f7f6);
        piStack_14 = piStack_24;
        FUN_005880d0();
        uStack_8._0_1_ = 6;
        piStack_24[10] = 0;
        uStack_b4 = (double)CONCAT44(auStack_78,0x97f80f);
        FUN_005880d0();
        piVar8[1] = piVar8[1] + 0x48;
        uStack_8._0_1_ = 5;
      }
      if (bVar2) {
        uStack_b4._4_4_ = iStack_1c;
        uStack_b4._0_4_ = 0x97f83a;
        uVar6 = FUN_008f7870();
        piStack_b8 = &uStack_28;
        uStack_b4 = (double)CONCAT44(uStack_b4._4_4_,uVar6);
        uStack_bc = 0x97f846;
        FUN_005e5de0();
        uStack_8 = CONCAT31(uStack_8._1_3_,7);
        uStack_b4 = (double)CONCAT44(0x97f855,(undefined4)uStack_b4);
        FUN_005cf2a0();
        piVar8 = piStack_24;
        uStack_b4 = (double)DAT_01d6461c / DAT_018c0d70;
        if (piStack_24 != (int *)0x0) {
          LOCK();
          piStack_24[2] = piStack_24[2] + 1;
          UNLOCK();
          LOCK();
          piStack_24[2] = piStack_24[2] + 1;
          UNLOCK();
        }
        FUN_0095f860(uStack_28,piStack_24,0);
        if (piVar8 != (int *)0x0) {
          LOCK();
          iVar4 = piVar8[2] + -1;
          piVar8[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
        uVar6 = FUN_009eef30(in_stack_ffffff2c,in_stack_ffffff30,in_stack_ffffff34,in_stack_ffffff38
                            );
        uStack_8._0_1_ = 5;
        *(undefined4 *)(iStack_1c + 0x1d0) = uVar6;
        if (piVar8 != (int *)0x0) {
          LOCK();
          piVar1 = piVar8 + 2;
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            uStack_b4 = (double)CONCAT44(0x97f8e9,(undefined4)uStack_b4);
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      iVar4 = iStack_1c;
      if (DAT_01d64614 <= (uint)((((int *)*piVar7)[1] - *(int *)*piVar7) / 0x48)) {
        uStack_b4 = (double)CONCAT44(iStack_1c,0x97f916);
        uVar6 = FUN_008f7870();
        iVar9 = *(int *)(param_1 + 0x1cc);
        if (iVar9 != 0) {
          LOCK();
          *(int *)(iVar9 + 4) = *(int *)(iVar9 + 4) + 1;
          UNLOCK();
          iVar9 = *(int *)(param_1 + 0x1cc);
        }
        piStack_24 = (int *)*piVar7;
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
        uStack_b4 = (double)CONCAT44(0x97f940,(undefined4)uStack_b4);
        piStack_20 = piStack_24;
        iStack_1c = iVar9;
        FUN_0058a2b0();
        if (0 < *(int *)(iVar4 + 0x1d0)) {
          uStack_b4 = (double)CONCAT44(0x97f954,(undefined4)uStack_b4);
          FUN_005cf2a0();
          uStack_b4 = (double)CONCAT44(*(undefined4 *)(iVar4 + 0x1d0),0x97f961);
          FUN_009eee80();
        }
        *(undefined4 *)(iVar4 + 0x1d0) = 0;
        if (iVar9 != 0) {
          LOCK();
          *(int *)(iVar9 + 4) = *(int *)(iVar9 + 4) + 1;
          UNLOCK();
        }
        uStack_b4 = (double)CONCAT44(iVar9,piStack_24);
        puStack_c4 = (undefined *)&uStack_bc;
        uStack_8._0_1_ = 9;
        uStack_c0 = uVar6;
        FUN_005e5de0();
        uStack_8._0_1_ = 8;
        uStack_c0 = 0x97f9ac;
        FUN_0098bda0();
        uStack_b4 = (double)CONCAT44(0x97f9b7,(undefined4)uStack_b4);
        FUN_00550b30();
      }
      uStack_b4 = (double)CONCAT44(0x97f9c2,(undefined4)uStack_b4);
      FUN_0096ca80();
    }
  }
  else if (iStack_30 == 0) {
    uStack_b4 = 8.70148866873503e-313;
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = 0;
    piStack_b8 = (undefined4 *)0x97f66b;
    FUN_005542c0();
    uStack_8._0_1_ = 4;
    FUN_00558c80(&puStack_c4,auStack_58,"Unknown user");
    FUN_005e65e0();
    uStack_b4 = (double)CONCAT44(0x97f696,(undefined4)uStack_b4);
    FUN_005507b0();
  }
  else {
    FUN_0054ef60(auStack_40);
    FUN_005e65e0();
  }
  uStack_b4 = (double)CONCAT44(0x97f9ca,(undefined4)uStack_b4);
  FUN_005507b0();
LAB_0097f9ca:
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      piStack_b8 = (int *)&stack0x00000014;
      uStack_b4 = (double)CONCAT44(2,piStack_b8);
      uStack_bc = 0x97f9eb;
      (**(code **)(param_4 & 0xfffffffe))();
    }
    param_4 = 0;
  }
  uStack_8 = 0xb;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    piStack_b8 = (int *)&stack0x00000034;
    uStack_b4 = (double)CONCAT44(2,piStack_b8);
    uStack_bc = 0x97fa19;
    (**(code **)(in_stack_0000002c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17795 ; VA 0x0097fa40 ; FUN_0097fa40 */

undefined __fastcall FUN_0097fa40(int param_1)

{
  return *(undefined *)(param_1 + 0x144);
}



/* FUNCTION 17796 ; VA 0x0097fa50 ; FUN_0097fa50 */

void __thiscall FUN_0097fa50(int param_1,int *param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0090;
  pvStack_10 = ExceptionList;
  if ((*param_3 == 0) && (param_1 != 0)) {
    iVar4 = *(int *)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    if ((iVar4 != 0) && (param_1 = iVar4, ExceptionList = &pvStack_10, *(int *)(iVar4 + 0x34) != 0))
    {
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
    }
    if (((param_1 != 0) &&
        (iVar4 = *(int *)(param_1 + 0xc), iVar3 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da))) && (iVar4 = FUN_005c2760(), iVar4 != 0)) {
      puStack_24 = (undefined4 *)0x0;
      uStack_20 = 0;
      uStack_1c = 0;
      uStack_8 = 0;
      uVar5 = FUN_009cc450(auStack_3c,param_4);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_008c8540(uVar5,&puStack_24,&DAT_01d62f20);
      if (0xf < uStack_28) {
        uVar7 = uStack_28 + 1;
        uVar6 = auStack_3c[0];
        if (0xfff < uVar7) {
          uVar6 = *(uint *)(auStack_3c[0] - 4);
          uVar7 = uStack_28 + 0x24;
          if (0x1f < (auStack_3c[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar6,uVar7);
      }
      uStack_2c = 0;
      uStack_28 = 0xf;
      auStack_3c[0] = auStack_3c[0] & 0xffffff00;
      piStack_14 = (int *)puStack_24[1];
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piStack_14[1] = piStack_14[1] + 1;
        UNLOCK();
        piStack_14 = (int *)puStack_24[1];
      }
      uStack_18 = *puStack_24;
      FUN_00577ac0();
      FUN_005587e0(&uStack_18);
      piVar2 = piStack_14;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_14[1] + -1;
        piStack_14[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_14)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
    }
  }
  iVar4 = param_3[1];
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar4 != 0) {
    LOCK();
    *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
    UNLOCK();
    iVar4 = param_3[1];
  }
  *param_2 = *param_3;
  param_2[1] = iVar4;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17797 ; VA 0x0097fc00 ; FUN_0097fc00 */

void __thiscall FUN_0097fc00(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined4 *unaff_FS_OFFSET;
  longlong lVar6;
  undefined4 uStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_10 = *unaff_FS_OFFSET;
  puStack_c = &LAB_017d00a8;
  *unaff_FS_OFFSET = &uStack_10;
  puVar5 = (undefined4 *)**(undefined4 **)(param_1 + 0xb8);
  puVar1 = (undefined4 *)(*(undefined4 **)(param_1 + 0xb8))[1];
  while( true ) {
    if (puVar5 == puVar1) {
      *param_2 = 0;
      param_2[1] = 0;
      *unaff_FS_OFFSET = uStack_10;
      return;
    }
    piVar4 = (int *)puVar5[1];
    uVar2 = *puVar5;
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)puVar5[1];
    }
    uStack_8 = 0;
    lVar6 = FUN_00928340();
    if (lVar6 == CONCAT44(param_4,param_3)) break;
    uStack_8 = 0xffffffff;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar3 = piVar4[1] + -1;
      piVar4[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar3 = piVar4[2] + -1;
        piVar4[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    puVar5 = puVar5 + 2;
  }
  *param_2 = uVar2;
  param_2[1] = piVar4;
  *unaff_FS_OFFSET = uStack_10;
  return;
}



/* FUNCTION 17798 ; VA 0x0097fce0 ; FUN_0097fce0 */

int * __thiscall FUN_0097fce0(int param_1,int *param_2,undefined4 *param_3)

{
  int iVar1;
  void **ppvVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  int in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 uStack_50;
  int *piStack_4c;
  undefined4 uStack_48;
  int *piStack_44;
  undefined auStack_40 [4];
  int *piStack_3c;
  int *piStack_38;
  undefined4 *puStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017d00e0;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  piVar5 = (int *)**(int **)(param_1 + 0xb8);
  piStack_38 = (int *)(*(int **)(param_1 + 0xb8))[1];
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  ppvVar2 = &pvStack_10;
  piStack_20 = piVar5;
  if (piVar5 != piStack_38) {
    do {
      piStack_20 = piVar5;
      if ((*piVar5 == 0) ||
         (iVar1 = *(int *)(*piVar5 + 0xc), iVar4 = FUN_00913630(),
         (uint)*(ushort *)(iVar4 + 0x1da) <
         (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
        uVar7 = uStack_18 | 4;
        piStack_44 = (int *)0x0;
        puVar8 = &uStack_48;
        iStack_24 = 0;
      }
      else {
        piStack_4c = (int *)piVar5[1];
        iStack_24 = *piVar5;
        if (piStack_4c != (int *)0x0) {
          LOCK();
          piStack_4c[1] = piStack_4c[1] + 1;
          UNLOCK();
          piStack_4c = (int *)piVar5[1];
        }
        puVar8 = &uStack_50;
        uVar7 = uStack_18 | 2;
      }
      iVar1 = iStack_24;
      piStack_28 = (int *)puVar8[1];
      uStack_18 = uVar7 | 8;
      *puVar8 = 0;
      puVar8[1] = 0;
      piVar5 = piStack_44;
      if (((uVar7 & 4) != 0) && (uStack_18 = uVar7 & 0xfffffffb | 8, piStack_44 != (int *)0x0)) {
        LOCK();
        iVar4 = piStack_44[1] + -1;
        piStack_44[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_44)();
          LOCK();
          piVar6 = piVar5 + 2;
          iVar4 = *piVar6 + -1;
          *piVar6 = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      piVar5 = piStack_4c;
      if (((uStack_18 & 2) != 0) && (uStack_18 = uStack_18 & 0xfffffffd, piStack_4c != (int *)0x0))
      {
        LOCK();
        iVar4 = piStack_4c[1] + -1;
        piStack_4c[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_4c)();
          LOCK();
          piVar6 = piVar5 + 2;
          iVar4 = *piVar6 + -1;
          *piVar6 = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      iStack_8._0_1_ = 2;
      piVar5 = (int *)FUN_016de181(1);
      puVar8 = *(undefined4 **)(iVar1 + 0x28);
      iStack_8._0_1_ = 4;
      piStack_3c = piVar5;
      (**(code **)(*piVar5 + 4))();
      iStack_8._0_1_ = 5;
      puStack_34 = puVar8;
      if (0xf < (uint)puVar8[5]) {
        puStack_34 = (undefined4 *)*puVar8;
      }
      puStack_34 = (undefined4 *)(puVar8[4] + (int)puStack_34);
      if (0xf < (uint)puVar8[5]) {
        puVar8 = (undefined4 *)*puVar8;
      }
      puStack_1c = &param_3;
      if (0xf < in_stack_0000001c) {
        puStack_1c = param_3;
      }
      puStack_1c = (undefined4 *)(in_stack_00000018 + (int)puStack_1c);
      puVar9 = &param_3;
      if (0xf < in_stack_0000001c) {
        puVar9 = param_3;
      }
      if (puVar8 != puStack_34) {
        do {
          if (puVar9 == puStack_1c) goto LAB_0097feca;
          uStack_2c = CONCAT31(uStack_2c._1_3_,*(undefined *)puVar8);
          piVar6 = (int *)FUN_0054e7d0(auStack_40);
          cStack_11 = (**(code **)(*piVar6 + 0x18))(uStack_2c);
          uStack_30 = CONCAT31(uStack_30._1_3_,*(undefined *)puVar9);
          piVar6 = (int *)FUN_0054e7d0(auStack_40);
          cVar3 = (**(code **)(*piVar6 + 0x18))(uStack_30);
          if (cStack_11 != cVar3) {
            iStack_8 = CONCAT31(iStack_8._1_3_,6);
            puVar8 = (undefined4 *)(**(code **)(*piVar5 + 8))();
            if (puVar8 != (undefined4 *)0x0) {
              (**(code **)*puVar8)(1);
            }
            cStack_11 = '\0';
            goto LAB_0097fef4;
          }
          puVar8 = (undefined4 *)((int)puVar8 + 1);
          puVar9 = (undefined4 *)((int)puVar9 + 1);
        } while (puVar8 != puStack_34);
      }
      if (puVar9 == puStack_1c) {
LAB_0097feca:
        cStack_11 = '\x01';
        if (puVar8 != puStack_34) goto LAB_0097fed2;
      }
      else {
LAB_0097fed2:
        cStack_11 = '\0';
      }
      iStack_8 = CONCAT31(iStack_8._1_3_,7);
      puVar8 = (undefined4 *)(**(code **)(*piVar5 + 8))();
      if (puVar8 != (undefined4 *)0x0) {
        (**(code **)*puVar8)(1);
      }
LAB_0097fef4:
      iStack_8 = CONCAT31(iStack_8._1_3_,8);
      puVar8 = (undefined4 *)(**(code **)(*piVar5 + 8))();
      if (puVar8 != (undefined4 *)0x0) {
        (**(code **)*puVar8)(1);
      }
      piVar5 = piStack_28;
      iStack_8 = CONCAT31(iStack_8._1_3_,1);
      if (cStack_11 != '\0') {
        *param_2 = iStack_24;
        param_2[1] = (int)piStack_28;
        goto LAB_0097ffa1;
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_28[1] + -1;
        piStack_28[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          piVar6 = piVar5 + 2;
          iVar1 = *piVar6 + -1;
          *piVar6 = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      piVar5 = piStack_20 + 2;
      ppvVar2 = (void **)ExceptionList;
      piStack_20 = piVar5;
    } while (piVar5 != piStack_38);
  }
  ExceptionList = ppvVar2;
  *param_2 = 0;
  param_2[1] = 0;
LAB_0097ffa1:
  if (0xf < in_stack_0000001c) {
    uVar7 = in_stack_0000001c + 1;
    puVar8 = param_3;
    if (0xfff < uVar7) {
      puVar8 = (undefined4 *)param_3[-1];
      uVar7 = in_stack_0000001c + 0x24;
      if ((undefined *)0x1f < (undefined *)((int)param_3 + (-4 - (int)puVar8))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar8,uVar7);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17799 ; VA 0x0097fff0 ; FUN_0097fff0 */

int FUN_0097fff0(int param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      piVar3 = (int *)FUN_00564080();
      if (*piVar3 == 0) {
        return 0;
      }
      piVar3 = *(int **)(*piVar3 + 0xb8);
      return piVar3[1] - *piVar3 >> 3;
    }
  }
  return 0;
}



/* FUNCTION 17800 ; VA 0x00980070 ; FUN_00980070 */

undefined4 FUN_00980070(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_c;
  int *piStack_8;
  
  uStack_1c = param_1;
  uStack_20 = 0x980082;
  iVar2 = FUN_0064e810();
  if (iVar2 != 0) {
    FUN_0060dcd0(&uStack_20,param_1);
    FUN_00988f90(&uStack_c);
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_8[1] + -1;
      piStack_8[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_1c = 0x9800c1;
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piStack_8 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          uStack_1c = 0x9800d0;
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return uStack_c;
  }
  return 0;
}



/* FUNCTION 17801 ; VA 0x009800f0 ; FUN_009800f0 */

uint FUN_009800f0(byte param_1,uint param_2,int param_3,uint param_4,int param_5,int param_6)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  undefined auStack_44 [16];
  undefined4 uStack_34;
  undefined4 uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0108;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar1 = (param_3 - param_5) - (uint)(param_2 < param_4);
  uVar2 = (int)uVar1 >> 0x1f;
  uVar4 = param_2 - param_4 ^ uVar2;
  iStack_14 = ((uVar1 ^ uVar2) - uVar2) - (uint)(uVar4 < uVar2);
  ExceptionList = &pvStack_10;
  if ((param_1 & 4) != 0) {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0("UserJoin-Suspicious-EqualUuid",0x1d);
    uStack_8 = 0;
    FUN_008783f0(auStack_2c,1,0);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_18) {
      uVar3 = uStack_18 + 1;
      uVar1 = auStack_2c[0];
      if (0xfff < uVar3) {
        uVar1 = *(uint *)(auStack_2c[0] - 4);
        uVar3 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar1,uVar3);
    }
    uVar3 = 1;
  }
  if ((0 < DAT_01ee2fbc) && (DAT_01ee2fbc < param_6)) {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("UserJoin-Suspicious-MultipleJoins",0x21);
    uStack_8 = 1;
    FUN_008783f0(auStack_2c,1,0);
    uStack_8 = 0xffffffff;
    FUN_005507b0();
    uVar3 = uVar3 | 2;
  }
  if (((iStack_14 <= (int)DAT_01ee2fb4 >> 0x1f) &&
      ((iStack_14 < (int)DAT_01ee2fb4 >> 0x1f || (uVar4 - uVar2 <= DAT_01ee2fb4)))) &&
     ((param_2 != param_4 || (param_3 != param_5)))) {
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = 0;
    FUN_005542c0("UserJoin-Suspicious-SimilarUserId",0x21);
    uStack_8 = 2;
    FUN_008783f0(auStack_44,1,0);
    FUN_005507b0();
    uVar3 = uVar3 | 4;
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 17802 ; VA 0x00980280 ; FUN_00980280 */

undefined4 * FUN_00980280(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  
  puVar5 = (undefined4 *)FUN_0097fc00(&param_2,param_2,param_3);
  piVar4 = param_3;
  *param_1 = *puVar5;
  uVar2 = puVar5[1];
  *puVar5 = 0;
  puVar5[1] = 0;
  param_1[1] = uVar2;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 17803 ; VA 0x009802f0 ; FUN_009802f0 */

undefined4 __fastcall FUN_009802f0(int param_1)

{
  return *(undefined4 *)(param_1 + 0xe8);
}



/* FUNCTION 17804 ; VA 0x00980300 ; FUN_00980300 */

undefined4 __thiscall FUN_00980300(int param_1,undefined4 param_2)

{
  if (DAT_01d641ec != '\0') {
    FUN_0097fa50(param_2,param_1 + 0x70,"avatar/characterR15V2.rbxm");
    return param_2;
  }
  FUN_0097fa50(param_2,param_1 + 0x70,"avatar/characterR15.rbxm");
  return param_2;
}



/* FUNCTION 17805 ; VA 0x00980340 ; FUN_00980340 */

undefined __fastcall FUN_00980340(int param_1)

{
  return *(undefined *)(param_1 + 0x298);
}



/* FUNCTION 17806 ; VA 0x00980350 ; FUN_00980350 */

undefined * __thiscall FUN_00980350(int param_1,undefined *param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined auStack_ac [152];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d015d;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  switch(*(undefined4 *)(param_1 + 0x30)) {
  default:
    ExceptionList = &pvStack_10;
    FUN_0054ef60(param_1 + 0x18);
    ExceptionList = pvStack_10;
    return param_2;
  case 1:
    puVar4 = (undefined4 *)(param_1 + 0x18);
    uStack_8 = 1;
    uStack_14 = 4;
    ExceptionList = &pvStack_10;
    *(undefined4 *)(param_2 + 0x10) = 0;
    *(undefined4 *)(param_2 + 0x14) = 0xf;
    *param_2 = 0;
    FUN_0058a190(*(int *)(param_1 + 0x28) + 8);
    FUN_00554150("[[team]]",8);
    if (0xf < *(uint *)(param_1 + 0x2c)) {
      puVar4 = (undefined4 *)*puVar4;
    }
    FUN_00554150(puVar4,*(undefined4 *)(param_1 + 0x28));
    ExceptionList = pvStack_10;
    return param_2;
  case 2:
    break;
  case 3:
    puVar4 = (undefined4 *)(param_1 + 0x18);
    uStack_8 = 0;
    uStack_14 = 2;
    ExceptionList = &pvStack_10;
    *(undefined4 *)(param_2 + 0x10) = 0;
    *(undefined4 *)(param_2 + 0x14) = 0xf;
    *param_2 = 0;
    FUN_0058a190(*(int *)(param_1 + 0x28) + 8);
    FUN_00554150("[[game]]",8);
    if (0xf < *(uint *)(param_1 + 0x2c)) {
      puVar4 = (undefined4 *)*puVar4;
    }
    FUN_00554150(puVar4,*(undefined4 *)(param_1 + 0x28));
    ExceptionList = pvStack_10;
    return param_2;
  }
  ExceptionList = &pvStack_10;
  FUN_00565520(2,1);
  uStack_8 = 2;
  FUN_00558890(auStack_ac,"[[to ");
  if (*(int *)(param_1 + 0x3c) == 0) {
    FUN_00558890(auStack_ac,&DAT_0193611c);
  }
  else {
    piVar2 = *(int **)(*(int *)(param_1 + 0x3c) + 0x28);
    piVar1 = piVar2 + 4;
    if (0xf < (uint)piVar2[5]) {
      piVar2 = (int *)*piVar2;
    }
    FUN_0055b3b0(auStack_ac,piVar2,*piVar1);
  }
  puVar4 = (undefined4 *)(param_1 + 0x18);
  uVar3 = FUN_00558890(auStack_ac,&DAT_01936120);
  if (0xf < *(uint *)(param_1 + 0x2c)) {
    puVar4 = (undefined4 *)*puVar4;
  }
  FUN_0055b3b0(uVar3,puVar4,*(undefined4 *)(param_1 + 0x28));
  FUN_0058c400(param_2);
  FUN_00570540();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17807 ; VA 0x00980550 ; FUN_00980550 */

undefined4 __thiscall
FUN_00980550(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  char *pcVar3;
  undefined auStack_10 [12];
  
  iVar2 = FUN_008f78c0(param_1);
  if (iVar2 == 0) {
    pcVar3 = "Could not find DataModel";
  }
  else {
    if (*(int *)(iVar2 + 0x4a0) == 2) {
      piVar1 = *(int **)(iVar2 + 0x43c);
      FUN_00f55670(param_2,param_3,param_4,*piVar1 - (int)piVar1,piVar1[1] - (int)piVar1);
      return param_2;
    }
    pcVar3 = "No SaveData url set";
  }
  FUN_00550130(pcVar3);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 17808 ; VA 0x009805c0 ; FUN_009805c0 */

undefined4 __fastcall FUN_009805c0(int param_1)

{
  char cVar1;
  int iVar2;
  
  iVar2 = FUN_005eef10(param_1);
  if (iVar2 == 0) {
    iVar2 = FUN_0064e920(param_1);
    if (iVar2 == 0) goto LAB_009805f4;
    cVar1 = *(int *)(iVar2 + 0x124) == 2;
  }
  else {
    cVar1 = FUN_0068ba60();
  }
  if (cVar1 != '\0') {
    return 0;
  }
LAB_009805f4:
  if (*(char *)(param_1 + 0xa1) == '\0') {
    return 0;
  }
  return 1;
}



/* FUNCTION 17809 ; VA 0x00980610 ; FUN_00980610 */

/* WARNING: Removing unreachable block (ram,0x0098066b) */

void __thiscall FUN_00980610(undefined *param_1,undefined4 *param_2)

{
  undefined *puVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  uint uVar7;
  int *piVar8;
  int *piVar9;
  longlong lVar10;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined8 in_stack_00000034;
  uint in_stack_0000003c;
  undefined4 in_stack_fffffefc;
  undefined4 in_stack_ffffff00;
  undefined4 uVar11;
  undefined *puStack_f4;
  int *piStack_f0;
  undefined4 uStack_ec;
  uint *puStack_e8;
  undefined8 uStack_e4;
  undefined auStack_d4 [16];
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 auStack_bc [8];
  undefined4 uStack_9c;
  uint auStack_7c [2];
  uint auStack_74 [6];
  int iStack_5c;
  int iStack_58;
  uint auStack_54 [2];
  uint uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  int iStack_34;
  int *piStack_30;
  int iStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d01cb;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_0054ef60(&param_2);
  piVar9 = &iStack_34;
  uVar11 = 0x980655;
  FUN_0097fce0(piVar9);
  uStack_8._0_1_ = 3;
  if (iStack_34 == 0) {
LAB_0098067a:
    uStack_e4 = (double)CONCAT44(&iStack_5c,&param_2);
    puStack_e8 = (uint *)0x98068d;
    cVar3 = FUN_00f89460();
    if (cVar3 == '\0') {
      uStack_e4 = (double)CONCAT44(param_1,0x980712);
      iVar4 = FUN_0064e700();
      if (iVar4 != 0) {
        uStack_c4 = 0;
        uStack_c0 = 0xf;
        auStack_d4[0] = 0;
        auStack_bc[0] = 0;
        uStack_9c = 0;
        puVar5 = &param_2;
        if (0xf < in_stack_00000018) {
          puVar5 = param_2;
        }
        uStack_e4 = (double)CONCAT44(in_stack_00000014,puVar5);
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
        puStack_e8 = (uint *)0x98076d;
        FUN_005542c0();
        auStack_54[0] = 0;
        if (in_stack_0000001c != 0) {
          auStack_54[0] = in_stack_0000001c;
          if ((in_stack_0000001c & 1) == 0) {
            uStack_e4 = (double)ZEXT48(&uStack_4c);
            puStack_e8 = &stack0x00000024;
            uStack_ec = 0x9807a7;
            (**(code **)(in_stack_0000001c & 0xfffffffe))();
          }
          else {
            uStack_4c = in_stack_00000024;
            uStack_48 = in_stack_00000028;
            uStack_44 = in_stack_0000002c;
            uStack_40 = in_stack_00000030;
            uStack_3c = in_stack_00000034;
          }
        }
        auStack_7c[0] = 0;
        uStack_8._0_1_ = 7;
        uStack_e4 = (double)CONCAT44(auStack_54,0x9807c1);
        FUN_005880d0();
        uStack_e4 = (double)CONCAT44(auStack_bc,0x9807d0);
        FUN_005880d0();
        uStack_e4 = (double)CONCAT44(auStack_7c,0x9807df);
        FUN_005880d0();
        uStack_8._0_1_ = 8;
        if (((auStack_7c[0] != 0) && ((auStack_7c[0] & 1) == 0)) &&
           (*(code **)(auStack_7c[0] & 0xfffffffe) != (code *)0x0)) {
          puStack_e8 = auStack_74;
          uStack_e4 = (double)CONCAT44(2,puStack_e8);
          uStack_ec = 0x980800;
          (**(code **)(auStack_7c[0] & 0xfffffffe))();
        }
        uStack_8._0_1_ = 9;
        if (((auStack_54[0] != 0) && ((auStack_54[0] & 1) == 0)) &&
           (*(code **)(auStack_54[0] & 0xfffffffe) != (code *)0x0)) {
          puStack_e8 = &uStack_4c;
          uStack_e4 = (double)CONCAT44(2,puStack_e8);
          uStack_ec = 0x980824;
          (**(code **)(auStack_54[0] & 0xfffffffe))();
        }
        uStack_8._0_1_ = 5;
        uStack_e4 = (double)CONCAT44(&stack0x0000003c,0x98083a);
        FUN_008c4480();
        piVar8 = *(int **)(param_1 + 0x1d4);
        cStack_11 = '\0';
        if (piVar8 == (int *)0x0) {
          uStack_e4 = 2.54688721655344e-313;
          puVar5 = (undefined4 *)FUN_01674e20();
          if (puVar5 == (undefined4 *)0x0) {
            puVar5 = (undefined4 *)0x0;
          }
          else {
            *puVar5 = 0;
            puVar5[1] = 0;
            puVar5[2] = 0;
          }
          uStack_24 = 0;
          uStack_e4 = (double)CONCAT44(in_stack_00000018,puVar5);
          iStack_20 = 0;
          puStack_e8 = (uint *)0x980880;
          FUN_00962e20();
          puVar1 = puStack_18;
          *(undefined4 *)(puStack_18 + 0x1d4) = uStack_24;
          piStack_1c = *(int **)(puStack_18 + 0x1d8);
          *(int *)(puStack_18 + 0x1d8) = iStack_20;
          if (piStack_1c != (int *)0x0) {
            LOCK();
            iVar4 = piStack_1c[1] + -1;
            piStack_1c[1] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              uStack_e4 = (double)CONCAT44(0x9808af,(undefined4)uStack_e4);
              (**(code **)*piStack_1c)();
              LOCK();
              iVar4 = piStack_1c[2] + -1;
              piStack_1c[2] = iVar4;
              UNLOCK();
              if (iVar4 == 0) {
                uStack_e4 = (double)CONCAT44(0x9808c0,(undefined4)uStack_e4);
                (**(code **)(*piStack_1c + 4))();
              }
            }
          }
          piVar8 = *(int **)(puVar1 + 0x1d4);
          if ((uint)((piVar8[2] - *piVar8) / 0x58) < DAT_01d64614) {
            if (0x2e8ba2e < DAT_01d64614) {
              uStack_e4 = (double)CONCAT44(0x980bb5,(undefined4)uStack_e4);
                    /* WARNING: Subroutine does not return */
              FUN_00577c30();
            }
            uStack_e4 = (double)CONCAT44(DAT_01d64614,0x9808fa);
            FUN_00971020();
            piVar8 = *(int **)(puStack_18 + 0x1d4);
          }
          cStack_11 = '\x01';
        }
        uStack_e4 = (double)CONCAT44(auStack_d4,piVar8[1]);
        if (piVar8[2] == piVar8[1]) {
          puStack_e8 = (uint *)0x98092d;
          FUN_00961f90();
        }
        else {
          uStack_ec = 0x98091d;
          puStack_e8 = (uint *)piVar8;
          FUN_00965bb0();
          piVar8[1] = piVar8[1] + 0x58;
        }
        if (cStack_11 != '\0') {
          uStack_e4._4_4_ = puStack_18;
          uStack_e4._0_4_ = 0x98093f;
          uVar6 = FUN_008f7870();
          puStack_e8 = (uint *)&iStack_2c;
          uStack_e4 = (double)CONCAT44(uStack_e4._4_4_,uVar6);
          uStack_ec = 0x98094b;
          FUN_005e5de0();
          uStack_8 = CONCAT31(uStack_8._1_3_,10);
          uStack_e4 = (double)CONCAT44(0x98095a,(undefined4)uStack_e4);
          piStack_1c = (int *)FUN_005cf2a0();
          piVar8 = piStack_28;
          uStack_e4 = (double)DAT_01d6461c / DAT_018c0d70;
          if (piStack_28 != (int *)0x0) {
            LOCK();
            piStack_28[2] = piStack_28[2] + 1;
            UNLOCK();
            LOCK();
            piStack_28[2] = piStack_28[2] + 1;
            UNLOCK();
          }
          FUN_0095f630(iStack_2c,piStack_28,0);
          if (piVar8 != (int *)0x0) {
            LOCK();
            iVar4 = piVar8[2] + -1;
            piVar8[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar8 + 4))();
            }
          }
          uVar11 = FUN_009eef30(in_stack_fffffefc,in_stack_ffffff00,uVar11,piVar9);
          uStack_8._0_1_ = 5;
          *(undefined4 *)(puStack_18 + 0x1dc) = uVar11;
          if (piVar8 != (int *)0x0) {
            LOCK();
            iVar4 = piVar8[2] + -1;
            piVar8[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              uStack_e4 = (double)CONCAT44(0x9809ef,(undefined4)uStack_e4);
              (**(code **)(*piVar8 + 4))();
            }
          }
        }
        puVar1 = puStack_18;
        if (DAT_01d64614 <=
            (uint)(((*(int **)(puStack_18 + 0x1d4))[1] - **(int **)(puStack_18 + 0x1d4)) / 0x58)) {
          uStack_e4 = (double)CONCAT44(puStack_18,0x980a20);
          piStack_1c = (int *)FUN_008f7870();
          piVar9 = *(int **)(puVar1 + 0x1d8);
          if (piVar9 != (int *)0x0) {
            LOCK();
            piVar9[1] = piVar9[1] + 1;
            UNLOCK();
            piVar9 = *(int **)(puVar1 + 0x1d8);
          }
          iStack_2c = *(int *)(puVar1 + 0x1d4);
          uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
          uStack_e4 = (double)CONCAT44(0x980a50,(undefined4)uStack_e4);
          piStack_28 = piVar9;
          iStack_20 = iStack_2c;
          FUN_0058a2b0();
          if (0 < *(int *)(puStack_18 + 0x1dc)) {
            uStack_e4 = (double)CONCAT44(0x980a67,(undefined4)uStack_e4);
            FUN_005cf2a0();
            uStack_e4 = (double)CONCAT44(*(undefined4 *)(puStack_18 + 0x1dc),0x980a77);
            FUN_009eee80();
          }
          *(undefined4 *)(puStack_18 + 0x1dc) = 0;
          if (piVar9 != (int *)0x0) {
            LOCK();
            piVar9[1] = piVar9[1] + 1;
            UNLOCK();
          }
          uStack_e4 = (double)CONCAT44(piVar9,iStack_20);
          puStack_f4 = (undefined *)&uStack_ec;
          uStack_8._0_1_ = 0xc;
          piStack_f0 = piStack_1c;
          puStack_18 = (undefined *)&uStack_e4;
          FUN_005e5de0();
          uStack_8._0_1_ = 0xb;
          piStack_f0 = (int *)0x980ac7;
          FUN_0098b780();
          uStack_e4 = (double)CONCAT44(0x980ad2,(undefined4)uStack_e4);
          FUN_00550b30();
        }
        uStack_e4 = (double)CONCAT44(0x980add,(undefined4)uStack_e4);
        FUN_0096d6c0();
      }
      goto joined_r0x00980ae2;
    }
    if ((iStack_58 < 1) && ((iStack_58 < 0 || (iStack_5c == 0)))) {
      uStack_e4 = 8.70148866656114e-313;
      uStack_3c = 0xf00000000;
      uStack_4c = uStack_4c & 0xffffff00;
      puStack_e8 = (uint *)0x9806c2;
      FUN_005542c0();
      uStack_8._0_1_ = 4;
      FUN_00558c80(&puStack_f4,&uStack_4c,"Unknown user");
      FUN_005e65e0();
      uStack_e4 = (double)CONCAT44(0x9806ed,(undefined4)uStack_e4);
      FUN_005507b0();
      goto joined_r0x00980ae2;
    }
    uStack_e4 = (double)CONCAT44(iStack_58,iStack_5c);
  }
  else {
    uStack_e4 = (double)CONCAT44(0x980665,(undefined4)uStack_e4);
    lVar10 = FUN_00928340();
    if (lVar10 < 1) goto LAB_0098067a;
    uStack_e4 = (double)CONCAT44(0x980677,(undefined4)uStack_e4);
    uStack_e4 = (double)FUN_00928340();
  }
  puStack_e8 = (uint *)0x9806f9;
  FUN_00949060();
joined_r0x00980ae2:
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_30[1] + -1;
    piStack_30[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      uStack_e4 = (double)CONCAT44(0x980af3,(undefined4)uStack_e4);
      (**(code **)*piStack_30)();
      LOCK();
      piVar9 = piStack_30 + 2;
      iVar4 = *piVar9;
      *piVar9 = *piVar9 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uStack_e4 = (double)CONCAT44(0x980b02,(undefined4)uStack_e4);
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 1;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    uVar7 = in_stack_00000018 + 1;
    puVar5 = param_2;
    if (0xfff < uVar7) {
      puVar5 = (undefined4 *)param_2[-1];
      uVar7 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar5))) {
        uStack_e4 = (double)CONCAT44(&UNK_00980bba,(undefined4)uStack_e4);
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_e4 = (double)CONCAT44(uVar7,puVar5);
    puStack_e8 = (uint *)0x980b37;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = (undefined4 *)((uint)param_2 & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  if (in_stack_0000001c != 0) {
    if (((in_stack_0000001c & 1) == 0) &&
       (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
      puStack_e8 = &stack0x00000024;
      uStack_e4 = (double)CONCAT44(2,puStack_e8);
      uStack_ec = 0x980b6d;
      (**(code **)(in_stack_0000001c & 0xfffffffe))();
    }
    in_stack_0000001c = 0;
  }
  uStack_8 = 0xe;
  if (((in_stack_0000003c != 0) && ((in_stack_0000003c & 1) == 0)) &&
     (*(code **)(in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
    puStack_e8 = (uint *)&stack0x00000044;
    uStack_e4 = (double)CONCAT44(2,puStack_e8);
    uStack_ec = 0x980b9b;
    (**(code **)(in_stack_0000003c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17810 ; VA 0x00980bc0 ; FUN_00980bc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00980bc0(undefined4 param_1,int *param_2,int **param_3,undefined *param_4,uint param_5,
                 undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
                 undefined4 param_10,undefined8 param_11,uint param_12,undefined4 param_13,
                 undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
                 undefined8 param_18)

{
  int *piVar1;
  undefined4 *puVar2;
  int **ppiVar3;
  undefined uVar4;
  char cVar5;
  undefined4 uVar6;
  undefined **ppuVar7;
  int iVar8;
  uint uVar9;
  char *pcVar10;
  int iVar11;
  int *piVar12;
  double dVar13;
  double dVar14;
  double dVar15;
  double dVar16;
  int *piStack_390;
  char *pcStack_38c;
  char *pcStack_388;
  undefined *puStack_384;
  uint *puStack_380;
  undefined4 *puStack_37c;
  undefined4 **ppuStack_378;
  undefined4 **ppuStack_374;
  char *pcStack_370;
  undefined auStack_364 [104];
  undefined auStack_2fc [104];
  undefined auStack_294 [104];
  undefined auStack_22c [112];
  undefined4 uStack_1bc;
  undefined auStack_15c [104];
  undefined auStack_f4 [24];
  undefined auStack_dc [8];
  uint uStack_d4;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined8 uStack_bc;
  uint uStack_b4;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined8 uStack_9c;
  undefined4 uStack_7c;
  int *piStack_78;
  uint uStack_74;
  int *piStack_70;
  undefined auStack_6c [24];
  uint uStack_54;
  undefined4 uStack_50;
  undefined8 uStack_4c;
  undefined8 uStack_44;
  uint auStack_3c [4];
  int iStack_2c;
  uint uStack_28;
  undefined4 *apuStack_24 [2];
  uint uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d02a5;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  iStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  if (param_3 == (int **)0x0) {
    pcStack_370 = (char *)0x12;
    ppuStack_374 = (undefined4 **)0x193687c;
LAB_00980c27:
    ppuStack_378 = (undefined4 **)0x980c2f;
    ExceptionList = &pvStack_10;
    FUN_005542c0();
  }
  else {
    if (param_3 == (int **)0x1) {
      pcStack_370 = (char *)0xe;
      ppuStack_374 = (undefined4 **)0x1936890;
      goto LAB_00980c27;
    }
    ExceptionList = &pvStack_10;
    if (param_3 == (int **)0x2) {
      pcStack_370 = (char *)0x10;
      ppuStack_374 = (undefined4 **)0x19368a0;
      goto LAB_00980c27;
    }
  }
  uStack_8._0_1_ = 2;
  if (iStack_2c == 0) {
    pcStack_38c = "Unknown value for thumbnailType.";
LAB_009812d8:
    pcStack_388 = (char *)0x20;
    ppuStack_374 = (undefined4 **)0x0;
    pcStack_370 = (char *)0xf;
    puStack_384 = (undefined *)((uint)puStack_384 & 0xffffff00);
    piStack_390 = (int *)0x9812ee;
    FUN_005542c0();
    pcStack_388 = (char *)0x9812f6;
    FUN_005e65e0();
  }
  else {
    switch(param_4) {
    case (undefined *)0x0:
      pcVar10 = (char *)0x30;
      break;
    case (undefined *)0x1:
      pcVar10 = (char *)0xb4;
      break;
    case (undefined *)0x2:
      pcVar10 = (char *)0x1a4;
      break;
    case (undefined *)0x3:
      pcVar10 = (char *)0x3c;
      break;
    case (undefined *)0x4:
      pcVar10 = (char *)0x64;
      break;
    case (undefined *)0x5:
      pcVar10 = (char *)0x96;
      break;
    case (undefined *)0x6:
      pcVar10 = (char *)0x160;
      break;
    default:
      pcStack_38c = "Unknown value for thumbnailSize.";
      goto LAB_009812d8;
    }
    ppuStack_374 = (undefined4 **)0x980c98;
    param_3 = (int **)pcVar10;
    ppuStack_374 = (undefined4 **)FUN_008f7870();
    ppuStack_378 = (undefined4 **)&uStack_1c;
    puStack_37c = (undefined4 *)0x980ca2;
    FUN_005c4330();
    piStack_390 = param_2;
    uVar6 = param_1;
    uStack_8._0_1_ = 3;
    if (uStack_1c != 0) {
      puStack_380 = auStack_3c;
      ppuStack_378 = (undefined4 **)param_2;
      puStack_37c = (undefined4 *)param_1;
      puStack_384 = auStack_f4;
      pcStack_388 = (char *)0x980cf8;
      ppuStack_374 = (undefined4 **)pcVar10;
      pcStack_370 = pcVar10;
      FUN_00f8aaf0();
      pcStack_388 = (char *)param_3;
      pcStack_38c = (char *)param_3;
      uStack_8._0_1_ = 4;
      FUN_00f8a5e0(auStack_6c,auStack_3c,uVar6);
      pcStack_370 = (char *)0x0;
      ppuStack_374 = (undefined4 **)0x7;
      ppuStack_378 = (undefined4 **)auStack_f4;
      uStack_8._0_1_ = 5;
      puStack_37c = (undefined4 *)0x980d2d;
      FUN_014cc090();
      uStack_1bc = 6000;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[2] = piStack_18[2] + 1;
        UNLOCK();
      }
      uStack_74 = uStack_1c;
      piStack_70 = piStack_18;
      uStack_8._0_1_ = 7;
      uVar4 = (undefined)uStack_8;
      uStack_8._0_1_ = 7;
      piVar12 = piStack_18;
      if (DAT_01d64690 != '\0') {
        pcStack_370 = (char *)&param_1;
        ppuStack_374 = (undefined4 **)0x980d65;
        FUN_01682800();
        uStack_4c = 0.0;
        iVar11 = iStack_14 + 0x1ed + (uint)*(byte *)(iStack_14 + 0x1ec);
        pcStack_370 = auStack_6c;
        ppuStack_374 = (undefined4 **)0x980d8d;
        ppuStack_378 = (undefined4 **)FUN_005702d0();
        ppuStack_374 = (undefined4 **)auStack_6c;
        pcStack_370 = (char *)(-(uint)(iVar11 != 0) & iVar11 + 1U);
        puStack_37c = &param_3;
        puStack_380 = (uint *)0x980dab;
        FUN_00562fc0();
        pcVar10 = (char *)param_3;
        if (param_3 == (int **)0x0) {
          pcStack_370 = (char *)0x0;
          ppuStack_374 = (undefined4 **)DAT_01d64598;
          uStack_4c = (double)CONCAT44(param_2,param_1);
          ppuStack_378 = (undefined4 **)&uStack_54;
          uStack_54 = uStack_54 & 0xffffff00;
          puStack_37c = (undefined4 *)auStack_6c;
          uStack_44 = CONCAT44(uStack_44._4_4_,1);
          puStack_380 = (uint *)0x981021;
          FUN_0098d1c0();
          piVar12 = piStack_18;
          uVar4 = (undefined)uStack_8;
        }
        else {
          pcStack_370 = auStack_6c;
          ppuStack_374 = &param_3;
          ppuStack_378 = (undefined4 **)0x980dcb;
          FUN_00981f90();
          iVar11 = *(int *)(pcVar10 + 0x20);
          param_3 = (int **)0x2;
          uStack_54 = *(uint *)(iVar11 + 0x28);
          uStack_50 = *(undefined4 *)(iVar11 + 0x2c);
          uStack_4c = *(double *)(iVar11 + 0x30);
          uStack_44 = *(undefined8 *)(iVar11 + 0x38);
          pcStack_370 = (char *)&param_3;
          ppuStack_374 = apuStack_24;
          ppuStack_378 = (undefined4 **)0x980df4;
          FUN_0088db90();
          uStack_8._0_1_ = 8;
          puVar2 = (undefined4 *)*apuStack_24[0];
          pcStack_370 = (char *)0x980e05;
          uVar6 = FUN_0088cb40();
          *puVar2 = uVar6;
          pcStack_370 = auStack_6c;
          ppuStack_374 = (undefined4 **)0x980e13;
          FUN_005c17a0();
          if (((char)uStack_54 != '\0') &&
             (((double)CONCAT44(param_2,param_1) - uStack_4c) * DAT_018c0d70 < (double)DAT_01d64580)
             ) {
            pcStack_370 = (char *)((int)&param_3 + 3);
            param_3 = (int **)CONCAT13(1,param_3._0_3_);
            ppuStack_374 = (undefined4 **)0x980e59;
            FUN_005e52b0();
            ppuStack_378 = apuStack_24;
            puStack_37c = (undefined4 *)0x980e67;
            FUN_00557fc0();
            ppuStack_378 = (undefined4 **)0x980e6f;
            FUN_00948fa0();
LAB_00980f35:
            pcStack_370 = (char *)0x980f3d;
            FUN_00550b30();
            pcStack_370 = (char *)0x980f45;
            FUN_0056c200();
            pcStack_370 = (char *)0x980f50;
            FUN_0056db40();
            pcStack_370 = (char *)0x980f58;
            FUN_005507b0();
            pcStack_370 = (char *)0x980f63;
            FUN_005507b0();
            goto LAB_00980f63;
          }
          iVar11 = (int)uStack_44;
          if ((int)uStack_44 == 0) {
LAB_00980fb5:
            uStack_44 = CONCAT44(uStack_44._4_4_,1);
          }
          else {
            dVar13 = (double)_DAT_01d64590 / DAT_018c0d70;
            pcStack_370 = (char *)0x980e9a;
            FUN_01726ab0();
            iVar8 = DAT_01d64580;
            if (DAT_01d64588 < DAT_01d64580) {
              iVar8 = DAT_01d64588;
            }
            dVar13 = dVar13 * (double)_DAT_01d64578;
            dVar15 = (double)iVar8;
            dVar16 = ((double)CONCAT44(param_2,param_1) - uStack_4c) * DAT_018c0d70;
            dVar14 = dVar15;
            if (dVar13 < dVar15) {
              dVar14 = dVar13;
            }
            if (dVar16 < dVar14) {
              pcStack_370 = (char *)((int)&param_3 + 3);
              param_3 = (int **)((uint)param_3 & 0xffffff);
              ppuStack_374 = (undefined4 **)0x980f08;
              FUN_005e52b0();
              ppuStack_378 = apuStack_24;
              puStack_37c = (undefined4 *)0x980f16;
              FUN_00557fc0();
              ppuStack_378 = (undefined4 **)0x980f1e;
              FUN_00948fa0();
              pcStack_370 = (char *)0x0;
              ppuStack_374 = (undefined4 **)DAT_01d64598;
              ppuStack_378 = (undefined4 **)&uStack_54;
              puStack_37c = (undefined4 *)auStack_6c;
              puStack_380 = (uint *)0x980f35;
              FUN_0098d1c0();
              goto LAB_00980f35;
            }
            if (dVar15 + dVar15 < dVar16) goto LAB_00980fb5;
            if (dVar13 < dVar15) {
              uStack_44 = CONCAT44(uStack_44._4_4_,iVar11 + 1);
            }
          }
          pcStack_370 = (char *)0x0;
          ppuStack_374 = (undefined4 **)DAT_01d64598;
          uStack_4c = (double)CONCAT44(param_2,param_1);
          ppuStack_378 = (undefined4 **)&uStack_54;
          puStack_37c = (undefined4 *)auStack_6c;
          puStack_380 = (uint *)0x980fdf;
          FUN_0098d1c0();
          uStack_8._0_1_ = 7;
          pcStack_370 = (char *)0x980feb;
          FUN_00550b30();
          piVar12 = piStack_18;
          uVar4 = (undefined)uStack_8;
        }
      }
      uStack_8._0_1_ = uVar4;
      pcStack_370 = (char *)iStack_14;
      ppuStack_374 = (undefined4 **)&param_1;
      ppuStack_378 = (undefined4 **)0x981033;
      FUN_0060e0c0();
      pcStack_370 = (char *)0x0;
      param_3 = &piStack_390;
      param_4 = auStack_dc;
      if (piVar12 != (int *)0x0) {
        LOCK();
        piVar12[2] = piVar12[2] + 1;
        UNLOCK();
      }
      uStack_8._0_1_ = 10;
      uStack_d4 = 0;
      ppiVar3 = &piStack_390;
      if (param_5 != 0) {
        uStack_d4 = param_5;
        if ((param_5 & 1) == 0) {
          (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_cc,0);
          ppiVar3 = param_3;
        }
        else {
          uStack_cc = param_7;
          uStack_c8 = param_8;
          uStack_c4 = param_9;
          uStack_c0 = param_10;
          uStack_bc = param_11;
          ppiVar3 = &piStack_390;
        }
      }
      param_3 = ppiVar3;
      uStack_8._0_1_ = 0xb;
      uStack_b4 = 0;
      if (param_12 != 0) {
        uStack_b4 = param_12;
        if ((param_12 & 1) == 0) {
          (**(code **)(param_12 & 0xfffffffe))(&param_14,&uStack_ac,0);
        }
        else {
          uStack_ac = param_14;
          uStack_a8 = param_15;
          uStack_a4 = param_16;
          uStack_a0 = param_17;
          uStack_9c = param_18;
        }
      }
      uStack_8._0_1_ = 0xc;
      FUN_0054ef60(auStack_6c);
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[2] = param_2[2] + 1;
        UNLOCK();
      }
      uStack_7c = param_1;
      piStack_78 = param_2;
      uStack_8._0_1_ = 0xd;
      FUN_009673f0(auStack_dc);
      puVar2 = param_3;
      uStack_8._0_1_ = 0xe;
      *param_3 = (int *)0x0;
      FUN_009673f0(auStack_364);
      uStack_8._0_1_ = 0xf;
      FUN_009673f0(auStack_2fc);
      uStack_8._0_1_ = 0x10;
      FUN_009673f0(auStack_294);
      uStack_8._0_1_ = 0x11;
      cVar5 = FUN_00585a40(auStack_15c);
      if (cVar5 == '\0') {
        FUN_009673f0(auStack_15c);
        uStack_8._0_1_ = 0x12;
        param_3 = (int **)FUN_01674e20(0x68);
        uStack_8._0_1_ = 0x13;
        if (param_3 == (int **)0x0) {
          uVar6 = 0;
        }
        else {
          uVar6 = FUN_009673f0(auStack_22c);
        }
        puVar2[2] = uVar6;
        FUN_0096bec0();
        FUN_0096bec0();
        param_3 = (int **)CONCAT13(1,param_3._0_3_);
      }
      else {
        FUN_0096bec0();
        param_3 = (int **)((uint)param_3 & 0xffffff);
      }
      FUN_0096bec0();
      ppuVar7 = &PTR_FUN_01936cd0;
      if (param_3._3_1_ == '\0') {
        ppuVar7 = (undefined **)0x0;
      }
      *puVar2 = ppuVar7;
      FUN_0096bec0();
      FUN_0096bec0();
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      FUN_0096bec0();
      FUN_014ccc70();
      if (param_2 != (int *)0x0) {
        LOCK();
        iVar11 = param_2[2] + -1;
        param_2[2] = iVar11;
        UNLOCK();
        if (iVar11 == 0) {
          pcStack_370 = (char *)0x981289;
          (**(code **)(*param_2 + 4))();
        }
      }
      if (piVar12 != (int *)0x0) {
        LOCK();
        piVar1 = piVar12 + 2;
        iVar11 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar11 == 1) {
          pcStack_370 = (char *)0x98129c;
          (**(code **)(*piVar12 + 4))();
        }
      }
      pcStack_370 = (char *)0x9812a7;
      FUN_0056db40();
      pcStack_370 = (char *)0x9812af;
      FUN_005507b0();
      pcStack_370 = (char *)0x9812ba;
      FUN_005507b0();
      pcStack_370 = (char *)0x9812c2;
      FUN_00550b30();
      pcStack_370 = (char *)0x9812ca;
      FUN_005507b0();
      goto LAB_00981340;
    }
    pcStack_388 = (char *)0x35;
    ppuStack_374 = (undefined4 **)0x0;
    pcStack_370 = (char *)0xf;
    pcStack_38c = "Players:GetUserThumbnailAsync() cannot find DataModel";
    puStack_384 = (undefined *)((uint)puStack_384 & 0xffffff00);
    piStack_390 = (int *)0x980cd1;
    FUN_005542c0();
    pcStack_388 = (char *)0x980cd9;
    FUN_005e65e0();
LAB_00980f63:
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar11 = piStack_18[1] + -1;
      piStack_18[1] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        pcStack_370 = (char *)0x980f84;
        (**(code **)*piStack_18)();
        LOCK();
        piVar12 = piStack_18 + 2;
        iVar11 = *piVar12;
        *piVar12 = *piVar12 + -1;
        UNLOCK();
        if (iVar11 == 1) {
          pcStack_370 = (char *)0x980f97;
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_28) {
    pcStack_370 = (char *)(uStack_28 + 1);
    uVar9 = auStack_3c[0];
    if (0xfff < pcStack_370) {
      uVar9 = *(uint *)(auStack_3c[0] - 4);
      pcStack_370 = (char *)(uStack_28 + 0x24);
      if (0x1f < (auStack_3c[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        pcStack_370 = "\x0f\x1f";
        FUN_017167a3();
      }
    }
    ppuStack_378 = (undefined4 **)0x98132b;
    ppuStack_374 = (undefined4 **)uVar9;
    FUN_01674ea0();
  }
  iStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
LAB_00981340:
  uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
  if (param_5 != 0) {
    if (((param_5 & 1) == 0) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0)) {
      ppuStack_378 = (undefined4 **)&param_7;
      pcStack_370 = (char *)0x2;
      puStack_37c = (undefined4 *)0x981361;
      ppuStack_374 = ppuStack_378;
      (**(code **)(param_5 & 0xfffffffe))();
    }
    param_5 = 0;
  }
  uStack_8 = 0x15;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    ppuStack_378 = (undefined4 **)&param_14;
    pcStack_370 = (char *)0x2;
    puStack_37c = (undefined4 *)0x98138f;
    ppuStack_374 = ppuStack_378;
    (**(code **)(param_12 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17811 ; VA 0x009813d0 ; FUN_009813d0 */

void FUN_009813d0(int param_1,int *param_2,int *param_3,int *param_4,uint param_5)

{
  undefined4 *puVar1;
  int iVar2;
  char cVar3;
  char *pcVar4;
  int iVar5;
  int *piVar6;
  char *pcVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  undefined4 in_stack_00000024;
  uint in_stack_00000028;
  uint in_stack_0000002c;
  uint in_stack_0000004c;
  int *in_stack_00000070;
  undefined uVar11;
  undefined4 in_stack_ffffff94;
  undefined4 in_stack_ffffff98;
  undefined4 in_stack_ffffff9c;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  int iStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  ulonglong uStack_40;
  undefined auStack_38 [12];
  undefined auStack_2c [8];
  int *piStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d02f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 5;
  uStack_7 = 0;
  if (param_3 == (int *)0x0) {
    if (param_1 == 0) {
      uVar12 = 0xf;
      uVar11 = 0;
      ExceptionList = &pvStack_10;
      FUN_005542c0("Players:GetUserThumbnailAsync() web request returned no response",0x40);
      FUN_005e65e0(uVar11,in_stack_ffffff94,in_stack_ffffff98,in_stack_ffffff9c,param_1,uVar12);
    }
    else {
      uVar12 = 0x98147a;
      ExceptionList = &pvStack_10;
      FUN_016819e0(auStack_38,param_1);
      uStack_8 = 6;
      cVar3 = FUN_016816d0();
      if (cVar3 == '\0') {
        FUN_0167eea0(auStack_2c,"Final");
        cStack_11 = FUN_0167e3d0(0);
        iStack_18 = 2;
        FUN_0088db90(&piStack_24,&iStack_18);
        piVar6 = piStack_24;
        uStack_8 = 7;
        puVar1 = (undefined4 *)*piStack_24;
        uVar12 = FUN_0088cb40();
        *puVar1 = uVar12;
        FUN_005c17a0(&param_5);
        iVar10 = *piVar6;
        uVar12 = FUN_0088daf0();
        *(undefined4 *)(iVar10 + 0xd0) = uVar12;
        iVar5 = FUN_005c9ef0();
        iVar2 = *(int *)(iVar10 + 0xd4);
        if (iVar2 == iVar5) {
          *(char *)(iVar10 + 0xd8) = cStack_11;
        }
        else {
          if (iVar2 != 0) {
            (**(code **)(iVar2 + 8))(iVar10 + 0xd8);
          }
          *(char *)(iVar10 + 0xd8) = cStack_11;
          *(int *)(iVar10 + 0xd4) = iVar5;
        }
        if (DAT_01d64690 != '\0') {
          piVar6 = (int *)FUN_00587490(auStack_2c);
          iVar10 = *piVar6;
          FUN_00550b30();
          if (iVar10 != 0) {
            iStack_18 = iVar10 + 0x1e0;
            uStack_48 = 0;
            iVar10 = (uint)*(byte *)(iVar10 + 0x1ec) + iVar10 + 0x1ed;
            uVar12 = FUN_005702d0(&param_5);
            FUN_00562fc0(&iStack_1c,uVar12,&param_5,-(uint)(iVar10 != 0) & iVar10 + 1U);
            if (iStack_1c != 0) {
              FUN_00981f90(&iStack_1c,&param_5);
              iVar10 = *(int *)(iStack_1c + 0x20);
              iStack_50 = *(int *)(iVar10 + 0x28);
              uStack_4c = *(undefined4 *)(iVar10 + 0x2c);
              uStack_48 = *(undefined8 *)(iVar10 + 0x30);
              uStack_40 = *(ulonglong *)(iVar10 + 0x38);
            }
            if ((cStack_11 == '\0') || (DAT_01d64698 != '\0')) {
              iStack_50 = (uint)iStack_50._1_3_ << 8;
            }
            else {
              iStack_50 = CONCAT31(iStack_50._1_3_,1);
              uStack_40 = uStack_40 & 0xffffffff00000000;
            }
            FUN_0098d1c0(&param_5,&iStack_50,DAT_01d64598,0);
          }
        }
        if (iStack_20 != 0) {
          LOCK();
          *(int *)(iStack_20 + 4) = *(int *)(iStack_20 + 4) + 1;
          UNLOCK();
        }
        FUN_00948fa0(piStack_24,iStack_20);
        FUN_00550b30();
      }
      else {
        uVar13 = 0;
        uVar14 = 0xf;
        uVar11 = 0;
        FUN_005542c0("Response JSON Invalid",0x15);
        FUN_005e65e0(uVar11,in_stack_ffffff94,in_stack_ffffff98,uVar12,uVar13,uVar14);
      }
      FUN_0167ec40();
    }
  }
  else {
    ExceptionList = &pvStack_10;
    pcVar4 = (char *)(**(code **)(*param_3 + 4))();
    uVar12 = 0;
    uVar13 = 0xf;
    uVar11 = 0;
    pcVar7 = pcVar4;
    do {
      cVar3 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar3 != '\0');
    FUN_005542c0(pcVar4,(int)pcVar7 - (int)(pcVar4 + 1));
    FUN_005e65e0(uVar11,in_stack_ffffff94,in_stack_ffffff98,in_stack_ffffff9c,uVar12,uVar13);
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar10 = param_2[1] + -1;
    param_2[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar10 = param_2[2] + -1;
      param_2[2] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar10 = param_4[1] + -1;
    param_4[1] = iVar10;
    UNLOCK();
    if (iVar10 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar10 = param_4[2] + -1;
      param_4[2] = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  uStack_8 = 2;
  uVar11 = uStack_8;
  uStack_8 = 2;
  if (0xf < in_stack_00000028) {
    uVar9 = in_stack_00000028 + 1;
    uVar8 = param_5;
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(param_5 - 4);
      uVar9 = in_stack_00000028 + 0x24;
      if (0x1f < (param_5 - uVar8) - 4) {
        uStack_8 = uVar11;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  in_stack_00000024 = 0;
  in_stack_00000028 = 0xf;
  param_5 = param_5 & 0xffffff00;
  uStack_8 = 8;
  if (in_stack_0000002c != 0) {
    if (((in_stack_0000002c & 1) == 0) &&
       (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
    }
    in_stack_0000002c = 0;
  }
  _uStack_8 = CONCAT31(uStack_7,9);
  if (in_stack_0000004c != 0) {
    if (((in_stack_0000004c & 1) == 0) &&
       (*(code **)(in_stack_0000004c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000004c & 0xfffffffe))(&stack0x00000054,&stack0x00000054,2);
    }
    in_stack_0000004c = 0;
  }
  if (in_stack_00000070 != (int *)0x0) {
    LOCK();
    piVar6 = in_stack_00000070 + 2;
    iVar10 = *piVar6;
    *piVar6 = *piVar6 + -1;
    UNLOCK();
    if (iVar10 == 1) {
      (**(code **)(*in_stack_00000070 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17812 ; VA 0x00981770 ; FUN_00981770 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __thiscall FUN_00981770(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined *puVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bba58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  piVar5 = (int *)FUN_0060dcd0(auStack_20,uVar4);
  iVar6 = *piVar5;
  piVar1 = (int *)piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  uStack_8 = 0;
  iStack_18 = iVar6;
  piStack_14 = piVar1;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar3 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  uVar4 = FUN_0088cd20();
  iVar3 = _tls_index;
  *param_3 = uVar4;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar3 * 4) + 0x34) < DAT_01eded64) {
    FUN_016f3809(&DAT_01eded64);
    if (DAT_01eded64 == -1) {
      _DAT_01eded58 = FUN_0057bbb0;
      _DAT_01eded5c = FUN_005880a0;
      _DAT_01eded60 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01eded64);
    }
  }
  puVar2 = (undefined *)param_3[1];
  if (puVar2 == &DAT_01eded58) {
    iVar6 = FUN_0056ecd0(&iStack_18);
  }
  else {
    if (puVar2 != (undefined *)0x0) {
      (**(code **)(puVar2 + 8))(param_3 + 2);
      param_3[1] = 0;
    }
    param_3[2] = 0;
    param_3[3] = 0;
    if (piVar1 != (int *)0x0) {
      LOCK();
      piVar1[1] = piVar1[1] + 1;
      UNLOCK();
    }
    param_3[2] = iVar6;
    param_3[3] = piVar1;
    param_3[1] = &DAT_01eded58;
  }
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar5 = piVar1 + 1;
    iVar3 = *piVar5;
    iVar6 = *piVar5;
    *piVar5 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar6 = (**(code **)*piVar1)();
      LOCK();
      piVar5 = piVar1 + 2;
      iVar3 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar6 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 17813 ; VA 0x009818f0 ; FUN_009818f0 */

/* WARNING: Removing unreachable block (ram,0x00981980) */
/* WARNING: Removing unreachable block (ram,0x00981993) */
/* WARNING: Removing unreachable block (ram,0x0098199a) */
/* WARNING: Removing unreachable block (ram,0x009819a1) */

undefined4 FUN_009818f0(undefined4 param_1)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (DAT_01d5a4c0 == '\0') {
    ExceptionList = &pvStack_10;
    if (DAT_01d65105 != '\0') {
      ExceptionList = &pvStack_10;
      FUN_01677760(DAT_01d65105,"Checking hash: %s",param_1);
    }
    FUN_00587410();
    piVar1 = (int *)FUN_0065ad50(&param_1,param_1);
    ExceptionList = pvStack_10;
    return CONCAT31((int3)((uint)*piVar1 >> 8),*piVar1 != DAT_01ee3090);
  }
  return CONCAT31((int3)((uint)ExceptionList >> 8),1);
}



/* FUNCTION 17814 ; VA 0x009819c0 ; FUN_009819c0 */

void __thiscall FUN_009819c0(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,int param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  int aiStack_8c [5];
  uint uStack_78;
  int iStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined8 uStack_64;
  uint uStack_5c;
  int iStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint uStack_48;
  undefined4 uStack_44;
  uint uStack_40;
  int iStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d031b;
  pvStack_10 = ExceptionList;
  iVar7 = (int)param_1 + 0xd + (uint)*(byte *)((int)param_1 + 0xc);
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar4 = FUN_005702d0(param_2);
  FUN_00562fc0(&iStack_14,uVar4,param_2,-(uint)(iVar7 != 0) & iVar7 + 1U);
  if (iStack_14 != 0) {
    piVar1 = *(int **)(iStack_14 + 0x20);
    piVar2 = (int *)**(int **)((int)param_1 + 4);
    if (((piVar1 != *(int **)((int)param_1 + 4)) && (iVar7 = *piVar1, piVar2 != piVar1)) &&
       (piVar2 != (int *)iVar7)) {
      *(int *)piVar1[1] = iVar7;
      **(int **)(iVar7 + 4) = (int)piVar2;
      *(int **)piVar2[1] = piVar1;
      iVar3 = piVar2[1];
      piVar2[1] = *(undefined4 *)(iVar7 + 4);
      *(int *)(iVar7 + 4) = piVar1[1];
      piVar1[1] = iVar3;
      param_1 = puStack_18;
    }
    FUN_0098a020(&iStack_14);
  }
  iStack_3c = param_4;
  uStack_34 = *param_3;
  uStack_30 = param_3[1];
  uStack_2c = param_3[2];
  uStack_28 = param_3[3];
  uStack_24 = uStack_34;
  uStack_20 = uStack_30;
  uStack_1c = uStack_2c;
  puStack_18 = (undefined4 *)uStack_28;
  FUN_0054ef60(param_2);
  iStack_74 = iStack_3c;
  uStack_70 = uStack_38;
  uStack_6c = uStack_34;
  uStack_68 = uStack_30;
  uStack_64 = CONCAT44(puStack_18,uStack_1c);
  uStack_8 = 0;
  iVar7 = **(int **)((int)param_1 + 4);
  puStack_18 = *(undefined4 **)(iVar7 + 4);
  uVar4 = FUN_00961940(iVar7,puStack_18,aiStack_8c);
  if (*(int *)((int)param_1 + 8) != 0x4924923) {
    uStack_8 = 0xffffffff;
    *(int *)((int)param_1 + 8) = *(int *)((int)param_1 + 8) + 1;
    *(undefined4 *)(iVar7 + 4) = uVar4;
    *puStack_18 = uVar4;
    if (0xf < uStack_78) {
      uVar5 = uStack_78 + 1;
      iVar7 = aiStack_8c[0];
      if (0xfff < uVar5) {
        iVar7 = *(int *)(aiStack_8c[0] + -4);
        uVar5 = uStack_78 + 0x24;
        if (0x1f < (aiStack_8c[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar7,uVar5);
    }
    uVar4 = **(undefined4 **)((int)param_1 + 4);
    FUN_0054ef60(param_2);
    uStack_5c = uStack_40;
    uStack_40 = uStack_40 & 0xffffff00;
    iStack_58 = iStack_3c;
    uStack_54 = uStack_38;
    uStack_50 = uStack_34;
    uStack_4c = uStack_30;
    uStack_48 = uStack_2c;
    uStack_30 = 0;
    uStack_2c = 0xf;
    uStack_8 = 2;
    uStack_44 = uVar4;
    uStack_28 = uVar4;
    FUN_00966120(&uStack_1c,&uStack_5c,&uStack_5c);
    if (0xf < uStack_48) {
      uVar6 = uStack_48 + 1;
      uVar5 = uStack_5c;
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(uStack_5c - 4);
        uVar6 = uStack_48 + 0x24;
        if (0x1f < (uStack_5c - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    *(int *)((int)param_1 + 0x24) = *(int *)((int)param_1 + 0x24) + param_4;
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 17815 ; VA 0x00981bd0 ; FUN_00981bd0 */

void __thiscall FUN_00981bd0(int param_1,undefined4 param_2,undefined4 *param_3,int param_4)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int aiStack_90 [5];
  uint uStack_7c;
  int iStack_78;
  uint uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  uint uStack_60;
  undefined4 uStack_5c;
  uint uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  uint uStack_44;
  undefined4 uStack_40;
  int iStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined auStack_18 [4];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d034b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  FUN_00981f90(&puStack_14,param_2);
  if (puStack_14 != (undefined4 *)0x0) {
    FUN_0098a190(&puStack_14);
  }
  iStack_3c = param_4;
  uStack_34 = *param_3;
  uStack_30 = param_3[1];
  uStack_2c = param_3[2];
  uStack_28 = param_3[3];
  uStack_24 = (uint)*(undefined8 *)(param_3 + 4);
  uStack_20 = (undefined4)((ulonglong)*(undefined8 *)(param_3 + 4) >> 0x20);
  FUN_0054ef60(param_2);
  iStack_78 = iStack_3c;
  uStack_74 = uStack_38;
  uStack_70 = uStack_34;
  uStack_6c = uStack_30;
  uStack_68 = uStack_2c;
  uStack_64 = uStack_28;
  uStack_60 = uStack_24;
  uStack_5c = uStack_20;
  uStack_8 = 0;
  iVar2 = **(int **)(param_1 + 4);
  puStack_14 = *(undefined4 **)(iVar2 + 4);
  uVar1 = FUN_009619a0(iVar2,puStack_14,aiStack_90);
  if (*(int *)(param_1 + 8) != 0x3fffffe) {
    uStack_8 = 0xffffffff;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *(undefined4 *)(iVar2 + 4) = uVar1;
    *puStack_14 = uVar1;
    if (0xf < uStack_7c) {
      uVar3 = uStack_7c + 1;
      iVar2 = aiStack_90[0];
      if (0xfff < uVar3) {
        iVar2 = *(int *)(aiStack_90[0] + -4);
        uVar3 = uStack_7c + 0x24;
        if (0x1f < (aiStack_90[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
    uVar1 = **(undefined4 **)(param_1 + 4);
    FUN_0054ef60(param_2);
    uStack_58 = uStack_38;
    uStack_38 = uStack_38 & 0xffffff00;
    uStack_54 = uStack_34;
    uStack_50 = uStack_30;
    uStack_4c = uStack_2c;
    uStack_48 = uStack_28;
    uStack_44 = uStack_24;
    uStack_28 = 0;
    uStack_24 = 0xf;
    uStack_8 = 2;
    uStack_40 = uVar1;
    uStack_20 = uVar1;
    FUN_009662c0(auStack_18,&uStack_58,&uStack_58);
    if (0xf < uStack_44) {
      uVar4 = uStack_44 + 1;
      uVar3 = uStack_58;
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(uStack_58 - 4);
        uVar4 = uStack_44 + 0x24;
        if (0x1f < (uStack_58 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
    *(int *)(iStack_1c + 0x24) = *(int *)(iStack_1c + 0x24) + param_4;
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 17816 ; VA 0x00981d90 ; FUN_00981d90 */

void __thiscall FUN_00981d90(int param_1,uint *param_2,int param_3,int param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  uint uStack_84;
  uint uStack_80;
  int iStack_7c;
  uint uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  uint uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  int iStack_54;
  uint uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined auStack_2c [4];
  undefined4 *puStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0370;
  pvStack_10 = ExceptionList;
  puStack_28 = (undefined4 *)(param_1 + 0xc);
  iVar8 = param_1 + 0xd + (uint)*(byte *)(param_1 + 0xc);
  uVar6 = param_2[1];
  uStack_1c = *param_2;
  if (((int)uVar6 < 1) && ((int)uVar6 < 0)) {
    uStack_1c = ~uStack_1c;
    uVar6 = ~uVar6;
  }
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_00606ff0(&iStack_18,(uVar6 >> 2) + uVar6 * 0x40 + *param_2 ^ uVar6,param_2,
               -(uint)(iVar8 != 0) & iVar8 + 1U);
  iVar8 = iStack_14;
  if (iStack_18 != 0) {
    piVar1 = *(int **)(iStack_18 + 0x10);
    piVar2 = (int *)**(int **)(iStack_14 + 4);
    if (((piVar1 != *(int **)(iStack_14 + 4)) && (iVar3 = *piVar1, piVar2 != piVar1)) &&
       (piVar2 != (int *)iVar3)) {
      *(int *)piVar1[1] = iVar3;
      **(int **)(iVar3 + 4) = (int)piVar2;
      *(int **)piVar2[1] = piVar1;
      iVar4 = piVar2[1];
      piVar2[1] = *(undefined4 *)(iVar3 + 4);
      *(int *)(iVar3 + 4) = piVar1[1];
      piVar1[1] = iVar4;
    }
    FUN_0098a2a0(&iStack_18);
  }
  iStack_54 = param_4;
  FUN_0054ef60(param_3);
  uStack_74 = uStack_4c;
  uStack_34 = *(undefined4 *)(param_3 + 0x18);
  uStack_30 = *(undefined4 *)(param_3 + 0x1c);
  uStack_4c = uStack_4c & 0xffffff00;
  uStack_84 = *param_2;
  uStack_80 = param_2[1];
  iStack_7c = iStack_54;
  uStack_5c = *(undefined4 *)(param_3 + 0x18);
  uStack_70 = uStack_48;
  uStack_6c = uStack_44;
  uStack_68 = uStack_40;
  uStack_60 = uStack_38;
  uStack_58 = *(undefined4 *)(param_3 + 0x1c);
  uStack_3c = 0;
  uStack_38 = 0xf;
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  iVar3 = **(int **)(iVar8 + 4);
  puStack_28 = *(undefined4 **)(iVar3 + 4);
  uVar5 = FUN_00961a00(iVar3,puStack_28,&uStack_84);
  if (*(int *)(iVar8 + 8) != 0x4924923) {
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    *(int *)(iVar8 + 8) = *(int *)(iVar8 + 8) + 1;
    *(undefined4 *)(iVar3 + 4) = uVar5;
    *puStack_28 = uVar5;
    if (0xf < uStack_60) {
      uVar7 = uStack_60 + 1;
      uVar6 = uStack_74;
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(uStack_74 - 4);
        uVar7 = uStack_60 + 0x24;
        if (0x1f < (uStack_74 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    iStack_8 = 0xffffffff;
    uStack_24 = *param_2;
    uStack_20 = param_2[1];
    uStack_1c = **(undefined4 **)(iVar8 + 4);
    FUN_00966460(auStack_2c,&uStack_24,&uStack_24);
    *(int *)(iVar8 + 0x24) = *(int *)(iVar8 + 0x24) + param_4;
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 17817 ; VA 0x00981f90 ; FUN_00981f90 */

int * __thiscall FUN_00981f90(int param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  
  iVar5 = param_1 + 0xd + (uint)*(byte *)(param_1 + 0xc);
  uVar4 = FUN_005702d0(param_3);
  FUN_00562fc0(param_2,uVar4,param_3,-(uint)(iVar5 != 0) & iVar5 + 1U);
  if (*param_2 != 0) {
    piVar1 = *(int **)(*param_2 + 0x20);
    piVar2 = (int *)**(int **)(param_1 + 4);
    if (((piVar1 != *(int **)(param_1 + 4)) && (iVar5 = *piVar1, piVar2 != piVar1)) &&
       (piVar2 != (int *)iVar5)) {
      *(int *)piVar1[1] = iVar5;
      **(int **)(iVar5 + 4) = (int)piVar2;
      *(int **)piVar2[1] = piVar1;
      iVar3 = piVar2[1];
      piVar2[1] = *(undefined4 *)(iVar5 + 4);
      *(int *)(iVar5 + 4) = piVar1[1];
      piVar1[1] = iVar3;
    }
  }
  return param_2;
}



/* FUNCTION 17818 ; VA 0x00982020 ; FUN_00982020 */

void FUN_00982020(int *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  
  puVar2 = (undefined4 *)*param_1;
  pcVar3 = (code *)*puVar2;
  FUN_0054ef60(puVar2 + 3);
  if (puVar2[2] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar3)(puVar2[1],puVar2[2]);
  return;
}



/* FUNCTION 17819 ; VA 0x00982070 ; FUN_00982070 */

void FUN_00982070(void)

{
  FUN_0096ddb0();
  return;
}



/* FUNCTION 17820 ; VA 0x00982080 ; FUN_00982080 */

void FUN_00982080(void)

{
  FUN_0096e090();
  return;
}



/* FUNCTION 17821 ; VA 0x00982090 ; FUN_00982090 */

int FUN_00982090(void)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a828;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = 0;
  if ((iStack_18 != 0) && (*(int *)(iStack_18 + 0x440) == 0)) {
    iVar3 = FUN_00933b20(1);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 17822 ; VA 0x00982110 ; FUN_00982110 */

void FUN_00982110(int *param_1)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = *param_1;
  if (*(int *)(iVar2 + 0x24) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar2 + 0x24) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_0096e490(*(undefined4 *)(iVar2 + 0x20),*(undefined4 *)(iVar2 + 0x24));
  return;
}



/* FUNCTION 17823 ; VA 0x00982150 ; FUN_00982150 */

void FUN_00982150(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  code *pcVar3;
  undefined4 uVar4;
  
  uVar2 = param_1[5];
  pcVar3 = (code *)*param_1;
  uVar4 = param_1[4];
  if (param_1[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar3)(param_1[2],param_1[3],uVar4,uVar2);
  return;
}



/* FUNCTION 17824 ; VA 0x00982190 ; FUN_00982190 */

/* WARNING: Removing unreachable block (ram,0x00982282) */
/* WARNING: Removing unreachable block (ram,0x00982290) */
/* WARNING: Removing unreachable block (ram,0x009822be) */
/* WARNING: Removing unreachable block (ram,0x009822a0) */

void FUN_00982190(undefined4 *param_1,int param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,uint param_7)

{
  int *piVar1;
  int iStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d0398;
  pvStack_10 = ExceptionList;
  iStack_2c = param_2;
  uStack_28 = param_3;
  uStack_24 = param_4;
  uStack_20 = param_5;
  uStack_1c = param_6;
  uStack_18 = param_7;
  ExceptionList = &pvStack_10;
  if (param_1[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[3] + 4);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uStack_7 = 0;
  FUN_0054ef60(&iStack_2c);
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  _uStack_8 = CONCAT31(uStack_7,1);
  FUN_00987740(*param_1,param_1[1]);
  if (0xf < uStack_18) {
    if ((0xfff < uStack_18 + 1) && (0x1f < (iStack_2c - *(int *)(iStack_2c + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17825 ; VA 0x009822d0 ; FUN_009822d0 */

/* WARNING: Removing unreachable block (ram,0x00982337) */
/* WARNING: Removing unreachable block (ram,0x00982345) */
/* WARNING: Removing unreachable block (ram,0x0098236d) */
/* WARNING: Removing unreachable block (ram,0x00982355) */

void FUN_009822d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0096da70(param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17826 ; VA 0x00982380 ; FUN_00982380 */

/* WARNING: Removing unreachable block (ram,0x00982472) */
/* WARNING: Removing unreachable block (ram,0x00982480) */
/* WARNING: Removing unreachable block (ram,0x009824ae) */
/* WARNING: Removing unreachable block (ram,0x00982490) */

void FUN_00982380(undefined4 *param_1,int param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,uint param_7)

{
  int *piVar1;
  int iStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d0398;
  pvStack_10 = ExceptionList;
  iStack_2c = param_2;
  uStack_28 = param_3;
  uStack_24 = param_4;
  uStack_20 = param_5;
  uStack_1c = param_6;
  uStack_18 = param_7;
  ExceptionList = &pvStack_10;
  if (param_1[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[3] + 4);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uStack_7 = 0;
  FUN_0054ef60(&iStack_2c);
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  _uStack_8 = CONCAT31(uStack_7,1);
  FUN_009878e0(*param_1,param_1[1]);
  if (0xf < uStack_18) {
    if ((0xfff < uStack_18 + 1) && (0x1f < (iStack_2c - *(int *)(iStack_2c + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17827 ; VA 0x009824c0 ; FUN_009824c0 */

/* WARNING: Removing unreachable block (ram,0x009825b2) */
/* WARNING: Removing unreachable block (ram,0x009825c0) */
/* WARNING: Removing unreachable block (ram,0x009825ee) */
/* WARNING: Removing unreachable block (ram,0x009825d0) */

void FUN_009824c0(undefined4 *param_1,int param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,uint param_7)

{
  int *piVar1;
  int iStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d03c8;
  pvStack_10 = ExceptionList;
  iStack_2c = param_2;
  uStack_28 = param_3;
  uStack_24 = param_4;
  uStack_20 = param_5;
  uStack_1c = param_6;
  uStack_18 = param_7;
  ExceptionList = &pvStack_10;
  if (param_1[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[3] + 4);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uStack_7 = 0;
  FUN_0054ef60(&iStack_2c);
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  _uStack_8 = CONCAT31(uStack_7,1);
  FUN_00988200(*param_1,param_1[1]);
  if (0xf < uStack_18) {
    if ((0xfff < uStack_18 + 1) && (0x1f < (iStack_2c - *(int *)(iStack_2c + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17828 ; VA 0x00982600 ; FUN_00982600 */

void FUN_00982600(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d03f0;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  if (((-(uint)(param_2 != 0) & param_2 + 0xcU) != 0) &&
     (ExceptionList = &pvStack_10, iVar5 = FUN_006715f0(), uVar4 = DAT_01d64564, iVar5 != 0)) {
    uVar3 = *(uint *)(iVar2 + 0x20);
    if ((uVar3 != 0) && ((uVar3 & 1) == 0)) {
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    if (*(int *)(iVar2 + 0x1c) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(iVar2 + 0x1c) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_8 = 1;
    FUN_0054ef60(iVar2);
    uStack_8 = 0xffffffff;
    FUN_00a85f10(uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17829 ; VA 0x00982700 ; FUN_00982700 */

/* WARNING: Removing unreachable block (ram,0x009827f2) */
/* WARNING: Removing unreachable block (ram,0x00982800) */
/* WARNING: Removing unreachable block (ram,0x0098282e) */
/* WARNING: Removing unreachable block (ram,0x00982810) */

void FUN_00982700(undefined4 *param_1,int param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,uint param_7)

{
  int *piVar1;
  int iStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d03c8;
  pvStack_10 = ExceptionList;
  iStack_2c = param_2;
  uStack_28 = param_3;
  uStack_24 = param_4;
  uStack_20 = param_5;
  uStack_1c = param_6;
  uStack_18 = param_7;
  ExceptionList = &pvStack_10;
  if (param_1[3] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[3] + 4);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uStack_7 = 0;
  FUN_0054ef60(&iStack_2c);
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  _uStack_8 = CONCAT31(uStack_7,1);
  FUN_00988060(*param_1,param_1[1]);
  if (0xf < uStack_18) {
    if ((0xfff < uStack_18 + 1) && (0x1f < (iStack_2c - *(int *)(iStack_2c + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17830 ; VA 0x00982840 ; FUN_00982840 */

/* WARNING: Removing unreachable block (ram,0x009828a7) */
/* WARNING: Removing unreachable block (ram,0x009828b5) */
/* WARNING: Removing unreachable block (ram,0x009828dd) */
/* WARNING: Removing unreachable block (ram,0x009828c5) */

void FUN_00982840(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0096df40(param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17831 ; VA 0x009828f0 ; FUN_009828f0 */

/* WARNING: Removing unreachable block (ram,0x00982957) */
/* WARNING: Removing unreachable block (ram,0x00982965) */
/* WARNING: Removing unreachable block (ram,0x0098298d) */
/* WARNING: Removing unreachable block (ram,0x00982975) */

void FUN_009828f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0096e220(param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17832 ; VA 0x009829a0 ; FUN_009829a0 */

void FUN_009829a0(int *param_1)

{
  uint *puVar1;
  undefined4 uVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d0410;
  pvStack_10 = ExceptionList;
  puVar1 = (uint *)*param_1;
  uVar3 = puVar1[9];
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(uVar3 + 4) = *(int *)(uVar3 + 4) + 1;
    UNLOCK();
    uVar3 = puVar1[9];
  }
  uStack_8 = 0;
  if (*puVar1 != 0) {
    (**(code **)((*puVar1 & 0xfffffffe) + 4))(puVar1 + 2,puVar1[8],uVar3);
    ExceptionList = pvStack_10;
    return;
  }
  uVar2 = FUN_0054fda0();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar2);
}



/* FUNCTION 17833 ; VA 0x00982a30 ; FUN_00982a30 */

void FUN_00982a30(int *param_1,int param_2)

{
  undefined4 *puVar1;
  code *pcVar2;
  int iVar3;
  uint uVar4;
  uint in_stack_0000001c;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 *puStack_50;
  ulonglong uStack_4c;
  uint uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017d0438;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  puVar1 = (undefined4 *)*param_1;
  pcVar2 = (code *)*puVar1;
  uStack_44 = 0;
  uVar4 = puVar1[0xc];
  ExceptionList = &pvStack_10;
  if (uVar4 != 0) {
    uStack_44 = uVar4;
    if ((uVar4 & 1) == 0) {
      uStack_4c = ZEXT48(&uStack_3c);
      puStack_50 = puVar1 + 0xe;
      uStack_54 = 0x982aa5;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar4 & 0xfffffffe))();
    }
    else {
      uStack_3c = puVar1[0xe];
      uStack_38 = puVar1[0xf];
      uStack_34 = puVar1[0x10];
      uStack_30 = puVar1[0x11];
      uStack_2c = *(undefined8 *)(puVar1 + 0x12);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8._0_1_ = 1;
  uVar4 = puVar1[4];
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      (**(code **)(uVar4 & 0xfffffffe))(puVar1 + 6,&uStack_5c,0);
    }
    else {
      uStack_5c = puVar1[6];
      uStack_58 = puVar1[7];
      uStack_54 = puVar1[8];
      puStack_50 = (undefined4 *)puVar1[9];
      uStack_4c = *(ulonglong *)(puVar1 + 10);
    }
  }
  iStack_8._0_1_ = 2;
  FUN_0054ef60(&param_2);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  (*pcVar2)();
  if (0xf < in_stack_0000001c) {
    uVar4 = in_stack_0000001c + 1;
    iVar3 = param_2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(param_2 + -4);
      uVar4 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar3) - 4U) {
        uStack_2c = CONCAT44(&UNK_00982b56,(undefined4)uStack_2c);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_2c = CONCAT44(uVar4,iVar3);
    uStack_30 = 0x982b3e;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17834 ; VA 0x00982b60 ; FUN_00982b60 */

int FUN_00982b60(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  code *pcVar4;
  uint uVar5;
  uint3 uVar6;
  int iVar7;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_24;
  int *piStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017d0460;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_1;
  pcVar4 = (code *)*puVar3;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_24 = param_2;
  piStack_20 = param_3;
  iStack_8._1_3_ = 0;
  uVar6 = iStack_8._1_3_;
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  uVar5 = puVar3[2];
  if (uVar5 != 0) {
    if ((uVar5 & 1) == 0) {
      (**(code **)(uVar5 & 0xfffffffe))(puVar3 + 4,&uStack_3c,0);
      uVar6 = iStack_8._1_3_;
    }
    else {
      uStack_3c = puVar3[4];
      uStack_38 = puVar3[5];
      uStack_34 = puVar3[6];
      uStack_30 = puVar3[7];
      uStack_2c = *(undefined8 *)(puVar3 + 8);
      uVar6 = iStack_8._1_3_;
    }
  }
  iStack_8._1_3_ = uVar6;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  iVar7 = (*pcVar4)();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_20 = (int *)0x982c1e;
      iVar7 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_20 = (int *)0x982c2d;
        iVar7 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 17835 ; VA 0x00982c40 ; FUN_00982c40 */

int FUN_00982c40(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  code *pcVar4;
  uint uVar5;
  uint3 uVar6;
  int iVar7;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_24;
  int *piStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017d0480;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_1;
  pcVar4 = (code *)*puVar3;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_24 = param_2;
  piStack_20 = param_3;
  iStack_8._1_3_ = 0;
  uVar6 = iStack_8._1_3_;
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  uVar5 = puVar3[2];
  if (uVar5 != 0) {
    if ((uVar5 & 1) == 0) {
      (**(code **)(uVar5 & 0xfffffffe))(puVar3 + 4,&uStack_3c,0);
      uVar6 = iStack_8._1_3_;
    }
    else {
      uStack_3c = puVar3[4];
      uStack_38 = puVar3[5];
      uStack_34 = puVar3[6];
      uStack_30 = puVar3[7];
      uStack_2c = *(undefined8 *)(puVar3 + 8);
      uVar6 = iStack_8._1_3_;
    }
  }
  iStack_8._1_3_ = uVar6;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  iVar7 = (*pcVar4)();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_20 = (int *)0x982cfe;
      iVar7 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_20 = (int *)0x982d0d;
        iVar7 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 17836 ; VA 0x00982d20 ; FUN_00982d20 */

int FUN_00982d20(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  code *pcVar4;
  uint uVar5;
  uint3 uVar6;
  int iVar7;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_24;
  int *piStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017d04a0;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_1;
  pcVar4 = (code *)*puVar3;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_24 = param_2;
  piStack_20 = param_3;
  iStack_8._1_3_ = 0;
  uVar6 = iStack_8._1_3_;
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  uVar5 = puVar3[2];
  if (uVar5 != 0) {
    if ((uVar5 & 1) == 0) {
      (**(code **)(uVar5 & 0xfffffffe))(puVar3 + 4,&uStack_3c,0);
      uVar6 = iStack_8._1_3_;
    }
    else {
      uStack_3c = puVar3[4];
      uStack_38 = puVar3[5];
      uStack_34 = puVar3[6];
      uStack_30 = puVar3[7];
      uStack_2c = *(undefined8 *)(puVar3 + 8);
      uVar6 = iStack_8._1_3_;
    }
  }
  iStack_8._1_3_ = uVar6;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  iVar7 = (*pcVar4)();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_20 = (int *)0x982dde;
      iVar7 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_20 = (int *)0x982ded;
        iVar7 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 17837 ; VA 0x00982e00 ; FUN_00982e00 */

void FUN_00982e00(int *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  code *pcVar2;
  uint uVar3;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  uStack_c = param_3;
  uStack_10 = param_2;
  puVar1 = (undefined4 *)*param_1;
  pcVar2 = (code *)*puVar1;
  uVar3 = puVar1[2];
  if (uVar3 != 0) {
    if ((uVar3 & 1) != 0) {
      uStack_28 = puVar1[4];
      uStack_24 = puVar1[5];
      uStack_20 = puVar1[6];
      uStack_1c = puVar1[7];
      uStack_18 = *(undefined8 *)(puVar1 + 8);
      (*pcVar2)();
      return;
    }
    (**(code **)(uVar3 & 0xfffffffe))(puVar1 + 4,&uStack_28,0);
  }
  (*pcVar2)();
  return;
}



/* FUNCTION 17838 ; VA 0x00982e70 ; FUN_00982e70 */

void FUN_00982e70(undefined4 *param_1)

{
  FUN_00960f00(param_1,*param_1,&param_1,0);
  return;
}



/* FUNCTION 17839 ; VA 0x00982e90 ; FUN_00982e90 */

void FUN_00982e90(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar1 = *param_1;
  param_1 = &param_2;
  ExceptionList = &pvStack_10;
  FUN_009611c0(param_1,uVar1,&param_1,0);
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17840 ; VA 0x00982f10 ; FUN_00982f10 */

void FUN_00982f10(undefined4 *param_1,undefined4 param_2)

{
  (*(code *)*param_1)(param_2,param_1 + 3,*(undefined *)(param_1 + 4));
  return;
}



/* FUNCTION 17841 ; VA 0x00982f30 ; FUN_00982f30 */

void FUN_00982f30(int *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_0000001c;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  int iStack_50;
  ulonglong uStack_4c;
  uint uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017d0438;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  iVar2 = *param_1;
  uVar1 = *(undefined4 *)(iVar2 + 8);
  uStack_44 = 0;
  uVar3 = *(uint *)(iVar2 + 0x30);
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    uStack_44 = uVar3;
    if ((uVar3 & 1) == 0) {
      uStack_4c = ZEXT48(&uStack_3c);
      iStack_50 = iVar2 + 0x38;
      uStack_54 = 0x982fa6;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_3c = *(undefined4 *)(iVar2 + 0x38);
      uStack_38 = *(undefined4 *)(iVar2 + 0x3c);
      uStack_34 = *(undefined4 *)(iVar2 + 0x40);
      uStack_30 = *(undefined4 *)(iVar2 + 0x44);
      uStack_2c = *(undefined8 *)(iVar2 + 0x48);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8._0_1_ = 1;
  uVar3 = *(uint *)(iVar2 + 0x10);
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(iVar2 + 0x18,&uStack_5c,0);
    }
    else {
      uStack_5c = *(undefined4 *)(iVar2 + 0x18);
      uStack_58 = *(undefined4 *)(iVar2 + 0x1c);
      uStack_54 = *(undefined4 *)(iVar2 + 0x20);
      iStack_50 = *(int *)(iVar2 + 0x24);
      uStack_4c = *(ulonglong *)(iVar2 + 0x28);
    }
  }
  iStack_8._0_1_ = 2;
  FUN_0054ef60(&param_2);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_0096e580(uVar1);
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
        uStack_2c = CONCAT44(&UNK_0098305a,(undefined4)uStack_2c);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_2c = CONCAT44(uVar3,iVar2);
    uStack_30 = 0x983042;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17842 ; VA 0x00983060 ; FUN_00983060 */

void FUN_00983060(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  uVar1 = *param_1;
  param_1 = (undefined4 *)param_2;
  FUN_00961450(param_2,uVar1,&param_1,0);
  return;
}



/* FUNCTION 17843 ; VA 0x00983090 ; FUN_00983090 */

void FUN_00983090(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_0096d8c0(param_2,param_3);
  return;
}



/* FUNCTION 17844 ; VA 0x009830b0 ; FUN_009830b0 */

int FUN_009830b0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5
                )

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c47e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puStack_18 = (undefined *)&param_2;
  puStack_14 = (undefined *)&param_4;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00961050(param_1,*param_1,&puStack_18,0);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_5)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 17845 ; VA 0x00983160 ; FUN_00983160 */

int FUN_00983160(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                undefined4 param_5,int *param_6)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bfa90;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puStack_1c = (undefined *)&param_2;
  puStack_18 = (undefined *)&param_3;
  puStack_14 = (undefined *)&param_5;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_009612d0(param_1,*param_1,&puStack_1c,0);
  piVar3 = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = param_6;
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_6)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 17846 ; VA 0x00983210 ; FUN_00983210 */

undefined FUN_00983210(undefined4 param_1)

{
  undefined uVar1;
  int iVar2;
  
  iVar2 = FUN_005eef10(param_1);
  if (iVar2 != 0) {
    uVar1 = FUN_0068ba60();
    return uVar1;
  }
  iVar2 = FUN_0064e920(param_1);
  if (iVar2 != 0) {
    return *(int *)(iVar2 + 0x124) == 2;
  }
  return false;
}



/* FUNCTION 17847 ; VA 0x00983250 ; FUN_00983250 */

undefined FUN_00983250(undefined4 param_1)

{
  undefined uVar1;
  int iVar2;
  
  iVar2 = FUN_005eef10(param_1);
  if (iVar2 != 0) {
    uVar1 = FUN_0068ba70();
    return uVar1;
  }
  iVar2 = FUN_0064e920(param_1);
  if (iVar2 != 0) {
    return *(int *)(iVar2 + 0x124) == 1;
  }
  return false;
}



/* FUNCTION 17848 ; VA 0x00983290 ; FUN_00983290 */

bool FUN_00983290(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_005edc10();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) goto LAB_009832c2;
  }
  param_1 = 0;
LAB_009832c2:
  return param_1 != 0;
}



/* FUNCTION 17849 ; VA 0x009832d0 ; FUN_009832d0 */

undefined __thiscall FUN_009832d0(int param_1,int param_2,int *param_3)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  undefined uVar4;
  int *piVar5;
  int *piVar6;
  
  uVar1 = *(undefined4 *)(param_1 + 0x30);
  piVar6 = *(int **)(param_1 + 0x40);
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar6[1] = piVar6[1] + 1;
    UNLOCK();
    piVar6 = *(int **)(param_1 + 0x40);
  }
  iVar2 = *(int *)(param_1 + 0x3c);
  piVar5 = *(int **)(param_1 + 0x38);
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = *(int **)(param_1 + 0x38);
  }
  iVar3 = *(int *)(param_1 + 0x34);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  switch(uVar1) {
  case 0:
  case 3:
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar2 = param_3[1] + -1;
      param_3[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_3)();
        LOCK();
        iVar2 = param_3[2] + -1;
        param_3[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar2 = piVar5[1] + -1;
      piVar5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar2 = piVar5[2] + -1;
        piVar5[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar2 = piVar6[1] + -1;
      piVar6[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        iVar2 = piVar6[2] + -1;
        piVar6[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    uVar4 = 1;
    goto LAB_00983486;
  case 1:
    if ((((param_2 == 0) || (iVar3 == 0)) || (*(char *)(iVar3 + 0xa8) != '\0')) ||
       ((*(char *)(param_2 + 0xa8) != '\0' || (*(int *)(iVar3 + 0x94) != *(int *)(param_2 + 0x94))))
       ) {
LAB_009833df:
      uVar4 = 0;
    }
    else {
      uVar4 = 1;
    }
    break;
  case 2:
    if ((param_2 == 0) || ((iVar3 != param_2 && (iVar2 != param_2)))) goto LAB_009833df;
    uVar4 = 1;
    break;
  default:
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar2 = param_3[1] + -1;
      param_3[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_3)();
        LOCK();
        iVar2 = param_3[2] + -1;
        param_3[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar2 = piVar5[1] + -1;
      piVar5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar2 = piVar5[2] + -1;
        piVar5[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar2 = piVar6[1] + -1;
      piVar6[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        iVar2 = piVar6[2] + -1;
        piVar6[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    uVar4 = 0;
    goto LAB_00983486;
  }
  FUN_00550b30();
  FUN_00550b30();
  FUN_00550b30();
LAB_00983486:
  if (param_3 == (int *)0x0) {
    return uVar4;
  }
  LOCK();
  iVar2 = param_3[1] + -1;
  param_3[1] = iVar2;
  UNLOCK();
  if (iVar2 == 0) {
    (**(code **)*param_3)();
    LOCK();
    piVar6 = param_3 + 2;
    iVar2 = *piVar6;
    *piVar6 = *piVar6 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return uVar4;
}



/* FUNCTION 17850 ; VA 0x009834e0 ; FUN_009834e0 */

int * FUN_009834e0(undefined4 param_1,undefined4 param_2)

{
  uint *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  uint *puVar6;
  int iVar7;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a828;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar2 = (int *)FUN_0097fc00(auStack_18,param_1,param_2);
  iVar7 = *piVar2;
  uStack_8 = 0;
  if (iVar7 != 0) {
    iVar4 = *(int *)(iVar7 + 0xc);
    iVar3 = FUN_00913630();
    piVar2 = (int *)(uint)*(ushort *)(iVar3 + 0x1da);
    if ((int *)((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) <= piVar2)
    goto LAB_0098353f;
  }
  iVar7 = 0;
LAB_0098353f:
  uStack_8 = 0xffffffff;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_14 + 1;
    iVar4 = *piVar5;
    piVar2 = (int *)*piVar5;
    *piVar5 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      piVar2 = (int *)(**(code **)*piStack_14)();
      LOCK();
      piVar5 = piStack_14 + 2;
      iVar4 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        piVar2 = (int *)(**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (((iVar7 != 0) && (*(int *)(iVar7 + 100) != 0)) &&
     (piVar5 = *(int **)(*(int *)(iVar7 + 100) + 0x2c), piVar5 != (int *)0x0)) {
    puVar1 = (uint *)piVar5[1];
    puVar6 = (uint *)*piVar5;
    if (puVar6 != puVar1) {
      do {
        piVar2 = (int *)*puVar6;
        piVar5 = piVar2;
        if (piVar2 != (int *)0x0) {
          iVar7 = piVar2[3];
          iVar4 = FUN_0099be20();
          piVar5 = (int *)(uint)*(ushort *)(iVar4 + 0x1da);
          if ((int *)((uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) <= piVar5
             ) {
            if (piVar2 == (int *)0x0) {
              ExceptionList = pvStack_10;
              return piVar5;
            }
            piVar2 = (int *)FUN_009c36b0(0);
            ExceptionList = pvStack_10;
            return piVar2;
          }
        }
        puVar6 = puVar6 + 2;
      } while (puVar6 != puVar1);
      ExceptionList = pvStack_10;
      return piVar5;
    }
  }
  ExceptionList = pvStack_10;
  return piVar2;
}



/* FUNCTION 17851 ; VA 0x00983600 ; FUN_00983600 */

uint __thiscall FUN_00983600(undefined4 param_1,uint param_2,int *param_3)

{
  int *piVar1;
  uint *puVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  code *pcStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = param_2;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  if (param_2 != 0) {
    iVar5 = *(int *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar4 = FUN_00b63e30();
    param_2 = (uint)*(ushort *)(iVar4 + 0x1da);
    if ((uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <= param_2) {
      iVar5 = FUN_009ba880(uStack_18);
      if (iVar5 == 0) {
        FUN_008a4100();
        uStack_20 = uStack_14;
        pcStack_28 = FUN_00972a70;
        uStack_24 = 0;
        FUN_00965af0(&uStack_18,&pcStack_28);
      }
      else {
        uStack_20 = uStack_14;
        pcStack_28 = FUN_00983720;
        uStack_24 = 0;
        FUN_00915d30(&uStack_18,&pcStack_28);
      }
      param_2 = uStack_18;
      if (uStack_18 != 0) {
        piVar1 = (int *)(uStack_18 + 4);
        LOCK();
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          param_2 = FUN_01674ea0(uStack_18);
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar2 = (uint *)(param_3 + 1);
    uVar3 = *puVar2;
    param_2 = *puVar2;
    *puVar2 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17852 ; VA 0x00983720 ; FUN_00983720 */

void __fastcall FUN_00983720(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined *puVar6;
  uint uVar7;
  undefined *puStack_170;
  undefined4 uStack_16c;
  undefined *puStack_168;
  undefined *puStack_164;
  undefined *puStack_160;
  undefined *puStack_15c;
  undefined *puStack_158;
  undefined **ppuStack_154;
  undefined *puStack_150;
  undefined **ppuStack_14c;
  undefined *puStack_148;
  undefined **ppuStack_144;
  undefined auStack_134 [24];
  undefined auStack_11c [24];
  undefined auStack_104 [24];
  undefined auStack_ec [24];
  undefined auStack_d4 [24];
  undefined auStack_bc [24];
  undefined auStack_a4 [24];
  undefined auStack_8c [24];
  undefined auStack_74 [24];
  undefined auStack_5c [24];
  undefined auStack_44 [16];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined *puStack_28;
  undefined8 uStack_24;
  float fStack_1c;
  undefined *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0530;
  pvStack_10 = ExceptionList;
  if ((*(int *)(param_1 + 0xf4) != 0) &&
     (ppuStack_144 = *(undefined ***)(*(int *)(param_1 + 0xf4) + 100),
     ppuStack_144 != (undefined **)0x0)) {
    puStack_148 = (undefined *)0x983760;
    ExceptionList = &pvStack_10;
    iVar1 = FUN_009ba880();
    if (iVar1 != 0) {
      ppuStack_144 = (undefined **)0x983772;
      iVar1 = FUN_009b7280();
      if (iVar1 != 0) {
        ppuStack_144 = (undefined **)0x983783;
        iVar2 = FUN_00b077e0();
        uStack_24 = *(undefined8 *)(iVar2 + 0x24);
        fStack_1c = *(float *)(iVar2 + 0x2c);
        ppuStack_144 = (undefined **)&uStack_11;
        puStack_148 = &uStack_11;
        ppuStack_14c = (undefined **)&uStack_11;
        puStack_150 = (undefined *)0xb;
        ppuStack_154 = (undefined **)0x9837a9;
        FUN_005d0b40();
        puStack_18 = (undefined *)(int)fStack_1c;
        iStack_8 = 0;
        ppuStack_144 = &puStack_18;
        puStack_148 = auStack_134;
        ppuStack_14c = (undefined **)0x9837c8;
        uVar3 = FUN_006368c0();
        puStack_18 = (undefined *)(int)uStack_24._4_4_;
        ppuStack_14c = &puStack_18;
        iStack_8._0_1_ = 1;
        puStack_150 = auStack_11c;
        ppuStack_154 = (undefined **)0x9837e6;
        uVar4 = FUN_006368c0();
        puStack_18 = (undefined *)(int)(float)uStack_24;
        ppuStack_154 = &puStack_18;
        iStack_8._0_1_ = 2;
        puStack_158 = auStack_104;
        puStack_15c = (undefined *)0x983804;
        puStack_15c = (undefined *)FUN_006368c0();
        puStack_164 = auStack_ec;
        iStack_8._0_1_ = 3;
        puStack_160 = &DAT_019360f0;
        puStack_168 = (undefined *)0x98381a;
        uStack_16c = FUN_00558d90();
        puStack_168 = &DAT_018bf378;
        puStack_170 = auStack_d4;
        iStack_8._0_1_ = 4;
        uVar5 = FUN_00558c80();
        iStack_8._0_1_ = 5;
        uVar4 = FUN_00558ba0(auStack_bc,uVar5,uVar4);
        puVar6 = auStack_a4;
        iStack_8._0_1_ = 6;
        puStack_148 = (undefined *)FUN_00558c80(puVar6,uVar4,&DAT_018bf378);
        ppuStack_14c = (undefined **)auStack_8c;
        iStack_8._0_1_ = 7;
        puStack_150 = (undefined *)0x98386d;
        ppuStack_144 = (undefined **)uVar3;
        ppuStack_154 = (undefined **)FUN_00558ba0();
        puStack_150 = &DAT_018d2114;
        puStack_158 = auStack_74;
        iStack_8._0_1_ = 8;
        puStack_15c = (undefined *)0x983880;
        uVar3 = FUN_00558c80();
        ppuStack_144 = (undefined **)0x3;
        puStack_148 = &DAT_019360ec;
        iStack_8._0_1_ = 9;
        uStack_34 = 0;
        uStack_30 = 0xf;
        auStack_44[0] = 0;
        ppuStack_14c = (undefined **)0x9838aa;
        FUN_005542c0();
        puStack_148 = auStack_44;
        iStack_8._0_1_ = 10;
        ppuStack_14c = (undefined **)0x9838bb;
        ppuStack_144 = (undefined **)uVar3;
        FUN_005d15d0();
        puStack_148 = (undefined *)0x9838c3;
        FUN_005511f0();
        ppuStack_144 = (undefined **)0x9838cb;
        FUN_005507b0();
        ppuStack_144 = (undefined **)0x9838d3;
        FUN_005507b0();
        ppuStack_144 = (undefined **)0x9838de;
        FUN_005507b0();
        ppuStack_144 = (undefined **)0x9838e9;
        FUN_005507b0();
        ppuStack_144 = (undefined **)0x9838f4;
        FUN_005507b0();
        ppuStack_144 = (undefined **)0x9838ff;
        FUN_005507b0();
        ppuStack_144 = (undefined **)0x98390a;
        FUN_005507b0();
        ppuStack_144 = (undefined **)0x983915;
        FUN_005507b0();
        ppuStack_144 = (undefined **)0x983920;
        FUN_005507b0();
        iStack_8._0_1_ = 0;
        ppuStack_144 = (undefined **)0x98392f;
        FUN_005507b0();
        puStack_18 = (undefined *)&puStack_158;
        puStack_15c = auStack_5c;
        puStack_160 = (undefined *)0x983940;
        FUN_0060e7f0();
        puStack_28 = (undefined *)&puStack_170;
        iStack_8._0_1_ = 0xb;
        puStack_160 = (undefined *)0x0;
        puStack_15c = (undefined *)0xf;
        puStack_170 = (undefined *)((uint)puStack_170 & 0xffffff00);
        FUN_005542c0(&DAT_018db520,4);
        iStack_8._0_1_ = 0xc;
        uVar7 = (uint)puVar6 & 0xffffff00;
        FUN_005542c0("killed",6);
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_0087a3e0(iVar1,uVar7);
        ppuStack_144 = (undefined **)0x9839a4;
        FUN_0056cfd0();
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17853 ; VA 0x009839c0 ; FUN_009839c0 */

void FUN_009839c0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_0098cfc0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 17854 ; VA 0x00983a00 ; FUN_00983a00 */

void FUN_00983a00(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_0098d050();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 17855 ; VA 0x00983a40 ; FUN_00983a40 */

int * FUN_00983a40(undefined4 param_1,int *param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  longlong lVar7;
  undefined uVar8;
  undefined auStack_5c [12];
  undefined4 uStack_50;
  uint uStack_4c;
  int **ppiStack_48;
  int **ppiStack_44;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d0568;
  pvStack_10 = ExceptionList;
  ppiStack_44 = &piStack_24;
  uStack_8 = 0;
  ppiStack_48 = (int **)0x983a71;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  piVar4 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    piStack_14 = (int *)0x0;
    while (piVar4 = (int *)piStack_24[0xb], piVar4 != (int *)0x0) {
      iVar6 = *piVar4;
      piVar4 = (int *)(piVar4[1] - iVar6 >> 3);
      if (piVar4 <= piStack_14) break;
      iVar6 = *(int *)(iVar6 + (int)piStack_14 * 8);
      if (iVar6 == 0) {
LAB_00983acf:
        iVar6 = 0;
      }
      else {
        iVar2 = *(int *)(iVar6 + 0xc);
        ppiStack_44 = (int **)0x983ab4;
        iVar5 = FUN_005ee170();
        if ((uint)*(ushort *)(iVar5 + 0x1da) <
            (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) goto LAB_00983acf;
      }
      ppiStack_48 = &piStack_34;
      uStack_4c = 0x983adb;
      ppiStack_44 = (int **)iVar6;
      FUN_0060dcd0();
      uStack_8._0_1_ = 2;
      if (piStack_34 != (int *)0x0) {
        ppiStack_44 = (int **)0x983af7;
        ppiStack_44 = (int **)(**(code **)(*piStack_34 + 0xb4))();
        ppiStack_48 = &piStack_2c;
        uStack_4c = 0x983b01;
        FUN_0060dcd0();
        piVar4 = piStack_2c;
        uStack_8._0_1_ = 3;
        if (piStack_2c != (int *)0x0) {
          ppiStack_44 = (int **)0x983b1a;
          lVar7 = FUN_00928340();
          if (lVar7 == CONCAT44(param_4,param_3)) {
            if (DAT_01ee420a != 0) {
              ppiStack_44 = (int **)0x0;
              uStack_4c = (uint)DAT_01ee420a;
              ppiStack_48 = (int **)0x19364b4;
              uStack_50 = 0x983b45;
              FUN_016774b0();
            }
            ppiStack_44 = (int **)piVar4;
            if (DAT_01d646e0 == '\0') {
              ppiStack_48 = (int **)0x983b80;
              iVar6 = FUN_005c8880();
              if (iVar6 != 0) {
                ppiStack_44 = (int **)0x1;
                ppiStack_48 = (int **)piVar4;
                uStack_4c = 0x983b8f;
                cVar3 = FUN_0064a9e0();
                goto joined_r0x00983b94;
              }
            }
            else {
              ppiStack_48 = (int **)0x983b57;
              iVar6 = FUN_008f78c0();
              if (iVar6 != 0) {
                ppiStack_48 = (int **)(iVar6 + 0xc);
                ppiStack_44 = (int **)0x1;
                uStack_4c = 0x983b6d;
                cVar3 = FUN_0064a9e0();
joined_r0x00983b94:
                if (cVar3 == '\0') {
                  ppiStack_44 = (int **)0x10b;
                  puStack_18 = auStack_5c;
                  uStack_4c = 0;
                  ppiStack_48 = (int **)0xf;
                  auStack_5c[0] = 0;
                  FUN_005542c0("Player service requests player disconnect",0x29);
                  uStack_8._0_1_ = 4;
                  uVar8 = 0;
                  FUN_005542c0("server",6);
                  uStack_8._0_1_ = 3;
                  FUN_0062db20(uVar8);
                }
              }
            }
            ppiStack_44 = (int **)0x10b;
            ppiStack_48 = (int **)0x983bff;
            FUN_0062b370();
          }
        }
        piVar4 = piStack_28;
        if (piStack_28 != (int *)0x0) {
          LOCK();
          iVar6 = piStack_28[1] + -1;
          piStack_28[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            ppiStack_44 = (int **)0x983c15;
            (**(code **)*piStack_28)();
            LOCK();
            piVar1 = piVar4 + 2;
            iVar6 = *piVar1 + -1;
            *piVar1 = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              ppiStack_44 = (int **)0x983c25;
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
      }
      piVar4 = piStack_30;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (piStack_30 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_30[1] + -1;
        piStack_30[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          ppiStack_44 = (int **)0x983c3f;
          (**(code **)*piStack_30)();
          LOCK();
          piVar1 = piVar4 + 2;
          iVar6 = *piVar1 + -1;
          *piVar1 = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            ppiStack_44 = (int **)0x983c4f;
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      piStack_14 = (int *)((int)piStack_14 + 1);
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_20 + 1;
    iVar6 = *piVar1;
    piVar4 = (int *)*piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      ppiStack_44 = (int **)0x983c71;
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar6 = *piVar1;
      piVar4 = (int *)*piVar1;
      *piVar1 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        ppiStack_44 = (int **)0x983c81;
        piVar4 = (int *)(**(code **)(*piStack_20 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar6 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar6 == 1) {
      ppiStack_44 = (int **)0x983c95;
      piVar4 = (int *)(**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 17856 ; VA 0x00983cb0 ; FUN_00983cb0 */

void __thiscall FUN_00983cb0(int param_1,int *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  code *pcVar2;
  char *pcVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  undefined4 *puVar10;
  undefined4 auStack_174 [2];
  undefined4 uStack_16c;
  uint *puStack_168;
  undefined *puStack_164;
  int iStack_160;
  undefined4 *puStack_15c;
  undefined4 *puStack_158;
  undefined8 uStack_154;
  undefined4 uStack_144;
  undefined4 uStack_140;
  uint uStack_13c;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  uint uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined8 uStack_4c;
  undefined4 uStack_44;
  uint uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  int *piStack_24;
  undefined4 *puStack_20;
  int iStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d05ca;
  pvStack_10 = ExceptionList;
  puStack_20 = (undefined4 *)0x0;
  uStack_154 = CONCAT44(param_1,0x983ce2);
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  iStack_18 = FUN_005eef10();
  if (param_1 == 0) {
LAB_00983d37:
    iVar6 = 0;
  }
  else {
    iVar6 = *(int *)(param_1 + 0x34);
    if ((iVar6 != 0) && (param_1 = iVar6, *(int *)(iVar6 + 0x34) != 0)) {
      uStack_154 = CONCAT44(0x983cff,(undefined4)uStack_154);
      param_1 = FUN_005c8ac0();
    }
    if (param_1 == 0) goto LAB_00983d37;
    iVar6 = *(int *)(param_1 + 0xc);
    uStack_154 = CONCAT44(0x983d11,(undefined4)uStack_154);
    iVar5 = FUN_008a8c30();
    if ((uint)*(ushort *)(iVar5 + 0x1da) <
        (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) goto LAB_00983d37;
    uStack_154 = CONCAT44(0x983d33,(undefined4)uStack_154);
    iVar6 = FUN_00562e40();
  }
  puVar10 = param_3;
  if (iStack_18 == 0) {
    if (iVar6 == 0) {
      *(undefined *)((int)param_2 + 0x22) = 0;
      uStack_154 = CONCAT44(0x983d6f,(undefined4)uStack_154);
      (**(code **)(*param_2 + 0x2c))();
      ExceptionList = pvStack_10;
      return;
    }
LAB_00983d81:
    cStack_11 = '\0';
    uStack_154 = CONCAT44(param_3,0x983d91);
    FUN_0054ef60();
    iStack_8 = 0;
    if (puVar10[4] == 0) {
      uStack_154 = 0x3201936580;
      puStack_158 = (undefined4 *)0x983dae;
      FUN_005542c0();
    }
    else {
      iStack_8._0_1_ = 1;
      iStack_8._1_3_ = 0;
      uStack_30 = 0;
      uStack_2c = 0xf;
      uStack_40 = uStack_40 & 0xffffff00;
      puStack_20 = (undefined4 *)0x1;
      uStack_154 = CONCAT44(puVar10[4] + 0x20,0x983ddc);
      FUN_0058a190();
      uStack_154 = 0x20019365b4;
      puStack_158 = (undefined4 *)0x983deb;
      FUN_00554150();
      puVar1 = puVar10 + 4;
      if (0xf < (uint)puVar10[5]) {
        puVar10 = (undefined4 *)*puVar10;
      }
      uStack_154 = CONCAT44(*puVar1,puVar10);
      puStack_158 = (undefined4 *)0x983e00;
      FUN_00554150();
      uStack_154 = CONCAT44(0x983e08,(undefined4)uStack_154);
      FUN_005507b0();
      uStack_5c = uStack_40;
      uStack_40 = uStack_40 & 0xffffff00;
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      uStack_58 = uStack_3c;
      uStack_54 = uStack_38;
      uStack_50 = uStack_34;
      uStack_4c = CONCAT44(uStack_2c,uStack_30);
      uStack_30 = 0;
      uStack_2c = 0xf;
      uStack_154 = CONCAT44(0x983e38,(undefined4)uStack_154);
      FUN_005507b0();
    }
    if (iVar6 == 0) {
      puStack_168 = &uStack_5c;
      uStack_16c = 0x983f8f;
      FUN_0054ef60();
      puStack_168 = (uint *)param_2;
      uStack_16c = 0x983f9d;
      FUN_00925c80();
    }
    else {
      uStack_154 = CONCAT44(&param_3,0x983e4e);
      FUN_00927d30();
      uStack_154 = CONCAT44(&uStack_5c,param_2);
      puStack_158 = (undefined4 *)0x983e5a;
      FUN_0064a950();
      if (DAT_01d646f0 == '\0') {
        puStack_28 = &param_3;
        piStack_24 = (int *)0x0;
        uStack_154 = CONCAT44(&uStack_5c,0x983e80);
        FUN_0054ef60();
        iStack_8._0_1_ = 2;
        pcVar2 = *(code **)(*param_2 + 8);
        uStack_154 = CONCAT44(0x983e8e,(undefined4)uStack_154);
        uStack_144 = FUN_0088cb40();
        uStack_140 = 0;
        uStack_13c = uStack_74;
        uStack_138 = uStack_70;
        uStack_134 = uStack_6c;
        uStack_130 = uStack_68;
        uStack_74 = uStack_74 & 0xffffff00;
        uStack_64 = 0;
        uStack_60 = 0xf;
        uStack_154 = CONCAT44(0x983ecd,(undefined4)uStack_154);
        uStack_140 = FUN_005c9d30();
        iStack_8._0_1_ = 3;
        uStack_154 = CONCAT44(param_2,&uStack_74);
        puStack_158 = &uStack_144;
        uStack_34 = 0;
        uStack_30 = 0;
        uStack_2c = 0;
        puStack_15c = (undefined4 *)0x983f02;
        FUN_00687980();
        iStack_8._0_1_ = 4;
        uStack_154 = CONCAT44(&puStack_28,&uStack_34);
        puStack_158 = (undefined4 *)&DAT_0211e2c0;
        puStack_15c = (undefined4 *)0x983f18;
        (*pcVar2)();
        iStack_8._0_1_ = 5;
        uStack_154 = CONCAT44(0x983f24,(undefined4)uStack_154);
        FUN_00577b20();
        uStack_154 = 0x56e5b000000001;
        puStack_158 = (undefined4 *)0xd0;
        puStack_15c = &uStack_144;
        iStack_8._0_1_ = 2;
        iStack_160 = 0x983f40;
        FUN_016f32d1();
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        if (0xf < uStack_60) {
          uVar9 = uStack_60 + 1;
          uVar7 = uStack_74;
          if (0xfff < uVar9) {
            uVar7 = *(uint *)(uStack_74 - 4);
            uVar9 = uStack_60 + 0x24;
            if (0x1f < (uStack_74 - uVar7) - 4) {
              uStack_154 = CONCAT44(&UNK_0098415c,(undefined4)uStack_154);
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          uStack_154 = CONCAT44(uVar9,uVar7);
          puStack_158 = (undefined4 *)0x983f75;
          FUN_01674ea0();
        }
      }
      cStack_11 = '\x01';
    }
    if (iStack_18 != 0) {
      iVar6 = iStack_18;
    }
    uStack_154 = CONCAT44(0x983fac,(undefined4)uStack_154);
    uStack_154 = FUN_00928340();
    uStack_44 = (undefined4)((ulonglong)uStack_154 >> 0x20);
    iStack_18 = (int)uStack_154;
    if (cStack_11 == '\0') {
      puStack_164 = (undefined *)&puStack_15c;
      puStack_168 = (uint *)0x984117;
      iStack_160 = iVar6;
      FUN_0060e0c0();
      iStack_160 = 0x98411f;
      FUN_00983a40();
    }
    else {
      uStack_154 = CONCAT44(iStack_1c,0x983fc6);
      iStack_1c = FUN_00899230();
      if (iStack_1c != 0) {
        param_3 = auStack_174;
        uStack_154 = DAT_018c0d60;
        FUN_0060e0c0(&puStack_28,iVar6);
        piVar4 = piStack_24;
        if (piStack_24 != (int *)0x0) {
          LOCK();
          piStack_24[2] = piStack_24[2] + 1;
          UNLOCK();
        }
        puStack_20 = puStack_28;
        if (piStack_24 != (int *)0x0) {
          piVar8 = piStack_24 + 2;
          LOCK();
          *piVar8 = *piVar8 + 1;
          UNLOCK();
          LOCK();
          *piVar8 = *piVar8 + 1;
          UNLOCK();
          LOCK();
          *piVar8 = *piVar8 + 1;
          UNLOCK();
          LOCK();
          iVar6 = *piVar8;
          *piVar8 = iVar6 + -1;
          UNLOCK();
          if (iVar6 + -1 == 0) {
            (**(code **)(*piStack_24 + 4))();
          }
          LOCK();
          iVar6 = piVar4[2] + -1;
          piVar4[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
          LOCK();
          iVar6 = piVar4[2] + -1;
          piVar4[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
          piVar8 = piVar4 + 2;
          if (piVar4 != (int *)0x0) {
            LOCK();
            *piVar8 = *piVar8 + 1;
            UNLOCK();
            LOCK();
            iVar6 = *piVar8;
            *piVar8 = iVar6 + -1;
            UNLOCK();
            if (iVar6 + -1 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
          if (piStack_24 != (int *)0x0) {
            LOCK();
            iVar6 = piStack_24[2] + -1;
            piStack_24[2] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*piStack_24 + 4))();
            }
          }
          if (piVar4 != (int *)0x0) {
            LOCK();
            piVar4[2] = piVar4[2] + 1;
            UNLOCK();
          }
        }
        *param_3 = 0;
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar4[2] = piVar4[2] + 1;
          UNLOCK();
        }
        FUN_009642d0(FUN_00983a40);
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar6 = piVar4[2] + -1;
          piVar4[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
          piVar8 = piVar4 + 2;
          LOCK();
          iVar6 = *piVar8;
          *piVar8 = *piVar8 + -1;
          UNLOCK();
          if (iVar6 == 1) {
            (**(code **)(*piVar4 + 4))();
          }
        }
        FUN_009eef30();
      }
    }
    uStack_154 = CONCAT44(0x98412a,(undefined4)uStack_154);
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  if (param_2 == *(int **)(iStack_1c + 0xf4)) {
    if (iVar6 == 0) goto LAB_00983d81;
    pcVar3 = "Cannot kick because of unkonwn network configuration";
  }
  else {
    pcVar3 = "Cannot kick a non-local Player from a LocalScript";
  }
  uStack_154 = CONCAT44(pcVar3,0x984149);
  FUN_00550130();
  uStack_154 = CONCAT44(&DAT_01c17198,&uStack_34);
                    /* WARNING: Subroutine does not return */
  puStack_158 = (undefined4 *)0x984157;
  FUN_0170c2a8();
}



/* FUNCTION 17857 ; VA 0x00984160 ; FUN_00984160 */

void FUN_00984160(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      *param_2 = *param_1;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1db9008);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&TypeDescriptor_01db9004;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 17858 ; VA 0x009841e0 ; FUN_009841e0 */

void FUN_009841e0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c007f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x68);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_009673f0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0096bec0();
        FUN_01674ea0(iVar2,0x68);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1db8b10);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_151497568cf99d2fe628fb34960301f6>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17859 ; VA 0x00984330 ; FUN_00984330 */

int * FUN_00984330(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 == 1) {
        piVar4 = (int *)param_1[3];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 1;
          iVar2 = *piVar1;
          piVar3 = (int *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            piVar1 = piVar4 + 2;
            iVar2 = *piVar1;
            piVar3 = (int *)*piVar1;
            *piVar1 = iVar2 + -1;
            UNLOCK();
            if (iVar2 + -1 == 0) {
              piVar3 = (int *)(**(code **)(*piVar4 + 4))();
            }
          }
        }
        piVar4 = (int *)param_1[1];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00984419. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            piVar3 = (int *)(**(code **)(*piVar4 + 4))();
            return piVar3;
          }
        }
      }
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)FUN_0096efe0(0);
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dba52c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_250a8844084e4a39dda47e6942506235>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 17860 ; VA 0x00984440 ; FUN_00984440 */

void FUN_00984440(int *param_1,int *param_2,int param_3)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar5 = *param_1;
      ExceptionList = &pvStack_10;
      iVar4 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar4 != 0) {
        iVar5 = FUN_00967510(iVar5);
        *param_2 = iVar5;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      puVar1 = (uint *)*param_2;
      if (puVar1 != (uint *)0x0) {
        piVar2 = (int *)puVar1[9];
        ExceptionList = &pvStack_10;
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar5 = piVar2[2] + -1;
          ExceptionList = &pvStack_10;
          piVar2[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        uVar3 = *puVar1;
        uStack_8 = 1;
        if (uVar3 != 0) {
          if ((uVar3 & 1) == 0) {
            if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
              (**(code **)(uVar3 & 0xfffffffe))(puVar1 + 2,puVar1 + 2,2);
            }
          }
          *puVar1 = 0;
        }
        FUN_01674ea0(puVar1,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar5 = FUN_0170d8dd(*param_2 + 4,0x1dba7d8);
      if (iVar5 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_3c7c4bc3df37b562b10806d0dcf11f56>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17861 ; VA 0x009845c0 ; FUN_009845c0 */

int * FUN_009845c0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 == 1) {
        piVar4 = (int *)param_1[3];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 1;
          iVar2 = *piVar1;
          piVar3 = (int *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            piVar1 = piVar4 + 2;
            iVar2 = *piVar1;
            piVar3 = (int *)*piVar1;
            *piVar1 = iVar2 + -1;
            UNLOCK();
            if (iVar2 + -1 == 0) {
              piVar3 = (int *)(**(code **)(*piVar4 + 4))();
            }
          }
        }
        piVar4 = (int *)param_1[1];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x009846a9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            piVar3 = (int *)(**(code **)(*piVar4 + 4))();
            return piVar3;
          }
        }
      }
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)FUN_0096efe0(0);
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dba564);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_48297b19624d1b783fff4ca625ac606b>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 17862 ; VA 0x009846d0 ; FUN_009846d0 */

int * FUN_009846d0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 == 1) {
        piVar4 = (int *)param_1[3];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 1;
          iVar2 = *piVar1;
          piVar3 = (int *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            piVar1 = piVar4 + 2;
            iVar2 = *piVar1;
            piVar3 = (int *)*piVar1;
            *piVar1 = iVar2 + -1;
            UNLOCK();
            if (iVar2 + -1 == 0) {
              piVar3 = (int *)(**(code **)(*piVar4 + 4))();
            }
          }
        }
        piVar4 = (int *)param_1[1];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x009847b9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            piVar3 = (int *)(**(code **)(*piVar4 + 4))();
            return piVar3;
          }
        }
      }
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)FUN_0096efe0(0);
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dba4bc);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_7b4d57d473310e4777e6a293ce7fc071>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 17863 ; VA 0x009847e0 ; FUN_009847e0 */

int * FUN_009847e0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0098488b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0098481e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dba59c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_8bd22ca0f5a993d152ed08954688787b>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 17864 ; VA 0x009848a0 ; FUN_009848a0 */

void FUN_009848a0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c000f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x40);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00967590(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0096c080();
        FUN_01674ea0(iVar2,0x40);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1db902c);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_9bc2c42ebffe3059e8800ae242af3123>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17865 ; VA 0x009849f0 ; FUN_009849f0 */

int * FUN_009849f0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 == 1) {
        piVar4 = (int *)param_1[3];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 1;
          iVar2 = *piVar1;
          piVar3 = (int *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            piVar1 = piVar4 + 2;
            iVar2 = *piVar1;
            piVar3 = (int *)*piVar1;
            *piVar1 = iVar2 + -1;
            UNLOCK();
            if (iVar2 + -1 == 0) {
              piVar3 = (int *)(**(code **)(*piVar4 + 4))();
            }
          }
        }
        piVar4 = (int *)param_1[1];
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar1 = piVar4 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00984ad9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            piVar3 = (int *)(**(code **)(*piVar4 + 4))();
            return piVar3;
          }
        }
      }
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)FUN_0096efe0(0);
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dba484);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_a44fdfcaf8c7caa37a35d82564d5f220>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 17866 ; VA 0x00984b00 ; FUN_00984b00 */

void FUN_00984b00(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffcf;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x48);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00967650(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008e9ba0();
        FUN_01674ea0(iVar2,0x48);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1db93e0);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_ab15919accc3a205f1258c18294ff1f0>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17867 ; VA 0x00984c50 ; FUN_00984c50 */

int * FUN_00984c50(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00984cfb. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00984c8e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dba4f4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_b905ae4e6e05fec8f267a1a47a6b203b>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 17868 ; VA 0x00984d10 ; FUN_00984d10 */

void FUN_00984d10(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffcf;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x48);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00967650(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008e9ba0();
        FUN_01674ea0(iVar2,0x48);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1db93a8);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_d5ce1f04cd623cebd08203e245b9a3ef>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17869 ; VA 0x00984e60 ; FUN_00984e60 */

int * FUN_00984e60(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00984f0b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00984e9e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1db8e4c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_e6bdec9c783492087b5a2dae38d48fc2>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 17870 ; VA 0x00984f20 ; FUN_00984f20 */

void FUN_00984f20(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b7ff;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x38);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_005e5f60(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_005e6120();
        FUN_01674ea0(iVar2,0x38);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1db941c);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<struct_boost::_bi::unspecified,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_boost::_bi::list1<class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17871 ; VA 0x00985070 ; FUN_00985070 */

void FUN_00985070(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a17f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008c1490(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3670();
        FUN_01674ea0(iVar2,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1db950c);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<struct_boost::_bi::unspecified,class_boost::function<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>,class_boost::_bi::list1<class_boost::_bi::value<class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17872 ; VA 0x009851c0 ; FUN_009851c0 */

void FUN_009851c0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a17f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008c1490(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3670();
        FUN_01674ea0(iVar2,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dba3cc);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<struct_boost::_bi::unspecified,class_boost::function<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_boost::_bi::list1<class_boost::_bi::value<class_std::shared_ptr<class_RBX::Pages>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17873 ; VA 0x00985310 ; FUN_00985310 */

void FUN_00985310(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a4a6f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x24);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_009680e0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_006511a0();
        FUN_01674ea0(iVar2,0x24);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1db9064);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<enum_RBX::worker_thread::work_result,enum_RBX::worker_thread::work_result_(__cdecl*)(class_std::shared_ptr<struct_RBX::AbuseReporter::data>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_boost::_bi::list2<class_boost::_bi::value<class_std::shared_ptr<struct_RBX::AbuseReporter::data>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17874 ; VA 0x00985460 ; FUN_00985460 */

void FUN_00985460(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a13f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x50);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        FUN_009682d0(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0096ca80();
        FUN_01674ea0(iVar3,0x50);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1db91c4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool,class_boost::function<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list4<struct_boost::arg<1>,class_boost::_bi::value<bool>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17875 ; VA 0x009855b0 ; FUN_009855b0 */

void FUN_009855b0(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008c1ba0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 8);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x10,iVar3 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar3 + 8) = 0;
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1db8a1c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),class_boost::_bi::list2<class_boost::_bi::value<class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17876 ; VA 0x00985720 ; FUN_00985720 */

void FUN_00985720(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008c1ba0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 8);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x10,iVar3 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar3 + 8) = 0;
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1db86c4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),class_boost::_bi::list2<class_boost::_bi::value<class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17877 ; VA 0x00985890 ; FUN_00985890 */

void FUN_00985890(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008c1ba0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 8);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x10,iVar3 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar3 + 8) = 0;
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1db8934);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>,class_std::shared_ptr<class_RBX::Instance>),class_boost::_bi::list2<class_boost::_bi::value<class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17878 ; VA 0x00985a00 ; FUN_00985a00 */

void FUN_00985a00(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008c1ba0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 8);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x10,iVar3 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar3 + 8) = 0;
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1db85fc);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>,__int64),class_boost::_bi::list2<class_boost::_bi::value<class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17879 ; VA 0x00985b70 ; FUN_00985b70 */

void FUN_00985b70(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017aef3f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x60);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        FUN_0096a4e0(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0096cbb0();
        FUN_01674ea0(iVar3,0x60);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1db9aec);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>,class_std::weak_ptr<class_RBX::DataModel>,class_std::shared_ptr<class_RBX::ModelInstance>,class_boost::function<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list5<class_boost::_bi::value<class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>_>,class_boost::_bi::value<class_std::weak_ptr<class_RBX::DataModel>_>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::ModelInstance>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17880 ; VA 0x00985cc0 ; FUN_00985cc0 */

void FUN_00985cc0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d05ef;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar5 = (undefined4 *)FUN_01674e20(0x68);
      uStack_8 = 0;
      if (puVar5 != (undefined4 *)0x0) {
        *puVar5 = *puVar1;
        FUN_00968b60(puVar1 + 2);
        *param_2 = (int)puVar5;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar6 = *param_2;
      if (iVar6 != 0) {
        piVar2 = *(int **)(iVar6 + 100);
        ExceptionList = &pvStack_10;
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar4 = piVar2[2] + -1;
          ExceptionList = &pvStack_10;
          piVar2[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        uVar3 = *(uint *)(iVar6 + 0x40);
        uStack_8 = 1;
        if (uVar3 != 0) {
          if ((uVar3 & 1) == 0) {
            if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
              (**(code **)(uVar3 & 0xfffffffe))(iVar6 + 0x48,iVar6 + 0x48,2);
            }
          }
          *(undefined4 *)(iVar6 + 0x40) = 0;
        }
        FUN_008c3170();
        FUN_01674ea0(iVar6,0x68);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar6 = FUN_0170d8dd(*param_2 + 4,0x1db8b4c);
      if (iVar6 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::shared_ptr<class_std::exception>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_std::weak_ptr<class_RBX::Players>),class_boost::_bi::list6<struct_boost::arg<1>,struct_boost::arg<2>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::value<class_std::weak_ptr<class_RBX::Players>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17881 ; VA 0x00985e60 ; FUN_00985e60 */

void FUN_00985e60(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a13f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x50);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        FUN_009684d0(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008e9ba0();
        FUN_01674ea0(iVar3,0x50);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dba814);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::DataModel>,class_boost::function<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_boost::_bi::list4<class_boost::_bi::value<class_std::weak_ptr<class_RBX::DataModel>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17882 ; VA 0x00985fb0 ; FUN_00985fb0 */

int * FUN_00985fb0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      param_2[4] = param_1[4];
      piVar3 = (int *)param_1[5];
      param_2[5] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[3];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0098606e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[3];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00985fee. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1db8e84);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::Instance>,__int64),class_boost::_bi::list2<class_boost::_bi::value<class_std::weak_ptr<class_RBX::Instance>_>,class_boost::_bi::value<__int64>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 17883 ; VA 0x00986090 ; FUN_00986090 */

void FUN_00986090(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d060f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x70);
      uStack_8 = 0;
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = *puVar1;
        FUN_00969050(puVar1 + 2);
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        uVar2 = *(uint *)(iVar4 + 0x50);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(iVar4 + 0x58,iVar4 + 0x58,2);
            }
          }
          *(undefined4 *)(iVar4 + 0x50) = 0;
        }
        FUN_0096cca0();
        FUN_01674ea0(iVar4,0x70);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dba07c);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(enum_RBX::HttpRequestResult,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::ModelInstance>,class_std::shared_ptr<int>,class_boost::function<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list7<struct_boost::arg<1>,struct_boost::arg<2>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::ModelInstance>_>,class_boost::_bi::value<class_std::shared_ptr<int>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17884 ; VA 0x00986220 ; FUN_00986220 */

void FUN_00986220(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_1 + 4);
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1db8f2c);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf3<void,class_RBX::Players,class_RBX::DataModel*,class_RBX::SystemAddress_const&,bool>,class_boost::_bi::list4<class_boost::_bi::value<class_RBX::Players*>,struct_boost::arg<1>,class_boost::_bi::value<class_RBX::SystemAddress>,class_boost::_bi::value<bool>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 17885 ; VA 0x00986290 ; FUN_00986290 */

void FUN_00986290(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a13f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x50);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        FUN_00968740(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0096ca80();
        FUN_01674ea0(iVar3,0x50);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1db98cc);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf4<void,class_RBX::Players,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool,class_boost::function<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::list5<class_boost::_bi::value<class_RBX::Players*>,struct_boost::arg<1>,class_boost::_bi::value<bool>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 17886 ; VA 0x009863f0 ; FUN_009863f0 */

void FUN_009863f0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      puVar2 = (undefined4 *)FUN_01674e20(0x48);
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        FUN_00968e30(puVar1 + 2);
        *param_2 = (int)puVar2;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        FUN_0096cc40();
        FUN_01674ea0(iVar3,0x48);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dba5d4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf5<void,class_RBX::Players,struct_RakNet::SystemAddress_const&,class_std::shared_ptr<class_RBX::Network::NetworkStream>_const&,class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::ChatMessage>,struct_RBX::TextFilterResult_const&>,class_boost::_bi::list6<class_boost::_bi::value<class_std::shared_ptr<class_RBX::Players>_>,class_boost::_bi::value<struct_RakNet::SystemAddress>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Network::NetworkStream>_>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Instance>_>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::ChatMessage>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 17887 ; VA 0x009864d0 ; FUN_009864d0 */

void __thiscall FUN_009864d0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  int *piVar10;
  undefined8 uVar11;
  undefined uVar12;
  undefined4 uStack_68;
  undefined4 uStack_54;
  undefined auStack_4c [4];
  undefined4 *puStack_48;
  undefined auStack_44 [4];
  undefined4 *puStack_40;
  undefined4 *puStack_3c;
  undefined4 *puStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 *puStack_20;
  char cStack_19;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d06e9;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  if (param_2 == 0) {
    return;
  }
  iVar6 = *(int *)(param_2 + 0xc);
  ExceptionList = &pvStack_10;
  puStack_3c = param_1;
  iVar5 = FUN_00913630();
  if ((uint)*(ushort *)(iVar5 + 0x1da) <
      (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
    ExceptionList = pvStack_10;
    return;
  }
  uVar11 = FUN_00928340();
  piStack_24 = (int *)((ulonglong)uVar11 >> 0x20);
  puStack_20 = (undefined4 *)uVar11;
  if ((0 < DAT_01ee2fb0) &&
     (DAT_01ee2fb0 <= (((int *)param_1[0x2e])[1] - *(int *)param_1[0x2e] >> 3) + 1)) {
    FUN_00972e70();
    uVar11 = CONCAT44(piStack_24,puStack_20);
  }
  piStack_24 = (int *)((ulonglong)uVar11 >> 0x20);
  puStack_20 = (undefined4 *)uVar11;
  if (DAT_01d59fd0 == '\0') {
LAB_009865a6:
    piStack_24 = (int *)((ulonglong)uVar11 >> 0x20);
    puStack_20 = (undefined4 *)uVar11;
    cStack_19 = '\0';
    iVar6 = FUN_005eef10();
    if (iVar6 == 0) {
      iVar6 = FUN_0064e920();
      if (iVar6 != 0) {
        cVar4 = *(int *)(iVar6 + 0x124) == 2;
        goto LAB_009865d7;
      }
    }
    else {
      cVar4 = FUN_0068ba60();
LAB_009865d7:
      if (cVar4 != '\0') goto LAB_00986641;
    }
    if ((-1 < (int)piStack_24) && ((0 < (int)piStack_24 || (puStack_20 != (undefined4 *)0x0)))) {
      piVar7 = (int *)FUN_0097fc00(auStack_44,puStack_20,piStack_24);
      uStack_30._0_4_ = (undefined4 *)*piVar7;
      uStack_30._4_4_ = (int *)piVar7[1];
      *piVar7 = 0;
      piVar7[1] = 0;
      uStack_8 = 0;
      piStack_14 = (undefined4 *)uStack_30;
      FUN_00550b30();
      if (piStack_14 != (int *)0x0) {
        FUN_008a65e0(0,0);
      }
      uStack_8 = 0xffffffff;
      FUN_00550b30();
    }
  }
  else {
    iVar6 = FUN_005eef10();
    if (iVar6 == 0) {
      iVar6 = FUN_0064e920();
      if (iVar6 != 0) {
        cVar4 = *(int *)(iVar6 + 0x124) == 2;
        goto LAB_00986599;
      }
    }
    else {
      cVar4 = FUN_0068ba60();
LAB_00986599:
      uVar11 = CONCAT44(piStack_24,puStack_20);
      if (cVar4 != '\0') goto LAB_009865a6;
    }
    cStack_19 = '\x01';
  }
LAB_00986641:
  piVar7 = param_1 + 0x2e;
  piStack_14 = (int *)FUN_008a86c0();
  piStack_14 = (int *)*piStack_14;
  puVar8 = (undefined4 *)FUN_0060dcd0(&uStack_30,param_2);
  uStack_8 = 1;
  puVar9 = *(undefined4 **)((int)piStack_14 + 4);
  if (*(undefined4 **)((int)piStack_14 + 8) == puVar9) {
    FUN_00603a30(puVar9,puVar8);
  }
  else {
    *puVar9 = 0;
    puVar9[1] = 0;
    *puVar9 = *puVar8;
    puVar9[1] = puVar8[1];
    *puVar8 = 0;
    puVar8[1] = 0;
    *(int *)((int)piStack_14 + 4) = *(int *)((int)piStack_14 + 4) + 8;
  }
  uStack_8 = 0xffffffff;
  piStack_14 = uStack_30._4_4_;
  if (uStack_30._4_4_ != (int *)0x0) {
    LOCK();
    iVar6 = uStack_30._4_4_[1] + -1;
    uStack_30._4_4_[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*uStack_30._4_4_)();
      LOCK();
      iVar6 = piStack_14[2] + -1;
      piStack_14[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (DAT_01d64710 != '\0') {
    iVar6 = FUN_005eef10();
    if (iVar6 == 0) {
      iVar6 = FUN_0064e920();
      if (iVar6 == 0) goto LAB_00986738;
      cVar4 = *(int *)(iVar6 + 0x124) == 2;
    }
    else {
      cVar4 = FUN_0068ba60();
    }
    if (cVar4 != '\0') {
      uStack_30 = FUN_00928340();
      FUN_00923b40();
    }
  }
LAB_00986738:
  if (DAT_01d64718 != '\0') {
    iVar6 = FUN_005eef10();
    if (iVar6 == 0) {
      iVar6 = FUN_0064e920();
      if (iVar6 == 0) goto LAB_009867ba;
      cVar4 = *(int *)(iVar6 + 0x124) == 2;
    }
    else {
      cVar4 = FUN_0068ba60();
    }
    if (cVar4 != '\0') {
      cVar4 = FUN_00971ce0(param_1,1);
      if (cVar4 != '\0') {
        uVar11 = FUN_00928340();
        uVar12 = 0;
        FUN_005542c0("PlayerConnected",0xf);
        param_1 = puStack_3c;
        FUN_0098af80(uVar11,uVar12);
      }
    }
  }
LAB_009867ba:
  iVar6 = FUN_00917170();
  if (iVar6 != 0) {
    FUN_00bf62d0(puStack_20,piStack_24);
  }
  if (param_1 != (undefined4 *)0x0) {
    puStack_18 = (undefined4 *)param_1[0xd];
    puVar9 = param_1;
    if ((puStack_18 != (undefined4 *)0x0) && (puVar9 = puStack_18, puStack_18[0xd] != 0)) {
      puVar9 = (undefined4 *)FUN_005c8ac0();
    }
    puStack_18 = puVar9;
    if (puStack_18 != (undefined4 *)0x0) {
      iVar6 = puStack_18[3];
      iVar5 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
          (uint)*(ushort *)(iVar5 + 0x1da)) {
        piVar10 = (int *)FUN_005f5690();
        if (*piVar10 != 0) {
          FUN_00a3e1e0();
        }
      }
    }
  }
  iVar6 = FUN_009174b0();
  if (iVar6 != 0) {
    FUN_00bdff10();
    FUN_00934ae0();
  }
  if (DAT_01d646e8 == '\0') {
    iVar6 = FUN_005c8880();
    if (iVar6 != 0) {
      cVar4 = FUN_0068a900(param_1,1);
      goto joined_r0x009868b3;
    }
  }
  else {
    iVar6 = FUN_008f78c0();
    if (iVar6 != 0) {
      cVar4 = FUN_0068a900(iVar6 + 0xc,1);
joined_r0x009868b3:
      if (cVar4 == '\0') {
        FUN_009211d0();
        puVar9 = puStack_20;
        piVar10 = piStack_24;
        uVar2 = uStack_34;
        piStack_14 = (int *)(param_2 + 0x388);
        uStack_30._0_4_ = puStack_20;
        uStack_30._4_4_ = piStack_24;
        puStack_38 = param_1;
        FUN_006eccd0();
        uStack_8 = 2;
        puStack_48 = (undefined4 *)FUN_01675290();
        uStack_8 = 3;
        puStack_18 = (undefined4 *)FUN_01674e20(0x30);
        if (puStack_18 == (undefined4 *)0x0) {
          puStack_18 = (undefined4 *)0x0;
        }
        else {
          *puStack_18 = 0;
          puStack_18[1] = 1;
          puStack_18[2] = FUN_0097aaf0;
          puStack_18[3] = _guard_check_icall;
          puStack_18[4] = 0;
          puStack_18[6] = FUN_0098aeb0;
          puStack_18[7] = 0;
          puStack_18[8] = param_1;
          puStack_18[9] = uVar2;
          puStack_18[5] = piStack_14;
          *(ulonglong *)(puStack_18 + 10) = CONCAT44(piVar10,puVar9);
        }
        FUN_016797d0();
        puStack_40 = puStack_18;
        if (puStack_18 != (undefined4 *)0x0) {
          LOCK();
          puStack_18[1] = puStack_18[1] + 1;
          UNLOCK();
        }
        uStack_28 = 2;
        uStack_8 = 4;
        FUN_01675290();
        uStack_8 = 0xffffffff;
        uStack_28 = 1;
        if (puStack_18 != (undefined4 *)0x0) {
          piVar10 = puStack_18 + 1;
          LOCK();
          iVar6 = *piVar10;
          *piVar10 = *piVar10 + -1;
          UNLOCK();
          if (iVar6 == 1) {
            FUN_01674ea0();
          }
        }
        puVar9 = puStack_20;
        piVar10 = piStack_24;
        uStack_30._0_4_ = puStack_20;
        piStack_14 = (int *)(param_2 + 0x3a8);
        uStack_30._4_4_ = piStack_24;
        puStack_38 = param_1;
        FUN_006eccd0();
        uStack_8 = 5;
        puStack_40 = (undefined4 *)FUN_01675290();
        uStack_8 = 6;
        puStack_18 = (undefined4 *)FUN_01674e20(0x30);
        if (puStack_18 == (undefined4 *)0x0) {
          puStack_18 = (undefined4 *)0x0;
        }
        else {
          *puStack_18 = 0;
          puStack_18[1] = 1;
          puStack_18[2] = FUN_0097a930;
          puStack_18[3] = _guard_check_icall;
          puStack_18[4] = 0;
          puStack_18[6] = FUN_009834e0;
          puStack_18[7] = 0;
          puStack_18[8] = param_1;
          puStack_18[9] = uStack_34;
          puStack_18[5] = piStack_14;
          *(ulonglong *)(puStack_18 + 10) = CONCAT44(piVar10,puVar9);
        }
        FUN_016797d0();
        puStack_48 = puStack_18;
        if (puStack_18 != (undefined4 *)0x0) {
          LOCK();
          puStack_18[1] = puStack_18[1] + 1;
          UNLOCK();
        }
        uStack_28 = 9;
        uStack_8 = 7;
        FUN_01675290();
        uStack_8 = 0xffffffff;
        uStack_28 = 5;
        if (puStack_18 != (undefined4 *)0x0) {
          piVar1 = puStack_18 + 1;
          LOCK();
          iVar6 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar6 == 1) {
            FUN_01674ea0();
          }
        }
        puVar8 = puStack_20;
        piVar1 = piStack_24;
        piStack_14 = (int *)(param_2 + 0x3b8);
        uStack_54 = CONCAT31((int3)((uint)puVar9 >> 8),1);
        FUN_006eccd0();
        uStack_8 = 8;
        puStack_40 = (undefined4 *)FUN_01675290();
        uStack_8 = 9;
        puStack_18 = (undefined4 *)FUN_01674e20(0x40);
        if (puStack_18 == (undefined4 *)0x0) {
          puStack_18 = (undefined4 *)0x0;
        }
        else {
          *puStack_18 = 0;
          puStack_18[1] = 1;
          puStack_18[2] = FUN_0097a9f0;
          puStack_18[3] = _guard_check_icall;
          puStack_18[4] = 0;
          puStack_18[6] = FUN_00988d80;
          puStack_18[7] = 0;
          puStack_18[8] = param_1;
          puStack_18[9] = uStack_68;
          puStack_18[5] = piStack_14;
          puStack_18[10] = puVar8;
          puStack_18[0xb] = piVar1;
          puStack_18[0xc] = "1920x1200";
          puStack_18[0xd] = uStack_34;
          *(ulonglong *)(puStack_18 + 0xe) = CONCAT44(piVar10,uStack_54);
        }
        FUN_016797d0();
        puStack_48 = puStack_18;
        if (puStack_18 != (undefined4 *)0x0) {
          LOCK();
          puStack_18[1] = puStack_18[1] + 1;
          UNLOCK();
        }
        uStack_28 = 0x25;
        uStack_8 = 10;
        FUN_01675290();
        uStack_8 = 0xffffffff;
        uStack_28 = 0x15;
        if (puStack_18 != (undefined4 *)0x0) {
          piVar10 = puStack_18 + 1;
          LOCK();
          iVar6 = *piVar10;
          *piVar10 = *piVar10 + -1;
          UNLOCK();
          if (iVar6 == 1) {
            FUN_01674ea0();
          }
        }
        piStack_24 = (int *)(param_2 + 0x3a0);
        FUN_0060e0c0(&uStack_30,param_2);
        piVar10 = uStack_30._4_4_;
        if (uStack_30._4_4_ != (int *)0x0) {
          LOCK();
          uStack_30._4_4_[2] = uStack_30._4_4_[2] + 1;
          UNLOCK();
        }
        puStack_18 = (undefined4 *)uStack_30;
        piStack_14 = uStack_30._4_4_;
        if (uStack_30._4_4_ != (int *)0x0) {
          LOCK();
          uStack_30._4_4_[2] = uStack_30._4_4_[2] + 1;
          UNLOCK();
          piVar1 = uStack_30._4_4_ + 2;
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
          LOCK();
          iVar6 = *piVar1;
          *piVar1 = iVar6 + -1;
          UNLOCK();
          if (iVar6 + -1 == 0) {
            (**(code **)(*uStack_30._4_4_ + 4))();
          }
          LOCK();
          iVar6 = piVar10[2] + -1;
          piVar10[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar10 + 4))();
          }
          LOCK();
          iVar6 = piVar10[2] + -1;
          piVar10[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar10 + 4))();
          }
          LOCK();
          iVar6 = piVar10[2] + -1;
          piVar10[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar10 + 4))();
          }
        }
        piVar1 = piVar10 + 2;
        if (piVar10 != (int *)0x0) {
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
          LOCK();
          iVar6 = *piVar1;
          *piVar1 = iVar6 + -1;
          UNLOCK();
          if (iVar6 + -1 == 0) {
            (**(code **)(*piVar10 + 4))();
          }
        }
        if (uStack_30._4_4_ != (int *)0x0) {
          LOCK();
          iVar6 = uStack_30._4_4_[2] + -1;
          uStack_30._4_4_[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*uStack_30._4_4_ + 4))();
          }
        }
        uStack_8 = 0xb;
        FUN_006eccd0();
        uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
        puStack_40 = (undefined4 *)FUN_01675290();
        uStack_8 = 0xd;
        puStack_20 = (undefined4 *)FUN_01674e20(0x30);
        if (puStack_20 == (undefined4 *)0x0) {
          puStack_20 = (undefined4 *)0x0;
        }
        else {
          *puStack_20 = 0;
          puStack_20[1] = 1;
          puStack_20[2] = FUN_0097a950;
          puStack_20[3] = FUN_0097ac50;
          puStack_20[4] = 0;
          puStack_20[5] = piStack_24;
          puStack_20[6] = FUN_0097c7a0;
          puStack_20[7] = 0;
          puStack_20[8] = param_1;
          puStack_20[9] = 0;
          puStack_20[10] = 0;
          if (piStack_14 != (int *)0x0) {
            LOCK();
            piStack_14[2] = piStack_14[2] + 1;
            UNLOCK();
          }
          puStack_20[9] = puStack_18;
          puStack_20[10] = piStack_14;
        }
        FUN_016797d0();
        puStack_48 = puStack_20;
        if (puStack_20 != (undefined4 *)0x0) {
          LOCK();
          puStack_20[1] = puStack_20[1] + 1;
          UNLOCK();
        }
        uStack_28 = 0x95;
        uStack_8 = 0xe;
        FUN_01675290();
        if (puStack_20 != (undefined4 *)0x0) {
          piVar10 = puStack_20 + 1;
          LOCK();
          iVar6 = *piVar10;
          *piVar10 = *piVar10 + -1;
          UNLOCK();
          if (iVar6 == 1) {
            FUN_01674ea0();
          }
        }
        uStack_8 = 0xffffffff;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          iVar6 = piStack_14[2] + -1;
          piStack_14[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piStack_14 + 4))();
          }
        }
        iVar6 = FUN_005eef10();
        if (iVar6 == 0) {
          iVar6 = FUN_0064e920();
          if (iVar6 != 0) {
            cVar4 = *(int *)(iVar6 + 0x124) == 2;
            goto LAB_00986e24;
          }
        }
        else {
          cVar4 = FUN_0068ba60();
LAB_00986e24:
          if (cVar4 != '\0') goto LAB_00986e54;
        }
        if (DAT_01d6420c == '\0') {
          cVar4 = FUN_0091dda0();
          if (cVar4 != '\0') goto LAB_00986e54;
        }
        iVar6 = FUN_009174b0();
        if (iVar6 != 0) {
          FUN_00bdfb90();
        }
      }
    }
  }
LAB_00986e54:
  iVar6 = FUN_008f7870();
  if ((iVar6 != 0) && (*(int *)(iVar6 + 0x4a0) == 2)) {
    iVar6 = FUN_008fbd40();
    if (iVar6 == 3) {
      if (*(int *)(param_2 + 0x440) == 0) {
        FUN_00933b20();
      }
    }
    else {
      piStack_14 = (int *)FUN_00899230();
      if (piStack_14 != (int *)0x0) {
        FUN_0060e0c0(&uStack_30,param_2);
        piVar10 = uStack_30._4_4_;
        uStack_8 = 0xf;
        if (uStack_30._4_4_ != (int *)0x0) {
          LOCK();
          uStack_30._4_4_[2] = uStack_30._4_4_[2] + 1;
          UNLOCK();
          LOCK();
          uStack_30._4_4_[2] = uStack_30._4_4_[2] + 1;
          UNLOCK();
        }
        FUN_0095f990(uStack_30,0);
        if (piVar10 != (int *)0x0) {
          LOCK();
          iVar6 = piVar10[2] + -1;
          piVar10[2] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar10 + 4))();
          }
        }
        FUN_009eef30();
        uStack_8 = 0xffffffff;
        FUN_0056c200();
      }
    }
  }
  puVar9 = (undefined4 *)FUN_0060dcd0(&uStack_30,param_2);
  uStack_8 = 0x10;
  uVar2 = *puVar9;
  uVar3 = puVar9[1];
  *puVar9 = 0;
  puVar9[1] = 0;
  FUN_0089be10(uVar2,uVar3);
  uStack_8 = 0xffffffff;
  piStack_14 = uStack_30._4_4_;
  if (uStack_30._4_4_ != (int *)0x0) {
    LOCK();
    iVar6 = uStack_30._4_4_[1] + -1;
    uStack_30._4_4_[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*uStack_30._4_4_)();
      LOCK();
      iVar6 = piStack_14[2] + -1;
      piStack_14[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  puVar8 = (undefined4 *)FUN_0060dcd0(&uStack_30,param_2);
  puVar9 = puStack_3c;
  uStack_8 = 0x11;
  uVar2 = *puVar8;
  uVar3 = puVar8[1];
  *puVar8 = 0;
  puVar8[1] = 0;
  FUN_0089be10(uVar2,uVar3);
  uStack_8 = 0xffffffff;
  piStack_14 = uStack_30._4_4_;
  if (uStack_30._4_4_ != (int *)0x0) {
    LOCK();
    iVar6 = uStack_30._4_4_[1] + -1;
    uStack_30._4_4_[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*uStack_30._4_4_)();
      LOCK();
      piVar10 = piStack_14 + 2;
      iVar6 = *piVar10;
      *piVar10 = *piVar10 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  LOCK();
  puVar9[0x3f] = puVar9[0x3f] + 1;
  UNLOCK();
  if (cStack_19 == '\0') {
    iVar6 = FUN_005eef10();
    if (iVar6 == 0) {
      iVar6 = FUN_0064e920();
      if (iVar6 == 0) goto LAB_0098711c;
      cVar4 = *(int *)(iVar6 + 0x124) == 2;
    }
    else {
      cVar4 = FUN_0068ba60();
    }
    if (cVar4 == '\0') goto LAB_0098711c;
  }
  if (*(char *)(param_2 + 0x4ca) == '\0') {
    puVar9 = (undefined4 *)FUN_0060dcd0(auStack_4c,param_2);
    uStack_8 = 0x13;
    uVar2 = *puVar9;
    uVar3 = puVar9[1];
    *puVar9 = 0;
    puVar9[1] = 0;
    FUN_0089be10(uVar2,uVar3);
  }
  else {
    puVar9 = (undefined4 *)FUN_0060dcd0(&uStack_30);
    uStack_8 = 0x12;
    uVar2 = *puVar9;
    uVar3 = puVar9[1];
    *puVar9 = 0;
    puVar9[1] = 0;
    FUN_0089be10(uVar2,uVar3);
  }
  FUN_00550b30();
LAB_0098711c:
  DAT_01f6dd34 = ((int *)*piVar7)[1] - *(int *)*piVar7 >> 3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17888 ; VA 0x00987150 ; FUN_00987150 */

void __thiscall FUN_00987150(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  undefined4 *puVar9;
  undefined8 uVar10;
  undefined uVar11;
  undefined auStack_34 [4];
  int *piStack_30;
  int *piStack_2c;
  undefined8 uStack_28;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0720;
  pvStack_10 = ExceptionList;
  if (param_2 == 0) {
    return;
  }
  iVar5 = *(int *)(param_2 + 0xc);
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  iVar4 = FUN_00913630();
  if ((uint)*(ushort *)(iVar4 + 0x1da) <
      (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8)) {
    ExceptionList = pvStack_10;
    return;
  }
  iVar5 = FUN_00917170(param_1);
  if (iVar5 != 0) {
    uVar10 = FUN_00928340();
    FUN_00bf63a0(uVar10);
  }
  piStack_2c = (int *)(param_1 + 0xb8);
  *(undefined *)(param_2 + 0x4cb) = 1;
  piVar6 = (int *)FUN_008a86c0();
  iStack_18 = *piVar6;
  piVar7 = (int *)FUN_0060dcd0(auStack_34,param_2);
  piVar8 = (int *)((int *)*piVar6)[1];
  piVar6 = *(int **)*piVar6;
  if (piVar6 != piVar8) {
    do {
      if (*piVar6 == *piVar7) break;
      piVar6 = piVar6 + 2;
    } while (piVar6 != piVar8);
  }
  piVar8 = *(int **)(iStack_18 + 4);
  uStack_28._4_4_ = piVar8;
  if (piVar6 + 2 != piVar8) {
    piStack_1c = (int *)((int)piVar6 - (int)(piVar6 + 2));
    piVar8 = piVar6 + 3;
    do {
      iVar5 = piVar8[-1];
      iVar4 = *piVar8;
      piVar8[-1] = 0;
      *piVar8 = 0;
      *piVar6 = iVar5;
      piVar7 = *(int **)((int)piVar8 + (int)piStack_1c);
      *(int *)((int)piVar8 + (int)piStack_1c) = iVar4;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar5 = piVar7[1] + -1;
        piVar7[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar5 = piVar7[2] + -1;
          piVar7[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar6 = piVar6 + 2;
      piVar7 = piVar8 + 1;
      piVar8 = piVar8 + 2;
    } while (piVar7 != uStack_28._4_4_);
    piVar8 = *(int **)(iStack_18 + 4);
    param_1 = iStack_14;
  }
  piVar8 = (int *)piVar8[-1];
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar5 = piVar8[1] + -1;
    piVar8[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      iVar5 = piVar8[2] + -1;
      piVar8[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  piVar8 = piStack_30;
  *(int *)(iStack_18 + 4) = *(int *)(iStack_18 + 4) + -8;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_30[1] + -1;
    piStack_30[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar6 = piVar8 + 2;
      iVar5 = *piVar6 + -1;
      *piVar6 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  if (DAT_01d64710 != '\0') {
    iVar5 = FUN_005eef10(param_1);
    if (iVar5 == 0) {
      iVar5 = FUN_0064e920(param_1);
      if (iVar5 == 0) goto LAB_00987346;
      cVar3 = *(int *)(iVar5 + 0x124) == 2;
    }
    else {
      cVar3 = FUN_0068ba60();
    }
    if (cVar3 != '\0') {
      uStack_28 = FUN_00928340();
      FUN_005e5570(auStack_34,&uStack_28,param_2);
    }
  }
LAB_00987346:
  if (DAT_01d64718 != '\0') {
    iVar5 = FUN_005eef10(param_1);
    if (iVar5 == 0) {
      iVar5 = FUN_0064e920(param_1);
      if (iVar5 == 0) goto LAB_009873c5;
      cVar3 = *(int *)(iVar5 + 0x124) == 2;
    }
    else {
      cVar3 = FUN_0068ba60();
    }
    if (cVar3 != '\0') {
      cVar3 = FUN_00971ce0(param_1,1);
      if (cVar3 != '\0') {
        uVar10 = FUN_00928340();
        uVar11 = 0;
        FUN_005542c0("PlayerDisconnected",0x12);
        FUN_0098af80(uVar10,uVar11);
      }
    }
  }
LAB_009873c5:
  iVar5 = FUN_009282a0();
  if (iVar5 != 0) {
    FUN_00e41950(param_2);
  }
  puVar9 = (undefined4 *)FUN_0060dcd0(auStack_34,param_2);
  uStack_8 = 0;
  uVar1 = *puVar9;
  uVar2 = puVar9[1];
  *puVar9 = 0;
  puVar9[1] = 0;
  FUN_0089be10(uVar1,uVar2);
  piVar8 = piStack_30;
  uStack_8 = 0xffffffff;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_30[1] + -1;
    piStack_30[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar6 = piVar8 + 2;
      iVar5 = *piVar6 + -1;
      *piVar6 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  puVar9 = (undefined4 *)FUN_0060dcd0(auStack_34,param_2);
  uStack_8 = 1;
  uVar1 = *puVar9;
  uVar2 = puVar9[1];
  *puVar9 = 0;
  puVar9[1] = 0;
  FUN_0089be10(uVar1,uVar2);
  piVar8 = piStack_30;
  uStack_8 = 0xffffffff;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_30[1] + -1;
    piStack_30[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar6 = piVar8 + 2;
      iVar5 = *piVar6 + -1;
      *piVar6 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  puVar9 = (undefined4 *)FUN_0060dcd0(auStack_34,param_2);
  uStack_8 = 2;
  uVar1 = *puVar9;
  uVar2 = puVar9[1];
  *puVar9 = 0;
  puVar9[1] = 0;
  FUN_0089be10(uVar1,uVar2);
  uStack_8 = 0xffffffff;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_30[1] + -1;
    piStack_30[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      iVar5 = piStack_30[2] + -1;
      piStack_30[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  iVar5 = iStack_14;
  if (DAT_01d59fd0 == '\0') {
LAB_0098757e:
    iVar4 = FUN_005eef10(iVar5);
    if (iVar4 == 0) {
      iVar5 = FUN_0064e920(iVar5);
      if (iVar5 == 0) goto LAB_0098762b;
      cVar3 = *(int *)(iVar5 + 0x124) == 2;
    }
    else {
      cVar3 = FUN_0068ba60();
    }
    if (cVar3 == '\0') goto LAB_0098762b;
  }
  else {
    iVar4 = FUN_005eef10(iStack_14);
    if (iVar4 == 0) {
      iVar4 = FUN_0064e920(iVar5);
      if (iVar4 != 0) {
        cVar3 = *(int *)(iVar4 + 0x124) == 2;
        goto LAB_0098757a;
      }
    }
    else {
      cVar3 = FUN_0068ba60();
LAB_0098757a:
      if (cVar3 != '\0') goto LAB_0098757e;
    }
  }
  if (*(char *)(param_2 + 0x4c9) == '\0') {
    puVar9 = (undefined4 *)FUN_0060dcd0(auStack_20,param_2);
    uStack_8 = 3;
    uVar1 = *puVar9;
    uVar2 = puVar9[1];
    *puVar9 = 0;
    puVar9[1] = 0;
    FUN_0089be10(uVar1,uVar2);
    piVar8 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar5 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar6 = piVar8 + 2;
        iVar5 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
LAB_0098762b:
  DAT_01f6dd34 = ((int *)*piStack_2c)[1] - *(int *)*piStack_2c >> 3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17889 ; VA 0x00987660 ; FUN_00987660 */

void __thiscall FUN_00987660(undefined4 param_1,int *param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  
  if (DAT_01d646e8 == '\0') {
    iVar3 = FUN_005c8880(param_1);
    if (iVar3 == 0) goto LAB_009876ed;
    cVar2 = FUN_0068a900(param_1,0);
joined_r0x009876b7:
    if (cVar2 != '\0') goto LAB_009876ed;
  }
  else {
    iVar3 = FUN_008f78c0();
    if (iVar3 == 0) goto LAB_009876ed;
    if (*(int *)(iVar3 + 0x4a0) != 2) {
      cVar2 = FUN_0068a900(iVar3 + 0xc,0);
      goto joined_r0x009876b7;
    }
  }
  iVar3 = *param_2;
  if ((iVar3 != 0) &&
     (iVar1 = *(int *)(iVar3 + 0xc), iVar4 = FUN_00913630(),
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
     (uint)*(ushort *)(iVar4 + 0x1da))) {
    *(undefined *)(iVar3 + 0x22) = 1;
  }
LAB_009876ed:
  FUN_008a41c0(param_2);
  return;
}



/* FUNCTION 17890 ; VA 0x00987700 ; FUN_00987700 */

void __thiscall FUN_00987700(int param_1,undefined *param_2)

{
  undefined8 uVar1;
  
  if (param_2 == PTR_DAT_02120610) {
    uVar1 = 0xffffffffffffffff;
    if (*(int *)(param_1 + 0xf4) != 0) {
      uVar1 = FUN_00928340();
    }
    FUN_00f90710(0,uVar1);
  }
  return;
}



/* FUNCTION 17891 ; VA 0x00987740 ; FUN_00987740 */

int * FUN_00987740(undefined4 param_1,int *param_2,uint param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void **ppvVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  int *in_stack_00000024;
  int *in_stack_00000028;
  uint uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d0758;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  piVar5 = in_stack_00000024;
  ppvVar4 = &pvStack_10;
  if (in_stack_00000024 != (int *)0x0) {
    iVar3 = in_stack_00000024[1];
    ppvVar4 = &pvStack_10;
    for (iVar8 = *in_stack_00000024; ExceptionList = ppvVar4, ppvVar4 = (void **)ExceptionList,
        iVar8 != iVar3; iVar8 = iVar8 + 0x58) {
      FUN_00558df0(&uStack_38,"Players:GetUserIdFromNameAsync() failed: ",&param_3);
      uVar6 = uStack_38;
      uStack_8._0_1_ = 3;
      if (*(uint *)(iVar8 + 0x38) == 0) {
        FUN_0054fda0();
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
        FUN_0054e5e0();
      }
      uStack_28 = 0;
      uStack_24 = 0xf;
      uStack_38 = uStack_38 & 0xffffff00;
      piVar5 = (int *)(**(code **)((*(uint *)(iVar8 + 0x38) & 0xfffffffe) + 4))
                                (iVar8 + 0x40,uVar6,uStack_34,uStack_30,uStack_2c);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (0xf < uStack_24) {
        if ((0xfff < uStack_24 + 1) && (0x1f < (uStack_38 - *(int *)(uStack_38 - 4)) - 4))
        goto LAB_009878bb;
        piVar5 = (int *)FUN_01674ea0();
      }
      ppvVar4 = (void **)ExceptionList;
    }
  }
  ExceptionList = ppvVar4;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar8 = *piVar1;
    piVar5 = (int *)*piVar1;
    *piVar1 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      piVar5 = (int *)(**(code **)(*param_2 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    uVar7 = in_stack_00000020 + 1;
    uVar6 = param_3;
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(param_3 - 4);
      uVar7 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - uVar6) - 4) {
LAB_009878bb:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    piVar5 = (int *)FUN_01674ea0(uVar6,uVar7);
  }
  piVar1 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar2 = in_stack_00000028 + 1;
    iVar8 = *piVar2;
    piVar5 = (int *)*piVar2;
    *piVar2 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      piVar5 = (int *)(**(code **)*in_stack_00000028)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar8 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        piVar5 = (int *)(**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 17892 ; VA 0x009878e0 ; FUN_009878e0 */

int FUN_009878e0(undefined4 param_1,int *param_2,uint param_3)

{
  int *piVar1;
  byte *pbVar2;
  int iVar3;
  undefined uVar4;
  char cVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int *piVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  uint *puVar12;
  uint uVar13;
  uint uVar14;
  uint *puVar15;
  undefined8 uVar16;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 *in_stack_00000024;
  int *in_stack_00000028;
  uint uStack_d0;
  uint *puStack_cc;
  uint uStack_c8;
  uint uStack_c4;
  uint *puStack_c0;
  uint *puStack_bc;
  undefined8 uStack_b8;
  undefined auStack_a8 [12];
  int iStack_9c;
  int *piStack_98;
  undefined4 uStack_94;
  undefined4 *puStack_90;
  undefined4 uStack_8c;
  int iStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  uint uStack_7c;
  undefined auStack_74 [4];
  undefined4 *puStack_70;
  undefined auStack_6c [4];
  uint uStack_68;
  uint auStack_64 [4];
  undefined4 uStack_54;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  uint *puStack_44;
  uint *puStack_40;
  undefined8 uStack_3c;
  undefined auStack_34 [8];
  undefined auStack_2c [4];
  uint uStack_28;
  undefined auStack_20 [4];
  uint *puStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d0827;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_b8 = CONCAT44(&iStack_9c,0x987916);
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8._0_1_ = 3;
  if (iStack_9c == 0) {
    puStack_1c = (uint *)&uStack_b8;
    if (in_stack_00000028 != (int *)0x0) {
      LOCK();
      in_stack_00000028[1] = in_stack_00000028[1] + 1;
      UNLOCK();
    }
    uStack_b8 = CONCAT44(in_stack_00000028,in_stack_00000024);
    uStack_8._0_1_ = 4;
    puStack_c0 = (uint *)0x0;
    puStack_bc = (uint *)&DAT_0000000f;
    uStack_d0 = uStack_d0 & 0xffffff00;
    FUN_005542c0("Internal error",0xe);
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[2] = param_2[2] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 3;
    iVar6 = FUN_00987740(param_1,param_2);
  }
  else {
    uStack_b8 = CONCAT44(&param_3,auStack_a8);
    puStack_bc = (uint *)0x9879bd;
    FUN_016819e0();
    uStack_8._0_1_ = 5;
    uStack_b8 = CONCAT44(0x9879cf,(uint)uStack_b8);
    cVar5 = FUN_016816d0();
    if (cVar5 == '\0') {
      uStack_b8 = CONCAT44(&DAT_018be4a0,auStack_34);
      puStack_bc = (uint *)0x987ab3;
      FUN_0167eea0();
      uStack_b8 = CONCAT44(0x987abb,(uint)uStack_b8);
      cVar5 = FUN_01681830();
      if (cVar5 != '\0') {
        uStack_b8 = CONCAT44(0x987bd3,(uint)uStack_b8);
        piVar9 = (int *)FUN_00564080();
        iStack_18 = *piVar9;
        if (iStack_18 != 0) {
          uStack_b8 = CONCAT44(auStack_34,iStack_18 + 0x148);
          puStack_bc = (uint *)0x987beb;
          FUN_0098d4c0();
        }
        uStack_b8 = 0;
        uStack_94 = 0;
        puStack_90 = (undefined4 *)0x0;
        uStack_8c = 0;
        puStack_bc = (uint *)0x987c1b;
        puStack_90 = (undefined4 *)FUN_008ed990();
        iStack_88 = 0;
        uStack_84 = 0;
        uStack_80 = 0;
        uStack_8._0_1_ = 0xb;
        uStack_94 = 0x3f800000;
        uStack_b8 = 0x800987c54;
        FUN_005cb500();
        uStack_8._0_1_ = 0xc;
        uVar14 = 0;
        uStack_b8 = CONCAT44(0x987c62,(uint)uStack_b8);
        iVar6 = FUN_01681be0();
        if (iVar6 != 0) {
          do {
            uStack_b8 = CONCAT44(uVar14,auStack_20);
            puStack_bc = (uint *)0x987c7d;
            FUN_01680e60();
            uStack_b8 = CONCAT44(&DAT_018c1fd8,auStack_2c);
            puStack_bc = (uint *)0x987c8e;
            FUN_0167eea0();
            uStack_b8 = CONCAT44(&DAT_018c387c,auStack_74);
            puStack_bc = (uint *)0x987c9f;
            FUN_0167eea0();
            uStack_b8 = CONCAT44("requestedUsername",auStack_6c);
            puStack_bc = (uint *)0x987cb0;
            FUN_0167eea0();
            uStack_b8 = CONCAT44(0x987cb8,(uint)uStack_b8);
            cVar5 = FUN_01681850();
            if (cVar5 != '\0') {
              uStack_b8 = CONCAT44(0x987cc8,(uint)uStack_b8);
              cVar5 = FUN_0167e580();
              if (cVar5 != '\0') {
                uStack_b8 = CONCAT44(0x987cd8,(uint)uStack_b8);
                uVar16 = FUN_0167e4f0();
                uStack_14 = (undefined4)((ulonglong)uVar16 >> 0x20);
                uStack_3c = 0xf00000000;
                uStack_4c = uStack_4c & 0xffffff00;
                uStack_8._0_1_ = 0xd;
                uStack_b8 = CONCAT44(&uStack_4c,auStack_64);
                puStack_bc = (uint *)0x987d03;
                uVar7 = FUN_01681580();
                uStack_8._0_1_ = 0xe;
                uStack_b8 = CONCAT44(uVar7,0x987d13);
                puVar10 = (undefined4 *)FUN_0096d830();
                *puVar10 = (int)uVar16;
                puVar10[1] = uStack_14;
                uStack_b8 = CONCAT44(0x987d23,(uint)uStack_b8);
                FUN_005507b0();
                uStack_8._0_1_ = 0xc;
                uStack_b8 = CONCAT44(0x987d2f,(uint)uStack_b8);
                FUN_005507b0();
                uStack_b8 = CONCAT44(0x987d37,(uint)uStack_b8);
                cVar5 = FUN_0167e580();
                if (cVar5 != '\0') {
                  uStack_3c = 0xf00000000;
                  uStack_4c = uStack_4c & 0xffffff00;
                  uStack_8._0_1_ = 0xf;
                  uStack_b8 = CONCAT44(&uStack_4c,auStack_64);
                  puStack_bc = (uint *)0x987d61;
                  uVar7 = FUN_01681580();
                  uStack_8._0_1_ = 0x10;
                  uStack_b8 = CONCAT44(uVar7,0x987d71);
                  puVar10 = (undefined4 *)FUN_0096d830();
                  *puVar10 = (int)uVar16;
                  puVar10[1] = uStack_14;
                  uStack_b8 = CONCAT44(0x987d81,(uint)uStack_b8);
                  FUN_005507b0();
                  uStack_8._0_1_ = 0xc;
                  uStack_b8 = CONCAT44(0x987d8d,(uint)uStack_b8);
                  FUN_005507b0();
                }
              }
            }
            uVar14 = uVar14 + 1;
            uStack_b8 = CONCAT44(0x987d96,(uint)uStack_b8);
            uVar13 = FUN_01681be0();
          } while (uVar14 < uVar13);
        }
        puVar15 = (uint *)*in_stack_00000024;
        puStack_1c = (uint *)in_stack_00000024[1];
        if (puVar15 != puStack_1c) {
          do {
            puVar12 = puVar15;
            if (0xf < puVar15[5]) {
              puVar12 = (uint *)*puVar15;
            }
            uVar14 = 0;
            uStack_68 = 0x811c9dc5;
            if (puVar15[4] != 0) {
              do {
                pbVar2 = (byte *)(uVar14 + (int)puVar12);
                uVar14 = uVar14 + 1;
                uStack_68 = (*pbVar2 ^ uStack_68) * 0x1000193;
              } while (uVar14 < puVar15[4]);
            }
            uStack_68 = uStack_68 & uStack_7c;
            puVar10 = *(undefined4 **)(iStack_88 + uStack_68 * 8);
            puStack_70 = puVar10;
            while( true ) {
              puVar11 = puStack_90;
              if (puStack_70 != puStack_90) {
                puVar11 = (undefined4 *)**(undefined4 **)(iStack_88 + 4 + uStack_68 * 8);
              }
              if (puVar10 == puVar11) goto LAB_00987ea4;
              puStack_c0 = puVar10 + 2;
              puVar12 = puVar15;
              if (0xf < puVar15[5]) {
                puVar12 = (uint *)*puVar15;
              }
              puStack_bc = (uint *)puVar10[6];
              uStack_28 = puVar10[7];
              if (0xf < uStack_28) {
                puStack_c0 = (uint *)*puStack_c0;
              }
              uStack_b8 = CONCAT44(puVar15[4],puVar12);
              uStack_c4 = 0x987e38;
              uStack_14 = puStack_bc;
              cVar5 = FUN_0055c360();
              if (cVar5 != '\0') break;
              puVar10 = (undefined4 *)*puVar10;
            }
            piVar9 = puVar10 + 2;
            if (0xf < uStack_28) {
              piVar9 = (int *)*piVar9;
            }
            puStack_c0 = puVar15;
            if (0xf < puVar15[5]) {
              puStack_c0 = (uint *)*puVar15;
            }
            uStack_b8 = CONCAT44(uStack_14,piVar9);
            puStack_bc = (uint *)puVar15[4];
            uStack_c4 = 0x987e6b;
            cVar5 = FUN_0055c360();
            if (cVar5 == '\0') {
              puVar10 = puStack_90;
            }
            if (puVar10 == puStack_90) {
LAB_00987ea4:
              uStack_b8 = 0x29019352bc;
              uStack_54 = 0;
              uStack_50 = 0xf;
              auStack_64[0] = auStack_64[0] & 0xffffff00;
              puStack_bc = (uint *)0x987ec5;
              FUN_005542c0();
              uStack_b8 = 0xc01935338;
              uStack_8._0_1_ = 0x12;
              puStack_bc = (uint *)0x987ed8;
              puVar12 = (uint *)FUN_00554150();
              uVar14 = *puVar12;
              uStack_48 = puVar12[1];
              puStack_44 = (uint *)puVar12[2];
              puStack_40 = (uint *)puVar12[3];
              uVar16 = *(undefined8 *)(puVar12 + 4);
              puVar12[4] = 0;
              puVar12[5] = 0xf;
              *(undefined *)puVar12 = 0;
              uStack_8._0_1_ = 0x13;
              uVar4 = (undefined)uStack_8;
              uStack_8._0_1_ = 0x13;
              if (puVar15[0xe] == 0) {
                uStack_b8 = CONCAT44(0x988055,(uint)uStack_b8);
                uStack_4c = uVar14;
                uStack_3c = uVar16;
                uStack_8._0_1_ = uVar4;
                uVar7 = FUN_0054fda0();
                uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
                uStack_b8 = CONCAT44(uVar7,&UNK_0098805f);
                    /* WARNING: Subroutine does not return */
                FUN_0054e5e0();
              }
              uStack_3c = 0xf00000000;
              uStack_4c = uVar14 & 0xffffff00;
              puStack_cc = puVar15 + 0x10;
              uStack_d0 = 0x987f34;
              uStack_c8 = uVar14;
              uStack_c4 = uStack_48;
              puStack_c0 = puStack_44;
              puStack_bc = puStack_40;
              uStack_b8 = uVar16;
              (**(code **)((puVar15[0xe] & 0xfffffffe) + 4))();
              uStack_8._0_1_ = 0xc;
              if (0xf < uStack_50) {
                uVar13 = uStack_50 + 1;
                uVar14 = auStack_64[0];
                if (0xfff < uVar13) {
                  uVar14 = *(uint *)(auStack_64[0] - 4);
                  uVar13 = uStack_50 + 0x24;
                  if (0x1f < (auStack_64[0] - uVar14) - 4) goto LAB_00988036;
                }
                uStack_b8 = CONCAT44(uVar13,uVar14);
                puStack_bc = (uint *)0x987f6c;
                FUN_01674ea0();
              }
              if (iStack_18 != 0) {
                uStack_b8 = 0;
                puStack_c0 = (uint *)0x987f86;
                puStack_bc = puVar15;
                FUN_00f89750();
              }
            }
            else {
              if (puVar15[6] == 0) {
                uStack_b8 = CONCAT44(0x988043,(uint)uStack_b8);
                uVar7 = FUN_0054fda0();
                uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
                uStack_b8 = CONCAT44(uVar7,0x98804d);
                    /* WARNING: Subroutine does not return */
                FUN_0054e5e0();
              }
              puStack_bc = puVar15 + 8;
              uStack_b8 = *(undefined8 *)(puVar10 + 8);
              puStack_c0 = (uint *)0x987e9c;
              (**(code **)((puVar15[6] & 0xfffffffe) + 4))();
            }
            puVar15 = puVar15 + 0x16;
          } while (puVar15 != puStack_1c);
        }
        uStack_b8 = CONCAT44(0x987f9d,(uint)uStack_b8);
        FUN_0096c3b0();
        uStack_b8 = CONCAT44(0x987fa8,(uint)uStack_b8);
        iVar6 = FUN_0167ec40();
        if (piStack_98 != (int *)0x0) {
          LOCK();
          piVar9 = piStack_98 + 1;
          iVar3 = *piVar9;
          iVar6 = *piVar9;
          *piVar9 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            uStack_b8 = CONCAT44(0x987fcc,(uint)uStack_b8);
            (**(code **)*piStack_98)();
            LOCK();
            piVar9 = piStack_98 + 2;
            iVar3 = *piVar9;
            iVar6 = *piVar9;
            *piVar9 = iVar3 + -1;
            UNLOCK();
            if (iVar3 + -1 == 0) {
              uStack_b8 = CONCAT44(0x987fe0,(uint)uStack_b8);
              iVar6 = (**(code **)(*piStack_98 + 4))();
            }
          }
        }
        goto LAB_00987b7f;
      }
      puStack_1c = (uint *)&uStack_b8;
      if (in_stack_00000028 != (int *)0x0) {
        LOCK();
        in_stack_00000028[1] = in_stack_00000028[1] + 1;
        UNLOCK();
      }
      uStack_b8 = CONCAT44(in_stack_00000028,in_stack_00000024);
      uStack_8._0_1_ = 9;
      puStack_c0 = (uint *)0x0;
      puStack_bc = (uint *)&DAT_0000000f;
      uStack_d0 = uStack_d0 & 0xffffff00;
      FUN_005542c0("Bad server response",0x13);
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[2] = param_2[2] + 1;
        UNLOCK();
      }
      uStack_8._0_1_ = 5;
      FUN_00987740(param_1,param_2);
    }
    else {
      uStack_b8 = CONCAT44(0x9879e2,(uint)uStack_b8);
      uVar7 = FUN_016814a0();
      uStack_b8 = 0x2018bcaac;
      uStack_54 = 0;
      uStack_50 = 0xf;
      auStack_64[0] = auStack_64[0] & 0xffffff00;
      puStack_bc = (uint *)0x987a05;
      FUN_005542c0();
      uStack_8._0_1_ = 6;
      puStack_bc = &uStack_4c;
      uStack_b8 = CONCAT44(auStack_64,"Bad server response");
      puStack_c0 = (uint *)0x987a1b;
      uVar8 = FUN_00558d90();
      puStack_1c = (uint *)&uStack_b8;
      if (in_stack_00000028 != (int *)0x0) {
        LOCK();
        in_stack_00000028[1] = in_stack_00000028[1] + 1;
        UNLOCK();
      }
      uStack_b8 = CONCAT44(in_stack_00000028,in_stack_00000024);
      uStack_8._0_1_ = 8;
      FUN_00558c80(&uStack_d0,uVar8,uVar7);
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[2] = param_2[2] + 1;
        UNLOCK();
      }
      uStack_8._0_1_ = 7;
      FUN_00987740(param_1,param_2);
      uStack_b8 = CONCAT44(0x987a95,(uint)uStack_b8);
      FUN_005507b0();
      uStack_b8 = CONCAT44(0x987a9d,(uint)uStack_b8);
      FUN_005507b0();
    }
    uStack_b8 = CONCAT44(0x987b53,(uint)uStack_b8);
    iVar6 = FUN_0167ec40();
  }
  if (piStack_98 != (int *)0x0) {
    LOCK();
    piVar9 = piStack_98 + 1;
    iVar3 = *piVar9;
    iVar6 = *piVar9;
    *piVar9 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      uStack_b8 = CONCAT44(0x987b6c,(uint)uStack_b8);
      (**(code **)*piStack_98)();
      LOCK();
      piVar9 = piStack_98 + 2;
      iVar3 = *piVar9;
      iVar6 = *piVar9;
      *piVar9 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        uStack_b8 = CONCAT44(0x987b7c,(uint)uStack_b8);
        iVar6 = (**(code **)(*piStack_98 + 4))();
      }
    }
  }
LAB_00987b7f:
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar9 = param_2 + 2;
    iVar3 = *piVar9;
    iVar6 = *piVar9;
    *piVar9 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      uStack_b8 = CONCAT44(0x987b94,(uint)uStack_b8);
      iVar6 = (**(code **)(*param_2 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    uVar13 = in_stack_00000020 + 1;
    uVar14 = param_3;
    if (0xfff < uVar13) {
      uVar14 = *(uint *)(param_3 - 4);
      uVar13 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - uVar14) - 4) {
LAB_00988036:
        uStack_b8 = CONCAT44(0x98803b,(uint)uStack_b8);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_b8 = CONCAT44(uVar13,uVar14);
    puStack_bc = (uint *)0x987fec;
    iVar6 = FUN_01674ea0();
  }
  piVar9 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000028 + 1;
    iVar3 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      uStack_b8 = CONCAT44(0x988017,(uint)uStack_b8);
      iVar6 = (**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        uStack_b8 = CONCAT44(0x988026,(uint)uStack_b8);
        iVar6 = (**(code **)(*piVar9 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 17893 ; VA 0x00988060 ; FUN_00988060 */

int * FUN_00988060(undefined4 param_1,int *param_2,uint param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void **ppvVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  int *in_stack_00000024;
  int *in_stack_00000028;
  uint uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d0868;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  piVar5 = in_stack_00000024;
  ppvVar4 = &pvStack_10;
  if (in_stack_00000024 != (int *)0x0) {
    iVar3 = in_stack_00000024[1];
    ppvVar4 = &pvStack_10;
    for (iVar8 = *in_stack_00000024; ExceptionList = ppvVar4, ppvVar4 = (void **)ExceptionList,
        iVar8 != iVar3; iVar8 = iVar8 + 0x48) {
      FUN_00558df0(&uStack_38,"Players:GetNameFromUserIdAsync() failed: ",&param_3);
      uVar6 = uStack_38;
      uStack_8._0_1_ = 3;
      if (*(uint *)(iVar8 + 0x28) == 0) {
        FUN_0054fda0();
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
        FUN_0054e5e0();
      }
      uStack_28 = 0;
      uStack_24 = 0xf;
      uStack_38 = uStack_38 & 0xffffff00;
      piVar5 = (int *)(**(code **)((*(uint *)(iVar8 + 0x28) & 0xfffffffe) + 4))
                                (iVar8 + 0x30,uVar6,uStack_34,uStack_30,uStack_2c);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (0xf < uStack_24) {
        if ((0xfff < uStack_24 + 1) && (0x1f < (uStack_38 - *(int *)(uStack_38 - 4)) - 4))
        goto LAB_009881db;
        piVar5 = (int *)FUN_01674ea0();
      }
      ppvVar4 = (void **)ExceptionList;
    }
  }
  ExceptionList = ppvVar4;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar8 = *piVar1;
    piVar5 = (int *)*piVar1;
    *piVar1 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      piVar5 = (int *)(**(code **)(*param_2 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    uVar7 = in_stack_00000020 + 1;
    uVar6 = param_3;
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(param_3 - 4);
      uVar7 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - uVar6) - 4) {
LAB_009881db:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    piVar5 = (int *)FUN_01674ea0(uVar6,uVar7);
  }
  piVar1 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar2 = in_stack_00000028 + 1;
    iVar8 = *piVar2;
    piVar5 = (int *)*piVar2;
    *piVar2 = iVar8 + -1;
    UNLOCK();
    if (iVar8 + -1 == 0) {
      piVar5 = (int *)(**(code **)*in_stack_00000028)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar8 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        piVar5 = (int *)(**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 17894 ; VA 0x00988200 ; FUN_00988200 */

int FUN_00988200(undefined4 param_1,int *param_2,uint param_3)

{
  int *piVar1;
  int iVar2;
  uint ***pppuVar3;
  uint ***pppuVar4;
  uint ***pppuVar5;
  uint *****pppppuVar6;
  undefined uVar7;
  char cVar8;
  int iVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  int *piVar12;
  uint ****ppppuVar13;
  uint uVar14;
  uint ****ppppuVar15;
  uint ****ppppuVar16;
  undefined4 *puVar17;
  uint uVar18;
  uint **ppuVar19;
  uint ***pppuVar20;
  undefined8 uVar21;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 *in_stack_00000024;
  int *in_stack_00000028;
  uint uStack_e8;
  uint ***pppuStack_e4;
  uint ****ppppuStack_e0;
  uint **ppuStack_dc;
  uint ***pppuStack_d8;
  uint ****ppppuStack_d4;
  undefined8 uStack_d0;
  undefined auStack_c0 [8];
  undefined auStack_b8 [12];
  undefined auStack_ac [8];
  undefined auStack_a4 [12];
  int iStack_98;
  int *piStack_94;
  uint ***pppuStack_90;
  undefined uStack_8c;
  undefined8 uStack_88;
  uint ****ppppuStack_80;
  uint **ppuStack_7c;
  uint **ppuStack_78;
  uint ****ppppuStack_74;
  undefined8 uStack_70;
  undefined4 uStack_68;
  uint ***pppuStack_64;
  int iStack_60;
  int iStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  uint uStack_50;
  undefined auStack_48 [8];
  int iStack_40;
  undefined uStack_39;
  uint ****ppppuStack_38;
  uint **ppuStack_34;
  uint **ppuStack_30;
  uint ****ppppuStack_2c;
  uint **ppuStack_28;
  uint ***pppuStack_24;
  uint ***pppuStack_20;
  uint **ppuStack_1c;
  uint **ppuStack_18;
  uint ***pppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d0934;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_d0 = CONCAT44(&iStack_98,0x988236);
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8._0_1_ = 3;
  if (iStack_98 == 0) {
    pppuStack_14 = (uint ***)&uStack_d0;
    if (in_stack_00000028 != (int *)0x0) {
      LOCK();
      in_stack_00000028[1] = in_stack_00000028[1] + 1;
      UNLOCK();
    }
    uStack_d0 = CONCAT44(in_stack_00000028,in_stack_00000024);
    uStack_8._0_1_ = 4;
    pppuStack_d8 = (uint ***)0x0;
    ppppuStack_d4 = (uint ****)&DAT_0000000f;
    uStack_e8 = uStack_e8 & 0xffffff00;
    FUN_005542c0("Internal error",0xe);
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[2] = param_2[2] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 3;
    iVar9 = FUN_00988060(param_1,param_2);
  }
  else {
    uStack_d0 = CONCAT44(&param_3,auStack_a4);
    ppppuStack_d4 = (uint ****)0x9882dd;
    FUN_016819e0();
    uStack_8._0_1_ = 5;
    uStack_d0 = CONCAT44(0x9882ef,(int)uStack_d0);
    cVar8 = FUN_016816d0();
    if (cVar8 == '\0') {
      uStack_d0 = CONCAT44(&DAT_018be4a0,auStack_48);
      ppppuStack_d4 = (uint ****)0x9883d3;
      FUN_0167eea0();
      uStack_d0 = CONCAT44(0x9883db,(int)uStack_d0);
      cVar8 = FUN_01681830();
      if (cVar8 != '\0') {
        uStack_d0 = CONCAT44(0x9884f3,(int)uStack_d0);
        piVar12 = (int *)FUN_00564080();
        iStack_40 = *piVar12;
        if (iStack_40 != 0) {
          uStack_d0 = CONCAT44(auStack_48,iStack_40 + 0x148);
          ppppuStack_d4 = (uint ****)0x98850b;
          FUN_0098d4c0();
        }
        uStack_d0 = 0;
        uStack_68 = 0;
        pppuStack_64 = (uint ***)0x0;
        iStack_60 = 0;
        ppppuStack_d4 = (uint ****)0x98852f;
        pppuStack_64 = (uint ***)FUN_008ed990();
        iStack_5c = 0;
        uStack_58 = 0;
        uStack_54 = 0;
        uStack_8._0_1_ = 0xb;
        uStack_68 = 0x3f800000;
        uStack_d0 = 0x80098855c;
        FUN_005cb500();
        ppuVar19 = (uint **)0x0;
        uStack_8._0_1_ = 0xc;
        ppuStack_18 = (uint **)0x0;
        uStack_d0 = CONCAT44(0x98856d,(int)uStack_d0);
        iVar9 = FUN_01681be0();
        if (iVar9 != 0) {
          do {
            uStack_d0 = CONCAT44(ppuVar19,auStack_b8);
            ppppuStack_d4 = (uint ****)0x988585;
            FUN_01680e60();
            uStack_d0 = CONCAT44(&DAT_018c1fd8,auStack_ac);
            ppppuStack_d4 = (uint ****)0x98859c;
            FUN_0167eea0();
            uStack_d0 = CONCAT44(&DAT_018c387c,auStack_c0);
            ppppuStack_d4 = (uint ****)0x9885b3;
            FUN_0167eea0();
            uStack_d0 = CONCAT44(0x9885be,(int)uStack_d0);
            cVar8 = FUN_01681850();
            if (cVar8 != '\0') {
              uStack_d0 = CONCAT44(0x9885d1,(int)uStack_d0);
              cVar8 = FUN_0167e580();
              if (cVar8 != '\0') {
                uStack_70 = 0xf00000000;
                ppppuStack_80 = (uint ****)((uint)ppppuStack_80 & 0xffffff00);
                uStack_8._0_1_ = 0xd;
                uStack_d0 = CONCAT44(&ppppuStack_80,&ppppuStack_38);
                ppppuStack_d4 = (uint ****)0x988602;
                ppppuVar13 = (uint ****)FUN_01681580();
                uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
                uStack_d0 = CONCAT44(0x988613,(int)uStack_d0);
                uVar21 = FUN_0167e4f0();
                uStack_d0 = CONCAT44(&uStack_88,&pppuStack_20);
                ppppuStack_d4 = (uint ****)0x98862f;
                uStack_88 = uVar21;
                FUN_0097bf20();
                if (pppuStack_20 == pppuStack_64) {
                  pppuVar20 = (uint ***)*pppuStack_64;
                  uStack_d0 = CONCAT44(&uStack_39,&ppuStack_1c);
                  ppuStack_1c = (uint **)&uStack_88;
                  ppppuStack_d4 = (uint ****)&DAT_018bdeda;
                  pppuStack_d8 = (uint ***)pppuVar20[1];
                  ppppuStack_e0 = (uint ****)0x988661;
                  ppuStack_dc = (uint **)pppuVar20;
                  pppuStack_14 = pppuStack_d8;
                  ppuStack_1c = (uint **)FUN_00961780();
                  if (iStack_60 == 0x6666665) {
                    uStack_d0 = 0x18c0fdc00988a8c;
                    /* WARNING: Subroutine does not return */
                    FUN_016ddcd9();
                  }
                  iStack_60 = iStack_60 + 1;
                  pppuVar20[1] = ppuStack_1c;
                  *pppuStack_14 = ppuStack_1c;
                  uStack_d0 = CONCAT44(*pppuStack_64,*pppuStack_64 + 2);
                  ppppuStack_d4 = &pppuStack_90;
                  pppuStack_d8 = (uint ***)0x98869f;
                  FUN_009624c0();
                }
                else {
                  pppuStack_90 = pppuStack_20;
                  uStack_8c = 0;
                }
                pppuVar20 = pppuStack_90;
                ppppuVar16 = (uint ****)(pppuStack_90 + 4);
                if (ppppuVar16 != ppppuVar13) {
                  uStack_d0 = CONCAT44(0x9886c2,(int)uStack_d0);
                  FUN_005507b0();
                  pppuVar3 = ppppuVar13[1];
                  pppuVar4 = ppppuVar13[2];
                  pppuVar5 = ppppuVar13[3];
                  *ppppuVar16 = *ppppuVar13;
                  pppuVar20[5] = (uint **)pppuVar3;
                  pppuVar20[6] = (uint **)pppuVar4;
                  pppuVar20[7] = (uint **)pppuVar5;
                  pppuVar3 = ppppuVar13[5];
                  pppuVar20[8] = (uint **)ppppuVar13[4];
                  pppuVar20[9] = (uint **)pppuVar3;
                  ppppuVar13[4] = (uint ***)0x0;
                  ppppuVar13[5] = (uint ***)0xf;
                  *(undefined *)ppppuVar13 = 0;
                }
                uStack_d0 = CONCAT44(0x9886eb,(int)uStack_d0);
                FUN_005507b0();
                uStack_8._0_1_ = 0xc;
                uStack_d0 = CONCAT44(0x9886f7,(int)uStack_d0);
                FUN_005507b0();
                ppuVar19 = ppuStack_18;
              }
            }
            ppuVar19 = (uint **)((int)ppuVar19 + 1);
            uStack_d0 = CONCAT44(0x988706,(int)uStack_d0);
            ppuStack_18 = ppuVar19;
            uVar14 = FUN_01681be0();
          } while (ppuVar19 < uVar14);
        }
        pppuVar20 = (uint ***)*in_stack_00000024;
        ppuStack_1c = (uint **)in_stack_00000024[1];
        ppuStack_18 = (uint **)pppuVar20;
        if (pppuVar20 != (uint ***)ppuStack_1c) {
          pppuStack_20 = pppuVar20 + 0xc;
          do {
            uStack_d0 = CONCAT44(pppuVar20,0x988739);
            ppuStack_18 = (uint **)pppuVar20;
            uVar14 = FUN_005e6570();
            pppuStack_14 = *(uint ****)(iStack_5c + (uVar14 & uStack_50) * 8);
            ppppuVar13 = (uint ****)pppuStack_14;
            while( true ) {
              ppppuVar16 = (uint ****)pppuStack_64;
              if (pppuStack_14 != pppuStack_64) {
                ppppuVar16 = (uint ****)**(undefined4 **)(iStack_5c + 4 + (uVar14 & uStack_50) * 8);
              }
              ppppuVar15 = (uint ****)pppuStack_64;
              if ((ppppuVar13 == ppppuVar16) ||
                 ((ppppuVar13[2] == (uint ***)*pppuVar20 &&
                  (ppppuVar15 = ppppuVar13, ppppuVar13[3] == (uint ***)pppuVar20[1])))) break;
              ppppuVar13 = (uint ****)*ppppuVar13;
            }
            ppuStack_28 = (uint **)0x0;
            if (ppppuVar15 == (uint ****)pppuStack_64) {
              uStack_d0 = 0x29019352bc;
              pppuStack_24 = (uint ***)0xf;
              ppppuStack_38 = (uint ****)((uint)ppppuStack_38 & 0xffffff00);
              ppppuStack_d4 = (uint ****)0x9888a0;
              FUN_005542c0();
              uStack_d0 = 0xc01935338;
              uStack_8._0_1_ = 0x11;
              ppppuStack_d4 = (uint ****)0x9888b3;
              puVar17 = (undefined4 *)FUN_00554150();
              pppppuVar6 = (uint *****)*puVar17;
              ppuStack_7c = (uint **)puVar17[1];
              ppuStack_78 = (uint **)puVar17[2];
              ppppuStack_74 = (uint ****)puVar17[3];
              uVar21 = *(undefined8 *)(puVar17 + 4);
              puVar17[4] = 0;
              puVar17[5] = 0xf;
              *(undefined *)puVar17 = 0;
              uStack_8._0_1_ = 0x12;
              uVar7 = (undefined)uStack_8;
              uStack_8._0_1_ = 0x12;
              if ((uint ***)pppuStack_20[-2] == (uint ***)0x0) {
                uStack_d0 = CONCAT44(0x988aac,(int)uStack_d0);
                ppppuStack_80 = (uint ****)pppppuVar6;
                uStack_70 = uVar21;
                uStack_8._0_1_ = uVar7;
                uVar10 = FUN_0054fda0();
                uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
                uStack_d0 = CONCAT44(uVar10,&UNK_00988ab6);
                    /* WARNING: Subroutine does not return */
                FUN_0054e5e0();
              }
              uStack_70 = 0xf00000000;
              ppppuStack_80 = (uint ****)((uint)pppppuVar6 & 0xffffff00);
              pppuStack_e4 = pppuStack_20;
              uStack_e8 = 0x98890f;
              ppppuStack_e0 = (uint ****)pppppuVar6;
              ppuStack_dc = ppuStack_7c;
              pppuStack_d8 = (uint ***)ppuStack_78;
              ppppuStack_d4 = ppppuStack_74;
              uStack_d0 = uVar21;
              (**(code **)(((uint)pppuStack_20[-2] & 0xfffffffe) + 4))();
              uStack_8._0_1_ = 0xc;
              uVar7 = (undefined)uStack_8;
              uStack_8._0_1_ = 0xc;
              if (0xf < pppuStack_24) {
                uVar14 = (int)pppuStack_24 + 1;
                ppppuVar13 = ppppuStack_38;
                if (0xfff < uVar14) {
                  ppppuVar13 = (uint ****)ppppuStack_38[-1];
                  uVar14 = (int)pppuStack_24 + 0x24;
                  if (0x1f < (uint)((int)ppppuStack_38 + (-4 - (int)ppppuVar13))) goto LAB_00988a7d;
                }
                uStack_d0 = CONCAT44(uVar14,ppppuVar13);
                ppppuStack_d4 = (uint ****)0x988947;
                FUN_01674ea0();
              }
              if (iStack_40 != 0) {
                uVar21 = *(undefined8 *)pppuVar20;
                uStack_d0 = 0x18bc9b8;
                ppuStack_28 = (uint **)0x0;
                pppuStack_24 = (uint ***)0xf;
                ppppuStack_38 = (uint ****)((uint)ppppuStack_38 & 0xffffff00);
                ppppuStack_d4 = (uint ****)0x988976;
                FUN_005542c0();
                ppppuStack_d4 = (uint ****)&ppppuStack_38;
                uStack_8._0_1_ = 0x14;
                pppuStack_d8 = (uint ***)0x98898e;
                uStack_d0 = uVar21;
                FUN_00f89750();
                uStack_8._0_1_ = 0xc;
                pppuVar20 = (uint ***)ppuStack_18;
                if (0xf < pppuStack_24) {
                  uVar14 = (int)pppuStack_24 + 1;
                  ppppuVar13 = ppppuStack_38;
                  if (0xfff < uVar14) {
                    ppppuVar13 = (uint ****)ppppuStack_38[-1];
                    uVar14 = (int)pppuStack_24 + 0x24;
                    uVar7 = (undefined)uStack_8;
                    if (0x1f < (uint)((int)ppppuStack_38 + (-4 - (int)ppppuVar13)))
                    goto LAB_00988a7d;
                  }
                  uStack_d0 = CONCAT44(uVar14,ppppuVar13);
                  ppppuStack_d4 = (uint ****)0x9889c3;
                  FUN_01674ea0();
                  pppuVar20 = (uint ***)ppuStack_18;
                }
              }
            }
            else {
              ppppuVar13 = ppppuVar15 + 4;
              ppuStack_18 = (uint **)ppppuVar15[8];
              pppuStack_24 = (uint ***)0x0;
              if ((uint ***)0xf < ppppuVar15[9]) {
                ppppuVar13 = (uint ****)*ppppuVar13;
              }
              if (&DAT_0000000f < ppuStack_18) {
                pppuStack_14 = (uint ***)((uint)ppuStack_18 | 0xf);
                if ((uint ****)0x7fffffff < pppuStack_14) {
                  pppuStack_14 = (uint ***)0x7fffffff;
                }
                ppppuVar16 = (uint ****)((int)pppuStack_14 + 1);
                if (ppppuVar16 < &DAT_00001000) {
                  if (ppppuVar16 == (uint ****)0x0) {
                    ppppuStack_d4 = (uint ****)0x0;
                  }
                  else {
                    uStack_d0 = CONCAT44(ppppuVar16,0x98880d);
                    ppppuStack_d4 = (uint ****)FUN_01674e20();
                  }
                }
                else {
                  ppppuVar15 = (uint ****)pppuStack_14 + 9;
                  if (ppppuVar15 <= ppppuVar16) {
                    ppppuVar15 = (uint ****)0xffffffff;
                  }
                  uStack_d0 = CONCAT44(ppppuVar15,0x9887ed);
                  ppppuVar16 = (uint ****)FUN_01674e20();
                  uVar7 = (undefined)uStack_8;
                  if (ppppuVar16 == (uint ****)0x0) goto LAB_00988a7d;
                  ppppuStack_d4 = (uint ****)((int)ppppuVar16 + 0x23U & 0xffffffe0);
                  ((uint *****)ppppuStack_d4)[-1] = ppppuVar16;
                }
                uStack_d0 = CONCAT44((undefined *)((int)ppuStack_18 + 1),ppppuVar13);
                pppuStack_d8 = (uint ***)0x988825;
                ppppuStack_38 = ppppuStack_d4;
                FUN_0170c6f0();
                pppuStack_24 = pppuStack_14;
              }
              else {
                ppppuStack_38 = (uint ****)*ppppuVar13;
                ppuStack_34 = (uint **)ppppuVar13[1];
                ppuStack_30 = (uint **)ppppuVar13[2];
                ppppuStack_2c = (uint ****)ppppuVar13[3];
                pppuStack_24 = (uint ***)&DAT_0000000f;
              }
              ppppuVar13 = ppppuStack_38;
              uStack_8._0_1_ = 0xf;
              if ((uint ***)pppuStack_20[-10] == (uint ***)0x0) {
                uStack_d0 = CONCAT44(0x988a97,(int)uStack_d0);
                ppuStack_28 = ppuStack_18;
                uVar10 = FUN_0054fda0();
                uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
                uStack_d0 = CONCAT44(uVar10,0x988aa1);
                    /* WARNING: Subroutine does not return */
                FUN_0054e5e0();
              }
              ppppuStack_38 = (uint ****)((uint)ppppuStack_38 & 0xffffff00);
              uStack_d0 = CONCAT44(pppuStack_24,ppuStack_18);
              pppuStack_e4 = pppuStack_20 + -8;
              ppuStack_28 = (uint **)0x0;
              pppuStack_24 = (uint ***)0xf;
              uStack_e8 = 0x98887a;
              ppppuStack_e0 = ppppuVar13;
              ppuStack_dc = ppuStack_34;
              pppuStack_d8 = (uint ***)ppuStack_30;
              ppppuStack_d4 = ppppuStack_2c;
              (**(code **)(((uint)pppuStack_20[-10] & 0xfffffffe) + 4))();
              uStack_8._0_1_ = 0xc;
            }
            pppuStack_20 = pppuStack_20 + 0x12;
            pppuVar20 = pppuVar20 + 0x12;
            ppuStack_18 = (uint **)pppuVar20;
          } while (pppuVar20 != (uint ***)ppuStack_1c);
        }
        uStack_d0 = CONCAT44(0x9889e4,(int)uStack_d0);
        FUN_0096c410();
        uStack_d0 = CONCAT44(0x9889ef,(int)uStack_d0);
        iVar9 = FUN_0167ec40();
        if (piStack_94 != (int *)0x0) {
          LOCK();
          piVar12 = piStack_94 + 1;
          iVar2 = *piVar12;
          iVar9 = *piVar12;
          *piVar12 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            uStack_d0 = CONCAT44(0x988a13,(int)uStack_d0);
            (**(code **)*piStack_94)();
            LOCK();
            piVar12 = piStack_94 + 2;
            iVar2 = *piVar12;
            iVar9 = *piVar12;
            *piVar12 = iVar2 + -1;
            UNLOCK();
            if (iVar2 + -1 == 0) {
              uStack_d0 = CONCAT44(0x988a27,(int)uStack_d0);
              iVar9 = (**(code **)(*piStack_94 + 4))();
            }
          }
        }
        goto LAB_0098849f;
      }
      pppuStack_14 = (uint ***)&uStack_d0;
      if (in_stack_00000028 != (int *)0x0) {
        LOCK();
        in_stack_00000028[1] = in_stack_00000028[1] + 1;
        UNLOCK();
      }
      uStack_d0 = CONCAT44(in_stack_00000028,in_stack_00000024);
      uStack_8._0_1_ = 9;
      pppuStack_d8 = (uint ***)0x0;
      ppppuStack_d4 = (uint ****)&DAT_0000000f;
      uStack_e8 = uStack_e8 & 0xffffff00;
      FUN_005542c0("Bad server response",0x13);
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[2] = param_2[2] + 1;
        UNLOCK();
      }
      uStack_8._0_1_ = 5;
      FUN_00988060(param_1,param_2);
    }
    else {
      uStack_d0 = CONCAT44(0x988302,(int)uStack_d0);
      uVar10 = FUN_016814a0();
      uStack_d0 = 0x2018bcaac;
      ppuStack_28 = (uint **)0x0;
      pppuStack_24 = (uint ***)0xf;
      ppppuStack_38 = (uint ****)((uint)ppppuStack_38 & 0xffffff00);
      ppppuStack_d4 = (uint ****)0x988325;
      FUN_005542c0();
      uStack_8._0_1_ = 6;
      ppppuStack_d4 = (uint ****)&ppppuStack_80;
      uStack_d0 = CONCAT44(&ppppuStack_38,"Bad server response");
      pppuStack_d8 = (uint ***)0x98833b;
      uVar11 = FUN_00558d90();
      pppuStack_14 = (uint ***)&uStack_d0;
      if (in_stack_00000028 != (int *)0x0) {
        LOCK();
        in_stack_00000028[1] = in_stack_00000028[1] + 1;
        UNLOCK();
      }
      uStack_d0 = CONCAT44(in_stack_00000028,in_stack_00000024);
      uStack_8._0_1_ = 8;
      FUN_00558c80(&uStack_e8,uVar11,uVar10);
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[2] = param_2[2] + 1;
        UNLOCK();
      }
      uStack_8._0_1_ = 7;
      FUN_00988060(param_1,param_2);
      uStack_d0 = CONCAT44(0x9883b5,(int)uStack_d0);
      FUN_005507b0();
      uStack_d0 = CONCAT44(0x9883bd,(int)uStack_d0);
      FUN_005507b0();
    }
    uStack_d0 = CONCAT44(0x988473,(int)uStack_d0);
    iVar9 = FUN_0167ec40();
  }
  uStack_88 = CONCAT44(uStack_88._4_4_,(uint *)uStack_88);
  if (piStack_94 != (int *)0x0) {
    LOCK();
    piVar12 = piStack_94 + 1;
    iVar2 = *piVar12;
    iVar9 = *piVar12;
    *piVar12 = iVar2 + -1;
    UNLOCK();
    uStack_88 = CONCAT44(uStack_88._4_4_,(uint *)uStack_88);
    if (iVar2 + -1 == 0) {
      uStack_d0 = CONCAT44(0x98848c,(int)uStack_d0);
      (**(code **)*piStack_94)();
      LOCK();
      piVar12 = piStack_94 + 2;
      iVar2 = *piVar12;
      iVar9 = *piVar12;
      *piVar12 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        uStack_d0 = CONCAT44(0x98849c,(int)uStack_d0);
        iVar9 = (**(code **)(*piStack_94 + 4))();
      }
    }
  }
LAB_0098849f:
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar12 = param_2 + 2;
    iVar2 = *piVar12;
    iVar9 = *piVar12;
    *piVar12 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      uStack_d0 = CONCAT44(0x9884b4,(int)uStack_d0);
      iVar9 = (**(code **)(*param_2 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    uVar18 = in_stack_00000020 + 1;
    uVar14 = param_3;
    if (0xfff < uVar18) {
      uVar14 = *(uint *)(param_3 - 4);
      uVar18 = in_stack_00000020 + 0x24;
      uVar7 = (undefined)uStack_8;
      if (0x1f < (param_3 - uVar14) - 4) {
LAB_00988a7d:
        uStack_8._0_1_ = uVar7;
        uStack_d0 = CONCAT44(0x988a82,(int)uStack_d0);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_d0 = CONCAT44(uVar18,uVar14);
    ppppuStack_d4 = (uint ****)0x988a33;
    iVar9 = FUN_01674ea0();
  }
  piVar12 = in_stack_00000028;
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000028 + 1;
    iVar2 = *piVar1;
    iVar9 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      uStack_d0 = CONCAT44(0x988a5e,(int)uStack_d0);
      iVar9 = (**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar12 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_d0 = CONCAT44(0x988a6d,(int)uStack_d0);
        iVar9 = (**(code **)(*piVar12 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar9;
}



/* FUNCTION 17895 ; VA 0x00988ac0 ; FUN_00988ac0 */

void __thiscall
FUN_00988ac0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 *param_5,uint param_6)

{
  char cVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  int iVar7;
  undefined4 *puVar8;
  uint uVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  bool bVar12;
  int aiStack_38 [5];
  uint uStack_24;
  undefined auStack_20 [4];
  undefined auStack_1c [4];
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0958;
  pvStack_10 = ExceptionList;
  if ((char)param_6 == '\0') {
LAB_00988af3:
    param_6 = param_6 & 0xffffff;
  }
  else {
    param_6 = CONCAT13(1,(undefined3)param_6);
    if (DAT_01ee2fc4 == '\0') goto LAB_00988af3;
  }
  iStack_14 = param_1 + 0x334;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_0096d790(&param_2);
  puVar11 = param_5;
  puVar10 = param_4;
  uVar2 = FUN_005f3cd0(aiStack_38,param_4,param_5);
  uStack_8 = 0;
  piVar3 = (int *)FUN_0065ad50(auStack_1c,uVar2);
  piVar4 = (int *)FUN_0096d790(&param_2);
  iVar6 = *piVar3;
  uStack_8 = 0xffffffff;
  param_5 = (undefined4 *)*piVar4;
  if (0xf < uStack_24) {
    uVar9 = uStack_24 + 1;
    iVar7 = aiStack_38[0];
    if (0xfff < uVar9) {
      iVar7 = *(int *)(aiStack_38[0] + -4);
      uVar9 = uStack_24 + 0x24;
      if (0x1f < (aiStack_38[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar9);
  }
  if ((undefined4 *)iVar6 != param_5) {
    if ((DAT_01d5a4c0 != '\0') && (DAT_01d5a4c8 == '\0')) {
      ExceptionList = pvStack_10;
      return;
    }
    if (param_6._3_1_ == '\0') {
      ExceptionList = pvStack_10;
      return;
    }
    FUN_0086f2f0(1,"Players::onRemoteSysStats disconnect not in the clist");
    goto LAB_00988d4a;
  }
  if (DAT_01ee4216 != '\0') {
    puVar5 = puVar11;
    if (0xf < (uint)puVar11[5]) {
      puVar5 = (undefined4 *)*puVar11;
    }
    puVar8 = puVar10;
    if (0xf < (uint)puVar10[5]) {
      puVar8 = (undefined4 *)*puVar10;
    }
    uVar2 = FUN_01675640(aiStack_38,"%lld | %s | %s",param_2,param_3,puVar8,puVar5);
    uStack_8 = 1;
    FUN_01677760(DAT_01ee4216,"onRemoteSysStats: %s",uVar2);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_24) {
      uVar9 = uStack_24 + 1;
      iVar6 = aiStack_38[0];
      if (0xfff < uVar9) {
        iVar6 = *(int *)(aiStack_38[0] + -4);
        uVar9 = uStack_24 + 0x24;
        if (0x1f < (aiStack_38[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar6,uVar9);
    }
  }
  FUN_0096d790(&param_2);
  uVar2 = FUN_005f3cd0(aiStack_38,puVar10,puVar11);
  uStack_8 = 2;
  FUN_0055b250(auStack_20,0,uVar2,param_6);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_24) {
    uVar9 = uStack_24 + 1;
    iVar6 = aiStack_38[0];
    if (0xfff < uVar9) {
      iVar6 = *(int *)(aiStack_38[0] + -4);
      uVar9 = uStack_24 + 0x24;
      if (0x1f < (aiStack_38[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar9);
  }
  iVar6 = iStack_18;
  cVar1 = FUN_0064a9e0(iStack_18,1);
  if (cVar1 == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  iVar6 = FUN_008f7870(iVar6);
  if (iVar6 == 0) {
LAB_00988cfb:
    if (DAT_01ee4216 != '\0') {
      if (0xf < (uint)puVar11[5]) {
        puVar11 = (undefined4 *)*puVar11;
      }
      if (0xf < (uint)puVar10[5]) {
        puVar10 = (undefined4 *)*puVar10;
      }
      FUN_01677520(DAT_01ee4216,"Sending display stats: %lld | %s | %s",param_2,param_3,puVar10,
                   puVar11);
    }
  }
  else {
    piVar3 = *(int **)(iVar6 + 0x43c);
    bVar12 = piVar3[1] - (int)piVar3 < 0;
    if (((int *)piVar3[1] == piVar3 || bVar12) && ((bVar12 || ((int *)*piVar3 == piVar3))))
    goto LAB_00988cfb;
  }
  if (DAT_01d5a4c0 != '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  if (param_6._3_1_ == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  FUN_0086f2f0(1,"Players::onRemoteSysStats disconnect");
LAB_00988d4a:
  FUN_00978d80(param_2,param_3,0x10c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17896 ; VA 0x00988d80 ; FUN_00988d80 */

int __thiscall
FUN_00988d80(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  uint uVar8;
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined auStack_34 [4];
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0980;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  FUN_005542c0("AntiCheat-AfterJoin",0x13);
  uStack_8 = 0;
  FUN_008783f0(auStack_4c,1,0);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_38) {
    uVar8 = uStack_38 + 1;
    uVar7 = auStack_4c[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_4c[0] - 4);
      uVar8 = uStack_38 + 0x24;
      if (0x1f < (auStack_4c[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  if (param_1 != 0) {
    iVar5 = *(int *)(param_1 + 0x34);
    if ((iVar5 != 0) && (param_1 = iVar5, *(int *)(iVar5 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if (((param_1 != 0) &&
        (iVar5 = *(int *)(param_1 + 0xc), iVar4 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da))) && (iVar5 = FUN_00562e40(), iVar5 != 0)) {
      puVar6 = (undefined4 *)FUN_00644d90(auStack_34,param_2,param_3);
      uVar7 = 1;
      piStack_2c = (int *)*puVar6;
      goto LAB_00988e99;
    }
  }
  piStack_20 = (int *)0x0;
  puVar6 = &uStack_24;
  uVar7 = 2;
  piStack_2c = (int *)0x0;
LAB_00988e99:
  piVar3 = (int *)puVar6[1];
  piStack_18 = piStack_2c;
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar2 = piStack_20;
  uStack_8 = 1;
  piStack_28 = piVar3;
  if (((uVar7 & 2) != 0) &&
     (uStack_14 = uVar7 & 0xfffffffd, uVar7 = uStack_14, piStack_20 != (int *)0x0)) {
    LOCK();
    iVar5 = piStack_20[1] + -1;
    piStack_20[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      uVar7 = uStack_14;
      if (iVar5 == 0) {
        (**(code **)(*piVar2 + 4))();
        uVar7 = uStack_14;
      }
    }
  }
  if (((uVar7 & 1) != 0) && (piStack_30 != (int *)0x0)) {
    LOCK();
    iVar5 = piStack_30[1] + -1;
    piStack_30[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      iVar5 = piStack_30[2] + -1;
      piStack_30[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  if (piStack_18 == (int *)0x0) {
    iVar5 = FUN_00988ac0(param_2,param_3,param_4,param_5,param_6,1);
  }
  else {
    iVar5 = (**(code **)(*piStack_18 + 0x290))("OldStats",0xf,1,"OldStats",0);
  }
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar2 = piVar3 + 1;
    iVar4 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar5 = (**(code **)*piVar3)();
      LOCK();
      piVar2 = piVar3 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar5 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 17897 ; VA 0x00988f90 ; FUN_00988f90 */

int * __thiscall FUN_00988f90(int param_1,int *param_2,int param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 == 0) {
    *param_2 = 0;
    param_2[1] = 0;
    if (param_4 != (int *)0x0) {
      LOCK();
      iVar3 = param_4[1] + -1;
      param_4[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_4)();
        LOCK();
        piVar4 = param_4 + 2;
        iVar3 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*param_4 + 4))();
          return param_2;
        }
      }
    }
  }
  else {
    piVar4 = *(int **)(param_1 + 0xbc);
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = *(int **)(param_1 + 0xbc);
    }
    for (piVar1 = (int *)**(undefined4 **)(param_1 + 0xb8);
        piVar1 != (int *)(*(undefined4 **)(param_1 + 0xb8))[1]; piVar1 = piVar1 + 2) {
      iVar3 = *piVar1;
      if (*(int *)(iVar3 + 100) == param_3) {
        iVar2 = piVar1[1];
        *param_2 = 0;
        param_2[1] = 0;
        if (iVar2 != 0) {
          LOCK();
          *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
          UNLOCK();
          iVar3 = *piVar1;
          iVar2 = piVar1[1];
        }
        *param_2 = iVar3;
        param_2[1] = iVar2;
        if (piVar4 != (int *)0x0) {
          LOCK();
          iVar3 = piVar4[1] + -1;
          piVar4[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piVar4)();
            LOCK();
            iVar3 = piVar4[2] + -1;
            piVar4[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar4 + 4))();
            }
          }
        }
        if (param_4 == (int *)0x0) {
          return param_2;
        }
        LOCK();
        iVar3 = param_4[1] + -1;
        param_4[1] = iVar3;
        UNLOCK();
        if (iVar3 != 0) {
          return param_2;
        }
        (**(code **)*param_4)();
        LOCK();
        piVar4 = param_4 + 2;
        iVar3 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar3 != 1) {
          return param_2;
        }
        (**(code **)(*param_4 + 4))();
        return param_2;
      }
    }
    *param_2 = 0;
    param_2[1] = 0;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar3 = piVar4[1] + -1;
      piVar4[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar3 = piVar4[2] + -1;
        piVar4[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (param_4 != (int *)0x0) {
      LOCK();
      iVar3 = param_4[1] + -1;
      param_4[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_4)();
        LOCK();
        piVar4 = param_4 + 2;
        iVar3 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*param_4 + 4))();
        }
      }
    }
  }
  return param_2;
}



/* FUNCTION 17898 ; VA 0x00989100 ; FUN_00989100 */

void __thiscall FUN_00989100(undefined4 param_1,undefined *param_2,int *param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  int *piVar6;
  code *apcStack_7c [3];
  undefined4 uStack_70;
  undefined8 uStack_6c;
  code ***pppcStack_64;
  undefined auStack_58 [24];
  code ***pppcStack_40;
  int iStack_3c;
  undefined8 uStack_38;
  undefined8 uStack_30;
  undefined auStack_28 [8];
  code ***pppcStack_20;
  int iStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d09b0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 == &DAT_021210d8) {
    uStack_6c._4_4_ = (code ****)0x989130;
    ExceptionList = &pvStack_10;
    pppcStack_64 = (code ***)param_1;
    iVar3 = FUN_005eef10();
    if (iVar3 == 0) {
      uStack_6c._4_4_ = (code ****)0x989146;
      pppcStack_64 = (code ***)param_1;
      iVar3 = FUN_0064e920();
      if (iVar3 == 0) goto LAB_009891a6;
      cVar2 = *(int *)(iVar3 + 0x124) == 2;
    }
    else {
      pppcStack_64 = (code ***)0x98913e;
      cVar2 = FUN_0068ba60();
    }
    if (cVar2 != '\0') {
      if (0xcf < (param_3[1] - *param_3) - 0xd0U) {
        ExceptionList = pvStack_10;
        return;
      }
      if (*(char *)(*(int *)*param_3 + 0x21) == '\0') {
        ExceptionList = pvStack_10;
        return;
      }
      pppcStack_64 = (code ***)0x989186;
      uStack_6c = FUN_00563790();
      pppcStack_64 = (code ***)0x10e;
      uStack_70 = 0x989194;
      FUN_00978d80();
      ExceptionList = pvStack_10;
      return;
    }
  }
LAB_009891a6:
  if (param_2 == &DAT_02121118) {
    uStack_6c._4_4_ = (code ****)0x9891b8;
    pppcStack_64 = (code ***)param_1;
    iVar3 = FUN_005eef10();
    if (iVar3 == 0) {
      uStack_6c._4_4_ = (code ****)0x9891ce;
      pppcStack_64 = (code ***)param_1;
      iVar3 = FUN_0064e920();
      if (iVar3 == 0) goto LAB_00989240;
      cVar2 = *(int *)(iVar3 + 0x124) == 2;
    }
    else {
      pppcStack_64 = (code ***)0x9891c6;
      cVar2 = FUN_0068ba60();
    }
    if (cVar2 != '\0') {
      uStack_6c._4_4_ = (code ****)0x9891e9;
      pppcStack_64 = (code ***)param_1;
      iVar3 = FUN_008f7870();
      if (iVar3 == 0) {
        ExceptionList = pvStack_10;
        return;
      }
      pppcStack_64 = (code ***)0x1;
      FUN_00984160(apcStack_7c,apcStack_7c,2);
      apcStack_7c[0] = FUN_00972a50;
      FUN_0090ca30();
      ExceptionList = pvStack_10;
      return;
    }
  }
LAB_00989240:
  if (param_2 == &DAT_02121158) {
    uStack_6c._4_4_ = (code ****)0x98924e;
    pppcStack_64 = (code ***)param_1;
    iVar3 = FUN_005eef10();
    if (iVar3 == 0) {
      uStack_6c._4_4_ = (code ****)0x989264;
      pppcStack_64 = (code ***)param_1;
      iVar3 = FUN_0064e920();
      if (iVar3 == 0) goto LAB_00989292;
      cVar2 = *(int *)(iVar3 + 0x124) == 2;
    }
    else {
      pppcStack_64 = (code ***)0x98925c;
      cVar2 = FUN_0068ba60();
    }
    if (cVar2 != '\0') {
      uStack_6c._4_4_ = (code ****)0x98927f;
      pppcStack_64 = (code ***)param_1;
      iVar3 = FUN_008f7870();
      if (iVar3 == 0) {
        ExceptionList = pvStack_10;
        return;
      }
      uStack_14 = CONCAT31(uStack_14._1_3_,1);
      goto LAB_009892ea;
    }
  }
LAB_00989292:
  if (param_2 == &DAT_02121198) {
    uStack_6c._4_4_ = (code ****)0x9892a4;
    pppcStack_64 = (code ***)param_1;
    iVar3 = FUN_005eef10();
    if (iVar3 == 0) {
      uStack_6c._4_4_ = (code ****)0x9892ba;
      pppcStack_64 = (code ***)param_1;
      iVar3 = FUN_0064e920();
      if (iVar3 == 0) goto LAB_00989350;
      cVar2 = *(int *)(iVar3 + 0x124) == 2;
    }
    else {
      pppcStack_64 = (code ***)0x9892b2;
      cVar2 = FUN_0068ba60();
    }
    if (cVar2 != '\0') {
      uStack_6c._4_4_ = (code ****)0x9892d9;
      pppcStack_64 = (code ***)param_1;
      iVar3 = FUN_008f7870();
      if (iVar3 == 0) {
        ExceptionList = pvStack_10;
        return;
      }
      uStack_14 = uStack_14 & 0xffffff00;
LAB_009892ea:
      pppcStack_64 = (code ***)0x1;
      iStack_18 = *param_4;
      uStack_38 = CONCAT44(iStack_18,param_1);
      uStack_30 = CONCAT44(uStack_30._4_4_,uStack_14);
      pppcStack_40 = (code ***)FUN_00972840;
      iStack_3c = 0;
      iStack_1c = param_1;
      FUN_00960c30(FUN_00972840,0,param_1,iStack_18,uStack_30,0);
      FUN_0090ca30();
      ExceptionList = pvStack_10;
      return;
    }
  }
LAB_00989350:
  if (param_2 == &DAT_021211d8) {
    uStack_6c._4_4_ = (code ****)0x989362;
    pppcStack_64 = (code ***)param_1;
    cVar2 = FUN_00983210();
    if (cVar2 != '\0') {
      pppcStack_64 = (code ***)0x1;
      uStack_6c._0_4_ = (undefined *)0x989375;
      uStack_6c._4_4_ = (code ****)param_1;
      cVar2 = FUN_0097c970();
      if (cVar2 != '\0') {
        if ((param_3[1] - *param_3) / 0xd0 != 2) {
          ExceptionList = pvStack_10;
          return;
        }
        iVar3 = *(int *)*param_3;
        pppcStack_64 = (code ***)0x9893ab;
        iVar4 = thunk_FUN_0086f380();
        if (iVar3 != iVar4) {
          ExceptionList = pvStack_10;
          return;
        }
        iVar3 = *(int *)(*param_3 + 0xd0);
        pppcStack_64 = (code ***)0x9893c0;
        iVar4 = FUN_0088cb40();
        if (iVar3 != iVar4) {
          ExceptionList = pvStack_10;
          return;
        }
        pppcStack_64 = (code ***)0x9893cf;
        puVar5 = (undefined4 *)FUN_0086eb80();
        uVar1 = *puVar5;
        pppcStack_64 = (code ***)0x9893de;
        pppcStack_64 = (code ***)FUN_0055d610();
        uStack_6c._4_4_ = (code ****)0x9893e7;
        FUN_0054ef60();
        pppcStack_64 = (code ***)0x6;
        uStack_6c._4_4_ = &pppcStack_40;
        uStack_8 = 0;
        uStack_70 = 0x9893fa;
        uStack_6c._0_4_ = (undefined *)uVar1;
        FUN_0086ed30();
        pppcStack_64 = (code ***)0x989405;
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  if (param_2 == &DAT_02121218) {
    uStack_6c._4_4_ = (code ****)0x989429;
    pppcStack_64 = (code ***)param_1;
    cVar2 = FUN_00983210();
    if (cVar2 != '\0') {
      pppcStack_64 = (code ***)0x1;
      uStack_6c._0_4_ = (undefined *)0x98943c;
      uStack_6c._4_4_ = (code ****)param_1;
      cVar2 = FUN_00971ce0();
      if (cVar2 != '\0') {
        if ((param_3[1] - *param_3) / 0xd0 != 2) {
          ExceptionList = pvStack_10;
          return;
        }
        iVar3 = *(int *)*param_3;
        pppcStack_64 = (code ***)0x989472;
        iVar4 = FUN_0088cb40();
        if (iVar3 != iVar4) {
          ExceptionList = pvStack_10;
          return;
        }
        iVar3 = *(int *)(*param_3 + 0xd0);
        pppcStack_64 = (code ***)0x98948a;
        iVar4 = FUN_0088cb40();
        if (iVar3 != iVar4) {
          ExceptionList = pvStack_10;
          return;
        }
        pppcStack_64 = (code ***)0x9894a2;
        puVar5 = (undefined4 *)FUN_0055d610();
        pppcStack_64 = (code ***)0x1936498;
        uStack_6c._4_4_ = (code ****)0x9894b1;
        uStack_6c._4_4_ = (code ****)FUN_0055d610();
        uStack_6c._0_4_ = auStack_58;
        uStack_70 = 0x9894bb;
        FUN_00558ce0();
        uStack_8 = 1;
        pppcStack_64 = (code ***)puVar5[4];
        if (0xf < (uint)puVar5[5]) {
          puVar5 = (undefined4 *)*puVar5;
        }
        uStack_6c._0_4_ = (undefined *)0x9894dc;
        uStack_6c._4_4_ = (code ****)puVar5;
        piVar6 = (int *)FUN_00554150();
        pppcStack_40 = (code ***)*piVar6;
        iStack_3c = piVar6[1];
        iStack_18 = piVar6[2];
        uStack_14 = piVar6[3];
        uStack_38 = *(undefined8 *)(piVar6 + 2);
        uStack_30 = *(undefined8 *)(piVar6 + 4);
        piVar6[4] = 0;
        piVar6[5] = 0xf;
        *(undefined *)piVar6 = 0;
        uStack_8._0_1_ = 3;
        pppcStack_64 = (code ***)0x98950e;
        pppcStack_20 = pppcStack_40;
        iStack_1c = iStack_3c;
        FUN_005507b0();
        pppcStack_64 = (code ***)&pppcStack_40;
        if (0xf < uStack_30._4_4_) {
          pppcStack_64 = pppcStack_20;
        }
        uStack_6c._4_4_ = (code ****)0x989522;
        FUN_0054eff0();
        pppcStack_64 = (code ***)auStack_28;
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        uStack_6c._4_4_ = (code ****)0x0;
        uStack_6c._0_4_ = (undefined *)0x989533;
        FUN_0098c2c0();
        pppcStack_64 = (code ***)0x98953b;
        FUN_005507b0();
        pppcStack_64 = (code ***)0x989543;
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  pppcStack_64 = (code ***)param_4;
  uStack_6c._4_4_ = (code ****)param_3;
  uStack_6c._0_4_ = param_2;
  uStack_70 = 0x989563;
  FUN_009cba80();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17899 ; VA 0x00989580 ; FUN_00989580 */

undefined4 FUN_00989580(int *param_1,int *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 ******ppppppuVar4;
  undefined4 *puVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  uint in_stack_00000020;
  int iStack_190;
  undefined **appuStack_18c [2];
  undefined8 uStack_184;
  undefined *****apppppuStack_17c [6];
  undefined *****pppppuStack_164;
  undefined4 uStack_160;
  undefined4 uStack_15c;
  undefined4 *puStack_158;
  undefined4 *puStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined4 *puStack_148;
  undefined4 *puStack_144;
  int iStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined4 uStack_128;
  undefined **ppuStack_124;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 *****apppppuStack_d4 [5];
  uint uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 *****apppppuStack_ac [5];
  uint uStack_98;
  undefined4 *****apppppuStack_94 [5];
  uint uStack_80;
  undefined4 *****apppppuStack_7c [5];
  uint uStack_68;
  undefined4 *apuStack_64 [2];
  undefined4 *****apppppuStack_5c [4];
  int iStack_4c;
  uint uStack_48;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined auStack_2c [4];
  uint *puStack_28;
  char acStack_24 [4];
  undefined auStack_20 [4];
  undefined auStack_1c [4];
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d0a3e;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffd30;
  uStack_18 = 0;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  FUN_0096b1b0();
  puStack_28 = (uint *)(param_1 + 5);
  uStack_8._0_1_ = 3;
  acStack_24[0] = '\0';
  FUN_00587410();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (param_1[4] != 0) {
    if ((param_1 == (int *)0x0) || ((int *)*param_1 == (int *)0x0)) {
      iVar3 = 0;
    }
    else {
      iVar3 = *(int *)*param_1;
    }
    puVar5 = *(undefined4 **)(*(int *)(iVar3 + 4) + (*(int *)(iVar3 + 8) - 1U & param_1[3]) * 4);
    uStack_dc = *puVar5;
    uStack_d8 = puVar5[1];
    ppppppuVar4 = (undefined4 ******)(puVar5 + 2);
    if (apppppuStack_d4 != ppppppuVar4) {
      if (0xf < (uint)puVar5[7]) {
        ppppppuVar4 = (undefined4 ******)*ppppppuVar4;
      }
      FUN_005542c0(ppppppuVar4,puVar5[6]);
    }
    uStack_bc = puVar5[8];
    uStack_b8 = puVar5[9];
    uStack_b4 = puVar5[10];
    uStack_b0 = puVar5[0xb];
    ppppppuVar4 = (undefined4 ******)(puVar5 + 0xc);
    if (apppppuStack_ac != ppppppuVar4) {
      if (0xf < (uint)puVar5[0x11]) {
        ppppppuVar4 = (undefined4 ******)*ppppppuVar4;
      }
      FUN_005542c0(ppppppuVar4,puVar5[0x10]);
    }
    ppppppuVar4 = (undefined4 ******)(puVar5 + 0x12);
    if (apppppuStack_94 != ppppppuVar4) {
      if (0xf < (uint)puVar5[0x17]) {
        ppppppuVar4 = (undefined4 ******)*ppppppuVar4;
      }
      FUN_005542c0(ppppppuVar4,puVar5[0x16]);
    }
    ppppppuVar4 = (undefined4 ******)(puVar5 + 0x18);
    if (apppppuStack_7c != ppppppuVar4) {
      if (0xf < (uint)puVar5[0x1d]) {
        ppppppuVar4 = (undefined4 ******)*ppppppuVar4;
      }
      FUN_005542c0(ppppppuVar4,puVar5[0x1c]);
    }
    if (apuStack_64 != (undefined4 **)(puVar5 + 0x1e)) {
      puVar1 = (undefined4 *)puVar5[0x1e];
      FUN_00963220(*puVar1,puVar1);
    }
    ppppppuVar4 = (undefined4 ******)(puVar5 + 0x20);
    if (apppppuStack_5c != ppppppuVar4) {
      if (0xf < (uint)puVar5[0x25]) {
        ppppppuVar4 = (undefined4 ******)*ppppppuVar4;
      }
      FUN_005542c0(ppppppuVar4,puVar5[0x24]);
    }
    uStack_8._0_1_ = 6;
    if (acStack_24[0] != '\0') {
      LOCK();
      uVar7 = *puStack_28;
      *puStack_28 = *puStack_28 + 0x80000000;
      UNLOCK();
      if (((uVar7 & 0x40000000) == 0) && (-0x80000000 < (int)uVar7)) {
        LOCK();
        uVar7 = *puStack_28;
        *puStack_28 = *puStack_28 | 0x40000000;
        UNLOCK();
        if ((uVar7 >> 0x1e & 1) == 0) {
          uVar2 = FUN_00554e40();
          SetEvent(uVar2);
        }
      }
    }
    appuStack_18c[0] = &PTR_018bf148;
    apppppuStack_17c[0] = (undefined *****)&DAT_018bf150;
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    uStack_18 = 1;
    ppuStack_124 = std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
    uStack_128 = 0x50;
    uStack_184 = 0;
    FUN_00554f20(apppppuStack_17c + 2,0);
    *(undefined ***)((int)apppppuStack_17c + (int)apppppuStack_17c[0][1]) =
         std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
    *(undefined *****)((int)apppppuStack_17c + (int)(apppppuStack_17c[0][1] + -1)) =
         apppppuStack_17c[0][1] + -2;
    *(undefined ***)((int)appuStack_18c + (int)appuStack_18c[0][1]) =
         std::basic_iostream<char,struct_std::char_traits<char>_>::vftable;
    *(undefined **)((int)&iStack_190 + (int)appuStack_18c[0][1]) = appuStack_18c[0][1] + -0x20;
    uStack_8 = 0xc;
    *(undefined ***)((int)appuStack_18c + (int)appuStack_18c[0][1]) =
         std::basic_stringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)((int)&iStack_190 + (int)appuStack_18c[0][1]) = appuStack_18c[0][1] + -0x68;
    apppppuStack_17c[2] =
         (undefined *****)std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
    iStack_140 = FUN_01674e20(8);
    if (iStack_140 == 0) {
      iStack_140 = 0;
    }
    else {
      uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
      uVar2 = FUN_016de181(1);
      *(undefined4 *)(iStack_140 + 4) = uVar2;
    }
    apppppuStack_17c[5] = (undefined *****)(apppppuStack_17c + 3);
    pppppuStack_164 = (undefined *****)(apppppuStack_17c + 4);
    puStack_158 = &uStack_160;
    puStack_154 = &uStack_15c;
    puStack_148 = &uStack_150;
    puStack_144 = &uStack_14c;
    apppppuStack_17c[4] = (undefined *****)0x0;
    uStack_15c = 0;
    uStack_14c = 0;
    apppppuStack_17c[3] = (undefined *****)0x0;
    uStack_160 = 0;
    uStack_150 = 0;
    apppppuStack_17c[2] =
         (undefined *****)
         std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    uStack_13c = 0;
    uStack_138 = 0;
    uStack_8._0_1_ = 0xe;
    FUN_01660050();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
    FUN_016605d0(auStack_1c,"report");
    FUN_01660540(auStack_20,"userID");
    FUN_016640c0(uStack_bc,uStack_b8);
    FUN_01660540(auStack_20,"placeID");
    FUN_016640c0(uStack_dc,uStack_d8);
    FUN_01660540(auStack_20,"gameJobID");
    ppppppuVar4 = apppppuStack_d4;
    if (0xf < uStack_c0) {
      ppppppuVar4 = (undefined4 ******)apppppuStack_d4[0];
    }
    FUN_01664080(ppppppuVar4);
    FUN_01660540(auStack_20,"userSystemAddress");
    ppppppuVar4 = apppppuStack_7c;
    if (0xf < uStack_68) {
      ppppppuVar4 = (undefined4 ******)apppppuStack_7c[0];
    }
    FUN_01664080(ppppppuVar4);
    FUN_016605d0(auStack_20,"userAgent");
    FUN_016644e0(&uStack_18);
    ppppppuVar4 = apppppuStack_94;
    if (0xf < uStack_80) {
      ppppppuVar4 = (undefined4 ******)apppppuStack_94[0];
    }
    FUN_01664000(ppppppuVar4);
    FUN_016605d0(auStack_20,"comment");
    FUN_016644e0(&uStack_18);
    ppppppuVar4 = apppppuStack_ac;
    if (0xf < uStack_98) {
      ppppppuVar4 = (undefined4 ******)apppppuStack_ac[0];
    }
    FUN_01664000(ppppppuVar4);
    FUN_016605d0(auStack_2c,"messages");
    for (puVar5 = (undefined4 *)*apuStack_64[0]; puVar5 != apuStack_64[0];
        puVar5 = (undefined4 *)*puVar5) {
      FUN_016605d0(&uStack_18,"message");
      FUN_016644e0(auStack_20);
      piVar6 = puVar5 + 4;
      if (0xf < (uint)puVar5[9]) {
        piVar6 = (int *)*piVar6;
      }
      FUN_01664000(piVar6);
      FUN_01660540(&iStack_190,"userID");
      FUN_016640c0(puVar5[2],puVar5[3]);
      FUN_01660540(acStack_24,&DAT_018d2348);
      piVar6 = puVar5 + 10;
      if (0xf < (uint)puVar5[0xf]) {
        piVar6 = (int *)*piVar6;
      }
      FUN_01664080(piVar6);
    }
    if ((DAT_01d646c8 != '\0') && (iStack_4c != 0)) {
      FUN_016605d0(&uStack_18,"screenshotIDs");
      FUN_016605d0(auStack_20,&DAT_018d2348);
      FUN_016644e0(acStack_24);
      ppppppuVar4 = apppppuStack_5c;
      if (0xf < uStack_48) {
        ppppppuVar4 = (undefined4 ******)apppppuStack_5c[0];
      }
      FUN_01664000(ppppppuVar4);
    }
    FUN_01663e20(apppppuStack_17c,&DAT_018c3720,1,0);
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    uStack_8._0_1_ = 0x10;
    FUN_014cc090(&param_3,7,0);
    uStack_8._0_1_ = 0x11;
    FUN_014cdc70(appuStack_18c,&DAT_01d79ff8,0,auStack_44,0,0);
    puVar5 = &param_3;
    if (0xf < in_stack_00000020) {
      puVar5 = param_3;
    }
    FUN_0086f2f0(4,"Posted abuse report to %s",puVar5);
    FUN_0086edd0(1,"Posted abuse report",6);
    FUN_0056db40();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
    if (0xf < uStack_30) {
      uVar8 = uStack_30 + 1;
      uVar7 = auStack_44[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_44[0] - 4);
        uVar8 = uStack_30 + 0x24;
        if (0x1f < (auStack_44[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    FUN_016600b0();
    FUN_005705c0();
    FUN_0096ce60();
    uVar2 = FUN_00989cf5();
    return uVar2;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (acStack_24[0] != '\0') {
    LOCK();
    uVar7 = *puStack_28;
    *puStack_28 = *puStack_28 + 0x80000000;
    UNLOCK();
    if (((uVar7 & 0x40000000) == 0) && (-0x80000000 < (int)uVar7)) {
      LOCK();
      uVar7 = *puStack_28;
      *puStack_28 = *puStack_28 | 0x40000000;
      UNLOCK();
      if ((uVar7 >> 0x1e & 1) == 0) {
        uVar2 = FUN_00554e40();
        SetEvent(uVar2);
      }
    }
  }
  FUN_0096ce60();
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar3 = param_2[1] + -1;
    param_2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar6 = param_2 + 2;
      iVar3 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000020) {
    uVar7 = in_stack_00000020 + 1;
    puVar5 = param_3;
    if (0xfff < uVar7) {
      puVar5 = (undefined4 *)param_3[-1];
      uVar7 = in_stack_00000020 + 0x24;
      if (0x1f < (uint)((int)param_3 + (-4 - (int)puVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar5,uVar7);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 17900 ; VA 0x00989caa ; Catch@00989caa */

undefined * Catch_00989caa(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int unaff_EBP;
  
  piVar1 = *(int **)(unaff_EBP + -400);
  uVar2 = (**(code **)(*piVar1 + 4))();
  iVar3 = unaff_EBP + 0x10;
  if (0xf < *(uint *)(unaff_EBP + 0x24)) {
    iVar3 = *(int *)(unaff_EBP + 0x10);
  }
  FUN_0086f2f0(4,"Unable to post abuse report to %s. %s",iVar3,uVar2);
  uVar2 = (**(code **)(*piVar1 + 4))();
  FUN_0086f2f0(2,"Unable to post abuse report. %s",uVar2);
  return &DAT_00989cf0;
}



/* FUNCTION 17901 ; VA 0x00989cf5 ; FUN_00989cf5 */

undefined4 FUN_00989cf5(void)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  uint *puVar5;
  undefined4 uVar6;
  int iVar7;
  uint uVar8;
  int unaff_EBX;
  int unaff_EBP;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  *(int *)(unaff_EBP + -0x24) = *(int *)(unaff_EBP + 8) + 0x14;
  *(undefined *)(unaff_EBP + -0x20) = 0;
  FUN_00587410();
  iVar4 = *(int *)(unaff_EBP + 8);
  FUN_0096ce60();
  piVar1 = (int *)(iVar4 + 0x10);
  *piVar1 = *piVar1 + -1;
  if (*piVar1 == 0) {
    *(undefined4 *)(iVar4 + 0xc) = 0;
  }
  else {
    *(int *)(iVar4 + 0xc) = *(int *)(iVar4 + 0xc) + 1;
  }
  *(undefined *)(unaff_EBP + -4) = 0x13;
  if (*(char *)(unaff_EBP + -0x20) != '\0') {
    puVar5 = *(uint **)(unaff_EBP + -0x24);
    LOCK();
    uVar3 = *puVar5;
    *puVar5 = *puVar5 + unaff_EBX;
    UNLOCK();
    if (((uVar3 & 0x40000000) == 0) && (-0x80000000 < (int)uVar3)) {
      LOCK();
      uVar3 = *puVar5;
      *puVar5 = *puVar5 | 0x40000000;
      UNLOCK();
      if ((uVar3 >> 0x1e & 1) == 0) {
        uVar6 = FUN_00554e40();
        SetEvent(uVar6);
      }
    }
  }
  piVar1 = *(int **)(unaff_EBP + 0xc);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(unaff_EBP + 0x24);
  if (0xf < uVar3) {
    iVar4 = *(int *)(unaff_EBP + 0x10);
    uVar8 = uVar3 + 1;
    iVar7 = iVar4;
    if (0xfff < uVar8) {
      iVar7 = *(int *)(iVar4 + -4);
      uVar8 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar8);
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return 1;
}



/* FUNCTION 17902 ; VA 0x00989df0 ; FUN_00989df0 */

void __thiscall FUN_00989df0(int param_1,undefined4 param_2)

{
  char cVar1;
  
  if ((*(int *)(param_1 + 0xf4) != 0) && (cVar1 = FUN_009281e0(), cVar1 != '\0')) {
    return;
  }
  FUN_005e6780(param_2);
  FUN_00989e30(param_2);
  return;
}



/* FUNCTION 17903 ; VA 0x00989e30 ; FUN_00989e30 */

void __thiscall FUN_00989e30(int param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 in_stack_ffffffc0;
  undefined4 in_stack_ffffffc4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0a70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(param_2 + 0x30) == 0) &&
     (ExceptionList = &pvStack_10, *(int *)(param_2 + 0x34) != 0)) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_2 + 0x40) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_2 + 0x40) + 4);
      ExceptionList = &pvStack_10;
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_8 = 0;
    FUN_0054ef60(param_2 + 0x18);
    uStack_8 = 0xffffffff;
    FUN_00688d70(in_stack_ffffffc0,in_stack_ffffffc4);
  }
  if (*(int *)(param_1 + 0xf4) != 0) {
    switch(*(undefined4 *)(param_2 + 0x30)) {
    case 0:
      uStack_8 = 1;
      iVar4 = param_2 + 0x18;
      uVar3 = 0x989efc;
      FUN_0054ef60(iVar4);
      FUN_00557fc0(param_2 + 0x34);
      uVar2 = 0;
      break;
    case 1:
      uStack_8 = 2;
      iVar4 = param_2 + 0x18;
      uVar3 = 0x989f5b;
      FUN_0054ef60(iVar4);
      FUN_00557fc0(param_2 + 0x34);
      uVar2 = 1;
      break;
    case 2:
      FUN_00557fc0(param_2 + 0x3c);
      uStack_8 = 3;
      iVar4 = param_2 + 0x18;
      uVar3 = 0x989f93;
      FUN_0054ef60(iVar4);
      FUN_00557fc0(param_2 + 0x34);
      uVar2 = 2;
      break;
    case 3:
      FUN_0054ef60(param_2 + 0x18);
      FUN_006ecaa0();
    default:
      ExceptionList = pvStack_10;
      return;
    }
    uStack_8 = 0xffffffff;
    FUN_0096ee10(uVar2,uVar3,iVar4,in_stack_ffffffc0,in_stack_ffffffc4);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17904 ; VA 0x00989f31 ; caseD_1 */

void switchD_00989ecb::caseD_1(void)

{
  int unaff_EBP;
  int unaff_EDI;
  undefined4 uVar1;
  int iVar2;
  undefined4 uStack_8;
  undefined4 uStack_4;
  
  *(undefined4 **)(unaff_EBP + 8) = &uStack_8;
  uStack_8 = 0;
  uStack_4 = 0;
  *(undefined4 *)(unaff_EBP + -4) = 2;
  iVar2 = unaff_EDI + 0x18;
  uVar1 = 0x989f5b;
  FUN_0054ef60(iVar2);
  FUN_00557fc0(unaff_EDI + 0x34);
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  FUN_0096ee10(1,uVar1,iVar2);
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 17905 ; VA 0x00989ff0 ; FUN_00989ff0 */

undefined4 * FUN_00989ff0(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uStack_8;
  
  FUN_006ab810(&uStack_8,param_2,param_3);
  uVar1 = FUN_006ac4d0();
  param_1[1] = uVar1;
  *param_1 = uStack_8;
  return param_1;
}



/* FUNCTION 17906 ; VA 0x0098a020 ; FUN_0098a020 */

uint __thiscall FUN_0098a020(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  
  *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) - *(int *)(*(int *)(*param_2 + 0x20) + 0x20);
  piVar1 = *(int **)(*param_2 + 0x20);
  *(int *)piVar1[1] = *piVar1;
  *(int *)(*piVar1 + 4) = piVar1[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_00970c10(piVar1);
  param_2 = (int *)*param_2;
  piVar1 = (int *)*param_2;
  uVar6 = (uint)param_2[1] % *(uint *)(param_1 + 0x10);
  piVar2 = *(int **)(*(int *)(param_1 + 0x20) + uVar6 * 4);
  for (piVar8 = (int *)*piVar2; piVar8 != param_2; piVar8 = (int *)*piVar8) {
    piVar2 = piVar8;
  }
  do {
    *piVar2 = *piVar8;
    uVar7 = piVar8[7];
    if (0xf < uVar7) {
      iVar3 = piVar8[2];
      uVar5 = uVar7 + 1;
      iVar4 = iVar3;
      if (0xfff < uVar5) {
        iVar4 = *(int *)(iVar3 + -4);
        uVar5 = uVar7 + 0x24;
        if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar5);
    }
    piVar8[6] = 0;
    piVar8[7] = 0xf;
    *(undefined *)(piVar8 + 2) = 0;
    FUN_01674ea0(piVar8,0x24);
    *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + -1;
    uVar7 = uVar6;
    if (*piVar2 == 0) {
LAB_0098a0f9:
      uVar5 = *(uint *)(param_1 + 0x20);
      if (*(int **)(uVar5 + uVar6 * 4) == piVar2) {
        *(undefined4 *)(uVar5 + uVar6 * 4) = 0;
      }
    }
    else {
      uVar7 = *(uint *)(*piVar2 + 4);
      uVar5 = uVar7 / *(uint *)(param_1 + 0x10);
      uVar7 = uVar7 % *(uint *)(param_1 + 0x10);
      if (uVar6 != uVar7) {
        *(int **)(*(int *)(param_1 + 0x20) + uVar7 * 4) = piVar2;
        goto LAB_0098a0f9;
      }
    }
    piVar8 = (int *)*piVar2;
    uVar6 = uVar7;
    if (piVar8 == piVar1) {
      return uVar5;
    }
  } while( true );
}



/* FUNCTION 17907 ; VA 0x0098a130 ; FUN_0098a130 */

undefined4 __thiscall FUN_0098a130(int param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  
  iVar2 = param_1 + 0xd + (uint)*(byte *)(param_1 + 0xc);
  uVar1 = FUN_005702d0(param_2);
  FUN_00562fc0(&param_2,uVar1,param_2,-(uint)(iVar2 != 0) & iVar2 + 1U);
  if (param_2 == 0) {
    return 0;
  }
  FUN_0098a020(&param_2);
  return 1;
}



/* FUNCTION 17908 ; VA 0x0098a190 ; FUN_0098a190 */

uint __thiscall FUN_0098a190(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  
  *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) - *(int *)(*(int *)(*param_2 + 0x20) + 0x20);
  piVar1 = *(int **)(*param_2 + 0x20);
  *(int *)piVar1[1] = *piVar1;
  *(int *)(*piVar1 + 4) = piVar1[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_00970c70(piVar1);
  param_2 = (int *)*param_2;
  piVar1 = (int *)*param_2;
  uVar6 = (uint)param_2[1] % *(uint *)(param_1 + 0x10);
  piVar2 = *(int **)(*(int *)(param_1 + 0x20) + uVar6 * 4);
  for (piVar8 = (int *)*piVar2; piVar8 != param_2; piVar8 = (int *)*piVar8) {
    piVar2 = piVar8;
  }
  do {
    *piVar2 = *piVar8;
    uVar7 = piVar8[7];
    if (0xf < uVar7) {
      iVar3 = piVar8[2];
      uVar5 = uVar7 + 1;
      iVar4 = iVar3;
      if (0xfff < uVar5) {
        iVar4 = *(int *)(iVar3 + -4);
        uVar5 = uVar7 + 0x24;
        if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar5);
    }
    piVar8[6] = 0;
    piVar8[7] = 0xf;
    *(undefined *)(piVar8 + 2) = 0;
    FUN_01674ea0(piVar8,0x24);
    *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + -1;
    uVar7 = uVar6;
    if (*piVar2 == 0) {
LAB_0098a269:
      uVar5 = *(uint *)(param_1 + 0x20);
      if (*(int **)(uVar5 + uVar6 * 4) == piVar2) {
        *(undefined4 *)(uVar5 + uVar6 * 4) = 0;
      }
    }
    else {
      uVar7 = *(uint *)(*piVar2 + 4);
      uVar5 = uVar7 / *(uint *)(param_1 + 0x10);
      uVar7 = uVar7 % *(uint *)(param_1 + 0x10);
      if (uVar6 != uVar7) {
        *(int **)(*(int *)(param_1 + 0x20) + uVar7 * 4) = piVar2;
        goto LAB_0098a269;
      }
    }
    piVar8 = (int *)*piVar2;
    uVar6 = uVar7;
    if (piVar8 == piVar1) {
      return uVar5;
    }
  } while( true );
}



/* FUNCTION 17909 ; VA 0x0098a2a0 ; FUN_0098a2a0 */

void __thiscall FUN_0098a2a0(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  uint uVar5;
  
  *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) - *(int *)(*(int *)(*param_2 + 0x10) + 0x10);
  piVar1 = *(int **)(*param_2 + 0x10);
  *(int *)piVar1[1] = *piVar1;
  *(int *)(*piVar1 + 4) = piVar1[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_00970cd0(piVar1);
  param_2 = (int *)*param_2;
  piVar1 = (int *)*param_2;
  uVar4 = (uint)param_2[1] % *(uint *)(param_1 + 0x10);
  piVar2 = *(int **)(*(int *)(param_1 + 0x20) + uVar4 * 4);
  for (piVar3 = (int *)*piVar2; piVar3 != param_2; piVar3 = (int *)*piVar3) {
    piVar2 = piVar3;
  }
  do {
    *piVar2 = *piVar3;
    FUN_01674ea0(piVar3,0x18);
    *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + -1;
    uVar5 = uVar4;
    if (*piVar2 == 0) {
LAB_0098a32c:
      if (*(int **)(*(int *)(param_1 + 0x20) + uVar4 * 4) == piVar2) {
        *(undefined4 *)(*(int *)(param_1 + 0x20) + uVar4 * 4) = 0;
      }
    }
    else {
      uVar5 = *(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 0x10);
      if (uVar4 != uVar5) {
        *(int **)(*(int *)(param_1 + 0x20) + uVar5 * 4) = piVar2;
        goto LAB_0098a32c;
      }
    }
    piVar3 = (int *)*piVar2;
    uVar4 = uVar5;
    if (piVar3 == piVar1) {
      return;
    }
  } while( true );
}



/* FUNCTION 17910 ; VA 0x0098a350 ; FUN_0098a350 */

undefined4 __thiscall FUN_0098a350(int param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  
  iVar2 = param_1 + 0xd + (uint)*(byte *)(param_1 + 0xc);
  uVar1 = param_2[1];
  if (((int)uVar1 < 1) && ((int)uVar1 < 0)) {
    uVar1 = ~uVar1;
  }
  FUN_00606ff0(&param_2,(uVar1 >> 2) + uVar1 * 0x40 + *param_2 ^ uVar1,param_2,
               -(uint)(iVar2 != 0) & iVar2 + 1U);
  if (param_2 == (int *)0x0) {
    return 0;
  }
  FUN_0098a2a0(&param_2);
  return 1;
}



/* FUNCTION 17911 ; VA 0x0098a3d0 ; FUN_0098a3d0 */

void * __thiscall FUN_0098a3d0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  void **ppvVar3;
  void *pvVar4;
  int *piVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017bbe08;
  ExceptionList = &pvStack_10;
  piVar5 = *(int **)(param_1 + 0xbc);
  ppvVar3 = &pvStack_10;
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = *(int **)(param_1 + 0xbc);
    ppvVar3 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar3;
  iVar2 = (*(int **)(param_1 + 0xb8))[1];
  iVar6 = **(int **)(param_1 + 0xb8);
  uStack_8 = 0;
  pvVar4 = pvStack_10;
  for (; iVar6 != iVar2; iVar6 = iVar6 + 8) {
    pvVar4 = (void *)FUN_00930420(param_2);
  }
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar1 = piVar5 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 17912 ; VA 0x0098a470 ; FUN_0098a470 */

void FUN_0098a470(int *param_1,undefined4 param_2,undefined4 param_3)

{
  code *pcVar1;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0aa1;
  pvStack_10 = ExceptionList;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_f0 = FUN_0088daf0();
  uStack_ec = 0;
  uStack_e8 = (undefined)param_2;
  uStack_ec = FUN_005c9ef0();
  uStack_8 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,param_2);
  uStack_8._0_1_ = 1;
  (*pcVar1)(uStack_14,&uStack_20,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00577b20();
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17913 ; VA 0x0098a550 ; FUN_0098a550 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __thiscall FUN_0098a550(undefined4 *param_1,int *param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  char cVar9;
  int iVar10;
  undefined4 uVar11;
  undefined4 *puVar12;
  int iVar13;
  int *piVar14;
  undefined8 uVar15;
  int iStack_dc;
  int iStack_d8;
  uint uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined8 uStack_bc;
  undefined8 uStack_b4;
  undefined4 auStack_ac [26];
  undefined4 uStack_44;
  int *piStack_40;
  int *piStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined8 uStack_20;
  undefined4 *puStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar12 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0aec;
  pvStack_10 = ExceptionList;
  uStack_44 = 0;
  if (param_1[0x2a] != 0) {
    if (param_2 == (undefined4 *)0x0) {
      ExceptionList = &pvStack_10;
      FUN_0086f2f0(1,"Submitting abuse report on game");
    }
    else {
      piVar14 = (int *)param_2[10];
      if (0xf < (uint)piVar14[5]) {
        piVar14 = (int *)*piVar14;
      }
      ExceptionList = &pvStack_10;
      FUN_0086f2f0(1,"Submitting abuse report on %s",piVar14);
    }
    FUN_0096b1b0();
    uStack_8 = 0;
    if (param_1[0x3d] == 0) {
      uStack_bc = 0;
    }
    else {
      uStack_bc = FUN_00928340();
    }
    if (puVar12 == (undefined4 *)0x0) {
      uStack_b4 = 0;
    }
    else {
      uStack_b4 = FUN_00928340();
    }
    if (auStack_ac != param_3) {
      puVar12 = param_3;
      if (0xf < (uint)param_3[5]) {
        puVar12 = (undefined4 *)*param_3;
      }
      FUN_005542c0(puVar12,param_3[4]);
    }
    iVar10 = FUN_008f7870(param_1);
    if (iVar10 != 0) {
      piVar14 = *(int **)(iVar10 + 0x43c);
      iStack_d8 = piVar14[1] - (int)piVar14;
      iStack_dc = *piVar14 - (int)piVar14;
      FUN_0054ef60(iVar10 + 0x288);
      FUN_005507b0();
      uStack_d4 = uStack_38;
      uStack_38 = uStack_38 & 0xffffff00;
      uStack_d0 = uStack_34;
      uStack_cc = uStack_30;
      uStack_c8 = uStack_2c;
      uStack_28 = 0;
      piStack_24 = (int *)&DAT_0000000f;
      FUN_005507b0();
    }
    if (param_1[0x3e] != 0) {
      LOCK();
      piVar14 = (int *)(param_1[0x3e] + 4);
      *piVar14 = *piVar14 + 1;
      UNLOCK();
    }
    FUN_00971600(&iStack_dc,param_1[0x3d],param_1[0x3e],param_1 + 0x2c);
    iVar10 = FUN_0096ce60();
    ExceptionList = pvStack_10;
    return iVar10;
  }
  ExceptionList = &pvStack_10;
  FUN_0086edd0(1,"Sending abuse report to game server via Raknet",6);
  if (param_1[0x30] == 0) {
    FUN_00550130("Can\'t report abuse: Not in a networked game");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(&uStack_2c,&DAT_01c17198);
  }
  FUN_00607880(&piStack_40);
  piVar14 = piStack_40;
  uStack_8 = 1;
  auStack_14[0] = 0x89;
  FUN_006ad5e0(auStack_14,1);
  iVar10 = FUN_005eef10(param_1);
  if (iVar10 != 0) {
    FUN_005f7170(iVar10 + 0x110);
  }
  if (param_2 == (undefined4 *)0x0) {
    uStack_20 = 0;
    uVar15 = 0;
  }
  else {
    uVar15 = FUN_00928340();
  }
  FUN_006ad310(uVar15,piVar14);
  FUN_006ae570(param_3);
  uVar11 = (**(code **)(*piVar14 + 8))();
  FUN_00971460(uVar11);
  if (DAT_01d646c8 != '\0') {
    if (DAT_01ee30a4 == 0) {
      FUN_016799d0();
      DAT_01ee30a4 = FUN_01679e20(1,0,100,0);
    }
    if (DAT_01ee30a4 <= DAT_01ee2fa8) {
      uStack_28 = 0;
      piStack_24 = (int *)&DAT_0000000f;
      uStack_38 = uStack_38 & 0xffffff00;
      FUN_005542c0("AbuseReportScreenshot-ReportStart",0x21);
      uStack_8._0_1_ = 2;
      FUN_008783f0(&uStack_38,1,0);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_005507b0();
      param_2 = (int *)param_1[0xd];
      puVar12 = param_1;
      if ((param_2 != (undefined4 *)0x0) && (puVar12 = param_2, param_2[0xd] != 0)) {
        puVar12 = (undefined4 *)FUN_005c8ac0();
      }
      param_2 = puVar12;
      if ((param_2 != (undefined4 *)0x0) &&
         (iVar10 = param_2[3], iVar13 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar10 + 0x1d8) - (uint)*(ushort *)(iVar13 + 0x1d8) <=
         (uint)*(ushort *)(iVar13 + 0x1da))) {
        FUN_005789c0(&DAT_01ead5f8,&LAB_006340d0);
        uVar11 = FUN_006352d0();
        param_2 = (int *)FUN_008aa140(uVar11);
        if (*param_2 == 0) {
          uVar11 = FUN_00b8c410();
          piVar14 = (int *)FUN_008a9ba0(&uStack_28,uVar11);
          iVar10 = *piVar14;
          iVar13 = piVar14[1];
          *piVar14 = 0;
          piVar14[1] = 0;
          *param_2 = iVar10;
          piVar14 = (int *)param_2[1];
          param_2[1] = iVar13;
          if (piVar14 != (int *)0x0) {
            LOCK();
            iVar10 = piVar14[1] + -1;
            piVar14[1] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)*piVar14)();
              LOCK();
              iVar10 = piVar14[2] + -1;
              piVar14[2] = iVar10;
              UNLOCK();
              if (iVar10 == 0) {
                (**(code **)(*piVar14 + 4))();
              }
            }
          }
          piVar14 = piStack_24;
          if (piStack_24 != (int *)0x0) {
            LOCK();
            iVar10 = piStack_24[1] + -1;
            piStack_24[1] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)*piStack_24)();
              LOCK();
              piVar1 = piVar14 + 2;
              iVar10 = *piVar1 + -1;
              *piVar1 = iVar10;
              UNLOCK();
              if (iVar10 == 0) {
                (**(code **)(*piVar14 + 4))();
              }
            }
          }
        }
        param_2 = (int *)*param_2;
        if (param_2 != (undefined4 *)0x0) {
          FUN_01531f50(param_1 + 0x9f);
          FUN_006ae570(param_1 + 0x9f);
          cVar9 = FUN_016793f0();
          if (cVar9 == '\0') {
            param_3 = param_2 + 0x23;
            uStack_8._0_1_ = 3;
            uVar11 = FUN_01675290(DAT_02110da8);
            uStack_20 = CONCAT44(uVar11,(undefined4)uStack_20);
            uStack_8._0_1_ = 4;
            puStack_18 = (undefined4 *)FUN_01674e20(0x1c);
            if (puStack_18 == (undefined4 *)0x0) {
              puStack_18 = (undefined4 *)0x0;
            }
            else {
              *puStack_18 = 0;
              puStack_18[1] = 1;
              puStack_18[2] = FUN_0097a860;
              puStack_18[3] = _guard_check_icall;
              puStack_18[4] = 0;
              puStack_18[5] = param_3;
              puStack_18[6] = param_1;
            }
            FUN_016797d0(puStack_18);
            param_2 = puStack_18;
            if (puStack_18 != (undefined4 *)0x0) {
              LOCK();
              puStack_18[1] = puStack_18[1] + 1;
              UNLOCK();
            }
            uStack_44 = 2;
            uStack_8._0_1_ = 5;
            FUN_01675290(uVar11);
            uStack_8 = CONCAT31(uStack_8._1_3_,3);
            cVar9 = FUN_01679300(&param_2);
            if (cVar9 != '\0') {
              FUN_01679490();
              FUN_016791c0(&param_2);
            }
            uStack_8 = CONCAT31(uStack_8._1_3_,1);
            FUN_0056e750();
          }
        }
      }
    }
  }
  uVar8 = uRam01ee2fe4;
  uVar7 = uRam01ee2fe0;
  uVar6 = uRam01ee2fdc;
  uVar5 = _DAT_01ee2fd8;
  uVar4 = uRam01ee2fd4;
  uVar3 = uRam01ee2fd0;
  uVar2 = uRam01ee2fcc;
  uVar11 = _DAT_01ee2fc8;
  if (piStack_3c != (int *)0x0) {
    LOCK();
    piStack_3c[1] = piStack_3c[1] + 1;
    UNLOCK();
  }
  iVar10 = FUN_006afb30(piStack_40,piStack_3c,1,2,2,uVar11,uVar2,uVar3,uVar4,uVar5,uVar6,uVar7,uVar8
                        ,1,0);
  if (piStack_3c != (int *)0x0) {
    LOCK();
    piVar14 = piStack_3c + 1;
    iVar13 = *piVar14;
    iVar10 = *piVar14;
    *piVar14 = iVar13 + -1;
    UNLOCK();
    if (iVar13 + -1 == 0) {
      iVar10 = (**(code **)*piStack_3c)();
      LOCK();
      piVar14 = piStack_3c + 2;
      iVar13 = *piVar14;
      *piVar14 = *piVar14 + -1;
      UNLOCK();
      if (iVar13 == 1) {
        iVar10 = (**(code **)(*piStack_3c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar10;
}



/* FUNCTION 17914 ; VA 0x0098ab10 ; FUN_0098ab10 */

/* WARNING: Removing unreachable block (ram,0x0098abd2) */

void __thiscall FUN_0098ab10(int param_1,int param_2,int *param_3,undefined4 *param_4)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int *piVar5;
  longlong lVar6;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 *in_stack_00000024;
  undefined4 in_stack_00000034;
  uint in_stack_00000038;
  undefined auStack_d0 [152];
  undefined auStack_38 [12];
  undefined auStack_2c [4];
  undefined auStack_28 [4];
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d0b33;
  pvStack_10 = ExceptionList;
  piVar5 = (int *)0x0;
  iStack_14 = 0;
  iStack_20 = 0;
  piStack_1c = (int *)0x0;
  uStack_8 = 3;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    piVar2 = (int *)FUN_00562c90(auStack_28,&param_2);
    iStack_20 = *piVar2;
    piVar5 = (int *)piVar2[1];
    *piVar2 = 0;
    piVar2[1] = 0;
    piStack_1c = piVar5;
    iStack_14 = iStack_20;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_24[1] + -1;
      piStack_24[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar1 = piStack_24[2] + -1;
        piStack_24[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    if (iStack_14 == 0) {
      FUN_016756b0(auStack_2c,"player must be a Player object or null");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_2c,&DAT_01c17198);
    }
  }
  if (*(int *)(iStack_18 + 0xf4) != 0) {
    lVar6 = FUN_00928340();
    if (0 < lVar6) {
      FUN_00565520(2,1);
      puVar3 = &param_4;
      if (0xf < in_stack_00000020) {
        puVar3 = param_4;
      }
      uStack_8 = 4;
      uVar4 = FUN_0055b3b0(auStack_d0,puVar3,in_stack_0000001c);
      uVar4 = FUN_00558890(uVar4,&DAT_018d1b9c);
      puVar3 = &stack0x00000024;
      if (0xf < in_stack_00000038) {
        puVar3 = in_stack_00000024;
      }
      FUN_0055b3b0(uVar4,puVar3,in_stack_00000034);
      uVar4 = FUN_0058c400(auStack_38);
      uStack_8 = 5;
      FUN_0098a550(iStack_14,uVar4);
      FUN_005507b0();
      FUN_00570540();
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    piVar5 = param_3;
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar1 = param_3[1] + -1;
      param_3[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*param_3)();
        LOCK();
        piVar2 = piVar5 + 2;
        iVar1 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    FUN_005507b0();
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  FUN_016756b0(auStack_2c,"You can only report-abuse from a client machine");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_2c,&DAT_01c17198);
}



/* FUNCTION 17915 ; VA 0x0098ad10 ; FUN_0098ad10 */

void FUN_0098ad10(uint param_1)

{
  uint uVar1;
  uint uVar2;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a2bf8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((param_1 & 1) != 0) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0("UserJoin-EqualIP",0x10);
    uStack_8 = 0;
    FUN_008783f0(auStack_28,1,0);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar2 = uStack_14 + 1;
      uVar1 = auStack_28[0];
      if (0xfff < uVar2) {
        uVar1 = *(uint *)(auStack_28[0] - 4);
        uVar2 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar1,uVar2);
    }
  }
  if ((param_1 & 2) != 0) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("UserJoin-SimilarIP",0x12);
    uStack_8 = 1;
    FUN_008783f0(auStack_28,1,0);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar2 = uStack_14 + 1;
      uVar1 = auStack_28[0];
      if (0xfff < uVar2) {
        uVar1 = *(uint *)(auStack_28[0] - 4);
        uVar2 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar1,uVar2);
    }
  }
  if ((param_1 & 4) != 0) {
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_005542c0("UserJoin-EqualClientUuid",0x18);
    uStack_8 = 2;
    FUN_008783f0(auStack_40,1,0);
    if (0xf < uStack_2c) {
      uVar2 = uStack_2c + 1;
      uVar1 = auStack_40[0];
      if (0xfff < uVar2) {
        uVar1 = *(uint *)(auStack_40[0] - 4);
        uVar2 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar1,uVar2);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17916 ; VA 0x0098aeb0 ; FUN_0098aeb0 */

void FUN_0098aeb0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  uint in_stack_00000020;
  int in_stack_00000024;
  uint in_stack_00000038;
  int in_stack_0000003c;
  uint in_stack_00000050;
  
  if (0xf < in_stack_00000020) {
    uVar2 = in_stack_00000020 + 1;
    iVar1 = param_3;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_3 + -4);
      uVar2 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - iVar1) - 4U) goto LAB_0098af6f;
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  if (0xf < in_stack_00000038) {
    uVar2 = in_stack_00000038 + 1;
    iVar1 = in_stack_00000024;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(in_stack_00000024 + -4);
      uVar2 = in_stack_00000038 + 0x24;
      if (0x1f < (in_stack_00000024 - iVar1) - 4U) goto LAB_0098af6f;
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  if (0xf < in_stack_00000050) {
    uVar2 = in_stack_00000050 + 1;
    iVar1 = in_stack_0000003c;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(in_stack_0000003c + -4);
      uVar2 = in_stack_00000050 + 0x24;
      if (0x1f < (in_stack_0000003c - iVar1) - 4U) {
LAB_0098af6f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  return;
}



/* FUNCTION 17917 ; VA 0x0098af80 ; FUN_0098af80 */

void FUN_0098af80(undefined4 param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined uVar4;
  undefined **ppuVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined **ppuVar8;
  uint uVar9;
  uint uVar10;
  uint in_stack_00000020;
  uint auStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined auStack_2c [4];
  undefined *puStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d0b90;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  auStack_2c[0] = 0;
  uStack_14 = 0xb;
  ExceptionList = &pvStack_10;
  ppuVar5 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
  ppuVar8 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar8 = ppuVar5;
  }
  puStack_28 = *ppuVar8;
  uStack_24 = 0;
  uStack_20 = 0x3f800000;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8._0_1_ = 1;
  puVar6 = (undefined4 *)FUN_0152fd20(auStack_5c);
  uStack_8._0_1_ = 2;
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  FUN_005542c0("device",6);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  iVar7 = FUN_005d15d0(auStack_44);
  if ((undefined4 *)(iVar7 + 0x18) != puVar6) {
    FUN_005507b0();
    uVar1 = puVar6[1];
    uVar2 = puVar6[2];
    uVar3 = puVar6[3];
    *(undefined4 *)(iVar7 + 0x18) = *puVar6;
    *(undefined4 *)(iVar7 + 0x1c) = uVar1;
    *(undefined4 *)(iVar7 + 0x20) = uVar2;
    *(undefined4 *)(iVar7 + 0x24) = uVar3;
    *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(puVar6 + 4);
    puVar6[4] = 0;
    puVar6[5] = 0xf;
    *(undefined *)puVar6 = 0;
  }
  uStack_8._0_1_ = 2;
  if (0xf < uStack_30) {
    uVar9 = uStack_30 + 1;
    uVar10 = auStack_44[0];
    if (0xfff < uVar9) {
      uVar10 = *(uint *)(auStack_44[0] - 4);
      uVar9 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar9);
  }
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  uStack_8._0_1_ = 1;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_48) {
    uVar9 = uStack_48 + 1;
    uVar10 = auStack_5c[0];
    if (0xfff < uVar9) {
      uVar10 = *(uint *)(auStack_5c[0] - 4);
      uVar9 = uStack_48 + 0x24;
      if (0x1f < (auStack_5c[0] - uVar10) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar9);
  }
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  FUN_005542c0("RobloxPlaceIdHeader",0x13);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  puVar6 = (undefined4 *)FUN_005d15d0(auStack_44);
  if ((undefined4 **)puVar6 != &DAT_01d79c68) {
    puVar6 = &DAT_01d79c80;
    if (0xf < DAT_01d79c94) {
      puVar6 = DAT_01d79c80;
    }
    FUN_005542c0(puVar6,DAT_01d79c90);
  }
  uStack_8._0_1_ = 1;
  if (0xf < uStack_30) {
    uVar9 = uStack_30 + 1;
    uVar10 = auStack_44[0];
    if (0xfff < uVar9) {
      uVar10 = *(uint *)(auStack_44[0] - 4);
      uVar9 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar9);
  }
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  FUN_005542c0("RobloxGameIdHeader",0x12);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  puVar6 = (undefined4 *)FUN_005d15d0(auStack_44);
  if (puVar6 != &DAT_01d79c50) {
    puVar6 = &DAT_01d79c68;
    if (0xf < DAT_01d79c7c) {
      puVar6 = DAT_01d79c68;
    }
    FUN_005542c0(puVar6,DAT_01d79c78);
  }
  uStack_8._0_1_ = 1;
  if (0xf < uStack_30) {
    uVar9 = uStack_30 + 1;
    uVar10 = auStack_44[0];
    if (0xfff < uVar9) {
      uVar10 = *(uint *)(auStack_44[0] - 4);
      uVar9 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar9);
  }
  puVar6 = (undefined4 *)FUN_01675640(auStack_5c,&DAT_018bed48,param_1,param_2);
  uStack_8._0_1_ = 6;
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  FUN_005542c0("userid",6);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  iVar7 = FUN_005d15d0(auStack_44);
  if ((undefined4 *)(iVar7 + 0x18) != puVar6) {
    FUN_005507b0();
    uVar1 = puVar6[1];
    uVar2 = puVar6[2];
    uVar3 = puVar6[3];
    *(undefined4 *)(iVar7 + 0x18) = *puVar6;
    *(undefined4 *)(iVar7 + 0x1c) = uVar1;
    *(undefined4 *)(iVar7 + 0x20) = uVar2;
    *(undefined4 *)(iVar7 + 0x24) = uVar3;
    *(undefined8 *)(iVar7 + 0x28) = *(undefined8 *)(puVar6 + 4);
    puVar6[4] = 0;
    puVar6[5] = 0xf;
    *(undefined *)puVar6 = 0;
  }
  uStack_8._0_1_ = 6;
  if (0xf < uStack_30) {
    uVar9 = uStack_30 + 1;
    uVar10 = auStack_44[0];
    if (0xfff < uVar9) {
      uVar10 = *(uint *)(auStack_44[0] - 4);
      uVar9 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar9);
  }
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  uStack_8._0_1_ = 1;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_48) {
    uVar9 = uStack_48 + 1;
    uVar10 = auStack_5c[0];
    if (0xfff < uVar9) {
      uVar10 = *(uint *)(auStack_5c[0] - 4);
      uVar9 = uStack_48 + 0x24;
      if (0x1f < (auStack_5c[0] - uVar10) - 4) {
        uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar9);
  }
  uStack_4c = 0;
  uStack_48 = 0xf;
  auStack_5c[0] = auStack_5c[0] & 0xffffff00;
  FUN_005542c0("TeamCreate",10);
  uStack_8._0_1_ = 8;
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  FUN_005542c0(&DAT_018bde9c,3);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  FUN_00879580(auStack_44,auStack_5c,&param_3,auStack_2c);
  if (0xf < uStack_30) {
    uVar9 = uStack_30 + 1;
    uVar10 = auStack_44[0];
    if (0xfff < uVar9) {
      uVar10 = *(uint *)(auStack_44[0] - 4);
      uVar9 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar9);
  }
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  if (0xf < uStack_48) {
    uVar9 = uStack_48 + 1;
    uVar10 = auStack_5c[0];
    if (0xfff < uVar9) {
      uVar10 = *(uint *)(auStack_5c[0] - 4);
      uVar9 = uStack_48 + 0x24;
      if (0x1f < (auStack_5c[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar9);
  }
  FUN_0056cfd0();
  if (0xf < in_stack_00000020) {
    uVar10 = in_stack_00000020 + 1;
    iVar7 = param_3;
    if (0xfff < uVar10) {
      iVar7 = *(int *)(param_3 + -4);
      uVar10 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar10);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17918 ; VA 0x0098b460 ; FUN_0098b460 */

void __thiscall FUN_0098b460(int param_1,int param_2)

{
  int *piVar1;
  double dVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  double *pdVar7;
  uint uVar8;
  undefined8 uVar9;
  undefined auStack_14 [4];
  int *piStack_10;
  int iStack_c;
  int *piStack_8;
  
  piStack_10 = (int *)0x0;
  piStack_8 = (int *)0x0;
  if (param_1 != 0) {
    iVar5 = *(int *)(param_1 + 0x34);
    if ((iVar5 != 0) && (param_1 = iVar5, *(int *)(iVar5 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if (((param_1 != 0) &&
        (iVar5 = *(int *)(param_1 + 0xc), iVar4 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da))) && (iStack_c = FUN_00562e40(), iStack_c != 0)) {
      uVar8 = 0;
      iVar5 = FUN_005d6c30();
      if (iVar5 != 0) {
        do {
          piVar1 = *(int **)(**(int **)(iStack_c + 0x2c) + uVar8 * 8);
          piVar3 = piStack_10;
          if (((piVar1 != (int *)0x0) &&
              (iVar5 = piVar1[3], iVar4 = FUN_005ee350(), piVar3 = piStack_10,
              (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
              (uint)*(ushort *)(iVar4 + 0x1da))) &&
             (iVar5 = (**(code **)(*piVar1 + 0xb4))(), piVar3 = piStack_10, iVar5 != 0)) {
            uVar9 = FUN_00928340();
            if (((int)uVar9 != *(int *)(param_2 + 0x20)) ||
               (piVar3 = piVar1, (int)((ulonglong)uVar9 >> 0x20) != *(int *)(param_2 + 0x24))) {
              uVar9 = FUN_00928340();
              piVar3 = piStack_10;
              if (((int)uVar9 == *(int *)(param_2 + 0x28)) &&
                 ((int)((ulonglong)uVar9 >> 0x20) == *(int *)(param_2 + 0x2c))) {
                piStack_8 = piVar1;
              }
            }
          }
          piStack_10 = piVar3;
          piVar3 = piStack_8;
          uVar8 = uVar8 + 1;
          uVar6 = FUN_005d6c30();
          piVar1 = piStack_10;
        } while (uVar8 < uVar6);
        if ((((piStack_10 != (int *)0x0) && (piVar3 != (int *)0x0)) &&
            (dVar2 = *(double *)(piStack_10 + 0xef0), pdVar7 = (double *)FUN_016830f0(auStack_14),
            DAT_018ce310 < *pdVar7 - dVar2)) &&
           (dVar2 = *(double *)(piVar1 + 0xef0), pdVar7 = (double *)FUN_016830f0(auStack_14),
           DAT_018ce310 < *pdVar7 - dVar2)) {
          iVar5 = (**(code **)(*piVar3 + 0x214))();
          if (iVar5 == 0x4beda921) {
            FUN_0066bb50();
          }
          FUN_0066bbc0(param_2);
        }
      }
    }
  }
  return;
}



/* FUNCTION 17919 ; VA 0x0098b610 ; FUN_0098b610 */

void __thiscall FUN_0098b610(int param_1,uint param_2)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int iStack_8;
  
  uVar1 = *(uint *)(param_1 + 8);
  iStack_8 = param_1;
  while (param_2 < uVar1) {
    iVar3 = *(int *)(*(int *)(param_1 + 4) + 4) + 8;
    iVar4 = param_1 + 0xd + (uint)*(byte *)(param_1 + 0xc);
    uVar2 = FUN_005702d0(iVar3);
    FUN_00562fc0(&iStack_8,uVar2,iVar3,-(uint)(iVar4 != 0) & iVar4 + 1U);
    if (iStack_8 != 0) {
      FUN_0098a020(&iStack_8);
    }
    uVar1 = *(uint *)(param_1 + 8);
  }
  return;
}



/* FUNCTION 17920 ; VA 0x0098b680 ; FUN_0098b680 */

void __thiscall FUN_0098b680(int param_1,uint param_2)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int iStack_8;
  
  uVar1 = *(uint *)(param_1 + 8);
  iStack_8 = param_1;
  while (param_2 < uVar1) {
    iVar3 = *(int *)(*(int *)(param_1 + 4) + 4) + 8;
    iVar4 = param_1 + 0xd + (uint)*(byte *)(param_1 + 0xc);
    uVar2 = FUN_005702d0(iVar3);
    FUN_00562fc0(&iStack_8,uVar2,iVar3,-(uint)(iVar4 != 0) & iVar4 + 1U);
    if (iStack_8 != 0) {
      FUN_0098a190(&iStack_8);
    }
    uVar1 = *(uint *)(param_1 + 8);
  }
  return;
}



/* FUNCTION 17921 ; VA 0x0098b6f0 ; FUN_0098b6f0 */

void __thiscall FUN_0098b6f0(int param_1,uint param_2)

{
  int iVar1;
  uint uVar2;
  byte *pbVar3;
  int *piVar4;
  int iStack_8;
  
  uVar2 = *(uint *)(param_1 + 8);
  while (param_2 < uVar2) {
    pbVar3 = (byte *)(param_1 + 0xc) + *(byte *)(param_1 + 0xc) + 1;
    iVar1 = *(int *)(*(int *)(param_1 + 4) + 4);
    piVar4 = (int *)(iVar1 + 8);
    uVar2 = *(uint *)(iVar1 + 0xc);
    if (((int)uVar2 < 1) && ((int)uVar2 < 0)) {
      uVar2 = ~uVar2;
    }
    FUN_00606ff0(&iStack_8,(uVar2 >> 2) + uVar2 * 0x40 + *piVar4 ^ uVar2,piVar4,
                 -(uint)(pbVar3 != (byte *)0x0) & (uint)(pbVar3 + 1));
    if (iStack_8 != 0) {
      FUN_0098a2a0(&iStack_8);
    }
    uVar2 = *(uint *)(param_1 + 8);
  }
  return;
}



/* FUNCTION 17922 ; VA 0x0098b780 ; FUN_0098b780 */

int FUN_0098b780(int *param_1,int *param_2,int *param_3,int *param_4)

{
  byte *pbVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  char cVar5;
  int *piVar6;
  int iVar7;
  int *piVar8;
  uint uVar9;
  int *piVar10;
  uint uVar11;
  int *piVar12;
  undefined auStack_124 [12];
  undefined4 uStack_118;
  int *piStack_114;
  int *piStack_110;
  int *piStack_10c;
  int *piStack_108;
  undefined4 uStack_104;
  undefined auStack_100 [8];
  undefined4 uStack_f8;
  int *piStack_f4;
  int *piStack_f0;
  int *piStack_ec;
  int *piStack_e8;
  int *piStack_e4;
  int aiStack_e0 [3];
  undefined4 uStack_d4;
  int *piStack_d0;
  undefined *puStack_cc;
  int *piStack_c8;
  int **ppiStack_c4;
  int *apiStack_a4 [4];
  undefined4 uStack_94;
  uint uStack_90;
  int *piStack_8c;
  undefined4 uStack_7c;
  uint uStack_78;
  int *piStack_74;
  int *piStack_70;
  int *piStack_6c;
  int *piStack_68;
  undefined auStack_64 [4];
  undefined *puStack_60;
  int iStack_5c;
  int *piStack_58;
  undefined *puStack_54;
  undefined4 uStack_50;
  int *piStack_4c;
  undefined4 uStack_48;
  int iStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  uint uStack_38;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int **ppiStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d0c29;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ppiStack_c4 = (int **)&iStack_5c;
  piStack_c8 = (int *)0x98b7b4;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  ppiStack_c4 = (int **)0x29;
  piStack_c8 = (int *)0x19352bc;
  uStack_8._0_1_ = 2;
  uStack_7c = 0;
  uStack_78 = 0xf;
  piStack_8c = (int *)((uint)piStack_8c & 0xffffff00);
  puStack_cc = (undefined *)0x98b7df;
  FUN_005542c0();
  uStack_8._0_1_ = 3;
  if (iStack_5c == 0) {
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 4;
  }
  else {
    ppiStack_c4 = (int **)0x98b826;
    piVar6 = (int *)FUN_0064f8c0();
    ppiStack_18 = (int **)*piVar6;
    if (ppiStack_18 != (int **)0x0) {
      ppiStack_c4 = apiStack_a4;
      piStack_c8 = (int *)0x98b8f6;
      FUN_00f56820();
      ppiStack_c4 = (int **)0x0;
      piStack_c8 = (int *)0x0;
      uStack_8._0_1_ = 6;
      uStack_50 = 0;
      piStack_4c = (int *)0x0;
      uStack_48 = 0;
      puStack_cc = (undefined *)0x98b91e;
      piStack_4c = (int *)FUN_005cb2b0();
      iStack_44 = 0;
      uStack_40 = 0;
      uStack_3c = 0;
      ppiStack_c4 = (int **)0x8;
      uStack_8._0_1_ = 8;
      uStack_50 = 0x3f800000;
      piStack_c8 = (int *)0x98b94b;
      FUN_005cb500();
      uStack_8._0_1_ = 9;
      ppiStack_c4 = (int **)0x98b957;
      FUN_0167e9f0();
      uStack_8 = CONCAT31(uStack_8._1_3_,10);
      ppiStack_c4 = (int **)0x98b963;
      FUN_01681c30();
      ppiStack_c4 = (int **)0x1935930;
      piStack_c8 = (int *)0x98b970;
      FUN_01681d10();
      ppiStack_c4 = (int **)0x98b978;
      FUN_01681c10();
      piStack_14 = (int *)param_3[1];
      piVar6 = (int *)*param_3;
      if (piVar6 != piStack_14) {
        do {
          piVar10 = piVar6;
          if (0xf < (uint)piVar6[5]) {
            piVar10 = (int *)*piVar6;
          }
          uVar9 = 0;
          uVar11 = 0x811c9dc5;
          if (piVar6[4] != 0) {
            do {
              pbVar1 = (byte *)(uVar9 + (int)piVar10);
              uVar9 = uVar9 + 1;
              uVar11 = (*pbVar1 ^ uVar11) * 0x1000193;
            } while (uVar9 < (uint)piVar6[4]);
          }
          piVar12 = (int *)(uVar11 & uStack_38);
          piVar10 = *(int **)(iStack_44 + (int)piVar12 * 8);
          piStack_20 = piVar12;
          piStack_1c = piVar10;
          while( true ) {
            piVar8 = piStack_4c;
            if (piStack_1c != piStack_4c) {
              piVar8 = (int *)**(undefined4 **)(iStack_44 + 4 + (int)piVar12 * 8);
            }
            if (piVar10 == piVar8) goto LAB_0098ba82;
            piStack_d0 = piVar10 + 2;
            piStack_c8 = piVar6;
            if (0xf < (uint)piVar6[5]) {
              piStack_c8 = (int *)*piVar6;
            }
            puStack_cc = (undefined *)piVar10[6];
            if (0xf < (uint)piVar10[7]) {
              piStack_d0 = (int *)*piStack_d0;
            }
            ppiStack_c4 = (int **)piVar6[4];
            uStack_d4 = 0x98ba0c;
            cVar5 = FUN_0055c360();
            piVar8 = piStack_20;
            piVar3 = piVar10;
            piVar4 = piVar10;
            if (cVar5 != '\0') break;
            piVar10 = (int *)*piVar10;
          }
          while( true ) {
            piStack_1c = piVar4;
            piStack_24 = piVar3;
            piVar12 = piStack_4c;
            if (*(int **)(iStack_44 + (int)piVar8 * 8) != piStack_4c) {
              piVar12 = (int *)**(undefined4 **)(iStack_44 + 4 + (int)piVar8 * 8);
            }
            if (piVar10 == piVar12) break;
            piStack_c8 = piVar10 + 2;
            ppiStack_c4 = (int **)piVar10[6];
            if (0xf < (uint)piVar10[7]) {
              piStack_c8 = (int *)*piStack_c8;
            }
            piStack_d0 = piVar6;
            if (0xf < (uint)piVar6[5]) {
              piStack_d0 = (int *)*piVar6;
            }
            puStack_cc = (undefined *)piVar6[4];
            uStack_d4 = 0x98ba6c;
            cVar5 = FUN_0055c360();
            if (cVar5 == '\0') break;
            piVar10 = (int *)*piVar10;
            piVar3 = piStack_24;
            piVar4 = piStack_1c;
          }
          piVar12 = piStack_24;
          if (piStack_1c == piVar10) {
LAB_0098ba82:
            piVar10 = piStack_4c;
            piVar12 = piStack_4c;
          }
          iVar7 = 0;
          if (piVar12 == piVar10) {
LAB_0098ba9b:
            piStack_c8 = (int *)0x98baa4;
            ppiStack_c4 = (int **)piVar6;
            FUN_01681cd0();
            ppiStack_c4 = ppiStack_18;
            puStack_cc = auStack_64;
            piStack_d0 = (int *)0x98bab4;
            piStack_c8 = piVar6;
            FUN_00870280();
          }
          else {
            do {
              piVar12 = (int *)*piVar12;
              iVar7 = iVar7 + 1;
            } while (piVar12 != piVar10);
            if (iVar7 == 0) goto LAB_0098ba9b;
          }
          piVar6 = piVar6 + 0x16;
        } while (piVar6 != piStack_14);
      }
      ppiStack_c4 = (int **)0x98bac8;
      FUN_016811a0();
      ppiStack_c4 = (int **)0x0;
      piStack_c8 = (int *)0x193593c;
      puStack_cc = (undefined *)0x98bad7;
      FUN_01680f40();
      ppiStack_c4 = (int **)0x98badf;
      FUN_01681200();
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[2] = param_2[2] + 1;
        UNLOCK();
      }
      piStack_24 = param_1;
      piStack_74 = param_1;
      piStack_70 = param_2;
      if (param_4 != (int *)0x0) {
        LOCK();
        param_4[1] = param_4[1] + 1;
        UNLOCK();
      }
      piStack_20 = param_3;
      piStack_6c = param_3;
      piStack_68 = param_4;
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[2] = param_2[2] + 1;
        UNLOCK();
      }
      if (param_4 != (int *)0x0) {
        LOCK();
        param_4[1] = param_4[1] + 1;
        UNLOCK();
      }
      piStack_1c = aiStack_e0;
      piStack_14 = aiStack_e0;
      piStack_e4 = (int *)0x0;
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[2] = param_2[2] + 1;
        UNLOCK();
      }
      piStack_f4 = param_1;
      piStack_f0 = param_2;
      if (param_4 != (int *)0x0) {
        LOCK();
        param_4[1] = param_4[1] + 1;
        UNLOCK();
      }
      piStack_ec = param_3;
      piStack_e8 = param_4;
      uStack_f8 = 0x98bb9d;
      FUN_0095f1e0();
      puStack_54 = auStack_100;
      piStack_14 = (int *)auStack_100;
      uStack_104 = 0;
      if (piStack_70 != (int *)0x0) {
        LOCK();
        piStack_70[2] = piStack_70[2] + 1;
        UNLOCK();
      }
      piStack_114 = piStack_24;
      piStack_110 = piStack_70;
      if (param_4 != (int *)0x0) {
        LOCK();
        param_4[1] = param_4[1] + 1;
        UNLOCK();
      }
      piStack_10c = piStack_20;
      piStack_108 = param_4;
      uStack_118 = 0x98bbf4;
      FUN_0095f430();
      uStack_104 = 7;
      piStack_108 = (int *)0x0;
      piStack_10c = (int *)0x0;
      puStack_60 = auStack_124;
      uStack_8._0_1_ = 0xe;
      FUN_01681c50(auStack_124);
      uStack_8._0_1_ = 0xf;
      FUN_0054ef60(apiStack_a4);
      uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
      FUN_00bd12f0();
      if (param_4 != (int *)0x0) {
        LOCK();
        iVar7 = param_4[1] + -1;
        param_4[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          ppiStack_c4 = (int **)0x98bc44;
          (**(code **)*param_4)();
          LOCK();
          iVar7 = param_4[2] + -1;
          param_4[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            ppiStack_c4 = (int **)0x98bc55;
            (**(code **)(*param_4 + 4))();
          }
        }
      }
      if (param_2 != (int *)0x0) {
        LOCK();
        iVar7 = param_2[2] + -1;
        param_2[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          ppiStack_c4 = (int **)0x98bc6a;
          (**(code **)(*param_2 + 4))();
        }
      }
      if (param_4 != (int *)0x0) {
        LOCK();
        iVar7 = param_4[1] + -1;
        param_4[1] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          ppiStack_c4 = (int **)0x98bc80;
          (**(code **)*param_4)();
          LOCK();
          iVar7 = param_4[2] + -1;
          param_4[2] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            ppiStack_c4 = (int **)0x98bc90;
            (**(code **)(*param_4 + 4))();
          }
        }
      }
      if (piStack_70 != (int *)0x0) {
        LOCK();
        iVar7 = piStack_70[2] + -1;
        piStack_70[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          ppiStack_c4 = (int **)0x98bca5;
          (**(code **)(*piStack_70 + 4))();
        }
      }
      ppiStack_c4 = (int **)0x98bcad;
      FUN_0167ec80();
      ppiStack_c4 = (int **)0x98bcb5;
      iVar7 = FUN_005cafb0();
      if (0xf < uStack_90) {
        ppiStack_c4 = (int **)(uStack_90 + 1);
        piVar6 = apiStack_a4[0];
        if (0xfff < ppiStack_c4) {
          piVar6 = (int *)apiStack_a4[0][-1];
          ppiStack_c4 = (int **)(uStack_90 + 0x24);
          if ((char *)0x1f < (char *)((int)apiStack_a4[0] + (-4 - (int)piVar6))) {
                    /* WARNING: Subroutine does not return */
            ppiStack_c4 = (int **)&UNK_0098bd94;
            FUN_017167a3();
          }
        }
        puStack_cc = (undefined *)0x98bcec;
        piStack_c8 = piVar6;
        iVar7 = FUN_01674ea0();
      }
      uStack_94 = 0;
      uStack_90 = 0xf;
      apiStack_a4[0] = (int *)((uint)apiStack_a4[0] & 0xffffff00);
      goto LAB_0098b8b0;
    }
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 5;
  }
  ppiStack_18 = &piStack_c8;
  ppiStack_c4 = (int **)param_4;
  piStack_c8 = param_3;
  piStack_e4 = (int *)0xe;
  piStack_d0 = (int *)0x0;
  puStack_cc = (undefined *)0xf;
  piStack_e8 = (int *)0x1935328;
  aiStack_e0[0]._0_1_ = 0;
  piStack_ec = (int *)0x98b87c;
  FUN_005542c0();
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[2] = param_2[2] + 1;
    UNLOCK();
  }
  piStack_e8 = param_1;
  piStack_e4 = param_2;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  piStack_ec = (int *)0x98b8ad;
  iVar7 = FUN_00987740();
LAB_0098b8b0:
  if (0xf < uStack_78) {
    ppiStack_c4 = (int **)(uStack_78 + 1);
    piVar6 = piStack_8c;
    if (0xfff < ppiStack_c4) {
      piVar6 = (int *)piStack_8c[-1];
      ppiStack_c4 = (int **)(uStack_78 + 0x24);
      if ((char *)0x1f < (char *)((int)piStack_8c + (-4 - (int)piVar6))) {
                    /* WARNING: Subroutine does not return */
        ppiStack_c4 = (int **)0x98bd8f;
        FUN_017167a3();
      }
    }
    puStack_cc = (undefined *)0x98bd16;
    piStack_c8 = piVar6;
    iVar7 = FUN_01674ea0();
  }
  if (piStack_58 != (int *)0x0) {
    LOCK();
    piVar6 = piStack_58 + 1;
    iVar2 = *piVar6;
    iVar7 = *piVar6;
    *piVar6 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      ppiStack_c4 = (int **)0x98bd2f;
      (**(code **)*piStack_58)();
      LOCK();
      piVar6 = piStack_58 + 2;
      iVar2 = *piVar6;
      iVar7 = *piVar6;
      *piVar6 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        ppiStack_c4 = (int **)0x98bd3f;
        iVar7 = (**(code **)(*piStack_58 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar6 = param_2 + 2;
    iVar2 = *piVar6;
    iVar7 = *piVar6;
    *piVar6 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      ppiStack_c4 = (int **)0x98bd54;
      iVar7 = (**(code **)(*param_2 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar6 = param_4 + 1;
    iVar2 = *piVar6;
    iVar7 = *piVar6;
    *piVar6 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      ppiStack_c4 = (int **)0x98bd6a;
      iVar7 = (**(code **)*param_4)();
      LOCK();
      piVar6 = param_4 + 2;
      iVar2 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        ppiStack_c4 = (int **)0x98bd79;
        iVar7 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 17923 ; VA 0x0098bda0 ; FUN_0098bda0 */

int FUN_0098bda0(int *param_1,int *param_2,int *param_3,int *param_4)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  undefined auStack_10c [12];
  undefined4 uStack_100;
  int *piStack_fc;
  int *piStack_f8;
  int *piStack_f4;
  int *piStack_f0;
  undefined4 uStack_ec;
  undefined4 auStack_e8 [2];
  undefined4 uStack_e0;
  int *piStack_dc;
  int *piStack_d8;
  int *piStack_d4;
  int *piStack_d0;
  int *piStack_cc;
  undefined auStack_c8 [16];
  undefined4 uStack_b8;
  int **ppiStack_b4;
  int *piStack_b0;
  int **ppiStack_ac;
  int *piStack_88;
  int iStack_80;
  uint uStack_74;
  int *apiStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  int *piStack_54;
  int *piStack_50;
  int *piStack_4c;
  int *piStack_48;
  int iStack_44;
  int *piStack_40;
  undefined *puStack_3c;
  int *piStack_2c;
  undefined4 *puStack_28;
  int iStack_24;
  int *piStack_20;
  int *piStack_1c;
  int **ppiStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d0cae;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ppiStack_ac = (int **)&iStack_44;
  piStack_b0 = (int *)0x98bdd4;
  ExceptionList = &pvStack_10;
  FUN_00587490();
  uStack_8._0_1_ = 2;
  if (iStack_44 == 0) {
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 3;
  }
  else {
    ppiStack_ac = (int **)0x98be1b;
    piVar3 = (int *)FUN_0064f8c0();
    ppiStack_18 = (int **)*piVar3;
    if (ppiStack_18 != (int **)0x0) {
      ppiStack_ac = apiStack_6c;
      piStack_b0 = (int *)0x98beb3;
      FUN_00f56aa0();
      uStack_8._0_1_ = 5;
      ppiStack_ac = (int **)0x98bec5;
      FUN_005e5ff0();
      uStack_8._0_1_ = 6;
      ppiStack_ac = (int **)0x98bed1;
      FUN_0167e9f0();
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      ppiStack_ac = (int **)0x98bedd;
      FUN_01681c30();
      ppiStack_ac = (int **)0x1935964;
      piStack_b0 = (int *)0x98beea;
      FUN_01681d10();
      ppiStack_ac = (int **)0x98bef2;
      FUN_01681c10();
      piStack_14 = (int *)param_3[1];
      piVar3 = (int *)*param_3;
      piStack_1c = piVar3;
      if (piVar3 != piStack_14) {
        do {
          piStack_b0 = (int *)0x98bf1c;
          ppiStack_ac = (int **)piVar3;
          piStack_1c = piVar3;
          uVar5 = FUN_005e6570();
          piVar2 = piStack_1c;
          iVar4 = (uVar5 & uStack_74) * 8;
          puStack_28 = (undefined4 *)(iVar4 + iStack_80);
          iStack_24 = iVar4 + 4;
          piVar6 = *(int **)(iVar4 + iStack_80);
          while( true ) {
            piVar7 = piStack_88;
            if (*(int **)(iVar4 + iStack_80) != piStack_88) {
              piVar7 = (int *)**(undefined4 **)(iStack_80 + iStack_24);
            }
            if (piVar6 == piVar7) goto LAB_0098bfad;
            puStack_3c = (undefined *)*piVar3;
            if (((undefined *)piVar6[2] == puStack_3c) && (piVar7 = piVar6, piVar6[3] == piVar3[1]))
            break;
            piVar6 = (int *)*piVar6;
            piVar3 = piStack_1c;
          }
          while( true ) {
            piVar8 = piStack_88;
            if ((int *)*puStack_28 != piStack_88) {
              piVar8 = (int *)**(undefined4 **)(iStack_80 + iStack_24);
            }
            if (((piVar7 == piVar8) || (puStack_3c != (undefined *)piVar7[2])) ||
               (piVar3[1] != piVar7[3])) break;
            piVar7 = (int *)*piVar7;
          }
          piStack_2c = piVar6;
          piStack_20 = piVar6;
          if (piVar6 == piVar7) {
LAB_0098bfad:
            piVar7 = piStack_88;
            piVar6 = piStack_88;
          }
          iVar4 = 0;
          if (piVar6 == piVar7) {
LAB_0098bfc2:
            ppiStack_ac = (int **)piStack_1c[1];
            piStack_b0 = (int *)*piStack_1c;
            ppiStack_b4 = (int **)0x98bfd2;
            FUN_01681740();
            ppiStack_ac = ppiStack_18;
            ppiStack_b4 = &piStack_4c;
            piStack_b0 = piVar2;
            uStack_b8 = 0x98bfe5;
            FUN_005e5570();
          }
          else {
            do {
              piVar6 = (int *)*piVar6;
              iVar4 = iVar4 + 1;
            } while (piVar6 != piVar7);
            if (iVar4 == 0) goto LAB_0098bfc2;
          }
          piVar3 = piVar2 + 0x12;
          piStack_1c = piVar3;
        } while (piVar3 != piStack_14);
      }
      ppiStack_ac = (int **)0x98c007;
      FUN_016811a0();
      ppiStack_ac = (int **)0x0;
      piStack_b0 = (int *)0x193593c;
      ppiStack_b4 = (int **)0x98c016;
      FUN_01680f40();
      ppiStack_ac = (int **)0x98c01e;
      FUN_01681200();
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[2] = param_2[2] + 1;
        UNLOCK();
      }
      piStack_20 = param_1;
      piStack_54 = param_1;
      piStack_50 = param_2;
      if (param_4 != (int *)0x0) {
        LOCK();
        param_4[1] = param_4[1] + 1;
        UNLOCK();
      }
      piStack_2c = param_3;
      piStack_4c = param_3;
      piStack_48 = param_4;
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[2] = param_2[2] + 1;
        UNLOCK();
      }
      if (param_4 != (int *)0x0) {
        LOCK();
        param_4[1] = param_4[1] + 1;
        UNLOCK();
      }
      puStack_3c = auStack_c8;
      piStack_14 = (int *)auStack_c8;
      piStack_cc = (int *)0x0;
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[2] = param_2[2] + 1;
        UNLOCK();
      }
      piStack_dc = param_1;
      piStack_d8 = param_2;
      if (param_4 != (int *)0x0) {
        LOCK();
        param_4[1] = param_4[1] + 1;
        UNLOCK();
      }
      piStack_d4 = param_3;
      piStack_d0 = param_4;
      uStack_e0 = 0x98c0dc;
      FUN_0095f760();
      puStack_28 = auStack_e8;
      piStack_14 = auStack_e8;
      uStack_ec = 0;
      if (piStack_50 != (int *)0x0) {
        LOCK();
        piStack_50[2] = piStack_50[2] + 1;
        UNLOCK();
      }
      piStack_fc = piStack_20;
      piStack_f8 = piStack_50;
      if (param_4 != (int *)0x0) {
        LOCK();
        param_4[1] = param_4[1] + 1;
        UNLOCK();
      }
      piStack_f4 = piStack_2c;
      piStack_f0 = param_4;
      uStack_100 = 0x98c133;
      FUN_0095f530();
      uStack_ec = 7;
      piStack_f0 = (int *)0x0;
      piStack_f4 = (int *)0x0;
      piStack_14 = (int *)auStack_10c;
      uStack_8._0_1_ = 0xb;
      FUN_01681c50(auStack_10c);
      uStack_8._0_1_ = 0xc;
      FUN_0054ef60(apiStack_6c);
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      FUN_00bd12f0();
      if (param_4 != (int *)0x0) {
        LOCK();
        iVar4 = param_4[1] + -1;
        param_4[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          ppiStack_ac = (int **)0x98c180;
          (**(code **)*param_4)();
          LOCK();
          iVar4 = param_4[2] + -1;
          param_4[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            ppiStack_ac = (int **)0x98c191;
            (**(code **)(*param_4 + 4))();
          }
        }
      }
      if (param_2 != (int *)0x0) {
        LOCK();
        iVar4 = param_2[2] + -1;
        param_2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          ppiStack_ac = (int **)0x98c1a6;
          (**(code **)(*param_2 + 4))();
        }
      }
      if (param_4 != (int *)0x0) {
        LOCK();
        iVar4 = param_4[1] + -1;
        param_4[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          ppiStack_ac = (int **)0x98c1bc;
          (**(code **)*param_4)();
          LOCK();
          iVar4 = param_4[2] + -1;
          param_4[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            ppiStack_ac = (int **)0x98c1cc;
            (**(code **)(*param_4 + 4))();
          }
        }
      }
      if (piStack_50 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_50[2] + -1;
        piStack_50[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          ppiStack_ac = (int **)0x98c1e1;
          (**(code **)(*piStack_50 + 4))();
        }
      }
      ppiStack_ac = (int **)0x98c1e9;
      FUN_0167ec80();
      ppiStack_ac = (int **)0x98c1f4;
      iVar4 = FUN_005e61c0();
      if (0xf < uStack_58) {
        ppiStack_ac = (int **)(uStack_58 + 1);
        piVar3 = apiStack_6c[0];
        if (0xfff < ppiStack_ac) {
          piVar3 = (int *)apiStack_6c[0][-1];
          ppiStack_ac = (int **)(uStack_58 + 0x24);
          if (0x1f < (uint)((int)apiStack_6c[0] + (-4 - (int)piVar3))) {
                    /* WARNING: Subroutine does not return */
            ppiStack_ac = (int **)&UNK_0098c2b0;
            FUN_017167a3();
          }
        }
        ppiStack_b4 = (int **)0x98c225;
        piStack_b0 = piVar3;
        iVar4 = FUN_01674ea0();
      }
      uStack_5c = 0;
      uStack_58 = 0xf;
      apiStack_6c[0] = (int *)((uint)apiStack_6c[0] & 0xffffff00);
      goto LAB_0098c23a;
    }
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 4;
  }
  ppiStack_18 = &piStack_b0;
  ppiStack_ac = (int **)param_4;
  piStack_b0 = param_3;
  piStack_cc = (int *)0xe;
  uStack_b8 = 0;
  ppiStack_b4 = (int **)0xf;
  piStack_d0 = (int *)0x1935328;
  auStack_c8[0] = 0;
  piStack_d4 = (int *)0x98be71;
  FUN_005542c0();
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[2] = param_2[2] + 1;
    UNLOCK();
  }
  piStack_d0 = param_1;
  piStack_cc = param_2;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  piStack_d4 = (int *)0x98bea2;
  iVar4 = FUN_00988060();
LAB_0098c23a:
  if (piStack_40 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_40 + 1;
    iVar1 = *piVar3;
    iVar4 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      ppiStack_ac = (int **)0x98c250;
      (**(code **)*piStack_40)();
      LOCK();
      piVar3 = piStack_40 + 2;
      iVar1 = *piVar3;
      iVar4 = *piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        ppiStack_ac = (int **)0x98c260;
        iVar4 = (**(code **)(*piStack_40 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar3 = param_2 + 2;
    iVar1 = *piVar3;
    iVar4 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      ppiStack_ac = (int **)0x98c275;
      iVar4 = (**(code **)(*param_2 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar3 = param_4 + 1;
    iVar1 = *piVar3;
    iVar4 = *piVar3;
    *piVar3 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      ppiStack_ac = (int **)0x98c28b;
      iVar4 = (**(code **)*param_4)();
      LOCK();
      piVar3 = param_4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        ppiStack_ac = (int **)0x98c29a;
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 17924 ; VA 0x0098c2c0 ; FUN_0098c2c0 */

void __thiscall FUN_0098c2c0(int *param_1,undefined4 param_2,undefined4 param_3)

{
  code *pcVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  uint uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  uint uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0cf4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_005eef10(param_1);
  if (iVar3 == 0) {
    iVar3 = FUN_0064e920(param_1);
    if (iVar3 == 0) {
      ExceptionList = pvStack_10;
      return;
    }
    cVar2 = *(int *)(iVar3 + 0x124) == 2;
  }
  else {
    cVar2 = FUN_0068ba60();
  }
  if (cVar2 != '\0') {
    if (DAT_01d646e8 == '\0') {
      iVar3 = FUN_005c8880(param_1);
      if (iVar3 == 0) {
        ExceptionList = pvStack_10;
        return;
      }
      cVar2 = FUN_0068a900(param_1,1);
    }
    else {
      iVar3 = FUN_008f78c0();
      if (iVar3 == 0) {
        ExceptionList = pvStack_10;
        return;
      }
      cVar2 = FUN_0068a900(iVar3 + 0xc,1);
    }
    if (cVar2 == '\0') {
      uStack_24 = 0;
      uStack_20 = 0;
      FUN_0054ef60(param_3);
      iStack_8 = 0;
      pcVar1 = *(code **)(*param_1 + 8);
      uStack_1dc = thunk_FUN_0086f380();
      uStack_1d8 = 0;
      uStack_1d4 = param_2;
      uStack_1d8 = FUN_0086f410();
      iStack_8._0_1_ = 1;
      uStack_10c = FUN_0088cb40();
      uStack_108 = 0;
      uStack_104 = uStack_3c;
      uStack_100 = uStack_38;
      uStack_fc = uStack_34;
      uStack_f8 = uStack_30;
      uStack_3c = uStack_3c & 0xffffff00;
      uStack_2c = 0;
      uStack_28 = 0xf;
      uStack_108 = FUN_005c9d30();
      iStack_8._0_1_ = 2;
      uStack_1c = 0;
      uStack_18 = 0;
      uStack_14 = 0;
      FUN_00687980(&uStack_1dc,&uStack_3c,param_3);
      iStack_8._0_1_ = 3;
      (*pcVar1)(&DAT_021211d8,&uStack_1c,&uStack_24);
      iStack_8._0_1_ = 4;
      FUN_00577b20();
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_016f32d1(&uStack_1dc,0xd0,2,FUN_0056e5b0);
      if (0xf < uStack_28) {
        uVar5 = uStack_28 + 1;
        uVar4 = uStack_3c;
        if (0xfff < uVar5) {
          uVar4 = *(uint *)(uStack_3c - 4);
          uVar5 = uStack_28 + 0x24;
          if (0x1f < (uStack_3c - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar4,uVar5);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17925 ; VA 0x0098c4d0 ; FUN_0098c4d0 */

int FUN_0098c4d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                undefined4 param_5,int *param_6,int param_7)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d0d10;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (*(char *)(param_7 + 8) == '\0') {
    ExceptionList = &pvStack_10;
    if (param_4 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    param_7 = FUN_0096e860(param_1,param_2,param_3,param_4,param_7);
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    param_7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      param_7 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_7 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    param_7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_7 = (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_7 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_7;
}



/* FUNCTION 17926 ; VA 0x0098c5a0 ; FUN_0098c5a0 */

void FUN_0098c5a0(void)

{
  FUN_0064a9e0();
  return;
}



/* FUNCTION 17927 ; VA 0x0098c5b0 ; FUN_0098c5b0 */

void __thiscall FUN_0098c5b0(int param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  int in_stack_00000014;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d0d37;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (in_stack_00000014 == 0) {
    iVar1 = *(int *)(param_1 + 0xa8);
    ExceptionList = &pvStack_10;
    *(undefined4 *)(param_1 + 0xa8) = 0;
  }
  else {
    ExceptionList = &pvStack_10;
    iVar1 = FUN_01674e20(0xc);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (iVar1 == 0) {
      uVar2 = 0;
    }
    else {
      FUN_0054ef60(&param_2);
      uVar2 = FUN_0096b280();
    }
    iVar1 = *(int *)(param_1 + 0xa8);
    *(undefined4 *)(param_1 + 0xa8) = uVar2;
  }
  if (iVar1 != 0) {
    FUN_0096e370(iVar1);
  }
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar1 = param_2;
    if (0xfff < uVar3) {
      iVar1 = *(int *)(param_2 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17928 ; VA 0x0098c690 ; FUN_0098c690 */

int FUN_0098c690(undefined4 param_1,int *param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d0d68;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iStack_18 != 0) {
    iVar3 = FUN_008a65e0(param_1,0);
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iVar3 = (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 17929 ; VA 0x0098c750 ; FUN_0098c750 */

void __thiscall FUN_0098c750(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0xa1)) {
    *(char *)(param_1 + 0xa1) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 17930 ; VA 0x0098c780 ; FUN_0098c780 */

void __thiscall FUN_0098c780(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if ((undefined4 **)(param_1 + 0x58) != &param_2) {
    puVar1 = &param_2;
    if (0xf < in_stack_00000018) {
      puVar1 = param_2;
    }
    ExceptionList = &pvStack_10;
    FUN_005542c0(puVar1,in_stack_00000014);
  }
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    puVar1 = param_2;
    if (0xfff < uVar2) {
      puVar1 = (undefined4 *)param_2[-1];
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17931 ; VA 0x0098c800 ; FUN_0098c800 */

void __thiscall FUN_0098c800(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x140) = param_2;
  return;
}



/* FUNCTION 17932 ; VA 0x0098c810 ; FUN_0098c810 */

void __thiscall FUN_0098c810(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0xc0) = param_2;
  return;
}



/* FUNCTION 17933 ; VA 0x0098c820 ; FUN_0098c820 */

/* WARNING: Removing unreachable block (ram,0x0098c9b4) */
/* WARNING: Removing unreachable block (ram,0x0098c9c7) */
/* WARNING: Removing unreachable block (ram,0x0098c9ce) */
/* WARNING: Removing unreachable block (ram,0x0098c9d5) */

void FUN_0098c820(int *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0d88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  piVar1 = DAT_01ee3090;
  iStack_8 = 0;
  if ((int **)param_1 != &DAT_01ee3090) {
    iStack_8._0_1_ = 1;
    iStack_8._1_3_ = 0;
    FUN_00576720(DAT_01ee3090[1]);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    DAT_01ee3090[1] = (int)piVar1;
    *DAT_01ee3090 = (int)piVar1;
    DAT_01ee3090[2] = (int)piVar1;
    DAT_01ee3094 = 0;
    iVar3 = FUN_00961a70(*(undefined4 *)(*param_1 + 4),DAT_01ee3090,param_1);
    DAT_01ee3090[1] = iVar3;
    DAT_01ee3094 = param_1[1];
    piVar1 = (int *)DAT_01ee3090[1];
    if (*(char *)((int)piVar1 + 0xd) == '\0') {
      cVar4 = *(char *)(*piVar1 + 0xd);
      piVar5 = (int *)*piVar1;
      while (cVar4 == '\0') {
        cVar4 = *(char *)(*piVar5 + 0xd);
        piVar1 = piVar5;
        piVar5 = (int *)*piVar5;
      }
      *DAT_01ee3090 = (int)piVar1;
      iVar3 = *(int *)(DAT_01ee3090[1] + 8);
      cVar4 = *(char *)(iVar3 + 0xd);
      iVar2 = DAT_01ee3090[1];
      while (cVar4 == '\0') {
        cVar4 = *(char *)(*(int *)(iVar3 + 8) + 0xd);
        iVar2 = iVar3;
        iVar3 = *(int *)(iVar3 + 8);
      }
      DAT_01ee3090[2] = iVar2;
    }
    else {
      *DAT_01ee3090 = (int)DAT_01ee3090;
      DAT_01ee3090[2] = (int)DAT_01ee3090;
    }
  }
  if (DAT_01ee3094 != 0) {
    DAT_01ee2fc4 = 1;
  }
  if (DAT_01d65105 != '\0') {
    FUN_016774b0(DAT_01d65105,"Golden hashes set, should kick: %u",DAT_01ee2fc4);
  }
  piVar1 = (int *)*DAT_01ee3090;
  cVar4 = DAT_01d65105;
  piVar5 = DAT_01ee3090;
  while (piVar1 != piVar5) {
    if (cVar4 != '\0') {
      FUN_01677760(cVar4,"hash: %s",piVar1 + 4);
      piVar5 = DAT_01ee3090;
      cVar4 = DAT_01d65105;
    }
    FUN_00551320();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17934 ; VA 0x0098c9f0 ; FUN_0098c9f0 */

void __thiscall FUN_0098c9f0(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  int in_stack_00000024;
  uint in_stack_00000038;
  undefined4 in_stack_0000003c;
  undefined4 in_stack_00000040;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d0db8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_01255470(7,0,0,0);
  FUN_01255490();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (*(int **)(param_1 + 0xf4) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0xf4) + 0x38))(&param_4);
    FUN_0054ef60(&param_4);
    FUN_00934090();
    FUN_0054ef60(&stack0x00000024);
    FUN_00933860();
    FUN_00934ca0(param_2,param_3);
    FUN_00933eb0(in_stack_0000003c);
    FUN_00934c50(in_stack_00000040);
  }
  FUN_008a4940(PTR_DAT_02120610);
  FUN_01255500();
  if (0xf < in_stack_00000020) {
    uVar2 = in_stack_00000020 + 1;
    uVar3 = param_4;
    if (0xfff < uVar2) {
      uVar3 = *(uint *)(param_4 - 4);
      uVar2 = in_stack_00000020 + 0x24;
      if (0x1f < (param_4 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar2);
  }
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = param_4 & 0xffffff00;
  if (0xf < in_stack_00000038) {
    uVar3 = in_stack_00000038 + 1;
    iVar1 = in_stack_00000024;
    if (0xfff < uVar3) {
      iVar1 = *(int *)(in_stack_00000024 + -4);
      uVar3 = in_stack_00000038 + 0x24;
      if (0x1f < (in_stack_00000024 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17935 ; VA 0x0098cb50 ; FUN_0098cb50 */

void __thiscall FUN_0098cb50(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = 1;
  if (-1 < param_2) {
    iVar1 = param_2;
  }
  if (iVar1 != *(int *)(param_1 + 0xe4)) {
    *(int *)(param_1 + 0xe4) = iVar1;
    FUN_008a4940(&DAT_02120614);
    FUN_008a4940(&DAT_0212064c);
  }
  return;
}



/* FUNCTION 17936 ; VA 0x0098cb90 ; FUN_0098cb90 */

void __thiscall FUN_0098cb90(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = 1;
  if (-1 < param_2) {
    iVar1 = param_2;
  }
  if (iVar1 != *(int *)(param_1 + 0xe8)) {
    *(int *)(param_1 + 0xe8) = iVar1;
    FUN_008a4940(&DAT_02120684);
    FUN_008a4940(&DAT_021206bc);
  }
  return;
}



/* FUNCTION 17937 ; VA 0x0098cbe0 ; FUN_0098cbe0 */

void __thiscall FUN_0098cbe0(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  
  piVar2 = param_3;
  if ((param_3 != (int *)0x0) &&
     (iVar1 = param_3[3], iVar3 = FUN_00913630(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    piVar6 = (int *)param_1[1];
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    if (param_2 == (int *)0x0) {
      param_2 = (int *)&DAT_018e3e8c;
    }
    else {
      (**(code **)(*param_2 + 0x10))();
      param_2 = (int *)FUN_005543f0();
    }
    (**(code **)(*piVar2 + 0x10))();
    uVar4 = FUN_005543f0();
    (**(code **)(*param_1 + 0x4c))();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Expected %s got %s for %s:%s.",uVar5,uVar4,param_2,piVar6);
  }
  param_3 = piVar2;
  (**(code **)(*(int *)param_1[0xe] + 0x10))(param_2,&param_3);
  return;
}



/* FUNCTION 17938 ; VA 0x0098cc90 ; FUN_0098cc90 */

void __thiscall FUN_0098cc90(int param_1,float param_2)

{
  if ((NAN(param_2) || NAN(*(float *)(param_1 + 0xa4))) == (param_2 == *(float *)(param_1 + 0xa4)))
  {
    *(float *)(param_1 + 0xa4) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 17939 ; VA 0x0098ccc0 ; FUN_0098ccc0 */

void * __thiscall FUN_0098ccc0(void **param_1,void *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  void *pvVar5;
  bool bVar6;
  undefined8 uVar7;
  undefined auStack_50 [12];
  undefined4 uStack_44;
  void **ppvStack_40;
  code **ppcStack_3c;
  undefined auStack_30 [8];
  code *pcStack_28;
  undefined4 uStack_24;
  void **ppvStack_20;
  void *pvStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017d0de8;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  pvVar5 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1[0x3d] == (void *)0x0) {
    ExceptionList = &pvStack_10;
    if (param_3 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    param_1[0x3d] = param_2;
    piVar1 = (int *)param_1[0x3e];
    param_1[0x3e] = param_3;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[1] + -1;
      piVar1[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        ppcStack_3c = (code **)0x98cd2a;
        (**(code **)*piVar1)();
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          ppcStack_3c = (code **)0x98cd3b;
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    ppvStack_40 = (void **)0x98cd41;
    ppcStack_3c = (code **)param_1;
    pvStack_14 = (void *)FUN_00671ce0();
    if (pvStack_14 != (void *)0x0) {
      ppcStack_3c = (code **)auStack_30;
      ppvStack_40 = (void **)0x98cd5a;
      uVar4 = FUN_00927240();
      iStack_8._0_1_ = 1;
      ppvStack_40 = (void **)0x0;
      ppcStack_3c = (code **)0xf;
      auStack_50[0] = 0;
      FUN_005542c0("Players::setServerCreatedPlayer",0x1f);
      FUN_00a4c770(uVar4);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      ppcStack_3c = (code **)0x98cd97;
      FUN_005507b0();
      FUN_00a434b0(auStack_50);
      FUN_00933bf0();
    }
    ppcStack_3c = (code **)0x98cdb5;
    uVar7 = FUN_00928340();
    DAT_01f6ea1c = (undefined4)((ulonglong)uVar7 >> 0x20);
    DAT_01f6ea18 = (undefined4)uVar7;
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      uVar7 = CONCAT44(DAT_01f6ea1c,DAT_01f6ea18);
      UNLOCK();
    }
    DAT_01f6ea1c = (undefined4)((ulonglong)uVar7 >> 0x20);
    DAT_01f6ea18 = (undefined4)uVar7;
    ppvStack_40 = (void **)param_2;
    ppcStack_3c = (code **)param_3;
    uStack_44 = 0x98cdf3;
    FUN_0096ed10();
    FUN_01255470(9,0,0,0);
    FUN_01255490();
    ppcStack_3c = (code **)0x0;
    iStack_8._0_1_ = 2;
    uStack_44 = 0x98ce1c;
    ppvStack_40 = param_1;
    FUN_008a65e0();
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    ppcStack_3c = (code **)0x98ce28;
    FUN_01255500();
    ppcStack_3c = (code **)0x98ce30;
    FUN_009301d0();
    ppcStack_3c = (code **)PTR_DAT_02120610;
    ppvStack_40 = (void **)0x98ce3d;
    FUN_008a4940();
    if (DAT_01d646e0 == '\0') {
      ppvStack_40 = (void **)0x98cea9;
      ppcStack_3c = (code **)param_1;
      pvVar5 = (void *)FUN_005c8880();
      if (pvVar5 == (void *)0x0) goto LAB_0098ce6d;
      ppcStack_3c = (code **)0x1;
      uStack_44 = 0x98ceb8;
      ppvStack_40 = param_1;
      pvVar5 = (void *)FUN_0064a9e0();
      bVar6 = (char)pvVar5 == '\0';
    }
    else {
      ppvStack_40 = (void **)0x98ce4c;
      ppcStack_3c = (code **)param_1;
      pvVar5 = (void *)FUN_008f78c0();
      if (pvVar5 == (void *)0x0) goto LAB_0098ce6d;
      ppvStack_40 = (void **)((int)pvVar5 + 0xc);
      ppcStack_3c = (code **)0x1;
      uStack_44 = 0x98ce5e;
      cVar3 = FUN_0064a9e0();
      bVar6 = cVar3 == '\0';
      pvVar5 = (void *)(uint)bVar6;
    }
    if ((bVar6) && (DAT_01d64688 != '\0')) {
      pcStack_28 = FUN_00983600;
      uStack_24 = 0;
      ppcStack_3c = (code **)0x98ceea;
      ppvStack_20 = param_1;
      FUN_006eccd0();
      ppcStack_3c = &pcStack_28;
      ppvStack_40 = &pvStack_14;
      uStack_44 = 0x98cefd;
      FUN_00965af0();
      pvVar5 = pvStack_14;
      if (pvStack_14 != (void *)0x0) {
        piVar1 = (int *)((int)pvStack_14 + 4);
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          ppcStack_3c = (code **)pvStack_14;
          ppvStack_40 = (void **)0x98cf25;
          pvVar5 = (void *)FUN_01674ea0();
        }
      }
    }
  }
LAB_0098ce6d:
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar5 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      ppcStack_3c = (code **)0x98ce83;
      pvVar5 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        ppcStack_3c = (code **)0x98ce92;
        pvVar5 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 17940 ; VA 0x0098cf30 ; FUN_0098cf30 */

int FUN_0098cf30(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_0089be10(param_1,param_2);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 17941 ; VA 0x0098cfc0 ; FUN_0098cfc0 */

undefined * FUN_0098cfc0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0e0c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee334c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee334c);
    if (DAT_01ee334c == -1) {
      uStack_8 = 0;
      FUN_00e2cce0();
      FUN_016f3654(&LAB_01885bd0);
      FUN_016f37bf(&DAT_01ee334c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee32e8;
}



/* FUNCTION 17942 ; VA 0x0098d050 ; FUN_0098d050 */

undefined * FUN_0098d050(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0e2c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee33b4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee33b4);
    if (DAT_01ee33b4 == -1) {
      uStack_8 = 0;
      FUN_009a0d40();
      FUN_016f3654(&LAB_01885bf0);
      FUN_016f37bf(&DAT_01ee33b4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee3350;
}



/* FUNCTION 17943 ; VA 0x0098d0e0 ; FUN_0098d0e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0098d0e0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee33c4) {
    FUN_016f3809(&DAT_01ee33c4);
    if (DAT_01ee33c4 == -1) {
      _DAT_01ee33b8 = FUN_005c65e0;
      _DAT_01ee33bc = FUN_005c65e0;
      _DAT_01ee33c0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee33c4);
    }
  }
  return &DAT_01ee33b8;
}



/* FUNCTION 17944 ; VA 0x0098d150 ; FUN_0098d150 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0098d150(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee33d4) {
    FUN_016f3809(&DAT_01ee33d4);
    if (DAT_01ee33d4 == -1) {
      _DAT_01ee33c8 = FUN_005c65e0;
      _DAT_01ee33cc = FUN_005c65e0;
      _DAT_01ee33d0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee33d4);
    }
  }
  return &DAT_01ee33c8;
}



/* FUNCTION 17945 ; VA 0x0098d1c0 ; FUN_0098d1c0 */

void __thiscall
FUN_0098d1c0(int *param_1,undefined4 param_2,undefined4 param_3,int param_4,undefined4 param_5)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  bool bVar6;
  
  bVar6 = param_4 != 0;
  uVar1 = param_4 - 1;
  uVar2 = param_1[2];
  while ((-(uint)bVar6 & uVar1) < uVar2) {
    iVar4 = *(int *)(param_1[1] + 4) + 8;
    iVar5 = (int)param_1 + *(byte *)(param_1 + 3) + 0xd;
    uVar3 = FUN_005702d0(iVar4);
    FUN_00562fc0(&param_4,uVar3,iVar4,-(uint)(iVar5 != 0) & iVar5 + 1U);
    if (param_4 != 0) {
      FUN_0098a190(&param_4);
    }
    uVar2 = param_1[2];
  }
  (**(code **)(*param_1 + 8))(param_2,param_3,param_5);
  return;
}



/* FUNCTION 17946 ; VA 0x0098d250 ; FUN_0098d250 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __thiscall FUN_0098d250(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  char cVar10;
  int *piVar11;
  int iVar12;
  undefined4 uVar13;
  undefined4 *puVar14;
  uint uVar15;
  uint in_stack_00000018;
  undefined auStack_6c [68];
  int *piStack_28;
  int *piStack_24;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017d0e67;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  FUN_00972d80(&param_2);
  iVar12 = *(int *)(param_1 + 0xf4);
  if (*(int *)(iVar12 + 0xec) == 1) goto LAB_0098d473;
  piVar11 = (int *)FUN_01674e20(0x34);
  uStack_8 = 1;
  piStack_1c = piVar11;
  if (piVar11 == (int *)0x0) {
    piVar11 = (int *)0x0;
  }
  else {
    piVar11[1] = 1;
    piVar11[2] = 1;
    *piVar11 = (int)std::_Ref_count_obj<class_RBX::Network::NetworkStream>::vftable;
    FUN_006ab530();
  }
  piStack_28 = piVar11 + 3;
  uStack_8 = 2;
  auStack_14[0] = 0x88;
  piStack_24 = piVar11;
  FUN_006ad5e0(auStack_14,1);
  iVar12 = FUN_008f7870(param_1);
  if (iVar12 == 0) {
    iVar12 = 0;
    if (piVar11 == (int *)0x0) goto LAB_0098d473;
    LOCK();
    piVar1 = piVar11 + 1;
    iVar2 = *piVar1 + -1;
    iVar12 = *piVar1;
    *piVar1 = iVar2;
    UNLOCK();
  }
  else {
    piStack_1c = (int *)FUN_008f87a0();
    uStack_18 = FUN_0097eeb0();
    if (*(int *)(param_1 + 0xf8) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_1 + 0xf8) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_0098daf0(piVar11 + 3,piStack_1c,uStack_18,*(undefined4 *)(param_1 + 0xf4),
                 *(undefined4 *)(param_1 + 0xf8));
    FUN_006ae570(&param_2);
    uVar13 = (**(code **)(piVar11[3] + 8))();
    FUN_00971460(uVar13);
    uVar9 = uRam01ee2fe4;
    uVar8 = uRam01ee2fe0;
    uVar7 = uRam01ee2fdc;
    uVar6 = _DAT_01ee2fd8;
    uVar5 = uRam01ee2fd4;
    uVar4 = uRam01ee2fd0;
    uVar3 = uRam01ee2fcc;
    uVar13 = _DAT_01ee2fc8;
    LOCK();
    piVar11[1] = piVar11[1] + 1;
    UNLOCK();
    FUN_006afb30(piVar11 + 3,piVar11,1,2,2,uVar13,uVar3,uVar4,uVar5,uVar6,uVar7,uVar8,uVar9,1,0);
    puVar14 = &param_2;
    if (0xf < in_stack_00000018) {
      puVar14 = param_2;
    }
    if (*(int *)(param_1 + 0xf8) != 0) {
      LOCK();
      piVar1 = (int *)(*(int *)(param_1 + 0xf8) + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    FUN_0096b650(puVar14,1,*(undefined4 *)(param_1 + 0xf4),*(undefined4 *)(param_1 + 0xf8));
    uStack_8 = 3;
    if (*(int *)(param_1 + 0xf4) == 0) {
LAB_0098d42e:
      FUN_005e6780(auStack_6c);
      FUN_00989e30(auStack_6c);
    }
    else {
      cVar10 = FUN_009281e0();
      if (cVar10 == '\0') goto LAB_0098d42e;
    }
    FUN_0096d050();
    piVar1 = piVar11 + 1;
    LOCK();
    iVar2 = *piVar1 + -1;
    iVar12 = *piVar1;
    *piVar1 = iVar2;
    UNLOCK();
  }
  if (iVar2 == 0) {
    iVar12 = (**(code **)*piVar11)();
    LOCK();
    piVar1 = piVar11 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iVar12 = (**(code **)(*piVar11 + 4))();
    }
  }
LAB_0098d473:
  if (0xf < in_stack_00000018) {
    uVar15 = in_stack_00000018 + 1;
    puVar14 = param_2;
    if (0xfff < uVar15) {
      puVar14 = (undefined4 *)param_2[-1];
      uVar15 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar14))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar12 = FUN_01674ea0(puVar14,uVar15);
  }
  ExceptionList = pvStack_10;
  return iVar12;
}



/* FUNCTION 17947 ; VA 0x0098d4c0 ; FUN_0098d4c0 */

void FUN_0098d4c0(void)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  uint *puVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  undefined8 uVar9;
  int aiStack_cc [5];
  uint uStack_b8;
  uint auStack_b4 [4];
  undefined4 uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined4 uStack_8c;
  uint uStack_88;
  uint auStack_84 [4];
  undefined4 uStack_74;
  uint uStack_70;
  uint auStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  undefined auStack_54 [8];
  undefined auStack_4c [8];
  undefined auStack_44 [8];
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined auStack_24 [8];
  undefined8 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8._0_1_ = 0xff;
  uStack_8._1_3_ = 0xffffff;
  puStack_c = &LAB_017d0ed0;
  pvStack_10 = ExceptionList;
  uVar7 = 0;
  uVar8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01681be0();
  if (iVar3 != 0) {
    do {
      FUN_01680e60(auStack_24,uVar8);
      FUN_0167eea0(auStack_44,&DAT_018c1fd8);
      FUN_0167eea0(auStack_4c,&DAT_018c387c);
      FUN_0167eea0(auStack_54,"requestedUsername");
      cVar2 = FUN_01682670();
      if (cVar2 != '\0') {
        cVar2 = FUN_01682670();
        if (cVar2 != '\0') {
          uVar9 = FUN_0167e4f0();
          uStack_5c = 0;
          uStack_58 = 0xf;
          auStack_6c[0] = auStack_6c[0] & 0xffffff00;
          uStack_8 = 0;
          uStack_1c = uVar9;
          FUN_01681580(aiStack_cc,auStack_6c);
          uStack_8._0_1_ = 2;
          if (0xf < uStack_58) {
            uVar5 = uStack_58 + 1;
            uVar6 = auStack_6c[0];
            if (0xfff < uVar5) {
              uVar6 = *(uint *)(auStack_6c[0] - 4);
              uVar5 = uStack_58 + 0x24;
              if (0x1f < (auStack_6c[0] - uVar6) - 4) goto LAB_0098d85c;
            }
            FUN_01674ea0(uVar6,uVar5);
          }
          uStack_5c = 0;
          uStack_58 = 0xf;
          auStack_6c[0] = auStack_6c[0] & 0xffffff00;
          cVar2 = FUN_01682670();
          if (cVar2 == '\0') {
            puVar4 = (uint *)FUN_0054ef60(aiStack_cc);
            uStack_14 = uStack_14 | 4;
          }
          else {
            uStack_74 = 0;
            uStack_70 = 0xf;
            auStack_84[0] = auStack_84[0] & 0xffffff00;
            uStack_8 = CONCAT31(uStack_8._1_3_,3);
            uStack_14 = uVar7 | 1;
            puVar4 = (uint *)FUN_01681580(auStack_b4,auStack_84);
            uStack_14 = uVar7 | 3;
          }
          uStack_3c = *puVar4;
          uStack_38 = puVar4[1];
          uStack_34 = puVar4[2];
          uStack_30 = puVar4[3];
          uStack_2c = puVar4[4];
          uStack_28 = puVar4[5];
          puVar4[4] = 0;
          puVar4[5] = 0xf;
          *(undefined *)puVar4 = 0;
          uStack_8._0_1_ = 5;
          uStack_8._1_3_ = 0;
          if ((uStack_14 & 4) != 0) {
            uStack_14 = uStack_14 & 0xfffffffb;
            if (0xf < uStack_88) {
              uVar6 = uStack_88 + 1;
              uVar7 = uStack_9c;
              if (0xfff < uVar6) {
                uVar7 = *(uint *)(uStack_9c - 4);
                uVar6 = uStack_88 + 0x24;
                if (0x1f < (uStack_9c - uVar7) - 4) goto LAB_0098d85c;
              }
              FUN_01674ea0(uVar7,uVar6);
            }
            uStack_8c = 0;
            uStack_88 = 0xf;
            uStack_9c = uStack_9c & 0xffffff00;
          }
          uStack_8._0_1_ = 6;
          if ((uStack_14 & 2) != 0) {
            uStack_14 = uStack_14 & 0xfffffffd;
            if (0xf < uStack_a0) {
              uVar6 = uStack_a0 + 1;
              uVar7 = auStack_b4[0];
              if (0xfff < uVar6) {
                uVar7 = *(uint *)(auStack_b4[0] - 4);
                uVar6 = uStack_a0 + 0x24;
                if (0x1f < (auStack_b4[0] - uVar7) - 4) goto LAB_0098d85c;
              }
              FUN_01674ea0(uVar7,uVar6);
            }
            uStack_a4 = 0;
            uStack_a0 = 0xf;
            auStack_b4[0] = auStack_b4[0] & 0xffffff00;
          }
          uStack_8._0_1_ = 7;
          if ((uStack_14 & 1) != 0) {
            uStack_14 = uStack_14 & 0xfffffffe;
            if (0xf < uStack_70) {
              uVar6 = uStack_70 + 1;
              uVar7 = auStack_84[0];
              if (0xfff < uVar6) {
                uVar7 = *(uint *)(auStack_84[0] - 4);
                uVar6 = uStack_70 + 0x24;
                if (0x1f < (auStack_84[0] - uVar7) - 4) goto LAB_0098d85c;
              }
              FUN_01674ea0(uVar7,uVar6);
            }
            uStack_74 = 0;
            uStack_70 = 0xf;
            auStack_84[0] = auStack_84[0] & 0xffffff00;
          }
          uVar1 = (undefined4)uStack_1c;
          FUN_00f89750(&uStack_3c,uStack_1c);
          FUN_00f89750(aiStack_cc,uVar1,uStack_1c._4_4_);
          uStack_8._0_1_ = 2;
          if (0xf < uStack_28) {
            uVar6 = uStack_28 + 1;
            uVar7 = uStack_3c;
            if (0xfff < uVar6) {
              uVar7 = *(uint *)(uStack_3c - 4);
              uVar6 = uStack_28 + 0x24;
              if (0x1f < (uStack_3c - uVar7) - 4) goto LAB_0098d85c;
            }
            FUN_01674ea0(uVar7,uVar6);
          }
          uStack_2c = 0;
          uStack_28 = 0xf;
          uStack_3c = uStack_3c & 0xffffff00;
          uStack_8._0_1_ = 0xff;
          uStack_8._1_3_ = 0xffffff;
          uVar7 = uStack_14;
          if (0xf < uStack_b8) {
            uVar7 = uStack_b8 + 1;
            iVar3 = aiStack_cc[0];
            if (0xfff < uVar7) {
              iVar3 = *(int *)(aiStack_cc[0] + -4);
              uVar7 = uStack_b8 + 0x24;
              if (0x1f < (aiStack_cc[0] - iVar3) - 4U) {
LAB_0098d85c:
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
            FUN_01674ea0(iVar3,uVar7);
            uVar7 = uStack_14;
          }
        }
      }
      uVar8 = uVar8 + 1;
      uVar6 = FUN_01681be0();
    } while (uVar8 < uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17948 ; VA 0x0098d870 ; FUN_0098d870 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __thiscall FUN_0098d870(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  int *in_stack_00000020;
  undefined4 uVar8;
  int *piVar9;
  undefined auStack_78 [68];
  int aiStack_34 [2];
  undefined auStack_2c [4];
  int *apiStack_28 [3];
  int *piStack_1c;
  int iStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d0f08;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_00972d80(&param_2);
  piStack_1c = (int *)(param_1 + 0xf4);
  iVar3 = *piStack_1c;
  if (*(int *)(iVar3 + 0xec) == 1) {
    if (0xf < in_stack_00000018) {
      uVar7 = in_stack_00000018 + 1;
      puVar6 = param_2;
      if (0xfff < uVar7) {
        puVar6 = (undefined4 *)param_2[-1];
        uVar7 = in_stack_00000018 + 0x24;
        if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      iVar3 = FUN_01674ea0(puVar6,uVar7);
    }
    piVar9 = in_stack_00000020;
    in_stack_00000014 = 0;
    in_stack_00000018 = 0xf;
    param_2 = (undefined4 *)((uint)param_2 & 0xffffff00);
    if (in_stack_00000020 != (int *)0x0) {
      LOCK();
      piVar1 = in_stack_00000020 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*in_stack_00000020)();
        LOCK();
        piVar1 = piVar9 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piVar9 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return iVar3;
  }
  FUN_00562c90(aiStack_34,&stack0x0000001c);
  uStack_8._0_1_ = 2;
  if ((aiStack_34[0] != 0) && (*(int *)(aiStack_34[0] + 0x34) == param_1)) {
    FUN_00607880(apiStack_28);
    uStack_8._0_1_ = 3;
    auStack_14[0] = 0x8c;
    FUN_006ad5e0(auStack_14,1);
    iVar3 = FUN_008f7870(param_1);
    if (iVar3 != 0) {
      uVar4 = FUN_008f87a0();
      uVar5 = FUN_0097eeb0();
      FUN_00557fc0(piStack_1c);
      FUN_0098daf0(apiStack_28[0],uVar4,uVar5);
      uVar5 = FUN_0097eeb0();
      FUN_00557fc0(aiStack_34);
      FUN_0098daf0(apiStack_28[0],uVar4,uVar5);
      FUN_006ae570(&param_2);
      uVar4 = (**(code **)(*apiStack_28[0] + 8))();
      iVar3 = iStack_18;
      FUN_00971460(uVar4);
      uVar5 = 0;
      uVar4 = 1;
      FUN_00557fc0(apiStack_28);
      FUN_006afb30();
      piVar9 = aiStack_34;
      puVar6 = &param_2;
      if (0xf < in_stack_00000018) {
        puVar6 = param_2;
      }
      uVar8 = 0x98da5e;
      FUN_00557fc0(piVar9);
      FUN_00557fc0(iVar3 + 0xf4);
      FUN_0096b520(puVar6,2,uVar8,piVar9,uVar4,uVar5);
      uStack_8._0_1_ = 4;
      FUN_00989df0(auStack_78);
      FUN_0096d050();
    }
    FUN_00550b30();
    FUN_00550b30();
    FUN_005507b0();
    iVar3 = FUN_00550b30();
    ExceptionList = pvStack_10;
    return iVar3;
  }
  FUN_00550130("Player object is not a player to chat to");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_2c,&DAT_01c17198);
}



/* FUNCTION 17949 ; VA 0x0098daf0 ; FUN_0098daf0 */

int FUN_0098daf0(undefined4 param_1,undefined4 param_2,int *param_3,int param_4,int *param_5)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined auStack_1c [4];
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  iVar7 = param_4;
  puStack_c = &LAB_017d0f38;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  param_3 = (int *)*param_3;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_4 + 0x14) == 0) {
    piVar1 = param_3 + 7;
    ExceptionList = &pvStack_10;
    piStack_14 = piVar1;
    iVar5 = FUN_016dee6d(piVar1);
    if (iVar5 != 0) {
      FUN_016df3c9(iVar5);
    }
    uStack_8._0_1_ = 1;
    if (*(int *)(iVar7 + 0x14) == 0) {
      puVar6 = (undefined4 *)FUN_0060e0c0(auStack_1c,iVar7);
      uStack_8._0_1_ = 2;
      iVar5 = FUN_006149c0(iVar7 + 0x18);
      uVar2 = *puVar6;
      uVar3 = puVar6[1];
      *puVar6 = 0;
      puVar6[1] = 0;
      *(undefined4 *)(iVar5 + 8) = uVar2;
      piVar4 = *(int **)(iVar5 + 0xc);
      *(undefined4 *)(iVar5 + 0xc) = uVar3;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_18[2] + -1;
        piStack_18[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
      if (param_3 != (int *)0x0) {
        LOCK();
        *param_3 = *param_3 + 1;
        UNLOCK();
      }
      piVar4 = *(int **)(iVar7 + 0x14);
      *(int **)(iVar7 + 0x14) = param_3;
      param_3 = piVar4;
      FUN_00611620();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    iVar7 = FUN_016deec8(piVar1);
    if (iVar7 != 0) {
      FUN_016df3c9(iVar7);
    }
    uStack_8 = uStack_8 & 0xffffff00;
  }
  iVar7 = param_4;
  FUN_006ad220(param_1,param_2,param_4 + 0x18);
  param_3 = *(int **)(iVar7 + 0x1c);
  FUN_006a5c10(&param_3,&piStack_14,4);
  iVar7 = FUN_006ad5e0(&piStack_14,4);
  piVar1 = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar4 = param_5 + 1;
    iVar5 = *piVar4;
    iVar7 = *piVar4;
    *piVar4 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar7 = (**(code **)*param_5)();
      LOCK();
      piVar4 = piVar1 + 2;
      iVar5 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        iVar7 = (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 17950 ; VA 0x0098dc70 ; FUN_0098dc70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0098dc70(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined *puVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  
  uVar6 = FUN_008880b0();
  iVar5 = _tls_index;
  *param_1 = uVar6;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar5 * 4) + 0x34) < DAT_01ead3b8) {
    FUN_016f3809(&DAT_01ead3b8);
    if (DAT_01ead3b8 == -1) {
      _DAT_01ead3ac = FUN_0057bbb0;
      _DAT_01ead3b0 = FUN_005880a0;
      DAT_01ead3b4 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ead3b8);
    }
  }
  puVar2 = (undefined *)param_1[1];
  if (puVar2 == &DAT_01ead3ac) {
    uVar6 = *param_2;
    uVar3 = param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    param_1[2] = uVar6;
    piVar4 = (int *)param_1[3];
    param_1[3] = uVar3;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piVar4 + 4))();
        }
      }
      return param_1;
    }
    return param_1;
  }
  if (puVar2 != (undefined *)0x0) {
    (**(code **)(puVar2 + 8))(param_1 + 2);
    param_1[1] = 0;
  }
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[2] = *param_2;
  param_1[3] = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  param_1[1] = &DAT_01ead3ac;
  return param_1;
}



/* FUNCTION 17951 ; VA 0x0098dda0 ; FUN_0098dda0 */

undefined4 * __thiscall FUN_0098dda0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  
  uVar6 = FUN_008881d0();
  iVar5 = _tls_index;
  *param_1 = uVar6;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar5 * 4) + 0x34) < DAT_01ea8a9c) {
    FUN_016f3809(&DAT_01ea8a9c);
    if (DAT_01ea8a9c == -1) {
      DAT_01ea8a90 = FUN_0057bbb0;
      DAT_01ea8a94 = FUN_005880a0;
      DAT_01ea8a98 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ea8a9c);
    }
  }
  puVar2 = (undefined4 *)param_1[1];
  if ((code **)puVar2 == &DAT_01ea8a90) {
    uVar6 = *param_2;
    uVar3 = param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    param_1[2] = uVar6;
    piVar4 = (int *)param_1[3];
    param_1[3] = uVar3;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piVar4 + 4))();
        }
      }
      return param_1;
    }
    return param_1;
  }
  if (puVar2 != (undefined4 *)0x0) {
    (*(code *)puVar2[2])(param_1 + 2);
    param_1[1] = 0;
  }
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[2] = *param_2;
  param_1[3] = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  param_1[1] = &DAT_01ea8a90;
  return param_1;
}



/* FUNCTION 17952 ; VA 0x0098ded0 ; FUN_0098ded0 */

int __thiscall FUN_0098ded0(int *param_1,int param_2,undefined4 *param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0f50;
  pvStack_10 = ExceptionList;
  iVar6 = *param_1;
  iVar3 = (param_1[1] - iVar6) / 0xd0;
  if (iVar3 == 0x13b13b1) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar4 = (param_1[2] - iVar6) / 0xd0;
  uVar7 = uVar1;
  if ((uVar4 <= 0x13b13b1 - (uVar4 >> 1)) && (uVar7 = (uVar4 >> 1) + uVar4, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00578090(uVar7);
  iVar6 = ((param_2 - iVar6) / 0xd0) * 0xd0;
  puVar2 = (undefined4 *)(iVar6 + iVar5);
  uStack_8 = 0;
  *puVar2 = *param_3;
  puVar2[1] = 0;
  if ((undefined4 *)param_3[1] != (undefined4 *)0x0) {
    (**(code **)param_3[1])(param_3 + 2,puVar2 + 2);
  }
  puVar2[1] = param_3[1];
  if (param_2 == param_1[1]) {
    FUN_005cb790(*param_1,param_1[1],iVar5);
  }
  else {
    FUN_005cb700(*param_1,param_2,iVar5);
    FUN_005cb700(param_2,param_1[1],puVar2 + 0x34);
  }
  uStack_8 = 0xffffffff;
  FUN_005cb2e0(iVar5,iVar3 + 1,uVar7);
  ExceptionList = pvStack_10;
  return *param_1 + iVar6;
}



/* FUNCTION 17953 ; VA 0x0098e036 ; Catch_All@0098e036 */

void Catch_All_0098e036(void)

{
  int unaff_EBP;
  
  FUN_005762e0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x18));
  FUN_0057d370(*(undefined4 *)(unaff_EBP + -0x30),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17954 ; VA 0x0098e070 ; FUN_0098e070 */

void FUN_0098e070(uint *param_1,uint *param_2,byte param_3)

{
  byte bVar1;
  uint uVar2;
  
  uVar2 = (uint)param_3;
  bVar1 = *(byte *)((int)&PTR_01a90bb0 + uVar2);
  if (*param_1 != 0) {
    *param_2 = *param_2 << 6 | uVar2 & 0x3f;
    *param_1 = (uint)(byte)(&DAT_01a90cb0)[*param_1 * 0x10 + (uint)bVar1];
    return;
  }
  *param_2 = 0xff >> (bVar1 & 0x1f) & uVar2;
  *param_1 = (uint)(byte)(&DAT_01a90cb0)[*param_1 * 0x10 + (uint)bVar1];
  return;
}



/* FUNCTION 17955 ; VA 0x0098e0d0 ; FUN_0098e0d0 */

bool FUN_0098e0d0(byte *param_1,int param_2)

{
  byte bVar1;
  uint uVar2;
  
  uVar2 = 0;
  if (param_2 != 0) {
    do {
      bVar1 = *param_1;
      param_1 = param_1 + 1;
      uVar2 = (uint)(byte)(&DAT_01a90cb0)
                          [uVar2 * 0x10 + (uint)*(byte *)((int)&PTR_01a90bb0 + (uint)bVar1)];
      param_2 = param_2 + -1;
    } while (param_2 != 0);
  }
  return uVar2 == 0;
}



/* FUNCTION 17956 ; VA 0x0098e110 ; FUN_0098e110 */

undefined4 FUN_0098e110(undefined4 param_1,int param_2)

{
  undefined4 *puVar1;
  char cVar2;
  int iVar3;
  undefined4 uStack_e0;
  undefined4 *puStack_dc;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0f6b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0087cde0(DAT_01ede658);
  while( true ) {
    if (iVar3 == 0) {
      ExceptionList = pvStack_10;
      return 1;
    }
    uStack_e0 = FUN_00888530();
    puStack_dc = (undefined4 *)0x0;
    uStack_8 = 0;
    cVar2 = FUN_0098e500(iVar3,&uStack_e0);
    if (cVar2 == '\0') break;
    puVar1 = *(undefined4 **)(param_2 + 4);
    if (*(undefined4 **)(param_2 + 8) == puVar1) {
      FUN_0098ded0(puVar1,&uStack_e0);
    }
    else {
      *puVar1 = uStack_e0;
      puVar1[1] = 0;
      if (puStack_dc != (undefined4 *)0x0) {
        (*(code *)*puStack_dc)(auStack_d8,puVar1 + 2);
      }
      puVar1[1] = puStack_dc;
      *(int *)(param_2 + 4) = *(int *)(param_2 + 4) + 0xd0;
    }
    iVar3 = FUN_0087ce10(iVar3);
    uStack_8 = 2;
    if (puStack_dc != (undefined4 *)0x0) {
      (*(code *)puStack_dc[2])(auStack_d8);
    }
    uStack_8 = 0xffffffff;
  }
  uStack_8 = 1;
  if (puStack_dc != (undefined4 *)0x0) {
    (*(code *)puStack_dc[2])(auStack_d8);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 17957 ; VA 0x0098e260 ; FUN_0098e260 */

undefined4 FUN_0098e260(undefined4 param_1,int *param_2)

{
  undefined4 **ppuVar1;
  bool bVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint *puVar7;
  uint *puVar8;
  uint *puVar9;
  uint uStack_108;
  undefined4 *puStack_104;
  undefined auStack_100 [200];
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  uint *puStack_20;
  int iStack_1c;
  uint *puStack_18;
  undefined uStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0f93;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_1c = FUN_0087cde0(DAT_01ede650);
  iVar4 = iStack_1c;
  while( true ) {
    if (iVar4 == 0) {
      ExceptionList = pvStack_10;
      return 1;
    }
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    uStack_8 = 0;
    uStack_108 = FUN_00888530();
    puStack_104 = (undefined4 *)0x0;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    cStack_11 = '\0';
    iVar4 = FUN_0087cde0(DAT_01ede654);
    bVar2 = false;
    if ((iVar4 != 0) && (cVar3 = FUN_0087ca30(), cVar3 != '\0')) {
      cVar3 = FUN_0087d060(auStack_38);
      bVar2 = false;
      if (cVar3 != '\0') {
        bVar2 = true;
      }
    }
    iVar4 = FUN_0087cde0(DAT_01ede658);
    cVar3 = cStack_11;
    if (iVar4 != 0) {
      cVar3 = FUN_0098e500(iVar4,&uStack_108);
    }
    if ((!bVar2) || (cVar3 == '\0')) break;
    puStack_18 = (uint *)*param_2;
    cVar3 = *(char *)((int)puStack_18[1] + 0xd);
    puVar8 = puStack_18;
    puVar7 = (uint *)puStack_18[1];
    while (cVar3 == '\0') {
      cVar3 = FUN_00570370(puVar7 + 4,auStack_38);
      if (cVar3 == '\0') {
        puVar9 = (uint *)*puVar7;
      }
      else {
        puVar9 = (uint *)puVar7[2];
        puVar7 = puVar8;
      }
      puVar8 = puVar7;
      puVar7 = puVar9;
      cVar3 = *(char *)((int)puVar9 + 0xd);
    }
    if ((puVar8 == puStack_18) || (cVar3 = FUN_00570370(auStack_38,puVar8 + 4), cVar3 != '\0')) {
      puStack_18 = auStack_38;
      iVar4 = FUN_00602c10(&DAT_018bdeda,&puStack_18,&uStack_12);
      FUN_006040a0(&puStack_20,puVar8,iVar4 + 0x10,iVar4);
      puVar8 = puStack_20;
    }
    ppuVar1 = (undefined4 **)(puVar8 + 0xb);
    puVar8[10] = uStack_108;
    if (&puStack_104 != ppuVar1) {
      if (*ppuVar1 != (undefined4 *)0x0) {
        (*(code *)(*ppuVar1)[2])(puVar8 + 0xc);
        *ppuVar1 = (undefined4 *)0x0;
      }
      if (puStack_104 != (undefined4 *)0x0) {
        (*(code *)*puStack_104)(auStack_100,puVar8 + 0xc);
        *ppuVar1 = puStack_104;
      }
    }
    iVar4 = FUN_0087ce10(iStack_1c);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    iStack_1c = iVar4;
    if (puStack_104 != (undefined4 *)0x0) {
      (*(code *)puStack_104[2])(auStack_100);
    }
    uStack_8 = 0xffffffff;
    if (0xf < uStack_24) {
      uVar6 = uStack_24 + 1;
      uVar5 = auStack_38[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_38[0] - 4);
        uVar6 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar5) - 4) {
LAB_0098e4f8:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puStack_104 != (undefined4 *)0x0) {
    (*(code *)puStack_104[2])(auStack_100);
  }
  if (0xf < uStack_24) {
    uVar6 = uStack_24 + 1;
    uVar5 = auStack_38[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_38[0] - 4);
      uVar6 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar5) - 4) goto LAB_0098e4f8;
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 17958 ; VA 0x0098e500 ; FUN_0098e500 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0098e500(undefined4 param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 ***pppuVar3;
  char cVar4;
  undefined uVar5;
  int iVar6;
  int *piVar7;
  int iVar8;
  undefined4 uVar9;
  undefined4 ****ppppuVar10;
  undefined4 ****ppppuVar11;
  uint uVar12;
  int *piVar13;
  uint uVar14;
  undefined4 ***apppuStack_4c [4];
  uint uStack_3c;
  uint uStack_38;
  undefined auStack_34 [12];
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0ff7;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar6 = FUN_0087cde0(DAT_01ede648);
  if (iVar6 == 0) {
    iVar6 = FUN_0087cde0(DAT_01ede64c);
    if (iVar6 != 0) {
      FUN_005cac50(&piStack_1c);
      uStack_8 = 3;
      cVar4 = FUN_0098e110(iVar6,piStack_1c);
      if (cVar4 == '\0') {
        FUN_00550b30();
        ExceptionList = pvStack_10;
        return 0;
      }
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      piStack_24 = piStack_1c;
      piStack_20 = piStack_18;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_005c1810(&piStack_24);
      FUN_00550b30();
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return 1;
    }
    iVar6 = FUN_0087cdb0(DAT_01ede65c);
    if (iVar6 != 0) {
      uStack_3c = 0;
      uStack_38 = 0xf;
      apppuStack_4c[0] = (undefined4 ***)((uint)apppuStack_4c[0] & 0xffffff00);
      uStack_8 = 5;
      cVar4 = FUN_0087d060(apppuStack_4c);
      uVar12 = uStack_38;
      pppuVar3 = apppuStack_4c[0];
      if (cVar4 != '\0') {
        ppppuVar10 = apppuStack_4c;
        if (0xf < uStack_38) {
          ppppuVar10 = (undefined4 ****)apppuStack_4c[0];
        }
        cVar4 = FUN_0055c360(ppppuVar10,uStack_3c,"boolean",7);
        if (cVar4 == '\0') {
          ppppuVar10 = apppuStack_4c;
          if (0xf < uVar12) {
            ppppuVar10 = (undefined4 ****)pppuVar3;
          }
          cVar4 = FUN_0055c360(ppppuVar10,uStack_3c,"string",6);
          if (cVar4 != '\0') {
            piStack_24 = (int *)0x0;
            piStack_20 = (int *)0xf;
            auStack_34[0] = 0;
            uStack_8 = CONCAT31(uStack_8._1_3_,6);
            cVar4 = FUN_0087d060(auStack_34);
            if (cVar4 == '\0') {
              FUN_005507b0();
              FUN_005507b0();
              ExceptionList = pvStack_10;
              return 0;
            }
            FUN_005c16d0(auStack_34);
            FUN_005507b0();
            FUN_005507b0();
            ExceptionList = pvStack_10;
            return 1;
          }
          ppppuVar10 = apppuStack_4c;
          if (0xf < uVar12) {
            ppppuVar10 = (undefined4 ****)pppuVar3;
          }
          cVar4 = FUN_0055c360(ppppuVar10,uStack_3c,&DAT_01936d24,6);
          if (cVar4 == '\0') {
            ppppuVar10 = apppuStack_4c;
            if (0xf < uVar12) {
              ppppuVar10 = (undefined4 ****)pppuVar3;
            }
            cVar4 = FUN_0055c360(ppppuVar10,uStack_3c,"integer",7);
            if (cVar4 == '\0') {
              ppppuVar10 = apppuStack_4c;
              if (0xf < uVar12) {
                ppppuVar10 = (undefined4 ****)pppuVar3;
              }
              cVar4 = FUN_0055c360(ppppuVar10,uStack_3c,"instance",8);
              if ((cVar4 != '\0') && (iVar6 = FUN_0087cde0(DAT_01ede5a0), iVar6 != 0)) {
                piStack_28 = (int *)0x0;
                piStack_24 = (int *)0x0;
                piStack_20 = (int *)0x0;
                uStack_8 = CONCAT31(uStack_8._1_3_,7);
                FUN_00f261e0(iVar6,&piStack_28);
                piVar7 = piStack_28;
                piStack_18 = piStack_24;
                if ((int)piStack_24 - (int)piStack_28 >> 3 == 1) {
                  uVar9 = FUN_0088cdc0();
                  iVar6 = _tls_index;
                  *param_2 = uVar9;
                  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar6 * 4) + 0x34) <
                       DAT_01ead288) && (FUN_016f3809(&DAT_01ead288), DAT_01ead288 == -1)) {
                    DAT_01ead27c = FUN_0057bbb0;
                    _DAT_01ead280 = FUN_005880a0;
                    DAT_01ead284 = FUN_0057d5e0;
                    FUN_016f37bf(&DAT_01ead288);
                  }
                  puVar1 = (undefined4 *)param_2[1];
                  if ((code **)puVar1 == &DAT_01ead27c) {
                    iVar6 = piVar7[1];
                    if (iVar6 != 0) {
                      LOCK();
                      *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
                      UNLOCK();
                      iVar6 = piVar7[1];
                    }
                    param_2[2] = *piVar7;
                    piVar7 = (int *)param_2[3];
                    param_2[3] = iVar6;
                    if (piVar7 != (int *)0x0) {
                      LOCK();
                      iVar6 = piVar7[1] + -1;
                      piVar7[1] = iVar6;
                      UNLOCK();
                      if (iVar6 == 0) {
                        (**(code **)*piVar7)();
                        LOCK();
                        iVar6 = piVar7[2] + -1;
                        piVar7[2] = iVar6;
                        UNLOCK();
                        if (iVar6 == 0) {
                          (**(code **)(*piVar7 + 4))();
                        }
                      }
                    }
                  }
                  else {
                    if (puVar1 != (undefined4 *)0x0) {
                      (*(code *)puVar1[2])(param_2 + 2);
                      param_2[1] = 0;
                    }
                    param_2[2] = 0;
                    param_2[3] = 0;
                    if (piVar7[1] != 0) {
                      LOCK();
                      piVar13 = (int *)(piVar7[1] + 4);
                      *piVar13 = *piVar13 + 1;
                      UNLOCK();
                    }
                    param_2[2] = *piVar7;
                    param_2[3] = piVar7[1];
                    param_2[1] = &DAT_01ead27c;
                  }
                  if (piStack_28 != (int *)0x0) {
                    piStack_18 = piStack_24;
                    piVar7 = piStack_24;
                    piVar13 = piStack_28;
                    if (piStack_28 != piStack_24) {
                      do {
                        piVar2 = (int *)piVar13[1];
                        if (piVar2 != (int *)0x0) {
                          LOCK();
                          iVar6 = piVar2[1] + -1;
                          piVar2[1] = iVar6;
                          UNLOCK();
                          piVar7 = piStack_18;
                          if (iVar6 == 0) {
                            (**(code **)*piVar2)();
                            LOCK();
                            iVar6 = piVar2[2] + -1;
                            piVar2[2] = iVar6;
                            UNLOCK();
                            piVar7 = piStack_18;
                            if (iVar6 == 0) {
                              (**(code **)(*piVar2 + 4))();
                              piVar7 = piStack_18;
                            }
                          }
                        }
                        piVar13 = piVar13 + 2;
                      } while (piVar13 != piVar7);
                    }
                    uVar12 = (int)piStack_20 - (int)piStack_28 & 0xfffffff8;
                    piVar7 = piStack_28;
                    if (0xfff < uVar12) {
                      piVar7 = (int *)piStack_28[-1];
                      uVar12 = uVar12 + 0x23;
                      if (0x1f < (uint)((int)piStack_28 + (-4 - (int)piVar7))) {
                    /* WARNING: Subroutine does not return */
                        FUN_017167a3();
                      }
                    }
                    FUN_01674ea0(piVar7,uVar12);
                  }
                  FUN_005507b0();
                  ExceptionList = pvStack_10;
                  return 1;
                }
                if (piStack_28 != (int *)0x0) {
                  piVar7 = piStack_24;
                  piVar13 = piStack_28;
                  if (piStack_28 != piStack_24) {
                    do {
                      piVar2 = (int *)piVar13[1];
                      if (piVar2 != (int *)0x0) {
                        LOCK();
                        iVar6 = piVar2[1] + -1;
                        piVar2[1] = iVar6;
                        UNLOCK();
                        piVar7 = piStack_18;
                        if (iVar6 == 0) {
                          (**(code **)*piVar2)();
                          LOCK();
                          iVar6 = piVar2[2] + -1;
                          piVar2[2] = iVar6;
                          UNLOCK();
                          piVar7 = piStack_18;
                          if (iVar6 == 0) {
                            (**(code **)(*piVar2 + 4))();
                            piVar7 = piStack_18;
                          }
                        }
                      }
                      piVar13 = piVar13 + 2;
                    } while (piVar13 != piVar7);
                  }
                  uVar12 = (int)piStack_20 - (int)piStack_28 & 0xfffffff8;
                  piVar7 = piStack_28;
                  if (0xfff < uVar12) {
                    piVar7 = (int *)piStack_28[-1];
                    uVar12 = uVar12 + 0x23;
                    if (0x1f < (uint)((int)piStack_28 + (-4 - (int)piVar7))) {
                    /* WARNING: Subroutine does not return */
                      FUN_017167a3();
                    }
                  }
                  FUN_01674ea0(piVar7,uVar12);
                }
              }
            }
            else {
              cVar4 = FUN_0087ce60(&piStack_18);
              if (cVar4 != '\0') {
                uVar9 = FUN_0088c8c0();
                *param_2 = uVar9;
                iVar8 = FUN_005c9cc0();
                iVar6 = param_2[1];
                if (iVar6 != iVar8) {
                  if (iVar6 != 0) {
                    (**(code **)(iVar6 + 8))(param_2 + 2);
                  }
                  param_2[2] = piStack_18;
                  param_2[1] = iVar8;
                  FUN_005507b0();
                  ExceptionList = pvStack_10;
                  return 1;
                }
                param_2[2] = piStack_18;
                FUN_005507b0();
                ExceptionList = pvStack_10;
                return 1;
              }
            }
          }
          else {
            cVar4 = FUN_0087cf80(&piStack_24);
            if (cVar4 != '\0') {
              uVar9 = FUN_0088ca00();
              *param_2 = uVar9;
              iVar8 = FUN_00630890();
              iVar6 = param_2[1];
              if (iVar6 != iVar8) {
                if (iVar6 != 0) {
                  (**(code **)(iVar6 + 8))(param_2 + 2);
                }
                *(ulonglong *)(param_2 + 2) = CONCAT44(piStack_20,piStack_24);
                param_2[1] = iVar8;
                FUN_005507b0();
                ExceptionList = pvStack_10;
                return 1;
              }
              *(ulonglong *)(param_2 + 2) = CONCAT44(piStack_20,piStack_24);
              FUN_005507b0();
              ExceptionList = pvStack_10;
              return 1;
            }
          }
        }
        else {
          cVar4 = FUN_0087d410(&uStack_11);
          if (cVar4 != '\0') {
            uVar9 = FUN_0088daf0();
            *param_2 = uVar9;
            iVar8 = FUN_005c9ef0();
            iVar6 = param_2[1];
            if (iVar6 != iVar8) {
              if (iVar6 != 0) {
                (**(code **)(iVar6 + 8))(param_2 + 2);
              }
              *(undefined *)(param_2 + 2) = uStack_11;
              param_2[1] = iVar8;
              FUN_005507b0();
              ExceptionList = pvStack_10;
              return 1;
            }
            *(undefined *)(param_2 + 2) = uStack_11;
            FUN_005507b0();
            ExceptionList = pvStack_10;
            return 1;
          }
        }
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return 0;
      }
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
    cVar4 = FUN_0087ca30();
    if (cVar4 != '\0') {
      piStack_24 = (int *)0x0;
      piStack_20 = (int *)0xf;
      auStack_34[0] = 0;
      uStack_8 = 8;
      cVar4 = FUN_0087d060(auStack_34);
      if (cVar4 != '\0') {
        FUN_0054ef60(auStack_34);
        uVar14 = 0;
        uStack_8 = CONCAT31(uStack_8._1_3_,9);
        ppppuVar10 = (undefined4 ****)apppuStack_4c[0];
        uVar12 = uStack_38;
        if (uStack_3c != 0) {
          do {
            ppppuVar11 = apppuStack_4c;
            if (0xf < uVar12) {
              ppppuVar11 = ppppuVar10;
            }
            iVar6 = FUN_0171dc5a(*(undefined *)((int)ppppuVar11 + uVar14));
            if (iVar6 != 0) {
              ppppuVar11 = apppuStack_4c;
              if (0xf < uVar12) {
                ppppuVar11 = ppppuVar10;
              }
              uVar5 = FUN_01725677(*(undefined *)((int)ppppuVar11 + uVar14));
              ppppuVar11 = apppuStack_4c;
              if (0xf < uVar12) {
                ppppuVar11 = ppppuVar10;
              }
              *(undefined *)((int)ppppuVar11 + uVar14) = uVar5;
              ppppuVar10 = (undefined4 ****)apppuStack_4c[0];
              uVar12 = uStack_38;
            }
            uVar14 = uVar14 + 1;
          } while (uVar14 < uStack_3c);
        }
        uVar14 = uStack_3c;
        ppppuVar11 = apppuStack_4c;
        if (0xf < uVar12) {
          ppppuVar11 = ppppuVar10;
        }
        cVar4 = FUN_0055c360(ppppuVar11,uStack_3c,&DAT_018bdf50,4);
        if (cVar4 == '\0') {
          ppppuVar11 = apppuStack_4c;
          if (0xf < uVar12) {
            ppppuVar11 = ppppuVar10;
          }
          cVar4 = FUN_0055c360(ppppuVar11,uVar14,&DAT_018bdf48,5);
          if (cVar4 == '\0') {
            FUN_005c16d0(auStack_34);
          }
          else {
            uStack_11 = 0;
            FUN_005e52b0(&uStack_11);
          }
        }
        else {
          uStack_11 = 1;
          FUN_005e52b0(&uStack_11);
        }
        FUN_005507b0();
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return 1;
      }
      FUN_005507b0();
    }
  }
  else {
    piVar7 = (int *)FUN_01674e20(8);
    uStack_8 = 0;
    if (piVar7 == (int *)0x0) {
      piVar7 = (int *)0x0;
    }
    else {
      *piVar7 = 0;
      piVar7[1] = 0;
      piStack_18 = piVar7;
      iVar8 = FUN_00616cf0();
      *piVar7 = iVar8;
    }
    piStack_18 = (int *)0x0;
    uStack_8 = 0xffffffff;
    piStack_1c = (int *)0x0;
    FUN_00604750(piVar7,0);
    piVar7 = piStack_1c;
    uStack_8 = 1;
    cVar4 = FUN_0098e260(iVar6,piStack_1c);
    piVar13 = piStack_18;
    if (cVar4 != '\0') {
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      piStack_24 = piVar7;
      piStack_20 = piStack_18;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_0098dc70(&piStack_24);
      piVar7 = piStack_20;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_20[1] + -1;
        piStack_20[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar2 = piVar7 + 2;
          iVar6 = *piVar2 + -1;
          *piVar2 = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      if (piVar13 != (int *)0x0) {
        LOCK();
        iVar6 = piVar13[1] + -1;
        piVar13[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar13)();
          LOCK();
          piVar7 = piVar13 + 2;
          iVar6 = *piVar7;
          *piVar7 = *piVar7 + -1;
          UNLOCK();
          if (iVar6 == 1) {
            (**(code **)(*piVar13 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return 1;
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_18[1] + -1;
      piStack_18[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar7 = piVar13 + 2;
        iVar6 = *piVar7;
        *piVar7 = *piVar7 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          (**(code **)(*piVar13 + 4))();
          ExceptionList = pvStack_10;
          return 0;
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 17959 ; VA 0x0098ee00 ; FUN_0098ee00 */

undefined FUN_0098ee00(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  undefined uVar8;
  undefined auStack_1c8 [4];
  int iStack_1c4;
  undefined auStack_1c0 [200];
  int iStack_f8;
  int iStack_f4;
  int aiStack_f0 [50];
  undefined auStack_28 [12];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1036;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_f8 = FUN_00888530();
  iStack_f4 = 0;
  iStack_8 = 0;
  FUN_0167e960();
  iStack_8._0_1_ = 1;
  uVar4 = FUN_016819e0(auStack_28,param_1);
  iStack_8._0_1_ = 3;
  FUN_0167ed10(uVar4);
  iStack_8._0_1_ = 1;
  FUN_0167ec40();
  cVar3 = FUN_016816d0();
  if (cVar3 == '\0') {
    uVar4 = FUN_0098f4a0(auStack_1c8,auStack_1c);
    iStack_8._0_1_ = 4;
    FUN_00947a40(uVar4);
    iStack_8._0_1_ = 5;
    if (iStack_1c4 != 0) {
      (**(code **)(iStack_1c4 + 8))(auStack_1c0);
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_0167ec40();
    iVar6 = iStack_f8;
    iVar5 = FUN_008882f0();
    iVar2 = iStack_f8;
    if (iVar6 == iVar5) {
      iVar6 = FUN_008882f0();
      if (iVar2 != iVar6) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      piVar7 = aiStack_f0;
      if (iStack_f4 == 0) {
        piVar7 = (int *)0x0;
      }
      iVar6 = piVar7[1];
      if (iVar6 != 0) {
        LOCK();
        *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
        UNLOCK();
        iVar6 = piVar7[1];
      }
      *param_2 = *piVar7;
      piVar7 = (int *)param_2[1];
      param_2[1] = iVar6;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar6 = piVar7[1] + -1;
        piVar7[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar6 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar6 == 1) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      uVar8 = 1;
    }
    else {
      uVar8 = 0;
    }
  }
  else {
    FUN_0167ec40();
    uVar8 = 0;
  }
  iStack_8 = 6;
  if (iStack_f4 != 0) {
    (**(code **)(iStack_f4 + 8))(aiStack_f0);
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 17960 ; VA 0x0098ef90 ; FUN_0098ef90 */

undefined FUN_0098ef90(undefined4 param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  undefined4 uVar2;
  undefined uVar3;
  undefined auStack_f8 [4];
  int iStack_f4;
  undefined auStack_f0 [200];
  undefined auStack_28 [12];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1063;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0167e960();
  uStack_8 = 0;
  if (param_3 == 1) {
    uVar2 = FUN_01681a70();
    uStack_8._0_1_ = 1;
  }
  else {
    uVar2 = FUN_016819e0(auStack_28,param_1);
    uStack_8._0_1_ = 2;
  }
  FUN_0167ed10(uVar2);
  uStack_8._0_1_ = 0;
  FUN_0167ec40();
  cVar1 = FUN_016816d0();
  if (cVar1 == '\0') {
    uVar2 = FUN_0098f4a0(auStack_f8,auStack_1c);
    uStack_8._0_1_ = 3;
    FUN_00947a40(uVar2);
    uStack_8._0_1_ = 4;
    if (iStack_f4 != 0) {
      (**(code **)(iStack_f4 + 8))(auStack_f0);
    }
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  FUN_0167ec40();
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 17961 ; VA 0x0098f070 ; FUN_0098f070 */

undefined FUN_0098f070(undefined4 param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  undefined uVar7;
  int iStack_e0;
  int iStack_dc;
  int aiStack_d8 [50];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_e0 = FUN_00888530();
  iStack_dc = 0;
  uStack_8 = 0;
  cVar3 = FUN_0098ef90(param_1,&iStack_e0,param_3);
  iVar5 = iStack_e0;
  if ((cVar3 == '\0') || (iVar4 = FUN_008881d0(), iVar2 = iStack_e0, iVar5 != iVar4)) {
    uVar7 = 0;
  }
  else {
    iVar5 = FUN_008881d0();
    if (iVar2 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar6 = aiStack_d8;
    if (iStack_dc == 0) {
      piVar6 = (int *)0x0;
    }
    iVar5 = piVar6[1];
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
      iVar5 = piVar6[1];
    }
    *param_2 = *piVar6;
    piVar6 = (int *)param_2[1];
    param_2[1] = iVar5;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar5 = piVar6[1] + -1;
      piVar6[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    uVar7 = 1;
  }
  uStack_8 = 1;
  if (iStack_dc != 0) {
    (**(code **)(iStack_dc + 8))(aiStack_d8);
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 17962 ; VA 0x0098f180 ; FUN_0098f180 */

undefined FUN_0098f180(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  int iVar4;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1088;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008828b0(*(undefined4 *)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1));
  uStack_8 = 0;
  iVar4 = FUN_005535a0();
  uStack_8 = 1;
  FUN_00883a10(&uStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_0098f280(uStack_18,param_2);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  uStack_8 = 3;
  FUN_005537e0(*(undefined4 *)(iVar4 + 4));
  *(int *)(iVar4 + 4) = iVar4;
  *(int *)iVar4 = iVar4;
  *(int *)(iVar4 + 8) = iVar4;
  FUN_01674ea0(iVar4,0x40);
  FUN_00550da0();
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 17963 ; VA 0x0098f280 ; FUN_0098f280 */

undefined4 FUN_0098f280(int param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  char cVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d10cf;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)(param_1 + 0x10);
  if (iVar3 == DAT_01ede648) {
    ExceptionList = &pvStack_10;
    puVar6 = (undefined4 *)FUN_01674e20(8);
    uStack_8 = 0;
    if (puVar6 == (undefined4 *)0x0) {
      puVar8 = (undefined4 *)0x0;
    }
    else {
      *puVar6 = 0;
      puVar6[1] = 0;
      uVar7 = FUN_00616cf0();
      *puVar6 = uVar7;
      puVar8 = puVar6;
    }
    uStack_8 = 0xffffffff;
    uStack_18 = 0;
    piStack_14 = (int *)0x0;
    FUN_00604750(puVar8,puVar6);
    uVar7 = uStack_18;
    uStack_8 = 1;
    cVar5 = FUN_0098e260(param_1,uStack_18);
    piVar4 = piStack_14;
    if (cVar5 != '\0') {
      if (piStack_14 != (int *)0x0) {
        LOCK();
        piStack_14[1] = piStack_14[1] + 1;
        UNLOCK();
      }
      uStack_20 = uVar7;
      piStack_1c = piStack_14;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_0098dc70(&uStack_20);
      piVar2 = piStack_1c;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1 + -1;
          *piVar1 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar3 = piVar4[1] + -1;
        piVar4[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          piVar2 = piVar4 + 2;
          iVar3 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return 1;
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[1] + -1;
      piStack_14[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar2 = piVar4 + 2;
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piVar4 + 4))();
          ExceptionList = pvStack_10;
          return 0;
        }
      }
    }
  }
  else {
    if (iVar3 == DAT_01ede64c) {
      ExceptionList = &pvStack_10;
      FUN_005cac50(&uStack_18);
      uStack_8 = 3;
      cVar5 = FUN_0098e110(param_1,uStack_18);
      if (cVar5 == '\0') {
        FUN_00550b30();
        ExceptionList = pvStack_10;
        return 0;
      }
      if (piStack_14 != (int *)0x0) {
        LOCK();
        *(int *)((int)piStack_14 + 4) = *(int *)((int)piStack_14 + 4) + 1;
        UNLOCK();
      }
      uStack_20 = uStack_18;
      piStack_1c = piStack_14;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_005c1810(&uStack_20);
      FUN_00550b30();
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return 1;
    }
    if ((iVar3 == DAT_01ede658) &&
       (ExceptionList = &pvStack_10, cVar5 = FUN_0098e500(param_1,param_2), cVar5 != '\0')) {
      ExceptionList = pvStack_10;
      return 1;
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 17964 ; VA 0x0098f4a0 ; FUN_0098f4a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_0098f4a0(undefined4 *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined **ppuVar9;
  uint uVar10;
  undefined **ppuVar11;
  uint uVar12;
  float10 fVar13;
  undefined8 uVar14;
  undefined auStack_140 [216];
  uint auStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  uint uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined auStack_34 [4];
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_24;
  undefined uStack_1d;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017d1157;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_38 = 0;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_00888530();
  *param_1 = uVar5;
  param_1[1] = 0;
  uStack_8 = 0;
  uStack_38 = 1;
  cVar4 = FUN_0167e540();
  if (cVar4 != '\0') {
    uVar5 = FUN_0167e2d0();
    uVar6 = FUN_0088c8c0();
    *param_1 = uVar6;
    puStack_18 = (undefined4 *)FUN_005c9cc0();
    iVar1 = param_1[1];
    if ((undefined4 *)iVar1 != puStack_18) {
      if (iVar1 != 0) {
        (**(code **)(iVar1 + 8))();
        param_1[1] = 0;
      }
      param_1[2] = uVar5;
      param_1[1] = puStack_18;
      ExceptionList = pvStack_10;
      return param_1;
    }
    param_1[2] = uVar5;
    ExceptionList = pvStack_10;
    return param_1;
  }
  cVar4 = FUN_0167e5a0();
  if (cVar4 != '\0') {
    uVar14 = FUN_0167e380(0,0);
    uStack_30 = (undefined4)((ulonglong)uVar14 >> 0x20);
    uVar5 = FUN_0088da50();
    iVar1 = _tls_index;
    *param_1 = uVar5;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar1 * 4) + 0x34) < DAT_01ea8c28) &&
       (FUN_016f3809(), DAT_01ea8c28 == -1)) {
      DAT_01ea8c1c = FUN_005c6620;
      _DAT_01ea8c20 = FUN_005c6620;
      DAT_01ea8c24 = _guard_check_icall;
      FUN_016f37bf();
    }
    puVar8 = (undefined4 *)param_1[1];
    if ((code **)puVar8 != &DAT_01ea8c1c) {
      if (puVar8 != (undefined4 *)0x0) {
        (*(code *)puVar8[2])();
        param_1[1] = 0;
      }
      param_1[2] = (int)uVar14;
      param_1[3] = uStack_30;
      param_1[1] = &DAT_01ea8c1c;
      ExceptionList = pvStack_10;
      return param_1;
    }
    param_1[2] = (int)uVar14;
    param_1[3] = uStack_30;
    ExceptionList = pvStack_10;
    return param_1;
  }
  cVar4 = FUN_0167e560();
  if (cVar4 != '\0') {
LAB_0098f780:
    fVar13 = (float10)FUN_0167e350(0);
    uStack_2c = (double)fVar13;
    FUN_0063d540();
    ExceptionList = pvStack_10;
    return param_1;
  }
  cVar4 = FUN_0167e5c0();
  if (cVar4 != '\0') {
    uStack_1d = FUN_0167e3d0();
    FUN_005e52b0();
    ExceptionList = pvStack_10;
    return param_1;
  }
  cVar4 = FUN_0167e580();
  if (cVar4 == '\0') {
    cVar4 = FUN_01681850();
    if (cVar4 == '\0') {
      cVar4 = FUN_01681870();
      if (cVar4 == '\0') {
        cVar4 = FUN_01681830();
        if (cVar4 != '\0') {
          FUN_005cac50();
          uStack_8 = 9;
          FUN_016810c0();
          FUN_01680ea0();
          FUN_01681140();
          cVar4 = FUN_005e0cd0();
          while (cVar4 != '\0') {
            FUN_0167efb0();
            uVar5 = FUN_0098f4a0(auStack_140,auStack_34);
            uStack_8 = CONCAT31(uStack_8._1_3_,10);
            if (*(int *)((int)uStack_2c + 8) == *(int *)((int)uStack_2c + 4)) {
              FUN_005ca4f0(*(int *)((int)uStack_2c + 4),uVar5);
            }
            else {
              FUN_005caf00();
              *(int *)((int)uStack_2c + 4) = *(int *)((int)uStack_2c + 4) + 0xd0;
            }
            uStack_8 = CONCAT31(uStack_8._1_3_,9);
            FUN_0056e5b0();
            FUN_0167f070();
            cVar4 = FUN_005e0cd0();
          }
          FUN_00557fc0();
          uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
          FUN_005c1810();
          FUN_00550b30();
          FUN_00550b30();
        }
        ExceptionList = pvStack_10;
        return param_1;
      }
      puVar8 = (undefined4 *)FUN_01674e20();
      if (puVar8 == (undefined4 *)0x0) {
        puVar8 = (undefined4 *)0x0;
        puStack_18 = (undefined4 *)0x0;
      }
      else {
        puVar8[1] = 1;
        puVar8[2] = 1;
        *puVar8 = std::
                  _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>
                  ::vftable;
        *(undefined *)(puVar8 + 3) = 0;
        uStack_24 = 0xb;
        puStack_18 = puVar8;
        ppuVar9 = (undefined **)
                  FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_24);
        ppuVar11 = ppuVar9 + -1;
        if (ppuVar9 != &boost::lock_error::vftable_meta_ptr) {
          ppuVar11 = ppuVar9;
        }
        puVar8[4] = *ppuVar11;
        puVar8[5] = 0;
        puVar8[6] = 0x3f800000;
        puVar8[7] = 0;
        puVar8[8] = 0;
      }
      uStack_38 = 5;
      uStack_2c = (double)CONCAT44(puVar8,puVar8 + 3);
      uStack_8 = 3;
      FUN_01681890();
      FUN_01680ec0();
      uStack_8._0_1_ = 4;
      FUN_01681160();
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      cVar4 = FUN_0167ed80();
      while (cVar4 != '\0') {
        FUN_0054eb90();
        uVar5 = FUN_01682680();
        FUN_0098f4a0(auStack_140,uVar5);
        uStack_8._0_1_ = 6;
        uVar5 = FUN_01681970();
        uStack_8._0_1_ = 7;
        FUN_005c4c00(uVar5);
        FUN_00947a40();
        FUN_005507b0();
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
        FUN_0056e5b0();
        FUN_0167f080();
        cVar4 = FUN_0167ed80();
        puVar8 = puStack_18;
      }
      FUN_005c4aa0();
      FUN_005c4aa0();
      if (puVar8 != (undefined4 *)0x0) {
        LOCK();
        puVar8[1] = puVar8[1] + 1;
        UNLOCK();
      }
      puStack_1c = puVar8 + 3;
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      puStack_18 = puVar8;
      uVar5 = FUN_008881d0();
      iVar1 = _tls_index;
      *param_1 = uVar5;
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar1 * 4) + 0x34) < DAT_01ea8a9c) &&
         (FUN_016f3809(), DAT_01ea8a9c == -1)) {
        DAT_01ea8a90 = FUN_0057bbb0;
        DAT_01ea8a94 = FUN_005880a0;
        DAT_01ea8a98 = FUN_0057d5e0;
        FUN_016f37bf();
      }
      puVar2 = (undefined4 *)param_1[1];
      if ((code **)puVar2 == &DAT_01ea8a90) {
        puStack_1c = (undefined4 *)0x0;
        param_1[2] = puVar8 + 3;
        piVar3 = (int *)param_1[3];
        param_1[3] = puVar8;
        puStack_18 = (undefined4 *)0x0;
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar1 = piVar3[1] + -1;
          piVar3[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar1 = piVar3[2] + -1;
            piVar3[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
      }
      else {
        if (puVar2 != (undefined4 *)0x0) {
          (*(code *)puVar2[2])();
          param_1[1] = 0;
        }
        param_1[3] = puVar8;
        param_1[2] = puVar8 + 3;
        puStack_1c = (undefined4 *)0x0;
        puStack_18 = (undefined4 *)0x0;
        param_1[1] = &DAT_01ea8a90;
      }
      FUN_00550b30();
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return param_1;
    }
    goto LAB_0098f780;
  }
  uStack_58 = 0;
  uStack_54 = 0xf;
  auStack_68[0] = auStack_68[0] & 0xffffff00;
  uStack_8 = 1;
  FUN_01681330(&uStack_50,auStack_68);
  uStack_38 = 3;
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_54) {
    uVar12 = uStack_54 + 1;
    uVar10 = auStack_68[0];
    if (0xfff < uVar12) {
      uVar10 = *(uint *)(auStack_68[0] - 4);
      uVar12 = uStack_54 + 0x24;
      if (0x1f < (auStack_68[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar12);
  }
  uStack_58 = 0;
  uStack_54 = 0xf;
  auStack_68[0] = auStack_68[0] & 0xffffff00;
  uStack_8 = 2;
  uVar5 = FUN_0088cb40();
  *param_1 = uVar5;
  iVar7 = FUN_005c9d30();
  iVar1 = param_1[1];
  if (iVar1 == iVar7) {
    if (param_1 + 2 == &uStack_50) goto LAB_0098f759;
    FUN_005507b0();
    param_1[2] = uStack_50;
    param_1[3] = uStack_4c;
    param_1[4] = uStack_48;
    param_1[5] = uStack_44;
    *(ulonglong *)(param_1 + 6) = CONCAT44(uStack_3c,uStack_40);
  }
  else {
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))();
      param_1[1] = 0;
    }
    param_1[6] = 0;
    param_1[7] = 0;
    param_1[2] = uStack_50;
    param_1[3] = uStack_4c;
    param_1[4] = uStack_48;
    param_1[5] = uStack_44;
    *(ulonglong *)(param_1 + 6) = CONCAT44(uStack_3c,uStack_40);
    param_1[1] = iVar7;
  }
  uStack_50 = uStack_50 & 0xffffff00;
  uStack_3c = 0xf;
  uStack_40 = 0;
LAB_0098f759:
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17965 ; VA 0x0098fba0 ; FUN_0098fba0 */

void __thiscall FUN_0098fba0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    *puVar1 = *param_2;
    puVar1[1] = 0;
    puVar2 = (undefined4 *)param_2[1];
    if (puVar2 != (undefined4 *)0x0) {
      (*(code *)*puVar2)(param_2 + 2,puVar1 + 2);
      puVar2 = (undefined4 *)param_2[1];
    }
    puVar1[1] = puVar2;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0xd0;
    return;
  }
  FUN_0098ded0(puVar1,param_2);
  return;
}



/* FUNCTION 17966 ; VA 0x0098fc00 ; FUN_0098fc00 */

undefined FUN_0098fc00(undefined4 param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  int aiStack_38 [5];
  uint uStack_24;
  undefined auStack_20 [15];
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1178;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0167e9f0();
  uStack_8 = 0;
  cVar4 = FUN_0098fce0(param_1,auStack_20,param_3);
  if (cVar4 == '\0') {
    uStack_11 = 0;
  }
  else {
    puVar5 = (undefined4 *)FUN_01681c50(aiStack_38);
    if (param_2 != puVar5) {
      FUN_005507b0();
      uVar1 = puVar5[1];
      uVar2 = puVar5[2];
      uVar3 = puVar5[3];
      *param_2 = *puVar5;
      param_2[1] = uVar1;
      param_2[2] = uVar2;
      param_2[3] = uVar3;
      *(undefined8 *)(param_2 + 4) = *(undefined8 *)(puVar5 + 4);
      puVar5[4] = 0;
      puVar5[5] = 0xf;
      *(undefined *)puVar5 = 0;
    }
    if (0xf < uStack_24) {
      uVar7 = uStack_24 + 1;
      iVar6 = aiStack_38[0];
      if (0xfff < uVar7) {
        iVar6 = *(int *)(aiStack_38[0] + -4);
        uVar7 = uStack_24 + 0x24;
        if (0x1f < (aiStack_38[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar6,uVar7);
    }
    uStack_11 = 1;
  }
  FUN_0167ec80();
  ExceptionList = pvStack_10;
  return uStack_11;
}



/* FUNCTION 17967 ; VA 0x0098fce0 ; FUN_0098fce0 */

undefined4 FUN_0098fce0(int *param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  char cVar4;
  int iVar5;
  int *piVar6;
  undefined8 *puVar7;
  uint uVar8;
  int iVar9;
  int iVar10;
  undefined4 *puVar11;
  undefined4 *****pppppuVar12;
  undefined4 *puVar13;
  undefined auStack_100 [200];
  undefined8 uStack_38;
  undefined4 ****appppuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d11e4;
  pvStack_10 = ExceptionList;
  iVar10 = *param_1;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00888530();
  if (iVar10 == iVar5) {
LAB_00990292:
    FUN_016819c0();
    ExceptionList = pvStack_10;
    return 1;
  }
  iVar10 = *param_1;
  if (*(char *)(iVar10 + 0x20) == '\0') {
    iVar9 = FUN_0088daf0();
    iVar5 = *param_1;
    if (iVar10 == iVar9) {
      iVar10 = FUN_0088daf0();
      if (iVar5 != iVar10) {
        puVar13 = (undefined4 *)param_1[1];
        if (puVar13 != (undefined4 *)0x0) {
          (*(code *)*puVar13)(param_1 + 2,auStack_100);
          puVar13 = (undefined4 *)param_1[1];
        }
        uStack_8 = 4;
        FUN_0088bcc0();
        uStack_8 = 5;
        if (puVar13 != (undefined4 *)0x0) {
          (*(code *)puVar13[2])();
        }
        uStack_8 = 0xffffffff;
        FUN_01680fa0();
        ExceptionList = pvStack_10;
        return 1;
      }
      iVar10 = *param_1;
      iVar5 = FUN_0088daf0();
      if (iVar10 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0();
      }
      FUN_01680fa0();
      ExceptionList = pvStack_10;
      return 1;
    }
    if (*(char *)(iVar5 + 0x21) != '\0') {
      iVar10 = FUN_0088da50();
      if (iVar5 != iVar10) {
        puVar13 = (undefined4 *)param_1[1];
        if (puVar13 != (undefined4 *)0x0) {
          (*(code *)*puVar13)(param_1 + 2,auStack_100);
          puVar13 = (undefined4 *)param_1[1];
        }
        uStack_8 = 6;
        puVar11 = (undefined4 *)FUN_0088baa0();
        uVar1 = *puVar11;
        uVar2 = puVar11[1];
        uStack_8 = 7;
        if (puVar13 != (undefined4 *)0x0) {
          (*(code *)puVar13[2])();
        }
        uStack_8 = 0xffffffff;
        FUN_01681740(uVar1,uVar2);
        ExceptionList = pvStack_10;
        return 1;
      }
      iVar10 = *param_1;
      iVar5 = FUN_0088da50();
      if (iVar10 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0();
      }
      piVar6 = param_1 + 2;
      if (param_1[1] == 0) {
        piVar6 = (int *)0x0;
      }
      FUN_01681740(*piVar6,piVar6[1]);
      ExceptionList = pvStack_10;
      return 1;
    }
    iVar10 = FUN_0088cb40();
    if (iVar5 == iVar10) {
      FUN_00563690();
      pppppuVar12 = appppuStack_30;
      if (0xf < uStack_1c) {
        pppppuVar12 = (undefined4 *****)appppuStack_30[0];
      }
      uStack_8 = 8;
      cVar4 = FUN_0098e0d0(pppppuVar12,uStack_20);
      if (cVar4 != '\0') {
        FUN_01681cd0();
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return 1;
      }
      FUN_005507b0();
    }
    else {
      iVar10 = *param_1;
      iVar5 = FUN_0088cf00();
      if (iVar10 == iVar5) {
        FUN_008994a0();
        uStack_8 = 9;
        FUN_01681cd0();
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return 1;
      }
      iVar10 = *param_1;
      iVar5 = FUN_008881d0();
      if (iVar10 == iVar5) {
        FUN_01681c30();
        FUN_00636000();
        uStack_8 = 10;
        if (*(int *)((int)(int *)uStack_18 + 8) == 0) {
          puVar13 = (undefined4 *)0x0;
        }
        else {
          puVar13 = *(undefined4 **)
                     (*(int *)((int)(int *)uStack_18 + 0x14) +
                     *(int *)((int)(int *)uStack_18 + 4) * 4);
        }
        while( true ) {
          if (puVar13 == (undefined4 *)0x0) {
            FUN_01681200();
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          piVar6 = puVar13 + 2;
          if (0xf < (uint)puVar13[7]) {
            piVar6 = (int *)*piVar6;
          }
          cVar4 = FUN_0098e0d0(piVar6,puVar13[6]);
          if (cVar4 == '\0') break;
          FUN_01681cd0();
          cVar4 = FUN_0098fce0(puVar13 + 8);
          if (cVar4 == '\0') break;
          puVar13 = (undefined4 *)*puVar13;
        }
        FUN_00550b30();
        ExceptionList = pvStack_10;
        return 0;
      }
      iVar10 = *param_1;
      iVar5 = FUN_008882f0();
      if (iVar10 == iVar5) {
        FUN_01681c10();
        FUN_00636130();
        uStack_8 = 0xb;
        iVar10 = *(int *)uStack_18;
        iVar5 = ((int *)uStack_18)[1];
        while( true ) {
          if (iVar10 == iVar5) {
            FUN_016811a0();
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return 1;
          }
          cVar4 = FUN_0098fce0(iVar10,param_2,param_3);
          if (cVar4 == '\0') break;
          iVar10 = iVar10 + 0xd0;
        }
        FUN_00550b30();
        ExceptionList = pvStack_10;
        return 0;
      }
      if (param_3 == 1) goto LAB_00990292;
    }
    ExceptionList = pvStack_10;
    return 0;
  }
  iVar5 = FUN_0088ca00();
  if (iVar10 == iVar5) {
    iVar10 = *param_1;
    iVar5 = FUN_0088ca00();
    if (iVar10 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar6 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar6 = (int *)0x0;
    }
    uStack_18 = *(undefined8 *)piVar6;
  }
  else {
    puVar13 = (undefined4 *)param_1[1];
    if (puVar13 != (undefined4 *)0x0) {
      (*(code *)*puVar13)(param_1 + 2,auStack_100);
      puVar13 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    puVar7 = (undefined8 *)FUN_008896a0();
    uStack_18 = *puVar7;
    uStack_8 = 1;
    if (puVar13 != (undefined4 *)0x0) {
      (*(code *)puVar13[2])();
    }
    uStack_8 = 0xffffffff;
  }
  if ((DAT_01ee33d8 != 0) &&
     (uStack_38._4_4_ = (uint)((ulonglong)uStack_18 >> 0x20), uVar8 = uStack_38._4_4_ & 0x7ff00000,
     uStack_38 = uStack_18, uVar8 == 0x7ff00000)) {
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = 2;
    FUN_0151f9c0("SkipMode",param_3);
    iVar10 = DAT_01ee33d8;
    uStack_20 = 0;
    uStack_1c = 0xf;
    appppuStack_30[0] = (undefined4 ****)((uint)appppuStack_30[0] & 0xffffff00);
    FUN_005542c0("WebParserWriteNanInf",0x14);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_01520d20(appppuStack_30,iVar10,0);
    FUN_005507b0();
    uStack_8 = 0xffffffff;
    FUN_0151f7f0();
  }
  if (param_3 == 1) {
    uStack_38 = uStack_18;
    uVar3 = uStack_38;
    uStack_38._4_4_ = (uint)((ulonglong)uStack_18 >> 0x20);
    uVar8 = uStack_38._4_4_ & 0x7ff00000;
    uStack_38 = uVar3;
    if (uVar8 == 0x7ff00000) goto LAB_00990292;
  }
  FUN_01681090(uStack_18);
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 17968 ; VA 0x009902d0 ; FUN_009902d0 */

int __thiscall FUN_009902d0(uint *param_1,uint param_2,undefined4 param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  
  uVar7 = *param_1;
  iVar1 = (int)(param_1[1] - *param_1) / 0x30;
  if (iVar1 == 0x5555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar4 = iVar1 + 1;
  uVar2 = (int)(param_1[2] - *param_1) / 0x30;
  uVar6 = uVar4;
  if ((uVar2 <= 0x5555555 - (uVar2 >> 1)) && (uVar6 = (uVar2 >> 1) + uVar2, uVar6 < uVar4)) {
    uVar6 = uVar4;
  }
  uVar4 = uVar6 * 0x30;
  if (uVar6 < 0x5555556) {
    uVar6 = uVar4;
    if (0xfff < uVar4) goto LAB_00990366;
    if (uVar4 == 0) {
      uVar6 = 0;
    }
    else {
      uVar6 = FUN_01674e20(uVar4);
    }
  }
  else {
    uVar6 = 0xffffffff;
LAB_00990366:
    uVar2 = uVar6 + 0x23;
    if (uVar2 <= uVar6) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_009904a1;
    uVar6 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar6 - 4) = iVar3;
  }
  iVar3 = ((int)(param_2 - uVar7) / 0x30) * 0x30;
  FUN_0093b8b0(param_1,iVar3 + uVar6,param_3);
  uVar7 = param_1[1];
  uVar2 = *param_1;
  uVar5 = uVar6;
  if (param_2 == uVar7) {
    for (; uVar2 != uVar7; uVar2 = uVar2 + 0x30) {
      FUN_0093b8b0(param_1,uVar5,uVar2);
      uVar5 = uVar5 + 0x30;
    }
  }
  else {
    FUN_0093c160(uVar2,param_2,uVar6);
    FUN_0093c160(param_2,param_1[1],iVar3 + 0x30 + uVar6);
  }
  uVar7 = *param_1;
  if (uVar7 != 0) {
    uVar2 = param_1[1];
    if (uVar7 != uVar2) {
      do {
        FUN_005509f0();
        uVar7 = uVar7 + 0x30;
      } while (uVar7 != uVar2);
      uVar7 = *param_1;
    }
    uVar5 = ((int)(param_1[2] - uVar7) / 0x30) * 0x30;
    uVar2 = uVar7;
    if (0xfff < uVar5) {
      uVar2 = *(uint *)(uVar7 - 4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (uVar7 - uVar2) - 4) {
LAB_009904a1:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar5);
  }
  *param_1 = uVar6;
  param_1[1] = (iVar1 * 3 + 3) * 0x10 + uVar6;
  param_1[2] = uVar4 + uVar6;
  return *param_1 + iVar3;
}



/* FUNCTION 17969 ; VA 0x009904b0 ; FUN_009904b0 */

int __thiscall FUN_009904b0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d11f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Analytics::GoogleAnalyticsConfiguration*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17970 ; VA 0x00990582 ; Catch_All@00990582 */

void Catch_All_00990582(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 17971 ; VA 0x009905a0 ; FUN_009905a0 */

undefined4 * FUN_009905a0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d1230;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00ef7b60();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x70);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00ef7fe0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_009904b0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17972 ; VA 0x00990660 ; FUN_00990660 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined2 * __thiscall
FUN_00990660(undefined2 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  uint *puVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined2 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d12cb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 2) = param_3;
  *param_1 = 0;
  *(undefined *)(param_1 + 1) = 0;
  *(undefined4 *)(param_1 + 4) = param_4;
  *(undefined4 *)(param_1 + 0xe) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0xf;
  *(undefined *)(param_1 + 6) = 0;
  puStack_14 = param_1;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  *(undefined4 *)(param_1 + 0x1a) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 0x12) = 0;
  FUN_005542c0("clientID=",9);
  uStack_8._0_1_ = 1;
  *(undefined4 *)(param_1 + 0x26) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0xf;
  *(undefined *)(param_1 + 0x1e) = 0;
  FUN_005542c0("sessionID=",10);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee3420) &&
     (FUN_016f3809(&DAT_01ee3420), DAT_01ee3420 == -1)) {
    _DAT_01d648b8 = 0xf00000000;
    DAT_01d648a8 = DAT_01d648a8 & 0xffffff00;
    FUN_016f3654(&LAB_01885fd0);
    FUN_016f37bf(&DAT_01ee3420);
  }
  if (DAT_01d648b8 == 0) {
    puVar1 = (uint *)FUN_00990d80(auStack_2c);
    if (puVar1 != &DAT_01d648a8) {
      FUN_005507b0();
      DAT_01d648a8 = *puVar1;
      uRam01d648ac = puVar1[1];
      uRam01d648b0 = puVar1[2];
      uRam01d648b4 = puVar1[3];
      _DAT_01d648b8 = *(undefined8 *)(puVar1 + 4);
      puVar1[4] = 0;
      puVar1[5] = 0xf;
      *(undefined *)puVar1 = 0;
    }
    if (0xf < uStack_18) {
      uVar5 = uStack_18 + 1;
      uVar3 = auStack_2c[0];
      if (0xfff < uVar5) {
        uVar3 = *(uint *)(auStack_2c[0] - 4);
        uVar5 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar5);
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  }
  FUN_0054ef60(&DAT_01d648a8);
  uStack_8._0_1_ = 3;
  uVar2 = FUN_00990f20();
  FUN_0054ef60(uVar2);
  uStack_8._0_1_ = 4;
  FUN_0054ef60(param_2);
  *(undefined4 *)(param_1 + 0x4e) = 0;
  *(undefined4 *)(param_1 + 0x50) = 0;
  *(undefined4 *)(param_1 + 0x52) = 0;
  *(undefined4 *)(param_1 + 0x54) = 0;
  *(undefined4 *)(param_1 + 0x56) = 0;
  *(undefined4 *)(param_1 + 0x58) = 0;
  uStack_8._0_1_ = 7;
  *(undefined4 *)(param_1 + 0x62) = 0;
  *(undefined4 *)(param_1 + 100) = 0xf;
  *(undefined *)(param_1 + 0x5a) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 8;
  *(undefined4 *)(param_1 + 0x6e) = 0;
  *(undefined4 *)(param_1 + 0x70) = 0xf;
  *(undefined *)(param_1 + 0x66) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 9;
  *(undefined4 *)(param_1 + 0x7a) = 0;
  *(undefined4 *)(param_1 + 0x7c) = 0xf;
  *(undefined *)(param_1 + 0x72) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uVar3 = *(uint *)(param_1 + 4);
  if (*(uint *)(param_1 + 4) == 0xffffffff) {
    uVar3 = *(uint *)(param_1 + 2);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  *(uint *)(param_1 + 4) = uVar3;
  uVar5 = FUN_00563b90(param_1 + 0x36);
  uVar4 = 10000;
  if (DAT_01d64858 == '\0') {
    uVar4 = 100;
  }
  uVar5 = uVar5 % uVar4;
  if (DAT_01ede470 != '\0') {
    FUN_016774b0(DAT_01ede470,"Google analytics lottery number = %d",uVar5);
    uVar3 = *(uint *)(param_1 + 4);
  }
  if ((uVar5 < *(uint *)(param_1 + 2)) || (DAT_01d62714 != '\0')) {
    *(undefined *)((int)param_1 + 1) = 1;
  }
  if ((uVar5 < uVar3) || (DAT_01d62714 != '\0')) {
    *(undefined *)(param_1 + 1) = 1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17973 ; VA 0x00990990 ; FUN_00990990 */

void __thiscall FUN_00990990(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  undefined auStack_58 [48];
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d12f0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  uStack_8 = 0;
  FUN_0054ef60(param_3);
  uStack_8 = 1;
  if (*(int *)(param_1 + 0xb0) == *(int *)(param_1 + 0xac)) {
    FUN_009902d0(*(int *)(param_1 + 0xac),auStack_58);
  }
  else {
    FUN_0093b8b0(param_1 + 0xa8);
    *(int *)(param_1 + 0xac) = *(int *)(param_1 + 0xac) + 0x30;
  }
  uStack_8 = 0xffffffff;
  FUN_005509f0();
  puVar4 = (undefined4 *)FUN_00990c80(aiStack_28,param_1 + 0xa8);
  if ((undefined4 *)(param_1 + 0xcc) != puVar4) {
    FUN_005507b0();
    uVar1 = puVar4[1];
    uVar2 = puVar4[2];
    uVar3 = puVar4[3];
    *(undefined4 *)(param_1 + 0xcc) = *puVar4;
    *(undefined4 *)(param_1 + 0xd0) = uVar1;
    *(undefined4 *)(param_1 + 0xd4) = uVar2;
    *(undefined4 *)(param_1 + 0xd8) = uVar3;
    *(undefined8 *)(param_1 + 0xdc) = *(undefined8 *)(puVar4 + 4);
    puVar4[4] = 0;
    puVar4[5] = 0xf;
    *(undefined *)puVar4 = 0;
  }
  if (0xf < uStack_14) {
    uVar6 = uStack_14 + 1;
    iVar5 = aiStack_28[0];
    if (0xfff < uVar6) {
      iVar5 = *(int *)(aiStack_28[0] + -4);
      uVar6 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17974 ; VA 0x00990aa0 ; FUN_00990aa0 */

undefined4 * FUN_00990aa0(undefined4 *param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  uint *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  int aiStack_40 [5];
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ee70;
  pvStack_10 = ExceptionList;
  puVar7 = param_3;
  if (0xf < (uint)param_3[5]) {
    puVar7 = (undefined4 *)*param_3;
  }
  piVar1 = param_3 + 4;
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  ExceptionList = &pvStack_10;
  puVar6 = (undefined4 *)FUN_0151d6e0(aiStack_40,param_3,*piVar1 + (int)puVar7);
  uStack_8 = 0;
  puVar7 = (undefined4 *)FUN_00558ce0(auStack_28,param_2,&DAT_0191bf9c);
  uVar10 = puVar6[4];
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (((uint)(puVar7[5] - puVar7[4]) < uVar10) &&
     (puVar2 = puVar7 + 4, *puVar2 <= puVar6[5] - uVar10)) {
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    puVar7 = (undefined4 *)FUN_00585d40(0,puVar7,*puVar2);
  }
  else {
    if (0xf < (uint)puVar6[5]) {
      puVar6 = (undefined4 *)*puVar6;
    }
    puVar7 = (undefined4 *)FUN_00554150(puVar6,uVar10);
  }
  param_1[4] = 0;
  param_1[5] = 0;
  uVar3 = puVar7[1];
  uVar4 = puVar7[2];
  uVar5 = puVar7[3];
  *param_1 = *puVar7;
  param_1[1] = uVar3;
  param_1[2] = uVar4;
  param_1[3] = uVar5;
  *(undefined8 *)(param_1 + 4) = *(undefined8 *)(puVar7 + 4);
  puVar7[4] = 0;
  puVar7[5] = 0xf;
  *(undefined *)puVar7 = 0;
  if (0xf < uStack_14) {
    uVar9 = uStack_14 + 1;
    uVar10 = auStack_28[0];
    if (0xfff < uVar9) {
      uVar10 = *(uint *)(auStack_28[0] - 4);
      uVar9 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar9);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar10 = uStack_2c + 1;
    iVar8 = aiStack_40[0];
    if (0xfff < uVar10) {
      iVar8 = *(int *)(aiStack_40[0] + -4);
      uVar10 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar10);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17975 ; VA 0x00990c10 ; FUN_00990c10 */

void __thiscall FUN_00990c10(undefined4 *param_1,int *param_2,int param_3)

{
  uint uVar1;
  code *pcVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  
  puVar3 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar3 = (undefined4 *)*param_1;
  }
  uVar1 = param_1[4];
  uVar5 = param_3 - (int)puVar3;
  if (uVar5 <= uVar1) {
    puVar3 = param_1;
    if (0xf < (uint)param_1[5]) {
      puVar3 = (undefined4 *)*param_1;
    }
    iVar4 = uVar1 - (uVar1 != uVar5);
    param_1[4] = iVar4;
    FUN_0170cc70((int)puVar3 + uVar5,(int)puVar3 + uVar5 + (uint)(uVar1 != uVar5),
                 (iVar4 - uVar5) + 1);
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    *param_2 = (int)param_1 + uVar5;
    return;
  }
  FUN_00554050();
  pcVar2 = (code *)swi(3);
  (*pcVar2)();
  return;
}



/* FUNCTION 17976 ; VA 0x00990c80 ; FUN_00990c80 */

undefined4 FUN_00990c80(undefined4 param_1,int *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  undefined auStack_c8 [160];
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017cba53;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00565940(3,1);
  iStack_8 = 0;
  iVar7 = *param_2;
  iVar2 = param_2[1];
  do {
    if (iVar7 == iVar2) {
      FUN_0058c420(param_1);
      FUN_005705c0();
      ExceptionList = pvStack_10;
      return param_1;
    }
    uVar3 = FUN_00558890(auStack_c8,&DAT_0191bfa0);
    puVar4 = (undefined4 *)FUN_00990aa0(aiStack_28,iVar7,iVar7 + 0x18);
    puVar1 = puVar4 + 4;
    iStack_8._0_1_ = 1;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    FUN_0055b3b0(uVar3,puVar4,*puVar1);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_14) {
      uVar6 = uStack_14 + 1;
      iVar5 = aiStack_28[0];
      if (0xfff < uVar6) {
        iVar5 = *(int *)(aiStack_28[0] + -4);
        uVar6 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar6);
    }
    iVar7 = iVar7 + 0x30;
  } while( true );
}



/* FUNCTION 17977 ; VA 0x00990d80 ; FUN_00990d80 */

undefined4 * FUN_00990d80(undefined4 *param_1)

{
  undefined *puVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined *puVar5;
  int iVar6;
  undefined auStack_18 [4];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792429;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  FUN_01531f50(param_1);
  puVar3 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar3 = (undefined4 *)*param_1;
  }
  iVar6 = param_1[4];
  puVar4 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar4 = (undefined4 *)*param_1;
  }
  puVar1 = (undefined *)FUN_0170db20(puVar4,0x7b,(iVar6 + (int)puVar3) - (int)puVar4);
  puVar5 = (undefined *)(iVar6 + (int)puVar3);
  if (puVar1 != (undefined *)0x0) {
    puVar5 = puVar1;
  }
  FUN_00990c10(auStack_18,puVar5);
  puVar3 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar3 = (undefined4 *)*param_1;
  }
  iVar6 = param_1[4];
  puVar4 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar4 = (undefined4 *)*param_1;
  }
  iVar2 = FUN_0170db20(puVar4,0x7d,(iVar6 + (int)puVar3) - (int)puVar4);
  iVar6 = iVar6 + (int)puVar3;
  if (iVar2 != 0) {
    iVar6 = iVar2;
  }
  FUN_00990c10(auStack_18,iVar6);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 17978 ; VA 0x00990e60 ; FUN_00990e60 */

undefined4 __thiscall FUN_00990e60(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 ***apppuStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  puVar4 = &DAT_01d64800;
  if (0xf < DAT_01d64814) {
    puVar4 = DAT_01d64800;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0151b370();
  FUN_0151b590(apppuStack_28,uVar1,puVar4);
  puVar4 = (undefined4 *)(param_1 + 0xc);
  uStack_8 = 0;
  if (0xf < *(uint *)(param_1 + 0x20)) {
    puVar4 = (undefined4 *)*puVar4;
  }
  ppppuVar2 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar2 = (undefined4 ****)apppuStack_28[0];
  }
  FUN_01675640(param_2,"%s/%s/e.png",ppppuVar2,puVar4);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    ppppuVar2 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar3) {
      ppppuVar2 = (undefined4 ****)apppuStack_28[0][-1];
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17979 ; VA 0x00990f20 ; FUN_00990f20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_00990f20(void)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined *puVar4;
  uint uVar5;
  undefined4 *puStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1318;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee341c) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ee341c), DAT_01ee341c == -1)) {
    FUN_016f3654(&LAB_01885eb0);
    FUN_016f37bf(&DAT_01ee341c);
  }
  if (DAT_01d648a0 == 0) {
    FUN_00991530();
    puVar2 = (undefined4 *)FUN_00ef85d0(auStack_18);
    iStack_28 = 0;
    uStack_24 = 0xf;
    puStack_38 = (undefined4 *)((uint)puStack_38 & 0xffffff00);
    iStack_8._0_1_ = 1;
    iStack_8._1_3_ = 0;
    (**(code **)(*(int *)*puVar2 + 0xa8))(&puStack_38);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_24) {
      uVar5 = uStack_24 + 1;
      puVar2 = puStack_38;
      if (0xfff < uVar5) {
        puVar2 = (undefined4 *)puStack_38[-1];
        uVar5 = uStack_24 + 0x24;
        if (0x1f < (uint)((int)puStack_38 + (-4 - (int)puVar2))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(puVar2,uVar5);
    }
    iStack_28 = 0;
    uStack_24 = 0xf;
    puStack_38 = (undefined4 *)((uint)puStack_38 & 0xffffff00);
    iStack_8 = 0xffffffff;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[1] + -1;
      piStack_14[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar3 = piStack_14[2] + -1;
        piStack_14[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    iVar3 = FUN_00991530();
    FUN_0054ef60(iVar3 + 0x58);
    FUN_005507b0();
    DAT_01d64890 = puStack_38;
    uRam01d64894 = uStack_34;
    uRam01d64898 = uStack_30;
    uRam01d6489c = uStack_2c;
    _DAT_01d648a0 = CONCAT44(uStack_24,iStack_28);
    if (iStack_28 == 0) {
      puVar2 = (undefined4 *)FUN_00990d80(&puStack_38);
      if ((undefined4 **)puVar2 != &DAT_01d64890) {
        FUN_005507b0();
        DAT_01d64890 = (undefined4 *)*puVar2;
        uRam01d64894 = puVar2[1];
        uRam01d64898 = puVar2[2];
        uRam01d6489c = puVar2[3];
        _DAT_01d648a0 = *(undefined8 *)(puVar2 + 4);
        puVar2[4] = 0;
        puVar2[5] = 0xf;
        *(undefined *)puVar2 = 0;
      }
      FUN_005507b0();
      DAT_01ee3415 = 1;
      puVar4 = (undefined *)FUN_00991530();
      if (puVar4 != &DAT_01d64838) {
        puVar2 = &DAT_01d64890;
        if (0xf < DAT_01d648a4) {
          puVar2 = DAT_01d64890;
        }
        FUN_005542c0(puVar2,DAT_01d648a0);
      }
      FUN_00ef85d0(auStack_20);
      iStack_8 = 2;
      FUN_00910bf0();
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar1 = piStack_1c + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01d64890;
}



/* FUNCTION 17980 ; VA 0x00991180 ; FUN_00991180 */

undefined4 __thiscall FUN_00991180(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x58);
  return param_2;
}



/* FUNCTION 17981 ; VA 0x009911a0 ; FUN_009911a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_009911a0(void)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  int aiStack_1c [5];
  uint uStack_8;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee3420) {
    FUN_016f3809(&DAT_01ee3420);
    if (DAT_01ee3420 == -1) {
      FUN_016f3654(&LAB_01885fd0);
      FUN_016f37bf(&DAT_01ee3420);
    }
  }
  if (DAT_01d648b8 == 0) {
    puVar1 = (undefined4 *)FUN_00990d80(aiStack_1c);
    if (puVar1 != &DAT_01d648a8) {
      FUN_005507b0();
      DAT_01d648a8 = *puVar1;
      uRam01d648ac = puVar1[1];
      uRam01d648b0 = puVar1[2];
      uRam01d648b4 = puVar1[3];
      _DAT_01d648b8 = *(undefined8 *)(puVar1 + 4);
      puVar1[4] = 0;
      puVar1[5] = 0xf;
      *(undefined *)puVar1 = 0;
    }
    if (0xf < uStack_8) {
      uVar3 = uStack_8 + 1;
      iVar2 = aiStack_1c[0];
      if (0xfff < uVar3) {
        iVar2 = *(int *)(aiStack_1c[0] + -4);
        uVar3 = uStack_8 + 0x24;
        if (0x1f < (aiStack_1c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar3);
    }
  }
  return &DAT_01d648a8;
}



/* FUNCTION 17982 ; VA 0x00991290 ; FUN_00991290 */

undefined4 __thiscall FUN_00991290(int param_1,undefined4 param_2,undefined4 *param_3,char param_4)

{
  undefined4 uVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined auStack_b0 [160];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c07b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00565940(3,1);
  uStack_8 = 0;
  if (param_4 == '\0') {
    piVar2 = (int *)(param_1 + 0x84);
    uVar1 = FUN_00558890(auStack_b0,&DAT_01936fb8,"&tid=");
    uVar1 = FUN_00558890(uVar1);
    if (0xf < *(uint *)(param_1 + 0x98)) {
      piVar2 = (int *)*piVar2;
    }
    uVar1 = FUN_0055b3b0(uVar1,piVar2,*(undefined4 *)(param_1 + 0x94));
    uVar1 = FUN_00558890(uVar1,"&cid=");
  }
  else {
    uVar1 = FUN_00558890(auStack_b0,&DAT_01936fb8,"&tid=");
    uVar1 = FUN_00558890(uVar1);
    uVar1 = FUN_00558890(uVar1,"UA-43420590-3","&cid=");
    uVar1 = FUN_00558890(uVar1);
  }
  puVar3 = (undefined4 *)(param_1 + 0x6c);
  if (0xf < *(uint *)(param_1 + 0x80)) {
    puVar3 = (undefined4 *)*puVar3;
  }
  uVar1 = FUN_0055b3b0(uVar1,puVar3,*(undefined4 *)(param_1 + 0x7c));
  uVar1 = FUN_00558890(uVar1,&DAT_01936fa4);
  puVar3 = param_3 + 4;
  if (0xf < (uint)param_3[5]) {
    param_3 = (undefined4 *)*param_3;
  }
  FUN_0055b3b0(uVar1,param_3,*puVar3);
  if ((DAT_01d64818 != '\0') && (DAT_01d7a8e0 != 0)) {
    uVar1 = FUN_00558890(auStack_b0,"&userId=");
    puVar3 = &DAT_01d7a8d0;
    if (0xf < DAT_01d7a8e4) {
      puVar3 = DAT_01d7a8d0;
    }
    FUN_0055b3b0(uVar1,puVar3,DAT_01d7a8e0);
  }
  if (*(int *)(param_1 + 0xf4) != 0) {
    piVar2 = (int *)(param_1 + 0xe4);
    if (0xf < *(uint *)(param_1 + 0xf8)) {
      piVar2 = (int *)*piVar2;
    }
    FUN_0055b3b0(auStack_b0,piVar2,*(undefined4 *)(param_1 + 0xf4));
  }
  FUN_0058c420(param_2);
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 17983 ; VA 0x00991430 ; FUN_00991430 */

void FUN_00991430(char param_1,undefined4 param_2,undefined4 param_3)

{
  undefined *puVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  puVar1 = &DAT_01d64878;
  if (param_1 == '\0') {
    puVar1 = &DAT_01d64860;
  }
  ExceptionList = &pvStack_10;
  FUN_00d82810(puVar1,param_2,&DAT_01d79f68,param_3,0,1);
  if (DAT_01d64850 != '\0') {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("GAUsageCounter",0xe);
    uStack_8 = 0;
    FUN_008783f0(auStack_28,1,0);
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      uVar2 = auStack_28[0];
      if (0xfff < uVar3) {
        uVar2 = *(uint *)(auStack_28[0] - 4);
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar2,uVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17984 ; VA 0x00991500 ; FUN_00991500 */

void __thiscall FUN_00991500(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  if ((undefined4 *)(param_1 + 0x58) != param_2) {
    puVar1 = param_2 + 4;
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_005542c0(param_2,*puVar1);
  }
  return;
}



/* FUNCTION 17985 ; VA 0x00991530 ; FUN_00991530 */

int FUN_00991530(void)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint *puVar8;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  uint *puStack_20;
  undefined uStack_1c;
  int iStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1348;
  pvStack_10 = ExceptionList;
  iVar5 = DAT_01ee3418;
  if (DAT_01ee3418 == 0) {
    ExceptionList = &pvStack_10;
    piVar2 = (int *)FUN_00ef85d0(auStack_30);
    iVar5 = *piVar2;
    iStack_18 = iVar5;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar1 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        iVar1 = piStack_2c[2] + -1;
        piStack_2c[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piStack_2c + 4))();
        }
      }
    }
    puVar8 = (uint *)(iVar5 + 0x94);
    uStack_1c = 0;
    puStack_20 = puVar8;
    if (puVar8 == (uint *)0x0) {
      uVar3 = FUN_0056aeb0(1,"boost unique_lock has no mutex");
      uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
      FUN_00564990(uVar3);
    }
    LOCK();
    uVar4 = *puVar8;
    *puVar8 = *puVar8 | 0x80000000;
    UNLOCK();
    if ((int)uVar4 < 0) {
      uVar4 = *puVar8;
      do {
        uVar6 = uVar4;
        uVar7 = uVar6 + 1;
        if (-1 < (int)uVar6) {
          uVar7 = uVar6 | 0x80000000;
        }
        LOCK();
        uVar4 = *puVar8;
        if (uVar6 == uVar4) {
          *puVar8 = uVar7;
          uVar4 = uVar6;
        }
        UNLOCK();
      } while (uVar4 != uVar6);
      if (-1 < (int)uVar6) {
        uVar7 = uVar6;
      }
      if ((int)uVar7 < 0) {
        uVar3 = FUN_00554e40();
        do {
          WaitForSingleObjectEx(uVar3,0xffffffff,0);
          uVar4 = uVar7 & 0x3fffffff | 0x40000000;
          do {
            uVar7 = uVar4;
            uVar6 = uVar7;
            if (-1 < (int)uVar7) {
              uVar6 = uVar7 - 1 | 0x80000000;
            }
            LOCK();
            uVar4 = *puVar8;
            if (uVar7 == uVar4) {
              *puVar8 = uVar6 & 0xbfffffff;
              uVar4 = uVar7;
            }
            UNLOCK();
          } while (uVar4 != uVar7);
        } while ((int)uVar7 < 0);
      }
    }
    uStack_1c = 1;
    uStack_8 = 2;
    if (DAT_01ee3418 == 0) {
      FUN_009905a0(auStack_28);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      FUN_008a65e0(iStack_18,0);
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_24[1] + -1;
        piStack_24[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar2 = piStack_24 + 2;
          iVar5 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar5 == 1) {
            (**(code **)(*piStack_24 + 4))();
          }
        }
      }
    }
    iVar5 = DAT_01ee3418;
    uStack_8 = 4;
    LOCK();
    uVar4 = *puVar8;
    *puVar8 = *puVar8 + 0x80000000;
    UNLOCK();
    if (((uVar4 & 0x40000000) == 0) && (-0x80000000 < (int)uVar4)) {
      LOCK();
      uVar4 = *puVar8;
      *puVar8 = *puVar8 | 0x40000000;
      UNLOCK();
      if ((uVar4 >> 0x1e & 1) == 0) {
        uVar3 = FUN_00554e40();
        SetEvent(uVar3);
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 17986 ; VA 0x00991700 ; FUN_00991700 */

void __thiscall
FUN_00991700(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  if (*(char *)(param_1 + 1) != '\0') {
    FUN_00991760(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  }
  if (*(char *)(param_1 + 2) != '\0') {
    FUN_009928b0(param_2,param_3,param_4,param_5,param_6,param_7);
  }
  return;
}



/* FUNCTION 17987 ; VA 0x00991760 ; FUN_00991760 */

void __thiscall
FUN_00991760(char *param_1,char *param_2,char *param_3,char *param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 *puVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined *puVar6;
  char *pcVar7;
  uint uVar8;
  uint uVar9;
  undefined auStack_200 [160];
  uint auStack_160 [4];
  undefined4 uStack_150;
  uint uStack_14c;
  uint auStack_148 [4];
  undefined4 uStack_138;
  uint uStack_134;
  uint auStack_130 [4];
  undefined4 uStack_120;
  uint uStack_11c;
  uint auStack_118 [4];
  undefined4 uStack_108;
  uint uStack_104;
  uint auStack_100 [4];
  undefined4 uStack_f0;
  uint uStack_ec;
  uint auStack_e8 [4];
  undefined4 uStack_d8;
  uint uStack_d4;
  uint auStack_d0 [4];
  undefined4 uStack_c0;
  uint uStack_bc;
  uint auStack_b8 [4];
  undefined4 uStack_a8;
  uint uStack_a4;
  uint auStack_a0 [4];
  undefined4 uStack_90;
  uint uStack_8c;
  uint auStack_88 [4];
  undefined4 uStack_78;
  uint uStack_74;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1414;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00565940(3,1);
  uStack_8 = 0;
  FUN_00565940(3,1);
  uStack_8._0_1_ = 1;
  FUN_00872bd0(param_5,param_6);
  uStack_f0 = 0;
  uStack_ec = 0xf;
  auStack_100[0] = auStack_100[0] & 0xffffff00;
  FUN_005542c0("event",5);
  uStack_8._0_1_ = 2;
  puVar4 = (undefined4 *)FUN_00991290(auStack_28,auStack_100,param_8);
  puVar1 = puVar4 + 4;
  uStack_8._0_1_ = 3;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  uVar5 = FUN_0055b3b0(auStack_200,puVar4,*puVar1);
  uVar5 = FUN_00558890(uVar5,&DAT_0191bfa0);
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  pcVar7 = param_2;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(param_2,(int)pcVar7 - (int)(param_2 + 1));
  uStack_8._0_1_ = 4;
  uStack_d8 = 0;
  uStack_d4 = 0xf;
  auStack_e8[0] = auStack_e8[0] & 0xffffff00;
  FUN_005542c0(&DAT_01936fe0,2);
  uStack_8._0_1_ = 5;
  puVar4 = (undefined4 *)FUN_00990aa0(auStack_160,auStack_e8,auStack_70);
  puVar1 = puVar4 + 4;
  uStack_8._0_1_ = 6;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  uVar5 = FUN_0055b3b0(uVar5,puVar4,*puVar1);
  uVar5 = FUN_00558890(uVar5,&DAT_0191bfa0);
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  pcVar7 = param_3;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(param_3,(int)pcVar7 - (int)(param_3 + 1));
  uStack_8._0_1_ = 7;
  uStack_c0 = 0;
  uStack_bc = 0xf;
  auStack_d0[0] = auStack_d0[0] & 0xffffff00;
  FUN_005542c0(&DAT_01936fdc,2);
  uStack_8._0_1_ = 8;
  puVar4 = (undefined4 *)FUN_00990aa0(auStack_148,auStack_d0,auStack_58);
  puVar1 = puVar4 + 4;
  uStack_8._0_1_ = 9;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  uVar5 = FUN_0055b3b0(uVar5,puVar4,*puVar1);
  uVar5 = FUN_00558890(uVar5,&DAT_0191bfa0);
  FUN_0058c420(auStack_b8);
  uStack_8._0_1_ = 10;
  uStack_90 = 0;
  uStack_8c = 0xf;
  auStack_a0[0] = auStack_a0[0] & 0xffffff00;
  FUN_005542c0(&DAT_01936fd8,2);
  uStack_8._0_1_ = 0xb;
  puVar4 = (undefined4 *)FUN_00990aa0(auStack_130,auStack_a0,auStack_b8);
  puVar1 = puVar4 + 4;
  uStack_8._0_1_ = 0xc;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  uVar5 = FUN_0055b3b0(uVar5,puVar4,*puVar1);
  uVar5 = FUN_00558890(uVar5,&DAT_0191bfa0);
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  pcVar7 = param_4;
  do {
    cVar2 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  FUN_005542c0(param_4,(int)pcVar7 - (int)(param_4 + 1));
  uStack_8._0_1_ = 0xd;
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  FUN_005542c0(&DAT_0192b7d4,2);
  uStack_8._0_1_ = 0xe;
  puVar4 = (undefined4 *)FUN_00990aa0(auStack_118,auStack_88,auStack_40);
  puVar1 = puVar4 + 4;
  uStack_8._0_1_ = 0xf;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  FUN_0055b3b0(uVar5,puVar4,*puVar1);
  uStack_8._0_1_ = 0xe;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xe;
  if (0xf < uStack_104) {
    uVar9 = uStack_104 + 1;
    uVar8 = auStack_118[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_118[0] - 4);
      uVar9 = uStack_104 + 0x24;
      if (0x1f < (auStack_118[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_108 = 0;
  uStack_104 = 0xf;
  auStack_118[0] = auStack_118[0] & 0xffffff00;
  uStack_8._0_1_ = 0xd;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xd;
  if (0xf < uStack_74) {
    uVar9 = uStack_74 + 1;
    uVar8 = auStack_88[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_88[0] - 4);
      uVar9 = uStack_74 + 0x24;
      if (0x1f < (auStack_88[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_8._0_1_ = 0xc;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xc;
  if (0xf < uStack_2c) {
    uVar9 = uStack_2c + 1;
    uVar8 = auStack_40[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_40[0] - 4);
      uVar9 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  uStack_8._0_1_ = 0xb;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xb;
  if (0xf < uStack_11c) {
    uVar9 = uStack_11c + 1;
    uVar8 = auStack_130[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_130[0] - 4);
      uVar9 = uStack_11c + 0x24;
      if (0x1f < (auStack_130[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_120 = 0;
  uStack_11c = 0xf;
  auStack_130[0] = auStack_130[0] & 0xffffff00;
  uStack_8._0_1_ = 10;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 10;
  if (0xf < uStack_8c) {
    uVar9 = uStack_8c + 1;
    uVar8 = auStack_a0[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_a0[0] - 4);
      uVar9 = uStack_8c + 0x24;
      if (0x1f < (auStack_a0[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_8._0_1_ = 9;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 9;
  if (0xf < uStack_a4) {
    uVar9 = uStack_a4 + 1;
    uVar8 = auStack_b8[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_b8[0] - 4);
      uVar9 = uStack_a4 + 0x24;
      if (0x1f < (auStack_b8[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_a8 = 0;
  uStack_a4 = 0xf;
  auStack_b8[0] = auStack_b8[0] & 0xffffff00;
  uStack_8._0_1_ = 8;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  if (0xf < uStack_134) {
    uVar9 = uStack_134 + 1;
    uVar8 = auStack_148[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_148[0] - 4);
      uVar9 = uStack_134 + 0x24;
      if (0x1f < (auStack_148[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_138 = 0;
  uStack_134 = 0xf;
  auStack_148[0] = auStack_148[0] & 0xffffff00;
  uStack_8._0_1_ = 7;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 7;
  if (0xf < uStack_bc) {
    uVar9 = uStack_bc + 1;
    uVar8 = auStack_d0[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_d0[0] - 4);
      uVar9 = uStack_bc + 0x24;
      if (0x1f < (auStack_d0[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_8._0_1_ = 6;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 6;
  if (0xf < uStack_44) {
    uVar9 = uStack_44 + 1;
    uVar8 = auStack_58[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_58[0] - 4);
      uVar9 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  uStack_8._0_1_ = 5;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 5;
  if (0xf < uStack_14c) {
    uVar9 = uStack_14c + 1;
    uVar8 = auStack_160[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_160[0] - 4);
      uVar9 = uStack_14c + 0x24;
      if (0x1f < (auStack_160[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_150 = 0;
  uStack_14c = 0xf;
  auStack_160[0] = auStack_160[0] & 0xffffff00;
  uStack_8._0_1_ = 4;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  if (0xf < uStack_d4) {
    uVar9 = uStack_d4 + 1;
    uVar8 = auStack_e8[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_e8[0] - 4);
      uVar9 = uStack_d4 + 0x24;
      if (0x1f < (auStack_e8[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_8._0_1_ = 3;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_5c) {
    uVar9 = uStack_5c + 1;
    uVar8 = auStack_70[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_70[0] - 4);
      uVar9 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  uStack_8._0_1_ = 2;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < uStack_14) {
    uVar9 = uStack_14 + 1;
    uVar8 = auStack_28[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_28[0] - 4);
      uVar9 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  uStack_8._0_1_ = 1;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_ec) {
    uVar9 = uStack_ec + 1;
    uVar8 = auStack_100[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_100[0] - 4);
      uVar9 = uStack_ec + 0x24;
      if (0x1f < (auStack_100[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  if (DAT_01d64850 == '\0') {
    FUN_0058c420(auStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
    puVar6 = &DAT_01d64878;
    if (*param_1 == '\0') {
      puVar6 = &DAT_01d64860;
    }
    FUN_00d82810(puVar6,auStack_28,&DAT_01d79f68,param_7,0,1);
  }
  else {
    FUN_0058c420(auStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
    FUN_00991430(*param_1,auStack_28,param_7);
  }
  if (0xf < uStack_14) {
    uVar9 = uStack_14 + 1;
    uVar8 = auStack_28[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_28[0] - 4);
      uVar9 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  FUN_005705c0();
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17988 ; VA 0x00991fc0 ; FUN_00991fc0 */

void __thiscall
FUN_00991fc0(char *param_1,char *param_2,char *param_3,undefined4 param_4,undefined4 param_5,
            int param_6,int param_7,undefined4 param_8,undefined4 param_9,int param_10,
            undefined4 param_11,undefined4 param_12,undefined4 param_13,undefined4 param_14)

{
  char cVar1;
  undefined uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined *puVar5;
  int *piVar6;
  char *pcVar7;
  uint uVar8;
  uint uVar9;
  undefined4 *puVar10;
  undefined auStack_2b0 [176];
  undefined auStack_200 [160];
  uint auStack_160 [4];
  undefined4 uStack_150;
  uint uStack_14c;
  uint auStack_148 [4];
  undefined4 uStack_138;
  uint uStack_134;
  uint auStack_130 [4];
  undefined4 uStack_120;
  uint uStack_11c;
  uint auStack_118 [4];
  undefined4 uStack_108;
  uint uStack_104;
  uint auStack_100 [4];
  undefined4 uStack_f0;
  uint uStack_ec;
  uint auStack_e8 [4];
  undefined4 uStack_d8;
  uint uStack_d4;
  uint auStack_d0 [4];
  undefined4 uStack_c0;
  uint uStack_bc;
  uint auStack_b8 [4];
  undefined4 uStack_a8;
  uint uStack_a4;
  uint auStack_a0 [4];
  undefined4 uStack_90;
  uint uStack_8c;
  uint auStack_88 [4];
  undefined4 uStack_78;
  uint uStack_74;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d14e7;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00565940(3,1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00558890(auStack_2b0,param_4);
  if (param_7 == 0) {
    puVar10 = (undefined4 *)0x0;
  }
  else {
    puVar10 = *(undefined4 **)(param_10 + param_6 * 4);
  }
  for (; puVar10 != (undefined4 *)0x0; puVar10 = (undefined4 *)*puVar10) {
    piVar6 = puVar10 + 2;
    uVar3 = FUN_00558890(auStack_2b0,&DAT_0191bfa0);
    if (0xf < (uint)puVar10[7]) {
      piVar6 = (int *)*piVar6;
    }
    uVar3 = FUN_0055b3b0(uVar3,piVar6,puVar10[6]);
    puVar4 = puVar10 + 8;
    uVar3 = FUN_00558890(uVar3,&DAT_0191bf9c);
    if (0xf < (uint)puVar10[0xd]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    FUN_0055b3b0(uVar3,puVar4,puVar10[0xc]);
  }
  FUN_0058c420(auStack_100);
  uStack_8._0_1_ = 2;
  FUN_00565940(3,1);
  uStack_8._0_1_ = 3;
  FUN_00565940(3,1);
  uStack_8._0_1_ = 4;
  FUN_00872bd0(param_11,param_12);
  uStack_d8 = 0;
  uStack_d4 = 0xf;
  auStack_e8[0] = auStack_e8[0] & 0xffffff00;
  FUN_005542c0("event",5);
  uStack_8._0_1_ = 5;
  puVar4 = (undefined4 *)FUN_00991290(auStack_28,auStack_e8,param_14);
  puVar10 = puVar4 + 4;
  uStack_8._0_1_ = 6;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  uVar3 = FUN_0055b3b0(auStack_200,puVar4,*puVar10);
  uVar3 = FUN_00558890(uVar3,&DAT_0191bfa0);
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  pcVar7 = param_2;
  do {
    cVar1 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_2,(int)pcVar7 - (int)(param_2 + 1));
  uStack_8._0_1_ = 7;
  uStack_c0 = 0;
  uStack_bc = 0xf;
  auStack_d0[0] = auStack_d0[0] & 0xffffff00;
  FUN_005542c0(&DAT_01936fe0,2);
  uStack_8._0_1_ = 8;
  puVar4 = (undefined4 *)FUN_00990aa0(auStack_160,auStack_d0,auStack_58);
  puVar10 = puVar4 + 4;
  uStack_8._0_1_ = 9;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  uVar3 = FUN_0055b3b0(uVar3,puVar4,*puVar10);
  uVar3 = FUN_00558890(uVar3,&DAT_0191bfa0);
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  pcVar7 = param_3;
  do {
    cVar1 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_3,(int)pcVar7 - (int)(param_3 + 1));
  uStack_8._0_1_ = 10;
  uStack_a8 = 0;
  uStack_a4 = 0xf;
  auStack_b8[0] = auStack_b8[0] & 0xffffff00;
  FUN_005542c0(&DAT_01936fdc,2);
  uStack_8._0_1_ = 0xb;
  puVar4 = (undefined4 *)FUN_00990aa0(auStack_148,auStack_b8,auStack_40);
  puVar10 = puVar4 + 4;
  uStack_8._0_1_ = 0xc;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  uVar3 = FUN_0055b3b0(uVar3,puVar4,*puVar10);
  uVar3 = FUN_00558890(uVar3,&DAT_0191bfa0);
  FUN_0058c420(auStack_a0);
  uStack_8._0_1_ = 0xd;
  uStack_78 = 0;
  uStack_74 = 0xf;
  auStack_88[0] = auStack_88[0] & 0xffffff00;
  FUN_005542c0(&DAT_01936fd8,2);
  uStack_8._0_1_ = 0xe;
  puVar4 = (undefined4 *)FUN_00990aa0(auStack_130,auStack_88,auStack_a0);
  puVar10 = puVar4 + 4;
  uStack_8._0_1_ = 0xf;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  uVar3 = FUN_0055b3b0(uVar3,puVar4,*puVar10);
  uVar3 = FUN_00558890(uVar3,&DAT_0191bfa0);
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  FUN_005542c0(&DAT_0192b7d4,2);
  uStack_8._0_1_ = 0x10;
  puVar4 = (undefined4 *)FUN_00990aa0(auStack_118,auStack_70,auStack_100);
  puVar10 = puVar4 + 4;
  uStack_8._0_1_ = 0x11;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  FUN_0055b3b0(uVar3,puVar4,*puVar10);
  uStack_8._0_1_ = 0x10;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0x10;
  if (0xf < uStack_104) {
    uVar9 = uStack_104 + 1;
    uVar8 = auStack_118[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_118[0] - 4);
      uVar9 = uStack_104 + 0x24;
      if (0x1f < (auStack_118[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_108 = 0;
  uStack_104 = 0xf;
  auStack_118[0] = auStack_118[0] & 0xffffff00;
  uStack_8._0_1_ = 0xf;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xf;
  if (0xf < uStack_5c) {
    uVar9 = uStack_5c + 1;
    uVar8 = auStack_70[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_70[0] - 4);
      uVar9 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_8._0_1_ = 0xe;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xe;
  if (0xf < uStack_11c) {
    uVar9 = uStack_11c + 1;
    uVar8 = auStack_130[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_130[0] - 4);
      uVar9 = uStack_11c + 0x24;
      if (0x1f < (auStack_130[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_120 = 0;
  uStack_11c = 0xf;
  auStack_130[0] = auStack_130[0] & 0xffffff00;
  uStack_8._0_1_ = 0xd;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xd;
  if (0xf < uStack_74) {
    uVar9 = uStack_74 + 1;
    uVar8 = auStack_88[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_88[0] - 4);
      uVar9 = uStack_74 + 0x24;
      if (0x1f < (auStack_88[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_8._0_1_ = 0xc;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xc;
  if (0xf < uStack_8c) {
    uVar9 = uStack_8c + 1;
    uVar8 = auStack_a0[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_a0[0] - 4);
      uVar9 = uStack_8c + 0x24;
      if (0x1f < (auStack_a0[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_90 = 0;
  uStack_8c = 0xf;
  auStack_a0[0] = auStack_a0[0] & 0xffffff00;
  uStack_8._0_1_ = 0xb;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xb;
  if (0xf < uStack_134) {
    uVar9 = uStack_134 + 1;
    uVar8 = auStack_148[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_148[0] - 4);
      uVar9 = uStack_134 + 0x24;
      if (0x1f < (auStack_148[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_138 = 0;
  uStack_134 = 0xf;
  auStack_148[0] = auStack_148[0] & 0xffffff00;
  uStack_8._0_1_ = 10;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 10;
  if (0xf < uStack_a4) {
    uVar9 = uStack_a4 + 1;
    uVar8 = auStack_b8[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_b8[0] - 4);
      uVar9 = uStack_a4 + 0x24;
      if (0x1f < (auStack_b8[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_8._0_1_ = 9;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 9;
  if (0xf < uStack_2c) {
    uVar9 = uStack_2c + 1;
    uVar8 = auStack_40[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_40[0] - 4);
      uVar9 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  uStack_8._0_1_ = 8;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  if (0xf < uStack_14c) {
    uVar9 = uStack_14c + 1;
    uVar8 = auStack_160[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_160[0] - 4);
      uVar9 = uStack_14c + 0x24;
      if (0x1f < (auStack_160[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_150 = 0;
  uStack_14c = 0xf;
  auStack_160[0] = auStack_160[0] & 0xffffff00;
  uStack_8._0_1_ = 7;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 7;
  if (0xf < uStack_bc) {
    uVar9 = uStack_bc + 1;
    uVar8 = auStack_d0[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_d0[0] - 4);
      uVar9 = uStack_bc + 0x24;
      if (0x1f < (auStack_d0[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_8._0_1_ = 6;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 6;
  if (0xf < uStack_44) {
    uVar9 = uStack_44 + 1;
    uVar8 = auStack_58[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_58[0] - 4);
      uVar9 = uStack_44 + 0x24;
      if (0x1f < (auStack_58[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_48 = 0;
  uStack_44 = 0xf;
  auStack_58[0] = auStack_58[0] & 0xffffff00;
  uStack_8._0_1_ = 5;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 5;
  if (0xf < uStack_14) {
    uVar9 = uStack_14 + 1;
    uVar8 = auStack_28[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_28[0] - 4);
      uVar9 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  uStack_8._0_1_ = 4;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  if (0xf < uStack_d4) {
    uVar9 = uStack_d4 + 1;
    uVar8 = auStack_e8[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_e8[0] - 4);
      uVar9 = uStack_d4 + 0x24;
      if (0x1f < (auStack_e8[0] - uVar8) - 4) {
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  if (DAT_01d64850 == '\0') {
    FUN_0058c420(auStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
    puVar5 = &DAT_01d64878;
    if (*param_1 == '\0') {
      puVar5 = &DAT_01d64860;
    }
    FUN_00d82810(puVar5,auStack_28,&DAT_01d79f68,param_13,0,1);
  }
  else {
    FUN_0058c420(auStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
    FUN_00991430(*param_1,auStack_28,param_13);
  }
  if (0xf < uStack_14) {
    uVar9 = uStack_14 + 1;
    uVar8 = auStack_28[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_28[0] - 4);
      uVar9 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar8) - 4) goto LAB_0099289f;
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  FUN_005705c0();
  FUN_005705c0();
  if (0xf < uStack_ec) {
    uVar9 = uStack_ec + 1;
    uVar8 = auStack_100[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_100[0] - 4);
      uVar9 = uStack_ec + 0x24;
      if (0x1f < (auStack_100[0] - uVar8) - 4) {
LAB_0099289f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_f0 = 0;
  uStack_ec = 0xf;
  auStack_100[0] = auStack_100[0] & 0xffffff00;
  FUN_005705c0();
  FUN_0056cfd0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17989 ; VA 0x009928b0 ; FUN_009928b0 */

void __thiscall
FUN_009928b0(int param_1,char *param_2,char *param_3,char *param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7)

{
  undefined4 *puVar1;
  char cVar2;
  undefined uVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  char *pcVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  int *piVar11;
  undefined8 uVar12;
  undefined auStack_290 [160];
  uint auStack_1f0 [4];
  undefined4 uStack_1e0;
  uint uStack_1dc;
  uint auStack_1d8 [4];
  undefined4 uStack_1c8;
  uint uStack_1c4;
  uint auStack_1c0 [4];
  undefined4 uStack_1b0;
  uint uStack_1ac;
  uint auStack_1a8 [4];
  undefined4 uStack_198;
  uint uStack_194;
  uint auStack_190 [4];
  undefined4 uStack_180;
  uint uStack_17c;
  uint auStack_178 [4];
  undefined4 uStack_168;
  uint uStack_164;
  uint auStack_160 [4];
  undefined4 uStack_150;
  uint uStack_14c;
  uint auStack_148 [4];
  undefined4 uStack_138;
  uint uStack_134;
  uint auStack_130 [4];
  undefined4 uStack_120;
  uint uStack_11c;
  uint auStack_118 [4];
  undefined4 uStack_108;
  uint uStack_104;
  uint auStack_100 [4];
  undefined4 uStack_f0;
  uint uStack_ec;
  uint auStack_e8 [4];
  undefined4 uStack_d8;
  uint uStack_d4;
  uint auStack_d0 [4];
  undefined4 uStack_c0;
  uint uStack_bc;
  uint auStack_b8 [4];
  undefined4 uStack_a8;
  uint uStack_a4;
  uint auStack_a0 [4];
  undefined4 uStack_90;
  uint uStack_8c;
  uint auStack_88 [4];
  undefined4 uStack_78;
  uint uStack_74;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1601;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x1c) != 0) {
    ExceptionList = &pvStack_10;
    FUN_00565940(3,1);
    uStack_8 = 0;
    FUN_00565940(3,1);
    uStack_8._0_1_ = 1;
    FUN_00872bd0(param_5,param_6);
    FUN_00565940(3,1);
    uStack_8._0_1_ = 2;
    uVar12 = FUN_016de945();
    uVar12 = FUN_016f3900(uVar12,10000,0);
    FUN_00872bd0(uVar12);
    piVar4 = (int *)(param_1 + 0x3c);
    if (0xf < *(uint *)(param_1 + 0x50)) {
      piVar4 = (int *)*piVar4;
    }
    uVar5 = FUN_0055b3b0(auStack_290,piVar4,*(undefined4 *)(param_1 + 0x4c));
    piVar4 = (int *)(param_1 + 0x54);
    if (0xf < *(uint *)(param_1 + 0x68)) {
      piVar4 = (int *)*piVar4;
    }
    uVar5 = FUN_0055b3b0(uVar5,piVar4,*(undefined4 *)(param_1 + 100));
    piVar4 = (int *)(param_1 + 0x24);
    uVar5 = FUN_00558890(uVar5,&DAT_0191bfa0);
    if (0xf < *(uint *)(param_1 + 0x38)) {
      piVar4 = (int *)*piVar4;
    }
    uVar5 = FUN_0055b3b0(uVar5,piVar4,*(undefined4 *)(param_1 + 0x34));
    piVar4 = (int *)(param_1 + 0x6c);
    if (0xf < *(uint *)(param_1 + 0x80)) {
      piVar4 = (int *)*piVar4;
    }
    uVar5 = FUN_0055b3b0(uVar5,piVar4,*(undefined4 *)(param_1 + 0x7c));
    uVar5 = FUN_00558890(uVar5,&DAT_0191bfa0);
    FUN_0058c420(aiStack_28);
    uStack_8._0_1_ = 3;
    uStack_120 = 0;
    uStack_11c = 0xf;
    auStack_130[0] = auStack_130[0] & 0xffffff00;
    FUN_005542c0("timestamp",9);
    uStack_8._0_1_ = 4;
    puVar6 = (undefined4 *)FUN_00990aa0(auStack_1f0,auStack_130,aiStack_28);
    puVar1 = puVar6 + 4;
    uStack_8._0_1_ = 5;
    if (0xf < (uint)puVar6[5]) {
      puVar6 = (undefined4 *)*puVar6;
    }
    uVar5 = FUN_0055b3b0(uVar5,puVar6,*puVar1);
    uVar5 = FUN_00558890(uVar5,&DAT_0191bfa0);
    uStack_108 = 0;
    uStack_104 = 0xf;
    auStack_118[0] = auStack_118[0] & 0xffffff00;
    FUN_005542c0("userID",6);
    uStack_8._0_1_ = 6;
    puVar6 = (undefined4 *)FUN_00990aa0(auStack_1d8,auStack_118,&DAT_01d7a8d0);
    puVar1 = puVar6 + 4;
    uStack_8._0_1_ = 7;
    if (0xf < (uint)puVar6[5]) {
      puVar6 = (undefined4 *)*puVar6;
    }
    uVar5 = FUN_0055b3b0(uVar5,puVar6,*puVar1);
    uVar5 = FUN_00558890(uVar5,&DAT_0191bfa0);
    uStack_f0 = 0;
    uStack_ec = 0xf;
    auStack_100[0] = auStack_100[0] & 0xffffff00;
    FUN_005542c0("placeID",7);
    uStack_8._0_1_ = 8;
    puVar6 = (undefined4 *)FUN_00990aa0(auStack_1c0,auStack_100,&DAT_01d7a8e8);
    puVar1 = puVar6 + 4;
    uStack_8._0_1_ = 9;
    if (0xf < (uint)puVar6[5]) {
      puVar6 = (undefined4 *)*puVar6;
    }
    uVar5 = FUN_0055b3b0(uVar5,puVar6,*puVar1);
    uVar5 = FUN_00558890(uVar5,&DAT_0191bfa0);
    uStack_60 = 0;
    uStack_5c = 0xf;
    auStack_70[0] = auStack_70[0] & 0xffffff00;
    pcVar7 = param_2;
    do {
      cVar2 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar2 != '\0');
    FUN_005542c0(param_2,(int)pcVar7 - (int)(param_2 + 1));
    uStack_8._0_1_ = 10;
    uStack_d8 = 0;
    uStack_d4 = 0xf;
    auStack_e8[0] = auStack_e8[0] & 0xffffff00;
    FUN_005542c0("category",8);
    uStack_8._0_1_ = 0xb;
    puVar6 = (undefined4 *)FUN_00990aa0(auStack_1a8,auStack_e8,auStack_70);
    puVar1 = puVar6 + 4;
    uStack_8._0_1_ = 0xc;
    if (0xf < (uint)puVar6[5]) {
      puVar6 = (undefined4 *)*puVar6;
    }
    uVar5 = FUN_0055b3b0(uVar5,puVar6,*puVar1);
    uVar5 = FUN_00558890(uVar5,&DAT_0191bfa0);
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    pcVar7 = param_3;
    do {
      cVar2 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar2 != '\0');
    FUN_005542c0(param_3,(int)pcVar7 - (int)(param_3 + 1));
    uStack_8._0_1_ = 0xd;
    uStack_c0 = 0;
    uStack_bc = 0xf;
    auStack_d0[0] = auStack_d0[0] & 0xffffff00;
    FUN_005542c0(&DAT_018cc3ac,3);
    uStack_8._0_1_ = 0xe;
    puVar6 = (undefined4 *)FUN_00990aa0(auStack_190,auStack_d0,auStack_58);
    puVar1 = puVar6 + 4;
    uStack_8._0_1_ = 0xf;
    if (0xf < (uint)puVar6[5]) {
      puVar6 = (undefined4 *)*puVar6;
    }
    uVar5 = FUN_0055b3b0(uVar5,puVar6,*puVar1);
    uVar5 = FUN_00558890(uVar5,&DAT_0191bfa0);
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    pcVar7 = param_4;
    do {
      cVar2 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar2 != '\0');
    FUN_005542c0(param_4,(int)pcVar7 - (int)(param_4 + 1));
    uStack_8._0_1_ = 0x10;
    uStack_a8 = 0;
    uStack_a4 = 0xf;
    auStack_b8[0] = auStack_b8[0] & 0xffffff00;
    FUN_005542c0("label",5);
    uStack_8._0_1_ = 0x11;
    puVar6 = (undefined4 *)FUN_00990aa0(auStack_178,auStack_b8,auStack_40);
    puVar1 = puVar6 + 4;
    uStack_8._0_1_ = 0x12;
    if (0xf < (uint)puVar6[5]) {
      puVar6 = (undefined4 *)*puVar6;
    }
    uVar5 = FUN_0055b3b0(uVar5,puVar6,*puVar1);
    uVar5 = FUN_00558890(uVar5,&DAT_0191bfa0);
    FUN_0058c420(auStack_a0);
    uStack_8._0_1_ = 0x13;
    uStack_78 = 0;
    uStack_74 = 0xf;
    auStack_88[0] = auStack_88[0] & 0xffffff00;
    FUN_005542c0("value",5);
    uStack_8._0_1_ = 0x14;
    puVar6 = (undefined4 *)FUN_00990aa0(auStack_160,auStack_88,auStack_a0);
    puVar1 = puVar6 + 4;
    uStack_8._0_1_ = 0x15;
    if (0xf < (uint)puVar6[5]) {
      puVar6 = (undefined4 *)*puVar6;
    }
    uVar5 = FUN_0055b3b0(uVar5,puVar6,*puVar1);
    piVar4 = (int *)(param_1 + 0xb4);
    if (0xf < *(uint *)(param_1 + 200)) {
      piVar4 = (int *)*piVar4;
    }
    piVar11 = (int *)(param_1 + 0xcc);
    uVar5 = FUN_0055b3b0(uVar5,piVar4,*(undefined4 *)(param_1 + 0xc4));
    if (0xf < *(uint *)(param_1 + 0xe0)) {
      piVar11 = (int *)*piVar11;
    }
    FUN_0055b3b0(uVar5,piVar11,*(undefined4 *)(param_1 + 0xdc));
    uStack_8._0_1_ = 0x14;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x14;
    if (0xf < uStack_14c) {
      uVar9 = uStack_14c + 1;
      uVar10 = auStack_160[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_160[0] - 4);
        uVar9 = uStack_14c + 0x24;
        if (0x1f < (auStack_160[0] - uVar10) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_150 = 0;
    uStack_14c = 0xf;
    auStack_160[0] = auStack_160[0] & 0xffffff00;
    uStack_8._0_1_ = 0x13;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x13;
    if (0xf < uStack_74) {
      uVar9 = uStack_74 + 1;
      uVar10 = auStack_88[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_88[0] - 4);
        uVar9 = uStack_74 + 0x24;
        if (0x1f < (auStack_88[0] - uVar10) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_8._0_1_ = 0x12;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x12;
    if (0xf < uStack_8c) {
      uVar9 = uStack_8c + 1;
      uVar10 = auStack_a0[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_a0[0] - 4);
        uVar9 = uStack_8c + 0x24;
        if (0x1f < (auStack_a0[0] - uVar10) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_90 = 0;
    uStack_8c = 0xf;
    auStack_a0[0] = auStack_a0[0] & 0xffffff00;
    uStack_8._0_1_ = 0x11;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x11;
    if (0xf < uStack_164) {
      uVar9 = uStack_164 + 1;
      uVar10 = auStack_178[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_178[0] - 4);
        uVar9 = uStack_164 + 0x24;
        if (0x1f < (auStack_178[0] - uVar10) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_168 = 0;
    uStack_164 = 0xf;
    auStack_178[0] = auStack_178[0] & 0xffffff00;
    uStack_8._0_1_ = 0x10;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x10;
    if (0xf < uStack_a4) {
      uVar9 = uStack_a4 + 1;
      uVar10 = auStack_b8[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_b8[0] - 4);
        uVar9 = uStack_a4 + 0x24;
        if (0x1f < (auStack_b8[0] - uVar10) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_8._0_1_ = 0xf;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xf;
    if (0xf < uStack_2c) {
      uVar9 = uStack_2c + 1;
      uVar10 = auStack_40[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_40[0] - 4);
        uVar9 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar10) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    uStack_8._0_1_ = 0xe;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xe;
    if (0xf < uStack_17c) {
      uVar9 = uStack_17c + 1;
      uVar10 = auStack_190[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_190[0] - 4);
        uVar9 = uStack_17c + 0x24;
        if (0x1f < (auStack_190[0] - uVar10) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_180 = 0;
    uStack_17c = 0xf;
    auStack_190[0] = auStack_190[0] & 0xffffff00;
    uStack_8._0_1_ = 0xd;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xd;
    if (0xf < uStack_bc) {
      uVar9 = uStack_bc + 1;
      uVar10 = auStack_d0[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_d0[0] - 4);
        uVar9 = uStack_bc + 0x24;
        if (0x1f < (auStack_d0[0] - uVar10) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_8._0_1_ = 0xc;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xc;
    if (0xf < uStack_44) {
      uVar9 = uStack_44 + 1;
      uVar10 = auStack_58[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_58[0] - 4);
        uVar9 = uStack_44 + 0x24;
        if (0x1f < (auStack_58[0] - uVar10) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    uStack_8._0_1_ = 0xb;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xb;
    if (0xf < uStack_194) {
      uVar9 = uStack_194 + 1;
      uVar10 = auStack_1a8[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_1a8[0] - 4);
        uVar9 = uStack_194 + 0x24;
        if (0x1f < (auStack_1a8[0] - uVar10) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_198 = 0;
    uStack_194 = 0xf;
    auStack_1a8[0] = auStack_1a8[0] & 0xffffff00;
    uStack_8._0_1_ = 10;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 10;
    if (0xf < uStack_d4) {
      uVar9 = uStack_d4 + 1;
      uVar10 = auStack_e8[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_e8[0] - 4);
        uVar9 = uStack_d4 + 0x24;
        if (0x1f < (auStack_e8[0] - uVar10) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_8._0_1_ = 9;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 9;
    if (0xf < uStack_5c) {
      uVar9 = uStack_5c + 1;
      uVar10 = auStack_70[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_70[0] - 4);
        uVar9 = uStack_5c + 0x24;
        if (0x1f < (auStack_70[0] - uVar10) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_60 = 0;
    uStack_5c = 0xf;
    auStack_70[0] = auStack_70[0] & 0xffffff00;
    uStack_8._0_1_ = 8;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < uStack_1ac) {
      uVar9 = uStack_1ac + 1;
      uVar10 = auStack_1c0[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_1c0[0] - 4);
        uVar9 = uStack_1ac + 0x24;
        if (0x1f < (auStack_1c0[0] - uVar10) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_1b0 = 0;
    uStack_1ac = 0xf;
    auStack_1c0[0] = auStack_1c0[0] & 0xffffff00;
    uStack_8._0_1_ = 7;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 7;
    if (0xf < uStack_ec) {
      uVar9 = uStack_ec + 1;
      uVar10 = auStack_100[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_100[0] - 4);
        uVar9 = uStack_ec + 0x24;
        if (0x1f < (auStack_100[0] - uVar10) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_8._0_1_ = 6;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 6;
    if (0xf < uStack_1c4) {
      uVar9 = uStack_1c4 + 1;
      uVar10 = auStack_1d8[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_1d8[0] - 4);
        uVar9 = uStack_1c4 + 0x24;
        if (0x1f < (auStack_1d8[0] - uVar10) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_1c8 = 0;
    uStack_1c4 = 0xf;
    auStack_1d8[0] = auStack_1d8[0] & 0xffffff00;
    uStack_8._0_1_ = 5;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 5;
    if (0xf < uStack_104) {
      uVar9 = uStack_104 + 1;
      uVar10 = auStack_118[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_118[0] - 4);
        uVar9 = uStack_104 + 0x24;
        if (0x1f < (auStack_118[0] - uVar10) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_8._0_1_ = 4;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 4;
    if (0xf < uStack_1dc) {
      uVar9 = uStack_1dc + 1;
      uVar10 = auStack_1f0[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_1f0[0] - 4);
        uVar9 = uStack_1dc + 0x24;
        if (0x1f < (auStack_1f0[0] - uVar10) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_1e0 = 0;
    uStack_1dc = 0xf;
    auStack_1f0[0] = auStack_1f0[0] & 0xffffff00;
    uStack_8._0_1_ = 3;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_11c) {
      uVar9 = uStack_11c + 1;
      uVar10 = auStack_130[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_130[0] - 4);
        uVar9 = uStack_11c + 0x24;
        if (0x1f < (auStack_130[0] - uVar10) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_8._0_1_ = 2;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      iVar8 = aiStack_28[0];
      if (0xfff < uVar10) {
        iVar8 = *(int *)(aiStack_28[0] + -4);
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar8) - 4U) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar8,uVar10);
    }
    FUN_0058c420(aiStack_28);
    uStack_8._0_1_ = 0x16;
    _guard_check_icall(param_1 + 0xc,aiStack_28);
    uStack_8._0_1_ = 2;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      iVar8 = aiStack_28[0];
      if (0xfff < uVar10) {
        iVar8 = *(int *)(aiStack_28[0] + -4);
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar8) - 4U) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar8,uVar10);
    }
    FUN_00990e60(auStack_148);
    uStack_8._0_1_ = 0x17;
    FUN_0058c420(aiStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
    FUN_00d82810(auStack_148,aiStack_28,&DAT_01d79f68,param_7,1,1);
    if (0xf < uStack_14) {
      uVar10 = uStack_14 + 1;
      iVar8 = aiStack_28[0];
      if (0xfff < uVar10) {
        iVar8 = *(int *)(aiStack_28[0] + -4);
        uVar10 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar8,uVar10);
    }
    if (0xf < uStack_134) {
      uVar9 = uStack_134 + 1;
      uVar10 = auStack_148[0];
      if (0xfff < uVar9) {
        uVar10 = *(uint *)(auStack_148[0] - 4);
        uVar9 = uStack_134 + 0x24;
        if (0x1f < (auStack_148[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar9);
    }
    uStack_138 = 0;
    uStack_134 = 0xf;
    auStack_148[0] = auStack_148[0] & 0xffffff00;
    FUN_005705c0();
    FUN_005705c0();
    FUN_005705c0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17990 ; VA 0x00993530 ; FUN_00993530 */

void __thiscall
FUN_00993530(int param_1,char *param_2,char *param_3,char *param_4,undefined4 param_5,int param_6,
            int param_7,undefined4 param_8,undefined4 param_9,int param_10,undefined4 param_11,
            undefined4 param_12,undefined4 param_13)

{
  char cVar1;
  undefined uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int *piVar6;
  char *pcVar7;
  uint uVar8;
  uint uVar9;
  undefined4 *puVar10;
  undefined auStack_24c [160];
  uint auStack_1ac [4];
  undefined4 uStack_19c;
  uint uStack_198;
  uint auStack_194 [4];
  undefined4 uStack_184;
  uint uStack_180;
  uint auStack_17c [4];
  undefined4 uStack_16c;
  uint uStack_168;
  uint auStack_164 [4];
  undefined4 uStack_154;
  uint uStack_150;
  uint auStack_14c [4];
  undefined4 uStack_13c;
  uint uStack_138;
  uint auStack_134 [4];
  undefined4 uStack_124;
  uint uStack_120;
  uint auStack_11c [4];
  undefined4 uStack_10c;
  uint uStack_108;
  uint auStack_104 [4];
  undefined4 uStack_f4;
  uint uStack_f0;
  uint auStack_ec [4];
  undefined4 uStack_dc;
  uint uStack_d8;
  uint auStack_d4 [4];
  undefined4 uStack_c4;
  uint uStack_c0;
  uint auStack_bc [4];
  undefined4 uStack_ac;
  uint uStack_a8;
  uint auStack_a4 [4];
  undefined4 uStack_94;
  uint uStack_90;
  uint auStack_8c [4];
  undefined4 uStack_7c;
  uint uStack_78;
  uint auStack_74 [4];
  undefined4 uStack_64;
  uint uStack_60;
  uint auStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  int iStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d16f5;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_2c = param_1;
  if (*(int *)(param_1 + 0x1c) != 0) {
    ExceptionList = &pvStack_10;
    FUN_00565940(3,1);
    uStack_8._0_1_ = 1;
    FUN_00565940(3,1);
    uStack_8._0_1_ = 2;
    FUN_00872bd0(param_11,param_12);
    piVar6 = (int *)(param_1 + 0x3c);
    if (0xf < *(uint *)(param_1 + 0x50)) {
      piVar6 = (int *)*piVar6;
    }
    uVar3 = FUN_0055b3b0(auStack_24c,piVar6,*(undefined4 *)(param_1 + 0x4c));
    piVar6 = (int *)(param_1 + 0x54);
    if (0xf < *(uint *)(param_1 + 0x68)) {
      piVar6 = (int *)*piVar6;
    }
    uVar3 = FUN_0055b3b0(uVar3,piVar6,*(undefined4 *)(param_1 + 100));
    piVar6 = (int *)(param_1 + 0x24);
    uVar3 = FUN_00558890(uVar3,&DAT_0191bfa0);
    if (0xf < *(uint *)(param_1 + 0x38)) {
      piVar6 = (int *)*piVar6;
    }
    uVar3 = FUN_0055b3b0(uVar3,piVar6,*(undefined4 *)(param_1 + 0x34));
    piVar6 = (int *)(param_1 + 0x6c);
    if (0xf < *(uint *)(param_1 + 0x80)) {
      piVar6 = (int *)*piVar6;
    }
    uVar3 = FUN_0055b3b0(uVar3,piVar6,*(undefined4 *)(param_1 + 0x7c));
    uVar3 = FUN_00558890(uVar3,&DAT_0191bfa0);
    uStack_10c = 0;
    uStack_108 = 0xf;
    auStack_11c[0] = auStack_11c[0] & 0xffffff00;
    FUN_005542c0("userID",6);
    uStack_8._0_1_ = 3;
    puVar4 = (undefined4 *)FUN_00990aa0(auStack_28,auStack_11c,&DAT_01d7a8d0);
    puVar10 = puVar4 + 4;
    uStack_8._0_1_ = 4;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    uVar3 = FUN_0055b3b0(uVar3,puVar4,*puVar10);
    uVar3 = FUN_00558890(uVar3,&DAT_0191bfa0);
    uStack_f4 = 0;
    uStack_f0 = 0xf;
    auStack_104[0] = auStack_104[0] & 0xffffff00;
    FUN_005542c0("placeID",7);
    uStack_8._0_1_ = 5;
    puVar4 = (undefined4 *)FUN_00990aa0(auStack_1ac,auStack_104,&DAT_01d7a8e8);
    puVar10 = puVar4 + 4;
    uStack_8._0_1_ = 6;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    uVar3 = FUN_0055b3b0(uVar3,puVar4,*puVar10);
    uVar3 = FUN_00558890(uVar3,&DAT_0191bfa0);
    uStack_64 = 0;
    uStack_60 = 0xf;
    auStack_74[0] = auStack_74[0] & 0xffffff00;
    pcVar7 = param_2;
    do {
      cVar1 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(param_2,(int)pcVar7 - (int)(param_2 + 1));
    uStack_8._0_1_ = 7;
    uStack_dc = 0;
    uStack_d8 = 0xf;
    auStack_ec[0] = auStack_ec[0] & 0xffffff00;
    FUN_005542c0("category",8);
    uStack_8._0_1_ = 8;
    puVar4 = (undefined4 *)FUN_00990aa0(auStack_194,auStack_ec,auStack_74);
    puVar10 = puVar4 + 4;
    uStack_8._0_1_ = 9;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    uVar3 = FUN_0055b3b0(uVar3,puVar4,*puVar10);
    uVar3 = FUN_00558890(uVar3,&DAT_0191bfa0);
    uStack_4c = 0;
    uStack_48 = 0xf;
    auStack_5c[0] = auStack_5c[0] & 0xffffff00;
    pcVar7 = param_3;
    do {
      cVar1 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(param_3,(int)pcVar7 - (int)(param_3 + 1));
    uStack_8._0_1_ = 10;
    uStack_c4 = 0;
    uStack_c0 = 0xf;
    auStack_d4[0] = auStack_d4[0] & 0xffffff00;
    FUN_005542c0(&DAT_018cc3ac,3);
    uStack_8._0_1_ = 0xb;
    puVar4 = (undefined4 *)FUN_00990aa0(auStack_17c,auStack_d4,auStack_5c);
    puVar10 = puVar4 + 4;
    uStack_8._0_1_ = 0xc;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    uVar3 = FUN_0055b3b0(uVar3,puVar4,*puVar10);
    uVar3 = FUN_00558890(uVar3,&DAT_0191bfa0);
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    pcVar7 = param_4;
    do {
      cVar1 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(param_4,(int)pcVar7 - (int)(param_4 + 1));
    uStack_8._0_1_ = 0xd;
    uStack_ac = 0;
    uStack_a8 = 0xf;
    auStack_bc[0] = auStack_bc[0] & 0xffffff00;
    FUN_005542c0("label",5);
    uStack_8._0_1_ = 0xe;
    puVar4 = (undefined4 *)FUN_00990aa0(auStack_164,auStack_bc,auStack_44);
    puVar10 = puVar4 + 4;
    uStack_8._0_1_ = 0xf;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    uVar3 = FUN_0055b3b0(uVar3,puVar4,*puVar10);
    uVar3 = FUN_00558890(uVar3,&DAT_0191bfa0);
    FUN_0058c420(auStack_a4);
    uStack_8._0_1_ = 0x10;
    uStack_7c = 0;
    uStack_78 = 0xf;
    auStack_8c[0] = auStack_8c[0] & 0xffffff00;
    FUN_005542c0("value",5);
    uStack_8._0_1_ = 0x11;
    puVar4 = (undefined4 *)FUN_00990aa0(auStack_14c,auStack_8c,auStack_a4);
    puVar10 = puVar4 + 4;
    uStack_8._0_1_ = 0x12;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    FUN_0055b3b0(uVar3,puVar4,*puVar10);
    uStack_8._0_1_ = 0x11;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x11;
    if (0xf < uStack_138) {
      uVar9 = uStack_138 + 1;
      uVar8 = auStack_14c[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_14c[0] - 4);
        uVar9 = uStack_138 + 0x24;
        if (0x1f < (auStack_14c[0] - uVar8) - 4) {
LAB_00994031:
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_13c = 0;
    uStack_138 = 0xf;
    auStack_14c[0] = auStack_14c[0] & 0xffffff00;
    uStack_8._0_1_ = 0x10;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x10;
    if (0xf < uStack_78) {
      uVar9 = uStack_78 + 1;
      uVar8 = auStack_8c[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_8c[0] - 4);
        uVar9 = uStack_78 + 0x24;
        if (0x1f < (auStack_8c[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_8._0_1_ = 0xf;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xf;
    if (0xf < uStack_90) {
      uVar9 = uStack_90 + 1;
      uVar8 = auStack_a4[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_a4[0] - 4);
        uVar9 = uStack_90 + 0x24;
        if (0x1f < (auStack_a4[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_94 = 0;
    uStack_90 = 0xf;
    auStack_a4[0] = auStack_a4[0] & 0xffffff00;
    uStack_8._0_1_ = 0xe;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xe;
    if (0xf < uStack_150) {
      uVar9 = uStack_150 + 1;
      uVar8 = auStack_164[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_164[0] - 4);
        uVar9 = uStack_150 + 0x24;
        if (0x1f < (auStack_164[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_154 = 0;
    uStack_150 = 0xf;
    auStack_164[0] = auStack_164[0] & 0xffffff00;
    uStack_8._0_1_ = 0xd;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xd;
    if (0xf < uStack_a8) {
      uVar9 = uStack_a8 + 1;
      uVar8 = auStack_bc[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_bc[0] - 4);
        uVar9 = uStack_a8 + 0x24;
        if (0x1f < (auStack_bc[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_8._0_1_ = 0xc;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xc;
    if (0xf < uStack_30) {
      uVar9 = uStack_30 + 1;
      uVar8 = auStack_44[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_44[0] - 4);
        uVar9 = uStack_30 + 0x24;
        if (0x1f < (auStack_44[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    uStack_8._0_1_ = 0xb;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xb;
    if (0xf < uStack_168) {
      uVar9 = uStack_168 + 1;
      uVar8 = auStack_17c[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_17c[0] - 4);
        uVar9 = uStack_168 + 0x24;
        if (0x1f < (auStack_17c[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_16c = 0;
    uStack_168 = 0xf;
    auStack_17c[0] = auStack_17c[0] & 0xffffff00;
    uStack_8._0_1_ = 10;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 10;
    if (0xf < uStack_c0) {
      uVar9 = uStack_c0 + 1;
      uVar8 = auStack_d4[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_d4[0] - 4);
        uVar9 = uStack_c0 + 0x24;
        if (0x1f < (auStack_d4[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_8._0_1_ = 9;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 9;
    if (0xf < uStack_48) {
      uVar9 = uStack_48 + 1;
      uVar8 = auStack_5c[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_5c[0] - 4);
        uVar9 = uStack_48 + 0x24;
        if (0x1f < (auStack_5c[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_4c = 0;
    uStack_48 = 0xf;
    auStack_5c[0] = auStack_5c[0] & 0xffffff00;
    uStack_8._0_1_ = 8;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < uStack_180) {
      uVar9 = uStack_180 + 1;
      uVar8 = auStack_194[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_194[0] - 4);
        uVar9 = uStack_180 + 0x24;
        if (0x1f < (auStack_194[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_184 = 0;
    uStack_180 = 0xf;
    auStack_194[0] = auStack_194[0] & 0xffffff00;
    uStack_8._0_1_ = 7;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 7;
    if (0xf < uStack_d8) {
      uVar9 = uStack_d8 + 1;
      uVar8 = auStack_ec[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_ec[0] - 4);
        uVar9 = uStack_d8 + 0x24;
        if (0x1f < (auStack_ec[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_8._0_1_ = 6;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 6;
    if (0xf < uStack_60) {
      uVar9 = uStack_60 + 1;
      uVar8 = auStack_74[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_74[0] - 4);
        uVar9 = uStack_60 + 0x24;
        if (0x1f < (auStack_74[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_64 = 0;
    uStack_60 = 0xf;
    auStack_74[0] = auStack_74[0] & 0xffffff00;
    uStack_8._0_1_ = 5;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 5;
    if (0xf < uStack_198) {
      uVar9 = uStack_198 + 1;
      uVar8 = auStack_1ac[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_1ac[0] - 4);
        uVar9 = uStack_198 + 0x24;
        if (0x1f < (auStack_1ac[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_19c = 0;
    uStack_198 = 0xf;
    auStack_1ac[0] = auStack_1ac[0] & 0xffffff00;
    uStack_8._0_1_ = 4;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 4;
    if (0xf < uStack_f0) {
      uVar9 = uStack_f0 + 1;
      uVar8 = auStack_104[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_104[0] - 4);
        uVar9 = uStack_f0 + 0x24;
        if (0x1f < (auStack_104[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_8._0_1_ = 3;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_14) {
      uVar9 = uStack_14 + 1;
      uVar8 = auStack_28[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_28[0] - 4);
        uVar9 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    uStack_8._0_1_ = 2;
    if (0xf < uStack_108) {
      uVar9 = uStack_108 + 1;
      uVar8 = auStack_11c[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_11c[0] - 4);
        uVar9 = uStack_108 + 0x24;
        if (0x1f < (auStack_11c[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    if (param_7 == 0) {
      puVar10 = (undefined4 *)0x0;
    }
    else {
      puVar10 = *(undefined4 **)(param_10 + param_6 * 4);
    }
    for (; puVar10 != (undefined4 *)0x0; puVar10 = (undefined4 *)*puVar10) {
      uVar3 = FUN_00558890(auStack_24c,&DAT_0191bfa0);
      puVar5 = (undefined4 *)FUN_00990aa0(auStack_28,puVar10 + 2,puVar10 + 8);
      puVar4 = puVar5 + 4;
      uStack_8._0_1_ = 0x13;
      if (0xf < (uint)puVar5[5]) {
        puVar5 = (undefined4 *)*puVar5;
      }
      FUN_0055b3b0(uVar3,puVar5,*puVar4);
      uStack_8._0_1_ = 2;
      if (0xf < uStack_14) {
        uVar9 = uStack_14 + 1;
        uVar8 = auStack_28[0];
        if (0xfff < uVar9) {
          uVar8 = *(uint *)(auStack_28[0] - 4);
          uVar9 = uStack_14 + 0x24;
          uVar2 = (undefined)uStack_8;
          if (0x1f < (auStack_28[0] - uVar8) - 4) goto LAB_00994031;
        }
        FUN_01674ea0(uVar8,uVar9);
      }
      param_1 = iStack_2c;
    }
    piVar6 = (int *)(param_1 + 0xb4);
    if (0xf < *(uint *)(param_1 + 200)) {
      piVar6 = (int *)*piVar6;
    }
    FUN_0055b3b0(auStack_24c,piVar6,*(undefined4 *)(param_1 + 0xc4));
    FUN_0058c420(auStack_28);
    uStack_8._0_1_ = 0x14;
    _guard_check_icall(param_1 + 0xc,auStack_28);
    uStack_8._0_1_ = 2;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (0xf < uStack_14) {
      uVar9 = uStack_14 + 1;
      uVar8 = auStack_28[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_28[0] - 4);
        uVar9 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    FUN_00990e60(auStack_134);
    uStack_8._0_1_ = 0x15;
    FUN_0058c420(auStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
    FUN_00d82810(auStack_134,auStack_28,&DAT_01d79f68,param_13,1,1);
    if (0xf < uStack_14) {
      uVar9 = uStack_14 + 1;
      uVar8 = auStack_28[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_28[0] - 4);
        uVar9 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    if (0xf < uStack_120) {
      uVar9 = uStack_120 + 1;
      uVar8 = auStack_134[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_134[0] - 4);
        uVar9 = uStack_120 + 0x24;
        if (0x1f < (auStack_134[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_124 = 0;
    uStack_120 = 0xf;
    auStack_134[0] = auStack_134[0] & 0xffffff00;
    FUN_005705c0();
    FUN_005705c0();
  }
  FUN_0056cfd0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17991 ; VA 0x009940a0 ; FUN_009940a0 */

void __thiscall FUN_009940a0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined *in_stack_00000028;
  undefined *in_stack_0000002c;
  undefined *in_stack_00000030;
  undefined auStack_3c [20];
  undefined *puStack_28;
  undefined *puStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d1708;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (*(char *)(param_1 + 1) != '\0') {
    puStack_1c = (undefined *)0x0;
    puStack_20 = in_stack_00000030;
    puStack_24 = in_stack_0000002c;
    puStack_28 = in_stack_00000028;
    ExceptionList = &pvStack_10;
    FUN_0060e660(&stack0x00000010);
    FUN_00991fc0(param_2,param_3,param_4);
  }
  if (*(char *)(param_1 + 2) != '\0') {
    puStack_20 = in_stack_0000002c;
    puStack_24 = in_stack_00000028;
    puStack_1c = in_stack_00000030;
    in_stack_00000030 = auStack_3c;
    FUN_0060e660();
    FUN_00993530(param_2,param_3);
  }
  puStack_1c = (undefined *)0x99412f;
  FUN_0056cfd0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17992 ; VA 0x00994140 ; FUN_00994140 */

void FUN_00994140(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined *in_stack_00000028;
  undefined *in_stack_0000002c;
  undefined *in_stack_00000030;
  byte in_stack_00000034;
  undefined auStack_3c [20];
  undefined *puStack_28;
  undefined *puStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d1708;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if ((in_stack_00000034 & 1) != 0) {
    puStack_1c = (undefined *)0x0;
    puStack_20 = in_stack_00000030;
    puStack_24 = in_stack_0000002c;
    puStack_28 = in_stack_00000028;
    ExceptionList = &pvStack_10;
    FUN_0060e660(&stack0x00000010);
    FUN_00991fc0(param_1,param_2,param_3);
  }
  if ((in_stack_00000034 & 2) != 0) {
    puStack_20 = in_stack_0000002c;
    puStack_1c = in_stack_00000030;
    in_stack_00000030 = auStack_3c;
    puStack_24 = in_stack_00000028;
    FUN_0060e660();
    FUN_00993530(param_1,param_2);
  }
  puStack_1c = (undefined *)0x9941d1;
  FUN_0056cfd0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17993 ; VA 0x009941f0 ; FUN_009941f0 */

void FUN_009941f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,byte param_7,undefined4 param_8)

{
  if ((param_7 & 1) != 0) {
    FUN_00991760(param_1,param_2,param_3,param_4,param_5,param_6,param_8);
  }
  if ((param_7 & 2) != 0) {
    FUN_009928b0(param_1,param_2,param_3,param_4,param_5,param_6);
  }
  return;
}



/* FUNCTION 17994 ; VA 0x00994250 ; FUN_00994250 */

void __thiscall
FUN_00994250(char *param_1,char *param_2,char *param_3,int param_4,char *param_5,undefined4 param_6)

{
  undefined4 *puVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined *puVar6;
  char *pcVar7;
  uint uVar8;
  uint uVar9;
  undefined auStack_204 [160];
  uint auStack_164 [4];
  undefined4 uStack_154;
  uint uStack_150;
  uint auStack_14c [4];
  undefined4 uStack_13c;
  uint uStack_138;
  uint auStack_134 [4];
  undefined4 uStack_124;
  uint uStack_120;
  uint auStack_11c [4];
  undefined4 uStack_10c;
  uint uStack_108;
  uint auStack_104 [4];
  undefined4 uStack_f4;
  uint uStack_f0;
  uint auStack_ec [4];
  undefined4 uStack_dc;
  uint uStack_d8;
  uint auStack_d4 [4];
  undefined4 uStack_c4;
  uint uStack_c0;
  uint auStack_bc [4];
  undefined4 uStack_ac;
  uint uStack_a8;
  uint auStack_a4 [4];
  undefined4 uStack_94;
  uint uStack_90;
  uint auStack_8c [4];
  undefined4 uStack_7c;
  uint uStack_78;
  uint auStack_74 [4];
  undefined4 uStack_64;
  uint uStack_60;
  uint auStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  char *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d17d4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pcStack_14 = param_1;
  if (param_1[2] != '\0') {
    ExceptionList = &pvStack_10;
    FUN_009928b0(param_2,param_3,param_5,param_4,param_4 >> 0x1f,param_6);
  }
  if (pcStack_14[1] != '\0') {
    FUN_00565940(3,1);
    uStack_8 = 0;
    FUN_00565940(3,1);
    uStack_8._0_1_ = 1;
    FUN_005af260(param_4);
    uStack_f4 = 0;
    uStack_f0 = 0xf;
    auStack_104[0] = auStack_104[0] & 0xffffff00;
    FUN_005542c0("timing",6);
    uStack_8._0_1_ = 2;
    puVar4 = (undefined4 *)FUN_00991290(auStack_2c,auStack_104,0);
    puVar1 = puVar4 + 4;
    uStack_8._0_1_ = 3;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    uVar5 = FUN_0055b3b0(auStack_204,puVar4,*puVar1);
    uVar5 = FUN_00558890(uVar5,&DAT_0191bfa0);
    uStack_64 = 0;
    uStack_60 = 0xf;
    auStack_74[0] = auStack_74[0] & 0xffffff00;
    pcVar7 = param_2;
    do {
      cVar2 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar2 != '\0');
    FUN_005542c0(param_2,(int)pcVar7 - (int)(param_2 + 1));
    uStack_8._0_1_ = 4;
    uStack_dc = 0;
    uStack_d8 = 0xf;
    auStack_ec[0] = auStack_ec[0] & 0xffffff00;
    FUN_005542c0(&DAT_01937018,3);
    uStack_8._0_1_ = 5;
    puVar4 = (undefined4 *)FUN_00990aa0(auStack_164,auStack_ec,auStack_74);
    puVar1 = puVar4 + 4;
    uStack_8._0_1_ = 6;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    uVar5 = FUN_0055b3b0(uVar5,puVar4,*puVar1);
    uVar5 = FUN_00558890(uVar5,&DAT_0191bfa0);
    uStack_4c = 0;
    uStack_48 = 0xf;
    auStack_5c[0] = auStack_5c[0] & 0xffffff00;
    pcVar7 = param_3;
    do {
      cVar2 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar2 != '\0');
    FUN_005542c0(param_3,(int)pcVar7 - (int)(param_3 + 1));
    uStack_8._0_1_ = 7;
    uStack_c4 = 0;
    uStack_c0 = 0xf;
    auStack_d4[0] = auStack_d4[0] & 0xffffff00;
    FUN_005542c0(&DAT_01937014,3);
    uStack_8._0_1_ = 8;
    puVar4 = (undefined4 *)FUN_00990aa0(auStack_14c,auStack_d4,auStack_5c);
    puVar1 = puVar4 + 4;
    uStack_8._0_1_ = 9;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    uVar5 = FUN_0055b3b0(uVar5,puVar4,*puVar1);
    uVar5 = FUN_00558890(uVar5,&DAT_0191bfa0);
    FUN_0058c420(auStack_bc);
    uStack_8._0_1_ = 10;
    uStack_94 = 0;
    uStack_90 = 0xf;
    auStack_a4[0] = auStack_a4[0] & 0xffffff00;
    FUN_005542c0(&DAT_01937010,3);
    uStack_8._0_1_ = 0xb;
    puVar4 = (undefined4 *)FUN_00990aa0(auStack_134,auStack_a4,auStack_bc);
    puVar1 = puVar4 + 4;
    uStack_8._0_1_ = 0xc;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    uVar5 = FUN_0055b3b0(uVar5,puVar4,*puVar1);
    uVar5 = FUN_00558890(uVar5,&DAT_0191bfa0);
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    pcVar7 = param_5;
    do {
      cVar2 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar2 != '\0');
    FUN_005542c0(param_5,(int)pcVar7 - (int)(param_5 + 1));
    uStack_8._0_1_ = 0xd;
    uStack_7c = 0;
    uStack_78 = 0xf;
    auStack_8c[0] = auStack_8c[0] & 0xffffff00;
    FUN_005542c0(&DAT_0193700c,3);
    uStack_8._0_1_ = 0xe;
    puVar4 = (undefined4 *)FUN_00990aa0(auStack_11c,auStack_8c,auStack_44);
    puVar1 = puVar4 + 4;
    uStack_8._0_1_ = 0xf;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    FUN_0055b3b0(uVar5,puVar4,*puVar1);
    uStack_8._0_1_ = 0xe;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xe;
    if (0xf < uStack_108) {
      uVar9 = uStack_108 + 1;
      uVar8 = auStack_11c[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_11c[0] - 4);
        uVar9 = uStack_108 + 0x24;
        if (0x1f < (auStack_11c[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_10c = 0;
    uStack_108 = 0xf;
    auStack_11c[0] = auStack_11c[0] & 0xffffff00;
    uStack_8._0_1_ = 0xd;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xd;
    if (0xf < uStack_78) {
      uVar9 = uStack_78 + 1;
      uVar8 = auStack_8c[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_8c[0] - 4);
        uVar9 = uStack_78 + 0x24;
        if (0x1f < (auStack_8c[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_8._0_1_ = 0xc;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xc;
    if (0xf < uStack_30) {
      uVar9 = uStack_30 + 1;
      uVar8 = auStack_44[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_44[0] - 4);
        uVar9 = uStack_30 + 0x24;
        if (0x1f < (auStack_44[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    uStack_8._0_1_ = 0xb;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 0xb;
    if (0xf < uStack_120) {
      uVar9 = uStack_120 + 1;
      uVar8 = auStack_134[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_134[0] - 4);
        uVar9 = uStack_120 + 0x24;
        if (0x1f < (auStack_134[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_124 = 0;
    uStack_120 = 0xf;
    auStack_134[0] = auStack_134[0] & 0xffffff00;
    uStack_8._0_1_ = 10;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 10;
    if (0xf < uStack_90) {
      uVar9 = uStack_90 + 1;
      uVar8 = auStack_a4[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_a4[0] - 4);
        uVar9 = uStack_90 + 0x24;
        if (0x1f < (auStack_a4[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_8._0_1_ = 9;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 9;
    if (0xf < uStack_a8) {
      uVar9 = uStack_a8 + 1;
      uVar8 = auStack_bc[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_bc[0] - 4);
        uVar9 = uStack_a8 + 0x24;
        if (0x1f < (auStack_bc[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_ac = 0;
    uStack_a8 = 0xf;
    auStack_bc[0] = auStack_bc[0] & 0xffffff00;
    uStack_8._0_1_ = 8;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < uStack_138) {
      uVar9 = uStack_138 + 1;
      uVar8 = auStack_14c[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_14c[0] - 4);
        uVar9 = uStack_138 + 0x24;
        if (0x1f < (auStack_14c[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_13c = 0;
    uStack_138 = 0xf;
    auStack_14c[0] = auStack_14c[0] & 0xffffff00;
    uStack_8._0_1_ = 7;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 7;
    if (0xf < uStack_c0) {
      uVar9 = uStack_c0 + 1;
      uVar8 = auStack_d4[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_d4[0] - 4);
        uVar9 = uStack_c0 + 0x24;
        if (0x1f < (auStack_d4[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_8._0_1_ = 6;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 6;
    if (0xf < uStack_48) {
      uVar9 = uStack_48 + 1;
      uVar8 = auStack_5c[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_5c[0] - 4);
        uVar9 = uStack_48 + 0x24;
        if (0x1f < (auStack_5c[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_4c = 0;
    uStack_48 = 0xf;
    auStack_5c[0] = auStack_5c[0] & 0xffffff00;
    uStack_8._0_1_ = 5;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 5;
    if (0xf < uStack_150) {
      uVar9 = uStack_150 + 1;
      uVar8 = auStack_164[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_164[0] - 4);
        uVar9 = uStack_150 + 0x24;
        if (0x1f < (auStack_164[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_154 = 0;
    uStack_150 = 0xf;
    auStack_164[0] = auStack_164[0] & 0xffffff00;
    uStack_8._0_1_ = 4;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 4;
    if (0xf < uStack_d8) {
      uVar9 = uStack_d8 + 1;
      uVar8 = auStack_ec[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_ec[0] - 4);
        uVar9 = uStack_d8 + 0x24;
        if (0x1f < (auStack_ec[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_8._0_1_ = 3;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_60) {
      uVar9 = uStack_60 + 1;
      uVar8 = auStack_74[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_74[0] - 4);
        uVar9 = uStack_60 + 0x24;
        if (0x1f < (auStack_74[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_64 = 0;
    uStack_60 = 0xf;
    auStack_74[0] = auStack_74[0] & 0xffffff00;
    uStack_8._0_1_ = 2;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (0xf < uStack_18) {
      uVar9 = uStack_18 + 1;
      uVar8 = auStack_2c[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_2c[0] - 4);
        uVar9 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    uStack_8._0_1_ = 1;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < uStack_f0) {
      uVar9 = uStack_f0 + 1;
      uVar8 = auStack_104[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_104[0] - 4);
        uVar9 = uStack_f0 + 0x24;
        if (0x1f < (auStack_104[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    if (DAT_01d64850 == '\0') {
      FUN_0058c420(auStack_2c);
      puVar6 = &DAT_01d64878;
      uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
      if (*pcStack_14 == '\0') {
        puVar6 = &DAT_01d64860;
      }
      FUN_00d82810(puVar6,auStack_2c,&DAT_01d79f68,param_6,0,1);
    }
    else {
      FUN_0058c420(auStack_2c);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
      FUN_00991430(*pcStack_14,auStack_2c,param_6);
    }
    FUN_005507b0();
    FUN_005705c0();
    FUN_005705c0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17995 ; VA 0x00994ab0 ; FUN_00994ab0 */

void __fastcall FUN_00994ab0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (*(int *)(param_1 + 0x80) != 0) {
    if (*(int *)(param_1 + 0x74) != 0) {
      puVar1 = (undefined4 *)(*(int *)(param_1 + 0x80) + *(int *)(param_1 + 0x70) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        uVar6 = puVar7[7];
        if (0xf < uVar6) {
          iVar2 = puVar7[2];
          uVar5 = uVar6 + 1;
          iVar4 = iVar2;
          if (0xfff < uVar5) {
            iVar4 = *(int *)(iVar2 + -4);
            uVar5 = uVar6 + 0x24;
            if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_00994d94;
          }
          FUN_01674ea0(iVar4,uVar5);
        }
        puVar7[6] = 0;
        puVar7[7] = 0xf;
        *(undefined *)(puVar7 + 2) = 0;
        FUN_01674ea0(puVar7,0x24);
        *(int *)(param_1 + 0x74) = *(int *)(param_1 + 0x74) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 0x70) * 4;
    uVar6 = iVar2 + 4;
    iVar4 = *(int *)(param_1 + 0x80);
    iVar3 = iVar4;
    if (0xfff < uVar6) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) goto LAB_00994d94;
    }
    FUN_01674ea0(iVar3,uVar6);
    *(undefined4 *)(param_1 + 0x80) = 0;
    *(undefined4 *)(param_1 + 0x7c) = 0;
  }
  iVar2 = *(int *)(param_1 + 0x60);
  if (iVar2 != 0) {
    uVar6 = *(int *)(param_1 + 0x68) - iVar2 & 0xfffffff8;
    iVar4 = iVar2;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_00994d94;
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x60) = 0;
    *(undefined4 *)(param_1 + 100) = 0;
    *(undefined4 *)(param_1 + 0x68) = 0;
  }
  iVar2 = *(int *)(param_1 + 0x54);
  if (iVar2 != 0) {
    uVar6 = *(int *)(param_1 + 0x5c) - iVar2 & 0xfffffff8;
    iVar4 = iVar2;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_00994d94;
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x54) = 0;
    *(undefined4 *)(param_1 + 0x58) = 0;
    *(undefined4 *)(param_1 + 0x5c) = 0;
  }
  iVar2 = *(int *)(param_1 + 0x48);
  if (iVar2 != 0) {
    uVar6 = *(int *)(param_1 + 0x50) - iVar2 & 0xfffffff8;
    iVar4 = iVar2;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_00994d94;
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x48) = 0;
    *(undefined4 *)(param_1 + 0x4c) = 0;
    *(undefined4 *)(param_1 + 0x50) = 0;
  }
  iVar2 = *(int *)(param_1 + 0x3c);
  if (iVar2 != 0) {
    uVar6 = *(int *)(param_1 + 0x44) - iVar2 & 0xfffffff8;
    iVar4 = iVar2;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_00994d94;
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x3c) = 0;
    *(undefined4 *)(param_1 + 0x40) = 0;
    *(undefined4 *)(param_1 + 0x44) = 0;
  }
  iVar2 = *(int *)(param_1 + 0x30);
  if (iVar2 != 0) {
    uVar6 = *(int *)(param_1 + 0x38) - iVar2 & 0xfffffff8;
    iVar4 = iVar2;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_00994d94;
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x30) = 0;
    *(undefined4 *)(param_1 + 0x34) = 0;
    *(undefined4 *)(param_1 + 0x38) = 0;
  }
  iVar2 = *(int *)(param_1 + 0x24);
  if (iVar2 != 0) {
    uVar6 = *(int *)(param_1 + 0x2c) - iVar2 & 0xfffffff8;
    iVar4 = iVar2;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_00994d94;
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x24) = 0;
    *(undefined4 *)(param_1 + 0x28) = 0;
    *(undefined4 *)(param_1 + 0x2c) = 0;
  }
  uVar6 = *(uint *)(param_1 + 0x1c);
  if (0xf < uVar6) {
    iVar2 = *(int *)(param_1 + 8);
    uVar5 = uVar6 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) {
LAB_00994d94:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0xf;
  *(undefined *)(param_1 + 8) = 0;
  LOCK();
  iVar2 = *(int *)(param_1 + 4);
  *(int *)(param_1 + 4) = 0;
  UNLOCK();
  if (iVar2 != 0) {
    CloseHandle(iVar2);
  }
  return;
}



/* FUNCTION 17996 ; VA 0x00994da0 ; FUN_00994da0 */

/* WARNING: Removing unreachable block (ram,0x00994dd5) */

void FUN_00994da0(undefined4 *param_1)

{
  char cVar1;
  char cVar2;
  ulonglong uVar3;
  
  cVar2 = DAT_01d648fc;
  cVar1 = DAT_01d648e4;
  uVar3 = FUN_016f4270(*param_1,param_1[1],1000000,0);
  if (((cVar1 == '\0') || ((ulonglong)(longlong)DAT_01ee344c <= uVar3)) ||
     (DAT_01ee3450 = 1, cVar2 == '\0')) {
    DAT_01ee3450 = 0;
  }
  return;
}



/* FUNCTION 17997 ; VA 0x00994e00 ; FUN_00994e00 */

void FUN_00994e00(void)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined auStack_18 [4];
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017969e8;
  pvStack_10 = ExceptionList;
  if (DAT_01ee3450 != '\0') {
    ExceptionList = &pvStack_10;
    cVar2 = FUN_0168a370();
    if (cVar2 != '\0') {
      piVar3 = (int *)FUN_01689dd0(auStack_14);
      piVar4 = (int *)FUN_01689df0(auStack_18);
      if (*piVar3 == *piVar4) {
        uVar5 = FUN_0056b4a0(0x24,"boost thread: trying joining itself");
        uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
        FUN_0054e630(uVar5);
      }
      FUN_0168a200();
    }
    piVar3 = &DAT_01ee3424;
    do {
      iVar1 = *piVar3;
      if (iVar1 != 0) {
        FUN_00dabd40();
        FUN_00994ab0();
        FUN_01674ea0(iVar1,0x84);
        if (DAT_01d64914 != '\0') {
          *piVar3 = 0;
        }
      }
      piVar3 = piVar3 + 1;
    } while ((int)piVar3 < 0x1ee344c);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 17998 ; VA 0x00994ed0 ; FUN_00994ed0 */

void FUN_00994ed0(undefined4 param_1)

{
  FUN_00994f00(2,param_1);
  if (DAT_01d6490c != '\0') {
    FUN_00dab530(&DAT_01d6491c);
  }
  return;
}



/* FUNCTION 17999 ; VA 0x00994f00 ; FUN_00994f00 */

void FUN_00994f00(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d1812;
  pvStack_10 = ExceptionList;
  if (DAT_01ee3450 != '\0') {
    ExceptionList = &pvStack_10;
    if ((&DAT_01ee3424)[param_1] != 0) {
      ExceptionList = &pvStack_10;
      FUN_00dabd40();
      iVar1 = (&DAT_01ee3424)[param_1];
      if (iVar1 != 0) {
        FUN_00994ab0();
        FUN_01674ea0(iVar1,0x84);
      }
    }
    iVar1 = FUN_01674e20(0x84);
    uStack_8 = 0;
    if (iVar1 == 0) {
      uVar2 = 0;
    }
    else {
      FUN_0054ef60(param_2);
      uVar2 = FUN_00daaed0();
    }
    (&DAT_01ee3424)[param_1] = uVar2;
  }
  ExceptionList = pvStack_10;
  return;
}


