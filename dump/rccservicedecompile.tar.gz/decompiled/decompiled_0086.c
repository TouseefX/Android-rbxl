/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 21500 ; VA 0x00a800e0 ; FUN_00a800e0 */

void FUN_00a800e0(int param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 ****ppppuVar3;
  uint uVar4;
  int *piVar5;
  undefined4 *puVar6;
  uint in_stack_0000001c;
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 ***apppuStack_28 [4];
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017e4360;
  pvStack_10 = ExceptionList;
  iStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  uStack_8 = 1;
  uStack_7 = 0;
  piVar5 = (int *)(param_1 + 0x24);
  ExceptionList = &pvStack_10;
  FUN_00a802b0(piVar5,apppuStack_28);
  puVar6 = (undefined4 *)(param_1 + 0x3c);
  FUN_00a802b0(puVar6,apppuStack_28);
  if ((iStack_18 != 0) && (0 < DAT_01eea9b0)) {
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = 2;
    FUN_00fa1220(&param_2,DAT_01d663b8);
    puVar2 = &param_2;
    if (0xf < in_stack_0000001c) {
      puVar2 = param_2;
    }
    FUN_0151f850("Original",puVar2);
    ppppuVar3 = apppuStack_28;
    if (0xf < uStack_14) {
      ppppuVar3 = (undefined4 ****)apppuStack_28[0];
    }
    FUN_0151f850("Match",ppppuVar3);
    if (0xf < *(uint *)(param_1 + 0x38)) {
      piVar5 = (int *)*piVar5;
    }
    FUN_0151f850("Under13",piVar5);
    if (0xf < *(uint *)(param_1 + 0x50)) {
      puVar6 = (undefined4 *)*puVar6;
    }
    FUN_0151f850("Over13",puVar6);
    iVar1 = DAT_01eea9b0;
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = 0;
    FUN_005542c0("SiftSwear",9);
    uStack_8 = 3;
    FUN_01520d20(auStack_40,iVar1,0);
    FUN_005507b0();
    FUN_0151f7f0();
  }
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    ppppuVar3 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar4) {
      ppppuVar3 = (undefined4 ****)apppuStack_28[0][-1];
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar3,uVar4);
  }
  iStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  if (0xf < in_stack_0000001c) {
    uVar4 = in_stack_0000001c + 1;
    puVar6 = param_2;
    if (0xfff < uVar4) {
      puVar6 = (undefined4 *)param_2[-1];
      uVar4 = in_stack_0000001c + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar6,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21501 ; VA 0x00a802b0 ; FUN_00a802b0 */

void __thiscall FUN_00a802b0(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int *piVar8;
  int aiStack_54 [5];
  uint uStack_40;
  int aiStack_3c [5];
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e4383;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  cVar1 = FUN_00fa09c0(param_2,param_3);
  if (cVar1 == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  FUN_016830f0(&uStack_24);
  FUN_00fa1110(aiStack_3c,param_2);
  uStack_8 = 0;
  uVar6 = 0xa8031c;
  iVar2 = FUN_00fa1110(aiStack_54,aiStack_3c);
  iVar4 = param_1 + 0xa5 + (uint)*(byte *)(param_1 + 0xa4);
  uVar3 = FUN_005702d0(iVar2);
  uVar5 = -(uint)(iVar4 != 0) & iVar4 + 1U;
  piVar8 = &iStack_1c;
  uVar7 = 0xa80347;
  FUN_00562fc0(piVar8,uVar3,iVar2,uVar5);
  if (0xf < uStack_40) {
    uVar5 = uStack_40 + 1;
    iVar2 = aiStack_54[0];
    if (0xfff < uVar5) {
      iVar2 = *(int *)(aiStack_54[0] + -4);
      uVar5 = uStack_40 + 0x24;
      if (0x1f < (aiStack_54[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uVar3 = 0xa80378;
    FUN_01674ea0(iVar2,uVar5);
  }
  if (iStack_1c == 0) {
    if (DAT_01d663c0 <= *(uint *)(iStack_14 + 0xac)) goto LAB_00a803db;
    FUN_0054ef60(param_3);
    uVar3 = FUN_00a7c080(uStack_24,uStack_20,uVar6,uVar7,piVar8,uVar3,iVar2,uVar5);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00a77190(&iStack_18,aiStack_3c,aiStack_3c,uVar3);
    FUN_00a7d100();
    iStack_1c = iStack_18;
  }
  *(undefined *)(iStack_1c + 0x61) = 1;
LAB_00a803db:
  if (0xf < uStack_28) {
    uVar5 = uStack_28 + 1;
    iVar2 = aiStack_3c[0];
    if (0xfff < uVar5) {
      iVar2 = *(int *)(aiStack_3c[0] + -4);
      uVar5 = uStack_28 + 0x24;
      if (0x1f < (aiStack_3c[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21502 ; VA 0x00a80430 ; FUN_00a80430 */

void __fastcall FUN_00a80430(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  
  piVar1 = (int *)*param_1;
  piVar6 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar6 != (int *)*param_1) {
    do {
      piVar1 = (int *)*piVar6;
      FUN_0096d5e0();
      uVar2 = piVar6[7];
      if (0xf < uVar2) {
        iVar3 = piVar6[2];
        uVar5 = uVar2 + 1;
        iVar4 = iVar3;
        if (0xfff < uVar5) {
          iVar4 = *(int *)(iVar3 + -4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar5);
      }
      piVar6[6] = 0;
      piVar6[7] = 0xf;
      *(undefined *)(piVar6 + 2) = 0;
      FUN_01674ea0(piVar6,0x88);
      piVar6 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 21503 ; VA 0x00a804c0 ; FUN_00a804c0 */

int FUN_00a804c0(undefined4 param_1,int *param_2,int param_3,int *param_4,undefined4 *param_5)

{
  int *piVar1;
  int iVar2;
  undefined *puVar3;
  int iVar4;
  undefined4 *puVar5;
  int *piVar6;
  undefined8 uVar7;
  uint in_stack_00000028;
  undefined4 **in_stack_0000002c;
  undefined auStack_114 [8];
  undefined4 uStack_10c;
  int iStack_108;
  int *piStack_104;
  undefined *puStack_100;
  code *pcStack_fc;
  undefined4 uStack_f8;
  undefined auStack_f4 [8];
  undefined4 uStack_ec;
  int iStack_e8;
  int *piStack_e4;
  undefined *puStack_e0;
  undefined4 *puStack_dc;
  undefined auStack_d8 [24];
  undefined *puStack_c0;
  undefined auStack_bc [16];
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined4 auStack_98 [7];
  undefined4 uStack_7c;
  undefined4 uStack_78;
  uint uStack_74;
  char *pcStack_70;
  undefined8 uStack_6c;
  undefined8 uStack_64;
  undefined4 *puStack_5c;
  undefined *puStack_50;
  undefined4 *puStack_4c;
  int iStack_48;
  int *piStack_44;
  undefined *puStack_40;
  undefined *puStack_3c;
  undefined *puStack_38;
  undefined *puStack_34;
  undefined *puStack_30;
  undefined8 uStack_2c;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4428;
  pvStack_10 = ExceptionList;
  puStack_5c = &param_1;
  uStack_8 = 2;
  uStack_64._4_4_ = (undefined **)&iStack_48;
  uStack_64._0_4_ = 0xa804f4;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00562c90();
  uStack_8._0_1_ = 3;
  piVar6 = piStack_44;
  if (iStack_48 != 0) {
    if (param_3 == 0) {
      if (DAT_01eea9ad != 0) {
        puVar5 = &param_5;
        if (0xf < in_stack_00000028) {
          puVar5 = param_5;
        }
        puStack_5c = (undefined4 *)0xa807df;
        uStack_64 = FUN_00928340();
        uStack_6c._0_4_ = (uint)DAT_01eea9ad;
        uStack_6c._4_4_ = "Client2Server:FilterStringForBroadcast() %lld \"%s\"";
        pcStack_70 = (char *)0xa807f4;
        puStack_5c = puVar5;
        FUN_01677520();
      }
      uStack_2c._4_4_ = CONCAT31(uStack_2c._5_3_,DAT_01eeaa44);
      puVar3 = (undefined *)*in_stack_0000002c;
      puStack_5c = (undefined4 *)0xa8080b;
      uVar7 = FUN_00928340();
      uStack_24._0_4_ = (undefined4)((ulonglong)uVar7 >> 0x20);
      uStack_24._4_4_ = (undefined4)uVar7;
      puStack_40 = (undefined *)&uStack_78;
      uStack_2c._0_4_ = &uStack_78;
      puStack_dc = &param_5;
      uStack_7c = 0;
      in_stack_0000002c = (undefined4 **)auStack_bc;
      puStack_3c = auStack_d8;
      puStack_e0 = (undefined *)0xa80834;
      puStack_c0 = puVar3;
      FUN_0054ef60();
      puStack_38 = (undefined *)&puStack_e0;
      puStack_e0 = (undefined *)0x0;
      puStack_dc = (undefined4 *)0x0;
      puStack_34 = (undefined *)&iStack_e8;
      if (piStack_44 != (int *)0x0) {
        LOCK();
        piStack_44[1] = piStack_44[1] + 1;
        UNLOCK();
      }
      iStack_e8 = iStack_48;
      piStack_e4 = piStack_44;
      uStack_ec = 0;
      pcStack_fc = (code *)auStack_f4;
      uStack_8._0_1_ = 0xe;
      uStack_f8 = uStack_14;
      puStack_100 = (undefined *)0xa80885;
      FUN_0060dcd0();
      uStack_8._0_1_ = 3;
      uStack_f8 = 0;
      pcStack_fc = FUN_00a80980;
      puStack_100 = (undefined *)in_stack_0000002c;
      piStack_104 = (int *)0xa8089b;
      FUN_00a76a10();
      puStack_c0 = (undefined *)0xa808a6;
      FUN_00a74430();
      uStack_2c._0_4_ = auStack_98;
      uStack_8._0_1_ = 0xf;
      pcStack_fc = (code *)&param_5;
      uStack_a0._4_4_ = 0;
      in_stack_0000002c = &puStack_dc;
      puStack_3c = (undefined *)&uStack_f8;
      puStack_100 = (undefined *)0xa808ca;
      puStack_e0 = puVar3;
      FUN_0054ef60();
      puStack_38 = (undefined *)&puStack_100;
      puStack_100 = (undefined *)0x0;
      pcStack_fc = (code *)0x0;
      puStack_34 = (undefined *)&iStack_108;
      if (piStack_44 != (int *)0x0) {
        LOCK();
        piStack_44[1] = piStack_44[1] + 1;
        UNLOCK();
      }
      iStack_108 = iStack_48;
      piStack_104 = piStack_44;
      uStack_10c = uStack_2c._4_4_;
      uStack_8._0_1_ = 0x12;
      FUN_0060dcd0(auStack_114,uStack_14);
      uStack_8._0_1_ = 0xf;
      FUN_00a760b0(in_stack_0000002c,FUN_00a80980,0);
      puStack_e0 = (undefined *)0xa8093b;
      FUN_00a743a0();
      uStack_a0._4_4_ = (undefined4)uStack_24;
      uStack_8._0_1_ = 3;
      uStack_a0._0_4_ = uStack_24._4_4_;
      uStack_a8._4_4_ = 0xa8094c;
      iVar4 = FUN_00a7f610();
      piVar6 = piStack_44;
    }
    else {
      puStack_5c = &param_3;
      uStack_64._4_4_ = &puStack_50;
      uStack_64._0_4_ = 0xa8051c;
      FUN_00562c90();
      uStack_8._0_1_ = 4;
      if (puStack_50 == (undefined *)0x0) {
        puStack_5c = (undefined4 *)0xa80536;
        iVar4 = FUN_00550b30();
        piVar6 = piStack_44;
      }
      else {
        if (DAT_01eea9ad != 0) {
          puStack_18 = &param_5;
          if (0xf < in_stack_00000028) {
            puStack_18 = param_5;
          }
          puStack_5c = (undefined4 *)0xa805fa;
          uVar7 = FUN_00928340();
          puStack_5c = (undefined4 *)0xa80606;
          uStack_6c = FUN_00928340();
          puStack_5c = puStack_18;
          uStack_74 = (uint)DAT_01eea9ad;
          pcStack_70 = "Client2Server:FilterStringAync() %lld to %lld \"%s\"";
          uStack_78 = 0xa8061f;
          uStack_64 = uVar7;
          FUN_01677520();
        }
        uStack_1c = CONCAT31(uStack_1c._1_3_,DAT_01eeaa44);
        puVar3 = (undefined *)*in_stack_0000002c;
        puStack_5c = (undefined4 *)0xa8063a;
        uStack_24 = FUN_00928340();
        puStack_5c = (undefined4 *)0xa80647;
        uStack_2c = FUN_00928340();
        puStack_30 = (undefined *)&uStack_78;
        puStack_18 = &uStack_78;
        puStack_dc = &param_5;
        uStack_7c = 0;
        in_stack_0000002c = (undefined4 **)auStack_bc;
        puStack_34 = auStack_d8;
        puStack_e0 = (undefined *)0xa80670;
        puStack_c0 = puVar3;
        FUN_0054ef60();
        puStack_38 = (undefined *)&puStack_e0;
        if (puStack_4c != (undefined4 *)0x0) {
          LOCK();
          puStack_4c[1] = puStack_4c[1] + 1;
          UNLOCK();
        }
        puStack_e0 = puStack_50;
        puStack_dc = puStack_4c;
        puStack_3c = (undefined *)&iStack_e8;
        if (piStack_44 != (int *)0x0) {
          LOCK();
          piStack_44[1] = piStack_44[1] + 1;
          UNLOCK();
        }
        iStack_e8 = iStack_48;
        piStack_e4 = piStack_44;
        uStack_ec = 0;
        pcStack_fc = (code *)auStack_f4;
        uStack_8._0_1_ = 7;
        uStack_f8 = uStack_14;
        puStack_100 = (undefined *)0xa806d4;
        FUN_0060dcd0();
        uStack_8._0_1_ = 4;
        uStack_f8 = 0;
        pcStack_fc = FUN_00a80980;
        puStack_100 = (undefined *)in_stack_0000002c;
        piStack_104 = (int *)0xa806ea;
        FUN_00a76a10();
        puStack_c0 = (undefined *)0xa806f5;
        FUN_00a74430();
        puStack_18 = auStack_98;
        uStack_8._0_1_ = 8;
        pcStack_fc = (code *)&param_5;
        uStack_a0._4_4_ = 0;
        in_stack_0000002c = &puStack_dc;
        puStack_40 = (undefined *)&uStack_f8;
        puStack_100 = (undefined *)0xa80719;
        puStack_e0 = puVar3;
        FUN_0054ef60();
        puStack_3c = (undefined *)&puStack_100;
        if (puStack_4c != (undefined4 *)0x0) {
          LOCK();
          puStack_4c[1] = puStack_4c[1] + 1;
          UNLOCK();
        }
        puStack_100 = puStack_50;
        pcStack_fc = (code *)puStack_4c;
        puStack_38 = (undefined *)&iStack_108;
        if (piStack_44 != (int *)0x0) {
          LOCK();
          piStack_44[1] = piStack_44[1] + 1;
          UNLOCK();
        }
        iStack_108 = iStack_48;
        piStack_104 = piStack_44;
        uStack_10c = uStack_1c;
        uStack_8._0_1_ = 0xb;
        FUN_0060dcd0(auStack_114,uStack_14);
        uStack_8._0_1_ = 8;
        FUN_00a760b0(in_stack_0000002c,FUN_00a80980,0);
        puStack_e0 = (undefined *)0xa8079d;
        FUN_00a743a0();
        uStack_8._0_1_ = 4;
        uStack_ac = 0xa807b4;
        uStack_a8 = uStack_2c;
        uStack_a0 = uStack_24;
        FUN_00a7f8c0();
        puStack_5c = (undefined4 *)0xa807bc;
        iVar4 = FUN_00550b30();
        piVar6 = piStack_44;
      }
    }
  }
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar1 = piVar6 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puStack_5c = (undefined4 *)0xa8054c;
      (**(code **)*piVar6)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        puStack_5c = (undefined4 *)0xa8055c;
        iVar4 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  piVar6 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puStack_5c = (undefined4 *)0xa80572;
      (**(code **)*param_2)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        puStack_5c = (undefined4 *)0xa80582;
        iVar4 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  piVar6 = param_4;
  uVar7 = uStack_64;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puStack_5c = (undefined4 *)0xa80598;
      iVar4 = (**(code **)*param_4)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      uVar7 = uStack_64;
      if (iVar2 == 1) {
        puStack_5c = (undefined4 *)0xa805a7;
        iVar4 = (**(code **)(*piVar6 + 4))();
        uVar7 = uStack_64;
      }
    }
  }
  if (0xf < in_stack_00000028) {
    puStack_5c = (undefined4 *)(in_stack_00000028 + 1);
    uStack_64._4_4_ = (undefined **)param_5;
    if (0xfff < puStack_5c) {
      uStack_64._4_4_ = (undefined **)param_5[-1];
      puStack_5c = (undefined4 *)(in_stack_00000028 + 0x24);
      if (0x1f < (uint)((int)param_5 + (-4 - (int)uStack_64._4_4_))) {
                    /* WARNING: Subroutine does not return */
        puStack_5c = (undefined4 *)&UNK_00a80975;
        uStack_64 = uVar7;
        FUN_017167a3();
      }
    }
    uStack_64._0_4_ = 0xa8095b;
    iVar4 = FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 21504 ; VA 0x00a80980 ; FUN_00a80980 */

code * __thiscall
FUN_00a80980(undefined4 param_1,undefined4 param_2,undefined4 *param_3,int *param_4,
            undefined1 *param_5,code *param_6,undefined4 *param_7)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  undefined4 uVar4;
  code *pcVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined8 uVar8;
  uint in_stack_0000002c;
  code **in_stack_00000030;
  uint uStack_d4;
  undefined4 *puStack_d0;
  undefined4 *puStack_cc;
  code *pcStack_c8;
  undefined1 *puStack_c4;
  undefined4 uStack_c0;
  undefined auStack_bc [4];
  undefined4 uStack_b8;
  undefined4 *puStack_b4;
  int *piStack_b0;
  undefined1 *puStack_ac;
  code *pcStack_a8;
  undefined auStack_a4 [4];
  undefined4 uStack_a0;
  uint uStack_9c;
  char *pcStack_98;
  undefined4 *puStack_94;
  undefined8 uStack_90;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined auStack_78 [24];
  undefined auStack_60 [24];
  undefined4 *puStack_48;
  code *pcStack_40;
  undefined4 uStack_38;
  uint uStack_34;
  char *pcStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e44b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if ((char)param_2 == '\0') {
    ExceptionList = &pvStack_10;
    if (DAT_01eea9ad != 0) {
      puVar6 = &param_7;
      if (0xf < in_stack_0000002c) {
        puVar6 = param_7;
      }
      if (param_3 == (undefined4 *)0x0) {
        uVar8 = 0x8000000000000000;
        ExceptionList = &pvStack_10;
      }
      else {
        uStack_90 = CONCAT44(0xa809d0,(undefined4)uStack_90);
        ExceptionList = &pvStack_10;
        uVar8 = FUN_00928340();
      }
      puStack_94 = (undefined4 *)uVar8;
      uStack_90 = CONCAT44(puVar6,(int)((ulonglong)uVar8 >> 0x20));
      uStack_9c = (uint)DAT_01eea9ad;
      pcStack_98 = "Client2Server:Callback:NoChat %lld \"%s\"";
      uStack_a0 = 0xa809f1;
      FUN_01677520();
    }
    puStack_20 = in_stack_00000030;
    uStack_1c = 0;
    pcStack_a8 = (code *)0x0;
    puStack_94 = (undefined4 *)0x0;
    uStack_90 = CONCAT44(&puStack_20,0xf);
    puStack_ac = &DAT_018bc9b8;
    auStack_a4[0] = 0;
    piStack_b0 = (int *)0xa80a2a;
    FUN_005542c0();
    in_stack_00000030 = (code **)auStack_bc;
    uStack_8._0_1_ = 3;
    uStack_c0 = 0;
    puStack_ac = (undefined1 *)0x0;
    pcStack_a8 = (code *)&DAT_0000000f;
    puStack_c4 = &DAT_018bc9b8;
    auStack_bc[0] = 0;
    pcStack_c8 = (code *)0xa80a53;
    FUN_005542c0();
    puStack_14 = (undefined *)&uStack_d4;
    uStack_8._0_1_ = 4;
    puStack_c4 = (undefined1 *)0x0;
    uStack_c0 = 0xf;
    uStack_d4 = uStack_d4 & 0xffffff00;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 5;
    FUN_0054ef60(&param_7);
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    pcVar5 = (code *)FUN_00a8be90(param_1,param_3,param_4);
  }
  else {
    param_2 = CONCAT31(param_2._1_3_,DAT_01eeaa44);
    uStack_90 = CONCAT44(*in_stack_00000030,(undefined4)uStack_90);
    pcStack_a8 = (code *)&param_7;
    in_stack_00000030 = (code **)auStack_a4;
    puStack_ac = (undefined1 *)0xa80aee;
    ExceptionList = &pvStack_10;
    FUN_0054ef60();
    puStack_18 = (undefined *)&puStack_ac;
    if (param_6 != (code *)0x0) {
      LOCK();
      *(int *)(param_6 + 4) = *(int *)(param_6 + 4) + 1;
      UNLOCK();
    }
    puStack_ac = param_5;
    pcStack_a8 = param_6;
    puStack_14 = (undefined *)&puStack_b4;
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    puStack_b4 = param_3;
    piStack_b0 = param_4;
    uStack_b8 = param_2;
    uStack_8._0_1_ = 8;
    pcStack_c8 = (code *)&uStack_c0;
    puStack_cc = (undefined4 *)0xa80b57;
    puStack_c4 = (undefined1 *)param_1;
    FUN_0060dcd0();
    uStack_8._0_1_ = 2;
    puStack_c4 = (undefined1 *)0x0;
    pcStack_c8 = FUN_00a80d60;
    puStack_d0 = (undefined4 *)0xa80b6b;
    puStack_cc = &uStack_80;
    FUN_00a760b0();
    uStack_90 = uStack_90 & 0xffffffff;
    puStack_cc = (undefined4 *)uStack_80;
    pcStack_c8 = (code *)uStack_7c;
    puStack_d0 = (undefined4 *)auStack_78;
    uStack_d4 = 0xa80b94;
    FUN_00a7a380();
    puStack_d0 = (undefined4 *)auStack_60;
    uStack_8._0_1_ = 10;
    uStack_d4 = 0xa80ba4;
    FUN_0054ef60();
    uStack_8._0_1_ = 9;
    puStack_94 = puStack_48;
    puStack_d0 = (undefined4 *)0xa80bb6;
    FUN_00a73dd0();
    uStack_90 = CONCAT44(0xa80bbe,(undefined4)uStack_90);
    FUN_00a7cb00();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    if (DAT_01eea9ad != 0) {
      puVar6 = &param_7;
      if (0xf < in_stack_0000002c) {
        puVar6 = param_7;
      }
      if (param_3 == (undefined4 *)0x0) {
        uVar8 = 0x8000000000000000;
      }
      else {
        uStack_90 = CONCAT44(0xa80be2,(undefined4)uStack_90);
        uVar8 = FUN_00928340();
      }
      puStack_94 = (undefined4 *)uVar8;
      uStack_90 = CONCAT44(puVar6,(int)((ulonglong)uVar8 >> 0x20));
      uStack_9c = (uint)DAT_01eea9ad;
      pcStack_98 = "Client2Server:Callback:Submitted %lld \"%s\"";
      uStack_a0 = 0xa80c00;
      FUN_01677520();
    }
    uVar4 = DAT_01d66400;
    in_stack_00000030 = &pcStack_a8;
    pcStack_a8 = (code *)0x0;
    if (pcStack_40 != (code *)0x0) {
      pcStack_a8 = pcStack_40;
      if (((uint)pcStack_40 & 1) == 0) {
        piStack_b0 = &uStack_a0;
        puStack_ac = (undefined1 *)0x0;
        puStack_b4 = &uStack_38;
        uStack_b8 = 0xa80c4d;
        (**(code **)((uint)pcStack_40 & 0xfffffffe))();
      }
      else {
        uStack_a0 = uStack_38;
        uStack_9c = uStack_34;
        pcStack_98 = pcStack_30;
        puStack_94 = puStack_2c;
        uStack_90 = uStack_28;
      }
    }
    puStack_ac = (undefined1 *)0x2;
    in_stack_00000030 = (code **)&puStack_b4;
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    puStack_b4 = param_3;
    piStack_b0 = param_4;
    uStack_8._0_1_ = 0xd;
    puStack_d0 = &param_7;
    uStack_d4 = 0xa80c8f;
    FUN_0054ef60();
    puStack_d0 = (undefined4 *)uVar4;
    uStack_8._0_1_ = 0xb;
    uStack_d4 = 0xa80c9b;
    FUN_00a85f10();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
    pcVar5 = pcStack_40;
    if (pcStack_40 != (code *)0x0) {
      if ((((uint)pcStack_40 & 1) == 0) &&
         (pcVar5 = *(code **)((uint)pcStack_40 & 0xfffffffe), pcVar5 != (code *)0x0)) {
        puStack_94 = &uStack_38;
        uStack_90 = CONCAT44(2,puStack_94);
        pcStack_98 = (char *)0xa80cbc;
        pcVar5 = (code *)(*pcVar5)();
      }
      pcStack_40 = (code *)0x0;
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar3 = *piVar1;
    pcVar5 = (code *)*piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      uStack_90 = CONCAT44(0xa80cdf,(undefined4)uStack_90);
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar3 = *piVar1;
      pcVar5 = (code *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        uStack_90 = CONCAT44(0xa80cef,(undefined4)uStack_90);
        pcVar5 = (code *)(**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (code *)0x0) {
    LOCK();
    pcVar2 = param_6 + 4;
    iVar3 = *(int *)pcVar2;
    pcVar5 = *(code **)pcVar2;
    *(int *)pcVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      uStack_90 = CONCAT44(0xa80d05,(undefined4)uStack_90);
      pcVar5 = (code *)(*(code *)**(undefined4 **)param_6)();
      LOCK();
      pcVar2 = param_6 + 8;
      iVar3 = *(int *)pcVar2;
      *(int *)pcVar2 = *(int *)pcVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        uStack_90 = CONCAT44(0xa80d14,(undefined4)uStack_90);
        pcVar5 = (code *)(**(code **)(*(int *)param_6 + 4))();
      }
    }
  }
  if (0xf < in_stack_0000002c) {
    uVar7 = in_stack_0000002c + 1;
    puVar6 = param_7;
    if (0xfff < uVar7) {
      puVar6 = (undefined4 *)param_7[-1];
      uVar7 = in_stack_0000002c + 0x24;
      if (0x1f < (uint)((int)param_7 + (-4 - (int)puVar6))) {
        uStack_90 = CONCAT44(&UNK_00a80d5b,(undefined4)uStack_90);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_90 = CONCAT44(uVar7,puVar6);
    puStack_94 = (undefined4 *)0xa80d41;
    pcVar5 = (code *)FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return pcVar5;
}



/* FUNCTION 21505 ; VA 0x00a80d60 ; FUN_00a80d60 */

int __thiscall
FUN_00a80d60(undefined4 param_1,int param_2,int param_3,int *param_4,undefined4 param_5,int *param_6
            ,undefined4 *param_7)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  uint in_stack_0000002c;
  undefined *in_stack_00000030;
  undefined auStack_74 [12];
  undefined4 uStack_68;
  undefined1 *puStack_64;
  int iStack_60;
  undefined uStack_5c;
  undefined4 uStack_50;
  undefined1 *puStack_4c;
  int iStack_48;
  undefined auStack_44 [8];
  undefined4 uStack_3c;
  uint uStack_38;
  char *pcStack_34;
  char *pcStack_30;
  undefined4 *puStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4508;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if ((param_3 == 0) || (*(char *)(param_2 + 8) != '\0')) {
    puVar4 = (undefined4 *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    if (DAT_01eea9ad != 0) {
      puStack_2c = puVar4;
      if (0xf < *(uint *)(param_2 + 0x20)) {
        puStack_2c = (undefined4 *)*puVar4;
      }
      pcStack_30 = (char *)&param_7;
      if (0xf < in_stack_0000002c) {
        pcStack_30 = (char *)param_7;
      }
      uStack_38 = (uint)DAT_01eea9ad;
      pcStack_34 = "Client2Server:Response:Error \"%s\" \"%s\"";
      uStack_3c = 0xa80e61;
      ExceptionList = &pvStack_10;
      FUN_01677520();
    }
    uStack_20 = in_stack_00000030;
    puStack_2c = &uStack_20;
    in_stack_00000030 = auStack_44;
    uStack_1c = 0;
    iStack_48 = 0;
    pcStack_34 = (char *)0x0;
    pcStack_30 = (char *)0xf;
    puStack_4c = &DAT_018bc9b8;
    auStack_44[0] = 0;
    uStack_50 = 0xa80e9a;
    FUN_005542c0();
    uStack_8._0_1_ = 3;
    iStack_60 = 0;
    puStack_4c = (undefined1 *)0x0;
    iStack_48 = 0xf;
    puStack_64 = &DAT_018bc9b8;
    uStack_5c = 0;
    uStack_68 = 0xa80ec3;
    FUN_005542c0();
    puStack_18 = auStack_74;
    uStack_8._0_1_ = 4;
    FUN_0054ef60(puVar4);
    uStack_8._0_1_ = 5;
  }
  else {
    ExceptionList = &pvStack_10;
    if (DAT_01eea9ad != 0) {
      puStack_2c = &param_7;
      if (0xf < in_stack_0000002c) {
        puStack_2c = param_7;
      }
      pcStack_34 = (char *)(uint)DAT_01eea9ad;
      pcStack_30 = "Client2Server:Response:Success \"%s\"";
      uStack_38 = 0xa80dc1;
      ExceptionList = &pvStack_10;
      FUN_01677520();
    }
    uStack_20 = in_stack_00000030;
    puStack_2c = &uStack_20;
    in_stack_00000030 = auStack_44;
    uStack_1c = 0;
    iStack_48 = param_2 + 0x3c;
    puStack_4c = (undefined1 *)0xa80de6;
    FUN_0054ef60();
    uStack_8._0_1_ = 6;
    iStack_60 = param_2 + 0x24;
    puStack_64 = (undefined1 *)0xa80dfb;
    FUN_0054ef60();
    puStack_14 = auStack_74;
    uStack_8._0_1_ = 7;
    puStack_64 = (undefined1 *)0x0;
    iStack_60 = 0xf;
    auStack_74[0] = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 8;
  }
  FUN_0054ef60(&param_7);
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iVar3 = FUN_00a8be90(param_1,param_3,param_4);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puStack_2c = (undefined4 *)0xa80f39;
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        puStack_2c = (undefined4 *)0xa80f49;
        iVar3 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    piVar1 = param_6 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puStack_2c = (undefined4 *)0xa80f5f;
      iVar3 = (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_2c = (undefined4 *)0xa80f6e;
        iVar3 = (**(code **)(*param_6 + 4))();
      }
    }
  }
  if (0xf < in_stack_0000002c) {
    puStack_2c = (undefined4 *)(in_stack_0000002c + 1);
    puVar4 = param_7;
    if (0xfff < puStack_2c) {
      puVar4 = (undefined4 *)param_7[-1];
      puStack_2c = (undefined4 *)(in_stack_0000002c + 0x24);
      if (0x1f < (uint)((int)param_7 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
        puStack_2c = (undefined4 *)&UNK_00a80fb5;
        FUN_017167a3();
      }
    }
    pcStack_34 = (char *)0xa80f9b;
    pcStack_30 = (char *)puVar4;
    iVar3 = FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 21506 ; VA 0x00a80fc0 ; FUN_00a80fc0 */

undefined4 * __thiscall
FUN_00a80fc0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4551;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00a82b90;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21507 ; VA 0x00a81170 ; FUN_00a81170 */

undefined4 * __thiscall
FUN_00a81170(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4591;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00a82e40;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21508 ; VA 0x00a81320 ; FUN_00a81320 */

undefined4 * __thiscall
FUN_00a81320(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e45d1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00a83070;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21509 ; VA 0x00a814d0 ; FUN_00a814d0 */

undefined4 * __thiscall
FUN_00a814d0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4611;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00a83250;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21510 ; VA 0x00a81680 ; FUN_00a81680 */

undefined4 * __thiscall
FUN_00a81680(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4651;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00a833e0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21511 ; VA 0x00a81820 ; FUN_00a81820 */

void __fastcall FUN_00a81820(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  if (param_1[1] == 0) {
    *(undefined2 *)(param_1 + 2) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0xb0);
    param_1[1] = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    FUN_0170d1f0(puVar1 + 2,0,0xa8);
    *(undefined *)(param_1 + 2) = 1;
    return;
  }
  if (*(char *)((int)param_1 + 9) != '\0') {
    FUN_00a77130(*param_1,param_1[1] + 8);
    *(undefined *)((int)param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 21512 ; VA 0x00a81880 ; FUN_00a81880 */

void FUN_00a81880(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00a8caa0();
    *param_2 = uVar3;
    iVar4 = FUN_00a8ccb0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 21513 ; VA 0x00a818e0 ; FUN_00a818e0 */

void FUN_00a818e0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00a8cb50();
    *param_2 = uVar3;
    iVar4 = FUN_00a8cd20();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 21514 ; VA 0x00a81940 ; FUN_00a81940 */

void FUN_00a81940(undefined4 param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined auStack_8 [4];
  
  cVar1 = FUN_009cb5f0(param_1,auStack_8);
  if (cVar1 != '\0') {
    uVar2 = FUN_00a8cc00();
    *param_2 = uVar2;
    FUN_00a74690(auStack_8);
  }
  return;
}



/* FUNCTION 21515 ; VA 0x00a81970 ; FUN_00a81970 */

void FUN_00a81970(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00a8caa0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 21516 ; VA 0x00a819b0 ; FUN_00a819b0 */

void FUN_00a819b0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00a8cb50();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 21517 ; VA 0x00a819f0 ; FUN_00a819f0 */

void FUN_00a819f0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00a8cc00();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 21518 ; VA 0x00a81a30 ; FUN_00a81a30 */

undefined4 * FUN_00a81a30(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00671530(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 21519 ; VA 0x00a81aa0 ; FUN_00a81aa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00a81aa0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 auStack_1b4 [50];
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798da0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088cbe0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar4 = 2;
  }
  else {
    uStack_1bc = FUN_00a8caa0();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar5;
    iStack_1b8 = FUN_00a8ccb0();
    puStack_18 = &uStack_1bc;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar5 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar2 = FUN_00a8caa0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_0088cbe0();
    puStack_e8 = (undefined4 *)0x0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead3c8)
       && (FUN_016f3809(&DAT_01ead3c8), DAT_01ead3c8 == -1)) {
      DAT_01ead3bc = FUN_0057bbb0;
      _DAT_01ead3c0 = FUN_005880a0;
      DAT_01ead3c4 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ead3c8);
    }
    puStack_e8 = &DAT_01ead3bc;
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cbe0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, puStack_e8 != (undefined4 *)0x0)) {
    (*(code *)puStack_e8[2])(&uStack_e4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21520 ; VA 0x00a81d50 ; FUN_00a81d50 */

void __thiscall FUN_00a81d50(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798aa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uStack_8 = 1;
    uVar6 = 2;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_006309e0();
    puStack_18 = &uStack_ec;
    uStack_8 = 0;
    uVar6 = 1;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar2 = *(int *)(param_1 + 0x44);
  if (iVar2 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar2);
    iStack_e8 = FUN_005c9d30();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x48);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    uStack_28c = FUN_00a8cb50();
    iStack_288 = 0;
    auStack_284[0] = *puVar5;
    iStack_288 = FUN_00a8cd20();
    puVar5 = &uStack_28c;
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_00a8cb50();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar6 & 0x10) != 0) && (uStack_8 = 0xb, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21521 ; VA 0x00a82090 ; FUN_00a82090 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00a82090(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  undefined *puStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_00a8caa0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar5;
    iStack_e8 = FUN_00a8ccb0();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar5 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar2 = FUN_00a8caa0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 == 0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = FUN_00d88470();
    puStack_1b8 = (undefined *)0x0;
    FUN_00d88580(iVar1);
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee047c)
       && (FUN_016f3809(&DAT_01ee047c), DAT_01ee047c == -1)) {
      _DAT_01ee0470 = FUN_008c9370;
      _DAT_01ee0474 = FUN_008c9370;
      DAT_01ee0478 = FUN_008ca540;
      FUN_016f37bf(&DAT_01ee047c);
    }
    puStack_1b8 = &DAT_01ee0470;
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_00d88470();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, puStack_1b8 != (undefined *)0x0)) {
    (**(code **)(puStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21522 ; VA 0x00a82320 ; FUN_00a82320 */

void __thiscall FUN_00a82320(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e4708;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_0088cb40();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  iVar2 = *(int *)(param_1 + 0x40);
  if (iVar2 == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar6 = 2;
  }
  else {
    uStack_ec = FUN_0088cb40();
    iStack_e8 = 0;
    FUN_0054ef60(iVar2);
    iStack_e8 = FUN_005c9d30();
    puStack_18 = &uStack_ec;
    uVar6 = 1;
  }
  uStack_8 = (uint)(iVar2 == 0);
  uStack_14 = uVar6;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar5 = &uStack_28c;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_006309e0();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x48);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    uStack_1bc = FUN_0088cdc0();
    iStack_1b8 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_1b4 = *puVar5;
    uStack_1b0 = puVar5[1];
    iStack_1b8 = FUN_006309e0();
    puVar5 = &uStack_1bc;
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar6 & 0x10) != 0) && (uStack_8 = 0xb, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(&uStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21523 ; VA 0x00a82680 ; FUN_00a82680 */

void __thiscall FUN_00a82680(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798da0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_0088cb40();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  iVar2 = *(int *)(param_1 + 0x40);
  if (iVar2 == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar5 = 2;
  }
  else {
    uStack_1bc = FUN_0088cb40();
    iStack_1b8 = 0;
    FUN_0054ef60(iVar2);
    iStack_1b8 = FUN_005c9d30();
    puStack_18 = &uStack_1bc;
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar2 == 0);
  uStack_14 = uVar5;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(param_1 + 0x44);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar6 = &uStack_35c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar6[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar6[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar6;
    uStack_e0 = puVar6[1];
    iStack_e8 = FUN_006309e0();
    puVar6 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_e8 != 0)) {
    (**(code **)(iStack_e8 + 8))(&uStack_e4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21524 ; VA 0x00a828d0 ; FUN_00a828d0 */

void __thiscall FUN_00a828d0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [204];
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0aa0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088daf0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_005c1470(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x44) == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    puVar4 = (undefined4 *)FUN_005c1470(*(int *)(param_1 + 0x44));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21525 ; VA 0x00a82ab0 ; FUN_00a82ab0 */

int __thiscall FUN_00a82ab0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_00d88a30();
    FUN_01674ea0(puVar1,0x2c);
    iVar2 = iVar2 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 21526 ; VA 0x00a82b00 ; FUN_00a82b00 */

int __thiscall FUN_00a82b00(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iVar6;
  
  iVar6 = 0;
  puVar5 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar5;
    uVar1 = puVar5[7];
    if (0xf < uVar1) {
      iVar2 = puVar5[2];
      uVar4 = uVar1 + 1;
      iVar3 = iVar2;
      if (0xfff < uVar4) {
        iVar3 = *(int *)(iVar2 + -4);
        uVar4 = uVar1 + 0x24;
        if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar4);
    }
    puVar5[6] = 0;
    puVar5[7] = 0xf;
    *(undefined *)(puVar5 + 2) = 0;
    FUN_01674ea0(puVar5,0x30);
    iVar6 = iVar6 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar5 = (undefined4 *)*param_2;
  } while (puVar5 != param_3);
  return iVar6;
}



/* FUNCTION 21527 ; VA 0x00a82b90 ; FUN_00a82b90 */

void FUN_00a82b90(int param_1,uint param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000030;
  uint in_stack_00000034;
  uint in_stack_00000038;
  undefined4 in_stack_00000048;
  uint in_stack_0000004c;
  int in_stack_00000050;
  uint in_stack_00000064;
  undefined4 uStack_360;
  undefined4 uStack_35c;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e478a;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 4;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_360 = FUN_0088cb40();
  uStack_35c = 0;
  FUN_0054ef60(&param_2);
  uStack_35c = FUN_005c9d30();
  uStack_8._0_1_ = 5;
  uStack_290 = FUN_0088cb40();
  uStack_28c = 0;
  FUN_0054ef60(&stack0x00000020);
  uStack_28c = FUN_005c9d30();
  uStack_8._0_1_ = 6;
  uStack_1c0 = FUN_0088cb40();
  uStack_1bc = 0;
  FUN_0054ef60(&stack0x00000038);
  uStack_1bc = FUN_005c9d30();
  uStack_8._0_1_ = 7;
  uStack_f0 = FUN_0088cb40();
  uStack_ec = 0;
  FUN_0054ef60(&stack0x00000050);
  uStack_ec = FUN_005c9d30();
  uStack_8._0_1_ = 8;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_360,&uStack_20,piVar1);
  uStack_8._0_1_ = 9;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 10;
  FUN_00577b20();
  uStack_8._0_1_ = 4;
  FUN_016f32d1(&uStack_360,0xd0,4,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  FUN_01675290(uVar3);
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    uVar6 = param_2;
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(param_2 - 4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar5);
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (0xf < in_stack_00000034) {
    uVar5 = in_stack_00000034 + 1;
    uVar6 = in_stack_00000020;
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(in_stack_00000020 - 4);
      uVar5 = in_stack_00000034 + 0x24;
      if (0x1f < (in_stack_00000020 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar5);
  }
  in_stack_00000030 = 0;
  in_stack_00000034 = 0xf;
  in_stack_00000020 = in_stack_00000020 & 0xffffff00;
  if (0xf < in_stack_0000004c) {
    uVar5 = in_stack_0000004c + 1;
    uVar6 = in_stack_00000038;
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(in_stack_00000038 - 4);
      uVar5 = in_stack_0000004c + 0x24;
      if (0x1f < (in_stack_00000038 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar5);
  }
  in_stack_00000048 = 0;
  in_stack_0000004c = 0xf;
  in_stack_00000038 = in_stack_00000038 & 0xffffff00;
  if (0xf < in_stack_00000064) {
    uVar6 = in_stack_00000064 + 1;
    iVar4 = in_stack_00000050;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(in_stack_00000050 + -4);
      uVar6 = in_stack_00000064 + 0x24;
      if (0x1f < (in_stack_00000050 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21528 ; VA 0x00a82e40 ; FUN_00a82e40 */

int FUN_00a82e40(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
                int param_6)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint in_stack_0000002c;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  int *piStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  int *piStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e47f7;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 3;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_290 = FUN_0088cdc0();
  uStack_28c = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_288 = param_2;
  piStack_284 = param_3;
  uStack_28c = FUN_006309e0();
  uStack_8._0_1_ = 4;
  uStack_1c0 = FUN_0088cdc0();
  uStack_1bc = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_1b8 = param_4;
  piStack_1b4 = param_5;
  uStack_1bc = FUN_006309e0();
  uStack_8._0_1_ = 5;
  uStack_f0 = FUN_0088cb40();
  uStack_ec = 0;
  FUN_0054ef60(&param_6);
  uStack_ec = FUN_005c9d30();
  uStack_8._0_1_ = 6;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,pcVar3);
  uStack_8._0_1_ = 7;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 8;
  FUN_00577b20();
  uStack_8._0_1_ = 3;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (0xf < in_stack_0000002c) {
    uVar6 = in_stack_0000002c + 1;
    iVar5 = param_6;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(param_6 + -4);
      uVar6 = in_stack_0000002c + 0x24;
      if (0x1f < (param_6 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(iVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 21529 ; VA 0x00a83070 ; FUN_00a83070 */

int FUN_00a83070(int param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  int *piStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e485f;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 2;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_290 = FUN_0088cdc0();
  uStack_28c = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_288 = param_2;
  piStack_284 = param_3;
  uStack_28c = FUN_006309e0();
  uStack_8._0_1_ = 3;
  uStack_1c0 = FUN_0088cb40();
  uStack_1bc = 0;
  FUN_0054ef60(&param_4);
  uStack_1bc = FUN_005c9d30();
  uStack_8._0_1_ = 4;
  uStack_f0 = FUN_00a8cb50();
  uStack_ec = 0;
  uStack_e8 = in_stack_00000028;
  uStack_ec = FUN_00a8cd20();
  uStack_8._0_1_ = 5;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_290,&uStack_20,pcVar3);
  uStack_8._0_1_ = 6;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 7;
  FUN_00577b20();
  uStack_8._0_1_ = 2;
  FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    uVar6 = in_stack_00000024 + 1;
    iVar5 = param_4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(param_4 + -4);
      uVar6 = in_stack_00000024 + 0x24;
      if (0x1f < (param_4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(iVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 21530 ; VA 0x00a83250 ; FUN_00a83250 */

void FUN_00a83250(undefined4 param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  uint in_stack_0000002c;
  undefined4 in_stack_0000003c;
  uint in_stack_00000040;
  uint in_stack_00000044;
  undefined4 in_stack_00000054;
  uint in_stack_00000058;
  int in_stack_0000005c;
  uint in_stack_00000070;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4898;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  ExceptionList = &pvStack_10;
  FUN_00a74740(&param_2,&param_4,&stack0x00000028,&stack0x0000002c,&stack0x00000044,&stack0x0000005c
              );
  piVar2 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    uVar4 = in_stack_00000024 + 1;
    uVar5 = param_4;
    if (0xfff < uVar4) {
      uVar5 = *(uint *)(param_4 - 4);
      uVar4 = in_stack_00000024 + 0x24;
      if (0x1f < (param_4 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar4);
  }
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_4 = param_4 & 0xffffff00;
  if (0xf < in_stack_00000040) {
    uVar4 = in_stack_00000040 + 1;
    uVar5 = in_stack_0000002c;
    if (0xfff < uVar4) {
      uVar5 = *(uint *)(in_stack_0000002c - 4);
      uVar4 = in_stack_00000040 + 0x24;
      if (0x1f < (in_stack_0000002c - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar4);
  }
  in_stack_0000003c = 0;
  in_stack_00000040 = 0xf;
  in_stack_0000002c = in_stack_0000002c & 0xffffff00;
  if (0xf < in_stack_00000058) {
    uVar4 = in_stack_00000058 + 1;
    uVar5 = in_stack_00000044;
    if (0xfff < uVar4) {
      uVar5 = *(uint *)(in_stack_00000044 - 4);
      uVar4 = in_stack_00000058 + 0x24;
      if (0x1f < (in_stack_00000044 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar4);
  }
  in_stack_00000054 = 0;
  in_stack_00000058 = 0xf;
  in_stack_00000044 = in_stack_00000044 & 0xffffff00;
  if (0xf < in_stack_00000070) {
    uVar5 = in_stack_00000070 + 1;
    iVar3 = in_stack_0000005c;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(in_stack_0000005c + -4);
      uVar5 = in_stack_00000070 + 0x24;
      if (0x1f < (in_stack_0000005c - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21531 ; VA 0x00a833e0 ; FUN_00a833e0 */

void FUN_00a833e0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined auStack_e8 [200];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e48e1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 1;
  puStack_ec = (undefined4 *)0x0;
  pcVar1 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_f0 = param_2;
  uStack_20 = uVar2;
  if (param_3 != (undefined4 *)0x0) {
    (*(code *)*param_3)(&stack0x00000010,auStack_e8);
  }
  puStack_ec = param_3;
  uStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,pcVar1);
  uStack_8._0_1_ = 3;
  (*pcVar1)(&uStack_1c);
  uStack_8._0_1_ = 4;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_01675290(uVar2);
  uStack_8 = 6;
  if (param_3 != (undefined4 *)0x0) {
    (*(code *)param_3[2])(&stack0x00000010);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21532 ; VA 0x00a83500 ; FUN_00a83500 */

void FUN_00a83500(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 in_stack_00000020;
  uint in_stack_00000024;
  undefined4 in_stack_00000028;
  uint in_stack_0000002c;
  undefined4 in_stack_0000003c;
  uint in_stack_00000040;
  uint in_stack_00000044;
  undefined4 in_stack_00000054;
  uint in_stack_00000058;
  int in_stack_0000005c;
  uint in_stack_00000070;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e2e60;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8._0_1_ = 5;
  FUN_0054ef60();
  uStack_8._0_1_ = 6;
  FUN_0054ef60(&stack0x0000002c);
  uStack_8._0_1_ = 7;
  FUN_0054ef60(&param_4);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00a75110(param_1 + 0x20,param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    if (0xfff < in_stack_00000024 + 1) {
      if (0x1f < (param_4 - *(int *)(param_4 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  in_stack_00000020 = 0;
  in_stack_00000024 = 0xf;
  param_4 = param_4 & 0xffffff00;
  if (0xf < in_stack_00000040) {
    if (0xfff < in_stack_00000040 + 1) {
      if (0x1f < (in_stack_0000002c - *(int *)(in_stack_0000002c - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  in_stack_0000003c = 0;
  in_stack_00000040 = 0xf;
  in_stack_0000002c = in_stack_0000002c & 0xffffff00;
  if (0xf < in_stack_00000058) {
    if (0xfff < in_stack_00000058 + 1) {
      if (0x1f < (in_stack_00000044 - *(int *)(in_stack_00000044 - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  in_stack_00000054 = 0;
  in_stack_00000058 = 0xf;
  in_stack_00000044 = in_stack_00000044 & 0xffffff00;
  if (0xf < in_stack_00000070) {
    if (0xfff < in_stack_00000070 + 1) {
      if (0x1f < (in_stack_0000005c - *(int *)(in_stack_0000005c + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21533 ; VA 0x00a83700 ; FUN_00a83700 */

int * __thiscall FUN_00a83700(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  
  piVar1 = (int *)*param_3;
  *param_2 = (int)piVar1;
  uVar3 = (uint)param_3[1] % *(uint *)(param_1 + 4);
  piVar2 = *(int **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  for (piVar5 = (int *)*piVar2; piVar5 != param_3; piVar5 = (int *)*piVar5) {
    piVar2 = piVar5;
  }
  do {
    *piVar2 = *piVar5;
    FUN_00a770b0(-(uint)(param_1 != -3) & param_1 + 4U,piVar5 + 2);
    FUN_01674ea0(piVar5,0x38);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    uVar4 = uVar3;
    if (*piVar2 == 0) {
LAB_00a83789:
      if (*(int **)(*(int *)(param_1 + 0x14) + uVar3 * 4) == piVar2) {
        *(undefined4 *)(*(int *)(param_1 + 0x14) + uVar3 * 4) = 0;
      }
    }
    else {
      uVar4 = *(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 4);
      if (uVar3 != uVar4) {
        *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4) = piVar2;
        goto LAB_00a83789;
      }
    }
    piVar5 = (int *)*piVar2;
    uVar3 = uVar4;
    if (piVar5 == piVar1) {
      return param_2;
    }
  } while( true );
}



/* FUNCTION 21534 ; VA 0x00a837c0 ; FUN_00a837c0 */

undefined8 * FUN_00a837c0(undefined8 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4909;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  *(undefined *)((int)param_1 + 9) = 0;
  *(undefined4 *)((int)param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 4) = 0xf;
  *(undefined *)((int)param_1 + 0xc) = 0;
  *(undefined4 *)((int)param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 7) = 0xf;
  *(undefined *)((int)param_1 + 0x24) = 0;
  *(undefined4 *)((int)param_1 + 0x4c) = 0;
  *(undefined4 *)(param_1 + 10) = 0xf;
  *(undefined *)((int)param_1 + 0x3c) = 0;
  uStack_8 = 0;
  *(undefined *)(param_1 + 1) = 1;
  if ((undefined4 *)((int)param_1 + 0xc) != param_2) {
    puVar1 = param_2 + 4;
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_005542c0(param_2,*puVar1);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21535 ; VA 0x00a83870 ; FUN_00a83870 */

void __thiscall FUN_00a83870(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  uint uVar8;
  int *piVar9;
  uint in_stack_0000002c;
  undefined4 uStack_118;
  int iStack_114;
  undefined auStack_110 [200];
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined auStack_28 [4];
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e495b;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar4 = (**(code **)*param_3)();
  if (2 < uVar4) {
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_8._0_1_ = 2;
    uStack_118 = FUN_00888530();
    iStack_114 = 0;
    uStack_8._0_1_ = 3;
    cVar3 = (**(code **)(*param_3 + 4))(3,&uStack_118);
    if (cVar3 != '\0') {
      puVar5 = (undefined4 *)FUN_0088a3d0();
      piVar9 = (int *)puVar5[1];
      if (piVar9 != (int *)0x0) {
        LOCK();
        piVar9[1] = piVar9[1] + 1;
        UNLOCK();
        piVar9 = (int *)puVar5[1];
      }
      uStack_1c = *puVar5;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      piStack_18 = piVar9;
      if (iStack_114 != 0) {
        (**(code **)(iStack_114 + 8))(auStack_110);
      }
      FUN_00550b30();
      goto LAB_00a83983;
    }
    uStack_8._0_1_ = 5;
    if (iStack_114 != 0) {
      (**(code **)(iStack_114 + 8))(auStack_110);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00550b30();
  }
  puVar5 = *(undefined4 **)(param_1 + 0x48);
  if (puVar5 == (undefined4 *)0x0) {
    FUN_016756b0(auStack_28,"Argument %d missing or nil",3);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_28,&DAT_01c17198);
  }
  piVar9 = (int *)puVar5[1];
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar9[1] = piVar9[1] + 1;
    UNLOCK();
    piVar9 = (int *)puVar5[1];
  }
  uStack_1c = *puVar5;
  piStack_18 = piVar9;
LAB_00a83983:
  uStack_8._0_1_ = 6;
  uVar6 = FUN_00a88400(auStack_30,param_3,iStack_14 + 0x44);
  uStack_8._0_1_ = 7;
  uVar7 = FUN_008cca80(auStack_48,param_3,iStack_14 + 0x40);
  uStack_8._0_1_ = 8;
  FUN_00a7f490(param_2,*(undefined4 *)(iStack_14 + 0x38),*(undefined4 *)(iStack_14 + 0x3c),uVar7,
               uVar6,&uStack_1c,&param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (0xf < uStack_34) {
    uVar8 = uStack_34 + 1;
    uVar4 = auStack_48[0];
    if (0xfff < uVar8) {
      uVar4 = *(uint *)(auStack_48[0] - 4);
      uVar8 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar8);
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar2 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (piVar9 != (int *)0x0) {
    LOCK();
    iVar2 = piVar9[1] + -1;
    piVar9[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar9)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar9 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 10;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21536 ; VA 0x00a83b00 ; FUN_00a83b00 */

void __thiscall FUN_00a83b00(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  uint in_stack_0000002c;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4990;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar3 = FUN_00a88400(auStack_1c,param_3,param_1 + 0x44);
  uStack_8._0_1_ = 2;
  uVar4 = FUN_008cca80(auStack_34,param_3,iStack_14 + 0x40);
  uStack_8._0_1_ = 3;
  FUN_00a7f200(param_2,*(undefined4 *)(iStack_14 + 0x38),*(undefined4 *)(iStack_14 + 0x3c),uVar4,
               uVar3,&param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < uStack_20) {
    uVar6 = uStack_20 + 1;
    uVar5 = auStack_34[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_34[0] - 4);
      uVar6 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 5;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21537 ; VA 0x00a83c50 ; FUN_00a83c50 */

void __thiscall FUN_00a83c50(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  char cVar1;
  uint uVar2;
  undefined4 *puVar3;
  uint in_stack_0000002c;
  undefined4 uStack_f4;
  int iStack_f0;
  undefined auStack_ec [200];
  undefined auStack_24 [4];
  undefined8 uStack_20;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e107b;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  uVar2 = (**(code **)*param_3)();
  if (1 < uVar2) {
    uStack_f4 = FUN_00888530();
    iStack_f0 = 0;
    uStack_8._0_1_ = 2;
    cVar1 = (**(code **)(*param_3 + 4))(2,&uStack_f4);
    if (cVar1 != '\0') {
      puVar3 = (undefined4 *)FUN_0088baa0();
      uStack_18 = *puVar3;
      uStack_14 = puVar3[1];
      uStack_8._0_1_ = 3;
      if (iStack_f0 != 0) {
        (**(code **)(iStack_f0 + 8))(auStack_ec);
      }
      uStack_8._0_1_ = 1;
      goto LAB_00a83d2c;
    }
    uStack_8._0_1_ = 4;
    if (iStack_f0 != 0) {
      (**(code **)(iStack_f0 + 8))(auStack_ec);
    }
    uStack_8._0_1_ = 1;
  }
  puVar3 = *(undefined4 **)(param_1 + 0x44);
  if (puVar3 == (undefined4 *)0x0) {
    FUN_016756b0(auStack_24,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_24,&DAT_01c17198);
  }
  uStack_18 = *puVar3;
  uStack_14 = puVar3[1];
LAB_00a83d2c:
  uStack_20 = FUN_009269c0(param_3,param_1 + 0x40);
  FUN_00a7f350(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&uStack_20,
               &uStack_18,&param_4,&stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21538 ; VA 0x00a83df0 ; FUN_00a83df0 */

void __thiscall
FUN_00a83df0(int param_1,undefined4 param_2,undefined4 param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10,uint param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined8 param_17)

{
  code *pcVar1;
  undefined8 uVar2;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined8 uStack_c0;
  undefined4 uStack_b8;
  undefined auStack_b4 [20];
  undefined4 uStack_a0;
  undefined4 *puStack_9c;
  undefined4 *puStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  undefined4 uStack_78;
  undefined4 *puStack_74;
  undefined4 *puStack_70;
  undefined4 uStack_6c;
  uint uStack_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined4 uStack_24;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_18 = &LAB_017c865e;
  pvStack_1c = ExceptionList;
  uStack_14 = 1;
  uStack_50 = CONCAT44(param_1 + 0x40,param_3);
  uStack_54 = 0xa83e36;
  ExceptionList = &pvStack_1c;
  uVar2 = FUN_009269c0();
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_24 = CONCAT31(uStack_24._1_3_,DAT_01eeaa44);
  uStack_68 = 0;
  if (param_11 != 0) {
    uStack_68 = param_11;
    if ((param_11 & 1) == 0) {
      puStack_70 = &uStack_60;
      uStack_6c = 0;
      puStack_74 = &param_13;
      uStack_78 = 0xa83e98;
      (**(code **)(param_11 & 0xfffffffe))();
    }
    else {
      uStack_60 = param_13;
      uStack_5c = param_14;
      uStack_58 = param_15;
      uStack_54 = param_16;
      uStack_50 = param_17;
    }
  }
  uStack_14._0_1_ = 2;
  uStack_90._4_4_ = 0;
  uStack_b8 = uStack_24;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_d0,0);
    }
    else {
      uStack_d0 = param_6;
      uStack_cc = param_7;
      uStack_c8 = param_8;
      uStack_c4 = param_9;
      uStack_c0 = param_10;
    }
  }
  FUN_008bfbf0(auStack_b4,FUN_008e61f0);
  uStack_b8 = 0xa83f07;
  FUN_008dc4b0();
  uStack_14._0_1_ = 1;
  uStack_94 = 0xa83f17;
  uStack_90 = uVar2;
  (*pcVar1)();
  uStack_14 = CONCAT31(uStack_14._1_3_,3);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_9c = &param_6;
    uStack_94 = 2;
    uStack_a0 = 0xa83f38;
    puStack_98 = puStack_9c;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_14 = 4;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_9c = &param_13;
    uStack_94 = 2;
    uStack_a0 = 0xa83f66;
    puStack_98 = puStack_9c;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 21539 ; VA 0x00a83f80 ; FUN_00a83f80 */

code * FUN_00a83f80(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  undefined auStack_40 [4];
  int *piStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined4 *puStack_30;
  int iStack_2c;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017e49b0;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar5 = FUN_01256300(param_2);
  iVar5 = iVar5 - param_3;
  puStack_30 = (undefined4 *)FUN_009d0b50(auStack_40,param_2,param_3,2,iVar5,(int)pcStack_28 + 0x44)
  ;
  uStack_14 = 0;
  if (0 < iVar5) {
    uVar6 = FUN_00a8caa0();
    cVar4 = FUN_009d1e20(uVar6,param_2,param_3 + 1,&iStack_2c);
    if (cVar4 != '\0') goto LAB_00a84024;
  }
  iStack_2c = FUN_00a77e20(param_2,param_3,1,iVar5,(int)pcStack_28 + 0x40);
LAB_00a84024:
  pcVar2 = *(code **)((int)pcStack_28 + 0x38);
  iVar5 = *(int *)((int)pcStack_28 + 0x3c);
  if (puStack_30[1] != 0) {
    LOCK();
    piVar1 = (int *)(puStack_30[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar3 = iStack_2c;
  iStack_2c = iVar5 + param_1;
  pcStack_28 = pcVar2;
  uVar6 = (*pcVar2)(auStack_38,iVar3,*puStack_30,puStack_30[1]);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  pcStack_28 = (code *)FUN_009d5730(param_2,uVar6);
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_34[1] + -1;
    piStack_34[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      iVar5 = piStack_34[2] + -1;
      piStack_34[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar5 = piStack_3c[1] + -1;
    piStack_3c[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_3c)();
      LOCK();
      piVar1 = piStack_3c + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return pcStack_28;
}



/* FUNCTION 21540 ; VA 0x00a840f0 ; FUN_00a840f0 */

undefined4 FUN_00a840f0(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  int aiStack_50 [5];
  uint uStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  int iStack_30;
  int iStack_2c;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017e49d0;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_01256300(param_2);
  iVar3 = iVar3 - param_3;
  if (2 < iVar3) {
    uVar4 = FUN_00a8cb50();
    cVar2 = FUN_009d1e20(uVar4,param_2,param_3 + 3,&iStack_30);
    if (cVar2 != '\0') goto LAB_00a84173;
  }
  iStack_30 = FUN_00a78020(param_2,param_3,3,iVar3,(int)pcStack_28 + 0x48);
LAB_00a84173:
  iStack_2c = iStack_30;
  uVar4 = FUN_009d09d0(aiStack_50,param_2,param_3,2,iVar3,(int)pcStack_28 + 0x44);
  uStack_14 = 0;
  puVar5 = (undefined4 *)FUN_009d1340(auStack_38,param_2,param_3,1,iVar3,(int)pcStack_28 + 0x40);
  uStack_14 = CONCAT31(uStack_14._1_3_,1);
  iStack_30 = *(int *)((int)pcStack_28 + 0x3c) + param_1;
  pcStack_28 = *(code **)((int)pcStack_28 + 0x38);
  FUN_0054ef60(uVar4);
  if (puVar5[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcStack_28)(*puVar5,puVar5[1]);
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_34[1] + -1;
    piStack_34[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar1 = piStack_34 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  if (0xf < uStack_3c) {
    uVar6 = uStack_3c + 1;
    iVar3 = aiStack_50[0];
    if (0xfff < uVar6) {
      iVar3 = *(int *)(aiStack_50[0] + -4);
      uVar6 = uStack_3c + 0x24;
      if (0x1f < (aiStack_50[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar6);
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 21541 ; VA 0x00a84280 ; FUN_00a84280 */

undefined4 __thiscall FUN_00a84280(int param_1,int param_2,undefined4 param_3,int param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 uStack_1e0;
  undefined4 *puStack_1dc;
  undefined auStack_1d8 [168];
  undefined4 uStack_130;
  undefined *puStack_12c;
  undefined4 uStack_128;
  int iStack_124;
  undefined4 uStack_120;
  int iStack_11c;
  int iStack_118;
  undefined4 uStack_114;
  undefined auStack_104 [4];
  int iStack_100;
  undefined auStack_fc [200];
  undefined *puStack_34;
  code *pcStack_30;
  int iStack_28;
  undefined4 *puStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017e49eb;
  pvStack_1c = ExceptionList;
  uStack_114 = param_3;
  iStack_118 = 0xa842bf;
  ExceptionList = &pvStack_1c;
  iStack_11c = FUN_01256300();
  iStack_118 = param_1 + 0x40;
  iStack_11c = iStack_11c - param_4;
  uStack_120 = 1;
  iStack_124 = param_4;
  puStack_12c = auStack_104;
  uStack_128 = param_3;
  uStack_130 = 0xa842d9;
  puVar2 = (undefined4 *)FUN_009d1540();
  pcStack_30 = *(code **)(param_1 + 0x38);
  puStack_34 = (undefined *)&uStack_1e0;
  iStack_28 = *(int *)(param_1 + 0x3c) + param_2;
  uStack_14 = 0;
  uStack_1e0 = *puVar2;
  puStack_1dc = (undefined4 *)0x0;
  puVar3 = (undefined4 *)puVar2[1];
  puVar1 = &uStack_1e0;
  puStack_24 = puVar2;
  if (puVar3 != (undefined4 *)0x0) {
    (*(code *)*puVar3)(puVar2 + 2,auStack_1d8);
    puVar3 = (undefined4 *)puVar2[1];
    puVar1 = (undefined4 *)puStack_34;
  }
  puStack_34 = (undefined *)puVar1;
  puStack_1dc = puVar3;
  (*pcStack_30)();
  uStack_14 = 1;
  if (iStack_100 != 0) {
    (**(code **)(iStack_100 + 8))(auStack_fc);
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 21542 ; VA 0x00a84370 ; FUN_00a84370 */

undefined4 FUN_00a84370(undefined4 param_1,undefined4 param_2,int param_3)

{
  code *pcVar1;
  undefined4 uVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined auStack_38 [32];
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e4a08;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_01256300(param_2);
  iVar4 = iVar4 - param_3;
  uStack_18 = FUN_009d1820(auStack_38,uVar2,param_3,2,iVar4,iStack_14 + 0x44);
  uStack_8 = 0;
  if (0 < iVar4) {
    uVar5 = FUN_00a8caa0();
    cVar3 = FUN_009d1e20(uVar5,uVar2,param_3 + 1,&param_2);
    uVar5 = param_2;
    if (cVar3 != '\0') goto LAB_00a843fe;
  }
  uVar5 = FUN_00a77e20(uVar2,param_3,1,iVar4,iStack_14 + 0x40);
LAB_00a843fe:
  pcVar1 = *(code **)(iStack_14 + 0x38);
  param_3 = uVar5;
  FUN_00d88580(uStack_18);
  (*pcVar1)(param_3);
  FUN_00d88a30();
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 21543 ; VA 0x00a84440 ; FUN_00a84440 */

void FUN_00a84440(uint param_1)

{
  char cVar1;
  uint *puVar2;
  undefined4 uVar3;
  uint uVar4;
  char *pcVar5;
  uint uVar6;
  uint *puVar7;
  undefined4 in_stack_00000024;
  char *in_stack_00000028;
  undefined auStack_84 [88];
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4a48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  pcVar5 = in_stack_00000028;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(in_stack_00000028,(int)pcVar5 - (int)(in_stack_00000028 + 1));
  uStack_8._0_1_ = 1;
  FUN_00a837c0(auStack_84,auStack_2c);
  uStack_8._0_1_ = 3;
  if (0xf < uStack_18) {
    uVar6 = uStack_18 + 1;
    uVar4 = auStack_2c[0];
    if (0xfff < uVar6) {
      uVar4 = *(uint *)(auStack_2c[0] - 4);
      uVar6 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar6);
  }
  if (param_1 == 0) {
    uVar3 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar3);
  }
  (**(code **)((param_1 & 0xfffffffe) + 4))(&stack0x0000000c,auStack_84);
  FUN_00a87870(&stack0x00000028,in_stack_00000024);
  pcVar5 = in_stack_00000028;
  if (in_stack_00000028 != (char *)0x0) {
    puVar2 = *(uint **)(in_stack_00000028 + 0x2c);
    for (puVar7 = *(uint **)(in_stack_00000028 + 0x28); puVar7 != puVar2; puVar7 = puVar7 + 8) {
      if (*puVar7 == 0) {
        uVar3 = FUN_0054fda0();
        uStack_8 = CONCAT31(uStack_8._1_3_,5);
                    /* WARNING: Subroutine does not return */
        FUN_0054e5e0(uVar3);
      }
      (**(code **)((*puVar7 & 0xfffffffe) + 4))(puVar7 + 2,auStack_84);
    }
    FUN_00a83700(&stack0x00000028,pcVar5);
  }
  FUN_0096d5e0();
  uStack_8 = 6;
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_1 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21544 ; VA 0x00a845d0 ; FUN_00a845d0 */

void FUN_00a845d0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined8 uVar5;
  int in_stack_00000014;
  uint in_stack_00000018;
  int *in_stack_00000020;
  uint in_stack_00000024;
  uint in_stack_00000044;
  undefined auStack_16c [4];
  undefined4 uStack_168;
  undefined4 *puStack_164;
  undefined auStack_160 [16];
  undefined4 uStack_150;
  undefined *puStack_14c;
  undefined *puStack_148;
  code *pcStack_144;
  undefined4 uStack_140;
  undefined auStack_13c [4];
  undefined4 uStack_138;
  int *piStack_134;
  undefined4 uStack_130;
  int *piStack_12c;
  undefined auStack_128 [4];
  undefined4 uStack_124;
  undefined auStack_120 [16];
  undefined4 uStack_110;
  undefined4 *puStack_10c;
  undefined auStack_108 [4];
  undefined4 uStack_104;
  undefined4 *puStack_100;
  undefined4 uStack_ec;
  undefined auStack_e8 [12];
  undefined1 *puStack_dc;
  undefined4 uStack_d8;
  undefined8 uStack_d4;
  undefined4 uStack_bc;
  int *piStack_b8;
  undefined4 uStack_b0;
  char *pcStack_ac;
  undefined4 *puStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  char *pcStack_9c;
  undefined8 uStack_98;
  undefined4 *puStack_90;
  undefined auStack_84 [32];
  undefined auStack_64 [24];
  undefined8 uStack_4c;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  int *piStack_34;
  undefined *puStack_30;
  undefined *puStack_2c;
  undefined *puStack_28;
  undefined *puStack_24;
  undefined8 uStack_20;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4af8;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  uStack_98._4_4_ = (char *)0xa845ff;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_008f7870();
  if (((DAT_01eeaa4c == '\0') && (iVar2 != 0)) && (*(int *)(iVar2 + 0x4a0) == 1)) {
    puStack_90 = (undefined4 *)0x6;
    uStack_98._4_4_ =
         "Calling Chat:FilterStringAsync or Chat:FilterStringForBroadcast from LocalScripts is deprecated and will be disabled in the future. Text filtering should be done from server-side Scripts. For more info see: https://devforum.roblox.com/t/deprecating-text-filtering-from-localscripts/46403"
    ;
    uStack_98._0_4_ = (undefined *)0x2;
    DAT_01eeaa4c = '\x01';
    pcStack_9c = (char *)0xa8462d;
    FUN_0086edd0();
  }
  puStack_90 = (undefined4 *)&stack0x0000001c;
  uStack_98._4_4_ = (char *)&iStack_38;
  uStack_98._0_4_ = (undefined *)0xa8463d;
  FUN_00562c90();
  uStack_8._0_1_ = 4;
  if (iStack_38 == 0) {
    puStack_a8 = (undefined4 *)0x3b;
    pcStack_ac = "ChatService:FilterString must be called with a valid player";
LAB_00a849d8:
    uStack_98._4_4_ = (char *)0x0;
    puStack_90 = (undefined4 *)0xf;
    uStack_a4 = uStack_a4 & 0xffffff00;
    uStack_b0 = 0xa849ee;
    FUN_005542c0();
  }
  else {
    if (in_stack_00000014 != 0) {
      if (DAT_01eea9ad != 0) {
        puVar4 = &param_1;
        if (0xf < in_stack_00000018) {
          puVar4 = param_1;
        }
        puStack_90 = (undefined4 *)0xa846aa;
        uStack_98 = FUN_00928340();
        uStack_a0 = (uint)DAT_01eea9ad;
        pcStack_9c = "FilterStringForBroadcast() %lld \"%s\"";
        uStack_a4 = 0xa846bf;
        puStack_90 = puVar4;
        FUN_01677520();
      }
      puStack_90 = (undefined4 *)uStack_14;
      uStack_98._4_4_ = (char *)0xa846ca;
      iVar2 = FUN_008f7870();
      if ((iVar2 != 0) && (*(int *)(iVar2 + 0x4a0) != 3)) {
        puStack_90 = (undefined4 *)0x0;
        uStack_20._0_4_ = auStack_108;
        puStack_24 = auStack_108;
        if (*(int *)(iVar2 + 0x4a0) == 1) {
          uStack_18 = CONCAT31(uStack_18._1_3_,DAT_01eeaa44);
          puStack_10c = &stack0x00000044;
          uStack_110 = 0xa8470d;
          FUN_0054f510();
          uStack_20._4_4_ = (undefined4 *)auStack_128;
          uStack_8._0_1_ = 5;
          piStack_12c = (int *)&stack0x00000024;
          uStack_130 = 0xa84722;
          FUN_0054f510();
          puStack_24 = (undefined *)&uStack_130;
          piStack_134 = &iStack_38;
          uStack_138 = 0xa84733;
          FUN_00557fc0();
          piStack_134 = (int *)uStack_18;
          uStack_8._0_1_ = 7;
          pcStack_144 = (code *)auStack_13c;
          uStack_140 = uStack_14;
          puStack_148 = (undefined *)0xa84748;
          FUN_0060dcd0();
          uStack_8._0_1_ = 4;
          uStack_140 = 0;
          pcStack_144 = FUN_00a84b00;
          puStack_14c = (undefined *)0xa8475c;
          puStack_148 = auStack_e8;
          FUN_00a764e0();
          uStack_ec = 0xa84767;
          FUN_00a73a50();
          uStack_8._0_1_ = 8;
          puStack_90 = (undefined4 *)0xa84773;
          uVar5 = FUN_00928340();
          puStack_90 = &param_1;
          uStack_98._4_4_ = (char *)0xa84783;
          FUN_0054ef60();
          puStack_90 = (undefined4 *)auStack_64;
          uStack_98._4_4_ = (char *)&puStack_24;
          uStack_8._0_1_ = 9;
          uStack_98._0_4_ = (undefined *)0xa847a0;
          uStack_4c = uVar5;
          piVar3 = (int *)FUN_00a87870();
          if (*piVar3 == 0) {
            uStack_44 = 0;
            uStack_40 = 0;
            uStack_3c = 0;
            puStack_90 = &uStack_44;
            uStack_8._0_1_ = 10;
            uStack_98._4_4_ = auStack_64;
            uStack_98._0_4_ = (undefined *)0xa847d2;
            FUN_00a7d4b0();
            uStack_98._4_4_ = (char *)0xa847da;
            FUN_00a7d230();
            uStack_8._0_1_ = 0xb;
            puStack_90 = (undefined4 *)0xa847e6;
            FUN_00a7ed40();
            puStack_90 = (undefined4 *)auStack_64;
            uStack_8._0_1_ = 9;
            uStack_98._4_4_ = (char *)0xa847f6;
            FUN_00a7d4b0();
            puStack_90 = (undefined4 *)auStack_84;
            uStack_98._4_4_ = (char *)0xa84802;
            FUN_00a8b190();
            puStack_a8 = &param_1;
            pcStack_ac = (char *)0xa84810;
            FUN_0054ef60();
            pcStack_ac = (char *)0x0;
            puStack_a8 = (undefined4 *)0x0;
            piStack_b8 = &iStack_38;
            uStack_bc = 0xa84830;
            FUN_00557fc0();
            piStack_b8 = (int *)uStack_14;
            uStack_bc = 0xa8483b;
            FUN_00a8b940();
            puStack_90 = (undefined4 *)0xa84843;
            FUN_005507b0();
          }
          else {
            puStack_90 = (undefined4 *)auStack_64;
            uStack_98._4_4_ = (char *)0xa84854;
            FUN_00a7d4b0();
            puStack_90 = (undefined4 *)auStack_84;
            uStack_98._4_4_ = (char *)0xa84860;
            FUN_00a8b190();
            puStack_90 = (undefined4 *)0xa84868;
            FUN_005507b0();
          }
        }
        else {
          uStack_18 = CONCAT31(uStack_18._1_3_,DAT_01eeaa44);
          puStack_10c = &stack0x00000044;
          uStack_110 = 0xa84883;
          FUN_0054f510();
          uStack_20._0_4_ = auStack_128;
          uStack_8._0_1_ = 0xc;
          piStack_12c = (int *)&stack0x00000024;
          uStack_130 = 0xa84898;
          FUN_0054f510();
          uStack_20._4_4_ = &uStack_130;
          piStack_134 = &iStack_38;
          uStack_138 = 0xa848a9;
          FUN_00557fc0();
          piStack_134 = (int *)uStack_18;
          uStack_8._0_1_ = 0xe;
          pcStack_144 = (code *)auStack_13c;
          uStack_140 = uStack_14;
          puStack_148 = (undefined *)0xa848be;
          FUN_0060dcd0();
          uStack_8._0_1_ = 4;
          uStack_140 = 0;
          pcStack_144 = FUN_00a84b00;
          puStack_14c = (undefined *)0xa848d2;
          puStack_148 = auStack_e8;
          FUN_00a764e0();
          uStack_ec = 0xa848dd;
          FUN_00a73a50();
          uStack_8._0_1_ = 0xf;
          uStack_18 = CONCAT31(uStack_18._1_3_,DAT_01eeaa44);
          puStack_90 = (undefined4 *)0xa848f3;
          uStack_20 = FUN_00928340();
          puStack_24 = (undefined *)&pcStack_ac;
          puStack_100 = &stack0x00000024;
          uStack_b0 = 0;
          puStack_dc = &DAT_018bc9b8;
          uStack_104 = 0xa8491b;
          FUN_0054f510();
          uStack_104 = 0xa84921;
          puStack_100 = &uStack_d8;
          FUN_00a75b20();
          puStack_dc = (undefined1 *)0xa8492b;
          FUN_00a73650();
          piStack_12c = &iStack_38;
          uStack_d4._4_4_ = 0;
          puStack_28 = auStack_128;
          uStack_130 = 0xa84948;
          FUN_00557fc0();
          puStack_2c = (undefined *)&puStack_148;
          uStack_8._0_1_ = 0x11;
          puStack_14c = auStack_84;
          uStack_150 = 0xa8495d;
          FUN_0054f510();
          puStack_30 = auStack_160;
          uStack_8._0_1_ = 0x12;
          puStack_164 = &param_1;
          uStack_168 = 0xa84972;
          FUN_0054ef60();
          puStack_164 = (undefined4 *)uStack_18;
          uStack_8._0_1_ = 0x13;
          FUN_0060dcd0(auStack_16c,uStack_14);
          uStack_8._0_1_ = 0x10;
          FUN_00a76820(auStack_120,FUN_00a87080,0);
          uStack_124 = 0xa849a5;
          FUN_00a73c10();
          uStack_8._0_1_ = 0xf;
          uStack_d8 = 0xa849b7;
          uStack_d4 = uStack_20;
          FUN_00a7f610();
        }
        puStack_90 = (undefined4 *)0xa849bf;
        FUN_00550990();
        puStack_90 = (undefined4 *)0xa849c7;
        FUN_00550b30();
        goto LAB_00a84a1c;
      }
      puStack_a8 = (undefined4 *)0x1f;
      pcStack_ac = "Invalid datamodel configuration";
      goto LAB_00a849d8;
    }
    puStack_a8 = (undefined4 *)0x0;
    uStack_98._4_4_ = (char *)0x0;
    puStack_90 = (undefined4 *)0xf;
    pcStack_ac = "";
    uStack_a4 = uStack_a4 & 0xffffff00;
    uStack_b0 = 0xa84687;
    FUN_005542c0();
  }
  puStack_a8 = (undefined4 *)0xa849f6;
  FUN_005e65e0();
  uStack_4c = CONCAT44(uStack_4c._4_4_,(undefined4)uStack_4c);
  uStack_20 = CONCAT44(uStack_20._4_4_,(undefined *)uStack_20);
  uStack_d4 = CONCAT44(uStack_d4._4_4_,(undefined4)uStack_d4);
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_34[1] + -1;
    piStack_34[1] = iVar2;
    UNLOCK();
    uStack_4c = CONCAT44(uStack_4c._4_4_,(undefined4)uStack_4c);
    uStack_20 = CONCAT44(uStack_20._4_4_,(undefined *)uStack_20);
    uStack_d4 = CONCAT44(uStack_d4._4_4_,(undefined4)uStack_d4);
    if (iVar2 == 0) {
      puStack_90 = (undefined4 *)0xa84a0c;
      (**(code **)*piStack_34)();
      LOCK();
      iVar2 = piStack_34[2] + -1;
      piStack_34[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_90 = (undefined4 *)0xa84a1c;
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
LAB_00a84a1c:
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < in_stack_00000018) {
    puStack_90 = (undefined4 *)(in_stack_00000018 + 1);
    puVar4 = param_1;
    if (0xfff < puStack_90) {
      puVar4 = (undefined4 *)param_1[-1];
      puStack_90 = (undefined4 *)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
        puStack_90 = (undefined4 *)&UNK_00a84af4;
        FUN_017167a3();
      }
    }
    uStack_98._0_4_ = (undefined *)0xa84a51;
    uStack_98._4_4_ = (char *)puVar4;
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = (undefined4 *)((uint)param_1 & 0xffffff00);
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000020[1] + -1;
    in_stack_00000020[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_90 = (undefined4 *)0xa84a7c;
      (**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_90 = (undefined4 *)0xa84a8b;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
  if (in_stack_00000024 != 0) {
    if (((in_stack_00000024 & 1) == 0) &&
       (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
      uStack_98._0_4_ = &stack0x0000002c;
      puStack_90 = (undefined4 *)0x2;
      pcStack_9c = (char *)0xa84aac;
      uStack_98._4_4_ = (undefined *)uStack_98;
      (**(code **)(in_stack_00000024 & 0xfffffffe))();
    }
    in_stack_00000024 = 0;
  }
  uStack_8 = 0x15;
  if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
     (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
    uStack_98._0_4_ = &stack0x0000004c;
    puStack_90 = (undefined4 *)0x2;
    pcStack_9c = (char *)0xa84ada;
    uStack_98._4_4_ = (undefined *)uStack_98;
    (**(code **)(in_stack_00000044 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21545 ; VA 0x00a84b00 ; FUN_00a84b00 */

void FUN_00a84b00(int param_1,int param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  undefined8 uVar3;
  uint in_stack_00000030;
  undefined4 in_stack_ffffffd0;
  uint in_stack_ffffffd4;
  char *in_stack_ffffffd8;
  undefined4 in_stack_ffffffdc;
  undefined4 in_stack_ffffffe0;
  int *in_stack_ffffffe4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar3 = CONCAT44(in_stack_ffffffe0,in_stack_ffffffdc);
  puStack_c = &LAB_017e4b28;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (*(char *)(param_1 + 8) == '\0') {
    piVar1 = (int *)(param_1 + 0x24);
    ExceptionList = &pvStack_10;
    if (DAT_01eea9ad != 0) {
      in_stack_ffffffe4 = piVar1;
      if (0xf < *(uint *)(param_1 + 0x38)) {
        in_stack_ffffffe4 = (int *)*piVar1;
      }
      if (param_2 == 0) {
        uVar3 = 0x8000000000000000;
        ExceptionList = &pvStack_10;
      }
      else {
        ExceptionList = &pvStack_10;
        uVar3 = FUN_00928340();
      }
      in_stack_ffffffd4 = (uint)DAT_01eea9ad;
      in_stack_ffffffd8 = "FilterStringForBroadcast:Success %lld \"%s\"";
      in_stack_ffffffd0 = 0xa84b6f;
      FUN_01677520(in_stack_ffffffd4,"FilterStringForBroadcast:Success %lld \"%s\"",uVar3,
                   in_stack_ffffffe4);
    }
    FUN_0054ef60(piVar1);
  }
  else {
    piVar1 = (int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    if (DAT_01eea9ad != 0) {
      in_stack_ffffffe4 = piVar1;
      if (0xf < *(uint *)(param_1 + 0x20)) {
        in_stack_ffffffe4 = (int *)*piVar1;
      }
      if (param_2 == 0) {
        uVar3 = 0x8000000000000000;
        ExceptionList = &pvStack_10;
      }
      else {
        ExceptionList = &pvStack_10;
        uVar3 = FUN_00928340();
      }
      in_stack_ffffffd4 = (uint)DAT_01eea9ad;
      in_stack_ffffffd8 = "FilterStringForBroadcast:Error %lld \"%s\"";
      in_stack_ffffffd0 = 0xa84bc1;
      FUN_01677520(in_stack_ffffffd4,"FilterStringForBroadcast:Error %lld \"%s\"",uVar3,
                   in_stack_ffffffe4);
    }
    FUN_0054ef60(piVar1);
  }
  FUN_005e65e0(in_stack_ffffffd0,in_stack_ffffffd4,in_stack_ffffffd8,uVar3,in_stack_ffffffe4);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_4 & 0xfffffffe))(&stack0x00000018,&stack0x00000018,2);
  }
  uStack_8 = 4;
  if (((in_stack_00000030 != 0) && ((in_stack_00000030 & 1) == 0)) &&
     (*(code **)(in_stack_00000030 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000030 & 0xfffffffe))(&stack0x00000038,&stack0x00000038,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21546 ; VA 0x00a84c70 ; FUN_00a84c70 */

void FUN_00a84c70(undefined4 *param_1)

{
  int *piVar1;
  undefined8 uVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  undefined4 *puVar6;
  int in_stack_00000014;
  uint in_stack_00000018;
  int *in_stack_00000020;
  uint in_stack_00000024;
  uint in_stack_00000044;
  undefined auStack_14c [4];
  undefined4 uStack_148;
  undefined4 *puStack_144;
  undefined auStack_140 [16];
  undefined4 uStack_130;
  uint *puStack_12c;
  undefined auStack_128 [16];
  undefined4 uStack_118;
  undefined *puStack_114;
  code *pcStack_110;
  undefined4 uStack_10c;
  undefined4 *puStack_108;
  int *piStack_104;
  undefined auStack_100 [24];
  undefined4 uStack_e8;
  undefined4 *puStack_e4;
  undefined4 *apuStack_e0 [7];
  undefined4 uStack_c4;
  undefined auStack_c0 [4];
  undefined1 *puStack_bc;
  undefined4 uStack_b8;
  undefined8 uStack_b4;
  undefined4 uStack_90;
  char *pcStack_8c;
  undefined4 uStack_88;
  undefined *puStack_84;
  code **ppcStack_80;
  char *pcStack_7c;
  undefined8 uStack_78;
  undefined4 *puStack_70;
  uint auStack_64 [2];
  undefined4 auStack_5c [6];
  code *apcStack_44 [2];
  undefined4 *puStack_3c;
  int *piStack_38;
  undefined *puStack_34;
  undefined *puStack_30;
  undefined *puStack_2c;
  undefined *puStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4b98;
  pvStack_10 = ExceptionList;
  puStack_70 = (undefined4 *)0x6;
  uStack_78._4_4_ =
       "Chat:FilterStringForPlayer is deprecated. Move to FilterStringAsync or FilterStringForBroadcast depending on your use case."
  ;
  uStack_78._0_4_ = (undefined4 *)0x3;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  pcStack_7c = (char *)0xa84ca7;
  ExceptionList = &pvStack_10;
  FUN_0086edd0();
  ppcStack_80 = (code **)0xa84cad;
  iVar5 = FUN_008f7870();
  apcStack_44[0] = FUN_00a8c570;
  piStack_38 = *(int **)(iVar5 + 0x43c);
  puStack_3c = (undefined4 *)(*piStack_38 - (int)piStack_38);
  piStack_38 = (int *)(piStack_38[1] - (int)piStack_38);
  ppcStack_80 = apcStack_44;
  puStack_84 = &DAT_01eeaa50;
  uStack_88 = 0xa84cd7;
  FUN_00942b20();
  uStack_88 = 1;
  uStack_90 = 0xa84cdf;
  cVar4 = FUN_0098c5a0();
  if (cVar4 == '\0') {
    uStack_88 = 0x44;
    uStack_78._4_4_ = (char *)0x0;
    puStack_70 = (undefined4 *)0xf;
    pcStack_8c = "ChatService:FilterString called on a client, only works from server.";
    puStack_84 = (undefined *)((uint)puStack_84 & 0xffffff00);
    uStack_90 = 0xa84d0a;
    FUN_005542c0();
    uStack_88 = 0xa84d12;
    FUN_005e65e0();
    uVar2 = CONCAT44(uStack_78._4_4_,(undefined4 *)uStack_78);
    uStack_24 = CONCAT44(uStack_24._4_4_,(undefined4 **)uStack_24);
    uStack_b4 = CONCAT44(uStack_b4._4_4_,(undefined4)uStack_b4);
  }
  else {
    puStack_70 = (undefined4 *)&stack0x0000001c;
    uStack_78._4_4_ = (char *)&puStack_3c;
    uStack_78._0_4_ = (undefined4 *)0xa84d24;
    FUN_00562c90();
    uStack_8._0_1_ = 4;
    if (puStack_3c == (undefined4 *)0x0) {
      uStack_88 = 0x3e;
      uStack_78._4_4_ = (char *)puStack_3c;
      puStack_70 = (undefined4 *)0xf;
      pcStack_8c = "ChatService:FilterString called without a valid Player object.";
      puStack_84 = (undefined *)((uint)puStack_84._1_3_ << 8);
      uStack_90 = 0xa84d50;
      FUN_005542c0();
    }
    else {
      if (in_stack_00000014 != 0) {
        if (DAT_01eea9ad != 0) {
          puVar6 = &param_1;
          if (0xf < in_stack_00000018) {
            puVar6 = param_1;
          }
          puStack_70 = (undefined4 *)0xa84dd8;
          uStack_78 = FUN_00928340();
          ppcStack_80 = (code **)(uint)DAT_01eea9ad;
          pcStack_7c = "FilterStringForPlayer() %lld \"%s\"";
          puStack_84 = (undefined *)0xa84ded;
          puStack_70 = puVar6;
          FUN_01677520();
        }
        puVar6 = puStack_3c;
        puStack_70 = (undefined4 *)0x0;
        uStack_14 = CONCAT31(uStack_14._1_3_,DAT_01eeaa44);
        puStack_e4 = &stack0x00000044;
        uStack_24._0_4_ = apuStack_e0;
        uStack_e8 = 0xa84e13;
        FUN_0054f510();
        uStack_8._0_1_ = 5;
        piStack_104 = (int *)&stack0x00000024;
        puStack_108 = (undefined4 *)0xa84e25;
        FUN_0054f510();
        if (piStack_38 != (int *)0x0) {
          LOCK();
          piStack_38[1] = piStack_38[1] + 1;
          UNLOCK();
        }
        uStack_10c = uStack_14;
        puStack_108 = puVar6;
        pcStack_110 = FUN_00a85da0;
        piStack_104 = piStack_38;
        uStack_8._0_1_ = 4;
        uStack_118 = 0xa84e59;
        puStack_114 = auStack_c0;
        FUN_00a75c40();
        uStack_c4 = 0xa84e64;
        FUN_00a73810();
        uStack_8._0_1_ = 6;
        uStack_14 = CONCAT31(uStack_14._1_3_,DAT_01eeaa44);
        puStack_70 = (undefined4 *)0xa84e77;
        uStack_24 = FUN_00928340();
        puStack_28 = (undefined *)&pcStack_8c;
        apuStack_e0[0] = &stack0x00000024;
        uStack_90 = 0;
        puStack_bc = &DAT_018bc9b8;
        puStack_e4 = (undefined4 *)0xa84e9f;
        FUN_0054f510();
        puStack_e4 = (undefined4 *)0xa84ea5;
        apuStack_e0[0] = &uStack_b8;
        FUN_00a75b20();
        puStack_bc = (undefined1 *)0xa84eaf;
        FUN_00a73650();
        uStack_b4._4_4_ = 0;
        puStack_1c = auStack_100;
        puStack_2c = (undefined *)&puStack_108;
        if (piStack_38 != (int *)0x0) {
          LOCK();
          piStack_38[1] = piStack_38[1] + 1;
          UNLOCK();
        }
        puStack_108 = puStack_3c;
        piStack_104 = piStack_38;
        puStack_30 = auStack_128;
        uStack_8._0_1_ = 8;
        puStack_12c = auStack_64;
        uStack_130 = 0xa84ef9;
        FUN_0054f510();
        puStack_34 = auStack_140;
        uStack_8._0_1_ = 9;
        puStack_144 = &param_1;
        uStack_148 = 0xa84f0e;
        FUN_0054ef60();
        puStack_144 = (undefined4 *)uStack_14;
        uStack_8._0_1_ = 10;
        FUN_0060dcd0(auStack_14c,uStack_18);
        uStack_8._0_1_ = 7;
        FUN_00a76820(puStack_1c,FUN_00a87080,0);
        piStack_104 = (int *)0xa84f44;
        FUN_00a73c10();
        uStack_8._0_1_ = 6;
        uStack_b8 = 0xa84f55;
        uStack_b4 = uStack_24;
        FUN_00a7f610();
        uStack_8._0_1_ = 0xb;
        if (auStack_64[0] != 0) {
          if (((auStack_64[0] & 1) == 0) && (*(code **)(auStack_64[0] & 0xfffffffe) != (code *)0x0))
          {
            uStack_78._0_4_ = auStack_5c;
            puStack_70 = (undefined4 *)0x2;
            pcStack_7c = (char *)0xa84f76;
            uStack_78._4_4_ = (char *)(undefined4 *)uStack_78;
            (**(code **)(auStack_64[0] & 0xfffffffe))();
          }
          auStack_64[0] = 0;
        }
        puStack_70 = (undefined4 *)0xa84f88;
        FUN_00550b30();
        uVar2 = uStack_78;
        goto LAB_00a84f8b;
      }
      uStack_88 = 0;
      uStack_78._4_4_ = (char *)0x0;
      puStack_70 = (undefined4 *)0xf;
      pcStack_8c = "";
      puStack_84 = (undefined *)((uint)puStack_84._1_3_ << 8);
      uStack_90 = 0xa84d7d;
      FUN_005542c0();
    }
    uStack_88 = 0xa84d85;
    FUN_005e65e0();
    piVar3 = piStack_38;
    uVar2 = CONCAT44(uStack_78._4_4_,(undefined4 *)uStack_78);
    uStack_24 = CONCAT44(uStack_24._4_4_,(undefined4 **)uStack_24);
    uStack_b4 = CONCAT44(uStack_b4._4_4_,(undefined4)uStack_b4);
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_38[1] + -1;
      piStack_38[1] = iVar5;
      UNLOCK();
      uVar2 = CONCAT44(uStack_78._4_4_,(undefined4 *)uStack_78);
      uStack_24 = CONCAT44(uStack_24._4_4_,(undefined4 **)uStack_24);
      uStack_b4 = CONCAT44(uStack_b4._4_4_,(undefined4)uStack_b4);
      if (iVar5 == 0) {
        puStack_70 = (undefined4 *)0xa84da3;
        (**(code **)*piStack_38)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        uVar2 = CONCAT44(uStack_78._4_4_,(undefined4 *)uStack_78);
        if (iVar5 == 0) {
          puStack_70 = (undefined4 *)0xa84db7;
          (**(code **)(*piVar3 + 4))();
          uVar2 = CONCAT44(uStack_78._4_4_,(undefined4 *)uStack_78);
        }
      }
    }
  }
LAB_00a84f8b:
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < in_stack_00000018) {
    puStack_70 = (undefined4 *)(in_stack_00000018 + 1);
    uStack_78._4_4_ = (char *)param_1;
    if (0xfff < puStack_70) {
      uStack_78._4_4_ = (char *)param_1[-1];
      puStack_70 = (undefined4 *)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_1 + (-4 - (int)uStack_78._4_4_))) {
                    /* WARNING: Subroutine does not return */
        puStack_70 = (undefined4 *)&UNK_00a85063;
        uStack_78 = uVar2;
        FUN_017167a3();
      }
    }
    uStack_78._0_4_ = (undefined4 *)0xa84fc0;
    FUN_01674ea0();
    uVar2 = CONCAT44(uStack_78._4_4_,(undefined4 *)uStack_78);
  }
  piVar3 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = (undefined4 *)((uint)param_1 & 0xffffff00);
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    iVar5 = in_stack_00000020[1] + -1;
    in_stack_00000020[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      puStack_70 = (undefined4 *)0xa84feb;
      uStack_78 = uVar2;
      (**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        puStack_70 = (undefined4 *)0xa84ffa;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  if (in_stack_00000024 != 0) {
    if (((in_stack_00000024 & 1) == 0) &&
       (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
      uStack_78._0_4_ = (undefined4 *)&stack0x0000002c;
      puStack_70 = (undefined4 *)0x2;
      pcStack_7c = (char *)0xa8501b;
      uStack_78._4_4_ = (char *)(undefined4 *)uStack_78;
      (**(code **)(in_stack_00000024 & 0xfffffffe))();
    }
    in_stack_00000024 = 0;
  }
  uStack_8 = 0xd;
  if (((in_stack_00000044 != 0) && ((in_stack_00000044 & 1) == 0)) &&
     (*(code **)(in_stack_00000044 & 0xfffffffe) != (code *)0x0)) {
    uStack_78._0_4_ = (undefined4 *)&stack0x0000004c;
    puStack_70 = (undefined4 *)0x2;
    pcStack_7c = (char *)0xa85049;
    uStack_78._4_4_ = (char *)(undefined4 *)uStack_78;
    (**(code **)(in_stack_00000044 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21547 ; VA 0x00a85070 ; FUN_00a85070 */

void __thiscall FUN_00a85070(int *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined uVar3;
  char cVar4;
  int iVar5;
  int *piVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  int in_stack_00000014;
  uint in_stack_00000018;
  int *in_stack_00000020;
  int *in_stack_00000028;
  uint in_stack_0000002c;
  uint in_stack_0000004c;
  undefined auStack_424 [4];
  undefined4 uStack_420;
  int *piStack_41c;
  undefined4 uStack_418;
  int *piStack_414;
  undefined4 uStack_410;
  undefined4 *puStack_40c;
  undefined auStack_408 [24];
  undefined4 uStack_3f0;
  undefined4 *puStack_3ec;
  undefined4 uStack_3e8;
  undefined4 *puStack_3e4;
  code *pcStack_3e0;
  int *piStack_3dc;
  undefined auStack_3d8 [4];
  undefined4 uStack_3d4;
  undefined4 *puStack_3d0;
  undefined4 uStack_3cc;
  undefined auStack_3c8 [12];
  undefined4 uStack_3bc;
  int *piStack_3b8;
  undefined4 uStack_3b4;
  int *piStack_3b0;
  undefined4 *puStack_3ac;
  undefined4 *puStack_3a8;
  undefined auStack_3a4 [12];
  undefined4 uStack_398;
  int *piStack_394;
  int *piStack_390;
  undefined4 uStack_38c;
  undefined ***pppuStack_388;
  char *pcStack_384;
  undefined4 *puStack_380;
  char *pcStack_37c;
  undefined8 uStack_378;
  undefined8 uStack_370;
  undefined ***pppuStack_368;
  undefined4 uStack_35c;
  undefined4 uStack_358;
  undefined auStack_354 [112];
  undefined4 uStack_2e4;
  undefined4 uStack_2e0;
  undefined auStack_2dc [112];
  undefined4 uStack_26c;
  undefined4 uStack_268;
  undefined auStack_264 [112];
  undefined4 uStack_1f4;
  undefined4 uStack_1f0;
  undefined auStack_1ec [112];
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined auStack_174 [112];
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined auStack_fc [112];
  undefined auStack_8c [32];
  undefined **appuStack_6c [2];
  undefined4 *puStack_64;
  undefined8 uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined *puStack_40;
  undefined *puStack_3c;
  undefined *puStack_38;
  int iStack_34;
  int *piStack_30;
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined *puStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4cb4;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  uStack_370._4_4_ = (char *)0xa850a2;
  ExceptionList = &pvStack_10;
  pppuStack_368 = (undefined ***)param_1;
  piStack_2c = param_1;
  iVar5 = FUN_008f7870();
  if (((DAT_01eeaa4c == '\0') && (iVar5 != 0)) && (*(int *)(iVar5 + 0x4a0) == 1)) {
    pppuStack_368 = (undefined ***)0x6;
    uStack_370._4_4_ =
         "Calling Chat:FilterStringAsync or Chat:FilterStringForBroadcast from LocalScripts is deprecated and will be disabled in the future. Text filtering should be done from server-side Scripts. For more info see: https://devforum.roblox.com/t/deprecating-text-filtering-from-localscripts/46403"
    ;
    uStack_370._0_4_ = (undefined *)0x2;
    DAT_01eeaa4c = '\x01';
    uStack_378._4_4_ = (int *)0xa850d0;
    FUN_0086edd0();
  }
  pppuStack_368 = (undefined ***)&stack0x0000001c;
  uStack_370._4_4_ = (char *)&iStack_28;
  uStack_370._0_4_ = (undefined *)0xa850e0;
  FUN_00562c90();
  uStack_370._0_4_ = &stack0x00000024;
  uStack_8._0_1_ = 5;
  uStack_378._4_4_ = &iStack_34;
  uStack_378._0_4_ = 0xa850f1;
  FUN_00562c90();
  uStack_8._0_1_ = 6;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 6;
  if ((iStack_28 == 0) || (iStack_34 == 0)) {
    puStack_380 = (undefined4 *)0x3e;
    pcStack_384 = "ChatService:FilterString must be called with two valid players";
    uStack_8._0_1_ = uVar3;
LAB_00a8565a:
    uStack_370._4_4_ = (char *)0x0;
    pppuStack_368 = (undefined ***)0xf;
    pcStack_37c = (char *)((uint)pcStack_37c & 0xffffff00);
    pppuStack_388 = (undefined ***)0xa85670;
    FUN_005542c0();
  }
  else {
    if (in_stack_00000014 != 0) {
      if (DAT_01eea9ad != 0) {
        puStack_18 = &param_2;
        if (0xf < in_stack_00000018) {
          puStack_18 = param_2;
        }
        pppuStack_368 = (undefined ***)0xa8515c;
        uVar7 = FUN_00928340();
        pppuStack_368 = (undefined ***)0xa85168;
        uStack_378 = FUN_00928340();
        pppuStack_368 = (undefined ***)puStack_18;
        puStack_380 = (undefined4 *)(uint)DAT_01eea9ad;
        pcStack_37c = "FilterStringAsync() %lld %lld \"%s\"";
        pcStack_384 = (char *)0xa85181;
        uStack_370 = uVar7;
        FUN_01677520();
        param_1 = piStack_2c;
      }
      uStack_370._4_4_ = (char *)0xa85190;
      pppuStack_368 = (undefined ***)param_1;
      iVar5 = FUN_008f7870();
      if ((iVar5 != 0) && (*(int *)(iVar5 + 0x4a0) != 3)) {
        puStack_18 = (undefined4 *)CONCAT31(puStack_18._1_3_,DAT_01eeaa44);
        if (*(int *)(iVar5 + 0x4a0) == 1) {
          pppuStack_368 = (undefined ***)0x0;
          puStack_38 = (undefined *)&uStack_3e8;
          uStack_3f0 = 0xa851d3;
          puStack_3ec = &stack0x0000004c;
          FUN_0054f510();
          puStack_40 = auStack_408;
          uStack_8._0_1_ = 7;
          puStack_40c = &stack0x0000002c;
          uStack_410 = 0xa851e8;
          FUN_0054f510();
          puStack_3c = (undefined *)&uStack_410;
          piStack_414 = &iStack_34;
          uStack_418 = 0xa851f9;
          FUN_00557fc0();
          puStack_20 = (undefined *)&uStack_418;
          piStack_41c = &iStack_28;
          uStack_420 = 0xa8520a;
          FUN_00557fc0();
          piStack_41c = puStack_18;
          uStack_8._0_1_ = 10;
          FUN_0060dcd0(auStack_424,param_1);
          uStack_8._0_1_ = 6;
          FUN_00a76270(auStack_3c8,FUN_00a85c40,0);
          uStack_3cc = 0xa8523f;
          FUN_00a74000();
          uStack_8._0_1_ = 0xb;
          pppuStack_368 = (undefined ***)0xa8524b;
          uVar7 = FUN_00928340();
          pppuStack_368 = (undefined ***)&param_2;
          uStack_370._4_4_ = (char *)0xa8525b;
          FUN_0054ef60();
          piVar2 = piStack_2c;
          pppuStack_368 = appuStack_6c;
          uStack_370._4_4_ = (char *)&puStack_20;
          uStack_8._0_1_ = 0xc;
          uStack_370._0_4_ = (undefined *)0xa85278;
          uStack_54 = uVar7;
          piVar6 = (int *)FUN_00a87870();
          if (*piVar6 == 0) {
            uStack_4c = 0;
            uStack_48 = 0;
            uStack_44 = 0;
            pppuStack_368 = (undefined ***)&uStack_4c;
            uStack_8._0_1_ = 0xd;
            uStack_370._4_4_ = (char *)appuStack_6c;
            uStack_370._0_4_ = (undefined *)0xa852aa;
            FUN_00a7d4b0();
            uStack_370._4_4_ = (char *)0xa852b2;
            FUN_00a7d230();
            uStack_8._0_1_ = 0xe;
            pppuStack_368 = (undefined ***)0xa852be;
            FUN_00a7ed40();
            pppuStack_368 = appuStack_6c;
            uStack_8._0_1_ = 0xc;
            uStack_370._4_4_ = (char *)0xa852ce;
            FUN_00a7d4b0();
            pppuStack_368 = (undefined ***)auStack_8c;
            uStack_370._4_4_ = (char *)0xa852dd;
            FUN_00a8b190();
            puStack_380 = &param_2;
            pcStack_384 = (char *)0xa852eb;
            FUN_0054ef60();
            pppuStack_388 = (undefined ***)&iStack_34;
            uStack_38c = 0xa852f9;
            FUN_00557fc0();
            piStack_390 = &iStack_28;
            piStack_394 = (int *)0xa85307;
            FUN_00557fc0();
            piStack_390 = piVar2;
            piStack_394 = (int *)0xa85312;
            FUN_00a8b940();
            pppuStack_368 = (undefined ***)0xa8531a;
            FUN_005507b0();
          }
          else {
            pppuStack_368 = appuStack_6c;
            uStack_370._4_4_ = (char *)0xa85331;
            FUN_00a7d4b0();
            pppuStack_368 = (undefined ***)auStack_8c;
            uStack_370._4_4_ = (char *)0xa85340;
            FUN_00a8b190();
            pppuStack_368 = (undefined ***)0xa85348;
            FUN_005507b0();
          }
        }
        else {
          puStack_20 = (undefined *)&pcStack_384;
          uStack_38c = 0xa85367;
          pppuStack_388 = (undefined ***)&stack0x0000004c;
          FUN_0054f510();
          puStack_3c = auStack_3a4;
          uStack_8._0_1_ = 0xf;
          puStack_3a8 = &stack0x0000002c;
          puStack_3ac = (undefined4 *)0xa8537c;
          FUN_0054f510();
          puStack_40 = (undefined *)&puStack_3ac;
          piStack_3b0 = &iStack_34;
          uStack_3b4 = 0xa8538d;
          FUN_00557fc0();
          puStack_38 = (undefined *)&uStack_3b4;
          piStack_3b8 = &iStack_28;
          uStack_3bc = 0xa8539e;
          FUN_00557fc0();
          puStack_1c = &uStack_3cc;
          uStack_8._0_1_ = 0x12;
          puStack_3d0 = &param_2;
          uStack_3d4 = 0xa853b3;
          FUN_0054ef60();
          puStack_3d0 = puStack_18;
          uStack_8._0_1_ = 0x13;
          pcStack_3e0 = (code *)auStack_3d8;
          puStack_3e4 = (undefined4 *)0xa853c6;
          piStack_3dc = param_1;
          FUN_0060dcd0();
          uStack_8._0_1_ = 6;
          piStack_3dc = (int *)0x0;
          pcStack_3e0 = FUN_00a857d0;
          uStack_3e8 = 0xa853da;
          puStack_3e4 = &uStack_35c;
          FUN_00a75e00();
          uStack_2e4 = uStack_35c;
          uStack_2e0 = uStack_358;
          pppuStack_368 = (undefined ***)auStack_354;
          uStack_8._0_1_ = 0x14;
          uStack_370._4_4_ = (char *)0xa8540e;
          FUN_00a7b940();
          uStack_26c = uStack_2e4;
          uStack_268 = uStack_2e0;
          pppuStack_368 = (undefined ***)auStack_2dc;
          uStack_8._0_1_ = 0x15;
          appuStack_6c[0] = (undefined **)0x0;
          uStack_370._4_4_ = (char *)0xa85443;
          FUN_00a7b940();
          uStack_1f4 = uStack_26c;
          uStack_1f0 = uStack_268;
          pppuStack_368 = (undefined ***)auStack_264;
          uStack_8._0_1_ = 0x16;
          uStack_370._4_4_ = (char *)0xa85471;
          FUN_00a7b940();
          uStack_104 = uStack_1f4;
          uStack_100 = uStack_1f0;
          pppuStack_368 = (undefined ***)auStack_1ec;
          uStack_8._0_1_ = 0x17;
          uStack_370._4_4_ = (char *)0xa8549f;
          FUN_00a7b940();
          pppuStack_368 = (undefined ***)&uStack_104;
          uStack_8._0_1_ = 0x18;
          uStack_370._4_4_ = (char *)0xa854af;
          cVar4 = FUN_00585a40();
          if (cVar4 == '\0') {
            uStack_17c = uStack_104;
            uStack_178 = uStack_100;
            pppuStack_368 = (undefined ***)auStack_fc;
            uStack_370._4_4_ = (char *)0xa854e4;
            FUN_00a7b940();
            pppuStack_368 = (undefined ***)0x78;
            uStack_8._0_1_ = 0x19;
            uStack_370._4_4_ = (char *)0xa854ef;
            puStack_64 = (undefined4 *)FUN_01674e20();
            uStack_8._0_1_ = 0x1a;
            puStack_1c = puStack_64;
            if (puStack_64 == (undefined4 *)0x0) {
              puStack_64 = (undefined4 *)0x0;
            }
            else {
              pppuStack_368 = (undefined ***)auStack_174;
              *puStack_64 = uStack_17c;
              puStack_64[1] = uStack_178;
              uStack_370._4_4_ = (char *)0xa8551f;
              FUN_00a7b940();
            }
            pppuStack_368 = (undefined ***)0xa85531;
            FUN_00a7cd80();
            pppuStack_368 = (undefined ***)0xa8553c;
            FUN_00a7cd80();
            cStack_11 = '\x01';
          }
          else {
            pppuStack_368 = (undefined ***)0xa8554d;
            FUN_00a7cd80();
            cStack_11 = '\0';
          }
          pppuStack_368 = (undefined ***)0xa8555c;
          FUN_00a7cd80();
          appuStack_6c[0] = &PTR_FUN_01946940;
          if (cStack_11 == '\0') {
            appuStack_6c[0] = (undefined **)0x0;
          }
          pppuStack_368 = (undefined ***)0xa85577;
          FUN_00a7cd80();
          pppuStack_368 = (undefined ***)0xa85582;
          FUN_00a7cd80();
          pppuStack_368 = (undefined ***)0xa8558d;
          FUN_00a7cd80();
          uStack_8._0_1_ = 0x1b;
          if (DAT_01eea9ad != 0) {
            puStack_18 = &param_2;
            if (0xf < in_stack_00000018) {
              puStack_18 = param_2;
            }
            pppuStack_368 = (undefined ***)0xa855b0;
            uVar7 = FUN_00928340();
            pppuStack_368 = (undefined ***)0xa855bc;
            uVar8 = FUN_00928340();
            pppuStack_368 = (undefined ***)puStack_18;
            puStack_380 = (undefined4 *)(uint)DAT_01eea9ad;
            pcStack_37c = "FilterStringAsync:Submitted %lld %lld \"%s\"";
            pcStack_384 = (char *)0xa855d5;
            uStack_370 = uVar7;
            uStack_378 = uVar8;
            FUN_01677520();
          }
          puVar1 = DAT_01d66400;
          pppuStack_388 = appuStack_6c;
          puStack_1c = &pcStack_384;
          uStack_38c = 0xa855f2;
          FUN_0054f510();
          pppuStack_388 = (undefined ***)0x2;
          puStack_20 = (undefined *)&piStack_390;
          piStack_394 = &iStack_28;
          uStack_398 = 0xa85605;
          FUN_00557fc0();
          uStack_8._0_1_ = 0x1d;
          puStack_3ac = &param_2;
          piStack_3b0 = (int *)0xa85617;
          FUN_0054ef60();
          puStack_3ac = puVar1;
          uStack_8._0_1_ = 0x1b;
          piStack_3b0 = (int *)0xa85623;
          FUN_00a85f10();
        }
        pppuStack_368 = (undefined ***)0xa8562b;
        FUN_00550990();
        pppuStack_368 = (undefined ***)0xa85633;
        FUN_00550b30();
        pppuStack_368 = (undefined ***)0xa8563b;
        FUN_00550b30();
        uVar7 = uStack_370;
        goto LAB_00a856c4;
      }
      puStack_380 = (undefined4 *)0x1f;
      pcStack_384 = "Invalid datamodel configuration";
      goto LAB_00a8565a;
    }
    puStack_380 = (undefined4 *)0x0;
    uStack_370._4_4_ = (char *)0x0;
    pppuStack_368 = (undefined ***)0xf;
    pcStack_384 = "";
    pcStack_37c = (char *)((uint)pcStack_37c & 0xffffff00);
    pppuStack_388 = (undefined ***)0xa85138;
    FUN_005542c0();
  }
  puStack_380 = (undefined4 *)0xa85678;
  FUN_005e65e0();
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_30[1] + -1;
    piStack_30[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      pppuStack_368 = (undefined ***)0xa8568e;
      (**(code **)*piStack_30)();
      LOCK();
      iVar5 = piStack_30[2] + -1;
      piStack_30[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        pppuStack_368 = (undefined ***)0xa8569e;
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  uVar7 = CONCAT44(uStack_370._4_4_,(undefined *)uStack_370);
  uStack_54 = CONCAT44(uStack_54._4_4_,(undefined4)uStack_54);
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_24[1] + -1;
    piStack_24[1] = iVar5;
    UNLOCK();
    uVar7 = CONCAT44(uStack_370._4_4_,(undefined *)uStack_370);
    uStack_54 = CONCAT44(uStack_54._4_4_,(undefined4)uStack_54);
    if (iVar5 == 0) {
      pppuStack_368 = (undefined ***)0xa856b4;
      (**(code **)*piStack_24)();
      LOCK();
      iVar5 = piStack_24[2] + -1;
      piStack_24[2] = iVar5;
      UNLOCK();
      uVar7 = CONCAT44(uStack_370._4_4_,(undefined *)uStack_370);
      if (iVar5 == 0) {
        pppuStack_368 = (undefined ***)0xa856c4;
        (**(code **)(*piStack_24 + 4))();
        uVar7 = CONCAT44(uStack_370._4_4_,(undefined *)uStack_370);
      }
    }
  }
LAB_00a856c4:
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (0xf < in_stack_00000018) {
    pppuStack_368 = (undefined ***)(in_stack_00000018 + 1);
    uStack_370._4_4_ = (char *)param_2;
    if (0xfff < pppuStack_368) {
      uStack_370._4_4_ = (char *)param_2[-1];
      pppuStack_368 = (undefined ***)(in_stack_00000018 + 0x24);
      if (0x1f < (uint)((int)param_2 + (-4 - (int)uStack_370._4_4_))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_368 = (undefined ***)&UNK_00a857c5;
        uStack_370 = uVar7;
        FUN_017167a3();
      }
    }
    uStack_370._0_4_ = (undefined *)0xa856f9;
    FUN_01674ea0();
    uVar7 = CONCAT44(uStack_370._4_4_,(undefined *)uStack_370);
  }
  piVar2 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = (undefined4 *)((uint)param_2 & 0xffffff00);
  uStack_370 = uVar7;
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    iVar5 = in_stack_00000020[1] + -1;
    in_stack_00000020[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      pppuStack_368 = (undefined ***)0xa85727;
      (**(code **)*in_stack_00000020)();
      LOCK();
      piVar6 = piVar2 + 2;
      iVar5 = *piVar6 + -1;
      *piVar6 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        pppuStack_368 = (undefined ***)0xa85737;
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = in_stack_00000028;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    iVar5 = in_stack_00000028[1] + -1;
    in_stack_00000028[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      pppuStack_368 = (undefined ***)0xa8574d;
      (**(code **)*in_stack_00000028)();
      LOCK();
      piVar6 = piVar2 + 2;
      iVar5 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        pppuStack_368 = (undefined ***)0xa8575c;
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x1e);
  if (in_stack_0000002c != 0) {
    if (((in_stack_0000002c & 1) == 0) &&
       (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
      uStack_370._0_4_ = &stack0x00000034;
      pppuStack_368 = (undefined ***)0x2;
      uStack_378._4_4_ = (int *)0xa8577d;
      uStack_370._4_4_ = (undefined *)uStack_370;
      (**(code **)(in_stack_0000002c & 0xfffffffe))();
    }
    in_stack_0000002c = 0;
  }
  uStack_8 = 0x1f;
  if (((in_stack_0000004c != 0) && ((in_stack_0000004c & 1) == 0)) &&
     (*(code **)(in_stack_0000004c & 0xfffffffe) != (code *)0x0)) {
    uStack_370._0_4_ = &stack0x00000054;
    pppuStack_368 = (undefined ***)0x2;
    uStack_378._4_4_ = (int *)0xa857ab;
    uStack_370._4_4_ = (undefined *)uStack_370;
    (**(code **)(in_stack_0000004c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21548 ; VA 0x00a857d0 ; FUN_00a857d0 */

void __thiscall
FUN_00a857d0(undefined4 param_1,int param_2,undefined4 *param_3,int param_4,int *param_5,int param_6
            ,int *param_7,uint param_8)

{
  int iVar1;
  bool bVar2;
  undefined uVar3;
  char cVar4;
  int *piVar5;
  undefined8 uVar6;
  uint in_stack_0000003c;
  undefined auStack_400 [68];
  undefined4 uStack_3bc;
  undefined8 uStack_3b8;
  undefined4 uStack_3b0;
  undefined4 *puStack_3ac;
  undefined **ppuStack_3a8;
  undefined4 *puStack_3a0;
  undefined4 uStack_390;
  undefined4 *puStack_38c;
  char *pcStack_388;
  char *pcStack_384;
  undefined auStack_380 [8];
  undefined auStack_378 [8];
  undefined4 *puStack_370;
  undefined4 *puStack_36c;
  undefined4 auStack_35c [2];
  undefined auStack_354 [128];
  undefined4 uStack_2d4;
  undefined auStack_2cc [128];
  undefined4 uStack_24c;
  undefined auStack_244 [128];
  undefined4 uStack_1c4;
  undefined auStack_1bc [128];
  undefined4 uStack_13c;
  undefined auStack_134 [128];
  undefined4 auStack_b4 [2];
  undefined auStack_ac [128];
  undefined *puStack_2c;
  undefined *puStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4d44;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  uStack_20 = param_1;
  if (*(char *)(param_2 + 8) == '\0') {
    if ((param_4 != 0) && (param_6 != 0)) {
      ExceptionList = &pvStack_10;
      unique0x10000595 = CONCAT44(auStack_378._0_4_,auStack_380._4_4_);
      unique0x1000059d = CONCAT44(puStack_370,auStack_378._4_4_);
      if (DAT_01eea9ad != 0) {
        if (0xf < (uint)param_3[5]) {
          param_3 = (undefined4 *)*param_3;
        }
        puStack_36c = (undefined4 *)0xa858be;
        ExceptionList = &pvStack_10;
        uVar6 = FUN_00928340();
        puStack_36c = (undefined4 *)0xa858ca;
        join_0x00000008_0x00000000_ = FUN_00928340();
        pcStack_384 = (char *)(uint)DAT_01eea9ad;
        auStack_380._0_4_ = "FilterStringAsync:CanChatChecking %lld %lld \"%s\"";
        pcStack_388 = (char *)0xa858e1;
        puStack_36c = param_3;
        unique0x1000058d = uVar6;
        FUN_01677520();
      }
      uVar3 = DAT_01eeaa44;
      puStack_36c = (undefined4 *)0xa858f7;
      uVar6 = FUN_00928340();
      uStack_14 = (undefined4)uVar6;
      puStack_36c = (undefined4 *)0xa85905;
      uStack_1c = FUN_00928340();
      puStack_2c = (undefined *)&pcStack_388;
      puStack_38c = &stack0x0000003c;
      uStack_390 = 0xa8591c;
      FUN_0054f510();
      uStack_8._0_1_ = 4;
      puStack_24 = auStack_400;
      FUN_00a7c000(param_2);
      uStack_8._0_1_ = 5;
      FUN_0054f510(&param_8);
      if (param_7 != (int *)0x0) {
        LOCK();
        param_7[1] = param_7[1] + 1;
        UNLOCK();
      }
      uStack_8._0_1_ = 4;
      FUN_00a76bc0(auStack_35c,FUN_00a7ea40,uVar3,param_6,param_7);
      uStack_2d4 = auStack_35c[0];
      puStack_3ac = (undefined4 *)auStack_354;
      uStack_8._0_1_ = 6;
      uStack_3b0 = 0xa859ad;
      FUN_00a78900();
      uStack_24c = uStack_2d4;
      puStack_3ac = (undefined4 *)auStack_2cc;
      uStack_8._0_1_ = 7;
      ppuStack_3a8 = (undefined **)0x0;
      uStack_3b0 = 0xa859d5;
      FUN_00a78900();
      uStack_1c4 = uStack_24c;
      puStack_3ac = (undefined4 *)auStack_244;
      uStack_8._0_1_ = 8;
      uStack_3b0 = 0xa859f7;
      FUN_00a78900();
      auStack_b4[0] = uStack_1c4;
      puStack_3ac = (undefined4 *)auStack_1bc;
      uStack_8._0_1_ = 9;
      uStack_3b0 = 0xa85a19;
      FUN_00a78900();
      puStack_3ac = auStack_b4;
      uStack_8._0_1_ = 10;
      uStack_3b0 = 0xa85a29;
      cVar4 = FUN_00585a40();
      if (cVar4 == '\0') {
        uStack_13c = auStack_b4[0];
        puStack_3ac = (undefined4 *)auStack_ac;
        uStack_3b0 = 0xa85a52;
        FUN_00a78900();
        puStack_3ac = (undefined4 *)0x88;
        uStack_8._0_1_ = 0xb;
        uStack_3b0 = 0xa85a60;
        puStack_3a0 = (undefined4 *)FUN_01674e20();
        uStack_8._0_1_ = 0xc;
        if (puStack_3a0 == (undefined4 *)0x0) {
          puStack_3a0 = (undefined4 *)0x0;
        }
        else {
          puStack_3ac = (undefined4 *)auStack_134;
          *puStack_3a0 = uStack_13c;
          uStack_3b0 = 0xa85a87;
          FUN_00a78900();
        }
        puStack_3ac = (undefined4 *)0xa85a99;
        FUN_0096d5e0();
        puStack_3ac = (undefined4 *)0xa85aa4;
        FUN_00a7c840();
        puStack_3ac = (undefined4 *)0xa85aac;
        FUN_0096d5e0();
        puStack_3ac = (undefined4 *)0xa85ab7;
        FUN_00a7c840();
        bVar2 = true;
      }
      else {
        puStack_3ac = (undefined4 *)0xa85ac3;
        FUN_0096d5e0();
        puStack_3ac = (undefined4 *)0xa85ace;
        FUN_00a7c840();
        bVar2 = false;
      }
      puStack_3ac = (undefined4 *)0xa85adb;
      FUN_0096d5e0();
      puStack_3ac = (undefined4 *)0xa85ae6;
      FUN_00a7c840();
      ppuStack_3a8 = &PTR_FUN_01946970;
      if (!bVar2) {
        ppuStack_3a8 = (undefined **)0x0;
      }
      puStack_3ac = (undefined4 *)0xa85aff;
      FUN_0096d5e0();
      puStack_3ac = (undefined4 *)0xa85b0a;
      FUN_00a7c840();
      puStack_3ac = (undefined4 *)0xa85b15;
      FUN_0096d5e0();
      puStack_3ac = (undefined4 *)0xa85b20;
      FUN_00a7c840();
      uStack_8._0_1_ = 4;
      puStack_3ac = (undefined4 *)0xa85b2f;
      FUN_0096d5e0();
      puStack_3ac = (undefined4 *)0xa85b3a;
      FUN_00a7c840();
      uStack_3b0 = uStack_14;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      uStack_3bc = 0xa85b52;
      puStack_3ac = (undefined4 *)(int)((ulonglong)uVar6 >> 0x20);
      uStack_3b8 = uStack_1c;
      FUN_00a7f8c0();
      goto LAB_00a85b7e;
    }
    pcStack_384 = (char *)0x15;
    puStack_370 = (undefined4 *)0x0;
    puStack_36c = (undefined4 *)0xf;
    pcStack_388 = "Player does not exist";
    auStack_380._0_4_ = auStack_380._0_4_ & 0xffffff00;
    puStack_38c = (undefined4 *)0xa85b76;
    ExceptionList = &pvStack_10;
    FUN_005542c0();
  }
  else {
    ExceptionList = &pvStack_10;
    if (DAT_01eea9ad != 0) {
      piVar5 = (int *)(param_2 + 0xc);
      if (0xf < *(uint *)(param_2 + 0x20)) {
        piVar5 = (int *)*piVar5;
      }
      if (0xf < (uint)param_3[5]) {
        param_3 = (undefined4 *)*param_3;
      }
      if (param_6 == 0) {
        auStack_378 = (undefined  [8])0x8000000000000000;
        ExceptionList = &pvStack_10;
      }
      else {
        puStack_36c = (undefined4 *)0xa85833;
        ExceptionList = &pvStack_10;
        auStack_378 = (undefined  [8])FUN_00928340();
      }
      if (param_4 == 0) {
        auStack_380 = (undefined  [8])0x8000000000000000;
      }
      else {
        puStack_36c = (undefined4 *)0xa85855;
        auStack_380 = (undefined  [8])FUN_00928340();
      }
      pcStack_388 = (char *)(uint)DAT_01eea9ad;
      pcStack_384 = "FilterStringAsync:Error %lld %lld \"%s\" \"%s\"";
      puStack_38c = (undefined4 *)0xa8587a;
      puStack_370 = param_3;
      puStack_36c = piVar5;
      FUN_01677520();
    }
    pcStack_384 = (char *)(param_2 + 0xc);
    pcStack_388 = (char *)0xa8588b;
    FUN_0054ef60();
  }
  pcStack_384 = (char *)0xa85b7e;
  FUN_005e65e0();
LAB_00a85b7e:
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar1 = param_5[1] + -1;
    param_5[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      puStack_36c = (undefined4 *)0xa85b97;
      (**(code **)*param_5)();
      LOCK();
      iVar1 = param_5[2] + -1;
      param_5[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        puStack_36c = (undefined4 *)0xa85ba7;
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_7 != (int *)0x0) {
    LOCK();
    iVar1 = param_7[1] + -1;
    param_7[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      puStack_36c = (undefined4 *)0xa85bbd;
      (**(code **)*param_7)();
      LOCK();
      piVar5 = param_7 + 2;
      iVar1 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        puStack_36c = (undefined4 *)0xa85bcc;
        (**(code **)(*param_7 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  if (param_8 != 0) {
    if (((param_8 & 1) == 0) && (*(code **)(param_8 & 0xfffffffe) != (code *)0x0)) {
      auStack_378._4_4_ = &stack0x00000024;
      puStack_36c = (undefined4 *)0x2;
      auStack_378._0_4_ = 0xa85bed;
      puStack_370 = (undefined4 *)auStack_378._4_4_;
      (**(code **)(param_8 & 0xfffffffe))();
    }
    param_8 = 0;
  }
  uStack_8 = 0xe;
  if (((in_stack_0000003c != 0) && ((in_stack_0000003c & 1) == 0)) &&
     (*(code **)(in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
    auStack_378._4_4_ = &stack0x00000044;
    puStack_36c = (undefined4 *)0x2;
    auStack_378._0_4_ = 0xa85c1b;
    puStack_370 = (undefined4 *)auStack_378._4_4_;
    (**(code **)(in_stack_0000003c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21549 ; VA 0x00a85c40 ; FUN_00a85c40 */

void FUN_00a85c40(int param_1,int param_2,int *param_3,int param_4,int *param_5,uint param_6)

{
  int *piVar1;
  int iVar2;
  uint in_stack_00000038;
  undefined auStack_30 [8];
  undefined4 uStack_28;
  undefined *puStack_24;
  undefined *puStack_20;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4d70;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  if (*(char *)(param_1 + 8) == '\0') {
    if ((param_2 == 0) || (param_4 == 0)) {
      puStack_20 = (undefined *)0x0;
      uStack_1c = 0xf;
      auStack_30[0] = 0;
      ExceptionList = &pvStack_10;
      FUN_005542c0("Player does not exist",0x15);
    }
    else {
      ExceptionList = &pvStack_10;
      if (param_5 != (int *)0x0) {
        LOCK();
        ExceptionList = &pvStack_10;
        param_5[1] = param_5[1] + 1;
        UNLOCK();
      }
      FUN_00a7ebd0(auStack_30,param_1,param_4,param_5);
    }
  }
  else {
    ExceptionList = &pvStack_10;
    FUN_0054ef60(param_1 + 0xc);
  }
  FUN_005e65e0();
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_1c = 0xa85d05;
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_1c = 0xa85d15;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_1c = 0xa85d2b;
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_1c = 0xa85d3a;
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    puStack_24 = &stack0x00000020;
    uStack_1c = 2;
    uStack_28 = 0xa85d5b;
    puStack_20 = puStack_24;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((in_stack_00000038 != 0) && ((in_stack_00000038 & 1) == 0)) &&
     (*(code **)(in_stack_00000038 & 0xfffffffe) != (code *)0x0)) {
    puStack_24 = &stack0x00000040;
    uStack_1c = 2;
    uStack_28 = 0xa85d89;
    puStack_20 = puStack_24;
    (**(code **)(in_stack_00000038 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21550 ; VA 0x00a85da0 ; FUN_00a85da0 */

void FUN_00a85da0(int param_1,int param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  undefined8 uVar3;
  uint in_stack_00000030;
  undefined4 in_stack_ffffffd0;
  uint in_stack_ffffffd4;
  char *in_stack_ffffffd8;
  undefined4 in_stack_ffffffdc;
  undefined4 in_stack_ffffffe0;
  int *in_stack_ffffffe4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar3 = CONCAT44(in_stack_ffffffe0,in_stack_ffffffdc);
  puStack_c = &LAB_017e4b28;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (*(char *)(param_1 + 8) == '\0') {
    piVar1 = (int *)(param_1 + 0x24);
    ExceptionList = &pvStack_10;
    if (DAT_01eea9ad != 0) {
      in_stack_ffffffe4 = piVar1;
      if (0xf < *(uint *)(param_1 + 0x38)) {
        in_stack_ffffffe4 = (int *)*piVar1;
      }
      if (param_2 == 0) {
        uVar3 = 0x8000000000000000;
        ExceptionList = &pvStack_10;
      }
      else {
        ExceptionList = &pvStack_10;
        uVar3 = FUN_00928340();
      }
      in_stack_ffffffd4 = (uint)DAT_01eea9ad;
      in_stack_ffffffd8 = "FilterStringForPlayer:Success %lld \"%s\"";
      in_stack_ffffffd0 = 0xa85e61;
      FUN_01677520(in_stack_ffffffd4,"FilterStringForPlayer:Success %lld \"%s\"",uVar3,
                   in_stack_ffffffe4);
    }
    FUN_0054ef60(piVar1);
  }
  else {
    piVar1 = (int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    if (DAT_01eea9ad != 0) {
      in_stack_ffffffe4 = piVar1;
      if (0xf < *(uint *)(param_1 + 0x20)) {
        in_stack_ffffffe4 = (int *)*piVar1;
      }
      if (param_2 == 0) {
        uVar3 = 0x8000000000000000;
        ExceptionList = &pvStack_10;
      }
      else {
        ExceptionList = &pvStack_10;
        uVar3 = FUN_00928340();
      }
      in_stack_ffffffd4 = (uint)DAT_01eea9ad;
      in_stack_ffffffd8 = "FilterStringForPlayer:Error %lld \"%s\"";
      in_stack_ffffffd0 = 0xa85e0f;
      FUN_01677520(in_stack_ffffffd4,"FilterStringForPlayer:Error %lld \"%s\"",uVar3,
                   in_stack_ffffffe4);
    }
    FUN_0054ef60(piVar1);
  }
  FUN_005e65e0(in_stack_ffffffd0,in_stack_ffffffd4,in_stack_ffffffd8,uVar3,in_stack_ffffffe4);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_4 & 0xfffffffe))(&stack0x00000018,&stack0x00000018,2);
  }
  uStack_8 = 4;
  if (((in_stack_00000030 != 0) && ((in_stack_00000030 & 1) == 0)) &&
     (*(code **)(in_stack_00000030 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000030 & 0xfffffffe))(&stack0x00000038,&stack0x00000038,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21551 ; VA 0x00a85f10 ; FUN_00a85f10 */

void FUN_00a85f10(undefined4 param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined uVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  undefined4 unaff_EBX;
  undefined8 uVar8;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  int in_stack_00000020;
  int *in_stack_00000024;
  undefined *in_stack_00000028;
  uint in_stack_0000002c;
  undefined auStack_124 [20];
  undefined4 uStack_110;
  int iStack_10c;
  undefined auStack_108 [20];
  undefined4 uStack_f4;
  undefined4 *puStack_f0;
  undefined auStack_ec [16];
  undefined4 uStack_dc;
  int *piStack_d8;
  char *pcStack_d4;
  uint *puStack_d0;
  undefined auStack_c0 [88];
  undefined auStack_68 [16];
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined *puStack_50;
  undefined4 uStack_4c;
  uint auStack_48 [4];
  int iStack_38;
  uint uStack_34;
  int iStack_2c;
  int *piStack_28;
  undefined *puStack_24;
  undefined4 uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4df6;
  pvStack_10 = ExceptionList;
  puStack_d0 = (uint *)DAT_01eea9bc;
  uStack_8 = 2;
  pcStack_d4 = (char *)0xa85f46;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290();
  uStack_8._0_1_ = 3;
  uStack_4c = uVar5;
  if (in_stack_00000020 == 0) {
    puStack_d0 = (uint *)0x1e;
    pcStack_d4 = "Cannot filter for null player.";
    iStack_38 = in_stack_00000020;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
    piStack_d8 = (int *)0xa85f7c;
    FUN_005542c0();
    puStack_d0 = auStack_48;
    uStack_8._0_1_ = 4;
    pcStack_d4 = auStack_c0;
    piStack_d8 = (int *)0xa85f90;
    puStack_d0 = (uint *)FUN_00a837c0();
    uStack_8._0_1_ = 5;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 5;
    if (in_stack_0000002c == 0) {
      puStack_d0 = (uint *)0xa86231;
      uStack_8._0_1_ = uVar4;
      puStack_d0 = (uint *)FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
                    /* WARNING: Subroutine does not return */
      pcStack_d4 = (char *)0xa8623b;
      FUN_0054e5e0();
    }
    pcStack_d4 = &stack0x00000034;
    piStack_d8 = (int *)0xa85fb1;
    (**(code **)((in_stack_0000002c & 0xfffffffe) + 4))();
    puStack_d0 = (uint *)0xa85fbf;
    FUN_0096d5e0();
    uStack_8._0_1_ = 3;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_34) {
      puStack_d0 = (uint *)(uStack_34 + 1);
      uVar7 = auStack_48[0];
      if (0xfff < puStack_d0) {
        uVar7 = *(uint *)(auStack_48[0] - 4);
        puStack_d0 = (uint *)(uStack_34 + 0x24);
        if (0x1f < (auStack_48[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          puStack_d0 = (uint *)0xa86240;
          uStack_8._0_1_ = uVar4;
          FUN_017167a3();
        }
      }
      piStack_d8 = (int *)0xa85ff8;
      pcStack_d4 = (char *)uVar7;
      FUN_01674ea0();
    }
  }
  else {
    puStack_d0 = (uint *)in_stack_00000020;
    pcStack_d4 = (char *)0xa86006;
    pcStack_d4 = (char *)FUN_008f7870();
    piStack_d8 = &iStack_2c;
    uStack_dc = 0xa86010;
    FUN_005c4330();
    iVar2 = in_stack_00000020;
    uStack_8._0_1_ = 8;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (iStack_2c != 0) {
      puStack_d0 = (uint *)0xa860c6;
      uStack_8._0_1_ = uVar4;
      iVar6 = FUN_00926bd0();
      iStack_18 = in_stack_00000020;
      puStack_d0 = (uint *)0xa860d8;
      uVar8 = FUN_00928340();
      uStack_1c = (undefined4)((ulonglong)uVar8 >> 0x20);
      uStack_14 = (undefined4)uVar8;
      puStack_50 = auStack_ec;
      puStack_f0 = &stack0x0000002c;
      uStack_f4 = 0xa860ef;
      FUN_0054f510();
      puStack_f0 = (undefined4 *)in_stack_00000028;
      iStack_10c = iVar2 + 0x470;
      uStack_8._0_1_ = 0xd;
      in_stack_00000028 = auStack_108;
      puStack_24 = auStack_108;
      uStack_110 = 0xa8610d;
      FUN_0054ef60();
      puStack_24 = auStack_124;
      uStack_8._0_1_ = 0xe;
      iStack_10c = CONCAT31((int3)((uint)unaff_EBX >> 8),iVar6 == 0);
      FUN_00927240(auStack_124);
      uStack_8._0_1_ = 0xf;
      FUN_0054ef60(&param_2);
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      FUN_00a86260(param_1);
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_28[1] + -1;
        piStack_28[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          puStack_d0 = (uint *)0xa86163;
          (**(code **)*piStack_28)();
          LOCK();
          iVar2 = piStack_28[2] + -1;
          piStack_28[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            puStack_d0 = (uint *)0xa86173;
            (**(code **)(*piStack_28 + 4))();
          }
        }
      }
      uStack_8._0_1_ = 0x10;
      goto LAB_00a86177;
    }
    puStack_d0 = (uint *)0x22;
    pcStack_d4 = "Cannot filter for detached player.";
    uStack_58 = 0;
    uStack_54 = 0xf;
    auStack_68[0] = 0;
    piStack_d8 = (int *)0xa86042;
    FUN_005542c0();
    puStack_d0 = (uint *)auStack_68;
    uStack_8._0_1_ = 9;
    pcStack_d4 = auStack_c0;
    piStack_d8 = (int *)0xa86056;
    puStack_d0 = (uint *)FUN_00a837c0();
    uStack_8._0_1_ = 10;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 10;
    if (in_stack_0000002c == 0) {
      puStack_d0 = (uint *)0xa86248;
      uStack_8._0_1_ = uVar4;
      puStack_d0 = (uint *)FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
                    /* WARNING: Subroutine does not return */
      pcStack_d4 = (char *)0xa86252;
      FUN_0054e5e0();
    }
    pcStack_d4 = &stack0x00000034;
    piStack_d8 = (int *)0xa86077;
    (**(code **)((in_stack_0000002c & 0xfffffffe) + 4))();
    puStack_d0 = (uint *)0xa86085;
    FUN_0096d5e0();
    puStack_d0 = (uint *)0xa8608d;
    FUN_005507b0();
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_28[1] + -1;
      piStack_28[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        puStack_d0 = (uint *)0xa860a3;
        (**(code **)*piStack_28)();
        LOCK();
        iVar2 = piStack_28[2] + -1;
        piStack_28[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          puStack_d0 = (uint *)0xa860b3;
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
  }
  uStack_8._0_1_ = 0xc;
LAB_00a86177:
  pcStack_d4 = (char *)0xa8617d;
  puStack_d0 = (uint *)uVar5;
  FUN_01675290();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < in_stack_0000001c) {
    puStack_d0 = (uint *)(in_stack_0000001c + 1);
    uVar7 = param_2;
    if (0xfff < puStack_d0) {
      uVar7 = *(uint *)(param_2 - 4);
      puStack_d0 = (uint *)(in_stack_0000001c + 0x24);
      if (0x1f < (param_2 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_d0 = (uint *)&UNK_00a86257;
        FUN_017167a3();
      }
    }
    piStack_d8 = (int *)0xa861b5;
    pcStack_d4 = (char *)uVar7;
    FUN_01674ea0();
  }
  piVar3 = in_stack_00000024;
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (in_stack_00000024 != (int *)0x0) {
    LOCK();
    iVar2 = in_stack_00000024[1] + -1;
    in_stack_00000024[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_d0 = (uint *)0xa861e0;
      (**(code **)*in_stack_00000024)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_d0 = (uint *)0xa861ef;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = 0x11;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    piStack_d8 = (int *)&stack0x00000034;
    puStack_d0 = (uint *)0x2;
    uStack_dc = 0xa86213;
    pcStack_d4 = (char *)piStack_d8;
    (**(code **)(in_stack_0000002c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21552 ; VA 0x00a86260 ; FUN_00a86260 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00a86260(uint param_1)

{
  int *piVar1;
  uint *puVar2;
  int *piVar3;
  uint uVar4;
  undefined uVar5;
  char cVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  undefined4 in_stack_00000020;
  int *in_stack_00000024;
  int in_stack_00000038;
  undefined in_stack_00000040;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined4 *in_stack_0000005c;
  uint in_stack_00000060;
  uint in_stack_00000068;
  uint in_stack_0000006c;
  uint in_stack_00000070;
  uint in_stack_00000074;
  undefined8 in_stack_00000078;
  undefined auStack_430 [88];
  undefined auStack_3d8 [88];
  undefined auStack_380 [88];
  undefined auStack_328 [88];
  undefined auStack_2d0 [96];
  int iStack_270;
  undefined4 uStack_210;
  int *piStack_20c;
  undefined4 uStack_208;
  undefined4 uStack_204;
  undefined4 uStack_1e8;
  int *piStack_1e4;
  uint uStack_1e0;
  uint uStack_1d8;
  uint uStack_1d4;
  uint uStack_1d0;
  uint uStack_1cc;
  undefined8 uStack_1c8;
  undefined uStack_1c0;
  int iStack_1bc;
  undefined **appuStack_1b8 [4];
  undefined *puStack_1a8;
  undefined **ppuStack_1a0;
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined4 *puStack_194;
  undefined4 *puStack_190;
  int aiStack_18c [2];
  int *piStack_184;
  int *piStack_180;
  undefined4 uStack_17c;
  undefined4 uStack_178;
  undefined4 *puStack_174;
  undefined4 *puStack_170;
  int iStack_16c;
  undefined4 uStack_168;
  uint uStack_164;
  undefined **ppuStack_150;
  undefined4 uStack_108;
  double dStack_104;
  undefined2 uStack_fc;
  undefined auStack_f8 [16];
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined auStack_e0 [16];
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined auStack_c8 [16];
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  uint auStack_ac [4];
  undefined4 uStack_9c;
  uint uStack_98;
  undefined4 uStack_94;
  int *piStack_90;
  undefined uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  uint uStack_6c;
  undefined4 uStack_5c;
  uint uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  int *piStack_4c;
  uint uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  uint uStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4f66;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  uStack_108 = FUN_01675290();
  uStack_8._0_1_ = 4;
  FUN_016830f0();
  FUN_0054ef60();
  uStack_94 = in_stack_00000020;
  piStack_90 = in_stack_00000024;
  uStack_8._0_1_ = 5;
  FUN_00a87870();
  uVar4 = uStack_14;
  if (uStack_14 == 0) {
    if (0 < (int)param_1) {
      uStack_fc = 0;
      dStack_104 = 0.0;
      uStack_e8 = 0;
      uStack_e4 = 0xf;
      auStack_f8[0] = 0;
      uStack_d0 = 0;
      uStack_cc = 0xf;
      auStack_e0[0] = 0;
      uStack_b8 = 0;
      uStack_b4 = 0xf;
      auStack_c8[0] = 0;
      uStack_8._0_1_ = 7;
      FUN_00a87870();
      uVar4 = uStack_14;
      if (uStack_14 != 0) {
        FUN_00a88840();
        iVar7 = *(int *)(uVar4 + 0x28);
        dStack_104 = *(double *)(iVar7 + 0x30);
        uStack_fc = *(undefined2 *)(iVar7 + 0x38);
        if (auStack_f8 != (undefined *)(iVar7 + 0x3c)) {
          FUN_005542c0();
        }
        if (auStack_e0 != (undefined *)(iVar7 + 0x54)) {
          FUN_005542c0();
        }
        if (auStack_c8 != (undefined *)(iVar7 + 0x6c)) {
          FUN_005542c0();
        }
        if (((NAN(dStack_104) || NAN(_PTR_018c6f48)) == (dStack_104 == _PTR_018c6f48)) &&
           ((double)CONCAT44(uStack_70,uStack_74) - dStack_104 < (double)(int)param_1 * DAT_018e0008
           )) {
          if (DAT_01eea9ad != '\0') {
            FUN_01677520();
          }
          FUN_008927d0();
          FUN_0096d5e0();
          goto LAB_00a86557;
        }
      }
      FUN_0096d5e0();
    }
    uStack_54 = 0;
    uStack_50 = 0;
    piStack_4c = (int *)0x0;
    uStack_8._0_1_ = 9;
    iVar7 = FUN_00a7d4b0();
    uStack_8._0_1_ = 10;
    if ((undefined4 *)(iVar7 + 0x20) != &uStack_54) {
      FUN_00a7ed40();
      *(undefined4 *)(iVar7 + 0x20) = 0;
      *(undefined4 *)(iVar7 + 0x24) = 0;
      *(undefined4 *)(iVar7 + 0x28) = 0;
      uStack_54 = 0;
      uStack_50 = 0;
      piStack_4c = (int *)0x0;
    }
    uStack_8._0_1_ = 0xb;
    FUN_00a7ed40();
    uStack_8._0_1_ = 5;
    uStack_38 = 0;
    uStack_34 = 0xf;
    uStack_48 = uStack_48 & 0xffffff00;
    FUN_005542c0();
    uStack_8._0_1_ = 0xc;
    FUN_00a89510();
    uStack_8._0_1_ = 5;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 5;
    if (0xf < uStack_34) {
      if ((0xfff < uStack_34 + 1) && (0x1f < (uStack_48 - *(int *)(uStack_48 - 4)) - 4)) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      FUN_01674ea0();
    }
    appuStack_1b8[0] = &PTR_018bf148;
    puStack_1a8 = &DAT_018bf150;
    ppuStack_150 = std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
    uStack_14 = 1;
    FUN_00564f30();
    uStack_8 = 0xe;
    *(undefined ***)((int)appuStack_1b8 + (int)appuStack_1b8[0][1]) =
         std::basic_stringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
         vftable;
    *(undefined **)((int)&iStack_1bc + (int)appuStack_1b8[0][1]) = appuStack_1b8[0][1] + -0x68;
    ppuStack_1a0 = std::basic_streambuf<char,struct_std::char_traits<char>_>::vftable;
    iStack_16c = FUN_01674e20();
    if (iStack_16c == 0) {
      iStack_16c = 0;
    }
    else {
      uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
      uVar8 = FUN_016de181();
      *(undefined4 *)(iStack_16c + 4) = uVar8;
    }
    puStack_194 = &uStack_19c;
    puStack_190 = &uStack_198;
    piStack_184 = aiStack_18c;
    piStack_180 = aiStack_18c + 1;
    puStack_174 = &uStack_17c;
    puStack_170 = &uStack_178;
    uStack_198 = 0;
    aiStack_18c[1] = 0;
    uStack_178 = 0;
    uStack_19c = 0;
    aiStack_18c[0] = 0;
    uStack_17c = 0;
    ppuStack_1a0 = std::
                   basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
                   vftable;
    uStack_168 = 0;
    uStack_164 = 0;
    uStack_8c = 0;
    uStack_88 = FUN_00588320();
    uStack_84 = 0;
    uStack_80 = 0x3f800000;
    uStack_7c = 0;
    uStack_78 = 0;
    uStack_8._0_1_ = 0x11;
    FUN_0060dcd0();
    uStack_8._0_1_ = 0x12;
    uStack_14 = FUN_008f7870();
    FUN_0151d700();
    uStack_8._0_1_ = 0x13;
    FUN_00558890();
    FUN_0055b3b0();
    uStack_8._0_1_ = 0x12;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x12;
    if (0xf < uStack_58) {
      if ((0xfff < uStack_58 + 1) && (0x1f < (uStack_6c - *(int *)(uStack_6c - 4)) - 4)) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      FUN_01674ea0();
    }
    FUN_00558890();
    FUN_00872bd0();
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_005542c0();
    uStack_8._0_1_ = 0x14;
    FUN_0055b3b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
    if (0xf < uStack_1c) {
      if ((0xfff < uStack_1c + 1) && (0x1f < (auStack_30[0] - *(int *)(auStack_30[0] - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      FUN_01674ea0();
    }
    if (in_stack_00000038 != 0) {
      FUN_00558890();
      FUN_0055b3b0();
    }
    uStack_38 = 0;
    uStack_34 = 0xf;
    uStack_48 = uStack_48 & 0xffffff00;
    FUN_005542c0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
    puVar9 = (undefined4 *)FUN_005d15d0();
    if (puVar9 != &DAT_01d79c68) {
      FUN_005542c0();
    }
    uStack_8._0_1_ = 0x12;
    if (0xf < uStack_34) {
      if ((0xfff < uStack_34 + 1) && (0x1f < (uStack_48 - *(int *)(uStack_48 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      FUN_01674ea0();
    }
    uStack_38 = 0;
    uStack_34 = 0xf;
    uStack_48 = uStack_48 & 0xffffff00;
    FUN_005542c0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
    puVar9 = (undefined4 *)FUN_005d15d0();
    if (puVar9 != &DAT_01d79c50) {
      FUN_005542c0();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
    if (0xf < uStack_34) {
      if ((0xfff < uStack_34 + 1) && (0x1f < (uStack_48 - *(int *)(uStack_48 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      FUN_01674ea0();
    }
    param_1 = 3;
    if (uStack_14 != 0) {
      if ((*(int *)(uStack_14 + 0x444) < 1) && (*(int *)(uStack_14 + 0x444) < 0)) {
        iVar7 = FUN_0055c3d0();
        *(undefined *)(iVar7 + -1) = 0x2d;
        iVar7 = iVar7 + -1;
      }
      else {
        iVar7 = FUN_0055c3d0();
      }
      uStack_38 = 0;
      uStack_34 = 0xf;
      uStack_48 = uStack_48 & 0xffffff00;
      if (iVar7 != (int)&uStack_1c + 1) {
        FUN_005542c0();
      }
      param_1 = 0xf;
      uStack_8._0_1_ = 0x17;
      uStack_5c = 0;
      uStack_58 = 0xf;
      uStack_6c = uStack_6c & 0xffffff00;
      FUN_005542c0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
      iVar7 = FUN_005d15d0();
      if ((uint *)(iVar7 + 0x18) != &uStack_48) {
        FUN_005507b0();
        uVar4 = uStack_48;
        uStack_48 = uStack_48 & 0xffffff00;
        *(uint *)(iVar7 + 0x18) = uVar4;
        *(undefined4 *)(iVar7 + 0x1c) = uStack_44;
        *(undefined4 *)(iVar7 + 0x20) = uStack_40;
        *(undefined4 *)(iVar7 + 0x24) = uStack_3c;
        *(ulonglong *)(iVar7 + 0x28) = CONCAT44(uStack_34,uStack_38);
        uStack_38 = 0;
        uStack_34 = 0xf;
      }
      FUN_005507b0();
      uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
      FUN_005507b0();
    }
    if ((DAT_01d79cc0 != 0) &&
       (iVar7 = FUN_005d15d0(), (undefined4 *)(iVar7 + 0x18) != &stack0x00000044)) {
      FUN_005542c0();
    }
    piVar3 = piStack_4c;
    uStack_8._0_1_ = 0x11;
    if (piStack_4c != (int *)0x0) {
      LOCK();
      iVar7 = piStack_4c[1] + -1;
      piStack_4c[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_4c)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar7 = *piVar1 + -1;
        *piVar1 = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    FUN_0060dcd0();
    uStack_8._0_1_ = 0x19;
    FUN_00a7e820();
    uStack_8._0_1_ = 0x1a;
    FUN_014cc090();
    uStack_8._0_1_ = 0x1c;
    uVar5 = (undefined)uStack_8;
    uStack_8._0_1_ = 0x1c;
    if (0xf < uStack_58) {
      if ((0xfff < uStack_58 + 1) && (0x1f < (uStack_6c - *(int *)(uStack_6c - 4)) - 4)) {
        uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      FUN_01674ea0();
    }
    iStack_270 = DAT_01d663e8 * 1000;
    uStack_5c = 0;
    uStack_58 = 0xf;
    uStack_6c = uStack_6c & 0xffffff00;
    FUN_014cc820();
    uStack_14 = param_1 | 0x20;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x1d);
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    if ((((uStack_164 & 2) == 0) && (*piStack_180 != 0)) ||
       (((uStack_164 & 4) == 0 && (*piStack_184 != 0)))) {
      FUN_005542c0();
    }
    in_stack_0000005c = &uStack_210;
    if (in_stack_00000024 != (int *)0x0) {
      LOCK();
      in_stack_00000024[1] = in_stack_00000024[1] + 1;
      UNLOCK();
    }
    uStack_210 = in_stack_00000020;
    piStack_20c = in_stack_00000024;
    uStack_208 = uStack_74;
    uStack_204 = uStack_70;
    uStack_8._0_1_ = 0x1f;
    uStack_8._1_3_ = 0;
    FUN_0054ef60(auStack_ac);
    uStack_1e8 = uStack_94;
    piStack_1e4 = piStack_90;
    uStack_8._0_1_ = 0x20;
    uStack_1e0 = 0;
    if (in_stack_00000060 != 0) {
      uStack_1e0 = in_stack_00000060;
      if ((in_stack_00000060 & 1) == 0) {
        (**(code **)(in_stack_00000060 & 0xfffffffe))(&stack0x00000068,&uStack_1d8,0);
      }
      else {
        uStack_1d8 = in_stack_00000068;
        uStack_1d4 = in_stack_0000006c;
        uStack_1d0 = in_stack_00000070;
        uStack_1cc = in_stack_00000074;
        uStack_1c8 = in_stack_00000078;
      }
    }
    uStack_1c0 = in_stack_00000040;
    uStack_8._0_1_ = 0x21;
    FUN_00a78220(&uStack_210);
    uStack_8._0_1_ = 0x22;
    FUN_00a78220(auStack_430);
    uStack_8._0_1_ = 0x23;
    FUN_00a78220(auStack_3d8);
    uStack_8._0_1_ = 0x24;
    FUN_00a78220(auStack_380);
    uStack_8._0_1_ = 0x25;
    cVar6 = FUN_00585a40(auStack_2d0);
    if (cVar6 == '\0') {
      FUN_00a78220(auStack_2d0);
      uStack_8._0_1_ = 0x26;
      iVar7 = FUN_01674e20(0x58);
      uStack_8._0_1_ = 0x27;
      if (iVar7 != 0) {
        FUN_00a78220(auStack_328);
      }
      FUN_00a7c180();
      FUN_00a7c180();
    }
    else {
      FUN_00a7c180();
    }
    FUN_00a7c180();
    FUN_00a7c180();
    FUN_00a7c180();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x1e);
    FUN_00a7c180();
    FUN_014cd990(auStack_30,&DAT_01d79f80,0);
    if (0xf < uStack_1c) {
      FUN_00554a20();
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_005507b0();
    FUN_0056cfd0();
    FUN_005507b0();
    if (in_stack_00000024 != (int *)0x0) {
      LOCK();
      iVar7 = in_stack_00000024[1] + -1;
      in_stack_00000024[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*in_stack_00000024)();
        LOCK();
        iVar7 = in_stack_00000024[2] + -1;
        in_stack_00000024[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*in_stack_00000024 + 4))();
        }
      }
    }
    FUN_0056cfd0();
    FUN_005705c0();
    FUN_005507b0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0x28);
    goto LAB_00a86ff3;
  }
  if (DAT_01eea9ad != '\0') {
    FUN_01677520();
  }
  puVar2 = *(uint **)(uVar4 + 0x2c);
  if (*(uint **)(uVar4 + 0x30) == puVar2) {
    FUN_00a754a0();
  }
  else {
    *puVar2 = 0;
    if (in_stack_00000060 != 0) {
      *puVar2 = in_stack_00000060;
      if ((in_stack_00000060 & 1) != 0) {
        puVar2[2] = in_stack_00000068;
        puVar2[3] = in_stack_0000006c;
        puVar2[4] = in_stack_00000070;
        puVar2[5] = in_stack_00000074;
        *(undefined8 *)(puVar2 + 6) = in_stack_00000078;
        *(int *)(uVar4 + 0x2c) = *(int *)(uVar4 + 0x2c) + 0x20;
        goto LAB_00a86557;
      }
      (**(code **)(in_stack_00000060 & 0xfffffffe))();
    }
    *(int *)(uVar4 + 0x2c) = *(int *)(uVar4 + 0x2c) + 0x20;
  }
LAB_00a86557:
  uStack_8._0_1_ = 4;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  if (0xf < uStack_98) {
    if ((0xfff < uStack_98 + 1) && (0x1f < (auStack_ac[0] - *(int *)(auStack_ac[0] - 4)) - 4)) {
      uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  uStack_9c = 0;
  uStack_98 = 0xf;
  auStack_ac[0] = auStack_ac[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
LAB_00a86ff3:
  FUN_01675290();
  FUN_005507b0();
  FUN_005507b0();
  FUN_005507b0();
  uStack_8 = 0x29;
  if (((in_stack_00000060 != 0) && ((in_stack_00000060 & 1) == 0)) &&
     (*(code **)(in_stack_00000060 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000060 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21553 ; VA 0x00a87080 ; FUN_00a87080 */

code * FUN_00a87080(char param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  code *pcVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined8 uVar8;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  code *in_stack_00000020;
  undefined4 in_stack_00000028;
  uint in_stack_0000002c;
  char *in_stack_00000030;
  undefined4 *in_stack_00000034;
  undefined8 in_stack_00000038;
  undefined4 *in_stack_00000040;
  int *in_stack_00000044;
  undefined4 *puStack_b0;
  int *piStack_ac;
  undefined4 uStack_a8;
  code *apcStack_a4 [2];
  undefined4 uStack_9c;
  uint uStack_98;
  char *pcStack_94;
  undefined4 *puStack_90;
  undefined8 uStack_8c;
  undefined8 uStack_7c;
  undefined2 uStack_74;
  undefined uStack_70;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined uStack_58;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined uStack_40;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4fa8;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (param_1 == '\0') {
    ExceptionList = &pvStack_10;
    if (DAT_01eea9ad != 0) {
      puVar6 = &param_2;
      if (0xf < in_stack_0000001c) {
        puVar6 = param_2;
      }
      if (in_stack_00000040 == (undefined4 *)0x0) {
        uVar8 = 0x8000000000000000;
        ExceptionList = &pvStack_10;
      }
      else {
        uStack_8c = CONCAT44(0xa870d0,(undefined4)uStack_8c);
        ExceptionList = &pvStack_10;
        uVar8 = FUN_00928340();
      }
      puStack_90 = (undefined4 *)uVar8;
      uStack_8c = CONCAT44(puVar6,(int)((ulonglong)uVar8 >> 0x20));
      uStack_98 = (uint)DAT_01eea9ad;
      pcStack_94 = "FilterStringForBroadcast:NoChat %lld \"%s\"";
      uStack_9c = 0xa870f1;
      FUN_01677520();
    }
    uStack_74 = 0;
    uStack_7c = 0;
    uStack_60 = 0;
    uStack_5c = 0xf;
    uStack_70 = 0;
    uStack_48 = 0;
    uStack_44 = 0xf;
    uStack_58 = 0;
    uStack_30 = 0;
    uStack_2c = 0xf;
    uStack_40 = 0;
    uStack_8._0_1_ = 3;
    if (in_stack_00000020 == (code *)0x0) {
      uStack_8c = CONCAT44(0xa872f5,(undefined4)uStack_8c);
      uVar5 = FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      uStack_8c = CONCAT44(uVar5,0xa872ff);
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0();
    }
    uStack_8c = CONCAT44(&uStack_7c,&stack0x00000028);
    puStack_90 = (undefined4 *)0xa87157;
    (**(code **)(((uint)in_stack_00000020 & 0xfffffffe) + 4))();
    uStack_8c = CONCAT44(0xa87162,(undefined4)uStack_8c);
    FUN_0096d5e0();
  }
  else {
    ExceptionList = &pvStack_10;
    if (DAT_01eea9ad != 0) {
      puVar6 = &param_2;
      if (0xf < in_stack_0000001c) {
        puVar6 = param_2;
      }
      if (in_stack_00000040 == (undefined4 *)0x0) {
        uVar8 = 0x8000000000000000;
        ExceptionList = &pvStack_10;
      }
      else {
        uStack_8c = CONCAT44(0xa87182,(undefined4)uStack_8c);
        ExceptionList = &pvStack_10;
        uVar8 = FUN_00928340();
      }
      puStack_90 = (undefined4 *)uVar8;
      uStack_8c = CONCAT44(puVar6,(int)((ulonglong)uVar8 >> 0x20));
      uStack_98 = (uint)DAT_01eea9ad;
      pcStack_94 = "FilterStringForBroadcast:Submitted %lld \"%s\"";
      uStack_9c = 0xa871a3;
      FUN_01677520();
    }
    uVar5 = DAT_01d66400;
    puStack_14 = (undefined *)apcStack_a4;
    apcStack_a4[0] = (code *)0x0;
    if (in_stack_00000020 != (code *)0x0) {
      apcStack_a4[0] = in_stack_00000020;
      if (((uint)in_stack_00000020 & 1) == 0) {
        piStack_ac = &uStack_9c;
        uStack_a8 = 0;
        puStack_b0 = &stack0x00000028;
        (**(code **)((uint)in_stack_00000020 & 0xfffffffe))();
      }
      else {
        uStack_9c = in_stack_00000028;
        uStack_98 = in_stack_0000002c;
        pcStack_94 = in_stack_00000030;
        puStack_90 = in_stack_00000034;
        uStack_8c = in_stack_00000038;
      }
    }
    uStack_a8 = 2;
    puStack_14 = (undefined *)&puStack_b0;
    if (in_stack_00000044 != (int *)0x0) {
      LOCK();
      in_stack_00000044[1] = in_stack_00000044[1] + 1;
      UNLOCK();
    }
    puStack_b0 = in_stack_00000040;
    piStack_ac = in_stack_00000044;
    uStack_8._0_1_ = 6;
    FUN_0054ef60(&param_2);
    uStack_8._0_1_ = 2;
    FUN_00a85f10(uVar5);
  }
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_0000001c) {
    uVar7 = in_stack_0000001c + 1;
    puVar6 = param_2;
    if (0xfff < uVar7) {
      puVar6 = (undefined4 *)param_2[-1];
      uVar7 = in_stack_0000001c + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar6))) {
        uStack_8c = CONCAT44(&UNK_00a87304,(undefined4)uStack_8c);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_8c = CONCAT44(uVar7,puVar6);
    puStack_90 = (undefined4 *)0xa87273;
    FUN_01674ea0();
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = (undefined4 *)((uint)param_2 & 0xffffff00);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  pcVar4 = in_stack_00000020;
  if (in_stack_00000020 != (code *)0x0) {
    if ((((uint)in_stack_00000020 & 1) == 0) &&
       (pcVar4 = *(code **)((uint)in_stack_00000020 & 0xfffffffe), pcVar4 != (code *)0x0)) {
      puStack_90 = &stack0x00000028;
      uStack_8c = CONCAT44(2,puStack_90);
      pcStack_94 = (char *)0xa872a9;
      pcVar4 = (code *)(*pcVar4)();
    }
    in_stack_00000020 = (code *)0x0;
  }
  piVar3 = in_stack_00000044;
  if (in_stack_00000044 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000044 + 1;
    iVar2 = *piVar1;
    pcVar4 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      uStack_8c = CONCAT44(0xa872cc,(undefined4)uStack_8c);
      pcVar4 = (code *)(**(code **)*in_stack_00000044)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_8c = CONCAT44(0xa872db,(undefined4)uStack_8c);
        pcVar4 = (code *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar4;
}



/* FUNCTION 21554 ; VA 0x00a87310 ; FUN_00a87310 */

void FUN_00a87310(undefined4 *param_1,undefined4 param_2,int param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  int iVar1;
  char cVar2;
  char cVar3;
  undefined4 uVar4;
  int *piVar5;
  byte *pbVar6;
  uint uVar7;
  int iVar8;
  undefined uStack0000005c;
  undefined4 *puVar9;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined uStack_c0;
  undefined uStack_bf;
  undefined auStack_a4 [24];
  undefined auStack_8c [32];
  undefined auStack_6c [4];
  uint uStack_68;
  undefined auStack_64 [4];
  uint uStack_60;
  undefined4 uStack_5c;
  uint uStack_58;
  undefined auStack_54 [16];
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined auStack_3c [8];
  int iStack_34;
  int iStack_30;
  undefined auStack_2c [12];
  undefined auStack_20 [8];
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5013;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff2c;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  uStack_5c = FUN_01675290(DAT_01eea9bc);
  uStack_8._0_1_ = 5;
  if (param_3 != 0) {
    piVar5 = (int *)FUN_0054db20();
    uVar4 = (**(code **)(*piVar5 + 4))();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("HTTP post exception: %s",uVar4);
  }
  if (param_1 == (undefined4 *)0x0) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("HTTP post response is null.");
  }
  FUN_016819e0(auStack_2c,param_1);
  uStack_8._0_1_ = 6;
  cVar2 = FUN_016816d0();
  if (cVar2 != '\0') {
    uVar4 = FUN_016814a0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Filter response parse error: %s",uVar4);
  }
  FUN_0167eea0(auStack_20,"success");
  cVar2 = FUN_0167e5c0();
  if (cVar2 != '\0') {
    FUN_0167eea0(auStack_20,"success");
    cVar2 = FUN_0167e3d0(0);
    if (cVar2 == '\0') {
      FUN_0167eea0(auStack_3c,PTR_s_message_01d66500);
      cVar2 = FUN_0167e580();
      if (cVar2 != '\0') {
        FUN_00a87827();
        return;
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Filter API returned failure with no message.");
    }
    FUN_0167eea0(auStack_20,&DAT_018be4a0);
    cVar2 = FUN_01681870();
    if (cVar2 != '\0') {
      FUN_0096be70();
      uStack_bf = uStack0000005c;
      uStack_c8 = param_5;
      uStack_c4 = param_6;
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      uStack_c0 = 0;
      FUN_0167eea0(auStack_3c,&DAT_018be4a0);
      FUN_0167eea0(auStack_20,PTR_s_AgeUnder13_01d664f8);
      cVar2 = FUN_0167e580();
      if (cVar2 != '\0') {
        FUN_0167eea0(auStack_6c,PTR_s_AgeUnder13_01d664f8);
        uVar4 = FUN_00563600(auStack_54);
        FUN_005511f0(uVar4);
        FUN_005507b0();
      }
      FUN_0167eea0(auStack_64,PTR_s_Age13OrOver_01d664fc);
      cVar3 = FUN_0167e580();
      if (cVar3 != '\0') {
        FUN_0167eea0(auStack_20,PTR_s_Age13OrOver_01d664fc);
        uVar4 = FUN_00563600(auStack_54);
        FUN_005511f0(uVar4);
        FUN_005507b0();
        if (cVar2 != '\0') {
          uStack_44 = 0;
          uStack_40 = 0xf;
          auStack_54[0] = 0;
          FUN_005542c0("FilteredContent (under13)",0x19);
          uStack_8._0_1_ = 8;
          FUN_00a89510(auStack_54,auStack_a4);
          uStack_8._0_1_ = 7;
          FUN_005507b0();
          uStack_44 = 0;
          uStack_40 = 0xf;
          auStack_54[0] = 0;
          FUN_005542c0("FilteredContent (13plus)",0x18);
          uStack_8._0_1_ = 9;
          FUN_00a89510(auStack_54,auStack_8c);
          uStack_8 = CONCAT31(uStack_8._1_3_,7);
          FUN_005507b0();
          FUN_00a87870(&stack0x0000005c,&stack0x0000001c);
          iVar1 = _uStack0000005c;
          iVar8 = iStack_18;
          if (_uStack0000005c != 0) {
            iVar8 = *(int *)(_uStack0000005c + 0x28);
            _uStack0000005c = *(int *)(_uStack0000005c + 0x2c);
            for (; iVar8 != _uStack0000005c; iVar8 = iVar8 + 0x20) {
              FUN_008927d0(&uStack_c8);
            }
            FUN_00a83700(&stack0x0000005c,iVar1);
            iVar8 = iStack_18;
          }
          uStack_68 = -(uint)(DAT_01d66388 != 0) & DAT_01d66388 - 1U;
          if (uStack_68 < *(uint *)(iVar8 + 0xf4)) {
            do {
              iVar1 = *(int *)(*(int *)(iVar8 + 0xf0) + 4);
              iStack_30 = iVar1 + 8;
              pbVar6 = (byte *)(iVar8 + 0xf8) + *(byte *)(iVar8 + 0xf8) + 1;
              uStack_60 = -(uint)(pbVar6 != (byte *)0x0) & (uint)(pbVar6 + 1);
              _uStack0000005c = FUN_005702d0(iStack_30);
              uStack_58 = _uStack0000005c + 0x9e3779b9;
              uVar7 = *(uint *)(iStack_30 + 0x1c);
              if (((int)uVar7 < 1) && ((int)uVar7 < 0)) {
                uVar7 = ~uVar7;
              }
              FUN_00a77880(&iStack_34,
                           (uStack_58 >> 2) + 0x2c15e7f9 +
                           ((uVar7 >> 2) + uVar7 * 0x40 + *(int *)(iVar1 + 0x20) ^ uVar7) +
                           _uStack0000005c * 0x40 ^ uStack_58,iStack_30,uStack_60);
              if (iStack_34 != 0) {
                FUN_00a8b2f0(&iStack_34);
              }
            } while (uStack_68 < *(uint *)(iVar8 + 0xf4));
          }
          puVar9 = &uStack_c8;
          uVar4 = 0;
          (**(code **)(*(int *)(iVar8 + 0xec) + 8))(&stack0x0000001c,puVar9,0);
          FUN_008927d0(&uStack_c8);
          FUN_0054ef60(&stack0x0000001c);
          FUN_00a800e0(&uStack_c8);
          FUN_0096d5e0();
          FUN_0167ec40();
          FUN_00a8774a(puVar9,uVar4);
          return;
        }
      }
      if (DAT_01eea9ac != '\0') {
        if (0xf < (uint)param_1[5]) {
          param_1 = (undefined4 *)*param_1;
        }
        FUN_01677650(DAT_01eea9ac,"ChatService response did not include Under13/Over13 (%s)",param_1
                    );
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Filter response did not contain expected variants.");
    }
    if (DAT_01eea9ac != '\0') {
      if (0xf < (uint)param_1[5]) {
        param_1 = (undefined4 *)*param_1;
      }
      FUN_01677650(DAT_01eea9ac,"ChatService response invalid format no member data (%s)",param_1);
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Filter response does not contain member \"data\"");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Filter response does not contain member \"success\"");
}



/* FUNCTION 21555 ; VA 0x00a876fc ; Catch@00a876fc */

undefined * Catch_00a876fc(void)

{
  int *piVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  piVar1 = *(int **)(unaff_EBP + -0x6c);
  uVar2 = (**(code **)(*piVar1 + 4))(0,0,0);
  FUN_0087c450(&DAT_018c5f98,"ChatFailure",uVar2);
  (**(code **)(*piVar1 + 4))();
  FUN_0054f510(unaff_EBP + 0x40);
  FUN_00a84440();
  return &DAT_00a87747;
}



/* FUNCTION 21556 ; VA 0x00a8774a ; FUN_00a8774a */

void FUN_00a8774a(void)

{
  int unaff_EBP;
  
  *(undefined4 *)(unaff_EBP + -4) = 4;
  *(undefined *)(unaff_EBP + -4) = 0xc;
  FUN_01675290();
  FUN_00550b30();
  FUN_00550b30();
  FUN_005507b0();
  FUN_00550990();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 21557 ; VA 0x00a87827 ; FUN_00a87827 */

void FUN_00a87827(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  FUN_0167eea0(unaff_EBP + -0x1c,PTR_s_message_01d66500);
  FUN_00563600(unaff_EBP + -0x50);
  *(undefined *)(unaff_EBP + -4) = 10;
  uVar1 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Filter API returned failure with message: %s",uVar1);
}



/* FUNCTION 21558 ; VA 0x00a87870 ; FUN_00a87870 */

undefined4 __thiscall FUN_00a87870(byte *param_1,undefined4 param_2,int param_3)

{
  byte bVar1;
  int iVar2;
  uint uVar3;
  
  bVar1 = *param_1;
  iVar2 = FUN_005702d0(param_3);
  uVar3 = *(uint *)(param_3 + 0x1c);
  if (((int)uVar3 < 1) && ((int)uVar3 < 0)) {
    uVar3 = ~uVar3;
  }
  FUN_00a77880(param_2,(iVar2 + 0x9e3779b9U >> 2) + 0x2c15e7f9 +
                       ((uVar3 >> 2) + uVar3 * 0x40 + *(int *)(param_3 + 0x18) ^ uVar3) +
                       iVar2 * 0x40 ^ iVar2 + 0x9e3779b9U,param_3,
               -(uint)(param_1 + bVar1 + 1 != (byte *)0x0) & (uint)(param_1 + bVar1 + 1 + 1));
  return param_2;
}



/* FUNCTION 21559 ; VA 0x00a87900 ; FUN_00a87900 */

/* WARNING: Removing unreachable block (ram,0x00a879e0) */
/* WARNING: Removing unreachable block (ram,0x00a879ec) */
/* WARNING: Removing unreachable block (ram,0x00a879fa) */

undefined4
FUN_00a87900(undefined4 param_1,undefined4 param_2,int param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,uint param_9,
            undefined4 param_10,undefined4 param_11)

{
  undefined8 uVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  undefined4 in_stack_ffffffc8;
  undefined4 in_stack_ffffffcc;
  undefined4 in_stack_ffffffd0;
  undefined8 in_stack_ffffffd4;
  undefined4 in_stack_ffffffdc;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar2 = param_10;
  puStack_c = &LAB_017e5030;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar5 = param_10;
  FUN_0054ef60(&param_4);
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) + 1;
    UNLOCK();
  }
  FUN_00a87dd0(param_1,param_2,param_3,in_stack_ffffffc8,in_stack_ffffffcc,in_stack_ffffffd0,
               in_stack_ffffffd4,in_stack_ffffffdc,uVar5);
  uVar3 = param_4;
  uVar1 = CONCAT44(param_9,param_8);
  param_8 = 0;
  param_9 = 0xf;
  param_4 = param_4 & 0xffffff00;
  uVar2 = FUN_00a8bcc0(param_1,param_2,param_3,uVar3,param_5,param_6,param_7,uVar1,uVar2,param_11);
  if (0xf < param_9) {
    uVar4 = param_9 + 1;
    uVar3 = param_4;
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(param_4 - 4);
      uVar4 = param_9 + 0x24;
      if (0x1f < (param_4 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uVar2 = FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 21560 ; VA 0x00a87a50 ; FUN_00a87a50 */

/* WARNING: Removing unreachable block (ram,0x00a87c28) */
/* WARNING: Removing unreachable block (ram,0x00a87be6) */
/* WARNING: Removing unreachable block (ram,0x00a87ba0) */
/* WARNING: Removing unreachable block (ram,0x00a87b5a) */
/* WARNING: Removing unreachable block (ram,0x00a87b68) */
/* WARNING: Removing unreachable block (ram,0x00a87c60) */
/* WARNING: Removing unreachable block (ram,0x00a87b7c) */
/* WARNING: Removing unreachable block (ram,0x00a87bae) */
/* WARNING: Removing unreachable block (ram,0x00a87c65) */
/* WARNING: Removing unreachable block (ram,0x00a87bc2) */
/* WARNING: Removing unreachable block (ram,0x00a87bf4) */
/* WARNING: Removing unreachable block (ram,0x00a87c6a) */
/* WARNING: Removing unreachable block (ram,0x00a87c04) */
/* WARNING: Removing unreachable block (ram,0x00a87c36) */
/* WARNING: Removing unreachable block (ram,0x00a87c6f) */
/* WARNING: Removing unreachable block (ram,0x00a87c46) */

void FUN_00a87a50(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
                 undefined4 param_17,undefined4 param_18,undefined4 param_19,undefined4 param_20,
                 undefined4 param_21,undefined4 param_22,undefined4 param_23,undefined4 param_24,
                 undefined4 param_25)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5060;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  FUN_00a7dae0(param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6),param_8,param_9,param_10,
               param_11,CONCAT44(param_13,param_12),param_14,param_15,param_16,param_17,
               CONCAT44(param_19,param_18),param_20,param_21,param_22,param_23,
               CONCAT44(param_25,param_24));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21561 ; VA 0x00a87c80 ; FUN_00a87c80 */

/* WARNING: Removing unreachable block (ram,0x00a87d90) */
/* WARNING: Removing unreachable block (ram,0x00a87d44) */
/* WARNING: Removing unreachable block (ram,0x00a87d4d) */
/* WARNING: Removing unreachable block (ram,0x00a87d5c) */
/* WARNING: Removing unreachable block (ram,0x00a87d6a) */
/* WARNING: Removing unreachable block (ram,0x00a87d73) */
/* WARNING: Removing unreachable block (ram,0x00a87d81) */
/* WARNING: Removing unreachable block (ram,0x00a87d9e) */
/* WARNING: Removing unreachable block (ram,0x00a87dca) */
/* WARNING: Removing unreachable block (ram,0x00a87dae) */

undefined4
FUN_00a87c80(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5088;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a7dd50(param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,
                       CONCAT44(param_11,param_10));
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 21562 ; VA 0x00a87dd0 ; FUN_00a87dd0 */

/* WARNING: Removing unreachable block (ram,0x00a87e90) */
/* WARNING: Removing unreachable block (ram,0x00a87e67) */
/* WARNING: Removing unreachable block (ram,0x00a87e73) */
/* WARNING: Removing unreachable block (ram,0x00a87e81) */
/* WARNING: Removing unreachable block (ram,0x00a87e9e) */
/* WARNING: Removing unreachable block (ram,0x00a87eca) */
/* WARNING: Removing unreachable block (ram,0x00a87eae) */

undefined4
FUN_00a87dd0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5030;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a7df40(param_2,param_3,param_4,param_5,param_6,param_7,CONCAT44(param_9,param_8),
                       param_10);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 21563 ; VA 0x00a87ed0 ; FUN_00a87ed0 */

/* WARNING: Removing unreachable block (ram,0x00a88100) */
/* WARNING: Removing unreachable block (ram,0x00a880be) */
/* WARNING: Removing unreachable block (ram,0x00a88078) */
/* WARNING: Removing unreachable block (ram,0x00a88032) */
/* WARNING: Removing unreachable block (ram,0x00a88009) */
/* WARNING: Removing unreachable block (ram,0x00a88015) */
/* WARNING: Removing unreachable block (ram,0x00a88023) */
/* WARNING: Removing unreachable block (ram,0x00a88040) */
/* WARNING: Removing unreachable block (ram,0x00a8813a) */
/* WARNING: Removing unreachable block (ram,0x00a88054) */
/* WARNING: Removing unreachable block (ram,0x00a88086) */
/* WARNING: Removing unreachable block (ram,0x00a8813f) */
/* WARNING: Removing unreachable block (ram,0x00a8809a) */
/* WARNING: Removing unreachable block (ram,0x00a880cc) */
/* WARNING: Removing unreachable block (ram,0x00a88144) */
/* WARNING: Removing unreachable block (ram,0x00a880dc) */
/* WARNING: Removing unreachable block (ram,0x00a8810e) */
/* WARNING: Removing unreachable block (ram,0x00a88149) */
/* WARNING: Removing unreachable block (ram,0x00a8811e) */

void FUN_00a87ed0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
                 undefined4 param_17,undefined4 param_18,undefined4 param_19,undefined4 param_20,
                 undefined4 param_21,undefined4 param_22,undefined4 param_23,undefined4 param_24,
                 undefined4 param_25,undefined4 param_26,undefined4 param_27,undefined4 param_28)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e4898;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  ExceptionList = &pvStack_10;
  FUN_00a7e0d0(param_2,param_3,param_4,param_5,param_6,param_7,CONCAT44(param_9,param_8),param_10,
               param_11,param_12,param_13,param_14,CONCAT44(param_16,param_15),param_17,param_18,
               param_19,param_20,CONCAT44(param_22,param_21),param_23,param_24,param_25,param_26,
               CONCAT44(param_28,param_27));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21564 ; VA 0x00a88150 ; FUN_00a88150 */

void FUN_00a88150(undefined4 param_1,undefined4 param_2,int param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc3b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005caf00(&param_2);
  FUN_00a7e3a0();
  uStack_8 = 1;
  if (param_3 != 0) {
    (**(code **)(param_3 + 8))(&stack0x00000010);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21565 ; VA 0x00a881c0 ; FUN_00a881c0 */

void FUN_00a881c0(undefined4 param_1,undefined4 param_2)

{
  FUN_00a77bb0(param_1,param_2,param_2);
  return;
}



/* FUNCTION 21566 ; VA 0x00a881e0 ; FUN_00a881e0 */

void FUN_00a881e0(undefined4 param_1,undefined4 param_2)

{
  FUN_00a77cf0(param_1,param_2,param_2);
  return;
}



/* FUNCTION 21567 ; VA 0x00a88200 ; FUN_00a88200 */

void FUN_00a88200(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e50a8;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(*param_2 + 0x1a0);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00a8cb50();
  if (iVar2 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  iVar2 = *param_2;
  iVar3 = *(int *)(iVar2 + 0xd0);
  iVar4 = FUN_0088cb40();
  if (iVar3 == iVar4) {
    iVar3 = iVar2 + 0xd8;
    if (*(int *)(iVar2 + 0xd4) == 0) {
      iVar3 = 0;
    }
    FUN_0054ef60(iVar3);
    param_2 = (int *)*param_2;
    uStack_8 = 0;
    iVar2 = *param_2;
    iVar3 = FUN_0088cdc0();
    if (iVar2 == iVar3) {
      piVar5 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar5 = (int *)0x0;
      }
      if (piVar5[1] != 0) {
        LOCK();
        piVar1 = (int *)(piVar5[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      uStack_8 = 0xffffffff;
      FUN_00a87dd0(param_1,*piVar5,piVar5[1]);
      ExceptionList = pvStack_10;
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0();
}



/* FUNCTION 21568 ; VA 0x00a88300 ; FUN_00a88300 */

void FUN_00a88300(undefined4 param_1,undefined4 param_2)

{
  FUN_00a779d0(param_1,param_2,param_2);
  return;
}



/* FUNCTION 21569 ; VA 0x00a88320 ; FUN_00a88320 */

void FUN_00a88320(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iStack_e0;
  undefined4 *puStack_dc;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00888410();
  if (iVar1 == iVar2) {
    piVar4 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar4 = (int *)0x0;
    }
    iStack_e0 = *piVar4;
    puStack_dc = (undefined4 *)0x0;
    puVar3 = (undefined4 *)piVar4[1];
    if (puVar3 != (undefined4 *)0x0) {
      (*(code *)*puVar3)(piVar4 + 2,auStack_d8);
      puVar3 = (undefined4 *)piVar4[1];
    }
    uStack_8 = 0;
    puStack_dc = puVar3;
    FUN_005caf00(&iStack_e0);
    FUN_00a7e3a0();
    uStack_8 = 1;
    if (puStack_dc != (undefined4 *)0x0) {
      (*(code *)puStack_dc[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 21570 ; VA 0x00a88400 ; FUN_00a88400 */

undefined4 * FUN_00a88400(undefined4 *param_1,int *param_2,int *param_3)

{
  char cVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [4];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c88f3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = (**(code **)*param_2)();
  if (1 < uVar2) {
    uStack_18 = 0;
    uStack_14 = 0;
    uStack_8 = 0;
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8._0_1_ = 1;
    cVar1 = (**(code **)(*param_2 + 4))(2,&uStack_ec);
    if (cVar1 != '\0') {
      puVar3 = (undefined4 *)FUN_0088a3d0();
      iVar4 = puVar3[1];
      *param_1 = 0;
      param_1[1] = 0;
      if (iVar4 != 0) {
        LOCK();
        *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
        UNLOCK();
        iVar4 = puVar3[1];
      }
      *param_1 = *puVar3;
      param_1[1] = iVar4;
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return param_1;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
    FUN_00550b30();
  }
  puVar3 = (undefined4 *)*param_3;
  if (puVar3 != (undefined4 *)0x0) {
    iVar4 = puVar3[1];
    *param_1 = 0;
    param_1[1] = 0;
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 4) = *(int *)(iVar4 + 4) + 1;
      UNLOCK();
      iVar4 = puVar3[1];
    }
    *param_1 = *puVar3;
    param_1[1] = iVar4;
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 21571 ; VA 0x00a88590 ; FUN_00a88590 */

void __thiscall FUN_00a88590(undefined4 *param_1,int param_2,undefined4 *param_3,int param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int aiStack_14c [5];
  uint uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  int iStack_12c;
  int iStack_cc;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined uStack_bc;
  undefined uStack_bb;
  uint uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  uint uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined auStack_1c [4];
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e50fc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_00a87870(&iStack_14,param_2);
  if (iStack_14 != 0) {
    piVar1 = *(int **)(iStack_14 + 0x28);
    piVar2 = (int *)**(int **)((int)param_1 + 4);
    if (((piVar1 != *(int **)((int)param_1 + 4)) && (iVar5 = *piVar1, piVar2 != piVar1)) &&
       (piVar2 != (int *)iVar5)) {
      *(int *)piVar1[1] = iVar5;
      **(int **)(iVar5 + 4) = (int)piVar2;
      *(int **)piVar2[1] = piVar1;
      iVar3 = piVar2[1];
      piVar2[1] = *(undefined4 *)(iVar5 + 4);
      *(int *)(iVar5 + 4) = piVar1[1];
      piVar1[1] = iVar3;
      param_1 = puStack_18;
    }
    FUN_00a8b2f0(&iStack_14);
  }
  iStack_cc = param_4;
  puStack_18 = &uStack_c4;
  uStack_c4 = *param_3;
  uStack_c0 = param_3[1];
  uStack_bc = *(undefined *)(param_3 + 2);
  uStack_bb = *(undefined *)((int)param_3 + 9);
  FUN_0054ef60(param_3 + 3);
  uStack_8 = 0;
  FUN_0054ef60(param_3 + 9);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_3 + 0xf);
  uStack_8 = 2;
  FUN_0054ef60(param_2);
  uStack_134 = *(undefined4 *)(param_2 + 0x18);
  uStack_130 = *(undefined4 *)(param_2 + 0x1c);
  iStack_12c = iStack_cc;
  FUN_00a7bf40(&uStack_c4);
  uStack_8._0_1_ = 3;
  iVar5 = **(int **)((int)param_1 + 4);
  puStack_18 = *(undefined4 **)(iVar5 + 4);
  uVar4 = FUN_00a75430(iVar5,puStack_18,aiStack_14c);
  if (*(char **)((int)param_1 + 8) != s___AV__GetSetImpl_P8CustomParticl_01e1e1e0) {
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    *(char **)((int)param_1 + 8) = *(char **)((int)param_1 + 8) + 1;
    *(undefined4 *)(iVar5 + 4) = uVar4;
    *puStack_18 = uVar4;
    FUN_0096d5e0();
    if (0xf < uStack_138) {
      uVar6 = uStack_138 + 1;
      iVar5 = aiStack_14c[0];
      if (0xfff < uVar6) {
        iVar5 = *(int *)(aiStack_14c[0] + -4);
        uVar6 = uStack_138 + 0x24;
        if (0x1f < (aiStack_14c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar6);
    }
    uStack_8 = 0xffffffff;
    FUN_0096d5e0();
    uVar4 = **(undefined4 **)((int)param_1 + 4);
    FUN_0054ef60(param_2);
    uStack_6c = uStack_44;
    uStack_54 = *(undefined4 *)(param_2 + 0x18);
    uStack_50 = *(undefined4 *)(param_2 + 0x1c);
    uStack_44 = uStack_44 & 0xffffff00;
    uStack_68 = uStack_40;
    uStack_64 = uStack_3c;
    uStack_60 = uStack_38;
    uStack_58 = uStack_30;
    uStack_34 = 0;
    uStack_30 = 0xf;
    uStack_8 = 5;
    uStack_4c = uVar4;
    uStack_2c = uStack_54;
    uStack_28 = uStack_50;
    uStack_24 = uVar4;
    FUN_00a77690(auStack_1c,&uStack_6c,&uStack_6c);
    if (0xf < uStack_58) {
      uVar7 = uStack_58 + 1;
      uVar6 = uStack_6c;
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(uStack_6c - 4);
        uVar7 = uStack_58 + 0x24;
        if (0x1f < (uStack_6c - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    *(int *)((int)param_1 + 0x24) = *(int *)((int)param_1 + 0x24) + param_4;
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 21572 ; VA 0x00a88840 ; FUN_00a88840 */

int * __thiscall FUN_00a88840(int param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  
  FUN_00a87870(param_2,param_3);
  if (*param_2 != 0) {
    piVar1 = *(int **)(*param_2 + 0x28);
    piVar2 = (int *)**(int **)(param_1 + 4);
    if (((piVar1 != *(int **)(param_1 + 4)) && (iVar3 = *piVar1, piVar2 != piVar1)) &&
       (piVar2 != (int *)iVar3)) {
      *(int *)piVar1[1] = iVar3;
      **(int **)(iVar3 + 4) = (int)piVar2;
      *(int **)piVar2[1] = piVar1;
      iVar4 = piVar2[1];
      piVar2[1] = *(undefined4 *)(iVar3 + 4);
      *(int *)(iVar3 + 4) = piVar1[1];
      piVar1[1] = iVar4;
    }
  }
  return param_2;
}



/* FUNCTION 21573 ; VA 0x00a888a0 ; FUN_00a888a0 */

void FUN_00a888a0(int *param_1,int param_2)

{
  char cVar1;
  char *pcVar2;
  int iVar3;
  char *pcVar4;
  uint uVar5;
  uint in_stack_0000001c;
  undefined uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pcVar2 = *(char **)(*param_1 + 0x20);
  uVar6 = 0;
  pcVar4 = pcVar2;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(pcVar2,(int)pcVar4 - (int)(pcVar2 + 1));
  FUN_005e65e0(uVar6);
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar3 = param_2;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(param_2 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21574 ; VA 0x00a88950 ; FUN_00a88950 */

void FUN_00a88950(int *param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  uint uVar4;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c47f8;
  pvStack_10 = ExceptionList;
  puVar2 = (undefined4 *)*param_1;
  pcVar3 = (code *)*puVar2;
  uStack_3c = 0;
  uVar4 = puVar2[0xc];
  ExceptionList = &pvStack_10;
  if (uVar4 != 0) {
    uStack_3c = uVar4;
    if ((uVar4 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = puVar2 + 0xe;
      uStack_4c = 0xa889b6;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar4 & 0xfffffffe))();
    }
    else {
      uStack_34 = puVar2[0xe];
      uStack_30 = puVar2[0xf];
      uStack_2c = puVar2[0x10];
      uStack_28 = puVar2[0x11];
      uStack_24 = *(undefined8 *)(puVar2 + 0x12);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar4 = puVar2[4];
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      (**(code **)(uVar4 & 0xfffffffe))(puVar2 + 6,&uStack_54,0);
    }
    else {
      uStack_54 = puVar2[6];
      uStack_50 = puVar2[7];
      uStack_4c = puVar2[8];
      puStack_48 = (undefined4 *)puVar2[9];
      uStack_44 = *(ulonglong *)(puVar2 + 10);
    }
  }
  if (puVar2[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  (*pcVar3)(param_2,puVar2[2],puVar2[3]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21575 ; VA 0x00a88a50 ; FUN_00a88a50 */

void FUN_00a88a50(int *param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  uint uVar4;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined uStack_70;
  undefined uStack_6f;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e512e;
  pvStack_10 = ExceptionList;
  puVar2 = (undefined4 *)*param_1;
  pcVar3 = (code *)*puVar2;
  uStack_78 = puVar2[0xc];
  uStack_74 = puVar2[0xd];
  uStack_70 = *(undefined *)(puVar2 + 0xe);
  uStack_6f = *(undefined *)((int)puVar2 + 0x39);
  uStack_80 = CONCAT44(puVar2 + 0xf,0xa88aa7);
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8 = 0;
  uStack_80 = CONCAT44(puVar2 + 0x15,0xa88aba);
  FUN_0054ef60();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_80 = CONCAT44(puVar2 + 0x1b,0xa88aca);
  FUN_0054ef60();
  uStack_8 = 2;
  uVar4 = puVar2[4];
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      (**(code **)(uVar4 & 0xfffffffe))(puVar2 + 6,&uStack_90,0);
    }
    else {
      uStack_90 = puVar2[6];
      uStack_8c = puVar2[7];
      uStack_88 = puVar2[8];
      uStack_84 = puVar2[9];
      uStack_80 = *(undefined8 *)(puVar2 + 10);
    }
  }
  if (puVar2[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[3] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  (*pcVar3)(param_2,puVar2[2],puVar2[3]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21576 ; VA 0x00a88b60 ; FUN_00a88b60 */

void FUN_00a88b60(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  int iStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c47f8;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  uStack_3c = 0;
  uVar3 = *(uint *)(iVar2 + 0x38);
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    uStack_3c = uVar3;
    if ((uVar3 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      iStack_48 = iVar2 + 0x40;
      uStack_4c = 0xa88bc7;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_34 = *(undefined4 *)(iVar2 + 0x40);
      uStack_30 = *(undefined4 *)(iVar2 + 0x44);
      uStack_2c = *(undefined4 *)(iVar2 + 0x48);
      uStack_28 = *(undefined4 *)(iVar2 + 0x4c);
      uStack_24 = *(undefined8 *)(iVar2 + 0x50);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar3 = *(uint *)(iVar2 + 0x18);
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(iVar2 + 0x20,&uStack_54,0);
    }
    else {
      uStack_54 = *(undefined4 *)(iVar2 + 0x20);
      uStack_50 = *(undefined4 *)(iVar2 + 0x24);
      uStack_4c = *(undefined4 *)(iVar2 + 0x28);
      iStack_48 = *(int *)(iVar2 + 0x2c);
      uStack_44 = *(ulonglong *)(iVar2 + 0x30);
    }
  }
  if (*(int *)(iVar2 + 0x14) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar2 + 0x14) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  FUN_00a74ce0(iVar2 + 8,param_2,*(undefined4 *)(iVar2 + 0x10),*(undefined4 *)(iVar2 + 0x14));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21577 ; VA 0x00a88c60 ; FUN_00a88c60 */

void FUN_00a88c60(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5150;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  ExceptionList = &pvStack_10;
  if (*(int *)(iVar2 + 0x4c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar2 + 0x4c) + 4);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_28 = *(undefined4 *)(iVar2 + 0x48);
  uStack_24 = *(undefined4 *)(iVar2 + 0x4c);
  uStack_8 = 0;
  uVar3 = *(uint *)(iVar2 + 0x28);
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(iVar2 + 0x30,&uStack_40,0);
    }
    else {
      uStack_40 = *(undefined4 *)(iVar2 + 0x30);
      uStack_3c = *(undefined4 *)(iVar2 + 0x34);
      uStack_38 = *(undefined4 *)(iVar2 + 0x38);
      uStack_34 = *(undefined4 *)(iVar2 + 0x3c);
      uStack_30 = *(undefined8 *)(iVar2 + 0x40);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(iVar2 + 0x10);
  uStack_8 = 0xffffffff;
  FUN_00a74e60(iVar2 + 8,param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21578 ; VA 0x00a88d40 ; FUN_00a88d40 */

void FUN_00a88d40(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  iVar2 = *param_1;
  FUN_0054ef60(iVar2 + 0x20);
  if (*(int *)(iVar2 + 0x1c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar2 + 0x1c) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar3 = *(undefined4 *)(iVar2 + 0x18);
  uVar4 = *(undefined4 *)(iVar2 + 0x1c);
  if (*(int *)(iVar2 + 0x14) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar2 + 0x14) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00a74fe0(iVar2 + 8,param_2,*(undefined4 *)(iVar2 + 0x10),*(undefined4 *)(iVar2 + 0x14),uVar3,
               uVar4);
  return;
}



/* FUNCTION 21579 ; VA 0x00a88dc0 ; FUN_00a88dc0 */

void FUN_00a88dc0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  uVar1 = *param_1;
  param_1 = (undefined4 *)param_2;
  FUN_00a74960(param_2,uVar1,&param_1,0);
  return;
}



/* FUNCTION 21580 ; VA 0x00a88df0 ; FUN_00a88df0 */

void FUN_00a88df0(int *param_1,int param_2)

{
  int *piVar1;
  undefined uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  iVar5 = *param_1;
  uVar2 = *(undefined *)(iVar5 + 0x10);
  ExceptionList = &pvStack_10;
  FUN_0054ef60(iVar5 + 0x24);
  if (*(int *)(iVar5 + 0x20) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar5 + 0x20) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar3 = *(undefined4 *)(iVar5 + 0x1c);
  uVar4 = *(undefined4 *)(iVar5 + 0x20);
  if (*(int *)(iVar5 + 0x18) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar5 + 0x18) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00a74fe0(iVar5 + 8,uVar2,*(undefined4 *)(iVar5 + 0x14),*(undefined4 *)(iVar5 + 0x18),uVar3,
               uVar4);
  if (0xf < in_stack_0000001c) {
    uVar6 = in_stack_0000001c + 1;
    iVar5 = param_2;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(param_2 + -4);
      uVar6 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21581 ; VA 0x00a88ed0 ; FUN_00a88ed0 */

void FUN_00a88ed0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  uVar1 = *param_1;
  param_1 = (undefined4 *)param_2;
  FUN_00a74b20(param_2,uVar1,&param_1,0);
  return;
}



/* FUNCTION 21582 ; VA 0x00a88f00 ; FUN_00a88f00 */

void FUN_00a88f00(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00a7d740(param_2,param_3);
  return;
}



/* FUNCTION 21583 ; VA 0x00a88f20 ; FUN_00a88f20 */

/* WARNING: Removing unreachable block (ram,0x00a88fad) */
/* WARNING: Removing unreachable block (ram,0x00a88fb6) */
/* WARNING: Removing unreachable block (ram,0x00a88fc5) */
/* WARNING: Removing unreachable block (ram,0x00a88fd3) */
/* WARNING: Removing unreachable block (ram,0x00a88fdc) */
/* WARNING: Removing unreachable block (ram,0x00a88fea) */

undefined4
FUN_00a88f20(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c47e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a7d960(param_2,param_3,param_4,param_5);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 21584 ; VA 0x00a89010 ; FUN_00a89010 */

undefined4 * __thiscall
FUN_00a89010(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined4 uVar4;
  char cVar5;
  int iVar6;
  undefined4 uStack_68;
  int iStack_64;
  undefined4 auStack_60 [5];
  undefined4 uStack_4c;
  undefined **ppuStack_48;
  undefined4 *puStack_44;
  undefined4 *puStack_40;
  char *pcStack_3c;
  undefined4 auStack_2c [3];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5190;
  pvStack_10 = ExceptionList;
  pcStack_3c = (char *)&uStack_20;
  uStack_8 = 0;
  puStack_40 = (undefined4 *)0xa89040;
  ExceptionList = &pvStack_10;
  FUN_00a77950();
  puVar2 = param_3;
  uStack_8._0_1_ = 1;
  if (DAT_01d66470 == '\0') {
LAB_00a89050:
    piVar3 = param_5;
    *param_2 = uStack_20;
    param_2[1] = uStack_1c;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar6 = param_5[1] + -1;
      param_5[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        pcStack_3c = (char *)0xa89077;
        (**(code **)*param_5)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar6 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          pcStack_3c = (char *)0xa89086;
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar6 = (int)param_1 + *(byte *)(param_1 + 0x46) + 0x119;
  pcStack_3c = (char *)(-(uint)(iVar6 != 0) & iVar6 + 1U);
  puStack_40 = &param_3;
  puStack_44 = param_3;
  ppuStack_48 = &puStack_14;
  uStack_4c = 0xa890ce;
  FUN_00606ea0();
  uVar4 = uStack_20;
  if (puStack_14 == (undefined *)0x0) goto LAB_00a89050;
  if (((uint)puVar2 & 0xfffffff0) == 0) {
    pcStack_3c = (char *)0x1;
    puStack_44 = (undefined4 *)0xa890e7;
    puStack_40 = param_1;
    cVar5 = FUN_0097c970();
    if (cVar5 == '\0') {
      puStack_40 = auStack_2c;
      pcStack_3c = "Chat client callbacks can only be called from a local script.";
      puStack_44 = (undefined4 *)0xa891f4;
      FUN_016756b0();
      puStack_40 = auStack_2c;
      pcStack_3c = "";
                    /* WARNING: Subroutine does not return */
      puStack_44 = (undefined4 *)0xa89205;
      FUN_0170c2a8();
    }
    puStack_14 = (undefined *)&puStack_40;
    puStack_44 = &param_4;
    ppuStack_48 = (undefined **)0xa89106;
    param_3 = puVar2;
    FUN_00557fc0();
    puStack_44 = &param_3;
    uStack_8._0_1_ = 2;
    ppuStack_48 = (undefined **)0xa89119;
    iStack_64 = FUN_00a7d290();
    param_3 = auStack_60;
    iStack_64 = iStack_64 + 4;
    uStack_68 = 0xa8912a;
    FUN_00d88580();
    uStack_8._0_1_ = 3;
  }
  else {
    if (((uint)puVar2 & 0xfffffff0) != 0x10) {
      uStack_20 = 0;
      *param_2 = uVar4;
      param_2[1] = uStack_1c;
      uStack_1c = 0;
      goto LAB_00a891c1;
    }
    pcStack_3c = (char *)0x1;
    puStack_44 = (undefined4 *)0xa8915c;
    puStack_40 = param_1;
    cVar5 = FUN_00971ce0();
    if (cVar5 == '\0') {
      puStack_40 = auStack_2c;
      pcStack_3c = "Chat server callbacks can only be called from a server script.";
      puStack_44 = (undefined4 *)0xa89213;
      FUN_016756b0();
      puStack_40 = auStack_2c;
      pcStack_3c = "";
                    /* WARNING: Subroutine does not return */
      puStack_44 = (undefined4 *)&UNK_00a89224;
      FUN_0170c2a8();
    }
    puStack_18 = (undefined *)&puStack_40;
    puStack_44 = &param_4;
    ppuStack_48 = (undefined **)0xa8917b;
    param_3 = puVar2;
    FUN_00557fc0();
    puStack_44 = &param_3;
    uStack_8._0_1_ = 4;
    ppuStack_48 = (undefined **)0xa8918e;
    iStack_64 = FUN_00a7d290();
    param_3 = auStack_60;
    iStack_64 = iStack_64 + 4;
    uStack_68 = 0xa8919f;
    FUN_00d88580();
    uStack_8._0_1_ = 5;
  }
  FUN_0060e0c0(&uStack_68,param_1);
  uStack_8._0_1_ = 1;
  FUN_00a89230(param_2);
LAB_00a891c1:
  pcStack_3c = (char *)0xa891c9;
  FUN_00550b30();
  pcStack_3c = (char *)0xa891d1;
  FUN_00550b30();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21585 ; VA 0x00a89230 ; FUN_00a89230 */

undefined4 * FUN_00a89230(undefined4 *param_1,int *param_2,int *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  undefined4 *puVar8;
  int *in_stack_00000024;
  undefined4 in_stack_00000030;
  int *in_stack_00000034;
  undefined auStack_38 [8];
  int *piStack_30;
  int *piStack_2c;
  int *piStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e51e1;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffbc;
  uStack_1c = 0;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  FUN_00a77950(param_1);
  piVar4 = in_stack_00000024;
  uStack_1c = 1;
  piStack_30 = (int *)0x0;
  piStack_2c = (int *)0x0;
  if (param_3 != (int *)0x0) {
    piVar1 = param_3 + 1;
    iVar7 = *piVar1;
    while (iVar7 != 0) {
      LOCK();
      iVar6 = *piVar1;
      if (iVar7 == iVar6) {
        *piVar1 = iVar7 + 1;
        iVar6 = iVar7;
      }
      UNLOCK();
      if (iVar6 == iVar7) {
        piStack_30 = param_2;
        piStack_2c = param_3;
        break;
      }
      iVar7 = *piVar1;
    }
  }
  piVar1 = piStack_2c;
  uStack_8._0_1_ = 4;
  if (piStack_30 != (int *)0x0) {
    piStack_20 = in_stack_00000024;
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + 1;
    UNLOCK();
    piStack_24 = in_stack_00000024;
    if (in_stack_00000024 != (int *)0x0) {
      LOCK();
      *in_stack_00000024 = *in_stack_00000024 + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 5;
    if (in_stack_00000024 != (int *)0x0) {
      if (in_stack_00000024[2] != 0) {
        piStack_18 = (int *)piStack_30[0xd];
        piVar5 = piStack_30;
        if ((piStack_18 != (int *)0x0) && (piVar5 = piStack_18, piStack_18[0xd] != 0)) {
          piVar5 = (int *)FUN_005c8ac0();
        }
        piStack_18 = piVar5;
        if (((piStack_18 != (int *)0x0) &&
            (iVar7 = piStack_18[3], iVar6 = FUN_008a8c30(),
            (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
            (uint)*(ushort *)(iVar6 + 0x1da))) && (iVar7 = FUN_0055ea10(), iVar7 != 0)) {
          uStack_8._0_1_ = 6;
          puVar8 = (undefined4 *)FUN_0094b750(auStack_38,&stack0x00000010,in_stack_00000030);
          uVar2 = *puVar8;
          uVar3 = puVar8[1];
          *puVar8 = 0;
          puVar8[1] = 0;
          *param_1 = uVar2;
          piStack_18 = (int *)param_1[1];
          param_1[1] = uVar3;
          if (piStack_18 != (int *)0x0) {
            LOCK();
            iVar7 = piStack_18[1] + -1;
            piStack_18[1] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              (**(code **)*piStack_18)();
              LOCK();
              iVar7 = piStack_18[2] + -1;
              piStack_18[2] = iVar7;
              UNLOCK();
              if (iVar7 == 0) {
                (**(code **)(*piStack_18 + 4))();
              }
            }
          }
          FUN_00550b30();
        }
      }
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar7 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          FUN_00d88950();
          FUN_01674ea0(piVar4,0x10);
        }
      }
    }
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + -1;
    UNLOCK();
  }
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar7 = piVar1[1] + -1;
    piVar1[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar7 = piVar1[2] + -1;
      piVar1[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar7 = param_3[2] + -1;
    param_3[2] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  FUN_00d88a30();
  piVar4 = in_stack_00000034;
  if (in_stack_00000034 != (int *)0x0) {
    LOCK();
    iVar7 = in_stack_00000034[1] + -1;
    in_stack_00000034[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*in_stack_00000034)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21586 ; VA 0x00a893c0 ; Catch@00a893c0 */

undefined * Catch_00a893c0(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x24) + 4))();
  FUN_0086f2f0(3,"ChatService: Unexpected error while invoking callback: %s",uVar1);
  return &DAT_00a893de;
}



/* FUNCTION 21587 ; VA 0x00a894a0 ; FUN_00a894a0 */

undefined FUN_00a894a0(undefined4 *param_1)

{
  if ((DAT_01d66478 == '\0') && (param_1 == &DAT_02126fb8)) {
    return 1;
  }
  return 0;
}



/* FUNCTION 21588 ; VA 0x00a894d0 ; FUN_00a894d0 */

uint FUN_00a894d0(void)

{
  int iVar1;
  
  iVar1 = FUN_00a75310();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 21589 ; VA 0x00a894f0 ; FUN_00a894f0 */

uint FUN_00a894f0(void)

{
  int iVar1;
  
  iVar1 = FUN_00a75310();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 21590 ; VA 0x00a89510 ; FUN_00a89510 */

void FUN_00a89510(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  if (DAT_01eea9ac != '\0') {
    ExceptionList = &pvStack_10;
    puVar1 = (undefined4 *)FUN_00a7e820(aiStack_28);
    uStack_8 = 0;
    if (0xf < (uint)puVar1[5]) {
      puVar1 = (undefined4 *)*puVar1;
    }
    puVar3 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar3 = (undefined4 *)*param_2;
    }
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    FUN_01677520(DAT_01eea9ac,"%s (%zu bytes) %s URL(%s)",param_1,param_2[4],puVar3,puVar1);
    if (0xf < uStack_14) {
      uVar4 = uStack_14 + 1;
      iVar2 = aiStack_28[0];
      if (0xfff < uVar4) {
        iVar2 = *(int *)(aiStack_28[0] + -4);
        uVar4 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar2,uVar4);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21591 ; VA 0x00a895d0 ; FUN_00a895d0 */

void FUN_00a895d0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00a8caa0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 21592 ; VA 0x00a89610 ; FUN_00a89610 */

void FUN_00a89610(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00a8cb50();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 21593 ; VA 0x00a89650 ; FUN_00a89650 */

void FUN_00a89650(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00a8cc00();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 21594 ; VA 0x00a89690 ; FUN_00a89690 */

void FUN_00a89690(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c005f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x58);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00a78220(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a7c180();
        FUN_01674ea0(iVar2,0x58);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dce3bc);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_03eee39fbddc32da1ffec9f7de6abc03>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 21595 ; VA 0x00a897e0 ; FUN_00a897e0 */

void FUN_00a897e0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c005f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x58);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00a78220(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a7c180();
        FUN_01674ea0(iVar2,0x58);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1dce3f4);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_a95fab767866264f74a26598771403dc>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 21596 ; VA 0x00a89930 ; FUN_00a89930 */

void FUN_00a89930(int *param_1,int *param_2,int param_3)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar3 != 0) {
        iVar4 = FUN_00a78670(iVar4);
        *param_2 = iVar4;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      puVar1 = (uint *)*param_2;
      if (puVar1 != (uint *)0x0) {
        uVar2 = *puVar1;
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(puVar1 + 2,puVar1 + 2,2);
            }
          }
          *puVar1 = 0;
        }
        FUN_01674ea0(puVar1,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dce664);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<struct_boost::_bi::unspecified,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_boost::_bi::list1<class_boost::_bi::value<char_const*>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 21597 ; VA 0x00a89aa0 ; FUN_00a89aa0 */

void FUN_00a89aa0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbc3f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x50);
      uStack_8 = 0;
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = *puVar1;
        FUN_00a786e0(puVar1 + 2);
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        uVar2 = *(uint *)(iVar4 + 0x30);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(iVar4 + 0x38,iVar4 + 0x38,2);
            }
          }
          *(undefined4 *)(iVar4 + 0x30) = 0;
        }
        FUN_00a7c840();
        FUN_01674ea0(iVar4,0x50);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dcf29c);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(struct_RBX::TextFilterResult_const&,class_std::shared_ptr<class_RBX::Player>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list4<struct_boost::arg<1>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Player>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 21598 ; VA 0x00a89c30 ; FUN_00a89c30 */

void FUN_00a89c30(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0462;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x88);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        FUN_00a78900(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_0096d5e0();
        FUN_00a7c840();
        FUN_01674ea0(iVar3,0x88);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dce4c4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(bool,class_std::shared_ptr<class_RBX::Player>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,struct_RBX::TextFilterResult),class_boost::_bi::list4<struct_boost::arg<1>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Player>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::value<struct_RBX::TextFilterResult>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 21599 ; VA 0x00a89da0 ; FUN_00a89da0 */

int * FUN_00a89da0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[3];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a89e88. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[3];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00a89df6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dce42c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf0<void,class_RBX::ChatService>,class_boost::_bi::list1<class_boost::_bi::value<class_std::shared_ptr<class_RBX::ChatService>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 21600 ; VA 0x00a89ea0 ; FUN_00a89ea0 */

void FUN_00a89ea0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c005f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x58);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        FUN_00a78dc0(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a7cc10();
        FUN_01674ea0(iVar3,0x58);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dcec7c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf4<void,class_RBX::ChatService,struct_RBX::TextFilterResult_const&,class_std::shared_ptr<class_RBX::Player>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::list5<class_boost::_bi::value<class_std::shared_ptr<class_RBX::ChatService>_>,struct_boost::arg<1>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Player>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 21601 ; VA 0x00a8a000 ; FUN_00a8a000 */

void FUN_00a8a000(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a13f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x50);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        FUN_00a78b10(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a7ca10();
        FUN_01674ea0(iVar3,0x50);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dce71c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf4<void,class_RBX::ChatService,bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_boost::function<void___cdecl(struct_RBX::TextFilterResult_const&)>,class_std::shared_ptr<class_RBX::Player>_>,class_boost::_bi::list5<class_boost::_bi::value<class_std::shared_ptr<class_RBX::ChatService>_>,struct_boost::arg<1>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<class_boost::function<void___cdecl(struct_RBX::TextFilterResult_const&)>_>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Player>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 21602 ; VA 0x00a8a160 ; FUN_00a8a160 */

void FUN_00a8a160(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5207;
  pvStack_10 = ExceptionList;
  if (param_3 == 4) {
    *param_2 = (int)&boost::_bi::
                     bind_t<void,class_boost::_mfi::mf5<void,class_RBX::ChatService,struct_RBX::TextFilterResult_const&,class_std::shared_ptr<class_RBX::Player>,class_std::shared_ptr<class_RBX::Player>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::SystemAddress_const&>,class_boost::_bi::list6<class_boost::_bi::value<class_std::shared_ptr<class_RBX::ChatService>_>,struct_boost::arg<1>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Player>_>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Player>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<class_RBX::SystemAddress>_>_>
                     ::RTTI_Type_Descriptor;
    *(undefined2 *)(param_2 + 1) = 0;
    return;
  }
  if (param_3 == 0) {
    puVar1 = (undefined4 *)*param_1;
    ExceptionList = &pvStack_10;
    puVar2 = (undefined4 *)FUN_01674e20(0x40);
    uStack_8 = 0;
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = *puVar1;
      puVar2[1] = puVar1[1];
      FUN_00a7a380(puVar1 + 2);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_0054ef60(puVar1 + 8);
      puVar2[0xe] = puVar1[0xe];
    }
    *param_2 = (int)puVar2;
    ExceptionList = pvStack_10;
    return;
  }
  if (param_3 == 1) {
    *param_2 = *param_1;
    *param_1 = 0;
    return;
  }
  if (param_3 == 2) {
    iVar3 = *param_2;
    if (iVar3 != 0) {
      ExceptionList = &pvStack_10;
      FUN_00a7cb00();
      FUN_01674ea0(iVar3,0x40);
    }
    *param_2 = 0;
    ExceptionList = pvStack_10;
    return;
  }
  if (param_3 != 3) {
    *param_2 = (int)&boost::_bi::
                     bind_t<void,class_boost::_mfi::mf5<void,class_RBX::ChatService,struct_RBX::TextFilterResult_const&,class_std::shared_ptr<class_RBX::Player>,class_std::shared_ptr<class_RBX::Player>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::SystemAddress_const&>,class_boost::_bi::list6<class_boost::_bi::value<class_std::shared_ptr<class_RBX::ChatService>_>,struct_boost::arg<1>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Player>_>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Player>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<class_RBX::SystemAddress>_>_>
                     ::RTTI_Type_Descriptor;
    *(undefined2 *)(param_2 + 1) = 0;
    return;
  }
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dcf41c);
  if (iVar3 == 0) {
    *param_2 = *param_1;
    ExceptionList = pvStack_10;
    return;
  }
  *param_2 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21603 ; VA 0x00a8a2e0 ; FUN_00a8a2e0 */

void FUN_00a8a2e0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e522f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_01674e20(0x60);
      uStack_8 = 0;
      if (puVar3 != (undefined4 *)0x0) {
        *puVar3 = *puVar1;
        puVar3[1] = puVar1[1];
        FUN_00a79230(puVar1 + 2);
        *param_2 = (int)puVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        uVar2 = *(uint *)(iVar4 + 0x40);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(iVar4 + 0x48,iVar4 + 0x48,2);
            }
          }
          *(undefined4 *)(iVar4 + 0x40) = 0;
        }
        FUN_00a7cb80();
        FUN_01674ea0(iVar4,0x60);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dcf0bc);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf5<void,class_RBX::ChatService,struct_RBX::TextFilterResult_const&,class_std::shared_ptr<class_RBX::Player>,class_std::shared_ptr<class_RBX::Player>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::list6<class_boost::_bi::value<class_std::shared_ptr<class_RBX::ChatService>_>,struct_boost::arg<1>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Player>_>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Player>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 21604 ; VA 0x00a8a470 ; FUN_00a8a470 */

void FUN_00a8a470(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5207;
  pvStack_10 = ExceptionList;
  if (param_3 == 4) {
    *param_2 = (int)&boost::_bi::
                     bind_t<void,class_boost::_mfi::mf5<void,class_RBX::ChatService,bool,class_std::shared_ptr<class_RBX::Player>,class_std::shared_ptr<class_RBX::Player>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::SystemAddress_const&>,class_boost::_bi::list6<class_boost::_bi::value<class_std::shared_ptr<class_RBX::ChatService>_>,struct_boost::arg<1>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Player>_>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Player>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<class_RBX::SystemAddress>_>_>
                     ::RTTI_Type_Descriptor;
    *(undefined2 *)(param_2 + 1) = 0;
    return;
  }
  if (param_3 == 0) {
    puVar1 = (undefined4 *)*param_1;
    ExceptionList = &pvStack_10;
    puVar2 = (undefined4 *)FUN_01674e20(0x40);
    uStack_8 = 0;
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = *puVar1;
      puVar2[1] = puVar1[1];
      FUN_00a7a380(puVar1 + 2);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_0054ef60(puVar1 + 8);
      puVar2[0xe] = puVar1[0xe];
    }
    *param_2 = (int)puVar2;
    ExceptionList = pvStack_10;
    return;
  }
  if (param_3 == 1) {
    *param_2 = *param_1;
    *param_1 = 0;
    return;
  }
  if (param_3 == 2) {
    iVar3 = *param_2;
    if (iVar3 != 0) {
      ExceptionList = &pvStack_10;
      FUN_00a7cb00();
      FUN_01674ea0(iVar3,0x40);
    }
    *param_2 = 0;
    ExceptionList = pvStack_10;
    return;
  }
  if (param_3 != 3) {
    *param_2 = (int)&boost::_bi::
                     bind_t<void,class_boost::_mfi::mf5<void,class_RBX::ChatService,bool,class_std::shared_ptr<class_RBX::Player>,class_std::shared_ptr<class_RBX::Player>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::SystemAddress_const&>,class_boost::_bi::list6<class_boost::_bi::value<class_std::shared_ptr<class_RBX::ChatService>_>,struct_boost::arg<1>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Player>_>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Player>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<class_RBX::SystemAddress>_>_>
                     ::RTTI_Type_Descriptor;
    *(undefined2 *)(param_2 + 1) = 0;
    return;
  }
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dceac4);
  if (iVar3 == 0) {
    *param_2 = *param_1;
    ExceptionList = pvStack_10;
    return;
  }
  *param_2 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21605 ; VA 0x00a8a5f0 ; FUN_00a8a5f0 */

void FUN_00a8a5f0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c000f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x40);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        FUN_00a79530(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a7cca0();
        FUN_01674ea0(iVar3,0x40);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dce90c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf5<void,class_RBX::ChatService,bool,class_std::shared_ptr<class_RBX::Player>,class_std::shared_ptr<class_RBX::Player>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::SystemAddress_const&>,class_boost::_bi::list6<class_boost::_bi::value<class_std::shared_ptr<class_RBX::ChatService>_>,class_boost::_bi::value<bool>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Player>_>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Player>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<class_RBX::SystemAddress>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 21606 ; VA 0x00a8a750 ; FUN_00a8a750 */

void FUN_00a8a750(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ad59f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x78);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        FUN_00a7b940(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a7cd80();
        FUN_01674ea0(iVar3,0x78);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dcee54);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf6<void,class_RBX::ChatService,struct_RBX::TextFilterResult_const&,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_std::shared_ptr<class_RBX::Player>,class_std::shared_ptr<class_RBX::Player>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::list7<class_boost::_bi::value<class_std::shared_ptr<class_RBX::ChatService>_>,struct_boost::arg<1>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Player>_>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Player>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 21607 ; VA 0x00a8a8b0 ; FUN_00a8a8b0 */

void __thiscall FUN_00a8a8b0(int *param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  undefined auStack_98 [4];
  undefined4 uStack_94;
  undefined auStack_90 [12];
  undefined4 uStack_84;
  undefined *puStack_80;
  code *pcStack_7c;
  int *piStack_78;
  undefined auStack_74 [8];
  uint uStack_6c;
  uint uStack_68;
  uint uStack_64;
  uint uStack_60;
  undefined8 uStack_5c;
  undefined auStack_4c [12];
  int *piStack_40;
  int *piStack_3c;
  code *pcStack_38;
  int iStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  uint uStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5292;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_5c = (double)CONCAT44(0xa8a8e2,(undefined4)uStack_5c);
  ExceptionList = &pvStack_10;
  piStack_28 = param_1;
  FUN_01679490();
  if (param_2 != 0) {
    uStack_5c = (double)CONCAT44(0xa8a8f1,(undefined4)uStack_5c);
    FUN_01679490();
    if (param_1[0x28] != 0) {
      uStack_5c = (double)CONCAT44(0xa8a901,(undefined4)uStack_5c);
      piVar4 = (int *)FUN_005cfa90();
      if (*piVar4 != 0) {
        uStack_5c = (double)CONCAT44(param_1[0x28],0xa8a912);
        FUN_009eee80();
      }
    }
    uStack_5c = 2.12745686603701e-314;
    FUN_00a8ce00();
    if (param_1[0x48] != 0) {
      uStack_5c = (double)(ulonglong)(uint)(param_1[0x4b] + param_1[0x47] * 4);
      uStack_60 = 0xa8a93d;
      FUN_00a82ab0();
      puVar8 = (undefined4 *)param_1[0x4b];
      puVar6 = puVar8 + param_1[0x47];
      for (; puVar8 != puVar6; puVar8 = puVar8 + 1) {
        *puVar8 = 0;
      }
    }
  }
  if (param_3 != 0) {
    *(undefined *)((int)param_1 + 0x99) = 0;
    cStack_11 = '\0';
    uStack_5c = (double)CONCAT44(param_3,0xa8a979);
    iStack_18 = FUN_008f7870();
    if (iStack_18 != 0) {
      iVar5 = *(int *)(iStack_18 + 0x4a0);
      if (iVar5 == 1) {
        uStack_5c = (double)(ulonglong)CONCAT14(DAT_01eeaa45,(uint)DAT_01eeaa46);
        uStack_60 = (uint)DAT_01eeaa47;
        uStack_64 = (uint)DAT_01eeaa48;
        uStack_68 = (uint)DAT_01eeaa49;
        uStack_6c = (uint)DAT_01eeaa44;
        pcStack_7c = (code *)auStack_74;
        puStack_80 = (undefined *)0xa8a9fb;
        piStack_78 = param_1;
        FUN_0060dcd0();
        puStack_80 = auStack_4c;
        piStack_78 = (int *)0x0;
        pcStack_7c = FUN_00a8c610;
        uStack_84 = 0xa8aa0e;
        piStack_24 = (int *)FUN_00a766d0();
        uStack_8 = 0;
        uStack_5c = (double)CONCAT44(0xa8aa23,(undefined4)uStack_5c);
        FUN_006eccd0();
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        uStack_5c._4_4_ = DAT_02110da8;
        uStack_5c._0_4_ = 0xa8aa32;
        piVar4 = (int *)FUN_01675290();
        uStack_5c = (double)CONCAT44(uStack_5c._4_4_,0x28);
        uStack_8 = 2;
        uStack_60 = 0xa8aa45;
        piStack_2c = piVar4;
        piStack_20 = (int *)FUN_01674e20();
        if (piStack_20 == (int *)0x0) {
          piStack_20 = (int *)0x0;
        }
        else {
          *piStack_20 = 0;
          piStack_20[1] = 1;
          piStack_20[2] = (int)FUN_00a83500;
          piStack_20[3] = (int)FUN_0057e0b0;
          piStack_20[4] = 0;
          piStack_20[5] = (int)(param_1 + 0x16);
          piStack_20[6] = *piStack_24;
          piStack_20[7] = piStack_24[1];
          piStack_20[8] = 0;
          piStack_20[9] = 0;
          if (piStack_24[3] != 0) {
            LOCK();
            piVar1 = (int *)(piStack_24[3] + 4);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
          }
          piStack_20[8] = piStack_24[2];
          piStack_20[9] = piStack_24[3];
        }
        uStack_5c = (double)CONCAT44(piStack_20,0xa8aabc);
        FUN_016797d0();
        piStack_3c = piStack_20;
        if (piStack_20 != (int *)0x0) {
          LOCK();
          piStack_20[1] = piStack_20[1] + 1;
          UNLOCK();
        }
        uStack_1c = 2;
        uStack_8 = 3;
        uStack_5c = (double)CONCAT44(piVar4,0xa8aae6);
        FUN_01675290();
        iVar5 = param_1[0x18];
        uStack_1c = 1;
        param_1[0x18] = (int)piStack_20;
        if (iVar5 != 0) {
          piVar4 = (int *)(iVar5 + 4);
          LOCK();
          iVar2 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            uStack_5c = (double)CONCAT44(iVar5,0xa8ab17);
            FUN_01674ea0();
          }
        }
        uStack_8 = 0xffffffff;
        piStack_24 = piStack_40;
        if (piStack_40 != (int *)0x0) {
          LOCK();
          iVar5 = piStack_40[1] + -1;
          piStack_40[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            uStack_5c = (double)CONCAT44(0xa8ab38,(undefined4)uStack_5c);
            (**(code **)*piStack_40)();
            LOCK();
            iVar5 = piStack_24[2] + -1;
            piStack_24[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              uStack_5c = (double)CONCAT44(0xa8ab49,(undefined4)uStack_5c);
              (**(code **)(*piStack_24 + 4))();
            }
          }
        }
      }
      else if (iVar5 == 2) {
        *(undefined *)((int)param_1 + 0x99) = 1;
        cStack_11 = '\x01';
      }
      else if (iVar5 == 3) {
        *(undefined *)((int)param_1 + 0x99) = 0;
        cStack_11 = '\x01';
      }
      if (*(char *)((int)param_1 + 0x99) != '\0') {
        uStack_5c = (double)CONCAT44(0xa8ab61,(undefined4)uStack_5c);
        iVar5 = FUN_0055e560();
        if (iVar5 != 0) {
          iStack_18 = iVar5 + 0x2a8;
          pcStack_38 = FUN_00553510;
          iStack_34 = 0;
          uStack_8 = 4;
          uStack_5c._4_4_ = DAT_02110da8;
          uStack_5c._0_4_ = 0xa8ab94;
          piStack_30 = param_1;
          piVar4 = (int *)FUN_01675290();
          uStack_5c = (double)CONCAT44(uStack_5c._4_4_,0x28);
          uStack_8._0_1_ = 5;
          uStack_60 = 0xa8aba4;
          piStack_3c = piVar4;
          piStack_24 = (int *)FUN_01674e20();
          if (piStack_24 == (int *)0x0) {
            piStack_24 = (int *)0x0;
          }
          else {
            *piStack_24 = 0;
            piStack_24[1] = 1;
            piStack_24[2] = (int)FUN_00a40b10;
            piStack_24[3] = (int)_guard_check_icall;
            piStack_24[4] = 0;
            piStack_24[5] = iStack_18;
            piStack_24[6] = (int)pcStack_38;
            piStack_24[7] = iStack_34;
            piStack_24[8] = (int)piStack_30;
            piStack_24[9] = (int)piStack_2c;
          }
          uStack_5c = (double)CONCAT44(piStack_24,0xa8abeb);
          FUN_016797d0();
          piStack_20 = piStack_24;
          if (piStack_24 != (int *)0x0) {
            LOCK();
            piStack_24[1] = piStack_24[1] + 1;
            UNLOCK();
          }
          uStack_1c = uStack_1c | 4;
          uStack_8._0_1_ = 6;
          uStack_5c = (double)CONCAT44(piVar4,0xa8ac0f);
          FUN_01675290();
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          uStack_5c = (double)CONCAT44(&piStack_20,0xa8ac25);
          cVar3 = FUN_01679300();
          if (cVar3 != '\0') {
            uStack_5c = (double)CONCAT44(0xa8ac34,(undefined4)uStack_5c);
            FUN_01679490();
            uStack_5c = (double)CONCAT44(&piStack_20,0xa8ac43);
            FUN_016791c0();
          }
          uStack_8 = 0xffffffff;
          if (piStack_20 != (int *)0x0) {
            piVar4 = piStack_20 + 1;
            LOCK();
            iVar5 = *piVar4;
            *piVar4 = *piVar4 + -1;
            UNLOCK();
            if (iVar5 == 1) {
              uStack_5c = (double)CONCAT44(piStack_20,0xa8ac68);
              FUN_01674ea0();
            }
          }
        }
      }
      if (cStack_11 != '\0') {
        uStack_5c = (double)CONCAT44(0xa8ac7f,(undefined4)uStack_5c);
        puVar6 = (undefined4 *)FUN_005cfa90();
        piStack_24 = (int *)*puVar6;
        if (piStack_24 == (int *)0x0) {
          uStack_5c = (double)CONCAT44(&piStack_30,0xa8ac95);
          FUN_005cf1e0();
          uStack_8 = 7;
          uStack_5c = (double)CONCAT44(param_3,0xa8aca8);
          FUN_008a5700();
          uStack_5c = 6.4403285500520894e-307;
          uStack_60 = 0xa8acb7;
          FUN_005789c0();
          uStack_5c = (double)CONCAT44(0xa8acbf,(undefined4)uStack_5c);
          uVar7 = FUN_005cf500();
          uStack_5c = (double)CONCAT44(uVar7,0xa8acc7);
          puVar6 = (undefined4 *)FUN_008aa140();
          if (piStack_2c != (int *)0x0) {
            LOCK();
            piStack_2c[1] = piStack_2c[1] + 1;
            UNLOCK();
          }
          *puVar6 = piStack_30;
          piVar4 = (int *)puVar6[1];
          puVar6[1] = piStack_2c;
          if (piVar4 != (int *)0x0) {
            LOCK();
            iVar5 = piVar4[1] + -1;
            piVar4[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              uStack_5c = (double)CONCAT44(0xa8acf8,(undefined4)uStack_5c);
              (**(code **)*piVar4)();
              LOCK();
              iVar5 = piVar4[2] + -1;
              piVar4[2] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                uStack_5c = (double)CONCAT44(0xa8ad08,(undefined4)uStack_5c);
                (**(code **)(*piVar4 + 4))();
              }
            }
          }
          piVar4 = piStack_2c;
          piStack_24 = piStack_30;
          uStack_8 = 0xffffffff;
          if (piStack_2c != (int *)0x0) {
            LOCK();
            iVar5 = piStack_2c[1] + -1;
            piStack_2c[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              uStack_5c = (double)CONCAT44(0xa8ad2b,(undefined4)uStack_5c);
              (**(code **)*piStack_2c)();
              LOCK();
              piVar1 = piVar4 + 2;
              iVar5 = *piVar1;
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (iVar5 == 1) {
                uStack_5c = (double)CONCAT44(0xa8ad3a,(undefined4)uStack_5c);
                (**(code **)(*piVar4 + 4))();
              }
            }
          }
        }
        uStack_5c = (double)DAT_01d663c8;
        puStack_80 = (undefined *)0x0;
        FUN_0060dcd0(auStack_98,piStack_28);
        FUN_006058b0(auStack_90,FUN_00a8d150,0);
        uStack_94 = 0xa8ad80;
        FUN_00a73960();
        puStack_80 = (undefined *)0xa8ad88;
        iVar5 = FUN_009eef30();
        piStack_28[0x28] = iVar5;
      }
    }
  }
  uStack_5c = (double)CONCAT44(param_3,param_2);
  uStack_60 = 0xa8ad9f;
  FUN_008a4210();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21608 ; VA 0x00a8adc0 ; FUN_00a8adc0 */

void * __thiscall
FUN_00a8adc0(int *param_1,undefined *param_2,undefined4 param_3,undefined *param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  void *pvVar4;
  undefined4 uVar5;
  longlong lVar6;
  undefined4 uVar7;
  undefined auStack_e0 [4];
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined8 uStack_d4;
  undefined *puStack_cc;
  undefined *puStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined1 *puStack_b8;
  undefined4 uStack_b4;
  undefined *puStack_b0;
  undefined4 uStack_a4;
  undefined **ppuStack_a0;
  int *piStack_9c;
  undefined **ppuStack_98;
  undefined auStack_88 [24];
  undefined auStack_70 [24];
  undefined auStack_58 [24];
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined *puStack_28;
  undefined4 uStack_24;
  int aiStack_20 [2];
  undefined *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5303;
  pvStack_10 = ExceptionList;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 == &DAT_02126ec0) {
    ppuStack_98 = (undefined **)0x1;
    ppuStack_a0 = (undefined **)0xa8adf3;
    ExceptionList = &pvStack_10;
    piStack_9c = param_1;
    pvVar4 = (void *)FUN_00971ce0();
    if ((char)pvVar4 != '\0') {
      ppuStack_98 = &puStack_18;
      piStack_9c = (int *)param_3;
      puStack_18 = param_4;
      ppuStack_a0 = (undefined **)param_2;
      piStack_14 = (int *)0x0;
      uStack_a4 = 0xa8ae16;
      pvVar4 = (void *)(**(code **)(*param_1 + 8))();
      ExceptionList = pvStack_10;
      return pvVar4;
    }
  }
  ppuStack_98 = (undefined **)param_1;
  if (param_2 == &DAT_02127070) {
    piStack_9c = (int *)param_4;
    ppuStack_a0 = &puStack_18;
    uStack_a4 = 0xa8ae42;
    pvVar4 = (void *)FUN_0097c020();
    uStack_8._0_1_ = 0;
    uStack_8._1_3_ = 0;
    if (puStack_18 != (undefined *)0x0) {
      ppuStack_98 = (undefined **)0xa8ae5c;
      lVar6 = FUN_00928340();
      pvVar4 = (void *)((ulonglong)lVar6 >> 0x20);
      if (lVar6 != 0) {
        ppuStack_98 = (undefined **)0xa8ae77;
        ppuStack_98 = (undefined **)FUN_0055d610();
        piStack_9c = (int *)0xa8ae80;
        FUN_0054ef60();
        uStack_8._0_1_ = 1;
        ppuStack_98 = (undefined **)0xa8ae91;
        ppuStack_98 = (undefined **)FUN_0055d610();
        piStack_9c = (int *)0xa8ae9d;
        FUN_0054ef60();
        uStack_8._0_1_ = 2;
        ppuStack_98 = (undefined **)0xa8aeae;
        ppuStack_98 = (undefined **)FUN_0055d610();
        piStack_9c = (int *)0xa8aeb7;
        FUN_0054ef60();
        uStack_30 = 0;
        uStack_2c = 0xf;
        auStack_40[0] = 0;
        ppuStack_98 = (undefined **)auStack_40;
        uStack_8._0_1_ = 4;
        piStack_9c = (int *)auStack_58;
        ppuStack_a0 = (undefined **)0xa8aeda;
        cVar3 = FUN_00fa09c0();
        if (cVar3 != '\0') {
          puStack_b0 = auStack_70;
          uStack_b4 = 0xa8aef2;
          FUN_0054ef60();
          uStack_8._0_1_ = 5;
          puStack_c8 = auStack_88;
          puStack_cc = (undefined *)0xa8af07;
          FUN_0054ef60();
          puStack_c8 = auStack_40;
          uStack_8._0_1_ = 4;
          puStack_cc = auStack_58;
          uStack_d8 = 0;
          uStack_dc = 0xa8af20;
          uStack_d4 = lVar6;
          FUN_00a7f000();
        }
        ppuStack_98 = (undefined **)0xa8af28;
        FUN_005507b0();
        ppuStack_98 = (undefined **)0xa8af30;
        FUN_005507b0();
        ppuStack_98 = (undefined **)0xa8af3b;
        FUN_005507b0();
        ppuStack_98 = (undefined **)0xa8af43;
        pvVar4 = (void *)FUN_005507b0();
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        ppuStack_98 = (undefined **)0xa8af64;
        pvVar4 = (void *)(**(code **)*piStack_14)();
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          ppuStack_98 = (undefined **)0xa8af77;
          pvVar4 = (void *)(**(code **)(*piStack_14 + 4))();
          ExceptionList = pvStack_10;
          return pvVar4;
        }
      }
    }
  }
  else if (param_2 == &DAT_021270b0) {
    if (*(char *)((int)param_1 + 0x99) != '\0') {
      ppuStack_a0 = (undefined **)aiStack_20;
      piStack_9c = (int *)param_4;
      uStack_a4 = 0xa8afb1;
      FUN_0097c020();
      uStack_8 = 6;
      if (aiStack_20[0] != 0) {
        ppuStack_98 = (undefined **)0xa8afcb;
        cVar3 = FUN_0091ea50();
        if (cVar3 == '\0') {
          if (*(char *)((int)param_1 + 0x9b) == '\0') {
            ppuStack_98 = (undefined **)0x1;
            piStack_9c = (int *)0xa8afe2;
            FUN_00a8c220();
            *(undefined *)((int)param_1 + 0x9b) = 1;
          }
          ppuStack_98 = &puStack_28;
          puStack_28 = param_4;
          uStack_24 = 0;
          uStack_b4 = 0;
          ppuStack_a0 = (undefined **)0x0;
          piStack_9c = (int *)0xf;
          puStack_b8 = &DAT_018bc9b8;
          puStack_b0 = (undefined *)((uint)puStack_b0 & 0xffffff00);
          uStack_bc = 0xa8b01f;
          FUN_005542c0();
          uStack_8._0_1_ = 7;
          puStack_cc = (undefined *)0x0;
          puStack_b8 = (undefined1 *)0x0;
          uStack_b4 = 0xf;
          uStack_d4._4_4_ = &DAT_018bc9b8;
          puStack_c8 = (undefined *)((uint)puStack_c8 & 0xffffff00);
          uStack_d4._0_4_ = 0xa8b048;
          FUN_005542c0();
          piStack_14 = (int *)auStack_e0;
          uStack_8._0_1_ = 8;
          uStack_d4._4_4_ = (undefined1 *)0x0;
          puStack_cc = (undefined *)0xf;
          auStack_e0[0] = 0;
          FUN_005542c0("Failed to filter message due to rate limit",0x2a);
          uStack_8._0_1_ = 9;
          uVar5 = FUN_0055d610();
          uVar7 = 0xa8b094;
          FUN_0054ef60(uVar5);
          FUN_00557fc0(aiStack_20);
          uStack_8 = CONCAT31(uStack_8._1_3_,6);
          FUN_00a8be90(param_1,uVar7,uVar5);
          ppuStack_98 = (undefined **)0xa8b0b9;
          pvVar4 = (void *)FUN_00550b30();
          ExceptionList = pvStack_10;
          return pvVar4;
        }
        if (*(char *)(param_1 + 0x27) == '\0') {
          ppuStack_98 = (undefined **)0x0;
          piStack_9c = (int *)0xa8b0dc;
          FUN_00a8c220();
          *(undefined *)(param_1 + 0x27) = 1;
        }
        ppuStack_98 = (undefined **)param_4;
        uStack_b4 = 0xa8b0ff;
        uStack_b4 = FUN_0055d610();
        puStack_b8 = (undefined1 *)0xa8b107;
        FUN_0054ef60();
        uStack_8._0_1_ = 10;
        uStack_bc = 0xa8b120;
        uStack_bc = FUN_00605c00();
        uStack_c0 = 0xa8b128;
        FUN_00557fc0();
        uStack_8._0_1_ = 0xb;
        uStack_c4 = 0xa8b138;
        uStack_c4 = FUN_00605c00();
        puStack_c8 = (undefined *)0xa8b140;
        FUN_00557fc0();
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
        uStack_c4 = 0xa8b14b;
        FUN_00a804c0();
      }
      ppuStack_98 = (undefined **)0xa8b153;
      pvVar4 = (void *)FUN_00550b30();
      ExceptionList = pvStack_10;
      return pvVar4;
    }
  }
  else {
    ppuStack_98 = (undefined **)param_4;
    piStack_9c = (int *)param_3;
    ppuStack_a0 = (undefined **)param_2;
    uStack_a4 = 0xa8b174;
    pvVar4 = (void *)FUN_009cba80();
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 21609 ; VA 0x00a8b190 ; FUN_00a8b190 */

void __thiscall FUN_00a8b190(int param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  
  puVar1 = *(uint **)(param_1 + 4);
  if (*(uint **)(param_1 + 8) == puVar1) {
    FUN_00a754a0(puVar1,param_2);
    return;
  }
  *puVar1 = 0;
  uVar2 = *param_2;
  if (uVar2 != 0) {
    *puVar1 = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar2 = param_2[3];
      uVar3 = param_2[4];
      uVar4 = param_2[5];
      puVar1[2] = param_2[2];
      puVar1[3] = uVar2;
      puVar1[4] = uVar3;
      puVar1[5] = uVar4;
      *(undefined8 *)(puVar1 + 6) = *(undefined8 *)(param_2 + 6);
      *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x20;
      return;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 2,puVar1 + 2,0);
  }
  *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x20;
  return;
}



/* FUNCTION 21610 ; VA 0x00a8b200 ; FUN_00a8b200 */

void __thiscall FUN_00a8b200(undefined4 param_1,uint param_2)

{
  uint uVar1;
  char cVar2;
  undefined *puVar3;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = param_2;
  puStack_c = &LAB_017e5318;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (DAT_01d66470 == '\0') {
    ExceptionList = &pvStack_10;
    FUN_00d88a30();
    ExceptionList = pvStack_10;
    return;
  }
  if ((param_2 & 0xfffffff0) == 0) {
    ExceptionList = &pvStack_10;
    cVar2 = FUN_0097c970(param_1,1);
    if (cVar2 == '\0') {
      FUN_016756b0(auStack_1c,"Chat client callbacks can only be set from a local script.");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
  }
  else {
    ExceptionList = &pvStack_10;
    if ((param_2 & 0xfffffff0) != 0x10) goto LAB_00a8b27f;
    ExceptionList = &pvStack_10;
    cVar2 = FUN_00971ce0(param_1,1);
    if (cVar2 == '\0') {
      FUN_016756b0(auStack_1c,"Chat server callbacks can only be set from a server script.");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
  }
  puVar3 = &stack0x00000008;
  param_2 = uVar1;
  FUN_00a7d290(&param_2);
  FUN_00d88b50(puVar3);
LAB_00a8b27f:
  FUN_00d88a30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21611 ; VA 0x00a8b2f0 ; FUN_00a8b2f0 */

uint __thiscall FUN_00a8b2f0(int param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  
  *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) - *(int *)(*(int *)(*param_2 + 0x28) + 0x28);
  piVar1 = *(int **)(*param_2 + 0x28);
  *(int *)piVar1[1] = *piVar1;
  *(int *)(*piVar1 + 4) = piVar1[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_00a7ecd0(piVar1);
  param_2 = (int *)*param_2;
  piVar1 = (int *)*param_2;
  uVar6 = (uint)param_2[1] % *(uint *)(param_1 + 0x10);
  piVar2 = *(int **)(*(int *)(param_1 + 0x20) + uVar6 * 4);
  for (piVar8 = (int *)*piVar2; piVar8 != param_2; piVar8 = (int *)*piVar8) {
    piVar2 = piVar8;
  }
  do {
    *piVar2 = *piVar8;
    uVar7 = piVar8[7];
    if (0xf < uVar7) {
      iVar3 = piVar8[2];
      uVar5 = uVar7 + 1;
      iVar4 = iVar3;
      if (0xfff < uVar5) {
        iVar4 = *(int *)(iVar3 + -4);
        uVar5 = uVar7 + 0x24;
        if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar5);
    }
    piVar8[6] = 0;
    piVar8[7] = 0xf;
    *(undefined *)(piVar8 + 2) = 0;
    FUN_01674ea0(piVar8,0x30);
    *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + -1;
    uVar7 = uVar6;
    if (*piVar2 == 0) {
LAB_00a8b3c9:
      uVar5 = *(uint *)(param_1 + 0x20);
      if (*(int **)(uVar5 + uVar6 * 4) == piVar2) {
        *(undefined4 *)(uVar5 + uVar6 * 4) = 0;
      }
    }
    else {
      uVar7 = *(uint *)(*piVar2 + 4);
      uVar5 = uVar7 / *(uint *)(param_1 + 0x10);
      uVar7 = uVar7 % *(uint *)(param_1 + 0x10);
      if (uVar6 != uVar7) {
        *(int **)(*(int *)(param_1 + 0x20) + uVar7 * 4) = piVar2;
        goto LAB_00a8b3c9;
      }
    }
    piVar8 = (int *)*piVar2;
    uVar6 = uVar7;
    if (piVar8 == piVar1) {
      return uVar5;
    }
  } while( true );
}



/* FUNCTION 21612 ; VA 0x00a8b400 ; FUN_00a8b400 */

/* WARNING: Removing unreachable block (ram,0x00a8b5ea) */
/* WARNING: Removing unreachable block (ram,0x00a8b5a8) */
/* WARNING: Removing unreachable block (ram,0x00a8b562) */
/* WARNING: Removing unreachable block (ram,0x00a8b51c) */
/* WARNING: Removing unreachable block (ram,0x00a8b52a) */
/* WARNING: Removing unreachable block (ram,0x00a8b622) */
/* WARNING: Removing unreachable block (ram,0x00a8b53e) */
/* WARNING: Removing unreachable block (ram,0x00a8b570) */
/* WARNING: Removing unreachable block (ram,0x00a8b627) */
/* WARNING: Removing unreachable block (ram,0x00a8b584) */
/* WARNING: Removing unreachable block (ram,0x00a8b5b6) */
/* WARNING: Removing unreachable block (ram,0x00a8b62c) */
/* WARNING: Removing unreachable block (ram,0x00a8b5c6) */
/* WARNING: Removing unreachable block (ram,0x00a8b5f8) */
/* WARNING: Removing unreachable block (ram,0x00a8b631) */
/* WARNING: Removing unreachable block (ram,0x00a8b608) */

void FUN_00a8b400(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
                 undefined4 param_17,undefined4 param_18,undefined4 param_19,undefined4 param_20,
                 undefined4 param_21,undefined4 param_22,undefined4 param_23,undefined4 param_24,
                 undefined4 param_25)

{
  undefined4 uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5060;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 3;
  ExceptionList = &pvStack_10;
  FUN_00a8b640(param_1,param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6),param_8,param_9,
               param_10,param_11,CONCAT44(param_13,param_12),param_14,param_15,param_16,param_17,
               CONCAT44(param_19,param_18),param_20,param_21,param_22,param_23,
               CONCAT44(param_25,param_24),&uStack_1c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21613 ; VA 0x00a8b640 ; FUN_00a8b640 */

/* WARNING: Removing unreachable block (ram,0x00a8b8e7) */
/* WARNING: Removing unreachable block (ram,0x00a8b8a5) */
/* WARNING: Removing unreachable block (ram,0x00a8b85f) */
/* WARNING: Removing unreachable block (ram,0x00a8b819) */
/* WARNING: Removing unreachable block (ram,0x00a8b827) */
/* WARNING: Removing unreachable block (ram,0x00a8b91f) */
/* WARNING: Removing unreachable block (ram,0x00a8b83b) */
/* WARNING: Removing unreachable block (ram,0x00a8b86d) */
/* WARNING: Removing unreachable block (ram,0x00a8b924) */
/* WARNING: Removing unreachable block (ram,0x00a8b881) */
/* WARNING: Removing unreachable block (ram,0x00a8b8b3) */
/* WARNING: Removing unreachable block (ram,0x00a8b929) */
/* WARNING: Removing unreachable block (ram,0x00a8b8c3) */
/* WARNING: Removing unreachable block (ram,0x00a8b8f5) */
/* WARNING: Removing unreachable block (ram,0x00a8b92e) */
/* WARNING: Removing unreachable block (ram,0x00a8b905) */

void FUN_00a8b640(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
                 undefined4 param_17,undefined4 param_18,undefined4 param_19,undefined4 param_20,
                 undefined4 param_21,undefined4 param_22,undefined4 param_23,undefined4 param_24,
                 undefined4 param_25,undefined4 param_26)

{
  code *pcVar1;
  undefined4 uStack_360;
  undefined4 uStack_35c;
  undefined4 uStack_358;
  undefined4 uStack_354;
  undefined4 uStack_350;
  undefined4 uStack_34c;
  undefined8 uStack_348;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined4 uStack_27c;
  undefined8 uStack_278;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined8 uStack_1a8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined8 uStack_d8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5392;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_360 = FUN_0088cb40();
  uStack_35c = 0;
  uStack_358 = param_2;
  uStack_354 = param_3;
  uStack_350 = param_4;
  uStack_34c = param_5;
  uStack_348 = CONCAT44(param_7,param_6);
  uStack_35c = FUN_005c9d30();
  uStack_8._0_1_ = 4;
  uStack_290 = FUN_0088cb40();
  uStack_28c = 0;
  uStack_288 = param_8;
  uStack_284 = param_9;
  uStack_280 = param_10;
  uStack_27c = param_11;
  uStack_278 = CONCAT44(param_13,param_12);
  uStack_28c = FUN_005c9d30();
  uStack_8._0_1_ = 5;
  uStack_1c0 = FUN_0088cb40();
  uStack_1bc = 0;
  uStack_1b8 = param_14;
  uStack_1b4 = param_15;
  uStack_1b0 = param_16;
  uStack_1ac = param_17;
  uStack_1a8 = CONCAT44(param_19,param_18);
  uStack_1bc = FUN_005c9d30();
  uStack_8._0_1_ = 6;
  uStack_f0 = FUN_0088cb40();
  uStack_ec = 0;
  uStack_e8 = param_20;
  uStack_e4 = param_21;
  uStack_e0 = param_22;
  uStack_dc = param_23;
  uStack_d8 = CONCAT44(param_25,param_24);
  uStack_ec = FUN_005c9d30();
  uStack_8._0_1_ = 7;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_360,&uStack_20,param_1);
  uStack_8._0_1_ = 8;
  (*pcVar1)(uStack_14,&uStack_20,param_26);
  uStack_8._0_1_ = 9;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_016f32d1(&uStack_360,0xd0,4,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21614 ; VA 0x00a8b940 ; FUN_00a8b940 */

/* WARNING: Removing unreachable block (ram,0x00a8ba64) */
/* WARNING: Removing unreachable block (ram,0x00a8ba18) */
/* WARNING: Removing unreachable block (ram,0x00a8ba21) */
/* WARNING: Removing unreachable block (ram,0x00a8ba30) */
/* WARNING: Removing unreachable block (ram,0x00a8ba3e) */
/* WARNING: Removing unreachable block (ram,0x00a8ba47) */
/* WARNING: Removing unreachable block (ram,0x00a8ba55) */
/* WARNING: Removing unreachable block (ram,0x00a8ba72) */
/* WARNING: Removing unreachable block (ram,0x00a8ba9e) */
/* WARNING: Removing unreachable block (ram,0x00a8ba82) */

undefined4
FUN_00a8b940(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5088;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a8bab0(param_1,param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9,
                       CONCAT44(param_11,param_10),&uStack_1c);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 21615 ; VA 0x00a8bab0 ; FUN_00a8bab0 */

/* WARNING: Removing unreachable block (ram,0x00a8bc75) */
/* WARNING: Removing unreachable block (ram,0x00a8bc27) */
/* WARNING: Removing unreachable block (ram,0x00a8bc30) */
/* WARNING: Removing unreachable block (ram,0x00a8bc3f) */
/* WARNING: Removing unreachable block (ram,0x00a8bc4d) */
/* WARNING: Removing unreachable block (ram,0x00a8bc56) */
/* WARNING: Removing unreachable block (ram,0x00a8bc64) */
/* WARNING: Removing unreachable block (ram,0x00a8bc83) */
/* WARNING: Removing unreachable block (ram,0x00a8bcad) */
/* WARNING: Removing unreachable block (ram,0x00a8bc93) */

undefined4
FUN_00a8bab0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined8 uStack_d8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e53ef;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_290 = FUN_0088cdc0();
  uStack_288 = param_2;
  uStack_28c = 0;
  uStack_284 = param_3;
  uStack_28c = FUN_006309e0();
  uStack_8._0_1_ = 3;
  uStack_1c0 = FUN_0088cdc0();
  uStack_1b8 = param_4;
  uStack_1bc = 0;
  uStack_1b4 = param_5;
  uStack_1bc = FUN_006309e0();
  uStack_8._0_1_ = 4;
  uStack_f0 = FUN_0088cb40();
  uStack_ec = 0;
  uStack_e8 = param_6;
  uStack_e4 = param_7;
  uStack_e0 = param_8;
  uStack_dc = param_9;
  uStack_d8 = CONCAT44(param_11,param_10);
  uStack_ec = FUN_005c9d30();
  uStack_8._0_1_ = 5;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_290,&uStack_20,param_1);
  uStack_8._0_1_ = 6;
  (*pcVar1)(uStack_14,&uStack_20,param_12);
  uStack_8._0_1_ = 7;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar2 = FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 21616 ; VA 0x00a8bcc0 ; FUN_00a8bcc0 */

/* WARNING: Removing unreachable block (ram,0x00a8be48) */
/* WARNING: Removing unreachable block (ram,0x00a8be1d) */
/* WARNING: Removing unreachable block (ram,0x00a8be29) */
/* WARNING: Removing unreachable block (ram,0x00a8be37) */
/* WARNING: Removing unreachable block (ram,0x00a8be56) */
/* WARNING: Removing unreachable block (ram,0x00a8be80) */
/* WARNING: Removing unreachable block (ram,0x00a8be66) */

undefined4
FUN_00a8bcc0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined8 uStack_1a8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5447;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_290 = FUN_0088cdc0();
  uStack_288 = param_2;
  uStack_28c = 0;
  uStack_284 = param_3;
  uStack_28c = FUN_006309e0();
  uStack_8._0_1_ = 2;
  uStack_1c0 = FUN_0088cb40();
  uStack_1bc = 0;
  uStack_1b8 = param_4;
  uStack_1b4 = param_5;
  uStack_1b0 = param_6;
  uStack_1ac = param_7;
  uStack_1a8 = CONCAT44(param_9,param_8);
  uStack_1bc = FUN_005c9d30();
  uStack_8._0_1_ = 3;
  uStack_f0 = FUN_00a8cb50();
  uStack_ec = 0;
  uStack_e8 = param_10;
  uStack_ec = FUN_00a8cd20();
  uStack_8._0_1_ = 4;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_290,&uStack_20,param_1);
  uStack_8._0_1_ = 5;
  (*pcVar1)(uStack_14,&uStack_20,param_11);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar2 = FUN_016f32d1(&uStack_290,0xd0,3,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 21617 ; VA 0x00a8be90 ; FUN_00a8be90 */

/* WARNING: Removing unreachable block (ram,0x00a8c1d0) */
/* WARNING: Removing unreachable block (ram,0x00a8c18e) */
/* WARNING: Removing unreachable block (ram,0x00a8c148) */
/* WARNING: Removing unreachable block (ram,0x00a8c102) */
/* WARNING: Removing unreachable block (ram,0x00a8c0d7) */
/* WARNING: Removing unreachable block (ram,0x00a8c0e3) */
/* WARNING: Removing unreachable block (ram,0x00a8c0f1) */
/* WARNING: Removing unreachable block (ram,0x00a8c110) */
/* WARNING: Removing unreachable block (ram,0x00a8c208) */
/* WARNING: Removing unreachable block (ram,0x00a8c124) */
/* WARNING: Removing unreachable block (ram,0x00a8c156) */
/* WARNING: Removing unreachable block (ram,0x00a8c20d) */
/* WARNING: Removing unreachable block (ram,0x00a8c16a) */
/* WARNING: Removing unreachable block (ram,0x00a8c19c) */
/* WARNING: Removing unreachable block (ram,0x00a8c212) */
/* WARNING: Removing unreachable block (ram,0x00a8c1ac) */
/* WARNING: Removing unreachable block (ram,0x00a8c1de) */
/* WARNING: Removing unreachable block (ram,0x00a8c217) */
/* WARNING: Removing unreachable block (ram,0x00a8c1ee) */

void FUN_00a8be90(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
                 undefined4 param_17,undefined4 param_18,undefined4 param_19,undefined4 param_20,
                 undefined4 param_21,undefined4 param_22,undefined4 param_23,undefined4 param_24,
                 undefined4 param_25,undefined4 param_26,undefined4 param_27,undefined4 param_28,
                 undefined4 param_29)

{
  code *pcVar1;
  undefined4 uStack_500;
  undefined4 uStack_4fc;
  undefined4 uStack_4f8;
  undefined4 uStack_4f4;
  undefined4 uStack_430;
  undefined4 uStack_42c;
  undefined4 uStack_428;
  undefined4 uStack_424;
  undefined4 uStack_420;
  undefined4 uStack_41c;
  undefined8 uStack_418;
  undefined4 uStack_360;
  undefined4 uStack_35c;
  undefined uStack_358;
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined4 uStack_27c;
  undefined8 uStack_278;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined8 uStack_1a8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined8 uStack_d8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e54e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_500 = FUN_0088cdc0();
  uStack_4f8 = param_2;
  uStack_4fc = 0;
  uStack_4f4 = param_3;
  uStack_4fc = FUN_006309e0();
  uStack_8._0_1_ = 5;
  uStack_430 = FUN_0088cb40();
  uStack_42c = 0;
  uStack_428 = param_4;
  uStack_424 = param_5;
  uStack_420 = param_6;
  uStack_41c = param_7;
  uStack_418 = CONCAT44(param_9,param_8);
  uStack_42c = FUN_005c9d30();
  uStack_8._0_1_ = 6;
  uStack_360 = FUN_0088daf0();
  uStack_35c = 0;
  uStack_358 = (undefined)param_10;
  uStack_35c = FUN_005c9ef0();
  uStack_8._0_1_ = 7;
  uStack_290 = FUN_0088cb40();
  uStack_28c = 0;
  uStack_288 = param_11;
  uStack_284 = param_12;
  uStack_280 = param_13;
  uStack_27c = param_14;
  uStack_278 = CONCAT44(param_16,param_15);
  uStack_28c = FUN_005c9d30();
  uStack_8._0_1_ = 8;
  uStack_1c0 = FUN_0088cb40();
  uStack_1bc = 0;
  uStack_1b8 = param_17;
  uStack_1b4 = param_18;
  uStack_1b0 = param_19;
  uStack_1ac = param_20;
  uStack_1a8 = CONCAT44(param_22,param_21);
  uStack_1bc = FUN_005c9d30();
  uStack_8._0_1_ = 9;
  uStack_f0 = FUN_0088cb40();
  uStack_ec = 0;
  uStack_e8 = param_23;
  uStack_e4 = param_24;
  uStack_e0 = param_25;
  uStack_dc = param_26;
  uStack_d8 = CONCAT44(param_28,param_27);
  uStack_ec = FUN_005c9d30();
  uStack_8._0_1_ = 10;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_500,&uStack_20,param_10);
  uStack_8._0_1_ = 0xb;
  (*pcVar1)(uStack_14,&uStack_20,param_29);
  uStack_8._0_1_ = 0xc;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_016f32d1(&uStack_500,0xd0,6,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21618 ; VA 0x00a8c220 ; FUN_00a8c220 */

void FUN_00a8c220(undefined4 param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bb60;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0151f6f0(0xffffffff,0,0);
  uStack_8 = 0;
  FUN_0151fcf0("RateLimited",param_1);
  uVar1 = DAT_01eea9b8;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("ChatServiceDeprecatedAPIs",0x19);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_01520d20(auStack_28,uVar1,0);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  FUN_0151f7f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21619 ; VA 0x00a8c2f0 ; FUN_00a8c2f0 */

void __thiscall
FUN_00a8c2f0(undefined4 param_1,undefined4 param_2,undefined4 *param_3,undefined *param_4)

{
  int iVar1;
  undefined *puVar2;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  int in_stack_00000024;
  uint in_stack_00000038;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 *puStack_68;
  undefined auStack_64 [16];
  undefined4 uStack_54;
  undefined4 *puStack_50;
  undefined auStack_4c [4];
  undefined4 uStack_48;
  undefined4 *puStack_44;
  undefined4 uStack_40;
  undefined *puStack_3c;
  undefined *puStack_38;
  undefined auStack_30 [24];
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5528;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puStack_3c = (undefined *)0xa8c31b;
  ExceptionList = &pvStack_10;
  puStack_38 = (undefined *)param_1;
  iVar1 = FUN_008f7870();
  if (iVar1 != 0) {
    if (*(int *)(iVar1 + 0x4a0) == 1) {
      puStack_38 = (undefined *)param_2;
      puStack_3c = (undefined *)0xa8c340;
      FUN_0054ef60();
      puStack_38 = (undefined *)DAT_01d663b8;
      puStack_3c = auStack_30;
      uStack_8._0_1_ = 2;
      uStack_40 = 0xa8c353;
      FUN_00fa1220();
      uStack_40 = DAT_01d663b0;
      puStack_44 = &param_4;
      uStack_48 = 0xa8c362;
      FUN_00fa11d0();
      puStack_50 = &stack0x00000024;
      uStack_54 = 0xa8c373;
      FUN_0054ef60();
      puStack_14 = auStack_64;
      uStack_8._0_1_ = 3;
      puStack_68 = &param_4;
      uStack_6c = 0xa8c388;
      FUN_0054ef60();
      puStack_18 = (undefined *)&uStack_7c;
      uStack_8._0_1_ = 4;
      FUN_0054ef60(param_3);
      uStack_8._0_1_ = 5;
      FUN_0054ef60(auStack_30);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_00a8b400(param_1);
      puStack_38 = (undefined *)0xa8c3c5;
      FUN_005507b0();
    }
    else if (*(int *)(iVar1 + 0x4a0) == 2) {
      puStack_18 = auStack_4c;
      puStack_50 = &stack0x00000024;
      uStack_54 = 0xa8c3dd;
      FUN_0054ef60();
      uStack_8._0_1_ = 6;
      puStack_68 = &param_4;
      uStack_6c = 0xa8c3ef;
      FUN_0054ef60();
      puStack_68 = param_3;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uStack_6c = param_2;
      uStack_70 = 0;
      uStack_74 = 0;
      uStack_78 = 1;
      uStack_7c = 0xa8c406;
      FUN_00a7f000();
    }
  }
  if (0xf < in_stack_00000020) {
    puStack_38 = (undefined *)(in_stack_00000020 + 1);
    puVar2 = param_4;
    if (0xfff < puStack_38) {
      puVar2 = *(undefined **)(param_4 + -4);
      puStack_38 = (undefined *)(in_stack_00000020 + 0x24);
      if ((undefined *)0x1f < param_4 + (-4 - (int)puVar2)) {
                    /* WARNING: Subroutine does not return */
        puStack_38 = (undefined *)0xa8c48e;
        FUN_017167a3();
      }
    }
    uStack_40 = 0xa8c433;
    puStack_3c = puVar2;
    FUN_01674ea0();
  }
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_4 = (undefined *)((uint)param_4 & 0xffffff00);
  if (0xf < in_stack_00000038) {
    puStack_38 = (undefined *)(in_stack_00000038 + 1);
    iVar1 = in_stack_00000024;
    if (0xfff < puStack_38) {
      iVar1 = *(int *)(in_stack_00000024 + -4);
      puStack_38 = (undefined *)(in_stack_00000038 + 0x24);
      if (0x1f < (in_stack_00000024 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_38 = &UNK_00a8c493;
        FUN_017167a3();
      }
    }
    uStack_40 = 0xa8c475;
    puStack_3c = (undefined *)iVar1;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21620 ; VA 0x00a8c4a0 ; FUN_00a8c4a0 */

void __thiscall FUN_00a8c4a0(int param_1,uint param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int aiStack_c [2];
  
  uVar3 = *(uint *)(param_1 + 8);
  while (param_2 < uVar3) {
    iVar1 = *(int *)(*(int *)(param_1 + 4) + 4);
    iVar4 = param_1 + 0xd + (uint)*(byte *)(param_1 + 0xc);
    iVar2 = FUN_005702d0(iVar1 + 8);
    uVar3 = *(uint *)(iVar1 + 0x24);
    if (((int)uVar3 < 1) && ((int)uVar3 < 0)) {
      uVar3 = ~uVar3;
    }
    FUN_00a77880(aiStack_c,
                 (iVar2 + 0x9e3779b9U >> 2) + 0x2c15e7f9 +
                 ((uVar3 >> 2) + uVar3 * 0x40 + *(int *)(iVar1 + 0x20) ^ uVar3) + iVar2 * 0x40 ^
                 iVar2 + 0x9e3779b9U,iVar1 + 8,-(uint)(iVar4 != 0) & iVar4 + 1U);
    if (aiStack_c[0] != 0) {
      FUN_00a8b2f0(aiStack_c);
    }
    uVar3 = *(uint *)(param_1 + 8);
  }
  return;
}



/* FUNCTION 21621 ; VA 0x00a8c570 ; FUN_00a8c570 */

void FUN_00a8c570(undefined4 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01675640(aiStack_28,"placeId: %lld",param_1,param_2);
  uStack_8 = 0;
  if (0xf < (uint)puVar1[5]) {
    puVar1 = (undefined4 *)*puVar1;
  }
  FUN_0087c450(&DAT_018c5f98,"ChatService:FilterStringForPlayerAsync",puVar1,0,0,0);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21622 ; VA 0x00a8c610 ; FUN_00a8c610 */

void FUN_00a8c610(undefined4 param_1,int *param_2,uint param_3)

{
  int *piVar1;
  uint *puVar2;
  int iVar3;
  uint *puVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  uint uVar8;
  uint uVar9;
  uint *puVar10;
  undefined8 uVar11;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  undefined uStack00000024;
  undefined4 *in_stack_00000028;
  undefined4 in_stack_00000038;
  uint in_stack_0000003c;
  undefined4 *in_stack_00000040;
  undefined4 in_stack_00000050;
  uint in_stack_00000054;
  undefined4 *in_stack_00000058;
  undefined4 in_stack_00000068;
  uint in_stack_0000006c;
  undefined8 uStack_98;
  undefined uStack_90;
  undefined uStack_8f;
  undefined uStack_8c;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined uStack_74;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined uStack_5c;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined auStack_40 [4];
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e558e;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  ExceptionList = &pvStack_10;
  FUN_00562c90(&iStack_1c,&param_1);
  uStack_8._0_1_ = 5;
  if (iStack_1c == 0) {
    FUN_0086f2f0(3,"ChatService::serverToClientFilterMessageHandler invalid player");
  }
  else {
    uVar11 = FUN_00928340();
    FUN_0054ef60(&param_3);
    uStack_8._0_1_ = 6;
    uStack_24 = uVar11;
    piVar5 = (int *)FUN_00a87870(auStack_40,auStack_3c);
    if (*piVar5 == 0) {
      FUN_0086f2f0(3,
                   "ChatService::serverToClientFilterMessageHandler pending client filter request not found"
                  );
      FUN_005507b0();
    }
    else {
      uStack_7c = 0;
      uStack_98 = 0;
      uStack_78 = 0xf;
      uStack_8c = 0;
      uStack_64 = 0;
      uStack_60 = 0xf;
      uStack_74 = 0;
      uStack_4c = 0;
      uStack_48 = 0xf;
      uStack_5c = 0;
      uStack_90 = uStack00000024;
      puVar6 = &stack0x00000028;
      if (0xf < in_stack_0000003c) {
        puVar6 = in_stack_00000028;
      }
      uStack_8._0_1_ = 7;
      uStack_8f = 0;
      FUN_005542c0(puVar6,in_stack_00000038);
      puVar6 = &stack0x00000040;
      if (0xf < in_stack_00000054) {
        puVar6 = in_stack_00000040;
      }
      FUN_005542c0(puVar6,in_stack_00000050);
      puVar6 = &stack0x00000058;
      if (0xf < in_stack_0000006c) {
        puVar6 = in_stack_00000058;
      }
      FUN_005542c0(puVar6,in_stack_00000068);
      FUN_00a87870(&stack0x00000024,auStack_3c);
      puVar4 = _uStack00000024;
      if (_uStack00000024 != (uint *)0x0) {
        puVar2 = (uint *)_uStack00000024[0xb];
        puVar10 = (uint *)_uStack00000024[10];
        _uStack00000024 = puVar2;
        if (puVar10 != puVar2) {
          do {
            if (*puVar10 == 0) {
              uVar7 = FUN_0054fda0();
              uStack_8 = CONCAT31(uStack_8._1_3_,8);
                    /* WARNING: Subroutine does not return */
              FUN_0054e5e0(uVar7);
            }
            (**(code **)((*puVar10 & 0xfffffffe) + 4))(puVar10 + 2,&uStack_98);
            puVar10 = puVar10 + 8;
          } while (puVar10 != _uStack00000024);
        }
        FUN_00a83700(&stack0x00000024,puVar4);
      }
      FUN_0096d5e0();
      if (0xf < uStack_28) {
        uVar8 = uStack_28 + 1;
        uVar9 = auStack_3c[0];
        if (0xfff < uVar8) {
          uVar9 = *(uint *)(auStack_3c[0] - 4);
          uVar8 = uStack_28 + 0x24;
          if (0x1f < (auStack_3c[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar9,uVar8);
      }
      uStack_2c = 0;
      uStack_28 = 0xf;
      auStack_3c[0] = auStack_3c[0] & 0xffffff00;
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  piVar5 = param_2;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar3 = param_2[1] + -1;
    param_2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_2)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000020) {
    uVar8 = in_stack_00000020 + 1;
    uVar9 = param_3;
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(param_3 - 4);
      uVar8 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_3 = param_3 & 0xffffff00;
  if (0xf < in_stack_0000003c) {
    uVar9 = in_stack_0000003c + 1;
    puVar6 = in_stack_00000028;
    if (0xfff < uVar9) {
      puVar6 = (undefined4 *)in_stack_00000028[-1];
      uVar9 = in_stack_0000003c + 0x24;
      if (0x1f < (uint)((int)in_stack_00000028 + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar6,uVar9);
  }
  in_stack_00000038 = 0;
  in_stack_0000003c = 0xf;
  in_stack_00000028 = (undefined4 *)((uint)in_stack_00000028 & 0xffffff00);
  if (0xf < in_stack_00000054) {
    uVar9 = in_stack_00000054 + 1;
    puVar6 = in_stack_00000040;
    if (0xfff < uVar9) {
      puVar6 = (undefined4 *)in_stack_00000040[-1];
      uVar9 = in_stack_00000054 + 0x24;
      if (0x1f < (uint)((int)in_stack_00000040 + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar6,uVar9);
  }
  in_stack_00000050 = 0;
  in_stack_00000054 = 0xf;
  in_stack_00000040 = (undefined4 *)((uint)in_stack_00000040 & 0xffffff00);
  if (0xf < in_stack_0000006c) {
    uVar9 = in_stack_0000006c + 1;
    puVar6 = in_stack_00000058;
    if (0xfff < uVar9) {
      puVar6 = (undefined4 *)in_stack_00000058[-1];
      uVar9 = in_stack_0000006c + 0x24;
      if (0x1f < (uint)((int)in_stack_00000058 + (-4 - (int)puVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar6,uVar9);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21623 ; VA 0x00a8c9a0 ; FUN_00a8c9a0 */

void __thiscall FUN_00a8c9a0(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0x9a)) {
    *(char *)(param_1 + 0x9a) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 21624 ; VA 0x00a8c9d0 ; FUN_00a8c9d0 */

void __thiscall FUN_00a8c9d0(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e55a8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01d66480 != '\0') {
    ExceptionList = &pvStack_10;
    iVar1 = FUN_008f7870(param_1);
    if (iVar1 != 0) {
      if (*(int *)(iVar1 + 0x4a0) != 1) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("SetBubbleChatSettings can only be called from the client");
      }
      FUN_0056a440(&param_2);
      FUN_00a88150(param_1);
    }
  }
  uStack_8 = 1;
  if (param_3 != 0) {
    (**(code **)(param_3 + 8))(&stack0x0000000c);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21625 ; VA 0x00a8ca70 ; FUN_00a8ca70 */

void __thiscall FUN_00a8ca70(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x98) != param_2) {
    *(char *)(param_1 + 0x98) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 21626 ; VA 0x00a8caa0 ; FUN_00a8caa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a8caa0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e55d6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeacf4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeacf4);
    if (DAT_01eeacf4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("ChatCallbackType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eeac90 = RBX::Reflection::EnumDesc<enum_RBX::ChatService::ChatCallbackType>::vftable;
      FUN_009caf20(&DAT_019459e0,4);
      FUN_016f3654(&LAB_0188aba0);
      FUN_016f37bf(&DAT_01eeacf4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeac90;
}



/* FUNCTION 21627 ; VA 0x00a8cb50 ; FUN_00a8cb50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a8cb50(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e55f6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeadc4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeadc4);
    if (DAT_01eeadc4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("ChatColor");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eead60 = RBX::Reflection::EnumDesc<enum_RBX::ChatService::ChatColor>::vftable;
      FUN_009caf20(&DAT_01d664c8,4);
      FUN_016f3654(&LAB_0188abc0);
      FUN_016f37bf(&DAT_01eeadc4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eead60;
}



/* FUNCTION 21628 ; VA 0x00a8cc00 ; FUN_00a8cc00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a8cc00(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5616;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eead5c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eead5c);
    if (DAT_01eead5c == -1) {
      uStack_8 = 0;
      FUN_009ca470("TextFilterContext");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eeacf8 = RBX::Reflection::EnumDesc<enum_RBX::ChatService::TextFilterContext>::vftable;
      FUN_009caf20(&DAT_01d664e8,2);
      FUN_016f3654(&LAB_0188abe0);
      FUN_016f37bf(&DAT_01eead5c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeacf8;
}



/* FUNCTION 21629 ; VA 0x00a8ccb0 ; FUN_00a8ccb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a8ccb0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeadd4) {
    FUN_016f3809(&DAT_01eeadd4);
    if (DAT_01eeadd4 == -1) {
      _DAT_01eeadc8 = FUN_005c65e0;
      _DAT_01eeadcc = FUN_005c65e0;
      _DAT_01eeadd0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eeadd4);
    }
  }
  return &DAT_01eeadc8;
}



/* FUNCTION 21630 ; VA 0x00a8cd20 ; FUN_00a8cd20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a8cd20(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeadf4) {
    FUN_016f3809(&DAT_01eeadf4);
    if (DAT_01eeadf4 == -1) {
      _DAT_01eeade8 = FUN_005c65e0;
      _DAT_01eeadec = FUN_005c65e0;
      _DAT_01eeadf0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eeadf4);
    }
  }
  return &DAT_01eeade8;
}



/* FUNCTION 21631 ; VA 0x00a8cd90 ; FUN_00a8cd90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a8cd90(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeade4) {
    FUN_016f3809(&DAT_01eeade4);
    if (DAT_01eeade4 == -1) {
      _DAT_01eeadd8 = FUN_005c65e0;
      _DAT_01eeaddc = FUN_005c65e0;
      _DAT_01eeade0 = _guard_check_icall;
      FUN_016f37bf(&DAT_01eeade4);
    }
  }
  return &DAT_01eeadd8;
}



/* FUNCTION 21632 ; VA 0x00a8ce00 ; FUN_00a8ce00 */

void __thiscall FUN_00a8ce00(int param_1,char param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined uVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  int *piVar7;
  int iVar8;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  double dStack_30;
  undefined4 uStack_28;
  uint uStack_24;
  uint uStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5638;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uStack_28 = FUN_01675290(DAT_01eea9bc);
  iStack_8 = 0;
  iStack_18 = 0;
  if (*(int *)(param_1 + 0xac) == 0) {
    piVar1 = (int *)0x0;
  }
  else {
    piVar1 = *(int **)(*(int *)(param_1 + 0xb8) + *(int *)(param_1 + 0xa8) * 4);
  }
joined_r0x00a8ce60:
  do {
    if (piVar1 == (int *)0x0) {
LAB_00a8d11c:
      iStack_8 = 3;
      FUN_01675290(uStack_28);
      ExceptionList = pvStack_10;
      return;
    }
    FUN_016830f0(&dStack_30);
    if (((param_2 == '\0') && (dStack_30 - *(double *)(piVar1 + 8) <= (double)DAT_01d663a8)) &&
       (dStack_30 - *(double *)(piVar1 + 10) <= (double)DAT_01d663a0)) {
      piVar1 = (int *)*piVar1;
      goto joined_r0x00a8ce60;
    }
    iVar8 = piVar1[0x27];
    if (*(char *)(piVar1 + 0x18) == '\0') {
      if (DAT_01d66390 <= iVar8) goto LAB_00a8cedb;
    }
    else {
      iVar8 = iVar8 + -1;
      if (DAT_01d66398 <= iVar8) {
LAB_00a8cedb:
        FUN_0151f6f0(0xffffffff,0,0);
        piVar4 = piVar1 + 0x12;
        iStack_8._0_1_ = 1;
        if (0xf < (uint)piVar1[0x17]) {
          piVar4 = (int *)*piVar4;
        }
        FUN_0151f850("WordMatch",piVar4);
        piVar4 = piVar1 + 0xc;
        if (0xf < (uint)piVar1[0x11]) {
          piVar4 = (int *)*piVar4;
        }
        FUN_0151f850("FullText",piVar4);
        piVar4 = piVar1 + 0x19;
        if (0xf < (uint)piVar1[0x1e]) {
          piVar4 = (int *)*piVar4;
        }
        FUN_0151f850("InstancePaths",piVar4);
        piVar4 = piVar1 + 0x1f;
        if (0xf < (uint)piVar1[0x24]) {
          piVar4 = (int *)*piVar4;
        }
        FUN_0151f850("InstanceTypes",piVar4);
        FUN_0151f9c0("ClientCount",iVar8);
        FUN_0151fcf0("ServerVerified",*(undefined *)(piVar1 + 0x18));
        FUN_0151fcf0("FilteringEnabled",1);
        FUN_0151fcf0("SiftSwear",*(undefined *)((int)piVar1 + 0x61));
        FUN_0151f9c0("CollectionDuration",(int)(*(double *)(piVar1 + 10) - *(double *)(piVar1 + 8)))
        ;
        FUN_0151f9c0("ReportDelay",(int)(dStack_30 - *(double *)(piVar1 + 8)));
        uVar2 = DAT_01d663d8;
        uStack_38 = 0;
        uStack_34 = 0xf;
        auStack_48[0] = auStack_48[0] & 0xffffff00;
        FUN_005542c0("GameSwearV2",0xb);
        iStack_8._0_1_ = 2;
        FUN_01520d20(auStack_48,uVar2,0);
        iStack_8._0_1_ = 1;
        uVar3 = (undefined)iStack_8;
        iStack_8._0_1_ = 1;
        if (0xf < uStack_34) {
          uVar6 = uStack_34 + 1;
          uVar5 = auStack_48[0];
          if (0xfff < uVar6) {
            uVar5 = *(uint *)(auStack_48[0] - 4);
            uVar6 = uStack_34 + 0x24;
            if (0x1f < (auStack_48[0] - uVar5) - 4) {
              iStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar5,uVar6);
        }
        iStack_18 = iStack_18 + 1;
        if (DAT_01d663d0 <= iStack_18) {
          FUN_0151f7f0();
          goto LAB_00a8d11c;
        }
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_0151f7f0();
      }
    }
    uStack_20 = (uint)piVar1[1] % *(uint *)(param_1 + 0xa8);
    piVar4 = (int *)*piVar1;
    piStack_1c = *(int **)(*(int *)(param_1 + 0xb8) + uStack_20 * 4);
    for (piVar7 = (int *)*piStack_1c; piVar7 != piVar1; piVar7 = (int *)*piVar7) {
      piStack_1c = piVar7;
    }
    uStack_24 = -(uint)(iStack_14 != -0xa7) & iStack_14 + 0xa8U;
    uVar5 = uStack_20;
    do {
      *piStack_1c = *piVar7;
      FUN_00a77130(uStack_24,piVar7 + 2);
      FUN_01674ea0(piVar7,0xb0);
      *(int *)(iStack_14 + 0xac) = *(int *)(iStack_14 + 0xac) + -1;
      uVar6 = uVar5;
      if (*piStack_1c == 0) {
LAB_00a8d0eb:
        if (*(int **)(*(int *)(iStack_14 + 0xb8) + uVar5 * 4) == piStack_1c) {
          *(undefined4 *)(*(int *)(iStack_14 + 0xb8) + uVar5 * 4) = 0;
        }
      }
      else {
        uVar6 = *(uint *)(*piStack_1c + 4) % *(uint *)(iStack_14 + 0xa8);
        if (uVar5 != uVar6) {
          *(int **)(*(int *)(iStack_14 + 0xb8) + uVar6 * 4) = piStack_1c;
          goto LAB_00a8d0eb;
        }
      }
      piVar7 = (int *)*piStack_1c;
      uVar5 = uVar6;
      piVar1 = piVar4;
      param_1 = iStack_14;
    } while (piVar7 != piVar4);
  } while( true );
}



/* FUNCTION 21633 ; VA 0x00a8d150 ; FUN_00a8d150 */

void __fastcall FUN_00a8d150(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined auStack_70 [4];
  undefined4 uStack_6c;
  undefined auStack_68 [16];
  undefined4 uStack_58;
  undefined8 uStack_34;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5658;
  pvStack_10 = ExceptionList;
  uStack_34 = (double)CONCAT44(DAT_01eea9bc,0xa8d17d);
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290();
  uStack_8 = 0;
  uStack_34 = 5.46619457995945e-317;
  FUN_00a8ce00();
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    iVar3 = param_1;
    if ((iVar1 != 0) && (iVar3 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      uStack_34 = (double)CONCAT44(0xa8d1b3,(undefined4)uStack_34);
      iVar3 = FUN_005c8ac0();
    }
    if (iVar3 != 0) {
      iVar1 = *(int *)(iVar3 + 0xc);
      uStack_34 = (double)CONCAT44(0xa8d1cd,(undefined4)uStack_34);
      iVar3 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) {
        uStack_34 = (double)CONCAT44(0xa8d1f0,(undefined4)uStack_34);
        piVar4 = (int *)FUN_005cfa90();
        if (*piVar4 != 0) {
          uStack_34 = (double)DAT_01d663c8;
          uStack_58 = 0;
          FUN_0060dcd0(auStack_70,param_1);
          FUN_006058b0(auStack_68,FUN_00a8d150,0);
          uStack_6c = 0xa8d241;
          FUN_00a73960();
          uStack_58 = 0xa8d249;
          uVar5 = FUN_009eef30();
          *(undefined4 *)(param_1 + 0xa0) = uVar5;
        }
      }
    }
  }
  uStack_8 = 1;
  uStack_34 = (double)CONCAT44(uVar2,0xa8d25f);
  FUN_01675290();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21634 ; VA 0x00a8d280 ; FUN_00a8d280 */

int FUN_00a8d280(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint3 uVar4;
  
  if (*(char *)(param_1 + 1) == '\0') {
    piVar1 = (int *)*param_1;
    if (piVar1 == (int *)0x0) {
LAB_00a8d2bc:
      *param_1 = 0;
    }
    else {
      if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
        uVar3 = (**(code **)(*piVar1 + 0x18))();
      }
      else {
        uVar3 = (uint)**(byte **)piVar1[7];
      }
      if (uVar3 == 0xffffffff) goto LAB_00a8d2bc;
      *(char *)((int)param_1 + 5) = (char)uVar3;
    }
    *(undefined *)(param_1 + 1) = 1;
  }
  if (*(char *)(param_2 + 1) == '\0') {
    piVar1 = (int *)*param_2;
    if (piVar1 == (int *)0x0) {
LAB_00a8d2f7:
      *param_2 = 0;
    }
    else {
      if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
        uVar3 = (**(code **)(*piVar1 + 0x18))();
      }
      else {
        uVar3 = (uint)**(byte **)piVar1[7];
      }
      if (uVar3 == 0xffffffff) goto LAB_00a8d2f7;
      *(char *)((int)param_2 + 5) = (char)uVar3;
    }
    *(undefined *)(param_2 + 1) = 1;
  }
  iVar2 = *param_2;
  uVar4 = (uint3)((uint)iVar2 >> 8);
  if (*param_1 == 0) {
    if (iVar2 == 0) {
LAB_00a8d316:
      return CONCAT31(uVar4,1);
    }
  }
  else if (iVar2 != 0) goto LAB_00a8d316;
  return (uint)uVar4 << 8;
}



/* FUNCTION 21635 ; VA 0x00a8d320 ; FUN_00a8d320 */

int * __thiscall FUN_00a8d320(int *param_1,undefined4 param_2)

{
  undefined *puVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  undefined4 *puVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  undefined4 uVar9;
  undefined auStack_48 [12];
  int *piStack_3c;
  int *piStack_38;
  char cStack_34;
  int *piStack_28;
  uint uStack_24;
  int *piStack_20;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e56a7;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff78;
  uStack_24 = 0;
  piVar6 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  ExceptionList = &pvStack_10;
  piStack_38 = param_1;
  piStack_20 = param_1;
  puVar1 = &stack0xffffff78;
  if (piVar6 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar6 + 4))();
    puVar1 = puStack_14;
  }
  puStack_14 = puVar1;
  uVar9 = 0;
  uStack_8 = 0;
  cStack_34 = FUN_00593b40(0);
  if (cStack_34 == '\0') goto LAB_00a8d519;
  piVar6 = *(int **)(*(int *)(*(int *)(*param_1 + 4) + 0x30 + (int)param_1) + 4);
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  piStack_3c = piVar6;
  (**(code **)(*piVar6 + 4))();
  uStack_8._0_1_ = 4;
  FUN_016dda75(0);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  piStack_28 = DAT_01eeae50;
  uStack_18 = DAT_01eeae4c;
  if (DAT_01eeae4c == 0) {
    FUN_016dda75(0);
    if (DAT_01eeae4c == 0) {
      DAT_01eeae4c = DAT_021130c8 + 1;
      DAT_021130c8 = DAT_01eeae4c;
    }
    FUN_016ddacd();
  }
  uStack_18 = DAT_01eeae4c;
  if (DAT_01eeae4c < (uint)piVar6[3]) {
    piVar3 = *(int **)(piVar6[2] + DAT_01eeae4c * 4);
    if (piVar3 == (int *)0x0) goto LAB_00a8d40f;
  }
  else {
    piVar3 = (int *)0x0;
LAB_00a8d40f:
    if (*(char *)(piVar6 + 5) == '\0') {
LAB_00a8d428:
      if (piVar3 != (int *)0x0) goto LAB_00a8d497;
    }
    else {
      iVar2 = FUN_016de17b();
      if (uStack_18 < *(uint *)(iVar2 + 0xc)) {
        piVar3 = *(int **)(*(int *)(iVar2 + 8) + uStack_18 * 4);
        goto LAB_00a8d428;
      }
    }
    piVar3 = piStack_28;
    if (piStack_28 == (int *)0x0) {
      piVar3 = (int *)FUN_01674e20(8);
      uStack_8._0_1_ = 6;
      if (piVar3 == (int *)0x0) {
        piVar3 = (int *)0x0;
      }
      else {
        piVar4 = (int *)piVar6[6];
        if (piVar4 == (int *)0x0) {
          piVar4 = piVar6 + 7;
        }
        piStack_28 = piVar3;
        FUN_0054f870(piVar4);
        piVar3[1] = 0;
        *piVar3 = (int)std::
                       num_get<char,class_std::istreambuf_iterator<char,struct_std::char_traits<char>_>_>
                       ::vftable;
        FUN_00550e70();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      piStack_28 = piVar3;
      FUN_016de14f(piVar3);
      (**(code **)(*piVar3 + 4))();
      DAT_01eeae50 = piVar3;
    }
  }
LAB_00a8d497:
  uStack_8._0_1_ = 4;
  FUN_016ddacd();
  piStack_28 = (int *)CONCAT22(piStack_28._2_2_,1);
  iVar2 = *(int *)(*param_1 + 4) + (int)param_1;
  uStack_18 = CONCAT31((int3)(uStack_18 >> 8),*(int *)(iVar2 + 0x38) == 0) & 0xffff00ff;
  (**(code **)(*piVar3 + 0x18))
            (auStack_48,*(undefined4 *)(iVar2 + 0x38),uStack_18,0,piStack_28,iVar2,&uStack_24,
             param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  puVar5 = (undefined4 *)(**(code **)(*piVar6 + 8))();
  if (puVar5 != (undefined4 *)0x0) {
    (**(code **)*puVar5)(1);
    piVar6 = (int *)FUN_00a8d512(uVar9);
    return piVar6;
  }
LAB_00a8d519:
  uStack_8 = 1;
  uVar8 = *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc) | uStack_24;
  uVar7 = uVar8 | 4;
  if (*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) != 0) {
    uVar7 = uVar8;
  }
  FUN_00554460(uVar7,0);
  uStack_8 = 10;
  piVar6 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar6 != (int *)0x0) {
    (**(code **)(*piVar6 + 8))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21636 ; VA 0x00a8d4f6 ; Catch_All@00a8d4f6 */

undefined * Catch_All_00a8d4f6(void)

{
  FUN_005565b0(4,1);
  return &DAT_00a8d50f;
}



/* FUNCTION 21637 ; VA 0x00a8d512 ; FUN_00a8d512 */

void FUN_00a8d512(void)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  int unaff_EBP;
  int *unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  uVar4 = *(uint *)((int)unaff_EDI + *(int *)(*unaff_EDI + 4) + 0xc) | *(uint *)(unaff_EBP + -0x20);
  uVar3 = uVar4 | 4;
  if (*(int *)((int)unaff_EDI + *(int *)(*unaff_EDI + 4) + 0x38) != 0) {
    uVar3 = uVar4;
  }
  FUN_00554460(uVar3,0);
  iVar1 = *unaff_EDI;
  *(undefined4 *)(unaff_EBP + -4) = 10;
  piVar2 = *(int **)(*(int *)(iVar1 + 4) + 0x38 + (int)unaff_EDI);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 8))();
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 21638 ; VA 0x00a8d570 ; FUN_00a8d570 */

int FUN_00a8d570(int param_1,int param_2,undefined *param_3)

{
  int iVar1;
  
  iVar1 = FUN_0170db20(param_1,*param_3,param_2 - param_1);
  if (iVar1 != 0) {
    param_2 = iVar1;
  }
  return param_2;
}



/* FUNCTION 21639 ; VA 0x00a8d5a0 ; FUN_00a8d5a0 */

uint FUN_00a8d5a0(int *param_1,int *param_2,uint param_3,char *param_4)

{
  char *pcVar1;
  int iVar2;
  int *piVar3;
  byte *pbVar4;
  bool bVar5;
  char cVar6;
  undefined4 ****ppppuVar7;
  uint uVar8;
  undefined uVar9;
  char *pcVar10;
  char cVar11;
  int iVar12;
  undefined4 ***apppuStack_40 [5];
  uint uStack_2c;
  char *pcStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined4 ***pppuStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794d38;
  pvStack_10 = ExceptionList;
  cVar6 = *param_4;
  pcVar10 = param_4;
  cVar11 = cVar6;
  if (cVar6 == '\0') {
    uStack_20 = param_3;
  }
  else {
    do {
      pcVar1 = pcVar10 + 1;
      uStack_20 = param_3 + 1;
      if (cVar11 != cVar6) {
        uStack_20 = param_3;
      }
      pcVar10 = pcVar10 + 1;
      param_3 = uStack_20;
      cVar11 = *pcVar1;
    } while (*pcVar1 != '\0');
  }
  ExceptionList = &pvStack_10;
  FUN_00565660(uStack_20,0);
  uStack_8 = 0;
  uStack_24 = 0xfffffffe;
  uStack_18 = 1;
  pppuStack_1c = apppuStack_40[0];
  while( true ) {
    bVar5 = false;
    iVar12 = 0;
    uStack_14 = 0;
    if (uStack_20 == 0) break;
    do {
      cVar6 = param_4[iVar12];
      if (cVar6 != '\0') {
        do {
          if (cVar6 == *param_4) break;
          cVar6 = param_4[iVar12 + 1];
          iVar12 = iVar12 + 1;
        } while (cVar6 != '\0');
      }
      ppppuVar7 = apppuStack_40;
      if (0xf < uStack_2c) {
        ppppuVar7 = (undefined4 ****)pppuStack_1c;
      }
      if (*(char *)((int)ppppuVar7 + uStack_14) == '\0') {
        iVar12 = iVar12 + uStack_18;
        pcStack_28 = param_4 + iVar12;
        cVar6 = param_4[iVar12];
        if ((cVar6 == *param_4) || (cVar6 == '\0')) {
          ppppuVar7 = apppuStack_40;
          if (0xf < uStack_2c) {
            ppppuVar7 = (undefined4 ****)apppuStack_40[0];
          }
          uVar9 = 0x7f;
          if (uStack_18 < 0x7f) {
            uVar9 = (char)uStack_18;
          }
          *(undefined *)((int)ppppuVar7 + uStack_14) = uVar9;
          uStack_24 = uStack_14;
        }
        else {
          if (*(char *)(param_1 + 1) == '\0') {
            piVar3 = (int *)*param_1;
            if (piVar3 == (int *)0x0) {
LAB_00a8d6c3:
              *param_1 = 0;
            }
            else {
              if ((*(byte **)piVar3[7] == (byte *)0x0) || (*(int *)piVar3[0xb] < 1)) {
                uVar8 = (**(code **)(*piVar3 + 0x18))();
              }
              else {
                uVar8 = (uint)**(byte **)piVar3[7];
              }
              if (uVar8 == 0xffffffff) goto LAB_00a8d6c3;
              *(char *)((int)param_1 + 5) = (char)uVar8;
            }
            *(undefined *)(param_1 + 1) = 1;
          }
          if (*(char *)(param_2 + 1) == '\0') {
            piVar3 = (int *)*param_2;
            if (piVar3 == (int *)0x0) {
LAB_00a8d6fe:
              *param_2 = 0;
            }
            else {
              if ((*(byte **)piVar3[7] == (byte *)0x0) || (*(int *)piVar3[0xb] < 1)) {
                uVar8 = (**(code **)(*piVar3 + 0x18))();
              }
              else {
                uVar8 = (uint)**(byte **)piVar3[7];
              }
              if (uVar8 == 0xffffffff) goto LAB_00a8d6fe;
              *(char *)((int)param_2 + 5) = (char)uVar8;
            }
            *(undefined *)(param_2 + 1) = 1;
          }
          piVar3 = (int *)*param_1;
          if (piVar3 == (int *)0x0) {
            iVar2 = *param_2;
          }
          else {
            iVar2 = *param_2;
          }
          if (iVar2 == 0) {
            if (*(char *)(param_1 + 1) == '\0') {
              if (piVar3 == (int *)0x0) {
LAB_00a8d76f:
                *param_1 = 0;
              }
              else {
                if ((*(byte **)piVar3[7] == (byte *)0x0) || (*(int *)piVar3[0xb] < 1)) {
                  uVar8 = (**(code **)(*piVar3 + 0x18))();
                }
                else {
                  uVar8 = (uint)**(byte **)piVar3[7];
                }
                if (uVar8 == 0xffffffff) goto LAB_00a8d76f;
                *(char *)((int)param_1 + 5) = (char)uVar8;
              }
              *(undefined *)(param_1 + 1) = 1;
            }
            if (*pcStack_28 == *(char *)((int)param_1 + 5)) {
              bVar5 = true;
              goto LAB_00a8d7c3;
            }
          }
          ppppuVar7 = apppuStack_40;
          if (0xf < uStack_2c) {
            ppppuVar7 = (undefined4 ****)apppuStack_40[0];
          }
          uVar9 = 0x7f;
          if (uStack_18 < 0x7f) {
            uVar9 = (char)uStack_18;
          }
          *(undefined *)((int)ppppuVar7 + uStack_14) = uVar9;
        }
        pppuStack_1c = apppuStack_40[0];
      }
      else {
        ppppuVar7 = apppuStack_40;
        if (0xf < uStack_2c) {
          ppppuVar7 = (undefined4 ****)pppuStack_1c;
        }
        iVar12 = iVar12 + *(char *)((int)ppppuVar7 + uStack_14);
      }
LAB_00a8d7c3:
      uStack_14 = uStack_14 + 1;
    } while (uStack_14 < uStack_20);
    if (!bVar5) break;
    if (*(char *)(param_1 + 1) == '\0') {
      piVar3 = (int *)*param_1;
      if (piVar3 == (int *)0x0) {
LAB_00a8d809:
        *param_1 = 0;
      }
      else {
        if ((*(byte **)piVar3[7] == (byte *)0x0) || (*(int *)piVar3[0xb] < 1)) {
          uVar8 = (**(code **)(*piVar3 + 0x18))();
        }
        else {
          uVar8 = (uint)**(byte **)piVar3[7];
        }
        if (uVar8 == 0xffffffff) goto LAB_00a8d809;
        *(char *)((int)param_1 + 5) = (char)uVar8;
      }
      *(undefined *)(param_1 + 1) = 1;
    }
    if (*(char *)(param_2 + 1) == '\0') {
      piVar3 = (int *)*param_2;
      if (piVar3 == (int *)0x0) {
LAB_00a8d844:
        *param_2 = 0;
      }
      else {
        if ((*(byte **)piVar3[7] == (byte *)0x0) || (*(int *)piVar3[0xb] < 1)) {
          uVar8 = (**(code **)(*piVar3 + 0x18))();
        }
        else {
          uVar8 = (uint)**(byte **)piVar3[7];
        }
        if (uVar8 == 0xffffffff) goto LAB_00a8d844;
        *(char *)((int)param_2 + 5) = (char)uVar8;
      }
      *(undefined *)(param_2 + 1) = 1;
    }
    piVar3 = (int *)*param_1;
    if (piVar3 == (int *)0x0) {
      if (*param_2 == 0) break;
    }
    else if (*param_2 != 0) break;
    uStack_18 = uStack_18 + 1;
    if (piVar3 == (int *)0x0) {
LAB_00a8d8d2:
      *param_1 = 0;
      *(undefined *)(param_1 + 1) = 1;
      uStack_24 = 0xffffffff;
    }
    else {
      if (*(int *)piVar3[7] == 0) {
LAB_00a8d8b8:
        uVar8 = (**(code **)(*piVar3 + 0x1c))();
      }
      else {
        iVar12 = *(int *)piVar3[0xb];
        if (iVar12 < 1) goto LAB_00a8d8b8;
        *(int *)piVar3[0xb] = iVar12 + -1;
        pbVar4 = *(byte **)piVar3[7];
        *(byte **)piVar3[7] = pbVar4 + 1;
        uVar8 = (uint)*pbVar4;
      }
      if (uVar8 == 0xffffffff) goto LAB_00a8d8d2;
      *(undefined *)(param_1 + 1) = 0;
      uStack_24 = 0xffffffff;
    }
  }
  if (0xf < uStack_2c) {
    uVar8 = uStack_2c + 1;
    ppppuVar7 = (undefined4 ****)apppuStack_40[0];
    if (0xfff < uVar8) {
      ppppuVar7 = (undefined4 ****)apppuStack_40[0][-1];
      uVar8 = uStack_2c + 0x24;
      if (0x1f < (uint)((int)apppuStack_40[0] + (-4 - (int)ppppuVar7))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar7,uVar8);
  }
  ExceptionList = pvStack_10;
  return uStack_24;
}



/* FUNCTION 21640 ; VA 0x00a8d910 ; thunk_FUN_00a8d930 */

int * __fastcall thunk_FUN_00a8d930(int *param_1)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined auStack_1c [8];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e56d0;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00a8dcc0();
  if (iVar5 == iVar1) {
    piVar2 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar2 = (int *)0x0;
    }
    if (piVar2 != (int *)0x0) {
      ExceptionList = pvStack_10;
      return piVar2;
    }
  }
  iVar5 = *param_1;
  iVar1 = FUN_0088cb40();
  if (iVar5 == iVar1) {
    uStack_14 = 0x3f800000;
    FUN_00a8e2b0(CONCAT44(DAT_018ce2f8,DAT_018ce2f8),0x3f800000);
    iVar5 = *param_1;
    iStack_8 = 0;
    iVar1 = FUN_0088cb40();
    if (iVar5 != iVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar2 = param_1 + 2;
    piVar3 = piVar2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    if (piVar3[4] != 0) {
      uVar4 = FUN_00a91730();
      iStack_8._0_1_ = 1;
      FUN_00613d00(uVar4);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_00617bc0();
      iVar1 = FUN_00630c10();
      iVar5 = param_1[1];
      if (iVar5 == iVar1) {
        FUN_00613d00(auStack_1c);
      }
      else {
        if (iVar5 != 0) {
          (**(code **)(iVar5 + 8))(piVar2);
          param_1[1] = 0;
        }
        FUN_00a8df50(auStack_1c);
        param_1[1] = iVar1;
      }
      iVar5 = FUN_00a8dcc0();
      *param_1 = iVar5;
      iVar1 = FUN_00a8dcc0();
      if (iVar5 == iVar1) {
        if (param_1[1] == 0) {
          piVar2 = (int *)0x0;
        }
        FUN_00617bc0();
        ExceptionList = pvStack_10;
        return piVar2;
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    iStack_8 = 0xffffffff;
    thunk_FUN_00617bc0();
  }
  thunk_FUN_00a8dcc0();
  uVar4 = FUN_005543f0();
  uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar6,uVar4);
}



/* FUNCTION 21641 ; VA 0x00a8d920 ; thunk_FUN_00a8dac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __fastcall thunk_FUN_00a8dac0(int *param_1)

{
  undefined *puVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e56eb;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00a8dd60();
  if (iVar5 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    if (piVar3 != (int *)0x0) {
      ExceptionList = pvStack_10;
      return piVar3;
    }
  }
  iVar5 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar5 == iVar2) {
    iVar5 = *param_1;
    iStack_24 = 0;
    iStack_20 = 0;
    iStack_1c = 0;
    iStack_18 = 0;
    iStack_14 = 0;
    iVar2 = FUN_0088cb40();
    if (iVar5 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_1 + 2;
    piVar4 = piVar3;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    if (piVar4[4] != 0) {
      FUN_00565000(piVar4,1,1);
      uStack_8 = 0;
      FUN_00a8d320(&iStack_24);
      FUN_00a8d320(&iStack_20);
      FUN_00a8d320(&iStack_1c);
      FUN_00a8d320(&iStack_18);
      FUN_00a8d320(&iStack_14);
      uStack_8 = 0xffffffff;
      FUN_005703e0();
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead358
          ) && (FUN_016f3809(&DAT_01ead358), DAT_01ead358 == -1)) {
        _DAT_01ead34c = FUN_00619ed0;
        _DAT_01ead350 = FUN_00619ed0;
        _DAT_01ead354 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ead358);
      }
      puVar1 = (undefined *)param_1[1];
      if (puVar1 == &DAT_01ead34c) {
        *piVar3 = iStack_24;
        param_1[3] = iStack_20;
        param_1[4] = iStack_1c;
        param_1[5] = iStack_18;
        param_1[6] = iStack_14;
      }
      else {
        if (puVar1 != (undefined *)0x0) {
          (**(code **)(puVar1 + 8))(piVar3);
        }
        param_1[2] = iStack_24;
        param_1[3] = iStack_20;
        param_1[4] = iStack_1c;
        param_1[5] = iStack_18;
        param_1[6] = iStack_14;
        param_1[1] = (int)&DAT_01ead34c;
      }
      iVar5 = FUN_00a8dd60();
      *param_1 = iVar5;
      iVar2 = FUN_00a8dd60();
      if (iVar5 == iVar2) {
        piVar3 = param_1 + 2;
        if (param_1[1] == 0) {
          piVar3 = (int *)0x0;
        }
        ExceptionList = pvStack_10;
        return piVar3;
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
  }
  thunk_FUN_00a8dd60();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 21642 ; VA 0x00a8d930 ; FUN_00a8d930 */

int * __fastcall FUN_00a8d930(int *param_1)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined auStack_1c [8];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e56d0;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00a8dcc0();
  if (iVar5 == iVar1) {
    piVar2 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar2 = (int *)0x0;
    }
    if (piVar2 != (int *)0x0) {
      ExceptionList = pvStack_10;
      return piVar2;
    }
  }
  iVar5 = *param_1;
  iVar1 = FUN_0088cb40();
  if (iVar5 == iVar1) {
    uStack_14 = 0x3f800000;
    FUN_00a8e2b0(CONCAT44(DAT_018ce2f8,DAT_018ce2f8),0x3f800000);
    iVar5 = *param_1;
    iStack_8 = 0;
    iVar1 = FUN_0088cb40();
    if (iVar5 != iVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar2 = param_1 + 2;
    piVar3 = piVar2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    if (piVar3[4] != 0) {
      uVar4 = FUN_00a91730();
      iStack_8._0_1_ = 1;
      FUN_00613d00(uVar4);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_00617bc0();
      iVar1 = FUN_00630c10();
      iVar5 = param_1[1];
      if (iVar5 == iVar1) {
        FUN_00613d00(auStack_1c);
      }
      else {
        if (iVar5 != 0) {
          (**(code **)(iVar5 + 8))(piVar2);
          param_1[1] = 0;
        }
        FUN_00a8df50(auStack_1c);
        param_1[1] = iVar1;
      }
      iVar5 = FUN_00a8dcc0();
      *param_1 = iVar5;
      iVar1 = FUN_00a8dcc0();
      if (iVar5 == iVar1) {
        if (param_1[1] == 0) {
          piVar2 = (int *)0x0;
        }
        FUN_00617bc0();
        ExceptionList = pvStack_10;
        return piVar2;
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    iStack_8 = 0xffffffff;
    thunk_FUN_00617bc0();
  }
  thunk_FUN_00a8dcc0();
  uVar4 = FUN_005543f0();
  uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar6,uVar4);
}



/* FUNCTION 21643 ; VA 0x00a8dac0 ; FUN_00a8dac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __fastcall FUN_00a8dac0(int *param_1)

{
  undefined *puVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e56eb;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00a8dd60();
  if (iVar5 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    if (piVar3 != (int *)0x0) {
      ExceptionList = pvStack_10;
      return piVar3;
    }
  }
  iVar5 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar5 == iVar2) {
    iVar5 = *param_1;
    iStack_24 = 0;
    iStack_20 = 0;
    iStack_1c = 0;
    iStack_18 = 0;
    iStack_14 = 0;
    iVar2 = FUN_0088cb40();
    if (iVar5 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_1 + 2;
    piVar4 = piVar3;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    if (piVar4[4] != 0) {
      FUN_00565000(piVar4,1,1);
      uStack_8 = 0;
      FUN_00a8d320(&iStack_24);
      FUN_00a8d320(&iStack_20);
      FUN_00a8d320(&iStack_1c);
      FUN_00a8d320(&iStack_18);
      FUN_00a8d320(&iStack_14);
      uStack_8 = 0xffffffff;
      FUN_005703e0();
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead358
          ) && (FUN_016f3809(&DAT_01ead358), DAT_01ead358 == -1)) {
        _DAT_01ead34c = FUN_00619ed0;
        _DAT_01ead350 = FUN_00619ed0;
        _DAT_01ead354 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ead358);
      }
      puVar1 = (undefined *)param_1[1];
      if (puVar1 == &DAT_01ead34c) {
        *piVar3 = iStack_24;
        param_1[3] = iStack_20;
        param_1[4] = iStack_1c;
        param_1[5] = iStack_18;
        param_1[6] = iStack_14;
      }
      else {
        if (puVar1 != (undefined *)0x0) {
          (**(code **)(puVar1 + 8))(piVar3);
        }
        param_1[2] = iStack_24;
        param_1[3] = iStack_20;
        param_1[4] = iStack_1c;
        param_1[5] = iStack_18;
        param_1[6] = iStack_14;
        param_1[1] = (int)&DAT_01ead34c;
      }
      iVar5 = FUN_00a8dd60();
      *param_1 = iVar5;
      iVar2 = FUN_00a8dd60();
      if (iVar5 == iVar2) {
        piVar3 = param_1 + 2;
        if (param_1[1] == 0) {
          piVar3 = (int *)0x0;
        }
        ExceptionList = pvStack_10;
        return piVar3;
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
  }
  thunk_FUN_00a8dd60();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 21644 ; VA 0x00a8dcc0 ; FUN_00a8dcc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a8dcc0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e570c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeae20) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeae20);
    if (DAT_01eeae20 == -1) {
      uStack_8 = 0;
      FUN_00888860("ColorSequence",0x29,0,0,0);
      _DAT_01eeadfc = RBX::Reflection::TType<class_RBX::ColorSequence>::vftable;
      FUN_016f3654(&LAB_0188aca0);
      FUN_016f37bf(&DAT_01eeae20);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeadfc;
}



/* FUNCTION 21645 ; VA 0x00a8dd60 ; FUN_00a8dd60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a8dd60(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e572c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeae48) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeae48);
    if (DAT_01eeae48 == -1) {
      uStack_8 = 0;
      FUN_00888860("ColorSequenceKeypoint",0x2a,0,0,0);
      _DAT_01eeae24 = RBX::Reflection::TType<class_RBX::ColorSequenceKeypoint>::vftable;
      FUN_016f3654(&LAB_0188acb0);
      FUN_016f37bf(&DAT_01eeae48);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeae24;
}



/* FUNCTION 21646 ; VA 0x00a8de00 ; FUN_00a8de00 */

int * FUN_00a8de00(int param_1)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  undefined1 *puVar5;
  bool bVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791cbf;
  pvStack_10 = ExceptionList;
  bVar6 = false;
  ExceptionList = &pvStack_10;
  FUN_016dda75(0);
  piVar2 = DAT_01eeae50;
  uStack_8 = 0;
  if (DAT_01eeae4c == 0) {
    FUN_016dda75(0);
    if (DAT_01eeae4c == 0) {
      DAT_01eeae4c = DAT_021130c8 + 1;
      DAT_021130c8 = DAT_01eeae4c;
    }
    FUN_016ddacd();
  }
  uVar1 = DAT_01eeae4c;
  iVar3 = *(int *)(param_1 + 4);
  if (DAT_01eeae4c < *(uint *)(iVar3 + 0xc)) {
    piVar4 = *(int **)(*(int *)(iVar3 + 8) + DAT_01eeae4c * 4);
    if (piVar4 != (int *)0x0) goto LAB_00a8df31;
  }
  else {
    piVar4 = (int *)0x0;
  }
  if (*(char *)(iVar3 + 0x14) == '\0') {
LAB_00a8dea3:
    if (piVar4 != (int *)0x0) goto LAB_00a8df31;
  }
  else {
    iVar3 = FUN_016de17b();
    if (uVar1 < *(uint *)(iVar3 + 0xc)) {
      piVar4 = *(int **)(*(int *)(iVar3 + 8) + uVar1 * 4);
      goto LAB_00a8dea3;
    }
  }
  piVar4 = piVar2;
  if (piVar2 == (int *)0x0) {
    piVar4 = (int *)FUN_01674e20(8);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (piVar4 == (int *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      iVar3 = *(int *)(param_1 + 4);
      if (iVar3 == 0) {
        puVar5 = &DAT_018bc9b8;
      }
      else {
        puVar5 = *(undefined1 **)(iVar3 + 0x18);
        if (puVar5 == (undefined1 *)0x0) {
          puVar5 = (undefined1 *)(iVar3 + 0x1c);
        }
      }
      FUN_0054f870(puVar5);
      bVar6 = true;
      piVar4[1] = 0;
      *piVar4 = (int)std::
                     num_get<char,class_std::istreambuf_iterator<char,struct_std::char_traits<char>_>_>
                     ::vftable;
    }
    if (bVar6) {
      FUN_00550e70();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_016de14f(piVar4);
    (**(code **)(*piVar4 + 4))();
    DAT_01eeae50 = piVar4;
  }
LAB_00a8df31:
  FUN_016ddacd();
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 21647 ; VA 0x00a8df50 ; FUN_00a8df50 */

int * __thiscall FUN_00a8df50(int *param_1,undefined4 param_2)

{
  float fVar1;
  undefined8 uVar2;
  int iVar3;
  float fVar4;
  int iVar5;
  int iVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fStack_20;
  float fStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5748;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uStack_8 = 0;
  if (DAT_01d66508 != '\0') {
    FUN_00613d00(param_2);
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_00613d00(param_2);
  fVar4 = DAT_018ce2f8;
  iVar6 = (param_1[1] - *param_1) / 0x14;
  if (iVar6 != 0) {
    iVar5 = 0;
    do {
      fVar1 = *(float *)(iVar5 + *param_1);
      fVar8 = 0.0;
      if (0.0 <= fVar1) {
        fVar8 = fVar1;
      }
      fVar1 = fVar4;
      if (fVar8 <= fVar4) {
        fVar1 = fVar8;
      }
      *(float *)(iVar5 + *param_1) = fVar1;
      iVar3 = *param_1;
      uVar2 = *(undefined8 *)(iVar5 + 4 + iVar3);
      fVar1 = *(float *)(iVar5 + 0xc + iVar3);
      fStack_20 = (float)uVar2;
      fVar8 = 0.0;
      if (0.0 <= fStack_20) {
        fVar8 = fStack_20;
      }
      if (fVar4 < fVar8) {
        fVar8 = fVar4;
      }
      fStack_1c = (float)((ulonglong)uVar2 >> 0x20);
      fVar7 = 0.0;
      if (0.0 <= fStack_1c) {
        fVar7 = fStack_1c;
      }
      if (fVar4 < fVar7) {
        fVar7 = fVar4;
      }
      fVar9 = 0.0;
      if (0.0 <= fVar1) {
        fVar9 = fVar1;
      }
      if (fVar4 < fVar9) {
        fVar9 = fVar4;
      }
      *(float *)(iVar5 + 4 + iVar3) = fVar8;
      *(float *)(iVar5 + 8 + iVar3) = fVar7;
      *(float *)(iVar5 + 0xc + iVar3) = fVar9;
      *(undefined4 *)(iVar5 + 0x10 + iVar3) = 0;
      iVar5 = iVar5 + 0x14;
      iVar6 = iVar6 + -1;
    } while (iVar6 != 0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21648 ; VA 0x00a8e070 ; FUN_00a8e070 */

undefined4 * __thiscall FUN_00a8e070(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5748;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uStack_8 = 0;
  cVar2 = FUN_00a91f00();
  if (cVar2 == '\0') {
    puVar3 = (undefined4 *)FUN_00a8e2b0(CONCAT44(DAT_018ce2f8,DAT_018ce2f8),0x3f800000);
    if (puVar3 != param_1) {
      uVar1 = *puVar3;
      *puVar3 = *param_1;
      *param_1 = uVar1;
      uVar1 = puVar3[1];
      puVar3[1] = param_1[1];
      param_1[1] = uVar1;
      uVar1 = puVar3[2];
      puVar3[2] = param_1[2];
      param_1[2] = uVar1;
    }
    FUN_00617bc0();
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_00613d00(param_2);
  *(undefined4 *)*param_1 = 0;
  *(undefined4 *)(param_1[1] + -0x14) = 0x3f800000;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21649 ; VA 0x00a8e160 ; FUN_00a8e160 */

undefined4 * __thiscall
FUN_00a8e160(undefined4 *param_1,undefined8 param_2,float param_3,undefined8 param_4,float param_5)

{
  undefined4 *puVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  float fStack_14;
  undefined uStack_5;
  
  FUN_006ab150(2,&uStack_5);
  if (DAT_01d66508 != '\0') {
    fStack_14 = (float)((ulonglong)param_2 >> 0x20);
    fVar2 = 0.0;
    if (0.0 <= (float)param_2) {
      fVar2 = (float)param_2;
    }
    fVar4 = 0.0;
    if (0.0 <= param_3) {
      fVar4 = param_3;
    }
    fVar5 = 0.0;
    if (0.0 <= param_5) {
      fVar5 = param_5;
    }
    fVar3 = DAT_018ce2f8;
    if (fVar2 <= DAT_018ce2f8) {
      fVar3 = fVar2;
    }
    fVar2 = 0.0;
    if (0.0 <= fStack_14) {
      fVar2 = fStack_14;
    }
    fVar6 = DAT_018ce2f8;
    if (fVar2 <= DAT_018ce2f8) {
      fVar6 = fVar2;
    }
    param_3 = DAT_018ce2f8;
    if (fVar4 <= DAT_018ce2f8) {
      param_3 = fVar4;
    }
    param_5 = DAT_018ce2f8;
    if (fVar5 <= DAT_018ce2f8) {
      param_5 = fVar5;
    }
    fVar2 = 0.0;
    if (0.0 <= (float)param_4) {
      fVar2 = (float)param_4;
    }
    fVar4 = DAT_018ce2f8;
    if (fVar2 <= DAT_018ce2f8) {
      fVar4 = fVar2;
    }
    param_2._4_4_ = (float)((ulonglong)param_4 >> 0x20);
    fVar2 = 0.0;
    if (0.0 <= param_2._4_4_) {
      fVar2 = param_2._4_4_;
    }
    fVar5 = DAT_018ce2f8;
    if (fVar2 <= DAT_018ce2f8) {
      fVar5 = fVar2;
    }
    param_4 = CONCAT44(fVar5,fVar4);
    param_2 = CONCAT44(fVar6,fVar3);
  }
  puVar1 = (undefined4 *)*param_1;
  uStack_1c = (undefined4)param_2;
  uStack_18 = (undefined4)((ulonglong)param_2 >> 0x20);
  *puVar1 = 0;
  puVar1[1] = uStack_1c;
  puVar1[2] = uStack_18;
  puVar1[3] = param_3;
  puVar1[4] = 0;
  uStack_1c = (undefined4)param_4;
  uStack_18 = (undefined4)((ulonglong)param_4 >> 0x20);
  puVar1[5] = 0x3f800000;
  puVar1[6] = uStack_1c;
  puVar1[7] = uStack_18;
  puVar1[8] = param_5;
  puVar1[9] = 0;
  return param_1;
}



/* FUNCTION 21650 ; VA 0x00a8e2b0 ; FUN_00a8e2b0 */

undefined4 * __thiscall FUN_00a8e2b0(undefined4 *param_1,undefined8 param_2,float param_3)

{
  undefined4 *puVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  float fStack_14;
  undefined uStack_5;
  
  FUN_006ab150(2,&uStack_5);
  if (DAT_01d66508 != '\0') {
    fStack_14 = (float)((ulonglong)param_2 >> 0x20);
    fVar2 = 0.0;
    if (0.0 <= (float)param_2) {
      fVar2 = (float)param_2;
    }
    fVar4 = 0.0;
    if (0.0 <= param_3) {
      fVar4 = param_3;
    }
    fVar3 = DAT_018ce2f8;
    if (fVar2 <= DAT_018ce2f8) {
      fVar3 = fVar2;
    }
    fVar2 = 0.0;
    if (0.0 <= fStack_14) {
      fVar2 = fStack_14;
    }
    param_3 = DAT_018ce2f8;
    if (fVar4 <= DAT_018ce2f8) {
      param_3 = fVar4;
    }
    fVar4 = DAT_018ce2f8;
    if (fVar2 <= DAT_018ce2f8) {
      fVar4 = fVar2;
    }
    param_2 = CONCAT44(fVar4,fVar3);
  }
  puVar1 = (undefined4 *)*param_1;
  uStack_1c = (undefined4)param_2;
  uStack_18 = (undefined4)((ulonglong)param_2 >> 0x20);
  *puVar1 = 0;
  puVar1[1] = uStack_1c;
  puVar1[2] = uStack_18;
  puVar1[3] = param_3;
  puVar1[4] = 0;
  puVar1[5] = 0x3f800000;
  puVar1[6] = uStack_1c;
  puVar1[7] = uStack_18;
  puVar1[8] = param_3;
  puVar1[9] = 0;
  return param_1;
}



/* FUNCTION 21651 ; VA 0x00a8e3b0 ; FUN_00a8e3b0 */

int * __thiscall FUN_00a8e3b0(int *param_1,float param_2)

{
  undefined *puVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  undefined auStack_2c [4];
  int *piStack_28;
  int *piStack_24;
  uint uStack_20;
  uint uStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5797;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff7c;
  iVar3 = *param_1;
  piVar5 = *(int **)(*(int *)(iVar3 + 4) + 0x38 + (int)param_1);
  ExceptionList = &pvStack_10;
  piStack_24 = param_1;
  puVar1 = &stack0xffffff7c;
  if (piVar5 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar5 + 4))();
    iVar3 = *param_1;
    puVar1 = puStack_14;
  }
  puStack_14 = puVar1;
  uStack_8 = 0;
  if (((*(int *)(*(int *)(iVar3 + 4) + 0xc + (int)param_1) == 0) &&
      (piVar5 = *(int **)(*(int *)(iVar3 + 4) + 0x3c + (int)param_1), piVar5 != (int *)0x0)) &&
     (piVar5 != param_1)) {
    FUN_00581480();
    iVar3 = *param_1;
  }
  uStack_8 = 1;
  if (*(int *)(*(int *)(iVar3 + 4) + 0xc + (int)param_1) != 0) {
    uVar7 = *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc);
    uVar6 = uVar7 | 4;
    if (*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) != 0) {
      uVar6 = uVar7;
    }
    FUN_00554460(uVar6,0);
    uStack_8 = 10;
    cVar2 = thunk_FUN_0170e3b7();
    if (cVar2 == '\0') {
      FUN_00577770();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    piVar5 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
    if (piVar5 != (int *)0x0) {
      (**(code **)(*piVar5 + 8))();
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  piVar5 = *(int **)(*(int *)(*(int *)(iVar3 + 4) + 0x30 + (int)param_1) + 4);
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  piStack_18 = piVar5;
  (**(code **)(*piVar5 + 4))();
  uStack_8._0_1_ = 3;
  FUN_016dda75();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  piStack_28 = DAT_01ea8a14;
  uStack_1c = DAT_01e90d00;
  if (DAT_01e90d00 == 0) {
    FUN_016dda75();
    if (DAT_01e90d00 == 0) {
      DAT_01e90d00 = DAT_021130c8 + 1;
      DAT_021130c8 = DAT_01e90d00;
    }
    FUN_016ddacd();
  }
  uStack_1c = DAT_01e90d00;
  if (DAT_01e90d00 < (uint)piVar5[3]) {
    piVar5 = *(int **)(piVar5[2] + DAT_01e90d00 * 4);
    if (piVar5 != (int *)0x0) goto LAB_00a8e54b;
  }
  else {
    piVar5 = (int *)0x0;
  }
  if (*(char *)(piStack_18 + 5) == '\0') {
LAB_00a8e4d9:
    if (piVar5 != (int *)0x0) goto LAB_00a8e54b;
  }
  else {
    iVar3 = FUN_016de17b();
    if (uStack_1c < *(uint *)(iVar3 + 0xc)) {
      piVar5 = *(int **)(*(int *)(iVar3 + 8) + uStack_1c * 4);
      goto LAB_00a8e4d9;
    }
  }
  piVar5 = piStack_28;
  if (piStack_28 == (int *)0x0) {
    piVar5 = (int *)FUN_01674e20();
    uStack_8._0_1_ = 5;
    if (piVar5 == (int *)0x0) {
      piVar5 = (int *)0x0;
    }
    else {
      piStack_28 = piVar5;
      FUN_0054f870();
      piVar5[1] = 0;
      *piVar5 = (int)std::
                     num_put<char,class_std::ostreambuf_iterator<char,struct_std::char_traits<char>_>_>
                     ::vftable;
      FUN_00550e70();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    piStack_28 = piVar5;
    FUN_016de14f();
    (**(code **)(*piVar5 + 4))();
    DAT_01ea8a14 = piVar5;
  }
LAB_00a8e54b:
  FUN_016ddacd();
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  puVar4 = (undefined4 *)(**(code **)(*piStack_18 + 8))();
  if (puVar4 != (undefined4 *)0x0) {
    (**(code **)*puVar4)();
  }
  uStack_20 = uStack_20 & 0xffffff00;
  iVar3 = *(int *)(*param_1 + 4) + (int)param_1;
  piStack_28 = (int *)CONCAT31(piStack_28._1_3_,
                               *(undefined *)(*(int *)(*param_1 + 4) + 0x40 + (int)param_1));
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  uVar7 = uStack_20;
  (**(code **)(*piVar5 + 0x14))
            (auStack_2c,uStack_20,*(undefined4 *)(iVar3 + 0x38),iVar3,piStack_28,(double)param_2);
  piVar5 = (int *)FUN_00a8e5d9(uVar7);
  return piVar5;
}



/* FUNCTION 21652 ; VA 0x00a8e5ba ; Catch_All@00a8e5ba */

undefined * Catch_All_00a8e5ba(void)

{
  FUN_005565b0(4,1);
  return &DAT_00a8e5d3;
}



/* FUNCTION 21653 ; VA 0x00a8e5d9 ; FUN_00a8e5d9 */

void FUN_00a8e5d9(void)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  int unaff_EBP;
  int *unaff_ESI;
  uint unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  uVar5 = *(uint *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0xc) | unaff_EDI;
  uVar4 = uVar5 | 4;
  if (*(int *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0x38) != 0) {
    uVar4 = uVar5;
  }
  FUN_00554460(uVar4,0);
  *(undefined4 *)(unaff_EBP + -4) = 10;
  cVar3 = thunk_FUN_0170e3b7();
  if (cVar3 == '\0') {
    FUN_00577770();
  }
  iVar1 = *unaff_ESI;
  *(undefined *)(unaff_EBP + -4) = 0xb;
  piVar2 = *(int **)(*(int *)(iVar1 + 4) + 0x38 + (int)unaff_ESI);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 8))();
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 21654 ; VA 0x00a8e650 ; FUN_00a8e650 */

uint __thiscall FUN_00a8e650(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  bool bVar6;
  
  piVar1 = (int *)param_1[1];
  param_1 = (int *)*param_1;
  piVar2 = (int *)(((int)piVar1 - (int)param_1) / 0x14);
  if (piVar2 == (int *)((param_2[1] - *param_2) / 0x14)) {
    if (param_1 != piVar1) {
      iVar4 = *param_2 - (int)param_1;
      do {
        piVar2 = (int *)(iVar4 + (int)param_1);
        uVar5 = 0x10;
        piVar3 = param_1;
        do {
          if (*piVar3 != *piVar2) goto LAB_00a8e6d2;
          piVar3 = piVar3 + 1;
          piVar2 = piVar2 + 1;
          bVar6 = 3 < uVar5;
          uVar5 = uVar5 - 4;
        } while (bVar6);
        param_1 = param_1 + 5;
      } while (param_1 != piVar1);
    }
    return CONCAT31((int3)((uint)piVar2 >> 8),1);
  }
LAB_00a8e6d2:
  return (uint)piVar2 & 0xffffff00;
}



/* FUNCTION 21655 ; VA 0x00a8e6e0 ; FUN_00a8e6e0 */

uint __thiscall FUN_00a8e6e0(int *param_1,int *param_2)

{
  uint uVar1;
  bool bVar2;
  
  uVar1 = 0x10;
  do {
    if (*param_1 != *param_2) {
      return (uint)param_2 & 0xffffff00;
    }
    param_1 = param_1 + 1;
    param_2 = param_2 + 1;
    bVar2 = 3 < uVar1;
    uVar1 = uVar1 - 4;
  } while (bVar2);
  return CONCAT31((int3)((uint)param_2 >> 8),1);
}



/* FUNCTION 21656 ; VA 0x00a8e710 ; FUN_00a8e710 */

uint __fastcall FUN_00a8e710(int *param_1)

{
  int *piVar1;
  uint uVar2;
  
  if (*(char *)(param_1 + 1) == '\0') {
    piVar1 = (int *)*param_1;
    if (piVar1 != (int *)0x0) {
      if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
        uVar2 = (**(code **)(*piVar1 + 0x18))();
      }
      else {
        uVar2 = (uint)**(byte **)piVar1[7];
      }
      if (uVar2 != 0xffffffff) {
        *(char *)((int)param_1 + 5) = (char)uVar2;
        *(undefined *)(param_1 + 1) = 1;
        return uVar2;
      }
    }
    *param_1 = 0;
    *(undefined *)(param_1 + 1) = 1;
  }
  return (uint)*(byte *)((int)param_1 + 5);
}



/* FUNCTION 21657 ; VA 0x00a8e760 ; FUN_00a8e760 */

int * __fastcall FUN_00a8e760(int *param_1)

{
  int *piVar1;
  int iVar2;
  byte *pbVar3;
  uint uVar4;
  
  piVar1 = (int *)*param_1;
  if (piVar1 == (int *)0x0) goto LAB_00a8e79f;
  if (*(int *)piVar1[7] == 0) {
LAB_00a8e78c:
    uVar4 = (**(code **)(*piVar1 + 0x1c))();
  }
  else {
    iVar2 = *(int *)piVar1[0xb];
    if (iVar2 < 1) goto LAB_00a8e78c;
    *(int *)piVar1[0xb] = iVar2 + -1;
    pbVar3 = *(byte **)piVar1[7];
    *(byte **)piVar1[7] = pbVar3 + 1;
    uVar4 = (uint)*pbVar3;
  }
  if (uVar4 != 0xffffffff) {
    *(undefined *)(param_1 + 1) = 0;
    return param_1;
  }
LAB_00a8e79f:
  *param_1 = 0;
  *(undefined *)(param_1 + 1) = 1;
  return param_1;
}



/* FUNCTION 21658 ; VA 0x00a8e7b0 ; FUN_00a8e7b0 */

int FUN_00a8e7b0(undefined4 param_1,char *param_2,int *param_3,undefined4 param_4,int param_5,
                int *param_6)

{
  byte *pbVar1;
  int iVar2;
  char cVar3;
  byte bVar4;
  char cVar5;
  bool bVar6;
  int iVar7;
  int *piVar8;
  undefined4 *puVar9;
  int *piVar10;
  uint uVar11;
  undefined *puVar12;
  char ****ppppcVar13;
  int ****ppppiVar14;
  undefined *puVar15;
  char *pcVar16;
  char ****ppppcVar17;
  int iVar18;
  char *pcVar19;
  int ***apppiStack_7c [4];
  int iStack_6c;
  uint uStack_68;
  char ***apppcStack_64 [5];
  uint uStack_50;
  char acStack_4c [10];
  byte bStack_42;
  byte bStack_41;
  byte bStack_40;
  byte bStack_3f;
  undefined auStack_3e [2];
  undefined auStack_3c [4];
  int ***pppiStack_38;
  int *piStack_34;
  char *pcStack_30;
  int iStack_2c;
  int ***pppiStack_28;
  int iStack_24;
  uint uStack_20;
  char *pcStack_1c;
  int iStack_18;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e57d0;
  pvStack_10 = ExceptionList;
  if ((*(uint *)(param_5 + 0x14) & 0x3000) == 0x3000) {
    ExceptionList = &pvStack_10;
    iVar7 = FUN_00a8f370(param_1,param_2,param_3,param_4,param_5,param_6);
    ExceptionList = pvStack_10;
    return iVar7;
  }
  piVar10 = *(int **)(*(int *)(param_5 + 0x30) + 4);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  pppiStack_38 = (int ***)piVar10;
  (**(code **)(*piVar10 + 4))();
  uStack_8 = 1;
  piVar8 = (int *)FUN_00564bf0(auStack_3c);
  uStack_8 = 2;
  piStack_34 = piVar8;
  if ((piVar10 != (int *)0x0) &&
     (puVar9 = (undefined4 *)(**(code **)(*piVar10 + 8))(), puVar9 != (undefined4 *)0x0)) {
    (**(code **)*puVar9)(1);
  }
  uStack_8 = 0xffffffff;
  (**(code **)(*piVar8 + 0x14))(apppiStack_7c);
  cStack_12 = '\0';
  uStack_20 = uStack_20 & 0xffffff00;
  ppppiVar14 = *(int *****)(*(int *)(param_5 + 0x30) + 4);
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  pppiStack_38 = (int ***)ppppiVar14;
  (*(code *)(*ppppiVar14)[1])();
  uStack_8._0_1_ = 5;
  piVar10 = (int *)FUN_0054e7d0(auStack_3c);
  uStack_8._0_1_ = 6;
  if ((ppppiVar14 != (int ****)0x0) &&
     (puVar9 = (undefined4 *)(*(code *)(*ppppiVar14)[2])(), puVar9 != (undefined4 *)0x0)) {
    (**(code **)*puVar9)(1);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  (**(code **)(*piVar10 + 0x1c))("0123456789-+Ee",&DAT_01946b67,acStack_4c);
  cVar3 = FUN_00a8d280(param_3,param_4);
  pcStack_30 = param_2;
  if (cVar3 == '\0') {
    bVar4 = FUN_00a8e710();
    if (bVar4 == bStack_41) {
      *param_2 = '+';
    }
    else {
      bVar4 = FUN_00a8e710();
      if (bVar4 != bStack_42) goto LAB_00a8e91b;
      *param_2 = '-';
    }
    FUN_00a8e760();
    pcStack_30 = param_2 + 1;
  }
LAB_00a8e91b:
  *pcStack_30 = '0';
  bVar6 = false;
  iVar7 = 0;
  iStack_2c = 0x24;
  pcVar16 = pcStack_30 + 1;
  iStack_24 = 0;
  pcStack_1c = pcVar16;
  iStack_18 = 0;
  if (*param_6 == 1000000000) {
    iStack_2c = 0x300;
  }
  pppiStack_28 = (int ***)apppiStack_7c;
  if (0xf < uStack_68) {
    pppiStack_28 = apppiStack_7c[0];
  }
  if ((*(char *)pppiStack_28 == '\x7f') || (*(char *)pppiStack_28 < '\x01')) {
    cVar3 = FUN_00a8d280(param_3,param_4);
    pcVar19 = pcStack_1c;
    while (cVar3 == '\0') {
      if (*(char *)(param_3 + 1) == '\0') {
        piVar10 = (int *)*param_3;
        if (piVar10 == (int *)0x0) {
LAB_00a8ebe1:
          *param_3 = 0;
        }
        else {
          if ((*(byte **)piVar10[7] == (byte *)0x0) || (*(int *)piVar10[0xb] < 1)) {
            uVar11 = (**(code **)(*piVar10 + 0x18))();
          }
          else {
            uVar11 = (uint)**(byte **)piVar10[7];
          }
          if (uVar11 == 0xffffffff) goto LAB_00a8ebe1;
          *(char *)((int)param_3 + 5) = (char)uVar11;
        }
        *(undefined *)(param_3 + 1) = 1;
      }
      puVar12 = (undefined *)FUN_0170db20(acStack_4c,*(undefined *)((int)param_3 + 5),0xe);
      puVar15 = auStack_3e;
      if (puVar12 != (undefined *)0x0) {
        puVar15 = puVar12;
      }
      uVar11 = (int)puVar15 - (int)acStack_4c;
      pcVar19 = pcVar16;
      if (9 < uVar11) break;
      if (iVar7 < iStack_2c) {
        if ((uVar11 != 0) || (iVar7 != 0)) {
          *pcVar16 = "0123456789-+Ee"[uVar11];
          pcVar16 = pcVar16 + 1;
          iVar7 = iVar7 + 1;
        }
      }
      else {
        iStack_18 = iStack_18 + 1;
        if (uVar11 != 0) {
          uStack_20 = CONCAT31(uStack_20._1_3_,1);
        }
      }
      piVar10 = (int *)*param_3;
      bVar6 = true;
      if (piVar10 == (int *)0x0) {
LAB_00a8ec71:
        *param_3 = 0;
        *(undefined *)(param_3 + 1) = 1;
      }
      else {
        if (*(int *)piVar10[7] == 0) {
LAB_00a8ec61:
          uVar11 = (**(code **)(*piVar10 + 0x1c))();
        }
        else {
          iVar18 = *(int *)piVar10[0xb];
          if (iVar18 < 1) goto LAB_00a8ec61;
          *(int *)piVar10[0xb] = iVar18 + -1;
          pbVar1 = *(byte **)piVar10[7];
          *(byte **)piVar10[7] = pbVar1 + 1;
          uVar11 = (uint)*pbVar1;
        }
        if (uVar11 == 0xffffffff) goto LAB_00a8ec71;
        *(undefined *)(param_3 + 1) = 0;
      }
      cVar3 = FUN_00a8d280(param_3,param_4);
      pcVar19 = pcVar16;
    }
  }
  else {
    if (iStack_6c == 0) {
      cStack_11 = '\0';
    }
    else {
      cStack_11 = (**(code **)(*piStack_34 + 0x10))();
    }
    FUN_00565660(1,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    iVar7 = 0;
    cVar3 = FUN_00a8d280(param_3,param_4);
    ppppcVar17 = (char ****)apppcStack_64[0];
    if (cVar3 == '\0') {
      do {
        if (*(char *)(param_3 + 1) == '\0') {
          piVar10 = (int *)*param_3;
          if (piVar10 == (int *)0x0) {
LAB_00a8e9e1:
            *param_3 = 0;
          }
          else {
            if ((*(byte **)piVar10[7] == (byte *)0x0) || (*(int *)piVar10[0xb] < 1)) {
              uVar11 = (**(code **)(*piVar10 + 0x18))();
            }
            else {
              uVar11 = (uint)**(byte **)piVar10[7];
            }
            if (uVar11 == 0xffffffff) goto LAB_00a8e9e1;
            *(char *)((int)param_3 + 5) = (char)uVar11;
          }
          *(undefined *)(param_3 + 1) = 1;
        }
        puVar12 = (undefined *)FUN_0170db20(acStack_4c,*(undefined *)((int)param_3 + 5),0xe);
        puVar15 = auStack_3e;
        if (puVar12 != (undefined *)0x0) {
          puVar15 = puVar12;
        }
        uVar11 = (int)puVar15 - (int)acStack_4c;
        if (uVar11 < 10) {
          bVar6 = true;
          if (iStack_24 < iStack_2c) {
            if ((uVar11 != 0) || (iStack_24 != 0)) {
              *pcStack_1c = "0123456789-+Ee"[uVar11];
              pcStack_1c = pcStack_1c + 1;
              iStack_24 = iStack_24 + 1;
            }
          }
          else {
            iStack_18 = iStack_18 + 1;
            if (uVar11 != 0) {
              uStack_20 = CONCAT31(uStack_20._1_3_,1);
            }
          }
          ppppcVar13 = apppcStack_64;
          if (0xf < uStack_50) {
            ppppcVar13 = ppppcVar17;
          }
          if (*(char *)((int)ppppcVar13 + iVar7) != '\x7f') {
            ppppcVar13 = apppcStack_64;
            if (0xf < uStack_50) {
              ppppcVar13 = ppppcVar17;
            }
            *(char *)((int)ppppcVar13 + iVar7) = *(char *)((int)ppppcVar13 + iVar7) + '\x01';
            ppppcVar17 = (char ****)apppcStack_64[0];
          }
        }
        else {
          ppppcVar13 = apppcStack_64;
          if (0xf < uStack_50) {
            ppppcVar13 = ppppcVar17;
          }
          if (((*(char *)((int)ppppcVar13 + iVar7) == '\0') || (cStack_11 == '\0')) ||
             (cVar3 = FUN_00a8e710(), cVar3 != cStack_11)) break;
          FUN_005558a0(0);
          iVar7 = iVar7 + 1;
          ppppcVar17 = (char ****)apppcStack_64[0];
        }
        FUN_00a8e760();
        cVar3 = FUN_00a8d280(param_3,param_4);
      } while (cVar3 == '\0');
      if (iVar7 == 0) goto LAB_00a8ead0;
      ppppcVar13 = apppcStack_64;
      if (0xf < uStack_50) {
        ppppcVar13 = ppppcVar17;
      }
      if ('\0' < *(char *)((int)ppppcVar13 + iVar7)) {
        iVar7 = iVar7 + 1;
        goto LAB_00a8ead0;
      }
LAB_00a8eb18:
      cStack_12 = '\x01';
    }
    else {
LAB_00a8ead0:
      while ((pppiStack_38 = pppiStack_28, iVar7 != 0 &&
             (cVar3 = *(char *)pppiStack_28, cVar3 != '\x7f'))) {
        iVar7 = iVar7 + -1;
        if (iVar7 != 0) {
          ppppcVar13 = apppcStack_64;
          if (0xf < uStack_50) {
            ppppcVar13 = ppppcVar17;
          }
          if (cVar3 != *(char *)((int)ppppcVar13 + iVar7)) goto LAB_00a8eb18;
        }
        if (iVar7 == 0) {
          ppppcVar13 = apppcStack_64;
          if (0xf < uStack_50) {
            ppppcVar13 = ppppcVar17;
          }
          if (cVar3 < *(char *)ppppcVar13) goto LAB_00a8eb18;
        }
        ppppiVar14 = (int ****)((int)pppiStack_28 + 1);
        if (*(char *)((int)pppiStack_28 + 1) < '\x01') {
          ppppiVar14 = (int ****)pppiStack_28;
        }
        pppiStack_28 = (int ***)ppppiVar14;
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    iVar7 = iStack_24;
    pcVar19 = pcStack_1c;
    if (0xf < uStack_50) {
      uVar11 = uStack_50 + 1;
      ppppcVar13 = ppppcVar17;
      if (0xfff < uVar11) {
        ppppcVar13 = (char ****)ppppcVar17[-1];
        uVar11 = uStack_50 + 0x24;
        if ((char *)0x1f < (char *)((int)ppppcVar17 + (-4 - (int)ppppcVar13))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppcVar13,uVar11);
      iVar7 = iStack_24;
      pcVar19 = pcStack_1c;
    }
  }
  pcStack_1c = pcVar19;
  cVar3 = FUN_00a8d280(param_3,param_4);
  pcVar16 = pcStack_1c;
  if (cVar3 == '\0') {
    if (*(char *)(param_3 + 1) == '\0') {
      piVar10 = (int *)*param_3;
      if (piVar10 == (int *)0x0) {
LAB_00a8eca6:
        *param_3 = 0;
      }
      else {
        if ((*(byte **)piVar10[7] == (byte *)0x0) || (*(int *)piVar10[0xb] < 1)) {
          uVar11 = (**(code **)(*piVar10 + 0x18))();
        }
        else {
          uVar11 = (uint)**(byte **)piVar10[7];
        }
        if (uVar11 == 0xffffffff) goto LAB_00a8eca6;
        *(char *)((int)param_3 + 5) = (char)uVar11;
      }
      *(undefined *)(param_3 + 1) = 1;
    }
    cVar3 = *(char *)((int)param_3 + 5);
    cVar5 = (**(code **)(*piStack_34 + 0xc))();
    pcVar16 = pcStack_1c;
    if (cVar3 == cVar5) {
      puVar9 = (undefined4 *)FUN_0171df30();
      *pcStack_1c = *(char *)*puVar9;
      pcVar16 = pcStack_1c + 1;
      piVar10 = (int *)*param_3;
      pcStack_1c = pcVar16;
      if (piVar10 != (int *)0x0) {
        if (*(int *)piVar10[7] == 0) {
LAB_00a8ecfc:
          uVar11 = (**(code **)(*piVar10 + 0x1c))();
        }
        else {
          iVar18 = *(int *)piVar10[0xb];
          if (iVar18 < 1) goto LAB_00a8ecfc;
          *(int *)piVar10[0xb] = iVar18 + -1;
          pbVar1 = *(byte **)piVar10[7];
          *(byte **)piVar10[7] = pbVar1 + 1;
          uVar11 = (uint)*pbVar1;
        }
        if (uVar11 != 0xffffffff) {
          *(undefined *)(param_3 + 1) = 0;
          goto LAB_00a8ed1b;
        }
      }
      *param_3 = 0;
      *(undefined *)(param_3 + 1) = 1;
    }
  }
LAB_00a8ed1b:
  if ((*param_6 != 1000000000) && (iVar7 == 0)) {
    cVar3 = FUN_00a8d280(param_3,param_4);
    iVar18 = iStack_18;
    while (cVar3 == '\0') {
      if (*(char *)(param_3 + 1) == '\0') {
        piVar10 = (int *)*param_3;
        if (piVar10 == (int *)0x0) {
LAB_00a8ed81:
          *param_3 = 0;
        }
        else {
          if ((*(byte **)piVar10[7] == (byte *)0x0) || (*(int *)piVar10[0xb] < 1)) {
            uVar11 = (**(code **)(*piVar10 + 0x18))();
          }
          else {
            uVar11 = (uint)**(byte **)piVar10[7];
          }
          if (uVar11 == 0xffffffff) goto LAB_00a8ed81;
          *(char *)((int)param_3 + 5) = (char)uVar11;
        }
        *(undefined *)(param_3 + 1) = 1;
      }
      pcVar16 = pcStack_1c;
      if (*(char *)((int)param_3 + 5) != acStack_4c[0]) break;
      piVar10 = (int *)*param_3;
      iVar18 = iVar18 + -1;
      bVar6 = true;
      if (piVar10 == (int *)0x0) {
LAB_00a8edd1:
        *param_3 = 0;
        *(undefined *)(param_3 + 1) = 1;
      }
      else {
        if (*(int *)piVar10[7] == 0) {
LAB_00a8edc1:
          uVar11 = (**(code **)(*piVar10 + 0x1c))();
        }
        else {
          iVar2 = *(int *)piVar10[0xb];
          if (iVar2 < 1) goto LAB_00a8edc1;
          *(int *)piVar10[0xb] = iVar2 + -1;
          pbVar1 = *(byte **)piVar10[7];
          *(byte **)piVar10[7] = pbVar1 + 1;
          uVar11 = (uint)*pbVar1;
        }
        if (uVar11 == 0xffffffff) goto LAB_00a8edd1;
        *(undefined *)(param_3 + 1) = 0;
      }
      cVar3 = FUN_00a8d280(param_3,param_4);
      pcVar16 = pcStack_1c;
    }
    iStack_18 = iVar18;
    if (iVar18 < 0) {
      *pcVar16 = '0';
      pcVar16 = pcVar16 + 1;
      iStack_18 = iVar18 + 1;
    }
  }
  cVar3 = FUN_00a8d280(param_3,param_4);
  while (cVar3 == '\0') {
    if (*(char *)(param_3 + 1) == '\0') {
      piVar10 = (int *)*param_3;
      if (piVar10 == (int *)0x0) {
LAB_00a8ee49:
        *param_3 = 0;
      }
      else {
        if ((*(byte **)piVar10[7] == (byte *)0x0) || (*(int *)piVar10[0xb] < 1)) {
          uVar11 = (**(code **)(*piVar10 + 0x18))();
        }
        else {
          uVar11 = (uint)**(byte **)piVar10[7];
        }
        if (uVar11 == 0xffffffff) goto LAB_00a8ee49;
        *(char *)((int)param_3 + 5) = (char)uVar11;
      }
      *(undefined *)(param_3 + 1) = 1;
    }
    puVar12 = (undefined *)FUN_0170db20(acStack_4c,*(undefined *)((int)param_3 + 5),0xe);
    puVar15 = auStack_3e;
    if (puVar12 != (undefined *)0x0) {
      puVar15 = puVar12;
    }
    uVar11 = (int)puVar15 - (int)acStack_4c;
    if (9 < uVar11) break;
    if (iVar7 < iStack_2c) {
      *pcVar16 = "0123456789-+Ee"[uVar11];
      pcVar16 = pcVar16 + 1;
      iVar7 = iVar7 + 1;
    }
    else {
      uStack_20 = uStack_20 & 0xff;
      if (uVar11 != 0) {
        uStack_20 = 1;
      }
    }
    piVar10 = (int *)*param_3;
    bVar6 = true;
    if (piVar10 == (int *)0x0) {
LAB_00a8eed9:
      *param_3 = 0;
      *(undefined *)(param_3 + 1) = 1;
    }
    else {
      if (*(int *)piVar10[7] == 0) {
LAB_00a8eec9:
        uVar11 = (**(code **)(*piVar10 + 0x1c))();
      }
      else {
        iVar18 = *(int *)piVar10[0xb];
        if (iVar18 < 1) goto LAB_00a8eec9;
        *(int *)piVar10[0xb] = iVar18 + -1;
        pbVar1 = *(byte **)piVar10[7];
        *(byte **)piVar10[7] = pbVar1 + 1;
        uVar11 = (uint)*pbVar1;
      }
      if (uVar11 == 0xffffffff) goto LAB_00a8eed9;
      *(undefined *)(param_3 + 1) = 0;
    }
    cVar3 = FUN_00a8d280(param_3,param_4);
  }
  if ((char)uStack_20 != '\0') {
    pcVar19 = pcVar16 + -1;
    if (pcVar19 != pcStack_30) {
      do {
        puVar9 = (undefined4 *)FUN_0171df30();
        cVar3 = *pcVar19;
        if (cVar3 != *(char *)*puVar9) {
          if (cVar3 != '9') {
            *pcVar19 = cVar3 + '\x01';
            if (pcVar19 != pcStack_30) goto LAB_00a8ef31;
            break;
          }
          *pcVar19 = '0';
        }
        pcVar19 = pcVar19 + -1;
      } while (pcVar19 != pcStack_30);
    }
    iStack_18 = iStack_18 + 1;
    *pcVar19 = '1';
  }
LAB_00a8ef31:
  if ((!bVar6) || (cVar3 = FUN_00a8d280(param_3,param_4), cVar3 != '\0')) goto LAB_00a8f30d;
  cVar3 = *(char *)(param_3 + 1);
  if (cVar3 == '\0') {
    piVar10 = (int *)*param_3;
    if (piVar10 == (int *)0x0) {
LAB_00a8ef82:
      *param_3 = 0;
    }
    else {
      if ((*(byte **)piVar10[7] == (byte *)0x0) || (*(int *)piVar10[0xb] < 1)) {
        uVar11 = (**(code **)(*piVar10 + 0x18))();
      }
      else {
        uVar11 = (uint)**(byte **)piVar10[7];
      }
      if (uVar11 == 0xffffffff) goto LAB_00a8ef82;
      *(char *)((int)param_3 + 5) = (char)uVar11;
    }
    *(undefined *)(param_3 + 1) = 1;
    cVar3 = '\x01';
  }
  bVar4 = *(byte *)((int)param_3 + 5);
  if (bVar4 != bStack_3f) {
    if (cVar3 == '\0') {
      piVar10 = (int *)*param_3;
      if (piVar10 == (int *)0x0) {
LAB_00a8efd2:
        *param_3 = 0;
        uVar11 = (uint)bVar4;
      }
      else {
        if ((*(byte **)piVar10[7] == (byte *)0x0) || (*(int *)piVar10[0xb] < 1)) {
          uVar11 = (**(code **)(*piVar10 + 0x18))();
          bVar4 = *(byte *)((int)param_3 + 5);
        }
        else {
          uVar11 = (uint)**(byte **)piVar10[7];
        }
        if (uVar11 == 0xffffffff) goto LAB_00a8efd2;
        *(char *)((int)param_3 + 5) = (char)uVar11;
      }
      bVar4 = (byte)uVar11;
      *(undefined *)(param_3 + 1) = 1;
    }
    if (bVar4 != bStack_40) goto LAB_00a8f30d;
  }
  *pcVar16 = 'e';
  pcVar19 = pcVar16 + 1;
  piVar10 = (int *)*param_3;
  if (piVar10 == (int *)0x0) {
LAB_00a8f024:
    *param_3 = 0;
    *(undefined *)(param_3 + 1) = 1;
  }
  else {
    if (*(int *)piVar10[7] == 0) {
LAB_00a8f014:
      uVar11 = (**(code **)(*piVar10 + 0x1c))();
    }
    else {
      iVar7 = *(int *)piVar10[0xb];
      if (iVar7 < 1) goto LAB_00a8f014;
      *(int *)piVar10[0xb] = iVar7 + -1;
      pbVar1 = *(byte **)piVar10[7];
      *(byte **)piVar10[7] = pbVar1 + 1;
      uVar11 = (uint)*pbVar1;
    }
    if (uVar11 == 0xffffffff) goto LAB_00a8f024;
    *(undefined *)(param_3 + 1) = 0;
  }
  bVar6 = false;
  cVar3 = FUN_00a8d280(param_3,param_4);
  if (cVar3 == '\0') {
    cVar3 = *(char *)(param_3 + 1);
    if (cVar3 == '\0') {
      piVar10 = (int *)*param_3;
      if (piVar10 == (int *)0x0) {
LAB_00a8f079:
        *param_3 = 0;
      }
      else {
        if ((*(byte **)piVar10[7] == (byte *)0x0) || (*(int *)piVar10[0xb] < 1)) {
          uVar11 = (**(code **)(*piVar10 + 0x18))();
        }
        else {
          uVar11 = (uint)**(byte **)piVar10[7];
        }
        if (uVar11 == 0xffffffff) goto LAB_00a8f079;
        *(char *)((int)param_3 + 5) = (char)uVar11;
      }
      *(undefined *)(param_3 + 1) = 1;
      cVar3 = '\x01';
    }
    bVar4 = *(byte *)((int)param_3 + 5);
    if (bVar4 == bStack_41) {
      *pcVar19 = '+';
      pcVar19 = pcVar16 + 2;
      piVar10 = (int *)*param_3;
      if (piVar10 != (int *)0x0) {
        if (*(int *)piVar10[7] == 0) {
LAB_00a8f0b5:
          uVar11 = (**(code **)(*piVar10 + 0x1c))();
        }
        else {
          iVar7 = *(int *)piVar10[0xb];
          if (iVar7 < 1) goto LAB_00a8f0b5;
          *(int *)piVar10[0xb] = iVar7 + -1;
          pbVar1 = *(byte **)piVar10[7];
          *(byte **)piVar10[7] = pbVar1 + 1;
          uVar11 = (uint)*pbVar1;
        }
        if (uVar11 != 0xffffffff) {
          *(undefined *)(param_3 + 1) = 0;
          goto LAB_00a8f165;
        }
      }
      *param_3 = 0;
    }
    else {
      if (cVar3 == '\0') {
        piVar10 = (int *)*param_3;
        if (piVar10 == (int *)0x0) {
LAB_00a8f10b:
          *param_3 = 0;
          uVar11 = (uint)bVar4;
        }
        else {
          if ((*(byte **)piVar10[7] == (byte *)0x0) || (*(int *)piVar10[0xb] < 1)) {
            uVar11 = (**(code **)(*piVar10 + 0x18))();
            bVar4 = *(byte *)((int)param_3 + 5);
          }
          else {
            uVar11 = (uint)**(byte **)piVar10[7];
          }
          if (uVar11 == 0xffffffff) goto LAB_00a8f10b;
          *(char *)((int)param_3 + 5) = (char)uVar11;
        }
        bVar4 = (byte)uVar11;
        *(undefined *)(param_3 + 1) = 1;
      }
      if (bVar4 != bStack_42) goto LAB_00a8f165;
      *pcVar19 = '-';
      pcVar19 = pcVar16 + 2;
      piVar10 = (int *)*param_3;
      if (piVar10 != (int *)0x0) {
        if (*(int *)piVar10[7] == 0) {
LAB_00a8f14b:
          uVar11 = (**(code **)(*piVar10 + 0x1c))();
        }
        else {
          iVar7 = *(int *)piVar10[0xb];
          if (iVar7 < 1) goto LAB_00a8f14b;
          *(int *)piVar10[0xb] = iVar7 + -1;
          pbVar1 = *(byte **)piVar10[7];
          *(byte **)piVar10[7] = pbVar1 + 1;
          uVar11 = (uint)*pbVar1;
        }
        if (uVar11 != 0xffffffff) {
          *(undefined *)(param_3 + 1) = 0;
          goto LAB_00a8f165;
        }
      }
      *param_3 = 0;
    }
    pcVar19 = pcVar16 + 2;
    *(undefined *)(param_3 + 1) = 1;
  }
LAB_00a8f165:
  iVar7 = 0;
  cVar3 = FUN_00a8d280(param_3,param_4);
  if (cVar3 == '\0') {
    do {
      if (*(char *)(param_3 + 1) == '\0') {
        piVar10 = (int *)*param_3;
        if (piVar10 == (int *)0x0) {
LAB_00a8f1b1:
          *param_3 = 0;
        }
        else {
          if ((*(byte **)piVar10[7] == (byte *)0x0) || (*(int *)piVar10[0xb] < 1)) {
            uVar11 = (**(code **)(*piVar10 + 0x18))();
          }
          else {
            uVar11 = (uint)**(byte **)piVar10[7];
          }
          if (uVar11 == 0xffffffff) goto LAB_00a8f1b1;
          *(char *)((int)param_3 + 5) = (char)uVar11;
        }
        *(undefined *)(param_3 + 1) = 1;
      }
      if (*(char *)((int)param_3 + 5) != acStack_4c[0]) {
        if (!bVar6) goto LAB_00a8f22b;
        break;
      }
      piVar10 = (int *)*param_3;
      bVar6 = true;
      if (piVar10 == (int *)0x0) {
LAB_00a8f200:
        *param_3 = 0;
        *(undefined *)(param_3 + 1) = 1;
      }
      else {
        if (*(int *)piVar10[7] == 0) {
LAB_00a8f1f0:
          uVar11 = (**(code **)(*piVar10 + 0x1c))();
        }
        else {
          iVar18 = *(int *)piVar10[0xb];
          if (iVar18 < 1) goto LAB_00a8f1f0;
          *(int *)piVar10[0xb] = iVar18 + -1;
          pbVar1 = *(byte **)piVar10[7];
          *(byte **)piVar10[7] = pbVar1 + 1;
          uVar11 = (uint)*pbVar1;
        }
        if (uVar11 == 0xffffffff) goto LAB_00a8f200;
        *(undefined *)(param_3 + 1) = 0;
      }
      cVar3 = FUN_00a8d280(param_3,param_4);
    } while (cVar3 == '\0');
    *pcVar19 = '0';
    pcVar19 = pcVar19 + 1;
  }
LAB_00a8f22b:
  cVar3 = FUN_00a8d280(param_3,param_4);
  pcVar16 = pcVar19;
  while (cVar3 == '\0') {
    if (*(char *)(param_3 + 1) == '\0') {
      piVar10 = (int *)*param_3;
      if (piVar10 == (int *)0x0) {
LAB_00a8f271:
        *param_3 = 0;
      }
      else {
        if ((*(byte **)piVar10[7] == (byte *)0x0) || (*(int *)piVar10[0xb] < 1)) {
          uVar11 = (**(code **)(*piVar10 + 0x18))();
        }
        else {
          uVar11 = (uint)**(byte **)piVar10[7];
        }
        if (uVar11 == 0xffffffff) goto LAB_00a8f271;
        *(char *)((int)param_3 + 5) = (char)uVar11;
      }
      *(undefined *)(param_3 + 1) = 1;
    }
    puVar12 = (undefined *)FUN_0170db20(acStack_4c,*(undefined *)((int)param_3 + 5),0xe);
    puVar15 = auStack_3e;
    if (puVar12 != (undefined *)0x0) {
      puVar15 = puVar12;
    }
    if (9 < (uint)((int)puVar15 - (int)acStack_4c)) break;
    if (iVar7 < 8) {
      *pcVar16 = "0123456789-+Ee"[(int)puVar15 - (int)acStack_4c];
      pcVar16 = pcVar16 + 1;
      iVar7 = iVar7 + 1;
    }
    piVar10 = (int *)*param_3;
    bVar6 = true;
    if (piVar10 == (int *)0x0) {
LAB_00a8f2ec:
      *param_3 = 0;
      *(undefined *)(param_3 + 1) = 1;
    }
    else {
      if (*(int *)piVar10[7] == 0) {
LAB_00a8f2dc:
        uVar11 = (**(code **)(*piVar10 + 0x1c))();
      }
      else {
        iVar18 = *(int *)piVar10[0xb];
        if (iVar18 < 1) goto LAB_00a8f2dc;
        *(int *)piVar10[0xb] = iVar18 + -1;
        pbVar1 = *(byte **)piVar10[7];
        *(byte **)piVar10[7] = pbVar1 + 1;
        uVar11 = (uint)*pbVar1;
      }
      if (uVar11 == 0xffffffff) goto LAB_00a8f2ec;
      *(undefined *)(param_3 + 1) = 0;
    }
    cVar3 = FUN_00a8d280(param_3,param_4);
  }
LAB_00a8f30d:
  if ((cStack_12 != '\0') || (!bVar6)) {
    pcVar16 = param_2;
  }
  *pcVar16 = '\0';
  if (0xf < uStack_68) {
    uVar11 = uStack_68 + 1;
    ppppiVar14 = (int ****)apppiStack_7c[0];
    if (0xfff < uVar11) {
      ppppiVar14 = (int ****)apppiStack_7c[0][-1];
      uVar11 = uStack_68 + 0x24;
      if ((char *)0x1f < (char *)((int)apppiStack_7c[0] + (-4 - (int)ppppiVar14))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppiVar14,uVar11);
  }
  ExceptionList = pvStack_10;
  return iStack_18;
}



/* FUNCTION 21659 ; VA 0x00a8f370 ; FUN_00a8f370 */

undefined4
FUN_00a8f370(undefined4 param_1,char *param_2,int *param_3,undefined4 param_4,int param_5,
            int *param_6)

{
  byte *pbVar1;
  int iVar2;
  char cVar3;
  byte bVar4;
  char cVar5;
  bool bVar6;
  int *piVar7;
  undefined4 *puVar8;
  int *piVar9;
  uint uVar10;
  undefined4 uVar11;
  undefined *puVar12;
  char ****ppppcVar13;
  int ****ppppiVar14;
  undefined *puVar15;
  char *pcVar16;
  int iVar17;
  char *pcVar18;
  int iVar19;
  char acStack_84 [22];
  byte bStack_6e;
  byte bStack_6d;
  char cStack_6c;
  char cStack_6b;
  byte bStack_6a;
  byte bStack_69;
  undefined auStack_68 [4];
  int ***apppiStack_64 [4];
  int iStack_54;
  uint uStack_50;
  char ***apppcStack_4c [5];
  uint uStack_38;
  undefined auStack_34 [4];
  int ***pppiStack_30;
  int *piStack_2c;
  int iStack_28;
  int ***pppiStack_24;
  int iStack_20;
  char *pcStack_1c;
  int iStack_18;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5800;
  pvStack_10 = ExceptionList;
  piVar9 = *(int **)(*(int *)(param_5 + 0x30) + 4);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  pppiStack_30 = (int ***)piVar9;
  (**(code **)(*piVar9 + 4))();
  uStack_8 = 1;
  piVar7 = (int *)FUN_00564bf0(auStack_34);
  uStack_8 = 2;
  piStack_2c = piVar7;
  if ((piVar9 != (int *)0x0) &&
     (puVar8 = (undefined4 *)(**(code **)(*piVar9 + 8))(), puVar8 != (undefined4 *)0x0)) {
    (**(code **)*puVar8)(1);
  }
  uStack_8 = 0xffffffff;
  (**(code **)(*piVar7 + 0x14))(apppiStack_64);
  ppppiVar14 = *(int *****)(*(int *)(param_5 + 0x30) + 4);
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  pppiStack_30 = (int ***)ppppiVar14;
  (*(code *)(*ppppiVar14)[1])();
  uStack_8._0_1_ = 5;
  piVar9 = (int *)FUN_0054e7d0(auStack_34);
  uStack_8._0_1_ = 6;
  if ((ppppiVar14 != (int ****)0x0) &&
     (puVar8 = (undefined4 *)(*(code *)(*ppppiVar14)[2])(), puVar8 != (undefined4 *)0x0)) {
    (**(code **)*puVar8)(1);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  (**(code **)(*piVar9 + 0x1c))("0123456789ABCDEFabcdef-+XxPp",&DAT_01946ba1,acStack_84);
  cStack_12 = '\0';
  cVar3 = FUN_00a8d280(param_3,param_4);
  pcVar16 = param_2;
  if (cVar3 == '\0') {
    if (*(char *)(param_3 + 1) == '\0') {
      piVar9 = (int *)*param_3;
      if (piVar9 == (int *)0x0) {
LAB_00a8f4a1:
        *param_3 = 0;
      }
      else {
        if ((*(byte **)piVar9[7] == (byte *)0x0) || (*(int *)piVar9[0xb] < 1)) {
          uVar10 = (**(code **)(*piVar9 + 0x18))();
        }
        else {
          uVar10 = (uint)**(byte **)piVar9[7];
        }
        if (uVar10 == 0xffffffff) goto LAB_00a8f4a1;
        *(char *)((int)param_3 + 5) = (char)uVar10;
      }
      *(undefined *)(param_3 + 1) = 1;
    }
    if (*(byte *)((int)param_3 + 5) == bStack_6d) {
      *param_2 = '+';
    }
    else {
      bVar4 = FUN_00a8e710();
      if (bVar4 != bStack_6e) goto LAB_00a8f4d1;
      *param_2 = '-';
    }
    FUN_00a8e760();
    pcVar16 = param_2 + 1;
  }
LAB_00a8f4d1:
  pcVar16[0] = '0';
  pcVar16[1] = 'x';
  iVar19 = 0;
  pcVar16 = pcVar16 + 2;
  bVar6 = false;
  iStack_20 = 0;
  iStack_18 = 0;
  pcStack_1c = pcVar16;
  cVar3 = FUN_00a8d280(param_3,param_4);
  if (cVar3 == '\0') {
    if (*(char *)(param_3 + 1) == '\0') {
      piVar9 = (int *)*param_3;
      if (piVar9 == (int *)0x0) {
LAB_00a8f527:
        *param_3 = 0;
      }
      else {
        if ((*(byte **)piVar9[7] == (byte *)0x0) || (*(int *)piVar9[0xb] < 1)) {
          uVar10 = (**(code **)(*piVar9 + 0x18))();
        }
        else {
          uVar10 = (uint)**(byte **)piVar9[7];
        }
        if (uVar10 == 0xffffffff) goto LAB_00a8f527;
        *(char *)((int)param_3 + 5) = (char)uVar10;
      }
      *(undefined *)(param_3 + 1) = 1;
    }
    if (*(char *)((int)param_3 + 5) == acStack_84[0]) {
      uVar11 = FUN_00a8e760();
      cVar3 = FUN_00a8d280(uVar11,param_4);
      if ((cVar3 == '\0') &&
         ((cVar3 = FUN_00a8e710(), cVar3 == cStack_6b ||
          (cVar3 = FUN_00a8e710(), cVar3 == cStack_6c)))) {
        FUN_00a8e760();
      }
      else {
        bVar6 = true;
      }
    }
  }
  iStack_28 = 0x24;
  if (*param_6 == 1000000000) {
    iStack_28 = 0x300;
  }
  pppiStack_24 = (int ***)apppiStack_64;
  if (0xf < uStack_50) {
    pppiStack_24 = apppiStack_64[0];
  }
  if ((*(char *)pppiStack_24 == '\x7f') || (*(char *)pppiStack_24 < '\x01')) {
    cVar3 = FUN_00a8d280(param_3,param_4);
    if (cVar3 != '\0') goto LAB_00a8f7c5;
    do {
      if (*(char *)(param_3 + 1) == '\0') {
        piVar9 = (int *)*param_3;
        if (piVar9 == (int *)0x0) {
LAB_00a8f861:
          *param_3 = 0;
        }
        else {
          if ((*(byte **)piVar9[7] == (byte *)0x0) || (*(int *)piVar9[0xb] < 1)) {
            uVar10 = (**(code **)(*piVar9 + 0x18))();
          }
          else {
            uVar10 = (uint)**(byte **)piVar9[7];
          }
          if (uVar10 == 0xffffffff) goto LAB_00a8f861;
          *(char *)((int)param_3 + 5) = (char)uVar10;
        }
        *(undefined *)(param_3 + 1) = 1;
      }
      puVar12 = (undefined *)FUN_0170db20(acStack_84,*(undefined *)((int)param_3 + 5),0x1c);
      puVar15 = auStack_68;
      if (puVar12 != (undefined *)0x0) {
        puVar15 = puVar12;
      }
      uVar10 = (int)puVar15 - (int)acStack_84;
      if (0x15 < uVar10) goto LAB_00a8f7c5;
      if (iVar19 < iStack_28) {
        if ((uVar10 != 0) || (iVar19 != 0)) {
          *pcVar16 = "0123456789ABCDEFabcdef-+XxPp"[uVar10];
          pcVar16 = pcVar16 + 1;
          iVar19 = iVar19 + 1;
          pcStack_1c = pcVar16;
        }
      }
      else {
        iStack_18 = iStack_18 + 1;
      }
      piVar9 = (int *)*param_3;
      bVar6 = true;
      if (piVar9 == (int *)0x0) {
LAB_00a8f8f0:
        *param_3 = 0;
        *(undefined *)(param_3 + 1) = 1;
      }
      else {
        if (*(int *)piVar9[7] == 0) {
LAB_00a8f8e0:
          uVar10 = (**(code **)(*piVar9 + 0x1c))();
        }
        else {
          iVar17 = *(int *)piVar9[0xb];
          if (iVar17 < 1) goto LAB_00a8f8e0;
          *(int *)piVar9[0xb] = iVar17 + -1;
          pbVar1 = *(byte **)piVar9[7];
          *(byte **)piVar9[7] = pbVar1 + 1;
          uVar10 = (uint)*pbVar1;
        }
        if (uVar10 == 0xffffffff) goto LAB_00a8f8f0;
        *(undefined *)(param_3 + 1) = 0;
      }
      cVar3 = FUN_00a8d280(param_3,param_4);
    } while (cVar3 == '\0');
LAB_00a8f7cb:
    if (iVar19 == 0) {
      *pcVar16 = '0';
      pcVar16 = pcVar16 + 1;
      pcStack_1c = pcVar16;
    }
  }
  else {
    if (iStack_54 == 0) {
      cStack_11 = '\0';
    }
    else {
      cStack_11 = (**(code **)(*piStack_2c + 0x10))();
    }
    FUN_00565660(1,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    iVar19 = 0;
    cVar3 = FUN_00a8d280(param_3,param_4);
    if (cVar3 == '\0') {
      do {
        if (*(char *)(param_3 + 1) == '\0') {
          piVar9 = (int *)*param_3;
          if (piVar9 == (int *)0x0) {
LAB_00a8f619:
            *param_3 = 0;
          }
          else {
            if ((*(byte **)piVar9[7] == (byte *)0x0) || (*(int *)piVar9[0xb] < 1)) {
              uVar10 = (**(code **)(*piVar9 + 0x18))();
            }
            else {
              uVar10 = (uint)**(byte **)piVar9[7];
            }
            if (uVar10 == 0xffffffff) goto LAB_00a8f619;
            *(char *)((int)param_3 + 5) = (char)uVar10;
          }
          *(undefined *)(param_3 + 1) = 1;
        }
        puVar12 = (undefined *)FUN_0170db20(acStack_84,*(undefined *)((int)param_3 + 5),0x1c);
        puVar15 = auStack_68;
        if (puVar12 != (undefined *)0x0) {
          puVar15 = puVar12;
        }
        uVar10 = (int)puVar15 - (int)acStack_84;
        if (uVar10 < 0x16) {
          bVar6 = true;
          if (iStack_20 < iStack_28) {
            if ((uVar10 != 0) || (iStack_20 != 0)) {
              *pcVar16 = "0123456789ABCDEFabcdef-+XxPp"[uVar10];
              pcVar16 = pcVar16 + 1;
              iStack_20 = iStack_20 + 1;
            }
          }
          else {
            iStack_18 = iStack_18 + 1;
          }
          ppppcVar13 = apppcStack_4c;
          if (0xf < uStack_38) {
            ppppcVar13 = (char ****)apppcStack_4c[0];
          }
          if (*(char *)((int)ppppcVar13 + iVar19) != '\x7f') {
            ppppcVar13 = apppcStack_4c;
            if (0xf < uStack_38) {
              ppppcVar13 = (char ****)apppcStack_4c[0];
            }
            *(char *)((int)ppppcVar13 + iVar19) = *(char *)((int)ppppcVar13 + iVar19) + '\x01';
          }
        }
        else {
          ppppcVar13 = apppcStack_4c;
          if (0xf < uStack_38) {
            ppppcVar13 = (char ****)apppcStack_4c[0];
          }
          if (((*(char *)((int)ppppcVar13 + iVar19) == '\0') || (cStack_11 == '\0')) ||
             (cVar3 = FUN_00a8e710(), cVar3 != cStack_11)) break;
          FUN_005558a0(0);
          iVar19 = iVar19 + 1;
        }
        piVar9 = (int *)*param_3;
        if (piVar9 == (int *)0x0) {
LAB_00a8f6fc:
          *param_3 = 0;
          *(undefined *)(param_3 + 1) = 1;
        }
        else {
          if (*(int *)piVar9[7] == 0) {
LAB_00a8f6ec:
            uVar10 = (**(code **)(*piVar9 + 0x1c))();
          }
          else {
            iVar17 = *(int *)piVar9[0xb];
            if (iVar17 < 1) goto LAB_00a8f6ec;
            *(int *)piVar9[0xb] = iVar17 + -1;
            pbVar1 = *(byte **)piVar9[7];
            *(byte **)piVar9[7] = pbVar1 + 1;
            uVar10 = (uint)*pbVar1;
          }
          if (uVar10 == 0xffffffff) goto LAB_00a8f6fc;
          *(undefined *)(param_3 + 1) = 0;
        }
        cVar3 = FUN_00a8d280(param_3,param_4);
      } while (cVar3 == '\0');
      pcStack_1c = pcVar16;
      if (iVar19 == 0) goto LAB_00a8f740;
      ppppcVar13 = apppcStack_4c;
      if (0xf < uStack_38) {
        ppppcVar13 = (char ****)apppcStack_4c[0];
      }
      if ('\0' < *(char *)((int)ppppcVar13 + iVar19)) {
        iVar19 = iVar19 + 1;
        goto LAB_00a8f740;
      }
LAB_00a8f787:
      cStack_12 = '\x01';
    }
    else {
LAB_00a8f740:
      while ((pppiStack_30 = pppiStack_24, iVar19 != 0 &&
             (cVar3 = *(char *)pppiStack_24, cVar3 != '\x7f'))) {
        iVar19 = iVar19 + -1;
        if (iVar19 != 0) {
          ppppcVar13 = apppcStack_4c;
          if (0xf < uStack_38) {
            ppppcVar13 = (char ****)apppcStack_4c[0];
          }
          if (cVar3 != *(char *)((int)ppppcVar13 + iVar19)) goto LAB_00a8f787;
        }
        if (iVar19 == 0) {
          ppppcVar13 = apppcStack_4c;
          if (0xf < uStack_38) {
            ppppcVar13 = (char ****)apppcStack_4c[0];
          }
          if (cVar3 < *(char *)ppppcVar13) goto LAB_00a8f787;
        }
        ppppiVar14 = (int ****)((int)pppiStack_24 + 1);
        if (*(char *)((int)pppiStack_24 + 1) < '\x01') {
          ppppiVar14 = (int ****)pppiStack_24;
        }
        pppiStack_24 = (int ***)ppppiVar14;
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    iVar19 = iStack_20;
    if (0xf < uStack_38) {
      uVar10 = uStack_38 + 1;
      ppppcVar13 = (char ****)apppcStack_4c[0];
      if (0xfff < uVar10) {
        ppppcVar13 = (char ****)((char ****)apppcStack_4c[0])[-1];
        uVar10 = uStack_38 + 0x24;
        if ((char *)0x1f < (char *)((int)apppcStack_4c[0] + (-4 - (int)ppppcVar13))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppcVar13,uVar10);
      iVar19 = iStack_20;
    }
LAB_00a8f7c5:
    if (bVar6) goto LAB_00a8f7cb;
  }
  cVar3 = FUN_00a8d280(param_3,param_4);
  if (cVar3 == '\0') {
    if (*(char *)(param_3 + 1) == '\0') {
      piVar9 = (int *)*param_3;
      if (piVar9 == (int *)0x0) {
LAB_00a8f922:
        *param_3 = 0;
      }
      else {
        if ((*(byte **)piVar9[7] == (byte *)0x0) || (*(int *)piVar9[0xb] < 1)) {
          uVar10 = (**(code **)(*piVar9 + 0x18))();
        }
        else {
          uVar10 = (uint)**(byte **)piVar9[7];
        }
        if (uVar10 == 0xffffffff) goto LAB_00a8f922;
        *(char *)((int)param_3 + 5) = (char)uVar10;
      }
      *(undefined *)(param_3 + 1) = 1;
    }
    cVar3 = *(char *)((int)param_3 + 5);
    cVar5 = (**(code **)(*piStack_2c + 0xc))();
    pcVar16 = pcStack_1c;
    if (cVar3 == cVar5) {
      puVar8 = (undefined4 *)FUN_0171df30();
      *pcStack_1c = *(char *)*puVar8;
      pcVar16 = pcStack_1c + 1;
      piVar9 = (int *)*param_3;
      pcStack_1c = pcVar16;
      if (piVar9 != (int *)0x0) {
        if (*(int *)piVar9[7] == 0) {
LAB_00a8f978:
          uVar10 = (**(code **)(*piVar9 + 0x1c))();
        }
        else {
          iVar17 = *(int *)piVar9[0xb];
          if (iVar17 < 1) goto LAB_00a8f978;
          *(int *)piVar9[0xb] = iVar17 + -1;
          pbVar1 = *(byte **)piVar9[7];
          *(byte **)piVar9[7] = pbVar1 + 1;
          uVar10 = (uint)*pbVar1;
        }
        if (uVar10 != 0xffffffff) {
          *(undefined *)(param_3 + 1) = 0;
          goto LAB_00a8f997;
        }
      }
      *param_3 = 0;
      *(undefined *)(param_3 + 1) = 1;
    }
  }
LAB_00a8f997:
  if (iVar19 == 0) {
    cVar3 = FUN_00a8d280(param_3,param_4);
    iVar17 = iStack_18;
    while (cVar3 == '\0') {
      if (*(char *)(param_3 + 1) == '\0') {
        piVar9 = (int *)*param_3;
        if (piVar9 == (int *)0x0) {
LAB_00a8f9e7:
          *param_3 = 0;
        }
        else {
          if ((*(byte **)piVar9[7] == (byte *)0x0) || (*(int *)piVar9[0xb] < 1)) {
            uVar10 = (**(code **)(*piVar9 + 0x18))();
          }
          else {
            uVar10 = (uint)**(byte **)piVar9[7];
          }
          if (uVar10 == 0xffffffff) goto LAB_00a8f9e7;
          *(char *)((int)param_3 + 5) = (char)uVar10;
        }
        *(undefined *)(param_3 + 1) = 1;
      }
      pcVar16 = pcStack_1c;
      if (*(char *)((int)param_3 + 5) != acStack_84[0]) break;
      piVar9 = (int *)*param_3;
      iVar17 = iVar17 + -1;
      bVar6 = true;
      if (piVar9 == (int *)0x0) {
LAB_00a8fa37:
        *param_3 = 0;
        *(undefined *)(param_3 + 1) = 1;
      }
      else {
        if (*(int *)piVar9[7] == 0) {
LAB_00a8fa27:
          uVar10 = (**(code **)(*piVar9 + 0x1c))();
        }
        else {
          iVar2 = *(int *)piVar9[0xb];
          if (iVar2 < 1) goto LAB_00a8fa27;
          *(int *)piVar9[0xb] = iVar2 + -1;
          pbVar1 = *(byte **)piVar9[7];
          *(byte **)piVar9[7] = pbVar1 + 1;
          uVar10 = (uint)*pbVar1;
        }
        if (uVar10 == 0xffffffff) goto LAB_00a8fa37;
        *(undefined *)(param_3 + 1) = 0;
      }
      cVar3 = FUN_00a8d280(param_3,param_4);
      pcVar16 = pcStack_1c;
    }
    iStack_18 = iVar17;
    if (iVar17 < 0) {
      *pcVar16 = '0';
      pcVar16 = pcVar16 + 1;
      iStack_18 = iVar17 + 1;
    }
  }
  cVar3 = FUN_00a8d280(param_3,param_4);
  if (cVar3 == '\0') {
    do {
      if (*(char *)(param_3 + 1) == '\0') {
        piVar9 = (int *)*param_3;
        if (piVar9 == (int *)0x0) {
LAB_00a8fab1:
          *param_3 = 0;
        }
        else {
          if ((*(byte **)piVar9[7] == (byte *)0x0) || (*(int *)piVar9[0xb] < 1)) {
            uVar10 = (**(code **)(*piVar9 + 0x18))();
          }
          else {
            uVar10 = (uint)**(byte **)piVar9[7];
          }
          if (uVar10 == 0xffffffff) goto LAB_00a8fab1;
          *(char *)((int)param_3 + 5) = (char)uVar10;
        }
        *(undefined *)(param_3 + 1) = 1;
      }
      puVar12 = (undefined *)FUN_0170db20(acStack_84,*(undefined *)((int)param_3 + 5),0x1c);
      puVar15 = auStack_68;
      if (puVar12 != (undefined *)0x0) {
        puVar15 = puVar12;
      }
      if (0x15 < (uint)((int)puVar15 - (int)acStack_84)) goto LAB_00a8fb4c;
      if (iVar19 < iStack_28) {
        *pcVar16 = "0123456789ABCDEFabcdef-+XxPp"[(int)puVar15 - (int)acStack_84];
        pcVar16 = pcVar16 + 1;
        iVar19 = iVar19 + 1;
      }
      piVar9 = (int *)*param_3;
      bVar6 = true;
      if (piVar9 == (int *)0x0) {
LAB_00a8fb2c:
        *param_3 = 0;
        *(undefined *)(param_3 + 1) = 1;
      }
      else {
        if (*(int *)piVar9[7] == 0) {
LAB_00a8fb1c:
          uVar10 = (**(code **)(*piVar9 + 0x1c))();
        }
        else {
          iVar17 = *(int *)piVar9[0xb];
          if (iVar17 < 1) goto LAB_00a8fb1c;
          *(int *)piVar9[0xb] = iVar17 + -1;
          pbVar1 = *(byte **)piVar9[7];
          *(byte **)piVar9[7] = pbVar1 + 1;
          uVar10 = (uint)*pbVar1;
        }
        if (uVar10 == 0xffffffff) goto LAB_00a8fb2c;
        *(undefined *)(param_3 + 1) = 0;
      }
      cVar3 = FUN_00a8d280(param_3,param_4);
    } while (cVar3 == '\0');
  }
  else {
LAB_00a8fb4c:
    if (!bVar6) goto LAB_00a8ff1f;
  }
  cVar3 = FUN_00a8d280(param_3,param_4);
  if (cVar3 != '\0') goto LAB_00a8ff1f;
  cVar3 = *(char *)(param_3 + 1);
  if (cVar3 == '\0') {
    piVar9 = (int *)*param_3;
    if (piVar9 == (int *)0x0) {
LAB_00a8fb9d:
      *param_3 = 0;
    }
    else {
      if ((*(byte **)piVar9[7] == (byte *)0x0) || (*(int *)piVar9[0xb] < 1)) {
        uVar10 = (**(code **)(*piVar9 + 0x18))();
      }
      else {
        uVar10 = (uint)**(byte **)piVar9[7];
      }
      if (uVar10 == 0xffffffff) goto LAB_00a8fb9d;
      *(char *)((int)param_3 + 5) = (char)uVar10;
    }
    *(undefined *)(param_3 + 1) = 1;
    cVar3 = '\x01';
  }
  bVar4 = *(byte *)((int)param_3 + 5);
  if (bVar4 != bStack_69) {
    if (cVar3 == '\0') {
      piVar9 = (int *)*param_3;
      if (piVar9 == (int *)0x0) {
LAB_00a8fbed:
        *param_3 = 0;
        uVar10 = (uint)bVar4;
      }
      else {
        if ((*(byte **)piVar9[7] == (byte *)0x0) || (*(int *)piVar9[0xb] < 1)) {
          uVar10 = (**(code **)(*piVar9 + 0x18))();
          bVar4 = *(byte *)((int)param_3 + 5);
        }
        else {
          uVar10 = (uint)**(byte **)piVar9[7];
        }
        if (uVar10 == 0xffffffff) goto LAB_00a8fbed;
        *(char *)((int)param_3 + 5) = (char)uVar10;
      }
      bVar4 = (byte)uVar10;
      *(undefined *)(param_3 + 1) = 1;
    }
    if (bVar4 != bStack_6a) goto LAB_00a8ff1f;
  }
  *pcVar16 = 'p';
  pcVar18 = pcVar16 + 1;
  piVar9 = (int *)*param_3;
  if (piVar9 == (int *)0x0) {
LAB_00a8fc3f:
    *param_3 = 0;
    *(undefined *)(param_3 + 1) = 1;
  }
  else {
    if (*(int *)piVar9[7] == 0) {
LAB_00a8fc2f:
      uVar10 = (**(code **)(*piVar9 + 0x1c))();
    }
    else {
      iVar19 = *(int *)piVar9[0xb];
      if (iVar19 < 1) goto LAB_00a8fc2f;
      *(int *)piVar9[0xb] = iVar19 + -1;
      pbVar1 = *(byte **)piVar9[7];
      *(byte **)piVar9[7] = pbVar1 + 1;
      uVar10 = (uint)*pbVar1;
    }
    if (uVar10 == 0xffffffff) goto LAB_00a8fc3f;
    *(undefined *)(param_3 + 1) = 0;
  }
  bVar6 = false;
  cVar3 = FUN_00a8d280(param_3,param_4);
  if (cVar3 == '\0') {
    cVar3 = *(char *)(param_3 + 1);
    if (cVar3 == '\0') {
      piVar9 = (int *)*param_3;
      if (piVar9 == (int *)0x0) {
LAB_00a8fc94:
        *param_3 = 0;
      }
      else {
        if ((*(byte **)piVar9[7] == (byte *)0x0) || (*(int *)piVar9[0xb] < 1)) {
          uVar10 = (**(code **)(*piVar9 + 0x18))();
        }
        else {
          uVar10 = (uint)**(byte **)piVar9[7];
        }
        if (uVar10 == 0xffffffff) goto LAB_00a8fc94;
        *(char *)((int)param_3 + 5) = (char)uVar10;
      }
      *(undefined *)(param_3 + 1) = 1;
      cVar3 = '\x01';
    }
    bVar4 = *(byte *)((int)param_3 + 5);
    if (bVar4 == bStack_6d) {
      *pcVar18 = '+';
      pcVar18 = pcVar16 + 2;
      piVar9 = (int *)*param_3;
      if (piVar9 != (int *)0x0) {
        if (*(int *)piVar9[7] == 0) {
LAB_00a8fcd0:
          uVar10 = (**(code **)(*piVar9 + 0x1c))();
        }
        else {
          iVar19 = *(int *)piVar9[0xb];
          if (iVar19 < 1) goto LAB_00a8fcd0;
          *(int *)piVar9[0xb] = iVar19 + -1;
          pbVar1 = *(byte **)piVar9[7];
          *(byte **)piVar9[7] = pbVar1 + 1;
          uVar10 = (uint)*pbVar1;
        }
        if (uVar10 != 0xffffffff) {
          *(undefined *)(param_3 + 1) = 0;
          goto LAB_00a8fd80;
        }
      }
      *param_3 = 0;
    }
    else {
      if (cVar3 == '\0') {
        piVar9 = (int *)*param_3;
        if (piVar9 == (int *)0x0) {
LAB_00a8fd26:
          *param_3 = 0;
          uVar10 = (uint)bVar4;
        }
        else {
          if ((*(byte **)piVar9[7] == (byte *)0x0) || (*(int *)piVar9[0xb] < 1)) {
            uVar10 = (**(code **)(*piVar9 + 0x18))();
            bVar4 = *(byte *)((int)param_3 + 5);
          }
          else {
            uVar10 = (uint)**(byte **)piVar9[7];
          }
          if (uVar10 == 0xffffffff) goto LAB_00a8fd26;
          *(char *)((int)param_3 + 5) = (char)uVar10;
        }
        bVar4 = (byte)uVar10;
        *(undefined *)(param_3 + 1) = 1;
      }
      if (bVar4 != bStack_6e) goto LAB_00a8fd80;
      *pcVar18 = '-';
      pcVar18 = pcVar16 + 2;
      piVar9 = (int *)*param_3;
      if (piVar9 != (int *)0x0) {
        if (*(int *)piVar9[7] == 0) {
LAB_00a8fd66:
          uVar10 = (**(code **)(*piVar9 + 0x1c))();
        }
        else {
          iVar19 = *(int *)piVar9[0xb];
          if (iVar19 < 1) goto LAB_00a8fd66;
          *(int *)piVar9[0xb] = iVar19 + -1;
          pbVar1 = *(byte **)piVar9[7];
          *(byte **)piVar9[7] = pbVar1 + 1;
          uVar10 = (uint)*pbVar1;
        }
        if (uVar10 != 0xffffffff) {
          *(undefined *)(param_3 + 1) = 0;
          goto LAB_00a8fd80;
        }
      }
      *param_3 = 0;
    }
    pcVar18 = pcVar16 + 2;
    *(undefined *)(param_3 + 1) = 1;
  }
LAB_00a8fd80:
  iVar19 = 0;
  cVar3 = FUN_00a8d280(param_3,param_4);
  if (cVar3 == '\0') {
    do {
      if (*(char *)(param_3 + 1) == '\0') {
        piVar9 = (int *)*param_3;
        if (piVar9 == (int *)0x0) {
LAB_00a8fdc5:
          *param_3 = 0;
        }
        else {
          if ((*(byte **)piVar9[7] == (byte *)0x0) || (*(int *)piVar9[0xb] < 1)) {
            uVar10 = (**(code **)(*piVar9 + 0x18))();
          }
          else {
            uVar10 = (uint)**(byte **)piVar9[7];
          }
          if (uVar10 == 0xffffffff) goto LAB_00a8fdc5;
          *(char *)((int)param_3 + 5) = (char)uVar10;
        }
        *(undefined *)(param_3 + 1) = 1;
      }
      if (*(char *)((int)param_3 + 5) != acStack_84[0]) {
        if (!bVar6) goto LAB_00a8fe3e;
        break;
      }
      piVar9 = (int *)*param_3;
      bVar6 = true;
      if (piVar9 == (int *)0x0) {
LAB_00a8fe14:
        *param_3 = 0;
        *(undefined *)(param_3 + 1) = 1;
      }
      else {
        if (*(int *)piVar9[7] == 0) {
LAB_00a8fe04:
          uVar10 = (**(code **)(*piVar9 + 0x1c))();
        }
        else {
          iVar17 = *(int *)piVar9[0xb];
          if (iVar17 < 1) goto LAB_00a8fe04;
          *(int *)piVar9[0xb] = iVar17 + -1;
          pbVar1 = *(byte **)piVar9[7];
          *(byte **)piVar9[7] = pbVar1 + 1;
          uVar10 = (uint)*pbVar1;
        }
        if (uVar10 == 0xffffffff) goto LAB_00a8fe14;
        *(undefined *)(param_3 + 1) = 0;
      }
      cVar3 = FUN_00a8d280(param_3,param_4);
    } while (cVar3 == '\0');
    *pcVar18 = '0';
    pcVar18 = pcVar18 + 1;
  }
LAB_00a8fe3e:
  cVar3 = FUN_00a8d280(param_3,param_4);
  pcVar16 = pcVar18;
  while (cVar3 == '\0') {
    if (*(char *)(param_3 + 1) == '\0') {
      piVar9 = (int *)*param_3;
      if (piVar9 == (int *)0x0) {
LAB_00a8fe83:
        *param_3 = 0;
      }
      else {
        if ((*(byte **)piVar9[7] == (byte *)0x0) || (*(int *)piVar9[0xb] < 1)) {
          uVar10 = (**(code **)(*piVar9 + 0x18))();
        }
        else {
          uVar10 = (uint)**(byte **)piVar9[7];
        }
        if (uVar10 == 0xffffffff) goto LAB_00a8fe83;
        *(char *)((int)param_3 + 5) = (char)uVar10;
      }
      *(undefined *)(param_3 + 1) = 1;
    }
    puVar12 = (undefined *)FUN_0170db20(acStack_84,*(undefined *)((int)param_3 + 5),0x1c);
    puVar15 = auStack_68;
    if (puVar12 != (undefined *)0x0) {
      puVar15 = puVar12;
    }
    if (0x15 < (uint)((int)puVar15 - (int)acStack_84)) break;
    if (iVar19 < 8) {
      *pcVar16 = "0123456789ABCDEFabcdef-+XxPp"[(int)puVar15 - (int)acStack_84];
      pcVar16 = pcVar16 + 1;
      iVar19 = iVar19 + 1;
    }
    piVar9 = (int *)*param_3;
    bVar6 = true;
    if (piVar9 == (int *)0x0) {
LAB_00a8fefe:
      *param_3 = 0;
      *(undefined *)(param_3 + 1) = 1;
    }
    else {
      if (*(int *)piVar9[7] == 0) {
LAB_00a8feee:
        uVar10 = (**(code **)(*piVar9 + 0x1c))();
      }
      else {
        iVar17 = *(int *)piVar9[0xb];
        if (iVar17 < 1) goto LAB_00a8feee;
        *(int *)piVar9[0xb] = iVar17 + -1;
        pbVar1 = *(byte **)piVar9[7];
        *(byte **)piVar9[7] = pbVar1 + 1;
        uVar10 = (uint)*pbVar1;
      }
      if (uVar10 == 0xffffffff) goto LAB_00a8fefe;
      *(undefined *)(param_3 + 1) = 0;
    }
    cVar3 = FUN_00a8d280(param_3,param_4);
  }
LAB_00a8ff1f:
  if ((cStack_12 != '\0') || (!bVar6)) {
    pcVar16 = param_2;
  }
  *pcVar16 = '\0';
  *param_6 = iStack_18;
  if (0xf < uStack_50) {
    uVar10 = uStack_50 + 1;
    ppppiVar14 = (int ****)apppiStack_64[0];
    if (0xfff < uVar10) {
      ppppiVar14 = (int ****)apppiStack_64[0][-1];
      uVar10 = uStack_50 + 0x24;
      if ((char *)0x1f < (char *)((int)apppiStack_64[0] + (-4 - (int)ppppiVar14))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppiVar14,uVar10);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 21660 ; VA 0x00a8ff90 ; FUN_00a8ff90 */

byte FUN_00a8ff90(undefined4 param_1,char *param_2,int *param_3,undefined4 param_4,uint param_5,
                 undefined4 param_6)

{
  int iVar1;
  byte *pbVar2;
  char cVar3;
  char cVar4;
  byte bVar5;
  int *piVar6;
  uint uVar7;
  undefined *puVar8;
  char ****ppppcVar9;
  undefined *puVar10;
  byte bVar11;
  int iVar12;
  char acStack_6c [22];
  char cStack_56;
  char cStack_55;
  char cStack_54;
  char cStack_53;
  undefined auStack_52 [2];
  char ***apppcStack_50 [4];
  int iStack_40;
  uint uStack_3c;
  char ***apppcStack_38 [5];
  uint uStack_24;
  char ***pppcStack_20;
  uint uStack_1c;
  char *pcStack_18;
  char cStack_14;
  byte bStack_13;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5820;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar6 = (int *)FUN_00564bf0(param_6);
  (**(code **)(*piVar6 + 0x14))(apppcStack_50);
  uStack_8 = 0;
  if (iStack_40 == 0) {
    bStack_13 = 0;
  }
  else {
    bStack_13 = (**(code **)(*piVar6 + 0x10))();
  }
  piVar6 = (int *)FUN_0054e7d0(param_6);
  (**(code **)(*piVar6 + 0x1c))("0123456789ABCDEFabcdef-+Xx",&DAT_01946b83,acStack_6c);
  pcStack_18 = param_2;
  cVar3 = FUN_00a8d280(param_3,param_4);
  if (cVar3 == '\0') {
    if (*(char *)(param_3 + 1) == '\0') {
      piVar6 = (int *)*param_3;
      if (piVar6 == (int *)0x0) {
LAB_00a90052:
        *param_3 = 0;
      }
      else {
        if ((*(byte **)piVar6[7] == (byte *)0x0) || (*(int *)piVar6[0xb] < 1)) {
          uVar7 = (**(code **)(*piVar6 + 0x18))();
        }
        else {
          uVar7 = (uint)**(byte **)piVar6[7];
        }
        if (uVar7 == 0xffffffff) goto LAB_00a90052;
        *(char *)((int)param_3 + 5) = (char)uVar7;
      }
      *(undefined *)(param_3 + 1) = 1;
    }
    if (*(char *)((int)param_3 + 5) == cStack_55) {
      *param_2 = '+';
    }
    else {
      cVar3 = FUN_00a8e710();
      if (cVar3 != cStack_56) goto LAB_00a90085;
      *param_2 = '-';
    }
    pcStack_18 = param_2 + 1;
    FUN_00a8e760();
  }
LAB_00a90085:
  param_5 = param_5 & 0xe00;
  if (param_5 == 0x400) {
    bVar11 = 8;
  }
  else if (param_5 == 0x800) {
    bVar11 = 0x10;
  }
  else {
    bVar11 = -(param_5 != 0) & 10;
  }
  cStack_11 = '\0';
  uStack_1c = uStack_1c & 0xffffff00;
  cStack_14 = '\0';
  cVar3 = FUN_00a8d280(param_3,param_4);
  if (cVar3 == '\0') {
    if (*(char *)(param_3 + 1) == '\0') {
      piVar6 = (int *)*param_3;
      if (piVar6 == (int *)0x0) {
LAB_00a90103:
        *param_3 = 0;
      }
      else {
        if ((*(byte **)piVar6[7] == (byte *)0x0) || (*(int *)piVar6[0xb] < 1)) {
          uVar7 = (**(code **)(*piVar6 + 0x18))();
        }
        else {
          uVar7 = (uint)**(byte **)piVar6[7];
        }
        if (uVar7 == 0xffffffff) goto LAB_00a90103;
        *(char *)((int)param_3 + 5) = (char)uVar7;
      }
      *(undefined *)(param_3 + 1) = 1;
    }
    if (*(char *)((int)param_3 + 5) != acStack_6c[0]) goto LAB_00a9017a;
    cStack_11 = '\x01';
    uStack_1c = CONCAT31(uStack_1c._1_3_,1);
    FUN_00a8e760();
    cVar3 = FUN_00a8d280(param_3,param_4);
    if (((cVar3 != '\0') ||
        ((cVar3 = FUN_00a8e710(), cVar3 != cStack_53 && (cVar3 = FUN_00a8e710(), cVar3 != cStack_54)
         ))) || ((bVar11 != 0 && (bVar11 != 0x10)))) {
      if (bVar11 == 0) {
        bVar11 = 8;
        goto LAB_00a90183;
      }
      goto LAB_00a9017e;
    }
    bVar11 = 0x10;
    cStack_11 = '\0';
    uStack_1c = uStack_1c & 0xffffff00;
    FUN_00a8e760();
LAB_00a90183:
    pppcStack_20 = (char ***)0x16;
    if (bVar11 == 8) {
      pppcStack_20 = (char ***)&DAT_00000008;
    }
  }
  else {
LAB_00a9017a:
    if (bVar11 != 0) {
LAB_00a9017e:
      if (bVar11 != 10) goto LAB_00a90183;
    }
    pppcStack_20 = (char ***)&DAT_0000000a;
  }
  FUN_00565660(1,uStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar12 = 0;
  cVar4 = FUN_00a8d280(param_3,param_4);
  cVar3 = cStack_11;
  if (cVar4 == '\0') {
    do {
      cStack_12 = *(char *)(param_3 + 1);
      if (cStack_12 == '\0') {
        piVar6 = (int *)*param_3;
        if (piVar6 == (int *)0x0) {
LAB_00a901fa:
          *param_3 = 0;
        }
        else {
          if ((*(byte **)piVar6[7] == (byte *)0x0) || (*(int *)piVar6[0xb] < 1)) {
            uVar7 = (**(code **)(*piVar6 + 0x18))();
          }
          else {
            uVar7 = (uint)**(byte **)piVar6[7];
          }
          if (uVar7 == 0xffffffff) goto LAB_00a901fa;
          *(char *)((int)param_3 + 5) = (char)uVar7;
        }
        *(undefined *)(param_3 + 1) = 1;
        cStack_12 = '\x01';
      }
      bVar5 = *(byte *)((int)param_3 + 5);
      puVar8 = (undefined *)FUN_0170db20(acStack_6c,bVar5,0x1a);
      puVar10 = auStack_52;
      if (puVar8 != (undefined *)0x0) {
        puVar10 = puVar8;
      }
      if (puVar10 + -(int)acStack_6c < pppcStack_20) {
        cVar3 = *(char *)((int)(puVar10 + -(int)acStack_6c) + 0x1946b68);
        *pcStack_18 = cVar3;
        if (((cStack_14 != '\0') || (cVar3 != '0')) && (pcStack_18 < param_2 + 0x1f)) {
          cStack_14 = '\x01';
          pcStack_18 = pcStack_18 + 1;
        }
        cStack_11 = '\x01';
        ppppcVar9 = apppcStack_38;
        if (0xf < uStack_24) {
          ppppcVar9 = (char ****)apppcStack_38[0];
        }
        if (*(char *)((int)ppppcVar9 + iVar12) != '\x7f') {
          ppppcVar9 = apppcStack_38;
          if (0xf < uStack_24) {
            ppppcVar9 = (char ****)apppcStack_38[0];
          }
          *(char *)((int)ppppcVar9 + iVar12) = *(char *)((int)ppppcVar9 + iVar12) + '\x01';
        }
      }
      else {
        ppppcVar9 = apppcStack_38;
        if (0xf < uStack_24) {
          ppppcVar9 = (char ****)apppcStack_38[0];
        }
        if ((*(char *)((int)ppppcVar9 + iVar12) == '\0') || (bStack_13 == 0)) break;
        if (cStack_12 == '\0') {
          piVar6 = (int *)*param_3;
          if (piVar6 == (int *)0x0) {
LAB_00a902de:
            *param_3 = 0;
            uVar7 = (uint)bVar5;
          }
          else {
            if ((*(byte **)piVar6[7] == (byte *)0x0) || (*(int *)piVar6[0xb] < 1)) {
              uVar7 = (**(code **)(*piVar6 + 0x18))();
              bVar5 = *(byte *)((int)param_3 + 5);
            }
            else {
              uVar7 = (uint)**(byte **)piVar6[7];
            }
            if (uVar7 == 0xffffffff) goto LAB_00a902de;
            *(char *)((int)param_3 + 5) = (char)uVar7;
          }
          bVar5 = (byte)uVar7;
          *(undefined *)(param_3 + 1) = 1;
        }
        if (bVar5 != bStack_13) break;
        FUN_005558a0(0);
        iVar12 = iVar12 + 1;
      }
      piVar6 = (int *)*param_3;
      if (piVar6 == (int *)0x0) {
LAB_00a90333:
        *param_3 = 0;
        *(undefined *)(param_3 + 1) = 1;
      }
      else {
        if (*(int *)piVar6[7] == 0) {
LAB_00a90323:
          uVar7 = (**(code **)(*piVar6 + 0x1c))();
        }
        else {
          iVar1 = *(int *)piVar6[0xb];
          if (iVar1 < 1) goto LAB_00a90323;
          *(int *)piVar6[0xb] = iVar1 + -1;
          pbVar2 = *(byte **)piVar6[7];
          *(byte **)piVar6[7] = pbVar2 + 1;
          uVar7 = (uint)*pbVar2;
        }
        if (uVar7 == 0xffffffff) goto LAB_00a90333;
        *(undefined *)(param_3 + 1) = 0;
      }
      cVar3 = FUN_00a8d280(param_3,param_4);
    } while (cVar3 == '\0');
    cVar3 = cStack_11;
    if (iVar12 != 0) {
      ppppcVar9 = apppcStack_38;
      if (0xf < uStack_24) {
        ppppcVar9 = (char ****)apppcStack_38[0];
      }
      if (*(char *)((int)ppppcVar9 + iVar12) < '\x01') {
        cVar3 = '\0';
      }
      else {
        iVar12 = iVar12 + 1;
      }
    }
  }
  ppppcVar9 = apppcStack_50;
  if (0xf < uStack_3c) {
    ppppcVar9 = (char ****)apppcStack_50[0];
  }
  if (cVar3 != '\0') {
    while ((pppcStack_20 = (char ***)ppppcVar9, iVar12 != 0 &&
           (cVar3 = *(char *)pppcStack_20, cVar3 != '\x7f'))) {
      iVar12 = iVar12 + -1;
      if (iVar12 != 0) {
        ppppcVar9 = apppcStack_38;
        if (0xf < uStack_24) {
          ppppcVar9 = (char ****)apppcStack_38[0];
        }
        if (cVar3 != *(char *)((int)ppppcVar9 + iVar12)) goto LAB_00a903e9;
      }
      if (iVar12 == 0) {
        ppppcVar9 = apppcStack_38;
        if (0xf < uStack_24) {
          ppppcVar9 = (char ****)apppcStack_38[0];
        }
        if (cVar3 < *(char *)ppppcVar9) goto LAB_00a903e9;
      }
      ppppcVar9 = (char ****)((int)pppcStack_20 + 1);
      if (*(char *)((int)pppcStack_20 + 1) < '\x01') {
        ppppcVar9 = (char ****)pppcStack_20;
      }
    }
    param_2 = pcStack_18;
    if (cStack_14 == '\0') {
      *pcStack_18 = '0';
      param_2 = pcStack_18 + 1;
    }
  }
LAB_00a903e9:
  *param_2 = '\0';
  if (0xf < uStack_24) {
    uVar7 = uStack_24 + 1;
    ppppcVar9 = (char ****)apppcStack_38[0];
    if (0xfff < uVar7) {
      ppppcVar9 = (char ****)((char ****)apppcStack_38[0])[-1];
      uVar7 = uStack_24 + 0x24;
      if ((char *)0x1f < (char *)((int)apppcStack_38[0] + (-4 - (int)ppppcVar9))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppcVar9,uVar7);
  }
  if (0xf < uStack_3c) {
    uVar7 = uStack_3c + 1;
    ppppcVar9 = (char ****)apppcStack_50[0];
    if (0xfff < uVar7) {
      ppppcVar9 = (char ****)((char ****)apppcStack_50[0])[-1];
      uVar7 = uStack_3c + 0x24;
      if ((char *)0x1f < (char *)((int)apppcStack_50[0] + (-4 - (int)ppppcVar9))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppcVar9,uVar7);
  }
  ExceptionList = pvStack_10;
  return bVar11;
}



/* FUNCTION 21661 ; VA 0x00a90470 ; FUN_00a90470 */

void __fastcall FUN_00a90470(int *param_1)

{
  int *piVar1;
  int iVar2;
  byte *pbVar3;
  uint uVar4;
  
  piVar1 = (int *)*param_1;
  if (piVar1 == (int *)0x0) goto LAB_00a904ad;
  if (*(int *)piVar1[7] == 0) {
LAB_00a9049c:
    uVar4 = (**(code **)(*piVar1 + 0x1c))();
  }
  else {
    iVar2 = *(int *)piVar1[0xb];
    if (iVar2 < 1) goto LAB_00a9049c;
    *(int *)piVar1[0xb] = iVar2 + -1;
    pbVar3 = *(byte **)piVar1[7];
    *(byte **)piVar1[7] = pbVar3 + 1;
    uVar4 = (uint)*pbVar3;
  }
  if (uVar4 != 0xffffffff) {
    *(undefined *)(param_1 + 1) = 0;
    return;
  }
LAB_00a904ad:
  *param_1 = 0;
  *(undefined *)(param_1 + 1) = 1;
  return;
}



/* FUNCTION 21662 ; VA 0x00a904c0 ; FUN_00a904c0 */

uint __fastcall FUN_00a904c0(int *param_1)

{
  int *piVar1;
  uint uVar2;
  
  piVar1 = (int *)*param_1;
  if (piVar1 != (int *)0x0) {
    if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
      uVar2 = (**(code **)(*piVar1 + 0x18))();
    }
    else {
      uVar2 = (uint)**(byte **)piVar1[7];
    }
    if (uVar2 != 0xffffffff) {
      *(char *)((int)param_1 + 5) = (char)uVar2;
      *(undefined *)(param_1 + 1) = 1;
      return uVar2;
    }
  }
  *param_1 = 0;
  *(undefined *)(param_1 + 1) = 1;
  return (uint)*(byte *)((int)param_1 + 5);
}



/* FUNCTION 21663 ; VA 0x00a90510 ; FUN_00a90510 */

float10 FUN_00a90510(undefined4 param_1,undefined4 param_2,int param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  float10 fVar3;
  double dVar4;
  
  puVar2 = (undefined4 *)FUN_0171689d();
  uVar1 = *puVar2;
  *puVar2 = 0;
  fVar3 = (float10)FUN_0172167a(param_1,param_2);
  *param_4 = *puVar2;
  *puVar2 = uVar1;
  if (param_3 != 0) {
    dVar4 = DAT_018d8a10;
    FUN_01726ab0();
    fVar3 = (float10)(dVar4 * (double)fVar3);
  }
  return fVar3;
}



/* FUNCTION 21664 ; VA 0x00a90580 ; FUN_00a90580 */

float10 FUN_00a90580(undefined4 param_1,undefined4 param_2,int param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  float10 fVar3;
  double dVar4;
  undefined4 uStack_8;
  
  puVar2 = (undefined4 *)FUN_0171689d();
  uVar1 = *puVar2;
  *puVar2 = 0;
  fVar3 = (float10)FUN_01721691(param_1,param_2);
  uStack_8 = (float)fVar3;
  *param_4 = *puVar2;
  *puVar2 = uVar1;
  if (param_3 != 0) {
    dVar4 = DAT_018d8a10;
    FUN_01726ab0();
    uStack_8 = (float)dVar4 * uStack_8;
  }
  return (float10)uStack_8;
}



/* FUNCTION 21665 ; VA 0x00a905f0 ; FUN_00a905f0 */

undefined4 FUN_00a905f0(undefined4 param_1,undefined4 param_2)

{
  FUN_00a91cc0(param_1,param_2);
  return param_1;
}



/* FUNCTION 21666 ; VA 0x00a90610 ; FUN_00a90610 */

/* WARNING: Type propagation algorithm not settling */

undefined4 FUN_00a90610(undefined4 param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined **appuStack_ac [15];
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_60;
  undefined **appuStack_5c [18];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e585f;
  pvStack_10 = ExceptionList;
  appuStack_ac[0] = &PTR_018be314;
  uStack_8 = 0;
  uStack_14 = 2;
  appuStack_5c[0] = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_60 = 0x48;
  ExceptionList = &pvStack_10;
  FUN_00554f20(appuStack_ac + 1,0);
  uStack_8 = 2;
  *(undefined ***)(appuStack_ac[0][1] + (int)appuStack_ac) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(appuStack_ac[0][1] + (int)&stack0xffffff50) = appuStack_ac[0][1] + -0x50;
  FUN_0054ee60();
  appuStack_ac[1] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  uStack_70 = 0;
  uStack_6c = 4;
  uStack_8 = 3;
  uVar1 = FUN_00a8e3b0(*param_2,&DAT_018c0cc8);
  FUN_00558890(uVar1);
  uVar1 = FUN_00a8e3b0(param_2[1],&DAT_018c0cc8);
  FUN_00558890(uVar1);
  uVar1 = FUN_00a8e3b0(param_2[2],&DAT_018c0cc8);
  FUN_00558890(uVar1);
  uVar1 = FUN_00a8e3b0(param_2[3],&DAT_018c0cc8);
  FUN_00558890(uVar1);
  uVar1 = FUN_00a8e3b0(param_2[4],&DAT_018c0cc8);
  FUN_00558890(uVar1);
  FUN_0058c400(param_1);
  *(undefined ***)(appuStack_ac[0][1] + (int)appuStack_ac) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(appuStack_ac[0][1] + (int)&stack0xffffff50) = appuStack_ac[0][1] + -0x50;
  FUN_0056b950();
  *(undefined ***)(appuStack_ac[0][1] + (int)appuStack_ac) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)(appuStack_ac[0][1] + (int)&stack0xffffff50) = appuStack_ac[0][1] + -8;
  uStack_8 = 4;
  appuStack_5c[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_5c);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21667 ; VA 0x00a90800 ; FUN_00a90800 */

undefined4 FUN_00a90800(int param_1)

{
  undefined4 uVar1;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5878;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x10) == 0) {
    return 0;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a91730(auStack_1c,param_1);
  uStack_8 = 0;
  FUN_00613d00(uVar1);
  FUN_00617bc0();
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 21668 ; VA 0x00a90870 ; FUN_00a90870 */

void __thiscall
FUN_00a90870(undefined4 param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,char *param_7,uint *param_8,short *param_9)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  char cVar4;
  undefined4 *puVar5;
  uint uVar6;
  char *pcVar7;
  char cStack_38;
  char acStack_37 [31];
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar2 = (int)param_7;
  puStack_c = &LAB_017922c8;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(*(int *)((int)param_7 + 0x30) + 4);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_14 = piVar1;
  (**(code **)(*piVar1 + 4))();
  uStack_8 = 1;
  param_7 = (char *)FUN_00a8ff90(param_1,&cStack_38,&param_3,&param_5,*(undefined4 *)(iVar2 + 0x14),
                                 auStack_18);
  uStack_8 = 2;
  if ((piVar1 != (int *)0x0) &&
     (puVar5 = (undefined4 *)(**(code **)(*piVar1 + 8))(), puVar5 != (undefined4 *)0x0)) {
    (**(code **)*puVar5)(1);
  }
  puVar3 = param_8;
  uStack_8 = 0xffffffff;
  if (cStack_38 == '\0') {
    *param_8 = 2;
    *param_9 = 0;
  }
  else {
    pcVar7 = acStack_37;
    if (cStack_38 != '-') {
      pcVar7 = &cStack_38;
    }
    uVar6 = FUN_016e0293(pcVar7,&param_7,param_7,&param_8);
    *param_9 = (short)uVar6;
    if (((param_7 == pcVar7) || (param_8 != (uint *)0x0)) || (0xffff < uVar6)) {
      *puVar3 = 2;
      *param_9 = -1;
    }
    else if (cStack_38 == '-') {
      *param_9 = -(short)uVar6;
    }
  }
  cVar4 = FUN_00a8d280(&param_3,&param_5);
  if (cVar4 != '\0') {
    *puVar3 = *puVar3 | 1;
  }
  *param_2 = param_3;
  param_2[1] = param_4;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21669 ; VA 0x00a909b0 ; FUN_00a909b0 */

void __thiscall
FUN_00a909b0(undefined4 param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,char *param_7,uint *param_8,undefined4 *param_9)

{
  int *piVar1;
  char *pcVar2;
  uint *puVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  char acStack_48 [32];
  undefined auStack_28 [4];
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pcVar2 = param_7;
  puStack_c = &LAB_017e5898;
  pvStack_10 = ExceptionList;
  uStack_20 = param_5;
  uStack_1c = param_6;
  uStack_18 = param_3;
  uStack_14 = param_4;
  piVar1 = *(int **)(*(int *)(param_7 + 0x30) + 4);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_24 = piVar1;
  (**(code **)(*piVar1 + 4))();
  uStack_8 = 1;
  uVar5 = FUN_00a8ff90(param_1,acStack_48,&uStack_18,&uStack_20,*(undefined4 *)(pcVar2 + 0x14),
                       auStack_28);
  uStack_8 = 2;
  if (piVar1 != (int *)0x0) {
    puVar6 = (undefined4 *)(**(code **)(*piVar1 + 8))();
    if (puVar6 != (undefined4 *)0x0) {
      (**(code **)*puVar6)(1);
    }
  }
  puVar3 = param_8;
  uStack_8 = 0xffffffff;
  if (acStack_48[0] == '\0') {
    uVar5 = 0;
  }
  else {
    uVar5 = FUN_016e0293(acStack_48,&param_7,uVar5,&param_8);
    if ((param_7 != acStack_48) && (param_8 == (uint *)0x0)) goto LAB_00a90a86;
  }
  *puVar3 = 2;
LAB_00a90a86:
  cVar4 = FUN_00a8d280(&uStack_18,&uStack_20);
  if (cVar4 != '\0') {
    *puVar3 = *puVar3 | 1;
  }
  *param_9 = uVar5;
  *param_2 = uStack_18;
  param_2[1] = uStack_14;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21670 ; VA 0x00a90ad0 ; FUN_00a90ad0 */

void __thiscall
FUN_00a90ad0(undefined4 param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,char *param_7,uint *param_8,undefined4 *param_9)

{
  int *piVar1;
  char *pcVar2;
  uint *puVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  char acStack_38 [32];
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pcVar2 = param_7;
  puStack_c = &LAB_017922c8;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(*(int *)(param_7 + 0x30) + 4);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_14 = piVar1;
  (**(code **)(*piVar1 + 4))();
  uStack_8 = 1;
  uVar5 = FUN_00a8ff90(param_1,acStack_38,&param_3,&param_5,*(undefined4 *)(pcVar2 + 0x14),
                       auStack_18);
  uStack_8 = 2;
  if (piVar1 != (int *)0x0) {
    puVar6 = (undefined4 *)(**(code **)(*piVar1 + 8))();
    if (puVar6 != (undefined4 *)0x0) {
      (**(code **)*puVar6)(1);
    }
  }
  puVar3 = param_8;
  uStack_8 = 0xffffffff;
  if (acStack_38[0] == '\0') {
    *param_8 = 2;
    *param_9 = 0;
  }
  else {
    uVar5 = FUN_016e01ee(acStack_38,&param_7,uVar5,&param_8);
    *param_9 = uVar5;
    if ((param_7 == acStack_38) || (param_8 != (uint *)0x0)) {
      *puVar3 = 2;
    }
  }
  cVar4 = FUN_00a8d280(&param_3,&param_5);
  if (cVar4 != '\0') {
    *puVar3 = *puVar3 | 1;
  }
  *param_2 = param_3;
  param_2[1] = param_4;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21671 ; VA 0x00a90be0 ; FUN_00a90be0 */

void __thiscall
FUN_00a90be0(undefined4 param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,char *param_7,uint *param_8,undefined4 *param_9)

{
  int *piVar1;
  char *pcVar2;
  uint *puVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  char acStack_38 [32];
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pcVar2 = param_7;
  puStack_c = &LAB_017922c8;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(*(int *)(param_7 + 0x30) + 4);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_14 = piVar1;
  (**(code **)(*piVar1 + 4))();
  uStack_8 = 1;
  uVar5 = FUN_00a8ff90(param_1,acStack_38,&param_3,&param_5,*(undefined4 *)(pcVar2 + 0x14),
                       auStack_18);
  uStack_8 = 2;
  if (piVar1 != (int *)0x0) {
    puVar6 = (undefined4 *)(**(code **)(*piVar1 + 8))();
    if (puVar6 != (undefined4 *)0x0) {
      (**(code **)*puVar6)(1);
    }
  }
  puVar3 = param_8;
  uStack_8 = 0xffffffff;
  if (acStack_38[0] == '\0') {
    *param_8 = 2;
    *param_9 = 0;
  }
  else {
    uVar5 = FUN_016e0293(acStack_38,&param_7,uVar5,&param_8);
    *param_9 = uVar5;
    if ((param_7 == acStack_38) || (param_8 != (uint *)0x0)) {
      *puVar3 = 2;
    }
  }
  cVar4 = FUN_00a8d280(&param_3,&param_5);
  if (cVar4 != '\0') {
    *puVar3 = *puVar3 | 1;
  }
  *param_2 = param_3;
  param_2[1] = param_4;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21672 ; VA 0x00a90cf0 ; FUN_00a90cf0 */

void __thiscall
FUN_00a90cf0(undefined4 param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,float param_7,uint *param_8,float *param_9)

{
  undefined4 uVar1;
  uint *puVar2;
  float *pfVar3;
  char cVar4;
  undefined4 *puVar5;
  float10 fVar6;
  float fVar7;
  double dVar8;
  char acStack_328 [792];
  char *pcStack_10;
  int iStack_c;
  int iStack_8;
  
  iStack_8 = 1000000000;
  iStack_c = FUN_00a8e7b0(param_1,acStack_328,&param_3,&param_5,param_7,&iStack_8);
  puVar2 = param_8;
  if (acStack_328[0] != '\0') {
    puVar5 = (undefined4 *)FUN_0171689d();
    uVar1 = *puVar5;
    *puVar5 = 0;
    fVar6 = (float10)FUN_01721691(acStack_328,&pcStack_10);
    param_8 = (uint *)*puVar5;
    *puVar5 = uVar1;
    fVar7 = (float)fVar6;
    param_7 = fVar7;
    if (iStack_c != 0) {
      dVar8 = DAT_018d8a10;
      FUN_01726ab0();
      fVar7 = (float)dVar8 * param_7;
    }
    pfVar3 = param_9;
    *param_9 = fVar7;
    if ((pcStack_10 != acStack_328) && (param_8 == (uint *)0x0)) {
      if ((iStack_8 != 1000000000) && (iStack_8 != 0)) {
        fVar6 = (float10)FUN_017277f1((double)fVar7,iStack_8 << 2);
        *pfVar3 = (float)fVar6;
      }
      goto LAB_00a90de2;
    }
  }
  *puVar2 = 2;
  *param_9 = 0.0;
LAB_00a90de2:
  cVar4 = FUN_00a8d280();
  if (cVar4 != '\0') {
    *puVar2 = *puVar2 | 1;
  }
  *param_2 = param_3;
  param_2[1] = param_4;
  return;
}



/* FUNCTION 21673 ; VA 0x00a90e10 ; FUN_00a90e10 */

void __thiscall
FUN_00a90e10(undefined4 param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,int param_7,uint *param_8,double *param_9)

{
  undefined4 uVar1;
  uint *puVar2;
  double *pdVar3;
  char cVar4;
  undefined4 *puVar5;
  float10 fVar6;
  double dVar7;
  char acStack_32c [792];
  double dStack_14;
  char *pcStack_c;
  int iStack_8;
  
  iStack_8 = 1000000000;
  param_7 = FUN_00a8e7b0(param_1,acStack_32c,&param_3,&param_5,param_7,&iStack_8);
  puVar2 = param_8;
  if (acStack_32c[0] != '\0') {
    puVar5 = (undefined4 *)FUN_0171689d();
    uVar1 = *puVar5;
    *puVar5 = 0;
    fVar6 = (float10)FUN_0172167a(acStack_32c,&pcStack_c);
    param_8 = (uint *)*puVar5;
    *puVar5 = uVar1;
    dVar7 = (double)fVar6;
    dStack_14 = dVar7;
    if (param_7 != 0) {
      dVar7 = DAT_018d8a10;
      FUN_01726ab0();
      dVar7 = dVar7 * dStack_14;
    }
    pdVar3 = param_9;
    *param_9 = dVar7;
    if ((pcStack_c != acStack_32c) && (param_8 == (uint *)0x0)) {
      if ((iStack_8 != 1000000000) && (iStack_8 != 0)) {
        fVar6 = (float10)FUN_017277f1(dVar7,iStack_8 << 2);
        *pdVar3 = (double)fVar6;
      }
      goto LAB_00a90ef9;
    }
  }
  *puVar2 = 2;
  *param_9 = 0.0;
LAB_00a90ef9:
  cVar4 = FUN_00a8d280();
  if (cVar4 != '\0') {
    *puVar2 = *puVar2 | 1;
  }
  *param_2 = param_3;
  param_2[1] = param_4;
  return;
}



/* FUNCTION 21674 ; VA 0x00a90f30 ; FUN_00a90f30 */

void __thiscall
FUN_00a90f30(undefined4 param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,uint *param_8,double *param_9)

{
  int iVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  float10 fVar6;
  double dVar7;
  char acStack_33c [792];
  undefined4 uStack_24;
  undefined4 uStack_20;
  char *pcStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  int iStack_10;
  double dStack_c;
  
  uStack_24 = param_5;
  uStack_20 = param_6;
  uStack_18 = param_3;
  uStack_14 = param_4;
  iStack_10 = 1000000000;
  iVar4 = FUN_00a8e7b0(param_1,acStack_33c,&uStack_18,&uStack_24,param_7,&iStack_10);
  if (acStack_33c[0] != '\0') {
    piVar5 = (int *)FUN_0171689d();
    iVar1 = *piVar5;
    *piVar5 = 0;
    fVar6 = (float10)FUN_0172167a(acStack_33c,&pcStack_1c);
    iVar2 = *piVar5;
    *piVar5 = iVar1;
    dStack_c = (double)fVar6;
    if (iVar4 != 0) {
      dVar7 = DAT_018d8a10;
      FUN_01726ab0();
      dStack_c = dVar7 * dStack_c;
    }
    if ((pcStack_1c != acStack_33c) && (iVar2 == 0)) {
      if ((iStack_10 != 1000000000) && (iStack_10 != 0)) {
        fVar6 = (float10)FUN_017277f1(dStack_c,iStack_10 << 2);
        dStack_c = (double)fVar6;
      }
      goto LAB_00a91034;
    }
  }
  dStack_c = 0.0;
  *param_8 = 2;
LAB_00a91034:
  cVar3 = FUN_00a8d280();
  if (cVar3 != '\0') {
    *param_8 = *param_8 | 1;
  }
  *param_9 = dStack_c;
  *param_2 = uStack_18;
  param_2[1] = uStack_14;
  return;
}



/* FUNCTION 21675 ; VA 0x00a91070 ; FUN_00a91070 */

void __thiscall
FUN_00a91070(undefined4 param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,char *param_7,uint *param_8,undefined4 *param_9)

{
  int *piVar1;
  uint *puVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  char acStack_38 [32];
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017922c8;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(*(int *)(param_7 + 0x30) + 4);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_14 = piVar1;
  (**(code **)(*piVar1 + 4))();
  uStack_8 = 1;
  uVar4 = FUN_00a8ff90(param_1,acStack_38,&param_3,&param_5,0x800,auStack_18);
  uStack_8 = 2;
  if (piVar1 != (int *)0x0) {
    puVar5 = (undefined4 *)(**(code **)(*piVar1 + 8))();
    if (puVar5 != (undefined4 *)0x0) {
      (**(code **)*puVar5)(1);
    }
  }
  puVar2 = param_8;
  uStack_8 = 0xffffffff;
  if (acStack_38[0] == '\0') {
    *param_8 = 2;
    *param_9 = 0;
  }
  else {
    uVar4 = FUN_016e0293(acStack_38,&param_7,uVar4,&param_8);
    *param_9 = uVar4;
    if ((param_7 == acStack_38) || (param_8 != (uint *)0x0)) {
      *puVar2 = 2;
      *param_9 = 0;
    }
  }
  cVar3 = FUN_00a8d280(&param_3,&param_5);
  if (cVar3 != '\0') {
    *puVar2 = *puVar2 | 1;
  }
  *param_2 = param_3;
  param_2[1] = param_4;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21676 ; VA 0x00a91180 ; FUN_00a91180 */

void __thiscall
FUN_00a91180(undefined4 param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,char *param_7,uint *param_8,undefined8 *param_9)

{
  int *piVar1;
  char *pcVar2;
  uint *puVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined8 uVar7;
  char acStack_38 [32];
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pcVar2 = param_7;
  puStack_c = &LAB_017922c8;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(*(int *)(param_7 + 0x30) + 4);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_14 = piVar1;
  (**(code **)(*piVar1 + 4))();
  uStack_8 = 1;
  uVar5 = FUN_00a8ff90(param_1,acStack_38,&param_3,&param_5,*(undefined4 *)(pcVar2 + 0x14),
                       auStack_18);
  uStack_8 = 2;
  if (piVar1 != (int *)0x0) {
    puVar6 = (undefined4 *)(**(code **)(*piVar1 + 8))();
    if (puVar6 != (undefined4 *)0x0) {
      (**(code **)*puVar6)(1);
    }
  }
  puVar3 = param_8;
  uStack_8 = 0xffffffff;
  if (acStack_38[0] == '\0') {
    *param_8 = 2;
    *(undefined4 *)param_9 = 0;
    *(undefined4 *)((int)param_9 + 4) = 0;
  }
  else {
    uVar7 = FUN_016e0406(acStack_38,&param_7,uVar5,&param_8);
    *param_9 = uVar7;
    if ((param_7 == acStack_38) || (param_8 != (uint *)0x0)) {
      *puVar3 = 2;
    }
  }
  cVar4 = FUN_00a8d280(&param_3,&param_5);
  if (cVar4 != '\0') {
    *puVar3 = *puVar3 | 1;
  }
  *param_2 = param_3;
  param_2[1] = param_4;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21677 ; VA 0x00a91290 ; FUN_00a91290 */

void __thiscall
FUN_00a91290(undefined4 param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,char *param_7,uint *param_8,undefined8 *param_9)

{
  int *piVar1;
  char *pcVar2;
  uint *puVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined8 uVar7;
  char acStack_38 [32];
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pcVar2 = param_7;
  puStack_c = &LAB_017922c8;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(*(int *)(param_7 + 0x30) + 4);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_14 = piVar1;
  (**(code **)(*piVar1 + 4))();
  uStack_8 = 1;
  uVar5 = FUN_00a8ff90(param_1,acStack_38,&param_3,&param_5,*(undefined4 *)(pcVar2 + 0x14),
                       auStack_18);
  uStack_8 = 2;
  if (piVar1 != (int *)0x0) {
    puVar6 = (undefined4 *)(**(code **)(*piVar1 + 8))();
    if (puVar6 != (undefined4 *)0x0) {
      (**(code **)*puVar6)(1);
    }
  }
  puVar3 = param_8;
  uStack_8 = 0xffffffff;
  if (acStack_38[0] == '\0') {
    *param_8 = 2;
    *(undefined4 *)param_9 = 0;
    *(undefined4 *)((int)param_9 + 4) = 0;
  }
  else {
    uVar7 = FUN_016e04d4(acStack_38,&param_7,uVar5,&param_8);
    *param_9 = uVar7;
    if ((param_7 == acStack_38) || (param_8 != (uint *)0x0)) {
      *puVar3 = 2;
    }
  }
  cVar4 = FUN_00a8d280(&param_3,&param_5);
  if (cVar4 != '\0') {
    *puVar3 = *puVar3 | 1;
  }
  *param_2 = param_3;
  param_2[1] = param_4;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21678 ; VA 0x00a913a0 ; FUN_00a913a0 */

void FUN_00a913a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,char *param_6,uint *param_7,undefined *param_8)

{
  int *piVar1;
  char *pcVar2;
  uint *puVar3;
  undefined uVar4;
  char cVar5;
  int *piVar6;
  undefined4 *puVar7;
  undefined4 ****ppppuVar8;
  int iVar9;
  undefined4 uVar10;
  uint uVar11;
  char acStack_70 [32];
  undefined4 ***apppuStack_50 [5];
  uint uStack_3c;
  undefined4 ***apppuStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar3 = param_7;
  pcVar2 = param_6;
  puStack_c = &LAB_017e58d8;
  pvStack_10 = ExceptionList;
  if ((*(uint *)(param_6 + 0x14) & 0x4000) == 0) {
    piVar1 = *(int **)(*(int *)(param_6 + 0x30) + 4);
    uStack_8 = 6;
    ExceptionList = &pvStack_10;
    piStack_1c = piVar1;
    (**(code **)(*piVar1 + 4))();
    uStack_8 = 7;
    uVar10 = FUN_00a8ff90(piStack_14,acStack_70,&param_2,&param_4,*(undefined4 *)(pcVar2 + 0x14),
                          auStack_20);
    uStack_8 = 8;
    if ((piVar1 != (int *)0x0) &&
       (puVar7 = (undefined4 *)(**(code **)(*piVar1 + 8))(), puVar7 != (undefined4 *)0x0)) {
      (**(code **)*puVar7)(1);
    }
    uStack_8 = 0xffffffff;
    if (acStack_70[0] == '\0') {
      *param_8 = 0;
    }
    else {
      iVar9 = FUN_016e01ee(acStack_70,&param_6,uVar10,&param_7);
      if ((param_6 == acStack_70) || (param_7 != (uint *)0x0)) {
        *param_8 = 1;
      }
      else {
        *param_8 = iVar9 != 0;
        if ((iVar9 == 0) || (iVar9 == 1)) goto LAB_00a9163b;
      }
    }
    *puVar3 = 2;
  }
  else {
    piVar1 = *(int **)(*(int *)(param_6 + 0x30) + 4);
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    piStack_14 = piVar1;
    (**(code **)(*piVar1 + 4))();
    uStack_8 = 1;
    piVar6 = (int *)FUN_00564bf0(auStack_18);
    uStack_8 = 2;
    if ((piVar1 != (int *)0x0) &&
       (puVar7 = (undefined4 *)(**(code **)(*piVar1 + 8))(), puVar7 != (undefined4 *)0x0)) {
      (**(code **)*puVar7)(1);
    }
    uStack_8 = 0xffffffff;
    FUN_00565660(1,0);
    uStack_8 = 3;
    (**(code **)(*piVar6 + 0x18))(apppuStack_38);
    ppppuVar8 = apppuStack_38;
    if (0xf < uStack_24) {
      ppppuVar8 = (undefined4 ****)apppuStack_38[0];
    }
    uStack_8._0_1_ = 4;
    FUN_00554150(ppppuVar8,uStack_28);
    uStack_8._0_1_ = 3;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (0xf < uStack_24) {
      uVar11 = uStack_24 + 1;
      ppppuVar8 = (undefined4 ****)apppuStack_38[0];
      if (0xfff < uVar11) {
        ppppuVar8 = (undefined4 ****)apppuStack_38[0][-1];
        uVar11 = uStack_24 + 0x24;
        if (0x1f < (uint)((int)apppuStack_38[0] + (-4 - (int)ppppuVar8))) {
          uStack_8._0_1_ = uVar4;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar8,uVar11);
    }
    FUN_005558a0(0);
    (**(code **)(*piVar6 + 0x1c))(apppuStack_38);
    ppppuVar8 = apppuStack_38;
    if (0xf < uStack_24) {
      ppppuVar8 = (undefined4 ****)apppuStack_38[0];
    }
    uStack_8._0_1_ = 5;
    FUN_00554150(ppppuVar8,uStack_28);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (0xf < uStack_24) {
      uVar11 = uStack_24 + 1;
      ppppuVar8 = (undefined4 ****)apppuStack_38[0];
      if (0xfff < uVar11) {
        ppppuVar8 = (undefined4 ****)apppuStack_38[0][-1];
        uVar11 = uStack_24 + 0x24;
        if (0x1f < (uint)((int)apppuStack_38[0] + (-4 - (int)ppppuVar8))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar8,uVar11);
    }
    ppppuVar8 = apppuStack_50;
    if (0xf < uStack_3c) {
      ppppuVar8 = (undefined4 ****)apppuStack_50[0];
    }
    iVar9 = FUN_00a8d5a0(&param_2,&param_4,2,ppppuVar8);
    if (iVar9 == 0) {
      *param_8 = 0;
    }
    else if (iVar9 == 1) {
      *param_8 = 1;
    }
    else {
      *param_8 = 0;
      *puVar3 = 2;
    }
    uStack_8 = 0xffffffff;
    if (0xf < uStack_3c) {
      uVar11 = uStack_3c + 1;
      ppppuVar8 = (undefined4 ****)apppuStack_50[0];
      if (0xfff < uVar11) {
        ppppuVar8 = (undefined4 ****)apppuStack_50[0][-1];
        uVar11 = uStack_3c + 0x24;
        if (0x1f < (uint)((int)apppuStack_50[0] + (-4 - (int)ppppuVar8))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar8,uVar11);
    }
  }
LAB_00a9163b:
  cVar5 = FUN_00a8d280(&param_2,&param_4);
  if (cVar5 != '\0') {
    *puVar3 = *puVar3 | 1;
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21679 ; VA 0x00a91690 ; FUN_00a91690 */

int __thiscall FUN_00a91690(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint3 uVar4;
  
  if (*(char *)(param_1 + 1) == '\0') {
    piVar1 = (int *)*param_1;
    if (piVar1 == (int *)0x0) {
LAB_00a916cb:
      *param_1 = 0;
    }
    else {
      if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
        uVar3 = (**(code **)(*piVar1 + 0x18))();
      }
      else {
        uVar3 = (uint)**(byte **)piVar1[7];
      }
      if (uVar3 == 0xffffffff) goto LAB_00a916cb;
      *(char *)((int)param_1 + 5) = (char)uVar3;
    }
    *(undefined *)(param_1 + 1) = 1;
  }
  if (*(char *)(param_2 + 1) == '\0') {
    piVar1 = (int *)*param_2;
    if (piVar1 == (int *)0x0) {
LAB_00a91706:
      *param_2 = 0;
    }
    else {
      if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
        uVar3 = (**(code **)(*piVar1 + 0x18))();
      }
      else {
        uVar3 = (uint)**(byte **)piVar1[7];
      }
      if (uVar3 == 0xffffffff) goto LAB_00a91706;
      *(char *)((int)param_2 + 5) = (char)uVar3;
    }
    *(undefined *)(param_2 + 1) = 1;
  }
  iVar2 = *param_2;
  uVar4 = (uint3)((uint)iVar2 >> 8);
  if (*param_1 == 0) {
    if (iVar2 == 0) {
LAB_00a91727:
      return CONCAT31(uVar4,1);
    }
  }
  else if (iVar2 != 0) goto LAB_00a91727;
  return (uint)uVar4 << 8;
}



/* FUNCTION 21680 ; VA 0x00a91730 ; FUN_00a91730 */

undefined4 * FUN_00a91730(undefined4 *param_1,undefined4 param_2)

{
  byte bVar1;
  undefined4 uVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int aiStack_d8 [3];
  byte abStack_cc [84];
  undefined **appuStack_78 [18];
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e590b;
  pvStack_10 = ExceptionList;
  puVar4 = (undefined4 *)0x0;
  uStack_30 = 0;
  puVar5 = (undefined4 *)0x0;
  puStack_2c = (undefined4 *)0x0;
  puStack_28 = (undefined4 *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00565000(param_2,1,1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_14 = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00a8d320(&uStack_24);
  FUN_00a8d320(&uStack_20);
  FUN_00a8d320(&uStack_1c);
  FUN_00a8d320(&uStack_18);
  FUN_00a8d320(&uStack_14);
  bVar1 = abStack_cc[*(int *)(aiStack_d8[0] + 4)];
  while ((bVar1 & 1) == 0) {
    if (puVar5 == puVar4) {
      FUN_00a1baf0();
      puVar5 = puStack_28;
    }
    else {
      *puVar4 = uStack_24;
      puVar4[1] = uStack_20;
      puVar4[2] = uStack_1c;
      puVar4[3] = uStack_18;
      puVar4[4] = uStack_14;
      puStack_2c = puVar4 + 5;
    }
    puVar4 = puStack_2c;
    uStack_14 = 0;
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_1c = 0;
    uStack_18 = 0;
    FUN_00a8d320(&uStack_24);
    FUN_00a8d320();
    FUN_00a8d320(&uStack_1c);
    FUN_00a8d320(&uStack_18);
    FUN_00a8d320(&uStack_14);
    bVar1 = abStack_cc[*(int *)(aiStack_d8[0] + 4)];
  }
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar3 = FUN_00a91f00();
  if (cVar3 == '\0') {
    uStack_14 = 0x3f800000;
    puVar4 = (undefined4 *)FUN_00a8e2b0(CONCAT44(DAT_018ce2f8,DAT_018ce2f8),0x3f800000);
    if (puVar4 != param_1) {
      uVar2 = *puVar4;
      *puVar4 = *param_1;
      *param_1 = uVar2;
      uVar2 = puVar4[1];
      puVar4[1] = param_1[1];
      param_1[1] = uVar2;
      uVar2 = puVar4[2];
      puVar4[2] = param_1[2];
      param_1[2] = uVar2;
    }
    FUN_00617bc0();
  }
  else {
    FUN_00613d00(&uStack_30);
    *(undefined4 *)*param_1 = 0;
    *(undefined4 *)(param_1[1] + -0x14) = 0x3f800000;
  }
  *(undefined ***)((int)aiStack_d8 + *(int *)(aiStack_d8[0] + 4)) =
       std::basic_istringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(int *)(abStack_cc + *(int *)(aiStack_d8[0] + 4) + -0x10) = *(int *)(aiStack_d8[0] + 4) + -0x60;
  FUN_0056b950();
  *(undefined ***)((int)aiStack_d8 + *(int *)(aiStack_d8[0] + 4)) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(abStack_cc + *(int *)(aiStack_d8[0] + 4) + -0x10) = *(int *)(aiStack_d8[0] + 4) + -0x18;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  appuStack_78[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_78);
  FUN_00617bc0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21681 ; VA 0x00a91990 ; FUN_00a91990 */

int __thiscall FUN_00a91990(int param_1,undefined4 param_2)

{
  int iStack_10;
  int iStack_c;
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&iStack_10,param_2);
  FUN_00617bc0();
  return ((iStack_c - iStack_10) / 0x14) * 0x14;
}



/* FUNCTION 21682 ; VA 0x00a919e0 ; FUN_00a919e0 */

undefined4 __thiscall FUN_00a919e0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5878;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_1c,param_3);
  uStack_8 = 0;
  FUN_00a91cc0(param_2,auStack_1c);
  FUN_00617bc0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21683 ; VA 0x00a91a40 ; FUN_00a91a40 */

void __thiscall FUN_00a91a40(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5930;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0087d060(auStack_34);
  uVar1 = FUN_00a91730(auStack_1c,auStack_34);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,uVar1);
  FUN_00617bc0();
  if (0xf < uStack_20) {
    uVar3 = uStack_20 + 1;
    uVar2 = auStack_34[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_34[0] - 4);
      uVar3 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21684 ; VA 0x00a91b00 ; FUN_00a91b00 */

void __thiscall
FUN_00a91b00(int *param_1,undefined8 *param_2,undefined8 *param_3,undefined8 *param_4)

{
  int iVar1;
  undefined8 *puVar2;
  float *pfVar3;
  int iVar4;
  int iVar5;
  float fVar6;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  fStack_8 = 0.0;
  iVar4 = 0;
  fStack_c = DAT_018ce2f8 / ((float)(int)param_4 - DAT_018ce2f8) - DAT_018fe498;
  puVar2 = (undefined8 *)FUN_0115e8f0(*param_1 + 4);
  *param_3 = *puVar2;
  *(undefined4 *)(param_3 + 1) = *(undefined4 *)(puVar2 + 1);
  *param_2 = *puVar2;
  *(undefined4 *)(param_2 + 1) = *(undefined4 *)(puVar2 + 1);
  if (1 < (int)param_4) {
    iVar5 = (int)param_2 - (int)param_3;
    puVar2 = (undefined8 *)((int)param_3 + 0xc);
    param_3 = (undefined8 *)((int)param_4 + -1);
    param_4 = puVar2;
    do {
      fStack_8 = fStack_c + fStack_8;
      iVar1 = *param_1;
      pfVar3 = (float *)(iVar1 + (iVar4 + 1) * 0x14);
      if (*pfVar3 <= fStack_8 && fStack_8 != *pfVar3) {
        do {
          pfVar3 = pfVar3 + 5;
          iVar4 = iVar4 + 1;
        } while (*pfVar3 <= fStack_8 && fStack_8 != *pfVar3);
      }
      fStack_14 = *(float *)(iVar1 + 8 + iVar4 * 0x14);
      fStack_10 = *(float *)(iVar1 + 0xc + iVar4 * 0x14);
      fVar6 = (fStack_8 - *(float *)(iVar1 + iVar4 * 0x14)) /
              (*(float *)(iVar1 + 0x14 + iVar4 * 0x14) - *(float *)(iVar1 + iVar4 * 0x14));
      fStack_14 = (*(float *)(iVar1 + 0x1c + iVar4 * 0x14) - fStack_14) * fVar6 + fStack_14;
      fStack_10 = (*(float *)(iVar1 + 0x20 + iVar4 * 0x14) - fStack_10) * fVar6 + fStack_10;
      fStack_18 = (*(float *)(iVar1 + 0x18 + iVar4 * 0x14) - *(float *)(iVar1 + 4 + iVar4 * 0x14)) *
                  fVar6 + *(float *)(iVar1 + 4 + iVar4 * 0x14);
      puVar2 = (undefined8 *)FUN_0115e8f0(&fStack_18);
      *(undefined8 *)(iVar5 + (int)param_4) = *puVar2;
      *(undefined4 *)(iVar5 + 8 + (int)param_4) = *(undefined4 *)(puVar2 + 1);
      *param_4 = *puVar2;
      *(undefined4 *)(param_4 + 1) = *(undefined4 *)(puVar2 + 1);
      param_4 = (undefined8 *)((int)param_4 + 0xc);
      param_3 = (undefined8 *)((int)param_3 + -1);
    } while (param_3 != (undefined8 *)0x0);
  }
  return;
}



/* FUNCTION 21685 ; VA 0x00a91c60 ; FUN_00a91c60 */

undefined4 __thiscall FUN_00a91c60(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5878;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00a91730(auStack_1c,param_3);
  uStack_8 = 0;
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,auStack_1c);
  FUN_00617bc0();
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 21686 ; VA 0x00a91cc0 ; FUN_00a91cc0 */

/* WARNING: Type propagation algorithm not settling */

undefined4 FUN_00a91cc0(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  undefined **appuStack_ac [15];
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_60;
  undefined **appuStack_5c [18];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e585f;
  pvStack_10 = ExceptionList;
  appuStack_ac[0] = &PTR_018be314;
  uStack_8 = 0;
  uStack_14 = 2;
  appuStack_5c[0] = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_60 = 0x48;
  ExceptionList = &pvStack_10;
  FUN_00554f20(appuStack_ac + 1,0);
  uStack_8 = 2;
  *(undefined ***)(appuStack_ac[0][1] + (int)appuStack_ac) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(appuStack_ac[0][1] + (int)&stack0xffffff50) = appuStack_ac[0][1] + -0x50;
  FUN_0054ee60();
  appuStack_ac[1] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  uStack_70 = 0;
  uStack_6c = 4;
  uStack_8 = 3;
  iVar3 = (param_2[1] - *param_2) / 0x14;
  if (0 < iVar3) {
    iVar2 = 0;
    do {
      uVar1 = FUN_00a8e3b0(*(undefined4 *)(*param_2 + iVar2),&DAT_018c0cc8);
      FUN_00558890(uVar1);
      uVar1 = FUN_00a8e3b0(*(undefined4 *)(iVar2 + 4 + *param_2),&DAT_018c0cc8);
      FUN_00558890(uVar1);
      uVar1 = FUN_00a8e3b0(*(undefined4 *)(iVar2 + 8 + *param_2),&DAT_018c0cc8);
      FUN_00558890(uVar1);
      uVar1 = FUN_00a8e3b0(*(undefined4 *)(iVar2 + 0xc + *param_2),&DAT_018c0cc8);
      FUN_00558890(uVar1);
      uVar1 = FUN_00a8e3b0(*(undefined4 *)(iVar2 + 0x10 + *param_2),&DAT_018c0cc8);
      FUN_00558890(uVar1);
      iVar2 = iVar2 + 0x14;
      iVar3 = iVar3 + -1;
    } while (iVar3 != 0);
  }
  FUN_0058c400(param_1);
  *(undefined ***)(appuStack_ac[0][1] + (int)appuStack_ac) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(appuStack_ac[0][1] + (int)&stack0xffffff50) = appuStack_ac[0][1] + -0x50;
  FUN_0056b950();
  *(undefined ***)(appuStack_ac[0][1] + (int)appuStack_ac) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)(appuStack_ac[0][1] + (int)&stack0xffffff50) = appuStack_ac[0][1] + -8;
  uStack_8 = 4;
  appuStack_5c[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_5c);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21687 ; VA 0x00a91f00 ; FUN_00a91f00 */

uint FUN_00a91f00(undefined4 *param_1,char param_2)

{
  float *pfVar1;
  float fVar2;
  float fVar3;
  float *pfVar4;
  float *pfVar5;
  float *pfVar6;
  int iVar7;
  int iVar8;
  float fVar9;
  double dVar10;
  float fVar11;
  uint uVar12;
  float fVar13;
  undefined auStack_1c [12];
  int iStack_10;
  float *pfStack_c;
  float *pfStack_8;
  
  iVar8 = param_1[1];
  pfVar6 = (float *)*param_1;
  pfVar5 = (float *)((iVar8 - (int)pfVar6) / 0x14);
  if (pfVar5 < (float *)0x2) {
    if (param_2 != '\0') {
      FUN_016756b0(auStack_1c,"ColorSequence: requires at least 2 keypoints");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
  }
  else if (pfVar5 < &DAT_00000015) {
    pfStack_8 = (float *)0x0;
    fVar13 = DAT_018ce2f8;
    if (pfVar5 != (float *)0x0) {
      iVar7 = 0;
      do {
        if ((DAT_020c0b1c != '\0') && (DAT_01d66514 != '\0')) {
          pfStack_c = *(float **)(iVar7 + (int)pfVar6);
          pfVar5 = (float *)FUN_01726720(&pfStack_c);
          fVar13 = DAT_018ce2f8;
          if ((short)pfVar5 == 2) {
            if (param_2 != '\0') {
              FUN_016756b0(auStack_1c,"ColorSequence: time must be a valid number");
                    /* WARNING: Subroutine does not return */
              FUN_0170c2a8(auStack_1c,&DAT_01c17198);
            }
            goto LAB_00a920b4;
          }
        }
        iVar8 = param_1[1];
        pfVar6 = (float *)*param_1;
        pfVar4 = (float *)((iVar8 - (int)pfVar6) / 0x14);
        pfVar5 = (float *)((int)pfVar4 + -1);
        iStack_10 = iVar8;
        if ((pfStack_8 < pfVar5) &&
           (pfVar1 = (float *)(iVar7 + 0x14 + (int)pfVar6),
           *pfVar1 <= *(float *)(iVar7 + (int)pfVar6) && *(float *)(iVar7 + (int)pfVar6) != *pfVar1)
           ) {
          if (param_2 != '\0') {
            FUN_016756b0(auStack_1c,"ColorSequence: all keypoints must be ordered by time");
                    /* WARNING: Subroutine does not return */
            FUN_0170c2a8(auStack_1c,&DAT_01c17198);
          }
          goto LAB_00a920b4;
        }
        fVar2 = *(float *)(iVar7 + 4 + (int)pfVar6);
        pfVar5 = (float *)((int)pfVar6 + iVar7 + 8);
        pfStack_c = (float *)((int)pfVar6 + iVar7 + 4);
        fVar3 = *pfVar5;
        fVar11 = fVar2;
        if (fVar3 < fVar2) {
          fVar11 = fVar3;
        }
        fVar9 = *(float *)(iVar7 + 0xc + (int)pfVar6);
        if (fVar9 < fVar11) {
          fVar11 = fVar9;
        }
        if (fVar11 < 0.0) {
LAB_00a92086:
          if (param_2 != '\0') {
            FUN_016756b0(auStack_1c,"ColorSequence: color value out of range");
                    /* WARNING: Subroutine does not return */
            FUN_0170c2a8(auStack_1c,&DAT_01c17198);
          }
          goto LAB_00a920b4;
        }
        if (fVar3 <= fVar2) {
          pfVar5 = pfStack_c;
        }
        if (fVar9 <= *pfVar5) {
          fVar9 = *pfVar5;
        }
        if (fVar13 < fVar9) goto LAB_00a92086;
        pfStack_8 = (float *)((int)pfStack_8 + 1);
        iVar7 = iVar7 + 0x14;
      } while (pfStack_8 < pfVar4);
    }
    uVar12 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
    if ((float)(double)CONCAT44((uint)((ulonglong)(double)*pfVar6 >> 0x20) & uVar12,
                                SUB84((double)*pfVar6,0) & (uint)DAT_018c0da0) <= DAT_018fd178) {
      dVar10 = (double)(*(float *)(iVar8 + -0x14) - fVar13);
      if ((float)(double)CONCAT44((uint)((ulonglong)dVar10 >> 0x20) & uVar12,
                                  SUB84(dVar10,0) & (uint)DAT_018c0da0) <= DAT_018fd178) {
        return CONCAT31((int3)((uint)pfVar5 >> 8),1);
      }
      if (param_2 != '\0') {
        FUN_016756b0(auStack_1c,"ColorSequence must end at time=1.0");
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_1c,&DAT_01c17198);
      }
    }
    else if (param_2 != '\0') {
      FUN_016756b0(auStack_1c,"ColorSequence must start at time=0.0");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
  }
  else if (param_2 != '\0') {
    FUN_016756b0(auStack_1c,"ColorSequence: max number of keypoints exceeded.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
LAB_00a920b4:
  return (uint)pfVar5 & 0xffffff00;
}



/* FUNCTION 21688 ; VA 0x00a921a0 ; FUN_00a921a0 */

void __thiscall FUN_00a921a0(int param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  int aiStack_4c [5];
  uint uStack_38;
  int aiStack_34 [5];
  uint uStack_20;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5967;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_1c,param_2);
  uStack_8 = 0;
  FUN_00a91cc0(aiStack_4c,auStack_1c);
  uStack_8._0_1_ = 2;
  FUN_00617bc0();
  FUN_0054ef60(aiStack_4c);
  uStack_8._0_1_ = 3;
  FUN_0087ccc0();
  iVar1 = FUN_01674e20(0x18);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (iVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_0054ef60(aiStack_34);
  }
  *(undefined4 *)(param_3 + 0x18) = uVar2;
  *(undefined4 *)(param_3 + 0x14) = 2;
  if (0xf < uStack_20) {
    uVar3 = uStack_20 + 1;
    iVar1 = aiStack_34[0];
    if (0xfff < uVar3) {
      iVar1 = *(int *)(aiStack_34[0] + -4);
      uVar3 = uStack_20 + 0x24;
      if (0x1f < (aiStack_34[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  if (0xf < uStack_38) {
    uVar3 = uStack_38 + 1;
    iVar1 = aiStack_4c[0];
    if (0xfff < uVar3) {
      iVar1 = *(int *)(aiStack_4c[0] + -4);
      uVar3 = uStack_38 + 0x24;
      if (0x1f < (aiStack_4c[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21689 ; VA 0x00a922c0 ; FUN_00a922c0 */

undefined * FUN_00a922c0(undefined *param_1,uint *param_2)

{
  uint uVar1;
  undefined4 ****ppppuVar2;
  int iVar3;
  undefined1 *puVar4;
  undefined4 uVar5;
  undefined4 ***apppuStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e59a1;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  uStack_1c = 0;
  uStack_18 = 0xf;
  apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 1;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  iVar3 = 0;
  uStack_14 = 1;
  do {
    uVar1 = FUN_00d6a3c0(iVar3);
    if ((*param_2 & uVar1) != 0) {
      ppppuVar2 = apppuStack_2c;
      if (0xf < uStack_18) {
        ppppuVar2 = (undefined4 ****)apppuStack_2c[0];
      }
      FUN_00554150(ppppuVar2,uStack_1c);
      switch(iVar3) {
      case 0:
        uVar5 = 5;
        puVar4 = &DAT_018fab10;
        break;
      case 1:
        uVar5 = 3;
        puVar4 = &DAT_0191cd4c;
        break;
      case 2:
        uVar5 = 4;
        puVar4 = &DAT_0191cd58;
        break;
      case 3:
        uVar5 = 4;
        puVar4 = &DAT_018fab04;
        break;
      case 4:
        uVar5 = 6;
        puVar4 = &DAT_0191cd50;
        break;
      case 5:
        uVar5 = 5;
        puVar4 = &DAT_0191cd60;
        break;
      default:
        goto switchD_00a9236a_caseD_6;
      }
      FUN_00554150(puVar4,uVar5);
switchD_00a9236a_caseD_6:
      FUN_005542c0(&DAT_018cecfc,2);
    }
    iVar3 = iVar3 + 1;
    if (iVar3 == 6) {
      if (0xf < uStack_18) {
        uVar1 = uStack_18 + 1;
        ppppuVar2 = (undefined4 ****)apppuStack_2c[0];
        if (0xfff < uVar1) {
          ppppuVar2 = (undefined4 ****)apppuStack_2c[0][-1];
          uVar1 = uStack_18 + 0x24;
          if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar2,uVar1);
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
  } while( true );
}



/* FUNCTION 21690 ; VA 0x00a92430 ; FUN_00a92430 */

undefined FUN_00a92430(undefined4 *param_1,uint *param_2)

{
  undefined4 *puVar1;
  char cVar2;
  undefined1 *puVar3;
  uint uVar4;
  undefined1 **ppuVar5;
  undefined1 *puVar6;
  uint uVar7;
  undefined uVar8;
  undefined1 *puVar9;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined1 *puStack_30;
  int iStack_2c;
  undefined1 *puStack_28;
  undefined4 uStack_24;
  undefined4 *puStack_20;
  undefined1 *puStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c4f08;
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  puStack_1c = (undefined1 *)param_1[4];
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  uVar8 = 0;
  puStack_20 = param_1;
  while( true ) {
    do {
      if (puStack_1c == (undefined1 *)0x0) {
        ExceptionList = pvStack_10;
        return uVar8;
      }
      puVar3 = (undefined1 *)FUN_01683820(&DAT_018cecfc,2,0);
      puVar1 = puStack_20;
      puVar9 = puStack_1c;
      if (puVar3 == (undefined1 *)0xffffffff) {
        ppuVar5 = &puStack_28;
        puStack_28 = &DAT_018bc9b8;
        uStack_24 = 0;
      }
      else {
        if (puVar3 <= puStack_1c) {
          puVar9 = puVar3;
        }
        puVar6 = puStack_1c;
        if (puVar3 + 1 <= puStack_1c) {
          puVar6 = puVar3 + 1;
        }
        iStack_2c = -1;
        if ((int)puStack_1c - (int)puVar6 != -1) {
          iStack_2c = (int)puStack_1c - (int)puVar6;
        }
        ppuVar5 = &puStack_30;
        puStack_30 = puVar6 + (int)puStack_20;
      }
      puStack_20 = (undefined4 *)*ppuVar5;
      puStack_1c = ppuVar5[1];
    } while (puVar9 == (undefined1 *)0x0);
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
    if (puVar1 != (undefined4 *)0x0) {
      FUN_005542c0(puVar1,puVar9);
    }
    uStack_8 = 0;
    cVar2 = FUN_0088e380(auStack_48,&uStack_14);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_34) {
      uVar7 = uStack_34 + 1;
      uVar4 = auStack_48[0];
      if (0xfff < uVar7) {
        uVar4 = *(uint *)(auStack_48[0] - 4);
        uVar7 = uStack_34 + 0x24;
        if (0x1f < (auStack_48[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar4,uVar7);
    }
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
    if (cVar2 == '\0') break;
    uVar4 = FUN_00d6a3c0(uStack_14);
    uVar8 = 1;
    *param_2 = *param_2 | uVar4;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 21691 ; VA 0x00a925d0 ; FUN_00a925d0 */

bool __thiscall FUN_00a925d0(uint *param_1,undefined4 param_2)

{
  uint uVar1;
  
  uVar1 = FUN_00d6a3c0(param_2);
  return (*param_1 & uVar1) != 0;
}



/* FUNCTION 21692 ; VA 0x00a925f0 ; FUN_00a925f0 */

void __thiscall FUN_00a925f0(uint *param_1,undefined4 param_2,char param_3)

{
  uint uVar1;
  
  uVar1 = FUN_00d6a3c0(param_2);
  if (param_3 != '\0') {
    *param_1 = *param_1 | uVar1;
    return;
  }
  *param_1 = ~uVar1 & *param_1;
  return;
}



/* FUNCTION 21693 ; VA 0x00a92620 ; FUN_00a92620 */

void __thiscall FUN_00a92620(int *param_1,uint param_2)

{
  undefined8 *puVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  undefined8 *puVar5;
  int iVar6;
  uint uVar7;
  
  uVar2 = (param_1[1] - *param_1) / 0xc;
  uVar3 = (param_1[2] - *param_1) / 0xc;
  if (param_2 <= uVar3) {
    if (param_2 <= uVar2) {
      if (param_2 != uVar2) {
        param_1[1] = *param_1 + param_2 * 0xc;
      }
      return;
    }
    iVar4 = FUN_006d3350(param_1[1],param_2 - uVar2);
    param_1[1] = iVar4;
    return;
  }
  if (0x15555555 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar7 = param_2;
  if ((uVar3 <= 0x15555555 - (uVar3 >> 1)) && (uVar7 = (uVar3 >> 1) + uVar3, uVar7 < param_2)) {
    uVar7 = param_2;
  }
  iVar4 = FUN_00618050(uVar7);
  FUN_006d3350(iVar4 + uVar2 * 0xc,param_2 - uVar2);
  puVar5 = (undefined8 *)*param_1;
  puVar1 = (undefined8 *)param_1[1];
  if (puVar5 != puVar1) {
    iVar6 = iVar4 - (int)puVar5;
    do {
      *(undefined8 *)(iVar6 + (int)puVar5) = *puVar5;
      *(undefined4 *)(iVar6 + 8 + (int)puVar5) = *(undefined4 *)(puVar5 + 1);
      puVar5 = (undefined8 *)((int)puVar5 + 0xc);
    } while (puVar5 != puVar1);
  }
  FUN_006bf950(iVar4,param_2,uVar7);
  return;
}



/* FUNCTION 21694 ; VA 0x00a92730 ; thunk_FUN_00a92750 */

int * __fastcall thunk_FUN_00a92750(int *param_1)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined auStack_2c [12];
  int iStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e59c0;
  pvStack_10 = ExceptionList;
  iVar4 = *param_1;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00a92ae0();
  if (iVar4 == iVar1) {
    piVar2 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar2 = (int *)0x0;
    }
    if (piVar2 != (int *)0x0) {
      ExceptionList = pvStack_10;
      return piVar2;
    }
  }
  iVar4 = *param_1;
  iVar1 = FUN_0088cb40();
  if (iVar4 == iVar1) {
    FUN_00a92e30(0);
    iVar4 = *param_1;
    iStack_8 = 0;
    iVar1 = FUN_0088cb40();
    if (iVar4 != iVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar2 = param_1 + 2;
    piVar3 = piVar2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    if (piVar3[4] != 0) {
      piVar3 = (int *)FUN_00a93240(auStack_2c,piVar3);
      iStack_8._0_1_ = 1;
      if (&iStack_20 != piVar3) {
        FUN_00602a00(*piVar3,piVar3[1],uStack_14);
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_00617ad0();
      iVar1 = FUN_00630f20();
      iVar4 = param_1[1];
      if (iVar4 == iVar1) {
        if (piVar2 != &iStack_20) {
          FUN_00602a00(iStack_20,uStack_1c,uStack_14);
        }
      }
      else {
        if (iVar4 != 0) {
          (**(code **)(iVar4 + 8))(piVar2);
          param_1[1] = 0;
        }
        FUN_00a92cb0(&iStack_20,0xe4078678,0x64078678);
        param_1[1] = iVar1;
      }
      iVar4 = FUN_00a92ae0();
      *param_1 = iVar4;
      iVar1 = FUN_00a92ae0();
      if (iVar4 == iVar1) {
        if (param_1[1] == 0) {
          piVar2 = (int *)0x0;
        }
        FUN_00617ad0();
        ExceptionList = pvStack_10;
        return piVar2;
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    iStack_8 = 0xffffffff;
    thunk_FUN_00617ad0();
  }
  thunk_FUN_00a92ae0();
  uVar5 = FUN_005543f0();
  uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar6,uVar5);
}



/* FUNCTION 21695 ; VA 0x00a92740 ; thunk_FUN_00a928f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __fastcall thunk_FUN_00a928f0(int *param_1)

{
  undefined *puVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e59db;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00a92b80();
  if (iVar5 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    if (piVar3 != (int *)0x0) {
      ExceptionList = pvStack_10;
      return piVar3;
    }
  }
  iVar5 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar5 == iVar2) {
    iVar5 = *param_1;
    uStack_1c = 0;
    uStack_18 = 0;
    iStack_14 = 0;
    iVar2 = FUN_0088cb40();
    if (iVar5 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_1 + 2;
    piVar4 = piVar3;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    if (piVar4[4] != 0) {
      FUN_00565000(piVar4,1,1);
      uStack_8 = 0;
      FUN_00a8d320(&uStack_1c);
      FUN_00a8d320(&uStack_18);
      FUN_00a8d320(&iStack_14);
      uStack_8 = 0xffffffff;
      FUN_005703e0();
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead368
          ) && (FUN_016f3809(&DAT_01ead368), DAT_01ead368 == -1)) {
        _DAT_01ead35c = FUN_005c6600;
        _DAT_01ead360 = FUN_005c6600;
        _DAT_01ead364 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ead368);
      }
      puVar1 = (undefined *)param_1[1];
      if (puVar1 == &DAT_01ead35c) {
        *(ulonglong *)piVar3 = CONCAT44(uStack_18,uStack_1c);
        param_1[4] = iStack_14;
      }
      else {
        if (puVar1 != (undefined *)0x0) {
          (**(code **)(puVar1 + 8))(piVar3);
        }
        *(ulonglong *)(param_1 + 2) = CONCAT44(uStack_18,uStack_1c);
        param_1[4] = iStack_14;
        param_1[1] = (int)&DAT_01ead35c;
      }
      iVar5 = FUN_00a92b80();
      *param_1 = iVar5;
      iVar2 = FUN_00a92b80();
      if (iVar5 == iVar2) {
        if (param_1[1] == 0) {
          piVar3 = (int *)0x0;
        }
        ExceptionList = pvStack_10;
        return piVar3;
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
  }
  thunk_FUN_00a92b80();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 21696 ; VA 0x00a92750 ; FUN_00a92750 */

int * __fastcall FUN_00a92750(int *param_1)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined auStack_2c [12];
  int iStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e59c0;
  pvStack_10 = ExceptionList;
  iVar4 = *param_1;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00a92ae0();
  if (iVar4 == iVar1) {
    piVar2 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar2 = (int *)0x0;
    }
    if (piVar2 != (int *)0x0) {
      ExceptionList = pvStack_10;
      return piVar2;
    }
  }
  iVar4 = *param_1;
  iVar1 = FUN_0088cb40();
  if (iVar4 == iVar1) {
    FUN_00a92e30(0);
    iVar4 = *param_1;
    iStack_8 = 0;
    iVar1 = FUN_0088cb40();
    if (iVar4 != iVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar2 = param_1 + 2;
    piVar3 = piVar2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    if (piVar3[4] != 0) {
      piVar3 = (int *)FUN_00a93240(auStack_2c,piVar3);
      iStack_8._0_1_ = 1;
      if (&iStack_20 != piVar3) {
        FUN_00602a00(*piVar3,piVar3[1],uStack_14);
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_00617ad0();
      iVar1 = FUN_00630f20();
      iVar4 = param_1[1];
      if (iVar4 == iVar1) {
        if (piVar2 != &iStack_20) {
          FUN_00602a00(iStack_20,uStack_1c,uStack_14);
        }
      }
      else {
        if (iVar4 != 0) {
          (**(code **)(iVar4 + 8))(piVar2);
          param_1[1] = 0;
        }
        FUN_00a92cb0(&iStack_20,0xe4078678,0x64078678);
        param_1[1] = iVar1;
      }
      iVar4 = FUN_00a92ae0();
      *param_1 = iVar4;
      iVar1 = FUN_00a92ae0();
      if (iVar4 == iVar1) {
        if (param_1[1] == 0) {
          piVar2 = (int *)0x0;
        }
        FUN_00617ad0();
        ExceptionList = pvStack_10;
        return piVar2;
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    iStack_8 = 0xffffffff;
    thunk_FUN_00617ad0();
  }
  thunk_FUN_00a92ae0();
  uVar5 = FUN_005543f0();
  uVar6 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar6,uVar5);
}



/* FUNCTION 21697 ; VA 0x00a928f0 ; FUN_00a928f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __fastcall FUN_00a928f0(int *param_1)

{
  undefined *puVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e59db;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00a92b80();
  if (iVar5 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    if (piVar3 != (int *)0x0) {
      ExceptionList = pvStack_10;
      return piVar3;
    }
  }
  iVar5 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar5 == iVar2) {
    iVar5 = *param_1;
    uStack_1c = 0;
    uStack_18 = 0;
    iStack_14 = 0;
    iVar2 = FUN_0088cb40();
    if (iVar5 != iVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar3 = param_1 + 2;
    piVar4 = piVar3;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    if (piVar4[4] != 0) {
      FUN_00565000(piVar4,1,1);
      uStack_8 = 0;
      FUN_00a8d320(&uStack_1c);
      FUN_00a8d320(&uStack_18);
      FUN_00a8d320(&iStack_14);
      uStack_8 = 0xffffffff;
      FUN_005703e0();
      if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead368
          ) && (FUN_016f3809(&DAT_01ead368), DAT_01ead368 == -1)) {
        _DAT_01ead35c = FUN_005c6600;
        _DAT_01ead360 = FUN_005c6600;
        _DAT_01ead364 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ead368);
      }
      puVar1 = (undefined *)param_1[1];
      if (puVar1 == &DAT_01ead35c) {
        *(ulonglong *)piVar3 = CONCAT44(uStack_18,uStack_1c);
        param_1[4] = iStack_14;
      }
      else {
        if (puVar1 != (undefined *)0x0) {
          (**(code **)(puVar1 + 8))(piVar3);
        }
        *(ulonglong *)(param_1 + 2) = CONCAT44(uStack_18,uStack_1c);
        param_1[4] = iStack_14;
        param_1[1] = (int)&DAT_01ead35c;
      }
      iVar5 = FUN_00a92b80();
      *param_1 = iVar5;
      iVar2 = FUN_00a92b80();
      if (iVar5 == iVar2) {
        if (param_1[1] == 0) {
          piVar3 = (int *)0x0;
        }
        ExceptionList = pvStack_10;
        return piVar3;
      }
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
  }
  thunk_FUN_00a92b80();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 21698 ; VA 0x00a92ae0 ; FUN_00a92ae0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a92ae0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e59fc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeae7c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeae7c);
    if (DAT_01eeae7c == -1) {
      uStack_8 = 0;
      FUN_00888860("NumberSequence",0x2c,0,0,0);
      _DAT_01eeae58 = RBX::Reflection::TType<class_RBX::NumberSequence>::vftable;
      FUN_016f3654(&LAB_0188acc0);
      FUN_016f37bf(&DAT_01eeae7c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeae58;
}



/* FUNCTION 21699 ; VA 0x00a92b80 ; FUN_00a92b80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00a92b80(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5a1c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeaea4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eeaea4);
    if (DAT_01eeaea4 == -1) {
      uStack_8 = 0;
      FUN_00888860("NumberSequenceKeypoint",0x2d,0,0,0);
      _DAT_01eeae80 = RBX::Reflection::TType<class_RBX::NumberSequenceKeypoint>::vftable;
      FUN_016f3654(&LAB_0188acd0);
      FUN_016f37bf(&DAT_01eeaea4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eeae80;
}



/* FUNCTION 21700 ; VA 0x00a92c20 ; FUN_00a92c20 */

int * __thiscall FUN_00a92c20(int *param_1,int *param_2)

{
  undefined8 *puVar1;
  uint uVar2;
  int iVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar2 = (param_2[1] - *param_2) / 0xc;
  if (uVar2 != 0) {
    if (0x15555555 < uVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar3 = FUN_00618050(uVar2);
    *param_1 = iVar3;
    param_1[1] = iVar3;
    param_1[2] = *param_1 + uVar2 * 0xc;
    puVar1 = (undefined8 *)param_2[1];
    puVar5 = (undefined8 *)*param_1;
    for (puVar4 = (undefined8 *)*param_2; puVar4 != puVar1;
        puVar4 = (undefined8 *)((int)puVar4 + 0xc)) {
      *puVar5 = *puVar4;
      *(undefined4 *)(puVar5 + 1) = *(undefined4 *)(puVar4 + 1);
      puVar5 = (undefined8 *)((int)puVar5 + 0xc);
    }
    param_1[1] = (int)puVar5;
  }
  return param_1;
}



/* FUNCTION 21701 ; VA 0x00a92cb0 ; FUN_00a92cb0 */

int * __thiscall FUN_00a92cb0(int *param_1,undefined4 param_2,float param_3,float param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  
  FUN_00a92c20(param_2);
  iVar3 = (param_1[1] - *param_1) / 0xc;
  if (iVar3 != 0) {
    iVar2 = 0;
    do {
      fVar5 = *(float *)(iVar2 + 4 + *param_1);
      fVar4 = param_3;
      if (param_3 <= fVar5) {
        fVar4 = fVar5;
      }
      fVar5 = param_4;
      if (fVar4 <= param_4) {
        fVar5 = fVar4;
      }
      *(float *)(iVar2 + 4 + *param_1) = fVar5;
      iVar1 = *param_1;
      fVar6 = param_4 - *(float *)(iVar2 + 4 + iVar1);
      fVar5 = *(float *)(iVar2 + 8 + iVar1);
      fVar4 = 0.0;
      if (0.0 <= fVar5) {
        fVar4 = fVar5;
      }
      if (fVar4 <= fVar6) {
        fVar6 = fVar4;
      }
      *(float *)(iVar2 + 8 + iVar1) = fVar6;
      iVar1 = *param_1;
      fVar5 = *(float *)(iVar2 + 8 + iVar1);
      fVar4 = 0.0;
      if (0.0 <= fVar5) {
        fVar4 = fVar5;
      }
      fVar5 = *(float *)(iVar2 + 4 + iVar1);
      if (fVar4 <= fVar5) {
        fVar5 = fVar4;
      }
      *(float *)(iVar2 + 8 + iVar1) = fVar5;
      iVar2 = iVar2 + 0xc;
      iVar3 = iVar3 + -1;
    } while (iVar3 != 0);
  }
  return param_1;
}



/* FUNCTION 21702 ; VA 0x00a92d50 ; FUN_00a92d50 */

undefined4 * __thiscall FUN_00a92d50(undefined4 *param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5a38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uStack_8 = 0;
  cVar2 = FUN_00a93960(param_2,param_3);
  if (cVar2 == '\0') {
    puVar3 = (undefined4 *)FUN_00a92e30(0);
    if (puVar3 != param_1) {
      uVar1 = *puVar3;
      *puVar3 = *param_1;
      *param_1 = uVar1;
      uVar1 = puVar3[1];
      puVar3[1] = param_1[1];
      param_1[1] = uVar1;
      uVar1 = puVar3[2];
      puVar3[2] = param_1[2];
      param_1[2] = uVar1;
    }
    FUN_00617ad0();
    ExceptionList = pvStack_10;
    return param_1;
  }
  if (param_1 != param_2) {
    FUN_00602a00(*param_2,param_2[1],param_3);
  }
  *(undefined4 *)*param_1 = 0;
  *(undefined4 *)(param_1[1] + -0xc) = 0x3f800000;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21703 ; VA 0x00a92e30 ; FUN_00a92e30 */

int * __thiscall FUN_00a92e30(int *param_1,uint param_2)

{
  longlong *plVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5a38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uStack_8 = 0;
  FUN_00a92620(2,param_1);
  plVar1 = (longlong *)*param_1;
  *plVar1 = (ulonglong)param_2 << 0x20;
  uVar3 = DAT_018ce2f8;
  *(undefined4 *)(plVar1 + 1) = 0;
  iVar2 = *param_1;
  *(ulonglong *)(iVar2 + 0xc) = CONCAT44(param_2,uVar3);
  *(undefined4 *)(iVar2 + 0x14) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21704 ; VA 0x00a92ed0 ; FUN_00a92ed0 */

int * __thiscall FUN_00a92ed0(int *param_1,uint param_2,undefined4 param_3)

{
  longlong *plVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5a38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uStack_8 = 0;
  FUN_00a92620(2,param_1);
  plVar1 = (longlong *)*param_1;
  *plVar1 = (ulonglong)param_2 << 0x20;
  uVar3 = DAT_018ce2f8;
  *(undefined4 *)(plVar1 + 1) = 0;
  iVar2 = *param_1;
  *(ulonglong *)(iVar2 + 0xc) = CONCAT44(param_3,uVar3);
  *(undefined4 *)(iVar2 + 0x14) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21705 ; VA 0x00a92f70 ; FUN_00a92f70 */

uint __thiscall FUN_00a92f70(int *param_1,int *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint *puVar3;
  int iVar4;
  
  puVar1 = (uint *)param_1[1];
  puVar3 = (uint *)*param_1;
  uVar2 = ((int)puVar1 - (int)puVar3) / 0xc;
  if (uVar2 == (param_2[1] - *param_2) / 0xc) {
    if (puVar3 != puVar1) {
      iVar4 = *param_2 - (int)puVar3;
      do {
        uVar2 = *puVar3;
        if (((uVar2 != *(uint *)(iVar4 + (int)puVar3)) ||
            (uVar2 = puVar3[1], uVar2 != *(uint *)(iVar4 + 4 + (int)puVar3))) ||
           (uVar2 = puVar3[2], uVar2 != *(uint *)(iVar4 + 8 + (int)puVar3))) goto LAB_00a92fdc;
        puVar3 = puVar3 + 3;
      } while (puVar3 != puVar1);
    }
    return CONCAT31((int3)(uVar2 >> 8),1);
  }
LAB_00a92fdc:
  return uVar2 & 0xffffff00;
}



/* FUNCTION 21706 ; VA 0x00a92ff0 ; FUN_00a92ff0 */

undefined4 FUN_00a92ff0(undefined4 param_1,undefined4 param_2)

{
  FUN_00a93780(param_1,param_2);
  return param_1;
}



/* FUNCTION 21707 ; VA 0x00a93010 ; FUN_00a93010 */

/* WARNING: Type propagation algorithm not settling */

undefined4 FUN_00a93010(undefined4 param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined **appuStack_ac [15];
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_60;
  undefined **appuStack_5c [18];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e585f;
  pvStack_10 = ExceptionList;
  appuStack_ac[0] = &PTR_018be314;
  uStack_8 = 0;
  uStack_14 = 2;
  appuStack_5c[0] = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_60 = 0x48;
  ExceptionList = &pvStack_10;
  FUN_00554f20(appuStack_ac + 1,0);
  uStack_8 = 2;
  *(undefined ***)(appuStack_ac[0][1] + (int)appuStack_ac) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(appuStack_ac[0][1] + (int)&stack0xffffff50) = appuStack_ac[0][1] + -0x50;
  FUN_0054ee60();
  appuStack_ac[1] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  uStack_70 = 0;
  uStack_6c = 4;
  uStack_8 = 3;
  uVar1 = FUN_00a8e3b0(*param_2,&DAT_018c0cc8);
  FUN_00558890(uVar1);
  uVar1 = FUN_00a8e3b0(param_2[1],&DAT_018c0cc8);
  FUN_00558890(uVar1);
  uVar1 = FUN_00a8e3b0(param_2[2],&DAT_018c0cc8);
  FUN_00558890(uVar1);
  FUN_0058c400(param_1);
  *(undefined ***)(appuStack_ac[0][1] + (int)appuStack_ac) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(appuStack_ac[0][1] + (int)&stack0xffffff50) = appuStack_ac[0][1] + -0x50;
  FUN_0056b950();
  *(undefined ***)(appuStack_ac[0][1] + (int)appuStack_ac) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)(appuStack_ac[0][1] + (int)&stack0xffffff50) = appuStack_ac[0][1] + -8;
  uStack_8 = 4;
  appuStack_5c[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_5c);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21708 ; VA 0x00a931c0 ; FUN_00a931c0 */

undefined4 FUN_00a931c0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5a58;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x10) == 0) {
    return 0;
  }
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_00a93240(auStack_1c,param_1);
  uStack_8 = 0;
  if (param_2 != puVar1) {
    FUN_00602a00(*puVar1,puVar1[1],param_1);
  }
  FUN_00617ad0();
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 21709 ; VA 0x00a93240 ; FUN_00a93240 */

undefined4 * FUN_00a93240(undefined4 *param_1,undefined4 param_2)

{
  byte bVar1;
  undefined4 uVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  int aiStack_d0 [3];
  byte abStack_c4 [84];
  undefined **appuStack_70 [18];
  undefined4 uStack_28;
  undefined8 *puStack_24;
  undefined8 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5a8b;
  pvStack_10 = ExceptionList;
  puVar5 = (undefined8 *)0x0;
  uStack_28 = 0;
  puVar6 = (undefined8 *)0x0;
  puStack_24 = (undefined8 *)0x0;
  puStack_20 = (undefined8 *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00565000(param_2,1,1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00a8d320(&uStack_1c);
  FUN_00a8d320(&uStack_18);
  FUN_00a8d320(&uStack_14);
  bVar1 = abStack_c4[*(int *)(aiStack_d0[0] + 4)];
  while ((bVar1 & 1) == 0) {
    if (puVar6 == puVar5) {
      FUN_007fc130(puVar5,&uStack_1c);
      puVar6 = puStack_20;
    }
    else {
      *puVar5 = CONCAT44(uStack_18,uStack_1c);
      *(undefined4 *)(puVar5 + 1) = uStack_14;
      puStack_24 = (undefined8 *)((int)puVar5 + 0xc);
    }
    puVar5 = puStack_24;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
    FUN_00a8d320(&uStack_1c);
    FUN_00a8d320(&uStack_18);
    FUN_00a8d320(&uStack_14);
    bVar1 = abStack_c4[*(int *)(aiStack_d0[0] + 4)];
  }
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uStack_8._1_3_ = (undefined3)((uint)uStack_8 >> 8);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar3 = FUN_00a93960(&uStack_28,0);
  if (cVar3 == '\0') {
    puVar4 = (undefined4 *)FUN_00a92e30(0);
    if (puVar4 != param_1) {
      uVar2 = *puVar4;
      *puVar4 = *param_1;
      *param_1 = uVar2;
      uVar2 = puVar4[1];
      puVar4[1] = param_1[1];
      param_1[1] = uVar2;
      uVar2 = puVar4[2];
      puVar4[2] = param_1[2];
      param_1[2] = uVar2;
    }
    FUN_00617ad0();
  }
  else {
    if (param_1 != &uStack_28) {
      FUN_00602a00(uStack_28,puStack_24,param_1);
    }
    *(undefined4 *)*param_1 = 0;
    *(undefined4 *)(param_1[1] + -0xc) = 0x3f800000;
  }
  *(undefined ***)((int)aiStack_d0 + *(int *)(aiStack_d0[0] + 4)) =
       std::basic_istringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(int *)(abStack_c4 + *(int *)(aiStack_d0[0] + 4) + -0x10) = *(int *)(aiStack_d0[0] + 4) + -0x60;
  FUN_0056b950();
  *(undefined ***)((int)aiStack_d0 + *(int *)(aiStack_d0[0] + 4)) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(abStack_c4 + *(int *)(aiStack_d0[0] + 4) + -0x10) = *(int *)(aiStack_d0[0] + 4) + -0x18;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  appuStack_70[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_70);
  FUN_00617ad0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21710 ; VA 0x00a93470 ; FUN_00a93470 */

int __thiscall FUN_00a93470(int param_1,undefined4 param_2)

{
  int iStack_10;
  int iStack_c;
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&iStack_10,param_2);
  FUN_00617ad0();
  return ((iStack_c - iStack_10) / 0xc) * 0xc;
}



/* FUNCTION 21711 ; VA 0x00a934c0 ; FUN_00a934c0 */

undefined4 __thiscall FUN_00a934c0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5a58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_1c,param_3);
  uStack_8 = 0;
  FUN_00a93780(param_2,auStack_1c);
  FUN_00617ad0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21712 ; VA 0x00a93520 ; FUN_00a93520 */

void __thiscall FUN_00a93520(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5ab0;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0087d060(auStack_34);
  uVar1 = FUN_00a93240(auStack_1c,auStack_34);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,uVar1);
  FUN_00617ad0();
  if (0xf < uStack_20) {
    uVar3 = uStack_20 + 1;
    uVar2 = auStack_34[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_34[0] - 4);
      uVar3 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21713 ; VA 0x00a935e0 ; FUN_00a935e0 */

void __thiscall FUN_00a935e0(int *param_1,float *param_2,int param_3,float param_4,float param_5)

{
  int iVar1;
  float *pfVar2;
  int iVar3;
  int iVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  
  iVar3 = 0;
  fVar9 = 0.0;
  iVar4 = 1;
  fVar5 = *(float *)(*param_1 + 4) - *(float *)(*param_1 + 8);
  fVar10 = DAT_018ce2f8 / ((float)param_3 - DAT_018ce2f8) - DAT_018fe498;
  fVar6 = param_4;
  if (param_4 <= fVar5) {
    fVar6 = fVar5;
  }
  fVar5 = param_5;
  if (fVar6 <= param_5) {
    fVar5 = fVar6;
  }
  *param_2 = fVar5;
  fVar5 = *(float *)(*param_1 + 8) + *(float *)(*param_1 + 4);
  fVar6 = param_4;
  if (param_4 <= fVar5) {
    fVar6 = fVar5;
  }
  fVar5 = param_5;
  if (fVar6 <= param_5) {
    fVar5 = fVar6;
  }
  param_2[1] = fVar5;
  if (1 < param_3) {
    do {
      iVar1 = *param_1;
      fVar9 = fVar9 + fVar10;
      pfVar2 = (float *)(iVar1 + (iVar3 + 1) * 0xc);
      if (*pfVar2 <= fVar9 && fVar9 != *pfVar2) {
        do {
          pfVar2 = pfVar2 + 3;
          iVar3 = iVar3 + 1;
        } while (*pfVar2 <= fVar9 && fVar9 != *pfVar2);
      }
      fVar6 = (fVar9 - *(float *)(iVar1 + iVar3 * 0xc)) /
              (*(float *)(iVar1 + 0xc + iVar3 * 0xc) - *(float *)(iVar1 + iVar3 * 0xc));
      fVar8 = (*(float *)(iVar1 + 0x10 + iVar3 * 0xc) - *(float *)(iVar1 + 4 + iVar3 * 0xc)) * fVar6
              + *(float *)(iVar1 + 4 + iVar3 * 0xc);
      fVar7 = (*(float *)(iVar1 + 0x14 + iVar3 * 0xc) - *(float *)(iVar1 + 8 + iVar3 * 0xc)) * fVar6
              + *(float *)(iVar1 + 8 + iVar3 * 0xc);
      fVar5 = fVar8 - fVar7;
      fVar7 = fVar7 + fVar8;
      fVar6 = param_4;
      if (param_4 <= fVar5) {
        fVar6 = fVar5;
      }
      fVar5 = param_5;
      if (fVar6 <= param_5) {
        fVar5 = fVar6;
      }
      fVar6 = param_4;
      if (param_4 <= fVar7) {
        fVar6 = fVar7;
      }
      param_2[iVar4 * 2] = fVar5;
      fVar5 = param_5;
      if (fVar6 <= param_5) {
        fVar5 = fVar6;
      }
      param_2[iVar4 * 2 + 1] = fVar5;
      iVar4 = iVar4 + 1;
    } while (iVar4 < param_3);
  }
  return;
}



/* FUNCTION 21714 ; VA 0x00a93720 ; FUN_00a93720 */

undefined4 __thiscall FUN_00a93720(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5a58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00a93240(auStack_1c,param_3);
  uStack_8 = 0;
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,uVar1);
  FUN_00617ad0();
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 21715 ; VA 0x00a93780 ; FUN_00a93780 */

/* WARNING: Type propagation algorithm not settling */

undefined4 FUN_00a93780(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  undefined **appuStack_ac [15];
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_60;
  undefined **appuStack_5c [18];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e585f;
  pvStack_10 = ExceptionList;
  appuStack_ac[0] = &PTR_018be314;
  uStack_8 = 0;
  uStack_14 = 2;
  appuStack_5c[0] = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_60 = 0x48;
  ExceptionList = &pvStack_10;
  FUN_00554f20(appuStack_ac + 1,0);
  uStack_8 = 2;
  *(undefined ***)(appuStack_ac[0][1] + (int)appuStack_ac) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(appuStack_ac[0][1] + (int)&stack0xffffff50) = appuStack_ac[0][1] + -0x50;
  FUN_0054ee60();
  appuStack_ac[1] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  uStack_70 = 0;
  uStack_6c = 4;
  uStack_8 = 3;
  iVar2 = (param_2[1] - *param_2) / 0xc;
  if (0 < iVar2) {
    iVar3 = 0;
    do {
      uVar1 = FUN_00a8e3b0(*(undefined4 *)(*param_2 + iVar3),&DAT_018c0cc8);
      FUN_00558890(uVar1);
      uVar1 = FUN_00a8e3b0(*(undefined4 *)(iVar3 + 4 + *param_2),&DAT_018c0cc8);
      FUN_00558890(uVar1);
      uVar1 = FUN_00a8e3b0(*(undefined4 *)(iVar3 + 8 + *param_2),&DAT_018c0cc8);
      FUN_00558890(uVar1);
      iVar3 = iVar3 + 0xc;
      iVar2 = iVar2 + -1;
    } while (iVar2 != 0);
  }
  FUN_0058c400(param_1);
  *(undefined ***)(appuStack_ac[0][1] + (int)appuStack_ac) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(appuStack_ac[0][1] + (int)&stack0xffffff50) = appuStack_ac[0][1] + -0x50;
  FUN_0056b950();
  *(undefined ***)(appuStack_ac[0][1] + (int)appuStack_ac) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)(appuStack_ac[0][1] + (int)&stack0xffffff50) = appuStack_ac[0][1] + -8;
  uStack_8 = 4;
  appuStack_5c[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_5c);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21716 ; VA 0x00a93960 ; FUN_00a93960 */

uint FUN_00a93960(undefined4 *param_1,char param_2)

{
  float *pfVar1;
  float fVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  float *pfVar6;
  double dVar7;
  undefined8 uVar8;
  uint uVar9;
  undefined auStack_1c [12];
  int iStack_10;
  uint uStack_c;
  uint uStack_8;
  
  iVar5 = param_1[1];
  pfVar6 = (float *)*param_1;
  uVar3 = (iVar5 - (int)pfVar6) / 0xc;
  if (uVar3 < 2) {
    if (param_2 != '\0') {
      FUN_016756b0(auStack_1c,"NumberSequence: requires at least 2 keypoints");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
  }
  else if (uVar3 < 0x15) {
    uStack_8 = 0;
    uVar8 = DAT_018c0da0;
    if (uVar3 != 0) {
      iVar4 = 0;
      do {
        if ((DAT_020c0b1c != '\0') && (DAT_01d66514 != '\0')) {
          uStack_c = *(uint *)(iVar4 + (int)pfVar6);
          uVar3 = FUN_01726720(&uStack_c);
          uVar8 = DAT_018c0da0;
          if ((short)uVar3 == 2) {
            if (param_2 != '\0') {
              FUN_016756b0(auStack_1c,"NumberSequence: time must be a valid number");
                    /* WARNING: Subroutine does not return */
              FUN_0170c2a8(auStack_1c,&DAT_01c17198);
            }
            goto LAB_00a93aec;
          }
        }
        iVar5 = param_1[1];
        pfVar6 = (float *)*param_1;
        uStack_c = (iVar5 - (int)pfVar6) / 0xc;
        uVar3 = uStack_c - 1;
        iStack_10 = iVar5;
        if ((uStack_8 < uVar3) &&
           (pfVar1 = (float *)(iVar4 + 0xc + (int)pfVar6),
           *pfVar1 <= *(float *)(iVar4 + (int)pfVar6) && *(float *)(iVar4 + (int)pfVar6) != *pfVar1)
           ) {
          if (param_2 != '\0') {
            FUN_016756b0(auStack_1c,"NumberSequence: all keypoints must be ordered by time");
                    /* WARNING: Subroutine does not return */
            FUN_0170c2a8(auStack_1c,&DAT_01c17198);
          }
          goto LAB_00a93aec;
        }
        fVar2 = *(float *)(iVar4 + 8 + (int)pfVar6);
        if (fVar2 < 0.0) {
          if (param_2 != '\0') {
            FUN_016756b0(auStack_1c,"NumberSequence: envelope must be non-negative");
                    /* WARNING: Subroutine does not return */
            FUN_0170c2a8(auStack_1c,&DAT_01c17198);
          }
          goto LAB_00a93aec;
        }
        dVar7 = (double)*(float *)(iVar4 + 4 + (int)pfVar6);
        if ((float)(double)CONCAT44((uint)((ulonglong)dVar7 >> 0x20) &
                                    (uint)((ulonglong)uVar8 >> 0x20),SUB84(dVar7,0) & (uint)uVar8) -
            fVar2 < 0.0) {
          if (param_2 != '\0') {
            FUN_016756b0(auStack_1c,"NumberSequence: envelope must not exceed the value");
                    /* WARNING: Subroutine does not return */
            FUN_0170c2a8(auStack_1c,&DAT_01c17198);
          }
          goto LAB_00a93aec;
        }
        uStack_8 = uStack_8 + 1;
        iVar4 = iVar4 + 0xc;
      } while (uStack_8 < uStack_c);
    }
    uVar9 = (uint)((ulonglong)uVar8 >> 0x20);
    if ((float)(double)CONCAT44((uint)((ulonglong)(double)*pfVar6 >> 0x20) & uVar9,
                                SUB84((double)*pfVar6,0) & (uint)uVar8) <= DAT_018fd178) {
      dVar7 = (double)(*(float *)(iVar5 + -0xc) - DAT_018ce2f8);
      if ((float)(double)CONCAT44((uint)((ulonglong)dVar7 >> 0x20) & uVar9,
                                  SUB84(dVar7,0) & (uint)uVar8) <= DAT_018fd178) {
        return CONCAT31((int3)(uVar3 >> 8),1);
      }
      if (param_2 != '\0') {
        FUN_016756b0(auStack_1c,"NumberSequence must end at time=1.0");
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_1c,&DAT_01c17198);
      }
    }
    else if (param_2 != '\0') {
      FUN_016756b0(auStack_1c,"NumberSequence must start at time=0.0");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
  }
  else if (param_2 != '\0') {
    FUN_016756b0(auStack_1c,"NumberSequence: max. number of keypoints exceeded.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
LAB_00a93aec:
  return uVar3 & 0xffffff00;
}



/* FUNCTION 21717 ; VA 0x00a93c00 ; FUN_00a93c00 */

void __thiscall FUN_00a93c00(int param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  int aiStack_4c [5];
  uint uStack_38;
  int aiStack_34 [5];
  uint uStack_20;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5ae7;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_1c,param_2);
  uStack_8 = 0;
  FUN_00a93780(aiStack_4c,auStack_1c);
  uStack_8._0_1_ = 2;
  FUN_00617ad0();
  FUN_0054ef60(aiStack_4c);
  uStack_8._0_1_ = 3;
  FUN_0087ccc0();
  iVar1 = FUN_01674e20(0x18);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (iVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_0054ef60(aiStack_34);
  }
  *(undefined4 *)(param_3 + 0x18) = uVar2;
  *(undefined4 *)(param_3 + 0x14) = 2;
  if (0xf < uStack_20) {
    uVar3 = uStack_20 + 1;
    iVar1 = aiStack_34[0];
    if (0xfff < uVar3) {
      iVar1 = *(int *)(aiStack_34[0] + -4);
      uVar3 = uStack_20 + 0x24;
      if (0x1f < (aiStack_34[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  if (0xf < uStack_38) {
    uVar3 = uStack_38 + 1;
    iVar1 = aiStack_4c[0];
    if (0xfff < uVar3) {
      iVar1 = *(int *)(aiStack_4c[0] + -4);
      uVar3 = uStack_38 + 0x24;
      if (0x1f < (aiStack_4c[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 21718 ; VA 0x00a93d20 ; FUN_00a93d20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00a93d20(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  void *pvVar4;
  undefined4 uVar5;
  
  uVar5 = FUN_00b00260();
  iVar3 = _tls_index;
  *param_1 = uVar5;
  param_1[1] = 0;
  uVar5 = param_2[1];
  uVar1 = param_2[2];
  uVar2 = param_2[3];
  param_1[2] = *param_2;
  param_1[3] = uVar5;
  param_1[4] = uVar1;
  param_1[5] = uVar2;
  uVar5 = param_2[5];
  uVar1 = param_2[6];
  uVar2 = param_2[7];
  param_1[6] = param_2[4];
  param_1[7] = uVar5;
  param_1[8] = uVar1;
  param_1[9] = uVar2;
  pvVar4 = ThreadLocalStoragePointer;
  uVar5 = param_2[9];
  uVar1 = param_2[10];
  uVar2 = param_2[0xb];
  param_1[10] = param_2[8];
  param_1[0xb] = uVar5;
  param_1[0xc] = uVar1;
  param_1[0xd] = uVar2;
  if (*(int *)(*(int *)((int)pvVar4 + iVar3 * 4) + 0x34) < DAT_01ead3d8) {
    FUN_016f3809(&DAT_01ead3d8);
    if (DAT_01ead3d8 == -1) {
      _DAT_01ead3cc = FUN_00619ef0;
      _DAT_01ead3d0 = FUN_00619ef0;
      DAT_01ead3d4 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead3d8);
    }
  }
  param_1[1] = &DAT_01ead3cc;
  return param_1;
}



/* FUNCTION 21719 ; VA 0x00a93dd0 ; FUN_00a93dd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00a93dd0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  void *pvVar4;
  undefined4 uVar5;
  
  uVar5 = FUN_0088d370();
  iVar3 = _tls_index;
  *param_1 = uVar5;
  param_1[1] = 0;
  uVar5 = param_2[1];
  uVar1 = param_2[2];
  uVar2 = param_2[3];
  param_1[2] = *param_2;
  param_1[3] = uVar5;
  param_1[4] = uVar1;
  param_1[5] = uVar2;
  pvVar4 = ThreadLocalStoragePointer;
  *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 4);
  if (*(int *)(*(int *)((int)pvVar4 + iVar3 * 4) + 0x34) < DAT_01ead458) {
    FUN_016f3809(&DAT_01ead458);
    if (DAT_01ead458 == -1) {
      _DAT_01ead44c = FUN_00619f80;
      _DAT_01ead450 = FUN_00619f80;
      DAT_01ead454 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead458);
    }
  }
  param_1[1] = &DAT_01ead44c;
  return param_1;
}



/* FUNCTION 21720 ; VA 0x00a93e70 ; FUN_00a93e70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00a93e70(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  
  uVar4 = FUN_00a73110();
  *param_1 = uVar4;
  param_1[1] = 0;
  iVar3 = _tls_index;
  uVar4 = param_2[1];
  uVar1 = param_2[2];
  uVar2 = param_2[3];
  param_1[2] = *param_2;
  param_1[3] = uVar4;
  param_1[4] = uVar1;
  param_1[5] = uVar2;
  uVar4 = param_2[5];
  uVar1 = param_2[6];
  uVar2 = param_2[7];
  param_1[6] = param_2[4];
  param_1[7] = uVar4;
  param_1[8] = uVar1;
  param_1[9] = uVar2;
  uVar4 = param_2[9];
  uVar1 = param_2[10];
  uVar2 = param_2[0xb];
  param_1[10] = param_2[8];
  param_1[0xb] = uVar4;
  param_1[0xc] = uVar1;
  param_1[0xd] = uVar2;
  *(undefined8 *)(param_1 + 0xe) = *(undefined8 *)(param_2 + 0xc);
  param_1[0x10] = param_2[0xe];
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar3 * 4) + 0x34) < DAT_01ead328) {
    FUN_016f3809(&DAT_01ead328);
    if (DAT_01ead328 == -1) {
      _DAT_01ead31c = FUN_00619fd0;
      _DAT_01ead320 = FUN_00619fd0;
      DAT_01ead324 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead328);
    }
  }
  param_1[1] = &DAT_01ead31c;
  return param_1;
}



/* FUNCTION 21721 ; VA 0x00a93f30 ; FUN_00a93f30 */

int * __thiscall FUN_00a93f30(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00a9e890();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 21722 ; VA 0x00a93f80 ; FUN_00a93f80 */

int * __thiscall FUN_00a93f80(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00a9e900();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 21723 ; VA 0x00a93fd0 ; FUN_00a93fd0 */

undefined * FUN_00a93fd0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5b0c;
  pvStack_10 = ExceptionList;
  if (DAT_01eeaebc == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeb0c8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eeb0c8);
      if (DAT_01eeb0c8 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00b63e30();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"WorldRoot",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_0188ae80);
        FUN_016f37bf(&DAT_01eeb0c8);
      }
    }
    DAT_01eeaebc = &DAT_01eeaec0;
  }
  ExceptionList = pvStack_10;
  return DAT_01eeaebc;
}



/* FUNCTION 21724 ; VA 0x00a940b0 ; FUN_00a940b0 */

int __thiscall FUN_00a940b0(int *param_1,int param_2,undefined4 param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5b20;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  iVar2 = (param_1[1] - iVar5) / 0xd0;
  if (iVar2 == 0x13b13b1) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar3 = (param_1[2] - iVar5) / 0xd0;
  uVar6 = uVar1;
  if ((uVar3 <= 0x13b13b1 - (uVar3 >> 1)) && (uVar6 = (uVar3 >> 1) + uVar3, uVar6 < uVar1)) {
    uVar6 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00578090(uVar6);
  uStack_8 = 0;
  iVar5 = ((param_2 - iVar5) / 0xd0) * 0xd0;
  FUN_00912980(param_3);
  if (param_2 == param_1[1]) {
    FUN_005cb790(*param_1,param_1[1],iVar4);
  }
  else {
    FUN_005cb700(*param_1,param_2,iVar4);
    FUN_005cb700(param_2,param_1[1],iVar5 + iVar4 + 0xd0);
  }
  uStack_8 = 0xffffffff;
  FUN_005cb2e0(iVar4,iVar2 + 1,uVar6);
  ExceptionList = pvStack_10;
  return *param_1 + iVar5;
}



/* FUNCTION 21725 ; VA 0x00a941ee ; Catch_All@00a941ee */

void Catch_All_00a941ee(void)

{
  int unaff_EBP;
  
  FUN_005762e0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_0057d370(*(undefined4 *)(unaff_EBP + -0x2c),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 21726 ; VA 0x00a94220 ; FUN_00a94220 */

int __thiscall FUN_00a94220(int *param_1,int param_2,undefined4 param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5b30;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  iVar2 = (param_1[1] - iVar5) / 0xd0;
  if (iVar2 == 0x13b13b1) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar3 = (param_1[2] - iVar5) / 0xd0;
  uVar7 = uVar1;
  if ((uVar3 <= 0x13b13b1 - (uVar3 >> 1)) && (uVar7 = (uVar3 >> 1) + uVar3, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00578090(uVar7);
  uStack_8 = 0;
  iVar5 = ((param_2 - iVar5) / 0xd0) * 0xd0;
  iVar6 = iVar5 + iVar4;
  FUN_00a94bd0(param_1,iVar6,param_3);
  if (param_2 == param_1[1]) {
    FUN_005cb790(*param_1,param_1[1],iVar4);
  }
  else {
    FUN_005cb700(*param_1,param_2,iVar4);
    FUN_005cb700(param_2,param_1[1],iVar6 + 0xd0);
  }
  uStack_8 = 0xffffffff;
  FUN_005cb2e0(iVar4,iVar2 + 1,uVar7);
  ExceptionList = pvStack_10;
  return *param_1 + iVar5;
}



/* FUNCTION 21727 ; VA 0x00a94361 ; Catch_All@00a94361 */

void Catch_All_00a94361(void)

{
  int unaff_EBP;
  
  FUN_005762e0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_0057d370(*(undefined4 *)(unaff_EBP + -0x2c),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 21728 ; VA 0x00a94390 ; FUN_00a94390 */

int __thiscall FUN_00a94390(int *param_1,int param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e5b40;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  iVar2 = (param_1[1] - iVar5) / 0xd0;
  if (iVar2 == 0x13b13b1) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar3 = (param_1[2] - iVar5) / 0xd0;
  uVar8 = uVar1;
  if ((uVar3 <= 0x13b13b1 - (uVar3 >> 1)) && (uVar8 = (uVar3 >> 1) + uVar3, uVar8 < uVar1)) {
    uVar8 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00578090(uVar8);
  uStack_8 = 0;
  iVar5 = ((param_2 - iVar5) / 0xd0) * 0xd0;
  uVar6 = FUN_0088cdc0();
  puVar7 = (undefined4 *)(iVar5 + iVar4);
  *puVar7 = uVar6;
  puVar7[1] = 0;
  puVar7[2] = 0;
  puVar7[3] = 0;
  puVar7[2] = *param_3;
  puVar7[3] = param_3[1];
  *param_3 = 0;
  param_3[1] = 0;
  uVar6 = FUN_006309e0();
  *(undefined4 *)(iVar5 + iVar4 + 4) = uVar6;
  if (param_2 == param_1[1]) {
    FUN_005cb790(*param_1,param_1[1],iVar4);
  }
  else {
    FUN_005cb700(*param_1,param_2,iVar4);
    FUN_005cb700(param_2,param_1[1],iVar5 + 0xd0 + iVar4);
  }
  uStack_8 = 0xffffffff;
  FUN_005cb2e0(iVar4,iVar2 + 1,uVar8);
  ExceptionList = pvStack_10;
  return *param_1 + iVar5;
}



/* FUNCTION 21729 ; VA 0x00a94509 ; Catch_All@00a94509 */

void Catch_All_00a94509(void)

{
  int unaff_EBP;
  
  FUN_005762e0(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x1c));
  FUN_0057d370(*(undefined4 *)(unaff_EBP + -0x2c),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 21730 ; VA 0x00a94540 ; FUN_00a94540 */

int __thiscall FUN_00a94540(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5b50;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Glue*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21731 ; VA 0x00a94612 ; Catch_All@00a94612 */

void Catch_All_00a94612(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 21732 ; VA 0x00a94630 ; FUN_00a94630 */

int __thiscall FUN_00a94630(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5b60;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Rotate*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21733 ; VA 0x00a94702 ; Catch_All@00a94702 */

void Catch_All_00a94702(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 21734 ; VA 0x00a94720 ; FUN_00a94720 */

int __thiscall FUN_00a94720(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5b70;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::RotateP*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21735 ; VA 0x00a947f2 ; Catch_All@00a947f2 */

void Catch_All_00a947f2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 21736 ; VA 0x00a94810 ; FUN_00a94810 */

int __thiscall FUN_00a94810(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5b80;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::RotateV*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21737 ; VA 0x00a948e2 ; Catch_All@00a948e2 */

void Catch_All_00a948e2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 21738 ; VA 0x00a94900 ; FUN_00a94900 */

int __thiscall FUN_00a94900(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5b90;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Snap*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21739 ; VA 0x00a949d2 ; Catch_All@00a949d2 */

void Catch_All_00a949d2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 21740 ; VA 0x00a949f0 ; FUN_00a949f0 */

int __thiscall FUN_00a949f0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5ba0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Team*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21741 ; VA 0x00a94ac2 ; Catch_All@00a94ac2 */

void Catch_All_00a94ac2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 21742 ; VA 0x00a94ae0 ; FUN_00a94ae0 */

int __thiscall FUN_00a94ae0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5bb0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Weld*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 21743 ; VA 0x00a94bb2 ; Catch_All@00a94bb2 */

void Catch_All_00a94bb2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 21744 ; VA 0x00a94bd0 ; FUN_00a94bd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00a94bd0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  
  uVar2 = thunk_FUN_00896e70();
  iVar1 = _tls_index;
  *param_2 = uVar2;
  param_2[1] = 0;
  param_2[2] = *param_3;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar1 * 4) + 0x34) < DAT_01edf534) {
    FUN_016f3809(&DAT_01edf534);
    if (DAT_01edf534 == -1) {
      _DAT_01edf528 = FUN_005c65e0;
      _DAT_01edf52c = FUN_005c65e0;
      DAT_01edf530 = _guard_check_icall;
      FUN_016f37bf(&DAT_01edf534);
    }
  }
  param_2[1] = &DAT_01edf528;
  return;
}



/* FUNCTION 21745 ; VA 0x00a94c60 ; FUN_00a94c60 */

undefined4 * FUN_00a94c60(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5bf3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c390f0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xc4);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c3a630();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a94540(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21746 ; VA 0x00a94d20 ; FUN_00a94d20 */

undefined4 * FUN_00a94d20(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5c33;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c397b0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x94);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c3aaa0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a94630(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21747 ; VA 0x00a94de0 ; FUN_00a94de0 */

undefined4 * FUN_00a94de0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5c73;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c398b0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x94);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c3ab50();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a94720(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21748 ; VA 0x00a94ea0 ; FUN_00a94ea0 */

undefined4 * FUN_00a94ea0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5cb3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c399b0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x94);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c3ac50();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a94810(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 21749 ; VA 0x00a94f60 ; FUN_00a94f60 */

undefined4 * FUN_00a94f60(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e5cf3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c39ab0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x94);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c3ad50();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00a94900(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}


