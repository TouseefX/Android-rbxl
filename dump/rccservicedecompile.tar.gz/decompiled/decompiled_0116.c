/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 29000 ; VA 0x00c6a4d0 ; FUN_00c6a4d0 */

uint __thiscall FUN_00c6a4d0(int param_1,int *param_2)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  float *pfVar7;
  float fVar8;
  int *piVar9;
  undefined auStack_34 [16];
  float fStack_24;
  int *piStack_20;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9558;
  pvStack_10 = ExceptionList;
  iStack_14 = param_1 + -0x54;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  uVar5 = FUN_008accc0(iStack_14);
  if (uVar5 == 0) {
    ExceptionList = pvStack_10;
    return 0;
  }
  piVar9 = *(int **)(uVar5 + 0x9c);
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar9[1] = piVar9[1] + 1;
    UNLOCK();
    piVar9 = *(int **)(uVar5 + 0x9c);
  }
  fVar8 = *(float *)(uVar5 + 0x98);
  uStack_8 = 0;
  fStack_24 = fVar8;
  piStack_20 = piVar9;
  uStack_1c = uVar5;
  if (fVar8 != 0.0) {
    iVar4 = *(int *)((int)fVar8 + 0xc);
    iVar6 = FUN_00aff8c0();
    uVar5 = (uint)*(ushort *)(iVar6 + 0x1da);
    if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <= uVar5)
    goto LAB_00c6a55b;
  }
  fVar8 = 0.0;
LAB_00c6a55b:
  uStack_8 = 0xffffffff;
  if (piVar9 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar9 + 1);
    uVar3 = *puVar1;
    uVar5 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar5 = (**(code **)*piVar9)();
      LOCK();
      piVar2 = piVar9 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar5 = (**(code **)(*piVar9 + 4))();
      }
    }
  }
  if (((fVar8 != 0.0) &&
      (uVar5 = FUN_00c69ba0(), iVar4 = iStack_18, piVar9 = param_2, (char)uVar5 != '\0')) &&
     (*(char *)(iStack_18 + 0x108) != '\0')) {
    pfVar7 = (float *)(**(code **)(*param_2 + 0x30))(auStack_34);
    piStack_20 = (int *)(pfVar7[3] - pfVar7[1]);
    fStack_24 = pfVar7[2] - *pfVar7;
    param_2 = *(int **)(uStack_1c + 0xa0);
    uVar5 = FUN_00d5b320(piVar9,fVar8,&param_2,&fStack_24,iVar4 + 0x1a4,iVar4 + 0x1d4);
    if ((char)uVar5 != '\0') {
      uVar5 = FUN_00d68920(piVar9);
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 29001 ; VA 0x00c6a620 ; FUN_00c6a620 */

void __thiscall FUN_00c6a620(int param_1,int param_2)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x68) != param_2) {
    *(int *)(param_1 + 0x68) = param_2;
    iVar1 = FUN_00b8e990();
    if (iVar1 != 0) {
      FUN_00b5cfe0();
    }
    FUN_008a4940(&DAT_02137c54);
  }
  return;
}



/* FUNCTION 29002 ; VA 0x00c6a660 ; FUN_00c6a660 */

void __thiscall FUN_00c6a660(int param_1,char param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined auStack_24 [16];
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  if (*(char *)(param_1 + 0x259) != param_2) {
    *(char *)(param_1 + 0x259) = param_2;
    iVar1 = FUN_006ebc30(param_1);
    if (iVar1 != 0) {
      if (*(char *)(param_1 + 0x259) == '\0') {
        puVar2 = (undefined4 *)FUN_00c69a30(auStack_24);
      }
      else {
        uStack_14 = *(undefined4 *)(iVar1 + 0xe8);
        uStack_10 = *(undefined4 *)(iVar1 + 0xec);
        uStack_c = *(undefined4 *)(iVar1 + 0xf0);
        uStack_8 = *(undefined4 *)(iVar1 + 0xf4);
        puVar2 = &uStack_14;
      }
      FUN_00d69a10(puVar2);
    }
    FUN_008a4940(&DAT_02137c8c);
  }
  return;
}



/* FUNCTION 29003 ; VA 0x00c6a6d0 ; FUN_00c6a6d0 */

void __thiscall FUN_00c6a6d0(int param_1,char param_2)

{
  int iVar1;
  
  if (*(char *)(param_1 + 0x25a) != param_2) {
    *(char *)(param_1 + 0x25a) = param_2;
    FUN_008a4940(&DAT_02137cc4);
    if (DAT_01d6889c == '\0') {
      FUN_008a4940(&DAT_02137c54);
    }
    else {
      iVar1 = FUN_00b8e990();
      if (iVar1 != 0) {
        FUN_00b5cfe0();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 29004 ; VA 0x00c6a720 ; FUN_00c6a720 */

undefined __fastcall FUN_00c6a720(int param_1)

{
  if ((*(char *)(param_1 + 0x204) != '\0') && (*(char *)(param_1 + 0x108) != '\0')) {
    return 1;
  }
  return 0;
}



/* FUNCTION 29005 ; VA 0x00c6a740 ; FUN_00c6a740 */

uint __thiscall FUN_00c6a740(int param_1,int *param_2)

{
  uint *puVar1;
  uint uVar2;
  byte bVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  float *pfVar8;
  uint uVar9;
  int *piVar10;
  float fVar11;
  double dVar12;
  undefined auStack_c0 [36];
  undefined auStack_9c [36];
  undefined auStack_78 [12];
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  undefined auStack_5c [36];
  float fStack_38;
  float fStack_34;
  float fStack_30;
  undefined auStack_2c [4];
  uint uStack_28;
  int *piStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbe88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar5 = (**(code **)*param_2)();
  cVar4 = FUN_00c69ba0();
  if (cVar4 == '\0') {
    if ((*(char *)(param_2 + 5) == '\0') || (iVar5 == 0)) {
      FUN_01159c60();
      bVar3 = *(byte *)(param_1 + 0x25a);
      *(byte *)(*(int *)(param_1 + 0x178) + 0x51) = bVar3;
      ExceptionList = pvStack_10;
      return (uint)bVar3;
    }
    (**(code **)(*param_2 + 0x30))(&fStack_6c);
    FUN_00d226b0(auStack_5c);
    fVar11 = *(float *)(iVar5 + 0x1a8) * DAT_018df580;
    dVar12 = DAT_0196dea0;
    FUN_01728120();
    fStack_14 = (float)dVar12 * fVar11 + (float)dVar12 * fVar11;
    pfVar8 = (float *)FUN_011612d0(&fStack_20,2);
    fStack_38 = fStack_38 - *pfVar8 * fVar11;
    fStack_34 = fStack_34 - pfVar8[1] * fVar11;
    fStack_30 = fStack_30 - pfVar8[2] * fVar11;
    FUN_011612d0(&fStack_20,0);
    fStack_38 = fStack_38 - fStack_20 * fStack_14 * DAT_018ce2f4;
    fStack_34 = fStack_34 - fStack_1c * fStack_14 * DAT_018ce2f4;
    fStack_30 = fStack_30 - fStack_18 * fStack_14 * DAT_018ce2f4;
    FUN_011612d0(&fStack_20,1);
    fStack_38 = fStack_38 + fStack_20 * fStack_14 * DAT_018ce2f4;
    fStack_34 = fStack_34 + fStack_1c * fStack_14 * DAT_018ce2f4;
    fStack_30 = fStack_30 + fStack_18 * fStack_14 * DAT_018ce2f4;
    FUN_01160a40(fStack_14 / (fStack_64 - fStack_6c),0,0,0,fStack_14 / (fStack_60 - fStack_68),0,0,0
                 ,0x3f800000);
    FUN_01160ec0(auStack_c0);
    FUN_01159c70(auStack_5c);
    goto LAB_00c6aaf5;
  }
  iVar5 = FUN_008accc0(param_1);
  if (iVar5 == 0) {
    ExceptionList = pvStack_10;
    return 0;
  }
  piVar10 = *(int **)(iVar5 + 0x9c);
  if (piVar10 != (int *)0x0) {
    LOCK();
    piVar10[1] = piVar10[1] + 1;
    UNLOCK();
    piVar10 = *(int **)(iVar5 + 0x9c);
  }
  uVar7 = *(uint *)(iVar5 + 0x98);
  uStack_8 = 0;
  uStack_28 = uVar7;
  piStack_24 = piVar10;
  if (uVar7 == 0) {
LAB_00c6a7e1:
    uVar9 = 0;
  }
  else {
    iVar5 = *(int *)(uVar7 + 0xc);
    iVar6 = FUN_00aff8c0();
    uVar7 = (uint)*(ushort *)(iVar6 + 0x1da);
    uVar9 = uStack_28;
    if (uVar7 < (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))
    goto LAB_00c6a7e1;
  }
  uStack_8 = 0xffffffff;
  if (piVar10 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar10 + 1);
    uVar2 = *puVar1;
    uVar7 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      (**(code **)*piVar10)();
      LOCK();
      puVar1 = (uint *)(piVar10 + 2);
      uVar2 = *puVar1;
      uVar7 = *puVar1;
      *puVar1 = uVar2 - 1;
      UNLOCK();
      if (uVar2 - 1 == 0) {
        uVar7 = (**(code **)(*piVar10 + 4))();
      }
    }
  }
  if (uVar9 == 0) {
    ExceptionList = pvStack_10;
    return uVar7;
  }
  FUN_0071f260(auStack_9c,param_1 + 0x228);
  pfVar8 = (float *)FUN_011612d0(auStack_2c,2);
  fVar11 = *pfVar8;
  fStack_14 = pfVar8[1];
  piStack_24 = (int *)pfVar8[2];
  dVar12 = (double)(fVar11 * fVar11 + fStack_14 * fStack_14 + (float)piStack_24 * (float)piStack_24)
  ;
  FUN_017267a0();
  fStack_18 = DAT_018ce2f8 / (float)dVar12;
  fStack_20 = fVar11 * fStack_18;
  fStack_1c = fStack_14 * fStack_18;
  fStack_18 = (float)piStack_24 * fStack_18;
  FUN_01159cd0(auStack_9c,auStack_78,&fStack_20);
LAB_00c6aaf5:
  *(undefined4 *)(*(int *)(param_1 + 0x178) + 0x4c) = 0;
  uVar7 = *(uint *)(param_1 + 0x178);
  *(undefined *)(uVar7 + 0x50) = 1;
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 29006 ; VA 0x00c6ab50 ; FUN_00c6ab50 */

int * __thiscall
FUN_00c6ab50(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d293;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c6ac40();
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar3,uVar4,param_2,param_3,param_5,param_6,param_7,param_8,param_9,param_9,0);
  param_1[0xd] = 0;
  uStack_8 = 3;
  *param_1 = (int)RBX::Reflection::BoundProp<int,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<int,1>::BoundPropGetSet<class_RBX::Handles>::vftable;
    puVar5[1] = param_1;
    puVar5[2] = param_4;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar5;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29007 ; VA 0x00c6ac40 ; FUN_00c6ac40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c6ac40(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d2c0;
  pvStack_10 = ExceptionList;
  if (DAT_01efe834 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efea48) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efea48);
      if (DAT_01efea48 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00ea4740();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Handles",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01efea40 = RBX::Creator<class_RBX::Handles>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efe838,&DAT_01efea40);
        FUN_016f3654(FUN_01895fc0);
        FUN_016f37bf(&DAT_01efea48);
      }
    }
    DAT_01efe834 = &DAT_01efe838;
  }
  ExceptionList = pvStack_10;
  return DAT_01efe834;
}



/* FUNCTION 29008 ; VA 0x00c6ad40 ; FUN_00c6ad40 */

void __thiscall FUN_00c6ad40(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180d2d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<struct_RBX::HandlesBase::MouseDownCaptureInfo>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29009 ; VA 0x00c6adae ; Catch_All@00c6adae */

void Catch_All_00c6adae(void)

{
  int unaff_EBP;
  
  FUN_01674ea0(*(undefined4 *)(unaff_EBP + 8),0x40);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 29010 ; VA 0x00c6add0 ; FUN_00c6add0 */

int __thiscall FUN_00c6add0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180d2e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Handles*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29011 ; VA 0x00c6aea2 ; Catch_All@00c6aea2 */

void Catch_All_00c6aea2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 29012 ; VA 0x00c6aec0 ; FUN_00c6aec0 */

undefined4 * FUN_00c6aec0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180d323;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c6ac40();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x16c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c6b0e0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c6add0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29013 ; VA 0x00c6af80 ; FUN_00c6af80 */

undefined4 * __thiscall
FUN_00c6af80(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 uVar1;
  undefined auStack_110 [216];
  undefined8 uStack_38;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_0180d351;
  pvStack_1c = ExceptionList;
  uStack_38 = param_6;
  ExceptionList = &pvStack_1c;
  puStack_30 = param_1;
  uVar1 = FUN_00c6ac40();
  FUN_009cb970(uVar1,param_3,param_5,uStack_38,param_7);
  param_1[0xd] = param_2;
  iStack_14 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::Handles,void___cdecl(enum_RBX::NormalId),class_rbx::remote_signal<void___cdecl(enum_RBX::NormalId)>,class_rbx::remote_signal<void___cdecl(enum_RBX::NormalId)>_RBX::Handles::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  thunk_FUN_00890320();
  FUN_00888740();
  iStack_14._0_1_ = 1;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687810(auStack_110,&uStack_38,puStack_30);
  iStack_14._0_1_ = 2;
  if (param_1 + 10 != &uStack_2c) {
    FUN_0068a760();
    param_1[10] = uStack_2c;
    param_1[0xb] = uStack_28;
    param_1[0xc] = uStack_24;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
  }
  iStack_14._0_1_ = 3;
  FUN_0068a760();
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_016f32d1(auStack_110,0xd8,1,FUN_00688b10);
  param_1[0xe] = param_9;
  param_1[0xf] = param_8;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::Handles,void___cdecl(enum_RBX::NormalId),class_rbx::remote_signal<void___cdecl(enum_RBX::NormalId)>,class_rbx::remote_signal<void___cdecl(enum_RBX::NormalId)>_RBX::Handles::*>
             ::vftable;
  ExceptionList = pvStack_1c;
  return param_1;
}



/* FUNCTION 29014 ; VA 0x00c6b0e0 ; FUN_00c6b0e0 */

undefined4 * __fastcall FUN_00c6b0e0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d3fc;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00ea4820("Handles");
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::Handles,class_RBX::HandlesBase>::vftable;
  param_1[0x15] = RBX::DescribedCreatable<class_RBX::Handles,class_RBX::HandlesBase>::vftable;
  uVar1 = FUN_00c6ac40();
  param_1[3] = uVar1;
  *param_1 = RBX::Handles::vftable;
  param_1[0x15] = RBX::Handles::vftable;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x33] = &DAT_02137ee8;
  param_1[0x34] = 0;
  param_1[0x35] = &DAT_02137da8;
  param_1[0x36] = param_1 + 0x28;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x32] = RBX::EventReplicator<class_RBX::Handles,void___cdecl(enum_RBX::NormalId)>::vftable
  ;
  param_1[0x39] = 0;
  param_1[0x3b] = &DAT_02137f20;
  param_1[0x3c] = 0;
  param_1[0x3d] = &DAT_02137de8;
  param_1[0x3e] = param_1 + 0x2a;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  param_1[0x3a] = RBX::EventReplicator<class_RBX::Handles,void___cdecl(enum_RBX::NormalId)>::vftable
  ;
  param_1[0x41] = 0;
  param_1[0x43] = &DAT_02137f58;
  param_1[0x44] = 0;
  param_1[0x45] = &DAT_02137e28;
  param_1[0x46] = param_1 + 0x2c;
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  param_1[0x42] =
       RBX::EventReplicator<class_RBX::Handles,void___cdecl(enum_RBX::NormalId,float)>::vftable;
  param_1[0x49] = 0;
  param_1[0x4b] = &DAT_02137f90;
  param_1[0x4c] = 0;
  param_1[0x4d] = &DAT_02137e68;
  param_1[0x4e] = param_1 + 0x2e;
  param_1[0x4f] = 0;
  param_1[0x50] = 0;
  param_1[0x4a] = RBX::EventReplicator<class_RBX::Handles,void___cdecl(enum_RBX::NormalId)>::vftable
  ;
  param_1[0x51] = 0;
  param_1[0x53] = &DAT_02137fc8;
  param_1[0x54] = 0;
  param_1[0x55] = &DAT_02137ea8;
  param_1[0x56] = param_1 + 0x30;
  param_1[0x57] = 0;
  param_1[0x58] = 0;
  param_1[0x52] = RBX::EventReplicator<class_RBX::Handles,void___cdecl(enum_RBX::NormalId)>::vftable
  ;
  uStack_8 = 0xb;
  param_1[0x59] = 0;
  FUN_0054d840(0x3f);
  param_1[0x34] = param_1;
  param_1[0x3c] = param_1;
  param_1[0x44] = param_1;
  param_1[0x4c] = param_1;
  param_1[0x54] = param_1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29015 ; VA 0x00c6b390 ; FUN_00c6b390 */

void __fastcall FUN_00c6b390(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Handles>::vftable;
  uVar1 = FUN_00c6ac40(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29016 ; VA 0x00c6b3d0 ; FUN_00c6b3d0 */

void FUN_00c6b3d0(void)

{
  FUN_0115a710();
  FUN_0089b230();
  return;
}



/* FUNCTION 29017 ; VA 0x00c6b3f0 ; thunk_FUN_00c6b560 */

void __fastcall thunk_FUN_00c6b560(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x94);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x88);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_0115a710();
  FUN_0089b230();
  return;
}



/* FUNCTION 29018 ; VA 0x00c6b400 ; thunk_FUN_00c6b420 */

void __fastcall thunk_FUN_00c6b420(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::EventReplicatorBase<class_RBX::Handles,void___cdecl(enum_RBX::NormalId)>::vftable;
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  iVar3 = param_1[6];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  iVar3 = param_1[5];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29019 ; VA 0x00c6b410 ; thunk_FUN_00c6b4c0 */

void __fastcall thunk_FUN_00c6b4c0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::EventReplicatorBase<class_RBX::Handles,void___cdecl(enum_RBX::NormalId,float)>::
             vftable;
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  iVar3 = param_1[6];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  iVar3 = param_1[5];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29020 ; VA 0x00c6b420 ; FUN_00c6b420 */

void __fastcall FUN_00c6b420(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::EventReplicatorBase<class_RBX::Handles,void___cdecl(enum_RBX::NormalId)>::vftable;
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  iVar3 = param_1[6];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  iVar3 = param_1[5];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29021 ; VA 0x00c6b4c0 ; FUN_00c6b4c0 */

void __fastcall FUN_00c6b4c0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::EventReplicatorBase<class_RBX::Handles,void___cdecl(enum_RBX::NormalId,float)>::
             vftable;
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  iVar3 = param_1[6];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  iVar3 = param_1[5];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29022 ; VA 0x00c6b560 ; FUN_00c6b560 */

void __fastcall FUN_00c6b560(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x94);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0x88);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_0115a710();
  FUN_0089b230();
  return;
}



/* FUNCTION 29023 ; VA 0x00c6b5c0 ; FUN_00c6b5c0 */

void __fastcall FUN_00c6b5c0(int param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0x88);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_0115a710();
  FUN_0089b230();
  return;
}



/* FUNCTION 29024 ; VA 0x00c6b5f0 ; FUN_00c6b5f0 */

/* WARNING: Removing unreachable block (ram,0x00c6b64a) */
/* WARNING: Removing unreachable block (ram,0x00c6b65a) */
/* WARNING: Removing unreachable block (ram,0x00c6b660) */

void __fastcall FUN_00c6b5f0(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d420;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29025 ; VA 0x00c6b6a4 ; Catch@00c6b6a4 */

undefined * Catch_00c6b6a4(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_00c6b6b5;
}



/* FUNCTION 29026 ; VA 0x00c6b6d0 ; FUN_00c6b6d0 */

undefined4 __thiscall FUN_00c6b6d0(undefined4 param_1,byte param_2)

{
  FUN_00c6b560();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x9c);
  }
  return param_1;
}



/* FUNCTION 29027 ; VA 0x00c6b700 ; FUN_00c6b700 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c6b700(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Handles::VisualStyle>::vftable;
  _DAT_01efea50 = _DAT_01efea50 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 29028 ; VA 0x00c6b730 ; FUN_00c6b730 */

undefined4 * __thiscall FUN_00c6b730(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Handles::VisualStyle>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 29029 ; VA 0x00c6b760 ; FUN_00c6b760 */

undefined4 * __thiscall FUN_00c6b760(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Handles::VisualStyle>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 29030 ; VA 0x00c6b790 ; FUN_00c6b790 */

undefined4 __thiscall FUN_00c6b790(undefined4 param_1,byte param_2)

{
  FUN_00c6b420();
  FUN_00c6b420();
  FUN_00c6b4c0();
  FUN_00c6b420();
  FUN_00c6b420();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_00c6b560();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x16c);
  }
  return param_1;
}



/* FUNCTION 29031 ; VA 0x00c6b860 ; FUN_00c6b860 */

void __fastcall FUN_00c6b860(int param_1)

{
  FUN_01674ea0(*(undefined4 *)(param_1 + 0xc),0x40);
  return;
}



/* FUNCTION 29032 ; VA 0x00c6b870 ; thunk_FUN_00c6cea0 */

undefined * thunk_FUN_00c6cea0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d61c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efeabc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efeabc);
    if (DAT_01efeabc == -1) {
      uStack_8 = 0;
      FUN_00ff4ff0();
      FUN_016f3654(&LAB_01895f60);
      FUN_016f37bf(&DAT_01efeabc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efea58;
}



/* FUNCTION 29033 ; VA 0x00c6b880 ; FUN_00c6b880 */

undefined4 * __thiscall
FUN_00c6b880(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180d4f1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c6bf30;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29034 ; VA 0x00c6ba30 ; FUN_00c6ba30 */

undefined4 * __thiscall
FUN_00c6ba30(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180d531;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c6c030;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29035 ; VA 0x00c6bbe0 ; FUN_00c6bbe0 */

void __fastcall FUN_00c6bbe0(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d561;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 8) == 0) {
    iVar3 = 0;
  }
  else {
    iVar3 = *(int *)(*(int *)(param_1 + 0xc) + 0x34) + *(int *)(param_1 + 8);
  }
  ExceptionList = &pvStack_10;
  FUN_006eccd0();
  uStack_8 = 0;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 1;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_006d7a70;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = iVar3;
    puVar5[6] = FUN_00c6cc90;
    puVar5[7] = param_1;
  }
  FUN_016797d0(puVar5);
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  FUN_01675290(uVar4);
  iVar3 = *(int *)(param_1 + 0x18);
  *(undefined4 **)(param_1 + 0x18) = puVar5;
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29036 ; VA 0x00c6bd00 ; FUN_00c6bd00 */

void __fastcall FUN_00c6bd00(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d561;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 8) == 0) {
    iVar3 = 0;
  }
  else {
    iVar3 = *(int *)(*(int *)(param_1 + 0xc) + 0x34) + *(int *)(param_1 + 8);
  }
  ExceptionList = &pvStack_10;
  FUN_006eccd0();
  uStack_8 = 0;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 1;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00c6c170;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = iVar3;
    puVar5[6] = FUN_00c6cd80;
    puVar5[7] = param_1;
  }
  FUN_016797d0(puVar5);
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  FUN_01675290(uVar4);
  iVar3 = *(int *)(param_1 + 0x18);
  *(undefined4 **)(param_1 + 0x18) = puVar5;
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29037 ; VA 0x00c6be20 ; FUN_00c6be20 */

void FUN_00c6be20(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00c6cea0();
    *param_2 = uVar3;
    iVar4 = FUN_00c6cf30();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 29038 ; VA 0x00c6be80 ; FUN_00c6be80 */

void FUN_00c6be80(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c6cea0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29039 ; VA 0x00c6bec0 ; FUN_00c6bec0 */

undefined4 * FUN_00c6bec0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c6aec0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 29040 ; VA 0x00c6bf30 ; FUN_00c6bf30 */

void FUN_00c6bf30(int param_1,undefined4 param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbcf9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_f0 = thunk_FUN_00890320();
  uStack_ec = 0;
  uStack_e8 = param_2;
  uStack_ec = FUN_00890440();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,piVar1);
  iStack_8._0_1_ = 2;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 3;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  iStack_8 = 4;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29041 ; VA 0x00c6c030 ; FUN_00c6c030 */

void FUN_00c6c030(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8524;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = thunk_FUN_00890320();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1bc = FUN_00890440();
  iStack_8._0_1_ = 1;
  uStack_f0 = FUN_0088c960();
  uStack_ec = 0;
  uStack_e8 = param_3;
  uStack_ec = FUN_00630820();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  iStack_8._0_1_ = 3;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 4;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  iStack_8 = 5;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29042 ; VA 0x00c6c160 ; FUN_00c6c160 */

void FUN_00c6c160(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00c6c16d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(param_1 + 0x18))();
  return;
}



/* FUNCTION 29043 ; VA 0x00c6c170 ; FUN_00c6c170 */

void FUN_00c6c170(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(param_1 + 0x18))(param_2,param_3);
  return;
}



/* FUNCTION 29044 ; VA 0x00c6c190 ; FUN_00c6c190 */

void FUN_00c6c190(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar2 = thunk_FUN_00890320();
  if (iVar1 == iVar2) {
    piVar3 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_005e6780(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29045 ; VA 0x00c6c1e0 ; FUN_00c6c1e0 */

void FUN_00c6c1e0(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  
  iVar2 = *param_2;
  iVar5 = *(int *)(iVar2 + 0xd0);
  iVar3 = FUN_0088c960();
  if (iVar5 == iVar3) {
    puVar4 = (undefined4 *)(iVar2 + 0xd8);
    param_2 = (int *)*param_2;
    if (*(int *)(iVar2 + 0xd4) == 0) {
      puVar4 = (undefined4 *)0x0;
    }
    iVar2 = *param_2;
    uVar1 = *puVar4;
    iVar5 = thunk_FUN_00890320();
    if (iVar2 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
      FUN_00c6b5f0(*piVar6,uVar1);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29046 ; VA 0x00c6c260 ; FUN_00c6c260 */

void FUN_00c6c260(void)

{
  int iVar1;
  
  if (DAT_01efea4c == 0) {
    iVar1 = FUN_00c6ac40();
    DAT_01efea4c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29047 ; VA 0x00c6c280 ; FUN_00c6c280 */

void __thiscall FUN_00c6c280(int param_1,undefined4 *param_2)

{
  *param_2 = *(undefined4 *)(param_1 + 0x168);
  return;
}



/* FUNCTION 29048 ; VA 0x00c6c2a0 ; FUN_00c6c2a0 */

undefined4 __fastcall FUN_00c6c2a0(int param_1)

{
  switch(*(undefined4 *)(param_1 + 0x164)) {
  default:
    return 0;
  case 1:
    return 1;
  case 2:
    return 2;
  case 3:
    return 3;
  }
}



/* FUNCTION 29049 ; VA 0x00c6c2e0 ; FUN_00c6c2e0 */

undefined4 __fastcall FUN_00c6c2e0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x168);
}



/* FUNCTION 29050 ; VA 0x00c6c2f0 ; FUN_00c6c2f0 */

void __thiscall FUN_00c6c2f0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00c6cea0();
  *param_3 = uVar3;
  iVar4 = FUN_00c6cf30();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 29051 ; VA 0x00c6c360 ; FUN_00c6c360 */

uint FUN_00c6c360(void)

{
  int iVar1;
  
  iVar1 = FUN_00c6ac40();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 29052 ; VA 0x00c6c380 ; FUN_00c6c380 */

uint FUN_00c6c380(void)

{
  int iVar1;
  
  iVar1 = FUN_00c6ac40();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 29053 ; VA 0x00c6c3a0 ; FUN_00c6c3a0 */

void __fastcall FUN_00c6c3a0(int param_1)

{
  int iVar1;
  int *piVar2;
  int iStack_c;
  int iStack_8;
  
  iStack_8 = 1;
  iVar1 = *(int *)(param_1 + 4);
  iStack_c = (**(code **)(**(int **)(iVar1 + 0x34) + 0xc))(*(undefined4 *)(param_1 + 8));
  iStack_c = iStack_c + 1;
  piVar2 = &iStack_8;
  if (iStack_8 <= iStack_c) {
    piVar2 = &iStack_c;
  }
  (**(code **)(**(int **)(iVar1 + 0x34) + 0x10))(*(undefined4 *)(param_1 + 8),piVar2);
  return;
}



/* FUNCTION 29054 ; VA 0x00c6c3f0 ; FUN_00c6c3f0 */

void FUN_00c6c3f0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c6cea0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29055 ; VA 0x00c6c430 ; FUN_00c6c430 */

void __thiscall FUN_00c6c430(undefined4 *param_1,int param_2)

{
  char cVar1;
  int iVar2;
  
  cVar1 = FUN_016793f0();
  if ((cVar1 == '\0') && (*(int *)(param_2 + 4) == *(int *)(param_1[1] + 4))) {
    iVar2 = (**(code **)(**(int **)(param_1[1] + 0x34) + 0xc))(param_1[2]);
    cVar1 = FUN_016793f0();
    if (iVar2 < 1) {
      if (cVar1 != '\0') {
        FUN_01679490();
      }
    }
    else if (cVar1 == '\0') {
      (**(code **)*param_1)();
      return;
    }
  }
  return;
}



/* FUNCTION 29056 ; VA 0x00c6c490 ; FUN_00c6c490 */

void __thiscall FUN_00c6c490(int param_1,int param_2)

{
  char cVar1;
  int iVar2;
  
  FUN_00c6c430(param_2);
  FUN_00c6c430(param_2);
  cVar1 = FUN_016793f0();
  if ((cVar1 == '\0') && (*(int *)(param_2 + 4) == *(int *)(*(int *)(param_1 + 0x10c) + 4))) {
    iVar2 = (**(code **)(**(int **)(*(int *)(param_1 + 0x10c) + 0x34) + 0xc))
                      (*(undefined4 *)(param_1 + 0x110));
    cVar1 = FUN_016793f0();
    if (iVar2 < 1) {
      if (cVar1 != '\0') {
        FUN_01679490();
      }
    }
    else if (cVar1 == '\0') {
      (*(code *)**(undefined4 **)(param_1 + 0x108))();
    }
  }
  FUN_00c6c430(param_2);
  FUN_00c6c430(param_2);
  return;
}



/* FUNCTION 29057 ; VA 0x00c6c530 ; FUN_00c6c530 */

void __thiscall FUN_00c6c530(int param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  char cVar7;
  undefined4 *puVar8;
  int iVar9;
  undefined4 *puVar10;
  undefined auStack_7c [48];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d598;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_40 = *(uint *)(*param_3 + 0x54);
  if ((uStack_40 < 5) && (*(char *)(param_1 + 0x80) != '\0')) {
    if (uStack_40 == 0) {
      iVar3 = *(int *)(*param_3 + 0x5c);
      if (iVar3 == 0) {
        ExceptionList = &pvStack_10;
        uStack_3c = uStack_40;
        uStack_38 = uStack_40;
        cVar7 = FUN_00ea49f0(param_3,&uStack_40,&uStack_1c);
        if (cVar7 != '\0') {
          puVar8 = (undefined4 *)FUN_01674e20(0x40);
          puStack_14 = puVar8;
          if (puVar8 == (undefined4 *)0x0) {
            puVar8 = (undefined4 *)0x0;
          }
          else {
            uStack_24 = uStack_1c;
            iVar3 = *(int *)(param_1 + 0x88);
            iStack_2c = 0;
            uStack_28 = 0;
            if (iVar3 != 0) {
              piVar1 = (int *)(iVar3 + 4);
              iVar3 = *(int *)(iVar3 + 4);
              while (iVar3 != 0) {
                LOCK();
                iVar9 = *piVar1;
                if (iVar3 == iVar9) {
                  *piVar1 = iVar3 + 1;
                  iVar9 = iVar3;
                }
                UNLOCK();
                if (iVar9 == iVar3) {
                  iStack_2c = *(int *)(param_1 + 0x84);
                  uStack_28 = *(undefined4 *)(param_1 + 0x88);
                  break;
                }
                iVar3 = *piVar1;
              }
            }
            uStack_18 = 2;
            uStack_8 = 1;
            puVar10 = (undefined4 *)
                      (*(code *)**(undefined4 **)
                                  (iStack_2c + *(int *)(*(int *)(iStack_2c + 0x54) + 4) + 0x54))
                                (auStack_7c);
            uVar4 = puVar10[1];
            uVar5 = puVar10[2];
            uVar6 = puVar10[3];
            *puVar8 = *puVar10;
            puVar8[1] = uVar4;
            puVar8[2] = uVar5;
            puVar8[3] = uVar6;
            uVar4 = puVar10[5];
            uVar5 = puVar10[6];
            uVar6 = puVar10[7];
            puVar8[4] = puVar10[4];
            puVar8[5] = uVar4;
            puVar8[6] = uVar5;
            puVar8[7] = uVar6;
            uVar4 = puVar10[9];
            uVar5 = puVar10[10];
            uVar6 = puVar10[0xb];
            puVar8[8] = puVar10[8];
            puVar8[9] = uVar4;
            puVar8[10] = uVar5;
            puVar8[0xb] = uVar6;
            *(ulonglong *)(puVar8 + 0xc) = CONCAT44(uStack_3c,uStack_40);
            puVar8[0xe] = uStack_38;
            puVar8[0xf] = uStack_24;
          }
          uStack_8 = 2;
          uStack_34 = 0;
          uStack_30 = 0;
          FUN_00c6ad40(puVar8,param_2);
          *(undefined4 *)(param_1 + 0x90) = uStack_34;
          param_3 = *(int **)(param_1 + 0x94);
          *(undefined4 *)(param_1 + 0x94) = uStack_30;
          if (param_3 != (int *)0x0) {
            LOCK();
            iVar3 = param_3[1] + -1;
            param_3[1] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)*param_3)();
              LOCK();
              piVar1 = param_3 + 2;
              iVar3 = *piVar1;
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (iVar3 == 1) {
                (**(code **)(*param_3 + 4))();
              }
            }
          }
          uStack_8 = 0xffffffff;
          if ((uStack_18 & 2) != 0) {
            FUN_00550b30();
          }
          FUN_005e6780(uStack_1c);
          *param_2 = 1;
          goto LAB_00c6c84c;
        }
      }
      else if (iVar3 == 2) {
        ExceptionList = &pvStack_10;
        if ((*(int *)(param_1 + 0x90) != 0) &&
           (iVar3 = *(int *)(*(int *)(param_1 + 0x90) + 0x3c), ExceptionList = &pvStack_10,
           iVar3 != 6)) {
          ExceptionList = &pvStack_10;
          FUN_005e6780(iVar3);
        }
        *(undefined4 *)(param_1 + 0x90) = 0;
        piVar1 = *(int **)(param_1 + 0x94);
        *(undefined4 *)(param_1 + 0x94) = 0;
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar3 = piVar1[1] + -1;
          piVar1[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            piVar2 = piVar1 + 2;
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
      }
    }
    else if (uStack_40 == 4) {
      iVar3 = *(int *)(param_1 + 0x90);
      ExceptionList = &pvStack_10;
      if ((iVar3 != 0) &&
         (ExceptionList = &pvStack_10,
         cVar7 = FUN_00ea4d50(param_3,*(undefined4 *)(iVar3 + 0x3c),iVar3 + 0x30,&uStack_20),
         cVar7 != '\0')) {
        FUN_00c6b5f0(*(undefined4 *)(*(int *)(param_1 + 0x90) + 0x3c),uStack_20);
      }
      uStack_4c = 0;
      uStack_48 = 0;
      uStack_44 = 0;
      param_3 = (int *)0x6;
      cVar7 = FUN_00ea49f0(piVar1,&uStack_4c,&param_3);
      if (cVar7 == '\0') {
        if (*(int *)(param_1 + 0x8c) != 6) {
          FUN_005e6780(*(int *)(param_1 + 0x8c));
          *(undefined4 *)(param_1 + 0x8c) = 6;
        }
      }
      else {
        iVar3 = *(int *)(param_1 + 0x8c);
        if ((iVar3 != 6) && ((int *)iVar3 != param_3)) {
          FUN_005e6780(iVar3);
        }
        *(int **)(param_1 + 0x8c) = param_3;
        FUN_005e6780(param_3);
      }
    }
  }
  *param_2 = 0;
LAB_00c6c84c:
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[4] = 0;
  param_2[3] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29058 ; VA 0x00c6c880 ; FUN_00c6c880 */

void FUN_00c6c880(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  return;
}



/* FUNCTION 29059 ; VA 0x00c6c8b0 ; FUN_00c6c8b0 */

void __thiscall FUN_00c6c8b0(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0x168) != param_2) {
    *(int *)(param_1 + 0x168) = param_2;
    FUN_008a4940(&DAT_02137d70);
  }
  return;
}



/* FUNCTION 29060 ; VA 0x00c6c8e0 ; FUN_00c6c8e0 */

void __thiscall FUN_00c6c8e0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int *piVar6;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d5d1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar3 = FUN_016793f0();
  if (cVar3 == '\0') {
    iStack_14 = *(int *)(param_1 + 0x10);
    uStack_8 = 0;
    uVar4 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 1;
    puVar5 = (undefined4 *)FUN_01674e20(0x20);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puVar5 = 0;
      puVar5[1] = 1;
      puVar5[2] = FUN_00c6c160;
      puVar5[3] = _guard_check_icall;
      puVar5[4] = 0;
      puVar5[5] = iStack_14;
      puVar5[6] = FUN_00c6c3a0;
      puVar5[7] = param_1;
    }
    FUN_016797d0(puVar5);
    if (puVar5 != (undefined4 *)0x0) {
      LOCK();
      puVar5[1] = puVar5[1] + 1;
      UNLOCK();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_01675290(uVar4);
    iVar2 = *(int *)(param_1 + 0x14);
    *(undefined4 **)(param_1 + 0x14) = puVar5;
    uStack_8 = 0xffffffff;
    if (iVar2 != 0) {
      piVar6 = (int *)(iVar2 + 4);
      LOCK();
      iVar1 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        FUN_01674ea0(iVar2);
      }
    }
    if ((char)param_2 != '\0') {
      iVar2 = *(int *)(param_1 + 4);
      param_2 = 1;
      iStack_14 = (**(code **)(**(int **)(iVar2 + 0x34) + 0xc))(*(undefined4 *)(param_1 + 8));
      iStack_14 = iStack_14 + 1;
      piVar6 = &param_2;
      if (param_2 <= iStack_14) {
        piVar6 = &iStack_14;
      }
      (**(code **)(**(int **)(iVar2 + 0x34) + 0x10))(*(undefined4 *)(param_1 + 8),piVar6);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29061 ; VA 0x00c6ca30 ; FUN_00c6ca30 */

void __fastcall FUN_00c6ca30(int param_1)

{
  int iVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  int iStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d601;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_00ea54b0();
  FUN_00c6c8e0(*(int *)(param_1 + 0x9c) != 0);
  FUN_00c6c8e0(*(int *)(param_1 + 0xa4) != 0);
  iStack_20 = *(int *)(param_1 + 0xac);
  cVar2 = FUN_016793f0();
  iVar3 = param_1;
  if (cVar2 == '\0') {
    iStack_14 = *(int *)(param_1 + 0x118);
    uStack_8 = 0;
    iVar3 = FUN_01675290(DAT_02110da8);
    uStack_8._0_1_ = 1;
    iStack_24 = iVar3;
    puVar4 = (undefined4 *)FUN_01674e20(0x20);
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = 0;
      puVar4[1] = 1;
      puVar4[2] = FUN_00c6c160;
      puVar4[3] = _guard_check_icall;
      puVar4[4] = 0;
      puVar4[5] = iStack_14;
      puVar4[6] = FUN_00c6c3a0;
      puVar4[7] = param_1 + 0x108;
    }
    FUN_016797d0(puVar4);
    if (puVar4 != (undefined4 *)0x0) {
      LOCK();
      puVar4[1] = puVar4[1] + 1;
      UNLOCK();
    }
    uStack_1c = 1;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_01675290(iVar3);
    iVar3 = *(int *)(param_1 + 0x11c);
    *(undefined4 **)(param_1 + 0x11c) = puVar4;
    uStack_8 = 0xffffffff;
    if (iVar3 != 0) {
      piVar5 = (int *)(iVar3 + 4);
      LOCK();
      iVar1 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        FUN_01674ea0(iVar3);
      }
    }
    iVar3 = iStack_18;
    if (iStack_20 != 0) {
      iVar3 = *(int *)(param_1 + 0x10c);
      iStack_14 = 1;
      iStack_24 = (**(code **)(**(int **)(iVar3 + 0x34) + 0xc))(*(undefined4 *)(param_1 + 0x110));
      iStack_24 = iStack_24 + 1;
      piVar5 = &iStack_14;
      if (iStack_14 <= iStack_24) {
        piVar5 = &iStack_24;
      }
      (**(code **)(**(int **)(iVar3 + 0x34) + 0x10))(*(undefined4 *)(param_1 + 0x110),piVar5);
      iVar3 = iStack_18;
    }
  }
  FUN_00c6c8e0(*(int *)(iVar3 + 0xb4) != 0);
  FUN_00c6c8e0(*(int *)(iVar3 + 0xbc) != 0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29062 ; VA 0x00c6cbf0 ; FUN_00c6cbf0 */

void __thiscall FUN_00c6cbf0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_00c6cea0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29063 ; VA 0x00c6cc40 ; FUN_00c6cc40 */

void __thiscall FUN_00c6cc40(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0x164) != param_2) {
    *(int *)(param_1 + 0x164) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 29064 ; VA 0x00c6cc70 ; FUN_00c6cc70 */

void __fastcall FUN_00c6cc70(int *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00c6cc75. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 8))();
  return;
}



/* FUNCTION 29065 ; VA 0x00c6cc80 ; FUN_00c6cc80 */

undefined __fastcall FUN_00c6cc80(int param_1)

{
  return *(undefined *)(param_1 + 0x2c);
}



/* FUNCTION 29066 ; VA 0x00c6cc90 ; FUN_00c6cc90 */

void __thiscall FUN_00c6cc90(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  code *pcVar2;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d53a1;
  pvStack_10 = ExceptionList;
  piStack_14 = *(int **)(param_1 + 8);
  uVar1 = *(undefined4 *)(param_1 + 0xc);
  uStack_28 = 0;
  uStack_24 = 0;
  pcVar2 = *(code **)(*piStack_14 + 8);
  ExceptionList = &pvStack_10;
  uStack_f8 = thunk_FUN_00890320();
  uStack_f4 = 0;
  uStack_f0 = param_2;
  uStack_f4 = FUN_00890440();
  uStack_8 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_f8,&uStack_28,param_2);
  uStack_8._0_1_ = 1;
  (*pcVar2)(uVar1,&uStack_20,&uStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00577b20();
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_f8,0xd0,1,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29067 ; VA 0x00c6cd80 ; FUN_00c6cd80 */

void __thiscall FUN_00c6cd80(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  code *pcVar2;
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c917c;
  pvStack_10 = ExceptionList;
  piStack_14 = *(int **)(param_1 + 8);
  uVar1 = *(undefined4 *)(param_1 + 0xc);
  uStack_28 = 0;
  uStack_24 = 0;
  pcVar2 = *(code **)(*piStack_14 + 8);
  ExceptionList = &pvStack_10;
  uStack_1c8 = thunk_FUN_00890320();
  uStack_1c4 = 0;
  uStack_1c0 = param_2;
  uStack_1c4 = FUN_00890440();
  uStack_8 = 0;
  uStack_f8 = FUN_0088c960();
  uStack_f4 = 0;
  uStack_f0 = param_3;
  uStack_f4 = FUN_00630820();
  uStack_8 = 1;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_1c8,&uStack_28,param_2);
  uStack_8._0_1_ = 2;
  (*pcVar2)(uVar1,&uStack_20,&uStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00577b20();
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_1c8,0xd0,2,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29068 ; VA 0x00c6cea0 ; FUN_00c6cea0 */

undefined * FUN_00c6cea0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d61c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efeabc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efeabc);
    if (DAT_01efeabc == -1) {
      uStack_8 = 0;
      FUN_00ff4ff0();
      FUN_016f3654(&LAB_01895f60);
      FUN_016f37bf(&DAT_01efeabc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efea58;
}



/* FUNCTION 29069 ; VA 0x00c6cf30 ; FUN_00c6cf30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c6cf30(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efeacc) {
    FUN_016f3809(&DAT_01efeacc);
    if (DAT_01efeacc == -1) {
      _DAT_01efeac0 = FUN_005c65e0;
      _DAT_01efeac4 = FUN_005c65e0;
      _DAT_01efeac8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01efeacc);
    }
  }
  return &DAT_01efeac0;
}



/* FUNCTION 29070 ; VA 0x00c6cfa0 ; FUN_00c6cfa0 */

undefined4 * __thiscall FUN_00c6cfa0(undefined4 *param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  int iStack_c;
  undefined4 uStack_8;
  
  *param_1 = 0;
  if (param_2 != 0) {
    iStack_c = param_2;
    uStack_8 = param_3;
    cVar1 = FUN_00585a40(&iStack_c);
    if (cVar1 == '\0') {
      param_1[2] = iStack_c;
      param_1[3] = uStack_8;
    }
    *param_1 = &DAT_0196f811;
    return param_1;
  }
  *param_1 = 0;
  return param_1;
}



/* FUNCTION 29071 ; VA 0x00c6d000 ; FUN_00c6d000 */

int * __thiscall
FUN_00c6d000(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ecf2b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c6de80();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::GuiObject,class_RBX::BrickColor>::
              GetSetImpl<class_RBX::BrickColor_(__thiscall_RBX::GuiObject::*)(void)const_,void_(__thiscall_RBX::GuiObject::*)(class_RBX::BrickColor)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cfa0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_RBX::BrickColor>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::GuiObject,class_RBX::BrickColor>::
                    vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::GuiObject,class_RBX::BrickColor>::
                    vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29072 ; VA 0x00c6d100 ; FUN_00c6d100 */

int * __thiscall
FUN_00c6d100(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d64b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c6de80();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::GuiObject,class_G3D::Color3>::
              GetSetImpl<class_G3D::Color3_(__thiscall_RBX::GuiObject::*)(void)const_,void_(__thiscall_RBX::GuiObject::*)(class_G3D::Color3)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d050();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::GuiObject,class_G3D::Color3>::vftable
    ;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::GuiObject,class_G3D::Color3>::vftable
    ;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29073 ; VA 0x00c6d200 ; FUN_00c6d200 */

int * __thiscall
FUN_00c6d200(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d67b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c6de80();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::GuiObject,class_RBX::UDim2>::
              GetSetImpl<class_RBX::UDim2_(__thiscall_RBX::GuiObject::*)(void)const_,void_(__thiscall_RBX::GuiObject::*)(class_RBX::UDim2)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d5f0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_RBX::UDim2>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::GuiObject,class_RBX::UDim2>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::GuiObject,class_RBX::UDim2>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29074 ; VA 0x00c6d300 ; FUN_00c6d300 */

int * __thiscall
FUN_00c6d300(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d64cb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c6de80();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::GuiObject,float>::
              GetSetImpl<float_(__thiscall_RBX::GuiObject::*)(void)const_,void_(__thiscall_RBX::GuiObject::*)(float)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::GuiObject,float>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::GuiObject,float>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29075 ; VA 0x00c6d400 ; FUN_00c6d400 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __thiscall
FUN_00c6d400(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f969f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eefe7c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eefe7c);
    if (DAT_01eefe7c == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01eefe58 = RBX::Reflection::RefType<class_RBX::GuiObject*>::vftable;
      FUN_016f3654(&LAB_0188e490);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eefe7c);
    }
  }
  uVar2 = FUN_00c6de80();
  FUN_009ca670(uVar2,&DAT_01eefe58,param_2,param_3,param_8,param_9,param_10,param_11,param_12,
               param_12,0);
  param_1[0xd] = (int)RBX::IIDREF::vftable;
  uStack_8 = 1;
  *param_1 = (int)RBX::Reflection::RefPropDescriptor<class_RBX::GuiObject,class_RBX::GuiObject>::
                  vftable;
  param_1[0xd] = (int)RBX::Reflection::RefPropDescriptor<class_RBX::GuiObject,class_RBX::GuiObject>
                      ::vftable;
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::GuiObject,class_RBX::GuiObject*>::
              GetSetImpl<class_RBX::GuiObject*_(__thiscall_RBX::GuiObject::*)(void)const_,void_(__thiscall_RBX::GuiObject::*)(class_RBX::GuiObject*)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  param_1[0xe] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (**(code **)(*param_1 + 0xc))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar1 = (**(code **)(*param_1 + 8))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29076 ; VA 0x00c6d560 ; FUN_00c6d560 */

undefined4 * __thiscall FUN_00c6d560(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0196f818;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 29077 ; VA 0x00c6d690 ; FUN_00c6d690 */

undefined4 * __thiscall FUN_00c6d690(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0196f828;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 29078 ; VA 0x00c6d7c0 ; FUN_00c6d7c0 */

undefined4 * __thiscall FUN_00c6d7c0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0196f820;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 29079 ; VA 0x00c6d8f0 ; FUN_00c6d8f0 */

undefined4 * __thiscall
FUN_00c6d8f0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_a0;
  int *piStack_9c;
  undefined4 uStack_7c;
  undefined4 *puStack_78;
  undefined4 uStack_68;
  int *piStack_64;
  undefined auStack_60 [32];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  undefined auStack_34 [32];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_0180d6c0;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_68;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_68 = param_3;
  piStack_64 = param_4;
  puStack_78 = (undefined4 *)&stack0x00000010;
  uStack_8 = 1;
  uStack_7 = 0;
  uStack_7c = 0xc6d95a;
  FUN_00d88580();
  uStack_40 = param_2;
  puStack_14 = &uStack_3c;
  *param_1 = 0;
  if (piStack_64 != (int *)0x0) {
    LOCK();
    piStack_64[2] = piStack_64[2] + 1;
    UNLOCK();
  }
  uStack_3c = uStack_68;
  piStack_38 = piStack_64;
  puStack_78 = (undefined4 *)auStack_60;
  uStack_8 = 3;
  uStack_7c = 0xc6d9a1;
  FUN_00d88580();
  puStack_78 = param_1 + 2;
  puStack_14 = &uStack_a0;
  if (piStack_38 != (int *)0x0) {
    LOCK();
    piStack_38[2] = piStack_38[2] + 1;
    UNLOCK();
  }
  uStack_a0 = uStack_3c;
  piStack_9c = piStack_38;
  uStack_8 = 5;
  FUN_00d88580(auStack_34);
  ppuVar4 = &PTR_FUN_0196f808;
  _uStack_8 = CONCAT31(uStack_7,4);
  cVar3 = FUN_00c6e1b0();
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  puStack_78 = (undefined4 *)0xc6da0c;
  FUN_00d88a30();
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_38[2] + -1;
    piStack_38[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_78 = (undefined4 *)0xc6da24;
      (**(code **)(*piStack_38 + 4))();
    }
  }
  puStack_78 = (undefined4 *)0xc6da2c;
  FUN_00d88a30();
  if (piStack_64 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_64[2] + -1;
    piStack_64[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_78 = (undefined4 *)0xc6da41;
      (**(code **)(*piStack_64 + 4))();
    }
  }
  puStack_78 = (undefined4 *)0xc6da49;
  FUN_00d88a30();
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_78 = (undefined4 *)0xc6da5d;
      (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29080 ; VA 0x00c6da80 ; FUN_00c6da80 */

int * __thiscall
FUN_00c6da80(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804848;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c6dcc0();
  FUN_005c44c0(uVar3,param_2,param_3,0,param_5,param_6,param_7,param_8,param_9);
  uStack_8 = 0;
  *param_1 = (int)RBX::Reflection::BoundProp<int,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<int,1>::BoundPropGetSet<class_RBX::GuiButton>::vftable;
    puVar4[1] = param_1;
    puVar4[2] = param_4;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar4;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29081 ; VA 0x00c6db50 ; FUN_00c6db50 */

int * __thiscall
FUN_00c6db50(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804848;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00c6de80();
  FUN_005c44c0(uVar3,param_2,param_3,0,param_5,param_6,param_7,param_8,param_9);
  uStack_8 = 0;
  *param_1 = (int)RBX::Reflection::BoundProp<int,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<int,1>::BoundPropGetSet<class_RBX::GuiObject>::vftable;
    puVar4[1] = param_1;
    puVar4[2] = param_4;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar4;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29082 ; VA 0x00c6dc20 ; FUN_00c6dc20 */

int * __thiscall FUN_00c6dc20(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00c7d6c0();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 29083 ; VA 0x00c6dc70 ; FUN_00c6dc70 */

int * __thiscall FUN_00c6dc70(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = FUN_00c7d730();
  iVar1 = *param_1;
  if (iVar1 == iVar2) {
    param_1[1] = *param_2;
    return param_1;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_1 + 1);
    *param_1 = 0;
  }
  param_1[1] = *param_2;
  *param_1 = iVar2;
  return param_1;
}



/* FUNCTION 29084 ; VA 0x00c6dcc0 ; FUN_00c6dcc0 */

undefined * FUN_00c6dcc0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d6dc;
  pvStack_10 = ExceptionList;
  if (DAT_01efed30 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efef40) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efef40);
      if (DAT_01efef40 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c6de80();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"GuiButton",0,uStack_20,0,0,0x1b,0,&DAT_01efeae4);
        FUN_016f3654(&LAB_01896820);
        FUN_016f37bf(&DAT_01efef40);
      }
    }
    DAT_01efed30 = &DAT_01efed38;
  }
  ExceptionList = pvStack_10;
  return DAT_01efed30;
}



/* FUNCTION 29085 ; VA 0x00c6dda0 ; FUN_00c6dda0 */

undefined * FUN_00c6dda0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d6fc;
  pvStack_10 = ExceptionList;
  if (DAT_01efef48 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff158) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eff158);
      if (DAT_01eff158 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c6de80();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"GuiLabel",0,uStack_20,0,0,0x1b,0,&DAT_01efeae4);
        FUN_016f3654(&LAB_01896830);
        FUN_016f37bf(&DAT_01eff158);
      }
    }
    DAT_01efef48 = &DAT_01efef50;
  }
  ExceptionList = pvStack_10;
  return DAT_01efef48;
}



/* FUNCTION 29086 ; VA 0x00c6de80 ; FUN_00c6de80 */

undefined * FUN_00c6de80(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d71c;
  pvStack_10 = ExceptionList;
  if (DAT_01efeb1c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efed28) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efed28);
      if (DAT_01efed28 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00d59db0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"GuiObject",0,uStack_20,0,0,0x1b,0,&DAT_01efeae4);
        FUN_016f3654(&LAB_01896840);
        FUN_016f37bf(&DAT_01efed28);
      }
    }
    DAT_01efeb1c = &DAT_01efeb20;
  }
  ExceptionList = pvStack_10;
  return DAT_01efeb1c;
}



/* FUNCTION 29087 ; VA 0x00c6df60 ; FUN_00c6df60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

float10 FUN_00c6df60(float *param_1)

{
  short sVar1;
  float10 fVar2;
  double dVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fStack_14;
  float fStack_10;
  int iStack_c;
  
  fVar4 = *param_1;
  fVar6 = param_1[1];
  fStack_14 = fVar4;
  sVar1 = FUN_016e0bd4(&fStack_14);
  if ((sVar1 == 1) || (fStack_14 = fVar6, sVar1 = FUN_016e0bd4(&fStack_14), sVar1 == 1)) {
    return (float10)INFINITY;
  }
  fStack_14 = fVar4;
  sVar1 = FUN_016e0bd4(&fStack_14);
  if (sVar1 == 2) {
    return (float10)fVar4;
  }
  fStack_14 = fVar6;
  sVar1 = FUN_016e0bd4(&fStack_14);
  if (sVar1 != 2) {
    if (fVar4 < 0.0) {
      fVar4 = (float)((uint)fVar4 ^ DAT_018c4ea0);
    }
    if (fVar6 < 0.0) {
      fVar6 = (float)((uint)fVar6 ^ DAT_018c4ea0);
    }
    fVar5 = fVar4;
    if (fVar4 < fVar6) {
      fVar5 = fVar6;
      fVar6 = fVar4;
    }
    if (NAN(fVar5) == (fVar5 == 0.0)) {
      fVar4 = DAT_018e3f8c;
      if (DAT_018ce2f8 <= fVar5) {
        fVar4 = DAT_018e1340;
      }
      fVar7 = fVar4 * fVar5;
      fVar4 = fVar4 * fVar6;
      fVar6 = fVar7 - fVar4;
      iStack_c = (uint)(DAT_018ce2f8 <= fVar5) * 4 + -2;
      if ((NAN(fVar6) || NAN(fVar7)) == (fVar6 == fVar7)) {
        if (fVar6 <= fVar4) {
          fStack_10 = fVar6 / fVar4;
          fStack_14 = (fStack_10 + DAT_018daf58) * fStack_10;
          dVar3 = (double)(fStack_14 + DAT_018daf58);
          FUN_017267a0();
          fVar6 = fStack_14 / ((float)dVar3 + DAT_0196f838) + _DAT_0196f830 + fStack_10 +
                  _DAT_0196f8b0;
        }
        else {
          fStack_14 = fVar7 / fVar4;
          dVar3 = (double)(fStack_14 * fStack_14 + DAT_018ce2f8);
          FUN_017267a0();
          fVar6 = (float)dVar3 + fStack_14;
        }
        fVar7 = fVar7 + fVar4 / fVar6;
      }
      fVar2 = (float10)FUN_017277f1((double)fVar7,iStack_c);
      return (float10)(float)fVar2;
    }
    return (float10)fVar5;
  }
  return (float10)fVar6;
}



/* FUNCTION 29088 ; VA 0x00c6e1b0 ; FUN_00c6e1b0 */

uint FUN_00c6e1b0(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined3 uStack00000030;
  undefined4 uStack_6c;
  int *piStack_68;
  undefined auStack_64 [32];
  undefined4 uStack_44;
  undefined4 uStack_40;
  int *piStack_3c;
  undefined auStack_38 [32];
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_0180d76f;
  pvStack_10 = ExceptionList;
  uStack_44 = param_1;
  puStack_14 = &uStack_40;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_40 = param_2;
  piStack_3c = param_3;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_00d88580(&stack0x00000010);
  uStack_8 = 2;
  cVar4 = FUN_00585a40(&uStack_44);
  uVar3 = uStack_44;
  if (cVar4 == '\0') {
    puStack_14 = &uStack_6c;
    if (piStack_3c != (int *)0x0) {
      LOCK();
      piStack_3c[2] = piStack_3c[2] + 1;
      UNLOCK();
    }
    uStack_6c = uStack_40;
    piStack_68 = piStack_3c;
    uStack_8 = 3;
    FUN_00d88580(auStack_38);
    uStack_8 = 4;
    puVar5 = (undefined4 *)FUN_01674e20(0x2c);
    uStack_8 = 5;
    puStack_14 = puVar5;
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      *puVar5 = uVar3;
      puStack_18 = puVar5 + 1;
      *puStack_18 = 0;
      puVar5[2] = 0;
      if (piStack_68 != (int *)0x0) {
        LOCK();
        piStack_68[2] = piStack_68[2] + 1;
        UNLOCK();
      }
      *puStack_18 = uStack_6c;
      puVar5[2] = piStack_68;
      uStack_8 = 6;
      FUN_00d88580(auStack_64);
    }
    *_uStack00000030 = (int)puVar5;
    FUN_00d88a30();
    if (piStack_68 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_68[2] + -1;
      piStack_68[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_68 + 4))();
      }
    }
    FUN_00d88a30();
    if (piStack_3c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_3c[2] + -1;
      piStack_3c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
    _uStack00000030 = (int *)CONCAT13(1,uStack00000030);
  }
  else {
    FUN_00d88a30();
    if (piStack_3c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_3c[2] + -1;
      piStack_3c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
    _uStack00000030 = (int *)((uint)_uStack00000030 & 0xffffff);
  }
  FUN_00d88a30();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return (uint)_uStack00000030 >> 0x18;
}



/* FUNCTION 29089 ; VA 0x00c6e370 ; FUN_00c6e370 */

undefined4 * FUN_00c6e370(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  undefined auStack_b4 [24];
  undefined4 uStack_9c;
  undefined *puStack_98;
  undefined4 uStack_8c;
  int *piStack_88;
  undefined auStack_84 [32];
  undefined auStack_64 [32];
  undefined auStack_44 [32];
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180d7c3;
  pvStack_10 = ExceptionList;
  puStack_98 = &stack0x00000014;
  uStack_8 = 1;
  uStack_9c = 0xc6e3a0;
  ExceptionList = &pvStack_10;
  FUN_00d88580();
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_1c = param_3;
  piStack_18 = param_4;
  puStack_98 = auStack_64;
  uStack_8._0_1_ = 3;
  uStack_9c = 0xc6e3c7;
  FUN_00d88580();
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_24 = param_3;
  piStack_20 = param_4;
  puStack_14 = auStack_b4;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_00d88580(auStack_44);
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  FUN_00b90480(param_3,param_4);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_98 = (undefined *)0xc6e42b;
      (**(code **)(*param_4 + 4))();
    }
  }
  puStack_98 = (undefined *)0xc6e433;
  FUN_00d88a30();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_98 = (undefined *)0xc6e447;
      (**(code **)(*param_4 + 4))();
    }
  }
  puStack_98 = (undefined *)0xc6e44f;
  FUN_00d88a30();
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (piStack_88 != (int *)0x0) {
    LOCK();
    piStack_88[2] = piStack_88[2] + 1;
    UNLOCK();
  }
  param_1[1] = uStack_8c;
  param_1[2] = piStack_88;
  puStack_98 = auStack_84;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  uStack_9c = 0xc6e499;
  FUN_00d88580();
  puStack_98 = (undefined *)0xc6e4a1;
  FUN_00d88a30();
  if (piStack_88 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_88[2] + -1;
    piStack_88[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_98 = (undefined *)0xc6e4b9;
      (**(code **)(*piStack_88 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_98 = (undefined *)0xc6e4cd;
      (**(code **)(*param_4 + 4))();
    }
  }
  puStack_98 = (undefined *)0xc6e4d5;
  FUN_00d88a30();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29090 ; VA 0x00c6e4f0 ; FUN_00c6e4f0 */

undefined4 * __thiscall FUN_00c6e4f0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c62e1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006eccd0();
  uStack_8 = 0;
  uVar2 = FUN_01675290(DAT_02110da8);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = 0;
    puVar3[1] = 1;
    puVar3[2] = FUN_00c75290;
    puVar3[3] = FUN_0068b170;
    puVar3[4] = 0;
    puVar3[5] = param_1;
    puVar3[6] = 0;
    puVar3[7] = 0;
    if (param_3[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_3[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puVar3[6] = *param_3;
    puVar3[7] = param_3[1];
  }
  FUN_016797d0(puVar3);
  *param_2 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    LOCK();
    puVar3[1] = puVar3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29091 ; VA 0x00c6e5f0 ; FUN_00c6e5f0 */

undefined4 FUN_00c6e5f0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_008e3430();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 29092 ; VA 0x00c6e650 ; FUN_00c6e650 */

int __fastcall FUN_00c6e650(int param_1)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = *(int *)(param_1 + 0x34);
  piVar2 = (int *)(param_1 + 0x34);
  while( true ) {
    if (iVar1 == 0) {
      return 0;
    }
    iVar1 = FUN_00c6e770();
    if (iVar1 != 0) break;
    piVar2 = (int *)(*piVar2 + 0x34);
    iVar1 = *piVar2;
  }
  return iVar1;
}



/* FUNCTION 29093 ; VA 0x00c6e680 ; FUN_00c6e680 */

int __fastcall FUN_00c6e680(int param_1)

{
  int iVar1;
  int iVar2;
  
  do {
    param_1 = *(int *)(param_1 + 0x34);
    if (param_1 == 0) {
      return 0;
    }
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00b9e640();
  } while ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
           (uint)*(ushort *)(iVar2 + 0x1da));
  return param_1;
}



/* FUNCTION 29094 ; VA 0x00c6e6c0 ; FUN_00c6e6c0 */

int __fastcall FUN_00c6e6c0(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  iVar1 = *(int *)(param_1 + 0x34);
  piVar4 = (int *)(param_1 + 0x34);
  while( true ) {
    if (iVar1 == 0) {
      return 0;
    }
    iVar2 = *(int *)(iVar1 + 0xc);
    iVar3 = FUN_00c68a10();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) break;
    piVar4 = (int *)(*piVar4 + 0x34);
    iVar1 = *piVar4;
  }
  return iVar1;
}



/* FUNCTION 29095 ; VA 0x00c6e710 ; FUN_00c6e710 */

int __fastcall FUN_00c6e710(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar3 = *piVar6;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00ee64a0(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        return iVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 29096 ; VA 0x00c6e770 ; FUN_00c6e770 */

int __fastcall FUN_00c6e770(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar3 = *piVar6;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00ee76e0(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        return iVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 29097 ; VA 0x00c6e7d0 ; thunk_FUN_00c7d060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00c7d060(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e916;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff38c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eff38c);
    if (DAT_01eff38c == -1) {
      uStack_8 = 0;
      FUN_009ca470("AutomaticSize");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eff328 = RBX::Reflection::EnumDesc<enum_RBX::GuiObject::AutomaticSize>::vftable;
      FUN_009caf20(&DAT_01d688d8,4);
      FUN_016f3654(&LAB_018965e0);
      FUN_016f37bf(&DAT_01eff38c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eff328;
}



/* FUNCTION 29098 ; VA 0x00c6e7e0 ; thunk_FUN_00c7d1a0 */

undefined * thunk_FUN_00c7d1a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e94c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff1ec) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eff1ec);
    if (DAT_01eff1ec == -1) {
      uStack_8 = 0;
      FUN_00ff4ed0();
      FUN_016f3654(&LAB_01896620);
      FUN_016f37bf(&DAT_01eff1ec);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eff188;
}



/* FUNCTION 29099 ; VA 0x00c6e7f0 ; thunk_FUN_00c7d370 */

undefined * thunk_FUN_00c7d370(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e9ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff3f4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eff3f4);
    if (DAT_01eff3f4 == -1) {
      uStack_8 = 0;
      FUN_00da8ff0();
      FUN_016f3654(&LAB_01896680);
      FUN_016f37bf(&DAT_01eff3f4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eff390;
}



/* FUNCTION 29100 ; VA 0x00c6e800 ; thunk_FUN_00c7d400 */

undefined * thunk_FUN_00c7d400(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e9cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff45c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eff45c);
    if (DAT_01eff45c == -1) {
      uStack_8 = 0;
      FUN_00da9050();
      FUN_016f3654(&LAB_018966a0);
      FUN_016f37bf(&DAT_01eff45c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eff3f8;
}



/* FUNCTION 29101 ; VA 0x00c6e810 ; FUN_00c6e810 */

void FUN_00c6e810(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 *puVar8;
  int iVar9;
  int *piVar10;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_0180d7d8;
  pvStack_1c = ExceptionList;
  iVar9 = *param_2;
  iVar5 = *(int *)(iVar9 + 0x270);
  ExceptionList = &pvStack_1c;
  iVar7 = thunk_FUN_00d82070();
  if (iVar5 != iVar7) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar8 = (undefined4 *)(iVar9 + 0x278);
  if (*(int *)(iVar9 + 0x274) == 0) {
    puVar8 = (undefined4 *)0x0;
  }
  uVar6 = *puVar8;
  iVar9 = *param_2;
  iVar5 = *(int *)(iVar9 + 0x1a0);
  iVar7 = FUN_0088d730();
  if (iVar5 != iVar7) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar8 = (undefined4 *)(iVar9 + 0x1a8);
  if (*(int *)(iVar9 + 0x1a4) == 0) {
    puVar8 = (undefined4 *)0x0;
  }
  uVar1 = *puVar8;
  uVar2 = puVar8[1];
  iVar9 = *param_2;
  iVar5 = *(int *)(iVar9 + 0xd0);
  iVar7 = FUN_0088d730();
  if (iVar5 != iVar7) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  param_2 = (int *)*param_2;
  puVar8 = (undefined4 *)(iVar9 + 0xd8);
  iVar5 = *param_2;
  if (*(int *)(iVar9 + 0xd4) == 0) {
    puVar8 = (undefined4 *)0x0;
  }
  uVar3 = *puVar8;
  uVar4 = puVar8[1];
  iVar9 = FUN_008882f0();
  if (iVar5 == iVar9) {
    piVar10 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar10 = (int *)0x0;
    }
    iVar9 = piVar10[1];
    if (iVar9 != 0) {
      LOCK();
      *(int *)(iVar9 + 4) = *(int *)(iVar9 + 4) + 1;
      UNLOCK();
      iVar9 = piVar10[1];
    }
    uStack_14 = 0;
    FUN_00c709a0(*piVar10,iVar9,uVar3,uVar4,uVar1,uVar2,uVar6);
    ExceptionList = pvStack_1c;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29102 ; VA 0x00c6e980 ; FUN_00c6e980 */

undefined4 * __thiscall
FUN_00c6e980(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined *puVar3;
  undefined in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  int in_stack_0000005c;
  undefined8 in_stack_00000060;
  undefined4 in_stack_00000068;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180d85c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c6de80();
  FUN_009cb790(uVar1,param_4,in_stack_0000005c,in_stack_00000060,in_stack_00000068);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::GuiObject,bool___cdecl(class_RBX::UDim2,class_RBX::UDim2,enum_RBX::TweenInfo::TweenEasingDirection,enum_RBX::TweenInfo::TweenEasingStyle,float,bool,class_RBX::Lua::WeakFunctionRef),7>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  uStack_8._0_1_ = 3;
  puVar2 = (undefined4 *)FUN_01674e20(4);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = in_stack_00000058;
  }
  param_1[0x12] = puVar2;
  uStack_8._0_1_ = 4;
  puVar2 = (undefined4 *)FUN_01674e20(4);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = in_stack_00000054;
  }
  param_1[0x13] = puVar2;
  uStack_8._0_1_ = 5;
  puVar2 = (undefined4 *)FUN_01674e20(4);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = in_stack_00000050;
  }
  param_1[0x14] = puVar2;
  uStack_8._0_1_ = 6;
  puVar3 = (undefined *)FUN_01674e20(1);
  if (puVar3 == (undefined *)0x0) {
    puVar3 = (undefined *)0x0;
  }
  else {
    *puVar3 = in_stack_0000004c;
  }
  param_1[0x15] = puVar3;
  uStack_8._0_1_ = 7;
  in_stack_0000005c = FUN_01674e20(0x20);
  uStack_8._0_1_ = 8;
  if (in_stack_0000005c == 0) {
    uVar1 = 0;
  }
  else {
    uVar1 = FUN_00d88580(&stack0x0000002c);
  }
  param_1[0x16] = uVar1;
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  FUN_00c74560(param_5,param_6,param_7,param_8,param_9,param_10,param_11);
  FUN_00d88a30();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29103 ; VA 0x00c6ead0 ; FUN_00c6ead0 */

undefined4 * __thiscall
FUN_00c6ead0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined *puVar3;
  undefined in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  int in_stack_00000058;
  undefined8 in_stack_0000005c;
  undefined4 in_stack_00000064;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180d8d1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c6de80();
  FUN_009cb790(uVar1,param_4,in_stack_00000058,in_stack_0000005c,in_stack_00000064);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::GuiObject,bool___cdecl(class_RBX::UDim2,enum_RBX::TweenInfo::TweenEasingDirection,enum_RBX::TweenInfo::TweenEasingStyle,float,bool,class_RBX::Lua::WeakFunctionRef),6>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 2;
  puVar2 = (undefined4 *)FUN_01674e20(4);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = in_stack_00000054;
  }
  param_1[0x11] = puVar2;
  uStack_8._0_1_ = 3;
  puVar2 = (undefined4 *)FUN_01674e20(4);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = in_stack_00000050;
  }
  param_1[0x12] = puVar2;
  uStack_8._0_1_ = 4;
  puVar2 = (undefined4 *)FUN_01674e20(4);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = in_stack_0000004c;
  }
  param_1[0x13] = puVar2;
  uStack_8._0_1_ = 5;
  puVar3 = (undefined *)FUN_01674e20(1);
  if (puVar3 == (undefined *)0x0) {
    puVar3 = (undefined *)0x0;
  }
  else {
    *puVar3 = in_stack_00000048;
  }
  param_1[0x14] = puVar3;
  uStack_8._0_1_ = 6;
  in_stack_00000058 = FUN_01674e20(0x20);
  uStack_8._0_1_ = 7;
  if (in_stack_00000058 == 0) {
    uVar1 = 0;
  }
  else {
    uVar1 = FUN_00d88580(&stack0x00000028);
  }
  param_1[0x15] = uVar1;
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  FUN_00c74c80(param_5,param_6,param_7,param_8,param_9,param_10);
  FUN_00d88a30();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29104 ; VA 0x00c6ec20 ; FUN_00c6ec20 */

undefined4 * __thiscall
FUN_00c6ec20(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined auStack_38c [864];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d922;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  uVar1 = FUN_00c6de80();
  FUN_009cb970(uVar1,param_3,param_8,CONCAT44(uStack_28,uStack_2c),0);
  param_1[0xd] = param_2;
  iStack_8 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::GuiObject,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,float,float,enum_RBX::InputObject::UserInputState),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,float,float,enum_RBX::InputObject::UserInputState)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,float,float,enum_RBX::InputObject::UserInputState)>_RBX::GuiObject::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_008882f0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(param_5);
  FUN_0088c960();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(param_6);
  FUN_0088c960();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  FUN_0086e3d0(param_7);
  thunk_FUN_00d82070();
  FUN_00888740();
  iStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_38c,&uStack_2c,param_8);
  iStack_8._0_1_ = 5;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = uStack_1c;
    param_1[0xb] = uStack_18;
    param_1[0xc] = uStack_14;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  iStack_8._0_1_ = 6;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_38c,0xd8,4,FUN_00688b10);
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::GuiObject,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,float,float,enum_RBX::InputObject::UserInputState),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,float,float,enum_RBX::InputObject::UserInputState)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,float,float,enum_RBX::InputObject::UserInputState)>_RBX::GuiObject::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29105 ; VA 0x00c6edc0 ; FUN_00c6edc0 */

undefined4 * __thiscall
FUN_00c6edc0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d951;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  uVar1 = FUN_00c6de80();
  FUN_009cb970(uVar1,param_3,param_5,CONCAT44(uStack_28,uStack_2c),0);
  param_1[0xd] = param_2;
  iStack_8 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::GuiObject,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::GuiObject::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,param_5);
  iStack_8._0_1_ = 2;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = uStack_1c;
    param_1[0xb] = uStack_18;
    param_1[0xc] = uStack_14;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::GuiObject,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::GuiObject::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29106 ; VA 0x00c6ef00 ; FUN_00c6ef00 */

undefined4 * __thiscall
FUN_00c6ef00(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  uVar1 = FUN_00c6de80();
  FUN_009cb970(uVar1,param_3,param_4,CONCAT44(uStack_1c,uStack_20),0);
  param_1[0xd] = param_2;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::GuiObject,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::GuiObject::*>
             ::vftable;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  if (param_1 + 10 != &uStack_20) {
    FUN_0068a760();
    param_1[10] = 0;
    param_1[0xb] = 0;
    param_1[0xc] = 0;
  }
  uStack_8 = 1;
  FUN_0068a760();
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::GuiObject,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::GuiObject::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29107 ; VA 0x00c6efd0 ; FUN_00c6efd0 */

undefined4 * __thiscall
FUN_00c6efd0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10)

{
  undefined4 uVar1;
  undefined auStack_1e8 [432];
  undefined8 uStack_38;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_0180d98c;
  pvStack_1c = ExceptionList;
  uStack_38 = param_7;
  ExceptionList = &pvStack_1c;
  puStack_30 = param_1;
  uVar1 = FUN_00c6dcc0();
  FUN_009cb970(uVar1,param_3,param_6,uStack_38,param_8);
  param_1[0xd] = param_2;
  iStack_14 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::GuiButton,void___cdecl(int,int),class_rbx::remote_signal<void___cdecl(int,int)>,class_rbx::remote_signal<void___cdecl(int,int)>_RBX::GuiButton::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_14._0_1_ = 1;
  FUN_0086e3d0(param_5);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_14._0_1_ = 2;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687810(auStack_1e8,&uStack_38,puStack_30);
  iStack_14._0_1_ = 3;
  if (param_1 + 10 != &uStack_2c) {
    FUN_0068a760();
    param_1[10] = uStack_2c;
    param_1[0xb] = uStack_28;
    param_1[0xc] = uStack_24;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
  }
  iStack_14._0_1_ = 4;
  FUN_0068a760();
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_016f32d1(auStack_1e8,0xd8,2,FUN_00688b10);
  param_1[0xe] = param_10;
  param_1[0xf] = param_9;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::GuiButton,void___cdecl(int,int),class_rbx::remote_signal<void___cdecl(int,int)>,class_rbx::remote_signal<void___cdecl(int,int)>_RBX::GuiButton::*>
             ::vftable;
  ExceptionList = pvStack_1c;
  return param_1;
}



/* FUNCTION 29108 ; VA 0x00c6f150 ; FUN_00c6f150 */

undefined4 * __thiscall
FUN_00c6f150(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined8 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uStack_18 = param_5;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00c6dcc0();
  FUN_009cb970(uVar1,param_3,param_4,uStack_18,param_6);
  param_1[0xd] = param_2;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::GuiButton,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::GuiButton::*>
             ::vftable;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = 0;
    param_1[0xb] = 0;
    param_1[0xc] = 0;
  }
  uStack_8 = 1;
  FUN_0068a760();
  param_1[0xe] = param_8;
  param_1[0xf] = param_7;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::GuiButton,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::GuiButton::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29109 ; VA 0x00c6f230 ; FUN_00c6f230 */

undefined4 * __thiscall
FUN_00c6f230(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10)

{
  undefined4 uVar1;
  undefined auStack_1e8 [432];
  undefined8 uStack_38;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_0180d9cc;
  pvStack_1c = ExceptionList;
  uStack_38 = param_7;
  ExceptionList = &pvStack_1c;
  puStack_30 = param_1;
  uVar1 = FUN_00c6de80();
  FUN_009cb970(uVar1,param_3,param_6,uStack_38,param_8);
  param_1[0xd] = param_2;
  iStack_14 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::GuiObject,void___cdecl(int,int),class_rbx::remote_signal<void___cdecl(int,int)>,class_rbx::remote_signal<void___cdecl(int,int)>_RBX::GuiObject::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_14._0_1_ = 1;
  FUN_0086e3d0(param_5);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_14._0_1_ = 2;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687810(auStack_1e8,&uStack_38,puStack_30);
  iStack_14._0_1_ = 3;
  if (param_1 + 10 != &uStack_2c) {
    FUN_0068a760();
    param_1[10] = uStack_2c;
    param_1[0xb] = uStack_28;
    param_1[0xc] = uStack_24;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
  }
  iStack_14._0_1_ = 4;
  FUN_0068a760();
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_016f32d1(auStack_1e8,0xd8,2,FUN_00688b10);
  param_1[0xe] = param_10;
  param_1[0xf] = param_9;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::GuiObject,void___cdecl(int,int),class_rbx::remote_signal<void___cdecl(int,int)>,class_rbx::remote_signal<void___cdecl(int,int)>_RBX::GuiObject::*>
             ::vftable;
  ExceptionList = pvStack_1c;
  return param_1;
}



/* FUNCTION 29110 ; VA 0x00c6f3b0 ; FUN_00c6f3b0 */

undefined4 * __thiscall FUN_00c6f3b0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9dc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  uStack_8 = 0;
  FUN_00d88580(param_2 + 3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29111 ; VA 0x00c6f430 ; FUN_00c6f430 */

undefined4 * __thiscall FUN_00c6f430(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d9e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00c6f840(param_2,1);
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::GuiButton,class_RBX::GuiObject>::vftable;
  param_1[0x15] = RBX::Described<class_RBX::GuiButton,class_RBX::GuiObject>::vftable;
  uVar1 = FUN_00c6dcc0();
  param_1[3] = uVar1;
  *param_1 = RBX::GuiButton::vftable;
  param_1[0x15] = RBX::GuiButton::vftable;
  param_1[0xd2] = 0;
  param_1[0xd3] = 0;
  param_1[0xd4] = 0;
  param_1[0xd5] = 0;
  param_1[0xd6] = 0;
  param_1[0xd7] = 0;
  param_1[0xd8] = 0;
  param_1[0xd9] = 0;
  param_1[0xda] = 0;
  param_1[0xdb] = 0;
  param_1[0xdc] = 0;
  param_1[0xdd] = 0;
  param_1[0xde] = 0;
  param_1[0xdf] = 0;
  param_1[0xe0] = 0;
  param_1[0xe1] = 0;
  param_1[0xe2] = 0;
  param_1[0xe3] = 0;
  param_1[0xe4] = 0;
  param_1[0xe5] = 0;
  param_1[0xe6] = 0;
  param_1[0xe7] = 0;
  param_1[0xe8] = 0;
  param_1[0xe9] = 0;
  param_1[0xea] = 0;
  param_1[0xeb] = 0;
  param_1[0xf0] = param_1 + 0xe0;
  param_1[0xed] = &DAT_02138f60;
  param_1[0xee] = 0;
  param_1[0xef] = &DAT_02138de0;
  param_1[0xf1] = 0;
  param_1[0xf2] = 0;
  param_1[0xec] = RBX::EventReplicator<class_RBX::GuiButton,void___cdecl(void)>::vftable;
  param_1[0xf3] = 0;
  param_1[0xf8] = param_1 + 0xe2;
  param_1[0xf5] = &DAT_02138f98;
  param_1[0xf6] = 0;
  param_1[0xf7] = &DAT_02138e20;
  param_1[0xf9] = 0;
  param_1[0xfa] = 0;
  param_1[0xf4] = RBX::EventReplicator<class_RBX::GuiButton,void___cdecl(void)>::vftable;
  param_1[0xfb] = 0;
  param_1[0x100] = param_1 + 0xe4;
  param_1[0xfd] = &DAT_02138fd0;
  param_1[0xfe] = 0;
  param_1[0xff] = &DAT_02138e60;
  param_1[0x101] = 0;
  param_1[0x102] = 0;
  param_1[0xfc] = RBX::EventReplicator<class_RBX::GuiButton,void___cdecl(int,int)>::vftable;
  param_1[0x103] = 0;
  param_1[0x108] = param_1 + 0xe6;
  param_1[0x105] = &DAT_02139008;
  param_1[0x106] = 0;
  param_1[0x107] = &DAT_02138ea0;
  param_1[0x109] = 0;
  param_1[0x10a] = 0;
  param_1[0x104] = RBX::EventReplicator<class_RBX::GuiButton,void___cdecl(int,int)>::vftable;
  param_1[0x10b] = 0;
  param_1[0x10d] = &DAT_02139040;
  param_1[0x10e] = 0;
  param_1[0x10f] = &DAT_02138ee0;
  param_1[0x110] = param_1 + 0xe8;
  param_1[0x111] = 0;
  param_1[0x112] = 0;
  param_1[0x10c] = RBX::EventReplicator<class_RBX::GuiButton,void___cdecl(int,int)>::vftable;
  param_1[0x113] = 0;
  param_1[0x118] = param_1 + 0xea;
  param_1[0x115] = &DAT_02139078;
  param_1[0x116] = 0;
  param_1[0x117] = &DAT_02138f20;
  param_1[0x119] = 0;
  param_1[0x11a] = 0;
  param_1[0x114] = RBX::EventReplicator<class_RBX::GuiButton,void___cdecl(int,int)>::vftable;
  *(undefined2 *)(param_1 + 0x11b) = 1;
  *(undefined *)((int)param_1 + 0x46e) = 0;
  param_1[0x11c] = 0;
  param_1[0x11d] = 0;
  *(undefined *)((int)param_1 + 0x342) = 1;
  param_1[0xee] = param_1;
  param_1[0xf6] = param_1;
  param_1[0xfe] = param_1;
  param_1[0x106] = param_1;
  param_1[0x10e] = param_1;
  param_1[0x116] = param_1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29112 ; VA 0x00c6f7d0 ; FUN_00c6f7d0 */

undefined4 * __thiscall FUN_00c6f7d0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d9e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00c6f840(param_2,0);
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::GuiLabel,class_RBX::GuiObject>::vftable;
  param_1[0x15] = RBX::Described<class_RBX::GuiLabel,class_RBX::GuiObject>::vftable;
  uVar1 = FUN_00c6dda0();
  param_1[3] = uVar1;
  *param_1 = RBX::GuiLabel::vftable;
  param_1[0x15] = RBX::GuiLabel::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29113 ; VA 0x00c6f840 ; FUN_00c6f840 */

undefined4 * __thiscall FUN_00c6f840(undefined4 *param_1,undefined4 param_2,undefined param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180dbec;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00d5a510(param_2);
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::GuiObject,class_RBX::GuiBase2d>::vftable;
  param_1[0x15] = RBX::Described<class_RBX::GuiObject,class_RBX::GuiBase2d>::vftable;
  uVar1 = FUN_00c6de80();
  param_1[3] = uVar1;
  *param_1 = RBX::GuiObject::vftable;
  param_1[0x15] = RBX::GuiObject::vftable;
  param_1[0x52] = 0;
  *(undefined *)(param_1 + 0x53) = 0;
  param_1[0x54] = 0;
  param_1[0x55] = 0;
  param_1[0x56] = 0;
  param_1[0x57] = 0;
  param_1[0x58] = 0;
  param_1[0x59] = 0;
  param_1[0x5a] = 0;
  param_1[0x5b] = 0;
  param_1[0x5c] = 0;
  param_1[0x5d] = 0;
  param_1[0x5e] = 0x16;
  *(undefined2 *)(param_1 + 0x5f) = 0;
  param_1[0x60] = 0;
  param_1[0x61] = 0;
  param_1[0x62] = 0;
  param_1[99] = 0;
  param_1[100] = 0;
  param_1[0x65] = 0;
  param_1[0x67] = 0;
  param_1[0x68] = 0;
  param_1[0x69] = 0;
  param_1[0x6a] = 0;
  param_1[0x6b] = 0;
  param_1[0x6c] = 0;
  param_1[0x6d] = 0;
  param_1[0x6e] = 0;
  param_1[0x6f] = 0;
  param_1[0x70] = 0;
  param_1[0x71] = 0;
  param_1[0x72] = 0;
  param_1[0x73] = 0;
  param_1[0x74] = 0;
  param_1[0x75] = 0;
  param_1[0x76] = 0;
  param_1[0x77] = 0;
  param_1[0x78] = 0;
  param_1[0x79] = 0;
  param_1[0x7a] = 0;
  param_1[0x7b] = 0;
  param_1[0x7c] = 0;
  param_1[0x7d] = 0;
  param_1[0x7f] = &DAT_02138c1c;
  param_1[0x80] = 0;
  param_1[0x81] = &DAT_021386c8;
  param_1[0x82] = param_1 + 0x74;
  param_1[0x83] = 0;
  param_1[0x84] = 0;
  param_1[0x7e] = RBX::EventReplicator<class_RBX::GuiObject,void___cdecl(int,int)>::vftable;
  param_1[0x85] = 0;
  param_1[0x87] = &DAT_02138c54;
  param_1[0x88] = 0;
  param_1[0x89] = &DAT_02138708;
  param_1[0x8a] = param_1 + 0x76;
  param_1[0x8b] = 0;
  param_1[0x8c] = 0;
  param_1[0x86] = RBX::EventReplicator<class_RBX::GuiObject,void___cdecl(int,int)>::vftable;
  param_1[0x8d] = 0;
  param_1[0x8f] = &DAT_02138c8c;
  param_1[0x90] = 0;
  param_1[0x91] = &DAT_02138748;
  param_1[0x92] = param_1 + 0x78;
  param_1[0x93] = 0;
  param_1[0x94] = 0;
  param_1[0x8e] = RBX::EventReplicator<class_RBX::GuiObject,void___cdecl(int,int)>::vftable;
  param_1[0x95] = 0;
  param_1[0x97] = &DAT_02138cc4;
  param_1[0x98] = 0;
  param_1[0x99] = &DAT_02138788;
  param_1[0x9a] = param_1 + 0x7a;
  param_1[0x9b] = 0;
  param_1[0x9c] = 0;
  param_1[0x96] = RBX::EventReplicator<class_RBX::GuiObject,void___cdecl(int,int)>::vftable;
  param_1[0x9d] = 0;
  param_1[0x9f] = &DAT_02138cfc;
  param_1[0xa0] = 0;
  param_1[0xa1] = &DAT_021387c8;
  param_1[0xa2] = param_1 + 0x7c;
  param_1[0xa3] = 0;
  param_1[0xa4] = 0;
  param_1[0x9e] = RBX::EventReplicator<class_RBX::GuiObject,void___cdecl(int,int)>::vftable;
  param_1[0xa5] = 0;
  param_1[0xa6] = 0;
  param_1[0xa7] = 0;
  param_1[0xa8] = 0;
  param_1[0xa9] = 0;
  param_1[0xab] = &DAT_02138d34;
  param_1[0xac] = 0;
  param_1[0xad] = &DAT_02138808;
  param_1[0xae] = param_1 + 0xa6;
  param_1[0xaf] = 0;
  param_1[0xb0] = 0;
  param_1[0xaa] = RBX::EventReplicator<class_RBX::GuiObject,void___cdecl(int,int)>::vftable;
  param_1[0xb1] = 0;
  param_1[0xb3] = &DAT_02138d6c;
  param_1[0xb4] = 0;
  param_1[0xb5] = &DAT_02138848;
  param_1[0xb6] = param_1 + 0xa8;
  param_1[0xb7] = 0;
  param_1[0xb8] = 0;
  param_1[0xb2] = RBX::EventReplicator<class_RBX::GuiObject,void___cdecl(class_RBX::UDim2)>::vftable
  ;
  *(undefined2 *)(param_1 + 0xb9) = 0;
  param_1[0xba] = 0;
  uStack_8 = 0x23;
  param_1[0xbb] = 0;
  param_1[0xbc] = 0;
  param_1[0xbd] = 0;
  param_1[0xbe] = 0;
  param_1[0xbf] = 0;
  param_1[0xc0] = 0;
  param_1[0xc1] = 0;
  param_1[0xc2] = 0;
  param_1[0xc3] = 0;
  param_1[0xc4] = 0;
  param_1[0xc5] = 0x3f800000;
  param_1[0xc6] = 0;
  param_1[199] = 0;
  param_1[200] = 1;
  param_1[0xc9] = 0;
  FUN_00c98ad0(param_1 + 0xca);
  FUN_00c98ad0(param_1 + 0xcd);
  *(undefined *)((int)param_1 + 0x341) = param_3;
  *(undefined *)(param_1 + 0xd0) = 1;
  *(undefined *)((int)param_1 + 0x342) = 0;
  param_1[0xd1] = 0;
  param_1[0x80] = param_1;
  param_1[0x88] = param_1;
  param_1[0x90] = param_1;
  param_1[0xac] = param_1;
  param_1[0xb4] = param_1;
  param_1[0x98] = param_1;
  param_1[0xa0] = param_1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29114 ; VA 0x00c6fde0 ; FUN_00c6fde0 */

void __fastcall FUN_00c6fde0(int param_1)

{
  if (*(int **)(param_1 + 0x58) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0x58) + 4))(1);
  }
  if (*(int *)(param_1 + 0x54) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x54),1);
  }
  if (*(int *)(param_1 + 0x50) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x50),4);
  }
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0x10);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),0x10);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 29115 ; VA 0x00c6fe70 ; FUN_00c6fe70 */

void __fastcall FUN_00c6fe70(int param_1)

{
  if (*(int **)(param_1 + 0x54) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0x54) + 4))(1);
  }
  if (*(int *)(param_1 + 0x50) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x50),1);
  }
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),0x10);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 29116 ; VA 0x00c6fef0 ; FUN_00c6fef0 */

void __fastcall FUN_00c6fef0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::EventReplicatorBase<class_RBX::GuiButton,void___cdecl(int,int)>::vftable;
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  iVar3 = param_1[6];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  iVar3 = param_1[5];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29117 ; VA 0x00c6ff90 ; FUN_00c6ff90 */

void __fastcall FUN_00c6ff90(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::EventReplicatorBase<class_RBX::GuiButton,void___cdecl(void)>::vftable;
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  cVar4 = FUN_016793f0();
  if (cVar4 != '\0') {
    FUN_01679490();
  }
  iVar3 = param_1[6];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  iVar3 = param_1[5];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29118 ; VA 0x00c70030 ; FUN_00c70030 */

void __fastcall FUN_00c70030(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x474);
  ExceptionList = &pvStack_10;
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + -4);
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_016f32d1(iVar4,0x44,*(undefined4 *)(iVar4 + -4),FUN_0091a630);
    FUN_01674ea0(piVar1,(*piVar1 * 0x10 + *piVar1) * 4 + 4);
  }
  FUN_00c6fef0();
  FUN_00c6fef0();
  FUN_00c6fef0();
  FUN_00c6fef0();
  FUN_00c6ff90();
  FUN_00c6ff90();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  iVar4 = *(int *)(param_1 + 0x374);
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  iVar4 = *(int *)(param_1 + 0x370);
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  iVar4 = *(int *)(param_1 + 0x36c);
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  iVar4 = *(int *)(param_1 + 0x368);
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  piVar1 = *(int **)(param_1 + 0x364);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[2] + -1;
    piVar1[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar1 = *(int **)(param_1 + 0x35c);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[2] + -1;
    piVar1[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar1 = *(int **)(param_1 + 0x354);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[2] + -1;
    piVar1[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar1 = *(int **)(param_1 + 0x34c);
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar2 = piVar1 + 2;
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_00c32d60();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29119 ; VA 0x00c70260 ; FUN_00c70260 */

uint * __thiscall FUN_00c70260(uint *param_1,uint *param_2)

{
  uint uVar1;
  uint auStack_50 [2];
  undefined auStack_48 [24];
  uint auStack_30 [2];
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180dc10;
  pvStack_10 = ExceptionList;
  auStack_30[0] = 0;
  uVar1 = *param_2;
  ExceptionList = &pvStack_10;
  if (uVar1 != 0) {
    auStack_30[0] = uVar1;
    if ((uVar1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 2,&uStack_28,0);
    }
    else {
      uStack_28 = param_2[2];
      uStack_24 = param_2[3];
      uStack_20 = param_2[4];
      uStack_1c = param_2[5];
      uStack_18 = *(undefined8 *)(param_2 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  if (param_1 != auStack_30) {
    auStack_50[0] = 0;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    FUN_005880d0(auStack_30);
    FUN_005880d0(param_1);
    FUN_005880d0(auStack_50);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (auStack_50[0] != 0) {
      if (((auStack_50[0] & 1) == 0) && (*(code **)(auStack_50[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_50[0] & 0xfffffffe))(auStack_48,auStack_48,2);
      }
      auStack_50[0] = 0;
    }
  }
  uStack_8 = 3;
  if (((auStack_30[0] != 0) && ((auStack_30[0] & 1) == 0)) &&
     (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_30[0] & 0xfffffffe))(&uStack_28,&uStack_28,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29120 ; VA 0x00c70360 ; FUN_00c70360 */

int __thiscall FUN_00c70360(undefined4 *param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180dc28;
  pvStack_10 = ExceptionList;
  if (param_2 == 2) {
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00587490(&iStack_1c);
    uStack_8 = 0;
    if (iStack_1c != 0) {
      FUN_01679490();
      iVar3 = FUN_008f7870(iStack_1c);
      if (iVar3 == 0) {
        *(undefined4 *)(iStack_1c + 0x358) = 0;
        piVar5 = *(int **)(iStack_1c + 0x35c);
        *(undefined4 *)(iStack_1c + 0x35c) = 0;
        iVar3 = 0;
        if (piVar5 != (int *)0x0) {
          LOCK();
          piVar1 = piVar5 + 2;
          iVar4 = *piVar1;
          iVar3 = *piVar1;
          *piVar1 = iVar4 + -1;
          UNLOCK();
          if (iVar4 + -1 == 0) {
            iVar3 = (**(code **)(*piVar5 + 4))();
          }
        }
      }
      else {
        piVar5 = (int *)param_1[1];
        if (piVar5 != (int *)0x0) {
          LOCK();
          piVar5[2] = piVar5[2] + 1;
          UNLOCK();
          piVar5 = (int *)param_1[1];
        }
        uVar2 = *param_1;
        piVar1 = piVar5 + 2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        FUN_00c6d690(uVar2,piVar5,0);
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar3 = *piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
        iVar3 = FUN_0090ca30();
      }
    }
    if (piStack_18 == (int *)0x0) {
      ExceptionList = pvStack_10;
      return iVar3;
    }
    LOCK();
    piVar5 = piStack_18 + 1;
    iVar3 = *piVar5;
    iVar4 = *piVar5;
    *piVar5 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 != 0) {
      ExceptionList = pvStack_10;
      return iVar4;
    }
    iVar4 = (**(code **)*piStack_18)();
    LOCK();
    piVar5 = piStack_18 + 2;
    iVar3 = *piVar5;
    *piVar5 = *piVar5 + -1;
    UNLOCK();
    if (iVar3 != 1) {
      ExceptionList = pvStack_10;
      return iVar4;
    }
    iVar3 = *piStack_18;
  }
  else {
    if (param_2 != 3) {
      return param_2;
    }
    ExceptionList = &pvStack_10;
    FUN_01679490();
    iVar3 = param_1[2];
    *(undefined4 *)(iVar3 + 0x358) = 0;
    piVar5 = *(int **)(iVar3 + 0x35c);
    *(undefined4 *)(iVar3 + 0x35c) = 0;
    if (piVar5 == (int *)0x0) {
      ExceptionList = pvStack_10;
      return iVar3;
    }
    LOCK();
    piVar1 = piVar5 + 2;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 != 0) {
      ExceptionList = pvStack_10;
      return iVar4;
    }
    iVar3 = *piVar5;
  }
  iVar3 = (**(code **)(iVar3 + 4))();
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 29121 ; VA 0x00c704d0 ; FUN_00c704d0 */

void __thiscall FUN_00c704d0(int *param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  float *pfVar6;
  int *piVar7;
  float fVar8;
  undefined auStack_30 [8];
  int iStack_28;
  int *piStack_24;
  float fStack_20;
  float fStack_1c;
  int *piStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbe88;
  pvStack_10 = ExceptionList;
  if (param_2 == &DAT_02141028) {
    iVar1 = *param_1;
    iVar5 = *(int *)(iVar1 + 0x18c);
    if (*(int *)(iVar5 + 0x5c) == 2) {
      piVar7 = *(int **)(iVar1 + 400);
      ExceptionList = &pvStack_10;
      if (piVar7 != (int *)0x0) {
        LOCK();
        ExceptionList = &pvStack_10;
        piVar7[1] = piVar7[1] + 1;
        UNLOCK();
        iVar5 = *(int *)(iVar1 + 0x18c);
        piVar7 = *(int **)(iVar1 + 400);
      }
      uStack_8 = 0;
      iStack_28 = iVar5;
      piStack_24 = piVar7;
      piStack_18 = param_1;
      if (((iVar5 != 0) &&
          (iVar2 = *(int *)(iVar5 + 0xc), iVar4 = FUN_00d7fd90(),
          (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
          (uint)*(ushort *)(iVar4 + 0x1da))) && (*(int *)(iVar1 + 0x18c) == iVar5)) {
        FUN_01679490();
        FUN_00d814c0(&fStack_20);
        fStack_14 = fStack_1c;
        iVar5 = FUN_006ebc30(iVar1);
        fVar8 = fStack_14;
        if ((iVar5 != 0) && (*(char *)(iVar1 + 0x14c) != '\0')) {
          pfVar6 = (float *)FUN_01126580(auStack_30);
          fStack_20 = fStack_20 - *pfVar6;
          fVar8 = fStack_14 - pfVar6[1];
        }
        FUN_006150c0((int)fStack_20,(int)fVar8);
        *(undefined4 *)(iVar1 + 0x18c) = 0;
        piVar3 = *(int **)(iVar1 + 400);
        *(undefined4 *)(iVar1 + 400) = 0;
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar5 = piVar3[1] + -1;
          piVar3[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar5 = piVar3[2] + -1;
            piVar3[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        *(undefined *)(iVar1 + 0x17d) = 0;
      }
      uStack_8 = 0xffffffff;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar1 = piVar7[1] + -1;
        piVar7[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          piVar3 = piVar7 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      FUN_01679490();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29122 ; VA 0x00c706a0 ; FUN_00c706a0 */

int __thiscall FUN_00c706a0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int iStack_20;
  int *piStack_1c;
  int aiStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180dc48;
  pvStack_10 = ExceptionList;
  if (param_2 == 2) {
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00587490(&iStack_20);
    uStack_8 = 0;
    if (iStack_20 != 0) {
      FUN_01679490();
      FUN_01679490();
      iVar3 = FUN_008f7870(iStack_20);
      if (iVar3 == 0) {
        FUN_00587490(aiStack_18);
        if (aiStack_18[0] != 0) {
          FUN_00c44b70();
        }
        iVar3 = FUN_00550b30();
      }
      else {
        piVar5 = (int *)param_1[1];
        if (piVar5 != (int *)0x0) {
          LOCK();
          piVar5[2] = piVar5[2] + 1;
          UNLOCK();
          piVar5 = (int *)param_1[1];
        }
        uVar2 = *param_1;
        piVar1 = piVar5 + 2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        FUN_00c6d560(uVar2,piVar5,0);
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar3 = *piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
        iVar3 = FUN_0090ca30();
      }
    }
    if (piStack_1c == (int *)0x0) {
      ExceptionList = pvStack_10;
      return iVar3;
    }
    LOCK();
    piVar5 = piStack_1c + 1;
    iVar3 = *piVar5;
    iVar4 = *piVar5;
    *piVar5 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 != 0) {
      ExceptionList = pvStack_10;
      return iVar4;
    }
    iVar4 = (**(code **)*piStack_1c)();
    LOCK();
    piVar5 = piStack_1c + 2;
    iVar3 = *piVar5;
    *piVar5 = *piVar5 + -1;
    UNLOCK();
    if (iVar3 != 1) {
      ExceptionList = pvStack_10;
      return iVar4;
    }
    iVar3 = *piStack_1c;
  }
  else {
    if (param_2 != 3) {
      return param_2;
    }
    ExceptionList = &pvStack_10;
    FUN_01679490();
    iVar3 = param_1[2];
    *(undefined4 *)(iVar3 + 0x350) = 0;
    piVar5 = *(int **)(iVar3 + 0x354);
    *(undefined4 *)(iVar3 + 0x354) = 0;
    if (piVar5 == (int *)0x0) {
      ExceptionList = pvStack_10;
      return iVar3;
    }
    LOCK();
    piVar1 = piVar5 + 2;
    iVar3 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 != 0) {
      ExceptionList = pvStack_10;
      return iVar4;
    }
    iVar3 = *piVar5;
  }
  iVar3 = (**(code **)(iVar3 + 4))();
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 29123 ; VA 0x00c70820 ; FUN_00c70820 */

void __thiscall
FUN_00c70820(uint *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792078;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)((*param_1 & 0xfffffffe) + 4))(param_1 + 2,param_2,param_3,param_4,param_5,param_6);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0054fda0();
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar1);
}



/* FUNCTION 29124 ; VA 0x00c70890 ; FUN_00c70890 */

/* WARNING: Removing unreachable block (ram,0x00c708e2) */
/* WARNING: Removing unreachable block (ram,0x00c708f2) */
/* WARNING: Removing unreachable block (ram,0x00c708f8) */

void * __thiscall FUN_00c70890(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180dc78;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 29125 ; VA 0x00c7097c ; Catch@00c7097c */

undefined * Catch_00c7097c(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00c7098d;
}



/* FUNCTION 29126 ; VA 0x00c709a0 ; FUN_00c709a0 */

/* WARNING: Removing unreachable block (ram,0x00c709f2) */
/* WARNING: Removing unreachable block (ram,0x00c70a02) */
/* WARNING: Removing unreachable block (ram,0x00c70a08) */

void * __thiscall FUN_00c709a0(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180dca8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 29127 ; VA 0x00c70a82 ; Catch@00c70a82 */

undefined * Catch_00c70a82(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00c70a93;
}



/* FUNCTION 29128 ; VA 0x00c70ab0 ; FUN_00c70ab0 */

undefined4 __thiscall FUN_00c70ab0(undefined4 param_1,byte param_2)

{
  FUN_00c6fde0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x60);
  }
  return param_1;
}



/* FUNCTION 29129 ; VA 0x00c70ae0 ; FUN_00c70ae0 */

undefined4 __thiscall FUN_00c70ae0(undefined4 param_1,byte param_2)

{
  FUN_00c6fe70();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 29130 ; VA 0x00c70b10 ; FUN_00c70b10 */

undefined4 __thiscall FUN_00c70b10(undefined4 param_1,byte param_2)

{
  FUN_00d5a740();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x148);
  }
  return param_1;
}



/* FUNCTION 29131 ; VA 0x00c70b40 ; FUN_00c70b40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c70b40(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::GuiObject::AutomaticSize>::vftable;
  _DAT_01eff178 = _DAT_01eff178 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 29132 ; VA 0x00c70b70 ; FUN_00c70b70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c70b70(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::GuiObject::BorderMode>::vftable;
  _DAT_01eff160 = _DAT_01eff160 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 29133 ; VA 0x00c70ba0 ; FUN_00c70ba0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c70ba0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::GuiObject::ImageScale>::vftable;
  _DAT_01eff170 = _DAT_01eff170 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 29134 ; VA 0x00c70bd0 ; FUN_00c70bd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c70bd0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::GuiObject::SizeConstraint>::vftable;
  _DAT_01eff168 = _DAT_01eff168 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 29135 ; VA 0x00c70c00 ; FUN_00c70c00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c70c00(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::GuiButton::Style>::vftable;
  _DAT_01eff180 = _DAT_01eff180 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 29136 ; VA 0x00c70c30 ; FUN_00c70c30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c70c30(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::TweenInfo::TweenEasingDirection>::vftable;
  _DAT_01f102f8 = _DAT_01f102f8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 29137 ; VA 0x00c70c60 ; FUN_00c70c60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c70c60(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::TweenInfo::TweenEasingStyle>::vftable;
  _DAT_01f102e8 = _DAT_01f102e8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 29138 ; VA 0x00c70c90 ; FUN_00c70c90 */

undefined4 * __thiscall FUN_00c70c90(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::GuiButton::Style>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 29139 ; VA 0x00c70cc0 ; FUN_00c70cc0 */

undefined4 * __thiscall FUN_00c70cc0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::UDim2>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 29140 ; VA 0x00c70cf0 ; FUN_00c70cf0 */

undefined4 * __thiscall FUN_00c70cf0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::GuiObject::AutomaticSize>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 29141 ; VA 0x00c70d20 ; FUN_00c70d20 */

undefined4 * __thiscall FUN_00c70d20(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::GuiObject::BorderMode>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 29142 ; VA 0x00c70d50 ; FUN_00c70d50 */

undefined4 * __thiscall FUN_00c70d50(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::GuiObject::SizeConstraint>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 29143 ; VA 0x00c70d80 ; FUN_00c70d80 */

undefined4 * __thiscall FUN_00c70d80(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::UDim2>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 29144 ; VA 0x00c70db0 ; FUN_00c70db0 */

undefined4 * __thiscall FUN_00c70db0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::GuiObject::AutomaticSize>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 29145 ; VA 0x00c70de0 ; FUN_00c70de0 */

undefined4 * __thiscall FUN_00c70de0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::GuiObject::BorderMode>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 29146 ; VA 0x00c70e10 ; FUN_00c70e10 */

undefined4 * __thiscall FUN_00c70e10(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::GuiObject::SizeConstraint>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 29147 ; VA 0x00c70e40 ; FUN_00c70e40 */

undefined4 * __thiscall FUN_00c70e40(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::GuiButton::Style>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 29148 ; VA 0x00c70e70 ; FUN_00c70e70 */

undefined4 __thiscall FUN_00c70e70(undefined4 param_1,byte param_2)

{
  FUN_00c70030();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x478);
  }
  return param_1;
}



/* FUNCTION 29149 ; VA 0x00c70ea0 ; FUN_00c70ea0 */

float * __thiscall FUN_00c70ea0(int param_1,float *param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  
  fVar2 = *param_3 + 0.0;
  fVar1 = param_3[1] + 0.0;
  param_2[3] = 0.0;
  fVar7 = fVar2;
  if (0.0 <= fVar2) {
    fVar7 = 0.0;
  }
  *param_2 = fVar7;
  fVar5 = fVar1;
  if (0.0 <= fVar1) {
    fVar5 = 0.0;
  }
  param_2[1] = fVar5;
  if (fVar2 <= 0.0) {
    fVar2 = 0.0;
  }
  param_2[2] = fVar2;
  if (fVar1 <= 0.0) {
    fVar1 = 0.0;
  }
  param_2[3] = fVar1;
  switch(*(undefined4 *)(param_1 + 0x470)) {
  case 1:
  case 2:
    fVar4 = (fVar2 - fVar7) / DAT_0196f8c8;
    if (DAT_018ce2f8 <= fVar4) {
      fVar4 = DAT_018ce2f8;
    }
    fVar3 = (fVar1 - fVar5) / DAT_0196f8c8;
    if (fVar4 <= fVar3) {
      fVar3 = fVar4;
    }
    fVar3 = fVar3 * DAT_019399c0;
    fVar4 = fVar3 + fVar5;
    fVar6 = fVar3 + fVar7;
    fVar2 = ((fVar2 - fVar7) - (fVar3 + fVar3)) + fVar6;
    fVar7 = ((fVar1 - fVar5) - (fVar3 + fVar3)) + fVar4;
    fVar1 = fVar6;
    if (fVar2 < fVar6) {
      fVar1 = fVar2;
    }
    fVar5 = fVar4;
    if (fVar7 < fVar4) {
      fVar5 = fVar7;
    }
    if (fVar2 <= fVar6) {
      fVar2 = fVar6;
    }
    if (fVar7 <= fVar4) {
      fVar7 = fVar4;
    }
    *param_2 = fVar1;
    break;
  case 3:
  case 4:
  case 5:
    fVar4 = (fVar2 - fVar7) / DAT_0196f8c4;
    if (DAT_018ce2f8 <= fVar4) {
      fVar4 = DAT_018ce2f8;
    }
    fVar3 = (fVar1 - fVar5) / DAT_0196f8c4;
    if (fVar4 <= fVar3) {
      fVar3 = fVar4;
    }
    fVar3 = fVar3 * DAT_019399c0;
    fVar4 = fVar3 + fVar5;
    fVar6 = fVar3 + fVar7;
    fVar2 = ((fVar2 - fVar7) - (fVar3 + fVar3)) + fVar6;
    fVar7 = ((fVar1 - fVar5) - (fVar3 + fVar3)) + fVar4;
    fVar1 = fVar6;
    if (fVar2 < fVar6) {
      fVar1 = fVar2;
    }
    fVar5 = fVar4;
    if (fVar7 < fVar4) {
      fVar5 = fVar7;
    }
    if (fVar2 <= fVar6) {
      fVar2 = fVar6;
    }
    if (fVar7 <= fVar4) {
      fVar7 = fVar4;
    }
    *param_2 = fVar1;
    break;
  default:
    goto switchD_00c70f0d_caseD_5;
  }
  param_2[1] = fVar5;
  param_2[3] = fVar7;
  param_2[2] = fVar2;
switchD_00c70f0d_caseD_5:
  return param_2;
}



/* FUNCTION 29150 ; VA 0x00c71060 ; FUN_00c71060 */

undefined4 __thiscall
FUN_00c71060(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  (**(code **)(*param_1 + 0xe0))(&fStack_14,param_3,param_4);
  fVar4 = (float)param_1[200];
  if (param_1[0xc9] == 2) {
    fVar1 = fVar4 + fStack_10;
    fVar3 = fStack_8 - fVar4;
    fVar2 = fStack_c - fVar4;
    fStack_c = fVar4 + fStack_14;
    fStack_10 = fVar3;
    if (fVar1 < fVar3) {
      fStack_10 = fVar1;
    }
    fStack_14 = fVar2;
    if (fStack_c < fVar2) {
      fStack_14 = fStack_c;
    }
    fStack_8 = fVar1;
    if (fVar1 <= fVar3) {
      fStack_8 = fVar3;
    }
    if (fStack_c <= fVar2) {
      fStack_c = fVar2;
    }
  }
  else if (param_1[0xc9] == 1) {
    fVar4 = fVar4 * DAT_018ce2f4;
    fVar2 = fStack_10 + fVar4;
    fVar3 = fStack_8 - fVar4;
    fVar1 = fStack_c - fVar4;
    fStack_c = fStack_14 + fVar4;
    fStack_10 = fVar3;
    if (fVar2 < fVar3) {
      fStack_10 = fVar2;
    }
    fStack_14 = fVar1;
    if (fStack_c < fVar1) {
      fStack_14 = fStack_c;
    }
    fStack_8 = fVar2;
    if (fVar2 <= fVar3) {
      fStack_8 = fVar3;
    }
    if (fStack_c <= fVar1) {
      fStack_c = fVar1;
    }
  }
  (**(code **)(*param_1 + 0xe8))(param_2,fStack_14,fStack_10,fStack_c,fStack_8);
  return param_2;
}



/* FUNCTION 29151 ; VA 0x00c71180 ; FUN_00c71180 */

void FUN_00c71180(float *param_1,float *param_2,float *param_3,undefined4 *param_4)

{
  float fVar1;
  float fVar2;
  undefined4 *puVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  uint in_stack_00000024;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f3258;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  fVar1 = param_2[1];
  fVar2 = *param_2;
  fVar7 = fVar1 + param_1[3];
  fVar6 = fVar1 + param_1[1];
  fVar4 = fVar2 + param_1[2];
  fVar5 = fVar2 + *param_1;
  param_1 = (float *)fVar7;
  if (fVar6 < fVar7) {
    param_1 = (float *)fVar6;
  }
  param_2 = (float *)fVar4;
  if (fVar5 < fVar4) {
    param_2 = (float *)fVar5;
  }
  if (fVar6 <= fVar7) {
    fVar6 = fVar7;
  }
  if (fVar5 <= fVar4) {
    fVar5 = fVar4;
  }
  fVar8 = fVar2 + *param_3;
  fVar7 = param_3[1] + fVar1;
  fVar4 = fVar8;
  if (fVar8 <= fVar2) {
    fVar4 = fVar2;
  }
  if (fVar2 <= fVar8) {
    fVar8 = fVar2;
  }
  fVar2 = fVar7;
  if (fVar7 <= fVar1) {
    fVar2 = fVar1;
  }
  if (fVar1 <= fVar7) {
    fVar7 = fVar1;
  }
  if (((((NAN(fVar8) == (fVar8 == 0.0)) || (NAN(fVar7) == (fVar7 == 0.0))) ||
       (NAN(fVar4) == (fVar4 == 0.0))) ||
      (ExceptionList = &pvStack_10, NAN(fVar2) == (fVar2 == 0.0))) &&
     ((((float)param_2 < fVar8 || ((float)param_1 < fVar7)) ||
      ((fVar4 < fVar5 || (ExceptionList = &pvStack_10, fVar2 < fVar6)))))) {
    puVar3 = &param_4;
    if (0xf < in_stack_00000024) {
      puVar3 = param_4;
    }
    ExceptionList = &pvStack_10;
    FUN_0086f2f0(2,
                 "SliceCenter ((%f,%f), (%f,%f)) is outside the bounds of imageOffset ((%f,%f), (%f,%f)) for GuiImage[%s]"
                 ,(double)(float)param_2,(double)(float)param_1,(double)fVar5,(double)fVar6,
                 (double)fVar8,(double)fVar7,(double)fVar4,(double)fVar2,puVar3);
  }
  if (0xf < in_stack_00000024) {
    if ((0xfff < in_stack_00000024 + 1) && (0x1f < (uint)((int)param_4 + (-4 - param_4[-1])))) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29152 ; VA 0x00c71320 ; FUN_00c71320 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00c71320(undefined4 param_1,int *param_2)

{
  int *piVar1;
  undefined *puVar2;
  undefined uVar3;
  undefined3 uVar4;
  int iVar5;
  int iVar6;
  int *in_stack_00000020;
  undefined4 in_stack_0000002c;
  undefined4 uStack_10c;
  undefined *puStack_108;
  undefined4 auStack_104 [50];
  undefined auStack_3c [4];
  int *piStack_38;
  int *piStack_30;
  int iStack_2c;
  int *piStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  piVar1 = in_stack_00000020;
  puStack_c = &LAB_0180df33;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffee8;
  piStack_24 = in_stack_00000020;
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + 1;
  UNLOCK();
  piStack_30 = in_stack_00000020;
  ExceptionList = &pvStack_10;
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *in_stack_00000020 = *in_stack_00000020 + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = uStack_8;
  uStack_8 = 2;
  uStack_7 = 0;
  puVar2 = &stack0xfffffee8;
  uVar4 = 0;
  if (in_stack_00000020 != (int *)0x0) {
    puVar2 = &stack0xfffffee8;
    if (in_stack_00000020[2] != 0) {
      FUN_00587490(&iStack_2c);
      uStack_8 = 3;
      if (iStack_2c != 0) {
        iVar6 = *(int *)(iStack_2c + 0x34);
        if ((iVar6 != 0) && (iStack_2c = iVar6, *(int *)(iVar6 + 0x34) != 0)) {
          iStack_2c = FUN_005c8ac0();
        }
        if (((iStack_2c != 0) &&
            (iVar6 = *(int *)(iStack_2c + 0xc), iVar5 = FUN_008a8c30(),
            (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
            (uint)*(ushort *)(iVar5 + 0x1da))) && (iVar6 = FUN_0055ea10(), iVar6 != 0)) {
          uStack_20 = 0;
          iStack_1c = 0;
          iStack_18 = 0;
          _uStack_8 = CONCAT31(uStack_7,4);
          uStack_10c = thunk_FUN_00da9580();
          auStack_104[0] = in_stack_0000002c;
          puStack_108 = (undefined *)0x0;
          if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) <
               DAT_01eff4dc) && (FUN_016f3809(&DAT_01eff4dc), DAT_01eff4dc == -1)) {
            _DAT_01eff4d0 = FUN_005c65e0;
            _DAT_01eff4d4 = FUN_005c65e0;
            DAT_01eff4d8 = _guard_check_icall;
            FUN_016f37bf(&DAT_01eff4dc);
          }
          puStack_108 = &DAT_01eff4d0;
          _uStack_8 = CONCAT31(uStack_7,5);
          if (iStack_18 == iStack_1c) {
            FUN_005ca4f0(iStack_1c,&uStack_10c);
          }
          else {
            FUN_005caaf0(&uStack_20);
            iStack_1c = iStack_1c + 0xd0;
          }
          uStack_8 = 6;
          if (puStack_108 != (undefined *)0x0) {
            (**(code **)(puStack_108 + 8))(auStack_104);
          }
          _uStack_8 = CONCAT31(uStack_7,7);
          FUN_0094b750(auStack_3c,&stack0x0000000c,&uStack_20);
          if (piStack_38 != (int *)0x0) {
            LOCK();
            iVar6 = piStack_38[1] + -1;
            piStack_38[1] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)*piStack_38)();
              LOCK();
              iVar6 = piStack_38[2] + -1;
              piStack_38[2] = iVar6;
              UNLOCK();
              if (iVar6 == 0) {
                (**(code **)(*piStack_38 + 4))();
                FUN_00c71503();
                return;
              }
            }
          }
          uStack_7 = 0;
          uStack_8 = 9;
          FUN_00577b20();
        }
      }
      puVar2 = puStack_14;
      uVar3 = uStack_8;
      uVar4 = uStack_7;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_28[1] + -1;
        piStack_28[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          iVar6 = piStack_28[2] + -1;
          piStack_28[2] = iVar6;
          UNLOCK();
          puVar2 = puStack_14;
          uVar3 = uStack_8;
          uVar4 = uStack_7;
          if (iVar6 == 0) {
            (**(code **)(*piStack_28 + 4))();
            puVar2 = puStack_14;
            uVar3 = uStack_8;
            uVar4 = uStack_7;
          }
        }
      }
    }
    uStack_7 = uVar4;
    uStack_8 = uVar3;
    puStack_14 = puVar2;
    puVar2 = puStack_14;
    uVar3 = uStack_8;
    uVar4 = uStack_7;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        FUN_00d88950();
        FUN_01674ea0(piVar1,0x10);
        puVar2 = puStack_14;
        uVar3 = uStack_8;
        uVar4 = uStack_7;
      }
    }
  }
  uStack_7 = uVar4;
  uStack_8 = uVar3;
  puStack_14 = puVar2;
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar6 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar6 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  FUN_00d88a30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29153 ; VA 0x00c714df ; Catch@00c714df */

undefined * Catch_00c714df(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x30) + 4))();
  FUN_0086f2f0(3,"Unexpected error while invoking callback: %s",uVar1);
  return &DAT_00c714fd;
}



/* FUNCTION 29154 ; VA 0x00c71503 ; FUN_00c71503 */

void FUN_00c71503(void)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int unaff_EBP;
  int unaff_ESI;
  int *unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 4;
  *(undefined *)(unaff_EBP + -4) = 9;
  FUN_00577b20();
  piVar2 = *(int **)(unaff_EBP + -0x24);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + unaff_ESI;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + unaff_ESI;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (unaff_EDI != (int *)0x0) {
    LOCK();
    iVar3 = *unaff_EDI;
    *unaff_EDI = *unaff_EDI + unaff_ESI;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_00d88950();
      FUN_01674ea0();
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  piVar2 = *(int **)(unaff_EBP + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + unaff_ESI;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_00d88a30();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 29155 ; VA 0x00c715f0 ; FUN_00c715f0 */

void FUN_00c715f0(float *param_1,float *param_2,float param_3,float param_4)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  
  fVar1 = param_2[2];
  fVar6 = *param_2;
  fVar5 = param_2[3] - param_2[1];
  fVar2 = (fVar1 - fVar6) / param_4;
  param_4 = fVar5 / param_4;
  if (DAT_018ce2f8 <= fVar2) {
    fVar2 = DAT_018ce2f8;
  }
  if (fVar2 <= param_4) {
    param_4 = fVar2;
  }
  param_4 = param_4 * param_3;
  fVar3 = param_4 + param_2[1];
  fVar4 = param_4 + *param_2;
  param_1[3] = 0.0;
  fVar2 = ((fVar1 - fVar6) - (param_4 + param_4)) + fVar4;
  fVar6 = (fVar5 - (param_4 + param_4)) + fVar3;
  fVar1 = fVar2;
  if (fVar4 <= fVar2) {
    fVar1 = fVar4;
  }
  *param_1 = fVar1;
  fVar1 = fVar3;
  if (fVar6 < fVar3) {
    fVar1 = fVar6;
  }
  param_1[1] = fVar1;
  if (fVar2 <= fVar4) {
    fVar2 = fVar4;
  }
  param_1[2] = fVar2;
  if (fVar6 <= fVar3) {
    fVar6 = fVar3;
  }
  param_1[3] = fVar6;
  return;
}



/* FUNCTION 29156 ; VA 0x00c716a0 ; FUN_00c716a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 *
FUN_00c716a0(undefined4 *param_1,int param_2,float param_3,float param_4,float param_5,
            undefined4 *param_6,undefined4 *param_7)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined *puVar3;
  float fVar4;
  undefined4 uVar5;
  double dVar6;
  double dVar7;
  undefined auStack_74 [16];
  undefined auStack_64 [16];
  undefined auStack_54 [16];
  undefined auStack_44 [16];
  undefined auStack_34 [16];
  undefined4 uStack_24;
  undefined4 uStack_20;
  double dStack_1c;
  undefined auStack_14 [8];
  undefined8 uStack_c;
  
  switch(param_3) {
  case 0.0:
    FUN_00da7ed0(&uStack_24,param_6);
    param_3 = param_4 / param_5;
    goto LAB_00c716da;
  case 1.4013e-45:
    param_3 = DAT_018ce2f8;
    if (param_2 == 0) {
      dVar7 = (double)((param_4 / param_5) * DAT_018f8ff0);
      FUN_017279f0();
      param_3 = DAT_018ce2f8 - (float)dVar7;
    }
    else if (param_2 == 1) {
      dVar7 = (double)((param_4 / param_5) * DAT_018f8ff0);
      FUN_01728390();
      param_3 = (float)dVar7;
    }
    else if (param_2 == 2) {
      dVar7 = (double)((param_4 * DAT_018f8ff4) / param_5);
      FUN_017279f0();
      param_3 = ((float)dVar7 - DAT_018ce2f8) * DAT_018f7860;
    }
    break;
  case 2.8026e-45:
    param_3 = DAT_018ce2f8;
    if (param_2 == 0) {
      param_4 = param_4 / param_5;
      param_3 = param_4 * param_4 * (param_4 * _DAT_0196f8c0 - _DAT_0196f850);
    }
    else if (param_2 == 1) {
      fVar4 = param_4 / param_5 - DAT_018ce2f8;
      param_3 = DAT_018ce2f8 + fVar4 * fVar4 * (fVar4 * _DAT_0196f8c0 + _DAT_0196f850);
    }
    else if (param_2 == 2) {
      param_4 = param_4 / (param_5 * DAT_018ce2f4);
      if (DAT_018ce2f8 <= param_4) {
        param_4 = param_4 - DAT_018daf58;
        param_3 = (float)((((double)param_4 * _DAT_0196f8a8 + _DAT_0196f840) *
                           (double)(param_4 * param_4) + DAT_018ce308) * _PTR_018cf0f8);
      }
      else {
        dVar7 = (double)param_4;
        param_3 = (float)(dVar7 * _PTR_018cf0f8 * dVar7 * (dVar7 * _DAT_0196f8a8 - _DAT_0196f8a0));
      }
    }
    goto LAB_00c718dd;
  case 4.2039e-45:
    param_3 = DAT_018ce2f8;
    if (param_2 == 0) {
      param_3 = (param_4 / param_5) * (param_4 / param_5);
    }
    else if (param_2 == 1) {
      param_3 = (float)((uint)((param_4 / param_5 - DAT_018daf58) * (param_4 / param_5)) ^
                       DAT_018c4ea0);
    }
    else if (param_2 == 2) {
      param_4 = param_4 / (param_5 * DAT_018ce2f4);
      if (DAT_018ce2f8 <= param_4) {
        param_3 = (float)((double)((param_4 - DAT_018ce2f8) * (param_4 - DAT_018df580) -
                                  DAT_018ce2f8) * DAT_0196f8d0);
      }
      else {
        param_3 = (float)((double)param_4 * _PTR_018cf0f8 * (double)param_4);
      }
    }
LAB_00c718dd:
    FUN_00da7ed0(&uStack_24,param_6);
    goto LAB_00c716da;
  case 5.60519e-45:
    param_3 = DAT_018ce2f8;
    if (param_2 == 0) {
      dVar7 = (double)(param_4 / param_5);
      FUN_01726ab0();
      param_3 = (float)dVar7;
    }
    else if (param_2 == 1) {
      dVar7 = (double)(param_4 / param_5 - DAT_018ce2f8);
      FUN_01726ab0();
      param_3 = (float)((uint)((float)dVar7 - DAT_018ce2f8) ^ DAT_018c4ea0);
    }
    else if (param_2 == 2) {
      param_4 = param_4 / (param_5 * DAT_018ce2f4);
      if (DAT_018ce2f8 <= param_4) {
        dVar7 = (double)(param_4 - DAT_018daf58);
        FUN_01726ab0();
        param_3 = (float)((double)((float)dVar7 - DAT_018daf58) * DAT_0196f8d0);
      }
      else {
LAB_00c71a0d:
        dVar7 = (double)param_4;
        FUN_01726ab0();
        param_3 = (float)((double)(float)dVar7 * _PTR_018cf0f8);
      }
    }
    break;
  case 7.00649e-45:
    param_3 = DAT_018ce2f8;
    if (param_2 == 0) {
      dVar7 = (double)(param_4 / param_5);
      FUN_01726ab0();
      param_3 = (float)dVar7;
    }
    else if (param_2 == 1) {
      dVar7 = (double)(param_4 / param_5 - DAT_018ce2f8);
      FUN_01726ab0();
      param_3 = (float)dVar7 + DAT_018ce2f8;
    }
    else if (param_2 == 2) {
      param_4 = param_4 / (param_5 * DAT_018ce2f4);
      if (param_4 < DAT_018ce2f8) goto LAB_00c71a0d;
      dVar7 = (double)(param_4 - DAT_018daf58);
      FUN_01726ab0();
      param_3 = (float)((double)((float)dVar7 + DAT_018daf58) * _PTR_018cf0f8);
    }
    break;
  case 8.40779e-45:
    if (param_2 == 0) {
      FUN_00da7ed0(auStack_74,param_6);
      uVar2 = FUN_00da7ed0(auStack_64,param_6);
      uStack_24 = 0;
      uStack_20 = 0;
      dStack_1c = 0.0;
      uVar2 = FUN_00c716a0(auStack_54,1,6,param_5 - param_4,param_5,&uStack_24,uVar2);
      FUN_00da7ed0(auStack_44,uVar2);
      FUN_00da7fd0(param_1,param_6);
      return param_1;
    }
    if (param_2 == 1) {
      param_4 = param_4 / param_5;
      dVar7 = (double)param_4;
      if (DAT_0196f848 <= dVar7) {
        if (DAT_0196f868 <= dVar7) {
          if (DAT_0196f880 <= dVar7) {
            dVar7 = (dVar7 - _DAT_0196f890) * (dVar7 - _DAT_0196f890) * _DAT_0196f8b8 +
                    _DAT_0196f898;
          }
          else {
            dVar7 = (dVar7 - _DAT_0196f878) * (dVar7 - _DAT_0196f878) * _DAT_0196f8b8 +
                    _DAT_0196f888;
          }
        }
        else {
          dVar7 = (dVar7 - _DAT_0196f860) * (dVar7 - _DAT_0196f860) * _DAT_0196f8b8 + _DAT_0196f870;
        }
      }
      else {
        dVar7 = (double)(param_4 * param_4) * _DAT_0196f8b8;
      }
      fVar4 = (float)dVar7;
      FUN_00da7ed0(auStack_74,param_6);
      puVar3 = auStack_64;
    }
    else {
      if (param_2 != 2) {
        FUN_0060f2c0();
        return param_1;
      }
      if ((double)param_5 * _PTR_018cf0f8 <= (double)param_4) {
        uVar2 = FUN_00da7ed0(auStack_44,param_6);
        uStack_24 = 0;
        uStack_20 = 0;
        dStack_1c = 0.0;
        FUN_00c716a0(auStack_34,1,6,(param_4 + param_4) - param_5,param_5,&uStack_24,uVar2);
        FUN_00da7e20(auStack_14,0x3f000000);
        FUN_00da7ed0(auStack_54,param_6);
        uVar2 = FUN_00da7e20(auStack_64,0x3f000000);
        FUN_00da7fd0(auStack_74,uVar2);
        FUN_00da7fd0(param_1,param_6);
        return param_1;
      }
      uVar2 = FUN_00da7ed0(auStack_14,param_6);
      uStack_24 = 0;
      uStack_20 = 0;
      dStack_1c = 0.0;
      FUN_00c716a0(auStack_34,0,6,param_4 + param_4,param_5,&uStack_24,uVar2);
      puVar3 = auStack_44;
      fVar4 = 0.5;
    }
    FUN_00da7e20(puVar3,fVar4);
    FUN_00da7fd0(param_1,param_6);
    return param_1;
  case 9.80909e-45:
    if ((NAN(param_4) || NAN(DAT_018ce2f0)) != (param_4 == DAT_018ce2f0)) {
      uVar2 = param_6[1];
      uVar5 = param_6[2];
      uVar1 = param_6[3];
      *param_1 = *param_6;
      param_1[1] = uVar2;
      param_1[2] = uVar5;
      param_1[3] = uVar1;
      return param_1;
    }
    fVar4 = param_4 / param_5;
    uStack_c = (double)CONCAT44(fVar4,(undefined4)uStack_c);
    param_3 = DAT_018ce2f8;
    if (DAT_018ce2f8 <= fVar4) {
      uVar2 = param_7[1];
      uVar5 = param_7[2];
      uVar1 = param_7[3];
      *param_1 = *param_7;
      param_1[1] = uVar2;
      param_1[2] = uVar5;
      param_1[3] = uVar1;
      return param_1;
    }
    if (param_2 == 0) {
      uStack_c = (double)CONCAT44(fVar4 - DAT_018ce2f8,(undefined4)uStack_c);
      dVar7 = ((double)((fVar4 - DAT_018ce2f8) * param_5 - param_5 * DAT_018fde64 * DAT_018e1340) *
              DAT_019011d0) / (double)(param_5 * DAT_018fde64);
      FUN_01728390();
      uVar2 = SUB84(DAT_018ce308,0);
      uVar5 = (undefined4)((ulonglong)DAT_018ce308 >> 0x20);
      dStack_1c = dVar7;
      FUN_01726ab0();
      dVar7 = dStack_1c * (double)CONCAT44(uVar5,uVar2);
      param_3 = (float)(double)CONCAT44((uint)((ulonglong)dVar7 >> 0x20) ^ DAT_0195cdb0._4_4_,
                                        SUB84(dVar7,0) ^ (uint)DAT_0195cdb0);
    }
    else if (param_2 == 1) {
      dVar7 = ((double)(fVar4 * param_5 - param_5 * DAT_018fde64 * DAT_018e1340) * DAT_019011d0) /
              (double)(param_5 * DAT_018fde64);
      FUN_01728390();
      uVar2 = SUB84(DAT_018ce308,0);
      uVar5 = (undefined4)((ulonglong)DAT_018ce308 >> 0x20);
      dStack_1c = dVar7;
      FUN_01726ab0();
      dVar7 = (double)CONCAT44(uVar5,uVar2);
      dVar6 = dStack_1c;
LAB_00c71fce:
      param_3 = (float)(dVar6 * dVar7 + DAT_018c0d60);
    }
    else if (param_2 == 2) {
      param_4 = param_4 / (param_5 * DAT_018ce2f4);
      dVar7 = ((double)((param_4 - DAT_018ce2f8) * param_5 -
                       (float)((double)param_5 * _DAT_0196f858) * DAT_018e1340) * DAT_019011d0) /
              (double)(float)((double)param_5 * _DAT_0196f858);
      if (DAT_018ce2f8 <= param_4) {
        FUN_01728390();
        uVar2 = SUB84(DAT_018ce308,0);
        uVar5 = (undefined4)((ulonglong)DAT_018ce308 >> 0x20);
        uStack_c = dVar7;
        FUN_01726ab0();
        dVar7 = (double)CONCAT44(uVar5,uVar2) * _PTR_018cf0f8;
        dVar6 = uStack_c;
        goto LAB_00c71fce;
      }
      FUN_01728390();
      uVar2 = SUB84(DAT_018ce308,0);
      uVar5 = (undefined4)((ulonglong)DAT_018ce308 >> 0x20);
      uStack_c = dVar7;
      FUN_01726ab0();
      param_3 = (float)(uStack_c * (double)CONCAT44(uVar5,uVar2) * DAT_0196f8d0);
    }
    FUN_00da7ed0(auStack_74,param_6);
    puVar3 = auStack_64;
    goto LAB_00c716dd;
  default:
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
    return param_1;
  }
  FUN_00da7ed0(&uStack_24,param_6);
LAB_00c716da:
  puVar3 = auStack_14;
LAB_00c716dd:
  FUN_00da7e20(puVar3,param_3);
  FUN_00da7fd0(param_1,param_6);
  return param_1;
}



/* FUNCTION 29157 ; VA 0x00c72130 ; FUN_00c72130 */

void FUN_00c72130(int *param_1,int param_2,uint param_3)

{
  uint uVar1;
  int iVar2;
  undefined4 *puVar3;
  float10 fVar4;
  float fVar5;
  float in_stack_0000002c;
  undefined auStack_20 [8];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180df48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if ((param_2 != 0) &&
     (puVar3 = (undefined4 *)*param_1, ExceptionList = &pvStack_10, puVar3 != (undefined4 *)0x0)) {
    fVar5 = in_stack_0000002c;
    ExceptionList = &pvStack_10;
    if (0.0 < (float)puVar3[0xc]) {
      fVar5 = (float)puVar3[0xc] - in_stack_0000002c;
      ExceptionList = &pvStack_10;
      puVar3[0xc] = fVar5;
      if (0.0 < fVar5) goto LAB_00c72293;
      FUN_00c70820(param_2,*puVar3,puVar3[1],puVar3[2],puVar3[3]);
      uStack_14 = 0;
      uStack_18 = *(undefined4 *)(*param_1 + 0x30);
      fVar4 = (float10)FUN_00c6df60(&uStack_18);
      puVar3 = (undefined4 *)*param_1;
      fVar5 = (float)fVar4;
    }
    fVar5 = fVar5 + (float)puVar3[8];
    puVar3[8] = fVar5;
    if (fVar5 < (float)puVar3[9]) {
      puVar3 = (undefined4 *)
               FUN_00c716a0(auStack_20,puVar3[10],puVar3[0xb],fVar5,puVar3[9],puVar3,puVar3 + 4);
      FUN_00c70820(param_2,*puVar3,puVar3[1],puVar3[2],puVar3[3]);
    }
    else {
      FUN_00c70820(param_2,puVar3[4],puVar3[5],puVar3[6],puVar3[7]);
      if (*(int *)(*param_1 + 0x38) != 0) {
        iVar2 = FUN_00c6e5f0(param_2);
        if (iVar2 != 0) {
          FUN_0054f510(*param_1 + 0x38);
          FUN_00e8ea30();
        }
        iVar2 = *param_1;
        uVar1 = *(uint *)(iVar2 + 0x38);
        if (uVar1 != 0) {
          if ((uVar1 & 1) == 0) {
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              (**(code **)(uVar1 & 0xfffffffe))(iVar2 + 0x40,iVar2 + 0x40,2);
            }
          }
          *(undefined4 *)(iVar2 + 0x38) = 0;
        }
      }
    }
  }
LAB_00c72293:
  uStack_8 = 1;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29158 ; VA 0x00c722d0 ; thunk_FUN_00c7d2c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00c7d2c0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e996;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff254) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eff254);
    if (DAT_01eff254 == -1) {
      uStack_8 = 0;
      FUN_009ca470("ButtonStyle");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01eff1f0 = RBX::Reflection::EnumDesc<enum_RBX::GuiButton::Style>::vftable;
      FUN_009caf20(&DAT_01d688f8,6);
      FUN_016f3654(&LAB_01896660);
      FUN_016f37bf(&DAT_01eff254);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eff1f0;
}



/* FUNCTION 29159 ; VA 0x00c722e0 ; thunk_FUN_00c7d110 */

undefined * thunk_FUN_00c7d110(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e92c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff2bc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eff2bc);
    if (DAT_01eff2bc == -1) {
      uStack_8 = 0;
      FUN_00ff4e70();
      FUN_016f3654(&LAB_01896600);
      FUN_016f37bf(&DAT_01eff2bc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eff258;
}



/* FUNCTION 29160 ; VA 0x00c722f0 ; thunk_FUN_00c7d230 */

undefined * thunk_FUN_00c7d230(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e96c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff324) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eff324);
    if (DAT_01eff324 == -1) {
      uStack_8 = 0;
      FUN_00ff4f90();
      FUN_016f3654(&LAB_01896640);
      FUN_016f37bf(&DAT_01eff324);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01eff2c0;
}



/* FUNCTION 29161 ; VA 0x00c72300 ; FUN_00c72300 */

uint FUN_00c72300(int param_1)

{
  int iVar1;
  uint in_EAX;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00d59db0();
    in_EAX = (uint)*(ushort *)(iVar2 + 0x1da);
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <= in_EAX) {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_00c6dcc0();
      return (uint)CONCAT11((char)(*(ushort *)(iVar2 + 0x1da) >> 8),
                            (uint)*(ushort *)(iVar2 + 0x1da) <
                            (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8));
    }
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 29162 ; VA 0x00c72370 ; FUN_00c72370 */

void __thiscall FUN_00c72370(int param_1,float *param_2,undefined4 param_3,undefined4 param_4)

{
  float fVar1;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  
  FUN_00d5b6a0(&fStack_20,param_3,param_4);
  fVar1 = (float)*(int *)(param_1 + 800);
  if (*(int *)(param_1 + 0x324) == 2) {
    *param_2 = fStack_20 + fVar1;
    param_2[1] = fStack_1c + fVar1;
    param_2[2] = fStack_18 + fVar1;
    param_2[3] = fStack_14 + fVar1;
    return;
  }
  if (*(int *)(param_1 + 0x324) == 1) {
    fVar1 = fVar1 * DAT_018ce2f4;
    *param_2 = fStack_20 + fVar1;
    param_2[1] = fStack_1c + fVar1;
    param_2[2] = fStack_18 + fVar1;
    param_2[3] = fStack_14 + fVar1;
    return;
  }
  *param_2 = fStack_20;
  param_2[1] = fStack_1c;
  param_2[2] = fStack_18;
  param_2[3] = fStack_14;
  return;
}



/* FUNCTION 29163 ; VA 0x00c72410 ; FUN_00c72410 */

undefined4 __thiscall
FUN_00c72410(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  (**(code **)(*param_1 + 0xe0))(&fStack_14,param_3,param_4);
  fVar4 = (float)param_1[200];
  if (param_1[0xc9] == 2) {
    fVar1 = fVar4 + fStack_10;
    fVar3 = fStack_8 - fVar4;
    fVar2 = fStack_c - fVar4;
    fStack_c = fVar4 + fStack_14;
    fStack_10 = fVar3;
    if (fVar1 < fVar3) {
      fStack_10 = fVar1;
    }
    fStack_14 = fVar2;
    if (fStack_c < fVar2) {
      fStack_14 = fStack_c;
    }
    fStack_8 = fVar1;
    if (fVar1 <= fVar3) {
      fStack_8 = fVar3;
    }
    if (fStack_c <= fVar2) {
      fStack_c = fVar2;
    }
  }
  else if (param_1[0xc9] == 1) {
    fVar4 = fVar4 * DAT_018ce2f4;
    fVar2 = fStack_10 + fVar4;
    fVar3 = fStack_8 - fVar4;
    fVar1 = fStack_c - fVar4;
    fStack_c = fStack_14 + fVar4;
    fStack_10 = fVar3;
    if (fVar2 < fVar3) {
      fStack_10 = fVar2;
    }
    fStack_14 = fVar1;
    if (fStack_c < fVar1) {
      fStack_14 = fStack_c;
    }
    fStack_8 = fVar2;
    if (fVar2 <= fVar3) {
      fStack_8 = fVar3;
    }
    if (fStack_c <= fVar1) {
      fStack_c = fVar1;
    }
  }
  (**(code **)(*param_1 + 0xf0))(param_2,fStack_14,fStack_10,fStack_c,fStack_8);
  return param_2;
}



/* FUNCTION 29164 ; VA 0x00c72530 ; FUN_00c72530 */

void __thiscall FUN_00c72530(int param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  int iStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  int iStack_30;
  undefined4 *puStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  float fStack_1c;
  float fStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180df99;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  iVar2 = FUN_006ebc30(param_1);
  if (((iVar2 == 0) || (iVar2 = FUN_00b98e50(), iVar2 == 0)) || (iVar2 != param_1)) {
    *param_2 = 0;
  }
  else {
    FUN_00d5c5d0(&fStack_54);
    fStack_18 = (fStack_48 - fStack_50) * DAT_018ce2f4 + fStack_50;
    fStack_1c = (fStack_4c - fStack_54) * DAT_018ce2f4 + fStack_54;
    if (*(int *)(*param_3 + 0x5c) == 0) {
      FUN_0088ddf0(param_3);
      iVar2 = (int)fStack_18;
      iVar3 = (int)fStack_1c;
      FUN_006150c0(iVar3,iVar2);
      FUN_00557fc0(param_3);
      FUN_0089be10(iVar3,iVar2);
      FUN_0088ddf0(param_3);
      FUN_0060e0c0(&uStack_38,param_1);
      piVar5 = piStack_34;
      if (piStack_34 != (int *)0x0) {
        LOCK();
        piStack_34[2] = piStack_34[2] + 1;
        UNLOCK();
      }
      uStack_44 = uStack_38;
      piStack_40 = piStack_34;
      iStack_3c = iStack_14;
      iStack_20 = *param_3 + 0xd8;
      uStack_8._0_1_ = 2;
      uStack_8._1_3_ = 0;
      uVar4 = FUN_01675290(DAT_02110da8);
      uStack_8._0_1_ = 3;
      uStack_28 = uVar4;
      puStack_2c = (undefined4 *)FUN_01674e20(0x24);
      if (puStack_2c == (undefined4 *)0x0) {
        puVar6 = (undefined4 *)0x0;
      }
      else {
        *puStack_2c = 0;
        puStack_2c[1] = 1;
        puStack_2c[2] = FUN_00c75c50;
        puStack_2c[3] = FUN_005d3660;
        puStack_2c[4] = 0;
        puStack_2c[5] = iStack_20;
        puStack_2c[6] = 0;
        puStack_2c[7] = 0;
        if (piVar5 != (int *)0x0) {
          LOCK();
          piVar5[2] = piVar5[2] + 1;
          UNLOCK();
        }
        puStack_2c[6] = uStack_38;
        puStack_2c[7] = piVar5;
        puStack_2c[8] = iStack_14;
        puVar6 = puStack_2c;
      }
      FUN_016797d0(puVar6);
      if (puVar6 != (undefined4 *)0x0) {
        LOCK();
        puVar6[1] = puVar6[1] + 1;
        UNLOCK();
      }
      uStack_24 = 2;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      puStack_2c = puVar6;
      FUN_01675290(uVar4);
      iVar2 = *(int *)(iStack_14 + 0x374);
      *(undefined4 **)(iStack_14 + 0x374) = puVar6;
      if (iVar2 != 0) {
        piVar1 = (int *)(iVar2 + 4);
        LOCK();
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          FUN_01674ea0(iVar2);
        }
      }
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar2 = piVar5[2] + -1;
        piVar5[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
      uStack_8 = 0xffffffff;
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar1 = piVar5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (*(int *)(*param_3 + 0x5c) == 2) {
      iVar2 = (int)fStack_18;
      iVar3 = (int)fStack_1c;
      FUN_006150c0(iVar3,iVar2);
      FUN_00557fc0(param_3);
      uVar4 = 0xc7279e;
      FUN_0089be10(iVar3,iVar2);
      FUN_00587490(&iStack_30);
      uStack_8 = 5;
      if (*param_3 == iStack_30) {
        FUN_006eccd0();
        uVar7 = 0xc727d5;
        piVar5 = (int *)FUN_00587490(&uStack_38);
        iVar2 = *piVar5;
        iVar3 = *param_3;
        FUN_00550b30();
        if (iVar2 == iVar3) {
          uVar8 = *(undefined4 *)(*param_3 + 0xb0);
          FUN_00557fc0(param_3);
          FUN_0089bf10(uVar4,uVar7,uVar8);
        }
        uStack_38 = 0;
        piStack_34 = (int *)0x0;
        FUN_0072a430(&uStack_38);
        FUN_0056c200();
      }
      FUN_00550b30();
    }
    *param_2 = 1;
  }
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[4] = 0;
  param_2[3] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29165 ; VA 0x00c72880 ; FUN_00c72880 */

void FUN_00c72880(float *param_1,float *param_2,float *param_3,float *param_4,float *param_5,
                 float *param_6,float param_7)

{
  float *pfVar1;
  float *pfVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fStack_10;
  undefined auStack_c [4];
  float fStack_8;
  
  pfVar1 = param_3;
  if (0.0 < param_7) {
    pfVar2 = (float *)FUN_01163100(auStack_c,param_7);
    fVar3 = *pfVar2;
    fVar6 = pfVar2[1] + 0.0;
    fVar14 = fVar6;
    if (fVar6 <= 0.0) {
      fVar14 = 0.0;
    }
    fStack_8 = *param_3;
    fStack_10 = param_3[1];
    param_3 = (float *)fVar14;
  }
  else {
    fStack_8 = *param_3;
    fStack_10 = param_3[1];
    fVar3 = param_3[2] - fStack_8;
    fVar6 = (param_3[3] - fStack_10) + 0.0;
    param_3 = (float *)fVar6;
    if (fVar6 <= 0.0) {
      param_3 = (float *)0x0;
    }
  }
  fVar3 = fVar3 + 0.0;
  if (0.0 <= fVar6) {
    fVar6 = 0.0;
  }
  fVar14 = param_4[1];
  fVar4 = fVar3;
  if (0.0 <= fVar3) {
    fVar4 = 0.0;
  }
  fVar15 = *param_4;
  if (fVar3 <= 0.0) {
    fVar3 = 0.0;
  }
  fVar13 = (param_5[3] - param_5[1]) - param_4[3];
  fVar12 = (param_5[2] - *param_5) - param_4[2];
  fVar3 = fVar3 - fVar4;
  fVar6 = (float)param_3 - fVar6;
  fVar9 = fVar6 / (fVar14 + fVar13);
  fVar4 = fVar3 / (fVar15 + fVar12);
  if (DAT_018ce2f8 <= fVar4) {
    fVar4 = DAT_018ce2f8;
  }
  param_1[1] = fStack_10;
  if (fVar4 <= fVar9) {
    fVar9 = fVar4;
  }
  fVar15 = fVar15 * fVar9;
  fVar14 = fVar14 * fVar9;
  if (fVar15 <= 0.0) {
    fVar15 = 0.0;
  }
  if (fVar14 <= 0.0) {
    fVar14 = 0.0;
  }
  fVar12 = fVar3 - fVar12 * fVar9;
  fVar4 = fVar6 - fVar13 * fVar9;
  *param_1 = fStack_8;
  if (fVar3 <= fVar12) {
    fVar12 = fVar3;
  }
  if (fVar6 <= fVar4) {
    fVar4 = fVar6;
  }
  fVar15 = fVar15 * param_7 + fStack_8;
  fVar6 = fVar14 * param_7 + fStack_10;
  param_1[2] = fVar15;
  fStack_8 = fVar12 * param_7 + fStack_8;
  param_1[3] = fVar6;
  fStack_10 = fVar4 * param_7 + fStack_10;
  fVar3 = pfVar1[1];
  param_1[4] = fVar15;
  param_1[5] = fVar3;
  param_1[6] = fStack_8;
  param_1[7] = fVar6;
  fVar3 = pfVar1[1];
  fVar14 = pfVar1[2];
  param_1[8] = fStack_8;
  param_1[9] = fVar3;
  param_1[10] = fVar14;
  param_1[0xb] = fVar6;
  param_1[0xc] = *pfVar1;
  param_1[0xd] = fVar6;
  param_1[0xe] = fVar15;
  param_1[0xf] = fStack_10;
  param_1[0x10] = fVar15;
  param_1[0x11] = fVar6;
  param_1[0x12] = fStack_8;
  param_1[0x13] = fStack_10;
  fVar3 = pfVar1[2];
  param_1[0x14] = fStack_8;
  param_1[0x15] = fVar6;
  param_1[0x16] = fVar3;
  param_1[0x17] = fStack_10;
  fVar3 = pfVar1[3];
  param_1[0x18] = *pfVar1;
  param_1[0x19] = fStack_10;
  param_1[0x1a] = fVar15;
  param_1[0x1b] = fVar3;
  fVar3 = pfVar1[3];
  param_1[0x1c] = fVar15;
  param_1[0x1d] = fStack_10;
  param_1[0x1e] = fStack_8;
  param_1[0x1f] = fVar3;
  fVar3 = pfVar1[2];
  fVar14 = pfVar1[3];
  param_1[0x20] = fStack_8;
  param_1[0x21] = fStack_10;
  param_1[0x22] = fVar3;
  param_1[0x23] = fVar14;
  fVar6 = param_5[1] + param_4[3];
  fVar3 = param_5[1] + param_4[1];
  fVar14 = fVar6;
  if (fVar3 < fVar6) {
    fVar14 = fVar3;
  }
  fVar15 = *param_5 + *param_4;
  fVar9 = *param_5 + param_4[2];
  fVar4 = fVar9;
  if (fVar15 < fVar9) {
    fVar4 = fVar15;
  }
  if (fVar3 <= fVar6) {
    fVar3 = fVar6;
  }
  if (fVar15 <= fVar9) {
    fVar15 = fVar9;
  }
  *param_4 = fVar4;
  param_4[1] = fVar14;
  param_4[2] = fVar15;
  param_4[3] = fVar3;
  fVar3 = *param_4;
  fVar14 = param_4[3];
  fVar6 = param_4[1];
  fVar4 = fVar15;
  if (param_1[0x12] - param_1[0x10] < fVar15 - fVar3) {
    fVar4 = (param_1[0x12] - param_1[0x10]) + fVar3;
  }
  fVar9 = fVar14;
  if (param_1[0x13] - param_1[0x11] < fVar14 - fVar6) {
    fVar9 = (param_1[0x13] - param_1[0x11]) + fVar6;
  }
  fVar12 = fVar6;
  if (fVar6 <= param_5[1]) {
    fVar12 = param_5[1];
  }
  fVar13 = fVar3;
  if (fVar3 <= *param_5) {
    fVar13 = *param_5;
  }
  fVar12 = fVar12 / param_6[1];
  fVar13 = fVar13 / *param_6;
  fVar10 = fVar3;
  if (*param_5 <= fVar3) {
    fVar10 = *param_5;
  }
  fVar7 = fVar6;
  if (param_5[1] <= fVar6) {
    fVar7 = param_5[1];
  }
  fVar10 = fVar10 / *param_6;
  fVar7 = fVar7 / param_6[1];
  param_4 = (float *)fVar12;
  if (fVar7 < fVar12) {
    param_4 = (float *)fVar7;
  }
  param_3 = (float *)fVar13;
  if (fVar10 < fVar13) {
    param_3 = (float *)fVar10;
  }
  if (fVar7 <= fVar12) {
    fVar7 = fVar12;
  }
  if (fVar10 <= fVar13) {
    fVar10 = fVar13;
  }
  *param_2 = (float)param_3;
  param_2[1] = (float)param_4;
  param_2[3] = fVar7;
  fVar12 = fVar4;
  if (fVar4 <= fVar3) {
    fVar12 = fVar3;
  }
  param_2[2] = fVar10;
  if (fVar3 <= fVar4) {
    fVar4 = fVar3;
  }
  fVar13 = param_5[1];
  fVar10 = fVar6;
  if (fVar6 <= fVar13) {
    fVar10 = fVar13;
  }
  fVar7 = fVar6;
  if (fVar13 <= fVar6) {
    fVar7 = fVar13;
  }
  fVar5 = fVar12 / *param_6;
  fVar10 = fVar10 / param_6[1];
  fVar7 = fVar7 / param_6[1];
  fVar13 = fVar4 / *param_6;
  fVar8 = fVar10;
  if (fVar7 < fVar10) {
    fVar8 = fVar7;
  }
  fVar11 = fVar5;
  if (fVar13 < fVar5) {
    fVar11 = fVar13;
  }
  if (fVar7 <= fVar10) {
    fVar7 = fVar10;
  }
  if (fVar13 <= fVar5) {
    fVar13 = fVar5;
  }
  param_2[5] = fVar8;
  param_2[4] = fVar11;
  param_2[6] = fVar13;
  param_2[7] = fVar7;
  fVar13 = param_5[1];
  fVar10 = fVar6;
  if (fVar6 <= fVar13) {
    fVar10 = fVar13;
  }
  fVar7 = param_5[2];
  fVar8 = fVar6;
  if (fVar13 <= fVar6) {
    fVar8 = fVar13;
  }
  fVar13 = fVar7;
  if (fVar7 <= fVar15) {
    fVar13 = fVar15;
  }
  if (fVar15 <= fVar7) {
    fVar7 = fVar15;
  }
  fVar10 = fVar10 / param_6[1];
  fVar8 = fVar8 / param_6[1];
  fVar13 = fVar13 / *param_6;
  fVar7 = fVar7 / *param_6;
  fVar5 = fVar10;
  if (fVar8 < fVar10) {
    fVar5 = fVar8;
  }
  fVar11 = fVar13;
  if (fVar7 < fVar13) {
    fVar11 = fVar7;
  }
  if (fVar8 <= fVar10) {
    fVar8 = fVar10;
  }
  if (fVar7 <= fVar13) {
    fVar7 = fVar13;
  }
  param_2[8] = fVar11;
  param_2[9] = fVar5;
  param_2[10] = fVar7;
  fVar13 = fVar9;
  if (fVar9 <= fVar6) {
    fVar13 = fVar6;
  }
  param_2[0xb] = fVar8;
  fVar10 = *param_5;
  fVar7 = fVar3;
  if (fVar3 <= fVar10) {
    fVar7 = fVar10;
  }
  if (fVar6 <= fVar9) {
    fVar9 = fVar6;
  }
  fVar8 = fVar13 / param_6[1];
  fVar7 = fVar7 / *param_6;
  fVar6 = fVar3;
  if (fVar10 <= fVar3) {
    fVar6 = fVar10;
  }
  fVar10 = fVar9 / param_6[1];
  fVar6 = fVar6 / *param_6;
  param_7 = fVar8;
  if (fVar10 < fVar8) {
    param_7 = fVar10;
  }
  fVar5 = fVar7;
  if (fVar6 < fVar7) {
    fVar5 = fVar6;
  }
  if (fVar10 <= fVar8) {
    fVar10 = fVar8;
  }
  if (fVar6 <= fVar7) {
    fVar6 = fVar7;
  }
  param_2[0xc] = fVar5;
  param_2[0xd] = param_7;
  param_2[0xf] = fVar10;
  param_2[0xe] = fVar6;
  fVar8 = fVar13 / param_6[1];
  fVar7 = fVar12 / *param_6;
  fVar10 = fVar4 / *param_6;
  fVar6 = fVar9 / param_6[1];
  param_3 = (float *)fVar8;
  if (fVar6 < fVar8) {
    param_3 = (float *)fVar6;
  }
  param_7 = fVar7;
  if (fVar10 < fVar7) {
    param_7 = fVar10;
  }
  if (fVar6 <= fVar8) {
    fVar6 = fVar8;
  }
  if (fVar10 <= fVar7) {
    fVar10 = fVar7;
  }
  param_2[0x10] = param_7;
  param_2[0x11] = (float)param_3;
  param_2[0x12] = fVar10;
  param_2[0x13] = fVar6;
  fVar6 = param_5[2];
  fVar13 = fVar13 / param_6[1];
  fVar9 = fVar9 / param_6[1];
  fVar10 = fVar6;
  if (fVar6 <= fVar15) {
    fVar10 = fVar15;
  }
  fVar10 = fVar10 / *param_6;
  if (fVar15 <= fVar6) {
    fVar6 = fVar15;
  }
  fVar6 = fVar6 / *param_6;
  fVar7 = fVar13;
  if (fVar9 < fVar13) {
    fVar7 = fVar9;
  }
  fVar8 = fVar10;
  if (fVar6 < fVar10) {
    fVar8 = fVar6;
  }
  if (fVar9 <= fVar13) {
    fVar9 = fVar13;
  }
  if (fVar6 <= fVar10) {
    fVar6 = fVar10;
  }
  param_2[0x15] = fVar7;
  param_2[0x14] = fVar8;
  param_2[0x17] = fVar9;
  param_2[0x16] = fVar6;
  fVar6 = param_5[3];
  fVar9 = *param_5;
  fVar13 = fVar6;
  if (fVar6 <= fVar14) {
    fVar13 = fVar14;
  }
  if (fVar14 <= fVar6) {
    fVar6 = fVar14;
  }
  fVar10 = fVar3;
  if (fVar3 <= fVar9) {
    fVar10 = fVar9;
  }
  if (fVar9 <= fVar3) {
    fVar3 = fVar9;
  }
  fVar13 = fVar13 / param_6[1];
  fVar6 = fVar6 / param_6[1];
  fVar10 = fVar10 / *param_6;
  fVar3 = fVar3 / *param_6;
  fVar9 = fVar13;
  if (fVar6 < fVar13) {
    fVar9 = fVar6;
  }
  fVar7 = fVar10;
  if (fVar3 < fVar10) {
    fVar7 = fVar3;
  }
  if (fVar6 <= fVar13) {
    fVar6 = fVar13;
  }
  if (fVar3 <= fVar10) {
    fVar3 = fVar10;
  }
  param_2[0x19] = fVar9;
  param_2[0x18] = fVar7;
  param_2[0x1a] = fVar3;
  param_2[0x1b] = fVar6;
  fVar3 = param_5[3];
  fVar6 = fVar3;
  if (fVar3 <= fVar14) {
    fVar6 = fVar14;
  }
  if (fVar14 <= fVar3) {
    fVar3 = fVar14;
  }
  fVar12 = fVar12 / *param_6;
  fVar6 = fVar6 / param_6[1];
  fVar3 = fVar3 / param_6[1];
  fVar4 = fVar4 / *param_6;
  fVar9 = fVar6;
  if (fVar3 < fVar6) {
    fVar9 = fVar3;
  }
  fVar13 = fVar12;
  if (fVar4 < fVar12) {
    fVar13 = fVar4;
  }
  if (fVar3 <= fVar6) {
    fVar3 = fVar6;
  }
  if (fVar4 <= fVar12) {
    fVar4 = fVar12;
  }
  param_2[0x1c] = fVar13;
  param_2[0x1d] = fVar9;
  param_2[0x1e] = fVar4;
  param_2[0x1f] = fVar3;
  fVar3 = param_5[3];
  fVar6 = param_5[2];
  fVar4 = fVar3;
  if (fVar3 <= fVar14) {
    fVar4 = fVar14;
  }
  if (fVar14 <= fVar3) {
    fVar3 = fVar14;
  }
  fVar14 = fVar6;
  if (fVar15 <= fVar6) {
    fVar14 = fVar15;
  }
  if (fVar6 <= fVar15) {
    fVar6 = fVar15;
  }
  fVar4 = fVar4 / param_6[1];
  fVar3 = fVar3 / param_6[1];
  fVar6 = fVar6 / *param_6;
  fVar14 = fVar14 / *param_6;
  fVar15 = fVar4;
  if (fVar3 < fVar4) {
    fVar15 = fVar3;
  }
  fVar9 = fVar6;
  if (fVar14 < fVar6) {
    fVar9 = fVar14;
  }
  if (fVar3 <= fVar4) {
    fVar3 = fVar4;
  }
  if (fVar14 <= fVar6) {
    fVar14 = fVar6;
  }
  param_2[0x20] = fVar9;
  param_2[0x21] = fVar15;
  param_2[0x22] = fVar14;
  param_2[0x23] = fVar3;
  return;
}



/* FUNCTION 29166 ; VA 0x00c73070 ; FUN_00c73070 */

void FUN_00c73070(float *param_1,float *param_2,short *param_3,float *param_4)

{
  float fVar1;
  float10 fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  
  fVar8 = param_2[3];
  fVar7 = param_2[1];
  fVar6 = param_2[2];
  fVar1 = *param_2;
  fVar4 = (fVar8 - fVar7) / param_4[1];
  fVar3 = (fVar6 - fVar1) / *param_4;
  if (DAT_018ce2f8 <= fVar3) {
    fVar3 = DAT_018ce2f8;
  }
  if (fVar3 <= fVar4) {
    fVar4 = fVar3;
  }
  fVar2 = (float10)FUN_01725280((double)((float)(int)*param_3 * fVar4));
  fVar5 = fVar1 + (float)fVar2;
  fVar6 = fVar6 - (float)fVar2;
  fVar2 = (float10)FUN_01725280((double)((float)(int)param_3[1] * fVar4));
  param_1[1] = fVar7;
  fVar7 = fVar7 + (float)fVar2;
  fVar8 = fVar8 - (float)fVar2;
  *param_1 = fVar1;
  param_1[2] = fVar5;
  param_1[3] = fVar7;
  fVar1 = param_2[1];
  param_1[4] = fVar5;
  param_1[5] = fVar1;
  param_1[6] = fVar6;
  param_1[7] = fVar7;
  fVar1 = param_2[1];
  fVar3 = param_2[2];
  param_1[8] = fVar6;
  param_1[9] = fVar1;
  param_1[10] = fVar3;
  param_1[0xb] = fVar7;
  param_1[0xc] = *param_2;
  param_1[0xd] = fVar7;
  param_1[0xe] = fVar5;
  param_1[0xf] = fVar8;
  param_1[0x10] = fVar5;
  param_1[0x11] = fVar7;
  param_1[0x12] = fVar6;
  param_1[0x13] = fVar8;
  fVar1 = param_2[2];
  param_1[0x14] = fVar6;
  param_1[0x15] = fVar7;
  param_1[0x16] = fVar1;
  param_1[0x17] = fVar8;
  fVar7 = param_2[3];
  param_1[0x18] = *param_2;
  param_1[0x19] = fVar8;
  param_1[0x1a] = fVar5;
  param_1[0x1b] = fVar7;
  fVar7 = param_2[3];
  param_1[0x1c] = fVar5;
  param_1[0x1d] = fVar8;
  param_1[0x1e] = fVar6;
  param_1[0x1f] = fVar7;
  fVar7 = param_2[2];
  fVar1 = param_2[3];
  param_1[0x20] = fVar6;
  param_1[0x21] = fVar8;
  param_1[0x22] = fVar7;
  param_1[0x23] = fVar1;
  return;
}



/* FUNCTION 29167 ; VA 0x00c73260 ; FUN_00c73260 */

undefined4 * FUN_00c73260(undefined4 *param_1,int param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_0180dfc0;
  uStack_8 = 0;
  if (param_2 == 0) {
    ExceptionList = &pvStack_10;
    *param_1 = 0;
  }
  else {
    ExceptionList = &pvStack_10;
    if (param_4 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    uStack_18 = param_3;
    piStack_14 = param_4;
    uStack_8 = 1;
    FUN_00c6e4f0(param_1,&uStack_18);
    piVar2 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[1] + -1;
      piStack_14[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[1] + -1;
    param_4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar2 = param_4 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 29168 ; VA 0x00c73340 ; FUN_00c73340 */

undefined4 * __thiscall
FUN_00c73340(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180e001;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c75940;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29169 ; VA 0x00c734e0 ; FUN_00c734e0 */

undefined4 * __thiscall
FUN_00c734e0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180e041;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c754c0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29170 ; VA 0x00c73680 ; FUN_00c73680 */

undefined4 * __thiscall
FUN_00c73680(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180e081;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c75660;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29171 ; VA 0x00c73820 ; FUN_00c73820 */

undefined4 * __thiscall
FUN_00c73820(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180e0c1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c75800;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29172 ; VA 0x00c739c0 ; FUN_00c739c0 */

undefined4 * __thiscall
FUN_00c739c0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180e101;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c753c0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29173 ; VA 0x00c73b70 ; FUN_00c73b70 */

undefined4 * __thiscall
FUN_00c73b70(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180e141;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00c75a80;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29174 ; VA 0x00c73d10 ; FUN_00c73d10 */

void __fastcall FUN_00c73d10(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d561;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 8) == 0) {
    iVar3 = 0;
  }
  else {
    iVar3 = *(int *)(*(int *)(param_1 + 0xc) + 0x34) + *(int *)(param_1 + 8);
  }
  ExceptionList = &pvStack_10;
  FUN_006eccd0();
  uStack_8 = 0;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 1;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00c75d70;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = iVar3;
    puVar5[6] = FUN_00c7cdd0;
    puVar5[7] = param_1;
  }
  FUN_016797d0(puVar5);
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  FUN_01675290(uVar4);
  iVar3 = *(int *)(param_1 + 0x18);
  *(undefined4 **)(param_1 + 0x18) = puVar5;
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29175 ; VA 0x00c73e30 ; FUN_00c73e30 */

void __fastcall FUN_00c73e30(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d561;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 8) == 0) {
    iVar3 = 0;
  }
  else {
    iVar3 = *(int *)(*(int *)(param_1 + 0xc) + 0x34) + *(int *)(param_1 + 8);
  }
  ExceptionList = &pvStack_10;
  FUN_006eccd0();
  uStack_8 = 0;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 1;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_006d7a90;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = iVar3;
    puVar5[6] = FUN_00c7cec0;
    puVar5[7] = param_1;
  }
  FUN_016797d0(puVar5);
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  FUN_01675290(uVar4);
  iVar3 = *(int *)(param_1 + 0x18);
  *(undefined4 **)(param_1 + 0x18) = puVar5;
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29176 ; VA 0x00c73f50 ; FUN_00c73f50 */

void __fastcall FUN_00c73f50(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d561;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 8) == 0) {
    iVar3 = 0;
  }
  else {
    iVar3 = *(int *)(*(int *)(param_1 + 0xc) + 0x34) + *(int *)(param_1 + 8);
  }
  ExceptionList = &pvStack_10;
  FUN_006eccd0();
  uStack_8 = 0;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 1;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00c6c160;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = iVar3;
    puVar5[6] = FUN_00c7cfe0;
    puVar5[7] = param_1;
  }
  FUN_016797d0(puVar5);
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  FUN_01675290(uVar4);
  iVar3 = *(int *)(param_1 + 0x18);
  *(undefined4 **)(param_1 + 0x18) = puVar5;
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29177 ; VA 0x00c74070 ; FUN_00c74070 */

void FUN_00c74070(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00c7d060();
    *param_2 = uVar3;
    iVar4 = FUN_00c7d490();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 29178 ; VA 0x00c740d0 ; FUN_00c740d0 */

void FUN_00c740d0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00c7d110();
    *param_2 = uVar3;
    iVar4 = FUN_00c7d500();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 29179 ; VA 0x00c74130 ; FUN_00c74130 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00c74130(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_00c7d1a0();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01eff4cc) {
      FUN_016f3809(&DAT_01eff4cc);
      if (DAT_01eff4cc == -1) {
        _DAT_01eff4c0 = FUN_005c65e0;
        _DAT_01eff4c4 = FUN_005c65e0;
        _DAT_01eff4c8 = _guard_check_icall;
        FUN_016f37bf(&DAT_01eff4cc);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01eff4c0) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01eff4c0;
  }
  return;
}



/* FUNCTION 29180 ; VA 0x00c741f0 ; FUN_00c741f0 */

void FUN_00c741f0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00c7d230();
    *param_2 = uVar3;
    iVar4 = FUN_00c7d5e0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 29181 ; VA 0x00c74250 ; FUN_00c74250 */

void FUN_00c74250(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00c7d2c0();
    *param_2 = uVar3;
    iVar4 = FUN_00c7d650();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 29182 ; VA 0x00c742b0 ; FUN_00c742b0 */

void FUN_00c742b0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00c7d370();
    *param_2 = uVar3;
    iVar4 = FUN_00c7d6c0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 29183 ; VA 0x00c74310 ; FUN_00c74310 */

void FUN_00c74310(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00c7d400();
    *param_2 = uVar3;
    iVar4 = FUN_00c7d730();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 29184 ; VA 0x00c74370 ; FUN_00c74370 */

void FUN_00c74370(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c7d060();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29185 ; VA 0x00c743b0 ; FUN_00c743b0 */

void FUN_00c743b0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c7d110();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29186 ; VA 0x00c743f0 ; FUN_00c743f0 */

void FUN_00c743f0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c7d1a0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29187 ; VA 0x00c74430 ; FUN_00c74430 */

void FUN_00c74430(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c7d230();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29188 ; VA 0x00c74470 ; FUN_00c74470 */

void FUN_00c74470(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c7d2c0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29189 ; VA 0x00c744b0 ; FUN_00c744b0 */

void FUN_00c744b0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00c7d370();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29190 ; VA 0x00c744f0 ; FUN_00c744f0 */

void FUN_00c744f0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00c7d400();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29191 ; VA 0x00c74530 ; FUN_00c74530 */

void __thiscall FUN_00c74530(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_14 [16];
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_14,param_2);
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,auStack_14);
  return;
}



/* FUNCTION 29192 ; VA 0x00c74560 ; FUN_00c74560 */

void __thiscall
FUN_00c74560(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_35c;
  undefined auStack_358 [200];
  undefined4 uStack_290;
  int iStack_28c;
  undefined auStack_288 [200];
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 *puStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e2fb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  puStack_18 = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088daf0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar4 = *(undefined4 **)(param_1 + 0x40);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puStack_20 = &uStack_1c0;
    uVar5 = 2;
  }
  else {
    uStack_f0 = FUN_0088d5f0();
    iStack_ec = 0;
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    uStack_e0 = puVar4[2];
    uStack_dc = puVar4[3];
    iStack_ec = FUN_006313f0();
    puStack_20 = &uStack_f0;
    uVar5 = 1;
  }
  uStack_8 = (uint)(puVar4 == (undefined4 *)0x0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088d5f0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_20);
  if ((uVar5 & 2) != 0) {
    uStack_14 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uVar5 = uStack_14;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
      uVar5 = uStack_14;
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_14 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(iStack_1c + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    uStack_14 = uStack_14 | 8;
    puVar4 = &uStack_1c0;
    uStack_8 = 5;
  }
  else {
    uStack_f0 = FUN_0088d5f0();
    iStack_ec = 0;
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    uStack_e0 = puVar4[2];
    uStack_dc = puVar4[3];
    iStack_ec = FUN_006313f0();
    uStack_14 = uStack_14 | 4;
    puVar4 = &uStack_f0;
    uStack_8 = 4;
  }
  uVar2 = FUN_0088d5f0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 8) != 0) {
    uStack_14 = uStack_14 & 0xfffffff7;
    uStack_8 = 6;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  if ((uStack_14 & 4) != 0) {
    uStack_14 = uStack_14 & 0xfffffffb;
    uStack_8 = 7;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(iStack_1c + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    uStack_14 = uStack_14 | 0x20;
    puVar4 = &uStack_1c0;
    uStack_8 = 9;
  }
  else {
    uStack_f0 = thunk_FUN_00c7d370();
    iStack_ec = 0;
    uStack_e8 = *puVar4;
    iStack_ec = FUN_00c7d6c0();
    uStack_14 = uStack_14 | 0x10;
    puVar4 = &uStack_f0;
    uStack_8 = 8;
  }
  uVar2 = thunk_FUN_00c7d370();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 0x20) != 0) {
    uStack_14 = uStack_14 & 0xffffffdf;
    uStack_8 = 10;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  if ((uStack_14 & 0x10) != 0) {
    uStack_14 = uStack_14 & 0xffffffef;
    uStack_8 = 0xb;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(iStack_1c + 0x4c);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    uStack_14 = uStack_14 | 0x80;
    puVar4 = &uStack_1c0;
    uStack_8 = 0xd;
  }
  else {
    uStack_f0 = thunk_FUN_00c7d400();
    iStack_ec = 0;
    uStack_e8 = *puVar4;
    iStack_ec = FUN_00c7d730();
    uStack_14 = uStack_14 | 0x40;
    puVar4 = &uStack_f0;
    uStack_8 = 0xc;
  }
  uVar2 = thunk_FUN_00c7d400();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((char)uStack_14 < '\0') {
    uStack_14 = uStack_14 & 0xffffff7f;
    uStack_8 = 0xe;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  if ((uStack_14 & 0x40) != 0) {
    uStack_14 = uStack_14 & 0xffffffbf;
    uStack_8 = 0xf;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(iStack_1c + 0x50);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    uStack_14 = uStack_14 | 0x200;
    puVar4 = &uStack_1c0;
    uStack_8 = 0x11;
  }
  else {
    uStack_f0 = FUN_0088c960();
    iStack_ec = 0;
    uStack_e8 = *puVar4;
    iStack_ec = FUN_00630820();
    uStack_14 = uStack_14 | 0x100;
    puVar4 = &uStack_f0;
    uStack_8 = 0x10;
  }
  uVar2 = FUN_0088c960();
  uVar3 = FUN_0086e3d0(param_6);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 0x200) != 0) {
    uStack_14 = uStack_14 & 0xfffffdff;
    uStack_8 = 0x12;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  if ((uStack_14 & 0x100) != 0) {
    uStack_14 = uStack_14 & 0xfffffeff;
    uStack_8 = 0x13;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  uStack_8 = 0xffffffff;
  puVar1 = *(undefined **)(iStack_1c + 0x54);
  if (puVar1 == (undefined *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    uStack_14 = uStack_14 | 0x800;
    puVar4 = &uStack_1c0;
    uStack_8 = 0x15;
  }
  else {
    uStack_f0 = FUN_0088daf0();
    iStack_ec = 0;
    uStack_e8 = CONCAT31(uStack_e8._1_3_,*puVar1);
    iStack_ec = FUN_005c9ef0();
    uStack_14 = uStack_14 | 0x400;
    puVar4 = &uStack_f0;
    uStack_8 = 0x14;
  }
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(param_7);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 0x800) != 0) {
    uStack_14 = uStack_14 & 0xfffff7ff;
    uStack_8 = 0x16;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  if ((uStack_14 & 0x400) != 0) {
    uStack_14 = uStack_14 & 0xfffffbff;
    uStack_8 = 0x17;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(iStack_1c + 0x58) == 0) {
    uStack_290 = FUN_00888530();
    iStack_28c = 0;
    param_2 = &uStack_290;
    uVar5 = uStack_14 | 0x2000;
    uStack_8 = 0x19;
  }
  else {
    param_2 = (undefined4 *)FUN_008bc7a0(*(int *)(iStack_1c + 0x58));
    uStack_8 = 0x18;
    uVar5 = uStack_14 | 0x1000;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_00d88470();
  uVar3 = FUN_0086e3d0(param_8);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((uVar5 & 0x2000) != 0) {
    uVar5 = uVar5 & 0xffffdfff;
    uStack_8 = 0x1a;
    uStack_14 = uVar5;
    if (iStack_28c != 0) {
      (**(code **)(iStack_28c + 8))(auStack_288);
    }
  }
  if (((uVar5 & 0x1000) != 0) && (uStack_8 = 0x1b, iStack_35c != 0)) {
    (**(code **)(iStack_35c + 8))(auStack_358);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29193 ; VA 0x00c74c80 ; FUN_00c74c80 */

void __thiscall
FUN_00c74c80(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_35c;
  undefined auStack_358 [200];
  undefined4 uStack_290;
  int iStack_28c;
  undefined auStack_288 [200];
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 *puStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e479;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  puStack_18 = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088daf0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar4 = *(undefined4 **)(param_1 + 0x40);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puStack_20 = &uStack_1c0;
    uVar5 = 2;
  }
  else {
    uStack_f0 = FUN_0088d5f0();
    iStack_ec = 0;
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    uStack_e0 = puVar4[2];
    uStack_dc = puVar4[3];
    iStack_ec = FUN_006313f0();
    puStack_20 = &uStack_f0;
    uVar5 = 1;
  }
  uStack_8 = (uint)(puVar4 == (undefined4 *)0x0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088d5f0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_20);
  if ((uVar5 & 2) != 0) {
    uStack_14 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uVar5 = uStack_14;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
      uVar5 = uStack_14;
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_14 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(iStack_1c + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    uStack_14 = uStack_14 | 8;
    puVar4 = &uStack_1c0;
    uStack_8 = 5;
  }
  else {
    uStack_f0 = thunk_FUN_00c7d370();
    iStack_ec = 0;
    uStack_e8 = *puVar4;
    iStack_ec = FUN_00c7d6c0();
    uStack_14 = uStack_14 | 4;
    puVar4 = &uStack_f0;
    uStack_8 = 4;
  }
  uVar2 = thunk_FUN_00c7d370();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 8) != 0) {
    uStack_14 = uStack_14 & 0xfffffff7;
    uStack_8 = 6;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  if ((uStack_14 & 4) != 0) {
    uStack_14 = uStack_14 & 0xfffffffb;
    uStack_8 = 7;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(iStack_1c + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    uStack_14 = uStack_14 | 0x20;
    puVar4 = &uStack_1c0;
    uStack_8 = 9;
  }
  else {
    uStack_f0 = thunk_FUN_00c7d400();
    iStack_ec = 0;
    uStack_e8 = *puVar4;
    iStack_ec = FUN_00c7d730();
    uStack_14 = uStack_14 | 0x10;
    puVar4 = &uStack_f0;
    uStack_8 = 8;
  }
  uVar2 = thunk_FUN_00c7d400();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 0x20) != 0) {
    uStack_14 = uStack_14 & 0xffffffdf;
    uStack_8 = 10;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  if ((uStack_14 & 0x10) != 0) {
    uStack_14 = uStack_14 & 0xffffffef;
    uStack_8 = 0xb;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(iStack_1c + 0x4c);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    uStack_14 = uStack_14 | 0x80;
    puVar4 = &uStack_1c0;
    uStack_8 = 0xd;
  }
  else {
    uStack_f0 = FUN_0088c960();
    iStack_ec = 0;
    uStack_e8 = *puVar4;
    iStack_ec = FUN_00630820();
    uStack_14 = uStack_14 | 0x40;
    puVar4 = &uStack_f0;
    uStack_8 = 0xc;
  }
  uVar2 = FUN_0088c960();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((char)uStack_14 < '\0') {
    uStack_14 = uStack_14 & 0xffffff7f;
    uStack_8 = 0xe;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  if ((uStack_14 & 0x40) != 0) {
    uStack_14 = uStack_14 & 0xffffffbf;
    uStack_8 = 0xf;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  uStack_8 = 0xffffffff;
  puVar1 = *(undefined **)(iStack_1c + 0x50);
  if (puVar1 == (undefined *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    uStack_14 = uStack_14 | 0x200;
    puVar4 = &uStack_1c0;
    uStack_8 = 0x11;
  }
  else {
    uStack_f0 = FUN_0088daf0();
    iStack_ec = 0;
    uStack_e8 = CONCAT31(uStack_e8._1_3_,*puVar1);
    iStack_ec = FUN_005c9ef0();
    uStack_14 = uStack_14 | 0x100;
    puVar4 = &uStack_f0;
    uStack_8 = 0x10;
  }
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(param_6);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 0x200) != 0) {
    uStack_14 = uStack_14 & 0xfffffdff;
    uStack_8 = 0x12;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  if ((uStack_14 & 0x100) != 0) {
    uStack_14 = uStack_14 & 0xfffffeff;
    uStack_8 = 0x13;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(iStack_1c + 0x54) == 0) {
    uStack_290 = FUN_00888530();
    iStack_28c = 0;
    param_2 = &uStack_290;
    uVar5 = uStack_14 | 0x800;
    uStack_8 = 0x15;
  }
  else {
    param_2 = (undefined4 *)FUN_008bc7a0(*(int *)(iStack_1c + 0x54));
    uStack_8 = 0x14;
    uVar5 = uStack_14 | 0x400;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_00d88470();
  uVar3 = FUN_0086e3d0(param_7);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((uVar5 & 0x800) != 0) {
    uVar5 = uVar5 & 0xfffff7ff;
    uStack_8 = 0x16;
    uStack_14 = uVar5;
    if (iStack_28c != 0) {
      (**(code **)(iStack_28c + 8))(auStack_288);
    }
  }
  if (((uVar5 & 0x400) != 0) && (uStack_8 = 0x17, iStack_35c != 0)) {
    (**(code **)(iStack_35c + 8))(auStack_358);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29194 ; VA 0x00c75290 ; FUN_00c75290 */

void FUN_00c75290(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8524;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = FUN_0088c8c0();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1bc = FUN_005c9cc0();
  iStack_8._0_1_ = 1;
  uStack_f0 = FUN_0088c8c0();
  uStack_ec = 0;
  uStack_e8 = param_3;
  uStack_ec = FUN_005c9cc0();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  iStack_8._0_1_ = 3;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 4;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  iStack_8 = 5;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29195 ; VA 0x00c753c0 ; FUN_00c753c0 */

void FUN_00c753c0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbcf9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_f0 = FUN_0088d5f0();
  uStack_ec = 0;
  uStack_e8 = param_2;
  uStack_e4 = param_3;
  uStack_e0 = param_4;
  uStack_dc = param_5;
  uStack_ec = FUN_006313f0();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,piVar1);
  iStack_8._0_1_ = 2;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 3;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  iStack_8 = 4;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29196 ; VA 0x00c754c0 ; FUN_00c754c0 */

int FUN_00c754c0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
                undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  code *pcVar4;
  undefined4 uVar5;
  int iVar6;
  undefined auStack_360 [208];
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180e4e2;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290(DAT_02110da8);
  piVar3 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar4 = *(code **)(*piVar3 + 4);
  uStack_20 = uVar5;
  FUN_005c1420(&param_2);
  uStack_8._0_1_ = 2;
  uStack_290 = FUN_0088c960();
  uStack_28c = 0;
  uStack_288 = param_4;
  uStack_28c = FUN_00630820();
  uStack_8._0_1_ = 3;
  uStack_1c0 = FUN_0088c960();
  uStack_1bc = 0;
  uStack_1b8 = param_5;
  uStack_1bc = FUN_00630820();
  uStack_8._0_1_ = 4;
  uStack_f0 = thunk_FUN_00d82070();
  uStack_ec = 0;
  uStack_e8 = param_6;
  uStack_ec = FUN_00b84ba0();
  uStack_8._0_1_ = 5;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(auStack_360,&uStack_20,piVar3);
  uStack_8._0_1_ = 6;
  (*pcVar4)(&uStack_1c);
  uStack_8._0_1_ = 7;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(auStack_360,0xd0,4,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  iVar6 = FUN_01675290(uVar5);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 29197 ; VA 0x00c75660 ; FUN_00c75660 */

int FUN_00c75660(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
                undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  code *pcVar4;
  undefined4 uVar5;
  int iVar6;
  undefined auStack_360 [208];
  undefined4 uStack_290;
  undefined4 uStack_28c;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180e4e2;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290(DAT_02110da8);
  piVar3 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar4 = *(code **)(*piVar3 + 4);
  uStack_20 = uVar5;
  FUN_005c1420(&param_2);
  uStack_8._0_1_ = 2;
  uStack_290 = FUN_0088d730();
  uStack_288 = param_4;
  uStack_28c = 0;
  uStack_284 = param_5;
  uStack_28c = FUN_006314d0();
  uStack_8._0_1_ = 3;
  uStack_1c0 = FUN_0088d730();
  uStack_1b8 = param_6;
  uStack_1bc = 0;
  uStack_1b4 = param_7;
  uStack_1bc = FUN_006314d0();
  uStack_8._0_1_ = 4;
  uStack_f0 = thunk_FUN_00d82070();
  uStack_ec = 0;
  uStack_e8 = param_8;
  uStack_ec = FUN_00b84ba0();
  uStack_8._0_1_ = 5;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(auStack_360,&uStack_20,piVar3);
  uStack_8._0_1_ = 6;
  (*pcVar4)(&uStack_1c);
  uStack_8._0_1_ = 7;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(auStack_360,0xd0,4,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  iVar6 = FUN_01675290(uVar5);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 29198 ; VA 0x00c75800 ; FUN_00c75800 */

int FUN_00c75800(int param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  code *pcVar4;
  undefined4 uVar5;
  int iVar6;
  undefined auStack_1c0 [208];
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f88fc;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290(DAT_02110da8);
  piVar3 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar4 = *(code **)(*piVar3 + 4);
  uStack_20 = uVar5;
  FUN_005c1420(&param_2);
  uStack_8._0_1_ = 2;
  uStack_f0 = thunk_FUN_00d82070();
  uStack_ec = 0;
  uStack_e8 = param_4;
  uStack_ec = FUN_00b84ba0();
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(auStack_1c0,&uStack_20,piVar3);
  uStack_8._0_1_ = 4;
  (*pcVar4)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(auStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  iVar6 = FUN_01675290(uVar5);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 29199 ; VA 0x00c75940 ; FUN_00c75940 */

int FUN_00c75940(int param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  code *pcVar4;
  undefined4 uVar5;
  int iVar6;
  undefined auStack_1c0 [208];
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3c7c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290(DAT_02110da8);
  piVar3 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar4 = *(code **)(*piVar3 + 4);
  uStack_20 = uVar5;
  FUN_006874f0(&param_2);
  uStack_8._0_1_ = 2;
  uStack_f0 = FUN_0088c8c0();
  uStack_ec = 0;
  uStack_e8 = param_4;
  uStack_ec = FUN_005c9cc0();
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(auStack_1c0,&uStack_20,piVar3);
  uStack_8._0_1_ = 4;
  (*pcVar4)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(auStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  iVar6 = FUN_01675290(uVar5);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 29200 ; VA 0x00c75a80 ; FUN_00c75a80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00c75a80(int param_1,undefined4 param_2,undefined4 param_3)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uStack_1c0;
  undefined *puStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8524;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_02110da8);
  iStack_8 = 0;
  pcVar1 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar2;
  uStack_1c0 = thunk_FUN_00b84860();
  uStack_1b8 = param_2;
  puStack_1bc = (undefined *)0x0;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef1bdc) {
    FUN_016f3809(&DAT_01ef1bdc);
    if (DAT_01ef1bdc == -1) {
      _DAT_01ef1bd0 = FUN_005c65e0;
      _DAT_01ef1bd4 = FUN_005c65e0;
      _DAT_01ef1bd8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ef1bdc);
    }
  }
  puStack_1bc = &DAT_01ef1bd0;
  iStack_8._0_1_ = 1;
  uStack_f0 = FUN_0088c8c0();
  uStack_ec = 0;
  uStack_e8 = param_3;
  uStack_ec = FUN_005c9cc0();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,pcVar1);
  iStack_8._0_1_ = 3;
  (*pcVar1)(&uStack_1c);
  iStack_8._0_1_ = 4;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  iStack_8 = 5;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29201 ; VA 0x00c75c10 ; FUN_00c75c10 */

void FUN_00c75c10(undefined4 param_1,undefined4 param_2)

{
  FUN_00c70360(param_2);
  return;
}



/* FUNCTION 29202 ; VA 0x00c75c30 ; FUN_00c75c30 */

void FUN_00c75c30(undefined4 param_1,undefined4 param_2)

{
  FUN_00c704d0(param_2);
  return;
}



/* FUNCTION 29203 ; VA 0x00c75c50 ; FUN_00c75c50 */

void * FUN_00c75c50(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  int *piVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e4f8;
  pvStack_10 = ExceptionList;
  pvVar4 = ExceptionList;
  if (param_2 == 2) {
    ExceptionList = &pvStack_10;
    pvVar4 = (void *)FUN_00587490(&iStack_18);
    uStack_8 = 0;
    if (iStack_18 != 0) {
      FUN_01679490();
      pvVar4 = (void *)FUN_008f7870(iStack_18);
      if (pvVar4 != (void *)0x0) {
        piVar5 = *(int **)(param_1 + 0x1c);
        if (piVar5 != (int *)0x0) {
          LOCK();
          piVar5[2] = piVar5[2] + 1;
          UNLOCK();
          piVar5 = *(int **)(param_1 + 0x1c);
        }
        uVar3 = *(undefined4 *)(param_1 + 0x18);
        piVar1 = piVar5 + 2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        FUN_00c6d7c0(uVar3,piVar5,0);
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar2 = *piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
        pvVar4 = (void *)FUN_0090ca30();
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar5 = piStack_14 + 1;
      iVar2 = *piVar5;
      pvVar4 = (void *)*piVar5;
      *piVar5 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)*piStack_14)();
        LOCK();
        piVar5 = piStack_14 + 2;
        iVar2 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar4 = (void *)(**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 29204 ; VA 0x00c75d50 ; FUN_00c75d50 */

void FUN_00c75d50(undefined4 param_1,undefined4 param_2)

{
  FUN_00c706a0(param_2);
  return;
}



/* FUNCTION 29205 ; VA 0x00c75d70 ; FUN_00c75d70 */

void FUN_00c75d70(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  (**(code **)(param_1 + 0x18))(param_2,param_3,param_4,param_5);
  return;
}



/* FUNCTION 29206 ; VA 0x00c75d90 ; FUN_00c75d90 */

int __fastcall FUN_00c75d90(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e518;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  iVar4 = FUN_00587490(&iStack_1c);
  uStack_8 = 0;
  if (iStack_1c != 0) {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    iVar4 = FUN_0089be10(iStack_1c,piStack_18);
    *(undefined4 *)(param_1 + 0x348) = 0;
    piVar3 = *(int **)(param_1 + 0x34c);
    *(undefined4 *)(param_1 + 0x34c) = 0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_18 + 1;
    iVar2 = *piVar3;
    iVar4 = *piVar3;
    *piVar3 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piStack_18)();
      LOCK();
      piVar3 = piStack_18 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 29207 ; VA 0x00c75e60 ; FUN_00c75e60 */

uint __fastcall FUN_00c75e60(int param_1)

{
  float *pfVar1;
  float fVar2;
  float *pfVar3;
  float *pfVar4;
  float fVar5;
  undefined auStack_24 [16];
  undefined auStack_14 [16];
  undefined2 uVar6;
  
  pfVar3 = (float *)(**(code **)(param_1 + 8))(auStack_14);
  pfVar4 = (float *)(**(code **)(param_1 + 8))(auStack_24);
  fVar2 = *pfVar3;
  uVar6 = (undefined2)((uint)pfVar4 >> 0x10);
  fVar5 = (float)((uint)CONCAT21(uVar6,(fVar2 == *pfVar4) << 6 | (NAN(fVar2) || NAN(*pfVar4)) << 2 |
                                       2U | fVar2 < *pfVar4) << 8);
  if (((NAN(fVar2) || NAN(*pfVar4)) != (fVar2 == *pfVar4)) && (pfVar3[1] == pfVar4[1])) {
    fVar2 = pfVar3[2];
    pfVar1 = pfVar4 + 2;
    fVar5 = (float)((uint)CONCAT21(uVar6,(fVar2 == *pfVar1) << 6 | (NAN(fVar2) || NAN(*pfVar1)) << 2
                                         | 2U | fVar2 < *pfVar1) << 8);
    if (((NAN(fVar2) || NAN(*pfVar1)) != (fVar2 == *pfVar1)) &&
       (fVar5 = pfVar3[3], fVar5 == pfVar4[3])) {
      return CONCAT31((int3)((uint)fVar5 >> 8),1);
    }
  }
  return (uint)fVar5 & 0xffffff00;
}



/* FUNCTION 29208 ; VA 0x00c75ed0 ; FUN_00c75ed0 */

undefined4 FUN_00c75ed0(undefined4 param_1,undefined4 param_2,int param_3)

{
  undefined uVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  float10 fVar6;
  undefined auStack_a0 [32];
  undefined auStack_80 [16];
  undefined auStack_70 [16];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  float fStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_0180e53b;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300(param_2);
  iVar2 = iVar2 - param_3;
  uStack_2c = FUN_009d1820(auStack_a0,param_2,param_3,7,iVar2,(int)pcStack_28 + 0x58);
  uStack_14 = 0;
  uVar1 = FUN_009d1aa0(param_2,param_3,6,iVar2,(int)pcStack_28 + 0x54);
  uStack_30 = CONCAT31(uStack_30._1_3_,uVar1);
  fVar6 = (float10)FUN_009d0730(param_2,param_3,5,iVar2,(int)pcStack_28 + 0x50);
  fStack_34 = (float)fVar6;
  uStack_38 = FUN_00c76ba0(param_2,param_3,4,iVar2,(int)pcStack_28 + 0x4c);
  uStack_3c = FUN_00c769f0(param_2,param_3,3,iVar2,(int)pcStack_28 + 0x48);
  puVar3 = (undefined4 *)FUN_00c76870(auStack_70,param_2,param_3,2,iVar2,(int)pcStack_28 + 0x44);
  puVar4 = (undefined4 *)FUN_00c76870(auStack_80,param_2,param_3,1,iVar2,(int)pcStack_28 + 0x40);
  uStack_50 = *puVar3;
  uStack_4c = puVar3[1];
  uStack_48 = puVar3[2];
  uStack_44 = puVar3[3];
  pcStack_28 = *(code **)((int)pcStack_28 + 0x38);
  uStack_60 = *puVar4;
  uStack_5c = puVar4[1];
  uStack_58 = puVar4[2];
  uStack_54 = puVar4[3];
  FUN_00d88580(uStack_2c);
  uVar5 = (*pcStack_28)(uStack_60,uStack_5c,uStack_58,uStack_54,uStack_50,uStack_4c,uStack_48,
                        uStack_44,uStack_3c,uStack_38,fStack_34,uStack_30);
  uVar5 = FUN_009d5ac0(param_2,uVar5);
  FUN_00d88a30();
  ExceptionList = pvStack_1c;
  return uVar5;
}



/* FUNCTION 29209 ; VA 0x00c76060 ; FUN_00c76060 */

undefined4 FUN_00c76060(undefined4 param_1,undefined4 param_2,int param_3)

{
  code *pcVar1;
  undefined uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  float10 fVar6;
  undefined auStack_78 [32];
  undefined auStack_58 [16];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  float fStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_0180e558;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_01256300(param_2);
  iVar3 = iVar3 - param_3;
  uStack_28 = FUN_009d1820(auStack_78,param_2,param_3,6,iVar3,iStack_24 + 0x54);
  uStack_14 = 0;
  uVar2 = FUN_009d1aa0(param_2,param_3,5,iVar3,iStack_24 + 0x50);
  uStack_2c = CONCAT31(uStack_2c._1_3_,uVar2);
  fVar6 = (float10)FUN_009d0730(param_2,param_3,4,iVar3,iStack_24 + 0x4c);
  fStack_30 = (float)fVar6;
  uStack_34 = FUN_00c76ba0(param_2,param_3,3,iVar3,iStack_24 + 0x48);
  uStack_38 = FUN_00c769f0(param_2,param_3,2,iVar3,iStack_24 + 0x44);
  puVar4 = (undefined4 *)FUN_00c76870(auStack_58,param_2,param_3,1,iVar3,iStack_24 + 0x40);
  uStack_48 = *puVar4;
  uStack_44 = puVar4[1];
  uStack_40 = puVar4[2];
  uStack_3c = puVar4[3];
  pcVar1 = *(code **)(iStack_24 + 0x38);
  FUN_00d88580(uStack_28);
  uVar5 = (*pcVar1)(uStack_48,uStack_44,uStack_40,uStack_3c,uStack_38,uStack_34,fStack_30,uStack_2c)
  ;
  uVar5 = FUN_009d5ac0(param_2,uVar5);
  FUN_00d88a30();
  ExceptionList = pvStack_1c;
  return uVar5;
}



/* FUNCTION 29210 ; VA 0x00c761b0 ; FUN_00c761b0 */

void FUN_00c761b0(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  
  iVar1 = *param_2;
  iVar5 = *(int *)(iVar1 + 0xd0);
  iVar3 = FUN_0088c8c0();
  if (iVar5 == iVar3) {
    puVar4 = (undefined4 *)(iVar1 + 0xd8);
    param_2 = (int *)*param_2;
    if (*(int *)(iVar1 + 0xd4) == 0) {
      puVar4 = (undefined4 *)0x0;
    }
    iVar1 = *param_2;
    uVar2 = *puVar4;
    iVar5 = FUN_0088c8c0();
    if (iVar1 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
      FUN_006150c0(*piVar6,uVar2);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29211 ; VA 0x00c76230 ; FUN_00c76230 */

void FUN_00c76230(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  iVar6 = *param_2;
  iVar4 = *(int *)(iVar6 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088c8c0();
  if (iVar4 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar3 = (undefined4 *)(iVar6 + 0xd8);
  param_2 = (int *)*param_2;
  if (*(int *)(iVar6 + 0xd4) == 0) {
    puVar3 = (undefined4 *)0x0;
  }
  iVar6 = *param_2;
  uVar1 = *puVar3;
  iVar4 = FUN_0088cdc0();
  if (iVar6 == iVar4) {
    piVar5 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar5 = (int *)0x0;
    }
    iVar6 = piVar5[1];
    if (iVar6 != 0) {
      LOCK();
      *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
      UNLOCK();
      iVar6 = piVar5[1];
    }
    uStack_8 = 0;
    FUN_0089bf10(*piVar5,iVar6,uVar1);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29212 ; VA 0x00c76300 ; FUN_00c76300 */

void FUN_00c76300(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  int *piVar7;
  int iVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d47a8;
  pvStack_10 = ExceptionList;
  iVar8 = *param_2;
  iVar6 = *(int *)(iVar8 + 0x270);
  ExceptionList = &pvStack_10;
  iVar4 = thunk_FUN_00d82070();
  if (iVar6 != iVar4) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar5 = (undefined4 *)(iVar8 + 0x278);
  iVar6 = *param_2;
  if (*(int *)(iVar8 + 0x274) == 0) {
    puVar5 = (undefined4 *)0x0;
  }
  iVar8 = *(int *)(iVar6 + 0x1a0);
  uVar3 = *puVar5;
  iVar4 = FUN_0088c960();
  if (iVar8 != iVar4) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar5 = (undefined4 *)(iVar6 + 0x1a8);
  iVar8 = *param_2;
  if (*(int *)(iVar6 + 0x1a4) == 0) {
    puVar5 = (undefined4 *)0x0;
  }
  iVar6 = *(int *)(iVar8 + 0xd0);
  uVar1 = *puVar5;
  iVar4 = FUN_0088c960();
  if (iVar6 != iVar4) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar5 = (undefined4 *)(iVar8 + 0xd8);
  param_2 = (int *)*param_2;
  if (*(int *)(iVar8 + 0xd4) == 0) {
    puVar5 = (undefined4 *)0x0;
  }
  iVar8 = *param_2;
  uVar2 = *puVar5;
  iVar6 = FUN_008882f0();
  if (iVar8 == iVar6) {
    piVar7 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar7 = (int *)0x0;
    }
    iVar8 = piVar7[1];
    if (iVar8 != 0) {
      LOCK();
      *(int *)(iVar8 + 4) = *(int *)(iVar8 + 4) + 1;
      UNLOCK();
      iVar8 = piVar7[1];
    }
    uStack_8 = 0;
    FUN_00c70890(*piVar7,iVar8,uVar2,uVar1,uVar3);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29213 ; VA 0x00c76460 ; FUN_00c76460 */

void FUN_00c76460(undefined4 param_1,undefined4 param_2)

{
  FUN_00c6e810(param_1,param_2,param_2);
  return;
}



/* FUNCTION 29214 ; VA 0x00c76480 ; FUN_00c76480 */

void FUN_00c76480(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795998;
  pvStack_10 = ExceptionList;
  iVar6 = *param_2;
  iVar4 = *(int *)(iVar6 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar2 = thunk_FUN_00d82070();
  if (iVar4 != iVar2) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar3 = (undefined4 *)(iVar6 + 0xd8);
  param_2 = (int *)*param_2;
  if (*(int *)(iVar6 + 0xd4) == 0) {
    puVar3 = (undefined4 *)0x0;
  }
  iVar6 = *param_2;
  uVar1 = *puVar3;
  iVar4 = FUN_008882f0();
  if (iVar6 == iVar4) {
    piVar5 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar5 = (int *)0x0;
    }
    iVar6 = piVar5[1];
    if (iVar6 != 0) {
      LOCK();
      *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
      UNLOCK();
      iVar6 = piVar5[1];
    }
    uStack_8 = 0;
    FUN_00b7ce90(*piVar5,iVar6,uVar1);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29215 ; VA 0x00c76550 ; FUN_00c76550 */

void FUN_00c76550(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar2 = FUN_0088d5f0();
  if (iVar1 == iVar2) {
    piVar3 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_00b91f60(*piVar3,piVar3[1],piVar3[2],piVar3[3]);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29216 ; VA 0x00c765a0 ; FUN_00c765a0 */

void FUN_00c765a0(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  
  iVar1 = *param_2;
  iVar5 = *(int *)(iVar1 + 0xd0);
  iVar3 = FUN_0088c8c0();
  if (iVar5 == iVar3) {
    puVar4 = (undefined4 *)(iVar1 + 0xd8);
    param_2 = (int *)*param_2;
    if (*(int *)(iVar1 + 0xd4) == 0) {
      puVar4 = (undefined4 *)0x0;
    }
    iVar1 = *param_2;
    uVar2 = *puVar4;
    iVar5 = thunk_FUN_00b84860();
    if (iVar1 == iVar5) {
      piVar6 = param_2 + 2;
      if (param_2[1] == 0) {
        piVar6 = (int *)0x0;
      }
      FUN_006150c0(*piVar6,uVar2);
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 29217 ; VA 0x00c76620 ; FUN_00c76620 */

void FUN_00c76620(undefined4 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 in_stack_ffffffb4;
  undefined4 in_stack_ffffffb8;
  undefined4 in_stack_ffffffbc;
  undefined4 uVar2;
  undefined4 in_stack_ffffffc0;
  undefined4 uVar3;
  undefined4 in_stack_ffffffc4;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 in_stack_ffffffc8;
  undefined4 in_stack_ffffffcc;
  undefined4 uVar6;
  
  switch(param_1) {
  case 0:
    FUN_00557fc0(param_2);
    FUN_0091bc20(in_stack_ffffffc8,in_stack_ffffffcc);
    return;
  case 1:
    puVar1 = (undefined4 *)FUN_00b7a3f0();
    uVar5 = *puVar1;
    FUN_00557fc0(param_2);
    FUN_00b7ce90(in_stack_ffffffc4,in_stack_ffffffc8,uVar5);
    return;
  case 2:
    puVar1 = (undefined4 *)FUN_0055d5e0();
    uVar5 = *puVar1;
    puVar1 = (undefined4 *)FUN_00b7a3c0();
    FUN_006150c0(*puVar1,uVar5);
    return;
  case 3:
    puVar1 = (undefined4 *)FUN_00b7a3f0();
    uVar2 = *puVar1;
    puVar1 = (undefined4 *)FUN_00605b70();
    uVar5 = *puVar1;
    puVar1 = (undefined4 *)FUN_00605b70();
    uVar4 = *puVar1;
    FUN_00557fc0(param_2);
    FUN_00c70890(in_stack_ffffffbc,in_stack_ffffffc0,uVar4,uVar5,uVar2);
    return;
  case 4:
    puVar1 = (undefined4 *)FUN_00b7a3f0();
    uVar2 = *puVar1;
    puVar1 = (undefined4 *)FUN_00605b70();
    uVar5 = *puVar1;
    puVar1 = (undefined4 *)FUN_00605b70();
    uVar4 = *puVar1;
    FUN_00557fc0(param_2);
    FUN_00c70890(in_stack_ffffffbc,in_stack_ffffffc0,uVar4,uVar5,uVar2);
    return;
  case 5:
    puVar1 = (undefined4 *)FUN_00b7a3f0();
    uVar6 = *puVar1;
    puVar1 = (undefined4 *)FUN_00605c30();
    uVar5 = *puVar1;
    uVar4 = puVar1[1];
    puVar1 = (undefined4 *)FUN_00605c30();
    uVar2 = *puVar1;
    uVar3 = puVar1[1];
    FUN_00557fc0(param_2);
    FUN_00c709a0(in_stack_ffffffb4,in_stack_ffffffb8,uVar2,uVar3,uVar5,uVar4,uVar6);
  }
  return;
}



/* FUNCTION 29218 ; VA 0x00c76870 ; FUN_00c76870 */

undefined4 *
FUN_00c76870(undefined4 *param_1,undefined4 param_2,int param_3,int param_4,int param_5,int *param_6
            )

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [204];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c871b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 <= param_5) {
    ExceptionList = &pvStack_10;
    puVar5 = (undefined4 *)FUN_01257810(param_2,param_3 + param_4,DAT_01ede6ec);
    if (puVar5 != (undefined4 *)0x0) {
      uVar2 = puVar5[1];
      uVar1 = puVar5[2];
      uVar3 = puVar5[3];
      *param_1 = *puVar5;
      param_1[1] = uVar2;
      param_1[2] = uVar1;
      param_1[3] = uVar3;
      ExceptionList = pvStack_10;
      return param_1;
    }
    if (param_4 <= param_5) {
      uStack_f0 = FUN_00888530();
      iStack_ec = 0;
      uStack_8 = 0;
      cVar4 = FUN_009d1bf0(param_2,param_3 + param_4,&uStack_f0,1);
      if (cVar4 != '\0') {
        puVar5 = (undefined4 *)FUN_0088b450();
        uVar1 = puVar5[1];
        uVar2 = puVar5[2];
        uVar3 = puVar5[3];
        *param_1 = *puVar5;
        param_1[1] = uVar1;
        param_1[2] = uVar2;
        param_1[3] = uVar3;
        uStack_8 = 1;
        if (iStack_ec == 0) {
          ExceptionList = pvStack_10;
          return param_1;
        }
        (**(code **)(iStack_ec + 8))(auStack_e8);
        ExceptionList = pvStack_10;
        return param_1;
      }
      uStack_8 = 2;
      if (iStack_ec != 0) {
        (**(code **)(iStack_ec + 8))(auStack_e8);
      }
      uStack_8 = 0xffffffff;
    }
  }
  puVar5 = (undefined4 *)*param_6;
  if (puVar5 != (undefined4 *)0x0) {
    uVar1 = puVar5[1];
    uVar2 = puVar5[2];
    uVar3 = puVar5[3];
    *param_1 = *puVar5;
    param_1[1] = uVar1;
    param_1[2] = uVar2;
    param_1[3] = uVar3;
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",param_4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 29219 ; VA 0x00c769f0 ; FUN_00c769f0 */

int FUN_00c769f0(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar1 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e587;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 <= param_4) {
    ExceptionList = &pvStack_10;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff3f4)
       && (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eff3f4), DAT_01eff3f4 == -1)) {
      uStack_8 = 0;
      FUN_00da8ff0();
      FUN_016f3654(&LAB_01896680);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eff3f4);
    }
    cVar2 = FUN_009d1e20(&DAT_01eff390,param_1,param_2 + iVar1,&param_3);
    if (cVar2 != '\0') {
      ExceptionList = pvStack_10;
      return param_3;
    }
  }
  if (iVar1 <= param_4) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8 = 1;
    cVar2 = FUN_009d1bf0(param_1,param_2 + iVar1,&uStack_ec,1);
    if (cVar2 != '\0') {
      piVar3 = (int *)FUN_00da8d80();
      iVar1 = *piVar3;
      uStack_8 = 2;
      if (iStack_e8 == 0) {
        ExceptionList = pvStack_10;
        return iVar1;
      }
      (**(code **)(iStack_e8 + 8))(auStack_e4);
      ExceptionList = pvStack_10;
      return iVar1;
    }
    uStack_8 = 3;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
  }
  if ((int *)*param_5 != (int *)0x0) {
    ExceptionList = pvStack_10;
    return *(int *)*param_5;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 29220 ; VA 0x00c76ba0 ; FUN_00c76ba0 */

int FUN_00c76ba0(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar1 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e5b7;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 <= param_4) {
    ExceptionList = &pvStack_10;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eff45c)
       && (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eff45c), DAT_01eff45c == -1)) {
      uStack_8 = 0;
      FUN_00da9050();
      FUN_016f3654(&LAB_018966a0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eff45c);
    }
    cVar2 = FUN_009d1e20(&DAT_01eff3f8,param_1,param_2 + iVar1,&param_3);
    if (cVar2 != '\0') {
      ExceptionList = pvStack_10;
      return param_3;
    }
  }
  if (iVar1 <= param_4) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    uStack_8 = 1;
    cVar2 = FUN_009d1bf0(param_1,param_2 + iVar1,&uStack_ec,1);
    if (cVar2 != '\0') {
      piVar3 = (int *)FUN_00da8e50();
      iVar1 = *piVar3;
      uStack_8 = 2;
      if (iStack_e8 == 0) {
        ExceptionList = pvStack_10;
        return iVar1;
      }
      (**(code **)(iStack_e8 + 8))(auStack_e4);
      ExceptionList = pvStack_10;
      return iVar1;
    }
    uStack_8 = 3;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
  }
  if ((int *)*param_5 != (int *)0x0) {
    ExceptionList = pvStack_10;
    return *(int *)*param_5;
  }
  FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 29221 ; VA 0x00c76d50 ; FUN_00c76d50 */

void __thiscall FUN_00c76d50(int *param_1,float *param_2)

{
  float fVar1;
  int iVar2;
  
  (**(code **)(*param_1 + 0x100))("AbsolutePosition");
  iVar2 = FUN_006ebc30(param_1);
  if ((iVar2 != 0) && (*(char *)(param_1 + 0x53) != '\0')) {
    fVar1 = *(float *)(iVar2 + 0xfc);
    *param_2 = (float)param_1[0x26] - *(float *)(iVar2 + 0xf8);
    param_2[1] = (float)param_1[0x27] - fVar1;
    return;
  }
  *param_2 = (float)param_1[0x26];
  param_2[1] = (float)param_1[0x27];
  return;
}



/* FUNCTION 29222 ; VA 0x00c76dd0 ; FUN_00c76dd0 */

void __thiscall FUN_00c76dd0(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 300);
  *param_2 = *(undefined4 *)(param_1 + 0x128);
  param_2[1] = uVar1;
  return;
}



/* FUNCTION 29223 ; VA 0x00c76e10 ; FUN_00c76e10 */

undefined4 __thiscall FUN_00c76e10(int param_1,undefined4 param_2)

{
  FUN_00c987e0(param_2,*(undefined8 *)(param_1 + 0x328),*(undefined4 *)(param_1 + 0x330));
  return param_2;
}



/* FUNCTION 29224 ; VA 0x00c76e40 ; FUN_00c76e40 */

void __thiscall FUN_00c76e40(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x33c);
  *param_2 = *(undefined8 *)(param_1 + 0x334);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 29225 ; VA 0x00c76e60 ; FUN_00c76e60 */

undefined4 __thiscall FUN_00c76e60(int param_1,undefined4 param_2)

{
  FUN_00c987e0(param_2,*(undefined8 *)(param_1 + 0x334),*(undefined4 *)(param_1 + 0x33c));
  return param_2;
}



/* FUNCTION 29226 ; VA 0x00c76eb0 ; FUN_00c76eb0 */

void FUN_00c76eb0(void)

{
  int iVar1;
  
  if (DAT_01efef44 == 0) {
    iVar1 = FUN_00c6dcc0();
    DAT_01efef44 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29227 ; VA 0x00c76ed0 ; FUN_00c76ed0 */

void FUN_00c76ed0(void)

{
  int iVar1;
  
  if (DAT_01eff15c == 0) {
    iVar1 = FUN_00c6dda0();
    DAT_01eff15c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29228 ; VA 0x00c76ef0 ; FUN_00c76ef0 */

void FUN_00c76ef0(void)

{
  int iVar1;
  
  if (DAT_01efed2c == 0) {
    iVar1 = FUN_00c6de80();
    DAT_01efed2c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 29229 ; VA 0x00c76f10 ; FUN_00c76f10 */

undefined4 __thiscall FUN_00c76f10(int param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_c = *param_3;
  uStack_8 = param_3[1];
  if (*(int *)(param_1 + 0x31c) == 1) {
    uStack_8 = *param_3;
  }
  else if (*(int *)(param_1 + 0x31c) != 2) goto LAB_00c76f4c;
  uStack_c = uStack_8;
LAB_00c76f4c:
  FUN_00da7e90(param_2,uStack_c,uStack_8);
  return param_2;
}



/* FUNCTION 29230 ; VA 0x00c76f80 ; FUN_00c76f80 */

void __fastcall FUN_00c76f80(int param_1)

{
  int *piVar1;
  
  if (*(int *)(param_1 + 0x15c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x15c) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00c776a0(*(undefined4 *)(param_1 + 0x158),*(undefined4 *)(param_1 + 0x15c),param_1);
  return;
}



/* FUNCTION 29231 ; VA 0x00c76fd0 ; FUN_00c76fd0 */

void __fastcall FUN_00c76fd0(int param_1)

{
  int *piVar1;
  
  if (*(int *)(param_1 + 0x164) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x164) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00c776a0(*(undefined4 *)(param_1 + 0x160),*(undefined4 *)(param_1 + 0x164),param_1);
  return;
}



/* FUNCTION 29232 ; VA 0x00c77020 ; FUN_00c77020 */

void __fastcall FUN_00c77020(int param_1)

{
  int *piVar1;
  
  if (*(int *)(param_1 + 0x16c) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x16c) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00c776a0(*(undefined4 *)(param_1 + 0x168),*(undefined4 *)(param_1 + 0x16c),param_1);
  return;
}



/* FUNCTION 29233 ; VA 0x00c77070 ; FUN_00c77070 */

void __fastcall FUN_00c77070(int param_1)

{
  int *piVar1;
  
  if (*(int *)(param_1 + 0x154) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x154) + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00c776a0(*(undefined4 *)(param_1 + 0x150),*(undefined4 *)(param_1 + 0x154),param_1);
  return;
}



/* FUNCTION 29234 ; VA 0x00c770c0 ; FUN_00c770c0 */

undefined * __thiscall FUN_00c770c0(int param_1,undefined *param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *apiStack_90 [2];
  int *apiStack_88 [2];
  int *piStack_80;
  int *piStack_7c;
  int *piStack_78;
  int *piStack_74;
  int *piStack_70;
  int *piStack_6c;
  int *piStack_68;
  int *piStack_64;
  int *piStack_60;
  undefined4 uStack_5c;
  int *piStack_58;
  int *piStack_54;
  int *piStack_50;
  int *piStack_4c;
  int *piStack_48;
  int *piStack_44;
  int *piStack_40;
  int *piStack_3c;
  int *piStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e63f;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  iStack_14 = param_1;
  uVar2 = FUN_00588320(0xb);
  *(undefined4 *)(param_2 + 4) = uVar2;
  *(undefined4 *)(param_2 + 8) = 0;
  *(undefined4 *)(param_2 + 0xc) = 0x3f800000;
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0;
  uStack_8 = 0;
  uStack_18 = 1;
  if (param_3 == (undefined4 *)&DAT_02138218) {
    iVar3 = *(int *)(param_1 + 0xf4);
    piStack_48 = (int *)0x0;
    piStack_44 = (int *)0x0;
    if (iVar3 != 0) {
      piVar1 = (int *)(iVar3 + 4);
      iVar3 = *(int *)(iVar3 + 4);
      while (iVar3 != 0) {
        LOCK();
        iVar5 = *piVar1;
        if (iVar3 == iVar5) {
          *piVar1 = iVar3 + 1;
          iVar5 = iVar3;
        }
        UNLOCK();
        if (iVar5 == iVar3) {
          piStack_48 = *(int **)(param_1 + 0xf0);
          piStack_44 = *(int **)(param_1 + 0xf4);
          break;
        }
        iVar3 = *piVar1;
      }
    }
    piVar1 = piStack_44;
    uStack_8 = 1;
    if (piStack_48 != (int *)0x0) {
      uVar2 = (**(code **)(*piStack_48 + 0xa4))(&DAT_02138218);
      piStack_1c = piStack_48;
      iVar3 = FUN_00bb3290(&piStack_1c);
      *(undefined4 *)(iVar3 + 4) = uVar2;
    }
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar3 = piVar1[1] + -1;
      piVar1[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar3 = piVar1[2] + -1;
        piVar1[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    piStack_50 = (int *)0x0;
    piStack_4c = (int *)0x0;
    iVar3 = *(int *)(iStack_14 + 0xec);
    if (iVar3 != 0) {
      piVar1 = (int *)(iVar3 + 4);
      iVar3 = *(int *)(iVar3 + 4);
      while (iVar3 != 0) {
        LOCK();
        iVar5 = *piVar1;
        if (iVar3 == iVar5) {
          *piVar1 = iVar3 + 1;
          iVar5 = iVar3;
        }
        UNLOCK();
        if (iVar5 == iVar3) {
          piStack_50 = *(int **)(iStack_14 + 0xe8);
          piStack_4c = *(int **)(iStack_14 + 0xec);
          break;
        }
        iVar3 = *piVar1;
      }
    }
    piVar1 = piStack_4c;
    uStack_8 = 2;
    if (piStack_50 != (int *)0x0) {
      uVar2 = (**(code **)(*piStack_50 + 0xa4))(&DAT_02138218);
      piStack_20 = piStack_50;
      iVar3 = FUN_00bb3290(&piStack_20);
      *(undefined4 *)(iVar3 + 4) = uVar2;
    }
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar3 = piVar1[1] + -1;
      piVar1[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar3 = piVar1[2] + -1;
        piVar1[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    iVar3 = iStack_14;
    FUN_00587490(&piStack_68);
    uStack_8 = 3;
    if (piStack_68 != (int *)0x0) {
      uVar2 = (**(code **)(*piStack_68 + 0xa4))(&DAT_02138218);
      piStack_24 = piStack_68;
      iVar3 = FUN_00bb3290(&piStack_24);
      *(undefined4 *)(iVar3 + 4) = uVar2;
      iVar3 = iStack_14;
    }
    if (piStack_64 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_64[1] + -1;
      piStack_64[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_64)();
        LOCK();
        iVar5 = piStack_64[2] + -1;
        piStack_64[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_64 + 4))();
        }
      }
    }
    iVar5 = *(int *)(iVar3 + 0xfc);
    piStack_58 = (int *)0x0;
    piStack_54 = (int *)0x0;
    if (iVar5 != 0) {
      piVar1 = (int *)(iVar5 + 4);
      iVar5 = *(int *)(iVar5 + 4);
      while (iVar5 != 0) {
        LOCK();
        iVar4 = *piVar1;
        if (iVar5 == iVar4) {
          *piVar1 = iVar5 + 1;
          iVar4 = iVar5;
        }
        UNLOCK();
        if (iVar4 == iVar5) {
          piStack_58 = *(int **)(iVar3 + 0xf8);
          piStack_54 = *(int **)(iVar3 + 0xfc);
          break;
        }
        iVar5 = *piVar1;
      }
    }
    piVar1 = piStack_54;
    uStack_8 = 4;
    if (piStack_58 != (int *)0x0) {
      uVar2 = (**(code **)(*piStack_58 + 0xa4))(&DAT_02138218);
      piStack_28 = piStack_58;
      iVar3 = FUN_00bb3290(&piStack_28);
      *(undefined4 *)(iVar3 + 4) = uVar2;
    }
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar3 = piVar1[1] + -1;
      piVar1[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar3 = piVar1[2] + -1;
        piVar1[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    FUN_00587490(&piStack_70);
    uStack_8 = 5;
    if (piStack_70 != (int *)0x0) {
      uVar2 = (**(code **)(*piStack_70 + 0xa4))(&DAT_02138218);
      piStack_2c = piStack_70;
      iVar3 = FUN_00bb3290(&piStack_2c);
      *(undefined4 *)(iVar3 + 4) = uVar2;
    }
    if (piStack_6c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_6c[1] + -1;
      piStack_6c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_6c)();
        LOCK();
        piVar1 = piStack_6c + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piStack_6c + 4))();
        }
      }
    }
  }
  else if (param_3 == (undefined4 *)&DAT_02138250) {
    FUN_00587490(&piStack_78);
    uStack_8 = 6;
    if (piStack_78 != (int *)0x0) {
      uVar2 = (**(code **)(*piStack_78 + 0xa4))(&DAT_02138250);
      piStack_30 = piStack_78;
      iVar3 = FUN_00bb3290(&piStack_30);
      *(undefined4 *)(iVar3 + 4) = uVar2;
    }
    if (piStack_74 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_74[1] + -1;
      piStack_74[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_74)();
        LOCK();
        iVar3 = piStack_74[2] + -1;
        piStack_74[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_74 + 4))();
        }
      }
    }
    FUN_00587490(&piStack_80);
    uStack_8 = 7;
    if (piStack_80 != (int *)0x0) {
      uVar2 = (**(code **)(*piStack_80 + 0xa4))(&DAT_02138250);
      piStack_34 = piStack_80;
      iVar3 = FUN_00bb3290(&piStack_34);
      *(undefined4 *)(iVar3 + 4) = uVar2;
    }
    if (piStack_7c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_7c[1] + -1;
      piStack_7c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_7c)();
        LOCK();
        piVar1 = piStack_7c + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piStack_7c + 4))();
        }
      }
    }
  }
  else {
    if (param_3 == (undefined4 *)&DAT_02138658) {
      FUN_00587490(apiStack_88);
      uStack_8 = 8;
      if (apiStack_88[0] != (int *)0x0) {
        uVar2 = (**(code **)(*apiStack_88[0] + 0xa4))(&DAT_02138658);
        piStack_38 = apiStack_88[0];
        iVar3 = FUN_00bb3290(&piStack_38);
        *(undefined4 *)(iVar3 + 4) = uVar2;
      }
    }
    else {
      if ((((param_3 != (undefined4 *)&DAT_02138abc) && (param_3 != (undefined4 *)&DAT_02138af8)) &&
          (param_3 != (undefined4 *)&DAT_02138b34)) && (param_3 != (undefined4 *)&DAT_02138a80)) {
        if ((param_3 != (undefined4 *)&DAT_02138288) && (param_3 != &DAT_02138420)) {
          ExceptionList = pvStack_10;
          return param_2;
        }
        iVar3 = *(int *)(param_1 + 0x124);
        piStack_60 = (int *)0x0;
        uStack_5c = 0;
        if (iVar3 != 0) {
          piVar1 = (int *)(iVar3 + 4);
          iVar3 = *(int *)(iVar3 + 4);
          while (iVar3 != 0) {
            LOCK();
            iVar5 = *piVar1;
            if (iVar3 == iVar5) {
              *piVar1 = iVar3 + 1;
              iVar5 = iVar3;
            }
            UNLOCK();
            if (iVar5 == iVar3) {
              piStack_60 = *(int **)(param_1 + 0x120);
              uStack_5c = *(undefined4 *)(param_1 + 0x124);
              break;
            }
            iVar3 = *piVar1;
          }
        }
        piVar1 = piStack_60;
        uStack_8 = 10;
        if (piStack_60 != (int *)0x0) {
          uVar2 = (**(code **)(*piStack_60 + 0xa4))(param_3);
          piStack_3c = piVar1;
          iVar3 = FUN_00bb3290(&piStack_3c);
          *(undefined4 *)(iVar3 + 4) = uVar2;
        }
        FUN_00550b30();
        ExceptionList = pvStack_10;
        return param_2;
      }
      FUN_00587490(apiStack_90);
      uStack_8 = 9;
      if (apiStack_90[0] != (int *)0x0) {
        uVar2 = (**(code **)(*apiStack_90[0] + 0xa4))(param_3);
        piStack_40 = apiStack_90[0];
        iVar3 = FUN_00bb3290(&piStack_40);
        *(undefined4 *)(iVar3 + 4) = uVar2;
      }
    }
    FUN_00550b30();
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 29235 ; VA 0x00c77680 ; FUN_00c77680 */

void __thiscall FUN_00c77680(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = *(undefined4 *)(param_1 + 0x300);
  uVar2 = *(undefined4 *)(param_1 + 0x304);
  uVar3 = *(undefined4 *)(param_1 + 0x308);
  *param_2 = *(undefined4 *)(param_1 + 0x2fc);
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  return;
}



/* FUNCTION 29236 ; VA 0x00c776a0 ; FUN_00c776a0 */

int FUN_00c776a0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_c;
  int *piStack_8;
  
  FUN_00587490(&iStack_c);
  iVar3 = 0;
  if (iStack_c != 0) {
    iVar3 = iStack_c;
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_8[1] + -1;
    piStack_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      iVar2 = piStack_8[2] + -1;
      piStack_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  return iVar3;
}



/* FUNCTION 29237 ; VA 0x00c77710 ; FUN_00c77710 */

void __thiscall FUN_00c77710(int param_1,undefined4 *param_2)

{
  undefined8 uVar1;
  undefined4 uVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  fVar5 = DAT_018ce2f8;
  uVar2 = *(undefined4 *)(param_1 + 0x330);
  uVar1 = *(undefined8 *)(param_1 + 0x328);
  uStack_10 = (undefined4)uVar1;
  *param_2 = uStack_10;
  uStack_c = (undefined4)((ulonglong)uVar1 >> 0x20);
  param_2[1] = uStack_c;
  param_2[2] = uVar2;
  fVar3 = fVar5 - *(float *)(param_1 + 0x344);
  fVar4 = 0.0;
  if (0.0 <= fVar3) {
    fVar4 = fVar3;
  }
  if (fVar4 <= fVar5) {
    fVar5 = fVar4;
  }
  param_2[3] = fVar5;
  return;
}



/* FUNCTION 29238 ; VA 0x00c777a0 ; FUN_00c777a0 */

void __thiscall FUN_00c777a0(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = *(undefined4 *)(param_1 + 0x2f0);
  uVar2 = *(undefined4 *)(param_1 + 0x2f4);
  uVar3 = *(undefined4 *)(param_1 + 0x2f8);
  *param_2 = *(undefined4 *)(param_1 + 0x2ec);
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  return;
}



/* FUNCTION 29239 ; VA 0x00c777d0 ; FUN_00c777d0 */

undefined4 __fastcall FUN_00c777d0(int param_1)

{
  return *(undefined4 *)(param_1 + 0x470);
}



/* FUNCTION 29240 ; VA 0x00c777e0 ; FUN_00c777e0 */

void __thiscall FUN_00c777e0(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined auStack_14 [16];
  
  puVar4 = (undefined4 *)(**(code **)(param_1 + 8))(auStack_14);
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_2 = *puVar4;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  return;
}



/* FUNCTION 29241 ; VA 0x00c77810 ; FUN_00c77810 */

void __thiscall FUN_00c77810(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  undefined auStack_14 [16];
  
  puVar4 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_14,param_2);
  uVar5 = FUN_0088d5f0();
  *param_3 = uVar5;
  iVar6 = FUN_006313f0();
  iVar1 = param_3[1];
  if (iVar1 == iVar6) {
    param_3[2] = *puVar4;
    param_3[3] = puVar4[1];
    param_3[4] = puVar4[2];
    param_3[5] = puVar4[3];
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
    param_3[1] = 0;
  }
  uVar5 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  param_3[2] = *puVar4;
  param_3[3] = uVar5;
  param_3[4] = uVar2;
  param_3[5] = uVar3;
  param_3[1] = iVar6;
  return;
}



/* FUNCTION 29242 ; VA 0x00c77890 ; FUN_00c77890 */

void __thiscall FUN_00c77890(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00c7d2c0();
  *param_3 = uVar3;
  iVar4 = FUN_00c7d650();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 29243 ; VA 0x00c778f0 ; FUN_00c778f0 */

void __thiscall FUN_00c778f0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00c7d060();
  *param_3 = uVar3;
  iVar4 = FUN_00c7d490();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 29244 ; VA 0x00c77950 ; FUN_00c77950 */

void __thiscall FUN_00c77950(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00c7d110();
  *param_3 = uVar3;
  iVar4 = FUN_00c7d500();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 29245 ; VA 0x00c779b0 ; FUN_00c779b0 */

void __thiscall FUN_00c779b0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_00c7d230();
  *param_3 = uVar3;
  iVar4 = FUN_00c7d5e0();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 29246 ; VA 0x00c77a10 ; FUN_00c77a10 */

void __thiscall FUN_00c77a10(int *param_1,int *param_2)

{
  float fVar1;
  code *pcVar2;
  int iVar3;
  char cVar4;
  undefined4 uVar5;
  int *piVar6;
  int iVar7;
  float *pfVar8;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  undefined auStack_1c [4];
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180e671;
  pvStack_10 = ExceptionList;
  fStack_20 = 0.0;
  pcVar2 = *(code **)(*param_1 + 0x10c);
  ExceptionList = &pvStack_10;
  uVar5 = FUN_00d814c0(&fStack_28);
  cVar4 = (*pcVar2)(uVar5,0);
  if ((cVar4 == '\0') || (*(int *)(*param_2 + 0x5c) != 0)) {
    if (*(char *)((int)param_1 + 0x17d) == '\0') {
      ExceptionList = pvStack_10;
      return;
    }
  }
  else if (*(char *)((int)param_1 + 0x17d) == '\0') {
    iVar7 = *(int *)(*param_2 + 0x54);
    if ((iVar7 != 0) && (iVar7 != 7)) {
      ExceptionList = pvStack_10;
      return;
    }
    *(undefined *)((int)param_1 + 0x17d) = 1;
    piVar6 = (int *)FUN_00d814c0(&fStack_28);
    iVar7 = piVar6[1];
    param_1[0x60] = *piVar6;
    param_1[0x61] = iVar7;
    FUN_00b91f60(param_1[0xbf],param_1[0xc0],param_1[0xc1],param_1[0xc2]);
    iVar7 = param_1[99];
    fStack_28 = 0.0;
    fStack_24 = 0.0;
    FUN_00550b30();
    if (iVar7 != 0) {
      ExceptionList = pvStack_10;
      return;
    }
    iVar7 = FUN_008acee0(param_1);
    if (iVar7 == 0) {
      ExceptionList = pvStack_10;
      return;
    }
    piVar6 = (int *)FUN_0060dcd0(&fStack_28,*param_2);
    iVar7 = *piVar6;
    iVar3 = piVar6[1];
    *piVar6 = 0;
    piVar6[1] = 0;
    param_1[99] = iVar7;
    piVar6 = (int *)param_1[100];
    param_1[100] = iVar3;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar7 = piVar6[1] + -1;
      piVar6[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        iVar7 = piVar6[2] + -1;
        piVar6[2] = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    FUN_00550b30();
    iStack_14 = param_1[99] + 0x4c;
    iStack_8 = 0;
    uVar5 = FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 1;
    fStack_24 = (float)uVar5;
    puStack_18 = (undefined4 *)FUN_01674e20(0x1c);
    if (puStack_18 == (undefined4 *)0x0) {
      puStack_18 = (undefined4 *)0x0;
    }
    else {
      *puStack_18 = 0;
      puStack_18[1] = 1;
      puStack_18[2] = FUN_00c75c30;
      puStack_18[3] = _guard_check_icall;
      puStack_18[4] = 0;
      puStack_18[5] = iStack_14;
      puStack_18[6] = param_1;
    }
    FUN_016797d0(puStack_18);
    param_2 = puStack_18;
    if (puStack_18 != (undefined4 *)0x0) {
      LOCK();
      puStack_18[1] = puStack_18[1] + 1;
      UNLOCK();
    }
    fStack_20 = 1.4013e-45;
    iStack_8._0_1_ = 2;
    FUN_01675290(uVar5);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    cVar4 = FUN_01679300(&param_2);
    if (cVar4 != '\0') {
      FUN_01679490();
      FUN_016791c0(&param_2);
    }
    FUN_0056e750();
    ExceptionList = pvStack_10;
    return;
  }
  pfVar8 = (float *)FUN_00d814c0(auStack_1c);
  fVar1 = (float)param_1[0x60];
  param_2 = (int *)*pfVar8;
  fStack_20 = pfVar8[1];
  if (((NAN((float)param_2) || NAN(fVar1)) == ((float)param_2 == fVar1)) ||
     ((NAN(fStack_20) || NAN((float)param_1[0x61])) == (fStack_20 == (float)param_1[0x61]))) {
    pfVar8 = (float *)FUN_00da7df0(param_1[0xbf],
                                   (int)((float)param_1[0xc0] + ((float)param_2 - fVar1)),
                                   param_1[0xc1],
                                   (int)((float)param_1[0xc2] + (fStack_20 - (float)param_1[0x61])))
    ;
    fVar1 = *pfVar8;
    fStack_28 = pfVar8[2];
    fStack_24 = pfVar8[3];
    if (((NAN((float)param_1[0xbf]) || NAN(fVar1)) == ((float)param_1[0xbf] == fVar1)) ||
       ((((float)param_1[0xc0] != pfVar8[1] ||
         ((NAN((float)param_1[0xc1]) || NAN(fStack_28)) == ((float)param_1[0xc1] == fStack_28))) ||
        ((float)param_1[0xc2] != fStack_24)))) {
      param_1[0xc0] = (int)pfVar8[1];
      param_1[0xbf] = (int)fVar1;
      param_1[0xc1] = (int)fStack_28;
      param_1[0xc2] = (int)fStack_24;
      FUN_00d5d070();
      FUN_008a4940(&DAT_02138250);
    }
    param_1[0x60] = (int)param_2;
    param_1[0x61] = (int)fStack_20;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 29247 ; VA 0x00c77d90 ; FUN_00c77d90 */

void FUN_00c77d90(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  (*(code *)*param_1)(param_3,param_4,param_5,param_6);
  return;
}



/* FUNCTION 29248 ; VA 0x00c77db0 ; FUN_00c77db0 */

int FUN_00c77db0(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iStack_c;
  int *piStack_8;
  
  FUN_00587490(&iStack_c);
  if (iStack_c != 0) {
    *(undefined4 *)(iStack_c + 0x350) = 0;
    piVar3 = *(int **)(iStack_c + 0x354);
    *(undefined4 *)(iStack_c + 0x354) = 0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iStack_c = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iStack_c = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_8 + 1;
    iVar2 = *piVar3;
    iStack_c = *piVar3;
    *piVar3 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iStack_c = (**(code **)*piStack_8)();
      LOCK();
      piVar3 = piStack_8 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iStack_c = (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  return iStack_c;
}



/* FUNCTION 29249 ; VA 0x00c77e30 ; FUN_00c77e30 */

int FUN_00c77e30(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iStack_c;
  int *piStack_8;
  
  FUN_00587490(&iStack_c);
  if (iStack_c != 0) {
    *(undefined4 *)(iStack_c + 0x358) = 0;
    piVar3 = *(int **)(iStack_c + 0x35c);
    *(undefined4 *)(iStack_c + 0x35c) = 0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iStack_c = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iStack_c = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_8 + 1;
    iVar2 = *piVar3;
    iStack_c = *piVar3;
    *piVar3 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iStack_c = (**(code **)*piStack_8)();
      LOCK();
      piVar3 = piStack_8 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iStack_c = (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  return iStack_c;
}


