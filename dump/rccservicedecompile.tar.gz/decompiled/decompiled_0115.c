/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 28750 ; VA 0x00c5d810 ; FUN_00c5d810 */

void __thiscall FUN_00c5d810(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uStack_8 = 1;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_006309e0();
    puStack_18 = &uStack_ec;
    uStack_8 = 0;
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = FUN_0088cbe0();
    iStack_1b8 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_1b4 = *puVar5;
    uStack_1b0 = puVar5[1];
    iStack_1b8 = FUN_00630900();
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cbe0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(&uStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28751 ; VA 0x00c5da80 ; FUN_00c5da80 */

void __thiscall FUN_00c5da80(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_0088cbe0();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar5 = *(undefined4 **)(param_1 + 0x40);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uStack_8 = 1;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088cdc0();
    iStack_e8 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    iStack_e8 = FUN_006309e0();
    puStack_18 = &uStack_ec;
    uStack_8 = 0;
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = FUN_0088cbe0();
    iStack_1b8 = 0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_1b4 = *puVar5;
    uStack_1b0 = puVar5[1];
    iStack_1b8 = FUN_00630900();
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cbe0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(&uStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28752 ; VA 0x00c5dcf0 ; FUN_00c5dcf0 */

void __fastcall FUN_00c5dcf0(int param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(param_1 + 0x38))(0);
  if (iVar1 != 0) {
    FUN_016795b0();
  }
  return;
}



/* FUNCTION 28753 ; VA 0x00c5dd10 ; FUN_00c5dd10 */

int FUN_00c5dd10(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  int *piStack_1b4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180c494;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 2;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_1c0 = FUN_0088cdc0();
  uStack_1bc = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_1b8 = param_2;
  piStack_1b4 = param_3;
  uStack_1bc = FUN_006309e0();
  uStack_8._0_1_ = 3;
  uStack_f0 = FUN_0088cbe0();
  uStack_ec = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_e8 = param_4;
  piStack_e4 = param_5;
  uStack_ec = FUN_00630900();
  uStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,pcVar3);
  uStack_8._0_1_ = 5;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8._0_1_ = 2;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  iVar5 = FUN_01675290(uVar4);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 28754 ; VA 0x00c5dee0 ; FUN_00c5dee0 */

void FUN_00c5dee0(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_00000020;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aa13c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = FUN_0088c8c0();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1bc = FUN_005c9cc0();
  uStack_8._0_1_ = 2;
  uStack_f0 = FUN_0088cb40();
  uStack_ec = 0;
  FUN_0054ef60(&param_3);
  uStack_ec = FUN_005c9d30();
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  uStack_8._0_1_ = 4;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_01675290(uVar3);
  if (0xf < in_stack_00000020) {
    uVar5 = in_stack_00000020 + 1;
    iVar4 = param_3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_3 + -4);
      uVar5 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28755 ; VA 0x00c5e040 ; FUN_00c5e040 */

int FUN_00c5e040(int param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  int *piStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180c4dc;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 1;
  pcVar3 = *(code **)(**(int **)(param_1 + 0x18) + 4);
  uStack_20 = uVar4;
  uStack_1c0 = FUN_0088c8c0();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1bc = FUN_005c9cc0();
  uStack_8._0_1_ = 2;
  uStack_f0 = FUN_0088cbe0();
  uStack_ec = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_e8 = param_3;
  piStack_e4 = param_4;
  uStack_ec = FUN_00630900();
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,pcVar3);
  uStack_8._0_1_ = 4;
  (*pcVar3)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  iVar5 = FUN_01675290(uVar4);
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 28756 ; VA 0x00c5e1c0 ; FUN_00c5e1c0 */

int FUN_00c5e1c0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uStack_74;
  undefined4 uStack_70;
  uint uStack_6c;
  undefined auStack_64 [24];
  undefined4 uStack_4c;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_0180c518;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_20 = param_3;
  piStack_1c = param_4;
  uStack_74 = 0;
  uStack_70 = 0;
  uStack_6c = 0;
  uStack_4c = 0;
  uStack_8 = 2;
  uStack_7 = 0;
  cVar3 = FUN_00c5d520(param_2,&uStack_74);
  if (cVar3 != '\0') {
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    uStack_18 = param_3;
    piStack_14 = param_4;
    uStack_8 = 3;
    if (uStack_6c == 0) {
      uVar5 = FUN_0054fda0();
      _uStack_8 = CONCAT31(uStack_7,4);
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0(uVar5);
    }
    uStack_18 = 0;
    piStack_14 = (int *)0x0;
    (**(code **)((uStack_6c & 0xfffffffe) + 4))(auStack_64,param_3,param_4);
  }
  iVar4 = FUN_008e9ba0();
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 28757 ; VA 0x00c5e2f0 ; FUN_00c5e2f0 */

int FUN_00c5e2f0(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00c617d0(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 28758 ; VA 0x00c5e380 ; FUN_00c5e380 */

void FUN_00c5e380(undefined4 param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000020;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_48;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180c548;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_3);
  uStack_70 = 0;
  uStack_6c = 0;
  uStack_68 = 0;
  uStack_48 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = FUN_00c5d520(param_2,&uStack_70);
  if (cVar1 != '\0') {
    FUN_0054ef60(aiStack_28);
    FUN_005e65e0();
  }
  FUN_008e9ba0();
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  if (0xf < in_stack_00000020) {
    uVar3 = in_stack_00000020 + 1;
    iVar2 = param_3;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_3 + -4);
      uVar3 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28759 ; VA 0x00c5e480 ; FUN_00c5e480 */

void __thiscall FUN_00c5e480(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  uint uVar6;
  uint in_stack_0000002c;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180c58f;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  iVar3 = (**(code **)*param_3)();
  if (iVar3 == 0) {
    piStack_20 = (int *)0x0;
    piStack_1c = (int *)0x0;
    piVar2 = piStack_1c;
  }
  else {
    uVar4 = (**(code **)*param_3)();
    piVar5 = (int *)FUN_01674e20(0x18);
    uStack_8._0_1_ = 2;
    piStack_18 = piVar5;
    if (piVar5 == (int *)0x0) {
      piVar5 = (int *)0x0;
      piStack_1c = (int *)0x0;
    }
    else {
      piVar5[1] = 1;
      piVar5[2] = 1;
      *piVar5 = (int)std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
      piStack_1c = piVar5;
      FUN_00569550(uVar4,&uStack_11);
    }
    piVar1 = piVar5 + 3;
    uStack_8._0_1_ = 3;
    iVar3 = piVar5[4] - *piVar1 >> 0x1f;
    piStack_20 = piVar1;
    piVar2 = piVar5;
    if ((piVar5[4] - *piVar1) / 0xd0 + iVar3 != iVar3) {
      uVar6 = 0;
      piStack_18 = (int *)0x0;
      do {
        uVar6 = uVar6 + 1;
        (**(code **)(*param_3 + 4))(uVar6,*piVar1 + (int)piStack_18);
        piStack_18 = piStack_18 + 0x34;
        piVar2 = piStack_1c;
      } while (uVar6 < (uint)((piVar5[4] - *piVar1) / 0xd0));
    }
  }
  piStack_1c = piVar2;
  piVar5 = piStack_1c;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00c5c2b0(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&piStack_20,
               &param_4,&stack0x0000002c);
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar3 = piVar5[1] + -1;
    piVar5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28760 ; VA 0x00c5e640 ; FUN_00c5e640 */

void FUN_00c5e640(undefined4 param_1,int *param_2,uint param_3)

{
  int *piVar1;
  char cVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int *piVar7;
  int *piVar8;
  uint in_stack_0000002c;
  undefined4 uStack_108;
  int iStack_104;
  undefined auStack_100 [200];
  undefined auStack_38 [4];
  int *piStack_34;
  int *piStack_30;
  int iStack_2c;
  int *piStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar8 = param_2;
  puStack_c = &LAB_0180c5ea;
  pvStack_10 = ExceptionList;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  ExceptionList = &pvStack_10;
  uVar3 = (**(code **)*param_2)();
  if (uVar3 < 2) {
    piStack_28 = (int *)0x0;
    piVar7 = (int *)0x0;
    piVar1 = piStack_14;
  }
  else {
    iVar5 = (**(code **)*piVar8)();
    piStack_14 = (int *)(iVar5 + -1);
    piVar4 = (int *)FUN_01674e20(0x18);
    uStack_8._0_1_ = 2;
    if (piVar4 == (int *)0x0) {
      piVar4 = (int *)0x0;
      piStack_24 = (int *)0x0;
    }
    else {
      piVar4[1] = 1;
      piVar4[2] = 1;
      *piVar4 = (int)std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
      piStack_24 = piVar4;
      piStack_1c = piVar4;
      FUN_00569550(piStack_14,(int)&param_2 + 3);
    }
    piVar1 = piVar4 + 3;
    uStack_8._0_1_ = 3;
    iVar5 = piVar4[4] - *piVar1 >> 0x1f;
    piStack_1c = (int *)0x0;
    piVar7 = piVar4;
    piStack_34 = piVar1;
    piStack_30 = piVar4;
    piStack_28 = piVar1;
    if ((piVar4[4] - *piVar1) / 0xd0 + iVar5 != iVar5) {
      param_2 = (int *)0x0;
      piStack_14 = piVar1;
      do {
        (**(code **)(*piVar8 + 4))((int)piStack_1c + 2,*piVar1 + (int)param_2);
        piStack_1c = (int *)((int)piStack_1c + 1);
        param_2 = param_2 + 0x34;
        piVar7 = piStack_24;
      } while (piStack_1c < (uint)((piVar4[4] - *piVar1) / 0xd0));
    }
  }
  piStack_14 = piVar1;
  uStack_8._0_1_ = 4;
  piStack_24 = piVar7;
  iVar5 = (**(code **)*piVar8)();
  if (iVar5 != 0) {
    uStack_20 = 0;
    piStack_1c = (int *)0x0;
    uStack_8._0_1_ = 5;
    uStack_108 = FUN_00888530();
    iStack_104 = 0;
    uStack_8._0_1_ = 6;
    cVar2 = (**(code **)(*piVar8 + 4))(1,&uStack_108);
    if (cVar2 != '\0') {
      puVar6 = (undefined4 *)FUN_0088a3d0();
      piVar8 = (int *)puVar6[1];
      if (piVar8 != (int *)0x0) {
        LOCK();
        piVar8[1] = piVar8[1] + 1;
        UNLOCK();
        piVar8 = (int *)puVar6[1];
      }
      uStack_18 = *puVar6;
      uStack_8._0_1_ = 7;
      piStack_14 = piVar8;
      if (iStack_104 != 0) {
        (**(code **)(iStack_104 + 8))(auStack_100);
      }
      FUN_00550b30();
      goto LAB_00c5e847;
    }
    uStack_8._0_1_ = 8;
    if (iStack_104 != 0) {
      (**(code **)(iStack_104 + 8))(auStack_100);
    }
    uStack_8._0_1_ = 4;
    FUN_00550b30();
  }
  puVar6 = *(undefined4 **)(iStack_2c + 0x40);
  if (puVar6 == (undefined4 *)0x0) {
    FUN_016756b0(auStack_38,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_38,&DAT_01c17198);
  }
  piVar8 = (int *)puVar6[1];
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar8[1] = piVar8[1] + 1;
    UNLOCK();
    piVar8 = (int *)puVar6[1];
  }
  uStack_18 = *puVar6;
  piStack_14 = piVar8;
LAB_00c5e847:
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  FUN_00c5c3f0(param_1,*(undefined4 *)(iStack_2c + 0x38),*(undefined4 *)(iStack_2c + 0x3c),
               &uStack_18,&piStack_28,&param_3,&stack0x0000002c);
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar5 = piVar8[1] + -1;
    piVar8[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      iVar5 = piVar8[2] + -1;
      piVar8[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  if (piVar7 != (int *)0x0) {
    LOCK();
    iVar5 = piVar7[1] + -1;
    piVar7[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar7)();
      LOCK();
      piVar8 = piVar7 + 2;
      iVar5 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar7 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_3 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_3 = 0;
  }
  uStack_8 = 0xb;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28761 ; VA 0x00c5e950 ; FUN_00c5e950 */

undefined4 __thiscall FUN_00c5e950(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined auStack_34 [4];
  int *piStack_30;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_0180c608;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300(param_3);
  puVar3 = (undefined4 *)FUN_009d0b50(auStack_34,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  pcStack_28 = *(code **)(param_1 + 0x38);
  uStack_14 = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcStack_28)(*puVar3,puVar3[1]);
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_30[1] + -1;
    piStack_30[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar1 = piStack_30 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 28762 ; VA 0x00c5ea30 ; FUN_00c5ea30 */

undefined4 FUN_00c5ea30(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180c630;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_01256300(param_2);
  puVar6 = (undefined4 *)FUN_009d0b50(auStack_24,param_2,param_3,2,iVar5 - param_3,iStack_14 + 0x44)
  ;
  uStack_8 = 0;
  puVar7 = (undefined4 *)FUN_009d1340(auStack_1c,param_2,param_3,1,iVar5 - param_3,iStack_14 + 0x40)
  ;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  pcVar2 = *(code **)(iStack_14 + 0x38);
  if (puVar6[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar6[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar3 = *puVar6;
  uVar4 = puVar6[1];
  if (puVar7[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar7[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(*puVar7,puVar7[1],uVar3,uVar4);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_18[1] + -1;
    piStack_18[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar5 = piStack_18[2] + -1;
      piStack_18[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_20[1] + -1;
    piStack_20[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 28763 ; VA 0x00c5eb70 ; FUN_00c5eb70 */

int __thiscall FUN_00c5eb70(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  undefined auStack_24 [4];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d3288;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar3 = FUN_00973950(param_1,0);
  if (cVar3 == '\0') {
    cVar3 = FUN_0098c5a0(param_1,0);
    if (cVar3 == '\0') {
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      iVar4 = FUN_00c58490(param_2,param_3);
    }
    else {
      uStack_20 = 0;
      uStack_1c = 0;
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      FUN_00c62b30(param_1,param_2,param_3,&uStack_20);
      iVar4 = FUN_00c59480(&DAT_01efdb2c,&uStack_11);
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      piVar1 = param_3 + 1;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)*param_3)();
        LOCK();
        piVar1 = param_3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar4 = (**(code **)(*param_3 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return iVar4;
  }
  FUN_00550130("FireAllClients can only be called from the server");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_24,&DAT_01c17198);
}



/* FUNCTION 28764 ; VA 0x00c5eca0 ; FUN_00c5eca0 */

int __thiscall
FUN_00c5eca0(undefined4 param_1,int param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  char *pcVar5;
  undefined auStack_28 [4];
  undefined *puStack_24;
  undefined4 uStack_20;
  undefined auStack_18 [7];
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180b8d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00973950(param_1,0);
  if (cVar2 == '\0') {
    cVar2 = FUN_0098c5a0(param_1,0);
    if (cVar2 == '\0') {
      if (param_5 != (int *)0x0) {
        LOCK();
        param_5[1] = param_5[1] + 1;
        UNLOCK();
      }
      iVar4 = FUN_00c58490(param_4,param_5);
LAB_00c5edba:
      if (param_3 != (int *)0x0) {
        LOCK();
        piVar1 = param_3 + 1;
        iVar3 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          (**(code **)*param_3)();
          LOCK();
          piVar1 = param_3 + 2;
          iVar3 = *piVar1;
          iVar4 = *piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            iVar4 = (**(code **)(*param_3 + 4))();
          }
        }
      }
      if (param_5 != (int *)0x0) {
        LOCK();
        piVar1 = param_5 + 1;
        iVar3 = *piVar1;
        iVar4 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          iVar4 = (**(code **)*param_5)();
          LOCK();
          piVar1 = param_5 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            iVar4 = (**(code **)(*param_5 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return iVar4;
    }
    if (param_2 != 0) {
      iVar4 = *(int *)(param_2 + 0xc);
      iVar3 = FUN_00913630();
      if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) {
        FUN_00927d30(auStack_18);
        puStack_24 = auStack_18;
        uStack_20 = 0;
        if (param_5 != (int *)0x0) {
          LOCK();
          param_5[1] = param_5[1] + 1;
          UNLOCK();
        }
        FUN_00c62b30(param_1,param_4,param_5,&puStack_24);
        iVar4 = FUN_00c59610(&DAT_01efdb24,&uStack_11);
        goto LAB_00c5edba;
      }
    }
    pcVar5 = "FireClient: player argument must be a Player object";
  }
  else {
    pcVar5 = "FireClient can only be called from the server";
  }
  FUN_00550130(pcVar5);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_28,&DAT_01c17198);
}



/* FUNCTION 28765 ; VA 0x00c5ee40 ; FUN_00c5ee40 */

void __thiscall FUN_00c5ee40(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1ae8;
  pvStack_10 = ExceptionList;
  param_3 = (int *)*param_3;
  iVar3 = *param_3;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0088cbe0();
  if (iVar3 == iVar1) {
    piVar2 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar2 = (int *)0x0;
    }
    iVar3 = piVar2[1];
    if (iVar3 != 0) {
      LOCK();
      *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
      UNLOCK();
      iVar3 = piVar2[1];
    }
    iVar1 = *piVar2;
    uStack_8 = 0;
    (**(code **)(param_1 + 0x38))(1);
    FUN_00c58490(iVar1,iVar3);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28766 ; VA 0x00c5eef0 ; FUN_00c5eef0 */

void FUN_00c5eef0(undefined4 param_1,undefined4 param_2)

{
  FUN_00c5a9b0(param_1,param_2,param_2);
  return;
}



/* FUNCTION 28767 ; VA 0x00c5ef10 ; FUN_00c5ef10 */

/* WARNING: Removing unreachable block (ram,0x00c5efdc) */
/* WARNING: Removing unreachable block (ram,0x00c5efea) */
/* WARNING: Removing unreachable block (ram,0x00c5f02a) */
/* WARNING: Removing unreachable block (ram,0x00c5effa) */

void FUN_00c5ef10(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_2;
  iVar2 = *piVar1;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088c8c0();
  if (iVar2 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  piVar4 = piVar1 + 2;
  if (piVar1[1] == 0) {
    piVar4 = (int *)0x0;
  }
  iVar2 = *piVar4;
  iVar3 = *(int *)(*param_2 + 0xd0);
  iVar5 = FUN_0088cb40();
  if (iVar3 != iVar5) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  FUN_0054ef60();
  uStack_8 = 0;
  FUN_006ecd90(iVar2,uStack_30,uStack_2c,uStack_28,uStack_24,CONCAT44(uStack_1c,uStack_20));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28768 ; VA 0x00c5f030 ; FUN_00c5f030 */

void FUN_00c5f030(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1ae8;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_2;
  iVar7 = *piVar1;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088c8c0();
  if (iVar7 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  piVar4 = piVar1 + 2;
  iVar7 = *param_2;
  if (piVar1[1] == 0) {
    piVar4 = (int *)0x0;
  }
  iVar3 = *(int *)(iVar7 + 0xd0);
  iVar2 = *piVar4;
  iVar5 = FUN_0088cbe0();
  if (iVar3 == iVar5) {
    puVar6 = (undefined4 *)(iVar7 + 0xd8);
    if (*(int *)(iVar7 + 0xd4) == 0) {
      puVar6 = (undefined4 *)0x0;
    }
    iVar7 = puVar6[1];
    if (iVar7 != 0) {
      LOCK();
      *(int *)(iVar7 + 4) = *(int *)(iVar7 + 4) + 1;
      UNLOCK();
      iVar7 = puVar6[1];
    }
    uStack_8 = 0;
    FUN_00c5bf00(iVar2,*puVar6,iVar7);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28769 ; VA 0x00c5f100 ; FUN_00c5f100 */

int FUN_00c5f100(undefined4 *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  code *pcVar4;
  char cVar5;
  int iVar6;
  undefined4 *puStack_1f4;
  undefined4 *puStack_1f0;
  undefined4 *puStack_1ec;
  code *pcStack_1e8;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  int *piStack_1d0;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 *puStack_104;
  int *piStack_100;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 *puStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_0180c694;
  pvStack_10 = ExceptionList;
  pcStack_1e8 = (code *)0x0;
  iStack_8 = 0;
  puStack_1f0 = (undefined4 *)0xc5f134;
  ExceptionList = &pvStack_10;
  cVar5 = FUN_0098c5a0();
  if (cVar5 == '\0') {
    pcStack_1e8 = (code *)0x0;
    puStack_1f0 = (undefined4 *)0xc5f147;
    cVar5 = FUN_00973950();
    if (cVar5 == '\0') {
      puStack_1ec = (undefined4 *)0xc5f2c6;
      piStack_14 = (int *)FUN_0097bfc0();
      piStack_18 = (int *)&puStack_1ec;
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[1] = param_2[1] + 1;
        UNLOCK();
      }
      puStack_1ec = param_1;
      pcStack_1e8 = (code *)param_2;
      iStack_8._0_1_ = 8;
      FUN_0060dcd0(&puStack_1f4,piStack_14);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      iVar6 = FUN_00c58520();
    }
    else {
      puStack_1ec = (undefined4 *)0xc5f15b;
      pcStack_1e8 = (code *)FUN_0097bfc0();
      uStack_3c = 0;
      uStack_38 = 0;
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[1] = param_2[1] + 1;
        UNLOCK();
      }
      piStack_18 = param_2;
      puStack_34 = param_1;
      piStack_30 = param_2;
      puStack_1ec = &uStack_20;
      iStack_8._0_1_ = 1;
      puStack_1f0 = (undefined4 *)0xc5f199;
      FUN_0060dcd0();
      iStack_8._0_1_ = 3;
      pcVar4 = *(code **)(*piStack_14 + 8);
      pcStack_1e8 = (code *)0xc5f1ad;
      uStack_1dc = FUN_0088cdc0();
      uStack_1d4 = uStack_20;
      uStack_1d8 = 0;
      piStack_1d0 = piStack_1c;
      uStack_20 = 0;
      piStack_1c = (int *)0x0;
      pcStack_1e8 = (code *)0xc5f1e2;
      uStack_1d8 = FUN_006309e0();
      iStack_8._0_1_ = 4;
      pcStack_1e8 = (code *)0xc5f1f1;
      uStack_10c = FUN_0088cbe0();
      uStack_108 = 0;
      puStack_104 = param_1;
      piStack_100 = piStack_18;
      puStack_34 = (undefined4 *)0x0;
      piStack_30 = (int *)0x0;
      pcStack_1e8 = (code *)0xc5f223;
      uStack_108 = FUN_00630900();
      pcStack_1e8 = (code *)param_2;
      puStack_1ec = &uStack_3c;
      iStack_8._0_1_ = 5;
      puStack_1f0 = &uStack_1dc;
      uStack_2c = 0;
      uStack_28 = 0;
      uStack_24 = 0;
      puStack_1f4 = (undefined4 *)0xc5f258;
      FUN_00687980();
      pcStack_1e8 = (code *)&uStack_3c;
      puStack_1ec = &uStack_2c;
      iStack_8._0_1_ = 6;
      puStack_1f0 = (undefined4 *)&DAT_02137608;
      puStack_1f4 = (undefined4 *)0xc5f26e;
      (*pcVar4)();
      iStack_8._0_1_ = 7;
      pcStack_1e8 = (code *)0xc5f27a;
      FUN_00577b20();
      pcStack_1e8 = FUN_0056e5b0;
      puStack_1ec = (undefined4 *)0x2;
      puStack_1f0 = (undefined4 *)0xd0;
      puStack_1f4 = &uStack_1dc;
      iStack_8 = CONCAT31(iStack_8._1_3_,3);
      iVar6 = FUN_016f32d1();
      piVar2 = piStack_1c;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        piVar1 = piStack_1c + 1;
        iVar3 = *piVar1;
        iVar6 = *piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          pcStack_1e8 = (code *)0xc5f2af;
          (**(code **)*piStack_1c)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1;
          iVar6 = *piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            pcStack_1e8 = (code *)0xc5f2bf;
            iVar6 = (**(code **)(*piVar2 + 4))();
          }
        }
      }
    }
    if (param_2 != (int *)0x0) {
      LOCK();
      piVar2 = param_2 + 1;
      iVar3 = *piVar2;
      iVar6 = *piVar2;
      *piVar2 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        pcStack_1e8 = (code *)0xc5f329;
        iVar6 = (**(code **)*param_2)();
        LOCK();
        piVar2 = param_2 + 2;
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          pcStack_1e8 = (code *)0xc5f338;
          iVar6 = (**(code **)(*param_2 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return iVar6;
  }
  pcStack_1e8 = (code *)0x196c61c;
  puStack_1ec = (undefined4 *)0xc5f357;
  FUN_00550130();
  pcStack_1e8 = (code *)&DAT_01c17198;
  puStack_1ec = &uStack_2c;
                    /* WARNING: Subroutine does not return */
  puStack_1f0 = (undefined4 *)&UNK_00c5f365;
  FUN_0170c2a8();
}



/* FUNCTION 28770 ; VA 0x00c5f370 ; FUN_00c5f370 */

void FUN_00c5f370(void)

{
  int iVar1;
  
  if (DAT_01efdf74 == 0) {
    iVar1 = FUN_00c58600();
    DAT_01efdf74 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28771 ; VA 0x00c5f390 ; FUN_00c5f390 */

void FUN_00c5f390(void)

{
  int iVar1;
  
  if (DAT_01efdd54 == 0) {
    iVar1 = FUN_00c58700();
    DAT_01efdd54 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28772 ; VA 0x00c5f3b0 ; FUN_00c5f3b0 */

undefined4 __thiscall FUN_00c5f3b0(int param_1,int param_2)

{
  undefined4 uVar1;
  
  if (param_2 != 0) {
    uVar1 = (**(code **)(param_1 + 0x38))(1);
    return uVar1;
  }
  return 0;
}



/* FUNCTION 28773 ; VA 0x00c5f3e0 ; FUN_00c5f3e0 */

int __thiscall FUN_00c5f3e0(int param_1,char param_2)

{
  char cVar1;
  undefined auStack_10 [12];
  
  if (param_2 != '\0') {
    cVar1 = FUN_0098c5a0(param_1,0);
    if (cVar1 != '\0') {
      FUN_00550130("OnClientEvent can only be used on the client");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_10,&DAT_01c17198);
    }
  }
  return param_1 + 0x84;
}



/* FUNCTION 28774 ; VA 0x00c5f430 ; FUN_00c5f430 */

int __thiscall FUN_00c5f430(int param_1,char param_2)

{
  char cVar1;
  undefined auStack_10 [12];
  
  if (param_2 != '\0') {
    cVar1 = FUN_00973950(param_1,0);
    if (cVar1 != '\0') {
      FUN_00550130("OnServerEvent can only be used on the server");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_10,&DAT_01c17198);
    }
  }
  return param_1 + 0x54;
}



/* FUNCTION 28775 ; VA 0x00c5f480 ; FUN_00c5f480 */

int * FUN_00c5f480(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  int iStack_1c;
  int *piStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180c6b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00562c90(&iStack_1c,&param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_1c != 0) {
    FUN_00927d30(auStack_14);
    cVar4 = FUN_00a33d60(param_4);
    if (cVar4 != '\0') {
      *param_1 = iStack_1c;
      param_1[1] = (int)piStack_18;
      piVar3 = param_3;
      goto joined_r0x00c5f52e;
    }
  }
  *param_1 = 0;
  param_1[1] = 0;
  piVar3 = param_3;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      piVar3 = param_3;
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
        piVar3 = param_3;
      }
    }
  }
joined_r0x00c5f52e:
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      param_3 = piVar3;
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28776 ; VA 0x00c5f570 ; FUN_00c5f570 */

int FUN_00c5f570(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  
  iVar2 = param_1;
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar4 = FUN_00913630();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da)) {
      FUN_00927d30(&param_1);
      cVar3 = FUN_00a33d60(param_2);
      if (cVar3 != '\0') {
        return iVar2;
      }
    }
  }
  return 0;
}



/* FUNCTION 28777 ; VA 0x00c5f5d0 ; FUN_00c5f5d0 */

int FUN_00c5f5d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_4 != 0) {
    iVar3 = *(int *)(param_4 + 0x34);
    iVar2 = param_4;
    if ((iVar3 != 0) && (iVar2 = iVar3, *(int *)(iVar3 + 0x34) != 0)) {
      iVar2 = FUN_005c8ac0();
    }
    if (((iVar2 != 0) &&
        (iVar3 = *(int *)(iVar2 + 0xc), iVar2 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da))) && (iVar3 = FUN_005cf750(), iVar3 != 0)) {
      piVar4 = (int *)FUN_00980280(auStack_c,param_1,param_2);
      iVar3 = *piVar4;
      if (piStack_8 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_8[1] + -1;
        piStack_8[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_8)();
          LOCK();
          piVar4 = piStack_8 + 2;
          iVar2 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piStack_8 + 4))();
          }
        }
      }
      if ((iVar3 != 0) &&
         (iVar2 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00913630(),
         (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        FUN_00927d30(&param_4);
        cVar1 = FUN_00a33d60(param_3);
        if (cVar1 != '\0') {
          return iVar3;
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 28778 ; VA 0x00c5f6d0 ; FUN_00c5f6d0 */

bool __fastcall FUN_00c5f6d0(int param_1)

{
  return *(int *)(param_1 + 4) != 0;
}



/* FUNCTION 28779 ; VA 0x00c5f6e0 ; FUN_00c5f6e0 */

bool __fastcall FUN_00c5f6e0(int param_1)

{
  return *(int *)(param_1 + 0x24) != 0;
}



/* FUNCTION 28780 ; VA 0x00c5f6f0 ; FUN_00c5f6f0 */

void FUN_00c5f6f0(undefined4 param_1,undefined4 param_2)

{
  FUN_009d5730(param_2,param_1);
  return;
}



/* FUNCTION 28781 ; VA 0x00c5f710 ; FUN_00c5f710 */

int FUN_00c5f710(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_009d5980(param_2,param_1);
  iVar2 = FUN_009d5730(param_2,param_1 + 8);
  return iVar2 + iVar1;
}



/* FUNCTION 28782 ; VA 0x00c5f740 ; FUN_00c5f740 */

void FUN_00c5f740(int *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  int iStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c47f8;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  uStack_3c = 0;
  uVar3 = *(uint *)(iVar2 + 0x30);
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    uStack_3c = uVar3;
    if ((uVar3 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      iStack_48 = iVar2 + 0x38;
      uStack_4c = 0xc5f7a6;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_34 = *(undefined4 *)(iVar2 + 0x38);
      uStack_30 = *(undefined4 *)(iVar2 + 0x3c);
      uStack_2c = *(undefined4 *)(iVar2 + 0x40);
      uStack_28 = *(undefined4 *)(iVar2 + 0x44);
      uStack_24 = *(undefined8 *)(iVar2 + 0x48);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar3 = *(uint *)(iVar2 + 0x10);
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(iVar2 + 0x18,&uStack_54,0);
    }
    else {
      uStack_54 = *(undefined4 *)(iVar2 + 0x18);
      uStack_50 = *(undefined4 *)(iVar2 + 0x1c);
      uStack_4c = *(undefined4 *)(iVar2 + 0x20);
      iStack_48 = *(int *)(iVar2 + 0x24);
      uStack_44 = *(ulonglong *)(iVar2 + 0x28);
    }
  }
  if (*(int *)(iVar2 + 8) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar2 + 8) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = 0xffffffff;
  FUN_00c60400(*(undefined4 *)(iVar2 + 4),*(undefined4 *)(iVar2 + 8));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28783 ; VA 0x00c5f840 ; FUN_00c5f840 */

void FUN_00c5f840(void)

{
  FUN_00c5bae0();
  return;
}



/* FUNCTION 28784 ; VA 0x00c5f850 ; FUN_00c5f850 */

int FUN_00c5f850(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  code *pcVar4;
  int iVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017e1ae8;
  pvStack_10 = ExceptionList;
  piVar6 = (int *)param_1[4];
  ExceptionList = &pvStack_10;
  if (piVar6 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar6[1] = piVar6[1] + 1;
    UNLOCK();
    piVar6 = (int *)param_1[4];
  }
  uVar3 = param_1[3];
  piVar1 = piVar6 + 1;
  uStack_8 = 0;
  pcVar4 = (code *)*param_1;
  if (piVar6 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar5 = (*pcVar4)(uVar3,piVar6);
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piVar6)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 28785 ; VA 0x00c5f900 ; FUN_00c5f900 */

void FUN_00c5f900(undefined4 *param_1)

{
  FUN_00c58380(param_1,*param_1,(int)&param_1 + 3,0);
  return;
}



/* FUNCTION 28786 ; VA 0x00c5f920 ; FUN_00c5f920 */

void FUN_00c5f920(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar1 = *(undefined4 *)(param_1 + 8);
  uVar2 = *(undefined4 *)(param_1 + 4);
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  FUN_00c628d0(uVar2,uVar1);
  if (0xf < in_stack_0000001c) {
    uVar4 = in_stack_0000001c + 1;
    iVar3 = param_2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(param_2 + -4);
      uVar4 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28787 ; VA 0x00c5f9b0 ; FUN_00c5f9b0 */

int FUN_00c5f9b0(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c47b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar3 = *(undefined4 *)(param_1 + 8);
  uVar4 = *(undefined4 *)(param_1 + 4);
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar5 = FUN_00c62a80(uVar4,uVar3,param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 28788 ; VA 0x00c5fa50 ; FUN_00c5fa50 */

void FUN_00c5fa50(undefined4 param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  uint in_stack_00000030;
  undefined *puStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180c6d8;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)&param_2;
  uStack_8 = 2;
  puStack_18 = &param_4;
  puStack_14 = &stack0x00000030;
  ExceptionList = &pvStack_10;
  FUN_00b11a90(param_1,param_1,&puStack_1c,0);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000018,&stack0x00000018,2);
    }
    param_4 = 0;
  }
  uStack_8 = 4;
  if (((in_stack_00000030 != 0) && ((in_stack_00000030 & 1) == 0)) &&
     (*(code **)(in_stack_00000030 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000030 & 0xfffffffe))(&stack0x00000038,&stack0x00000038,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28789 ; VA 0x00c5fb30 ; FUN_00c5fb30 */

void FUN_00c5fb30(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5
                 ,uint param_6)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  uint in_stack_00000038;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180c710;
  pvStack_10 = ExceptionList;
  puStack_20 = (undefined *)&param_2;
  uStack_8 = 3;
  puStack_1c = (undefined *)&param_4;
  puStack_18 = &param_6;
  puStack_14 = &stack0x00000038;
  ExceptionList = &pvStack_10;
  FUN_00c58220(param_1,param_1,&puStack_20,0);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1 + -1;
      *piVar1 = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (param_6 != 0) {
    if (((param_6 & 1) == 0) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_6 & 0xfffffffe))(&stack0x00000020,&stack0x00000020,2);
    }
    param_6 = 0;
  }
  uStack_8 = 5;
  if (((in_stack_00000038 != 0) && ((in_stack_00000038 & 1) == 0)) &&
     (*(code **)(in_stack_00000038 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000038 & 0xfffffffe))(&stack0x00000040,&stack0x00000040,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28790 ; VA 0x00c5fc40 ; FUN_00c5fc40 */

void FUN_00c5fc40(int param_1,int *param_2,undefined4 param_3,int *param_4,uint param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  uint in_stack_00000034;
  undefined auStack_54 [8];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 *puStack_44;
  undefined4 **ppuStack_40;
  char *pcStack_3c;
  undefined4 **ppuStack_38;
  undefined auStack_28 [4];
  undefined **ppuStack_24;
  int *piStack_20;
  undefined *puStack_1c;
  undefined4 uStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180c750;
  pvStack_10 = ExceptionList;
  ppuStack_38 = (undefined4 **)0x0;
  uStack_8 = 3;
  ppuStack_40 = (undefined4 **)0xc5fc72;
  ExceptionList = &pvStack_10;
  cVar4 = FUN_00973950();
  if (cVar4 == '\0') {
    ppuStack_38 = (undefined4 **)0x0;
    ppuStack_40 = (undefined4 **)0xc5fc85;
    cVar4 = FUN_0098c5a0();
    iVar2 = param_1;
    if (cVar4 == '\0') {
      puStack_1c = auStack_54;
      FUN_0054f510(&stack0x00000034);
      uStack_8._0_1_ = 5;
      FUN_0054f510(&param_5);
      if (param_4 != (int *)0x0) {
        LOCK();
        param_4[1] = param_4[1] + 1;
        UNLOCK();
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      FUN_00c60400(param_3,param_4);
LAB_00c5fde1:
      piVar3 = param_2;
      if (param_2 != (int *)0x0) {
        LOCK();
        iVar2 = param_2[1] + -1;
        param_2[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          ppuStack_38 = (undefined4 **)0xc5fdf7;
          (**(code **)*param_2)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1 + -1;
          *piVar1 = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            ppuStack_38 = (undefined4 **)0xc5fe07;
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      piVar3 = param_4;
      if (param_4 != (int *)0x0) {
        LOCK();
        iVar2 = param_4[1] + -1;
        param_4[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          ppuStack_38 = (undefined4 **)0xc5fe1d;
          (**(code **)*param_4)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            ppuStack_38 = (undefined4 **)0xc5fe2c;
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      if (param_5 != 0) {
        if (((param_5 & 1) == 0) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0)) {
          ppuStack_40 = (undefined4 **)&stack0x0000001c;
          ppuStack_38 = (undefined4 **)0x2;
          puStack_44 = (undefined4 *)0xc5fe4d;
          pcStack_3c = (char *)ppuStack_40;
          (**(code **)(param_5 & 0xfffffffe))();
        }
        param_5 = 0;
      }
      uStack_8 = 7;
      if (((in_stack_00000034 != 0) && ((in_stack_00000034 & 1) == 0)) &&
         (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
        ppuStack_40 = (undefined4 **)&stack0x0000003c;
        ppuStack_38 = (undefined4 **)0x2;
        puStack_44 = (undefined4 *)0xc5fe7b;
        pcStack_3c = (char *)ppuStack_40;
        (**(code **)(in_stack_00000034 & 0xfffffffe))();
      }
      ExceptionList = pvStack_10;
      return;
    }
    if (param_1 != 0) {
      iVar6 = *(int *)(param_1 + 0xc);
      ppuStack_38 = (undefined4 **)0xc5fca6;
      iVar5 = FUN_00913630();
      if ((uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
          (uint)*(ushort *)(iVar5 + 0x1da)) {
        if (*(int *)(iVar2 + 0x34) != 0) {
          iVar2 = *(int *)(*(int *)(iVar2 + 0x34) + 0xc);
          ppuStack_38 = (undefined4 **)0xc5fcd8;
          iVar6 = FUN_00961580();
          if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
              (uint)*(ushort *)(iVar6 + 0x1da)) {
            ppuStack_38 = (undefined4 **)&puStack_1c;
            pcStack_3c = (char *)0xc5fd02;
            FUN_00927d30();
            ppuStack_38 = (undefined4 **)&param_1;
            pcStack_3c = (char *)0xc5fd0e;
            FUN_005587b0();
            ppuStack_38 = (undefined4 **)&stack0x00000034;
            pcStack_3c = (char *)&param_5;
            uStack_8._0_1_ = 4;
            ppuStack_40 = &ppuStack_24;
            puStack_44 = (undefined4 *)0xc5fd28;
            uVar7 = FUN_00c5d680();
            uStack_8 = CONCAT31(uStack_8._1_3_,3);
            if (piStack_20 != (int *)0x0) {
              LOCK();
              iVar2 = piStack_20[2] + -1;
              piStack_20[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                ppuStack_38 = (undefined4 **)0xc5fd43;
                (**(code **)(*piStack_20 + 4))();
              }
            }
            ppuStack_24 = &puStack_1c;
            piStack_20 = (int *)0x0;
            ppuStack_38 = &ppuStack_24;
            puStack_44 = &param_3;
            uStack_48 = 0xc5fd62;
            FUN_00557fc0();
            uStack_48 = uStack_18;
            uStack_4c = 0xc5fd6e;
            puStack_44 = (undefined4 *)uVar7;
            FUN_00c62c50();
            ppuStack_38 = (undefined4 **)&uStack_11;
            pcStack_3c = &DAT_01efdb14;
            ppuStack_40 = (undefined4 **)0xc5fd7c;
            FUN_00c597a0();
            goto LAB_00c5fde1;
          }
        }
        ppuStack_38 = (undefined4 **)0xc5feb3;
        FUN_005c8aa0();
        ppuStack_38 = (undefined4 **)0xc5feba;
        ppuStack_38 = (undefined4 **)FUN_005543f0();
        ppuStack_40 = (undefined4 **)auStack_28;
        pcStack_3c = "InvokeClient: player %s must be a child of game.Players";
        puStack_44 = (undefined4 *)0xc5fec9;
        FUN_016756b0();
        pcStack_3c = auStack_28;
        ppuStack_38 = (undefined4 **)&DAT_01c17198;
                    /* WARNING: Subroutine does not return */
        ppuStack_40 = (undefined4 **)&UNK_00c5feda;
        FUN_0170c2a8();
      }
    }
    ppuStack_38 = (undefined4 **)0x196c418;
  }
  else {
    ppuStack_38 = (undefined4 **)0x196c3e8;
  }
  pcStack_3c = (char *)0xc5fe9e;
  FUN_00550130();
  ppuStack_38 = (undefined4 **)&DAT_01c17198;
  pcStack_3c = auStack_28;
                    /* WARNING: Subroutine does not return */
  ppuStack_40 = (undefined4 **)0xc5feac;
  FUN_0170c2a8();
}



/* FUNCTION 28791 ; VA 0x00c5fee0 ; FUN_00c5fee0 */

void FUN_00c5fee0(undefined4 param_1,int *param_2,uint param_3)

{
  int *piVar1;
  int *piVar2;
  code *pcVar3;
  int iVar4;
  char cVar5;
  undefined4 uVar6;
  uint in_stack_0000002c;
  undefined auStack_308 [8];
  undefined4 uStack_300;
  int *piStack_2fc;
  int aiStack_2f8 [6];
  undefined4 uStack_2e0;
  undefined4 *puStack_2dc;
  int aiStack_2d8 [3];
  undefined4 uStack_2cc;
  undefined4 *puStack_2c8;
  undefined4 *puStack_2c4;
  undefined4 *puStack_2c0;
  code *pcStack_2bc;
  undefined4 uStack_2b0;
  undefined4 uStack_2ac;
  undefined4 uStack_2a8;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  int *piStack_104;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180c7e7;
  pvStack_10 = ExceptionList;
  pcStack_2bc = (code *)0x0;
  uStack_8 = 2;
  puStack_2c4 = (undefined4 *)0xc5ff14;
  ExceptionList = &pvStack_10;
  cVar5 = FUN_0098c5a0();
  if (cVar5 == '\0') {
    pcStack_2bc = (code *)0x0;
    puStack_2c4 = (undefined4 *)0xc5ff27;
    cVar5 = FUN_00973950();
    if (cVar5 == '\0') {
      puStack_2c0 = (undefined4 *)0xc60107;
      uStack_24 = FUN_0097bfc0();
      piStack_20 = aiStack_2d8;
      puStack_2dc = &stack0x0000002c;
      uStack_2e0 = 0xc6011b;
      FUN_0054f510();
      piStack_1c = aiStack_2f8;
      uStack_8._0_1_ = 0xc;
      piStack_2fc = (int *)&param_3;
      uStack_300 = 0xc60130;
      FUN_0054f510();
      piStack_34 = &uStack_300;
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[1] = param_2[1] + 1;
        UNLOCK();
      }
      uStack_300 = param_1;
      piStack_2fc = param_2;
      uStack_8._0_1_ = 0xe;
      FUN_0060dcd0(auStack_308,uStack_24);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_00c60870();
    }
    else {
      puStack_2c0 = (undefined4 *)0xc5ff3b;
      uVar6 = FUN_0097bfc0();
      uStack_18 = 0;
      piStack_14 = (int *)0x0;
      pcStack_2bc = (code *)&stack0x0000002c;
      uStack_8._0_1_ = 3;
      puStack_2c0 = &param_3;
      puStack_2c4 = &uStack_18;
      puStack_2c8 = (undefined4 *)0xc5ff65;
      uStack_24 = FUN_00c5d680();
      uStack_40 = 0;
      uStack_3c = 0;
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[1] = param_2[1] + 1;
        UNLOCK();
      }
      piStack_1c = param_2;
      uStack_38 = param_1;
      piStack_34 = param_2;
      puStack_2c0 = &uStack_18;
      uStack_8._0_1_ = 4;
      puStack_2c4 = (undefined4 *)0xc5ffa1;
      pcStack_2bc = (code *)uVar6;
      FUN_0060dcd0();
      uStack_8._0_1_ = 6;
      pcVar3 = *(code **)(*piStack_20 + 8);
      pcStack_2bc = (code *)0xc5ffb5;
      uStack_2b0 = FUN_0088c8c0();
      uStack_2ac = 0;
      uStack_2a8 = uStack_24;
      pcStack_2bc = (code *)0xc5ffd3;
      uStack_2ac = FUN_005c9cc0();
      uStack_8._0_1_ = 7;
      pcStack_2bc = (code *)0xc5ffe2;
      uStack_1e0 = FUN_0088cdc0();
      uStack_1d8 = uStack_18;
      uStack_1dc = 0;
      uStack_1d4 = piStack_14;
      uStack_18 = 0;
      piStack_14 = (int *)0x0;
      pcStack_2bc = (code *)0xc60017;
      uStack_1dc = FUN_006309e0();
      uStack_8._0_1_ = 8;
      pcStack_2bc = (code *)0xc60026;
      uStack_110 = FUN_0088cbe0();
      uStack_10c = 0;
      uStack_108 = param_1;
      piStack_104 = piStack_1c;
      uStack_38 = 0;
      piStack_34 = (int *)0x0;
      pcStack_2bc = (code *)0xc60058;
      uStack_10c = FUN_00630900();
      pcStack_2bc = (code *)param_2;
      puStack_2c0 = &uStack_40;
      uStack_8._0_1_ = 9;
      puStack_2c4 = &uStack_2b0;
      uStack_30 = 0;
      uStack_2c = 0;
      uStack_28 = 0;
      puStack_2c8 = (undefined4 *)0xc6008d;
      FUN_00687980();
      pcStack_2bc = (code *)&uStack_40;
      puStack_2c0 = &uStack_30;
      uStack_8._0_1_ = 10;
      puStack_2c4 = (undefined4 *)&DAT_02137430;
      puStack_2c8 = (undefined4 *)0xc600a3;
      (*pcVar3)();
      uStack_8._0_1_ = 0xb;
      pcStack_2bc = (code *)0xc600af;
      FUN_00577b20();
      pcStack_2bc = FUN_0056e5b0;
      puStack_2c0 = (undefined4 *)0x3;
      puStack_2c4 = (undefined4 *)0xd0;
      puStack_2c8 = &uStack_2b0;
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      uStack_2cc = 0xc600cb;
      FUN_016f32d1();
      piVar2 = piStack_14;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_14[1] + -1;
        piStack_14[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          pcStack_2bc = (code *)0xc600ec;
          (**(code **)*piStack_14)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar4 = *piVar1 + -1;
          *piVar1 = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            pcStack_2bc = (code *)0xc60100;
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
    }
    if (param_2 != (int *)0x0) {
      LOCK();
      iVar4 = param_2[1] + -1;
      param_2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        pcStack_2bc = (code *)0xc60191;
        (**(code **)*param_2)();
        LOCK();
        piVar2 = param_2 + 2;
        iVar4 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          pcStack_2bc = (code *)0xc601a0;
          (**(code **)(*param_2 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
    if (param_3 != 0) {
      if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
        puStack_2c4 = (undefined4 *)&stack0x00000014;
        pcStack_2bc = (code *)0x2;
        puStack_2c8 = (undefined4 *)0xc601c1;
        puStack_2c0 = puStack_2c4;
        (**(code **)(param_3 & 0xfffffffe))();
      }
      param_3 = 0;
    }
    uStack_8 = 0x10;
    if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
       (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
      puStack_2c4 = (undefined4 *)&stack0x00000034;
      pcStack_2bc = (code *)0x2;
      puStack_2c8 = (undefined4 *)0xc601ef;
      puStack_2c0 = puStack_2c4;
      (**(code **)(in_stack_0000002c & 0xfffffffe))();
    }
    ExceptionList = pvStack_10;
    return;
  }
  pcStack_2bc = (code *)0x196c3a8;
  puStack_2c0 = (undefined4 *)0xc60211;
  FUN_00550130();
  pcStack_2bc = (code *)&DAT_01c17198;
  puStack_2c0 = &uStack_30;
                    /* WARNING: Subroutine does not return */
  puStack_2c4 = (undefined4 *)&UNK_00c6021f;
  FUN_0170c2a8();
}



/* FUNCTION 28792 ; VA 0x00c60220 ; FUN_00c60220 */

undefined4 FUN_00c60220(int param_1,undefined4 param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar3 = FUN_00913630();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      FUN_00927d30(&param_1);
      cVar2 = FUN_00a33d60(param_2);
      if (cVar2 != '\0') {
        return 1;
      }
    }
  }
  return 0;
}



/* FUNCTION 28793 ; VA 0x00c60280 ; FUN_00c60280 */

undefined FUN_00c60280(int *param_1,undefined4 param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180c810;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088cdc0();
  if (iVar1 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  piVar4 = param_1 + 2;
  if (param_1[1] == 0) {
    piVar4 = (int *)0x0;
  }
  piVar5 = (int *)piVar4[1];
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = (int *)piVar4[1];
  }
  iStack_1c = *piVar4;
  uStack_8 = 0;
  piStack_18 = piVar5;
  FUN_00562c90(&iStack_24,&iStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_24 != 0) {
    FUN_00927d30(auStack_14);
    cVar2 = FUN_005e0cd0(param_2);
    param_1._3_1_ = 1;
    if (cVar2 == '\0') goto LAB_00c60313;
  }
  param_1._3_1_ = 0;
LAB_00c60313:
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_20[1] + -1;
    piStack_20[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar1 = piStack_20[2] + -1;
      piStack_20[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar1 = piVar5[1] + -1;
    piVar5[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      piVar4 = piVar5 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1._3_1_;
}



/* FUNCTION 28794 ; VA 0x00c60380 ; FUN_00c60380 */

uint FUN_00c60380(void)

{
  int iVar1;
  
  iVar1 = FUN_00c58600();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28795 ; VA 0x00c603a0 ; FUN_00c603a0 */

uint FUN_00c603a0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c58700();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28796 ; VA 0x00c603c0 ; FUN_00c603c0 */

uint FUN_00c603c0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c58600();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28797 ; VA 0x00c603e0 ; FUN_00c603e0 */

uint FUN_00c603e0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c58700();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28798 ; VA 0x00c60400 ; FUN_00c60400 */

void __thiscall
FUN_00c60400(int param_1,undefined4 param_2,int *param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 *param_9,
            ulonglong param_10,char *param_11,undefined4 param_12,int param_13,int param_14,
            int param_15,undefined4 *param_16,undefined8 param_17)

{
  int iVar1;
  uint *puVar2;
  char **ppcVar3;
  undefined uVar4;
  char cVar5;
  undefined4 *puVar6;
  int *piVar7;
  uint auStack_27c [2];
  undefined4 uStack_274;
  undefined4 uStack_270;
  undefined4 uStack_26c;
  undefined4 *puStack_268;
  undefined8 uStack_264;
  char *pcStack_25c;
  undefined4 uStack_258;
  int iStack_254;
  int iStack_250;
  int iStack_24c;
  undefined4 *puStack_248;
  undefined8 uStack_244;
  undefined auStack_234 [80];
  undefined auStack_1e4 [80];
  undefined auStack_194 [80];
  undefined auStack_144 [80];
  undefined auStack_f4 [80];
  int iStack_a4;
  undefined4 uStack_a0;
  int *piStack_9c;
  uint uStack_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 *puStack_80;
  ulonglong uStack_7c;
  char *pcStack_74;
  int iStack_6c;
  int iStack_68;
  int iStack_64;
  undefined4 *puStack_60;
  undefined8 uStack_5c;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined **appuStack_3c [2];
  undefined4 auStack_34 [6];
  undefined *puStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180c8bf;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (*(int *)(param_1 + 0x78) == 0) {
    piStack_18 = &iStack_a4;
    ExceptionList = &pvStack_10;
    if (param_3 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    uStack_a0 = param_2;
    piStack_9c = param_3;
    uStack_8._0_1_ = 3;
    uStack_8._1_3_ = 0;
    uStack_94 = 0;
    iStack_a4 = param_1;
    if (param_4 != 0) {
      uStack_94 = param_4;
      if ((param_4 & 1) == 0) {
        uStack_244 = ZEXT48(&uStack_8c);
        puStack_248 = &param_6;
        iStack_24c = 0xc604bd;
        (**(code **)(param_4 & 0xfffffffe))();
      }
      else {
        uStack_8c = param_6;
        uStack_88 = param_7;
        uStack_84 = param_8;
        puStack_80 = param_9;
        uStack_7c = param_10;
      }
    }
    uStack_8._0_1_ = 4;
    pcStack_74 = (char *)0x0;
    if (param_11 != (char *)0x0) {
      pcStack_74 = param_11;
      if (((uint)param_11 & 1) == 0) {
        uStack_244 = ZEXT48(&iStack_6c);
        puStack_248 = &param_13;
        iStack_24c = 0xc604fe;
        (**(code **)((uint)param_11 & 0xfffffffe))();
      }
      else {
        iStack_6c = param_13;
        iStack_68 = param_14;
        iStack_64 = param_15;
        puStack_60 = param_16;
        uStack_5c = param_17;
      }
    }
    uStack_8._0_1_ = 5;
    uStack_244 = CONCAT44(&iStack_a4,0xc60517);
    FUN_00c5aad0();
    uStack_8._0_1_ = 6;
    appuStack_3c[0] = (undefined **)0x0;
    uStack_244 = CONCAT44(auStack_234,0xc60534);
    FUN_00c5aad0();
    uStack_8._0_1_ = 7;
    uStack_244 = CONCAT44(auStack_1e4,0xc6054a);
    FUN_00c5aad0();
    uStack_8._0_1_ = 8;
    uStack_244 = CONCAT44(auStack_194,0xc60560);
    FUN_00c5aad0();
    uStack_8._0_1_ = 9;
    uStack_244 = CONCAT44(auStack_f4,0xc60570);
    cVar5 = FUN_00585a40();
    if (cVar5 == '\0') {
      uStack_244 = CONCAT44(auStack_f4,0xc60589);
      FUN_00c5aad0();
      uStack_8._0_1_ = 10;
      uStack_244 = 0x5000c60594;
      piStack_18 = (int *)FUN_01674e20();
      uStack_8._0_1_ = 0xb;
      if (piStack_18 == (int *)0x0) {
        auStack_34[0] = 0;
      }
      else {
        uStack_244 = CONCAT44(auStack_144,0xc605b0);
        auStack_34[0] = FUN_00c5aad0();
      }
      uStack_244 = CONCAT44(0xc605c2,(undefined4)uStack_244);
      FUN_00c5b430();
      uStack_244 = CONCAT44(0xc605cd,(undefined4)uStack_244);
      FUN_00c5b430();
      cStack_11 = '\x01';
    }
    else {
      uStack_244 = CONCAT44(0xc605de,(undefined4)uStack_244);
      FUN_00c5b430();
      cStack_11 = '\0';
    }
    uStack_244 = CONCAT44(0xc605ed,(undefined4)uStack_244);
    FUN_00c5b430();
    appuStack_3c[0] = &PTR_FUN_0196c85c;
    if (cStack_11 == '\0') {
      appuStack_3c[0] = (undefined **)0x0;
    }
    uStack_244 = CONCAT44(0xc60608,(undefined4)uStack_244);
    FUN_00c5b430();
    uStack_244 = CONCAT44(0xc60613,(undefined4)uStack_244);
    FUN_00c5b430();
    uStack_244 = CONCAT44(0xc6061e,(undefined4)uStack_244);
    FUN_00c5b430();
    uStack_8._0_1_ = 0xc;
    uStack_244 = CONCAT44(appuStack_3c,0xc60631);
    cVar5 = FUN_00c62700();
    cStack_11 = cVar5 == '\0';
    uStack_8._0_1_ = 0xd;
    if (((appuStack_3c[0] != (undefined **)0x0) && (((uint)appuStack_3c[0] & 1) == 0)) &&
       (*(code **)((uint)appuStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
      puStack_248 = auStack_34;
      uStack_244 = CONCAT44(2,puStack_248);
      iStack_24c = 0xc60658;
      (**(code **)((uint)appuStack_3c[0] & 0xfffffffe))();
    }
    uStack_8._0_1_ = 2;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (cStack_11 != '\0') {
      uStack_244 = CONCAT44(auStack_34,0xc60674);
      FUN_008a2380();
      uStack_244 = 0x2f0196c57c;
      puStack_248 = (undefined4 *)0x0;
      uStack_8._0_1_ = 0xe;
      iStack_24c = 0xc60688;
      puVar6 = (undefined4 *)FUN_00585d40();
      uStack_54 = *puVar6;
      uStack_50 = puVar6[1];
      uStack_4c = puVar6[2];
      uStack_48 = puVar6[3];
      uStack_44 = *(undefined8 *)(puVar6 + 4);
      puVar6[4] = 0;
      puVar6[5] = 0xf;
      *(undefined *)puVar6 = 0;
      piStack_18 = &iStack_254;
      uStack_8._0_1_ = 0xf;
      uStack_258 = 0x2d;
      pcStack_25c = "; did you forget to implement OnClientInvoke?";
      uStack_264 = CONCAT44(0xc606d3,(undefined4)uStack_264);
      piVar7 = (int *)FUN_00554150();
      iStack_254 = *piVar7;
      iStack_250 = piVar7[1];
      iStack_24c = piVar7[2];
      puStack_248 = (undefined4 *)piVar7[3];
      uStack_244 = *(ulonglong *)(piVar7 + 4);
      piVar7[4] = 0;
      piVar7[5] = 0xf;
      *(undefined *)piVar7 = 0;
      uStack_258 = 0xc6070a;
      FUN_005e65e0();
      uStack_244 = CONCAT44(0xc60712,(undefined4)uStack_244);
      FUN_005507b0();
      uStack_244 = CONCAT44(0xc6071a,(undefined4)uStack_244);
      FUN_005507b0();
      uVar4 = (undefined)uStack_8;
    }
  }
  else {
    piStack_18 = (int *)&pcStack_25c;
    puStack_1c = (undefined *)&pcStack_25c;
    pcStack_25c = (char *)0x0;
    ExceptionList = &pvStack_10;
    ppcVar3 = &pcStack_25c;
    if (param_11 != (char *)0x0) {
      pcStack_25c = param_11;
      if (((uint)param_11 & 1) == 0) {
        uStack_264 = ZEXT48(&iStack_254);
        puStack_268 = &param_13;
        uStack_26c = 0xc60763;
        ExceptionList = &pvStack_10;
        (**(code **)((uint)param_11 & 0xfffffffe))();
        ppcVar3 = (char **)piStack_18;
      }
      else {
        iStack_254 = param_13;
        iStack_250 = param_14;
        iStack_24c = param_15;
        puStack_248 = param_16;
        uStack_244 = param_17;
        ExceptionList = &pvStack_10;
        ppcVar3 = &pcStack_25c;
      }
    }
    piStack_18 = (int *)ppcVar3;
    puStack_1c = (undefined *)auStack_27c;
    uStack_8._0_1_ = 0x10;
    auStack_27c[0] = 0;
    puVar2 = auStack_27c;
    if (param_4 != 0) {
      auStack_27c[0] = param_4;
      if ((param_4 & 1) == 0) {
        (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_274,0);
        puVar2 = (uint *)puStack_1c;
      }
      else {
        uStack_274 = param_6;
        uStack_270 = param_7;
        uStack_26c = param_8;
        puStack_268 = param_9;
        uStack_264 = param_10;
        puVar2 = auStack_27c;
      }
    }
    puStack_1c = (undefined *)puVar2;
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 2;
    FUN_00c5bc10(param_2,param_3);
    uVar4 = (undefined)uStack_8;
  }
  uStack_8._0_1_ = uVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_244 = CONCAT44(0xc607fb,(undefined4)uStack_244);
      (**(code **)*param_3)();
      LOCK();
      piVar7 = param_3 + 2;
      iVar1 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        uStack_244 = CONCAT44(0xc6080a,(undefined4)uStack_244);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_248 = &param_6;
    uStack_244 = CONCAT44(2,puStack_248);
    iStack_24c = 0xc6082b;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 0x12;
  if (((param_11 != (char *)0x0) && (((uint)param_11 & 1) == 0)) &&
     (*(code **)((uint)param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_248 = &param_13;
    uStack_244 = CONCAT44(2,puStack_248);
    iStack_24c = 0xc60859;
    (**(code **)((uint)param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28799 ; VA 0x00c60870 ; FUN_00c60870 */

void __thiscall
FUN_00c60870(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5,
            uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 *param_11,ulonglong param_12,char *param_13,
            undefined4 param_14,int param_15,int param_16,int param_17,undefined4 *param_18,
            undefined8 param_19)

{
  int iVar1;
  uint *puVar2;
  char **ppcVar3;
  undefined uVar4;
  char cVar5;
  undefined4 *puVar6;
  int *piVar7;
  uint auStack_2ac [2];
  undefined4 uStack_2a4;
  undefined4 uStack_2a0;
  undefined4 uStack_29c;
  undefined4 *puStack_298;
  undefined8 uStack_294;
  char *pcStack_28c;
  undefined4 uStack_288;
  int iStack_284;
  int iStack_280;
  int iStack_27c;
  undefined4 *puStack_278;
  undefined8 uStack_274;
  undefined auStack_264 [88];
  undefined auStack_20c [88];
  undefined auStack_1b4 [88];
  undefined auStack_15c [88];
  undefined auStack_104 [88];
  int iStack_ac;
  undefined4 uStack_a8;
  int *piStack_a4;
  undefined4 uStack_a0;
  int *piStack_9c;
  uint uStack_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 *puStack_80;
  ulonglong uStack_7c;
  char *pcStack_74;
  int iStack_6c;
  int iStack_68;
  int iStack_64;
  undefined4 *puStack_60;
  undefined8 uStack_5c;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined **appuStack_3c [2];
  undefined4 auStack_34 [6];
  undefined *puStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180c982;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  if (*(int *)(param_1 + 0x58) == 0) {
    piStack_18 = &iStack_ac;
    ExceptionList = &pvStack_10;
    if (param_3 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    uStack_a8 = param_2;
    piStack_a4 = param_3;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    uStack_a0 = param_4;
    piStack_9c = param_5;
    uStack_8._0_1_ = 5;
    uStack_8._1_3_ = 0;
    uStack_94 = 0;
    iStack_ac = param_1;
    if (param_6 != 0) {
      uStack_94 = param_6;
      if ((param_6 & 1) == 0) {
        uStack_274 = ZEXT48(&uStack_8c);
        puStack_278 = &param_8;
        iStack_27c = 0xc6095e;
        (**(code **)(param_6 & 0xfffffffe))();
      }
      else {
        uStack_8c = param_8;
        uStack_88 = param_9;
        uStack_84 = param_10;
        puStack_80 = param_11;
        uStack_7c = param_12;
      }
    }
    uStack_8._0_1_ = 6;
    pcStack_74 = (char *)0x0;
    if (param_13 != (char *)0x0) {
      pcStack_74 = param_13;
      if (((uint)param_13 & 1) == 0) {
        uStack_274 = ZEXT48(&iStack_6c);
        puStack_278 = &param_15;
        iStack_27c = 0xc6099f;
        (**(code **)((uint)param_13 & 0xfffffffe))();
      }
      else {
        iStack_6c = param_15;
        iStack_68 = param_16;
        iStack_64 = param_17;
        puStack_60 = param_18;
        uStack_5c = param_19;
      }
    }
    uStack_8._0_1_ = 7;
    uStack_274 = CONCAT44(&iStack_ac,0xc609b8);
    FUN_00c5abd0();
    uStack_8._0_1_ = 8;
    appuStack_3c[0] = (undefined **)0x0;
    uStack_274 = CONCAT44(auStack_264,0xc609d5);
    FUN_00c5abd0();
    uStack_8._0_1_ = 9;
    uStack_274 = CONCAT44(auStack_20c,0xc609eb);
    FUN_00c5abd0();
    uStack_8._0_1_ = 10;
    uStack_274 = CONCAT44(auStack_1b4,0xc60a01);
    FUN_00c5abd0();
    uStack_8._0_1_ = 0xb;
    uStack_274 = CONCAT44(auStack_104,0xc60a11);
    cVar5 = FUN_00585a40();
    if (cVar5 == '\0') {
      uStack_274 = CONCAT44(auStack_104,0xc60a2a);
      FUN_00c5abd0();
      uStack_8._0_1_ = 0xc;
      uStack_274 = 0x5800c60a35;
      piStack_18 = (int *)FUN_01674e20();
      uStack_8._0_1_ = 0xd;
      if (piStack_18 == (int *)0x0) {
        auStack_34[0] = 0;
      }
      else {
        uStack_274 = CONCAT44(auStack_15c,0xc60a51);
        auStack_34[0] = FUN_00c5abd0();
      }
      uStack_274 = CONCAT44(0xc60a63,(undefined4)uStack_274);
      FUN_00c5b4e0();
      uStack_274 = CONCAT44(0xc60a6e,(undefined4)uStack_274);
      FUN_00c5b4e0();
      cStack_11 = '\x01';
    }
    else {
      uStack_274 = CONCAT44(0xc60a7f,(undefined4)uStack_274);
      FUN_00c5b4e0();
      cStack_11 = '\0';
    }
    uStack_274 = CONCAT44(0xc60a8e,(undefined4)uStack_274);
    FUN_00c5b4e0();
    appuStack_3c[0] = &PTR_FUN_0196c854;
    if (cStack_11 == '\0') {
      appuStack_3c[0] = (undefined **)0x0;
    }
    uStack_274 = CONCAT44(0xc60aa9,(undefined4)uStack_274);
    FUN_00c5b4e0();
    uStack_274 = CONCAT44(0xc60ab4,(undefined4)uStack_274);
    FUN_00c5b4e0();
    uStack_274 = CONCAT44(0xc60abf,(undefined4)uStack_274);
    FUN_00c5b4e0();
    uStack_8._0_1_ = 0xe;
    uStack_274 = CONCAT44(appuStack_3c,0xc60ad2);
    cVar5 = FUN_00c62700();
    cStack_11 = cVar5 == '\0';
    uStack_8._0_1_ = 0xf;
    if (((appuStack_3c[0] != (undefined **)0x0) && (((uint)appuStack_3c[0] & 1) == 0)) &&
       (*(code **)((uint)appuStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
      puStack_278 = auStack_34;
      uStack_274 = CONCAT44(2,puStack_278);
      iStack_27c = 0xc60af9;
      (**(code **)((uint)appuStack_3c[0] & 0xfffffffe))();
    }
    uStack_8._0_1_ = 3;
    uVar4 = (undefined)uStack_8;
    uStack_8._0_1_ = 3;
    if (cStack_11 != '\0') {
      uStack_274 = CONCAT44(auStack_34,0xc60b15);
      FUN_008a2380();
      uStack_274 = 0x2f0196c57c;
      puStack_278 = (undefined4 *)0x0;
      uStack_8._0_1_ = 0x10;
      iStack_27c = 0xc60b29;
      puVar6 = (undefined4 *)FUN_00585d40();
      uStack_54 = *puVar6;
      uStack_50 = puVar6[1];
      uStack_4c = puVar6[2];
      uStack_48 = puVar6[3];
      uStack_44 = *(undefined8 *)(puVar6 + 4);
      puVar6[4] = 0;
      puVar6[5] = 0xf;
      *(undefined *)puVar6 = 0;
      piStack_18 = &iStack_284;
      uStack_8._0_1_ = 0x11;
      uStack_288 = 0x2d;
      pcStack_28c = "; did you forget to implement OnServerInvoke?";
      uStack_294 = CONCAT44(0xc60b74,(undefined4)uStack_294);
      piVar7 = (int *)FUN_00554150();
      iStack_284 = *piVar7;
      iStack_280 = piVar7[1];
      iStack_27c = piVar7[2];
      puStack_278 = (undefined4 *)piVar7[3];
      uStack_274 = *(ulonglong *)(piVar7 + 4);
      piVar7[4] = 0;
      piVar7[5] = 0xf;
      *(undefined *)piVar7 = 0;
      uStack_288 = 0xc60bab;
      FUN_005e65e0();
      uStack_274 = CONCAT44(0xc60bb3,(undefined4)uStack_274);
      FUN_005507b0();
      uStack_274 = CONCAT44(0xc60bbb,(undefined4)uStack_274);
      FUN_005507b0();
      uVar4 = (undefined)uStack_8;
    }
  }
  else {
    uStack_274 = CONCAT44(&cStack_11,&DAT_01efdb1c);
    puStack_278 = (undefined4 *)0xc60bce;
    ExceptionList = &pvStack_10;
    FUN_00c59160();
    piStack_18 = (int *)&pcStack_28c;
    puStack_1c = (undefined *)&pcStack_28c;
    pcStack_28c = (char *)0x0;
    ppcVar3 = &pcStack_28c;
    if (param_13 != (char *)0x0) {
      pcStack_28c = param_13;
      if (((uint)param_13 & 1) == 0) {
        uStack_294 = ZEXT48(&iStack_284);
        puStack_298 = &param_15;
        uStack_29c = 0xc60c12;
        (**(code **)((uint)param_13 & 0xfffffffe))();
        ppcVar3 = (char **)piStack_18;
      }
      else {
        iStack_284 = param_15;
        iStack_280 = param_16;
        iStack_27c = param_17;
        puStack_278 = param_18;
        uStack_274 = param_19;
        ppcVar3 = &pcStack_28c;
      }
    }
    piStack_18 = (int *)ppcVar3;
    puStack_1c = (undefined *)auStack_2ac;
    uStack_8._0_1_ = 0x12;
    auStack_2ac[0] = 0;
    puVar2 = auStack_2ac;
    if (param_6 != 0) {
      auStack_2ac[0] = param_6;
      if ((param_6 & 1) == 0) {
        (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_2a4,0);
        puVar2 = (uint *)puStack_1c;
      }
      else {
        uStack_2a4 = param_8;
        uStack_2a0 = param_9;
        uStack_29c = param_10;
        puStack_298 = param_11;
        uStack_294 = param_12;
        puVar2 = auStack_2ac;
      }
    }
    puStack_1c = (undefined *)puVar2;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 3;
    FUN_00c5bd60(param_2,param_3,param_4,param_5);
    uVar4 = (undefined)uStack_8;
  }
  uStack_8._0_1_ = uVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_274 = CONCAT44(0xc60cd2,(undefined4)uStack_274);
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_274 = CONCAT44(0xc60ce2,(undefined4)uStack_274);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar1 = param_5[1] + -1;
    param_5[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_274 = CONCAT44(0xc60cf8,(undefined4)uStack_274);
      (**(code **)*param_5)();
      LOCK();
      piVar7 = param_5 + 2;
      iVar1 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        uStack_274 = CONCAT44(0xc60d07,(undefined4)uStack_274);
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    puStack_278 = &param_8;
    uStack_274 = CONCAT44(2,puStack_278);
    iStack_27c = 0xc60d28;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  uStack_8 = 0x14;
  if (((param_13 != (char *)0x0) && (((uint)param_13 & 1) == 0)) &&
     (*(code **)((uint)param_13 & 0xfffffffe) != (code *)0x0)) {
    puStack_278 = &param_15;
    uStack_274 = CONCAT44(2,puStack_278);
    iStack_27c = 0xc60d56;
    (**(code **)((uint)param_13 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28800 ; VA 0x00c60d70 ; FUN_00c60d70 */

void FUN_00c60d70(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a13f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x50);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00c5aad0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00c5b430();
        FUN_01674ea0(iVar2,0x50);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1e06fc4);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_240be024802ac75a9610739ba6e3ced1>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 28801 ; VA 0x00c60ec0 ; FUN_00c60ec0 */

void FUN_00c60ec0(undefined8 *param_1,int *param_2,int param_3)

{
  int iVar1;
  undefined8 *puVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *(undefined8 *)param_2 = *param_1;
      param_2[2] = *(int *)(param_1 + 1);
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1e07034);
      puVar2 = (undefined8 *)0x0;
      if (iVar1 == 0) {
        puVar2 = param_1;
      }
      *param_2 = (int)puVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_2845f6e05374110a6f2af25f7177f6f2>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 28802 ; VA 0x00c60f30 ; FUN_00c60f30 */

void FUN_00c60f30(undefined8 *param_1,int *param_2,int param_3)

{
  int iVar1;
  undefined8 *puVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *(undefined8 *)param_2 = *param_1;
      param_2[2] = *(int *)(param_1 + 1);
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1e070a4);
      puVar2 = (undefined8 *)0x0;
      if (iVar1 == 0) {
        puVar2 = param_1;
      }
      *param_2 = (int)puVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_4d6a5baa7774f4e9e2a8e44b1eca0103>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 28803 ; VA 0x00c60fb0 ; FUN_00c60fb0 */

void FUN_00c60fb0(undefined8 *param_1,int *param_2,int param_3)

{
  int iVar1;
  undefined8 *puVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *(undefined8 *)param_2 = *param_1;
      param_2[2] = *(int *)(param_1 + 1);
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1e0706c);
      puVar2 = (undefined8 *)0x0;
      if (iVar1 == 0) {
        puVar2 = param_1;
      }
      *param_2 = (int)puVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_4da60328e663bc5caf1a1a43e257f467>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 28804 ; VA 0x00c61020 ; FUN_00c61020 */

void FUN_00c61020(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c005f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x58);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00c5abd0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00c5b4e0();
        FUN_01674ea0(iVar2,0x58);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1e06ffc);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_a775febdc0006fe30c5559a6605215e2>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 28805 ; VA 0x00c61170 ; FUN_00c61170 */

void FUN_00c61170(undefined8 *param_1,int *param_2,int param_3)

{
  int iVar1;
  undefined8 *puVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *(undefined8 *)param_2 = *param_1;
      param_2[2] = *(int *)(param_1 + 1);
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1e070dc);
      puVar2 = (undefined8 *)0x0;
      if (iVar1 == 0) {
        puVar2 = param_1;
      }
      *param_2 = (int)puVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_b445612209c5b74e35cb120dfc11a256>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 28806 ; VA 0x00c611e0 ; FUN_00c611e0 */

int * FUN_00c611e0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c612b7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c61236. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1e077c4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_d1ff37bc88d45b4407b4b0cd6c741139>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 28807 ; VA 0x00c612d0 ; FUN_00c612d0 */

void FUN_00c612d0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar2 = (int *)(param_1[1] + 4);
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar2 = (int *)(param_1[3] + 4);
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      if (param_3 != 1) {
        return;
      }
      FUN_0056b650();
      return;
    }
    if (param_3 == 2) {
      FUN_0056b650();
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1e0798c);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&<lambda_f793a36b46b18180de5a69c53a72db8f>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 28808 ; VA 0x00c61390 ; FUN_00c61390 */

int * FUN_00c61390(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (param_1[2] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[2] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[2];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c61472. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[2];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c613e6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1e07484);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>)>_>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list4<class_boost::_bi::value<class_std::shared_ptr<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>)>_>_>,struct_boost::arg<1>,struct_boost::arg<2>,struct_boost::arg<3>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 28809 ; VA 0x00c61490 ; FUN_00c61490 */

int * FUN_00c61490(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (param_1[2] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[2] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[2];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c61572. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[2];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c614e6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1e07114);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>)>_>,class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list5<class_boost::_bi::value<class_std::shared_ptr<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>)>_>_>,struct_boost::arg<1>,struct_boost::arg<2>,struct_boost::arg<3>,struct_boost::arg<4>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 28810 ; VA 0x00c61590 ; FUN_00c61590 */

int * FUN_00c61590(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      param_2[3] = 0;
      param_2[4] = 0;
      if (param_1[4] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[4] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[3] = param_1[3];
      piVar3 = (int *)param_1[4];
      param_2[4] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[4];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c6167e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[4];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00c615e6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1e077fc);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf1<void,class_RBX::LatchedSignal<class_rbx::remote_signal,void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>_>,class_boost::_bi::list2<class_boost::_bi::value<class_RBX::LatchedSignal<class_rbx::remote_signal,void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>*>,class_boost::_bi::value<class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 28811 ; VA 0x00c616a0 ; FUN_00c616a0 */

void FUN_00c616a0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      puVar2 = (undefined4 *)FUN_01674e20(0x20);
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        FUN_00a66ab0(puVar1 + 2);
        *param_2 = (int)puVar2;
        return;
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        FUN_00a678e0();
        FUN_01674ea0(iVar3,0x20);
      }
      *param_2 = 0;
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1e079c4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        return;
      }
      *param_2 = 0;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf2<void,class_RBX::LatchedSignal<class_rbx::remote_signal,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>_>,class_boost::_bi::list3<class_boost::_bi::value<class_RBX::LatchedSignal<class_rbx::remote_signal,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>*>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::Instance>_>,class_boost::_bi::value<class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 28812 ; VA 0x00c61780 ; FUN_00c61780 */

void __fastcall FUN_00c61780(undefined4 param_1)

{
  char cVar1;
  undefined auStack_10 [12];
  
  cVar1 = FUN_0098c5a0(param_1,0);
  if (cVar1 == '\0') {
    FUN_00c61f30();
    return;
  }
  FUN_00b1a2e0(0);
  FUN_00550130("OnClientInvoke can only be implemented on the client");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 28813 ; VA 0x00c617d0 ; FUN_00c617d0 */

uint __thiscall FUN_00c617d0(int param_1,int param_2,int *param_3)

{
  uint *puVar1;
  undefined8 uVar2;
  undefined uVar3;
  uint ****ppppuVar4;
  int *piVar5;
  undefined4 ****ppppuVar6;
  uint **ppuVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  uint uVar13;
  undefined4 uStack_fc;
  int *piStack_f8;
  uint uStack_f4;
  undefined auStack_ec [24];
  uint uStack_d4;
  undefined auStack_cc [24];
  uint uStack_b4;
  undefined4 uStack_a4;
  uint uStack_a0;
  int iStack_9c;
  int *piStack_98;
  uint uStack_94;
  undefined4 uStack_84;
  uint uStack_80;
  uint ***pppuStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  uint **ppuStack_64;
  uint **ppuStack_60;
  uint **ppuStack_5c;
  uint **ppuStack_58;
  uint uStack_54;
  uint uStack_50;
  undefined4 ***pppuStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  undefined8 uStack_3c;
  int iStack_34;
  undefined4 *puStack_30;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  int *piStack_24;
  int iStack_20;
  uint ***pppuStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_0180c9fd;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_24 = param_3;
  iStack_9c = param_2;
  piStack_98 = param_3;
  puVar12 = (undefined4 *)0x0;
  puVar11 = (undefined4 *)0x0;
  iStack_18 = 0;
  iStack_34 = 0;
  puStack_30 = (undefined4 *)0x0;
  puStack_28 = (undefined4 *)0x0;
  puStack_2c = (undefined4 *)0x0;
  uStack_8 = 2;
  uStack_7 = 0;
  uStack_14 = **(int **)(param_1 + 200);
  iStack_20 = param_1;
  if ((int *)uStack_14 != *(int **)(param_1 + 200)) {
    do {
      if ((piStack_24 <= *(int **)(uStack_14 + 0x1c)) && (*(int **)(uStack_14 + 0x1c) <= piStack_24)
         ) {
        if (puVar12 == puVar11) {
          FUN_0063d9b0(puVar11,(undefined4 *)(uStack_14 + 0x10));
          puVar11 = puStack_30;
          puVar12 = puStack_2c;
        }
        else {
          *puVar11 = *(undefined4 *)(uStack_14 + 0x10);
          puStack_30 = puVar11 + 1;
          puVar11 = puStack_30;
        }
      }
      FUN_00551320();
    } while (uStack_14 != *(int *)(iStack_20 + 200));
    iStack_18 = iStack_34;
    puStack_28 = puVar12;
  }
  iStack_34 = iStack_18;
  puVar12 = (undefined4 *)FUN_008a2380();
  pppuStack_1c = *(uint ****)(param_2 + 0x28);
  uStack_84 = 0;
  uStack_80 = 0xf;
  uStack_94 = uStack_94 & 0xffffff00;
  uStack_8 = 4;
  uStack_14 = 1;
  FUN_0058a190();
  FUN_00554150("Player ",7);
  ppppuVar4 = (uint ****)pppuStack_1c;
  if ((uint ***)0xf < pppuStack_1c[5]) {
    ppppuVar4 = (uint ****)*pppuStack_1c;
  }
  FUN_00554150(ppppuVar4,pppuStack_1c[4]);
  piVar5 = (int *)FUN_00554150(" disconnected during remote call to ",0x24);
  uStack_14 = 3;
  pppuStack_4c = (undefined4 ***)*piVar5;
  iStack_48 = piVar5[1];
  iStack_44 = piVar5[2];
  iStack_40 = piVar5[3];
  uVar2 = *(undefined8 *)(piVar5 + 4);
  piVar5[4] = 0;
  piVar5[5] = 0xf;
  *(undefined *)piVar5 = 0;
  uStack_3c._4_4_ = (uint)((ulonglong)uVar2 >> 0x20);
  uStack_3c._0_4_ = (uint)uVar2;
  uVar8 = puVar12[4];
  _uStack_8 = CONCAT31(uStack_7,5);
  uStack_3c = uVar2;
  if ((uStack_3c._4_4_ - (uint)uStack_3c < uVar8) && ((uint)uStack_3c <= puVar12[5] - uVar8)) {
    ppppuVar6 = &pppuStack_4c;
    if (0xf < uStack_3c._4_4_) {
      ppppuVar6 = (undefined4 ****)pppuStack_4c;
    }
    uVar8 = (uint)uStack_3c;
    puVar12 = (undefined4 *)FUN_00585d40(0,ppppuVar6,uVar8);
  }
  else {
    if (0xf < (uint)puVar12[5]) {
      puVar12 = (undefined4 *)*puVar12;
    }
    puVar12 = (undefined4 *)FUN_00554150(puVar12,uVar8);
  }
  pppuStack_7c = (uint ***)*puVar12;
  uStack_78 = puVar12[1];
  uStack_74 = puVar12[2];
  uStack_70 = puVar12[3];
  uStack_6c = *(undefined8 *)(puVar12 + 4);
  puVar12[4] = 0;
  puVar12[5] = 0xf;
  *(undefined *)puVar12 = 0;
  uStack_8 = 7;
  if (0xf < uStack_3c._4_4_) {
    uVar8 = uStack_3c._4_4_ + 1;
    ppppuVar6 = (undefined4 ****)pppuStack_4c;
    if (0xfff < uVar8) {
      ppppuVar6 = (undefined4 ****)pppuStack_4c[-1];
      uVar8 = uStack_3c._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppuStack_4c + (-4 - (int)ppppuVar6))) {
LAB_00c61d59:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar6,uVar8);
  }
  uStack_3c = 0xf00000000;
  pppuStack_4c = (undefined4 ***)((uint)pppuStack_4c & 0xffffff00);
  uStack_8 = 8;
  uVar3 = uStack_8;
  uStack_8 = 8;
  if (0xf < uStack_80) {
    uVar9 = uStack_80 + 1;
    uVar8 = uStack_94;
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(uStack_94 - 4);
      uVar9 = uStack_80 + 0x24;
      if (0x1f < (uStack_94 - uVar8) - 4) {
        uStack_8 = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uStack_84 = 0;
  uStack_80 = 0xf;
  uStack_94 = uStack_94 & 0xffffff00;
  _uStack_8 = CONCAT31(uStack_7,9);
  if (0xf < uStack_a0) {
    uVar9 = uStack_a0 + 1;
    uVar8 = uStack_b4;
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(uStack_b4 - 4);
      uVar9 = uStack_a0 + 0x24;
      if (0x1f < (uStack_b4 - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  uVar8 = (int)puVar11 - iStack_18 >> 2;
  uStack_a4 = 0;
  uStack_a0 = 0xf;
  uStack_b4 = uStack_b4 & 0xffffff00;
  uStack_14 = 0;
  if (uVar8 != 0) {
    do {
      uVar9 = uStack_14;
      uStack_fc = 0;
      piStack_f8 = (int *)0x0;
      uStack_f4 = 0;
      uStack_d4 = 0;
      uStack_8 = 10;
      FUN_00c5d520(*(undefined4 *)(iStack_18 + uStack_14 * 4),&uStack_fc);
      pppuStack_1c = (uint ***)&pppuStack_7c;
      if (0xf < uStack_6c._4_4_) {
        pppuStack_1c = pppuStack_7c;
      }
      uStack_54 = 0;
      uStack_50 = 0;
      if ((uint)uStack_6c < 0x10) {
        ppuStack_64 = *pppuStack_1c;
        ppuStack_60 = (uint **)((uint ****)pppuStack_1c)[1];
        ppuStack_5c = (uint **)((uint ****)pppuStack_1c)[2];
        ppuStack_58 = (uint **)((uint ****)pppuStack_1c)[3];
        uStack_54 = (uint)uStack_6c;
        uStack_50 = 0xf;
      }
      else {
        uVar13 = (uint)uStack_6c | 0xf;
        if (0x7fffffff < uVar13) {
          uVar13 = 0x7fffffff;
        }
        if (uVar13 + 1 < 0x1000) {
          if (uVar13 == 0xffffffff) {
            ppuStack_64 = (uint **)0x0;
          }
          else {
            ppuStack_64 = (uint **)FUN_01674e20();
          }
        }
        else {
          ppuVar7 = (uint **)FUN_01674e20();
          if (ppuVar7 == (uint **)0x0) goto LAB_00c61d59;
          ppuStack_64 = (uint **)((int)ppuVar7 + 0x23U & 0xffffffe0);
          ((uint ***)ppuStack_64)[-1] = ppuVar7;
        }
        FUN_0170c6f0(ppuStack_64,pppuStack_1c,(uint)uStack_6c + 1);
        uStack_54 = (uint)uStack_6c;
        uVar9 = uStack_14;
        uStack_50 = uVar13;
      }
      ppuVar7 = ppuStack_64;
      uStack_8 = 0xb;
      uVar3 = uStack_8;
      uStack_8 = 0xb;
      if (uStack_d4 == 0) {
        uStack_8 = uVar3;
        FUN_0054fda0();
        _uStack_8 = CONCAT31(uStack_7,0xc);
                    /* WARNING: Subroutine does not return */
        FUN_0054e5e0();
      }
      ppuStack_64 = (uint **)((uint)ppuStack_64 & 0xffffff00);
      uStack_54 = 0;
      uStack_50 = 0xf;
      (**(code **)((uStack_d4 & 0xfffffffe) + 4))
                (auStack_cc,ppuVar7,ppuStack_60,ppuStack_5c,ppuStack_58);
      uStack_8 = 0xd;
      if (uStack_d4 != 0) {
        if (((uStack_d4 & 1) == 0) && (*(code **)(uStack_d4 & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(uStack_d4 & 0xfffffffe))(auStack_cc);
        }
        uStack_d4 = 0;
      }
      uStack_8 = 0xe;
      if (uStack_f4 != 0) {
        if (((uStack_f4 & 1) == 0) && (*(code **)(uStack_f4 & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(uStack_f4 & 0xfffffffe))(auStack_ec);
        }
        uStack_f4 = 0;
      }
      _uStack_8 = CONCAT31(uStack_7,9);
      if (piStack_f8 != (int *)0x0) {
        LOCK();
        iVar10 = piStack_f8[2] + -1;
        piStack_f8[2] = iVar10;
        UNLOCK();
        if (iVar10 == 0) {
          (**(code **)(*piStack_f8 + 4))();
        }
      }
      uStack_14 = uVar9 + 1;
    } while (uStack_14 < uVar8);
  }
  uVar8 = uStack_6c._4_4_;
  if (0xf < uStack_6c._4_4_) {
    uVar8 = uStack_6c._4_4_ + 1;
    ppppuVar4 = (uint ****)pppuStack_7c;
    if (0xfff < uVar8) {
      ppppuVar4 = (uint ****)pppuStack_7c[-1];
      uVar8 = uStack_6c._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppuStack_7c + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uVar8 = FUN_01674ea0(ppppuVar4,uVar8);
  }
  if (iStack_18 != 0) {
    uVar8 = (int)puStack_28 - iStack_18 & 0xfffffffc;
    iVar10 = iStack_18;
    if (0xfff < uVar8) {
      iVar10 = *(int *)(iStack_18 + -4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (iStack_18 - iVar10) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uVar8 = FUN_01674ea0(iVar10,uVar8);
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_24 + 2);
    uVar9 = *puVar1;
    uVar8 = *puVar1;
    *puVar1 = uVar9 - 1;
    UNLOCK();
    if (uVar9 - 1 == 0) {
      uVar8 = (**(code **)(*piStack_24 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar9 = *puVar1;
    uVar8 = *puVar1;
    *puVar1 = uVar9 - 1;
    UNLOCK();
    if (uVar9 - 1 == 0) {
      uVar8 = (**(code **)*param_3)();
      LOCK();
      piVar5 = param_3 + 2;
      iVar10 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar10 == 1) {
        uVar8 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 28814 ; VA 0x00c61d90 ; FUN_00c61d90 */

void __fastcall FUN_00c61d90(undefined4 param_1)

{
  char cVar1;
  undefined auStack_10 [12];
  
  cVar1 = FUN_00973950(param_1,0);
  if (cVar1 == '\0') {
    FUN_00c61f30();
    return;
  }
  FUN_00b1a2e0(0);
  FUN_00550130("OnServerInvoke can only be implemented on the server");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 28815 ; VA 0x00c61de0 ; FUN_00c61de0 */

void __thiscall FUN_00c61de0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar3 = (int)param_3;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd921;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008a4210(param_2,param_3);
  FUN_01679490();
  if (iVar3 != 0) {
    iVar3 = FUN_005cf750();
    if (iVar3 != 0) {
      iStack_8 = 0;
      uVar4 = FUN_01675290(DAT_02110da8);
      iStack_8._0_1_ = 1;
      puVar5 = (undefined4 *)FUN_01674e20(0x1c);
      if (puVar5 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)0x0;
      }
      else {
        *puVar5 = 0;
        puVar5[1] = 1;
        puVar5[2] = FUN_00c5e2f0;
        puVar5[3] = _guard_check_icall;
        puVar5[4] = 0;
        puVar5[5] = iVar3 + 0x2a8;
        puVar5[6] = param_1;
      }
      FUN_016797d0(puVar5);
      if (puVar5 != (undefined4 *)0x0) {
        LOCK();
        puVar5[1] = puVar5[1] + 1;
        UNLOCK();
      }
      iStack_8._0_1_ = 2;
      param_3 = puVar5;
      FUN_01675290(uVar4);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      cVar2 = FUN_01679300(&param_3);
      if (cVar2 != '\0') {
        FUN_01679490();
        FUN_016791c0(&param_3);
      }
      if (param_3 != (undefined4 *)0x0) {
        piVar1 = param_3 + 1;
        LOCK();
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          FUN_01674ea0(param_3);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28816 ; VA 0x00c61f30 ; FUN_00c61f30 */

void __fastcall FUN_00c61f30(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint *puVar4;
  undefined4 uVar5;
  uint uVar6;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180ca20;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffc0;
  iStack_24 = 0;
  iStack_28 = 0;
  iStack_20 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != &iStack_28) {
    iStack_28 = *param_1;
    ExceptionList = &pvStack_10;
    *param_1 = 0;
    iStack_24 = param_1[1];
    param_1[1] = 0;
    iStack_20 = param_1[2];
    param_1[2] = 0;
  }
  iVar3 = iStack_24;
  iVar2 = iStack_28;
  uVar6 = 0;
  while( true ) {
    uStack_8 = 0;
    uStack_18 = uVar6;
    if ((uint)(iVar3 - iVar2 >> 5) <= uVar6) {
      FUN_006d2070();
      ExceptionList = pvStack_10;
      return;
    }
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    puVar4 = (uint *)(uVar6 * 0x20 + iVar2);
    uVar1 = *puVar4;
    if (uVar1 == 0) break;
    (**(code **)((uVar1 & 0xfffffffe) + 4))(puVar4 + 2);
    uVar6 = uVar6 + 1;
  }
  uVar5 = FUN_0054fda0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar5);
}



/* FUNCTION 28817 ; VA 0x00c61fc3 ; Catch@00c61fc3 */

undefined * Catch_00c61fc3(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x18) + 4))();
  FUN_0086f2f0(0,"DelayedInvocationQueue::process encountered an error %s",uVar1);
  FUN_01675310("CaughtException",&DAT_018bc9b8);
  return &DAT_00c61ff0;
}



/* FUNCTION 28818 ; VA 0x00c62030 ; FUN_00c62030 */

void __fastcall FUN_00c62030(int **param_1)

{
  int *piVar1;
  int *piVar2;
  uint *puVar3;
  uint uVar4;
  int *piVar5;
  int iVar6;
  undefined4 uVar7;
  int *piVar8;
  int *piStack_3c;
  int *piStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ca40;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb8;
  piStack_2c = (int *)0x0;
  piStack_3c = (int *)0x0;
  piStack_38 = (int *)0x0;
  piStack_34 = (int *)0x0;
  piStack_30 = (int *)0x0;
  ExceptionList = &pvStack_10;
  piVar5 = (int *)FUN_01674e20(8);
  *piVar5 = 0;
  piVar5[1] = 0;
  *piVar5 = (int)&piStack_3c;
  piStack_3c = piVar5;
  if (param_1 != &piStack_3c) {
    piStack_3c = *param_1;
    *param_1 = piVar5;
    if (piVar5 != (int *)0x0) {
      *piVar5 = (int)param_1;
    }
    if (piStack_3c != (int *)0x0) {
      *piStack_3c = (int)&piStack_3c;
    }
    piVar5 = param_1[1];
    param_1[1] = piStack_38;
    piVar8 = param_1[2];
    param_1[2] = piStack_34;
    piVar1 = param_1[3];
    param_1[3] = piStack_30;
    piVar2 = param_1[4];
    param_1[4] = piStack_2c;
    piStack_38 = piVar5;
    piStack_34 = piVar8;
    piStack_30 = piVar1;
    piStack_2c = piVar2;
  }
  piVar5 = (int *)0x0;
  while( true ) {
    uStack_8 = 0;
    piStack_18 = piVar5;
    if (piStack_2c <= piVar5) {
      FUN_00c0a180();
      ExceptionList = pvStack_10;
      return;
    }
    piVar8 = (int *)0x0;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    if ((piStack_3c != (int *)0x0) && ((undefined4 *)*piStack_3c != (undefined4 *)0x0)) {
      piVar8 = *(int **)*piStack_3c;
    }
    if (((piVar8 == (int *)0x0) || ((int *)*piVar8 == (int *)0x0)) ||
       (piVar8 = *(int **)*piVar8, piVar8 == (int *)0x0)) {
      iVar6 = 0;
    }
    else {
      iVar6 = *piVar8;
    }
    puVar3 = *(uint **)(*(int *)(iVar6 + 4) +
                       (*(int *)(iVar6 + 8) - 1U & (int)piStack_30 + (int)piVar5) * 4);
    uVar4 = *puVar3;
    if (uVar4 == 0) break;
    (**(code **)((uVar4 & 0xfffffffe) + 4))(puVar3 + 2);
    piVar5 = (int *)((int)piVar5 + 1);
  }
  uVar7 = FUN_0054fda0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar7);
}



/* FUNCTION 28819 ; VA 0x00c62145 ; Catch@00c62145 */

undefined * Catch_00c62145(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x18) + 4))();
  FUN_0086f2f0(0,"DelayedInvocationXferQueue::process encountered an error %s",uVar1);
  FUN_01675310("CaughtException",&DAT_018bc9b8);
  return &DAT_00c62172;
}



/* FUNCTION 28820 ; VA 0x00c621b0 ; FUN_00c621b0 */

int FUN_00c621b0(undefined *param_1,int *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8348;
  pvStack_10 = ExceptionList;
  if (param_1 != &DAT_02137608) {
    ExceptionList = &pvStack_10;
    iVar5 = FUN_009cba80(param_1,param_2,param_3);
    ExceptionList = pvStack_10;
    return iVar5;
  }
  piVar6 = (int *)*param_2;
  iVar5 = *piVar6;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088cdc0();
  puVar1 = param_3;
  if (iVar5 == iVar3) {
    piVar4 = piVar6 + 2;
    if (piVar6[1] == 0) {
      piVar4 = (int *)0x0;
    }
    piVar6 = (int *)piVar4[1];
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = (int *)piVar4[1];
    }
    uStack_8 = 0;
    cVar2 = FUN_00c60220(*piVar4,param_3);
    if (cVar2 == '\0') {
      iVar5 = FUN_0086f2f0(4,"RemoteEvent::processRemoteEvent: ignore a remote call from %d",*puVar1
                          );
    }
    else {
      FUN_009cba80(&DAT_02137608,param_2,puVar1);
      iVar5 = FUN_00c592f0(&DAT_01efdb34,(int)&param_2 + 3);
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar4 = piVar6 + 1;
      iVar3 = *piVar4;
      iVar5 = *piVar4;
      *piVar4 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar5 = (**(code **)*piVar6)();
        LOCK();
        piVar4 = piVar6 + 2;
        iVar3 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          iVar5 = (**(code **)(*piVar6 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return iVar5;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28821 ; VA 0x00c622c0 ; FUN_00c622c0 */

int __thiscall FUN_00c622c0(undefined4 param_1,undefined *param_2,int *param_3,undefined4 *param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  char cVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  undefined4 *puVar8;
  int iVar9;
  int *piVar10;
  undefined *puVar11;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180ca68;
  pvStack_10 = ExceptionList;
  uStack_14 = param_1;
  if (param_2 == &DAT_02137430) {
    piVar10 = (int *)*param_3;
    iVar9 = *piVar10;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088c8c0();
    if (iVar9 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar6 = piVar10 + 2;
    iVar9 = *param_3;
    if (piVar10[1] == 0) {
      piVar6 = (int *)0x0;
    }
    iVar5 = *(int *)(iVar9 + 0xd0);
    iVar2 = *piVar6;
    iVar7 = FUN_0088cdc0();
    if (iVar5 != iVar7) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    puVar8 = (undefined4 *)(iVar9 + 0xd8);
    if (*(int *)(iVar9 + 0xd4) == 0) {
      puVar8 = (undefined4 *)0x0;
    }
    piVar10 = (int *)puVar8[1];
    if (piVar10 != (int *)0x0) {
      LOCK();
      piVar10[1] = piVar10[1] + 1;
      UNLOCK();
      piVar10 = (int *)puVar8[1];
    }
    uStack_24 = *puVar8;
    iVar9 = *param_3;
    uStack_8 = 0;
    iVar5 = *(int *)(iVar9 + 0x1a0);
    piStack_20 = piVar10;
    uStack_18 = uStack_24;
    iVar7 = FUN_0088cbe0();
    if (iVar5 != iVar7) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    puVar8 = (undefined4 *)(iVar9 + 0x1a8);
    if (*(int *)(iVar9 + 0x1a4) == 0) {
      puVar8 = (undefined4 *)0x0;
    }
    piVar6 = (int *)puVar8[1];
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = (int *)puVar8[1];
    }
    uStack_2c = *puVar8;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    piStack_28 = piVar6;
    uStack_1c = uStack_2c;
    cVar4 = FUN_00c60220();
    uVar3 = uStack_14;
    if (cVar4 == '\0') {
      iVar9 = FUN_0086f2f0();
    }
    else {
      _uStack_38 = CONCAT44(*param_4,uStack_14);
      iStack_30 = iVar2;
      FUN_00585a40(&uStack_38);
      _uStack_38 = CONCAT44(*param_4,uVar3);
      iStack_30 = iVar2;
      cVar4 = FUN_00585a40(&uStack_38);
      if (cVar4 == '\0') {
        puVar11 = &DAT_0196c835;
      }
      else {
        puVar11 = (undefined *)0x0;
      }
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
      }
      if (piVar10 != (int *)0x0) {
        LOCK();
        piVar10[1] = piVar10[1] + 1;
        UNLOCK();
      }
      iVar9 = FUN_00c60870(uStack_18,piVar10,uStack_1c,piVar6,puVar11);
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar1 = piVar6 + 1;
      iVar5 = *piVar1;
      iVar9 = *piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar5 = *piVar1;
        iVar9 = *piVar1;
        *piVar1 = iVar5 + -1;
        UNLOCK();
        if (iVar5 + -1 == 0) {
          iVar9 = (**(code **)(*piVar6 + 4))();
        }
      }
    }
    if (piVar10 != (int *)0x0) {
      LOCK();
      piVar6 = piVar10 + 1;
      iVar5 = *piVar6;
      iVar9 = *piVar6;
      *piVar6 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        iVar9 = (**(code **)*piVar10)();
        LOCK();
        piVar6 = piVar10 + 2;
        iVar5 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          iVar9 = (**(code **)(*piVar10 + 4))();
          ExceptionList = pvStack_10;
          return iVar9;
        }
      }
    }
  }
  else if (param_2 == &DAT_02137470) {
    piVar10 = (int *)*param_3;
    iVar9 = *piVar10;
    ExceptionList = &pvStack_10;
    iVar5 = FUN_0088c8c0();
    if (iVar9 != iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    piVar6 = piVar10 + 2;
    if (piVar10[1] == 0) {
      piVar6 = (int *)0x0;
    }
    iVar9 = *piVar6;
    iVar5 = *param_3;
    iVar2 = *(int *)(iVar5 + 0xd0);
    iVar7 = FUN_0088cbe0();
    if (iVar2 != iVar7) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0();
    }
    puVar8 = (undefined4 *)(iVar5 + 0xd8);
    if (*(int *)(iVar5 + 0xd4) == 0) {
      puVar8 = (undefined4 *)0x0;
    }
    piVar10 = (int *)puVar8[1];
    if (piVar10 != (int *)0x0) {
      LOCK();
      piVar10[1] = piVar10[1] + 1;
      UNLOCK();
      piVar10 = (int *)puVar8[1];
    }
    uVar3 = *puVar8;
    uStack_8 = 2;
    _uStack_38 = CONCAT44(*param_4,param_1);
    iStack_30 = iVar9;
    uStack_2c = uVar3;
    piStack_28 = piVar10;
    FUN_00585a40(&uStack_38);
    _uStack_38 = CONCAT44(*param_4,param_1);
    iStack_30 = iVar9;
    cVar4 = FUN_00585a40(&uStack_38);
    if (cVar4 == '\0') {
      puVar11 = &DAT_0196c845;
    }
    else {
      puVar11 = (undefined *)0x0;
    }
    piVar6 = piVar10 + 1;
    if (piVar10 != (int *)0x0) {
      LOCK();
      *piVar6 = *piVar6 + 1;
      UNLOCK();
    }
    iVar9 = FUN_00c60400(uVar3,piVar10,puVar11);
    if (piVar10 != (int *)0x0) {
      LOCK();
      iVar5 = *piVar6;
      iVar9 = *piVar6;
      *piVar6 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        iVar9 = (**(code **)*piVar10)();
        LOCK();
        piVar6 = piVar10 + 2;
        iVar5 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          iVar9 = (**(code **)(*piVar10 + 4))();
          ExceptionList = pvStack_10;
          return iVar9;
        }
      }
    }
  }
  else {
    ExceptionList = &pvStack_10;
    iVar9 = FUN_009cba80();
  }
  ExceptionList = pvStack_10;
  return iVar9;
}



/* FUNCTION 28822 ; VA 0x00c62700 ; FUN_00c62700 */

undefined4 __thiscall FUN_00c62700(int *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  
  puVar1 = (uint *)param_1[1];
  if ((uint)param_1[3] <= (uint)((int)puVar1 - *param_1 >> 5)) {
    return 0;
  }
  if ((uint *)param_1[2] != puVar1) {
    *puVar1 = 0;
    uVar2 = *param_2;
    if (uVar2 != 0) {
      *puVar1 = uVar2;
      if ((uVar2 & 1) != 0) {
        uVar2 = param_2[3];
        uVar3 = param_2[4];
        uVar4 = param_2[5];
        puVar1[2] = param_2[2];
        puVar1[3] = uVar2;
        puVar1[4] = uVar3;
        puVar1[5] = uVar4;
        *(undefined8 *)(puVar1 + 6) = *(undefined8 *)(param_2 + 6);
        param_1[1] = param_1[1] + 0x20;
        return 1;
      }
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 2,puVar1 + 2,0);
    }
    param_1[1] = param_1[1] + 0x20;
    return 1;
  }
  FUN_00c58850(puVar1,param_2);
  return 1;
}



/* FUNCTION 28823 ; VA 0x00c62790 ; FUN_00c62790 */

undefined4 __thiscall FUN_00c62790(int param_1,uint *param_2)

{
  int iVar1;
  uint *puVar2;
  uint uVar3;
  uint uVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01804218;
  pvStack_10 = ExceptionList;
  if (*(uint *)(param_1 + 0x14) <= *(uint *)(param_1 + 0x10)) {
    return 0;
  }
  uVar7 = *(uint *)(param_1 + 8);
  ExceptionList = &pvStack_10;
  if (uVar7 <= *(uint *)(param_1 + 0x10) + 1) {
    ExceptionList = &pvStack_10;
    FUN_006afce0(1);
    uVar7 = *(uint *)(param_1 + 8);
  }
  uVar7 = uVar7 - 1 & *(uint *)(param_1 + 0xc);
  *(uint *)(param_1 + 0xc) = uVar7;
  uVar7 = *(int *)(param_1 + 8) - 1U & *(int *)(param_1 + 0x10) + uVar7;
  iVar6 = *(int *)(param_1 + 4);
  iVar1 = uVar7 * 4;
  if (*(int *)(iVar6 + uVar7 * 4) == 0) {
    uVar5 = FUN_01674e20(0x40);
    *(undefined4 *)(iVar1 + *(int *)(param_1 + 4)) = uVar5;
    iVar6 = *(int *)(param_1 + 4);
  }
  puVar2 = *(uint **)(iVar1 + iVar6);
  *puVar2 = 0;
  uVar7 = *param_2;
  if (uVar7 != 0) {
    *puVar2 = uVar7;
    if ((uVar7 & 1) == 0) {
      (**(code **)(uVar7 & 0xfffffffe))(param_2 + 2,puVar2 + 2,0);
    }
    else {
      uVar7 = param_2[3];
      uVar3 = param_2[4];
      uVar4 = param_2[5];
      puVar2[2] = param_2[2];
      puVar2[3] = uVar7;
      puVar2[4] = uVar3;
      puVar2[5] = uVar4;
      *(undefined8 *)(puVar2 + 6) = *(undefined8 *)(param_2 + 6);
    }
  }
  puVar2[8] = 0;
  uVar7 = param_2[8];
  uStack_8 = 0;
  if (uVar7 != 0) {
    puVar2[8] = uVar7;
    if ((uVar7 & 1) == 0) {
      (**(code **)(uVar7 & 0xfffffffe))(param_2 + 10,puVar2 + 10,0);
    }
    else {
      uVar7 = param_2[0xb];
      uVar3 = param_2[0xc];
      uVar4 = param_2[0xd];
      puVar2[10] = param_2[10];
      puVar2[0xb] = uVar7;
      puVar2[0xc] = uVar3;
      puVar2[0xd] = uVar4;
      *(undefined8 *)(puVar2 + 0xe) = *(undefined8 *)(param_2 + 0xe);
    }
  }
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 28824 ; VA 0x00c628c0 ; FUN_00c628c0 */

void FUN_00c628c0(void)

{
  FUN_00c63140();
  return;
}



/* FUNCTION 28825 ; VA 0x00c628d0 ; FUN_00c628d0 */

void __thiscall FUN_00c628d0(int *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  code *pcVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint in_stack_00000020;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined4 uStack_1d4;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  uint uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  uint uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180cabc;
  pvStack_10 = ExceptionList;
  puStack_24 = &param_2;
  uStack_8 = 0;
  uStack_20 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_4);
  uStack_8._0_1_ = 1;
  pcVar1 = *(code **)(*param_1 + 8);
  uStack_1dc = FUN_0088c8c0();
  uStack_1d8 = 0;
  uStack_1d4 = param_3;
  uStack_1d8 = FUN_005c9cc0();
  uStack_8._0_1_ = 2;
  uStack_10c = FUN_0088cb40();
  uStack_108 = 0;
  uStack_104 = uStack_3c;
  uStack_100 = uStack_38;
  uStack_fc = uStack_34;
  uStack_f8 = uStack_30;
  uStack_3c = uStack_3c & 0xffffff00;
  uStack_2c = 0;
  uStack_28 = 0xf;
  uStack_108 = FUN_005c9d30();
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1dc,&uStack_3c,param_2);
  uStack_8._0_1_ = 4;
  (*pcVar1)(&DAT_021374f0,&uStack_1c,&puStack_24);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_016f32d1(&uStack_1dc,0xd0,2,FUN_0056e5b0);
  if (0xf < uStack_28) {
    uVar3 = uStack_28 + 1;
    uVar4 = uStack_3c;
    if (0xfff < uVar3) {
      uVar4 = *(uint *)(uStack_3c - 4);
      uVar3 = uStack_28 + 0x24;
      if (0x1f < (uStack_3c - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar3);
  }
  if (0xf < in_stack_00000020) {
    uVar4 = in_stack_00000020 + 1;
    iVar2 = param_4;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(param_4 + -4);
      uVar4 = in_stack_00000020 + 0x24;
      if (0x1f < (param_4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28826 ; VA 0x00c62a80 ; FUN_00c62a80 */

int __thiscall
FUN_00c62a80(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined *puStack_1c;
  undefined4 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180cad8;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)&param_2;
  uStack_18 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  iVar4 = FUN_00c62c50(param_1,param_3,param_4,param_5,&puStack_1c);
  piVar3 = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_5)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 28827 ; VA 0x00c62b30 ; FUN_00c62b30 */

/* WARNING: Removing unreachable block (ram,0x00c62c12) */
/* WARNING: Removing unreachable block (ram,0x00c62c1e) */
/* WARNING: Removing unreachable block (ram,0x00c62c2c) */

undefined4 FUN_00c62b30(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_0180cb19;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_f0 = FUN_0088cbe0();
  uStack_e8 = param_2;
  uStack_ec = 0;
  uStack_e4 = param_3;
  uStack_ec = FUN_00630900();
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,param_1);
  iStack_8._0_1_ = 2;
  (*pcVar1)(uStack_14,&uStack_20,param_4);
  iStack_8._0_1_ = 3;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  uVar2 = FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 28828 ; VA 0x00c62c50 ; FUN_00c62c50 */

/* WARNING: Removing unreachable block (ram,0x00c62d5f) */
/* WARNING: Removing unreachable block (ram,0x00c62d6b) */
/* WARNING: Removing unreachable block (ram,0x00c62d79) */

undefined4
FUN_00c62c50(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_0180cb64;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_1c0 = FUN_0088c8c0();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1bc = FUN_005c9cc0();
  iStack_8._0_1_ = 1;
  uStack_f0 = FUN_0088cbe0();
  uStack_e8 = param_3;
  uStack_ec = 0;
  uStack_e4 = param_4;
  uStack_ec = FUN_00630900();
  iStack_8._0_1_ = 2;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,param_1);
  iStack_8._0_1_ = 3;
  (*pcVar1)(uStack_14,&uStack_20,param_5);
  iStack_8._0_1_ = 4;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  uVar2 = FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 28829 ; VA 0x00c62da0 ; FUN_00c62da0 */

int __thiscall FUN_00c62da0(int param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  undefined uVar4;
  undefined uVar5;
  undefined4 uVar6;
  int iVar7;
  undefined auStack_20 [8];
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar5 = DAT_01efdb10;
  uVar4 = DAT_01efdb0f;
  uVar3 = DAT_01efdb0e;
  puStack_c = &LAB_0180cb80;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uVar6 = FUN_00b138b0(auStack_20,FUN_00c5c550,param_3,param_4,uVar5,uVar4,uVar3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar7 = FUN_00c5a6f0(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x40),
                       *(undefined4 *)(param_1 + 0x44),uVar6);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar7 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar7 = (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar7 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 28830 ; VA 0x00c62e90 ; FUN_00c62e90 */

int __thiscall FUN_00c62e90(int param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  undefined uVar4;
  undefined uVar5;
  undefined uVar6;
  undefined4 uVar7;
  int iVar8;
  undefined auStack_20 [8];
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar6 = DAT_01efdb11;
  uVar5 = DAT_01efdb10;
  uVar4 = DAT_01efdb0f;
  uVar3 = DAT_01efdb0e;
  puStack_c = &LAB_0180cba0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uVar7 = FUN_00b8db90(auStack_20,FUN_00c5c7e0,param_3,param_4,uVar5,uVar4,uVar3,uVar6);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar8 = FUN_00c5a850(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x40),
                       *(undefined4 *)(param_1 + 0x44),uVar7);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar8 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      iVar8 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar8 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    iVar8 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar8 = (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar8 = (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 28831 ; VA 0x00c62f90 ; FUN_00c62f90 */

void __thiscall FUN_00c62f90(int param_1,int param_2)

{
  uint auStack_30 [2];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180cbb8;
  pvStack_10 = ExceptionList;
  if (param_2 != param_1) {
    auStack_30[0] = 0;
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_005880d0(param_1);
    FUN_005880d0(param_2);
    FUN_005880d0(auStack_30);
    uStack_8 = 1;
    if (((auStack_30[0] != 0) && ((auStack_30[0] & 1) == 0)) &&
       (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_30[0] & 0xfffffffe))(auStack_28,auStack_28,2);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28832 ; VA 0x00c63020 ; FUN_00c63020 */

void __thiscall FUN_00c63020(int param_1,int param_2)

{
  uint auStack_30 [2];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180cbd8;
  pvStack_10 = ExceptionList;
  if (param_2 != param_1) {
    auStack_30[0] = 0;
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_005880d0(param_1);
    FUN_005880d0(param_2);
    FUN_005880d0(auStack_30);
    uStack_8 = 1;
    if (((auStack_30[0] != 0) && ((auStack_30[0] & 1) == 0)) &&
       (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_30[0] & 0xfffffffe))(auStack_28,auStack_28,2);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28833 ; VA 0x00c630b0 ; FUN_00c630b0 */

void __thiscall FUN_00c630b0(int param_1,int param_2)

{
  uint auStack_30 [2];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180cbf8;
  pvStack_10 = ExceptionList;
  if (param_2 != param_1) {
    auStack_30[0] = 0;
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_005880d0(param_1);
    FUN_005880d0(param_2);
    FUN_005880d0(auStack_30);
    uStack_8 = 1;
    if (((auStack_30[0] != 0) && ((auStack_30[0] & 1) == 0)) &&
       (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_30[0] & 0xfffffffe))(auStack_28,auStack_28,2);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28834 ; VA 0x00c63140 ; FUN_00c63140 */

/* WARNING: Removing unreachable block (ram,0x00c631df) */

undefined4 __fastcall FUN_00c63140(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180cc28;
  pvStack_10 = ExceptionList;
  if (param_1[4] != 0) {
    puVar3 = (undefined4 *)*param_1;
    uStack_8 = 0;
    if (puVar3 != (undefined4 *)0x0) {
      puVar3 = (undefined4 *)*puVar3;
    }
    iVar2 = *(int *)(puVar3[1] + (puVar3[2] - 1 & param_1[3]) * 4);
    ExceptionList = &pvStack_10;
    FUN_005880d0(iVar2);
    uStack_8._0_1_ = 1;
    FUN_005880d0(iVar2 + 0x20);
    uStack_8._0_1_ = 2;
    FUN_008c3510();
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    else {
      param_1[3] = param_1[3] + 1;
    }
    uVar4 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar4);
  }
  return 0;
}



/* FUNCTION 28835 ; VA 0x00c63210 ; Catch@00c63210 */

undefined4 Catch_00c63210(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x14) + 4))();
  FUN_0086f2f0(0,"DelayedInvocationXferQueue::transferEvent encountered an error %s",uVar1);
  FUN_01675310("CaughtException",&DAT_018bc9b8);
  return 0xc6323d;
}



/* FUNCTION 28836 ; VA 0x00c63270 ; FUN_00c63270 */

int * __thiscall
FUN_00c63270(int *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d64cb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c63380();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::VehicleSeat,float>::
              GetSetImpl<float_(__thiscall_RBX::VehicleSeat::*)(void)const_,void_(__thiscall_RBX::VehicleSeat::*)(float)>
              ::vftable;
    *(undefined8 *)(puVar3 + 2) = param_4;
    puVar3[4] = param_5;
    *(undefined8 *)(puVar3 + 6) = param_6;
    puVar3[8] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::VehicleSeat,float>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::VehicleSeat,float>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28837 ; VA 0x00c63380 ; FUN_00c63380 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c63380(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180cc60;
  pvStack_10 = ExceptionList;
  if (DAT_01efdf80 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efe198) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efe198);
      if (DAT_01efe198 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00aff8c0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"VehicleSeat",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01efe190 = RBX::Creator<class_RBX::VehicleSeat>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efdf88,&DAT_01efe190);
        FUN_016f3654(FUN_01895c30);
        FUN_016f37bf(&DAT_01efe198);
      }
    }
    DAT_01efdf80 = &DAT_01efdf88;
  }
  ExceptionList = pvStack_10;
  return DAT_01efdf80;
}



/* FUNCTION 28838 ; VA 0x00c63480 ; FUN_00c63480 */

int __thiscall FUN_00c63480(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180cc70;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::VehicleSeat*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28839 ; VA 0x00c63552 ; Catch_All@00c63552 */

void Catch_All_00c63552(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28840 ; VA 0x00c63570 ; FUN_00c63570 */

undefined FUN_00c63570(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      undefined4 param_5,int *param_6,undefined4 *param_7)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined uVar5;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int *piStack_8;
  
  uStack_1c = param_1;
  uStack_18 = param_2;
  uStack_14 = param_3;
  uStack_10 = param_4;
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  uStack_c = param_5;
  piStack_8 = param_6;
  cVar4 = FUN_00585a40(&uStack_1c);
  piVar2 = piStack_8;
  if (cVar4 == '\0') {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      piStack_8[1] = piStack_8[1] + 1;
      UNLOCK();
    }
    *param_7 = uStack_1c;
    param_7[1] = uStack_18;
    param_7[2] = uStack_14;
    param_7[3] = uStack_10;
    param_7[4] = 0;
    param_7[5] = 0;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      piStack_8[1] = piStack_8[1] + 1;
      UNLOCK();
    }
    param_7[4] = uStack_c;
    param_7[5] = piStack_8;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_8;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar5 = 1;
  }
  else {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar5 = 0;
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar3 = param_6[1] + -1;
    param_6[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar2 = param_6 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  return uVar5;
}



/* FUNCTION 28841 ; VA 0x00c63690 ; FUN_00c63690 */

undefined4 *
FUN_00c63690(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_24;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
    piVar1 = param_5 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  piVar1 = param_5 + 1;
  uStack_30 = (undefined4)param_2;
  uStack_2c = (undefined4)((ulonglong)param_2 >> 0x20);
  *param_1 = uStack_30;
  param_1[1] = uStack_2c;
  param_1[2] = param_3;
  param_1[3] = uStack_24;
  param_1[4] = 0;
  param_1[5] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[4] = param_4;
  param_1[5] = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
      return param_1;
    }
  }
  return param_1;
}



/* FUNCTION 28842 ; VA 0x00c637b0 ; FUN_00c637b0 */

undefined4 * FUN_00c637b0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180ccb3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c63380();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x268);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c63af0(1);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c63480(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28843 ; VA 0x00c63880 ; FUN_00c63880 */

void * __thiscall FUN_00c63880(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  code *pcVar6;
  void *pvVar7;
  int *piVar8;
  int *piVar9;
  undefined4 *puVar10;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a4510;
  puVar10 = *(undefined4 **)(param_1 + 0x2c);
  pvVar7 = ExceptionList;
  if (puVar10 != (undefined4 *)0x0) {
    piVar8 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar8 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar8[1] = piVar8[1] + 1;
      UNLOCK();
      piVar8 = *(int **)(param_1 + 0x30);
      puVar10 = *(undefined4 **)(param_1 + 0x2c);
    }
    puVar3 = (undefined4 *)puVar10[1];
    puVar10 = (undefined4 *)*puVar10;
    iStack_8 = 0;
    pvVar7 = pvStack_10;
    for (; puVar10 != puVar3; puVar10 = puVar10 + 2) {
      piVar9 = (int *)puVar10[1];
      uVar4 = param_2[5];
      if (piVar9 != (int *)0x0) {
        LOCK();
        piVar9[1] = piVar9[1] + 1;
        UNLOCK();
        piVar9 = (int *)puVar10[1];
      }
      uVar5 = *puVar10;
      iStack_8._1_3_ = (uint3)((uint)iStack_8 >> 8);
      iStack_8._0_1_ = 1;
      pcVar6 = (code *)*param_2;
      if (piVar9 != (int *)0x0) {
        LOCK();
        piVar9[1] = piVar9[1] + 1;
        UNLOCK();
      }
      pvVar7 = (void *)(*pcVar6)(uVar5,piVar9,uVar4);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (piVar9 != (int *)0x0) {
        piVar1 = piVar9 + 1;
        LOCK();
        iVar2 = *piVar1;
        pvVar7 = (void *)*piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          (**(code **)*piVar9)();
          LOCK();
          piVar1 = piVar9 + 2;
          iVar2 = *piVar1;
          pvVar7 = (void *)*piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            pvVar7 = (void *)(**(code **)(*piVar9 + 4))();
          }
        }
      }
    }
    if (piVar8 != (int *)0x0) {
      LOCK();
      piVar9 = piVar8 + 1;
      iVar2 = *piVar9;
      pvVar7 = (void *)*piVar9;
      *piVar9 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar7 = (void *)(**(code **)*piVar8)();
        LOCK();
        piVar9 = piVar8 + 2;
        iVar2 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar7 = (void *)(**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar7;
}



/* FUNCTION 28844 ; VA 0x00c639d0 ; FUN_00c639d0 */

void FUN_00c639d0(code *param_1,undefined4 param_2,int param_3,int param_4)

{
  int iVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  
  if ((param_4 == 0) ||
     (((param_4 == 1 && (*(int *)(param_3 + 0x1b0) != 0)) &&
      (iVar3 = (**(code **)(**(int **)(param_3 + 0x1ac) + 8))(), iVar3 != 10)))) {
    (*param_1)(param_3,param_2);
  }
  iVar3 = 0;
  if (0 < *(int *)(param_3 + 0x14)) {
    do {
      iVar1 = *(int *)(*(int *)(param_3 + 0x10) + iVar3 * 4);
      uVar4 = -(uint)(iVar1 != 0) & iVar1 - 8U;
      cVar2 = FUN_00ca1a80(uVar4);
      if (cVar2 == '\0') {
        FUN_00c639d0(param_1,param_2,uVar4,param_4);
      }
      iVar3 = iVar3 + 1;
    } while (iVar3 < *(int *)(param_3 + 0x14));
  }
  return;
}



/* FUNCTION 28845 ; VA 0x00c63a50 ; FUN_00c63a50 */

void FUN_00c63a50(code *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,int param_7,int param_8)

{
  int iVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  
  if (param_8 != 0) {
    if ((param_8 != 1) || (*(int *)(param_7 + 0x1b0) == 0)) goto LAB_00c63a9a;
    iVar3 = (**(code **)(**(int **)(param_7 + 0x1ac) + 8))();
    if (iVar3 == 10) goto LAB_00c63a9a;
  }
  (*param_1)(param_7);
LAB_00c63a9a:
  iVar3 = 0;
  if (0 < *(int *)(param_7 + 0x14)) {
    do {
      iVar1 = *(int *)(*(int *)(param_7 + 0x10) + iVar3 * 4);
      uVar4 = -(uint)(iVar1 != 0) & iVar1 - 8U;
      cVar2 = FUN_00ca1a80(uVar4);
      if (cVar2 == '\0') {
        FUN_00c63a50(param_1,param_2,param_3,param_4,param_5,param_6,uVar4,param_8);
      }
      iVar3 = iVar3 + 1;
    } while (iVar3 < *(int *)(param_7 + 0x14));
  }
  return;
}



/* FUNCTION 28846 ; VA 0x00c63af0 ; FUN_00c63af0 */

undefined4 * __thiscall FUN_00c63af0(undefined4 *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  double *pdVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  undefined4 *puVar8;
  bool bVar9;
  undefined4 uStack_4c;
  uint auStack_48 [2];
  code *pcStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  uint uStack_34;
  undefined auStack_30 [4];
  undefined4 *puStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180cdbf;
  pvStack_10 = ExceptionList;
  bVar9 = param_2 != (int *)0x0;
  ExceptionList = &pvStack_10;
  if (bVar9) {
    ExceptionList = &pvStack_10;
    param_1[0x15] = &DAT_0196d1e0;
    param_1[0x26] = &DAT_0196d1e8;
    param_1[0x99] = RBX::IHasLocation::vftable;
    uStack_8 = 0;
  }
  uStack_14 = (uint)bVar9;
  uStack_18 = (uint)bVar9;
  uStack_3c = 0x40800000;
  uStack_38 = 0x3f99999a;
  uStack_34 = 0x40000000;
  puStack_1c = param_1;
  FUN_00b00ef0(&uStack_3c,0);
  *param_1 = RBX::ActionStation<class_RBX::PartInstance>::vftable;
  param_1[0x16] = RBX::ActionStation<class_RBX::PartInstance>::vftable;
  param_1[0x1e] = RBX::ActionStation<class_RBX::PartInstance>::vftable;
  param_1[0x25] = RBX::ActionStation<class_RBX::PartInstance>::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::ActionStation<class_RBX::PartInstance>::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xb8;
  pdVar4 = (double *)FUN_01682800(auStack_30);
  *(double *)(param_1 + 0x3e) = *pdVar4 - DAT_018cf100;
  FUN_01682800(param_1 + 0x40);
  FUN_00c18fe0(3);
  *param_1 = RBX::SeatImpl<class_RBX::PartInstance>::vftable;
  param_1[0x16] = RBX::SeatImpl<class_RBX::PartInstance>::vftable;
  param_1[0x1e] = RBX::SeatImpl<class_RBX::PartInstance>::vftable;
  param_1[0x25] = RBX::SeatImpl<class_RBX::PartInstance>::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::SeatImpl<class_RBX::PartInstance>::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xd0;
  param_1[0x42] = 0;
  param_1[0x43] = 0;
  param_1[0x44] = 0;
  param_1[0x45] = 0;
  *(undefined *)(param_1 + 0x46) = 0;
  *param_1 = RBX::
             DescribedCreatable<class_RBX::VehicleSeat,class_RBX::SeatImpl<class_RBX::PartInstance>_>
             ::vftable;
  param_1[0x16] =
       RBX::DescribedCreatable<class_RBX::VehicleSeat,class_RBX::SeatImpl<class_RBX::PartInstance>_>
       ::vftable;
  param_1[0x1e] =
       RBX::DescribedCreatable<class_RBX::VehicleSeat,class_RBX::SeatImpl<class_RBX::PartInstance>_>
       ::vftable;
  param_1[0x25] =
       RBX::DescribedCreatable<class_RBX::VehicleSeat,class_RBX::SeatImpl<class_RBX::PartInstance>_>
       ::vftable;
  uStack_8 = 3;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::DescribedCreatable<class_RBX::VehicleSeat,class_RBX::SeatImpl<class_RBX::PartInstance>_>
       ::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xd0;
  uVar5 = FUN_00c63380();
  param_1[3] = uVar5;
  uStack_8 = 4;
  FUN_00ca27c0();
  param_1[0x72] = RBX::Connector::vftable;
  param_1[0x73] = 0xffffffff;
  param_1[0x74] = 0xffffffff;
  param_1[0x75] = 0xffffffff;
  param_1[0x76] = 0xffffffff;
  param_1[0x77] = 0xffffffff;
  param_1[0x78] = 0xffffffff;
  param_1[0x48] = RBX::KernelJoint::vftable;
  param_1[0x4a] = RBX::KernelJoint::vftable;
  param_1[0x72] = RBX::KernelJoint::vftable;
  uStack_8._0_1_ = 5;
  *(undefined *)(param_1 + 0x79) = 0;
  param_1[0x7a] = 0;
  FUN_016f4053(param_1 + 0x7b,4,2,FUN_00610ca0,FUN_005f60a0);
  *param_1 = RBX::VehicleSeat::vftable;
  param_1[0x16] = RBX::VehicleSeat::vftable;
  param_1[0x1e] = RBX::VehicleSeat::vftable;
  param_1[0x25] = RBX::VehicleSeat::vftable;
  param_1[0x48] = RBX::VehicleSeat::vftable;
  param_1[0x4a] = RBX::VehicleSeat::vftable;
  param_1[0x72] = RBX::VehicleSeat::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) = RBX::VehicleSeat::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0x210
  ;
  param_1[0x7d] = 0x41c80000;
  param_1[0x7e] = 0x3f800000;
  param_1[0x7f] = 0x41200000;
  *(undefined *)(param_1 + 0x80) = 1;
  param_1[0x81] = 0;
  param_1[0x82] = 0;
  param_1[0x83] = 0;
  param_1[0x84] = 0;
  param_1[0x85] = 0;
  param_1[0x87] = 0;
  param_1[0x88] = 0;
  param_1[0x86] = 0;
  param_1[0x8a] = 0;
  param_1[0x8b] = 0;
  param_1[0x89] = 0;
  param_1[0x8d] = 0;
  param_1[0x8e] = 0;
  param_1[0x8c] = 0;
  param_1[0x90] = 0;
  param_1[0x91] = 0;
  param_1[0x8f] = 0;
  param_1[0x92] = 0;
  param_1[0x93] = 0;
  param_1[0x94] = 0;
  param_1[0x95] = 0;
  puStack_20 = param_1 + 0x96;
  *puStack_20 = 0;
  puStack_24 = param_1 + 0x97;
  *puStack_24 = 0;
  uStack_8._0_1_ = 0xd;
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  FUN_005542c0("VehicleSeat",0xb);
  uStack_8._0_1_ = 0xe;
  FUN_00b0dd50(auStack_48);
  FUN_00c18fe0(3);
  uStack_8._0_1_ = 0xd;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xd;
  if (0xf < uStack_34) {
    uVar7 = uStack_34 + 1;
    uVar6 = auStack_48[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_48[0] - 4);
      uVar7 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar6) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  pcStack_40 = FUN_00c65070;
  uStack_3c = 0;
  uStack_38 = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  uVar5 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0x10;
  uStack_28 = uVar5;
  puStack_2c = (undefined4 *)FUN_01674e20(0x30);
  if (puStack_2c == (undefined4 *)0x0) {
    puVar8 = (undefined4 *)0x0;
  }
  else {
    *puStack_2c = 0;
    puStack_2c[1] = 1;
    puStack_2c[2] = FUN_00c65540;
    puStack_2c[3] = _guard_check_icall;
    puStack_2c[4] = 0;
    puStack_2c[6] = pcStack_40;
    puStack_2c[7] = uStack_3c;
    puStack_2c[8] = uStack_38;
    puStack_2c[9] = uStack_34;
    puStack_2c[5] = param_1 + 0x94;
    *(ulonglong *)(puStack_2c + 10) = CONCAT44(uStack_4c,param_1);
    puVar8 = puStack_2c;
  }
  FUN_016797d0(puVar8);
  if (puVar8 != (undefined4 *)0x0) {
    LOCK();
    puVar8[1] = puVar8[1] + 1;
    UNLOCK();
  }
  uStack_18 = uStack_14 | 8;
  uStack_8 = 0x11;
  uStack_14 = uStack_18;
  FUN_01675290(uVar5);
  uStack_14 = uStack_14 & 0xfffffff7;
  uStack_8 = 0xd;
  uStack_18 = uStack_14 | 4;
  if (puVar8 != (undefined4 *)0x0) {
    piVar1 = puVar8 + 1;
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(puVar8);
    }
  }
  puVar8 = puStack_1c;
  pcStack_40 = FUN_00c65670;
  uStack_3c = 0;
  uStack_38 = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
  uVar5 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0x13;
  puStack_2c = (undefined4 *)FUN_01674e20(0x30);
  if (puStack_2c == (undefined4 *)0x0) {
    puVar8 = (undefined4 *)0x0;
  }
  else {
    *puStack_2c = 0;
    puStack_2c[1] = 1;
    puStack_2c[2] = FUN_00c65510;
    puStack_2c[3] = _guard_check_icall;
    puStack_2c[4] = 0;
    puStack_2c[6] = pcStack_40;
    puStack_2c[7] = uStack_3c;
    puStack_2c[8] = uStack_38;
    puStack_2c[9] = uStack_34;
    puStack_2c[5] = puStack_20;
    *(ulonglong *)(puStack_2c + 10) = CONCAT44(uStack_4c,puVar8);
    puVar8 = puStack_2c;
  }
  FUN_016797d0(puVar8);
  if (puVar8 == (undefined4 *)0x0) {
    param_2 = (int *)&DAT_00000004;
  }
  else {
    param_2 = puVar8 + 1;
    LOCK();
    *param_2 = *param_2 + 1;
    UNLOCK();
  }
  uStack_18 = uStack_14 | 0x24;
  uStack_8 = 0x14;
  puStack_2c = puVar8;
  FUN_01675290(uVar5);
  if (puVar8 != (undefined4 *)0x0) {
    LOCK();
    iVar2 = *param_2;
    *param_2 = *param_2 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(puVar8);
    }
  }
  ExceptionList = pvStack_10;
  return puStack_1c;
}



/* FUNCTION 28847 ; VA 0x00c64140 ; FUN_00c64140 */

void __fastcall FUN_00c64140(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::VehicleSeat>::vftable;
  uVar1 = FUN_00c63380(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28848 ; VA 0x00c64180 ; thunk_FUN_00c64190 */

void __fastcall thunk_FUN_00c64190(undefined4 *param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  piVar2 = (int *)param_1[0x45];
  ExceptionList = &pvStack_10;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    ExceptionList = &pvStack_10;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = param_1[0x43];
  if (iVar3 != 0) {
    piVar2 = (int *)(iVar3 + 4);
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar3 = param_1[0x42];
  if (iVar3 != 0) {
    piVar2 = (int *)(iVar3 + 4);
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  *param_1 = RBX::ActionStation<class_RBX::PartInstance>::vftable;
  param_1[0x16] = RBX::ActionStation<class_RBX::PartInstance>::vftable;
  param_1[0x1e] = RBX::ActionStation<class_RBX::PartInstance>::vftable;
  param_1[0x25] = RBX::ActionStation<class_RBX::PartInstance>::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::ActionStation<class_RBX::PartInstance>::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xb8;
  FUN_00b013e0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28849 ; VA 0x00c64190 ; FUN_00c64190 */

void __fastcall FUN_00c64190(undefined4 *param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  piVar2 = (int *)param_1[0x45];
  ExceptionList = &pvStack_10;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    ExceptionList = &pvStack_10;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = param_1[0x43];
  if (iVar3 != 0) {
    piVar2 = (int *)(iVar3 + 4);
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar3 = param_1[0x42];
  if (iVar3 != 0) {
    piVar2 = (int *)(iVar3 + 4);
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  *param_1 = RBX::ActionStation<class_RBX::PartInstance>::vftable;
  param_1[0x16] = RBX::ActionStation<class_RBX::PartInstance>::vftable;
  param_1[0x1e] = RBX::ActionStation<class_RBX::PartInstance>::vftable;
  param_1[0x25] = RBX::ActionStation<class_RBX::PartInstance>::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::ActionStation<class_RBX::PartInstance>::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xb8;
  FUN_00b013e0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28850 ; VA 0x00c6429d ; FUN_00c6429d */

void FUN_00c6429d(void)

{
  FUN_00c642f0();
  return;
}



/* FUNCTION 28851 ; VA 0x00c642ab ; FUN_00c642ab */

void FUN_00c642ab(void)

{
  FUN_00c64360();
  return;
}



/* FUNCTION 28852 ; VA 0x00c642b9 ; FUN_00c642b9 */

void FUN_00c642b9(void)

{
  FUN_00c643f0();
  return;
}



/* FUNCTION 28853 ; VA 0x00c642c7 ; FUN_00c642c7 */

void FUN_00c642c7(void)

{
  FUN_00c643f0();
  return;
}



/* FUNCTION 28854 ; VA 0x00c642d2 ; FUN_00c642d2 */

void FUN_00c642d2(void)

{
  FUN_00c643f0();
  return;
}



/* FUNCTION 28855 ; VA 0x00c642dd ; FUN_00c642dd */

void FUN_00c642dd(void)

{
  FUN_00c643f0();
  return;
}



/* FUNCTION 28856 ; VA 0x00c642f0 ; FUN_00c642f0 */

undefined4 * __thiscall FUN_00c642f0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::ActionStation<class_RBX::PartInstance>::vftable;
  param_1[0x16] = RBX::ActionStation<class_RBX::PartInstance>::vftable;
  param_1[0x1e] = RBX::ActionStation<class_RBX::PartInstance>::vftable;
  param_1[0x25] = RBX::ActionStation<class_RBX::PartInstance>::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::ActionStation<class_RBX::PartInstance>::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xb8;
  FUN_00b013e0();
  param_1[0x43] = RBX::IHasLocation::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x110);
  }
  return param_1;
}



/* FUNCTION 28857 ; VA 0x00c64360 ; FUN_00c64360 */

undefined4 __thiscall FUN_00c64360(undefined4 param_1,byte param_2)

{
  FUN_00c64190();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x128);
  }
  return param_1;
}



/* FUNCTION 28858 ; VA 0x00c64390 ; FUN_00c64390 */

undefined4 * __thiscall FUN_00c64390(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Humanoid*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 28859 ; VA 0x00c643c0 ; FUN_00c643c0 */

undefined4 * __thiscall FUN_00c643c0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Humanoid*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 28860 ; VA 0x00c643f0 ; FUN_00c643f0 */

undefined4 * __thiscall FUN_00c643f0(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a950;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::VehicleSeat::vftable;
  param_1[0x16] = RBX::VehicleSeat::vftable;
  param_1[0x1e] = RBX::VehicleSeat::vftable;
  param_1[0x25] = RBX::VehicleSeat::vftable;
  param_1[0x48] = RBX::VehicleSeat::vftable;
  param_1[0x4a] = RBX::VehicleSeat::vftable;
  param_1[0x72] = RBX::VehicleSeat::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) = RBX::VehicleSeat::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0x210
  ;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  piVar1 = (int *)param_1[0x93];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  uStack_8 = 0;
  FUN_01674ea0(param_1[0x8f]);
  param_1[0x8f] = 0;
  param_1[0x90] = 0;
  param_1[0x91] = 0;
  uStack_8 = 1;
  FUN_01674ea0(param_1[0x8c]);
  param_1[0x8c] = 0;
  param_1[0x8d] = 0;
  param_1[0x8e] = 0;
  uStack_8 = 2;
  FUN_01674ea0(param_1[0x89]);
  param_1[0x89] = 0;
  param_1[0x8a] = 0;
  param_1[0x8b] = 0;
  uStack_8 = 3;
  FUN_01674ea0(param_1[0x86]);
  param_1[0x86] = 0;
  param_1[0x87] = 0;
  param_1[0x88] = 0;
  uStack_8 = 4;
  FUN_016f32d1(param_1 + 0x7b,4,2,FUN_005f60a0);
  param_1[0x48] = RBX::KernelJoint::vftable;
  param_1[0x4a] = RBX::KernelJoint::vftable;
  param_1[0x72] = RBX::Connector::vftable;
  FUN_00ca2b60();
  FUN_00c64190();
  param_1[0x99] = RBX::IHasLocation::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x268);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28861 ; VA 0x00c645f0 ; FUN_00c645f0 */

void __thiscall FUN_00c645f0(int param_1,float *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0x20) + 0x2c);
  if (iVar1 != 0) {
    FUN_00f9f070();
    *(float *)(iVar1 + 0x170) = *param_2 + *(float *)(iVar1 + 0x170);
    *(float *)(iVar1 + 0x174) = param_2[1] + *(float *)(iVar1 + 0x174);
    *(float *)(iVar1 + 0x178) = param_2[2] + *(float *)(iVar1 + 0x178);
  }
  return;
}



/* FUNCTION 28862 ; VA 0x00c64650 ; FUN_00c64650 */

void __thiscall FUN_00c64650(int param_1,float *param_2)

{
  FUN_00f9f070();
  *(float *)(param_1 + 0x170) = *(float *)(param_1 + 0x170) + *param_2;
  *(float *)(param_1 + 0x174) = param_2[1] + *(float *)(param_1 + 0x174);
  *(float *)(param_1 + 0x178) = param_2[2] + *(float *)(param_1 + 0x178);
  return;
}



/* FUNCTION 28863 ; VA 0x00c646b0 ; FUN_00c646b0 */

void __thiscall FUN_00c646b0(int *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  
  puVar2 = param_2;
  iVar1 = param_1[1];
  if (iVar1 < param_1[2]) {
    *(undefined4 *)(*param_1 + iVar1 * 4) = *param_2;
    param_1[1] = param_1[1] + 1;
    return;
  }
  if (((undefined4 *)*param_1 <= param_2) && (param_2 < (undefined4 *)*param_1 + iVar1)) {
    param_2 = (undefined4 *)*param_2;
    FUN_00c646b0(&param_2);
    return;
  }
  FUN_00c66b70(iVar1 + 1,0);
  *(undefined4 *)(*param_1 + -4 + param_1[1] * 4) = *puVar2;
  return;
}



/* FUNCTION 28864 ; VA 0x00c64720 ; FUN_00c64720 */

void __thiscall FUN_00c64720(int *param_1,undefined *param_2)

{
  int iVar1;
  undefined *puVar2;
  
  puVar2 = param_2;
  iVar1 = param_1[1];
  if (iVar1 < param_1[2]) {
    *(undefined *)(iVar1 + *param_1) = *param_2;
    param_1[1] = param_1[1] + 1;
    return;
  }
  if (((undefined *)*param_1 <= param_2) && (param_2 < (undefined *)*param_1 + iVar1)) {
    param_2 = (undefined *)CONCAT13(*param_2,param_2._0_3_);
    FUN_00c64720((int)&param_2 + 3);
    return;
  }
  FUN_00c66c30(iVar1 + 1,0);
  *(undefined *)(param_1[1] + -1 + *param_1) = *puVar2;
  return;
}



/* FUNCTION 28865 ; VA 0x00c64790 ; FUN_00c64790 */

void FUN_00c64790(void)

{
  FUN_00c674e0();
  return;
}



/* FUNCTION 28866 ; VA 0x00c647a0 ; FUN_00c647a0 */

undefined4 * __thiscall
FUN_00c647a0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c8141;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar3 = param_5[1] + -1;
      param_5[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar3 = *(int *)(*(int *)(param_3 + 0x54) + *(int *)(param_1 + 0x3c));
  iVar2 = *(int *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00922c30;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = iVar3 + 0x54 + iVar2 + param_3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar3 = param_5[2] + -1;
      param_5[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar3 = param_5[1] + -1;
    param_5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28867 ; VA 0x00c64960 ; FUN_00c64960 */

undefined4 * FUN_00c64960(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c637b0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28868 ; VA 0x00c649d0 ; FUN_00c649d0 */

void FUN_00c649d0(undefined4 param_1)

{
  FUN_00c64bd0(param_1,0);
  return;
}



/* FUNCTION 28869 ; VA 0x00c649f0 ; FUN_00c649f0 */

void __thiscall FUN_00c649f0(int *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  code *pcVar3;
  int *piVar4;
  char cVar5;
  int iVar6;
  double *pdVar7;
  undefined4 *puVar8;
  int *piVar9;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined auStack_40 [8];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180cec9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  iVar6 = FUN_0097ee20(param_2);
  if (iVar6 == 1) {
    cVar5 = FUN_00c65a20(param_2);
    if (cVar5 != '\0') {
      pdVar7 = (double *)FUN_01682800(auStack_40);
      if ((double)DAT_01d68a54 < *pdVar7 - *(double *)(param_1 + 0x40)) {
        puVar8 = (undefined4 *)FUN_0060dcd0(auStack_40,param_2);
        uVar1 = *puVar8;
        uVar2 = puVar8[1];
        *puVar8 = 0;
        puVar8[1] = 0;
        uStack_30 = 0;
        uStack_2c = 0;
        uStack_38 = 0;
        uStack_34 = 0;
        uStack_8._0_1_ = 2;
        uStack_8._1_3_ = 0;
        pcVar3 = *(code **)(*piStack_14 + 8);
        uStack_1c = uVar1;
        uStack_18 = uVar2;
        uStack_110 = FUN_0088cdc0();
        uStack_10c = 0;
        uStack_1c = 0;
        uStack_18 = 0;
        uStack_108 = uVar1;
        uStack_104 = uVar2;
        uStack_10c = FUN_006309e0();
        uStack_8._0_1_ = 3;
        uStack_28 = 0;
        uStack_24 = 0;
        uStack_20 = 0;
        FUN_00687980(&uStack_110,auStack_40,pcVar3);
        piVar4 = piStack_14;
        uStack_8._0_1_ = 4;
        (*pcVar3)(&DAT_021379f0,&uStack_28,&uStack_30);
        uStack_8._0_1_ = 5;
        FUN_00577b20();
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_016f32d1(&uStack_110,0xd0,1,FUN_0056e5b0);
        uStack_8 = 0xffffffff;
        FUN_00550b30();
        piVar9 = (int *)FUN_01682800(&uStack_38);
        piVar4[0x40] = *piVar9;
        piVar4[0x41] = piVar9[1];
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  else {
    FUN_00c64bd0(param_2,0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28870 ; VA 0x00c64bd0 ; FUN_00c64bd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00c64bd0(undefined4 param_1,float param_2)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_4c [12];
  undefined auStack_40 [4];
  undefined4 uStack_3c;
  undefined *puStack_38;
  float fStack_34;
  int *apiStack_30 [2];
  undefined auStack_28 [12];
  undefined4 uStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = (int)param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180cf10;
  pvStack_10 = ExceptionList;
  if (((param_2 != 0.0) && (ExceptionList = &pvStack_10, iVar2 = FUN_009b7250(), iVar2 != 0)) &&
     (*(char *)(iVar4 + 0x21f) < '\x01')) {
    FUN_009b7250();
    iVar2 = FUN_00c155c0();
    if (iVar2 != 0) {
      FUN_00ca1550();
      iVar2 = FUN_00b08320();
      fStack_34 = *(float *)(iVar2 + 4) * DAT_018ce2f4;
      FUN_0060efa0();
      puStack_38 = &DAT_bf800000;
      uStack_1c = 0;
      puStack_18 = &DAT_bf800000;
      uStack_14 = 0;
      FUN_01163c80(&uStack_1c,0,&DAT_bf800000);
      puStack_38 = (undefined *)0x0;
      FUN_0060efa0();
      puStack_38 = &DAT_bf800000;
      uStack_1c = 0;
      puStack_18 = &DAT_bf800000;
      uStack_14 = 0;
      FUN_01163c80(&uStack_1c,0,&DAT_bf800000);
      param_2 = 0.0;
      if (*(int *)(iVar4 + 0x228) != 0) {
        puStack_18 = (undefined *)0x0;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        FUN_005542c0();
        uStack_8 = 0;
        uVar3 = FUN_008a1240(auStack_28);
        iVar4 = FUN_00836510(uVar3);
        uStack_8 = 0xffffffff;
        FUN_005507b0();
        if (iVar4 != 0) {
          iVar4 = FUN_00a6bd00(auStack_40);
          param_2 = *(float *)(iVar4 + 4) + 0.0;
        }
        uVar3 = FUN_009b4460(2);
        iVar4 = FUN_006e16a0(uVar3);
        if (iVar4 != 0) {
          puStack_18 = (undefined *)0x0;
          uStack_14 = 0xf;
          auStack_28[0] = 0;
          FUN_005542c0();
          uStack_8 = 1;
          uVar3 = FUN_008a1240(auStack_28);
          fStack_34 = (float)FUN_00836510(uVar3);
          uStack_8 = 0xffffffff;
          FUN_005507b0();
          if (fStack_34 != 0.0) {
            iVar4 = FUN_00a6bd00(auStack_40);
            param_2 = param_2 - *(float *)(iVar4 + 4);
          }
          puStack_18 = (undefined *)0x0;
          uStack_14 = 0xf;
          auStack_28[0] = 0;
          FUN_005542c0();
          uStack_8 = 2;
          uVar3 = FUN_008a1240(auStack_28);
          iVar4 = FUN_00836510(uVar3);
          uStack_8 = 0xffffffff;
          FUN_005507b0();
          if (iVar4 != 0) {
            iVar4 = FUN_00a6bd00(auStack_40);
            param_2 = *(float *)(iVar4 + 4) + param_2;
          }
        }
        uVar3 = FUN_009b4460(5);
        iVar4 = FUN_006e16a0(uVar3);
        if (iVar4 != 0) {
          puStack_18 = (undefined *)0x0;
          uStack_14 = 0xf;
          auStack_28[0] = 0;
          FUN_005542c0();
          uStack_8 = 3;
          uVar3 = FUN_008a1240(auStack_28);
          iVar4 = FUN_00836510(uVar3);
          uStack_8 = 0xffffffff;
          FUN_005507b0();
          if (iVar4 != 0) {
            iVar4 = FUN_00a6bd00(auStack_40);
            param_2 = *(float *)(iVar4 + 8) + param_2;
          }
          FUN_00b08320();
        }
      }
      puStack_38 = (undefined *)0x0;
      uVar3 = FUN_00c19e00();
      FUN_00c19180(uVar3);
      FUN_00a950e0(apiStack_30);
      uStack_8 = 4;
      uStack_3c = 0;
      puStack_38 = (undefined *)0xf;
      auStack_4c[0] = 0;
      pcVar1 = *(code **)(*apiStack_30[0] + 0x38);
      FUN_005542c0();
      uStack_8._0_1_ = 5;
      (*pcVar1)(auStack_4c);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_005507b0();
      FUN_00c3d740();
      FUN_00c3d770();
      FUN_00c3ceb0();
      FUN_00c3cee0();
      param_2 = (float)((uint)param_2 & 0xffffff);
      (**(code **)(*DAT_02119b74 + 0x10))(apiStack_30[0],(int)&param_2 + 3);
      FUN_008a65e0(param_1,0);
      FUN_00550b30();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28871 ; VA 0x00c65070 ; FUN_00c65070 */

int __thiscall FUN_00c65070(undefined4 param_1,int param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  bool bVar4;
  bool bVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180cf30;
  pvStack_10 = ExceptionList;
  uStack_18 = param_1;
  iStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    iVar8 = *(int *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar6 = FUN_0099be20();
    if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
        (uint)*(ushort *)(iVar6 + 0x1da)) {
      iStack_14 = param_2;
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      piStack_24 = param_3;
      bVar5 = true;
      bVar4 = false;
      puVar7 = &uStack_28;
      goto LAB_00c650fe;
    }
  }
  piStack_1c = (int *)0x0;
  puVar7 = &uStack_20;
  iStack_14 = 0;
  bVar5 = false;
  bVar4 = true;
LAB_00c650fe:
  piVar3 = (int *)puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  if (bVar4) {
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar8 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar8 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  piVar2 = piStack_24;
  if ((bVar5) && (piStack_24 != (int *)0x0)) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar8 = *piVar1 + -1;
      *piVar1 = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar8 = FUN_00c64bd0(iStack_14,0);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar2 = piVar3 + 1;
    iVar6 = *piVar2;
    iVar8 = *piVar2;
    *piVar2 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar2 = piVar3 + 2;
      iVar6 = *piVar2;
      iVar8 = *piVar2;
      *piVar2 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar8 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar3 = param_3 + 1;
    iVar6 = *piVar3;
    iVar8 = *piVar3;
    *piVar3 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      iVar8 = (**(code **)*param_3)();
      LOCK();
      piVar3 = param_3 + 2;
      iVar6 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        iVar8 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 28872 ; VA 0x00c651e0 ; FUN_00c651e0 */

int FUN_00c651e0(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != param_3) {
    ExceptionList = &pvStack_10;
    param_1 = FUN_00c65c30(param_1);
    if (param_1 != 0) {
      param_1 = FUN_008a65e0(0,0);
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    param_1 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_1 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_1 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28873 ; VA 0x00c65260 ; FUN_00c65260 */

void __thiscall FUN_00c65260(int param_1,int param_2)

{
  undefined *puVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  uint *puVar5;
  double dVar6;
  float fVar7;
  undefined auStack_64 [48];
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  undefined auStack_1c [4];
  undefined auStack_18 [4];
  int *piStack_14;
  int iStack_10;
  int iStack_c;
  undefined uStack_8;
  undefined uStack_7;
  byte bStack_6;
  byte bStack_5;
  
  iStack_10 = 0;
  iStack_c = param_1;
  if (0 < *(int *)(param_2 + 0x14)) {
    do {
      iVar2 = *(int *)(*(int *)(param_2 + 0x10) + iStack_10 * 4);
      piVar4 = (int *)(iVar2 + 0x24);
      if (iVar2 == 0) {
        piVar4 = (int *)0x2c;
      }
      piStack_14 = (int *)(-(uint)(*piVar4 != 0) & *piVar4 - 8U);
      iVar2 = (**(code **)(*piStack_14 + 0x10))();
      if (iVar2 == 7) {
        FUN_00c157b0();
        FUN_011612d0(&fStack_28,0);
        iVar2 = FUN_00ca3fa0(auStack_64,0);
        iVar3 = FUN_00c157b0();
        piVar4 = piStack_14;
        bStack_5 = DAT_018ce2f0 <
                   (*(float *)(iVar2 + 0x28) - *(float *)(iVar3 + 0x28)) * fStack_24 +
                   (*(float *)(iVar2 + 0x24) - *(float *)(iVar3 + 0x24)) * fStack_28 +
                   (*(float *)(iVar2 + 0x2c) - *(float *)(iVar3 + 0x2c)) * fStack_20;
        FUN_01080a00(&fStack_34);
        iVar2 = iStack_c;
        fVar7 = fStack_34 * fStack_28 + fStack_30 * fStack_24 + fStack_2c * fStack_20;
        dVar6 = (double)fVar7;
        bStack_6 = 0.0 <= fVar7 ^ bStack_5;
        if (DAT_018f994c <
            (float)(double)CONCAT44((uint)((ulonglong)dVar6 >> 0x20) & DAT_018c0da0._4_4_,
                                    SUB84(dVar6,0) & (uint)DAT_018c0da0)) {
          puVar5 = (uint *)(iStack_c + 0x218);
          iVar3 = *(int *)(iStack_c + 0x21c);
          puVar1 = (undefined *)*puVar5;
          if (iVar3 < *(int *)(iStack_c + 0x220)) {
            *(int **)(puVar1 + iVar3 * 4) = piVar4;
            *(int *)(iStack_c + 0x21c) = *(int *)(iStack_c + 0x21c) + 1;
          }
          else if ((auStack_18 < puVar1) || (puVar1 + iVar3 * 4 <= auStack_18)) {
            FUN_0078c900(iVar3 + 1,0);
            *(int **)((*puVar5 - 4) + *(int *)(iVar2 + 0x21c) * 4) = piVar4;
          }
          else {
            piStack_14 = piVar4;
            FUN_007c5360(&piStack_14);
          }
          iVar3 = iStack_c;
          iVar2 = *(int *)(iStack_c + 0x228);
          puVar5 = (uint *)(iStack_c + 0x224);
          puVar1 = (undefined *)*puVar5;
          if (iVar2 < *(int *)(iStack_c + 0x22c)) {
            puVar1[iVar2] = bStack_5;
            *(int *)(iStack_c + 0x228) = *(int *)(iStack_c + 0x228) + 1;
          }
          else if ((&uStack_7 < puVar1) || (puVar1 + iVar2 <= &uStack_7)) {
            FUN_00c66c30(iVar2 + 1,0);
            *(byte *)(*(int *)(iVar3 + 0x228) + -1 + *puVar5) = bStack_5;
          }
          else {
            FUN_00c64720(&bStack_5);
          }
          iVar2 = *(int *)(iVar3 + 0x240);
          puVar1 = *(undefined **)(iVar3 + 0x23c);
          if (iVar2 < *(int *)(iVar3 + 0x244)) {
            *(undefined4 *)(puVar1 + iVar2 * 4) = 0;
            *(int *)(iVar3 + 0x240) = *(int *)(iVar3 + 0x240) + 1;
          }
          else if ((auStack_1c < puVar1) || (puVar1 + iVar2 * 4 <= auStack_1c)) {
            FUN_00c66b70(iVar2 + 1,0);
            *(undefined4 *)((*(uint *)(iVar3 + 0x23c) - 4) + *(int *)(iVar3 + 0x240) * 4) = 0;
          }
          else {
            piStack_14 = (int *)0x0;
            FUN_00c646b0(&piStack_14);
          }
          iVar2 = *(int *)(iVar3 + 0x234);
          puVar1 = *(undefined **)(iVar3 + 0x230);
          if (iVar2 < *(int *)(iVar3 + 0x238)) {
            puVar1[iVar2] = bStack_6;
            *(int *)(iVar3 + 0x234) = *(int *)(iVar3 + 0x234) + 1;
          }
          else if ((&uStack_8 < puVar1) || (puVar1 + iVar2 <= &uStack_8)) {
            FUN_00c66c30(iVar2 + 1,0);
            *(byte *)((*(uint *)(iVar3 + 0x230) - 1) + *(int *)(iVar3 + 0x234)) = bStack_6;
          }
          else {
            FUN_00c64720(&bStack_6);
          }
        }
      }
      iStack_10 = iStack_10 + 1;
    } while (iStack_10 < *(int *)(param_2 + 0x14));
  }
  return;
}



/* FUNCTION 28874 ; VA 0x00c65510 ; FUN_00c65510 */

void FUN_00c65510(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00c65531. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(param_1 + 0x18))();
  return;
}



/* FUNCTION 28875 ; VA 0x00c65540 ; FUN_00c65540 */

int FUN_00c65540(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5e40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  pcVar3 = *(code **)(param_1 + 0x18);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar4 = (*pcVar3)(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 28876 ; VA 0x00c65620 ; FUN_00c65620 */

bool __fastcall FUN_00c65620(int param_1)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = (char *)(**(code **)(param_1 + 8))();
  pcVar2 = (char *)(**(code **)(param_1 + 8))();
  return *pcVar2 == *pcVar1;
}



/* FUNCTION 28877 ; VA 0x00c65670 ; FUN_00c65670 */

void FUN_00c65670(void)

{
  int iVar1;
  
  iVar1 = FUN_00c65730();
  if (iVar1 != 0) {
    FUN_008a65e0(0,0);
  }
  return;
}



/* FUNCTION 28878 ; VA 0x00c65690 ; FUN_00c65690 */

void __fastcall FUN_00c65690(int *param_1)

{
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d9648;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_006eccd0();
  uStack_24 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_8 = 0;
  (**(code **)(*param_1 + 8))(&DAT_02137a38,&uStack_24,&uStack_18);
  uStack_8 = 1;
  FUN_00577b20();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28879 ; VA 0x00c65730 ; FUN_00c65730 */

int __fastcall FUN_00c65730(int param_1)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  
  uVar9 = 0;
  iVar4 = FUN_005d6c30();
  if (iVar4 != 0) {
    do {
      iVar4 = *(int *)(**(int **)(param_1 + 0x2c) + uVar9 * 8);
      piVar5 = *(int **)(iVar4 + 0x28);
      piVar1 = piVar5 + 4;
      if (0xf < (uint)piVar5[5]) {
        piVar5 = (int *)*piVar5;
      }
      cVar3 = FUN_0055c360(piVar5,*piVar1,"SeatWeld",8);
      if (cVar3 != '\0') {
        iVar2 = *(int *)(iVar4 + 0xc);
        iVar6 = FUN_00c39bb0();
        iVar8 = 0;
        if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
            (uint)*(ushort *)(iVar6 + 0x1da)) {
          iVar8 = iVar4;
        }
        if (iVar8 != 0) {
          return iVar8;
        }
      }
      uVar9 = uVar9 + 1;
      uVar7 = FUN_005d6c30();
    } while (uVar9 < uVar7);
  }
  return 0;
}



/* FUNCTION 28880 ; VA 0x00c657c0 ; FUN_00c657c0 */

void FUN_00c657c0(undefined4 param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  param_2 = (int *)*param_2;
  iVar3 = *param_2;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0088cdc0();
  if (iVar3 == iVar1) {
    piVar2 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar2 = (int *)0x0;
    }
    iVar3 = piVar2[1];
    if (iVar3 != 0) {
      LOCK();
      *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
      UNLOCK();
      iVar3 = piVar2[1];
    }
    uStack_8 = 0;
    FUN_0089be10(*piVar2,iVar3);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28881 ; VA 0x00c65870 ; FUN_00c65870 */

void FUN_00c65870(undefined4 param_1,int param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_2 + 4);
  if (*(undefined4 **)(param_2 + 8) != puVar1) {
    *puVar1 = param_1;
    *(int *)(param_2 + 4) = *(int *)(param_2 + 4) + 4;
    return;
  }
  FUN_0063d9b0(puVar1,&param_1);
  return;
}



/* FUNCTION 28882 ; VA 0x00c658a0 ; FUN_00c658a0 */

void FUN_00c658a0(undefined4 param_1)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar2 = FUN_00c155c0();
  if (iVar2 != 0) {
    cVar1 = FUN_00ca0f40();
    if (cVar1 == '\0') {
      uVar3 = FUN_00ca1550();
      FUN_00c639d0(FUN_00c65870,param_1,uVar3,0);
    }
  }
  return;
}



/* FUNCTION 28883 ; VA 0x00c658e0 ; FUN_00c658e0 */

void FUN_00c658e0(void)

{
  int iVar1;
  
  if (DAT_01efe19c == 0) {
    iVar1 = FUN_00c63380();
    DAT_01efe19c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28884 ; VA 0x00c65910 ; FUN_00c65910 */

undefined4 __fastcall FUN_00c65910(int param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)(*(int *)(param_1 + -0x78) + 0x70);
  if (*(int *)(param_1 + -0x78) == 0) {
    puVar1 = (undefined4 *)&DAT_00000020;
  }
  return *puVar1;
}



/* FUNCTION 28885 ; VA 0x00c65930 ; FUN_00c65930 */

void __fastcall FUN_00c65930(undefined4 param_1)

{
  FUN_009b52d0(param_1);
  return;
}



/* FUNCTION 28886 ; VA 0x00c6593a ; FUN_00c6593a */

void FUN_00c6593a(void)

{
  FUN_00afc020();
  return;
}



/* FUNCTION 28887 ; VA 0x00c65945 ; FUN_00c65945 */

void FUN_00c65945(void)

{
  FUN_00afc020();
  return;
}



/* FUNCTION 28888 ; VA 0x00c65953 ; FUN_00c65953 */

void FUN_00c65953(void)

{
  FUN_00afc020();
  return;
}



/* FUNCTION 28889 ; VA 0x00c65970 ; FUN_00c65970 */

undefined4 __fastcall FUN_00c65970(int param_1)

{
  FUN_00c65cd0();
  return *(undefined4 *)(param_1 + 0x21c);
}



/* FUNCTION 28890 ; VA 0x00c659f0 ; FUN_00c659f0 */

undefined __fastcall FUN_00c659f0(int param_1)

{
  undefined *puVar1;
  
  puVar1 = (undefined *)(**(code **)(param_1 + 8))();
  return *puVar1;
}



/* FUNCTION 28891 ; VA 0x00c65a20 ; FUN_00c65a20 */

undefined4 __thiscall FUN_00c65a20(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if (param_1 != 0) {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        FUN_005789c0(&DAT_01ea8a70,&LAB_0055d570);
        uVar3 = FUN_00560c40();
        piVar4 = (int *)FUN_008aa140(uVar3);
        if (*piVar4 == 0) {
          uVar3 = FUN_00961660();
          piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
          iVar1 = *piVar5;
          iVar2 = piVar5[1];
          *piVar5 = 0;
          piVar5[1] = 0;
          *piVar4 = iVar1;
          piVar5 = (int *)piVar4[1];
          piVar4[1] = iVar2;
          if (piVar5 != (int *)0x0) {
            LOCK();
            iVar1 = piVar5[1] + -1;
            piVar5[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piVar5)();
              LOCK();
              iVar1 = piVar5[2] + -1;
              piVar5[2] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)(*piVar5 + 4))();
              }
            }
          }
          if (piStack_8 != (int *)0x0) {
            LOCK();
            iVar1 = piStack_8[1] + -1;
            piStack_8[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piStack_8)();
              LOCK();
              piVar5 = piStack_8 + 2;
              iVar1 = *piVar5;
              *piVar5 = *piVar5 + -1;
              UNLOCK();
              if (iVar1 == 1) {
                (**(code **)(*piStack_8 + 4))();
              }
            }
          }
        }
        if ((((*piVar4 != 0) && (iVar1 = *(int *)(*piVar4 + 0xf4), iVar1 != 0)) &&
            (iVar2 = FUN_009b48a0(param_2), iVar2 != 0)) && (*(int *)(iVar1 + 100) == iVar2)) {
          return 1;
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 28892 ; VA 0x00c65b50 ; FUN_00c65b50 */

int FUN_00c65b50(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5e40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  pcVar3 = (code *)*param_1;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar4 = (*pcVar3)(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 28893 ; VA 0x00c65c30 ; FUN_00c65c30 */

int FUN_00c65c30(int param_1)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  
  piVar4 = *(int **)(param_1 + 0x28);
  piVar1 = piVar4 + 4;
  if (0xf < (uint)piVar4[5]) {
    piVar4 = (int *)*piVar4;
  }
  cVar3 = FUN_0055c360(piVar4,*piVar1,"SeatWeld",8);
  if (cVar3 != '\0') {
    iVar2 = *(int *)(param_1 + 0xc);
    iVar5 = FUN_00c39bb0();
    iVar6 = 0;
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
        (uint)*(ushort *)(iVar5 + 0x1da)) {
      iVar6 = param_1;
    }
    if (iVar6 != 0) {
      return iVar6;
    }
  }
  return 0;
}



/* FUNCTION 28894 ; VA 0x00c65c90 ; FUN_00c65c90 */

uint FUN_00c65c90(void)

{
  int iVar1;
  
  iVar1 = FUN_00c63380();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28895 ; VA 0x00c65cb0 ; FUN_00c65cb0 */

uint FUN_00c65cb0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c63380();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28896 ; VA 0x00c65cd0 ; FUN_00c65cd0 */

void __fastcall FUN_00c65cd0(int param_1)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_2c;
  undefined4 uStack_14;
  
  iVar2 = *(int *)(param_1 + 0x21c);
  if (iVar2 != 0) {
    *(undefined4 *)(param_1 + 0x21c) = 0;
    if (*(int *)(param_1 + 0x220) < 0) {
      if (*(int *)(param_1 + 0x220) == 0) {
        uVar3 = 0;
      }
      else {
        uVar3 = 10;
      }
      *(undefined4 *)(param_1 + 0x220) = uVar3;
      FUN_0078c480(iVar2);
    }
  }
  iVar2 = *(int *)(param_1 + 0x228);
  if (iVar2 != 0) {
    *(undefined4 *)(param_1 + 0x228) = 0;
    if (*(int *)(param_1 + 0x22c) < 0) {
      if (*(int *)(param_1 + 0x22c) == 0) {
        uVar3 = 0;
      }
      else {
        uVar3 = 0x20;
      }
      *(undefined4 *)(param_1 + 0x22c) = uVar3;
      FUN_00c66b20(iVar2);
    }
  }
  iVar2 = *(int *)(param_1 + 0x234);
  if (iVar2 != 0) {
    *(undefined4 *)(param_1 + 0x234) = 0;
    if (*(int *)(param_1 + 0x238) < 0) {
      if (*(int *)(param_1 + 0x238) == 0) {
        uVar3 = 0;
      }
      else {
        uVar3 = 0x20;
      }
      *(undefined4 *)(param_1 + 0x238) = uVar3;
      FUN_00c66b20(iVar2);
    }
  }
  iVar2 = *(int *)(param_1 + 0x240);
  if (iVar2 != 0) {
    *(undefined4 *)(param_1 + 0x240) = 0;
    if (*(int *)(param_1 + 0x244) < 0) {
      if (*(int *)(param_1 + 0x244) == 0) {
        uVar3 = 0;
      }
      else {
        uVar3 = 10;
      }
      *(undefined4 *)(param_1 + 0x244) = uVar3;
      FUN_00c66a70(iVar2);
    }
  }
  iVar2 = FUN_00c155c0();
  if (iVar2 != 0) {
    cVar1 = FUN_00ca0f40();
    if (cVar1 == '\0') {
      uVar3 = FUN_00ca1550();
      FUN_00c63a50(FUN_00c65260,0,0,uStack_14,CONCAT44(uStack_2c,param_1),uVar3,0);
    }
  }
  return;
}



/* FUNCTION 28897 ; VA 0x00c65e50 ; FUN_00c65e50 */

int * FUN_00c65e50(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar1 = param_1[1];
      iVar2 = param_1[2];
      iVar3 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar1;
      param_2[2] = iVar2;
      param_2[3] = iVar3;
      param_2[4] = 0;
      param_2[5] = 0;
      if (param_1[5] != 0) {
        LOCK();
        piVar5 = (int *)(param_1[5] + 4);
        *piVar5 = *piVar5 + 1;
        UNLOCK();
      }
      param_2[4] = param_1[4];
      piVar5 = (int *)param_1[5];
      param_2[5] = (int)piVar5;
      if (param_3 != 1) {
        return piVar5;
      }
      piVar6 = (int *)param_1[5];
      if (piVar6 == (int *)0x0) {
        return piVar5;
      }
      LOCK();
      piVar5 = piVar6 + 1;
      iVar1 = *piVar5;
      piVar4 = (int *)*piVar5;
      *piVar5 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar4;
      }
      piVar4 = (int *)(**(code **)*piVar6)();
      LOCK();
      piVar5 = piVar6 + 2;
      iVar1 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar4;
      }
                    /* WARNING: Could not recover jumptable at 0x00c65f34. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar5 = (int *)(**(code **)(*piVar6 + 4))();
      return piVar5;
    }
    if (param_3 == 2) {
      piVar5 = (int *)param_2[5];
      if (piVar5 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar6 = piVar5 + 1;
      iVar1 = *piVar6;
      piVar4 = (int *)*piVar6;
      *piVar6 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar4;
      }
      piVar4 = (int *)(**(code **)*piVar5)();
      LOCK();
      piVar6 = piVar5 + 2;
      iVar1 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar4;
      }
                    /* WARNING: Could not recover jumptable at 0x00c65ea6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar5 = (int *)(**(code **)(*piVar5 + 4))();
      return piVar5;
    }
    if (param_3 == 3) {
      piVar6 = (int *)FUN_0170d8dd(*param_2 + 4,0x1e093e4);
      piVar5 = (int *)0x0;
      if (piVar6 == (int *)0x0) {
        piVar5 = param_1;
      }
      *param_2 = (int)piVar5;
      return piVar6;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf0<void,class_RBX::VehicleSeat>,class_boost::_bi::list1<class_boost::_bi::value<class_std::shared_ptr<class_RBX::VehicleSeat>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 28898 ; VA 0x00c65f50 ; FUN_00c65f50 */

void FUN_00c65f50(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_1 + 4);
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1e0947c);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf1<void,class_RBX::SeatImpl<class_RBX::PartInstance>,class_std::shared_ptr<class_RBX::Instance>_>,class_boost::_bi::list2<class_boost::_bi::value<class_RBX::SeatImpl<class_RBX::PartInstance>*>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 28899 ; VA 0x00c65fc0 ; FUN_00c65fc0 */

void __thiscall FUN_00c65fc0(int param_1,undefined4 param_2)

{
  int iVar1;
  
  FUN_00b09c70(param_2);
  iVar1 = FUN_008b45a0(param_1);
  if (iVar1 != *(int *)(param_1 + 0x214)) {
    if (*(int *)(param_1 + 0x214) != 0) {
      FUN_00c3dac0(param_1 + 0x120,0,1);
      FUN_00ca4900(0,0);
      FUN_00ca4900(1,0);
    }
    *(int *)(param_1 + 0x214) = iVar1;
    if (iVar1 != 0) {
      FUN_00ca4900(0,*(undefined4 *)(param_1 + 0xa8));
      FUN_00ca4900(1,*(undefined4 *)(*(int *)(param_1 + 0x214) + 0xd4));
      FUN_00c3dac0(param_1 + 0x120,*(undefined4 *)(param_1 + 0x214),1);
    }
  }
  FUN_008a4940(&DAT_021379b4);
  return;
}



/* FUNCTION 28900 ; VA 0x00c66070 ; FUN_00c66070 */

void __thiscall FUN_00c66070(int *param_1,undefined4 *param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uStack_40;
  code *pcStack_3c;
  undefined4 uStack_38;
  undefined *puStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017e1c21;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00c65c30(param_2);
  if (iVar3 != 0) {
    pcStack_3c = FUN_00c651e0;
    uStack_38 = 0;
    puStack_34 = (undefined *)0x0;
    uStack_30 = iStack_28;
    piStack_2c = param_1;
    iStack_28 = iVar3;
    FUN_00c63880(&pcStack_3c);
    uVar4 = FUN_00c3c020();
    iStack_14 = FUN_009ade20(uVar4);
    if (iStack_14 != 0) {
      iStack_20 = iStack_14;
      (**(code **)(*param_1 + 0x168))(iStack_14);
      FUN_009c4e40(param_1);
      FUN_009c4f20(1);
      iStack_14 = iStack_14 + 0x77c;
      puStack_34 = &LAB_00c662e0;
      uStack_30 = 0;
      piStack_2c = (int *)0x0;
      iStack_8 = 0;
      uVar4 = FUN_01675290(DAT_02110da8);
      iStack_8._0_1_ = 1;
      uStack_24 = uVar4;
      puStack_18 = (undefined4 *)FUN_01674e20(0x30);
      if (puStack_18 == (undefined4 *)0x0) {
        puStack_18 = (undefined4 *)0x0;
      }
      else {
        *puStack_18 = 0;
        puStack_18[1] = 1;
        puStack_18[2] = FUN_00c65510;
        puStack_18[3] = _guard_check_icall;
        puStack_18[4] = 0;
        puStack_18[6] = puStack_34;
        puStack_18[7] = uStack_30;
        puStack_18[8] = piStack_2c;
        puStack_18[9] = iStack_28;
        puStack_18[5] = iStack_14;
        *(ulonglong *)(puStack_18 + 10) = CONCAT44(uStack_40,param_1);
      }
      FUN_016797d0(puStack_18);
      param_2 = puStack_18;
      if (puStack_18 != (undefined4 *)0x0) {
        LOCK();
        puStack_18[1] = puStack_18[1] + 1;
        UNLOCK();
      }
      uStack_1c = 1;
      iStack_8._0_1_ = 2;
      FUN_01675290(uVar4);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      cVar2 = FUN_01679300(&param_2);
      if (cVar2 != '\0') {
        FUN_01679490();
        FUN_016791c0(&param_2);
      }
      iStack_8 = 0xffffffff;
      if (param_2 != (undefined4 *)0x0) {
        piVar1 = param_2 + 1;
        LOCK();
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          FUN_01674ea0(param_2);
        }
      }
      (**(code **)(*param_1 + 0x164))(1,iStack_20);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28901 ; VA 0x00c66260 ; FUN_00c66260 */

void __thiscall FUN_00c66260(int *param_1,undefined4 param_2)

{
  code *pcVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined auStack_c [8];
  
  iVar2 = FUN_00c65c30(param_2);
  if (iVar2 != 0) {
    (**(code **)(*param_1 + 0x168))(0);
    FUN_01679490();
    piVar3 = (int *)FUN_01682800(auStack_c);
    param_1[0x3e] = *piVar3;
    param_1[0x3f] = piVar3[1];
    pcVar1 = *(code **)(*param_1 + 0x164);
    uVar4 = FUN_00c3c020();
    uVar4 = FUN_009ade20(uVar4);
    (*pcVar1)(0,uVar4);
  }
  return;
}



/* FUNCTION 28902 ; VA 0x00c662f0 ; FUN_00c662f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

double * __thiscall FUN_00c662f0(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  double *pdVar3;
  double *pdVar4;
  double *pdVar5;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  pdVar3 = (double *)FUN_009ade20(param_2);
  pdVar5 = pdVar3;
  if ((pdVar3 == (double *)0x0) ||
     (pdVar4 = (double *)FUN_009b7250(), pdVar5 = pdVar4, pdVar4 == (double *)0x0))
  goto LAB_00c663e8;
  pdVar5 = (double *)FUN_01682800(auStack_18);
  if ((*pdVar5 - *(double *)(param_1 + 0x3e) <= _PTR_018dad08) ||
     (((DAT_01d68a5c != '\0' && (pdVar5 = (double *)FUN_009b6ef0(0xd), (char)pdVar5 == '\0')) ||
      (pdVar5 = (double *)FUN_00c65730(), pdVar5 != (double *)0x0)))) {
LAB_00c663c2:
    if (*(char *)((int)pdVar3 + 0x21f) < '\x01') goto LAB_00c663e8;
  }
  else if (*(char *)((int)pdVar3 + 0x21f) < '\x01') {
    pdVar5 = (double *)FUN_009b4a80();
    if ((((char)pdVar5 == '\0') && (*(char *)(param_1 + 0x46) == '\0')) &&
       ((pdVar5 = (double *)FUN_008b0500(pdVar4), (char)pdVar5 != '\0' &&
        (pdVar5 = (double *)FUN_008b0500(param_1), (char)pdVar5 != '\0')))) {
      pdVar5 = (double *)(**(code **)(*param_1 + 0x15c))(pdVar3);
      goto LAB_00c663e8;
    }
    goto LAB_00c663c2;
  }
  pdVar5 = (double *)FUN_00c65730();
  if ((pdVar5 != (double *)0x0) && (*(int *)((int)pdVar3 + 0x194) == 0)) {
    pdVar5 = (double *)FUN_009c4e40(param_1);
  }
LAB_00c663e8:
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pdVar5 = (double *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pdVar5 = (double *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pdVar5 = (double *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pdVar5;
}



/* FUNCTION 28903 ; VA 0x00c66430 ; FUN_00c66430 */

void __thiscall FUN_00c66430(undefined4 param_1,char param_2,int param_3)

{
  int iVar1;
  
  if (param_3 != 0) {
    iVar1 = FUN_009b52d0(param_1);
    if (param_3 == iVar1) {
      iVar1 = FUN_008b2e60(param_1);
      if (param_2 == '\0') {
        if (iVar1 != 0) {
          (**(code **)(*(int *)(iVar1 + 0x144) + 4))();
          FUN_00d24b00(param_3);
          (**(code **)(*(int *)(iVar1 + 0x144) + 4))();
          FUN_00d24d00(5);
          FUN_009c4f20(0);
        }
      }
      else if (iVar1 != 0) {
        (**(code **)(*(int *)(iVar1 + 0x144) + 4))();
        FUN_00d24d00(5);
        (**(code **)(*(int *)(iVar1 + 0x144) + 4))();
        FUN_00d24b00(param_1);
      }
      FUN_00c67210(0);
      FUN_00c67120(0);
    }
  }
  FUN_0115b050();
  return;
}



/* FUNCTION 28904 ; VA 0x00c664f0 ; FUN_00c664f0 */

void __thiscall FUN_00c664f0(int *param_1,int param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  uint auStack_4c [2];
  code *pcStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined8 uStack_34;
  code *pcStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180cf69;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    FUN_01679490();
    pcVar2 = *(code **)(*param_1 + 0x164);
    iVar4 = FUN_00c65730();
    if (iVar4 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_00c3c020();
    }
    uVar5 = FUN_009ade20(uVar5);
    (*pcVar2)(0,uVar5);
  }
  iVar4 = param_3;
  FUN_00b0a250(param_2,param_3);
  if (iVar4 != 0) {
    iVar4 = FUN_008a4100();
    uStack_34 = CONCAT44(uStack_34._4_4_,param_1);
    pcStack_2c = FUN_00c662f0;
    uStack_28 = 0;
    uStack_24 = 0;
    uStack_20 = uStack_18;
    iStack_8 = 0;
    uStack_18 = uStack_34._4_4_;
    piStack_1c = param_1;
    cVar3 = FUN_00585a40(&pcStack_2c);
    if (cVar3 == '\0') {
      pcStack_44 = pcStack_2c;
      uStack_40 = uStack_28;
      uStack_3c = uStack_24;
      uStack_38 = uStack_20;
      auStack_4c[0] = 0x196d571;
      uStack_34 = CONCAT44(uStack_18,piStack_1c);
    }
    else {
      auStack_4c[0] = 0;
    }
    iStack_8._0_1_ = 1;
    uVar5 = FUN_00b01210(auStack_4c,*(undefined4 *)(iVar4 + 0xbc));
    iStack_8._0_1_ = 2;
    uVar5 = FUN_00affe60(&param_2,uVar5);
    uStack_14 = 1;
    FUN_00b01550();
    iStack_8._0_1_ = 3;
    if (auStack_4c[0] != 0) {
      if (((auStack_4c[0] & 1) == 0) && (*(code **)(auStack_4c[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(auStack_4c[0] & 0xfffffffe))(&pcStack_44,&pcStack_44,2);
      }
      auStack_4c[0] = 0;
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    cVar3 = FUN_01679300(uVar5);
    if (cVar3 != '\0') {
      FUN_01679490();
      FUN_016791c0(uVar5);
    }
    if (param_2 != 0) {
      piVar1 = (int *)(param_2 + 4);
      LOCK();
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        FUN_01674ea0(param_2);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28905 ; VA 0x00c666b0 ; FUN_00c666b0 */

int FUN_00c666b0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180cf90;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_00899040();
    puVar5 = (undefined4 *)FUN_0060dcd0(auStack_24,uStack_14);
    uStack_8 = 0;
    uVar3 = *puVar5;
    uVar4 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    FUN_00d14680(uVar3,uVar4);
    uStack_8 = 0xffffffff;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_20[1] + -1;
      piStack_20[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar6 = piStack_20[2] + -1;
        piStack_20[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
  }
  iVar6 = FUN_00c664f0(param_1,param_2);
  if (param_2 != 0) {
    FUN_00899040();
    puVar5 = (undefined4 *)FUN_0060dcd0(auStack_1c,uStack_14);
    uStack_8 = 1;
    uVar3 = *puVar5;
    uVar4 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    iVar6 = FUN_00d120f0(uVar3,uVar4);
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_18 + 1;
      iVar2 = *piVar1;
      iVar6 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar6 = (**(code **)*piStack_18)();
        LOCK();
        piVar1 = piStack_18 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar6 = (**(code **)(*piStack_18 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 28906 ; VA 0x00c667f0 ; FUN_00c667f0 */

void __thiscall FUN_00c667f0(undefined4 param_1,undefined *param_2,int *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  int *piVar7;
  int aiStack_2c [2];
  int iStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180cfb8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_20 = param_1;
  iVar3 = FUN_008f7870(param_1);
  if (iVar3 != 0) {
    if ((*(int *)(iVar3 + 0x4a0) == 1) || (*(int *)(iVar3 + 0x4a0) == 3)) {
      FUN_00b0a450(param_2,param_3,param_4);
      ExceptionList = pvStack_10;
      return;
    }
    if (param_2 != &DAT_021379f0) {
      if (param_2 != &DAT_02137a38) {
        FUN_00b0a450(param_2,param_3,param_4);
        ExceptionList = pvStack_10;
        return;
      }
      FUN_0097c020(aiStack_2c,param_4,param_1);
      uStack_8 = 2;
      if ((aiStack_2c[0] != 0) && (iVar3 = *(int *)(aiStack_2c[0] + 100), iVar3 != 0)) {
        iStack_18 = FUN_00c65730();
        puVar1 = *(undefined4 **)(iVar3 + 0x2c);
        if (puVar1 != (undefined4 *)0x0) {
          piVar2 = (int *)puVar1[1];
          for (piVar7 = (int *)*puVar1; piVar7 != piVar2; piVar7 = piVar7 + 2) {
            iStack_14 = *piVar7;
            if ((iStack_14 != 0) &&
               (iVar3 = *(int *)(iStack_14 + 0xc), iVar6 = FUN_0099be20(), iVar4 = iStack_14,
               (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
               (uint)*(ushort *)(iVar6 + 0x1da))) goto LAB_00c669d5;
          }
        }
        iVar4 = 0;
LAB_00c669d5:
        if ((iStack_18 != 0) && (iVar4 != 0)) {
          uVar5 = FUN_00c3c020();
          iVar3 = FUN_009ade20(uVar5);
          if (iVar4 == iVar3) {
            FUN_00b0a450(&DAT_02137a38,param_3,param_4);
          }
        }
      }
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return;
    }
    if (((param_3[1] - *param_3) / 0xd0 == 1) ||
       (iVar3 = *(int *)*param_3, iVar4 = FUN_0088cdc0(), iVar3 == iVar4)) {
      uVar5 = FUN_00605c00();
      FUN_00557fc0(uVar5);
      uStack_8 = 0;
      if ((iStack_1c == 0) ||
         (iVar3 = *(int *)(iStack_1c + 0xc), iVar6 = FUN_0099be20(), iVar4 = iStack_1c,
         (uint)*(ushort *)(iVar6 + 0x1da) <
         (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8))) {
        iVar4 = 0;
      }
      iStack_14 = FUN_009b48a0(iVar4);
      iVar6 = FUN_00c65730();
      iVar3 = iStack_14;
      if (((((iVar6 == 0) && (iStack_1c != 0)) && (iVar4 != 0)) &&
          ((iStack_14 != 0 && (*(int *)(iVar4 + 0x194) == 0)))) &&
         (**(char **)(iVar4 + 0x22c) == (char)*(char **)(iVar4 + 0x22c))) {
        FUN_0097c020(&iStack_24,param_4,param_1);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        if ((iStack_24 != 0) && (*(int *)(iStack_24 + 100) == iVar3)) {
          FUN_00b0a450(&DAT_021379f0,param_3,param_4);
        }
        FUN_00550b30();
      }
      FUN_00550b30();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28907 ; VA 0x00c66a70 ; FUN_00c66a70 */

void __thiscall FUN_00c66a70(undefined4 *param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  
  puVar1 = (undefined4 *)*param_1;
  puVar3 = (undefined4 *)FUN_01674f30(param_1[2] << 2);
  *param_1 = puVar3;
  if ((int)param_1[2] < (int)param_2) {
    param_2 = param_1[2];
  }
  uVar6 = 0;
  uVar7 = param_2 & 0x3fffffff;
  if (puVar3 + param_2 < puVar3) {
    uVar7 = 0;
  }
  puVar4 = puVar1;
  if (3 < uVar7) {
    iVar8 = (uVar7 - 4 >> 2) + 1;
    uVar6 = iVar8 * 4;
    do {
      *puVar3 = *puVar4;
      puVar3[1] = puVar4[1];
      puVar3[2] = puVar4[2];
      puVar5 = puVar4 + 3;
      puVar4 = puVar4 + 4;
      puVar3[3] = *puVar5;
      puVar3 = puVar3 + 4;
      iVar8 = iVar8 + -1;
    } while (iVar8 != 0);
  }
  if (uVar6 < uVar7) {
    puVar5 = puVar4;
    do {
      uVar2 = *puVar5;
      puVar5 = puVar5 + 1;
      uVar6 = uVar6 + 1;
      *(undefined4 *)((int)puVar3 + (-4 - (int)puVar4) + (int)puVar5) = uVar2;
    } while (uVar6 < uVar7);
  }
  FUN_01674ea0(puVar1);
  return;
}



/* FUNCTION 28908 ; VA 0x00c66b20 ; FUN_00c66b20 */

void __thiscall FUN_00c66b20(undefined4 *param_1,uint param_2)

{
  undefined uVar1;
  undefined *puVar2;
  undefined *puVar3;
  undefined *puVar4;
  uint uVar5;
  
  puVar2 = (undefined *)*param_1;
  puVar3 = (undefined *)FUN_01674f30(param_1[2]);
  *param_1 = puVar3;
  if ((int)param_1[2] < (int)param_2) {
    param_2 = param_1[2];
  }
  uVar5 = 0;
  if (puVar3 + param_2 < puVar3) {
    param_2 = 0;
  }
  puVar4 = puVar2;
  if (param_2 != 0) {
    do {
      uVar1 = *puVar4;
      puVar4 = puVar4 + 1;
      uVar5 = uVar5 + 1;
      *puVar3 = uVar1;
      puVar3 = puVar3 + 1;
    } while (uVar5 < param_2);
  }
  FUN_01674ea0(puVar2);
  return;
}



/* FUNCTION 28909 ; VA 0x00c66b70 ; FUN_00c66b70 */

void __thiscall FUN_00c66b70(int param_1,int param_2,char param_3)

{
  int iVar1;
  int iVar2;
  float fVar3;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 == param_2) {
    return;
  }
  iVar2 = *(int *)(param_1 + 8);
  *(int *)(param_1 + 4) = param_2;
  if (param_2 <= iVar2) {
    if (iVar2 / 3 < param_2) {
      return;
    }
    if (param_3 == '\0') {
      return;
    }
    if (param_2 < 0xb) {
      return;
    }
    if (iVar1 <= param_2) {
      param_2 = iVar1;
    }
    FUN_00c66a70(param_2);
    return;
  }
  if (iVar2 == 0) {
    *(int *)(param_1 + 8) = param_2;
    FUN_00c66a70(iVar1);
    return;
  }
  if (9 < param_2) {
    fVar3 = DAT_018df57c;
    if ((iVar2 * 4 < 0x61a81) && (fVar3 = DAT_018df580, 64000 < iVar2 * 4)) {
      fVar3 = DAT_018daf58;
    }
    param_2 = ((int)((float)iVar2 * fVar3) - iVar2) + param_2;
    *(int *)(param_1 + 8) = param_2;
    if (9 < param_2) goto LAB_00c66bf6;
  }
  *(undefined4 *)(param_1 + 8) = 10;
LAB_00c66bf6:
  FUN_00c66a70(iVar1);
  return;
}



/* FUNCTION 28910 ; VA 0x00c66c30 ; FUN_00c66c30 */

void __thiscall FUN_00c66c30(int param_1,int param_2,char param_3)

{
  int iVar1;
  int iVar2;
  float fVar3;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 == param_2) {
    return;
  }
  iVar2 = *(int *)(param_1 + 8);
  *(int *)(param_1 + 4) = param_2;
  if (param_2 <= iVar2) {
    if (iVar2 / 3 < param_2) {
      return;
    }
    if (param_3 == '\0') {
      return;
    }
    if (param_2 < 0x21) {
      return;
    }
    if (iVar1 <= param_2) {
      param_2 = iVar1;
    }
    FUN_00c66b20(param_2);
    return;
  }
  if (iVar2 == 0) {
    *(int *)(param_1 + 8) = param_2;
    FUN_00c66b20(iVar1);
    return;
  }
  if (0x1f < param_2) {
    fVar3 = DAT_018df57c;
    if ((iVar2 < 0x61a81) && (fVar3 = DAT_018df580, 64000 < iVar2)) {
      fVar3 = DAT_018daf58;
    }
    param_2 = ((int)((float)iVar2 * fVar3) - iVar2) + param_2;
    *(int *)(param_1 + 8) = param_2;
    if (0x1f < param_2) goto LAB_00c66cb1;
  }
  *(undefined4 *)(param_1 + 8) = 0x20;
LAB_00c66cb1:
  FUN_00c66b20(iVar1);
  return;
}



/* FUNCTION 28911 ; VA 0x00c66cf0 ; FUN_00c66cf0 */

void __thiscall FUN_00c66cf0(int param_1,char *param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined *puStack_20;
  undefined4 uStack_1c;
  int iStack_10;
  int *piStack_c;
  char cStack_5;
  
  cVar2 = *param_2;
  cStack_5 = *(char *)(param_1 + 0x118);
  if (cStack_5 != cVar2) {
    *(char *)(param_1 + 0x118) = cVar2;
    FUN_008a4940();
  }
  if ((cStack_5 == '\0') && (cVar2 != '\0')) {
    iVar3 = FUN_00c65730();
    if (iVar3 != 0) {
      FUN_00c3c020();
      iVar3 = FUN_009ade20();
      if (iVar3 != 0) {
        FUN_009c4f20();
      }
      FUN_008a65e0();
    }
    iVar3 = FUN_00c65730();
    if ((iVar3 != 0) && (iStack_10 = FUN_008f7870(), iStack_10 != 0)) {
      puStack_20 = &LAB_00c66ed0;
      uStack_1c = 0;
      FUN_0060dcd0();
      FUN_00c63690(&uStack_38,CONCAT44(uStack_1c,puStack_20),0);
      piVar1 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piStack_24[1] = piStack_24[1] + 1;
        UNLOCK();
      }
      piStack_c = piStack_24 + 1;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        *piStack_c = *piStack_c + 1;
        UNLOCK();
        LOCK();
        *piStack_c = *piStack_c + 1;
        UNLOCK();
      }
      FUN_00c63570(uStack_38,uStack_34,uStack_30,uStack_2c,uStack_28);
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar3 = *piStack_c;
        *piStack_c = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar3 = piVar1[2] + -1;
          piVar1[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar3 = piVar1[1] + -1;
          piVar1[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar3 = piVar1[2] + -1;
            piVar1[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
      }
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar1 = piStack_24 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piStack_24 + 4))();
          }
        }
      }
      FUN_0090ca30();
    }
  }
  return;
}



/* FUNCTION 28912 ; VA 0x00c66f10 ; FUN_00c66f10 */

void __thiscall FUN_00c66f10(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x200) != param_2) {
    *(char *)(param_1 + 0x200) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 28913 ; VA 0x00c66f40 ; FUN_00c66f40 */

void __thiscall FUN_00c66f40(int param_1,float param_2)

{
  if ((NAN(*(float *)(param_1 + 500)) || NAN(param_2)) == (*(float *)(param_1 + 500) == param_2)) {
    *(float *)(param_1 + 500) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 28914 ; VA 0x00c66f80 ; FUN_00c66f80 */

void FUN_00c66f80(undefined4 param_1)

{
  FUN_00b0dd50(param_1);
  FUN_00c18fe0(3);
  return;
}



/* FUNCTION 28915 ; VA 0x00c66fa0 ; FUN_00c66fa0 */

void __thiscall FUN_00c66fa0(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (*(int *)(param_1 + 0x110) != param_2) {
    puVar5 = (undefined4 *)FUN_0060dcd0(auStack_c,param_2);
    uVar1 = *puVar5;
    uVar2 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    *(undefined4 *)(param_1 + 0x110) = uVar1;
    piVar3 = *(int **)(param_1 + 0x114);
    *(undefined4 *)(param_1 + 0x114) = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[1] + -1;
      piVar3[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        iVar4 = piVar3[2] + -1;
        piVar3[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_8[1] + -1;
      piStack_8[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar3 = piStack_8 + 2;
        iVar4 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    FUN_008a4940(&DAT_021377b8);
  }
  return;
}



/* FUNCTION 28916 ; VA 0x00c67050 ; FUN_00c67050 */

void __thiscall FUN_00c67050(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  
  piVar2 = param_3;
  if ((param_3 != (int *)0x0) &&
     (iVar1 = param_3[3], iVar3 = FUN_0099be20(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    piVar6 = (int *)param_1[1];
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    if (param_2 == (int *)0x0) {
      param_2 = (int *)&DAT_018e3e8c;
    }
    else {
      (**(code **)(*param_2 + 0x10))();
      param_2 = (int *)FUN_005543f0();
    }
    (**(code **)(*piVar2 + 0x10))();
    uVar4 = FUN_005543f0();
    (**(code **)(*param_1 + 0x4c))();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Expected %s got %s for %s:%s.",uVar5,uVar4,param_2,piVar6);
  }
  param_3 = piVar2;
  (**(code **)(*(int *)param_1[0xe] + 0x10))(param_2,&param_3);
  return;
}



/* FUNCTION 28917 ; VA 0x00c67100 ; FUN_00c67100 */

void FUN_00c67100(int param_1)

{
  FUN_00c67120((float)param_1);
  return;
}



/* FUNCTION 28918 ; VA 0x00c67120 ; FUN_00c67120 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00c67120(int param_1,float param_2)

{
  bool bVar1;
  uint uVar2;
  int iVar3;
  float fVar4;
  double dVar5;
  float fVar6;
  
  fVar4 = DAT_018f7864;
  if (DAT_018f7864 <= param_2) {
    fVar4 = param_2;
  }
  fVar6 = DAT_018ce2f8;
  if (fVar4 <= DAT_018ce2f8) {
    fVar6 = fVar4;
  }
  bVar1 = (NAN(*(float *)(param_1 + 0x210)) || NAN(fVar6)) == (*(float *)(param_1 + 0x210) == fVar6)
  ;
  if (bVar1) {
    *(float *)(param_1 + 0x210) = fVar6;
  }
  dVar5 = (double)param_2;
  if (dVar5 <= 0.0) {
    iVar3 = (0.0 <= dVar5) - 1;
  }
  else {
    iVar3 = 1;
  }
  dVar5 = (double)CONCAT44((uint)((ulonglong)dVar5 >> 0x20) & DAT_018c0da0._4_4_,
                           SUB84(dVar5,0) & (uint)DAT_018c0da0);
  if (dVar5 < 0.0) {
    dVar5 = dVar5 - _PTR_018cf0f8;
  }
  else {
    dVar5 = dVar5 + _PTR_018cf0f8;
  }
  uVar2 = (int)dVar5 * iVar3;
  if (uVar2 < 0x80000000) {
    if (0 < (int)uVar2) {
      uVar2 = 1;
    }
  }
  else {
    uVar2 = 0xffffffff;
  }
  if (*(uint *)(param_1 + 0x208) != uVar2) {
    *(uint *)(param_1 + 0x208) = uVar2;
    FUN_008a4940(&DAT_0213782c);
  }
  if (bVar1) {
    FUN_008a4940(&DAT_0213789c);
  }
  return;
}



/* FUNCTION 28919 ; VA 0x00c671f0 ; FUN_00c671f0 */

void FUN_00c671f0(int param_1)

{
  FUN_00c67210((float)param_1);
  return;
}



/* FUNCTION 28920 ; VA 0x00c67210 ; FUN_00c67210 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00c67210(int param_1,float param_2)

{
  bool bVar1;
  uint uVar2;
  int iVar3;
  float fVar4;
  double dVar5;
  float fVar6;
  
  bVar1 = false;
  if ((NAN(*(float *)(param_1 + 0x20c)) || NAN(param_2)) == (*(float *)(param_1 + 0x20c) == param_2)
     ) {
    fVar6 = DAT_018f7864;
    if (DAT_018f7864 <= param_2) {
      fVar6 = param_2;
    }
    bVar1 = true;
    fVar4 = DAT_018ce2f8;
    if (fVar6 <= DAT_018ce2f8) {
      fVar4 = fVar6;
    }
    *(float *)(param_1 + 0x20c) = fVar4;
  }
  dVar5 = (double)param_2;
  if (dVar5 <= 0.0) {
    iVar3 = (0.0 <= dVar5) - 1;
  }
  else {
    iVar3 = 1;
  }
  dVar5 = (double)CONCAT44((uint)((ulonglong)dVar5 >> 0x20) & DAT_018c0da0._4_4_,
                           SUB84(dVar5,0) & (uint)DAT_018c0da0);
  if (dVar5 < 0.0) {
    dVar5 = dVar5 - _PTR_018cf0f8;
  }
  else {
    dVar5 = dVar5 + _PTR_018cf0f8;
  }
  uVar2 = (int)dVar5 * iVar3;
  if (uVar2 < 0x80000000) {
    if (0 < (int)uVar2) {
      uVar2 = 1;
    }
  }
  else {
    uVar2 = 0xffffffff;
  }
  if (*(uint *)(param_1 + 0x204) != uVar2) {
    *(uint *)(param_1 + 0x204) = uVar2;
    FUN_008a4940(&DAT_021377f4);
  }
  if (bVar1) {
    FUN_008a4940(&DAT_02137864);
  }
  return;
}



/* FUNCTION 28921 ; VA 0x00c672e0 ; FUN_00c672e0 */

void __thiscall FUN_00c672e0(int param_1,float param_2)

{
  if ((NAN(*(float *)(param_1 + 0x1fc)) || NAN(param_2)) == (*(float *)(param_1 + 0x1fc) == param_2)
     ) {
    *(float *)(param_1 + 0x1fc) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 28922 ; VA 0x00c67320 ; FUN_00c67320 */

void __thiscall FUN_00c67320(int param_1,float param_2)

{
  if ((NAN(*(float *)(param_1 + 0x1f8)) || NAN(param_2)) == (*(float *)(param_1 + 0x1f8) == param_2)
     ) {
    *(float *)(param_1 + 0x1f8) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 28923 ; VA 0x00c67360 ; FUN_00c67360 */

int * __thiscall FUN_00c67360(int *param_1,int param_2,int *param_3)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  char *pcVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_2 == 0) {
    piVar2 = (int *)0x0;
    ExceptionList = &pvStack_10;
    if (param_1[0x44] != 0) {
      ExceptionList = &pvStack_10;
      piVar2 = (int *)FUN_009c4f20(0);
    }
    goto LAB_00c67497;
  }
  iVar4 = *(int *)(param_2 + 0xc);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0099be20();
  iVar6 = 0;
  if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
      (uint)*(ushort *)(iVar3 + 0x1da)) {
    iVar6 = param_2;
  }
  if ((iVar6 == 0) || (cVar1 = FUN_009b4a80(), cVar1 != '\0')) {
    pcVar7 = "Sit : param is not a Humanoid or humanoid is dead";
  }
  else {
    iVar4 = FUN_009b7250();
    if (iVar4 == 0) {
      pcVar7 = "Sit : Humanoid doesn\'t have HumanoidRootPart";
    }
    else {
      cVar1 = FUN_008b0500(iVar4);
      if ((cVar1 == '\0') || (piVar2 = (int *)FUN_008b0500(param_1), (char)piVar2 == '\0')) {
        pcVar7 = "Sit : Seat or Humanoid is not in Workspace.";
      }
      else {
        if (param_1[0x44] == iVar6) goto LAB_00c67497;
        iVar4 = FUN_00c65730();
        if (iVar4 == 0) {
          piVar2 = *(int **)(iVar6 + 0x194);
          if (piVar2 != (int *)0x0) {
            if (piVar2 == param_1) goto LAB_00c67497;
            iVar4 = piVar2[3];
            iVar3 = FUN_00aff8c0();
            piVar5 = (int *)0x0;
            if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
                (uint)*(ushort *)(iVar3 + 0x1da)) {
              piVar5 = piVar2;
            }
            if (piVar5 != (int *)0x0) {
              (**(code **)(*piVar5 + 0x160))();
            }
          }
          piVar2 = (int *)(**(code **)(*param_1 + 0x15c))(iVar6);
          goto LAB_00c67497;
        }
        pcVar7 = "Sit : This Seat is occupied";
      }
    }
  }
  piVar2 = (int *)FUN_0086f2f0(3,pcVar7);
LAB_00c67497:
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar5 = param_3 + 1;
    iVar4 = *piVar5;
    piVar2 = (int *)*piVar5;
    *piVar5 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      piVar2 = (int *)(**(code **)*param_3)();
      LOCK();
      piVar5 = param_3 + 2;
      iVar4 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        piVar2 = (int *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar2;
}



/* FUNCTION 28924 ; VA 0x00c674e0 ; FUN_00c674e0 */

void __fastcall FUN_00c674e0(int param_1)

{
  float fVar1;
  undefined8 uVar2;
  char cVar3;
  char cVar4;
  bool bVar5;
  bool bVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int *piVar11;
  float10 fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  double dVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  int iStack_48;
  int iStack_44;
  int iStack_34;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  undefined8 uStack_20;
  float fStack_18;
  undefined8 uStack_14;
  
  iVar8 = FUN_00c157b0();
  uVar2 = *(undefined8 *)(iVar8 + 0x30);
  fStack_18 = *(float *)(iVar8 + 0x38);
  uStack_14 = *(undefined8 *)(iVar8 + 0x3c);
  uStack_20._0_4_ = (float)uVar2;
  uStack_20._4_4_ = (float)((ulonglong)uVar2 >> 0x20);
  dVar17 = (double)((float)uStack_20 * (float)uStack_20 + uStack_20._4_4_ * uStack_20._4_4_ +
                   fStack_18 * fStack_18);
  uStack_20 = uVar2;
  FUN_017267a0();
  fVar13 = (float)dVar17;
  bVar5 = fVar13 != *(float *)(param_1 + 500);
  bVar6 = *(float *)(param_1 + 500) <= fVar13;
  iStack_48 = 0;
  fVar14 = (float)(double)CONCAT44((uint)((ulonglong)(double)uStack_14._4_4_ >> 0x20) &
                                   DAT_018c0da0._4_4_,
                                   SUB84((double)uStack_14._4_4_,0) & (uint)DAT_018c0da0);
  fVar1 = *(float *)(param_1 + 0x1f8);
  if (0 < *(int *)(param_1 + 0x21c)) {
    iStack_44 = 2;
    iStack_34 = 4;
    do {
      iVar8 = *(int *)(*(int *)(param_1 + 0x218) + iStack_48 * 4);
      fVar12 = (float10)FUN_01080960();
      fVar19 = DAT_018f7864;
      fVar15 = DAT_018ce2f8;
      fVar21 = (float)fVar12;
      cVar3 = *(char *)(iStack_48 + *(int *)(param_1 + 0x230));
      if (cVar3 == '\0') {
        fVar21 = (float)((uint)fVar21 ^ DAT_018c4ea0);
      }
      cVar4 = *(char *)(*(int *)(param_1 + 0x224) + iStack_48);
      iVar9 = 0;
      if (cVar4 != '\0') {
        iVar9 = iStack_44;
      }
      iVar10 = 0;
      if (fVar1 < fVar14) {
        iVar10 = iStack_34;
      }
      iVar9 = *(int *)(&DAT_0196c940 +
                      (iVar9 + (uint)(bVar6 && bVar5) +
                      (*(int *)(param_1 + 0x208) + *(int *)(param_1 + 0x204) * 2 +
                      *(int *)(param_1 + 0x204)) * 4) * 8 + iVar10);
      if (iVar9 == 0) {
        iVar10 = (uint)(fVar21 <= 0.0) * 2 + -1;
      }
      else {
        iVar10 = -iVar9;
        if (cVar4 != '\0') {
          iVar10 = iVar9;
        }
      }
      iVar9 = -iVar10;
      if (cVar3 != '\0') {
        iVar9 = iVar10;
      }
      if (*(int *)(param_1 + 0x208) == 0) {
        iVar10 = *(int *)(param_1 + 0x224);
        fVar20 = *(float *)(*(int *)(param_1 + 0x23c) + iStack_48 * 4);
        *(float *)(*(int *)(param_1 + 0x23c) + iStack_48 * 4) = fVar21;
        fVar18 = (float)*(int *)(param_1 + 0x204) * uStack_14._4_4_ * DAT_018e3f90;
        fVar16 = fVar15;
        if (fVar18 <= fVar15) {
          fVar16 = fVar18;
        }
        fVar18 = fVar19;
        if (fVar19 <= fVar16) {
          fVar18 = fVar16;
        }
        if (*(char *)(iVar10 + iStack_48) != '\0') {
          fVar18 = fVar18 * fVar19;
        }
        fVar19 = 0.0;
        if (0.0 <= fVar18) {
          fVar19 = fVar18;
        }
        if (*(int *)(param_1 + 0x204) == 0) {
          fVar18 = (float)(double)CONCAT44((uint)((ulonglong)(double)fVar21 >> 0x20) &
                                           DAT_018c0da0._4_4_,
                                           SUB84((double)fVar21,0) & (uint)DAT_018c0da0);
          fVar15 = fVar18 / DAT_018fde94;
          fVar16 = 0.0;
          if (0.0 <= fVar15) {
            fVar16 = fVar15;
          }
          fVar15 = DAT_018ce2f8;
          if (fVar16 <= DAT_018ce2f8) {
            fVar15 = fVar16;
          }
          if (fVar20 * fVar21 < 0.0) {
            dVar17 = (double)(fVar20 - fVar21);
            fVar19 = fVar15 * (fVar18 / (float)(double)CONCAT44((uint)((ulonglong)dVar17 >> 0x20) &
                                                                DAT_018c0da0._4_4_,
                                                                SUB84(dVar17,0) & (uint)DAT_018c0da0
                                                               )) + fVar19;
            goto LAB_00c677a8;
          }
        }
        else if (!bVar6 || !bVar5) {
          dVar17 = (double)(fVar13 - *(float *)(param_1 + 500));
          fVar16 = (float)(double)CONCAT44((uint)((ulonglong)dVar17 >> 0x20) & DAT_018c0da0._4_4_,
                                           SUB84(dVar17,0) & (uint)DAT_018c0da0) - DAT_018ce2f4;
          fVar20 = 0.0;
          if (0.0 <= fVar16) {
            fVar20 = fVar16;
          }
          if (fVar20 <= fVar15) {
            fVar15 = fVar20;
          }
        }
        fVar19 = fVar15 + fVar19;
      }
      else {
        fVar15 = *(float *)(param_1 + 0x1f8);
        fVar19 = DAT_018ce2f8;
        if (NAN(fVar15) == (fVar15 == 0.0)) {
          dVar17 = (double)((fVar15 - fVar14) / fVar15 + DAT_018ce2f8);
          dVar17 = (double)(float)(double)CONCAT44((uint)((ulonglong)dVar17 >> 0x20) &
                                                   DAT_018c0da0._4_4_,
                                                   SUB84(dVar17,0) & (uint)DAT_018c0da0);
          FUN_017267a0();
          fVar19 = (float)dVar17;
        }
      }
LAB_00c677a8:
      if ((float)DAT_01d68888 <
          (float)(double)CONCAT44((uint)((ulonglong)(double)fVar21 >> 0x20) & DAT_018c0da0._4_4_,
                                  SUB84((double)fVar21,0) & (uint)DAT_018c0da0)) {
        fVar19 = 0.0;
      }
      fVar21 = *(float *)(param_1 + 0x1fc) * fVar19 * DAT_018ce324;
      FUN_01080a00(&fStack_2c);
      iVar10 = *(int *)(iVar8 + 0x2c);
      fVar15 = (float)iVar9;
      piVar11 = (int *)(iVar10 + 0x70);
      if (iVar10 == 0) {
        piVar11 = (int *)&DAT_00000020;
      }
      fVar19 = fStack_24 * fVar15 * fVar21;
      iVar9 = *(int *)(*piVar11 + 0x2c);
      fVar20 = fStack_28 * fVar15 * fVar21;
      fVar21 = fStack_2c * fVar15 * fVar21;
      if (iVar9 != 0) {
        FUN_00f9f070();
        *(float *)(iVar9 + 0x170) = fVar21 + *(float *)(iVar9 + 0x170);
        *(float *)(iVar9 + 0x174) = *(float *)(iVar9 + 0x174) + fVar20;
        *(float *)(iVar9 + 0x178) = *(float *)(iVar9 + 0x178) + fVar19;
      }
      iVar8 = *(int *)(iVar8 + 0x30);
      piVar11 = (int *)(iVar8 + 0x70);
      if (iVar8 == 0) {
        piVar11 = (int *)&DAT_00000020;
      }
      iVar8 = *(int *)(*piVar11 + 0x2c);
      if (iVar8 != 0) {
        FUN_00f9f070();
        uVar7 = DAT_018c4ea0;
        *(float *)(iVar8 + 0x170) = (float)((uint)fVar21 ^ DAT_018c4ea0) + *(float *)(iVar8 + 0x170)
        ;
        *(float *)(iVar8 + 0x174) = (float)((uint)fVar20 ^ uVar7) + *(float *)(iVar8 + 0x174);
        *(float *)(iVar8 + 0x178) = (float)((uint)fVar19 ^ uVar7) + *(float *)(iVar8 + 0x178);
      }
      iStack_48 = iStack_48 + 1;
    } while (iStack_48 < *(int *)(param_1 + 0x21c));
  }
  return;
}



/* FUNCTION 28925 ; VA 0x00c67940 ; FUN_00c67940 */

uint __fastcall FUN_00c67940(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  uVar2 = FUN_00c65cd0();
  if ((((*(int *)(param_1 + 0xe4) != 0) || (*(int *)(param_1 + 0xe8) != 0)) &&
      (*(int *)(param_1 + 0xf4) != 0)) && (iVar3 = 0, 0 < *(int *)(param_1 + 0xfc))) {
    do {
      iVar1 = *(int *)(*(int *)(param_1 + 0xf8) + iVar3 * 4);
      FUN_00bc1c10(*(undefined4 *)(iVar1 + 0x2c),1);
      uVar2 = FUN_00bc1c10(*(undefined4 *)(iVar1 + 0x30),1);
      iVar3 = iVar3 + 1;
    } while (iVar3 < *(int *)(param_1 + 0xfc));
  }
  return uVar2 & 0xffffff00;
}



/* FUNCTION 28926 ; VA 0x00c679c0 ; FUN_00c679c0 */

int * __thiscall
FUN_00c679c0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d64cb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c67ac0();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::SkateboardController,float>::
              GetImpl<float_(__thiscall_RBX::SkateboardController::*)(void)const_>::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_7,param_8,param_9,param_10,param_11,param_11,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::SkateboardController,float>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::SkateboardController,float>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28927 ; VA 0x00c67ac0 ; FUN_00c67ac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c67ac0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180cff0;
  pvStack_10 = ExceptionList;
  if (DAT_01efe1cc == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efe3e0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efe3e0);
      if (DAT_01efe3e0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00db7610();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"SkateboardController",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01efe3d8 = RBX::Creator<class_RBX::SkateboardController>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efe1d0,&DAT_01efe3d8);
        FUN_016f3654(FUN_01895cf0);
        FUN_016f37bf(&DAT_01efe3e0);
      }
    }
    DAT_01efe1cc = &DAT_01efe1d0;
  }
  ExceptionList = pvStack_10;
  return DAT_01efe1cc;
}



/* FUNCTION 28928 ; VA 0x00c67bc0 ; FUN_00c67bc0 */

int __thiscall FUN_00c67bc0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180d000;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::SkateboardController*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28929 ; VA 0x00c67c92 ; Catch_All@00c67c92 */

void Catch_All_00c67c92(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28930 ; VA 0x00c67cb0 ; FUN_00c67cb0 */

undefined4 * FUN_00c67cb0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180d077;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c67ac0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  uStack_18 = uVar2;
  puVar3 = (undefined4 *)FUN_01674e20(0x94);
  uStack_8._0_1_ = 2;
  puStack_1c = puVar3;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_00db8370();
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::SkateboardController,class_RBX::Controller>::
              vftable;
    puVar3[0x15] = RBX::DescribedCreatable<class_RBX::SkateboardController,class_RBX::Controller>::
                   vftable;
    uVar4 = FUN_00c67ac0();
    puVar3[3] = uVar4;
    *puVar3 = RBX::SkateboardController::vftable;
    puVar3[0x15] = RBX::SkateboardController::vftable;
    puVar3[0x22] = 0;
    puVar3[0x23] = 0;
    puVar3[0x24] = 0;
    uStack_8._0_1_ = 6;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("SkateboardController",0x14);
    uStack_8._0_1_ = 7;
    FUN_008a6520(auStack_34);
    uStack_8._0_1_ = 6;
    if (0xf < uStack_20) {
      uVar6 = uStack_20 + 1;
      uVar5 = auStack_34[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_34[0] - 4);
        uVar6 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c67bc0(puVar3,puStack_1c);
  uStack_14 = 1;
  uStack_8 = 0xb;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28931 ; VA 0x00c67e30 ; FUN_00c67e30 */

void __fastcall FUN_00c67e30(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::SkateboardController>::vftable;
  uVar1 = FUN_00c67ac0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28932 ; VA 0x00c67e70 ; thunk_FUN_00db8530 */

void __fastcall thunk_FUN_00db8530(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Controller::vftable;
  param_1[0x15] = RBX::Controller::vftable;
  if (DAT_01f754a1 != '\0') {
    FUN_016774b0(DAT_01f754a1,"Controller destroyed - %p",param_1);
  }
  FUN_016790b0();
  FUN_00a62ae0();
  param_1[0x15] = RBX::IStepped::vftable;
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = param_1[0x17];
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28933 ; VA 0x00c67e75 ; FUN_00c67e75 */

void FUN_00c67e75(void)

{
  FUN_00c67e90();
  return;
}



/* FUNCTION 28934 ; VA 0x00c67e7d ; FUN_00c67e7d */

void FUN_00c67e7d(void)

{
  FUN_00c67ec0();
  return;
}



/* FUNCTION 28935 ; VA 0x00c67e90 ; FUN_00c67e90 */

undefined4 __thiscall FUN_00c67e90(undefined4 param_1,byte param_2)

{
  FUN_00db8530();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x80);
  }
  return param_1;
}



/* FUNCTION 28936 ; VA 0x00c67ec0 ; FUN_00c67ec0 */

int __thiscall FUN_00c67ec0(int param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  
  FUN_016790b0();
  piVar1 = *(int **)(param_1 + 0x8c);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_00db8530();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x94);
  }
  return param_1;
}



/* FUNCTION 28937 ; VA 0x00c67f10 ; FUN_00c67f10 */

undefined4 * FUN_00c67f10(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c67cb0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28938 ; VA 0x00c67f80 ; FUN_00c67f80 */

void FUN_00c67f80(void)

{
  int iVar1;
  
  if (DAT_01efe3e4 == 0) {
    iVar1 = FUN_00c67ac0();
    DAT_01efe3e4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28939 ; VA 0x00c67fa0 ; FUN_00c67fa0 */

undefined4 * __thiscall FUN_00c67fa0(int param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  *param_2 = 0;
  param_2[1] = 0;
  iVar1 = *(int *)(param_1 + 0x218);
  if (iVar1 != 0) {
    iVar2 = *(int *)(iVar1 + 4);
    piVar3 = (int *)(iVar1 + 4);
    if (iVar2 != 0) {
      while( true ) {
        LOCK();
        iVar1 = *piVar3;
        if (iVar2 == iVar1) {
          *piVar3 = iVar2 + 1;
          iVar1 = iVar2;
        }
        UNLOCK();
        if (iVar1 == iVar2) break;
        iVar2 = *piVar3;
        if (iVar2 == 0) {
          return param_2;
        }
      }
      *param_2 = *(undefined4 *)(param_1 + 0x214);
      param_2[1] = *(undefined4 *)(param_1 + 0x218);
    }
  }
  return param_2;
}



/* FUNCTION 28940 ; VA 0x00c68010 ; FUN_00c68010 */

float10 __fastcall FUN_00c68010(int param_1)

{
  return (float10)*(float *)(param_1 + 0x80);
}



/* FUNCTION 28941 ; VA 0x00c68020 ; FUN_00c68020 */

uint FUN_00c68020(void)

{
  int iVar1;
  
  iVar1 = FUN_00c67ac0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28942 ; VA 0x00c68040 ; FUN_00c68040 */

uint FUN_00c68040(void)

{
  int iVar1;
  
  iVar1 = FUN_00c67ac0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28943 ; VA 0x00c68060 ; FUN_00c68060 */

void FUN_00c68060(undefined4 param_1,undefined4 param_2)

{
  FUN_008a4210(param_1,param_2);
  FUN_00f958f0(param_1,param_2);
  return;
}



/* FUNCTION 28944 ; VA 0x00c68090 ; FUN_00c68090 */

void __fastcall FUN_00c68090(int param_1)

{
  char cVar1;
  
  FUN_008acee0(param_1 + -0x54);
  cVar1 = FUN_00b83620();
  if (cVar1 != '\0') {
    FUN_00c684d0();
  }
  cVar1 = FUN_00b82ab0();
  if (cVar1 != '\0') {
    FUN_00c680d0();
  }
  return;
}



/* FUNCTION 28945 ; VA 0x00c680d0 ; FUN_00c680d0 */

int __fastcall FUN_00c680d0(int param_1)

{
  int *piVar1;
  char cVar2;
  undefined uVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  float fVar9;
  uint in_stack_ffffffa4;
  undefined4 in_stack_ffffffa8;
  undefined4 in_stack_ffffffac;
  undefined4 in_stack_ffffffb0;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined uStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  uint uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d0e0;
  pvStack_10 = ExceptionList;
  uStack_18 = uStack_18 & 0xffffff00;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00554b40();
  if (cVar2 == '\0') {
    iVar5 = FUN_00db9180();
    if (iVar5 == 0) {
      ExceptionList = pvStack_10;
      return 0;
    }
    uStack_38 = 0;
    uStack_34 = 0;
    uStack_30 = (int *)0x0;
    uStack_2c = 0;
    iVar5 = FUN_008f7870(param_1);
    if (iVar5 != 0) {
      uVar3 = FUN_008fbc50();
      in_stack_ffffffb0 = 0xc6827a;
      FUN_01006470(&uStack_38,uVar3);
    }
    if ((char)uStack_38 == '\0') {
      iVar5 = -(uint)(uStack_38._1_1_ != '\0');
    }
    else {
      iVar5 = 1;
    }
    if ((char)uStack_34 == '\0') {
      iVar6 = -(uint)(uStack_34._1_1_ != '\0');
    }
    else {
      iVar6 = 1;
    }
    iVar6 = iVar6 + iVar5;
    if (uStack_38._2_1_ == '\0') {
      uVar7 = (uint)(uStack_38._3_1_ != '\0');
    }
    else {
      uVar7 = 0xffffffff;
    }
    if (uStack_34._2_1_ == '\0') {
      uVar8 = (uint)(uStack_34._3_1_ != '\0');
    }
    else {
      uVar8 = 0xffffffff;
    }
    iStack_14 = uVar7 + uVar8;
    uStack_18 = CONCAT31(uStack_18._1_3_,uStack_30._2_1_);
    uStack_1c = CONCAT31(uStack_1c._1_3_,uStack_30._3_1_);
    goto LAB_00c682de;
  }
  uStack_30 = (int *)FUN_008acee0(param_1);
  iStack_14 = 0;
  iVar6 = 0;
  if (uStack_30 == (int *)0x0) goto LAB_00c682de;
  piVar4 = (int *)FUN_00b82570(&iStack_28);
  iStack_14 = *piVar4;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_24[1] + -1;
    piStack_24[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar5 = piStack_24[2] + -1;
      piStack_24[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  cVar2 = FUN_00b839e0(0x20);
  if (cVar2 == '\0') {
LAB_00c68173:
    uStack_18 = uStack_18 & 0xffffff00;
  }
  else {
    uStack_18 = CONCAT31(uStack_18._1_3_,1);
    if (iStack_14 != 0) goto LAB_00c68173;
  }
  cVar2 = FUN_00b839e0(8);
  if (cVar2 == '\0') {
LAB_00c6818e:
    uStack_1c = uStack_1c & 0xffffff00;
  }
  else {
    uStack_1c = CONCAT31(uStack_1c._1_3_,1);
    if (iStack_14 != 0) goto LAB_00c6818e;
  }
  in_stack_ffffffb0 = 0x61;
  cVar2 = FUN_00b839e0(0x61);
  if ((cVar2 == '\0') || (uStack_30 = (int *)0xffffffff, iStack_14 != 0)) {
    uStack_30 = (int *)0x0;
  }
  in_stack_ffffffac = 100;
  cVar2 = FUN_00b839e0(100);
  if ((cVar2 == '\0') || (piStack_24 = (int *)0x1, iStack_14 != 0)) {
    piStack_24 = (int *)0x0;
  }
  in_stack_ffffffa8 = 0x77;
  cVar2 = FUN_00b839e0(0x77);
  if ((cVar2 == '\0') || (iStack_20 = 1, iStack_14 != 0)) {
    iStack_20 = 0;
  }
  in_stack_ffffffa4 = 0;
  cVar2 = FUN_00b839e0(0x73);
  if ((cVar2 == '\0') || (iStack_14 != 0)) {
    iStack_14 = (int)uStack_30 + (int)piStack_24;
    iVar6 = iStack_20;
  }
  else {
    iStack_14 = (int)uStack_30 + (int)piStack_24;
    iVar6 = iStack_20 + -1;
  }
LAB_00c682de:
  fVar9 = (float)iVar6;
  if ((NAN(*(float *)(param_1 + 0x80)) || NAN(fVar9)) == (*(float *)(param_1 + 0x80) == fVar9)) {
    *(float *)(param_1 + 0x80) = fVar9;
    uVar10 = 0;
    uVar11 = 0xf;
    in_stack_ffffffa4 = in_stack_ffffffa4 & 0xffffff00;
    FUN_005542c0("Throttle",8);
    FUN_006ecaa0(in_stack_ffffffa4,in_stack_ffffffa8,in_stack_ffffffac,in_stack_ffffffb0,uVar10,
                 uVar11);
  }
  fVar9 = (float)iStack_14;
  if ((NAN(*(float *)(param_1 + 0x84)) || NAN(fVar9)) == (*(float *)(param_1 + 0x84) == fVar9)) {
    *(float *)(param_1 + 0x84) = fVar9;
    uVar10 = 0;
    uVar11 = 0xf;
    in_stack_ffffffa4 = in_stack_ffffffa4 & 0xffffff00;
    FUN_005542c0("Steer",5);
    FUN_006ecaa0(in_stack_ffffffa4,in_stack_ffffffa8,in_stack_ffffffac,in_stack_ffffffb0,uVar10,
                 uVar11);
  }
  cVar2 = FUN_00db91c0(0x20);
  if (cVar2 == '\0') {
    FUN_00587490(&iStack_28);
    uStack_8 = 0;
    if (iStack_28 != 0) {
      FUN_00c67fa0(&uStack_34);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (uStack_34 != 0) {
        FUN_009c39b0(uStack_18);
      }
      piVar4 = uStack_30;
      if (uStack_30 != (int *)0x0) {
        LOCK();
        iVar5 = uStack_30[1] + -1;
        uStack_30[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*uStack_30)();
          LOCK();
          piVar1 = piVar4 + 2;
          iVar5 = *piVar1 + -1;
          *piVar1 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
    }
    piVar4 = piStack_24;
    uStack_8 = 0xffffffff;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_24[1] + -1;
      piStack_24[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  else {
    FUN_00db96d0(0x20,uStack_18);
  }
  iVar5 = FUN_00db96d0(8,uStack_1c);
  if ((char)uStack_1c != '\0') {
    iVar5 = FUN_00587490(&iStack_28);
    uStack_8 = 2;
    if (iStack_28 != 0) {
      iVar5 = FUN_00c67fa0(&uStack_34);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      if (uStack_34 != 0) {
        iVar5 = FUN_009c39b0(1);
      }
      piVar4 = uStack_30;
      if (uStack_30 != (int *)0x0) {
        LOCK();
        piVar1 = uStack_30 + 1;
        iVar6 = *piVar1;
        iVar5 = *piVar1;
        *piVar1 = iVar6 + -1;
        UNLOCK();
        if (iVar6 + -1 == 0) {
          (**(code **)*uStack_30)();
          LOCK();
          piVar1 = piVar4 + 2;
          iVar6 = *piVar1;
          iVar5 = *piVar1;
          *piVar1 = iVar6 + -1;
          UNLOCK();
          if (iVar6 + -1 == 0) {
            iVar5 = (**(code **)(*piVar4 + 4))();
          }
        }
      }
    }
    piVar4 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_24 + 1;
      iVar6 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar5 = (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar6 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          iVar5 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 28946 ; VA 0x00c684d0 ; FUN_00c684d0 */

uint __fastcall FUN_00c684d0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  undefined8 *puVar3;
  uint uVar4;
  int iVar5;
  float fVar6;
  uint uVar7;
  undefined uVar8;
  undefined *puVar9;
  float fStack_30;
  float fStack_2c;
  int iStack_24;
  int *piStack_20;
  uint uStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d100;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar7 = FUN_00587490(&iStack_24);
  uStack_8 = 0;
  if (iStack_24 == 0) goto LAB_00c68694;
  FUN_00c67fa0(&uStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (uStack_1c != 0) {
    puVar3 = (undefined8 *)(uStack_1c + 0x1c8);
    fVar6 = *(float *)(uStack_1c + 0x1d0);
    fStack_30 = (float)*puVar3;
    uVar8 = SUB41(fVar6,0);
    uStack_1c = (uint)CONCAT11((fStack_30 == 0.0) << 6 | NAN(fStack_30) << 2 | 2U | fStack_30 < 0.0,
                               uVar8);
    if (NAN(fStack_30) != (fStack_30 == 0.0)) {
      fStack_2c = (float)((ulonglong)*puVar3 >> 0x20);
      uStack_1c = (uint)CONCAT11((fStack_2c == 0.0) << 6 | NAN(fStack_2c) << 2 | 2U |
                                 fStack_2c < 0.0,uVar8);
      if ((NAN(fStack_2c) != (fStack_2c == 0.0)) &&
         (uStack_1c = (uint)CONCAT11((fVar6 == 0.0) << 6 | NAN(fVar6) << 2 | 2U | fVar6 < 0.0,uVar8)
         , NAN(fVar6) != (fVar6 == 0.0))) {
        if (NAN(*(float *)(param_1 + 0x80)) == (*(float *)(param_1 + 0x80) == 0.0)) {
          *(undefined4 *)(param_1 + 0x80) = 0;
          uVar8 = 0;
          FUN_005542c0("Throttle",8);
          uVar8 = FUN_006ecaa0(uVar8);
        }
        fVar6 = *(float *)(param_1 + 0x84);
        uStack_1c = (uint)CONCAT11((fVar6 == 0.0) << 6 | NAN(fVar6) << 2 | 2U | fVar6 < 0.0,uVar8);
        if (NAN(fVar6) == (fVar6 == 0.0)) {
          *(undefined4 *)(param_1 + 0x84) = 0;
          uVar8 = 0;
          FUN_005542c0("Steer",5);
          uStack_1c = FUN_006ecaa0(uVar8);
        }
        goto LAB_00c6866e;
      }
    }
    if (fVar6 <= 0.0) {
      if (fVar6 < 0.0) {
        puVar9 = (undefined *)0x3f800000;
        goto LAB_00c6862e;
      }
    }
    else {
      puVar9 = &DAT_bf800000;
LAB_00c6862e:
      uStack_1c = FUN_00c687b0(puVar9);
    }
    if (DAT_0196d7a0 <= (double)fStack_30) {
      if ((double)fStack_30 <= DAT_018e2380) goto LAB_00c6866e;
      puVar9 = (undefined *)0x3f800000;
    }
    else {
      puVar9 = &DAT_bf800000;
    }
    uStack_1c = FUN_00c68750(puVar9);
  }
LAB_00c6866e:
  uVar7 = uStack_1c;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_18 + 1);
    uVar4 = *puVar1;
    uVar7 = *puVar1;
    *puVar1 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      puVar1 = (uint *)(piStack_18 + 2);
      uVar4 = *puVar1;
      uVar7 = *puVar1;
      *puVar1 = uVar4 - 1;
      UNLOCK();
      if (uVar4 - 1 == 0) {
        uVar7 = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
LAB_00c68694:
  if (piStack_20 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piStack_20 + 1);
    uVar4 = *puVar1;
    uVar7 = *puVar1;
    *puVar1 = uVar4 - 1;
    UNLOCK();
    if (uVar4 - 1 == 0) {
      uVar7 = (**(code **)*piStack_20)();
      LOCK();
      piVar2 = piStack_20 + 2;
      iVar5 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        uVar7 = (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 28947 ; VA 0x00c686d0 ; FUN_00c686d0 */

int __thiscall FUN_00c686d0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  piVar2 = (int *)FUN_0060dcd0(auStack_c,param_2);
  iVar4 = piVar2[1];
  if (iVar4 != 0) {
    LOCK();
    *(int *)(iVar4 + 8) = *(int *)(iVar4 + 8) + 1;
    UNLOCK();
    iVar4 = piVar2[1];
  }
  iVar3 = *piVar2;
  *(int *)(param_1 + 0x88) = iVar3;
  piVar2 = *(int **)(param_1 + 0x8c);
  *(int *)(param_1 + 0x8c) = iVar4;
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar4 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar3 = (**(code **)(*piVar2 + 4))();
    }
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_8 + 1;
    iVar4 = *piVar2;
    iVar3 = *piVar2;
    *piVar2 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      iVar3 = (**(code **)*piStack_8)();
      LOCK();
      piVar2 = piStack_8 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        iVar3 = (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  return iVar3;
}



/* FUNCTION 28948 ; VA 0x00c68750 ; FUN_00c68750 */

void __thiscall FUN_00c68750(int param_1,float param_2)

{
  undefined uVar1;
  
  if ((NAN(*(float *)(param_1 + 0x84)) || NAN(param_2)) == (*(float *)(param_1 + 0x84) == param_2))
  {
    *(float *)(param_1 + 0x84) = param_2;
    uVar1 = 0;
    FUN_005542c0("Steer",5);
    FUN_006ecaa0(uVar1);
  }
  return;
}



/* FUNCTION 28949 ; VA 0x00c687b0 ; FUN_00c687b0 */

void __thiscall FUN_00c687b0(int param_1,float param_2)

{
  undefined uVar1;
  
  if ((NAN(*(float *)(param_1 + 0x80)) || NAN(param_2)) == (*(float *)(param_1 + 0x80) == param_2))
  {
    *(float *)(param_1 + 0x80) = param_2;
    uVar1 = 0;
    FUN_005542c0("Throttle",8);
    FUN_006ecaa0(uVar1);
  }
  return;
}



/* FUNCTION 28950 ; VA 0x00c68810 ; FUN_00c68810 */

int * __thiscall
FUN_00c68810(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baf8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c68a10();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ScreenGui,bool>::
              GetSetImpl<bool_(__thiscall_RBX::ScreenGui::*)(void)const_,void_(__thiscall_RBX::ScreenGui::*)(bool)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::ScreenGui,bool>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::ScreenGui,bool>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28951 ; VA 0x00c68910 ; FUN_00c68910 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c68910(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d130;
  pvStack_10 = ExceptionList;
  if (DAT_01efe3f4 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efe608) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efe608);
      if (DAT_01efe608 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c68a10();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"GuiMain",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01efe600 = RBX::Creator<class_RBX::GuiMain>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efe3f8,&DAT_01efe600);
        FUN_016f3654(FUN_01895db0);
        FUN_016f37bf(&DAT_01efe608);
      }
    }
    DAT_01efe3f4 = &DAT_01efe3f8;
  }
  ExceptionList = pvStack_10;
  return DAT_01efe3f4;
}



/* FUNCTION 28952 ; VA 0x00c68a10 ; FUN_00c68a10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c68a10(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d160;
  pvStack_10 = ExceptionList;
  if (DAT_01efe610 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efe828) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efe828);
      if (DAT_01efe828 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00d5e4a0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ScreenGui",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01efe820 = RBX::Creator<class_RBX::ScreenGui>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efe618,&DAT_01efe820);
        FUN_016f3654(FUN_01895e10);
        FUN_016f37bf(&DAT_01efe828);
      }
    }
    DAT_01efe610 = &DAT_01efe618;
  }
  ExceptionList = pvStack_10;
  return DAT_01efe610;
}



/* FUNCTION 28953 ; VA 0x00c68b10 ; FUN_00c68b10 */

int __thiscall FUN_00c68b10(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180d170;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::GuiMain*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28954 ; VA 0x00c68be2 ; Catch_All@00c68be2 */

void Catch_All_00c68be2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28955 ; VA 0x00c68c00 ; FUN_00c68c00 */

undefined4 * FUN_00c68c00(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180d1c3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c68910();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x280);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_00d62500(PTR_s_GuiMain_0196d7a8);
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::ScreenGui,class_RBX::GuiLayerCollector>::vftable;
    puVar3[0x15] = RBX::DescribedCreatable<class_RBX::ScreenGui,class_RBX::GuiLayerCollector>::
                   vftable;
    puVar3[0x52] = RBX::DescribedCreatable<class_RBX::ScreenGui,class_RBX::GuiLayerCollector>::
                   vftable;
    puVar3[0x54] = RBX::DescribedCreatable<class_RBX::ScreenGui,class_RBX::GuiLayerCollector>::
                   vftable;
    uVar4 = FUN_00c68a10();
    puVar3[3] = uVar4;
    *puVar3 = RBX::ScreenGui::vftable;
    puVar3[0x15] = RBX::ScreenGui::vftable;
    puVar3[0x52] = RBX::ScreenGui::vftable;
    puVar3[0x54] = RBX::ScreenGui::vftable;
    puVar3[0x7e] = 0x3f800000;
    puVar3[0x7f] = 0;
    puVar3[0x80] = 0;
    puVar3[0x81] = 0;
    puVar3[0x82] = 0x3f800000;
    puVar3[0x83] = 0;
    puVar3[0x84] = 0;
    puVar3[0x85] = 0;
    puVar3[0x86] = 0x3f800000;
    puVar3[0x87] = 0;
    puVar3[0x88] = 0;
    puVar3[0x89] = 0;
    puVar3[0x8a] = 0x3f800000;
    puVar3[0x8b] = 0;
    puVar3[0x8c] = 0;
    puVar3[0x8d] = 0;
    puVar3[0x8e] = 0x3f800000;
    puVar3[0x8f] = 0;
    puVar3[0x90] = 0;
    puVar3[0x91] = 0;
    puVar3[0x92] = 0x3f800000;
    puVar3[0x93] = 0;
    puVar3[0x94] = 0;
    puVar3[0x95] = 0;
    *(undefined2 *)(puVar3 + 0x96) = 0;
    *(undefined *)((int)puVar3 + 0x25a) = 0;
    puVar3[0x97] = 0;
    puVar3[0x98] = 0;
    puVar3[0x99] = 0;
    *(undefined *)(puVar3 + 0x9a) = 0;
    uVar4 = FUN_00588320(0xb);
    puVar3[0x9b] = uVar4;
    puVar3[0x9c] = 0;
    puVar3[0x9d] = 0x3f800000;
    puVar3[0x9e] = 0;
    puVar3[0x9f] = 0;
    puVar3[0x59] = 0;
    puVar3[0x5a] = 0;
    puVar3[0x5b] = 0x44480000;
    puVar3[0x5c] = 0x44160000;
    uStack_8._0_1_ = 4;
    *puVar3 = RBX::DescribedCreatable<class_RBX::GuiMain,class_RBX::ScreenGui>::vftable;
    puVar3[0x15] = RBX::DescribedCreatable<class_RBX::GuiMain,class_RBX::ScreenGui>::vftable;
    puVar3[0x52] = RBX::DescribedCreatable<class_RBX::GuiMain,class_RBX::ScreenGui>::vftable;
    puVar3[0x54] = RBX::DescribedCreatable<class_RBX::GuiMain,class_RBX::ScreenGui>::vftable;
    uVar4 = FUN_00c68910();
    puVar3[3] = uVar4;
    *puVar3 = RBX::GuiMain::vftable;
    puVar3[0x15] = RBX::GuiMain::vftable;
    puVar3[0x52] = RBX::GuiMain::vftable;
    puVar3[0x54] = RBX::GuiMain::vftable;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c68b10(puVar3,param_1);
  uStack_8 = 8;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28956 ; VA 0x00c68ef0 ; FUN_00c68ef0 */

undefined4 * __fastcall FUN_00c68ef0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d1d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00d62500(PTR_s_ScreenGui_0196d7ac);
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::ScreenGui,class_RBX::GuiLayerCollector>::vftable;
  param_1[0x15] =
       RBX::DescribedCreatable<class_RBX::ScreenGui,class_RBX::GuiLayerCollector>::vftable;
  param_1[0x52] =
       RBX::DescribedCreatable<class_RBX::ScreenGui,class_RBX::GuiLayerCollector>::vftable;
  param_1[0x54] =
       RBX::DescribedCreatable<class_RBX::ScreenGui,class_RBX::GuiLayerCollector>::vftable;
  uVar1 = FUN_00c68a10();
  param_1[3] = uVar1;
  *param_1 = RBX::ScreenGui::vftable;
  param_1[0x15] = RBX::ScreenGui::vftable;
  param_1[0x52] = RBX::ScreenGui::vftable;
  param_1[0x54] = RBX::ScreenGui::vftable;
  param_1[0x7e] = 0x3f800000;
  param_1[0x7f] = 0;
  param_1[0x80] = 0;
  param_1[0x81] = 0;
  param_1[0x82] = 0x3f800000;
  param_1[0x83] = 0;
  param_1[0x84] = 0;
  param_1[0x85] = 0;
  param_1[0x86] = 0x3f800000;
  param_1[0x87] = 0;
  param_1[0x88] = 0;
  param_1[0x89] = 0;
  param_1[0x8a] = 0x3f800000;
  param_1[0x8b] = 0;
  param_1[0x8c] = 0;
  param_1[0x8d] = 0;
  param_1[0x8e] = 0x3f800000;
  param_1[0x8f] = 0;
  param_1[0x90] = 0;
  param_1[0x91] = 0;
  param_1[0x92] = 0x3f800000;
  param_1[0x93] = 0;
  param_1[0x94] = 0;
  param_1[0x95] = 0;
  *(undefined2 *)(param_1 + 0x96) = 0;
  *(undefined *)((int)param_1 + 0x25a) = 0;
  param_1[0x97] = 0;
  param_1[0x98] = 0;
  param_1[0x99] = 0;
  *(undefined *)(param_1 + 0x9a) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[0x9b] = uVar1;
  param_1[0x9c] = 0;
  param_1[0x9d] = 0x3f800000;
  param_1[0x9e] = 0;
  param_1[0x9f] = 0;
  param_1[0x59] = 0;
  param_1[0x5a] = 0;
  param_1[0x5b] = 0x44480000;
  param_1[0x5c] = 0x44160000;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28957 ; VA 0x00c69110 ; FUN_00c69110 */

void __fastcall FUN_00c69110(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::GuiMain>::vftable;
  uVar1 = FUN_00c68910(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28958 ; VA 0x00c69150 ; FUN_00c69150 */

void __fastcall FUN_00c69150(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::ScreenGui>::vftable;
  uVar1 = FUN_00c68a10(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28959 ; VA 0x00c69190 ; FUN_00c69190 */

void __fastcall FUN_00c69190(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)(param_1 + 4);
  if (iVar3 != 0) {
    ExceptionList = &pvStack_10;
    if (*(char *)(param_1 + 9) != '\0') {
      uStack_8 = 0;
      ExceptionList = &pvStack_10;
      FUN_01679490();
      iVar3 = *(int *)(iVar3 + 0xc);
      if (iVar3 != 0) {
        piVar1 = (int *)(iVar3 + 4);
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(iVar3);
        }
      }
    }
    FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x10);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28960 ; VA 0x00c69210 ; FUN_00c69210 */

void __fastcall FUN_00c69210(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      ExceptionList = &pvStack_10;
      FUN_00c697d0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28961 ; VA 0x00c692b0 ; FUN_00c692b0 */

void __fastcall FUN_00c692b0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      ExceptionList = &pvStack_10;
      FUN_00c697d0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28962 ; VA 0x00c692c0 ; FUN_00c692c0 */

void __fastcall FUN_00c692c0(undefined4 *param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::ScreenGui::vftable;
  param_1[0x15] = RBX::ScreenGui::vftable;
  param_1[0x52] = RBX::ScreenGui::vftable;
  param_1[0x54] = RBX::ScreenGui::vftable;
  param_1[0x98] = param_1[0x97];
  if (param_1[0x9c] != 0) {
    FUN_00c697d0(param_1[0x9f] + param_1[0x9b] * 4,0);
    puVar3 = (undefined4 *)param_1[0x9f];
    puVar1 = puVar3 + param_1[0x9b];
    for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
      *puVar3 = 0;
    }
  }
  FUN_00c69210();
  iVar2 = param_1[0x97];
  if (iVar2 != 0) {
    uVar5 = param_1[0x99] - iVar2 & 0xfffffffc;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar5 + 0x23;
      if (0x1f < (iVar2 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    param_1[0x97] = 0;
    param_1[0x98] = 0;
    param_1[0x99] = 0;
  }
  FUN_00d62a80();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28963 ; VA 0x00c693c0 ; FUN_00c693c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c693c0(int param_1,uint *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180d1f8;
  pvStack_10 = ExceptionList;
  uVar3 = *param_2;
  uVar8 = (uVar3 >> 3) + uVar3;
  uVar7 = uVar8 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) != 0) {
    puVar5 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puVar5 = (undefined4 *)*puVar5;
    }
    for (; puVar5 != (undefined4 *)0x0; puVar5 = (undefined4 *)*puVar5) {
      if (uVar8 == puVar5[1]) {
        if (uVar3 == puVar5[2]) {
          if (puVar5 != (undefined4 *)0x0) {
            return puVar5 + 2;
          }
          break;
        }
      }
      else if ((uint)puVar5[1] % *(uint *)(param_1 + 4) != uVar7) break;
    }
  }
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00c69650();
  _DAT_0000000c = 0;
  uVar1 = *(uint *)(param_1 + 8);
  uVar7 = uVar1 + 1;
  _DAT_00000008 = uVar3;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar3 = FUN_005d6bb0(uVar7);
    if (uVar3 <= *(uint *)(param_1 + 4)) {
      uVar3 = *(uint *)(param_1 + 4);
    }
    FUN_00780ee0(uVar3);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    uVar3 = uVar1 >> 1;
    if (uVar1 + (uVar1 >> 1) <= uVar7) {
      uVar3 = 1;
    }
    iVar4 = FUN_005d6bb0(uVar3 + uVar1);
    if (iVar4 != *(int *)(param_1 + 4)) {
      FUN_00780ee0(iVar4);
      puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar2 = (undefined4 *)*puVar5;
      while (puVar2 != (undefined4 *)0x0) {
        uVar3 = (uint)puVar2[1] % *(uint *)(param_1 + 4);
        piVar6 = (int *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar3 * 4) == 0) {
          *piVar6 = (int)puVar5;
          puVar5 = puVar2;
        }
        else {
          *puVar5 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar6;
          *(undefined4 **)*piVar6 = puVar2;
        }
        puVar2 = (undefined4 *)*puVar5;
      }
    }
  }
  uVar3 = uVar8 % *(uint *)(param_1 + 4);
  piVar6 = *(int **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  _DAT_00000004 = uVar8;
  if (piVar6 == (int *)0x0) {
    piVar6 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar6 != 0) {
      *(undefined4 *)
       (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar6 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
    }
    *puVar5 = piVar6;
    _DAT_00000000 = *piVar6;
  }
  else {
    _DAT_00000000 = *piVar6;
    piVar6 = (int *)*puVar5;
  }
  *piVar6 = 0;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return (undefined4 *)&DAT_00000008;
}



/* FUNCTION 28964 ; VA 0x00c6957d ; FUN_00c6957d */

void FUN_00c6957d(void)

{
  FUN_00c695b0();
  return;
}



/* FUNCTION 28965 ; VA 0x00c69588 ; FUN_00c69588 */

void FUN_00c69588(void)

{
  FUN_00c695b0();
  return;
}



/* FUNCTION 28966 ; VA 0x00c69593 ; FUN_00c69593 */

void FUN_00c69593(void)

{
  FUN_00c695e0();
  return;
}



/* FUNCTION 28967 ; VA 0x00c6959e ; FUN_00c6959e */

void FUN_00c6959e(void)

{
  FUN_00c695e0();
  return;
}



/* FUNCTION 28968 ; VA 0x00c695b0 ; FUN_00c695b0 */

undefined4 __thiscall FUN_00c695b0(undefined4 param_1,byte param_2)

{
  FUN_00c692c0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x280);
  }
  return param_1;
}



/* FUNCTION 28969 ; VA 0x00c695e0 ; FUN_00c695e0 */

undefined4 __thiscall FUN_00c695e0(undefined4 param_1,byte param_2)

{
  FUN_00d62a80();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1f8);
  }
  return param_1;
}



/* FUNCTION 28970 ; VA 0x00c69610 ; FUN_00c69610 */

bool FUN_00c69610(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00d59db0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) goto LAB_00c69642;
  }
  param_1 = 0;
LAB_00c69642:
  return param_1 == 0;
}



/* FUNCTION 28971 ; VA 0x00c69650 ; FUN_00c69650 */

void __fastcall FUN_00c69650(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)(param_1 + 4);
  if (iVar3 == 0) {
    ExceptionList = &pvStack_10;
    *(undefined2 *)(param_1 + 8) = 0;
    puVar4 = (undefined4 *)FUN_01674e20(0x10);
    *(undefined4 **)(param_1 + 4) = puVar4;
    *puVar4 = 0;
    puVar4[1] = 0;
    *(undefined8 *)(puVar4 + 2) = 0;
    *(undefined *)(param_1 + 8) = 1;
    ExceptionList = pvStack_10;
    return;
  }
  if (*(char *)(param_1 + 9) != '\0') {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_01679490();
    iVar3 = *(int *)(iVar3 + 0xc);
    if (iVar3 != 0) {
      piVar1 = (int *)(iVar3 + 4);
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(iVar3);
      }
    }
    *(undefined *)(param_1 + 9) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28972 ; VA 0x00c696f0 ; FUN_00c696f0 */

undefined4 * FUN_00c696f0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c68c00(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28973 ; VA 0x00c69760 ; FUN_00c69760 */

undefined4 * FUN_00c69760(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00b59600(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28974 ; VA 0x00c697d0 ; FUN_00c697d0 */

int __thiscall FUN_00c697d0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar4 = 0;
  puVar5 = (undefined4 *)*param_2;
  ExceptionList = &pvStack_10;
  do {
    *param_2 = *puVar5;
    uStack_8 = 0;
    FUN_01679490();
    iVar3 = puVar5[3];
    if (iVar3 != 0) {
      piVar1 = (int *)(iVar3 + 4);
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(iVar3);
      }
    }
    uStack_8 = 0xffffffff;
    FUN_01674ea0(puVar5,0x10);
    iVar4 = iVar4 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar5 = (undefined4 *)*param_2;
  } while (puVar5 != param_3);
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 28975 ; VA 0x00c69870 ; FUN_00c69870 */

void FUN_00c69870(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x1c);
  if (*(char *)(iVar1 + 0x46e) != '\0') {
    FUN_00c69ac0(iVar1);
    return;
  }
  FUN_00c6a350(iVar1);
  return;
}



/* FUNCTION 28976 ; VA 0x00c698a0 ; FUN_00c698a0 */

void __thiscall FUN_00c698a0(int *param_1,float *param_2)

{
  float fVar1;
  int iVar2;
  
  (**(code **)(*param_1 + 0x100))("AbsolutePosition");
  iVar2 = FUN_006ebc30(param_1);
  if (iVar2 != 0) {
    fVar1 = *(float *)(iVar2 + 0xfc);
    *param_2 = (float)param_1[0x26] - *(float *)(iVar2 + 0xf8);
    param_2[1] = (float)param_1[0x27] - fVar1;
    return;
  }
  *param_2 = (float)param_1[0x26];
  param_2[1] = (float)param_1[0x27];
  return;
}



/* FUNCTION 28977 ; VA 0x00c69910 ; FUN_00c69910 */

void FUN_00c69910(void)

{
  int iVar1;
  
  if (DAT_01efe60c == 0) {
    iVar1 = FUN_00c68910();
    DAT_01efe60c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28978 ; VA 0x00c69930 ; FUN_00c69930 */

void FUN_00c69930(void)

{
  int iVar1;
  
  if (DAT_01efe82c == 0) {
    iVar1 = FUN_00c68a10();
    DAT_01efe82c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28979 ; VA 0x00c69950 ; FUN_00c69950 */

undefined __fastcall FUN_00c69950(int param_1)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined uVar4;
  int iStack_c;
  int *piStack_8;
  
  cVar2 = FUN_00c69ba0();
  if ((cVar2 != '\0') && (iVar3 = FUN_008accc0(param_1), iVar3 != 0)) {
    FUN_00b5efb0(&iStack_c);
    if ((iStack_c == 0) || (iStack_c != param_1)) {
      uVar4 = 1;
    }
    else {
      uVar4 = 0;
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piStack_8 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return uVar4;
  }
  return 0;
}



/* FUNCTION 28980 ; VA 0x00c699d0 ; FUN_00c699d0 */

undefined4 __fastcall FUN_00c699d0(int param_1)

{
  undefined4 uVar1;
  
  if ((DAT_01d6889c != '\0') || (uVar1 = 0x7fffffff, *(char *)(param_1 + 0x25a) == '\0')) {
    uVar1 = *(undefined4 *)(param_1 + 0x68);
  }
  return uVar1;
}



/* FUNCTION 28981 ; VA 0x00c69a20 ; FUN_00c69a20 */

undefined __fastcall FUN_00c69a20(int param_1)

{
  return *(undefined *)(param_1 + 0x25a);
}



/* FUNCTION 28982 ; VA 0x00c69a30 ; FUN_00c69a30 */

void __thiscall FUN_00c69a30(int param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  
  fVar4 = *(float *)(param_1 + 0xf0) - *(float *)(param_1 + 0x100);
  fVar5 = *(float *)(param_1 + 0xf8) + *(float *)(param_1 + 0xe8);
  fVar2 = *(float *)(param_1 + 0xf4) - *(float *)(param_1 + 0x104);
  fVar3 = *(float *)(param_1 + 0xfc) + *(float *)(param_1 + 0xec);
  fVar1 = fVar4;
  if (fVar5 <= fVar4) {
    fVar1 = fVar5;
  }
  param_2[3] = 0.0;
  *param_2 = fVar1;
  fVar1 = fVar3;
  if (fVar2 < fVar3) {
    fVar1 = fVar2;
  }
  param_2[1] = fVar1;
  if (fVar4 <= fVar5) {
    fVar4 = fVar5;
  }
  param_2[2] = fVar4;
  if (fVar2 <= fVar3) {
    fVar2 = fVar3;
  }
  param_2[3] = fVar2;
  return;
}



/* FUNCTION 28983 ; VA 0x00c69ac0 ; FUN_00c69ac0 */

undefined4 __thiscall FUN_00c69ac0(int param_1,int param_2)

{
  int *piVar1;
  
  for (piVar1 = *(int **)(param_1 + 0x25c); piVar1 != *(int **)(param_1 + 0x260);
      piVar1 = piVar1 + 1) {
    if (*piVar1 == param_2) {
      return 0;
    }
  }
  piVar1 = *(int **)(param_1 + 0x260);
  if (*(int **)(param_1 + 0x264) == piVar1) {
    FUN_006030d0(piVar1,&param_2);
    return 1;
  }
  *piVar1 = param_2;
  *(int *)(param_1 + 0x260) = *(int *)(param_1 + 0x260) + 4;
  return 1;
}



/* FUNCTION 28984 ; VA 0x00c69b20 ; FUN_00c69b20 */

uint FUN_00c69b20(void)

{
  int iVar1;
  
  iVar1 = FUN_00c68910();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28985 ; VA 0x00c69b40 ; FUN_00c69b40 */

uint FUN_00c69b40(void)

{
  int iVar1;
  
  iVar1 = FUN_00c68a10();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28986 ; VA 0x00c69b60 ; FUN_00c69b60 */

uint FUN_00c69b60(void)

{
  int iVar1;
  
  iVar1 = FUN_00c68910();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28987 ; VA 0x00c69b80 ; FUN_00c69b80 */

uint FUN_00c69b80(void)

{
  int iVar1;
  
  iVar1 = FUN_00c68a10();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28988 ; VA 0x00c69ba0 ; FUN_00c69ba0 */

undefined __fastcall FUN_00c69ba0(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  int iStack_c;
  int *piStack_8;
  
  iVar2 = FUN_008accc0(param_1);
  if (iVar2 != 0) {
    FUN_00b5efb0(&iStack_c);
    if ((*(char *)(iVar2 + 0x94) == '\0') || ((iStack_c != 0 && (iStack_c == param_1)))) {
      uVar3 = 0;
    }
    else {
      uVar3 = 1;
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_8[1] + -1;
      piStack_8[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piStack_8 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return uVar3;
  }
  return 0;
}



/* FUNCTION 28989 ; VA 0x00c69c20 ; FUN_00c69c20 */

undefined4 FUN_00c69c20(float *param_1)

{
  float *pfVar1;
  undefined auStack_14 [16];
  
  pfVar1 = (float *)FUN_00d5c5d0(auStack_14);
  if ((((*param_1 <= pfVar1[2] && pfVar1[2] != *param_1) &&
       (param_1[1] <= pfVar1[3] && pfVar1[3] != param_1[1])) &&
      (*pfVar1 <= param_1[2] && param_1[2] != *pfVar1)) &&
     (pfVar1[1] <= param_1[3] && param_1[3] != pfVar1[1])) {
    return 1;
  }
  return 0;
}



/* FUNCTION 28990 ; VA 0x00c69c70 ; FUN_00c69c70 */

void __thiscall FUN_00c69c70(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  
  FUN_00d5cef0(param_2);
  iVar1 = *(int *)(param_1 + 0x34);
  do {
    if (iVar1 == 0) {
      cVar3 = '\0';
LAB_00c69cba:
      if (cVar3 != *(char *)(param_1 + 600)) {
        *(char *)(param_1 + 600) = cVar3;
        FUN_0115b050();
      }
      return;
    }
    iVar2 = *(int *)(iVar1 + 0xc);
    iVar4 = FUN_00b56cd0();
    iVar5 = 0;
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da)) {
      iVar5 = iVar1;
    }
    if (iVar5 != 0) {
      cVar3 = '\x01';
      goto LAB_00c69cba;
    }
    iVar1 = *(int *)(iVar1 + 0x34);
  } while( true );
}



/* FUNCTION 28991 ; VA 0x00c69ce0 ; FUN_00c69ce0 */

void __thiscall FUN_00c69ce0(undefined4 param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar3 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0180d261;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00d66e70(param_2);
  if ((iVar3 != 0) &&
     (iVar2 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00c6dcc0(),
     (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
     (uint)*(ushort *)(iVar5 + 0x1da))) {
    iStack_8 = 0;
    uVar6 = FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 1;
    puStack_14 = (undefined4 *)FUN_01674e20(0x20);
    if (puStack_14 == (undefined4 *)0x0) {
      puStack_14 = (undefined4 *)0x0;
    }
    else {
      *puStack_14 = 0;
      puStack_14[1] = 1;
      puStack_14[2] = FUN_00c69870;
      puStack_14[3] = _guard_check_icall;
      puStack_14[4] = 0;
      puStack_14[5] = iVar3 + 0x4c;
      puStack_14[6] = param_1;
      puStack_14[7] = iVar3;
    }
    FUN_016797d0(puStack_14);
    if (puStack_14 != (undefined4 *)0x0) {
      LOCK();
      puStack_14[1] = puStack_14[1] + 1;
      UNLOCK();
    }
    iStack_8._0_1_ = 2;
    FUN_01675290(uVar6);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_00c693c0(&param_2);
    cVar4 = FUN_01679300(&puStack_14);
    if (cVar4 != '\0') {
      FUN_01679490();
      FUN_016791c0(&puStack_14);
    }
    iStack_8 = 0xffffffff;
    if (puStack_14 != (undefined4 *)0x0) {
      piVar1 = puStack_14 + 1;
      LOCK();
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        FUN_01674ea0(puStack_14);
      }
    }
    if (*(char *)(iVar3 + 0x46e) != '\0') {
      FUN_00c69ac0(iVar3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28992 ; VA 0x00c69e60 ; FUN_00c69e60 */

int * __thiscall FUN_00c69e60(int param_1,uint *param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  int *piVar10;
  
  piVar5 = (int *)FUN_00d67090(param_2);
  uVar1 = *param_2;
  if (uVar1 != 0) {
    iVar2 = *(int *)(uVar1 + 0xc);
    iVar6 = FUN_00c6dcc0();
    piVar5 = (int *)(uint)*(ushort *)(iVar6 + 0x1da);
    if (((int *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) <= piVar5) &&
       (piVar5 = (int *)FUN_00c6a350(uVar1), *(int *)(param_1 + 0x270) != 0)) {
      uVar1 = *param_2;
      uVar7 = (uVar1 >> 3) + uVar1;
      uVar9 = uVar7 % *(uint *)(param_1 + 0x26c);
      piVar5 = *(int **)(param_1 + 0x27c);
      piVar10 = (int *)piVar5[uVar9];
      if ((piVar10 != (int *)0x0) && (piVar4 = (int *)*piVar10, (int *)*piVar10 != (int *)0x0)) {
        while( true ) {
          piVar8 = piVar4;
          uVar3 = piVar8[1];
          piVar5 = (int *)(uVar3 / *(uint *)(param_1 + 0x26c));
          if (uVar3 % *(uint *)(param_1 + 0x26c) != uVar9) break;
          if ((uVar3 == uVar7) && (uVar1 == piVar8[2])) {
            FUN_00c697d0(piVar10,*piVar8);
            if (*piVar10 != 0) {
              uVar1 = *(uint *)(*piVar10 + 4);
              uVar7 = uVar1 % *(uint *)(param_1 + 0x26c);
              if (uVar9 == uVar7) {
                return (int *)(uVar1 / *(uint *)(param_1 + 0x26c));
              }
              *(int **)(*(int *)(param_1 + 0x27c) + uVar7 * 4) = piVar10;
            }
            piVar5 = (int *)(*(int *)(param_1 + 0x27c) + uVar9 * 4);
            if ((int *)*piVar5 != piVar10) {
              return piVar5;
            }
            *piVar5 = 0;
            return piVar5;
          }
          piVar4 = (int *)*piVar8;
          piVar10 = piVar8;
          if (piVar4 == (int *)0x0) {
            return piVar4;
          }
        }
      }
    }
  }
  return piVar5;
}



/* FUNCTION 28993 ; VA 0x00c69f70 ; FUN_00c69f70 */

void __thiscall FUN_00c69f70(int param_1,int param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 uVar4;
  undefined auStack_24 [16];
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  if ((param_2 != 0) &&
     (*(undefined4 *)(param_1 + 0x260) = *(undefined4 *)(param_1 + 0x25c),
     *(int *)(param_1 + 0x270) != 0)) {
    FUN_00c697d0(*(int *)(param_1 + 0x27c) + *(int *)(param_1 + 0x26c) * 4,0);
    puVar2 = *(undefined4 **)(param_1 + 0x27c);
    puVar1 = puVar2 + *(int *)(param_1 + 0x26c);
    for (; puVar2 != puVar1; puVar2 = puVar2 + 1) {
      *puVar2 = 0;
    }
  }
  FUN_00d674f0(param_2,param_3);
  if ((param_3 != 0) && (iVar3 = FUN_006ebc30(param_1), iVar3 != 0)) {
    if (*(char *)(param_1 + 0x259) != '\0') {
      uStack_14 = *(undefined4 *)(iVar3 + 0xe8);
      uStack_10 = *(undefined4 *)(iVar3 + 0xec);
      uStack_c = *(undefined4 *)(iVar3 + 0xf0);
      uStack_8 = *(undefined4 *)(iVar3 + 0xf4);
      FUN_00d69a10(&uStack_14);
      return;
    }
    uVar4 = FUN_00c69a30(auStack_24);
    FUN_00d69a10(uVar4);
  }
  return;
}



/* FUNCTION 28994 ; VA 0x00c6a030 ; FUN_00c6a030 */

undefined4 * __thiscall
FUN_00c6a030(int param_1,undefined4 *param_2,int *param_3,float param_4,float param_5,float param_6)

{
  int iVar1;
  char cVar2;
  float *pfVar3;
  float fVar4;
  undefined auStack_58 [16];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined auStack_34 [20];
  float fStack_20;
  undefined8 uStack_1c;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  cVar2 = FUN_00c69ba0();
  if ((cVar2 != '\0') && (*(char *)(param_1 + 0x15c) != '\0')) {
    param_5 = param_5 - *(float *)(param_1 + 0x220);
    param_4 = param_4 - *(float *)(param_1 + 0x21c);
    param_6 = param_6 - *(float *)(param_1 + 0x224);
    fStack_c = (*(float *)(param_1 + 0x204) * param_5 + *(float *)(param_1 + 0x1f8) * param_4 +
               *(float *)(param_1 + 0x210) * param_6) - *(float *)(param_1 + 0x24c);
    fStack_8 = (*(float *)(param_1 + 0x1fc) * param_4 + *(float *)(param_1 + 0x208) * param_5 +
               *(float *)(param_1 + 0x214) * param_6) - *(float *)(param_1 + 0x250);
    fStack_10 = (*(float *)(param_1 + 0x200) * param_4 + *(float *)(param_1 + 0x20c) * param_5 +
                *(float *)(param_1 + 0x218) * param_6) - *(float *)(param_1 + 0x254);
    pfVar3 = (float *)FUN_01162330(auStack_58,0x358637bd);
    iVar1 = *param_3;
    fVar4 = pfVar3[4] * fStack_8 + pfVar3[3] * fStack_c + pfVar3[5] * fStack_10;
    uStack_1c = CONCAT44(fVar4,pfVar3[1] * fStack_8 + *pfVar3 * fStack_c + pfVar3[2] * fStack_10);
    fStack_20 = pfVar3[7] * fStack_8 + pfVar3[6] * fStack_c + pfVar3[8] * fStack_10;
    if (iVar1 != 0) {
      fStack_14 = fStack_20;
      fStack_10 = (float)((uint)fVar4 ^ DAT_018c4ea0);
      pfVar3 = (float *)FUN_00d81770(auStack_34);
      fStack_20 = fStack_14 - pfVar3[2];
      *(ulonglong *)(iVar1 + 0x78) = CONCAT44(fStack_10 - pfVar3[1],(float)uStack_1c - *pfVar3);
      *(float *)(iVar1 + 0x80) = fStack_20;
      FUN_00d687d0(&uStack_48,param_3,0);
      iVar1 = *param_3;
      *(undefined8 *)(iVar1 + 0x78) = 0;
      *(undefined4 *)(iVar1 + 0x80) = 0;
      param_2[1] = uStack_44;
      param_2[2] = uStack_40;
      *param_2 = uStack_48;
      param_2[3] = uStack_3c;
      param_2[4] = uStack_38;
      return param_2;
    }
  }
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  return param_2;
}



/* FUNCTION 28995 ; VA 0x00c6a2a0 ; FUN_00c6a2a0 */

undefined4 * __thiscall FUN_00c6a2a0(int param_1,undefined4 *param_2,undefined4 param_3)

{
  char cVar1;
  
  cVar1 = FUN_00c69ba0();
  if ((cVar1 == '\0') && (*(char *)(param_1 + 0x15c) != '\0')) {
    FUN_00d677d0(param_2,param_3);
    return param_2;
  }
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  return param_2;
}



/* FUNCTION 28996 ; VA 0x00c6a300 ; FUN_00c6a300 */

undefined4 * __thiscall
FUN_00c6a300(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  if (*(char *)(param_1 + 0x15c) == '\0') {
    *param_2 = 0;
    param_2[1] = 0;
    param_2[2] = 0;
    param_2[3] = 0;
    param_2[4] = 0;
    return param_2;
  }
  FUN_00d68270(param_2,param_3,param_4,param_5);
  return param_2;
}



/* FUNCTION 28997 ; VA 0x00c6a350 ; FUN_00c6a350 */

undefined4 __thiscall FUN_00c6a350(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  
  piVar1 = *(int **)(param_1 + 0x25c);
  do {
    piVar2 = piVar1;
    if (piVar2 == *(int **)(param_1 + 0x260)) {
      return 0;
    }
    piVar1 = piVar2 + 1;
  } while (*piVar2 != param_2);
  FUN_0170cc70(piVar2,piVar1,(int)*(int **)(param_1 + 0x260) - (int)piVar1);
  *(int *)(param_1 + 0x260) = *(int *)(param_1 + 0x260) + -4;
  return 1;
}



/* FUNCTION 28998 ; VA 0x00c6a3b0 ; FUN_00c6a3b0 */

void __thiscall FUN_00c6a3b0(int *param_1,undefined4 param_2)

{
  char cVar1;
  
  cVar1 = FUN_00c69ba0();
  if ((cVar1 == '\0') && (*(char *)(param_1 + 0x42) != '\0')) {
    (**(code **)(*param_1 + 0x14))(param_2,0);
  }
  return;
}



/* FUNCTION 28999 ; VA 0x00c6a3e0 ; FUN_00c6a3e0 */

void __thiscall FUN_00c6a3e0(int param_1,int *param_2,undefined4 param_3)

{
  float *pfVar1;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  if (*(char *)(param_1 + 0x205) == '\0') {
    (**(code **)(*param_2 + 0x30))(&fStack_14);
    fStack_1c = fStack_c - (float)param_2[3];
    fStack_14 = (float)param_2[1] + fStack_14;
    fStack_18 = fStack_8 - (float)param_2[4];
    fStack_10 = (float)param_2[2] + fStack_10;
    fStack_24 = fStack_14;
    if (fStack_1c < fStack_14) {
      fStack_24 = fStack_1c;
    }
    fStack_20 = fStack_10;
    if (fStack_18 < fStack_10) {
      fStack_20 = fStack_18;
    }
    if (fStack_1c <= fStack_14) {
      fStack_1c = fStack_14;
    }
    if (fStack_18 <= fStack_10) {
      fStack_18 = fStack_10;
    }
    pfVar1 = &fStack_24;
  }
  else {
    pfVar1 = (float *)(**(code **)(*param_2 + 0x30))(&fStack_24);
  }
  FUN_00d69a10(pfVar1);
  if (*(char *)(param_1 + 0x206) == '\0') {
    FUN_00d68940(param_2,param_3);
    return;
  }
  (**(code **)(*param_2 + 0x28))(1);
  FUN_00d68940(param_2,param_3);
  (**(code **)(*param_2 + 0x2c))();
  return;
}


