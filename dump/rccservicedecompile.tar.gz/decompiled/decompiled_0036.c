/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 9000 ; VA 0x006c4930 ; FUN_006c4930 */

bool FUN_006c4930(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_005ee170();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) goto LAB_006c4962;
  }
  param_1 = 0;
LAB_006c4962:
  return param_1 != 0;
}



/* FUNCTION 9001 ; VA 0x006c4970 ; FUN_006c4970 */

void FUN_006c4970(int *param_1)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined auStack_20 [12];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7d2b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00724070();
  uStack_8 = 0;
  FUN_00724320(&DAT_01eaeed0);
  iStack_14 = (**(code **)(*param_1 + 8))();
  iStack_14 = iStack_14 + -1;
  iVar3 = (**(code **)(*param_1 + 4))();
  iVar1 = iStack_14;
  iVar4 = (**(code **)(*param_1 + 4))();
  cVar2 = FUN_00724080(iVar4 + 1,iVar1,iVar3 + 1,&iStack_14);
  if (cVar2 != '\0') {
    _guard_check_icall();
    ExceptionList = pvStack_10;
    return;
  }
  FUN_00550130("Data error");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_20,&DAT_01c17198);
}



/* FUNCTION 9002 ; VA 0x006c4a30 ; FUN_006c4a30 */

void FUN_006c4a30(int *param_1,undefined4 param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined auStack_20 [12];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7d2b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00724070();
  uStack_8 = 0;
  FUN_00724320(param_2);
  iStack_14 = (**(code **)(*param_1 + 8))();
  iStack_14 = iStack_14 + -1;
  iVar3 = (**(code **)(*param_1 + 4))();
  iVar1 = iStack_14;
  iVar4 = (**(code **)(*param_1 + 4))();
  cVar2 = FUN_00724080(iVar4 + 1,iVar1,iVar3 + 1,&iStack_14);
  if (cVar2 != '\0') {
    _guard_check_icall();
    ExceptionList = pvStack_10;
    return;
  }
  FUN_00550130("Data error");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_20,&DAT_01c17198);
}



/* FUNCTION 9003 ; VA 0x006c4af0 ; FUN_006c4af0 */

void __thiscall FUN_006c4af0(int param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7d4b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00724070();
  uStack_8 = 0;
  FUN_00724320(&DAT_01eaeed0);
  iVar1 = (**(code **)(*param_2 + 8))();
  iStack_14 = iVar1 + -1;
  iVar2 = (**(code **)(*param_2 + 8))();
  FUN_006ab630(((iVar1 + 0x14U & 0xfffffff0) - iVar2) + 1);
  iVar2 = (**(code **)(*param_2 + 4))();
  iVar1 = iStack_14;
  iVar3 = (**(code **)(*param_2 + 4))();
  FUN_007241d0(iVar3 + 1,iVar1,iVar2 + 1,&iStack_14,param_1 + 0xe0);
  FUN_006ab6a0(iStack_14 + 1,0);
  _guard_check_icall();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9004 ; VA 0x006c4bc0 ; FUN_006c4bc0 */

void __thiscall FUN_006c4bc0(int param_1,int *param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7d4b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00724070();
  uStack_8 = 0;
  FUN_00724320(param_3);
  iVar1 = (**(code **)(*param_2 + 8))();
  iStack_14 = iVar1 + -1;
  iVar2 = (**(code **)(*param_2 + 8))();
  FUN_006ab630(((iVar1 + 0x14U & 0xfffffff0) - iVar2) + 1);
  iVar2 = (**(code **)(*param_2 + 4))();
  iVar1 = iStack_14;
  iVar3 = (**(code **)(*param_2 + 4))();
  FUN_007241d0(iVar3 + 1,iVar1,iVar2 + 1,&iStack_14,param_1 + 0xe0);
  FUN_006ab6a0(iStack_14 + 1,0);
  _guard_check_icall();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9005 ; VA 0x006c4c90 ; FUN_006c4c90 */

undefined4 __thiscall FUN_006c4c90(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_01256300(param_3);
  uVar2 = FUN_009d05b0(param_3,param_4,1,iVar1 - param_4,param_1 + 0x40);
  (**(code **)(param_1 + 0x38))(uVar2);
  return 0;
}



/* FUNCTION 9006 ; VA 0x006c4cd0 ; FUN_006c4cd0 */

void __thiscall FUN_006c4cd0(undefined4 param_1,double param_2)

{
  FUN_009ffd50(param_1,param_2,"%.1f%%",param_2 * DAT_018ce318);
  return;
}



/* FUNCTION 9007 ; VA 0x006c4d10 ; thunk_FUN_005ee4d0 */

void thunk_FUN_005ee4d0(void)

{
  int iVar1;
  
  if (DAT_01ea9d3c == 0) {
    iVar1 = FUN_005ee090();
    DAT_01ea9d3c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 9008 ; VA 0x006c4d20 ; FUN_006c4d20 */

void __thiscall FUN_006c4d20(int param_1,undefined4 param_2,undefined4 param_3)

{
  if (*(int **)(param_1 + 0xf8) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0xf8) + 4))(param_2,param_3);
  }
  return;
}



/* FUNCTION 9009 ; VA 0x006c4d40 ; FUN_006c4d40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_006c4d40(void)

{
  int *piVar1;
  uint *puVar2;
  
  piVar1 = (int *)FUN_0054db20();
  puVar2 = (uint *)(**(code **)(*piVar1 + 0xc0))
                             (_DAT_01eaeee0,uRam01eaeee4,uRam01eaeee8,uRam01eaeeec,_DAT_01eaeef0,
                              uRam01eaeef4,uRam01eaeef8,uRam01eaeefc);
  FUN_0167a1b0(puVar2[1] ^ *puVar2,0);
  piVar1 = (int *)FUN_0054db20();
  (**(code **)(*piVar1 + 0xa4))(1);
  return;
}



/* FUNCTION 9010 ; VA 0x006c4db0 ; FUN_006c4db0 */

int __thiscall FUN_006c4db0(int *param_1,uint param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  code *pcVar4;
  int iVar5;
  int *piVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  uint uVar9;
  int **ppiStack_74;
  int *piStack_70;
  int **ppiStack_6c;
  int **ppiStack_68;
  uint auStack_58 [4];
  undefined4 uStack_48;
  uint uStack_44;
  int *apiStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  int *piStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7de7;
  pvStack_10 = ExceptionList;
  ppiStack_68 = (int **)param_2;
  ppiStack_6c = (int **)0x6c4dd8;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_00606de0();
  if (iVar5 != 0) {
    ppiStack_68 = (int **)0x7;
    ppiStack_6c = (int **)&DAT_018c5904;
    uStack_30 = 0;
    uStack_2c = 0xf;
    apiStack_40[0] = (int *)((uint)apiStack_40[0] & 0xffffff00);
    piStack_70 = (int *)0x6c4e09;
    FUN_005542c0();
    ppiStack_68 = apiStack_40;
    uStack_8 = 0;
    ppiStack_6c = (int **)0x6c4e1b;
    iVar5 = FUN_008a1240();
    if (iVar5 == 0) {
      ppiStack_68 = (int **)0x0;
    }
    else {
      ppiStack_68 = (int **)(iVar5 + 4);
    }
    ppiStack_6c = (int **)&iStack_20;
    piStack_70 = (int *)0x6c4e30;
    FUN_0060ddd0();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (0xf < uStack_2c) {
      ppiStack_68 = (int **)(uStack_2c + 1);
      piVar6 = apiStack_40[0];
      if (0xfff < ppiStack_68) {
        piVar6 = (int *)apiStack_40[0][-1];
        ppiStack_68 = (int **)(uStack_2c + 0x24);
        if (0x1f < (uint)((int)apiStack_40[0] + (-4 - (int)piVar6))) {
                    /* WARNING: Subroutine does not return */
          ppiStack_68 = (int **)0x6c55e5;
          FUN_017167a3();
        }
      }
      piStack_70 = (int *)0x6c4e68;
      ppiStack_6c = (int **)piVar6;
      FUN_01674ea0();
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    apiStack_40[0] = (int *)((uint)apiStack_40[0] & 0xffffff00);
    if (iStack_20 != 0) {
      ppiStack_68 = (int **)0x0;
      ppiStack_6c = (int **)0x0;
      piStack_70 = (int *)0x6c4e8d;
      FUN_008a65e0();
    }
    piVar6 = piStack_1c;
    uStack_8 = 0xffffffff;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar5 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_68 = (int **)0x6c4eaa;
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          ppiStack_68 = (int **)0x6c4eba;
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  iVar5 = param_1[0x35];
  if (iVar5 != 0) {
    *(undefined4 *)(iVar5 + 0x130) = 0;
    piVar6 = *(int **)(iVar5 + 0x134);
    *(undefined4 *)(iVar5 + 0x134) = 0;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar5 = piVar6[2] + -1;
      piVar6[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_68 = (int **)0x6c4ef4;
        (**(code **)(*piVar6 + 4))();
      }
    }
    piVar6 = (int *)param_1[0x36];
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = (int *)param_1[0x36];
    }
    iStack_20 = param_1[0x35];
    uStack_8 = 3;
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
    }
    piStack_1c = piVar6;
    FUN_0151dac0(iStack_20,piVar6,0,0);
    uStack_8 = 0xffffffff;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar5 = piVar6[1] + -1;
      piVar6[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_68 = (int **)0x6c4f6d;
        (**(code **)*piVar6)();
        LOCK();
        iVar5 = piVar6[2] + -1;
        piVar6[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          ppiStack_68 = (int **)0x6c4f7d;
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    param_1[0x35] = 0;
    piVar6 = (int *)param_1[0x36];
    param_1[0x36] = 0;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar5 = piVar6[1] + -1;
      piVar6[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_68 = (int **)0x6c4faa;
        (**(code **)*piVar6)();
        LOCK();
        iVar5 = piVar6[2] + -1;
        piVar6[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          ppiStack_68 = (int **)0x6c4fba;
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  ppiStack_68 = (int **)0x6c4fc1;
  FUN_008a50b0();
  if (param_1[0x32] != 0) {
    if (DAT_01eadf38 != 0) {
      ppiStack_68 = (int **)0x0;
      piStack_70 = (int *)(uint)DAT_01eadf38;
      ppiStack_6c = (int **)0x18dd720;
      ppiStack_74 = (int **)0x6c4fe4;
      FUN_016774b0();
    }
    ppiStack_68 = (int **)0x6c4ff2;
    piVar6 = (int *)FUN_0054db20();
    ppiStack_68 = (int **)(param_1 + 0x15);
    ppiStack_6c = (int **)0x6c5002;
    (**(code **)(*piVar6 + 0x100))();
    param_1[0x32] = 0;
    piVar6 = (int *)param_1[0x33];
    param_1[0x33] = 0;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar5 = piVar6[1] + -1;
      piVar6[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_68 = (int **)0x6c502f;
        (**(code **)*piVar6)();
        LOCK();
        iVar5 = piVar6[2] + -1;
        piVar6[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          ppiStack_68 = (int **)0x6c503f;
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  ppiStack_68 = (int **)param_3;
  ppiStack_6c = (int **)param_2;
  piStack_70 = (int *)0x6c504d;
  FUN_008a4210();
  if (param_2 != 0) {
    param_1[0x3a] = 0;
    piVar6 = (int *)param_1[0x3b];
    param_1[0x3b] = 0;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar5 = piVar6[1] + -1;
      piVar6[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_68 = (int **)0x6c507e;
        (**(code **)*piVar6)();
        LOCK();
        iVar5 = piVar6[2] + -1;
        piVar6[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          ppiStack_68 = (int **)0x6c508e;
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    param_1[0x3c] = 0;
    piVar6 = (int *)param_1[0x3d];
    param_1[0x3d] = 0;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar5 = piVar6[1] + -1;
      piVar6[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_68 = (int **)0x6c50bb;
        (**(code **)*piVar6)();
        LOCK();
        iVar5 = piVar6[2] + -1;
        piVar6[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          ppiStack_68 = (int **)0x6c50cb;
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    ppiStack_68 = (int **)0x30;
    ppiStack_6c = (int **)0x6c50dd;
    piStack_18 = (int *)FUN_01674e20();
    uStack_8 = 4;
    if (piStack_18 == (int *)0x0) {
      ppiStack_6c = (int **)0x0;
    }
    else {
      iVar5 = (int)param_3 + -0xc;
      ppiStack_68 = (int **)0x700;
      ppiStack_6c = (int **)0x6c5103;
      piStack_14 = (int *)FUN_01674e20();
      uStack_8._0_1_ = 5;
      if (piStack_14 == (int *)0x0) {
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        ppiStack_6c = (int **)0x0;
        piStack_70 = (int *)0x6c513a;
        ppiStack_68 = (int **)iVar5;
        ppiStack_6c = (int **)FUN_006aec50();
      }
      else {
        ppiStack_68 = (int **)0x6c5118;
        ppiStack_6c = (int **)FUN_00695e50();
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        piStack_70 = (int *)0x6c5127;
        ppiStack_68 = (int **)iVar5;
        ppiStack_6c = (int **)FUN_006aec50();
      }
    }
    ppiStack_68 = (int **)param_3;
    uStack_8 = 0xffffffff;
    iStack_20 = 0;
    piStack_1c = (int *)0x0;
    piStack_70 = (int *)0x6c515f;
    FUN_006c3f70();
    param_1[0x32] = iStack_20;
    piVar6 = (int *)param_1[0x33];
    param_1[0x33] = (int)piStack_1c;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar5 = piVar6[1] + -1;
      piVar6[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_68 = (int **)0x6c518a;
        (**(code **)*piVar6)();
        LOCK();
        iVar5 = piVar6[2] + -1;
        piVar6[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          ppiStack_68 = (int **)0x6c519a;
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    if (DAT_01eadf38 != 0) {
      ppiStack_68 = (int **)0x0;
      piStack_70 = (int *)(uint)DAT_01eadf38;
      ppiStack_6c = (int **)0x18dd748;
      ppiStack_74 = (int **)0x6c51b3;
      FUN_016774b0();
    }
    ppiStack_68 = (int **)0x6c51c1;
    piVar6 = (int *)FUN_0054db20();
    ppiStack_68 = (int **)(param_1 + 0x15);
    ppiStack_6c = (int **)0x6c51d1;
    (**(code **)(*piVar6 + 0xfc))();
    ppiStack_6c = (int **)0x6c51db;
    (**(code **)(*param_1 + 0xa4))();
    ppiStack_6c = (int **)0x140;
    piStack_70 = (int *)0x6c51e5;
    puVar7 = (undefined4 *)FUN_01674e20();
    if (puVar7 == (undefined4 *)0x0) {
      puVar7 = (undefined4 *)0x0;
    }
    else {
      piVar6 = (int *)param_1[0x33];
      piStack_14 = (int *)((int)param_3 + -0xc);
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
        piVar6 = (int *)param_1[0x33];
      }
      piStack_28 = (int *)param_1[0x32];
      ppiStack_6c = (int **)0x1;
      uStack_8._0_1_ = 7;
      uStack_8._1_3_ = 0;
      piStack_24 = piVar6;
      piStack_18 = piStack_28;
      FUN_005c4330(&ppiStack_74,piStack_14);
      FUN_00a360a0("Net PacketReceive",7,0);
      ppiStack_6c = (int **)piStack_14;
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      *puVar7 = RBX::Network::PacketReceiveJob::vftable;
      piStack_70 = &iStack_20;
      ppiStack_74 = (int **)0x6c5265;
      puVar8 = (undefined4 *)FUN_005c4330();
      puVar7[0x4a] = 0;
      puVar7[0x4b] = 0;
      if (puVar8[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar8[1] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      puVar7[0x4a] = *puVar8;
      puVar7[0x4b] = puVar8[1];
      piStack_14 = piStack_1c;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar5 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          ppiStack_6c = (int **)0x6c52b6;
          (**(code **)*piStack_1c)();
          LOCK();
          iVar5 = piStack_14[2] + -1;
          piStack_14[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            ppiStack_6c = (int **)0x6c52c7;
            (**(code **)(*piStack_14 + 4))();
          }
        }
      }
      puVar7[0x4c] = 0;
      puVar7[0x4d] = 0;
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[2] = piVar6[2] + 1;
        UNLOCK();
      }
      puVar7[0x4c] = piStack_18;
      puVar7[0x4d] = piVar6;
      ppiStack_6c = (int **)(puVar7 + 0x4e);
      uStack_8 = CONCAT31(uStack_8._1_3_,10);
      piStack_70 = (int *)0x6c5307;
      FUN_016830f0();
      ppiStack_6c = (int **)0x6c5312;
      FUN_00a361f0();
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar5 = piVar6[1] + -1;
        piVar6[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          ppiStack_6c = (int **)0x6c5325;
          (**(code **)*piVar6)();
          LOCK();
          iVar5 = piVar6[2] + -1;
          piVar6[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            ppiStack_6c = (int **)0x6c5337;
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
    }
    ppiStack_6c = (int **)param_3;
    uStack_8 = 0xffffffff;
    iStack_20 = 0;
    piStack_1c = (int *)0x0;
    ppiStack_74 = (int **)0x6c535f;
    piStack_70 = puVar7;
    FUN_006c4000();
    param_1[0x35] = iStack_20;
    piVar6 = (int *)param_1[0x36];
    param_1[0x36] = (int)piStack_1c;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar5 = piVar6[1] + -1;
      piVar6[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_6c = (int **)0x6c538a;
        (**(code **)*piVar6)();
        LOCK();
        iVar5 = piVar6[2] + -1;
        piVar6[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          ppiStack_6c = (int **)0x6c539a;
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    if (param_1[0x36] != 0) {
      LOCK();
      piVar6 = (int *)(param_1[0x36] + 4);
      *piVar6 = *piVar6 + 1;
      UNLOCK();
    }
    piStack_70 = (int *)param_1[0x35];
    ppiStack_6c = (int **)param_1[0x36];
    ppiStack_74 = (int **)0x6c53d0;
    FUN_0151d950();
    ppiStack_74 = &piStack_28;
    piVar6 = (int *)FUN_00693470();
    iVar5 = *piVar6;
    iVar3 = piVar6[1];
    *piVar6 = 0;
    piVar6[1] = 0;
    param_1[0x3a] = iVar5;
    piVar6 = (int *)param_1[0x3b];
    param_1[0x3b] = iVar3;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar5 = piVar6[1] + -1;
      piVar6[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_6c = (int **)0x6c5413;
        (**(code **)*piVar6)();
        LOCK();
        iVar5 = piVar6[2] + -1;
        piVar6[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          ppiStack_6c = (int **)0x6c5423;
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    piVar6 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_24[1] + -1;
      piStack_24[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_6c = (int **)0x6c5439;
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          ppiStack_6c = (int **)0x6c5449;
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    ppiStack_6c = &piStack_28;
    piStack_70 = (int *)0x6c5452;
    piVar6 = (int *)FUN_00691720();
    iVar5 = *piVar6;
    iVar3 = piVar6[1];
    *piVar6 = 0;
    piVar6[1] = 0;
    param_1[0x3c] = iVar5;
    piVar6 = (int *)param_1[0x3d];
    param_1[0x3d] = iVar3;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar5 = piVar6[1] + -1;
      piVar6[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_68 = (int **)0x6c548c;
        (**(code **)*piVar6)();
        LOCK();
        iVar5 = piVar6[2] + -1;
        piVar6[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          ppiStack_68 = (int **)0x6c549c;
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    piVar6 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_24[1] + -1;
      piStack_24[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        ppiStack_68 = (int **)0x6c54b2;
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          ppiStack_68 = (int **)0x6c54c2;
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  ppiStack_68 = (int **)param_3;
  ppiStack_6c = (int **)0x6c54cb;
  iVar5 = FUN_00606de0();
  if (iVar5 != 0) {
    ppiStack_68 = &param_3;
    ppiStack_6c = (int **)&iStack_20;
    piStack_70 = (int *)0x6c54e9;
    param_3 = param_1;
    puVar7 = (undefined4 *)FUN_006c41f0();
    piVar1 = piStack_1c;
    param_3 = (int *)*puVar7;
    piVar6 = (int *)puVar7[1];
    *puVar7 = 0;
    puVar7[1] = 0;
    uStack_8 = 0xb;
    piStack_28 = param_3;
    piStack_24 = piVar6;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        ppiStack_68 = (int **)0x6c5524;
        (**(code **)*piStack_1c)();
        LOCK();
        piVar2 = piVar1 + 2;
        iVar3 = *piVar2 + -1;
        *piVar2 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          ppiStack_68 = (int **)0x6c5534;
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    ppiStack_68 = (int **)0x7;
    ppiStack_6c = (int **)&DAT_018c5904;
    uStack_48 = 0;
    uStack_44 = 0xf;
    auStack_58[0] = auStack_58[0] & 0xffffff00;
    pcVar4 = *(code **)(*param_3 + 0x38);
    piStack_70 = (int *)0x6c555d;
    FUN_005542c0();
    ppiStack_68 = (int **)auStack_58;
    uStack_8._0_1_ = 0xc;
    ppiStack_6c = (int **)0x6c556a;
    (*pcVar4)();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    if (0xf < uStack_44) {
      ppiStack_6c = (int **)(uStack_44 + 1);
      uVar9 = auStack_58[0];
      if (0xfff < ppiStack_6c) {
        uVar9 = *(uint *)(auStack_58[0] - 4);
        ppiStack_6c = (int **)(uStack_44 + 0x24);
        if (0x1f < (auStack_58[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
          ppiStack_6c = (int **)&UNK_006c55ea;
          FUN_017167a3();
        }
      }
      ppiStack_74 = (int **)0x6c559b;
      piStack_70 = (int *)uVar9;
      FUN_01674ea0();
    }
    ppiStack_6c = (int **)0x0;
    ppiStack_74 = (int **)0x6c55ab;
    piStack_70 = (int *)iVar5;
    iVar5 = FUN_008a65e0();
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar1 = piVar6 + 1;
      iVar3 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        ppiStack_6c = (int **)0x6c55be;
        iVar5 = (**(code **)*piVar6)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          ppiStack_6c = (int **)0x6c55cd;
          iVar5 = (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 9011 ; VA 0x006c55f0 ; FUN_006c55f0 */

undefined4 * __thiscall FUN_006c55f0(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7e08;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar6 = (undefined4 *)FUN_008a4210(param_2,param_3);
  if (param_3 != 0) {
    FUN_009ff040(auStack_18,"Packets Thread");
    uStack_8 = 0;
    puVar6 = (undefined4 *)FUN_009ff040(auStack_20,&DAT_018dd66c);
    uVar2 = *puVar6;
    uVar3 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x7c) = uVar2;
    piVar4 = *(int **)(param_1 + 0x80);
    *(undefined4 *)(param_1 + 0x80) = uVar3;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    piVar4 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar5 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    puVar6 = (undefined4 *)FUN_009ff040(auStack_20,"Activity");
    uVar2 = *puVar6;
    uVar3 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x84) = uVar2;
    piVar4 = *(int **)(param_1 + 0x88);
    *(undefined4 *)(param_1 + 0x88) = uVar3;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    piVar4 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar5 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    puVar6 = (undefined4 *)FUN_009ff040(auStack_20,"Physics Senders");
    uVar2 = *puVar6;
    uVar3 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x8c) = uVar2;
    piVar4 = *(int **)(param_1 + 0x90);
    *(undefined4 *)(param_1 + 0x90) = uVar3;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    piVar4 = piStack_1c;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar5 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar5 = *piVar1 + -1;
        *piVar1 = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    puVar6 = (undefined4 *)FUN_009ff040(auStack_20,"Send Buffer Health");
    uVar2 = *puVar6;
    uVar3 = puVar6[1];
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 *)(param_1 + 0x94) = uVar2;
    piVar4 = *(int **)(param_1 + 0x98);
    *(undefined4 *)(param_1 + 0x98) = uVar3;
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar1 = piVar4 + 1;
      iVar5 = *piVar1;
      puVar6 = (undefined4 *)*piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar5 = *piVar1;
        puVar6 = (undefined4 *)*piVar1;
        *piVar1 = iVar5 + -1;
        UNLOCK();
        if (iVar5 + -1 == 0) {
          puVar6 = (undefined4 *)(**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar4 = piStack_1c + 1;
      iVar5 = *piVar4;
      puVar6 = (undefined4 *)*piVar4;
      *piVar4 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar4 = piStack_1c + 2;
        iVar5 = *piVar4;
        puVar6 = (undefined4 *)*piVar4;
        *piVar4 = iVar5 + -1;
        UNLOCK();
        if (iVar5 + -1 == 0) {
          puVar6 = (undefined4 *)(**(code **)(*piStack_1c + 4))();
        }
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar4 = piStack_14 + 1;
      iVar5 = *piVar4;
      puVar6 = (undefined4 *)*piVar4;
      *piVar4 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        puVar6 = (undefined4 *)(**(code **)*piStack_14)();
        LOCK();
        piVar4 = piStack_14 + 2;
        iVar5 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          puVar6 = (undefined4 *)(**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar6;
}



/* FUNCTION 9012 ; VA 0x006c5870 ; FUN_006c5870 */

void FUN_006c5870(int param_1,byte *param_2,undefined4 *param_3,undefined4 *param_4)

{
  short sVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int iStack_2c;
  int iStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7e28;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006ab380(*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x30),0);
  uStack_8 = 0;
  FUN_006ab660(1);
  FUN_006abe60(param_2,1);
  if (*param_2 < 3) {
    uVar2 = FUN_006ace40();
    *param_3 = uVar2;
    if (*param_2 == 0) {
      sVar1 = FUN_006ac450();
      FUN_0055b6c0((int)sVar1,param_4);
      FUN_006abe60(*param_4,(int)sVar1);
    }
  }
  else {
    *param_2 = 2;
    FUN_0055b6c0(0,param_4);
  }
  if (iStack_2c != 0) {
    uVar4 = iStack_24 - iStack_2c;
    iVar3 = iStack_2c;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iStack_2c + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iStack_2c - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9013 ; VA 0x006c5950 ; FUN_006c5950 */

undefined4 FUN_006c5950(void)

{
  code *pcVar1;
  undefined4 uVar2;
  uint uVar3;
  int iVar4;
  int *in_stack_00000024;
  undefined4 uVar5;
  undefined2 uVar6;
  undefined auStack_40 [12];
  int iStack_34;
  int iStack_2c;
  undefined auStack_18 [4];
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7e48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006ab530();
  uStack_8 = 0;
  auStack_14[0] = 0x9c;
  FUN_006ad5e0(auStack_14,1);
  auStack_14[0] = 1;
  FUN_006ad5e0(auStack_14,1);
  FUN_006a5c10(&stack0x00000024,auStack_18,4);
  FUN_006ad5e0(auStack_18,4);
  in_stack_00000024 = (int *)FUN_0054db20();
  pcVar1 = *(code **)(*in_stack_00000024 + 0x4c);
  FUN_005f70a0();
  FUN_005f7140();
  uVar2 = DAT_01d5b688;
  uVar5 = DAT_01d5b68c;
  uVar6 = DAT_01d5b690;
  FUN_005f7170(&stack0x00000004);
  uVar2 = (*pcVar1)(auStack_40,0,3,1,uVar2,uVar5,uVar6);
  if (iStack_34 != 0) {
    uVar3 = iStack_2c - iStack_34;
    iVar4 = iStack_34;
    if (0xfff < uVar3) {
      iVar4 = *(int *)(iStack_34 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iStack_34 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 9014 ; VA 0x006c5a80 ; FUN_006c5a80 */

undefined4 FUN_006c5a80(int *param_1)

{
  code *pcVar1;
  int *piVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  int *in_stack_00000028;
  undefined4 uVar6;
  undefined2 uVar7;
  undefined auStack_40 [12];
  int iStack_34;
  int iStack_2c;
  undefined auStack_18 [4];
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7e48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006ab530();
  uStack_8 = 0;
  auStack_14[0] = 0x9c;
  FUN_006ad5e0(auStack_14,1);
  auStack_14[0] = 0;
  FUN_006ad5e0(auStack_14,1);
  FUN_006a5c10(&stack0x00000028,auStack_18,4);
  FUN_006ad5e0(auStack_18,4);
  piVar2 = param_1;
  param_1 = (int *)(param_1[1] - *param_1 & 0xffff);
  FUN_006a5c10(&param_1,&stack0x00000028,2);
  FUN_006ad5e0(&stack0x00000028,2);
  iVar5 = *piVar2;
  FUN_006ad5e0(iVar5,piVar2[1] - iVar5);
  in_stack_00000028 = (int *)FUN_0054db20();
  pcVar1 = *(code **)(*in_stack_00000028 + 0x4c);
  FUN_005f70a0();
  FUN_005f7140();
  uVar3 = DAT_01d5b688;
  uVar6 = DAT_01d5b68c;
  uVar7 = DAT_01d5b690;
  FUN_005f7170(&stack0x00000008);
  uVar3 = (*pcVar1)(auStack_40,0,3,1,uVar3,uVar6,uVar7);
  if (iStack_34 != 0) {
    uVar4 = iStack_2c - iStack_34;
    iVar5 = iStack_34;
    if (0xfff < uVar4) {
      iVar5 = *(int *)(iStack_34 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iStack_34 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 9015 ; VA 0x006c5bf0 ; FUN_006c5bf0 */

void FUN_006c5bf0(int param_1)

{
  int *piVar1;
  
  if (param_1 < 1) {
    piVar1 = (int *)FUN_0054db20();
                    /* WARNING: Could not recover jumptable at 0x006c5c13. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*piVar1 + 0x124))();
    return;
  }
  piVar1 = (int *)FUN_0054db20();
  if (param_1 < 0xb) {
    (**(code **)(*piVar1 + 0x124))(10000);
    return;
  }
  if (9999 < param_1) {
    param_1 = 10000;
  }
  (**(code **)(*piVar1 + 0x124))(param_1 * 1000);
  return;
}



/* FUNCTION 9016 ; VA 0x006c5c60 ; FUN_006c5c60 */

undefined4 __fastcall FUN_006c5c60(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  int *piStack_28;
  int iStack_24;
  int *piStack_20;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a7e78;
  pvStack_10 = ExceptionList;
  iStack_24 = 0;
  piStack_20 = (int *)0x0;
  iVar5 = *(int *)(param_1 + 300);
  ExceptionList = &pvStack_10;
  if (iVar5 != 0) {
    piVar6 = (int *)(iVar5 + 4);
    iVar5 = *(int *)(iVar5 + 4);
    ExceptionList = &pvStack_10;
    while (iVar5 != 0) {
      LOCK();
      iVar3 = *piVar6;
      if (iVar5 == iVar3) {
        *piVar6 = iVar5 + 1;
        iVar3 = iVar5;
      }
      UNLOCK();
      if (iVar3 == iVar5) {
        iStack_24 = *(int *)(param_1 + 0x128);
        piStack_20 = *(int **)(param_1 + 300);
        break;
      }
      iVar5 = *piVar6;
    }
  }
  piVar6 = piStack_20;
  uStack_8 = 0;
  iStack_18 = param_1;
  if (iStack_24 == 0) {
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return 0;
  }
  if (DAT_01d6514b != '\0') {
    FUN_016774b0(DAT_01d6514b,"Packet receive start, data model: %p",iStack_24);
  }
  FUN_008e9840(iStack_24 + 0xc);
  uStack_8._0_1_ = 1;
  uStack_14 = uStack_14 & 0xffffff00;
  if ((DAT_01d5b6b0 != '\0') &&
     (FUN_016830f0(&uStack_34),
     (double)DAT_01d5b67c < (double)CONCAT44(uStack_30,uStack_34) - *(double *)(param_1 + 0x138))) {
    *(undefined4 *)(param_1 + 0x138) = uStack_34;
    uStack_14 = CONCAT31(uStack_14._1_3_,1);
    *(undefined4 *)(param_1 + 0x13c) = uStack_30;
  }
  puStack_2c = (undefined4 *)0x0;
  piStack_28 = (int *)0x0;
  iVar5 = *(int *)(iStack_18 + 0x134);
  if (iVar5 != 0) {
    piVar1 = (int *)(iVar5 + 4);
    iVar5 = *(int *)(iVar5 + 4);
    while (piVar6 = piStack_20, iVar5 != 0) {
      LOCK();
      iVar3 = *piVar1;
      if (iVar5 == iVar3) {
        *piVar1 = iVar5 + 1;
        iVar3 = iVar5;
      }
      UNLOCK();
      if (iVar3 == iVar5) {
        puStack_2c = *(undefined4 **)(iStack_18 + 0x130);
        piStack_28 = *(int **)(iStack_18 + 0x134);
        break;
      }
      iVar5 = *piVar1;
    }
  }
  piVar1 = piStack_28;
  puVar2 = puStack_2c;
  uStack_8._0_1_ = 2;
  if (puStack_2c != (undefined4 *)0x0) {
    piVar4 = (int *)FUN_0054db20();
    iVar5 = (**(code **)(*piVar4 + 0x5c))(uStack_14);
    while (iVar5 != 0) {
      (**(code **)(*(int *)*puVar2 + 0x60))(iVar5);
      piVar4 = (int *)FUN_0054db20();
      iVar5 = (**(code **)(*piVar4 + 0x5c))(uStack_14);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar5 = piVar1[1] + -1;
    piVar1[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar5 = piVar1[2] + -1;
      piVar1[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (DAT_01d6514b != '\0') {
    FUN_016774b0(DAT_01d6514b,"Packet receive finish, data model: %p",iStack_24);
  }
  FUN_008eb130();
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar5 = piVar6[1] + -1;
    piVar6[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar6)();
      LOCK();
      piVar1 = piVar6 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 9017 ; VA 0x006c5ed0 ; FUN_006c5ed0 */

void __fastcall FUN_006c5ed0(int param_1)

{
  int *piVar1;
  undefined4 uVar2;
  double *pdVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined4 *puVar7;
  int iVar8;
  float10 fVar9;
  double dVar10;
  double dVar11;
  undefined8 uStack_14;
  undefined8 uStack_c;
  
  if ((((*(int *)(param_1 + 0x84) != 0) && (*(int *)(param_1 + 0x7c) != 0)) &&
      (*(int *)(param_1 + 0x8c) != 0)) && (*(int *)(param_1 + 0x94) != 0)) {
    iVar8 = *(int *)(param_1 + 0x78);
    pdVar3 = (double *)FUN_016827a0(&uStack_14);
    dVar11 = *(double *)(iVar8 + 0xa8);
    uStack_c = *pdVar3 - *(double *)(iVar8 + 0x88);
    if (((*(char **)(iVar8 + 0xc0) == (char *)0x0) || (**(char **)(iVar8 + 0xc0) == '\0')) &&
       (dVar11 + dVar11 < uStack_c)) {
      dVar11 = uStack_c;
      uStack_14 = uStack_c;
    }
    if (NAN(dVar11) == (dVar11 == 0.0)) {
      dVar11 = *(double *)(iVar8 + 0x70) / dVar11;
    }
    else {
      dVar11 = (double)(0.0 < *(double *)(iVar8 + 0x70));
    }
    FUN_006c4cd0(SUB84(dVar11,0),(int)((ulonglong)dVar11 >> 0x20));
    iVar8 = *(int *)(param_1 + 0x78);
    pdVar3 = (double *)FUN_016827a0(&uStack_c);
    dVar11 = *(double *)(iVar8 + 0xa8);
    uStack_14 = *pdVar3 - *(double *)(iVar8 + 0x88);
    if (((*(char **)(iVar8 + 0xc0) == (char *)0x0) || (**(char **)(iVar8 + 0xc0) == '\0')) &&
       (dVar11 + dVar11 < uStack_14)) {
      dVar11 = uStack_14;
      uStack_c = uStack_14;
    }
    dVar10 = 0.0;
    if (0.0 < dVar11) {
      dVar10 = DAT_018c0d60 / dVar11;
    }
    uVar5 = (undefined4)((ulonglong)dVar10 >> 0x20);
    FUN_009ffd50(*(undefined4 *)(param_1 + 0x7c),SUB84(dVar10,0),uVar5,"%.2g/s",SUB84(dVar10,0),
                 uVar5);
    iVar8 = *(int *)(param_1 + 0x34);
    iVar4 = param_1;
    if ((iVar8 != 0) && (iVar4 = iVar8, *(int *)(iVar8 + 0x34) != 0)) {
      iVar4 = FUN_005c8ac0();
    }
    if ((iVar4 == 0) ||
       (iVar8 = *(int *)(iVar4 + 0xc), iVar4 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar4 + 0x1da) <
       (uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
      iVar8 = 0;
    }
    else {
      FUN_005789c0(&DAT_01eaef08,&LAB_006c41e0);
      uVar5 = FUN_006c4340();
      piVar6 = (int *)FUN_008aa140(uVar5);
      uStack_c = (double)CONCAT44(piVar6,(undefined4)uStack_c);
      if (*piVar6 == 0) {
        uVar5 = FUN_00c9ab50();
        puVar7 = (undefined4 *)FUN_008a9ba0(&uStack_14,uVar5);
        uVar5 = *puVar7;
        uVar2 = puVar7[1];
        *puVar7 = 0;
        puVar7[1] = 0;
        *uStack_c._4_4_ = uVar5;
        piVar6 = (int *)uStack_c._4_4_[1];
        uStack_c._4_4_[1] = uVar2;
        if (piVar6 != (int *)0x0) {
          LOCK();
          iVar8 = piVar6[1] + -1;
          piVar6[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piVar6)();
            LOCK();
            iVar8 = piVar6[2] + -1;
            piVar6[2] = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
        piVar6 = uStack_14._4_4_;
        if (uStack_14._4_4_ != (int *)0x0) {
          LOCK();
          iVar8 = uStack_14._4_4_[1] + -1;
          uStack_14._4_4_[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*uStack_14._4_4_)();
            LOCK();
            piVar1 = piVar6 + 2;
            iVar8 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar8 == 1) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
        piVar6 = uStack_c._4_4_;
      }
      iVar8 = *piVar6;
    }
    if (iVar8 == 0) {
      uStack_c = (double)((ulonglong)uStack_c & 0xffffffff);
    }
    else {
      uStack_c = (double)CONCAT44(*(undefined4 *)(iVar8 + 0x60),(undefined4)uStack_c);
    }
    FUN_009fdde0((int)&uStack_c + 4);
    fVar9 = (float10)FUN_006af9e0();
    uStack_14 = (double)fVar9;
    FUN_009ffd50(*(undefined4 *)(param_1 + 0x94),uStack_14,&DAT_018dd664,uStack_14);
  }
  return;
}



/* FUNCTION 9018 ; VA 0x006c6180 ; FUN_006c6180 */

int FUN_006c6180(undefined4 param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  int iVar2;
  
  iVar2 = FUN_006c8d20(param_1,param_2);
  *(undefined ***)(iVar2 + 8) = RBX::Network::ReplicationDataBlob::vftable;
  *(undefined4 *)(iVar2 + 0xc) = *(undefined4 *)(param_3 + 4);
  *(undefined4 *)(iVar2 + 0x10) = *(undefined4 *)(param_3 + 8);
  *(undefined4 *)(iVar2 + 0x14) = *(undefined4 *)(param_3 + 0xc);
  *(undefined *)(iVar2 + 0x18) = *(undefined *)(param_3 + 0x10);
  *(undefined *)(iVar2 + 0x19) = *(undefined *)(param_3 + 0x11);
  FUN_006c83e0(param_3 + 0x14);
  uVar1 = *(undefined4 *)(param_3 + 0x3c);
  *(undefined4 *)(param_3 + 0x3c) = 0;
  *(undefined4 *)(iVar2 + 0x44) = uVar1;
  *(undefined4 *)(iVar2 + 0x48) = 0;
  *(undefined4 *)(iVar2 + 0x4c) = 0;
  *(undefined4 *)(iVar2 + 0x50) = 0;
  *(undefined4 *)(iVar2 + 0x48) = *(undefined4 *)(param_3 + 0x40);
  *(undefined4 *)(iVar2 + 0x4c) = *(undefined4 *)(param_3 + 0x44);
  *(undefined4 *)(iVar2 + 0x50) = *(undefined4 *)(param_3 + 0x48);
  *(undefined4 *)(param_3 + 0x40) = 0;
  *(undefined4 *)(param_3 + 0x44) = 0;
  *(undefined4 *)(param_3 + 0x48) = 0;
  *(undefined4 *)(iVar2 + 0x54) = 0;
  *(undefined4 *)(iVar2 + 0x58) = 0;
  *(undefined4 *)(iVar2 + 0x5c) = 0;
  *(undefined4 *)(iVar2 + 0x54) = *(undefined4 *)(param_3 + 0x4c);
  *(undefined4 *)(iVar2 + 0x58) = *(undefined4 *)(param_3 + 0x50);
  *(undefined4 *)(iVar2 + 0x5c) = *(undefined4 *)(param_3 + 0x54);
  *(undefined4 *)(param_3 + 0x4c) = 0;
  *(undefined4 *)(param_3 + 0x50) = 0;
  *(undefined4 *)(param_3 + 0x54) = 0;
  return iVar2;
}



/* FUNCTION 9019 ; VA 0x006c6260 ; FUN_006c6260 */

void FUN_006c6260(int *param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  
  if (param_1 != param_2) {
    piVar2 = param_1 + 0xc;
    do {
      FUN_00617ad0();
      if ((undefined4 *)*piVar2 != (undefined4 *)0x0) {
        (*(code *)**(undefined4 **)*piVar2)(1);
      }
      FUN_0061ac80();
      FUN_006c8890();
      piVar1 = piVar2 + 0xc;
      piVar2 = piVar2 + 0x18;
    } while (piVar1 != param_2);
  }
  return;
}



/* FUNCTION 9020 ; VA 0x006c62b0 ; FUN_006c62b0 */

int __thiscall
FUN_006c62b0(int *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  
  iVar7 = *param_1;
  iVar3 = (int)param_2 - iVar7 >> 3;
  iVar4 = param_1[1] - iVar7 >> 3;
  if (iVar4 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar4 + 1;
  uVar8 = param_1[2] - iVar7 >> 3;
  uVar5 = uVar1;
  if ((uVar8 <= 0x1fffffff - (uVar8 >> 1)) && (uVar5 = (uVar8 >> 1) + uVar8, uVar5 < uVar1)) {
    uVar5 = uVar1;
  }
  uVar8 = uVar5 * 8;
  if (uVar5 < 0x20000000) {
    if (0xfff < uVar8) goto LAB_006c6327;
    if (uVar8 == 0) {
      puVar11 = (undefined4 *)0x0;
    }
    else {
      puVar11 = (undefined4 *)FUN_01674e20(uVar8);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_006c6327:
    uVar6 = uVar8 + 0x23;
    if (uVar6 <= uVar8) {
      uVar6 = 0xffffffff;
    }
    iVar7 = FUN_01674e20(uVar6);
    if (iVar7 == 0) goto LAB_006c6442;
    puVar11 = (undefined4 *)(iVar7 + 0x23U & 0xffffffe0);
    puVar11[-1] = iVar7;
  }
  uVar2 = *param_3;
  puVar11[iVar3 * 2 + 1] = *param_4;
  puVar11[iVar3 * 2] = uVar2;
  puVar12 = (undefined4 *)param_1[1];
  puVar9 = (undefined4 *)*param_1;
  puVar10 = puVar11;
  if (param_2 == puVar12) {
    for (; puVar9 != puVar12; puVar9 = puVar9 + 2) {
      *puVar10 = *puVar9;
      puVar10[1] = puVar9[1];
      puVar10 = puVar10 + 2;
    }
  }
  else {
    if (puVar9 != param_2) {
      do {
        *puVar10 = *puVar9;
        puVar12 = puVar9 + 1;
        puVar9 = puVar9 + 2;
        puVar10[1] = *puVar12;
        puVar10 = puVar10 + 2;
      } while (puVar9 != param_2);
      puVar12 = (undefined4 *)param_1[1];
    }
    if (param_2 != puVar12) {
      puVar9 = puVar11 + iVar3 * 2 + 2;
      do {
        *puVar9 = *param_2;
        puVar10 = param_2 + 1;
        param_2 = param_2 + 2;
        puVar9[1] = *puVar10;
        puVar9 = puVar9 + 2;
      } while (param_2 != puVar12);
    }
  }
  iVar7 = *param_1;
  if (iVar7 != 0) {
    uVar8 = param_1[2] - iVar7 & 0xfffffff8;
    iVar4 = iVar7;
    if (0xfff < uVar8) {
      iVar4 = *(int *)(iVar7 + -4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (iVar7 - iVar4) - 4U) {
LAB_006c6442:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar8);
  }
  *param_1 = (int)puVar11;
  param_1[1] = (int)(puVar11 + uVar1 * 2);
  param_1[2] = (int)(puVar11 + uVar5 * 2);
  return *param_1 + iVar3 * 8;
}



/* FUNCTION 9021 ; VA 0x006c6450 ; FUN_006c6450 */

int __thiscall
FUN_006c6450(int *param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7e90;
  pvStack_10 = ExceptionList;
  iVar8 = *param_1;
  iVar2 = (param_1[1] - iVar8) / 0x60;
  if (iVar2 == 0x2aaaaaa) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar3 = (param_1[2] - iVar8) / 0x60;
  uVar7 = uVar1;
  if ((uVar3 <= 0x2aaaaaa - (uVar3 >> 1)) && (uVar7 = (uVar3 >> 1) + uVar3, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar4 = FUN_006c9410(uVar7);
  uStack_8 = 0;
  iVar5 = ((param_2 - iVar8) / 0x60) * 0x60;
  iVar6 = iVar5 + iVar4;
  iVar8 = iVar6 + 0x60;
  FUN_006c7830(param_1,iVar6,param_3,param_4,param_5,param_6,param_7);
  iVar6 = param_1[1];
  if (param_2 == iVar6) {
    param_2 = *param_1;
    iVar8 = iVar4;
  }
  else {
    FUN_006c7340(*param_1,param_2,iVar4,param_1);
    iVar6 = param_1[1];
  }
  FUN_006c7340(param_2,iVar6,iVar8,param_1);
  FUN_006c8d50(iVar4,iVar2 + 1,uVar7);
  ExceptionList = pvStack_10;
  return *param_1 + iVar5;
}



/* FUNCTION 9022 ; VA 0x006c6593 ; Catch_All@006c6593 */

void Catch_All_006c6593(void)

{
  int unaff_EBP;
  
  FUN_006c8e10(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x18));
  FUN_006c96a0(*(undefined4 *)(unaff_EBP + -0x30),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9023 ; VA 0x006c65c0 ; FUN_006c65c0 */

int __thiscall
FUN_006c65c0(int *param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7ea0;
  pvStack_10 = ExceptionList;
  iVar8 = *param_1;
  iVar2 = (param_1[1] - iVar8) / 0x60;
  if (iVar2 == 0x2aaaaaa) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar2 + 1;
  uVar3 = (param_1[2] - iVar8) / 0x60;
  uVar7 = uVar1;
  if ((uVar3 <= 0x2aaaaaa - (uVar3 >> 1)) && (uVar7 = (uVar3 >> 1) + uVar3, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  ExceptionList = &pvStack_10;
  iVar4 = FUN_006c9410(uVar7);
  uStack_8 = 0;
  iVar5 = ((param_2 - iVar8) / 0x60) * 0x60;
  iVar6 = iVar5 + iVar4;
  iVar8 = iVar6 + 0x60;
  FUN_006c7970(param_1,iVar6,param_3,param_4,param_5);
  iVar6 = param_1[1];
  if (param_2 == iVar6) {
    param_2 = *param_1;
    iVar8 = iVar4;
  }
  else {
    FUN_006c7340(*param_1,param_2,iVar4,param_1);
    iVar6 = param_1[1];
  }
  FUN_006c7340(param_2,iVar6,iVar8,param_1);
  FUN_006c8d50(iVar4,iVar2 + 1,uVar7);
  ExceptionList = pvStack_10;
  return *param_1 + iVar5;
}



/* FUNCTION 9024 ; VA 0x006c66fd ; Catch_All@006c66fd */

void Catch_All_006c66fd(void)

{
  int unaff_EBP;
  
  FUN_006c8e10(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x18));
  FUN_006c96a0(*(undefined4 *)(unaff_EBP + -0x30),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9025 ; VA 0x006c6730 ; FUN_006c6730 */

int __thiscall FUN_006c6730(uint *param_1,uint param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  
  uVar12 = *param_1;
  iVar10 = param_2 - uVar12;
  iVar2 = (int)(param_1[1] - uVar12) / 0x18;
  if (iVar2 == 0xaaaaaaa) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar8 = iVar2 + 1;
  uVar6 = (int)(param_1[2] - uVar12) / 0x18;
  uVar12 = uVar8;
  if ((uVar6 <= 0xaaaaaaa - (uVar6 >> 1)) && (uVar12 = (uVar6 >> 1) + uVar6, uVar12 < uVar8)) {
    uVar12 = uVar8;
  }
  uVar8 = uVar12 * 0x18;
  if (uVar12 < 0xaaaaaab) {
    uVar12 = uVar8;
    if (0xfff < uVar8) goto LAB_006c67cb;
    if (uVar8 == 0) {
      uVar12 = 0;
    }
    else {
      uVar12 = FUN_01674e20(uVar8);
    }
  }
  else {
    uVar12 = 0xffffffff;
LAB_006c67cb:
    uVar6 = uVar12 + 0x23;
    if (uVar6 <= uVar12) {
      uVar6 = 0xffffffff;
    }
    iVar7 = FUN_01674e20(uVar6);
    if (iVar7 == 0) goto LAB_006c690b;
    uVar12 = iVar7 + 0x23U & 0xffffffe0;
    *(int *)(uVar12 - 4) = iVar7;
  }
  iVar10 = (iVar10 / 0x18) * 0x18;
  puVar1 = (undefined4 *)(iVar10 + uVar12);
  uVar3 = param_3[1];
  uVar4 = param_3[2];
  uVar5 = param_3[3];
  *puVar1 = *param_3;
  puVar1[1] = uVar3;
  puVar1[2] = uVar4;
  puVar1[3] = uVar5;
  *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(param_3 + 4);
  uVar6 = param_1[1];
  if (param_2 == uVar6) {
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(uVar12,*param_1,uVar6 - *param_1);
  }
  else {
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(uVar12,*param_1,param_2 - *param_1);
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(puVar1 + 6,param_2,param_1[1] - param_2);
  }
  uVar6 = *param_1;
  if (uVar6 != 0) {
    uVar9 = ((int)(param_1[2] - uVar6) / 0x18) * 0x18;
    uVar11 = uVar6;
    if (0xfff < uVar9) {
      uVar11 = *(uint *)(uVar6 - 4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (uVar6 - uVar11) - 4) {
LAB_006c690b:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar9);
  }
  *param_1 = uVar12;
  param_1[1] = uVar12 + (iVar2 * 3 + 3) * 8;
  param_1[2] = uVar8 + uVar12;
  return *param_1 + iVar10;
}



/* FUNCTION 9026 ; VA 0x006c6920 ; FUN_006c6920 */

int __thiscall FUN_006c6920(int *param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined8 *puVar5;
  int iVar6;
  undefined8 *puVar7;
  uint uVar8;
  undefined8 *puVar9;
  int iVar10;
  undefined8 *puVar11;
  
  iVar6 = *param_1;
  iVar2 = (param_1[1] - *param_1) / 0xc;
  if (iVar2 == 0x15555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar3 = iVar2 + 1;
  uVar8 = (param_1[2] - *param_1) / 0xc;
  uVar4 = uVar3;
  if ((uVar8 <= 0x15555555 - (uVar8 >> 1)) && (uVar4 = (uVar8 >> 1) + uVar8, uVar4 < uVar3)) {
    uVar4 = uVar3;
  }
  puVar5 = (undefined8 *)FUN_00618050(uVar4);
  iVar6 = (((int)param_2 - iVar6) / 0xc) * 0xc;
  puVar1 = (undefined8 *)(iVar6 + (int)puVar5);
  *puVar1 = *param_3;
  *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_3 + 1);
  puVar11 = (undefined8 *)param_1[1];
  puVar7 = (undefined8 *)*param_1;
  puVar9 = puVar5;
  if (param_2 == puVar11) {
    for (; puVar7 != puVar11; puVar7 = (undefined8 *)((int)puVar7 + 0xc)) {
      *puVar9 = *puVar7;
      *(undefined4 *)(puVar9 + 1) = *(undefined4 *)(puVar7 + 1);
      puVar9 = (undefined8 *)((int)puVar9 + 0xc);
    }
  }
  else {
    if (puVar7 != param_2) {
      do {
        *puVar9 = *puVar7;
        puVar11 = puVar7 + 1;
        puVar7 = (undefined8 *)((int)puVar7 + 0xc);
        *(undefined4 *)(puVar9 + 1) = *(undefined4 *)puVar11;
        puVar9 = (undefined8 *)((int)puVar9 + 0xc);
      } while (puVar7 != param_2);
      puVar11 = (undefined8 *)param_1[1];
    }
    if (param_2 != puVar11) {
      do {
        *(undefined8 *)((int)puVar1 + 0xc) = *param_2;
        puVar7 = param_2 + 1;
        param_2 = (undefined8 *)((int)param_2 + 0xc);
        *(undefined4 *)((int)puVar1 + 0x14) = *(undefined4 *)puVar7;
        puVar1 = (undefined8 *)((int)puVar1 + 0xc);
      } while (param_2 != puVar11);
    }
  }
  iVar2 = *param_1;
  if (iVar2 != 0) {
    uVar8 = ((param_1[2] - iVar2) / 0xc) * 0xc;
    iVar10 = iVar2;
    if (0xfff < uVar8) {
      iVar10 = *(int *)(iVar2 + -4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (iVar2 - iVar10) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar10,uVar8);
  }
  *param_1 = (int)puVar5;
  param_1[1] = (int)puVar5 + uVar3 * 0xc;
  param_1[2] = (int)puVar5 + uVar4 * 0xc;
  return *param_1 + iVar6;
}



/* FUNCTION 9027 ; VA 0x006c6ad0 ; FUN_006c6ad0 */

int __thiscall FUN_006c6ad0(int *param_1,int param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  
  iVar2 = *param_1;
  iVar8 = param_2 - iVar2;
  iVar3 = param_1[1] - iVar2 >> 3;
  if (iVar3 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar3 + 1;
  uVar6 = param_1[2] - iVar2 >> 3;
  uVar7 = uVar1;
  if ((uVar6 <= 0x1fffffff - (uVar6 >> 1)) && (uVar7 = (uVar6 >> 1) + uVar6, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  iVar4 = FUN_00578020(uVar7);
  iVar2 = (iVar8 >> 3) * 8;
  puVar5 = (undefined4 *)(iVar4 + iVar2);
  *puVar5 = *param_3;
  puVar5[1] = param_3[1];
  iVar3 = param_1[1];
  if (param_2 == iVar3) {
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(iVar4,*param_1,iVar3 - *param_1);
  }
  else {
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(iVar4,*param_1,param_2 - *param_1);
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(puVar5 + 2,param_2,param_1[1] - param_2);
  }
  FUN_00654980(iVar4,uVar1,uVar7);
  return *param_1 + iVar2;
}



/* FUNCTION 9028 ; VA 0x006c6bf0 ; FUN_006c6bf0 */

void __thiscall FUN_006c6bf0(int *param_1,int *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  bool bVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  uint uVar10;
  int *piVar11;
  int *piVar12;
  int iVar13;
  
  uVar10 = 0;
  piVar5 = param_3;
  if (param_3 != param_4) {
    do {
      piVar5 = (int *)*piVar5;
      uVar10 = uVar10 + 1;
    } while (piVar5 != param_4);
  }
  iVar6 = (int)param_2 - *param_1 >> 2;
  if ((uVar10 == 1) && (param_2 == (int *)param_1[1])) {
    bVar4 = true;
  }
  else {
    bVar4 = false;
    if (uVar10 == 0) {
      return;
    }
  }
  piVar5 = (int *)param_1[1];
  if (uVar10 <= (uint)(param_1[2] - (int)piVar5 >> 2)) {
    if (uVar10 < (uint)((int)piVar5 - (int)param_2 >> 2)) {
      piVar11 = piVar5 + -uVar10;
      piVar12 = piVar5;
      for (piVar9 = piVar11; piVar9 != piVar5; piVar9 = piVar9 + 1) {
        iVar6 = *piVar9;
        *piVar12 = iVar6;
        LOCK();
        piVar1 = (int *)(iVar6 + 0x28);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
        piVar12 = piVar12 + 1;
      }
      param_1[1] = (int)piVar12;
      while (piVar11 != param_2) {
        iVar6 = piVar11[-1];
        piVar5 = piVar5 + -1;
        piVar11 = piVar11 + -1;
        LOCK();
        piVar12 = (int *)(iVar6 + 0x28);
        *piVar12 = *piVar12 + 1;
        UNLOCK();
        *piVar5 = iVar6;
        FUN_0056cd30();
      }
      piVar5 = param_2;
      if (param_2 != param_2 + uVar10) {
        do {
          FUN_0056cd30();
          piVar5 = piVar5 + 1;
        } while (piVar5 != param_2 + uVar10);
      }
      if (param_3 != param_4) {
        do {
          iVar6 = param_3[2];
          *param_2 = iVar6;
          LOCK();
          piVar5 = (int *)(iVar6 + 0x28);
          *piVar5 = *piVar5 + 1;
          UNLOCK();
          param_3 = (int *)*param_3;
          param_2 = param_2 + 1;
        } while (param_3 != param_4);
        return;
      }
    }
    else {
      piVar9 = param_2 + uVar10;
      piVar12 = param_2;
      if (param_2 != piVar5) {
        do {
          iVar6 = *piVar12;
          *piVar9 = iVar6;
          LOCK();
          piVar11 = (int *)(iVar6 + 0x28);
          *piVar11 = *piVar11 + 1;
          UNLOCK();
          piVar12 = piVar12 + 1;
          piVar9 = piVar9 + 1;
        } while (piVar12 != piVar5);
      }
      param_1[1] = (int)piVar9;
      piVar12 = param_2;
      if (param_2 != piVar5) {
        do {
          FUN_0056cd30();
          piVar12 = piVar12 + 1;
        } while (piVar12 != piVar5);
      }
      if (param_3 != param_4) {
        do {
          iVar6 = param_3[2];
          *param_2 = iVar6;
          LOCK();
          piVar5 = (int *)(iVar6 + 0x28);
          *piVar5 = *piVar5 + 1;
          UNLOCK();
          param_3 = (int *)*param_3;
          param_2 = param_2 + 1;
        } while (param_3 != param_4);
      }
    }
    return;
  }
  iVar13 = (int)piVar5 - *param_1 >> 2;
  if (0x3fffffffU - iVar13 < uVar10) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar2 = uVar10 + iVar13;
  uVar8 = param_1[2] - *param_1 >> 2;
  uVar7 = uVar2;
  if ((uVar8 <= 0x3fffffff - (uVar8 >> 1)) && (uVar7 = (uVar8 >> 1) + uVar8, uVar7 < uVar2)) {
    uVar7 = uVar2;
  }
  iVar13 = FUN_00577ed0(uVar7);
  piVar5 = (int *)(iVar13 + iVar6 * 4);
  if (param_3 != param_4) {
    do {
      iVar3 = param_3[2];
      *piVar5 = iVar3;
      LOCK();
      piVar12 = (int *)(iVar3 + 0x28);
      *piVar12 = *piVar12 + 1;
      UNLOCK();
      param_3 = (int *)*param_3;
      piVar5 = piVar5 + 1;
    } while (param_3 != param_4);
  }
  if (!bVar4) {
    FUN_00617ca0(*param_1,param_2,iVar13);
    FUN_00617ca0(param_2,param_1[1],iVar13 + (iVar6 + uVar10) * 4);
    FUN_00616de0(iVar13,uVar2,uVar7);
    return;
  }
  FUN_00617cd0(*param_1,param_1[1],iVar13);
  FUN_00616de0(iVar13,uVar2,uVar7);
  return;
}



/* FUNCTION 9029 ; VA 0x006c6e50 ; FUN_006c6e50 */

void __thiscall FUN_006c6e50(int *param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  uint uVar2;
  int iVar3;
  undefined8 *puVar4;
  
  *param_1 = 0;
  uVar2 = ((int)param_3 - (int)param_2) / 0xc;
  param_1[1] = 0;
  param_1[2] = 0;
  if (uVar2 != 0) {
    if (0x15555555 < uVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar3 = FUN_00618050(uVar2);
    *param_1 = iVar3;
    param_1[1] = iVar3;
    param_1[2] = *param_1 + uVar2 * 0xc;
    puVar4 = (undefined8 *)*param_1;
    if (param_2 != param_3) {
      do {
        *puVar4 = *param_2;
        puVar1 = param_2 + 1;
        param_2 = (undefined8 *)((int)param_2 + 0xc);
        *(undefined4 *)(puVar4 + 1) = *(undefined4 *)puVar1;
        puVar4 = (undefined8 *)((int)puVar4 + 0xc);
      } while (param_2 != param_3);
    }
    param_1[1] = (int)puVar4;
  }
  return;
}



/* FUNCTION 9030 ; VA 0x006c6ee0 ; FUN_006c6ee0 */

void __thiscall FUN_006c6ee0(int *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uStack_8;
  
  uVar1 = param_2;
  iVar2 = param_1[1];
  iVar3 = *param_1;
  uVar4 = iVar2 - iVar3 >> 3;
  uStack_8 = param_1[2] - iVar3 >> 3;
  if (param_2 <= uStack_8) {
    if (param_2 <= uVar4) {
      if (param_2 != uVar4) {
        param_1[1] = iVar3 + param_2 * 8;
      }
      return;
    }
    iVar3 = param_2 - uVar4;
    if (iVar3 != 0) {
      FUN_0170d1f0(iVar2,0,iVar3 * 8);
      iVar2 = iVar2 + iVar3 * 8;
    }
    param_1[1] = iVar2;
    return;
  }
  if (0x1fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  if (0x1fffffff - (uStack_8 >> 1) < uStack_8) {
    uStack_8 = param_2;
  }
  else {
    uStack_8 = (uStack_8 >> 1) + uStack_8;
    if (uStack_8 < param_2) {
      uStack_8 = param_2;
    }
  }
  iVar2 = FUN_00578020(uStack_8);
  iVar3 = uVar1 - uVar4;
  if (iVar3 != 0) {
    FUN_0170d1f0(iVar2 + uVar4 * 8,0,iVar3 * 8);
  }
  iVar3 = *param_1;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  FUN_0170cc70(iVar2,iVar3,param_1[1] - iVar3);
  FUN_00654980(iVar2,uVar1,uStack_8);
  return;
}



/* FUNCTION 9031 ; VA 0x006c6fe0 ; FUN_006c6fe0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __thiscall FUN_006c6fe0(int *param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  void **ppvVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  int iVar13;
  undefined *puVar14;
  undefined *puVar15;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  uStack_8 = 0xff;
  uStack_7 = 0xffffff;
  puStack_c = &LAB_017a7ec8;
  pvStack_10 = ExceptionList;
  iVar5 = param_1[1];
  iVar8 = param_1[2] - *param_1;
  uVar10 = (iVar5 - *param_1) / 0x18;
  uStack_20 = iVar8 / 0x18;
  if (param_2 <= uStack_20) {
    if (uVar10 < param_2) {
      ExceptionList = &pvStack_10;
      piVar7 = (int *)FUN_006c8c20(iVar5,param_2 - uVar10);
      param_1[1] = (int)piVar7;
      ExceptionList = pvStack_10;
      return piVar7;
    }
    piVar7 = (int *)(iVar8 * 0x2aaaaaab);
    if (param_2 != uVar10) {
      iVar8 = *param_1 + param_2 * 0x18;
      ppvVar3 = &pvStack_10;
      for (iVar13 = iVar8; ExceptionList = ppvVar3, iVar13 != iVar5; iVar13 = iVar13 + 0x18) {
        FUN_00612650();
        ppvVar3 = (void **)ExceptionList;
      }
      param_1[1] = iVar8;
      piVar7 = param_1;
    }
    ExceptionList = pvStack_10;
    return piVar7;
  }
  if (0xaaaaaaa < param_2) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  if (0xaaaaaaa - (uStack_20 >> 1) < uStack_20) {
    uStack_20 = param_2;
  }
  else {
    uStack_20 = (uStack_20 >> 1) + uStack_20;
    if (uStack_20 < param_2) {
      uStack_20 = param_2;
    }
  }
  uVar9 = uStack_20 * 0x18;
  if (uStack_20 < 0xaaaaaab) {
    if (0xfff < uVar9) goto LAB_006c7086;
    if (uVar9 == 0) {
      puVar14 = (undefined *)0x0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      puVar14 = (undefined *)FUN_01674e20(uVar9);
    }
  }
  else {
    uVar9 = 0xffffffff;
LAB_006c7086:
    uVar4 = uVar9 + 0x23;
    if (uVar4 <= uVar9) {
      uVar4 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar5 = FUN_01674e20(uVar4);
    if (iVar5 == 0) goto LAB_006c7302;
    puVar14 = (undefined *)(iVar5 + 0x23U & 0xffffffe0);
    *(int *)(puVar14 + -4) = iVar5;
  }
  uStack_8 = 0;
  uStack_7 = 0;
  FUN_006c8c20(puVar14 + uVar10 * 0x18,param_2 - uVar10);
  iVar5 = param_1[1];
  puVar15 = puVar14;
  for (iVar8 = *param_1; uStack_8 = 1, iVar8 != iVar5; iVar8 = iVar8 + 0x18) {
    *puVar15 = 0;
    uVar6 = FUN_005c9310(*(undefined4 *)(iVar8 + 8));
    *(undefined4 *)(puVar15 + 8) = 0;
    *(undefined4 *)(puVar15 + 4) = uVar6;
    *(undefined4 *)(puVar15 + 0xc) = *(undefined4 *)(iVar8 + 0xc);
    *(undefined4 *)(puVar15 + 0x10) = 0;
    *(undefined4 *)(puVar15 + 0x14) = 0;
    uStack_8 = 2;
    if (*(int *)(iVar8 + 8) != 0) {
      FUN_005d2b00(uVar6);
      uStack_8 = 3;
      if (*(int *)(iVar8 + 8) == 0) {
        puVar12 = (undefined4 *)0x0;
      }
      else {
        puVar12 = *(undefined4 **)(*(int *)(iVar8 + 0x14) + *(int *)(iVar8 + 4) * 4);
      }
      puVar11 = (undefined4 *)(*(int *)(puVar15 + 0x14) + *(int *)(puVar15 + 4) * 4);
      while (puVar12 != (undefined4 *)0x0) {
        FUN_006c7ae0(puVar12 + 2);
        _DAT_00000004 = puVar12[1];
        *puVar11 = 0;
        *(int *)(puVar15 + 8) = *(int *)(puVar15 + 8) + 1;
        puVar2 = (undefined4 *)*puVar11;
        puVar12 = (undefined4 *)*puVar12;
        puVar1 = (undefined4 *)
                 (*(int *)(puVar15 + 0x14) + ((uint)puVar2[1] % *(uint *)(puVar15 + 4)) * 4);
        if (*(int *)(*(int *)(puVar15 + 0x14) + ((uint)puVar2[1] % *(uint *)(puVar15 + 4)) * 4) == 0
           ) {
          *puVar1 = puVar11;
          puVar11 = puVar2;
        }
        else {
          *puVar11 = *puVar2;
          *puVar2 = *(undefined4 *)*puVar1;
          *(undefined4 **)*puVar1 = puVar2;
        }
      }
    }
    puVar15 = puVar15 + 0x18;
  }
  iVar5 = *param_1;
  if (iVar5 != 0) {
    iVar8 = param_1[1];
    if (iVar5 != iVar8) {
      do {
        FUN_00612650();
        iVar5 = iVar5 + 0x18;
      } while (iVar5 != iVar8);
      iVar5 = *param_1;
    }
    uVar10 = ((param_1[2] - iVar5) / 0x18) * 0x18;
    iVar8 = iVar5;
    if (0xfff < uVar10) {
      iVar8 = *(int *)(iVar5 + -4);
      uVar10 = uVar10 + 0x23;
      if (0x1f < (iVar5 - iVar8) - 4U) {
LAB_006c7302:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar8,uVar10);
  }
  *param_1 = (int)puVar14;
  param_1[1] = (int)(puVar14 + param_2 * 0x18);
  param_1[2] = (int)(puVar14 + uStack_20 * 0x18);
  ExceptionList = pvStack_10;
  return (int *)(puVar14 + uStack_20 * 0x18);
}



/* FUNCTION 9032 ; VA 0x006c7307 ; Catch_All@006c7307 */

void Catch_All_006c7307(void)

{
  int unaff_EBP;
  undefined4 uVar1;
  undefined4 uVar2;
  
  FUN_006c8de0(*(undefined4 *)(unaff_EBP + -0x28),*(undefined4 *)(unaff_EBP + -0x24));
  uVar2 = *(undefined4 *)(unaff_EBP + -0x1c);
  uVar1 = *(undefined4 *)(unaff_EBP + -0x2c);
  FUN_0054eb90(uVar1,uVar2);
  FUN_0057d2f0(uVar1,uVar2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9033 ; VA 0x006c7340 ; FUN_006c7340 */

undefined4 *
FUN_006c7340(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a7ee8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    puVar3 = param_1 + 0x13;
    ExceptionList = &pvStack_10;
    do {
      *param_3 = puVar3[-0x13];
      param_3[1] = puVar3[-0x12];
      param_3[2] = 0;
      param_3[3] = 0;
      uVar2 = FUN_006c8d20(0,0);
      param_3[2] = uVar2;
      param_3[2] = puVar3[-0x11];
      puVar3[-0x11] = uVar2;
      uVar2 = param_3[3];
      param_3[3] = puVar3[-0x10];
      puVar3[-0x10] = uVar2;
      *(undefined *)(param_3 + 4) = 0;
      param_3[5] = puVar3[-0xe];
      param_3[6] = puVar3[-0xd];
      param_3[7] = puVar3[-0xc];
      param_3[8] = puVar3[-0xb];
      param_3[9] = puVar3[-10];
      puVar3[-10] = 0;
      puVar3[-0xd] = 0;
      puVar3[-0xb] = 0;
      param_3[10] = puVar3[-9];
      param_3[0xb] = puVar3[-8];
      uVar2 = puVar3[-7];
      puVar3[-7] = 0;
      param_3[0xc] = uVar2;
      param_3[0xd] = puVar3[-6];
      param_3[0xe] = puVar3[-5];
      param_3[0xf] = puVar3[-4];
      param_3[0x10] = puVar3[-3];
      param_3[0x11] = puVar3[-2];
      param_3[0x12] = 0;
      param_3[0x13] = 0;
      param_3[0x14] = 0;
      param_3[0x12] = puVar3[-1];
      param_3[0x13] = *puVar3;
      param_3[0x14] = puVar3[1];
      puVar3[-1] = 0;
      *puVar3 = 0;
      puVar3[1] = 0;
      param_3[0x15] = puVar3[2];
      param_3[0x16] = puVar3[3];
      param_3[0x17] = puVar3[4];
      param_3 = param_3 + 0x18;
      puVar1 = puVar3 + 5;
      puVar3 = puVar3 + 0x18;
    } while (puVar1 != param_2);
  }
  FUN_006c6260(param_3,param_3,param_4);
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 9034 ; VA 0x006c74e0 ; FUN_006c74e0 */

void __thiscall FUN_006c74e0(undefined4 *param_1,int param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  undefined8 uVar8;
  undefined auStack_44 [12];
  undefined4 *puStack_38;
  undefined uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7f24;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaefe0) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eaefe0), DAT_01eaefe0 == -1)) {
    uStack_8 = 0;
    uVar8 = FUN_0152dab0("TaskQueue","addTasks",0xffffffff);
    DAT_01eaefdc = (undefined4)((ulonglong)uVar8 >> 0x20);
    DAT_01eaefd8 = (undefined4)uVar8;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eaefe0);
  }
  uStack_30 = DAT_01eaefd8;
  uStack_2c = DAT_01eaefdc;
  uVar8 = FUN_0152d930(DAT_01eaefd8,DAT_01eaefdc);
  puStack_38 = param_1 + 8;
  uStack_8 = 1;
  iVar2 = FUN_016dee6d(puStack_38);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  uStack_34 = 1;
  LOCK();
  param_1[0x1e] = param_1[0x1e] + (param_3 - param_2 >> 5);
  UNLOCK();
  piVar6 = (int *)(param_1[0x29] + (param_3 - param_2 >> 5));
  iStack_1c = param_3;
  piVar3 = (int *)param_1[0x27];
  iStack_18 = param_2;
  if (piVar3 < piVar6) {
    uStack_8._0_1_ = 3;
    do {
      piVar3 = (int *)((uint)((int)piVar3 * 3) >> 1);
    } while (piVar3 < piVar6);
    piStack_20 = piVar3;
    puVar4 = (undefined4 *)FUN_01674f30((int)piVar3 << 5);
    puStack_28 = puVar4;
    if (param_1[0x29] != 0) {
      uVar7 = 0;
      do {
        puStack_14 = (uint *)(((param_1[0x28] + uVar7) % (uint)param_1[0x27]) * 0x20 + param_1[0x2a]
                             );
        *puVar4 = 0;
        FUN_005880d0(puStack_14);
        uStack_8._0_1_ = 4;
        uVar1 = *puStack_14;
        if (uVar1 != 0) {
          if ((uVar1 & 1) == 0) {
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              (**(code **)(uVar1 & 0xfffffffe))(puStack_14 + 2,puStack_14 + 2,2);
            }
          }
          *puStack_14 = 0;
        }
        uVar7 = uVar7 + 1;
        uStack_8._0_1_ = 3;
        puVar4 = puVar4 + 8;
        param_2 = iStack_18;
        param_3 = iStack_1c;
      } while (uVar7 < (uint)param_1[0x29]);
    }
    FUN_01674ea0(param_1[0x2a]);
    param_1[0x27] = piStack_20;
    param_1[0x28] = 0;
    param_1[0x2a] = puStack_28;
  }
  uStack_8._0_1_ = 2;
  for (; param_2 != param_3; param_2 = param_2 + 0x20) {
    *(undefined4 *)
     (((uint)(param_1[0x29] + param_1[0x28]) % (uint)param_1[0x27]) * 0x20 + param_1[0x2a]) = 0;
    FUN_005880d0(param_2);
    param_1[0x29] = param_1[0x29] + 1;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  iVar2 = FUN_016deec8(param_1 + 8);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (*(char *)(param_1 + 6) == '\0') {
LAB_006c7794:
    uStack_8 = 7;
    FUN_0152dda0(uStack_30,uStack_2c,uVar8);
    ExceptionList = pvStack_10;
    return;
  }
  iVar2 = param_1[1];
  uStack_24 = 0;
  piStack_20 = (int *)0x0;
  if (iVar2 != 0) {
    piVar3 = (int *)(iVar2 + 4);
    iVar2 = *(int *)(iVar2 + 4);
    while (iVar2 != 0) {
      LOCK();
      iVar5 = *piVar3;
      if (iVar2 == iVar5) {
        *piVar3 = iVar2 + 1;
        iVar5 = iVar2;
      }
      UNLOCK();
      if (iVar5 == iVar2) {
        uStack_24 = *param_1;
        piVar3 = (int *)param_1[1];
        uStack_8 = CONCAT31(uStack_8._1_3_,6);
        if (piVar3 != (int *)0x0) {
          LOCK();
          piVar3[1] = piVar3[1] + 1;
          UNLOCK();
        }
        piStack_20 = piVar3;
        FUN_0151dbc0(uStack_24,piVar3);
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar2 = piVar3[1] + -1;
          piVar3[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            piVar6 = piVar3 + 2;
            iVar2 = *piVar6;
            *piVar6 = *piVar6 + -1;
            UNLOCK();
            if (iVar2 == 1) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        goto LAB_006c7794;
      }
      iVar2 = *piVar3;
    }
  }
  FUN_005c47d0();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_44,&DAT_01c21d80);
}



/* FUNCTION 9035 ; VA 0x006c7830 ; FUN_006c7830 */

void FUN_006c7830(undefined4 param_1,undefined4 *param_2,undefined4 param_3,undefined4 *param_4,
                 undefined4 *param_5,undefined4 *param_6,undefined4 *param_7)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined **ppuVar5;
  undefined **ppuVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7f51;
  pvStack_10 = ExceptionList;
  uVar1 = *param_7;
  param_6 = (undefined4 *)*param_6;
  param_7 = (undefined4 *)*param_5;
  uVar2 = *param_4;
  ExceptionList = &pvStack_10;
  *param_2 = param_3;
  param_2[1] = 0;
  puVar7 = param_2 + 2;
  *puVar7 = 0;
  param_2[3] = 0;
  param_5 = puVar7;
  uVar4 = FUN_006c8d20(0,0);
  puVar3 = param_2;
  *puVar7 = uVar4;
  uStack_8 = 0;
  *(undefined *)(param_2 + 4) = 0;
  param_2 = (undefined4 *)0xb;
  ppuVar5 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
  ppuVar6 = ppuVar5 + -1;
  if (ppuVar5 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar6 = ppuVar5;
  }
  puVar3[5] = *ppuVar6;
  puVar3[6] = 0;
  puVar3[7] = 0x3f800000;
  puVar3[8] = 0;
  puVar3[9] = 0;
  puVar3[0xb] = uVar2;
  puVar3[0xc] = 0;
  puVar3[0xd] = 0;
  puVar3[0xe] = 0;
  puVar3[0xf] = 0;
  puVar3[0x10] = 0;
  puVar3[0x11] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  puVar3[0x12] = 0;
  puVar3[0x13] = 0;
  puVar3[0x14] = 0;
  FUN_006c6e50(0,0,param_2);
  puVar3[0x15] = param_7;
  puVar3[0x16] = param_6;
  puVar3[0x17] = uVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9036 ; VA 0x006c7970 ; FUN_006c7970 */

void FUN_006c7970(undefined4 param_1,undefined4 *param_2,undefined4 param_3,undefined4 *param_4,
                 undefined4 *param_5)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined **ppuVar4;
  undefined **ppuVar5;
  
  uVar2 = *param_4;
  puVar1 = param_2 + 2;
  *param_2 = param_3;
  param_2[1] = 0;
  *puVar1 = 0;
  param_2[3] = 0;
  param_4 = puVar1;
  uVar3 = FUN_006c8d20(0,0);
  *puVar1 = uVar3;
  *(undefined *)(param_2 + 4) = 0;
  param_4 = (undefined4 *)0xb;
  ppuVar4 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_4);
  ppuVar5 = ppuVar4 + -1;
  if (ppuVar4 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar5 = ppuVar4;
  }
  param_2[5] = *ppuVar5;
  param_2[6] = 0;
  param_2[7] = 0x3f800000;
  param_2[8] = 0;
  param_2[9] = 0;
  param_2[0xb] = uVar2;
  param_2[0xc] = 0;
  param_2[0xd] = 0;
  param_2[0xe] = 0;
  param_2[0xf] = 0;
  param_2[0x10] = 0;
  param_2[0x11] = 0;
  param_2[0x12] = 0;
  param_2[0x13] = 0;
  param_2[0x14] = 0;
  param_2[0x12] = *param_5;
  param_2[0x13] = param_5[1];
  param_2[0x14] = param_5[2];
  *param_5 = 0;
  param_5[1] = 0;
  param_5[2] = 0;
  param_2[0x15] = 0;
  param_2[0x16] = 0xffffffff;
  param_2[0x17] = 0xffffffff;
  return;
}



/* FUNCTION 9037 ; VA 0x006c7a80 ; FUN_006c7a80 */

void __thiscall FUN_006c7a80(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = *(int *)(param_1 + 4);
  if (iVar2 == 0) {
    *(undefined2 *)(param_1 + 8) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0x10);
    *(undefined4 **)(param_1 + 4) = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    *(undefined8 *)(puVar1 + 2) = 0;
    iVar2 = *(int *)(param_1 + 4);
    *(undefined *)(param_1 + 8) = 1;
  }
  else if (*(char *)(param_1 + 9) != '\0') {
    *(undefined *)(param_1 + 9) = 0;
  }
  *(undefined4 *)(iVar2 + 8) = *param_2;
  *(undefined4 *)(iVar2 + 0xc) = param_2[1];
  *(undefined *)(param_1 + 9) = 1;
  return;
}



/* FUNCTION 9038 ; VA 0x006c7ae0 ; FUN_006c7ae0 */

void __thiscall FUN_006c7ae0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  
  if (*(int *)(param_1 + 4) == 0) {
    *(undefined2 *)(param_1 + 8) = 0;
    puVar3 = (undefined4 *)FUN_01674e20(0xc);
    *(undefined4 **)(param_1 + 4) = puVar3;
    *puVar3 = 0;
    puVar3[1] = 0;
    puVar3[2] = 0;
    *(undefined *)(param_1 + 8) = 1;
  }
  else if (*(char *)(param_1 + 9) != '\0') {
    FUN_0056cd30();
    *(undefined *)(param_1 + 9) = 0;
  }
  iVar2 = *param_2;
  *(int *)(*(int *)(param_1 + 4) + 8) = iVar2;
  LOCK();
  piVar1 = (int *)(iVar2 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  *(undefined *)(param_1 + 9) = 1;
  return;
}



/* FUNCTION 9039 ; VA 0x006c7b50 ; FUN_006c7b50 */

undefined4 * __thiscall
FUN_006c7b50(byte *param_1,undefined4 *param_2,uint *param_3,undefined2 *param_4)

{
  uint *puVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined2 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar1 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7f68;
  pvStack_10 = ExceptionList;
  iVar3 = (*param_3 >> 3) + *param_3;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_3,iVar3,param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_3 != (uint *)0x0) {
    *param_2 = param_3;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return param_2;
  }
  puStack_18 = (undefined4 *)0x0;
  uStack_1c = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  uStack_8 = 0;
  uStack_14 = 0;
  puStack_18 = (undefined4 *)FUN_01674e20(0x10);
  uStack_14 = 0x101;
  *puStack_18 = 0;
  puStack_18[1] = 0;
  *(undefined8 *)(puStack_18 + 2) = 0;
  puStack_18[2] = *puVar1;
  *(undefined2 *)(puStack_18 + 3) = *param_4;
  FUN_0062b610(*(int *)(param_1 + 8) + 1);
  puVar2 = (undefined4 *)FUN_005c5550(&param_3,&uStack_1c,iVar3);
  *param_2 = *puVar2;
  *(undefined *)(param_2 + 1) = 1;
  if (puStack_18 != (undefined4 *)0x0) {
    FUN_01674ea0(puStack_18,0x10);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9040 ; VA 0x006c7c70 ; FUN_006c7c70 */

int __fastcall FUN_006c7c70(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00aff8c0();
  iVar3 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar3 = param_1;
  }
  return iVar3;
}



/* FUNCTION 9041 ; VA 0x006c7ca0 ; FUN_006c7ca0 */

void __thiscall FUN_006c7ca0(byte *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  int iVar2;
  uint uStack_28;
  undefined4 *puStack_24;
  undefined2 uStack_20;
  int iStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a7f88;
  pvStack_10 = ExceptionList;
  if (param_2 != param_3) {
    puStack_24 = (undefined4 *)0x0;
    uStack_20 = 0;
    uStack_28 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_006c7e90(&uStack_28,param_2 + 2,param_2,param_3);
    param_2 = (undefined4 *)*param_2;
    while (puStack_18 = param_2, param_2 != param_3) {
      iStack_14 = ((uint)param_2[2] >> 3) + param_2[2];
      FUN_00606ea0(&iStack_1c,iStack_14,param_2 + 2,
                   -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) &
                   (uint)(param_1 + *param_1 + 1 + 1));
      if (iStack_1c == 0) {
        if (puStack_24 == (undefined4 *)0x0) {
          uStack_20 = 0;
          puStack_24 = (undefined4 *)FUN_01674e20(0x14);
          uStack_20 = 1;
          *puStack_24 = 0;
          puStack_24[1] = 0;
          *(undefined8 *)(puStack_24 + 2) = 0;
          puStack_24[4] = 0;
        }
        uVar1 = param_2[3];
        puStack_24[2] = param_2[2];
        puStack_24[3] = uVar1;
        puStack_24[4] = param_2[4];
        uStack_20 = CONCAT11(1,(undefined)uStack_20);
        if (*(uint *)(param_1 + 0x10) < *(int *)(param_1 + 8) + 1U) {
          iVar2 = 0;
          for (; param_2 != param_3; param_2 = (undefined4 *)*param_2) {
            iVar2 = iVar2 + 1;
          }
          FUN_0062b610(iVar2 + *(int *)(param_1 + 8));
        }
        FUN_005c5550(&iStack_14,&uStack_28,iStack_14);
      }
      param_2 = (undefined4 *)*puStack_18;
    }
    if (puStack_24 != (undefined4 *)0x0) {
      FUN_01674ea0(puStack_24,0x14);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9042 ; VA 0x006c7e10 ; FUN_006c7e10 */

void __thiscall
FUN_006c7e10(int param_1,undefined4 param_2,int param_3,undefined4 *param_4,undefined4 *param_5)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar3 = param_3;
  uVar2 = FUN_00a33fd0(param_3);
  FUN_0061ded0(&param_3,uVar2,iVar3);
  if (param_3 == 0) {
    FUN_006c7ae0(param_4 + 2);
    if (*(uint *)(param_1 + 0x10) < *(int *)(param_1 + 8) + 1U) {
      iVar3 = 0;
      for (puVar1 = param_4; puVar1 != param_5; puVar1 = (undefined4 *)*puVar1) {
        iVar3 = iVar3 + 1;
      }
      FUN_0062b610(*(int *)(param_1 + 8) + iVar3);
    }
    FUN_005c5550(&param_3,param_2,uVar2);
  }
  return;
}



/* FUNCTION 9043 ; VA 0x006c7e90 ; FUN_006c7e90 */

void __thiscall
FUN_006c7e90(byte *param_1,int param_2,uint *param_3,undefined4 *param_4,undefined4 *param_5)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = (*param_3 >> 3) + *param_3;
  FUN_00606ea0(&param_3,iVar3,param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_3 == (uint *)0x0) {
    param_3 = param_4;
    iVar2 = *(int *)(param_2 + 4);
    if (iVar2 == 0) {
      *(undefined2 *)(param_2 + 8) = 0;
      puVar1 = (undefined4 *)FUN_01674e20(0x14);
      *(undefined4 **)(param_2 + 4) = puVar1;
      *puVar1 = 0;
      puVar1[1] = 0;
      *(undefined8 *)(puVar1 + 2) = 0;
      puVar1[4] = 0;
      iVar2 = *(int *)(param_2 + 4);
      *(undefined *)(param_2 + 8) = 1;
    }
    else if (*(char *)(param_2 + 9) != '\0') {
      *(undefined *)(param_2 + 9) = 0;
    }
    *(undefined8 *)(iVar2 + 8) = *(undefined8 *)(param_3 + 2);
    *(uint *)(iVar2 + 0x10) = param_3[4];
    *(undefined *)(param_2 + 9) = 1;
    if (*(uint *)(param_1 + 0x10) < *(int *)(param_1 + 8) + 1U) {
      iVar2 = 0;
      for (puVar1 = param_4; puVar1 != param_5; puVar1 = (undefined4 *)*puVar1) {
        iVar2 = iVar2 + 1;
      }
      FUN_0062b610(*(int *)(param_1 + 8) + iVar2);
    }
    FUN_005c5550(&param_3,param_2,iVar3);
  }
  return;
}



/* FUNCTION 9044 ; VA 0x006c7f70 ; FUN_006c7f70 */

undefined2 __fastcall FUN_006c7f70(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00aff8c0();
  return CONCAT11((char)(*(ushort *)(iVar2 + 0x1da) >> 8),
                  (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
                  (uint)*(ushort *)(iVar2 + 0x1da));
}



/* FUNCTION 9045 ; VA 0x006c7fa0 ; FUN_006c7fa0 */

void __thiscall FUN_006c7fa0(uint *param_1,int param_2,int param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint *puVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017939a0;
  pvStack_10 = ExceptionList;
  uVar6 = *param_1;
  uVar4 = param_1[2] + (param_3 - param_2 >> 5);
  ExceptionList = &pvStack_10;
  if (uVar6 < uVar4) {
    uStack_8._0_1_ = 0;
    uStack_8._1_3_ = 0;
    do {
      uVar6 = uVar6 * 3 >> 1;
    } while (uVar6 < uVar4);
    ExceptionList = &pvStack_10;
    puVar2 = (undefined4 *)FUN_01674f30(uVar6 << 5);
    if (param_1[2] != 0) {
      uVar4 = 0;
      puVar3 = puVar2;
      do {
        puVar5 = (uint *)(((param_1[1] + uVar4) % *param_1) * 0x20 + param_1[3]);
        *puVar3 = 0;
        FUN_005880d0(puVar5);
        uVar1 = *puVar5;
        uStack_8._0_1_ = 1;
        if (uVar1 != 0) {
          if ((uVar1 & 1) == 0) {
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              (**(code **)(uVar1 & 0xfffffffe))(puVar5 + 2,puVar5 + 2,2);
            }
          }
          *puVar5 = 0;
        }
        uVar4 = uVar4 + 1;
        puVar3 = puVar3 + 8;
        uStack_8._0_1_ = 0;
      } while (uVar4 < param_1[2]);
    }
    FUN_01674ea0(param_1[3]);
    param_1[3] = (uint)puVar2;
    param_1[1] = 0;
    *param_1 = uVar6;
  }
  uStack_8 = 0xffffffff;
  if (param_2 != param_3) {
    do {
      *(undefined4 *)(((param_1[1] + param_1[2]) % *param_1) * 0x20 + param_1[3]) = 0;
      FUN_005880d0(param_2);
      param_1[2] = param_1[2] + 1;
      param_2 = param_2 + 0x20;
    } while (param_2 != param_3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9046 ; VA 0x006c80e0 ; FUN_006c80e0 */

int __thiscall FUN_006c80e0(int param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  undefined **ppuVar2;
  undefined **ppuVar3;
  undefined4 uStack_48;
  undefined uStack_44;
  undefined *puStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined uStack_2c;
  undefined *puStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7fa8;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uStack_14 = 0xb;
  ExceptionList = &pvStack_10;
  ppuVar2 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
  puVar1 = param_2;
  uStack_20 = 0x3f800000;
  uStack_44 = 0;
  uStack_3c = 0;
  ppuVar3 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar3 = ppuVar2;
  }
  uStack_38 = 0x3f800000;
  uStack_48 = *param_2;
  uStack_34 = 0;
  puStack_40 = *ppuVar3;
  uStack_30 = 0;
  uStack_18 = 0;
  uStack_24 = 0;
  uStack_1c = 0;
  puStack_28 = puStack_40;
  FUN_00612320();
  uStack_8 = 0;
  FUN_006c81d0(param_3,&uStack_48,(int)&param_2 + 3);
  FUN_00612320();
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 0x10) = *puVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9047 ; VA 0x006c81d0 ; FUN_006c81d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint * __thiscall FUN_006c81d0(uint *param_1,uint param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7fd8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x9249249 < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar7 = param_2 * 0x1c;
    if (uVar7 < 0x1000) {
      if (uVar7 == 0) {
        uVar3 = 0;
      }
      else {
        uVar3 = FUN_01674e20(uVar7);
      }
    }
    else {
      uVar3 = uVar7 + 0x23;
      if (uVar3 <= uVar7) {
        uVar3 = 0xffffffff;
      }
      iVar4 = FUN_01674e20(uVar3);
      if (iVar4 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar3 = iVar4 + 0x23U & 0xffffffe0;
      *(int *)(uVar3 - 4) = iVar4;
    }
    *param_1 = uVar3;
    param_1[1] = uVar3;
    uStack_8._1_3_ = 0;
    param_1[2] = *param_1 + uVar7;
    puVar6 = (undefined4 *)*param_1;
    for (; uStack_8._0_1_ = 1, param_2 != 0; param_2 = param_2 - 1) {
      *puVar6 = *param_3;
      *(undefined *)(puVar6 + 1) = 0;
      uVar5 = FUN_005c9310(param_3[3]);
      puVar6[2] = uVar5;
      puVar6[3] = 0;
      puVar6[4] = param_3[4];
      puVar6[5] = 0;
      puVar6[6] = 0;
      uStack_8._0_1_ = 2;
      if (param_3[3] != 0) {
        FUN_005d2b00(uVar5);
        uStack_8._0_1_ = 3;
        if (param_3[3] == 0) {
          puVar8 = (undefined4 *)0x0;
        }
        else {
          puVar8 = *(undefined4 **)(param_3[6] + param_3[2] * 4);
        }
        puVar9 = (undefined4 *)(puVar6[6] + puVar6[2] * 4);
        while (puVar8 != (undefined4 *)0x0) {
          FUN_006c7a80(puVar8 + 2);
          _DAT_00000004 = puVar8[1];
          *puVar9 = 0;
          puVar6[3] = puVar6[3] + 1;
          puVar2 = (undefined4 *)*puVar9;
          puVar8 = (undefined4 *)*puVar8;
          puVar1 = (undefined4 *)(puVar6[6] + ((uint)puVar2[1] % (uint)puVar6[2]) * 4);
          if (*(int *)(puVar6[6] + ((uint)puVar2[1] % (uint)puVar6[2]) * 4) == 0) {
            *puVar1 = puVar9;
            puVar9 = puVar2;
          }
          else {
            *puVar9 = *puVar2;
            *puVar2 = *(undefined4 *)*puVar1;
            *(undefined4 **)*puVar1 = puVar2;
          }
        }
      }
      puVar6 = puVar6 + 7;
    }
    param_1[1] = (uint)puVar6;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9048 ; VA 0x006c83c0 ; Catch_All@006c83c0 */

void Catch_All_006c83c0(void)

{
  FUN_006c8f00();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9049 ; VA 0x006c83e0 ; FUN_006c83e0 */

undefined4 * __thiscall FUN_006c83e0(undefined4 *param_1,int param_2)

{
  *param_1 = RakNet::AbstractBitStream::vftable;
  *(undefined *)(param_1 + 1) = *(undefined *)(param_2 + 4);
  *param_1 = RBX::Network::NetworkStream::vftable;
  param_1[2] = *(undefined4 *)(param_2 + 8);
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[3] = *(undefined4 *)(param_2 + 0xc);
  param_1[4] = *(undefined4 *)(param_2 + 0x10);
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  *(undefined4 *)(param_2 + 0xc) = 0;
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0;
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  param_1[8] = *(undefined4 *)(param_2 + 0x20);
  *(undefined *)(param_1 + 9) = *(undefined *)(param_2 + 0x24);
  return param_1;
}



/* FUNCTION 9050 ; VA 0x006c8460 ; FUN_006c8460 */

undefined4 * __thiscall FUN_006c8460(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined **ppuVar6;
  undefined4 *puVar7;
  uint uVar8;
  undefined **ppuVar9;
  uint uVar10;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined8 uStack_34;
  undefined2 uStack_2c;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a808e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  param_2 = (undefined4 *)0x0;
  puStack_14 = param_1;
  FUN_006c80e0(&param_2,0);
  uStack_8 = 0;
  param_2 = (undefined4 *)0x0;
  FUN_006c80e0(&param_2,0);
  uStack_8._0_1_ = 1;
  param_2 = (undefined4 *)0x0;
  FUN_006c80e0(&param_2,0);
  param_1[0x13] = RBX::Network::ReplicationDataPreBlob::vftable;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = RBX::Network::ReplicationDataPreBlob::vftable;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = RBX::Network::ReplicationDataPreBlob::vftable;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  puVar7 = param_1 + 0x22;
  uStack_8._0_1_ = 5;
  *puVar7 = 0;
  param_1[0x23] = 0;
  param_2 = puVar7;
  uVar5 = FUN_006c8d20(0,0);
  *puVar7 = uVar5;
  puVar7 = param_1 + 0x24;
  uStack_8._0_1_ = 6;
  *puVar7 = 0;
  param_1[0x25] = 0;
  param_2 = puVar7;
  uVar5 = FUN_006c8d20(0,0);
  *puVar7 = uVar5;
  *(undefined *)(param_1 + 0x26) = 0;
  param_2 = (undefined4 *)0xb;
  ppuVar6 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
  ppuVar9 = ppuVar6 + -1;
  if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar9 = ppuVar6;
  }
  param_1[0x27] = *ppuVar9;
  param_1[0x28] = 0;
  param_1[0x29] = 0x3f800000;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  uStack_34 = DAT_018c45c8;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  uStack_38 = 0;
  uStack_2c = 0;
  uStack_3c = 0;
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  puVar7 = (undefined4 *)FUN_0151d9e0(auStack_24,&uStack_1c,4,&uStack_3c);
  uVar5 = *puVar7;
  uVar2 = puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  param_1[0x2f] = uVar5;
  piVar3 = (int *)param_1[0x30];
  param_1[0x30] = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_20[1] + -1;
    piStack_20[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar4 = piStack_20[2] + -1;
      piStack_20[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  piVar3 = piStack_18;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_18[1] + -1;
    piStack_18[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uVar8 = FUN_0151da90();
  uVar10 = 1;
  if (1 < uVar8) {
    uVar10 = uVar8;
  }
  param_1[0x34] = uVar10;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9051 ; VA 0x006c87c0 ; thunk_FUN_006c8f00 */

void __fastcall thunk_FUN_006c8f00(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_00612320();
        iVar2 = iVar2 + 0x1c;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x1c) * 0x1c;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 9052 ; VA 0x006c87d0 ; FUN_006c87d0 */

void __fastcall FUN_006c87d0(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  for (iVar2 = *param_1; iVar2 != iVar1; iVar2 = iVar2 + 0x1c) {
    FUN_00612320();
  }
  return;
}



/* FUNCTION 9053 ; VA 0x006c8800 ; FUN_006c8800 */

void __fastcall FUN_006c8800(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  for (iVar2 = *param_1; iVar2 != iVar1; iVar2 = iVar2 + 0x18) {
    FUN_00612650();
  }
  return;
}



/* FUNCTION 9054 ; VA 0x006c8830 ; FUN_006c8830 */

void __fastcall FUN_006c8830(undefined4 *param_1)

{
  FUN_006c6260(*param_1,param_1[1],param_1[2]);
  return;
}



/* FUNCTION 9055 ; VA 0x006c8850 ; FUN_006c8850 */

void __fastcall FUN_006c8850(int param_1)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 0xc);
  while (puVar1 != (undefined4 *)0x0) {
    *(undefined4 *)(param_1 + 0xc) = *puVar1;
    FUN_01674ea0(puVar1,0x10);
    puVar1 = *(undefined4 **)(param_1 + 0xc);
  }
  if (*(int *)(param_1 + 4) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 4),0x10);
  }
  return;
}



/* FUNCTION 9056 ; VA 0x006c8890 ; FUN_006c8890 */

void __fastcall FUN_006c8890(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)*param_1;
  piVar3 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar2 = (int *)*param_1;
  if (piVar3 != piVar2) {
    do {
      piVar1 = (int *)*piVar3;
      (**(code **)(piVar3[2] + 0x14))(0);
      FUN_01674ea0(piVar3,0x60);
      piVar2 = (int *)*param_1;
      piVar3 = piVar1;
    } while (piVar1 != piVar2);
  }
  FUN_01674ea0(piVar2,0x60);
  return;
}



/* FUNCTION 9057 ; VA 0x006c88e0 ; FUN_006c88e0 */

void FUN_006c88e0(void)

{
  FUN_00612320();
  return;
}



/* FUNCTION 9058 ; VA 0x006c88f0 ; FUN_006c88f0 */

void __fastcall FUN_006c88f0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_00612650();
        iVar2 = iVar2 + 0x18;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x18) * 0x18;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 9059 ; VA 0x006c8970 ; FUN_006c8970 */

void __fastcall FUN_006c8970(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_006c6260(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x60) * 0x60;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 9060 ; VA 0x006c89f0 ; FUN_006c89f0 */

void __fastcall FUN_006c89f0(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = param_1[0x13];
  if (iVar1 != 0) {
    uVar3 = param_1[0x15] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[0x13] = 0;
    param_1[0x14] = 0;
    param_1[0x15] = 0;
  }
  FUN_00612d60();
  if ((undefined4 *)param_1[0xf] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0xf])(1);
  }
  FUN_00613200();
  *param_1 = RBX::Network::ReplicationDataBlock::vftable;
  return;
}



/* FUNCTION 9061 ; VA 0x006c8a70 ; FUN_006c8a70 */

void __fastcall FUN_006c8a70(undefined4 *param_1)

{
  *param_1 = RBX::Network::ReplicationDataBlock::vftable;
  return;
}



/* FUNCTION 9062 ; VA 0x006c8a80 ; FUN_006c8a80 */

void __fastcall FUN_006c8a80(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    uVar3 = param_1[3] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
  }
  *param_1 = RBX::Network::ReplicationDataBlock::vftable;
  return;
}



/* FUNCTION 9063 ; VA 0x006c8ae0 ; FUN_006c8ae0 */

int * __thiscall FUN_006c8ae0(int *param_1,int *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  
  if (param_1 != param_2) {
    iVar1 = *param_2;
    *param_2 = 0;
    puVar2 = (undefined4 *)*param_1;
    *param_1 = iVar1;
    if (puVar2 != (undefined4 *)0x0) {
      (**(code **)*puVar2)(1);
    }
  }
  return param_1;
}



/* FUNCTION 9064 ; VA 0x006c8b10 ; FUN_006c8b10 */

uint * __thiscall FUN_006c8b10(byte *param_1,uint *param_2)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined2 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7f68;
  pvStack_10 = ExceptionList;
  uVar1 = *param_2;
  iVar3 = (uVar1 >> 3) + uVar1;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_2,iVar3,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (uint *)0x0) {
    ExceptionList = pvStack_10;
    return param_2 + 3;
  }
  puStack_18 = (undefined4 *)0x0;
  uStack_1c = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  uStack_8 = 0;
  uStack_14 = 0;
  puStack_18 = (undefined4 *)FUN_01674e20(0x10);
  uStack_14 = 0x101;
  *puStack_18 = 0;
  puStack_18[1] = 0;
  *(undefined8 *)(puStack_18 + 2) = 0;
  puStack_18[2] = uVar1;
  *(undefined2 *)(puStack_18 + 3) = 0;
  FUN_0062b610(*(int *)(param_1 + 8) + 1);
  piVar2 = (int *)FUN_005c5550(&param_2,&uStack_1c,iVar3);
  iVar3 = *piVar2;
  if (puStack_18 != (undefined4 *)0x0) {
    FUN_01674ea0(puStack_18,0x10);
  }
  ExceptionList = pvStack_10;
  return (uint *)(iVar3 + 0xc);
}



/* FUNCTION 9065 ; VA 0x006c8c20 ; FUN_006c8c20 */

undefined * FUN_006c8c20(undefined *param_1,int param_2)

{
  undefined **ppuVar1;
  undefined **ppuVar2;
  int iVar3;
  
  iVar3 = param_2;
  if (param_2 != 0) {
    param_2 = 0xb;
    do {
      *param_1 = 0;
      ppuVar1 = (undefined **)
                FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
      ppuVar2 = (undefined **)&DAT_018be194;
      if (ppuVar1 != &boost::lock_error::vftable_meta_ptr) {
        ppuVar2 = ppuVar1;
      }
      *(undefined **)(param_1 + 4) = *ppuVar2;
      *(undefined4 *)(param_1 + 8) = 0;
      *(undefined4 *)(param_1 + 0xc) = 0x3f800000;
      *(undefined4 *)(param_1 + 0x10) = 0;
      *(undefined4 *)(param_1 + 0x14) = 0;
      param_1 = param_1 + 0x18;
      iVar3 = iVar3 + -1;
    } while (iVar3 != 0);
  }
  return param_1;
}



/* FUNCTION 9066 ; VA 0x006c8c90 ; FUN_006c8c90 */

undefined4 __thiscall FUN_006c8c90(undefined4 param_1,byte param_2)

{
  FUN_006c89f0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 9067 ; VA 0x006c8cc0 ; FUN_006c8cc0 */

undefined4 * __thiscall FUN_006c8cc0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Network::ReplicationDataBlock::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 9068 ; VA 0x006c8cf0 ; FUN_006c8cf0 */

undefined4 __thiscall FUN_006c8cf0(undefined4 param_1,byte param_2)

{
  FUN_006c8a80();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x14);
  }
  return param_1;
}



/* FUNCTION 9069 ; VA 0x006c8d20 ; FUN_006c8d20 */

void FUN_006c8d20(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_01674e20(0x60);
  if (param_1 == 0) {
    *piVar1 = (int)piVar1;
    piVar1[1] = (int)piVar1;
    return;
  }
  *piVar1 = param_1;
  piVar1[1] = param_2;
  return;
}



/* FUNCTION 9070 ; VA 0x006c8d50 ; FUN_006c8d50 */

void __thiscall FUN_006c8d50(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_006c6260(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x60) * 0x60;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  *param_1 = param_2;
  param_1[1] = param_3 * 0x60 + param_2;
  param_1[2] = param_4 * 0x60 + param_2;
  return;
}



/* FUNCTION 9071 ; VA 0x006c8de0 ; FUN_006c8de0 */

void FUN_006c8de0(int param_1,int param_2)

{
  if (param_1 != param_2) {
    do {
      FUN_00612650();
      param_1 = param_1 + 0x18;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 9072 ; VA 0x006c8e10 ; FUN_006c8e10 */

void __thiscall FUN_006c8e10(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_006c6260(param_2,param_3,param_1);
  return;
}



/* FUNCTION 9073 ; VA 0x006c8e30 ; FUN_006c8e30 */

void __thiscall FUN_006c8e30(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  int *piVar7;
  
  iVar2 = param_1[1];
  iVar3 = *param_1;
  piVar7 = (int *)FUN_00577ed0(param_2);
  piVar4 = (int *)param_1[1];
  piVar6 = piVar7;
  for (param_1 = (int *)*param_1; param_1 != piVar4; param_1 = param_1 + 1) {
    iVar5 = *param_1;
    *piVar6 = iVar5;
    LOCK();
    piVar1 = (int *)(iVar5 + 0x28);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    piVar6 = piVar6 + 1;
  }
  FUN_00616de0(piVar7,iVar2 - iVar3 >> 2,param_2);
  return;
}



/* FUNCTION 9074 ; VA 0x006c8e80 ; FUN_006c8e80 */

void __thiscall
FUN_006c8e80(int param_1,int param_2,int param_3,int param_4,int param_5,uint param_6)

{
  undefined4 uVar1;
  
  if (param_1 != param_3) {
    if (0x2aaaaa9U - *(int *)(param_1 + 4) < param_6) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    *(uint *)(param_1 + 4) = *(int *)(param_1 + 4) + param_6;
    *(int *)(param_3 + 4) = *(int *)(param_3 + 4) - param_6;
  }
  **(int **)(param_4 + 4) = param_5;
  **(int **)(param_5 + 4) = param_2;
  **(int **)(param_2 + 4) = param_4;
  uVar1 = *(undefined4 *)(param_2 + 4);
  *(undefined4 *)(param_2 + 4) = *(undefined4 *)(param_5 + 4);
  *(undefined4 *)(param_5 + 4) = *(undefined4 *)(param_4 + 4);
  *(undefined4 *)(param_4 + 4) = uVar1;
  return;
}



/* FUNCTION 9075 ; VA 0x006c8f00 ; FUN_006c8f00 */

void __fastcall FUN_006c8f00(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_00612320();
        iVar2 = iVar2 + 0x1c;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x1c) * 0x1c;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 9076 ; VA 0x006c8f90 ; FUN_006c8f90 */

void __thiscall FUN_006c8f90(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  
  piVar5 = *(int **)(param_1 + 8);
  if ((param_3 != (int *)*param_2) &&
     (((int *)(param_1 + 8) != param_2 || ((piVar5 != param_3 && (piVar5 != (int *)*param_3)))))) {
    FUN_006c8e80(piVar5,param_2,param_3,(int *)*param_3,1);
    piVar5 = *(int **)(param_1 + 8);
  }
  iVar1 = piVar5[1];
  *(int *)(param_1 + 4) = iVar1 + 8;
  uVar3 = (**(code **)(**(int **)(iVar1 + 0x44) + 8))();
  *(undefined4 *)(param_1 + 0x34) = uVar3;
  uVar3 = (**(code **)(*(int *)(*(int *)(param_1 + 4) + 0x14) + 8))();
  *(undefined4 *)(param_1 + 0x38) = uVar3;
  FUN_006ab670();
  piVar5 = (int *)(param_1 + 0x30);
  piVar4 = (int *)(*(int *)(param_1 + 4) + 0x3c);
  if (piVar5 != piVar4) {
    iVar1 = *piVar4;
    *piVar4 = 0;
    puVar2 = (undefined4 *)*piVar5;
    *piVar5 = iVar1;
    if (puVar2 != (undefined4 *)0x0) {
      (**(code **)*puVar2)(1);
    }
  }
  uVar3 = (**(code **)(*(int *)*piVar5 + 8))();
  *(undefined4 *)(param_1 + 0x28) = uVar3;
  if (DAT_01ee4215 != '\0') {
    FUN_01677520(DAT_01ee4215,"ReplicationDataCache:: Reuse Blob %p ",*(undefined4 *)(param_1 + 4));
  }
  return;
}



/* FUNCTION 9077 ; VA 0x006c9050 ; FUN_006c9050 */

void __thiscall FUN_006c9050(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 0xb4);
  if (*(undefined4 **)(param_1 + 0xb8) != puVar1) {
    *puVar1 = param_2;
    *(int *)(param_1 + 0xb4) = *(int *)(param_1 + 0xb4) + 4;
    return;
  }
  FUN_006030d0(puVar1,&param_2);
  return;
}



/* FUNCTION 9078 ; VA 0x006c9080 ; FUN_006c9080 */

void FUN_006c9080(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iStack_8;
  
  param_1 = (undefined4 *)*param_1;
  FUN_006c9df0(&iStack_8,&param_1);
  FUN_006c90c0(iStack_8 + 0xc,param_2,param_3,param_4);
  return;
}



/* FUNCTION 9079 ; VA 0x006c90c0 ; FUN_006c90c0 */

void __thiscall
FUN_006c90c0(int param_1,int param_2,undefined4 param_3,undefined4 param_4,char param_5)

{
  char cVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  char *pcVar10;
  int *piVar11;
  int aiStack_60 [5];
  uint uStack_4c;
  int aiStack_48 [5];
  uint uStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined auStack_18 [4];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  cVar1 = param_5;
  iVar7 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a80b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (DAT_01ee4215 != '\0') {
    if (param_5 == '\0') {
      pcVar10 = "non cacheable";
      ExceptionList = &pvStack_10;
    }
    else {
      iVar5 = *(int *)(*(int *)(param_2 + 4) + 0xc);
      ExceptionList = &pvStack_10;
      iVar3 = FUN_00aff8c0();
      pcVar10 = "part";
      if ((uint)*(ushort *)(iVar3 + 0x1da) <
          (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
        pcVar10 = "cacheable";
      }
    }
    puVar4 = (undefined4 *)FUN_008a2380(aiStack_48);
    uStack_8 = 0;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    FUN_01677520(DAT_01ee4215,"add to cache pending list: %p with name: %s, for type: %s",iVar7,
                 puVar4,pcVar10);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_34) {
      uVar8 = uStack_34 + 1;
      iVar5 = aiStack_48[0];
      if (0xfff < uVar8) {
        iVar5 = *(int *)(aiStack_48[0] + -4);
        uVar8 = uStack_34 + 0x24;
        if (0x1f < (aiStack_48[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar8);
    }
  }
  if (DAT_01d5b720 == '\0') {
    if (*(int *)(iVar7 + 0x20) != 0) {
      FUN_006cbc40(iVar7,1);
    }
    param_3._0_2_ = CONCAT11((undefined)param_4,(undefined)param_3);
    if (cVar1 == '\0') {
      iVar5 = 0x34;
    }
    else {
      iVar5 = *(int *)(*(int *)(iVar7 + 4) + 0xc);
      iVar3 = FUN_00aff8c0();
      iVar5 = (-(uint)((uint)*(ushort *)(iVar3 + 0x1da) <
                      (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) &
              0xffffffe8) + 0x1c;
    }
    piVar11 = (int *)(iStack_14 + iVar5);
    param_4 = *(undefined4 *)(*(int *)(iVar7 + 4) + 0xc);
    if ((uint)(((piVar11[1] - *piVar11) / 0x1c) * 3) >> 2 <= (uint)piVar11[3]) {
      FUN_006cc5b0();
    }
    FUN_006cb310(&param_4);
    iVar5 = FUN_006c7b50(auStack_18,&param_2,&param_3);
    iVar7 = param_2;
    if ((*(char *)(iVar5 + 4) != '\0') && (DAT_01ee4215 != '\0')) {
      puVar4 = (undefined4 *)FUN_009c9510(aiStack_60);
      uStack_8 = 1;
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      puVar6 = (undefined4 *)FUN_008a2380(auStack_30);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (0xf < (uint)puVar6[5]) {
        puVar6 = (undefined4 *)*puVar6;
      }
      FUN_01677490(DAT_01ee4215,
                   "ReplicationDataCache::addToCachePendingList(instance) :  inserting instance %s [ mrd = %p, guid=%s] to noBlobNonCacheableMRDMap"
                   ,puVar6,iVar7,puVar4);
      if (0xf < uStack_1c) {
        uVar9 = uStack_1c + 1;
        uVar8 = auStack_30[0];
        if (0xfff < uVar9) {
          uVar8 = *(uint *)(auStack_30[0] - 4);
          uVar9 = uStack_1c + 0x24;
          if (0x1f < (auStack_30[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar8,uVar9);
      }
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = auStack_30[0] & 0xffffff00;
      if (0xf < uStack_4c) {
        uVar8 = uStack_4c + 1;
        iVar7 = aiStack_60[0];
        if (0xfff < uVar8) {
          iVar7 = *(int *)(aiStack_60[0] + -4);
          uVar8 = uStack_4c + 0x24;
          if (0x1f < (aiStack_60[0] - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar7,uVar8);
      }
    }
    ExceptionList = pvStack_10;
    return;
  }
  if ((*(undefined4 **)(iVar7 + 0x24) != (undefined4 *)0x0) &&
     (cVar2 = (**(code **)**(undefined4 **)(iVar7 + 0x24))(), cVar2 != '\0')) {
    *(undefined4 *)(iVar7 + 0x20) = 0;
    FUN_006cbc40(iVar7,1);
  }
  if (cVar1 == '\0') {
    iVar5 = 0x74;
  }
  else {
    iVar5 = *(int *)(*(int *)(iVar7 + 4) + 0xc);
    iVar3 = FUN_00aff8c0();
    iVar5 = (-(uint)((uint)*(ushort *)(iVar3 + 0x1da) <
                    (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) &
            0xffffffec) + 0x60;
  }
  param_3._0_2_ = CONCAT11((undefined)param_4,(undefined)param_3);
  if (*(int *)(iVar7 + 0x24) != 0) {
    *(undefined2 *)(*(int *)(iStack_14 + iVar5 + 4) + 4 + *(int *)(iVar7 + 0x28) * 8) =
         (undefined2)param_3;
    ExceptionList = pvStack_10;
    return;
  }
  FUN_006cb170(iVar7,param_3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9080 ; VA 0x006c9410 ; FUN_006c9410 */

uint FUN_006c9410(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 * 0x60;
  if (param_1 < 0x2aaaaab) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 9081 ; VA 0x006c9480 ; FUN_006c9480 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_006c9480(int param_1,int param_2)

{
  float fVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  float10 fVar8;
  undefined4 *puStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a80d8;
  pvStack_10 = ExceptionList;
  fVar1 = *(float *)(param_2 + 0xc);
  puVar7 = *(undefined4 **)(param_1 + 0x14);
  ExceptionList = &pvStack_10;
  *(float *)(param_1 + 0xc) = fVar1;
  if (puVar7 == (undefined4 *)0x0) {
    uVar5 = 0;
  }
  else {
    fVar8 = (float10)FUN_01725160(((double)*(int *)(param_1 + 4) +
                                  (double)(&DAT_018c0d90)[-(*(int *)(param_1 + 4) >> 0x1f)]) *
                                  (double)fVar1);
    if ((double)fVar8 < _DAT_018c4e98) {
      uVar5 = FUN_016f3eb1();
    }
    else {
      uVar5 = 0xffffffff;
    }
  }
  *(uint *)(param_1 + 0x10) = uVar5;
  if ((*(int *)(param_1 + 8) != 0) || (*(int *)(param_2 + 8) != 0)) {
    if (*(uint *)(param_2 + 8) < uVar5) {
      puVar6 = puVar7 + *(int *)(param_1 + 4);
      for (; puVar7 != puVar6; puVar7 = puVar7 + 1) {
        *puVar7 = 0;
      }
    }
    else {
      FUN_005c9310();
      FUN_005d2b00();
    }
    puVar7 = (undefined4 *)0x0;
    if (*(int *)(param_1 + 8) != 0) {
      puVar7 = *(undefined4 **)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      *(undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4) = 0;
      *(undefined4 *)(param_1 + 8) = 0;
    }
    uStack_8 = 0;
    if (*(int *)(param_2 + 8) == 0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      puVar6 = *(undefined4 **)(*(int *)(param_2 + 0x14) + *(int *)(param_2 + 4) * 4);
    }
    puVar4 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
    while (puVar6 != (undefined4 *)0x0) {
      puStack_1c = (undefined4 *)0x0;
      if (puVar7 != (undefined4 *)0x0) {
        puVar2 = (undefined4 *)*puVar7;
        *puVar7 = 0;
        puStack_1c = puVar7;
        puVar7 = puVar2;
      }
      FUN_006c7a80(puVar6 + 2);
      puStack_1c[1] = puVar6[1];
      *puVar4 = puStack_1c;
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      puVar3 = (undefined4 *)*puVar4;
      puVar6 = (undefined4 *)*puVar6;
      uVar5 = (uint)puVar3[1] % *(uint *)(param_1 + 4);
      puVar2 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar5 * 4);
      if (*(int *)(*(int *)(param_1 + 0x14) + uVar5 * 4) == 0) {
        *puVar2 = puVar4;
        puVar4 = puVar3;
      }
      else {
        *puVar4 = *puVar3;
        *puVar3 = *(undefined4 *)*puVar2;
        *(undefined4 **)*puVar2 = puVar3;
      }
    }
    while (puVar7 != (undefined4 *)0x0) {
      puVar6 = (undefined4 *)*puVar7;
      FUN_01674ea0(puVar7,0x10);
      puVar7 = puVar6;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9082 ; VA 0x006c9660 ; FUN_006c9660 */

void __fastcall FUN_006c9660(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  iVar2 = *param_1;
  if (iVar2 != iVar1) {
    do {
      FUN_00612320();
      iVar2 = iVar2 + 0x1c;
    } while (iVar2 != iVar1);
    param_1[1] = *param_1;
    param_1[3] = 0;
    return;
  }
  param_1[1] = iVar2;
  param_1[3] = 0;
  return;
}



/* FUNCTION 9083 ; VA 0x006c96a0 ; FUN_006c96a0 */

void FUN_006c96a0(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x60;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 9084 ; VA 0x006c96e0 ; FUN_006c96e0 */

int __thiscall FUN_006c96e0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_01674ea0(puVar1,0x10);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar1 = (undefined4 *)*param_2;
    iVar2 = iVar2 + 1;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 9085 ; VA 0x006c9720 ; FUN_006c9720 */

bool __fastcall FUN_006c9720(int param_1)

{
  return *(int *)(param_1 + 0xc) == 0;
}



/* FUNCTION 9086 ; VA 0x006c9730 ; FUN_006c9730 */

undefined4 __thiscall FUN_006c9730(int param_1,uint *param_2)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  
  if (*(int *)(param_1 + 8) == 0) {
    return 0;
  }
  uVar7 = *param_2;
  uVar3 = (uVar7 >> 3) + uVar7;
  uVar6 = uVar3 % *(uint *)(param_1 + 4);
  piVar1 = *(int **)(uVar6 * 4 + *(int *)(param_1 + 0x14));
  if (piVar1 != (int *)0x0) {
    piVar2 = (int *)*piVar1;
    while( true ) {
      if ((piVar2 == (int *)0x0) || ((uint)piVar2[1] % *(uint *)(param_1 + 4) != uVar6)) {
        return 0;
      }
      if ((piVar2[1] == uVar3) && (uVar7 == piVar2[2])) break;
      piVar1 = piVar2;
      piVar2 = (int *)*piVar2;
    }
    uVar4 = FUN_006c96e0(piVar1,*piVar2);
    if (*piVar1 != 0) {
      uVar7 = *(uint *)(*piVar1 + 4) % *(uint *)(param_1 + 4);
      if (uVar6 == uVar7) {
        return uVar4;
      }
      *(int **)(*(int *)(param_1 + 0x14) + uVar7 * 4) = piVar1;
    }
    puVar5 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    if ((int *)*puVar5 == piVar1) {
      *puVar5 = 0;
    }
    return uVar4;
  }
  return 0;
}



/* FUNCTION 9087 ; VA 0x006c9810 ; FUN_006c9810 */

void __thiscall FUN_006c9810(int param_1,char param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  
  if (DAT_01ee4215 != '\0') {
    FUN_016774b0(DAT_01ee4215,"ReplicationDataCache::finalizeBlob : %p",*(undefined4 *)(param_1 + 4)
                );
  }
  if (*(int *)(param_1 + 4) != 0) {
    puVar1 = (undefined4 *)(param_1 + 0x30);
    if ((*(int **)(param_1 + 0x30) != (int *)0x0) &&
       ((param_2 != '\0' ||
        (iVar2 = (**(code **)(**(int **)(param_1 + 0x30) + 8))(),
        ((float)DAT_01d5b6e4 / DAT_018ce320) *
        (float)((double)*(int *)(param_1 + 0x2c) +
               (double)(&DAT_018c0d90)[-(*(int *)(param_1 + 0x2c) >> 0x1f)]) <=
        (float)((double)iVar2 + (double)(&DAT_018c0d90)[-(iVar2 >> 0x1f)]))))) {
      if (DAT_01d5b710 == '\0') {
        uVar3 = (**(code **)(*(int *)*puVar1 + 8))();
        *(undefined4 *)(*(int *)(param_1 + 4) + 4) = uVar3;
        uVar3 = (**(code **)(*(int *)*puVar1 + 8))();
        *(undefined4 *)(*(int *)(param_1 + 4) + 8) = uVar3;
      }
      FUN_00619a10(*puVar1,*(int *)(param_1 + 4) + 0x14,DAT_01d5be5c);
      iVar2 = (**(code **)(*(int *)*puVar1 + 8))();
      *(int *)(param_1 + 0x40) = *(int *)(param_1 + 0x40) + iVar2;
      iVar2 = (**(code **)(*(int *)(*(int *)(param_1 + 4) + 0x14) + 8))();
      *(int *)(param_1 + 0x44) = *(int *)(param_1 + 0x44) + iVar2;
      if (DAT_01ee4215 != '\0') {
        uVar3 = *(undefined4 *)(*(int *)(param_1 + 4) + 0xc);
        uVar4 = (**(code **)(*(int *)(*(int *)(param_1 + 4) + 0x14) + 8))();
        uVar5 = (**(code **)(*(int *)*puVar1 + 8))();
        uVar6 = (**(code **)(*(int *)(*(int *)(param_1 + 4) + 0x14) + 4))();
        FUN_01677520(DAT_01ee4215,
                     "ReplicationDataCache::Finalize curBlob %p, compressedStream=%p, numOfRawBytes=%d, numOfCompressedBytes=%d, numOfInstances=%d  "
                     ,*(undefined4 *)(param_1 + 4),uVar6,uVar5,uVar4,uVar3);
      }
      if ((DAT_01d5b710 == '\0') ||
         (iVar2 = (**(code **)(**(int **)(param_1 + 0x30) + 8))(),
         ((float)DAT_01d5b6e4 / DAT_018ce320) *
         (float)((double)*(int *)(param_1 + 0x2c) +
                (double)(&DAT_018c0d90)[-(*(int *)(param_1 + 0x2c) >> 0x1f)]) <=
         (float)((double)iVar2 + (double)(&DAT_018c0d90)[-(iVar2 >> 0x1f)]))) {
        FUN_006ab670();
      }
      else {
        FUN_006c8ae0((undefined4 *)(param_1 + 0x30));
      }
      *(undefined4 *)(param_1 + 0x28) = 0;
      *(undefined4 *)(param_1 + 4) = 0;
    }
  }
  return;
}



/* FUNCTION 9088 ; VA 0x006c99e0 ; FUN_006c99e0 */

void __thiscall FUN_006c99e0(int param_1,uint param_2,undefined2 *param_3,uint param_4)

{
  uint uVar1;
  uint *puVar2;
  undefined4 *puVar3;
  int *piVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  int aiStack_50 [5];
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined4 *puStack_28;
  undefined2 uStack_24;
  undefined2 uStack_22;
  uint uStack_20;
  int iStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  uVar1 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8108;
  pvStack_10 = ExceptionList;
  uStack_20 = param_2;
  ExceptionList = &pvStack_10;
  if (DAT_01ee4215 != '\0') {
    ExceptionList = &pvStack_10;
    puStack_14 = (undefined4 *)FUN_009c9510(aiStack_50);
    iStack_8 = 0;
    if (0xf < (uint)puStack_14[5]) {
      puStack_14 = (undefined4 *)*puStack_14;
    }
    puVar3 = (undefined4 *)FUN_008a2380(&uStack_38);
    iStack_8._0_1_ = 1;
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    FUN_01677490(DAT_01ee4215,"ReplicationDataCache::finalizeInstanceWrite : serializing %s [%s]",
                 puVar3,puStack_14,0);
    uVar10 = CONCAT22(uStack_22,uStack_24);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uVar10) {
      uVar9 = uVar10 + 1;
      uVar7 = uStack_38;
      if (0xfff < uVar9) {
        uVar7 = *(uint *)(uStack_38 - 4);
        uVar9 = uVar10 + 0x24;
        if (0x1f < (uStack_38 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar9);
    }
    puStack_28 = (undefined4 *)0x0;
    uStack_24 = 0xf;
    uStack_22 = 0;
    uStack_38 = uStack_38 & 0xffffff00;
    iStack_8 = 0xffffffff;
    if (0xf < uStack_3c) {
      uVar10 = uStack_3c + 1;
      iVar8 = aiStack_50[0];
      if (0xfff < uVar10) {
        iVar8 = *(int *)(aiStack_50[0] + -4);
        uVar10 = uStack_3c + 0x24;
        if (0x1f < (aiStack_50[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar8,uVar10);
    }
  }
  if ((param_4 == 0) || (param_4 == 3)) {
    if (DAT_01d5b720 == '\0') {
      *(undefined4 *)(uVar1 + 0x20) = *(undefined4 *)(param_1 + 4);
    }
    else {
      *(undefined4 *)(uVar1 + 0x24) = *(undefined4 *)(param_1 + 4);
    }
    *(int *)(uVar1 + 0x28) =
         (*(int *)(*(int *)(param_1 + 4) + 0x44) - *(int *)(*(int *)(param_1 + 4) + 0x40)) / 0x18;
  }
  if (param_4 == 1) {
    iStack_18 = *(int *)(param_1 + 4);
    iStack_1c = (*(int *)(iStack_18 + 0x44) - *(int *)(iStack_18 + 0x40)) / 0x18;
    param_4 = (uVar1 >> 3) + uVar1;
    iVar8 = param_1 + 0x11 + (uint)*(byte *)(param_1 + 0x10);
    FUN_00606ea0(&puStack_14,param_4,&param_2,-(uint)(iVar8 != 0) & iVar8 + 1U);
    if (puStack_14 == (undefined4 *)0x0) {
      puStack_28 = (undefined4 *)0x0;
      uStack_2c = -(uint)(param_1 != -0x13) & param_1 + 0x14U;
      iStack_8 = 2;
      uStack_24 = 0;
      puStack_28 = (undefined4 *)FUN_01674e20(0x14);
      *puStack_28 = 0;
      puStack_28[1] = 0;
      puStack_28[3] = 0;
      puStack_28[4] = 0;
      puStack_28[2] = uVar1;
      *(undefined8 *)(puStack_28 + 3) = 0;
      uStack_24 = 0x101;
      FUN_0062b610(*(int *)(param_1 + 0x18) + 1);
      piVar4 = (int *)FUN_005c5550(&param_2,&uStack_2c,param_4);
      iStack_8 = 0xffffffff;
      puVar3 = (undefined4 *)(*piVar4 + 8);
      if (puStack_28 != (undefined4 *)0x0) {
        FUN_01674ea0(puStack_28,0x14);
      }
    }
    else {
      puVar3 = puStack_14 + 2;
    }
    puVar3[1] = iStack_18;
    puVar3[2] = iStack_1c;
  }
  uVar1 = *(uint *)(param_1 + 0x28);
  iVar8 = (**(code **)(**(int **)(param_1 + 0x30) + 8))();
  uVar10 = uStack_20;
  param_4 = iVar8 - uVar1;
  uStack_24 = *param_3;
  iVar8 = *(int *)(param_1 + 4);
  uStack_30 = uStack_20;
  uStack_2c = 0;
  puStack_28 = (undefined4 *)0x0;
  puVar2 = *(uint **)(iVar8 + 0x44);
  uStack_38 = uVar1;
  uStack_34 = param_4;
  if (*(uint **)(iVar8 + 0x48) == puVar2) {
    FUN_006c6730(puVar2,&uStack_38);
  }
  else {
    *puVar2 = uVar1;
    puVar2[1] = param_4;
    puVar2[2] = uStack_20;
    puVar2[3] = 0;
    *(ulonglong *)(puVar2 + 4) = (ulonglong)CONCAT22(uStack_22,uStack_24) << 0x20;
    *(int *)(iVar8 + 0x44) = *(int *)(iVar8 + 0x44) + 0x18;
  }
  piVar4 = (int *)(*(int *)(param_1 + 4) + 0xc);
  *piVar4 = *piVar4 + 1;
  if (DAT_01d5b710 != '\0') {
    piVar4 = (int *)(*(int *)(param_1 + 4) + 4);
    *piVar4 = *piVar4 + param_4;
    piVar4 = (int *)(*(int *)(param_1 + 4) + 8);
    *piVar4 = *piVar4 + param_4;
  }
  uVar5 = (**(code **)(**(int **)(param_1 + 0x30) + 8))();
  *(undefined4 *)(param_1 + 0x28) = uVar5;
  if (DAT_01d5bc10 != '\0') {
    if (*(int *)(uVar10 + 4) != 0) {
      iVar8 = *(int *)(*(int *)(uVar10 + 4) + 0xc);
      iVar6 = FUN_00af0010();
      if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
          (uint)*(ushort *)(iVar6 + 0x1da)) {
        *(undefined *)(*(int *)(param_1 + 4) + 0x10) = 1;
        ExceptionList = pvStack_10;
        return;
      }
    }
    iVar8 = FUN_008aa870();
    iVar6 = thunk_FUN_00897b90();
    if (iVar6 == iVar8) {
      *(undefined *)(*(int *)(param_1 + 4) + 0x11) = 1;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9089 ; VA 0x006c9d50 ; FUN_006c9d50 */

uint __thiscall FUN_006c9d50(int *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  
  if (*param_1 != param_1[1]) {
    uVar1 = *param_2;
    if (uVar1 != param_1[4]) {
      uVar2 = (uVar1 >> 3) + uVar1;
      uVar5 = (param_1[1] - *param_1) / 0x1c - 1;
      uVar4 = 0;
      do {
        uVar2 = uVar2 & uVar5;
        puVar3 = (uint *)(*param_1 + uVar2 * 0x1c);
        if (*puVar3 == uVar1) goto LAB_006c9ddb;
        if (*puVar3 == param_1[4]) break;
        uVar2 = uVar2 + 1 + uVar4;
        uVar4 = uVar4 + 1;
      } while (uVar4 <= uVar5);
      puVar3 = (uint *)0x0;
LAB_006c9ddb:
      return (uint)(puVar3 + 1) & -(uint)(puVar3 != (uint *)0x0);
    }
  }
  return 0;
}



/* FUNCTION 9090 ; VA 0x006c9df0 ; FUN_006c9df0 */

void __thiscall FUN_006c9df0(int param_1,undefined4 *param_2,uint *param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  uint uVar5;
  
  uVar1 = *param_3;
  uVar5 = (uVar1 >> 3) + uVar1;
  uVar4 = uVar5 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar3 = (int *)0x0;
  }
  else {
    puVar2 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
    if (puVar2 == (undefined4 *)0x0) {
      piVar3 = (int *)0x0;
    }
    else {
      piVar3 = (int *)*puVar2;
    }
    if (piVar3 != (int *)0x0) {
      do {
        if (uVar5 == piVar3[1]) {
          if (uVar1 == piVar3[2]) break;
        }
        else if ((uint)piVar3[1] % *(uint *)(param_1 + 4) != uVar4) {
          *param_2 = 0;
          return;
        }
        piVar3 = (int *)*piVar3;
        if (piVar3 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar3;
  return;
}



/* FUNCTION 9091 ; VA 0x006c9e80 ; FUN_006c9e80 */

void __thiscall
FUN_006c9e80(int param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5)

{
  undefined uVar1;
  undefined **ppuVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined **ppuVar5;
  int iVar6;
  undefined4 *puVar7;
  uint uVar8;
  undefined4 *puVar9;
  int iVar10;
  bool bVar11;
  undefined8 uVar12;
  undefined auStack_50 [4];
  undefined *puStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  int iStack_28;
  int iStack_24;
  uint uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8190;
  pvStack_10 = ExceptionList;
  auStack_50[0] = 0;
  uStack_1c = 0xb;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  ppuVar2 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_1c);
  ppuVar5 = ppuVar2 + -1;
  if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar5 = ppuVar2;
  }
  puStack_4c = *ppuVar5;
  uStack_48 = 0;
  uStack_44 = 0x3f800000;
  uStack_40 = 0;
  uStack_3c = 0;
  *(undefined4 *)(param_1 + 0xd4) = 0;
  puVar3 = (undefined4 *)(param_1 + 0xd4);
  puVar9 = (undefined4 *)(param_1 + 0xf4);
  *(undefined4 *)(param_1 + 0xd8) = 0;
  *(undefined4 *)(param_1 + 0xdc) = 0;
  *(undefined4 *)(param_1 + 0xe0) = 0;
  *(undefined4 *)(param_1 + 0xe4) = 0;
  *(undefined4 *)(param_1 + 0xe8) = 0;
  *(undefined4 *)(param_1 + 0xec) = 0;
  *(undefined4 *)(param_1 + 0xf0) = 0;
  *puVar9 = 0;
  *(undefined4 *)(param_1 + 0xf8) = 0;
  *(undefined4 *)(param_1 + 0xfc) = 0;
  *(undefined4 *)(param_1 + 0x100) = 0;
  iStack_8 = 0;
  puStack_18 = puVar9;
  if (DAT_01ee4215 != '\0') {
    FUN_016774b0(DAT_01ee4215,
                 "ReplicationDataCache::generateDataBlobs : serializing and creating blobs for cacheable instances"
                 ,0);
  }
  iVar10 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  if ((*(int *)(iVar10 + 0x34) < DAT_01eaef60) && (FUN_016f3809(&DAT_01eaef60), DAT_01eaef60 == -1))
  {
    iStack_8._0_1_ = 1;
    uVar12 = FUN_0152dab0(&DAT_018c5904,"GenerateDataBlobsCacheable",0xffffffff);
    DAT_01eaef5c = (uint)((ulonglong)uVar12 >> 0x20);
    DAT_01eaef58 = (uint)uVar12;
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_016f37bf(&DAT_01eaef60);
  }
  uStack_20 = DAT_01eaef58;
  uStack_38 = DAT_01eaef58;
  uStack_1c = DAT_01eaef5c;
  uStack_34 = DAT_01eaef5c;
  uStack_30 = FUN_0152d930(DAT_01eaef58,DAT_01eaef5c);
  iStack_8 = CONCAT31(iStack_8._1_3_,2);
  if (DAT_01d5b720 == '\0') {
    FUN_006ca9c0(param_2,iStack_14 + 4,iStack_14 + 0x88,puVar3,auStack_50,0);
    FUN_006c9660();
    puVar9 = puStack_18;
  }
  else {
    FUN_006ca5f0(param_2,iStack_14 + 0x4c,iStack_14 + 0x88,puVar3,auStack_50,0);
    *(undefined4 *)(iStack_14 + 0x5c) = 0;
    *(undefined4 *)(iStack_14 + 0x54) = *(undefined4 *)(iStack_14 + 0x50);
  }
  if (*(int *)(iVar10 + 0x34) < DAT_01eaef70) {
    FUN_016f3809(&DAT_01eaef70);
    if (DAT_01eaef70 == -1) {
      iStack_8._0_1_ = 3;
      uVar12 = FUN_0152da50(&DAT_018c5904);
      DAT_01eaef6c = (undefined4)((ulonglong)uVar12 >> 0x20);
      DAT_01eaef68 = (undefined4)uVar12;
      iStack_8 = CONCAT31(iStack_8._1_3_,2);
      FUN_016f37bf(&DAT_01eaef70);
    }
  }
  FUN_0152d760(DAT_01eaef68,DAT_01eaef6c,"Number of serialized cacheable instances: %u",*puVar3);
  iStack_8._0_1_ = 4;
  FUN_0152dda0(uStack_20,uStack_1c,uStack_30);
  iStack_8._0_1_ = 0;
  if (DAT_01ee4215 != '\0') {
    FUN_016774b0(DAT_01ee4215,
                 "ReplicationDataCache::generateDataBlobs : serializing and creating blobs for part instances"
                 ,0);
  }
  if (*(int *)(iVar10 + 0x34) < DAT_01eaef80) {
    FUN_016f3809(&DAT_01eaef80);
    if (DAT_01eaef80 == -1) {
      iStack_8._0_1_ = 5;
      uVar12 = FUN_0152dab0(&DAT_018c5904,"GenerateDataBlobsParts",0xffffffff);
      DAT_01eaef7c = (uint)((ulonglong)uVar12 >> 0x20);
      DAT_01eaef78 = (undefined4)uVar12;
      iStack_8._0_1_ = 0;
      FUN_016f37bf(&DAT_01eaef80);
    }
  }
  uVar4 = DAT_01eaef78;
  uStack_38 = DAT_01eaef78;
  uStack_20 = DAT_01eaef7c;
  uStack_34 = DAT_01eaef7c;
  uVar12 = FUN_0152d930(DAT_01eaef78,DAT_01eaef7c);
  iStack_8 = CONCAT31(iStack_8._1_3_,6);
  uStack_30 = uVar12;
  FUN_006cb560();
  if (DAT_01d5b720 == '\0') {
    FUN_006ca9c0(param_2,iStack_14 + 0x1c,iStack_14 + 0x90,puStack_18,auStack_50,3);
    FUN_006c9660();
    puVar9 = puStack_18;
  }
  else {
    FUN_006ca5f0(param_2,iStack_14 + 0x60,iStack_14 + 0x90,puVar9,auStack_50,3);
    *(undefined4 *)(iStack_14 + 0x70) = 0;
    *(undefined4 *)(iStack_14 + 0x68) = *(undefined4 *)(iStack_14 + 100);
  }
  if (*(int *)(iVar10 + 0x34) < DAT_01eaef90) {
    FUN_016f3809(&DAT_01eaef90);
    if (DAT_01eaef90 == -1) {
      iStack_8._0_1_ = 7;
      uVar12 = FUN_0152da50(&DAT_018c5904);
      DAT_01eaef8c = (undefined4)((ulonglong)uVar12 >> 0x20);
      DAT_01eaef88 = (undefined4)uVar12;
      iStack_8 = CONCAT31(iStack_8._1_3_,6);
      FUN_016f37bf(&DAT_01eaef90);
    }
  }
  FUN_0152d760(DAT_01eaef88,DAT_01eaef8c,"Number of serialized parts instances: %u",*puVar9);
  iStack_8._0_1_ = 8;
  FUN_0152dda0(uVar4,uStack_20,uStack_30);
  iStack_8._0_1_ = 0;
  if (DAT_01ee4215 != '\0') {
    FUN_016774b0(DAT_01ee4215,
                 "ReplicationDataCache::generateDataBlobs : serializing and creating blobs for non-cacheable instances"
                 ,0);
  }
  if (*(int *)(iVar10 + 0x34) < DAT_01eaefa0) {
    FUN_016f3809(&DAT_01eaefa0);
    if (DAT_01eaefa0 == -1) {
      iStack_8._0_1_ = 9;
      uVar12 = FUN_0152dab0(&DAT_018c5904,"GenerateDataBlobsNotCacheable",0xffffffff);
      DAT_01eaef9c = (uint)((ulonglong)uVar12 >> 0x20);
      DAT_01eaef98 = (undefined4)uVar12;
      iStack_8._0_1_ = 0;
      FUN_016f37bf(&DAT_01eaefa0);
    }
  }
  uVar4 = DAT_01eaef98;
  uStack_38 = DAT_01eaef98;
  uStack_20 = DAT_01eaef9c;
  uStack_34 = DAT_01eaef9c;
  uVar12 = FUN_0152d930(DAT_01eaef98,DAT_01eaef9c);
  iStack_8 = CONCAT31(iStack_8._1_3_,10);
  puVar3 = (undefined4 *)(iStack_14 + 0xe4);
  uStack_30 = uVar12;
  if (DAT_01d5b720 == '\0') {
    FUN_006ca9c0(param_2,iStack_14 + 0x34,param_3,puVar3,auStack_50,1);
  }
  else {
    FUN_006ca5f0(param_2,iStack_14 + 0x74,param_3,puVar3,auStack_50,1);
  }
  if (*(int *)(iVar10 + 0x34) < DAT_01eaefb0) {
    FUN_016f3809(&DAT_01eaefb0);
    if (DAT_01eaefb0 == -1) {
      iStack_8._0_1_ = 0xb;
      uVar12 = FUN_0152da50(&DAT_018c5904);
      DAT_01eaefac = (undefined4)((ulonglong)uVar12 >> 0x20);
      DAT_01eaefa8 = (undefined4)uVar12;
      iStack_8 = CONCAT31(iStack_8._1_3_,10);
      FUN_016f37bf(&DAT_01eaefb0);
    }
  }
  FUN_0152d760(DAT_01eaefa8,DAT_01eaefac,"Number of serialized not cacheable instances: %u",*puVar3)
  ;
  iStack_8._0_1_ = 0xc;
  FUN_0152dda0(uVar4,uStack_20,uStack_30);
  iStack_8._0_1_ = 0;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 0;
  uVar8 = *(uint *)(iStack_14 + 0xc4);
  puVar3 = *(undefined4 **)(iStack_14 + 200);
  uStack_1c = uVar8;
  puStack_18 = puVar3;
  if ((undefined4 *)uVar8 != puVar3) {
    iVar10 = iStack_14 + 0x98;
    iStack_28 = iVar10;
    uVar12 = uStack_30;
    do {
      uStack_30._4_4_ = (uint)((ulonglong)uVar12 >> 0x20);
      if (*(int *)(uVar8 + 8) != 0) {
        puVar3 = *(undefined4 **)(*(int *)(uVar8 + 0x14) + *(int *)(uVar8 + 4) * 4);
        uStack_1c = uVar8;
        if (puVar3 != (undefined4 *)0x0) {
          uStack_30._0_4_ = 0;
          uStack_30._4_4_ = uStack_30._4_4_ & 0xffff0000;
          uStack_34 = -(uint)(iVar10 != -3) & iVar10 + 4U;
          iStack_8 = CONCAT31(iStack_8._1_3_,0xd);
          FUN_006c7e10(&uStack_34,puVar3 + 2,puVar3,0);
          iVar6 = (int)uStack_30;
          for (puVar3 = (undefined4 *)*puVar3; uStack_30._0_4_ = iVar6, puVar3 != (undefined4 *)0x0;
              puVar3 = (undefined4 *)*puVar3) {
            puVar9 = puVar3 + 2;
            iStack_24 = FUN_00a33fd0(puVar9);
            FUN_0061ded0(&uStack_20,iStack_24,puVar9);
            if (uStack_20 == 0) {
              FUN_006c7ae0(puVar9);
              if (*(uint *)(iVar10 + 0x10) < *(int *)(iVar10 + 8) + 1U) {
                iVar6 = 0;
                for (puVar9 = puVar3; puVar9 != (undefined4 *)0x0; puVar9 = (undefined4 *)*puVar9) {
                  iVar6 = iVar6 + 1;
                }
                FUN_0062b610(*(int *)(iVar10 + 8) + iVar6);
              }
              FUN_005c5550(&iStack_24,&uStack_34,iStack_24);
            }
            uVar8 = uStack_1c;
            iVar6 = (int)uStack_30;
          }
          uVar12 = CONCAT44(uStack_30._4_4_,iVar6);
          iStack_8._1_3_ = (uint3)((uint)iStack_8 >> 8);
          iStack_8._0_1_ = 0;
          if (iVar6 != 0) {
            uStack_30._5_1_ = (char)(uStack_30._4_4_ >> 8);
            bVar11 = uStack_30._5_1_ != '\0';
            if (bVar11) {
              FUN_0056cd30();
            }
            FUN_01674ea0(iVar6,0xc);
            uVar12 = CONCAT44(uStack_30._4_4_,(int)uStack_30);
          }
        }
        puVar3 = puStack_18;
        if (*(int *)(uVar8 + 8) != 0) {
          iStack_24 = *(int *)(uVar8 + 0x14);
          iVar10 = *(int *)(uVar8 + 4);
          puVar3 = *(undefined4 **)(iStack_24 + iVar10 * 4);
          uStack_30 = uVar12;
          do {
            *(undefined4 *)(iStack_24 + iVar10 * 4) = *puVar3;
            FUN_0056cd30();
            FUN_01674ea0(puVar3,0xc);
            *(int *)(uVar8 + 8) = *(int *)(uVar8 + 8) + -1;
            puVar3 = *(undefined4 **)(iStack_24 + iVar10 * 4);
          } while (puVar3 != (undefined4 *)0x0);
          puVar7 = *(undefined4 **)(uVar8 + 0x14);
          puVar9 = puVar7 + *(int *)(uVar8 + 4);
          for (; puVar3 = puStack_18, iVar10 = iStack_28, uVar12 = uStack_30, puVar7 != puVar9;
              puVar7 = puVar7 + 1) {
            *puVar7 = 0;
          }
        }
      }
      uStack_30 = uVar12;
      uVar8 = uVar8 + 0x18;
      uStack_1c = uVar8;
      uVar1 = (undefined)iStack_8;
      uVar12 = uStack_30;
    } while ((undefined4 *)uVar8 != puVar3);
  }
  iStack_8._0_1_ = uVar1;
  iVar6 = iStack_14;
  uVar8 = *(uint *)(iStack_14 + 0xa0);
  iVar10 = *param_4;
  if ((uint)(param_4[2] - iVar10 >> 2) < uVar8) {
    if (0x3fffffff < uVar8) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    FUN_006c8e30(uVar8);
    iVar10 = *param_4;
    uVar8 = *(uint *)(iVar6 + 0xa0);
  }
  if (uVar8 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = *(undefined4 *)(*(int *)(iVar6 + 0xac) + *(int *)(iVar6 + 0x9c) * 4);
  }
  param_4 = (int *)((uint)param_4 & 0xffffff00);
  FUN_006c6bf0(iVar10,uVar4,0,param_4);
  FUN_006cd0e0(param_2,param_3,auStack_50,param_5);
  FUN_0061ac80();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9092 ; VA 0x006ca5f0 ; FUN_006ca5f0 */

void __thiscall
FUN_006ca5f0(int param_1,uint param_2,uint param_3,int *param_4,int *param_5,undefined4 param_6,
            undefined4 param_7)

{
  char cVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  uint auStack_7c [2];
  int *piStack_74;
  uint uStack_70;
  undefined4 uStack_6c;
  int iStack_68;
  int *piStack_5c;
  uint uStack_58;
  undefined4 uStack_54;
  int iStack_50;
  int *piStack_4c;
  uint uStack_48;
  undefined4 uStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  uint uStack_28;
  int iStack_24;
  uint uStack_20;
  int iStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017a81b0;
  pvStack_10 = ExceptionList;
  uStack_20 = *(uint *)(param_3 + 0x10);
  if (0 < (int)uStack_20) {
    iStack_3c = 0;
    uStack_28 = uStack_20;
    if ((int)*(uint *)(param_1 + 0xd0) <= (int)uStack_20) {
      uStack_28 = *(uint *)(param_1 + 0xd0);
    }
    iStack_30 = (int)uStack_20 / (int)uStack_28 + 1;
    if ((int)uStack_20 % (int)uStack_28 < 1) {
      iStack_30 = (int)uStack_20 / (int)uStack_28;
    }
    iStack_38 = 0;
    iStack_34 = 0;
    uStack_8 = 0;
    uStack_7 = 0;
    ExceptionList = &pvStack_10;
    iStack_2c = param_1;
    if ((uint)((*(int *)(param_1 + 200) - *(int *)(param_1 + 0xc4)) / 0x18) < uStack_28) {
      ExceptionList = &pvStack_10;
      FUN_006c6fe0(uStack_28,(int *)(param_1 + 0xc4));
    }
    iStack_1c = 0;
    iVar6 = 0;
    uStack_18 = 0;
    uStack_14 = 0;
    iVar4 = iStack_38;
    if (0 < (int)uStack_20) {
      do {
        iVar7 = iVar6 + 1;
        if (*(int *)(*(int *)(param_3 + 4) + uStack_18 * 8) == 0) {
          iVar7 = iVar6;
        }
        if ((iVar7 == iStack_30) ||
           (uStack_18 == (*(int *)(param_3 + 8) - *(int *)(param_3 + 4) >> 3) - 1U)) {
          uStack_28 = (uint)DAT_01d6520c * 1000;
          iStack_24 = param_3;
          if (iStack_34 == iVar4) {
            FUN_006c6450(iVar4,param_2,&uStack_28,&iStack_24,&iStack_1c,&uStack_18);
          }
          else {
            FUN_006c7830(&iStack_3c);
            iStack_38 = iStack_38 + 0x60;
          }
          uStack_14 = uStack_14 + iVar7;
          iVar7 = 0;
          iStack_1c = uStack_18 + 1;
          iVar4 = iStack_38;
          if (((*(int *)(param_3 + 8) - *(int *)(param_3 + 4) >> 3) - 1U < uStack_18 + 1) ||
             (uStack_14 == uStack_20)) break;
        }
        uStack_28 = uStack_18 + 1;
        iVar6 = iVar7;
        uStack_18 = uStack_28;
      } while ((int)uStack_14 < (int)uStack_20);
    }
    if ((DAT_01d5b710 != '\0') &&
       (param_3 = 0, iVar6 = iVar4 - iStack_3c >> 0x1f, (iVar4 - iStack_3c) / 0x60 + iVar6 != iVar6)
       ) {
      do {
        if ((param_4[1] == 0) || (*(int *)(*(int *)(*param_4 + 4) + 0x44) == 0)) break;
        FUN_006c8f90(param_4,*(int *)(*param_4 + 4));
        param_3 = param_3 + 1;
        param_5[3] = param_5[3] + -1;
        iVar4 = iStack_38;
      } while (param_3 < (uint)((iStack_38 - iStack_3c) / 0x60));
    }
    iVar6 = iVar4 - iStack_3c >> 0x1f;
    if ((iVar4 - iStack_3c) / 0x60 + iVar6 != iVar6) {
      piStack_4c = &iStack_3c;
      uVar5 = 0;
      uStack_44 = param_7;
      iStack_40 = iStack_2c;
      do {
        piStack_5c = piStack_4c;
        uStack_54 = uStack_44;
        iStack_50 = iStack_40;
        uStack_58 = uVar5;
        uStack_48 = uVar5;
        cVar1 = FUN_00585a40(&piStack_5c);
        if (cVar1 == '\0') {
          piStack_74 = piStack_5c;
          uStack_70 = uStack_58;
          uStack_6c = uStack_54;
          iStack_68 = iStack_50;
          auStack_7c[0] = 0x18de3c9;
        }
        else {
          auStack_7c[0] = 0;
        }
        uStack_8 = 1;
        FUN_006c74e0(auStack_7c,&piStack_5c);
        uStack_8 = 2;
        if (((auStack_7c[0] != 0) && ((auStack_7c[0] & 1) == 0)) &&
           (*(code **)(auStack_7c[0] & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(auStack_7c[0] & 0xfffffffe))(&piStack_74,&piStack_74,2);
        }
        uVar5 = uVar5 + 1;
        uStack_8 = 0;
      } while (uVar5 < (uint)((iStack_38 - iStack_3c) / 0x60));
    }
    FUN_0153a600(1);
    param_2 = 0;
    iVar4 = iStack_38 - iStack_3c >> 0x1f;
    if ((iStack_38 - iStack_3c) / 0x60 + iVar4 != iVar4) {
      param_3 = 0;
      do {
        iVar4 = iStack_3c + param_3;
        *param_5 = *param_5 + *(int *)(iVar4 + 0x3c);
        param_5[1] = param_5[1] + *(int *)(iVar4 + 0x40);
        param_5[2] = param_5[2] + *(int *)(iVar4 + 0x44);
        param_5[3] = param_5[3] + *(int *)(iVar4 + 0xc);
        if (DAT_01ee4215 != '\0') {
          FUN_01677520(DAT_01ee4215,
                       "ReplicationDataCache::generateDataBlobsHelper : %u Instances packed in %lu blobs"
                       ,*(undefined4 *)(iVar4 + 0x3c),*(undefined4 *)(iVar4 + 0xc));
        }
        piVar3 = (int *)(param_3 + 8 + iStack_3c);
        if ((param_4 != piVar3) && (piVar3[1] != 0)) {
          FUN_006c8e80(*param_4,piVar3,*(undefined4 *)*piVar3,(undefined4 *)*piVar3,piVar3[1]);
        }
        if (*(int *)(iStack_3c + 0x18 + param_3) == 0) {
          uVar2 = 0;
        }
        else {
          uVar2 = *(undefined4 *)
                   (*(int *)(iStack_3c + 0x24 + param_3) + *(int *)(iStack_3c + 0x14 + param_3) * 4)
          ;
        }
        FUN_006c7ca0(uVar2,0);
        param_2 = param_2 + 1;
        param_3 = param_3 + 0x60;
      } while (param_2 < (uint)((iStack_38 - iStack_3c) / 0x60));
    }
    FUN_006c8970();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9093 ; VA 0x006ca9c0 ; FUN_006ca9c0 */

void __thiscall
FUN_006ca9c0(uint param_1,uint param_2,int *param_3,int *param_4,int *param_5,undefined4 param_6,
            int param_7)

{
  undefined4 *puVar1;
  char cVar2;
  int *piVar3;
  undefined4 uVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  undefined4 *puVar8;
  uint auStack_a0 [2];
  int *piStack_98;
  uint uStack_94;
  int *piStack_90;
  int iStack_8c;
  uint uStack_88;
  int *piStack_80;
  uint uStack_7c;
  int *piStack_78;
  int iStack_74;
  int iStack_70;
  int *piStack_6c;
  uint uStack_68;
  int *piStack_64;
  int iStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined4 *puStack_54;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  int *piStack_40;
  undefined4 uStack_3c;
  undefined4 *puStack_38;
  undefined4 *puStack_34;
  int *piStack_30;
  int iStack_2c;
  uint uStack_28;
  uint uStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a81db;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uVar6 = 0;
  piVar5 = (int *)*param_3;
  uStack_14 = (param_3[1] - (int)piVar5) / 0x1c;
  if (uStack_14 != 0) {
    piVar3 = piVar5;
    do {
      if (*piVar3 != param_3[4]) break;
      uVar6 = uVar6 + 1;
      piVar3 = piVar3 + 7;
    } while (uVar6 < uStack_14);
  }
LAB_006caa33:
  if (uVar6 != uStack_14) {
    piVar3 = piVar5 + uVar6 * 7;
    uStack_28 = uStack_28 + piVar3[3];
    do {
      piVar3 = piVar3 + 7;
      uVar6 = uVar6 + 1;
      if ((uint)((param_3[1] - *param_3) / 0x1c) <= uVar6) break;
    } while (*piVar3 == param_3[4]);
    goto LAB_006caa33;
  }
  if (uStack_28 != 0) {
    iStack_20 = 0;
    iStack_1c = 0;
    iStack_18 = 0;
    uVar6 = *(uint *)(param_1 + 0xd0);
    if (uStack_28 < *(uint *)(param_1 + 0xd0)) {
      uVar6 = uStack_28;
    }
    uStack_24 = uStack_28 / uVar6 + 1;
    if (uStack_28 % uVar6 == 0) {
      uStack_24 = uStack_28 / uVar6;
    }
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    uStack_4c = param_1;
    if ((uint)((*(int *)(param_1 + 200) - *(int *)(param_1 + 0xc4)) / 0x18) < uVar6) {
      ExceptionList = &pvStack_10;
      FUN_006c6fe0(uVar6,(int *)(param_1 + 0xc4));
    }
    puVar8 = (undefined4 *)0x0;
    uStack_14 = 0;
    uStack_3c = 0;
    puStack_38 = (undefined4 *)0x0;
    puStack_34 = (undefined4 *)0x0;
    uStack_8._0_1_ = 1;
    uStack_48 = 0;
    piStack_30 = (int *)*param_3;
    uStack_28 = (param_3[1] - (int)piStack_30) / 0x1c;
    if (uStack_28 != 0) {
      uStack_48 = 0;
      piVar5 = piStack_30;
      do {
        if (*piVar5 != param_3[4]) break;
        uStack_48 = uStack_48 + 1;
        piVar5 = piVar5 + 7;
      } while (uStack_48 < uStack_28);
    }
LAB_006cab56:
    if (uStack_48 != uStack_28) {
      piStack_30 = (int *)(uStack_48 * 0x1c);
      iStack_2c = 0;
      puStack_54 = (undefined4 *)(*param_3 + (int)piStack_30);
      piStack_40 = (int *)*puStack_54;
      uVar6 = puStack_54[3] + uStack_14;
      if (uStack_24 < puStack_54[3] + uStack_14) {
        uStack_50 = puStack_54[2];
        uStack_44 = 0;
        uVar6 = uStack_14;
        if (uStack_50 != 0) {
          do {
            if (puStack_54[3] == 0) {
LAB_006cabeb:
              iVar7 = 0;
            }
            else {
              puVar1 = *(undefined4 **)(puStack_54[6] + uStack_44 * 4);
              if (puVar1 == (undefined4 *)0x0) {
                piVar5 = (int *)0x0;
              }
              else {
                piVar5 = (int *)*puVar1;
              }
              if (piVar5 == (int *)0x0) goto LAB_006cabeb;
              iVar7 = 0;
              uStack_58 = puStack_54[2];
              do {
                puVar8 = puStack_38;
                if ((uint)piVar5[1] % uStack_58 != uStack_44) break;
                piVar5 = (int *)*piVar5;
                iVar7 = iVar7 + 1;
              } while (piVar5 != (int *)0x0);
            }
            uStack_14 = uStack_14 + iVar7;
            if (uStack_24 <= uStack_14) {
              piStack_64 = piStack_40;
              iStack_60 = iStack_2c;
              uStack_5c = uStack_44;
              if (puStack_34 == puVar8) {
                FUN_006c6920(puVar8,&piStack_64);
              }
              else {
                *puVar8 = piStack_40;
                puVar8[1] = iStack_2c;
                puVar8[2] = uStack_44;
                puStack_38 = puVar8 + 3;
              }
              iStack_2c = (uint)DAT_01d6520c * 1000;
              if (iStack_18 == iStack_1c) {
                FUN_006c65c0(iStack_1c,param_2,&iStack_2c,&uStack_3c);
              }
              else {
                FUN_006c7970(&iStack_20);
                iStack_1c = iStack_1c + 0x60;
              }
              uStack_14 = 0;
              iStack_2c = uStack_44 + 1;
              puVar8 = puStack_38;
            }
            uStack_44 = uStack_44 + 1;
            uVar6 = uStack_14;
          } while (uStack_44 < uStack_50);
        }
      }
      uStack_14 = uVar6;
      if (uStack_14 != 0) {
        iStack_70 = puStack_54[2] + -1;
        piStack_78 = piStack_40;
        iStack_74 = iStack_2c;
        if (puStack_34 == puVar8) {
          FUN_006c6920(puVar8,&piStack_78);
          puVar8 = puStack_38;
        }
        else {
          *puVar8 = piStack_40;
          puVar8[1] = iStack_2c;
          puVar8[2] = iStack_70;
          puStack_38 = puVar8 + 3;
          puVar8 = puStack_38;
        }
      }
      if (uStack_24 <= uStack_14) {
        piStack_40 = (int *)((uint)DAT_01d6520c * 1000);
        if (iStack_18 == iStack_1c) {
          FUN_006c65c0(iStack_1c,param_2,&piStack_40,&uStack_3c);
        }
        else {
          FUN_006c7970(&iStack_20,iStack_1c,param_2,&piStack_40,&uStack_3c);
          iStack_1c = iStack_1c + 0x60;
        }
        uStack_14 = 0;
        puVar8 = puStack_38;
      }
      uStack_50 = (param_3[1] - *param_3) / 0x1c;
      piVar5 = (int *)((int)piStack_30 + *param_3);
      do {
        piVar5 = piVar5 + 7;
        uStack_48 = uStack_48 + 1;
        if (uStack_50 <= uStack_48) break;
      } while (*piVar5 == param_3[4]);
      goto LAB_006cab56;
    }
    if (uStack_14 != 0) {
      piStack_30 = (int *)((uint)DAT_01d6520c * 1000);
      if (iStack_18 == iStack_1c) {
        FUN_006c65c0(iStack_1c,param_2,&piStack_30,&uStack_3c);
      }
      else {
        FUN_006c7970(&iStack_20,iStack_1c,param_2,&piStack_30,&uStack_3c);
        iStack_1c = iStack_1c + 0x60;
      }
    }
    if ((DAT_01d5b710 != '\0') &&
       (param_2 = 0, iVar7 = iStack_1c - iStack_20 >> 0x1f,
       (iStack_1c - iStack_20) / 0x60 + iVar7 != iVar7)) {
      uStack_24 = 0;
      do {
        if ((param_4[1] == 0) || (*(int *)(*(int *)(*param_4 + 4) + 0x44) == 0)) break;
        FUN_006c8f90(param_4,*(int *)(*param_4 + 4));
        param_2 = param_2 + 1;
        uStack_24 = uStack_24 + 0x60;
        param_5[3] = param_5[3] + -1;
      } while (param_2 < (uint)((iStack_1c - iStack_20) / 0x60));
    }
    uVar6 = 0;
    iVar7 = iStack_1c - iStack_20 >> 0x1f;
    if ((iStack_1c - iStack_20) / 0x60 + iVar7 != iVar7) {
      do {
        piStack_80 = &iStack_20;
        piStack_78 = param_3;
        iStack_74 = param_7;
        uStack_5c = uStack_4c;
        piStack_64 = param_3;
        iStack_60 = param_7;
        uStack_7c = uVar6;
        piStack_6c = piStack_80;
        uStack_68 = uVar6;
        cVar2 = FUN_00585a40(&piStack_6c);
        if (cVar2 == '\0') {
          uStack_88 = uStack_5c;
          piStack_98 = piStack_6c;
          uStack_94 = uStack_68;
          piStack_90 = piStack_64;
          iStack_8c = iStack_60;
          auStack_a0[0] = 0x18de3d1;
        }
        else {
          auStack_a0[0] = 0;
        }
        uStack_8._0_1_ = 2;
        FUN_006c74e0(auStack_a0,&piStack_80);
        uStack_8._0_1_ = 3;
        if (((auStack_a0[0] != 0) && ((auStack_a0[0] & 1) == 0)) &&
           (*(code **)(auStack_a0[0] & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(auStack_a0[0] & 0xfffffffe))(&piStack_98,&piStack_98,2);
        }
        uVar6 = uVar6 + 1;
        uStack_8._0_1_ = 1;
      } while (uVar6 < (uint)((iStack_1c - iStack_20) / 0x60));
    }
    FUN_0153a600(1);
    param_2 = 0;
    iVar7 = iStack_1c - iStack_20 >> 0x1f;
    if ((iStack_1c - iStack_20) / 0x60 + iVar7 != iVar7) {
      param_3 = (int *)0x0;
      do {
        iVar7 = (int)param_3 + iStack_20;
        *param_5 = *param_5 + *(int *)(iVar7 + 0x3c);
        param_5[1] = param_5[1] + *(int *)(iVar7 + 0x40);
        param_5[2] = param_5[2] + *(int *)(iVar7 + 0x44);
        param_5[3] = param_5[3] + *(int *)(iVar7 + 0xc);
        if (DAT_01ee4215 != '\0') {
          FUN_01677520(DAT_01ee4215,
                       "ReplicationDataCache::generateDataBlobsHelper : %u Instances packed in %lu blobs"
                       ,*(undefined4 *)(iVar7 + 0x3c),*(undefined4 *)(iVar7 + 0xc));
        }
        piVar5 = (int *)((int)param_3 + 8 + iStack_20);
        if ((param_4 != piVar5) && (piVar5[1] != 0)) {
          FUN_006c8e80(*param_4,piVar5,*(undefined4 *)*piVar5,(undefined4 *)*piVar5,piVar5[1]);
        }
        if (*(int *)((int)param_3 + 0x18 + iStack_20) == 0) {
          uVar4 = 0;
        }
        else {
          uVar4 = *(undefined4 *)
                   (*(int *)((int)param_3 + 0x24 + iStack_20) +
                   *(int *)((int)param_3 + 0x14 + iStack_20) * 4);
        }
        FUN_006c7ca0(uVar4,0);
        param_2 = param_2 + 1;
        param_3 = (int *)((int)param_3 + 0x60);
      } while (param_2 < (uint)((iStack_1c - iStack_20) / 0x60));
    }
    FUN_00617ad0();
    FUN_006c8970();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9094 ; VA 0x006cb060 ; FUN_006cb060 */

int __fastcall FUN_006cb060(int param_1)

{
  return param_1 + 0x88;
}



/* FUNCTION 9095 ; VA 0x006cb070 ; FUN_006cb070 */

int __fastcall FUN_006cb070(int param_1)

{
  return param_1 + 0x90;
}



/* FUNCTION 9096 ; VA 0x006cb080 ; FUN_006cb080 */

void __thiscall FUN_006cb080(uint *param_1,uint param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint *puVar4;
  uint uVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  for (uVar5 = *param_1; uVar5 < param_2; uVar5 = uVar5 * 3 >> 1) {
  }
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_01674f30(uVar5 << 5);
  if (param_1[2] != 0) {
    uVar6 = 0;
    puVar3 = puVar2;
    do {
      puVar4 = (uint *)(((param_1[1] + uVar6) % *param_1) * 0x20 + param_1[3]);
      *puVar3 = 0;
      FUN_005880d0(puVar4);
      uVar1 = *puVar4;
      uStack_8 = 0;
      if (uVar1 != 0) {
        if ((uVar1 & 1) == 0) {
          if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
            (**(code **)(uVar1 & 0xfffffffe))(puVar4 + 2,puVar4 + 2,2);
          }
        }
        *puVar4 = 0;
      }
      uVar6 = uVar6 + 1;
      puVar3 = puVar3 + 8;
      uStack_8 = 0xffffffff;
    } while (uVar6 < param_1[2]);
  }
  FUN_01674ea0(param_1[3]);
  *param_1 = uVar5;
  param_1[1] = 0;
  param_1[3] = (uint)puVar2;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9097 ; VA 0x006cb170 ; FUN_006cb170 */

void __thiscall FUN_006cb170(int param_1,int param_2,undefined2 param_3)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  int iVar10;
  int aiStack_34 [5];
  uint uStack_20;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795d48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (DAT_01ee4215 != '\0') {
    ExceptionList = &pvStack_10;
    puVar4 = (undefined4 *)FUN_008a2380(aiStack_34);
    uStack_8 = 0;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    FUN_01677520(DAT_01ee4215,"inserting from ReplicationDataPreBlob: %p, instance name: %s",param_2
                 ,puVar4);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_20) {
      uVar7 = uStack_20 + 1;
      iVar5 = aiStack_34[0];
      if (0xfff < uVar7) {
        iVar5 = *(int *)(aiStack_34[0] + -4);
        uVar7 = uStack_20 + 0x24;
        if (0x1f < (aiStack_34[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar7);
    }
  }
  piVar8 = (int *)(param_1 + 4);
  piStack_18 = piVar8;
  if (*(int *)(param_1 + 4) != *(int *)(param_1 + 8)) {
    uVar9 = *(int *)(param_1 + 8) - *(int *)(param_1 + 4) >> 3;
    uVar7 = *(uint *)(iStack_14 + 0x10);
    if (uVar7 <= uVar9 >> 1) {
      iVar10 = uVar9 - 1;
      iVar5 = 0;
      if (0 < iVar10) {
        do {
          if (iVar5 < (int)uVar7) {
            piVar6 = (int *)(*piVar8 + iVar5 * 8);
            do {
              if (*piVar6 == 0) break;
              iVar5 = iVar5 + 1;
              piVar6 = piVar6 + 2;
            } while (iVar5 < (int)uVar7);
          }
          if ((int)uVar7 < iVar10) {
            piVar6 = (int *)(*piVar8 + iVar10 * 8);
            do {
              if (*piVar6 != 0) break;
              iVar10 = iVar10 + -1;
              piVar6 = piVar6 + -2;
            } while ((int)uVar7 < iVar10);
          }
          if (iVar10 <= iVar5) break;
          *(int *)(*(int *)(*piVar8 + iVar10 * 8) + 0x28) = iVar5;
          iVar2 = *piVar8;
          iVar1 = iVar10 * 8;
          uVar3 = *(undefined4 *)(iVar2 + 4 + iVar10 * 8);
          iVar10 = iVar10 + -1;
          *(undefined4 *)(iVar2 + iVar5 * 8) = *(undefined4 *)(iVar2 + iVar1);
          *(undefined4 *)(iVar2 + 4 + iVar5 * 8) = uVar3;
          iVar5 = iVar5 + 1;
          uVar7 = *(uint *)(iStack_14 + 0x10);
        } while (iVar5 < iVar10);
      }
      FUN_006c6ee0(uVar7,piVar8);
    }
  }
  piVar6 = *(int **)(param_1 + 8);
  iStack_1c = param_2;
  piStack_18 = (int *)CONCAT22(piStack_18._2_2_,param_3);
  if (*(int **)(param_1 + 0xc) == piVar6) {
    FUN_006c6ad0(piVar6,&iStack_1c);
  }
  else {
    *piVar6 = param_2;
    piVar6[1] = (int)piStack_18;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 8;
  }
  *(int *)(param_2 + 0x24) = iStack_14;
  *(int *)(param_2 + 0x28) = (*(int *)(param_1 + 8) - *piVar8 >> 3) + -1;
  *(int *)(iStack_14 + 0x10) = *(int *)(iStack_14 + 0x10) + 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9098 ; VA 0x006cb310 ; FUN_006cb310 */

uint * __thiscall FUN_006cb310(int *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  
  uVar2 = *param_2;
  uVar4 = (param_1[1] - *param_1) / 0x1c - 1;
  uVar3 = (uVar2 >> 3) + uVar2;
  uVar5 = 0;
  while( true ) {
    uVar3 = uVar3 & uVar4;
    puVar1 = (uint *)(*param_1 + uVar3 * 0x1c);
    if (*puVar1 == param_1[4]) {
      *puVar1 = uVar2;
      param_1[3] = param_1[3] + 1;
      return puVar1;
    }
    if (*puVar1 == uVar2) break;
    uVar3 = uVar3 + 1 + uVar5;
    uVar5 = uVar5 + 1;
    if (uVar4 < uVar5) {
      return (uint *)0x0;
    }
  }
  return puVar1;
}



/* FUNCTION 9099 ; VA 0x006cb3a0 ; FUN_006cb3a0 */

void __thiscall FUN_006cb3a0(int param_1,int *param_2,char param_3)

{
  int *piVar1;
  undefined2 *puVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  undefined4 uStack_10;
  uint uStack_c;
  int iStack_8;
  
  if (DAT_01ee4215 != '\0') {
    FUN_016774b0(DAT_01ee4215,
                 "ReplicationDataCache::invalidateBlob_deprecated(blob) : marking blob invalid",0);
  }
  iVar3 = param_2[0x11];
  iVar4 = param_2[0x10];
  iStack_8 = iVar3;
  if (iVar4 != iVar3) {
    piVar5 = (int *)(iVar4 + 8);
    do {
      if (*piVar5 != 0) {
        param_2[1] = param_2[1] - piVar5[-1];
        piVar5[-1] = 0;
        param_2[3] = param_2[3] + -1;
        *(undefined4 *)(*piVar5 + 0x20) = 0;
        uStack_c = (uint)*(ushort *)(piVar5 + 3);
        uStack_10 = *(undefined4 *)(*(int *)(*piVar5 + 4) + 0xc);
        if (param_3 == '\0') {
          if ((uint)(((*(int *)(param_1 + 8) - *(int *)(param_1 + 4)) / 0x1c) * 3) >> 2 <=
              *(uint *)(param_1 + 0x10)) {
            FUN_006cc5b0();
          }
        }
        else if ((uint)(((*(int *)(param_1 + 0x20) - *(int *)(param_1 + 0x1c)) / 0x1c) * 3) >> 2 <=
                 *(uint *)(param_1 + 0x28)) {
          FUN_006cc5b0();
        }
        FUN_006cb310(&uStack_10);
        puVar2 = (undefined2 *)FUN_006c8b10(piVar5);
        *puVar2 = (short)uStack_c;
        iVar3 = iStack_8;
      }
      iVar4 = iVar4 + 0x18;
      piVar5 = piVar5 + 6;
    } while (iVar4 != iVar3);
  }
  if (param_3 == '\0') {
    piVar5 = (int *)**(int **)(param_1 + 0x88);
    if (piVar5 != *(int **)(param_1 + 0x88)) {
      do {
        piVar1 = (int *)*piVar5;
        if (piVar5 + 2 == param_2) {
          *(int **)piVar5[1] = piVar1;
          *(int *)(*piVar5 + 4) = piVar5[1];
          *(int *)(param_1 + 0x8c) = *(int *)(param_1 + 0x8c) + -1;
          (**(code **)(piVar5[2] + 0x14))(0);
          FUN_01674ea0(piVar5,0x60);
        }
        piVar5 = piVar1;
      } while (piVar1 != (int *)*(int *)(param_1 + 0x88));
    }
  }
  else {
    piVar5 = (int *)**(int **)(param_1 + 0x90);
    if (piVar5 != *(int **)(param_1 + 0x90)) {
      do {
        piVar1 = (int *)*piVar5;
        if (piVar5 + 2 == param_2) {
          *(int **)piVar5[1] = piVar1;
          *(int *)(*piVar5 + 4) = piVar5[1];
          *(int *)(param_1 + 0x94) = *(int *)(param_1 + 0x94) + -1;
          (**(code **)(piVar5[2] + 0x14))(0);
          FUN_01674ea0(piVar5,0x60);
        }
        piVar5 = piVar1;
      } while (piVar1 != (int *)*(int *)(param_1 + 0x90));
      return;
    }
  }
  return;
}



/* FUNCTION 9100 ; VA 0x006cb560 ; FUN_006cb560 */

void __fastcall FUN_006cb560(int *param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint *puVar4;
  char cVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  int *piVar9;
  byte *pbVar10;
  uint uVar11;
  int *piVar12;
  bool bVar13;
  int aiStack_5c [5];
  uint uStack_48;
  uint uStack_44;
  undefined4 *puStack_40;
  undefined2 uStack_3c;
  int *piStack_38;
  int iStack_34;
  undefined auStack_30 [4];
  int iStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  uint *puStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8210;
  pvStack_10 = ExceptionList;
  piStack_38 = (int *)0x0;
  iStack_34 = 0;
  ExceptionList = &pvStack_10;
  piStack_20 = param_1;
  piStack_38 = (int *)FUN_00575b50(0,0);
  puVar1 = (undefined4 *)param_1[0x24];
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  puVar2 = (undefined4 *)*puVar1;
  piStack_14 = piStack_38;
  do {
    piVar9 = piStack_14;
    iVar8 = iStack_34;
    if (puVar2 == puVar1) {
      while (piStack_14 = piVar9, iVar8 != 0) {
        piVar9 = *(int **)(*piVar9 + 8);
        if (DAT_01d5b720 == '\0') {
          FUN_006cb3a0(piVar9,1);
        }
        else {
          piStack_20 = piVar9;
          if (DAT_01ee4215 != '\0') {
            FUN_01677520(DAT_01ee4215,"Invalidating blob(%p) from %s",piVar9,"part cache");
          }
          cVar5 = (**(code **)(*piStack_20 + 4))();
          if (cVar5 == '\0') {
            (**(code **)(*piStack_20 + 0xc))(param_1 + 0x18);
          }
          piVar9 = *(int **)param_1[0x24];
          if (piVar9 != (int *)param_1[0x24]) {
            do {
              if (piVar9 + 2 == piStack_20) {
                piVar12 = (int *)*piVar9;
                *(int **)piVar9[1] = piVar12;
                *(int *)(*piVar9 + 4) = piVar9[1];
                param_1[0x25] = param_1[0x25] + -1;
                (**(code **)(piVar9[2] + 0x14))(0);
                FUN_01674ea0(piVar9,0x60);
              }
              else {
                piVar12 = (int *)*piVar9;
              }
              piVar9 = piVar12;
              iVar8 = iStack_34;
            } while (piVar12 != (int *)param_1[0x24]);
          }
        }
        piVar9 = (int *)*piStack_14;
        *(int *)piVar9[1] = *piVar9;
        *(int *)(*piVar9 + 4) = piVar9[1];
        iStack_34 = iVar8 + -1;
        FUN_01674ea0(piVar9,0xc);
        piVar9 = piStack_14;
        iVar8 = iVar8 + -1;
      }
      piVar12 = (int *)*piVar9;
      *piVar9 = (int)piVar9;
      piVar9[1] = (int)piVar9;
      while (piVar12 != piVar9) {
        piVar3 = (int *)*piVar12;
        FUN_01674ea0(piVar12,0xc);
        piVar12 = piVar3;
      }
      FUN_01674ea0(piVar9,0xc);
      ExceptionList = pvStack_10;
      return;
    }
    piStack_24 = (int *)puVar2[0x13];
    piStack_18 = (int *)puVar2[0x12];
    iVar8 = (int)piStack_24 - (int)piStack_18 >> 0x1f;
    if (((int)piStack_24 - (int)piStack_18) / 0x18 + iVar8 != iVar8) {
      if (piStack_18 != piStack_24) {
        do {
          puStack_1c = (uint *)(piStack_18 + 2);
          if (piStack_18[2] != 0) {
            piStack_28 = *(int **)(piStack_18[2] + 4);
            iVar8 = piStack_28[3];
            iVar6 = FUN_00aff8c0();
            puVar4 = puStack_1c;
            piVar9 = (int *)0x0;
            if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
                (uint)*(ushort *)(iVar6 + 0x1da)) {
              piVar9 = piStack_28;
            }
            if (DAT_01d6866c == '\0') {
              bVar13 = piVar9[0x1c] == 0;
            }
            else {
              bVar13 = piVar9[0x1b] == -1;
            }
            if ((!bVar13) || (param_1 = piStack_20, (*(byte *)(piVar9 + 0x2d) & 2) != 0)) {
              if (DAT_01ee4215 != '\0') {
                puVar7 = (undefined4 *)FUN_008a2380(aiStack_5c);
                uStack_8._0_1_ = 1;
                if (0xf < (uint)puVar7[5]) {
                  puVar7 = (undefined4 *)*puVar7;
                }
                FUN_016774b0(DAT_01ee4215,
                             "Invalidating cache for partInstance %s, as its not sleeping",puVar7);
                uStack_8._0_1_ = 0;
                if (0xf < uStack_48) {
                  uVar11 = uStack_48 + 1;
                  iVar8 = aiStack_5c[0];
                  if (0xfff < uVar11) {
                    iVar8 = *(int *)(aiStack_5c[0] + -4);
                    uVar11 = uStack_48 + 0x24;
                    if (0x1f < (aiStack_5c[0] - iVar8) - 4U) goto LAB_006cbb14;
                  }
                  FUN_01674ea0(iVar8,uVar11);
                }
              }
              if (DAT_01d5b720 == '\0') {
                puStack_1c = (uint *)(piStack_20 + 7);
                piStack_28 = *(int **)(*(int *)(*puVar4 + 4) + 0xc);
                if ((uint)(((int)(piStack_20[8] - *puStack_1c) / 0x1c) * 3) >> 2 <=
                    (uint)piStack_20[10]) {
                  FUN_006cc5b0();
                }
                iVar8 = FUN_006cb310(&piStack_28);
                piStack_28 = (int *)((*puVar4 >> 3) + *puVar4);
                puStack_1c = (uint *)(iVar8 + 4);
                pbVar10 = (byte *)((int)puStack_1c + *(byte *)puStack_1c + 1);
                FUN_00606ea0(&iStack_2c,piStack_28,puVar4,
                             -(uint)(pbVar10 != (byte *)0x0) & (uint)(pbVar10 + 1));
                if (iStack_2c == 0) {
                  puStack_40 = (undefined4 *)0x0;
                  uStack_44 = -(uint)(puStack_1c != (uint *)0xfffffffd) & (uint)(puStack_1c + 1);
                  uStack_8._0_1_ = 2;
                  uStack_3c = 0;
                  puStack_40 = (undefined4 *)FUN_01674e20(0x10);
                  uStack_3c = 0x101;
                  *puStack_40 = 0;
                  puStack_40[1] = 0;
                  *(undefined8 *)(puStack_40 + 2) = 0;
                  puStack_40[2] = *puVar4;
                  *(undefined2 *)(puStack_40 + 3) = *(undefined2 *)(piStack_18 + 5);
                  FUN_0062b610(puStack_1c[2] + 1);
                  FUN_005c5550(auStack_30,&uStack_44,piStack_28);
                  uStack_8._0_1_ = 0;
                  if (puStack_40 != (undefined4 *)0x0) {
                    FUN_01674ea0(puStack_40,0x10);
                  }
                  if (DAT_01ee4215 != '\0') {
                    piStack_28 = (int *)*puVar4;
                    puVar7 = (undefined4 *)FUN_008a2380(aiStack_5c);
                    uStack_8._0_1_ = 3;
                    if (0xf < (uint)puVar7[5]) {
                      puVar7 = (undefined4 *)*puVar7;
                    }
                    FUN_01677490(DAT_01ee4215,
                                 "ReplicationDataCache::addToCachePendingList(mrd) : inserting instance %s [ mrd = %p] to noBlobPartMRDMap"
                                 ,puVar7,piStack_28,0);
                    uStack_8._0_1_ = 0;
                    if (0xf < uStack_48) {
                      uVar11 = uStack_48 + 1;
                      iVar8 = aiStack_5c[0];
                      if (0xfff < uVar11) {
                        iVar8 = *(int *)(aiStack_5c[0] + -4);
                        uVar11 = uStack_48 + 0x24;
                        if (0x1f < (aiStack_5c[0] - iVar8) - 4U) {
LAB_006cbb14:
                          uStack_8._0_1_ = 0;
                    /* WARNING: Subroutine does not return */
                          FUN_017167a3();
                        }
                      }
                      FUN_01674ea0(iVar8,uVar11);
                    }
                  }
                }
              }
              param_1 = piStack_20;
              piStack_28 = (int *)*puVar4;
              FUN_006cbc40(piStack_28,0);
              if (DAT_01d5b720 != '\0') {
                FUN_006cb170(piStack_28,*(undefined2 *)(piStack_18 + 5));
              }
            }
          }
          piStack_18 = piStack_18 + 6;
        } while (piStack_18 != piStack_24);
      }
      if (DAT_01d5b720 == '\0') {
LAB_006cb8ed:
        piStack_28 = (int *)((uint)(puVar2[4] * DAT_01d5b6c4) / 100);
        if (DAT_01d5b230 == '\0') {
          bVar13 = false;
        }
        else {
          bVar13 = (uint)(((longlong)((int)(puVar2[0x13] - puVar2[0x12]) / 0x18) *
                           (longlong)DAT_01d5b6cc & 0xffffffffU) / 100) <
                   (uint)((int)(puVar2[0x16] - puVar2[0x15]) >> 3);
        }
        if ((piStack_28 <= (int *)puVar2[3]) && (!bVar13)) goto LAB_006cb8ce;
      }
      else {
        cVar5 = (**(code **)(puVar2[2] + 8))();
        if (cVar5 == '\0') {
          if (DAT_01d5b720 != '\0') goto LAB_006cb8ce;
          goto LAB_006cb8ed;
        }
      }
      if (DAT_01ee4215 != '\0') {
        FUN_01677520(DAT_01ee4215,
                     "Invalidating whole Blob; totalUncompressedUsedBytess = %d, totalBytes = %d, useful bytes threshold = %d%%, total mrd count = %zu, invalid mrd count = %zu, invalid count threshold = %d"
                     ,puVar2[3],puVar2[4],DAT_01d5b6c4,(int)(puVar2[0x13] - puVar2[0x12]) / 0x18,
                     (int)(puVar2[0x16] - puVar2[0x15]) >> 3,DAT_01d5b6cc);
      }
      piStack_28 = puVar2 + 2;
      piStack_24 = (int *)piStack_14[1];
      iVar8 = FUN_00602bf0(piStack_14,piStack_24,&piStack_28);
      if (iStack_34 == 0x15555554) {
                    /* WARNING: Subroutine does not return */
        FUN_016ddcd9("list<T> too long");
      }
      iStack_34 = iStack_34 + 1;
      piStack_14[1] = iVar8;
      *piStack_24 = iVar8;
      piStack_14 = piStack_38;
    }
LAB_006cb8ce:
    puVar2 = (undefined4 *)*puVar2;
  } while( true );
}



/* FUNCTION 9101 ; VA 0x006cbb30 ; FUN_006cbb30 */

void __thiscall FUN_006cbb30(int param_1,int *param_2,char param_3)

{
  int *piVar1;
  char cVar2;
  char *pcVar3;
  int iVar4;
  int *piVar5;
  
  if (DAT_01ee4215 != '\0') {
    pcVar3 = "part cache";
    if (param_3 == '\0') {
      pcVar3 = "cacheable cache";
    }
    FUN_01677520(DAT_01ee4215,"Invalidating blob(%p) from %s",param_2,pcVar3);
  }
  cVar2 = (**(code **)(*param_2 + 4))();
  if (cVar2 == '\0') {
    iVar4 = 0x60;
    if (param_3 == '\0') {
      iVar4 = 0x4c;
    }
    (**(code **)(*param_2 + 0xc))(iVar4 + param_1);
  }
  if (param_3 == '\0') {
    piVar5 = (int *)**(int **)(param_1 + 0x88);
    if (piVar5 != *(int **)(param_1 + 0x88)) {
      do {
        piVar1 = (int *)*piVar5;
        if (piVar5 + 2 == param_2) {
          *(int **)piVar5[1] = piVar1;
          *(int *)(*piVar5 + 4) = piVar5[1];
          *(int *)(param_1 + 0x8c) = *(int *)(param_1 + 0x8c) + -1;
          (**(code **)(piVar5[2] + 0x14))(0);
          FUN_01674ea0(piVar5,0x60);
        }
        piVar5 = piVar1;
      } while (piVar1 != (int *)*(int *)(param_1 + 0x88));
    }
  }
  else {
    piVar5 = (int *)**(int **)(param_1 + 0x90);
    if (piVar5 != *(int **)(param_1 + 0x90)) {
      do {
        piVar1 = (int *)*piVar5;
        if (piVar5 + 2 == param_2) {
          *(int **)piVar5[1] = piVar1;
          *(int *)(*piVar5 + 4) = piVar5[1];
          *(int *)(param_1 + 0x94) = *(int *)(param_1 + 0x94) + -1;
          (**(code **)(piVar5[2] + 0x14))(0);
          FUN_01674ea0(piVar5,0x60);
        }
        piVar5 = piVar1;
      } while (piVar1 != (int *)*(int *)(param_1 + 0x90));
      return;
    }
  }
  return;
}



/* FUNCTION 9102 ; VA 0x006cbc40 ; FUN_006cbc40 */

void __thiscall FUN_006cbc40(undefined4 param_1,int param_2,char param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  char cVar5;
  undefined4 *puVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  if (DAT_01ee4215 != '\0') {
    ExceptionList = &pvStack_10;
    puVar6 = (undefined4 *)FUN_008a2380(auStack_2c);
    uStack_8 = 0;
    if (0xf < (uint)puVar6[5]) {
      puVar6 = (undefined4 *)*puVar6;
    }
    FUN_01677490(DAT_01ee4215,
                 "ReplicationDataCache::invalidateInstanceCache(mrd) : marking mrd(%p) blob invalid for %s"
                 ,param_2,puVar6,0);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_18) {
      uVar10 = uStack_18 + 1;
      uVar9 = auStack_2c[0];
      if (0xfff < uVar10) {
        uVar9 = *(uint *)(auStack_2c[0] - 4);
        uVar10 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar10);
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  }
  if (DAT_01d5b720 == '\0') {
    iVar2 = *(int *)(param_2 + 0x20);
    if (DAT_01d5b230 != '\0') {
      if (DAT_01ee4215 != '\0') {
        FUN_01677490(DAT_01ee4215,"Invalidating instance in blob %p  offset %u  length %u",iVar2,
                     *(undefined4 *)(*(int *)(iVar2 + 0x40) + *(int *)(param_2 + 0x28) * 0x18),
                     *(undefined4 *)(*(int *)(iVar2 + 0x40) + 4 + *(int *)(param_2 + 0x28) * 0x18));
      }
      puVar3 = *(undefined4 **)(iVar2 + 0x50);
      puVar6 = (undefined4 *)(*(int *)(iVar2 + 0x40) + *(int *)(param_2 + 0x28) * 0x18);
      if (*(undefined4 **)(iVar2 + 0x54) == puVar3) {
        FUN_006c62b0(puVar3,puVar6,puVar6 + 1);
      }
      else {
        uVar4 = puVar6[1];
        *puVar3 = *puVar6;
        puVar3[1] = uVar4;
        *(int *)(iVar2 + 0x50) = *(int *)(iVar2 + 0x50) + 8;
      }
    }
    *(undefined4 *)(param_2 + 0x20) = 0;
    *(int *)(iVar2 + 0xc) = *(int *)(iVar2 + 0xc) + -1;
    *(int *)(iVar2 + 4) =
         *(int *)(iVar2 + 4) -
         *(int *)(*(int *)(iVar2 + 0x40) + 4 + *(int *)(param_2 + 0x28) * 0x18);
    *(undefined4 *)(*(int *)(iVar2 + 0x40) + 8 + *(int *)(param_2 + 0x28) * 0x18) = 0;
    *(undefined4 *)(*(int *)(iVar2 + 0x40) + 4 + *(int *)(param_2 + 0x28) * 0x18) = 0;
    if (DAT_01d5bc10 != '\0') {
      if ((*(int *)(param_2 + 4) == 0) ||
         (iVar7 = *(int *)(*(int *)(param_2 + 4) + 0xc), iVar8 = FUN_00af0010(),
         (uint)*(ushort *)(iVar8 + 0x1da) <
         (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8))) {
        iVar7 = FUN_008aa870();
        iVar8 = thunk_FUN_00897b90();
        if (iVar8 == iVar7) {
          *(undefined *)(iVar2 + 0x11) = 0;
        }
      }
      else {
        *(undefined *)(iVar2 + 0x10) = 0;
      }
    }
    if ((param_3 != '\0') &&
       ((cVar5 = FUN_006cd690(iVar2), cVar5 != '\0' || (*(int *)(iVar2 + 0xc) == 0)))) {
      if (DAT_01ee4215 != '\0') {
        FUN_01677520(DAT_01ee4215,
                     "Invalidating Blob; totalUncompressedUsedBytes = %d, totalBytes = %d, useful bytes threshold = %d%%, total mrd count = %zu, invalid mrd count = %zu, invalid mrd count threshold = %d%%"
                     ,*(undefined4 *)(iVar2 + 4),*(undefined4 *)(iVar2 + 8),DAT_01d5b6c4,
                     (*(int *)(iVar2 + 0x44) - *(int *)(iVar2 + 0x40)) / 0x18,
                     *(int *)(iVar2 + 0x50) - *(int *)(iVar2 + 0x4c) >> 3,DAT_01d5b6cc);
      }
      iVar7 = *(int *)(*(int *)(param_2 + 4) + 0xc);
      iVar8 = FUN_00aff8c0();
      FUN_006cb3a0(iVar2,(uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8) <=
                         (uint)*(ushort *)(iVar8 + 0x1da));
    }
    ExceptionList = pvStack_10;
    return;
  }
  piVar1 = *(int **)(param_2 + 0x24);
  (**(code **)(*piVar1 + 0x10))(param_2);
  if (param_3 == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  cVar5 = (**(code **)(*piVar1 + 8))();
  if ((cVar5 == '\0') && (cVar5 = (**(code **)(*piVar1 + 4))(), cVar5 == '\0')) {
    ExceptionList = pvStack_10;
    return;
  }
  iVar2 = *(int *)(*(int *)(param_2 + 4) + 0xc);
  iVar7 = FUN_00aff8c0();
  FUN_006cbb30(piVar1,(uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
                      (uint)*(ushort *)(iVar7 + 0x1da));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9103 ; VA 0x006cbf30 ; FUN_006cbf30 */

void FUN_006cbf30(undefined4 *param_1)

{
  FUN_006cd710(param_1[1] * 0x60 + *(int *)*param_1,*(int *)(param_1[3] + 0xc4) + param_1[1] * 0x18,
               param_1[2]);
  return;
}



/* FUNCTION 9104 ; VA 0x006cbf70 ; FUN_006cbf70 */

void FUN_006cbf70(undefined4 *param_1)

{
  FUN_006cce60(param_1[2],param_1[1] * 0x60 + *(int *)*param_1,
               *(int *)(param_1[4] + 0xc4) + param_1[1] * 0x18,param_1[3]);
  return;
}



/* FUNCTION 9105 ; VA 0x006cbfb0 ; FUN_006cbfb0 */

undefined4 FUN_006cbfb0(uint param_1)

{
  uint uVar1;
  char cVar2;
  undefined4 *puVar3;
  byte *pbVar4;
  int iVar5;
  uint uVar6;
  int aiStack_34 [5];
  uint uStack_20;
  byte *pbStack_1c;
  byte *pbStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795d48;
  pvStack_10 = ExceptionList;
  if (DAT_01d5b720 != '\0') {
    ExceptionList = &pvStack_10;
    if (DAT_01ee4215 != '\0') {
      ExceptionList = &pvStack_10;
      puVar3 = (undefined4 *)FUN_008a2380(aiStack_34);
      uStack_8 = 0;
      if (0xf < (uint)puVar3[5]) {
        puVar3 = (undefined4 *)*puVar3;
      }
      FUN_01677520(DAT_01ee4215,
                   "ReplicationDataCache::isMrdInCachePendingList(mrd) : checking if mrd(%p) in cache pending for %s"
                   ,uVar1,puVar3);
      uStack_8 = 0xffffffff;
      if (0xf < uStack_20) {
        uVar6 = uStack_20 + 1;
        iVar5 = aiStack_34[0];
        if (0xfff < uVar6) {
          iVar5 = *(int *)(aiStack_34[0] + -4);
          uVar6 = uStack_20 + 0x24;
          if (0x1f < (aiStack_34[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar5,uVar6);
      }
    }
    if ((*(undefined4 **)(uVar1 + 0x24) != (undefined4 *)0x0) &&
       (cVar2 = (**(code **)**(undefined4 **)(uVar1 + 0x24))(), cVar2 == '\0')) {
      ExceptionList = pvStack_10;
      return 1;
    }
    ExceptionList = pvStack_10;
    return 0;
  }
  pbVar4 = *(byte **)(*(int *)(param_1 + 4) + 0xc);
  ExceptionList = &pvStack_10;
  pbStack_1c = pbVar4;
  pbStack_14 = pbVar4;
  pbStack_14 = (byte *)FUN_006c9d50(&pbStack_14);
  if ((pbStack_14 != (byte *)0x0) &&
     (FUN_00606ea0(&pbStack_18,(uVar1 >> 3) + uVar1,&param_1,
                   -(uint)(pbStack_14 + *pbStack_14 + 1 != (byte *)0x0) &
                   (uint)(pbStack_14 + *pbStack_14 + 1 + 1)), pbStack_18 != (byte *)0x0)) {
    ExceptionList = pvStack_10;
    return 1;
  }
  pbStack_18 = pbVar4;
  pbVar4 = (byte *)FUN_006c9d50(&pbStack_18);
  if ((pbVar4 != (byte *)0x0) &&
     (FUN_00606ea0(&pbStack_18,(uVar1 >> 3) + uVar1,&param_1,
                   -(uint)(pbVar4 + *pbVar4 + 1 != (byte *)0x0) & (uint)(pbVar4 + *pbVar4 + 1 + 1)),
     pbStack_18 != (byte *)0x0)) {
    ExceptionList = pvStack_10;
    return 1;
  }
  pbVar4 = (byte *)FUN_006c9d50(&pbStack_1c);
  if ((pbVar4 != (byte *)0x0) &&
     (FUN_00606ea0(&pbStack_1c,(uVar1 >> 3) + uVar1,&param_1,
                   -(uint)(pbVar4 + *pbVar4 + 1 != (byte *)0x0) & (uint)(pbVar4 + *pbVar4 + 1 + 1)),
     pbStack_1c != (byte *)0x0)) {
    ExceptionList = pvStack_10;
    return 1;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 9106 ; VA 0x006cc1a0 ; FUN_006cc1a0 */

void FUN_006cc1a0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1d9b5dc);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&<lambda_1b0894b57b9a9714897a3c543dc88667>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 9107 ; VA 0x006cc210 ; FUN_006cc210 */

void FUN_006cc210(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      iVar3 = param_1[1];
      iVar1 = param_1[2];
      iVar2 = param_1[3];
      *param_2 = *param_1;
      param_2[1] = iVar3;
      param_2[2] = iVar1;
      param_2[3] = iVar2;
      param_2[4] = param_1[4];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1d9b5a4);
      piVar4 = (int *)0x0;
      if (iVar3 == 0) {
        piVar4 = param_1;
      }
      *param_2 = (int)piVar4;
      return;
    }
  }
  *param_2 = (int)&<lambda_54e465e7cbc7b31329e3b292d129f0cb>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 9108 ; VA 0x006cc280 ; FUN_006cc280 */

void __thiscall
FUN_006cc280(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined **appuStack_6c [15];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a823f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x30) == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8 = 0;
    if (puStack_14 == (undefined4 *)0x0) {
      uVar3 = 0;
    }
    else {
      uVar3 = FUN_006ab530();
    }
    puVar1 = *(undefined4 **)(param_1 + 0x30);
    uStack_8 = 0xffffffff;
    *(undefined4 *)(param_1 + 0x30) = uVar3;
    if (puVar1 != (undefined4 *)0x0) {
      (**(code **)*puVar1)(1);
    }
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  if (*(int *)(param_1 + 4) == 0) {
    FUN_0170d1f0(appuStack_6c,0,0x58);
    uStack_8 = 1;
    appuStack_6c[0] = RBX::Network::ReplicationDataBlob::vftable;
    FUN_006ab530();
    uStack_20 = 0;
    uStack_30 = 0;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
    uStack_1c = 0;
    uStack_18 = 0;
    iVar2 = *(int *)(param_1 + 8);
    uStack_8 = 2;
    puStack_14 = *(undefined4 **)(iVar2 + 4);
    uVar3 = FUN_006c6180(iVar2,puStack_14,appuStack_6c);
    if (*(int *)(param_1 + 0xc) == 0x2aaaaa9) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    uStack_8 = 0xffffffff;
    *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 1;
    *(undefined4 *)(iVar2 + 4) = uVar3;
    *puStack_14 = uVar3;
    FUN_006c89f0();
    iVar2 = *(int *)(*(int *)(param_1 + 8) + 4);
    *(int *)(param_1 + 4) = iVar2 + 8;
    *(undefined *)(iVar2 + 0x18) = 0;
    *(undefined *)(*(int *)(param_1 + 4) + 0x11) = 0;
    if (DAT_01ee4215 != '\0') {
      FUN_01677520(DAT_01ee4215,"ReplicationDataCache::Open Blob %p ",*(undefined4 *)(param_1 + 4));
    }
  }
  *(int *)(param_1 + 0x3c) = *(int *)(param_1 + 0x3c) + 1;
  FUN_006ccc30(param_2,param_4);
  FUN_006c99e0(param_2,param_3,param_5);
  FUN_006c9810(0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9109 ; VA 0x006cc400 ; FUN_006cc400 */

void __thiscall FUN_006cc400(undefined4 param_1,uint param_2,byte *param_3,int *param_4)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint *puVar7;
  int aiStack_38 [5];
  uint uStack_24;
  undefined4 uStack_20;
  uint *puStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799148;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(param_2 + 0x2c);
  if (piVar1 != (int *)0x0) {
    puVar7 = (uint *)*piVar1;
    puStack_1c = (uint *)piVar1[1];
    ExceptionList = &pvStack_10;
    uStack_20 = param_1;
    if (puVar7 != puStack_1c) {
      do {
        param_2 = *puVar7;
        FUN_006c9df0(&iStack_14,&param_2);
        iVar4 = iStack_14;
        if (iStack_14 != 0) {
          if (DAT_01d5b720 == '\0') {
LAB_006cc4a2:
            iVar3 = *(int *)(iVar4 + 0x2c);
            if (iVar3 == 0) {
LAB_006cc4ae:
              param_2 = iVar4 + 0xc;
              FUN_00606ea0(&iStack_18,(param_2 >> 3) + param_2,&param_2,
                           -(uint)(param_3 + *param_3 + 1 != (byte *)0x0) &
                           (uint)(param_3 + *param_3 + 1 + 1));
              if (iStack_18 == 0) goto LAB_006cc57d;
              iVar3 = *(int *)(iStack_18 + 0xc);
              iVar4 = *(int *)(iStack_18 + 0x10);
            }
            else {
              iVar4 = *(int *)(iVar4 + 0x34);
            }
          }
          else {
            if ((*(undefined4 **)(iStack_14 + 0x30) == (undefined4 *)0x0) ||
               (cVar2 = (**(code **)**(undefined4 **)(iStack_14 + 0x30))(), cVar2 == '\0')) {
              if (DAT_01d5b720 == '\0') goto LAB_006cc4a2;
              goto LAB_006cc4ae;
            }
            iVar3 = FUN_0170d75d(*(undefined4 *)(iVar4 + 0x30),0,
                                 &RBX::Network::ReplicationDataBlock::RTTI_Type_Descriptor,
                                 &RBX::Network::ReplicationDataBlob::RTTI_Type_Descriptor,0);
            iVar4 = *(int *)(iVar4 + 0x34);
          }
          if (iVar3 != 0) {
            *param_4 = *param_4 + 1;
            *(int *)(*(int *)(iVar3 + 0x40) + 0x10 + iVar4 * 0x18) = *param_4;
            if (DAT_01ee4215 != '\0') {
              iVar4 = *param_4;
              puVar5 = (undefined4 *)FUN_008a2380(aiStack_38);
              uStack_8 = 0;
              if (0xf < (uint)puVar5[5]) {
                puVar5 = (undefined4 *)*puVar5;
              }
              FUN_01677520(DAT_01ee4215,"ReplicationDataCache:: Instance[%s] assigned order#%d=",
                           puVar5,iVar4);
              uStack_8 = 0xffffffff;
              if (0xf < uStack_24) {
                uVar6 = uStack_24 + 1;
                iVar4 = aiStack_38[0];
                if (0xfff < uVar6) {
                  iVar4 = *(int *)(aiStack_38[0] + -4);
                  uVar6 = uStack_24 + 0x24;
                  if (0x1f < (aiStack_38[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
                    FUN_017167a3();
                  }
                }
                FUN_01674ea0(iVar4,uVar6);
              }
            }
          }
        }
LAB_006cc57d:
        puVar7 = puVar7 + 2;
      } while (puVar7 != puStack_1c);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9110 ; VA 0x006cc5b0 ; FUN_006cc5b0 */

void __fastcall FUN_006cc5b0(int *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint *puVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  uint uStack_28;
  int *piStack_20;
  int iStack_1c;
  uint uStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8258;
  pvStack_10 = ExceptionList;
  if (*param_1 == param_1[1]) {
    iVar3 = 0x10;
  }
  else {
    iVar3 = ((param_1[1] - *param_1) / 0x1c) * 2;
  }
  ExceptionList = &pvStack_10;
  piStack_20 = param_1;
  FUN_006c80e0(param_1 + 4,iVar3);
  iVar3 = *param_1;
  uStack_8 = 0;
  uStack_18 = 0;
  iVar1 = param_1[1] - iVar3 >> 0x1f;
  if ((param_1[1] - iVar3) / 0x1c + iVar1 != iVar1) {
    iStack_1c = 0;
    do {
      puStack_14 = (uint *)(iStack_1c + iVar3);
      uVar8 = *puStack_14;
      if (uVar8 != param_1[4]) {
        uVar4 = (uVar8 >> 3) + uVar8;
        uVar6 = (iStack_34 - iStack_38) / 0x1c - 1;
        uVar7 = 0;
        do {
          uVar4 = uVar4 & uVar6;
          puVar5 = (uint *)(iStack_38 + uVar4 * 0x1c);
          if (*puVar5 == uStack_28) {
            *puVar5 = uVar8;
            iStack_2c = iStack_2c + 1;
            uVar8 = *puStack_14;
            goto LAB_006cc6a5;
          }
          if (*puVar5 == uVar8) goto LAB_006cc6a5;
          uVar4 = uVar4 + 1 + uVar7;
          uVar7 = uVar7 + 1;
        } while (uVar7 <= uVar6);
        puVar5 = (uint *)0x0;
LAB_006cc6a5:
        *puVar5 = uVar8;
        param_1 = piStack_20;
        if (puVar5 + 1 != puStack_14 + 1) {
          FUN_006c9480(puStack_14 + 1,piStack_20);
          param_1 = piStack_20;
        }
      }
      iVar3 = *param_1;
      uStack_18 = uStack_18 + 1;
      iStack_1c = iStack_1c + 0x1c;
    } while (uStack_18 < (uint)((param_1[1] - iVar3) / 0x1c));
  }
  if (param_1 != &iStack_38) {
    *param_1 = iStack_38;
    iVar1 = param_1[1];
    param_1[1] = iStack_34;
    iVar2 = param_1[2];
    param_1[2] = iStack_30;
    iStack_38 = iVar3;
    iStack_34 = iVar1;
    iStack_30 = iVar2;
  }
  FUN_006c8f00();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9111 ; VA 0x006cc730 ; FUN_006cc730 */

void __thiscall FUN_006cc730(int param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  iVar5 = *(int *)(param_2 + 0x28);
  ExceptionList = &pvStack_10;
  if (DAT_01ee4215 != '\0') {
    ExceptionList = &pvStack_10;
    puVar3 = (undefined4 *)FUN_008a2380(auStack_28);
    uStack_8 = 0;
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    FUN_01677490(DAT_01ee4215,
                 "ReplicationDataBlob::remove(mrd) : marking mrd(%p) blob invalid for %s",param_2,
                 puVar3,0);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar7 = uStack_14 + 1;
      uVar6 = auStack_28[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_28[0] - 4);
        uVar7 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
  }
  if (DAT_01d5b230 != '\0') {
    if (DAT_01ee4215 != '\0') {
      FUN_01677490(DAT_01ee4215,"Invalidating instance in blob %p  offset %u  length %u",param_1,
                   *(undefined4 *)(*(int *)(param_1 + 0x40) + iVar5 * 0x18),
                   *(undefined4 *)(*(int *)(param_1 + 0x40) + 4 + iVar5 * 0x18));
    }
    puVar1 = *(undefined4 **)(param_1 + 0x50);
    puVar3 = (undefined4 *)(*(int *)(param_1 + 0x40) + iVar5 * 0x18);
    if (*(undefined4 **)(param_1 + 0x54) == puVar1) {
      FUN_006c62b0(puVar1,puVar3,puVar3 + 1);
    }
    else {
      uVar2 = puVar3[1];
      *puVar1 = *puVar3;
      puVar1[1] = uVar2;
      *(int *)(param_1 + 0x50) = *(int *)(param_1 + 0x50) + 8;
    }
  }
  *(undefined4 *)(param_2 + 0x24) = 0;
  *(undefined4 *)(*(int *)(param_1 + 0x40) + 8 + iVar5 * 0x18) = 0;
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + -1;
  *(int *)(param_1 + 4) =
       *(int *)(param_1 + 4) - *(int *)(*(int *)(param_1 + 0x40) + 4 + iVar5 * 0x18);
  *(undefined4 *)(*(int *)(param_1 + 0x40) + 4 + iVar5 * 0x18) = 0;
  *(undefined4 *)(param_2 + 0x28) = 0xffffffff;
  if (DAT_01d5bc10 != '\0') {
    if ((*(int *)(param_2 + 4) != 0) &&
       (iVar5 = *(int *)(*(int *)(param_2 + 4) + 0xc), iVar4 = FUN_00af0010(),
       (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
       (uint)*(ushort *)(iVar4 + 0x1da))) {
      *(undefined *)(param_1 + 0x10) = 0;
      ExceptionList = pvStack_10;
      return;
    }
    iVar5 = FUN_008aa870();
    iVar4 = thunk_FUN_00897b90();
    if (iVar4 == iVar5) {
      *(undefined *)(param_1 + 0x11) = 0;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9112 ; VA 0x006cc900 ; FUN_006cc900 */

void __thiscall FUN_006cc900(int param_1,int param_2)

{
  int iVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_2 + 0x28);
  if (DAT_01ee4215 != '\0') {
    ExceptionList = &pvStack_10;
    puVar2 = (undefined4 *)FUN_008a2380(aiStack_28);
    uStack_8 = 0;
    if (0xf < (uint)puVar2[5]) {
      puVar2 = (undefined4 *)*puVar2;
    }
    FUN_01677520(DAT_01ee4215,"removing from ReplicationDataPreBlob: %p, instance name: %s",param_2,
                 puVar2);
    if (0xf < uStack_14) {
      uVar4 = uStack_14 + 1;
      iVar3 = aiStack_28[0];
      if (0xfff < uVar4) {
        iVar3 = *(int *)(aiStack_28[0] + -4);
        uVar4 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar4);
    }
  }
  *(undefined4 *)(*(int *)(param_1 + 4) + iVar1 * 8) = 0;
  *(undefined4 *)(param_2 + 0x24) = 0;
  *(undefined4 *)(param_2 + 0x28) = 0xffffffff;
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + -1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9113 ; VA 0x006cc9d0 ; FUN_006cc9d0 */

void FUN_006cc9d0(int param_1)

{
  char cVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int aiStack_2c [5];
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ee4215 != '\0') {
    ExceptionList = &pvStack_10;
    puVar2 = (undefined4 *)FUN_008a2380(aiStack_2c);
    uStack_8 = 0;
    if (0xf < (uint)puVar2[5]) {
      puVar2 = (undefined4 *)*puVar2;
    }
    FUN_01677520(DAT_01ee4215,
                 "ReplicationDataCache::removeFromCacheAndCachePendingListIfExist(mrd) : marking mrd(%p) blob invalid for %s"
                 ,iVar4,puVar2);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_18) {
      uVar6 = uStack_18 + 1;
      iVar5 = aiStack_2c[0];
      if (0xfff < uVar6) {
        iVar5 = *(int *)(aiStack_2c[0] + -4);
        uVar6 = uStack_18 + 0x24;
        if (0x1f < (aiStack_2c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar5,uVar6);
    }
  }
  if (DAT_01d5b720 == '\0') {
    if (*(int *)(iVar4 + 0x20) != 0) {
      FUN_006cbc40(iVar4,1);
    }
    iVar5 = *(int *)(iVar4 + 4);
    uStack_14 = *(undefined4 *)(iVar5 + 0xc);
    iVar3 = FUN_006c9d50(&uStack_14);
    if (iVar3 != 0) {
      FUN_006c9730(&param_1);
      iVar5 = *(int *)(iVar4 + 4);
    }
    uStack_14 = *(undefined4 *)(iVar5 + 0xc);
    iVar3 = FUN_006c9d50(&uStack_14);
    if (iVar3 != 0) {
      FUN_006c9730(&param_1);
      iVar5 = *(int *)(iVar4 + 4);
    }
    uStack_14 = *(undefined4 *)(iVar5 + 0xc);
    iVar4 = FUN_006c9d50(&uStack_14);
    if (iVar4 != 0) {
      FUN_006c9730(&param_1);
    }
  }
  else if (*(undefined4 **)(iVar4 + 0x24) != (undefined4 *)0x0) {
    cVar1 = (**(code **)**(undefined4 **)(iVar4 + 0x24))();
    if (cVar1 != '\0') {
      FUN_006cbc40(iVar4,1);
      ExceptionList = pvStack_10;
      return;
    }
    (**(code **)(**(int **)(iVar4 + 0x24) + 0x10))(iVar4);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9114 ; VA 0x006ccb60 ; FUN_006ccb60 */

void __thiscall FUN_006ccb60(int *param_1,undefined4 param_2)

{
  undefined2 uVar1;
  int iVar2;
  int iVar3;
  uint uStack_8;
  
  if (DAT_01ee4215 != '\0') {
    FUN_01677520(DAT_01ee4215,
                 "ReplicationDataBlob::requeueInstancesForBlobbing(blob) : requeueing instances from %p to %p"
                 ,param_1,param_2);
  }
  uStack_8 = 0;
  iVar3 = param_1[0x10];
  iVar2 = param_1[0x11] - iVar3 >> 0x1f;
  if ((param_1[0x11] - iVar3) / 0x18 + iVar2 != iVar2) {
    iVar2 = 0;
    do {
      iVar3 = *(int *)(iVar2 + 8 + iVar3);
      if (iVar3 != 0) {
        uVar1 = *(undefined2 *)(iVar2 + 0x14 + param_1[0x10]);
        (**(code **)(*param_1 + 0x10))(iVar3);
        FUN_006cb170(iVar3,uVar1);
      }
      iVar3 = param_1[0x10];
      iVar2 = iVar2 + 0x18;
      uStack_8 = uStack_8 + 1;
    } while (uStack_8 < (uint)((param_1[0x11] - iVar3) / 0x18));
  }
  if (DAT_01ee4215 != '\0') {
    FUN_01677520(DAT_01ee4215,"totalUncompressedUsedBytes = %d",param_1[1]);
  }
  return;
}



/* FUNCTION 9115 ; VA 0x006ccc30 ; FUN_006ccc30 */

void __thiscall FUN_006ccc30(int *param_1,uint param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  ushort *puVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int aiStack_60 [5];
  uint uStack_4c;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  ushort *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar1 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8280;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ee4215 != '\0') {
    ExceptionList = &pvStack_10;
    puVar2 = (undefined4 *)FUN_009c9510(aiStack_60);
    iStack_8 = 0;
    if (0xf < (uint)puVar2[5]) {
      puVar2 = (undefined4 *)*puVar2;
    }
    puVar3 = (undefined4 *)FUN_008a2380(auStack_48);
    iStack_8._0_1_ = 1;
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    FUN_01677490(DAT_01ee4215,"ReplicationDataCache::serializeInstance : serializing %s [%s]",puVar3
                 ,puVar2,0);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_34) {
      uVar7 = uStack_34 + 1;
      uVar8 = auStack_48[0];
      if (0xfff < uVar7) {
        uVar8 = *(uint *)(auStack_48[0] - 4);
        uVar7 = uStack_34 + 0x24;
        if (0x1f < (auStack_48[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar7);
    }
    uStack_38 = 0;
    uStack_34 = 0xf;
    auStack_48[0] = auStack_48[0] & 0xffffff00;
    iStack_8 = 0xffffffff;
    if (0xf < uStack_4c) {
      uVar8 = uStack_4c + 1;
      iVar6 = aiStack_60[0];
      if (0xfff < uVar8) {
        iVar6 = *(int *)(aiStack_60[0] + -4);
        uVar8 = uStack_4c + 0x24;
        if (0x1f < (aiStack_60[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar6,uVar8);
    }
  }
  FUN_006b9320(param_1[0xc],*(undefined4 *)(iVar1 + 4));
  iVar6 = *(int *)(*param_1 + 0x19f4);
  puVar4 = (ushort *)FUN_006193f0(*(undefined4 *)(*(int *)(iVar1 + 4) + 0xc));
  param_2 = (uint)*puVar4;
  if (param_2 < (uint)((*(int *)(iVar6 + 0x5c) - *(int *)(iVar6 + 0x58)) / 0x3c)) {
    puStack_14 = (ushort *)(*(int *)(iVar6 + 0x58) + param_2 * 0x3c);
  }
  else {
    puStack_14 = (ushort *)0x0;
  }
  uStack_18 = (uint)*puStack_14;
  FUN_006a5c10(&uStack_18,&param_2,2);
  FUN_006ad5e0(&param_2,2);
  puVar4 = puStack_14;
  uVar5 = FUN_0061ec80(*(undefined4 *)(*(int *)(puStack_14 + 4) + 4));
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_006c1bf0(*param_1,param_1[0xc],puVar4,*(undefined4 *)(iVar1 + 4),0,0,uVar5,param_3,&uStack_30)
  ;
  uStack_20 = 0xffffffff;
  uStack_1c = 0;
  iVar1 = *(int *)(*(int *)(iVar1 + 4) + 0x34);
  if (iVar1 != 0) {
    uStack_20 = *(undefined4 *)(iVar1 + 0x18);
    uStack_1c = *(undefined4 *)(iVar1 + 0x1c);
  }
  FUN_006b92d0(param_1[0xc],&uStack_20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9116 ; VA 0x006cce60 ; FUN_006cce60 */

void FUN_006cce60(int *param_1,int param_2,int param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  uint *puVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined *puVar8;
  uint uVar9;
  undefined4 *puVar10;
  uint uVar11;
  uint uVar12;
  undefined4 *puVar13;
  int *piStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  uint uStack_34;
  undefined4 *puStack_30;
  undefined2 uStack_2c;
  undefined4 *puStack_28;
  int *piStack_24;
  int *piStack_20;
  uint *puStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017a82a0;
  pvStack_10 = ExceptionList;
  piStack_40 = (int *)0x0;
  piStack_3c = (int *)0x0;
  uStack_38 = 0;
  iStack_8 = 0;
  puStack_28 = *(undefined4 **)(param_2 + 0x4c);
  puVar10 = *(undefined4 **)(param_2 + 0x48);
  ExceptionList = &pvStack_10;
  puStack_18 = puVar10;
  if (puVar10 != puStack_28) {
    piStack_20 = (int *)&DAT_00000008;
    ExceptionList = &pvStack_10;
    do {
      if (*param_1 != param_1[1]) {
        puVar5 = (uint *)*puVar10;
        puStack_1c = (uint *)param_1[4];
        if (puVar5 != puStack_1c) {
          uVar11 = (param_1[1] - *param_1) / 0x1c - 1;
          puVar8 = (undefined *)(((uint)puVar5 >> 3) + (int)puVar5);
          uVar12 = 0;
          do {
            uVar9 = (uint)puVar8 & uVar11;
            puStack_14 = (undefined4 *)(*param_1 + uVar9 * 0x1c);
            if ((uint *)*puStack_14 == (uint *)*puVar10) goto LAB_006ccf27;
            if ((uint *)*puStack_14 == puStack_1c) break;
            puVar8 = (undefined *)(uVar9 + 1 + uVar12);
            uVar12 = uVar12 + 1;
          } while (uVar12 <= uVar11);
        }
      }
      puStack_14 = (undefined4 *)0x0;
LAB_006ccf27:
      uVar11 = puVar10[1];
      if (uVar11 <= (uint)puVar10[2]) {
        puVar5 = puStack_14 + 2;
        if (puStack_14 == (undefined4 *)0x0) {
          puVar5 = (uint *)&DAT_00000004;
        }
        piStack_24 = puStack_14 + 3;
        puVar13 = puStack_14;
        puStack_1c = puVar5;
        puStack_18 = puVar10;
        if (puStack_14 == (undefined4 *)0x0) {
          piStack_24 = piStack_20;
        }
        do {
          uVar12 = *puVar5;
          if (*piStack_24 != 0) {
            piVar6 = puVar13 + 6;
            if (puVar13 == (undefined4 *)0x0) {
              piVar6 = (int *)&DAT_00000014;
            }
            puVar13 = *(undefined4 **)(*piVar6 + uVar11 * 4);
            if (puVar13 == (undefined4 *)0x0) {
              piVar6 = (int *)0x0;
            }
            else {
              piVar6 = (int *)*puVar13;
            }
            do {
              puVar5 = puStack_1c;
              puVar13 = puStack_14;
              if (piVar6 == (int *)0x0) break;
              FUN_006cc280(piVar6[2],piVar6 + 3,&piStack_40,param_4);
              piVar6 = (int *)*piVar6;
              puVar10 = puStack_18;
            } while ((piVar6 == (int *)0x0) ||
                    (puVar5 = puStack_1c, puVar13 = puStack_14, (uint)piVar6[1] % uVar12 == uVar11))
            ;
          }
          uVar11 = uVar11 + 1;
        } while (uVar11 <= (uint)puVar10[2]);
      }
      puVar10 = puVar10 + 3;
      puStack_18 = puVar10;
    } while (puVar10 != puStack_28);
  }
  FUN_006c9810(1);
  piVar4 = piStack_3c;
  iVar3 = param_3;
  piVar6 = piStack_40;
  if (DAT_01d5b710 != '\0') {
    *(int *)(param_2 + 0x40) = *(int *)(param_2 + 0x40) - *(int *)(param_2 + 0x34);
    *(int *)(param_2 + 0x44) = *(int *)(param_2 + 0x44) - *(int *)(param_2 + 0x38);
  }
  for (; piVar6 != piVar4; piVar6 = piVar6 + 1) {
    uVar7 = FUN_00a33fd0(piVar6);
    FUN_0061ded0(&param_2,uVar7,piVar6);
    if (param_2 == 0) {
      puStack_30 = (undefined4 *)0x0;
      uStack_34 = -(uint)(iVar3 != -3) & iVar3 + 4U;
      iStack_8._0_1_ = 1;
      uStack_2c = 0;
      puStack_30 = (undefined4 *)FUN_01674e20(0xc);
      uStack_2c = 0x101;
      *puStack_30 = 0;
      puStack_30[1] = 0;
      puStack_30[2] = 0;
      iVar2 = *piVar6;
      puStack_30[2] = iVar2;
      LOCK();
      piVar1 = (int *)(iVar2 + 0x28);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      FUN_0062b610(*(int *)(iVar3 + 8) + 1);
      FUN_005c5550(&param_4,&uStack_34,uVar7);
      puVar10 = puStack_30;
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (puStack_30 != (undefined4 *)0x0) {
        if (uStack_2c._1_1_ != '\0') {
          FUN_0056cd30();
        }
        FUN_01674ea0(puVar10,0xc);
      }
    }
  }
  FUN_00612dd0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9117 ; VA 0x006cd0e0 ; FUN_006cd0e0 */

void __thiscall
FUN_006cd0e0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  uint uVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a82d0;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if (*(int *)(iVar1 + 0x34) < DAT_01eaefc0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01eaefc0);
    if (DAT_01eaefc0 == -1) {
      uStack_8 = 0;
      uVar8 = FUN_0152dab0(&DAT_018c5904,"SettingInstanceAlive",0xffffffff);
      DAT_01eaefbc = (undefined4)((ulonglong)uVar8 >> 0x20);
      DAT_01eaefb8 = (undefined4)uVar8;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01eaefc0);
    }
  }
  uVar3 = DAT_01eaefbc;
  uVar2 = DAT_01eaefb8;
  uVar8 = FUN_0152d930(DAT_01eaefb8,DAT_01eaefbc);
  uStack_8 = 1;
  uStack_14 = 0;
  FUN_006cd320(param_2,param_1 + 0x88,param_4,&uStack_14,param_5);
  FUN_006cd320(param_2,param_1 + 0x90,param_4,&uStack_14,param_5);
  FUN_006cd320(param_2,param_3,param_4,&uStack_14,param_5);
  if (((DAT_01d5b808 != '\0') && (DAT_01d5b7f8 != '\0')) && ((char)param_5 == '\0')) {
    FUN_00620a50();
  }
  if (*(int *)(iVar1 + 0x34) < DAT_01eaefd0) {
    FUN_016f3809(&DAT_01eaefd0);
    if (DAT_01eaefd0 == -1) {
      uStack_8._0_1_ = 2;
      uVar9 = FUN_0152da50(&DAT_018c5904);
      DAT_01eaefcc = (undefined4)((ulonglong)uVar9 >> 0x20);
      DAT_01eaefc8 = (undefined4)uVar9;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01eaefd0);
    }
  }
  FUN_0152d760(DAT_01eaefc8,DAT_01eaefcc,"Number of instances set alive: %zu",uStack_14);
  cVar4 = FUN_0061ef20();
  if ((cVar4 == '\0') && (DAT_01d5a098 != '\0')) {
    puVar6 = *(undefined4 **)(param_1 + 0xb0);
    uVar7 = 0;
    uVar5 = (uint)((int)*(undefined4 **)(param_1 + 0xb4) + (3 - (int)puVar6)) >> 2;
    if (*(undefined4 **)(param_1 + 0xb4) < puVar6) {
      uVar5 = 0;
    }
    if (uVar5 != 0) {
      do {
        param_5 = 0;
        FUN_006cc400(*puVar6,param_4,&param_5);
        uVar7 = uVar7 + 1;
        puVar6 = puVar6 + 1;
      } while (uVar7 != uVar5);
    }
  }
  uStack_8 = 3;
  FUN_0152dda0(uVar2,uVar3,uVar8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9118 ; VA 0x006cd320 ; FUN_006cd320 */

uint FUN_006cd320(int param_1,int *param_2,undefined4 param_3,int *param_4,char param_5)

{
  int *piVar1;
  int *piVar2;
  undefined uVar3;
  undefined uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined uVar7;
  char cVar8;
  uint uVar9;
  undefined4 *puVar10;
  int iVar11;
  uint *puVar12;
  int iVar13;
  int iVar14;
  int iVar15;
  uint uVar16;
  undefined4 uVar17;
  undefined4 uVar18;
  int aiStack_50 [5];
  uint uStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  int iStack_2c;
  int iStack_28;
  uint uStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  byte bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017a82f0;
  pvStack_10 = ExceptionList;
  uStack_38 = 0;
  piStack_34 = (int *)0x0;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar9 = FUN_0061ef20();
  uVar16 = uVar9 & 0xff;
  bStack_11 = (byte)uVar9;
  puVar5 = (undefined4 *)*param_2;
  puVar6 = (undefined4 *)*puVar5;
  piVar1 = piStack_34;
  do {
    piStack_34 = piVar1;
    if (puVar6 == puVar5) {
      if (piVar1 != (int *)0x0) {
        LOCK();
        puVar12 = (uint *)(piVar1 + 1);
        uVar16 = *puVar12;
        uVar9 = *puVar12;
        *puVar12 = uVar16 - 1;
        UNLOCK();
        if (uVar16 - 1 == 0) {
          uVar9 = (**(code **)*piVar1)();
          LOCK();
          piVar2 = piVar1 + 2;
          iVar11 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar11 == 1) {
            uVar9 = (**(code **)(*piVar1 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return uVar9;
    }
    if (((param_5 == '\0') && (cVar8 = FUN_006216f0(), cVar8 == '\0')) || ((char)uVar16 == '\0')) {
      iVar11 = puVar6[0x12];
      iVar14 = puVar6[0x13];
      iStack_18 = iVar14;
      if (iVar11 != iVar14) {
        do {
          iVar15 = *(int *)(iVar11 + 8);
          iStack_20 = iVar15;
          if (iVar15 != 0) {
            if ((param_5 == '\0') &&
               (cVar8 = FUN_006216f0(), uVar7 = DAT_01d5b840, iVar14 = iStack_18, cVar8 == '\0')) {
              iVar14 = *(int *)(param_1 + 0x19f4);
              iStack_2c = *(int *)(iVar14 + 0x1c);
              uStack_24 = *(uint *)(*(int *)(iVar15 + 4) + 0xc);
              if ((iStack_2c != *(int *)(iVar14 + 0x20)) && (uStack_24 != *(uint *)(iVar14 + 0x2c)))
              {
                iStack_28 = *(int *)(iVar14 + 0x20) - iStack_2c >> 3;
                uVar9 = (uStack_24 >> 3) + uStack_24 & iStack_28 - 1U;
                uVar16 = 0;
                do {
                  puVar12 = (uint *)(iStack_2c + uVar9 * 8);
                  if (*puVar12 == uStack_24) goto LAB_006cd427;
                  if (*puVar12 == *(uint *)(iVar14 + 0x2c)) break;
                  uVar9 = uVar9 + 1 + uVar16;
                  uVar16 = uVar16 + 1;
                  uVar9 = uVar9 & iStack_28 - 1U;
                } while (uVar16 <= iStack_28 - 1U);
              }
              puVar12 = (uint *)0x0;
LAB_006cd427:
              uVar9 = (uint)*(ushort *)(-(uint)(puVar12 != (uint *)0x0) & (uint)(puVar12 + 1));
              iVar13 = *(int *)(iVar14 + 0x5c) - *(int *)(iVar14 + 0x58);
              iVar15 = iVar13 >> 0x1f;
              iVar13 = iVar13 / 0x3c + iVar15;
              if (uVar9 < (uint)(iVar13 - iVar15)) {
                iStack_1c = *(uint *)(iVar14 + 0x58) + uVar9 * 0x3c;
                uVar9 = *(uint *)(iVar14 + 0x58);
                iVar13 = iVar14;
              }
              else {
                iStack_1c = 0;
              }
              if (DAT_01d5b718 == '\0') {
                uVar3 = *(undefined *)(iVar11 + 0x15);
                uVar4 = *(undefined *)(iVar11 + 0x14);
                if (*(int *)(iStack_20 + 8) != 0) {
                  LOCK();
                  piVar1 = (int *)(*(int *)(iStack_20 + 8) + 4);
                  *piVar1 = *piVar1 + 1;
                  UNLOCK();
                }
                uVar17 = *(undefined4 *)(iStack_20 + 4);
                uVar18 = *(undefined4 *)(iStack_20 + 8);
              }
              else {
                uVar3 = *(undefined *)(iStack_20 + 0x32);
                uVar4 = *(undefined *)(iStack_20 + 0x31);
                if (*(int *)(iStack_20 + 8) != 0) {
                  LOCK();
                  piVar1 = (int *)(*(int *)(iStack_20 + 8) + 4);
                  *piVar1 = *piVar1 + 1;
                  UNLOCK();
                }
                uVar17 = *(undefined4 *)(iStack_20 + 4);
                uVar18 = *(undefined4 *)(iStack_20 + 8);
              }
              FUN_00617d00(iStack_1c,uVar17,uVar18,CONCAT31((int3)((uint)iVar13 >> 8),uVar4),
                           CONCAT31((int3)(uVar9 >> 8),uVar3),0,&uStack_38,uVar7);
              iVar14 = iStack_18;
            }
            if (bStack_11 == 0) {
              iStack_20 = 0;
              FUN_006cc400(*(undefined4 *)(*(int *)(iVar11 + 8) + 4),param_3,&iStack_20);
              iVar14 = iStack_20;
              if (DAT_01ee4215 != '\0') {
                puVar10 = (undefined4 *)FUN_008a2380(aiStack_50);
                iStack_8._0_1_ = 1;
                if (0xf < (uint)puVar10[5]) {
                  puVar10 = (undefined4 *)*puVar10;
                }
                FUN_01677520(DAT_01ee4215,
                             "ReplicationDataCache:: Instance[%s] assigned numOfChildren#%d=",
                             puVar10,iVar14);
                iStack_8 = (uint)iStack_8._1_3_ << 8;
                if (0xf < uStack_3c) {
                  uVar9 = uStack_3c + 1;
                  iVar15 = aiStack_50[0];
                  if (0xfff < uVar9) {
                    iVar15 = *(int *)(aiStack_50[0] + -4);
                    uVar9 = uStack_3c + 0x24;
                    if (0x1f < (aiStack_50[0] - iVar15) - 4U) {
                    /* WARNING: Subroutine does not return */
                      FUN_017167a3();
                    }
                  }
                  FUN_01674ea0(iVar15,uVar9);
                }
              }
              *(int *)(iVar11 + 0xc) = iVar14;
              iVar14 = iStack_18;
            }
          }
          uVar16 = (uint)bStack_11;
          iVar11 = iVar11 + 0x18;
        } while (iVar11 != iVar14);
      }
    }
    uVar9 = puVar6[5];
    *param_4 = *param_4 + uVar9;
    puVar6 = (undefined4 *)*puVar6;
    piVar1 = piStack_34;
  } while( true );
}



/* FUNCTION 9119 ; VA 0x006cd620 ; FUN_006cd620 */

int __fastcall FUN_006cd620(int param_1)

{
  ulonglong uVar1;
  int iVar2;
  
  uVar1 = (longlong)*(int *)(param_1 + 8) * (longlong)DAT_01d5b6c4 & 0xffffffff;
  if (DAT_01d5b230 == '\0') {
    iVar2 = (uint)(uint3)(uVar1 * 0x51eb851f >> 8) << 8;
  }
  else {
    iVar2 = *(int *)(param_1 + 0x50) - *(int *)(param_1 + 0x4c);
    iVar2 = CONCAT31((int3)(iVar2 >> 0xb),
                     (uint)(((longlong)
                             ((*(int *)(param_1 + 0x44) - *(int *)(param_1 + 0x40)) / 0x18) *
                             (longlong)DAT_01d5b6cc & 0xffffffffU) / 100) < (uint)(iVar2 >> 3));
  }
  if (((uint)(uVar1 / 100) <= *(uint *)(param_1 + 4)) && ((char)iVar2 == '\0')) {
    return iVar2;
  }
  return CONCAT31((int3)((uint)iVar2 >> 8),1);
}



/* FUNCTION 9120 ; VA 0x006cd690 ; FUN_006cd690 */

int FUN_006cd690(int param_1)

{
  ulonglong uVar1;
  int iVar2;
  
  uVar1 = (longlong)*(int *)(param_1 + 8) * (longlong)DAT_01d5b6c4 & 0xffffffff;
  if (DAT_01d5b230 == '\0') {
    iVar2 = (uint)(uint3)(uVar1 * 0x51eb851f >> 8) << 8;
  }
  else {
    iVar2 = *(int *)(param_1 + 0x50) - *(int *)(param_1 + 0x4c);
    iVar2 = CONCAT31((int3)(iVar2 >> 0xb),
                     (uint)(((longlong)
                             ((*(int *)(param_1 + 0x44) - *(int *)(param_1 + 0x40)) / 0x18) *
                             (longlong)DAT_01d5b6cc & 0xffffffffU) / 100) < (uint)(iVar2 >> 3));
  }
  if (((uint)(uVar1 / 100) <= *(uint *)(param_1 + 4)) && ((char)iVar2 == '\0')) {
    return iVar2;
  }
  return CONCAT31((int3)((uint)iVar2 >> 8),1);
}



/* FUNCTION 9121 ; VA 0x006cd710 ; FUN_006cd710 */

void FUN_006cd710(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  void **ppvVar6;
  undefined4 uVar7;
  int *piVar8;
  int iVar9;
  int *piStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined2 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  uVar7 = param_3;
  iVar4 = param_1;
  puStack_c = &LAB_017a8310;
  pvStack_10 = ExceptionList;
  piStack_28 = (int *)0x0;
  piStack_24 = (int *)0x0;
  uStack_20 = 0;
  iStack_8 = 0;
  iVar9 = *(int *)(param_1 + 0x58);
  ExceptionList = &pvStack_10;
  ppvVar6 = &pvStack_10;
  if (iVar9 <= *(int *)(param_1 + 0x5c)) {
    do {
      ExceptionList = ppvVar6;
      iVar2 = *(int *)(*(int *)(iVar4 + 0x54) + 4);
      iVar3 = *(int *)(iVar2 + iVar9 * 8);
      if (iVar3 != 0) {
        FUN_006cc280(iVar3,iVar2 + iVar9 * 8 + 4,&piStack_28,uVar7);
      }
      iVar9 = iVar9 + 1;
      ppvVar6 = (void **)ExceptionList;
    } while (iVar9 <= *(int *)(iVar4 + 0x5c));
  }
  FUN_006c9810(1);
  iVar9 = param_2;
  if (DAT_01d5b710 != '\0') {
    *(int *)(iVar4 + 0x40) = *(int *)(iVar4 + 0x40) - *(int *)(iVar4 + 0x34);
    *(int *)(iVar4 + 0x44) = *(int *)(iVar4 + 0x44) - *(int *)(iVar4 + 0x38);
  }
  param_3 = piStack_24;
  piVar8 = piStack_28;
  if (piStack_28 != piStack_24) {
    do {
      uVar7 = FUN_00a33fd0(piVar8);
      FUN_0061ded0(&param_1,uVar7,piVar8);
      if (param_1 == 0) {
        puStack_18 = (undefined4 *)0x0;
        uStack_1c = -(uint)(iVar9 != -3) & iVar9 + 4U;
        iStack_8._0_1_ = 1;
        uStack_14 = 0;
        puStack_18 = (undefined4 *)FUN_01674e20(0xc);
        uStack_14 = 0x101;
        *puStack_18 = 0;
        puStack_18[1] = 0;
        puStack_18[2] = 0;
        iVar4 = *piVar8;
        puStack_18[2] = iVar4;
        LOCK();
        piVar1 = (int *)(iVar4 + 0x28);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
        FUN_0062b610(*(int *)(iVar9 + 8) + 1);
        FUN_005c5550(&param_2,&uStack_1c,uVar7);
        puVar5 = puStack_18;
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        if (puStack_18 != (undefined4 *)0x0) {
          if (uStack_14._1_1_ != '\0') {
            FUN_0056cd30();
          }
          FUN_01674ea0(puVar5,0xc);
        }
      }
      piVar8 = piVar8 + 1;
    } while (piVar8 != param_3);
  }
  FUN_00612dd0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9122 ; VA 0x006cd8a0 ; FUN_006cd8a0 */

undefined4 * __thiscall
FUN_006cd8a0(undefined4 *param_1,int *param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 *param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a8333;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Network::SharedQueueItem::vftable;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[2] = *param_5;
  param_1[3] = param_5[1];
  param_1[4] = param_5[2];
  *param_5 = 0;
  param_5[1] = 0;
  param_5[2] = 0;
  param_1[5] = param_5[3];
  param_1[6] = param_5[4];
  param_1[8] = param_6;
  param_1[9] = param_7;
  *param_1 = RBX::Network::SharedReferencePropertyChangedItem::vftable;
  param_1[10] = param_2;
  param_1[0xb] = param_3;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  if (param_4[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[0xc] = *param_4;
  param_1[0xd] = param_4[1];
  param_1[0xe] = 0xffffffff;
  param_1[0xf] = 0;
  uStack_8 = 1;
  iVar3 = (**(code **)(*param_2 + 0x44))(*param_4);
  if (iVar3 != 0) {
    iVar2 = *(int *)(iVar3 + 0xc);
    iVar4 = thunk_FUN_00897b90();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da)) {
      uVar5 = *(undefined4 *)(iVar3 + 0x18);
      uVar6 = *(undefined4 *)(iVar3 + 0x1c);
      goto LAB_006cd9ac;
    }
  }
  uVar5 = 0xffffffff;
  uVar6 = 0;
LAB_006cd9ac:
  param_1[0xe] = uVar5;
  param_1[0xf] = uVar6;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9123 ; VA 0x006cd9d0 ; FUN_006cd9d0 */

void __fastcall FUN_006cd9d0(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  *param_1 = RBX::Network::SharedQueueItem::vftable;
  iVar1 = param_1[2];
  if (iVar1 != 0) {
    uVar3 = param_1[4] - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[2] = 0;
    param_1[3] = 0;
    param_1[4] = 0;
  }
  return;
}



/* FUNCTION 9124 ; VA 0x006cda30 ; FUN_006cda30 */

undefined4 __thiscall FUN_006cda30(undefined4 param_1,byte param_2)

{
  FUN_006cd9d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 9125 ; VA 0x006cda60 ; FUN_006cda60 */

undefined4 * __thiscall FUN_006cda60(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *param_1 = RBX::Network::SharedReferencePropertyChangedItem::vftable;
  piVar2 = (int *)param_1[0xd];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_006cd9d0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x40);
  }
  return param_1;
}



/* FUNCTION 9126 ; VA 0x006cdac0 ; FUN_006cdac0 */

void __thiscall FUN_006cdac0(int param_1,int *param_2)

{
  (**(code **)(*param_2 + 0xd8))
            (*(undefined4 *)(param_1 + 0x28),*(undefined4 *)(param_1 + 0x30),param_1 + 0x34);
  return;
}



/* FUNCTION 9127 ; VA 0x006cdaf0 ; FUN_006cdaf0 */

int __thiscall FUN_006cdaf0(int param_1,uint param_2)

{
  int iVar1;
  uint uVar2;
  uint3 uVar4;
  uint uVar3;
  int iVar5;
  uint uVar6;
  uint uVar7;
  
  iVar1 = *(int *)(param_1 + 8);
  uVar4 = (uint3)((uint)param_1 >> 8);
  if (iVar1 == *(int *)(param_1 + 0xc)) {
    return (uint)uVar4 << 8;
  }
  if (param_2 == *(uint *)(param_1 + 0x18)) {
    return (uint)uVar4 << 8;
  }
  uVar7 = (*(int *)(param_1 + 0xc) - iVar1 >> 2) - 1;
  uVar3 = (param_2 >> 3) + param_2 & uVar7;
  uVar6 = 0;
  do {
    uVar2 = *(uint *)(iVar1 + uVar3 * 4);
    iVar5 = iVar1 + uVar3 * 4;
    if (uVar2 == param_2) goto LAB_006cdb62;
    if (uVar2 == *(uint *)(param_1 + 0x18)) break;
    uVar3 = uVar3 + 1 + uVar6;
    uVar6 = uVar6 + 1;
    uVar3 = uVar3 & uVar7;
  } while (uVar6 <= uVar7);
  iVar5 = 0;
LAB_006cdb62:
  return CONCAT31((int3)(uVar3 >> 8),iVar5 != 0);
}



/* FUNCTION 9128 ; VA 0x006cdb70 ; FUN_006cdb70 */

void __thiscall FUN_006cdb70(int param_1,undefined4 param_2,undefined4 *param_3)

{
  FUN_006f6920(param_2,*param_3,param_1 + 0x28,param_1 + 0x40);
  return;
}



/* FUNCTION 9129 ; VA 0x006cdb90 ; FUN_006cdb90 */

void __thiscall FUN_006cdb90(int param_1,undefined4 param_2,undefined4 *param_3)

{
  FUN_006f5de0(param_2,*param_3,*(undefined4 *)(param_1 + 0x28),*(undefined4 *)(param_1 + 0x2c),
               param_1 + 0x30);
  return;
}



/* FUNCTION 9130 ; VA 0x006cdbc0 ; FUN_006cdbc0 */

void __thiscall FUN_006cdbc0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  FUN_006f70b0(param_2,*param_3,param_1 + 0x48);
  return;
}



/* FUNCTION 9131 ; VA 0x006cdbe0 ; FUN_006cdbe0 */

undefined4 __thiscall FUN_006cdbe0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  
  if (*(int *)(param_1 + 0x40) == 0) {
    return 1;
  }
  uVar1 = FUN_006f7850(*param_3,param_2,*(undefined4 *)(param_1 + 0x40),
                       *(undefined4 *)(param_1 + 0x28),param_1 + 0x34);
  return uVar1;
}



/* FUNCTION 9132 ; VA 0x006cdc10 ; FUN_006cdc10 */

void __thiscall FUN_006cdc10(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  uVar2 = *(undefined *)(param_1 + 0x44);
  uVar3 = *(undefined4 *)(param_1 + 0x28);
  uVar4 = *param_3;
  if (*(int *)(param_1 + 0x30) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x30) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_006c1e20(param_2,uVar4,uVar3,*(undefined4 *)(param_1 + 0x2c),*(undefined4 *)(param_1 + 0x30),
               param_1 + 0x3c,uVar2,param_1 + 0x34);
  return;
}



/* FUNCTION 9133 ; VA 0x006cdc70 ; FUN_006cdc70 */

void __thiscall FUN_006cdc70(int param_1,undefined4 param_2,undefined4 *param_3)

{
  FUN_006fc8d0(param_2,*param_3,*(undefined4 *)(param_1 + 0x28),*(undefined4 *)(param_1 + 0x2c),
               param_1 + 0x30,param_1 + 0x38);
  return;
}



/* FUNCTION 9134 ; VA 0x006cdca0 ; FUN_006cdca0 */

undefined4 * __thiscall FUN_006cdca0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_018df574;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 9135 ; VA 0x006cddd0 ; FUN_006cddd0 */

void FUN_006cddd0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_006d3380(param_2,param_3);
  return;
}



/* FUNCTION 9136 ; VA 0x006cddf0 ; FUN_006cddf0 */

void FUN_006cddf0(int *param_1,int param_2)

{
  if (*(char *)(*(int *)(*(int *)(*(int *)(*param_1 + 0x130) + 0x1bc) + param_2 * 4) + 0x1db9) ==
      '\0') {
    FUN_006bbee0();
    return;
  }
  return;
}



/* FUNCTION 9137 ; VA 0x006cde30 ; FUN_006cde30 */

void FUN_006cde30(int *param_1,int param_2)

{
  if (*(char *)(*(int *)(*(int *)(*(int *)(*param_1 + 0x130) + 0x1bc) + param_2 * 4) + 0x1db9) ==
      '\0') {
    FUN_006bbd30();
    return;
  }
  return;
}



/* FUNCTION 9138 ; VA 0x006cde70 ; thunk_FUN_00b63e30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b63e30(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5270;
  pvStack_10 = ExceptionList;
  if (DAT_01ef031c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef0530) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ef0530);
      if (DAT_01ef0530 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00e70350();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Model",0,uStack_20,0,0,0x1b,0,&DAT_01ef02e8);
        _DAT_01ef0528 = RBX::Creator<class_RBX::ModelInstance>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ef0320,&DAT_01ef0528);
        FUN_016f3654(FUN_0188e8a0);
        FUN_016f37bf(&DAT_01ef0530);
      }
    }
    DAT_01ef031c = &DAT_01ef0320;
  }
  ExceptionList = pvStack_10;
  return DAT_01ef031c;
}



/* FUNCTION 9139 ; VA 0x006cde80 ; FUN_006cde80 */

int FUN_006cde80(undefined4 param_1,int *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  undefined **ppuVar4;
  undefined **ppuVar5;
  
  iVar3 = FUN_00575bc0();
  piVar2 = param_2;
  param_2 = (int *)0xb;
  *(undefined2 *)(iVar3 + 0xc) = 0;
  puVar1 = (undefined4 *)*piVar2;
  *(undefined4 *)(iVar3 + 0x10) = *puVar1;
  *(undefined4 *)(iVar3 + 0x14) = puVar1[1];
  *(undefined *)(iVar3 + 0x18) = 0;
  ppuVar4 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
  ppuVar5 = ppuVar4 + -1;
  if (ppuVar4 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar5 = ppuVar4;
  }
  *(undefined **)(iVar3 + 0x1c) = *ppuVar5;
  *(undefined4 *)(iVar3 + 0x20) = 0;
  *(undefined4 *)(iVar3 + 0x24) = 0x3f800000;
  *(undefined4 *)(iVar3 + 0x28) = 0;
  *(undefined4 *)(iVar3 + 0x2c) = 0;
  return iVar3;
}



/* FUNCTION 9140 ; VA 0x006cdf00 ; FUN_006cdf00 */

void FUN_006cdf00(undefined4 param_1,int *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = FUN_006d3d00();
  *(undefined2 *)(iVar2 + 0xc) = 0;
  puVar1 = (undefined4 *)*param_2;
  *(undefined4 *)(iVar2 + 0x10) = *puVar1;
  *(undefined4 *)(iVar2 + 0x14) = puVar1[1];
  *(undefined4 *)(iVar2 + 0x18) = 0;
  *(undefined4 *)(iVar2 + 0x1c) = 0;
  *(undefined4 *)(iVar2 + 0x20) = 0;
  return;
}



/* FUNCTION 9141 ; VA 0x006cdf40 ; FUN_006cdf40 */

bool FUN_006cdf40(int *param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  char cVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a8348;
  pvStack_10 = ExceptionList;
  iVar1 = *param_2;
  piVar2 = (int *)param_2[1];
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  param_2[1] = 0;
  iVar8 = *(int *)(iVar1 + 0xc);
  uStack_8 = 0;
  iVar6 = FUN_006193f0(iVar8);
  if (iVar6 != 0) {
    iVar6 = FUN_00aff8c0();
    piVar3 = (int *)*param_1;
    if ((uint)*(ushort *)(iVar6 + 0x1da) <
        (uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) {
      iVar1 = piVar3[1];
      iVar8 = *piVar3;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar6 = piVar2[1] + -1;
        piVar2[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          piVar3 = piVar2 + 2;
          iVar6 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar6 == 1) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return iVar1 - iVar8 >> 2 != 0;
    }
    iVar8 = piVar3[1] - *piVar3 >> 2;
    while (iVar8 = iVar8 + -1, -1 < iVar8) {
      iVar6 = *(int *)(iVar8 * 4 + *(int *)*param_1);
      cVar5 = FUN_00621090(iVar1);
      if (cVar5 != '\0') {
        *(undefined4 *)(*(int *)param_1[1] + 4 + iVar6 * 8) = 2;
        iVar6 = ((int *)*param_1)[1];
        puVar7 = (undefined4 *)(*(int *)*param_1 + iVar8 * 4);
        uVar4 = *puVar7;
        *puVar7 = *(undefined4 *)(iVar6 + -4);
        *(undefined4 *)(iVar6 + -4) = uVar4;
        *(int *)(*param_1 + 4) = *(int *)(*param_1 + 4) + -4;
      }
    }
  }
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar1 = piVar2[1] + -1;
    piVar2[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar3 = piVar2 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return false;
}



/* FUNCTION 9142 ; VA 0x006ce0c0 ; FUN_006ce0c0 */

void FUN_006ce0c0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != param_2) {
    iVar2 = param_1 + 0x60;
    do {
      LOCK();
      iVar1 = *(int *)(iVar2 + 0x2c);
      *(int *)(iVar2 + 0x2c) = 0;
      UNLOCK();
      if (iVar1 != 0) {
        CloseHandle(iVar1);
      }
      FUN_00613200();
      iVar1 = iVar2 + 0x30;
      iVar2 = iVar2 + 0x90;
    } while (iVar1 != param_2);
  }
  return;
}



/* FUNCTION 9143 ; VA 0x006ce110 ; FUN_006ce110 */

void FUN_006ce110(uint *param_1,uint *param_2)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    do {
      uVar1 = *param_1;
      uStack_8 = 0;
      if (uVar1 != 0) {
        if (((uVar1 & 1) == 0) && (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(uVar1 & 0xfffffffe))(param_1 + 2,param_1 + 2,2);
        }
        *param_1 = 0;
      }
      param_1 = param_1 + 8;
    } while (param_1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9144 ; VA 0x006ce180 ; FUN_006ce180 */

int __thiscall
FUN_006ce180(uint *param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8360;
  pvStack_10 = ExceptionList;
  uVar1 = *param_1;
  iVar3 = (int)(param_1[1] - uVar1) / 0x90;
  if (iVar3 == 0x1c71c71) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar7 = iVar3 + 1;
  uVar5 = (int)(param_1[2] - uVar1) / 0x90;
  uVar8 = uVar7;
  if ((uVar5 <= 0x1c71c71 - (uVar5 >> 1)) && (uVar8 = (uVar5 >> 1) + uVar5, uVar8 < uVar7)) {
    uVar8 = uVar7;
  }
  uVar5 = uVar8 * 0x90;
  if (uVar8 < 0x1c71c72) {
    uVar8 = uVar5;
    if (0xfff < uVar5) goto LAB_006ce23b;
    if (uVar5 == 0) {
      uVar8 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar8 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_006ce23b:
    uVar2 = uVar8 + 0x23;
    if (uVar2 <= uVar8) {
      uVar2 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_006ce38d;
    uVar8 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar8 - 4) = iVar3;
  }
  uStack_8 = 0;
  iVar3 = ((int)(param_2 - uVar1) / 0x90) * 0x90;
  iVar4 = iVar3 + uVar8;
  FUN_006cfe30(param_1,iVar4,param_3,param_4,param_5);
  if (param_2 == param_1[1]) {
    FUN_006cf960(*param_1,param_1[1],uVar8,param_1);
  }
  else {
    FUN_006cf960(*param_1,param_2,uVar8,param_1);
    FUN_006cf960(param_2,param_1[1],iVar4 + 0x90,param_1);
  }
  if (*param_1 != 0) {
    FUN_006ce0c0(*param_1,param_1[1],param_1);
    uVar1 = *param_1;
    uVar6 = ((int)(param_1[2] - uVar1) / 0x90) * 0x90;
    uVar2 = uVar1;
    if (0xfff < uVar6) {
      uVar2 = *(uint *)(uVar1 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar1 - uVar2) - 4) {
LAB_006ce38d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar6);
  }
  *param_1 = uVar8;
  param_1[1] = uVar7 * 0x90 + uVar8;
  param_1[2] = uVar5 + uVar8;
  ExceptionList = pvStack_10;
  return *param_1 + iVar3;
}



/* FUNCTION 9145 ; VA 0x006ce364 ; Catch_All@006ce364 */

void Catch_All_006ce364(void)

{
  int unaff_EBP;
  
  FUN_006d3df0(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x18));
  FUN_006d67a0(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9146 ; VA 0x006ce3a0 ; FUN_006ce3a0 */

int __thiscall FUN_006ce3a0(int *param_1,undefined8 *param_2,undefined4 *param_3)

{
  int iVar1;
  uint uVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  int iVar6;
  undefined8 *puVar7;
  uint uVar8;
  undefined8 *puVar9;
  
  iVar6 = *param_1;
  iVar1 = (param_1[1] - *param_1) / 0xc;
  if (iVar1 == 0x15555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar2 = (param_1[2] - *param_1) / 0xc;
  uVar8 = iVar1 + 1;
  if (uVar2 <= 0x15555555 - (uVar2 >> 1)) {
    uVar8 = (uVar2 >> 1) + uVar2;
    if (uVar8 < iVar1 + 1U) {
      uVar8 = iVar1 + 1U;
    }
  }
  puVar3 = (undefined8 *)FUN_00618050(uVar8);
  iVar6 = (((int)param_2 - iVar6) / 0xc) * 0xc;
  puVar4 = (undefined8 *)((int)puVar3 + iVar6);
  *(undefined4 *)puVar4 = *param_3;
  *(undefined4 *)((int)puVar4 + 4) = param_3[1];
  *(undefined4 *)(puVar4 + 1) = param_3[2];
  puVar9 = (undefined8 *)param_1[1];
  puVar5 = (undefined8 *)*param_1;
  puVar7 = puVar3;
  if (param_2 == puVar9) {
    for (; puVar5 != puVar9; puVar5 = (undefined8 *)((int)puVar5 + 0xc)) {
      *puVar7 = *puVar5;
      *(undefined4 *)(puVar7 + 1) = *(undefined4 *)(puVar5 + 1);
      puVar7 = (undefined8 *)((int)puVar7 + 0xc);
    }
  }
  else {
    if (puVar5 != param_2) {
      do {
        *puVar7 = *puVar5;
        puVar9 = puVar5 + 1;
        puVar5 = (undefined8 *)((int)puVar5 + 0xc);
        *(undefined4 *)(puVar7 + 1) = *(undefined4 *)puVar9;
        puVar7 = (undefined8 *)((int)puVar7 + 0xc);
      } while (puVar5 != param_2);
      puVar9 = (undefined8 *)param_1[1];
    }
    if (param_2 != puVar9) {
      do {
        *(undefined8 *)((int)puVar4 + 0xc) = *param_2;
        puVar5 = param_2 + 1;
        param_2 = (undefined8 *)((int)param_2 + 0xc);
        *(undefined4 *)((int)puVar4 + 0x14) = *(undefined4 *)puVar5;
        puVar4 = (undefined8 *)((int)puVar4 + 0xc);
      } while (param_2 != puVar9);
    }
  }
  FUN_006bf950(puVar3,iVar1 + 1,uVar8);
  return *param_1 + iVar6;
}



/* FUNCTION 9147 ; VA 0x006ce4f0 ; FUN_006ce4f0 */

int __thiscall FUN_006ce4f0(int *param_1,uint *param_2,undefined4 param_3)

{
  uint uVar1;
  int iVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint *puVar10;
  uint *puVar11;
  uint *puVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8378;
  pvStack_10 = ExceptionList;
  iVar2 = *param_1;
  iVar5 = (int)param_2 - iVar2 >> 5;
  iVar6 = param_1[1] - iVar2 >> 5;
  if (iVar6 == 0x7ffffff) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar6 + 1;
  uVar9 = param_1[2] - iVar2 >> 5;
  uVar7 = uVar1;
  if ((uVar9 <= 0x7ffffff - (uVar9 >> 1)) && (uVar7 = (uVar9 >> 1) + uVar9, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  uVar9 = uVar7 << 5;
  if (uVar7 < 0x8000000) {
    if (0xfff < uVar9) goto LAB_006ce581;
    if (uVar9 == 0) {
      puVar11 = (uint *)0x0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      puVar11 = (uint *)FUN_01674e20(uVar9);
    }
  }
  else {
    uVar9 = 0xffffffff;
LAB_006ce581:
    uVar8 = uVar9 + 0x23;
    if (uVar8 <= uVar9) {
      uVar8 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    uVar9 = FUN_01674e20(uVar8);
    if (uVar9 == 0) goto LAB_006ce746;
    puVar11 = (uint *)(uVar9 + 0x23 & 0xffffffe0);
    puVar11[-1] = uVar9;
  }
  uStack_8 = 0;
  FUN_006cff00(param_1,puVar11 + iVar5 * 8,param_3);
  puVar3 = (uint *)param_1[1];
  if (param_2 == puVar3) {
    puVar12 = (uint *)*param_1;
    uStack_8._0_1_ = 1;
    puVar10 = puVar11;
    while (puVar12 != puVar3) {
      *puVar10 = 0;
      uVar9 = *puVar12;
      if (uVar9 == 0) {
LAB_006ce65f:
        puVar10 = puVar10 + 8;
        puVar12 = puVar12 + 8;
      }
      else {
        *puVar10 = uVar9;
        if ((uVar9 & 1) == 0) {
          (**(code **)(uVar9 & 0xfffffffe))(puVar12 + 2,puVar10 + 2,0);
          goto LAB_006ce65f;
        }
        uVar9 = puVar12[3];
        uVar8 = puVar12[4];
        uVar4 = puVar12[5];
        puVar10[2] = puVar12[2];
        puVar10[3] = uVar9;
        puVar10[4] = uVar8;
        puVar10[5] = uVar4;
        uVar9 = puVar12[7];
        puVar10[6] = puVar12[6];
        puVar10[7] = uVar9;
        puVar10 = puVar10 + 8;
        puVar12 = puVar12 + 8;
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_006ce110(puVar10,puVar10,param_1);
  }
  else {
    FUN_006d4080(*param_1,param_2,puVar11);
    FUN_006d4080(param_2,param_1[1],puVar11 + iVar5 * 8 + 8);
  }
  uStack_8 = 0xffffffff;
  if (*param_1 != 0) {
    FUN_006ce110(*param_1,param_1[1],param_1);
    iVar2 = *param_1;
    uVar9 = param_1[2] - iVar2 & 0xffffffe0;
    iVar6 = iVar2;
    if (0xfff < uVar9) {
      iVar6 = *(int *)(iVar2 + -4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (iVar2 - iVar6) - 4U) {
LAB_006ce746:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar9);
  }
  *param_1 = (int)puVar11;
  param_1[1] = (int)(puVar11 + uVar1 * 8);
  param_1[2] = (int)(puVar11 + uVar7 * 8);
  ExceptionList = pvStack_10;
  return *param_1 + iVar5 * 0x20;
}



/* FUNCTION 9148 ; VA 0x006ce71c ; Catch_All@006ce71c */

void Catch_All_006ce71c(void)

{
  int unaff_EBP;
  
  FUN_006d3e10(*(undefined4 *)(unaff_EBP + 0xc),*(undefined4 *)(unaff_EBP + -0x24));
  FUN_0057d2b0(*(undefined4 *)(unaff_EBP + -0x30),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9149 ; VA 0x006ce750 ; FUN_006ce750 */

int __thiscall FUN_006ce750(uint *param_1,uint param_2,undefined4 *param_3)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  
  uVar9 = *param_1;
  iVar4 = (int)(param_1[1] - uVar9) >> 3;
  if (iVar4 == 0x1fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar4 + 1;
  uVar6 = (int)(param_1[2] - uVar9) >> 3;
  uVar8 = uVar1;
  if ((uVar6 <= 0x1fffffff - (uVar6 >> 1)) && (uVar8 = (uVar6 >> 1) + uVar6, uVar8 < uVar1)) {
    uVar8 = uVar1;
  }
  uVar6 = uVar8 * 8;
  if (uVar8 < 0x20000000) {
    uVar8 = uVar6;
    if (0xfff < uVar6) goto LAB_006ce7c1;
    if (uVar6 == 0) {
      uVar8 = 0;
    }
    else {
      uVar8 = FUN_01674e20(uVar6);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_006ce7c1:
    uVar5 = uVar8 + 0x23;
    if (uVar5 <= uVar8) {
      uVar5 = 0xffffffff;
    }
    iVar4 = FUN_01674e20(uVar5);
    if (iVar4 == 0) goto LAB_006ce8e3;
    uVar8 = iVar4 + 0x23U & 0xffffffe0;
    *(int *)(uVar8 - 4) = iVar4;
  }
  iVar4 = ((int)(param_2 - uVar9) >> 3) * 8;
  *(undefined4 *)(iVar4 + uVar8) = 0;
  *(undefined4 *)(iVar4 + 4 + uVar8) = 0;
  *(undefined4 *)(iVar4 + uVar8) = *param_3;
  *(undefined4 *)(iVar4 + 4 + uVar8) = param_3[1];
  *param_3 = 0;
  param_3[1] = 0;
  uVar9 = *param_1;
  uVar5 = param_1[1];
  uVar7 = uVar8;
  if (param_2 != uVar5) {
    FUN_006cfaf0(uVar9,param_2,uVar8,param_1);
    uVar5 = param_1[1];
    uVar7 = iVar4 + 8 + uVar8;
    uVar9 = param_2;
  }
  FUN_006cfaf0(uVar9,uVar5,uVar7,param_1);
  uVar9 = *param_1;
  if (uVar9 != 0) {
    uVar5 = param_1[1];
    if (uVar9 != uVar5) {
      do {
        piVar2 = *(int **)(uVar9 + 4);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[2] + -1;
          piVar2[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        uVar9 = uVar9 + 8;
      } while (uVar9 != uVar5);
      uVar9 = *param_1;
    }
    uVar7 = param_1[2] - uVar9 & 0xfffffff8;
    uVar5 = uVar9;
    if (0xfff < uVar7) {
      uVar5 = *(uint *)(uVar9 - 4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (uVar9 - uVar5) - 4) {
LAB_006ce8e3:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar7);
  }
  *param_1 = uVar8;
  param_1[1] = uVar8 + uVar1 * 8;
  param_1[2] = uVar6 + uVar8;
  return *param_1 + iVar4;
}



/* FUNCTION 9150 ; VA 0x006ce8f0 ; FUN_006ce8f0 */

void __thiscall
FUN_006ce8f0(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x5555553 < (uint)param_1[1]) {
    FUN_006d3e30(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_006ce9a2:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_006ce9a2;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 9151 ; VA 0x006cea50 ; FUN_006cea50 */

void __thiscall
FUN_006cea50(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x71c71c5 < (uint)param_1[1]) {
    FUN_006d3e50(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_006ceb02:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_006ceb02;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 9152 ; VA 0x006cebb0 ; FUN_006cebb0 */

undefined4 * __thiscall
FUN_006cebb0(int *param_1,undefined4 *param_2,int *param_3,undefined4 param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a8390;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    param_3 = (int *)*param_1;
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
  }
  else {
    if (param_3 != *(int **)*param_1) {
      if (param_3 != (int *)*param_1) {
        ExceptionList = &pvStack_10;
        cVar1 = FUN_009c8f70(param_3 + 4);
        if (cVar1 != '\0') {
          piStack_18 = param_3;
          FUN_0056f560();
          cVar1 = FUN_009c8f70(param_4);
          if (cVar1 != '\0') {
            if (*(char *)(piStack_18[2] + 0xd) == '\0') {
              uVar4 = 1;
              param_3 = param_3;
            }
            else {
              uVar4 = 0;
              param_3 = piStack_18;
            }
            goto LAB_006cebf9;
          }
        }
        cVar1 = FUN_009c8f70(param_4);
        if (cVar1 != '\0') {
          piStack_18 = param_3;
          piVar2 = (int *)FUN_00551320();
          if ((*piVar2 == *param_1) || (cVar1 = FUN_009c8f70(piStack_18 + 4), cVar1 != '\0')) {
            if (*(char *)(param_3[2] + 0xd) == '\0') {
              uVar4 = 1;
              param_3 = piStack_18;
            }
            else {
              uVar4 = 0;
              param_3 = param_3;
            }
            goto LAB_006cebf9;
          }
        }
LAB_006ced0a:
        uStack_8 = 0xffffffff;
        puVar3 = (undefined4 *)FUN_006cef10(auStack_20,0,param_4,param_5);
        *param_2 = *puVar3;
        ExceptionList = pvStack_10;
        return param_2;
      }
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      cVar1 = FUN_009c8f70(param_4);
      if (cVar1 == '\0') goto LAB_006ced0a;
      param_3 = *(int **)(*param_1 + 8);
      uVar4 = 0;
      goto LAB_006cebf9;
    }
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar1 = FUN_009c8f70(param_3 + 4);
    if (cVar1 == '\0') goto LAB_006ced0a;
  }
  uVar4 = 1;
LAB_006cebf9:
  FUN_006ce8f0(param_2,uVar4,param_3,param_4,param_5);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9153 ; VA 0x006ced3c ; Catch_All@006ced3c */

void Catch_All_006ced3c(void)

{
  int unaff_EBP;
  
  FUN_006d3e30(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9154 ; VA 0x006ced60 ; FUN_006ced60 */

undefined4 * __thiscall
FUN_006ced60(int *param_1,undefined4 *param_2,int *param_3,undefined4 param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a83a0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    param_3 = (int *)*param_1;
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
  }
  else {
    if (param_3 != *(int **)*param_1) {
      if (param_3 != (int *)*param_1) {
        ExceptionList = &pvStack_10;
        cVar1 = FUN_009c8f70(param_3 + 4);
        if (cVar1 != '\0') {
          piStack_18 = param_3;
          FUN_0056f560();
          cVar1 = FUN_009c8f70(param_4);
          if (cVar1 != '\0') {
            if (*(char *)(piStack_18[2] + 0xd) == '\0') {
              uVar4 = 1;
              param_3 = param_3;
            }
            else {
              uVar4 = 0;
              param_3 = piStack_18;
            }
            goto LAB_006ceda9;
          }
        }
        cVar1 = FUN_009c8f70(param_4);
        if (cVar1 != '\0') {
          piStack_18 = param_3;
          piVar2 = (int *)FUN_00551320();
          if ((*piVar2 == *param_1) || (cVar1 = FUN_009c8f70(piStack_18 + 4), cVar1 != '\0')) {
            if (*(char *)(param_3[2] + 0xd) == '\0') {
              uVar4 = 1;
              param_3 = piStack_18;
            }
            else {
              uVar4 = 0;
              param_3 = param_3;
            }
            goto LAB_006ceda9;
          }
        }
LAB_006ceeba:
        uStack_8 = 0xffffffff;
        puVar3 = (undefined4 *)FUN_006cf030(auStack_20,0,param_4,param_5);
        *param_2 = *puVar3;
        ExceptionList = pvStack_10;
        return param_2;
      }
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      cVar1 = FUN_009c8f70(param_4);
      if (cVar1 == '\0') goto LAB_006ceeba;
      param_3 = *(int **)(*param_1 + 8);
      uVar4 = 0;
      goto LAB_006ceda9;
    }
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar1 = FUN_009c8f70(param_3 + 4);
    if (cVar1 == '\0') goto LAB_006ceeba;
  }
  uVar4 = 1;
LAB_006ceda9:
  FUN_006cea50(param_2,uVar4,param_3,param_4,param_5);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9155 ; VA 0x006ceeec ; Catch_All@006ceeec */

void Catch_All_006ceeec(void)

{
  int unaff_EBP;
  
  FUN_006d3e50(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9156 ; VA 0x006cef10 ; FUN_006cef10 */

void __thiscall
FUN_006cef10(int *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = param_4;
  puStack_c = &LAB_017a83b0;
  pvStack_10 = ExceptionList;
  cVar3 = '\x01';
  uStack_8 = 0;
  puVar5 = (undefined4 *)((undefined4 *)*param_1)[1];
  puVar6 = (undefined4 *)*param_1;
  ExceptionList = &pvStack_10;
  while (*(char *)((int)puVar5 + 0xd) == '\0') {
    if ((char)param_3 == '\0') {
      cVar3 = FUN_009c8f70(puVar5 + 4);
    }
    else {
      cVar3 = FUN_009c8f70(uVar1);
      cVar3 = cVar3 == '\0';
    }
    puVar6 = puVar5;
    if (cVar3 == '\0') {
      puVar5 = (undefined4 *)puVar5[2];
    }
    else {
      puVar5 = (undefined4 *)*puVar5;
    }
  }
  param_3 = puVar6;
  if (cVar3 != '\0') {
    if (puVar6 == *(undefined4 **)*param_1) {
      cVar3 = '\x01';
      goto LAB_006cef9a;
    }
    FUN_0056f560();
  }
  puVar5 = param_3;
  cVar4 = FUN_009c8f70(uVar1);
  uVar2 = param_5;
  if (cVar4 == '\0') {
    FUN_0061ac80();
    FUN_01674ea0(uVar2,0x30);
    *param_2 = puVar5;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_006cef9a:
  puVar5 = (undefined4 *)FUN_006ce8f0(&param_3,cVar3,puVar6,uVar1,param_5);
  *param_2 = *puVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9157 ; VA 0x006cf018 ; Catch_All@006cf018 */

void Catch_All_006cf018(void)

{
  int unaff_EBP;
  
  FUN_006d3e30(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9158 ; VA 0x006cf030 ; FUN_006cf030 */

void __thiscall
FUN_006cf030(int *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = param_4;
  puStack_c = &LAB_017a83c0;
  pvStack_10 = ExceptionList;
  cVar3 = '\x01';
  uStack_8 = 0;
  puVar5 = (undefined4 *)((undefined4 *)*param_1)[1];
  puVar6 = (undefined4 *)*param_1;
  ExceptionList = &pvStack_10;
  while (*(char *)((int)puVar5 + 0xd) == '\0') {
    if ((char)param_3 == '\0') {
      cVar3 = FUN_009c8f70(puVar5 + 4);
    }
    else {
      cVar3 = FUN_009c8f70(uVar1);
      cVar3 = cVar3 == '\0';
    }
    puVar6 = puVar5;
    if (cVar3 == '\0') {
      puVar5 = (undefined4 *)puVar5[2];
    }
    else {
      puVar5 = (undefined4 *)*puVar5;
    }
  }
  param_3 = puVar6;
  if (cVar3 != '\0') {
    if (puVar6 == *(undefined4 **)*param_1) {
      cVar3 = '\x01';
      goto LAB_006cf0ba;
    }
    FUN_0056f560();
  }
  puVar5 = param_3;
  cVar4 = FUN_009c8f70(uVar1);
  uVar2 = param_5;
  if (cVar4 == '\0') {
    thunk_FUN_00617ad0();
    FUN_01674ea0(uVar2,0x24);
    *param_2 = puVar5;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_006cf0ba:
  puVar5 = (undefined4 *)FUN_006cea50(&param_3,cVar3,puVar6,uVar1,param_5);
  *param_2 = *puVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9159 ; VA 0x006cf138 ; Catch_All@006cf138 */

void Catch_All_006cf138(void)

{
  int unaff_EBP;
  
  FUN_006d3e50(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9160 ; VA 0x006cf150 ; FUN_006cf150 */

void __thiscall FUN_006cf150(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  
  uVar5 = param_1[1];
  uVar3 = (int)(uVar5 - *param_1) / 0xc;
  uVar4 = (int)(param_1[2] - *param_1) / 0xc;
  if (param_2 <= uVar4) {
    if (uVar3 < param_2) {
      uVar5 = FUN_006d3350(uVar5,param_2 - uVar3);
      param_1[1] = uVar5;
      return;
    }
    if (param_2 != uVar3) {
      uVar3 = *param_1 + param_2 * 0xc;
      for (uVar4 = uVar3; uVar4 != uVar5; uVar4 = uVar4 + 0xc) {
        FUN_005e6280();
      }
      param_1[1] = uVar3;
    }
    return;
  }
  if (0x15555555 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar5 = param_2;
  if ((uVar4 <= 0x15555555 - (uVar4 >> 1)) && (uVar5 = uVar4 + (uVar4 >> 1), uVar5 < param_2)) {
    uVar5 = param_2;
  }
  uVar4 = uVar5 * 0xc;
  if (uVar5 < 0x15555556) {
    uVar5 = uVar4;
    if (0xfff < uVar4) goto LAB_006cf1e2;
    if (uVar4 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_01674e20(uVar4);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_006cf1e2:
    uVar1 = uVar5 + 0x23;
    if (uVar1 <= uVar5) {
      uVar1 = 0xffffffff;
    }
    iVar2 = FUN_01674e20(uVar1);
    if (iVar2 == 0) goto LAB_006cf363;
    uVar5 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar5 - 4) = iVar2;
  }
  FUN_006d3350(uVar5 + uVar3 * 0xc,param_2 - uVar3);
  puVar8 = (undefined4 *)param_1[1];
  puVar7 = (undefined4 *)*param_1;
  if (puVar7 != puVar8) {
    puVar6 = (undefined4 *)(uVar5 + 8);
    do {
      puVar6[-2] = 0;
      puVar6[-1] = 0;
      *puVar6 = 0;
      puVar6[-2] = *puVar7;
      puVar6[-1] = puVar7[1];
      *puVar6 = puVar7[2];
      *puVar7 = 0;
      puVar7[1] = 0;
      puVar7[2] = 0;
      puVar7 = puVar7 + 3;
      puVar6 = puVar6 + 3;
    } while (puVar7 != puVar8);
    puVar7 = (undefined4 *)*param_1;
  }
  if (puVar7 != (undefined4 *)0x0) {
    puVar8 = (undefined4 *)param_1[1];
    if (puVar7 != puVar8) {
      do {
        FUN_005e6280();
        puVar7 = puVar7 + 3;
      } while (puVar7 != puVar8);
      puVar7 = (undefined4 *)*param_1;
    }
    uVar3 = ((int)(param_1[2] - (int)puVar7) / 0xc) * 0xc;
    puVar8 = puVar7;
    if (0xfff < uVar3) {
      puVar8 = (undefined4 *)puVar7[-1];
      uVar3 = uVar3 + 0x23;
      if (0x1f < (uint)((int)puVar7 + (-4 - (int)puVar8))) {
LAB_006cf363:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar8,uVar3);
  }
  *param_1 = uVar5;
  param_1[1] = uVar5 + param_2 * 0xc;
  param_1[2] = uVar4 + uVar5;
  return;
}



/* FUNCTION 9161 ; VA 0x006cf370 ; FUN_006cf370 */

void __thiscall FUN_006cf370(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  undefined8 *puVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint uVar7;
  uint uVar8;
  
  puVar3 = (undefined8 *)param_1[1];
  uVar8 = *param_1;
  uVar4 = (int)((int)puVar3 - uVar8) >> 3;
  uVar7 = (int)(param_1[2] - uVar8) >> 3;
  if (param_2 <= uVar7) {
    if (uVar4 < param_2) {
      iVar2 = param_2 - uVar4;
      if (iVar2 != 0) {
        do {
          *puVar3 = 0;
          *(undefined4 *)((int)puVar3 + 4) = 1;
          puVar3 = puVar3 + 1;
          iVar2 = iVar2 + -1;
        } while (iVar2 != 0);
        param_1[1] = (uint)puVar3;
        return;
      }
    }
    else {
      if (param_2 == uVar4) {
        return;
      }
      puVar3 = (undefined8 *)(uVar8 + param_2 * 8);
    }
    param_1[1] = (uint)puVar3;
    return;
  }
  if (0x1fffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar8 = param_2;
  if ((uVar7 <= 0x1fffffff - (uVar7 >> 1)) && (uVar8 = (uVar7 >> 1) + uVar7, uVar8 < param_2)) {
    uVar8 = param_2;
  }
  uVar7 = uVar8 * 8;
  if (uVar8 < 0x20000000) {
    uVar8 = uVar7;
    if (0xfff < uVar7) goto LAB_006cf3e2;
    if (uVar7 == 0) {
      uVar8 = 0;
    }
    else {
      uVar8 = FUN_01674e20(uVar7);
    }
  }
  else {
    uVar8 = 0xffffffff;
LAB_006cf3e2:
    uVar1 = uVar8 + 0x23;
    if (uVar1 <= uVar8) {
      uVar1 = 0xffffffff;
    }
    iVar2 = FUN_01674e20(uVar1);
    if (iVar2 == 0) goto LAB_006cf508;
    uVar8 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar8 - 4) = iVar2;
  }
  puVar3 = (undefined8 *)(uVar8 + uVar4 * 8);
  for (iVar2 = param_2 - uVar4; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar3 = 0;
    *(undefined4 *)((int)puVar3 + 4) = 1;
    puVar3 = puVar3 + 1;
  }
  puVar5 = (undefined4 *)*param_1;
  puVar6 = (undefined4 *)param_1[1];
  if (puVar5 != puVar6) {
    iVar2 = uVar8 - (int)puVar5;
    do {
      *(undefined4 *)((int)puVar5 + iVar2) = *puVar5;
      *(undefined4 *)((int)puVar5 + iVar2 + 4) = puVar5[1];
      puVar5 = puVar5 + 2;
    } while (puVar5 != puVar6);
    puVar5 = (undefined4 *)*param_1;
  }
  if (puVar5 != (undefined4 *)0x0) {
    uVar4 = param_1[2] - (int)puVar5 & 0xfffffff8;
    puVar6 = puVar5;
    if (0xfff < uVar4) {
      puVar6 = (undefined4 *)puVar5[-1];
      uVar4 = uVar4 + 0x23;
      if (0x1f < (uint)((int)puVar5 + (-4 - (int)puVar6))) {
LAB_006cf508:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar6,uVar4);
  }
  *param_1 = uVar8;
  param_1[1] = uVar8 + param_2 * 8;
  param_1[2] = uVar7 + uVar8;
  return;
}



/* FUNCTION 9162 ; VA 0x006cf510 ; FUN_006cf510 */

void __thiscall FUN_006cf510(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a83d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<struct_RBX::Network::CachedBitstream>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9163 ; VA 0x006cf57e ; Catch_All@006cf57e */

void Catch_All_006cf57e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_006d37b0(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9164 ; VA 0x006cf5a0 ; FUN_006cf5a0 */

int __thiscall FUN_006cf5a0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a83e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::Network::ModelCompletenessJob>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9165 ; VA 0x006cf674 ; Catch_All@006cf674 */

void Catch_All_006cf674(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9166 ; VA 0x006cf690 ; FUN_006cf690 */

int __thiscall FUN_006cf690(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a83f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::Network::NetworkPhysicsParallelReceiveJob>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9167 ; VA 0x006cf764 ; Catch_All@006cf764 */

void Catch_All_006cf764(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9168 ; VA 0x006cf780 ; FUN_006cf780 */

int __thiscall FUN_006cf780(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a8400;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::Network::NetworkSendDataMegaJob>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9169 ; VA 0x006cf854 ; Catch_All@006cf854 */

void Catch_All_006cf854(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9170 ; VA 0x006cf870 ; FUN_006cf870 */

int __thiscall FUN_006cf870(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a8410;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::Network::NetworkSenderScheduleJob>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9171 ; VA 0x006cf944 ; Catch_All@006cf944 */

void Catch_All_006cf944(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9172 ; VA 0x006cf960 ; FUN_006cf960 */

undefined4 *
FUN_006cf960(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  
  puVar8 = param_3;
  if (param_1 != param_2) {
    puVar6 = param_3 + 0x1d;
    puVar7 = param_1 + 0x1c;
    do {
      *puVar8 = puVar7[-0x1c];
      puVar6[-0x1c] = puVar7[-0x1b];
      uVar3 = puVar7[-0x19];
      uVar4 = puVar7[-0x18];
      uVar5 = puVar7[-0x17];
      puVar6[-0x1b] = puVar7[-0x1a];
      puVar6[-0x1a] = uVar3;
      puVar6[-0x19] = uVar4;
      puVar6[-0x18] = uVar5;
      uVar3 = puVar7[-0x15];
      uVar4 = puVar7[-0x14];
      uVar5 = puVar7[-0x13];
      puVar6[-0x17] = puVar7[-0x16];
      puVar6[-0x16] = uVar3;
      puVar6[-0x15] = uVar4;
      puVar6[-0x14] = uVar5;
      uVar3 = puVar7[-0x11];
      uVar4 = puVar7[-0x10];
      uVar5 = puVar7[-0xf];
      puVar6[-0x13] = puVar7[-0x12];
      puVar6[-0x12] = uVar3;
      puVar6[-0x11] = uVar4;
      puVar6[-0x10] = uVar5;
      *(undefined8 *)(puVar6 + -0xf) = *(undefined8 *)(puVar7 + -0xe);
      puVar6[-0xd] = puVar7[-0xc];
      *(undefined8 *)(puVar6 + -0xc) = *(undefined8 *)(puVar7 + -0xb);
      puVar6[-10] = puVar7[-9];
      puVar6[-9] = puVar7[-8];
      *(undefined *)(puVar6 + -8) = *(undefined *)(puVar7 + -7);
      *(undefined *)((int)puVar6 + -0x1f) = *(undefined *)((int)puVar7 + -0x1b);
      *(undefined *)((int)puVar6 + -0x1e) = *(undefined *)((int)puVar7 + -0x1a);
      *(undefined *)((int)puVar6 + -0x1d) = *(undefined *)((int)puVar7 + -0x19);
      puVar6[-7] = puVar7[-6];
      puVar6[-6] = puVar7[-5];
      puVar6[-5] = RakNet::AbstractBitStream::vftable;
      puVar2 = puVar6 + 0x24;
      puVar8 = puVar8 + 0x24;
      *(undefined *)(puVar6 + -4) = *(undefined *)(puVar7 + -3);
      puVar6[-5] = RBX::Network::NetworkStream::vftable;
      puVar6[-3] = puVar7[-2];
      puVar6[-2] = 0;
      puVar6[-1] = 0;
      *puVar6 = 0;
      puVar6[-2] = puVar7[-1];
      puVar6[-1] = *puVar7;
      *puVar6 = *(undefined4 *)((int)param_1 + (-0x90 - (int)param_3) + (int)puVar2);
      puVar7[-1] = 0;
      *puVar7 = 0;
      *(undefined4 *)((int)param_1 + (-0x90 - (int)param_3) + (int)puVar2) = 0;
      puVar6[1] = puVar7[2];
      puVar6[2] = puVar7[3];
      puVar6[3] = puVar7[4];
      *(undefined *)(puVar6 + 4) = *(undefined *)(puVar7 + 5);
      puVar1 = puVar7 + 8;
      puVar6[5] = 0;
      puVar6[6] = 0;
      puVar6 = puVar2;
      puVar7 = puVar7 + 0x24;
    } while (puVar1 != param_2);
  }
  FUN_006ce0c0(puVar8,puVar8,param_4);
  return puVar8;
}



/* FUNCTION 9173 ; VA 0x006cfaf0 ; FUN_006cfaf0 */

void FUN_006cfaf0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  puVar1 = param_3;
  puVar2 = param_1;
  if (param_1 != param_2) {
    do {
      *puVar1 = 0;
      puVar1[1] = 0;
      *puVar1 = *puVar2;
      puVar1[1] = *(undefined4 *)((int)param_1 + (4 - (int)param_3) + (int)puVar1);
      *puVar2 = 0;
      puVar2 = puVar2 + 2;
      *(undefined4 *)((int)param_1 + (4 - (int)param_3) + (int)puVar1) = 0;
      puVar1 = puVar1 + 2;
    } while (puVar2 != param_2);
  }
  return;
}



/* FUNCTION 9174 ; VA 0x006cfb50 ; FUN_006cfb50 */

void __thiscall FUN_006cfb50(int param_1,int param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  undefined8 uVar7;
  int *piStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8444;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaf1f8) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01eaf1f8), DAT_01eaf1f8 == -1)) {
    uStack_8 = 0;
    uVar7 = FUN_0152dab0("TaskQueue","addTasks",0xffffffff);
    DAT_01eaf1f4 = (undefined4)((ulonglong)uVar7 >> 0x20);
    DAT_01eaf1f0 = (undefined4)uVar7;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01eaf1f8);
  }
  uVar4 = DAT_01eaf1f4;
  uVar3 = DAT_01eaf1f0;
  uVar7 = FUN_0152d930(DAT_01eaf1f0,DAT_01eaf1f4);
  iVar1 = param_1 + 0x20;
  uStack_8 = 1;
  iVar5 = FUN_016dee6d(iVar1);
  if (iVar5 != 0) {
    FUN_016df3c9(iVar5);
  }
  piStack_20 = (int *)CONCAT31(piStack_20._1_3_,1);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  LOCK();
  *(int *)(param_1 + 0x78) = *(int *)(param_1 + 0x78) + (param_3 - param_2 >> 5);
  UNLOCK();
  uVar6 = *(int *)(param_1 + 0xa4) + (param_3 - param_2 >> 5);
  if (*(uint *)(param_1 + 0x9c) < uVar6) {
    FUN_006cb080(uVar6);
  }
  if (param_2 != param_3) {
    do {
      *(undefined4 *)
       (((uint)(*(int *)(param_1 + 0xa4) + *(int *)(param_1 + 0xa0)) % *(uint *)(param_1 + 0x9c)) *
        0x20 + *(int *)(param_1 + 0xa8)) = 0;
      FUN_005880d0(param_2);
      *(int *)(param_1 + 0xa4) = *(int *)(param_1 + 0xa4) + 1;
      param_2 = param_2 + 0x20;
    } while (param_2 != param_3);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  iVar5 = FUN_016deec8(iVar1);
  if (iVar5 != 0) {
    FUN_016df3c9(iVar5);
  }
  uStack_8._0_1_ = 1;
  if (*(char *)(param_1 + 0x18) != '\0') {
    FUN_006022f0(param_1);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piStack_20[1] = piStack_20[1] + 1;
      UNLOCK();
    }
    FUN_0151dbc0(iVar1,piStack_20);
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_20[1] + -1;
      piStack_20[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar2 = piStack_20 + 2;
        iVar1 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
  }
  uStack_8 = 5;
  FUN_0152dda0(uVar3,uVar4,uVar7);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9175 ; VA 0x006cfd60 ; FUN_006cfd60 */

undefined4 * __thiscall FUN_006cfd60(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c3f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  puVar2 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 1;
    puVar2[2] = FUN_006d7a90;
    puVar2[3] = _guard_check_icall;
    puVar2[4] = 0;
    puVar2[5] = param_1;
    puVar2[6] = *param_3;
    puVar2[7] = param_3[1];
  }
  FUN_016797d0(puVar2);
  *param_2 = puVar2;
  if (puVar2 != (undefined4 *)0x0) {
    LOCK();
    puVar2[1] = puVar2[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9176 ; VA 0x006cfe30 ; FUN_006cfe30 */

void FUN_006cfe30(undefined4 param_1,int *param_2,int *param_3,int *param_4,undefined *param_5)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined uVar6;
  int *piVar7;
  undefined8 *puVar8;
  
  uVar6 = *param_5;
  iVar1 = *param_4;
  iVar2 = *param_3;
  *param_2 = iVar2;
  param_2[1] = iVar1;
  piVar7 = (int *)FUN_00b077e0();
  iVar3 = piVar7[1];
  iVar4 = piVar7[2];
  iVar5 = piVar7[3];
  param_2[2] = *piVar7;
  param_2[3] = iVar3;
  param_2[4] = iVar4;
  param_2[5] = iVar5;
  iVar3 = piVar7[5];
  iVar4 = piVar7[6];
  iVar5 = piVar7[7];
  param_2[6] = piVar7[4];
  param_2[7] = iVar3;
  param_2[8] = iVar4;
  param_2[9] = iVar5;
  iVar3 = piVar7[9];
  iVar4 = piVar7[10];
  iVar5 = piVar7[0xb];
  param_2[10] = piVar7[8];
  param_2[0xb] = iVar3;
  param_2[0xc] = iVar4;
  param_2[0xd] = iVar5;
  puVar8 = (undefined8 *)FUN_00b07b60();
  *(undefined8 *)(param_2 + 0xe) = *puVar8;
  param_2[0x10] = *(int *)(puVar8 + 1);
  *(undefined8 *)(param_2 + 0x11) = *(undefined8 *)((int)puVar8 + 0xc);
  param_2[0x13] = *(int *)((int)puVar8 + 0x14);
  param_2[0x14] = 0;
  *(undefined *)(param_2 + 0x15) = uVar6;
  uVar6 = FUN_00ca1a80(*(undefined4 *)(iVar2 + 0xa8));
  *(undefined *)((int)param_2 + 0x55) = uVar6;
  *(bool *)((int)param_2 + 0x56) = *(int *)(iVar1 + 0x14) == 0;
  *(undefined *)((int)param_2 + 0x57) = *(undefined *)(iVar1 + 0x38);
  FUN_00b07ca0(param_2 + 0x16);
  FUN_0170d1f0(param_2 + 0x17,0,0x34);
  FUN_006ab530();
  param_2[0x22] = 0;
  param_2[0x23] = 0;
  return;
}



/* FUNCTION 9177 ; VA 0x006cff00 ; FUN_006cff00 */

int FUN_006cff00(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  
  piVar3 = (int *)param_3[1];
  uVar4 = *param_3;
  *param_3 = 0;
  param_3[1] = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar3[2] = piVar3[2] + 1;
    UNLOCK();
  }
  iVar5 = FUN_006cdca0(uVar4,piVar3,0);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x006cff56. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar5 = (**(code **)(*piVar3 + 4))();
      return iVar5;
    }
  }
  return iVar5;
}



/* FUNCTION 9178 ; VA 0x006cff60 ; FUN_006cff60 */

void FUN_006cff60(undefined4 param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_2 + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar3 = *(int *)(param_2 + 4);
  if (iVar3 != 0) {
    piVar2 = (int *)(iVar3 + 4);
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  return;
}



/* FUNCTION 9179 ; VA 0x006cffc0 ; FUN_006cffc0 */

int FUN_006cffc0(undefined4 param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_00617ad0();
  piVar3 = *(int **)(param_2 + 0x1c);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = *(int **)(param_2 + 0x14);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = *(int **)(param_2 + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  iVar2 = *(int *)(param_2 + 4);
  if (iVar2 != 0) {
    piVar3 = (int *)(iVar2 + 4);
    LOCK();
    iVar4 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    iVar4 = iVar4 + -1;
    if (iVar4 == 0) {
      iVar4 = FUN_01674ea0(iVar2);
    }
  }
  return iVar4;
}



/* FUNCTION 9180 ; VA 0x006d0070 ; FUN_006d0070 */

void FUN_006d0070(undefined4 param_1,int param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_2 + 4);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_2 + 0xc) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_2 + 4) = 0;
    *(undefined4 *)(param_2 + 8) = 0;
    *(undefined4 *)(param_2 + 0xc) = 0;
  }
  return;
}



/* FUNCTION 9181 ; VA 0x006d00d0 ; FUN_006d00d0 */

void __thiscall FUN_006d00d0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    *puVar1 = 0;
    puVar1[1] = 0;
    *puVar1 = *param_2;
    puVar1[1] = param_2[1];
    *param_2 = 0;
    param_2[1] = 0;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 8;
    return;
  }
  FUN_006ce750(puVar1,param_2);
  return;
}



/* FUNCTION 9182 ; VA 0x006d0130 ; FUN_006d0130 */

undefined4 * __thiscall
FUN_006d0130(byte *param_1,undefined4 *param_2,uint *param_3,int *param_4,int *param_5)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8458;
  pvStack_10 = ExceptionList;
  uVar7 = (*param_3 >> 3) + *param_3;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_3,uVar7,param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_3 != (uint *)0x0) {
    *param_2 = param_3;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return param_2;
  }
  uStack_8 = 0;
  piVar5 = (int *)FUN_01674e20(0x18);
  *piVar5 = 0;
  piVar5[1] = 0;
  piVar5[2] = 0;
  piVar5[3] = 0;
  piVar5[4] = 0;
  piVar5[5] = 0;
  piVar5[2] = *param_4;
  piVar5[3] = *param_5;
  *param_5 = 0;
  piVar5[4] = 0;
  piVar5[5] = 0;
  piVar5[4] = param_5[1];
  piVar5[5] = param_5[2];
  param_5[1] = 0;
  param_5[2] = 0;
  uVar3 = *(uint *)(param_1 + 8);
  uVar6 = uVar3 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar6 = FUN_005c9310(uVar6);
    if (uVar6 <= *(uint *)(param_1 + 4)) {
      uVar6 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar6);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar6) {
    param_3 = (uint *)0x1;
    uVar8 = uVar3 >> 1;
    if (uVar3 + (uVar3 >> 1) <= uVar6) {
      uVar8 = 1;
    }
    uVar6 = FUN_005c9310(uVar8 + *(int *)(param_1 + 8));
    param_3 = (uint *)(param_1 + 4);
    if (uVar6 != *param_3) {
      FUN_005d2b00(uVar6);
      puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_3 * 4);
      puVar4 = (undefined4 *)*puVar9;
      while (puVar4 != (undefined4 *)0x0) {
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *param_3) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *param_3) * 4) == 0) {
          *piVar1 = (int)puVar9;
          puVar9 = puVar4;
        }
        else {
          *puVar9 = *puVar4;
          *puVar4 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar4;
        }
        puVar4 = (undefined4 *)*puVar9;
      }
    }
  }
  piVar5[1] = uVar7;
  uVar6 = *(uint *)(param_1 + 4);
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + (uVar7 % uVar6) * 4);
  if ((int *)*piVar1 == (int *)0x0) {
    piVar2 = (int *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    if (*piVar2 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar2 + 4) % uVar6) * 4) = piVar5;
    }
    *piVar1 = (int)piVar2;
    *piVar5 = *piVar2;
    *piVar2 = (int)piVar5;
  }
  else {
    *piVar5 = *(int *)*piVar1;
    *(int **)*piVar1 = piVar5;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = piVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 9183 ; VA 0x006d0350 ; FUN_006d0350 */

void __thiscall FUN_006d0350(int param_1,undefined4 *param_2,uint param_3,int param_4)

{
  undefined4 *puVar1;
  char cVar2;
  uint uVar3;
  int *piVar4;
  
  uVar3 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar4 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4 = (int *)*puVar1;
    }
    if (piVar4 != (int *)0x0) {
      do {
        if (param_3 == piVar4[1]) {
          cVar2 = FUN_009c8f50(piVar4 + 2);
          if ((cVar2 != '\0') && (*(int *)(param_4 + 8) == piVar4[4])) break;
        }
        else if ((uint)piVar4[1] % *(uint *)(param_1 + 4) != uVar3) {
          *param_2 = 0;
          return;
        }
        piVar4 = (int *)*piVar4;
        if (piVar4 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar4;
  return;
}



/* FUNCTION 9184 ; VA 0x006d03f0 ; FUN_006d03f0 */

void FUN_006d03f0(int *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a847f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x50);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count_obj<struct_RBX::Network::CachedBitstream>::vftable;
    FUN_0060edf0(*param_2);
  }
  *param_1 = (int)(puVar1 + 3);
  param_1[1] = (int)puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9185 ; VA 0x006d0470 ; FUN_006d0470 */

void __thiscall FUN_006d0470(int param_1,int param_2)

{
  float fVar1;
  char cVar2;
  uint uVar3;
  int *piVar4;
  uint uVar5;
  float fVar6;
  uint uStack_8;
  
  piVar4 = *(int **)(param_1 + 4);
  uStack_8 = 0;
  uVar3 = *(uint *)(param_1 + 8) & 0x3fffffff;
  if (piVar4 + *(uint *)(param_1 + 8) < piVar4) {
    uVar3 = 0;
  }
  if (uVar3 != 0) {
    do {
      uVar5 = -(uint)(*piVar4 != 0) & *piVar4 - 8U;
      cVar2 = *(char *)(uVar5 + 0xa8);
      if (cVar2 != '\0') {
        FUN_00ca0e10();
        cVar2 = *(char *)(uVar5 + 0xa8);
      }
      fVar1 = *(float *)(uVar5 + 0xa4);
      fVar6 = fVar1;
      if (cVar2 != '\0') {
        FUN_00ca0e10();
        fVar6 = *(float *)(uVar5 + 0xa4);
      }
      *(float *)(param_2 + 0x50) = fVar6 * fVar1 + *(float *)(param_2 + 0x50);
      FUN_006d0470(param_2);
      piVar4 = piVar4 + 1;
      uStack_8 = uStack_8 + 1;
    } while (uStack_8 != uVar3);
  }
  return;
}



/* FUNCTION 9186 ; VA 0x006d0520 ; FUN_006d0520 */

int * __thiscall FUN_006d0520(int *param_1,int *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  int iVar9;
  
  param_1[1] = 0;
  iVar9 = param_2[1];
  param_1[2] = 0;
  *param_1 = 0;
  if (iVar9 < 1) {
    iVar6 = param_1[1];
  }
  else {
    iVar6 = 0;
    if (iVar9 != 0) {
      param_1[1] = iVar9;
      param_1[2] = iVar9;
      FUN_006dda40(0);
      iVar6 = param_1[1];
      iVar9 = 0;
      if (0 < iVar6) {
        iVar8 = 0;
        do {
          iVar9 = iVar9 + 1;
          puVar7 = (undefined4 *)(*param_1 + iVar8);
          iVar8 = iVar8 + 0x1c;
          *puVar7 = 0;
          puVar7[1] = 0;
          puVar7[2] = 0;
          puVar7[3] = 0;
          puVar7[4] = 0;
          puVar7[5] = 0;
          puVar7[6] = 0;
          iVar6 = param_1[1];
        } while (iVar9 < iVar6);
      }
    }
  }
  iVar9 = 0;
  if (0 < iVar6) {
    iVar6 = 0;
    do {
      iVar8 = *param_2;
      iVar6 = iVar6 + 0x1c;
      iVar2 = *param_1;
      iVar9 = iVar9 + 1;
      puVar7 = (undefined4 *)(iVar8 + -0x1c + iVar6);
      uVar3 = puVar7[1];
      uVar4 = puVar7[2];
      uVar5 = puVar7[3];
      puVar1 = (undefined4 *)(iVar2 + -0x1c + iVar6);
      *puVar1 = *puVar7;
      puVar1[1] = uVar3;
      puVar1[2] = uVar4;
      puVar1[3] = uVar5;
      *(undefined8 *)(iVar2 + -0xc + iVar6) = *(undefined8 *)(iVar8 + -0xc + iVar6);
      *(undefined4 *)(iVar2 + -4 + iVar6) = *(undefined4 *)(iVar8 + -4 + iVar6);
    } while (iVar9 < param_1[1]);
  }
  return param_1;
}



/* FUNCTION 9187 ; VA 0x006d05f0 ; FUN_006d05f0 */

int * __thiscall FUN_006d05f0(int *param_1,int param_2)

{
  undefined4 uVar1;
  undefined auStack_20 [8];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8498;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  *(undefined *)(param_1 + 1) = 0;
  if (param_2 != 0) {
    uStack_18 = 0xffffffff;
    uStack_14 = 0x7fffffff;
    param_2 = 0xffffffff;
    FUN_005672c0(&param_2,&uStack_18);
    FUN_006dfe10(auStack_20);
    *(undefined *)(param_1 + 1) = 1;
    ExceptionList = pvStack_10;
    return param_1;
  }
  uVar1 = FUN_0056aeb0(1,"boost shared_lock has no mutex");
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_00564990(uVar1);
}



/* FUNCTION 9188 ; VA 0x006d0690 ; FUN_006d0690 */

undefined8 * __thiscall FUN_006d0690(undefined8 *param_1,undefined8 *param_2)

{
  uint uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)((int)param_1 + 0xc) = 0;
  uVar1 = *(uint *)((int)param_2 + 0xc);
  *(uint *)((int)param_1 + 0xc) = uVar1;
  if ((*(uint *)((int)param_2 + 0xc) & 0xfffffff8) != 0) {
    if ((((int)uVar1 >> 1 & 1U) == 0) || ((~(byte)((int)uVar1 >> 2) & 1) != 0)) {
      *param_1 = *param_2;
      *(undefined4 *)(param_1 + 1) = *(undefined4 *)(param_2 + 1);
    }
    else {
      (**(code **)((uVar1 & 0xfffffff8) + 4))(param_1,param_2);
    }
    *(undefined4 *)((int)param_2 + 0xc) = 0;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9189 ; VA 0x006d0720 ; FUN_006d0720 */

int * __thiscall FUN_006d0720(int *param_1,int param_2)

{
  undefined4 uVar1;
  undefined auStack_20 [8];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8498;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  *(undefined *)(param_1 + 1) = 0;
  if (param_2 != 0) {
    uStack_18 = 0xffffffff;
    uStack_14 = 0x7fffffff;
    param_2 = 0xffffffff;
    FUN_005672c0(&param_2,&uStack_18);
    FUN_006dfad0(auStack_20);
    *(undefined *)(param_1 + 1) = 1;
    ExceptionList = pvStack_10;
    return param_1;
  }
  uVar1 = FUN_0056aeb0(1,"boost unique_lock has no mutex");
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_00564990(uVar1);
}



/* FUNCTION 9190 ; VA 0x006d07c0 ; FUN_006d07c0 */

undefined4 * __thiscall FUN_006d07c0(undefined4 *param_1,int *param_2)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a84b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  cVar2 = FUN_005759f0((param_2[1] - *param_2) / 0xd0);
  if (cVar2 != '\0') {
    puVar5 = (undefined4 *)*param_1;
    puVar1 = (undefined4 *)param_2[1];
    puVar4 = (undefined4 *)*param_2;
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    for (; puVar4 != puVar1; puVar4 = puVar4 + 0x34) {
      *puVar5 = *puVar4;
      puVar5[1] = 0;
      puVar3 = (undefined4 *)puVar4[1];
      if (puVar3 != (undefined4 *)0x0) {
        (*(code *)*puVar3)(puVar4 + 2,puVar5 + 2);
        puVar3 = (undefined4 *)puVar4[1];
      }
      puVar5[1] = puVar3;
      puVar5 = puVar5 + 0x34;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00559720(puVar5,puVar5,param_1);
    param_1[1] = puVar5;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9191 ; VA 0x006d08a6 ; Catch_All@006d08a6 */

void Catch_All_006d08a6(void)

{
  FUN_00577b20();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 9192 ; VA 0x006d08c0 ; FUN_006d08c0 */

int * __thiscall FUN_006d08c0(int *param_1,uint param_2,char *param_3)

{
  uint *puVar1;
  int iVar2;
  int iVar3;
  code *pcVar4;
  int *piVar5;
  uint uVar6;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a84d8;
  pvStack_10 = ExceptionList;
  iStack_14 = -(uint)(*param_3 != '\0');
  uVar6 = param_2 + 0x1f >> 5;
  ExceptionList = &pvStack_10;
  FUN_005d0b80(uVar6,&iStack_14,(int)&param_3 + 3);
  param_1[3] = 0;
  uStack_8 = 0;
  if (param_2 < 0x80000000) {
    iVar3 = *param_1;
    if ((uVar6 < (uint)(param_1[1] - iVar3 >> 2)) &&
       (iVar2 = iVar3 + uVar6 * 4, iVar2 != param_1[1])) {
      param_1[1] = iVar2;
    }
    param_1[3] = param_2;
    if ((param_2 & 0x1f) != 0) {
      puVar1 = (uint *)(iVar3 + uVar6 * 4 + -4);
      *puVar1 = *puVar1 & (1 << (sbyte)(param_2 & 0x1f)) - 1U;
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_00657a00();
  pcVar4 = (code *)swi(3);
  piVar5 = (int *)(*pcVar4)();
  return piVar5;
}



/* FUNCTION 9193 ; VA 0x006d0970 ; FUN_006d0970 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __thiscall FUN_006d0970(undefined *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvVar5;
  undefined **ppuVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  undefined **ppuVar9;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined2 uStack_34;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined *puStack_20;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a868b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  piStack_14 = (int *)0xb;
  puStack_20 = param_1;
  ppuVar6 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&piStack_14);
  ppuVar9 = ppuVar6 + -1;
  if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar9 = ppuVar6;
  }
  *(undefined **)(param_1 + 4) = *ppuVar9;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  iVar2 = _tls_index;
  param_1[0x18] = param_2._0_1_;
  *(int *)(param_1 + 0x1c) = param_3;
  pvVar5 = ThreadLocalStoragePointer;
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  iVar2 = *(int *)((int)pvVar5 + iVar2 * 4);
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0;
  param_1[0x38] = 0;
  uStack_8 = 0;
  if (*(int *)(iVar2 + 0x34) < DAT_01eaf0a8) {
    FUN_016f3809(&DAT_01eaf0a8);
    if (DAT_01eaf0a8 == -1) {
      piStack_24 = (int *)0x0;
      _DAT_01eaf098 = 0;
      piStack_14 = (int *)0x0;
      _DAT_01eaf090 = 0;
      _DAT_01eaf09c = 0;
      DAT_01eaf0a0._0_4_ = 0;
      DAT_01eaf0a0._4_4_ = 0;
      FUN_016f37bf(&DAT_01eaf0a8);
    }
  }
  uVar4 = _DAT_01eaf09c;
  uVar3 = _DAT_01eaf098;
  uVar7 = DAT_01eaf090_4;
  *(undefined4 *)(param_1 + 0x3c) = _DAT_01eaf090;
  *(undefined4 *)(param_1 + 0x40) = uVar7;
  *(undefined4 *)(param_1 + 0x44) = uVar3;
  *(undefined4 *)(param_1 + 0x48) = uVar4;
  *(ulonglong *)(param_1 + 0x4c) = CONCAT44(DAT_01eaf0a0._4_4_,(undefined4)DAT_01eaf0a0);
  *(undefined8 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x60) = 0;
  *(undefined4 *)(param_1 + 100) = 0;
  *(undefined4 *)(param_1 + 0x68) = 0;
  *(undefined4 *)(param_1 + 0x6c) = 0;
  *(undefined4 *)(param_1 + 0x70) = 0;
  uStack_8._0_1_ = 2;
  FUN_006d1690();
  uStack_8._0_1_ = 3;
  param_1[0x85] = 0;
  param_2 = (int *)(param_1 + 0x88);
  uStack_18 = 0;
  piStack_14 = (int *)0x0;
  FUN_0060e9d0(0,&uStack_18,(int)&param_2 + 3);
  *(undefined4 *)(param_1 + 0x94) = 0;
  *(undefined4 *)(param_1 + 0x98) = 0;
  *(undefined4 *)(param_1 + 0xa0) = 0;
  *(undefined4 *)(param_1 + 0xa4) = 0;
  *(undefined4 *)(param_1 + 0xa8) = 0;
  *(undefined4 *)(param_1 + 0xac) = 0;
  *(undefined4 *)(param_1 + 0xb0) = 0;
  *(undefined4 *)(param_1 + 0xb4) = 0;
  *(undefined4 *)(param_1 + 0xb8) = 0;
  *(undefined4 *)(param_1 + 0xbc) = 0;
  *(undefined4 *)(param_1 + 0xc0) = 0;
  *(undefined4 *)(param_1 + 0xc4) = 0;
  uStack_8._0_1_ = 9;
  FUN_006d1070();
  param_1[0x18c] = 0;
  param_2 = (int *)0xb;
  ppuVar6 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
  ppuVar9 = ppuVar6 + -1;
  if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar9 = ppuVar6;
  }
  *(undefined **)(param_1 + 400) = *ppuVar9;
  *(undefined4 *)(param_1 + 0x194) = 0;
  *(undefined4 *)(param_1 + 0x198) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x19c) = 0;
  *(undefined4 *)(param_1 + 0x1a0) = 0;
  param_1[0x1a4] = 0;
  param_2 = (int *)0xb;
  ppuVar6 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
  ppuVar9 = ppuVar6 + -1;
  if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar9 = ppuVar6;
  }
  *(undefined **)(param_1 + 0x1a8) = *ppuVar9;
  *(undefined4 *)(param_1 + 0x1ac) = 0;
  *(undefined4 *)(param_1 + 0x1b0) = 0x3f800000;
  *(undefined4 *)(param_1 + 0x1b4) = 0;
  *(undefined4 *)(param_1 + 0x1b8) = 0;
  *(undefined4 *)(param_1 + 0x1bc) = 0;
  *(undefined4 *)(param_1 + 0x1c0) = 0;
  *(undefined4 *)(param_1 + 0x1c4) = 0;
  *(undefined4 *)(param_1 + 0x1c8) = 0;
  *(undefined4 *)(param_1 + 0x1cc) = 0;
  *(undefined4 *)(param_1 + 0x1d0) = 0;
  uStack_8._0_1_ = 0x10;
  FUN_006d1690();
  *(undefined4 *)(param_1 + 0x1e4) = 0;
  *(undefined4 *)(param_1 + 0x1e8) = 0;
  *(undefined4 *)(param_1 + 0x1ec) = 0;
  *(undefined4 *)(param_1 + 0x1f0) = 0;
  *(undefined4 *)(param_1 + 0x1f8) = 1;
  *(undefined4 *)(param_1 + 0x1fc) = 0;
  *(undefined4 *)(param_1 + 0x200) = 1;
  *(undefined4 *)(param_1 + 0x204) = 0;
  uStack_8._0_1_ = 0x14;
  *(undefined4 *)(param_1 + 0x208) = 8;
  *(undefined4 *)(param_1 + 0x20c) = 0;
  *(undefined4 *)(param_1 + 0x210) = 0;
  uVar7 = FUN_01674f30(0x40);
  *(undefined4 *)(param_1 + 0x214) = uVar7;
  *(undefined4 *)(param_1 + 0x218) = 0;
  *(undefined4 *)(param_1 + 0x21c) = 0;
  *(undefined4 *)(param_1 + 0x220) = 0;
  *(undefined4 *)(param_1 + 0x224) = 0;
  *(undefined4 *)(param_1 + 0x228) = 0;
  *(undefined4 *)(param_1 + 0x22c) = 0;
  *(undefined4 *)(param_1 + 0x230) = 0;
  *(undefined4 *)(param_1 + 0x234) = 0;
  *(undefined4 *)(param_1 + 0x238) = 0;
  *(undefined4 *)(param_1 + 0x23c) = 0;
  *(undefined4 *)(param_1 + 0x240) = 0;
  *(undefined4 *)(param_1 + 0x244) = 0;
  *(undefined4 *)(param_1 + 0x248) = 0;
  puVar8 = (undefined4 *)(param_1 + 0x24c);
  uStack_8._0_1_ = 0x19;
  *puVar8 = 0;
  *(undefined4 *)(param_1 + 0x250) = 0;
  param_2 = puVar8;
  uVar7 = FUN_00575b10();
  *puVar8 = uVar7;
  puVar8 = (undefined4 *)(param_1 + 0x254);
  uStack_8._0_1_ = 0x1a;
  *puVar8 = 0;
  *(undefined4 *)(param_1 + 600) = 0;
  param_2 = puVar8;
  uVar7 = FUN_006d3cb0();
  *puVar8 = uVar7;
  *(undefined4 *)(param_1 + 0x25c) = 0xffffffff;
  *(undefined4 *)(param_1 + 0x260) = 0;
  *(undefined4 *)(param_1 + 0x264) = 0;
  *(undefined4 *)(param_1 + 0x268) = 0;
  uStack_8._0_1_ = 0x1c;
  param_1[0x26c] = 0;
  if ((DAT_01d5b820 != '\0') && (param_3 != 0)) {
    param_2 = (int *)FUN_01674e20(0x104);
    uStack_8._0_1_ = 0x1d;
    if (param_2 == (undefined4 *)0x0) {
      uVar7 = 0;
    }
    else {
      uVar7 = FUN_006c8460(param_1);
    }
    iVar2 = *(int *)(param_1 + 0x1e4);
    *(undefined4 *)(param_1 + 0x1e4) = uVar7;
    if (iVar2 != 0) {
      FUN_006d2840();
      FUN_01674ea0(iVar2,0x104);
    }
  }
  uStack_40 = 0;
  uStack_3c = DAT_018c45c8;
  uStack_34 = 0;
  uStack_44 = 0;
  uStack_18 = 0;
  piStack_14 = (int *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x1e);
  puVar8 = (undefined4 *)FUN_0151d9e0(auStack_28,&uStack_18,4,&uStack_44);
  uVar7 = *puVar8;
  uVar3 = puVar8[1];
  *puVar8 = 0;
  puVar8[1] = 0;
  *(undefined4 *)(param_1 + 0x264) = uVar7;
  param_2 = *(int **)(param_1 + 0x268);
  *(undefined4 *)(param_1 + 0x268) = uVar3;
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar2 = param_2[1] + -1;
    param_2[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_2)();
      LOCK();
      iVar2 = param_2[2] + -1;
      param_2[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  param_2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_24[1] + -1;
    piStack_24[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar2 = param_2[2] + -1;
      param_2[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 0x1c;
  param_2 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar2 = param_2[2] + -1;
      param_2[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  if (DAT_01d5b838 != '\0') {
    uStack_40 = 0;
    uStack_3c = DAT_018c45c8;
    uStack_44 = 0;
    uStack_34 = 0x100;
    uStack_18 = 0;
    piStack_14 = (int *)0x0;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x1f);
    puVar8 = (undefined4 *)FUN_0151d9e0(auStack_28,&uStack_18,4,&uStack_44);
    uVar7 = *puVar8;
    uVar3 = puVar8[1];
    *puVar8 = 0;
    puVar8[1] = 0;
    *(undefined4 *)(param_1 + 0x220) = uVar7;
    param_2 = *(int **)(param_1 + 0x224);
    *(undefined4 *)(param_1 + 0x224) = uVar3;
    if (param_2 != (int *)0x0) {
      LOCK();
      iVar2 = param_2[1] + -1;
      param_2[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_2)();
        LOCK();
        iVar2 = param_2[2] + -1;
        param_2[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_2 + 4))();
        }
      }
    }
    param_2 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[1] + -1;
      piStack_24[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar2 = param_2[2] + -1;
        param_2[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_2 + 4))();
        }
      }
    }
    param_2 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_14[1] + -1;
      piStack_14[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = param_2 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_2 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9194 ; VA 0x006d1070 ; FUN_006d1070 */

undefined * __fastcall FUN_006d1070(undefined *param_1)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  int aiStack_5c [5];
  uint uStack_48;
  undefined2 uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8713;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  puStack_1c = (undefined *)0x0;
  puStack_18 = param_1;
  FUN_006b3040(0,&uStack_28,&uStack_11);
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  uStack_8 = 0;
  puStack_1c = (undefined *)((uint)puStack_1c & 0xffff0000);
  uStack_24 = uStack_24 & 0xffffffff;
  FUN_0060e8c0(0,(int)&uStack_24 + 4,&uStack_11);
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  uStack_8._0_1_ = 1;
  puStack_1c = (undefined *)((uint)puStack_1c & 0xffff0000);
  uStack_24 = uStack_24 & 0xffffffff;
  FUN_0060e8c0(0,(int)&uStack_24 + 4,&uStack_11);
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined4 *)(param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 0x4c) = 0;
  *(undefined4 *)(param_1 + 0x50) = 0;
  *(undefined4 *)(param_1 + 0x54) = 0;
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0;
  *(undefined4 *)(param_1 + 0x60) = 0;
  *(undefined4 *)(param_1 + 100) = 0;
  *(undefined4 *)(param_1 + 0x68) = 0;
  *(undefined4 *)(param_1 + 0x6c) = 0;
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x74) = 0;
  *(undefined4 *)(param_1 + 0x78) = 0;
  *(undefined4 *)(param_1 + 0x80) = 0;
  *(undefined4 *)(param_1 + 0x84) = 0;
  *(undefined4 *)(param_1 + 0x88) = 0;
  puStack_1c = param_1 + 0x8c;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  uStack_8._0_1_ = 8;
  FUN_0054ef60(auStack_40);
  uStack_44 = 0;
  uStack_8._0_1_ = 9;
  FUN_006b30f0(0,aiStack_5c,&uStack_11);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (0xf < uStack_48) {
    uVar2 = uStack_48 + 1;
    iVar1 = aiStack_5c[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_5c[0] + -4);
      uVar2 = uStack_48 + 0x24;
      if (0x1f < (aiStack_5c[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  *(undefined4 *)(param_1 + 0x98) = 0;
  FUN_0054ef60(auStack_40);
  if (0xf < uStack_2c) {
    uVar3 = uStack_2c + 1;
    uVar2 = auStack_40[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_40[0] - 4);
      uVar3 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  *(undefined4 *)(param_1 + 0xb8) = 0;
  *(undefined4 *)(param_1 + 0xbc) = 0;
  *(undefined4 *)(param_1 + 0xc0) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9195 ; VA 0x006d12a0 ; FUN_006d12a0 */

undefined4 * __thiscall
FUN_006d12a0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined8 uStack_34;
  undefined2 uStack_2c;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a8780;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  puStack_14 = param_1;
  FUN_00a360a0("SendData Mega Job",1,0,param_2,param_3,7);
  *param_1 = RBX::Network::NetworkSendDataMegaJob::vftable;
  param_1[0x4a] = 0;
  param_1[0x4b] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  param_1[0x4a] = param_2;
  param_1[0x4b] = param_3;
  param_1[0x4c] = param_4;
  param_1[0x4d] = 0;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  param_1[0x50] = 0;
  param_1[0x51] = 0;
  param_1[0x52] = 0;
  uStack_8._0_1_ = 5;
  FUN_00a361f0();
  uStack_38 = 0;
  uStack_34 = DAT_018c45c8;
  uStack_2c = 0;
  uStack_3c = 0;
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  puVar6 = (undefined4 *)FUN_0151d9e0(auStack_24,&uStack_1c,4,&uStack_3c);
  uVar2 = *puVar6;
  uVar3 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  param_1[0x4f] = uVar2;
  piVar4 = (int *)param_1[0x50];
  param_1[0x50] = uVar3;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar5 = piVar4[2] + -1;
      piVar4[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_20[1] + -1;
    piStack_20[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_18[1] + -1;
    piStack_18[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  puVar6 = (undefined4 *)FUN_0151d9e0(auStack_24,&uStack_1c,4,&uStack_3c);
  uVar2 = *puVar6;
  uVar3 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  param_1[0x4d] = uVar2;
  piVar4 = (int *)param_1[0x4e];
  param_1[0x4e] = uVar3;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar5 = piVar4[2] + -1;
      piVar4[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_20;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_20[1] + -1;
    piStack_20[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_18[1] + -1;
    piStack_18[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  uStack_2c = CONCAT11(uStack_2c._1_1_,1);
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  puVar6 = (undefined4 *)FUN_0151d9e0(auStack_24,&uStack_1c,4,&uStack_3c);
  uVar2 = *puVar6;
  uVar3 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  param_1[0x51] = uVar2;
  piVar4 = (int *)param_1[0x52];
  param_1[0x52] = uVar3;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar5 = piVar4[2] + -1;
      piVar4[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_20[1] + -1;
    piStack_20[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar5 = piStack_20[2] + -1;
      piStack_20[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  piVar4 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_18[1] + -1;
    piStack_18[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1 + -1;
      *piVar1 = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar5 = param_3[1] + -1;
    param_3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar4 = param_3 + 2;
      iVar5 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 9196 ; VA 0x006d1620 ; FUN_006d1620 */

undefined4 * __fastcall FUN_006d1620(undefined4 *param_1)

{
  undefined4 uVar1;
  char *pcStack_c;
  undefined4 *puStack_8;
  
  puStack_8 = param_1;
  uVar1 = FUN_01685730();
  *param_1 = std::exception::vftable;
  pcStack_c = "boost::lock_error";
  puStack_8 = (undefined4 *)CONCAT31(puStack_8._1_3_,1);
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(&pcStack_c,param_1 + 1);
  param_1[4] = uVar1;
  param_1[3] = 0;
  param_1[9] = 0;
  param_1[10] = 0xf;
  *(undefined *)(param_1 + 5) = 0;
  *param_1 = boost::lock_error::vftable;
  return param_1;
}



/* FUNCTION 9197 ; VA 0x006d1690 ; FUN_006d1690 */

undefined4 * __fastcall FUN_006d1690(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a87a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = CreateSemaphoreA(0,0,0x7fffffff,0);
  if (iVar1 == 0) {
    uVar2 = FUN_005503c0();
    uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
    FUN_0054e630(uVar2);
  }
  param_1[1] = iVar1;
  iVar1 = CreateSemaphoreA(0,0,0x7fffffff,0);
  param_1[2] = iVar1;
  if (iVar1 != 0) {
    iVar1 = CreateSemaphoreA(0,0,0x7fffffff,0);
    param_1[3] = iVar1;
    if (iVar1 != 0) {
      *param_1 = 0;
      ExceptionList = pvStack_10;
      return param_1;
    }
    FUN_006ddd60(param_1[1],0x7fffffff);
    FUN_006ddd60(param_1[2],0x7fffffff);
    uVar2 = FUN_005503c0();
    uStack_8 = 2;
                    /* WARNING: Subroutine does not return */
    FUN_0054e630(uVar2);
  }
  FUN_006ddd60(param_1[1],0x7fffffff);
  uVar2 = FUN_005503c0();
  uStack_8 = 1;
                    /* WARNING: Subroutine does not return */
  FUN_0054e630(uVar2);
}



/* FUNCTION 9198 ; VA 0x006d1780 ; FUN_006d1780 */

void __fastcall FUN_006d1780(uint *param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  void **ppvVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  uVar3 = param_1[2];
  ppvVar5 = &pvStack_10;
  pvStack_10 = ExceptionList;
  while (ExceptionList = ppvVar5, uVar3 != 0) {
    puVar1 = (undefined4 *)(param_1[3] + (param_1[1] % *param_1) * 8);
    param_1[1] = (param_1[1] + 1) % *param_1;
    piVar2 = (int *)puVar1[1];
    *puVar1 = 0;
    puVar1[1] = 0;
    param_1[2] = param_1[2] - 1;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    ppvVar5 = (void **)ExceptionList;
    uVar3 = param_1[2];
  }
  FUN_01674ea0(param_1[3]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9199 ; VA 0x006d1810 ; FUN_006d1810 */

void __fastcall FUN_006d1810(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_006d18f0();
  return;
}



/* FUNCTION 9200 ; VA 0x006d1870 ; FUN_006d1870 */

void __fastcall FUN_006d1870(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006ce110(*param_1,param_1[1],param_1[2]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9201 ; VA 0x006d18b0 ; FUN_006d18b0 */

void __fastcall FUN_006d18b0(int param_1)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_1 + 0xc);
  while (puVar1 != (undefined4 *)0x0) {
    *(undefined4 *)(param_1 + 0xc) = *puVar1;
    FUN_01674ea0(puVar1,0x14);
    puVar1 = *(undefined4 **)(param_1 + 0xc);
  }
  if (*(int *)(param_1 + 4) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 4),0x14);
  }
  return;
}



/* FUNCTION 9202 ; VA 0x006d18f0 ; FUN_006d18f0 */

void __fastcall FUN_006d18f0(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)*param_1;
  piVar3 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar2 = (int *)*param_1;
  if (piVar3 != piVar2) {
    do {
      piVar1 = (int *)*piVar3;
      FUN_01674ea0(piVar3,0x18);
      piVar2 = (int *)*param_1;
      piVar3 = piVar1;
    } while (piVar1 != piVar2);
  }
  FUN_01674ea0(piVar2,0x18);
  return;
}



/* FUNCTION 9203 ; VA 0x006d1940 ; FUN_006d1940 */

void __fastcall FUN_006d1940(undefined4 *param_1)

{
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_006d7f40(&puStack_14,*(undefined4 *)*param_1,(undefined4 *)*param_1);
  FUN_01674ea0(*param_1,0x30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9204 ; VA 0x006d1990 ; FUN_006d1990 */

void __fastcall FUN_006d1990(undefined4 *param_1)

{
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_006d8010(&puStack_14,*(undefined4 *)*param_1,(undefined4 *)*param_1);
  FUN_01674ea0(*param_1,0x24);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9205 ; VA 0x006d19e0 ; FUN_006d19e0 */

void __fastcall FUN_006d19e0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_006cff60(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x18);
  }
  return;
}



/* FUNCTION 9206 ; VA 0x006d1a10 ; FUN_006d1a10 */

void __fastcall FUN_006d1a10(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_006cffc0(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x4c);
  }
  return;
}



/* FUNCTION 9207 ; VA 0x006d1a40 ; FUN_006d1a40 */

void __fastcall FUN_006d1a40(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_006d0070(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x18);
  }
  return;
}



/* FUNCTION 9208 ; VA 0x006d1a70 ; FUN_006d1a70 */

void __fastcall FUN_006d1a70(undefined4 *param_1)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  
  if (*(char *)(param_1 + 1) != '\0') {
    puVar1 = (uint *)*param_1;
    uVar5 = *puVar1;
    do {
      uVar4 = uVar5;
      uVar2 = (uVar4 - 1 ^ uVar4) & 0x7ff ^ uVar4;
      uVar3 = uVar2 & 0x7ff;
      if (uVar3 == 0) {
        if ((uVar2 & 0x800000) == 0) {
          if ((uVar4 >> 0x18 & 0x7f) != 0) {
            uVar2 = uVar2 & 0xffffff | ((uVar4 >> 0x18) - 1 & 0x7f) << 0x18;
          }
          uVar2 = uVar2 & 0xffc007ff;
        }
        else {
          uVar2 = uVar2 & 0xff7fffff | 0x400000;
        }
      }
      LOCK();
      uVar5 = *puVar1;
      if (uVar4 == uVar5) {
        *puVar1 = uVar2;
        uVar5 = uVar4;
      }
      UNLOCK();
    } while (uVar5 != uVar4);
    if (uVar3 == 0) {
      if ((uVar4 & 0x800000) != 0) {
        ReleaseSemaphore(puVar1[3],1,0);
        return;
      }
      uVar5 = uVar4 & 0x7f000000;
      if (uVar5 != 0) {
        ReleaseSemaphore(puVar1[2],1,0);
      }
      uVar2 = uVar4 >> 0xb & 0x7ff;
      if ((uVar2 != 0) || (uVar5 != 0)) {
        ReleaseSemaphore(puVar1[1],(uVar5 != 0) + uVar2,0);
      }
    }
  }
  return;
}



/* FUNCTION 9209 ; VA 0x006d1b40 ; FUN_006d1b40 */

void __fastcall FUN_006d1b40(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        piVar3 = (int *)puVar7[5];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[1] + -1;
          piVar3[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar4 = piVar3[2] + -1;
            piVar3[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        iVar4 = puVar7[3];
        if (iVar4 != 0) {
          piVar3 = (int *)(iVar4 + 4);
          LOCK();
          iVar2 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            FUN_01674ea0(iVar4);
          }
        }
        FUN_01674ea0(puVar7,0x18);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 9210 ; VA 0x006d1c20 ; FUN_006d1c20 */

void __fastcall FUN_006d1c20(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_006d6980(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 9211 ; VA 0x006d1ca0 ; FUN_006d1ca0 */

void __fastcall FUN_006d1ca0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_006d0070(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x18);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 9212 ; VA 0x006d1d50 ; FUN_006d1d50 */

void __fastcall FUN_006d1d50(undefined4 *param_1)

{
  uint uVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  uVar1 = param_1[3];
  if ((uVar1 & 0xfffffff8) != 0) {
    ExceptionList = &pvStack_10;
    if ((~(byte)((int)uVar1 >> 2) & 1) == 0) {
      puVar2 = param_1;
      if (((int)uVar1 >> 1 & 1U) == 0) {
        puVar2 = (undefined4 *)*param_1;
      }
      ExceptionList = &pvStack_10;
      (**(code **)((uVar1 & 0xfffffff8) + 8))(puVar2);
    }
    if (((int)uVar1 >> 1 & 1U) == 0) {
      FUN_01674ee0(*param_1);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9213 ; VA 0x006d1dc0 ; FUN_006d1dc0 */

void __fastcall FUN_006d1dc0(int param_1)

{
  if (*(char *)(param_1 + 4) != '\0') {
    FUN_006e00b0();
    return;
  }
  return;
}



/* FUNCTION 9214 ; VA 0x006d1dd0 ; FUN_006d1dd0 */

void __fastcall FUN_006d1dd0(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_006d2840();
    FUN_01674ea0(iVar1,0x104);
  }
  return;
}



/* FUNCTION 9215 ; VA 0x006d1df0 ; FUN_006d1df0 */

void __fastcall FUN_006d1df0(int *param_1)

{
  if (*param_1 != 0) {
    (*(code *)**(undefined4 **)(*param_1 + 8))(1);
  }
  return;
}



/* FUNCTION 9216 ; VA 0x006d1e10 ; FUN_006d1e10 */

void __fastcall FUN_006d1e10(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        piVar3 = (int *)puVar7[5];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[1] + -1;
          piVar3[1] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar4 = piVar3[2] + -1;
            piVar3[2] = iVar4;
            UNLOCK();
            if (iVar4 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        iVar4 = puVar7[3];
        if (iVar4 != 0) {
          piVar3 = (int *)(iVar4 + 4);
          LOCK();
          iVar2 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            FUN_01674ea0(iVar4);
          }
        }
        FUN_01674ea0(puVar7,0x18);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 9217 ; VA 0x006d1e20 ; FUN_006d1e20 */

void __fastcall FUN_006d1e20(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_006d6980(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 9218 ; VA 0x006d1e30 ; FUN_006d1e30 */

void __fastcall FUN_006d1e30(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_006d0070(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x18);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 9219 ; VA 0x006d1e40 ; FUN_006d1e40 */

void __fastcall FUN_006d1e40(undefined4 *param_1)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  
  if (*(char *)(param_1 + 1) != '\0') {
    puVar1 = (uint *)*param_1;
    uVar5 = *puVar1;
    do {
      uVar4 = uVar5;
      uVar2 = uVar4 & 0xff7fffff;
      uVar2 = uVar2 ^ (uVar2 - 1 ^ uVar2) & 0x7ff;
      uVar3 = uVar2 & 0x7ff;
      if (uVar3 == 0) {
        if ((uVar4 >> 0x18 & 0x7f) != 0) {
          uVar2 = uVar2 & 0xffffff | ((uVar4 >> 0x18) - 1 & 0x7f) << 0x18;
        }
        uVar2 = uVar2 & 0xffc007ff;
      }
      LOCK();
      uVar5 = *puVar1;
      if (uVar4 == uVar5) {
        *puVar1 = uVar2;
        uVar5 = uVar4;
      }
      UNLOCK();
    } while (uVar5 != uVar4);
    if (uVar3 == 0) {
      uVar5 = uVar4 & 0x7f000000;
      if (uVar5 != 0) {
        ReleaseSemaphore(puVar1[2],1,0);
      }
      uVar2 = uVar4 >> 0xb & 0x7ff;
      if ((uVar2 != 0) || (uVar5 != 0)) {
        ReleaseSemaphore(puVar1[1],(uVar5 != 0) + uVar2,0);
      }
    }
  }
  return;
}



/* FUNCTION 9220 ; VA 0x006d1ef0 ; FUN_006d1ef0 */

void __fastcall FUN_006d1ef0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_006ce0c0(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x90) * 0x90;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 9221 ; VA 0x006d1f70 ; FUN_006d1f70 */

void __fastcall FUN_006d1f70(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  
  iVar5 = *param_1;
  if (iVar5 != 0) {
    iVar6 = param_1[1];
    if (iVar5 != iVar6) {
      piVar4 = (int *)(iVar5 + 0xc);
      do {
        iVar1 = piVar4[-2];
        if (iVar1 != 0) {
          uVar2 = ((*piVar4 - iVar1) / 0xc) * 0xc;
          iVar3 = iVar1;
          if (0xfff < uVar2) {
            iVar3 = *(int *)(iVar1 + -4);
            uVar2 = uVar2 + 0x23;
            if (0x1f < (iVar1 - iVar3) - 4U) goto LAB_006d2056;
          }
          FUN_01674ea0(iVar3,uVar2);
          piVar4[-2] = 0;
          piVar4[-1] = 0;
          *piVar4 = 0;
        }
        iVar5 = iVar5 + 0x14;
        piVar4 = piVar4 + 5;
      } while (iVar5 != iVar6);
      iVar5 = *param_1;
    }
    uVar2 = ((param_1[2] - iVar5) / 0x14) * 0x14;
    iVar6 = iVar5;
    if (0xfff < uVar2) {
      iVar6 = *(int *)(iVar5 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar5 - iVar6) - 4U) {
LAB_006d2056:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 9222 ; VA 0x006d2060 ; thunk_FUN_006d3f40 */

void __fastcall thunk_FUN_006d3f40(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  
  iVar5 = *param_1;
  if (iVar5 != 0) {
    iVar6 = param_1[1];
    if (iVar5 != iVar6) {
      piVar4 = (int *)(iVar5 + 0x2c);
      do {
        iVar1 = piVar4[-2];
        if (iVar1 != 0) {
          uVar3 = *piVar4 - iVar1 & 0xfffffff8;
          iVar2 = iVar1;
          if (0xfff < uVar3) {
            iVar2 = *(int *)(iVar1 + -4);
            uVar3 = uVar3 + 0x23;
            if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006d406c;
          }
          FUN_01674ea0(iVar2,uVar3);
          piVar4[-2] = 0;
          piVar4[-1] = 0;
          *piVar4 = 0;
        }
        iVar1 = piVar4[-8];
        if (iVar1 != 0) {
          uVar3 = piVar4[-6] - iVar1 & 0xfffffff8;
          iVar2 = iVar1;
          if (0xfff < uVar3) {
            iVar2 = *(int *)(iVar1 + -4);
            uVar3 = uVar3 + 0x23;
            if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006d406c;
          }
          FUN_01674ea0(iVar2,uVar3);
          piVar4[-8] = 0;
          piVar4[-7] = 0;
          piVar4[-6] = 0;
        }
        iVar5 = iVar5 + 0x3c;
        piVar4 = piVar4 + 0xf;
      } while (iVar5 != iVar6);
      iVar5 = *param_1;
    }
    uVar3 = ((param_1[2] - iVar5) / 0x3c) * 0x3c;
    iVar6 = iVar5;
    if (0xfff < uVar3) {
      iVar6 = *(int *)(iVar5 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar5 - iVar6) - 4U) {
LAB_006d406c:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 9223 ; VA 0x006d2070 ; FUN_006d2070 */

void __fastcall FUN_006d2070(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_006ce110(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar3 = param_1[2] - iVar1 & 0xffffffe0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9224 ; VA 0x006d2100 ; FUN_006d2100 */

void __fastcall FUN_006d2100(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_005e6280();
        iVar2 = iVar2 + 0xc;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0xc) * 0xc;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 9225 ; VA 0x006d2180 ; FUN_006d2180 */

void __fastcall FUN_006d2180(uint *param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  void **ppvVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  uVar3 = param_1[2];
  ppvVar5 = &pvStack_10;
  pvStack_10 = ExceptionList;
  while (ExceptionList = ppvVar5, uVar3 != 0) {
    puVar1 = (undefined4 *)(param_1[3] + (param_1[1] % *param_1) * 8);
    param_1[1] = (param_1[1] + 1) % *param_1;
    piVar2 = (int *)puVar1[1];
    *puVar1 = 0;
    puVar1[1] = 0;
    param_1[2] = param_1[2] - 1;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    ppvVar5 = (void **)ExceptionList;
    uVar3 = param_1[2];
  }
  FUN_01674ea0(param_1[3]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9226 ; VA 0x006d2190 ; FUN_006d2190 */

int __fastcall FUN_006d2190(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int in_EAX;
  int iVar4;
  
  piVar3 = (int *)param_1[3];
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
    *param_1 = RBX::Instance::ICombinedSignalData::vftable;
    return iVar4;
  }
  *param_1 = RBX::Instance::ICombinedSignalData::vftable;
  return in_EAX;
}



/* FUNCTION 9227 ; VA 0x006d21d0 ; FUN_006d21d0 */

void __fastcall FUN_006d21d0(undefined4 *param_1)

{
  *param_1 = RBX::Instance::ICombinedSignalData::vftable;
  return;
}



/* FUNCTION 9228 ; VA 0x006d21e0 ; FUN_006d21e0 */

void __fastcall FUN_006d21e0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void **ppvVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a950;
  iStack_14 = param_1;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x194) == 0) {
    puVar7 = (undefined4 *)0x0;
    ppvVar4 = &pvStack_10;
  }
  else {
    puVar7 = *(undefined4 **)(*(int *)(param_1 + 0x1a0) + *(int *)(param_1 + 400) * 4);
    ppvVar4 = &pvStack_10;
  }
  for (; ExceptionList = ppvVar4, puVar7 != (undefined4 *)0x0; puVar7 = (undefined4 *)*puVar7) {
    FUN_01679490();
    ppvVar4 = (void **)ExceptionList;
  }
  piVar2 = *(int **)(param_1 + 0x268);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8 = 0;
  FUN_006d8010(&iStack_14,**(undefined4 **)(param_1 + 0x254),*(undefined4 **)(param_1 + 0x254));
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x254),0x24);
  uStack_8 = 1;
  FUN_006d7f40(&iStack_14,**(undefined4 **)(param_1 + 0x24c),*(undefined4 **)(param_1 + 0x24c));
  FUN_01674ea0(*(undefined4 *)(param_1 + 0x24c),0x30);
  uStack_8 = 0xffffffff;
  FUN_005e6280();
  FUN_006d2100();
  FUN_006d2070();
  piVar2 = *(int **)(param_1 + 0x224);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_006d1780();
  iVar3 = *(int *)(param_1 + 0x1e8);
  if (iVar3 != 0) {
    uVar6 = (*(int *)(param_1 + 0x1f0) - iVar3 >> 2) * 4;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_006d2629;
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x1e8) = 0;
    *(undefined4 *)(param_1 + 0x1ec) = 0;
    *(undefined4 *)(param_1 + 0x1f0) = 0;
  }
  iVar3 = *(int *)(param_1 + 0x1e4);
  if (iVar3 != 0) {
    FUN_006d2840();
    FUN_01674ea0(iVar3,0x104);
  }
  CloseHandle(*(undefined4 *)(param_1 + 0x1e0));
  CloseHandle(*(undefined4 *)(param_1 + 0x1d8));
  CloseHandle(*(undefined4 *)(param_1 + 0x1dc));
  uStack_8 = 2;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x1d0);
  if (iVar3 != 0) {
    piVar2 = (int *)(iVar3 + 4);
    LOCK();
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 3;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x1cc);
  if (iVar3 != 0) {
    piVar2 = (int *)(iVar3 + 4);
    LOCK();
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uStack_8 = 4;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x1c8);
  if (iVar3 != 0) {
    piVar2 = (int *)(iVar3 + 4);
    LOCK();
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  iVar3 = *(int *)(param_1 + 0x1bc);
  if (iVar3 != 0) {
    uVar6 = *(int *)(param_1 + 0x1c4) - iVar3 & 0xfffffffc;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_006d2629;
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x1bc) = 0;
    *(undefined4 *)(param_1 + 0x1c0) = 0;
    *(undefined4 *)(param_1 + 0x1c4) = 0;
  }
  FUN_006d1ca0();
  FUN_006d1b40();
  FUN_006d2630();
  piVar2 = *(int **)(param_1 + 0xc4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (*(int *)(param_1 + 0xbc) != 0) {
    (*(code *)**(undefined4 **)(*(int *)(param_1 + 0xbc) + 8))(1);
  }
  piVar2 = *(int **)(param_1 + 0xb8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xb0);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 0xa8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar3 = *(int *)(param_1 + 0x88);
  if (iVar3 != 0) {
    uVar6 = *(int *)(param_1 + 0x90) - iVar3 & 0xfffffff8;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar3 - iVar5) - 4U) {
LAB_006d2629:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x88) = 0;
    *(undefined4 *)(param_1 + 0x8c) = 0;
    *(undefined4 *)(param_1 + 0x90) = 0;
  }
  CloseHandle(*(undefined4 *)(param_1 + 0x80));
  CloseHandle(*(undefined4 *)(param_1 + 0x78));
  CloseHandle(*(undefined4 *)(param_1 + 0x7c));
  FUN_006d1ef0();
  piVar2 = *(int **)(param_1 + 100);
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  FUN_006d1c20();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 9229 ; VA 0x006d2630 ; FUN_006d2630 */

void __fastcall FUN_006d2630(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  
  FUN_00577a40();
  uVar3 = *(uint *)(param_1 + 0xb0);
  if (0xf < uVar3) {
    iVar1 = *(int *)(param_1 + 0x9c);
    uVar4 = uVar3 + 1;
    iVar2 = iVar1;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar4 = uVar3 + 0x24;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006d27e3;
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  *(undefined4 *)(param_1 + 0xac) = 0;
  *(undefined4 *)(param_1 + 0xb0) = 0xf;
  *(undefined *)(param_1 + 0x9c) = 0;
  FUN_006b35b0();
  FUN_00577a40();
  FUN_006d1f70();
  FUN_00617bc0();
  FUN_006d3f40();
  iVar1 = *(int *)(param_1 + 0x4c);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x54) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006d27e3;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x4c) = 0;
    *(undefined4 *)(param_1 + 0x50) = 0;
    *(undefined4 *)(param_1 + 0x54) = 0;
  }
  iVar1 = *(int *)(param_1 + 0x34);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x3c) - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006d27e3;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x34) = 0;
    *(undefined4 *)(param_1 + 0x38) = 0;
    *(undefined4 *)(param_1 + 0x3c) = 0;
  }
  iVar1 = *(int *)(param_1 + 0x1c);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x24) - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_006d27e3;
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0x1c) = 0;
    *(undefined4 *)(param_1 + 0x20) = 0;
    *(undefined4 *)(param_1 + 0x24) = 0;
  }
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0xc) - iVar1 & 0xfffffff0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_006d27e3:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 4) = 0;
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)(param_1 + 0xc) = 0;
  }
  return;
}



/* FUNCTION 9230 ; VA 0x006d27f0 ; FUN_006d27f0 */

void __fastcall FUN_006d27f0(int *param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = (int *)param_1[2];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar3 = *param_1;
  if (iVar3 != 0) {
    piVar2 = (int *)(iVar3 + 4);
    LOCK();
    iVar1 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar1 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  return;
}



/* FUNCTION 9231 ; VA 0x006d2840 ; FUN_006d2840 */

void __fastcall FUN_006d2840(int param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  iVar5 = *(int *)(param_1 + 0xc4);
  if (iVar5 != 0) {
    iVar4 = *(int *)(param_1 + 200);
    if (iVar5 != iVar4) {
      do {
        FUN_006129a0();
        iVar5 = iVar5 + 0x18;
      } while (iVar5 != iVar4);
      iVar5 = *(int *)(param_1 + 0xc4);
    }
    uVar3 = ((*(int *)(param_1 + 0xcc) - iVar5) / 0x18) * 0x18;
    iVar4 = iVar5;
    if (0xfff < uVar3) {
      iVar4 = *(int *)(iVar5 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar5 - iVar4) - 4U) goto LAB_006d29b2;
    }
    FUN_01674ea0(iVar4,uVar3);
    *(undefined4 *)(param_1 + 0xc4) = 0;
    *(undefined4 *)(param_1 + 200) = 0;
    *(undefined4 *)(param_1 + 0xcc) = 0;
  }
  piVar2 = *(int **)(param_1 + 0xc0);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar5 = piVar2[1] + -1;
    piVar2[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar5 = *(int *)(param_1 + 0xb0);
  if (iVar5 != 0) {
    uVar3 = *(int *)(param_1 + 0xb8) - iVar5 & 0xfffffffc;
    iVar4 = iVar5;
    if (0xfff < uVar3) {
      iVar4 = *(int *)(iVar5 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar5 - iVar4) - 4U) {
LAB_006d29b2:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar3);
    *(undefined4 *)(param_1 + 0xb0) = 0;
    *(undefined4 *)(param_1 + 0xb4) = 0;
    *(undefined4 *)(param_1 + 0xb8) = 0;
  }
  FUN_006129a0();
  FUN_006c8890();
  FUN_006c8890();
  FUN_006c8a80();
  FUN_006c8a80();
  FUN_006c8a80();
  thunk_FUN_006c8f00();
  thunk_FUN_006c8f00();
  thunk_FUN_006c8f00();
  return;
}



/* FUNCTION 9232 ; VA 0x006d29c0 ; FUN_006d29c0 */

void __fastcall FUN_006d29c0(int param_1)

{
  CloseHandle(*(undefined4 *)(param_1 + 0xc));
  CloseHandle(*(undefined4 *)(param_1 + 4));
  CloseHandle(*(undefined4 *)(param_1 + 8));
  return;
}



/* FUNCTION 9233 ; VA 0x006d29e0 ; FUN_006d29e0 */

undefined __thiscall FUN_006d29e0(float *param_1,float *param_2)

{
  if ((((NAN(*param_1) || NAN(*param_2)) != (*param_1 == *param_2)) &&
      ((NAN(param_1[1]) || NAN(param_2[1])) != (param_1[1] == param_2[1]))) &&
     ((NAN(param_1[2]) || NAN(param_2[2])) != (param_1[2] == param_2[2]))) {
    return 1;
  }
  return 0;
}



/* FUNCTION 9234 ; VA 0x006d2a20 ; FUN_006d2a20 */

undefined4 * __thiscall FUN_006d2a20(int *param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int *piStack_8;
  
  piVar1 = param_2;
  puVar3 = (undefined4 *)*param_1;
  puVar5 = puVar3;
  puVar6 = (undefined4 *)puVar3[1];
  piStack_8 = param_1;
  if (*(char *)((int)puVar3[1] + 0xd) == '\0') {
    do {
      puVar5 = puVar6;
      cVar2 = FUN_009c8f70(piVar1);
      if (cVar2 == '\0') {
        puVar6 = (undefined4 *)*puVar5;
      }
      else {
        puVar6 = (undefined4 *)puVar5[2];
        puVar5 = puVar3;
      }
      puVar3 = puVar5;
    } while (*(char *)((int)puVar6 + 0xd) == '\0');
    puVar3 = (undefined4 *)*piStack_8;
  }
  if ((puVar5 != puVar3) && (cVar2 = FUN_009c8f70(puVar5 + 4), cVar2 == '\0')) {
    return puVar5 + 6;
  }
  piStack_8 = piVar1;
  iVar4 = FUN_006cde80(&DAT_018bdeda,&piStack_8,(int)&param_2 + 3);
  FUN_006cebb0(&param_2,puVar5,iVar4 + 0x10,iVar4);
  return param_2 + 6;
}



/* FUNCTION 9235 ; VA 0x006d2ac0 ; FUN_006d2ac0 */

undefined4 * __thiscall FUN_006d2ac0(int *param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int *piStack_8;
  
  piVar1 = param_2;
  puVar3 = (undefined4 *)*param_1;
  puVar5 = puVar3;
  puVar6 = (undefined4 *)puVar3[1];
  piStack_8 = param_1;
  if (*(char *)((int)puVar3[1] + 0xd) == '\0') {
    do {
      puVar5 = puVar6;
      cVar2 = FUN_009c8f70(piVar1);
      if (cVar2 == '\0') {
        puVar6 = (undefined4 *)*puVar5;
      }
      else {
        puVar6 = (undefined4 *)puVar5[2];
        puVar5 = puVar3;
      }
      puVar3 = puVar5;
    } while (*(char *)((int)puVar6 + 0xd) == '\0');
    puVar3 = (undefined4 *)*piStack_8;
  }
  if ((puVar5 != puVar3) && (cVar2 = FUN_009c8f70(puVar5 + 4), cVar2 == '\0')) {
    return puVar5 + 6;
  }
  piStack_8 = piVar1;
  iVar4 = FUN_006cdf00(&DAT_018bdeda,&piStack_8,(int)&param_2 + 3);
  FUN_006ced60(&param_2,puVar5,iVar4 + 0x10,iVar4);
  return param_2 + 6;
}



/* FUNCTION 9236 ; VA 0x006d2b60 ; FUN_006d2b60 */

uint * __thiscall FUN_006d2b60(byte *param_1,uint *param_2)

{
  uint *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  undefined4 *puVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a87c8;
  pvStack_10 = ExceptionList;
  uVar5 = *param_2;
  uVar9 = (uVar5 >> 3) + uVar5;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_2,uVar9,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (uint *)0x0) {
    uStack_8 = 0;
    piVar4 = (int *)FUN_01674e20(0x10);
    puVar1 = (uint *)(piVar4 + 2);
    *piVar4 = 0;
    piVar4[1] = 0;
    puVar1[0] = 0;
    puVar1[1] = 0;
    *puVar1 = uVar5;
    if (piVar4 + 3 != (int *)0x0) {
      piVar4[3] = 0;
    }
    uVar2 = *(uint *)(param_1 + 8);
    uVar5 = uVar2 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005c9310(uVar5);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar5) {
      param_2 = (uint *)0x1;
      uVar7 = uVar2 >> 1;
      if ((uVar2 >> 1) + uVar2 <= uVar5) {
        uVar7 = 1;
      }
      iVar6 = FUN_005c9310(uVar7 + uVar2);
      if (iVar6 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar6);
        puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar3 = (undefined4 *)*puVar10;
        while (puVar3 != (undefined4 *)0x0) {
          piVar8 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar8 = (int)puVar10;
            puVar10 = puVar3;
          }
          else {
            *puVar10 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar8;
            *(undefined4 **)*piVar8 = puVar3;
          }
          puVar3 = (undefined4 *)*puVar10;
        }
      }
    }
    piVar4[1] = uVar9;
    uVar9 = uVar9 % *(uint *)(param_1 + 4);
    piVar8 = *(int **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    if (piVar8 == (int *)0x0) {
      piVar8 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar8 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar4;
      }
      *puVar10 = piVar8;
      *piVar4 = *piVar8;
    }
    else {
      *piVar4 = *piVar8;
      piVar8 = (int *)*puVar10;
    }
    *piVar8 = (int)piVar4;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return puVar1;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 9237 ; VA 0x006d2d20 ; FUN_006d2d20 */

uint * __thiscall FUN_006d2d20(byte *param_1,uint *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a87e8;
  pvStack_10 = ExceptionList;
  uVar4 = *param_2;
  uVar8 = (uVar4 >> 3) + uVar4;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_2,uVar8,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (uint *)0x0) {
    uStack_8 = 0;
    piVar3 = (int *)FUN_01674e20(0x4c);
    *piVar3 = 0;
    piVar3[1] = 0;
    piVar3[3] = 0;
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[6] = 0;
    piVar3[7] = 0;
    piVar3[8] = 0;
    piVar3[9] = 0;
    piVar3[10] = 0;
    piVar3[0xb] = 0;
    piVar3[0xc] = 0;
    piVar3[0xd] = 0;
    piVar3[0xe] = 0;
    piVar3[0xf] = 0;
    piVar3[0x10] = 0;
    piVar3[0x11] = 0;
    piVar3[0x12] = 0;
    piVar3[2] = uVar4;
    FUN_0170d1f0(piVar3 + 3,0,0x40);
    piVar3[4] = 0;
    piVar3[5] = 0;
    piVar3[6] = 0;
    piVar3[7] = 0;
    piVar3[8] = 0;
    piVar3[9] = 0;
    piVar3[10] = 0;
    piVar3[0xb] = 0;
    piVar3[0xc] = 0;
    piVar3[0xd] = -1;
    *(undefined2 *)((int)piVar3 + 0x3d) = 0;
    *(undefined *)((int)piVar3 + 0x3f) = 0;
    piVar3[0x10] = 0;
    piVar3[0x11] = 0;
    piVar3[0x12] = 0;
    uVar1 = *(uint *)(param_1 + 8);
    uVar4 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar4 = FUN_005c9310(uVar4);
      if (uVar4 <= *(uint *)(param_1 + 4)) {
        uVar4 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar4);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar4) {
      param_2 = (uint *)0x1;
      uVar6 = uVar1 >> 1;
      if (uVar1 + (uVar1 >> 1) <= uVar4) {
        uVar6 = 1;
      }
      iVar5 = FUN_005c9310(uVar6 + uVar1);
      if (iVar5 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar5);
        puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar9;
        while (puVar2 != (undefined4 *)0x0) {
          piVar7 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar7 = (int)puVar9;
            puVar9 = puVar2;
          }
          else {
            *puVar9 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar7;
            *(undefined4 **)*piVar7 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar9;
        }
      }
    }
    piVar3[1] = uVar8;
    uVar8 = uVar8 % *(uint *)(param_1 + 4);
    piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (piVar7 == (int *)0x0) {
      piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar7 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar3;
      }
      *puVar9 = piVar7;
      *piVar3 = *piVar7;
    }
    else {
      *piVar3 = *piVar7;
      piVar7 = (int *)*puVar9;
    }
    *piVar7 = (int)piVar3;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return (uint *)(piVar3 + 2);
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 9238 ; VA 0x006d2fb0 ; FUN_006d2fb0 */

uint * __thiscall FUN_006d2fb0(byte *param_1,uint *param_2)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  undefined4 *puVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8808;
  pvStack_10 = ExceptionList;
  uVar6 = *param_2;
  uVar9 = (uVar6 >> 3) + uVar6;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_2,uVar9,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (uint *)0x0) {
    ExceptionList = pvStack_10;
    return param_2 + 2;
  }
  uStack_8 = 0;
  piVar5 = (int *)FUN_01674e20(0x18);
  puVar1 = (uint *)(piVar5 + 2);
  *piVar5 = 0;
  piVar5[1] = 0;
  *puVar1 = 0;
  piVar5[3] = 0;
  piVar5[4] = 0;
  piVar5[5] = 0;
  *puVar1 = uVar6;
  piVar5[3] = 0;
  piVar5[4] = 0;
  piVar5[5] = 0;
  uVar3 = *(uint *)(param_1 + 8);
  uVar6 = uVar3 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar6 = FUN_005c9310(uVar6);
    if (uVar6 <= *(uint *)(param_1 + 4)) {
      uVar6 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar6);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar6) {
    param_2 = (uint *)0x1;
    uVar7 = uVar3 >> 1;
    if (uVar3 + (uVar3 >> 1) <= uVar6) {
      uVar7 = 1;
    }
    uVar6 = FUN_005c9310(uVar7 + *(int *)(param_1 + 8));
    param_2 = (uint *)(param_1 + 4);
    if (uVar6 != *param_2) {
      FUN_005d2b00(uVar6);
      puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_2 * 4);
      puVar4 = (undefined4 *)*puVar10;
      while (puVar4 != (undefined4 *)0x0) {
        piVar2 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *param_2) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *param_2) * 4) == 0) {
          *piVar2 = (int)puVar10;
          puVar10 = puVar4;
        }
        else {
          *puVar10 = *puVar4;
          *puVar4 = *(undefined4 *)*piVar2;
          *(undefined4 **)*piVar2 = puVar4;
        }
        puVar4 = (undefined4 *)*puVar10;
      }
    }
  }
  piVar5[1] = uVar9;
  uVar6 = *(uint *)(param_1 + 4);
  piVar2 = (int *)(*(int *)(param_1 + 0x14) + (uVar9 % uVar6) * 4);
  if ((int *)*piVar2 == (int *)0x0) {
    piVar8 = (int *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    if (*piVar8 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % uVar6) * 4) = piVar5;
    }
    *piVar2 = (int)piVar8;
    *piVar5 = *piVar8;
  }
  else {
    *piVar5 = *(int *)*piVar2;
    piVar8 = (int *)*piVar2;
  }
  *piVar8 = (int)piVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return puVar1;
}



/* FUNCTION 9239 ; VA 0x006d31a0 ; FUN_006d31a0 */

undefined4 __thiscall FUN_006d31a0(uint *param_1,undefined4 param_2,uint *param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined auStack_1c [8];
  uint uStack_14;
  uint uStack_10;
  uint uStack_c;
  uint uStack_8;
  
  uStack_14 = *param_1;
  uVar1 = param_1[1];
  if ((((uStack_14 != 0) || (uVar1 != 0x80000000)) &&
      ((uStack_14 != 0xffffffff || (uVar1 != 0x7fffffff)))) &&
     ((uStack_14 != 0xfffffffe || (uVar1 != 0x7fffffff)))) {
    uVar1 = *param_3;
    uVar2 = param_3[1];
    if (((uVar1 != 0) || (uVar2 != 0x80000000)) &&
       (((uVar1 != 0xffffffff || (uVar2 != 0x7fffffff)) &&
        ((uVar1 != 0xfffffffe || (uVar2 != 0x7fffffff)))))) {
      FUN_005ef640(0,0,0,uStack_14 - *param_3,
                   (param_1[1] - param_3[1]) - (uint)(uStack_14 < *param_3));
      return param_2;
    }
  }
  uStack_10 = param_1[1];
  uStack_c = *param_3;
  uStack_8 = param_3[1];
  piVar5 = (int *)FUN_00602640(auStack_1c,&uStack_c);
  iVar3 = *piVar5;
  iVar4 = piVar5[1];
  if ((iVar3 == -2) && (iVar4 == 0x7fffffff)) {
    FUN_0056b510(0);
    return param_2;
  }
  if ((iVar3 == 0) && (iVar4 == -0x80000000)) {
    FUN_0056b510(1);
    return param_2;
  }
  if ((iVar3 != -1) || (uVar6 = 2, iVar4 != 0x7fffffff)) {
    uVar6 = 5;
  }
  FUN_0056b510(uVar6);
  return param_2;
}



/* FUNCTION 9240 ; VA 0x006d32d0 ; FUN_006d32d0 */

void __thiscall FUN_006d32d0(float *param_1,float *param_2,float *param_3)

{
  *param_2 = *param_1 - *param_3;
  param_2[1] = param_1[1] - param_3[1];
  param_2[2] = param_1[2] - param_3[2];
  return;
}



/* FUNCTION 9241 ; VA 0x006d3310 ; FUN_006d3310 */

void __thiscall FUN_006d3310(float *param_1,float *param_2,float *param_3)

{
  *param_2 = *param_3 + *param_1;
  param_2[1] = param_3[1] + param_1[1];
  param_2[2] = param_3[2] + param_1[2];
  return;
}



/* FUNCTION 9242 ; VA 0x006d3350 ; FUN_006d3350 */

void FUN_006d3350(undefined4 *param_1,int param_2)

{
  if (param_2 != 0) {
    do {
      *param_1 = 0;
      param_1[1] = 0;
      param_1[2] = 0;
      param_1 = param_1 + 3;
      param_2 = param_2 + -1;
    } while (param_2 != 0);
  }
  return;
}



/* FUNCTION 9243 ; VA 0x006d3380 ; FUN_006d3380 */

int * __thiscall FUN_006d3380(uint *param_1,uint param_2)

{
  int iVar1;
  uint uVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint uVar5;
  bool bVar6;
  bool bVar7;
  void **ppvVar8;
  char cVar9;
  int iVar10;
  int *piVar11;
  int *piVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8830;
  pvStack_10 = ExceptionList;
  piVar11 = (int *)*param_1;
  uVar2 = *(uint *)((int)piVar11 + 4);
  if (*(int *)((int)piVar11 + 8) != 0) {
    piVar11 = *(int **)((int)piVar11 + 0x14);
    puVar3 = *(undefined4 **)((int)piVar11 + param_2 * 4);
    ppvVar8 = &pvStack_10;
    if (puVar3 == (undefined4 *)0x0) {
      piVar12 = (int *)0x0;
    }
    else {
      piVar12 = (int *)*puVar3;
    }
    do {
      ExceptionList = ppvVar8;
      if (piVar12 == (int *)0x0) {
        ExceptionList = pvStack_10;
        return (int *)(uint)piVar11;
      }
      cVar9 = FUN_00621710();
      if (cVar9 == '\0') {
        uVar4 = param_1[1];
        if ((uint)((piVar12[0x11] - piVar12[0x10]) / 0xc) <= uVar4) goto LAB_006d36f1;
        if ((DAT_01d5b840 == '\0') || (*(char *)((int)piVar12 + 0x3f) == '\0')) {
          iVar10 = piVar12[0x10];
          if (*(char *)(iVar10 + 8 + uVar4 * 0xc) != '\0') goto LAB_006d358c;
        }
        else {
          iVar10 = piVar12[0x10];
LAB_006d358c:
          *(undefined4 *)(iVar10 + 4 + uVar4 * 0xc) = 0;
          *(undefined *)(iVar10 + 8 + uVar4 * 0xc) = 0;
          if ((DAT_01d5b840 == '\0') || (*(char *)((int)piVar12 + 0x3f) == '\0')) {
            piVar12[0xe] = piVar12[0xe] + -1;
          }
          if (DAT_01d5b7f8 == '\0') {
            *(undefined2 *)(iVar10 + 9 + uVar4 * 0xc) = 0;
            *(undefined4 *)(iVar10 + uVar4 * 0xc) = 0;
          }
        }
        if ((DAT_01d5b840 == '\0') || (*(char *)((int)piVar12 + 0x3f) == '\0')) {
          iVar10 = piVar12[0xe];
        }
        else {
          iVar10 = *(int *)(*param_1 + 0x218);
        }
        if (0 < iVar10) {
          iVar1 = piVar12[0x10] + param_1[1] * 0xc;
          iVar10 = iVar1 + 0xc;
          FUN_0170cc70(iVar1,iVar10,piVar12[0x11] - iVar10);
          piVar12[0x11] = piVar12[0x11] + -0xc;
        }
        if ((DAT_01d5b840 == '\0') || (*(char *)((int)piVar12 + 0x3f) == '\0')) {
          iVar10 = piVar12[0xe];
        }
        else {
          iVar10 = *(int *)(*param_1 + 0x218);
        }
        if (iVar10 < 1) {
          uVar4 = param_1[2];
          iVar10 = FUN_016dee6d(uVar4);
          if (iVar10 != 0) {
            FUN_016df3c9(iVar10);
          }
          uStack_8 = 2;
          if ((DAT_01d5b840 == '\0') || (*(char *)((int)piVar12 + 0x3f) == '\0')) {
            iVar10 = piVar12[0xe];
          }
          else {
            iVar10 = *(int *)(*param_1 + 0x218);
          }
          if (iVar10 < 1) {
            if ((DAT_01d5b820 != '\0') && (*(int *)(*param_1 + 0x1c) != 0)) {
              FUN_006cc9d0(piVar12 + 3);
            }
            FUN_006dc8d0();
            uVar5 = param_1[3];
            piVar11 = *(int **)(uVar5 + 4);
            if (*(int **)(uVar5 + 8) == piVar11) {
              FUN_006030d0(piVar11,piVar12 + 2);
            }
            else {
              *piVar11 = piVar12[2];
              *(int *)(uVar5 + 4) = *(int *)(uVar5 + 4) + 4;
            }
          }
          uStack_8 = 3;
          iVar10 = FUN_016deec8(uVar4);
          if (iVar10 != 0) {
            FUN_016df3c9(iVar10);
          }
          goto LAB_006d36ea;
        }
      }
      else {
        uVar4 = param_1[1];
        uVar5 = (piVar12[0x11] - piVar12[0x10]) / 0xc;
        if ((DAT_01d5b840 == '\0') || (bVar7 = true, *(char *)((int)piVar12 + 0x3f) == '\0')) {
          bVar7 = false;
        }
        if ((uVar4 < uVar5) && (*(char *)(piVar12[0x10] + 8 + uVar4 * 0xc) != '\0')) {
          bVar6 = true;
        }
        else {
          bVar6 = false;
        }
        if (uVar4 < uVar5) {
          *(undefined4 *)(piVar12[0x10] + 4 + uVar4 * 0xc) = 0;
          if (bVar6) {
            uVar4 = param_1[1];
            iVar10 = piVar12[0x10];
            *(undefined *)(iVar10 + 8 + uVar4 * 0xc) = 0;
            if ((DAT_01d5b840 == '\0') || (*(char *)((int)piVar12 + 0x3f) == '\0')) {
              piVar12[0xe] = piVar12[0xe] + -1;
            }
            if (DAT_01d5b7f8 == '\0') {
              *(undefined2 *)(iVar10 + 9 + uVar4 * 0xc) = 0;
              *(undefined4 *)(iVar10 + uVar4 * 0xc) = 0;
            }
          }
          iVar1 = piVar12[0x10] + param_1[1] * 0xc;
          iVar10 = iVar1 + 0xc;
          FUN_0170cc70(iVar1,iVar10,piVar12[0x11] - iVar10);
          piVar12[0x11] = piVar12[0x11] + -0xc;
        }
        if (((bVar7) && (*(int *)(*param_1 + 0x218) < 1)) || ((bVar6 && (piVar12[0xe] < 1)))) {
          uVar4 = param_1[2];
          iVar10 = FUN_016dee6d(uVar4);
          if (iVar10 != 0) {
            FUN_016df3c9(iVar10);
          }
          uStack_8 = 0;
          if ((DAT_01d5b820 != '\0') && (*(int *)(*param_1 + 0x1c) != 0)) {
            FUN_006cc9d0(piVar12 + 3);
          }
          FUN_006dc8d0();
          uVar5 = param_1[3];
          piVar11 = *(int **)(uVar5 + 4);
          if (*(int **)(uVar5 + 8) == piVar11) {
            FUN_006030d0(piVar11,piVar12 + 2);
          }
          else {
            *piVar11 = piVar12[2];
            *(int *)(uVar5 + 4) = *(int *)(uVar5 + 4) + 4;
          }
          uStack_8 = 1;
          iVar10 = FUN_016deec8(uVar4);
          if (iVar10 != 0) {
            FUN_016df3c9(iVar10);
          }
LAB_006d36ea:
          uStack_8 = 0xffffffff;
        }
      }
LAB_006d36f1:
      piVar12 = (int *)*piVar12;
      ppvVar8 = (void **)ExceptionList;
      piVar11 = piVar12;
    } while ((piVar12 == (int *)0x0) ||
            (piVar11 = (int *)((uint)piVar12[1] / uVar2), (uint)piVar12[1] % uVar2 == param_2));
  }
  ExceptionList = pvStack_10;
  return piVar11;
}



/* FUNCTION 9244 ; VA 0x006d3730 ; FUN_006d3730 */

void __thiscall FUN_006d3730(int *param_1,int param_2)

{
  float fVar1;
  char cVar2;
  float fVar3;
  
  cVar2 = *(char *)(param_2 + 0xa8);
  if (cVar2 != '\0') {
    FUN_00ca0e10();
    cVar2 = *(char *)(param_2 + 0xa8);
  }
  fVar1 = *(float *)(param_2 + 0xa4);
  fVar3 = fVar1;
  if (cVar2 != '\0') {
    FUN_00ca0e10();
    fVar3 = *(float *)(param_2 + 0xa4);
  }
  *(float *)(*param_1 + 0x50) = fVar3 * fVar1 + *(float *)(*param_1 + 0x50);
  return;
}



/* FUNCTION 9245 ; VA 0x006d3790 ; FUN_006d3790 */

undefined4 __thiscall FUN_006d3790(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 9246 ; VA 0x006d37b0 ; FUN_006d37b0 */

int __thiscall FUN_006d37b0(int param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *(int *)(param_1 + 0x38);
  if (iVar2 != 0) {
    iVar3 = *(int *)(param_1 + 0x3c);
    if (iVar2 != iVar3) {
      do {
        FUN_00615780(0);
        iVar2 = iVar2 + 4;
      } while (iVar2 != iVar3);
      iVar2 = *(int *)(param_1 + 0x38);
    }
    uVar1 = *(int *)(param_1 + 0x40) - iVar2 & 0xfffffffc;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *(undefined4 *)(param_1 + 0x38) = 0;
    *(undefined4 *)(param_1 + 0x3c) = 0;
    *(undefined4 *)(param_1 + 0x40) = 0;
  }
  FUN_00613200();
  LOCK();
  iVar2 = *(int *)(param_1 + 8);
  *(int *)(param_1 + 8) = 0;
  UNLOCK();
  if (iVar2 != 0) {
    CloseHandle(iVar2);
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x44);
  }
  return param_1;
}



/* FUNCTION 9247 ; VA 0x006d3860 ; FUN_006d3860 */

undefined4 * __thiscall FUN_006d3860(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = (int *)param_1[3];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  *param_1 = RBX::Instance::ICombinedSignalData::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 9248 ; VA 0x006d38b0 ; FUN_006d38b0 */

undefined4 * __thiscall FUN_006d38b0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Instance::ICombinedSignalData::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 9249 ; VA 0x006d38e0 ; FUN_006d38e0 */

undefined4 __thiscall FUN_006d38e0(undefined4 param_1,byte param_2)

{
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x130);
  }
  return param_1;
}


