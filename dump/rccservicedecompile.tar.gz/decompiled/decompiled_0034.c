/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 8500 ; VA 0x006a1690 ; FUN_006a1690 */

int __thiscall
FUN_006a1690(int *param_1,int param_2,int param_3,int param_4,undefined4 param_5,undefined4 param_6,
            undefined4 param_7)

{
  char cVar1;
  int iVar2;
  char cStack0000004c;
  int in_stack_00000050;
  
  if ((((param_2 != 0) && (param_3 != 0)) && (param_1[0x8d] != 0)) &&
     ((*(char *)((int)param_1 + 5) == '\0' && (param_4 != 0)))) {
    if ((cStack0000004c == '\0') && (cVar1 = FUN_0069b550(), cVar1 != '\0')) {
      return 0;
    }
    iVar2 = in_stack_00000050;
    if (in_stack_00000050 == 0) {
      iVar2 = (**(code **)(*param_1 + 0x44))();
    }
    FUN_00677af0(&stack0x0000001c);
    FUN_006a0eb0(param_2,param_3,param_4,param_5,param_6,param_7);
    return iVar2;
  }
  return 0;
}



/* FUNCTION 8501 ; VA 0x006a1720 ; FUN_006a1720 */

void __thiscall FUN_006a1720(int *param_1,int param_2,int param_3)

{
  int iVar1;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  int iStack_8;
  
  if ((param_2 != 0) && (-1 < param_3)) {
    iVar1 = FUN_00697270(param_3,
                         "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                         ,0x559);
    FUN_0170c6f0(*(undefined4 *)(iVar1 + 0x38),param_2,param_3);
    iStack_24 = param_1[0x130];
    iStack_20 = param_1[0x131];
    iStack_1c = param_1[0x132];
    iStack_18 = param_1[0x133];
    iStack_14 = param_1[0x134];
    iStack_10 = param_1[0x135];
    iStack_c = param_1[0x136];
    iStack_8 = param_1[0x137];
    FUN_005f7170(&iStack_24);
    *(int *)(iVar1 + 0x20) = param_1[0x11c];
    *(int *)(iVar1 + 0x24) = param_1[0x11d];
    *(undefined2 *)(iVar1 + 0x28) = *(undefined2 *)(param_1 + 0x11e);
    (**(code **)(*param_1 + 0x104))(iVar1,0);
  }
  return;
}



/* FUNCTION 8502 ; VA 0x006a17b0 ; FUN_006a17b0 */

undefined __thiscall
FUN_006a17b0(int *param_1,char *param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6)

{
  char cVar1;
  undefined uVar2;
  int iVar3;
  undefined auStack_14c [8];
  int iStack_144;
  undefined4 uStack_138;
  undefined auStack_30 [32];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a632b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = (**(code **)(*param_1 + 0x38))();
  if (cVar1 == '\0') {
    ExceptionList = pvStack_10;
    return 0;
  }
  if ((param_2 != (char *)0x0) && (*param_2 != '\0')) {
    FUN_006a5600();
    uStack_8 = 0;
    if ((DAT_01d59d40 != '\0') && (param_1[0x1be] != 0)) {
      FUN_006a67e0(auStack_14c);
    }
    (**(code **)(*param_1 + 0x11c))(auStack_14c);
    if (param_5 != 0) {
      FUN_006a5e80(param_4,param_5);
    }
    iVar3 = FUN_0069a070(param_6);
    FUN_005f7140();
    uVar2 = FUN_005f77c0();
    FUN_005f7750(param_2,param_3,uVar2);
    FUN_005f7320(*(int *)(param_1[0x10e] + iVar3 * 8) + 8);
    FUN_006952f0(**(undefined4 **)(param_1[0x10e] + iVar3 * 8),uStack_138,iStack_144 + 7U >> 3,
                 auStack_30,
                 "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                 ,0xbb1);
    FUN_006a5640();
    ExceptionList = pvStack_10;
    return 1;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 8503 ; VA 0x006a1910 ; FUN_006a1910 */

void __thiscall FUN_006a1910(int param_1,int param_2,uint param_3)

{
  uint uVar1;
  
  uVar1 = 0xff;
  if ((int)param_3 < 0x100) {
    uVar1 = param_3;
  }
  uVar1 = -(uint)(param_2 != 0) & uVar1;
  if (0 < (int)uVar1) {
    FUN_0170c6f0(param_1 + 0x130,param_2,uVar1);
  }
  *(char *)(param_1 + 0x230) = (char)uVar1;
  return;
}



/* FUNCTION 8504 ; VA 0x006a1950 ; FUN_006a1950 */

void __thiscall FUN_006a1950(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0x610) = param_2;
  return;
}



/* FUNCTION 8505 ; VA 0x006a1960 ; FUN_006a1960 */

void __thiscall FUN_006a1960(int param_1,undefined2 param_2)

{
  *(undefined2 *)(param_1 + 0x10) = param_2;
  return;
}



/* FUNCTION 8506 ; VA 0x006a1970 ; FUN_006a1970 */

void __thiscall FUN_006a1970(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0xc) = param_2;
  return;
}



/* FUNCTION 8507 ; VA 0x006a1980 ; FUN_006a1980 */

void FUN_006a1980(int param_1,int param_2)

{
  FUN_00722910();
  FUN_006a5be0();
  if ((param_1 != 0) && (param_2 != 0)) {
    FUN_006a5e80(param_1,param_2);
  }
  FUN_00722920();
  return;
}



/* FUNCTION 8508 ; VA 0x006a19d0 ; FUN_006a19d0 */

void __thiscall FUN_006a19d0(int param_1)

{
  char cVar1;
  ushort uVar2;
  undefined4 in_stack_00000024;
  
  if ((*(int *)(param_1 + 0x234) != 0) && (uVar2 = 0, *(short *)(param_1 + 0xe) != 0)) {
    while( true ) {
      cVar1 = FUN_005f71d0(&stack0x00000004);
      if (cVar1 != '\0') break;
      uVar2 = uVar2 + 1;
      if (*(ushort *)(param_1 + 0xe) <= uVar2) {
        return;
      }
    }
    *(undefined4 *)((uint)uVar2 * 0xb70 + 0xb50 + *(int *)(param_1 + 0x234)) = in_stack_00000024;
  }
  return;
}



/* FUNCTION 8509 ; VA 0x006a1a40 ; FUN_006a1a40 */

void __thiscall FUN_006a1a40(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x480) = param_2;
  return;
}



/* FUNCTION 8510 ; VA 0x006a1a50 ; FUN_006a1a50 */

void __thiscall FUN_006a1a50(int param_1,undefined4 param_2)

{
  ushort uVar1;
  
  uVar1 = 0;
  *(undefined4 *)(param_1 + 0x4ac) = param_2;
  if (*(short *)(param_1 + 0xe) != 0) {
    do {
      FUN_005ffa40(*(undefined4 *)(param_1 + 0x4ac));
      uVar1 = uVar1 + 1;
    } while (uVar1 < *(ushort *)(param_1 + 0xe));
  }
  return;
}



/* FUNCTION 8511 ; VA 0x006a1aa0 ; FUN_006a1aa0 */

void __thiscall
FUN_006a1aa0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10)

{
  char cVar1;
  uint uVar2;
  int iVar3;
  
  cVar1 = FUN_005f71d0(&DAT_01eae4bc);
  if (cVar1 == '\0') {
    iVar3 = FUN_0069a190(param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,0,1);
    if (iVar3 != 0) {
      FUN_005ffa50(param_2);
    }
  }
  else {
    uVar2 = 0;
    *(undefined4 *)(param_1 + 0x46c) = param_2;
    if (*(short *)(param_1 + 0xe) != 0) {
      iVar3 = 0;
      do {
        if (*(char *)(iVar3 + *(int *)(param_1 + 0x234)) != '\0') {
          FUN_005ffa50(param_2);
        }
        uVar2 = uVar2 + 1;
        iVar3 = iVar3 + 0xb70;
      } while (uVar2 < *(ushort *)(param_1 + 0xe));
      return;
    }
  }
  return;
}



/* FUNCTION 8512 ; VA 0x006a1b40 ; FUN_006a1b40 */

void __thiscall FUN_006a1b40(int param_1,undefined4 param_2)

{
  ushort uVar1;
  
  uVar1 = 0;
  *(undefined4 *)(param_1 + 0x4b0) = param_2;
  if (*(short *)(param_1 + 0xe) != 0) {
    do {
      FUN_005ffa60(*(undefined4 *)(param_1 + 0x4b0));
      uVar1 = uVar1 + 1;
    } while (uVar1 < *(ushort *)(param_1 + 0xe));
  }
  return;
}



/* FUNCTION 8513 ; VA 0x006a1b90 ; FUN_006a1b90 */

void __thiscall FUN_006a1b90(int param_1,undefined4 param_2,undefined4 param_3)

{
  *(undefined4 *)(param_1 + 0x604) = param_2;
  *(undefined4 *)(param_1 + 0x608) = param_3;
  return;
}



/* FUNCTION 8514 ; VA 0x006a1bb0 ; FUN_006a1bb0 */

void __thiscall FUN_006a1bb0(int *param_1,uint param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  void **ppvVar4;
  char cVar5;
  uint uVar6;
  char *pcVar7;
  int iVar8;
  undefined4 *puVar9;
  uint uVar10;
  int iVar11;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uVar6 = (uint)*(ushort *)((int)param_1 + 0xe);
  ExceptionList = &pvStack_10;
  uStack_20 = uVar6;
  if (param_2 != 0) {
    uStack_18 = 0;
    ExceptionList = &pvStack_10;
    ppvVar4 = &pvStack_10;
    if (uVar6 != 0) {
      do {
        ExceptionList = ppvVar4;
        iVar8 = param_1[0x8d];
        if (*(char *)(uStack_18 * 0xb70 + iVar8) != '\0') {
          puVar9 = (undefined4 *)(uStack_18 * 0xb70 + 4 + iVar8);
          puVar2 = (undefined4 *)(uStack_18 * 0xb70 + 0x14 + iVar8);
          uStack_1c = uStack_18;
          FUN_0069b580(*puVar9,puVar9[1],puVar9[2],puVar9[3],*puVar2,puVar2[1],puVar2[2],puVar2[3],0
                       ,param_3,param_4,
                       "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                       ,0x414);
        }
        uStack_1c = uStack_18 + 1;
        ppvVar4 = (void **)ExceptionList;
        uStack_18 = uStack_1c;
      } while (uStack_1c < uVar6);
    }
    uStack_1c = FUN_006a6900();
    if (param_2 == 0) {
      param_2._3_1_ = '\0';
      cVar5 = param_2._3_1_;
    }
    else {
      while( true ) {
        uVar10 = 0;
        cStack_11 = '\0';
        cVar5 = '\0';
        if (uVar6 == 0) break;
        pcVar7 = (char *)param_1[0x8d];
        while (*pcVar7 == '\0') {
          uVar10 = uVar10 + 1;
          pcVar7 = pcVar7 + 0xb70;
          cVar5 = cStack_11;
          if (uVar6 <= uVar10) goto LAB_006a1c86;
        }
        cStack_11 = '\x01';
        FUN_00722890(0xf);
        iVar8 = FUN_006a6900();
        cVar5 = cStack_11;
        if (param_2 <= iVar8 - uStack_1c) break;
      }
    }
LAB_006a1c86:
    if ((DAT_01d5b2a0 != '\0') && (cVar5 != '\0')) {
      if (uVar6 != 0) {
        param_2 = 0;
        do {
          iVar8 = param_1[0x8d];
          if (*(char *)(iVar8 + param_2) != '\0') {
            puVar9 = (undefined4 *)(iVar8 + 4 + param_2);
            puVar2 = (undefined4 *)(iVar8 + 0x14 + param_2);
            FUN_0069b580(*puVar9,puVar9[1],puVar9[2],puVar9[3],*puVar2,puVar2[1],puVar2[2],puVar2[3]
                         ,1,param_3,param_4,
                         "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                         ,0x43e);
          }
          param_2 = param_2 + 0xb70;
          uVar6 = uVar6 - 1;
        } while (uVar6 != 0);
      }
      FUN_00722890(0xf);
    }
  }
  if ((DAT_01d5b280 == '\0') && (uStack_18 = 0, param_1[0xb7] != 0)) {
    do {
      (**(code **)(**(int **)(param_1[0xb6] + uStack_18 * 4) + 0x18))();
      uStack_18 = uStack_18 + 1;
    } while (uStack_18 < (uint)param_1[0xb7]);
  }
  uStack_18 = 0;
  if (param_1[0xba] != 0) {
    do {
      (**(code **)(**(int **)(param_1[0xb9] + uStack_18 * 4) + 0x18))();
      uStack_18 = uStack_18 + 1;
    } while (uStack_18 < (uint)param_1[0xba]);
  }
  param_1[0x8f] = 0;
  FUN_007229d0();
  LOCK();
  *(undefined *)((int)param_1 + 5) = 1;
  UNLOCK();
  uStack_18 = 0;
  if (param_1[0x10f] != 0) {
    do {
      piVar1 = (int *)(param_1[0x10e] + uStack_18 * 8);
      iVar8 = *piVar1;
      uStack_40 = *(undefined4 *)(iVar8 + 8);
      uStack_3c = *(undefined4 *)(iVar8 + 0xc);
      uStack_38 = *(undefined4 *)(iVar8 + 0x10);
      uStack_34 = *(undefined4 *)(iVar8 + 0x14);
      uStack_30 = *(undefined4 *)(iVar8 + 0x18);
      uStack_2c = *(undefined4 *)(iVar8 + 0x1c);
      uStack_28 = *(undefined4 *)(iVar8 + 0x20);
      uStack_24 = *(undefined4 *)(iVar8 + 0x24);
      iVar8 = FUN_006952f0(*(undefined4 *)*piVar1,&uStack_18,1,&uStack_40,
                           "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                           ,0x463);
      if (iVar8 != 0) break;
      uStack_18 = uStack_18 + 1;
    } while (uStack_18 < (uint)param_1[0x10f]);
  }
  while (*(char *)((int)param_1 + 6) != '\0') {
    LOCK();
    *(undefined *)((int)param_1 + 5) = 1;
    UNLOCK();
    FUN_00722890(0xf);
  }
  iVar8 = FUN_006a6900();
  while ((param_1[2] != 0 && (uVar6 = FUN_006a6900(), uVar6 < iVar8 + 1000U))) {
    uStack_18 = 0;
    if (param_1[0x10f] != 0) {
      do {
        piVar1 = (int *)(param_1[0x10e] + uStack_18 * 8);
        iVar11 = *piVar1;
        uStack_60 = *(undefined4 *)(iVar11 + 8);
        uStack_5c = *(undefined4 *)(iVar11 + 0xc);
        uStack_58 = *(undefined4 *)(iVar11 + 0x10);
        uStack_54 = *(undefined4 *)(iVar11 + 0x14);
        uStack_50 = *(undefined4 *)(iVar11 + 0x18);
        uStack_4c = *(undefined4 *)(iVar11 + 0x1c);
        uStack_48 = *(undefined4 *)(iVar11 + 0x20);
        uStack_44 = *(undefined4 *)(iVar11 + 0x24);
        FUN_006952f0(*(undefined4 *)*piVar1,&uStack_18,1,&uStack_60,
                     "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                     ,0x473);
        uStack_18 = uStack_18 + 1;
      } while (uStack_18 < (uint)param_1[0x10f]);
    }
    FUN_00722890(0x1e);
  }
  uStack_18 = 0;
  if ((uStack_20 & 0xffff) != 0) {
    do {
      *(undefined *)(uStack_18 * 0xb70 + param_1[0x8d]) = 0;
      FUN_005fec80(0,*(undefined4 *)(uStack_18 * 0xb70 + 0xb40 + param_1[0x8d]),0);
      iVar11 = uStack_18 * 0xb70;
      iVar8 = param_1[0x8d];
      *(undefined4 *)(iVar11 + 0xb44 + iVar8) = 0;
      piVar1 = *(int **)(iVar11 + 0xb48 + iVar8);
      *(undefined4 *)(iVar11 + 0xb48 + iVar8) = 0;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar8 = piVar1[1] + -1;
        piVar1[1] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar8 = piVar1[2] + -1;
          piVar1[2] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      uStack_18 = uStack_18 + 1;
    } while (uStack_18 < (uStack_20 & 0xffff));
  }
  *(undefined2 *)((int)param_1 + 0xe) = 0;
  FUN_00722910();
  uStack_18 = 0;
  while( true ) {
    uVar6 = param_1[0x197];
    if ((uint)param_1[0x198] < uVar6) {
      iVar8 = param_1[0x199] - uVar6;
    }
    else {
      iVar8 = -uVar6;
    }
    if ((uint)(param_1[0x198] + iVar8) <= uStack_18) break;
    if (uStack_18 + uVar6 < (uint)param_1[0x199]) {
      (**(code **)(*param_1 + 0x60))(*(undefined4 *)(param_1[0x196] + (uStack_18 + uVar6) * 4));
      uStack_18 = uStack_18 + 1;
    }
    else {
      (**(code **)(*param_1 + 0x60))
                (*(undefined4 *)(param_1[0x196] + ((uStack_18 - param_1[0x199]) + uVar6) * 4));
      uStack_18 = uStack_18 + 1;
    }
  }
  if (param_1[0x199] != 0) {
    if (0x20 < (uint)param_1[0x199]) {
      FUN_01674ea0(param_1[0x196]);
      param_1[0x199] = 0;
    }
    param_1[0x197] = 0;
    param_1[0x198] = 0;
  }
  FUN_00722920();
  if (DAT_01d5b250 == '\0') {
    iVar8 = param_1[0x1a3];
    while (iVar8 != 0) {
      if ((int *)param_1[0x19f] == (int *)0x0) {
        iVar11 = 0;
      }
      else {
        iVar11 = *(int *)param_1[0x19f];
      }
      uVar3 = *(undefined4 *)
               (*(int *)(*(int *)(iVar11 + 4) +
                        (*(int *)(iVar11 + 8) - 1U & (uint)param_1[0x1a2] >> 2) * 4) +
               (param_1[0x1a2] & 3U) * 4);
      param_1[0x1a3] = iVar8 + -1;
      if (iVar8 + -1 == 0) {
        param_1[0x1a2] = 0;
      }
      else {
        param_1[0x1a2] = param_1[0x1a2] + 1;
      }
      (**(code **)(*param_1 + 0x60))(uVar3);
      iVar8 = param_1[0x1a3];
    }
  }
  else {
    iVar8 = param_1[0x19e];
    while (iVar8 != 0) {
      puVar9 = (undefined4 *)param_1[0x19a];
      if (puVar9 != (undefined4 *)0x0) {
        puVar9 = (undefined4 *)*puVar9;
      }
      uVar3 = **(undefined4 **)(puVar9[1] + (puVar9[2] - 1 & param_1[0x19d]) * 4);
      param_1[0x19e] = iVar8 + -1;
      if (iVar8 + -1 == 0) {
        param_1[0x19d] = 0;
      }
      else {
        param_1[0x19d] = param_1[0x19d] + 1;
      }
      (**(code **)(*param_1 + 0x60))(uVar3);
      iVar8 = param_1[0x19e];
    }
  }
  FUN_00722910();
  FUN_005f9da0("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
               ,0x4a6);
  FUN_00722920();
  if (param_1[2] != 0) {
    iVar8 = FUN_006a6900();
    while ((param_1[2] != 0 && (uVar6 = FUN_006a6900(), uVar6 < iVar8 + 1000U))) {
      FUN_00722890(0x1e);
    }
  }
  FUN_00698da0();
  FUN_00698240();
  FUN_00698420();
  FUN_00698070("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
               ,0x1186);
  param_1[0xa5] = 0;
  param_1[0xa4] = 0;
  FUN_00698530();
  iVar8 = param_1[0x8d];
  param_1[0x8d] = 0;
  if (iVar8 != 0) {
    uStack_8 = 0;
    FUN_016f32d1(iVar8,0xb70,*(undefined4 *)(iVar8 + -4),FUN_00696980);
    FUN_01674ea0((int *)(iVar8 + -4),*(int *)(iVar8 + -4) * 0xb70 + 4);
    uStack_8 = 0xffffffff;
  }
  FUN_01674ea0(param_1[0x8e]);
  param_1[0x8e] = 0;
  FUN_005f9da0("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
               ,0xfa5);
  FUN_01674ea0(param_1[0x91]);
  param_1[0x91] = 0;
  FUN_00722910();
  param_1[0x1aa] = 1;
  FUN_00722920();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8515 ; VA 0x006a2280 ; FUN_006a2280 */

undefined4 __thiscall FUN_006a2280(int *param_1,uint param_2,uint param_3,uint param_4,uint param_5)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  short sVar4;
  int iVar5;
  uint *puVar6;
  undefined4 *puVar7;
  int iVar8;
  char *pcVar9;
  uint uVar10;
  undefined4 uVar11;
  undefined2 *puVar12;
  uint uVar13;
  undefined4 auStack_144 [64];
  undefined auStack_44 [24];
  uint *puStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  uint uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  iVar5 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6394;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_28 = FUN_01675290(DAT_01eae558);
  uStack_8 = 0;
  cVar3 = (**(code **)(*param_1 + 0x38))();
  if (cVar3 == '\0') {
    iStack_20 = 0;
    if (param_5 != -99999) {
      iStack_20 = param_5;
    }
    thunk_FUN_00694bc0(param_1 + 0x130);
    if ((param_3 == 0) || (param_4 == 0)) {
      uVar11 = 2;
    }
    else if ((ushort)param_2 == 0) {
      uVar11 = 3;
    }
    else {
      FUN_00698da0();
      param_5 = 0;
      uStack_1c = 0;
      param_3 = 0;
      if (param_4 != 0) {
        puVar12 = (undefined2 *)(iVar5 + 0x44);
        do {
          pcVar9 = (char *)0x0;
          if (*(char *)(puVar12 + -0x21) != '\0') {
            pcVar9 = (char *)(puVar12 + -0x21);
          }
          if (((DAT_01d5a538 != '\0') && (pcVar9 != (char *)0x0)) && (puVar12[-0x22] == 0)) {
            puVar12[-0x22] = (short)uStack_1c;
          }
          if (DAT_01d5b1e4 == '\0') {
            if ((puVar12[-0x22] == 0) ||
               (cVar3 = FUN_00694ea0(puVar12[-0x22],pcVar9,*puVar12), cVar3 != '\x01')) {
LAB_006a23ba:
              puStack_2c = (uint *)FUN_01674e20(0x30);
              uStack_8._0_1_ = 5;
              if (puStack_2c == (uint *)0x0) {
                uVar11 = 0;
              }
              else {
                uVar11 = FUN_007228a0();
              }
              uStack_8._0_1_ = 0;
              piStack_18 = (int *)0x0;
              piStack_14 = (int *)0x0;
              FUN_00695c30(uVar11,param_2);
              uStack_8 = CONCAT31(uStack_8._1_3_,6);
              iVar5 = FUN_006946b0(puVar12[-0x22],1,pcVar9,100,*puVar12);
              *piStack_18 = iVar5;
              if (iVar5 == -1) {
                FUN_00698da0();
                uVar11 = 6;
              }
              else {
                FUN_00694d80(iVar5,piStack_18 + 2);
                if (((DAT_01d5a538 != '\0') && (pcVar9 != (char *)0x0)) && ((short)uStack_1c == 0))
                {
                  uStack_1c = FUN_005f7810();
                  uStack_1c = uStack_1c & 0xffff;
                }
                piStack_18[1] = param_3;
                if ((DAT_01d5b1e4 == '\0') && (pcVar9 == (char *)0x0)) {
                  FUN_005f7a60(4);
                }
                uStack_24 = 0;
                iVar5 = FUN_006952f0(*piStack_18,&uStack_24,4,piStack_18 + 2,
                                     "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                                     ,0x253);
                if (iVar5 == 0) {
                  FUN_0069b020(&piStack_18,
                               "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                               ,0x261);
                  uStack_8 = uStack_8 & 0xffffff00;
                  FUN_00550b30();
                  goto LAB_006a24c9;
                }
                uVar11 = GetLastError();
                if (DAT_01ee420a != '\0') {
                  puVar7 = (undefined4 *)FUN_016757a0(auStack_44,uVar11);
                  uStack_8._0_1_ = 8;
                  if (0xf < (uint)puVar7[5]) {
                    puVar7 = (undefined4 *)*puVar7;
                  }
                  uVar11 = FUN_005f7ae0(1,0x7c);
                  FUN_01677520(DAT_01ee420a,"Socket send test failed. Tried to connect to %s, %s",
                               uVar11,puVar7);
                  uStack_8 = CONCAT31(uStack_8._1_3_,6);
                  FUN_005507b0();
                }
                FUN_00698da0();
                uVar11 = 7;
              }
              piVar2 = piStack_14;
              if (piStack_14 != (int *)0x0) {
                LOCK();
                iVar5 = piStack_14[1] + -1;
                piStack_14[1] = iVar5;
                UNLOCK();
                if (iVar5 == 0) {
                  (**(code **)*piStack_14)();
                  LOCK();
                  piVar1 = piVar2 + 2;
                  iVar5 = *piVar1;
                  *piVar1 = *piVar1 + -1;
                  UNLOCK();
                  if (iVar5 == 1) {
                    (**(code **)(*piVar2 + 4))();
                  }
                }
              }
            }
            else {
              FUN_00698da0();
              uVar11 = 5;
            }
            goto LAB_006a2932;
          }
          cVar3 = FUN_00695040(pcVar9,*puVar12);
          if ((cVar3 != '\0') &&
             ((puVar12[-0x22] == 0 ||
              (cVar3 = FUN_00694ea0(puVar12[-0x22],pcVar9,*puVar12), cVar3 != '\x01')))) {
            param_5 = param_5 + 1;
            goto LAB_006a23ba;
          }
LAB_006a24c9:
          puVar12 = puVar12 + 0x23;
          param_3 = param_3 + 1;
        } while (param_3 < param_4);
      }
      if (*(short *)((int)param_1 + 0xe) == 0) {
        if ((ushort)param_2 < *(ushort *)(param_1 + 4)) {
          *(ushort *)(param_1 + 4) = (ushort)param_2;
        }
        uVar13 = param_2 & 0xffff;
        *(ushort *)((int)param_1 + 0xe) = (ushort)param_2;
        if (uVar13 == 0) {
          puVar6 = (uint *)0x0;
        }
        else {
          puStack_2c = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar13 * 0xb70) |
                                            uVar13 * 0xb70 + 4);
          uStack_8._0_1_ = 0xb;
          if (puStack_2c == (uint *)0x0) {
            puVar6 = (uint *)0x0;
          }
          else {
            *puStack_2c = uVar13;
            puVar6 = puStack_2c + 1;
            FUN_016f4053(puVar6,0xb70,uVar13,FUN_006963c0,FUN_00696980);
          }
          param_2._0_2_ = *(ushort *)((int)param_1 + 0xe);
          uStack_8 = (uint)uStack_8._1_3_ << 8;
        }
        param_1[0x8d] = (int)puVar6;
        if ((ushort)param_2 == 0) {
          iVar5 = 0;
          uVar13 = 0;
        }
        else {
          iVar5 = FUN_01674e20((int)((ulonglong)(ushort)param_2 << 5));
          uVar13 = (uint)*(ushort *)((int)param_1 + 0xe);
        }
        sVar4 = (short)uVar13;
        param_1[0x91] = iVar5;
        iVar5 = 0;
        if (uVar13 != 0) {
          iVar5 = FUN_01674e20(uVar13 * 4);
          sVar4 = *(short *)((int)param_1 + 0xe);
        }
        param_1[0x8e] = iVar5;
        if (sVar4 == 0) {
          uVar13 = (uint)*(ushort *)((int)param_1 + 0xe);
        }
        else {
          iVar5 = 0;
          uVar10 = 0;
          do {
            *(undefined *)(iVar5 + param_1[0x8d]) = 0;
            FUN_005f7170(&DAT_01eae4bc);
            iVar8 = param_1[0x8d];
            *(undefined4 *)(iVar8 + 0xb30 + iVar5) = DAT_01d5b1f0;
            *(undefined4 *)(iVar8 + 0xb34 + iVar5) = DAT_01d5b1f4;
            *(undefined2 *)(iVar8 + 0xb38 + iVar5) = DAT_01d5b1f8;
            FUN_005f7170(&DAT_01eae4bc);
            *(undefined4 *)(iVar5 + 0xb68 + param_1[0x8d]) = 0;
            *(int *)(iVar5 + 0xb40 + param_1[0x8d]) = param_1[0x10b];
            *(short *)(iVar5 + 0xb4c + param_1[0x8d]) = (short)uVar10;
            *(undefined4 *)(iVar5 + 0xb50 + param_1[0x8d]) = 0;
            iVar8 = param_1[0x8d];
            *(undefined4 *)(iVar5 + 0xb58 + iVar8) = 0;
            *(undefined4 *)(iVar5 + 0xb5c + iVar8) = 0;
            iVar8 = param_1[0x8d] + iVar5;
            iVar5 = iVar5 + 0xb70;
            *(int *)(param_1[0x8e] + uVar10 * 4) = iVar8;
            uVar10 = uVar10 + 1;
            uVar13 = (uint)*(ushort *)((int)param_1 + 0xe);
          } while (uVar10 < uVar13);
        }
        uVar10 = 0;
        if (uVar13 != 0) {
          do {
            *(undefined4 *)(param_1[0x91] + uVar10 * 4) = 0;
            uVar10 = uVar10 + 1;
          } while (uVar10 < (uint)*(ushort *)((int)param_1 + 0xe) << 3);
        }
      }
      if (*(char *)((int)param_1 + 5) != '\0') {
        *(undefined *)(param_1 + 0xa3) = 0;
        LOCK();
        *(undefined *)((int)param_1 + 5) = 0;
        UNLOCK();
        FUN_00698240();
        FUN_00698420();
        FUN_00698070("C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                     ,0x1186);
        if (*(char *)((int)param_1 + 6) == '\0') {
          iVar5 = FUN_00722930(FUN_006a2960,param_1,iStack_20);
          if (iVar5 != 0) {
LAB_006a288f:
            (**(code **)(*param_1 + 0x34))(0,0,3);
            uVar11 = 9;
            goto LAB_006a2932;
          }
          if ((DAT_01d5b1e4 != '\0') && (param_4 = param_5, param_5 == 0)) {
            FUN_00698da0();
            uVar11 = 7;
            goto LAB_006a2932;
          }
          uVar13 = 0;
          if (param_4 != 0) {
            do {
              iVar5 = iStack_20;
              auStack_144[uVar13 * 2] = **(undefined4 **)(param_1[0x10e] + uVar13 * 8);
              auStack_144[uVar13 * 2 + 1] = param_1;
              iVar5 = FUN_00722930(FUN_0069d640,auStack_144 + uVar13 * 2,iVar5);
              if (iVar5 != 0) goto LAB_006a288f;
              uVar13 = uVar13 + 1;
            } while (uVar13 < param_4);
          }
          while ((uint)param_1[2] < param_4) {
            FUN_00722890(10);
          }
        }
        while (*(char *)((int)param_1 + 6) == '\0') {
          FUN_00722890(10);
        }
      }
      if ((DAT_01d5b280 == '\0') && (uVar13 = 0, param_1[0xb7] != 0)) {
        do {
          (**(code **)(**(int **)(param_1[0xb6] + uVar13 * 4) + 0x14))();
          uVar13 = uVar13 + 1;
        } while (uVar13 < (uint)param_1[0xb7]);
      }
      uVar13 = 0;
      if (param_1[0xba] != 0) {
        do {
          (**(code **)(**(int **)(param_1[0xb9] + uVar13 * 4) + 0x14))();
          uVar13 = uVar13 + 1;
        } while (uVar13 < (uint)param_1[0xba]);
      }
      uVar11 = 0;
    }
  }
  else {
    uVar11 = 1;
  }
LAB_006a2932:
  uStack_8 = 0xf;
  FUN_01675290(uStack_28);
  ExceptionList = pvStack_10;
  return uVar11;
}



/* FUNCTION 8516 ; VA 0x006a2960 ; FUN_006a2960 */

undefined4 FUN_006a2960(int *param_1)

{
  undefined auStack_130 [284];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a63b3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_14 = FUN_01675290(DAT_01eae558);
  uStack_8 = 0;
  FUN_0151a220("RakNet::UpdateNetworkLoop");
  FUN_006a54a0(0x5d4);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  LOCK();
  *(undefined *)((int)param_1 + 6) = 1;
  UNLOCK();
  while (*(char *)((int)param_1 + 5) == '\0') {
    if ((code *)param_1[0x181] != (code *)0x0) {
      (*(code *)param_1[0x181])(param_1,param_1[0x182]);
    }
    (**(code **)(*param_1 + 0x174))(0,0,0,0,auStack_130);
    FUN_007229e0(DAT_01d5b160);
  }
  LOCK();
  *(undefined *)((int)param_1 + 6) = 0;
  UNLOCK();
  FUN_006a5640();
  uStack_8 = 2;
  FUN_01675290(uStack_14);
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 8517 ; VA 0x006a2a40 ; FUN_006a2a40 */

void __fastcall FUN_006a2a40(int param_1)

{
  char cVar1;
  undefined *puVar2;
  undefined auStack_10 [11];
  undefined uStack_5;
  
  uStack_5 = 0xd;
  FUN_006a6060(&uStack_5,8,1);
  puVar2 = (undefined *)(param_1 + 0x470);
  cVar1 = FUN_005fda50();
  if (cVar1 == '\0') {
    FUN_006a5c10(puVar2,auStack_10,8);
    puVar2 = auStack_10;
  }
  FUN_006a6060(puVar2,0x40,1);
  FUN_006a5ee0(&DAT_018d94a4,0x10);
  return;
}



/* FUNCTION 8518 ; VA 0x006a2ab0 ; FUN_006a2ab0 */

void __fastcall FUN_006a2ab0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_007228c0();
    FUN_01674ea0(iVar1,0x30);
  }
  return;
}



/* FUNCTION 8519 ; VA 0x006a2ad0 ; FUN_006a2ad0 */

void __fastcall FUN_006a2ad0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    FUN_006969c0();
    FUN_01674ea0(iVar1,0x10);
  }
  return;
}



/* FUNCTION 8520 ; VA 0x006a2af0 ; FUN_006a2af0 */

void __thiscall FUN_006a2af0(int param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  uVar4 = *(uint *)(param_1 + 8);
  uVar1 = 1;
  if (uVar4 != 0) {
    uVar1 = uVar4;
  }
  for (; (uVar3 = uVar1 - uVar4, uVar3 < param_2 || (uVar1 < 8)); uVar1 = uVar1 * 2) {
    if (0xfffffff - uVar1 < uVar1) {
      FUN_00593ce0();
LAB_006a2cc7:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  uVar4 = uVar1 * 4;
  uVar5 = *(uint *)(param_1 + 0xc) >> 2;
  if (uVar1 < 0x40000000) {
    if (0xfff < uVar4) goto LAB_006a2b57;
    if (uVar4 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_01674e20(uVar4);
    }
  }
  else {
    uVar4 = 0xffffffff;
LAB_006a2b57:
    uVar1 = uVar4 + 0x23;
    if (uVar1 <= uVar4) {
      uVar1 = 0xffffffff;
    }
    iVar2 = FUN_01674e20(uVar1);
    if (iVar2 == 0) goto LAB_006a2cc7;
    uVar4 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar4 - 4) = iVar2;
  }
  iVar7 = *(int *)(param_1 + 4);
  iVar8 = uVar5 * 4;
  iVar2 = iVar7 + iVar8;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  iVar7 = (*(int *)(param_1 + 8) * 4 - iVar2) + iVar7;
  FUN_0170cc70(iVar8 + uVar4,iVar2,iVar7);
  iVar7 = iVar7 + iVar8 + uVar4;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  if (uVar3 < uVar5) {
    iVar6 = uVar3 * 4;
    FUN_0170cc70(iVar7,*(undefined4 *)(param_1 + 4),iVar6);
    iVar7 = *(int *)(param_1 + 4);
    iVar2 = iVar6 + iVar7;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    iVar8 = (iVar7 - iVar2) + iVar8;
    FUN_0170cc70(uVar4,iVar2,iVar8);
    FUN_0170d1f0(iVar8 + uVar4,0,iVar6);
  }
  else {
    FUN_0170cc70(iVar7,*(undefined4 *)(param_1 + 4),uVar5 * 4);
    FUN_0170d1f0(iVar7 + iVar8,0,(uVar3 - uVar5) * 4);
    FUN_0170d1f0(uVar4,0,iVar8);
  }
  iVar2 = *(int *)(param_1 + 4);
  if (iVar2 != 0) {
    uVar1 = *(int *)(param_1 + 8) * 4;
    iVar7 = iVar2;
    if (0xfff < uVar1) {
      iVar7 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar7) - 4U) goto LAB_006a2cc7;
    }
    FUN_01674ea0(iVar7,uVar1);
  }
  *(uint *)(param_1 + 4) = uVar4;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + uVar3;
  return;
}



/* FUNCTION 8521 ; VA 0x006a2cd0 ; FUN_006a2cd0 */

undefined4 __thiscall FUN_006a2cd0(int *param_1,undefined1 *param_2,undefined4 param_3)

{
  int *piVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  undefined1 *puVar6;
  int *piVar7;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  int *piStack_34;
  int iStack_30;
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a63f0;
  pvStack_10 = ExceptionList;
  piStack_1c = (int *)0x0;
  iStack_18 = param_1[0x1be];
  piStack_14 = param_1;
  if (iStack_18 == 0) {
    ExceptionList = &pvStack_10;
    iStack_18 = FUN_01674e20(0x10);
    uStack_8 = 1;
    if (iStack_18 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_006a6350(1,0);
    }
    uStack_8 = uStack_8 & 0xffffff00;
    iStack_28 = 0;
    piStack_24 = (int *)0x0;
    FUN_00695d50(uVar5,param_3);
    piVar3 = &iStack_28;
    piVar7 = (int *)0x2;
    iStack_18 = iStack_28;
  }
  else {
    piStack_2c = (int *)param_1[0x1bf];
    ExceptionList = &pvStack_10;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piStack_2c[1] = piStack_2c[1] + 1;
      UNLOCK();
      iStack_18 = param_1[0x1be];
      piStack_2c = (int *)param_1[0x1bf];
    }
    piVar3 = &iStack_30;
    piVar7 = (int *)0x1;
    iStack_30 = iStack_18;
  }
  piVar1 = (int *)piVar3[1];
  *piVar3 = 0;
  piVar3[1] = 0;
  uStack_8 = 2;
  iStack_38 = iStack_18;
  piStack_34 = piVar1;
  if ((((uint)piVar7 & 2) != 0) &&
     (piStack_1c = (int *)((uint)piVar7 & 0xfffffffd), piVar7 = piStack_1c, piStack_24 != (int *)0x0
     )) {
    LOCK();
    iVar4 = piStack_24[1] + -1;
    piStack_24[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar4 = piStack_24[2] + -1;
      piStack_24[2] = iVar4;
      UNLOCK();
      piVar7 = piStack_1c;
      if (iVar4 == 0) {
        (**(code **)(*piStack_24 + 4))();
        piVar7 = piStack_1c;
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if ((((uint)piVar7 & 1) != 0) && (piStack_2c != (int *)0x0)) {
    LOCK();
    iVar4 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar4 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar1[1] = piVar1[1] + 1;
    UNLOCK();
  }
  piStack_14[0x1be] = iStack_18;
  piStack_1c = (int *)piStack_14[0x1bf];
  piStack_14[0x1bf] = (int)piVar1;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar4 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      iVar4 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  cVar2 = (**(code **)(*piStack_14 + 0xe4))(param_2);
  puVar6 = &DAT_018c92b8;
  if (cVar2 == '\0') {
    puVar6 = param_2;
  }
  iVar4 = inet_pton(2,puVar6,&uStack_20);
  if (iVar4 == 0) {
    iVar4 = inet_pton(0x17,puVar6,&uStack_48);
    if (iVar4 == 0) {
      uVar5 = 0xffffffff;
    }
    else {
      uVar5 = FUN_006a63f0(uStack_48,uStack_44,uStack_40,uStack_3c,param_3);
    }
  }
  else {
    uVar5 = FUN_006a6380(uStack_20,param_3);
  }
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[1] + -1;
    piVar1[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar3 = piVar1 + 2;
      iVar4 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
      ExceptionList = pvStack_10;
      return uVar5;
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 8522 ; VA 0x006a2f20 ; FUN_006a2f20 */

undefined8 FUN_006a2f20(void)

{
  uint uVar1;
  uint uVar2;
  uint uStack_c;
  
  if (DAT_01d5b220 == '\0') {
    uStack_c = 0;
  }
  else {
    uStack_c = 2;
  }
  if (DAT_01d5b208 != '\0') {
    uStack_c = uStack_c | 0x40;
  }
  if (DAT_01d5b210 != '\0') {
    uStack_c = uStack_c | 0x100;
  }
  uVar1 = uStack_c | 0x1fc00;
  if ((DAT_01d5b820 != '\0') && (DAT_01d5b228 != '\0')) {
    uVar1 = uStack_c | 0x3fc00;
  }
  uVar2 = uVar1 | 0x9300200;
  if (((DAT_01d5b240 != '\0') && (uVar2 = uVar1 | 0xb300200, DAT_01d5b248 != '\0')) &&
     (DAT_01d5be48 != '\0')) {
    uVar2 = uVar1 | 0x2b300200;
  }
  if (DAT_01d5b258 != '\0') {
    uVar2 = uVar2 | 0x10000000;
  }
  uVar1 = uVar2 | 4;
  if (DAT_01d5b230 != '\0') {
    uVar1 = uVar2 | 0xc;
  }
  uVar2 = uVar1 | 0x40000000;
  if (DAT_01d5b268 != '\0') {
    uVar2 = uVar1 | 0x40000010;
  }
  if (DAT_01d5b270 != '\0') {
    uVar2 = uVar2 | 0x20;
  }
  uVar1 = (uint)(DAT_01d5b278 != '\0');
  if (DAT_01d5b288 != '\0') {
    uVar2 = uVar2 | 0x80;
  }
  if (DAT_01d5b290 != '\0') {
    uVar2 = uVar2 | 0x80000000;
  }
  if ((DAT_01d5b298 != '\0') && (DAT_01d66380 != '\0')) {
    uVar1 = uVar1 | 2;
  }
  return CONCAT44(uVar1,uVar2);
}



/* FUNCTION 8523 ; VA 0x006a3030 ; FUN_006a3030 */

char * FUN_006a3030(undefined4 param_1)

{
  switch(param_1) {
  case 0:
    return "No action";
  case 1:
    return "Disconnect ASAP";
  case 2:
    return "Disconnect ASAP Silently";
  case 3:
    return "Disconnect from no ACK";
  case 4:
    return "Requested Connection";
  case 5:
    return "Handling Connection Request";
  case 6:
    return "Unverified Sender";
  case 7:
    return "Connected";
  default:
    return "Unknown";
  }
}



/* FUNCTION 8524 ; VA 0x006a30c0 ; FUN_006a30c0 */

int __thiscall
FUN_006a30c0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,uint param_10,uint param_11)

{
  uint uVar1;
  uint3 uVar2;
  undefined8 uVar3;
  
  uVar3 = (**(code **)(*param_1 + 0x150))
                    (param_2,param_3,param_4,param_5,param_6,param_7,param_8,param_9);
  uVar1 = (uint)uVar3 & param_10 | (uint)((ulonglong)uVar3 >> 0x20) & param_11;
  uVar2 = (uint3)(uVar1 >> 8);
  if (uVar1 != 0) {
    return CONCAT31(uVar2,1);
  }
  return (uint)uVar2 << 8;
}



/* FUNCTION 8525 ; VA 0x006a3100 ; FUN_006a3100 */

undefined4 __thiscall FUN_006a3100(int param_1,undefined4 param_2)

{
  uint uVar1;
  undefined4 uVar2;
  char cVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  
  FUN_00722910();
  uVar6 = 0;
  while( true ) {
    uVar1 = *(uint *)(param_1 + 0x2f4);
    if (*(uint *)(param_1 + 0x2f8) < uVar1) {
      iVar5 = *(int *)(param_1 + 0x2fc) - uVar1;
    }
    else {
      iVar5 = -uVar1;
    }
    if (*(uint *)(param_1 + 0x2f8) + iVar5 <= uVar6) {
      FUN_00722920();
      return 0;
    }
    uVar4 = uVar1 + uVar6;
    if (*(uint *)(param_1 + 0x2fc) <= uVar4) {
      uVar4 = (uVar1 - *(uint *)(param_1 + 0x2fc)) + uVar6;
    }
    uVar2 = *(undefined4 *)(*(int *)(param_1 + 0x2f0) + uVar4 * 4);
    cVar3 = FUN_005f71d0(param_2);
    if (cVar3 != '\0') break;
    uVar6 = uVar6 + 1;
  }
  FUN_00722920();
  return uVar2;
}



/* FUNCTION 8526 ; VA 0x006a31a0 ; FUN_006a31a0 */

undefined8 __fastcall FUN_006a31a0(int param_1)

{
  char cVar1;
  ushort uVar2;
  
  if ((*(int *)(param_1 + 0x234) != 0) && (uVar2 = 0, *(short *)(param_1 + 0xe) != 0)) {
    do {
      cVar1 = FUN_005f71d0(&stack0x00000004);
      if (cVar1 != '\0') {
        return CONCAT44(*(undefined4 *)((uint)uVar2 * 0xb70 + 0xb5c + *(int *)(param_1 + 0x234)),
                        *(undefined4 *)((uint)uVar2 * 0xb70 + 0xb58 + *(int *)(param_1 + 0x234)));
      }
      uVar2 = uVar2 + 1;
    } while (uVar2 < *(ushort *)(param_1 + 0xe));
  }
  return 0;
}



/* FUNCTION 8527 ; VA 0x006a3220 ; FUN_006a3220 */

undefined4 __fastcall FUN_006a3220(int param_1)

{
  return *(undefined4 *)(param_1 + 0x434);
}



/* FUNCTION 8528 ; VA 0x006a3230 ; FUN_006a3230 */

undefined4 FUN_006a3230(undefined4 param_1,undefined4 param_2,undefined2 param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  FUN_005f70a0();
  FUN_005f7140();
  FUN_005f7170(&stack0x00000014);
  cVar1 = FUN_005f7240(&DAT_01d5b1f0);
  if (cVar1 == '\0') {
    iVar2 = FUN_0069a190(uStack_24,uStack_20,uStack_1c,uStack_18,uStack_14,uStack_10,uStack_c,
                         uStack_8,0,1);
  }
  else {
    iVar2 = FUN_0069a100(param_1,param_2,param_3,uStack_28,1);
  }
  if (iVar2 == 0) {
    return 0;
  }
  return *(undefined4 *)(iVar2 + 0xb64);
}



/* FUNCTION 8529 ; VA 0x006a32d0 ; FUN_006a32d0 */

void __thiscall FUN_006a32d0(int param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x6fc);
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
    iVar1 = *(int *)(param_1 + 0x6fc);
  }
  *param_2 = *(undefined4 *)(param_1 + 0x6f8);
  param_2[1] = iVar1;
  return;
}



/* FUNCTION 8530 ; VA 0x006a3310 ; FUN_006a3310 */

int * __thiscall FUN_006a3310(int param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  int *piVar5;
  ushort uVar6;
  int *piVar7;
  int iVar8;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6408;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  if ((*(int *)(param_1 + 0x234) != 0) &&
     (uVar6 = 0, ExceptionList = &pvStack_10, *(short *)(param_1 + 0xe) != 0)) {
    do {
      if ((*(char *)((uint)uVar6 * 0xb70 + *(int *)(param_1 + 0x234)) != '\0') &&
         (cVar2 = FUN_005f71d0(&stack0x00000008), cVar2 != '\0')) {
        iVar8 = *(int *)(param_1 + 0x234);
        iVar3 = (uint)uVar6 * 0xb70;
        piVar7 = *(int **)(iVar3 + 0x18c + iVar8);
        if (piVar7 != (int *)0x0) {
          LOCK();
          piVar7[1] = piVar7[1] + 1;
          UNLOCK();
          piVar7 = *(int **)(iVar3 + 0x18c + iVar8);
        }
        iVar8 = *(int *)(iVar3 + 0x188 + iVar8);
        uStack_8 = 0;
        iStack_28 = iVar8;
        if ((iVar8 == 0) || (piStack_24 = piVar7, cVar2 = FUN_006871f0(), cVar2 == '\0')) {
          piStack_24 = (int *)0x0;
          piVar5 = &iStack_28;
          uVar4 = 6;
          iVar8 = 0;
        }
        else {
          if (piVar7 != (int *)0x0) {
            LOCK();
            piVar7[1] = piVar7[1] + 1;
            UNLOCK();
          }
          iStack_20 = iVar8;
          piVar5 = &iStack_20;
          piStack_1c = piVar7;
          uVar4 = 5;
        }
        iVar3 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        piVar5 = piStack_24;
        *param_2 = iVar8;
        param_2[1] = iVar3;
        if (((uVar4 & 2) != 0) &&
           (uStack_14 = uVar4 & 0xfffffffd, uVar4 = uStack_14, piStack_24 != (int *)0x0)) {
          LOCK();
          iVar8 = piStack_24[1] + -1;
          piStack_24[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            piVar1 = piVar5 + 2;
            iVar8 = *piVar1 + -1;
            *piVar1 = iVar8;
            UNLOCK();
            uVar4 = uStack_14;
            if (iVar8 == 0) {
              (**(code **)(*piVar5 + 4))();
              uVar4 = uStack_14;
            }
          }
        }
        piVar5 = piStack_1c;
        if (((uVar4 & 1) != 0) && (piStack_1c != (int *)0x0)) {
          LOCK();
          iVar8 = piStack_1c[1] + -1;
          piStack_1c[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piStack_1c)();
            LOCK();
            piVar1 = piVar5 + 2;
            iVar8 = *piVar1 + -1;
            *piVar1 = iVar8;
            UNLOCK();
            if (iVar8 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piVar7 != (int *)0x0) {
          LOCK();
          iVar8 = piVar7[1] + -1;
          piVar7[1] = iVar8;
          UNLOCK();
          if (iVar8 == 0) {
            (**(code **)*piVar7)();
            LOCK();
            piVar5 = piVar7 + 2;
            iVar8 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar8 == 1) {
              (**(code **)(*piVar7 + 4))();
            }
          }
        }
        ExceptionList = pvStack_10;
        return param_2;
      }
      uVar6 = uVar6 + 1;
    } while (uVar6 < *(ushort *)(param_1 + 0xe));
  }
  *param_2 = 0;
  param_2[1] = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 8531 ; VA 0x006a34d0 ; FUN_006a34d0 */

bool FUN_006a34d0(undefined4 param_1,undefined4 param_2,undefined2 param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  FUN_005f70a0();
  FUN_005f7140();
  FUN_005f7170(&stack0x00000014);
  cVar1 = FUN_005f7240(&DAT_01d5b1f0);
  if (cVar1 == '\0') {
    iVar2 = FUN_0069a190(uStack_24,uStack_20,uStack_1c,uStack_18,uStack_14,uStack_10,uStack_c,
                         uStack_8,0,1);
  }
  else {
    iVar2 = FUN_0069a100(param_1,param_2,param_3,uStack_28,1);
  }
  if (iVar2 == 0) {
    return false;
  }
  return *(char *)(iVar2 + 0xb60) != '\0';
}



/* FUNCTION 8532 ; VA 0x006a3570 ; FUN_006a3570 */

uint FUN_006a3570(int param_1)

{
  uint uVar1;
  
  uVar1 = 0;
  do {
    if (param_1 == *(int *)((int)&DAT_018d9498 + uVar1)) {
      return CONCAT31((int3)(uVar1 >> 8),1);
    }
    uVar1 = uVar1 + 4;
  } while (uVar1 < 0xc);
  return uVar1 & 0xffffff00;
}



/* FUNCTION 8533 ; VA 0x006a35a0 ; FUN_006a35a0 */

void FUN_006a35a0(undefined4 param_1,undefined4 param_2)

{
  if (DAT_01ee420a != '\0') {
    FUN_01677520(DAT_01ee420a,"out of memory in raknet file %s, line %ld",param_1,param_2);
  }
  return;
}



/* FUNCTION 8534 ; VA 0x006a35d0 ; FUN_006a35d0 */

undefined FUN_006a35d0(undefined4 param_1,int param_2,uint param_3,undefined4 param_4)

{
  uint uVar1;
  char cVar2;
  undefined uVar3;
  int iVar4;
  undefined auStack_28 [16];
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a616b;
  pvStack_10 = ExceptionList;
  if (param_2 != 0x1c) {
    if (DAT_01eae4ae != '\0') {
      ExceptionList = &pvStack_10;
      FUN_01677520(DAT_01eae4ae,"RbxOpenReply1 has invalid size %d.",param_2);
    }
    ExceptionList = pvStack_10;
    return 0;
  }
  ExceptionList = &pvStack_10;
  FUN_00697e80(&LAB_00696ba1,param_3);
  FUN_006a5530(param_1,0x1c,0);
  uStack_8 = 0;
  FUN_006a57f0(1);
  FUN_006a57f0(0x10);
  FUN_005f70a0();
  cVar2 = FUN_005fda50();
  if (cVar2 == '\0') {
    cVar2 = FUN_006a5ae0(auStack_18,0x40,1);
    if (cVar2 != '\0') {
      FUN_006a5c10(auStack_18,auStack_28,8);
    }
  }
  else {
    FUN_006a5ae0(auStack_28,0x40,1);
  }
  FUN_006a57f0(1);
  cVar2 = FUN_005fda50();
  if (cVar2 == '\0') {
    cVar2 = FUN_006a5ae0(&param_2,0x10,1);
    if (cVar2 != '\0') {
      FUN_006a5c10(&param_2,&param_3,2);
    }
  }
  else {
    FUN_006a5ae0(&param_3,0x10,1);
  }
  if (0 < (int)DAT_01eae4b0) {
    param_3 = DAT_01eae4b0 & 0xffff;
  }
  iVar4 = FUN_006a3100(uVar1);
  if (iVar4 == 0) {
    if (DAT_01eae4ac != '\0') {
      FUN_016774b0(DAT_01eae4ac,"RakNet: OpenReply1 received but cannot find related RCS",0);
    }
    uVar3 = 0;
  }
  else {
    if (DAT_01eae4ac != '\0') {
      FUN_016774b0(DAT_01eae4ac,
                   "RakNet: OpenReply1 received will send OpenRequest2 with mtu size %d",
                   param_3 & 0xffff);
    }
    uVar3 = FUN_006a5040(param_3 & 0xffff,iVar4,uVar1,param_4);
  }
  FUN_006a5640();
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 8535 ; VA 0x006a3790 ; FUN_006a3790 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined __thiscall
FUN_006a3790(int *param_1,undefined4 param_2,uint param_3,undefined4 *param_4,int *param_5,
            undefined4 param_6,undefined4 param_7)

{
  uint uVar1;
  undefined *puVar2;
  char cVar3;
  int iVar4;
  char *pcVar5;
  int *piVar6;
  undefined4 uVar7;
  uint uVar8;
  undefined8 uVar9;
  undefined auStack_230 [288];
  undefined auStack_110 [32];
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  int iStack_70;
  int iStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  int iStack_60;
  int iStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined auStack_4c [8];
  undefined4 uStack_44;
  undefined auStack_40 [7];
  undefined uStack_39;
  uint uStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  int iStack_28;
  undefined uStack_22;
  char cStack_21;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017a6436;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  piStack_30 = param_1;
  puVar2 = &stack0xfffffffc;
  if (DAT_01eae4ac != '\0') {
    ExceptionList = &pvStack_1c;
    FUN_016774b0(DAT_01eae4ac,"RakNet: OpenReply2 received",0);
    puVar2 = puStack_20;
  }
  puStack_20 = puVar2;
  if (param_3 < 0x6b) {
    if (DAT_01eae4ae != '\0') {
      FUN_01677520(DAT_01eae4ae,"RbxOpenReply2 invalid size %d.",param_3);
    }
    ExceptionList = pvStack_1c;
    return 0;
  }
  iStack_28 = FUN_006a3100(param_4);
  if (iStack_28 == 0) {
    if (DAT_01eae4ae != '\0') {
      FUN_016774b0(DAT_01eae4ae,"RbxOpenReply2 unexptected reply",0);
    }
    ExceptionList = pvStack_1c;
    return 1;
  }
  piStack_34 = (int *)(iStack_28 + 0x154);
  if (*piStack_34 == 0) {
    if (DAT_01eae4ae == '\0') {
      ExceptionList = pvStack_1c;
      return 1;
    }
    FUN_016774b0(DAT_01eae4ae,"RbxOpenReply2 no session crypto",0);
    ExceptionList = pvStack_1c;
    return 1;
  }
  FUN_006a5530(param_2,param_3,0);
  uStack_14 = 0;
  FUN_006a57f0(0x11);
  FUN_006a5ae0(&uStack_39,8,1);
  FUN_006a5ae0(&uStack_22,8,1);
  FUN_005f7f10(auStack_4c);
  uStack_14 = 0xffffffff;
  FUN_006a5640();
  FUN_006a5530(param_2,param_3,0);
  uStack_14 = 1;
  cVar3 = FUN_00686760(auStack_230,uStack_22);
  if (cVar3 == '\0') {
    if (DAT_01eae4ae != '\0') {
      FUN_016774b0(DAT_01eae4ae,"RbxOpenReply2 decrypt failed",0);
    }
  }
  else {
    FUN_00697e80(&LAB_00696ba6,param_4);
    FUN_006a57f0(0x15);
    FUN_006a5930(auStack_110,0x20);
    uVar9 = FUN_006a45e0(auStack_230);
    piStack_2c = (int *)((ulonglong)uVar9 >> 0x20);
    uStack_38 = (uint)uVar9;
    if (DAT_01ee420b != '\0') {
      FUN_01677520(DAT_01ee420b,"Peer commonCapabilities: %llx",uVar9);
      uVar9 = CONCAT44(piStack_2c,uStack_38);
    }
    piStack_2c = (int *)((ulonglong)uVar9 >> 0x20);
    uStack_38 = (uint)uVar9;
    FUN_005f70a0();
    FUN_00695a10(&iStack_60);
    FUN_005f7f10(auStack_40);
    FUN_006a5ae0(&uStack_44,8,1);
    FUN_005f7140();
    FUN_00695a70(&uStack_f0);
    uVar9 = FUN_006a2f20(param_1);
    piVar6 = piStack_2c;
    uVar8 = uStack_38;
    uStack_38 = (uint)uVar9 & uStack_38;
    piStack_2c = (int *)((uint)((ulonglong)uVar9 >> 0x20) & (uint)piStack_2c);
    if (DAT_01ee420b != '\0') {
      FUN_01677520(DAT_01ee420b,"Peer has capabilities: 0x%llx ,common capabilities: 0x%llx",uVar8,
                   piVar6,uStack_38,piStack_2c);
    }
    FUN_006863f0(auStack_110,0x20);
    cVar3 = FUN_00687210(uStack_44);
    if ((cVar3 == '\0') && ((char)uStack_44 != '\0')) {
      FUN_00687370(uStack_44);
      uStack_d0 = *param_4;
      uStack_cc = param_4[1];
      uStack_c8 = param_4[2];
      uStack_c4 = param_4[3];
      cStack_21 = '\0';
      uStack_c0 = param_4[4];
      uStack_bc = param_4[5];
      uStack_b8 = param_4[6];
      uStack_b4 = param_4[7];
      cVar3 = FUN_005f71d0(&DAT_01eae4bc);
      if ((cVar3 == '\0') &&
         (((iVar4 = FUN_0069a270(&uStack_d0), iVar4 != -1 &&
           (pcVar5 = (char *)(param_1[0x8d] + iVar4 * 0xb70), *pcVar5 == '\x01')) &&
          (pcVar5 != (char *)0x0)))) {
LAB_006a3b99:
        pcVar5[1] = '\x01';
        pcVar5[0xb68] = '\x04';
        pcVar5[0xb69] = '\0';
        pcVar5[0xb6a] = '\0';
        pcVar5[0xb6b] = '\0';
        if (*(int *)(iStack_28 + 0x144) != 0) {
          FUN_005ffa50(*(int *)(iStack_28 + 0x144));
        }
        FUN_006a4ac0(iStack_28,param_4,param_6,param_7);
      }
      else {
        iStack_70 = iStack_60;
        iStack_6c = iStack_5c;
        uStack_68 = uStack_58;
        uStack_64 = uStack_54;
        piVar6 = (int *)(iStack_28 + 0x14c);
        if (*(int *)(iStack_28 + 0x14c) == 0) {
          piVar6 = param_5;
        }
        uStack_80 = uStack_f0;
        uStack_7c = uStack_ec;
        uStack_78 = uStack_e8;
        uStack_74 = uStack_e4;
        uStack_90 = uStack_e0;
        uStack_8c = uStack_dc;
        uStack_88 = uStack_d8;
        uStack_84 = uStack_d4;
        uStack_a0 = *param_4;
        uStack_9c = param_4[1];
        uStack_98 = param_4[2];
        uStack_94 = param_4[3];
        uStack_b0 = param_4[4];
        uStack_ac = param_4[5];
        uStack_a8 = param_4[6];
        uStack_a4 = param_4[7];
        FUN_00557fc0(piStack_34);
        FUN_00557fc0(piVar6);
        param_1 = piStack_30;
        pcVar5 = (char *)FUN_00697920(uStack_a0,uStack_9c,uStack_98,uStack_94,uStack_b0,uStack_ac,
                                      uStack_a8,uStack_a4,6);
        if (cStack_21 == '\0') {
          if (pcVar5 != (char *)0x0) goto LAB_006a3b99;
          if (DAT_01eae4ae != '\0') {
            FUN_016774b0(DAT_01eae4ae,"RbxOpenReply2 too many recent connections",0);
          }
          piVar6 = (int *)FUN_00697270(1,
                                       "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                                       ,0x19f9);
          *(undefined *)piVar6[0xe] = 0x11;
          piVar6[0xd] = 8;
          FUN_005f7170(iStack_28);
          piVar6[8] = iStack_60;
          piVar6[9] = iStack_5c;
          *(undefined2 *)(piVar6 + 10) = (undefined2)uStack_58;
          piStack_30 = piVar6;
          FUN_00722910();
          FUN_005fe020(&piStack_30,
                       "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                       ,0x119f);
          FUN_00722920();
          FUN_00697e80(&LAB_00696bb0,iStack_28);
        }
      }
      piStack_2c = param_1 + 0xc0;
      FUN_00722910();
      uVar8 = 0;
      while( true ) {
        uVar1 = param_1[0xbd];
        if ((uint)param_1[0xbe] < uVar1) {
          iVar4 = param_1[0xbf] - uVar1;
        }
        else {
          iVar4 = -uVar1;
        }
        if ((uint)(param_1[0xbe] + iVar4) <= uVar8) goto LAB_006a3cee;
        piStack_30 = param_1 + 0xbc;
        cVar3 = FUN_005f71d0(param_4);
        if (cVar3 != '\0') break;
        uVar8 = uVar8 + 1;
      }
      FUN_0069dd40(uVar8);
LAB_006a3cee:
      FUN_00722920();
      FUN_00696cb0(1);
      cStack_21 = 1;
      goto LAB_006a3d3e;
    }
    uVar7 = (**(code **)(*param_1 + 0xc0))
                      (_DAT_01eae4bc,uRam01eae4c0,uRam01eae4c4,uRam01eae4c8,_DAT_01eae4cc,
                       uRam01eae4d0,uRam01eae4d4,uRam01eae4d8,param_4,param_5);
    FUN_006a4c90(0xb,uVar7,param_4,param_5);
  }
  cStack_21 = 0;
LAB_006a3d3e:
  FUN_006a5640();
  ExceptionList = pvStack_1c;
  return cStack_21;
}



/* FUNCTION 8536 ; VA 0x006a3d70 ; FUN_006a3d70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall
FUN_006a3d70(int *param_1,int param_2,uint param_3,undefined4 param_4,undefined4 *param_5,
            uint param_6)

{
  uint uVar1;
  char cVar2;
  undefined *puVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_12c;
  undefined4 uStack_120;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a644b;
  pvStack_10 = ExceptionList;
  if (0x11 < param_3) {
    puVar3 = (undefined *)0x0;
    do {
      if (param_3 + 0x28 + (param_6 & 0xffff) == *(int *)(puVar3 + 0x18d9498)) {
        if (*(char *)(param_2 + 0x11) == '\x05') {
          ExceptionList = &pvStack_10;
          FUN_006a54a0(0x1c);
          uStack_8 = 0;
          param_3 = CONCAT13(0x7e,(undefined3)param_3);
          FUN_006a6060((int)&param_3 + 3,8,1);
          FUN_006a5ee0(&DAT_018d94a4,0x10);
          puVar3 = (undefined *)
                   (**(code **)(*param_1 + 0xc0))
                             (_DAT_01eae4bc,uRam01eae4c0,uRam01eae4c4,uRam01eae4c8,_DAT_01eae4cc,
                              uRam01eae4d0,uRam01eae4d4,uRam01eae4d8);
          cVar2 = FUN_005fda50();
          if (cVar2 == '\0') {
            FUN_006a5c10(puVar3,auStack_18,8);
            puVar3 = auStack_18;
          }
          FUN_006a6060(puVar3,0x40,1);
          param_3 = param_3 & 0xffffff;
          FUN_006a6060((int)&param_3 + 3,8,1);
          param_3 = param_6 + 0x28 + uVar1 & 0xffff;
          cVar2 = FUN_005fda50();
          if (cVar2 == '\0') {
            FUN_006a5c10(&param_3,&param_6,2);
            puVar5 = &param_6;
          }
          else {
            puVar5 = &param_3;
          }
          FUN_006a6060(puVar5,0x10,1);
          FUN_006952f0(*(undefined4 *)*param_5,uStack_120,iStack_12c + 7U >> 3,param_4,
                       "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                       ,0x17f9);
          FUN_006a5640();
          ExceptionList = pvStack_10;
          return 1;
        }
        ExceptionList = &pvStack_10;
        if (DAT_01eae4ae != '\0') {
          ExceptionList = &pvStack_10;
          FUN_016774b0(DAT_01eae4ae,"RbxOpenRequest1 Incompatible Protocol",0);
        }
        uVar6 = _DAT_01eae4bc;
        uVar7 = uRam01eae4c0;
        uVar4 = (**(code **)(*param_1 + 0xc0))
                          (_DAT_01eae4bc,uRam01eae4c0,uRam01eae4c4,uRam01eae4c8,_DAT_01eae4cc,
                           uRam01eae4d0,uRam01eae4d4,uRam01eae4d8,param_4,param_5);
        FUN_006a4c90(0x19,uVar4,uVar6,uVar7);
        ExceptionList = pvStack_10;
        return 1;
      }
      puVar3 = puVar3 + 4;
    } while (puVar3 < &DAT_0000000c);
  }
  if (DAT_01eae4ae != '\0') {
    ExceptionList = &pvStack_10;
    FUN_01677520(DAT_01eae4ae,"RbxOpenRequest1 has incorrect size %d.",param_3);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 8537 ; VA 0x006a3fa0 ; FUN_006a3fa0 */

undefined __thiscall
FUN_006a3fa0(int param_1,undefined4 param_2,uint param_3,undefined4 *param_4,undefined4 param_5,
            ushort param_6)

{
  char cVar1;
  char cVar2;
  undefined *puVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  byte bVar7;
  undefined *puVar8;
  bool bVar9;
  undefined8 uVar10;
  char *pcVar11;
  undefined auStack_220 [288];
  undefined auStack_100 [32];
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  uint uStack_50;
  char *pcStack_4c;
  ushort auStack_48 [3];
  undefined uStack_41;
  uint uStack_40;
  int aiStack_3c [2];
  uint uStack_34;
  char *pcStack_30;
  undefined4 *puStack_2c;
  undefined2 auStack_28 [3];
  byte bStack_22;
  char cStack_21;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017a648d;
  pvStack_1c = ExceptionList;
  if (0x6a < param_3) {
    puVar3 = (undefined *)0x0;
    do {
      if (param_6 + 0x28 + param_3 == *(int *)(puVar3 + 0x18d9498)) {
        ExceptionList = &pvStack_1c;
        FUN_006a5530(param_2,param_3,0);
        uStack_14 = 0;
        FUN_006a57f0(0x11);
        FUN_006a5ae0(&uStack_41,8,1);
        FUN_006a5ae0(&bStack_22,8,1);
        FUN_005f7f10(auStack_48);
        FUN_006a5930(auStack_100,0x20);
        uStack_14 = 0xffffffff;
        FUN_006a5640();
        param_3 = (uint)bStack_22;
        uStack_40 = auStack_48[0] + 0x1c + param_3;
        if (bStack_22 == 0x35) {
          uStack_80 = *param_4;
          uStack_7c = param_4[1];
          uStack_78 = param_4[2];
          uStack_74 = param_4[3];
          uStack_70 = param_4[4];
          uStack_6c = param_4[5];
          uStack_68 = param_4[6];
          uStack_64 = param_4[7];
          cVar2 = FUN_005f71d0(&DAT_01eae4bc);
          if (((cVar2 == '\0') && (iVar4 = FUN_0069a270(&uStack_80), iVar4 != -1)) &&
             (pcStack_4c = (char *)(*(int *)(param_1 + 0x234) + iVar4 * 0xb70),
             *pcStack_4c == '\x01')) {
            if (pcStack_4c == (char *)0x0) goto LAB_006a413a;
            cStack_21 = '\x01';
          }
          else {
            pcStack_4c = (char *)0x0;
LAB_006a413a:
            cStack_21 = '\0';
          }
          aiStack_3c[0] = 0;
          aiStack_3c[1] = 0;
          uStack_14 = 1;
          if (cStack_21 == '\0') {
            puStack_2c = (undefined4 *)FUN_01674e20(0x70);
            uStack_14._0_1_ = 2;
            if (puStack_2c == (undefined4 *)0x0) {
              puVar5 = (undefined4 *)0x0;
            }
            else {
              FUN_00686030();
              *puStack_2c = RBX::Security::RakPeerCrypto::vftable;
              puVar5 = puStack_2c;
            }
            uStack_14 = CONCAT31(uStack_14._1_3_,1);
            FUN_00695de0(puVar5);
            bVar9 = *(char *)(param_1 + 0x6ac) == '\0';
            puStack_2c = (undefined4 *)&DAT_018d6c88;
            puVar3 = &DAT_018d6c48;
            if (bVar9) {
              puVar3 = &DAT_018d6c68;
            }
            puVar8 = &DAT_01eadee8;
            if (bVar9) {
              puVar8 = &DAT_018d6c88;
            }
            FUN_00687160(puVar3,0x20,puVar8,0x20);
            FUN_00687260(auStack_100,0x20);
          }
          else {
            FUN_0056ecd0(pcStack_4c + 0x188);
          }
          if (aiStack_3c[0] == 0) {
            if (DAT_01eae4ae != '\0') {
              FUN_016774b0(DAT_01eae4ae,"RbxOpenRequest2 no session crypto",0);
            }
            cStack_21 = 0;
            FUN_00550b30();
            ExceptionList = pvStack_1c;
            return cStack_21;
          }
          FUN_006a5530(param_2,uStack_40,0);
          uStack_14 = CONCAT31(uStack_14._1_3_,3);
          cVar2 = FUN_00686760(auStack_220,bStack_22);
          if (cVar2 == '\0') {
            if (DAT_01eae4ae != '\0') {
              uVar6 = FUN_005f7ae0(0,0x7c);
              FUN_01677650(DAT_01eae4ae,"RbxOpenRequest2 decrypt failed for %s",uVar6);
              cStack_21 = 0;
              goto LAB_006a45c2;
            }
          }
          else {
            FUN_00697e80(&LAB_00696ba6,param_4);
            FUN_006a57f0(0x35);
            uVar10 = FUN_006a45e0(auStack_220);
            uStack_40 = (uint)((ulonglong)uVar10 >> 0x20);
            puStack_2c = (undefined4 *)uVar10;
            FUN_005f70a0();
            FUN_00695a10(&uStack_60);
            FUN_005f7f10(auStack_28);
            FUN_006a5ae0(&uStack_34,8,1);
            FUN_005f7140();
            FUN_00695a70(&uStack_e0);
            cVar2 = FUN_006a3570(auStack_28[0]);
            if (cVar2 != '\0') {
              uVar10 = FUN_006a2f20(param_1);
              pcStack_30 = (char *)((uint)uVar10 & (uint)puStack_2c);
              uStack_50 = (uint)((ulonglong)uVar10 >> 0x20) & uStack_40;
              if (DAT_01ee420b != '\0') {
                FUN_01677520(DAT_01ee420b,
                             "Peer has capabilities: 0x%llx ,common capabilities: 0x%llx",puStack_2c
                             ,uStack_40,pcStack_30,uStack_50);
              }
              pcVar11 = (char *)FUN_0069a100(uStack_60,uStack_5c,uStack_58,uStack_54,1);
              if ((pcVar11 == (char *)0x0) || (*pcVar11 == '\0')) {
                cVar2 = '\0';
              }
              else {
                cVar2 = '\x01';
              }
              cVar1 = cVar2;
              if ((cStack_21 == '\0') || (cVar1 = cStack_21, cVar2 == '\0')) {
                if (cVar1 == '\x01') goto LAB_006a43ec;
                cVar2 = FUN_006978a0();
                if (cVar2 == '\0') {
                  if (DAT_01eae4ae != '\0') {
                    FUN_016774b0(DAT_01eae4ae,"RbxOpenRequest2 no free incoming connections",0);
                  }
                  FUN_006a4c90(0x14,&uStack_60,param_4,param_5);
                  cStack_21 = 1;
                  goto LAB_006a45c2;
                }
                uStack_90 = uStack_60;
                uStack_8c = uStack_5c;
                uStack_88 = uStack_58;
                uStack_84 = uStack_54;
                cStack_21 = '\0';
                uStack_a0 = uStack_e0;
                uStack_9c = uStack_dc;
                uStack_98 = uStack_d8;
                uStack_94 = uStack_d4;
                uStack_b0 = uStack_d0;
                uStack_ac = uStack_cc;
                uStack_a8 = uStack_c8;
                uStack_a4 = uStack_c4;
                uStack_c0 = *param_4;
                uStack_bc = param_4[1];
                uStack_b8 = param_4[2];
                uStack_b4 = param_4[3];
                uStack_70 = param_4[4];
                uStack_6c = param_4[5];
                uStack_68 = param_4[6];
                uStack_64 = param_4[7];
                FUN_00557fc0(aiStack_3c);
                FUN_00557fc0(param_5);
                pcStack_30 = (char *)FUN_00697920(uStack_c0,uStack_bc,uStack_b8,uStack_b4,uStack_70,
                                                  uStack_6c,uStack_68,uStack_64,6);
                if (cStack_21 == '\x01') {
                  if (DAT_01eae4ae != '\0') {
                    FUN_016774b0(DAT_01eae4ae,"RbxOpenRequest2 recently connected",0);
                  }
                  FUN_006a4c90(0x1a,&uStack_60,param_4,param_5);
                  cStack_21 = 1;
                  goto LAB_006a45c2;
                }
                FUN_00687300();
                cVar2 = FUN_006871e0(uStack_34);
                if (cVar2 == '\0') {
                  bVar7 = (byte)uStack_34;
                }
                else {
                  cVar2 = FUN_00686cc0();
                  bVar7 = (byte)uStack_34;
                  if (cVar2 == '\0') {
                    bVar7 = 1;
                  }
                }
                uStack_34 = CONCAT31(uStack_34._1_3_,bVar7) & 0xffffff7f;
                if ((bVar7 & 0x7f) == 0) {
                  FUN_006a4c90(0xb,&uStack_60,param_4,param_5);
                  cStack_21 = 0;
                  goto LAB_006a45c2;
                }
                FUN_00687370(uStack_34);
                pcVar11 = pcStack_30;
              }
              else if ((pcStack_4c != pcVar11) ||
                      (pcVar11 = pcStack_4c, *(int *)(pcStack_4c + 0xb68) != 6)) {
LAB_006a43ec:
                if (DAT_01eae4ae != '\0') {
                  FUN_016774b0(DAT_01eae4ae,"RbxOpenRequest2 already connected",0);
                }
                FUN_006a4c90(0x12,&uStack_60,param_4,param_5);
                cStack_21 = 1;
                goto LAB_006a45c2;
              }
              cStack_21 = FUN_006a4d70(pcVar11,param_4,param_5);
              goto LAB_006a45c2;
            }
            if (DAT_01eae4ae != '\0') {
              FUN_01677520(DAT_01eae4ae,"RbxOpenRequest2 invalide mtu %d.",auStack_28[0]);
            }
          }
          cStack_21 = 0;
LAB_006a45c2:
          FUN_006a5640();
          FUN_00550b30();
          ExceptionList = pvStack_1c;
          return cStack_21;
        }
        if (DAT_01eae4ae == '\0') {
          ExceptionList = pvStack_1c;
          return 0;
        }
        pcVar11 = "RbxOpenRequest2 unexpected aad size %d.";
        goto LAB_006a400f;
      }
      puVar3 = puVar3 + 4;
    } while (puVar3 < &DAT_0000000c);
  }
  if (DAT_01eae4ae != '\0') {
    pcVar11 = "RbxOpenRequest2 has invalid size %d.";
    ExceptionList = &pvStack_1c;
    puStack_20 = &stack0xfffffffc;
LAB_006a400f:
    FUN_01677520(DAT_01eae4ae,pcVar11,param_3);
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 8538 ; VA 0x006a45e0 ; FUN_006a45e0 */

undefined8 FUN_006a45e0(int param_1)

{
  char cVar1;
  undefined auStack_14 [8];
  undefined8 uStack_c;
  
  if ((uint)(*(int *)(param_1 + 8) - *(int *)(param_1 + 0x10)) < 0x40) {
    return 0;
  }
  cVar1 = FUN_005fda50();
  if (cVar1 == '\0') {
    cVar1 = FUN_006a5ae0(auStack_14,0x40,1);
    if (cVar1 != '\0') {
      FUN_006a5c10(auStack_14,&uStack_c,8);
      return uStack_c;
    }
  }
  else {
    FUN_006a5ae0(&uStack_c,0x40,1);
  }
  return uStack_c;
}



/* FUNCTION 8539 ; VA 0x006a4650 ; FUN_006a4650 */

void FUN_006a4650(char param_1,int param_2,int param_3)

{
  undefined uVar1;
  char *pcVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uStack_78;
  uint uStack_74;
  uint uStack_70;
  uint uStack_6c;
  undefined8 uStack_68;
  double dStack_60;
  int iStack_58;
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  int iStack_28;
  uint *puStack_24;
  uint *puStack_20;
  double dStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6505;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  if (0 < DAT_01eae4b4) {
    ExceptionList = &pvStack_10;
    FUN_0151f6f0(0xffffffff,0,0);
    iStack_8 = 0;
    FUN_0151fa60("DeferredMs",param_2);
    FUN_0151fa60("QueueLengthAtDeferred",param_3);
    iVar5 = DAT_01eae4b4;
    pcVar2 = "RakNetQueueDeferredJoinTimeMs";
    if (param_1 == '\0') {
      pcVar2 = "RakNetQueueDeferredLeaveTimeMs";
    }
    FUN_0054eff0(pcVar2);
    iStack_8._0_1_ = 1;
    FUN_01520d20(auStack_40,iVar5,0);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_2c) {
      uVar6 = uStack_2c + 1;
      uVar4 = auStack_40[0];
      if (0xfff < uVar6) {
        uVar4 = *(uint *)(auStack_40[0] - 4);
        uVar6 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar4,uVar6);
    }
    FUN_0151f7f0();
  }
  iStack_28 = 0;
  puStack_24 = (uint *)0x0;
  puStack_20 = (uint *)0x0;
  iStack_8 = 2;
  dStack_1c = (double)param_2 + (double)(&DAT_018c0d90)[-(param_2 >> 0x1f)];
  if (param_1 == '\0') {
    puVar3 = (uint *)FUN_0054eff0("RakNetQueueDeferredLeaveTimeMs");
    uVar4 = 2;
  }
  else {
    puVar3 = (uint *)FUN_0054eff0("RakNetQueueDeferredJoinTimeMs");
    uVar4 = 1;
  }
  uStack_78 = *puVar3;
  uStack_74 = puVar3[1];
  uStack_70 = puVar3[2];
  uStack_6c = puVar3[3];
  uStack_68 = *(undefined8 *)(puVar3 + 4);
  puVar3[4] = 0;
  puVar3[5] = 0xf;
  *(undefined *)puVar3 = 0;
  dStack_60 = dStack_1c;
  iStack_8 = 5;
  uStack_14 = uVar4;
  if (puStack_20 == puStack_24) {
    FUN_00603540(puStack_24,&uStack_78);
    uVar6 = uStack_68._4_4_;
  }
  else {
    puStack_24[4] = 0;
    *puStack_24 = uStack_78;
    puStack_24[1] = uStack_74;
    puStack_24[2] = uStack_70;
    puStack_24[3] = uStack_6c;
    uStack_78 = uStack_78 & 0xffffff00;
    *(undefined8 *)(puStack_24 + 4) = uStack_68;
    *(double *)(puStack_24 + 6) = dStack_1c;
    puStack_24 = puStack_24 + 8;
    uVar6 = 0xf;
  }
  iStack_8 = CONCAT31(iStack_8._1_3_,4);
  if (0xf < uVar6) {
    uVar7 = uVar6 + 1;
    uVar8 = uStack_78;
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(uStack_78 - 4);
      uVar7 = uVar6 + 0x24;
      if (0x1f < (uStack_78 - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  iStack_8 = 3;
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    if (0xf < uStack_2c) {
      uVar8 = uStack_2c + 1;
      uVar6 = auStack_40[0];
      if (0xfff < uVar8) {
        uVar6 = *(uint *)(auStack_40[0] - 4);
        uVar8 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar8);
    }
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
  }
  iStack_8 = 2;
  if (((uVar4 & 1) != 0) && (0xf < uStack_44)) {
    uVar4 = uStack_44 + 1;
    iVar5 = iStack_58;
    if (0xfff < uVar4) {
      iVar5 = *(int *)(iStack_58 + -4);
      uVar4 = uStack_44 + 0x24;
      if (0x1f < (iStack_58 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar4);
  }
  dStack_1c = (double)param_3 + (double)(&DAT_018c0d90)[-(param_3 >> 0x1f)];
  puVar3 = (uint *)FUN_0054eff0("RakNetDeferredQueueLength");
  uStack_78 = *puVar3;
  uStack_74 = puVar3[1];
  uStack_70 = puVar3[2];
  uStack_6c = puVar3[3];
  uStack_68 = *(undefined8 *)(puVar3 + 4);
  puVar3[4] = 0;
  puVar3[5] = 0xf;
  *(undefined *)puVar3 = 0;
  dStack_60 = dStack_1c;
  iStack_8._0_1_ = 7;
  if (puStack_20 == puStack_24) {
    FUN_00603540(puStack_24,&uStack_78);
    uVar4 = uStack_68._4_4_;
  }
  else {
    puStack_24[4] = 0;
    *puStack_24 = uStack_78;
    puStack_24[1] = uStack_74;
    puStack_24[2] = uStack_70;
    puStack_24[3] = uStack_6c;
    uStack_78 = uStack_78 & 0xffffff00;
    *(undefined8 *)(puStack_24 + 4) = uStack_68;
    *(double *)(puStack_24 + 6) = dStack_1c;
    puStack_24 = puStack_24 + 8;
    uVar4 = 0xf;
  }
  iStack_8._0_1_ = 6;
  uVar1 = (undefined)iStack_8;
  iStack_8._0_1_ = 6;
  if (0xf < uVar4) {
    uVar8 = uVar4 + 1;
    uVar6 = uStack_78;
    if (0xfff < uVar8) {
      uVar6 = *(uint *)(uStack_78 - 4);
      uVar8 = uVar4 + 0x24;
      if (0x1f < (uStack_78 - uVar6) - 4) {
        iStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar8);
  }
  iStack_8 = CONCAT31(iStack_8._1_3_,2);
  if (0xf < uStack_44) {
    uVar4 = uStack_44 + 1;
    iVar5 = iStack_58;
    if (0xfff < uVar4) {
      iVar5 = *(int *)(iStack_58 + -4);
      uVar4 = uStack_44 + 0x24;
      if (0x1f < (iStack_58 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar4);
  }
  FUN_00874d70(&iStack_28,0);
  if (DAT_01eae4ad != '\0') {
    pcVar2 = "RakNet Join Deferred Time Ms : %d";
    if (param_1 == '\0') {
      pcVar2 = "RakNet Leave Deferred Time Ms : %d";
    }
    FUN_01677520(DAT_01eae4ad,pcVar2,param_2);
    if (DAT_01eae4ad != '\0') {
      FUN_01677520(DAT_01eae4ad,"RakNet Deferred Queue Length At Packet Deferred Time : %zu",param_3
                  );
    }
  }
  if (iStack_28 != 0) {
    FUN_00559500(iStack_28,puStack_24,&iStack_28);
    uVar4 = (int)puStack_20 - iStack_28 & 0xffffffe0;
    iVar5 = iStack_28;
    if (0xfff < uVar4) {
      iVar5 = *(int *)(iStack_28 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iStack_28 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8540 ; VA 0x006a4ac0 ; FUN_006a4ac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_006a4ac0(int *param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  undefined8 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined2 uVar5;
  undefined4 uStack_13c;
  undefined4 uStack_130;
  undefined8 uStack_28;
  int *piStack_20;
  undefined8 uStack_1c;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a616b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_20 = param_1;
  if (DAT_01eae4ac != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01eae4ac,"RakNet: Send App Connection Request",0);
  }
  FUN_006a5600();
  uStack_8 = 0;
  uStack_11 = 9;
  FUN_006a6060(&uStack_11,8,1);
  puVar2 = (undefined8 *)
           (**(code **)(*param_1 + 0xc0))
                     (_DAT_01eae4bc,uRam01eae4c0,uRam01eae4c4,uRam01eae4c8,_DAT_01eae4cc,
                      uRam01eae4d0,uRam01eae4d4,uRam01eae4d8);
  cVar1 = FUN_005fda50();
  if (cVar1 == '\0') {
    FUN_006a5c10(puVar2,&uStack_1c,8);
    puVar2 = &uStack_1c;
  }
  FUN_006a6060(puVar2,0x40,1);
  uStack_1c = FUN_006a6900();
  cVar1 = FUN_005fda50();
  if (cVar1 == '\0') {
    FUN_006a5c10(&uStack_1c,&uStack_28,8);
    puVar2 = &uStack_28;
  }
  else {
    puVar2 = &uStack_1c;
  }
  FUN_006a6060(puVar2,0x40,1);
  uStack_11 = 0;
  FUN_006a6060(&uStack_11,8,1);
  if (*(char *)(param_2 + 0x132) != '\0') {
    FUN_006a5e80(param_2 + 0x32,*(char *)(param_2 + 0x132));
  }
  uStack_1c._4_4_ = uStack_130;
  FUN_005f70a0();
  FUN_005f7140();
  uVar3 = DAT_01d5b1f0;
  uVar4 = DAT_01d5b1f4;
  uVar5 = DAT_01d5b1f8;
  FUN_005f7170(param_3);
  FUN_006a1380(uStack_1c._4_4_,uStack_13c,0,2,0,uVar3,uVar4,uVar5);
  FUN_006a5640();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8541 ; VA 0x006a4c90 ; FUN_006a4c90 */

void FUN_006a4c90(undefined4 param_1,undefined *param_2,undefined4 param_3,undefined4 *param_4)

{
  char cVar1;
  undefined *puVar2;
  int iStack_12c;
  undefined4 uStack_120;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a644b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006a54a0(200);
  uStack_8 = 0;
  FUN_006a6060(&param_1,8,1);
  FUN_006a5ee0(&DAT_018d94a4,0x10);
  cVar1 = FUN_005fda50();
  puVar2 = param_2;
  if (cVar1 == '\0') {
    FUN_006a5c10(param_2,auStack_18,8);
    puVar2 = auStack_18;
  }
  FUN_006a6060(puVar2,0x40,1);
  FUN_006952f0(*(undefined4 *)*param_4,uStack_120,iStack_12c + 7U >> 3,param_3,
               "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
               ,0x19e0);
  FUN_006a5640();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8542 ; VA 0x006a4d70 ; FUN_006a4d70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_006a4d70(uint param_1,uint param_2,undefined4 *param_3)

{
  uint uVar1;
  char cVar2;
  undefined4 uVar3;
  char *pcVar4;
  undefined auStack_144 [8];
  uint uStack_13c;
  undefined4 uStack_130;
  int iStack_28;
  int iStack_24;
  uint uStack_20;
  int *piStack_1c;
  uint uStack_18;
  undefined uStack_13;
  undefined uStack_12;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a616b;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x188) == 0) {
    if (DAT_01eae4ae != '\0') {
      ExceptionList = &pvStack_10;
      FUN_016774b0(DAT_01eae4ae,"RbxOpenReply2 no session crypto",0);
    }
    ExceptionList = pvStack_10;
    return 0;
  }
  ExceptionList = &pvStack_10;
  FUN_006a54a0(0x3b8);
  uStack_8 = 0;
  uStack_12 = 0;
  param_1 = param_1 & 0xffffff;
  uStack_18 = 0;
  FUN_00686bf0(&iStack_28);
  if ((iStack_28 == 0) || (iStack_24 == 0)) {
    if (DAT_01eae4ae != '\0') {
      pcVar4 = "RbxOpenReply2 no public key";
LAB_006a5007:
      FUN_016774b0(DAT_01eae4ae,pcVar4,0);
    }
  }
  else {
    uStack_13 = FUN_00686c30();
    uStack_11 = 0x7d;
    FUN_006a6060(&uStack_11,8,1);
    FUN_006a5ee0(&DAT_018d94a4,0x10);
    FUN_006a6060(&uStack_12,8,1);
    FUN_006a6060((int)&param_1 + 3,8,1);
    FUN_005f8080(&uStack_18);
    param_1 = CONCAT13((char)(uStack_13c >> 3),(undefined3)param_1);
    FUN_006a5ee0(iStack_28,0x20);
    FUN_006a5450(auStack_144,*(undefined4 *)(uVar1 + 0xb58),*(undefined4 *)(uVar1 + 0xb5c));
    uVar3 = (**(code **)(*piStack_1c + 0xc0))
                      (_DAT_01eae4bc,uRam01eae4c0,uRam01eae4c4,uRam01eae4c8,_DAT_01eae4cc,
                       uRam01eae4d0,uRam01eae4d4,uRam01eae4d8);
    FUN_00695af0(uVar3);
    uStack_20 = (uint)*(ushort *)(uVar1 + 0xb40);
    FUN_005f8080(&uStack_20);
    FUN_006a6060(&uStack_13,8,1);
    FUN_00695b40(uVar1 + 4);
    uStack_18 = (uint)(ushort)((short)(uStack_13c >> 3) - (ushort)param_1._3_1_);
    FUN_006a5ee0(&DAT_018d8eb0,0x1c);
    uVar1 = uStack_13c;
    FUN_006a5c40(0x90,0);
    FUN_006a6060((int)&param_1 + 3,8,1);
    FUN_005f8080(&uStack_18);
    FUN_006a5c40(uVar1 & 0xfffffff8,0);
    cVar2 = FUN_00686830(auStack_144,param_1 >> 0x18,0);
    if (cVar2 != '\0') {
      FUN_006952f0(*(undefined4 *)*param_3,uStack_130,uStack_13c + 7 >> 3,param_2,
                   "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                   ,0x1951);
      param_2 = CONCAT13(1,(undefined3)param_2);
      goto LAB_006a5017;
    }
    if (DAT_01eae4ae != '\0') {
      pcVar4 = "RbxOpenReply2 encrypt failed";
      goto LAB_006a5007;
    }
  }
  param_2 = param_2 & 0xffffff;
LAB_006a5017:
  FUN_006a5640();
  ExceptionList = pvStack_10;
  return param_2 >> 0x18;
}



/* FUNCTION 8543 ; VA 0x006a5040 ; FUN_006a5040 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined __thiscall FUN_006a5040(int *param_1,uint param_2,int param_3)

{
  uint uVar1;
  char cVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  char *pcVar5;
  undefined auStack_14c [8];
  uint uStack_144;
  undefined4 uStack_138;
  int iStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  int *piStack_20;
  uint uStack_1c;
  uint uStack_18;
  char acStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a632b;
  pvStack_10 = ExceptionList;
  piStack_20 = param_1;
  if (*(int *)(param_3 + 0x154) == 0) {
    if (DAT_01eae4ae != '\0') {
      ExceptionList = &pvStack_10;
      FUN_016774b0(DAT_01eae4ae,"RbxOpenRequest2 no session crypto",0);
    }
    ExceptionList = pvStack_10;
    return 0;
  }
  ExceptionList = &pvStack_10;
  FUN_006a54a0(param_2 << 3);
  uStack_8 = 0;
  uStack_18 = 0;
  if ((DAT_01d59d40 != '\0') && (param_1[0x1be] != 0)) {
    uStack_18 = FUN_006a6780();
    uStack_18 = uStack_18 & 0xffff;
    FUN_006a67e0(auStack_14c);
  }
  uStack_28 = *(undefined4 *)(param_3 + 0x154);
  acStack_14[1] = 0;
  acStack_14[3] = 0;
  uStack_1c = 0;
  FUN_00686bf0(&iStack_30);
  if ((iStack_30 == 0) || (iStack_2c == 0)) {
    if (DAT_01eae4ae != '\0') {
      pcVar5 = "RbxOpenRequest2 no public key";
LAB_006a5341:
      FUN_016774b0(DAT_01eae4ae,pcVar5,0);
    }
  }
  else {
    cVar2 = FUN_00686cc0();
    acStack_14[0] = (cVar2 != '\0') + '\x01';
    uVar4 = FUN_006a2f20(param_1);
    FUN_005f70a0();
    acStack_14[2] = 0x78;
    FUN_006a6060(acStack_14 + 2,8,1);
    FUN_006a5ee0(&DAT_018d94a4,0x10);
    FUN_006a6060(acStack_14 + 1,8,1);
    FUN_006a6060(acStack_14 + 3,8,1);
    FUN_005f8080(&uStack_1c);
    FUN_006a5ee0(iStack_30,0x20);
    acStack_14[3] = (char)(uStack_144 >> 3) - (char)uStack_18;
    FUN_006a5450(auStack_14c,uVar4);
    uVar3 = (**(code **)(*piStack_20 + 0xc0))
                      (_DAT_01eae4bc,uRam01eae4c0,uRam01eae4c4,uRam01eae4c8,_DAT_01eae4cc,
                       uRam01eae4d0,uRam01eae4d4,uRam01eae4d8);
    FUN_00695af0(uVar3);
    uStack_24 = param_2 & 0xffff;
    FUN_005f8080(&uStack_24);
    FUN_006a6060(acStack_14,8,1);
    FUN_00695b40(param_3);
    uVar1 = uStack_144;
    uStack_1c = (uint)(ushort)(((short)(uStack_144 >> 3) - (ushort)(byte)acStack_14[3]) -
                              (short)uStack_18);
    FUN_006a5c40((uStack_18 & 0xffff) * 8 + 0x90,0);
    FUN_006a6060(acStack_14 + 3,8,1);
    FUN_005f8080(&uStack_1c);
    FUN_006a5c40(uVar1 & 0xfffffff8,0);
    cVar2 = FUN_00686830(auStack_14c,acStack_14[3],uStack_18);
    if (cVar2 != '\0') {
      FUN_006a5860(param_2 - 0x28);
      FUN_006952f0(**(undefined4 **)(piStack_20[0x10e] + *(int *)(param_3 + 0x134) * 8),uStack_138,
                   uStack_144 + 7 >> 3,param_3,
                   "C:\\teamcity-agent\\work\\trunk_ninja_rcc-x86\\Client\\Network\\raknet\\Source\\RakPeer.cpp"
                   ,0x1864);
      param_2._3_1_ = 1;
      goto LAB_006a5351;
    }
    if (DAT_01eae4ae != '\0') {
      pcVar5 = "RbxOpenRequest2 failed to encrypt";
      goto LAB_006a5341;
    }
  }
  param_2._3_1_ = 0;
LAB_006a5351:
  FUN_006a5640();
  ExceptionList = pvStack_10;
  return param_2._3_1_;
}



/* FUNCTION 8544 ; VA 0x006a5380 ; FUN_006a5380 */

void __thiscall FUN_006a5380(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x434) = param_2;
  return;
}



/* FUNCTION 8545 ; VA 0x006a5390 ; FUN_006a5390 */

void FUN_006a5390(undefined4 param_1,undefined4 param_2,undefined2 param_3)

{
  char cVar1;
  int iVar2;
  undefined in_stack_00000034;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  FUN_005f70a0();
  FUN_005f7140();
  FUN_005f7170(&stack0x00000014);
  cVar1 = FUN_005f7240(&DAT_01d5b1f0);
  if (cVar1 == '\0') {
    iVar2 = FUN_0069a190(uStack_24,uStack_20,uStack_1c,uStack_18,uStack_14,uStack_10,uStack_c,
                         uStack_8,0,1);
  }
  else {
    iVar2 = FUN_0069a100(param_1,param_2,param_3,uStack_28,1);
  }
  if (iVar2 != 0) {
    LOCK();
    *(undefined *)(iVar2 + 0xb60) = in_stack_00000034;
    UNLOCK();
  }
  return;
}



/* FUNCTION 8546 ; VA 0x006a5430 ; FUN_006a5430 */

void __thiscall FUN_006a5430(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 4) = param_2;
  return;
}



/* FUNCTION 8547 ; VA 0x006a5440 ; FUN_006a5440 */

void __thiscall FUN_006a5440(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0x6ac) = param_2;
  return;
}



/* FUNCTION 8548 ; VA 0x006a5450 ; FUN_006a5450 */

void FUN_006a5450(void)

{
  char cVar1;
  undefined auStack_c [8];
  
  cVar1 = FUN_005fda50();
  if (cVar1 == '\0') {
    FUN_006a5c10(&stack0x00000008,auStack_c,8);
    FUN_006a6060(auStack_c,0x40,1);
    return;
  }
  FUN_006a6060(&stack0x00000008,0x40,1);
  return;
}



/* FUNCTION 8549 ; VA 0x006a54a0 ; FUN_006a54a0 */

undefined4 * __thiscall FUN_006a54a0(undefined4 *param_1,uint param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a6518;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = RakNet::BitStream::vftable;
  *(undefined *)(param_1 + 1) = 0;
  param_1[2] = 0;
  param_1[4] = 0;
  if (param_2 < 0x101) {
    param_1[3] = 0x800;
    param_1[5] = (int)param_1 + 0x19;
  }
  else {
    uVar1 = FUN_01674f30(param_2);
    param_1[5] = uVar1;
    param_1[3] = param_2 * 8;
  }
  *(undefined *)(param_1 + 6) = 1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8550 ; VA 0x006a5530 ; FUN_006a5530 */

undefined4 * __thiscall
FUN_006a5530(undefined4 *param_1,undefined4 param_2,uint param_3,char param_4)

{
  void *pvVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar1 = ExceptionList;
  puStack_c = &LAB_017a6518;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = RakNet::BitStream::vftable;
  *(undefined *)(param_1 + 1) = 0;
  param_1[2] = param_3 * 8;
  param_1[4] = 0;
  *(char *)(param_1 + 6) = param_4;
  param_1[3] = param_3 * 8;
  if (param_4 == '\0') {
    param_1[5] = param_2;
    ExceptionList = pvVar1;
    return param_1;
  }
  if (param_3 != 0) {
    if (param_3 < 0x100) {
      iVar2 = (int)param_1 + 0x19;
      param_1[3] = 0x800;
    }
    else {
      iVar2 = FUN_01674f30(param_3);
    }
    param_1[5] = iVar2;
    FUN_0170c6f0(iVar2,param_2,param_3);
    ExceptionList = pvStack_10;
    return param_1;
  }
  param_1[5] = 0;
  ExceptionList = pvVar1;
  return param_1;
}



/* FUNCTION 8551 ; VA 0x006a5600 ; FUN_006a5600 */

undefined4 * __fastcall FUN_006a5600(undefined4 *param_1)

{
  param_1[5] = (int)param_1 + 0x19;
  *param_1 = RakNet::BitStream::vftable;
  *(undefined *)(param_1 + 1) = 0;
  param_1[2] = 0;
  param_1[3] = 0x800;
  param_1[4] = 0;
  *(undefined *)(param_1 + 6) = 1;
  return param_1;
}



/* FUNCTION 8552 ; VA 0x006a5640 ; FUN_006a5640 */

void __fastcall FUN_006a5640(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RakNet::BitStream::vftable;
  if ((*(char *)(param_1 + 6) != '\0') && (0x800 < (uint)param_1[3])) {
    FUN_01674ea0(param_1[5]);
  }
  *param_1 = RakNet::AbstractBitStream::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8553 ; VA 0x006a5690 ; FUN_006a5690 */

undefined4 * __thiscall FUN_006a5690(undefined4 *param_1,byte param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = RakNet::BitStream::vftable;
  if ((*(char *)(param_1 + 6) != '\0') && (0x800 < (uint)param_1[3])) {
    FUN_01674ea0(param_1[5]);
  }
  *param_1 = RakNet::AbstractBitStream::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x11c);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8554 ; VA 0x006a5700 ; FUN_006a5700 */

void __thiscall FUN_006a5700(int param_1,int param_2)

{
  uint uVar1;
  undefined4 uVar2;
  uint uVar3;
  
  uVar3 = *(int *)(param_1 + 8) + param_2;
  if ((uVar3 != 0) && ((*(int *)(param_1 + 0xc) - 1U & 0xfffffff8) < (uVar3 - 1 & 0xfffffff8))) {
    uVar1 = uVar3 * 2;
    uVar3 = uVar3 + 0x100000;
    if ((uVar1 - *(int *)(param_1 + 8)) - param_2 < 0x100001) {
      uVar3 = uVar1;
    }
    uVar1 = uVar3 + 7 >> 3;
    if (*(int *)(param_1 + 0x14) == param_1 + 0x19) {
      if (0x100 < uVar1) {
        uVar2 = FUN_01674f30(uVar1);
        *(undefined4 *)(param_1 + 0x14) = uVar2;
        FUN_0170c6f0(uVar2,param_1 + 0x19,*(int *)(param_1 + 0xc) + 7U >> 3);
      }
    }
    else {
      uVar2 = FUN_01675190(*(int *)(param_1 + 0x14),uVar1);
      *(undefined4 *)(param_1 + 0x14) = uVar2;
    }
  }
  if (*(uint *)(param_1 + 0xc) < uVar3) {
    *(uint *)(param_1 + 0xc) = uVar3;
  }
  return;
}



/* FUNCTION 8555 ; VA 0x006a5790 ; FUN_006a5790 */

void __fastcall FUN_006a5790(int param_1)

{
  undefined4 uVar1;
  
  if (*(char *)(param_1 + 0x18) == '\0') {
    *(undefined *)(param_1 + 0x18) = 1;
    if (*(int *)(param_1 + 0xc) != 0) {
      uVar1 = FUN_01674f30(*(int *)(param_1 + 0xc) + 7U >> 3);
      FUN_0170c6f0(uVar1,*(undefined4 *)(param_1 + 0x14),*(int *)(param_1 + 0xc) + 7U >> 3);
      *(undefined4 *)(param_1 + 0x14) = uVar1;
      return;
    }
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  return;
}



/* FUNCTION 8556 ; VA 0x006a57e0 ; FUN_006a57e0 */

void __thiscall FUN_006a57e0(int param_1,int param_2)

{
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + param_2;
  return;
}



/* FUNCTION 8557 ; VA 0x006a57f0 ; FUN_006a57f0 */

void __thiscall FUN_006a57f0(int param_1,int param_2)

{
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + param_2 * 8;
  return;
}



/* FUNCTION 8558 ; VA 0x006a5800 ; FUN_006a5800 */

undefined FUN_006a5800(void)

{
  int iVar1;
  
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eaeaf0) {
    FUN_016f3809(&DAT_01eaeaf0);
    if (DAT_01eaeaf0 == -1) {
      iVar1 = Ordinal_8(0x3039);
      DAT_01eaeaec = iVar1 == 0x3039;
      FUN_016f37bf(&DAT_01eaeaf0);
    }
  }
  return DAT_01eaeaec;
}



/* FUNCTION 8559 ; VA 0x006a5860 ; FUN_006a5860 */

void __thiscall FUN_006a5860(int *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  
  uVar1 = (**(code **)(*param_1 + 8))();
  if (uVar1 < param_2) {
    param_1[2] = (param_1[2] - (param_1[2] - 1U & 7)) + 7;
    iVar2 = (**(code **)(*param_1 + 8))();
    iVar2 = param_2 - iVar2;
    FUN_006a5700(iVar2 * 8);
    FUN_0170d1f0((param_1[2] + 7U >> 3) + param_1[5],0,iVar2);
    param_1[2] = param_1[2] + iVar2 * 8;
  }
  return;
}



/* FUNCTION 8560 ; VA 0x006a58d0 ; FUN_006a58d0 */

undefined4 __thiscall FUN_006a58d0(int param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  undefined4 uVar3;
  
  uVar2 = *(uint *)(param_1 + 0x10);
  iVar1 = param_3 * 8;
  if ((uVar2 & 7) != 0) {
    uVar3 = FUN_006a5ae0(param_2,iVar1,1);
    return uVar3;
  }
  if (*(uint *)(param_1 + 8) < iVar1 + uVar2) {
    return 0;
  }
  FUN_0170c6f0(param_2,(uVar2 >> 3) + *(int *)(param_1 + 0x14),param_3);
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + iVar1;
  return 1;
}



/* FUNCTION 8561 ; VA 0x006a5930 ; FUN_006a5930 */

undefined4 __thiscall FUN_006a5930(int param_1,undefined4 param_2,int param_3)

{
  uint uVar1;
  
  if (param_3 != 0) {
    uVar1 = (*(int *)(param_1 + 0x10) - (*(int *)(param_1 + 0x10) - 1U & 7)) + 7;
    *(uint *)(param_1 + 0x10) = uVar1;
    if (uVar1 + param_3 * 8 <= *(uint *)(param_1 + 8)) {
      FUN_0170c6f0(param_2,(uVar1 >> 3) + *(int *)(param_1 + 0x14),param_3);
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + param_3 * 8;
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 8562 ; VA 0x006a5990 ; FUN_006a5990 */

uint __thiscall FUN_006a5990(int param_1,undefined *param_2)

{
  int iVar1;
  char cVar2;
  uint uVar3;
  undefined *puVar4;
  
  uVar3 = *(int *)(param_1 + 0x10) + 0x10;
  if (*(uint *)(param_1 + 8) < uVar3) {
    return uVar3 & 0xffffff00;
  }
  cVar2 = FUN_005fda50();
  puVar4 = (undefined *)((*(uint *)(param_1 + 0x10) >> 3) + *(int *)(param_1 + 0x14));
  if (cVar2 == '\0') {
    *param_2 = puVar4[1];
    iVar1 = *(int *)(param_1 + 0x14);
    param_2[1] = *(undefined *)((*(uint *)(param_1 + 0x10) >> 3) + iVar1);
    *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 0x10;
    return CONCAT31((int3)((uint)iVar1 >> 8),1);
  }
  *param_2 = *puVar4;
  iVar1 = *(int *)(param_1 + 0x14);
  param_2[1] = *(undefined *)((*(uint *)(param_1 + 0x10) >> 3) + 1 + iVar1);
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 0x10;
  return CONCAT31((int3)((uint)iVar1 >> 8),1);
}



/* FUNCTION 8563 ; VA 0x006a5a00 ; FUN_006a5a00 */

uint __thiscall FUN_006a5a00(int param_1,undefined *param_2)

{
  int iVar1;
  char cVar2;
  uint uVar3;
  undefined *puVar4;
  
  uVar3 = *(int *)(param_1 + 0x10) + 0x20;
  if (*(uint *)(param_1 + 8) < uVar3) {
    return uVar3 & 0xffffff00;
  }
  cVar2 = FUN_005fda50();
  puVar4 = (undefined *)((*(uint *)(param_1 + 0x10) >> 3) + *(int *)(param_1 + 0x14));
  if (cVar2 == '\0') {
    *param_2 = puVar4[3];
    param_2[1] = *(undefined *)((*(uint *)(param_1 + 0x10) >> 3) + 2 + *(int *)(param_1 + 0x14));
    param_2[2] = *(undefined *)((*(uint *)(param_1 + 0x10) >> 3) + 1 + *(int *)(param_1 + 0x14));
    iVar1 = *(int *)(param_1 + 0x14);
    param_2[3] = *(undefined *)((*(uint *)(param_1 + 0x10) >> 3) + iVar1);
    *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 0x20;
    return CONCAT31((int3)((uint)iVar1 >> 8),1);
  }
  *param_2 = *puVar4;
  param_2[1] = *(undefined *)((*(uint *)(param_1 + 0x10) >> 3) + 1 + *(int *)(param_1 + 0x14));
  param_2[2] = *(undefined *)((*(uint *)(param_1 + 0x10) >> 3) + 2 + *(int *)(param_1 + 0x14));
  iVar1 = *(int *)(param_1 + 0x14);
  param_2[3] = *(undefined *)((*(uint *)(param_1 + 0x10) >> 3) + 3 + iVar1);
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 0x20;
  return CONCAT31((int3)((uint)iVar1 >> 8),1);
}



/* FUNCTION 8564 ; VA 0x006a5ab0 ; FUN_006a5ab0 */

undefined4 __thiscall FUN_006a5ab0(int param_1,undefined *param_2)

{
  if (*(uint *)(param_1 + 8) < *(uint *)(param_1 + 0x10) + 8) {
    return 0;
  }
  *param_2 = *(undefined *)((*(uint *)(param_1 + 0x10) >> 3) + *(int *)(param_1 + 0x14));
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 8;
  return 1;
}



/* FUNCTION 8565 ; VA 0x006a5ae0 ; FUN_006a5ae0 */

undefined4 __thiscall FUN_006a5ae0(int param_1,byte *param_2,uint param_3,char param_4)

{
  uint uVar1;
  uint uVar2;
  byte bVar3;
  uint uVar4;
  byte *pbVar5;
  
  if (param_3 != 0) {
    uVar2 = *(uint *)(param_1 + 0x10);
    if (uVar2 + param_3 <= *(uint *)(param_1 + 8)) {
      uVar1 = uVar2 & 7;
      if ((uVar1 == 0) && ((param_3 & 7) == 0)) {
        FUN_0170c6f0(param_2,(uVar2 >> 3) + *(int *)(param_1 + 0x14),param_3 >> 3);
        *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + param_3;
        return 1;
      }
      FUN_0170d1f0(param_2,0,param_3 + 7 >> 3);
      uVar2 = *(uint *)(param_1 + 0x10);
      pbVar5 = param_2;
      do {
        bVar3 = *(char *)((uVar2 >> 3) + *(int *)(param_1 + 0x14)) << (sbyte)uVar1 | *pbVar5;
        *pbVar5 = bVar3;
        if ((uVar1 != 0) && (8 - uVar1 < param_3)) {
          param_2._0_1_ = (byte)(8 - uVar1);
          bVar3 = *(byte *)((*(uint *)(param_1 + 0x10) >> 3) + 1 + *(int *)(param_1 + 0x14)) >>
                  ((byte)param_2 & 0x1f) | bVar3;
          *pbVar5 = bVar3;
        }
        uVar4 = param_3 - 8;
        if (param_3 < 8) {
          if ((int)uVar4 < 0) {
            if (param_4 != '\0') {
              *pbVar5 = bVar3 >> (-(char)uVar4 & 0x1fU);
            }
            *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + param_3;
          }
          else {
            *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 8;
          }
          uVar4 = 0;
        }
        else {
          *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 8;
        }
        uVar2 = *(uint *)(param_1 + 0x10);
        pbVar5 = pbVar5 + 1;
        param_3 = uVar4;
      } while (uVar4 != 0);
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 8566 ; VA 0x006a5be0 ; FUN_006a5be0 */

void __fastcall FUN_006a5be0(int param_1)

{
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined *)(param_1 + 4) = 0;
  return;
}



/* FUNCTION 8567 ; VA 0x006a5c00 ; FUN_006a5c00 */

void __fastcall FUN_006a5c00(int param_1)

{
  *(undefined4 *)(param_1 + 8) = 0;
  return;
}



/* FUNCTION 8568 ; VA 0x006a5c10 ; FUN_006a5c10 */

void FUN_006a5c10(int param_1,int param_2,uint param_3)

{
  undefined uVar1;
  uint uVar2;
  undefined *puVar3;
  
  uVar2 = 0;
  if (param_3 != 0) {
    puVar3 = (undefined *)((param_3 - 1) + param_1);
    do {
      uVar1 = *puVar3;
      puVar3 = puVar3 + -1;
      *(undefined *)(uVar2 + param_2) = uVar1;
      uVar2 = uVar2 + 1;
    } while (uVar2 < param_3);
  }
  return;
}



/* FUNCTION 8569 ; VA 0x006a5c40 ; FUN_006a5c40 */

void __thiscall FUN_006a5c40(int param_1,uint param_2,char param_3)

{
  sbyte sVar1;
  byte bVar2;
  uint uVar3;
  byte *pbVar4;
  uint uVar5;
  
  if (param_3 == '\0') {
    *(uint *)(param_1 + 8) = param_2;
    return;
  }
  uVar3 = *(uint *)(param_1 + 8);
  if (param_2 < uVar3) {
    _param_3 = param_2 >> 3;
    uVar5 = uVar3 >> 3;
    uVar3 = uVar3 & 7;
    sVar1 = (sbyte)(param_2 & 7);
    if (uVar5 == _param_3) {
      bVar2 = (byte)(0xff00 >> sVar1);
      if (uVar3 != 0) {
        pbVar4 = (byte *)(*(int *)(param_1 + 0x14) + _param_3);
        *pbVar4 = *pbVar4 & (bVar2 | (byte)(0xff >> (sbyte)uVar3));
        *(uint *)(param_1 + 8) = param_2;
        return;
      }
      pbVar4 = (byte *)(*(int *)(param_1 + 0x14) + _param_3);
      *pbVar4 = *pbVar4 & bVar2;
      *(uint *)(param_1 + 8) = param_2;
      return;
    }
    if ((param_2 & 7) != 0) {
      pbVar4 = (byte *)(_param_3 + *(int *)(param_1 + 0x14));
      *pbVar4 = *pbVar4 & (byte)(0xff00 >> sVar1);
      _param_3 = _param_3 + 1;
    }
    if (uVar3 != 0) {
      pbVar4 = (byte *)(*(int *)(param_1 + 0x14) + uVar5);
      *pbVar4 = *pbVar4 & (byte)(0xff >> (sbyte)uVar3);
    }
    if (uVar5 - _param_3 != 0) {
      FUN_0170d1f0(*(int *)(param_1 + 0x14) + _param_3,0,uVar5 - _param_3);
    }
  }
  *(uint *)(param_1 + 8) = param_2;
  return;
}



/* FUNCTION 8570 ; VA 0x006a5d20 ; FUN_006a5d20 */

void __fastcall FUN_006a5d20(int param_1)

{
  uint uVar1;
  
  FUN_006a5700(1);
  uVar1 = *(uint *)(param_1 + 8);
  if ((uVar1 & 7) == 0) {
    *(undefined *)((uVar1 >> 3) + *(int *)(param_1 + 0x14)) = 0;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    return;
  }
  *(uint *)(param_1 + 8) = uVar1 + 1;
  return;
}



/* FUNCTION 8571 ; VA 0x006a5d50 ; FUN_006a5d50 */

void __fastcall FUN_006a5d50(int param_1)

{
  byte *pbVar1;
  uint uVar2;
  uint uVar3;
  
  FUN_006a5700(1);
  uVar3 = *(uint *)(param_1 + 8) >> 3;
  pbVar1 = (byte *)(*(int *)(param_1 + 0x14) + uVar3);
  uVar2 = *(uint *)(param_1 + 8) & 7;
  if (uVar2 == 0) {
    *pbVar1 = 0x80;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    return;
  }
  *(byte *)(*(int *)(param_1 + 0x14) + uVar3) = (byte)(0x80 >> (sbyte)uVar2) | *pbVar1;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  return;
}



/* FUNCTION 8572 ; VA 0x006a5d90 ; FUN_006a5d90 */

void __thiscall FUN_006a5d90(int param_1,int *param_2,uint param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  byte *pbVar4;
  uint uVar5;
  
  FUN_006a5700(param_3);
  if (((param_2[4] & 7U) == 0) && ((*(byte *)(param_1 + 8) & 7) == 0)) {
    uVar2 = (uint)param_2[4] >> 3;
    uVar5 = param_3 >> 3;
    iVar3 = (**(code **)(*param_2 + 4))(uVar5);
    FUN_0170c6f0((*(uint *)(param_1 + 8) >> 3) + *(int *)(param_1 + 0x14),iVar3 + uVar2);
    param_3 = param_3 + uVar5 * -8;
    param_2[4] = (uVar2 + uVar5) * 8;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + uVar5 * 8;
  }
  while( true ) {
    if (param_3 == 0) {
      return;
    }
    uVar2 = param_2[4];
    uVar5 = param_3 - 1;
    if ((uint)param_2[2] < uVar2 + 1) break;
    uVar1 = *(uint *)(param_1 + 8);
    pbVar4 = (byte *)((uVar2 >> 3) + param_2[5]);
    param_3._0_1_ = (byte)(0x80 >> ((byte)uVar2 & 7));
    if ((uVar1 & 7) == 0) {
      *(byte *)((uVar1 >> 3) + *(int *)(param_1 + 0x14)) = -((*pbVar4 & (byte)param_3) != 0) & 0x80;
    }
    else if ((*pbVar4 & (byte)param_3) != 0) {
      pbVar4 = (byte *)((uVar1 >> 3) + *(int *)(param_1 + 0x14));
      *pbVar4 = *pbVar4 | (byte)(0x80 >> (sbyte)(uVar1 & 7));
    }
    param_2[4] = param_2[4] + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    param_3 = uVar5;
  }
  return;
}



/* FUNCTION 8573 ; VA 0x006a5e80 ; FUN_006a5e80 */

void __thiscall FUN_006a5e80(int param_1,undefined4 param_2,int param_3)

{
  if (param_3 != 0) {
    if ((*(byte *)(param_1 + 8) & 7) == 0) {
      FUN_006a5700(param_3 * 8);
      FUN_0170c6f0((*(int *)(param_1 + 8) + 7U >> 3) + *(int *)(param_1 + 0x14),param_2,param_3);
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + param_3 * 8;
      return;
    }
    FUN_006a6060(param_2,param_3 * 8,1);
  }
  return;
}



/* FUNCTION 8574 ; VA 0x006a5ee0 ; FUN_006a5ee0 */

void __thiscall FUN_006a5ee0(int param_1,undefined4 param_2,int param_3)

{
  uint uVar1;
  
  uVar1 = (*(int *)(param_1 + 8) - (*(int *)(param_1 + 8) - 1U & 7)) + 7;
  *(uint *)(param_1 + 8) = uVar1;
  if (param_3 != 0) {
    if ((uVar1 & 7) == 0) {
      FUN_006a5700(param_3 * 8);
      FUN_0170c6f0((*(int *)(param_1 + 8) + 7U >> 3) + *(int *)(param_1 + 0x14),param_2,param_3);
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + param_3 * 8;
      return;
    }
    FUN_006a6060(param_2,param_3 * 8,1);
  }
  return;
}



/* FUNCTION 8575 ; VA 0x006a5f50 ; FUN_006a5f50 */

void __thiscall FUN_006a5f50(int param_1,undefined *param_2)

{
  char cVar1;
  undefined uVar2;
  undefined *puVar3;
  
  FUN_006a5700(0x10);
  cVar1 = FUN_005fda50();
  puVar3 = (undefined *)((*(uint *)(param_1 + 8) >> 3) + *(int *)(param_1 + 0x14));
  if (cVar1 == '\0') {
    *puVar3 = param_2[1];
    uVar2 = *param_2;
  }
  else {
    *puVar3 = *param_2;
    uVar2 = param_2[1];
  }
  *(undefined *)((*(uint *)(param_1 + 8) >> 3) + 1 + *(int *)(param_1 + 0x14)) = uVar2;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 0x10;
  return;
}



/* FUNCTION 8576 ; VA 0x006a5fa0 ; FUN_006a5fa0 */

void __thiscall FUN_006a5fa0(int param_1,undefined *param_2)

{
  char cVar1;
  undefined uVar2;
  uint uVar3;
  
  FUN_006a5700(0x20);
  cVar1 = FUN_005fda50();
  uVar3 = *(uint *)(param_1 + 8) >> 3;
  if (cVar1 == '\0') {
    *(undefined *)(uVar3 + *(int *)(param_1 + 0x14)) = param_2[3];
    *(undefined *)((*(uint *)(param_1 + 8) >> 3) + 1 + *(int *)(param_1 + 0x14)) = param_2[2];
    *(undefined *)((*(uint *)(param_1 + 8) >> 3) + 2 + *(int *)(param_1 + 0x14)) = param_2[1];
    uVar2 = *param_2;
  }
  else {
    *(undefined *)(uVar3 + *(int *)(param_1 + 0x14)) = *param_2;
    *(undefined *)((*(uint *)(param_1 + 8) >> 3) + 1 + *(int *)(param_1 + 0x14)) = param_2[1];
    *(undefined *)((*(uint *)(param_1 + 8) >> 3) + 2 + *(int *)(param_1 + 0x14)) = param_2[2];
    uVar2 = param_2[3];
  }
  *(undefined *)((*(uint *)(param_1 + 8) >> 3) + 3 + *(int *)(param_1 + 0x14)) = uVar2;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 0x20;
  return;
}



/* FUNCTION 8577 ; VA 0x006a6030 ; FUN_006a6030 */

void __thiscall FUN_006a6030(int param_1,undefined *param_2)

{
  FUN_006a5700(8);
  *(undefined *)((*(uint *)(param_1 + 8) >> 3) + *(int *)(param_1 + 0x14)) = *param_2;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 8;
  return;
}



/* FUNCTION 8578 ; VA 0x006a6060 ; FUN_006a6060 */

void __thiscall FUN_006a6060(int param_1,byte *param_2,uint param_3,char param_4)

{
  byte *pbVar1;
  uint uVar2;
  byte bVar3;
  uint uVar4;
  bool bVar5;
  
  FUN_006a5700(param_3);
  uVar4 = *(uint *)(param_1 + 8);
  uVar2 = uVar4 & 7;
  if ((uVar2 == 0) && ((param_3 & 7) == 0)) {
    FUN_0170c6f0((uVar4 >> 3) + *(int *)(param_1 + 0x14),param_2,param_3 >> 3);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + param_3;
    return;
  }
  if (param_3 != 0) {
    do {
      bVar3 = *param_2;
      param_2 = param_2 + 1;
      if ((param_3 < 8) && (param_4 != '\0')) {
        bVar3 = bVar3 << (8U - (char)param_3 & 0x1f);
      }
      pbVar1 = (byte *)((uVar4 >> 3) + *(int *)(param_1 + 0x14));
      if (uVar2 == 0) {
        *pbVar1 = bVar3;
      }
      else {
        uVar4 = 8 - uVar2;
        *pbVar1 = *pbVar1 | bVar3 >> (sbyte)uVar2;
        if ((uVar4 < 8) && (uVar4 < param_3)) {
          *(byte *)((*(uint *)(param_1 + 8) >> 3) + 1 + *(int *)(param_1 + 0x14)) =
               bVar3 << ((byte)uVar4 & 0x1f);
        }
      }
      uVar4 = param_3;
      if (7 < param_3) {
        uVar4 = 8;
      }
      bVar5 = param_3 < 8;
      param_3 = param_3 - 8;
      if (bVar5) {
        param_3 = 0;
      }
      uVar4 = *(int *)(param_1 + 8) + uVar4;
      *(uint *)(param_1 + 8) = uVar4;
    } while (param_3 != 0);
  }
  return;
}



/* FUNCTION 8579 ; VA 0x006a6150 ; FUN_006a6150 */

int __thiscall FUN_006a6150(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  int *piVar11;
  int *piVar12;
  int iVar13;
  
  iVar6 = *param_1;
  iVar13 = (int)param_2 - iVar6 >> 2;
  iVar2 = param_1[1] - iVar6 >> 2;
  if (iVar2 == 0x3fffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar3 = iVar2 + 1;
  uVar7 = param_1[2] - iVar6 >> 2;
  uVar4 = uVar3;
  if ((uVar7 <= 0x3fffffff - (uVar7 >> 1)) && (uVar4 = (uVar7 >> 1) + uVar7, uVar4 < uVar3)) {
    uVar4 = uVar3;
  }
  uVar7 = uVar4 * 4;
  if (uVar4 < 0x40000000) {
    if (0xfff < uVar7) goto LAB_006a61c2;
    if (uVar7 == 0) {
      puVar9 = (undefined4 *)0x0;
    }
    else {
      puVar9 = (undefined4 *)FUN_01674e20(uVar7);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_006a61c2:
    uVar5 = uVar7 + 0x23;
    if (uVar5 <= uVar7) {
      uVar5 = 0xffffffff;
    }
    iVar6 = FUN_01674e20(uVar5);
    if (iVar6 == 0) goto LAB_006a6336;
    puVar9 = (undefined4 *)(iVar6 + 0x23U & 0xffffffe0);
    puVar9[-1] = iVar6;
  }
  uVar1 = *param_3;
  *param_3 = 0;
  puVar9[iVar13] = uVar1;
  puVar10 = (undefined4 *)param_1[1];
  puVar8 = (undefined4 *)*param_1;
  if (param_2 == puVar10) {
    uVar7 = 0;
    uVar5 = (uint)((int)puVar10 + (3 - (int)puVar8)) >> 2;
    if (puVar10 < puVar8) {
      uVar5 = 0;
    }
    puVar10 = puVar9;
    if (uVar5 != 0) {
      do {
        uVar1 = *puVar8;
        *puVar8 = 0;
        puVar8 = puVar8 + 1;
        uVar7 = uVar7 + 1;
        *puVar10 = uVar1;
        puVar10 = puVar10 + 1;
      } while (uVar7 != uVar5);
    }
  }
  else {
    uVar5 = 0;
    uVar7 = (uint)((int)param_2 + (3 - (int)puVar8)) >> 2;
    if (param_2 < puVar8) {
      uVar7 = 0;
    }
    puVar10 = puVar9;
    if (uVar7 != 0) {
      do {
        uVar1 = *puVar8;
        *puVar8 = 0;
        puVar8 = puVar8 + 1;
        uVar5 = uVar5 + 1;
        *puVar10 = uVar1;
        puVar10 = puVar10 + 1;
      } while (uVar5 != uVar7);
    }
    uVar7 = 0;
    uVar5 = (uint)(param_1[1] + (3 - (int)param_2)) >> 2;
    if ((undefined4 *)param_1[1] < param_2) {
      uVar5 = 0;
    }
    if (uVar5 != 0) {
      puVar8 = param_2;
      do {
        uVar1 = *puVar8;
        *puVar8 = 0;
        uVar7 = uVar7 + 1;
        *(undefined4 *)(((int)(puVar9 + iVar13) - (int)param_2) + (int)(puVar8 + 1)) = uVar1;
        puVar8 = puVar8 + 1;
      } while (uVar7 != uVar5);
    }
  }
  piVar11 = (int *)*param_1;
  if (piVar11 != (int *)0x0) {
    piVar12 = (int *)param_1[1];
    if (piVar11 != piVar12) {
      do {
        if ((undefined4 *)*piVar11 != (undefined4 *)0x0) {
          (*(code *)**(undefined4 **)*piVar11)(1);
        }
        piVar11 = piVar11 + 1;
      } while (piVar11 != piVar12);
      piVar11 = (int *)*param_1;
    }
    uVar7 = param_1[2] - (int)piVar11 & 0xfffffffc;
    piVar12 = piVar11;
    if (0xfff < uVar7) {
      piVar12 = (int *)piVar11[-1];
      uVar7 = uVar7 + 0x23;
      if (0x1f < (uint)((int)piVar11 + (-4 - (int)piVar12))) {
LAB_006a6336:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar12,uVar7);
  }
  *param_1 = (int)puVar9;
  param_1[1] = (int)(puVar9 + uVar3);
  param_1[2] = (int)(puVar9 + uVar4);
  return *param_1 + iVar13 * 4;
}



/* FUNCTION 8580 ; VA 0x006a6350 ; FUN_006a6350 */

undefined * __thiscall FUN_006a6350(undefined *param_1,undefined param_2,undefined param_3)

{
  *param_1 = param_2;
  param_1[1] = param_3;
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  return param_1;
}



/* FUNCTION 8581 ; VA 0x006a6380 ; FUN_006a6380 */

void FUN_006a6380(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a653f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(0xc);
  uStack_8 = 0;
  if (iVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_00722a30(param_1,param_2);
  }
  uStack_8 = 0xffffffff;
  FUN_006a6470(uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8582 ; VA 0x006a63f0 ; FUN_006a63f0 */

void FUN_006a63f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a655f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(0x18);
  uStack_8 = 0;
  if (iVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_00722a50(param_1,param_2,param_3,param_4,param_5);
  }
  uStack_8 = 0xffffffff;
  FUN_006a6470(uVar2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8583 ; VA 0x006a6470 ; FUN_006a6470 */

undefined4 __thiscall FUN_006a6470(int param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a6578;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = (**(code **)(*param_2 + 4))();
  puVar4 = *(undefined4 **)(param_1 + 4);
  if (puVar4 < *(undefined4 **)(param_1 + 8)) {
    do {
      cVar3 = (**(code **)(*(int *)*puVar4 + 4))();
      if (cVar3 == cVar2) {
        if ((int)puVar4 - *(int *)(param_1 + 4) >> 2 != -1) {
          uVar5 = 7;
          goto LAB_006a6501;
        }
        break;
      }
      puVar4 = puVar4 + 1;
    } while (puVar4 < *(undefined4 **)(param_1 + 8));
  }
  piVar1 = param_2;
  puVar4 = *(undefined4 **)(param_1 + 8);
  if (*(undefined4 **)(param_1 + 0xc) == puVar4) {
    FUN_006a6150(puVar4,&param_2);
  }
  else {
    param_2 = (int *)0x0;
    *puVar4 = piVar1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 4;
  }
  uVar5 = 0;
LAB_006a6501:
  if (param_2 != (int *)0x0) {
    (**(code **)*param_2)(1);
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 8584 ; VA 0x006a6530 ; FUN_006a6530 */

undefined FUN_006a6530(undefined *param_1,undefined4 param_2)

{
  char cVar1;
  short sVar2;
  int iVar3;
  int *piVar4;
  undefined uVar5;
  ushort auStack_20 [3];
  ushort uStack_1a;
  short asStack_18 [2];
  char cStack_13;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a65b6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_006a5ae0(&cStack_11,8,1);
  if (cVar1 != '\0') {
    if (cStack_11 != '\x01') {
      ExceptionList = pvStack_10;
      return 2;
    }
    *param_1 = 1;
    cVar1 = FUN_006a5ae0(&cStack_12,8,1);
    if (cVar1 != '\0') {
      if (cStack_12 != '\0') {
        ExceptionList = pvStack_10;
        return 3;
      }
      param_1[1] = 0;
      cVar1 = FUN_005f7f10(auStack_20);
      if (cVar1 != '\0') {
        if (auStack_20[0] < 5) {
          ExceptionList = pvStack_10;
          return 4;
        }
        uStack_1a = 4;
        while ((cVar1 = FUN_006a5ae0(&cStack_13,8,1), cVar1 != '\0' &&
               (cVar1 = FUN_005f7f10(asStack_18), cVar1 != '\0'))) {
          if (cStack_13 == '\x01') {
            iVar3 = FUN_01674e20(0xc);
            uStack_8 = 0;
            if (iVar3 == 0) {
LAB_006a6695:
              piVar4 = (int *)0x0;
            }
            else {
              piVar4 = (int *)FUN_00722a30(0,0);
            }
          }
          else if (cStack_13 == '\x02') {
            iVar3 = FUN_01674e20(0x18);
            uStack_8 = 1;
            if (iVar3 == 0) goto LAB_006a6695;
            piVar4 = (int *)FUN_00722a50(0,0,0,0,0);
          }
          else {
            piVar4 = (int *)0x0;
          }
          uStack_8 = 2;
          if (piVar4 == (int *)0x0) {
            ExceptionList = pvStack_10;
            return 5;
          }
          sVar2 = (**(code **)(*piVar4 + 8))();
          if (asStack_18[0] != sVar2) {
            uVar5 = 6;
LAB_006a672e:
            if (piVar4 != (int *)0x0) {
              (**(code **)*piVar4)(1);
            }
            ExceptionList = pvStack_10;
            return uVar5;
          }
          iVar3 = (**(code **)(*piVar4 + 0x10))(param_2);
          if (iVar3 != 0) {
            uVar5 = 1;
            goto LAB_006a672e;
          }
          iVar3 = FUN_006a6470(piVar4);
          uVar5 = iVar3 != 0;
          if (iVar3 != 0) {
            piVar4 = (int *)0x0;
            goto LAB_006a672e;
          }
          uStack_1a = uStack_1a + asStack_18[0];
          uStack_8 = 0xffffffff;
          if (auStack_20[0] <= uStack_1a) {
            ExceptionList = pvStack_10;
            return 0;
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 8585 ; VA 0x006a6780 ; FUN_006a6780 */

short __fastcall FUN_006a6780(int param_1)

{
  short sVar1;
  uint uVar2;
  undefined4 *puVar3;
  uint uVar4;
  short sStack_8;
  
  puVar3 = *(undefined4 **)(param_1 + 4);
  uVar2 = (uint)((int)*(undefined4 **)(param_1 + 8) + (3 - (int)puVar3)) >> 2;
  uVar4 = 0;
  if (*(undefined4 **)(param_1 + 8) < puVar3) {
    uVar2 = 0;
  }
  sStack_8 = 4;
  if (uVar2 == 0) {
    return 4;
  }
  do {
    sVar1 = (**(code **)(*(int *)*puVar3 + 8))();
    uVar4 = uVar4 + 1;
    puVar3 = puVar3 + 1;
    sStack_8 = sStack_8 + sVar1;
  } while (uVar4 != uVar2);
  return sStack_8;
}



/* FUNCTION 8586 ; VA 0x006a67e0 ; FUN_006a67e0 */

void __thiscall FUN_006a67e0(int param_1,uint param_2)

{
  char cVar1;
  undefined uVar2;
  short sVar3;
  uint *puVar4;
  ushort uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  uint uVar8;
  uint uVar9;
  uint uStack_10;
  uint uStack_c;
  uint uStack_8;
  
  uVar9 = param_2;
  FUN_006a6060(param_1,8,1);
  FUN_006a6060(param_1 + 1,8,1);
  puVar6 = *(undefined4 **)(param_1 + 4);
  uStack_8 = 4;
  uStack_10 = (*(int *)(param_1 + 8) - (int)puVar6) + 3U >> 2;
  uStack_8._0_2_ = 4;
  if (*(undefined4 **)(param_1 + 8) < puVar6) {
    uStack_10 = 0;
  }
  uVar5 = (ushort)uStack_8;
  if (uStack_10 != 0) {
    uVar8 = 0;
    do {
      sVar3 = (**(code **)(*(int *)*puVar6 + 8))();
      uVar8 = uVar8 + 1;
      puVar6 = puVar6 + 1;
      uVar5 = uVar5 + sVar3;
      uVar9 = param_2;
    } while (uVar8 != uStack_10);
  }
  uStack_c = (uint)uVar5;
  cVar1 = FUN_005fda50();
  if (cVar1 == '\0') {
    FUN_006a5c10(&uStack_c,&param_2,2);
    puVar4 = &param_2;
  }
  else {
    puVar4 = &uStack_c;
  }
  FUN_006a6060(puVar4,0x10,1);
  puVar6 = *(undefined4 **)(param_1 + 8);
  for (puVar7 = *(undefined4 **)(param_1 + 4); puVar7 != puVar6; puVar7 = puVar7 + 1) {
    uVar2 = (**(code **)(*(int *)*puVar7 + 4))();
    param_2 = CONCAT13(uVar2,(undefined3)param_2);
    FUN_006a6060((int)&param_2 + 3,8,1);
    uStack_10 = (**(code **)(*(int *)*puVar7 + 8))();
    uStack_10 = uStack_10 & 0xffff;
    cVar1 = FUN_005fda50();
    if (cVar1 == '\0') {
      FUN_006a5c10(&uStack_10,&uStack_8,2);
      puVar4 = &uStack_8;
    }
    else {
      puVar4 = &uStack_10;
    }
    FUN_006a6060(puVar4,0x10,1);
    (**(code **)(*(int *)*puVar7 + 0xc))(uVar9);
  }
  return;
}



/* FUNCTION 8587 ; VA 0x006a6900 ; FUN_006a6900 */

void FUN_006a6900(void)

{
  undefined8 uVar1;
  
  uVar1 = FUN_006a6920();
  FUN_016f3c60(uVar1,1000,0);
  return;
}



/* FUNCTION 8588 ; VA 0x006a6920 ; FUN_006a6920 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_006a6920(void)

{
  undefined4 uVar1;
  uint extraout_ECX;
  int unaff_EBX;
  undefined8 uVar2;
  longlong lVar3;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  uint uStack_8;
  
  if (DAT_01eaeb20 == '\0') {
    DAT_01eaeb20 = '\x01';
    uVar1 = GetCurrentProcess();
    GetProcessAffinityMask(uVar1,&DAT_01eaeb14,&DAT_01eaeb18);
    _DAT_01eaeb1c = GetCurrentThread();
  }
  QueryPerformanceFrequency(&uStack_14);
  QueryPerformanceCounter(&uStack_c);
  uVar2 = FUN_016f43b0(uStack_c,uStack_8,uStack_14,uStack_10);
  uStack_8 = (uint)uVar2;
  lVar3 = FUN_016f3c60((int)((ulonglong)extraout_ECX * 1000000),
                       unaff_EBX * 1000000 + (int)((ulonglong)extraout_ECX * 1000000 >> 0x20),
                       uStack_14,uStack_10);
  return lVar3 + CONCAT44((int)((ulonglong)uStack_8 * 1000000 >> 0x20) +
                          (int)((ulonglong)uVar2 >> 0x20) * 1000000,
                          (int)((ulonglong)uStack_8 * 1000000));
}



/* FUNCTION 8589 ; VA 0x006a69e0 ; FUN_006a69e0 */

undefined4 * __fastcall FUN_006a69e0(undefined4 *param_1)

{
  *param_1 = RakNet::CCRakNetSlidingWindow::vftable;
  return param_1;
}



/* FUNCTION 8590 ; VA 0x006a6a00 ; FUN_006a6a00 */

void __fastcall FUN_006a6a00(undefined4 *param_1)

{
  *param_1 = RakNet::CCRakNetBase::vftable;
  return;
}



/* FUNCTION 8591 ; VA 0x006a6a10 ; FUN_006a6a10 */

undefined4 * __thiscall FUN_006a6a10(undefined4 *param_1,byte param_2)

{
  *param_1 = RakNet::CCRakNetBase::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 8592 ; VA 0x006a6a40 ; FUN_006a6a40 */

undefined4 * __thiscall FUN_006a6a40(undefined4 *param_1,byte param_2)

{
  *param_1 = RakNet::CCRakNetBase::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x40);
  }
  return param_1;
}



/* FUNCTION 8593 ; VA 0x006a6a70 ; FUN_006a6a70 */

void __thiscall FUN_006a6a70(int param_1,int *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x28);
  *param_2 = iVar1;
  *(int *)(param_1 + 0x28) = iVar1 + 1;
  *(undefined *)(param_1 + 0x2b) = 0;
  return;
}



/* FUNCTION 8594 ; VA 0x006a6a90 ; FUN_006a6a90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined __fastcall FUN_006a6a90(int param_1)

{
  double dVar1;
  
  dVar1 = *(double *)(param_1 + 0x18);
  if ((dVar1 < *(double *)(param_1 + 0x10)) &&
     ((NAN(dVar1) || NAN(_PTR_018c6f48)) == (dVar1 == _PTR_018c6f48))) {
    return 0;
  }
  return 1;
}



/* FUNCTION 8595 ; VA 0x006a6ab0 ; FUN_006a6ab0 */

void __thiscall FUN_006a6ab0(int param_1,undefined4 *param_2)

{
  *param_2 = *(undefined4 *)(param_1 + 0x28);
  return;
}



/* FUNCTION 8596 ; VA 0x006a6ac0 ; FUN_006a6ac0 */

longlong __fastcall FUN_006a6ac0(int param_1)

{
  int iVar1;
  int iVar2;
  double dVar3;
  double dVar4;
  undefined8 uVar5;
  longlong lVar6;
  
  iVar2 = DAT_01d5b2d8;
  iVar1 = DAT_01d5b2c8;
  dVar3 = *(double *)(param_1 + 8);
  if ((NAN(dVar3) || NAN(DAT_018ce330)) == (dVar3 == DAT_018ce330)) {
    dVar3 = (double)DAT_01d5b2e0 * dVar3;
    dVar4 = dVar3;
    FUN_016f3fe0();
    if (dVar3 <= dVar4) {
      FUN_016f3fe0();
      if (dVar4 <= dVar3) {
        uVar5 = FUN_016f3ec0();
        lVar6 = FUN_016f39b0(uVar5,DAT_01d5b2e0,DAT_01d5b2e0 >> 0x1f);
        return lVar6;
      }
      return (longlong)iVar2;
    }
  }
  return (longlong)iVar1;
}



/* FUNCTION 8597 ; VA 0x006a6b70 ; FUN_006a6b70 */

float10 __fastcall FUN_006a6b70(int param_1)

{
  double dVar1;
  
  dVar1 = *(double *)(param_1 + 8);
  if ((NAN(dVar1) || NAN(DAT_018ce330)) != (dVar1 == DAT_018ce330)) {
    return (float10)0;
  }
  return (float10)dVar1;
}



/* FUNCTION 8598 ; VA 0x006a6ba0 ; FUN_006a6ba0 */

undefined4 FUN_006a6ba0(void)

{
  undefined4 in_stack_00000014;
  
  return in_stack_00000014;
}



/* FUNCTION 8599 ; VA 0x006a6bb0 ; FUN_006a6bb0 */

int __thiscall FUN_006a6bb0(int param_1)

{
  int in_stack_00000014;
  undefined in_stack_00000018;
  
  *(undefined *)(param_1 + 0x38) = in_stack_00000018;
  if ((double)in_stack_00000014 + (double)(&DAT_018c0d90)[-(in_stack_00000014 >> 0x1f)] <=
      *(double *)(param_1 + 0x10)) {
    return (int)(*(double *)(param_1 + 0x10) -
                ((double)in_stack_00000014 + (double)(&DAT_018c0d90)[-(in_stack_00000014 >> 0x1f)]))
    ;
  }
  return 0;
}



/* FUNCTION 8600 ; VA 0x006a6bf0 ; FUN_006a6bf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_006a6bf0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  double dVar1;
  undefined8 uVar2;
  
  uVar2 = DAT_018ce330;
  *(int *)(param_1 + 4) = param_4;
  *(undefined8 *)(param_1 + 8) = uVar2;
  dVar1 = (double)(&DAT_018c0d90)[-(param_4 >> 0x1f)];
  *(double *)(param_1 + 0x10) = (double)param_4 + dVar1;
  if ((DAT_01eaeb24 != 0) && (DAT_01eaeb24 < 0x2711)) {
    *(double *)(param_1 + 0x10) =
         ((double)DAT_01eaeb24 / _PTR_018dab58) * (double)DAT_01d59cbc * ((double)param_4 + dVar1);
  }
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined8 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined *)(param_1 + 0x2b) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined2 *)(param_1 + 0x2f) = 0;
  *(undefined *)(param_1 + 0x31) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0;
  *(undefined2 *)(param_1 + 0x37) = 0;
  return;
}



/* FUNCTION 8601 ; VA 0x006a6ca0 ; FUN_006a6ca0 */

void __thiscall FUN_006a6ca0(int param_1)

{
  double dVar1;
  bool bVar2;
  int iVar3;
  undefined8 in_XMM0_Qa;
  double dVar4;
  char in_stack_00000030;
  int in_stack_00000034;
  
  FUN_016f3fe0();
  *(undefined8 *)(param_1 + 8) = in_XMM0_Qa;
  *(char *)(param_1 + 0x38) = in_stack_00000030;
  if (in_stack_00000030 != '\0') {
    if ((*(int *)(param_1 + 0x2c) == in_stack_00000034) ||
       ((*(int *)(param_1 + 0x2c) - in_stack_00000034 & 0xffffffU) < 0x800000)) {
      dVar4 = *(double *)(param_1 + 0x18);
      bVar2 = false;
    }
    else {
      bVar2 = true;
      *(undefined4 *)(param_1 + 0x2c) = *(undefined4 *)(param_1 + 0x28);
      dVar4 = 0.0;
      *(undefined2 *)(param_1 + 0x30) = 0;
      *(undefined8 *)(param_1 + 0x18) = 0;
    }
    dVar1 = *(double *)(param_1 + 0x10);
    if ((dVar1 <= dVar4) || (NAN(dVar4) != (dVar4 == 0.0))) {
      if ((dVar1 < DAT_018dab60) &&
         ((*(double *)(param_1 + 0x10) = dVar1 + dVar1, dVar4 < dVar1 + dVar1 &&
          (NAN(dVar4) == (dVar4 == 0.0))))) {
        iVar3 = *(int *)(param_1 + 4) * *(int *)(param_1 + 4);
        *(double *)(param_1 + 0x10) =
             ((double)iVar3 + (double)(&DAT_018c0d90)[-(iVar3 >> 0x1f)]) / dVar4 + dVar4;
      }
    }
    else if (bVar2) {
      iVar3 = *(int *)(param_1 + 4) * *(int *)(param_1 + 4);
      *(double *)(param_1 + 0x10) =
           ((double)iVar3 + (double)(&DAT_018c0d90)[-(iVar3 >> 0x1f)]) / dVar1 + dVar1;
      return;
    }
  }
  return;
}



/* FUNCTION 8602 ; VA 0x006a6da0 ; FUN_006a6da0 */

void __thiscall FUN_006a6da0(int *param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(*param_1 + 0x30))(param_2,param_3);
  return;
}



/* FUNCTION 8603 ; VA 0x006a6dc0 ; FUN_006a6dc0 */

undefined4 __thiscall
FUN_006a6dc0(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,uint *param_7)

{
  int iVar1;
  uint uVar2;
  
  if (*(int *)(param_1 + 0x20) == 0 && *(int *)(param_1 + 0x24) == 0) {
    *(undefined4 *)(param_1 + 0x20) = param_4;
    *(undefined4 *)(param_1 + 0x24) = param_5;
  }
  iVar1 = *(int *)(param_1 + 0x34);
  if (param_2 == iVar1) {
    *param_7 = 0;
    *(uint *)(param_1 + 0x34) = param_2 + 1U & 0xffffff;
    return 1;
  }
  if ((iVar1 - param_2 & 0xffffffU) < 0x800000) {
    *param_7 = 0;
    return 1;
  }
  uVar2 = param_2 - iVar1 & 0xffffff;
  *param_7 = uVar2;
  if (1000 < uVar2) {
    if (50000 < uVar2) {
      return 0;
    }
    *param_7 = 1000;
  }
  *(uint *)(param_1 + 0x34) = param_2 + 1U & 0xffffff;
  return 1;
}



/* FUNCTION 8604 ; VA 0x006a6e60 ; FUN_006a6e60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_006a6e60(int param_1)

{
  int iVar1;
  double dVar2;
  double dVar3;
  
  if ((*(char *)(param_1 + 0x38) != '\0') && (*(char *)(param_1 + 0x30) == '\0')) {
    iVar1 = *(int *)(param_1 + 4);
    dVar3 = *(double *)(param_1 + 0x10);
    if ((double)(iVar1 * 2) + (double)(&DAT_018c0d90)[-(iVar1 * 2 >> 0x1f)] < dVar3) {
      dVar2 = (double)iVar1 + (double)(&DAT_018c0d90)[-(iVar1 >> 0x1f)];
      if (DAT_01eaeb28 - 1U < 9999) {
        dVar3 = ((_PTR_018dab58 - (double)DAT_01eaeb28) / _PTR_018dab58) * dVar3;
        *(double *)(param_1 + 0x10) = dVar3;
        if (dVar3 < dVar2) {
          *(double *)(param_1 + 0x10) = dVar2;
          *(double *)(param_1 + 0x18) = dVar2;
          *(undefined *)(param_1 + 0x30) = 1;
          return;
        }
        *(undefined *)(param_1 + 0x30) = 1;
        *(double *)(param_1 + 0x18) = dVar3;
        return;
      }
      dVar3 = dVar3 * _PTR_018cf0f8;
      *(double *)(param_1 + 0x18) = dVar3;
      if (dVar3 < dVar2) {
        *(double *)(param_1 + 0x18) = dVar2;
      }
      *(double *)(param_1 + 0x10) = dVar2;
      *(undefined *)(param_1 + 0x30) = 1;
    }
  }
  return;
}



/* FUNCTION 8605 ; VA 0x006a6f30 ; FUN_006a6f30 */

void __fastcall FUN_006a6f30(int param_1)

{
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  return;
}



/* FUNCTION 8606 ; VA 0x006a6f50 ; FUN_006a6f50 */

void FUN_006a6f50(undefined4 param_1,undefined4 param_2,undefined *param_3)

{
  *param_3 = 0;
  return;
}



/* FUNCTION 8607 ; VA 0x006a6f60 ; FUN_006a6f60 */

void FUN_006a6f60(void)

{
  return;
}



/* FUNCTION 8608 ; VA 0x006a6f70 ; FUN_006a6f70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_006a6f70(int param_1,int param_2)

{
  double dVar1;
  
  if (((DAT_01eaeb24 != 0) && (DAT_01eaeb24 < 0x2711)) &&
     (dVar1 = ((double)(DAT_01d59cbc * param_2) +
              (double)(&DAT_018c0d90)[-(DAT_01d59cbc * param_2 >> 0x1f)]) *
              ((double)DAT_01eaeb24 / _PTR_018dab58),
     *(double *)(param_1 + 0x10) <= dVar1 && dVar1 != *(double *)(param_1 + 0x10))) {
    *(double *)(param_1 + 0x10) = dVar1;
  }
  return;
}



/* FUNCTION 8609 ; VA 0x006a6fd0 ; FUN_006a6fd0 */

uint __thiscall FUN_006a6fd0(int param_1,uint param_2,uint param_3)

{
  double dVar1;
  undefined4 in_EAX;
  uint uVar2;
  undefined8 uVar3;
  
  dVar1 = *(double *)(param_1 + 8);
  uVar2 = (uint)CONCAT21((short)((uint)in_EAX >> 0x10),
                         (dVar1 == DAT_018ce330) << 6 | (NAN(dVar1) || NAN(DAT_018ce330)) << 2 | 2U
                         | dVar1 < DAT_018ce330) << 8;
  if ((NAN(dVar1) || NAN(DAT_018ce330)) == (dVar1 == DAT_018ce330)) {
    uVar3 = FUN_016f3ec0();
    uVar2 = (uint)uVar3 & (uint)((ulonglong)uVar3 >> 0x20);
    if (uVar2 != 0xffffffff) {
      uVar2 = *(int *)(param_1 + 0x24) + (uint)(0xffffd8ef < *(uint *)(param_1 + 0x20));
      if ((param_3 < uVar2) || ((param_3 <= uVar2 && (param_2 < *(uint *)(param_1 + 0x20) + 10000)))
         ) {
        return uVar2 & 0xffffff00;
      }
    }
  }
  return CONCAT31((int3)(uVar2 >> 8),1);
}



/* FUNCTION 8610 ; VA 0x006a7030 ; FUN_006a7030 */

void FUN_006a7030(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar4 = FUN_006a8fb0(param_1,param_2);
  uVar1 = param_3[1];
  uVar2 = param_3[2];
  uVar3 = param_3[3];
  *(undefined4 *)(iVar4 + 8) = *param_3;
  *(undefined4 *)(iVar4 + 0xc) = uVar1;
  *(undefined4 *)(iVar4 + 0x10) = uVar2;
  *(undefined4 *)(iVar4 + 0x14) = uVar3;
  uVar1 = param_3[5];
  uVar2 = param_3[6];
  uVar3 = param_3[7];
  *(undefined4 *)(iVar4 + 0x18) = param_3[4];
  *(undefined4 *)(iVar4 + 0x1c) = uVar1;
  *(undefined4 *)(iVar4 + 0x20) = uVar2;
  *(undefined4 *)(iVar4 + 0x24) = uVar3;
  uVar1 = param_3[9];
  uVar2 = param_3[10];
  uVar3 = param_3[0xb];
  *(undefined4 *)(iVar4 + 0x28) = param_3[8];
  *(undefined4 *)(iVar4 + 0x2c) = uVar1;
  *(undefined4 *)(iVar4 + 0x30) = uVar2;
  *(undefined4 *)(iVar4 + 0x34) = uVar3;
  *(undefined8 *)(iVar4 + 0x38) = *(undefined8 *)(param_3 + 0xc);
  return;
}



/* FUNCTION 8611 ; VA 0x006a7070 ; FUN_006a7070 */

void FUN_006a7070(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = param_2[1];
  iVar3 = param_1[1];
  if (((*(int *)(iVar2 + 0x14) < *(int *)(iVar3 + 0x14)) ||
      ((*(int *)(iVar2 + 0x14) <= *(int *)(iVar3 + 0x14) &&
       (*(uint *)(iVar2 + 0x10) < *(uint *)(iVar3 + 0x10))))) && (param_2 != param_1)) {
    uVar1 = *param_2;
    *param_2 = *param_1;
    *param_1 = uVar1;
    iVar3 = param_2[1];
    param_2[1] = param_1[1];
    param_1[1] = iVar3;
    iVar2 = param_2[1];
  }
  if ((*(int *)(param_3[1] + 0x14) <= *(int *)(iVar2 + 0x14)) &&
     ((*(int *)(param_3[1] + 0x14) < *(int *)(iVar2 + 0x14) ||
      (*(uint *)(param_3[1] + 0x10) < *(uint *)(iVar2 + 0x10))))) {
    if (param_3 != param_2) {
      uVar1 = *param_3;
      *param_3 = *param_2;
      *param_2 = uVar1;
      iVar2 = param_3[1];
      param_3[1] = param_2[1];
      param_2[1] = iVar2;
      iVar3 = param_1[1];
    }
    if ((*(int *)(iVar2 + 0x14) <= *(int *)(iVar3 + 0x14)) &&
       (((*(int *)(iVar2 + 0x14) < *(int *)(iVar3 + 0x14) ||
         (*(uint *)(iVar2 + 0x10) < *(uint *)(iVar3 + 0x10))) && (param_2 != param_1)))) {
      uVar1 = *param_2;
      *param_2 = *param_1;
      *param_1 = uVar1;
      uVar1 = param_2[1];
      param_2[1] = param_1[1];
      param_1[1] = uVar1;
    }
  }
  return;
}



/* FUNCTION 8612 ; VA 0x006a7120 ; FUN_006a7120 */

void FUN_006a7120(uint *param_1,int *param_2,int *param_3,uint param_4)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  int *piVar9;
  int *piVar10;
  uint uStack_18;
  int *piStack_10;
  int *piStack_c;
  int *piStack_8;
  
  piStack_8 = param_2 + ((int)param_3 - (int)param_2 >> 4) * 2;
  uStack_18 = param_4 & 0xff;
  iVar4 = (int)(param_3 + -2) - (int)param_2 >> 3;
  if (iVar4 < 0x29) {
    FUN_006a7070(param_2,piStack_8,param_3 + -2,param_4);
  }
  else {
    iVar4 = iVar4 + 1 >> 3;
    FUN_006a7070(param_2,param_2 + iVar4 * 2,param_2 + iVar4 * 4,param_4);
    FUN_006a7070(piStack_8 + iVar4 * -2,piStack_8,piStack_8 + iVar4 * 2,uStack_18);
    piVar5 = param_3 + -2;
    FUN_006a7070(piVar5 + iVar4 * -4,piVar5 + iVar4 * -2,piVar5,uStack_18);
    FUN_006a7070(param_2 + iVar4 * 2,piStack_8,piVar5 + iVar4 * -2,uStack_18);
  }
  piVar5 = piStack_8 + 2;
  for (; param_2 < piStack_8; piStack_8 = piStack_8 + -2) {
    iVar4 = *(int *)(piStack_8[-1] + 0x14);
    uVar1 = *(uint *)(piStack_8[-1] + 0x10);
    uVar2 = *(uint *)(piStack_8[1] + 0x10);
    iVar3 = *(int *)(piStack_8[1] + 0x14);
    if ((iVar4 < iVar3) ||
       ((((iVar4 <= iVar3 && (uVar1 < uVar2)) || (iVar3 < iVar4)) ||
        ((iVar3 <= iVar4 && (uVar2 < uVar1)))))) break;
  }
  piVar7 = piVar5;
  piStack_10 = piVar5;
  piStack_c = piVar5;
  piVar8 = piStack_8;
  if (piVar5 < param_3) {
    uVar1 = *(uint *)(piStack_8[1] + 0x10);
    iVar4 = *(int *)(piStack_8[1] + 0x14);
    while( true ) {
      uVar2 = *(uint *)(piVar5[1] + 0x10);
      iVar3 = *(int *)(piVar5[1] + 0x14);
      piVar7 = piVar5;
      piStack_10 = piVar5;
      piStack_c = piVar5;
      if (((iVar3 < iVar4) || ((iVar3 <= iVar4 && (uVar2 < uVar1)))) || (iVar4 < iVar3)) break;
      if (((iVar4 <= iVar3) && (uVar1 < uVar2)) ||
         (piVar5 = piVar5 + 2, piVar7 = piVar5, piStack_10 = piVar5, piStack_c = piVar5,
         param_3 <= piVar5)) break;
    }
  }
joined_r0x006a7252:
  do {
    if (param_3 <= piVar5) {
LAB_006a72b1:
      piVar9 = piVar8;
      piVar10 = piVar7;
      if (param_2 < piStack_8) {
        piVar7 = piStack_8 + -1;
        do {
          uVar1 = *(uint *)(*piVar7 + 0x10);
          iVar4 = *(int *)(*piVar7 + 0x14);
          uVar2 = *(uint *)(piVar8[1] + 0x10);
          iVar3 = *(int *)(piVar8[1] + 0x14);
          piVar9 = piVar8;
          piVar5 = piStack_10;
          piVar10 = piStack_c;
          if ((iVar3 <= iVar4) && ((iVar3 < iVar4 || (uVar2 <= uVar1)))) {
            if ((iVar3 < iVar4) || ((iVar3 <= iVar4 && (uVar2 < uVar1)))) break;
            piVar9 = piVar8 + -2;
            if (piVar9 != piVar7 + -1) {
              iVar4 = *piVar9;
              *piVar9 = piVar7[-1];
              piVar7[-1] = iVar4;
              iVar4 = piVar8[-1];
              piVar8[-1] = *piVar7;
              *piVar7 = iVar4;
            }
          }
          piStack_8 = piStack_8 + -2;
          piVar7 = piVar7 + -2;
          piVar8 = piVar9;
        } while (param_2 < piStack_8);
      }
      if (piStack_8 == param_2) {
        if (piVar5 == param_3) {
          param_1[1] = (uint)piVar10;
          *param_1 = (uint)piVar9;
          return;
        }
        if ((piVar10 != piVar5) && (piVar9 != piVar10)) {
          iVar4 = *piVar9;
          *piVar9 = *piVar10;
          *piVar10 = iVar4;
          iVar4 = piVar9[1];
          piVar9[1] = piVar10[1];
          piVar10[1] = iVar4;
        }
        if (piVar9 != piVar5) {
          iVar4 = *piVar9;
          *piVar9 = *piVar5;
          *piVar5 = iVar4;
          iVar4 = piVar9[1];
          piVar9[1] = piVar5[1];
          piVar5[1] = iVar4;
        }
        piVar5 = piVar5 + 2;
        piVar7 = piVar10 + 2;
        piStack_10 = piVar5;
        piStack_c = piVar10 + 2;
        piVar8 = piVar9 + 2;
      }
      else {
        piVar6 = piStack_8 + -2;
        if (piVar5 == param_3) {
          piVar8 = piVar9 + -2;
          if (piVar6 != piVar8) {
            iVar4 = *piVar6;
            *piVar6 = *piVar8;
            *piVar8 = iVar4;
            iVar4 = piStack_8[-1];
            piStack_8[-1] = piVar9[-1];
            piVar9[-1] = iVar4;
          }
          piVar7 = piVar10 + -2;
          piStack_c = piVar7;
          piStack_8 = piVar6;
          if (piVar8 != piVar7) {
            iVar4 = *piVar8;
            *piVar8 = *piVar7;
            *piVar7 = iVar4;
            iVar4 = piVar9[-1];
            piVar9[-1] = piVar10[-1];
            piVar10[-1] = iVar4;
          }
        }
        else {
          if (piVar5 != piVar6) {
            iVar4 = *piVar5;
            *piVar5 = *piVar6;
            *piVar6 = iVar4;
            iVar4 = piVar5[1];
            piVar5[1] = piStack_8[-1];
            piStack_8[-1] = iVar4;
          }
          piVar5 = piVar5 + 2;
          piVar7 = piVar10;
          piStack_10 = piVar5;
          piStack_8 = piVar6;
          piVar8 = piVar9;
        }
      }
      goto joined_r0x006a7252;
    }
    uVar1 = *(uint *)(piVar8[1] + 0x10);
    iVar4 = *(int *)(piVar8[1] + 0x14);
    uVar2 = *(uint *)(piVar5[1] + 0x10);
    iVar3 = *(int *)(piVar5[1] + 0x14);
    if ((iVar3 <= iVar4) && ((iVar3 < iVar4 || (uVar2 <= uVar1)))) {
      piStack_10 = piVar5;
      piStack_c = piVar7;
      if ((iVar3 < iVar4) || ((iVar3 <= iVar4 && (uVar2 < uVar1)))) goto LAB_006a72b1;
      if (piVar7 != piVar5) {
        iVar4 = *piVar7;
        *piVar7 = *piVar5;
        *piVar5 = iVar4;
        iVar4 = piVar7[1];
        piVar7[1] = piVar5[1];
        piVar5[1] = iVar4;
      }
      piVar7 = piVar7 + 2;
    }
    piVar5 = piVar5 + 2;
    piStack_10 = piVar5;
    piStack_c = piVar7;
  } while( true );
}



/* FUNCTION 8613 ; VA 0x006a7430 ; FUN_006a7430 */

void FUN_006a7430(int param_1,int param_2,uint param_3,undefined4 *param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  
  iVar6 = (int)(param_3 - 1) >> 1;
  iVar4 = param_2;
  iVar3 = param_2;
  if (param_2 < iVar6) {
    do {
      iVar1 = *(int *)(param_1 + 0x14 + iVar4 * 0x10);
      iVar5 = *(int *)(param_1 + 0xc + iVar4 * 0x10);
      iVar2 = *(int *)(iVar1 + 0x14);
      iVar3 = *(int *)(iVar5 + 0x14);
      if ((iVar2 < iVar3) ||
         ((iVar2 <= iVar3 && (*(uint *)(iVar1 + 0x10) < *(uint *)(iVar5 + 0x10))))) {
        iVar3 = 1;
      }
      else {
        iVar3 = 2;
      }
      iVar3 = iVar4 * 2 + iVar3;
      *(undefined4 *)(param_1 + iVar4 * 8) = *(undefined4 *)(param_1 + iVar3 * 8);
      *(undefined4 *)(param_1 + 4 + iVar4 * 8) = *(undefined4 *)(param_1 + 4 + iVar3 * 8);
      iVar4 = iVar3;
    } while (iVar3 < iVar6);
  }
  if ((iVar3 == iVar6) && ((param_3 & 1) == 0)) {
    *(undefined4 *)(param_1 + iVar3 * 8) = *(undefined4 *)(param_1 + -8 + param_3 * 8);
    *(undefined4 *)(param_1 + 4 + iVar3 * 8) = *(undefined4 *)(param_1 + -4 + param_3 * 8);
    iVar3 = param_3 - 1;
  }
  while (param_2 < iVar3) {
    iVar5 = iVar3 + -1 >> 1;
    iVar6 = *(int *)(param_1 + 4 + iVar5 * 8);
    iVar1 = *(int *)(iVar6 + 0x14);
    iVar4 = *(int *)(param_4[1] + 0x14);
    if ((iVar4 < iVar1) ||
       ((iVar4 <= iVar1 && (*(uint *)(param_4[1] + 0x10) <= *(uint *)(iVar6 + 0x10))))) break;
    *(undefined4 *)(param_1 + iVar3 * 8) = *(undefined4 *)(param_1 + iVar5 * 8);
    *(undefined4 *)(param_1 + 4 + iVar3 * 8) = *(undefined4 *)(param_1 + 4 + iVar5 * 8);
    iVar3 = iVar5;
  }
  *(undefined4 *)(param_1 + iVar3 * 8) = *param_4;
  *(undefined4 *)(param_1 + 4 + iVar3 * 8) = param_4[1];
  return;
}



/* FUNCTION 8614 ; VA 0x006a7510 ; FUN_006a7510 */

void FUN_006a7510(undefined4 *param_1,undefined4 *param_2,int param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  bool bVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined4 *puVar9;
  int iVar10;
  undefined4 *puVar11;
  uint uVar12;
  int iVar13;
  undefined4 *puVar14;
  undefined4 *puStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int iStack_14;
  uint uStack_10;
  int iStack_c;
  int iStack_8;
  
  iVar6 = (int)param_2 - (int)param_1;
  puVar14 = param_1;
  do {
    iVar6 = iVar6 >> 3;
    if (iVar6 < 0x21) {
LAB_006a759e:
      if ((1 < iVar6) && (puVar7 = puVar14, puVar14 != param_2)) {
        while (puVar14 = puVar14 + 2, puVar14 != param_2) {
          iVar13 = puVar14[1];
          uVar4 = *puVar14;
          iVar6 = *(int *)(puVar7[1] + 0x14);
          puVar9 = puVar14;
          if ((iVar6 < *(int *)(iVar13 + 0x14)) ||
             ((iVar6 <= *(int *)(iVar13 + 0x14) &&
              (*(uint *)(puVar7[1] + 0x10) <= *(uint *)(iVar13 + 0x10))))) {
            while( true ) {
              iVar6 = *(int *)(puVar9[-1] + 0x14);
              if ((iVar6 < *(int *)(iVar13 + 0x14)) ||
                 ((iVar6 <= *(int *)(iVar13 + 0x14) &&
                  (*(uint *)(puVar9[-1] + 0x10) <= *(uint *)(iVar13 + 0x10))))) break;
              *puVar9 = puVar9[-2];
              puVar9[1] = puVar9[-1];
              puVar9 = puVar9 + -2;
            }
            *puVar9 = uVar4;
            puVar9[1] = iVar13;
            puVar7 = param_1;
          }
          else {
            if (puVar14 != puVar7) {
              puVar9 = puVar14 + -1;
              puVar11 = puVar14 + 2;
              do {
                puVar11[-2] = puVar9[-1];
                puVar11[-1] = *puVar9;
                puVar1 = puVar9 + -1;
                puVar9 = puVar9 + -2;
                puVar11 = puVar11 + -2;
              } while (puVar1 != puVar7);
            }
            *puVar7 = uVar4;
            puVar7[1] = iVar13;
          }
        }
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < iVar6) {
        iVar6 = (int)param_2 - (int)puVar14;
        uVar12 = iVar6 >> 3;
        iVar13 = iVar6 >> 4;
        if (0 < iVar13) {
          iStack_8 = (int)(uVar12 - 1) >> 1;
          puVar7 = puVar14 + iVar13 * 2;
          do {
            uStack_1c = puVar7[-2];
            puStack_20 = puVar7 + -2;
            iVar13 = iVar13 + -1;
            iStack_c = puVar7[-1];
            iVar2 = iVar13;
            while (iVar2 < iStack_8) {
              iStack_14 = iVar2 * 2;
              iVar10 = *(int *)(puVar14[iVar2 * 4 + 5] + 0x14);
              iVar8 = *(int *)(puVar14[iVar2 * 4 + 3] + 0x14);
              if ((iVar10 < iVar8) ||
                 ((iVar10 <= iVar8 &&
                  (*(uint *)(puVar14[iVar2 * 4 + 5] + 0x10) <
                   *(uint *)(puVar14[iVar2 * 4 + 3] + 0x10))))) {
                iVar8 = 1;
              }
              else {
                iVar8 = 2;
              }
              iVar8 = iStack_14 + iVar8;
              puVar14[iVar2 * 2] = puVar14[iVar8 * 2];
              puVar14[iVar2 * 2 + 1] = puVar14[iVar8 * 2 + 1];
              iVar2 = iVar8;
            }
            if ((iVar2 == iStack_8) && ((uVar12 & 1) == 0)) {
              puVar14[iVar2 * 2] = puVar14[uVar12 * 2 + -2];
              puVar14[iVar2 * 2 + 1] = puVar14[uVar12 * 2 + -1];
              iVar2 = uVar12 - 1;
            }
            while (iVar13 < iVar2) {
              iVar10 = iVar2 + -1 >> 1;
              piVar3 = puVar14 + iVar10 * 2 + 1;
              iVar8 = *(int *)(*piVar3 + 0x14);
              puVar14 = param_1;
              if ((*(int *)(iStack_c + 0x14) < iVar8) ||
                 ((*(int *)(iStack_c + 0x14) <= iVar8 &&
                  (*(uint *)(iStack_c + 0x10) <= *(uint *)(*piVar3 + 0x10))))) break;
              param_1[iVar2 * 2] = param_1[iVar10 * 2];
              param_1[iVar2 * 2 + 1] = param_1[iVar10 * 2 + 1];
              iVar2 = iVar10;
            }
            puVar14[iVar2 * 2] = uStack_1c;
            puVar14[iVar2 * 2 + 1] = iStack_c;
            puVar7 = puStack_20;
            iStack_18 = iVar13;
          } while (0 < iVar13);
        }
        uStack_10 = uVar12;
        if ((int)uVar12 < 2) {
          return;
        }
        do {
          puVar7 = param_2 + -2;
          bVar5 = 1 < (int)uVar12;
          uVar12 = iVar6 + -8 >> 3;
          if (bVar5) {
            puStack_28 = (undefined4 *)*puVar7;
            puStack_24 = (undefined4 *)param_2[-1];
            *puVar7 = *puVar14;
            *(undefined4 *)((int)puVar14 + iVar6 + -4) = puVar14[1];
            FUN_006a7430(puVar14,0,uVar12,&puStack_28,param_4);
          }
          param_2 = puVar7;
          iVar6 = iVar6 + -8;
        } while (1 < (int)uVar12);
        return;
      }
      goto LAB_006a759e;
    }
    FUN_006a7120(&puStack_28,puVar14,param_2,param_4);
    puVar7 = puStack_24;
    param_3 = (param_3 >> 1) + (param_3 >> 2);
    if ((int)((int)puStack_28 - (int)puVar14 & 0xfffffff8U) <
        (int)((int)param_2 - (int)puStack_24 & 0xfffffff8U)) {
      FUN_006a7510(puVar14,puStack_28,param_3,param_4);
      param_1 = puVar7;
      puVar14 = puVar7;
    }
    else {
      FUN_006a7510(puStack_24,param_2,param_3,param_4);
      param_2 = puStack_28;
    }
    iVar6 = (int)param_2 - (int)puVar14;
  } while( true );
}



/* FUNCTION 8615 ; VA 0x006a77e0 ; FUN_006a77e0 */

void __thiscall FUN_006a77e0(int *param_1,uint param_2,uint param_3,undefined4 *param_4)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint uVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  
  puVar6 = (undefined4 *)param_1[1];
  iVar1 = (int)puVar6 - *param_1 >> 7;
  uVar7 = iVar1 - param_1[4];
  if (param_3 < uVar7) {
    uVar7 = param_3;
  }
  puVar5 = *(undefined4 **)(param_2 + 4);
  puVar2 = (undefined4 *)param_1[3];
  if (puVar5 == (undefined4 *)0x0) {
    param_2 = 0;
    if (uVar7 != 0) {
      do {
        if (puVar2 != (undefined4 *)0x0) {
          puVar6 = (undefined4 *)*param_4;
          puVar5 = puVar2;
          for (iVar1 = 0x20; iVar1 != 0; iVar1 = iVar1 + -1) {
            *puVar5 = *puVar6;
            puVar6 = puVar6 + 1;
            puVar5 = puVar5 + 1;
          }
        }
        puVar6 = (undefined4 *)param_1[1];
        param_2 = param_2 + 1;
        puVar2 = puVar2 + 0x20;
        if (puVar2 == puVar6) {
          puVar2 = (undefined4 *)*param_1;
        }
      } while (param_2 < uVar7);
    }
    while (param_2 < param_3) {
      puVar5 = puVar2 + 0x20;
      puVar6 = (undefined4 *)*param_4;
      for (iVar1 = 0x20; iVar1 != 0; iVar1 = iVar1 + -1) {
        *puVar2 = *puVar6;
        puVar6 = puVar6 + 1;
        puVar2 = puVar2 + 1;
      }
      puVar6 = (undefined4 *)param_1[1];
      param_2 = param_2 + 1;
      puVar2 = puVar5;
      if (puVar5 == puVar6) {
        puVar2 = (undefined4 *)*param_1;
      }
    }
  }
  else {
    iVar8 = param_3 - 1;
    if ((int)puVar6 - (int)puVar2 >> 7 <= iVar8) {
      iVar8 = iVar8 - iVar1;
    }
    puVar9 = puVar2 + iVar8 * 0x20;
    if (puVar2 != puVar5) {
      puVar3 = (undefined4 *)*param_1;
      do {
        if (puVar2 != puVar3) {
          puVar6 = puVar2;
        }
        puVar2 = puVar6 + -0x20;
        if ((puVar9 < (undefined4 *)param_1[3]) ||
           ((((undefined4 *)param_1[3] <= (undefined4 *)param_1[2] &&
             ((undefined4 *)param_1[2] <= puVar9)) || (puVar9 != (undefined4 *)0x0)))) {
          puVar6 = puVar2;
          puVar3 = puVar9;
          for (iVar1 = 0x20; iVar1 != 0; iVar1 = iVar1 + -1) {
            *puVar3 = *puVar6;
            puVar6 = puVar6 + 1;
            puVar3 = puVar3 + 1;
          }
        }
        puVar3 = (undefined4 *)*param_1;
        puVar6 = (undefined4 *)param_1[1];
        puVar10 = puVar6;
        if (puVar9 != puVar3) {
          puVar10 = puVar9;
        }
        puVar9 = puVar10 + -0x20;
      } while (puVar2 != *(undefined4 **)(param_2 + 4));
    }
    if (param_3 != 0) {
      param_2 = param_3;
      do {
        if (((puVar5 < (undefined4 *)param_1[3]) ||
            (((undefined4 *)param_1[3] <= (undefined4 *)param_1[2] &&
             ((undefined4 *)param_1[2] <= puVar5)))) || (puVar5 != (undefined4 *)0x0)) {
          puVar6 = (undefined4 *)*param_4;
          puVar2 = puVar5;
          for (iVar1 = 0x20; iVar1 != 0; iVar1 = iVar1 + -1) {
            *puVar2 = *puVar6;
            puVar6 = puVar6 + 1;
            puVar2 = puVar2 + 1;
          }
        }
        puVar6 = (undefined4 *)param_1[1];
        puVar5 = puVar5 + 0x20;
        if (puVar5 == puVar6) {
          puVar5 = (undefined4 *)*param_1;
        }
        param_2 = param_2 - 1;
      } while (param_2 != 0);
    }
  }
  uVar4 = param_3;
  if ((int)puVar6 - param_1[3] >> 7 <= (int)param_3) {
    uVar4 = param_3 - ((int)puVar6 - *param_1 >> 7);
  }
  param_1[3] = param_1[3] + uVar4 * 0x80;
  iVar1 = param_3 - uVar7;
  if ((int)puVar6 - param_1[2] >> 7 <= iVar1) {
    iVar1 = iVar1 - ((int)puVar6 - *param_1 >> 7);
  }
  param_1[4] = param_1[4] + uVar7;
  param_1[2] = iVar1 * 0x80 + param_1[2];
  return;
}



/* FUNCTION 8616 ; VA 0x006a7990 ; FUN_006a7990 */

undefined4 * __fastcall FUN_006a7990(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017a65ef;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RakNet::CCRakNetSlidingWindow2::vftable;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  puVar1 = param_1 + 0x25;
  uStack_8 = 1;
  uStack_7 = 0;
  *puVar1 = 0;
  param_1[0x26] = 0;
  uVar2 = FUN_006a8fb0(0,0);
  *puVar1 = uVar2;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2d] = 0;
  _uStack_8 = CONCAT31(uStack_7,3);
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  uVar2 = FUN_00601dc0();
  param_1[0x2e] = uVar2;
  param_1[0x2d] = *puVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8617 ; VA 0x006a7a80 ; thunk_FUN_006a95d0 */

void __fastcall thunk_FUN_006a95d0(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = 0;
  if (param_1[4] != 0) {
    do {
      param_1[2] = param_1[2] + 0x80;
      uVar3 = uVar3 + 1;
      if (param_1[2] == param_1[1]) {
        param_1[2] = *param_1;
      }
    } while (uVar3 < (uint)param_1[4]);
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[1] - iVar1 & 0xffffff80;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  return;
}



/* FUNCTION 8618 ; VA 0x006a7a90 ; FUN_006a7a90 */

void __fastcall FUN_006a7a90(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)*param_1;
  piVar3 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar2 = (int *)*param_1;
  if (piVar3 != piVar2) {
    do {
      piVar1 = (int *)*piVar3;
      FUN_01674ea0(piVar3,0x40);
      piVar2 = (int *)*param_1;
      piVar3 = piVar1;
    } while (piVar1 != piVar2);
  }
  FUN_01674ea0(piVar2,0x40);
  return;
}



/* FUNCTION 8619 ; VA 0x006a7ae0 ; FUN_006a7ae0 */

int __thiscall FUN_006a7ae0(int *param_1,int param_2)

{
  if (param_1[1] - param_1[2] >> 7 <= param_2) {
    param_2 = param_2 - (param_1[1] - *param_1 >> 7);
  }
  return param_1[2] + param_2 * 0x80;
}



/* FUNCTION 8620 ; VA 0x006a7b10 ; FUN_006a7b10 */

int * __thiscall FUN_006a7b10(int *param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  
  if (param_2 < 1) {
    if (param_2 < 0) {
      FUN_006a7b70(-param_2);
    }
  }
  else {
    piVar2 = (int *)*param_1;
    if (piVar2[1] - param_1[1] >> 7 <= param_2) {
      param_2 = param_2 - (piVar2[1] - *piVar2 >> 7);
    }
    iVar1 = param_2 * 0x80 + param_1[1];
    param_1[1] = iVar1;
    if (iVar1 == piVar2[3]) {
      param_1[1] = 0;
      return param_1;
    }
  }
  return param_1;
}



/* FUNCTION 8621 ; VA 0x006a7b70 ; FUN_006a7b70 */

int * __thiscall FUN_006a7b70(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  
  if (0 < param_2) {
    iVar2 = param_1[1];
    piVar1 = (int *)*param_1;
    if (iVar2 == 0) {
      iVar2 = piVar1[3];
    }
    if (iVar2 - *piVar1 >> 7 < param_2) {
      param_2 = param_2 - (piVar1[1] - *piVar1 >> 7);
    }
    param_1[1] = iVar2 + param_2 * -0x80;
    return param_1;
  }
  if (param_2 < 0) {
    FUN_006a7b10(-param_2);
  }
  return param_1;
}



/* FUNCTION 8622 ; VA 0x006a7bc0 ; FUN_006a7bc0 */

undefined4 * __thiscall FUN_006a7bc0(undefined4 *param_1,byte param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  undefined4 *puStack_8;
  
  *param_1 = RakNet::CCRakNetSlidingWindow2::vftable;
  puStack_8 = param_1;
  FUN_006a9630(&puStack_8,*(undefined4 *)param_1[0x2e],(undefined4 *)param_1[0x2e]);
  FUN_01674ea0(param_1[0x2e],0x18);
  FUN_006a95d0();
  FUN_006a7a90();
  iVar1 = param_1[0x1d];
  if (iVar1 != 0) {
    uVar3 = param_1[0x1f] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[0x1d] = 0;
    param_1[0x1e] = 0;
    param_1[0x1f] = 0;
  }
  *param_1 = RakNet::CCRakNetBase::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x148);
  }
  return param_1;
}



/* FUNCTION 8623 ; VA 0x006a7c80 ; FUN_006a7c80 */

int __thiscall FUN_006a7c80(int param_1,uint *param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  uint3 uVar3;
  
  *param_2 = *(uint *)(param_1 + 0x20);
  param_2[1] = *(uint *)(param_1 + 0x24);
  iVar1 = *(int *)(param_1 + 0x28);
  iVar2 = *(int *)(param_1 + 0x2c);
  *param_3 = iVar1;
  param_3[1] = iVar2;
  uVar3 = (uint3)((*param_2 | param_2[1]) >> 8);
  if (((*param_2 | param_2[1]) != 0) && (iVar1 != 0 || iVar2 != 0)) {
    return CONCAT31(uVar3,1);
  }
  return (uint)uVar3 << 8;
}



/* FUNCTION 8624 ; VA 0x006a7cc0 ; FUN_006a7cc0 */

void __thiscall FUN_006a7cc0(int param_1,int *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x30);
  *param_2 = iVar1;
  *(int *)(param_1 + 0x30) = iVar1 + 1;
  *(undefined *)(param_1 + 0x33) = 0;
  return;
}



/* FUNCTION 8625 ; VA 0x006a7ce0 ; FUN_006a7ce0 */

void __thiscall FUN_006a7ce0(int param_1,int *param_2)

{
  int iVar1;
  undefined8 uVar2;
  
  *param_2 = ((*(int *)(param_1 + 0x118) / DAT_01d5b160) / 1000) * 8;
  iVar1 = FUN_006a8fe0();
  param_2[1] = (iVar1 / 1000) * 8;
  uVar2 = FUN_006a9750();
  iVar1 = FUN_016f3900(uVar2,1000,0);
  param_2[2] = iVar1;
  param_2[3] = *(int *)(param_1 + 0xcc) / 1000;
  param_2[4] = *(int *)(param_1 + 0xe4) / 1000;
  param_2[5] = (*(int *)(param_1 + 0xcc) - *(int *)(param_1 + 0xec)) - *(int *)(param_1 + 0xe4);
  if (*(int *)(param_1 + 0x128) != 0 || *(int *)(param_1 + 300) != 0) {
    *(undefined *)(param_2 + 6) = 1;
    return;
  }
  *(undefined *)(param_2 + 6) = 0;
  return;
}



/* FUNCTION 8626 ; VA 0x006a7db0 ; FUN_006a7db0 */

void __thiscall FUN_006a7db0(int param_1,undefined4 *param_2)

{
  *param_2 = *(undefined4 *)(param_1 + 0x30);
  return;
}



/* FUNCTION 8627 ; VA 0x006a7dc0 ; FUN_006a7dc0 */

void __thiscall
FUN_006a7dc0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  (**(code **)(*param_1 + 0x14))(param_2,param_3,param_4,param_5,param_6,param_7);
  return;
}



/* FUNCTION 8628 ; VA 0x006a7de0 ; FUN_006a7de0 */

/* WARNING: Removing unreachable block (ram,0x006a807a) */
/* WARNING: Removing unreachable block (ram,0x006a8062) */
/* WARNING: Removing unreachable block (ram,0x006a80f9) */

uint __thiscall FUN_006a7de0(int param_1,uint param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  longlong lVar11;
  undefined8 uVar12;
  longlong lVar13;
  longlong lVar14;
  undefined in_stack_00000018;
  longlong lVar15;
  int iVar16;
  
  *(undefined *)(param_1 + 0x40) = in_stack_00000018;
  uVar1 = DAT_01d5b160;
  if ((int)DAT_01d5b160 < 10) {
    uVar1 = 10;
  }
  uVar10 = ((int)uVar1 >> 0x1f) * 2000 + (int)((ulonglong)uVar1 * 2000 >> 0x20);
  uVar6 = (param_3 - *(int *)(param_1 + 0x124)) - (uint)(param_2 < *(uint *)(param_1 + 0x120));
  if ((uVar6 < uVar10) ||
     ((uVar6 <= uVar10 && (param_2 - *(uint *)(param_1 + 0x120) <= (uint)((ulonglong)uVar1 * 2000)))
     )) {
    if (0 < *(int *)(param_1 + 0x118)) {
      if ((*(int *)(param_1 + 0x11c) == 0) ||
         (*(int *)(param_1 + 4) + *(int *)(param_1 + 0x11c) < *(int *)(param_1 + 0x118)))
      goto LAB_006a7e8f;
      iVar7 = *(int *)(param_1 + 0x130) + 1;
      *(int *)(param_1 + 0x130) = iVar7;
      if ((*(int *)(param_1 + 0x128) != 0 || *(int *)(param_1 + 300) != 0) && (2 < iVar7)) {
        *(undefined4 *)(param_1 + 0x128) = 0;
        *(undefined4 *)(param_1 + 300) = 0;
      }
    }
  }
  else {
LAB_006a7e8f:
    *(undefined4 *)(param_1 + 0x130) = 0;
    if (*(int *)(param_1 + 0x128) == 0 && *(int *)(param_1 + 300) == 0) {
      *(uint *)(param_1 + 0x128) = param_2;
      *(int *)(param_1 + 300) = param_3;
      iVar7 = *(int *)(param_1 + 0xa8);
      if (iVar7 == *(int *)(param_1 + 0x9c)) {
        iVar7 = *(int *)(param_1 + 0xa0);
      }
      *(undefined *)(iVar7 + -4) = 1;
    }
  }
  *(uint *)(param_1 + 0x120) = param_2;
  *(int *)(param_1 + 0x124) = param_3;
  *(undefined4 *)(param_1 + 0x11c) = 0;
  *(undefined4 *)(param_1 + 0x118) = 0;
  lVar11 = FUN_006a9750();
  iVar7 = *(int *)(param_1 + 0xcc);
  iVar4 = *(int *)(param_1 + 0xec);
  iVar8 = *(int *)(param_1 + 0xe4);
  if (*(int *)(param_1 + 0x44) == 0) {
    FUN_006aac50(param_2,param_3);
  }
  else {
    if (*(int *)(param_1 + 0x44) == 1) {
      iVar2 = FUN_006a93b0(0xffffffff);
      if (iVar2 != -1) goto LAB_006a7f65;
      iVar2 = FUN_006a8fe0();
      if (iVar2 == -1) {
        iVar2 = FUN_006a8fe0();
      }
      *(undefined4 *)(param_1 + 0x48) = 0;
      *(undefined4 *)(param_1 + 0x44) = 3;
    }
    else {
      iVar2 = *(int *)(param_1 + 0x134);
    }
    FUN_006a9b20(iVar2);
  }
LAB_006a7f65:
  uVar1 = *(uint *)(param_1 + 0x138);
  if (uVar1 == 0 && *(int *)(param_1 + 0x13c) == 0) {
    iVar2 = *(int *)(param_1 + 4) + -0xc;
    _in_stack_00000018 = iVar2 >> 0x1f;
  }
  else {
    uVar12 = FUN_016f39b0(param_2 - uVar1,
                          (param_3 - *(int *)(param_1 + 0x13c)) - (uint)(param_2 < uVar1),
                          *(int *)(param_1 + 0x134),*(int *)(param_1 + 0x134) >> 0x1f);
    uVar12 = FUN_016f3900(uVar12,1000000,0);
    iVar2 = (uint)uVar12 - *(uint *)(param_1 + 0x140);
    _in_stack_00000018 =
         ((int)((ulonglong)uVar12 >> 0x20) - *(int *)(param_1 + 0x144)) -
         (uint)((uint)uVar12 < *(uint *)(param_1 + 0x140));
  }
  iVar3 = (*(int *)(param_1 + 200) - *(int *)(param_1 + 0xe8)) - *(int *)(param_1 + 0xe0);
  iVar9 = DAT_01d59cbc - iVar3;
  iVar3 = iVar3 * 100;
  if (iVar3 < DAT_01d59cbc * 0x50) {
    iVar3 = 0;
    uVar1 = DAT_01d5b160;
    if ((int)DAT_01d5b160 < 2) {
      uVar1 = 2;
    }
    lVar15 = (longlong)(int)uVar1 * (longlong)*(int *)(param_1 + 0x134);
    iVar16 = 2000;
  }
  else {
    uVar1 = DAT_01d5b160;
    if ((int)DAT_01d5b160 < 1) {
      uVar1 = 1;
    }
    iVar16 = 2000;
    if (DAT_01d59cbc * 0x5f <= iVar3) {
      iVar16 = 1000;
    }
    lVar15 = (longlong)iVar16 * (longlong)(int)uVar1;
    iVar16 = *(int *)(param_1 + 0x134);
    iVar3 = iVar16 >> 0x1f;
  }
  uVar12 = FUN_016f39b0(lVar15,iVar16,iVar3);
  lVar13 = FUN_016f3900(uVar12,1000000,0);
  lVar15 = CONCAT44(_in_stack_00000018,iVar2);
  if (lVar13 < CONCAT44(_in_stack_00000018,iVar2)) {
    lVar15 = lVar13;
  }
  lVar13 = lVar15;
  if (0 < lVar15) {
    lVar13 = lVar11 + (int)DAT_01d5b324 / 2;
    iVar2 = *(int *)(param_1 + 0x44);
    if ((iVar2 == 4) || (iVar2 == 5)) {
      lVar14 = FUN_016f3900(lVar13,2,0);
      lVar13 = lVar14 + lVar13;
    }
    else if (iVar2 == 0) {
      lVar13 = CONCAT44((int)((ulonglong)lVar13 >> 0x20) * 2 | (uint)lVar13 >> 0x1f,(uint)lVar13 * 2
                       );
    }
    uVar12 = FUN_016f39b0(*(int *)(param_1 + 0x134),*(int *)(param_1 + 0x134) >> 0x1f,lVar13);
    iVar3 = FUN_016f3900(uVar12,1000000,0);
    iVar2 = *(int *)(param_1 + 4) * 2 + -0x18;
    if (iVar3 <= iVar2) {
      iVar3 = iVar2;
    }
    iVar3 = iVar3 - ((iVar7 - iVar4) - iVar8);
    lVar13 = (longlong)iVar3;
    if (lVar15 <= iVar3) goto LAB_006a8112;
  }
  lVar15 = lVar13;
LAB_006a8112:
  iVar4 = *(int *)(param_1 + 4) + -0xc;
  iVar7 = (int)(lVar15 + iVar4);
  uVar1 = iVar7 - 1;
  iVar8 = (int)((ulonglong)(lVar15 + iVar4) >> 0x20) - (uint)(iVar7 == 0);
  uVar12 = FUN_016f4270(uVar1,iVar8,iVar4,iVar4 >> 0x1f);
  iVar2 = (int)((ulonglong)uVar12 >> 0x20);
  uVar6 = uVar1 - (uint)uVar12;
  uVar1 = (uint)(uVar1 < (uint)uVar12);
  iVar7 = iVar8 - iVar2;
  _in_stack_00000018 = iVar7 - uVar1;
  if ((_in_stack_00000018 >= 0) &&
     ((_in_stack_00000018 != 0 &&
       (SBORROW4(iVar8,iVar2) != SBORROW4(iVar7,uVar1)) == _in_stack_00000018 < 0 || (uVar6 != 0))))
  {
    uVar1 = iVar4 * iVar9;
    iVar7 = (int)uVar1 >> 0x1f;
    if ((iVar7 <= _in_stack_00000018) && ((iVar7 < _in_stack_00000018 || (uVar1 < uVar6)))) {
      uVar6 = uVar1;
      _in_stack_00000018 = iVar7;
    }
  }
  uVar10 = FUN_016f3900((longlong)iVar4 * 2000000,*(int *)(param_1 + 0x134),
                        *(int *)(param_1 + 0x134) >> 0x1f);
  uVar1 = DAT_01d5b324;
  if ((int)DAT_01d5b324 < (int)uVar10) {
    uVar1 = uVar10;
  }
  uVar5 = 0x50;
  if (*(int *)(param_1 + 0x44) == 1) {
    uVar5 = 0x78;
  }
  uVar12 = FUN_016f39b0(uVar5,0,lVar11);
  uVar10 = FUN_016f3900(uVar12,100,0);
  if ((int)uVar10 <= (int)uVar1) {
    uVar10 = uVar1;
  }
  if (1000000 < (int)uVar10) {
    uVar10 = 1000000;
  }
  if ((_in_stack_00000018 < 1) && ((_in_stack_00000018 < 0 || (uVar6 == 0)))) {
    uVar1 = *(uint *)(param_1 + 0x110);
    if (uVar1 != 0 || *(int *)(param_1 + 0x114) != 0) {
      iVar7 = (param_3 - *(int *)(param_1 + 0x114)) - (uint)(param_2 < uVar1);
      if (((int)uVar10 >> 0x1f <= iVar7) &&
         (((int)uVar10 >> 0x1f < iVar7 || (uVar10 < param_2 - uVar1)))) {
        uVar6 = 1;
      }
    }
  }
  *(uint *)(param_1 + 0x118) = uVar6;
  return uVar6;
}



/* FUNCTION 8629 ; VA 0x006a8220 ; FUN_006a8220 */

void __thiscall FUN_006a8220(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int *piVar4;
  undefined8 uVar5;
  undefined auStack_84 [128];
  
  uVar5 = DAT_018ce330;
  *(int *)(param_1 + 4) = param_4;
  *(undefined8 *)(param_1 + 8) = uVar5;
  *(undefined4 *)(param_1 + 0x48) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(double *)(param_1 + 0x10) =
       (double)(param_4 << 5) + (double)(&DAT_018c0d90)[-((param_4 << 5) >> 0x1f)];
  *(undefined8 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined *)(param_1 + 0x33) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0;
  *(undefined2 *)(param_1 + 0x37) = 0;
  *(undefined *)(param_1 + 0x39) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0;
  *(undefined2 *)(param_1 + 0x3f) = 0;
  *(undefined4 *)(param_1 + 0x134) = DAT_01d5b30c;
  *(undefined4 *)(param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 0xc4) = 0;
  *(undefined4 *)(param_1 + 0xc0) = 0;
  *(undefined4 *)(param_1 + 0xcc) = 0;
  *(undefined4 *)(param_1 + 200) = 0;
  *(undefined4 *)(param_1 + 0xd4) = 0;
  *(undefined4 *)(param_1 + 0xd0) = 0;
  *(undefined4 *)(param_1 + 0xdc) = 0;
  *(undefined4 *)(param_1 + 0xd8) = 0;
  *(undefined4 *)(param_1 + 0xe4) = 0;
  *(undefined4 *)(param_1 + 0xe0) = 0;
  *(undefined4 *)(param_1 + 0xec) = 0;
  *(undefined4 *)(param_1 + 0xe8) = 0;
  *(undefined4 *)(param_1 + 0xf0) = 0;
  *(undefined4 *)(param_1 + 0xf4) = 0;
  *(undefined4 *)(param_1 + 0xf8) = 0;
  *(undefined4 *)(param_1 + 0xfc) = 0;
  *(undefined4 *)(param_1 + 0x10c) = 0;
  *(undefined4 *)(param_1 + 0x108) = 0;
  *(undefined4 *)(param_1 + 0x100) = 0;
  *(undefined4 *)(param_1 + 0x104) = 0;
  FUN_006a9cf0(DAT_01d5b304 + 1);
  uVar3 = 0;
  if (*(int *)(param_1 + 0xac) != 0) {
    do {
      *(int *)(param_1 + 0xa4) = *(int *)(param_1 + 0xa4) + 0x80;
      uVar3 = uVar3 + 1;
      if (*(int *)(param_1 + 0xa4) == *(int *)(param_1 + 0xa0)) {
        *(undefined4 *)(param_1 + 0xa4) = *(undefined4 *)(param_1 + 0x9c);
      }
    } while (uVar3 < *(uint *)(param_1 + 0xac));
  }
  *(undefined4 *)(param_1 + 0xac) = 0;
  FUN_00601ea0();
  piVar2 = *(int **)(param_1 + 0x94);
  piVar4 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*(int *)(param_1 + 0x94) + 4) = *(int *)(param_1 + 0x94);
  *(undefined4 *)(param_1 + 0x98) = 0;
  piVar2 = *(int **)(param_1 + 0x94);
  if (piVar4 != piVar2) {
    do {
      piVar1 = (int *)*piVar4;
      FUN_01674ea0(piVar4,0x40);
      piVar2 = *(int **)(param_1 + 0x94);
      piVar4 = piVar1;
    } while (piVar1 != piVar2);
  }
  *(int **)(param_1 + 0xb4) = piVar2;
  FUN_0170d1f0(auStack_84,0,0x80);
  FUN_006a9a40(1,auStack_84);
  *(undefined4 *)(param_1 + 0x80) = 0;
  *(undefined4 *)(param_1 + 0x84) = 0;
  *(undefined4 *)(param_1 + 0x88) = 0;
  *(undefined4 *)(param_1 + 0x8c) = 0;
  *(undefined4 *)(param_1 + 0x90) = 0xffffffff;
  *(undefined4 *)(param_1 + 0x140) = 0;
  *(undefined4 *)(param_1 + 0x144) = 0;
  *(undefined4 *)(param_1 + 0x138) = 0;
  *(undefined4 *)(param_1 + 0x13c) = 0;
  *(undefined4 *)(param_1 + 0x50) = 0;
  *(undefined4 *)(param_1 + 0x54) = 0;
  *(undefined4 *)(param_1 + 0x60) = 0;
  *(undefined4 *)(param_1 + 100) = 0;
  *(undefined4 *)(param_1 + 0x118) = 0;
  *(undefined4 *)(param_1 + 0x11c) = 0;
  *(undefined4 *)(param_1 + 0x120) = 0;
  *(undefined4 *)(param_1 + 0x124) = 0;
  uVar5 = FUN_006a6920();
  *(undefined8 *)(param_1 + 0x128) = uVar5;
  *(undefined4 *)(param_1 + 0x130) = 0;
  *(undefined4 *)(param_1 + 0x68) = 0;
  *(undefined4 *)(param_1 + 0x110) = 0;
  *(undefined4 *)(param_1 + 0x114) = 0;
  *(undefined4 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x6c) = 0;
  return;
}



/* FUNCTION 8630 ; VA 0x006a8520 ; FUN_006a8520 */

void __thiscall FUN_006a8520(int param_1,int param_2,int param_3)

{
  double dVar1;
  double dVar2;
  int *piVar3;
  bool bVar4;
  int iVar5;
  undefined8 in_XMM0_Qa;
  char in_stack_00000030;
  int in_stack_00000034;
  
  iVar5 = in_stack_00000034;
  *(int *)(param_1 + 0x80) = param_2;
  *(int *)(param_1 + 0x84) = param_3;
  *(int *)(param_1 + 0x110) = param_2;
  *(int *)(param_1 + 0x114) = param_3;
  piVar3 = *(int **)(param_1 + 0x78);
  param_3 = *(int *)(param_1 + 0x94);
  param_2 = in_stack_00000034;
  if (*(int **)(param_1 + 0x7c) == piVar3) {
    FUN_00559ce0(piVar3,&param_2);
  }
  else {
    *piVar3 = in_stack_00000034;
    piVar3[1] = param_3;
    *(int *)(param_1 + 0x78) = *(int *)(param_1 + 0x78) + 8;
  }
  FUN_016f3fe0();
  *(undefined8 *)(param_1 + 8) = in_XMM0_Qa;
  *(char *)(param_1 + 0x40) = in_stack_00000030;
  if (in_stack_00000030 != '\0') {
    if ((*(int *)(param_1 + 0x34) == iVar5) ||
       ((*(int *)(param_1 + 0x34) - iVar5 & 0xffffffU) < 0x800000)) {
      bVar4 = false;
    }
    else {
      bVar4 = true;
      *(undefined4 *)(param_1 + 0x34) = *(undefined4 *)(param_1 + 0x30);
      *(undefined2 *)(param_1 + 0x38) = 0;
    }
    dVar1 = *(double *)(param_1 + 0x10);
    dVar2 = *(double *)(param_1 + 0x18);
    if ((dVar1 <= dVar2) || (NAN(dVar2) != (dVar2 == 0.0))) {
      if ((dVar1 < DAT_018dab60) &&
         ((*(double *)(param_1 + 0x10) = dVar1 + dVar1, dVar2 < dVar1 + dVar1 &&
          (NAN(dVar2) == (dVar2 == 0.0))))) {
        *(double *)(param_1 + 0x10) =
             (double)(*(int *)(param_1 + 4) * *(int *)(param_1 + 4)) / dVar2 + dVar2;
      }
    }
    else if (bVar4) {
      *(double *)(param_1 + 0x10) =
           (double)(*(int *)(param_1 + 4) * *(int *)(param_1 + 4)) / dVar1 + dVar1;
      return;
    }
  }
  return;
}



/* FUNCTION 8631 ; VA 0x006a8650 ; FUN_006a8650 */

/* WARNING: Removing unreachable block (ram,0x006a8a23) */

void __thiscall FUN_006a8650(int param_1,uint param_2,uint param_3)

{
  int *piVar1;
  int *piVar2;
  uint *puVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 uVar11;
  undefined4 *puVar12;
  uint uVar13;
  undefined4 *puVar14;
  int iVar15;
  uint uVar16;
  bool bVar17;
  undefined8 uVar18;
  longlong lVar19;
  uint uStack_38;
  uint uStack_34;
  int iStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  uint uStack_10;
  int iStack_c;
  
  if (*(int *)(param_1 + 0x74) == *(int *)(param_1 + 0x78)) {
    return;
  }
  uStack_18 = *(uint *)(param_1 + 0x88);
  iStack_14 = *(int *)(param_1 + 0x84);
  iStack_c = *(int *)(param_1 + 0x8c);
  uStack_10 = *(uint *)(param_1 + 0x80);
  *(uint *)(param_1 + 0x88) = uStack_10;
  uVar5 = *(undefined4 *)(param_1 + 0x90);
  *(int *)(param_1 + 0x8c) = iStack_14;
  iVar15 = 0;
  bVar17 = false;
  *(undefined4 *)(param_1 + 0x90) = *(undefined4 *)(*(int *)(param_1 + 0x78) + -8);
  *(undefined4 *)(param_1 + 0x80) = 0;
  *(undefined4 *)(param_1 + 0x84) = 0;
  puVar12 = *(undefined4 **)(param_1 + 0x74);
  if (0 < (int)(*(int *)(param_1 + 0x78) - (int)puVar12 & 0xfffffff8U)) {
    do {
      puVar3 = puVar12 + iVar15 * 2;
      puVar14 = *(undefined4 **)(param_1 + 0xb8);
      puVar10 = puVar14;
      if (*(char *)((int)puVar14[1] + 0xd) == '\0') {
        puVar9 = puVar14;
        puVar12 = (undefined4 *)puVar14[1];
        do {
          puVar10 = puVar12;
          if ((uint)puVar10[4] < *puVar3) {
            puVar12 = (undefined4 *)puVar10[2];
            puVar10 = puVar9;
          }
          else {
            puVar12 = (undefined4 *)*puVar10;
          }
          puVar9 = puVar10;
        } while (*(char *)((int)puVar12 + 0xd) == '\0');
        puVar12 = *(undefined4 **)(param_1 + 0x74);
      }
      if ((puVar10 == puVar14) || (*puVar3 < (uint)puVar10[4])) {
        puVar10 = puVar14;
      }
      if (puVar10 == puVar14) {
        uVar11 = *(undefined4 *)(param_1 + 0x94);
        bVar17 = true;
      }
      else {
        uVar11 = puVar10[5];
      }
      puVar12[iVar15 * 2 + 1] = uVar11;
      iVar15 = iVar15 + 1;
      puVar12 = *(undefined4 **)(param_1 + 0x74);
    } while (iVar15 < *(int *)(param_1 + 0x78) - (int)puVar12 >> 3);
    if ((bVar17) && (puVar14 = *(undefined4 **)(param_1 + 0x78), puVar12 != puVar14)) {
      do {
        if (puVar12[1] == *(int *)(param_1 + 0x94)) break;
        puVar12 = puVar12 + 2;
      } while (puVar12 != puVar14);
      puVar10 = puVar12;
      if (puVar12 != puVar14) {
        while (puVar9 = puVar10, puVar10 = puVar9 + 2, puVar10 != puVar14) {
          if (puVar9[3] != *(int *)(param_1 + 0x94)) {
            *puVar12 = *puVar10;
            puVar12[1] = puVar9[3];
            puVar12 = puVar12 + 2;
          }
        }
        if (puVar12 != puVar14) {
          puVar10 = *(undefined4 **)(param_1 + 0x78);
          for (; puVar14 != puVar10; puVar14 = puVar14 + 2) {
            *puVar12 = *puVar14;
            puVar12[1] = puVar14[1];
            puVar12 = puVar12 + 2;
          }
          *(undefined4 **)(param_1 + 0x78) = puVar12;
        }
      }
    }
  }
  iVar15 = *(int *)(param_1 + 0x78);
  iVar7 = *(int *)(param_1 + 0x74);
  if (*(int *)(param_1 + 0x74) == iVar15) {
    return;
  }
  do {
    iVar8 = iVar7 + 8;
    if (iVar8 == iVar15) goto LAB_006a8820;
    piVar1 = (int *)(iVar7 + 0xc);
    piVar2 = (int *)(iVar7 + 4);
    iVar6 = *(int *)(*piVar1 + 0x14);
    iVar4 = *(int *)(*piVar2 + 0x14);
  } while ((iVar4 <= iVar6) &&
          ((iVar7 = iVar8, iVar4 < iVar6 || (*(uint *)(*piVar2 + 0x10) <= *(uint *)(*piVar1 + 0x10))
           )));
  if (iVar8 != iVar15) {
    FUN_006a7510(*(int *)(param_1 + 0x74),*(int *)(param_1 + 0x78),
                 *(int *)(param_1 + 0x78) - *(int *)(param_1 + 0x74) >> 3,param_2);
  }
LAB_006a8820:
  if ((param_2 == 0) || (param_3 == 0)) {
    if (uStack_18 == 0 && iStack_c == 0) {
LAB_006a88bb:
      uStack_18 = uStack_10 - 10000;
      iVar15 = *(int *)(*(int *)(param_1 + 0x74) + 4);
      uStack_20 = *(uint *)(iVar15 + 0x10);
      iStack_1c = *(int *)(iVar15 + 0x14);
      iStack_c = iStack_14 - (uint)(uStack_10 < 10000);
    }
    else {
      bVar17 = -1 < (int)((iStack_14 - iStack_c) - (uint)(uStack_10 < uStack_18));
      if ((iStack_14 - iStack_c != (uint)(uStack_10 < uStack_18) && bVar17) ||
         (((bVar17 && (29999 < uStack_10 - uStack_18)) ||
          (iVar15 = FUN_006a96a0(uVar5), iVar15 == 0)))) goto LAB_006a88bb;
      uStack_20 = *(uint *)(iVar15 + 8);
      iStack_1c = *(int *)(iVar15 + 0xc);
      if (uStack_20 == 0 && iStack_1c == 0) goto LAB_006a88bb;
    }
    if ((iStack_c <= iStack_1c) && ((iStack_c < iStack_1c || (uStack_18 < uStack_20)))) {
      uStack_18 = uStack_20 + 1;
      iStack_c = iStack_1c + (uint)(0xfffffffe < uStack_20);
    }
    iVar15 = *(int *)(*(int *)(param_1 + 0x78) + -4);
    uStack_28 = *(uint *)(iVar15 + 0x10);
    iStack_2c = *(int *)(iVar15 + 0x14);
  }
  else {
    iVar15 = *(int *)(*(int *)(param_1 + 0x74) + 4);
    uStack_20 = *(uint *)(iVar15 + 0x10);
    iStack_1c = *(int *)(iVar15 + 0x14);
    iVar15 = *(int *)(*(int *)(param_1 + 0x78) + -4);
    uStack_28 = *(uint *)(iVar15 + 0x10);
    iStack_2c = *(int *)(iVar15 + 0x14);
    uStack_18 = uStack_10 - param_2;
    iStack_c = iStack_14 - (uint)(uStack_10 < param_2);
    bVar17 = uStack_10 < param_3;
    uStack_10 = uStack_10 - param_3;
    iStack_14 = iStack_14 - (uint)bVar17;
  }
  iVar15 = *(int *)(param_1 + 0x74);
  uStack_34 = 0;
  uStack_38 = 0;
  param_2 = 0;
  param_3 = 0;
  uVar16 = uStack_34;
  if (*(int *)(param_1 + 0x78) - iVar15 >> 3 != 0) {
    do {
      iVar7 = *(int *)(iVar15 + 4 + uStack_38 * 8);
      if (*(int *)(iVar7 + 0x18) == 0 && *(int *)(iVar7 + 0x1c) == 0) {
        *(int *)(param_1 + 0x108) = *(int *)(param_1 + 0x108) + 1;
        lVar19 = CONCAT44(iStack_c,uStack_18);
        if ((uStack_28 != uStack_20) || (iStack_2c != iStack_1c)) {
          uVar18 = FUN_016f39b0(*(uint *)(iVar7 + 0x10) - uStack_20,
                                (*(int *)(iVar7 + 0x14) - iStack_1c) -
                                (uint)(*(uint *)(iVar7 + 0x10) < uStack_20),uStack_10 - uStack_18,
                                (iStack_14 - iStack_c) - (uint)(uStack_10 < uStack_18));
          lVar19 = FUN_016f3900(uVar18,uStack_28 - uStack_20,
                                (iStack_2c - iStack_1c) - (uint)(uStack_28 < uStack_20));
          lVar19 = lVar19 + CONCAT44(iStack_c,uStack_18);
          uStack_34 = param_3;
        }
        uStack_24 = (uint)lVar19;
        if (*(int *)(iVar7 + 0x20) != 0 || *(int *)(iVar7 + 0x24) != 0) {
          *(undefined4 *)(iVar7 + 0x20) = 0;
          *(undefined4 *)(iVar7 + 0x24) = 0;
          *(int *)(param_1 + 0xe8) = *(int *)(param_1 + 0xe8) + -1;
          *(int *)(param_1 + 0xec) = *(int *)(param_1 + 0xec) - *(int *)(iVar7 + 0xc);
          iVar15 = FUN_006a96f0(param_1 + 0x9c,*(undefined4 *)(iVar7 + 8));
          if (iVar15 != 0) {
            *(int *)(iVar15 + 0x24) = *(int *)(iVar15 + 0x24) + -1;
            *(int *)(iVar15 + 0x28) = *(int *)(iVar15 + 0x28) - *(int *)(iVar7 + 0xc);
          }
        }
        uVar16 = *(uint *)(iVar7 + 0x10);
        if (*(longlong *)(iVar7 + 0x10) < lVar19) {
          uVar13 = uStack_24 - uVar16;
          iVar15 = ((int)((ulonglong)lVar19 >> 0x20) - *(int *)(iVar7 + 0x14)) -
                   (uint)(uStack_24 < uVar16);
          if ((iVar15 < (int)param_2) ||
             (((iVar15 <= (int)param_2 && (uVar13 < uStack_34)) || (uStack_34 == 0 && param_2 == 0))
             )) {
            uStack_34 = uVar13;
            param_2 = iVar15;
            param_3 = uVar13;
          }
        }
        *(longlong *)(iVar7 + 0x18) = lVar19;
        *(int *)(param_1 + 0xe0) = *(int *)(param_1 + 0xe0) + 1;
        *(int *)(param_1 + 0xe4) = *(int *)(param_1 + 0xe4) + *(int *)(iVar7 + 0xc);
        uVar13 = *(uint *)(iVar7 + 0xc);
        puVar3 = (uint *)(param_1 + 0xf8);
        uVar16 = *puVar3;
        *puVar3 = *puVar3 + uVar13;
        *(int *)(param_1 + 0xfc) =
             *(int *)(param_1 + 0xfc) + ((int)uVar13 >> 0x1f) + (uint)CARRY4(uVar16,uVar13);
        uVar5 = *(undefined4 *)(param_1 + 0xfc);
        *(undefined4 *)(iVar7 + 0x38) = *(undefined4 *)(param_1 + 0xf8);
        *(undefined4 *)(iVar7 + 0x3c) = uVar5;
      }
      else {
        *(undefined4 *)(iVar15 + uStack_38 * 8) = 0xffffffff;
      }
      uStack_38 = uStack_38 + 1;
      iVar15 = *(int *)(param_1 + 0x74);
    } while (uStack_38 < (uint)(*(int *)(param_1 + 0x78) - iVar15 >> 3));
    uVar16 = uStack_34;
    if ((-1 < (int)param_2) && ((iVar15 = param_2, 0 < (int)param_2 || (1 < uStack_34))))
    goto LAB_006a8aba;
  }
  uStack_34 = 1;
  iVar15 = 0;
LAB_006a8aba:
  *(uint *)(param_1 + 0x100) = uStack_34;
  *(int *)(param_1 + 0x104) = iVar15;
  if (((int)param_2 < 1) && (((int)param_2 < 0 || (uVar16 == 0)))) {
    param_3 = 5000;
    param_2 = 0;
  }
  iVar15 = *(int *)(param_1 + 0x74);
  uStack_38 = 0;
  if (*(int *)(param_1 + 0x78) - iVar15 >> 3 != 0) {
    do {
      if (*(int *)(iVar15 + uStack_38 * 8) != -1) {
        piVar1 = *(int **)(iVar15 + 4 + uStack_38 * 8);
        uVar16 = piVar1[4];
        iVar15 = (piVar1[7] - piVar1[5]) - (uint)((uint)piVar1[6] < uVar16);
        if ((iVar15 <= (int)param_2) && ((iVar15 < (int)param_2 || (piVar1[6] - uVar16 < param_3))))
        {
          piVar1[6] = param_3 + uVar16;
          piVar1[7] = param_2 + piVar1[5] + (uint)CARRY4(param_3,uVar16);
        }
        piVar2 = *(int **)(param_1 + 0xb4);
        if (piVar2 == *(int **)(param_1 + 0x94)) {
          piVar2 = (int *)**(int **)(param_1 + 0x94);
          *(int *)(param_1 + 0xd0) = *(int *)(param_1 + 0xd0) + 1;
          *(int **)(param_1 + 0xb4) = piVar2;
          *(int *)(param_1 + 0xd4) = *(int *)(param_1 + 0xd4) + piVar2[3];
          if (piVar2[2] != -1) {
            *(int *)(param_1 + 0xd8) = *(int *)(param_1 + 0xd8) + 1;
            *(int *)(param_1 + 0xdc) = *(int *)(param_1 + 0xdc) + piVar2[3];
          }
joined_r0x006a8b79:
          while (piVar2 != piVar1) {
            piVar2 = (int *)*piVar2;
            *(int **)(param_1 + 0xb4) = piVar2;
            *(int *)(param_1 + 0xd0) = *(int *)(param_1 + 0xd0) + 1;
            *(int *)(param_1 + 0xd4) = *(int *)(param_1 + 0xd4) + piVar2[3];
            if (piVar2[2] != -1) {
              *(int *)(param_1 + 0xd8) = *(int *)(param_1 + 0xd8) + 1;
              *(int *)(param_1 + 0xdc) = *(int *)(param_1 + 0xdc) + piVar2[3];
            }
          }
        }
        else if (piVar2[10] < piVar1[10]) goto joined_r0x006a8b79;
        uVar16 = piVar1[6];
        FUN_006aa6d0(param_1 + 0x9c,piVar1[2],piVar1[3],uVar16,piVar1[7],uVar16 - piVar1[4],
                     (piVar1[7] - piVar1[5]) - (uint)(uVar16 < (uint)piVar1[4]));
      }
      uStack_38 = uStack_38 + 1;
      iVar15 = *(int *)(param_1 + 0x74);
    } while (uStack_38 < (uint)(*(int *)(param_1 + 0x78) - iVar15 >> 3));
  }
  *(int *)(param_1 + 0x78) = iVar15;
  return;
}



/* FUNCTION 8632 ; VA 0x006a8c00 ; FUN_006a8c00 */

undefined4 __thiscall
FUN_006a8c00(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,uint *param_7)

{
  int iVar1;
  uint uVar2;
  
  if (*(int *)(param_1 + 0x20) == 0 && *(int *)(param_1 + 0x24) == 0) {
    *(undefined4 *)(param_1 + 0x20) = param_4;
    *(undefined4 *)(param_1 + 0x24) = param_5;
  }
  iVar1 = *(int *)(param_1 + 0x3c);
  *(undefined4 *)(param_1 + 0x28) = param_4;
  *(undefined4 *)(param_1 + 0x2c) = param_5;
  if (param_2 == iVar1) {
    *param_7 = 0;
    *(uint *)(param_1 + 0x3c) = param_2 + 1U & 0xffffff;
    return 1;
  }
  if ((iVar1 - param_2 & 0xffffffU) < 0x800000) {
    *param_7 = 0;
    return 1;
  }
  uVar2 = param_2 - iVar1 & 0xffffff;
  *param_7 = uVar2;
  if (1000 < uVar2) {
    if (50000 < uVar2) {
      return 0;
    }
    *param_7 = 1000;
  }
  *(uint *)(param_1 + 0x3c) = param_2 + 1U & 0xffffff;
  return 1;
}



/* FUNCTION 8633 ; VA 0x006a8ca0 ; FUN_006a8ca0 */

void __thiscall FUN_006a8ca0(int *param_1,int param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  param_1[0x43] = param_1[0x43] + 1;
  iVar1 = FUN_006a96a0(param_4);
  if ((iVar1 != 0) && (*(int *)(iVar1 + 0x18) == 0 && *(int *)(iVar1 + 0x1c) == 0)) {
    *(int *)(iVar1 + 0x18) = param_2;
    *(int *)(iVar1 + 0x1c) = param_3;
    param_1[0x44] = param_2;
    param_1[0x45] = param_3;
    iVar2 = FUN_006a96f0(param_1 + 0x27,param_4);
    if (iVar2 != 0) {
      *(int *)(iVar2 + 0x28) = *(int *)(iVar2 + 0x28) + *(int *)(iVar1 + 4);
      *(int *)(iVar2 + 0x24) = *(int *)(iVar2 + 0x24) + 1;
    }
    param_1[0x3a] = param_1[0x3a] + 1;
    param_1[0x3b] = param_1[0x3b] + *(int *)(iVar1 + 4);
  }
  (**(code **)(*param_1 + 0x30))(param_2,param_3);
  return;
}



/* FUNCTION 8634 ; VA 0x006a8d30 ; FUN_006a8d30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_006a8d30(int param_1)

{
  double dVar1;
  double dVar2;
  
  if ((*(char *)(param_1 + 0x40) != '\0') && (*(char *)(param_1 + 0x38) == '\0')) {
    if ((double)(*(int *)(param_1 + 4) * 2) < *(double *)(param_1 + 0x10)) {
      dVar2 = *(double *)(param_1 + 0x10) * _PTR_018cf0f8;
      dVar1 = (double)*(int *)(param_1 + 4);
      *(double *)(param_1 + 0x18) = dVar2;
      if (dVar2 < dVar1) {
        *(double *)(param_1 + 0x18) = dVar1;
      }
      *(double *)(param_1 + 0x10) = dVar1;
      *(undefined *)(param_1 + 0x38) = 1;
    }
  }
  return;
}



/* FUNCTION 8635 ; VA 0x006a8d90 ; FUN_006a8d90 */

void __fastcall FUN_006a8d90(int param_1)

{
  *(undefined4 *)(param_1 + 0x20) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  return;
}



/* FUNCTION 8636 ; VA 0x006a8db0 ; FUN_006a8db0 */

void FUN_006a8db0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,uint3 param_5
                 )

{
  uint3 uVar1;
  char cVar2;
  undefined *puVar3;
  int iVar4;
  int iVar5;
  bool bVar6;
  bool bVar7;
  char cStack00000017;
  uint uStack_12c;
  uint uStack_124;
  int iStack_120;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar1 = param_5;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a644b;
  pvStack_10 = ExceptionList;
  iVar5 = param_4 + 0x12;
  if ((char)param_5 == '\0') {
    iVar5 = param_4;
  }
  ExceptionList = &pvStack_10;
  if (4 < param_4) {
    _param_5 = (uint)param_5;
    ExceptionList = &pvStack_10;
    FUN_006a5530(param_3,4,0);
    uStack_8 = 0;
    if (uStack_124 + 1 <= uStack_12c) {
      _param_5 = CONCAT13((*(byte *)((uStack_124 >> 3) + iStack_120) &
                          (byte)(0x80 >> ((byte)uStack_124 & 7))) != 0,uVar1);
      uStack_124 = uStack_124 + 1;
    }
    if (uStack_12c < uStack_124 + 1) {
      bVar6 = false;
    }
    else {
      bVar6 = (*(byte *)((uStack_124 >> 3) + iStack_120) & (byte)(0x80 >> ((byte)uStack_124 & 7)))
              != 0;
      uStack_124 = uStack_124 + 1;
    }
    if (uStack_12c < uStack_124 + 1) {
      bVar7 = false;
    }
    else {
      bVar7 = (*(byte *)((uStack_124 >> 3) + iStack_120) & (byte)(0x80 >> ((byte)uStack_124 & 7)))
              != 0;
      uStack_124 = uStack_124 + 1;
    }
    if (((cStack00000017 != '\0') && (!bVar6)) && (!bVar7)) {
      iVar4 = uStack_124 - (uStack_124 - 1 & 7);
      iVar4 = (iVar4 + 7) - (iVar4 + 6U & 7);
      if (iVar4 + 0x1fU <= uStack_12c) {
        cVar2 = FUN_005fda50();
        puVar3 = (undefined *)((iVar4 + 7U >> 3) + iStack_120);
        if (cVar2 == '\0') {
          param_5 = CONCAT12(puVar3[2],CONCAT11(puVar3[1],*puVar3));
          _param_5 = (uint)param_5;
        }
        else {
          _param_5 = (uint)CONCAT21(CONCAT11(*puVar3,puVar3[1]),puVar3[2]) << 8;
        }
      }
      FUN_006a90f0(_param_5,iVar5,param_1,param_2);
      FUN_006a5640();
      ExceptionList = pvStack_10;
      return;
    }
    uStack_8 = 0xffffffff;
    FUN_006a5640();
  }
  FUN_006a90f0(0xffffffff,iVar5,param_1,param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8637 ; VA 0x006a8fb0 ; FUN_006a8fb0 */

void FUN_006a8fb0(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_01674e20(0x40);
  if (param_1 == 0) {
    *piVar1 = (int)piVar1;
    piVar1[1] = (int)piVar1;
    return;
  }
  *piVar1 = param_1;
  piVar1[1] = param_2;
  return;
}



/* FUNCTION 8638 ; VA 0x006a8fe0 ; FUN_006a8fe0 */

int __fastcall FUN_006a8fe0(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uVar5 = *(uint *)(param_1 + 0xac);
  uStack_8 = -1;
  iVar4 = -1;
  if (1 < uVar5) {
    iVar1 = uVar5 - 2;
    uStack_c = 0;
    if (-1 < iVar1) {
      do {
        if ((3 < uStack_c) ||
           ((*(int *)(param_1 + 0x6c) != 0 && (iVar1 < (int)(uVar5 - *(int *)(param_1 + 0x6c))))))
        break;
        iVar4 = *(int *)(param_1 + 0xa0);
        iVar3 = *(int *)(param_1 + 0xa4);
        iVar2 = iVar4 - iVar3 >> 7;
        iVar6 = iVar1;
        if (iVar2 <= iVar1) {
          iVar6 = iVar1 - (iVar4 - *(int *)(param_1 + 0x9c) >> 7);
          iVar3 = *(int *)(param_1 + 0xa4);
        }
        if (uStack_8 < *(int *)(iVar6 * 0x80 + 0x6c + iVar3)) {
          iVar6 = iVar1;
          if (iVar2 <= iVar1) {
            iVar6 = iVar1 - (iVar4 - *(int *)(param_1 + 0x9c) >> 7);
            iVar3 = *(int *)(param_1 + 0xa4);
          }
          uStack_8 = *(int *)(iVar6 * 0x80 + 0x6c + iVar3);
        }
        iVar3 = iVar1;
        if (iVar2 <= iVar1) {
          iVar3 = iVar1 - (iVar4 - *(int *)(param_1 + 0x9c) >> 7);
        }
        uVar5 = *(uint *)(param_1 + 0xac);
        iVar4 = uStack_c + -1;
        if (*(char *)(iVar3 * 0x80 + 0x7c + *(int *)(param_1 + 0xa4)) == '\0') {
          iVar4 = uStack_c;
        }
        uStack_c = iVar4 + 1;
        iVar1 = iVar1 + -1;
      } while (-1 < iVar1);
      iVar4 = uStack_8;
      if (0x8000 < uStack_8) {
        iVar4 = uStack_8 - ((int)(uStack_8 + (uStack_8 >> 0x1f & 0x3fU)) >> 6);
      }
    }
  }
  return iVar4;
}



/* FUNCTION 8639 ; VA 0x006a90f0 ; FUN_006a90f0 */

void __thiscall FUN_006a90f0(int param_1,uint param_2,uint param_3,uint param_4,int param_5)

{
  uint *puVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  undefined4 *puVar10;
  uint uVar11;
  int iVar12;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  int iStack_40;
  undefined8 uStack_3c;
  undefined8 uStack_34;
  int iStack_2c;
  int iStack_24;
  int iStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  int iStack_10;
  uint uStack_c;
  undefined uStack_5;
  
  param_3 = param_3 + 0x28;
  uStack_c = param_2;
  iStack_10 = param_1;
  if (param_2 == 0xffffffff) goto LAB_006a928a;
  *(int *)(param_1 + 0x11c) = *(int *)(param_1 + 0x11c) + param_3;
  puVar1 = (uint *)(param_1 + 0x140);
  uVar11 = *puVar1;
  *puVar1 = *puVar1 + param_3;
  *(uint *)(param_1 + 0x110) = param_4;
  *(int *)(param_1 + 0x144) =
       *(int *)(param_1 + 0x144) + ((int)param_3 >> 0x1f) + (uint)CARRY4(uVar11,param_3);
  *(int *)(param_1 + 0xcc) = *(int *)(param_1 + 0xcc) + param_3;
  iStack_24 = param_3 + *(uint *)(param_1 + 0xf0);
  iStack_20 = ((int)param_3 >> 0x1f) + *(int *)(param_1 + 0xf4) +
              (uint)CARRY4(param_3,*(uint *)(param_1 + 0xf0));
  *(int *)(param_1 + 200) = *(int *)(param_1 + 200) + 1;
  *(int *)(param_1 + 0xf0) = iStack_24;
  *(int *)(param_1 + 0x114) = param_5;
  *(int *)(param_1 + 0xf4) = iStack_20;
  if (*(int *)(param_1 + 0x138) == 0 && *(int *)(param_1 + 0x13c) == 0) {
    *(uint *)(param_1 + 0x138) = param_4;
    *(int *)(param_1 + 0x13c) = param_5;
    *(undefined4 *)(param_1 + 0x140) = 0;
    *(undefined4 *)(param_1 + 0x144) = 0;
    *(undefined4 *)(param_1 + 0x50) = 0;
    *(undefined4 *)(param_1 + 0x54) = 0;
  }
  uStack_4c = param_2;
  iStack_2c = *(int *)(param_1 + 0x68);
  *(int *)(param_1 + 0x68) = iStack_2c + 1;
  uStack_44 = param_4;
  iVar7 = *(int *)(param_1 + 0x94);
  puStack_14 = *(undefined4 **)(iVar7 + 4);
  iStack_40 = param_5;
  uStack_3c = 0;
  uStack_34 = 0;
  uStack_1c = 0;
  uStack_48 = param_3;
  uVar4 = FUN_006a7030(iVar7,puStack_14,&uStack_4c);
  if (*(int *)(param_1 + 0x98) == 0x3fffffe) {
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("list<T> too long");
  }
  *(int *)(param_1 + 0x98) = *(int *)(param_1 + 0x98) + 1;
  *(undefined4 *)(iVar7 + 4) = uVar4;
  *puStack_14 = uVar4;
  puVar10 = *(undefined4 **)(param_1 + 0xb8);
  puVar5 = (undefined4 *)puVar10[1];
  uVar4 = *(undefined4 *)(*(int *)(param_1 + 0x94) + 4);
  if (*(char *)((int)puVar5 + 0xd) == '\0') {
    do {
      if ((uint)puVar5[4] < param_2) {
        puVar6 = (undefined4 *)puVar5[2];
      }
      else {
        puVar6 = (undefined4 *)*puVar5;
        puVar10 = puVar5;
      }
      puVar5 = puVar6;
    } while (*(char *)((int)puVar6 + 0xd) == '\0');
    if ((puVar10 == *(undefined4 **)(param_1 + 0xb8)) || (param_2 < (uint)puVar10[4]))
    goto LAB_006a9245;
  }
  else {
LAB_006a9245:
    puStack_14 = &param_2;
    iVar7 = FUN_005f81a0(&DAT_018bdeda,&puStack_14,&uStack_5);
    FUN_00687600(&puStack_14,puVar10,iVar7 + 0x10,iVar7);
    puVar10 = puStack_14;
  }
  puVar10[5] = uVar4;
LAB_006a928a:
  iVar3 = iStack_10;
  *(int *)(param_1 + 0xc0) = *(int *)(param_1 + 0xc0) + 1;
  *(int *)(param_1 + 0xc4) = *(int *)(param_1 + 0xc4) + param_3;
  iVar7 = *(int *)(param_1 + 0xa8);
  if (iVar7 == *(int *)(param_1 + 0x9c)) {
    iVar7 = *(int *)(param_1 + 0xa0);
  }
  *(int *)(iVar7 + -0x74) = *(int *)(iVar7 + -0x74) + 1;
  *(int *)(iVar7 + -0x70) = *(int *)(iVar7 + -0x70) + param_3;
  if (param_2 != 0xffffffff) {
    *(int *)(iVar7 + -0x68) = *(int *)(iVar7 + -0x68) + param_3;
    *(int *)(iVar7 + -0x6c) = *(int *)(iVar7 + -0x6c) + 1;
    *(uint *)(iVar7 + -0x38) = param_4;
    *(int *)(iVar7 + -0x34) = param_5;
    *(uint *)(iVar7 + -0x7c) = param_2;
    if (*(int *)(iVar7 + -0x40) == 0 && *(int *)(iVar7 + -0x3c) == 0) {
      *(uint *)(iVar7 + -0x40) = param_4;
      *(int *)(iVar7 + -0x3c) = param_5;
      *(uint *)(iVar7 + -0x80) = param_2;
    }
  }
  if (2 < *(uint *)(param_1 + 0xac)) {
    uVar11 = param_4 + DAT_01d5b2fc * -1000;
    uStack_c = *(int *)(param_1 + 0xa4);
    iVar12 = (param_5 - (DAT_01d5b2fc * 1000 >> 0x1f)) -
             (uint)(param_4 < (uint)(DAT_01d5b2fc * 1000));
    iVar7 = *(int *)(param_1 + 0xa0);
    iVar9 = *(uint *)(param_1 + 0xac) - 3;
    param_3 = (int)(iVar7 - uStack_c) >> 7;
    iVar8 = iVar9;
    if ((int)param_3 <= iVar9) {
      param_5 = iVar9 - (iVar7 - *(int *)(param_1 + 0x9c) >> 7);
      iVar8 = param_5;
    }
    iVar2 = *(int *)(iVar8 * 0x80 + 0x44 + uStack_c);
    if ((iVar2 <= iVar12) &&
       ((iVar2 < iVar12 || (*(uint *)(iVar8 * 0x80 + 0x40 + uStack_c) < uVar11)))) {
      if ((int)param_3 <= iVar9) {
        iVar9 = iVar9 - (iVar7 - *(int *)(iStack_10 + 0x9c) >> 7);
      }
      uVar11 = *(uint *)(iVar9 * 0x80 + 0x40 + uStack_c);
      iVar12 = *(int *)(iVar9 * 0x80 + 0x44 + uStack_c);
    }
    iVar7 = *(int *)(iStack_10 + 0x98);
    while (iVar7 != 0) {
      iVar7 = **(int **)(iVar3 + 0x94);
      iVar8 = *(int *)(iVar7 + 0x14);
      if (iVar12 < iVar8) {
        return;
      }
      if ((iVar12 <= iVar8) && (uVar11 <= *(uint *)(iVar7 + 0x10))) {
        return;
      }
      FUN_006a98a0();
      iVar7 = *(int *)(iVar3 + 0x98);
    }
  }
  return;
}



/* FUNCTION 8640 ; VA 0x006a93b0 ; FUN_006a93b0 */

int __thiscall FUN_006a93b0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  longlong lVar7;
  undefined8 uVar8;
  longlong lVar9;
  
  if (2 < (*(int *)(param_1 + 200) - *(int *)(param_1 + 0xe8)) - *(int *)(param_1 + 0xe0)) {
    if (param_2 == -1) {
      param_2 = FUN_006a8fe0();
    }
    lVar7 = FUN_006a9750();
    uVar4 = param_2 >> 0x1f;
    uVar8 = FUN_016f39b0(param_2,uVar4,lVar7);
    iVar2 = FUN_016f3900(uVar8,1000000,0);
    iVar6 = ((*(int *)(param_1 + 0xcc) - *(int *)(param_1 + 0xec)) - *(int *)(param_1 + 0xe4)) -
            iVar2;
    if (*(int *)(param_1 + 4) + 0x3a <= iVar6) {
      iVar3 = *(int *)(param_1 + 0x44);
      if (iVar3 == 1) {
        iVar2 = (int)(iVar2 + (iVar2 >> 0x1f & 0xfU)) >> 4;
      }
      else if ((iVar3 == 4) || (iVar3 == 5)) {
        iVar2 = iVar2 / 2;
      }
      else {
        iVar2 = (int)(iVar2 + (iVar2 >> 0x1f & 3U)) >> 2;
      }
      if (iVar2 < iVar6) {
        lVar9 = FUN_016f3900(lVar7,8,0);
        lVar7 = lVar7 + lVar9;
        iVar2 = (int)((ulonglong)lVar7 >> 0x20);
        if (1 < *(uint *)(param_1 + 0xac)) {
          iVar5 = *(uint *)(param_1 + 0xac) - 1;
          iVar3 = iVar5;
          if (*(int *)(param_1 + 0xa0) - *(int *)(param_1 + 0xa4) >> 7 <= iVar5) {
            iVar3 = iVar5 - (*(int *)(param_1 + 0xa0) - *(int *)(param_1 + 0x9c) >> 7);
          }
          iVar1 = *(int *)(iVar3 * 0x80 + 0x34 + *(int *)(param_1 + 0xa4));
          if ((iVar2 <= iVar1) &&
             ((iVar2 < iVar1 ||
              ((uint)lVar7 < *(uint *)(iVar3 * 0x80 + 0x30 + *(int *)(param_1 + 0xa4)))))) {
            iVar2 = FUN_006a7ae0(iVar5);
            lVar7 = *(longlong *)(iVar2 + 0x30);
          }
        }
        uVar8 = FUN_016f39b0(param_2,uVar4,lVar7);
        iVar3 = FUN_016f3900(uVar8,1000000,0);
        iVar2 = iVar3 * 3;
        if (iVar6 <= iVar2 / 2) {
          if ((int)(iVar2 + (iVar2 >> 0x1f & 3U)) >> 2 <= iVar6) {
            return (int)((uVar4 & 3) + param_2) >> 2;
          }
          iVar2 = FUN_016f3900((longlong)iVar6 * (longlong)param_2,iVar3,iVar3 >> 0x1f);
          return param_2 - iVar2;
        }
        return (int)((uVar4 & 7) + param_2) >> 3;
      }
    }
  }
  return -1;
}



/* FUNCTION 8641 ; VA 0x006a9590 ; FUN_006a9590 */

void FUN_006a9590(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  if (param_1 != 0) {
    uVar2 = param_2 * 0x80;
    iVar1 = param_1;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  return;
}



/* FUNCTION 8642 ; VA 0x006a95d0 ; FUN_006a95d0 */

void __fastcall FUN_006a95d0(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = 0;
  if (param_1[4] != 0) {
    do {
      param_1[2] = param_1[2] + 0x80;
      uVar3 = uVar3 + 1;
      if (param_1[2] == param_1[1]) {
        param_1[2] = *param_1;
      }
    } while (uVar3 < (uint)param_1[4]);
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[1] - iVar1 & 0xffffff80;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  return;
}



/* FUNCTION 8643 ; VA 0x006a9630 ; FUN_006a9630 */

void __thiscall FUN_006a9630(undefined4 *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  undefined4 uVar1;
  
  if ((param_3 == *(int **)*param_1) && (param_4 == (int *)*param_1)) {
    FUN_00601ea0();
    *param_2 = *(undefined4 *)*param_1;
    return;
  }
  while (param_3 != param_4) {
    FUN_00551320();
    FUN_00551320();
    uVar1 = FUN_00553830(param_3);
    FUN_01674ea0(uVar1,0x18);
  }
  *param_2 = param_3;
  return;
}



/* FUNCTION 8644 ; VA 0x006a96a0 ; FUN_006a96a0 */

int __thiscall FUN_006a96a0(int param_1,uint param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar1 = *(undefined4 **)(param_1 + 0xb8);
  puVar2 = puVar1;
  puVar4 = (undefined4 *)puVar1[1];
  if (*(char *)((int)puVar1[1] + 0xd) == '\0') {
    do {
      puVar3 = puVar4;
      if ((uint)puVar3[4] < param_2) {
        puVar4 = (undefined4 *)puVar3[2];
        puVar3 = puVar2;
      }
      else {
        puVar4 = (undefined4 *)*puVar3;
      }
      puVar2 = puVar3;
    } while (*(char *)((int)puVar4 + 0xd) == '\0');
    if ((puVar3 != puVar1) && ((uint)puVar3[4] <= param_2)) goto LAB_006a96d7;
  }
  puVar3 = puVar1;
LAB_006a96d7:
  if (puVar3 == puVar1) {
    return 0;
  }
  return puVar3[5] + 8;
}



/* FUNCTION 8645 ; VA 0x006a96f0 ; FUN_006a96f0 */

int * FUN_006a96f0(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  
  iVar5 = param_1[4] + -1;
  if (-1 < iVar5) {
    iVar1 = param_1[1];
    iVar4 = param_1[2];
    iVar6 = iVar1 - iVar4;
    while( true ) {
      iVar2 = iVar5;
      if (iVar6 >> 7 <= iVar5) {
        iVar4 = param_1[2];
        iVar2 = iVar5 - (iVar1 - *param_1 >> 7);
      }
      piVar3 = (int *)(iVar2 * 0x80 + iVar4);
      if ((piVar3[5] != 0) && (*piVar3 <= param_2)) break;
      iVar5 = iVar5 + -1;
      if (iVar5 < 0) {
        return (int *)0x0;
      }
      iVar1 = param_1[1];
    }
    if (param_2 <= piVar3[1]) {
      return piVar3;
    }
  }
  return (int *)0x0;
}



/* FUNCTION 8646 ; VA 0x006a9750 ; FUN_006a9750 */

undefined8 __fastcall FUN_006a9750(int param_1)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uStack_20;
  int iStack_1c;
  
  uVar3 = *(uint *)(param_1 + 0x70);
  uVar2 = 0;
  uVar1 = *(uint *)(param_1 + 0xac);
  if (uVar3 == 0) {
    uVar3 = 0xc;
  }
  if ((uVar3 != 0) && (uVar3 < uVar1)) {
    uVar2 = uVar1 - uVar3;
  }
  if (uVar2 < uVar1) {
    uStack_20 = 0;
    iStack_1c = 0;
    do {
      uVar3 = uVar2;
      if (*(int *)(param_1 + 0xa0) - *(int *)(param_1 + 0xa4) >> 7 <= (int)uVar2) {
        uVar3 = uVar2 - (*(int *)(param_1 + 0xa0) - *(int *)(param_1 + 0x9c) >> 7);
      }
      iVar4 = uVar3 * 0x80 + *(int *)(param_1 + 0xa4);
      if (((*(int *)(iVar4 + 0x30) != 0 || *(int *)(iVar4 + 0x34) != 0) &&
          ((*(int *)(iVar4 + 0x34) < iStack_1c ||
           (((*(int *)(iVar4 + 0x34) <= iStack_1c && (*(uint *)(iVar4 + 0x30) < uStack_20)) ||
            (uStack_20 == 0 && iStack_1c == 0)))))) &&
         (((uVar2 != uVar1 - 1 || (4 < *(int *)(iVar4 + 8))) ||
          (*(int *)(param_1 + 4) <= *(int *)(iVar4 + 0x60))))) {
        uStack_20 = *(uint *)(iVar4 + 0x30);
        iStack_1c = *(int *)(iVar4 + 0x34);
      }
      uVar2 = uVar2 + 1;
    } while (uVar2 < uVar1);
    if ((-1 < iStack_1c) && ((0 < iStack_1c || (uStack_20 != 0)))) {
      return CONCAT44(iStack_1c,uStack_20);
    }
  }
  return 0xffffffffffffffff;
}



/* FUNCTION 8647 ; VA 0x006a9840 ; FUN_006a9840 */

int __fastcall FUN_006a9840(int param_1)

{
  int iVar1;
  longlong lVar2;
  
  lVar2 = FUN_006a9750();
  if (lVar2 == -1) {
    return -1;
  }
  iVar1 = FUN_016f3900((longlong)((*(int *)(param_1 + 4) + 0x3a) * DAT_01d59cbc) * 1000000,
                       lVar2 + 20000);
  if ((DAT_01eaeb60 != 0) && (DAT_01eaeb60 < iVar1)) {
    iVar1 = DAT_01eaeb60;
  }
  return iVar1;
}



/* FUNCTION 8648 ; VA 0x006a98a0 ; FUN_006a98a0 */

void __fastcall FUN_006a98a0(int param_1)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  undefined4 *puStack_c;
  undefined4 *puStack_8;
  
  piVar2 = *(int **)(param_1 + 0x94);
  piVar3 = (int *)*piVar2;
  uVar4 = piVar3[2];
  iVar5 = piVar3[3];
  iVar6 = piVar3[6];
  iVar7 = piVar3[7];
  iVar8 = piVar3[8];
  iVar9 = piVar3[9];
  if (*(int **)(param_1 + 0xb4) != piVar2) {
    if (*(int **)(param_1 + 0xb4) == piVar3) {
      *(undefined4 *)(param_1 + 0xd4) = 0;
      *(undefined4 *)(param_1 + 0xd0) = 0;
      *(undefined4 *)(param_1 + 0xdc) = 0;
      *(undefined4 *)(param_1 + 0xd8) = 0;
      *(int **)(param_1 + 0xb4) = piVar2;
    }
    else {
      *(int *)(param_1 + 0xd0) = *(int *)(param_1 + 0xd0) + -1;
      *(int *)(param_1 + 0xd4) = *(int *)(param_1 + 0xd4) - iVar5;
      if (uVar4 != 0xffffffff) {
        *(int *)(param_1 + 0xd8) = *(int *)(param_1 + 0xd8) + -1;
        *(int *)(param_1 + 0xdc) = *(int *)(param_1 + 0xdc) - iVar5;
      }
    }
  }
  piVar2 = (int *)*piVar2;
  *(int *)piVar2[1] = *piVar2;
  *(int *)(*piVar2 + 4) = piVar2[1];
  *(int *)(param_1 + 0x98) = *(int *)(param_1 + 0x98) + -1;
  FUN_01674ea0(piVar2,0x40);
  if (uVar4 != 0xffffffff) {
    puVar12 = *(undefined4 **)(param_1 + 0xb8);
    puVar11 = (undefined4 *)puVar12[1];
    cVar1 = *(char *)((int)puVar11 + 0xd);
    puStack_c = puVar12;
    puStack_8 = puVar11;
    while (cVar1 == '\0') {
      if ((uint)puStack_8[4] < uVar4) {
        puVar10 = (undefined4 *)puStack_8[2];
        puStack_8 = puStack_c;
      }
      else {
        if ((*(char *)((int)puVar12 + 0xd) != '\0') && (uVar4 < (uint)puStack_8[4])) {
          puVar12 = puStack_8;
        }
        puVar10 = (undefined4 *)*puStack_8;
      }
      puStack_c = puStack_8;
      puStack_8 = puVar10;
      cVar1 = *(char *)((int)puVar10 + 0xd);
    }
    if (*(char *)((int)puVar12 + 0xd) == '\0') {
      puVar11 = (undefined4 *)*puVar12;
    }
    cVar1 = *(char *)((int)puVar11 + 0xd);
    while (puStack_8 = puStack_c, cVar1 == '\0') {
      if (uVar4 < (uint)puVar11[4]) {
        puVar10 = (undefined4 *)*puVar11;
        puVar12 = puVar11;
      }
      else {
        puVar10 = (undefined4 *)puVar11[2];
      }
      puVar11 = puVar10;
      cVar1 = *(char *)((int)puVar10 + 0xd);
    }
    while (puStack_c != puVar12) {
      FUN_00551320();
    }
    FUN_006a9630(&puStack_c,puStack_8,puVar12);
    *(int *)(param_1 + 200) = *(int *)(param_1 + 200) + -1;
    *(int *)(param_1 + 0xcc) = *(int *)(param_1 + 0xcc) - iVar5;
    if (iVar6 != 0 || iVar7 != 0) {
      *(int *)(param_1 + 0xe0) = *(int *)(param_1 + 0xe0) + -1;
      *(int *)(param_1 + 0xe4) = *(int *)(param_1 + 0xe4) - iVar5;
    }
    if (iVar8 != 0 || iVar9 != 0) {
      *(int *)(param_1 + 0xe8) = *(int *)(param_1 + 0xe8) + -1;
      *(int *)(param_1 + 0xec) = *(int *)(param_1 + 0xec) - iVar5;
    }
  }
  *(int *)(param_1 + 0xc0) = *(int *)(param_1 + 0xc0) + -1;
  *(int *)(param_1 + 0xc4) = *(int *)(param_1 + 0xc4) - iVar5;
  return;
}



/* FUNCTION 8649 ; VA 0x006a9a40 ; FUN_006a9a40 */

void __thiscall FUN_006a9a40(int *param_1,uint param_2,undefined4 param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int *piStack_c;
  int iStack_8;
  
  uVar3 = param_2;
  uVar1 = param_1[4];
  piStack_c = param_1;
  if (uVar1 < param_2) {
    if ((uint)(param_1[1] - *param_1 >> 7) < param_2) {
      FUN_006a9cf0(param_2);
      uVar1 = param_1[4];
    }
    iStack_8 = 0;
    uVar3 = uVar3 - uVar1;
    if ((uVar3 != 0) && (uVar1 = param_1[1] - *param_1 >> 7, uVar1 != 0)) {
      param_2 = param_3;
      if (uVar3 <= uVar1) {
        uVar1 = uVar3;
      }
      FUN_006a77e0(&piStack_c,uVar1,&param_2);
      return;
    }
  }
  else {
    iVar2 = uVar1 - param_2;
    iStack_8 = 0;
    if (iVar2 < 1) {
      if (-1 < iVar2) {
        return;
      }
      FUN_006a7b10(-iVar2);
    }
    else {
      if (param_1[3] - *param_1 >> 7 < iVar2) {
        iVar2 = iVar2 - (param_1[1] - *param_1 >> 7);
      }
      iStack_8 = param_1[3] + iVar2 * -0x80;
    }
    if (iStack_8 != 0) {
      do {
        iVar2 = param_1[3];
        if (iVar2 == *param_1) {
          iVar2 = param_1[1];
        }
        param_1[3] = iVar2 + -0x80;
        param_1[4] = param_1[4] + -1;
      } while (iVar2 + -0x80 != iStack_8);
    }
  }
  return;
}



/* FUNCTION 8650 ; VA 0x006a9b20 ; FUN_006a9b20 */

/* WARNING: Removing unreachable block (ram,0x006a9c70) */

void __thiscall FUN_006a9b20(int param_1,uint param_2)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  longlong lVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  
  lVar6 = FUN_006a9750();
  if (lVar6 != -1) {
    uVar2 = FUN_016f3900((longlong)((*(int *)(param_1 + 4) + 0x3a) * DAT_01d59cbc) * 1000000,
                         lVar6 + 20000);
    if ((DAT_01eaeb60 != 0) && ((int)DAT_01eaeb60 < (int)uVar2)) {
      uVar2 = DAT_01eaeb60;
    }
    if ((uVar2 != 0xffffffff) && ((int)uVar2 < (int)param_2)) {
      param_2 = uVar2;
    }
  }
  if ((int)param_2 < (int)DAT_01d5b32c) {
    param_2 = DAT_01d5b32c;
  }
  param_2 = param_2 & 0xffffff00;
  if (param_2 != *(uint *)(param_1 + 0x134)) {
    if (*(int *)(param_1 + 0x138) != 0 || *(int *)(param_1 + 0x13c) != 0) {
      uVar7 = FUN_006a6920();
      iVar4 = (int)((ulonglong)uVar7 >> 0x20);
      uVar3 = (uint)uVar7;
      iVar5 = *(int *)(param_1 + 0x134);
      uVar8 = FUN_016f39b0(uVar3 - *(uint *)(param_1 + 0x138),
                           (iVar4 - *(int *)(param_1 + 0x13c)) -
                           (uint)(uVar3 < *(uint *)(param_1 + 0x138)),iVar5,iVar5 >> 0x1f);
      lVar6 = FUN_016f3900(uVar8,1000000,0);
      uVar2 = *(uint *)(param_1 + 0x140);
      iVar1 = *(int *)(param_1 + 0x144);
      uVar8 = FUN_016f39b0(uVar2,iVar1,1000000,0);
      uVar8 = FUN_016f3900(uVar8,iVar5,iVar5 >> 0x1f);
      iVar5 = (int)((ulonglong)uVar8 >> 0x20) + *(int *)(param_1 + 0x13c) +
              (uint)CARRY4((uint)uVar8,*(uint *)(param_1 + 0x138));
      iVar4 = iVar4 - (uint)(uVar3 < 20000);
      if ((iVar5 <= iVar4) &&
         (((iVar5 < iVar4 || ((uint)uVar8 + *(uint *)(param_1 + 0x138) < uVar3 - 20000)) &&
          (uVar3 = *(int *)(param_1 + 4) * 2 + 0x74,
          CONCAT44(((int)uVar3 >> 0x1f) + iVar1 + (uint)CARRY4(uVar3,uVar2),uVar3 + uVar2) < lVar6))
         )) {
        *(undefined4 *)(param_1 + 0x140) = 0;
        *(undefined4 *)(param_1 + 0x144) = 0;
        *(undefined4 *)(param_1 + 0x138) = 0;
        *(undefined4 *)(param_1 + 0x13c) = 0;
        *(uint *)(param_1 + 0x134) = param_2;
        return;
      }
      *(undefined8 *)(param_1 + 0x138) = uVar7;
      *(uint *)(param_1 + 0x140) = uVar2 - (uint)lVar6;
      *(uint *)(param_1 + 0x144) =
           (iVar1 - (int)((ulonglong)lVar6 >> 0x20)) - (uint)(uVar2 < (uint)lVar6);
    }
    *(uint *)(param_1 + 0x134) = param_2;
  }
  return;
}



/* FUNCTION 8651 ; VA 0x006a9cf0 ; FUN_006a9cf0 */

void __thiscall FUN_006a9cf0(int *param_1,uint param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  undefined4 *puStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6608;
  pvStack_10 = ExceptionList;
  if (param_2 == param_1[1] - *param_1 >> 7) {
    return;
  }
  if (0x1ffffff < param_2) {
    ExceptionList = &pvStack_10;
    uVar4 = FUN_005e07c0("circular_buffer");
    uStack_8 = 0;
    FUN_005dffd0(uVar4);
    goto LAB_006a9ea7;
  }
  if (param_2 == 0) {
LAB_006a9d91:
    puVar8 = (undefined4 *)0x0;
    ExceptionList = &pvStack_10;
  }
  else {
    uVar5 = param_2 << 7;
    if (param_2 < 0x2000000) {
      if (uVar5 < 0x1000) {
        if (uVar5 != 0) {
          ExceptionList = &pvStack_10;
          puVar8 = (undefined4 *)FUN_01674e20(uVar5);
          goto LAB_006a9d93;
        }
        goto LAB_006a9d91;
      }
    }
    else {
      uVar5 = 0xffffffff;
    }
    uVar2 = uVar5 + 0x23;
    if (uVar2 <= uVar5) {
      uVar2 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) {
LAB_006a9ea7:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    puVar8 = (undefined4 *)(iVar3 + 0x23U & 0xffffffe0);
    puVar8[-1] = iVar3;
  }
LAB_006a9d93:
  uVar5 = param_1[4];
  if (uVar5 == 0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    puVar6 = (undefined4 *)param_1[2];
  }
  uStack_8 = 1;
  uVar2 = param_2;
  if (uVar5 < param_2) {
    uVar2 = uVar5;
  }
  puVar1 = puVar8;
  if ((int)uVar2 < 1) {
    puStack_24 = puVar6;
    if ((int)uVar2 < 0) {
      FUN_006a7b70(-uVar2);
    }
  }
  else {
    if (param_1[1] - (int)puVar6 >> 7 <= (int)uVar2) {
      uVar2 = uVar2 - (param_1[1] - *param_1 >> 7);
    }
    puStack_24 = puVar6 + uVar2 * 0x20;
    if (puVar6 + uVar2 * 0x20 == (undefined4 *)param_1[3]) {
      puStack_24 = (undefined4 *)0x0;
    }
  }
  while (puVar6 != puStack_24) {
    if (puVar1 != (undefined4 *)0x0) {
      puVar7 = puVar6;
      puVar9 = puVar1;
      for (iVar3 = 0x20; iVar3 != 0; iVar3 = iVar3 + -1) {
        *puVar9 = *puVar7;
        puVar7 = puVar7 + 1;
        puVar9 = puVar9 + 1;
      }
    }
    puVar7 = puVar6 + 0x20;
    if (puVar7 == (undefined4 *)param_1[1]) {
      puVar7 = (undefined4 *)*param_1;
    }
    puVar6 = (undefined4 *)0x0;
    if (puVar7 != (undefined4 *)param_1[3]) {
      puVar6 = puVar7;
    }
    puVar1 = puVar1 + 0x20;
  }
  FUN_006a95d0();
  *param_1 = (int)puVar8;
  param_1[4] = (int)puVar1 - (int)puVar8 >> 7;
  param_1[2] = (int)puVar8;
  param_1[1] = (int)(puVar8 + param_2 * 0x20);
  if (puVar1 != puVar8 + param_2 * 0x20) {
    puVar8 = puVar1;
  }
  param_1[3] = (int)puVar8;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8652 ; VA 0x006a9e76 ; Catch_All@006a9e76 */

void Catch_All_006a9e76(void)

{
  int unaff_EBP;
  
  FUN_006a9590(*(undefined4 *)(unaff_EBP + -0x1c),*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 8653 ; VA 0x006a9eb0 ; FUN_006a9eb0 */

/* WARNING: Removing unreachable block (ram,0x006aa5a8) */
/* WARNING: Removing unreachable block (ram,0x006aa5f9) */
/* WARNING: Removing unreachable block (ram,0x006aa434) */
/* WARNING: Removing unreachable block (ram,0x006aa26a) */
/* WARNING: Removing unreachable block (ram,0x006aa18f) */
/* WARNING: Removing unreachable block (ram,0x006aa19e) */
/* WARNING: Removing unreachable block (ram,0x006aa48b) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_006a9eb0(int param_1,int *param_2)

{
  double dVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  double in_XMM0_Qa;
  longlong lVar13;
  undefined8 uVar14;
  longlong lVar15;
  longlong lVar16;
  int iStack_18;
  
  if ((uint)param_2[4] < 2) {
    return;
  }
  iVar9 = param_2[4] - 2;
  iVar6 = param_2[1] - param_2[2] >> 7;
  if (iVar6 <= iVar9) {
    iVar9 = iVar9 - (param_2[1] - *param_2 >> 7);
  }
  iVar10 = iVar9 * 0x80 + param_2[2];
  iVar9 = FUN_006a8fe0();
  iVar4 = FUN_006a96a0(*(undefined4 *)(iVar10 + 4));
  if ((uint)param_2[4] < 3) {
    if (iVar4 != 0) {
      iVar6 = param_2[3];
      if (param_2[3] == *param_2) {
        iVar6 = param_2[1];
      }
      iVar7 = *(uint *)(iVar6 + -0x30) - *(uint *)(iVar10 + 0x50);
      iVar12 = (*(int *)(iVar6 + -0x2c) - *(int *)(iVar10 + 0x54)) -
               (uint)(*(uint *)(iVar6 + -0x30) < *(uint *)(iVar10 + 0x50));
      iVar6 = param_2[3];
      if (param_2[3] == *param_2) {
        iVar6 = param_2[1];
      }
      if ((-1 < iVar12) && ((0 < iVar12 || (iVar7 != 0)))) {
        iVar11 = *(uint *)(iVar6 + -0x40) - *(uint *)(iVar10 + 0x40);
        uVar5 = (uint)(*(uint *)(iVar6 + -0x40) < *(uint *)(iVar10 + 0x40));
        iVar3 = *(int *)(iVar6 + -0x3c) - *(int *)(iVar10 + 0x44);
        iVar8 = iVar3 - uVar5;
        if ((iVar8 >= 0) &&
           ((iVar8 != 0 &&
             (SBORROW4(*(int *)(iVar6 + -0x3c),*(int *)(iVar10 + 0x44)) != SBORROW4(iVar3,uVar5)) ==
             iVar8 < 0 || (iVar11 != 0)))) {
          lVar13 = FUN_016f39b0(*(undefined4 *)(iVar4 + 0x28),*(undefined4 *)(iVar4 + 0x2c),0x7a12,0
                               );
          lVar13 = lVar13 + CONCAT44(iVar8,iVar11);
          uVar5 = (uint)lVar13;
          uVar5 = FUN_016f3900(uVar5 * 0x20,(int)((ulonglong)lVar13 >> 0x20) * 0x20 | uVar5 >> 0x1b,
                               iVar11,iVar8);
          *(uint *)(iVar10 + 0x68) = uVar5 & 0xffffffc0;
          lVar13 = FUN_016f39b0(*(undefined4 *)(iVar4 + 0x30),*(undefined4 *)(iVar4 + 0x34),0x7a12,0
                               );
          lVar13 = lVar13 + CONCAT44(iVar12,iVar7);
          goto LAB_006aa0b3;
        }
      }
    }
  }
  else {
    iVar7 = param_2[4] - 3;
    if (iVar6 <= iVar7) {
      iVar7 = iVar7 - (param_2[1] - *param_2 >> 7);
    }
    iVar6 = FUN_006a96a0(*(undefined4 *)(iVar7 * 0x80 + 4 + param_2[2]));
    if ((iVar4 != 0) && (iVar6 != 0)) {
      iVar7 = *(uint *)(iVar4 + 0x10) - *(uint *)(iVar6 + 0x10);
      uVar5 = (uint)(*(uint *)(iVar4 + 0x10) < *(uint *)(iVar6 + 0x10));
      iVar3 = *(int *)(iVar4 + 0x14) - *(int *)(iVar6 + 0x14);
      iVar12 = iVar3 - uVar5;
      if ((iVar12 >= 0) &&
         ((iVar12 != 0 &&
           (SBORROW4(*(int *)(iVar4 + 0x14),*(int *)(iVar6 + 0x14)) != SBORROW4(iVar3,uVar5)) ==
           iVar12 < 0 || (iVar7 != 0)))) {
        iVar8 = *(uint *)(iVar4 + 8) - *(uint *)(iVar6 + 8);
        uVar5 = (uint)(*(uint *)(iVar4 + 8) < *(uint *)(iVar6 + 8));
        iVar3 = *(int *)(iVar4 + 0xc) - *(int *)(iVar6 + 0xc);
        iVar11 = iVar3 - uVar5;
        if ((iVar11 >= 0) &&
           ((iVar11 != 0 &&
             (SBORROW4(*(int *)(iVar4 + 0xc),*(int *)(iVar6 + 0xc)) != SBORROW4(iVar3,uVar5)) ==
             iVar11 < 0 || (iVar8 != 0)))) {
          lVar13 = FUN_016f39b0(*(uint *)(iVar4 + 0x28) - *(uint *)(iVar6 + 0x28),
                                (*(int *)(iVar4 + 0x2c) - *(int *)(iVar6 + 0x2c)) -
                                (uint)(*(uint *)(iVar4 + 0x28) < *(uint *)(iVar6 + 0x28)),0x7a12,0);
          lVar13 = lVar13 + CONCAT44(iVar11,iVar8);
          uVar5 = (uint)lVar13;
          uVar5 = FUN_016f3900(uVar5 * 0x20,(int)((ulonglong)lVar13 >> 0x20) * 0x20 | uVar5 >> 0x1b,
                               iVar8,iVar11);
          *(uint *)(iVar10 + 0x68) = uVar5 & 0xffffffc0;
          lVar13 = FUN_016f39b0(*(uint *)(iVar4 + 0x30) - *(uint *)(iVar6 + 0x30),
                                (*(int *)(iVar4 + 0x34) - *(int *)(iVar6 + 0x34)) -
                                (uint)(*(uint *)(iVar4 + 0x30) < *(uint *)(iVar6 + 0x30)),0x7a12,0);
          lVar13 = lVar13 + CONCAT44(iVar12,iVar7);
LAB_006aa0b3:
          uVar5 = FUN_016f3900(lVar13 << 5,iVar7,iVar12);
          *(uint *)(iVar10 + 0x6c) = uVar5 & 0xffffffc0;
        }
      }
    }
  }
  iStack_18 = *(int *)(iVar10 + 0x6c);
  if (iStack_18 < 1) {
    *(undefined4 *)(iVar10 + 0x6c) = 1;
    iStack_18 = 1;
  }
  if ((0 < *(int *)(iVar10 + 0x18)) && (*(int *)(iVar10 + 0x28) != 0)) {
    in_XMM0_Qa = (double)*(int *)(iVar10 + 0x18);
    *(double *)(iVar10 + 0x70) = ((double)*(int *)(iVar10 + 0x28) * DAT_018ce318) / in_XMM0_Qa;
  }
  if (*(char *)(iVar10 + 0x7c) == '\0') {
    iVar6 = *(int *)(iVar10 + 0x60);
    if ((iVar6 < *(int *)(param_1 + 4)) && (0 < iVar6)) {
      iVar4 = *(int *)(param_1 + 4) + 0x3a;
      lVar16 = *(longlong *)(iVar10 + 0x30);
      uVar14 = FUN_016f39b0(iVar4,iVar4 >> 0x1f,*(undefined4 *)(iVar10 + 0x30),
                            *(undefined4 *)(iVar10 + 0x34));
      lVar15 = FUN_016f3900(uVar14,iVar6,iVar6 >> 0x1f);
      lVar13 = FUN_016f3900((longlong)iVar4 * 1000000,iStack_18,iStack_18 >> 0x1f);
      if (lVar15 < lVar13) {
        lVar13 = lVar15;
      }
      if (lVar16 < lVar13) {
        *(longlong *)(iVar10 + 0x30) = lVar13;
      }
    }
  }
  if (*(int *)(iVar10 + 0x30) != 0 || *(int *)(iVar10 + 0x34) != 0) {
    FUN_016f4020();
    *(double *)(param_1 + 8) = in_XMM0_Qa;
  }
  if (2 < (uint)param_2[4]) {
    iVar6 = *(int *)(iVar10 + 0x78);
    if ((((iVar6 == 3) || (iVar6 == 5)) || (iVar6 == 4)) && (*(char *)(iVar10 + 0x7c) == '\0')) {
      uVar14 = FUN_006a9750();
      iVar4 = (int)((ulonglong)uVar14 >> 0x20);
      uVar5 = (uint)uVar14;
      iVar6 = *(int *)(iVar10 + 0x6c) * 5;
      if (((int)(iVar6 + (iVar6 >> 0x1f & 3U)) >> 2 < *(int *)(iVar10 + 100)) &&
         (iVar6 = *(int *)(iVar10 + 0x68) * 5,
         (int)(iVar6 + (iVar6 >> 0x1f & 3U)) >> 2 < *(int *)(iVar10 + 100))) {
        uVar2 = *(uint *)(iVar10 + 0x30);
        iVar6 = *(int *)(iVar10 + 0x34);
        lVar13 = *(longlong *)(iVar10 + 0x30);
        lVar16 = FUN_016f3900(uVar5 * 5,
                              iVar4 + (iVar4 << 2 | uVar5 >> 0x1e) + (uint)CARRY4(uVar5,uVar5 * 4),4
                              ,0);
        if (lVar16 < lVar13) {
          iVar6 = (iVar6 - iVar4) - (uint)(uVar2 < uVar5);
          if ((((int)DAT_01d5b324 >> 0x1f <= iVar6) &&
              (((int)DAT_01d5b324 >> 0x1f < iVar6 || (DAT_01d5b324 < uVar2 - uVar5)))) &&
             (*(undefined4 *)(param_1 + 0x70) = 2, *(int *)(param_1 + 0x44) != 2)) {
            iVar6 = *(int *)(iVar10 + 0x6c) * 3;
            iVar6 = (int)(iVar6 + (iVar6 >> 0x1f & 3U)) >> 2;
            if (iVar6 == -1) {
              iVar6 = FUN_006a8fe0();
            }
            *(undefined4 *)(param_1 + 0x44) = 2;
            FUN_006a9b20(iVar6);
          }
        }
      }
    }
    iVar6 = param_2[4] + -3;
    if (param_2[1] - param_2[2] >> 7 <= iVar6) {
      iVar6 = iVar6 - (param_2[1] - *param_2 >> 7);
    }
    iVar6 = iVar6 * 0x80 + param_2[2];
    if (*(int *)(param_1 + 0x44) == 2) {
      if (*(int *)(iVar10 + 0x78) == 2) {
        if ((*(int *)(iVar10 + 0x34) <= *(int *)(iVar6 + 0x34)) &&
           ((*(int *)(iVar10 + 0x34) < *(int *)(iVar6 + 0x34) ||
            (*(uint *)(iVar10 + 0x30) < *(uint *)(iVar6 + 0x30))))) {
          iVar9 = *(int *)(iVar10 + 0x6c);
          iVar6 = *(int *)(iVar10 + 0x68);
          iVar4 = (int)(iVar9 + (iVar9 >> 0x1f & 0xfU)) >> 4;
          iVar10 = iVar9 - iVar4;
          if (iVar6 < iVar10) {
            if (iVar4 + iVar9 < iVar6) {
              return;
            }
            if (iVar6 < iVar10) {
              return;
            }
            FUN_006a9b20((int)(iVar9 * 3 + (iVar9 * 3 >> 0x1f & 3U)) >> 2);
            return;
          }
        }
LAB_006aa35d:
        iVar9 = FUN_006a8fe0();
        iVar9 = (int)(iVar9 * 5 + (iVar9 * 5 >> 0x1f & 3U)) >> 2;
        if (iVar9 == -1) {
          iVar9 = FUN_006a8fe0();
        }
        *(undefined4 *)(param_1 + 0x44) = 4;
        FUN_006a9b20(iVar9);
        return;
      }
    }
    else if (*(int *)(param_1 + 0x44) == 0) {
      if ((1 < *(int *)(iVar10 + 0x24)) &&
         (((dVar1 = *(double *)(iVar10 + 0x70), _DAT_018dad18 < dVar1 &&
           (*(double *)(iVar6 + 0x70) + *(double *)(iVar6 + 0x70) < dVar1)) ||
          ((*(int *)(iVar6 + 0x78) == 0 &&
           ((((_PTR_018c6f48 < *(double *)(iVar6 + 0x70) &&
              (*(double *)(iVar6 + 0x70) < _PTR_018cf0f8)) && (_PTR_018dad08 < dVar1)) ||
            ((*(double *)(iVar6 + 0x70) <= _PTR_018cf0f8 &&
              _PTR_018cf0f8 != *(double *)(iVar6 + 0x70) && (_DAT_018dad10 < dVar1)))))))))) {
LAB_006aa494:
        iVar9 = FUN_006a8fe0();
        iVar6 = FUN_006a93b0(iVar9);
        if (iVar6 != -1) {
          iVar9 = iVar6;
        }
        if (iVar9 == -1) {
          iVar9 = FUN_006a8fe0();
        }
        if (iVar6 == -1) {
          *(undefined4 *)(param_1 + 0x48) = 0;
        }
        *(uint *)(param_1 + 0x44) = (uint)(iVar6 == -1) * 2 + 1;
        FUN_006a9b20(iVar9);
        return;
      }
      iVar9 = *(int *)(iVar10 + 0x68);
      if (((longlong)*(int *)(iVar6 + 0x68) * 0x6e <= (longlong)iVar9 * 100) &&
         ((10000 < iVar9 - *(int *)(iVar6 + 0x68) && (*(int *)(iVar6 + 0x78) == 0)))) {
        lVar13 = FUN_016f39b0((longlong)*(int *)(iVar6 + 0x6c) * (longlong)iVar9,0x55,0);
        lVar16 = FUN_016f39b0((longlong)*(int *)(iVar10 + 0x6c) * (longlong)*(int *)(iVar6 + 0x68),
                              100,0);
        if (lVar16 < lVar13) goto LAB_006aa494;
      }
    }
    else {
      iVar4 = FUN_006a93b0(0xffffffff);
      iVar6 = *(int *)(param_1 + 0x44);
      if (iVar6 == 1) {
        if (iVar4 == -1) {
LAB_006aa50a:
          iVar9 = FUN_006a8fe0();
          if (iVar9 == -1) {
            iVar9 = FUN_006a8fe0();
          }
          *(undefined4 *)(param_1 + 0x48) = 0;
          *(undefined4 *)(param_1 + 0x44) = 3;
          FUN_006a9b20(iVar9);
          return;
        }
      }
      else {
        if (iVar4 != -1) {
          iVar9 = FUN_006a93b0(0xffffffff);
          if (iVar9 == -1) {
            iVar4 = 3;
            iVar9 = FUN_006a8fe0();
          }
          else {
            iVar4 = 1;
          }
          if ((iVar6 != iVar4) && (iVar4 == 3)) {
            *(undefined4 *)(param_1 + 0x48) = 0;
          }
          *(int *)(param_1 + 0x44) = iVar4;
          FUN_006a9b20(iVar9);
          return;
        }
        if (*(int *)(iVar10 + 0x78) == 4) {
          lVar13 = (longlong)iVar9 * 0x73;
        }
        else {
          lVar13 = (longlong)iVar9 * 0x78;
        }
        if (lVar13 < (longlong)*(int *)(iVar10 + 0x6c) * 100) {
          iVar9 = FUN_006a8fe0();
          if (iVar9 == -1) {
            iVar9 = FUN_006a8fe0();
          }
          *(undefined4 *)(param_1 + 0x50) = 0;
          *(undefined4 *)(param_1 + 0x54) = 0;
          *(undefined4 *)(param_1 + 0x44) = 0;
          FUN_006a9b20(iVar9);
          return;
        }
        if (iVar6 == 4) {
          iVar9 = FUN_006a8fe0();
          iVar9 = (int)(iVar9 * 3 + (iVar9 * 3 >> 0x1f & 3U)) >> 2;
          if (iVar9 == -1) {
            iVar9 = FUN_006a8fe0();
          }
          *(undefined4 *)(param_1 + 0x44) = 5;
          FUN_006a9b20(iVar9);
          return;
        }
        if (iVar6 == 5) goto LAB_006aa50a;
        if ((*(int *)(param_1 + 0x128) == 0 && *(int *)(param_1 + 300) == 0) &&
           (*(int *)(param_1 + 0x48) = *(int *)(param_1 + 0x48) + 1, *(int *)(param_1 + 0x48) == 10)
           ) goto LAB_006aa35d;
        iVar4 = FUN_006a8fe0();
      }
      FUN_006a9b20(iVar4);
    }
  }
  return;
}



/* FUNCTION 8654 ; VA 0x006aa680 ; FUN_006aa680 */

void FUN_006aa680(int *param_1,int param_2,int param_3,int param_4,int param_5)

{
  param_1[3] = param_1[3] + 1;
  param_1[4] = param_1[4] + param_3;
  if (param_2 != -1) {
    param_1[6] = param_1[6] + param_3;
    param_1[5] = param_1[5] + 1;
    param_1[0x12] = param_4;
    param_1[0x13] = param_5;
    param_1[1] = param_2;
    if (param_1[0x10] == 0 && param_1[0x11] == 0) {
      param_1[0x10] = param_4;
      param_1[0x11] = param_5;
      *param_1 = param_2;
    }
  }
  return;
}



/* FUNCTION 8655 ; VA 0x006aa6d0 ; FUN_006aa6d0 */

void __thiscall
FUN_006aa6d0(int param_1,int *param_2,uint param_3,uint param_4,uint param_5,uint param_6,
            uint param_7,uint param_8)

{
  uint *puVar1;
  uint *puVar2;
  int iVar3;
  uint *puVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  undefined auStack_90 [128];
  uint *puStack_10;
  uint uStack_c;
  uint uStack_8;
  
  uVar6 = param_3;
  puVar2 = (uint *)FUN_006a96f0(param_2,param_3);
  if (puVar2 == (uint *)0x0) {
    return;
  }
  uStack_8 = *puVar2;
  puStack_10 = (uint *)FUN_006a96f0(param_2,uStack_8 - 1);
  iVar3 = param_2[3];
  if (iVar3 == *param_2) {
    iVar3 = param_2[1];
  }
  if (((puVar2 == (uint *)(iVar3 + -0x80)) && (puVar2[0x14] == 0 && puVar2[0x15] == 0)) &&
     (puStack_10 != (uint *)0x0)) {
    puVar4 = puStack_10;
    if (puStack_10[2] == puStack_10[1]) {
      if (2 < (uint)param_2[4]) {
        iVar3 = FUN_006a7ae0(param_2[4] - 3);
        if (((int)puStack_10[0x17] <= *(int *)(iVar3 + 0x5c)) &&
           ((puVar4 = puStack_10, (int)puStack_10[0x17] < *(int *)(iVar3 + 0x5c) ||
            (puStack_10[0x16] <= *(uint *)(iVar3 + 0x58))))) goto joined_r0x006aa773;
      }
    }
    else {
joined_r0x006aa773:
      for (; puVar1 = puStack_10, puStack_10 = puVar4, (int)uStack_8 <= (int)param_3;
          uStack_8 = uStack_8 + 1) {
        uStack_c = FUN_006a96a0(uStack_8);
        if (uStack_c != 0) {
          FUN_006aa680(puVar1,uStack_8,*(undefined4 *)(uStack_c + 4),*(undefined4 *)(uStack_c + 8),
                       *(undefined4 *)(uStack_c + 0xc));
          puVar2[5] = puVar2[5] - 1;
          puVar2[3] = puVar2[3] - 1;
          puVar2[6] = puVar2[6] - *(int *)(uStack_c + 4);
          puVar2[4] = puVar2[4] - *(int *)(uStack_c + 4);
          if (*(int *)(uStack_c + 0x18) != 0 || *(int *)(uStack_c + 0x1c) != 0) {
            puVar2[10] = puVar2[10] - *(int *)(uStack_c + 4);
            puVar2[9] = puVar2[9] - 1;
            puVar1[10] = puVar1[10] + *(int *)(uStack_c + 4);
            puVar1[9] = puVar1[9] + 1;
          }
        }
        puVar4 = puStack_10;
        puStack_10 = puVar1;
      }
      if ((int)param_3 < (int)puVar2[1]) {
        puVar4 = (uint *)FUN_006a96a0(param_3 + 1);
        if (puVar4 != (uint *)0x0) {
          puVar2[0x10] = puVar4[2];
          puVar2[0x11] = puVar4[3];
          *puVar2 = *puVar4;
        }
      }
      else {
        puVar2[0x12] = 0;
        puVar2[0x13] = 0;
        puVar2[0x10] = 0;
        puVar2[0x11] = 0;
        puVar2[1] = 0;
        *puVar2 = 0;
      }
      puVar2 = puStack_10;
      puStack_10 = (uint *)FUN_006a96f0(param_2,*puStack_10 - 1);
    }
  }
  puVar2[8] = puVar2[8] + param_4;
  puVar2[7] = puVar2[7] + 1;
  if ((int)puVar2[2] < (int)param_3) {
    puVar2[2] = param_3;
  }
  if (puVar2[0x14] == 0 && puVar2[0x15] == 0) {
    puVar2[0x14] = param_5;
    puVar2[0x15] = param_6;
    puVar2[0x18] = param_4;
    puVar2[0xe] = param_7;
    puVar2[0xf] = param_8;
    puVar2[0xc] = param_7;
    puVar2[0xd] = param_8;
    uVar5 = param_7;
    uVar7 = param_8;
  }
  else {
    if (((int)puVar2[0xf] <= (int)param_8) &&
       (((int)puVar2[0xf] < (int)param_8 || (puVar2[0xe] < param_7)))) {
      puVar2[0xe] = param_7;
      puVar2[0xf] = param_8;
    }
    uStack_c = puVar2[0xd];
    uStack_8 = puVar2[0xc];
    if (((((int)param_8 <= (int)uStack_c) &&
         (((int)param_8 < (int)uStack_c || (param_7 < uStack_8)))) &&
        (((int)(*(int *)(param_1 + 4) + (*(int *)(param_1 + 4) >> 0x1f & 3U)) >> 2 <= (int)param_4
         || ((int)puVar2[0x18] < *(int *)(param_1 + 4))))) ||
       ((uVar5 = uStack_8, uVar7 = uStack_c, *(int *)(param_1 + 4) <= (int)param_4 &&
        ((int)puVar2[0x18] <
         (int)(*(int *)(param_1 + 4) + (*(int *)(param_1 + 4) >> 0x1f & 3U)) >> 2)))) {
      puVar2[0x18] = param_4;
      puVar2[0xc] = param_7;
      puVar2[0xd] = param_8;
      uVar5 = param_7;
      uVar7 = param_8;
    }
  }
  puVar2[0x16] = param_5;
  puVar2[0x17] = param_6;
  if ((((uVar7 - 1) + (uint)(1 < uVar5) == 0) && (uVar5 - 2 < 0xbb6)) &&
     (*(int *)(param_1 + 0x134) < 500000)) {
    FUN_006a9b20(10000000);
  }
  if (puStack_10 == (uint *)0x0) {
    param_3 = puVar2[0x15];
    uStack_c = puVar2[0x14];
    param_4 = puVar2[0x10];
    uVar5 = puVar2[0x11];
  }
  else {
    param_3 = puStack_10[0x17];
    uStack_c = puStack_10[0x16];
    param_4 = puStack_10[0x12];
    uVar5 = puStack_10[0x13];
  }
  uVar7 = puVar2[0x1e];
  if (uVar7 == 0) {
    if ((((*(int *)(param_1 + 0x44) != 0) || ((int)puVar2[0xd] < 0)) ||
        (((int)puVar2[0xd] < 1 && (puVar2[0xc] < 100000)))) || ((int)puVar2[7] < 0x15))
    goto LAB_006aab06;
    uStack_8 = puVar2[0x16] - uStack_c;
    uVar7 = (uint)(puVar2[0x16] < uStack_c);
    iVar3 = puVar2[0x17] - param_3;
    iVar8 = iVar3 - uVar7;
    if (((iVar8 < 0) ||
        ((iVar8 == 0 || (SBORROW4(puVar2[0x17],param_3) != SBORROW4(iVar3,uVar7)) != iVar8 < 0 &&
         (uStack_8 < 0x7531)))) || (iVar3 = FUN_006a96a0(uVar6), iVar3 == 0)) goto LAB_006aab06;
    uVar7 = *(uint *)(iVar3 + 8) - param_4;
    uVar6 = ((*(int *)(iVar3 + 0xc) - uVar5) - (uint)(*(uint *)(iVar3 + 8) < param_4)) * 2 |
            uVar7 >> 0x1f;
    if (((iVar8 <= (int)uVar6) &&
        (((iVar8 < (int)uVar6 || (uStack_8 <= uVar7 * 2)) &&
         ((int)(puVar2[10] * 4) <= (int)puVar2[8])))) ||
       ((puVar2[0x16] == uStack_c && (puVar2[0x17] == param_3)))) goto LAB_006aab06;
    iVar3 = FUN_016f3900((longlong)(int)puVar2[8] * 1000000,uStack_8,iVar8);
    if (iVar3 == -1) {
      iVar3 = FUN_006a8fe0();
    }
    iVar8 = FUN_006a93b0(iVar3);
    if (iVar8 != -1) {
      iVar3 = iVar8;
    }
    if (iVar3 == -1) {
      iVar3 = FUN_006a8fe0();
    }
    if (iVar8 == -1) {
      *(undefined4 *)(param_1 + 0x48) = 0;
    }
    *(uint *)(param_1 + 0x44) = (uint)(iVar8 == -1) * 2 + 1;
    FUN_006a9b20(iVar3);
    uVar7 = puVar2[0x1e];
  }
  if (((uVar7 == 2) && (*(int *)(param_1 + 0x44) == 2)) &&
     ((*(int *)(param_1 + 0xcc) - *(int *)(param_1 + 0xec)) - *(int *)(param_1 + 0xe4) <
      *(int *)(param_1 + 4) * 2 + 0x74)) {
    iVar3 = FUN_006a8fe0();
    if (iVar3 == -1) {
      iVar3 = FUN_006a8fe0();
    }
    *(undefined4 *)(param_1 + 0x48) = 0;
    *(undefined4 *)(param_1 + 0x44) = 3;
    FUN_006a9b20(iVar3);
    *(undefined4 *)(param_1 + 0x48) = 9;
  }
LAB_006aab06:
  iVar3 = param_2[3];
  iVar8 = iVar3;
  if (iVar3 == *param_2) {
    iVar8 = param_2[1];
  }
  if (puVar2 == (uint *)(iVar8 + -0x80)) {
    iVar8 = iVar3;
    if (iVar3 == *param_2) {
      iVar8 = param_2[1];
    }
    uVar6 = (param_6 - *(int *)(iVar8 + -0x3c)) - (uint)(param_5 < *(uint *)(iVar8 + -0x40));
    if (((uint)((int)DAT_01d5b324 >> 0x1f) <= uVar6) &&
       (((uint)((int)DAT_01d5b324 >> 0x1f) < uVar6 ||
        (DAT_01d5b324 <= param_5 - *(uint *)(iVar8 + -0x40))))) {
      iVar8 = iVar3;
      if (iVar3 == *param_2) {
        iVar8 = param_2[1];
      }
      if (*(int *)(iVar8 + -0x6c) < 3) {
        if (iVar3 == *param_2) {
          iVar3 = param_2[1];
        }
        if (*(int *)(iVar3 + -0x68) <= (*(int *)(param_1 + 4) + -0xc) / 2) {
          return;
        }
      }
      FUN_006a9eb0(param_2);
      FUN_0170d1f0();
      FUN_006a9a40(param_2[4] + 1,auStack_90);
      iVar3 = param_2[3];
      if (iVar3 == *param_2) {
        iVar3 = param_2[1];
      }
      *(undefined4 *)(iVar3 + -8) = *(undefined4 *)(param_1 + 0x44);
      iVar3 = param_2[3];
      if (iVar3 == *param_2) {
        iVar3 = param_2[1];
      }
      *(undefined4 *)(iVar3 + -0x1c) = *(undefined4 *)(param_1 + 0x134);
      if (*(int *)(param_1 + 0x128) != 0 || *(int *)(param_1 + 300) != 0) {
        iVar3 = param_2[3];
        if (iVar3 == *param_2) {
          iVar3 = param_2[1];
        }
        *(undefined *)(iVar3 + -4) = 1;
      }
      if (DAT_01d5b304 < param_2[4]) {
        param_2[2] = param_2[2] + 0x80;
        if (param_2[2] == param_2[1]) {
          param_2[2] = *param_2;
        }
        param_2[4] = param_2[4] + -1;
      }
      if ((*(int *)(param_1 + 0x6c) != 0) &&
         (uVar6 = *(int *)(param_1 + 0x6c) + 1, *(uint *)(param_1 + 0x6c) = uVar6,
         (uint)param_2[4] <= uVar6)) {
        *(undefined4 *)(param_1 + 0x6c) = 0;
      }
      if ((*(int *)(param_1 + 0x70) != 0) &&
         (uVar6 = *(int *)(param_1 + 0x70) + 1, *(uint *)(param_1 + 0x70) = uVar6,
         (uint)param_2[4] <= uVar6)) {
        *(undefined4 *)(param_1 + 0x70) = 0;
      }
    }
  }
  return;
}



/* FUNCTION 8656 ; VA 0x006aac50 ; FUN_006aac50 */

/* WARNING: Removing unreachable block (ram,0x006aade0) */
/* WARNING: Removing unreachable block (ram,0x006aae52) */
/* WARNING: Removing unreachable block (ram,0x006aae0b) */
/* WARNING: Removing unreachable block (ram,0x006aae2b) */
/* WARNING: Removing unreachable block (ram,0x006aaedb) */
/* WARNING: Type propagation algorithm not settling */

void __thiscall FUN_006aac50(int param_1,undefined8 param_2)

{
  int iVar1;
  longlong lVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  double dVar7;
  double dVar8;
  undefined8 uVar9;
  
  if (*(int *)(param_1 + 0x138) != 0 || *(int *)(param_1 + 0x13c) != 0) {
    iVar5 = *(int *)(param_1 + 4);
    lVar2 = FUN_016f39b0(*(undefined4 *)(param_1 + 0x140),*(undefined4 *)(param_1 + 0x144),1000000,0
                        );
    uVar9 = FUN_016f3900((longlong)(iVar5 + -0xc) * 1000000 + lVar2,*(int *)(param_1 + 0x134),
                         *(int *)(param_1 + 0x134) >> 0x1f);
    uVar3 = (uint)uVar9 + *(uint *)(param_1 + 0x138);
    iVar5 = (int)((ulonglong)uVar9 >> 0x20) + *(int *)(param_1 + 0x13c) +
            (uint)CARRY4((uint)uVar9,*(uint *)(param_1 + 0x138)) + (uint)(0xffffb1df < uVar3);
    if ((param_2._4_4_ < iVar5) || ((param_2._4_4_ <= iVar5 && ((uint)param_2 <= uVar3 + 20000))))
    goto LAB_006aad07;
  }
  *(undefined4 *)(param_1 + 0x138) = 0;
  *(undefined4 *)(param_1 + 0x13c) = 0;
  *(undefined4 *)(param_1 + 0x140) = 0;
  *(undefined4 *)(param_1 + 0x144) = 0;
  *(undefined4 *)(param_1 + 0x50) = 0;
  *(undefined4 *)(param_1 + 0x54) = 0;
LAB_006aad07:
  if (*(int *)(param_1 + 0x128) != 0 || *(int *)(param_1 + 300) != 0) {
    *(undefined4 *)(param_1 + 0x50) = 0;
    *(undefined4 *)(param_1 + 0x54) = 0;
    return;
  }
  if (*(int *)(param_1 + 0x50) == 0 && *(int *)(param_1 + 0x54) == 0) {
    *(uint *)(param_1 + 0x50) = (uint)param_2;
    *(uint *)(param_1 + 0x60) = (uint)param_2;
    *(int *)(param_1 + 0x54) = param_2._4_4_;
    *(int *)(param_1 + 100) = param_2._4_4_;
    *(undefined4 *)(param_1 + 0x58) = *(undefined4 *)(param_1 + 0x134);
    return;
  }
  iVar5 = DAT_01d5b31c;
  if (1 < *(uint *)(param_1 + 0xac)) {
    iVar4 = *(uint *)(param_1 + 0xac) - 2;
    if (*(int *)(param_1 + 0xa0) - *(int *)(param_1 + 0xa4) >> 7 <= iVar4) {
      iVar4 = iVar4 - (*(int *)(param_1 + 0xa0) - *(int *)(param_1 + 0x9c) >> 7);
    }
    iVar6 = DAT_01d5b324 * 2 >> 0x1f;
    iVar1 = *(int *)(iVar4 * 0x80 + 0x34 + *(int *)(param_1 + 0xa4));
    if ((iVar1 <= iVar6) &&
       ((iVar1 < iVar6 ||
        (*(uint *)(iVar4 * 0x80 + 0x30 + *(int *)(param_1 + 0xa4)) < (uint)(DAT_01d5b324 * 2))))) {
      iVar5 = DAT_01d5b31c / 2;
    }
  }
  if ((longlong)iVar5 * 1000 <=
      CONCAT44((param_2._4_4_ - *(int *)(param_1 + 100)) -
               (uint)((uint)param_2 < *(uint *)(param_1 + 0x60)),
               (uint)param_2 - *(uint *)(param_1 + 0x60))) {
    *(uint *)(param_1 + 0x60) = (uint)param_2;
    *(int *)(param_1 + 100) = param_2._4_4_;
    FUN_006a9750();
    dVar7 = (double)DAT_01d5b314 / DAT_018ce318;
    FUN_016f4020();
    FUN_016f4020();
    FUN_01726ab0();
    dVar7 = dVar7 * (double)*(int *)(param_1 + 0x58);
    iVar5 = FUN_006a9840();
    dVar8 = dVar7;
    if ((iVar5 != -1) && (dVar8 = (double)iVar5, dVar7 <= (double)iVar5)) {
      dVar8 = dVar7;
    }
    FUN_006a9b20((int)dVar8);
  }
  return;
}



/* FUNCTION 8657 ; VA 0x006aaf80 ; FUN_006aaf80 */

void FUN_006aaf80(int param_1,ushort *param_2)

{
  undefined auStack_4c [36];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x20) + 2U <= *(uint *)(param_1 + 0x18)) {
    *param_2 = *(ushort *)(*(int *)(param_1 + 8) + *(int *)(param_1 + 0x20));
    *(int *)(param_1 + 0x20) = *(int *)(param_1 + 0x20) + 2;
    *param_2 = *param_2 << 8 | *param_2 >> 8;
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_0054eff0("readFast past end for int16_t");
  uStack_8 = 0;
  FUN_005f8ef0(auStack_28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_4c,&DAT_01c27108);
}



/* FUNCTION 8658 ; VA 0x006ab010 ; FUN_006ab010 */

void FUN_006ab010(int param_1,uint *param_2)

{
  uint uVar1;
  undefined auStack_4c [36];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x20) + 4U <= *(uint *)(param_1 + 0x18)) {
    *param_2 = *(uint *)(*(int *)(param_1 + 8) + *(int *)(param_1 + 0x20));
    *(int *)(param_1 + 0x20) = *(int *)(param_1 + 0x20) + 4;
    uVar1 = *param_2;
    uVar1 = (uVar1 >> 8 ^ uVar1 << 8) & 0xff00ff ^ uVar1 << 8;
    *param_2 = uVar1 << 0x10 | uVar1 >> 0x10;
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_0054eff0("readFast past end for int32_t");
  uStack_8 = 0;
  FUN_005f8ef0(auStack_28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_4c,&DAT_01c27108);
}



/* FUNCTION 8659 ; VA 0x006ab0b0 ; FUN_006ab0b0 */

void FUN_006ab0b0(int param_1,uint *param_2)

{
  uint uVar1;
  undefined auStack_4c [36];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x20) + 4U <= *(uint *)(param_1 + 0x18)) {
    *param_2 = *(uint *)(*(int *)(param_1 + 8) + *(int *)(param_1 + 0x20));
    *(int *)(param_1 + 0x20) = *(int *)(param_1 + 0x20) + 4;
    uVar1 = *param_2;
    uVar1 = (uVar1 >> 8 ^ uVar1 << 8) & 0xff00ff ^ uVar1 << 8;
    *param_2 = uVar1 << 0x10 | uVar1 >> 0x10;
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_0054eff0("readFast past end for uint32_t");
  uStack_8 = 0;
  FUN_005f8ef0(auStack_28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_4c,&DAT_01c27108);
}



/* FUNCTION 8660 ; VA 0x006ab150 ; FUN_006ab150 */

uint * __thiscall FUN_006ab150(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  uint uVar5;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0xccccccc < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar5 = param_2 * 0x14;
    if (uVar5 < 0x1000) {
      if (uVar5 == 0) {
        uVar1 = 0;
      }
      else {
        uVar1 = FUN_01674e20(uVar5);
      }
    }
    else {
      uVar1 = uVar5 + 0x23;
      if (uVar1 <= uVar5) {
        uVar1 = 0xffffffff;
      }
      iVar2 = FUN_01674e20(uVar1);
      if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar1 = iVar2 + 0x23U & 0xffffffe0;
      *(int *)(uVar1 - 4) = iVar2;
    }
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + uVar5;
    puVar4 = (undefined4 *)*param_1;
    if (param_2 != 0) {
      puVar3 = puVar4 + 3;
      do {
        *puVar4 = 0;
        puVar3[-2] = 0;
        puVar4 = puVar4 + 5;
        puVar3[-1] = 0;
        *puVar3 = 0;
        puVar3[1] = 0;
        param_2 = param_2 - 1;
        puVar3 = puVar3 + 5;
      } while (param_2 != 0);
    }
    param_1[1] = (uint)puVar4;
  }
  return param_1;
}



/* FUNCTION 8661 ; VA 0x006ab230 ; FUN_006ab230 */

uint * __thiscall FUN_006ab230(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 != 0) {
    if (0x15555555 < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar4 = param_2 * 0xc;
    if (uVar4 < 0x1000) {
      if (uVar4 == 0) {
        uVar1 = 0;
      }
      else {
        uVar1 = FUN_01674e20(uVar4);
      }
    }
    else {
      uVar1 = uVar4 + 0x23;
      if (uVar1 <= uVar4) {
        uVar1 = 0xffffffff;
      }
      iVar2 = FUN_01674e20(uVar1);
      if (iVar2 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar1 = iVar2 + 0x23U & 0xffffffe0;
      *(int *)(uVar1 - 4) = iVar2;
    }
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + uVar4;
    puVar3 = (undefined4 *)*param_1;
    if (param_2 != 0) {
      do {
        *puVar3 = 0;
        puVar3[1] = 0;
        puVar3[2] = 0;
        puVar3 = puVar3 + 3;
        param_2 = param_2 - 1;
      } while (param_2 != 0);
    }
    param_1[1] = (uint)puVar3;
  }
  return param_1;
}



/* FUNCTION 8662 ; VA 0x006ab2f0 ; FUN_006ab2f0 */

undefined4 * __thiscall FUN_006ab2f0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a6633;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined *)(param_1 + 1) = 0;
  puVar1 = param_1 + 3;
  *param_1 = RBX::Network::NetworkStream::vftable;
  *puVar1 = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  uStack_8 = 1;
  FUN_0055b6c0(param_2,puVar1);
  param_1[7] = param_2;
  param_1[2] = *puVar1;
  param_1[6] = 0;
  param_1[8] = 0;
  *(undefined *)(param_1 + 9) = 1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8663 ; VA 0x006ab380 ; FUN_006ab380 */

undefined4 * __thiscall FUN_006ab380(undefined4 *param_1,uint param_2,uint param_3,char param_4)

{
  uint *puVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a6633;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined *)(param_1 + 1) = 0;
  puVar1 = param_1 + 3;
  *param_1 = RBX::Network::NetworkStream::vftable;
  *puVar1 = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  *(char *)(param_1 + 9) = param_4;
  uStack_8 = 1;
  param_1[7] = param_3;
  param_1[6] = param_3;
  param_1[8] = 0;
  if (param_4 != '\0') {
    uVar3 = *puVar1;
    iVar2 = param_2 + param_3;
    _param_4 = param_1[4] - uVar3;
    uVar4 = param_1[5] - uVar3;
    if (uVar4 < param_3) {
      if (0x7fffffff < param_3) {
                    /* WARNING: Subroutine does not return */
        FUN_00577c30();
      }
      _param_4 = uVar4 >> 1;
      uVar5 = param_3;
      if ((uVar4 <= 0x7fffffff - _param_4) && (uVar5 = _param_4 + uVar4, _param_4 + uVar4 < param_3)
         ) {
        uVar5 = param_3;
      }
      if (uVar3 != 0) {
        FUN_00554a20(uVar3,uVar4);
      }
      *puVar1 = 0;
      param_1[4] = 0;
      param_1[5] = 0;
      if (uVar5 != 0) {
        if (0x7fffffff < uVar5) {
                    /* WARNING: Subroutine does not return */
          FUN_00577c30();
        }
        uVar3 = FUN_00554060(uVar5);
        *puVar1 = uVar3;
        param_1[4] = uVar3;
        param_1[5] = *puVar1 + uVar5;
      }
      param_3 = *puVar1;
      FUN_0055b6b0(&stack0x0000000f,&param_4,&param_4);
      uVar3 = iVar2 - param_2;
      FUN_0170cc70(param_3,param_2,uVar3);
    }
    else if (_param_4 < param_3) {
      iVar6 = _param_4 + param_2;
      FUN_0170cc70(uVar3,param_2,iVar6 - param_2);
      param_3 = param_1[4];
      FUN_0055b6b0(&stack0x0000000f,&param_4,&param_4);
      uVar3 = iVar2 - iVar6;
      FUN_0170cc70(param_3,iVar6,uVar3);
    }
    else {
      FUN_0170cc70(uVar3,param_2,iVar2 - param_2);
    }
    param_1[4] = uVar3 + param_3;
    param_2 = *puVar1;
  }
  param_1[2] = param_2;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8664 ; VA 0x006ab530 ; FUN_006ab530 */

undefined4 * __fastcall FUN_006ab530(undefined4 *param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a6633;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined *)(param_1 + 1) = 0;
  puVar1 = param_1 + 3;
  *param_1 = RBX::Network::NetworkStream::vftable;
  *puVar1 = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  uStack_8 = 1;
  FUN_0055b6c0(0x100,puVar1);
  param_1[2] = *puVar1;
  param_1[7] = 0x100;
  param_1[6] = 0;
  param_1[8] = 0;
  *(undefined *)(param_1 + 9) = 1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 8665 ; VA 0x006ab5c0 ; FUN_006ab5c0 */

undefined4 * __thiscall FUN_006ab5c0(undefined4 *param_1,byte param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = param_1[3];
  if (iVar1 != 0) {
    uVar3 = param_1[5] - iVar1;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[5] = 0;
  }
  *param_1 = RakNet::AbstractBitStream::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 8666 ; VA 0x006ab630 ; FUN_006ab630 */

void __thiscall FUN_006ab630(int param_1,int param_2)

{
  uint uVar1;
  
  uVar1 = *(int *)(param_1 + 0x18) + param_2;
  if (*(uint *)(param_1 + 0x1c) < uVar1) {
    FUN_0055b6c0(uVar1,(undefined4 *)(param_1 + 0xc));
    *(uint *)(param_1 + 0x1c) = uVar1;
    *(undefined4 *)(param_1 + 8) = *(undefined4 *)(param_1 + 0xc);
  }
  return;
}



/* FUNCTION 8667 ; VA 0x006ab660 ; FUN_006ab660 */

void __thiscall FUN_006ab660(int param_1,int param_2)

{
  *(int *)(param_1 + 0x20) = *(int *)(param_1 + 0x20) + param_2;
  return;
}



/* FUNCTION 8668 ; VA 0x006ab670 ; FUN_006ab670 */

void __fastcall FUN_006ab670(int param_1)

{
  *(undefined *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0;
  return;
}



/* FUNCTION 8669 ; VA 0x006ab690 ; FUN_006ab690 */

void __thiscall FUN_006ab690(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x20) = param_2;
  return;
}



/* FUNCTION 8670 ; VA 0x006ab6a0 ; FUN_006ab6a0 */

void __thiscall FUN_006ab6a0(int param_1,uint param_2,char param_3)

{
  int iVar1;
  
  if (param_3 != '\0') {
    if ((param_2 < *(uint *)(param_1 + 0x18)) &&
       (iVar1 = *(uint *)(param_1 + 0x18) - param_2, iVar1 != 0)) {
      FUN_0170d1f0(*(int *)(param_1 + 8) + param_2,0,iVar1);
    }
    *(uint *)(param_1 + 0x18) = param_2;
    return;
  }
  *(uint *)(param_1 + 0x18) = param_2;
  return;
}



/* FUNCTION 8671 ; VA 0x006ab6e0 ; FUN_006ab6e0 */

void FUN_006ab6e0(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  float10 fVar5;
  undefined auStack_58 [36];
  undefined auStack_34 [24];
  int iStack_1c;
  uint uStack_18;
  byte bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795d48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  fVar5 = (float10)FUN_006ac3c0();
  *(float *)(param_1 + 0x24) = (float)fVar5;
  fVar5 = (float10)FUN_006ac3c0();
  *(float *)(param_1 + 0x28) = (float)fVar5;
  fVar5 = (float10)FUN_006ac3c0();
  *(float *)(param_1 + 0x2c) = (float)fVar5;
  FUN_00607ba0(param_2,&bStack_11);
  if (bStack_11 != 0) {
    FUN_00c93e80(bStack_11 - 1,param_1);
    ExceptionList = pvStack_10;
    return;
  }
  iStack_1c = 0;
  do {
    iVar4 = 0;
    do {
      uVar3 = *(int *)(param_2 + 0x20) + 4;
      if (*(uint *)(param_2 + 0x18) < uVar3) {
        FUN_0054eff0("readFast past end for float");
        uStack_8 = 0;
        FUN_005f8ef0(auStack_34);
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(auStack_58,&DAT_01c27108);
      }
      uVar2 = *(uint *)(*(int *)(param_2 + 8) + *(int *)(param_2 + 0x20));
      *(uint *)(param_2 + 0x20) = uVar3;
      uVar3 = uVar2 << 8 ^ (uVar2 >> 8 ^ uVar2 << 8) & 0xff00ff;
      uStack_18 = uVar3 << 0x10 | uVar3 >> 0x10;
      iVar1 = iStack_1c + iVar4;
      iVar4 = iVar4 + 1;
      *(uint *)(param_1 + iVar1 * 4) = uStack_18;
    } while (iVar4 < 3);
    iStack_1c = iStack_1c + 3;
  } while (iStack_1c < 9);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8672 ; VA 0x006ab810 ; FUN_006ab810 */

void FUN_006ab810(undefined4 *param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = param_1;
  uStack_8 = 0;
  FUN_006abaf0(&puStack_c,param_2);
  if (puStack_c == (undefined4 *)0x0) {
    *param_1 = 0xffffffff;
    return;
  }
  if (puStack_c == param_3) {
    puStack_c = (undefined4 *)0x0;
  }
  *param_1 = puStack_c;
  return;
}



/* FUNCTION 8673 ; VA 0x006ab860 ; FUN_006ab860 */

void FUN_006ab860(uint *param_1,undefined4 param_2)

{
  uint uStack_c;
  uint uStack_8;
  
  FUN_006abaf0(&uStack_c,param_2);
  param_1[1] = uStack_8 >> 1 ^ -(uint)((uStack_c & 1) != 0);
  *param_1 = (uStack_c >> 1 | uStack_8 << 0x1f) ^ -(uStack_c & 1);
  return;
}



/* FUNCTION 8674 ; VA 0x006ab8a0 ; FUN_006ab8a0 */

void FUN_006ab8a0(uint *param_1,undefined4 param_2)

{
  undefined8 uStack_c;
  
  uStack_c = 0;
  FUN_006abaf0(&uStack_c,param_2);
  *param_1 = (uint)uStack_c >> 1 ^ -((uint)uStack_c & 1);
  return;
}



/* FUNCTION 8675 ; VA 0x006ab8e0 ; FUN_006ab8e0 */

void FUN_006ab8e0(undefined4 *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined auStack_54 [36];
  undefined auStack_30 [24];
  uint auStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  auStack_18[0] = param_2;
  auStack_18[1] = 0;
  ExceptionList = &pvStack_10;
  FUN_006abaf0(auStack_18,param_2);
  uVar1 = auStack_18[0];
  uVar2 = *(int *)(param_2 + 0x18) - *(int *)(param_2 + 0x20);
  if (auStack_18[0] <= uVar2) {
    if ((uint)param_1[4] < auStack_18[0]) {
      FUN_00578160(auStack_18[0] - param_1[4],0);
    }
    else {
      puVar3 = param_1;
      if (0xf < (uint)param_1[5]) {
        puVar3 = (undefined4 *)*param_1;
      }
      param_1[4] = auStack_18[0];
      *(undefined *)((int)puVar3 + auStack_18[0]) = 0;
    }
    if (uVar1 != 0) {
      if (0xf < (uint)param_1[5]) {
        param_1 = (undefined4 *)*param_1;
      }
      if (*(int *)(param_2 + 0x20) + uVar1 <= *(uint *)(param_2 + 0x18)) {
        FUN_0170c6f0(param_1,*(int *)(param_2 + 8) + *(int *)(param_2 + 0x20),uVar1);
        *(int *)(param_2 + 0x20) = *(int *)(param_2 + 0x20) + uVar1;
      }
    }
    ExceptionList = pvStack_10;
    return;
  }
  uVar4 = FUN_01675640(auStack_30,"BitStream string read: String too long by: %u",
                       auStack_18[0] - uVar2);
  uStack_8 = 0;
  FUN_005f8ef0(uVar4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_54,&DAT_01c27108);
}



/* FUNCTION 8676 ; VA 0x006ab9d0 ; FUN_006ab9d0 */

void FUN_006ab9d0(undefined4 *param_1,undefined4 *param_2,uint param_3)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined auStack_54 [36];
  undefined auStack_30 [24];
  uint auStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  auStack_18[0] = param_3;
  auStack_18[1] = 0;
  ExceptionList = &pvStack_10;
  FUN_006abaf0(auStack_18,param_3);
  uVar2 = auStack_18[0];
  uVar3 = *(int *)(param_3 + 0x18) - *(int *)(param_3 + 0x20);
  if (auStack_18[0] <= uVar3) {
    iVar1 = param_2[4];
    uVar3 = iVar1 + auStack_18[0];
    if ((uint)param_1[4] < uVar3) {
      FUN_00578160(uVar3 - param_1[4],0);
    }
    else {
      puVar5 = param_1;
      if (0xf < (uint)param_1[5]) {
        puVar5 = (undefined4 *)*param_1;
      }
      param_1[4] = uVar3;
      *(undefined *)((int)puVar5 + uVar3) = 0;
    }
    puVar5 = param_2 + 4;
    puVar6 = param_1;
    if (0xf < (uint)param_1[5]) {
      puVar6 = (undefined4 *)*param_1;
    }
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_0170c6f0(puVar6,param_2,*puVar5);
    if (uVar2 != 0) {
      if (0xf < (uint)param_1[5]) {
        param_1 = (undefined4 *)*param_1;
      }
      if (*(int *)(param_3 + 0x20) + uVar2 <= *(uint *)(param_3 + 0x18)) {
        FUN_0170c6f0(iVar1 + (int)param_1,*(int *)(param_3 + 8) + *(int *)(param_3 + 0x20),uVar2);
        *(int *)(param_3 + 0x20) = *(int *)(param_3 + 0x20) + uVar2;
      }
    }
    ExceptionList = pvStack_10;
    return;
  }
  uVar4 = FUN_01675640(auStack_30,"BitStream string read: String too long by: %u",
                       auStack_18[0] - uVar3);
  uStack_8 = 0;
  FUN_005f8ef0(uVar4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_54,&DAT_01c27108);
}



/* FUNCTION 8677 ; VA 0x006abaf0 ; FUN_006abaf0 */

void FUN_006abaf0(uint *param_1,int *param_2)

{
  byte bVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  byte bVar6;
  int iVar7;
  undefined8 uVar8;
  undefined auStack_80 [36];
  undefined auStack_5c [36];
  undefined auStack_38 [24];
  uint uStack_20;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar3 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6658;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  uStack_1c = 0;
  bVar6 = 1;
  iVar2 = param_2[8];
  ExceptionList = &pvStack_10;
  iVar4 = (**(code **)(*param_2 + 8))();
  iVar7 = 0;
  uStack_18 = uStack_1c;
  param_2 = (int *)0x0;
  uStack_14 = uStack_20;
  uVar5 = iVar4 - iVar2;
  do {
    if (bVar6 == 0) goto LAB_006abba7;
    if ((iVar7 < 0) || ((iVar7 < 1 && (uVar5 == 0)))) {
      FUN_0054eff0("varint decode read past end");
      uStack_8 = 0;
      FUN_005f8ef0(auStack_38);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_80,&DAT_01c27108);
    }
    uStack_1c = uVar5 - 1;
    iVar7 = iVar7 + -1 + (uint)(uVar5 != 0);
    uVar5 = piVar3[8] + 1;
    if ((uint)piVar3[6] < uVar5) {
      FUN_0054eff0("readFast past end for uint8_t");
      uStack_8 = 1;
      FUN_005f8ef0(auStack_38);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_80,&DAT_01c27108);
    }
    bVar1 = *(byte *)(piVar3[2] + piVar3[8]);
    piVar3[8] = uVar5;
    uVar8 = FUN_016f4490();
    uStack_14 = uStack_14 | (uint)uVar8;
    param_2 = (int *)((int)param_2 + 7);
    uStack_18 = uStack_18 | (uint)((ulonglong)uVar8 >> 0x20);
    bVar6 = bVar1 >> 7;
    uVar5 = uStack_1c;
  } while ((int)param_2 < 0x46);
  if ((char)bVar1 < '\0') {
    FUN_0054eff0("varint decode larger than maximum size");
    uStack_8 = 2;
    FUN_005f8ef0(auStack_38);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_5c,&DAT_01c27108);
  }
LAB_006abba7:
  *param_1 = uStack_14;
  param_1[1] = uStack_18;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 8678 ; VA 0x006abc60 ; FUN_006abc60 */

void FUN_006abc60(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  uStack_c = *param_1;
  FUN_006abaf0(&uStack_c,param_2);
  *param_1 = uStack_c;
  return;
}



/* FUNCTION 8679 ; VA 0x006abc90 ; FUN_006abc90 */

void FUN_006abc90(int param_1)

{
  char cVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  
  cVar1 = FUN_01160820(*(undefined4 *)(param_1 + 0x24));
  if (cVar1 != '\0') {
    cVar1 = FUN_01160820(*(undefined4 *)(param_1 + 0x28));
    if (cVar1 != '\0') {
      cVar1 = FUN_01160820(*(undefined4 *)(param_1 + 0x2c));
      if (cVar1 != '\0') {
        fVar2 = *(float *)(param_1 + 0x24);
        if (*(float *)(param_1 + 0x24) <= DAT_018daf5c) {
          fVar2 = DAT_018daf5c;
        }
        fVar5 = DAT_018d0938;
        if (fVar2 <= DAT_018d0938) {
          fVar5 = fVar2;
        }
        fVar2 = *(float *)(param_1 + 0x28);
        if (*(float *)(param_1 + 0x28) <= DAT_018daf5c) {
          fVar2 = DAT_018daf5c;
        }
        fVar3 = DAT_018d0938;
        if (fVar2 <= DAT_018d0938) {
          fVar3 = fVar2;
        }
        fVar2 = *(float *)(param_1 + 0x2c);
        if (*(float *)(param_1 + 0x2c) <= DAT_018daf5c) {
          fVar2 = DAT_018daf5c;
        }
        fVar4 = DAT_018d0938;
        if (fVar2 <= DAT_018d0938) {
          fVar4 = fVar2;
        }
        *(ulonglong *)(param_1 + 0x24) = CONCAT44(fVar3,fVar5);
        *(float *)(param_1 + 0x2c) = fVar4;
        return;
      }
    }
  }
  *(ulonglong *)(param_1 + 0x24) = (ulonglong)(uint)DAT_018daf5c << 0x20;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  return;
}



/* FUNCTION 8680 ; VA 0x006abd60 ; FUN_006abd60 */

undefined4 * FUN_006abd60(undefined4 *param_1)

{
  undefined4 uVar1;
  
  FUN_0054d840(0);
  uVar1 = FUN_006ac4d0();
  *param_1 = uVar1;
  return param_1;
}



/* FUNCTION 8681 ; VA 0x006abd90 ; FUN_006abd90 */

bool __fastcall FUN_006abd90(undefined4 param_1)

{
  undefined4 uStack_8;
  
  uStack_8 = param_1;
  FUN_00607ba0(param_1,(int)&uStack_8 + 3);
  return uStack_8._3_1_ != '\0';
}



/* FUNCTION 8682 ; VA 0x006abdb0 ; FUN_006abdb0 */

undefined4 __thiscall FUN_006abdb0(int param_1,undefined4 param_2)

{
  uint uVar1;
  ushort uVar2;
  undefined auStack_4c [36];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uVar1 = *(int *)(param_1 + 0x20) + 2;
  if (uVar1 <= *(uint *)(param_1 + 0x18)) {
    uVar2 = *(ushort *)(*(int *)(param_1 + 8) + *(int *)(param_1 + 0x20));
    ExceptionList = &pvStack_10;
    *(uint *)(param_1 + 0x20) = uVar1;
    FUN_00c95dd0(uVar2 << 8 | uVar2 >> 8);
    ExceptionList = pvStack_10;
    return param_2;
  }
  ExceptionList = &pvStack_10;
  FUN_0054eff0("readFast past end for uint16_t");
  uStack_8 = 0;
  FUN_005f8ef0(auStack_28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_4c,&DAT_01c27108);
}



/* FUNCTION 8683 ; VA 0x006abe40 ; FUN_006abe40 */

uint __fastcall FUN_006abe40(uint param_1)

{
  undefined4 uStack_8;
  
  uStack_8 = param_1;
  FUN_00607ba0(param_1,(int)&uStack_8 + 3);
  return uStack_8 >> 0x18;
}



/* FUNCTION 8684 ; VA 0x006abe60 ; FUN_006abe60 */

undefined4 __thiscall FUN_006abe60(int param_1,undefined4 param_2,int param_3)

{
  if (*(uint *)(param_1 + 0x18) < (uint)(*(int *)(param_1 + 0x20) + param_3)) {
    return 0;
  }
  FUN_0170c6f0(param_2,*(int *)(param_1 + 8) + *(int *)(param_1 + 0x20),param_3);
  *(int *)(param_1 + 0x20) = *(int *)(param_1 + 0x20) + param_3;
  return 1;
}



/* FUNCTION 8685 ; VA 0x006abea0 ; FUN_006abea0 */

float * FUN_006abea0(float *param_1)

{
  float10 fVar1;
  
  *param_1 = 0.0;
  param_1[1] = 0.0;
  param_1[2] = 0.0;
  fVar1 = (float10)FUN_006ac3c0();
  *param_1 = (float)fVar1;
  fVar1 = (float10)FUN_006ac3c0();
  param_1[1] = (float)fVar1;
  fVar1 = (float10)FUN_006ac3c0();
  param_1[2] = (float)fVar1;
  return param_1;
}



/* FUNCTION 8686 ; VA 0x006abef0 ; FUN_006abef0 */

undefined2 * __thiscall FUN_006abef0(undefined4 param_1,undefined2 *param_2)

{
  undefined2 *puVar1;
  
  puVar1 = param_2;
  *param_2 = 0;
  *(undefined *)(param_2 + 1) = 0;
  FUN_00607ba0(param_1,(int)&param_2 + 3);
  *(undefined *)puVar1 = param_2._3_1_;
  FUN_00607ba0(param_1,(int)&param_2 + 3);
  *(undefined *)((int)puVar1 + 1) = param_2._3_1_;
  FUN_00607ba0(param_1,(int)&param_2 + 3);
  *(undefined *)(puVar1 + 1) = param_2._3_1_;
  return puVar1;
}



/* FUNCTION 8687 ; VA 0x006abf40 ; FUN_006abf40 */

undefined4 __thiscall FUN_006abf40(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  float fVar2;
  float10 fVar3;
  undefined auStack_70 [36];
  undefined auStack_4c [24];
  int aiStack_34 [3];
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6680;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006ab0b0(param_1,&fStack_18);
  fVar2 = fStack_18;
  if (0x14 < (uint)fStack_18) {
    FUN_0054eff0("Number sequence is too big");
    uStack_8 = 0;
    FUN_005f8ef0(auStack_4c);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_70,&DAT_01c27108);
  }
  FUN_006ab150(fStack_18,&uStack_11);
  uStack_8 = 1;
  if (fVar2 != 0.0) {
    iVar1 = 0;
    do {
      fVar3 = (float10)FUN_006ac3c0();
      fStack_18 = (float)fVar3;
      fVar3 = (float10)FUN_006ac3c0();
      fStack_1c = (float)fVar3;
      fVar3 = (float10)FUN_006ac3c0();
      fStack_20 = (float)fVar3;
      fVar3 = (float10)FUN_006ac3c0();
      fStack_24 = (float)fVar3;
      fVar3 = (float10)FUN_006ac3c0();
      fStack_28 = (float)fVar3;
      *(float *)(iVar1 + aiStack_34[0]) = fStack_18;
      *(float *)(iVar1 + 4 + aiStack_34[0]) = fStack_1c;
      *(float *)(iVar1 + 8 + aiStack_34[0]) = fStack_20;
      *(float *)(iVar1 + 0xc + aiStack_34[0]) = fStack_24;
      *(float *)(iVar1 + 0x10 + aiStack_34[0]) = fStack_28;
      fVar2 = (float)((int)fVar2 + -1);
      iVar1 = iVar1 + 0x14;
    } while (fVar2 != 0.0);
  }
  FUN_00a8e070(aiStack_34,0);
  FUN_00617bc0();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 8688 ; VA 0x006ac070 ; FUN_006ac070 */

float * FUN_006ac070(float *param_1)

{
  float10 fVar1;
  float10 fVar2;
  float10 fVar3;
  
  *param_1 = 0.0;
  param_1[1] = 0.0;
  param_1[2] = 0.0;
  param_1[3] = 0.0;
  param_1[4] = 0.0;
  fVar1 = (float10)FUN_006ac3c0();
  *param_1 = (float)fVar1;
  fVar1 = (float10)FUN_006ac3c0();
  fVar2 = (float10)FUN_006ac3c0();
  fVar3 = (float10)FUN_006ac3c0();
  param_1[1] = (float)fVar1;
  param_1[2] = (float)fVar2;
  param_1[3] = (float)fVar3;
  fVar1 = (float10)FUN_006ac3c0();
  param_1[4] = (float)fVar1;
  return param_1;
}



/* FUNCTION 8689 ; VA 0x006ac100 ; FUN_006ac100 */

undefined4 * __thiscall FUN_006ac100(undefined4 param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  float10 fVar2;
  
  puVar1 = param_2;
  *param_2 = 0x3f800000;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0x3f800000;
  param_2[5] = 0;
  param_2[6] = 0;
  param_2[7] = 0;
  param_2[8] = 0x3f800000;
  param_2[9] = 0;
  param_2[10] = 0;
  param_2[0xb] = 0;
  fVar2 = (float10)FUN_006ac3c0();
  puVar1[9] = (float)fVar2;
  fVar2 = (float10)FUN_006ac3c0();
  puVar1[10] = (float)fVar2;
  fVar2 = (float10)FUN_006ac3c0();
  puVar1[0xb] = (float)fVar2;
  FUN_00607ba0(param_1,(int)&param_2 + 3);
  if (param_2._3_1_ != 0) {
    FUN_00c93e80(param_2._3_1_ - 1);
    return puVar1;
  }
  FUN_00722c40(param_1,puVar1);
  return puVar1;
}



/* FUNCTION 8690 ; VA 0x006ac1c0 ; FUN_006ac1c0 */

undefined4 __thiscall FUN_006ac1c0(int param_1,undefined4 param_2)

{
  undefined8 uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  undefined auStack_54 [36];
  undefined auStack_30 [24];
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  uVar2 = *(int *)(param_1 + 0x20) + 8;
  if (uVar2 <= *(uint *)(param_1 + 0x18)) {
    uVar1 = *(undefined8 *)(*(int *)(param_1 + 8) + *(int *)(param_1 + 0x20));
    ExceptionList = &pvStack_10;
    *(uint *)(param_1 + 0x20) = uVar2;
    uStack_14 = (uint)((ulonglong)uVar1 >> 0x20);
    uStack_18 = (uint)uVar1;
    uVar4 = uStack_14 << 0x10;
    uVar2 = (uStack_18 ^ uStack_14) >> 0x10 ^ (uStack_18 << 0x10 | uStack_14 >> 0x10);
    uVar3 = uStack_14 >> 0x10 ^ uVar4;
    _uStack_18 = CONCAT44(uVar2,uStack_18);
    FUN_00b43410(param_2,(uVar3 >> 8 ^ uVar3 << 8) & 0xff00ff ^ uVar3 << 8,
                 (uVar2 >> 8 ^ (uVar2 << 8 | uVar4 >> 0x18)) & 0xff00ff ^
                 (uVar2 << 8 | uVar4 >> 0x18));
    ExceptionList = pvStack_10;
    return param_2;
  }
  ExceptionList = &pvStack_10;
  FUN_0054eff0("readFast past end for int64_t");
  uStack_8 = 0;
  FUN_005f8ef0(auStack_30);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_54,&DAT_01c27108);
}



/* FUNCTION 8691 ; VA 0x006ac2c0 ; FUN_006ac2c0 */

float10 __fastcall FUN_006ac2c0(int param_1)

{
  undefined8 uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  undefined auStack_58 [36];
  undefined auStack_34 [24];
  undefined8 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795d48;
  pvStack_10 = ExceptionList;
  uVar2 = *(int *)(param_1 + 0x20) + 8;
  if (uVar2 <= *(uint *)(param_1 + 0x18)) {
    uVar1 = *(undefined8 *)(*(int *)(param_1 + 8) + *(int *)(param_1 + 0x20));
    *(uint *)(param_1 + 0x20) = uVar2;
    uStack_1c._0_4_ = (uint)uVar1;
    uStack_1c._4_4_ = (uint)((ulonglong)uVar1 >> 0x20);
    uVar4 = uStack_1c._4_4_ << 0x10;
    uVar2 = ((uint)uStack_1c ^ uStack_1c._4_4_) >> 0x10 ^
            ((uint)uStack_1c << 0x10 | uStack_1c._4_4_ >> 0x10);
    uVar3 = uStack_1c._4_4_ >> 0x10 ^ uVar4;
    uStack_1c = (double)CONCAT44((uVar2 >> 8 ^ (uVar2 << 8 | uVar4 >> 0x18)) & 0xff00ff ^
                                 (uVar2 << 8 | uVar4 >> 0x18),
                                 (uVar3 >> 8 ^ uVar3 << 8) & 0xff00ff ^ uVar3 << 8);
    return (float10)uStack_1c;
  }
  ExceptionList = &pvStack_10;
  FUN_0054eff0("readFast past end for double");
  uStack_8 = 0;
  FUN_005f8ef0(auStack_34);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_58,&DAT_01c27108);
}



/* FUNCTION 8692 ; VA 0x006ac3c0 ; FUN_006ac3c0 */

float10 __fastcall FUN_006ac3c0(int param_1)

{
  uint uVar1;
  uint uVar2;
  undefined auStack_50 [36];
  undefined auStack_2c [28];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  uVar2 = *(int *)(param_1 + 0x20) + 4;
  if (uVar2 <= *(uint *)(param_1 + 0x18)) {
    uVar1 = *(uint *)(*(int *)(param_1 + 8) + *(int *)(param_1 + 0x20));
    *(uint *)(param_1 + 0x20) = uVar2;
    uVar2 = (uVar1 >> 8 ^ uVar1 << 8) & 0xff00ff ^ uVar1 << 8;
    return (float10)(float)(uVar2 << 0x10 | uVar2 >> 0x10);
  }
  ExceptionList = &pvStack_10;
  FUN_0054eff0("readFast past end for float");
  uStack_8 = 0;
  FUN_005f8ef0(auStack_2c);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_50,&DAT_01c27108);
}



/* FUNCTION 8693 ; VA 0x006ac450 ; FUN_006ac450 */

void __fastcall FUN_006ac450(int param_1)

{
  uint uVar1;
  undefined auStack_50 [36];
  undefined auStack_2c [28];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  uVar1 = *(int *)(param_1 + 0x20) + 2;
  if (uVar1 <= *(uint *)(param_1 + 0x18)) {
    *(uint *)(param_1 + 0x20) = uVar1;
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_0054eff0("readFast past end for int16_t");
  uStack_8 = 0;
  FUN_005f8ef0(auStack_2c);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_50,&DAT_01c27108);
}



/* FUNCTION 8694 ; VA 0x006ac4d0 ; FUN_006ac4d0 */

uint __fastcall FUN_006ac4d0(int param_1)

{
  uint uVar1;
  uint uVar2;
  undefined auStack_4c [36];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uVar2 = *(int *)(param_1 + 0x20) + 4;
  if (uVar2 <= *(uint *)(param_1 + 0x18)) {
    uVar1 = *(uint *)(*(int *)(param_1 + 8) + *(int *)(param_1 + 0x20));
    *(uint *)(param_1 + 0x20) = uVar2;
    uVar2 = (uVar1 >> 8 ^ uVar1 << 8) & 0xff00ff ^ uVar1 << 8;
    return uVar2 << 0x10 | uVar2 >> 0x10;
  }
  ExceptionList = &pvStack_10;
  FUN_0054eff0("readFast past end for int32_t");
  uStack_8 = 0;
  FUN_005f8ef0(auStack_28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_4c,&DAT_01c27108);
}



/* FUNCTION 8695 ; VA 0x006ac560 ; FUN_006ac560 */

undefined4 __fastcall FUN_006ac560(int param_1)

{
  uint uVar1;
  undefined uVar2;
  undefined auStack_4c [36];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uVar1 = *(int *)(param_1 + 0x20) + 1;
  if (uVar1 <= *(uint *)(param_1 + 0x18)) {
    uVar2 = *(undefined *)(*(int *)(param_1 + 8) + *(int *)(param_1 + 0x20));
    *(uint *)(param_1 + 0x20) = uVar1;
    return CONCAT31((int3)((uint)*(int *)(param_1 + 8) >> 8),uVar2);
  }
  ExceptionList = &pvStack_10;
  FUN_0054eff0("readFast past end for int8_t");
  uStack_8 = 0;
  FUN_005f8ef0(auStack_28);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_4c,&DAT_01c27108);
}



/* FUNCTION 8696 ; VA 0x006ac5d0 ; FUN_006ac5d0 */

float * FUN_006ac5d0(float *param_1)

{
  float10 fVar1;
  
  *param_1 = 0.0;
  param_1[1] = 0.0;
  fVar1 = (float10)FUN_006ac3c0();
  *param_1 = (float)fVar1;
  fVar1 = (float10)FUN_006ac3c0();
  param_1[1] = (float)fVar1;
  return param_1;
}



/* FUNCTION 8697 ; VA 0x006ac600 ; FUN_006ac600 */

undefined4 __thiscall FUN_006ac600(undefined4 param_1,undefined4 param_2)

{
  uint uVar1;
  float10 fVar2;
  undefined auStack_60 [36];
  int aiStack_3c [3];
  undefined auStack_30 [12];
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  uint uStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a66a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006ab0b0(param_1,&uStack_18);
  uVar1 = uStack_18;
  if (uStack_18 < 0x15) {
    FUN_006ab230(uStack_18,&uStack_11);
    uStack_8 = 1;
    if (uVar1 != 0) {
      uStack_18 = 0;
      do {
        fVar2 = (float10)FUN_006ac3c0();
        fStack_24 = (float)fVar2;
        fVar2 = (float10)FUN_006ac3c0();
        fStack_20 = (float)fVar2;
        fVar2 = (float10)FUN_006ac3c0();
        fStack_1c = (float)fVar2;
        *(ulonglong *)(uStack_18 + aiStack_3c[0]) = CONCAT44(fStack_20,fStack_24);
        *(float *)(uStack_18 + 8 + aiStack_3c[0]) = fStack_1c;
        uStack_18 = uStack_18 + 0xc;
        uVar1 = uVar1 - 1;
      } while (uVar1 != 0);
    }
    FUN_00a92d50(aiStack_3c,0);
    FUN_00617ad0();
    ExceptionList = pvStack_10;
    return param_2;
  }
  FUN_0054eff0("Number sequence is too big");
  uStack_8 = 0;
  FUN_005f8ef0(auStack_30);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_60,&DAT_01c27108);
}



/* FUNCTION 8698 ; VA 0x006ac700 ; FUN_006ac700 */

undefined8 * FUN_006ac700(undefined8 *param_1)

{
  undefined4 uVar1;
  float10 fVar2;
  float10 fVar3;
  float10 fVar4;
  
  FUN_00aa1120();
  fVar2 = (float10)FUN_006ac3c0();
  fVar3 = (float10)FUN_006ac3c0();
  fVar4 = (float10)FUN_006ac3c0();
  *param_1 = CONCAT44((float)fVar3,(float)fVar2);
  *(float *)(param_1 + 1) = (float)fVar4;
  uVar1 = FUN_006ac4d0();
  *(undefined4 *)((int)param_1 + 0xc) = uVar1;
  return param_1;
}



/* FUNCTION 8699 ; VA 0x006ac760 ; FUN_006ac760 */

undefined * __thiscall FUN_006ac760(undefined4 param_1,undefined *param_2)

{
  undefined *puVar1;
  float10 fVar2;
  float10 fVar3;
  float10 fVar4;
  float10 fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  
  puVar1 = param_2;
  FUN_00607ba0(param_1,(int)&param_2 + 3);
  if (param_2._3_1_ != '\0') {
    fVar2 = (float10)FUN_006ac3c0();
    param_2 = (undefined *)(float)fVar2;
    fVar2 = (float10)FUN_006ac3c0();
    fVar3 = (float10)FUN_006ac3c0();
    fVar4 = (float10)FUN_006ac3c0();
    fVar5 = (float10)FUN_006ac3c0();
    fVar9 = DAT_018ce320;
    fVar7 = DAT_018daf54;
    if (DAT_018daf54 <= (float)param_2) {
      fVar7 = (float)param_2;
    }
    *puVar1 = 1;
    fVar8 = 0.0;
    if (0.0 <= (float)fVar5) {
      fVar8 = (float)fVar5;
    }
    fVar6 = fVar9;
    if (fVar7 <= fVar9) {
      fVar6 = fVar7;
    }
    fVar7 = 0.0;
    if (0.0 <= (float)fVar3) {
      fVar7 = (float)fVar3;
    }
    *(float *)(puVar1 + 4) = fVar6;
    fVar6 = DAT_018ce2f8;
    if (fVar7 <= DAT_018ce2f8) {
      fVar6 = fVar7;
    }
    fVar7 = 0.0;
    if (0.0 <= (float)fVar2) {
      fVar7 = (float)fVar2;
    }
    *(float *)(puVar1 + 8) = fVar6;
    fVar6 = DAT_018daf58;
    if (fVar7 <= DAT_018daf58) {
      fVar6 = fVar7;
    }
    fVar7 = 0.0;
    if (0.0 <= (float)fVar4) {
      fVar7 = (float)fVar4;
    }
    *(float *)(puVar1 + 0xc) = fVar6;
    fVar6 = fVar9;
    if (fVar7 <= fVar9) {
      fVar6 = fVar7;
    }
    if (fVar8 <= fVar9) {
      fVar9 = fVar8;
    }
    *(float *)(puVar1 + 0x10) = fVar6;
    *(float *)(puVar1 + 0x14) = fVar9;
    return puVar1;
  }
  *puVar1 = 0;
  *(undefined4 *)(puVar1 + 4) = 0;
  *(undefined4 *)(puVar1 + 8) = 0;
  *(undefined4 *)(puVar1 + 0xc) = 0;
  *(undefined4 *)(puVar1 + 0x10) = 0;
  *(undefined4 *)(puVar1 + 0x14) = 0;
  return puVar1;
}



/* FUNCTION 8700 ; VA 0x006ac870 ; FUN_006ac870 */

undefined4 __fastcall FUN_006ac870(int param_1)

{
  uint uVar1;
  undefined2 uVar2;
  int iVar3;
  undefined2 uStack_8;
  
  uVar1 = *(int *)(param_1 + 0x20) + 2;
  if (*(uint *)(param_1 + 0x18) < uVar1) {
    return 0;
  }
  uVar2 = *(undefined2 *)(*(int *)(param_1 + 8) + *(int *)(param_1 + 0x20));
  uStack_8 = CONCAT11((char)uVar2,(char)((ushort)uVar2 >> 8));
  *(uint *)(param_1 + 0x20) = uVar1;
  if (uStack_8 != 0) {
    uVar1 = (uint)uStack_8;
    iVar3 = FUN_01674e20(uVar1 + 1);
    if (*(uint *)(param_1 + 0x18) < *(int *)(param_1 + 0x20) + uVar1) {
      thunk_FUN_0071e4a0();
      FUN_01674ea0(iVar3);
      return 0;
    }
    FUN_0170c6f0(iVar3,*(int *)(param_1 + 8) + *(int *)(param_1 + 0x20),uVar1);
    *(int *)(param_1 + 0x20) = *(int *)(param_1 + 0x20) + uVar1;
    *(undefined *)((uint)uStack_8 + iVar3) = 0;
    FUN_0071e130(iVar3);
    FUN_01674ea0(iVar3);
  }
  return 1;
}



/* FUNCTION 8701 ; VA 0x006ac930 ; FUN_006ac930 */

undefined8 * FUN_006ac930(undefined8 *param_1)

{
  float10 fVar1;
  float10 fVar2;
  float10 fVar3;
  
  *(undefined4 *)param_1 = 0;
  *(undefined4 *)((int)param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 1) = 0;
  *(undefined4 *)((int)param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  *(undefined4 *)((int)param_1 + 0x14) = 0;
  fVar1 = (float10)FUN_006ac3c0();
  fVar2 = (float10)FUN_006ac3c0();
  fVar3 = (float10)FUN_006ac3c0();
  *param_1 = CONCAT44((float)fVar2,(float)fVar1);
  *(float *)(param_1 + 1) = (float)fVar3;
  fVar1 = (float10)FUN_006ac3c0();
  fVar2 = (float10)FUN_006ac3c0();
  fVar3 = (float10)FUN_006ac3c0();
  *(ulonglong *)((int)param_1 + 0xc) = CONCAT44((float)fVar2,(float)fVar1);
  *(float *)((int)param_1 + 0x14) = (float)fVar3;
  return param_1;
}



/* FUNCTION 8702 ; VA 0x006ac9d0 ; FUN_006ac9d0 */

void FUN_006ac9d0(float *param_1)

{
  float fVar1;
  float fVar2;
  float10 fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  
  fVar3 = (float10)FUN_006ac3c0();
  fVar4 = (float)fVar3;
  fVar3 = (float10)FUN_006ac3c0();
  fVar5 = (float)fVar3;
  fVar3 = (float10)FUN_006ac3c0();
  fVar1 = (float)fVar3;
  fVar3 = (float10)FUN_006ac3c0();
  fVar2 = (float)fVar3;
  fVar6 = fVar2;
  if (fVar5 < fVar2) {
    fVar6 = fVar5;
  }
  fVar7 = fVar1;
  if (fVar4 < fVar1) {
    fVar7 = fVar4;
  }
  *param_1 = fVar7;
  param_1[1] = fVar6;
  if (fVar5 <= fVar2) {
    fVar5 = fVar2;
  }
  if (fVar4 <= fVar1) {
    fVar4 = fVar1;
  }
  param_1[2] = fVar4;
  param_1[3] = fVar5;
  return;
}



/* FUNCTION 8703 ; VA 0x006aca60 ; FUN_006aca60 */

undefined4 FUN_006aca60(undefined4 param_1)

{
  float10 fVar1;
  undefined8 uStack_34;
  float fStack_2c;
  undefined8 uStack_28;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  fVar1 = (float10)FUN_006ac3c0();
  fStack_10 = (float)fVar1;
  fVar1 = (float10)FUN_006ac3c0();
  fStack_c = (float)fVar1;
  fVar1 = (float10)FUN_006ac3c0();
  fStack_8 = (float)fVar1;
  fVar1 = (float10)FUN_006ac3c0();
  fStack_1c = (float)fVar1;
  fVar1 = (float10)FUN_006ac3c0();
  fStack_18 = (float)fVar1;
  fVar1 = (float10)FUN_006ac3c0();
  uStack_34 = CONCAT44(fStack_c,fStack_10);
  fStack_2c = fStack_8;
  fStack_20 = (float)fVar1;
  uStack_28 = CONCAT44(fStack_18,fStack_1c);
  fStack_14 = fStack_20;
  FUN_00a731b0(&uStack_34);
  return param_1;
}



/* FUNCTION 8704 ; VA 0x006acae0 ; FUN_006acae0 */

void FUN_006acae0(undefined4 *param_1)

{
  undefined2 uVar1;
  undefined2 uVar2;
  undefined2 uVar3;
  undefined4 uStack_10;
  undefined4 uStack_a;
  
  uVar1 = FUN_006ac450();
  uVar2 = FUN_006ac450();
  uStack_a = CONCAT22(uVar2,uVar1);
  uVar1 = FUN_006ac450();
  uVar2 = FUN_006ac450();
  uVar3 = FUN_006ac450();
  uStack_10 = CONCAT22(uVar3,uVar2);
  uVar2 = FUN_006ac450();
  *param_1 = uStack_a;
  *(undefined2 *)(param_1 + 1) = uVar1;
  *(undefined4 *)((int)param_1 + 6) = uStack_10;
  *(undefined2 *)((int)param_1 + 10) = uVar2;
  return;
}



/* FUNCTION 8705 ; VA 0x006acb50 ; FUN_006acb50 */

void __thiscall FUN_006acb50(undefined4 param_1,undefined8 *param_2)

{
  char cVar1;
  int iVar2;
  int iStack_14;
  int iStack_10;
  char cStack_5;
  
  FUN_00607ba0(param_1,&cStack_5);
  if (cStack_5 == '\0') {
    cVar1 = FUN_006ac560();
    iStack_14 = (int)cVar1;
    cVar1 = FUN_006ac560();
    iStack_10 = (int)cVar1;
    cVar1 = FUN_006ac560();
    iVar2 = (int)cVar1;
  }
  else {
    iStack_14 = FUN_006ac4d0();
    iStack_10 = FUN_006ac4d0();
    iVar2 = FUN_006ac4d0();
  }
  *param_2 = CONCAT44(iStack_10,iStack_14);
  *(int *)(param_2 + 1) = iVar2;
  return;
}



/* FUNCTION 8706 ; VA 0x006acbd0 ; FUN_006acbd0 */

undefined4 * __thiscall FUN_006acbd0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_90 [36];
  undefined auStack_6c [36];
  undefined auStack_48 [24];
  undefined auStack_30 [24];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a66d9;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  FUN_006ab0b0(param_1,&uStack_14);
  if ((uint)(*(int *)(param_1 + 0x18) - *(int *)(param_1 + 0x20)) < uStack_14) {
    iVar2 = FUN_00615980();
    uVar3 = FUN_01675640(auStack_30,"BitStream >> String: String too long by: %u",uStack_14 - iVar2)
    ;
    uStack_8 = 1;
    FUN_005f8ef0(uVar3);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_6c,&DAT_01c27108);
  }
  if (uStack_14 <= DAT_01d5b348) {
    param_2[4] = 0;
    param_2[5] = 0xf;
    *(undefined *)param_2 = 0;
    uStack_8 = 0;
    uStack_18 = 1;
    if ((uint)param_2[4] < uStack_14) {
      FUN_00578160(uStack_14 - param_2[4],0);
    }
    else {
      puVar1 = param_2;
      if (0xf < (uint)param_2[5]) {
        puVar1 = (undefined4 *)*param_2;
      }
      param_2[4] = uStack_14;
      *(undefined *)((int)puVar1 + uStack_14) = 0;
    }
    if (uStack_14 != 0) {
      puVar1 = param_2;
      if (0xf < (uint)param_2[5]) {
        puVar1 = (undefined4 *)*param_2;
      }
      FUN_006abe60(puVar1,uStack_14);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  uVar3 = FUN_01675640(auStack_48,"BitStream >> String: String too long: %u",uStack_14);
  uStack_8 = 2;
  FUN_005f8ef0(uVar3);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_90,&DAT_01c27108);
}



/* FUNCTION 8707 ; VA 0x006acd20 ; FUN_006acd20 */

float * FUN_006acd20(float *param_1)

{
  float fVar1;
  float10 fVar2;
  
  *param_1 = 0.0;
  param_1[1] = 0.0;
  param_1[2] = 0.0;
  param_1[3] = 0.0;
  fVar2 = (float10)FUN_006ac3c0();
  fVar1 = (float)FUN_006ac4d0();
  *param_1 = (float)fVar2;
  param_1[1] = fVar1;
  fVar2 = (float10)FUN_006ac3c0();
  fVar1 = (float)FUN_006ac4d0();
  param_1[3] = fVar1;
  param_1[2] = (float)fVar2;
  return param_1;
}



/* FUNCTION 8708 ; VA 0x006acd90 ; FUN_006acd90 */

float * FUN_006acd90(float *param_1)

{
  float fVar1;
  float10 fVar2;
  
  *param_1 = 0.0;
  param_1[1] = 0.0;
  fVar2 = (float10)FUN_006ac3c0();
  *param_1 = (float)fVar2;
  fVar1 = (float)FUN_006ac4d0();
  param_1[1] = fVar1;
  return param_1;
}



/* FUNCTION 8709 ; VA 0x006acdc0 ; FUN_006acdc0 */

void __fastcall FUN_006acdc0(int param_1)

{
  uint uVar1;
  undefined auStack_50 [36];
  undefined auStack_2c [28];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  uVar1 = *(int *)(param_1 + 0x20) + 2;
  if (uVar1 <= *(uint *)(param_1 + 0x18)) {
    *(uint *)(param_1 + 0x20) = uVar1;
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_0054eff0("readFast past end for uint16_t");
  uStack_8 = 0;
  FUN_005f8ef0(auStack_2c);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_50,&DAT_01c27108);
}



/* FUNCTION 8710 ; VA 0x006ace40 ; FUN_006ace40 */

undefined4 __fastcall FUN_006ace40(undefined4 param_1)

{
  undefined4 uStack_8;
  
  uStack_8 = param_1;
  FUN_006ab0b0(param_1,&uStack_8);
  return uStack_8;
}



/* FUNCTION 8711 ; VA 0x006ace60 ; FUN_006ace60 */

undefined8 __fastcall FUN_006ace60(int param_1)

{
  undefined8 uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  undefined auStack_54 [36];
  undefined auStack_30 [24];
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  uVar2 = *(int *)(param_1 + 0x20) + 8;
  if (uVar2 <= *(uint *)(param_1 + 0x18)) {
    uVar1 = *(undefined8 *)(*(int *)(param_1 + 8) + *(int *)(param_1 + 0x20));
    *(uint *)(param_1 + 0x20) = uVar2;
    uStack_18 = (uint)uVar1;
    uStack_14 = (uint)((ulonglong)uVar1 >> 0x20);
    uVar4 = uStack_14 << 0x10;
    uVar2 = (uStack_18 ^ uStack_14) >> 0x10 ^ (uStack_18 << 0x10 | uStack_14 >> 0x10);
    uVar3 = uStack_14 >> 0x10 ^ uVar4;
    return CONCAT44((uVar2 >> 8 ^ (uVar2 << 8 | uVar4 >> 0x18)) & 0xff00ff ^
                    (uVar2 << 8 | uVar4 >> 0x18),(uVar3 >> 8 ^ uVar3 << 8) & 0xff00ff ^ uVar3 << 8);
  }
  ExceptionList = &pvStack_10;
  FUN_0054eff0("readFast past end for uint64_t");
  uStack_8 = 0;
  FUN_005f8ef0(auStack_30);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_54,&DAT_01c27108);
}



/* FUNCTION 8712 ; VA 0x006acf50 ; FUN_006acf50 */

undefined4 * FUN_006acf50(undefined4 *param_1)

{
  undefined2 uVar1;
  
  *param_1 = 0;
  uVar1 = FUN_006ac450();
  *(undefined2 *)param_1 = uVar1;
  uVar1 = FUN_006ac450();
  *(undefined2 *)((int)param_1 + 2) = uVar1;
  return param_1;
}



/* FUNCTION 8713 ; VA 0x006acf80 ; FUN_006acf80 */

undefined4 * FUN_006acf80(undefined4 *param_1)

{
  undefined2 uVar1;
  
  *param_1 = 0;
  *(undefined2 *)(param_1 + 1) = 0;
  uVar1 = FUN_006ac450();
  *(undefined2 *)param_1 = uVar1;
  uVar1 = FUN_006ac450();
  *(undefined2 *)((int)param_1 + 2) = uVar1;
  uVar1 = FUN_006ac450();
  *(undefined2 *)(param_1 + 1) = uVar1;
  return param_1;
}



/* FUNCTION 8714 ; VA 0x006acfc0 ; FUN_006acfc0 */

void FUN_006acfc0(undefined4 *param_1,int param_2)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  int iStack_c;
  int iStack_8;
  
  iVar3 = param_2;
  uStack_40 = *param_1;
  uStack_3c = param_1[1];
  uStack_38 = param_1[2];
  uStack_34 = param_1[3];
  uStack_30 = param_1[4];
  uStack_2c = param_1[5];
  uStack_28 = param_1[6];
  uStack_24 = param_1[7];
  uStack_20 = param_1[8];
  uStack_1c = param_1[9];
  uStack_18 = param_1[10];
  uStack_14 = param_1[0xb];
  FUN_006abc90(&uStack_40);
  piVar1 = (int *)(param_2 + 0xc);
  iVar7 = *(int *)(param_2 + 0x18);
  uVar2 = iVar7 + 4;
  param_2._0_2_ = CONCAT11((char)((uint)uStack_1c >> 0x10),(char)((uint)uStack_1c >> 0x18));
  param_2._0_3_ = CONCAT12((char)((uint)uStack_1c >> 8),(undefined2)param_2);
  param_2 = CONCAT13((char)uStack_1c,(undefined3)param_2);
  if (*(uint *)(iVar3 + 0x1c) < uVar2) {
    FUN_0055b6c0(uVar2,piVar1);
    iVar7 = *(int *)(iVar3 + 0x18);
    *(uint *)(iVar3 + 0x1c) = uVar2;
    iVar5 = *piVar1;
    *(int *)(iVar3 + 8) = iVar5;
  }
  else {
    iVar5 = *(int *)(iVar3 + 8);
  }
  *(int *)(iVar5 + iVar7) = param_2;
  iVar7 = *(int *)(iVar3 + 0x18) + 4;
  uVar2 = *(int *)(iVar3 + 0x18) + 8;
  param_2._0_2_ = CONCAT11((char)((uint)uStack_18 >> 0x10),(char)((uint)uStack_18 >> 0x18));
  *(int *)(iVar3 + 0x18) = iVar7;
  param_2._0_3_ = CONCAT12((char)((uint)uStack_18 >> 8),(undefined2)param_2);
  param_2 = CONCAT13((char)uStack_18,(undefined3)param_2);
  if (*(uint *)(iVar3 + 0x1c) < uVar2) {
    FUN_0055b6c0(uVar2,piVar1);
    iVar7 = *(int *)(iVar3 + 0x18);
    *(uint *)(iVar3 + 0x1c) = uVar2;
    iVar5 = *piVar1;
    *(int *)(iVar3 + 8) = iVar5;
  }
  else {
    iVar5 = *(int *)(iVar3 + 8);
  }
  *(int *)(iVar5 + iVar7) = param_2;
  iVar7 = *(int *)(iVar3 + 0x18) + 4;
  uVar2 = *(int *)(iVar3 + 0x18) + 8;
  param_2._0_2_ = CONCAT11((char)((uint)uStack_14 >> 0x10),(char)((uint)uStack_14 >> 0x18));
  *(int *)(iVar3 + 0x18) = iVar7;
  param_2._0_3_ = CONCAT12((char)((uint)uStack_14 >> 8),(undefined2)param_2);
  param_2 = CONCAT13((char)uStack_14,(undefined3)param_2);
  if (*(uint *)(iVar3 + 0x1c) < uVar2) {
    FUN_0055b6c0(uVar2,piVar1);
    iVar7 = *(int *)(iVar3 + 0x18);
    *(uint *)(iVar3 + 0x1c) = uVar2;
    iVar5 = *piVar1;
    *(int *)(iVar3 + 8) = iVar5;
  }
  else {
    iVar5 = *(int *)(iVar3 + 8);
  }
  *(int *)(iVar5 + iVar7) = param_2;
  *(int *)(iVar3 + 0x18) = *(int *)(iVar3 + 0x18) + 4;
  cVar4 = FUN_00c94220(&uStack_40);
  if (cVar4 != '\0') {
    cVar4 = FUN_00c938f0(&uStack_40);
    uVar2 = *(int *)(iVar3 + 0x18) + 1;
    if (*(uint *)(iVar3 + 0x1c) < uVar2) {
      FUN_0055b6c0(uVar2,piVar1);
      *(uint *)(iVar3 + 0x1c) = uVar2;
      iVar7 = *piVar1;
      *(int *)(iVar3 + 8) = iVar7;
      *(char *)(iVar7 + *(int *)(iVar3 + 0x18)) = cVar4 + '\x01';
      *(int *)(iVar3 + 0x18) = *(int *)(iVar3 + 0x18) + 1;
      return;
    }
    *(char *)(*(int *)(iVar3 + 8) + *(int *)(iVar3 + 0x18)) = cVar4 + '\x01';
    *(int *)(iVar3 + 0x18) = *(int *)(iVar3 + 0x18) + 1;
    return;
  }
  iVar7 = *(int *)(iVar3 + 0x18);
  uVar2 = iVar7 + 1;
  if (*(uint *)(iVar3 + 0x1c) < uVar2) {
    FUN_0055b6c0(uVar2,piVar1);
    iVar7 = *(int *)(iVar3 + 0x18);
    *(uint *)(iVar3 + 0x1c) = uVar2;
    iVar5 = *piVar1;
    *(int *)(iVar3 + 8) = iVar5;
  }
  else {
    iVar5 = *(int *)(iVar3 + 8);
  }
  *(undefined *)(iVar5 + iVar7) = 0;
  puVar6 = &uStack_40;
  *(int *)(iVar3 + 0x18) = *(int *)(iVar3 + 0x18) + 1;
  iVar7 = *(int *)(iVar3 + 0x18);
  iStack_c = 3;
  do {
    iStack_8 = 3;
    do {
      uStack_10 = *puVar6;
      uVar2 = iVar7 + 4;
      param_2._0_2_ = CONCAT11((char)((uint)uStack_10 >> 0x10),(char)((uint)uStack_10 >> 0x18));
      param_2._0_3_ = CONCAT12((char)((uint)uStack_10 >> 8),(undefined2)param_2);
      param_2 = CONCAT13((char)uStack_10,(undefined3)param_2);
      if (*(uint *)(iVar3 + 0x1c) < uVar2) {
        FUN_0055b6c0(uVar2,piVar1);
        *(uint *)(iVar3 + 0x1c) = uVar2;
        *(int *)(iVar3 + 8) = *piVar1;
      }
      *(int *)(*(int *)(iVar3 + 0x18) + *(int *)(iVar3 + 8)) = param_2;
      iVar7 = *(int *)(iVar3 + 0x18) + 4;
      puVar6 = puVar6 + 1;
      *(int *)(iVar3 + 0x18) = iVar7;
      iStack_8 = iStack_8 + -1;
    } while (iStack_8 != 0);
    iStack_c = iStack_c + -1;
  } while (iStack_c != 0);
  return;
}



/* FUNCTION 8715 ; VA 0x006ad220 ; FUN_006ad220 */

void FUN_006ad220(undefined4 param_1,int param_2,int *param_3)

{
  int iVar1;
  
  iVar1 = *param_3;
  if (*param_3 == 0) {
    iVar1 = param_2;
  }
  FUN_006ad430(iVar1,0,param_1);
  return;
}



/* FUNCTION 8716 ; VA 0x006ad240 ; FUN_006ad240 */

void FUN_006ad240(undefined4 *param_1,int param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  undefined auStack_50 [36];
  undefined auStack_2c [24];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  uVar1 = param_1[1];
  if (uVar1 <= DAT_01d5b348) {
    ExceptionList = &pvStack_10;
    FUN_006ad430(uVar1,0,param_2);
    iVar2 = param_1[1];
    uStack_14 = *param_1;
    if (iVar2 != 0) {
      iVar5 = *(int *)(param_2 + 0x18);
      uVar1 = iVar5 + iVar2;
      if (*(uint *)(param_2 + 0x1c) < uVar1) {
        FUN_0055b6c0(uVar1,(int *)(param_2 + 0xc));
        iVar5 = *(int *)(param_2 + 0x18);
        *(uint *)(param_2 + 0x1c) = uVar1;
        iVar3 = *(int *)(param_2 + 0xc);
        *(int *)(param_2 + 8) = iVar3;
      }
      else {
        iVar3 = *(int *)(param_2 + 8);
      }
      FUN_0170c6f0(iVar3 + iVar5,uStack_14,iVar2);
      *(int *)(param_2 + 0x18) = *(int *)(param_2 + 0x18) + iVar2;
    }
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675640(auStack_2c,"BitStream string write: String too long: %u",uVar1);
  uStack_8 = 0;
  FUN_005f8ef0(uVar4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_50,&DAT_01c27108);
}



/* FUNCTION 8717 ; VA 0x006ad310 ; FUN_006ad310 */

void FUN_006ad310(uint param_1,int param_2,undefined4 param_3)

{
  FUN_006ad430(param_2 >> 0x1f ^ param_1 * 2,param_2 >> 0x1f ^ (param_2 << 1 | param_1 >> 0x1f),
               param_3);
  return;
}



/* FUNCTION 8718 ; VA 0x006ad340 ; FUN_006ad340 */

void FUN_006ad340(int param_1,undefined4 param_2)

{
  FUN_006ad430(param_1 >> 0x1f ^ param_1 * 2,0,param_2);
  return;
}



/* FUNCTION 8719 ; VA 0x006ad360 ; FUN_006ad360 */

void FUN_006ad360(undefined4 *param_1,int param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  undefined auStack_50 [36];
  undefined auStack_2c [24];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  uVar1 = param_1[4];
  if (uVar1 <= DAT_01d5b348) {
    ExceptionList = &pvStack_10;
    FUN_006ad430(uVar1,0,param_2);
    iStack_14 = param_1[4];
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    if (iStack_14 != 0) {
      iVar5 = *(int *)(param_2 + 0x18);
      uVar1 = iVar5 + iStack_14;
      if (*(uint *)(param_2 + 0x1c) < uVar1) {
        FUN_0055b6c0(uVar1,(int *)(param_2 + 0xc));
        iVar5 = *(int *)(param_2 + 0x18);
        *(uint *)(param_2 + 0x1c) = uVar1;
        iVar3 = *(int *)(param_2 + 0xc);
        *(int *)(param_2 + 8) = iVar3;
      }
      else {
        iVar3 = *(int *)(param_2 + 8);
      }
      iVar2 = iStack_14;
      FUN_0170c6f0(iVar3 + iVar5,param_1,iStack_14);
      *(int *)(param_2 + 0x18) = *(int *)(param_2 + 0x18) + iVar2;
    }
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675640(auStack_2c,"BitStream string write: String too long: %u",uVar1);
  uStack_8 = 0;
  FUN_005f8ef0(uVar4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_50,&DAT_01c27108);
}



/* FUNCTION 8720 ; VA 0x006ad430 ; FUN_006ad430 */

void FUN_006ad430(uint param_1,uint param_2,int param_3)

{
  uint uVar1;
  bool bVar2;
  byte bVar3;
  uint uVar4;
  int iStack_c;
  
  bVar2 = true;
  iStack_c = 0;
  do {
    if ((!bVar2) && (param_1 == 0 && param_2 == 0)) {
      return;
    }
    uVar1 = param_2 << 0x19;
    bVar3 = (byte)param_1 & 0x7f;
    if ((param_2 != 0) || (0x7f < param_1)) {
      bVar3 = bVar3 | 0x80;
    }
    uVar4 = *(int *)(param_3 + 0x18) + 1;
    if (*(uint *)(param_3 + 0x1c) < uVar4) {
      FUN_0055b6c0(uVar4,(undefined4 *)(param_3 + 0xc));
      *(uint *)(param_3 + 0x1c) = uVar4;
      *(undefined4 *)(param_3 + 8) = *(undefined4 *)(param_3 + 0xc);
    }
    bVar2 = false;
    *(byte *)(*(int *)(param_3 + 8) + *(int *)(param_3 + 0x18)) = bVar3;
    *(int *)(param_3 + 0x18) = *(int *)(param_3 + 0x18) + 1;
    iStack_c = iStack_c + 1;
    param_2 = param_2 >> 7;
    param_1 = param_1 >> 7 | uVar1;
  } while (iStack_c < 10);
  return;
}



/* FUNCTION 8721 ; VA 0x006ad4e0 ; FUN_006ad4e0 */

void FUN_006ad4e0(undefined4 param_1,undefined4 param_2)

{
  FUN_006ad430(param_1,0,param_2);
  return;
}



/* FUNCTION 8722 ; VA 0x006ad500 ; FUN_006ad500 */

void __thiscall FUN_006ad500(int param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  
  uVar2 = *param_2;
  param_2 = (undefined4 *)
            CONCAT13((char)uVar2,
                     CONCAT12((char)((uint)uVar2 >> 8),
                              CONCAT11((char)((uint)uVar2 >> 0x10),(char)((uint)uVar2 >> 0x18))));
  uVar1 = *(int *)(param_1 + 0x18) + 4;
  if (*(uint *)(param_1 + 0x1c) < uVar1) {
    FUN_0055b6c0(uVar1,(int *)(param_1 + 0xc));
    *(uint *)(param_1 + 0x1c) = uVar1;
    iVar3 = *(int *)(param_1 + 0xc);
    *(int *)(param_1 + 8) = iVar3;
    *(undefined4 **)(iVar3 + *(int *)(param_1 + 0x18)) = param_2;
    *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
    return;
  }
  *(undefined4 **)(*(int *)(param_1 + 8) + *(int *)(param_1 + 0x18)) = param_2;
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
  return;
}



/* FUNCTION 8723 ; VA 0x006ad570 ; FUN_006ad570 */

void __thiscall FUN_006ad570(int param_1,undefined2 *param_2)

{
  uint uVar1;
  int iVar2;
  undefined2 uVar3;
  
  uVar3 = CONCAT11((char)*param_2,(char)((ushort)*param_2 >> 8));
  uVar1 = *(int *)(param_1 + 0x18) + 2;
  if (*(uint *)(param_1 + 0x1c) < uVar1) {
    FUN_0055b6c0(uVar1,(int *)(param_1 + 0xc));
    *(uint *)(param_1 + 0x1c) = uVar1;
    iVar2 = *(int *)(param_1 + 0xc);
    *(int *)(param_1 + 8) = iVar2;
    *(undefined2 *)(iVar2 + *(int *)(param_1 + 0x18)) = uVar3;
    *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 2;
    return;
  }
  *(undefined2 *)(*(int *)(param_1 + 8) + *(int *)(param_1 + 0x18)) = uVar3;
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 2;
  return;
}



/* FUNCTION 8724 ; VA 0x006ad5e0 ; FUN_006ad5e0 */

void __thiscall FUN_006ad5e0(int param_1,undefined4 param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  if (param_3 != 0) {
    iVar3 = *(int *)(param_1 + 0x18);
    uVar1 = iVar3 + param_3;
    if (*(uint *)(param_1 + 0x1c) < uVar1) {
      FUN_0055b6c0(uVar1,(int *)(param_1 + 0xc));
      iVar3 = *(int *)(param_1 + 0x18);
      *(uint *)(param_1 + 0x1c) = uVar1;
      iVar2 = *(int *)(param_1 + 0xc);
      *(int *)(param_1 + 8) = iVar2;
    }
    else {
      iVar2 = *(int *)(param_1 + 8);
    }
    FUN_0170c6f0(iVar2 + iVar3,param_2,param_3);
    *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + param_3;
  }
  return;
}



/* FUNCTION 8725 ; VA 0x006ad640 ; FUN_006ad640 */

void __thiscall FUN_006ad640(int param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  undefined4 uStack_8;
  
  uVar3 = *param_2;
  piVar1 = (int *)(param_1 + 0xc);
  uStack_8._0_2_ = CONCAT11((char)((uint)uVar3 >> 0x10),(char)((uint)uVar3 >> 0x18));
  iVar4 = *(int *)(param_1 + 0x18);
  uStack_8._0_3_ = CONCAT12((char)((uint)uVar3 >> 8),(undefined2)uStack_8);
  uStack_8 = CONCAT13((char)uVar3,(undefined3)uStack_8);
  uVar2 = iVar4 + 4;
  if (*(uint *)(param_1 + 0x1c) < uVar2) {
    FUN_0055b6c0(uVar2,piVar1);
    iVar4 = *(int *)(param_1 + 0x18);
    *(uint *)(param_1 + 0x1c) = uVar2;
    iVar5 = *piVar1;
    *(int *)(param_1 + 8) = iVar5;
  }
  else {
    iVar5 = *(int *)(param_1 + 8);
  }
  *(undefined4 *)(iVar5 + iVar4) = uStack_8;
  iVar4 = *(int *)(param_1 + 0x18);
  iVar5 = iVar4 + 4;
  *(int *)(param_1 + 0x18) = iVar5;
  uVar3 = param_2[1];
  uVar2 = iVar4 + 8;
  uStack_8._0_2_ = CONCAT11((char)((uint)uVar3 >> 0x10),(char)((uint)uVar3 >> 0x18));
  uStack_8._0_3_ = CONCAT12((char)((uint)uVar3 >> 8),(undefined2)uStack_8);
  uStack_8 = CONCAT13((char)uVar3,(undefined3)uStack_8);
  if (*(uint *)(param_1 + 0x1c) < uVar2) {
    FUN_0055b6c0(uVar2,piVar1);
    iVar5 = *(int *)(param_1 + 0x18);
    *(uint *)(param_1 + 0x1c) = uVar2;
    iVar4 = *piVar1;
    *(int *)(param_1 + 8) = iVar4;
  }
  else {
    iVar4 = *(int *)(param_1 + 8);
  }
  *(undefined4 *)(iVar4 + iVar5) = uStack_8;
  iVar4 = *(int *)(param_1 + 0x18);
  iVar5 = iVar4 + 4;
  *(int *)(param_1 + 0x18) = iVar5;
  uVar3 = param_2[2];
  uVar2 = iVar4 + 8;
  param_2._3_1_ = (undefined)uVar3;
  param_2._0_3_ =
       CONCAT12((char)((uint)uVar3 >> 8),
                CONCAT11((char)((uint)uVar3 >> 0x10),(char)((uint)uVar3 >> 0x18)));
  if (*(uint *)(param_1 + 0x1c) < uVar2) {
    FUN_0055b6c0(uVar2,piVar1);
    *(uint *)(param_1 + 0x1c) = uVar2;
    *(int *)(param_1 + 8) = *piVar1;
    *(undefined4 **)(*piVar1 + *(int *)(param_1 + 0x18)) = param_2;
    *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
    return;
  }
  *(undefined4 **)(*(int *)(param_1 + 8) + iVar5) = param_2;
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
  return;
}



/* FUNCTION 8726 ; VA 0x006ad780 ; FUN_006ad780 */

void __thiscall FUN_006ad780(int param_1,undefined *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined uVar3;
  int iVar4;
  int iVar5;
  
  uVar3 = *param_2;
  iVar5 = *(int *)(param_1 + 0x18);
  piVar1 = (int *)(param_1 + 0xc);
  uVar2 = iVar5 + 1;
  if (*(uint *)(param_1 + 0x1c) < uVar2) {
    FUN_0055b6c0(uVar2,piVar1);
    iVar5 = *(int *)(param_1 + 0x18);
    *(uint *)(param_1 + 0x1c) = uVar2;
    iVar4 = *piVar1;
    *(int *)(param_1 + 8) = iVar4;
  }
  else {
    iVar4 = *(int *)(param_1 + 8);
  }
  *(undefined *)(iVar5 + iVar4) = uVar3;
  iVar5 = *(int *)(param_1 + 0x18);
  iVar4 = iVar5 + 1;
  *(int *)(param_1 + 0x18) = iVar4;
  uVar3 = param_2[1];
  uVar2 = iVar5 + 2;
  if (*(uint *)(param_1 + 0x1c) < uVar2) {
    FUN_0055b6c0(uVar2,piVar1);
    iVar4 = *(int *)(param_1 + 0x18);
    *(uint *)(param_1 + 0x1c) = uVar2;
    iVar5 = *piVar1;
    *(int *)(param_1 + 8) = iVar5;
  }
  else {
    iVar5 = *(int *)(param_1 + 8);
  }
  *(undefined *)(iVar4 + iVar5) = uVar3;
  iVar5 = *(int *)(param_1 + 0x18);
  iVar4 = iVar5 + 1;
  *(int *)(param_1 + 0x18) = iVar4;
  uVar3 = param_2[2];
  uVar2 = iVar5 + 2;
  if (*(uint *)(param_1 + 0x1c) < uVar2) {
    FUN_0055b6c0(uVar2,piVar1);
    *(uint *)(param_1 + 0x1c) = uVar2;
    *(int *)(param_1 + 8) = *piVar1;
    *(undefined *)(*piVar1 + *(int *)(param_1 + 0x18)) = uVar3;
    *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 1;
    return;
  }
  *(undefined *)(*(int *)(param_1 + 8) + iVar4) = uVar3;
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 1;
  return;
}



/* FUNCTION 8727 ; VA 0x006ad850 ; FUN_006ad850 */

void __thiscall FUN_006ad850(int param_1,int *param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  int iVar5;
  int iStack_14;
  int iStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  iVar2 = (param_2[1] - *param_2) / 0x14;
  iVar5 = *(int *)(param_1 + 0x18);
  uVar4 = iVar5 + 4;
  uStack_8._0_2_ = CONCAT11((char)((uint)iVar2 >> 0x10),(char)((uint)iVar2 >> 0x18));
  uStack_8._3_1_ = (undefined)iVar2;
  uStack_8._0_3_ = CONCAT12((char)((uint)iVar2 >> 8),(undefined2)uStack_8);
  if (*(uint *)(param_1 + 0x1c) < uVar4) {
    FUN_0055b6c0(uVar4,(int *)(param_1 + 0xc));
    iVar5 = *(int *)(param_1 + 0x18);
    *(uint *)(param_1 + 0x1c) = uVar4;
    iVar2 = *(int *)(param_1 + 0xc);
    *(int *)(param_1 + 8) = iVar2;
  }
  else {
    iVar2 = *(int *)(param_1 + 8);
  }
  *(undefined4 *)(iVar2 + iVar5) = uStack_8;
  iVar5 = *(int *)(param_1 + 0x18) + 4;
  *(int *)(param_1 + 0x18) = iVar5;
  iStack_14 = (param_2[1] - *param_2) / 0x14;
  if (0 < iStack_14) {
    iStack_10 = 0;
    do {
      puVar3 = (undefined4 *)(*param_2 + iStack_10);
      uVar1 = *puVar3;
      uStack_8._0_2_ = CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18));
      uStack_8._0_3_ = CONCAT12((char)((uint)uVar1 >> 8),(undefined2)uStack_8);
      uVar4 = iVar5 + 4;
      uStack_8 = CONCAT13((char)uVar1,(undefined3)uStack_8);
      if (*(uint *)(param_1 + 0x1c) < uVar4) {
        FUN_0055b6c0(uVar4,(int *)(param_1 + 0xc));
        *(uint *)(param_1 + 0x1c) = uVar4;
        iVar2 = *(int *)(param_1 + 0xc);
        iVar5 = *(int *)(param_1 + 0x18);
        *(int *)(param_1 + 8) = iVar2;
      }
      else {
        iVar2 = *(int *)(param_1 + 8);
      }
      *(undefined4 *)(iVar2 + iVar5) = uStack_8;
      *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
      FUN_006ad640(puVar3 + 1);
      uVar1 = puVar3[4];
      uVar4 = *(int *)(param_1 + 0x18) + 4;
      uStack_c = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
      if (*(uint *)(param_1 + 0x1c) < uVar4) {
        FUN_0055b6c0(uVar4,(undefined4 *)(param_1 + 0xc));
        *(uint *)(param_1 + 0x1c) = uVar4;
        *(undefined4 *)(param_1 + 8) = *(undefined4 *)(param_1 + 0xc);
      }
      *(undefined4 *)(*(int *)(param_1 + 0x18) + *(int *)(param_1 + 8)) = uStack_c;
      *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
      iStack_10 = iStack_10 + 0x14;
      iStack_14 = iStack_14 + -1;
      iVar5 = *(int *)(param_1 + 0x18);
    } while (iStack_14 != 0);
  }
  return;
}



/* FUNCTION 8728 ; VA 0x006ad9e0 ; FUN_006ad9e0 */

void __thiscall FUN_006ad9e0(int param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  undefined4 uStack_8;
  
  uVar2 = *param_2;
  iVar4 = *(int *)(param_1 + 0x18);
  uStack_8 = CONCAT13((char)uVar2,
                      CONCAT12((char)((uint)uVar2 >> 8),
                               CONCAT11((char)((uint)uVar2 >> 0x10),(char)((uint)uVar2 >> 0x18))));
  uVar1 = iVar4 + 4;
  if (*(uint *)(param_1 + 0x1c) < uVar1) {
    FUN_0055b6c0(uVar1,(int *)(param_1 + 0xc));
    iVar4 = *(int *)(param_1 + 0x18);
    *(uint *)(param_1 + 0x1c) = uVar1;
    iVar3 = *(int *)(param_1 + 0xc);
    *(int *)(param_1 + 8) = iVar3;
  }
  else {
    iVar3 = *(int *)(param_1 + 8);
  }
  *(undefined4 *)(iVar3 + iVar4) = uStack_8;
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
  FUN_006ad640(param_2 + 1);
  uVar2 = param_2[4];
  uVar1 = *(int *)(param_1 + 0x18) + 4;
  param_2 = (undefined4 *)
            CONCAT13((char)uVar2,
                     CONCAT12((char)((uint)uVar2 >> 8),
                              CONCAT11((char)((uint)uVar2 >> 0x10),(char)((uint)uVar2 >> 0x18))));
  if (*(uint *)(param_1 + 0x1c) < uVar1) {
    FUN_0055b6c0(uVar1,(int *)(param_1 + 0xc));
    *(uint *)(param_1 + 0x1c) = uVar1;
    iVar4 = *(int *)(param_1 + 0xc);
    *(int *)(param_1 + 8) = iVar4;
    *(undefined4 **)(iVar4 + *(int *)(param_1 + 0x18)) = param_2;
    *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
    return;
  }
  *(undefined4 **)(*(int *)(param_1 + 8) + *(int *)(param_1 + 0x18)) = param_2;
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
  return;
}



/* FUNCTION 8729 ; VA 0x006adad0 ; FUN_006adad0 */

void __thiscall FUN_006adad0(int param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined uStack_5;
  
  uStack_3c = *param_2;
  uStack_38 = param_2[1];
  uStack_34 = param_2[2];
  uStack_30 = param_2[3];
  uStack_2c = param_2[4];
  uStack_28 = param_2[5];
  uStack_24 = param_2[6];
  uStack_20 = param_2[7];
  uStack_1c = param_2[8];
  uStack_18 = param_2[9];
  uStack_14 = param_2[10];
  uStack_10 = param_2[0xb];
  FUN_006abc90(&uStack_3c);
  piVar1 = (int *)(param_1 + 0xc);
  iVar5 = *(int *)(param_1 + 0x18);
  uVar2 = iVar5 + 4;
  uStack_c._0_2_ = CONCAT11((char)((uint)uStack_18 >> 0x10),(char)((uint)uStack_18 >> 0x18));
  uStack_c._0_3_ = CONCAT12((char)((uint)uStack_18 >> 8),(undefined2)uStack_c);
  uStack_c = CONCAT13((char)uStack_18,(undefined3)uStack_c);
  if (*(uint *)(param_1 + 0x1c) < uVar2) {
    FUN_0055b6c0(uVar2,piVar1);
    iVar5 = *(int *)(param_1 + 0x18);
    *(uint *)(param_1 + 0x1c) = uVar2;
    iVar4 = *piVar1;
    *(int *)(param_1 + 8) = iVar4;
  }
  else {
    iVar4 = *(int *)(param_1 + 8);
  }
  *(undefined4 *)(iVar4 + iVar5) = uStack_c;
  iVar5 = *(int *)(param_1 + 0x18) + 4;
  uVar2 = *(int *)(param_1 + 0x18) + 8;
  uStack_c._0_2_ = CONCAT11((char)((uint)uStack_14 >> 0x10),(char)((uint)uStack_14 >> 0x18));
  *(int *)(param_1 + 0x18) = iVar5;
  uStack_c._0_3_ = CONCAT12((char)((uint)uStack_14 >> 8),(undefined2)uStack_c);
  uStack_c = CONCAT13((char)uStack_14,(undefined3)uStack_c);
  if (*(uint *)(param_1 + 0x1c) < uVar2) {
    FUN_0055b6c0(uVar2,piVar1);
    iVar5 = *(int *)(param_1 + 0x18);
    *(uint *)(param_1 + 0x1c) = uVar2;
    iVar4 = *piVar1;
    *(int *)(param_1 + 8) = iVar4;
  }
  else {
    iVar4 = *(int *)(param_1 + 8);
  }
  *(undefined4 *)(iVar4 + iVar5) = uStack_c;
  iVar5 = *(int *)(param_1 + 0x18) + 4;
  uVar2 = *(int *)(param_1 + 0x18) + 8;
  uStack_c._0_2_ = CONCAT11((char)((uint)uStack_10 >> 0x10),(char)((uint)uStack_10 >> 0x18));
  *(int *)(param_1 + 0x18) = iVar5;
  uStack_c._0_3_ = CONCAT12((char)((uint)uStack_10 >> 8),(undefined2)uStack_c);
  uStack_c = CONCAT13((char)uStack_10,(undefined3)uStack_c);
  if (*(uint *)(param_1 + 0x1c) < uVar2) {
    FUN_0055b6c0(uVar2,piVar1);
    iVar5 = *(int *)(param_1 + 0x18);
    *(uint *)(param_1 + 0x1c) = uVar2;
    iVar4 = *piVar1;
    *(int *)(param_1 + 8) = iVar4;
  }
  else {
    iVar4 = *(int *)(param_1 + 8);
  }
  *(undefined4 *)(iVar4 + iVar5) = uStack_c;
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
  iVar4 = FUN_00c93940(&uStack_3c,0x358637bd);
  iVar5 = *(int *)(param_1 + 0x18);
  uVar2 = iVar5 + 1;
  if (-1 < iVar4) {
    cVar3 = (char)iVar4 + '\x01';
    if (*(uint *)(param_1 + 0x1c) < uVar2) {
      FUN_0055b6c0(uVar2,piVar1);
      *(uint *)(param_1 + 0x1c) = uVar2;
      *(int *)(param_1 + 8) = *piVar1;
      *(char *)(*piVar1 + *(int *)(param_1 + 0x18)) = cVar3;
      *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 1;
      return;
    }
    *(char *)(*(int *)(param_1 + 8) + iVar5) = cVar3;
    *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 1;
    return;
  }
  uStack_5 = 0;
  if (*(uint *)(param_1 + 0x1c) < uVar2) {
    FUN_0055b6c0(uVar2,piVar1);
    iVar5 = *(int *)(param_1 + 0x18);
    *(uint *)(param_1 + 0x1c) = uVar2;
    iVar4 = *piVar1;
    *(int *)(param_1 + 8) = iVar4;
  }
  else {
    iVar4 = *(int *)(param_1 + 8);
  }
  *(undefined *)(iVar4 + iVar5) = uStack_5;
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 1;
  FUN_00723280(param_1,param_2);
  return;
}



/* FUNCTION 8730 ; VA 0x006adcb0 ; FUN_006adcb0 */

void __fastcall FUN_006adcb0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  undefined8 uVar4;
  
  uVar4 = FUN_00b45ba0();
  iVar3 = *(int *)(param_1 + 0x18);
  uVar1 = iVar3 + 8;
  if (*(uint *)(param_1 + 0x1c) < uVar1) {
    FUN_0055b6c0(uVar1,(int *)(param_1 + 0xc));
    iVar3 = *(int *)(param_1 + 0x18);
    *(uint *)(param_1 + 0x1c) = uVar1;
    iVar2 = *(int *)(param_1 + 0xc);
    *(int *)(param_1 + 8) = iVar2;
  }
  else {
    iVar2 = *(int *)(param_1 + 8);
  }
  *(ulonglong *)(iVar2 + iVar3) =
       CONCAT17((char)uVar4,
                CONCAT16((char)((ulonglong)uVar4 >> 8),
                         CONCAT15((char)((ulonglong)uVar4 >> 0x10),
                                  CONCAT14((char)((ulonglong)uVar4 >> 0x18),
                                           CONCAT13((char)((ulonglong)uVar4 >> 0x20),
                                                    CONCAT12((char)((ulonglong)uVar4 >> 0x28),
                                                             CONCAT11((char)((ulonglong)uVar4 >>
                                                                            0x30),
                                                                      (char)((ulonglong)uVar4 >>
                                                                            0x38))))))));
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 8;
  return;
}



/* FUNCTION 8731 ; VA 0x006add40 ; FUN_006add40 */

void __thiscall FUN_006add40(int param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  iVar2 = param_2[8];
  iVar3 = (**(code **)(*param_2 + 4))();
  if (param_3 != 0) {
    iVar5 = *(int *)(param_1 + 0x18);
    uVar1 = iVar5 + param_3;
    if (*(uint *)(param_1 + 0x1c) < uVar1) {
      FUN_0055b6c0(uVar1,(int *)(param_1 + 0xc));
      iVar5 = *(int *)(param_1 + 0x18);
      *(uint *)(param_1 + 0x1c) = uVar1;
      iVar4 = *(int *)(param_1 + 0xc);
      *(int *)(param_1 + 8) = iVar4;
    }
    else {
      iVar4 = *(int *)(param_1 + 8);
    }
    FUN_0170c6f0(iVar4 + iVar5,iVar3 + iVar2,param_3);
    *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + param_3;
  }
  param_2[8] = iVar2 + param_3;
  return;
}



/* FUNCTION 8732 ; VA 0x006addc0 ; FUN_006addc0 */

void __thiscall FUN_006addc0(int param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  undefined4 uStack_8;
  
  uVar2 = *param_2;
  iVar3 = *(int *)(param_1 + 0x18);
  uStack_8 = CONCAT13((char)uVar2,
                      CONCAT12((char)((uint)uVar2 >> 8),
                               CONCAT11((char)((uint)uVar2 >> 0x10),(char)((uint)uVar2 >> 0x18))));
  uVar1 = iVar3 + 4;
  if (*(uint *)(param_1 + 0x1c) < uVar1) {
    FUN_0055b6c0(uVar1,(int *)(param_1 + 0xc));
    iVar3 = *(int *)(param_1 + 0x18);
    *(uint *)(param_1 + 0x1c) = uVar1;
    iVar4 = *(int *)(param_1 + 0xc);
    *(int *)(param_1 + 8) = iVar4;
  }
  else {
    iVar4 = *(int *)(param_1 + 8);
  }
  *(undefined4 *)(iVar4 + iVar3) = uStack_8;
  iVar3 = *(int *)(param_1 + 0x18);
  iVar4 = iVar3 + 4;
  *(int *)(param_1 + 0x18) = iVar4;
  uVar2 = param_2[1];
  uVar1 = iVar3 + 8;
  param_2._3_1_ = (undefined)uVar2;
  param_2._0_3_ =
       CONCAT12((char)((uint)uVar2 >> 8),
                CONCAT11((char)((uint)uVar2 >> 0x10),(char)((uint)uVar2 >> 0x18)));
  if (*(uint *)(param_1 + 0x1c) < uVar1) {
    FUN_0055b6c0(uVar1,(int *)(param_1 + 0xc));
    *(uint *)(param_1 + 0x1c) = uVar1;
    iVar3 = *(int *)(param_1 + 0xc);
    *(int *)(param_1 + 8) = iVar3;
    *(undefined4 **)(iVar3 + *(int *)(param_1 + 0x18)) = param_2;
    *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
    return;
  }
  *(undefined4 **)(*(int *)(param_1 + 8) + iVar4) = param_2;
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
  return;
}



/* FUNCTION 8733 ; VA 0x006adea0 ; FUN_006adea0 */

int __thiscall FUN_006adea0(int param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_8;
  
  iVar3 = (param_2[1] - *param_2) / 0xc;
  iVar1 = *(int *)(param_1 + 0x18);
  uStack_8._3_1_ = (undefined)iVar3;
  uStack_8._0_3_ =
       CONCAT12((char)((uint)iVar3 >> 8),
                CONCAT11((char)((uint)iVar3 >> 0x10),(char)((uint)iVar3 >> 0x18)));
  if (*(uint *)(param_1 + 0x1c) < iVar1 + 4U) {
    FUN_0055b6c0(iVar1 + 4U,(int *)(param_1 + 0xc));
    *(int *)(param_1 + 0x1c) = iVar1 + 4;
    iVar3 = *(int *)(param_1 + 0xc);
    *(int *)(param_1 + 8) = iVar3;
    iVar1 = *(int *)(param_1 + 0x18);
  }
  else {
    iVar3 = *(int *)(param_1 + 8);
  }
  *(undefined4 *)(iVar3 + iVar1) = uStack_8;
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
  iVar1 = (param_2[1] - *param_2) * 0x2aaaaaab;
  iVar3 = (param_2[1] - *param_2) / 0xc;
  if (0 < iVar3) {
    iVar2 = 0;
    do {
      iVar1 = FUN_006ad640(*param_2 + iVar2);
      iVar2 = iVar2 + 0xc;
      iVar3 = iVar3 + -1;
    } while (iVar3 != 0);
  }
  return iVar1;
}



/* FUNCTION 8734 ; VA 0x006adf60 ; FUN_006adf60 */

void __thiscall FUN_006adf60(int param_1,int param_2)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  
  FUN_006ad640(param_2);
  uVar2 = *(undefined4 *)(param_2 + 0xc);
  param_2 = CONCAT13((char)uVar2,
                     CONCAT12((char)((uint)uVar2 >> 8),
                              CONCAT11((char)((uint)uVar2 >> 0x10),(char)((uint)uVar2 >> 0x18))));
  uVar1 = *(int *)(param_1 + 0x18) + 4;
  if (*(uint *)(param_1 + 0x1c) < uVar1) {
    FUN_0055b6c0(uVar1,(int *)(param_1 + 0xc));
    *(uint *)(param_1 + 0x1c) = uVar1;
    iVar3 = *(int *)(param_1 + 0xc);
    *(int *)(param_1 + 8) = iVar3;
    *(int *)(iVar3 + *(int *)(param_1 + 0x18)) = param_2;
    *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
    return;
  }
  *(int *)(*(int *)(param_1 + 8) + *(int *)(param_1 + 0x18)) = param_2;
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
  return;
}



/* FUNCTION 8735 ; VA 0x006adfe0 ; FUN_006adfe0 */

void __thiscall FUN_006adfe0(int param_1,char *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  undefined4 uStack_c;
  
  cVar4 = *param_2;
  iVar5 = *(int *)(param_1 + 0x18);
  piVar1 = (int *)(param_1 + 0xc);
  uVar2 = iVar5 + 1;
  if (*(uint *)(param_1 + 0x1c) < uVar2) {
    FUN_0055b6c0(uVar2,piVar1);
    iVar5 = *(int *)(param_1 + 0x18);
    *(uint *)(param_1 + 0x1c) = uVar2;
    iVar6 = *piVar1;
    *(int *)(param_1 + 8) = iVar6;
  }
  else {
    iVar6 = *(int *)(param_1 + 8);
  }
  *(char *)(iVar6 + iVar5) = cVar4;
  iVar5 = *(int *)(param_1 + 0x18);
  iVar6 = iVar5 + 1;
  *(int *)(param_1 + 0x18) = iVar6;
  if (cVar4 != '\0') {
    uVar2 = iVar5 + 5;
    uVar3 = *(undefined4 *)(param_2 + 4);
    uStack_c._0_2_ = CONCAT11((char)((uint)uVar3 >> 0x10),(char)((uint)uVar3 >> 0x18));
    uStack_c._0_3_ = CONCAT12((char)((uint)uVar3 >> 8),(undefined2)uStack_c);
    uStack_c = CONCAT13((char)uVar3,(undefined3)uStack_c);
    if (*(uint *)(param_1 + 0x1c) < uVar2) {
      FUN_0055b6c0(uVar2,piVar1);
      iVar6 = *(int *)(param_1 + 0x18);
      *(uint *)(param_1 + 0x1c) = uVar2;
      iVar5 = *piVar1;
      *(int *)(param_1 + 8) = iVar5;
    }
    else {
      iVar5 = *(int *)(param_1 + 8);
    }
    *(undefined4 *)(iVar5 + iVar6) = uStack_c;
    iVar5 = *(int *)(param_1 + 0x18);
    iVar6 = iVar5 + 4;
    *(int *)(param_1 + 0x18) = iVar6;
    uVar3 = *(undefined4 *)(param_2 + 0xc);
    uVar2 = iVar5 + 8;
    uStack_c._0_2_ = CONCAT11((char)((uint)uVar3 >> 0x10),(char)((uint)uVar3 >> 0x18));
    uStack_c._0_3_ = CONCAT12((char)((uint)uVar3 >> 8),(undefined2)uStack_c);
    uStack_c = CONCAT13((char)uVar3,(undefined3)uStack_c);
    if (*(uint *)(param_1 + 0x1c) < uVar2) {
      FUN_0055b6c0(uVar2,piVar1);
      iVar6 = *(int *)(param_1 + 0x18);
      *(uint *)(param_1 + 0x1c) = uVar2;
      iVar5 = *piVar1;
      *(int *)(param_1 + 8) = iVar5;
    }
    else {
      iVar5 = *(int *)(param_1 + 8);
    }
    *(undefined4 *)(iVar5 + iVar6) = uStack_c;
    iVar5 = *(int *)(param_1 + 0x18);
    iVar6 = iVar5 + 4;
    *(int *)(param_1 + 0x18) = iVar6;
    uVar3 = *(undefined4 *)(param_2 + 8);
    uVar2 = iVar5 + 8;
    uStack_c._0_2_ = CONCAT11((char)((uint)uVar3 >> 0x10),(char)((uint)uVar3 >> 0x18));
    uStack_c._0_3_ = CONCAT12((char)((uint)uVar3 >> 8),(undefined2)uStack_c);
    uStack_c = CONCAT13((char)uVar3,(undefined3)uStack_c);
    if (*(uint *)(param_1 + 0x1c) < uVar2) {
      FUN_0055b6c0(uVar2,piVar1);
      iVar6 = *(int *)(param_1 + 0x18);
      *(uint *)(param_1 + 0x1c) = uVar2;
      iVar5 = *piVar1;
      *(int *)(param_1 + 8) = iVar5;
    }
    else {
      iVar5 = *(int *)(param_1 + 8);
    }
    *(undefined4 *)(iVar5 + iVar6) = uStack_c;
    iVar5 = *(int *)(param_1 + 0x18);
    iVar6 = iVar5 + 4;
    *(int *)(param_1 + 0x18) = iVar6;
    uVar3 = *(undefined4 *)(param_2 + 0x10);
    uVar2 = iVar5 + 8;
    uStack_c._0_2_ = CONCAT11((char)((uint)uVar3 >> 0x10),(char)((uint)uVar3 >> 0x18));
    uStack_c._0_3_ = CONCAT12((char)((uint)uVar3 >> 8),(undefined2)uStack_c);
    uStack_c = CONCAT13((char)uVar3,(undefined3)uStack_c);
    if (*(uint *)(param_1 + 0x1c) < uVar2) {
      FUN_0055b6c0(uVar2,piVar1);
      iVar6 = *(int *)(param_1 + 0x18);
      *(uint *)(param_1 + 0x1c) = uVar2;
      iVar5 = *piVar1;
      *(int *)(param_1 + 8) = iVar5;
    }
    else {
      iVar5 = *(int *)(param_1 + 8);
    }
    *(undefined4 *)(iVar5 + iVar6) = uStack_c;
    iVar5 = *(int *)(param_1 + 0x18);
    iVar6 = iVar5 + 4;
    *(int *)(param_1 + 0x18) = iVar6;
    uVar3 = *(undefined4 *)(param_2 + 0x14);
    uVar2 = iVar5 + 8;
    param_2._3_1_ = (undefined)uVar3;
    param_2._0_3_ =
         CONCAT12((char)((uint)uVar3 >> 8),
                  CONCAT11((char)((uint)uVar3 >> 0x10),(char)((uint)uVar3 >> 0x18)));
    if (*(uint *)(param_1 + 0x1c) < uVar2) {
      FUN_0055b6c0(uVar2,piVar1);
      *(uint *)(param_1 + 0x1c) = uVar2;
      *(int *)(param_1 + 8) = *piVar1;
      *(char **)(*piVar1 + *(int *)(param_1 + 0x18)) = param_2;
      *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
      return;
    }
    *(char **)(*(int *)(param_1 + 8) + iVar6) = param_2;
    *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
  }
  return;
}



/* FUNCTION 8736 ; VA 0x006ae210 ; FUN_006ae210 */

void __thiscall FUN_006ae210(int param_1,int *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  undefined2 uStack_8;
  
  uVar4 = FUN_0071e5b0();
  iVar6 = *(int *)(param_1 + 0x18);
  piVar1 = (int *)(param_1 + 0xc);
  uVar4 = uVar4 & 0xffff;
  uVar2 = iVar6 + 2;
  uStack_8 = CONCAT11((char)uVar4,(char)(uVar4 >> 8));
  if (*(uint *)(param_1 + 0x1c) < uVar2) {
    FUN_0055b6c0(uVar2,piVar1);
    iVar6 = *(int *)(param_1 + 0x18);
    *(uint *)(param_1 + 0x1c) = uVar2;
    iVar5 = *piVar1;
    *(int *)(param_1 + 8) = iVar5;
  }
  else {
    iVar5 = *(int *)(param_1 + 8);
  }
  *(undefined2 *)(iVar6 + iVar5) = uStack_8;
  iVar6 = *(int *)(param_1 + 0x18) + 2;
  *(int *)(param_1 + 0x18) = iVar6;
  uVar3 = *(undefined4 *)(*param_2 + 0x10);
  if (uVar4 != 0) {
    uVar2 = iVar6 + uVar4;
    if (*(uint *)(param_1 + 0x1c) < uVar2) {
      FUN_0055b6c0(uVar2,piVar1);
      iVar6 = *(int *)(param_1 + 0x18);
      *(uint *)(param_1 + 0x1c) = uVar2;
      iVar5 = *piVar1;
      *(int *)(param_1 + 8) = iVar5;
    }
    else {
      iVar5 = *(int *)(param_1 + 8);
    }
    FUN_0170c6f0(iVar5 + iVar6,uVar3,uVar4);
    *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + uVar4;
  }
  return;
}



/* FUNCTION 8737 ; VA 0x006ae2d0 ; FUN_006ae2d0 */

void FUN_006ae2d0(int param_1)

{
  FUN_006ad640(param_1);
  FUN_006ad640(param_1 + 0xc);
  return;
}



/* FUNCTION 8738 ; VA 0x006ae300 ; FUN_006ae300 */

void FUN_006ae300(undefined4 *param_1)

{
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_c = *param_1;
  uStack_8 = param_1[1];
  FUN_006addc0(&uStack_c);
  uStack_c = param_1[2];
  uStack_8 = param_1[3];
  FUN_006addc0(&uStack_c);
  return;
}



/* FUNCTION 8739 ; VA 0x006ae340 ; FUN_006ae340 */

void FUN_006ae340(void)

{
  undefined4 uVar1;
  undefined auStack_10 [12];
  
  uVar1 = FUN_00a735f0(auStack_10);
  FUN_006ad640(uVar1);
  uVar1 = FUN_00a735a0(auStack_10);
  FUN_006ad640(uVar1);
  return;
}



/* FUNCTION 8740 ; VA 0x006ae380 ; FUN_006ae380 */

void FUN_006ae380(int param_1)

{
  FUN_006ae7f0(param_1);
  FUN_006ae7f0(param_1 + 6);
  return;
}



/* FUNCTION 8741 ; VA 0x006ae3b0 ; FUN_006ae3b0 */

void __thiscall FUN_006ae3b0(int param_1,int *param_2)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  
  piVar3 = param_2;
  if ((((*param_2 < 0x80) && (param_2[1] < 0x80)) && (param_2[2] < 0x80)) &&
     (((-0x81 < *param_2 && (-0x81 < param_2[1])) && (-0x81 < param_2[2])))) {
    FUN_00632380(0);
    FUN_006323a0(*(undefined *)param_2);
    FUN_006323a0(*(undefined *)(param_2 + 1));
    FUN_006323a0(*(undefined *)(param_2 + 2));
    return;
  }
  iVar5 = *(int *)(param_1 + 0x18);
  piVar1 = (int *)(param_1 + 0xc);
  if (*(uint *)(param_1 + 0x1c) < iVar5 + 1U) {
    FUN_0055b6c0(iVar5 + 1U,piVar1);
    *(int *)(param_1 + 0x1c) = iVar5 + 1;
    iVar4 = *piVar1;
    *(int *)(param_1 + 8) = iVar4;
    iVar5 = *(int *)(param_1 + 0x18);
  }
  else {
    iVar4 = *(int *)(param_1 + 8);
  }
  *(undefined *)(iVar4 + iVar5) = 1;
  iVar5 = *(int *)(param_1 + 0x18);
  iVar6 = iVar5 + 1;
  *(int *)(param_1 + 0x18) = iVar6;
  iVar4 = *param_2;
  param_2._0_2_ = CONCAT11((char)((uint)iVar4 >> 0x10),(char)((uint)iVar4 >> 0x18));
  param_2._0_3_ = CONCAT12((char)((uint)iVar4 >> 8),param_2._0_2_);
  param_2 = (int *)CONCAT13((char)iVar4,param_2._0_3_);
  if (*(uint *)(param_1 + 0x1c) < iVar5 + 5U) {
    FUN_0055b6c0(iVar5 + 5U,piVar1);
    iVar6 = *(int *)(param_1 + 0x18);
    *(int *)(param_1 + 0x1c) = iVar5 + 5;
    iVar5 = *piVar1;
    *(int *)(param_1 + 8) = iVar5;
  }
  else {
    iVar5 = *(int *)(param_1 + 8);
  }
  *(int **)(iVar5 + iVar6) = param_2;
  iVar5 = *(int *)(param_1 + 0x18);
  iVar6 = iVar5 + 4;
  *(int *)(param_1 + 0x18) = iVar6;
  iVar4 = piVar3[1];
  param_2._0_2_ = CONCAT11((char)((uint)iVar4 >> 0x10),(char)((uint)iVar4 >> 0x18));
  param_2._0_3_ = CONCAT12((char)((uint)iVar4 >> 8),param_2._0_2_);
  param_2 = (int *)CONCAT13((char)iVar4,param_2._0_3_);
  if (*(uint *)(param_1 + 0x1c) < iVar5 + 8U) {
    FUN_0055b6c0(iVar5 + 8U,piVar1);
    iVar6 = *(int *)(param_1 + 0x18);
    *(int *)(param_1 + 0x1c) = iVar5 + 8;
    iVar5 = *piVar1;
    *(int *)(param_1 + 8) = iVar5;
  }
  else {
    iVar5 = *(int *)(param_1 + 8);
  }
  *(int **)(iVar5 + iVar6) = param_2;
  iVar5 = *(int *)(param_1 + 0x18);
  iVar6 = iVar5 + 4;
  *(int *)(param_1 + 0x18) = iVar6;
  iVar4 = piVar3[2];
  uVar2 = iVar5 + 8;
  param_2._0_2_ = CONCAT11((char)((uint)iVar4 >> 0x10),(char)((uint)iVar4 >> 0x18));
  param_2._0_3_ = CONCAT12((char)((uint)iVar4 >> 8),param_2._0_2_);
  param_2 = (int *)CONCAT13((char)iVar4,param_2._0_3_);
  if (*(uint *)(param_1 + 0x1c) < uVar2) {
    FUN_0055b6c0(uVar2,piVar1);
    *(uint *)(param_1 + 0x1c) = uVar2;
    *(int *)(param_1 + 8) = *piVar1;
    *(int **)(*piVar1 + *(int *)(param_1 + 0x18)) = param_2;
    *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
    return;
  }
  *(int **)(*(int *)(param_1 + 8) + iVar6) = param_2;
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
  return;
}



/* FUNCTION 8742 ; VA 0x006ae570 ; FUN_006ae570 */

void __thiscall FUN_006ae570(int param_1,undefined4 *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  undefined auStack_50 [36];
  undefined auStack_2c [24];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  uVar1 = param_2[4];
  if (uVar1 <= DAT_01d5b348) {
    ExceptionList = &pvStack_10;
    FUN_006323c0(uVar1);
    iStack_14 = param_2[4];
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    if (iStack_14 != 0) {
      iVar5 = *(int *)(param_1 + 0x18);
      uVar1 = iVar5 + iStack_14;
      if (*(uint *)(param_1 + 0x1c) < uVar1) {
        FUN_0055b6c0(uVar1,(int *)(param_1 + 0xc));
        iVar5 = *(int *)(param_1 + 0x18);
        *(uint *)(param_1 + 0x1c) = uVar1;
        iVar3 = *(int *)(param_1 + 0xc);
        *(int *)(param_1 + 8) = iVar3;
      }
      else {
        iVar3 = *(int *)(param_1 + 8);
      }
      iVar2 = iStack_14;
      FUN_0170c6f0(iVar3 + iVar5,param_2,iStack_14);
      *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + iVar2;
    }
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675640(auStack_2c,"BitStream string write: String too long: %u",uVar1);
  uStack_8 = 0;
  FUN_005f8ef0(uVar4);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_50,&DAT_01c27108);
}



/* FUNCTION 8743 ; VA 0x006ae640 ; FUN_006ae640 */

void FUN_006ae640(int param_1)

{
  FUN_006ae670(param_1);
  FUN_006ae670(param_1 + 8);
  return;
}



/* FUNCTION 8744 ; VA 0x006ae670 ; FUN_006ae670 */

void __thiscall FUN_006ae670(int param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  undefined4 uStack_8;
  
  uVar2 = *param_2;
  iVar3 = *(int *)(param_1 + 0x18);
  uStack_8 = CONCAT13((char)uVar2,
                      CONCAT12((char)((uint)uVar2 >> 8),
                               CONCAT11((char)((uint)uVar2 >> 0x10),(char)((uint)uVar2 >> 0x18))));
  uVar1 = iVar3 + 4;
  if (*(uint *)(param_1 + 0x1c) < uVar1) {
    FUN_0055b6c0(uVar1,(int *)(param_1 + 0xc));
    iVar3 = *(int *)(param_1 + 0x18);
    *(uint *)(param_1 + 0x1c) = uVar1;
    iVar4 = *(int *)(param_1 + 0xc);
    *(int *)(param_1 + 8) = iVar4;
  }
  else {
    iVar4 = *(int *)(param_1 + 8);
  }
  *(undefined4 *)(iVar4 + iVar3) = uStack_8;
  iVar3 = *(int *)(param_1 + 0x18);
  iVar4 = iVar3 + 4;
  *(int *)(param_1 + 0x18) = iVar4;
  uVar2 = param_2[1];
  uVar1 = iVar3 + 8;
  param_2 = (undefined4 *)
            CONCAT13((char)uVar2,
                     CONCAT12((char)((uint)uVar2 >> 8),
                              CONCAT11((char)((uint)uVar2 >> 0x10),(char)((uint)uVar2 >> 0x18))));
  if (*(uint *)(param_1 + 0x1c) < uVar1) {
    FUN_0055b6c0(uVar1,(int *)(param_1 + 0xc));
    *(uint *)(param_1 + 0x1c) = uVar1;
    iVar3 = *(int *)(param_1 + 0xc);
    *(int *)(param_1 + 8) = iVar3;
    *(undefined4 **)(iVar3 + *(int *)(param_1 + 0x18)) = param_2;
    *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
    return;
  }
  *(undefined4 **)(*(int *)(param_1 + 8) + iVar4) = param_2;
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 4;
  return;
}



/* FUNCTION 8745 ; VA 0x006ae750 ; FUN_006ae750 */

void __thiscall FUN_006ae750(int param_1,undefined2 *param_2)

{
  uint uVar1;
  undefined2 uVar2;
  int iVar3;
  int iVar4;
  
  uVar2 = *param_2;
  iVar3 = *(int *)(param_1 + 0x18);
  uVar1 = iVar3 + 2;
  if (*(uint *)(param_1 + 0x1c) < uVar1) {
    FUN_0055b6c0(uVar1,(int *)(param_1 + 0xc));
    iVar3 = *(int *)(param_1 + 0x18);
    *(uint *)(param_1 + 0x1c) = uVar1;
    iVar4 = *(int *)(param_1 + 0xc);
    *(int *)(param_1 + 8) = iVar4;
  }
  else {
    iVar4 = *(int *)(param_1 + 8);
  }
  *(ushort *)(iVar3 + iVar4) = CONCAT11((char)uVar2,(char)((ushort)uVar2 >> 8));
  iVar3 = *(int *)(param_1 + 0x18);
  iVar4 = iVar3 + 2;
  *(int *)(param_1 + 0x18) = iVar4;
  uVar2 = param_2[1];
  uVar1 = iVar3 + 4;
  if (*(uint *)(param_1 + 0x1c) < uVar1) {
    FUN_0055b6c0(uVar1,(int *)(param_1 + 0xc));
    iVar4 = *(int *)(param_1 + 0x18);
    *(uint *)(param_1 + 0x1c) = uVar1;
    iVar3 = *(int *)(param_1 + 0xc);
    *(int *)(param_1 + 8) = iVar3;
  }
  else {
    iVar3 = *(int *)(param_1 + 8);
  }
  *(ushort *)(iVar3 + iVar4) = CONCAT11((char)uVar2,(char)((ushort)uVar2 >> 8));
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 2;
  return;
}



/* FUNCTION 8746 ; VA 0x006ae7f0 ; FUN_006ae7f0 */

void __thiscall FUN_006ae7f0(int param_1,undefined2 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined2 uVar3;
  int iVar4;
  int iVar5;
  
  uVar3 = *param_2;
  iVar4 = *(int *)(param_1 + 0x18);
  piVar1 = (int *)(param_1 + 0xc);
  uVar2 = iVar4 + 2;
  if (*(uint *)(param_1 + 0x1c) < uVar2) {
    FUN_0055b6c0(uVar2,piVar1);
    iVar4 = *(int *)(param_1 + 0x18);
    *(uint *)(param_1 + 0x1c) = uVar2;
    iVar5 = *piVar1;
    *(int *)(param_1 + 8) = iVar5;
  }
  else {
    iVar5 = *(int *)(param_1 + 8);
  }
  *(ushort *)(iVar4 + iVar5) = CONCAT11((char)uVar3,(char)((ushort)uVar3 >> 8));
  iVar4 = *(int *)(param_1 + 0x18);
  iVar5 = iVar4 + 2;
  *(int *)(param_1 + 0x18) = iVar5;
  uVar3 = param_2[1];
  uVar2 = iVar4 + 4;
  if (*(uint *)(param_1 + 0x1c) < uVar2) {
    FUN_0055b6c0(uVar2,piVar1);
    iVar5 = *(int *)(param_1 + 0x18);
    *(uint *)(param_1 + 0x1c) = uVar2;
    iVar4 = *piVar1;
    *(int *)(param_1 + 8) = iVar4;
  }
  else {
    iVar4 = *(int *)(param_1 + 8);
  }
  *(ushort *)(iVar4 + iVar5) = CONCAT11((char)uVar3,(char)((ushort)uVar3 >> 8));
  iVar4 = *(int *)(param_1 + 0x18);
  iVar5 = iVar4 + 2;
  *(int *)(param_1 + 0x18) = iVar5;
  uVar3 = param_2[2];
  uVar2 = iVar4 + 4;
  if (*(uint *)(param_1 + 0x1c) < uVar2) {
    FUN_0055b6c0(uVar2,piVar1);
    iVar5 = *(int *)(param_1 + 0x18);
    *(uint *)(param_1 + 0x1c) = uVar2;
    iVar4 = *piVar1;
    *(int *)(param_1 + 8) = iVar4;
  }
  else {
    iVar4 = *(int *)(param_1 + 8);
  }
  *(ushort *)(iVar4 + iVar5) = CONCAT11((char)uVar3,(char)((ushort)uVar3 >> 8));
  *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 2;
  return;
}



/* FUNCTION 8747 ; VA 0x006ae8d0 ; FUN_006ae8d0 */

void FUN_006ae8d0(float *param_1,float *param_2,float *param_3)

{
  float fVar1;
  float fVar2;
  
  *param_1 = 0.0;
  param_1[1] = 0.0;
  param_1[2] = 0.0;
  param_1[3] = 0.0;
  fVar2 = param_2[1];
  if (param_3[1] <= param_2[1]) {
    fVar2 = param_3[1];
  }
  fVar1 = *param_2;
  if (*param_3 <= *param_2) {
    fVar1 = *param_3;
  }
  *param_1 = fVar1;
  param_1[1] = fVar2;
  fVar2 = param_2[1];
  if (param_2[1] <= param_3[1]) {
    fVar2 = param_3[1];
  }
  fVar1 = *param_2;
  if (*param_2 <= *param_3) {
    fVar1 = *param_3;
  }
  param_1[2] = fVar1;
  param_1[3] = fVar2;
  return;
}



/* FUNCTION 8748 ; VA 0x006ae950 ; FUN_006ae950 */

int __thiscall FUN_006ae950(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a66f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::Network::ConcurrentRakPeer::PacketJob>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) &&
     ((*(int *)(param_2 + 0xc) == 0 || (*(int *)(*(int *)(param_2 + 0xc) + 4) == 0)))) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 8) = param_2;
    piVar3 = *(int **)(param_2 + 0xc);
    *(int **)(param_2 + 0xc) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 8749 ; VA 0x006aea24 ; Catch_All@006aea24 */

void Catch_All_006aea24(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}


