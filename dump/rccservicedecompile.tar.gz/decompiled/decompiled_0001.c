/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 250 ; VA 0x00475aa0 ; FUN_00475aa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00475aa0(void)

{
  undefined **ppuVar1;
  undefined4 uStack_8;
  
  uStack_8 = 0xb;
  ppuVar1 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_8)
  ;
  if (ppuVar1 == &boost::lock_error::vftable_meta_ptr) {
    ppuVar1 = (undefined **)&DAT_018be194;
  }
  _DAT_01eada78 = *ppuVar1;
  DAT_01eada7c = 0;
  _DAT_01eada80 = 0x3f800000;
  _DAT_01eada84 = 0;
  _DAT_01eada88 = 0;
  FUN_016f3654(&LAB_0187d7d0);
  return;
}



/* FUNCTION 251 ; VA 0x00476190 ; FUN_00476190 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00476190(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a516c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_005edfb0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::NetworkSettings,bool>::
              GetSetImpl<bool_(__thiscall_RBX::NetworkSettings::*)(void)const_,void_(__thiscall_RBX::NetworkSettings::*)(bool)>
              ::vftable;
    puVar3[2] = FUN_00685240;
    puVar3[3] = 0;
    puVar3[4] = FUN_00685850;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_HttpProxyEnabled_02119850,s_Proxy_Settings_02119840,uStack_24,0,0,0x1f,
               0,5,0);
  DAT_021196d4 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02119708 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_021196f8 = _DAT_021196f8 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_021196d4[2])();
    if (cVar1 != '\0') {
      _DAT_021196f8 = _DAT_021196f8 & 0xfffffff3;
    }
  }
  DAT_021196d4 = RBX::Reflection::PropDescriptor<class_RBX::NetworkSettings,bool>::vftable;
  FUN_016f3654(&LAB_0187daa0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 252 ; VA 0x004762c0 ; FUN_004762c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004762c0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a519c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_005edfb0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::NetworkSettings,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetSetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::NetworkSettings::*)(void)const_,void_(__thiscall_RBX::NetworkSettings::*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>
              ::vftable;
    puVar3[2] = FUN_006852a0;
    puVar3[3] = 0;
    puVar3[4] = FUN_006858b0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,s_HttpProxyURL_02119864,s_Proxy_Settings_02119840,uStack_24,0,0,0x1f,0,5,
               0);
  DAT_0211970c = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02119740 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02119730 = _DAT_02119730 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0211970c[2])();
    if (cVar1 != '\0') {
      _DAT_02119730 = _DAT_02119730 & 0xfffffff3;
    }
  }
  DAT_0211970c = RBX::Reflection::
                 PropDescriptor<class_RBX::NetworkSettings,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_0187dac0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 253 ; VA 0x004763f0 ; FUN_004763f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004763f0(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a51d6;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_005edfb0();
  uStack_8 = 0;
  uVar4 = FUN_0088ca00();
  FUN_009ca670(uVar3,uVar4,s_IncomingReplicationLag_021197bc,s_Diagnostics_02119744,uStack_24,0,0,
               0x1f,0,0,0);
  DAT_021195f0 = (undefined4 *)0x0;
  uStack_8 = 3;
  DAT_021195bc = RBX::Reflection::BoundProp<double,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<double,1>::BoundPropGetSet<class_RBX::NetworkSettings>::
              vftable;
    puVar5[1] = &DAT_021195bc;
    puVar5[2] = 0x60;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  if (DAT_021195f0 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_021195f0;
    DAT_021195f0 = puVar5;
    (*(code *)*puVar1)(1);
    puVar5 = DAT_021195f0;
  }
  DAT_021195f0 = puVar5;
  cVar2 = (*(code *)DAT_021195bc[3])();
  if (cVar2 != '\0') {
    _DAT_021195e0 = _DAT_021195e0 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_021195bc[2])();
  if (cVar2 != '\0') {
    _DAT_021195e0 = _DAT_021195e0 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0187dae0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 254 ; VA 0x00476560 ; FUN_00476560 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00476560(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a51fc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_005edfb0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::NetworkSettings,int>::
              GetSetImpl<int_(__thiscall_RBX::NetworkSettings::*)(void)const_,void_(__thiscall_RBX::NetworkSettings::*)(int)>
              ::vftable;
    puVar3[2] = &LAB_00685250;
    puVar3[3] = 0;
    puVar3[4] = FUN_00685880;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,s_ExtraMemoryUsed_021197dc,&DAT_021197d4,uStack_24,0,0,0x10,1,1,0);
  DAT_021195f4 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02119628 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02119618 = _DAT_02119618 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_021195f4[2])();
    if (cVar1 != '\0') {
      _DAT_02119618 = _DAT_02119618 & 0xfffffff3;
    }
  }
  DAT_021195f4 = RBX::Reflection::PropDescriptor<class_RBX::NetworkSettings,int>::vftable;
  FUN_016f3654(&LAB_0187db00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 255 ; VA 0x00476690 ; FUN_00476690 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00476690(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a522c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_005edfb0();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::NetworkSettings,float>::
              GetImpl<float_(__thiscall_RBX::NetworkSettings::*)(void)const_>::vftable;
    puVar3[2] = FUN_00685260;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,s_FreeMemoryMBytes_021197ec,&DAT_021197d4,uStack_24,0,0,0x10,1,1,0);
  DAT_0211962c = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02119660 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02119650 = _DAT_02119650 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0211962c[2])();
    if (cVar1 != '\0') {
      _DAT_02119650 = _DAT_02119650 & 0xfffffff3;
    }
  }
  DAT_0211962c = RBX::Reflection::PropDescriptor<class_RBX::NetworkSettings,float>::vftable;
  FUN_016f3654(&LAB_0187db20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 256 ; VA 0x004769f0 ; FUN_004769f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004769f0(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a55be;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_005edc10();
  FUN_009cb970(uVar1,s_ConnectionAccepted_0211990c,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021198b0 = FUN_0068ba80;
  _DAT_021198b4 = 0;
  iStack_8 = 0;
  _DAT_02119878 =
       RBX::Reflection::
       EventDesc<class_RBX::Network::Client,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>)>*_(__thiscall_RBX::Network::Client::*)(bool)>
       ::vftable;
  FUN_0086e3d0(&DAT_02119904);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_replicator_021198f8);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_021198a0 = uStack_1c;
  _DAT_021198a4 = uStack_18;
  _DAT_021198a8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_02119878 =
       RBX::Reflection::
       EventDesc<class_RBX::Network::Client,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>)>*_(__thiscall_RBX::Network::Client::*)(bool)>
       ::vftable;
  FUN_016f3654(&LAB_0187dc00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 257 ; VA 0x00476b70 ; FUN_00476b70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00476b70(void)

{
  undefined4 uVar1;
  undefined auStack_2b4 [648];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5609;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_005edc10();
  FUN_009cb970(uVar1,s_ConnectionFailed_02119930,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021198f0 = FUN_0068bb50;
  _DAT_021198f4 = 0;
  iStack_8 = 0;
  _DAT_021198b8 =
       RBX::Reflection::
       EventDesc<class_RBX::Network::Client,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>*_(__thiscall_RBX::Network::Client::*)(bool)>
       ::vftable;
  FUN_0086e3d0(&DAT_02119904);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(&DAT_02119928);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_reason_02119920);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b4,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_021198e0 = uStack_1c;
  _DAT_021198e4 = uStack_18;
  _DAT_021198e8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b4,0xd8,3,FUN_00688b10);
  _DAT_021198b8 =
       RBX::Reflection::
       EventDesc<class_RBX::Network::Client,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>*_(__thiscall_RBX::Network::Client::*)(bool)>
       ::vftable;
  FUN_016f3654(&LAB_0187dc10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 258 ; VA 0x00476d10 ; FUN_00476d10 */

void __fastcall FUN_00476d10(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(4,param_1);
  if (iVar1 == 0) {
    DAT_01eadf98 = 0;
  }
  else {
    *(int *)iVar1 = iVar1;
    DAT_01eadf98 = iVar1;
  }
  FUN_016f3654(&LAB_0187dc20,iVar1);
  return;
}



/* FUNCTION 259 ; VA 0x00476e10 ; FUN_00476e10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00476e10(void)

{
  double dVar1;
  
  dVar1 = DAT_018ce308;
  FUN_017267a0();
  _DAT_01eae01c = (float)dVar1 * DAT_018ce328;
  return;
}



/* FUNCTION 260 ; VA 0x00477770 ; FUN_00477770 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00477770(void)

{
  undefined auStack_1c4 [16];
  undefined4 uStack_1b4;
  undefined4 uStack_1b0;
  undefined uStack_1ac;
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined uStack_194;
  undefined4 uStack_184;
  undefined4 uStack_180;
  undefined uStack_17c;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  undefined uStack_164;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined uStack_14c;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined uStack_134;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined uStack_11c;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined uStack_104;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined uStack_ec;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined uStack_d4;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined uStack_bc;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined uStack_a4;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined uStack_8c;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined uStack_74;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined uStack_5c;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined uStack_44;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined uStack_2c;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6a98;
  pvStack_10 = ExceptionList;
  uStack_1b4 = 0;
  uStack_1b0 = 0xf;
  auStack_1c4[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("rbxassetid://",0xd);
  uStack_8 = 0;
  uStack_19c = 0;
  uStack_198 = 0xf;
  uStack_1ac = 0;
  FUN_005542c0(&DAT_018db19c,0xf);
  uStack_8._0_1_ = 1;
  uStack_184 = 0;
  uStack_180 = 0xf;
  uStack_194 = 0;
  FUN_005542c0("http://www.roblox.com/",0x16);
  uStack_8._0_1_ = 2;
  uStack_16c = 0;
  uStack_168 = 0xf;
  uStack_17c = 0;
  FUN_005542c0("https://www.roblox.com/",0x17);
  uStack_8._0_1_ = 3;
  uStack_154 = 0;
  uStack_150 = 0xf;
  uStack_164 = 0;
  FUN_005542c0("http://www.roblox.com/asset/?id=",0x20);
  uStack_8._0_1_ = 4;
  uStack_13c = 0;
  uStack_138 = 0xf;
  uStack_14c = 0;
  FUN_005542c0("https://www.roblox.com/asset/?id=",0x21);
  uStack_8._0_1_ = 5;
  uStack_124 = 0;
  uStack_120 = 0xf;
  uStack_134 = 0;
  FUN_005542c0("http://assetgame.roblox.com/asset/?id=",0x26);
  uStack_8._0_1_ = 6;
  uStack_10c = 0;
  uStack_108 = 0xf;
  uStack_11c = 0;
  FUN_005542c0("https://assetgame.roblox.com/asset/?id=",0x27);
  uStack_8._0_1_ = 7;
  uStack_f4 = 0;
  uStack_f0 = 0xf;
  uStack_104 = 0;
  FUN_005542c0("http://assetdelivery.roblox.com/v1/asset/?id=",0x2d);
  uStack_8._0_1_ = 8;
  uStack_dc = 0;
  uStack_d8 = 0xf;
  uStack_ec = 0;
  FUN_005542c0("https://assetdelivery.roblox.com/v1/asset/?id=",0x2e);
  uStack_8._0_1_ = 9;
  uStack_c4 = 0;
  uStack_c0 = 0xf;
  uStack_d4 = 0;
  FUN_005542c0("http://www.roblox.qq.com/",0x19);
  uStack_8._0_1_ = 10;
  uStack_ac = 0;
  uStack_a8 = 0xf;
  uStack_bc = 0;
  FUN_005542c0("https://www.roblox.qq.com/",0x1a);
  uStack_8._0_1_ = 0xb;
  uStack_94 = 0;
  uStack_90 = 0xf;
  uStack_a4 = 0;
  FUN_005542c0("http://www.roblox.qq.com/asset/?id=",0x23);
  uStack_8._0_1_ = 0xc;
  uStack_7c = 0;
  uStack_78 = 0xf;
  uStack_8c = 0;
  FUN_005542c0("https://www.roblox.qq.com/asset/?id=",0x24);
  uStack_8._0_1_ = 0xd;
  uStack_64 = 0;
  uStack_60 = 0xf;
  uStack_74 = 0;
  FUN_005542c0("http://assetgame.roblox.qq.com/asset/?id=",0x29);
  uStack_8._0_1_ = 0xe;
  uStack_4c = 0;
  uStack_48 = 0xf;
  uStack_5c = 0;
  FUN_005542c0("https://assetgame.roblox.qq.com/asset/?id=",0x2a);
  uStack_8._0_1_ = 0xf;
  uStack_34 = 0;
  uStack_30 = 0xf;
  uStack_44 = 0;
  FUN_005542c0("http://assetdelivery.roblox.qq.com/v1/asset/?id=",0x30);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
  uStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = 0;
  FUN_005542c0("https://assetdelivery.roblox.qq.com/v1/asset/?id=",0x31);
  uStack_8 = 0x11;
  DAT_01eaec74 = 0;
  DAT_01eaec78 = 0;
  _DAT_01eaec7c = 0;
  FUN_00604490(auStack_1c4,&uStack_14,uStack_14);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(auStack_1c4,0x18,0x12,FUN_005507b0);
  FUN_016f3654(&LAB_0187de30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 261 ; VA 0x00478060 ; FUN_00478060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00478060(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a7d0c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_005ee090();
  FUN_009cb790(uVar1,s_SetOutgoingKBPSLimit_02119998,1,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02119948 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Network::Peer,void___cdecl(int),1>::vftable;
  _DAT_02119980 = FUN_006c5bf0;
  _DAT_02119984 = 0;
  DAT_02119988 = (undefined4 *)0x0;
  uStack_8 = 1;
  _DAT_0211996c = FUN_00888530();
  puVar3 = DAT_02119988;
  if (DAT_02119988 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088c8c0();
    puStack_ec = (undefined4 *)0x0;
    auStack_e8[0] = *puVar3;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c18) {
      FUN_016f3809(&DAT_01ea8c18);
      if (DAT_01ea8c18 == -1) {
        DAT_01ea8c0c = FUN_005c65e0;
        DAT_01ea8c10 = FUN_005c65e0;
        DAT_01ea8c14 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ea8c18);
      }
    }
    puStack_ec = &DAT_01ea8c0c;
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(s_limit_02119990);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_ec != (undefined4 *)0x0) {
      (*(code *)puStack_ec[2])(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0187e080);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 262 ; VA 0x00478d00 ; FUN_00478d00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00478d00(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9cc3;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_005edd10();
  FUN_009cb970(uVar1,s_StatsReceived_02119b04,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02119a74 = 0x3cdc;
  iStack_8 = 0;
  _DAT_02119a40 =
       RBX::Reflection::
       EventDesc<class_RBX::Network::ClientReplicator,void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>_RBX::Network::ClientReplicator::*>
       ::vftable;
  FUN_0086e3d0(s_stats_02119afc);
  FUN_008881d0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_02119a68 = uStack_1c;
  _DAT_02119a6c = uStack_18;
  _DAT_02119a70 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_02119a40 =
       RBX::Reflection::
       EventDesc<class_RBX::Network::ClientReplicator,void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>)>_RBX::Network::ClientReplicator::*>
       ::vftable;
  FUN_016f3654(&LAB_0187e280);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 263 ; VA 0x00478e50 ; FUN_00478e50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00478e50(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9cfe;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_005edd10();
  FUN_009cb970(uVar1,s_RCCProfilerDataComplete_02119b24,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02119aac = 0x3ce4;
  iStack_8 = 0;
  _DAT_02119a78 =
       RBX::Reflection::
       EventDesc<class_RBX::Network::ClientReplicator,void___cdecl(bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::Network::ClientReplicator::*>
       ::vftable;
  FUN_0086e3d0(s_success_02119b1c);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_message_02119b14);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02119aa0 = uStack_1c;
  _DAT_02119aa4 = uStack_18;
  _DAT_02119aa8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_02119a78 =
       RBX::Reflection::
       EventDesc<class_RBX::Network::ClientReplicator,void___cdecl(bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::Network::ClientReplicator::*>
       ::vftable;
  FUN_016f3654(&LAB_0187e290);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 264 ; VA 0x00478fc0 ; FUN_00478fc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00478fc0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9d2e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_005edd10(uVar2,0);
  FUN_009cb790(uVar1,s_RequestRCCProfilerData_02119ac8,5,CONCAT44(uVar3,uVar2),0);
  _DAT_021199b0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Network::ClientReplicator,void___cdecl(int,int),2>
       ::vftable;
  _DAT_021199e8 = FUN_006f3ae0;
  _DAT_021199ec = 0;
  DAT_021199f0 = 0;
  DAT_021199f4 = 0;
  uStack_8 = 2;
  FUN_006ee970();
  FUN_016f3654(&LAB_0187e2a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 265 ; VA 0x00479080 ; FUN_00479080 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00479080(void)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a9d8c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_005edd10();
  FUN_009cb790(uVar2,s_RequestServerStats_02119ae8,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_021199f8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Network::ClientReplicator,void___cdecl(bool),1>::
       vftable;
  _DAT_02119a30 = FUN_006f3c60;
  _DAT_02119a34 = 0;
  DAT_02119a38 = (undefined *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_02119a1c = FUN_00888530();
  puVar1 = DAT_02119a38;
  if (DAT_02119a38 == (undefined *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088daf0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar1;
    iStack_ec = FUN_005c9ef0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(s_request_02119ae0);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0187e2e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 266 ; VA 0x00479790 ; FUN_00479790 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00479790(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffd8;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffd8 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_005eded0(uVar2,0);
  FUN_009cb970(uVar1,"Received",0,CONCAT44(uVar3,uVar2),0);
  _DAT_01eaf68c = 0x58;
  _DAT_01eaf658 =
       RBX::Reflection::
       EventDesc<class_RBX::Network::Marker,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::Network::Marker::*>
       ::vftable;
  uStack_8 = 0;
  FUN_0068a760();
  _DAT_01eaf680 = 0;
  _DAT_01eaf684 = 0;
  _DAT_01eaf688 = 0;
  uStack_8 = 1;
  FUN_0068a760();
  _DAT_01eaf658 =
       RBX::Reflection::
       EventDesc<class_RBX::Network::Marker,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::Network::Marker::*>
       ::vftable;
  FUN_016f3654(&LAB_0187e7e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 267 ; VA 0x0047a600 ; FUN_0047a600 */

void FUN_0047a600(void)

{
  double dVar1;
  
  dVar1 = DAT_018ce308;
  FUN_017267a0();
  DAT_01eafd9c = DAT_018ce2f8 / (float)dVar1;
  return;
}



/* FUNCTION 268 ; VA 0x0047b120 ; FUN_0047b120 */

void FUN_0047b120(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b0f3a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005542c0("rbxasset://textures/materials.json",0x22);
  uStack_8 = 0;
  FUN_009cbbb0(&DAT_01d60ea8);
  FUN_016f3654(&LAB_0187f210);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 269 ; VA 0x0047b760 ; FUN_0047b760 */

void FUN_0047b760(void)

{
  FUN_011619f0(&DAT_01eb286c,0xbfc90fdb,0x3fc90fdb,0);
  return;
}



/* FUNCTION 270 ; VA 0x0047b790 ; FUN_0047b790 */

void FUN_0047b790(void)

{
  FUN_01161480(&DAT_01eb2890,0,0xbfc90fdb,0);
  return;
}



/* FUNCTION 271 ; VA 0x0047c070 ; FUN_0047c070 */

void FUN_0047c070(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b5f4a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005542c0("rbxasset://sky/moon.jpg",0x17);
  uStack_8 = 0;
  FUN_009cbbb0(&DAT_01d6202c);
  FUN_016f3654(&LAB_0187f680);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 272 ; VA 0x0047c0d0 ; FUN_0047c0d0 */

void FUN_0047c0d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b5f6a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005542c0("rbxasset://sky/sun.jpg",0x16);
  uStack_8 = 0;
  FUN_009cbbb0(&DAT_01d62014);
  FUN_016f3654(&LAB_0187f6e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 273 ; VA 0x0047c270 ; FUN_0047c270 */

void FUN_0047c270(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b655a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005542c0("rbxasset://sky/noisefb.dds",0x1a);
  uStack_8 = 0;
  FUN_009cbbb0(&DAT_01d6215c);
  FUN_016f3654(&LAB_0187f800);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 274 ; VA 0x0047c2d0 ; FUN_0047c2d0 */

void FUN_0047c2d0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b657a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005542c0("rbxasset://sky/noise.dds",0x18);
  uStack_8 = 0;
  FUN_009cbbb0(&DAT_01d62144);
  FUN_016f3654(&LAB_0187f860);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 275 ; VA 0x0047c330 ; FUN_0047c330 */

void FUN_0047c330(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b659a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005542c0("rbxasset://sky/cloudsfb.dds",0x1b);
  uStack_8 = 0;
  FUN_009cbbb0(&DAT_01d6212c);
  FUN_016f3654(&LAB_0187f8c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 276 ; VA 0x0047c390 ; FUN_0047c390 */

void FUN_0047c390(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b65ba;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005542c0("rbxasset://sky/clouds.dds",0x19);
  uStack_8 = 0;
  FUN_009cbbb0(&DAT_01d62114);
  FUN_016f3654(&LAB_0187f920);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 277 ; VA 0x0047c700 ; FUN_0047c700 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0047c700(void)

{
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b78d8;
  pvStack_10 = ExceptionList;
  uStack_e0 = _DAT_0191a420;
  uStack_dc = _UNK_0191a424;
  uStack_d8 = _UNK_0191a428;
  uStack_d4 = _UNK_0191a42c;
  uStack_1c = 0;
  uStack_d0 = _DAT_0191a530;
  uStack_cc = _UNK_0191a534;
  uStack_c8 = _UNK_0191a538;
  uStack_c4 = _UNK_0191a53c;
  uStack_c0 = _DAT_0191a3b0;
  uStack_bc = _UNK_0191a3b4;
  uStack_b8 = _UNK_0191a3b8;
  uStack_b4 = _UNK_0191a3bc;
  uStack_b0 = _DAT_0191a490;
  uStack_ac = _UNK_0191a494;
  uStack_a8 = _UNK_0191a498;
  uStack_a4 = _UNK_0191a49c;
  uStack_18 = 0;
  uStack_a0 = _DAT_0191a560;
  uStack_9c = _UNK_0191a564;
  uStack_98 = _UNK_0191a568;
  uStack_94 = _UNK_0191a56c;
  uStack_14 = 0;
  uStack_90 = _DAT_0191a3c0;
  uStack_8c = _UNK_0191a3c4;
  uStack_88 = _UNK_0191a3c8;
  uStack_84 = _UNK_0191a3cc;
  uStack_80 = _DAT_0191a4b0;
  uStack_7c = _UNK_0191a4b4;
  uStack_78 = _UNK_0191a4b8;
  uStack_74 = _UNK_0191a4bc;
  uStack_70 = _DAT_0191a570;
  uStack_6c = _UNK_0191a574;
  uStack_68 = _UNK_0191a578;
  uStack_64 = _UNK_0191a57c;
  uStack_60 = _DAT_0191a390;
  uStack_5c = _UNK_0191a394;
  uStack_58 = _UNK_0191a398;
  uStack_54 = _UNK_0191a39c;
  uStack_50 = _DAT_0191a4e0;
  uStack_4c = _UNK_0191a4e4;
  uStack_48 = _UNK_0191a4e8;
  uStack_44 = _UNK_0191a4ec;
  uStack_40 = _DAT_0191a480;
  uStack_3c = _UNK_0191a484;
  uStack_38 = _UNK_0191a488;
  uStack_34 = _UNK_0191a48c;
  uStack_30 = _DAT_0191a3e0;
  uStack_2c = _UNK_0191a3e4;
  uStack_28 = _UNK_0191a3e8;
  uStack_24 = _UNK_0191a3ec;
  ExceptionList = &pvStack_10;
  FUN_0084e500(&uStack_e0,&uStack_20,uStack_20);
  uStack_8 = 0;
  FUN_00a92d50(&uStack_1c,0);
  FUN_00617ad0();
  FUN_016f3654(&LAB_0187fb60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 278 ; VA 0x0047c820 ; FUN_0047c820 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0047c820(void)

{
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b78d8;
  pvStack_10 = ExceptionList;
  uStack_e0 = _DAT_0191a430;
  uStack_dc = _UNK_0191a434;
  uStack_d8 = _UNK_0191a438;
  uStack_d4 = _UNK_0191a43c;
  uStack_1c = 0;
  uStack_d0 = _DAT_0191a540;
  uStack_cc = _UNK_0191a544;
  uStack_c8 = _UNK_0191a548;
  uStack_c4 = _UNK_0191a54c;
  uStack_c0 = _DAT_0191a3b0;
  uStack_bc = _UNK_0191a3b4;
  uStack_b8 = _UNK_0191a3b8;
  uStack_b4 = _UNK_0191a3bc;
  uStack_b0 = _DAT_0191a490;
  uStack_ac = _UNK_0191a494;
  uStack_a8 = _UNK_0191a498;
  uStack_a4 = _UNK_0191a49c;
  uStack_18 = 0;
  uStack_a0 = _DAT_0191a520;
  uStack_9c = _UNK_0191a524;
  uStack_98 = _UNK_0191a528;
  uStack_94 = _UNK_0191a52c;
  uStack_14 = 0;
  uStack_90 = _DAT_0191a450;
  uStack_8c = _UNK_0191a454;
  uStack_88 = _UNK_0191a458;
  uStack_84 = _UNK_0191a45c;
  uStack_80 = _DAT_0191a4c0;
  uStack_7c = _UNK_0191a4c4;
  uStack_78 = _UNK_0191a4c8;
  uStack_74 = _UNK_0191a4cc;
  uStack_70 = _DAT_0191a4a0;
  uStack_6c = _UNK_0191a4a4;
  uStack_68 = _UNK_0191a4a8;
  uStack_64 = _UNK_0191a4ac;
  uStack_60 = _DAT_0191a460;
  uStack_5c = _UNK_0191a464;
  uStack_58 = _UNK_0191a468;
  uStack_54 = _UNK_0191a46c;
  uStack_50 = _DAT_0191a500;
  uStack_4c = _UNK_0191a504;
  uStack_48 = _UNK_0191a508;
  uStack_44 = _UNK_0191a50c;
  uStack_40 = _DAT_0191a400;
  uStack_3c = _UNK_0191a404;
  uStack_38 = _UNK_0191a408;
  uStack_34 = _UNK_0191a40c;
  uStack_30 = _DAT_0191a370;
  uStack_2c = _UNK_0191a374;
  uStack_28 = _UNK_0191a378;
  uStack_24 = _UNK_0191a37c;
  ExceptionList = &pvStack_10;
  FUN_0084e500(&uStack_e0,&uStack_20,uStack_20);
  uStack_8 = 0;
  FUN_00a92d50(&uStack_1c,0);
  FUN_00617ad0();
  FUN_016f3654(&LAB_0187fb70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 279 ; VA 0x0047c940 ; FUN_0047c940 */

void FUN_0047c940(void)

{
  undefined4 uStack_160;
  undefined8 uStack_15c;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined8 uStack_148;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined8 uStack_134;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined8 uStack_120;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined8 uStack_10c;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined8 uStack_d0;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined8 uStack_bc;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b78f8;
  pvStack_10 = ExceptionList;
  uStack_15c = CONCAT44(DAT_0191a300,DAT_0191a278);
  uStack_148 = CONCAT44(DAT_01901f3c,DAT_0191a258);
  uStack_134 = CONCAT44(DAT_0191a2ac,DAT_0191a23c);
  uStack_120 = CONCAT44(DAT_0191a28c,DAT_0191a21c);
  uStack_10c = CONCAT44(DAT_0191a270,DAT_0191a1fc);
  uStack_f8 = CONCAT44(DAT_0191a254,DAT_0191a1ec);
  uStack_154 = 0x3f67676f;
  uStack_140 = 0x3f63635e;
  uStack_12c = 0x3f5adadc;
  uStack_118 = 0x3f44c4bd;
  uStack_e4 = CONCAT44(DAT_0191a244,DAT_0191a1f8);
  uStack_104 = 0x3f30302b;
  uStack_d0 = CONCAT44(DAT_0191a230,DAT_0191a200);
  uStack_f0 = 0x3f20a0a1;
  uStack_dc = 0x3f0f0f17;
  uStack_160 = 0;
  uStack_150 = 0;
  uStack_14c = 0x3d8888b5;
  uStack_13c = 0;
  uStack_138 = 0x3e088872;
  uStack_128 = 0;
  uStack_124 = 0x3e4ccccd;
  uStack_114 = 0;
  uStack_110 = 0x3e888894;
  uStack_100 = 0;
  uStack_fc = 0x3eaaaa9f;
  uStack_ec = 0;
  uStack_e8 = 0x3ecccccd;
  uStack_d8 = 0;
  uStack_d4 = 0x3eeeeefa;
  uStack_c8 = 0x3f030308;
  uStack_c4 = 0;
  uStack_c0 = 0x3f088883;
  uStack_bc = CONCAT44(DAT_0191a22c,DAT_0191a200);
  uStack_b4 = 0x3ef6f6f9;
  uStack_a8 = CONCAT44(DAT_0191a228,DAT_0191a200);
  uStack_a0 = 0x3eeeeefa;
  uStack_8c = 0x3ec5c5d6;
  uStack_78 = 0x3e9696a2;
  uStack_64 = 0x3e54d4cc;
  uStack_50 = 0x3df8f92b;
  uStack_3c = 0x3d60e0eb;
  uStack_28 = 0;
  uStack_6c = CONCAT44(DAT_0191a1e8,DAT_0191a1e4);
  uStack_58 = CONCAT44(DAT_0191a1dc,DAT_0191a1dc);
  uStack_b0 = 0;
  uStack_ac = 0x3f19999a;
  uStack_9c = 0;
  uStack_98 = 0x3f2aaab0;
  uStack_94 = CONCAT44(DAT_0191a20c,DAT_0191a200);
  uStack_88 = 0;
  uStack_84 = 0x3f3bbbb6;
  uStack_80 = CONCAT44(DAT_0191a204,DAT_0191a1ec);
  uStack_74 = 0;
  uStack_70 = 0x3f4ccccd;
  uStack_60 = 0;
  uStack_5c = 0x3f5ddde3;
  uStack_4c = 0;
  uStack_48 = 0x3f6eeee9;
  uStack_44 = CONCAT44(DAT_0191a1d0,DAT_0191a1d8);
  uStack_38 = 0;
  uStack_34 = 0x3f800000;
  uStack_30 = 0;
  uStack_24 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_0084e430(&uStack_160,&uStack_20,uStack_20);
  uStack_8 = 0;
  FUN_00a8e070(&uStack_1c,0);
  FUN_00617bc0();
  FUN_016f3654(&LAB_0187fb80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 280 ; VA 0x0047cd50 ; FUN_0047cd50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0047cd50(void)

{
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b78d8;
  pvStack_10 = ExceptionList;
  uStack_e0 = _DAT_0191a440;
  uStack_dc = _UNK_0191a444;
  uStack_d8 = _UNK_0191a448;
  uStack_d4 = _UNK_0191a44c;
  uStack_1c = 0;
  uStack_d0 = _DAT_0191a550;
  uStack_cc = _UNK_0191a554;
  uStack_c8 = _UNK_0191a558;
  uStack_c4 = _UNK_0191a55c;
  uStack_c0 = _DAT_0191a3b0;
  uStack_bc = _UNK_0191a3b4;
  uStack_b8 = _UNK_0191a3b8;
  uStack_b4 = _UNK_0191a3bc;
  uStack_b0 = _DAT_0191a490;
  uStack_ac = _UNK_0191a494;
  uStack_a8 = _UNK_0191a498;
  uStack_a4 = _UNK_0191a49c;
  uStack_18 = 0;
  uStack_a0 = _DAT_0191a560;
  uStack_9c = _UNK_0191a564;
  uStack_98 = _UNK_0191a568;
  uStack_94 = _UNK_0191a56c;
  uStack_14 = 0;
  uStack_90 = _DAT_0191a3c0;
  uStack_8c = _UNK_0191a3c4;
  uStack_88 = _UNK_0191a3c8;
  uStack_84 = _UNK_0191a3cc;
  uStack_80 = _DAT_0191a4b0;
  uStack_7c = _UNK_0191a4b4;
  uStack_78 = _UNK_0191a4b8;
  uStack_74 = _UNK_0191a4bc;
  uStack_70 = _DAT_0191a570;
  uStack_6c = _UNK_0191a574;
  uStack_68 = _UNK_0191a578;
  uStack_64 = _UNK_0191a57c;
  uStack_60 = _DAT_0191a3d0;
  uStack_5c = _UNK_0191a3d4;
  uStack_58 = _UNK_0191a3d8;
  uStack_54 = _UNK_0191a3dc;
  uStack_50 = _DAT_0191a4f0;
  uStack_4c = _UNK_0191a4f4;
  uStack_48 = _UNK_0191a4f8;
  uStack_44 = _UNK_0191a4fc;
  uStack_40 = _DAT_0191a470;
  uStack_3c = _UNK_0191a474;
  uStack_38 = _UNK_0191a478;
  uStack_34 = _UNK_0191a47c;
  uStack_30 = _DAT_0191a380;
  uStack_2c = _UNK_0191a384;
  uStack_28 = _UNK_0191a388;
  uStack_24 = _UNK_0191a38c;
  ExceptionList = &pvStack_10;
  FUN_0084e500(&uStack_e0,&uStack_20,uStack_20);
  uStack_8 = 0;
  FUN_00a92d50(&uStack_1c,0);
  FUN_00617ad0();
  FUN_016f3654(&LAB_0187fb90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 281 ; VA 0x0047ce90 ; FUN_0047ce90 */

void FUN_0047ce90(void)

{
  undefined4 uStack_160;
  undefined8 uStack_15c;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined8 uStack_148;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined8 uStack_134;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined8 uStack_120;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined8 uStack_10c;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined8 uStack_d0;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined8 uStack_bc;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b78f8;
  pvStack_10 = ExceptionList;
  uStack_15c = CONCAT44(DAT_0191a314,DAT_0191a314);
  uStack_148 = CONCAT44(DAT_0191a274,DAT_0191a26c);
  uStack_134 = CONCAT44(DAT_0191a248,DAT_0191a248);
  uStack_120 = CONCAT44(DAT_0191a240,DAT_0191a244);
  uStack_10c = CONCAT44(DAT_0191a238,DAT_0191a234);
  uStack_154 = 0x3f5a5a57;
  uStack_140 = 0x3ee6e6da;
  uStack_12c = 0x3ea6a6a0;
  uStack_118 = 0x3e9696a2;
  uStack_e4 = CONCAT44(DAT_0191a208,DAT_0191a208);
  uStack_104 = 0x3e6eeed9;
  uStack_f8 = CONCAT44(DAT_0191a220,DAT_0191a224);
  uStack_f0 = 0x3e44c4ce;
  uStack_dc = 0x3e0c8c93;
  uStack_c8 = 0x3da4a490;
  uStack_d0 = CONCAT44(DAT_0191a1f4,DAT_0191a1f0);
  uStack_bc = CONCAT44(DAT_0191a1e0,DAT_0191a1e0);
  uStack_160 = 0;
  uStack_150 = 0;
  uStack_14c = 0x3d8888b5;
  uStack_13c = 0;
  uStack_138 = 0x3e088872;
  uStack_128 = 0;
  uStack_124 = 0x3e4ccccd;
  uStack_114 = 0;
  uStack_110 = 0x3e888894;
  uStack_100 = 0;
  uStack_fc = 0x3eaaaa9f;
  uStack_ec = 0;
  uStack_e8 = 0x3ecccccd;
  uStack_d8 = 0;
  uStack_d4 = 0x3eeeeefa;
  uStack_c4 = 0;
  uStack_c0 = 0x3f088883;
  uStack_b4 = 0x3d20a0f5;
  uStack_b0 = 0;
  uStack_94 = CONCAT44(DAT_0191a1c8,DAT_0191a1c8);
  uStack_a0 = 0x3ca0a0f5;
  uStack_8c = 0x3b80841f;
  uStack_80 = CONCAT44(DAT_0191a214,DAT_0191a214);
  uStack_78 = 0x3e2cac8e;
  uStack_64 = 0x3eaeae9f;
  uStack_50 = 0x3f088883;
  uStack_6c = CONCAT44(DAT_0191a24c,DAT_0191a24c);
  uStack_3c = 0x3f31b1b8;
  uStack_28 = 0x3f63e3e3;
  uStack_44 = CONCAT44(DAT_0191a2d0,DAT_0191a2d0);
  uStack_ac = 0x3f19999a;
  uStack_a8 = CONCAT44(DAT_0191a1d4,DAT_0191a1d8);
  uStack_9c = 0;
  uStack_98 = 0x3f2aaab0;
  uStack_88 = 0;
  uStack_84 = 0x3f3bbbb6;
  uStack_74 = 0;
  uStack_70 = 0x3f4ccccd;
  uStack_60 = 0;
  uStack_5c = 0x3f5ddde3;
  uStack_58 = CONCAT44(DAT_0191a290,DAT_0191a290);
  uStack_4c = 0;
  uStack_48 = 0x3f6eeee9;
  uStack_38 = 0;
  uStack_34 = 0x3f800000;
  uStack_30 = CONCAT44(DAT_0191a32c,DAT_0191a32c);
  uStack_24 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_0084e430(&uStack_160,&uStack_20,uStack_20);
  uStack_8 = 0;
  FUN_00a8e070(&uStack_1c,0);
  FUN_00617bc0();
  FUN_016f3654(&LAB_0187fba0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 282 ; VA 0x0047d280 ; FUN_0047d280 */

void FUN_0047d280(void)

{
  undefined4 uStack_160;
  undefined8 uStack_15c;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined8 uStack_148;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined8 uStack_134;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined8 uStack_120;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined8 uStack_10c;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined8 uStack_d0;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined8 uStack_bc;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b78f8;
  pvStack_10 = ExceptionList;
  uStack_15c = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_148 = CONCAT44(DAT_018ce2f8,DAT_0191a350);
  uStack_134 = CONCAT44(DAT_0191a358,DAT_0191a348);
  uStack_120 = CONCAT44(DAT_0191a354,DAT_0191a338);
  uStack_10c = CONCAT44(DAT_0191a34c,DAT_0191a32c);
  uStack_f8 = CONCAT44(DAT_0191a340,DAT_0191a310);
  uStack_154 = 0x3f800000;
  uStack_140 = 0x3f800000;
  uStack_12c = 0x3f7f7f7c;
  uStack_118 = 0x3f7efef8;
  uStack_e4 = CONCAT44(DAT_0191a324,DAT_0191a304);
  uStack_104 = 0x3f7efef8;
  uStack_f0 = 0x3f7f7f7c;
  uStack_d0 = CONCAT44(DAT_0191a308,DAT_0191a2f4);
  uStack_dc = 0x3f7efef8;
  uStack_c8 = 0x3f7efef8;
  uStack_160 = 0;
  uStack_150 = 0;
  uStack_14c = 0x3d8888b5;
  uStack_13c = 0;
  uStack_138 = 0x3e088872;
  uStack_128 = 0;
  uStack_124 = 0x3e4ccccd;
  uStack_114 = 0;
  uStack_110 = 0x3e888894;
  uStack_100 = 0;
  uStack_fc = 0x3eaaaa9f;
  uStack_ec = 0;
  uStack_e8 = 0x3ecccccd;
  uStack_d8 = 0;
  uStack_d4 = 0x3eeeeefa;
  uStack_c4 = 0;
  uStack_c0 = 0x3f088883;
  uStack_bc = CONCAT44(DAT_0191a2ec,DAT_0191a2d4);
  uStack_b4 = 0x3f7efef8;
  uStack_b0 = 0;
  uStack_a8 = CONCAT44(DAT_0191a2f8,DAT_0191a2dc);
  uStack_a0 = 0x3f7efef8;
  uStack_8c = 0x3f7bfc01;
  uStack_78 = 0x3f5b5b60;
  uStack_80 = CONCAT44(DAT_0191a2bc,DAT_0191a2b8);
  uStack_64 = 0x3f4b4b51;
  uStack_50 = 0x3f4d4d51;
  uStack_6c = CONCAT44(DAT_0191a2c8,DAT_0191a2c0);
  uStack_3c = 0x3f36b6bf;
  uStack_28 = 0x3f606067;
  uStack_94 = CONCAT44(DAT_0191a2e8,DAT_0191a2dc);
  uStack_ac = 0x3f19999a;
  uStack_9c = 0;
  uStack_98 = 0x3f2aaab0;
  uStack_88 = 0;
  uStack_84 = 0x3f3bbbb6;
  uStack_74 = 0;
  uStack_70 = 0x3f4ccccd;
  uStack_60 = 0;
  uStack_5c = 0x3f5ddde3;
  uStack_58 = CONCAT44(DAT_0191a2e4,DAT_0191a2e0);
  uStack_4c = 0;
  uStack_48 = 0x3f6eeee9;
  uStack_44 = CONCAT44(DAT_0191a2c4,DAT_0191a2c0);
  uStack_38 = 0;
  uStack_34 = 0x3f800000;
  uStack_30 = CONCAT44(DAT_0191a31c,DAT_0191a318);
  uStack_24 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_0084e430(&uStack_160,&uStack_20,uStack_20);
  uStack_8 = 0;
  FUN_00a8e070(&uStack_1c,0);
  FUN_00617bc0();
  FUN_016f3654(&LAB_0187fbb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 283 ; VA 0x0047d6a0 ; FUN_0047d6a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0047d6a0(void)

{
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b78d8;
  pvStack_10 = ExceptionList;
  uStack_e0 = _DAT_0191a430;
  uStack_dc = _UNK_0191a434;
  uStack_d8 = _UNK_0191a438;
  uStack_d4 = _UNK_0191a43c;
  uStack_1c = 0;
  uStack_d0 = _DAT_0191a540;
  uStack_cc = _UNK_0191a544;
  uStack_c8 = _UNK_0191a548;
  uStack_c4 = _UNK_0191a54c;
  uStack_c0 = _DAT_0191a3b0;
  uStack_bc = _UNK_0191a3b4;
  uStack_b8 = _UNK_0191a3b8;
  uStack_b4 = _UNK_0191a3bc;
  uStack_b0 = _DAT_0191a490;
  uStack_ac = _UNK_0191a494;
  uStack_a8 = _UNK_0191a498;
  uStack_a4 = _UNK_0191a49c;
  uStack_18 = 0;
  uStack_a0 = _DAT_0191a560;
  uStack_9c = _UNK_0191a564;
  uStack_98 = _UNK_0191a568;
  uStack_94 = _UNK_0191a56c;
  uStack_14 = 0;
  uStack_90 = _DAT_0191a3c0;
  uStack_8c = _UNK_0191a3c4;
  uStack_88 = _UNK_0191a3c8;
  uStack_84 = _UNK_0191a3cc;
  uStack_80 = _DAT_0191a4b0;
  uStack_7c = _UNK_0191a4b4;
  uStack_78 = _UNK_0191a4b8;
  uStack_74 = _UNK_0191a4bc;
  uStack_70 = _DAT_0191a570;
  uStack_6c = _UNK_0191a574;
  uStack_68 = _UNK_0191a578;
  uStack_64 = _UNK_0191a57c;
  uStack_60 = _DAT_0191a3f0;
  uStack_5c = _UNK_0191a3f4;
  uStack_58 = _UNK_0191a3f8;
  uStack_54 = _UNK_0191a3fc;
  uStack_50 = _DAT_0191a4d0;
  uStack_4c = _UNK_0191a4d4;
  uStack_48 = _UNK_0191a4d8;
  uStack_44 = _UNK_0191a4dc;
  uStack_40 = _DAT_0191a3a0;
  uStack_3c = _UNK_0191a3a4;
  uStack_38 = _UNK_0191a3a8;
  uStack_34 = _UNK_0191a3ac;
  uStack_30 = _DAT_019189f0;
  uStack_2c = _UNK_019189f4;
  uStack_28 = _UNK_019189f8;
  uStack_24 = _UNK_019189fc;
  ExceptionList = &pvStack_10;
  FUN_0084e500(&uStack_e0,&uStack_20,uStack_20);
  uStack_8 = 0;
  FUN_00a92d50(&uStack_1c,0);
  FUN_00617ad0();
  FUN_016f3654(&LAB_0187fbc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 284 ; VA 0x0047d7c0 ; FUN_0047d7c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0047d7c0(void)

{
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b78d8;
  pvStack_10 = ExceptionList;
  uStack_e0 = _DAT_0191a410;
  uStack_dc = _UNK_0191a414;
  uStack_d8 = _UNK_0191a418;
  uStack_d4 = _UNK_0191a41c;
  uStack_1c = 0;
  uStack_d0 = _DAT_0191a510;
  uStack_cc = _UNK_0191a514;
  uStack_c8 = _UNK_0191a518;
  uStack_c4 = _UNK_0191a51c;
  uStack_c0 = _DAT_0191a3b0;
  uStack_bc = _UNK_0191a3b4;
  uStack_b8 = _UNK_0191a3b8;
  uStack_b4 = _UNK_0191a3bc;
  uStack_b0 = _DAT_0191a490;
  uStack_ac = _UNK_0191a494;
  uStack_a8 = _UNK_0191a498;
  uStack_a4 = _UNK_0191a49c;
  uStack_18 = 0;
  uStack_a0 = _DAT_0191a560;
  uStack_9c = _UNK_0191a564;
  uStack_98 = _UNK_0191a568;
  uStack_94 = _UNK_0191a56c;
  uStack_14 = 0;
  uStack_90 = _DAT_0191a3c0;
  uStack_8c = _UNK_0191a3c4;
  uStack_88 = _UNK_0191a3c8;
  uStack_84 = _UNK_0191a3cc;
  uStack_80 = _DAT_0191a4b0;
  uStack_7c = _UNK_0191a4b4;
  uStack_78 = _UNK_0191a4b8;
  uStack_74 = _UNK_0191a4bc;
  uStack_70 = _DAT_0191a570;
  uStack_6c = _UNK_0191a574;
  uStack_68 = _UNK_0191a578;
  uStack_64 = _UNK_0191a57c;
  uStack_60 = _DAT_0191a3f0;
  uStack_5c = _UNK_0191a3f4;
  uStack_58 = _UNK_0191a3f8;
  uStack_54 = _UNK_0191a3fc;
  uStack_50 = _DAT_0191a4d0;
  uStack_4c = _UNK_0191a4d4;
  uStack_48 = _UNK_0191a4d8;
  uStack_44 = _UNK_0191a4dc;
  uStack_40 = _DAT_0191a3a0;
  uStack_3c = _UNK_0191a3a4;
  uStack_38 = _UNK_0191a3a8;
  uStack_34 = _UNK_0191a3ac;
  uStack_30 = _DAT_019189f0;
  uStack_2c = _UNK_019189f4;
  uStack_28 = _UNK_019189f8;
  uStack_24 = _UNK_019189fc;
  ExceptionList = &pvStack_10;
  FUN_0084e500(&uStack_e0,&uStack_20,uStack_20);
  uStack_8 = 0;
  FUN_00a92d50(&uStack_1c,0);
  FUN_00617ad0();
  FUN_016f3654(&LAB_0187fbd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 285 ; VA 0x0047d8e0 ; FUN_0047d8e0 */

void FUN_0047d8e0(void)

{
  undefined4 uStack_160;
  ulonglong uStack_15c;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  ulonglong uStack_148;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  ulonglong uStack_134;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  ulonglong uStack_120;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  ulonglong uStack_10c;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined8 uStack_d0;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined8 uStack_bc;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b78f8;
  pvStack_10 = ExceptionList;
  uStack_15c = (ulonglong)DAT_018ce2f8;
  uStack_148 = (ulonglong)DAT_018ce2f8;
  uStack_134 = (ulonglong)DAT_018ce2f8;
  uStack_120 = (ulonglong)DAT_018ce2f8;
  uStack_10c = (ulonglong)DAT_018ce2f8;
  uStack_154 = 0;
  uStack_f8 = CONCAT44(DAT_0191a210,DAT_0191a358);
  uStack_140 = 0;
  uStack_12c = 0;
  uStack_118 = 0;
  uStack_e4 = CONCAT44(DAT_018fde64,DAT_0191a358);
  uStack_104 = 0;
  uStack_f0 = 0x3e2aaac1;
  uStack_dc = 0x3e99999a;
  uStack_d0 = CONCAT44(DAT_0191a250,DAT_0191a358);
  uStack_c8 = 0x3ebbbbc7;
  uStack_160 = 0;
  uStack_150 = 0;
  uStack_14c = 0x3d8888b5;
  uStack_13c = 0;
  uStack_138 = 0x3e088872;
  uStack_128 = 0;
  uStack_124 = 0x3e4ccccd;
  uStack_114 = 0;
  uStack_110 = 0x3e888894;
  uStack_100 = 0;
  uStack_fc = 0x3eaaaa9f;
  uStack_ec = 0;
  uStack_e8 = 0x3ecccccd;
  uStack_d8 = 0;
  uStack_d4 = 0x3eeeeefa;
  uStack_c4 = 0;
  uStack_c0 = 0x3f088883;
  uStack_bc = CONCAT44(DAT_0191a268,DAT_0191a358);
  uStack_b4 = 0x3eddddd3;
  uStack_b0 = 0;
  uStack_ac = 0x3f19999a;
  uStack_a0 = 0x3f22221d;
  uStack_a8 = CONCAT44(DAT_0191a2b0,DAT_018ce2f8);
  uStack_94 = CONCAT44(DAT_0191a30c,DAT_018ce2f8);
  uStack_80 = CONCAT44(DAT_0191a33c,DAT_018ce2f8);
  uStack_8c = 0x3f555550;
  uStack_78 = 0x3f6eeee9;
  uStack_64 = 0x3f77777d;
  uStack_6c = CONCAT44(DAT_0191a344,DAT_018ce2f8);
  uStack_50 = 0x3f800000;
  uStack_3c = 0x3f800000;
  uStack_28 = 0x3f800000;
  uStack_58 = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_9c = 0;
  uStack_98 = 0x3f2aaab0;
  uStack_88 = 0;
  uStack_84 = 0x3f3bbbb6;
  uStack_74 = 0;
  uStack_70 = 0x3f4ccccd;
  uStack_60 = 0;
  uStack_5c = 0x3f5ddde3;
  uStack_4c = 0;
  uStack_48 = 0x3f6eeee9;
  uStack_44 = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_38 = 0;
  uStack_34 = 0x3f800000;
  uStack_30 = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_24 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_0084e430(&uStack_160,&uStack_20,uStack_20);
  uStack_8 = 0;
  FUN_00a8e070(&uStack_1c,0);
  FUN_00617bc0();
  FUN_016f3654(&LAB_0187fbe0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 286 ; VA 0x0047dca0 ; FUN_0047dca0 */

void FUN_0047dca0(void)

{
  undefined4 uStack_160;
  undefined8 uStack_15c;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined8 uStack_148;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined8 uStack_134;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined8 uStack_120;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined8 uStack_10c;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined8 uStack_d0;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined8 uStack_bc;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b78f8;
  pvStack_10 = ExceptionList;
  uStack_15c = CONCAT44(DAT_0191a1cc,DAT_018ce2f8);
  uStack_148 = CONCAT44(DAT_0191a1cc,DAT_018ce2f8);
  uStack_134 = CONCAT44(DAT_0191a1cc,DAT_018ce2f8);
  uStack_120 = CONCAT44(DAT_0191a1cc,DAT_018ce2f8);
  uStack_10c = CONCAT44(DAT_0191a1cc,DAT_018ce2f8);
  uStack_154 = 0;
  uStack_f8 = CONCAT44(DAT_0191a218,DAT_0191a358);
  uStack_140 = 0;
  uStack_12c = 0;
  uStack_118 = 0;
  uStack_e4 = CONCAT44(DAT_018fde64,DAT_0191a358);
  uStack_104 = 0;
  uStack_f0 = 0x3e2aaac1;
  uStack_dc = 0x3e99999a;
  uStack_d0 = CONCAT44(DAT_0191a250,DAT_0191a358);
  uStack_c8 = 0x3ebbbbc7;
  uStack_160 = 0;
  uStack_150 = 0;
  uStack_14c = 0x3d8888b5;
  uStack_13c = 0;
  uStack_138 = 0x3e088872;
  uStack_128 = 0;
  uStack_124 = 0x3e4ccccd;
  uStack_114 = 0;
  uStack_110 = 0x3e888894;
  uStack_100 = 0;
  uStack_fc = 0x3eaaaa9f;
  uStack_ec = 0;
  uStack_e8 = 0x3ecccccd;
  uStack_d8 = 0;
  uStack_d4 = 0x3eeeeefa;
  uStack_c4 = 0;
  uStack_c0 = 0x3f088883;
  uStack_bc = CONCAT44(DAT_0191a268,DAT_0191a358);
  uStack_b4 = 0x3eddddd3;
  uStack_b0 = 0;
  uStack_ac = 0x3f19999a;
  uStack_a0 = 0x3f22221d;
  uStack_a8 = CONCAT44(DAT_0191a2b4,DAT_018ce2f8);
  uStack_94 = CONCAT44(DAT_0191a30c,DAT_018ce2f8);
  uStack_80 = CONCAT44(DAT_0191a33c,DAT_018ce2f8);
  uStack_8c = 0x3f555550;
  uStack_78 = 0x3f6eeee9;
  uStack_64 = 0x3f77777d;
  uStack_6c = CONCAT44(DAT_0191a344,DAT_018ce2f8);
  uStack_50 = 0x3f800000;
  uStack_3c = 0x3f800000;
  uStack_28 = 0x3f800000;
  uStack_58 = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_9c = 0;
  uStack_98 = 0x3f2aaab0;
  uStack_88 = 0;
  uStack_84 = 0x3f3bbbb6;
  uStack_74 = 0;
  uStack_70 = 0x3f4ccccd;
  uStack_60 = 0;
  uStack_5c = 0x3f5ddde3;
  uStack_4c = 0;
  uStack_48 = 0x3f6eeee9;
  uStack_44 = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_38 = 0;
  uStack_34 = 0x3f800000;
  uStack_30 = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_24 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_0084e430(&uStack_160,&uStack_20,uStack_20);
  uStack_8 = 0;
  FUN_00a8e070(&uStack_1c,0);
  FUN_00617bc0();
  FUN_016f3654(&LAB_0187fbf0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 287 ; VA 0x0047e060 ; FUN_0047e060 */

void FUN_0047e060(void)

{
  undefined4 uStack_160;
  undefined8 uStack_15c;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined8 uStack_148;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined8 uStack_134;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined8 uStack_120;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined8 uStack_10c;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined8 uStack_d0;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined8 uStack_bc;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b78f8;
  pvStack_10 = ExceptionList;
  uStack_15c = CONCAT44(DAT_0191a354,DAT_0191a354);
  uStack_148 = CONCAT44(DAT_0191a358,DAT_0191a358);
  uStack_134 = CONCAT44(DAT_0191a354,DAT_0191a354);
  uStack_120 = CONCAT44(DAT_0191a354,DAT_0191a354);
  uStack_10c = CONCAT44(DAT_0191a354,DAT_0191a354);
  uStack_f8 = CONCAT44(DAT_0191a354,DAT_0191a354);
  uStack_154 = 0x3f7efef8;
  uStack_e4 = CONCAT44(DAT_0191a354,DAT_0191a354);
  uStack_140 = 0x3f7f7f7c;
  uStack_12c = 0x3f7efef8;
  uStack_118 = 0x3f7efef8;
  uStack_104 = 0x3f7efef8;
  uStack_d0 = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_f0 = 0x3f7efef8;
  uStack_dc = 0x3f7efef8;
  uStack_bc = CONCAT44(DAT_0191a354,DAT_0191a354);
  uStack_c8 = 0x3f800000;
  uStack_b4 = 0x3f7efef8;
  uStack_160 = 0;
  uStack_150 = 0;
  uStack_14c = 0x3d8888b5;
  uStack_13c = 0;
  uStack_138 = 0x3e088872;
  uStack_128 = 0;
  uStack_124 = 0x3e4ccccd;
  uStack_114 = 0;
  uStack_110 = 0x3e888894;
  uStack_100 = 0;
  uStack_fc = 0x3eaaaa9f;
  uStack_ec = 0;
  uStack_e8 = 0x3ecccccd;
  uStack_d8 = 0;
  uStack_d4 = 0x3eeeeefa;
  uStack_c4 = 0;
  uStack_c0 = 0x3f088883;
  uStack_b0 = 0;
  uStack_ac = 0x3f19999a;
  uStack_a8 = CONCAT44(DAT_0191a354,DAT_0191a354);
  uStack_a0 = 0x3f7efef8;
  uStack_8c = 0x3f800000;
  uStack_94 = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_78 = 0x3f7efef8;
  uStack_64 = 0x3f800000;
  uStack_80 = CONCAT44(DAT_0191a354,DAT_0191a354);
  uStack_50 = 0x3f7efef8;
  uStack_3c = 0x3f800000;
  uStack_28 = 0x3f800000;
  uStack_6c = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_9c = 0;
  uStack_98 = 0x3f2aaab0;
  uStack_88 = 0;
  uStack_84 = 0x3f3bbbb6;
  uStack_74 = 0;
  uStack_70 = 0x3f4ccccd;
  uStack_60 = 0;
  uStack_5c = 0x3f5ddde3;
  uStack_58 = CONCAT44(DAT_0191a354,DAT_0191a354);
  uStack_4c = 0;
  uStack_48 = 0x3f6eeee9;
  uStack_44 = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_38 = 0;
  uStack_34 = 0x3f800000;
  uStack_30 = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_24 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_0084e430(&uStack_160,&uStack_20,uStack_20);
  uStack_8 = 0;
  FUN_00a8e070(&uStack_1c,0);
  FUN_00617bc0();
  FUN_016f3654(&LAB_0187fc00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 288 ; VA 0x0047e3e0 ; FUN_0047e3e0 */

void FUN_0047e3e0(void)

{
  undefined4 uStack_160;
  undefined8 uStack_15c;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined8 uStack_148;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined8 uStack_134;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined8 uStack_120;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined8 uStack_10c;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined8 uStack_d0;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined8 uStack_bc;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b78f8;
  pvStack_10 = ExceptionList;
  uStack_15c = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_134 = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_148 = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_120 = CONCAT44(DAT_0191a320,DAT_0191a330);
  uStack_10c = CONCAT44(DAT_0191a2c0,DAT_0191a2fc);
  uStack_154 = 0x3f800000;
  uStack_140 = 0x3f800000;
  uStack_12c = 0x3f800000;
  uStack_e4 = CONCAT44(DAT_0191a264,DAT_0191a264);
  uStack_118 = 0x3f60e0db;
  uStack_f8 = CONCAT44(DAT_0191a2a8,DAT_0191a2f0);
  uStack_104 = 0x3f2aaab0;
  uStack_f0 = 0x3f1a9aa2;
  uStack_d0 = CONCAT44(DAT_0191a260,DAT_0191a288);
  uStack_dc = 0x3ef2f2fa;
  uStack_c8 = 0x3ecccccd;
  uStack_bc = CONCAT44(DAT_0191a280,DAT_0191a27c);
  uStack_160 = 0;
  uStack_150 = 0;
  uStack_14c = 0x3d8888b5;
  uStack_13c = 0;
  uStack_138 = 0x3e088872;
  uStack_128 = 0;
  uStack_124 = 0x3e4ccccd;
  uStack_114 = 0;
  uStack_110 = 0x3e888894;
  uStack_100 = 0;
  uStack_fc = 0x3eaaaa9f;
  uStack_ec = 0;
  uStack_e8 = 0x3ecccccd;
  uStack_d8 = 0;
  uStack_d4 = 0x3eeeeefa;
  uStack_c4 = 0;
  uStack_c0 = 0x3f088883;
  uStack_b4 = 0x3f03838c;
  uStack_b0 = 0;
  uStack_a8 = CONCAT44(DAT_0191a2a0,DAT_0191a284);
  uStack_a0 = 0x3edcdcec;
  uStack_94 = CONCAT44(DAT_0191a294,DAT_0191a2cc);
  uStack_8c = 0x3f07878b;
  uStack_78 = 0x3f03838c;
  uStack_64 = 0x3f0a8a83;
  uStack_80 = CONCAT44(DAT_0191a298,DAT_0191a2a4);
  uStack_50 = 0x3f189891;
  uStack_3c = 0x3f3ababf;
  uStack_28 = 0x3f62e2eb;
  uStack_6c = CONCAT44(DAT_0191a29c,DAT_0191a2ac);
  uStack_ac = 0x3f19999a;
  uStack_9c = 0;
  uStack_98 = 0x3f2aaab0;
  uStack_88 = 0;
  uStack_84 = 0x3f3bbbb6;
  uStack_74 = 0;
  uStack_70 = 0x3f4ccccd;
  uStack_60 = 0;
  uStack_5c = 0x3f5ddde3;
  uStack_58 = CONCAT44(DAT_0191a2a8,DAT_0191a2c0);
  uStack_4c = 0;
  uStack_48 = 0x3f6eeee9;
  uStack_44 = CONCAT44(DAT_0191a2d8,DAT_0191a2f0);
  uStack_38 = 0;
  uStack_34 = 0x3f800000;
  uStack_30 = CONCAT44(DAT_0191a328,DAT_0191a334);
  uStack_24 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_0084e430(&uStack_160,&uStack_20,uStack_20);
  uStack_8 = 0;
  FUN_00a8e070(&uStack_1c,0);
  FUN_00617bc0();
  FUN_016f3654(&LAB_0187fc10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 289 ; VA 0x0047e7e0 ; FUN_0047e7e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0047e7e0(void)

{
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b78d8;
  pvStack_10 = ExceptionList;
  uStack_e0 = _DAT_0191a7c0;
  uStack_dc = _UNK_0191a7c4;
  uStack_d8 = _UNK_0191a7c8;
  uStack_d4 = _UNK_0191a7cc;
  uStack_1c = 0;
  uStack_d0 = _DAT_0191a880;
  uStack_cc = _UNK_0191a884;
  uStack_c8 = _UNK_0191a888;
  uStack_c4 = _UNK_0191a88c;
  uStack_c0 = _DAT_0191a800;
  uStack_bc = _UNK_0191a804;
  uStack_b8 = _UNK_0191a808;
  uStack_b4 = _UNK_0191a80c;
  uStack_b0 = _DAT_0191a830;
  uStack_ac = _UNK_0191a834;
  uStack_a8 = _UNK_0191a838;
  uStack_a4 = _UNK_0191a83c;
  uStack_18 = 0;
  uStack_a0 = _DAT_0191a850;
  uStack_9c = _UNK_0191a854;
  uStack_98 = _UNK_0191a858;
  uStack_94 = _UNK_0191a85c;
  uStack_14 = 0;
  uStack_90 = _DAT_0191a810;
  uStack_8c = _UNK_0191a814;
  uStack_88 = _UNK_0191a818;
  uStack_84 = _UNK_0191a81c;
  uStack_80 = _DAT_0191a870;
  uStack_7c = _UNK_0191a874;
  uStack_78 = _UNK_0191a878;
  uStack_74 = _UNK_0191a87c;
  uStack_70 = _DAT_0191a840;
  uStack_6c = _UNK_0191a844;
  uStack_68 = _UNK_0191a848;
  uStack_64 = _UNK_0191a84c;
  uStack_60 = _DAT_0191a7f0;
  uStack_5c = _UNK_0191a7f4;
  uStack_58 = _UNK_0191a7f8;
  uStack_54 = _UNK_0191a7fc;
  uStack_50 = _DAT_0191a8a0;
  uStack_4c = _UNK_0191a8a4;
  uStack_48 = _UNK_0191a8a8;
  uStack_44 = _UNK_0191a8ac;
  uStack_40 = _DAT_0191a790;
  uStack_3c = _UNK_0191a794;
  uStack_38 = _UNK_0191a798;
  uStack_34 = _UNK_0191a79c;
  uStack_30 = _DAT_0191a780;
  uStack_2c = _UNK_0191a784;
  uStack_28 = _UNK_0191a788;
  uStack_24 = _UNK_0191a78c;
  ExceptionList = &pvStack_10;
  FUN_0084e500(&uStack_e0,&uStack_20,uStack_20);
  uStack_8 = 0;
  FUN_00a92d50(&uStack_1c,0);
  FUN_00617ad0();
  FUN_016f3654(&LAB_0187fc20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 290 ; VA 0x0047e900 ; FUN_0047e900 */

void FUN_0047e900(void)

{
  undefined4 uStack_160;
  undefined8 uStack_15c;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined8 uStack_148;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined8 uStack_134;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined8 uStack_120;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined8 uStack_10c;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined8 uStack_d0;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined8 uStack_bc;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b78f8;
  pvStack_10 = ExceptionList;
  uStack_148 = CONCAT44(DAT_0191a714,DAT_0191a240);
  uStack_134 = CONCAT44(DAT_0191a710,DAT_0191a6d4);
  uStack_120 = CONCAT44(DAT_0191a700,DAT_0191a6cc);
  uStack_15c = CONCAT44(DAT_0191a720,DAT_0191a6e0);
  uStack_154 = 0x3f575760;
  uStack_f8 = CONCAT44(DAT_0191a6f0,DAT_0191a6c4);
  uStack_140 = 0x3f46464a;
  uStack_12c = 0x3f353533;
  uStack_118 = 0x3f25a5a9;
  uStack_e4 = CONCAT44(DAT_0191a6ec,DAT_0191a6bc);
  uStack_104 = 0x3f19999a;
  uStack_f0 = 0x3f129292;
  uStack_10c = CONCAT44(DAT_0191a6fc,DAT_0191a6c8);
  uStack_dc = 0x3f0f0f17;
  uStack_d0 = CONCAT44(DAT_0191a6e8,DAT_0191a6b8);
  uStack_c8 = 0x3f0e0e0f;
  uStack_160 = 0;
  uStack_150 = 0;
  uStack_14c = 0x3d8888b5;
  uStack_13c = 0;
  uStack_138 = 0x3e088872;
  uStack_128 = 0;
  uStack_124 = 0x3e4ccccd;
  uStack_114 = 0;
  uStack_110 = 0x3e888894;
  uStack_100 = 0;
  uStack_fc = 0x3eaaaa9f;
  uStack_ec = 0;
  uStack_e8 = 0x3ecccccd;
  uStack_d8 = 0;
  uStack_d4 = 0x3eeeeefa;
  uStack_c4 = 0;
  uStack_c0 = 0x3f088883;
  uStack_bc = CONCAT44(DAT_0191a6e4,DAT_0191a6b4);
  uStack_b4 = 0x3f0d8d8b;
  uStack_a8 = CONCAT44(DAT_0191a6e4,DAT_0191a6b4);
  uStack_94 = CONCAT44(DAT_0191a6e4,DAT_0191a6b4);
  uStack_a0 = 0x3f0d0d06;
  uStack_8c = 0x3f0d8d8b;
  uStack_80 = CONCAT44(DAT_0191a6e4,DAT_0191a6b4);
  uStack_78 = 0x3f0d8d8b;
  uStack_64 = 0x3f0d8d8b;
  uStack_50 = 0x3f0d8d8b;
  uStack_6c = CONCAT44(DAT_0191a6e4,DAT_0191a6b4);
  uStack_3c = 0x3f0d0d06;
  uStack_28 = 0x3f0d8d8b;
  uStack_58 = CONCAT44(DAT_0191a6e4,DAT_0191a6b4);
  uStack_b0 = 0;
  uStack_ac = 0x3f19999a;
  uStack_9c = 0;
  uStack_98 = 0x3f2aaab0;
  uStack_88 = 0;
  uStack_84 = 0x3f3bbbb6;
  uStack_74 = 0;
  uStack_70 = 0x3f4ccccd;
  uStack_60 = 0;
  uStack_5c = 0x3f5ddde3;
  uStack_4c = 0;
  uStack_48 = 0x3f6eeee9;
  uStack_44 = CONCAT44(DAT_0191a6e4,DAT_0191a6b4);
  uStack_38 = 0;
  uStack_34 = 0x3f800000;
  uStack_30 = CONCAT44(DAT_0191a6e4,DAT_0191a6b4);
  uStack_24 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_0084e430(&uStack_160,&uStack_20,uStack_20);
  uStack_8 = 0;
  FUN_00a8e070(&uStack_1c,0);
  FUN_00617bc0();
  FUN_016f3654(&LAB_0187fc30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 291 ; VA 0x0047ece0 ; FUN_0047ece0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0047ece0(void)

{
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b78d8;
  pvStack_10 = ExceptionList;
  uStack_e0 = _DAT_0191a7b0;
  uStack_dc = _UNK_0191a7b4;
  uStack_d8 = _UNK_0191a7b8;
  uStack_d4 = _UNK_0191a7bc;
  uStack_1c = 0;
  uStack_d0 = _DAT_0191a7a0;
  uStack_cc = _UNK_0191a7a4;
  uStack_c8 = _UNK_0191a7a8;
  uStack_c4 = _UNK_0191a7ac;
  uStack_c0 = _DAT_0191a760;
  uStack_bc = _UNK_0191a764;
  uStack_b8 = _UNK_0191a768;
  uStack_b4 = _UNK_0191a76c;
  uStack_b0 = _DAT_0191a820;
  uStack_ac = _UNK_0191a824;
  uStack_a8 = _UNK_0191a828;
  uStack_a4 = _UNK_0191a82c;
  uStack_18 = 0;
  uStack_a0 = _DAT_0191a7e0;
  uStack_9c = _UNK_0191a7e4;
  uStack_98 = _UNK_0191a7e8;
  uStack_94 = _UNK_0191a7ec;
  uStack_14 = 0;
  uStack_90 = _DAT_0191a770;
  uStack_8c = _UNK_0191a774;
  uStack_88 = _UNK_0191a778;
  uStack_84 = _UNK_0191a77c;
  uStack_80 = _DAT_0191a860;
  uStack_7c = _UNK_0191a864;
  uStack_78 = _UNK_0191a868;
  uStack_74 = _UNK_0191a86c;
  uStack_70 = _DAT_0191a7d0;
  uStack_6c = _UNK_0191a7d4;
  uStack_68 = _UNK_0191a7d8;
  uStack_64 = _UNK_0191a7dc;
  uStack_60 = _DAT_0191a750;
  uStack_5c = _UNK_0191a754;
  uStack_58 = _UNK_0191a758;
  uStack_54 = _UNK_0191a75c;
  uStack_50 = _DAT_0191a890;
  uStack_4c = _UNK_0191a894;
  uStack_48 = _UNK_0191a898;
  uStack_44 = _UNK_0191a89c;
  uStack_40 = _DAT_0191a3a0;
  uStack_3c = _UNK_0191a3a4;
  uStack_38 = _UNK_0191a3a8;
  uStack_34 = _UNK_0191a3ac;
  uStack_30 = _DAT_019189f0;
  uStack_2c = _UNK_019189f4;
  uStack_28 = _UNK_019189f8;
  uStack_24 = _UNK_019189fc;
  ExceptionList = &pvStack_10;
  FUN_0084e500(&uStack_e0,&uStack_20,uStack_20);
  uStack_8 = 0;
  FUN_00a92d50(&uStack_1c,0);
  FUN_00617ad0();
  FUN_016f3654(&LAB_0187fc40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 292 ; VA 0x0047ee00 ; FUN_0047ee00 */

void FUN_0047ee00(void)

{
  undefined4 uStack_160;
  undefined8 uStack_15c;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined8 uStack_148;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined8 uStack_134;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined8 uStack_120;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined8 uStack_10c;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined8 uStack_d0;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined8 uStack_bc;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b78f8;
  pvStack_10 = ExceptionList;
  uStack_15c = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_148 = CONCAT44(DAT_0191a350,DAT_0191a350);
  uStack_134 = CONCAT44(DAT_0191a324,DAT_0191a728);
  uStack_120 = CONCAT44(DAT_0191a724,DAT_0191a2fc);
  uStack_10c = CONCAT44(DAT_0191a71c,DAT_0191a718);
  uStack_f8 = CONCAT44(DAT_0191a70c,DAT_0191a708);
  uStack_154 = 0x3f800000;
  uStack_140 = 0x3f7e7e84;
  uStack_12c = 0x3f63635e;
  uStack_e4 = CONCAT44(DAT_0191a6f4,DAT_0191a6f8);
  uStack_118 = 0x3f46c6ce;
  uStack_104 = 0x3f28282c;
  uStack_f0 = 0x3f0b0b07;
  uStack_d0 = CONCAT44(DAT_0191a6dc,DAT_0191a6d8);
  uStack_dc = 0x3edbdbe4;
  uStack_c8 = 0x3e9c9c91;
  uStack_bc = CONCAT44(DAT_0191a6d0,DAT_0191a224);
  uStack_160 = 0;
  uStack_150 = 0;
  uStack_14c = 0x3d8888b5;
  uStack_13c = 0;
  uStack_138 = 0x3e088872;
  uStack_128 = 0;
  uStack_124 = 0x3e4ccccd;
  uStack_114 = 0;
  uStack_110 = 0x3e888894;
  uStack_100 = 0;
  uStack_fc = 0x3eaaaa9f;
  uStack_ec = 0;
  uStack_e8 = 0x3ecccccd;
  uStack_d8 = 0;
  uStack_d4 = 0x3eeeeefa;
  uStack_c4 = 0;
  uStack_c0 = 0x3f088883;
  uStack_b4 = 0x3e44c4ce;
  uStack_b0 = 0;
  uStack_94 = 0;
  uStack_a0 = 0x3da0a06f;
  uStack_80 = 0;
  uStack_8c = 0;
  uStack_78 = 0;
  uStack_64 = 0;
  uStack_6c = 0;
  uStack_50 = 0;
  uStack_3c = 0;
  uStack_28 = 0;
  uStack_58 = 0;
  uStack_ac = 0x3f19999a;
  uStack_a8 = CONCAT44(DAT_0191a6c0,DAT_0191a1ec);
  uStack_9c = 0;
  uStack_98 = 0x3f2aaab0;
  uStack_88 = 0;
  uStack_84 = 0x3f3bbbb6;
  uStack_74 = 0;
  uStack_70 = 0x3f4ccccd;
  uStack_60 = 0;
  uStack_5c = 0x3f5ddde3;
  uStack_4c = 0;
  uStack_48 = 0x3f6eeee9;
  uStack_44 = 0;
  uStack_38 = 0;
  uStack_34 = 0x3f800000;
  uStack_30 = 0;
  uStack_24 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_0084e430(&uStack_160,&uStack_20,uStack_20);
  uStack_8 = 0;
  FUN_00a8e070(&uStack_1c,0);
  FUN_00617bc0();
  FUN_016f3654(&LAB_0187fc50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 293 ; VA 0x0047f1e0 ; FUN_0047f1e0 */

void FUN_0047f1e0(void)

{
  undefined4 uStack_160;
  undefined8 uStack_15c;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined8 uStack_148;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined8 uStack_134;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined8 uStack_120;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined8 uStack_10c;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined8 uStack_d0;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined8 uStack_bc;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b78f8;
  pvStack_10 = ExceptionList;
  uStack_15c = CONCAT44(DAT_0191a300,DAT_0191a278);
  uStack_148 = CONCAT44(DAT_01901f3c,DAT_0191a258);
  uStack_134 = CONCAT44(DAT_0191a2ac,DAT_0191a23c);
  uStack_120 = CONCAT44(DAT_0191a28c,DAT_0191a21c);
  uStack_10c = CONCAT44(DAT_0191a270,DAT_0191a1fc);
  uStack_f8 = CONCAT44(DAT_0191a254,DAT_0191a1ec);
  uStack_154 = 0x3f67676f;
  uStack_140 = 0x3f63635e;
  uStack_12c = 0x3f5adadc;
  uStack_118 = 0x3f44c4bd;
  uStack_e4 = CONCAT44(DAT_0191a244,DAT_0191a1f8);
  uStack_104 = 0x3f30302b;
  uStack_d0 = CONCAT44(DAT_0191a230,DAT_0191a200);
  uStack_f0 = 0x3f20a0a1;
  uStack_dc = 0x3f0f0f17;
  uStack_160 = 0;
  uStack_150 = 0;
  uStack_14c = 0x3d8888b5;
  uStack_13c = 0;
  uStack_138 = 0x3e088872;
  uStack_128 = 0;
  uStack_124 = 0x3e4ccccd;
  uStack_114 = 0;
  uStack_110 = 0x3e888894;
  uStack_100 = 0;
  uStack_fc = 0x3eaaaa9f;
  uStack_ec = 0;
  uStack_e8 = 0x3ecccccd;
  uStack_d8 = 0;
  uStack_d4 = 0x3eeeeefa;
  uStack_c8 = 0x3f030308;
  uStack_c4 = 0;
  uStack_c0 = 0x3f088883;
  uStack_bc = CONCAT44(DAT_0191a22c,DAT_0191a200);
  uStack_b4 = 0x3ef6f6f9;
  uStack_a8 = CONCAT44(DAT_0191a228,DAT_0191a200);
  uStack_a0 = 0x3eeeeefa;
  uStack_8c = 0x3ec5c5d6;
  uStack_78 = 0x3e9696a2;
  uStack_64 = 0x3e54d4cc;
  uStack_50 = 0x3df8f92b;
  uStack_3c = 0x3d60e0eb;
  uStack_28 = 0;
  uStack_6c = CONCAT44(DAT_0191a1e8,DAT_0191a1e4);
  uStack_58 = CONCAT44(DAT_0191a1dc,DAT_0191a1dc);
  uStack_b0 = 0;
  uStack_ac = 0x3f19999a;
  uStack_9c = 0;
  uStack_98 = 0x3f2aaab0;
  uStack_94 = CONCAT44(DAT_0191a20c,DAT_0191a200);
  uStack_88 = 0;
  uStack_84 = 0x3f3bbbb6;
  uStack_80 = CONCAT44(DAT_0191a204,DAT_0191a1ec);
  uStack_74 = 0;
  uStack_70 = 0x3f4ccccd;
  uStack_60 = 0;
  uStack_5c = 0x3f5ddde3;
  uStack_4c = 0;
  uStack_48 = 0x3f6eeee9;
  uStack_44 = CONCAT44(DAT_0191a1d0,DAT_0191a1d8);
  uStack_38 = 0;
  uStack_34 = 0x3f800000;
  uStack_30 = 0;
  uStack_24 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_0084e430(&uStack_160,&uStack_20,uStack_20);
  uStack_8 = 0;
  FUN_00a8e070(&uStack_1c,0);
  FUN_00617bc0();
  FUN_016f3654(&LAB_0187fc60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 294 ; VA 0x0047f5f0 ; FUN_0047f5f0 */

void FUN_0047f5f0(void)

{
  undefined4 uStack_160;
  undefined8 uStack_15c;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined8 uStack_148;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined8 uStack_134;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined8 uStack_120;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined8 uStack_10c;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined8 uStack_f8;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined8 uStack_d0;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined8 uStack_bc;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined8 uStack_94;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b78f8;
  pvStack_10 = ExceptionList;
  uStack_15c = CONCAT44(DAT_0191a354,DAT_0191a354);
  uStack_148 = CONCAT44(DAT_0191a358,DAT_0191a358);
  uStack_134 = CONCAT44(DAT_0191a354,DAT_0191a354);
  uStack_120 = CONCAT44(DAT_0191a354,DAT_0191a354);
  uStack_10c = CONCAT44(DAT_0191a354,DAT_0191a354);
  uStack_f8 = CONCAT44(DAT_0191a354,DAT_0191a354);
  uStack_154 = 0x3f7efef8;
  uStack_e4 = CONCAT44(DAT_0191a354,DAT_0191a354);
  uStack_140 = 0x3f7f7f7c;
  uStack_12c = 0x3f7efef8;
  uStack_118 = 0x3f7efef8;
  uStack_104 = 0x3f7efef8;
  uStack_d0 = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_f0 = 0x3f7efef8;
  uStack_dc = 0x3f7efef8;
  uStack_bc = CONCAT44(DAT_0191a354,DAT_0191a354);
  uStack_c8 = 0x3f800000;
  uStack_b4 = 0x3f7efef8;
  uStack_160 = 0;
  uStack_150 = 0;
  uStack_14c = 0x3d8888b5;
  uStack_13c = 0;
  uStack_138 = 0x3e088872;
  uStack_128 = 0;
  uStack_124 = 0x3e4ccccd;
  uStack_114 = 0;
  uStack_110 = 0x3e888894;
  uStack_100 = 0;
  uStack_fc = 0x3eaaaa9f;
  uStack_ec = 0;
  uStack_e8 = 0x3ecccccd;
  uStack_d8 = 0;
  uStack_d4 = 0x3eeeeefa;
  uStack_c4 = 0;
  uStack_c0 = 0x3f088883;
  uStack_b0 = 0;
  uStack_ac = 0x3f19999a;
  uStack_a8 = CONCAT44(DAT_0191a354,DAT_0191a354);
  uStack_a0 = 0x3f7efef8;
  uStack_8c = 0x3f800000;
  uStack_94 = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_78 = 0x3f7efef8;
  uStack_64 = 0x3f800000;
  uStack_80 = CONCAT44(DAT_0191a354,DAT_0191a354);
  uStack_50 = 0x3f7efef8;
  uStack_3c = 0x3f800000;
  uStack_28 = 0x3f800000;
  uStack_6c = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_9c = 0;
  uStack_98 = 0x3f2aaab0;
  uStack_88 = 0;
  uStack_84 = 0x3f3bbbb6;
  uStack_74 = 0;
  uStack_70 = 0x3f4ccccd;
  uStack_60 = 0;
  uStack_5c = 0x3f5ddde3;
  uStack_58 = CONCAT44(DAT_0191a354,DAT_0191a354);
  uStack_4c = 0;
  uStack_48 = 0x3f6eeee9;
  uStack_44 = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_38 = 0;
  uStack_34 = 0x3f800000;
  uStack_30 = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  uStack_24 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_0084e430(&uStack_160,&uStack_20,uStack_20);
  uStack_8 = 0;
  FUN_00a8e070(&uStack_1c,0);
  FUN_00617bc0();
  FUN_016f3654(&LAB_0187fc70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 295 ; VA 0x00481650 ; FUN_00481650 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00481650(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb640;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x15;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf874) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf874,uVar3,0,0,0x15);
    if (DAT_01edf874 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01edf850 = RBX::Reflection::RefType<class_RBX::Instance*>::vftable;
      FUN_016f3654(&LAB_018813c0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edf874);
    }
  }
  uVar2 = FUN_00897b90();
  FUN_009ca670(uVar2,&DAT_01edf850,s_Parent_0211ab18,&DAT_021197d4,uVar3,uVar4,uVar5,uVar6,0,0,0);
  uStack_8 = 1;
  DAT_0211a3d8 = RBX::Reflection::RefPropDescriptor<class_RBX::Instance,class_RBX::Instance>::
                 vftable;
  _DAT_0211a40c =
       RBX::Reflection::RefPropDescriptor<class_RBX::Instance,class_RBX::Instance>::vftable;
  DAT_0211a410 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0211a410 == (undefined4 *)0x0) {
    DAT_0211a410 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211a410 =
         RBX::Reflection::PropDescriptor<class_RBX::Instance,class_RBX::Instance*>::
         GetSetImpl<class_RBX::Instance*_(__thiscall_RBX::Instance::*)(void)const_,void_(__thiscall_RBX::Instance::*)(class_RBX::Instance*)>
         ::vftable;
    DAT_0211a410[2] = FUN_005c8ab0;
    DAT_0211a410[3] = 0;
    DAT_0211a410[4] = FUN_0058bb00;
    DAT_0211a410[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_0211a3d8[3])();
  if (cVar1 != '\0') {
    _DAT_0211a3fc = _DAT_0211a3fc & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211a3d8[2])();
  if (cVar1 != '\0') {
    _DAT_0211a3fc = _DAT_0211a3fc & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01880d50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 296 ; VA 0x004818f0 ; FUN_004818f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004818f0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb66c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00897b90();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Instance,__int64>::
              GetSetImpl<__int64_(__thiscall_RBX::Instance::*)(void)const_,void_(__thiscall_RBX::Instance::*)(__int64)>
              ::vftable;
    puVar3[2] = FUN_008a2af0;
    puVar3[3] = 0;
    puVar3[4] = FUN_008a6f80;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088da50();
  FUN_009ca670(uVar2,uVar4,s_SourceAssetId_0211aadc,&DAT_021197d4,uStack_24,0,0,0x1c,5,5,0);
  DAT_0211a318 = RBX::Reflection::TypedPropertyDescriptor<__int64>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0211a34c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0211a33c = _DAT_0211a33c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0211a318[2])();
    if (cVar1 != '\0') {
      _DAT_0211a33c = _DAT_0211a33c & 0xfffffff3;
    }
  }
  DAT_0211a318 = RBX::Reflection::PropDescriptor<class_RBX::Instance,__int64>::vftable;
  FUN_016f3654(&LAB_01880db0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 297 ; VA 0x00481ab0 ; FUN_00481ab0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00481ab0(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("Attributes",10);
  _DAT_01edf5a8 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 298 ; VA 0x00481b20 ; FUN_00481b20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00481b20(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("CoreAttributes",0xe);
  _DAT_01edf5ac = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 299 ; VA 0x00481dc0 ; FUN_00481dc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00481dc0(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_0089a250(FUN_008a24f0,0,s_childAdded_0211ac10,s_child_0211abfc,0,
               CONCAT44(&DAT_0211a6c0,uStack_10),0);
  _DAT_0211a700 =
       RBX::Reflection::
       EventDesc<class_RBX::Instance,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>*_(__thiscall_RBX::Instance::*)(bool)>
       ::vftable;
  FUN_016f3654(&LAB_01880e00);
  return;
}



/* FUNCTION 300 ; VA 0x00481e20 ; FUN_00481e20 */

void FUN_00481e20(void)

{
  undefined8 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined8 *)FUN_009cb380(auStack_14,&DAT_0211a108,0x15);
  FUN_00899f50(FUN_008a3710,0,s_isDescendantOf_0211aa70,s_ancestor_0211aa54,0,*puVar1,
               *(undefined4 *)(puVar1 + 1));
  FUN_016f3654(&LAB_01880e10);
  return;
}



/* FUNCTION 301 ; VA 0x00481e80 ; FUN_00481e80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00481e80(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb6ce;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00897b90();
  FUN_009cb970(uVar1,s_AncestryChanged_0211ac58,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0211a834 = 0x48;
  iStack_8 = 0;
  _DAT_0211a800 =
       RBX::Reflection::
       EventDesc<class_RBX::Instance,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>)>_RBX::Instance::*>
       ::vftable;
  FUN_0086e3d0(s_child_0211abfc);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_parent_0211ac50);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_0211a828 = uStack_1c;
  _DAT_0211a82c = uStack_18;
  _DAT_0211a830 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_0211a800 =
       RBX::Reflection::
       EventDesc<class_RBX::Instance,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::shared_ptr<class_RBX::Instance>)>_RBX::Instance::*>
       ::vftable;
  FUN_016f3654(&LAB_01880e60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 302 ; VA 0x00481ff0 ; FUN_00481ff0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00481ff0(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb703;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00897b90();
  FUN_009cb970(uVar1,s_AttributeChanged_0211abe8,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0211a6b8 = FUN_008a24b0;
  _DAT_0211a6bc = 0;
  iStack_8 = 0;
  _DAT_0211a680 =
       RBX::Reflection::
       EventDesc<class_RBX::Instance,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>*_(__thiscall_RBX::Instance::*)(bool)>
       ::vftable;
  FUN_0086e3d0(s_attribute_0211ab54);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0211a6a8 = uStack_1c;
  _DAT_0211a6ac = uStack_18;
  _DAT_0211a6b0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_0211a680 =
       RBX::Reflection::
       EventDesc<class_RBX::Instance,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>*_(__thiscall_RBX::Instance::*)(bool)>
       ::vftable;
  FUN_016f3654(&LAB_01880e70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 303 ; VA 0x00482150 ; FUN_00482150 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00482150(void)

{
  undefined4 extraout_var;
  
  FUN_0089a250(FUN_008a24f0,0,s_ChildAdded_0211ac04,s_child_0211abfc,0,0,0,0);
  _DAT_0211a6c0 =
       RBX::Reflection::
       EventDesc<class_RBX::Instance,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>*_(__thiscall_RBX::Instance::*)(bool)>
       ::vftable;
  FUN_016f3654(&LAB_01880e80,extraout_var);
  return;
}



/* FUNCTION 304 ; VA 0x004821b0 ; FUN_004821b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004821b0(void)

{
  undefined4 extraout_var;
  
  FUN_0089a250(FUN_008a2530,0,s_ChildRemoved_0211ac1c,s_child_0211abfc,0,0,0,0);
  _DAT_0211a740 =
       RBX::Reflection::
       EventDesc<class_RBX::Instance,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>*_(__thiscall_RBX::Instance::*)(bool)>
       ::vftable;
  FUN_016f3654(&LAB_01880e90,extraout_var);
  return;
}



/* FUNCTION 305 ; VA 0x00482210 ; FUN_00482210 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00482210(void)

{
  undefined4 extraout_var;
  
  FUN_0089a250(FUN_0085e850,0,s_DescendantAdded_0211ac2c,s_descendant_0211aa80,0,0,0,0);
  _DAT_0211a780 =
       RBX::Reflection::
       EventDesc<class_RBX::Instance,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>*_(__thiscall_RBX::Instance::*)(bool)>
       ::vftable;
  FUN_016f3654(&LAB_01880ea0,extraout_var);
  return;
}



/* FUNCTION 306 ; VA 0x00482270 ; FUN_00482270 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00482270(void)

{
  undefined4 extraout_var;
  
  FUN_0089a250(FUN_008a2570,0,s_DescendantRemoving_0211ac3c,s_descendant_0211aa80,0,0,0,0);
  _DAT_0211a7c0 =
       RBX::Reflection::
       EventDesc<class_RBX::Instance,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>*_(__thiscall_RBX::Instance::*)(bool)>
       ::vftable;
  FUN_016f3654(&LAB_01880eb0,extraout_var);
  return;
}



/* FUNCTION 307 ; VA 0x004822d0 ; FUN_004822d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004822d0(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb733;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00897b90();
  FUN_009cb970(uVar1,s_Changed_0211ac74,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0211a86c = 0x4c;
  iStack_8 = 0;
  _DAT_0211a838 =
       RBX::Reflection::
       EventDesc<class_RBX::Instance,void___cdecl(class_RBX::Reflection::PropertyDescriptor_const*),class_rbx::signal<void___cdecl(class_RBX::Reflection::PropertyDescriptor_const*)>,class_rbx::signal<void___cdecl(class_RBX::Reflection::PropertyDescriptor_const*)>_RBX::Instance::*>
       ::vftable;
  FUN_0086e3d0(s_property_0211ac68);
  FUN_009ca3d0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0211a860 = uStack_1c;
  _DAT_0211a864 = uStack_18;
  _DAT_0211a868 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_0211a838 =
       RBX::Reflection::
       EventDesc<class_RBX::Instance,void___cdecl(class_RBX::Reflection::PropertyDescriptor_const*),class_rbx::signal<void___cdecl(class_RBX::Reflection::PropertyDescriptor_const*)>,class_rbx::signal<void___cdecl(class_RBX::Reflection::PropertyDescriptor_const*)>_RBX::Instance::*>
       ::vftable;
  FUN_016f3654(&LAB_01880ec0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 308 ; VA 0x00482420 ; FUN_00482420 */

void FUN_00482420(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00899ea0(FUN_0063a700,0,s_FindFirstChild_0211a944,&DAT_0211a93c,s_recursive_0211a930,0,0,
               uStack_10,0);
  FUN_016f3654(&LAB_01880ed0);
  return;
}



/* FUNCTION 309 ; VA 0x00482480 ; FUN_00482480 */

void FUN_00482480(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00899ea0(FUN_0063a700,0,s_findFirstChild_0211a954,&DAT_0211a93c,s_recursive_0211a930,0,0,
               uStack_10,0);
  FUN_016f3654(&LAB_01880f00);
  return;
}



/* FUNCTION 310 ; VA 0x004824e0 ; FUN_004824e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004824e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb74a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00897b90(uVar2,0);
  FUN_009cb790(uVar1,s_Destroy_0211aa14,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02119f88 = RBX::Reflection::BoundFuncDesc<class_RBX::Instance,void___cdecl(void),0>::vftable;
  _DAT_02119fc0 = &LAB_00696ba6;
  _DAT_02119fc4 = 0;
  _DAT_02119fac = FUN_00888530();
  FUN_016f3654(&LAB_01880f30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 311 ; VA 0x00482580 ; FUN_00482580 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00482580(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb7ac;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00897b90();
  FUN_009cb790(uVar2,s_GetAttribute_0211ab60,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211a4c0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Instance,class_RBX::Reflection::Variant___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&)const_,1>
       ::vftable;
  _DAT_0211a4f8 = FUN_008a1e50;
  _DAT_0211a4fc = 0;
  DAT_0211a500 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211a4e4 = FUN_00888410();
  iVar1 = DAT_0211a500;
  if (DAT_0211a500 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_attribute_0211ab54);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01880f40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 312 ; VA 0x00482730 ; FUN_00482730 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00482730(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb7ca;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00897b90(uVar2,0);
  FUN_009cb790(uVar1,s_GetAttributes_0211ab88,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211a550 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Instance,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(void)const_,0>
       ::vftable;
  _DAT_0211a588 = FUN_008a2020;
  _DAT_0211a58c = 0;
  _DAT_0211a574 = FUN_008881d0();
  FUN_016f3654(&LAB_01880f60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 313 ; VA 0x004827d0 ; FUN_004827d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004827d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb7ea;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00897b90(uVar2,0);
  FUN_009cb790(uVar1,s_GetDescendants_0211aab4,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211a228 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Instance,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0211a260 = 0;
  _DAT_0211a264 = 0;
  _DAT_0211a24c = FUN_008882f0();
  _DAT_0211a228 =
       RBX::Reflection::
       CustomBoundFuncDesc<class_RBX::Instance,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0211a268 = FUN_008a2330;
  _DAT_0211a26c = 0;
  _DAT_0211a25c = 1;
  FUN_016f3654(&LAB_01880f70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 314 ; VA 0x004828a0 ; FUN_004828a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004828a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb80a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00897b90(uVar2,0);
  FUN_009cb790(uVar1,s_GetFullName_0211aa48,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211a0c8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Instance,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(void),0>
       ::vftable;
  _DAT_0211a100 = FUN_008a2480;
  _DAT_0211a104 = 0;
  _DAT_0211a0ec = FUN_0088cb40();
  FUN_016f3654(&LAB_01880f80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 315 ; VA 0x00482940 ; FUN_00482940 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00482940(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb86c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00897b90();
  FUN_009cb790(uVar1,s_GetDebugId_0211aaa8,1,CONCAT44(uStack_1c,uStack_20),0);
  uStack_8 = 0;
  _DAT_0211a1e0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Instance,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(int),1>
       ::vftable;
  _DAT_0211a218 = FUN_008a2ac0;
  _DAT_0211a21c = 0;
  DAT_0211a220 = (undefined4 *)FUN_01674e20(4);
  if (DAT_0211a220 == (undefined4 *)0x0) {
    DAT_0211a220 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211a220 = 4;
  }
  uStack_8._0_1_ = 1;
  _DAT_0211a204 = FUN_0088cb40();
  puVar3 = DAT_0211a220;
  if (DAT_0211a220 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088c8c0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_005c9cc0();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(s_scopeLength_0211aa9c);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01880f90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 316 ; VA 0x00482b00 ; FUN_00482b00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00482b00(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb88a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00897b90(uVar2,0);
  FUN_009cb790(uVar1,s_Remove_0211a9f0,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02119ec8 = RBX::Reflection::BoundFuncDesc<class_RBX::Instance,void___cdecl(void),0>::vftable;
  _DAT_02119f00 = FUN_008a5010;
  _DAT_02119f04 = 0;
  _DAT_02119eec = FUN_00888530();
  FUN_016f3654(&LAB_01880fb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 317 ; VA 0x00482ba0 ; FUN_00482ba0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00482ba0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb8aa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00897b90(uVar2,0);
  FUN_009cb790(uVar1,s_ClearAllChildren_0211aa00,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02119f48 = RBX::Reflection::BoundFuncDesc<class_RBX::Instance,void___cdecl(void),0>::vftable;
  _DAT_02119f80 = FUN_0089f680;
  _DAT_02119f84 = 0;
  _DAT_02119f6c = FUN_00888530();
  FUN_016f3654(&LAB_01880fc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 318 ; VA 0x00482c40 ; FUN_00482c40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00482c40(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb8ca;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00897b90(uVar2,0);
  FUN_009cb790(uVar1,s_remove_0211a9f8,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02119f08 = RBX::Reflection::BoundFuncDesc<class_RBX::Instance,void___cdecl(void),0>::vftable;
  _DAT_02119f40 = FUN_008a5010;
  _DAT_02119f44 = 0;
  _DAT_02119f2c = FUN_00888530();
  FUN_016f3654(&LAB_01880fd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 319 ; VA 0x00482ce0 ; FUN_00482ce0 */

/* WARNING: Removing unreachable block (ram,0x00482d58) */
/* WARNING: Removing unreachable block (ram,0x00482e6b) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00482ce0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb931;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uStack_f0 = FUN_00888530();
  puStack_14 = &uStack_f0;
  puStack_ec = (undefined4 *)0x0;
  uStack_8 = 1;
  FUN_00888530();
  uStack_8._0_1_ = 2;
  uVar1 = FUN_00897b90();
  FUN_009cb790(uVar1,s_SetAttribute_0211ab78,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211a508 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Instance,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_RBX::Reflection::Variant),2>
       ::vftable;
  _DAT_0211a540 = FUN_008a5c80;
  _DAT_0211a544 = 0;
  _DAT_0211a548 = 0;
  uStack_8._0_1_ = 4;
  puVar2 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 5;
  puStack_14 = puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    DAT_0211a54c = (undefined4 *)0x0;
  }
  else {
    *puVar2 = uStack_f0;
    puVar2[1] = 0;
    if (puStack_ec != (undefined4 *)0x0) {
      (*(code *)*puStack_ec)();
    }
    puVar2[1] = puStack_ec;
    DAT_0211a54c = puVar2;
  }
  uStack_8._0_1_ = 6;
  FUN_0089f290();
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (puStack_ec != (undefined4 *)0x0) {
    (*(code *)puStack_ec[2])(auStack_e8);
  }
  uStack_8 = 8;
  FUN_016f3654(FUN_01880fe0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 320 ; VA 0x00482ea0 ; FUN_00482ea0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00482ea0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb95e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00897b90(uVar2,0);
  FUN_009cb790(uVar1,s_WaitForChild_0211ab00,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0211a350 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Instance,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,double),2>
       ::vftable;
  _DAT_0211a388 = 0;
  _DAT_0211a38c = 0;
  _DAT_0211a390 = 0;
  DAT_0211a394 = 0;
  uStack_8 = 2;
  FUN_0089f000();
  _DAT_0211a350 =
       RBX::Reflection::
       CustomBoundFuncDesc<class_RBX::Instance,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,double),2>
       ::vftable;
  _DAT_0211a398 = FUN_008a7e20;
  _DAT_0211a39c = 0;
  _DAT_0211a384 = 1;
  FUN_016f3654(&LAB_01881050);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 321 ; VA 0x00482fb0 ; FUN_00482fb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00482fb0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb97a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00897b90(uVar2,0);
  FUN_009cb790(uVar1,s_GetChildren_0211aa3c,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211a088 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Instance,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0211a0c0 = FUN_00696bbf;
  _DAT_0211a0c4 = 0;
  _DAT_0211a0ac = FUN_0088cc80();
  FUN_016f3654(&LAB_01881080);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 322 ; VA 0x00483050 ; FUN_00483050 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00483050(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb99a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00897b90(uVar2,0);
  FUN_009cb790(uVar1,s_getChildren_0211aa30,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211a048 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Instance,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0211a080 = FUN_00696bbf;
  _DAT_0211a084 = 0;
  _DAT_0211a06c = FUN_0088cc80();
  FUN_016f3654(&LAB_01881090);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 323 ; VA 0x004830f0 ; FUN_004830f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004830f0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb9ba;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00897b90(uVar2,0);
  FUN_009cb790(uVar1,s_children_0211aa24,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211a008 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Instance,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0211a040 = FUN_00696bbf;
  _DAT_0211a044 = 0;
  _DAT_0211a02c = FUN_0088cc80();
  FUN_016f3654(&LAB_018810a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 324 ; VA 0x00483190 ; FUN_00483190 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00483190(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb9da;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00897b90(uVar2,0);
  FUN_009cb790(uVar1,s_Clone_0211a9e0,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02119e48 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Instance,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_02119e80 = &LAB_00696bb0;
  _DAT_02119e84 = 0;
  _DAT_02119e6c = FUN_0088cdc0();
  FUN_016f3654(&LAB_018810b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 325 ; VA 0x00483230 ; FUN_00483230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00483230(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bb9fa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00897b90(uVar2,0);
  FUN_009cb790(uVar1,s_clone_0211a9e8,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02119e88 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Instance,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_02119ec0 = &LAB_00696bb0;
  _DAT_02119ec4 = 0;
  _DAT_02119eac = FUN_0088cdc0();
  FUN_016f3654(&LAB_018810c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 326 ; VA 0x004832d0 ; FUN_004832d0 */

void FUN_004832d0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00899d20(FUN_008a0f90,0,s_FindFirstAncestor_0211a994,&DAT_0211a93c,0,uStack_10,0);
  FUN_016f3654(&LAB_018810d0);
  return;
}



/* FUNCTION 327 ; VA 0x00483330 ; FUN_00483330 */

void FUN_00483330(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00899d20(FUN_008a1090,0,s_FindFirstAncestorOfClass_0211a9a8,s_className_0211a91c,0,uStack_10,0
              );
  FUN_016f3654(&LAB_018810f0);
  return;
}



/* FUNCTION 328 ; VA 0x00483390 ; FUN_00483390 */

void FUN_00483390(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00899d20(FUN_008a1190,0,s_FindFirstAncestorWhichIsA_0211a9c4,s_className_0211a91c,0,uStack_10,
               0);
  FUN_016f3654(&LAB_01881110);
  return;
}



/* FUNCTION 329 ; VA 0x004833f0 ; FUN_004833f0 */

void FUN_004833f0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00899d20(FUN_008a1410,0,s_FindFirstChildOfClass_0211a964,s_className_0211a91c,0,uStack_10,0);
  FUN_016f3654(&LAB_01881130);
  return;
}



/* FUNCTION 330 ; VA 0x00483450 ; FUN_00483450 */

void FUN_00483450(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00899ea0(FUN_008a15a0,0,s_FindFirstChildWhichIsA_0211a97c,s_className_0211a91c,
               s_recursive_0211a930,0,0,uStack_10,0);
  FUN_016f3654(&LAB_01881150);
  return;
}



/* FUNCTION 331 ; VA 0x004834b0 ; FUN_004834b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004834b0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bba1a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00897b90(uVar2,0);
  FUN_009cb790(uVar1,s_GetActor_0211ac98,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211a8b8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Instance,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_0211a8f0 = FUN_008a19e0;
  _DAT_0211a8f4 = 0;
  _DAT_0211a8dc = FUN_0088cdc0();
  FUN_016f3654(&LAB_01881180);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 332 ; VA 0x00483550 ; FUN_00483550 */

void FUN_00483550(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00899ba0(FUN_008a1b90,0,s_GetAttributeChangedSignal_0211abcc,s_attribute_0211ab54,0,uStack_10,
               0);
  FUN_016f3654(&LAB_01881190);
  return;
}



/* FUNCTION 333 ; VA 0x004835b0 ; FUN_004835b0 */

void FUN_004835b0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00899ba0(FUN_008a26f0,0,s_GetPropertyChangedSignal_0211ac7c,s_property_0211ac68,0,uStack_10,0)
  ;
  FUN_016f3654(&LAB_018811b0);
  return;
}



/* FUNCTION 334 ; VA 0x00483610 ; FUN_00483610 */

void FUN_00483610(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_0089a0b0(FUN_008a39e0,0,&DAT_0211a928,s_className_0211a91c,0,uStack_10,0);
  FUN_016f3654(&LAB_018811d0);
  return;
}



/* FUNCTION 335 ; VA 0x00483670 ; FUN_00483670 */

void FUN_00483670(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_0089a0b0(FUN_008a39e0,0,&DAT_0211a92c,s_className_0211a91c,0,uStack_10,0);
  FUN_016f3654(&LAB_018811f0);
  return;
}



/* FUNCTION 336 ; VA 0x004836d0 ; FUN_004836d0 */

void FUN_004836d0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00899f50(FUN_008a3600,0,s_IsAncestorOf_0211aa8c,s_descendant_0211aa80,0,uStack_10,0);
  FUN_016f3654(&LAB_01881210);
  return;
}



/* FUNCTION 337 ; VA 0x00483730 ; FUN_00483730 */

void FUN_00483730(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00899f50(FUN_008a3710,0,s_IsDescendantOf_0211aa60,s_ancestor_0211aa54,0,uStack_10,0);
  FUN_016f3654(&LAB_01881260);
  return;
}



/* FUNCTION 338 ; VA 0x004837d0 ; FUN_004837d0 */

void FUN_004837d0(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cb380(auStack_14,&DAT_02119b40,0x14);
  FUN_008976e0(s_archivable_0211a910,s_Behavior_0211a8f8,&LAB_008a24a0,0,&LAB_0089c009,0,*puVar1,
               puVar1[1],puVar1[2],puVar1[3],0);
  FUN_016f3654(&LAB_018812d0);
  return;
}



/* FUNCTION 339 ; VA 0x00483ba0 ; FUN_00483ba0 */

void FUN_00483ba0(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_008a8f20(FUN_008a9ce0,0,s_getService_0211aec8,s_className_0211a91c,0,
               CONCAT44(&DAT_0211acf0,uStack_10),0);
  FUN_016f3654(&LAB_018813d0);
  return;
}



/* FUNCTION 340 ; VA 0x00483c00 ; FUN_00483c00 */

void FUN_00483c00(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_008a8f20(FUN_008a9ce0,0,s_service_0211aec0,s_className_0211a91c,0,
               CONCAT44(&DAT_0211acf0,uStack_10),0);
  FUN_016f3654(&LAB_018813f0);
  return;
}



/* FUNCTION 341 ; VA 0x00483c60 ; FUN_00483c60 */

void FUN_00483c60(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_008a8f20(FUN_008a9a80,0,s_FindService_0211aea8,s_className_0211a91c,0,uStack_10,0);
  FUN_016f3654(&LAB_01881410);
  return;
}



/* FUNCTION 342 ; VA 0x00483cc0 ; FUN_00483cc0 */

void FUN_00483cc0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_008a8f20(FUN_008a9ce0,0,s_GetService_0211aeb4,s_className_0211a91c,0,uStack_10,0);
  FUN_016f3654(&LAB_01881430);
  return;
}



/* FUNCTION 343 ; VA 0x00483d30 ; FUN_00483d30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00483d30(void)

{
  undefined4 extraout_var;
  
  FUN_008a9250(0x68,s_Close_0211aed4,0,0,0,0);
  _DAT_0211adc8 =
       RBX::Reflection::
       EventDesc<class_RBX::ServiceProvider,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::ServiceProvider::*>
       ::vftable;
  FUN_016f3654(&LAB_01881450,extraout_var);
  return;
}



/* FUNCTION 344 ; VA 0x00483d80 ; FUN_00483d80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00483d80(void)

{
  undefined4 extraout_var;
  
  FUN_008a9250(0x6c,s_CloseLate_0211aedc,3,0,0,0);
  _DAT_0211ae00 =
       RBX::Reflection::
       EventDesc<class_RBX::ServiceProvider,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::ServiceProvider::*>
       ::vftable;
  FUN_016f3654(&LAB_01881460,extraout_var);
  return;
}



/* FUNCTION 345 ; VA 0x00483e40 ; FUN_00483e40 */

void FUN_00483e40(void)

{
  FUN_008aa600(s_FilteringEnabled_0211b8d0,s_Behavior_0211a8f8,0x644890,0,0x8bb130,0,0,0,0,0x1f,0,1)
  ;
  FUN_016f3654(&LAB_018814b0);
  return;
}



/* FUNCTION 346 ; VA 0x00483ee0 ; FUN_00483ee0 */

void FUN_00483ee0(void)

{
  FUN_008aa600(s_StreamingEnabled_0211b804,s_Behavior_0211a8f8,0x5d48c0,0,0x8bb190,0,0,0,0,0x1f,0,1)
  ;
  FUN_016f3654(&LAB_018814d0);
  return;
}



/* FUNCTION 347 ; VA 0x00483f80 ; FUN_00483f80 */

void FUN_00483f80(void)

{
  FUN_008aa4f0(s_StreamingMinRadius_0211b830,s_Behavior_0211a8f8,0x61f530,0,0x8bb520,0,0,0,0,0xf,0);
  FUN_016f3654(&LAB_018814f0);
  return;
}



/* FUNCTION 348 ; VA 0x00484010 ; FUN_00484010 */

void FUN_00484010(void)

{
  FUN_008aa4f0(s_StreamingTargetRadius_0211b818,s_Behavior_0211a8f8,0x6e61d0,0,0x8bb5d0,0,0,0,0,0xf,
               0);
  FUN_016f3654(&LAB_01881510);
  return;
}



/* FUNCTION 349 ; VA 0x004840a0 ; FUN_004840a0 */

void FUN_004840a0(void)

{
  FUN_008aa710(s_AllowThirdPartySales_0211b908,s_Behavior_0211a8f8,0x67c630,0,0x8b9b20,0,0,0,0,0x1d,
               0);
  FUN_016f3654(&LAB_01881530);
  return;
}



/* FUNCTION 350 ; VA 0x00484130 ; FUN_00484130 */

void FUN_00484130(void)

{
  FUN_008aa4f0(s_DataModelPlaceVersion_0211b920,s_Behavior_0211a8f8,0x8b3790,0,0x8ba2d0,0,0,0,0,2,0)
  ;
  FUN_016f3654(&LAB_01881550);
  return;
}



/* FUNCTION 351 ; VA 0x004841c0 ; FUN_004841c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004841c0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd0a4;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008bbb80();
  uVar3 = FUN_008aa870();
  FUN_009ca670(uVar3,uVar2,s_InterpolationThrottling_0211b858,s_Behavior_0211a8f8,uStack_3c,0,0,0x1f
               ,0,1,1);
  uStack_8 = 0;
  DAT_0211b028 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Workspace,enum_RBX::Workspace::InterpolationThrottlingMode>
                 ::vftable;
  _DAT_0211b05c = uVar2;
  DAT_0211b060 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_0211b060 == (undefined4 *)0x0) {
    DAT_0211b060 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_0211b060 + 2) = 0x8b39d0;
    *(undefined8 *)(DAT_0211b060 + 6) = 0x8ba960;
    *DAT_0211b060 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Workspace,enum_RBX::Workspace::InterpolationThrottlingMode>::
         GetSetImpl<enum_RBX::Workspace::InterpolationThrottlingMode_(__thiscall_RBX::Workspace::*)(void)const_,void_(__thiscall_RBX::Workspace::*)(enum_RBX::Workspace::InterpolationThrottlingMode)>
         ::vftable;
    DAT_0211b060[4] = 0;
    DAT_0211b060[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0211b064 = FUN_008bbb80();
  cVar1 = (*(code *)DAT_0211b028[3])();
  if (cVar1 != '\0') {
    _DAT_0211b04c = _DAT_0211b04c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211b028[2])();
  if (cVar1 != '\0') {
    _DAT_0211b04c = _DAT_0211b04c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01881570);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 352 ; VA 0x00484480 ; FUN_00484480 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00484480(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("FeatureEnableMeshPartHeadsApp",0x1d);
  _DAT_01edfb90 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 353 ; VA 0x00484840 ; FUN_00484840 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00484840(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffc4;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd0d0;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffc4 & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1d;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0084) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0084,uVar3,0,0,0x1d);
    if (DAT_01ee0084 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01ee0060 = RBX::Reflection::RefType<class_RBX::Camera*>::vftable;
      FUN_016f3654(&LAB_01881960);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ee0084);
    }
  }
  uVar2 = FUN_008aa870();
  FUN_009ca670(uVar2,&DAT_01ee0060,s_CurrentCamera_0211ba48,&DAT_021197d4,uVar3,uVar4,uVar5,uVar6,0,
               0,0);
  uStack_8 = 1;
  DAT_0211b524 = RBX::Reflection::RefPropDescriptor<class_RBX::Workspace,class_RBX::Camera>::vftable
  ;
  _DAT_0211b558 =
       RBX::Reflection::RefPropDescriptor<class_RBX::Workspace,class_RBX::Camera>::vftable;
  DAT_0211b55c = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_0211b55c == (undefined4 *)0x0) {
    DAT_0211b55c = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_0211b55c + 2) = 0x8b34f0;
    *(undefined8 *)(DAT_0211b55c + 6) = 0x8ba0d0;
    *DAT_0211b55c =
         RBX::Reflection::PropDescriptor<class_RBX::Workspace,class_RBX::Camera*>::
         GetSetImpl<class_RBX::Camera*_(__thiscall_RBX::Workspace::*)(void)const_,void_(__thiscall_RBX::Workspace::*)(class_RBX::Camera*)>
         ::vftable;
    DAT_0211b55c[4] = 0;
    DAT_0211b55c[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_0211b524[3])();
  if (cVar1 != '\0') {
    _DAT_0211b548 = _DAT_0211b548 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211b524[2])();
  if (cVar1 != '\0') {
    _DAT_0211b548 = _DAT_0211b548 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018815f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 354 ; VA 0x00484a00 ; FUN_00484a00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00484a00(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd0ea;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008aa870();
  FUN_009cb790(uVar1,s_ExperimentalSolverIsEnabled_0211ba98,3,uStack_1c,0);
  _DAT_0211b700 = 0x554b40;
  uStack_8 = 0;
  _DAT_0211b6c8 = RBX::Reflection::BoundFuncDesc<class_RBX::Workspace,bool___cdecl(void),0>::vftable
  ;
  _DAT_0211b708 = 0;
  _DAT_0211b6ec = FUN_0088daf0();
  FUN_016f3654(&LAB_01881610);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 355 ; VA 0x00484ab0 ; FUN_00484ab0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00484ab0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd128;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008aa870();
  FUN_009cb790(uVar1,s_CalculateJumpDistance_0211b9dc,5,uStack_1c,0);
  _DAT_0211b440 = 0x8b65e0;
  _DAT_0211b408 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Workspace,float___cdecl(float,float,float),3>::
       vftable;
  _DAT_0211b448 = 0;
  DAT_0211b44c = 0;
  DAT_0211b450 = 0;
  DAT_0211b454 = 0;
  uStack_8 = 3;
  FUN_008b1bd0(s_gravity_0211b994,s_jumpPower_0211b9b0,s_walkSpeed_0211b9d0);
  FUN_016f3654(&LAB_01881620);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 356 ; VA 0x00484b90 ; FUN_00484b90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00484b90(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd15e;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008aa870();
  FUN_009cb790(uVar1,s_CalculateJumpHeight_0211b9bc,5,uStack_1c,0);
  _DAT_0211b3f0 = 0x8b6620;
  _DAT_0211b3b8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Workspace,float___cdecl(float,float),2>::vftable;
  _DAT_0211b3f8 = 0;
  DAT_0211b3fc = 0;
  DAT_0211b400 = 0;
  uStack_8 = 2;
  FUN_008b19a0();
  FUN_016f3654(&LAB_01881670);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 357 ; VA 0x00484c60 ; FUN_00484c60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00484c60(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd18e;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008aa870();
  FUN_009cb790(uVar1,s_CalculateJumpPower_0211b99c,5,uStack_1c,0);
  _DAT_0211b3a0 = 0x8b6650;
  _DAT_0211b368 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Workspace,float___cdecl(float,float),2>::vftable;
  _DAT_0211b3a8 = 0;
  DAT_0211b3ac = 0;
  DAT_0211b3b0 = 0;
  uStack_8 = 2;
  FUN_008b19a0();
  FUN_016f3654(&LAB_018816b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 358 ; VA 0x00484d30 ; FUN_00484d30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00484d30(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined4 auStack_f4 [50];
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd1ec;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  pcStack_2c = FUN_008b6680;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008aa870();
  FUN_009cb790(uVar1,s_SetMeshPartHeads_0211b974,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211b358 = CONCAT44(uStack_28,pcStack_2c);
  _DAT_0211b320 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Workspace,void___cdecl(enum_RBX::Workspace::MeshPartHeads),1>::
       vftable;
  _DAT_0211b360 = 0;
  DAT_0211b364 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211b344 = FUN_00888530();
  puVar3 = DAT_0211b364;
  if (DAT_0211b364 == (undefined4 *)0x0) {
    uStack_1cc = FUN_00888530();
    iStack_1c8 = 0;
    puVar3 = &uStack_1cc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_fc = FUN_008bbc30();
    iStack_f8 = 0;
    auStack_f4[0] = *puVar3;
    iStack_f8 = FUN_008bbf20();
    puVar3 = &uStack_fc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_008bbc30();
  uVar2 = FUN_0086e3d0(s_value_0211ab70);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(auStack_f4);
    }
  }
  FUN_016f3654(&LAB_018816f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 359 ; VA 0x00484ee0 ; FUN_00484ee0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00484ee0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd20a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008aa870();
  FUN_009cb790(uVar1,s_GetNumAwakeParts_0211ba84,0,uStack_1c,0);
  _DAT_0211b6b8 = 0x8b3c40;
  uStack_8 = 0;
  _DAT_0211b680 = RBX::Reflection::BoundFuncDesc<class_RBX::Workspace,int___cdecl(void),0>::vftable;
  _DAT_0211b6c0 = 0;
  _DAT_0211b6a4 = FUN_0088c8c0();
  FUN_016f3654(&LAB_01881710);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 360 ; VA 0x00484fa0 ; FUN_00484fa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00484fa0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd22a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008aa870();
  FUN_009cb790(uVar1,s_GetPhysicsThrottling_0211ba6c,0,uStack_1c,0);
  _DAT_0211b670 = 0x8b3cf0;
  uStack_8 = 0;
  _DAT_0211b638 = RBX::Reflection::BoundFuncDesc<class_RBX::Workspace,int___cdecl(void),0>::vftable;
  _DAT_0211b678 = 0;
  _DAT_0211b65c = FUN_0088c8c0();
  FUN_016f3654(&LAB_01881720);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 361 ; VA 0x00485050 ; FUN_00485050 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00485050(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd24a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008aa870();
  FUN_009cb790(uVar1,s_GetRealPhysicsFPS_0211ba58,0,uStack_1c,0);
  _DAT_0211b628 = 0x8b3d20;
  uStack_8 = 0;
  _DAT_0211b5f0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Workspace,double___cdecl(void),0>::vftable;
  _DAT_0211b630 = 0;
  _DAT_0211b614 = FUN_0088ca00();
  FUN_016f3654(&LAB_01881730);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 362 ; VA 0x00485100 ; FUN_00485100 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00485100(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd26a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008aa870();
  FUN_009cb790(uVar1,s_PGSIsEnabled_0211bab4,0,uStack_1c,0);
  _DAT_0211b748 = 0x554b40;
  uStack_8 = 0;
  _DAT_0211b710 = RBX::Reflection::BoundFuncDesc<class_RBX::Workspace,bool___cdecl(void),0>::vftable
  ;
  _DAT_0211b750 = 0;
  _DAT_0211b734 = FUN_0088daf0();
  FUN_016f3654(&LAB_018817e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 363 ; VA 0x004851b0 ; FUN_004851b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004851b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd29c;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008aa870();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0x6d88c0;
    *(undefined8 *)(puVar3 + 6) = 0x8ba380;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Workspace,double>::
              GetSetImpl<double_(__thiscall_RBX::Workspace::*)(void)const_,void_(__thiscall_RBX::Workspace::*)(double)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088ca00();
  FUN_009ca670(uVar2,uVar4,s_DistributedGameTime_0211b7f0,&DAT_021197d4,uStack_3c,0,0,0x1d,0,0,0);
  DAT_0211af08 = RBX::Reflection::TypedPropertyDescriptor<double>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0211af3c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0211af2c = _DAT_0211af2c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0211af08[2])();
    if (cVar1 != '\0') {
      _DAT_0211af2c = _DAT_0211af2c & 0xfffffff3;
    }
  }
  DAT_0211af08 = RBX::Reflection::PropDescriptor<class_RBX::Workspace,double>::vftable;
  FUN_016f3654(&LAB_018817f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 364 ; VA 0x00485300 ; FUN_00485300 */

void FUN_00485300(void)

{
  FUN_008aa710(s_ExplicitAutoJoints_0211b8a8,s_Behavior_0211a8f8,0x8b37e0,0,0x8ba3f0,0,0,0,0,0xe,0);
  FUN_016f3654(&LAB_01881810);
  return;
}



/* FUNCTION 365 ; VA 0x00485390 ; FUN_00485390 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00485390(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd2cc;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008aa870();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0x8b3810;
    *(undefined8 *)(puVar3 + 6) = 0x8ba480;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Workspace,float>::
              GetSetImpl<float_(__thiscall_RBX::Workspace::*)(void)const_,void_(__thiscall_RBX::Workspace::*)(float)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,s_Gravity_0211b900,s_Behavior_0211a8f8,uStack_3c,0,0,0x1f,0,0,0);
  DAT_0211b1c8 = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0211b1fc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0211b1ec = _DAT_0211b1ec & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0211b1c8[2])();
    if (cVar1 != '\0') {
      _DAT_0211b1ec = _DAT_0211b1ec & 0xfffffff3;
    }
  }
  DAT_0211b1c8 = RBX::Reflection::PropDescriptor<class_RBX::Workspace,float>::vftable;
  FUN_016f3654(&LAB_01881830);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 366 ; VA 0x004854e0 ; FUN_004854e0 */

void FUN_004854e0(void)

{
  FUN_008aa410(s_PhysicsSimulationRate_0211b870,s_Behavior_0211a8f8,0x8b3ca0,0,0x8bb300,0,0,0,0,0x10
               ,0);
  FUN_016f3654(&LAB_01881850);
  return;
}



/* FUNCTION 367 ; VA 0x00485570 ; FUN_00485570 */

void FUN_00485570(void)

{
  FUN_008aa410(s_PhysicsSimulationRateReplicator_0211b888,s_Behavior_0211a8f8,0x8b3ce0,0,0x8bb340,0,
               0,0,0,2,0);
  FUN_016f3654(&LAB_01881870);
  return;
}



/* FUNCTION 368 ; VA 0x00485600 ; FUN_00485600 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00485600(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd2f4;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008bbd90();
  uVar3 = FUN_008aa870();
  FUN_009ca670(uVar3,uVar2,s_StreamingPauseMode_0211b844,s_Behavior_0211a8f8,uStack_3c,0,0,0xf,0,0,1
              );
  uStack_8 = 0;
  DAT_0211afe8 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Workspace,enum_RBX::Workspace::StreamingPauseMode>::
                 vftable;
  _DAT_0211b01c = uVar2;
  DAT_0211b020 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_0211b020 == (undefined4 *)0x0) {
    DAT_0211b020 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_0211b020 + 2) = 0x67c6b0;
    *(undefined8 *)(DAT_0211b020 + 6) = 0x8bb5a0;
    *DAT_0211b020 =
         RBX::Reflection::
         PropDescriptor<class_RBX::Workspace,enum_RBX::Workspace::StreamingPauseMode>::
         GetSetImpl<enum_RBX::Workspace::StreamingPauseMode_(__thiscall_RBX::Workspace::*)(void)const_,void_(__thiscall_RBX::Workspace::*)(enum_RBX::Workspace::StreamingPauseMode)>
         ::vftable;
    DAT_0211b020[4] = 0;
    DAT_0211b020[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0211b024 = FUN_008bbd90();
  cVar1 = (*(code *)DAT_0211afe8[3])();
  if (cVar1 != '\0') {
    _DAT_0211b00c = _DAT_0211b00c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211afe8[2])();
  if (cVar1 != '\0') {
    _DAT_0211b00c = _DAT_0211b00c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01881890);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 369 ; VA 0x00485820 ; FUN_00485820 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00485820(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd31c;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008aa870();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0x8b2f20;
    *(undefined8 *)(puVar3 + 6) = 0x8b9c10;
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::Workspace,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetSetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::Workspace::*)(void)const_,void_(__thiscall_RBX::Workspace::*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,s_CollisionGroups_0211b938,s_Behavior_0211a8f8,uStack_3c,0,0,0xe,0,0,0);
  DAT_0211b270 = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0211b2a4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0211b294 = _DAT_0211b294 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0211b270[2])();
    if (cVar1 != '\0') {
      _DAT_0211b294 = _DAT_0211b294 & 0xfffffff3;
    }
  }
  DAT_0211b270 = RBX::Reflection::
                 PropDescriptor<class_RBX::Workspace,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_018818d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 370 ; VA 0x00485970 ; FUN_00485970 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00485970(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd34c;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008aa870();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0x8b37f0;
    *(undefined8 *)(puVar3 + 6) = 0x8ba420;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Workspace,float>::
              GetSetImpl<float_(__thiscall_RBX::Workspace::*)(void)const_,void_(__thiscall_RBX::Workspace::*)(float)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,s_FallenPartsDestroyHeight_0211b8e4,s_Behavior_0211a8f8,uStack_3c,0,0,
               0x1f,0,1,0);
  DAT_0211b190 = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0211b1c4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0211b1b4 = _DAT_0211b1b4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0211b190[2])();
    if (cVar1 != '\0') {
      _DAT_0211b1b4 = _DAT_0211b1b4 & 0xfffffff3;
    }
  }
  DAT_0211b190 = RBX::Reflection::PropDescriptor<class_RBX::Workspace,float>::vftable;
  FUN_016f3654(&LAB_018818f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 371 ; VA 0x00485ac0 ; FUN_00485ac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00485ac0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd374;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008bbc30();
  uVar3 = FUN_008aa870();
  FUN_009ca670(uVar3,uVar2,s_MeshPartHeads_0211b964,s_Behavior_0211a8f8,uStack_3c,0,0,0xf,0,0,1);
  uStack_8 = 0;
  DAT_0211b2e0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::Workspace,enum_RBX::Workspace::MeshPartHeads>::
                 vftable;
  _DAT_0211b314 = uVar2;
  DAT_0211b318 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_0211b318 == (undefined4 *)0x0) {
    DAT_0211b318 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_0211b318 + 2) = 0x8b3a00;
    *(undefined8 *)(DAT_0211b318 + 6) = 0x8bab90;
    *DAT_0211b318 =
         RBX::Reflection::PropDescriptor<class_RBX::Workspace,enum_RBX::Workspace::MeshPartHeads>::
         GetSetImpl<enum_RBX::Workspace::MeshPartHeads_(__thiscall_RBX::Workspace::*)(void)const_,void_(__thiscall_RBX::Workspace::*)(enum_RBX::Workspace::MeshPartHeads)>
         ::vftable;
    DAT_0211b318[4] = 0;
    DAT_0211b318[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0211b31c = FUN_008bbc30();
  cVar1 = (*(code *)DAT_0211b2e0[3])();
  if (cVar1 != '\0') {
    _DAT_0211b304 = _DAT_0211b304 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211b2e0[2])();
  if (cVar1 != '\0') {
    _DAT_0211b304 = _DAT_0211b304 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01881910);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 372 ; VA 0x00485c00 ; FUN_00485c00 */

void FUN_00485c00(void)

{
  FUN_008aa710(s_TouchesUseCollisionGroups_0211b948,s_Behavior_0211a8f8,0x8b4200,0,0x8bb7f0,0,0,0,0,
               0xf,0);
  FUN_016f3654(&LAB_01881930);
  return;
}



/* FUNCTION 373 ; VA 0x00485c90 ; FUN_00485c90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00485c90(void)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined auStack_f4 [200];
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd3cc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  pcStack_2c = FUN_00553510;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008aa870();
  FUN_009cb790(uVar2,s_SetPhysicsThrottleEnabled_0211ba1c,3,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211b598 = CONCAT44(uStack_28,pcStack_2c);
  _DAT_0211b560 = RBX::Reflection::BoundFuncDesc<class_RBX::Workspace,void___cdecl(bool),1>::vftable
  ;
  _DAT_0211b5a0 = 0;
  DAT_0211b5a4 = (undefined *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211b584 = FUN_00888530();
  puVar1 = DAT_0211b5a4;
  if (DAT_0211b5a4 == (undefined *)0x0) {
    uStack_1cc = FUN_00888530();
    iStack_1c8 = 0;
    puVar4 = &uStack_1cc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_fc = FUN_0088daf0();
    iStack_f8 = 0;
    auStack_f4[0] = *puVar1;
    iStack_f8 = FUN_005c9ef0();
    puVar4 = &uStack_fc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(s_value_0211ab70);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(auStack_f4);
    }
  }
  FUN_016f3654(&LAB_01881970);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 374 ; VA 0x00485e40 ; FUN_00485e40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00485e40(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffd0;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd400;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffd0 & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x15;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf874) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf874,uVar3,0,0,0x15);
    if (DAT_01edf874 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01edf850 = RBX::Reflection::RefType<class_RBX::Instance*>::vftable;
      FUN_016f3654(&LAB_018813c0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edf874);
    }
  }
  uVar2 = FUN_008aa870();
  FUN_009ca670(uVar2,&DAT_01edf850,s_Terrain_0211ba14,s_Behavior_0211a8f8,uVar3,uVar4,uVar5,uVar6,0,
               0,0);
  uStack_8 = 1;
  DAT_0211b4e8 = RBX::Reflection::RefPropDescriptor<class_RBX::Workspace,class_RBX::Instance>::
                 vftable;
  _DAT_0211b51c =
       RBX::Reflection::RefPropDescriptor<class_RBX::Workspace,class_RBX::Instance>::vftable;
  DAT_0211b520 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0211b520 == (undefined4 *)0x0) {
    DAT_0211b520 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_0211b520 + 2) = 0xa9d3e0;
    *DAT_0211b520 =
         RBX::Reflection::PropDescriptor<class_RBX::Workspace,class_RBX::Instance*>::
         GetImpl<class_RBX::Instance*_(__thiscall_RBX::WorldRoot::*)(void)const_>::vftable;
    DAT_0211b520[4] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_0211b4e8[3])();
  if (cVar1 != '\0') {
    _DAT_0211b50c = _DAT_0211b50c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211b4e8[2])();
  if (cVar1 != '\0') {
    _DAT_0211b50c = _DAT_0211b50c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01881990);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 375 ; VA 0x00485fe0 ; FUN_00485fe0 */

void FUN_00485fe0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_008ad620(0x8affc0,0,s_BreakJoints_0211ba08,s_objects_0211b9f4,1,uStack_10,0);
  FUN_016f3654(&LAB_018819b0);
  return;
}



/* FUNCTION 376 ; VA 0x00486050 ; FUN_00486050 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00486050(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd42e;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008aa870();
  FUN_009cb790(uVar1,s_JoinToOutsiders_0211bad0,0,uStack_1c,0);
  _DAT_0211b790 = 0x8b6390;
  _DAT_0211b758 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Workspace,void___cdecl(class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>,enum_RBX::AdvArrowToolJointCreationMode),2>
       ::vftable;
  _DAT_0211b798 = 0;
  _DAT_0211b79c = 0;
  _DAT_0211b7a0 = 0;
  uStack_8 = 2;
  FUN_008b1ef0();
  FUN_016f3654(&LAB_01881a00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 377 ; VA 0x00486120 ; FUN_00486120 */

void FUN_00486120(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_008ad620(0x8b66c0,0,s_MakeJoints_0211b9fc,s_objects_0211b9f4,1,uStack_10,0);
  FUN_016f3654(&LAB_01881a10);
  return;
}



/* FUNCTION 378 ; VA 0x00486190 ; FUN_00486190 */

void FUN_00486190(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_008ad620(0x8bc490,0,s_UnjoinFromOutsiders_0211bae0,s_objects_0211b9f4,0,uStack_10,0);
  FUN_016f3654(&LAB_01881a60);
  return;
}



/* FUNCTION 379 ; VA 0x00486200 ; FUN_00486200 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00486200(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd44a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008aa870();
  FUN_009cb790(uVar1,s_ZoomToExtents_0211ba38,1,uStack_1c,0);
  _DAT_0211b5e0 = 0x8bc740;
  uStack_8 = 0;
  _DAT_0211b5a8 = RBX::Reflection::BoundFuncDesc<class_RBX::Workspace,void___cdecl(void),0>::vftable
  ;
  _DAT_0211b5e8 = 0;
  _DAT_0211b5cc = FUN_00888530();
  FUN_016f3654(&LAB_01881ab0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 380 ; VA 0x004862c0 ; FUN_004862c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004862c0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bee2c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008bd840();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::ContentProvider,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&_(__thiscall_RBX::ContentProvider::*)(void)const_>
              ::vftable;
    puVar3[2] = FUN_008cd320;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,s_BaseUrl_0211c034,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0211bd28 = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0211bd5c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0211bd4c = _DAT_0211bd4c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0211bd28[2])();
    if (cVar1 != '\0') {
      _DAT_0211bd4c = _DAT_0211bd4c & 0xfffffff3;
    }
  }
  DAT_0211bd28 = RBX::Reflection::
                 PropDescriptor<class_RBX::ContentProvider,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_01881ad0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 381 ; VA 0x004868f0 ; FUN_004868f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004868f0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bee5c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008bd840();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ContentProvider,int>::
              GetImpl<int_(__thiscall_RBX::ContentProvider::*)(void)const_>::vftable;
    puVar3[2] = FUN_008ce8b0;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,s_RequestQueueSize_0211c08c,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0211be30 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0211be64 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0211be54 = _DAT_0211be54 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0211be30[2])();
    if (cVar1 != '\0') {
      _DAT_0211be54 = _DAT_0211be54 & 0xfffffff3;
    }
  }
  DAT_0211be30 = RBX::Reflection::PropDescriptor<class_RBX::ContentProvider,int>::vftable;
  FUN_016f3654(&LAB_01881d90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 382 ; VA 0x00486a10 ; FUN_00486a10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00486a10(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bee93;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008bd840();
  FUN_009cb970(uVar1,s_AssetFetchFailed_0211c0e4,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0211bf2c = 0x60;
  iStack_8 = 0;
  _DAT_0211bef8 =
       RBX::Reflection::
       EventDesc<class_RBX::ContentProvider,void___cdecl(class_RBX::ContentId),class_rbx::signal<void___cdecl(class_RBX::ContentId)>,class_rbx::signal<void___cdecl(class_RBX::ContentId)>_RBX::ContentProvider::*>
       ::vftable;
  FUN_0086e3d0(s_assetId_0211bf40);
  FUN_0088d190();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0211bf20 = uStack_1c;
  _DAT_0211bf24 = uStack_18;
  _DAT_0211bf28 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_0211bef8 =
       RBX::Reflection::
       EventDesc<class_RBX::ContentProvider,void___cdecl(class_RBX::ContentId),class_rbx::signal<void___cdecl(class_RBX::ContentId)>,class_rbx::signal<void___cdecl(class_RBX::ContentId)>_RBX::ContentProvider::*>
       ::vftable;
  FUN_016f3654(&LAB_01881db0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 383 ; VA 0x00486b80 ; FUN_00486b80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00486b80(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017beeec;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008bd840();
  FUN_009cb820(uVar2,s_CalculateNumTrianglesInMesh_0211c0a8,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211be68 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::ContentProvider,int___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_0211bea0 = FUN_008c8650;
  _DAT_0211bea4 = 0;
  DAT_0211bea8 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211be8c = FUN_0088c8c0();
  iVar1 = DAT_0211bea8;
  if (DAT_0211bea8 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_meshId_0211c0a0);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01881e80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 384 ; VA 0x00486d30 ; FUN_00486d30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00486d30(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bef4c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008bd840();
  FUN_009cb790(uVar2,s_CalculateNumTrianglesInMeshSync_0211c0c4,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211beb0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ContentProvider,int___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_0211bee8 = FUN_008c89a0;
  _DAT_0211beec = 0;
  DAT_0211bef0 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211bed4 = FUN_0088c8c0();
  iVar1 = DAT_0211bef0;
  if (DAT_0211bef0 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_meshId_0211c0a0);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01881ea0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 385 ; VA 0x00486ee0 ; FUN_00486ee0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00486ee0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bef6a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008bd840(uVar2,0);
  FUN_009cb790(uVar1,s_GetFailedRequests_0211c078,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211bdf0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ContentProvider,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0211be28 = FUN_008ce320;
  _DAT_0211be2c = 0;
  _DAT_0211be14 = FUN_008882f0();
  FUN_016f3654(&LAB_01881ec0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 386 ; VA 0x00486fb0 ; FUN_00486fb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00486fb0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bef8a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008bd840(uVar2,0);
  FUN_009cb790(uVar1,s_ListEncryptedAssets_0211c010,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211bca0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ContentProvider,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0211bcd8 = FUN_008d0a90;
  _DAT_0211bcdc = 0;
  _DAT_0211bcc4 = FUN_008882f0();
  FUN_016f3654(&LAB_01881ed0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 387 ; VA 0x00487050 ; FUN_00487050 */

void FUN_00487050(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_008c1960(FUN_008d5a40,0,s_Preload_0211c070,s_contentId_0211bf6c,0,
               CONCAT44(&DAT_0211bd60,uStack_10),0);
  FUN_016f3654(&LAB_01881ee0);
  return;
}



/* FUNCTION 388 ; VA 0x004870b0 ; FUN_004870b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004870b0(void)

{
  undefined4 uVar1;
  undefined auStack_60 [32];
  undefined **ppuStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017befdd;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  uStack_3c = 0;
  LOCK();
  DAT_01e90cd8 = DAT_01e90cd8 + 1;
  UNLOCK();
  ppuStack_40 = RBX::Lua::WeakFunctionRef::vftable;
  uStack_34 = 0;
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00d88580(&ppuStack_40);
  uStack_8._0_1_ = 1;
  uVar1 = FUN_008bd840();
  FUN_009cb820(uVar1,s_PreloadAsync_0211c060,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211bd60 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::ContentProvider,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_RBX::Lua::WeakFunctionRef),2>
       ::vftable;
  _DAT_0211bd98 = FUN_008d5b70;
  _DAT_0211bd9c = 0;
  _DAT_0211bda0 = 0;
  uStack_8._0_1_ = 3;
  iStack_14 = FUN_01674e20(0x20);
  uStack_8._0_1_ = 4;
  if (iStack_14 == 0) {
    _DAT_0211bda4 = 0;
  }
  else {
    _DAT_0211bda4 = FUN_00d88580(auStack_60);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_008c9650();
  FUN_00d88a30();
  FUN_00d88a30();
  FUN_016f3654(&LAB_01881f00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 389 ; VA 0x004871e0 ; FUN_004871e0 */

void FUN_004871e0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_008c17e0(FUN_008d8fe0,0,s_RegisterDefaultEncryptionKey_0211bfb4,s_encryptionKey_0211bf30,0,
               uStack_10,0);
  FUN_016f3654(&LAB_01881f10);
  return;
}



/* FUNCTION 390 ; VA 0x00487240 ; FUN_00487240 */

void FUN_00487240(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_008c17e0(FUN_008d9080,0,s_RegisterDefaultSessionKey_0211bfd4,s_sessionKey_0211bf60,0,uStack_10
               ,0);
  FUN_016f3654(&LAB_01881f30);
  return;
}



/* FUNCTION 391 ; VA 0x004872a0 ; FUN_004872a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004872a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf00e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008bd840(uVar2,0);
  FUN_009cb790(uVar1,s_RegisterEncryptedAsset_0211bf48,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0211baf8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ContentProvider,void___cdecl(class_RBX::ContentId,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_0211bb30 = FUN_008d9130;
  _DAT_0211bb34 = 0;
  _DAT_0211bb38 = 0;
  _DAT_0211bb3c = 0;
  uStack_8 = 2;
  FUN_008c9420();
  FUN_016f3654(&LAB_01881f50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 392 ; VA 0x00487360 ; FUN_00487360 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00487360(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf03e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008bd840(uVar2,0);
  FUN_009cb790(uVar1,s_RegisterSessionEncryptedAsset_0211bf78,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0211bb40 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ContentProvider,void___cdecl(class_RBX::ContentId,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_0211bb78 = FUN_008d9210;
  _DAT_0211bb7c = 0;
  _DAT_0211bb80 = 0;
  _DAT_0211bb84 = 0;
  uStack_8 = 2;
  FUN_008c9420();
  FUN_016f3654(&LAB_01881f70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 393 ; VA 0x00487420 ; FUN_00487420 */

void FUN_00487420(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_008c17e0(FUN_008da0d0,0,s_SetBaseUrl_0211c028,&DAT_0211c024,3,uStack_10,0);
  FUN_016f3654(&LAB_01881f90);
  return;
}



/* FUNCTION 394 ; VA 0x00487480 ; FUN_00487480 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00487480(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bf05a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008bd840(uVar2,0);
  FUN_009cb790(uVar1,s_UnregisterDefaultEncryptionKey_0211bff0,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211bc60 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ContentProvider,void___cdecl(void),0>::vftable;
  _DAT_0211bc98 = &LAB_008da9a0;
  _DAT_0211bc9c = 0;
  _DAT_0211bc84 = FUN_00888530();
  FUN_016f3654(&LAB_01881fb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 395 ; VA 0x00487520 ; FUN_00487520 */

void FUN_00487520(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_008c1960(FUN_008da9d0,0,s_UnregisterEncryptedAsset_0211bf98,s_assetId_0211bf40,0,uStack_10,0);
  FUN_016f3654(&LAB_01881fc0);
  return;
}



/* FUNCTION 396 ; VA 0x00487720 ; FUN_00487720 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00487720(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2efe;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008dcf60(uVar2,0);
  FUN_009cb820(uVar1,s_HttpGetAsync_0211cf6c,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0211c320 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::DataModel,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::HttpRequestType),2>
       ::vftable;
  _DAT_0211c358 = FUN_008fc3f0;
  _DAT_0211c35c = 0;
  _DAT_0211c360 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  DAT_0211c364 = (undefined4 *)FUN_01674e20(4);
  if (DAT_0211c364 == (undefined4 *)0x0) {
    DAT_0211c364 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211c364 = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_008f2f80();
  FUN_016f3654(&LAB_01882690);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 397 ; VA 0x00487800 ; FUN_00487800 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00487800(void)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2f59;
  pvStack_10 = ExceptionList;
  pcVar3 = &DAT_0211cf7c;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  uStack_8 = 0;
  uVar2 = FUN_008dcf60();
  FUN_009cb820(uVar2,s_HttpPostAsync_0211cf94,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211c368 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::DataModel,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,enum_RBX::HttpRequestType),4>
       ::vftable;
  _DAT_0211c3a0 = FUN_008fc5d0;
  _DAT_0211c3a4 = 0;
  _DAT_0211c3a8 = 0;
  _DAT_0211c3ac = 0;
  uStack_8._0_1_ = 3;
  iStack_14 = FUN_01674e20(0x18);
  uStack_8._0_1_ = 4;
  if (iStack_14 == 0) {
    _DAT_0211c3b0 = 0;
  }
  else {
    _DAT_0211c3b0 = FUN_0054ef60(auStack_38);
  }
  uStack_8._0_1_ = 5;
  DAT_0211c3b4 = (undefined4 *)FUN_01674e20(4);
  if (DAT_0211c3b4 == (undefined4 *)0x0) {
    DAT_0211c3b4 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211c3b4 = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_008f2b70(&DAT_0211c024,&DAT_0211cf8c,s_contentType_0211cf80,s_httpRequestType_0211cf5c);
  if (0xf < uStack_24) {
    if (0xfff < uStack_24 + 1) {
      if (0x1f < (auStack_38[0] - *(int *)(auStack_38[0] - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  FUN_016f3654(&LAB_018826c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 398 ; VA 0x00487f10 ; FUN_00487f10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00487f10(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c2faa;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008dcf60(uVar2,0);
  FUN_009cb790(uVar1,s_GetRemoteBuildMode_0211cf48,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211c2e0 = RBX::Reflection::BoundFuncDesc<class_RBX::DataModel,bool___cdecl(void),0>::vftable
  ;
  _DAT_0211c318 = FUN_00585a40;
  _DAT_0211c31c = 0;
  _DAT_0211c304 = FUN_0088daf0();
  FUN_016f3654(&LAB_01882a20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 399 ; VA 0x00487fb0 ; FUN_00487fb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00487fb0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c300c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_1c = 0;
  uStack_20 = CONCAT31(uStack_20._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008dcf60();
  FUN_009cb820(uVar1,s_SavePlace_0211cf34,0,CONCAT44(uStack_1c,uStack_20),0);
  uStack_8 = 0;
  _DAT_0211c250 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::DataModel,bool___cdecl(enum_RBX::Instance::SaveFilter_DEPRECATED),1>
       ::vftable;
  _DAT_0211c288 = FUN_0090a180;
  _DAT_0211c28c = 0;
  DAT_0211c290 = (undefined4 *)FUN_01674e20(4);
  if (DAT_0211c290 == (undefined4 *)0x0) {
    DAT_0211c290 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211c290 = 2;
  }
  uStack_8._0_1_ = 1;
  _DAT_0211c274 = FUN_0088daf0();
  puVar3 = DAT_0211c290;
  if (DAT_0211c290 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = thunk_FUN_008a7680();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_008a7710();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = thunk_FUN_008a7680();
  uVar2 = FUN_0086e3d0(s_saveFilter_0211cf28);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01882a30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 400 ; VA 0x004883b0 ; FUN_004883b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004883b0(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("LoadErrorHandlerFromEngine",0x1a);
  _DAT_01ee0564 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 401 ; VA 0x004884a0 ; FUN_004884a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004884a0(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("LuobuModerationStatus",0x15);
  _DAT_01ee0560 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 402 ; VA 0x004886d0 ; FUN_004886d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004886d0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c302a;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_0211cb50;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008dcf60(uVar2,&DAT_0211cb50);
  FUN_00f50070(uVar1,s_OnClose_0211d214,CONCAT44(puVar3,uVar2),0,0);
  uStack_8 = 0;
  _DAT_0211cb98 =
       RBX::Reflection::
       BoundAsyncCallbackDesc<class_RBX::DataModel,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0211cbd0 = 0x2d8;
  _DAT_0211cbd8 = FUN_008ed270;
  _DAT_0211cbdc = 0;
  _DAT_0211cbbc = FUN_0088cbe0();
  FUN_016f3654(&LAB_01882b70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 403 ; VA 0x00488780 ; FUN_00488780 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00488780(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c304a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008dcf60(uVar2,0);
  FUN_009cb790(uVar1,s_Shutdown_0211cff4,3,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211c448 = RBX::Reflection::BoundFuncDesc<class_RBX::DataModel,void___cdecl(void),0>::vftable
  ;
  _DAT_0211c480 = FUN_008f0fa0;
  _DAT_0211c484 = 0;
  _DAT_0211c46c = FUN_00888530();
  FUN_016f3654(&LAB_01882b80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 404 ; VA 0x00488940 ; FUN_00488940 */

void FUN_00488940(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cb380(auStack_14,&DAT_0211ca38,0x1e);
  FUN_008dae20(s_VIPServerId_0211d1cc,&DAT_021197d4,FUN_008fbd60,0,0,*puVar1,puVar1[1],puVar1[2],
               puVar1[3],0);
  FUN_016f3654(&LAB_01882c30);
  return;
}



/* FUNCTION 405 ; VA 0x004889a0 ; FUN_004889a0 */

void FUN_004889a0(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cb380(auStack_14,&DAT_0211ca70,0x1e);
  FUN_008db080(s_VIPServerOwnerId_0211d1d8,&DAT_021197d4,FUN_008fbdb0,0,0,*puVar1,puVar1[1],
               puVar1[2],puVar1[3],0);
  FUN_016f3654(&LAB_01882c50);
  return;
}



/* FUNCTION 406 ; VA 0x00488a00 ; FUN_00488a00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00488a00(void)

{
  undefined4 extraout_var;
  
  FUN_008e70d0(0xac,s_Loaded_0211d164,0,0,0,0);
  _DAT_0211c940 =
       RBX::Reflection::
       EventDesc<class_RBX::DataModel,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::DataModel::*>
       ::vftable;
  FUN_016f3654(&LAB_01882c70,extraout_var);
  return;
}



/* FUNCTION 407 ; VA 0x00488a50 ; FUN_00488a50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00488a50(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c308e;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uStack_2c = CONCAT31(uStack_2c._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008dcf60();
  FUN_009cb970(uVar1,s_ItemChanged_0211cec4,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0211c12c = 0x2ac;
  iStack_8 = 0;
  _DAT_0211c0f8 =
       RBX::Reflection::
       EventDesc<class_RBX::DataModel,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_RBX::Reflection::PropertyDescriptor_const*),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_RBX::Reflection::PropertyDescriptor_const*)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_RBX::Reflection::PropertyDescriptor_const*)>_RBX::DataModel::*>
       ::vftable;
  FUN_0086e3d0(s_object_0211cebc);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_descriptor_0211ceb0);
  FUN_009ca3d0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_0211c120 = uStack_1c;
  _DAT_0211c124 = uStack_18;
  _DAT_0211c128 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  FUN_016f3654(&LAB_01882c80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 408 ; VA 0x00488bc0 ; FUN_00488bc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00488bc0(void)

{
  FUN_008e70d0(0xa0,s_AllowedGearTypeChanged_0211d0f4,0,1,0);
  _DAT_0211c860 =
       RBX::Reflection::
       EventDesc<class_RBX::DataModel,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::DataModel::*>
       ::vftable;
  FUN_016f3654(&LAB_01882c90);
  return;
}



/* FUNCTION 409 ; VA 0x00488c20 ; FUN_00488c20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00488c20(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c30c3;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008dcf60();
  FUN_009cb970(uVar1,s_GraphicsQualityChangeRequest_0211d12c,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0211c904 = 0x9c;
  iStack_8 = 0;
  _DAT_0211c8d0 =
       RBX::Reflection::
       EventDesc<class_RBX::DataModel,void___cdecl(bool),class_rbx::signal<void___cdecl(bool)>,class_rbx::signal<void___cdecl(bool)>_RBX::DataModel::*>
       ::vftable;
  FUN_0086e3d0(s_betterQuality_0211d11c);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0211c8f8 = uStack_1c;
  _DAT_0211c8fc = uStack_18;
  _DAT_0211c900 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_0211c8d0 =
       RBX::Reflection::
       EventDesc<class_RBX::DataModel,void___cdecl(bool),class_rbx::signal<void___cdecl(bool)>,class_rbx::signal<void___cdecl(bool)>_RBX::DataModel::*>
       ::vftable;
  FUN_016f3654(&LAB_01882ca0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 410 ; VA 0x00488d70 ; FUN_00488d70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00488d70(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c30f3;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008dcf60();
  FUN_009cb970(uVar1,s_ScreenshotReady_0211d154,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0211c93c = 0x8c;
  iStack_8 = 0;
  _DAT_0211c908 =
       RBX::Reflection::
       EventDesc<class_RBX::DataModel,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::DataModel::*>
       ::vftable;
  FUN_0086e3d0(&DAT_0211d14c);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0211c930 = uStack_1c;
  _DAT_0211c934 = uStack_18;
  _DAT_0211c938 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_0211c908 =
       RBX::Reflection::
       EventDesc<class_RBX::DataModel,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::DataModel::*>
       ::vftable;
  FUN_016f3654(&LAB_01882cb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 411 ; VA 0x00488ec0 ; FUN_00488ec0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00488ec0(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined *puStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c314c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008dcf60();
  FUN_009cb790(uVar2,s_BindToClose_0211d208,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211cb50 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DataModel,void___cdecl(class_RBX::Lua::WeakFunctionRef),1>::vftable;
  _DAT_0211cb88 = FUN_008eea30;
  _DAT_0211cb8c = 0;
  DAT_0211cb90 = 0;
  uStack_8 = 1;
  _DAT_0211cb74 = FUN_00888530();
  iVar1 = DAT_0211cb90;
  if (DAT_0211cb90 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_00d88470();
    puStack_ec = (undefined *)0x0;
    FUN_00d88580(iVar1);
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee047c) {
      FUN_016f3809(&DAT_01ee047c);
      if (DAT_01ee047c == -1) {
        _DAT_01ee0470 = FUN_008c9370;
        _DAT_01ee0474 = FUN_008c9370;
        DAT_01ee0478 = FUN_008ca540;
        FUN_016f37bf(&DAT_01ee047c);
      }
    }
    puStack_ec = &DAT_01ee0470;
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_00d88470();
  uVar3 = FUN_0086e3d0(s_function_0211d1fc);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_ec != (undefined *)0x0) {
      (**(code **)(puStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01882cc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 412 ; VA 0x004890d0 ; FUN_004890d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004890d0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c316a;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008dcf60(uVar2,0);
  FUN_009cb790(uVar1,s_GetMessage_0211d000,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211c488 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DataModel,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(void),0>
       ::vftable;
  _DAT_0211c4c0 = FUN_008f3420;
  _DAT_0211c4c4 = 0;
  _DAT_0211c4ac = FUN_0088cb40();
  FUN_016f3654(&LAB_01882ce0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 413 ; VA 0x00489170 ; FUN_00489170 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00489170(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c319e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008dcf60(uVar2,0);
  FUN_009cb790(uVar1,s_DefineFastFlag_0211d254,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0211ccb8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DataModel,bool___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool),2>
       ::vftable;
  _DAT_0211ccf0 = FUN_008f31a0;
  _DAT_0211ccf4 = 0;
  _DAT_0211ccf8 = 0;
  DAT_0211ccfc = 0;
  uStack_8 = 2;
  FUN_008f2950();
  FUN_016f3654(&LAB_01882cf0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 414 ; VA 0x00489230 ; FUN_00489230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00489230(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c31ce;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008dcf60(uVar2,0);
  FUN_009cb790(uVar1,s_DefineFastInt_0211d264,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0211cd00 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DataModel,int___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int),2>
       ::vftable;
  _DAT_0211cd38 = FUN_008f32a0;
  _DAT_0211cd3c = 0;
  _DAT_0211cd40 = 0;
  DAT_0211cd44 = 0;
  uStack_8 = 2;
  FUN_008f2320();
  FUN_016f3654(&LAB_01882d20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 415 ; VA 0x004892f0 ; FUN_004892f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004892f0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c31fe;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008dcf60(uVar2,0);
  FUN_009cb790(uVar1,s_DefineFastString_0211d274,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0211cd48 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DataModel,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_0211cd80 = FUN_008f3320;
  _DAT_0211cd84 = 0;
  _DAT_0211cd88 = 0;
  _DAT_0211cd8c = 0;
  uStack_8 = 2;
  FUN_008f20f0();
  FUN_016f3654(&LAB_01882d50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 416 ; VA 0x004893b0 ; FUN_004893b0 */

void FUN_004893b0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_008e6c20(FUN_008f7ca0,0,s_GetEngineFeature_0211d288,&DAT_0211a93c,3,uStack_10,0);
  FUN_016f3654(&LAB_01882d70);
  return;
}



/* FUNCTION 417 ; VA 0x00489410 ; FUN_00489410 */

void FUN_00489410(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_008e6c20(FUN_008f7d20,0,s_GetFastFlag_0211d21c,&DAT_0211a93c,3,uStack_10,0);
  FUN_016f3654(&LAB_01882d90);
  return;
}



/* FUNCTION 418 ; VA 0x00489470 ; FUN_00489470 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00489470(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c325c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008dcf60();
  FUN_009cb790(uVar2,s_GetFastInt_0211d228,3,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211cc28 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DataModel,int___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_0211cc60 = FUN_008f7da0;
  _DAT_0211cc64 = 0;
  DAT_0211cc68 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211cc4c = FUN_0088c8c0();
  iVar1 = DAT_0211cc68;
  if (DAT_0211cc68 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_0211a93c);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01882db0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 419 ; VA 0x00489620 ; FUN_00489620 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00489620(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c32bc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008dcf60();
  FUN_009cb790(uVar2,s_GetFastString_0211d234,3,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211cc70 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DataModel,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_0211cca8 = FUN_008f7e20;
  _DAT_0211ccac = 0;
  DAT_0211ccb0 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211cc94 = FUN_0088cb40();
  iVar1 = DAT_0211ccb0;
  if (DAT_0211ccb0 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cb40();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_005c9d30();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_0211a93c);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01882dd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 420 ; VA 0x004897d0 ; FUN_004897d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004897d0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c331c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_1c = 0;
  uStack_20 = CONCAT31(uStack_20._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008dcf60();
  FUN_009cb790(uVar1,s_IsGearTypeAllowed_0211d0e0,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211c818 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DataModel,bool___cdecl(enum_RBX::DataModel::GearType),1>::vftable;
  _DAT_0211c850 = FUN_008ff0b0;
  _DAT_0211c854 = 0;
  DAT_0211c858 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211c83c = FUN_0088daf0();
  puVar3 = DAT_0211c858;
  if (DAT_0211c858 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0090bea0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_0090c3e0();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0090bea0();
  uVar2 = FUN_0086e3d0(s_gearType_0211d0d4);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01882df0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 421 ; VA 0x00489970 ; FUN_00489970 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00489970(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c333a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008dcf60(uVar2,0);
  FUN_009cb790(uVar1,s_OpenScreenshotsFolder_0211d178,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211c9b8 = RBX::Reflection::BoundFuncDesc<class_RBX::DataModel,void___cdecl(void),0>::vftable
  ;
  _DAT_0211c9f0 = &LAB_00902480;
  _DAT_0211c9f4 = 0;
  _DAT_0211c9dc = FUN_00888530();
  FUN_016f3654(&LAB_01882e10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 422 ; VA 0x00489a10 ; FUN_00489a10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00489a10(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c335a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008dcf60(uVar2,0);
  FUN_009cb790(uVar1,s_OpenVideosFolder_0211d190,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211c9f8 = RBX::Reflection::BoundFuncDesc<class_RBX::DataModel,void___cdecl(void),0>::vftable
  ;
  _DAT_0211ca30 = &LAB_00902490;
  _DAT_0211ca34 = 0;
  _DAT_0211ca1c = FUN_00888530();
  FUN_016f3654(&LAB_01882e20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 423 ; VA 0x00489ab0 ; FUN_00489ab0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00489ab0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c338e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008dcf60(uVar2,0);
  FUN_009cb790(uVar1,s_SetFastFlagForTesting_0211d2a8,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0211cdd8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DataModel,bool___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool),2>
       ::vftable;
  _DAT_0211ce10 = FUN_0090a910;
  _DAT_0211ce14 = 0;
  _DAT_0211ce18 = 0;
  DAT_0211ce1c = 0;
  uStack_8 = 2;
  FUN_008f2950();
  FUN_016f3654(&LAB_01882e30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 424 ; VA 0x00489b70 ; FUN_00489b70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00489b70(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c33be;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008dcf60(uVar2,0);
  FUN_009cb790(uVar1,s_SetFastIntForTesting_0211d2c0,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0211ce20 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DataModel,int___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int),2>
       ::vftable;
  _DAT_0211ce58 = FUN_0090aa00;
  _DAT_0211ce5c = 0;
  _DAT_0211ce60 = 0;
  DAT_0211ce64 = 0;
  uStack_8 = 2;
  FUN_008f2320();
  FUN_016f3654(&LAB_01882e60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 425 ; VA 0x00489c30 ; FUN_00489c30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00489c30(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c33ee;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008dcf60(uVar2,0);
  FUN_009cb790(uVar1,s_SetFastStringForTesting_0211d2d8,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0211ce68 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DataModel,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_0211cea0 = FUN_0090ab20;
  _DAT_0211cea4 = 0;
  _DAT_0211cea8 = 0;
  _DAT_0211ceac = 0;
  uStack_8 = 2;
  FUN_008f20f0();
  FUN_016f3654(&LAB_01882e90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 426 ; VA 0x00489cf0 ; FUN_00489cf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00489cf0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c340a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008dcf60(uVar2,0);
  FUN_009cb790(uVar1,s_IsLoaded_0211d16c,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211c978 = RBX::Reflection::BoundFuncDesc<class_RBX::DataModel,bool___cdecl(void),0>::vftable
  ;
  _DAT_0211c9b0 = &LAB_008f8130;
  _DAT_0211c9b4 = 0;
  _DAT_0211c99c = FUN_0088daf0();
  FUN_016f3654(&LAB_01882eb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 427 ; VA 0x00489d90 ; FUN_00489d90 */

void FUN_00489d90(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_008e6da0(FUN_008f6370,0,s_GetObjectsAsync_0211cef4,&DAT_0211c024,5,uStack_10,0);
  FUN_016f3654(&LAB_01882ec0);
  return;
}



/* FUNCTION 428 ; VA 0x00489df0 ; FUN_00489df0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00489df0(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c346c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008dcf60();
  FUN_009cb790(uVar2,s_GetObjects_0211ced0,1,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211c130 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DataModel,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(class_RBX::ContentId),1>
       ::vftable;
  _DAT_0211c168 = FUN_008f61f0;
  _DAT_0211c16c = 0;
  DAT_0211c170 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211c154 = FUN_0088cc80();
  iVar1 = DAT_0211c170;
  if (DAT_0211c170 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088d190();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_00630cf0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088d190();
  uVar3 = FUN_0086e3d0(&DAT_0211c024);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01882ee0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 429 ; VA 0x00489fa0 ; FUN_00489fa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00489fa0(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c34cc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008dcf60();
  FUN_009cb790(uVar2,s_GetObjectsList_0211cee4,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211c178 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DataModel,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),1>
       ::vftable;
  _DAT_0211c1b0 = FUN_008f6670;
  _DAT_0211c1b4 = 0;
  DAT_0211c1b8 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211c19c = FUN_008882f0();
  puVar4 = DAT_0211c1b8;
  if (DAT_0211c1b8 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_008882f0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_005c9da0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_008882f0();
  uVar3 = FUN_0086e3d0(&DAT_0211cedc);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_01882f00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 430 ; VA 0x0048a170 ; FUN_0048a170 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048a170(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c34ea;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008dcf60(uVar2,0);
  FUN_009cb790(uVar1,s_GetJobsInfo_0211cfa4,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211c3b8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DataModel,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0211c3f0 = FUN_008f8170;
  _DAT_0211c3f4 = 0;
  _DAT_0211c3dc = FUN_008882f0();
  FUN_016f3654(&LAB_01882f50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 431 ; VA 0x0048a210 ; FUN_0048a210 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048a210(void)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  undefined4 uStack_54;
  undefined auStack_50 [16];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined auStack_38 [16];
  undefined4 uStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c3560;
  pvStack_10 = ExceptionList;
  pcVar3 = &DAT_0211cfb0;
  uStack_20 = uStack_20 & 0xffffff00;
  puStack_14 = &uStack_54;
  uStack_1c = 0;
  uStack_54 = 0;
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = 0;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  pcVar3 = &DAT_0211cfb8;
  uStack_8 = 0;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = 0;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0();
  uStack_8 = 1;
  uVar2 = FUN_008dcf60();
  FUN_009cb790(uVar2,s_ReportInGoogleAnalytics_0211cfdc,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211c3f8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::DataModel,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int),4>
       ::vftable;
  _DAT_0211c430 = FUN_008ffe00;
  _DAT_0211c434 = 0;
  _DAT_0211c438 = 0;
  uStack_8._0_1_ = 3;
  puStack_14 = (undefined4 *)FUN_01674e20(0x18);
  uStack_8._0_1_ = 4;
  if (puStack_14 == (undefined4 *)0x0) {
    _DAT_0211c43c = 0;
  }
  else {
    _DAT_0211c43c = FUN_0054ef60(auStack_38);
  }
  uStack_8._0_1_ = 5;
  puStack_14 = (undefined4 *)FUN_01674e20(0x18);
  uStack_8._0_1_ = 6;
  if (puStack_14 == (undefined4 *)0x0) {
    _DAT_0211c440 = 0;
  }
  else {
    _DAT_0211c440 = FUN_0054ef60(auStack_50);
  }
  uStack_8._0_1_ = 7;
  DAT_0211c444 = (undefined4 *)FUN_01674e20(4);
  if (DAT_0211c444 == (undefined4 *)0x0) {
    DAT_0211c444 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211c444 = uStack_54;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  FUN_008f2540(s_category_0211cfd0,s_action_0211cfc8,s_label_0211cfc0,s_value_0211ab70);
  FUN_0056e2f0();
  FUN_016f3654(&LAB_01882f60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 432 ; VA 0x0048a3d0 ; FUN_0048a3d0 */

void FUN_0048a3d0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_008e6da0(FUN_008fdbc0,0,s_InsertObjectsAndJoinIfLegacyAsyn_0211cf04,&DAT_0211c024,5,uStack_10,
               0);
  FUN_016f3654(&LAB_01882fa0);
  return;
}



/* FUNCTION 433 ; VA 0x0048a430 ; FUN_0048a430 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048a430(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c35bc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008dcf60();
  FUN_009cb790(uVar2,&DAT_0211cf40,3,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211c298 =
       RBX::Reflection::BoundFuncDesc<class_RBX::DataModel,void___cdecl(class_RBX::ContentId),1>::
       vftable;
  _DAT_0211c2d0 = FUN_008ff3b0;
  _DAT_0211c2d4 = 0;
  DAT_0211c2d8 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211c2bc = FUN_00888530();
  iVar1 = DAT_0211c2d8;
  if (DAT_0211c2d8 == 0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088d190();
    iStack_ec = 0;
    FUN_0054ef60(iVar1);
    iStack_ec = FUN_00630cf0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088d190();
  uVar3 = FUN_0086e3d0(&DAT_0211c024);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01882fc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 434 ; VA 0x0048a6e0 ; FUN_0048a6e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048a6e0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c35e4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0090bc60();
  uVar3 = FUN_008dcf60();
  FUN_009ca670(uVar3,uVar2,s_AvatarJointPositionType_0211d094,s_State_0211d030,uStack_24,0,0,2,6,6,1
              );
  uStack_8 = 0;
  DAT_0211c718 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::DataModel,enum_RBX::AvatarJointPositionType>::vftable
  ;
  _DAT_0211c74c = uVar2;
  DAT_0211c750 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0211c750 == (undefined4 *)0x0) {
    DAT_0211c750 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211c750 =
         RBX::Reflection::PropDescriptor<class_RBX::DataModel,enum_RBX::AvatarJointPositionType>::
         GetSetImpl<enum_RBX::AvatarJointPositionType_(__thiscall_RBX::DataModel::*)(void)const_,void_(__thiscall_RBX::DataModel::*)(enum_RBX::AvatarJointPositionType)>
         ::vftable;
    DAT_0211c750[2] = &LAB_008f7b50;
    DAT_0211c750[3] = 0;
    DAT_0211c750[4] = FUN_0090a7c0;
    DAT_0211c750[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0211c754 = FUN_0090bc60();
  cVar1 = (*(code *)DAT_0211c718[3])();
  if (cVar1 != '\0') {
    _DAT_0211c73c = _DAT_0211c73c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211c718[2])();
  if (cVar1 != '\0') {
    _DAT_0211c73c = _DAT_0211c73c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01883100);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 435 ; VA 0x0048a850 ; FUN_0048a850 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048a850(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c3604;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0063cc40();
  uVar3 = FUN_008dcf60();
  FUN_009ca670(uVar3,uVar2,s_CreatorType_0211d0ac,s_State_0211d030,uStack_24,0,0,0x15,0,0,1);
  uStack_8 = 0;
  DAT_0211c758 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::DataModel,enum_RBX::DataModel::CreatorType>::vftable;
  _DAT_0211c78c = uVar2;
  DAT_0211c790 = (undefined4 *)FUN_01674e20(0x10);
  if (DAT_0211c790 == (undefined4 *)0x0) {
    DAT_0211c790 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211c790 =
         RBX::Reflection::PropDescriptor<class_RBX::DataModel,enum_RBX::DataModel::CreatorType>::
         GetImpl<enum_RBX::DataModel::CreatorType_(__thiscall_RBX::DataModel::*)(void)const_>::
         vftable;
    DAT_0211c790[2] = &LAB_008f7c40;
    DAT_0211c790[3] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0211c794 = FUN_0063cc40();
  cVar1 = (*(code *)DAT_0211c758[3])();
  if (cVar1 != '\0') {
    _DAT_0211c77c = _DAT_0211c77c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211c758[2])();
  if (cVar1 != '\0') {
    _DAT_0211c77c = _DAT_0211c77c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01883140);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 436 ; VA 0x0048acc0 ; FUN_0048acc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048acc0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c3664;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0090bf80();
  uVar3 = FUN_008dcf60();
  FUN_009ca670(uVar3,uVar2,s_Genre_0211d0b8,s_State_0211d030,uStack_24,0,0,0x15,0,0,1);
  uStack_8 = 0;
  DAT_0211c798 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::DataModel,enum_RBX::DataModel::Genre>::vftable;
  _DAT_0211c7cc = uVar2;
  DAT_0211c7d0 = (undefined4 *)FUN_01674e20(0x10);
  if (DAT_0211c7d0 == (undefined4 *)0x0) {
    DAT_0211c7d0 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211c7d0 =
         RBX::Reflection::PropDescriptor<class_RBX::DataModel,enum_RBX::DataModel::Genre>::
         GetImpl<enum_RBX::DataModel::Genre_(__thiscall_RBX::DataModel::*)(void)const_>::vftable;
    DAT_0211c7d0[2] = &LAB_008f7ef0;
    DAT_0211c7d0[3] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0211c7d4 = FUN_0090bf80();
  cVar1 = (*(code *)DAT_0211c798[3])();
  if (cVar1 != '\0') {
    _DAT_0211c7bc = _DAT_0211c7bc & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211c798[2])();
  if (cVar1 != '\0') {
    _DAT_0211c7bc = _DAT_0211c7bc & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018831e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 437 ; VA 0x0048ae70 ; FUN_0048ae70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048ae70(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c368c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_008dcf60();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::DataModel,int>::
              GetImpl<int_(__thiscall_RBX::DataModel::*)(void)const_>::vftable;
    puVar3[2] = FUN_005d48b0;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,s_PlaceVersion_0211d040,s_State_0211d030,uStack_24,0,0,0x15,0,0,0);
  DAT_0211c5b4 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0211c5e8 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0211c5d8 = _DAT_0211c5d8 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0211c5b4[2])();
    if (cVar1 != '\0') {
      _DAT_0211c5d8 = _DAT_0211c5d8 & 0xfffffff3;
    }
  }
  DAT_0211c5b4 = RBX::Reflection::PropDescriptor<class_RBX::DataModel,int>::vftable;
  FUN_016f3654(&LAB_01883240);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 438 ; VA 0x0048b0c0 ; FUN_0048b0c0 */

void FUN_0048b0c0(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cb380(auStack_14,&DAT_0211c4c8,0x15);
  FUN_008daf20(s_workspace_0211d018,&DAT_021197d4,&LAB_005d5830,0,0,*puVar1,puVar1[1],puVar1[2],
               puVar1[3],0);
  FUN_016f3654(&LAB_01883280);
  return;
}



/* FUNCTION 439 ; VA 0x0048b210 ; FUN_0048b210 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048b210(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("AvatarEditorCurrentlyWearingPersistenceLogic",0x2c);
  _DAT_01ee0fdc = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 440 ; VA 0x0048b260 ; FUN_0048b260 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048b260(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("AvatarEditorEquippedAssetsNilIndexingFix",0x28);
  _DAT_01ee0fe0 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 441 ; VA 0x0048b2d0 ; FUN_0048b2d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048b2d0(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("AvatarEditorGothamFont",0x16);
  _DAT_01ee0fe4 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 442 ; VA 0x0048b360 ; FUN_0048b360 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048b360(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("AvatarEditorLightThemeFix",0x19);
  _DAT_01ee0fe8 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 443 ; VA 0x0048b3d0 ; FUN_0048b3d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048b3d0(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("AvatarEditorRTranslations",0x19);
  _DAT_01ee0fec = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 444 ; VA 0x0048b780 ; FUN_0048b780 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048b780(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("EnableRoactInspector",0x14);
  _DAT_01ee0f50 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 445 ; VA 0x0048ba50 ; FUN_0048ba50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048ba50(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("LuaAppAEUseAppPolicyForShowingBuyRobuxOnTopBar",0x2e);
  _DAT_01ee0e50 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 446 ; VA 0x0048be20 ; FUN_0048be20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048be20(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("LuaAppTopBarFixedAbleToRotateAvatar",0x23);
  _DAT_01ee0e24 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 447 ; VA 0x0048c330 ; FUN_0048c330 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048c330(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("PlayEmoteAndGetAnimTrackByIdApiEnabled",0x26);
  _DAT_01ee1014 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 448 ; VA 0x0048cbb0 ; FUN_0048cbb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048cbb0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5a2c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0090de90();
  FUN_009cb790(uVar1,s_GetFVariable_0211d408,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211d2f0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GlobalAdvancedSettings,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_0211d328 = FUN_0090f770;
  _DAT_0211d32c = 0;
  DAT_0211d330 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211d314 = FUN_0088cb40();
  if (DAT_0211d330 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_0211d330);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_0211a93c);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018839c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 449 ; VA 0x0048cd30 ; FUN_0048cd30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048cd30(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5a8c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0090de90();
  FUN_009cb790(uVar1,s_GetFFlag_0211d418,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211d338 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GlobalAdvancedSettings,bool___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_0211d370 = FUN_0090f5c0;
  _DAT_0211d374 = 0;
  DAT_0211d378 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211d35c = FUN_0088daf0();
  if (DAT_0211d378 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_0211d378);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_0211a93c);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_018839e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 450 ; VA 0x0048ceb0 ; FUN_0048ceb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048ceb0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5aec;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0090df70();
  FUN_009cb790(uVar1,s_IsUserFeatureEnabled_0211d42c,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211d3c0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GlobalBasicSettings,bool___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_0211d3f8 = FUN_0090fe00;
  _DAT_0211d3fc = 0;
  DAT_0211d400 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211d3e4 = FUN_0088daf0();
  if (DAT_0211d400 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_0211d400);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(&DAT_0211a93c);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_01883a00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 451 ; VA 0x0048d030 ; FUN_0048d030 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048d030(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5b0a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0090df70(uVar2,0);
  FUN_009cb790(uVar1,s_Reset_0211d424,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211d380 =
       RBX::Reflection::BoundFuncDesc<class_RBX::GlobalBasicSettings,void___cdecl(void),0>::vftable;
  _DAT_0211d3b8 = FUN_00910a60;
  _DAT_0211d3bc = 0;
  _DAT_0211d3a4 = FUN_00888530();
  FUN_016f3654(&LAB_01883a20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 452 ; VA 0x0048d390 ; FUN_0048d390 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048d390(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5f54;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00896f00();
  uVar3 = FUN_009112a0();
  FUN_009ca670(uVar3,uVar2,s_TickCountPreciseOverride_0211d7f0,s_Benchmarking_0211d7e0,uStack_24,0,0
               ,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0211d6b8 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::DebugSettings,enum_RBX::Time::SampleMethod>::vftable;
  _DAT_0211d6ec = uVar2;
  DAT_0211d6f0 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0211d6f0 == (undefined4 *)0x0) {
    DAT_0211d6f0 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211d6f0 =
         RBX::Reflection::PropDescriptor<class_RBX::DebugSettings,enum_RBX::Time::SampleMethod>::
         GetSetImpl<enum_RBX::Time::SampleMethod_(__thiscall_RBX::DebugSettings::*)(void)const_,void_(__thiscall_RBX::DebugSettings::*)(enum_RBX::Time::SampleMethod)>
         ::vftable;
    DAT_0211d6f0[2] = &LAB_00912190;
    DAT_0211d6f0[3] = 0;
    DAT_0211d6f0[4] = FUN_00912760;
    DAT_0211d6f0[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0211d6f4 = FUN_00896f00();
  cVar1 = (*(code *)DAT_0211d6b8[3])();
  if (cVar1 != '\0') {
    _DAT_0211d6dc = _DAT_0211d6dc & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211d6b8[2])();
  if (cVar1 != '\0') {
    _DAT_0211d6dc = _DAT_0211d6dc & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01883ae0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 453 ; VA 0x0048d4b0 ; FUN_0048d4b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048d4b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5f7c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_009112a0();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::DebugSettings,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::DebugSettings::*)(void)const_>
              ::vftable;
    puVar3[2] = FUN_009120e0;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,s_RobloxVersion_0211d700,s_Profile_0211d6f8,uStack_24,0,0,0x1f,0,0,0);
  DAT_0211d448 = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0211d47c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0211d46c = _DAT_0211d46c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0211d448[2])();
    if (cVar1 != '\0') {
      _DAT_0211d46c = _DAT_0211d46c & 0xfffffff3;
    }
  }
  DAT_0211d448 = RBX::Reflection::
                 PropDescriptor<class_RBX::DebugSettings,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_01883b00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 454 ; VA 0x0048d620 ; FUN_0048d620 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048d620(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5fa4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00897160();
  uVar3 = FUN_00911380();
  FUN_009ca670(uVar3,uVar2,s_ThreadPoolConfig_0211d7cc,s_Configuration_0211d7bc,uStack_24,0,0,0x1f,0
               ,0,1);
  uStack_8 = 0;
  DAT_0211d678 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::TaskSchedulerSettings,enum_RBX::TaskScheduler::ThreadPoolConfig>
                 ::vftable;
  _DAT_0211d6ac = uVar2;
  DAT_0211d6b0 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0211d6b0 == (undefined4 *)0x0) {
    DAT_0211d6b0 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211d6b0 =
         RBX::Reflection::
         PropDescriptor<class_RBX::TaskSchedulerSettings,enum_RBX::TaskScheduler::ThreadPoolConfig>
         ::
         GetSetImpl<enum_RBX::TaskScheduler::ThreadPoolConfig_(__thiscall_RBX::TaskSchedulerSettings::*)(void)const_,void_(__thiscall_RBX::TaskSchedulerSettings::*)(enum_RBX::TaskScheduler::ThreadPoolConfig)>
         ::vftable;
    DAT_0211d6b0[2] = FUN_00819220;
    DAT_0211d6b0[3] = 0;
    DAT_0211d6b0[4] = FUN_00912730;
    DAT_0211d6b0[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0211d6b4 = FUN_00897160();
  cVar1 = (*(code *)DAT_0211d678[3])();
  if (cVar1 != '\0') {
    _DAT_0211d69c = _DAT_0211d69c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211d678[2])();
  if (cVar1 != '\0') {
    _DAT_0211d69c = _DAT_0211d69c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01883b40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 455 ; VA 0x0048d9b0 ; FUN_0048d9b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048d9b0(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7013;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630();
  FUN_009cb970(uVar1,s_CloudEditSelectionChanged_021200c0,6,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0211f4c4 = 0x400;
  iStack_8 = 0;
  _DAT_0211f490 =
       RBX::Reflection::
       EventDesc<class_RBX::Player,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>_RBX::Player::*>
       ::vftable;
  FUN_0086e3d0(s_newSelection_021200b0);
  FUN_008882f0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0211f4b8 = uStack_1c;
  _DAT_0211f4bc = uStack_18;
  _DAT_0211f4c0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_0211f490 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Player,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>)>_RBX::Player::*>
       ::vftable;
  _DAT_0211f4c8 = 1;
  _DAT_0211f4cc = 0;
  FUN_016f3654(&LAB_01883c80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 456 ; VA 0x0048db60 ; FUN_0048db60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048db60(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7040;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee1f84) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee1f84,uVar3,0,0,0x1f);
    if (DAT_01ee1f84 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01ee1f60 = RBX::Reflection::RefType<class_RBX::ModelInstance*>::vftable;
      FUN_016f3654(&LAB_01884f90);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ee1f84);
    }
  }
  uVar2 = FUN_00913630();
  FUN_009ca670(uVar2,&DAT_01ee1f60,s_Character_0211faa0,&DAT_021197d4,uVar3,uVar4,uVar5,uVar6,0,0,0)
  ;
  uStack_8 = 1;
  DAT_0211e300 = RBX::Reflection::RefPropDescriptor<class_RBX::Player,class_RBX::ModelInstance>::
                 vftable;
  _DAT_0211e334 =
       RBX::Reflection::RefPropDescriptor<class_RBX::Player,class_RBX::ModelInstance>::vftable;
  DAT_0211e338 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0211e338 == (undefined4 *)0x0) {
    DAT_0211e338 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211e338 =
         RBX::Reflection::PropDescriptor<class_RBX::Player,class_RBX::ModelInstance*>::
         GetSetImpl<class_RBX::ModelInstance*_(__thiscall_RBX::Player::*)(void)const_,void_(__thiscall_RBX::Player::*)(class_RBX::ModelInstance*)>
         ::vftable;
    DAT_0211e338[2] = FUN_00926ca0;
    DAT_0211e338[3] = 0;
    DAT_0211e338[4] = FUN_009326f0;
    DAT_0211e338[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_0211e300[3])();
  if (cVar1 != '\0') {
    _DAT_0211e324 = _DAT_0211e324 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211e300[2])();
  if (cVar1 != '\0') {
    _DAT_0211e324 = _DAT_0211e324 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01883ca0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 457 ; VA 0x0048dd00 ; FUN_0048dd00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048dd00(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c706c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00913630();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Player,class_G3D::Vector3>::
              GetSetImpl<class_G3D::Vector3_(__thiscall_RBX::Player::*)(void)const_,void_(__thiscall_RBX::Player::*)(class_G3D::Vector3)>
              ::vftable;
    puVar3[2] = FUN_006e5bc0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00932fc0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d870();
  FUN_009ca670(uVar2,uVar4,s_ChararacterRegionId_021201ac,&DAT_021197d4,uStack_24,0,0,2,6,6,0);
  DAT_0211f6c8 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0211f6fc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0211f6ec = _DAT_0211f6ec & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0211f6c8[2])();
    if (cVar1 != '\0') {
      _DAT_0211f6ec = _DAT_0211f6ec & 0xfffffff3;
    }
  }
  DAT_0211f6c8 = RBX::Reflection::PropDescriptor<class_RBX::Player,class_G3D::Vector3>::vftable;
  FUN_016f3654(&LAB_01883cc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 458 ; VA 0x0048dfb0 ; FUN_0048dfb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048dfb0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c709c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00913630();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Player,bool>::
              GetSetImpl<bool_(__thiscall_RBX::Player::*)(void)const_,void_(__thiscall_RBX::Player::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_0085e840;
    puVar3[3] = 0;
    puVar3[4] = FUN_00933a00;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_GameplayPaused_0211fd0c,s_Behavior_0211a8f8,uStack_24,0,0,0x1f,0,7,0);
  DAT_0211eac0 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0211eaf4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0211eae4 = _DAT_0211eae4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0211eac0[2])();
    if (cVar1 != '\0') {
      _DAT_0211eae4 = _DAT_0211eae4 & 0xfffffff3;
    }
  }
  DAT_0211eac0 = RBX::Reflection::PropDescriptor<class_RBX::Player,bool>::vftable;
  FUN_016f3654(&LAB_01883d20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 459 ; VA 0x0048e130 ; FUN_0048e130 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048e130(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c70ba;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00913630();
  FUN_0089a380(uVar3,s_OsPlatform_0211fc94,&DAT_021197d4,0);
  uStack_8 = 0;
  DAT_0211e968 = RBX::Reflection::
                 BoundProp<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,1>
                 ::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::
              BoundProp<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,1>
              ::BoundPropGetSet<class_RBX::Player>::vftable;
    puVar4[1] = &DAT_0211e968;
    puVar4[2] = 0x1fc;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  if (DAT_0211e99c != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_0211e99c;
    DAT_0211e99c = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_0211e99c;
  }
  DAT_0211e99c = puVar4;
  cVar2 = (*(code *)DAT_0211e968[3])();
  if (cVar2 != '\0') {
    _DAT_0211e98c = _DAT_0211e98c & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_0211e968[2])();
  if (cVar2 != '\0') {
    _DAT_0211e98c = _DAT_0211e98c & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 460 ; VA 0x0048e490 ; FUN_0048e490 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048e490(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c70f0;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf874) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf874,uVar3,0,0,0x1f);
    if (DAT_01edf874 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01edf850 = RBX::Reflection::RefType<class_RBX::Instance*>::vftable;
      FUN_016f3654(&LAB_018813c0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edf874);
    }
  }
  uVar2 = FUN_00913630();
  FUN_009ca670(uVar2,&DAT_01edf850,s_ReplicationFocus_0211fb38,&DAT_021197d4,uVar3,uVar4,uVar5,uVar6
               ,0,0,0);
  uStack_8 = 1;
  DAT_0211e3e4 = RBX::Reflection::RefPropDescriptor<class_RBX::Player,class_RBX::Instance>::vftable;
  _DAT_0211e418 = RBX::Reflection::RefPropDescriptor<class_RBX::Player,class_RBX::Instance>::vftable
  ;
  DAT_0211e41c = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0211e41c == (undefined4 *)0x0) {
    DAT_0211e41c = (undefined4 *)0x0;
  }
  else {
    *DAT_0211e41c =
         RBX::Reflection::PropDescriptor<class_RBX::Player,class_RBX::Instance*>::
         GetSetImpl<class_RBX::Instance*_(__thiscall_RBX::Player::*)(void)const_,void_(__thiscall_RBX::Player::*)(class_RBX::Instance*)>
         ::vftable;
    DAT_0211e41c[2] = FUN_00927fa0;
    DAT_0211e41c[3] = 0;
    DAT_0211e41c[4] = FUN_009344e0;
    DAT_0211e41c[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_0211e3e4[3])();
  if (cVar1 != '\0') {
    _DAT_0211e408 = _DAT_0211e408 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211e3e4[2])();
  if (cVar1 != '\0') {
    _DAT_0211e408 = _DAT_0211e408 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01883de0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 461 ; VA 0x0048e740 ; FUN_0048e740 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048e740(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7120;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1d;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee1f34) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee1f34,uVar3,0,0,0x1d);
    if (DAT_01ee1f34 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01ee1f10 = RBX::Reflection::RefType<class_RBX::Team*>::vftable;
      FUN_016f3654(&LAB_01884fb0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ee1f34);
    }
  }
  uVar2 = FUN_00913630();
  FUN_009ca670(uVar2,&DAT_01ee1f10,&DAT_0211fd60,&DAT_0211fd60,uVar3,uVar4,uVar5,uVar6,0,0,0);
  uStack_8 = 1;
  DAT_0211e66c = RBX::Reflection::RefPropDescriptor<class_RBX::Player,class_RBX::Team>::vftable;
  _DAT_0211e6a0 = RBX::Reflection::RefPropDescriptor<class_RBX::Player,class_RBX::Team>::vftable;
  DAT_0211e6a4 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0211e6a4 == (undefined4 *)0x0) {
    DAT_0211e6a4 = (undefined4 *)0x0;
  }
  else {
    *DAT_0211e6a4 =
         RBX::Reflection::PropDescriptor<class_RBX::Player,class_RBX::Team*>::
         GetSetImpl<class_RBX::Team*_(__thiscall_RBX::Player::*)(void)const_,void_(__thiscall_RBX::Player::*)(class_RBX::Team*)>
         ::vftable;
    DAT_0211e6a4[2] = FUN_009282a0;
    DAT_0211e6a4[3] = 0;
    DAT_0211e6a4[4] = FUN_00934950;
    DAT_0211e6a4[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_0211e66c[3])();
  if (cVar1 != '\0') {
    _DAT_0211e690 = _DAT_0211e690 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0211e66c[2])();
  if (cVar1 != '\0') {
    _DAT_0211e690 = _DAT_0211e690 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01883e40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 462 ; VA 0x0048ea60 ; FUN_0048ea60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048ea60(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c714c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00913630();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Player,class_RBX::BinaryString>::
              GetSetImpl<class_RBX::BinaryString_const&_(__thiscall_RBX::Player::*)(void)const_,void_(__thiscall_RBX::Player::*)(class_RBX::BinaryString_const&)>
              ::vftable;
    puVar3[2] = &LAB_00927c90;
    puVar3[3] = 0;
    puVar3[4] = FUN_009341f0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cf00();
  FUN_009ca670(uVar2,uVar4,s_RawJoinData_0212016c,&DAT_021197d4,uStack_24,0,0,0xe,6,6,0);
  DAT_0211f600 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::BinaryString>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0211f634 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0211f624 = _DAT_0211f624 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0211f600[2])();
    if (cVar1 != '\0') {
      _DAT_0211f624 = _DAT_0211f624 & 0xfffffff3;
    }
  }
  DAT_0211f600 = RBX::Reflection::PropDescriptor<class_RBX::Player,class_RBX::BinaryString>::vftable
  ;
  FUN_016f3654(&LAB_01883ea0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 463 ; VA 0x0048f230 ; FUN_0048f230 */

void FUN_0048f230(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00918670(FUN_00929bb0,0,s_isFriendsWith_0211fc04,s_userId_0211fb64,0,
               CONCAT44(&DAT_0211e738,uStack_10),0);
  FUN_016f3654(&LAB_01883fc0);
  return;
}



/* FUNCTION 464 ; VA 0x0048f290 ; FUN_0048f290 */

void FUN_0048f290(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_009184f0(FUN_00929fd0,0,s_loadBoolean_0211f8f4,&DAT_0211f870,0,
               CONCAT44(&DAT_0211db58,uStack_10),0);
  FUN_016f3654(&LAB_01883fe0);
  return;
}



/* FUNCTION 465 ; VA 0x0048f2f0 ; FUN_0048f2f0 */

void FUN_0048f2f0(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00917b70(FUN_0092c4b0,0,s_loadInstance_0211f924,&DAT_0211f870,0,
               CONCAT44(&DAT_0211dc78,uStack_10),0);
  FUN_016f3654(&LAB_01884000);
  return;
}



/* FUNCTION 466 ; VA 0x0048f350 ; FUN_0048f350 */

void FUN_0048f350(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00917cf0(FUN_0092c540,0,s_loadNumber_0211f90c,&DAT_0211f870,0,
               CONCAT44(&DAT_0211dbe8,uStack_10),0);
  FUN_016f3654(&LAB_01884020);
  return;
}



/* FUNCTION 467 ; VA 0x0048f3b0 ; FUN_0048f3b0 */

void FUN_0048f3b0(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_009179f0(FUN_0092c5d0,0,s_loadString_0211f8dc,&DAT_0211f870,0,
               CONCAT44(&DAT_0211dac8,uStack_10),0);
  FUN_016f3654(&LAB_01884040);
  return;
}



/* FUNCTION 468 ; VA 0x0048f410 ; FUN_0048f410 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048f410(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c717e;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_0211dba0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,&DAT_0211dba0);
  FUN_009cb790(uVar1,s_saveBoolean_0211f900,0,CONCAT44(puVar3,uVar2),0);
  _DAT_0211dde0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Player,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool),2>
       ::vftable;
  _DAT_0211de18 = FUN_00931e40;
  _DAT_0211de1c = 0;
  _DAT_0211de20 = 0;
  DAT_0211de24 = 0;
  uStack_8 = 2;
  FUN_009218e0();
  FUN_016f3654(&LAB_01884060);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 469 ; VA 0x0048f4d0 ; FUN_0048f4d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048f4d0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c71ae;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_0211dcc0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,&DAT_0211dcc0);
  FUN_009cb790(uVar1,s_saveInstance_0211f934,0,CONCAT44(puVar3,uVar2),0);
  _DAT_0211df00 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Player,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>),2>
       ::vftable;
  _DAT_0211df38 = FUN_009320a0;
  _DAT_0211df3c = 0;
  _DAT_0211df40 = 0;
  DAT_0211df44 = 0;
  uStack_8 = 2;
  FUN_00921690();
  FUN_016f3654(&LAB_01884090);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 470 ; VA 0x0048f590 ; FUN_0048f590 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048f590(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c71de;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_0211dc30;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,&DAT_0211dc30);
  FUN_009cb790(uVar1,s_saveNumber_0211f918,0,CONCAT44(puVar3,uVar2),0);
  _DAT_0211de70 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Player,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,double),2>
       ::vftable;
  _DAT_0211dea8 = FUN_009321a0;
  _DAT_0211deac = 0;
  _DAT_0211deb0 = 0;
  DAT_0211deb4 = 0;
  uStack_8 = 2;
  FUN_00921490();
  FUN_016f3654(&LAB_018840f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 471 ; VA 0x0048f650 ; FUN_0048f650 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048f650(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c720e;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_0211db10;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,&DAT_0211db10);
  FUN_009cb790(uVar1,s_saveString_0211f8e8,0,CONCAT44(puVar3,uVar2),0);
  _DAT_0211dd50 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Player,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_0211dd88 = FUN_00932270;
  _DAT_0211dd8c = 0;
  _DAT_0211dd90 = 0;
  _DAT_0211dd94 = 0;
  uStack_8 = 2;
  FUN_00921260();
  FUN_016f3654(&LAB_01884120);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 472 ; VA 0x0048f760 ; FUN_0048f760 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048f760(void)

{
  undefined4 uVar1;
  undefined auStack_1e0 [432];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c724e;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630();
  FUN_009cb970(uVar1,s_RemoteFriendRequestSignal_0211f848,5,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0211da7c = 0x3a0;
  iStack_8 = 0;
  _DAT_0211da48 =
       RBX::Reflection::
       EventDesc<class_RBX::Player,void___cdecl(__int64,enum_RBX::FriendService_FriendEventType),class_rbx::remote_signal<void___cdecl(__int64,enum_RBX::FriendService_FriendEventType)>,class_rbx::remote_signal<void___cdecl(__int64,enum_RBX::FriendService_FriendEventType)>_RBX::Player::*>
       ::vftable;
  FUN_0086e3d0(s_otherUserId_0211f83c);
  FUN_0088da50();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_eventType_0211f830);
  thunk_FUN_00bfa7a0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1e0,&uStack_30,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_0211da70 = uStack_1c;
  _DAT_0211da74 = uStack_18;
  _DAT_0211da78 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1e0,0xd8,2,FUN_00688b10);
  _DAT_0211da48 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Player,void___cdecl(__int64,enum_RBX::FriendService_FriendEventType),class_rbx::remote_signal<void___cdecl(__int64,enum_RBX::FriendService_FriendEventType)>,class_rbx::remote_signal<void___cdecl(__int64,enum_RBX::FriendService_FriendEventType)>_RBX::Player::*>
       ::vftable;
  _DAT_0211da80 = 0;
  _DAT_0211da84 = 0;
  FUN_016f3654(&LAB_01884150);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 473 ; VA 0x0048f8f0 ; FUN_0048f8f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048f8f0(void)

{
  undefined4 uVar1;
  undefined auStack_1e0 [432];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c728e;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630();
  FUN_009cb970(uVar1,s_RemoteInsert_0211fec0,3,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0211efdc = 0x390;
  iStack_8 = 0;
  _DAT_0211efa8 =
       RBX::Reflection::
       EventDesc<class_RBX::Player,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_G3D::Vector3),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_G3D::Vector3)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_G3D::Vector3)>_RBX::Player::*>
       ::vftable;
  FUN_0086e3d0(&DAT_0211c024);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_position_0211fd1c);
  FUN_0088d870();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1e0,&uStack_30,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_0211efd0 = uStack_1c;
  _DAT_0211efd4 = uStack_18;
  _DAT_0211efd8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1e0,0xd8,2,FUN_00688b10);
  _DAT_0211efa8 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Player,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_G3D::Vector3),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_G3D::Vector3)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_G3D::Vector3)>_RBX::Player::*>
       ::vftable;
  _DAT_0211efe0 = 0;
  _DAT_0211efe4 = 0;
  FUN_016f3654(&LAB_01884160);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 474 ; VA 0x0048fa80 ; FUN_0048fa80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048fa80(void)

{
  undefined4 uVar1;
  undefined auStack_2b8 [648];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c72d9;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630();
  FUN_009cb970(uVar1,s_ScriptSecurityError_0211feac,3,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0211ef9c = 0x388;
  iStack_8 = 0;
  _DAT_0211ef68 =
       RBX::Reflection::
       EventDesc<class_RBX::Player,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::Player::*>
       ::vftable;
  FUN_0086e3d0(&DAT_0211fea4);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_error_0211fe9c);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_stack_0211fe94);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b8,&uStack_30,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_0211ef90 = uStack_1c;
  _DAT_0211ef94 = uStack_18;
  _DAT_0211ef98 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b8,0xd8,3,FUN_00688b10);
  _DAT_0211ef68 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Player,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::Player::*>
       ::vftable;
  _DAT_0211efa0 = 0;
  _DAT_0211efa4 = 0;
  FUN_016f3654(&LAB_01884170);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 475 ; VA 0x0048fd20 ; FUN_0048fd20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048fd20(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7313;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630();
  FUN_009cb970(uVar1,s_CharacterRemoving_0211fe44,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0211eeb4 = 0x3d8;
  iStack_8 = 0;
  _DAT_0211ee80 =
       RBX::Reflection::
       EventDesc<class_RBX::Player,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Player::*>
       ::vftable;
  FUN_0086e3d0(s_character_0211fe0c);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0211eea8 = uStack_1c;
  _DAT_0211eeac = uStack_18;
  _DAT_0211eeb0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_0211ee80 =
       RBX::Reflection::
       EventDesc<class_RBX::Player,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Player::*>
       ::vftable;
  FUN_016f3654(&LAB_018841b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 476 ; VA 0x0048fe70 ; FUN_0048fe70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048fe70(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c734e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630();
  FUN_009cb970(uVar1,s_FriendStatusChanged_0211fe78,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0211ef24 = 0x3e4;
  iStack_8 = 0;
  _DAT_0211eef0 =
       RBX::Reflection::
       EventDesc<class_RBX::Player,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::FriendService_FriendStatus),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::FriendService_FriendStatus)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::FriendService_FriendStatus)>_RBX::Player::*>
       ::vftable;
  FUN_0086e3d0(s_player_0211f800);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_friendStatus_0211fe68);
  thunk_FUN_00935e70();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_0211ef18 = uStack_1c;
  _DAT_0211ef1c = uStack_18;
  _DAT_0211ef20 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_0211eef0 =
       RBX::Reflection::
       EventDesc<class_RBX::Player,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::FriendService_FriendStatus),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::FriendService_FriendStatus)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::FriendService_FriendStatus)>_RBX::Player::*>
       ::vftable;
  FUN_016f3654(&LAB_018841c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 477 ; VA 0x0048ffe0 ; FUN_0048ffe0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048ffe0(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7383;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630();
  FUN_009cb970(uVar1,s_Idled_0211fe60,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0211eeec = 0x3e0;
  iStack_8 = 0;
  _DAT_0211eeb8 =
       RBX::Reflection::
       EventDesc<class_RBX::Player,void___cdecl(double),class_rbx::signal<void___cdecl(double)>,class_rbx::signal<void___cdecl(double)>_RBX::Player::*>
       ::vftable;
  FUN_0086e3d0(&DAT_0211fe58);
  FUN_0088ca00();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0211eee0 = uStack_1c;
  _DAT_0211eee4 = uStack_18;
  _DAT_0211eee8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_0211eeb8 =
       RBX::Reflection::
       EventDesc<class_RBX::Player,void___cdecl(double),class_rbx::signal<void___cdecl(double)>,class_rbx::signal<void___cdecl(double)>_RBX::Player::*>
       ::vftable;
  FUN_016f3654(&LAB_018841d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 478 ; VA 0x00490130 ; FUN_00490130 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00490130(void)

{
  undefined4 uVar1;
  undefined auStack_2b8 [648];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c73c9;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630();
  FUN_009cb970(uVar1,s_OnTeleport_02120100,0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0211f504 = 1000;
  iStack_8 = 0;
  _DAT_0211f4d0 =
       RBX::Reflection::
       EventDesc<class_RBX::Player,void___cdecl(enum_RBX::TeleportService_TeleportState,__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(enum_RBX::TeleportService_TeleportState,__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(enum_RBX::TeleportService_TeleportState,__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::Player::*>
       ::vftable;
  FUN_0086e3d0(s_teleportState_021200f0);
  thunk_FUN_00adb7d0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_placeId_021200e8);
  FUN_0088da50();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_spawnName_021200dc);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b8,&uStack_30,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_0211f4f8 = uStack_1c;
  _DAT_0211f4fc = uStack_18;
  _DAT_0211f500 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b8,0xd8,3,FUN_00688b10);
  _DAT_0211f4d0 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Player,void___cdecl(enum_RBX::TeleportService_TeleportState,__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(enum_RBX::TeleportService_TeleportState,__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(enum_RBX::TeleportService_TeleportState,__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::Player::*>
       ::vftable;
  _DAT_0211f508 = 0;
  _DAT_0211f50c = 1;
  FUN_016f3654(&LAB_018841e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 479 ; VA 0x004902e0 ; FUN_004902e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004902e0(void)

{
  undefined4 uVar1;
  undefined auStack_2b8 [648];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7419;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630();
  FUN_009cb970(uVar1,s_OnTeleportInternal_02120130,6,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0211f544 = 0x3f0;
  iStack_8 = 0;
  _DAT_0211f510 =
       RBX::Reflection::
       EventDesc<class_RBX::Player,void___cdecl(enum_RBX::TeleportService_TeleportState,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(enum_RBX::TeleportService_TeleportState,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string...s_RBX::Reflection::Variant>_>_>_const_>,class_std::shared_ptr<class_RBX::Instance>)>_RBX::Player::*>
       ::vftable;
  FUN_0086e3d0(s_teleportState_021200f0);
  thunk_FUN_00adb7d0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_teleportInfo_02120120);
  FUN_008881d0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_customLoadingScreen_0212010c);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b8,&uStack_30,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_0211f538 = uStack_1c;
  _DAT_0211f53c = uStack_18;
  _DAT_0211f540 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b8,0xd8,3,FUN_00688b10);
  _DAT_0211f510 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Player,void___cdecl(enum_RBX::TeleportService_TeleportState,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(enum_RBX::TeleportService_TeleportState,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_...s_RBX::Reflection::Variant>_>_>_const_>,class_std::shared_ptr<class_RBX::Instance>)>_RBX::Player::*>
       ::vftable;
  _DAT_0211f548 = 0;
  _DAT_0211f54c = 0;
  FUN_016f3654(&LAB_018841f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 480 ; VA 0x00490490 ; FUN_00490490 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00490490(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c745e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630();
  FUN_009cb970(uVar1,s_Chatted_0211fe04,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0211edfc = 0x3c4;
  iStack_8 = 0;
  _DAT_0211edc8 =
       RBX::Reflection::
       EventDesc<class_RBX::Player,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>)>_RBX::Player::*>
       ::vftable;
  FUN_0086e3d0(s_message_02119b14);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_recipient_0211fdf8);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_0211edf0 = uStack_1c;
  _DAT_0211edf4 = uStack_18;
  _DAT_0211edf8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_0211edc8 =
       RBX::Reflection::
       EventDesc<class_RBX::Player,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>)>_RBX::Player::*>
       ::vftable;
  FUN_016f3654(&LAB_01884200);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 481 ; VA 0x00490650 ; FUN_00490650 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00490650(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7493;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630();
  FUN_009cb970(uVar1,s_SimulationRadiusChanged_0211fcb4,3,CONCAT44(uStack_2c,uStack_30),0);
  DAT_0211ea0c = 0x3b0;
  iStack_8 = 0;
  _DAT_0211e9d8 =
       RBX::Reflection::
       EventDesc<class_RBX::Player,void___cdecl(float),class_rbx::remote_signal<void___cdecl(float)>,class_rbx::remote_signal<void___cdecl(float)>_RBX::Player::*>
       ::vftable;
  FUN_0086e3d0(s_radius_0211fcac);
  FUN_0088c960();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0211ea00 = uStack_1c;
  _DAT_0211ea04 = uStack_18;
  _DAT_0211ea08 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_0211e9d8 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::Player,void___cdecl(float),class_rbx::remote_signal<void___cdecl(float)>,class_rbx::remote_signal<void___cdecl(float)>_RBX::Player::*>
       ::vftable;
  _DAT_0211ea10 = 0;
  _DAT_0211ea14 = 1;
  FUN_016f3654(&LAB_01884220);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 482 ; VA 0x004907b0 ; FUN_004907b0 */

void FUN_004907b0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00917e70(FUN_0092fea0,0,s_ProveRealPlayer_021201c0,s_reason_02119920,5,uStack_10,0);
  FUN_016f3654(&LAB_01884230);
  return;
}



/* FUNCTION 483 ; VA 0x00490810 ; FUN_00490810 */

void FUN_00490810(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00917e70(FUN_00932560,0,s_SetBotStatus_021201d0,s_reason_02119920,5,uStack_10,0);
  FUN_016f3654(&LAB_01884250);
  return;
}



/* FUNCTION 484 ; VA 0x00490870 ; FUN_00490870 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00490870(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c74aa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,0);
  FUN_009cb790(uVar1,s_HasAppearanceLoaded_0211ff20,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211f098 = RBX::Reflection::BoundFuncDesc<class_RBX::Player,bool___cdecl(void),0>::vftable;
  _DAT_0211f0d0 = &LAB_00926bc0;
  _DAT_0211f0d4 = 0;
  _DAT_0211f0bc = FUN_0088daf0();
  FUN_016f3654(&LAB_01884270);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 485 ; VA 0x00490910 ; FUN_00490910 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00490910(void)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined8 uStack_e8;
  undefined4 uStack_e0;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c750c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00913630();
  FUN_009cb790(uVar2,s_DistanceFromCharacter_0211fbcc,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211e6a8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Player,float___cdecl(class_G3D::Vector3),1>::
       vftable;
  _DAT_0211e6e0 = FUN_00922280;
  _DAT_0211e6e4 = 0;
  DAT_0211e6e8 = (undefined8 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211e6cc = FUN_0088c960();
  puVar1 = DAT_0211e6e8;
  if (DAT_0211e6e8 == (undefined8 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088d870();
    iStack_ec = 0;
    uStack_e8 = *puVar1;
    uStack_e0 = *(undefined4 *)(puVar1 + 1);
    iStack_ec = FUN_006315b0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088d870();
  uVar3 = FUN_0086e3d0(s_point_0211fbc4);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_01884280);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 486 ; VA 0x00490ac0 ; FUN_00490ac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00490ac0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c752a;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,0);
  FUN_009cb790(uVar1,s_IsUserAvailableForExperiment_0211f9fc,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211e120 = RBX::Reflection::BoundFuncDesc<class_RBX::Player,bool___cdecl(void),0>::vftable;
  _DAT_0211e158 = FUN_00926b10;
  _DAT_0211e15c = 0;
  _DAT_0211e144 = FUN_0088daf0();
  FUN_016f3654(&LAB_018842a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 487 ; VA 0x00490b60 ; FUN_00490b60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00490b60(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c758c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00913630();
  FUN_009cb790(uVar2,s_GetFriendStatus_0211fbe4,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211e6f0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Player,enum_RBX::FriendService_FriendStatus___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_0211e728 = FUN_00926e10;
  _DAT_0211e72c = 0;
  DAT_0211e730 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211e714 = thunk_FUN_00935e70();
  puVar4 = DAT_0211e730;
  if (DAT_0211e730 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cdc0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_006309e0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_player_0211f800);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_018842b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 488 ; VA 0x00490d30 ; FUN_00490d30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00490d30(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c75aa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,0);
  FUN_009cb790(uVar1,s_GetGameSessionID_0211fa78,6,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211e280 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Player,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(void),0>
       ::vftable;
  _DAT_0211e2b8 = FUN_005d4890;
  _DAT_0211e2bc = 0;
  _DAT_0211e2a4 = FUN_0088cb40();
  FUN_016f3654(&LAB_01884300);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 489 ; VA 0x00490dd0 ; FUN_00490dd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00490dd0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c75ca;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,0);
  FUN_009cb790(uVar1,s_GetJoinData_02120160,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211f5c0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Player,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0211f5f8 = FUN_00928390;
  _DAT_0211f5fc = 0;
  _DAT_0211f5e4 = FUN_008881d0();
  FUN_016f3654(&LAB_01884310);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 490 ; VA 0x00490e70 ; FUN_00490e70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00490e70(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c75ea;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,0);
  FUN_009cb790(uVar1,s_GetUnder13_0211f9f0,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211e0e0 = RBX::Reflection::BoundFuncDesc<class_RBX::Player,bool___cdecl(void),0>::vftable;
  _DAT_0211e118 = FUN_00928330;
  _DAT_0211e11c = 0;
  _DAT_0211e104 = FUN_0088daf0();
  FUN_016f3654(&LAB_01884320);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 491 ; VA 0x00490f10 ; FUN_00490f10 */

void FUN_00490f10(void)

{
  FUN_00918670(FUN_00929a00,0,s_IsBestFriendsWith_0211fc14,s_userId_0211fb64,0,1,0);
  FUN_016f3654(&LAB_01884330);
  return;
}



/* FUNCTION 492 ; VA 0x00490f70 ; FUN_00490f70 */

void FUN_00490f70(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00918670(FUN_00929bb0,0,s_IsFriendsWith_0211fbf4,s_userId_0211fb64,0,uStack_10,0);
  FUN_016f3654(&LAB_01884350);
  return;
}



/* FUNCTION 493 ; VA 0x00490fd0 ; FUN_00490fd0 */

void FUN_00490fd0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00918670(FUN_00929da0,0,s_IsInGroup_0211fc30,s_groupId_0211fc28,0,uStack_10,0);
  FUN_016f3654(&LAB_01884370);
  return;
}



/* FUNCTION 494 ; VA 0x00491030 ; FUN_00491030 */

void FUN_00491030(void)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = &DAT_0211fa6e;
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_0211fa6e,pcVar2 + -0x211fa6e);
  FUN_00917ff0(FUN_0092c860,0,&DAT_0211fa70,s_message_02119b14);
  FUN_016f3654();
  return;
}



/* FUNCTION 495 ; VA 0x004910d0 ; FUN_004910d0 */

void FUN_004910d0(void)

{
  FUN_009181d0(FUN_0092a060,0,s_LoadCharacterAppearance_0211fb20,s_assetInstance_0211fb10,0,1,0);
  FUN_016f3654(&LAB_018843b0);
  return;
}



/* FUNCTION 496 ; VA 0x00491130 ; FUN_00491130 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00491130(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c760a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,0);
  FUN_009cb790(uVar1,s_ClearCharacterAppearance_0211faf4,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0211e420 = RBX::Reflection::BoundFuncDesc<class_RBX::Player,void___cdecl(void),0>::vftable;
  _DAT_0211e458 = FUN_00930400;
  _DAT_0211e45c = 0;
  _DAT_0211e444 = FUN_00888530();
  FUN_016f3654(&LAB_01884400);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 497 ; VA 0x004911d0 ; FUN_004911d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004911d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c763e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630(uVar2,0);
  FUN_009cb820(uVar1,s_RequestStreamAroundAsync_0211fd28,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0211eaf8 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::Player,void___cdecl(class_G3D::Vector3,double),2>::vftable;
  _DAT_0211eb30 = FUN_00931360;
  _DAT_0211eb34 = 0;
  DAT_0211eb38 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  DAT_0211eb3c = (undefined8 *)FUN_01674e20(8);
  if (DAT_0211eb3c == (undefined8 *)0x0) {
    DAT_0211eb3c = (undefined8 *)0x0;
  }
  else {
    *DAT_0211eb3c = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00921f60();
  FUN_016f3654(&LAB_01884410);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 498 ; VA 0x004912b0 ; FUN_004912b0 */

void FUN_004912b0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00917e70(FUN_00932340,0,s_SetAccountAge_0211fa60,s_accountAge_0211fa54,1,uStack_10,0);
  FUN_016f3654(&LAB_01884450);
  return;
}



/* FUNCTION 499 ; VA 0x00491310 ; FUN_00491310 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00491310(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c769c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630();
  FUN_009cb790(uVar1,s_SetMembershipType_0211fa40,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0211e1a8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::Player,void___cdecl(enum_RBX::MembershipType),1>::
       vftable;
  _DAT_0211e1e0 = FUN_00933eb0;
  _DAT_0211e1e4 = 0;
  DAT_0211e1e8 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0211e1cc = FUN_00888530();
  puVar3 = DAT_0211e1e8;
  if (DAT_0211e1e8 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = thunk_FUN_005f32d0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_005f3850();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = thunk_FUN_005f32d0();
  uVar2 = FUN_0086e3d0(s_membershipType_0211fa30);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01884470);
  ExceptionList = pvStack_10;
  return;
}


