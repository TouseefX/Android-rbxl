/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 6500 ; VA 0x006129b0 ; thunk_FUN_00617ad0 */

void __fastcall thunk_FUN_00617ad0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0xc) * 0xc;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 6501 ; VA 0x006129c0 ; FUN_006129c0 */

void __fastcall FUN_006129c0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_00602e00(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0xc) * 0xc;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 6502 ; VA 0x00612a40 ; FUN_00612a40 */

void __fastcall FUN_00612a40(int *param_1)

{
  void **ppvVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar3 = *param_1;
  if (iVar3 != 0) {
    iVar4 = param_1[1];
    ExceptionList = &pvStack_10;
    ppvVar1 = &pvStack_10;
    if (iVar3 != iVar4) {
      do {
        uStack_8 = 0;
        FUN_01674ea0(*(undefined4 *)(iVar3 + 4));
        *(undefined4 *)(iVar3 + 4) = 0;
        *(undefined4 *)(iVar3 + 8) = 0;
        *(undefined4 *)(iVar3 + 0xc) = 0;
        iVar3 = iVar3 + 0x10;
      } while (iVar3 != iVar4);
      iVar3 = *param_1;
      ppvVar1 = (void **)ExceptionList;
    }
    ExceptionList = ppvVar1;
    uStack_8 = 0xffffffff;
    uVar2 = param_1[2] - iVar3 & 0xfffffff0;
    iVar4 = iVar3;
    if (0xfff < uVar2) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6503 ; VA 0x00612b00 ; FUN_00612b00 */

void __fastcall FUN_00612b00(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1 & 0xfffffff0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 6504 ; VA 0x00612b60 ; FUN_00612b60 */

void FUN_00612b60(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00617b40();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6505 ; VA 0x00612b90 ; FUN_00612b90 */

void __fastcall FUN_00612b90(int *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  
  iVar4 = *param_1;
  if (iVar4 != 0) {
    iVar5 = param_1[1];
    if (iVar4 != iVar5) {
      do {
        piVar1 = *(int **)(iVar4 + 0xc);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[1] + -1;
          piVar1[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar2 = piVar1[2] + -1;
            piVar1[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        piVar1 = *(int **)(iVar4 + 4);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[1] + -1;
          piVar1[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar2 = piVar1[2] + -1;
            piVar1[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        iVar4 = iVar4 + 0x18;
      } while (iVar4 != iVar5);
      iVar4 = *param_1;
    }
    uVar3 = ((param_1[2] - iVar4) / 0x18) * 0x18;
    iVar5 = iVar4;
    if (0xfff < uVar3) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 6506 ; VA 0x00612c70 ; FUN_00612c70 */

void __fastcall FUN_00612c70(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (*param_1 != 0) {
    FUN_00616fc0(*param_1,param_1[1]);
    iVar1 = *param_1;
    uVar3 = param_1[2] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 6507 ; VA 0x00612cd0 ; thunk_FUN_00617bc0 */

void __fastcall thunk_FUN_00617bc0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x14) * 0x14;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 6508 ; VA 0x00612ce0 ; FUN_00612ce0 */

void __fastcall FUN_00612ce0(int *param_1)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  
  puVar2 = (undefined4 *)*param_1;
  if (puVar2 != (undefined4 *)0x0) {
    puVar3 = (undefined4 *)param_1[1];
    if (puVar2 != puVar3) {
      do {
        (**(code **)*puVar2)(0);
        puVar2 = puVar2 + 0x16;
      } while (puVar2 != puVar3);
      puVar2 = (undefined4 *)*param_1;
    }
    uVar1 = ((param_1[2] - (int)puVar2) / 0x58) * 0x58;
    puVar3 = puVar2;
    if (0xfff < uVar1) {
      puVar3 = (undefined4 *)puVar2[-1];
      uVar1 = uVar1 + 0x23;
      if (0x1f < (uint)((int)puVar2 + (-4 - (int)puVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 6509 ; VA 0x00612d60 ; FUN_00612d60 */

void __fastcall FUN_00612d60(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x18) * 0x18;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 6510 ; VA 0x00612dd0 ; FUN_00612dd0 */

void __fastcall FUN_00612dd0(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_0056cd30();
        iVar2 = iVar2 + 4;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = param_1[2] - iVar2 & 0xfffffffc;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 6511 ; VA 0x00612e40 ; FUN_00612e40 */

void __fastcall FUN_00612e40(undefined4 *param_1)

{
  *param_1 = RakNet::AbstractBitStream::vftable;
  return;
}



/* FUNCTION 6512 ; VA 0x00612e50 ; FUN_00612e50 */

void __fastcall FUN_00612e50(undefined4 *param_1)

{
  *param_1 = RBX::TaskScheduler::Arbiter::vftable;
  return;
}



/* FUNCTION 6513 ; VA 0x00612e60 ; FUN_00612e60 */

void __fastcall FUN_00612e60(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 8);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00612e89. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 6514 ; VA 0x00612e90 ; FUN_00612e90 */

void __fastcall FUN_00612e90(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x14);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00612eb9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 6515 ; VA 0x00612ec0 ; FUN_00612ec0 */

void __fastcall FUN_00612ec0(uint *param_1)

{
  uint uVar1;
  uint uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0061ac80();
  FUN_00610ff0();
  uVar1 = param_1[2];
  uStack_8 = 0;
  if (uVar1 != 0) {
    uVar2 = param_1[1];
    do {
      uVar2 = (uVar2 + 1) % *param_1;
      uVar1 = uVar1 - 1;
    } while (uVar1 != 0);
    param_1[2] = 0;
    param_1[1] = uVar2;
  }
  FUN_01674ea0(param_1[3]);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6516 ; VA 0x00612f30 ; FUN_00612f30 */

void __fastcall FUN_00612f30(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  
  iVar5 = *(int *)(param_1 + 8);
  if (iVar5 != 0) {
    iVar6 = *(int *)(param_1 + 0xc);
    if (iVar5 != iVar6) {
      do {
        piVar2 = *(int **)(iVar5 + 4);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[1] + -1;
          piVar2[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            iVar3 = piVar2[2] + -1;
            piVar2[2] = iVar3;
            UNLOCK();
            if (iVar3 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        iVar5 = iVar5 + 8;
      } while (iVar5 != iVar6);
      iVar5 = *(int *)(param_1 + 8);
    }
    uVar4 = *(int *)(param_1 + 0x10) - iVar5 & 0xfffffff8;
    iVar6 = iVar5;
    if (0xfff < uVar4) {
      iVar6 = *(int *)(iVar5 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar5 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar4);
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar5 = piVar2[1] + -1;
    piVar2[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  return;
}



/* FUNCTION 6517 ; VA 0x00613000 ; FUN_00613000 */

void __fastcall FUN_00613000(undefined4 *param_1)

{
  *param_1 = RBX::Network::DeserializedItem::vftable;
  return;
}



/* FUNCTION 6518 ; VA 0x00613010 ; FUN_00613010 */

void __fastcall FUN_00613010(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Network::DeserializedNewInstanceItem::vftable;
  FUN_00617ad0();
  piVar2 = (int *)param_1[0x11];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0xf];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8 = 0;
  FUN_00617b40();
  *param_1 = RBX::Network::DeserializedItem::vftable;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6519 ; VA 0x006130b0 ; FUN_006130b0 */

void __fastcall FUN_006130b0(undefined4 *param_1)

{
  *param_1 = RBX::Voxel2::GridListener::vftable;
  return;
}



/* FUNCTION 6520 ; VA 0x006130c0 ; FUN_006130c0 */

void __fastcall FUN_006130c0(undefined4 *param_1)

{
  *param_1 = RBX::IMetric::vftable;
  return;
}



/* FUNCTION 6521 ; VA 0x006130d0 ; FUN_006130d0 */

void __fastcall FUN_006130d0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x18);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00613123. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 6522 ; VA 0x00613130 ; FUN_00613130 */

void __fastcall FUN_00613130(undefined4 *param_1)

{
  *param_1 = RBX::Network::Item::vftable;
  return;
}



/* FUNCTION 6523 ; VA 0x00613140 ; FUN_00613140 */

void __fastcall FUN_00613140(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x14) - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0;
  }
  FUN_006129c0();
  return;
}



/* FUNCTION 6524 ; VA 0x006131a0 ; FUN_006131a0 */

void __fastcall FUN_006131a0(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_01674ea0(*(undefined4 *)(param_1 + 4));
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6525 ; VA 0x00613200 ; FUN_00613200 */

void __fastcall FUN_00613200(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = param_1[3];
  if (iVar1 != 0) {
    uVar3 = param_1[5] - iVar1;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[5] = 0;
  }
  *param_1 = RakNet::AbstractBitStream::vftable;
  return;
}



/* FUNCTION 6526 ; VA 0x00613260 ; FUN_00613260 */

void __fastcall FUN_00613260(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = param_1[0xc];
  if (iVar1 != 0) {
    uVar3 = param_1[0xe] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_0061333f;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[0xc] = 0;
    param_1[0xd] = 0;
    param_1[0xe] = 0;
  }
  iVar1 = param_1[6];
  if (iVar1 != 0) {
    uVar3 = param_1[8] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_0061333f;
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[6] = 0;
    param_1[7] = 0;
    param_1[8] = 0;
  }
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar3 = param_1[2] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
LAB_0061333f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 6527 ; VA 0x00613350 ; FUN_00613350 */

void __fastcall FUN_00613350(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0152dda0(*param_1,param_1[1],param_1[2],param_1[3]);
  if ((*(char *)(param_1 + 4) != '\0') && (DAT_01d7ad40 != '\0')) {
    FUN_01532d10(*param_1,param_1[1],param_1[2],param_1[3]);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6528 ; VA 0x006133b0 ; FUN_006133b0 */

void __fastcall FUN_006133b0(int param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*(int *)(param_1 + 8) != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*(int *)(param_1 + 8) + 8))(param_1 + 0xc);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6529 ; VA 0x006133f0 ; FUN_006133f0 */

void __fastcall FUN_006133f0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794990;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[0x17] = RBX::Network::Replicator::vftable;
  *param_1 = RBX::Network::Replicator::vftable;
  param_1[0x19] = RBX::Network::Replicator::vftable;
  param_1[0x1a] = RBX::Network::Replicator::vftable;
  if (DAT_01ee420a != '\0') {
    FUN_016774b0(DAT_01ee420a,"Replicator destroyed: %p",param_1);
  }
  FUN_00612c70();
  piVar2 = (int *)param_1[0xe3e];
  if (piVar2 != (int *)0x0) {
    uStack_8 = 0;
    FUN_016899e0();
    puVar3 = (undefined4 *)*piVar2;
    if (puVar3 != (undefined4 *)0x0) {
      LOCK();
      iVar6 = puVar3[1] + -1;
      puVar3[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*puVar3)(0);
        uVar4 = GetProcessHeap(0,puVar3);
        HeapFree(uVar4);
      }
    }
    FUN_01674ea0(piVar2,4);
  }
  piVar2 = (int *)param_1[0xe3d];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_006113b0();
  FUN_0056c7e0();
  FUN_0056c7e0();
  LOCK();
  iVar6 = param_1[0xe2d];
  param_1[0xe2d] = 0;
  UNLOCK();
  if (iVar6 != 0) {
    CloseHandle(iVar6);
  }
  FUN_0151f390();
  uStack_8 = 1;
  FUN_01679490();
  iVar6 = param_1[0xe2a];
  if (iVar6 != 0) {
    piVar2 = (int *)(iVar6 + 4);
    LOCK();
    iVar5 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar6);
    }
  }
  piVar2 = (int *)param_1[0xe27];
  uStack_8 = 0xffffffff;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  iVar6 = param_1[0xe22];
  if (iVar6 != 0) {
    uVar7 = (param_1[0xe24] - iVar6 >> 2) * 4;
    iVar5 = iVar6;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(iVar6 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar6 - iVar5) - 4U) goto LAB_00613bf5;
    }
    FUN_01674ea0(iVar5,uVar7);
    param_1[0xe22] = 0;
    param_1[0xe23] = 0;
    param_1[0xe24] = 0;
  }
  iVar6 = param_1[0xe1f];
  if (iVar6 != 0) {
    uVar7 = (param_1[0xe21] - iVar6 >> 2) * 4;
    iVar5 = iVar6;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(iVar6 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar6 - iVar5) - 4U) goto LAB_00613bf5;
    }
    FUN_01674ea0(iVar5,uVar7);
    param_1[0xe1f] = 0;
    param_1[0xe20] = 0;
    param_1[0xe21] = 0;
  }
  iVar6 = param_1[0xe1c];
  if (iVar6 != 0) {
    uVar7 = (param_1[0xe1e] - iVar6 >> 2) * 4;
    iVar5 = iVar6;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(iVar6 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar6 - iVar5) - 4U) goto LAB_00613bf5;
    }
    FUN_01674ea0(iVar5,uVar7);
    param_1[0xe1c] = 0;
    param_1[0xe1d] = 0;
    param_1[0xe1e] = 0;
  }
  piVar2 = (int *)param_1[0xe17];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0xe15];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0xe13];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00612170();
  FUN_006120e0();
  FUN_00611f60();
  FUN_00611f60();
  FUN_00612650();
  FUN_00610df0();
  FUN_00611470();
  FUN_00611300();
  LOCK();
  iVar6 = param_1[0x7c2];
  param_1[0x7c2] = 0;
  UNLOCK();
  if (iVar6 != 0) {
    CloseHandle(iVar6);
  }
  FUN_006123a0();
  FUN_0061a9e0();
  FUN_006122a0();
  FUN_0061ab40();
  FUN_00612320();
  FUN_016dedfb(param_1 + 0x794);
  FUN_006126f0();
  FUN_00612460();
  FUN_006b1b80();
  FUN_006b1b80();
  piVar2 = (int *)param_1[0x77a];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x778];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x776];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x774];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x772];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_006baa90();
  FUN_0061ac80();
  FUN_00610ff0();
  iVar6 = param_1[0x689];
  uStack_8 = 2;
  if (iVar6 != 0) {
    uVar7 = param_1[0x688];
    do {
      uVar7 = (uVar7 + 1) % (uint)param_1[0x687];
      iVar6 = iVar6 + -1;
    } while (iVar6 != 0);
    param_1[0x689] = 0;
    param_1[0x688] = uVar7;
  }
  FUN_01674ea0(param_1[0x68a]);
  if (param_1[0x685] != 0) {
    FUN_006157e0(1);
  }
  FUN_00612580();
  piVar2 = (int *)param_1[0x65b];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  piVar2 = (int *)param_1[0x65a];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  piVar2 = (int *)param_1[0x659];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  piVar2 = (int *)param_1[0x658];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  piVar2 = (int *)param_1[0x657];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  piVar2 = (int *)param_1[0x656];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  piVar2 = (int *)param_1[0x655];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  piVar2 = (int *)param_1[0x654];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  piVar2 = (int *)param_1[0x653];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  piVar2 = (int *)param_1[0x652];
  if (piVar2 != (int *)0x0) {
    if (*piVar2 != 0) {
      FUN_00615040(*piVar2);
    }
    FUN_01674ea0(piVar2,4);
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_00612a40();
  iVar6 = param_1[0x647];
  if (iVar6 != 0) {
    uVar7 = param_1[0x649] - iVar6 & 0xfffffff0;
    iVar5 = iVar6;
    if (0xfff < uVar7) {
      iVar5 = *(int *)(iVar6 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar6 - iVar5) - 4U) {
LAB_00613bf5:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar7);
    param_1[0x647] = 0;
    param_1[0x648] = 0;
    param_1[0x649] = 0;
  }
  piVar2 = (int *)param_1[0x642];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_1[0x63d];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar6 = piVar2[2] + -1;
      piVar2[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00613260();
  FUN_00613260();
  FUN_00613140();
  piVar2 = (int *)param_1[0x1c];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[1] + -1;
    piVar2[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  param_1[0x1a] = RBX::Voxel2::GridListener::vftable;
  param_1[0x19] = RBX::IMetric::vftable;
  FUN_006bcd30();
  FUN_00611620();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6530 ; VA 0x00613c00 ; FUN_00613c00 */

void __fastcall FUN_00613c00(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 300);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01522e10();
  return;
}



/* FUNCTION 6531 ; VA 0x00613c40 ; FUN_00613c40 */

void __fastcall FUN_00613c40(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = RBX::physics_receiver_exception::vftable;
  uVar1 = param_1[8];
  if (0xf < uVar1) {
    iVar2 = param_1[3];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[7] = 0;
  param_1[8] = 0xf;
  *(undefined *)(param_1 + 3) = 0;
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  return;
}



/* FUNCTION 6532 ; VA 0x00613cb0 ; FUN_00613cb0 */

undefined4 * FUN_00613cb0(undefined4 param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)*param_2;
  if (puVar1 != (undefined4 *)0x0) {
    *(undefined4 *)*param_2 = *puVar1;
    *puVar1 = param_2;
    return puVar1 + 1;
  }
  puVar1 = (undefined4 *)FUN_00621d50();
  *puVar1 = param_2;
  return puVar1 + 1;
}



/* FUNCTION 6533 ; VA 0x00613ce0 ; FUN_00613ce0 */

void FUN_00613ce0(undefined4 *param_1,undefined4 *param_2)

{
  param_2 = (undefined4 *)*param_2;
  *param_1 = *param_2;
  *param_2 = param_1;
  return;
}



/* FUNCTION 6534 ; VA 0x00613d00 ; FUN_00613d00 */

undefined4 * __thiscall FUN_00613d00(undefined4 *param_1,undefined4 *param_2)

{
  if (param_1 != param_2) {
    FUN_00602830(*param_2,param_2[1],param_2);
  }
  return param_1;
}



/* FUNCTION 6535 ; VA 0x00613d30 ; FUN_00613d30 */

undefined4 * __thiscall FUN_00613d30(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  
  uVar2 = param_2[2];
  param_2[2] = 0;
  *param_1 = *param_2;
  uVar3 = param_2[1];
  param_2[1] = 0;
  param_1[1] = uVar3;
  piVar4 = (int *)param_1[2];
  param_1[2] = uVar2;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar5 = piVar4[1] + -1;
    piVar4[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 6536 ; VA 0x00613da0 ; FUN_00613da0 */

undefined4 * __thiscall FUN_00613da0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uVar2 = *param_1;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  *param_2 = uVar2;
  uVar2 = param_1[1];
  param_1[1] = param_2[1];
  param_2[1] = uVar2;
  uVar2 = param_1[2];
  param_1[2] = param_2[2];
  param_2[2] = uVar2;
  uVar2 = param_1[3];
  param_1[3] = param_2[3];
  param_2[3] = uVar2;
  if (param_1 + 4 != param_2 + 4) {
    puVar1 = param_2 + 7;
    param_1[4] = param_2[4];
    if (param_1 + 7 != puVar1) {
      FUN_0056d320();
      param_1[7] = *puVar1;
      param_1[8] = param_2[8];
      param_1[9] = param_2[9];
      *puVar1 = 0;
      param_2[8] = 0;
      param_2[9] = 0;
    }
    puVar1 = param_2 + 5;
    param_1[10] = param_2[10];
    param_1[0xb] = param_2[0xb];
    puVar3 = param_1 + 5;
    if (puVar3 != puVar1) {
      FUN_00619470();
      uVar2 = *puVar3;
      *puVar3 = *puVar1;
      *puVar1 = uVar2;
      uVar2 = param_1[6];
      param_1[6] = param_2[6];
      param_2[6] = uVar2;
    }
    uStack_8 = 1;
    FUN_00619470();
    FUN_005cb500(8);
  }
  if (param_1 + 0xc != param_2 + 0xc) {
    FUN_0061ac80();
    param_1[0xf] = param_2[0xf];
    param_1[0x10] = param_2[0x10];
    param_1[0x11] = param_2[0x11];
    param_1[0xd] = param_2[0xd];
    param_1[0xe] = param_2[0xe];
    param_2[0x11] = 0;
    param_2[0xe] = 0;
    param_2[0x10] = 0;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6537 ; VA 0x00613ee0 ; FUN_00613ee0 */

undefined4 * __thiscall FUN_00613ee0(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  
  *param_1 = *param_2;
  piVar9 = param_1 + 1;
  if (piVar9 != param_2 + 1) {
    iVar2 = param_2[2];
    iVar3 = param_2[1];
    iVar4 = *piVar9;
    uVar8 = iVar2 - iVar3 >> 3;
    uVar7 = param_1[3] - iVar4 >> 3;
    uVar5 = param_1[2] - iVar4 >> 3;
    if (uVar7 < uVar8) {
      if (0x1fffffff < uVar8) {
                    /* WARNING: Subroutine does not return */
        FUN_00577c30();
      }
      uVar5 = uVar8;
      if ((uVar7 <= 0x1fffffff - (uVar7 >> 1)) && (uVar5 = (uVar7 >> 1) + uVar7, uVar5 < uVar8)) {
        uVar5 = uVar8;
      }
      if (iVar4 != 0) {
        FUN_005596d0(iVar4,param_1[2],piVar9);
        FUN_0057d330(*piVar9,uVar7);
      }
      FUN_00616bd0(uVar5);
      uVar6 = FUN_0055c480(iVar3,iVar2,*piVar9);
      param_1[2] = uVar6;
      return param_1;
    }
    if (uVar5 < uVar8) {
      iVar1 = iVar3 + uVar5 * 8;
      FUN_00602d30(iVar3,iVar1,iVar4);
      uVar6 = FUN_0055c480(iVar1,iVar2,param_1[2]);
      param_1[2] = uVar6;
      return param_1;
    }
    iVar1 = iVar4 + uVar8 * 8;
    FUN_00602d30(iVar3,iVar2,iVar4);
    FUN_005596d0(iVar1,param_1[2],piVar9);
    param_1[2] = iVar1;
  }
  return param_1;
}



/* FUNCTION 6538 ; VA 0x00613ff0 ; FUN_00613ff0 */

int * __thiscall FUN_00613ff0(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = *param_2;
  LOCK();
  piVar1 = (int *)(iVar2 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  *param_1 = iVar2;
  FUN_0056cd30();
  return param_1;
}



/* FUNCTION 6539 ; VA 0x00614020 ; FUN_00614020 */

undefined4 __thiscall FUN_00614020(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  
  cVar1 = FUN_01679300(param_2);
  if (cVar1 != '\0') {
    FUN_01679490();
    FUN_016791c0(param_2);
  }
  return param_1;
}



/* FUNCTION 6540 ; VA 0x00614050 ; FUN_00614050 */

undefined4 * __thiscall FUN_00614050(int *param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puStack_8;
  
  puVar3 = param_2;
  puStack_8 = (undefined4 *)*param_1;
  cVar1 = *(char *)((int)puStack_8[1] + 0xd);
  puVar2 = puStack_8;
  puVar7 = (undefined4 *)puStack_8[1];
  while (cVar1 == '\0') {
    piVar5 = puVar7 + 4;
    puVar6 = puVar3;
    if (0xf < (uint)puVar3[5]) {
      puVar6 = (undefined4 *)*puVar3;
    }
    if (0xf < (uint)puVar7[9]) {
      piVar5 = (int *)*piVar5;
    }
    iVar4 = FUN_0055c2d0(piVar5,puVar7[8],puVar6,puVar3[4]);
    if (iVar4 < 0) {
      puVar6 = (undefined4 *)puVar7[2];
      puVar7 = puVar2;
    }
    else {
      puVar6 = (undefined4 *)*puVar7;
    }
    puVar2 = puVar7;
    puVar7 = puVar6;
    cVar1 = *(char *)((int)puVar6 + 0xd);
  }
  if (puVar2 != puStack_8) {
    piVar5 = puVar2 + 4;
    if (0xf < (uint)puVar2[9]) {
      piVar5 = (int *)*piVar5;
    }
    puVar7 = puVar3;
    if (0xf < (uint)puVar3[5]) {
      puVar7 = (undefined4 *)*puVar3;
    }
    iVar4 = FUN_0055c2d0(puVar7,puVar3[4],piVar5,puVar2[8]);
    if (-1 < iVar4) {
      return puVar2 + 10;
    }
  }
  puStack_8 = puVar3;
  iVar4 = FUN_00602c10(&DAT_018bdeda,&puStack_8,(int)&param_2 + 3);
  FUN_006040a0(&param_2,puVar2,iVar4 + 0x10,iVar4);
  return param_2 + 10;
}



/* FUNCTION 6541 ; VA 0x00614120 ; FUN_00614120 */

int * __thiscall FUN_00614120(byte *param_1,int param_2)

{
  int *piVar1;
  byte bVar2;
  uint uVar3;
  undefined4 *puVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  int *piVar8;
  uint uVar9;
  undefined4 *puVar10;
  int aiStack_3c [5];
  uint uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined2 uStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar6 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179d980;
  pvStack_10 = ExceptionList;
  bVar2 = *param_1;
  ExceptionList = &pvStack_10;
  uStack_14 = FUN_005702d0(param_2);
  FUN_00562fc0(&param_2,uStack_14,iVar6,
               -(uint)(param_1 + bVar2 + 1 != (byte *)0x0) & (uint)(param_1 + bVar2 + 1 + 1));
  if (param_2 != 0) {
    ExceptionList = pvStack_10;
    return (int *)(param_2 + 8);
  }
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  uStack_24 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar6);
  iStack_8._0_1_ = 1;
  FUN_00619c70();
  piVar5 = piStack_20;
  piStack_18 = piStack_20 + 2;
  FUN_0054ef60(aiStack_3c);
  piVar5[8] = 0;
  piVar5[9] = 0;
  piVar5[10] = 0;
  uStack_1c = CONCAT11(1,(undefined)uStack_1c);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_28) {
    uVar9 = uStack_28 + 1;
    iVar6 = aiStack_3c[0];
    if (0xfff < uVar9) {
      iVar6 = *(int *)(aiStack_3c[0] + -4);
      uVar9 = uStack_28 + 0x24;
      if (0x1f < (aiStack_3c[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar9);
  }
  uVar3 = *(uint *)(param_1 + 8);
  uVar9 = uVar3 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar9 = FUN_005c9310(uVar9);
    if (uVar9 <= *(uint *)(param_1 + 4)) {
      uVar9 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar9);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar9) {
    param_2 = 1;
    uVar7 = uVar3 >> 1;
    if (uVar3 + (uVar3 >> 1) <= uVar9) {
      uVar7 = 1;
    }
    iVar6 = FUN_005c9310(uVar7 + uVar3);
    if (iVar6 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar6);
      puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar4 = (undefined4 *)*puVar10;
      while (puVar4 != (undefined4 *)0x0) {
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar1 = (int)puVar10;
          puVar10 = puVar4;
        }
        else {
          *puVar10 = *puVar4;
          *puVar4 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar4;
        }
        puVar4 = (undefined4 *)*puVar10;
      }
    }
  }
  piVar5[1] = uStack_14;
  uStack_14 = uStack_14 % *(uint *)(param_1 + 4);
  piVar8 = *(int **)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  if (piVar8 == (int *)0x0) {
    piVar8 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar8 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar8 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar5;
    }
    *piVar1 = (int)piVar8;
    *piVar5 = *piVar8;
  }
  else {
    *piVar5 = *piVar8;
    piVar8 = (int *)*piVar1;
  }
  *piVar8 = (int)piVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_18;
}



/* FUNCTION 6542 ; VA 0x00614330 ; FUN_00614330 */

int * __thiscall FUN_00614330(byte *param_1,uint *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  int aiStack_40 [5];
  uint uStack_2c;
  uint uStack_28;
  int *piStack_24;
  undefined2 uStack_20;
  int *piStack_1c;
  uint uStack_18;
  byte *pbStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar4 = (int)param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179d9a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pbStack_14 = param_1;
  uStack_18 = FUN_009cc8a0(param_2);
  FUN_00607080(&param_2,uStack_18,iVar4,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (uint *)0x0) {
    ExceptionList = pvStack_10;
    return (int *)((int)param_2 + 8);
  }
  piStack_24 = (int *)0x0;
  uStack_20 = 0;
  uStack_28 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar4);
  iStack_8._0_1_ = 1;
  uStack_20 = 0;
  piVar3 = (int *)FUN_01674e20(0x38);
  piStack_1c = piVar3 + 2;
  *piVar3 = 0;
  piVar3[1] = 0;
  piStack_24 = piVar3;
  FUN_0170d1f0(piStack_1c,0,0x30);
  uStack_20 = CONCAT11(uStack_20._1_1_,1);
  FUN_0054ef60(aiStack_40);
  uStack_20 = CONCAT11(1,(undefined)uStack_20);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  piVar3[8] = 0;
  piVar3[9] = 0;
  piVar3[10] = 0;
  piVar3[0xb] = 0;
  piVar3[0xc] = 0;
  piVar3[0xd] = 0;
  if (0xf < uStack_2c) {
    uVar7 = uStack_2c + 1;
    iVar4 = aiStack_40[0];
    if (0xfff < uVar7) {
      iVar4 = *(int *)(aiStack_40[0] + -4);
      uVar7 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar7);
  }
  uVar1 = *(uint *)(param_1 + 8);
  uVar7 = uVar1 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_005c9310(uVar7);
    if (uVar7 <= *(uint *)(param_1 + 4)) {
      uVar7 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    param_2 = (uint *)0x1;
    uVar5 = uVar1 >> 1;
    if (uVar1 + (uVar1 >> 1) <= uVar7) {
      uVar5 = 1;
    }
    uVar7 = FUN_005c9310(uVar5 + *(int *)(param_1 + 8));
    param_2 = (uint *)(param_1 + 4);
    if (uVar7 != *param_2) {
      FUN_005d2b00(uVar7);
      puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_2 * 4);
      puVar2 = (undefined4 *)*puVar8;
      while (piVar3 = piStack_24, puVar2 != (undefined4 *)0x0) {
        piVar3 = (int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar2[1] % *param_2) * 4);
        if (*(int *)(*(int *)(pbStack_14 + 0x14) + ((uint)puVar2[1] % *param_2) * 4) == 0) {
          *piVar3 = (int)puVar8;
          puVar8 = puVar2;
        }
        else {
          *puVar8 = *puVar2;
          *puVar2 = *(undefined4 *)*piVar3;
          *(undefined4 **)*piVar3 = puVar2;
        }
        param_1 = pbStack_14;
        puVar2 = (undefined4 *)*puVar8;
      }
    }
  }
  piVar3[1] = uStack_18;
  uVar7 = *(uint *)(param_1 + 4);
  piVar3 = (int *)(*(int *)(param_1 + 0x14) + (uStack_18 % uVar7) * 4);
  if ((int *)*piVar3 == (int *)0x0) {
    piVar6 = (int *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (*piVar6 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar6 + 4) % uVar7) * 4) = piStack_24;
    }
    *piVar3 = (int)piVar6;
    *piStack_24 = *piVar6;
  }
  else {
    *piStack_24 = *(int *)*piVar3;
    piVar6 = (int *)*piVar3;
  }
  *piVar6 = (int)piStack_24;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_1c;
}



/* FUNCTION 6543 ; VA 0x00614570 ; FUN_00614570 */

int * __thiscall FUN_00614570(byte *param_1,int *param_2)

{
  int iVar1;
  uint uVar2;
  undefined4 *puVar3;
  uint uVar4;
  int *piVar5;
  undefined **ppuVar6;
  uint uVar7;
  int iVar8;
  undefined **ppuVar9;
  uint uVar10;
  int *piVar11;
  undefined4 *puVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar5 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179d9b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_009c91f0(param_2);
  FUN_00607110(&param_2,uVar4,piVar5,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (int *)0x0) {
    iVar8 = *piVar5;
    iVar1 = piVar5[1];
    uStack_8 = 0;
    piVar5 = (int *)FUN_01674e20(0x30);
    *piVar5 = 0;
    piVar5[1] = 0;
    piVar5[4] = 0;
    piVar5[5] = 0;
    piVar5[6] = 0;
    piVar5[7] = 0;
    piVar5[8] = 0;
    piVar5[9] = 0;
    piVar5[10] = 0;
    piVar5[0xb] = 0;
    piVar5[2] = iVar8;
    piVar5[3] = iVar1;
    piVar5[4] = 0;
    piVar5[5] = 0;
    *(undefined *)(piVar5 + 6) = 0;
    param_2 = (int *)0xb;
    ppuVar6 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
    ppuVar9 = ppuVar6 + -1;
    if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar9 = ppuVar6;
    }
    piVar5[7] = (int)*ppuVar9;
    piVar5[8] = 0;
    piVar5[9] = 0x3f800000;
    piVar5[10] = 0;
    piVar5[0xb] = 0;
    if (DAT_01d5a098 != '\0') {
      piVar5[5] = 1;
    }
    uVar2 = *(uint *)(param_1 + 8);
    uVar7 = uVar2 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar7 = FUN_005c9310(uVar7);
      if (uVar7 <= *(uint *)(param_1 + 4)) {
        uVar7 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar7);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar7) {
      uVar10 = uVar2 >> 1;
      if (uVar2 + uVar10 <= uVar7) {
        uVar10 = 1;
      }
      iVar8 = FUN_005c9310(uVar10 + uVar2);
      if (iVar8 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar8);
        puVar12 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar3 = (undefined4 *)*puVar12;
        while (puVar3 != (undefined4 *)0x0) {
          piVar11 = (int *)(*(int *)(param_1 + 0x14) +
                           ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4);
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar11 = (int)puVar12;
            puVar12 = puVar3;
          }
          else {
            *puVar12 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar11;
            *(undefined4 **)*piVar11 = puVar3;
          }
          puVar3 = (undefined4 *)*puVar12;
        }
      }
    }
    piVar5[1] = uVar4;
    uVar4 = uVar4 % *(uint *)(param_1 + 4);
    piVar11 = *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
    puVar12 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
    if (piVar11 == (int *)0x0) {
      piVar11 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar11 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar11 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar5;
      }
      *puVar12 = piVar11;
      *piVar5 = *piVar11;
    }
    else {
      *piVar5 = *piVar11;
      piVar11 = (int *)*puVar12;
    }
    *piVar11 = (int)piVar5;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar5 + 2;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 6544 ; VA 0x006147d0 ; FUN_006147d0 */

int * __thiscall FUN_006147d0(byte *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  undefined4 *puVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179d9d8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar6 = FUN_009c91f0(param_2);
  FUN_00607110(&param_2,uVar6,piVar1,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 != (int *)0x0) {
    ExceptionList = pvStack_10;
    return param_2 + 2;
  }
  iVar8 = *piVar1;
  iVar2 = piVar1[1];
  uStack_8 = 0;
  param_2 = (int *)FUN_01674e20(0x1c);
  piVar1 = param_2 + 2;
  *param_2 = 0;
  param_2[1] = 0;
  param_2[4] = 0;
  param_2[5] = 0;
  param_2[6] = 0;
  *piVar1 = iVar8;
  param_2[3] = iVar2;
  param_2[4] = 0;
  param_2[5] = 0;
  param_2[6] = 0;
  uVar3 = *(uint *)(param_1 + 8);
  uVar7 = uVar3 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_005c9310(uVar7);
    if (uVar7 <= *(uint *)(param_1 + 4)) {
      uVar7 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    uVar9 = uVar3 >> 1;
    if (uVar9 + uVar3 <= uVar7) {
      uVar9 = 1;
    }
    iVar8 = FUN_005c9310(uVar9 + uVar3);
    if (iVar8 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar8);
      puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar4 = (undefined4 *)*puVar10;
      while (puVar4 != (undefined4 *)0x0) {
        piVar5 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar5 = (int)puVar10;
          puVar10 = puVar4;
        }
        else {
          *puVar10 = *puVar4;
          *puVar4 = *(undefined4 *)*piVar5;
          *(undefined4 **)*piVar5 = puVar4;
        }
        puVar4 = (undefined4 *)*puVar10;
      }
    }
  }
  param_2[1] = uVar6;
  uVar6 = uVar6 % *(uint *)(param_1 + 4);
  piVar5 = *(int **)(*(int *)(param_1 + 0x14) + uVar6 * 4);
  puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
  if (piVar5 == (int *)0x0) {
    piVar5 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar5 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar5 + 4) % *(uint *)(param_1 + 4)) * 4) =
           param_2;
    }
    *puVar10 = piVar5;
    *param_2 = *piVar5;
    *piVar5 = (int)param_2;
  }
  else {
    *param_2 = *piVar5;
    *(int **)*puVar10 = param_2;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piVar1;
}



/* FUNCTION 6545 ; VA 0x006149c0 ; FUN_006149c0 */

int * __thiscall FUN_006149c0(byte *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  undefined4 *puVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179d9f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar6 = FUN_009c91f0(param_2);
  FUN_00607110(&param_2,uVar6,piVar1,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (int *)0x0) {
    iVar8 = *piVar1;
    iVar2 = piVar1[1];
    uStack_8 = 0;
    param_2 = (int *)FUN_01674e20(0x18);
    piVar1 = param_2 + 2;
    *param_2 = 0;
    param_2[1] = 0;
    param_2[4] = 0;
    param_2[5] = 0;
    *piVar1 = iVar8;
    param_2[3] = iVar2;
    param_2[4] = 0;
    param_2[5] = 0;
    uVar3 = *(uint *)(param_1 + 8);
    uVar7 = uVar3 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar7 = FUN_005c9310(uVar7);
      if (uVar7 <= *(uint *)(param_1 + 4)) {
        uVar7 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar7);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar7) {
      uVar9 = uVar3 >> 1;
      if (uVar3 + uVar9 <= uVar7) {
        uVar9 = 1;
      }
      iVar8 = FUN_005c9310(uVar9 + uVar3);
      if (iVar8 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar8);
        puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar4 = (undefined4 *)*puVar10;
        while (puVar4 != (undefined4 *)0x0) {
          piVar5 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar5 = (int)puVar10;
            puVar10 = puVar4;
          }
          else {
            *puVar10 = *puVar4;
            *puVar4 = *(undefined4 *)*piVar5;
            *(undefined4 **)*piVar5 = puVar4;
          }
          puVar4 = (undefined4 *)*puVar10;
        }
      }
    }
    param_2[1] = uVar6;
    uVar6 = uVar6 % *(uint *)(param_1 + 4);
    piVar5 = *(int **)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    if (piVar5 == (int *)0x0) {
      piVar5 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar5 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar5 + 4) % *(uint *)(param_1 + 4)) * 4)
             = param_2;
      }
      *puVar10 = piVar5;
      *param_2 = *piVar5;
      *piVar5 = (int)param_2;
    }
    else {
      *param_2 = *piVar5;
      *(int **)*puVar10 = param_2;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return piVar1;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 6546 ; VA 0x00614ba0 ; FUN_00614ba0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint * __thiscall FUN_00614ba0(byte *param_1,uint *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined **ppuVar4;
  uint uVar5;
  int iVar6;
  undefined **ppuVar7;
  uint uVar8;
  uint uVar9;
  undefined4 *puVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179da18;
  pvStack_10 = ExceptionList;
  uVar5 = *param_2;
  uVar9 = (uVar5 >> 3) + uVar5;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_2,uVar9,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (uint *)0x0) {
    uStack_8 = 0;
    FUN_00619d30();
    _DAT_0000000c = 0;
    _DAT_00000010 = 0;
    DAT_00000014 = 0;
    param_2 = (uint *)0xb;
    _DAT_00000008 = uVar5;
    ppuVar4 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
    ppuVar7 = ppuVar4 + -1;
    if (ppuVar4 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar7 = ppuVar4;
    }
    _DAT_00000018 = *ppuVar7;
    _DAT_0000001c = 0;
    _DAT_00000020 = 0x3f800000;
    uRam00000024 = 0;
    uRam00000028 = 0;
    uVar1 = *(uint *)(param_1 + 8);
    uVar5 = uVar1 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar5 = FUN_005c9310(uVar5);
      if (uVar5 <= *(uint *)(param_1 + 4)) {
        uVar5 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar5);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar5) {
      param_2 = (uint *)0x1;
      uVar8 = uVar1 >> 1;
      if ((uVar1 >> 1) + uVar1 <= uVar5) {
        uVar8 = 1;
      }
      iVar6 = FUN_005c9310(uVar8 + uVar1);
      if (iVar6 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar6);
        puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar2 = (undefined4 *)*puVar10;
        while (puVar2 != (undefined4 *)0x0) {
          piVar3 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar2[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar3 = (int)puVar10;
            puVar10 = puVar2;
          }
          else {
            *puVar10 = *puVar2;
            *puVar2 = *(undefined4 *)*piVar3;
            *(undefined4 **)*piVar3 = puVar2;
          }
          puVar2 = (undefined4 *)*puVar10;
        }
      }
    }
    uVar5 = uVar9 % *(uint *)(param_1 + 4);
    piVar3 = *(int **)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar5 * 4);
    _DAT_00000004 = uVar9;
    if (piVar3 == (int *)0x0) {
      piVar3 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar3 != 0) {
        *(undefined4 *)
         (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar3 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
      }
      *puVar10 = piVar3;
      _DAT_00000000 = *piVar3;
      *piVar3 = 0;
    }
    else {
      _DAT_00000000 = *piVar3;
      *(undefined4 *)*puVar10 = 0;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    FUN_006119f0();
    ExceptionList = pvStack_10;
    return (uint *)&DAT_00000008;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 6547 ; VA 0x00614da0 ; FUN_00614da0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint * __thiscall FUN_00614da0(byte *param_1,uint *param_2)

{
  uint uVar1;
  uint uVar2;
  undefined4 *puVar3;
  uint uVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  undefined4 *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179da38;
  pvStack_10 = ExceptionList;
  uVar4 = *param_2;
  uVar7 = (uVar4 >> 3) + uVar4;
  ExceptionList = &pvStack_10;
  FUN_00606ea0(&param_2,uVar7,param_2,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (param_2 == (uint *)0x0) {
    uStack_8 = 0;
    FUN_00619db0();
    _DAT_0000000c = 0;
    _DAT_00000010 = 0;
    uVar2 = *(uint *)(param_1 + 8);
    uVar1 = uVar2 + 1;
    _DAT_00000008 = uVar4;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar4 = FUN_005c9310(uVar1);
      if (uVar4 <= *(uint *)(param_1 + 4)) {
        uVar4 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar4);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar1) {
      param_2 = (uint *)0x1;
      uVar4 = uVar2 >> 1;
      if ((uVar2 >> 1) + uVar2 <= uVar1) {
        uVar4 = 1;
      }
      iVar5 = FUN_005c9310(uVar4 + uVar2);
      if (iVar5 != *(int *)(param_1 + 4)) {
        FUN_005d2b00(iVar5);
        puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar3 = (undefined4 *)*puVar8;
        while (puVar3 != (undefined4 *)0x0) {
          piVar6 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar6 = (int)puVar8;
            puVar8 = puVar3;
          }
          else {
            *puVar8 = *puVar3;
            *puVar3 = *(undefined4 *)*piVar6;
            *(undefined4 **)*piVar6 = puVar3;
          }
          puVar3 = (undefined4 *)*puVar8;
        }
      }
    }
    uVar4 = uVar7 % *(uint *)(param_1 + 4);
    piVar6 = *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4);
    puVar8 = (undefined4 *)(*(int *)(param_1 + 0x14) + uVar4 * 4);
    _DAT_00000004 = uVar7;
    if (piVar6 == (int *)0x0) {
      piVar6 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar6 != 0) {
        *(undefined4 *)
         (*(int *)(param_1 + 0x14) + (*(uint *)(*piVar6 + 4) % *(uint *)(param_1 + 4)) * 4) = 0;
      }
      *puVar8 = piVar6;
      _DAT_00000000 = *piVar6;
    }
    else {
      _DAT_00000000 = *piVar6;
      piVar6 = (int *)*puVar8;
    }
    *piVar6 = 0;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    ExceptionList = pvStack_10;
    return (uint *)&DAT_00000008;
  }
  ExceptionList = pvStack_10;
  return param_2 + 2;
}



/* FUNCTION 6548 ; VA 0x00614f50 ; FUN_00614f50 */

int * __thiscall FUN_00614f50(int param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  int *piStack_10;
  undefined4 *puStack_c;
  int *piStack_8;
  
  piVar2 = param_2;
  FUN_0061ddc0(&param_2,param_2);
  if (param_2 == *(int **)(param_1 + 4)) {
    piStack_8 = piVar2;
    iVar1 = **(int **)(param_1 + 4);
    puStack_c = *(undefined4 **)(iVar1 + 4);
    uVar3 = FUN_00602ca0(iVar1,puStack_c,&DAT_018bdeda,&piStack_8,(int)&param_2 + 3);
    if (*(int *)(param_1 + 8) == 0x7fffffe) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puStack_c = uVar3;
    FUN_00603d30(&piStack_10,**(int **)(param_1 + 4) + 8,**(int **)(param_1 + 4));
    param_2 = piStack_10;
  }
  return param_2 + 5;
}



/* FUNCTION 6549 ; VA 0x00614fe0 ; FUN_00614fe0 */

undefined4 * FUN_00614fe0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined auStack_c [8];
  
  puVar1 = (undefined4 *)FUN_00602640(auStack_c,param_2);
  *param_1 = *puVar1;
  param_1[1] = puVar1[1];
  return param_1;
}



/* FUNCTION 6550 ; VA 0x00615010 ; FUN_00615010 */

void __thiscall FUN_00615010(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  if (*(int **)(param_1 + 0x24) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0x24) + 8))(param_2,param_3,param_4,&stack0x00000010);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddc9c();
}



/* FUNCTION 6551 ; VA 0x00615040 ; FUN_00615040 */

void FUN_00615040(undefined4 *param_1)

{
  int iVar1;
  void **ppvVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  if (param_1 != (undefined4 *)0x0) {
    iVar4 = param_1[2];
    uStack_8 = 0;
    iVar3 = param_1[1];
    ExceptionList = &pvStack_10;
    ppvVar2 = &pvStack_10;
    if (param_1[1] != 0) {
      do {
        ExceptionList = ppvVar2;
        iVar1 = *(int *)(iVar4 + -8 + iVar3);
        iVar4 = *(int *)(iVar4 + iVar3 + -4);
        FUN_01674ea0(iVar3);
        iVar3 = iVar1;
        ppvVar2 = (void **)ExceptionList;
      } while (iVar1 != 0);
      param_1[1] = 0;
      *param_1 = 0;
      param_1[4] = param_1[5];
    }
    FUN_01674ea0(param_1,0x1c);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6552 ; VA 0x006150c0 ; FUN_006150c0 */

/* WARNING: Removing unreachable block (ram,0x0061511a) */
/* WARNING: Removing unreachable block (ram,0x0061512a) */
/* WARNING: Removing unreachable block (ram,0x00615130) */

void __fastcall FUN_006150c0(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179da60;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6553 ; VA 0x0061516c ; Catch@0061516c */

undefined * Catch_0061516c(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_0061517d;
}



/* FUNCTION 6554 ; VA 0x00615190 ; FUN_00615190 */

/* WARNING: Removing unreachable block (ram,0x0061527a) */
/* WARNING: Removing unreachable block (ram,0x0061528a) */
/* WARNING: Removing unreachable block (ram,0x00615290) */

void __thiscall FUN_00615190(int *param_1,int param_2)

{
  uint in_stack_00000018;
  int in_stack_00000020;
  uint in_stack_00000034;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179da98;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    FUN_01675290();
    uStack_8._0_1_ = 4;
    FUN_005e6300();
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,7);
    FUN_01675290();
    FUN_005507b0();
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  if (0xf < in_stack_00000018) {
    if ((0xfff < in_stack_00000018 + 1) && (0x1f < (param_2 - *(int *)(param_2 + -4)) - 4U)) {
      ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0();
  }
  if (0xf < in_stack_00000034) {
    if ((0xfff < in_stack_00000034 + 1) &&
       (0x1f < (in_stack_00000020 - *(int *)(in_stack_00000020 + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6555 ; VA 0x00615302 ; Catch@00615302 */

undefined * Catch_00615302(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x28));
  return &DAT_00615313;
}



/* FUNCTION 6556 ; VA 0x00615330 ; FUN_00615330 */

void FUN_00615330(void)

{
  FUN_006156f0();
  return;
}



/* FUNCTION 6557 ; VA 0x00615338 ; FUN_00615338 */

void FUN_00615338(void)

{
  FUN_006156f0();
  return;
}



/* FUNCTION 6558 ; VA 0x00615340 ; FUN_00615340 */

void FUN_00615340(void)

{
  FUN_006156f0();
  return;
}



/* FUNCTION 6559 ; VA 0x00615350 ; FUN_00615350 */

undefined4 __thiscall FUN_00615350(undefined4 param_1,byte param_2)

{
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x40);
  }
  return param_1;
}



/* FUNCTION 6560 ; VA 0x00615380 ; FUN_00615380 */

undefined4 __thiscall FUN_00615380(undefined4 param_1,byte param_2)

{
  FUN_00611620();
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x5c);
  }
  return param_1;
}



/* FUNCTION 6561 ; VA 0x006153b0 ; FUN_006153b0 */

int * __thiscall FUN_006153b0(int *param_1,byte param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00617290(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0xf8);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6562 ; VA 0x00615430 ; FUN_00615430 */

undefined4 * __thiscall FUN_00615430(undefined4 *param_1,byte param_2)

{
  *param_1 = RakNet::AbstractBitStream::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,8);
  }
  return param_1;
}



/* FUNCTION 6563 ; VA 0x00615460 ; FUN_00615460 */

undefined4 * __thiscall FUN_00615460(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::TaskScheduler::Arbiter::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 6564 ; VA 0x00615490 ; FUN_00615490 */

int __thiscall FUN_00615490(int param_1,byte param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 300);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0x134) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 300) = 0;
    *(undefined4 *)(param_1 + 0x130) = 0;
    *(undefined4 *)(param_1 + 0x134) = 0;
  }
  FUN_016dedfb(param_1 + 0xfc);
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x138);
  }
  return param_1;
}



/* FUNCTION 6565 ; VA 0x00615530 ; FUN_00615530 */

undefined4 * __thiscall FUN_00615530(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Network::DeserializedItem::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 6566 ; VA 0x00615560 ; FUN_00615560 */

undefined4 __thiscall FUN_00615560(undefined4 param_1,byte param_2)

{
  FUN_00613010();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 6567 ; VA 0x00615590 ; FUN_00615590 */

undefined4 * __thiscall FUN_00615590(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Network::DeserializedTouchItemS2::vftable;
  FUN_00612b90();
  *param_1 = RBX::Network::DeserializedItem::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1c);
  }
  return param_1;
}



/* FUNCTION 6568 ; VA 0x006155d0 ; FUN_006155d0 */

undefined4 * __thiscall FUN_006155d0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Voxel2::GridListener::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 6569 ; VA 0x00615600 ; FUN_00615600 */

undefined4 * __thiscall FUN_00615600(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::IMetric::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 6570 ; VA 0x00615630 ; FUN_00615630 */

undefined4 * __thiscall FUN_00615630(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Network::Item::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x30);
  }
  return param_1;
}



/* FUNCTION 6571 ; VA 0x00615660 ; FUN_00615660 */

undefined4 __thiscall FUN_00615660(undefined4 param_1,byte param_2)

{
  FUN_006c2bb0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xb0);
  }
  return param_1;
}



/* FUNCTION 6572 ; VA 0x00615690 ; FUN_00615690 */

int __thiscall FUN_00615690(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 300);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x130);
  }
  return param_1;
}



/* FUNCTION 6573 ; VA 0x006156f0 ; FUN_006156f0 */

undefined4 __thiscall FUN_006156f0(undefined4 param_1,byte param_2)

{
  FUN_006133f0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x3b00);
  }
  return param_1;
}



/* FUNCTION 6574 ; VA 0x00615720 ; FUN_00615720 */

int __thiscall FUN_00615720(int param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 300);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01522e10();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x148);
  }
  return param_1;
}



/* FUNCTION 6575 ; VA 0x00615780 ; FUN_00615780 */

undefined4 __thiscall FUN_00615780(undefined4 param_1,byte param_2)

{
  FUN_0056cd30();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 6576 ; VA 0x006157b0 ; FUN_006157b0 */

undefined4 * __thiscall FUN_006157b0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Network::Item::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x38);
  }
  return param_1;
}



/* FUNCTION 6577 ; VA 0x006157e0 ; FUN_006157e0 */

int __thiscall FUN_006157e0(int param_1,byte param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  
  piVar4 = *(int **)(param_1 + 0x34);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar6 = piVar4[2] + -1;
    piVar4[2] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)(*piVar4 + 4))();
    }
  }
  iVar6 = *(int *)(param_1 + 0x2c);
  if (iVar6 != 0) {
    if (*(int *)(param_1 + 0x20) != 0) {
      puVar2 = (undefined4 *)(iVar6 + *(int *)(param_1 + 0x1c) * 4);
      puVar5 = (undefined4 *)*puVar2;
      do {
        *puVar2 = *puVar5;
        FUN_01674ea0(puVar5,0x10);
        *(int *)(param_1 + 0x20) = *(int *)(param_1 + 0x20) + -1;
        puVar5 = (undefined4 *)*puVar2;
      } while (puVar5 != (undefined4 *)0x0);
      iVar6 = *(int *)(param_1 + 0x2c);
    }
    iVar3 = *(int *)(param_1 + 0x1c) * 4;
    uVar8 = iVar3 + 4;
    iVar7 = iVar6;
    if (0xfff < uVar8) {
      iVar7 = *(int *)(iVar6 + -4);
      uVar8 = iVar3 + 0x27;
      if (0x1f < (iVar6 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar8);
    *(undefined4 *)(param_1 + 0x2c) = 0;
    *(undefined4 *)(param_1 + 0x28) = 0;
  }
  piVar4 = *(int **)(param_1 + 0x14);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar6 = piVar4[1] + -1;
    piVar4[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar6 = piVar4[2] + -1;
      piVar4[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = *(int **)(param_1 + 0xc);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar6 = piVar4[1] + -1;
    piVar4[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x38);
  }
  return param_1;
}



/* FUNCTION 6578 ; VA 0x006158e0 ; FUN_006158e0 */

undefined4 * __thiscall FUN_006158e0(undefined4 *param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = RBX::physics_receiver_exception::vftable;
  uVar1 = param_1[8];
  if (0xf < uVar1) {
    iVar2 = param_1[3];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[7] = 0;
  param_1[8] = 0xf;
  *(undefined *)(param_1 + 3) = 0;
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x24);
  }
  return param_1;
}



/* FUNCTION 6579 ; VA 0x00615960 ; FUN_00615960 */

undefined4 __fastcall FUN_00615960(int param_1)

{
  return *(undefined4 *)(param_1 + 8);
}



/* FUNCTION 6580 ; VA 0x00615970 ; FUN_00615970 */

undefined4 __fastcall FUN_00615970(int param_1)

{
  return *(undefined4 *)(param_1 + 0x18);
}



/* FUNCTION 6581 ; VA 0x00615980 ; FUN_00615980 */

int __fastcall FUN_00615980(int param_1)

{
  return *(int *)(param_1 + 0x18) - *(int *)(param_1 + 0x20);
}



/* FUNCTION 6582 ; VA 0x00615990 ; FUN_00615990 */

undefined4 __fastcall FUN_00615990(int param_1)

{
  return *(undefined4 *)(param_1 + 0x20);
}



/* FUNCTION 6583 ; VA 0x006159a0 ; FUN_006159a0 */

void FUN_006159a0(void)

{
  return;
}



/* FUNCTION 6584 ; VA 0x006159b0 ; FUN_006159b0 */

void FUN_006159b0(void)

{
  return;
}



/* FUNCTION 6585 ; VA 0x006159c0 ; FUN_006159c0 */

void FUN_006159c0(void)

{
  return;
}



/* FUNCTION 6586 ; VA 0x006159d0 ; FUN_006159d0 */

void __thiscall FUN_006159d0(int param_1,int param_2)

{
  undefined4 ***pppuVar1;
  int in_stack_00000030;
  undefined4 **appuStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  if (in_stack_00000030 != 0) {
    if (*(int *)(param_2 + 0x14) == 0) {
      *(int *)(param_1 + 0x90c) = *(int *)(param_1 + 0x90c) + 1;
      return;
    }
    ExceptionList = &pvStack_10;
    *(int *)(param_1 + 0x910) = *(int *)(param_1 + 0x910) + 1;
    if (DAT_01d5b348 < *(int *)(param_2 + 0x18) + 7U >> 3) {
      FUN_01675640(appuStack_28,&DAT_018bed68,**(undefined **)(param_2 + 0x3c));
      pppuVar1 = appuStack_28;
      if (0xf < uStack_14) {
        pppuVar1 = (undefined4 ***)appuStack_28[0];
      }
      uStack_8 = 0;
      FUN_0087c450(&DAT_018c5f98,"NetworkPacketSplitCountOverThreshold",pppuVar1,0,0,0);
      FUN_005507b0();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6587 ; VA 0x00615a80 ; FUN_00615a80 */

void FUN_00615a80(void)

{
  return;
}



/* FUNCTION 6588 ; VA 0x00615a90 ; FUN_00615a90 */

undefined4 __thiscall FUN_00615a90(int param_1,int param_2)

{
  undefined *puVar1;
  int iVar2;
  undefined4 *puVar3;
  char cVar4;
  short sVar5;
  undefined4 uVar6;
  double *pdVar7;
  uint uVar8;
  int *piVar9;
  undefined4 uVar10;
  int iVar11;
  uint uVar12;
  bool bVar13;
  double in_XMM0_Qa;
  double dVar14;
  double dVar15;
  double dVar16;
  double dVar17;
  undefined8 uVar18;
  undefined4 uStack_610;
  int iStack_60c;
  undefined4 uStack_600;
  char *pcStack_5fc;
  undefined4 uStack_5f8;
  char acStack_5f4 [8];
  undefined4 uStack_5ec;
  undefined *puStack_5e8;
  undefined *puStack_5e4;
  char *pcStack_5e0;
  undefined8 *puStack_5dc;
  undefined auStack_5cc [1028];
  undefined auStack_1c8 [24];
  undefined auStack_1b0 [24];
  undefined auStack_198 [24];
  undefined auStack_180 [24];
  undefined auStack_168 [24];
  undefined auStack_150 [24];
  undefined auStack_138 [208];
  undefined auStack_68 [16];
  undefined4 uStack_58;
  undefined4 uStack_54;
  int iStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  char acStack_3c [4];
  undefined4 *puStack_38;
  uint uStack_34;
  undefined auStack_30 [4];
  int iStack_2c;
  undefined8 uStack_28;
  int *piStack_20;
  undefined8 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179db80;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffa28;
  puStack_5dc = (undefined8 *)DAT_01eadc98;
  pcStack_5e0 = (char *)0x615ac4;
  ExceptionList = &pvStack_10;
  iStack_4c = param_1;
  uVar6 = FUN_01675290();
  puStack_5dc = (undefined8 *)(param_1 + 0x18);
  iStack_8 = 0;
  pcStack_5e0 = (char *)0x615ae1;
  uStack_40 = uVar6;
  cVar4 = FUN_005f71d0();
  if (cVar4 == '\0') {
switchD_00615c9a_caseD_17:
    iStack_8 = 0x25;
    goto LAB_0061692c;
  }
  if (DAT_01d5a0d0 != '\0') {
    puStack_5dc = (undefined8 *)auStack_30;
    pcStack_5e0 = (char *)0x615aff;
    pdVar7 = (double *)FUN_01682800();
    in_XMM0_Qa = (double)DAT_01d59f68;
    if (in_XMM0_Qa < *pdVar7 - *(double *)(param_1 + 0x38a4)) {
      puStack_5dc = (undefined8 *)0x0;
      pcStack_5e0 = (char *)0x0;
      puStack_5e4 = (undefined *)0xffffffff;
      puStack_5e8 = (undefined *)0x615b35;
      FUN_0151f6f0();
      puStack_5dc = (undefined8 *)0x7c;
      pcStack_5e0 = (char *)0x401;
      puStack_5e4 = auStack_5cc;
      iStack_8._0_1_ = 1;
      puStack_5e8 = (undefined *)0x1;
      uStack_5ec = 0x615b51;
      FUN_005f7b20();
      puStack_5dc = *(undefined8 **)(param_1 + 0x38ac);
      pcStack_5e0 = "BaseInitialPing";
      puStack_5e4 = (undefined *)0x615b67;
      FUN_0151f9c0();
      puStack_5dc = (undefined8 *)auStack_5cc;
      pcStack_5e0 = "ServerIp";
      puStack_5e4 = (undefined *)0x615b7e;
      FUN_0151f850();
      puStack_5dc = (undefined8 *)DAT_01d7a884;
      pcStack_5e0 = "DataCenterId";
      puStack_5e4 = (undefined *)0x615b94;
      FUN_0151f9c0();
      puStack_5dc = *(undefined8 **)(param_1 + 0xdd4);
      pcStack_5e0 = "Ping";
      puStack_5e4 = (undefined *)0x615baa;
      FUN_0151f9c0();
      puStack_5dc = *(undefined8 **)(param_1 + 0x38b0);
      pcStack_5e0 = "PhysicsPercentLoss";
      puStack_5e4 = (undefined *)0x615bc0;
      FUN_0151f9c0();
      uVar10 = DAT_01eace7c;
      puStack_5dc = (undefined8 *)0xf;
      pcStack_5e0 = "RakNetBandwidth";
      uStack_58 = 0;
      uStack_54 = 0xf;
      auStack_68[0] = 0;
      puStack_5e4 = (undefined *)0x615be7;
      FUN_005542c0();
      puStack_5dc = (undefined8 *)0x0;
      pcStack_5e0 = (char *)uVar10;
      puStack_5e4 = auStack_68;
      iStack_8._0_1_ = 2;
      puStack_5e8 = (undefined *)0x615bfd;
      FUN_01520d20();
      iStack_8._0_1_ = 1;
      puStack_5dc = (undefined8 *)0x615c09;
      FUN_005507b0();
      puStack_5dc = &uStack_1c;
      pcStack_5e0 = (char *)0x615c12;
      FUN_01682800();
      *(undefined4 *)(param_1 + 0x38a4) = (undefined4)uStack_1c;
      *(int **)(param_1 + 0x38a8) = uStack_1c._4_4_;
      if (-1 < *(int *)(param_1 + 0x38b0)) {
        *(undefined4 *)(param_1 + 0x38b0) = 0xffffffff;
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      puStack_5dc = (undefined8 *)0x615c49;
      FUN_0151f7f0();
    }
  }
  puStack_5dc = (undefined8 *)0x615c57;
  FUN_0062ba20();
  iStack_8._0_1_ = 3;
  if (DAT_01ee4215 != 0) {
    puStack_5dc = (undefined8 *)(uint)**(byte **)(param_2 + 0x38);
    puStack_5e4 = (undefined *)(uint)DAT_01ee4215;
    pcStack_5e0 = "Replicator::OnReceive() Received Msg ID Type : %d";
    puStack_5e8 = (undefined *)0x615c7a;
    FUN_016774b0();
  }
  puVar1 = *(undefined **)(param_2 + 0x38);
  puStack_5dc = (undefined8 *)uVar6;
  switch(*puVar1) {
  case 0x15:
    if (DAT_01d5a2c0 == '\0') {
      if (DAT_01ee420a != 0) {
        puStack_5dc = (undefined8 *)0x7c;
        pcStack_5e0 = (char *)0x1;
        puStack_5e8 = auStack_180;
        puStack_5e4 = (undefined *)param_2;
        uStack_5ec = 0x616323;
        puStack_5dc = (undefined8 *)FUN_006b1620();
        iStack_8 = CONCAT31(iStack_8._1_3_,0x11);
        if (0xf < *(uint *)((int)puStack_5dc + 0x14)) {
          puStack_5dc = *(undefined8 **)puStack_5dc;
        }
        puStack_5e4 = (undefined *)(uint)DAT_01ee420a;
        pcStack_5e0 = "Disconnect from %s: ID_DISCONNECTION_NOTIFICATION";
        puStack_5e8 = (undefined *)0x616345;
        FUN_01677650();
        goto LAB_0061634b;
      }
    }
    else {
      puStack_5dc = (undefined8 *)0x6162ac;
      piVar9 = (int *)FUN_0054db20();
      puStack_5dc = (undefined8 *)0x6162b6;
      iVar11 = (**(code **)(*piVar9 + 0x14c))();
      if ((iVar11 != 0x119) && (DAT_01ee420a != 0)) {
        puStack_5dc = (undefined8 *)0x7c;
        pcStack_5e0 = (char *)0x1;
        puStack_5e8 = auStack_168;
        puStack_5e4 = (undefined *)param_2;
        uStack_5ec = 0x6162df;
        puStack_5dc = (undefined8 *)FUN_006b1620();
        iStack_8 = CONCAT31(iStack_8._1_3_,0x10);
        if (0xf < *(uint *)((int)puStack_5dc + 0x14)) {
          puStack_5dc = *(undefined8 **)puStack_5dc;
        }
        puStack_5e4 = (undefined *)(uint)DAT_01ee420a;
        pcStack_5e0 = "Disconnect from %s: ID_DISCONNECTION_NOTIFICATION";
        puStack_5e8 = (undefined *)0x616301;
        FUN_01677650();
LAB_0061634b:
        iStack_8._0_1_ = 3;
        puStack_5dc = (undefined8 *)0x616357;
        FUN_005507b0();
      }
    }
    puStack_5dc = (undefined8 *)0x7c;
    pcStack_5e0 = (char *)0x1;
    puStack_5e8 = auStack_198;
    puStack_5e4 = (undefined *)param_2;
    uStack_5ec = 0x616368;
    puStack_5dc = (undefined8 *)FUN_006b1620();
    iStack_8._0_1_ = 0x12;
    if (0xf < *(uint *)((int)puStack_5dc + 0x14)) {
      puStack_5dc = *(undefined8 **)puStack_5dc;
    }
    pcStack_5e0 = "Disconnect from %s";
    puStack_5e4 = &DAT_00000004;
    puStack_5e8 = (undefined *)0x616384;
    FUN_0086f2f0();
    iStack_8 = CONCAT31(iStack_8._1_3_,3);
    puStack_5dc = (undefined8 *)0x616396;
    FUN_005507b0();
    if (param_1 + -0x5c == 0) {
LAB_006164c3:
      if (DAT_01d5a2c0 == '\0') {
        if (DAT_01ee420a != 0) {
          puStack_5dc = (undefined8 *)0x616548;
          piVar9 = (int *)FUN_0054db20();
          puStack_5dc = (undefined8 *)0x616552;
          puStack_5dc = (undefined8 *)(**(code **)(*piVar9 + 0x14c))();
          pcStack_5e0 = auStack_1c8;
          puStack_5e4 = (undefined *)0x61655f;
          puStack_5dc = (undefined8 *)FUN_0061be30();
          puStack_5e4 = (undefined *)(uint)DAT_01ee420a;
          pcStack_5e0 = "Client has been disconnected with reason: %s";
          iStack_8 = CONCAT31(iStack_8._1_3_,0x14);
          puStack_5e8 = (undefined *)0x616579;
          FUN_01677760();
          goto LAB_0061657f;
        }
      }
      else {
        puStack_5dc = (undefined8 *)0x6164d4;
        piVar9 = (int *)FUN_0054db20();
        puStack_5dc = (undefined8 *)0x6164de;
        iVar11 = (**(code **)(*piVar9 + 0x14c))();
        if ((iVar11 != 0x119) && (DAT_01ee420a != 0)) {
          puStack_5dc = (undefined8 *)0x6164fe;
          piVar9 = (int *)FUN_0054db20();
          puStack_5dc = (undefined8 *)0x616508;
          puStack_5dc = (undefined8 *)(**(code **)(*piVar9 + 0x14c))();
          pcStack_5e0 = auStack_1b0;
          puStack_5e4 = (undefined *)0x616515;
          puStack_5dc = (undefined8 *)FUN_0061be30();
          puStack_5e4 = (undefined *)(uint)DAT_01ee420a;
          pcStack_5e0 = "Client has been disconnected with reason: %s";
          iStack_8 = CONCAT31(iStack_8._1_3_,0x13);
          puStack_5e8 = (undefined *)0x61652f;
          FUN_01677760();
LAB_0061657f:
          iStack_8 = CONCAT31(iStack_8._1_3_,3);
          puStack_5dc = (undefined8 *)0x61658b;
          FUN_005507b0();
        }
      }
      puStack_5dc = (undefined8 *)0x616593;
      piVar9 = (int *)FUN_0054db20();
      puStack_5dc = (undefined8 *)0x61659d;
      uVar10 = (**(code **)(*piVar9 + 0x14c))();
      puStack_5dc = (undefined8 *)0x6165a8;
      uStack_1c._4_4_ = (int *)uVar10;
      piVar9 = (int *)FUN_0054db20();
      puStack_5dc = (undefined8 *)uStack_1c._4_4_;
      pcStack_5e0 = (char *)0x6165b5;
      uStack_5f8 = (**(code **)(*piVar9 + 0x14c))();
      pcStack_5fc = acStack_5f4;
      uStack_1c = (double)CONCAT44(acStack_5f4,(undefined4)uStack_1c);
      uStack_600 = 0x6165c4;
      FUN_0061be30();
      uStack_5f8 = 0;
      iStack_8._0_1_ = 0x15;
      FUN_006b1620(&uStack_610,param_2,1,0x7c);
      iStack_8 = CONCAT31(iStack_8._1_3_,3);
      FUN_0062db20();
      puStack_5dc = (undefined8 *)0xffffffff;
      pcStack_5e0 = (char *)0x6165f6;
      FUN_0062baf0();
    }
    else {
      iStack_2c = *(int *)(param_1 + -0x28);
      iVar11 = param_1 + -0x5c;
      if ((iStack_2c != 0) && (iVar11 = iStack_2c, *(int *)(iStack_2c + 0x34) != 0)) {
        puStack_5dc = (undefined8 *)0x6163b7;
        iVar11 = FUN_005c8ac0();
      }
      iStack_2c = iVar11;
      if (iStack_2c == 0) goto LAB_006164c3;
      uStack_1c = (double)CONCAT44(*(undefined4 *)(iStack_2c + 0xc),(undefined4)uStack_1c);
      puStack_5dc = (undefined8 *)0x6163d4;
      iVar11 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar11 + 0x1da) <
          (uint)*(ushort *)((int)uStack_1c._4_4_ + 0x1d8) - (uint)*(ushort *)(iVar11 + 0x1d8))
      goto LAB_006164c3;
      puStack_5dc = (undefined8 *)&LAB_00605b60;
      pcStack_5e0 = &DAT_01ead2e4;
      puStack_5e4 = (undefined *)0x616405;
      FUN_005789c0();
      puStack_5dc = (undefined8 *)0x61640d;
      puStack_5dc = (undefined8 *)FUN_00606020();
      pcStack_5e0 = (char *)0x616416;
      piStack_20 = (int *)FUN_008aa140();
      if (*piStack_20 == 0) {
        puStack_5dc = (undefined8 *)0x616427;
        puStack_5dc = (undefined8 *)FUN_00ac1050();
        pcStack_5e0 = acStack_3c;
        puStack_5e4 = (undefined *)0x616434;
        piVar9 = (int *)FUN_008a9ba0();
        iVar11 = *piVar9;
        iVar2 = piVar9[1];
        *piVar9 = 0;
        piVar9[1] = 0;
        *piStack_20 = iVar11;
        piVar9 = (int *)piStack_20[1];
        piStack_20[1] = iVar2;
        if (piVar9 != (int *)0x0) {
          LOCK();
          iVar11 = piVar9[1] + -1;
          piVar9[1] = iVar11;
          UNLOCK();
          if (iVar11 == 0) {
            puStack_5dc = (undefined8 *)0x616468;
            uStack_1c._4_4_ = piVar9;
            (**(code **)*piVar9)();
            LOCK();
            iVar11 = uStack_1c._4_4_[2] + -1;
            uStack_1c._4_4_[2] = iVar11;
            UNLOCK();
            if (iVar11 == 0) {
              puStack_5dc = (undefined8 *)0x61647c;
              (**(code **)(*uStack_1c._4_4_ + 4))();
            }
          }
        }
        uStack_1c = (double)CONCAT44(puStack_38,(undefined4)uStack_1c);
        if (puStack_38 != (undefined4 *)0x0) {
          LOCK();
          iVar11 = puStack_38[1] + -1;
          puStack_38[1] = iVar11;
          UNLOCK();
          if (iVar11 == 0) {
            puStack_5dc = (undefined8 *)0x616499;
            (**(code **)*puStack_38)();
            LOCK();
            piVar9 = uStack_1c._4_4_ + 2;
            iVar11 = *piVar9;
            *piVar9 = *piVar9 + -1;
            UNLOCK();
            if (iVar11 == 1) {
              puStack_5dc = (undefined8 *)0x6164ac;
              (**(code **)(*uStack_1c._4_4_ + 4))();
            }
          }
        }
      }
      if ((*piStack_20 == 0) || (uVar6 = uStack_40, *(char *)(*piStack_20 + 0x58) == '\0'))
      goto LAB_006164c3;
    }
    iStack_8 = 0x16;
    goto LAB_0061692c;
  case 0x16:
    if (DAT_01ee420a != 0) {
      puStack_5dc = (undefined8 *)0x7c;
      pcStack_5e0 = (char *)0x1;
      puStack_5e8 = auStack_138;
      puStack_5e4 = (undefined *)param_2;
      uStack_5ec = 0x6161c3;
      puStack_5dc = (undefined8 *)FUN_006b1620();
      iStack_8._0_1_ = 0xc;
      if (0xf < *(uint *)((int)puStack_5dc + 0x14)) {
        puStack_5dc = *(undefined8 **)puStack_5dc;
      }
      puStack_5e4 = (undefined *)(uint)DAT_01ee420a;
      pcStack_5e0 = "Lost connection to %s: ID_CONNECTION_LOST";
      puStack_5e8 = (undefined *)0x6161e5;
      FUN_01677650();
      iStack_8._0_1_ = 3;
      puStack_5dc = (undefined8 *)0x6161f7;
      FUN_005507b0();
    }
    puStack_5dc = (undefined8 *)0x7c;
    pcStack_5e0 = (char *)0x1;
    puStack_5e8 = auStack_150;
    puStack_5e4 = (undefined *)param_2;
    uStack_5ec = 0x616208;
    puStack_5dc = (undefined8 *)FUN_006b1620();
    iStack_8._0_1_ = 0xd;
    if (0xf < *(uint *)((int)puStack_5dc + 0x14)) {
      puStack_5dc = *(undefined8 **)puStack_5dc;
    }
    pcStack_5e0 = "Lost connection to %s\n";
    puStack_5e4 = (undefined *)0x4;
    puStack_5e8 = (undefined *)0x616224;
    FUN_0086f2f0();
    iStack_8._0_1_ = 3;
    puStack_5dc = (undefined8 *)0x616236;
    FUN_005507b0();
    puStack_5dc = (undefined8 *)0x115;
    uStack_1c = (double)CONCAT44(acStack_5f4,(undefined4)uStack_1c);
    uStack_5f8 = 0x34;
    puStack_5e4 = (undefined *)0x0;
    pcStack_5e0 = (char *)0xf;
    pcStack_5fc = "Lost connection to the game server, please reconnect";
    acStack_5f4[0] = '\0';
    uStack_600 = 0x616260;
    FUN_005542c0();
    uStack_5f8 = 1;
    iStack_8._0_1_ = 0xe;
    FUN_006b1620(&uStack_610,param_2,1,0x7c);
    iStack_8 = CONCAT31(iStack_8._1_3_,3);
    FUN_0062db20();
    puStack_5dc = (undefined8 *)0xffffffff;
    pcStack_5e0 = (char *)0x61628f;
    FUN_0062baf0();
    iStack_8 = 0xf;
    goto LAB_0061692c;
  default:
    goto switchD_00615c9a_caseD_17;
  case 0x1b:
    puStack_5dc = (undefined8 *)0x0;
    pcStack_5e0 = *(char **)(param_2 + 0x30);
    puStack_5e8 = (undefined *)0x615cb2;
    puStack_5e4 = puVar1;
    FUN_006ab380();
    puStack_5dc = (undefined8 *)0x1;
    iStack_8 = CONCAT31(iStack_8._1_3_,4);
    pcStack_5e0 = (char *)0x615cc3;
    FUN_006ab660();
    puStack_5dc = (undefined8 *)0x615cce;
    uVar18 = FUN_006ace60();
    iStack_2c = (int)((ulonglong)uVar18 >> 0x20);
    piStack_20 = (int *)uVar18;
    puStack_5dc = (undefined8 *)0x615ce1;
    cVar4 = (**(code **)(*(int *)(param_1 + -0x5c) + 0x11c))();
    if ((cVar4 == '\0') && (*(int *)(param_1 + 0x37fc) == 0)) {
      if (DAT_01ee420a != 0) {
        puStack_5dc = (undefined8 *)0x0;
        puStack_5e4 = (undefined *)(uint)DAT_01ee420a;
        pcStack_5e0 = 
        "call to onreceive before physicsReceiver is initialized are ready, dropping packet";
        puStack_5e8 = (undefined *)0x615d07;
        FUN_016774b0();
      }
      puStack_5dc = (undefined8 *)0x615d15;
      FUN_00613200();
      iStack_8 = 5;
      pcStack_5e0 = (char *)0x615d22;
      puStack_5dc = (undefined8 *)uVar6;
      FUN_01675290();
      ExceptionList = pvStack_10;
      return 0;
    }
    puStack_5dc = (undefined8 *)0x615d45;
    uVar18 = FUN_006ace60();
    puStack_38 = (undefined4 *)((ulonglong)uVar18 >> 0x20);
    uStack_34 = (uint)uVar18;
    puStack_5dc = (undefined8 *)0x615d56;
    cVar4 = FUN_006abe40();
    if (cVar4 == -0x7b) {
      if (*(char *)(param_1 + 0x38c4) != '\0') {
        piVar9 = *(int **)(param_1 + 0x38b4);
        iVar11 = *(int *)(param_1 + 0x38b8);
        if (piVar9 == (int *)0x0 && iVar11 == 0) {
          *(uint *)(param_1 + 0x38cc) = uStack_34;
          *(undefined4 **)(param_1 + 0x38d0) = puStack_38;
          *(int **)(param_1 + 0x38b4) = piStack_20;
          *(int *)(param_1 + 0x38b8) = iStack_2c;
          *(int **)(param_1 + 0x38bc) = piStack_20;
          *(int *)(param_1 + 0x38c0) = iStack_2c;
          uStack_28._4_4_ = (code *)piStack_20;
          piVar9 = piStack_20;
          iVar2 = iStack_2c;
          iVar11 = iStack_2c;
        }
        else {
          uStack_28._4_4_ = *(code **)(param_1 + 0x38bc);
          iVar2 = *(int *)(param_1 + 0x38c0);
        }
        uStack_48 = (double)CONCAT44(iVar11,(undefined4)uStack_48);
        bVar13 = piStack_20 < uStack_28._4_4_;
        uVar8 = (int)piStack_20 - (int)uStack_28._4_4_;
        uStack_28 = (double)CONCAT44(uVar8,(undefined4)uStack_28);
        uStack_1c._4_4_ = (int *)((iStack_2c - iVar2) - (uint)bVar13);
        if ((uStack_1c._4_4_ != (int *)0x0) || (1000 < uVar8)) {
          puStack_5dc = (undefined8 *)0x615e17;
          FUN_016f3fe0();
          in_XMM0_Qa = in_XMM0_Qa * DAT_018ce318;
          puStack_5dc = (undefined8 *)0x615e35;
          uStack_1c = in_XMM0_Qa;
          FUN_016f3fe0();
          puStack_5dc = &uStack_28;
          dVar14 = (double)(float)(uStack_1c / in_XMM0_Qa);
          pcStack_5e0 = (char *)0x615e58;
          uStack_28 = dVar14;
          uStack_1c._4_4_ = (int *)(float)(uStack_1c / in_XMM0_Qa);
          sVar5 = FUN_017265ed();
          dVar15 = DAT_018c0d60;
          if (sVar5 < 1) {
            dVar14 = *(double *)(param_1 + 0x38d4);
            dVar17 = (double)(float)uStack_1c._4_4_;
            dVar16 = dVar17;
            if (*(char *)(param_1 + 0x38f4) == '\0') {
              dVar16 = (DAT_018c0d60 - dVar14) * *(double *)(param_1 + 0x38e4) + dVar17 * dVar14;
            }
            *(double *)(param_1 + 0x38e4) = dVar16;
            *(int **)(param_1 + 0x38dc) = uStack_1c._4_4_;
            *(undefined *)(param_1 + 0x38f4) = 0;
            dVar14 = (dVar15 - dVar14) * *(double *)(param_1 + 0x38ec) +
                     dVar14 * (dVar17 - dVar16) * (dVar17 - dVar16);
            *(double *)(param_1 + 0x38ec) = dVar14;
          }
          puStack_5dc = (undefined8 *)0x615eef;
          FUN_016f3fe0();
          dVar14 = dVar14 * DAT_018ce318;
          puStack_5dc = (undefined8 *)0x615f0d;
          uStack_1c = dVar14;
          FUN_016f3fe0();
          puStack_5dc = &uStack_48;
          in_XMM0_Qa = (double)(float)(uStack_1c / dVar14);
          pcStack_5e0 = (char *)0x615f30;
          uStack_48 = in_XMM0_Qa;
          uStack_1c._4_4_ = (int *)(float)(uStack_1c / dVar14);
          sVar5 = FUN_017265ed();
          if (sVar5 < 1) {
            dVar15 = *(double *)(param_1 + 0x38fc);
            dVar14 = (double)(float)uStack_1c._4_4_;
            dVar16 = dVar14;
            if (*(char *)(param_1 + 0x391c) == '\0') {
              dVar16 = (DAT_018c0d60 - dVar15) * *(double *)(param_1 + 0x390c) + dVar14 * dVar15;
            }
            dVar17 = DAT_018c0d60 - dVar15;
            *(double *)(param_1 + 0x390c) = dVar16;
            *(int **)(param_1 + 0x3904) = uStack_1c._4_4_;
            *(undefined *)(param_1 + 0x391c) = 0;
            in_XMM0_Qa = dVar17 * *(double *)(param_1 + 0x3914) +
                         dVar15 * (dVar14 - dVar16) * (dVar14 - dVar16);
            *(double *)(param_1 + 0x3914) = in_XMM0_Qa;
          }
          piVar9 = *(int **)(param_1 + 0x38b4);
          *(int **)(param_1 + 0x38bc) = piStack_20;
          *(int *)(param_1 + 0x38c0) = iStack_2c;
          uStack_48 = (double)CONCAT44(*(undefined4 *)(param_1 + 0x38b8),(undefined4)uStack_48);
        }
        iVar11 = *(int *)(param_1 + 0x38c8) + 1;
        *(int *)(param_1 + 0x38c8) = iVar11;
        uVar8 = (iStack_2c - uStack_48._4_4_) - (uint)(piStack_20 < piVar9);
        uStack_1c = (double)CONCAT44((int)piStack_20 - (int)piVar9,(undefined4)uStack_1c);
        uStack_28 = (double)CONCAT44(iVar11,(undefined4)uStack_28);
        uVar12 = DAT_01d59dc0 * 1000 >> 0x1f;
        if ((uVar12 <= uVar8) &&
           ((uVar12 < uVar8 || ((uint)(DAT_01d59dc0 * 1000) < (uint)((int)piStack_20 - (int)piVar9))
            ))) {
          puVar3 = *(undefined4 **)(param_1 + 0x38d0);
          uStack_1c = (double)CONCAT44(puVar3,(undefined4)uStack_1c);
          if ((puStack_38 < puVar3) ||
             ((puStack_38 <= puVar3 && (uStack_34 <= *(uint *)(param_1 + 0x38cc))))) {
            dVar15 = 0.0;
            *(undefined4 *)(param_1 + 0x39a4) = 0;
            *(undefined4 *)(param_1 + 0x39a8) = 0;
            *(undefined4 *)(param_1 + 0x39ac) = 0;
            *(undefined4 *)(param_1 + 0x39b0) = 0;
          }
          else {
            puStack_5dc = (undefined8 *)0x61605b;
            FUN_016f3fe0();
            uStack_1c = (double)CONCAT44((float)in_XMM0_Qa,(undefined4)uStack_1c);
            dVar15 = (double)(float)in_XMM0_Qa * DAT_018ce318;
            puStack_5dc = (undefined8 *)0x61607e;
            uStack_28 = dVar15;
            FUN_016f3fe0();
            dVar15 = uStack_28 / (double)(float)dVar15;
            *(double *)(iStack_4c + 0x39a4) = dVar15;
            *(double *)(iStack_4c + 0x39ac) = (double)((float)uStack_1c._4_4_ / (float)DAT_01d59dc0)
            ;
            param_1 = iStack_4c;
          }
          *(undefined4 **)(param_1 + 0x38d0) = puStack_38;
          *(undefined4 *)(param_1 + 0x38c8) = 1;
          *(int *)(param_1 + 0x38b0) = (int)dVar15;
          *(uint *)(param_1 + 0x38cc) = uStack_34;
          puStack_5dc = (undefined8 *)0x6160f6;
          FUN_006291a0();
          *(int **)(param_1 + 0x38b4) = piStack_20;
          *(int *)(param_1 + 0x38b8) = iStack_2c;
          puStack_5dc = (undefined8 *)0x616110;
          FUN_0062b770();
        }
      }
      puStack_5dc = (undefined8 *)param_2;
      pcStack_5e0 = (char *)0x616119;
      FUN_00625a90();
      puStack_5dc = (undefined8 *)0x616124;
      FUN_00613200();
      iStack_8 = 7;
      pcStack_5e0 = (char *)0x616131;
      puStack_5dc = (undefined8 *)uVar6;
      FUN_01675290();
      ExceptionList = pvStack_10;
      return 2;
    }
    puStack_5dc = (undefined8 *)0x615d65;
    FUN_00613200();
    iStack_8 = 6;
LAB_0061692c:
    pcStack_5e0 = (char *)0x616932;
    puStack_5dc = (undefined8 *)uVar6;
    FUN_01675290();
    uVar6 = 1;
    break;
  case 0x81:
    puStack_5dc = (undefined8 *)param_2;
    pcStack_5e0 = (char *)0x61673c;
    FUN_00625a90();
    iStack_8 = 0x1c;
    pcStack_5e0 = (char *)0x616749;
    puStack_5dc = (undefined8 *)uVar6;
    FUN_01675290();
    uVar6 = 2;
    break;
  case 0x82:
    iStack_8 = 0xb;
    pcStack_5e0 = (char *)0x61619f;
    FUN_01675290();
    uVar6 = 2;
    break;
  case 0x83:
    if (DAT_01eace54 != 0) {
      puStack_5dc = (undefined8 *)0x616613;
      piVar9 = (int *)FUN_0054db20();
      uStack_1c = (double)CONCAT44(piVar9,(undefined4)uStack_1c);
      uStack_28 = (double)CONCAT44(*(undefined4 *)(*piVar9 + 0x160),(undefined4)uStack_28);
      iStack_60c = param_1 + 0x18;
      uStack_610 = 0x61662f;
      FUN_0060ed10();
      iStack_60c = 0x616635;
      cVar4 = (*uStack_28._4_4_)();
      if (cVar4 != '\0') {
        if (*(int *)(param_1 + 0x37c0) == 0) {
          puStack_5dc = (undefined8 *)0x616647;
          uVar10 = FUN_006a6900();
          *(undefined4 *)(param_1 + 0x37c0) = uVar10;
        }
        *(int *)(param_1 + 0x37d8) = *(int *)(param_1 + 0x37d8) + 1;
        *(int *)(param_1 + 0x37d4) = *(int *)(param_1 + 0x37d4) + *(int *)(param_2 + 0x30);
      }
    }
    puStack_5dc = (undefined8 *)param_2;
    pcStack_5e0 = (char *)0x616665;
    FUN_00625a90();
    iStack_8 = 0x17;
    pcStack_5e0 = (char *)0x616672;
    puStack_5dc = (undefined8 *)uVar6;
    FUN_01675290();
    uVar6 = 2;
    break;
  case 0x84:
    puStack_5dc = (undefined8 *)0x0;
    pcStack_5e0 = *(char **)(param_2 + 0x30);
    puStack_5e8 = (undefined *)0x6166ad;
    puStack_5e4 = puVar1;
    FUN_006ab380();
    puStack_5dc = (undefined8 *)0x1;
    iStack_8._0_1_ = 0x19;
    pcStack_5e0 = (char *)0x6166be;
    FUN_006ab660();
    puStack_5dc = (undefined8 *)0x6166c9;
    uStack_1c._4_4_ = (int *)FUN_006ace40();
    puStack_5dc = (undefined8 *)0x38;
    pcStack_5e0 = (char *)0x6166d3;
    iVar11 = FUN_01674e20();
    uStack_28 = (double)CONCAT44(iVar11,(undefined4)uStack_28);
    iStack_8._0_1_ = 0x1a;
    if (iVar11 == 0) {
      puStack_5dc = (undefined8 *)0x0;
    }
    else {
      puStack_5dc = (undefined8 *)uStack_1c._4_4_;
      pcStack_5e0 = (char *)(param_1 + -0x5c);
      puStack_5e4 = (undefined *)0x6166ef;
      puStack_5dc = (undefined8 *)FUN_006faeb0();
    }
    iStack_8 = CONCAT31(iStack_8._1_3_,0x19);
    pcStack_5e0 = (char *)0x616703;
    FUN_006b1f50();
    puStack_5dc = (undefined8 *)0x61670e;
    FUN_00613200();
    iStack_8 = 0x1b;
    pcStack_5e0 = (char *)0x61671b;
    puStack_5dc = (undefined8 *)uVar6;
    FUN_01675290();
    ExceptionList = pvStack_10;
    return 0;
  case 0x86:
    puStack_5dc = (undefined8 *)param_2;
    pcStack_5e0 = (char *)0x616144;
    FUN_00625a90();
    iStack_8 = 8;
    pcStack_5e0 = (char *)0x616151;
    puStack_5dc = (undefined8 *)uVar6;
    FUN_01675290();
    uVar6 = 2;
    break;
  case 0x87:
  case 0x88:
  case 0x8b:
  case 0x8c:
    puStack_38 = *(undefined4 **)(param_1 + 0x1d64);
    uStack_1c._0_5_ = CONCAT14(*puVar1,(undefined4)uStack_1c);
    puStack_5dc = (undefined8 *)0x616767;
    uVar10 = FUN_0054db20();
    puStack_5dc = (undefined8 *)0x616776;
    uStack_28._4_4_ = (code *)uVar10;
    puStack_5e8 = (undefined *)(**(code **)(*(int *)(param_1 + -0x5c) + 0xb8))();
    puStack_5dc = (undefined8 *)uStack_1c._4_4_;
    pcStack_5e0 = (char *)param_2;
    puStack_5e4 = uStack_28._4_4_;
    uStack_5ec = 0x616786;
    iVar11 = FUN_0096f770();
    if ((iVar11 == 0) || (iVar11 != 1)) {
      iStack_8 = 0x1e;
      pcStack_5e0 = (char *)0x6167b4;
      puStack_5dc = (undefined8 *)uVar6;
      FUN_01675290();
      ExceptionList = pvStack_10;
      return 0;
    }
    iStack_8 = 0x1d;
    pcStack_5e0 = (char *)0x61679d;
    puStack_5dc = (undefined8 *)uVar6;
    FUN_01675290();
    uVar6 = 2;
    break;
  case 0x89:
    uStack_28 = (double)CONCAT44(*(undefined4 *)(param_1 + 0x1d64),(undefined4)uStack_28);
    puStack_5dc = (undefined8 *)0x6167dd;
    uVar10 = FUN_0054db20();
    puStack_5dc = (undefined8 *)0x6167ec;
    uStack_1c._4_4_ = (int *)uVar10;
    puStack_5e4 = (undefined *)(**(code **)(*(int *)(param_1 + -0x5c) + 0xb4))();
    puStack_5dc = (undefined8 *)param_2;
    pcStack_5e0 = (char *)uStack_1c._4_4_;
    puStack_5e8 = (undefined *)0x6167f9;
    iVar11 = FUN_009701f0();
    if ((iVar11 == 0) || (iVar11 != 1)) {
      iStack_8 = 0x20;
      pcStack_5e0 = (char *)0x616827;
      puStack_5dc = (undefined8 *)uVar6;
      FUN_01675290();
      ExceptionList = pvStack_10;
      return 0;
    }
    iStack_8 = 0x1f;
    pcStack_5e0 = (char *)0x616810;
    puStack_5dc = (undefined8 *)uVar6;
    FUN_01675290();
    uVar6 = 2;
    break;
  case 0x8d:
    puStack_5dc = (undefined8 *)param_2;
    pcStack_5e0 = (char *)0x616685;
    FUN_00625a90();
    iStack_8 = 0x18;
    pcStack_5e0 = (char *)0x616692;
    puStack_5dc = (undefined8 *)uVar6;
    FUN_01675290();
    uVar6 = 2;
    break;
  case 0x91:
    iStack_8 = 9;
    pcStack_5e0 = (char *)0x616168;
    FUN_01675290();
    uVar6 = 2;
    break;
  case 0x97:
    puStack_5dc = (undefined8 *)param_2;
    pcStack_5e0 = (char *)0x61617b;
    FUN_00625a90();
    iStack_8 = 10;
    pcStack_5e0 = (char *)0x616188;
    puStack_5dc = (undefined8 *)uVar6;
    FUN_01675290();
    uVar6 = 2;
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 6589 ; VA 0x0061683f ; Catch@0061683f */

undefined * Catch_0061683f(void)

{
  int iVar1;
  char *pcVar2;
  char *pcVar3;
  int unaff_EBP;
  
  pcVar2 = (char *)(**(code **)(**(int **)(unaff_EBP + -0x4c) + 4))();
  iVar1 = *(int *)(unaff_EBP + 8);
  pcVar3 = "empty error string";
  if (pcVar2 != (char *)0x0) {
    pcVar3 = pcVar2;
  }
  FUN_0086f2f0(3,"Replicator::OnReceive packet %d: %s",**(undefined **)(iVar1 + 0x38),pcVar3);
  if (DAT_01ee420a != '\0') {
    FUN_01677650(DAT_01ee420a,"Error on Replicator::OnReceive: %s",pcVar2);
  }
  FUN_0054eff0(pcVar2);
  *(undefined *)(unaff_EBP + -4) = 0x22;
  *(undefined4 *)(unaff_EBP + -0x6c) = 0;
  *(undefined4 *)(unaff_EBP + -0x68) = 0xf;
  *(undefined *)(unaff_EBP + -0x7c) = 0;
  FUN_005542c0("Other",5);
  *(undefined *)(unaff_EBP + -4) = 0x23;
  FUN_006217d0(iVar1,unaff_EBP + -0x7c,unaff_EBP + -0xf4);
  FUN_005507b0();
  *(undefined *)(unaff_EBP + -4) = 0x21;
  FUN_005507b0();
  FUN_0062b590(0x104);
  return &LAB_006168fe;
}



/* FUNCTION 6590 ; VA 0x00616a10 ; FUN_00616a10 */

undefined FUN_00616a10(void)

{
  return 0;
}



/* FUNCTION 6591 ; VA 0x00616a20 ; FUN_00616a20 */

undefined FUN_00616a20(void)

{
  return 0;
}



/* FUNCTION 6592 ; VA 0x00616a30 ; FUN_00616a30 */

undefined FUN_00616a30(void)

{
  return 0;
}



/* FUNCTION 6593 ; VA 0x00616a40 ; FUN_00616a40 */

int FUN_00616a40(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  int iStack_1c;
  int *piStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179c1b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_1c);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_1c != 0) {
    iStack_1c = FUN_0097bfc0(iStack_1c + 0xc);
    if (iStack_1c != 0) {
      uVar3 = 0;
      FUN_005542c0("rocky",5);
      iStack_1c = FUN_00930bd0(uVar3);
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iStack_1c = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar2 = *piVar1;
      iStack_1c = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iStack_1c = (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iStack_1c = (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iStack_1c;
}



/* FUNCTION 6594 ; VA 0x00616b10 ; FUN_00616b10 */

undefined4 __thiscall FUN_00616b10(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 == 0) {
    return 0;
  }
  if (0xaaaaaaa < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  param_2 = param_2 * 0x18;
  if (param_2 < 0x1000) {
    if (param_2 != 0) {
      uVar1 = FUN_01674e20(param_2);
      *param_1 = uVar1;
      param_1[1] = uVar1;
      param_1[2] = *param_1 + param_2;
      return CONCAT31((int3)(*param_1 + param_2 >> 8),1);
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = *param_1;
    return CONCAT31((int3)(*param_1 >> 8),1);
  }
  uVar1 = param_2 + 0x23;
  if (uVar1 <= param_2) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar1 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar1 - 4) = iVar2;
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + param_2;
    return CONCAT31((int3)(*param_1 + param_2 >> 8),1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 6595 ; VA 0x00616bd0 ; FUN_00616bd0 */

uint __thiscall FUN_00616bd0(int *param_1,uint param_2)

{
  uint in_EAX;
  int iVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 == 0) {
    return in_EAX & 0xffffff00;
  }
  if (param_2 < 0x20000000) {
    iVar1 = FUN_00578020(param_2);
    *param_1 = iVar1;
    param_1[1] = iVar1;
    iVar1 = *param_1 + param_2 * 8;
    param_1[2] = iVar1;
    return CONCAT31((int3)((uint)iVar1 >> 8),1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 6596 ; VA 0x00616c30 ; FUN_00616c30 */

undefined4 __thiscall FUN_00616c30(uint *param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 == 0) {
    return 0;
  }
  if (0xccccccc < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  param_2 = param_2 * 0x14;
  if (param_2 < 0x1000) {
    if (param_2 != 0) {
      uVar1 = FUN_01674e20(param_2);
      *param_1 = uVar1;
      param_1[1] = uVar1;
      param_1[2] = *param_1 + param_2;
      return CONCAT31((int3)(*param_1 + param_2 >> 8),1);
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = *param_1;
    return CONCAT31((int3)(*param_1 >> 8),1);
  }
  uVar1 = param_2 + 0x23;
  if (uVar1 <= param_2) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar1 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar1 - 4) = iVar2;
    *param_1 = uVar1;
    param_1[1] = uVar1;
    param_1[2] = *param_1 + param_2;
    return CONCAT31((int3)(*param_1 + param_2 >> 8),1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 6597 ; VA 0x00616cf0 ; FUN_00616cf0 */

void FUN_00616cf0(void)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(0xf8);
  *(int *)iVar1 = iVar1;
  *(int *)(iVar1 + 4) = iVar1;
  *(int *)(iVar1 + 8) = iVar1;
  *(undefined2 *)(iVar1 + 0xc) = 0x101;
  return;
}



/* FUNCTION 6598 ; VA 0x00616d10 ; FUN_00616d10 */

void FUN_00616d10(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_01674e20(0x24);
  if (param_1 == 0) {
    *piVar1 = (int)piVar1;
    piVar1[1] = (int)piVar1;
    return;
  }
  *piVar1 = param_1;
  piVar1[1] = param_2;
  return;
}



/* FUNCTION 6599 ; VA 0x00616d40 ; FUN_00616d40 */

void __fastcall FUN_00616d40(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0xf8);
  *puVar1 = *param_1;
  puVar1[1] = *param_1;
  puVar1[2] = *param_1;
  return;
}



/* FUNCTION 6600 ; VA 0x00616d60 ; FUN_00616d60 */

void __thiscall FUN_00616d60(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x18) * 0x18;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 0x18;
  param_1[2] = param_2 + param_4 * 0x18;
  return;
}



/* FUNCTION 6601 ; VA 0x00616de0 ; FUN_00616de0 */

void __thiscall FUN_00616de0(int *param_1,int param_2,int param_3,int param_4)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_0056cd30();
        iVar2 = iVar2 + 4;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = param_1[2] - iVar2 & 0xfffffffc;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 4;
  param_1[2] = param_2 + param_4 * 4;
  return;
}



/* FUNCTION 6602 ; VA 0x00616e60 ; FUN_00616e60 */

void __thiscall FUN_00616e60(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_f82bc6ee5d89765a5ff306a4a47ee448>,void,class_std::shared_ptr<class_RBX::Instance>_const&,struct_RBX::Network::NetworkSchema::ClassInfo_const&,class_std::shared_ptr<struct_RBX::Network::CachedBitstream>&&,bool>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 6603 ; VA 0x00616e80 ; FUN_00616e80 */

void __thiscall FUN_00616e80(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<class_<lambda_f98ccb6a5bed2139072d681c8827c301>,void,class_std::shared_ptr<class_RBX::Instance>_const&,struct_RBX::Network::NetworkSchema::ClassInfo_const&,class_std::shared_ptr<struct_RBX::Network::CachedBitstream>&&,bool>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  param_2[2] = *(undefined4 *)(param_1 + 8);
  return;
}



/* FUNCTION 6604 ; VA 0x00616ea0 ; FUN_00616ea0 */

void __fastcall FUN_00616ea0(int param_1)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(param_1 + 0xc);
  if (piVar1 != (int *)0x0) {
    iVar2 = *piVar1;
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_00617290(*(undefined4 *)(iVar2 + 4));
    *(int *)(*piVar1 + 4) = iVar2;
    *(int *)*piVar1 = iVar2;
    *(int *)(*piVar1 + 8) = iVar2;
    piVar1[1] = 0;
    FUN_01674ea0(*piVar1,0xf8);
    FUN_01674ea0(piVar1,8);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6605 ; VA 0x00616f10 ; FUN_00616f10 */

void __fastcall FUN_00616f10(int param_1)

{
  (*(code *)**(undefined4 **)(param_1 + 0xc))(0);
  return;
}



/* FUNCTION 6606 ; VA 0x00616f20 ; FUN_00616f20 */

void FUN_00616f20(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (param_1 != param_2) {
    puVar2 = param_1 + 1;
    ExceptionList = &pvStack_10;
    do {
      uStack_8 = 0;
      FUN_01674ea0(*puVar2);
      *puVar2 = 0;
      puVar2[1] = 0;
      puVar1 = puVar2 + 3;
      puVar2[2] = 0;
      puVar2 = puVar2 + 4;
    } while (puVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6607 ; VA 0x00616fa0 ; FUN_00616fa0 */

void __thiscall FUN_00616fa0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_00602ed0(param_2,param_3,param_1);
  return;
}



/* FUNCTION 6608 ; VA 0x00616fc0 ; FUN_00616fc0 */

void FUN_00616fc0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  
  if (param_1 != param_2) {
    do {
      piVar1 = *(int **)(param_1 + 4);
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar2 = piVar1[1] + -1;
        piVar1[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      param_1 = param_1 + 8;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 6609 ; VA 0x00617010 ; FUN_00617010 */

void FUN_00617010(undefined4 *param_1,undefined4 *param_2)

{
  if (param_1 != param_2) {
    do {
      (**(code **)*param_1)(0);
      param_1 = param_1 + 0x16;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 6610 ; VA 0x00617040 ; FUN_00617040 */

void __thiscall FUN_00617040(int param_1,int *param_2)

{
  *(int *)param_2[1] = *param_2;
  *(int *)(*param_2 + 4) = param_2[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_00612d60();
  FUN_01674ea0(param_2,0x20);
  return;
}



/* FUNCTION 6611 ; VA 0x00617080 ; FUN_00617080 */

void FUN_00617080(undefined4 param_1)

{
  FUN_0056cb40();
  FUN_01674ea0(param_1,0xf8);
  return;
}



/* FUNCTION 6612 ; VA 0x006170b0 ; FUN_006170b0 */

int __thiscall
FUN_006170b0(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined *param_5)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  int iVar8;
  int *piVar9;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_0179dba9;
  pvStack_10 = ExceptionList;
  iVar8 = *(int *)(param_1 + 4);
  uVar3 = *param_5;
  piVar9 = (int *)param_2[1];
  ExceptionList = &pvStack_10;
  if (piVar9 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar9[1] = piVar9[1] + 1;
    UNLOCK();
    piVar9 = (int *)param_2[1];
  }
  uVar7 = *param_2;
  puVar4 = *(undefined4 **)(iVar8 + 0x1948);
  iStack_8 = 0;
  puVar5 = (undefined4 *)*puVar4;
  puVar6 = (undefined4 *)*puVar5;
  if (puVar6 == (undefined4 *)0x0) {
    puVar6 = (undefined4 *)FUN_00621d50();
  }
  else {
    *puVar5 = *puVar6;
  }
  *puVar6 = puVar4;
  iStack_8._0_1_ = 1;
  if (puVar6 == (undefined4 *)0xfffffffc) {
    uVar7 = 0;
  }
  else {
    if (piVar9 != (int *)0x0) {
      LOCK();
      piVar9[1] = piVar9[1] + 1;
      UNLOCK();
    }
    uVar7 = FUN_006bf3f0(iVar8,param_3,uVar7,piVar9,param_4,uVar3);
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  iVar8 = FUN_006b1f50(uVar7);
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar1 = piVar9 + 1;
    iVar2 = *piVar1;
    iVar8 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar8 = (**(code **)*piVar9)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar8 = (**(code **)(*piVar9 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 6613 ; VA 0x006171b0 ; FUN_006171b0 */

void __thiscall
FUN_006171b0(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined *param_5)

{
  undefined uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179dbc8;
  pvStack_10 = ExceptionList;
  uVar1 = *param_5;
  if (((DAT_01d5b808 != '\0') && (DAT_01d5b7f8 != '\0')) ||
     (ExceptionList = &pvStack_10, DAT_01d5b800 != '\0')) {
    iVar4 = *(int *)(param_1 + 4);
    uVar2 = *param_2;
    ExceptionList = &pvStack_10;
    iVar3 = FUN_016dee6d(iVar4 + 0x1e50);
    if (iVar3 != 0) {
      FUN_016df3c9(iVar3);
    }
    uStack_8 = 0;
    if (*(char *)(iVar4 + 0x1db8) == '\0') {
      FUN_006d9230(iVar4,uVar2);
    }
    uStack_8 = 1;
    iVar4 = FUN_016deec8(iVar4 + 0x1e50);
    if (iVar4 != 0) {
      FUN_016df3c9(iVar4);
    }
  }
  uStack_8 = 0xffffffff;
  FUN_006c2f30(param_2,param_3,param_4,uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6614 ; VA 0x00617290 ; FUN_00617290 */

void FUN_00617290(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_00617290(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_0056cb40();
    FUN_01674ea0(param_1,0xf8);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 6615 ; VA 0x006172e0 ; FUN_006172e0 */

void FUN_006172e0(undefined4 param_1)

{
  FUN_01674ea0(param_1,0xf8);
  return;
}



/* FUNCTION 6616 ; VA 0x00617300 ; FUN_00617300 */

void __thiscall FUN_00617300(int param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  uVar5 = *(uint *)(param_1 + 8);
  uVar2 = 1;
  if (uVar5 != 0) {
    uVar2 = uVar5;
  }
  for (; (uVar4 = uVar2 - uVar5, uVar4 < param_2 || (uVar2 < 8)); uVar2 = uVar2 * 2) {
    if (0xfffffff - uVar2 < uVar2) {
      FUN_00593ce0();
LAB_006174dc:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  uVar1 = *(uint *)(param_1 + 0xc);
  uVar5 = uVar2 * 4;
  if (uVar2 < 0x40000000) {
    if (0xfff < uVar5) goto LAB_00617364;
    if (uVar5 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_00617364:
    uVar2 = uVar5 + 0x23;
    if (uVar2 <= uVar5) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_006174dc;
    uVar5 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar5 - 4) = iVar3;
  }
  iVar3 = *(int *)(param_1 + 4);
  iVar6 = uVar1 * 4 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  iVar3 = (*(int *)(param_1 + 8) * 4 - iVar6) + iVar3;
  iVar8 = uVar1 * 4 + uVar5;
  FUN_0170cc70(iVar8,iVar6,iVar3);
  iVar8 = iVar8 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  if (uVar4 < uVar1) {
    iVar7 = uVar4 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar7);
    iVar6 = *(int *)(param_1 + 4);
    iVar3 = iVar7 + iVar6;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    iVar6 = (iVar6 - iVar3) + uVar1 * 4;
    FUN_0170cc70(uVar5,iVar3,iVar6);
    FUN_0170d1f0(iVar6 + uVar5,0,iVar7);
  }
  else {
    iVar3 = uVar1 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar3);
    FUN_0170d1f0(iVar8 + iVar3,0,(uVar4 - uVar1) * 4);
    FUN_0170d1f0(uVar5,0,iVar3);
  }
  iVar3 = *(int *)(param_1 + 4);
  if (iVar3 != 0) {
    uVar2 = *(int *)(param_1 + 8) * 4;
    iVar6 = iVar3;
    if (0xfff < uVar2) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar3 - iVar6) - 4U) goto LAB_006174dc;
    }
    FUN_01674ea0(iVar6,uVar2);
  }
  *(uint *)(param_1 + 4) = uVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + uVar4;
  return;
}



/* FUNCTION 6617 ; VA 0x006174f0 ; FUN_006174f0 */

void __thiscall FUN_006174f0(int param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  uVar5 = *(uint *)(param_1 + 8);
  uVar2 = 1;
  if (uVar5 != 0) {
    uVar2 = uVar5;
  }
  for (; (uVar4 = uVar2 - uVar5, uVar4 < param_2 || (uVar2 < 8)); uVar2 = uVar2 * 2) {
    if (0xaaaaaaa - uVar2 < uVar2) {
      FUN_00593ce0();
LAB_006176cc:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  uVar1 = *(uint *)(param_1 + 0xc);
  uVar5 = uVar2 * 4;
  if (uVar2 < 0x40000000) {
    if (0xfff < uVar5) goto LAB_00617554;
    if (uVar5 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_00617554:
    uVar2 = uVar5 + 0x23;
    if (uVar2 <= uVar5) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_006176cc;
    uVar5 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar5 - 4) = iVar3;
  }
  iVar3 = *(int *)(param_1 + 4);
  iVar6 = uVar1 * 4 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  iVar3 = (*(int *)(param_1 + 8) * 4 - iVar6) + iVar3;
  iVar8 = uVar1 * 4 + uVar5;
  FUN_0170cc70(iVar8,iVar6,iVar3);
  iVar8 = iVar8 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  if (uVar4 < uVar1) {
    iVar7 = uVar4 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar7);
    iVar6 = *(int *)(param_1 + 4);
    iVar3 = iVar7 + iVar6;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    iVar6 = (iVar6 - iVar3) + uVar1 * 4;
    FUN_0170cc70(uVar5,iVar3,iVar6);
    FUN_0170d1f0(iVar6 + uVar5,0,iVar7);
  }
  else {
    iVar3 = uVar1 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar3);
    FUN_0170d1f0(iVar8 + iVar3,0,(uVar4 - uVar1) * 4);
    FUN_0170d1f0(uVar5,0,iVar3);
  }
  iVar3 = *(int *)(param_1 + 4);
  if (iVar3 != 0) {
    uVar2 = *(int *)(param_1 + 8) * 4;
    iVar6 = iVar3;
    if (0xfff < uVar2) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar3 - iVar6) - 4U) goto LAB_006176cc;
    }
    FUN_01674ea0(iVar6,uVar2);
  }
  *(uint *)(param_1 + 4) = uVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + uVar4;
  return;
}



/* FUNCTION 6618 ; VA 0x006176e0 ; FUN_006176e0 */

void __thiscall FUN_006176e0(int param_1,uint param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  uVar4 = *(uint *)(param_1 + 8);
  uVar1 = 1;
  if (uVar4 != 0) {
    uVar1 = uVar4;
  }
  for (; (uVar3 = uVar1 - uVar4, uVar3 < param_2 || (uVar1 < 8)); uVar1 = uVar1 * 2) {
    if (0xfffffff - uVar1 < uVar1) {
      FUN_00593ce0();
LAB_006178b6:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  uVar4 = uVar1 * 4;
  uVar5 = *(uint *)(param_1 + 0xc) >> 1;
  if (uVar1 < 0x40000000) {
    if (0xfff < uVar4) goto LAB_00617746;
    if (uVar4 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_01674e20(uVar4);
    }
  }
  else {
    uVar4 = 0xffffffff;
LAB_00617746:
    uVar1 = uVar4 + 0x23;
    if (uVar1 <= uVar4) {
      uVar1 = 0xffffffff;
    }
    iVar2 = FUN_01674e20(uVar1);
    if (iVar2 == 0) goto LAB_006178b6;
    uVar4 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar4 - 4) = iVar2;
  }
  iVar7 = *(int *)(param_1 + 4);
  iVar8 = uVar5 * 4;
  iVar2 = iVar7 + iVar8;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  iVar7 = (*(int *)(param_1 + 8) * 4 - iVar2) + iVar7;
  FUN_0170cc70(iVar8 + uVar4,iVar2,iVar7);
  iVar7 = iVar7 + iVar8 + uVar4;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  if (uVar3 < uVar5) {
    iVar6 = uVar3 * 4;
    FUN_0170cc70(iVar7,*(undefined4 *)(param_1 + 4),iVar6);
    iVar7 = *(int *)(param_1 + 4);
    iVar2 = iVar6 + iVar7;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    iVar8 = (iVar7 - iVar2) + iVar8;
    FUN_0170cc70(uVar4,iVar2,iVar8);
    FUN_0170d1f0(iVar8 + uVar4,0,iVar6);
  }
  else {
    FUN_0170cc70(iVar7,*(undefined4 *)(param_1 + 4),uVar5 * 4);
    FUN_0170d1f0(iVar7 + iVar8,0,(uVar3 - uVar5) * 4);
    FUN_0170d1f0(uVar4,0,iVar8);
  }
  iVar2 = *(int *)(param_1 + 4);
  if (iVar2 != 0) {
    uVar1 = *(int *)(param_1 + 8) * 4;
    iVar7 = iVar2;
    if (0xfff < uVar1) {
      iVar7 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar7) - 4U) goto LAB_006178b6;
    }
    FUN_01674ea0(iVar7,uVar1);
  }
  *(uint *)(param_1 + 4) = uVar4;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + uVar3;
  return;
}



/* FUNCTION 6619 ; VA 0x006178c0 ; FUN_006178c0 */

void __thiscall FUN_006178c0(int param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  uVar5 = *(uint *)(param_1 + 8);
  uVar2 = 1;
  if (uVar5 != 0) {
    uVar2 = uVar5;
  }
  for (; (uVar4 = uVar2 - uVar5, uVar4 < param_2 || (uVar2 < 8)); uVar2 = uVar2 * 2) {
    if (0x2e8ba2e - uVar2 < uVar2) {
      FUN_00593ce0();
LAB_00617a9c:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  uVar1 = *(uint *)(param_1 + 0xc);
  uVar5 = uVar2 * 4;
  if (uVar2 < 0x40000000) {
    if (0xfff < uVar5) goto LAB_00617924;
    if (uVar5 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_00617924:
    uVar2 = uVar5 + 0x23;
    if (uVar2 <= uVar5) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_00617a9c;
    uVar5 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar5 - 4) = iVar3;
  }
  iVar3 = *(int *)(param_1 + 4);
  iVar6 = uVar1 * 4 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  iVar3 = (*(int *)(param_1 + 8) * 4 - iVar6) + iVar3;
  iVar8 = uVar1 * 4 + uVar5;
  FUN_0170cc70(iVar8,iVar6,iVar3);
  iVar8 = iVar8 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  if (uVar4 < uVar1) {
    iVar7 = uVar4 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar7);
    iVar6 = *(int *)(param_1 + 4);
    iVar3 = iVar7 + iVar6;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    iVar6 = (iVar6 - iVar3) + uVar1 * 4;
    FUN_0170cc70(uVar5,iVar3,iVar6);
    FUN_0170d1f0(iVar6 + uVar5,0,iVar7);
  }
  else {
    iVar3 = uVar1 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar3);
    FUN_0170d1f0(iVar8 + iVar3,0,(uVar4 - uVar1) * 4);
    FUN_0170d1f0(uVar5,0,iVar3);
  }
  iVar3 = *(int *)(param_1 + 4);
  if (iVar3 != 0) {
    uVar2 = *(int *)(param_1 + 8) * 4;
    iVar6 = iVar3;
    if (0xfff < uVar2) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar3 - iVar6) - 4U) goto LAB_00617a9c;
    }
    FUN_01674ea0(iVar6,uVar2);
  }
  *(uint *)(param_1 + 4) = uVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + uVar4;
  return;
}



/* FUNCTION 6620 ; VA 0x00617ab0 ; FUN_00617ab0 */

TypeDescriptor * FUN_00617ab0(void)

{
  return &<lambda_f82bc6ee5d89765a5ff306a4a47ee448>::RTTI_Type_Descriptor;
}



/* FUNCTION 6621 ; VA 0x00617ac0 ; FUN_00617ac0 */

TypeDescriptor * FUN_00617ac0(void)

{
  return &<lambda_f98ccb6a5bed2139072d681c8827c301>::RTTI_Type_Descriptor;
}



/* FUNCTION 6622 ; VA 0x00617ad0 ; FUN_00617ad0 */

void __fastcall FUN_00617ad0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0xc) * 0xc;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 6623 ; VA 0x00617b40 ; FUN_00617b40 */

void __fastcall FUN_00617b40(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_00602ed0(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0xd8) * 0xd8;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 6624 ; VA 0x00617bc0 ; FUN_00617bc0 */

void __fastcall FUN_00617bc0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x14) * 0x14;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 6625 ; VA 0x00617c30 ; FUN_00617c30 */

int FUN_00617c30(int param_1,int param_2,int param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179dbe8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != param_2) {
    do {
      FUN_0060f060(param_1);
      param_3 = param_3 + 0x58;
      param_1 = param_1 + 0x58;
    } while (param_1 != param_2);
  }
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 6626 ; VA 0x00617ca0 ; FUN_00617ca0 */

void FUN_00617ca0(int *param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  
  if (param_1 != param_2) {
    do {
      iVar2 = *param_1;
      *param_3 = iVar2;
      LOCK();
      piVar1 = (int *)(iVar2 + 0x28);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      param_1 = param_1 + 1;
      param_3 = param_3 + 1;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 6627 ; VA 0x00617cd0 ; FUN_00617cd0 */

void FUN_00617cd0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  
  if (param_1 != param_2) {
    param_3 = param_3 - (int)param_1;
    do {
      iVar2 = *param_1;
      *(int *)(param_3 + (int)param_1) = iVar2;
      LOCK();
      piVar1 = (int *)(iVar2 + 0x28);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      param_1 = param_1 + 1;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 6628 ; VA 0x00617d00 ; FUN_00617d00 */

void * __thiscall
FUN_00617d00(int *param_1,undefined4 param_2,int param_3,int *param_4,uint param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,char param_9)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  char cVar5;
  int iVar6;
  void *pvVar7;
  undefined4 uVar8;
  undefined auStack_58 [72];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar2 = param_3;
  puStack_c = &LAB_0179dc10;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  pvVar7 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    iVar3 = *(int *)(param_3 + 0xc);
    ExceptionList = &pvStack_10;
    iVar6 = FUN_00af0010();
    pvVar7 = (void *)(uint)*(ushort *)(iVar6 + 0x1da);
    if (((void *)((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8)) <= pvVar7) &&
       ((DAT_01d5b820 == '\0' || (param_1[0x686] == 0)))) {
      if (DAT_01eace39 != '\0') {
        FUN_01677520(DAT_01eace39,"Adding replication data for mega cluster instance %p",iVar2);
      }
      if (DAT_01d65191 != '\0') {
        FUN_01677490(DAT_01d65191,"Adding MegaCluster replication data :%p, listenToChanges: %u",
                     param_3,param_5 & 0xff,0);
      }
      FUN_0170d1f0(auStack_58,0,0x48);
      uVar8 = FUN_0060ee60();
      iStack_8._0_1_ = 1;
      FUN_00613da0(uVar8);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_00612ec0();
      cVar5 = (**(code **)(*param_1 + 0xd4))();
      if (cVar5 != '\0') {
        FUN_00708420(iVar2);
        FUN_00707180(param_1,iVar2);
      }
      param_1[0x686] = iVar2;
      pvVar7 = (void *)FUN_00a6e300(param_1 + 0x1a);
    }
  }
  if (*(char *)(param_1 + 0x76e) == '\0') {
    if ((DAT_01d5b840 == '\0') || (param_9 == '\0')) {
      uVar8 = 0;
    }
    else {
      uVar8 = 1;
    }
    pvVar7 = (void *)FUN_006d4ab0(param_1,param_2,&param_3,param_5,param_6,param_7,param_8,uVar8);
  }
  piVar4 = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar2 = *piVar1;
    pvVar7 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar7 = (void *)(**(code **)*param_4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar7 = (void *)(**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar7;
}



/* FUNCTION 6629 ; VA 0x00617ea0 ; FUN_00617ea0 */

void __thiscall FUN_00617ea0(double *param_1,double param_2)

{
  *(int *)(param_1 + 1) = *(int *)(param_1 + 1) + 1;
  *param_1 = *param_1 + param_2;
  return;
}



/* FUNCTION 6630 ; VA 0x00617ec0 ; FUN_00617ec0 */

int __thiscall
FUN_00617ec0(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_0179dc39;
  pvStack_10 = ExceptionList;
  puVar3 = *(undefined4 **)(param_1 + 0x1948);
  iStack_8 = 0;
  puVar4 = (undefined4 *)*puVar3;
  puVar5 = (undefined4 *)*puVar4;
  if (puVar5 == (undefined4 *)0x0) {
    ExceptionList = &pvStack_10;
    puVar5 = (undefined4 *)FUN_00621d50();
  }
  else {
    ExceptionList = &pvStack_10;
    *puVar4 = *puVar5;
  }
  *puVar5 = puVar3;
  iStack_8._0_1_ = 1;
  if (puVar5 == (undefined4 *)0xfffffffc) {
    uVar6 = 0;
  }
  else {
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    uVar6 = FUN_006bf3f0(param_1,param_4,param_2,param_3,param_5,param_6);
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  iVar7 = FUN_006b1f50(uVar6);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar7 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar7 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 6631 ; VA 0x00617fa0 ; FUN_00617fa0 */

void __thiscall FUN_00617fa0(undefined4 *param_1,int *param_2,int param_3,uint param_4)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)*param_1;
  if ((piVar2 == (int *)0x0) || (param_2 < piVar2)) {
    piVar3 = (int *)0x0;
  }
  else {
    piVar3 = piVar2;
    for (piVar1 = (int *)*piVar2; (piVar1 != (int *)0x0 && (piVar1 <= param_2));
        piVar1 = (int *)*piVar1) {
      piVar3 = piVar1;
    }
  }
  piVar1 = (int *)(((param_3 - param_4) / param_4) * param_4 + (int)param_2);
  if (piVar3 != (int *)0x0) {
    *piVar1 = *piVar3;
    if (piVar1 != param_2) {
      for (piVar2 = (int *)((int)piVar1 - param_4); piVar2 != param_2;
          piVar2 = (int *)((int)piVar2 - param_4)) {
        *piVar2 = (int)piVar1;
        piVar1 = piVar2;
      }
      *param_2 = (int)piVar1;
    }
    *piVar3 = (int)param_2;
    return;
  }
  *piVar1 = (int)piVar2;
  if (piVar1 != param_2) {
    for (piVar2 = (int *)((int)piVar1 - param_4); piVar2 != param_2;
        piVar2 = (int *)((int)piVar2 - param_4)) {
      *piVar2 = (int)piVar1;
      piVar1 = piVar2;
    }
    *param_2 = (int)piVar1;
  }
  *param_1 = param_2;
  return;
}



/* FUNCTION 6632 ; VA 0x00618050 ; FUN_00618050 */

uint FUN_00618050(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 * 0xc;
  if (param_1 < 0x15555556) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 6633 ; VA 0x006180c0 ; FUN_006180c0 */

uint FUN_006180c0(undefined *param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = (int)param_1 * 0xd8;
  if (param_1 < &UNK_012f684c) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 6634 ; VA 0x00618130 ; FUN_00618130 */

uint FUN_00618130(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 * 0x14;
  if (param_1 < 0xccccccd) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 6635 ; VA 0x006181a0 ; FUN_006181a0 */

uint FUN_006181a0(uint param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = param_1 * 0x58;
  if (param_1 < 0x2e8ba2f) {
    if (uVar3 < 0x1000) {
      if (uVar3 != 0) {
        uVar3 = FUN_01674e20(uVar3);
        return uVar3;
      }
      return 0;
    }
  }
  else {
    uVar3 = 0xffffffff;
  }
  uVar1 = uVar3 + 0x23;
  if (uVar1 <= uVar3) {
    uVar1 = 0xffffffff;
  }
  iVar2 = FUN_01674e20(uVar1);
  if (iVar2 != 0) {
    uVar3 = iVar2 + 0x23U & 0xffffffe0;
    *(int *)(uVar3 - 4) = iVar2;
    return uVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 6636 ; VA 0x00618210 ; FUN_00618210 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_00618210(int param_1)

{
  code *pcVar1;
  uint uVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179dc58;
  pvStack_10 = ExceptionList;
  if (param_1 == 1) {
    if (DAT_01ead26a == '\0') {
      DAT_01ead26a = '\x01';
      DAT_01ead1f4 = 0;
      uRam01ead1f8 = 0;
      DAT_01ead1fc = (undefined4 *)0x0;
      DAT_01ead200 = 0;
      _DAT_01ead214 = 0;
      DAT_01ead204 = _DAT_018ce380;
      _DAT_01ead208 = _UNK_018ce384;
      _DAT_01ead20c = _UNK_018ce388;
      _DAT_01ead210 = _UNK_018ce38c;
    }
    ExceptionList = &pvStack_10;
    FUN_005874f0();
    if (DAT_01ead1fc == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)FUN_00621e70();
    }
    else {
      puVar5 = DAT_01ead1fc;
      DAT_01ead1fc = (undefined4 *)*DAT_01ead1fc;
    }
    uStack_8 = 0;
  }
  else {
    if (DAT_01ead26a == '\0') {
      DAT_01ead26a = '\x01';
      DAT_01ead1f4 = 0;
      uRam01ead1f8 = 0;
      DAT_01ead1fc = (undefined4 *)0x0;
      DAT_01ead200 = 0;
      _DAT_01ead214 = 0;
      DAT_01ead204 = _DAT_018ce380;
      _DAT_01ead208 = _UNK_018ce384;
      _DAT_01ead20c = _UNK_018ce388;
      _DAT_01ead210 = _UNK_018ce38c;
    }
    ExceptionList = &pvStack_10;
    FUN_005874f0();
    puVar5 = (undefined4 *)FUN_00624080(param_1);
    uStack_8 = 1;
  }
  LOCK();
  uVar2 = DAT_01ead1f4 + 0x80000000;
  UNLOCK();
  uVar3 = uVar2;
  if (((DAT_01ead1f4 & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead1f4)) {
    LOCK();
    DAT_01ead1f4 = uVar2 | 0x40000000;
    UNLOCK();
    uVar3 = DAT_01ead1f4;
    if ((uVar2 >> 0x1e & 1) == 0) {
      uVar4 = FUN_00554e40();
      SetEvent(uVar4);
      uVar3 = DAT_01ead1f4;
    }
  }
  DAT_01ead1f4 = uVar3;
  uStack_8 = 0xffffffff;
  if (puVar5 != (undefined4 *)0x0) {
    ExceptionList = pvStack_10;
    return puVar5;
  }
  uVar4 = FUN_0054fbc0();
  uStack_8 = 2;
  FUN_005648a0(uVar4);
  pcVar1 = (code *)swi(3);
  puVar5 = (undefined4 *)(*pcVar1)();
  return puVar5;
}



/* FUNCTION 6637 ; VA 0x00618350 ; FUN_00618350 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_00618350(int param_1)

{
  code *pcVar1;
  uint uVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179dc58;
  pvStack_10 = ExceptionList;
  if (param_1 == 1) {
    if (DAT_01ead269 == '\0') {
      DAT_01ead269 = '\x01';
      DAT_01ead21c = 0;
      uRam01ead220 = 0;
      DAT_01ead224 = (undefined4 *)0x0;
      DAT_01ead228 = 0;
      _DAT_01ead23c = 0;
      DAT_01ead22c = _DAT_018ce370;
      _DAT_01ead230 = _UNK_018ce374;
      _DAT_01ead234 = _UNK_018ce378;
      _DAT_01ead238 = _UNK_018ce37c;
    }
    ExceptionList = &pvStack_10;
    FUN_005874f0();
    if (DAT_01ead224 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)FUN_00621e70();
    }
    else {
      puVar5 = DAT_01ead224;
      DAT_01ead224 = (undefined4 *)*DAT_01ead224;
    }
    uStack_8 = 0;
  }
  else {
    if (DAT_01ead269 == '\0') {
      DAT_01ead269 = '\x01';
      DAT_01ead21c = 0;
      uRam01ead220 = 0;
      DAT_01ead224 = (undefined4 *)0x0;
      DAT_01ead228 = 0;
      _DAT_01ead23c = 0;
      DAT_01ead22c = _DAT_018ce370;
      _DAT_01ead230 = _UNK_018ce374;
      _DAT_01ead234 = _UNK_018ce378;
      _DAT_01ead238 = _UNK_018ce37c;
    }
    ExceptionList = &pvStack_10;
    FUN_005874f0();
    puVar5 = (undefined4 *)FUN_00624080(param_1);
    uStack_8 = 1;
  }
  LOCK();
  uVar2 = DAT_01ead21c + 0x80000000;
  UNLOCK();
  uVar3 = uVar2;
  if (((DAT_01ead21c & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead21c)) {
    LOCK();
    DAT_01ead21c = uVar2 | 0x40000000;
    UNLOCK();
    uVar3 = DAT_01ead21c;
    if ((uVar2 >> 0x1e & 1) == 0) {
      uVar4 = FUN_00554e40();
      SetEvent(uVar4);
      uVar3 = DAT_01ead21c;
    }
  }
  DAT_01ead21c = uVar3;
  uStack_8 = 0xffffffff;
  if (puVar5 != (undefined4 *)0x0) {
    ExceptionList = pvStack_10;
    return puVar5;
  }
  uVar4 = FUN_0054fbc0();
  uStack_8 = 2;
  FUN_005648a0(uVar4);
  pcVar1 = (code *)swi(3);
  puVar5 = (undefined4 *)(*pcVar1)();
  return puVar5;
}



/* FUNCTION 6638 ; VA 0x00618490 ; FUN_00618490 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_00618490(int param_1)

{
  code *pcVar1;
  uint uVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179dc58;
  pvStack_10 = ExceptionList;
  if (param_1 == 1) {
    if (DAT_01ead26b == '\0') {
      DAT_01ead26b = '\x01';
      DAT_01ead244 = 0;
      uRam01ead248 = 0;
      DAT_01ead24c = (undefined4 *)0x0;
      DAT_01ead250 = 0;
      _DAT_01ead264 = 0;
      DAT_01ead254 = _DAT_018ce340;
      uRam01ead258 = _UNK_018ce344;
      uRam01ead25c = _UNK_018ce348;
      uRam01ead260 = _UNK_018ce34c;
    }
    ExceptionList = &pvStack_10;
    FUN_005874f0();
    if (DAT_01ead24c == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)FUN_00621e70();
    }
    else {
      puVar5 = DAT_01ead24c;
      DAT_01ead24c = (undefined4 *)*DAT_01ead24c;
    }
    uStack_8 = 0;
  }
  else {
    if (DAT_01ead26b == '\0') {
      DAT_01ead26b = '\x01';
      DAT_01ead244 = 0;
      uRam01ead248 = 0;
      DAT_01ead24c = (undefined4 *)0x0;
      DAT_01ead250 = 0;
      _DAT_01ead264 = 0;
      DAT_01ead254 = _DAT_018ce340;
      uRam01ead258 = _UNK_018ce344;
      uRam01ead25c = _UNK_018ce348;
      uRam01ead260 = _UNK_018ce34c;
    }
    ExceptionList = &pvStack_10;
    FUN_005874f0();
    puVar5 = (undefined4 *)FUN_00624080(param_1);
    uStack_8 = 1;
  }
  LOCK();
  uVar2 = DAT_01ead244 + 0x80000000;
  UNLOCK();
  uVar3 = uVar2;
  if (((DAT_01ead244 & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead244)) {
    LOCK();
    DAT_01ead244 = uVar2 | 0x40000000;
    UNLOCK();
    uVar3 = DAT_01ead244;
    if ((uVar2 >> 0x1e & 1) == 0) {
      uVar4 = FUN_00554e40();
      SetEvent(uVar4);
      uVar3 = DAT_01ead244;
    }
  }
  DAT_01ead244 = uVar3;
  uStack_8 = 0xffffffff;
  if (puVar5 != (undefined4 *)0x0) {
    ExceptionList = pvStack_10;
    return puVar5;
  }
  uVar4 = FUN_0054fbc0();
  uStack_8 = 2;
  FUN_005648a0(uVar4);
  pcVar1 = (code *)swi(3);
  puVar5 = (undefined4 *)(*pcVar1)();
  return puVar5;
}



/* FUNCTION 6639 ; VA 0x006185d0 ; FUN_006185d0 */

void __fastcall FUN_006185d0(int param_1)

{
  int *piVar1;
  int *piVar2;
  double *pdVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  float fStack_28;
  int iStack_24;
  int iStack_20;
  undefined uStack_1c;
  undefined auStack_18 [4];
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179dc78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pdVar3 = (double *)FUN_016830f0(auStack_18);
  fStack_14 = (float)(*pdVar3 - *(double *)(param_1 + 0x18e0));
  if ((float)DAT_01d59f4c < fStack_14) {
    uVar4 = FUN_01679ce0();
    if (uVar4 % 10000 < DAT_01eace74) {
      uStack_30 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = auStack_40[0] & 0xffffff00;
      uStack_8 = 0;
      FUN_01531f50(auStack_40);
      uStack_1c = *(char *)(param_1 + 0x18ee) == '\0';
      fStack_28 = fStack_14;
      iVar5 = FUN_016f3cd0();
      iStack_24 = *(int *)(param_1 + 0x1874) + *(int *)(param_1 + 0x1870) +
                  *(int *)(param_1 + 0x186c) + *(int *)(param_1 + 0x1868) +
                  *(int *)(param_1 + 0x1864) + iVar5;
      iVar6 = FUN_016f3cd0();
      piVar1 = (int *)(param_1 + 0x18dc);
      iStack_20 = *(int *)(param_1 + 0x18dc) + *(int *)(param_1 + 0x18d8) +
                  *(int *)(param_1 + 0x18d4) + *(int *)(param_1 + 0x18d0) +
                  *(int *)(param_1 + 0x18cc) + iVar6;
      FUN_006073c0("NewInstance",param_1 + 0x1818,param_1 + 0x1880,iVar5,iVar6,auStack_40);
      FUN_006071a0("PropertyChange",param_1 + 0x1830,param_1 + 0x1898,
                   *(undefined4 *)(param_1 + 0x1864),*(undefined4 *)(param_1 + 0x18cc),auStack_40);
      FUN_006071a0("EventInvocation",param_1 + 0x1848,param_1 + 0x18b0,
                   *(undefined4 *)(param_1 + 0x1868),*(undefined4 *)(param_1 + 0x18d0),auStack_40);
      piVar2 = (int *)(param_1 + 0x18d4);
      if ((*(int *)(param_1 + 0x186c) != 0) || (*piVar2 != 0)) {
        FUN_0060d9a0("Terrain","Total",param_1 + 0x186c,piVar2,*(int *)(param_1 + 0x186c),*piVar2,
                     auStack_40);
      }
      piVar2 = (int *)(param_1 + 0x18d8);
      if ((*(int *)(param_1 + 0x1870) != 0) || (*piVar2 != 0)) {
        FUN_0060d9a0(&DAT_018cb3fc,"Total",param_1 + 0x1870,piVar2,*(int *)(param_1 + 0x1870),
                     *piVar2,auStack_40);
      }
      if ((*(int *)(param_1 + 0x1874) != 0) || (*piVar1 != 0)) {
        FUN_0060d9a0("Touches","Total",param_1 + 0x1874,piVar1,*(int *)(param_1 + 0x1874),*piVar1,
                     auStack_40);
      }
      uStack_8 = 0xffffffff;
      if (0xf < uStack_2c) {
        uVar7 = uStack_2c + 1;
        uVar4 = auStack_40[0];
        if (0xfff < uVar7) {
          uVar4 = *(uint *)(auStack_40[0] - 4);
          uVar7 = uStack_2c + 0x24;
          if (0x1f < (auStack_40[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar4,uVar7);
      }
      uStack_30 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = auStack_40[0] & 0xffffff00;
    }
    FUN_0062b6f0();
    FUN_0062b6f0();
    *(undefined *)(param_1 + 0x18ee) = 1;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6640 ; VA 0x00618870 ; FUN_00618870 */

undefined * FUN_00618870(undefined *param_1)

{
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0("Dummy",5);
  return param_1;
}



/* FUNCTION 6641 ; VA 0x006188a0 ; FUN_006188a0 */

void FUN_006188a0(int *param_1,int *param_2)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179dc98;
  pvStack_10 = ExceptionList;
  iVar5 = param_1[5];
  ExceptionList = &pvStack_10;
  if (iVar5 != 0) {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_016dee6d(iVar5 + 0x1c);
    if (iVar2 != 0) {
      FUN_016df3c9(iVar2);
    }
    uStack_8 = 0;
    if (*(int *)(iVar5 + 0xc) != 0) {
      uVar3 = FUN_009c91f0(param_1 + 6);
      uVar6 = uVar3 % *(uint *)(iVar5 + 8);
      piVar7 = *(int **)(uVar6 * 4 + *(int *)(iVar5 + 0x18));
      if ((piVar7 != (int *)0x0) && (iVar2 = *piVar7, iVar2 != 0)) {
        while (*(uint *)(iVar2 + 4) % *(uint *)(iVar5 + 8) == uVar6) {
          if ((*(uint *)(iVar2 + 4) == uVar3) && (cVar1 = FUN_009c8f50(iVar2 + 8), cVar1 != '\0')) {
            FUN_0061ad00(piVar7,*(undefined4 *)*piVar7);
            if (*piVar7 != 0) {
              uVar3 = *(uint *)(*piVar7 + 4) % *(uint *)(iVar5 + 8);
              if (uVar6 == uVar3) break;
              *(int **)(*(int *)(iVar5 + 0x18) + uVar3 * 4) = piVar7;
            }
            puVar4 = (undefined4 *)(*(int *)(iVar5 + 0x18) + uVar6 * 4);
            if ((int *)*puVar4 == piVar7) {
              *puVar4 = 0;
            }
            break;
          }
          piVar7 = (int *)*piVar7;
          iVar2 = *piVar7;
          if (iVar2 == 0) break;
        }
      }
    }
    uStack_8 = 1;
    iVar5 = FUN_016deec8(iVar5 + 0x1c);
    if (iVar5 != 0) {
      FUN_016df3c9(iVar5);
    }
    uStack_8 = 0xffffffff;
    param_1[5] = 0;
    FUN_00611620();
  }
  param_1[6] = *param_2;
  param_1[7] = param_2[1];
  FUN_00628420(param_1);
  (**(code **)(*param_1 + 0x18))();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6642 ; VA 0x00618a10 ; FUN_00618a10 */

void __thiscall FUN_00618a10(int param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  int *piVar2;
  undefined4 *puStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179dcb8;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_2 + 0x22) == '\0') {
    piVar2 = (int *)(param_1 + 0x1ee4);
    puStack_18 = &DAT_0211a3d8;
    iStack_14 = param_2;
    iVar1 = *piVar2;
    ExceptionList = &pvStack_10;
    *piVar2 = (int)&puStack_18;
    uStack_8 = 0;
    FUN_008a65e0(param_3,0);
    *piVar2 = iVar1;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6643 ; VA 0x00618a80 ; FUN_00618a80 */

void __thiscall FUN_00618a80(int param_1,undefined4 *param_2)

{
  if (*(int *)(param_1 + 8) != 0) {
    *param_2 = *(undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
    return;
  }
  *param_2 = 0;
  return;
}



/* FUNCTION 6644 ; VA 0x00618ab0 ; FUN_00618ab0 */

uint __thiscall FUN_00618ab0(int *param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 uVar2;
  
  cVar1 = (**(code **)(*param_1 + 0x11c))();
  if (cVar1 != '\0') {
    if (((((DAT_01d67098 != '\0') && (param_2 == (undefined4 *)&DAT_01eeec34)) ||
         (param_2 == (undefined4 *)&DAT_01eeebc4)) ||
        (((param_2 == (undefined4 *)&DAT_0211b158 || (param_2 == (undefined4 *)&DAT_0211b200)) ||
         ((param_2 == &DAT_0212ca3c ||
          ((param_2 == (undefined4 *)&DAT_0212076c || (param_2 == &DAT_01eebf14)))))))) ||
       ((param_2 == &DAT_01eee910 ||
        ((((param_2 == (undefined4 *)&DAT_0212cb68 || (param_2 == &DAT_02125100)) ||
          (param_2 == &DAT_0212d5c0)) || (param_2 == &DAT_0211a318)))))) {
      return 1;
    }
    if (param_2 == (undefined4 *)&DAT_0212c458) {
      return 0;
    }
    if (DAT_01d665a8 != '\0') {
      uVar2 = FUN_00abe1a0();
      cVar1 = FUN_00892700(uVar2);
      if (cVar1 != '\0') {
        return 0;
      }
    }
  }
  return (uint)param_2[9] >> 2 & 0xffffff01;
}



/* FUNCTION 6645 ; VA 0x00618b80 ; FUN_00618b80 */

uint FUN_00618b80(char param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 uVar2;
  
  if (param_1 != '\0') {
    if (((((DAT_01d67098 != '\0') && (param_2 == (undefined4 *)&DAT_01eeec34)) ||
         (param_2 == (undefined4 *)&DAT_01eeebc4)) ||
        (((param_2 == (undefined4 *)&DAT_0211b158 || (param_2 == (undefined4 *)&DAT_0211b200)) ||
         ((param_2 == &DAT_0212ca3c ||
          ((param_2 == (undefined4 *)&DAT_0212076c || (param_2 == &DAT_01eebf14)))))))) ||
       ((param_2 == &DAT_01eee910 ||
        ((((param_2 == (undefined4 *)&DAT_0212cb68 || (param_2 == &DAT_02125100)) ||
          (param_2 == &DAT_0212d5c0)) || (param_2 == &DAT_0211a318)))))) {
      return 1;
    }
    if (param_2 == (undefined4 *)&DAT_0212c458) {
      return 0;
    }
    if (DAT_01d665a8 != '\0') {
      uVar2 = FUN_00abe1a0();
      cVar1 = FUN_00892700(uVar2);
      if (cVar1 != '\0') {
        return 0;
      }
    }
  }
  return (uint)param_2[9] >> 2 & 0xffffff01;
}



/* FUNCTION 6646 ; VA 0x00618c40 ; FUN_00618c40 */

bool FUN_00618c40(int *param_1,int param_2,char param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined8 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179dce8;
  pvStack_10 = ExceptionList;
  iVar3 = *param_1;
  if (iVar3 == 0) {
    return false;
  }
  if (param_3 == '\0') {
    iVar4 = 1;
  }
  else {
    iVar4 = *(int *)(iVar3 + 0xe28) + -200;
    if (iVar4 < 1) {
      iVar4 = 0;
    }
  }
  iVar2 = iVar3 + 0xf10;
  if (*(int *)(iVar3 + 0x6c) == 0) {
    iVar2 = 0;
  }
  if (iVar2 != 0) {
    if (param_3 == '\0') {
      iVar4 = iVar4 - *(int *)(iVar2 + 0x98 + param_2 * 4);
      iVar3 = 0;
      if (-1 < iVar4) {
        iVar3 = iVar4;
      }
      return 0 < iVar3;
    }
    iVar3 = (int)((double)iVar4 - *(double *)(iVar2 + 0xa8 + param_2 * 8));
    if ((DAT_01d5b598 != '\0') && (iVar3 < 0)) {
      iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
      ExceptionList = &pvStack_10;
      if ((*(int *)(iVar1 + 0x34) < DAT_01ead0f0) &&
         (ExceptionList = &pvStack_10, FUN_016f3809(), DAT_01ead0f0 == -1)) {
        uStack_8 = 0;
        uVar5 = FUN_0152da50();
        DAT_01ead0ec = (undefined4)((ulonglong)uVar5 >> 0x20);
        DAT_01ead0e8 = (undefined4)uVar5;
        uStack_8 = 0xffffffff;
        FUN_016f37bf(&DAT_01ead0f0);
      }
      FUN_0152d740(DAT_01ead0e8,DAT_01ead0ec,"Insufficient buffer to serialize data");
      if ((*(int *)(iVar1 + 0x34) < DAT_01ead100) && (FUN_016f3809(), DAT_01ead100 == -1)) {
        uStack_8 = 1;
        uVar5 = FUN_0152da50();
        DAT_01ead0fc = (undefined4)((ulonglong)uVar5 >> 0x20);
        DAT_01ead0f8 = (undefined4)uVar5;
        uStack_8 = 0xffffffff;
        FUN_016f37bf(&DAT_01ead100);
      }
      FUN_0152d760(DAT_01ead0f8,DAT_01ead0fc,
                   "Buffer Requested : %d bytes - Data already in buffers : %f bytes",iVar4,
                   *(undefined8 *)(iVar2 + 0xa8 + param_2 * 8));
    }
    if (iVar3 < 1) {
      iVar3 = 0;
    }
    ExceptionList = pvStack_10;
    return 0 < iVar3;
  }
  return false;
}



/* FUNCTION 6647 ; VA 0x00618e60 ; FUN_00618e60 */

uint __thiscall FUN_00618e60(undefined4 *param_1,float param_2)

{
  float fVar1;
  undefined4 in_EAX;
  int iVar2;
  uint uVar3;
  undefined4 *puVar4;
  float10 extraout_ST0;
  undefined auStack_c [8];
  undefined2 uVar5;
  
  fVar1 = (float)param_1[4];
  uVar5 = (undefined2)((uint)in_EAX >> 0x10);
  iVar2 = (uint)CONCAT21(uVar5,(fVar1 == 0.0) << 6 | NAN(fVar1) << 2 | 2U | fVar1 < 0.0) << 8;
  if (NAN(fVar1) == (fVar1 == 0.0)) {
    fVar1 = (float)param_1[3];
    iVar2 = (uint)CONCAT21(uVar5,(fVar1 == 0.0) << 6 | NAN(fVar1) << 2 | 2U | fVar1 < 0.0) << 8;
    if (NAN(fVar1) == (fVar1 == 0.0)) {
      uVar3 = FUN_0061f160();
      fVar1 = (float)(extraout_ST0 + (float10)param_2);
      if ((float)param_1[3] <= fVar1 && fVar1 != (float)param_1[3]) {
        return uVar3 & 0xffffff00;
      }
      param_1[2] = fVar1;
      puVar4 = (undefined4 *)FUN_016830f0(auStack_c);
      *param_1 = *puVar4;
      iVar2 = puVar4[1];
      param_1[1] = iVar2;
    }
  }
  return CONCAT31((int3)((uint)iVar2 >> 8),1);
}



/* FUNCTION 6648 ; VA 0x00618ed0 ; FUN_00618ed0 */

undefined __thiscall FUN_00618ed0(int *param_1,int param_2)

{
  uint uVar1;
  uint uVar2;
  float fVar3;
  char cVar4;
  int *piVar5;
  undefined *puVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 ****ppppuVar9;
  bool bVar10;
  float fVar11;
  undefined8 uVar12;
  undefined auStack_5c [24];
  undefined4 ***apppuStack_44 [5];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179dd44;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  cVar4 = (**(code **)(*param_1 + 0xd4))();
  if (cVar4 == '\0') {
    ExceptionList = pvStack_10;
    return 0;
  }
  iVar8 = *(int *)(param_2 + 0x14);
  piVar5 = (int *)(**(code **)(**(int **)(param_2 + 0x1c) + 0x10))(iVar8);
  if (piVar5 != (int *)0x0) {
    cVar4 = (**(code **)(*piVar5 + 4))();
    if (cVar4 == '\0') {
      fVar11 = (float)((double)*(int *)(param_2 + 0x10) +
                      (double)(&DAT_018c0d90)[-(*(int *)(param_2 + 0x10) >> 0x1f)]);
      fVar3 = *(float *)(param_2 + 0xc);
      if (*(float *)(param_2 + 0xc) <= fVar11) {
        fVar3 = fVar11;
      }
      cVar4 = FUN_00618e60(fVar3);
      if (cVar4 == '\0') {
        uVar2 = param_1[0x67a];
        uVar1 = uVar2 + 1;
        param_1[0x67a] = uVar1;
        if ((uVar2 & uVar1) == 0) {
          bVar10 = iVar8 == 0;
          if (bVar10) {
            uStack_18 = 0;
            uStack_14 = 0xf;
            auStack_28[0] = 0;
            FUN_005542c0("unknown instance",0x10);
            puVar6 = auStack_28;
          }
          else {
            puVar6 = (undefined *)FUN_008a2380(auStack_5c);
          }
          FUN_0054ef20(puVar6);
          uStack_8 = 1;
          if (bVar10) {
            FUN_005507b0();
          }
          uStack_8._0_1_ = 2;
          if (!bVar10) {
            FUN_005507b0();
          }
          iVar8 = param_1[0x67a];
          uVar7 = (**(code **)(*piVar5 + 0xc))();
          ppppuVar9 = apppuStack_44;
          if (0xf < uStack_30) {
            ppppuVar9 = (undefined4 ****)apppuStack_44[0];
          }
          FUN_0086f2f0(3,
                       "Remote event invocation queue data rate limit reached on %s.%s.  (%d errors)"
                       ,ppppuVar9,uVar7,iVar8);
          if (param_1[0x67a] == 1) {
            uStack_18 = 0;
            uStack_14 = 0xf;
            auStack_28[0] = 0;
            FUN_005542c0("DiqLimit",8);
            uStack_8._0_1_ = 3;
            FUN_008783f0(auStack_28,1,0);
            uStack_8._0_1_ = 2;
            FUN_005507b0();
            if (0 < DAT_01eace60) {
              FUN_0151f6f0(0xffffffff,0,0);
              uStack_8._0_1_ = 4;
              uVar7 = FUN_0058c540(auStack_5c,0,0x80);
              uStack_8._0_1_ = 5;
              FUN_0151f950(&DAT_018cc3a4,uVar7);
              uStack_8 = CONCAT31(uStack_8._1_3_,4);
              FUN_005507b0();
              uVar7 = (**(code **)(*piVar5 + 0xc))();
              FUN_0151f850(&DAT_018cc3ac,uVar7);
              iVar8 = (**(code **)(*param_1 + 0xb4))();
              if (iVar8 == 0) {
                uVar12 = 0xffffffffffffffff;
              }
              else {
                uVar12 = FUN_00928340();
              }
              FUN_0151fbb0(&DAT_018cc3b0,uVar12);
              iVar8 = DAT_01eace60;
              uStack_18 = 0;
              uStack_14 = 0xf;
              auStack_28[0] = 0;
              FUN_005542c0("DiqLimit",8);
              uStack_8._0_1_ = 6;
              FUN_01520d20(auStack_28,iVar8,0);
              FUN_005507b0();
              FUN_0151f7f0();
            }
          }
          FUN_005507b0();
        }
        ExceptionList = pvStack_10;
        return DAT_01d5a0b8;
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 6649 ; VA 0x006191b0 ; FUN_006191b0 */

void __thiscall
FUN_006191b0(int param_1,undefined4 param_2,uint param_3,int *param_4,ushort param_5)

{
  int *piVar1;
  char cVar2;
  undefined4 ****ppppuVar3;
  uint uVar4;
  undefined auStack_50 [8];
  undefined4 uStack_48;
  undefined4 uStack_38;
  undefined4 ***apppuStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179dd60;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_006ab8e0(apppuStack_28,param_2);
  if (*(int *)(param_1 + 0x1dc4) == 0) {
LAB_00619290:
    if (0xf < uStack_14) {
      uVar4 = uStack_14 + 1;
      ppppuVar3 = (undefined4 ****)apppuStack_28[0];
      if (0xfff < uVar4) {
        ppppuVar3 = (undefined4 ****)apppuStack_28[0][-1];
        uVar4 = uStack_14 + 0x24;
        if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar3,uVar4);
    }
    ExceptionList = pvStack_10;
    return;
  }
  FUN_006ab530();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_006ae570(param_3);
  piVar1 = param_4;
  FUN_006b92d0(auStack_50,param_4);
  param_3 = (uint)param_5;
  FUN_006a5c10(&param_3,&param_2,2);
  FUN_006ad5e0(&param_2,2);
  ppppuVar3 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar3 = (undefined4 ****)apppuStack_28[0];
  }
  if ((*piVar1 != -1) && (param_5 != DAT_018db184)) {
    cVar2 = FUN_00686380(ppppuVar3,uStack_18,uStack_48,uStack_38);
    if (cVar2 != '\0') {
      FUN_00613200();
      goto LAB_00619290;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Bytecode Auth Check Failed.");
}



/* FUNCTION 6650 ; VA 0x006192f0 ; FUN_006192f0 */

void FUN_006192f0(uint param_1,undefined4 param_2)

{
  int iVar1;
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179bb60;
  pvStack_10 = ExceptionList;
  if (param_1 < DAT_01d59ef4) {
    return;
  }
  ExceptionList = &pvStack_10;
  if (DAT_01eace68 != 0) {
    ExceptionList = &pvStack_10;
    FUN_0151f6f0(0xffffffff,0,0);
    uStack_8 = 0;
    FUN_0151fa60("Count",param_1);
    FUN_0151f850(&DAT_018bf030,param_2);
    iVar1 = DAT_01eace68;
    FUN_0054eff0("ReplicatorVariantCountLimit");
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_01520d20(auStack_28,iVar1,0);
    FUN_005507b0();
    uStack_8 = 0xffffffff;
    FUN_0151f7f0();
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Too many items in %s",param_2);
}



/* FUNCTION 6651 ; VA 0x006193b0 ; FUN_006193b0 */

int __thiscall FUN_006193b0(int param_1,ushort param_2)

{
  if ((uint)param_2 < (uint)((*(int *)(param_1 + 0x5c) - *(int *)(param_1 + 0x58)) / 0x3c)) {
    return *(int *)(param_1 + 0x58) + (uint)param_2 * 0x3c;
  }
  return 0;
}



/* FUNCTION 6652 ; VA 0x006193f0 ; FUN_006193f0 */

uint __thiscall FUN_006193f0(int param_1,uint param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  
  iVar5 = *(int *)(param_1 + 0x1c);
  if (iVar5 == *(int *)(param_1 + 0x20)) {
    return 0;
  }
  if (param_2 != *(uint *)(param_1 + 0x2c)) {
    uVar2 = (param_2 >> 3) + param_2;
    uVar4 = (*(int *)(param_1 + 0x20) - iVar5 >> 3) - 1;
    uVar3 = 0;
    do {
      uVar2 = uVar2 & uVar4;
      puVar1 = (uint *)(iVar5 + uVar2 * 8);
      if (*puVar1 == param_2) goto LAB_00619452;
      if (*puVar1 == *(uint *)(param_1 + 0x2c)) break;
      iVar5 = *(int *)(param_1 + 0x1c);
      uVar2 = uVar2 + 1 + uVar3;
      uVar3 = uVar3 + 1;
    } while (uVar3 <= uVar4);
  }
  puVar1 = (uint *)0x0;
LAB_00619452:
  return -(uint)(puVar1 != (uint *)0x0) & (uint)(puVar1 + 1);
}



/* FUNCTION 6653 ; VA 0x00619470 ; FUN_00619470 */

void __fastcall FUN_00619470(int *param_1)

{
  int *piVar1;
  int *piVar2;
  
  piVar1 = (int *)*param_1;
  piVar2 = (int *)*piVar1;
  *piVar1 = (int)piVar1;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  if (piVar2 != (int *)*param_1) {
    do {
      piVar1 = (int *)*piVar2;
      FUN_00612d60();
      FUN_01674ea0(piVar2,0x20);
      piVar2 = piVar1;
    } while (piVar1 != (int *)*param_1);
  }
  return;
}



/* FUNCTION 6654 ; VA 0x006194b0 ; FUN_006194b0 */

void __fastcall FUN_006194b0(int param_1)

{
  code *pcVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined2 uVar5;
  
  if (*(int *)(param_1 + 0x6c) != 0) {
    piVar2 = (int *)FUN_0054db20();
    pcVar1 = *(code **)(*piVar2 + 0x68);
    FUN_005f70a0();
    FUN_005f7140();
    uVar3 = DAT_01d59f90;
    uVar4 = DAT_01d59f94;
    uVar5 = DAT_01d59f98;
    FUN_005f7170(param_1 + 0x74);
    (*pcVar1)(uVar3,uVar4,uVar5);
  }
  *(undefined *)(param_1 + 0x22) = 0;
  FUN_008a65e0(0,0);
  return;
}



/* FUNCTION 6655 ; VA 0x00619540 ; FUN_00619540 */

void __thiscall FUN_00619540(int *param_1,undefined4 param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179dd70;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  (**(code **)(*param_1 + 0x18c))(param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6656 ; VA 0x00619589 ; Catch_All@00619589 */

void Catch_All_00619589(void)

{
  if (DAT_01ee420a != '\0') {
    FUN_016774b0(DAT_01ee420a,"Exception during cluster out step, request disconnect",0);
  }
  FUN_0062b590(0x106);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6657 ; VA 0x006195c0 ; FUN_006195c0 */

undefined4 __fastcall FUN_006195c0(int param_1)

{
  int iVar1;
  
  if (((*(char *)(param_1 + 0x18fc) != '\0') || (iVar1 = *(int *)(param_1 + 0x18f0), iVar1 == 0)) ||
     (*(int *)(iVar1 + 0x20) != 2)) {
    if (((*(uint *)(param_1 + 0x3808) & 0x2000000) == 0) ||
       ((*(uint *)(param_1 + 0x3808) & 0x20000000) == 0)) {
      iVar1 = *(int *)(param_1 + 0x1a54);
    }
    else {
      iVar1 = *(int *)(param_1 + 0x1a24);
    }
    if (iVar1 == 0) {
      return 0;
    }
  }
  return CONCAT31((int3)((uint)iVar1 >> 8),1);
}



/* FUNCTION 6658 ; VA 0x00619630 ; FUN_00619630 */

undefined FUN_00619630(byte *param_1,undefined *param_2,int *param_3)

{
  uint uVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined *puVar5;
  undefined4 *puVar6;
  uint *puVar7;
  int iVar8;
  byte *pbVar9;
  int *piVar10;
  undefined auStack_58 [32];
  uint uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined uStack_12;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  pbVar9 = param_1;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179dda8;
  pvStack_10 = ExceptionList;
  uStack_11 = 1;
  uVar2 = 1;
  if ((param_1 == (byte *)0x0) ||
     (iVar8 = *(int *)(param_1 + 0xc), ExceptionList = &pvStack_10, iVar3 = FUN_00ae6b40(),
     uVar2 = uStack_11,
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    ExceptionList = pvStack_10;
    return uVar2;
  }
  uVar4 = FUN_0170d75d(pbVar9,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::Animator::RTTI_Type_Descriptor,0);
  FUN_0060dcd0(auStack_20,uVar4);
  iStack_8 = 0;
  if (((int *)*param_3 != (int *)param_3[1]) &&
     (iVar8 = *(int *)*param_3, iVar3 = FUN_0088d190(), iVar8 == iVar3)) {
    iVar8 = (int)piStack_18 + *(byte *)(piStack_18 + 0x7ac) + 0x1eb1;
    FUN_00606ea0(&piStack_18,pbVar9 + ((uint)pbVar9 >> 3),&param_1,-(uint)(iVar8 != 0) & iVar8 + 1U)
    ;
    if (piStack_18 == (int *)0x0) {
      FUN_005693e0(0xb,&uStack_12,&uStack_12,&uStack_12);
      iStack_8._0_1_ = 1;
      FUN_00601f80(auStack_20,&uStack_38);
      puVar5 = auStack_58;
      iStack_8._0_1_ = 2;
      FUN_00614ba0(&param_1);
      FUN_006023d0(puVar5);
      FUN_00611e50();
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_00612010();
    }
    iVar8 = FUN_00614ba0(&param_1);
    param_1 = (byte *)(iVar8 + 0xc);
    piVar10 = (int *)*param_3;
    iVar8 = *piVar10;
    piStack_18 = piVar10;
    iVar3 = FUN_0088d190();
    if (iVar8 != iVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    piVar10 = piVar10 + 2;
    if (piStack_18[1] == 0) {
      piVar10 = (int *)0x0;
    }
    if (*(int *)(param_1 + 8) <= DAT_01d59e04) {
      pbVar9 = param_1 + *param_1 + 1;
      uVar4 = FUN_009cc8a0(piVar10);
      FUN_00607080(&piStack_18,uVar4,piVar10,-(uint)(pbVar9 != (byte *)0x0) & (uint)(pbVar9 + 1));
      if (piStack_18 == (int *)0x0) {
        uStack_38 = uStack_38 & 0xffffff00;
        uStack_24 = 0;
        uStack_34 = 0;
        uStack_30 = 0;
        uStack_2c = 0;
        uStack_28 = 0;
        iVar8 = FUN_00614330(piVar10);
        uStack_11 = 0;
        *(uint *)(iVar8 + 0x18) = uStack_38;
        *(undefined4 *)(iVar8 + 0x1c) = uStack_34;
        *(undefined4 *)(iVar8 + 0x20) = uStack_30;
        *(undefined4 *)(iVar8 + 0x24) = uStack_2c;
        *(ulonglong *)(iVar8 + 0x28) = CONCAT44(uStack_24,uStack_28);
      }
      iVar8 = FUN_00614330(piVar10);
      if (param_2 == &DAT_021291e0) {
        puVar5 = (undefined *)FUN_00605c60();
        *(undefined *)(iVar8 + 0x18) = *puVar5;
        puVar6 = (undefined4 *)FUN_00605b70();
        *(undefined4 *)(iVar8 + 0x1c) = *puVar6;
        puVar6 = (undefined4 *)FUN_00605b70();
        *(undefined4 *)(iVar8 + 0x20) = *puVar6;
        puVar6 = (undefined4 *)FUN_00605b70();
        *(undefined4 *)(iVar8 + 0x24) = *puVar6;
        puVar6 = (undefined4 *)FUN_00605b70();
        *(undefined4 *)(iVar8 + 0x28) = *puVar6;
        puVar7 = (uint *)FUN_0055d5e0();
        uVar1 = *puVar7;
        *(uint *)(iVar8 + 0x2c) = *(uint *)(iVar8 + 0x2c) | uVar1;
        if ((uVar1 == 1) && (*(char *)(iVar8 + 0x18) == '\x01')) {
          *(undefined4 *)(iVar8 + 0x2c) = 1;
        }
        uStack_11 = 0;
      }
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return uStack_11;
    }
    if (DAT_01ee420a != '\0') {
      FUN_01677520(DAT_01ee420a,"Limiting Animation Track, total tracks attempted %zu",
                   *(int *)(param_1 + 8));
    }
    if (DAT_01ead115 == '\0') {
      FUN_0151f6f0(0xffffffff,0,0);
      iStack_8._0_1_ = 3;
      FUN_0151f950("ContentIdOverLimit",piVar10);
      uVar4 = DAT_01eace4c;
      uStack_28 = 0;
      uStack_24 = 0xf;
      uStack_38 = uStack_38 & 0xffffff00;
      FUN_005542c0("AnimationSpamRecipent",0x15);
      iStack_8 = CONCAT31(iStack_8._1_3_,4);
      FUN_01520d20(&uStack_38,uVar4,0);
      FUN_005507b0();
      DAT_01ead115 = '\x01';
      FUN_0151f7f0();
    }
  }
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar8 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar10 = piStack_1c + 2;
      iVar8 = *piVar10;
      *piVar10 = *piVar10 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 6659 ; VA 0x006199a0 ; FUN_006199a0 */

uint FUN_006199a0(byte *param_1,byte *param_2,uint param_3)

{
  uint uVar1;
  bool bVar2;
  
  if (param_3 == 0) {
    return 0;
  }
  uVar1 = param_3 - 4;
  if (3 < param_3) {
    do {
      if (*(int *)param_1 != *(int *)param_2) goto LAB_006199d6;
      param_1 = param_1 + 4;
      param_2 = param_2 + 4;
      bVar2 = 3 < uVar1;
      uVar1 = uVar1 - 4;
    } while (bVar2);
  }
  if (uVar1 != 0xfffffffc) {
LAB_006199d6:
    bVar2 = *param_1 < *param_2;
    if ((*param_1 != *param_2) ||
       ((uVar1 != 0xfffffffd &&
        ((bVar2 = param_1[1] < param_2[1], param_1[1] != param_2[1] ||
         ((uVar1 != 0xfffffffe &&
          ((bVar2 = param_1[2] < param_2[2], param_1[2] != param_2[2] ||
           ((uVar1 != 0xffffffff && (bVar2 = param_1[3] < param_2[3], param_1[3] != param_2[3]))))))
         )))))) {
      return -(uint)bVar2 | 1;
    }
  }
  return 0;
}



/* FUNCTION 6660 ; VA 0x00619a10 ; FUN_00619a10 */

void FUN_00619a10(int *param_1,undefined4 param_2,uint param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined **ppuVar6;
  undefined **ppuVar7;
  undefined4 *puVar8;
  char cVar9;
  undefined4 *puVar10;
  undefined4 auStack_70 [2];
  uint uStack_68;
  int iStack_64;
  uint uStack_60;
  int iStack_5c;
  uint uStack_48;
  int iStack_44;
  undefined auStack_30 [4];
  undefined *puStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ddd0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = (**(code **)(*param_1 + 8))();
  uVar2 = FUN_00abce10(uVar1);
  uVar3 = FUN_01674e20(uVar2);
  uStack_8 = 0;
  uStack_18 = uVar3;
  uVar4 = (**(code **)(*param_1 + 4))();
  uVar2 = FUN_00ab2ec0(uVar3,uVar2,uVar4,uVar1,param_3 & 0xff);
  iVar5 = FUN_00abd960(uVar2);
  if (iVar5 != 0) {
    auStack_70[0] = 0x40;
    iVar5 = GlobalMemoryStatusEx(auStack_70);
    if ((iVar5 != 0) && (DAT_01ee420a != '\0')) {
      FUN_01677520(DAT_01ee420a,
                   "out of Memory in compressBitStream, total server RAM %u MB, free server ram %u MB, Virtual address space for this process %u MB"
                   ,uStack_68 >> 0x14 | iStack_64 << 0xc,uStack_60 >> 0x14 | iStack_5c << 0xc,
                   uStack_48 >> 0x14 | iStack_44 << 0xc);
    }
    auStack_30[0] = 0;
    param_3 = 0xb;
    ppuVar6 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_3);
    ppuVar7 = ppuVar6 + -1;
    if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar7 = ppuVar6;
    }
    puStack_2c = *ppuVar7;
    iStack_28 = 0;
    uStack_24 = 0x3f800000;
    uStack_20 = 0;
    iStack_1c = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_01533d90(auStack_30);
    cVar9 = DAT_01ee420a;
    if (iStack_28 == 0) {
      puVar10 = (undefined4 *)0x0;
    }
    else {
      puVar10 = *(undefined4 **)(iStack_1c + (int)puStack_2c * 4);
    }
    for (; puVar10 != (undefined4 *)0x0; puVar10 = (undefined4 *)*puVar10) {
      if (cVar9 != '\0') {
        puVar8 = puVar10 + 2;
        if (0xf < (uint)puVar10[7]) {
          puVar8 = (undefined4 *)puVar10[2];
        }
        FUN_01677520(cVar9,"memory used %4d MB in catagory %s",(uint)puVar10[8] >> 0x14,puVar8);
        cVar9 = DAT_01ee420a;
      }
    }
    uStack_8 = uStack_8 & 0xffffff00;
    FUN_005d1280();
  }
  iVar5 = FUN_00abd960(uVar2);
  if (iVar5 != 0) {
    uVar1 = FUN_00abd740(uVar2);
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("zstd_compressed returned error %s",uVar1);
  }
  param_3 = uVar2;
  FUN_006a5c10(&param_3,auStack_14,4);
  FUN_006ad5e0(auStack_14,4);
  param_3 = uVar1;
  FUN_006a5c10(&param_3,auStack_14,4);
  FUN_006ad5e0(auStack_14,4);
  FUN_006ad5e0(uVar3,uVar2);
  FUN_01674ea0(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6661 ; VA 0x00619c20 ; FUN_00619c20 */

void FUN_00619c20(undefined4 *param_1)

{
  *param_1 = 0x3f800000;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0x3f800000;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0x3f800000;
  return;
}



/* FUNCTION 6662 ; VA 0x00619c70 ; FUN_00619c70 */

void __fastcall FUN_00619c70(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  if (param_1[1] == 0) {
    *(undefined2 *)(param_1 + 2) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0x2c);
    param_1[1] = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    puVar1[6] = 0;
    puVar1[7] = 0;
    puVar1[8] = 0;
    puVar1[9] = 0;
    puVar1[10] = 0;
    *(undefined *)(param_1 + 2) = 1;
    return;
  }
  if (*(char *)((int)param_1 + 9) != '\0') {
    FUN_00605e10(*param_1,param_1[1] + 8);
    *(undefined *)((int)param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 6663 ; VA 0x00619cd0 ; FUN_00619cd0 */

void __fastcall FUN_00619cd0(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  if (param_1[1] == 0) {
    *(undefined2 *)(param_1 + 2) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0x24);
    param_1[1] = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    *(undefined8 *)(puVar1 + 6) = 0;
    puVar1[8] = 0;
    *(undefined *)(param_1 + 2) = 1;
    return;
  }
  if (*(char *)((int)param_1 + 9) != '\0') {
    FUN_00605eb0(*param_1,param_1[1] + 8);
    *(undefined *)((int)param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 6664 ; VA 0x00619d30 ; FUN_00619d30 */

void __fastcall FUN_00619d30(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  
  iVar2 = *(int *)(param_1 + 4);
  if (iVar2 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_00612010();
      piVar3 = *(int **)(iVar2 + 0x10);
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[1] + -1;
        piVar3[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          piVar1 = piVar3 + 2;
          iVar2 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      *(undefined *)(param_1 + 9) = 0;
    }
    return;
  }
  *(undefined2 *)(param_1 + 8) = 0;
  puVar4 = (undefined4 *)FUN_01674e20(0x2c);
  *(undefined4 **)(param_1 + 4) = puVar4;
  *puVar4 = 0;
  puVar4[1] = 0;
  puVar4[2] = 0;
  puVar4[3] = 0;
  puVar4[4] = 0;
  puVar4[5] = 0;
  puVar4[6] = 0;
  puVar4[7] = 0;
  puVar4[8] = 0;
  puVar4[9] = 0;
  puVar4[10] = 0;
  *(undefined *)(param_1 + 8) = 1;
  return;
}



/* FUNCTION 6665 ; VA 0x00619db0 ; FUN_00619db0 */

void __fastcall FUN_00619db0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  
  if (*(int *)(param_1 + 4) != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      piVar2 = *(int **)(*(int *)(param_1 + 4) + 0x10);
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar3 = piVar2[1] + -1;
        piVar2[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar2)();
          LOCK();
          piVar1 = piVar2 + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piVar2 + 4))();
          }
        }
      }
      *(undefined *)(param_1 + 9) = 0;
    }
    return;
  }
  *(undefined2 *)(param_1 + 8) = 0;
  puVar4 = (undefined4 *)FUN_01674e20(0x14);
  *(undefined4 **)(param_1 + 4) = puVar4;
  *puVar4 = 0;
  puVar4[1] = 0;
  *(undefined8 *)(puVar4 + 2) = 0;
  puVar4[4] = 0;
  *(undefined *)(param_1 + 8) = 1;
  return;
}



/* FUNCTION 6666 ; VA 0x00619e20 ; FUN_00619e20 */

void __fastcall FUN_00619e20(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  if (param_1[1] == 0) {
    *(undefined2 *)(param_1 + 2) = 0;
    puVar1 = (undefined4 *)FUN_00618210(1);
    param_1[1] = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    *(undefined8 *)(puVar1 + 6) = 0;
    puVar1[8] = 0;
    *(undefined *)(param_1 + 2) = 1;
    return;
  }
  if (*(char *)((int)param_1 + 9) != '\0') {
    FUN_005cf430(*param_1,param_1[1] + 8);
    *(undefined *)((int)param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 6667 ; VA 0x00619e80 ; FUN_00619e80 */

void FUN_00619e80(undefined8 *param_1,undefined8 *param_2)

{
  *param_2 = *param_1;
  return;
}



/* FUNCTION 6668 ; VA 0x00619ea0 ; FUN_00619ea0 */

void FUN_00619ea0(undefined2 *param_1,undefined2 *param_2)

{
  *param_2 = *param_1;
  *(undefined *)(param_2 + 1) = *(undefined *)(param_1 + 1);
  return;
}



/* FUNCTION 6669 ; VA 0x00619ec0 ; FUN_00619ec0 */

void FUN_00619ec0(undefined4 param_1)

{
  FUN_00a8df50(param_1);
  return;
}



/* FUNCTION 6670 ; VA 0x00619ed0 ; FUN_00619ed0 */

void FUN_00619ed0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = param_1[1];
  uVar2 = param_1[2];
  uVar3 = param_1[3];
  *param_2 = *param_1;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  param_2[4] = param_1[4];
  return;
}



/* FUNCTION 6671 ; VA 0x00619ef0 ; FUN_00619ef0 */

void FUN_00619ef0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = param_1[1];
  uVar2 = param_1[2];
  uVar3 = param_1[3];
  *param_2 = *param_1;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  uVar1 = param_1[5];
  uVar2 = param_1[6];
  uVar3 = param_1[7];
  param_2[4] = param_1[4];
  param_2[5] = uVar1;
  param_2[6] = uVar2;
  param_2[7] = uVar3;
  uVar1 = param_1[9];
  uVar2 = param_1[10];
  uVar3 = param_1[0xb];
  param_2[8] = param_1[8];
  param_2[9] = uVar1;
  param_2[10] = uVar2;
  param_2[0xb] = uVar3;
  return;
}



/* FUNCTION 6672 ; VA 0x00619f20 ; FUN_00619f20 */

void FUN_00619f20(undefined4 *param_1,undefined4 *param_2)

{
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  param_2[2] = param_1[2];
  param_2[3] = param_1[3];
  return;
}



/* FUNCTION 6673 ; VA 0x00619f50 ; FUN_00619f50 */

void FUN_00619f50(undefined4 param_1)

{
  FUN_00a92cb0(param_1,0xe4078678,0x64078678);
  return;
}



/* FUNCTION 6674 ; VA 0x00619f80 ; FUN_00619f80 */

void FUN_00619f80(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = param_1[1];
  uVar2 = param_1[2];
  uVar3 = param_1[3];
  *param_2 = *param_1;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_1 + 4);
  return;
}



/* FUNCTION 6675 ; VA 0x00619fa0 ; FUN_00619fa0 */

void FUN_00619fa0(undefined4 param_1)

{
  FUN_008866a0(param_1);
  return;
}



/* FUNCTION 6676 ; VA 0x00619fb0 ; FUN_00619fb0 */

void FUN_00619fb0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = param_1[1];
  uVar2 = param_1[2];
  uVar3 = param_1[3];
  *param_2 = *param_1;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  return;
}



/* FUNCTION 6677 ; VA 0x00619fd0 ; FUN_00619fd0 */

void FUN_00619fd0(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar1 = param_1[1];
  uVar2 = param_1[2];
  uVar3 = param_1[3];
  *param_2 = *param_1;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  uVar1 = param_1[5];
  uVar2 = param_1[6];
  uVar3 = param_1[7];
  param_2[4] = param_1[4];
  param_2[5] = uVar1;
  param_2[6] = uVar2;
  param_2[7] = uVar3;
  uVar1 = param_1[9];
  uVar2 = param_1[10];
  uVar3 = param_1[0xb];
  param_2[8] = param_1[8];
  param_2[9] = uVar1;
  param_2[10] = uVar2;
  param_2[0xb] = uVar3;
  *(undefined8 *)(param_2 + 0xc) = *(undefined8 *)(param_1 + 0xc);
  param_2[0xe] = param_1[0xe];
  return;
}



/* FUNCTION 6678 ; VA 0x0061a010 ; FUN_0061a010 */

void FUN_0061a010(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = *param_1;
  *param_2 = iVar2;
  LOCK();
  piVar1 = (int *)(iVar2 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  return;
}



/* FUNCTION 6679 ; VA 0x0061a030 ; FUN_0061a030 */

void FUN_0061a030(undefined4 *param_1,undefined4 *param_2)

{
  *param_2 = *param_1;
  *(undefined2 *)(param_2 + 1) = *(undefined2 *)(param_1 + 1);
  return;
}



/* FUNCTION 6680 ; VA 0x0061a050 ; FUN_0061a050 */

char * FUN_0061a050(undefined4 param_1)

{
  switch(param_1) {
  case 0:
    return "End Item";
  case 1:
    return "Delete Items";
  case 2:
    return "New Items";
  case 3:
    return "Change Property Items";
  case 4:
    return "Marker Items";
  case 5:
  case 6:
  case 9:
  case 0x12:
    return "Other Items";
  case 7:
    return "Event Invocation Items";
  case 8:
    return "Request Character Items";
  case 10:
    return "CFrame Ack Items";
  case 0xb:
    return "Join Data Items";
  case 0xc:
    return "Client Quota Update Items";
  case 0xd:
    return "Stream Data Items";
  case 0xe:
    return "Region Removal Items";
  case 0xf:
    return "Instance Removal Items";
  case 0x10:
    return "Tag Items";
  case 0x11:
    return "Stats Items";
  case 0x13:
    return "Resolve Atomic Tree Items";
  case 0x14:
    return "Streaming Info Items";
  default:
    return "Unknown Items";
  case 0x16:
    return "Join Data Items V2";
  case 0x17:
    return "Stream Terrain Item";
  case 0x18:
    return "Stream Prefetch Info Items";
  }
}



/* FUNCTION 6681 ; VA 0x0061a170 ; FUN_0061a170 */

undefined4 * FUN_0061a170(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  char cVar2;
  int *piVar3;
  code *pcVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined auStack_c [4];
  int *piStack_8;
  
  piVar3 = (int *)FUN_00892e40(param_2);
  if (piVar3 != (int *)0x0) {
    switch(param_3) {
    case 0:
    case 3:
      goto switchD_0061a195_caseD_0;
    case 1:
      pcVar4 = *(code **)(*piVar3 + 4);
      break;
    case 2:
      pcVar4 = *(code **)(*piVar3 + 8);
      break;
    default:
      goto switchD_0061a195_caseD_4;
    }
    cVar2 = (*pcVar4)();
    if (cVar2 != '\0') {
switchD_0061a195_caseD_0:
      puVar5 = (undefined4 *)(**(code **)*piVar3)(auStack_c,param_3);
      iVar6 = puVar5[1];
      uVar1 = *puVar5;
      *param_1 = 0;
      param_1[1] = 0;
      if (iVar6 != 0) {
        LOCK();
        *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
        UNLOCK();
        iVar6 = puVar5[1];
      }
      *param_1 = uVar1;
      param_1[1] = iVar6;
      if (piStack_8 != (int *)0x0) {
        LOCK();
        iVar6 = piStack_8[1] + -1;
        piStack_8[1] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)*piStack_8)();
          LOCK();
          piVar3 = piStack_8 + 2;
          iVar6 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar6 == 1) {
            (**(code **)(*piStack_8 + 4))();
          }
        }
      }
      return param_1;
    }
  }
switchD_0061a195_caseD_4:
  *param_1 = 0;
  param_1[1] = 0;
  return param_1;
}



/* FUNCTION 6682 ; VA 0x0061a240 ; FUN_0061a240 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0061a240(int param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  float10 fVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179dde8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_00618490();
  for (puVar3 = puVar1; puVar3 != puVar1 + param_2 + 1; puVar3 = puVar3 + 1) {
    *puVar3 = 0;
  }
  if (*(int *)(param_1 + 0x14) != 0) {
    puVar1[param_2] = *(undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
    FUN_0061bc00();
  }
  *(int *)(param_1 + 4) = param_2;
  *(undefined4 **)(param_1 + 0x14) = puVar1;
  if (puVar1 == (undefined4 *)0x0) {
    uVar2 = 0;
  }
  else {
    fVar4 = (float10)FUN_01725160((double)*(float *)(param_1 + 0xc) *
                                  ((double)param_2 + (double)(&DAT_018c0d90)[-(param_2 >> 0x1f)]));
    if ((double)fVar4 < _DAT_018c4e98) {
      uVar2 = FUN_016f3eb1();
    }
    else {
      uVar2 = 0xffffffff;
    }
  }
  *(undefined4 *)(param_1 + 0x10) = uVar2;
  FUN_00611100();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6683 ; VA 0x0061a360 ; FUN_0061a360 */

undefined4 __thiscall FUN_0061a360(int *param_1,undefined4 param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179de00;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  (**(code **)(*param_1 + 0x188))(param_2);
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 6684 ; VA 0x0061a3ab ; Catch_All@0061a3ab */

void Catch_All_0061a3ab(void)

{
  if (DAT_01ee420a != '\0') {
    FUN_016774b0(DAT_01ee420a,"Exception during data out step, request disconnect",0);
  }
  FUN_0062b590(0x106);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 6685 ; VA 0x0061a3e0 ; FUN_0061a3e0 */

void FUN_0061a3e0(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x10;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 6686 ; VA 0x0061a420 ; FUN_0061a420 */

void FUN_0061a420(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0xd8;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 6687 ; VA 0x0061a460 ; FUN_0061a460 */

void FUN_0061a460(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x14;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 6688 ; VA 0x0061a4a0 ; FUN_0061a4a0 */

void FUN_0061a4a0(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x58;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 6689 ; VA 0x0061a4e0 ; FUN_0061a4e0 */

void FUN_0061a4e0(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0xc;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 6690 ; VA 0x0061a520 ; FUN_0061a520 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0061a520(undefined4 *param_1,int param_2)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  if (param_2 == 1) {
    if (DAT_01ead26a == '\0') {
      DAT_01ead26a = '\x01';
      DAT_01ead1f4 = 0;
      uRam01ead1f8 = 0;
      DAT_01ead1fc = (undefined4 *)0x0;
      DAT_01ead200 = 0;
      _DAT_01ead214 = 0;
      DAT_01ead204 = _DAT_018ce380;
      _DAT_01ead208 = _UNK_018ce384;
      _DAT_01ead20c = _UNK_018ce388;
      _DAT_01ead210 = _UNK_018ce38c;
    }
    ExceptionList = &pvStack_10;
    FUN_005874f0();
    *param_1 = DAT_01ead1fc;
    DAT_01ead1fc = param_1;
    uStack_8 = 0;
  }
  else {
    if (DAT_01ead26a == '\0') {
      DAT_01ead26a = '\x01';
      DAT_01ead1f4 = 0;
      uRam01ead1f8 = 0;
      DAT_01ead1fc = (undefined4 *)0x0;
      DAT_01ead200 = 0;
      _DAT_01ead214 = 0;
      DAT_01ead204 = _DAT_018ce380;
      _DAT_01ead208 = _UNK_018ce384;
      _DAT_01ead20c = _UNK_018ce388;
      _DAT_01ead210 = _UNK_018ce38c;
    }
    ExceptionList = &pvStack_10;
    FUN_005874f0();
    FUN_0061e1a0(param_1,param_2);
    uStack_8 = 1;
  }
  LOCK();
  uVar1 = DAT_01ead1f4 + 0x80000000;
  UNLOCK();
  uVar2 = uVar1;
  if (((DAT_01ead1f4 & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead1f4)) {
    LOCK();
    DAT_01ead1f4 = uVar1 | 0x40000000;
    UNLOCK();
    uVar2 = DAT_01ead1f4;
    if ((uVar1 >> 0x1e & 1) == 0) {
      uVar3 = FUN_00554e40();
      SetEvent(uVar3);
      uVar2 = DAT_01ead1f4;
    }
  }
  DAT_01ead1f4 = uVar2;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6691 ; VA 0x0061a630 ; FUN_0061a630 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0061a630(undefined4 *param_1,int param_2)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  if (param_2 == 1) {
    if (DAT_01ead269 == '\0') {
      DAT_01ead269 = '\x01';
      DAT_01ead21c = 0;
      uRam01ead220 = 0;
      DAT_01ead224 = (undefined4 *)0x0;
      DAT_01ead228 = 0;
      _DAT_01ead23c = 0;
      DAT_01ead22c = _DAT_018ce370;
      _DAT_01ead230 = _UNK_018ce374;
      _DAT_01ead234 = _UNK_018ce378;
      _DAT_01ead238 = _UNK_018ce37c;
    }
    ExceptionList = &pvStack_10;
    FUN_005874f0();
    *param_1 = DAT_01ead224;
    DAT_01ead224 = param_1;
    uStack_8 = 0;
  }
  else {
    if (DAT_01ead269 == '\0') {
      DAT_01ead269 = '\x01';
      DAT_01ead21c = 0;
      uRam01ead220 = 0;
      DAT_01ead224 = (undefined4 *)0x0;
      DAT_01ead228 = 0;
      _DAT_01ead23c = 0;
      DAT_01ead22c = _DAT_018ce370;
      _DAT_01ead230 = _UNK_018ce374;
      _DAT_01ead234 = _UNK_018ce378;
      _DAT_01ead238 = _UNK_018ce37c;
    }
    ExceptionList = &pvStack_10;
    FUN_005874f0();
    FUN_0061e1a0(param_1,param_2);
    uStack_8 = 1;
  }
  LOCK();
  uVar1 = DAT_01ead21c + 0x80000000;
  UNLOCK();
  uVar2 = uVar1;
  if (((DAT_01ead21c & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead21c)) {
    LOCK();
    DAT_01ead21c = uVar1 | 0x40000000;
    UNLOCK();
    uVar2 = DAT_01ead21c;
    if ((uVar1 >> 0x1e & 1) == 0) {
      uVar3 = FUN_00554e40();
      SetEvent(uVar3);
      uVar2 = DAT_01ead21c;
    }
  }
  DAT_01ead21c = uVar2;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6692 ; VA 0x0061a740 ; FUN_0061a740 */

void FUN_0061a740(int *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179de38;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if (*(int *)(iVar1 + 0x34) < DAT_01ead120) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ead120);
    if (DAT_01ead120 == -1) {
      uStack_8 = 0;
      uVar9 = FUN_0152dab0(&DAT_018c5904,"decompressBitStream",0xffffffff);
      DAT_01ead11c = (undefined4)((ulonglong)uVar9 >> 0x20);
      DAT_01ead118 = (undefined4)uVar9;
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ead120);
    }
  }
  uVar3 = DAT_01ead11c;
  uVar2 = DAT_01ead118;
  uVar9 = FUN_0152d930(DAT_01ead118,DAT_01ead11c);
  uStack_8 = 1;
  uVar4 = FUN_006ace40();
  iVar5 = FUN_006ace40();
  if (uVar4 <= (uint)(param_1[6] - param_1[8])) {
    uVar6 = FUN_01674e20(iVar5);
    iVar8 = param_1[8];
    uStack_8._0_1_ = 2;
    iVar7 = (**(code **)(*param_1 + 4))();
    iVar8 = FUN_00abd0f0(uVar6,iVar5,iVar7 + iVar8,uVar4);
    if (iVar8 == iVar5) {
      FUN_006ab660(uVar4);
      FUN_006ad5e0(uVar6,iVar5);
      if (*(int *)(iVar1 + 0x34) < DAT_01ead130) {
        FUN_016f3809(&DAT_01ead130);
        if (DAT_01ead130 == -1) {
          uStack_8._0_1_ = 3;
          uVar10 = FUN_0152da50(&DAT_018c5904);
          DAT_01ead12c = (undefined4)((ulonglong)uVar10 >> 0x20);
          DAT_01ead128 = (undefined4)uVar10;
          uStack_8._0_1_ = 2;
          FUN_016f37bf(&DAT_01ead130);
        }
      }
      FUN_0152d760(DAT_01ead128,DAT_01ead12c,"%d bytes -> %d bytes",uVar4,iVar5);
      FUN_01674ea0(uVar6);
      uStack_8 = 4;
      FUN_0152dda0(uVar2,uVar3,uVar9);
      ExceptionList = pvStack_10;
      return;
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Expected to decompress %d bytes but got %d instead",iVar5,iVar8);
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Out of bounds when reading %d compressed bytes",uVar4);
}



/* FUNCTION 6693 ; VA 0x0061a940 ; FUN_0061a940 */

undefined __thiscall FUN_0061a940(int param_1,undefined4 param_2)

{
  undefined uVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179de58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_016dee6d(param_1 + 0x1e50);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  uStack_8 = 0;
  if (*(char *)(param_1 + 0x1db8) == '\0') {
    uVar1 = FUN_006d67e0(param_1,param_2);
  }
  else {
    uVar1 = 0;
  }
  uStack_8 = 1;
  iVar2 = FUN_016deec8(param_1 + 0x1e50);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 6694 ; VA 0x0061a9e0 ; FUN_0061a9e0 */

void __fastcall FUN_0061a9e0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  int iVar7;
  
  iVar6 = *(int *)(param_1 + 0x14);
  if (iVar6 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar5 = *(undefined4 **)(iVar6 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar6 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar5;
        iVar6 = puVar5[6];
        if (iVar6 != 0) {
          iVar7 = puVar5[7];
          if (iVar6 != iVar7) {
            do {
              piVar2 = *(int **)(iVar6 + 4);
              if (piVar2 != (int *)0x0) {
                LOCK();
                iVar4 = piVar2[1] + -1;
                piVar2[1] = iVar4;
                UNLOCK();
                if (iVar4 == 0) {
                  (**(code **)*piVar2)();
                  LOCK();
                  iVar4 = piVar2[2] + -1;
                  piVar2[2] = iVar4;
                  UNLOCK();
                  if (iVar4 == 0) {
                    (**(code **)(*piVar2 + 4))();
                  }
                }
              }
              iVar6 = iVar6 + 8;
            } while (iVar6 != iVar7);
            iVar6 = puVar5[6];
          }
          uVar3 = puVar5[8] - iVar6 & 0xfffffff8;
          iVar7 = iVar6;
          if (0xfff < uVar3) {
            iVar7 = *(int *)(iVar6 + -4);
            uVar3 = uVar3 + 0x23;
            if (0x1f < (iVar6 - iVar7) - 4U) goto LAB_0061ab35;
          }
          FUN_01674ea0(iVar7,uVar3);
          puVar5[6] = 0;
          puVar5[7] = 0;
          puVar5[8] = 0;
        }
        piVar2 = (int *)puVar5[5];
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar6 = piVar2[1] + -1;
          piVar2[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            iVar6 = piVar2[2] + -1;
            piVar2[2] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        FUN_01674ea0(puVar5,0x24);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar5 = (undefined4 *)*puVar1;
      } while (puVar5 != (undefined4 *)0x0);
    }
    iVar6 = *(int *)(param_1 + 4) * 4;
    uVar3 = iVar6 + 4;
    iVar7 = *(int *)(param_1 + 0x14);
    iVar4 = iVar7;
    if (0xfff < uVar3) {
      iVar4 = *(int *)(iVar7 + -4);
      uVar3 = iVar6 + 0x27;
      if (0x1f < (iVar7 - iVar4) - 4U) {
LAB_0061ab35:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar3);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6695 ; VA 0x0061ab40 ; FUN_0061ab40 */

void __fastcall FUN_0061ab40(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  undefined4 *puVar9;
  
  iVar6 = *(int *)(param_1 + 0x14);
  if (iVar6 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar9 = *(undefined4 **)(iVar6 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar6 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar9;
        iVar6 = puVar9[10];
        if (iVar6 != 0) {
          if (puVar9[7] != 0) {
            puVar2 = (undefined4 *)(iVar6 + puVar9[6] * 4);
            puVar5 = (undefined4 *)*puVar2;
            do {
              *puVar2 = *puVar5;
              FUN_01674ea0(puVar5,0x10);
              puVar9[7] = puVar9[7] + -1;
              puVar5 = (undefined4 *)*puVar2;
            } while (puVar5 != (undefined4 *)0x0);
            iVar6 = puVar9[10];
          }
          uVar8 = puVar9[6] * 4 + 4;
          iVar7 = iVar6;
          if (0xfff < uVar8) {
            iVar7 = *(int *)(iVar6 + -4);
            uVar8 = puVar9[6] * 4 + 0x27;
            if (0x1f < (iVar6 - iVar7) - 4U) goto LAB_0061ac74;
          }
          FUN_01674ea0(iVar7,uVar8);
          puVar9[10] = 0;
          puVar9[9] = 0;
        }
        piVar3 = (int *)puVar9[4];
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar6 = piVar3[1] + -1;
          piVar3[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piVar3)();
            LOCK();
            iVar6 = piVar3[2] + -1;
            piVar3[2] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*piVar3 + 4))();
            }
          }
        }
        FUN_01674ea0(puVar9,0x2c);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar9 = (undefined4 *)*puVar1;
      } while (puVar9 != (undefined4 *)0x0);
    }
    iVar6 = *(int *)(param_1 + 4) * 4;
    uVar8 = iVar6 + 4;
    iVar7 = *(int *)(param_1 + 0x14);
    iVar4 = iVar7;
    if (0xfff < uVar8) {
      iVar4 = *(int *)(iVar7 + -4);
      uVar8 = iVar6 + 0x27;
      if (0x1f < (iVar7 - iVar4) - 4U) {
LAB_0061ac74:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar8);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6696 ; VA 0x0061ac80 ; FUN_0061ac80 */

void __fastcall FUN_0061ac80(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar3;
        FUN_01674ea0(puVar3,0x14);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar3 = (undefined4 *)*puVar1;
      } while (puVar3 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 6697 ; VA 0x0061ad00 ; FUN_0061ad00 */

int __thiscall FUN_0061ad00(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  
  iVar4 = 0;
  puVar3 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar3;
    piVar1 = (int *)puVar3[5];
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    FUN_01674ea0(puVar3,0x18);
    iVar4 = iVar4 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar3 = (undefined4 *)*param_2;
  } while (puVar3 != param_3);
  return iVar4;
}



/* FUNCTION 6698 ; VA 0x0061ad50 ; FUN_0061ad50 */

int __thiscall FUN_0061ad50(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  
  iVar3 = 0;
  puVar4 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar4;
    FUN_00612010();
    piVar1 = (int *)puVar4[4];
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[1] + -1;
      piVar1[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar2 = piVar1[2] + -1;
        piVar1[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    FUN_01674ea0(puVar4,0x2c);
    iVar3 = iVar3 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar4 = (undefined4 *)*param_2;
  } while (puVar4 != param_3);
  return iVar3;
}



/* FUNCTION 6699 ; VA 0x0061adc0 ; FUN_0061adc0 */

int __thiscall FUN_0061adc0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iVar6;
  
  iVar6 = 0;
  puVar5 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar5;
    uVar1 = puVar5[7];
    if (0xf < uVar1) {
      iVar2 = puVar5[2];
      uVar4 = uVar1 + 1;
      iVar3 = iVar2;
      if (0xfff < uVar4) {
        iVar3 = *(int *)(iVar2 + -4);
        uVar4 = uVar1 + 0x24;
        if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar4);
    }
    puVar5[6] = 0;
    puVar5[7] = 0xf;
    *(undefined *)(puVar5 + 2) = 0;
    FUN_01674ea0(puVar5,0x20);
    iVar6 = iVar6 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar5 = (undefined4 *)*param_2;
  } while (puVar5 != param_3);
  return iVar6;
}



/* FUNCTION 6700 ; VA 0x0061ae50 ; FUN_0061ae50 */

int __thiscall FUN_0061ae50(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_01674ea0(puVar1,0x14);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar1 = (undefined4 *)*param_2;
    iVar2 = iVar2 + 1;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 6701 ; VA 0x0061ae90 ; FUN_0061ae90 */

void FUN_0061ae90(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  int iStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179de88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_01eadc98);
  uStack_8 = 0;
  uStack_1c = uVar3;
  FUN_01255470(9,0,0,0);
  FUN_01255490();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_006b2050(param_1,&iStack_14);
  while (iStack_14 != 0) {
    piStack_18[0x42c] = iStack_14;
    iVar4 = *(int *)(param_1 + 0x20);
    (**(code **)(*piStack_18 + 0x194))(&iStack_24,param_1,iStack_14);
    uStack_8._0_1_ = 2;
    if (iStack_24 != 0) {
      if (DAT_01d59fb8 != '\0') {
        iVar4 = *(int *)(param_1 + 0x20) - iVar4;
        *(float *)(iStack_24 + 0xc) =
             (float)((double)iVar4 + (double)(&DAT_018c0d90)[-(iVar4 >> 0x1f)]);
      }
      piVar2 = *(int **)(param_2 + 4);
      if (*(int **)(param_2 + 8) == piVar2) {
        FUN_00603260(piVar2,&iStack_24);
      }
      else {
        *piVar2 = 0;
        piVar2[1] = 0;
        if (piStack_20 != (int *)0x0) {
          LOCK();
          piStack_20[1] = piStack_20[1] + 1;
          UNLOCK();
        }
        *piVar2 = iStack_24;
        piVar2[1] = (int)piStack_20;
        *(int *)(param_2 + 4) = *(int *)(param_2 + 4) + 8;
      }
    }
    piVar2 = piStack_20;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_20[1] + -1;
      piStack_20[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar4 = *piVar1 + -1;
        *piVar1 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_006b2050(param_1,&iStack_14);
    uVar3 = uStack_1c;
  }
  FUN_01255500();
  uStack_8 = 3;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6702 ; VA 0x0061b020 ; FUN_0061b020 */

undefined4 * __thiscall
FUN_0061b020(undefined4 param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  undefined auStack_20 [4];
  undefined auStack_1c [8];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179deb9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  param_2[1] = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  switch(param_4) {
  case 1:
    uVar2 = FUN_006f6ee0(auStack_1c,param_1,param_3);
    break;
  case 2:
    uVar2 = FUN_006c0d20(auStack_1c,param_1,param_3);
    break;
  case 3:
    uVar2 = FUN_006f5a20(auStack_1c,param_1,param_3);
    break;
  case 4:
    uVar2 = FUN_006faf40(auStack_1c,param_1,param_3);
    break;
  case 5:
  case 6:
    uVar2 = FUN_006fb900(auStack_1c,param_1,param_3);
    break;
  case 7:
    uVar2 = FUN_006f7360(auStack_1c,param_1,param_3);
    break;
  default:
    cVar1 = FUN_005512d0();
    pcVar3 = "Error while deserializing item";
    if (cVar1 == '\0') {
      pcVar3 = "";
    }
    goto LAB_0061b16f;
  case 0xb:
    if (DAT_01d5af48 == '\0') {
      uVar2 = FUN_006c30d0(auStack_1c,param_1,param_3);
      break;
    }
    goto LAB_0061b16a;
  case 0x13:
    uVar2 = FUN_006c13f0(auStack_1c,param_1,param_3);
    break;
  case 0x15:
    uVar2 = FUN_006f64a0(auStack_1c,param_1,param_3);
    break;
  case 0x16:
    if (DAT_01d5af48 == '\0') {
      uVar2 = FUN_006f9b40(auStack_1c,param_1,param_3);
      break;
    }
LAB_0061b16a:
    pcVar3 = "Error while deserializing item";
LAB_0061b16f:
    FUN_00550130(pcVar3);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_20,&DAT_01c17198);
  }
  FUN_005587e0(uVar2);
  FUN_00550b30();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 6703 ; VA 0x0061b1d0 ; FUN_0061b1d0 */

undefined4 __thiscall FUN_0061b1d0(int param_1,int param_2)

{
  uint *puVar1;
  int *piVar2;
  double dVar3;
  char cVar4;
  undefined *puVar5;
  int *piVar6;
  bool bVar7;
  double dVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  short sVar11;
  undefined4 uVar12;
  int iVar13;
  undefined4 *puVar14;
  uint uVar15;
  double dVar16;
  undefined8 uVar17;
  double adStack_c4 [2];
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined8 uStack_a8;
  char cStack_a0;
  int iStack_98;
  undefined auStack_94 [12];
  int iStack_88;
  int iStack_84;
  undefined **appuStack_80 [3];
  int iStack_74;
  undefined4 uStack_70;
  int iStack_6c;
  int iStack_60;
  undefined4 uStack_58;
  int *piStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  double dStack_20;
  char cStack_15;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179df7b;
  pvStack_10 = ExceptionList;
  piStack_28 = *(int **)((int)ThreadLocalStoragePointer + _tls_index * 4);
  puStack_14 = &stack0xfffffea0;
  uStack_44 = (double)CONCAT44(param_1,(undefined4)uStack_44);
  ExceptionList = &pvStack_10;
  puVar5 = &stack0xfffffea0;
  if ((piStack_28[0xd] < DAT_01ead150) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ead150), cVar4 = DAT_01d7ad48,
     puVar5 = puStack_14, DAT_01ead150 == -1)) {
    uStack_8 = 0;
    uVar17 = FUN_0152dab0(&DAT_018c5904,"deserializePacket",0xffffffff);
    uStack_24 = (undefined4)((ulonglong)uVar17 >> 0x20);
    if ((cVar4 != '\0') && (DAT_01d7ad40 != '\0')) {
      FUN_01532a30(uVar17);
    }
    uStack_8 = 0xffffffff;
    DAT_01ead148 = (int)uVar17;
    DAT_01ead14c = uStack_24;
    FUN_016f37bf(&DAT_01ead150);
    puVar5 = puStack_14;
  }
  puStack_14 = puVar5;
  cVar4 = DAT_01d7ad48;
  cStack_15 = DAT_01d7ad48;
  uStack_50 = DAT_01ead148;
  uStack_b0 = DAT_01ead148;
  uStack_4c = DAT_01ead14c;
  uStack_ac = DAT_01ead14c;
  uStack_a8 = FUN_01532c80(DAT_01ead148,DAT_01ead14c);
  uStack_24 = (undefined4)((ulonglong)uStack_a8 >> 0x20);
  uStack_48 = (undefined4)uStack_a8;
  cStack_a0 = cVar4;
  uStack_8 = 1;
  uVar17 = uStack_a8;
  if (piStack_28[0xd] < DAT_01ead160) {
    FUN_016f3809(&DAT_01ead160);
    uVar17 = CONCAT44(uStack_24,uStack_48);
    if (DAT_01ead160 == -1) {
      uStack_8._0_1_ = 2;
      uVar17 = FUN_0152da50(&DAT_018c5904);
      DAT_01ead15c = (undefined4)((ulonglong)uVar17 >> 0x20);
      DAT_01ead158 = (undefined4)uVar17;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01ead160);
      uVar17 = CONCAT44(uStack_24,uStack_48);
    }
  }
  uStack_24 = (undefined4)((ulonglong)uVar17 >> 0x20);
  uStack_48 = (undefined4)uVar17;
  FUN_0152d760(DAT_01ead158,DAT_01ead15c,"ID %d (%d bytes)",**(undefined **)(param_2 + 0x38),
               *(undefined4 *)(param_2 + 0x30));
  iStack_3c = param_2;
  bVar7 = false;
  iStack_38 = 0;
  iStack_34 = 0;
  uStack_30 = 0;
  uStack_8._0_1_ = 3;
  FUN_006ab380(*(undefined4 *)(param_2 + 0x38),*(undefined4 *)(param_2 + 0x30),0);
  uStack_8._0_1_ = 4;
  FUN_006ab660(1);
  uStack_8._0_1_ = 5;
  if (DAT_01ee4215 != '\0') {
    puVar5 = *(undefined **)(param_2 + 0x38);
    FUN_01677490(DAT_01ee4215,
                 "Replicator::deserializePacketAsync() : received packet ID=%d, Type=%d, SubType=%d"
                 ,*puVar5,puVar5[1],puVar5[2]);
  }
  iVar13 = iStack_60;
  cVar4 = **(char **)(param_2 + 0x38);
  if (cVar4 == -0x7d) {
    FUN_0061ae90(appuStack_80,&iStack_38);
    FUN_0062ba20();
    iStack_60 = iStack_60 - iVar13;
    uStack_44 = (double)iStack_60 + (double)(&DAT_018c0d90)[-(iStack_60 >> 0x1f)];
    dStack_20 = uStack_44;
    sVar11 = FUN_017265ed(&uStack_44);
    dVar8 = DAT_018c0d60;
    if (sVar11 < 1) {
      dVar3 = *(double *)(param_1 + 0x6a8);
      dVar16 = dStack_20;
      if (*(char *)(param_1 + 0x6c8) == '\0') {
        dVar16 = (DAT_018c0d60 - dVar3) * *(double *)(param_1 + 0x6b8) + dVar3 * dStack_20;
      }
      *(double *)(param_1 + 0x6b0) = dStack_20;
      *(double *)(param_1 + 0x6b8) = dVar16;
      *(undefined *)(param_1 + 0x6c8) = 0;
      *(double *)(param_1 + 0x6c0) =
           (dVar8 - dVar3) * *(double *)(param_1 + 0x6c0) +
           dVar3 * (dStack_20 - dVar16) * (dStack_20 - dVar16);
    }
  }
  else {
    if (cVar4 != -0x7a) {
      if (cVar4 == -0x73) {
        FUN_006bdf00(&dStack_20,param_1,appuStack_80);
        uStack_8 = CONCAT31(uStack_8._1_3_,8);
        if (((*(uint *)(param_1 + 0x380c) & 2) == 0) || (dStack_20._0_4_ != 0)) {
          FUN_00625d30(&dStack_20);
          bVar7 = true;
        }
        FUN_00550b30();
      }
      goto LAB_0061b3f2;
    }
    if (*(int *)(param_1 + 0x3858) != 0) {
      puVar14 = (undefined4 *)FUN_01674e20(0x1c);
      if (puVar14 == (undefined4 *)0x0) {
        puVar14 = (undefined4 *)0x0;
      }
      else {
        puVar14[1] = 0x1c;
        puVar14[2] = 1;
        puVar14[3] = 0;
        *puVar14 = RBX::Network::DeserializedTouchItemS2::vftable;
        puVar14[4] = 0;
        puVar14[5] = 0;
        puVar14[6] = 0;
      }
      uStack_2c = 0;
      piStack_28 = (int *)0x0;
      FUN_00604960(puVar14,param_2);
      uStack_8._0_1_ = 6;
      FUN_00704450(appuStack_80,param_2,&uStack_2c);
      if (piStack_28 != (int *)0x0) {
        LOCK();
        piStack_28[1] = piStack_28[1] + 1;
        UNLOCK();
      }
      uStack_58 = uStack_2c;
      piStack_54 = piStack_28;
      uStack_8._0_1_ = 7;
      FUN_00603a30(0,&uStack_58);
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      FUN_00550b30();
      FUN_0062ba20();
      iStack_60 = iStack_60 - iVar13;
      adStack_c4[0] = (double)iStack_60 + (double)(&DAT_018c0d90)[-(iStack_60 >> 0x1f)];
      dStack_20 = adStack_c4[0];
      sVar11 = FUN_017265ed(adStack_c4);
      piVar6 = piStack_28;
      dVar8 = DAT_018c0d60;
      if (sVar11 < 1) {
        dVar3 = *(double *)(param_1 + 0x7e0);
        dVar16 = dStack_20;
        if (*(char *)(param_1 + 0x800) == '\0') {
          dVar16 = (DAT_018c0d60 - dVar3) * *(double *)(param_1 + 0x7f0) + dVar3 * dStack_20;
        }
        *(double *)(param_1 + 0x7e8) = dStack_20;
        *(double *)(param_1 + 0x7f0) = dVar16;
        *(undefined *)(param_1 + 0x800) = 0;
        *(double *)(param_1 + 0x7f8) =
             (dVar8 - dVar3) * *(double *)(param_1 + 0x7f8) +
             dVar3 * (dStack_20 - dVar16) * (dStack_20 - dVar16);
      }
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar13 = piStack_28[1] + -1;
        piStack_28[1] = iVar13;
        UNLOCK();
        if (iVar13 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          piVar2 = piVar6 + 2;
          iVar13 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar13 == 1) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
    }
  }
  bVar7 = true;
LAB_0061b3f2:
  uStack_8 = 4;
  if ((!bVar7) || (7 < (uint)(iStack_34 - iStack_38))) {
    iStack_98 = iStack_3c;
    FUN_0060eca0(&iStack_38);
    uStack_8._0_1_ = 0x10;
    FUN_01682800(&iStack_88);
    puVar1 = (uint *)(param_1 + 0x38e4);
    do {
      LOCK();
      uVar15 = *puVar1;
      *puVar1 = *puVar1 | 1;
      UNLOCK();
    } while ((uVar15 & 1) != 0);
    uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
    if (*(int *)(param_1 + 0x38e0) == 0) {
      *(ulonglong *)(param_1 + 0x38e8) = CONCAT44(iStack_84,iStack_88);
    }
    uVar15 = *(uint *)(param_1 + 0x38d8);
    if (uVar15 <= *(int *)(param_1 + 0x38e0) + 1U) {
      FUN_006174f0(1);
      uVar15 = *(uint *)(param_1 + 0x38d8);
    }
    uVar15 = uVar15 - 1 & *(uint *)(param_1 + 0x38dc);
    *(uint *)(param_1 + 0x38dc) = uVar15;
    uVar15 = *(int *)(param_1 + 0x38d8) - 1U & *(int *)(param_1 + 0x38e0) + uVar15;
    iVar13 = *(int *)(param_1 + 0x38d4);
    if (*(int *)(iVar13 + uVar15 * 4) == 0) {
      uVar12 = FUN_01674e20(0x18);
      *(undefined4 *)(*(int *)(param_1 + 0x38d4) + uVar15 * 4) = uVar12;
      iVar13 = *(int *)(param_1 + 0x38d4);
    }
    piVar6 = *(int **)(iVar13 + uVar15 * 4);
    *piVar6 = iStack_98;
    FUN_0060eca0(auStack_94);
    piVar6[4] = iStack_88;
    piVar6[5] = iStack_84;
    *(int *)(param_1 + 0x38e0) = *(int *)(param_1 + 0x38e0) + 1;
    *puVar1 = 0;
    FUN_00577ac0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (iStack_74 != 0) {
    if (0xfff < (uint)(iStack_6c - iStack_74)) {
      if (0x1f < (iStack_74 - *(int *)(iStack_74 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar12 = FUN_0061b93b();
      return uVar12;
    }
    FUN_01674ea0(iStack_74,iStack_6c - iStack_74);
    iStack_74 = 0;
    uStack_70 = 0;
    iStack_6c = 0;
  }
  appuStack_80[0] = RakNet::AbstractBitStream::vftable;
  FUN_00577ac0();
  uVar10 = uStack_48;
  uVar9 = uStack_4c;
  uVar12 = uStack_50;
  uStack_8 = 0x13;
  FUN_0152dda0(uStack_50,uStack_4c,uStack_48,uStack_24);
  if ((cStack_15 != '\0') && (DAT_01d7ad40 != '\0')) {
    FUN_01532d10(uVar12,uVar9,uVar10,uStack_24);
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 6704 ; VA 0x0061b72e ; Catch@0061b72e */

undefined * Catch_0061b72e(void)

{
  int iVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  uVar2 = (**(code **)(**(int **)(unaff_EBP + -0xb0) + 4))();
  FUN_0054eff0(uVar2);
  *(undefined *)(unaff_EBP + -4) = 10;
  *(undefined4 *)(unaff_EBP + -200) = 0;
  *(undefined4 *)(unaff_EBP + -0xc4) = 0xf;
  *(undefined *)(unaff_EBP + -0xd8) = 0;
  FUN_005542c0("Stream",6);
  uVar2 = *(undefined4 *)(unaff_EBP + -0x38);
  iVar1 = *(int *)(unaff_EBP + -0x3c);
  *(undefined *)(unaff_EBP + -4) = 0xb;
  FUN_006217d0(uVar2,unaff_EBP + -0xd8,unaff_EBP + -0x120);
  FUN_005507b0();
  *(undefined *)(unaff_EBP + -4) = 9;
  FUN_005507b0();
  (**(code **)(*(int *)**(undefined4 **)(iVar1 + 0x6c) + 0x60))(uVar2);
  FUN_0062b590(0x104);
  return &LAB_0061b7cd;
}



/* FUNCTION 6705 ; VA 0x0061b7fd ; Catch@0061b7fd */

undefined * Catch_0061b7fd(void)

{
  int iVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  uVar2 = (**(code **)(**(int **)(unaff_EBP + -0xb4) + 4))();
  FUN_0054eff0(uVar2);
  *(undefined *)(unaff_EBP + -4) = 0xc;
  *(undefined4 *)(unaff_EBP + -0xe0) = 0;
  *(undefined4 *)(unaff_EBP + -0xdc) = 0xf;
  *(undefined *)(unaff_EBP + -0xf0) = 0;
  FUN_005542c0("Stream",6);
  uVar2 = *(undefined4 *)(unaff_EBP + -0x38);
  iVar1 = *(int *)(unaff_EBP + -0x3c);
  *(undefined *)(unaff_EBP + -4) = 0xd;
  FUN_006217d0(uVar2,unaff_EBP + -0xf0,unaff_EBP + -0x138);
  FUN_005507b0();
  *(undefined *)(unaff_EBP + -4) = 9;
  FUN_005507b0();
  (**(code **)(*(int *)**(undefined4 **)(iVar1 + 0x6c) + 0x60))(uVar2);
  FUN_0062b590(0x105);
  return &LAB_0061b7cd;
}



/* FUNCTION 6706 ; VA 0x0061b89c ; Catch@0061b89c */

undefined * Catch_0061b89c(void)

{
  int iVar1;
  undefined4 uVar2;
  int unaff_EBP;
  
  uVar2 = (**(code **)(**(int **)(unaff_EBP + -0xb8) + 4))();
  FUN_0054eff0(uVar2);
  *(undefined *)(unaff_EBP + -4) = 0xe;
  *(undefined4 *)(unaff_EBP + -0xf8) = 0;
  *(undefined4 *)(unaff_EBP + -0xf4) = 0xf;
  *(undefined *)(unaff_EBP + -0x108) = 0;
  FUN_005542c0("Other",5);
  uVar2 = *(undefined4 *)(unaff_EBP + -0x38);
  iVar1 = *(int *)(unaff_EBP + -0x3c);
  *(undefined *)(unaff_EBP + -4) = 0xf;
  FUN_006217d0(uVar2,unaff_EBP + -0x108,unaff_EBP + -0x150);
  FUN_005507b0();
  *(undefined *)(unaff_EBP + -4) = 9;
  FUN_005507b0();
  (**(code **)(*(int *)**(undefined4 **)(iVar1 + 0x6c) + 0x60))(uVar2);
  FUN_0062b590(0x104);
  return &LAB_0061b7cd;
}



/* FUNCTION 6707 ; VA 0x0061b93b ; FUN_0061b93b */

undefined __fastcall FUN_0061b93b(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int unaff_EBP;
  
  FUN_01674ea0(param_1,param_2);
  *(undefined4 *)(unaff_EBP + -0x70) = 0;
  *(undefined4 *)(unaff_EBP + -0x6c) = 0;
  *(undefined4 *)(unaff_EBP + -0x68) = 0;
  *(undefined ***)(unaff_EBP + -0x7c) = RakNet::AbstractBitStream::vftable;
  FUN_00577ac0();
  uVar1 = *(undefined4 *)(unaff_EBP + -0x44);
  uVar2 = *(undefined4 *)(unaff_EBP + -0x48);
  uVar3 = *(undefined4 *)(unaff_EBP + -0x4c);
  *(undefined4 *)(unaff_EBP + -4) = 0x13;
  FUN_0152dda0(uVar3,uVar2,uVar1,*(undefined4 *)(unaff_EBP + -0x20));
  if ((*(char *)(unaff_EBP + -0x11) != '\0') && (DAT_01d7ad40 != '\0')) {
    FUN_01532d10(uVar3,uVar2,uVar1,*(undefined4 *)(unaff_EBP + -0x20));
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return 1;
}



/* FUNCTION 6708 ; VA 0x0061ba90 ; FUN_0061ba90 */

/* WARNING: Removing unreachable block (ram,0x0061bb3a) */
/* WARNING: Removing unreachable block (ram,0x0061bb4d) */
/* WARNING: Removing unreachable block (ram,0x0061bb54) */
/* WARNING: Removing unreachable block (ram,0x0061bb5b) */

void __fastcall FUN_0061ba90(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int *piVar4;
  char cVar5;
  undefined4 uVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179df98;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar6 = FUN_01675290(DAT_01eadc98);
  uStack_8 = 0;
  FUN_0152e020("DeserializePackets");
  cVar5 = *(char *)(param_1 + 0x38b8);
  while (cVar5 != '\0') {
    if (*(int *)(param_1 + 0x38c8) == 0) {
      iVar7 = 0;
      if (*(int *)(param_1 + 0x38c0) != 0) {
        FUN_00587410();
        puVar1 = (undefined4 *)(param_1 + 0x38c4);
        puVar2 = (undefined4 *)(param_1 + 0x38bc);
        if (puVar2 != puVar1) {
          uVar3 = *puVar2;
          *puVar2 = *puVar1;
          *puVar1 = uVar3;
          uVar3 = *(undefined4 *)(param_1 + 0x38c0);
          *(undefined4 *)(param_1 + 0x38c0) = *(undefined4 *)(param_1 + 0x38c8);
          *(undefined4 *)(param_1 + 0x38c8) = uVar3;
        }
        iVar7 = *(int *)(param_1 + 0x38c8);
        uStack_8 = uStack_8 & 0xffffff00;
      }
      if (iVar7 != 0) goto LAB_0061bb8a;
      if (*(int *)(param_1 + 0x38c0) == 0) {
        FUN_0151f430();
      }
    }
    else {
LAB_0061bb8a:
      piVar4 = (int *)**(int **)(param_1 + 0x38c4);
      iVar7 = piVar4[2];
      *(int *)piVar4[1] = *piVar4;
      *(int *)(*piVar4 + 4) = piVar4[1];
      *(int *)(param_1 + 0x38c8) = *(int *)(param_1 + 0x38c8) + -1;
      FUN_01674ea0(piVar4,0xc);
      cVar5 = FUN_0061b1d0(iVar7);
      if (cVar5 == '\0') break;
    }
    cVar5 = *(char *)(param_1 + 0x38b8);
  }
  FUN_0152e090();
  uStack_8 = 2;
  FUN_01675290(uVar6);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6709 ; VA 0x0061bc00 ; FUN_0061bc00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_0061bc00(int param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  undefined4 uVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  iVar5 = *(int *)(param_1 + 4) + 1;
  puVar1 = *(undefined4 **)(param_1 + 0x14);
  if (iVar5 == 1) {
    if (DAT_01ead26b == '\0') {
      DAT_01ead26b = '\x01';
      DAT_01ead244 = 0;
      uRam01ead248 = 0;
      DAT_01ead24c = (undefined4 *)0x0;
      DAT_01ead250 = 0;
      _DAT_01ead264 = 0;
      DAT_01ead254 = _DAT_018ce340;
      uRam01ead258 = _UNK_018ce344;
      uRam01ead25c = _UNK_018ce348;
      uRam01ead260 = _UNK_018ce34c;
    }
    ExceptionList = &pvStack_10;
    FUN_005874f0();
    *puVar1 = DAT_01ead24c;
    uStack_8 = 0;
    DAT_01ead24c = puVar1;
  }
  else {
    if (DAT_01ead26b == '\0') {
      DAT_01ead26b = '\x01';
      DAT_01ead244 = 0;
      uRam01ead248 = 0;
      DAT_01ead24c = (undefined4 *)0x0;
      DAT_01ead250 = 0;
      _DAT_01ead264 = 0;
      DAT_01ead254 = _DAT_018ce340;
      uRam01ead258 = _UNK_018ce344;
      uRam01ead25c = _UNK_018ce348;
      uRam01ead260 = _UNK_018ce34c;
    }
    ExceptionList = &pvStack_10;
    FUN_005874f0();
    FUN_0061e1a0(puVar1,iVar5);
    uStack_8 = 1;
  }
  LOCK();
  uVar2 = DAT_01ead244 + 0x80000000;
  UNLOCK();
  uVar3 = uVar2;
  if (((DAT_01ead244 & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead244)) {
    LOCK();
    DAT_01ead244 = uVar2 | 0x40000000;
    UNLOCK();
    uVar3 = DAT_01ead244;
    if ((uVar2 >> 0x1e & 1) == 0) {
      uVar4 = FUN_00554e40();
      SetEvent(uVar4);
      uVar3 = DAT_01ead244;
    }
  }
  DAT_01ead244 = uVar3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6710 ; VA 0x0061bd10 ; FUN_0061bd10 */

void FUN_0061bd10(void)

{
  FUN_00617bc0();
  return;
}



/* FUNCTION 6711 ; VA 0x0061bd20 ; FUN_0061bd20 */

void FUN_0061bd20(void)

{
  FUN_00617ad0();
  return;
}



/* FUNCTION 6712 ; VA 0x0061bd30 ; FUN_0061bd30 */

void FUN_0061bd30(void)

{
  FUN_0056cd30();
  FUN_0056cd30();
  return;
}



/* FUNCTION 6713 ; VA 0x0061bd50 ; FUN_0061bd50 */

void FUN_0061bd50(void)

{
  FUN_0056cd30();
  return;
}



/* FUNCTION 6714 ; VA 0x0061bd60 ; FUN_0061bd60 */

void __fastcall FUN_0061bd60(int param_1)

{
  undefined4 uVar1;
  uint uStack_58;
  uint uStack_54;
  int iStack_50;
  undefined4 uStack_4c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179dfb8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x1a18) != 0) {
    ExceptionList = &pvStack_10;
    FUN_00a6f530(param_1 + 0x68);
  }
  *(undefined4 *)(param_1 + 0x1a18) = 0;
  *(undefined4 *)(param_1 + 0x1dbc) = 0;
  FUN_0170d1f0(&uStack_58,0,0x48);
  uVar1 = FUN_0060ee60();
  uStack_8 = 0;
  FUN_00613da0(uVar1);
  FUN_0061ac80();
  FUN_00610ff0();
  uStack_8 = 1;
  if (iStack_50 != 0) {
    do {
      uStack_54 = (uStack_54 + 1) % uStack_58;
      iStack_50 = iStack_50 + -1;
    } while (iStack_50 != 0);
    iStack_50 = 0;
  }
  FUN_01674ea0(uStack_4c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6715 ; VA 0x0061be30 ; FUN_0061be30 */

undefined * FUN_0061be30(undefined *param_1,int param_2)

{
  char *pcVar1;
  undefined4 uVar2;
  
  if (param_2 < 0x102) {
    if (param_2 == 0x101) {
      uVar2 = 0x68;
      pcVar1 = 
      "Disconnected due to authentication failure. Please upgrade to the latest version of Roblox and reconnect"
      ;
      goto LAB_0061bf37;
    }
    if (param_2 == -1) {
      uVar2 = 0x69;
      pcVar1 = 
      "Developer has shut down all game servers or game server has shut down for other reasons, please reconnect"
      ;
      goto LAB_0061bf37;
    }
switchD_0061be6f_caseD_115:
    uVar2 = 0x28;
    pcVar1 = "Disconnected from game, please reconnect";
  }
  else {
    switch(param_2) {
    case 0x102:
    case 0x110:
      uVar2 = 0x57;
      pcVar1 = 
      "Disconnected due to unsupported version. Please upgrade to the latest version of Roblox";
      break;
    case 0x103:
      uVar2 = 0x23;
      pcVar1 = "Protocol mismatch, please reconnect";
      break;
    case 0x104:
      uVar2 = 0x2c;
      pcVar1 = "Error while receiving data, please reconnect";
      break;
    case 0x105:
      uVar2 = 0x2c;
      pcVar1 = "Error while streaming data, please reconnect";
      break;
    case 0x106:
      uVar2 = 0x2a;
      pcVar1 = "Error while sending data, please reconnect";
      break;
    case 0x107:
      uVar2 = 0x1c;
      pcVar1 = "Invalid teleport destination";
      break;
    case 0x108:
      uVar2 = 0x4d;
      pcVar1 = "You are already playing a game. Please shut down the other game and try again";
      break;
    case 0x109:
      uVar2 = 0x29;
      pcVar1 = "Error processing ticket, please reconnect";
      break;
    case 0x10a:
      uVar2 = 0x28;
      pcVar1 = "Lost connection to server due to timeout";
      break;
    case 0x10b:
      uVar2 = 0x22;
      pcVar1 = "You have been kicked from the game";
      break;
    case 0x10c:
      uVar2 = 0x44;
      pcVar1 = "You have been kicked by server. Please close and rejoin another game";
      break;
    case 0x10d:
      uVar2 = 0x2d;
      pcVar1 = "Disconnected due to timeout, please reconnect";
      break;
    case 0x10e:
      uVar2 = 0x3d;
      pcVar1 = "You have been disconnected from Team Create, please reconnect";
      break;
    case 0x10f:
      uVar2 = 0x30;
      pcVar1 = "You have been kicked by server, please reconnect";
      break;
    case 0x111:
      uVar2 = 0x47;
      pcVar1 = "Disconnected from game, possibly due to game joined from another device";
      break;
    case 0x112:
      uVar2 = 0x38;
      pcVar1 = "Developer has shut down this game server for maintenance";
      break;
    case 0x113:
      uVar2 = 0x35;
      pcVar1 = "Roblox has shut down this game server for maintenance";
      break;
    case 0x114:
      uVar2 = 0x52;
      pcVar1 = "This game has been disconnected because you have joined a game from another device";
      break;
    default:
      goto switchD_0061be6f_caseD_115;
    case 0x11b:
      uVar2 = 0x1b;
      pcVar1 = "Requesting RoMark Reconnect";
    }
  }
LAB_0061bf37:
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0(pcVar1,uVar2);
  return param_1;
}



/* FUNCTION 6716 ; VA 0x0061bfc0 ; FUN_0061bfc0 */

undefined * FUN_0061bfc0(undefined *param_1,undefined4 param_2)

{
  char *pcVar1;
  undefined4 uVar2;
  
  switch(param_2) {
  case 0x101:
    uVar2 = 7;
    pcVar1 = "BadHash";
    break;
  case 0x102:
    uVar2 = 0x13;
    pcVar1 = "SecurityKeyMismatch";
    break;
  case 0x103:
    uVar2 = 0x10;
    pcVar1 = "ProtocolMismatch";
    break;
  case 0x104:
    uVar2 = 0x12;
    pcVar1 = "ReceivePacketError";
    break;
  case 0x105:
    uVar2 = 0x18;
    pcVar1 = "ReceivePacketStreamError";
    break;
  case 0x106:
    uVar2 = 0xf;
    pcVar1 = "SendPacketError";
    break;
  case 0x107:
    uVar2 = 0xf;
    pcVar1 = "IllegalTeleport";
    break;
  case 0x108:
    uVar2 = 0xf;
    pcVar1 = "DuplicatePlayer";
    break;
  case 0x109:
    uVar2 = 0xf;
    pcVar1 = "DuplicateTicket";
    break;
  case 0x10a:
    uVar2 = 7;
    pcVar1 = "TimeOut";
    break;
  case 0x10b:
    uVar2 = 7;
    pcVar1 = "LuaKick";
    break;
  case 0x10c:
    uVar2 = 0x10;
    pcVar1 = "OnRemoteSysStats";
    break;
  case 0x10d:
    uVar2 = 10;
    pcVar1 = "MagicDisco";
    break;
  case 0x10e:
    uVar2 = 0xd;
    pcVar1 = "CloudEditKick";
    break;
  case 0x10f:
    uVar2 = 10;
    pcVar1 = "Playerless";
    break;
  case 0x110:
    uVar2 = 0x16;
    pcVar1 = "NewSecurityKeyMismatch";
    break;
  case 0x111:
    uVar2 = 7;
    pcVar1 = "Evicted";
    break;
  case 0x112:
    uVar2 = 0xe;
    pcVar1 = "DevMaintenance";
    break;
  case 0x113:
    uVar2 = 0xd;
    pcVar1 = "RoMaintenance";
    break;
  case 0x114:
    uVar2 = 6;
    pcVar1 = "Rejoin";
    break;
  default:
    uVar2 = 4;
    pcVar1 = "none";
    break;
  case 0x119:
    uVar2 = 0xe;
    pcVar1 = "SecurityPolicy";
    break;
  case 0x11a:
    uVar2 = 9;
    pcVar1 = "BlockedIP";
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  FUN_005542c0(pcVar1,uVar2);
  return param_1;
}



/* FUNCTION 6717 ; VA 0x0061c150 ; FUN_0061c150 */

char __thiscall FUN_0061c150(int param_1,int *param_2)

{
  char cVar1;
  
  if (*param_2 == 0) {
    return '\0';
  }
  cVar1 = '\0';
  if (*(char *)(param_1 + 0x1db8) == '\0') {
    cVar1 = FUN_006d7910(param_1,param_2);
    if ((cVar1 != '\0') && (*param_2 == *(int *)(param_1 + 0x1a18))) {
      FUN_0061bd60();
    }
  }
  return cVar1;
}



/* FUNCTION 6718 ; VA 0x0061c1a0 ; FUN_0061c1a0 */

void FUN_0061c1a0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined *puVar3;
  undefined8 uVar4;
  undefined auStack_60 [40];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  int iStack_28;
  int *piStack_24;
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_0179e00c;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff94;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar3 = &stack0xffffff94;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead140) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ead140);
    puVar3 = puStack_14;
    if (DAT_01ead140 == -1) {
      iStack_8._0_1_ = 1;
      uVar4 = FUN_0152dab0(&DAT_018c5904,"ParallelPhysicsReceive",0xffffffff);
      DAT_01ead13c = (undefined4)((ulonglong)uVar4 >> 0x20);
      DAT_01ead138 = (undefined4)uVar4;
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_016f37bf(&DAT_01ead140);
      puVar3 = puStack_14;
    }
  }
  puStack_14 = puVar3;
  uStack_38 = DAT_01ead138;
  uStack_34 = DAT_01ead13c;
  uStack_30 = FUN_0152d930(DAT_01ead138,DAT_01ead13c);
  FUN_00587490(&iStack_28);
  iStack_8._0_1_ = 3;
  if (iStack_28 != 0) {
    piStack_1c = *(int **)(iStack_28 + 0x1920);
    piVar1 = *(int **)(iStack_28 + 0x191c);
    piStack_18 = piVar1;
    if (piVar1 != piStack_1c) {
      FUN_006ab380(*(undefined4 *)(*piVar1 + 0x38),*(undefined4 *)(*piVar1 + 0x30),0);
      iStack_8._0_1_ = 4;
      FUN_006ab660(0x11);
      FUN_006abe40();
      iStack_8 = CONCAT31(iStack_8._1_3_,5);
      FUN_00705990(auStack_60,piVar1[2],piVar1[3]);
      FUN_0061c2c7();
      return;
    }
    *(undefined4 *)(iStack_28 + 0x1920) = *(undefined4 *)(iStack_28 + 0x191c);
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_24[1] + -1;
    piStack_24[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  iStack_8 = CONCAT31(iStack_8._1_3_,7);
  FUN_0152dda0(uStack_38,uStack_34,uStack_30);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_2 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6719 ; VA 0x0061c281 ; Catch@0061c281 */

undefined * Catch_0061c281(void)

{
  undefined uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int unaff_EBP;
  
  if (DAT_01ee420a != '\0') {
    uVar2 = *(undefined4 *)(**(int **)(unaff_EBP + -0x14) + 0x34);
    uVar1 = **(undefined **)(**(int **)(unaff_EBP + -0x14) + 0x38);
    uVar3 = (**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))();
    FUN_01677520(DAT_01ee420a,
                 "Error while (parallel) processing physics packet (ignored): %s (Packet size: %d, packet type: %d)\n"
                 ,uVar3,uVar2,uVar1);
  }
  return &DAT_0061c2be;
}



/* FUNCTION 6720 ; VA 0x0061c2c7 ; FUN_0061c2c7 */

void FUN_0061c2c7(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int *unaff_EBX;
  int unaff_EBP;
  undefined4 *unaff_ESI;
  int *piVar8;
  int unaff_EDI;
  
  puVar3 = *(undefined4 **)(unaff_EDI + 0x6c);
  uVar4 = *unaff_ESI;
  *(undefined4 *)(unaff_EBP + -4) = 4;
  (**(code **)(*(int *)*puVar3 + 0x60))(uVar4);
  iVar5 = *(int *)(unaff_EBP + -0x50);
  *(undefined *)(unaff_EBP + -4) = 3;
  if (iVar5 != 0) {
    uVar7 = *(int *)(unaff_EBP + -0x48) - iVar5;
    iVar6 = iVar5;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(iVar5 + -4);
      uVar7 = uVar7 + 0x23;
      if (0x1f < (iVar5 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar7);
  }
  piVar8 = unaff_ESI + 4;
  *(int **)(unaff_EBP + -0x14) = piVar8;
  if (piVar8 != unaff_EBX) {
    FUN_006ab380(*(undefined4 *)(*piVar8 + 0x38),*(undefined4 *)(*piVar8 + 0x30),0);
    *(undefined *)(unaff_EBP + -4) = 4;
    FUN_006ab660(0x11);
    FUN_006abe40();
    uVar4 = unaff_ESI[7];
    uVar2 = unaff_ESI[6];
    *(undefined *)(unaff_EBP + -4) = 5;
    FUN_00705990(unaff_EBP + -0x5c,uVar2,uVar4);
    FUN_0061c2c7();
    return;
  }
  *(undefined4 *)(unaff_EDI + 0x1920) = *(undefined4 *)(unaff_EDI + 0x191c);
  piVar8 = *(int **)(unaff_EBP + -0x20);
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar5 = piVar8[1] + -1;
    piVar8[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      iVar5 = piVar8[2] + -1;
      piVar8[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  *(undefined *)(unaff_EBP + -4) = 7;
  FUN_0152dda0(*(undefined4 *)(unaff_EBP + -0x34),*(undefined4 *)(unaff_EBP + -0x30),
               *(undefined4 *)(unaff_EBP + -0x2c),*(undefined4 *)(unaff_EBP + -0x28));
  piVar8 = *(int **)(unaff_EBP + 0xc);
  if (piVar8 != (int *)0x0) {
    LOCK();
    piVar1 = piVar8 + 2;
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      (**(code **)(*piVar8 + 4))();
    }
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 6721 ; VA 0x0061c3f0 ; FUN_0061c3f0 */

int FUN_0061c3f0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int *param_5,
                undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  code *pcVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179e030;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  pcVar3 = *(code **)(param_1 + 0x18);
  uStack_8 = 1;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  iVar4 = (*pcVar3)(param_2,param_3,param_4,param_5,param_6);
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 6722 ; VA 0x0061c4c0 ; FUN_0061c4c0 */

void __thiscall FUN_0061c4c0(byte *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  undefined4 *puVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  uint uVar10;
  undefined4 *puVar11;
  int aiStack_c [2];
  
  iVar9 = *(int *)(param_3 + 4);
  iVar6 = FUN_005702d0(iVar9 + 8);
  uVar7 = iVar6 + 0x9e3779b9;
  uVar7 = uVar7 * 0x40 + *(int *)(iVar9 + 0x20) + (*(uint *)(iVar9 + 0x20) >> 3) +
          (uVar7 >> 2) + 0x9e3779b9 ^ uVar7;
  FUN_00606f30(aiStack_c,uVar7,iVar9 + 8,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (aiStack_c[0] == 0) {
    uVar3 = *(uint *)(param_1 + 8);
    uVar8 = uVar3 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar8 = FUN_005c9310(uVar8);
      if (uVar8 <= *(uint *)(param_1 + 4)) {
        uVar8 = *(uint *)(param_1 + 4);
      }
      FUN_0061a240(uVar8);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar8) {
      uVar10 = uVar3 >> 1;
      if (uVar10 + uVar3 <= uVar8) {
        uVar10 = 1;
      }
      iVar9 = FUN_005c9310(uVar10 + uVar3);
      if (iVar9 != *(int *)(param_1 + 4)) {
        FUN_0061a240(iVar9);
        puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
        puVar4 = (undefined4 *)*puVar11;
        while (puVar4 != (undefined4 *)0x0) {
          piVar1 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4
                          );
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *(uint *)(param_1 + 4)) * 4) ==
              0) {
            *piVar1 = (int)puVar11;
            puVar11 = puVar4;
          }
          else {
            *puVar11 = *puVar4;
            *puVar4 = *(undefined4 *)*piVar1;
            *(undefined4 **)*piVar1 = puVar4;
          }
          puVar4 = (undefined4 *)*puVar11;
        }
      }
    }
    piVar5 = *(int **)(param_3 + 4);
    *(undefined4 *)(param_3 + 4) = 0;
    piVar5[1] = uVar7;
    uVar7 = uVar7 % *(uint *)(param_1 + 4);
    puVar11 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    piVar1 = (int *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (puVar11 == (undefined4 *)0x0) {
      piVar2 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar2 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 4)) * 4)
             = piVar5;
      }
      *piVar1 = (int)piVar2;
      *piVar5 = *piVar2;
      *piVar2 = (int)piVar5;
    }
    else {
      *piVar5 = *puVar11;
      *(int **)*piVar1 = piVar5;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *(undefined *)(param_2 + 1) = 1;
    *param_2 = (int)piVar5;
    return;
  }
  *(undefined *)(param_2 + 1) = 0;
  *param_2 = aiStack_c[0];
  return;
}



/* FUNCTION 6723 ; VA 0x0061c640 ; FUN_0061c640 */

void __fastcall FUN_0061c640(uint param_1)

{
  int *piVar1;
  uint *puVar2;
  undefined3 uVar3;
  char cVar4;
  uint *puVar5;
  int iVar6;
  int iVar7;
  undefined4 *puVar8;
  uint uVar9;
  undefined **ppuVar10;
  int *piVar11;
  undefined8 uVar12;
  undefined4 uVar13;
  uint *puStack_114;
  int **ppiStack_110;
  uint auStack_d8 [2];
  int aiStack_d0 [6];
  uint auStack_b8 [2];
  int aiStack_b0 [6];
  undefined **appuStack_98 [2];
  int aiStack_90 [6];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  int *piStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  int *piStack_5c;
  int iStack_58;
  undefined uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  uint *puStack_3c;
  char cStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e0c7;
  pvStack_10 = ExceptionList;
  piStack_14 = (int *)0x0;
  piStack_20 = (int *)0x0;
  iStack_18 = param_1;
  if (DAT_01d5a038 == '\0') {
    puStack_3c = (uint *)(param_1 + 0x38b0);
    cStack_38 = '\0';
    ppiStack_110 = (int **)0x61c936;
    ExceptionList = &pvStack_10;
    FUN_00587410();
    ppiStack_110 = (int **)0x4;
    uStack_8 = 3;
    *(undefined *)(param_1 + 0x38b8) = 1;
    puStack_114 = (uint *)0x61c94b;
    piStack_24 = (int *)FUN_01674e20();
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (piStack_24 == (int *)0x0) {
      piVar11 = (int *)0x0;
    }
    else {
      FUN_0060dcd0(&puStack_114,param_1);
      FUN_006058b0(&uStack_4c,FUN_0061ba90,0);
      piVar11 = piStack_40;
      uStack_68 = uStack_4c;
      uStack_64 = uStack_48;
      if ((uint *)piStack_40 != (uint *)0x0) {
        LOCK();
        piStack_40[1] = piStack_40[1] + 1;
        UNLOCK();
      }
      uStack_60 = uStack_44;
      piStack_5c = piStack_40;
      appuStack_98[0] = (undefined **)0x0;
      uStack_78 = uStack_4c;
      uStack_74 = uStack_48;
      if ((uint *)piStack_40 != (uint *)0x0) {
        LOCK();
        piStack_40[1] = piStack_40[1] + 1;
        UNLOCK();
      }
      ppiStack_110 = (int **)aiStack_90;
      uStack_70 = uStack_44;
      piStack_6c = piStack_40;
      if ((uint *)piStack_40 != (uint *)0x0) {
        LOCK();
        piStack_40[1] = piStack_40[1] + 1;
        UNLOCK();
      }
      ppuVar10 = &PTR_FUN_018ce2e0;
      puStack_114 = (uint *)piStack_40;
      cVar4 = FUN_00605370(uStack_4c,uStack_48,uStack_44);
      if (cVar4 == '\0') {
        ppuVar10 = (undefined **)0x0;
      }
      appuStack_98[0] = ppuVar10;
      if ((uint *)piVar11 != (uint *)0x0) {
        LOCK();
        uVar9 = piVar11[1] - 1;
        piVar11[1] = uVar9;
        UNLOCK();
        if (uVar9 == 0) {
          ppiStack_110 = (int **)0x61ca1f;
          (**(code **)*piVar11)();
          LOCK();
          uVar9 = piVar11[2] - 1;
          piVar11[2] = uVar9;
          UNLOCK();
          if (uVar9 == 0) {
            ppiStack_110 = (int **)0x61ca2f;
            (**(code **)(*piVar11 + 4))();
          }
        }
        if ((uint *)piVar11 != (uint *)0x0) {
          LOCK();
          uVar9 = piVar11[1] - 1;
          piVar11[1] = uVar9;
          UNLOCK();
          if (uVar9 == 0) {
            ppiStack_110 = (int **)0x61ca42;
            (**(code **)*piVar11)();
            LOCK();
            uVar9 = piVar11[2] - 1;
            piVar11[2] = uVar9;
            UNLOCK();
            if (uVar9 == 0) {
              ppiStack_110 = (int **)0x61ca52;
              (**(code **)(*piVar11 + 4))();
            }
          }
        }
      }
      if ((uint *)piStack_40 != (uint *)0x0) {
        LOCK();
        uVar9 = piStack_40[1] - 1;
        piStack_40[1] = uVar9;
        UNLOCK();
        if (uVar9 == 0) {
          ppiStack_110 = (int **)0x61ca68;
          (**(code **)*piStack_40)();
          LOCK();
          uVar9 = piStack_40[2] - 1;
          piStack_40[2] = uVar9;
          UNLOCK();
          if (uVar9 == 0) {
            ppiStack_110 = (int **)0x61ca78;
            (**(code **)(*piStack_40 + 4))();
          }
        }
      }
      ppiStack_110 = (int **)0x18cc930;
      puStack_114 = (uint *)appuStack_98;
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      piStack_14 = (int *)0x1;
      ppiStack_110 = (int **)FUN_0151a450(auStack_d8);
      uStack_8 = 6;
      piStack_14 = (int *)0x3;
      auStack_b8[0] = 0;
      puStack_114 = (uint *)0x61cac2;
      FUN_005880d0();
      piVar11 = piStack_24;
      piStack_14 = (int *)0xb;
      ppiStack_110 = (int **)auStack_b8;
      uStack_8 = 7;
      puStack_114 = (uint *)0x61cadf;
      iVar7 = FUN_00563bf0();
      *piVar11 = iVar7;
      if (iVar7 != 0) {
        LOCK();
        *(int *)(iVar7 + 4) = *(int *)(iVar7 + 4) + 1;
        UNLOCK();
      }
      piStack_20 = (int *)0x1b;
      piStack_14 = (int *)0x1b;
      uStack_8._0_1_ = 10;
      if (auStack_b8[0] != 0) {
        if (((auStack_b8[0] & 1) == 0) && (*(code **)(auStack_b8[0] & 0xfffffffe) != (code *)0x0)) {
          puStack_114 = (uint *)aiStack_b0;
          ppiStack_110 = (int **)0x2;
          (**(code **)(auStack_b8[0] & 0xfffffffe))(puStack_114);
        }
        auStack_b8[0] = 0;
      }
      uStack_8._0_1_ = 9;
      ppiStack_110 = (int **)0x61cb36;
      cVar4 = FUN_0168a8f0();
      if (cVar4 == '\0') {
        ppiStack_110 = (int **)0x61cd83;
        ppiStack_110 = (int **)FUN_005503c0();
        uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
                    /* WARNING: Subroutine does not return */
        puStack_114 = (uint *)0x61cd8d;
        FUN_0054e630();
      }
    }
    piStack_1c = *(int **)(iStack_18 + 0x38f8);
    *(int **)(iStack_18 + 0x38f8) = piVar11;
    if ((uint *)piStack_1c != (uint *)0x0) {
      uStack_8 = 0xe;
      ppiStack_110 = (int **)0x61cb66;
      FUN_016899e0();
      puVar5 = (uint *)*piStack_1c;
      if (puVar5 != (uint *)0x0) {
        LOCK();
        puVar2 = puVar5 + 1;
        uVar9 = *puVar2;
        *puVar2 = *puVar2 - 1;
        UNLOCK();
        if (uVar9 == 1) {
          ppiStack_110 = (int **)0x0;
          puStack_114 = (uint *)0x61cb7f;
          (**(code **)*puVar5)();
          puStack_114 = puVar5;
          uVar13 = GetProcessHeap(0);
          HeapFree(uVar13);
        }
      }
      ppiStack_110 = (int **)0x4;
      puStack_114 = (uint *)piStack_1c;
      FUN_01674ea0();
    }
    if (((uint)piStack_20 & 2) != 0) {
      piStack_20 = (int *)((uint)piStack_20 & 0xfffffffd);
      uStack_8 = 0xf;
      piStack_14 = piStack_20;
      if (auStack_d8[0] != 0) {
        if (((auStack_d8[0] & 1) == 0) && (*(code **)(auStack_d8[0] & 0xfffffffe) != (code *)0x0)) {
          puStack_114 = (uint *)aiStack_d0;
          ppiStack_110 = (int **)0x2;
          (**(code **)(auStack_d8[0] & 0xfffffffe))(puStack_114);
        }
        auStack_d8[0] = 0;
      }
    }
    uStack_8 = 3;
    if (((uint)piStack_20 & 1) != 0) {
      piStack_14 = (int *)((uint)piStack_20 & 0xfffffffe);
      uStack_8._1_3_ = 0;
      uVar3 = uStack_8._1_3_;
      uStack_8._0_1_ = 0x10;
      uStack_8._1_3_ = 0;
      if (appuStack_98[0] != (undefined **)0x0) {
        if ((((uint)appuStack_98[0] & 1) == 0) &&
           (*(code **)((uint)appuStack_98[0] & 0xfffffffe) != (code *)0x0)) {
          puStack_114 = (uint *)aiStack_90;
          ppiStack_110 = (int **)0x2;
          (**(code **)((uint)appuStack_98[0] & 0xfffffffe))(puStack_114);
        }
        appuStack_98[0] = (undefined **)0x0;
        uVar3 = uStack_8._1_3_;
      }
      uStack_8._1_3_ = uVar3;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
    }
    iVar7 = iStack_18;
    piVar11 = (int *)(iStack_18 + 0x1f10);
    while( true ) {
      do {
        puVar5 = (uint *)(iVar7 + 0x1f24);
        LOCK();
        uVar9 = *puVar5;
        *puVar5 = *puVar5 | 1;
        UNLOCK();
      } while ((uVar9 & 1) != 0);
      if (*(int *)(iVar7 + 0x1f20) == 0) break;
      if ((piVar11 == (int *)0x0) || ((int *)*piVar11 == (int *)0x0)) {
        iVar6 = 0;
      }
      else {
        iVar6 = *(int *)*piVar11;
      }
      piStack_28 = (int *)**(undefined4 **)
                            (*(int *)(iVar6 + 4) +
                            (*(int *)(iVar6 + 8) - 1U & *(uint *)(iVar7 + 0x1f1c)) * 4);
      iVar6 = *(int *)(iVar7 + 0x1f20) + -1;
      *(int *)(iVar7 + 0x1f20) = iVar6;
      if (iVar6 == 0) {
        *(undefined4 *)(iVar7 + 0x1f1c) = 0;
        uVar12 = 0;
      }
      else {
        *(int *)(iVar7 + 0x1f1cU) = *(int *)(iVar7 + 0x1f1cU) + 1;
        puVar8 = (undefined4 *)*piVar11;
        if (puVar8 != (undefined4 *)0x0) {
          puVar8 = (undefined4 *)*puVar8;
        }
        uVar12 = *(undefined8 *)
                  (*(int *)(puVar8[1] + (puVar8[2] - 1 & *(uint *)(iVar7 + 0x1f1c)) * 4) + 8);
      }
      *(undefined8 *)(iVar7 + 0x1f28) = uVar12;
      *puVar5 = 0;
      ppiStack_110 = &piStack_28;
      piStack_1c = *(int **)(iStack_18 + 0x38bc);
      puStack_114 = (uint *)((uint *)piStack_1c)[1];
      piStack_20 = (int *)puStack_114;
      uVar9 = FUN_00602bf0(piStack_1c);
      if (*(int *)(iStack_18 + 0x38c0) == 0x15555554) {
        ppiStack_110 = (int **)0x18c0fdc;
                    /* WARNING: Subroutine does not return */
        puStack_114 = (uint *)&UNK_0061cd97;
        FUN_016ddcd9();
      }
      *(int *)(iStack_18 + 0x38c0) = *(int *)(iStack_18 + 0x38c0) + 1;
      piStack_1c[1] = uVar9;
      *piStack_20 = uVar9;
    }
    *puVar5 = 0;
    uStack_8 = 0x11;
    if (cStack_38 != '\0') {
      LOCK();
      uVar9 = *puStack_3c;
      *puStack_3c = *puStack_3c + 0x80000000;
      UNLOCK();
      if (((uVar9 & 0x40000000) == 0) && (-0x80000000 < (int)uVar9)) {
        LOCK();
        uVar9 = *puStack_3c;
        *puStack_3c = *puStack_3c | 0x40000000;
        UNLOCK();
        if ((uVar9 >> 0x1e & 1) == 0) {
          ppiStack_110 = (int **)0x61cd54;
          ppiStack_110 = (int **)FUN_00554e40();
          puStack_114 = (uint *)0x61cd5b;
          SetEvent();
        }
      }
    }
  }
  else {
    ppiStack_110 = (int **)0x138;
    puStack_114 = (uint *)0x61c683;
    ExceptionList = &pvStack_10;
    puVar5 = (uint *)FUN_01674e20();
    uStack_8 = 0;
    piStack_28 = (int *)puVar5;
    if (puVar5 == (uint *)0x0) {
      puStack_114 = (uint *)0x0;
    }
    else {
      ppiStack_110 = (int **)0x4;
      puStack_114 = (uint *)0x61c6a1;
      piStack_24 = (int *)FUN_01674e20();
      if (piStack_24 == (int *)0x0) {
        piVar11 = (int *)0x0;
      }
      else {
        *piStack_24 = (int)RBX::Network::DeserializePacketsJob::DummyArbiter::vftable;
        piVar11 = piStack_24;
      }
      ppiStack_110 = (int **)0xb;
      uVar13 = 0;
      puStack_114 = (uint *)0x0;
      FUN_006049f0(piVar11,piStack_28);
      FUN_01522c10("DeserializePacketsJob",uVar13);
      puStack_114 = puVar5 + 0x3f;
      *puVar5 = (uint)RBX::Network::DeserializePacketsJob::vftable;
      ppiStack_110 = (int **)0x2;
      puVar5[0x3e] = param_1;
      FUN_016dee4c();
      puVar5[0x4b] = 0;
      puVar5[0x4c] = 0;
      puVar5[0x4d] = 0;
      puStack_114 = puVar5;
    }
    ppiStack_110 = (int **)piStack_28;
    uStack_8 = 0xffffffff;
    uStack_34 = 0;
    piStack_30 = (int *)0x0;
    FUN_00604870();
    uVar13 = *(undefined4 *)(param_1 + 0x38f0);
    *(undefined4 *)(param_1 + 0x38f0) = uStack_34;
    piVar11 = *(int **)(param_1 + 0x38f4);
    uStack_50 = uStack_34;
    uStack_2c = piStack_30;
    *(int **)(iStack_18 + 0x38f4) = piStack_30;
    uStack_34 = uVar13;
    piStack_30 = piVar11;
    if (piVar11 != (int *)0x0) {
      LOCK();
      iVar7 = piVar11[1] + -1;
      piVar11[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        ppiStack_110 = (int **)0x61c781;
        (**(code **)*piVar11)();
        LOCK();
        piVar1 = piVar11 + 2;
        iVar7 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar7 == 1) {
          ppiStack_110 = (int **)0x61c790;
          (**(code **)(*piVar11 + 4))();
        }
      }
    }
    iVar7 = iStack_18;
    piVar11 = (int *)(iStack_18 + 0x1f10);
    puVar5 = (uint *)(iStack_18 + 0x1f24);
    while( true ) {
      do {
        LOCK();
        uVar9 = *puVar5;
        *puVar5 = *puVar5 | 1;
        UNLOCK();
      } while ((uVar9 & 1) != 0);
      if (*(int *)(iVar7 + 0x1f20) == 0) break;
      if ((piVar11 == (int *)0x0) || ((int *)*piVar11 == (int *)0x0)) {
        iVar6 = 0;
      }
      else {
        iVar6 = *(int *)*piVar11;
      }
      piStack_24 = (int *)**(undefined4 **)
                            (*(int *)(iVar6 + 4) +
                            (*(int *)(iVar6 + 8) - 1U & *(uint *)(iVar7 + 0x1f1c)) * 4);
      iVar6 = *(int *)(iVar7 + 0x1f20) + -1;
      *(int *)(iVar7 + 0x1f20) = iVar6;
      if (iVar6 == 0) {
        *(undefined4 *)(iVar7 + 0x1f1c) = 0;
        uVar12 = 0;
      }
      else {
        *(int *)(iVar7 + 0x1f1cU) = *(int *)(iVar7 + 0x1f1cU) + 1;
        puVar8 = (undefined4 *)*piVar11;
        if (puVar8 != (undefined4 *)0x0) {
          puVar8 = (undefined4 *)*puVar8;
        }
        uVar12 = *(undefined8 *)
                  (*(int *)(puVar8[1] + (puVar8[2] - 1 & *(uint *)(iVar7 + 0x1f1c)) * 4) + 8);
      }
      *(undefined8 *)(iVar7 + 0x1f28) = uVar12;
      *puVar5 = 0;
      piStack_14 = *(int **)(iStack_18 + 0x38f0);
      ppiStack_110 = (int **)((int)piStack_14 + 0xfc);
      puStack_114 = (uint *)0x61c840;
      iStack_58 = (int)ppiStack_110;
      piStack_1c = piStack_24;
      ppiStack_110 = (int **)FUN_016dee6d();
      if (ppiStack_110 != (int **)0x0) {
        puStack_114 = (uint *)0x61c84d;
        FUN_016df3c9();
      }
      uStack_54 = 1;
      uStack_8 = 1;
      puStack_114 = *(uint **)((int)piStack_14 + 0x130);
      if (*(uint **)((int)piStack_14 + 0x134) == puStack_114) {
        ppiStack_110 = &piStack_24;
        FUN_006030d0();
      }
      else {
        *puStack_114 = (uint)piStack_1c;
        *(int *)((int)piStack_14 + 0x130) = *(int *)((int)piStack_14 + 0x130) + 4;
      }
      ppiStack_110 = (int **)((int)piStack_14 + 0xfc);
      uStack_8 = 2;
      puStack_114 = (uint *)0x61c896;
      iVar6 = FUN_016deec8();
      if (iVar6 != 0) {
        puStack_114 = (uint *)0x61c8a3;
        ppiStack_110 = (int **)iVar6;
        FUN_016df3c9();
      }
      piStack_1c = (int *)&puStack_114;
      uStack_8 = 0xffffffff;
      FUN_006022f0((int)piStack_14 + 8);
      piStack_20 = (int *)((uint)piStack_20 | 4);
      piStack_14 = piStack_20;
      FUN_0151dbc0();
    }
    *puVar5 = 0;
    if (*(int *)(iStack_18 + 0x38f4) != 0) {
      LOCK();
      piVar11 = (int *)(*(int *)(iStack_18 + 0x38f4) + 4);
      *piVar11 = *piVar11 + 1;
      UNLOCK();
    }
    puStack_114 = *(uint **)(iStack_18 + 0x38f0);
    ppiStack_110 = *(int ***)(iStack_18 + 0x38f4);
    FUN_0151d950();
  }
  *(undefined4 *)(iStack_18 + 0x1f38) = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6724 ; VA 0x0061cda0 ; FUN_0061cda0 */

void FUN_0061cda0(int param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined auStack_98 [88];
  int aiStack_40 [5];
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar4 = param_1;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e0fb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00614570(param_1 + 0x1c);
  if (DAT_01d5a098 == '\0') {
    *(undefined4 *)(iVar1 + 8) = *(undefined4 *)(iVar4 + 0x30);
    *(undefined4 *)(iVar1 + 0xc) = 1;
  }
  if (DAT_01ee420f != '\0') {
    puVar2 = (undefined4 *)FUN_009c9510(aiStack_40);
    iStack_8 = 0;
    if (0xf < (uint)puVar2[5]) {
      puVar2 = (undefined4 *)*puVar2;
    }
    puVar3 = (undefined4 *)FUN_009c9510(auStack_28);
    iStack_8._0_1_ = 1;
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    FUN_01677490(DAT_01ee420f,
                 "Replicator::processDeserializedItemChildren() :   children of %s[parentId=%s] ",
                 puVar3,puVar2,0);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_14) {
      uVar5 = uStack_14 + 1;
      uVar6 = auStack_28[0];
      if (0xfff < uVar5) {
        uVar6 = *(uint *)(auStack_28[0] - 4);
        uVar5 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar5);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    iStack_8 = 0xffffffff;
    if (0xf < uStack_2c) {
      uVar6 = uStack_2c + 1;
      iVar4 = aiStack_40[0];
      if (0xfff < uVar6) {
        iVar4 = *(int *)(aiStack_40[0] + -4);
        uVar6 = uStack_2c + 0x24;
        if (0x1f < (aiStack_40[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar6);
    }
  }
  iVar4 = (uint)*(byte *)(iVar1 + 0x10) + iVar1 + 0x11;
  FUN_00606ea0(&param_1,*(undefined4 *)(iVar1 + 0xc),(undefined4 *)(iVar1 + 0xc),
               -(uint)(iVar4 != 0) & iVar4 + 1U);
  iVar4 = param_1;
  if (param_1 != 0) {
    FUN_0060f060(param_1 + 0xc);
    iStack_8 = 2;
    FUN_006078f0(auStack_98,aiStack_40);
    FUN_00613010();
    if (DAT_01d5a098 != '\0') {
      FUN_0061d620(&param_1,iVar4);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6725 ; VA 0x0061cf70 ; FUN_0061cf70 */

uint __thiscall FUN_0061cf70(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  int *piVar10;
  undefined auStack_a0 [88];
  int aiStack_48 [5];
  uint uStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e13b;
  pvStack_10 = ExceptionList;
  iVar9 = param_1 + 0x37c9 + (uint)*(byte *)(param_1 + 0x37c8);
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  uVar3 = FUN_009c91f0(param_2 + 0x24);
  uVar4 = FUN_00607110(&piStack_14,uVar3,param_2 + 0x24,-(uint)(iVar9 != 0) & iVar9 + 1U);
  piVar2 = piStack_14;
  if (piStack_14 == (int *)0x0) {
    ExceptionList = pvStack_10;
    return uVar4;
  }
  if (DAT_01ee420f != '\0') {
    puVar5 = (undefined4 *)FUN_009c9510(aiStack_48);
    iStack_8 = 0;
    if (0xf < (uint)puVar5[5]) {
      puVar5 = (undefined4 *)*puVar5;
    }
    puVar6 = (undefined4 *)FUN_009c9510(auStack_30);
    iStack_8._0_1_ = 1;
    if (0xf < (uint)puVar6[5]) {
      puVar6 = (undefined4 *)*puVar6;
    }
    FUN_01677490(DAT_01ee420f,
                 "Replicator::processDeserializedItemChildren() :   siblings of %s[parentId=%s] ",
                 puVar6,puVar5,0);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_1c) {
      uVar7 = uStack_1c + 1;
      uVar4 = auStack_30[0];
      if (0xfff < uVar7) {
        uVar4 = *(uint *)(auStack_30[0] - 4);
        uVar7 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar4,uVar7);
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    iStack_8 = 0xffffffff;
    if (0xf < uStack_34) {
      uVar4 = uStack_34 + 1;
      iVar9 = aiStack_48[0];
      if (0xfff < uVar4) {
        iVar9 = *(int *)(aiStack_48[0] + -4);
        uVar4 = uStack_34 + 0x24;
        if (0x1f < (aiStack_48[0] - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar9,uVar4);
    }
  }
  piVar2[5] = piVar2[5] + 1;
  iVar9 = (int)piVar2 + *(byte *)(piVar2 + 6) + 0x19;
  uVar4 = FUN_00606ea0(&piStack_14,piVar2[5],piVar2 + 5,-(uint)(iVar9 != 0) & iVar9 + 1U);
  if (piStack_14 != (int *)0x0) {
    FUN_0060f060(piStack_14 + 3);
    iStack_8 = 2;
    FUN_006078f0(auStack_a0,aiStack_48);
    iStack_8 = 0xffffffff;
    FUN_00613010();
    if (DAT_01d5a098 == '\0') goto LAB_0061d157;
    uVar4 = FUN_0061d620(&param_3,piStack_14);
  }
  if (DAT_01d5a098 != '\0') {
    ExceptionList = pvStack_10;
    return uVar4;
  }
LAB_0061d157:
  uVar4 = piVar2[5];
  if ((uint)piVar2[4] < uVar4) {
    if (DAT_01ee420f != '\0') {
      puVar5 = (undefined4 *)FUN_009c9510(aiStack_48);
      iStack_8 = 3;
      if (0xf < (uint)puVar5[5]) {
        puVar5 = (undefined4 *)*puVar5;
      }
      puVar6 = (undefined4 *)FUN_009c9510(auStack_30);
      iStack_8 = CONCAT31(iStack_8._1_3_,4);
      if (0xf < (uint)puVar6[5]) {
        puVar6 = (undefined4 *)*puVar6;
      }
      FUN_01677490(DAT_01ee420f,
                   "Replicator::processDeserializedItemChildren() :   erasing row for parent of %s[parentId=%s] "
                   ,puVar6,puVar5,0);
      if (0xf < uStack_1c) {
        uVar7 = uStack_1c + 1;
        uVar4 = auStack_30[0];
        if (0xfff < uVar7) {
          uVar4 = *(uint *)(auStack_30[0] - 4);
          uVar7 = uStack_1c + 0x24;
          if (0x1f < (auStack_30[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar4,uVar7);
      }
      uStack_20 = 0;
      uStack_1c = 0xf;
      auStack_30[0] = auStack_30[0] & 0xffffff00;
      if (0xf < uStack_34) {
        uVar4 = uStack_34 + 1;
        iVar9 = aiStack_48[0];
        if (0xfff < uVar4) {
          iVar9 = *(int *)(aiStack_48[0] + -4);
          uVar4 = uStack_34 + 0x24;
          if (0x1f < (aiStack_48[0] - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar9,uVar4);
      }
    }
    param_3 = (int *)*piVar2;
    uVar7 = (uint)piVar2[1] % *(uint *)(param_1 + 0x37cc);
    piVar1 = *(int **)(*(int *)(param_1 + 0x37dc) + uVar7 * 4);
    for (piVar10 = (int *)*piVar1; piVar10 != piVar2; piVar10 = (int *)*piVar10) {
      piVar1 = piVar10;
    }
    do {
      *piVar1 = *piVar10;
      FUN_00611ed0();
      FUN_01674ea0(piVar10,0x30);
      *(int *)(iStack_18 + 0x37d0) = *(int *)(iStack_18 + 0x37d0) + -1;
      uVar8 = uVar7;
      if (*piVar1 == 0) {
LAB_0061d2b0:
        uVar4 = *(uint *)(iStack_18 + 0x37dc);
        if (*(int **)(uVar4 + uVar7 * 4) == piVar1) {
          *(undefined4 *)(uVar4 + uVar7 * 4) = 0;
        }
      }
      else {
        uVar8 = *(uint *)(*piVar1 + 4);
        uVar4 = uVar8 / *(uint *)(iStack_18 + 0x37cc);
        uVar8 = uVar8 % *(uint *)(iStack_18 + 0x37cc);
        if (uVar7 != uVar8) {
          *(int **)(*(int *)(iStack_18 + 0x37dc) + uVar8 * 4) = piVar1;
          goto LAB_0061d2b0;
        }
      }
      piVar10 = (int *)*piVar1;
      uVar7 = uVar8;
    } while (piVar10 != param_3);
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 6726 ; VA 0x0061d300 ; FUN_0061d300 */

void __thiscall FUN_0061d300(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = FUN_00a6ce70(param_3 + 2);
  uVar3 = *(uint *)(param_1 + 0x18) & uVar3;
  piVar1 = (int *)(*(int *)(param_1 + 0xc) + uVar3 * 8);
  if ((int *)piVar1[1] == param_3) {
    if ((int *)*piVar1 == param_3) {
      *piVar1 = *(int *)(param_1 + 4);
      *(undefined4 *)(*(int *)(param_1 + 0xc) + 4 + uVar3 * 8) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar1[1] = param_3[1];
    }
  }
  else if ((int *)*piVar1 == param_3) {
    *piVar1 = *param_3;
  }
  iVar2 = *param_3;
  *(int *)param_3[1] = iVar2;
  *(int *)(*param_3 + 4) = param_3[1];
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
  FUN_00612d60();
  FUN_01674ea0(param_3,0x20);
  *param_2 = iVar2;
  return;
}



/* FUNCTION 6727 ; VA 0x0061d390 ; FUN_0061d390 */

int __thiscall FUN_0061d390(int param_1,int *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  int iVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_00a6ce70(param_2);
  uVar4 = uVar4 & *(uint *)(param_1 + 0x18);
  iVar2 = *(int *)(param_1 + 0xc);
  piVar3 = *(int **)(param_1 + 4);
  puVar1 = (undefined4 *)(iVar2 + uVar4 * 8);
  iVar8 = uVar4 * 8 + 4;
  piVar7 = (int *)*puVar1;
  piVar6 = piVar7;
  while( true ) {
    piVar5 = piVar3;
    if (piVar7 != piVar3) {
      piVar5 = (int *)**(undefined4 **)(iVar2 + iVar8);
    }
    if (piVar6 == piVar5) goto LAB_0061d465;
    if (((piVar6[2] == *param_2) && (piVar6[3] == param_2[1])) &&
       (piVar5 = piVar6, piVar6[4] == param_2[2])) break;
    piVar6 = (int *)*piVar6;
  }
  while( true ) {
    piVar7 = piVar3;
    if ((int *)*puVar1 != piVar3) {
      piVar7 = (int *)**(undefined4 **)(iVar2 + iVar8);
    }
    if (((piVar5 == piVar7) || (*param_2 != piVar5[2])) ||
       ((param_2[1] != piVar5[3] || (param_2[2] != piVar5[4])))) break;
    piVar5 = (int *)*piVar5;
  }
  if (piVar6 == piVar5) {
LAB_0061d465:
    piVar6 = piVar3;
    piVar5 = piVar3;
  }
  iVar8 = 0;
  for (piVar7 = piVar6; piVar7 != piVar5; piVar7 = (int *)*piVar7) {
    iVar8 = iVar8 + 1;
  }
  if ((piVar6 == (int *)*piVar3) && (piVar5 == piVar3)) {
    uStack_8 = 0;
    FUN_00619470();
    FUN_005cb500(8);
  }
  else if (piVar6 != piVar5) {
    do {
      piVar3 = (int *)*piVar6;
      uVar4 = FUN_00a6ce70(piVar6 + 2);
      iVar2 = (uVar4 & *(uint *)(param_1 + 0x18)) * 8;
      piVar7 = (int *)(*(int *)(param_1 + 0xc) + iVar2);
      if ((int *)piVar7[1] == piVar6) {
        if ((int *)*piVar7 == piVar6) {
          *piVar7 = *(int *)(param_1 + 4);
          *(undefined4 *)(iVar2 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
        }
        else {
          piVar7[1] = piVar6[1];
        }
      }
      else if ((int *)*piVar7 == piVar6) {
        *piVar7 = *piVar6;
      }
      *(int *)piVar6[1] = *piVar6;
      *(int *)(*piVar6 + 4) = piVar6[1];
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
      FUN_00612d60();
      FUN_01674ea0(piVar6,0x20);
      piVar6 = piVar3;
    } while (piVar3 != piVar5);
    ExceptionList = pvStack_10;
    return iVar8;
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 6728 ; VA 0x0061d550 ; FUN_0061d550 */

void __thiscall FUN_0061d550(int *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  void **ppvVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  ppvVar2 = &pvStack_10;
  if ((param_3 == (int *)*piVar1) && (ppvVar2 = &pvStack_10, param_4 == piVar1)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_00617290(piVar1[1]);
    *(int **)(*param_1 + 4) = piVar1;
    *(int **)*param_1 = piVar1;
    *(int **)(*param_1 + 8) = piVar1;
    param_1[1] = 0;
    *param_2 = *(undefined4 *)*param_1;
    ExceptionList = pvStack_10;
    return;
  }
  while (ExceptionList = ppvVar2, param_3 != param_4) {
    FUN_00551320();
    FUN_00551320();
    uVar3 = FUN_00553830(param_3);
    FUN_0056cb40();
    FUN_01674ea0(uVar3,0xf8);
    ppvVar2 = (void **)ExceptionList;
  }
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6729 ; VA 0x0061d620 ; FUN_0061d620 */

int * __thiscall FUN_0061d620(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  
  piVar1 = (int *)*param_3;
  *param_2 = (int)piVar1;
  uVar3 = (uint)param_3[1] % *(uint *)(param_1 + 4);
  piVar2 = *(int **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  for (piVar5 = (int *)*piVar2; piVar5 != param_3; piVar5 = (int *)*piVar5) {
    piVar2 = piVar5;
  }
  do {
    *piVar2 = *piVar5;
    FUN_00613010();
    FUN_01674ea0(piVar5,100);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    uVar4 = uVar3;
    if (*piVar2 == 0) {
LAB_0061d697:
      if (*(int **)(*(int *)(param_1 + 0x14) + uVar3 * 4) == piVar2) {
        *(undefined4 *)(*(int *)(param_1 + 0x14) + uVar3 * 4) = 0;
      }
    }
    else {
      uVar4 = *(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 4);
      if (uVar3 != uVar4) {
        *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4) = piVar2;
        goto LAB_0061d697;
      }
    }
    piVar5 = (int *)*piVar2;
    uVar3 = uVar4;
    if (piVar5 == piVar1) {
      return param_2;
    }
  } while( true );
}



/* FUNCTION 6730 ; VA 0x0061d6c0 ; FUN_0061d6c0 */

int * __thiscall FUN_0061d6c0(int param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  
  piVar1 = (int *)*param_3;
  *param_2 = (int)piVar1;
  uVar3 = (uint)param_3[1] % *(uint *)(param_1 + 4);
  piVar2 = *(int **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
  for (piVar5 = (int *)*piVar2; piVar5 != param_3; piVar5 = (int *)*piVar5) {
    piVar2 = piVar5;
  }
  do {
    *piVar2 = *piVar5;
    FUN_00605f10(-(uint)(param_1 != -3) & param_1 + 4U,piVar5 + 2);
    FUN_01674ea0(piVar5,0x1c);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    uVar4 = uVar3;
    if (*piVar2 == 0) {
LAB_0061d749:
      if (*(int **)(*(int *)(param_1 + 0x14) + uVar3 * 4) == piVar2) {
        *(undefined4 *)(*(int *)(param_1 + 0x14) + uVar3 * 4) = 0;
      }
    }
    else {
      uVar4 = *(uint *)(*piVar2 + 4) % *(uint *)(param_1 + 4);
      if (uVar3 != uVar4) {
        *(int **)(*(int *)(param_1 + 0x14) + uVar4 * 4) = piVar2;
        goto LAB_0061d749;
      }
    }
    piVar5 = (int *)*piVar2;
    uVar3 = uVar4;
    if (piVar5 == piVar1) {
      return param_2;
    }
  } while( true );
}



/* FUNCTION 6731 ; VA 0x0061d780 ; FUN_0061d780 */

uint __thiscall FUN_0061d780(int param_1,uint param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  
  iVar5 = *(int *)(param_1 + 0x24);
  if (iVar5 == *(int *)(param_1 + 0x28)) {
    return 0;
  }
  if (param_2 != *(uint *)(param_1 + 0x34)) {
    uVar2 = (param_2 >> 3) + param_2;
    uVar4 = (*(int *)(param_1 + 0x28) - iVar5 >> 3) - 1;
    uVar3 = 0;
    do {
      uVar2 = uVar2 & uVar4;
      puVar1 = (uint *)(iVar5 + uVar2 * 8);
      if (*puVar1 == param_2) goto LAB_0061d7e2;
      if (*puVar1 == *(uint *)(param_1 + 0x34)) break;
      iVar5 = *(int *)(param_1 + 0x24);
      uVar2 = uVar2 + 1 + uVar3;
      uVar3 = uVar3 + 1;
    } while (uVar3 <= uVar4);
  }
  puVar1 = (uint *)0x0;
LAB_0061d7e2:
  return -(uint)(puVar1 != (uint *)0x0) & (uint)(puVar1 + 1);
}



/* FUNCTION 6732 ; VA 0x0061d800 ; FUN_0061d800 */

undefined4 __thiscall FUN_0061d800(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = (**(code **)(param_1 + 0x38))(auStack_18);
  uStack_8 = 0;
  uVar2 = FUN_009d5980(param_3,uVar2);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_14[1] + -1;
    piStack_14[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar1 = piStack_14[2] + -1;
      piStack_14[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 6733 ; VA 0x0061d880 ; FUN_0061d880 */

undefined4 __thiscall FUN_0061d880(int *param_1,uint param_2,int param_3)

{
  int *piVar1;
  undefined4 ***pppuVar2;
  char cVar3;
  undefined4 ****ppppuVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  int iVar8;
  undefined4 uVar9;
  undefined4 ***apppuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e178;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  FUN_0054ef60(param_3);
  pppuVar2 = apppuStack_30[0];
  uStack_18 = param_2;
  piVar1 = (int *)param_1[0x7ba];
  uStack_8 = 0;
  if (piVar1 == (int *)0x0) {
LAB_0061d907:
    iVar8 = (int)param_1 + *(byte *)(param_1 + 0x78e) + 0x1e39;
    iVar5 = FUN_005702d0(apppuStack_30);
    piVar1 = piStack_14;
    FUN_00606f30(&param_3,(param_2 >> 3) + 0x2c15e7f9 +
                          (iVar5 + 0x9e3779b9U >> 2) + param_2 + iVar5 * 0x40 ^ iVar5 + 0x9e3779b9U,
                 apppuStack_30,-(uint)(iVar8 != 0) & iVar8 + 1U);
    if ((param_3 == 0) &&
       ((cVar3 = FUN_006210c0(param_2), cVar3 == '\0' &&
        (cVar3 = (**(code **)(*piVar1 + 0x10c))(), cVar3 != '\0')))) {
      uVar9 = 0;
      goto LAB_0061d999;
    }
  }
  else {
    ppppuVar4 = apppuStack_30;
    if (0xf < uStack_1c) {
      ppppuVar4 = (undefined4 ****)apppuStack_30[0];
    }
    piVar6 = piVar1;
    if (0xf < (uint)piVar1[5]) {
      piVar6 = (int *)*piVar1;
    }
    cVar3 = FUN_0055c360(piVar6,piVar1[4],ppppuVar4,uStack_20);
    if ((cVar3 == '\0') || (piVar1[6] != param_2)) goto LAB_0061d907;
    param_1[0x7ba] = 0;
    apppuStack_30[0] = pppuVar2;
  }
  uVar9 = 1;
LAB_0061d999:
  if (0xf < uStack_1c) {
    uVar7 = uStack_1c + 1;
    ppppuVar4 = (undefined4 ****)apppuStack_30[0];
    if (0xfff < uVar7) {
      ppppuVar4 = (undefined4 ****)((undefined4 ****)apppuStack_30[0])[-1];
      uVar7 = uStack_1c + 0x24;
      if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar4,uVar7);
  }
  ExceptionList = pvStack_10;
  return uVar9;
}



/* FUNCTION 6734 ; VA 0x0061d9f0 ; FUN_0061d9f0 */

undefined4 __thiscall FUN_0061d9f0(int *param_1,int param_2,undefined4 *param_3)

{
  uint *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  double dVar4;
  undefined4 *puVar5;
  char cVar6;
  undefined4 uVar7;
  double *pdVar8;
  int iVar9;
  undefined4 *puStack_c;
  int iStack_8;
  
  puVar5 = param_3;
  if (param_2 == param_1[0x26]) {
    return 1;
  }
  puVar3 = (undefined4 *)param_1[0x7b9];
  puStack_c = param_3;
  iStack_8 = param_2;
  if (((puVar3 != (undefined4 *)0x0) && (param_3 == (undefined4 *)*puVar3)) &&
     (param_2 == puVar3[1])) {
    param_1[0x7b9] = 0;
    return 1;
  }
  cVar6 = (**(code **)(*param_1 + 0x110))(param_2,param_3);
  if (cVar6 == '\0') {
    return 1;
  }
  cVar6 = FUN_006210c0();
  if ((cVar6 != '\0') && (cVar6 = FUN_00620ff0(), cVar6 == '\0')) {
    if (DAT_01d5a080 == '\0') {
      return 1;
    }
    puVar1 = (uint *)(param_1 + 0x5e6);
    uVar2 = *puVar1;
    *puVar1 = *puVar1 + 1;
    param_1[0x5e7] = param_1[0x5e7] + (uint)(0xfffffffe < uVar2);
    return 1;
  }
  cVar6 = (**(code **)(*param_1 + 0x11c))();
  if (cVar6 != '\0') {
    if (((((DAT_01d67098 != '\0') && (puVar5 == (undefined4 *)&DAT_01eeec34)) ||
         ((puVar5 == (undefined4 *)&DAT_01eeebc4 ||
          ((((puVar5 == (undefined4 *)&DAT_0211b158 || (puVar5 == (undefined4 *)&DAT_0211b200)) ||
            (puVar5 == &DAT_0212ca3c)) ||
           ((puVar5 == (undefined4 *)&DAT_0212076c || (puVar5 == &DAT_01eebf14)))))))) ||
        (puVar5 == &DAT_01eee910)) ||
       (((puVar5 == (undefined4 *)&DAT_0212cb68 || (puVar5 == &DAT_02125100)) ||
        ((puVar5 == &DAT_0212d5c0 || (puVar5 == &DAT_0211a318)))))) goto LAB_0061db4b;
    if (puVar5 == (undefined4 *)&DAT_0212c458) {
      return 1;
    }
    if (DAT_01d665a8 != '\0') {
      FUN_00abe1a0();
      cVar6 = FUN_00892700();
      if (cVar6 != '\0') {
        return 1;
      }
    }
  }
  if (((uint)puVar5[9] >> 2 & 1) == 0) {
    return 1;
  }
LAB_0061db4b:
  FUN_01682800();
  iVar9 = (int)param_1 + *(byte *)(param_1 + 0x788) + 0x1e21;
  uVar7 = FUN_008a2fa0(&puStack_c);
  FUN_00606ff0(&param_2,uVar7,&puStack_c,-(uint)(iVar9 != 0) & iVar9 + 1U);
  if (param_2 == 0) {
    return 0;
  }
  dVar4 = *(double *)(param_2 + 0x10);
  uVar7 = *(undefined4 *)(param_2 + 0x18);
  if (DAT_01d5a080 == '\0') {
    return 1;
  }
  pdVar8 = (double *)FUN_01682800();
  FUN_006b8880(uVar7,(*pdVar8 - dVar4) * DAT_018c0d70);
  return 1;
}



/* FUNCTION 6735 ; VA 0x0061dc00 ; FUN_0061dc00 */

undefined4 FUN_0061dc00(void)

{
  return 0;
}



/* FUNCTION 6736 ; VA 0x0061dc10 ; FUN_0061dc10 */

undefined4 FUN_0061dc10(void)

{
  return 0;
}



/* FUNCTION 6737 ; VA 0x0061dc20 ; FUN_0061dc20 */

uint __thiscall FUN_0061dc20(int *param_1,uint *param_2)

{
  int iVar1;
  uint uVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  
  iVar1 = *param_1;
  if (iVar1 == param_1[1]) {
    return 0;
  }
  uVar2 = *param_2;
  if (uVar2 != param_1[4]) {
    uVar4 = (uVar2 >> 3) + uVar2;
    uVar6 = (param_1[1] - iVar1 >> 3) - 1;
    uVar5 = 0;
    do {
      uVar4 = uVar4 & uVar6;
      puVar3 = (uint *)(iVar1 + uVar4 * 8);
      if (*puVar3 == uVar2) goto LAB_0061dc83;
      if (*puVar3 == param_1[4]) break;
      uVar4 = uVar4 + 1 + uVar5;
      uVar5 = uVar5 + 1;
    } while (uVar5 <= uVar6);
  }
  puVar3 = (uint *)0x0;
LAB_0061dc83:
  return -(uint)(puVar3 != (uint *)0x0) & (uint)(puVar3 + 1);
}



/* FUNCTION 6738 ; VA 0x0061dca0 ; FUN_0061dca0 */

uint __thiscall FUN_0061dca0(int *param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  char cVar5;
  uint uVar6;
  undefined4 *puVar7;
  int *piVar8;
  uint uVar9;
  int *piVar10;
  uint uStack_10;
  
  iVar2 = *param_1;
  if (iVar2 == param_1[1]) {
    return 0;
  }
  piVar1 = param_1 + 4;
  piVar10 = piVar1;
  if (0xf < (uint)param_1[9]) {
    piVar10 = (int *)*piVar1;
  }
  uVar3 = param_2[4];
  puVar7 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar7 = (undefined4 *)*param_2;
  }
  cVar5 = FUN_0055c360(puVar7,uVar3,piVar10,param_1[8]);
  if (cVar5 == '\0') {
    uVar9 = (param_1[1] - iVar2) / 0x1c - 1;
    uVar6 = FUN_005702d0(param_2);
    uStack_10 = 0;
    do {
      uVar6 = uVar6 & uVar9;
      piVar10 = (int *)(iVar2 + uVar6 * 0x1c);
      puVar7 = param_2;
      if (0xf < (uint)param_2[5]) {
        puVar7 = (undefined4 *)*param_2;
      }
      iVar4 = piVar10[4];
      piVar8 = piVar10;
      if (0xf < (uint)piVar10[5]) {
        piVar8 = (int *)*piVar10;
      }
      cVar5 = FUN_0055c360(piVar8,iVar4,puVar7,uVar3);
      if (cVar5 != '\0') goto LAB_0061dda8;
      piVar8 = piVar1;
      if (0xf < (uint)param_1[9]) {
        piVar8 = (int *)*piVar1;
      }
      if (0xf < (uint)piVar10[5]) {
        piVar10 = (int *)*piVar10;
      }
      cVar5 = FUN_0055c360(piVar10,iVar4,piVar8,param_1[8]);
      if (cVar5 != '\0') break;
      uVar6 = uVar6 + 1 + uStack_10;
      uStack_10 = uStack_10 + 1;
    } while (uStack_10 <= uVar9);
  }
  piVar10 = (int *)0x0;
LAB_0061dda8:
  return (uint)(piVar10 + 6) & -(uint)(piVar10 != (int *)0x0);
}



/* FUNCTION 6739 ; VA 0x0061ddc0 ; FUN_0061ddc0 */

int * __thiscall FUN_0061ddc0(int param_1,int *param_2,int *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  uVar3 = FUN_00a6ce70(param_3);
  uVar3 = *(uint *)(param_1 + 0x18) & uVar3;
  puVar1 = *(undefined4 **)(param_1 + 4);
  puVar2 = *(undefined4 **)(*(int *)(param_1 + 0xc) + uVar3 * 8);
  puVar4 = puVar2;
  while( true ) {
    puVar5 = puVar1;
    if (puVar2 != puVar1) {
      puVar5 = (undefined4 *)**(undefined4 **)(*(int *)(param_1 + 0xc) + uVar3 * 8 + 4);
    }
    if (puVar4 == puVar5) break;
    if (((puVar4[2] == *param_3) && (puVar4[3] == param_3[1])) && (puVar4[4] == param_3[2])) {
      if ((param_3[1] != puVar4[3]) || (param_3[2] != puVar4[4])) {
        puVar4 = puVar1;
      }
      *param_2 = (int)puVar4;
      return param_2;
    }
    puVar4 = (undefined4 *)*puVar4;
  }
  *param_2 = (int)puVar1;
  return param_2;
}



/* FUNCTION 6740 ; VA 0x0061de50 ; FUN_0061de50 */

undefined4 __thiscall FUN_0061de50(byte *param_1,undefined4 param_2,undefined4 param_3)

{
  byte bVar1;
  undefined4 uVar2;
  
  bVar1 = *param_1;
  uVar2 = FUN_005702d0(param_3);
  FUN_00562fc0(param_2,uVar2,param_3,
               -(uint)(param_1 + bVar1 + 1 != (byte *)0x0) & (uint)(param_1 + bVar1 + 1 + 1));
  return param_2;
}



/* FUNCTION 6741 ; VA 0x0061de90 ; FUN_0061de90 */

undefined4 __thiscall FUN_0061de90(byte *param_1,undefined4 param_2,undefined4 param_3)

{
  byte bVar1;
  undefined4 uVar2;
  
  bVar1 = *param_1;
  uVar2 = FUN_009c91f0(param_3);
  FUN_00607110(param_2,uVar2,param_3,
               -(uint)(param_1 + bVar1 + 1 != (byte *)0x0) & (uint)(param_1 + bVar1 + 1 + 1));
  return param_2;
}



/* FUNCTION 6742 ; VA 0x0061ded0 ; FUN_0061ded0 */

void __thiscall FUN_0061ded0(int param_1,undefined4 *param_2,uint param_3)

{
  undefined4 *puVar1;
  char cVar2;
  uint uVar3;
  int *piVar4;
  
  uVar3 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar4 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar4 = (int *)0x0;
    }
    else {
      piVar4 = (int *)*puVar1;
    }
    if (piVar4 != (int *)0x0) {
      do {
        if (param_3 == piVar4[1]) {
          cVar2 = FUN_00a33d60(piVar4 + 2);
          if (cVar2 != '\0') break;
        }
        else if ((uint)piVar4[1] % *(uint *)(param_1 + 4) != uVar3) {
          *param_2 = 0;
          return;
        }
        piVar4 = (int *)*piVar4;
        if (piVar4 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar4;
  return;
}



/* FUNCTION 6743 ; VA 0x0061df60 ; FUN_0061df60 */

void __thiscall FUN_0061df60(int param_1,undefined4 *param_2,uint param_3,int *param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  uint uVar3;
  
  uVar3 = param_3 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
    piVar2 = (int *)0x0;
  }
  else {
    puVar1 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar3 * 4);
    if (puVar1 == (undefined4 *)0x0) {
      piVar2 = (int *)0x0;
    }
    else {
      piVar2 = (int *)*puVar1;
    }
    if (piVar2 != (int *)0x0) {
      do {
        if (param_3 == piVar2[1]) {
          if (((*param_4 == piVar2[2]) && (param_4[1] == piVar2[3])) && (param_4[2] == piVar2[4]))
          break;
        }
        else if ((uint)piVar2[1] % *(uint *)(param_1 + 4) != uVar3) {
          *param_2 = 0;
          return;
        }
        piVar2 = (int *)*piVar2;
        if (piVar2 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar2;
  return;
}



/* FUNCTION 6744 ; VA 0x0061e000 ; FUN_0061e000 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_0061e000(int param_1,ushort param_2)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead050) {
    FUN_016f3809(&DAT_01ead050);
    if (DAT_01ead050 == -1) {
      _DAT_01ead048 = 0;
      DAT_01ead04c = 0xf;
      DAT_01ead038._0_1_ = 0;
      FUN_016f3654(&LAB_0187c600);
      FUN_016f37bf(&DAT_01ead050);
    }
  }
  if ((uint)param_2 < (uint)((*(int *)(param_1 + 0xbc) - *(int *)(param_1 + 0xb8)) / 0x18)) {
    return (undefined4 *)(*(int *)(param_1 + 0xb8) + (uint)param_2 * 0x18);
  }
  return &DAT_01ead038;
}



/* FUNCTION 6745 ; VA 0x0061e0c0 ; FUN_0061e0c0 */

undefined4 FUN_0061e0c0(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  float10 fVar2;
  float10 fVar3;
  int iVar4;
  float10 fVar5;
  float10 fVar6;
  float10 fVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179e198;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  fVar5 = (float10)FUN_01523050();
  fVar2 = (float10)DAT_018ce318;
  fVar6 = (float10)FUN_015230f0();
  fVar3 = (float10)DAT_018c0d70;
  fVar7 = (float10)FUN_01523100();
  FUN_01675640(param_1,"%.1f/s %.1f msec %d%%",(double)fVar7,(double)(fVar6 * fVar3),
               (int)(fVar5 * fVar2));
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar4 = param_3[1] + -1;
    param_3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 6746 ; VA 0x0061e1a0 ; FUN_0061e1a0 */

void __thiscall FUN_0061e1a0(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  
  uVar1 = param_1[3];
  uVar5 = uVar1;
  if (uVar1 < 4) {
    uVar5 = 4;
  }
  if ((uVar5 & 3) != 0) {
    uVar5 = (uVar5 - (uVar5 & 3)) + 4;
  }
  iVar3 = (uint)((uVar1 * param_3) % uVar5 != 0) + (uVar1 * param_3) / uVar5;
  if (iVar3 != 0) {
    puVar4 = (undefined4 *)((((iVar3 + -1) * uVar5) / uVar5) * uVar5 + (int)param_2);
    *puVar4 = *param_1;
    if (puVar4 != param_2) {
      for (puVar2 = (undefined4 *)((int)puVar4 - uVar5); puVar2 != param_2;
          puVar2 = (undefined4 *)((int)puVar2 - uVar5)) {
        *puVar2 = puVar4;
        puVar4 = puVar2;
      }
      *param_2 = puVar4;
    }
    *param_1 = param_2;
  }
  return;
}



/* FUNCTION 6747 ; VA 0x0061e220 ; FUN_0061e220 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0061e220(undefined4 *param_1)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (DAT_01ead26b == '\0') {
    DAT_01ead26b = '\x01';
    DAT_01ead244 = 0;
    uRam01ead248 = 0;
    DAT_01ead24c = (undefined4 *)0x0;
    DAT_01ead250 = 0;
    _DAT_01ead264 = 0;
    DAT_01ead254 = _DAT_018ce340;
    uRam01ead258 = _UNK_018ce344;
    uRam01ead25c = _UNK_018ce348;
    uRam01ead260 = _UNK_018ce34c;
  }
  ExceptionList = &pvStack_10;
  FUN_005874f0();
  *param_1 = DAT_01ead24c;
  DAT_01ead24c = param_1;
  uStack_8 = 0;
  LOCK();
  uVar1 = DAT_01ead244 + 0x80000000;
  UNLOCK();
  uVar2 = uVar1;
  if (((DAT_01ead244 & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead244)) {
    LOCK();
    DAT_01ead244 = uVar1 | 0x40000000;
    UNLOCK();
    uVar2 = DAT_01ead244;
    if ((uVar1 >> 0x1e & 1) == 0) {
      uVar3 = FUN_00554e40();
      SetEvent(uVar3);
      uVar2 = DAT_01ead244;
    }
  }
  DAT_01ead244 = uVar2;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6748 ; VA 0x0061e2d0 ; FUN_0061e2d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0061e2d0(undefined4 param_1,undefined4 param_2)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  if (DAT_01ead26b == '\0') {
    DAT_01ead26b = '\x01';
    DAT_01ead244 = 0;
    uRam01ead248 = 0;
    DAT_01ead24c = 0;
    DAT_01ead250 = 0;
    _DAT_01ead264 = 0;
    DAT_01ead254 = _DAT_018ce340;
    uRam01ead258 = _UNK_018ce344;
    uRam01ead25c = _UNK_018ce348;
    uRam01ead260 = _UNK_018ce34c;
  }
  ExceptionList = &pvStack_10;
  FUN_005874f0();
  FUN_0061e1a0(param_1,param_2);
  uStack_8 = 0;
  LOCK();
  uVar1 = DAT_01ead244 + 0x80000000;
  UNLOCK();
  uVar2 = uVar1;
  if (((DAT_01ead244 & 0x40000000) == 0) && (-0x80000000 < (int)DAT_01ead244)) {
    LOCK();
    DAT_01ead244 = uVar1 | 0x40000000;
    UNLOCK();
    uVar2 = DAT_01ead244;
    if ((uVar1 >> 0x1e & 1) == 0) {
      uVar3 = FUN_00554e40();
      SetEvent(uVar3);
      uVar2 = DAT_01ead244;
    }
  }
  DAT_01ead244 = uVar2;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 6749 ; VA 0x0061e380 ; FUN_0061e380 */

void FUN_0061e380(undefined8 *param_1,int *param_2,byte param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar2 = *param_2 << (param_3 & 0x1f);
  iVar4 = param_2[1] << (param_3 & 0x1f);
  iVar3 = param_2[2] << (param_3 & 0x1f);
  iVar1 = 1 << (param_3 & 0x1f);
  *param_1 = CONCAT44(iVar4,iVar2);
  *(int *)(param_1 + 1) = iVar3;
  *(int *)((int)param_1 + 0xc) = iVar2 + iVar1;
  *(int *)(param_1 + 2) = iVar4 + iVar1;
  *(int *)((int)param_1 + 0x14) = iVar3 + iVar1;
  return;
}


