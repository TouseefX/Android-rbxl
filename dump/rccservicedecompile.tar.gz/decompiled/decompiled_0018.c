/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 4500 ; VA 0x0059baa0 ; FUN_0059baa0 */

int * FUN_0059baa0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x25,0x18,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x25,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(0x18);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__GetExpirationResponse::vftable;
        *(undefined8 *)(puVar2 + 2) = 0;
        puVar2[4] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[4] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4501 ; VA 0x0059bbc0 ; FUN_0059bbc0 */

int * FUN_0059bbc0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x12,8,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x12,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(8);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__GetStatus::vftable;
        puVar2[1] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[1] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4502 ; VA 0x0059bcd0 ; FUN_0059bcd0 */

int * FUN_0059bcd0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x13,0xc,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x13,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(0xc);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__GetStatusResponse::vftable;
        puVar2[1] = 0;
        puVar2[2] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[2] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4503 ; VA 0x0059bdf0 ; FUN_0059bdf0 */

int * FUN_0059bdf0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x10,8,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x10,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(8);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__GetVersion::vftable;
        puVar2[1] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[1] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4504 ; VA 0x0059bf00 ; FUN_0059bf00 */

undefined4 * FUN_0059bf00(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if ((iVar1 == 0) &&
     ((param_3 != (undefined4 *)0x0 ||
      (param_3 = (undefined4 *)FUN_005b7fc0(param_1,4), param_3 != (undefined4 *)0x0)))) {
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
      FUN_005bb7f0(param_1);
      piVar2 = (int *)FUN_005a70c0(param_1,0xffffffff,param_1 + 0x144b4,param_1 + 0x148b4,0);
      *param_3 = piVar2;
      if (piVar2 == (int *)0x0) {
        return (undefined4 *)0x0;
      }
      (**(code **)(*piVar2 + 4))(param_1);
      iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
    }
    else {
      param_3 = (undefined4 *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x11,0x20,0);
      if (*(short *)(param_1 + 0x309a) == 0) {
        return param_3;
      }
      iVar1 = FUN_005b3cc0(param_1,param_2);
    }
    if (iVar1 == 0) {
      return param_3;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4505 ; VA 0x0059bfd0 ; FUN_0059bfd0 */

int * FUN_0059bfd0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0xe,8,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0xe,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(8);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__HelloWorld::vftable;
        puVar2[1] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[1] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4506 ; VA 0x0059c0e0 ; FUN_0059c0e0 */

int * FUN_0059c0e0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0xf,0xc,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0xf,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(0xc);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__HelloWorldResponse::vftable;
        puVar2[1] = 0;
        puVar2[2] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[2] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4507 ; VA 0x0059c200 ; FUN_0059c200 */

int * FUN_0059c200(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x14,0x10,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x14,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(0x10);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__OpenJob::vftable;
        puVar2[1] = 0;
        puVar2[2] = 0;
        puVar2[3] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[3] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4508 ; VA 0x0059c320 ; FUN_0059c320 */

int * FUN_0059c320(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x15,0x10,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x15,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(0x10);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__OpenJobEx::vftable;
        puVar2[1] = 0;
        puVar2[2] = 0;
        puVar2[3] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[3] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4509 ; VA 0x0059c440 ; FUN_0059c440 */

int * FUN_0059c440(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x17,0xc,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x17,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(0xc);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__OpenJobExResponse::vftable;
        puVar2[1] = 0;
        puVar2[2] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[2] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4510 ; VA 0x0059c560 ; FUN_0059c560 */

undefined4 * FUN_0059c560(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if ((iVar1 == 0) &&
     ((param_3 != (undefined4 *)0x0 ||
      (param_3 = (undefined4 *)FUN_005b7fc0(param_1,4), param_3 != (undefined4 *)0x0)))) {
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
      FUN_005bb7f0(param_1);
      piVar2 = (int *)FUN_005a78b0(param_1,0xffffffff,param_1 + 0x144b4,param_1 + 0x148b4,0);
      *param_3 = piVar2;
      if (piVar2 == (int *)0x0) {
        return (undefined4 *)0x0;
      }
      (**(code **)(*piVar2 + 4))(param_1);
      iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
    }
    else {
      param_3 = (undefined4 *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x16,0x14,0);
      if (*(short *)(param_1 + 0x309a) == 0) {
        return param_3;
      }
      iVar1 = FUN_005b3cc0(param_1,param_2);
    }
    if (iVar1 == 0) {
      return param_3;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4511 ; VA 0x0059c630 ; FUN_0059c630 */

undefined4 * FUN_0059c630(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if ((iVar1 == 0) &&
     ((param_3 != (undefined4 *)0x0 ||
      (param_3 = (undefined4 *)FUN_005b7fc0(param_1,4), param_3 != (undefined4 *)0x0)))) {
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
      FUN_005bb7f0(param_1);
      piVar2 = (int *)FUN_005a7a10(param_1,0xffffffff,param_1 + 0x144b4,param_1 + 0x148b4,0);
      *param_3 = piVar2;
      if (piVar2 == (int *)0x0) {
        return (undefined4 *)0x0;
      }
      (**(code **)(*piVar2 + 4))(param_1);
      iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
    }
    else {
      param_3 = (undefined4 *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x18,0x30,0);
      if (*(short *)(param_1 + 0x309a) == 0) {
        return param_3;
      }
      iVar1 = FUN_005b3cc0(param_1,param_2);
    }
    if (iVar1 == 0) {
      return param_3;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4512 ; VA 0x0059c700 ; FUN_0059c700 */

int * FUN_0059c700(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x19,0x18,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,0x19,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(0x18);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = _ns1__RenewLeaseResponse::vftable;
        *(undefined8 *)(puVar2 + 2) = 0;
        puVar2[4] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[4] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4513 ; VA 0x0059c820 ; FUN_0059c820 */

undefined4 * FUN_0059c820(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if ((iVar1 == 0) &&
     ((param_3 != (undefined4 *)0x0 ||
      (param_3 = (undefined4 *)FUN_005b7fc0(param_1,4), param_3 != (undefined4 *)0x0)))) {
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
      FUN_005bb7f0(param_1);
      piVar2 = (int *)FUN_005a7cc0(param_1,0xffffffff,param_1 + 0x144b4,param_1 + 0x148b4,0);
      *param_3 = piVar2;
      if (piVar2 == (int *)0x0) {
        return (undefined4 *)0x0;
      }
      (**(code **)(*piVar2 + 4))(param_1);
      iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
    }
    else {
      param_3 = (undefined4 *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0xc,0x14,0);
      if (*(short *)(param_1 + 0x309a) == 0) {
        return param_3;
      }
      iVar1 = FUN_005b3cc0(param_1,param_2);
    }
    if (iVar1 == 0) {
      return param_3;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4514 ; VA 0x0059c8f0 ; FUN_0059c8f0 */

undefined4 * FUN_0059c8f0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if ((iVar1 == 0) &&
     ((param_3 != (undefined4 *)0x0 ||
      (param_3 = (undefined4 *)FUN_005b7fc0(param_1,4), param_3 != (undefined4 *)0x0)))) {
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
      FUN_005bb7f0(param_1);
      piVar2 = (int *)FUN_005a7e20(param_1,0xffffffff,param_1 + 0x144b4,param_1 + 0x148b4,0);
      *param_3 = piVar2;
      if (piVar2 == (int *)0x0) {
        return (undefined4 *)0x0;
      }
      (**(code **)(*piVar2 + 4))(param_1);
      iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
    }
    else {
      param_3 = (undefined4 *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0xb,0x14,0);
      if (*(short *)(param_1 + 0x309a) == 0) {
        return param_3;
      }
      iVar1 = FUN_005b3cc0(param_1,param_2);
    }
    if (iVar1 == 0) {
      return param_3;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4515 ; VA 0x0059c9c0 ; FUN_0059c9c0 */

undefined4 * FUN_0059c9c0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if ((iVar1 == 0) &&
     ((param_3 != (undefined4 *)0x0 ||
      (param_3 = (undefined4 *)FUN_005b7fc0(param_1,4), param_3 != (undefined4 *)0x0)))) {
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
      FUN_005bb7f0(param_1);
      piVar2 = (int *)FUN_005a7f80(param_1,0xffffffff,param_1 + 0x144b4,param_1 + 0x148b4,0);
      *param_3 = piVar2;
      if (piVar2 == (int *)0x0) {
        return (undefined4 *)0x0;
      }
      (**(code **)(*piVar2 + 4))(param_1);
      iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
    }
    else {
      param_3 = (undefined4 *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,9,0x40,0);
      if (*(short *)(param_1 + 0x309a) == 0) {
        return param_3;
      }
      iVar1 = FUN_005b3cc0(param_1,param_2);
    }
    if (iVar1 == 0) {
      return param_3;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4516 ; VA 0x0059ca90 ; FUN_0059ca90 */

undefined4 * FUN_0059ca90(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if ((iVar1 == 0) &&
     ((param_3 != (undefined4 *)0x0 ||
      (param_3 = (undefined4 *)FUN_005b7fc0(param_1,4), param_3 != (undefined4 *)0x0)))) {
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
      FUN_005bb7f0(param_1);
      piVar2 = (int *)FUN_005a80f0(param_1,0xffffffff,param_1 + 0x144b4,param_1 + 0x148b4,0);
      *param_3 = piVar2;
      if (piVar2 == (int *)0x0) {
        return (undefined4 *)0x0;
      }
      (**(code **)(*piVar2 + 4))(param_1);
      iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
    }
    else {
      param_3 = (undefined4 *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0xd,0x14,0);
      if (*(short *)(param_1 + 0x309a) == 0) {
        return param_3;
      }
      iVar1 = FUN_005b3cc0(param_1,param_2);
    }
    if (iVar1 == 0) {
      return param_3;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4517 ; VA 0x0059cb60 ; FUN_0059cb60 */

undefined4 * FUN_0059cb60(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if ((iVar1 == 0) &&
     ((param_3 != (undefined4 *)0x0 ||
      (param_3 = (undefined4 *)FUN_005b7fc0(param_1,4), param_3 != (undefined4 *)0x0)))) {
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
      FUN_005bb7f0(param_1);
      piVar2 = (int *)FUN_005a8250(param_1,0xffffffff,param_1 + 0x144b4,param_1 + 0x148b4,0);
      *param_3 = piVar2;
      if (piVar2 == (int *)0x0) {
        return (undefined4 *)0x0;
      }
      (**(code **)(*piVar2 + 4))(param_1);
      iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
    }
    else {
      param_3 = (undefined4 *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,10,0x14,0);
      if (*(short *)(param_1 + 0x309a) == 0) {
        return param_3;
      }
      iVar1 = FUN_005b3cc0(param_1,param_2);
    }
    if (iVar1 == 0) {
      return param_3;
    }
  }
  return (undefined4 *)0x0;
}



/* FUNCTION 4518 ; VA 0x0059cc30 ; FUN_0059cc30 */

int * FUN_0059cc30(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 == 0) {
    if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0)
       ) {
      return (int *)0x0;
    }
    *param_3 = 0;
    if ((*(short *)(param_1 + 0x15504) != 0) || (*(char *)(param_1 + 0x140b4) == '#')) {
      piVar3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,8,0x10,0);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar3;
    }
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005b7ec0(param_1,0,8,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      *param_3 = 0;
    }
    else {
      puVar2 = (undefined4 *)FUN_01674e20(0x10);
      if (puVar2 == (undefined4 *)0x0) {
        puVar2 = (undefined4 *)0x0;
      }
      else {
        *puVar2 = ns1__Status::vftable;
        puVar2[1] = 0;
        puVar2[2] = 0;
        puVar2[3] = 0;
      }
      *(undefined4 **)(iVar1 + 4) = puVar2;
      puVar2[3] = param_1;
      piVar3 = *(int **)(iVar1 + 4);
      *param_3 = (int)piVar3;
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 4))(param_1);
        iVar1 = (**(code **)(*(int *)*param_3 + 0x18))(param_1,param_2,0);
        if (iVar1 != 0) {
          return param_3;
        }
        return (int *)0x0;
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4519 ; VA 0x0059cd50 ; FUN_0059cd50 */

int * FUN_0059cd50(int param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int iVar1;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 != 0) {
    return (int *)0x0;
  }
  if ((param_3 == (int *)0x0) && (param_3 = (int *)FUN_005b7fc0(param_1,4), param_3 == (int *)0x0))
  {
    return (int *)0x0;
  }
  *param_3 = 0;
  if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
    FUN_005bb7f0(param_1);
    iVar1 = FUN_005a2880(param_1,param_2,*param_3,param_4);
    *param_3 = iVar1;
    if (iVar1 == 0) {
      return (int *)0x0;
    }
  }
  else {
    param_3 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),param_3,0x33,0x18,0);
    if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0))
    {
      return (int *)0x0;
    }
  }
  return param_3;
}



/* FUNCTION 4520 ; VA 0x0059ce00 ; FUN_0059ce00 */

int FUN_0059ce00(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,param_4);
  if ((iVar1 == 0) &&
     (iVar1 = FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,0xab,1,0,0,0,0), iVar1 != 0)) {
    if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
      iVar1 = FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),iVar1,0,0xab,0,1,0,0);
      if ((*(short *)(param_1 + 0x309a) == 0) || (iVar2 = FUN_005b3cc0(param_1,param_2), iVar2 == 0)
         ) {
        return iVar1;
      }
    }
    else {
      do {
        *(undefined4 *)(param_1 + 0x1615c) = 3;
        iVar2 = FUN_00599d40(param_1);
        *(int *)(param_1 + 0x1615c) = iVar2;
        if (iVar2 == 6) {
          iVar2 = FUN_005b3cc0(param_1,param_2);
          if (iVar2 == 0) {
            return iVar1;
          }
          return 0;
        }
      } while (iVar2 == 0);
    }
  }
  return 0;
}



/* FUNCTION 4521 ; VA 0x0059cee0 ; FUN_0059cee0 */

int * FUN_0059cee0(int param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  short sVar6;
  
  sVar6 = 1;
  piVar2 = (int *)FUN_005b6e40(param_1,&DAT_018bc9b8,param_3,0x66,4,0,0,0,0);
  if (piVar2 == (int *)0x0) {
    return (int *)0x0;
  }
  *piVar2 = 0;
  bVar1 = false;
  while (*(undefined4 *)(param_1 + 0x1615c) = 3, sVar6 != 0) {
    iVar3 = FUN_005b3b70(param_1,"ns1:BatchJob",1,0);
    if (iVar3 == 0) {
      *piVar2 = 0;
      if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
        FUN_005bb7f0(param_1);
        iVar3 = FUN_005b7ec0(param_1,0,0x20,0xffffffff,FUN_00598780);
        if (iVar3 == 0) {
          *piVar2 = 0;
        }
        else {
          puVar4 = (undefined4 *)FUN_01674e20(0x10);
          if (puVar4 == (undefined4 *)0x0) {
            puVar4 = (undefined4 *)0x0;
          }
          else {
            *puVar4 = _ns1__BatchJob::vftable;
            puVar4[1] = 0;
            puVar4[2] = 0;
            puVar4[3] = 0;
          }
          *(undefined4 **)(iVar3 + 4) = puVar4;
          puVar4[3] = param_1;
          piVar5 = *(int **)(iVar3 + 4);
          *piVar2 = (int)piVar5;
          if (piVar5 != (int *)0x0) {
            (**(code **)(*piVar5 + 4))(param_1);
            iVar3 = (**(code **)(*(int *)*piVar2 + 0x18))(param_1,"ns1:BatchJob",0);
            piVar5 = piVar2;
            goto joined_r0x0059d04e;
          }
        }
        goto LAB_0059cf90;
      }
      piVar5 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),piVar2,0x20,0x10,0);
      if (*(short *)(param_1 + 0x309a) != 0) {
        iVar3 = FUN_005b3cc0(param_1,"ns1:BatchJob");
joined_r0x0059d04e:
        if (iVar3 != 0) goto LAB_0059cf90;
      }
      if (piVar5 == (int *)0x0) goto LAB_0059cf90;
      sVar6 = sVar6 + -1;
      bVar1 = true;
    }
    else {
LAB_0059cf90:
      iVar3 = *(int *)(param_1 + 0x1615c);
      if (iVar3 == 3) break;
      if (iVar3 == 6) {
        return piVar2;
      }
      if (iVar3 != 0) {
        return (int *)0x0;
      }
      bVar1 = true;
    }
  }
  if (bVar1) {
    *(undefined4 *)(param_1 + 0x1615c) = 0;
    return piVar2;
  }
  return (int *)0x0;
}



/* FUNCTION 4522 ; VA 0x0059d0a0 ; FUN_0059d0a0 */

int * FUN_0059d0a0(int param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  short sVar6;
  
  sVar6 = 1;
  piVar2 = (int *)FUN_005b6e40(param_1,&DAT_018bc9b8,param_3,0x6a,4,0,0,0,0);
  if (piVar2 == (int *)0x0) {
    return (int *)0x0;
  }
  *piVar2 = 0;
  bVar1 = false;
  while (*(undefined4 *)(param_1 + 0x1615c) = 3, sVar6 != 0) {
    iVar3 = FUN_005b3b70(param_1,"ns1:BatchJobEx",1,0);
    if (iVar3 == 0) {
      *piVar2 = 0;
      if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
        FUN_005bb7f0(param_1);
        iVar3 = FUN_005b7ec0(param_1,0,0x22,0xffffffff,FUN_00598780);
        if (iVar3 == 0) {
          *piVar2 = 0;
        }
        else {
          puVar4 = (undefined4 *)FUN_01674e20(0x10);
          if (puVar4 == (undefined4 *)0x0) {
            puVar4 = (undefined4 *)0x0;
          }
          else {
            *puVar4 = _ns1__BatchJobEx::vftable;
            puVar4[1] = 0;
            puVar4[2] = 0;
            puVar4[3] = 0;
          }
          *(undefined4 **)(iVar3 + 4) = puVar4;
          puVar4[3] = param_1;
          piVar5 = *(int **)(iVar3 + 4);
          *piVar2 = (int)piVar5;
          if (piVar5 != (int *)0x0) {
            (**(code **)(*piVar5 + 4))(param_1);
            iVar3 = (**(code **)(*(int *)*piVar2 + 0x18))(param_1,"ns1:BatchJobEx",0);
            piVar5 = piVar2;
            goto joined_r0x0059d20e;
          }
        }
        goto LAB_0059d150;
      }
      piVar5 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),piVar2,0x22,0x10,0);
      if (*(short *)(param_1 + 0x309a) != 0) {
        iVar3 = FUN_005b3cc0(param_1,"ns1:BatchJobEx");
joined_r0x0059d20e:
        if (iVar3 != 0) goto LAB_0059d150;
      }
      if (piVar5 == (int *)0x0) goto LAB_0059d150;
      sVar6 = sVar6 + -1;
      bVar1 = true;
    }
    else {
LAB_0059d150:
      iVar3 = *(int *)(param_1 + 0x1615c);
      if (iVar3 == 3) break;
      if (iVar3 == 6) {
        return piVar2;
      }
      if (iVar3 != 0) {
        return (int *)0x0;
      }
      bVar1 = true;
    }
  }
  if (bVar1) {
    *(undefined4 *)(param_1 + 0x1615c) = 0;
    return piVar2;
  }
  return (int *)0x0;
}



/* FUNCTION 4523 ; VA 0x0059d260 ; FUN_0059d260 */

int * FUN_0059d260(int param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  short sVar6;
  
  sVar6 = 1;
  piVar2 = (int *)FUN_005b6e40(param_1,&DAT_018bc9b8,param_3,0x7e,4,0,0,0,0);
  if (piVar2 == (int *)0x0) {
    return (int *)0x0;
  }
  *piVar2 = 0;
  bVar1 = false;
  while (*(undefined4 *)(param_1 + 0x1615c) = 3, sVar6 != 0) {
    iVar3 = FUN_005b3b70(param_1,"ns1:CloseAllJobs",1,0);
    if (iVar3 == 0) {
      *piVar2 = 0;
      if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
        FUN_005bb7f0(param_1);
        iVar3 = FUN_005b7ec0(param_1,0,0x2c,0xffffffff,FUN_00598780);
        if (iVar3 == 0) {
          *piVar2 = 0;
        }
        else {
          puVar4 = (undefined4 *)FUN_01674e20(8);
          if (puVar4 == (undefined4 *)0x0) {
            puVar4 = (undefined4 *)0x0;
          }
          else {
            *puVar4 = _ns1__CloseAllJobs::vftable;
            puVar4[1] = 0;
          }
          *(undefined4 **)(iVar3 + 4) = puVar4;
          puVar4[1] = param_1;
          piVar5 = *(int **)(iVar3 + 4);
          *piVar2 = (int)piVar5;
          if (piVar5 != (int *)0x0) {
            (**(code **)(*piVar5 + 4))(param_1);
            iVar3 = (**(code **)(*(int *)*piVar2 + 0x18))(param_1,"ns1:CloseAllJobs",0);
            piVar5 = piVar2;
            goto joined_r0x0059d3bc;
          }
        }
        goto LAB_0059d310;
      }
      piVar5 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),piVar2,0x2c,8,0);
      if (*(short *)(param_1 + 0x309a) != 0) {
        iVar3 = FUN_005b3cc0(param_1,"ns1:CloseAllJobs");
joined_r0x0059d3bc:
        if (iVar3 != 0) goto LAB_0059d310;
      }
      if (piVar5 == (int *)0x0) goto LAB_0059d310;
      sVar6 = sVar6 + -1;
      bVar1 = true;
    }
    else {
LAB_0059d310:
      iVar3 = *(int *)(param_1 + 0x1615c);
      if (iVar3 == 3) break;
      if (iVar3 == 6) {
        return piVar2;
      }
      if (iVar3 != 0) {
        return (int *)0x0;
      }
      bVar1 = true;
    }
  }
  if (bVar1) {
    *(undefined4 *)(param_1 + 0x1615c) = 0;
    return piVar2;
  }
  return (int *)0x0;
}



/* FUNCTION 4524 ; VA 0x0059d400 ; FUN_0059d400 */

int * FUN_0059d400(int param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  short sVar6;
  
  sVar6 = 1;
  piVar2 = (int *)FUN_005b6e40(param_1,&DAT_018bc9b8,param_3,0x7a,4,0,0,0,0);
  if (piVar2 == (int *)0x0) {
    return (int *)0x0;
  }
  *piVar2 = 0;
  bVar1 = false;
  while (*(undefined4 *)(param_1 + 0x1615c) = 3, sVar6 != 0) {
    iVar3 = FUN_005b3b70(param_1,"ns1:CloseExpiredJobs",1,0);
    if (iVar3 == 0) {
      *piVar2 = 0;
      if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
        FUN_005bb7f0(param_1);
        iVar3 = FUN_005b7ec0(param_1,0,0x2a,0xffffffff,FUN_00598780);
        if (iVar3 == 0) {
          *piVar2 = 0;
        }
        else {
          puVar4 = (undefined4 *)FUN_01674e20(8);
          if (puVar4 == (undefined4 *)0x0) {
            puVar4 = (undefined4 *)0x0;
          }
          else {
            *puVar4 = _ns1__CloseExpiredJobs::vftable;
            puVar4[1] = 0;
          }
          *(undefined4 **)(iVar3 + 4) = puVar4;
          puVar4[1] = param_1;
          piVar5 = *(int **)(iVar3 + 4);
          *piVar2 = (int)piVar5;
          if (piVar5 != (int *)0x0) {
            (**(code **)(*piVar5 + 4))(param_1);
            iVar3 = (**(code **)(*(int *)*piVar2 + 0x18))(param_1,"ns1:CloseExpiredJobs",0);
            piVar5 = piVar2;
            goto joined_r0x0059d55c;
          }
        }
        goto LAB_0059d4b0;
      }
      piVar5 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),piVar2,0x2a,8,0);
      if (*(short *)(param_1 + 0x309a) != 0) {
        iVar3 = FUN_005b3cc0(param_1,"ns1:CloseExpiredJobs");
joined_r0x0059d55c:
        if (iVar3 != 0) goto LAB_0059d4b0;
      }
      if (piVar5 == (int *)0x0) goto LAB_0059d4b0;
      sVar6 = sVar6 + -1;
      bVar1 = true;
    }
    else {
LAB_0059d4b0:
      iVar3 = *(int *)(param_1 + 0x1615c);
      if (iVar3 == 3) break;
      if (iVar3 == 6) {
        return piVar2;
      }
      if (iVar3 != 0) {
        return (int *)0x0;
      }
      bVar1 = true;
    }
  }
  if (bVar1) {
    *(undefined4 *)(param_1 + 0x1615c) = 0;
    return piVar2;
  }
  return (int *)0x0;
}



/* FUNCTION 4525 ; VA 0x0059d5a0 ; FUN_0059d5a0 */

int * FUN_0059d5a0(int param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  short sVar6;
  
  sVar6 = 1;
  piVar2 = (int *)FUN_005b6e40(param_1,&DAT_018bc9b8,param_3,0x82,4,0,0,0,0);
  if (piVar2 == (int *)0x0) {
    return (int *)0x0;
  }
  *piVar2 = 0;
  bVar1 = false;
  while (*(undefined4 *)(param_1 + 0x1615c) = 3, sVar6 != 0) {
    iVar3 = FUN_005b3b70(param_1,"ns1:Diag",1,0);
    if (iVar3 == 0) {
      *piVar2 = 0;
      if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
        FUN_005bb7f0(param_1);
        iVar3 = FUN_005b7ec0(param_1,0,0x2e,0xffffffff,FUN_00598780);
        if (iVar3 == 0) {
          *piVar2 = 0;
        }
        else {
          puVar4 = (undefined4 *)FUN_01674e20(0x10);
          if (puVar4 == (undefined4 *)0x0) {
            puVar4 = (undefined4 *)0x0;
          }
          else {
            *puVar4 = _ns1__Diag::vftable;
            puVar4[1] = 0;
            puVar4[2] = 0;
            puVar4[3] = 0;
          }
          *(undefined4 **)(iVar3 + 4) = puVar4;
          puVar4[3] = param_1;
          piVar5 = *(int **)(iVar3 + 4);
          *piVar2 = (int)piVar5;
          if (piVar5 != (int *)0x0) {
            (**(code **)(*piVar5 + 4))(param_1);
            iVar3 = (**(code **)(*(int *)*piVar2 + 0x18))(param_1,"ns1:Diag",0);
            piVar5 = piVar2;
            goto joined_r0x0059d711;
          }
        }
        goto LAB_0059d653;
      }
      piVar5 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),piVar2,0x2e,0x10,0);
      if (*(short *)(param_1 + 0x309a) != 0) {
        iVar3 = FUN_005b3cc0(param_1,"ns1:Diag");
joined_r0x0059d711:
        if (iVar3 != 0) goto LAB_0059d653;
      }
      if (piVar5 == (int *)0x0) goto LAB_0059d653;
      sVar6 = sVar6 + -1;
      bVar1 = true;
    }
    else {
LAB_0059d653:
      iVar3 = *(int *)(param_1 + 0x1615c);
      if (iVar3 == 3) break;
      if (iVar3 == 6) {
        return piVar2;
      }
      if (iVar3 != 0) {
        return (int *)0x0;
      }
      bVar1 = true;
    }
  }
  if (bVar1) {
    *(undefined4 *)(param_1 + 0x1615c) = 0;
    return piVar2;
  }
  return (int *)0x0;
}



/* FUNCTION 4526 ; VA 0x0059d760 ; FUN_0059d760 */

int * FUN_0059d760(int param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  short sVar6;
  
  sVar6 = 1;
  piVar2 = (int *)FUN_005b6e40(param_1,&DAT_018bc9b8,param_3,0x86,4,0,0,0,0);
  if (piVar2 == (int *)0x0) {
    return (int *)0x0;
  }
  *piVar2 = 0;
  bVar1 = false;
  while (*(undefined4 *)(param_1 + 0x1615c) = 3, sVar6 != 0) {
    iVar3 = FUN_005b3b70(param_1,"ns1:DiagEx",1,0);
    if (iVar3 == 0) {
      *piVar2 = 0;
      if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
        FUN_005bb7f0(param_1);
        iVar3 = FUN_005b7ec0(param_1,0,0x30,0xffffffff,FUN_00598780);
        if (iVar3 == 0) {
          *piVar2 = 0;
        }
        else {
          puVar4 = (undefined4 *)FUN_01674e20(0x10);
          if (puVar4 == (undefined4 *)0x0) {
            puVar4 = (undefined4 *)0x0;
          }
          else {
            *puVar4 = _ns1__DiagEx::vftable;
            puVar4[1] = 0;
            puVar4[2] = 0;
            puVar4[3] = 0;
          }
          *(undefined4 **)(iVar3 + 4) = puVar4;
          puVar4[3] = param_1;
          piVar5 = *(int **)(iVar3 + 4);
          *piVar2 = (int)piVar5;
          if (piVar5 != (int *)0x0) {
            (**(code **)(*piVar5 + 4))(param_1);
            iVar3 = (**(code **)(*(int *)*piVar2 + 0x18))(param_1,"ns1:DiagEx",0);
            piVar5 = piVar2;
            goto joined_r0x0059d8d1;
          }
        }
        goto LAB_0059d813;
      }
      piVar5 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),piVar2,0x30,0x10,0);
      if (*(short *)(param_1 + 0x309a) != 0) {
        iVar3 = FUN_005b3cc0(param_1,"ns1:DiagEx");
joined_r0x0059d8d1:
        if (iVar3 != 0) goto LAB_0059d813;
      }
      if (piVar5 == (int *)0x0) goto LAB_0059d813;
      sVar6 = sVar6 + -1;
      bVar1 = true;
    }
    else {
LAB_0059d813:
      iVar3 = *(int *)(param_1 + 0x1615c);
      if (iVar3 == 3) break;
      if (iVar3 == 6) {
        return piVar2;
      }
      if (iVar3 != 0) {
        return (int *)0x0;
      }
      bVar1 = true;
    }
  }
  if (bVar1) {
    *(undefined4 *)(param_1 + 0x1615c) = 0;
    return piVar2;
  }
  return (int *)0x0;
}



/* FUNCTION 4527 ; VA 0x0059d920 ; FUN_0059d920 */

int * FUN_0059d920(int param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  short sVar6;
  
  sVar6 = 1;
  piVar2 = (int *)FUN_005b6e40(param_1,&DAT_018bc9b8,param_3,0x72,4,0,0,0,0);
  if (piVar2 == (int *)0x0) {
    return (int *)0x0;
  }
  *piVar2 = 0;
  bVar1 = false;
  while (*(undefined4 *)(param_1 + 0x1615c) = 3, sVar6 != 0) {
    iVar3 = FUN_005b3b70(param_1,"ns1:GetAllJobs",1,0);
    if (iVar3 == 0) {
      *piVar2 = 0;
      if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
        FUN_005bb7f0(param_1);
        iVar3 = FUN_005b7ec0(param_1,0,0x26,0xffffffff,FUN_00598780);
        if (iVar3 == 0) {
          *piVar2 = 0;
        }
        else {
          puVar4 = (undefined4 *)FUN_01674e20(8);
          if (puVar4 == (undefined4 *)0x0) {
            puVar4 = (undefined4 *)0x0;
          }
          else {
            *puVar4 = _ns1__GetAllJobs::vftable;
            puVar4[1] = 0;
          }
          *(undefined4 **)(iVar3 + 4) = puVar4;
          puVar4[1] = param_1;
          piVar5 = *(int **)(iVar3 + 4);
          *piVar2 = (int)piVar5;
          if (piVar5 != (int *)0x0) {
            (**(code **)(*piVar5 + 4))(param_1);
            iVar3 = (**(code **)(*(int *)*piVar2 + 0x18))(param_1,"ns1:GetAllJobs",0);
            piVar5 = piVar2;
            goto joined_r0x0059da7c;
          }
        }
        goto LAB_0059d9d0;
      }
      piVar5 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),piVar2,0x26,8,0);
      if (*(short *)(param_1 + 0x309a) != 0) {
        iVar3 = FUN_005b3cc0(param_1,"ns1:GetAllJobs");
joined_r0x0059da7c:
        if (iVar3 != 0) goto LAB_0059d9d0;
      }
      if (piVar5 == (int *)0x0) goto LAB_0059d9d0;
      sVar6 = sVar6 + -1;
      bVar1 = true;
    }
    else {
LAB_0059d9d0:
      iVar3 = *(int *)(param_1 + 0x1615c);
      if (iVar3 == 3) break;
      if (iVar3 == 6) {
        return piVar2;
      }
      if (iVar3 != 0) {
        return (int *)0x0;
      }
      bVar1 = true;
    }
  }
  if (bVar1) {
    *(undefined4 *)(param_1 + 0x1615c) = 0;
    return piVar2;
  }
  return (int *)0x0;
}



/* FUNCTION 4528 ; VA 0x0059dac0 ; FUN_0059dac0 */

int * FUN_0059dac0(int param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  short sVar6;
  
  sVar6 = 1;
  piVar2 = (int *)FUN_005b6e40(param_1,&DAT_018bc9b8,param_3,0x76,4,0,0,0,0);
  if (piVar2 == (int *)0x0) {
    return (int *)0x0;
  }
  *piVar2 = 0;
  bVar1 = false;
  while (*(undefined4 *)(param_1 + 0x1615c) = 3, sVar6 != 0) {
    iVar3 = FUN_005b3b70(param_1,"ns1:GetAllJobsEx",1,0);
    if (iVar3 == 0) {
      *piVar2 = 0;
      if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
        FUN_005bb7f0(param_1);
        iVar3 = FUN_005b7ec0(param_1,0,0x28,0xffffffff,FUN_00598780);
        if (iVar3 == 0) {
          *piVar2 = 0;
        }
        else {
          puVar4 = (undefined4 *)FUN_01674e20(8);
          if (puVar4 == (undefined4 *)0x0) {
            puVar4 = (undefined4 *)0x0;
          }
          else {
            *puVar4 = _ns1__GetAllJobsEx::vftable;
            puVar4[1] = 0;
          }
          *(undefined4 **)(iVar3 + 4) = puVar4;
          puVar4[1] = param_1;
          piVar5 = *(int **)(iVar3 + 4);
          *piVar2 = (int)piVar5;
          if (piVar5 != (int *)0x0) {
            (**(code **)(*piVar5 + 4))(param_1);
            iVar3 = (**(code **)(*(int *)*piVar2 + 0x18))(param_1,"ns1:GetAllJobsEx",0);
            piVar5 = piVar2;
            goto joined_r0x0059dc1c;
          }
        }
        goto LAB_0059db70;
      }
      piVar5 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),piVar2,0x28,8,0);
      if (*(short *)(param_1 + 0x309a) != 0) {
        iVar3 = FUN_005b3cc0(param_1,"ns1:GetAllJobsEx");
joined_r0x0059dc1c:
        if (iVar3 != 0) goto LAB_0059db70;
      }
      if (piVar5 == (int *)0x0) goto LAB_0059db70;
      sVar6 = sVar6 + -1;
      bVar1 = true;
    }
    else {
LAB_0059db70:
      iVar3 = *(int *)(param_1 + 0x1615c);
      if (iVar3 == 3) break;
      if (iVar3 == 6) {
        return piVar2;
      }
      if (iVar3 != 0) {
        return (int *)0x0;
      }
      bVar1 = true;
    }
  }
  if (bVar1) {
    *(undefined4 *)(param_1 + 0x1615c) = 0;
    return piVar2;
  }
  return (int *)0x0;
}



/* FUNCTION 4529 ; VA 0x0059dc60 ; FUN_0059dc60 */

int * FUN_0059dc60(int param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  short sVar6;
  
  sVar6 = 1;
  piVar2 = (int *)FUN_005b6e40(param_1,&DAT_018bc9b8,param_3,0x4a,4,0,0,0,0);
  if (piVar2 == (int *)0x0) {
    return (int *)0x0;
  }
  *piVar2 = 0;
  bVar1 = false;
  while (*(undefined4 *)(param_1 + 0x1615c) = 3, sVar6 != 0) {
    iVar3 = FUN_005b3b70(param_1,"ns1:GetStatus",1,0);
    if (iVar3 == 0) {
      *piVar2 = 0;
      if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
        FUN_005bb7f0(param_1);
        iVar3 = FUN_005b7ec0(param_1,0,0x12,0xffffffff,FUN_00598780);
        if (iVar3 == 0) {
          *piVar2 = 0;
        }
        else {
          puVar4 = (undefined4 *)FUN_01674e20(8);
          if (puVar4 == (undefined4 *)0x0) {
            puVar4 = (undefined4 *)0x0;
          }
          else {
            *puVar4 = _ns1__GetStatus::vftable;
            puVar4[1] = 0;
          }
          *(undefined4 **)(iVar3 + 4) = puVar4;
          puVar4[1] = param_1;
          piVar5 = *(int **)(iVar3 + 4);
          *piVar2 = (int)piVar5;
          if (piVar5 != (int *)0x0) {
            (**(code **)(*piVar5 + 4))(param_1);
            iVar3 = (**(code **)(*(int *)*piVar2 + 0x18))(param_1,"ns1:GetStatus",0);
            piVar5 = piVar2;
            goto joined_r0x0059ddbc;
          }
        }
        goto LAB_0059dd10;
      }
      piVar5 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),piVar2,0x12,8,0);
      if (*(short *)(param_1 + 0x309a) != 0) {
        iVar3 = FUN_005b3cc0(param_1,"ns1:GetStatus");
joined_r0x0059ddbc:
        if (iVar3 != 0) goto LAB_0059dd10;
      }
      if (piVar5 == (int *)0x0) goto LAB_0059dd10;
      sVar6 = sVar6 + -1;
      bVar1 = true;
    }
    else {
LAB_0059dd10:
      iVar3 = *(int *)(param_1 + 0x1615c);
      if (iVar3 == 3) break;
      if (iVar3 == 6) {
        return piVar2;
      }
      if (iVar3 != 0) {
        return (int *)0x0;
      }
      bVar1 = true;
    }
  }
  if (bVar1) {
    *(undefined4 *)(param_1 + 0x1615c) = 0;
    return piVar2;
  }
  return (int *)0x0;
}



/* FUNCTION 4530 ; VA 0x0059de00 ; FUN_0059de00 */

int * FUN_0059de00(int param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  short sVar6;
  
  sVar6 = 1;
  piVar2 = (int *)FUN_005b6e40(param_1,&DAT_018bc9b8,param_3,0x46,4,0,0,0,0);
  if (piVar2 == (int *)0x0) {
    return (int *)0x0;
  }
  *piVar2 = 0;
  bVar1 = false;
  while (*(undefined4 *)(param_1 + 0x1615c) = 3, sVar6 != 0) {
    iVar3 = FUN_005b3b70(param_1,"ns1:GetVersion",1,0);
    if (iVar3 == 0) {
      *piVar2 = 0;
      if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
        FUN_005bb7f0(param_1);
        iVar3 = FUN_005b7ec0(param_1,0,0x10,0xffffffff,FUN_00598780);
        if (iVar3 == 0) {
          *piVar2 = 0;
        }
        else {
          puVar4 = (undefined4 *)FUN_01674e20(8);
          if (puVar4 == (undefined4 *)0x0) {
            puVar4 = (undefined4 *)0x0;
          }
          else {
            *puVar4 = _ns1__GetVersion::vftable;
            puVar4[1] = 0;
          }
          *(undefined4 **)(iVar3 + 4) = puVar4;
          puVar4[1] = param_1;
          piVar5 = *(int **)(iVar3 + 4);
          *piVar2 = (int)piVar5;
          if (piVar5 != (int *)0x0) {
            (**(code **)(*piVar5 + 4))(param_1);
            iVar3 = (**(code **)(*(int *)*piVar2 + 0x18))(param_1,"ns1:GetVersion",0);
            piVar5 = piVar2;
            goto joined_r0x0059df5c;
          }
        }
        goto LAB_0059deb0;
      }
      piVar5 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),piVar2,0x10,8,0);
      if (*(short *)(param_1 + 0x309a) != 0) {
        iVar3 = FUN_005b3cc0(param_1,"ns1:GetVersion");
joined_r0x0059df5c:
        if (iVar3 != 0) goto LAB_0059deb0;
      }
      if (piVar5 == (int *)0x0) goto LAB_0059deb0;
      sVar6 = sVar6 + -1;
      bVar1 = true;
    }
    else {
LAB_0059deb0:
      iVar3 = *(int *)(param_1 + 0x1615c);
      if (iVar3 == 3) break;
      if (iVar3 == 6) {
        return piVar2;
      }
      if (iVar3 != 0) {
        return (int *)0x0;
      }
      bVar1 = true;
    }
  }
  if (bVar1) {
    *(undefined4 *)(param_1 + 0x1615c) = 0;
    return piVar2;
  }
  return (int *)0x0;
}



/* FUNCTION 4531 ; VA 0x0059dfb0 ; FUN_0059dfb0 */

int * FUN_0059dfb0(int param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  short sVar6;
  
  sVar6 = 1;
  piVar2 = (int *)FUN_005b6e40(param_1,&DAT_018bc9b8,param_3,0x42,4,0,0,0,0);
  if (piVar2 == (int *)0x0) {
    return (int *)0x0;
  }
  *piVar2 = 0;
  bVar1 = false;
  while (*(undefined4 *)(param_1 + 0x1615c) = 3, sVar6 != 0) {
    iVar3 = FUN_005b3b70(param_1,"ns1:HelloWorld",1,0);
    if (iVar3 == 0) {
      *piVar2 = 0;
      if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
        FUN_005bb7f0(param_1);
        iVar3 = FUN_005b7ec0(param_1,0,0xe,0xffffffff,FUN_00598780);
        if (iVar3 == 0) {
          *piVar2 = 0;
        }
        else {
          puVar4 = (undefined4 *)FUN_01674e20(8);
          if (puVar4 == (undefined4 *)0x0) {
            puVar4 = (undefined4 *)0x0;
          }
          else {
            *puVar4 = _ns1__HelloWorld::vftable;
            puVar4[1] = 0;
          }
          *(undefined4 **)(iVar3 + 4) = puVar4;
          puVar4[1] = param_1;
          piVar5 = *(int **)(iVar3 + 4);
          *piVar2 = (int)piVar5;
          if (piVar5 != (int *)0x0) {
            (**(code **)(*piVar5 + 4))(param_1);
            iVar3 = (**(code **)(*(int *)*piVar2 + 0x18))(param_1,"ns1:HelloWorld",0);
            piVar5 = piVar2;
            goto joined_r0x0059e10c;
          }
        }
        goto LAB_0059e060;
      }
      piVar5 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),piVar2,0xe,8,0);
      if (*(short *)(param_1 + 0x309a) != 0) {
        iVar3 = FUN_005b3cc0(param_1,"ns1:HelloWorld");
joined_r0x0059e10c:
        if (iVar3 != 0) goto LAB_0059e060;
      }
      if (piVar5 == (int *)0x0) goto LAB_0059e060;
      sVar6 = sVar6 + -1;
      bVar1 = true;
    }
    else {
LAB_0059e060:
      iVar3 = *(int *)(param_1 + 0x1615c);
      if (iVar3 == 3) break;
      if (iVar3 == 6) {
        return piVar2;
      }
      if (iVar3 != 0) {
        return (int *)0x0;
      }
      bVar1 = true;
    }
  }
  if (bVar1) {
    *(undefined4 *)(param_1 + 0x1615c) = 0;
    return piVar2;
  }
  return (int *)0x0;
}



/* FUNCTION 4532 ; VA 0x0059e150 ; FUN_0059e150 */

int * FUN_0059e150(int param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  short sVar6;
  
  sVar6 = 1;
  piVar2 = (int *)FUN_005b6e40(param_1,&DAT_018bc9b8,param_3,0x4e,4,0,0,0,0);
  if (piVar2 == (int *)0x0) {
    return (int *)0x0;
  }
  *piVar2 = 0;
  bVar1 = false;
  while (*(undefined4 *)(param_1 + 0x1615c) = 3, sVar6 != 0) {
    iVar3 = FUN_005b3b70(param_1,"ns1:OpenJob",1,0);
    if (iVar3 == 0) {
      *piVar2 = 0;
      if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
        FUN_005bb7f0(param_1);
        iVar3 = FUN_005b7ec0(param_1,0,0x14,0xffffffff,FUN_00598780);
        if (iVar3 == 0) {
          *piVar2 = 0;
        }
        else {
          puVar4 = (undefined4 *)FUN_01674e20(0x10);
          if (puVar4 == (undefined4 *)0x0) {
            puVar4 = (undefined4 *)0x0;
          }
          else {
            *puVar4 = _ns1__OpenJob::vftable;
            puVar4[1] = 0;
            puVar4[2] = 0;
            puVar4[3] = 0;
          }
          *(undefined4 **)(iVar3 + 4) = puVar4;
          puVar4[3] = param_1;
          piVar5 = *(int **)(iVar3 + 4);
          *piVar2 = (int)piVar5;
          if (piVar5 != (int *)0x0) {
            (**(code **)(*piVar5 + 4))(param_1);
            iVar3 = (**(code **)(*(int *)*piVar2 + 0x18))(param_1,"ns1:OpenJob",0);
            piVar5 = piVar2;
            goto joined_r0x0059e2be;
          }
        }
        goto LAB_0059e200;
      }
      piVar5 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),piVar2,0x14,0x10,0);
      if (*(short *)(param_1 + 0x309a) != 0) {
        iVar3 = FUN_005b3cc0(param_1,"ns1:OpenJob");
joined_r0x0059e2be:
        if (iVar3 != 0) goto LAB_0059e200;
      }
      if (piVar5 == (int *)0x0) goto LAB_0059e200;
      sVar6 = sVar6 + -1;
      bVar1 = true;
    }
    else {
LAB_0059e200:
      iVar3 = *(int *)(param_1 + 0x1615c);
      if (iVar3 == 3) break;
      if (iVar3 == 6) {
        return piVar2;
      }
      if (iVar3 != 0) {
        return (int *)0x0;
      }
      bVar1 = true;
    }
  }
  if (bVar1) {
    *(undefined4 *)(param_1 + 0x1615c) = 0;
    return piVar2;
  }
  return (int *)0x0;
}



/* FUNCTION 4533 ; VA 0x0059e310 ; FUN_0059e310 */

int * FUN_0059e310(int param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  short sVar6;
  
  sVar6 = 1;
  piVar2 = (int *)FUN_005b6e40(param_1,&DAT_018bc9b8,param_3,0x52,4,0,0,0,0);
  if (piVar2 == (int *)0x0) {
    return (int *)0x0;
  }
  *piVar2 = 0;
  bVar1 = false;
  while (*(undefined4 *)(param_1 + 0x1615c) = 3, sVar6 != 0) {
    iVar3 = FUN_005b3b70(param_1,"ns1:OpenJobEx",1,0);
    if (iVar3 == 0) {
      *piVar2 = 0;
      if ((*(short *)(param_1 + 0x15504) == 0) && (*(char *)(param_1 + 0x140b4) != '#')) {
        FUN_005bb7f0(param_1);
        iVar3 = FUN_005b7ec0(param_1,0,0x15,0xffffffff,FUN_00598780);
        if (iVar3 == 0) {
          *piVar2 = 0;
        }
        else {
          puVar4 = (undefined4 *)FUN_01674e20(0x10);
          if (puVar4 == (undefined4 *)0x0) {
            puVar4 = (undefined4 *)0x0;
          }
          else {
            *puVar4 = _ns1__OpenJobEx::vftable;
            puVar4[1] = 0;
            puVar4[2] = 0;
            puVar4[3] = 0;
          }
          *(undefined4 **)(iVar3 + 4) = puVar4;
          puVar4[3] = param_1;
          piVar5 = *(int **)(iVar3 + 4);
          *piVar2 = (int)piVar5;
          if (piVar5 != (int *)0x0) {
            (**(code **)(*piVar5 + 4))(param_1);
            iVar3 = (**(code **)(*(int *)*piVar2 + 0x18))(param_1,"ns1:OpenJobEx",0);
            piVar5 = piVar2;
            goto joined_r0x0059e47e;
          }
        }
        goto LAB_0059e3c0;
      }
      piVar5 = (int *)FUN_005b70d0(param_1,(char *)(param_1 + 0x140b4),piVar2,0x15,0x10,0);
      if (*(short *)(param_1 + 0x309a) != 0) {
        iVar3 = FUN_005b3cc0(param_1,"ns1:OpenJobEx");
joined_r0x0059e47e:
        if (iVar3 != 0) goto LAB_0059e3c0;
      }
      if (piVar5 == (int *)0x0) goto LAB_0059e3c0;
      sVar6 = sVar6 + -1;
      bVar1 = true;
    }
    else {
LAB_0059e3c0:
      iVar3 = *(int *)(param_1 + 0x1615c);
      if (iVar3 == 3) break;
      if (iVar3 == 6) {
        return piVar2;
      }
      if (iVar3 != 0) {
        return (int *)0x0;
      }
      bVar1 = true;
    }
  }
  if (bVar1) {
    *(undefined4 *)(param_1 + 0x1615c) = 0;
    return piVar2;
  }
  return (int *)0x0;
}



/* FUNCTION 4534 ; VA 0x0059e4d0 ; FUN_0059e4d0 */

int * FUN_0059e4d0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  short sVar3;
  short sVar4;
  short sVar5;
  short sVar6;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar1 == 0) {
    piVar2 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x20,0x10,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar2 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x20)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
        return piVar2;
      }
      sVar5 = 1;
      sVar3 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
        piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x20,0,0x10,0,
                                     FUN_005983c0);
        sVar6 = 1;
        sVar4 = 1;
        if ((*(short *)(param_1 + 0x309a) == 0) ||
           (iVar1 = FUN_005b3cc0(param_1,param_2), sVar6 = sVar5, sVar4 = sVar3, iVar1 == 0)) {
LAB_0059e679:
          if ((*(uint *)(param_1 + 8) & 0x1000) == 0) {
            return piVar2;
          }
          if ((sVar6 < 1) && (sVar4 < 1)) {
            return piVar2;
          }
          *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
        }
      }
      else {
LAB_0059e590:
        do {
          *(undefined4 *)(param_1 + 0x1615c) = 3;
          iVar1 = 3;
          if (sVar5 != 0) {
            iVar1 = FUN_0059c9c0(param_1,"ns1:job",piVar2 + 1,"ns1:Job");
            if (iVar1 != 0) {
              sVar5 = sVar5 + -1;
              goto LAB_0059e590;
            }
            iVar1 = *(int *)(param_1 + 0x1615c);
          }
          if (((sVar3 != 0) && (iVar1 == 3)) &&
             (iVar1 = FUN_0059cb60(param_1,"ns1:script",piVar2 + 2,"ns1:ScriptExecution"),
             iVar1 != 0)) {
            sVar3 = sVar3 + -1;
            goto LAB_0059e590;
          }
          iVar1 = *(int *)(param_1 + 0x1615c);
          if (iVar1 == 3) {
            iVar1 = FUN_00599d40(param_1);
            *(int *)(param_1 + 0x1615c) = iVar1;
          }
          if (iVar1 == 6) {
            iVar1 = FUN_005b3cc0(param_1,param_2);
            sVar6 = sVar5;
            sVar4 = sVar3;
            if (iVar1 != 0) {
              return (int *)0x0;
            }
            goto LAB_0059e679;
          }
        } while (iVar1 == 0);
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4535 ; VA 0x0059e6a0 ; FUN_0059e6a0 */

int * FUN_0059e6a0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  short sVar3;
  short sVar4;
  short sVar5;
  short sVar6;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar1 == 0) {
    piVar2 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x22,0x10,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar2 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x22)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
        return piVar2;
      }
      sVar5 = 1;
      sVar3 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
        piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x22,0,0x10,0,
                                     FUN_005983c0);
        sVar6 = 1;
        sVar4 = 1;
        if ((*(short *)(param_1 + 0x309a) == 0) ||
           (iVar1 = FUN_005b3cc0(param_1,param_2), sVar6 = sVar5, sVar4 = sVar3, iVar1 == 0)) {
LAB_0059e849:
          if ((*(uint *)(param_1 + 8) & 0x1000) == 0) {
            return piVar2;
          }
          if ((sVar6 < 1) && (sVar4 < 1)) {
            return piVar2;
          }
          *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
        }
      }
      else {
LAB_0059e760:
        do {
          *(undefined4 *)(param_1 + 0x1615c) = 3;
          iVar1 = 3;
          if (sVar5 != 0) {
            iVar1 = FUN_0059c9c0(param_1,"ns1:job",piVar2 + 1,"ns1:Job");
            if (iVar1 != 0) {
              sVar5 = sVar5 + -1;
              goto LAB_0059e760;
            }
            iVar1 = *(int *)(param_1 + 0x1615c);
          }
          if (((sVar3 != 0) && (iVar1 == 3)) &&
             (iVar1 = FUN_0059cb60(param_1,"ns1:script",piVar2 + 2,"ns1:ScriptExecution"),
             iVar1 != 0)) {
            sVar3 = sVar3 + -1;
            goto LAB_0059e760;
          }
          iVar1 = *(int *)(param_1 + 0x1615c);
          if (iVar1 == 3) {
            iVar1 = FUN_00599d40(param_1);
            *(int *)(param_1 + 0x1615c) = iVar1;
          }
          if (iVar1 == 6) {
            iVar1 = FUN_005b3cc0(param_1,param_2);
            sVar6 = sVar5;
            sVar4 = sVar3;
            if (iVar1 != 0) {
              return (int *)0x0;
            }
            goto LAB_0059e849;
          }
        } while (iVar1 == 0);
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4536 ; VA 0x0059e870 ; FUN_0059e870 */

int * FUN_0059e870(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short sVar1;
  int iVar2;
  int *piVar3;
  short sVar4;
  
  iVar2 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar2 == 0) {
    piVar3 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x23,0xc,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar3 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar3 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x23)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar3 = (int *)(**(code **)(*piVar3 + 0x18))(param_1,param_2,param_4);
        return piVar3;
      }
      sVar4 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (sVar1 = 1, *(char *)(param_1 + 0x140b4) != '\0'))
      {
        piVar3 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar3,0,0x23,0,0xc,0,
                                     FUN_005983e0);
        if ((*(short *)(param_1 + 0x309a) == 0) ||
           (iVar2 = FUN_005b3cc0(param_1,param_2), iVar2 == 0)) {
LAB_0059e9e4:
          if (((*(uint *)(param_1 + 8) & 0x1000) != 0) && (0 < sVar4)) {
            *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
            return (int *)0x0;
          }
          return piVar3;
        }
      }
      else {
        do {
          while ((sVar4 = sVar1, *(undefined4 *)(param_1 + 0x1615c) = 3, sVar4 != 0 &&
                 (iVar2 = FUN_0059c8f0(param_1,"ns1:BatchJobExResult",piVar3 + 1,
                                       "ns1:ArrayOfLuaValue"), iVar2 != 0))) {
            sVar1 = sVar4 + -1;
          }
          FUN_005b2cf0(param_1,"ns1:BatchJobExResult");
          iVar2 = *(int *)(param_1 + 0x1615c);
          if (iVar2 == 3) {
            iVar2 = FUN_00599d40(param_1);
            *(int *)(param_1 + 0x1615c) = iVar2;
          }
          if (iVar2 == 6) {
            iVar2 = FUN_005b3cc0(param_1,param_2);
            if (iVar2 != 0) {
              return (int *)0x0;
            }
            goto LAB_0059e9e4;
          }
          sVar1 = sVar4;
        } while (iVar2 == 0);
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4537 ; VA 0x0059ea10 ; FUN_0059ea10 */

int * FUN_0059ea10(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if ((iVar1 == 0) &&
     (piVar2 = (int *)FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,0x21,0x14,0,param_1 + 0x144b4,
                                   param_1 + 0x148b4,FUN_005a2cc0), piVar2 != (int *)0x0)) {
    if ((*(short *)(param_1 + 0x1550a) != 0) &&
       ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x21)) {
      FUN_005bb7f0(param_1);
      *(undefined *)(param_1 + 0x13cb4) = 0;
      piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
      return piVar2;
    }
    if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
      piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x21,0,0x14,0,
                                   FUN_00598400);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar2;
    }
    do {
      do {
        *(undefined4 *)(param_1 + 0x1615c) = 3;
        iVar1 = FUN_005a2b50(param_1,"ns1:BatchJobResult",piVar2 + 1,"ns1:LuaValue");
      } while (iVar1 != 0);
      FUN_005b2cf0(param_1,"ns1:BatchJobResult");
      iVar1 = *(int *)(param_1 + 0x1615c);
      if (iVar1 == 3) {
        iVar1 = FUN_00599d40(param_1);
        *(int *)(param_1 + 0x1615c) = iVar1;
      }
      if (iVar1 == 6) {
        iVar1 = FUN_005b3cc0(param_1,param_2);
        if (iVar1 == 0) {
          return piVar2;
        }
        return (int *)0x0;
      }
    } while (iVar1 == 0);
  }
  return (int *)0x0;
}



/* FUNCTION 4538 ; VA 0x0059eb70 ; FUN_0059eb70 */

int * FUN_0059eb70(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if ((iVar1 == 0) &&
     (piVar2 = (int *)FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,0x2c,8,0,param_1 + 0x144b4,
                                   param_1 + 0x148b4,FUN_005a2cc0), piVar2 != (int *)0x0)) {
    if ((*(short *)(param_1 + 0x1550a) != 0) &&
       ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x2c)) {
      FUN_005bb7f0(param_1);
      *(undefined *)(param_1 + 0x13cb4) = 0;
      piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
      return piVar2;
    }
    if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
      piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x2c,0,8,0,
                                   FUN_00598430);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar2;
    }
    do {
      *(undefined4 *)(param_1 + 0x1615c) = 3;
      iVar1 = FUN_00599d40(param_1);
      *(int *)(param_1 + 0x1615c) = iVar1;
      if (iVar1 == 6) {
        iVar1 = FUN_005b3cc0(param_1,param_2);
        if (iVar1 == 0) {
          return piVar2;
        }
        return (int *)0x0;
      }
    } while (iVar1 == 0);
  }
  return (int *)0x0;
}



/* FUNCTION 4539 ; VA 0x0059eca0 ; FUN_0059eca0 */

int * FUN_0059eca0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short sVar1;
  int iVar2;
  int *piVar3;
  short sVar4;
  
  iVar2 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar2 == 0) {
    piVar3 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x2d,0xc,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar3 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar3 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x2d)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar3 = (int *)(**(code **)(*piVar3 + 0x18))(param_1,param_2,param_4);
        return piVar3;
      }
      sVar4 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (sVar1 = 1, *(char *)(param_1 + 0x140b4) != '\0'))
      {
        piVar3 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar3,0,0x2d,0,0xc,0,
                                     FUN_005983e0);
        if ((*(short *)(param_1 + 0x309a) == 0) ||
           (iVar2 = FUN_005b3cc0(param_1,param_2), iVar2 == 0)) {
LAB_0059ee16:
          if (((*(uint *)(param_1 + 8) & 0x1000) != 0) && (0 < sVar4)) {
            *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
            return (int *)0x0;
          }
          return piVar3;
        }
      }
      else {
        do {
          while ((sVar4 = sVar1, *(undefined4 *)(param_1 + 0x1615c) = 3, sVar4 != 0 &&
                 (iVar2 = FUN_005b7550(param_1,"ns1:CloseAllJobsResult",piVar3 + 1,"xsd:int",1),
                 iVar2 != 0))) {
            sVar1 = sVar4 + -1;
          }
          FUN_005b2cf0(param_1,"ns1:CloseAllJobsResult");
          iVar2 = *(int *)(param_1 + 0x1615c);
          if (iVar2 == 3) {
            iVar2 = FUN_00599d40(param_1);
            *(int *)(param_1 + 0x1615c) = iVar2;
          }
          if (iVar2 == 6) {
            iVar2 = FUN_005b3cc0(param_1,param_2);
            if (iVar2 != 0) {
              return (int *)0x0;
            }
            goto LAB_0059ee16;
          }
          sVar1 = sVar4;
        } while (iVar2 == 0);
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4540 ; VA 0x0059ee40 ; FUN_0059ee40 */

int * FUN_0059ee40(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if ((iVar1 == 0) &&
     (piVar2 = (int *)FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,0x2a,8,0,param_1 + 0x144b4,
                                   param_1 + 0x148b4,FUN_005a2cc0), piVar2 != (int *)0x0)) {
    if ((*(short *)(param_1 + 0x1550a) != 0) &&
       ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x2a)) {
      FUN_005bb7f0(param_1);
      *(undefined *)(param_1 + 0x13cb4) = 0;
      piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
      return piVar2;
    }
    if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
      piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x2a,0,8,0,
                                   FUN_00598430);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar2;
    }
    do {
      *(undefined4 *)(param_1 + 0x1615c) = 3;
      iVar1 = FUN_00599d40(param_1);
      *(int *)(param_1 + 0x1615c) = iVar1;
      if (iVar1 == 6) {
        iVar1 = FUN_005b3cc0(param_1,param_2);
        if (iVar1 == 0) {
          return piVar2;
        }
        return (int *)0x0;
      }
    } while (iVar1 == 0);
  }
  return (int *)0x0;
}



/* FUNCTION 4541 ; VA 0x0059ef70 ; FUN_0059ef70 */

int * FUN_0059ef70(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short sVar1;
  int iVar2;
  int *piVar3;
  short sVar4;
  
  iVar2 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar2 == 0) {
    piVar3 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x2b,0xc,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar3 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar3 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x2b)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar3 = (int *)(**(code **)(*piVar3 + 0x18))(param_1,param_2,param_4);
        return piVar3;
      }
      sVar4 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (sVar1 = 1, *(char *)(param_1 + 0x140b4) != '\0'))
      {
        piVar3 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar3,0,0x2b,0,0xc,0,
                                     FUN_005983e0);
        if ((*(short *)(param_1 + 0x309a) == 0) ||
           (iVar2 = FUN_005b3cc0(param_1,param_2), iVar2 == 0)) {
LAB_0059f0e6:
          if (((*(uint *)(param_1 + 8) & 0x1000) != 0) && (0 < sVar4)) {
            *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
            return (int *)0x0;
          }
          return piVar3;
        }
      }
      else {
        do {
          while ((sVar4 = sVar1, *(undefined4 *)(param_1 + 0x1615c) = 3, sVar4 != 0 &&
                 (iVar2 = FUN_005b7550(param_1,"ns1:CloseExpiredJobsResult",piVar3 + 1,"xsd:int",1),
                 iVar2 != 0))) {
            sVar1 = sVar4 + -1;
          }
          FUN_005b2cf0(param_1,"ns1:CloseExpiredJobsResult");
          iVar2 = *(int *)(param_1 + 0x1615c);
          if (iVar2 == 3) {
            iVar2 = FUN_00599d40(param_1);
            *(int *)(param_1 + 0x1615c) = iVar2;
          }
          if (iVar2 == 6) {
            iVar2 = FUN_005b3cc0(param_1,param_2);
            if (iVar2 != 0) {
              return (int *)0x0;
            }
            goto LAB_0059f0e6;
          }
          sVar1 = sVar4;
        } while (iVar2 == 0);
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4542 ; VA 0x0059f110 ; FUN_0059f110 */

int * FUN_0059f110(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short sVar1;
  int iVar2;
  int *piVar3;
  short sVar4;
  
  iVar2 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar2 == 0) {
    piVar3 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x1e,0x20,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar3 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar3 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x1e)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar3 = (int *)(**(code **)(*piVar3 + 0x18))(param_1,param_2,param_4);
        return piVar3;
      }
      sVar4 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (sVar1 = 1, *(char *)(param_1 + 0x140b4) != '\0'))
      {
        piVar3 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar3,0,0x1e,0,0x20,0,
                                     FUN_00598450);
        if ((*(short *)(param_1 + 0x309a) == 0) ||
           (iVar2 = FUN_005b3cc0(param_1,param_2), iVar2 == 0)) {
LAB_0059f27b:
          if (((*(uint *)(param_1 + 8) & 0x1000) != 0) && (0 < sVar4)) {
            *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
            return (int *)0x0;
          }
          return piVar3;
        }
      }
      else {
LAB_0059f1d0:
        do {
          sVar4 = sVar1;
          *(undefined4 *)(param_1 + 0x1615c) = 3;
          iVar2 = 3;
          if (sVar4 != 0) {
            iVar2 = FUN_005a2880(param_1,"ns1:jobID",piVar3 + 1,"xsd:string");
            if (iVar2 != 0) {
              sVar1 = sVar4 + -1;
              goto LAB_0059f1d0;
            }
            iVar2 = *(int *)(param_1 + 0x1615c);
          }
          if (iVar2 == 3) {
            iVar2 = FUN_00599d40(param_1);
            *(int *)(param_1 + 0x1615c) = iVar2;
          }
          if (iVar2 == 6) {
            iVar2 = FUN_005b3cc0(param_1,param_2);
            if (iVar2 != 0) {
              return (int *)0x0;
            }
            goto LAB_0059f27b;
          }
          sVar1 = sVar4;
        } while (iVar2 == 0);
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4543 ; VA 0x0059f2b0 ; FUN_0059f2b0 */

int * FUN_0059f2b0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if ((iVar1 == 0) &&
     (piVar2 = (int *)FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,0x1f,8,0,param_1 + 0x144b4,
                                   param_1 + 0x148b4,FUN_005a2cc0), piVar2 != (int *)0x0)) {
    if ((*(short *)(param_1 + 0x1550a) != 0) &&
       ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x1f)) {
      FUN_005bb7f0(param_1);
      *(undefined *)(param_1 + 0x13cb4) = 0;
      piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
      return piVar2;
    }
    if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
      piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x1f,0,8,0,
                                   FUN_00598430);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar2;
    }
    do {
      *(undefined4 *)(param_1 + 0x1615c) = 3;
      iVar1 = FUN_00599d40(param_1);
      *(int *)(param_1 + 0x1615c) = iVar1;
      if (iVar1 == 6) {
        iVar1 = FUN_005b3cc0(param_1,param_2);
        if (iVar1 == 0) {
          return piVar2;
        }
        return (int *)0x0;
      }
    } while (iVar1 == 0);
  }
  return (int *)0x0;
}



/* FUNCTION 4544 ; VA 0x0059f3e0 ; FUN_0059f3e0 */

int * FUN_0059f3e0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  short sVar3;
  short sVar4;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar1 == 0) {
    piVar2 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x2e,0x10,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar2 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x2e)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
        return piVar2;
      }
      sVar4 = 1;
      sVar3 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
        piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x2e,0,0x10,0,
                                     FUN_005983c0);
        if (*(short *)(param_1 + 0x309a) != 0) {
          iVar1 = FUN_005b3cc0(param_1,param_2);
joined_r0x0059f54a:
          if (iVar1 != 0) {
            return (int *)0x0;
          }
        }
        if (((*(uint *)(param_1 + 8) & 0x1000) != 0) && (0 < sVar4)) {
          *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
          return (int *)0x0;
        }
        return piVar2;
      }
LAB_0059f4a0:
      do {
        *(undefined4 *)(param_1 + 0x1615c) = 3;
        iVar1 = 3;
        if (sVar4 != 0) {
          iVar1 = FUN_005b7550(param_1,"ns1:type",piVar2 + 1,"xsd:int",1);
          if (iVar1 != 0) {
            sVar4 = sVar4 + -1;
            goto LAB_0059f4a0;
          }
          iVar1 = *(int *)(param_1 + 0x1615c);
        }
        if ((sVar3 != 0) &&
           (((iVar1 == 3 || (iVar1 == 6)) &&
            (iVar1 = FUN_0059cd50(param_1,"ns1:jobID",piVar2 + 2,"xsd:string"), iVar1 != 0)))) {
          sVar3 = sVar3 + -1;
          goto LAB_0059f4a0;
        }
        iVar1 = *(int *)(param_1 + 0x1615c);
        if (iVar1 == 3) {
          iVar1 = FUN_00599d40(param_1);
          *(int *)(param_1 + 0x1615c) = iVar1;
        }
        if (iVar1 == 6) {
          iVar1 = FUN_005b3cc0(param_1,param_2);
          goto joined_r0x0059f54a;
        }
      } while (iVar1 == 0);
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4545 ; VA 0x0059f5c0 ; FUN_0059f5c0 */

int * FUN_0059f5c0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  short sVar3;
  short sVar4;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar1 == 0) {
    piVar2 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x30,0x10,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar2 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x30)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
        return piVar2;
      }
      sVar4 = 1;
      sVar3 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
        piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x30,0,0x10,0,
                                     FUN_005983c0);
        if (*(short *)(param_1 + 0x309a) != 0) {
          iVar1 = FUN_005b3cc0(param_1,param_2);
joined_r0x0059f72a:
          if (iVar1 != 0) {
            return (int *)0x0;
          }
        }
        if (((*(uint *)(param_1 + 8) & 0x1000) != 0) && (0 < sVar4)) {
          *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
          return (int *)0x0;
        }
        return piVar2;
      }
LAB_0059f680:
      do {
        *(undefined4 *)(param_1 + 0x1615c) = 3;
        iVar1 = 3;
        if (sVar4 != 0) {
          iVar1 = FUN_005b7550(param_1,"ns1:type",piVar2 + 1,"xsd:int",1);
          if (iVar1 != 0) {
            sVar4 = sVar4 + -1;
            goto LAB_0059f680;
          }
          iVar1 = *(int *)(param_1 + 0x1615c);
        }
        if ((sVar3 != 0) &&
           (((iVar1 == 3 || (iVar1 == 6)) &&
            (iVar1 = FUN_0059cd50(param_1,"ns1:jobID",piVar2 + 2,"xsd:string"), iVar1 != 0)))) {
          sVar3 = sVar3 + -1;
          goto LAB_0059f680;
        }
        iVar1 = *(int *)(param_1 + 0x1615c);
        if (iVar1 == 3) {
          iVar1 = FUN_00599d40(param_1);
          *(int *)(param_1 + 0x1615c) = iVar1;
        }
        if (iVar1 == 6) {
          iVar1 = FUN_005b3cc0(param_1,param_2);
          goto joined_r0x0059f72a;
        }
      } while (iVar1 == 0);
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4546 ; VA 0x0059f7a0 ; FUN_0059f7a0 */

int * FUN_0059f7a0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short sVar1;
  int iVar2;
  int *piVar3;
  short sVar4;
  
  iVar2 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar2 == 0) {
    piVar3 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x31,0xc,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar3 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar3 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x31)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar3 = (int *)(**(code **)(*piVar3 + 0x18))(param_1,param_2,param_4);
        return piVar3;
      }
      sVar4 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (sVar1 = 1, *(char *)(param_1 + 0x140b4) != '\0'))
      {
        piVar3 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar3,0,0x31,0,0xc,0,
                                     FUN_005983e0);
        if ((*(short *)(param_1 + 0x309a) == 0) ||
           (iVar2 = FUN_005b3cc0(param_1,param_2), iVar2 == 0)) {
LAB_0059f914:
          if (((*(uint *)(param_1 + 8) & 0x1000) != 0) && (0 < sVar4)) {
            *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
            return (int *)0x0;
          }
          return piVar3;
        }
      }
      else {
        do {
          while ((sVar4 = sVar1, *(undefined4 *)(param_1 + 0x1615c) = 3, sVar4 != 0 &&
                 (iVar2 = FUN_0059c8f0(param_1,"ns1:DiagExResult",piVar3 + 1,"ns1:ArrayOfLuaValue"),
                 iVar2 != 0))) {
            sVar1 = sVar4 + -1;
          }
          FUN_005b2cf0(param_1,"ns1:DiagExResult");
          iVar2 = *(int *)(param_1 + 0x1615c);
          if (iVar2 == 3) {
            iVar2 = FUN_00599d40(param_1);
            *(int *)(param_1 + 0x1615c) = iVar2;
          }
          if (iVar2 == 6) {
            iVar2 = FUN_005b3cc0(param_1,param_2);
            if (iVar2 != 0) {
              return (int *)0x0;
            }
            goto LAB_0059f914;
          }
          sVar1 = sVar4;
        } while (iVar2 == 0);
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4547 ; VA 0x0059f940 ; FUN_0059f940 */

int * FUN_0059f940(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if ((iVar1 == 0) &&
     (piVar2 = (int *)FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,0x2f,0x14,0,param_1 + 0x144b4,
                                   param_1 + 0x148b4,FUN_005a2cc0), piVar2 != (int *)0x0)) {
    if ((*(short *)(param_1 + 0x1550a) != 0) &&
       ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x2f)) {
      FUN_005bb7f0(param_1);
      *(undefined *)(param_1 + 0x13cb4) = 0;
      piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
      return piVar2;
    }
    if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
      piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x2f,0,0x14,0,
                                   FUN_00598400);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar2;
    }
    do {
      do {
        *(undefined4 *)(param_1 + 0x1615c) = 3;
        iVar1 = FUN_005a2b50(param_1,"ns1:DiagResult",piVar2 + 1,"ns1:LuaValue");
      } while (iVar1 != 0);
      FUN_005b2cf0(param_1,"ns1:DiagResult");
      iVar1 = *(int *)(param_1 + 0x1615c);
      if (iVar1 == 3) {
        iVar1 = FUN_00599d40(param_1);
        *(int *)(param_1 + 0x1615c) = iVar1;
      }
      if (iVar1 == 6) {
        iVar1 = FUN_005b3cc0(param_1,param_2);
        if (iVar1 == 0) {
          return piVar2;
        }
        return (int *)0x0;
      }
    } while (iVar1 == 0);
  }
  return (int *)0x0;
}



/* FUNCTION 4548 ; VA 0x0059faa0 ; FUN_0059faa0 */

int * FUN_0059faa0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  short sVar3;
  short sVar4;
  short sVar5;
  short sVar6;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar1 == 0) {
    piVar2 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x1a,0x24,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar2 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x1a)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
        return piVar2;
      }
      sVar5 = 1;
      sVar3 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
        piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x1a,0,0x24,0,
                                     FUN_00598490);
        sVar6 = 1;
        sVar4 = 1;
        if ((*(short *)(param_1 + 0x309a) == 0) ||
           (iVar1 = FUN_005b3cc0(param_1,param_2), sVar6 = sVar5, sVar4 = sVar3, iVar1 == 0)) {
LAB_0059fc49:
          if ((*(uint *)(param_1 + 8) & 0x1000) == 0) {
            return piVar2;
          }
          if ((sVar6 < 1) && (sVar4 < 1)) {
            return piVar2;
          }
          *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
        }
      }
      else {
LAB_0059fb60:
        do {
          *(undefined4 *)(param_1 + 0x1615c) = 3;
          iVar1 = 3;
          if (sVar5 != 0) {
            iVar1 = FUN_005a2880(param_1,"ns1:jobID",piVar2 + 1,"xsd:string");
            if (iVar1 != 0) {
              sVar5 = sVar5 + -1;
              goto LAB_0059fb60;
            }
            iVar1 = *(int *)(param_1 + 0x1615c);
          }
          if (((sVar3 != 0) && (iVar1 == 3)) &&
             (iVar1 = FUN_0059cb60(param_1,"ns1:script",piVar2 + 7,"ns1:ScriptExecution"),
             iVar1 != 0)) {
            sVar3 = sVar3 + -1;
            goto LAB_0059fb60;
          }
          iVar1 = *(int *)(param_1 + 0x1615c);
          if (iVar1 == 3) {
            iVar1 = FUN_00599d40(param_1);
            *(int *)(param_1 + 0x1615c) = iVar1;
          }
          if (iVar1 == 6) {
            iVar1 = FUN_005b3cc0(param_1,param_2);
            sVar6 = sVar5;
            sVar4 = sVar3;
            if (iVar1 != 0) {
              return (int *)0x0;
            }
            goto LAB_0059fc49;
          }
        } while (iVar1 == 0);
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4549 ; VA 0x0059fc70 ; FUN_0059fc70 */

int * FUN_0059fc70(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  short sVar3;
  short sVar4;
  short sVar5;
  short sVar6;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar1 == 0) {
    piVar2 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x1c,0x24,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar2 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x1c)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
        return piVar2;
      }
      sVar5 = 1;
      sVar3 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
        piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x1c,0,0x24,0,
                                     FUN_00598490);
        sVar6 = 1;
        sVar4 = 1;
        if ((*(short *)(param_1 + 0x309a) == 0) ||
           (iVar1 = FUN_005b3cc0(param_1,param_2), sVar6 = sVar5, sVar4 = sVar3, iVar1 == 0)) {
LAB_0059fe19:
          if ((*(uint *)(param_1 + 8) & 0x1000) == 0) {
            return piVar2;
          }
          if ((sVar6 < 1) && (sVar4 < 1)) {
            return piVar2;
          }
          *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
        }
      }
      else {
LAB_0059fd30:
        do {
          *(undefined4 *)(param_1 + 0x1615c) = 3;
          iVar1 = 3;
          if (sVar5 != 0) {
            iVar1 = FUN_005a2880(param_1,"ns1:jobID",piVar2 + 1,"xsd:string");
            if (iVar1 != 0) {
              sVar5 = sVar5 + -1;
              goto LAB_0059fd30;
            }
            iVar1 = *(int *)(param_1 + 0x1615c);
          }
          if (((sVar3 != 0) && (iVar1 == 3)) &&
             (iVar1 = FUN_0059cb60(param_1,"ns1:script",piVar2 + 7,"ns1:ScriptExecution"),
             iVar1 != 0)) {
            sVar3 = sVar3 + -1;
            goto LAB_0059fd30;
          }
          iVar1 = *(int *)(param_1 + 0x1615c);
          if (iVar1 == 3) {
            iVar1 = FUN_00599d40(param_1);
            *(int *)(param_1 + 0x1615c) = iVar1;
          }
          if (iVar1 == 6) {
            iVar1 = FUN_005b3cc0(param_1,param_2);
            sVar6 = sVar5;
            sVar4 = sVar3;
            if (iVar1 != 0) {
              return (int *)0x0;
            }
            goto LAB_0059fe19;
          }
        } while (iVar1 == 0);
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4550 ; VA 0x0059fe40 ; FUN_0059fe40 */

int * FUN_0059fe40(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short sVar1;
  int iVar2;
  int *piVar3;
  short sVar4;
  
  iVar2 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar2 == 0) {
    piVar3 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x1d,0xc,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar3 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar3 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x1d)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar3 = (int *)(**(code **)(*piVar3 + 0x18))(param_1,param_2,param_4);
        return piVar3;
      }
      sVar4 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (sVar1 = 1, *(char *)(param_1 + 0x140b4) != '\0'))
      {
        piVar3 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar3,0,0x1d,0,0xc,0,
                                     FUN_005983e0);
        if ((*(short *)(param_1 + 0x309a) == 0) ||
           (iVar2 = FUN_005b3cc0(param_1,param_2), iVar2 == 0)) {
LAB_0059ffb4:
          if (((*(uint *)(param_1 + 8) & 0x1000) != 0) && (0 < sVar4)) {
            *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
            return (int *)0x0;
          }
          return piVar3;
        }
      }
      else {
        do {
          while ((sVar4 = sVar1, *(undefined4 *)(param_1 + 0x1615c) = 3, sVar4 != 0 &&
                 (iVar2 = FUN_0059c8f0(param_1,"ns1:ExecuteExResult",piVar3 + 1,
                                       "ns1:ArrayOfLuaValue"), iVar2 != 0))) {
            sVar1 = sVar4 + -1;
          }
          FUN_005b2cf0(param_1,"ns1:ExecuteExResult");
          iVar2 = *(int *)(param_1 + 0x1615c);
          if (iVar2 == 3) {
            iVar2 = FUN_00599d40(param_1);
            *(int *)(param_1 + 0x1615c) = iVar2;
          }
          if (iVar2 == 6) {
            iVar2 = FUN_005b3cc0(param_1,param_2);
            if (iVar2 != 0) {
              return (int *)0x0;
            }
            goto LAB_0059ffb4;
          }
          sVar1 = sVar4;
        } while (iVar2 == 0);
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4551 ; VA 0x0059ffe0 ; FUN_0059ffe0 */

int * FUN_0059ffe0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if ((iVar1 == 0) &&
     (piVar2 = (int *)FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,0x1b,0x14,0,param_1 + 0x144b4,
                                   param_1 + 0x148b4,FUN_005a2cc0), piVar2 != (int *)0x0)) {
    if ((*(short *)(param_1 + 0x1550a) != 0) &&
       ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x1b)) {
      FUN_005bb7f0(param_1);
      *(undefined *)(param_1 + 0x13cb4) = 0;
      piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
      return piVar2;
    }
    if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
      piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x1b,0,0x14,0,
                                   FUN_00598400);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar2;
    }
    do {
      do {
        *(undefined4 *)(param_1 + 0x1615c) = 3;
        iVar1 = FUN_005a2b50(param_1,"ns1:ExecuteResult",piVar2 + 1,"ns1:LuaValue");
      } while (iVar1 != 0);
      FUN_005b2cf0(param_1,"ns1:ExecuteResult");
      iVar1 = *(int *)(param_1 + 0x1615c);
      if (iVar1 == 3) {
        iVar1 = FUN_00599d40(param_1);
        *(int *)(param_1 + 0x1615c) = iVar1;
      }
      if (iVar1 == 6) {
        iVar1 = FUN_005b3cc0(param_1,param_2);
        if (iVar1 == 0) {
          return piVar2;
        }
        return (int *)0x0;
      }
    } while (iVar1 == 0);
  }
  return (int *)0x0;
}



/* FUNCTION 4552 ; VA 0x005a0140 ; FUN_005a0140 */

int * FUN_005a0140(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if ((iVar1 == 0) &&
     (piVar2 = (int *)FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,0x26,8,0,param_1 + 0x144b4,
                                   param_1 + 0x148b4,FUN_005a2cc0), piVar2 != (int *)0x0)) {
    if ((*(short *)(param_1 + 0x1550a) != 0) &&
       ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x26)) {
      FUN_005bb7f0(param_1);
      *(undefined *)(param_1 + 0x13cb4) = 0;
      piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
      return piVar2;
    }
    if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
      piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x26,0,8,0,
                                   FUN_00598430);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar2;
    }
    do {
      *(undefined4 *)(param_1 + 0x1615c) = 3;
      iVar1 = FUN_00599d40(param_1);
      *(int *)(param_1 + 0x1615c) = iVar1;
      if (iVar1 == 6) {
        iVar1 = FUN_005b3cc0(param_1,param_2);
        if (iVar1 == 0) {
          return piVar2;
        }
        return (int *)0x0;
      }
    } while (iVar1 == 0);
  }
  return (int *)0x0;
}



/* FUNCTION 4553 ; VA 0x005a0270 ; FUN_005a0270 */

int * FUN_005a0270(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if ((iVar1 == 0) &&
     (piVar2 = (int *)FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,0x28,8,0,param_1 + 0x144b4,
                                   param_1 + 0x148b4,FUN_005a2cc0), piVar2 != (int *)0x0)) {
    if ((*(short *)(param_1 + 0x1550a) != 0) &&
       ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x28)) {
      FUN_005bb7f0(param_1);
      *(undefined *)(param_1 + 0x13cb4) = 0;
      piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
      return piVar2;
    }
    if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
      piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x28,0,8,0,
                                   FUN_00598430);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar2;
    }
    do {
      *(undefined4 *)(param_1 + 0x1615c) = 3;
      iVar1 = FUN_00599d40(param_1);
      *(int *)(param_1 + 0x1615c) = iVar1;
      if (iVar1 == 6) {
        iVar1 = FUN_005b3cc0(param_1,param_2);
        if (iVar1 == 0) {
          return piVar2;
        }
        return (int *)0x0;
      }
    } while (iVar1 == 0);
  }
  return (int *)0x0;
}



/* FUNCTION 4554 ; VA 0x005a03a0 ; FUN_005a03a0 */

int * FUN_005a03a0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short sVar1;
  int iVar2;
  int *piVar3;
  short sVar4;
  
  iVar2 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar2 == 0) {
    piVar3 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x29,0xc,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar3 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar3 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x29)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar3 = (int *)(**(code **)(*piVar3 + 0x18))(param_1,param_2,param_4);
        return piVar3;
      }
      sVar4 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (sVar1 = 1, *(char *)(param_1 + 0x140b4) != '\0'))
      {
        piVar3 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar3,0,0x29,0,0xc,0,
                                     FUN_005983e0);
        if ((*(short *)(param_1 + 0x309a) == 0) ||
           (iVar2 = FUN_005b3cc0(param_1,param_2), iVar2 == 0)) {
LAB_005a0514:
          if (((*(uint *)(param_1 + 8) & 0x1000) != 0) && (0 < sVar4)) {
            *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
            return (int *)0x0;
          }
          return piVar3;
        }
      }
      else {
        do {
          while ((sVar4 = sVar1, *(undefined4 *)(param_1 + 0x1615c) = 3, sVar4 != 0 &&
                 (iVar2 = FUN_0059c820(param_1,"ns1:GetAllJobsExResult",piVar3 + 1,"ns1:ArrayOfJob")
                 , iVar2 != 0))) {
            sVar1 = sVar4 + -1;
          }
          FUN_005b2cf0(param_1,"ns1:GetAllJobsExResult");
          iVar2 = *(int *)(param_1 + 0x1615c);
          if (iVar2 == 3) {
            iVar2 = FUN_00599d40(param_1);
            *(int *)(param_1 + 0x1615c) = iVar2;
          }
          if (iVar2 == 6) {
            iVar2 = FUN_005b3cc0(param_1,param_2);
            if (iVar2 != 0) {
              return (int *)0x0;
            }
            goto LAB_005a0514;
          }
          sVar1 = sVar4;
        } while (iVar2 == 0);
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4555 ; VA 0x005a0540 ; FUN_005a0540 */

int * FUN_005a0540(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if ((iVar1 == 0) &&
     (piVar2 = (int *)FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,0x27,0x14,0,param_1 + 0x144b4,
                                   param_1 + 0x148b4,FUN_005a2cc0), piVar2 != (int *)0x0)) {
    if ((*(short *)(param_1 + 0x1550a) != 0) &&
       ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x27)) {
      FUN_005bb7f0(param_1);
      *(undefined *)(param_1 + 0x13cb4) = 0;
      piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
      return piVar2;
    }
    if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
      piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x27,0,0x14,0,
                                   FUN_00598400);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar2;
    }
    do {
      do {
        *(undefined4 *)(param_1 + 0x1615c) = 3;
        iVar1 = FUN_005a29e0(param_1,"ns1:GetAllJobsResult",piVar2 + 1,"ns1:Job");
      } while (iVar1 != 0);
      FUN_005b2cf0(param_1,"ns1:GetAllJobsResult");
      iVar1 = *(int *)(param_1 + 0x1615c);
      if (iVar1 == 3) {
        iVar1 = FUN_00599d40(param_1);
        *(int *)(param_1 + 0x1615c) = iVar1;
      }
      if (iVar1 == 6) {
        iVar1 = FUN_005b3cc0(param_1,param_2);
        if (iVar1 == 0) {
          return piVar2;
        }
        return (int *)0x0;
      }
    } while (iVar1 == 0);
  }
  return (int *)0x0;
}



/* FUNCTION 4556 ; VA 0x005a06a0 ; FUN_005a06a0 */

int * FUN_005a06a0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short sVar1;
  int iVar2;
  int *piVar3;
  short sVar4;
  
  iVar2 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar2 == 0) {
    piVar3 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x24,0x20,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar3 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar3 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x24)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar3 = (int *)(**(code **)(*piVar3 + 0x18))(param_1,param_2,param_4);
        return piVar3;
      }
      sVar4 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (sVar1 = 1, *(char *)(param_1 + 0x140b4) != '\0'))
      {
        piVar3 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar3,0,0x24,0,0x20,0,
                                     FUN_00598450);
        if ((*(short *)(param_1 + 0x309a) == 0) ||
           (iVar2 = FUN_005b3cc0(param_1,param_2), iVar2 == 0)) {
LAB_005a080b:
          if (((*(uint *)(param_1 + 8) & 0x1000) != 0) && (0 < sVar4)) {
            *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
            return (int *)0x0;
          }
          return piVar3;
        }
      }
      else {
LAB_005a0760:
        do {
          sVar4 = sVar1;
          *(undefined4 *)(param_1 + 0x1615c) = 3;
          iVar2 = 3;
          if (sVar4 != 0) {
            iVar2 = FUN_005a2880(param_1,"ns1:jobID",piVar3 + 1,"xsd:string");
            if (iVar2 != 0) {
              sVar1 = sVar4 + -1;
              goto LAB_005a0760;
            }
            iVar2 = *(int *)(param_1 + 0x1615c);
          }
          if (iVar2 == 3) {
            iVar2 = FUN_00599d40(param_1);
            *(int *)(param_1 + 0x1615c) = iVar2;
          }
          if (iVar2 == 6) {
            iVar2 = FUN_005b3cc0(param_1,param_2);
            if (iVar2 != 0) {
              return (int *)0x0;
            }
            goto LAB_005a080b;
          }
          sVar1 = sVar4;
        } while (iVar2 == 0);
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4557 ; VA 0x005a0840 ; FUN_005a0840 */

int * FUN_005a0840(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short sVar1;
  int iVar2;
  int *piVar3;
  short sVar4;
  
  iVar2 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar2 == 0) {
    piVar3 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x25,0x18,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar3 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar3 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x25)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar3 = (int *)(**(code **)(*piVar3 + 0x18))(param_1,param_2,param_4);
        return piVar3;
      }
      sVar4 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (sVar1 = 1, *(char *)(param_1 + 0x140b4) != '\0'))
      {
        piVar3 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar3,0,0x25,0,0x18,0,
                                     FUN_005984d0);
        if ((*(short *)(param_1 + 0x309a) == 0) ||
           (iVar2 = FUN_005b3cc0(param_1,param_2), iVar2 == 0)) {
LAB_005a09b6:
          if (((*(uint *)(param_1 + 8) & 0x1000) != 0) && (0 < sVar4)) {
            *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
            return (int *)0x0;
          }
          return piVar3;
        }
      }
      else {
        do {
          while ((sVar4 = sVar1, *(undefined4 *)(param_1 + 0x1615c) = 3, sVar4 != 0 &&
                 (iVar2 = FUN_005b73b0(param_1,"ns1:GetExpirationResult",piVar3 + 2,"xsd:double",
                                       0x36), iVar2 != 0))) {
            sVar1 = sVar4 + -1;
          }
          FUN_005b2cf0(param_1,"ns1:GetExpirationResult");
          iVar2 = *(int *)(param_1 + 0x1615c);
          if (iVar2 == 3) {
            iVar2 = FUN_00599d40(param_1);
            *(int *)(param_1 + 0x1615c) = iVar2;
          }
          if (iVar2 == 6) {
            iVar2 = FUN_005b3cc0(param_1,param_2);
            if (iVar2 != 0) {
              return (int *)0x0;
            }
            goto LAB_005a09b6;
          }
          sVar1 = sVar4;
        } while (iVar2 == 0);
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4558 ; VA 0x005a09e0 ; FUN_005a09e0 */

int * FUN_005a09e0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if ((iVar1 == 0) &&
     (piVar2 = (int *)FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,0x12,8,0,param_1 + 0x144b4,
                                   param_1 + 0x148b4,FUN_005a2cc0), piVar2 != (int *)0x0)) {
    if ((*(short *)(param_1 + 0x1550a) != 0) &&
       ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x12)) {
      FUN_005bb7f0(param_1);
      *(undefined *)(param_1 + 0x13cb4) = 0;
      piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
      return piVar2;
    }
    if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
      piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x12,0,8,0,
                                   FUN_00598430);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar2;
    }
    do {
      *(undefined4 *)(param_1 + 0x1615c) = 3;
      iVar1 = FUN_00599d40(param_1);
      *(int *)(param_1 + 0x1615c) = iVar1;
      if (iVar1 == 6) {
        iVar1 = FUN_005b3cc0(param_1,param_2);
        if (iVar1 == 0) {
          return piVar2;
        }
        return (int *)0x0;
      }
    } while (iVar1 == 0);
  }
  return (int *)0x0;
}



/* FUNCTION 4559 ; VA 0x005a0b10 ; FUN_005a0b10 */

int * FUN_005a0b10(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short sVar1;
  int iVar2;
  int *piVar3;
  short sVar4;
  
  iVar2 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar2 == 0) {
    piVar3 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x13,0xc,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar3 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar3 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x13)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar3 = (int *)(**(code **)(*piVar3 + 0x18))(param_1,param_2,param_4);
        return piVar3;
      }
      sVar4 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (sVar1 = 1, *(char *)(param_1 + 0x140b4) != '\0'))
      {
        piVar3 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar3,0,0x13,0,0xc,0,
                                     FUN_005983e0);
        if ((*(short *)(param_1 + 0x309a) == 0) ||
           (iVar2 = FUN_005b3cc0(param_1,param_2), iVar2 == 0)) {
LAB_005a0c84:
          if (((*(uint *)(param_1 + 8) & 0x1000) != 0) && (0 < sVar4)) {
            *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
            return (int *)0x0;
          }
          return piVar3;
        }
      }
      else {
        do {
          while ((sVar4 = sVar1, *(undefined4 *)(param_1 + 0x1615c) = 3, sVar4 != 0 &&
                 (iVar2 = FUN_0059cc30(param_1,"ns1:GetStatusResult",piVar3 + 1,"ns1:Status"),
                 iVar2 != 0))) {
            sVar1 = sVar4 + -1;
          }
          FUN_005b2cf0(param_1,"ns1:GetStatusResult");
          iVar2 = *(int *)(param_1 + 0x1615c);
          if (iVar2 == 3) {
            iVar2 = FUN_00599d40(param_1);
            *(int *)(param_1 + 0x1615c) = iVar2;
          }
          if (iVar2 == 6) {
            iVar2 = FUN_005b3cc0(param_1,param_2);
            if (iVar2 != 0) {
              return (int *)0x0;
            }
            goto LAB_005a0c84;
          }
          sVar1 = sVar4;
        } while (iVar2 == 0);
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4560 ; VA 0x005a0cb0 ; FUN_005a0cb0 */

int * FUN_005a0cb0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if ((iVar1 == 0) &&
     (piVar2 = (int *)FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,0x10,8,0,param_1 + 0x144b4,
                                   param_1 + 0x148b4,FUN_005a2cc0), piVar2 != (int *)0x0)) {
    if ((*(short *)(param_1 + 0x1550a) != 0) &&
       ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x10)) {
      FUN_005bb7f0(param_1);
      *(undefined *)(param_1 + 0x13cb4) = 0;
      piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
      return piVar2;
    }
    if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
      piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x10,0,8,0,
                                   FUN_00598430);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar2;
    }
    do {
      *(undefined4 *)(param_1 + 0x1615c) = 3;
      iVar1 = FUN_00599d40(param_1);
      *(int *)(param_1 + 0x1615c) = iVar1;
      if (iVar1 == 6) {
        iVar1 = FUN_005b3cc0(param_1,param_2);
        if (iVar1 == 0) {
          return piVar2;
        }
        return (int *)0x0;
      }
    } while (iVar1 == 0);
  }
  return (int *)0x0;
}



/* FUNCTION 4561 ; VA 0x005a0de0 ; FUN_005a0de0 */

int * FUN_005a0de0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short sVar1;
  int iVar2;
  int *piVar3;
  short sVar4;
  
  iVar2 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar2 == 0) {
    piVar3 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x11,0x20,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar3 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar3 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x11)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar3 = (int *)(**(code **)(*piVar3 + 0x18))(param_1,param_2,param_4);
        return piVar3;
      }
      sVar4 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (sVar1 = 1, *(char *)(param_1 + 0x140b4) != '\0'))
      {
        piVar3 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar3,0,0x11,0,0x20,0,
                                     FUN_00598450);
        if ((*(short *)(param_1 + 0x309a) == 0) ||
           (iVar2 = FUN_005b3cc0(param_1,param_2), iVar2 == 0)) {
LAB_005a0f54:
          if (((*(uint *)(param_1 + 8) & 0x1000) != 0) && (0 < sVar4)) {
            *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
            return (int *)0x0;
          }
          return piVar3;
        }
      }
      else {
        do {
          while ((sVar4 = sVar1, *(undefined4 *)(param_1 + 0x1615c) = 3, sVar4 != 0 &&
                 (iVar2 = FUN_005a2880(param_1,"ns1:GetVersionResult",piVar3 + 1,"xsd:string"),
                 iVar2 != 0))) {
            sVar1 = sVar4 + -1;
          }
          FUN_005b2cf0(param_1,"ns1:GetVersionResult");
          iVar2 = *(int *)(param_1 + 0x1615c);
          if (iVar2 == 3) {
            iVar2 = FUN_00599d40(param_1);
            *(int *)(param_1 + 0x1615c) = iVar2;
          }
          if (iVar2 == 6) {
            iVar2 = FUN_005b3cc0(param_1,param_2);
            if (iVar2 != 0) {
              return (int *)0x0;
            }
            goto LAB_005a0f54;
          }
          sVar1 = sVar4;
        } while (iVar2 == 0);
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4562 ; VA 0x005a0f80 ; FUN_005a0f80 */

int * FUN_005a0f80(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if ((iVar1 == 0) &&
     (piVar2 = (int *)FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,0xe,8,0,param_1 + 0x144b4,
                                   param_1 + 0x148b4,FUN_005a2cc0), piVar2 != (int *)0x0)) {
    if ((*(short *)(param_1 + 0x1550a) != 0) &&
       ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0xe)) {
      FUN_005bb7f0(param_1);
      *(undefined *)(param_1 + 0x13cb4) = 0;
      piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
      return piVar2;
    }
    if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
      piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0xe,0,8,0,
                                   FUN_00598430);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar2;
    }
    do {
      *(undefined4 *)(param_1 + 0x1615c) = 3;
      iVar1 = FUN_00599d40(param_1);
      *(int *)(param_1 + 0x1615c) = iVar1;
      if (iVar1 == 6) {
        iVar1 = FUN_005b3cc0(param_1,param_2);
        if (iVar1 == 0) {
          return piVar2;
        }
        return (int *)0x0;
      }
    } while (iVar1 == 0);
  }
  return (int *)0x0;
}



/* FUNCTION 4563 ; VA 0x005a10b0 ; FUN_005a10b0 */

int * FUN_005a10b0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  short sVar3;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if ((iVar1 == 0) &&
     (piVar2 = (int *)FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,0xf,0xc,0,param_1 + 0x144b4,
                                   param_1 + 0x148b4,FUN_005a2cc0), piVar2 != (int *)0x0)) {
    if ((*(short *)(param_1 + 0x1550a) != 0) &&
       ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0xf)) {
      FUN_005bb7f0(param_1);
      *(undefined *)(param_1 + 0x13cb4) = 0;
      piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
      return piVar2;
    }
    sVar3 = 1;
    if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
      piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0xf,0,0xc,0,
                                   FUN_005983e0);
      if ((*(short *)(param_1 + 0x309a) == 0) || (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 == 0)
         ) {
        return piVar2;
      }
    }
    else {
      do {
        while ((*(undefined4 *)(param_1 + 0x1615c) = 3, sVar3 != 0 &&
               (iVar1 = FUN_0059cd50(param_1,"ns1:HelloWorldResult",piVar2 + 1,"xsd:string"),
               iVar1 != 0))) {
          sVar3 = sVar3 + -1;
        }
        FUN_005b2cf0(param_1,"ns1:HelloWorldResult");
        iVar1 = *(int *)(param_1 + 0x1615c);
        if (iVar1 == 3) {
          iVar1 = FUN_00599d40(param_1);
          *(int *)(param_1 + 0x1615c) = iVar1;
        }
        if (iVar1 == 6) {
          iVar1 = FUN_005b3cc0(param_1,param_2);
          if (iVar1 == 0) {
            return piVar2;
          }
          return (int *)0x0;
        }
      } while (iVar1 == 0);
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4564 ; VA 0x005a1230 ; FUN_005a1230 */

int * FUN_005a1230(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  short sVar3;
  short sVar4;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar1 == 0) {
    piVar2 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x14,0x10,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar2 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x14)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
        return piVar2;
      }
      sVar4 = 1;
      sVar3 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
        piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x14,0,0x10,0,
                                     FUN_005983c0);
        if (*(short *)(param_1 + 0x309a) != 0) {
          iVar1 = FUN_005b3cc0(param_1,param_2);
joined_r0x005a1393:
          if (iVar1 != 0) {
            return (int *)0x0;
          }
        }
        if (((*(uint *)(param_1 + 8) & 0x1000) != 0) && (0 < sVar4)) {
          *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
          return (int *)0x0;
        }
        return piVar2;
      }
LAB_005a12f0:
      do {
        *(undefined4 *)(param_1 + 0x1615c) = 3;
        iVar1 = 3;
        if (sVar4 != 0) {
          iVar1 = FUN_0059c9c0(param_1,"ns1:job",piVar2 + 1,"ns1:Job");
          if (iVar1 != 0) {
            sVar4 = sVar4 + -1;
            goto LAB_005a12f0;
          }
          iVar1 = *(int *)(param_1 + 0x1615c);
        }
        if (((sVar3 != 0) && (iVar1 == 3)) &&
           (iVar1 = FUN_0059cb60(param_1,"ns1:script",piVar2 + 2,"ns1:ScriptExecution"), iVar1 != 0)
           ) {
          sVar3 = sVar3 + -1;
          goto LAB_005a12f0;
        }
        iVar1 = *(int *)(param_1 + 0x1615c);
        if (iVar1 == 3) {
          iVar1 = FUN_00599d40(param_1);
          *(int *)(param_1 + 0x1615c) = iVar1;
        }
        if (iVar1 == 6) {
          iVar1 = FUN_005b3cc0(param_1,param_2);
          goto joined_r0x005a1393;
        }
      } while (iVar1 == 0);
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4565 ; VA 0x005a1400 ; FUN_005a1400 */

int * FUN_005a1400(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  short sVar3;
  short sVar4;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar1 == 0) {
    piVar2 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x15,0x10,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar2 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x15)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
        return piVar2;
      }
      sVar4 = 1;
      sVar3 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
        piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x15,0,0x10,0,
                                     FUN_005983c0);
        if (*(short *)(param_1 + 0x309a) != 0) {
          iVar1 = FUN_005b3cc0(param_1,param_2);
joined_r0x005a1563:
          if (iVar1 != 0) {
            return (int *)0x0;
          }
        }
        if (((*(uint *)(param_1 + 8) & 0x1000) != 0) && (0 < sVar4)) {
          *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
          return (int *)0x0;
        }
        return piVar2;
      }
LAB_005a14c0:
      do {
        *(undefined4 *)(param_1 + 0x1615c) = 3;
        iVar1 = 3;
        if (sVar4 != 0) {
          iVar1 = FUN_0059c9c0(param_1,"ns1:job",piVar2 + 1,"ns1:Job");
          if (iVar1 != 0) {
            sVar4 = sVar4 + -1;
            goto LAB_005a14c0;
          }
          iVar1 = *(int *)(param_1 + 0x1615c);
        }
        if (((sVar3 != 0) && (iVar1 == 3)) &&
           (iVar1 = FUN_0059cb60(param_1,"ns1:script",piVar2 + 2,"ns1:ScriptExecution"), iVar1 != 0)
           ) {
          sVar3 = sVar3 + -1;
          goto LAB_005a14c0;
        }
        iVar1 = *(int *)(param_1 + 0x1615c);
        if (iVar1 == 3) {
          iVar1 = FUN_00599d40(param_1);
          *(int *)(param_1 + 0x1615c) = iVar1;
        }
        if (iVar1 == 6) {
          iVar1 = FUN_005b3cc0(param_1,param_2);
          goto joined_r0x005a1563;
        }
      } while (iVar1 == 0);
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4566 ; VA 0x005a15d0 ; FUN_005a15d0 */

int * FUN_005a15d0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short sVar1;
  int iVar2;
  int *piVar3;
  short sVar4;
  
  iVar2 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar2 == 0) {
    piVar3 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x17,0xc,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar3 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar3 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x17)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar3 = (int *)(**(code **)(*piVar3 + 0x18))(param_1,param_2,param_4);
        return piVar3;
      }
      sVar4 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (sVar1 = 1, *(char *)(param_1 + 0x140b4) != '\0'))
      {
        piVar3 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar3,0,0x17,0,0xc,0,
                                     FUN_005983e0);
        if ((*(short *)(param_1 + 0x309a) == 0) ||
           (iVar2 = FUN_005b3cc0(param_1,param_2), iVar2 == 0)) {
LAB_005a1744:
          if (((*(uint *)(param_1 + 8) & 0x1000) != 0) && (0 < sVar4)) {
            *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
            return (int *)0x0;
          }
          return piVar3;
        }
      }
      else {
        do {
          while ((sVar4 = sVar1, *(undefined4 *)(param_1 + 0x1615c) = 3, sVar4 != 0 &&
                 (iVar2 = FUN_0059c8f0(param_1,"ns1:OpenJobExResult",piVar3 + 1,
                                       "ns1:ArrayOfLuaValue"), iVar2 != 0))) {
            sVar1 = sVar4 + -1;
          }
          FUN_005b2cf0(param_1,"ns1:OpenJobExResult");
          iVar2 = *(int *)(param_1 + 0x1615c);
          if (iVar2 == 3) {
            iVar2 = FUN_00599d40(param_1);
            *(int *)(param_1 + 0x1615c) = iVar2;
          }
          if (iVar2 == 6) {
            iVar2 = FUN_005b3cc0(param_1,param_2);
            if (iVar2 != 0) {
              return (int *)0x0;
            }
            goto LAB_005a1744;
          }
          sVar1 = sVar4;
        } while (iVar2 == 0);
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4567 ; VA 0x005a1770 ; FUN_005a1770 */

int * FUN_005a1770(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if ((iVar1 == 0) &&
     (piVar2 = (int *)FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,0x16,0x14,0,param_1 + 0x144b4,
                                   param_1 + 0x148b4,FUN_005a2cc0), piVar2 != (int *)0x0)) {
    if ((*(short *)(param_1 + 0x1550a) != 0) &&
       ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x16)) {
      FUN_005bb7f0(param_1);
      *(undefined *)(param_1 + 0x13cb4) = 0;
      piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
      return piVar2;
    }
    if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
      piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x16,0,0x14,0,
                                   FUN_00598400);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar2;
    }
    do {
      do {
        *(undefined4 *)(param_1 + 0x1615c) = 3;
        iVar1 = FUN_005a2b50(param_1,"ns1:OpenJobResult",piVar2 + 1,"ns1:LuaValue");
      } while (iVar1 != 0);
      FUN_005b2cf0(param_1,"ns1:OpenJobResult");
      iVar1 = *(int *)(param_1 + 0x1615c);
      if (iVar1 == 3) {
        iVar1 = FUN_00599d40(param_1);
        *(int *)(param_1 + 0x1615c) = iVar1;
      }
      if (iVar1 == 6) {
        iVar1 = FUN_005b3cc0(param_1,param_2);
        if (iVar1 == 0) {
          return piVar2;
        }
        return (int *)0x0;
      }
    } while (iVar1 == 0);
  }
  return (int *)0x0;
}



/* FUNCTION 4568 ; VA 0x005a18d0 ; FUN_005a18d0 */

int * FUN_005a18d0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  short sVar3;
  short sVar4;
  short sVar5;
  short sVar6;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar1 == 0) {
    piVar2 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x18,0x30,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar2 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x18)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
        return piVar2;
      }
      sVar5 = 1;
      sVar3 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
        piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0x18,0,0x30,0,
                                     FUN_005984f0);
        sVar6 = 1;
        sVar4 = 1;
        if ((*(short *)(param_1 + 0x309a) == 0) ||
           (iVar1 = FUN_005b3cc0(param_1,param_2), sVar6 = sVar5, sVar4 = sVar3, iVar1 == 0)) {
LAB_005a1a7b:
          if ((*(uint *)(param_1 + 8) & 0x1000) == 0) {
            return piVar2;
          }
          if ((sVar6 < 1) && (sVar4 < 1)) {
            return piVar2;
          }
          *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
        }
      }
      else {
LAB_005a1990:
        do {
          *(undefined4 *)(param_1 + 0x1615c) = 3;
          iVar1 = 3;
          if (sVar5 != 0) {
            iVar1 = FUN_005a2880(param_1,"ns1:jobID",piVar2 + 2,"xsd:string");
            if (iVar1 != 0) {
              sVar5 = sVar5 + -1;
              goto LAB_005a1990;
            }
            iVar1 = *(int *)(param_1 + 0x1615c);
          }
          if (((sVar3 != 0) && (iVar1 == 3)) &&
             (iVar1 = FUN_005b73b0(param_1,"ns1:expirationInSeconds",piVar2 + 8,"xsd:double",0x36),
             iVar1 != 0)) {
            sVar3 = sVar3 + -1;
            goto LAB_005a1990;
          }
          iVar1 = *(int *)(param_1 + 0x1615c);
          if (iVar1 == 3) {
            iVar1 = FUN_00599d40(param_1);
            *(int *)(param_1 + 0x1615c) = iVar1;
          }
          if (iVar1 == 6) {
            iVar1 = FUN_005b3cc0(param_1,param_2);
            sVar6 = sVar5;
            sVar4 = sVar3;
            if (iVar1 != 0) {
              return (int *)0x0;
            }
            goto LAB_005a1a7b;
          }
        } while (iVar1 == 0);
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4569 ; VA 0x005a1ab0 ; FUN_005a1ab0 */

int * FUN_005a1ab0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short sVar1;
  int iVar2;
  int *piVar3;
  short sVar4;
  
  iVar2 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar2 == 0) {
    piVar3 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0x19,0x18,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar3 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar3 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0x19)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar3 = (int *)(**(code **)(*piVar3 + 0x18))(param_1,param_2,param_4);
        return piVar3;
      }
      sVar4 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (sVar1 = 1, *(char *)(param_1 + 0x140b4) != '\0'))
      {
        piVar3 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar3,0,0x19,0,0x18,0,
                                     FUN_005984d0);
        if ((*(short *)(param_1 + 0x309a) == 0) ||
           (iVar2 = FUN_005b3cc0(param_1,param_2), iVar2 == 0)) {
LAB_005a1c26:
          if (((*(uint *)(param_1 + 8) & 0x1000) != 0) && (0 < sVar4)) {
            *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
            return (int *)0x0;
          }
          return piVar3;
        }
      }
      else {
        do {
          while ((sVar4 = sVar1, *(undefined4 *)(param_1 + 0x1615c) = 3, sVar4 != 0 &&
                 (iVar2 = FUN_005b73b0(param_1,"ns1:RenewLeaseResult",piVar3 + 2,"xsd:double",0x36),
                 iVar2 != 0))) {
            sVar1 = sVar4 + -1;
          }
          FUN_005b2cf0(param_1,"ns1:RenewLeaseResult");
          iVar2 = *(int *)(param_1 + 0x1615c);
          if (iVar2 == 3) {
            iVar2 = FUN_00599d40(param_1);
            *(int *)(param_1 + 0x1615c) = iVar2;
          }
          if (iVar2 == 6) {
            iVar2 = FUN_005b3cc0(param_1,param_2);
            if (iVar2 != 0) {
              return (int *)0x0;
            }
            goto LAB_005a1c26;
          }
          sVar1 = sVar4;
        } while (iVar2 == 0);
      }
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4570 ; VA 0x005a1c50 ; FUN_005a1c50 */

int * FUN_005a1c50(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if ((iVar1 == 0) &&
     (piVar2 = (int *)FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,0xc,0x14,0,param_1 + 0x144b4,
                                   param_1 + 0x148b4,FUN_005a2cc0), piVar2 != (int *)0x0)) {
    if ((*(short *)(param_1 + 0x1550a) != 0) &&
       ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0xc)) {
      FUN_005bb7f0(param_1);
      *(undefined *)(param_1 + 0x13cb4) = 0;
      piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
      return piVar2;
    }
    if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
      piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0xc,0,0x14,0,
                                   FUN_00598400);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar2;
    }
    do {
      do {
        *(undefined4 *)(param_1 + 0x1615c) = 3;
        iVar1 = FUN_005a29e0(param_1,"ns1:Job",piVar2 + 1,"ns1:Job");
      } while (iVar1 != 0);
      iVar1 = *(int *)(param_1 + 0x1615c);
      if (iVar1 == 3) {
        iVar1 = FUN_00599d40(param_1);
        *(int *)(param_1 + 0x1615c) = iVar1;
      }
      if (iVar1 == 6) {
        iVar1 = FUN_005b3cc0(param_1,param_2);
        if (iVar1 == 0) {
          return piVar2;
        }
        return (int *)0x0;
      }
    } while (iVar1 == 0);
  }
  return (int *)0x0;
}



/* FUNCTION 4571 ; VA 0x005a1da0 ; FUN_005a1da0 */

int * FUN_005a1da0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if ((iVar1 == 0) &&
     (piVar2 = (int *)FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,0xb,0x14,0,param_1 + 0x144b4,
                                   param_1 + 0x148b4,FUN_005a2cc0), piVar2 != (int *)0x0)) {
    if ((*(short *)(param_1 + 0x1550a) != 0) &&
       ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0xb)) {
      FUN_005bb7f0(param_1);
      *(undefined *)(param_1 + 0x13cb4) = 0;
      piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
      return piVar2;
    }
    if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
      piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,0xb,0,0x14,0,
                                   FUN_00598400);
      if ((*(short *)(param_1 + 0x309a) != 0) && (iVar1 = FUN_005b3cc0(param_1,param_2), iVar1 != 0)
         ) {
        return (int *)0x0;
      }
      return piVar2;
    }
    do {
      do {
        *(undefined4 *)(param_1 + 0x1615c) = 3;
        iVar1 = FUN_005a2b50(param_1,"ns1:LuaValue",piVar2 + 1,"ns1:LuaValue");
      } while (iVar1 != 0);
      iVar1 = *(int *)(param_1 + 0x1615c);
      if (iVar1 == 3) {
        iVar1 = FUN_00599d40(param_1);
        *(int *)(param_1 + 0x1615c) = iVar1;
      }
      if (iVar1 == 6) {
        iVar1 = FUN_005b3cc0(param_1,param_2);
        if (iVar1 == 0) {
          return piVar2;
        }
        return (int *)0x0;
      }
    } while (iVar1 == 0);
  }
  return (int *)0x0;
}



/* FUNCTION 4572 ; VA 0x005a1ef0 ; FUN_005a1ef0 */

int * FUN_005a1ef0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short sVar1;
  int iVar2;
  int *piVar3;
  short sVar4;
  short sVar5;
  short sVar6;
  short sVar7;
  
  iVar2 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar2 == 0) {
    piVar3 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,9,0x40,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar3 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar3 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 9)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar3 = (int *)(**(code **)(*piVar3 + 0x18))(param_1,param_2,param_4);
        return piVar3;
      }
      sVar4 = 1;
      sVar5 = 1;
      sVar7 = 1;
      sVar6 = 1;
      sVar1 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
        piVar3 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar3,0,9,0,0x40,0,
                                     FUN_00598530);
        if (*(short *)(param_1 + 0x309a) != 0) {
          iVar2 = FUN_005b3cc0(param_1,param_2);
joined_r0x005a20e3:
          if (iVar2 != 0) {
            return (int *)0x0;
          }
        }
        if (((*(uint *)(param_1 + 8) & 0x1000) != 0) &&
           ((((0 < sVar4 || (0 < sVar5)) || (0 < sVar1)) || (0 < sVar6)))) {
          *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
          return (int *)0x0;
        }
        return piVar3;
      }
LAB_005a1fc0:
      do {
        *(undefined4 *)(param_1 + 0x1615c) = 3;
        iVar2 = 3;
        if (sVar4 != 0) {
          iVar2 = FUN_005a2880(param_1,"ns1:id",piVar3 + 2,"xsd:string");
          if (iVar2 != 0) {
            sVar4 = sVar4 + -1;
            goto LAB_005a1fc0;
          }
          iVar2 = *(int *)(param_1 + 0x1615c);
        }
        if (((sVar5 != 0) && (iVar2 == 3)) &&
           (iVar2 = FUN_005b73b0(param_1,"ns1:expirationInSeconds",piVar3 + 8,"xsd:double",0x36),
           iVar2 != 0)) {
          sVar5 = sVar5 + -1;
          goto LAB_005a1fc0;
        }
        if (((sVar1 != 0) && (*(int *)(param_1 + 0x1615c) == 3)) &&
           (iVar2 = FUN_005b7550(param_1,"ns1:category",piVar3 + 10,"xsd:int",1), iVar2 != 0)) {
          sVar1 = sVar1 + -1;
          goto LAB_005a1fc0;
        }
        if (((sVar7 != 0) && (*(int *)(param_1 + 0x1615c) == 3)) &&
           (iVar2 = FUN_005b73b0(param_1,"ns1:cores",piVar3 + 0xc,"xsd:double",0x36), iVar2 != 0)) {
          sVar7 = sVar7 + -1;
          goto LAB_005a1fc0;
        }
        iVar2 = *(int *)(param_1 + 0x1615c);
        if (iVar2 == 3) {
          iVar2 = FUN_00599d40(param_1);
          *(int *)(param_1 + 0x1615c) = iVar2;
        }
        if (iVar2 == 6) {
          iVar2 = FUN_005b3cc0(param_1,param_2);
          sVar6 = sVar7;
          goto joined_r0x005a20e3;
        }
      } while (iVar2 == 0);
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4573 ; VA 0x005a2170 ; FUN_005a2170 */

uint * FUN_005a2170(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  uint *puVar2;
  uint *puVar3;
  uint uStack_8;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,param_4);
  if ((iVar1 == 0) &&
     (puVar2 = (uint *)FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,0x32,4,0,0,0,0),
     puVar2 != (uint *)0x0)) {
    if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
      puVar2 = (uint *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),puVar2,0,0x32,0,4,0,0);
      if (*(short *)(param_1 + 0x309a) == 0) {
        return puVar2;
      }
      iVar1 = FUN_005b3cc0(param_1,param_2);
    }
    else {
      iVar1 = FUN_005bde00(param_1);
      if (iVar1 != 0) {
        puVar3 = (uint *)FUN_005b2ed0(&DAT_018c16b4,iVar1);
        if (puVar3 == (uint *)0x0) {
          iVar1 = FUN_005bbbf0(param_1,iVar1,&uStack_8);
          if ((iVar1 != 0) || (((*(uint *)(param_1 + 8) & 0x1000) != 0 && (4 < uStack_8)))) {
            *(undefined4 *)(param_1 + 0x1615c) = 4;
            return (uint *)0x0;
          }
        }
        else {
          uStack_8 = *puVar3;
        }
        *puVar2 = uStack_8;
      }
      iVar1 = FUN_005b3cc0(param_1,param_2);
    }
    if (iVar1 == 0) {
      return puVar2;
    }
  }
  return (uint *)0x0;
}



/* FUNCTION 4574 ; VA 0x005a2280 ; FUN_005a2280 */

int * FUN_005a2280(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short sVar1;
  int iVar2;
  int *piVar3;
  short sVar4;
  short sVar5;
  
  iVar2 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar2 == 0) {
    piVar3 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,0xd,0x14,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar3 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar3 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 0xd)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar3 = (int *)(**(code **)(*piVar3 + 0x18))(param_1,param_2,param_4);
        return piVar3;
      }
      sVar5 = 1;
      sVar4 = 1;
      sVar1 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
        piVar3 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar3,0,0xd,0,0x14,0,
                                     FUN_00598580);
        if (*(short *)(param_1 + 0x309a) != 0) {
          iVar2 = FUN_005b3cc0(param_1,param_2);
joined_r0x005a241f:
          if (iVar2 != 0) {
            return (int *)0x0;
          }
        }
        if (((*(uint *)(param_1 + 8) & 0x1000) != 0) && (0 < sVar5)) {
          *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
          return (int *)0x0;
        }
        return piVar3;
      }
LAB_005a2341:
      do {
        *(undefined4 *)(param_1 + 0x1615c) = 3;
        iVar2 = 3;
        if (sVar5 != 0) {
          iVar2 = FUN_005a2170(param_1,"ns1:type",piVar3 + 1,"ns1:LuaType");
          if (iVar2 != 0) {
            sVar5 = sVar5 + -1;
            goto LAB_005a2341;
          }
          iVar2 = *(int *)(param_1 + 0x1615c);
        }
        if ((sVar4 != 0) &&
           (((iVar2 == 3 || (iVar2 == 6)) &&
            (iVar2 = FUN_0059cd50(param_1,"ns1:value",piVar3 + 2,"xsd:string"), iVar2 != 0)))) {
          sVar4 = sVar4 + -1;
          goto LAB_005a2341;
        }
        if (((sVar1 != 0) && (*(int *)(param_1 + 0x1615c) == 3)) &&
           (iVar2 = FUN_0059c8f0(param_1,"ns1:table",piVar3 + 3,"ns1:ArrayOfLuaValue"), iVar2 != 0))
        {
          sVar1 = sVar1 + -1;
          goto LAB_005a2341;
        }
        iVar2 = *(int *)(param_1 + 0x1615c);
        if (iVar2 == 3) {
          iVar2 = FUN_00599d40(param_1);
          *(int *)(param_1 + 0x1615c) = iVar2;
        }
        if (iVar2 == 6) {
          iVar2 = FUN_005b3cc0(param_1,param_2);
          goto joined_r0x005a241f;
        }
      } while (iVar2 == 0);
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4575 ; VA 0x005a2490 ; FUN_005a2490 */

int * FUN_005a2490(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  short sVar3;
  short sVar4;
  short sVar5;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar1 == 0) {
    piVar2 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,10,0x14,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar2 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 10)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
        return piVar2;
      }
      sVar3 = 1;
      sVar4 = 1;
      sVar5 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
        piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,10,0,0x14,0,
                                     FUN_00598580);
        if (*(short *)(param_1 + 0x309a) != 0) {
          iVar1 = FUN_005b3cc0(param_1,param_2);
joined_r0x005a2649:
          if (iVar1 != 0) {
            return (int *)0x0;
          }
        }
        return piVar2;
      }
LAB_005a2560:
      do {
        *(undefined4 *)(param_1 + 0x1615c) = 3;
        iVar1 = 3;
        if (sVar3 != 0) {
          iVar1 = FUN_0059cd50(param_1,"ns1:name",piVar2 + 1,"xsd:string");
          if (iVar1 != 0) {
            sVar3 = sVar3 + -1;
            goto LAB_005a2560;
          }
          iVar1 = *(int *)(param_1 + 0x1615c);
        }
        if ((sVar4 != 0) &&
           (((iVar1 == 3 || (iVar1 == 6)) &&
            (iVar1 = FUN_0059cd50(param_1,"ns1:script",piVar2 + 2,"xsd:string"), iVar1 != 0)))) {
          sVar4 = sVar4 + -1;
          goto LAB_005a2560;
        }
        if (((sVar5 != 0) && (*(int *)(param_1 + 0x1615c) == 3)) &&
           (iVar1 = FUN_0059c8f0(param_1,"ns1:arguments",piVar2 + 3,"ns1:ArrayOfLuaValue"),
           iVar1 != 0)) {
          sVar5 = sVar5 + -1;
          goto LAB_005a2560;
        }
        iVar1 = *(int *)(param_1 + 0x1615c);
        if (iVar1 == 3) {
          iVar1 = FUN_00599d40(param_1);
          *(int *)(param_1 + 0x1615c) = iVar1;
        }
        if (iVar1 == 6) {
          iVar1 = FUN_005b3cc0(param_1,param_2);
          goto joined_r0x005a2649;
        }
      } while (iVar1 == 0);
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4576 ; VA 0x005a26a0 ; FUN_005a26a0 */

int * FUN_005a26a0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  short sVar3;
  short sVar4;
  short sVar5;
  
  iVar1 = FUN_005b3b70(param_1,param_2,0,0);
  if (iVar1 == 0) {
    piVar2 = (int *)FUN_005b6e40(param_1,(undefined *)(param_1 + 0x13cb4),param_3,8,0x10,0,
                                 param_1 + 0x144b4,param_1 + 0x148b4,FUN_005a2cc0);
    if (piVar2 != (int *)0x0) {
      if ((*(short *)(param_1 + 0x1550a) != 0) &&
         ((**(code **)(*piVar2 + 4))(param_1), *(int *)(*(int *)(param_1 + 0x60) + 8) != 8)) {
        FUN_005bb7f0(param_1);
        *(undefined *)(param_1 + 0x13cb4) = 0;
        piVar2 = (int *)(**(code **)(*piVar2 + 0x18))(param_1,param_2,param_4);
        return piVar2;
      }
      sVar3 = 1;
      sVar5 = 1;
      sVar4 = 1;
      if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
        piVar2 = (int *)FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),piVar2,0,8,0,0x10,0,
                                     FUN_005983c0);
        if (*(short *)(param_1 + 0x309a) != 0) {
          iVar1 = FUN_005b3cc0(param_1,param_2);
joined_r0x005a2805:
          if (iVar1 != 0) {
            return (int *)0x0;
          }
        }
        if (((*(uint *)(param_1 + 8) & 0x1000) != 0) && (0 < sVar4)) {
          *(undefined4 *)(param_1 + 0x1615c) = 0x2c;
          return (int *)0x0;
        }
        return piVar2;
      }
LAB_005a2760:
      do {
        *(undefined4 *)(param_1 + 0x1615c) = 3;
        iVar1 = 3;
        if (sVar3 != 0) {
          iVar1 = FUN_0059cd50(param_1,"ns1:version",piVar2 + 1,"xsd:string");
          if (iVar1 != 0) {
            sVar3 = sVar3 + -1;
            goto LAB_005a2760;
          }
          iVar1 = *(int *)(param_1 + 0x1615c);
        }
        if (((sVar5 != 0) && (iVar1 == 3)) &&
           (iVar1 = FUN_005b7550(param_1,"ns1:environmentCount",piVar2 + 2,"xsd:int",1), iVar1 != 0)
           ) {
          sVar5 = sVar5 + -1;
          goto LAB_005a2760;
        }
        iVar1 = *(int *)(param_1 + 0x1615c);
        if (iVar1 == 3) {
          iVar1 = FUN_00599d40(param_1);
          *(int *)(param_1 + 0x1615c) = iVar1;
        }
        if (iVar1 == 6) {
          iVar1 = FUN_005b3cc0(param_1,param_2);
          sVar4 = sVar5;
          goto joined_r0x005a2805;
        }
      } while (iVar1 == 0);
    }
  }
  return (int *)0x0;
}



/* FUNCTION 4577 ; VA 0x005a2880 ; FUN_005a2880 */

int FUN_005a2880(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 uVar4;
  
  iVar1 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar1 != 0) {
    return 0;
  }
  if (param_3 == (undefined4 *)0x0) {
    iVar1 = FUN_005b7ec0(param_1,0,0x33,0xffffffff,FUN_00598780);
    if (iVar1 == 0) {
      param_3 = (undefined4 *)0x0;
    }
    else {
      param_3 = (undefined4 *)FUN_01674e20(0x18);
      if (param_3 == (undefined4 *)0x0) {
        param_3 = (undefined4 *)0x0;
      }
      else {
        param_3[4] = 0;
        param_3[5] = 0xf;
        *(undefined *)param_3 = 0;
      }
      *(undefined4 **)(iVar1 + 4) = param_3;
    }
  }
  if ((*(short *)(param_1 + 0x15504) != 0) && (param_3 != (undefined4 *)0x0)) {
    puVar2 = param_3;
    if (0xf < (uint)param_3[5]) {
      puVar2 = (undefined4 *)*param_3;
    }
    param_3[4] = 0;
    *(undefined *)puVar2 = 0;
  }
  if ((*(short *)(param_1 + 0x309a) == 0) || (*(char *)(param_1 + 0x140b4) != '\0')) {
    uVar4 = FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,0x33,0x18,0,param_1 + 0x144b4,
                         param_1 + 0x148b4,FUN_005a2cc0);
    iVar1 = FUN_005b6f90(param_1,(char *)(param_1 + 0x140b4),uVar4,0,0x33,0,0x18,0,FUN_005985b0);
  }
  else {
    iVar1 = FUN_005b6e40(param_1,param_1 + 0x13cb4,param_3,0x33,0x18,0,param_1 + 0x144b4,
                         param_1 + 0x148b4,FUN_005a2cc0);
    if (iVar1 != 0) {
      iVar3 = FUN_005bd410(param_1,1,0xffffffff,0xffffffff);
      if (iVar3 == 0) {
        return 0;
      }
      FUN_00551260(iVar3);
    }
  }
  if ((*(short *)(param_1 + 0x309a) != 0) && (iVar3 = FUN_005b3cc0(param_1,param_2), iVar3 != 0)) {
    return 0;
  }
  return iVar1;
}



/* FUNCTION 4578 ; VA 0x005a29e0 ; FUN_005a29e0 */

int * FUN_005a29e0(int param_1,undefined4 param_2,int *param_3)

{
  bool bVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uStack_8;
  
  iVar2 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar2 != 0) {
    return (int *)0x0;
  }
  if (param_3 == (int *)0x0) {
    iVar2 = FUN_005b7ec0(param_1,0,0x3b,0xffffffff,FUN_00598780);
    if (iVar2 == 0) {
      return (int *)0x0;
    }
    param_3 = (int *)FUN_01674e20(0xc);
    if (param_3 == (int *)0x0) {
      param_3 = (int *)0x0;
    }
    else {
      *param_3 = 0;
      param_3[1] = 0;
      param_3[2] = 0;
    }
    *(int **)(iVar2 + 4) = param_3;
    if (param_3 == (int *)0x0) {
      return (int *)0x0;
    }
  }
  bVar1 = false;
  do {
    FUN_005bb7f0(param_1);
    uStack_8 = 0;
    if ((*(char *)(param_1 + 0x13cb4) != '\0') || (*(char *)(param_1 + 0x140b4) != '\0')) {
      iVar2 = 0x13cb4;
      if (*(char *)(param_1 + 0x13cb4) == '\0') {
        iVar2 = 0x140b4;
      }
      iVar2 = FUN_005b6f90(param_1,iVar2 + param_1,param_3,param_3[1] - *param_3 >> 2,9,0x3b,0x40,1,
                           FUN_00598390);
      if (iVar2 != 0) {
        puVar3 = (undefined4 *)0x0;
        goto LAB_005a2acf;
      }
LAB_005a2b1b:
      if (!bVar1) {
        return (int *)0x0;
      }
      break;
    }
    puVar3 = &uStack_8;
LAB_005a2acf:
    iVar2 = FUN_0059c9c0(param_1,param_2,puVar3,"ns1:Job");
    if (iVar2 == 0) goto LAB_005a2b1b;
    puVar3 = (undefined4 *)param_3[1];
    if ((undefined4 *)param_3[2] == puVar3) {
      FUN_00595d30(puVar3,&uStack_8);
    }
    else {
      *puVar3 = uStack_8;
      param_3[1] = param_3[1] + 4;
    }
    bVar1 = true;
    iVar2 = FUN_005b3b70(param_1,param_2,1,0);
  } while (iVar2 == 0);
  if ((*(int *)(param_1 + 0x1615c) != 3) && (*(int *)(param_1 + 0x1615c) != 6)) {
    return (int *)0x0;
  }
  *(undefined4 *)(param_1 + 0x1615c) = 0;
  return param_3;
}



/* FUNCTION 4579 ; VA 0x005a2b50 ; FUN_005a2b50 */

int * FUN_005a2b50(int param_1,undefined4 param_2,int *param_3)

{
  bool bVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uStack_8;
  
  iVar2 = FUN_005b3b70(param_1,param_2,1,0);
  if (iVar2 != 0) {
    return (int *)0x0;
  }
  if (param_3 == (int *)0x0) {
    iVar2 = FUN_005b7ec0(param_1,0,0x39,0xffffffff,FUN_00598780);
    if (iVar2 == 0) {
      return (int *)0x0;
    }
    param_3 = (int *)FUN_01674e20(0xc);
    if (param_3 == (int *)0x0) {
      param_3 = (int *)0x0;
    }
    else {
      *param_3 = 0;
      param_3[1] = 0;
      param_3[2] = 0;
    }
    *(int **)(iVar2 + 4) = param_3;
    if (param_3 == (int *)0x0) {
      return (int *)0x0;
    }
  }
  bVar1 = false;
  do {
    FUN_005bb7f0(param_1);
    uStack_8 = 0;
    if ((*(char *)(param_1 + 0x13cb4) != '\0') || (*(char *)(param_1 + 0x140b4) != '\0')) {
      iVar2 = 0x13cb4;
      if (*(char *)(param_1 + 0x13cb4) == '\0') {
        iVar2 = 0x140b4;
      }
      iVar2 = FUN_005b6f90(param_1,iVar2 + param_1,param_3,param_3[1] - *param_3 >> 2,0xd,0x39,0x14,
                           1,FUN_00598390);
      if (iVar2 != 0) {
        puVar3 = (undefined4 *)0x0;
        goto LAB_005a2c3f;
      }
LAB_005a2c8b:
      if (!bVar1) {
        return (int *)0x0;
      }
      break;
    }
    puVar3 = &uStack_8;
LAB_005a2c3f:
    iVar2 = FUN_0059ca90(param_1,param_2,puVar3,"ns1:LuaValue");
    if (iVar2 == 0) goto LAB_005a2c8b;
    puVar3 = (undefined4 *)param_3[1];
    if ((undefined4 *)param_3[2] == puVar3) {
      FUN_00595d30(puVar3,&uStack_8);
    }
    else {
      *puVar3 = uStack_8;
      param_3[1] = param_3[1] + 4;
    }
    bVar1 = true;
    iVar2 = FUN_005b3b70(param_1,param_2,1,0);
  } while (iVar2 == 0);
  if ((*(int *)(param_1 + 0x1615c) != 3) && (*(int *)(param_1 + 0x1615c) != 6)) {
    return (int *)0x0;
  }
  *(undefined4 *)(param_1 + 0x1615c) = 0;
  return param_3;
}



/* FUNCTION 4580 ; VA 0x005a2cc0 ; FUN_005a2cc0 */

undefined4 FUN_005a2cc0(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  switch(param_2) {
  case 8:
    uVar1 = FUN_005a83b0();
    return uVar1;
  case 9:
    uVar1 = FUN_005a7f80();
    return uVar1;
  case 10:
    uVar1 = FUN_005a8250();
    return uVar1;
  case 0xb:
    uVar1 = FUN_005a7e20();
    return uVar1;
  case 0xc:
    uVar1 = FUN_005a7cc0();
    return uVar1;
  case 0xd:
    uVar1 = FUN_005a80f0();
    return uVar1;
  case 0xe:
    uVar1 = FUN_005a7220();
    return uVar1;
  case 0xf:
    uVar1 = FUN_005a7370();
    return uVar1;
  case 0x10:
    uVar1 = FUN_005a6f70();
    return uVar1;
  case 0x11:
    uVar1 = FUN_005a70c0();
    return uVar1;
  case 0x12:
    uVar1 = FUN_005a6cd0();
    return uVar1;
  case 0x13:
    uVar1 = FUN_005a6e20();
    return uVar1;
  case 0x14:
    uVar1 = FUN_005a74c0();
    return uVar1;
  case 0x15:
    uVar1 = FUN_005a7610();
    return uVar1;
  case 0x16:
    uVar1 = FUN_005a78b0();
    return uVar1;
  case 0x17:
    uVar1 = FUN_005a7760();
    return uVar1;
  case 0x18:
    uVar1 = FUN_005a7a10();
    return uVar1;
  case 0x19:
    uVar1 = FUN_005a7b70();
    return uVar1;
  case 0x1a:
    uVar1 = FUN_005a5f60();
    return uVar1;
  case 0x1b:
    uVar1 = FUN_005a6370();
    return uVar1;
  case 0x1c:
    uVar1 = FUN_005a60c0();
    return uVar1;
  case 0x1d:
    uVar1 = FUN_005a6220();
    return uVar1;
  case 0x1e:
    uVar1 = FUN_005a5760();
    return uVar1;
  case 0x1f:
    uVar1 = FUN_005a58c0();
    return uVar1;
  case 0x20:
    uVar1 = FUN_005a4cd0();
    return uVar1;
  case 0x21:
    uVar1 = FUN_005a50c0();
    return uVar1;
  case 0x22:
    uVar1 = FUN_005a4e20();
    return uVar1;
  case 0x23:
    uVar1 = FUN_005a4f70();
    return uVar1;
  case 0x24:
    uVar1 = FUN_005a6a20();
    return uVar1;
  case 0x25:
    uVar1 = FUN_005a6b80();
    return uVar1;
  case 0x26:
    uVar1 = FUN_005a64d0();
    return uVar1;
  case 0x27:
    uVar1 = FUN_005a68c0();
    return uVar1;
  case 0x28:
    uVar1 = FUN_005a6620();
    return uVar1;
  case 0x29:
    uVar1 = FUN_005a6770();
    return uVar1;
  case 0x2a:
    uVar1 = FUN_005a54c0();
    return uVar1;
  case 0x2b:
    uVar1 = FUN_005a5610();
    return uVar1;
  case 0x2c:
    uVar1 = FUN_005a5220();
    return uVar1;
  case 0x2d:
    uVar1 = FUN_005a5370();
    return uVar1;
  case 0x2e:
    uVar1 = FUN_005a5a10();
    return uVar1;
  case 0x2f:
    uVar1 = FUN_005a5e00();
    return uVar1;
  case 0x30:
    uVar1 = FUN_005a5b60();
    return uVar1;
  case 0x31:
    uVar1 = FUN_005a5cb0();
    return uVar1;
  default:
    return 0;
  case 0x33:
    uVar1 = FUN_005a8500();
    return uVar1;
  case 0x39:
    uVar1 = FUN_005a86e0();
    return uVar1;
  case 0x3b:
    uVar1 = FUN_005a85f0();
    return uVar1;
  case 0x42:
    uVar1 = FUN_005a3f10();
    return uVar1;
  case 0x46:
    uVar1 = FUN_005a3e70();
    return uVar1;
  case 0x4a:
    uVar1 = FUN_005a3dd0();
    return uVar1;
  case 0x4e:
    uVar1 = FUN_005a3fb0();
    return uVar1;
  case 0x52:
    uVar1 = FUN_005a4050();
    return uVar1;
  case 0x56:
    uVar1 = FUN_005a40f0();
    return uVar1;
  case 0x5a:
    uVar1 = FUN_005a3ab0();
    return uVar1;
  case 0x5e:
    uVar1 = FUN_005a3b50();
    return uVar1;
  case 0x62:
    uVar1 = FUN_005a38d0();
    return uVar1;
  case 0x66:
    uVar1 = FUN_005a3650();
    return uVar1;
  case 0x6a:
    uVar1 = FUN_005a36f0();
    return uVar1;
  case 0x6e:
    uVar1 = FUN_005a3d30();
    return uVar1;
  case 0x72:
    uVar1 = FUN_005a3bf0();
    return uVar1;
  case 0x76:
    uVar1 = FUN_005a3c90();
    return uVar1;
  case 0x7a:
    uVar1 = FUN_005a3830();
    return uVar1;
  case 0x7e:
    uVar1 = FUN_005a3790();
    return uVar1;
  case 0x82:
    uVar1 = FUN_005a3970();
    return uVar1;
  case 0x86:
    uVar1 = FUN_005a3a10();
    return uVar1;
  case 0x88:
    uVar1 = FUN_005a4a50();
    return uVar1;
  case 0x8a:
    uVar1 = FUN_005a49b0();
    return uVar1;
  case 0x8c:
    uVar1 = FUN_005a4910();
    return uVar1;
  case 0x8e:
    uVar1 = FUN_005a4af0();
    return uVar1;
  case 0x90:
    uVar1 = FUN_005a4b90();
    return uVar1;
  case 0x92:
    uVar1 = FUN_005a4c30();
    return uVar1;
  case 0x94:
    uVar1 = FUN_005a45f0();
    return uVar1;
  case 0x96:
    uVar1 = FUN_005a4690();
    return uVar1;
  case 0x98:
    uVar1 = FUN_005a4410();
    return uVar1;
  case 0x9a:
    uVar1 = FUN_005a4190();
    return uVar1;
  case 0x9c:
    uVar1 = FUN_005a4230();
    return uVar1;
  case 0x9e:
    uVar1 = FUN_005a4870();
    return uVar1;
  case 0xa0:
    uVar1 = FUN_005a4730();
    return uVar1;
  case 0xa2:
    uVar1 = FUN_005a47d0();
    return uVar1;
  case 0xa4:
    uVar1 = FUN_005a4370();
    return uVar1;
  case 0xa6:
    uVar1 = FUN_005a42d0();
    return uVar1;
  case 0xa8:
    uVar1 = FUN_005a44b0();
    return uVar1;
  case 0xaa:
    uVar1 = FUN_005a4550();
    return uVar1;
  case 0xab:
    uVar1 = FUN_005a3530();
    return uVar1;
  case 0xac:
    uVar1 = FUN_005a3350();
    return uVar1;
  case 0xae:
    uVar1 = FUN_005a33f0();
    return uVar1;
  case 0xb1:
    uVar1 = FUN_005a35b0();
    return uVar1;
  case 0xb2:
    uVar1 = FUN_005a3490();
    return uVar1;
  }
}



/* FUNCTION 4581 ; VA 0x005a3350 ; FUN_005a3350 */

undefined4 FUN_005a3350(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0xac,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(8);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 8;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 8 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 8));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 8;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4582 ; VA 0x005a33f0 ; FUN_005a33f0 */

undefined4 FUN_005a33f0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0xae,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(0xc);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0xc;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 0xc >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 0xc));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0xc;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4583 ; VA 0x005a3490 ; FUN_005a3490 */

undefined4 FUN_005a3490(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0xb2,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(0x24);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x24;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 0x24 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 0x24));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0x24;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4584 ; VA 0x005a3530 ; FUN_005a3530 */

undefined4 FUN_005a3530(int param_1,int param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0xab,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if (param_2 < 0) {
    uVar2 = FUN_01674e20(1);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 1;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(param_2);
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4585 ; VA 0x005a35b0 ; FUN_005a35b0 */

undefined4 FUN_005a35b0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0xb1,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4586 ; VA 0x005a3650 ; FUN_005a3650 */

undefined4 FUN_005a3650(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x66,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4587 ; VA 0x005a36f0 ; FUN_005a36f0 */

undefined4 FUN_005a36f0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x6a,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4588 ; VA 0x005a3790 ; FUN_005a3790 */

undefined4 FUN_005a3790(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x7e,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4589 ; VA 0x005a3830 ; FUN_005a3830 */

undefined4 FUN_005a3830(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x7a,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4590 ; VA 0x005a38d0 ; FUN_005a38d0 */

undefined4 FUN_005a38d0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x62,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4591 ; VA 0x005a3970 ; FUN_005a3970 */

undefined4 FUN_005a3970(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x82,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4592 ; VA 0x005a3a10 ; FUN_005a3a10 */

undefined4 FUN_005a3a10(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x86,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4593 ; VA 0x005a3ab0 ; FUN_005a3ab0 */

undefined4 FUN_005a3ab0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x5a,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4594 ; VA 0x005a3b50 ; FUN_005a3b50 */

undefined4 FUN_005a3b50(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x5e,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4595 ; VA 0x005a3bf0 ; FUN_005a3bf0 */

undefined4 FUN_005a3bf0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x72,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4596 ; VA 0x005a3c90 ; FUN_005a3c90 */

undefined4 FUN_005a3c90(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x76,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4597 ; VA 0x005a3d30 ; FUN_005a3d30 */

undefined4 FUN_005a3d30(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x6e,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4598 ; VA 0x005a3dd0 ; FUN_005a3dd0 */

undefined4 FUN_005a3dd0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x4a,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4599 ; VA 0x005a3e70 ; FUN_005a3e70 */

undefined4 FUN_005a3e70(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x46,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4600 ; VA 0x005a3f10 ; FUN_005a3f10 */

undefined4 FUN_005a3f10(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x42,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4601 ; VA 0x005a3fb0 ; FUN_005a3fb0 */

undefined4 FUN_005a3fb0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x4e,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4602 ; VA 0x005a4050 ; FUN_005a4050 */

undefined4 FUN_005a4050(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x52,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4603 ; VA 0x005a40f0 ; FUN_005a40f0 */

undefined4 FUN_005a40f0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x56,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4604 ; VA 0x005a4190 ; FUN_005a4190 */

undefined4 FUN_005a4190(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x9a,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4605 ; VA 0x005a4230 ; FUN_005a4230 */

undefined4 FUN_005a4230(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x9c,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4606 ; VA 0x005a42d0 ; FUN_005a42d0 */

undefined4 FUN_005a42d0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0xa6,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4607 ; VA 0x005a4370 ; FUN_005a4370 */

undefined4 FUN_005a4370(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0xa4,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4608 ; VA 0x005a4410 ; FUN_005a4410 */

undefined4 FUN_005a4410(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x98,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4609 ; VA 0x005a44b0 ; FUN_005a44b0 */

undefined4 FUN_005a44b0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0xa8,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4610 ; VA 0x005a4550 ; FUN_005a4550 */

undefined4 FUN_005a4550(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0xaa,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4611 ; VA 0x005a45f0 ; FUN_005a45f0 */

undefined4 FUN_005a45f0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x94,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4612 ; VA 0x005a4690 ; FUN_005a4690 */

undefined4 FUN_005a4690(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x96,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4613 ; VA 0x005a4730 ; FUN_005a4730 */

undefined4 FUN_005a4730(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0xa0,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4614 ; VA 0x005a47d0 ; FUN_005a47d0 */

undefined4 FUN_005a47d0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0xa2,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4615 ; VA 0x005a4870 ; FUN_005a4870 */

undefined4 FUN_005a4870(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x9e,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4616 ; VA 0x005a4910 ; FUN_005a4910 */

undefined4 FUN_005a4910(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x8c,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4617 ; VA 0x005a49b0 ; FUN_005a49b0 */

undefined4 FUN_005a49b0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x8a,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4618 ; VA 0x005a4a50 ; FUN_005a4a50 */

undefined4 FUN_005a4a50(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x88,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4619 ; VA 0x005a4af0 ; FUN_005a4af0 */

undefined4 FUN_005a4af0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x8e,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4620 ; VA 0x005a4b90 ; FUN_005a4b90 */

undefined4 FUN_005a4b90(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x90,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4621 ; VA 0x005a4c30 ; FUN_005a4c30 */

undefined4 FUN_005a4c30(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x92,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return 0;
  }
  if ((int)param_2 < 0) {
    uVar2 = FUN_01674e20(4);
    *(undefined4 *)(iVar1 + 4) = uVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 4;
      return *(undefined4 *)(iVar1 + 4);
    }
  }
  else {
    iVar3 = FUN_01674e20(-(uint)((int)((ulonglong)param_2 * 4 >> 0x20) != 0) |
                         (uint)((ulonglong)param_2 * 4));
    *(int *)(iVar1 + 4) = iVar3;
    if (iVar3 == 0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return 0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 4;
    }
  }
  return *(undefined4 *)(iVar1 + 4);
}



/* FUNCTION 4622 ; VA 0x005a4cd0 ; FUN_005a4cd0 */

uint * FUN_005a4cd0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797cad;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x20,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x10);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__BatchJob::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x10;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[3] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x10 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x10);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x10,param_2,&LAB_0056a490,FUN_0056e630);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 << 4;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      iVar5 = iVar5 + 0x10;
      *(int *)(*(int *)(iVar1 + 4) + -4 + iVar5) = param_1;
      param_2 = param_2 - 1;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4623 ; VA 0x005a4e20 ; FUN_005a4e20 */

uint * FUN_005a4e20(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797cad;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x22,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x10);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__BatchJobEx::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x10;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[3] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x10 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x10);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x10,param_2,&LAB_00595e80,&LAB_00596370);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 << 4;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      iVar5 = iVar5 + 0x10;
      *(int *)(*(int *)(iVar1 + 4) + -4 + iVar5) = param_1;
      param_2 = param_2 - 1;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4624 ; VA 0x005a4f70 ; FUN_005a4f70 */

uint * FUN_005a4f70(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797ced;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x23,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0xc);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__BatchJobExResponse::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0xc;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[2] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0xc >> 0x20) != 0) | (uint)((ulonglong)param_2 * 0xc)
    ;
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0xc,param_2,&LAB_00595ea0,FUN_00596380);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0xc;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 8 + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0xc;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4625 ; VA 0x005a50c0 ; FUN_005a50c0 */

uint * FUN_005a50c0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797d2d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x21,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x14);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__BatchJobResponse::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
      puVar2[4] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x14;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[4] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x14 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x14);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x14,param_2,FUN_0056a4b0,FUN_0056e640);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0x14;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 0x10 + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0x14;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4626 ; VA 0x005a5220 ; FUN_005a5220 */

uint * FUN_005a5220(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797d6d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x2c,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(8);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__CloseAllJobs::vftable;
      puVar2[1] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 8;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[1] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 8 >> 0x20) != 0) | (uint)((ulonglong)param_2 * 8);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,8,param_2,&LAB_00595ec0,&LAB_00596390);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 8;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    iVar5 = 0;
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    do {
      *(int *)(*(int *)(iVar1 + 4) + 4 + iVar5 * 8) = param_1;
      iVar5 = iVar5 + 1;
    } while (iVar5 < (int)param_2);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4627 ; VA 0x005a5370 ; FUN_005a5370 */

uint * FUN_005a5370(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797ced;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x2d,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0xc);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__CloseAllJobsResponse::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0xc;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[2] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0xc >> 0x20) != 0) | (uint)((ulonglong)param_2 * 0xc)
    ;
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0xc,param_2,&LAB_00595ed0,FUN_005963a0);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0xc;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 8 + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0xc;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4628 ; VA 0x005a54c0 ; FUN_005a54c0 */

uint * FUN_005a54c0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797d6d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x2a,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(8);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__CloseExpiredJobs::vftable;
      puVar2[1] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 8;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[1] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 8 >> 0x20) != 0) | (uint)((ulonglong)param_2 * 8);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,8,param_2,&LAB_00595ef0,&LAB_005963b0);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 8;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    iVar5 = 0;
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    do {
      *(int *)(*(int *)(iVar1 + 4) + 4 + iVar5 * 8) = param_1;
      iVar5 = iVar5 + 1;
    } while (iVar5 < (int)param_2);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4629 ; VA 0x005a5610 ; FUN_005a5610 */

uint * FUN_005a5610(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797ced;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x2b,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0xc);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__CloseExpiredJobsResponse::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0xc;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[2] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0xc >> 0x20) != 0) | (uint)((ulonglong)param_2 * 0xc)
    ;
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0xc,param_2,&LAB_00595f00,FUN_005963c0);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0xc;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 8 + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0xc;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4630 ; VA 0x005a5760 ; FUN_005a5760 */

uint * FUN_005a5760(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797dad;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x1e,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x20);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__CloseJob::vftable;
      puVar2[5] = 0;
      puVar2[6] = 0xf;
      *(undefined *)(puVar2 + 1) = 0;
      puVar2[7] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x20;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[7] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x20 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x20);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x20,param_2,FUN_00595f20,FUN_005963d0);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 << 5;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 0x1c + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0x20;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4631 ; VA 0x005a58c0 ; FUN_005a58c0 */

uint * FUN_005a58c0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797d6d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x1f,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(8);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__CloseJobResponse::vftable;
      puVar2[1] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 8;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[1] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 8 >> 0x20) != 0) | (uint)((ulonglong)param_2 * 8);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,8,param_2,&LAB_00595f50,FUN_00596430);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 8;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    iVar5 = 0;
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    do {
      *(int *)(*(int *)(iVar1 + 4) + 4 + iVar5 * 8) = param_1;
      iVar5 = iVar5 + 1;
    } while (iVar5 < (int)param_2);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4632 ; VA 0x005a5a10 ; FUN_005a5a10 */

uint * FUN_005a5a10(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797cad;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x2e,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x10);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__Diag::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x10;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[3] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x10 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x10);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x10,param_2,&LAB_00595f60,&LAB_00596440);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 << 4;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      iVar5 = iVar5 + 0x10;
      *(int *)(*(int *)(iVar1 + 4) + -4 + iVar5) = param_1;
      param_2 = param_2 - 1;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4633 ; VA 0x005a5b60 ; FUN_005a5b60 */

uint * FUN_005a5b60(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797cad;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x30,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x10);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__DiagEx::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x10;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[3] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x10 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x10);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x10,param_2,&LAB_00595f80,&LAB_00596450);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 << 4;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      iVar5 = iVar5 + 0x10;
      *(int *)(*(int *)(iVar1 + 4) + -4 + iVar5) = param_1;
      param_2 = param_2 - 1;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4634 ; VA 0x005a5cb0 ; FUN_005a5cb0 */

uint * FUN_005a5cb0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797ced;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x31,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0xc);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__DiagExResponse::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0xc;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[2] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0xc >> 0x20) != 0) | (uint)((ulonglong)param_2 * 0xc)
    ;
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0xc,param_2,&LAB_00595fa0,FUN_00596460);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0xc;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 8 + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0xc;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4635 ; VA 0x005a5e00 ; FUN_005a5e00 */

uint * FUN_005a5e00(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797d2d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x2f,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x14);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__DiagResponse::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
      puVar2[4] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x14;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[4] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x14 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x14);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x14,param_2,FUN_00595fc0,FUN_00596470);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0x14;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 0x10 + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0x14;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4636 ; VA 0x005a5f60 ; FUN_005a5f60 */

uint * FUN_005a5f60(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797ded;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x1a,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x24);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__Execute::vftable;
      puVar2[5] = 0;
      puVar2[6] = 0xf;
      *(undefined *)(puVar2 + 1) = 0;
      puVar2[7] = 0;
      puVar2[8] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x24;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[8] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x24 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x24);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x24,param_2,FUN_00595ff0,FUN_005964d0);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0x24;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      iVar5 = iVar5 + 0x24;
      *(int *)(*(int *)(iVar1 + 4) + -4 + iVar5) = param_1;
      param_2 = param_2 - 1;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4637 ; VA 0x005a60c0 ; FUN_005a60c0 */

uint * FUN_005a60c0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797ded;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x1c,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x24);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__ExecuteEx::vftable;
      puVar2[5] = 0;
      puVar2[6] = 0xf;
      *(undefined *)(puVar2 + 1) = 0;
      puVar2[7] = 0;
      puVar2[8] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x24;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[8] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x24 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x24);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x24,param_2,FUN_00596030,FUN_00596530);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0x24;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      iVar5 = iVar5 + 0x24;
      *(int *)(*(int *)(iVar1 + 4) + -4 + iVar5) = param_1;
      param_2 = param_2 - 1;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4638 ; VA 0x005a6220 ; FUN_005a6220 */

uint * FUN_005a6220(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797ced;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x1d,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0xc);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__ExecuteExResponse::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0xc;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[2] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0xc >> 0x20) != 0) | (uint)((ulonglong)param_2 * 0xc)
    ;
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0xc,param_2,&LAB_00596070,FUN_00596590);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0xc;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 8 + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0xc;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4639 ; VA 0x005a6370 ; FUN_005a6370 */

uint * FUN_005a6370(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797d2d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x1b,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x14);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__ExecuteResponse::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
      puVar2[4] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x14;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[4] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x14 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x14);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x14,param_2,FUN_00596090,FUN_005965a0);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0x14;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 0x10 + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0x14;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4640 ; VA 0x005a64d0 ; FUN_005a64d0 */

uint * FUN_005a64d0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797d6d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x26,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(8);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__GetAllJobs::vftable;
      puVar2[1] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 8;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[1] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 8 >> 0x20) != 0) | (uint)((ulonglong)param_2 * 8);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,8,param_2,&LAB_005960c0,&LAB_00596600);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 8;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    iVar5 = 0;
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    do {
      *(int *)(*(int *)(iVar1 + 4) + 4 + iVar5 * 8) = param_1;
      iVar5 = iVar5 + 1;
    } while (iVar5 < (int)param_2);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4641 ; VA 0x005a6620 ; FUN_005a6620 */

uint * FUN_005a6620(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797d6d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x28,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(8);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__GetAllJobsEx::vftable;
      puVar2[1] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 8;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[1] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 8 >> 0x20) != 0) | (uint)((ulonglong)param_2 * 8);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,8,param_2,&LAB_005960d0,&LAB_00596610);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 8;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    iVar5 = 0;
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    do {
      *(int *)(*(int *)(iVar1 + 4) + 4 + iVar5 * 8) = param_1;
      iVar5 = iVar5 + 1;
    } while (iVar5 < (int)param_2);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4642 ; VA 0x005a6770 ; FUN_005a6770 */

uint * FUN_005a6770(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797ced;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x29,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0xc);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__GetAllJobsExResponse::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0xc;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[2] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0xc >> 0x20) != 0) | (uint)((ulonglong)param_2 * 0xc)
    ;
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0xc,param_2,&LAB_005960e0,FUN_00596620);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0xc;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 8 + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0xc;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4643 ; VA 0x005a68c0 ; FUN_005a68c0 */

uint * FUN_005a68c0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797d2d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x27,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x14);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__GetAllJobsResponse::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
      puVar2[4] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x14;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[4] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x14 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x14);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x14,param_2,FUN_00596100,FUN_00596630);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0x14;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 0x10 + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0x14;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4644 ; VA 0x005a6a20 ; FUN_005a6a20 */

uint * FUN_005a6a20(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797dad;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x24,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x20);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__GetExpiration::vftable;
      puVar2[5] = 0;
      puVar2[6] = 0xf;
      *(undefined *)(puVar2 + 1) = 0;
      puVar2[7] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x20;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[7] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x20 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x20);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x20,param_2,FUN_00596130,FUN_00596690);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 << 5;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 0x1c + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0x20;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4645 ; VA 0x005a6b80 ; FUN_005a6b80 */

uint * FUN_005a6b80(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797e2d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x25,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x18);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__GetExpirationResponse::vftable;
      *(undefined8 *)(puVar2 + 2) = 0;
      puVar2[4] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x18;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[4] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x18 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x18);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x18,param_2,&LAB_00596160,FUN_005966f0);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0x18;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 0x10 + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0x18;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4646 ; VA 0x005a6cd0 ; FUN_005a6cd0 */

uint * FUN_005a6cd0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797d6d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x12,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(8);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__GetStatus::vftable;
      puVar2[1] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 8;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[1] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 8 >> 0x20) != 0) | (uint)((ulonglong)param_2 * 8);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,8,param_2,&LAB_00596180,&LAB_00596700);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 8;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    iVar5 = 0;
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    do {
      *(int *)(*(int *)(iVar1 + 4) + 4 + iVar5 * 8) = param_1;
      iVar5 = iVar5 + 1;
    } while (iVar5 < (int)param_2);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4647 ; VA 0x005a6e20 ; FUN_005a6e20 */

uint * FUN_005a6e20(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797ced;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x13,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0xc);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__GetStatusResponse::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0xc;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[2] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0xc >> 0x20) != 0) | (uint)((ulonglong)param_2 * 0xc)
    ;
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0xc,param_2,&LAB_00596190,FUN_00596710);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0xc;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 8 + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0xc;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4648 ; VA 0x005a6f70 ; FUN_005a6f70 */

uint * FUN_005a6f70(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797d6d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x10,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(8);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__GetVersion::vftable;
      puVar2[1] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 8;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[1] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 8 >> 0x20) != 0) | (uint)((ulonglong)param_2 * 8);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,8,param_2,&LAB_005961b0,&LAB_00596720);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 8;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    iVar5 = 0;
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    do {
      *(int *)(*(int *)(iVar1 + 4) + 4 + iVar5 * 8) = param_1;
      iVar5 = iVar5 + 1;
    } while (iVar5 < (int)param_2);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4649 ; VA 0x005a70c0 ; FUN_005a70c0 */

uint * FUN_005a70c0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797dad;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x11,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x20);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__GetVersionResponse::vftable;
      puVar2[5] = 0;
      puVar2[6] = 0xf;
      *(undefined *)(puVar2 + 1) = 0;
      puVar2[7] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x20;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[7] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x20 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x20);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x20,param_2,FUN_005961c0,FUN_00596730);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 << 5;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 0x1c + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0x20;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4650 ; VA 0x005a7220 ; FUN_005a7220 */

uint * FUN_005a7220(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797d6d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0xe,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(8);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__HelloWorld::vftable;
      puVar2[1] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 8;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[1] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 8 >> 0x20) != 0) | (uint)((ulonglong)param_2 * 8);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,8,param_2,&LAB_005961f0,&LAB_00596790);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 8;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    iVar5 = 0;
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    do {
      *(int *)(*(int *)(iVar1 + 4) + 4 + iVar5 * 8) = param_1;
      iVar5 = iVar5 + 1;
    } while (iVar5 < (int)param_2);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4651 ; VA 0x005a7370 ; FUN_005a7370 */

uint * FUN_005a7370(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797ced;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0xf,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0xc);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__HelloWorldResponse::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0xc;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[2] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0xc >> 0x20) != 0) | (uint)((ulonglong)param_2 * 0xc)
    ;
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0xc,param_2,&LAB_00596200,FUN_005967a0);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0xc;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 8 + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0xc;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4652 ; VA 0x005a74c0 ; FUN_005a74c0 */

uint * FUN_005a74c0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797cad;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x14,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x10);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__OpenJob::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x10;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[3] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x10 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x10);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x10,param_2,&LAB_0056a4e0,FUN_0056e6a0);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 << 4;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      iVar5 = iVar5 + 0x10;
      *(int *)(*(int *)(iVar1 + 4) + -4 + iVar5) = param_1;
      param_2 = param_2 - 1;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4653 ; VA 0x005a7610 ; FUN_005a7610 */

uint * FUN_005a7610(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797cad;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x15,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x10);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__OpenJobEx::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x10;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[3] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x10 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x10);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x10,param_2,&LAB_00596220,&LAB_005967b0);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 << 4;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      iVar5 = iVar5 + 0x10;
      *(int *)(*(int *)(iVar1 + 4) + -4 + iVar5) = param_1;
      param_2 = param_2 - 1;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4654 ; VA 0x005a7760 ; FUN_005a7760 */

uint * FUN_005a7760(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797ced;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x17,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0xc);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__OpenJobExResponse::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0xc;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[2] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0xc >> 0x20) != 0) | (uint)((ulonglong)param_2 * 0xc)
    ;
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0xc,param_2,&LAB_00596240,FUN_005967c0);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0xc;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 8 + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0xc;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4655 ; VA 0x005a78b0 ; FUN_005a78b0 */

uint * FUN_005a78b0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797d2d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x16,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x14);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__OpenJobResponse::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
      puVar2[4] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x14;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[4] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x14 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x14);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x14,param_2,FUN_0056a500,FUN_0056e6b0);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0x14;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 0x10 + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0x14;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4656 ; VA 0x005a7a10 ; FUN_005a7a10 */

uint * FUN_005a7a10(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797e6d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x18,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x30);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__RenewLease::vftable;
      puVar2[6] = 0;
      puVar2[7] = 0xf;
      *(undefined *)(puVar2 + 2) = 0;
      *(undefined8 *)(puVar2 + 8) = 0;
      puVar2[10] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x30;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[10] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x30 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x30);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x30,param_2,FUN_00596260,FUN_005967d0);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0x30;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      iVar5 = iVar5 + 0x30;
      *(int *)(*(int *)(iVar1 + 4) + -8 + iVar5) = param_1;
      param_2 = param_2 - 1;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4657 ; VA 0x005a7b70 ; FUN_005a7b70 */

uint * FUN_005a7b70(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797e2d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0x19,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x18);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = _ns1__RenewLeaseResponse::vftable;
      *(undefined8 *)(puVar2 + 2) = 0;
      puVar2[4] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x18;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[4] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x18 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x18);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x18,param_2,&LAB_005962a0,FUN_00596830);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0x18;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 0x10 + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0x18;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4658 ; VA 0x005a7cc0 ; FUN_005a7cc0 */

uint * FUN_005a7cc0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797d2d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0xc,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x14);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = ns1__ArrayOfJob::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
      puVar2[4] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x14;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[4] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x14 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x14);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x14,param_2,FUN_005962c0,FUN_00596840);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0x14;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 0x10 + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0x14;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4659 ; VA 0x005a7e20 ; FUN_005a7e20 */

uint * FUN_005a7e20(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797d2d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0xb,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x14);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = ns1__ArrayOfLuaValue::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
      puVar2[4] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x14;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[4] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x14 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x14);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x14,param_2,FUN_005962f0,FUN_005968a0);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0x14;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 0x10 + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0x14;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4660 ; VA 0x005a7f80 ; FUN_005a7f80 */

uint * FUN_005a7f80(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797ead;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,9,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x40);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = ns1__Job::vftable;
      puVar2[6] = 0;
      puVar2[7] = 0xf;
      *(undefined *)(puVar2 + 2) = 0;
      *(undefined8 *)(puVar2 + 8) = 0;
      puVar2[10] = 0;
      *(undefined8 *)(puVar2 + 0xc) = 0;
      puVar2[0xe] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x40;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[0xe] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x40 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x40);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x40,param_2,FUN_0056afb0,FUN_0056e940);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 << 6;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      iVar5 = iVar5 + 0x40;
      *(int *)(*(int *)(iVar1 + 4) + -8 + iVar5) = param_1;
      param_2 = param_2 - 1;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4661 ; VA 0x005a80f0 ; FUN_005a80f0 */

uint * FUN_005a80f0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797d2d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,0xd,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x14);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = ns1__LuaValue::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
      puVar2[4] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x14;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[4] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x14 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x14);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x14,param_2,&LAB_00596320,&LAB_00596900);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0x14;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 0x10 + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0x14;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4662 ; VA 0x005a8250 ; FUN_005a8250 */

uint * FUN_005a8250(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797d2d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,10,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x14);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = ns1__ScriptExecution::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
      puVar2[4] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x14;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[4] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x14 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x14);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x14,param_2,&LAB_0056aff0,FUN_0056e9a0);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 * 0x14;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      *(int *)(iVar5 + 0x10 + *(int *)(iVar1 + 4)) = param_1;
      param_2 = param_2 - 1;
      iVar5 = iVar5 + 0x14;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4663 ; VA 0x005a83b0 ; FUN_005a83b0 */

uint * FUN_005a83b0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797cad;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_005b7ec0(param_1,0,8,param_2,FUN_00598780);
  if (iVar1 == 0) {
    ExceptionList = pvStack_10;
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0x10);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = ns1__Status::vftable;
      puVar2[1] = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x10;
      puVar2 = *(undefined4 **)(iVar1 + 4);
    }
    puVar2[3] = param_1;
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x10 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x10);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    uStack_8 = 0;
    if (puVar3 == (uint *)0x0) {
      puVar6 = (uint *)0x0;
    }
    else {
      puVar6 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar6,0x10,param_2,&LAB_00596350,&LAB_00596910);
    }
    *(uint **)(iVar1 + 4) = puVar6;
    if (puVar6 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      ExceptionList = pvStack_10;
      return (uint *)0x0;
    }
    if (param_5 != (int *)0x0) {
      *param_5 = param_2 << 4;
      puVar6 = *(uint **)(iVar1 + 4);
    }
    if ((int)param_2 < 1) {
      ExceptionList = pvStack_10;
      return puVar6;
    }
    iVar5 = 0;
    do {
      iVar5 = iVar5 + 0x10;
      *(int *)(*(int *)(iVar1 + 4) + -4 + iVar5) = param_1;
      param_2 = param_2 - 1;
    } while (param_2 != 0);
  }
  ExceptionList = pvStack_10;
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4664 ; VA 0x005a8500 ; FUN_005a8500 */

uint * FUN_005a8500(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined *puVar2;
  uint *puVar3;
  uint uVar4;
  uint *puVar5;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x33,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined *)FUN_01674e20(0x18);
    if (puVar2 == (undefined *)0x0) {
      puVar2 = (undefined *)0x0;
    }
    else {
      *(undefined4 *)(puVar2 + 0x10) = 0;
      *(undefined4 *)(puVar2 + 0x14) = 0xf;
      *puVar2 = 0;
    }
    *(undefined **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0x18;
      return *(uint **)(iVar1 + 4);
    }
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0x18 >> 0x20) != 0) |
            (uint)((ulonglong)param_2 * 0x18);
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    if (puVar3 == (uint *)0x0) {
      puVar5 = (uint *)0x0;
    }
    else {
      puVar5 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar5,0x18,param_2,FUN_0054f030,FUN_005507b0);
    }
    *(uint **)(iVar1 + 4) = puVar5;
    if (puVar5 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return (uint *)0x0;
    }
    if (param_5 == (int *)0x0) {
      return puVar5;
    }
    *param_5 = param_2 * 0x18;
  }
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4665 ; VA 0x005a85f0 ; FUN_005a85f0 */

uint * FUN_005a85f0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  uint *puVar5;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x3b,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0xc);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = 0;
      puVar2[1] = 0;
      puVar2[2] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0xc;
      return *(uint **)(iVar1 + 4);
    }
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0xc >> 0x20) != 0) | (uint)((ulonglong)param_2 * 0xc)
    ;
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    if (puVar3 == (uint *)0x0) {
      puVar5 = (uint *)0x0;
    }
    else {
      puVar5 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar5,0xc,param_2,FUN_00569440,FUN_0056d320);
    }
    *(uint **)(iVar1 + 4) = puVar5;
    if (puVar5 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return (uint *)0x0;
    }
    if (param_5 == (int *)0x0) {
      return puVar5;
    }
    *param_5 = param_2 * 0xc;
  }
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4666 ; VA 0x005a86e0 ; FUN_005a86e0 */

uint * FUN_005a86e0(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,int *param_5)

{
  int iVar1;
  undefined4 *puVar2;
  uint *puVar3;
  uint uVar4;
  uint *puVar5;
  
  iVar1 = FUN_005b7ec0(param_1,0,0x39,param_2,FUN_00598780);
  if (iVar1 == 0) {
    return (uint *)0x0;
  }
  if ((int)param_2 < 0) {
    puVar2 = (undefined4 *)FUN_01674e20(0xc);
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = 0;
      puVar2[1] = 0;
      puVar2[2] = 0;
    }
    *(undefined4 **)(iVar1 + 4) = puVar2;
    if (param_5 != (int *)0x0) {
      *param_5 = 0xc;
      return *(uint **)(iVar1 + 4);
    }
  }
  else {
    uVar4 = -(uint)((int)((ulonglong)param_2 * 0xc >> 0x20) != 0) | (uint)((ulonglong)param_2 * 0xc)
    ;
    puVar3 = (uint *)FUN_01674e20(-(uint)(0xfffffffb < uVar4) | uVar4 + 4);
    if (puVar3 == (uint *)0x0) {
      puVar5 = (uint *)0x0;
    }
    else {
      puVar5 = puVar3 + 1;
      *puVar3 = param_2;
      FUN_016f4053(puVar5,0xc,param_2,FUN_00569440,FUN_0056d320);
    }
    *(uint **)(iVar1 + 4) = puVar5;
    if (puVar5 == (uint *)0x0) {
      *(undefined4 *)(param_1 + 0x1615c) = 0x14;
      return (uint *)0x0;
    }
    if (param_5 == (int *)0x0) {
      return puVar5;
    }
    *param_5 = param_2 * 0xc;
  }
  return *(uint **)(iVar1 + 4);
}



/* FUNCTION 4667 ; VA 0x005a87d0 ; FUN_005a87d0 */

void FUN_005a87d0(undefined4 param_1,undefined4 param_2)

{
  FUN_005a7cc0(param_1,param_2,0,0,0);
  return;
}



/* FUNCTION 4668 ; VA 0x005a87f0 ; FUN_005a87f0 */

void FUN_005a87f0(undefined4 param_1,undefined4 param_2)

{
  FUN_005a7e20(param_1,param_2,0,0,0);
  return;
}



/* FUNCTION 4669 ; VA 0x005a8810 ; FUN_005a8810 */

void FUN_005a8810(undefined4 param_1,undefined4 param_2)

{
  FUN_005a7f80(param_1,param_2,0,0,0);
  return;
}



/* FUNCTION 4670 ; VA 0x005a8830 ; FUN_005a8830 */

void FUN_005a8830(undefined4 param_1,undefined4 param_2)

{
  FUN_005a80f0(param_1,param_2,0,0,0);
  return;
}



/* FUNCTION 4671 ; VA 0x005a8850 ; FUN_005a8850 */

void FUN_005a8850(undefined4 param_1,undefined4 param_2)

{
  FUN_005a83b0(param_1,param_2,0,0,0);
  return;
}



/* FUNCTION 4672 ; VA 0x005a8870 ; FUN_005a8870 */

void FUN_005a8870(undefined4 param_1,undefined4 param_2)

{
  FUN_005a8500(param_1,param_2,0,0,0);
  return;
}



/* FUNCTION 4673 ; VA 0x005a8890 ; FUN_005a8890 */

undefined4 __thiscall
FUN_005a8890(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x20,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    iVar2 = FUN_005b3f00(param_2,"ns1:job",0xffffffff,*(undefined4 *)(param_1 + 4),0,0,&DAT_018bc9b8
                         ,9);
    if (iVar2 < 0) {
      iVar2 = *(int *)(param_2 + 0x1615c);
    }
    else {
      iVar2 = (**(code **)(**(int **)(param_1 + 4) + 0x10))(param_2,"ns1:job",iVar2,&DAT_018bc9b8);
    }
    if (iVar2 == 0) {
      iVar2 = FUN_005b3f00(param_2,"ns1:script",0xffffffff,*(undefined4 *)(param_1 + 8),0,0,
                           &DAT_018bc9b8,10);
      if (iVar2 < 0) {
        iVar2 = *(int *)(param_2 + 0x1615c);
      }
      else {
        iVar2 = (**(code **)(**(int **)(param_1 + 8) + 0x10))
                          (param_2,"ns1:script",iVar2,&DAT_018bc9b8);
      }
      if (iVar2 == 0) {
        uVar1 = FUN_005b3e10(param_2,param_3);
        return uVar1;
      }
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4674 ; VA 0x005a8970 ; FUN_005a8970 */

undefined4 __thiscall
FUN_005a8970(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x22,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    iVar2 = FUN_005b3f00(param_2,"ns1:job",0xffffffff,*(undefined4 *)(param_1 + 4),0,0,&DAT_018bc9b8
                         ,9);
    if (iVar2 < 0) {
      iVar2 = *(int *)(param_2 + 0x1615c);
    }
    else {
      iVar2 = (**(code **)(**(int **)(param_1 + 4) + 0x10))(param_2,"ns1:job",iVar2,&DAT_018bc9b8);
    }
    if (iVar2 == 0) {
      iVar2 = FUN_005b3f00(param_2,"ns1:script",0xffffffff,*(undefined4 *)(param_1 + 8),0,0,
                           &DAT_018bc9b8,10);
      if (iVar2 < 0) {
        iVar2 = *(int *)(param_2 + 0x1615c);
      }
      else {
        iVar2 = (**(code **)(**(int **)(param_1 + 8) + 0x10))
                          (param_2,"ns1:script",iVar2,&DAT_018bc9b8);
      }
      if (iVar2 == 0) {
        uVar1 = FUN_005b3e10(param_2,param_3);
        return uVar1;
      }
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4675 ; VA 0x005a8a50 ; FUN_005a8a50 */

undefined4 __thiscall
FUN_005a8a50(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x23,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    if (*(int *)(param_1 + 4) != 0) {
      FUN_005b4190(param_2,"ns1:BatchJobExResult");
    }
    iVar2 = FUN_005b3f00(param_2,"ns1:BatchJobExResult",0xffffffff,*(undefined4 *)(param_1 + 4),0,0,
                         &DAT_018bc9b8,0xb);
    if (iVar2 < 0) {
      iVar2 = *(int *)(param_2 + 0x1615c);
    }
    else {
      iVar2 = (**(code **)(**(int **)(param_1 + 4) + 0x10))
                        (param_2,"ns1:BatchJobExResult",iVar2,&DAT_018bc9b8);
    }
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4676 ; VA 0x005a8b00 ; FUN_005a8b00 */

undefined4 __thiscall
FUN_005a8b00(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x21,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    FUN_005b4190(param_2,"ns1:BatchJobResult");
    iVar2 = FUN_005ab3d0(param_2,"ns1:BatchJobResult",0xffffffff,param_1 + 4,&DAT_018bc9b8);
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4677 ; VA 0x005a8b80 ; FUN_005a8b80 */

undefined4 __thiscall
FUN_005a8b80(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x2c,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005b3e10(param_2,param_3);
  return uVar1;
}



/* FUNCTION 4678 ; VA 0x005a8bd0 ; FUN_005a8bd0 */

undefined4 __thiscall
FUN_005a8bd0(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x2d,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    FUN_005b4190(param_2,"ns1:CloseAllJobsResult");
    iVar2 = FUN_005b8630(param_2,"ns1:CloseAllJobsResult",0xffffffff,param_1 + 4,&DAT_018bc9b8,1);
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4679 ; VA 0x005a8c50 ; FUN_005a8c50 */

undefined4 __thiscall
FUN_005a8c50(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x2a,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005b3e10(param_2,param_3);
  return uVar1;
}



/* FUNCTION 4680 ; VA 0x005a8ca0 ; FUN_005a8ca0 */

undefined4 __thiscall
FUN_005a8ca0(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x2b,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    FUN_005b4190(param_2,"ns1:CloseExpiredJobsResult");
    iVar2 = FUN_005b8630(param_2,"ns1:CloseExpiredJobsResult",0xffffffff,param_1 + 4,&DAT_018bc9b8,1
                        );
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4681 ; VA 0x005a8d20 ; FUN_005a8d20 */

undefined4 __thiscall
FUN_005a8d20(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x1e,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    iVar2 = FUN_005ab2d0(param_2,"ns1:jobID",0xffffffff,param_1 + 4,&DAT_018bc9b8);
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4682 ; VA 0x005a8d90 ; FUN_005a8d90 */

undefined4 __thiscall
FUN_005a8d90(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x1f,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005b3e10(param_2,param_3);
  return uVar1;
}



/* FUNCTION 4683 ; VA 0x005a8de0 ; FUN_005a8de0 */

undefined4 __thiscall
FUN_005a8de0(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x2e,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    iVar2 = FUN_005b8630(param_2,"ns1:type",0xffffffff,param_1 + 4,&DAT_018bc9b8,1);
    if (iVar2 == 0) {
      iVar2 = FUN_005b3f00(param_2,"ns1:jobID",0xffffffff,*(undefined4 *)(param_1 + 8),0,0,
                           &DAT_018bc9b8,0x33);
      if (iVar2 < 0) {
        iVar2 = *(int *)(param_2 + 0x1615c);
      }
      else {
        iVar2 = FUN_005ab2d0(param_2,"ns1:jobID",iVar2,*(undefined4 *)(param_1 + 8),&DAT_018bc9b8);
      }
      if (iVar2 == 0) {
        uVar1 = FUN_005b3e10(param_2,param_3);
        return uVar1;
      }
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4684 ; VA 0x005a8e90 ; FUN_005a8e90 */

undefined4 __thiscall
FUN_005a8e90(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x30,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    iVar2 = FUN_005b8630(param_2,"ns1:type",0xffffffff,param_1 + 4,&DAT_018bc9b8,1);
    if (iVar2 == 0) {
      iVar2 = FUN_005b3f00(param_2,"ns1:jobID",0xffffffff,*(undefined4 *)(param_1 + 8),0,0,
                           &DAT_018bc9b8,0x33);
      if (iVar2 < 0) {
        iVar2 = *(int *)(param_2 + 0x1615c);
      }
      else {
        iVar2 = FUN_005ab2d0(param_2,"ns1:jobID",iVar2,*(undefined4 *)(param_1 + 8),&DAT_018bc9b8);
      }
      if (iVar2 == 0) {
        uVar1 = FUN_005b3e10(param_2,param_3);
        return uVar1;
      }
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4685 ; VA 0x005a8f40 ; FUN_005a8f40 */

undefined4 __thiscall
FUN_005a8f40(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x31,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    if (*(int *)(param_1 + 4) != 0) {
      FUN_005b4190(param_2,"ns1:DiagExResult");
    }
    iVar2 = FUN_005b3f00(param_2,"ns1:DiagExResult",0xffffffff,*(undefined4 *)(param_1 + 4),0,0,
                         &DAT_018bc9b8,0xb);
    if (iVar2 < 0) {
      iVar2 = *(int *)(param_2 + 0x1615c);
    }
    else {
      iVar2 = (**(code **)(**(int **)(param_1 + 4) + 0x10))
                        (param_2,"ns1:DiagExResult",iVar2,&DAT_018bc9b8);
    }
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4686 ; VA 0x005a8ff0 ; FUN_005a8ff0 */

undefined4 __thiscall
FUN_005a8ff0(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x2f,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    FUN_005b4190(param_2,"ns1:DiagResult");
    iVar2 = FUN_005ab3d0(param_2,"ns1:DiagResult",0xffffffff,param_1 + 4,&DAT_018bc9b8);
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4687 ; VA 0x005a9070 ; FUN_005a9070 */

undefined4 __thiscall
FUN_005a9070(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x1a,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    iVar2 = FUN_005ab2d0(param_2,"ns1:jobID",0xffffffff,param_1 + 4,&DAT_018bc9b8);
    if (iVar2 == 0) {
      iVar2 = FUN_005b3f00(param_2,"ns1:script",0xffffffff,*(undefined4 *)(param_1 + 0x1c),0,0,
                           &DAT_018bc9b8,10);
      if (iVar2 < 0) {
        iVar2 = *(int *)(param_2 + 0x1615c);
      }
      else {
        iVar2 = (**(code **)(**(int **)(param_1 + 0x1c) + 0x10))
                          (param_2,"ns1:script",iVar2,&DAT_018bc9b8);
      }
      if (iVar2 == 0) {
        uVar1 = FUN_005b3e10(param_2,param_3);
        return uVar1;
      }
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4688 ; VA 0x005a9120 ; FUN_005a9120 */

undefined4 __thiscall
FUN_005a9120(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x1c,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    iVar2 = FUN_005ab2d0(param_2,"ns1:jobID",0xffffffff,param_1 + 4,&DAT_018bc9b8);
    if (iVar2 == 0) {
      iVar2 = FUN_005b3f00(param_2,"ns1:script",0xffffffff,*(undefined4 *)(param_1 + 0x1c),0,0,
                           &DAT_018bc9b8,10);
      if (iVar2 < 0) {
        iVar2 = *(int *)(param_2 + 0x1615c);
      }
      else {
        iVar2 = (**(code **)(**(int **)(param_1 + 0x1c) + 0x10))
                          (param_2,"ns1:script",iVar2,&DAT_018bc9b8);
      }
      if (iVar2 == 0) {
        uVar1 = FUN_005b3e10(param_2,param_3);
        return uVar1;
      }
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4689 ; VA 0x005a91d0 ; FUN_005a91d0 */

undefined4 __thiscall
FUN_005a91d0(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x1d,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    if (*(int *)(param_1 + 4) != 0) {
      FUN_005b4190(param_2,"ns1:ExecuteExResult");
    }
    iVar2 = FUN_005b3f00(param_2,"ns1:ExecuteExResult",0xffffffff,*(undefined4 *)(param_1 + 4),0,0,
                         &DAT_018bc9b8,0xb);
    if (iVar2 < 0) {
      iVar2 = *(int *)(param_2 + 0x1615c);
    }
    else {
      iVar2 = (**(code **)(**(int **)(param_1 + 4) + 0x10))
                        (param_2,"ns1:ExecuteExResult",iVar2,&DAT_018bc9b8);
    }
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4690 ; VA 0x005a9280 ; FUN_005a9280 */

undefined4 __thiscall
FUN_005a9280(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x1b,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    FUN_005b4190(param_2,"ns1:ExecuteResult");
    iVar2 = FUN_005ab3d0(param_2,"ns1:ExecuteResult",0xffffffff,param_1 + 4,&DAT_018bc9b8);
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4691 ; VA 0x005a9300 ; FUN_005a9300 */

undefined4 __thiscall
FUN_005a9300(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x26,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005b3e10(param_2,param_3);
  return uVar1;
}



/* FUNCTION 4692 ; VA 0x005a9350 ; FUN_005a9350 */

undefined4 __thiscall
FUN_005a9350(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x28,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005b3e10(param_2,param_3);
  return uVar1;
}



/* FUNCTION 4693 ; VA 0x005a93a0 ; FUN_005a93a0 */

undefined4 __thiscall
FUN_005a93a0(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x29,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    if (*(int *)(param_1 + 4) != 0) {
      FUN_005b4190(param_2,"ns1:GetAllJobsExResult");
    }
    iVar2 = FUN_005b3f00(param_2,"ns1:GetAllJobsExResult",0xffffffff,*(undefined4 *)(param_1 + 4),0,
                         0,&DAT_018bc9b8,0xc);
    if (iVar2 < 0) {
      iVar2 = *(int *)(param_2 + 0x1615c);
    }
    else {
      iVar2 = (**(code **)(**(int **)(param_1 + 4) + 0x10))
                        (param_2,"ns1:GetAllJobsExResult",iVar2,&DAT_018bc9b8);
    }
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4694 ; VA 0x005a9450 ; FUN_005a9450 */

undefined4 __thiscall
FUN_005a9450(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x27,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    FUN_005b4190(param_2,"ns1:GetAllJobsResult");
    iVar2 = FUN_005ab360(param_2,"ns1:GetAllJobsResult",0xffffffff,param_1 + 4,&DAT_018bc9b8);
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4695 ; VA 0x005a94d0 ; FUN_005a94d0 */

undefined4 __thiscall
FUN_005a94d0(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x24,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    iVar2 = FUN_005ab2d0(param_2,"ns1:jobID",0xffffffff,param_1 + 4,&DAT_018bc9b8);
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4696 ; VA 0x005a9540 ; FUN_005a9540 */

undefined4 __thiscall
FUN_005a9540(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x25,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    FUN_005b4190(param_2,"ns1:GetExpirationResult");
    iVar2 = FUN_005b8530(param_2,"ns1:GetExpirationResult",0xffffffff,param_1 + 8,&DAT_018bc9b8,0x36
                        );
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4697 ; VA 0x005a95c0 ; FUN_005a95c0 */

undefined4 __thiscall
FUN_005a95c0(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x12,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005b3e10(param_2,param_3);
  return uVar1;
}



/* FUNCTION 4698 ; VA 0x005a9610 ; FUN_005a9610 */

undefined4 __thiscall
FUN_005a9610(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x13,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    if (*(int *)(param_1 + 4) != 0) {
      FUN_005b4190(param_2,"ns1:GetStatusResult");
    }
    iVar2 = FUN_005b3f00(param_2,"ns1:GetStatusResult",0xffffffff,*(undefined4 *)(param_1 + 4),0,0,
                         &DAT_018bc9b8,8);
    if (iVar2 < 0) {
      iVar2 = *(int *)(param_2 + 0x1615c);
    }
    else {
      iVar2 = (**(code **)(**(int **)(param_1 + 4) + 0x10))
                        (param_2,"ns1:GetStatusResult",iVar2,&DAT_018bc9b8);
    }
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4699 ; VA 0x005a96c0 ; FUN_005a96c0 */

undefined4 __thiscall
FUN_005a96c0(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x10,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005b3e10(param_2,param_3);
  return uVar1;
}



/* FUNCTION 4700 ; VA 0x005a9710 ; FUN_005a9710 */

undefined4 __thiscall
FUN_005a9710(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x11,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    FUN_005b4190(param_2,"ns1:GetVersionResult");
    iVar2 = FUN_005ab2d0(param_2,"ns1:GetVersionResult",0xffffffff,param_1 + 4,&DAT_018bc9b8);
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4701 ; VA 0x005a9790 ; FUN_005a9790 */

undefined4 __thiscall
FUN_005a9790(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0xe,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 != 0) {
    return *(undefined4 *)(param_2 + 0x1615c);
  }
  uVar1 = FUN_005b3e10(param_2,param_3);
  return uVar1;
}



/* FUNCTION 4702 ; VA 0x005a97e0 ; FUN_005a97e0 */

undefined4 __thiscall
FUN_005a97e0(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0xf,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    if (*(int *)(param_1 + 4) != 0) {
      FUN_005b4190(param_2,"ns1:HelloWorldResult");
    }
    iVar2 = FUN_005b3f00(param_2,"ns1:HelloWorldResult",0xffffffff,*(undefined4 *)(param_1 + 4),0,0,
                         &DAT_018bc9b8,0x33);
    if (iVar2 < 0) {
      iVar2 = *(int *)(param_2 + 0x1615c);
    }
    else {
      iVar2 = FUN_005ab2d0(param_2,"ns1:HelloWorldResult",iVar2,*(undefined4 *)(param_1 + 4),
                           &DAT_018bc9b8);
    }
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4703 ; VA 0x005a9890 ; FUN_005a9890 */

undefined4 __thiscall
FUN_005a9890(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x14,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    iVar2 = FUN_005b3f00(param_2,"ns1:job",0xffffffff,*(undefined4 *)(param_1 + 4),0,0,&DAT_018bc9b8
                         ,9);
    if (iVar2 < 0) {
      iVar2 = *(int *)(param_2 + 0x1615c);
    }
    else {
      iVar2 = (**(code **)(**(int **)(param_1 + 4) + 0x10))(param_2,"ns1:job",iVar2,&DAT_018bc9b8);
    }
    if (iVar2 == 0) {
      iVar2 = FUN_005b3f00(param_2,"ns1:script",0xffffffff,*(undefined4 *)(param_1 + 8),0,0,
                           &DAT_018bc9b8,10);
      if (iVar2 < 0) {
        iVar2 = *(int *)(param_2 + 0x1615c);
      }
      else {
        iVar2 = (**(code **)(**(int **)(param_1 + 8) + 0x10))
                          (param_2,"ns1:script",iVar2,&DAT_018bc9b8);
      }
      if (iVar2 == 0) {
        uVar1 = FUN_005b3e10(param_2,param_3);
        return uVar1;
      }
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4704 ; VA 0x005a9970 ; FUN_005a9970 */

undefined4 __thiscall
FUN_005a9970(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x15,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    iVar2 = FUN_005b3f00(param_2,"ns1:job",0xffffffff,*(undefined4 *)(param_1 + 4),0,0,&DAT_018bc9b8
                         ,9);
    if (iVar2 < 0) {
      iVar2 = *(int *)(param_2 + 0x1615c);
    }
    else {
      iVar2 = (**(code **)(**(int **)(param_1 + 4) + 0x10))(param_2,"ns1:job",iVar2,&DAT_018bc9b8);
    }
    if (iVar2 == 0) {
      iVar2 = FUN_005b3f00(param_2,"ns1:script",0xffffffff,*(undefined4 *)(param_1 + 8),0,0,
                           &DAT_018bc9b8,10);
      if (iVar2 < 0) {
        iVar2 = *(int *)(param_2 + 0x1615c);
      }
      else {
        iVar2 = (**(code **)(**(int **)(param_1 + 8) + 0x10))
                          (param_2,"ns1:script",iVar2,&DAT_018bc9b8);
      }
      if (iVar2 == 0) {
        uVar1 = FUN_005b3e10(param_2,param_3);
        return uVar1;
      }
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4705 ; VA 0x005a9a50 ; FUN_005a9a50 */

undefined4 __thiscall
FUN_005a9a50(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x17,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    if (*(int *)(param_1 + 4) != 0) {
      FUN_005b4190(param_2,"ns1:OpenJobExResult");
    }
    iVar2 = FUN_005b3f00(param_2,"ns1:OpenJobExResult",0xffffffff,*(undefined4 *)(param_1 + 4),0,0,
                         &DAT_018bc9b8,0xb);
    if (iVar2 < 0) {
      iVar2 = *(int *)(param_2 + 0x1615c);
    }
    else {
      iVar2 = (**(code **)(**(int **)(param_1 + 4) + 0x10))
                        (param_2,"ns1:OpenJobExResult",iVar2,&DAT_018bc9b8);
    }
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4706 ; VA 0x005a9b00 ; FUN_005a9b00 */

undefined4 __thiscall
FUN_005a9b00(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x16,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    FUN_005b4190(param_2,"ns1:OpenJobResult");
    iVar2 = FUN_005ab3d0(param_2,"ns1:OpenJobResult",0xffffffff,param_1 + 4,&DAT_018bc9b8);
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4707 ; VA 0x005a9b80 ; FUN_005a9b80 */

undefined4 __thiscall
FUN_005a9b80(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x18,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    iVar2 = FUN_005ab2d0(param_2,"ns1:jobID",0xffffffff,param_1 + 8,&DAT_018bc9b8);
    if (iVar2 == 0) {
      iVar2 = FUN_005b8530(param_2,"ns1:expirationInSeconds",0xffffffff,param_1 + 0x20,&DAT_018bc9b8
                           ,0x36);
      if (iVar2 == 0) {
        uVar1 = FUN_005b3e10(param_2,param_3);
        return uVar1;
      }
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4708 ; VA 0x005a9c10 ; FUN_005a9c10 */

undefined4 __thiscall
FUN_005a9c10(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0x19,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    FUN_005b4190(param_2,"ns1:RenewLeaseResult");
    iVar2 = FUN_005b8530(param_2,"ns1:RenewLeaseResult",0xffffffff,param_1 + 8,&DAT_018bc9b8,0x36);
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4709 ; VA 0x005a9c90 ; FUN_005a9c90 */

undefined4 __thiscall
FUN_005a9c90(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0xc,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    iVar2 = FUN_005ab360(param_2,"ns1:Job",0xffffffff,param_1 + 4,&DAT_018bc9b8);
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4710 ; VA 0x005a9d00 ; FUN_005a9d00 */

undefined4 __thiscall
FUN_005a9d00(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0xb,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    iVar2 = FUN_005ab3d0(param_2,"ns1:LuaValue",0xffffffff,param_1 + 4,&DAT_018bc9b8);
    if (iVar2 == 0) {
      uVar1 = FUN_005b3e10(param_2,param_3);
      return uVar1;
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4711 ; VA 0x005a9d70 ; FUN_005a9d70 */

undefined4 __thiscall
FUN_005a9d70(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,9,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    iVar2 = FUN_005ab2d0(param_2,"ns1:id",0xffffffff,param_1 + 8,&DAT_018bc9b8);
    if (iVar2 == 0) {
      iVar2 = FUN_005b8530(param_2,"ns1:expirationInSeconds",0xffffffff,param_1 + 0x20,&DAT_018bc9b8
                           ,0x36);
      if (iVar2 == 0) {
        iVar2 = FUN_005b8630(param_2,"ns1:category",0xffffffff,param_1 + 0x28,&DAT_018bc9b8,1);
        if (iVar2 == 0) {
          iVar2 = FUN_005b8530(param_2,"ns1:cores",0xffffffff,param_1 + 0x30,&DAT_018bc9b8,0x36);
          if (iVar2 == 0) {
            uVar1 = FUN_005b3e10(param_2,param_3);
            return uVar1;
          }
        }
      }
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4712 ; VA 0x005a9e40 ; FUN_005a9e40 */

undefined4 __thiscall
FUN_005a9e40(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,0xd,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    iVar2 = FUN_005ab250(param_2,"ns1:type",0xffffffff,param_1 + 4,&DAT_018bc9b8);
    if (iVar2 == 0) {
      iVar2 = FUN_005b3f00(param_2,"ns1:value",0xffffffff,*(undefined4 *)(param_1 + 8),0,0,
                           &DAT_018bc9b8,0x33);
      if (iVar2 < 0) {
        iVar2 = *(int *)(param_2 + 0x1615c);
      }
      else {
        iVar2 = FUN_005ab2d0(param_2,"ns1:value",iVar2,*(undefined4 *)(param_1 + 8),&DAT_018bc9b8);
      }
      if (iVar2 == 0) {
        iVar2 = FUN_005aad40(param_2,"ns1:table",0xffffffff,param_1 + 0xc,&DAT_018bc9b8);
        if (iVar2 == 0) {
          uVar1 = FUN_005b3e10(param_2,param_3);
          return uVar1;
        }
      }
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4713 ; VA 0x005a9f10 ; FUN_005a9f10 */

undefined4 __thiscall
FUN_005a9f10(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,10,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    iVar2 = FUN_005b3f00(param_2,"ns1:name",0xffffffff,*(undefined4 *)(param_1 + 4),0,0,
                         &DAT_018bc9b8,0x33);
    if (iVar2 < 0) {
      iVar2 = *(int *)(param_2 + 0x1615c);
    }
    else {
      iVar2 = FUN_005ab2d0(param_2,"ns1:name",iVar2,*(undefined4 *)(param_1 + 4),&DAT_018bc9b8);
    }
    if (iVar2 == 0) {
      iVar2 = FUN_005b3f00(param_2,"ns1:script",0xffffffff,*(undefined4 *)(param_1 + 8),0,0,
                           &DAT_018bc9b8,0x33);
      if (iVar2 < 0) {
        iVar2 = *(int *)(param_2 + 0x1615c);
      }
      else {
        iVar2 = FUN_005ab2d0(param_2,"ns1:script",iVar2,*(undefined4 *)(param_1 + 8),&DAT_018bc9b8);
      }
      if (iVar2 == 0) {
        iVar2 = FUN_005aad40(param_2,"ns1:arguments",0xffffffff,param_1 + 0xc,&DAT_018bc9b8);
        if (iVar2 == 0) {
          uVar1 = FUN_005b3e10(param_2,param_3);
          return uVar1;
        }
      }
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4714 ; VA 0x005aa010 ; FUN_005aa010 */

undefined4 __thiscall
FUN_005aa010(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_005b44d0(param_2,param_4,param_1,8,param_5);
  iVar2 = FUN_005b3c80(param_2,param_3,uVar1);
  if (iVar2 == 0) {
    iVar2 = FUN_005b3f00(param_2,"ns1:version",0xffffffff,*(undefined4 *)(param_1 + 4),0,0,
                         &DAT_018bc9b8,0x33);
    if (iVar2 < 0) {
      iVar2 = *(int *)(param_2 + 0x1615c);
    }
    else {
      iVar2 = FUN_005ab2d0(param_2,"ns1:version",iVar2,*(undefined4 *)(param_1 + 4),&DAT_018bc9b8);
    }
    if (iVar2 == 0) {
      iVar2 = FUN_005b8630(param_2,"ns1:environmentCount",0xffffffff,param_1 + 8,&DAT_018bc9b8,1);
      if (iVar2 == 0) {
        uVar1 = FUN_005b3e10(param_2,param_3);
        return uVar1;
      }
    }
  }
  return *(undefined4 *)(param_2 + 0x1615c);
}



/* FUNCTION 4715 ; VA 0x005aa0c0 ; FUN_005aa0c0 */

undefined4
FUN_005aa0c0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0xac);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = FUN_005aaf20(param_1,param_2,iVar1,*param_4,param_5);
  return uVar2;
}



/* FUNCTION 4716 ; VA 0x005aa110 ; FUN_005aa110 */

undefined4
FUN_005aa110(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0xae);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = FUN_005aafe0(param_1,param_2,iVar1,*param_4,param_5);
  return uVar2;
}



/* FUNCTION 4717 ; VA 0x005aa160 ; FUN_005aa160 */

undefined4
FUN_005aa160(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0xb1);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = FUN_005ab1e0(param_1,param_2,iVar1,*param_4,param_5);
  return uVar2;
}



/* FUNCTION 4718 ; VA 0x005aa1b0 ; FUN_005aa1b0 */

undefined4
FUN_005aa1b0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x20);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4719 ; VA 0x005aa200 ; FUN_005aa200 */

undefined4
FUN_005aa200(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x22);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4720 ; VA 0x005aa250 ; FUN_005aa250 */

undefined4
FUN_005aa250(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x23);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4721 ; VA 0x005aa2a0 ; FUN_005aa2a0 */

undefined4
FUN_005aa2a0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x21);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4722 ; VA 0x005aa2f0 ; FUN_005aa2f0 */

undefined4
FUN_005aa2f0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x2c);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4723 ; VA 0x005aa340 ; FUN_005aa340 */

undefined4
FUN_005aa340(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x2d);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4724 ; VA 0x005aa390 ; FUN_005aa390 */

undefined4
FUN_005aa390(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x2a);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4725 ; VA 0x005aa3e0 ; FUN_005aa3e0 */

undefined4
FUN_005aa3e0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x2b);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4726 ; VA 0x005aa430 ; FUN_005aa430 */

undefined4
FUN_005aa430(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x1e);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4727 ; VA 0x005aa480 ; FUN_005aa480 */

undefined4
FUN_005aa480(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x1f);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4728 ; VA 0x005aa4d0 ; FUN_005aa4d0 */

undefined4
FUN_005aa4d0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x2e);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4729 ; VA 0x005aa520 ; FUN_005aa520 */

undefined4
FUN_005aa520(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x30);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4730 ; VA 0x005aa570 ; FUN_005aa570 */

undefined4
FUN_005aa570(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x31);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4731 ; VA 0x005aa5c0 ; FUN_005aa5c0 */

undefined4
FUN_005aa5c0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x2f);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4732 ; VA 0x005aa610 ; FUN_005aa610 */

undefined4
FUN_005aa610(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x1a);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4733 ; VA 0x005aa660 ; FUN_005aa660 */

undefined4
FUN_005aa660(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x1c);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4734 ; VA 0x005aa6b0 ; FUN_005aa6b0 */

undefined4
FUN_005aa6b0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x1d);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4735 ; VA 0x005aa700 ; FUN_005aa700 */

undefined4
FUN_005aa700(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x1b);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4736 ; VA 0x005aa750 ; FUN_005aa750 */

undefined4
FUN_005aa750(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x26);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4737 ; VA 0x005aa7a0 ; FUN_005aa7a0 */

undefined4
FUN_005aa7a0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x28);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4738 ; VA 0x005aa7f0 ; FUN_005aa7f0 */

undefined4
FUN_005aa7f0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x29);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4739 ; VA 0x005aa840 ; FUN_005aa840 */

undefined4
FUN_005aa840(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x27);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4740 ; VA 0x005aa890 ; FUN_005aa890 */

undefined4
FUN_005aa890(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x24);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4741 ; VA 0x005aa8e0 ; FUN_005aa8e0 */

undefined4
FUN_005aa8e0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x25);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4742 ; VA 0x005aa930 ; FUN_005aa930 */

undefined4
FUN_005aa930(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x12);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4743 ; VA 0x005aa980 ; FUN_005aa980 */

undefined4
FUN_005aa980(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x13);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4744 ; VA 0x005aa9d0 ; FUN_005aa9d0 */

undefined4
FUN_005aa9d0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x10);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4745 ; VA 0x005aaa20 ; FUN_005aaa20 */

undefined4
FUN_005aaa20(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x11);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4746 ; VA 0x005aaa70 ; FUN_005aaa70 */

undefined4
FUN_005aaa70(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0xe);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4747 ; VA 0x005aaac0 ; FUN_005aaac0 */

undefined4
FUN_005aaac0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0xf);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4748 ; VA 0x005aab10 ; FUN_005aab10 */

undefined4
FUN_005aab10(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x14);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}



/* FUNCTION 4749 ; VA 0x005aab60 ; FUN_005aab60 */

undefined4
FUN_005aab60(int param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_005b3f00(param_1,param_2,param_3,*param_4,0,0,param_5,0x15);
  if (iVar1 < 0) {
    return *(undefined4 *)(param_1 + 0x1615c);
  }
  uVar2 = (**(code **)(*(int *)*param_4 + 0x10))(param_1,param_2,iVar1,param_5);
  return uVar2;
}


