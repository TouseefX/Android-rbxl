/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 4000 ; VA 0x005882d0 ; FUN_005882d0 */

undefined * __thiscall FUN_005882d0(int param_1,undefined *param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  
  pcVar2 = (char *)FUN_0170d919(*(int *)(param_1 + 4) + 4,&DAT_021137d8);
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0xf;
  *param_2 = 0;
  pcVar3 = pcVar2;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar2,(int)pcVar3 - (int)(pcVar2 + 1));
  return param_2;
}



/* FUNCTION 4001 ; VA 0x00588320 ; FUN_00588320 */

undefined * FUN_00588320(undefined4 param_1)

{
  undefined **ppuVar1;
  undefined **ppuVar2;
  
  ppuVar1 = (undefined **)FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_1);
  ppuVar2 = ppuVar1 + -1;
  if (ppuVar1 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar2 = ppuVar1;
  }
  return *ppuVar2;
}



/* FUNCTION 4002 ; VA 0x00588350 ; FUN_00588350 */

void __fastcall FUN_00588350(uint *param_1)

{
  uint uVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  if (param_1[2] != 0) {
    ExceptionList = &pvStack_10;
    FUN_005874f0();
    uVar1 = param_1[2];
    if (uVar1 == 0) {
      uStack_8 = 0;
    }
    else {
      param_1[2] = 0;
      ReleaseSemaphore(param_1[7],uVar1,0);
      piVar2 = (int *)param_1[5];
      for (piVar5 = (int *)param_1[4]; piVar5 != piVar2; piVar5 = piVar5 + 1) {
        puVar3 = (undefined4 *)*piVar5;
        *(undefined *)(puVar3 + 3) = 1;
        ReleaseSemaphore(*puVar3,puVar3[2],0);
      }
      FUN_005595e0(param_1[4],param_1[5],param_1 + 4);
      param_1[5] = param_1[4];
      uVar1 = param_1[7];
      if ((uVar1 != 0) && (uVar1 != 0xffffffff)) {
        CloseHandle(uVar1);
      }
      param_1[7] = 0;
      uStack_8 = 1;
    }
    LOCK();
    uVar1 = *param_1;
    *param_1 = *param_1 + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *param_1;
      *param_1 = *param_1 | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar4 = FUN_00554e40();
        SetEvent(uVar4);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4003 ; VA 0x00588440 ; FUN_00588440 */

void __thiscall FUN_00588440(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  puVar1 = *(undefined4 **)(param_1 + 0x20);
  uStack_c = param_2;
  uStack_8 = param_3;
  if (*(undefined4 **)(param_1 + 0x24) != puVar1) {
    puVar1[1] = param_3;
    *puVar1 = param_2;
    *(int *)(param_1 + 0x20) = *(int *)(param_1 + 0x20) + 8;
    return;
  }
  FUN_00559ce0(puVar1,&uStack_c);
  return;
}



/* FUNCTION 4004 ; VA 0x00588480 ; FUN_00588480 */

/* WARNING: Removing unreachable block (ram,0x005885c0) */
/* WARNING: Removing unreachable block (ram,0x005885d3) */
/* WARNING: Removing unreachable block (ram,0x005885da) */
/* WARNING: Removing unreachable block (ram,0x005885e1) */

void FUN_00588480(void)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  char cVar5;
  int iVar6;
  undefined *puVar7;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_01796c30;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0151dd70(DAT_018c0d60 / (double)DAT_01d590f8);
  iVar4 = DAT_01d590d4;
  if ((DAT_01d59338 != '\0') && (iVar6 = FUN_0151da90(), iVar6 != iVar4)) {
    FUN_0151ddb0(iVar4);
  }
  if ((DAT_01d5aa00 != '\0') && (DAT_01ea84c0 != 0)) {
    FUN_00587410();
    iStack_8 = 0;
    piVar2 = *(int **)(DAT_01ea84c0 + 0xb4);
    piVar3 = (int *)*piVar2;
    while (piVar3 != piVar2) {
      FUN_0054ef60(piVar3 + 4);
      if (piVar3[0xb] != 0) {
        LOCK();
        piVar1 = (int *)(piVar3[0xb] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      iStack_8._0_1_ = 1;
      if (*(int *)(piVar3[10] + 0x18) != 0) {
        auStack_14[0] = 0;
        cVar5 = FUN_00585a40(auStack_14);
        if (cVar5 == '\0') {
          puVar7 = &DAT_018c0c49;
        }
        else {
          puVar7 = (undefined *)0x0;
        }
        FUN_0090ca30(puVar7);
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_0056cac0();
      FUN_00551320();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4005 ; VA 0x00588600 ; FUN_00588600 */

void FUN_00588600(void)

{
  code *pcVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796c48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0056a600();
  uStack_8 = 0;
  FUN_005647b0(uVar2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 4006 ; VA 0x00588640 ; FUN_00588640 */

void FUN_00588640(void)

{
  code *pcVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796c68;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0056a6f0();
  uStack_8 = 0;
  FUN_00564800(uVar2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 4007 ; VA 0x00588680 ; FUN_00588680 */

void FUN_00588680(void)

{
  code *pcVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796c88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0056a820();
  uStack_8 = 0;
  FUN_00564850(uVar2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 4008 ; VA 0x005886c0 ; FUN_005886c0 */

int __thiscall FUN_005886c0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017922c8;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x4c) == 0) {
    ExceptionList = &pvStack_10;
    iVar3 = FUN_016de719(param_2,param_3,param_4);
    if (iVar3 != 0) {
      FUN_00553bc0(iVar3,1);
      piVar1 = *(int **)(*(int *)(param_1 + 0x34) + 4);
      uStack_8 = 0;
      piStack_14 = piVar1;
      (**(code **)(*piVar1 + 4))();
      uStack_8 = 1;
      piVar4 = (int *)FUN_0054e680(auStack_18);
      cVar2 = (**(code **)(*piVar4 + 0xc))();
      if (cVar2 == '\0') {
        *(int **)(param_1 + 0x38) = piVar4;
        FUN_00553ca0();
      }
      else {
        *(undefined4 *)(param_1 + 0x38) = 0;
      }
      uStack_8 = 2;
      if (piVar1 != (int *)0x0) {
        puVar5 = (undefined4 *)(**(code **)(*piVar1 + 8))();
        if (puVar5 != (undefined4 *)0x0) {
          (**(code **)*puVar5)(1);
        }
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 4009 ; VA 0x005887a0 ; FUN_005887a0 */

int __thiscall
FUN_005887a0(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined4 ****ppppuVar8;
  int *piStack_c8;
  undefined4 ***pppuStack_c4;
  uint *puStack_c0;
  undefined4 ***pppuStack_bc;
  undefined4 ***pppuStack_b8;
  uint auStack_90 [2];
  undefined auStack_88 [28];
  undefined4 ***apppuStack_6c [5];
  uint uStack_58;
  uint auStack_54 [2];
  undefined auStack_4c [24];
  undefined auStack_34 [4];
  int *piStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796d0f;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff4c;
  uStack_2c = 0;
  iStack_20 = param_1;
  if (0 < *(int *)(param_1 + 0xc4)) {
    pppuStack_b8 = (undefined4 ***)0x18bf644;
    pppuStack_bc = (undefined4 ***)0x588c4c;
    ExceptionList = &pvStack_10;
    FUN_0054eff0();
    pppuStack_b8 = (undefined4 ***)0x0;
    puStack_c0 = (uint *)auStack_4c;
    uStack_8 = 0;
    pppuStack_bc = (undefined4 ***)0x1;
    pppuStack_c4 = (undefined4 ***)0x588c60;
    FUN_008783f0();
    uStack_8 = 0xffffffff;
    pppuStack_b8 = (undefined4 ***)0x588c72;
    FUN_005507b0();
    pppuStack_b8 = (undefined4 ***)0x0;
    pppuStack_bc = (undefined4 ***)0x0;
    puStack_c0 = (uint *)0xffffffff;
    pppuStack_c4 = (undefined4 ***)0x588c83;
    FUN_0151f6f0();
    pppuStack_b8 = (undefined4 ***)0x18bf664;
    pppuStack_bc = (undefined4 ***)0x18bf590;
    uStack_8 = 1;
    puStack_c0 = (uint *)0x588c9f;
    FUN_0151f850();
    uVar6 = DAT_01e90d5c;
    pppuStack_b8 = (undefined4 ***)0x18bf59c;
    pppuStack_bc = (undefined4 ***)0x588cb2;
    FUN_0054eff0();
    pppuStack_b8 = (undefined4 ***)0x0;
    pppuStack_bc = (undefined4 ***)uVar6;
    puStack_c0 = (uint *)auStack_4c;
    uStack_8._0_1_ = 2;
    pppuStack_c4 = (undefined4 ***)0x588cc8;
    FUN_01520d20();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    pppuStack_b8 = (undefined4 ***)0x588cd4;
    FUN_005507b0();
    pppuStack_b8 = (undefined4 ***)0x18bf66c;
                    /* WARNING: Subroutine does not return */
    pppuStack_bc = (undefined4 ***)0x588cde;
    FUN_016757c0();
  }
  puVar7 = param_2 + 2;
  pppuStack_bc = (undefined4 ***)0x5887f2;
  ExceptionList = &pvStack_10;
  pppuStack_b8 = (undefined4 ***)puVar7;
  puStack_14 = &stack0xffffff4c;
  FUN_0054ef60();
  uStack_8 = 3;
  if (puVar7 != &DAT_01d79c68) {
    pppuStack_b8 = (undefined4 ***)param_2[6];
    if (0xf < (uint)param_2[7]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    puStack_c0 = (uint *)0x588818;
    pppuStack_bc = (undefined4 ***)puVar7;
    FUN_005542c0();
  }
  iStack_1c = 0;
  piStack_18 = (int *)0x0;
  LOCK();
  *(int *)(param_1 + 0xc4) = *(int *)(param_1 + 0xc4) + 1;
  UNLOCK();
  uStack_8._0_1_ = 5;
  pppuStack_b8 = (undefined4 ***)0x588832;
  FUN_00554d20();
  pppuStack_b8 = (undefined4 ***)&iStack_1c;
  pppuStack_bc = (undefined4 ***)param_6;
  piStack_c8 = &iStack_28;
  puStack_c0 = (uint *)param_3;
  pppuStack_c4 = (undefined4 ***)param_2;
  FUN_0057bff0();
  uStack_8._0_1_ = 7;
  if (DAT_01d5a4c0 == '\0') {
    pppuStack_b8 = (undefined4 ***)0x0;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[1] = piStack_24[1] + 1;
      UNLOCK();
    }
    FUN_0055d300(&piStack_c8,FUN_0057da90,param_1,iStack_28,piStack_24);
    FUN_00558340();
    pppuStack_b8 = (undefined4 ***)0x18bf694;
    pppuStack_bc = (undefined4 ***)auStack_90;
    uStack_8._0_1_ = 8;
    puStack_c0 = auStack_54;
    pppuStack_c4 = (undefined4 ***)0x5888bd;
    pppuStack_b8 = (undefined4 ***)FUN_0151a450();
    uStack_8._0_1_ = 9;
    pppuStack_bc = (undefined4 ***)0x5888cd;
    FUN_00558700();
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    pppuStack_b8 = (undefined4 ***)0x5888d9;
    FUN_016899e0();
    if (param_2 != (undefined4 *)0x0) {
      LOCK();
      iVar5 = param_2[1] + -1;
      param_2[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        pppuStack_b8 = (undefined4 ***)0x0;
        pppuStack_bc = (undefined4 ***)0x5888f4;
        (**(code **)*param_2)();
        pppuStack_bc = (undefined4 ***)param_2;
        puStack_c0 = (uint *)0x0;
        pppuStack_c4 = (undefined4 ***)0x5888fd;
        pppuStack_c4 = (undefined4 ***)GetProcessHeap();
        piStack_c8 = (int *)0x588904;
        HeapFree();
      }
    }
    uStack_8._0_1_ = 0xb;
    if (auStack_54[0] != 0) {
      if (((auStack_54[0] & 1) == 0) && (*(code **)(auStack_54[0] & 0xfffffffe) != (code *)0x0)) {
        puStack_c0 = (uint *)auStack_4c;
        pppuStack_b8 = (undefined4 ***)0x2;
        pppuStack_c4 = (undefined4 ***)0x588925;
        pppuStack_bc = (undefined4 ***)puStack_c0;
        (**(code **)(auStack_54[0] & 0xfffffffe))();
      }
      auStack_54[0] = 0;
    }
    uStack_8._0_1_ = 0xc;
    if (((auStack_90[0] != 0) && ((auStack_90[0] & 1) == 0)) &&
       (*(code **)(auStack_90[0] & 0xfffffffe) != (code *)0x0)) {
      puStack_c0 = (uint *)auStack_88;
      pppuStack_b8 = (undefined4 ***)0x2;
      pppuStack_c4 = (undefined4 ***)0x588956;
      pppuStack_bc = (undefined4 ***)puStack_c0;
      (**(code **)(auStack_90[0] & 0xfffffffe))();
    }
  }
  uStack_8._0_1_ = 7;
  iVar5 = iStack_1c;
  if (DAT_01d59035 != 0) {
    pppuStack_b8 = apppuStack_6c;
    if (0xf < uStack_58) {
      pppuStack_b8 = apppuStack_6c[0];
    }
    puStack_c0 = (uint *)(uint)DAT_01d59035;
    pppuStack_bc = (undefined4 ***)0x18bf6a8;
    pppuStack_c4 = (undefined4 ***)0x588986;
    FUN_01677650();
    iVar5 = iStack_1c;
    if (DAT_01d59035 != 0) {
      pppuStack_b8 = (undefined4 ***)iStack_1c;
      puStack_c0 = (uint *)(uint)DAT_01d59035;
      pppuStack_bc = (undefined4 ***)0x18bf610;
      pppuStack_c4 = (undefined4 ***)0x5889a4;
      FUN_016774b0();
    }
  }
  pppuStack_b8 = (undefined4 ***)param_5;
  pppuStack_c4 = apppuStack_6c;
  pppuStack_bc = (undefined4 ***)param_4;
  puStack_c0 = (uint *)param_3;
  piStack_c8 = (int *)0x5889c0;
  FUN_0057efc0();
  if ((-(uint)(iVar5 != 0) & iVar5 + 0xcU) == 0) {
    iVar5 = 0;
  }
  else {
    pppuStack_b8 = (undefined4 ***)&LAB_0055d590;
    pppuStack_bc = (undefined4 ***)&DAT_01ea8af8;
    puStack_c0 = (uint *)0x5889de;
    FUN_005789c0();
    pppuStack_b8 = (undefined4 ***)0x5889e6;
    pppuStack_b8 = (undefined4 ***)FUN_00560d40();
    pppuStack_bc = (undefined4 ***)0x5889ee;
    piVar3 = (int *)FUN_008aa140();
    if (*piVar3 == 0) {
      pppuStack_b8 = (undefined4 ***)0x5889fa;
      pppuStack_b8 = (undefined4 ***)FUN_00995770();
      pppuStack_bc = (undefined4 ***)auStack_34;
      puStack_c0 = (uint *)0x588a06;
      piVar4 = (int *)FUN_008a9ba0();
      iVar5 = *piVar4;
      iVar2 = piVar4[1];
      *piVar4 = 0;
      piVar4[1] = 0;
      *piVar3 = iVar5;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = iVar2;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          pppuStack_b8 = (undefined4 ***)0x588a33;
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            pppuStack_b8 = (undefined4 ***)0x588a43;
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      piVar4 = piStack_30;
      if (piStack_30 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_30[1] + -1;
        piStack_30[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          pppuStack_b8 = (undefined4 ***)0x588a59;
          (**(code **)*piStack_30)();
          LOCK();
          piVar1 = piVar4 + 2;
          iVar5 = *piVar1 + -1;
          *piVar1 = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            pppuStack_b8 = (undefined4 ***)0x588a69;
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
    }
    iVar5 = *piVar3;
  }
  pppuStack_b8 = (undefined4 ***)DAT_02110da8;
  uStack_8._0_1_ = 0xd;
  pppuStack_bc = (undefined4 ***)0x588a86;
  uVar6 = FUN_01675290();
  pppuStack_b8 = (undefined4 ***)0x20;
  uStack_8._0_1_ = 0xe;
  pppuStack_bc = (undefined4 ***)0x588a99;
  puVar7 = (undefined4 *)FUN_01674e20();
  if (puVar7 == (undefined4 *)0x0) {
    puVar7 = (undefined4 *)0x0;
  }
  else {
    *puVar7 = 0;
    puVar7[1] = 1;
    puVar7[2] = FUN_0057df60;
    puVar7[3] = _guard_check_icall;
    puVar7[4] = 0;
    puVar7[5] = iVar5 + 0xd4;
    puVar7[6] = FUN_00554d20;
    puVar7[7] = piStack_30;
  }
  pppuStack_bc = (undefined4 ***)0x588ae1;
  pppuStack_b8 = (undefined4 ***)puVar7;
  FUN_016797d0();
  if (puVar7 != (undefined4 *)0x0) {
    LOCK();
    puVar7[1] = puVar7[1] + 1;
    UNLOCK();
  }
  uStack_2c = 1;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  pppuStack_bc = (undefined4 ***)0x588b05;
  pppuStack_b8 = (undefined4 ***)uVar6;
  FUN_01675290();
  pppuStack_b8 = *(undefined4 ****)(iStack_28 + 0x44);
  *(undefined4 **)(iStack_28 + 0x44) = puVar7;
  if (pppuStack_b8 != (undefined4 ***)0x0) {
    piVar3 = (int *)((int)pppuStack_b8 + 4);
    LOCK();
    iStack_28 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    iStack_28 = iStack_28 + -1;
    if (iStack_28 == 0) {
      pppuStack_bc = (undefined4 ***)0x588b2b;
      iStack_28 = FUN_01674ea0();
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar3 = piStack_24 + 1;
    iVar5 = *piVar3;
    iStack_28 = *piVar3;
    *piVar3 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      pppuStack_b8 = (undefined4 ***)0x588b44;
      (**(code **)*piStack_24)();
      LOCK();
      piVar3 = piStack_24 + 2;
      iVar5 = *piVar3;
      iStack_28 = *piVar3;
      *piVar3 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        pppuStack_b8 = (undefined4 ***)0x588b54;
        iStack_28 = (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  piVar3 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar4 = piStack_18 + 1;
    iVar5 = *piVar4;
    iStack_28 = *piVar4;
    *piVar4 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      pppuStack_b8 = (undefined4 ***)0x588b6a;
      iStack_28 = (**(code **)*piStack_18)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar5 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        pppuStack_b8 = (undefined4 ***)0x588b79;
        iStack_28 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (0xf < uStack_58) {
    pppuStack_b8 = (undefined4 ***)(uStack_58 + 1);
    ppppuVar8 = (undefined4 ****)apppuStack_6c[0];
    if (0xfff < pppuStack_b8) {
      ppppuVar8 = (undefined4 ****)apppuStack_6c[0][-1];
      pppuStack_b8 = (undefined4 ***)(uStack_58 + 0x24);
      if (0x1f < (uint)((int)apppuStack_6c[0] + (-4 - (int)ppppuVar8))) {
                    /* WARNING: Subroutine does not return */
        pppuStack_b8 = (undefined4 ***)Catch_00588ce3;
        FUN_017167a3();
      }
    }
    puStack_c0 = (uint *)0x588baa;
    pppuStack_bc = ppppuVar8;
    iStack_28 = FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return iStack_28;
}



/* FUNCTION 4010 ; VA 0x00588bc0 ; Catch@00588bc0 */

void Catch_00588bc0(void)

{
  int *piVar1;
  int iVar2;
  int unaff_EBP;
  char *in_stack_fffffff8;
  undefined4 in_stack_fffffffc;
  
  if (DAT_01d59035 != '\0') {
    in_stack_fffffffc = (**(code **)(**(int **)(unaff_EBP + -0x6c) + 4))();
    in_stack_fffffff8 = "Closing DataModel due to exception: %s";
    FUN_01677650(DAT_01d59035,"Closing DataModel due to exception: %s",in_stack_fffffffc);
    if (DAT_01d59035 != '\0') {
      in_stack_fffffffc = *(undefined4 *)(unaff_EBP + -0x18);
      in_stack_fffffff8 = "DataModel: %p";
      FUN_016774b0(DAT_01d59035,"DataModel: %p",in_stack_fffffffc);
    }
  }
  FUN_00557fc0(unaff_EBP + -0x18);
  iVar2 = *(int *)(unaff_EBP + -0x1c);
  FUN_0057ac50(in_stack_fffffff8,in_stack_fffffffc);
  FUN_0058a2b0();
  LOCK();
  piVar1 = (int *)(iVar2 + 0xc4);
  iVar2 = *piVar1 + -1;
  *piVar1 = iVar2;
  UNLOCK();
  if (iVar2 == 0) {
    FUN_00554b10();
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 4011 ; VA 0x00588ce3 ; Catch@00588ce3 */

void Catch_00588ce3(void)

{
  int unaff_EBP;
  
  FUN_005693c0(*(int *)(unaff_EBP + -0x1c) + 0xbc);
  *(undefined *)(unaff_EBP + -4) = 0x11;
  FUN_0057edd0(unaff_EBP + -0x68);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 4012 ; VA 0x00588d20 ; FUN_00588d20 */

int __thiscall FUN_00588d20(int param_1,int param_2)

{
  int iVar1;
  undefined *puVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  
  if ((*(byte *)(param_1 + 0x3c) & 2) != 0) {
    return -1;
  }
  if (param_2 != -1) {
    uVar4 = **(uint **)(param_1 + 0x20);
    iVar1 = **(int **)(param_1 + 0x30);
    uVar6 = iVar1 + uVar4;
    if ((uVar4 != 0) && (uVar4 < uVar6)) {
      **(int **)(param_1 + 0x30) = iVar1 + -1;
      puVar2 = (undefined *)**(int **)(param_1 + 0x20);
      **(int **)(param_1 + 0x20) = (int)(puVar2 + 1);
      *puVar2 = (char)param_2;
      *(uint *)(param_1 + 0x38) = uVar4 + 1;
      return param_2;
    }
    iVar1 = **(int **)(param_1 + 0xc);
    uVar6 = -(uint)(uVar4 != 0) & uVar6 - iVar1;
    if (uVar6 < 0x20) {
      iVar7 = 0x20;
    }
    else if (uVar6 < 0x3fffffff) {
      iVar7 = uVar6 * 2;
    }
    else {
      if (0x7ffffffe < uVar6) {
        return -1;
      }
      iVar7 = 0x7fffffff;
    }
    iVar3 = FUN_00554060(iVar7);
    FUN_0170c6f0(iVar3,iVar1,uVar6);
    iVar5 = iVar3 + uVar6;
    *(int *)(param_1 + 0x38) = iVar5 + 1;
    **(int **)(param_1 + 0x10) = iVar3;
    **(int **)(param_1 + 0x20) = iVar5;
    **(int **)(param_1 + 0x30) = (iVar3 - iVar5) + iVar7;
    if ((*(byte *)(param_1 + 0x3c) & 4) == 0) {
      iVar7 = *(int *)(param_1 + 0x38);
      iVar5 = (**(int **)(param_1 + 0x1c) - iVar1) + iVar3;
      **(int **)(param_1 + 0xc) = iVar3;
      **(int **)(param_1 + 0x1c) = iVar5;
      **(int **)(param_1 + 0x2c) = iVar7 - iVar5;
    }
    else {
      **(int **)(param_1 + 0xc) = iVar3;
      **(undefined4 **)(param_1 + 0x1c) = 0;
      **(int **)(param_1 + 0x2c) = iVar3;
    }
    uVar4 = *(uint *)(param_1 + 0x3c);
    if ((uVar4 & 1) != 0) {
      FUN_00554a20(iVar1,uVar6);
      uVar4 = *(uint *)(param_1 + 0x3c);
    }
    *(uint *)(param_1 + 0x3c) = uVar4 | 1;
    **(int **)(param_1 + 0x30) = **(int **)(param_1 + 0x30) + -1;
    puVar2 = (undefined *)**(int **)(param_1 + 0x20);
    **(int **)(param_1 + 0x20) = (int)(puVar2 + 1);
    *puVar2 = (char)param_2;
    return param_2;
  }
  return 0;
}



/* FUNCTION 4013 ; VA 0x00588e80 ; FUN_00588e80 */

int __thiscall FUN_00588e80(int param_1,int param_2)

{
  uint uVar1;
  
  uVar1 = **(uint **)(param_1 + 0x1c);
  if (((uVar1 != 0) && (**(uint **)(param_1 + 0xc) < uVar1)) &&
     ((param_2 == -1 ||
      (((char)param_2 == *(char *)(uVar1 - 1) || ((*(byte *)(param_1 + 0x3c) & 2) == 0)))))) {
    **(int **)(param_1 + 0x2c) = **(int **)(param_1 + 0x2c) + 1;
    **(int **)(param_1 + 0x1c) = **(int **)(param_1 + 0x1c) + -1;
    if (param_2 == -1) {
      param_2 = 0;
    }
    else {
      *(char *)**(undefined4 **)(param_1 + 0x1c) = (char)param_2;
    }
    return param_2;
  }
  return -1;
}



/* FUNCTION 4014 ; VA 0x00588ee0 ; FUN_00588ee0 */

undefined *
FUN_00588ee0(int param_1,int param_2,undefined4 param_3,int *param_4,int param_5,undefined **param_6
            ,int *param_7,int *param_8)

{
  int *piVar1;
  undefined **ppuVar2;
  int iVar3;
  undefined *puVar4;
  undefined *puVar5;
  undefined4 uVar6;
  undefined4 **ppuStack_74;
  int *piStack_70;
  int aiStack_60 [9];
  int *piStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  int iStack_30;
  undefined **ppuStack_2c;
  undefined8 uStack_28;
  undefined4 *puStack_20;
  undefined uStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01796d58;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  *param_7 = *param_7 + 1;
  if ((*param_7 < DAT_01d5918c) &&
     (((DAT_01d593d8 != '\0' && (param_1 != 0)) ||
      ((DAT_01d593e0 != '\0' && (*(int *)(param_2 + 0xc) == 0x1f7)))))) {
    piStack_70 = (int *)auStack_18;
    ppuStack_74 = (undefined4 **)0x588f5a;
    FUN_014c9ba0();
    if (param_4 != (int *)0x0) {
      LOCK();
      param_4[1] = param_4[1] + 1;
      UNLOCK();
    }
    piStack_34 = param_4;
    uStack_38 = param_3;
    if (param_6 != (undefined **)0x0) {
      LOCK();
      param_6[1] = param_6[1] + 1;
      UNLOCK();
    }
    ppuStack_2c = param_6;
    iStack_30 = param_5;
    if (param_8 != (int *)0x0) {
      LOCK();
      param_8[1] = param_8[1] + 1;
      UNLOCK();
    }
    piStack_70 = &uStack_38;
    uStack_28 = CONCAT44(param_8,param_7);
    piStack_3c = (int *)0x0;
    ppuStack_74 = (undefined4 **)0x588fb2;
    piStack_3c = (int *)FUN_005580b0();
    piStack_70 = (int *)0x588fbd;
    FUN_0056b6b0();
    piStack_70 = aiStack_60;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    ppuStack_74 = (undefined4 **)0x588fcd;
    puVar5 = (undefined *)FUN_014cb530();
    if (piStack_3c != (int *)0x0) {
      piStack_70 = (int *)(uint)(piStack_3c != aiStack_60);
      ppuStack_74 = (undefined4 **)0x588fe5;
      puVar5 = (undefined *)(**(code **)(*piStack_3c + 0x10))();
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar3 = *piVar1;
      puVar5 = (undefined *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        piStack_70 = (int *)0x589003;
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar3 = *piVar1;
        puVar5 = (undefined *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          piStack_70 = (int *)0x589017;
          puVar5 = (undefined *)(**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  else if (param_1 == 0) {
    iVar3 = *(int *)(param_2 + 0xc);
    if ((iVar3 - 200U < 100) && (iVar3 != 0xca)) {
      ppuStack_74 = &DAT_01d79ea8;
      if (0xf < DAT_01d79ebc) {
        ppuStack_74 = DAT_01d79ea8;
      }
      piStack_70 = (int *)DAT_01d79eb8;
      FUN_014ca040(&puStack_20);
      piStack_70 = &uStack_38;
      ppuStack_74 = (undefined4 **)0x5890d9;
      piStack_70 = (int *)FUN_0058c4f0();
      ppuStack_74 = (undefined4 **)0x5890e2;
      FUN_005511f0();
      piStack_70 = (int *)0x5890ea;
      FUN_005507b0();
      if (*(int *)(param_5 + 0x10) == 0) {
        piStack_70 = (int *)0x7;
        ppuStack_74 = (undefined4 **)&DAT_018bf2f0;
        FUN_005542c0();
      }
      piStack_70 = (int *)(param_2 + 0x40);
      ppuStack_74 = (undefined4 **)0x58910b;
      puVar5 = (undefined *)FUN_0058bd10();
    }
    else {
      piStack_70 = (int *)(param_2 + 0x40);
      ppuStack_74 = (undefined4 **)(param_2 + 0x74);
      uVar6 = FUN_014cc1e0(iVar3);
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      FUN_0055ddf0(&ppuStack_74,uVar6);
      FUN_0058bc20();
      piStack_70 = (int *)0x589143;
      puVar5 = (undefined *)FUN_0056e860();
    }
  }
  else {
    puStack_20 = (undefined4 *)(param_2 + 0x74);
    if (0xf < *(uint *)(param_2 + 0x88)) {
      puStack_20 = (undefined4 *)*puStack_20;
    }
    piStack_70 = (int *)&uStack_28;
    ppuStack_2c = std::exception::vftable;
    ppuStack_74 = &puStack_20;
    uStack_1c = 1;
    uStack_28 = 0;
    FUN_0170c226();
    ppuStack_2c = std::runtime_error::vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_0055de60(&ppuStack_74,&ppuStack_2c);
    FUN_0058bc20();
    piStack_70 = (int *)&uStack_28;
    ppuStack_2c = std::exception::vftable;
    ppuStack_74 = (undefined4 **)0x589082;
    puVar5 = (undefined *)FUN_0170c289();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 1;
    iVar3 = *piVar1;
    puVar5 = (undefined *)*piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      piStack_70 = (int *)0x589159;
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar3 = *piVar1;
      puVar5 = (undefined *)*piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        piStack_70 = (int *)0x589169;
        puVar5 = (undefined *)(**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (undefined **)0x0) {
    LOCK();
    ppuVar2 = param_6 + 1;
    puVar4 = *ppuVar2;
    puVar5 = *ppuVar2;
    *ppuVar2 = puVar4 + -1;
    UNLOCK();
    if (puVar4 + -1 == (undefined *)0x0) {
      piStack_70 = (int *)0x58917f;
      (**(code **)*param_6)();
      LOCK();
      ppuVar2 = param_6 + 2;
      puVar4 = *ppuVar2;
      puVar5 = *ppuVar2;
      *ppuVar2 = puVar4 + -1;
      UNLOCK();
      if (puVar4 + -1 == (undefined *)0x0) {
        piStack_70 = (int *)0x58918f;
        puVar5 = (undefined *)(**(code **)(*param_6 + 4))();
      }
    }
  }
  if (param_8 != (int *)0x0) {
    LOCK();
    piVar1 = param_8 + 1;
    iVar3 = *piVar1;
    puVar5 = (undefined *)*piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      piStack_70 = (int *)0x5891a5;
      puVar5 = (undefined *)(**(code **)*param_8)();
      LOCK();
      piVar1 = param_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        piStack_70 = (int *)0x5891b4;
        puVar5 = (undefined *)(**(code **)(*param_8 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 4015 ; VA 0x005891d0 ; FUN_005891d0 */

int FUN_005891d0(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [8];
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01796d90;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piStack_18 = (int *)0x0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  piStack_18 = (int *)FUN_00575b30();
  uStack_8._0_1_ = 1;
  iVar5 = *param_1;
  if (iVar5 != param_1[1]) {
    do {
      FUN_00563690(auStack_38);
      uStack_8._0_1_ = 2;
      FUN_0055b0f0(auStack_20,0,auStack_38,param_2);
      uStack_8._0_1_ = 1;
      if (0xf < uStack_24) {
        uVar4 = uStack_24 + 1;
        uVar3 = auStack_38[0];
        if (0xfff < uVar4) {
          uVar3 = *(uint *)(auStack_38[0] - 4);
          uVar4 = uStack_24 + 0x24;
          if (0x1f < (auStack_38[0] - uVar3) - 4) goto LAB_00589377;
        }
        FUN_01674ea0(uVar3,uVar4);
      }
      iVar5 = iVar5 + 0xd0;
    } while (iVar5 != param_1[1]);
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  FUN_005542c0("ios,ios",7);
  uStack_8._0_1_ = 3;
  FUN_0055b250(auStack_20,0,auStack_38,param_2);
  uStack_8._0_1_ = 1;
  if (0xf < uStack_24) {
    uVar4 = uStack_24 + 1;
    uVar3 = auStack_38[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_38[0] - 4);
      uVar4 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar3) - 4) {
LAB_00589377:
        uStack_8._0_1_ = 1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  FUN_0098c820(&piStack_18);
  piVar1 = piStack_18;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00576720(piStack_18[1]);
  piStack_18[1] = (int)piVar1;
  *piStack_18 = (int)piVar1;
  piStack_18[2] = (int)piVar1;
  uStack_14 = 0;
  iVar5 = FUN_01674ea0(piStack_18,0x28);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 4016 ; VA 0x00589380 ; FUN_00589380 */

void FUN_00589380(int *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01796da0;
  pvStack_10 = ExceptionList;
  LOCK();
  DAT_01e90d80 = DAT_01e90d80 + 1;
  UNLOCK();
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  (**(code **)(*param_1 + 0x3c))();
  (**(code **)*param_1)(1);
  LOCK();
  DAT_01e90d80 = DAT_01e90d80 + -1;
  UNLOCK();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4017 ; VA 0x005893d7 ; Catch_All@005893d7 */

undefined4 Catch_All_005893d7(void)

{
  FUN_01675310("CaughtException",&DAT_018bc9b8);
  return 0x5893bf;
}



/* FUNCTION 4018 ; VA 0x005893f0 ; FUN_005893f0 */

void __thiscall FUN_005893f0(int param_1,undefined4 param_2)

{
  if (*(int *)(param_1 + 8) != *(int *)(param_1 + 4)) {
    FUN_0054ef60(param_2);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x18;
    return;
  }
  FUN_00559960(*(int *)(param_1 + 4),param_2);
  return;
}



/* FUNCTION 4019 ; VA 0x00589420 ; FUN_00589420 */

int * __thiscall FUN_00589420(int *param_1,undefined param_2)

{
  undefined *puVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796dc0;
  pvStack_10 = ExceptionList;
  iVar3 = *param_1;
  piVar4 = *(int **)(*(int *)(iVar3 + 4) + 0x38 + (int)param_1);
  ExceptionList = &pvStack_10;
  if (piVar4 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar4 + 4))();
    iVar3 = *param_1;
  }
  uStack_8 = 0;
  if (((*(int *)(*(int *)(iVar3 + 4) + 0xc + (int)param_1) == 0) &&
      (piVar4 = *(int **)(*(int *)(iVar3 + 4) + 0x3c + (int)param_1), piVar4 != (int *)0x0)) &&
     (piVar4 != param_1)) {
    FUN_00581480();
    iVar3 = *param_1;
  }
  uStack_8 = 1;
  if (*(int *)(*(int *)(iVar3 + 4) + 0xc + (int)param_1) != 0) {
    FUN_00554460(*(uint *)(*(int *)(*param_1 + 4) + 0xc + (int)param_1) | 4,0);
    uStack_8 = 4;
    cVar2 = thunk_FUN_0170e3b7();
    if (cVar2 == '\0') {
      FUN_00577770();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    piVar4 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
    if (piVar4 != (int *)0x0) {
      (**(code **)(*piVar4 + 8))();
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  piVar4 = *(int **)(*(int *)(iVar3 + 4) + 0x38 + (int)param_1);
  uStack_8 = 2;
  if (*(int *)piVar4[8] != 0) {
    iVar3 = *(int *)piVar4[0xc];
    if (0 < iVar3) {
      *(int *)piVar4[0xc] = iVar3 + -1;
      puVar1 = *(undefined **)piVar4[8];
      *(undefined **)piVar4[8] = puVar1 + 1;
      *puVar1 = param_2;
      piVar4 = (int *)FUN_0058952e();
      return piVar4;
    }
  }
  (**(code **)(*piVar4 + 0xc))(param_2);
  piVar4 = (int *)FUN_0058952e();
  return piVar4;
}



/* FUNCTION 4020 ; VA 0x0058950a ; Catch_All@0058950a */

undefined * Catch_All_0058950a(void)

{
  FUN_005565b0(4,1);
  return &DAT_00589523;
}



/* FUNCTION 4021 ; VA 0x0058952e ; FUN_0058952e */

void __fastcall FUN_0058952e(undefined4 param_1,uint param_2)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  int unaff_EBP;
  int *unaff_ESI;
  uint unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  if (*(int *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0x38) == 0) {
    param_2 = unaff_EDI;
  }
  FUN_00554460(*(uint *)(*(int *)(*unaff_ESI + 4) + 0xc + (int)unaff_ESI) | param_2,0);
  *(undefined4 *)(unaff_EBP + -4) = 4;
  cVar3 = thunk_FUN_0170e3b7();
  if (cVar3 == '\0') {
    FUN_00577770();
  }
  iVar1 = *unaff_ESI;
  *(undefined *)(unaff_EBP + -4) = 5;
  piVar2 = *(int **)(*(int *)(iVar1 + 4) + 0x38 + (int)unaff_ESI);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 8))();
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 4022 ; VA 0x005895a0 ; FUN_005895a0 */

void FUN_005895a0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  
  if (*(int *)(param_1 + 4) == 3) {
    piVar2 = *(int **)(param_1 + 8);
    piVar1 = piVar2 + 4;
    if (0xf < (uint)piVar2[5]) {
      piVar2 = (int *)*piVar2;
    }
    FUN_0055b3b0(param_2,piVar2,*piVar1);
    return;
  }
  if (*(int *)(param_1 + 4) == 4) {
    uVar3 = FUN_00558890(param_2,&DAT_018bfd90);
    FUN_00562ba0(uVar3);
    iVar4 = *(int *)(param_1 + 0xc);
    uVar5 = 0;
    if (*(int *)(iVar4 + 8) - *(int *)(iVar4 + 4) >> 2 != 0) {
      do {
        if (uVar5 != 0) {
          uVar3 = FUN_00558890(param_2,&DAT_018bf378);
          FUN_00562ba0(uVar3);
        }
        FUN_005895a0(*(undefined4 *)(*(int *)(*(int *)(param_1 + 0xc) + 4) + uVar5 * 4),param_2);
        iVar4 = *(int *)(param_1 + 0xc);
        uVar5 = uVar5 + 1;
      } while (uVar5 < (uint)(*(int *)(iVar4 + 8) - *(int *)(iVar4 + 4) >> 2));
    }
    if (*(int *)(iVar4 + 4) != *(int *)(iVar4 + 8)) {
      FUN_00562ba0(param_2);
    }
    FUN_00558890(param_2,&DAT_018bfd94);
  }
  return;
}



/* FUNCTION 4023 ; VA 0x00589660 ; FUN_00589660 */

undefined4 __fastcall FUN_00589660(undefined4 *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  void *pvVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar4 = ExceptionList;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  piVar1 = param_1 + 9;
  ExceptionList = &pvStack_10;
  *piVar1 = *piVar1 + -1;
  if (*piVar1 != 0) {
    ExceptionList = pvVar4;
    return 0;
  }
  *param_1 = boost::exception_detail::error_info_container_impl::vftable;
  uVar2 = param_1[8];
  if (0xf < uVar2) {
    iVar3 = param_1[3];
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_1[7] = 0;
  param_1[8] = 0xf;
  *(undefined *)(param_1 + 3) = 0;
  iVar3 = param_1[1];
  uStack_8 = 0;
  FUN_005765a0(*(undefined4 *)(iVar3 + 4));
  *(int *)(param_1[1] + 4) = iVar3;
  *(int *)param_1[1] = iVar3;
  *(int *)(param_1[1] + 8) = iVar3;
  param_1[2] = 0;
  FUN_01674ea0(param_1[1],0x1c);
  *param_1 = boost::exception_detail::error_info_container::vftable;
  FUN_01674ea0(param_1,0x28);
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 4024 ; VA 0x00589740 ; FUN_00589740 */

void * FUN_00589740(int param_1,int *param_2)

{
  int *piVar1;
  uint uVar2;
  void *pvVar3;
  undefined4 ****ppppuVar4;
  undefined4 ****ppppuVar5;
  undefined4 ****ppppuVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  undefined8 uVar10;
  undefined auStack_b8 [24];
  undefined4 ***apppuStack_a0 [5];
  uint uStack_8c;
  undefined auStack_88 [24];
  int iStack_70;
  int iStack_6c;
  undefined4 ***apppuStack_68 [4];
  int iStack_58;
  uint uStack_54;
  undefined4 ***apppuStack_50 [4];
  int iStack_40;
  uint uStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_2c;
  undefined8 uStack_28;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01796e19;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar3 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar2 = FUN_01679ce0();
    pvVar3 = (void *)(uVar2 / 10000);
    if ((int)(uVar2 % 10000) < DAT_01e90d50) {
      FUN_0054ef60(param_1 + 0x14);
      uStack_8._0_1_ = 1;
      FUN_0054ef60(param_1 + 0x2c);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if ((iStack_58 != 0) && (iStack_40 != 0)) {
        iStack_1c = 0;
        iStack_18 = 0;
        iStack_14 = 0;
        uVar10 = 0;
        uStack_8._0_1_ = 3;
        uStack_28 = 0;
        FUN_005dbba0(&iStack_38);
        uStack_8._0_1_ = 4;
        iStack_2c = iStack_34;
        iVar7 = (int)uStack_28;
        iVar9 = uStack_28._4_4_;
        if (iStack_38 != iStack_34) {
          iStack_20 = uStack_28._4_4_;
          iVar8 = iStack_38;
          do {
            iVar9 = iStack_20;
            FUN_0054ef60(iVar8);
            iStack_70 = *(int *)(iVar8 + 0x18);
            iStack_6c = *(int *)(iVar8 + 0x1c);
            uStack_8._0_1_ = 5;
            if (iVar7 == 0 && iVar9 == 0) {
              iVar7 = iStack_70;
              iStack_20 = iStack_6c;
            }
            FUN_0054ef60(auStack_88);
            uStack_8._0_1_ = 6;
            FUN_016f4020();
            ppppuVar6 = apppuStack_a0;
            if (0xf < uStack_8c) {
              ppppuVar6 = (undefined4 ****)apppuStack_a0[0];
            }
            ppppuVar5 = apppuStack_50;
            if (0xf < uStack_3c) {
              ppppuVar5 = (undefined4 ****)apppuStack_50[0];
            }
            ppppuVar4 = apppuStack_68;
            if (0xf < uStack_54) {
              ppppuVar4 = (undefined4 ****)apppuStack_68[0];
            }
            uStack_28 = uVar10;
            FUN_01675640(auStack_b8,"BatchJob_%s_%s_%s",ppppuVar4,ppppuVar5,ppppuVar6);
            iVar9 = iStack_18;
            uStack_8 = CONCAT31(uStack_8._1_3_,7);
            if (iStack_14 == iStack_18) {
              FUN_00559790(iStack_18,auStack_b8,&uStack_28);
            }
            else {
              FUN_0054ef60(auStack_b8);
              *(undefined8 *)(iVar9 + 0x18) = uStack_28;
              iStack_18 = iStack_18 + 0x20;
              uVar10 = uStack_28;
            }
            FUN_005507b0();
            FUN_005507b0();
            uStack_8._0_1_ = 4;
            FUN_005507b0();
            iVar8 = iVar8 + 0x20;
            iVar9 = iStack_20;
          } while (iVar8 != iStack_2c);
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        FUN_0056d440();
        if (iVar7 != 0 || iVar9 != 0) {
          FUN_00874d70(&iStack_1c,0);
        }
        if (iStack_1c != 0) {
          FUN_00559500(iStack_1c,iStack_18,&iStack_1c);
          uVar2 = iStack_14 - iStack_1c & 0xffffffe0;
          iVar7 = iStack_1c;
          if (0xfff < uVar2) {
            iVar7 = *(int *)(iStack_1c + -4);
            uVar2 = uVar2 + 0x23;
            if (0x1f < (iStack_1c - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar7,uVar2);
          iStack_1c = 0;
          iStack_18 = 0;
          iStack_14 = 0;
        }
      }
      FUN_005507b0();
      pvVar3 = (void *)FUN_005507b0();
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar7 = *piVar1;
    pvVar3 = (void *)*piVar1;
    *piVar1 = iVar7 + -1;
    UNLOCK();
    if (iVar7 + -1 == 0) {
      pvVar3 = (void *)(**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        pvVar3 = (void *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar3;
}



/* FUNCTION 4025 ; VA 0x005899f0 ; FUN_005899f0 */

void FUN_005899f0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined auStack_94 [80];
  undefined auStack_44 [24];
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796e53;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01d59104 != '\0') {
    puVar2 = param_3;
    if (0xf < (uint)param_3[5]) {
      puVar2 = (undefined4 *)*param_3;
    }
    puVar3 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar3 = (undefined4 *)*param_2;
    }
    puStack_14 = param_1;
    if (0xf < (uint)param_1[5]) {
      puStack_14 = (undefined4 *)*param_1;
    }
    ExceptionList = &pvStack_10;
    FUN_01677520(DAT_01d59104,"Failed to execute script. Type = %s Error = %s json = [%s]",
                 puStack_14,puVar3,puVar2);
  }
  FUN_0054eff0("RCCFailedExecuteScriptRequest");
  uStack_8 = 0;
  FUN_008783f0(auStack_2c,1,1);
  uStack_8 = 0xffffffff;
  FUN_005507b0();
  uVar1 = FUN_005543f0();
  uVar1 = FUN_01675640(auStack_94,"RCCFailedExecuteScriptRequest-%s",uVar1);
  uStack_8 = 1;
  FUN_008783f0(uVar1,1,1);
  uStack_8 = 0xffffffff;
  FUN_005507b0();
  FUN_0151f6f0(0xffffffff,0,0);
  uStack_8 = 2;
  FUN_0151f950(&DAT_018bf030,param_1);
  FUN_0151f950("Error",param_2);
  FUN_0151f950("OriginalRequestJson",param_3);
  uVar1 = DAT_01e90d48;
  FUN_0054eff0("RCCExecuteScriptFailure");
  uStack_8._0_1_ = 3;
  FUN_01520d20(auStack_44,uVar1,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_005507b0();
  uVar1 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("ExecuteScript error: %s",uVar1);
}



/* FUNCTION 4026 ; VA 0x00589b60 ; FUN_00589b60 */

void FUN_00589b60(undefined4 param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796e78;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("RCCMalformedEvictPlayerRequest",0x1e);
  uStack_8 = 0;
  FUN_008783f0(auStack_28,1,0);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  FUN_0151f6f0(0xffffffff,0,0);
  uStack_8 = 1;
  FUN_0151f950("Error",param_1);
  uVar1 = DAT_01e90d40;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  FUN_005542c0("RCCFailedToEvictPlayer",0x16);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_01520d20(auStack_40,uVar1,0);
  if (0xf < uStack_2c) {
    uVar3 = uStack_2c + 1;
    uVar2 = auStack_40[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_40[0] - 4);
      uVar3 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  FUN_0151f7f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4027 ; VA 0x00589ca0 ; FUN_00589ca0 */

void FUN_00589ca0(undefined4 *param_1,double *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int aiStack_48 [5];
  uint uStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796ea0;
  pvStack_10 = ExceptionList;
  dStack_18 = *param_2 * DAT_018c0d70;
  puVar1 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar1 = (undefined4 *)*param_1;
  }
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675640(auStack_30,"%s_Soap_%s",PTR_DAT_01d593e8,puVar1);
  uStack_8 = 0;
  FUN_00878cf0(uVar2,dStack_18,0);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_1c) {
    if (0xfff < uStack_1c + 1) {
      if (0x1f < (auStack_30[0] - *(int *)(auStack_30[0] - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  dStack_18 = *param_2 * DAT_018c0d70;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  uVar2 = FUN_01675640(aiStack_48,"%s_Soap_%s_%d",PTR_DAT_01d593e8,param_1,DAT_01d7a884);
  uStack_8 = 1;
  FUN_00878cf0(uVar2,dStack_18,0);
  if (0xf < uStack_34) {
    uVar4 = uStack_34 + 1;
    iVar3 = aiStack_48[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_48[0] + -4);
      uVar4 = uStack_34 + 0x24;
      if (0x1f < (aiStack_48[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4028 ; VA 0x00589e10 ; FUN_00589e10 */

void FUN_00589e10(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int aiStack_58 [5];
  uint uStack_44;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796ed3;
  pvStack_10 = ExceptionList;
  puVar1 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar1 = (undefined4 *)*param_1;
  }
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675640(auStack_40,"%s_SoapException_%s",PTR_DAT_01d593e8,puVar1);
  uStack_8 = 0;
  FUN_008783f0(uVar2,1,0);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    uVar5 = auStack_40[0];
    if (0xfff < uVar4) {
      uVar5 = *(uint *)(auStack_40[0] - 4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar4);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  uVar2 = FUN_01675640(aiStack_58,"%s_SoapException_%s_%d",PTR_DAT_01d593e8,param_1,DAT_01d7a884);
  uStack_8 = 1;
  FUN_008783f0(uVar2,1,0);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_44) {
    uVar5 = uStack_44 + 1;
    iVar3 = aiStack_58[0];
    if (0xfff < uVar5) {
      iVar3 = *(int *)(aiStack_58[0] + -4);
      uVar5 = uStack_44 + 0x24;
      if (0x1f < (aiStack_58[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  FUN_0151f6f0(0xffffffff,0,0);
  uStack_8 = 2;
  FUN_0151f850("ServerName",PTR_DAT_01d593e8);
  FUN_0151f9c0("DataCenterId",DAT_01d7a884);
  FUN_0151f950("Exception",param_2);
  uVar2 = DAT_01d59134;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  FUN_005542c0("RCCSoapException",0x10);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_01520d20(auStack_28,uVar2,0);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar5 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar5 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar4);
  }
  FUN_0151f7f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4029 ; VA 0x0058a020 ; FUN_0058a020 */

void FUN_0058a020(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined auStack_94 [80];
  undefined auStack_44 [24];
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796e53;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01d59104 != '\0') {
    puVar2 = param_3;
    if (0xf < (uint)param_3[5]) {
      puVar2 = (undefined4 *)*param_3;
    }
    puVar3 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar3 = (undefined4 *)*param_2;
    }
    puStack_14 = param_1;
    if (0xf < (uint)param_1[5]) {
      puStack_14 = (undefined4 *)*param_1;
    }
    ExceptionList = &pvStack_10;
    FUN_01677520(DAT_01d59104,"Failed to generate thumbnail. Type = %s Error = %s json = [%s]",
                 puStack_14,puVar3,puVar2);
  }
  FUN_0054eff0("RCCFailedThumbnailRequest");
  uStack_8 = 0;
  FUN_008783f0(auStack_2c,1,1);
  uStack_8 = 0xffffffff;
  FUN_005507b0();
  uVar1 = FUN_005543f0();
  uVar1 = FUN_01675640(auStack_94,"RCCFailedThumbnailRequest-%s",uVar1);
  uStack_8 = 1;
  FUN_008783f0(uVar1,1,1);
  uStack_8 = 0xffffffff;
  FUN_005507b0();
  FUN_0151f6f0(0xffffffff,0,0);
  uStack_8 = 2;
  FUN_0151f950(&DAT_018bf030,param_1);
  FUN_0151f950("Error",param_2);
  FUN_0151f950("OriginalRequestJson",param_3);
  uVar1 = DAT_01e90d44;
  FUN_0054eff0("RCCThumbnailFailure");
  uStack_8._0_1_ = 3;
  FUN_01520d20(auStack_44,uVar1,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_005507b0();
  uVar1 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Thumbnailing error: %s",uVar1);
}



/* FUNCTION 4030 ; VA 0x0058a190 ; FUN_0058a190 */

void __thiscall FUN_0058a190(int *param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  
  uVar2 = param_1[4];
  if (uVar2 <= param_2) {
    uVar3 = param_1[5];
    if (uVar3 != param_2) {
      if (uVar3 < param_2) {
        if (0x7fffffff - uVar2 < param_2 - uVar2) {
          FUN_00554040();
LAB_0058a2a6:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
        uVar6 = param_2 | 0xf;
        if (uVar6 < 0x80000000) {
          if (0x7fffffff - (uVar3 >> 1) < uVar3) {
            uVar6 = 0x7fffffff;
          }
          else {
            uVar1 = (uVar3 >> 1) + uVar3;
            if (uVar6 < uVar1) {
              uVar6 = uVar1;
            }
          }
        }
        else {
          uVar6 = 0x7fffffff;
        }
        iVar5 = FUN_00554060(uVar6 + 1);
        param_1[5] = uVar6;
        param_1[4] = param_2;
        if (uVar3 < 0x10) {
          FUN_0170c6f0(iVar5,param_1,uVar2 + 1);
          *param_1 = iVar5;
          param_1[4] = uVar2;
          return;
        }
        iVar4 = *param_1;
        FUN_0170c6f0(iVar5,iVar4,uVar2 + 1);
        uVar6 = uVar3 + 1;
        iVar7 = iVar4;
        if (0xfff < uVar6) {
          iVar7 = *(int *)(iVar4 + -4);
          uVar6 = uVar3 + 0x24;
          if (0x1f < (iVar4 - iVar7) - 4U) goto LAB_0058a2a6;
        }
        FUN_01674ea0(iVar7,uVar6);
        *param_1 = iVar5;
        param_1[4] = uVar2;
        return;
      }
      if ((param_2 < 0x10) && (0xf < uVar3)) {
        FUN_005758e0();
      }
    }
  }
  return;
}



/* FUNCTION 4031 ; VA 0x0058a2b0 ; FUN_0058a2b0 */

void __fastcall FUN_0058a2b0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *param_1 = 0;
  piVar2 = (int *)param_1[1];
  param_1[1] = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0058a2e6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 4032 ; VA 0x0058a2f0 ; FUN_0058a2f0 */

void __thiscall FUN_0058a2f0(int *param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  if (piVar1 != (int *)0x0) {
    uStack_8 = 0;
    FUN_016899e0();
    puVar2 = (undefined4 *)*piVar1;
    if (puVar2 != (undefined4 *)0x0) {
      LOCK();
      iVar3 = puVar2[1] + -1;
      puVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*puVar2)(0);
        uVar4 = GetProcessHeap(0,puVar2);
        HeapFree(uVar4);
      }
    }
    FUN_01674ea0(piVar1,4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4033 ; VA 0x0058a370 ; FUN_0058a370 */

void __thiscall FUN_0058a370(undefined4 *param_1,uint param_2)

{
  uint *puVar1;
  
  puVar1 = param_1 + 4;
  if (param_2 <= *puVar1) {
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    *puVar1 = param_2;
    *(undefined *)((int)param_1 + param_2) = 0;
    return;
  }
  FUN_00578160();
  return;
}



/* FUNCTION 4034 ; VA 0x0058a39a ; FUN_0058a39a */

void FUN_0058a39a(void)

{
  FUN_0058a3b0();
  return;
}



/* FUNCTION 4035 ; VA 0x0058a3b0 ; FUN_0058a3b0 */

void __fastcall FUN_0058a3b0(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00565c60(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c1e50c);
}



/* FUNCTION 4036 ; VA 0x0058a3d3 ; FUN_0058a3d3 */

void FUN_0058a3d3(void)

{
  FUN_0058a3e0();
  return;
}



/* FUNCTION 4037 ; VA 0x0058a3e0 ; FUN_0058a3e0 */

void __fastcall FUN_0058a3e0(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00565d40(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c1eae8);
}



/* FUNCTION 4038 ; VA 0x0058a403 ; FUN_0058a403 */

void FUN_0058a403(void)

{
  FUN_0058a410();
  return;
}



/* FUNCTION 4039 ; VA 0x0058a410 ; FUN_0058a410 */

void __fastcall FUN_0058a410(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00565e20(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c1eb70);
}



/* FUNCTION 4040 ; VA 0x0058a433 ; FUN_0058a433 */

void FUN_0058a433(void)

{
  FUN_0058a440();
  return;
}



/* FUNCTION 4041 ; VA 0x0058a440 ; FUN_0058a440 */

void __fastcall FUN_0058a440(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00565f00(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c1e62c);
}



/* FUNCTION 4042 ; VA 0x0058a463 ; FUN_0058a463 */

void FUN_0058a463(void)

{
  FUN_0058a470();
  return;
}



/* FUNCTION 4043 ; VA 0x0058a470 ; FUN_0058a470 */

void __fastcall FUN_0058a470(int param_1)

{
  undefined auStack_38 [52];
  
  FUN_00565fe0(param_1 + -0x30,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_38,&DAT_01c1e890);
}



/* FUNCTION 4044 ; VA 0x0058a493 ; FUN_0058a493 */

void FUN_0058a493(void)

{
  FUN_0058a4a0();
  return;
}



/* FUNCTION 4045 ; VA 0x0058a4a0 ; FUN_0058a4a0 */

void __fastcall FUN_0058a4a0(int param_1)

{
  undefined auStack_38 [52];
  
  FUN_005660d0(param_1 + -0x30,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_38,&DAT_01c1ea60);
}



/* FUNCTION 4046 ; VA 0x0058a4c3 ; FUN_0058a4c3 */

void FUN_0058a4c3(void)

{
  FUN_0058a4d0();
  return;
}



/* FUNCTION 4047 ; VA 0x0058a4d0 ; FUN_0058a4d0 */

void __fastcall FUN_0058a4d0(int param_1)

{
  undefined auStack_50 [76];
  
  FUN_005661c0(param_1 + -0x48,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_50,&DAT_01c1e918);
}



/* FUNCTION 4048 ; VA 0x0058a4f3 ; FUN_0058a4f3 */

void FUN_0058a4f3(void)

{
  FUN_0058a500();
  return;
}



/* FUNCTION 4049 ; VA 0x0058a500 ; FUN_0058a500 */

void __fastcall FUN_0058a500(int param_1)

{
  undefined auStack_38 [52];
  
  FUN_00566250(param_1 + -0x30,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_38,&DAT_01c1e6ac);
}



/* FUNCTION 4050 ; VA 0x0058a523 ; FUN_0058a523 */

void FUN_0058a523(void)

{
  FUN_0058a530();
  return;
}



/* FUNCTION 4051 ; VA 0x0058a530 ; FUN_0058a530 */

void __fastcall FUN_0058a530(int param_1)

{
  undefined auStack_38 [52];
  
  FUN_00566340(param_1 + -0x30,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_38,&DAT_01c1e808);
}



/* FUNCTION 4052 ; VA 0x0058a553 ; FUN_0058a553 */

void FUN_0058a553(void)

{
  FUN_0058a560();
  return;
}



/* FUNCTION 4053 ; VA 0x0058a560 ; FUN_0058a560 */

void __fastcall FUN_0058a560(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00566430(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c1f0b0);
}



/* FUNCTION 4054 ; VA 0x0058a583 ; FUN_0058a583 */

void FUN_0058a583(void)

{
  FUN_0058a590();
  return;
}



/* FUNCTION 4055 ; VA 0x0058a590 ; FUN_0058a590 */

void __fastcall FUN_0058a590(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00566510(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c1f114);
}



/* FUNCTION 4056 ; VA 0x0058a5b3 ; FUN_0058a5b3 */

void FUN_0058a5b3(void)

{
  FUN_0058a5c0();
  return;
}



/* FUNCTION 4057 ; VA 0x0058a5c0 ; FUN_0058a5c0 */

void __fastcall FUN_0058a5c0(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_005665f0(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c1f1f8);
}



/* FUNCTION 4058 ; VA 0x0058a5e3 ; FUN_0058a5e3 */

void FUN_0058a5e3(void)

{
  FUN_0058a5f0();
  return;
}



/* FUNCTION 4059 ; VA 0x0058a5f0 ; FUN_0058a5f0 */

void __fastcall FUN_0058a5f0(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_005666d0(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c1f178);
}



/* FUNCTION 4060 ; VA 0x0058a613 ; FUN_0058a613 */

void FUN_0058a613(void)

{
  FUN_0058a620();
  return;
}



/* FUNCTION 4061 ; VA 0x0058a620 ; FUN_0058a620 */

void __fastcall FUN_0058a620(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_005667b0(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c1ebf8);
}



/* FUNCTION 4062 ; VA 0x0058a643 ; FUN_0058a643 */

void FUN_0058a643(void)

{
  FUN_0058a650();
  return;
}



/* FUNCTION 4063 ; VA 0x0058a650 ; FUN_0058a650 */

void __fastcall FUN_0058a650(int param_1)

{
  undefined auStack_38 [52];
  
  FUN_00566890(param_1 + -0x30,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_38,&DAT_01c1efdc);
}



/* FUNCTION 4064 ; VA 0x0058a673 ; FUN_0058a673 */

void FUN_0058a673(void)

{
  FUN_0058a680();
  return;
}



/* FUNCTION 4065 ; VA 0x0058a680 ; FUN_0058a680 */

void __fastcall FUN_0058a680(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00566980(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c1ec7c);
}



/* FUNCTION 4066 ; VA 0x0058a6a3 ; FUN_0058a6a3 */

void FUN_0058a6a3(void)

{
  FUN_0058a6b0();
  return;
}



/* FUNCTION 4067 ; VA 0x0058a6b0 ; FUN_0058a6b0 */

void __fastcall FUN_0058a6b0(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00566a60(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c1ed00);
}



/* FUNCTION 4068 ; VA 0x0058a6d3 ; FUN_0058a6d3 */

void FUN_0058a6d3(void)

{
  FUN_0058a6e0();
  return;
}



/* FUNCTION 4069 ; VA 0x0058a6e0 ; FUN_0058a6e0 */

void __fastcall FUN_0058a6e0(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00566b40(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c1edec);
}



/* FUNCTION 4070 ; VA 0x0058a703 ; FUN_0058a703 */

void FUN_0058a703(void)

{
  FUN_0058a710();
  return;
}



/* FUNCTION 4071 ; VA 0x0058a710 ; FUN_0058a710 */

void __fastcall FUN_0058a710(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00566c20(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c1ed84);
}



/* FUNCTION 4072 ; VA 0x0058a733 ; FUN_0058a733 */

void FUN_0058a733(void)

{
  FUN_0058a740();
  return;
}



/* FUNCTION 4073 ; VA 0x0058a740 ; FUN_0058a740 */

void __fastcall FUN_0058a740(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00566d00(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c1eed4);
}



/* FUNCTION 4074 ; VA 0x0058a763 ; FUN_0058a763 */

void FUN_0058a763(void)

{
  FUN_0058a770();
  return;
}



/* FUNCTION 4075 ; VA 0x0058a770 ; FUN_0058a770 */

void __fastcall FUN_0058a770(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00566de0(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c1ee50);
}



/* FUNCTION 4076 ; VA 0x0058a793 ; FUN_0058a793 */

void FUN_0058a793(void)

{
  FUN_0058a7a0();
  return;
}



/* FUNCTION 4077 ; VA 0x0058a7a0 ; FUN_0058a7a0 */

void __fastcall FUN_0058a7a0(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00566ec0(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c1f04c);
}



/* FUNCTION 4078 ; VA 0x0058a7c3 ; FUN_0058a7c3 */

void FUN_0058a7c3(void)

{
  FUN_0058a7d0();
  return;
}



/* FUNCTION 4079 ; VA 0x0058a7d0 ; FUN_0058a7d0 */

void __fastcall FUN_0058a7d0(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00566fa0(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c1ef58);
}



/* FUNCTION 4080 ; VA 0x0058a7f3 ; FUN_0058a7f3 */

void FUN_0058a7f3(void)

{
  FUN_0058a800();
  return;
}



/* FUNCTION 4081 ; VA 0x0058a800 ; FUN_0058a800 */

void __fastcall FUN_0058a800(int param_1)

{
  undefined auStack_24 [32];
  
  FUN_00567080(param_1 + -0x1c,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_24,&DAT_01c1e788);
}



/* FUNCTION 4082 ; VA 0x0058a823 ; FUN_0058a823 */

void FUN_0058a823(void)

{
  FUN_0058a830();
  return;
}



/* FUNCTION 4083 ; VA 0x0058a830 ; FUN_0058a830 */

void __fastcall FUN_0058a830(int param_1)

{
  undefined auStack_38 [52];
  
  FUN_00567100(param_1 + -0x30,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_38,&DAT_01c1ea00);
}



/* FUNCTION 4084 ; VA 0x0058a853 ; FUN_0058a853 */

void FUN_0058a853(void)

{
  FUN_0058a860();
  return;
}



/* FUNCTION 4085 ; VA 0x0058a860 ; FUN_0058a860 */

void __fastcall FUN_0058a860(int param_1)

{
  undefined auStack_1c [24];
  
  FUN_005671c0(param_1 + -0x14,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c1e9a4);
}



/* FUNCTION 4086 ; VA 0x0058a883 ; FUN_0058a883 */

void FUN_0058a883(void)

{
  FUN_0058a890();
  return;
}



/* FUNCTION 4087 ; VA 0x0058a890 ; FUN_0058a890 */

void __fastcall FUN_0058a890(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00567230(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c1e5cc);
}



/* FUNCTION 4088 ; VA 0x0058a8c0 ; FUN_0058a8c0 */

void FUN_0058a8c0(void)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_0054db20();
  (**(code **)(*piVar1 + 4))();
  FUN_0171d6f3();
  return;
}



/* FUNCTION 4089 ; VA 0x0058a8e0 ; FUN_0058a8e0 */

void FUN_0058a8e0(undefined4 *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  
  LOCK();
  *param_1 = 0;
  UNLOCK();
  iVar2 = *(int *)(param_2 + 0xc);
  if (iVar2 == 0) {
    if (*(char *)(param_2 + 0x10) == '\0') {
      FUN_005881c0(param_2 + 0x10,param_1);
    }
    iVar2 = OpenEventA(0x100002,0,param_2 + 0x10);
    iVar1 = *(int *)(param_2 + 0xc);
    if ((iVar1 != 0) && (iVar1 != -1)) {
      CloseHandle(iVar1);
    }
    *(int *)(param_2 + 0xc) = iVar2;
    if (iVar2 == 0) {
      return;
    }
  }
  SetEvent(iVar2);
  return;
}



/* FUNCTION 4090 ; VA 0x0058a940 ; FUN_0058a940 */

void __fastcall FUN_0058a940(int param_1)

{
  (**(code **)(param_1 + 0x40))
            (param_1 + 0x48,param_1 + 0x60,*(undefined4 *)(param_1 + 0x68),
             *(undefined4 *)(param_1 + 0x6c),param_1 + 0x70,param_1 + 0x88,
             *(undefined4 *)(param_1 + 0x90),*(undefined4 *)(param_1 + 0x94));
  return;
}



/* FUNCTION 4091 ; VA 0x0058a970 ; FUN_0058a970 */

void __fastcall FUN_0058a970(int param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792078;
  pvStack_10 = ExceptionList;
  if (*(uint *)(param_1 + 0x40) != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)((*(uint *)(param_1 + 0x40) & 0xfffffffe) + 4))(param_1 + 0x48);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0054fda0();
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar1);
}



/* FUNCTION 4092 ; VA 0x0058a9d0 ; FUN_0058a9d0 */

void FUN_0058a9d0(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  undefined auStack_9c [12];
  undefined **appuStack_90 [2];
  undefined uStack_88;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  undefined4 uStack_68;
  undefined8 uStack_60;
  undefined4 uStack_58;
  int *piStack_50;
  undefined **ppuStack_4c;
  uint *puStack_48;
  undefined4 *puStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined **ppuStack_38;
  undefined ***pppuStack_34;
  undefined ***pppuStack_30;
  undefined4 uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01796f1d;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar1 = (int *)FUN_01674e20(0x17658);
  uStack_8._0_1_ = 1;
  piStack_50 = piVar1;
  if (piVar1 == (int *)0x0) {
    piVar1 = (int *)0x0;
  }
  else {
    FUN_0170d1f0(piVar1,0,0x17658);
    FUN_005be850();
    *piVar1 = (int)_anon_5DAC6851::ExceptionAwareSoap<class_RCCServiceSoapService>::vftable;
  }
  uStack_8._0_1_ = 0;
  FUN_005b3080(piVar1,&DAT_01e90d84);
  if (piVar1 != (int *)0x0) {
    appuStack_90[0] = ns1__Job::vftable;
    uStack_78 = 0;
    uStack_74 = 0xf;
    uStack_88 = 0;
    uStack_70 = 0;
    uStack_68 = 0;
    uStack_60 = 0;
    uStack_58 = 0;
    uStack_8._0_1_ = 2;
    FUN_005542c0(&DAT_018bfd6c,4);
    uStack_70 = DAT_018c0d68;
    ppuStack_4c = ns1__ScriptExecution::vftable;
    puStack_48 = (uint *)0x0;
    puStack_44 = (undefined4 *)0x0;
    uStack_40 = 0;
    uStack_3c = 0;
    uStack_8._0_1_ = 3;
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("Batch Job",9);
    puStack_48 = auStack_28;
    ppuStack_38 = _ns1__BatchJob::vftable;
    puStack_44 = &param_1;
    uStack_2c = 0;
    pppuStack_30 = &ppuStack_4c;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pppuStack_34 = appuStack_90;
    (**(code **)(*piVar1 + 0x68))(&ppuStack_38,in_stack_0000001c);
    ppuStack_38 = _ns1__BatchJob::vftable;
    if (0xf < uStack_14) {
      uVar4 = uStack_14 + 1;
      uVar5 = auStack_28[0];
      if (0xfff < uVar4) {
        uVar5 = *(uint *)(auStack_28[0] - 4);
        uVar4 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar4);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    ppuStack_4c = ns1__ScriptExecution::vftable;
    FUN_0056e940();
    if (0xf < in_stack_00000018) {
      uVar5 = in_stack_00000018 + 1;
      iVar3 = param_1;
      if (0xfff < uVar5) {
        iVar3 = *(int *)(param_1 + -4);
        uVar5 = in_stack_00000018 + 0x24;
        if (0x1f < (param_1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar5);
    }
    ExceptionList = pvStack_10;
    return;
  }
  puVar2 = (undefined4 *)FUN_005ace30(&DAT_01e90d84);
  FUN_00550130(*puVar2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_9c,&DAT_01c17198);
}



/* FUNCTION 4093 ; VA 0x0058abf0 ; FUN_0058abf0 */

void FUN_0058abf0(int param_1)

{
  undefined4 *puVar1;
  undefined3 uVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  undefined4 ****ppppuVar9;
  undefined4 ****ppppuVar10;
  uint uVar11;
  longlong lVar12;
  undefined auStack_234 [120];
  int iStack_1bc;
  uint uStack_1b0;
  undefined auStack_1ac [40];
  int aiStack_184 [9];
  int iStack_160;
  undefined auStack_104 [24];
  undefined auStack_ec [24];
  undefined auStack_d4 [24];
  undefined auStack_bc [24];
  undefined auStack_a4 [8];
  undefined auStack_9c [8];
  undefined4 uStack_94;
  undefined auStack_90 [4];
  undefined auStack_8c [8];
  undefined **ppuStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined auStack_70 [4];
  undefined auStack_6c [4];
  undefined4 ***pppuStack_68;
  undefined4 **ppuStack_64;
  undefined4 **ppuStack_60;
  undefined4 **ppuStack_5c;
  undefined8 uStack_58;
  undefined auStack_50 [4];
  undefined auStack_4c [4];
  undefined4 uStack_48;
  undefined4 ***pppuStack_38;
  undefined4 **ppuStack_34;
  undefined4 **ppuStack_30;
  undefined4 **ppuStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  undefined auStack_1c [4];
  undefined4 uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796ff3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_01e90d74);
  uStack_58 = 0xf00000000;
  pppuStack_68 = (undefined4 ***)((uint)pppuStack_68 & 0xffffff00);
  uStack_8._1_3_ = 0;
  uVar2 = uStack_8._1_3_;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uStack_94 = uVar4;
  if (*(int *)(param_1 + 0x18) != 0) {
    FUN_00565940(3,1);
    uStack_8._0_1_ = 2;
    FUN_00564d90(param_1 + 8,1,0x40,1);
    uStack_8._0_1_ = 3;
    if (iStack_160 != 0) {
      FUN_0056f130(auStack_1ac);
      iVar5 = FUN_005548a0();
      if (iVar5 == 0) {
        FUN_00554460((uint)(*(int *)((int)aiStack_184 + *(int *)(iStack_1bc + 4)) == 0) * 4 + 2 |
                     *(uint *)((int)&uStack_1b0 + *(int *)(iStack_1bc + 4)),0);
      }
    }
    FUN_0058c420(&pppuStack_38);
    FUN_005507b0();
    pppuStack_68 = pppuStack_38;
    ppuStack_64 = ppuStack_34;
    ppuStack_60 = ppuStack_30;
    ppuStack_5c = ppuStack_2c;
    uStack_58 = CONCAT44(uStack_24,uStack_28);
    FUN_00551650();
    uStack_8._0_1_ = 1;
    FUN_005705c0();
    uVar2 = uStack_8._1_3_;
  }
  uStack_8._1_3_ = uVar2;
  if (DAT_01d592f0 != '\0') {
    FUN_0167e960();
    uStack_8._0_1_ = 4;
    uVar6 = FUN_016819e0(auStack_90,&pppuStack_68);
    uStack_8._0_1_ = 5;
    FUN_0167ed10(uVar6);
    uStack_8._0_1_ = 4;
    FUN_0167ec40();
    cVar3 = FUN_016816d0();
    if (cVar3 != '\0') {
      FUN_016756b0(auStack_90,"Failed to parse console JSON");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_90,&DAT_01c17198);
    }
    FUN_0167e9f0();
    uStack_8._0_1_ = 6;
    FUN_01681c30();
    FUN_01681890(auStack_6c);
    FUN_01680ec0(auStack_20);
    uStack_8._0_1_ = 7;
    FUN_01681160(auStack_50);
    uStack_8._0_1_ = 8;
    cVar3 = FUN_0167ed80(auStack_50);
    while (cVar3 != '\0') {
      uStack_18 = FUN_0054eb90();
      puVar7 = (undefined4 *)FUN_01681970(&pppuStack_38);
      puVar1 = puVar7 + 4;
      if (0xf < (uint)puVar7[5]) {
        puVar7 = (undefined4 *)*puVar7;
      }
      cStack_11 = FUN_0055c360(puVar7,*puVar1,"Settings",8);
      if (0xf < uStack_24) {
        uVar11 = uStack_24 + 1;
        ppppuVar9 = (undefined4 ****)pppuStack_38;
        if (0xfff < uVar11) {
          ppppuVar9 = (undefined4 ****)pppuStack_38[-1];
          uVar11 = uStack_24 + 0x24;
          if (0x1f < (uint)((int)pppuStack_38 + (-4 - (int)ppppuVar9))) goto LAB_0058b49f;
        }
        FUN_01674ea0(ppppuVar9,uVar11);
      }
      if (cStack_11 == '\0') {
        uVar6 = FUN_01682680(auStack_8c);
        uVar8 = FUN_01681970(&pppuStack_38);
        uStack_8._0_1_ = 0x17;
        FUN_016826d0(uVar8,uVar6);
        uStack_8._0_1_ = 8;
        if (0xf < uStack_24) {
          uVar11 = uStack_24 + 1;
          ppppuVar9 = (undefined4 ****)pppuStack_38;
          if (0xfff < uVar11) {
            ppppuVar9 = (undefined4 ****)pppuStack_38[-1];
            uVar11 = uStack_24 + 0x24;
            if (0x1f < (uint)((int)pppuStack_38 + (-4 - (int)ppppuVar9))) goto LAB_0058b49f;
          }
          FUN_01674ea0(ppppuVar9,uVar11);
        }
      }
      else {
        FUN_01681d10("Settings");
        FUN_01681c30();
        FUN_01682680(auStack_9c);
        FUN_01681890(auStack_70);
        FUN_01680ec0(auStack_1c);
        uStack_8._0_1_ = 9;
        FUN_01681160(auStack_4c);
        uStack_8._0_1_ = 10;
        cVar3 = FUN_0167ed80(auStack_4c);
        while (cVar3 != '\0') {
          uStack_48 = FUN_0054eb90();
          puVar7 = (undefined4 *)FUN_01681970(&pppuStack_38);
          puVar1 = puVar7 + 4;
          if (0xf < (uint)puVar7[5]) {
            puVar7 = (undefined4 *)*puVar7;
          }
          cStack_11 = FUN_0055c360(puVar7,*puVar1,"PlaceId",7);
          if (0xf < uStack_24) {
            uVar11 = uStack_24 + 1;
            ppppuVar9 = (undefined4 ****)pppuStack_38;
            if (0xfff < uVar11) {
              ppppuVar9 = (undefined4 ****)pppuStack_38[-1];
              uVar11 = uStack_24 + 0x24;
              if (0x1f < (uint)((int)pppuStack_38 + (-4 - (int)ppppuVar9))) goto LAB_0058b49f;
            }
            FUN_01674ea0(ppppuVar9,uVar11);
          }
          if (cStack_11 == '\0') {
            puVar7 = (undefined4 *)FUN_01681970(&pppuStack_38);
            puVar1 = puVar7 + 4;
            if (0xf < (uint)puVar7[5]) {
              puVar7 = (undefined4 *)*puVar7;
            }
            cStack_11 = FUN_0055c360(puVar7,*puVar1,"PlaceFetchUrl",0xd);
            if (0xf < uStack_24) {
              uVar11 = uStack_24 + 1;
              ppppuVar9 = (undefined4 ****)pppuStack_38;
              if (0xfff < uVar11) {
                ppppuVar9 = (undefined4 ****)pppuStack_38[-1];
                uVar11 = uStack_24 + 0x24;
                if (0x1f < (uint)((int)pppuStack_38 + (-4 - (int)ppppuVar9))) goto LAB_0058b49f;
              }
              FUN_01674ea0(ppppuVar9,uVar11);
            }
            if (cStack_11 == '\0') {
              puVar7 = (undefined4 *)FUN_01681970(&pppuStack_38);
              puVar1 = puVar7 + 4;
              if (0xf < (uint)puVar7[5]) {
                puVar7 = (undefined4 *)*puVar7;
              }
              cStack_11 = FUN_0055c360(puVar7,*puVar1,"UniverseId",10);
              if (0xf < uStack_24) {
                uVar11 = uStack_24 + 1;
                ppppuVar9 = (undefined4 ****)pppuStack_38;
                if (0xfff < uVar11) {
                  ppppuVar9 = (undefined4 ****)pppuStack_38[-1];
                  uVar11 = uStack_24 + 0x24;
                  if (0x1f < (uint)((int)pppuStack_38 + (-4 - (int)ppppuVar9))) goto LAB_0058b49f;
                }
                FUN_01674ea0(ppppuVar9,uVar11);
              }
              if (cStack_11 != '\0') {
                lVar12 = FUN_01678fc0("UniverseId");
                uStack_18 = (undefined4)((ulonglong)lVar12 >> 0x20);
                if (lVar12 != 0) {
                  if (DAT_01d59104 != '\0') {
                    FUN_01677520(DAT_01d59104,"Overriding UniverseId to %lld",lVar12);
                  }
                  FUN_016816e0("UniverseId",(int)lVar12,uStack_18);
                  goto LAB_0058b1ff;
                }
              }
            }
            else {
              lVar12 = FUN_01678fc0("PlaceId");
              if (lVar12 != 0) {
                uVar6 = FUN_01675640(auStack_104,"/v1/asset/?id=%lld",lVar12);
                uStack_8._0_1_ = 0xb;
                uVar8 = FUN_0151b370();
                uVar8 = FUN_0151f2f0(auStack_ec,uVar8);
                uStack_8._0_1_ = 0xc;
                uVar8 = FUN_0151b590(auStack_d4,uVar8,"assetdelivery");
                uStack_8._0_1_ = 0xd;
                puVar7 = (undefined4 *)FUN_00558ba0(auStack_bc,uVar8,uVar6);
                puVar1 = puVar7 + 4;
                uStack_8._0_1_ = 0xe;
                if (0xf < (uint)puVar7[5]) {
                  puVar7 = (undefined4 *)*puVar7;
                }
                FUN_0151bda0(auStack_234,puVar7,*puVar1);
                uStack_8._0_1_ = 0xf;
                FUN_0151bb70(&pppuStack_38);
                FUN_0056d9d0();
                FUN_005507b0();
                FUN_005507b0();
                FUN_005507b0();
                uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
                FUN_005507b0();
                if (DAT_01d59104 != '\0') {
                  ppppuVar9 = &pppuStack_38;
                  if (0xf < uStack_24) {
                    ppppuVar9 = (undefined4 ****)pppuStack_38;
                  }
                  FUN_01677520(DAT_01d59104,"Overriding PlaceFetchUrl to %s",ppppuVar9);
                }
                FUN_01681e50("PlaceFetchUrl",&pppuStack_38);
                uStack_8._0_1_ = 10;
                FUN_005507b0();
                goto LAB_0058b1ff;
              }
            }
LAB_0058b19d:
            uVar6 = FUN_01682680(auStack_a4);
            uVar8 = FUN_01681970(&pppuStack_38);
            uStack_8._0_1_ = 0x16;
            FUN_016826d0(uVar8,uVar6);
            uStack_8._0_1_ = 10;
            if (0xf < uStack_24) {
              uVar11 = uStack_24 + 1;
              ppppuVar9 = (undefined4 ****)pppuStack_38;
              if (0xfff < uVar11) {
                ppppuVar9 = (undefined4 ****)pppuStack_38[-1];
                uVar11 = uStack_24 + 0x24;
                if (0x1f < (uint)((int)pppuStack_38 + (-4 - (int)ppppuVar9))) goto LAB_0058b49f;
              }
              FUN_01674ea0(ppppuVar9,uVar11);
            }
          }
          else {
            lVar12 = FUN_01678fc0("PlaceId");
            uStack_18 = (undefined4)((ulonglong)lVar12 >> 0x20);
            if (lVar12 == 0) goto LAB_0058b19d;
            if (DAT_01d59104 != '\0') {
              FUN_01677520(DAT_01d59104,"Overriding PlaceId to %lld",lVar12);
            }
            FUN_016816e0("PlaceId",(int)lVar12,uStack_18);
          }
LAB_0058b1ff:
          FUN_0167f080();
          cVar3 = FUN_0167ed80(auStack_4c);
        }
        FUN_005c4aa0();
        uStack_8._0_1_ = 8;
        FUN_005c4aa0();
        FUN_01681200();
      }
      FUN_0167f080();
      cVar3 = FUN_0167ed80(auStack_50);
    }
    FUN_005c4aa0();
    uStack_8._0_1_ = 6;
    FUN_005c4aa0();
    FUN_01681200();
    ppppuVar9 = (undefined4 ****)FUN_01681c50(&pppuStack_38);
    if (&pppuStack_68 != ppppuVar9) {
      if (0xf < uStack_58._4_4_) {
        uVar11 = uStack_58._4_4_ + 1;
        ppppuVar10 = (undefined4 ****)pppuStack_68;
        if (0xfff < uVar11) {
          ppppuVar10 = (undefined4 ****)pppuStack_68[-1];
          uVar11 = uStack_58._4_4_ + 0x24;
          if (0x1f < (uint)((int)pppuStack_68 + (-4 - (int)ppppuVar10))) {
LAB_0058b49f:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(ppppuVar10,uVar11);
      }
      pppuStack_68 = *ppppuVar9;
      ppuStack_64 = ppppuVar9[1];
      ppuStack_60 = ppppuVar9[2];
      ppuStack_5c = ppppuVar9[3];
      uStack_58 = *(undefined8 *)(ppppuVar9 + 4);
      ppppuVar9[4] = (undefined4 ***)0x0;
      ppppuVar9[5] = (undefined4 ***)0xf;
      *(undefined *)ppppuVar9 = 0;
    }
    if (0xf < uStack_24) {
      uVar11 = uStack_24 + 1;
      ppppuVar9 = (undefined4 ****)pppuStack_38;
      if (0xfff < uVar11) {
        ppppuVar9 = (undefined4 ****)pppuStack_38[-1];
        uVar11 = uStack_24 + 0x24;
        if (0x1f < (uint)((int)pppuStack_38 + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar9,uVar11);
    }
    FUN_0167ec80();
    FUN_0167ec40();
  }
  uStack_80 = 0;
  uStack_7c = 0;
  uStack_78 = 0;
  uStack_74 = 0;
  if (*(char *)(param_1 + 0x38) == '\0') {
    ppuStack_84 = _ns1__OpenJobResponse::vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
    FUN_0054ef60(&pppuStack_68);
    FUN_0058b4b0();
    FUN_00581f30(param_1,&uStack_80);
    FUN_0056e6b0();
  }
  else {
    ppuStack_84 = _ns1__BatchJobResponse::vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
    FUN_0054ef60(&pppuStack_68);
    FUN_0058a9d0();
    FUN_00581f30(param_1,&uStack_80);
    FUN_0056e640();
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_58._4_4_) {
    uVar11 = uStack_58._4_4_ + 1;
    ppppuVar9 = (undefined4 ****)pppuStack_68;
    if (0xfff < uVar11) {
      ppppuVar9 = (undefined4 ****)pppuStack_68[-1];
      uVar11 = uStack_58._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppuStack_68 + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar9,uVar11);
  }
  uStack_58 = 0xf00000000;
  pppuStack_68 = (undefined4 ***)((uint)pppuStack_68 & 0xffffff00);
  uStack_8 = 0x1a;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4094 ; VA 0x0058b4b0 ; FUN_0058b4b0 */

void FUN_0058b4b0(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  undefined auStack_9c [12];
  undefined **appuStack_90 [2];
  undefined uStack_88;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined8 uStack_70;
  undefined4 uStack_68;
  undefined8 uStack_60;
  undefined4 uStack_58;
  int *piStack_50;
  undefined **ppuStack_4c;
  uint *puStack_48;
  undefined4 *puStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined **ppuStack_38;
  undefined ***pppuStack_34;
  undefined ***pppuStack_30;
  undefined4 uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179703d;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar1 = (int *)FUN_01674e20(0x17658);
  uStack_8._0_1_ = 1;
  piStack_50 = piVar1;
  if (piVar1 == (int *)0x0) {
    piVar1 = (int *)0x0;
  }
  else {
    FUN_0170d1f0(piVar1,0,0x17658);
    FUN_005be850();
    *piVar1 = (int)_anon_5DAC6851::ExceptionAwareSoap<class_RCCServiceSoapService>::vftable;
  }
  uStack_8._0_1_ = 0;
  FUN_005b3080(piVar1,&DAT_01e90d84);
  if (piVar1 != (int *)0x0) {
    appuStack_90[0] = ns1__Job::vftable;
    uStack_78 = 0;
    uStack_74 = 0xf;
    uStack_88 = 0;
    uStack_70 = 0;
    uStack_68 = 0;
    uStack_60 = 0;
    uStack_58 = 0;
    uStack_8._0_1_ = 2;
    FUN_005542c0(&DAT_018bfd6c,4);
    uStack_70 = DAT_018c0d68;
    ppuStack_4c = ns1__ScriptExecution::vftable;
    puStack_48 = (uint *)0x0;
    puStack_44 = (undefined4 *)0x0;
    uStack_40 = 0;
    uStack_3c = 0;
    uStack_8._0_1_ = 3;
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("Start Server",0xc);
    puStack_48 = auStack_28;
    ppuStack_38 = _ns1__OpenJob::vftable;
    puStack_44 = &param_1;
    uStack_2c = 0;
    pppuStack_30 = &ppuStack_4c;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    pppuStack_34 = appuStack_90;
    (**(code **)(*piVar1 + 0x50))(&ppuStack_38,in_stack_0000001c);
    ppuStack_38 = _ns1__OpenJob::vftable;
    if (0xf < uStack_14) {
      uVar4 = uStack_14 + 1;
      uVar5 = auStack_28[0];
      if (0xfff < uVar4) {
        uVar5 = *(uint *)(auStack_28[0] - 4);
        uVar4 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar4);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    ppuStack_4c = ns1__ScriptExecution::vftable;
    FUN_0056e940();
    if (0xf < in_stack_00000018) {
      uVar5 = in_stack_00000018 + 1;
      iVar3 = param_1;
      if (0xfff < uVar5) {
        iVar3 = *(int *)(param_1 + -4);
        uVar5 = in_stack_00000018 + 0x24;
        if (0x1f < (param_1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar5);
    }
    ExceptionList = pvStack_10;
    return;
  }
  puVar2 = (undefined4 *)FUN_005ace30(&DAT_01e90d84);
  FUN_00550130(*puVar2);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_9c,&DAT_01c17198);
}



/* FUNCTION 4095 ; VA 0x0058b6d0 ; FUN_0058b6d0 */

void __thiscall
FUN_0058b6d0(int param_1,uint *param_2,uint param_3,int param_4,int param_5,byte param_6)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  uint uStack_20;
  uint uStack_1c;
  
  iVar1 = **(int **)(param_1 + 0x1c);
  uVar2 = **(uint **)(param_1 + 0x20);
  if ((uVar2 != 0) && (*(uint *)(param_1 + 0x38) < uVar2)) {
    *(uint *)(param_1 + 0x38) = uVar2;
  }
  iVar3 = **(int **)(param_1 + 0xc);
  iVar4 = *(int *)(param_1 + 0x38);
  uVar5 = iVar4 - iVar3;
  uVar8 = (int)uVar5 >> 0x1f;
  if (param_5 == 0) {
    uStack_1c = 0;
    uStack_20 = 0;
LAB_0058b782:
    uVar9 = uStack_20 + param_3;
    uVar6 = uStack_1c + param_4 + (uint)CARRY4(uStack_20,param_3);
    if (((uVar6 < uVar8) || ((uVar6 <= uVar8 && (uVar9 <= uVar5)))) &&
       ((uVar9 == 0 && uVar6 == 0 ||
        ((((param_6 & 1) == 0 || (iVar1 != 0)) && (((param_6 & 2) == 0 || (uVar2 != 0)))))))) {
      iVar7 = iVar3 + uVar9;
      if (((param_6 & 1) != 0) && (iVar1 != 0)) {
        **(int **)(param_1 + 0x1c) = iVar7;
        **(int **)(param_1 + 0x2c) = iVar4 - iVar7;
      }
      if (((param_6 & 2) != 0) && (uVar2 != 0)) {
        iVar1 = **(int **)(param_1 + 0x30);
        iVar4 = **(int **)(param_1 + 0x20);
        **(int **)(param_1 + 0x10) = iVar3;
        **(int **)(param_1 + 0x20) = iVar7;
        **(int **)(param_1 + 0x30) = (iVar1 + iVar4) - iVar7;
      }
      *param_2 = uVar9;
      param_2[1] = uVar6;
      goto LAB_0058b80b;
    }
  }
  else if (param_5 == 1) {
    if ((param_6 & 3) != 3) {
      if ((param_6 & 1) == 0) {
        if (((param_6 & 2) != 0) && ((uVar2 != 0 || (iVar3 == 0)))) {
          uStack_1c = (int)(uVar2 - iVar3) >> 0x1f;
          uStack_20 = uVar2 - iVar3;
          goto LAB_0058b782;
        }
      }
      else if ((iVar1 != 0) || (iVar3 == 0)) {
        uStack_1c = iVar1 - iVar3 >> 0x1f;
        uStack_20 = iVar1 - iVar3;
        goto LAB_0058b782;
      }
    }
  }
  else {
    uStack_1c = uVar8;
    uStack_20 = uVar5;
    if (param_5 == 2) goto LAB_0058b782;
  }
  *param_2 = 0xffffffff;
  param_2[1] = 0xffffffff;
LAB_0058b80b:
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  param_2[5] = 0;
  return;
}



/* FUNCTION 4096 ; VA 0x0058b830 ; FUN_0058b830 */

void __thiscall
FUN_0058b830(int param_1,uint *param_2,uint param_3,int param_4,uint param_5,int param_6,
            undefined4 param_7,undefined4 param_8,uint param_9)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  
  uVar8 = param_5 + param_3;
  uVar7 = param_6 + param_4 + (uint)CARRY4(param_5,param_3);
  iVar1 = **(int **)(param_1 + 0x1c);
  uVar2 = **(uint **)(param_1 + 0x20);
  if ((uVar2 != 0) && (*(uint *)(param_1 + 0x38) < uVar2)) {
    *(uint *)(param_1 + 0x38) = uVar2;
  }
  iVar3 = **(int **)(param_1 + 0xc);
  iVar4 = *(int *)(param_1 + 0x38);
  uVar5 = iVar4 - iVar3;
  uVar6 = (int)uVar5 >> 0x1f;
  if (((uVar7 < uVar6) || ((uVar7 <= uVar6 && (uVar8 <= uVar5)))) &&
     ((uVar8 == 0 && uVar7 == 0 ||
      ((((param_9 & 1) == 0 || (iVar1 != 0)) && (((param_9 & 2) == 0 || (uVar2 != 0)))))))) {
    if (((param_9 & 1) != 0) && (iVar1 != 0)) {
      **(int **)(param_1 + 0x1c) = iVar3 + uVar8;
      **(int **)(param_1 + 0x2c) = iVar4 - (iVar3 + uVar8);
    }
    if (((param_9 & 2) != 0) && (uVar2 != 0)) {
      iVar1 = **(int **)(param_1 + 0x20);
      iVar4 = **(int **)(param_1 + 0x30);
      **(int **)(param_1 + 0x10) = iVar3;
      **(int **)(param_1 + 0x20) = iVar3 + uVar8;
      **(int **)(param_1 + 0x30) = (iVar1 + iVar4) - (iVar3 + uVar8);
    }
    *param_2 = uVar8;
    param_2[1] = uVar7;
  }
  else {
    *param_2 = 0xffffffff;
    param_2[1] = 0xffffffff;
  }
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  param_2[5] = 0;
  return;
}



/* FUNCTION 4097 ; VA 0x0058b920 ; FUN_0058b920 */

undefined4 * FUN_0058b920(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_c = 0xfffffffe;
  uStack_8 = 0x7fffffff;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0xffffffff;
  param_1[3] = 0xffffffff;
  *(undefined *)(param_1 + 4) = 1;
  uVar1 = FUN_0056a9c0(0);
  FUN_005672c0(uVar1,&uStack_c);
  return param_1;
}



/* FUNCTION 4098 ; VA 0x0058b980 ; FUN_0058b980 */

undefined * __thiscall FUN_0058b980(int *param_1,int *param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined *puVar4;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  piVar2 = (int *)FUN_0055b610(param_3);
  if (piVar2 != (int *)param_1[1]) {
    iVar3 = FUN_0170d8dd(*param_3 + 4,piVar2[4] + 4);
    if (-1 < iVar3) goto LAB_0058b9fc;
  }
  piStack_14 = param_3;
  iVar3 = FUN_00559250(&DAT_018bdeda,&piStack_14,(int)&param_3 + 3);
  FUN_0055a560(&param_3,piVar2,iVar3 + 0x10,iVar3);
  piVar2 = param_3;
LAB_0058b9fc:
  iVar3 = *param_2;
  puVar4 = (undefined *)param_2[1];
  if (puVar4 != (undefined *)0x0) {
    LOCK();
    *(int *)(puVar4 + 4) = *(int *)(puVar4 + 4) + 1;
    UNLOCK();
  }
  piVar2[5] = iVar3;
  piVar1 = (int *)piVar2[6];
  piVar2[6] = (int)puVar4;
  uStack_8 = 0;
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar2 = piVar1 + 1;
    iVar3 = *piVar2;
    puVar4 = (undefined *)*piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      puVar4 = (undefined *)(**(code **)(*piVar1 + 4))();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        puVar4 = (undefined *)(**(code **)(*piVar1 + 8))();
      }
    }
  }
  param_1[7] = 0;
  if (0xf < (uint)param_1[8]) {
    puVar4 = (undefined *)param_1[3];
    *puVar4 = 0;
    ExceptionList = pvStack_10;
    return puVar4;
  }
  *(undefined *)(param_1 + 3) = 0;
  ExceptionList = pvStack_10;
  return puVar4;
}



/* FUNCTION 4099 ; VA 0x0058ba80 ; FUN_0058ba80 */

int __thiscall FUN_0058ba80(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *(int *)(param_1 + 0x374) = param_2;
  piVar3 = *(int **)(param_1 + 0x378);
  *(int **)(param_1 + 0x378) = param_3;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar3 = param_3 + 1;
    iVar2 = *piVar3;
    param_2 = *piVar3;
    *piVar3 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar3 = param_3 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_2;
}



/* FUNCTION 4100 ; VA 0x0058bb00 ; FUN_0058bb00 */

void FUN_0058bb00(undefined4 param_1)

{
  FUN_008a65e0(param_1,0);
  return;
}



/* FUNCTION 4101 ; VA 0x0058bb20 ; FUN_0058bb20 */

int __thiscall FUN_0058bb20(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *(int *)(param_1 + 0x58) = param_2;
  piVar3 = *(int **)(param_1 + 0x5c);
  *(int **)(param_1 + 0x5c) = param_3;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar3 = param_3 + 1;
    iVar2 = *piVar3;
    param_2 = *piVar3;
    *piVar3 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar3 = param_3 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_2;
}



/* FUNCTION 4102 ; VA 0x0058bba0 ; FUN_0058bba0 */

int __thiscall FUN_0058bba0(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  *(int *)(param_1 + 0x5c) = param_2;
  piVar3 = *(int **)(param_1 + 0x60);
  *(int **)(param_1 + 0x60) = param_3;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 1;
    iVar2 = *piVar1;
    param_2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar3 = param_3 + 1;
    iVar2 = *piVar3;
    param_2 = *piVar3;
    *piVar3 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar3 = param_3 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_2;
}



/* FUNCTION 4103 ; VA 0x0058bc20 ; FUN_0058bc20 */

uint __thiscall FUN_0058bc20(int *param_1,undefined4 param_2,int *param_3)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  code *pcVar5;
  int *piVar6;
  uint uVar7;
  undefined4 uVar8;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01797068;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_005863d0();
  puStack_18 = (uint *)(*param_1 + 0x24);
  cStack_14 = '\0';
  FUN_00587410();
  uStack_8._0_1_ = 1;
  if (*(char *)(*param_1 + 0x18) != '\0') {
    uVar8 = FUN_0056b140();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_005649e0(uVar8);
    pcVar5 = (code *)swi(3);
    uVar7 = (*pcVar5)();
    return uVar7;
  }
  uVar7 = FUN_00587d90(&param_2,&puStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (cStack_14 != '\0') {
    LOCK();
    uVar7 = *puStack_18;
    *puStack_18 = *puStack_18 + 0x80000000;
    UNLOCK();
    if (((uVar7 & 0x40000000) == 0) && (-0x80000000 < (int)uVar7)) {
      LOCK();
      uVar3 = *puStack_18;
      *puStack_18 = *puStack_18 | 0x40000000;
      UNLOCK();
      if ((uVar3 >> 0x1e & 1) == 0) {
        uVar8 = FUN_00554e40();
        uVar7 = SetEvent(uVar8);
      }
    }
  }
  piVar6 = param_3;
  uStack_8 = 4;
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar3 = *puVar1;
    uVar7 = *puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      uVar7 = (**(code **)(*param_3 + 4))();
      LOCK();
      piVar2 = piVar6 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        uVar7 = (**(code **)(*piVar6 + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 4104 ; VA 0x0058bd10 ; FUN_0058bd10 */

void __thiscall FUN_0058bd10(int *param_1,undefined4 *param_2)

{
  uint uVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  uint *puStack_1c;
  char cStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797090;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005863d0();
  puStack_1c = (uint *)(*param_1 + 0x24);
  cStack_18 = '\0';
  FUN_00587410();
  iVar2 = *param_1;
  uStack_8 = 0;
  if (*(char *)(iVar2 + 0x18) == '\0') {
    puStack_14 = (undefined4 *)FUN_01674e20(0x18);
    if (puStack_14 == (undefined4 *)0x0) {
      puVar7 = (undefined4 *)0x0;
    }
    else {
      puStack_14[4] = 0;
      puStack_14[5] = 0;
      uVar6 = param_2[1];
      uVar4 = param_2[2];
      uVar5 = param_2[3];
      *puStack_14 = *param_2;
      puStack_14[1] = uVar6;
      puStack_14[2] = uVar4;
      puStack_14[3] = uVar5;
      *(undefined8 *)(puStack_14 + 4) = *(undefined8 *)(param_2 + 4);
      param_2[4] = 0;
      param_2[5] = 0xf;
      *(undefined *)param_2 = 0;
      puVar7 = puStack_14;
    }
    *(undefined4 **)(iVar2 + 0x88) = puVar7;
    FUN_0056cee0();
    FUN_00587e20(&puStack_1c);
    uStack_8 = 2;
    if (cStack_18 != '\0') {
      LOCK();
      uVar1 = *puStack_1c;
      *puStack_1c = *puStack_1c + 0x80000000;
      UNLOCK();
      if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
        LOCK();
        uVar1 = *puStack_1c;
        *puStack_1c = *puStack_1c | 0x40000000;
        UNLOCK();
        if ((uVar1 >> 0x1e & 1) == 0) {
          uVar6 = FUN_00554e40();
          SetEvent(uVar6);
        }
      }
    }
    ExceptionList = pvStack_10;
    return;
  }
  uVar6 = FUN_0056b140();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_005649e0(uVar6);
  pcVar3 = (code *)swi(3);
  (*pcVar3)();
  return;
}



/* FUNCTION 4105 ; VA 0x0058be30 ; FUN_0058be30 */

void FUN_0058be30(void)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_005df410();
  if (cVar1 == '\0') {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("ExternalAntiCheat_Errors_All,ExternalAntiCheat_Errors_ShutdownFailed",0x44);
    uStack_8 = 0;
    FUN_00878480(auStack_28,0);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      uVar2 = auStack_28[0];
      if (0xfff < uVar3) {
        uVar2 = *(uint *)(auStack_28[0] - 4);
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar2,uVar3);
    }
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    if (DAT_01d59037 != '\0') {
      FUN_016774b0(DAT_01d59037,"ERROR - Unable to cleanly shut down external anticheat module.",0);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4106 ; VA 0x0058bf10 ; FUN_0058bf10 */

int FUN_0058bf10(void)

{
  uint uVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017970b0;
  pvStack_10 = ExceptionList;
  iVar4 = DAT_01ea8528;
  if (DAT_01ea8528 == 0) {
    ExceptionList = &pvStack_10;
    piVar2 = (int *)FUN_00910d90();
    cStack_14 = '\0';
    iVar4 = *piVar2;
    puStack_18 = (uint *)(iVar4 + 0x94);
    FUN_00587410();
    uStack_8 = 0;
    if (DAT_01ea8528 == 0) {
      FUN_0055e190(auStack_20);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_008a65e0(iVar4,0);
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar4 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar2 = piStack_1c + 2;
          iVar4 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
    }
    iVar4 = DAT_01ea8528;
    uStack_8 = 2;
    if (cStack_14 != '\0') {
      LOCK();
      uVar1 = *puStack_18;
      *puStack_18 = *puStack_18 + 0x80000000;
      UNLOCK();
      if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
        LOCK();
        uVar1 = *puStack_18;
        *puStack_18 = *puStack_18 | 0x40000000;
        UNLOCK();
        if ((uVar1 >> 0x1e & 1) == 0) {
          uVar3 = FUN_00554e40();
          SetEvent(uVar3);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 4107 ; VA 0x0058c000 ; FUN_0058c000 */

undefined4 * FUN_0058c000(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8a9c) {
    FUN_016f3809(&DAT_01ea8a9c);
    if (DAT_01ea8a9c == -1) {
      DAT_01ea8a90 = FUN_0057bbb0;
      DAT_01ea8a94 = FUN_005880a0;
      DAT_01ea8a98 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ea8a9c);
    }
  }
  return &DAT_01ea8a90;
}



/* FUNCTION 4108 ; VA 0x0058c070 ; FUN_0058c070 */

int __fastcall FUN_0058c070(int *param_1)

{
  return (param_1[1] - *param_1) / 0x18;
}



/* FUNCTION 4109 ; VA 0x0058c090 ; FUN_0058c090 */

uint __fastcall FUN_0058c090(int *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  byte *pbVar4;
  
  if (*(int *)param_1[7] == 0) {
LAB_0058c0cb:
    uVar3 = (**(code **)(*param_1 + 0x1c))();
  }
  else {
    piVar1 = (int *)param_1[0xb];
    iVar2 = *piVar1;
    if (1 < iVar2) {
      *piVar1 = iVar2 + -1;
      pbVar4 = (byte *)(*(int *)param_1[7] + 1);
      *(int *)param_1[7] = (int)pbVar4;
      goto LAB_0058c0b0;
    }
    if (iVar2 < 1) goto LAB_0058c0cb;
    *piVar1 = iVar2 + -1;
    pbVar4 = *(byte **)param_1[7];
    *(byte **)param_1[7] = pbVar4 + 1;
    uVar3 = (uint)*pbVar4;
  }
  if (uVar3 == 0xffffffff) {
    return 0xffffffff;
  }
  pbVar4 = *(byte **)param_1[7];
  if ((pbVar4 == (byte *)0x0) || (*(int *)param_1[0xb] < 1)) {
                    /* WARNING: Could not recover jumptable at 0x0058c0f1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar3 = (**(code **)(*param_1 + 0x18))();
    return uVar3;
  }
LAB_0058c0b0:
  return (uint)*pbVar4;
}



/* FUNCTION 4110 ; VA 0x0058c100 ; FUN_0058c100 */

undefined4 FUN_0058c100(void)

{
  return 0x20;
}



/* FUNCTION 4111 ; VA 0x0058c110 ; FUN_0058c110 */

undefined4 FUN_0058c110(void)

{
  return 0x21;
}



/* FUNCTION 4112 ; VA 0x0058c120 ; FUN_0058c120 */

undefined4 FUN_0058c120(void)

{
  return 0x14;
}



/* FUNCTION 4113 ; VA 0x0058c130 ; FUN_0058c130 */

undefined4 FUN_0058c130(void)

{
  return 0x16;
}



/* FUNCTION 4114 ; VA 0x0058c140 ; FUN_0058c140 */

undefined4 FUN_0058c140(void)

{
  return 9;
}



/* FUNCTION 4115 ; VA 0x0058c150 ; FUN_0058c150 */

undefined4 FUN_0058c150(void)

{
  return 10;
}



/* FUNCTION 4116 ; VA 0x0058c160 ; FUN_0058c160 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0058c160(int param_1)

{
  char *pcVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 ****ppppuVar5;
  undefined4 *puVar6;
  uint uVar7;
  bool bVar8;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 ***apppuStack_34 [5];
  uint uStack_20;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017970da;
  pvStack_10 = ExceptionList;
  pcVar1 = "RCCThumbnail";
  if (*(char *)(param_1 + 0xf8) == '\0') {
    pcVar1 = PTR_DAT_01d593e8;
  }
  PTR_DAT_01d593e8 = pcVar1;
  ExceptionList = &pvStack_10;
  FUN_00556200("Service starting");
  FUN_0054ef60(param_1 + 0x18);
  FUN_00912660();
  if ((DAT_01d79c48 == 0) && (puVar6 = (undefined4 *)(param_1 + 0x80), puVar6 != &DAT_01d79c38)) {
    if (0xf < *(uint *)(param_1 + 0x94)) {
      puVar6 = (undefined4 *)*puVar6;
    }
    FUN_005542c0(puVar6,*(undefined4 *)(param_1 + 0x90));
  }
  if ((DAT_01d79cc0 == 0) && (puVar6 = (undefined4 *)(param_1 + 0xfc), puVar6 != &DAT_01d79cb0)) {
    if (0xf < *(uint *)(param_1 + 0x110)) {
      puVar6 = (undefined4 *)*puVar6;
    }
    FUN_005542c0(puVar6,*(undefined4 *)(param_1 + 0x10c));
  }
  piVar2 = (int *)(param_1 + 100);
  if (0xf < *(uint *)(param_1 + 0x78)) {
    piVar2 = (int *)*piVar2;
  }
  FUN_008d9a00(piVar2);
  FUN_0151b650(param_1 + 0xb0);
  thunk_FUN_00f6ed60();
  iVar3 = FUN_01674e20(0xe8);
  uStack_8 = 0;
  if (iVar3 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_00569610(param_1);
  }
  iVar3 = DAT_01ea84c0;
  uStack_8 = 0xffffffff;
  bVar8 = DAT_01ea84c0 != 0;
  DAT_01ea84c0 = uVar4;
  if (bVar8) {
    FUN_0056d630();
    FUN_01674ea0(iVar3,0xe8);
  }
  if (DAT_01d59318 == '\0') {
    FUN_00891da0();
  }
  _DAT_01e90dc0 = 1;
  _DAT_01e90dd0 = 4;
  _DAT_01e90dcc = 4;
  uStack_54 = 0x526c44e3;
  uStack_50 = 0xb91da505;
  uStack_4c = 0xa2361f03;
  uStack_48 = 0x5a908d59;
  uStack_44 = 0xdd30b735;
  uStack_40 = 0x4c48fc5c;
  uStack_3c = 0x81121386;
  uStack_38 = 0x437146a8;
  FUN_005f2fe0(&uStack_54,0x20);
  iVar3 = FUN_005be910(&DAT_018bfc3c,*(undefined4 *)(param_1 + 0x60),100);
  if (iVar3 != -1) {
    FUN_01675640(apppuStack_34,"Service started on port %d",*(undefined4 *)(param_1 + 0x60));
    uStack_8 = 1;
    ppppuVar5 = apppuStack_34;
    if (0xf < uStack_20) {
      ppppuVar5 = (undefined4 ****)apppuStack_34[0];
    }
    FUN_00556200(ppppuVar5);
    if (0xf < uStack_20) {
      uVar7 = uStack_20 + 1;
      ppppuVar5 = (undefined4 ****)apppuStack_34[0];
      if (0xfff < uVar7) {
        ppppuVar5 = (undefined4 ****)apppuStack_34[0][-1];
        uVar7 = uStack_20 + 0x24;
        if (0x1f < (uint)((int)apppuStack_34[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar5,uVar7);
    }
    ExceptionList = pvStack_10;
    return;
  }
  puVar6 = (undefined4 *)FUN_005ace30(&DAT_01e90d84);
  FUN_00550130(*puVar6);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 4117 ; VA 0x0058c3b0 ; FUN_0058c3b0 */

void FUN_0058c3b0(void)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792248;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_0168a8f0();
  if (cVar1 != '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  uVar2 = FUN_005503c0();
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_0054e630(uVar2);
}



/* FUNCTION 4118 ; VA 0x0058c400 ; FUN_0058c400 */

undefined4 FUN_0058c400(undefined4 param_1)

{
  FUN_0058c420(param_1);
  return param_1;
}



/* FUNCTION 4119 ; VA 0x0058c420 ; FUN_0058c420 */

undefined * __thiscall FUN_0058c420(int param_1,undefined *param_2)

{
  void *pvVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar1 = ExceptionList;
  puStack_c = &LAB_01792429;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0xf;
  *param_2 = 0;
  uStack_8 = 0;
  if (((*(uint *)(param_1 + 0x3c) & 2) == 0) && (uVar2 = **(uint **)(param_1 + 0x20), uVar2 != 0)) {
    if (uVar2 < *(uint *)(param_1 + 0x38)) {
      uVar2 = *(uint *)(param_1 + 0x38);
    }
    iVar4 = **(int **)(param_1 + 0x10);
    iVar3 = uVar2 - iVar4;
  }
  else {
    if ((*(uint *)(param_1 + 0x3c) & 4) != 0) {
      ExceptionList = pvVar1;
      return param_2;
    }
    if (**(int **)(param_1 + 0x1c) == 0) {
      ExceptionList = pvVar1;
      return param_2;
    }
    iVar4 = **(int **)(param_1 + 0xc);
    iVar3 = (**(int **)(param_1 + 0x2c) - iVar4) + **(int **)(param_1 + 0x1c);
  }
  FUN_005542c0(iVar4,iVar3);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 4120 ; VA 0x0058c4d0 ; FUN_0058c4d0 */

undefined4 FUN_0058c4d0(undefined4 param_1)

{
  FUN_0058c420(param_1);
  return param_1;
}



/* FUNCTION 4121 ; VA 0x0058c4f0 ; FUN_0058c4f0 */

undefined * __thiscall FUN_0058c4f0(int *param_1,undefined *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *param_1;
  if (iVar1 == 0) {
    *(undefined4 *)(param_2 + 0x10) = 0;
    *(undefined4 *)(param_2 + 0x14) = 0xf;
    *param_2 = 0;
    return param_2;
  }
  iVar2 = param_1[1];
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0xf;
  *param_2 = 0;
  FUN_005542c0(iVar1,iVar2);
  return param_2;
}



/* FUNCTION 4122 ; VA 0x0058c540 ; FUN_0058c540 */

undefined * __thiscall
FUN_0058c540(undefined4 *param_1,undefined *param_2,uint param_3,uint param_4)

{
  code *pcVar1;
  uint uVar2;
  undefined *puVar3;
  
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0xf;
  *param_2 = 0;
  if (param_3 <= (uint)param_1[4]) {
    uVar2 = param_1[4] - param_3;
    if (uVar2 < param_4) {
      param_4 = uVar2;
    }
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    FUN_005542c0((int)param_1 + param_3,param_4);
    return param_2;
  }
  FUN_00554050();
  pcVar1 = (code *)swi(3);
  puVar3 = (undefined *)(*pcVar1)();
  return puVar3;
}



/* FUNCTION 4123 ; VA 0x0058c590 ; FUN_0058c590 */

undefined * FUN_0058c590(undefined *param_1,int param_2,int param_3)

{
  int iVar1;
  undefined *puVar2;
  undefined auStack_7 [3];
  
  if ((param_3 < 1) && (param_3 < 0)) {
    iVar1 = FUN_0055c3d0(auStack_7,-param_2,-(param_3 + (uint)(param_2 != 0)));
    *(undefined *)(iVar1 + -1) = 0x2d;
    puVar2 = (undefined *)(iVar1 + -1);
  }
  else {
    puVar2 = (undefined *)FUN_0055c3d0(auStack_7,param_2,param_3);
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  if (puVar2 != auStack_7) {
    FUN_005542c0(puVar2,(int)auStack_7 - (int)puVar2);
  }
  return param_1;
}



/* FUNCTION 4124 ; VA 0x0058c600 ; FUN_0058c600 */

uint __fastcall FUN_0058c600(int param_1)

{
  int *piVar1;
  byte *pbVar2;
  byte *pbVar3;
  int iVar4;
  byte *pbVar5;
  
  piVar1 = *(int **)(param_1 + 0x1c);
  pbVar2 = (byte *)*piVar1;
  if (pbVar2 != (byte *)0x0) {
    if (pbVar2 < pbVar2 + **(int **)(param_1 + 0x2c)) {
      return (uint)*pbVar2;
    }
    pbVar3 = (byte *)**(undefined4 **)(param_1 + 0x20);
    if ((pbVar3 != (byte *)0x0) && ((*(byte *)(param_1 + 0x3c) & 4) == 0)) {
      pbVar5 = *(byte **)(param_1 + 0x38);
      if (*(byte **)(param_1 + 0x38) < pbVar3) {
        pbVar5 = pbVar3;
      }
      if (pbVar2 < pbVar5) {
        *(byte **)(param_1 + 0x38) = pbVar5;
        iVar4 = *piVar1;
        *piVar1 = iVar4;
        **(int **)(param_1 + 0x2c) = (int)pbVar5 - iVar4;
        return (uint)*(byte *)**(undefined4 **)(param_1 + 0x1c);
      }
    }
  }
  return 0xffffffff;
}



/* FUNCTION 4125 ; VA 0x0058c660 ; FUN_0058c660 */

void __fastcall FUN_0058c660(undefined4 *param_1)

{
  uint uVar1;
  uint *puVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796b90;
  pvStack_10 = ExceptionList;
  puVar2 = (uint *)*param_1;
  if (puVar2 == (uint *)0x0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_0056aeb0(1,"boost unique_lock has no mutex");
    uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
    FUN_00564990(uVar3);
  }
  if (*(char *)(param_1 + 1) != '\0') {
    LOCK();
    uVar1 = *puVar2;
    ExceptionList = &pvStack_10;
    *puVar2 = *puVar2 + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puVar2;
      *puVar2 = *puVar2 | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar3 = FUN_00554e40();
        SetEvent(uVar3);
      }
    }
    *(undefined *)(param_1 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar3 = FUN_0056aeb0(1,"boost unique_lock doesn\'t own the mutex");
  uStack_8 = 1;
                    /* WARNING: Subroutine does not return */
  FUN_00564990(uVar3);
}



/* FUNCTION 4126 ; VA 0x0058c700 ; FUN_0058c700 */

bool FUN_0058c700(char *param_1)

{
  int iVar1;
  char *pcVar2;
  char *pcVar3;
  uint uVar4;
  bool bVar5;
  int in_stack_00000014;
  uint in_stack_00000018;
  
  bVar5 = in_stack_00000014 != 0;
  pcVar3 = (char *)&param_1;
  if (0xf < in_stack_00000018) {
    pcVar3 = param_1;
  }
  pcVar2 = pcVar3 + in_stack_00000014;
  do {
    if (pcVar3 == pcVar2) {
LAB_0058c753:
      if (0xf < in_stack_00000018) {
        uVar4 = in_stack_00000018 + 1;
        pcVar3 = param_1;
        if (0xfff < uVar4) {
          pcVar3 = *(char **)(param_1 + -4);
          uVar4 = in_stack_00000018 + 0x24;
          if ((char *)0x1f < param_1 + (-4 - (int)pcVar3)) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(pcVar3,uVar4);
      }
      return bVar5;
    }
    iVar1 = FUN_0171dac9((int)*pcVar3);
    if ((iVar1 == 0) && (*pcVar3 != '_')) {
      bVar5 = false;
      goto LAB_0058c753;
    }
    pcVar3 = pcVar3 + 1;
  } while( true );
}



/* FUNCTION 4127 ; VA 0x0058c7a0 ; FUN_0058c7a0 */

void __fastcall FUN_0058c7a0(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  code *pcVar5;
  char cVar6;
  int *piVar7;
  undefined **ppuVar8;
  int iVar9;
  undefined4 *puVar10;
  undefined **ppuVar11;
  uint uVar12;
  uint uVar13;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797100;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  do {
    puVar3 = *(undefined4 **)(param_1 + 0xb0);
    if ((puVar3 != (undefined4 *)0x0) && (cVar6 = FUN_0057fcf0(), cVar6 != '\0')) {
      piVar7 = (int *)FUN_01674e20(0x24);
      if (piVar7 == (int *)0x0) {
        piVar7 = (int *)0x0;
        uStack_18 = 0;
      }
      else {
        piVar7[1] = 1;
        piVar7[2] = 1;
        *piVar7 = (int)std::
                       _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>
                       ::vftable;
        *(undefined *)(piVar7 + 3) = 0;
        uStack_18 = 0xb;
        ppuVar8 = (undefined **)
                  FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_18);
        ppuVar11 = (undefined **)&DAT_018be194;
        if (ppuVar8 != &boost::lock_error::vftable_meta_ptr) {
          ppuVar11 = ppuVar8;
        }
        piVar7[4] = (int)*ppuVar11;
        piVar7[5] = 0;
        piVar7[6] = 0x3f800000;
        piVar7[7] = 0;
        piVar7[8] = 0;
      }
      piStack_24 = piVar7 + 3;
      uStack_8 = 0;
      piStack_20 = piVar7;
      cVar6 = FUN_0098f070(puVar3 + 7,&piStack_24,0);
      if (cVar6 != '\0') {
        uStack_34 = 0;
        uStack_30 = 0xf;
        auStack_44[0] = auStack_44[0] & 0xffffff00;
        FUN_005542c0(&DAT_018be4a0,4);
        FUN_00580040(&iStack_1c,auStack_44);
        if (0xf < uStack_30) {
          uVar13 = uStack_30 + 1;
          uVar12 = auStack_44[0];
          if (0xfff < uVar13) {
            uVar12 = *(uint *)(auStack_44[0] - 4);
            uVar13 = uStack_30 + 0x24;
            if (0x1f < (auStack_44[0] - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(uVar12,uVar13);
        }
        iVar2 = iStack_1c;
        if (iStack_1c != 0) {
          iVar4 = *(int *)(iStack_1c + 0x20);
          iVar9 = FUN_008882f0();
          if (iVar4 != iVar9) {
                    /* WARNING: Subroutine does not return */
            FUN_016757c0("Variant cast failed");
          }
          puVar10 = (undefined4 *)(iVar2 + 0x28);
          if (*(int *)(iVar2 + 0x24) == 0) {
            puVar10 = (undefined4 *)0x0;
          }
          piVar7 = (int *)puVar10[1];
          if (piVar7 != (int *)0x0) {
            LOCK();
            piVar7[1] = piVar7[1] + 1;
            UNLOCK();
            piVar7 = (int *)puVar10[1];
          }
          uStack_2c = *puVar10;
          piVar1 = piVar7 + 1;
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          pcVar5 = *(code **)*puVar3;
          if (piVar7 != (int *)0x0) {
            LOCK();
            *piVar1 = *piVar1 + 1;
            UNLOCK();
          }
          piStack_28 = piVar7;
          (*pcVar5)(uStack_2c,piVar7);
          param_1 = iStack_14;
          if (piVar7 != (int *)0x0) {
            LOCK();
            iVar2 = *piVar1;
            *piVar1 = iVar2 + -1;
            UNLOCK();
            if (iVar2 + -1 == 0) {
              (**(code **)*piVar7)();
              LOCK();
              iVar2 = piVar7[2] + -1;
              piVar7[2] = iVar2;
              UNLOCK();
              param_1 = iStack_14;
              if (iVar2 == 0) {
                (**(code **)(*piVar7 + 4))();
                param_1 = iStack_14;
              }
            }
          }
        }
      }
      piVar7 = piStack_20;
      uStack_8 = 0xffffffff;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_20[1] + -1;
        piStack_20[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar2 = *piVar1 + -1;
          *piVar1 = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
    }
    FUN_0151f3f0();
    cVar6 = FUN_0151f440(*(int *)(param_1 + 0x34) * 1000);
  } while (cVar6 == '\0');
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4128 ; VA 0x0058ca00 ; FUN_0058ca00 */

void FUN_0058ca00(undefined4 param_1)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  uStack_10 = 0xfffffffe;
  uStack_c = 0x7fffffff;
  uVar1 = FUN_0056a9c0(0);
  FUN_005672c0(uVar1,&uStack_10);
  FUN_00560fc0(param_1,0,0,0xffffffff,0xffffffff,1,uStack_1c,uStack_18,uStack_14);
  return;
}



/* FUNCTION 4129 ; VA 0x0058ca70 ; FUN_0058ca70 */

void __thiscall FUN_0058ca70(int param_1,undefined4 param_2)

{
  uint uVar1;
  undefined4 uVar2;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796168;
  pvStack_10 = ExceptionList;
  cStack_14 = '\0';
  puStack_18 = (uint *)(param_1 + 0x24);
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  FUN_0058cb00(&puStack_18,param_2);
  uStack_8 = 1;
  if (cStack_14 != '\0') {
    LOCK();
    uVar1 = *puStack_18;
    *puStack_18 = *puStack_18 + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puStack_18;
      *puStack_18 = *puStack_18 | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar2 = FUN_00554e40();
        SetEvent(uVar2);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4130 ; VA 0x0058cb00 ; FUN_0058cb00 */

void __thiscall FUN_0058cb00(int *param_1,undefined4 param_2,char param_3)

{
  char cVar1;
  uint uVar2;
  undefined4 uVar3;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8._0_1_ = 0xff;
  uStack_8._1_3_ = 0xffffff;
  puStack_c = &LAB_01795d28;
  pvStack_10 = ExceptionList;
  uVar2 = param_1[0x16];
  ExceptionList = &pvStack_10;
  if ((uVar2 != 0) && (ExceptionList = &pvStack_10, *(char *)(param_1 + 6) == '\0')) {
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x18,&iStack_3c,0);
    }
    else {
      iStack_3c = param_1[0x18];
      iStack_38 = param_1[0x19];
      iStack_34 = param_1[0x1a];
      iStack_30 = param_1[0x1b];
      uStack_2c = *(undefined8 *)(param_1 + 0x1c);
      ExceptionList = &pvStack_10;
    }
    uStack_8 = 0;
    uStack_18 = param_2;
    FUN_0058c660();
    uStack_14 = CONCAT31(uStack_14._1_3_,1);
    uStack_8._0_1_ = 1;
    if (uVar2 == 0) goto LAB_0058cc84;
    (**(code **)((uVar2 & 0xfffffffe) + 4))(&iStack_3c);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    FUN_00587410();
    uStack_8 = 4;
    if (((uVar2 != 0) && ((uVar2 & 1) == 0)) && (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uVar2 & 0xfffffffe))(&iStack_3c,&iStack_3c,2);
    }
  }
  uStack_8._1_3_ = 0xffffff;
  uStack_8._0_1_ = 0xff;
  if (*(char *)((int)param_1 + 0x19) == '\0') {
    cVar1 = *(char *)(param_1 + 6);
    while (cVar1 == '\0') {
      iStack_3c = -1;
      iStack_38 = -1;
      uVar2 = (uint)iStack_34 >> 8;
      iStack_34 = CONCAT31((int3)uVar2,1);
      uStack_18 = 0xfffffffe;
      uStack_14 = 0x7fffffff;
      uVar3 = FUN_0056a9c0(0);
      FUN_005672c0(uVar3,&uStack_18);
      FUN_00560fc0(param_2,0,0,iStack_3c,iStack_38,iStack_34,iStack_30,(undefined4)uStack_2c,
                   uStack_2c._4_4_);
      cVar1 = *(char *)(param_1 + 6);
    }
    if (param_3 != '\0') {
      if (*(char *)(param_1 + 0x1e) != '\0') {
                    /* WARNING: Subroutine does not return */
        FUN_0170c2a8(&stack0x0000000b,&DAT_01c1e4d8);
      }
      if (param_1[4] != 0) {
        FUN_0058a8c0(param_1 + 4);
LAB_0058cc84:
        uVar3 = FUN_0054fda0();
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
        FUN_0054e5e0(uVar3);
      }
    }
  }
  else {
    *(undefined *)((int)param_1 + 0x19) = 0;
    (**(code **)(*param_1 + 0xc))(param_2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4131 ; VA 0x0058ccb0 ; FUN_0058ccb0 */

void __fastcall FUN_0058ccb0(int *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0058ccb6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x1c))();
  return;
}



/* FUNCTION 4132 ; VA 0x0058ccc0 ; FUN_0058ccc0 */

int FUN_0058ccc0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  puVar1 = (undefined4 *)FUN_005574c0(param_1,param_2,param_3,0,&stack0x00000010);
  iVar2 = FUN_0171d0de(*puVar1,puVar1[1]);
  if (iVar2 < 0) {
    iVar2 = -1;
  }
  return iVar2;
}



/* FUNCTION 4133 ; VA 0x0058ccf0 ; FUN_0058ccf0 */

undefined4 * __thiscall FUN_0058ccf0(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  
  puVar2 = param_1;
  if (7 < (uint)param_1[5]) {
    puVar2 = (undefined4 *)*param_1;
  }
  param_1[4] = 0;
  *(undefined2 *)puVar2 = 0;
  iVar1 = param_2[4];
  if (iVar1 != 0) {
    puVar2 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar2 = (undefined4 *)*param_2;
    }
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    uVar3 = FUN_01686580();
    FUN_01685950(param_2,iVar1 + (int)puVar2,param_1,uVar3);
  }
  return param_1;
}



/* FUNCTION 4134 ; VA 0x0058cd50 ; FUN_0058cd50 */

void FUN_0058cd50(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  
  iVar1 = FUN_0058e9f0(param_1,param_2);
  puVar3 = (undefined4 *)(iVar1 + 8);
  for (iVar2 = 0x50; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar3 = *param_3;
    param_3 = param_3 + 1;
    puVar3 = puVar3 + 1;
  }
  return;
}



/* FUNCTION 4135 ; VA 0x0058cd80 ; FUN_0058cd80 */

void FUN_0058cd80(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  if (param_1 != param_2) {
    do {
      if (7 < (uint)param_1[5]) {
        iVar2 = *param_1;
        iVar1 = param_1[5] * 2;
        uVar4 = iVar1 + 2;
        iVar3 = iVar2;
        if (0xfff < uVar4) {
          iVar3 = *(int *)(iVar2 + -4);
          uVar4 = iVar1 + 0x25;
          if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar3,uVar4);
      }
      param_1[4] = 0;
      param_1[5] = 7;
      *(undefined2 *)param_1 = 0;
      param_1 = param_1 + 6;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 4136 ; VA 0x0058cdf0 ; FUN_0058cdf0 */

int __thiscall FUN_0058cdf0(uint *param_1,uint param_2,int param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8._0_1_ = 0xff;
  uStack_8._1_3_ = 0xffffff;
  puStack_c = &LAB_0179713e;
  pvStack_10 = ExceptionList;
  uVar7 = *param_1;
  iVar4 = (int)(param_1[1] - uVar7) / 0x3c;
  if (iVar4 == 0x4444444) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar4 + 1;
  uVar5 = (int)(param_1[2] - uVar7) / 0x3c;
  uVar2 = uVar1;
  if ((uVar5 <= 0x4444444 - (uVar5 >> 1)) && (uVar2 = (uVar5 >> 1) + uVar5, uVar2 < uVar1)) {
    uVar2 = uVar1;
  }
  uVar5 = uVar2 * 0x3c;
  if (uVar2 < 0x4444445) {
    if (0xfff < uVar5) goto LAB_0058ceb6;
    if (uVar5 == 0) {
      uVar5 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar5 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_0058ceb6:
    uVar3 = uVar5 + 0x23;
    if (uVar3 <= uVar5) {
      uVar3 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) goto LAB_0058d099;
    uVar5 = iVar4 + 0x23U & 0xffffffe0;
    *(int *)(uVar5 - 4) = iVar4;
  }
  iVar4 = ((int)(param_2 - uVar7) / 0x3c) * 0x3c;
  uStack_8 = 0;
  FUN_0054f050(param_3);
  uStack_8._0_1_ = 1;
  FUN_0054f050(param_3 + 0x18);
  uStack_8._0_1_ = 2;
  FUN_0058d6a0(param_3 + 0x30);
  uVar7 = param_1[1];
  uStack_8._0_1_ = 0;
  if (param_2 == uVar7) {
    for (uVar3 = *param_1; uStack_8._0_1_ = 3, uVar3 != uVar7; uVar3 = uVar3 + 0x3c) {
      FUN_0054f050(uVar3);
      uStack_8._0_1_ = 4;
      FUN_0054f050(uVar3 + 0x18);
      uStack_8._0_1_ = 5;
      FUN_0058d6a0(uVar3 + 0x30);
    }
  }
  else {
    FUN_0058ebc0(*param_1,param_2,uVar5);
    FUN_0058ebc0(param_2,param_1[1],iVar4 + uVar5 + 0x3c);
  }
  uVar7 = *param_1;
  if (uVar7 != 0) {
    uVar3 = param_1[1];
    if (uVar7 != uVar3) {
      do {
        FUN_0058dbf0();
        uVar7 = uVar7 + 0x3c;
      } while (uVar7 != uVar3);
      uVar7 = *param_1;
    }
    uVar6 = ((int)(param_1[2] - uVar7) / 0x3c) * 0x3c;
    uVar3 = uVar7;
    if (0xfff < uVar6) {
      uVar3 = *(uint *)(uVar7 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar7 - uVar3) - 4) {
LAB_0058d099:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar6);
  }
  *param_1 = uVar5;
  param_1[1] = uVar5 + uVar1 * 0x3c;
  param_1[2] = uVar5 + uVar2 * 0x3c;
  ExceptionList = pvStack_10;
  return *param_1 + iVar4;
}



/* FUNCTION 4137 ; VA 0x0058d06f ; Catch_All@0058d06f */

void Catch_All_0058d06f(void)

{
  int unaff_EBP;
  
  FUN_0058eaf0(*(undefined4 *)(unaff_EBP + -0x1c),*(undefined4 *)(unaff_EBP + -0x24));
  FUN_0058ee20(*(undefined4 *)(unaff_EBP + -0x30),*(undefined4 *)(unaff_EBP + -0x20));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 4138 ; VA 0x0058d0a0 ; FUN_0058d0a0 */

int __thiscall FUN_0058d0a0(int *param_1,int param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined4 *puVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  
  iVar10 = *param_1;
  iVar2 = (param_2 - iVar10) / 0x18;
  iVar8 = (param_1[1] - iVar10) / 0x18;
  if (iVar8 == 0xaaaaaaa) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar11 = iVar8 + 1;
  uVar3 = (param_1[2] - iVar10) / 0x18;
  uVar12 = uVar11;
  if ((uVar3 <= 0xaaaaaaa - (uVar3 >> 1)) && (uVar12 = (uVar3 >> 1) + uVar3, uVar12 < uVar11)) {
    uVar12 = uVar11;
  }
  puVar7 = (undefined4 *)FUN_00577fb0(uVar12);
  puVar1 = puVar7 + iVar2 * 6;
  puVar1[4] = 0;
  puVar1[5] = 0;
  uVar4 = param_3[1];
  uVar5 = param_3[2];
  uVar6 = param_3[3];
  *puVar1 = *param_3;
  puVar1[1] = uVar4;
  puVar1[2] = uVar5;
  puVar1[3] = uVar6;
  *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(param_3 + 4);
  param_3[4] = 0;
  param_3[5] = 0xf;
  *(undefined *)param_3 = 0;
  iVar10 = param_1[1];
  iVar8 = *param_1;
  puVar9 = puVar7;
  if (param_2 != iVar10) {
    FUN_0055c6d0(*param_1,param_2,puVar7,param_1);
    puVar9 = puVar1 + 6;
    iVar10 = param_1[1];
    iVar8 = param_2;
  }
  FUN_0055c6d0(iVar8,iVar10,puVar9,param_1);
  FUN_00575cd0(puVar7,uVar11,uVar12);
  return *param_1 + iVar2 * 0x18;
}



/* FUNCTION 4139 ; VA 0x0058d1c0 ; FUN_0058d1c0 */

int __thiscall FUN_0058d1c0(int *param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797158;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  iVar2 = (param_1[1] - iVar1) / 0x18;
  if (iVar2 == 0xaaaaaaa) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar6 = iVar2 + 1;
  uVar3 = (param_1[2] - iVar1) / 0x18;
  uVar7 = uVar6;
  if ((uVar3 <= 0xaaaaaaa - (uVar3 >> 1)) && (uVar7 = (uVar3 >> 1) + uVar3, uVar7 < uVar6)) {
    uVar7 = uVar6;
  }
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00577fb0(uVar7);
  uStack_8 = 0;
  iVar5 = ((param_2 - iVar1) / 0x18) * 0x18;
  FUN_0054f050(param_3);
  iVar1 = param_1[1];
  if (param_2 == iVar1) {
    iVar9 = *param_1;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar8 = iVar4;
    for (; iVar9 != iVar1; iVar9 = iVar9 + 0x18) {
      FUN_0054f050(iVar9);
      iVar8 = iVar8 + 0x18;
    }
    FUN_0058cd80(iVar8,iVar8,param_1);
  }
  else {
    FUN_0058d5c0(*param_1,param_2,iVar4);
    FUN_0058d5c0(param_2,param_1[1],iVar5 + iVar4 + 0x18);
  }
  if (*param_1 != 0) {
    FUN_0058cd80(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar6 = ((param_1[2] - iVar1) / 0x18) * 0x18;
    iVar9 = iVar1;
    if (0xfff < uVar6) {
      iVar9 = *(int *)(iVar1 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar1 - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar9,uVar6);
  }
  *param_1 = iVar4;
  param_1[1] = iVar4 + (iVar2 * 3 + 3) * 8;
  param_1[2] = iVar4 + uVar7 * 0x18;
  ExceptionList = pvStack_10;
  return *param_1 + iVar5;
}



/* FUNCTION 4140 ; VA 0x0058d392 ; Catch_All@0058d392 */

void Catch_All_0058d392(void)

{
  int unaff_EBP;
  
  FUN_0058eb20(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x24));
  FUN_0057d2f0(*(undefined4 *)(unaff_EBP + -0x1c),*(undefined4 *)(unaff_EBP + -0x18));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 4141 ; VA 0x0058d3d0 ; FUN_0058d3d0 */

void __thiscall
FUN_0058d3d0(int *param_1,undefined4 *param_2,int *param_3,int param_4,undefined4 param_5,
            uint param_6)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  int *piVar7;
  int *piVar8;
  uint uVar9;
  int *piVar10;
  bool bVar11;
  bool bVar12;
  
  uVar1 = param_5;
  if (param_6 < 2) {
    *param_2 = param_3;
    return;
  }
  uVar9 = param_6 >> 1;
  uVar5 = uVar9;
  puVar3 = param_3;
  if (uVar9 != 0) {
    do {
      puVar3 = (undefined4 *)*puVar3;
      uVar5 = uVar5 - 1;
    } while (0 < (int)uVar5);
  }
  if ((int)uVar5 < 0) {
    iVar6 = -uVar5;
    do {
      puVar3 = (undefined4 *)puVar3[1];
      iVar6 = iVar6 + -1;
    } while (iVar6 != 0);
  }
  puVar2 = (undefined4 *)FUN_0058d3d0(&param_5,param_3,puVar3,param_5,uVar9);
  piVar4 = (int *)*puVar2;
  puVar3 = (undefined4 *)FUN_0058d3d0(&param_6,puVar3,param_4,uVar1,param_6 - uVar9);
  bVar12 = true;
  piVar7 = (int *)*puVar3;
  piVar10 = piVar4;
  param_3 = piVar4;
  while( true ) {
    bVar11 = (uint)piVar7[4] < (uint)piVar4[4];
    if (piVar7[4] == piVar4[4]) {
      bVar11 = (uint)piVar7[3] < (uint)piVar4[3];
    }
    if (bVar11) {
      piVar8 = piVar7;
      if (!bVar12) {
        piVar8 = piVar10;
      }
      piVar10 = (int *)*piVar7;
      if (((piVar7 != (int *)*param_1) && (piVar4 != piVar7)) && (piVar4 != piVar10)) {
        *(int **)piVar7[1] = piVar10;
        *(int **)piVar10[1] = piVar4;
        *(int **)piVar4[1] = piVar7;
        iVar6 = piVar4[1];
        piVar4[1] = piVar10[1];
        piVar10[1] = piVar7[1];
        piVar7[1] = iVar6;
        piVar4 = param_3;
      }
      bVar12 = piVar10 == (int *)param_4;
      piVar7 = piVar10;
      piVar10 = piVar8;
    }
    else {
      piVar4 = (int *)*piVar4;
      bVar12 = piVar4 == piVar7;
      param_3 = piVar4;
    }
    if (bVar12) break;
    bVar12 = false;
  }
  *param_2 = piVar10;
  return;
}



/* FUNCTION 4142 ; VA 0x0058d4d0 ; FUN_0058d4d0 */

uint FUN_0058d4d0(int param_1,uint param_2,uint param_3,byte *param_4,uint param_5)

{
  byte bVar1;
  int iVar2;
  byte *pbVar3;
  byte *pbVar4;
  byte *pbVar5;
  uint uVar6;
  bool bVar7;
  
  if ((param_5 <= param_2) && (param_3 <= param_2 - param_5)) {
    if (param_5 == 0) {
      return param_3;
    }
    iVar2 = (param_1 - param_5) + param_2 + 1;
    bVar1 = *param_4;
    for (pbVar3 = (byte *)FUN_0170db20(param_1 + param_3,(int)(char)bVar1,
                                       iVar2 - (param_1 + param_3)); pbVar3 != (byte *)0x0;
        pbVar3 = (byte *)FUN_0170db20(pbVar3 + 1,(int)(char)bVar1,iVar2 - (int)(pbVar3 + 1))) {
      uVar6 = param_5 - 4;
      pbVar4 = param_4;
      pbVar5 = pbVar3;
      if (3 < param_5) {
        do {
          if (*(int *)pbVar5 != *(int *)pbVar4) goto LAB_0058d556;
          pbVar5 = pbVar5 + 4;
          pbVar4 = pbVar4 + 4;
          bVar7 = 3 < uVar6;
          uVar6 = uVar6 - 4;
        } while (bVar7);
      }
      if (uVar6 == 0xfffffffc) {
LAB_0058d58a:
        uVar6 = 0;
      }
      else {
LAB_0058d556:
        bVar7 = *pbVar5 < *pbVar4;
        if ((*pbVar5 == *pbVar4) &&
           ((uVar6 == 0xfffffffd ||
            ((bVar7 = pbVar5[1] < pbVar4[1], pbVar5[1] == pbVar4[1] &&
             ((uVar6 == 0xfffffffe ||
              ((bVar7 = pbVar5[2] < pbVar4[2], pbVar5[2] == pbVar4[2] &&
               ((uVar6 == 0xffffffff || (bVar7 = pbVar5[3] < pbVar4[3], pbVar5[3] == pbVar4[3]))))))
             )))))) goto LAB_0058d58a;
        uVar6 = -(uint)bVar7 | 1;
      }
      if (uVar6 == 0) {
        return (int)pbVar3 - param_1;
      }
    }
  }
  return 0xffffffff;
}



/* FUNCTION 4143 ; VA 0x0058d5c0 ; FUN_0058d5c0 */

int __thiscall FUN_0058d5c0(undefined4 param_1,int param_2,int param_3,int param_4)

{
  void **ppvVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01797178;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  if (param_2 != param_3) {
    do {
      FUN_0054f050(param_2);
      param_4 = param_4 + 0x18;
      param_2 = param_2 + 0x18;
      ppvVar1 = (void **)ExceptionList;
    } while (param_2 != param_3);
  }
  ExceptionList = ppvVar1;
  FUN_0058cd80(param_4,param_4,param_1);
  ExceptionList = pvStack_10;
  return param_4;
}



/* FUNCTION 4144 ; VA 0x0058d640 ; FUN_0058d640 */

void __thiscall FUN_0058d640(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    puVar1[4] = 0;
    puVar1[5] = 0;
    uVar2 = param_2[1];
    uVar3 = param_2[2];
    uVar4 = param_2[3];
    *puVar1 = *param_2;
    puVar1[1] = uVar2;
    puVar1[2] = uVar3;
    puVar1[3] = uVar4;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(param_2 + 4);
    param_2[4] = 0;
    param_2[5] = 0xf;
    *(undefined *)param_2 = 0;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x18;
    return;
  }
  FUN_0058d0a0(puVar1,param_2);
  return;
}



/* FUNCTION 4145 ; VA 0x0058d6a0 ; FUN_0058d6a0 */

int * __thiscall FUN_0058d6a0(int *param_1,int *param_2)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797198;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar2 = (param_2[1] - *param_2) / 0x18;
  if (uVar2 != 0) {
    if (0xaaaaaaa < uVar2) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    iVar3 = FUN_00577fb0(uVar2);
    *param_1 = iVar3;
    param_1[1] = iVar3;
    param_1[2] = *param_1 + uVar2 * 0x18;
    iVar3 = *param_1;
    iVar1 = param_2[1];
    iVar4 = *param_2;
    uStack_8 = 1;
    for (; iVar4 != iVar1; iVar4 = iVar4 + 0x18) {
      FUN_0054f050(iVar4);
      iVar3 = iVar3 + 0x18;
    }
    FUN_0058cd80(iVar3,iVar3,param_1);
    param_1[1] = iVar3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4146 ; VA 0x0058d778 ; Catch_All@0058d778 */

void Catch_All_0058d778(void)

{
  FUN_0058eb40();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 4147 ; VA 0x0058d790 ; FUN_0058d790 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __fastcall FUN_0058d790(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined *puVar7;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017971ee;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  puVar1 = (undefined4 *)FUN_01518d10(auStack_44,1,0,&DAT_018c0e28);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  if (7 < (uint)puVar1[5]) {
    puVar1 = (undefined4 *)*puVar1;
  }
  piVar2 = (int *)FUN_005527b0();
  if (piVar2 != (int *)0x0) {
    iVar3 = (**(code **)(*piVar2 + 0xc))();
    puVar7 = (undefined *)(iVar3 + 0x10);
    uStack_8._0_1_ = 1;
    puStack_14 = puVar7;
    if (puVar1 == (undefined4 *)0x0) {
      iVar4 = 0;
LAB_0058d82d:
      if (iVar4 < 1) {
        FUN_00552520();
        puVar7 = puStack_14;
        iVar3 = iStack_18;
      }
      else {
        if ((int)(*(int *)(iVar3 + 8) - iVar4 | 1U - *(int *)(iVar3 + 0xc)) < 0) {
          FUN_00552b90(iVar4);
          puVar7 = puStack_14;
        }
        WideCharToMultiByte(3,0,puVar1,0xffffffff,puVar7,iVar4,0,0);
        if (*(int *)((int)puVar7 + -8) < iVar4) goto LAB_0058d9b4;
        *(int *)((int)puVar7 + -0xc) = iVar4;
        *(undefined *)(iVar4 + (int)puVar7) = 0;
        iVar3 = iStack_18;
      }
    }
    else {
      if (((uint)puVar1 & 0xffff0000) != 0) {
        iVar4 = WideCharToMultiByte(3,0,puVar1,0xffffffff,0,0,0,0);
        iVar4 = iVar4 + -1;
        goto LAB_0058d82d;
      }
      FUN_00552980((uint)puVar1 & 0xffff);
      puVar7 = puStack_14;
      iVar3 = param_1;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_0054e9f0(puVar7);
    LOCK();
    piVar2 = (int *)((int)puVar7 + -4);
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar4 + -1 < 1) {
      (**(code **)(**(int **)((int)puVar7 + -0x10) + 4))((undefined4 *)((int)puVar7 + -0x10));
    }
    uStack_8._0_1_ = 5;
    if (7 < uStack_30) {
      uVar6 = uStack_30 * 2 + 2;
      uVar5 = auStack_44[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_44[0] - 4);
        uVar6 = uStack_30 * 2 + 0x25;
        if (0x1f < (auStack_44[0] - uVar5) - 4) goto LAB_0058d9be;
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    uStack_34 = 0;
    puVar7 = (undefined *)(iVar3 + 4);
    uStack_30 = 7;
    auStack_44[0] = auStack_44[0] & 0xffff0000;
    puStack_14 = puVar7;
    FUN_00590910();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (DAT_01d65246 != '\0') {
      FUN_016774b0(DAT_01d65246,"Getting app version, module handle: %p",DAT_0211374c);
    }
    iVar4 = FUN_005910b0(DAT_0211374c);
    if (iVar4 == 0) {
      *(undefined4 *)(iVar3 + 0x14) = 0;
      *(undefined4 *)(iVar3 + 0x18) = 0xf;
      *puVar7 = 0;
      FUN_005542c0("0, 0, 0, 0",10);
    }
    else {
      FUN_00590f00(puVar7);
    }
    FUN_005909b0();
    *(undefined4 *)(iVar3 + 0x2c) = 0;
    *(undefined4 *)(iVar3 + 0x30) = 0xf;
    *(undefined *)(iVar3 + 0x1c) = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    FUN_009c9100((undefined *)(iVar3 + 0x1c));
    _DAT_01ea8b34 = iVar3;
    ExceptionList = pvStack_10;
    return iVar3;
  }
  FUN_005522b0(0x80004005);
LAB_0058d9b4:
  FUN_005522b0(0x80070057);
LAB_0058d9be:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 4148 ; VA 0x0058d9d0 ; FUN_0058d9d0 */

undefined4 * __thiscall
FUN_0058d9d0(undefined4 *param_1,char *param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797213;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RobloxCrashLogManager::vftable;
  uVar2 = GetCurrentThreadId();
  param_1[1] = uVar2;
  param_1[6] = 0;
  param_1[7] = 0xf;
  *(undefined *)(param_1 + 2) = 0;
  pcVar3 = param_2;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_2,(int)pcVar3 - (int)(param_2 + 1));
  *param_1 = MainCrashLogManager::vftable;
  param_1[8] = 0;
  param_1[9] = param_3;
  param_1[10] = param_4;
  param_1[0xb] = 0;
  uStack_8 = 1;
  DAT_01ea8b10 = param_1;
  FUN_01675420(FUN_00590220);
  FUN_0170c0ba(FUN_00590310);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4149 ; VA 0x0058da90 ; FUN_0058da90 */

void __fastcall FUN_0058da90(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_1[1];
  for (iVar2 = *param_1; iVar2 != iVar1; iVar2 = iVar2 + 0x3c) {
    FUN_0058dbf0();
  }
  return;
}



/* FUNCTION 4150 ; VA 0x0058dac0 ; FUN_0058dac0 */

void __fastcall FUN_0058dac0(undefined4 *param_1)

{
  FUN_0058cd80(*param_1,param_1[1],param_1[2]);
  return;
}



/* FUNCTION 4151 ; VA 0x0058dae0 ; FUN_0058dae0 */

void __fastcall FUN_0058dae0(int *param_1)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = (int *)*param_1;
  piVar3 = (int *)*piVar2;
  *piVar2 = (int)piVar2;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar2 = (int *)*param_1;
  if (piVar3 != piVar2) {
    do {
      piVar1 = (int *)*piVar3;
      FUN_01674ea0(piVar3,0x148);
      piVar2 = (int *)*param_1;
      piVar3 = piVar1;
    } while (piVar1 != piVar2);
  }
  FUN_01674ea0(piVar2,0x148);
  return;
}



/* FUNCTION 4152 ; VA 0x0058db30 ; FUN_0058db30 */

void __fastcall FUN_0058db30(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    FUN_005e0950();
    FUN_01674ea0(iVar1,0x398);
  }
  return;
}



/* FUNCTION 4153 ; VA 0x0058db50 ; FUN_0058db50 */

void __fastcall FUN_0058db50(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_0058dbf0();
        iVar2 = iVar2 + 0x3c;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x3c) * 0x3c;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 4154 ; VA 0x0058dbe0 ; thunk_FUN_0058eb40 */

void __fastcall thunk_FUN_0058eb40(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_0058cd80(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x18) * 0x18;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 4155 ; VA 0x0058dbf0 ; FUN_0058dbf0 */

void __fastcall FUN_0058dbf0(int *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  FUN_0058eb40();
  if (7 < (uint)param_1[0xb]) {
    iVar2 = param_1[6];
    iVar1 = param_1[0xb] * 2;
    uVar4 = iVar1 + 2;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = iVar1 + 0x25;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0058dc8f;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[10] = 0;
  param_1[0xb] = 7;
  *(undefined2 *)(param_1 + 6) = 0;
  if (7 < (uint)param_1[5]) {
    iVar2 = *param_1;
    iVar1 = param_1[5] * 2;
    uVar4 = iVar1 + 2;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = iVar1 + 0x25;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_0058dc8f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 7;
  *(undefined2 *)param_1 = 0;
  return;
}



/* FUNCTION 4156 ; VA 0x0058dca0 ; FUN_0058dca0 */

void __fastcall FUN_0058dca0(undefined4 *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = RobloxCrashLogManager::vftable;
  uVar1 = param_1[7];
  if (0xf < uVar1) {
    iVar2 = param_1[2];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[6] = 0;
  param_1[7] = 0xf;
  *(undefined *)(param_1 + 2) = 0;
  return;
}



/* FUNCTION 4157 ; VA 0x0058dd00 ; FUN_0058dd00 */

undefined4 * __thiscall FUN_0058dd00(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  if (param_1 != param_2) {
    puVar1 = param_2 + 4;
    if (7 < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_0058ed10(param_2,*puVar1);
  }
  return param_1;
}



/* FUNCTION 4158 ; VA 0x0058dd30 ; FUN_0058dd30 */

undefined4 * __thiscall FUN_0058dd30(undefined4 *param_1,byte param_2)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = MainCrashLogManager::vftable;
  DAT_01ea8b10 = 0;
  iVar1 = param_1[8];
  if (iVar1 != 0) {
    FUN_005e0950();
    FUN_01674ea0(iVar1,0x398);
  }
  *param_1 = RobloxCrashLogManager::vftable;
  uVar2 = param_1[7];
  if (0xf < uVar2) {
    iVar1 = param_1[2];
    uVar4 = uVar2 + 1;
    iVar3 = iVar1;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar4 = uVar2 + 0x24;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[6] = 0;
  param_1[7] = 0xf;
  *(undefined *)(param_1 + 2) = 0;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x30);
  }
  return param_1;
}



/* FUNCTION 4159 ; VA 0x0058ddd0 ; FUN_0058ddd0 */

undefined4 * __thiscall FUN_0058ddd0(undefined4 *param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = RobloxCrashLogManager::vftable;
  uVar1 = param_1[7];
  if (0xf < uVar1) {
    iVar2 = param_1[2];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[6] = 0;
  param_1[7] = 0xf;
  *(undefined *)(param_1 + 2) = 0;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x20);
  }
  return param_1;
}



/* FUNCTION 4160 ; VA 0x0058de40 ; FUN_0058de40 */

void __fastcall FUN_0058de40(int *param_1)

{
  code *pcVar1;
  int iVar2;
  
  iVar2 = *param_1;
  if ((int)(1U - *(int *)(iVar2 + -4) | *(int *)(iVar2 + -8) - 0x104U) < 0) {
    FUN_00552b90(0x104);
    iVar2 = *param_1;
  }
  PathAddBackslashA(iVar2);
  iVar2 = *param_1;
  if (iVar2 == 0) {
    iVar2 = 0;
  }
  else {
    iVar2 = FUN_01717cb5(iVar2,*(undefined4 *)(iVar2 + -8));
    if (iVar2 < 0) goto LAB_0058de9c;
  }
  if (iVar2 <= *(int *)(*param_1 + -8)) {
    *(int *)(*param_1 + -0xc) = iVar2;
    *(undefined *)(iVar2 + *param_1) = 0;
    return;
  }
LAB_0058de9c:
  FUN_005522b0(0x80070057);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 4161 ; VA 0x0058deb0 ; FUN_0058deb0 */

undefined4 __thiscall FUN_0058deb0(int *param_1,undefined4 param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar3 = *param_1;
  if ((int)(1U - *(int *)(iVar3 + -4) | *(int *)(iVar3 + -8) - 0x104U) < 0) {
    FUN_00552b90(0x104);
    iVar3 = *param_1;
  }
  uVar2 = PathAppendA(iVar3,param_2);
  iVar3 = *param_1;
  if (iVar3 != 0) {
    iVar3 = FUN_01717cb5(iVar3,*(undefined4 *)(iVar3 + -8));
    if (iVar3 < 0) goto LAB_0058df17;
  }
  if (iVar3 <= *(int *)(*param_1 + -8)) {
    *(int *)(*param_1 + -0xc) = iVar3;
    *(undefined *)(iVar3 + *param_1) = 0;
    return uVar2;
  }
LAB_0058df17:
  FUN_005522b0(0x80070057);
  pcVar1 = (code *)swi(3);
  uVar2 = (*pcVar1)();
  return uVar2;
}



/* FUNCTION 4162 ; VA 0x0058df30 ; FUN_0058df30 */

undefined4 FUN_0058df30(undefined4 *param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  int iVar4;
  char *pcVar5;
  
  pcVar5 = PTR_DAT_01d593f0;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar1 != '\0');
  uVar2 = param_1[4];
  puVar3 = param_1;
  if (0xf < (uint)param_1[5]) {
    puVar3 = (undefined4 *)*param_1;
  }
  iVar4 = FUN_0058d4d0(puVar3,uVar2,0,PTR_DAT_01d593f0,(int)pcVar5 - (int)(PTR_DAT_01d593f0 + 1));
  if (iVar4 == -1) {
    pcVar5 = PTR_DAT_01d593f4;
    do {
      cVar1 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar1 != '\0');
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    iVar4 = FUN_0058d4d0(param_1,uVar2,0,PTR_DAT_01d593f4,(int)pcVar5 - (int)(PTR_DAT_01d593f4 + 1))
    ;
    if (iVar4 == -1) {
      return 0;
    }
  }
  return 1;
}



/* FUNCTION 4163 ; VA 0x0058dfb0 ; FUN_0058dfb0 */

void FUN_0058dfb0(char *param_1,int param_2,int param_3)

{
  int iVar1;
  char cVar2;
  code *pcVar3;
  undefined uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  int *piVar8;
  int iVar9;
  char *pcVar10;
  char *pcVar11;
  uint uVar12;
  undefined8 uVar13;
  byte abStack_198 [44];
  char acStack_16c [276];
  undefined auStack_58 [16];
  undefined auStack_48 [16];
  int iStack_38;
  char *pcStack_34;
  int iStack_30;
  uint uStack_2c;
  char *pcStack_28;
  uint uStack_24;
  undefined4 *puStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797259;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  ExceptionList = &pvStack_10;
  uVar6 = FUN_00590180();
  FUN_0054e960(uVar6);
  uStack_8 = 0;
  FUN_0058deb0(param_1);
  FUN_0058de40();
  puStack_20 = (undefined4 *)0x0;
  iStack_1c = 0;
  puStack_20 = (undefined4 *)FUN_0058e9f0(0,0);
  uStack_8._0_1_ = 1;
  puVar7 = (undefined4 *)FUN_00551380(&iStack_30,&iStack_14,&DAT_018c0fac);
  iStack_18 = FindFirstFileA(*puVar7,abStack_198);
  LOCK();
  piVar8 = (int *)(iStack_30 + -4);
  iVar9 = *piVar8;
  *piVar8 = *piVar8 + -1;
  UNLOCK();
  if (iVar9 == 1 || iVar9 + -1 < 0) {
    (**(code **)(**(int **)(iStack_30 + -0x10) + 4))((undefined4 *)(iStack_30 + -0x10));
  }
  if (iStack_18 != -1) {
    do {
      if ((abStack_198[0] & 0x10) == 0) {
        piVar8 = (int *)FUN_005527b0();
        if (piVar8 == (int *)0x0) goto LAB_0058e3cd;
        iVar9 = (**(code **)(*piVar8 + 0xc))();
        param_1 = (char *)(iVar9 + 0x10);
        uStack_8._0_1_ = 2;
        if (((uint)acStack_16c & 0xffff0000) == 0) {
          FUN_00552980((uint)acStack_16c & 0xffff);
          pcVar11 = param_1;
        }
        else {
          pcVar10 = acStack_16c;
          do {
            cVar2 = *pcVar10;
            pcVar10 = pcVar10 + 1;
          } while (cVar2 != '\0');
          uVar12 = (int)pcVar10 - (int)(acStack_16c + 1);
          if (uVar12 == 0) {
            FUN_00552520();
            pcVar11 = param_1;
          }
          else {
            pcStack_28 = *(char **)(iVar9 + 4);
            pcVar10 = acStack_16c + -(int)param_1;
            if ((int)uVar12 < 0) goto LAB_0058e3c3;
            if ((int)(*(int *)(iVar9 + 8) - uVar12 | 1U - *(int *)(iVar9 + 0xc)) < 0) {
              FUN_00552b90(uVar12);
            }
            pcVar11 = param_1;
            if (pcStack_28 < pcVar10) {
              FUN_00557ba0(param_1,*(undefined4 *)(param_1 + -8),acStack_16c,uVar12);
            }
            else if ((param_1 == (char *)0x0) || (param_1 + (int)pcVar10 == (char *)0x0)) {
              puVar7 = (undefined4 *)FUN_0171689d();
              *puVar7 = 0x16;
              FUN_01716793();
            }
            else if (*(uint *)(param_1 + -8) < uVar12) {
              puVar7 = (undefined4 *)FUN_0171689d();
              *puVar7 = 0x22;
              FUN_01716793();
            }
            else {
              FUN_0170cc70(param_1,param_1 + (int)pcVar10,uVar12);
            }
            if (*(int *)(pcVar11 + -8) < (int)uVar12) goto LAB_0058e3c3;
            *(uint *)(pcVar11 + -0xc) = uVar12;
            pcVar11[uVar12] = '\0';
          }
        }
        puVar5 = puStack_20;
        uStack_8._0_1_ = 3;
        puVar7 = (undefined4 *)puStack_20[1];
        uVar6 = FUN_0058cd50(puStack_20,puVar7,abStack_198);
        if (iStack_1c == 0xc7ce0b) {
                    /* WARNING: Subroutine does not return */
          FUN_016ddcd9("list<T> too long");
        }
        iStack_1c = iStack_1c + 1;
        uStack_8._0_1_ = 1;
        puVar5[1] = uVar6;
        *puVar7 = uVar6;
        LOCK();
        piVar8 = (int *)(pcVar11 + -4);
        iVar9 = *piVar8;
        *piVar8 = *piVar8 + -1;
        UNLOCK();
        if (iVar9 == 1 || iVar9 + -1 < 0) {
          (**(code **)(**(int **)(pcVar11 + -0x10) + 4))(pcVar11 + -0x10);
        }
      }
      iVar9 = FindNextFileA(iStack_18,abStack_198);
    } while (iVar9 != 0);
  }
  uVar4 = param_1._3_1_;
  param_1 = (char *)CONCAT31(param_1._1_3_,uVar4);
  FUN_0058d3d0(&pcStack_28,*puStack_20,puStack_20,&param_1,iStack_1c);
  GetSystemTime(auStack_48);
  SystemTimeToFileTime(auStack_48,&uStack_2c);
  uVar13 = FUN_016f39b0(param_3,param_3 >> 0x1f,0x2a69c000,0xc9);
  uVar12 = -(int)uVar13;
  iStack_38 = uVar12 + uStack_2c;
  pcStack_34 = pcStack_28 +
               (uint)CARRY4(uVar12,uStack_2c) +
               (-(uint)((int)uVar13 != 0) - (int)((ulonglong)uVar13 >> 0x20));
  FileTimeToSystemTime(&iStack_38,auStack_58);
  iStack_18 = iStack_1c - param_2;
  puVar7 = (undefined4 *)*puStack_20;
  if (puVar7 != puStack_20) {
    do {
      if ((iStack_18 < 1) && (iVar9 = CompareFileTime(puVar7 + 3,&iStack_38), iVar9 != -1)) break;
      pcVar10 = (char *)(puVar7 + 0xd);
      if ((*(int **)(iStack_14 + -0x10) == (int *)0x0) ||
         (piVar8 = (int *)(**(code **)(**(int **)(iStack_14 + -0x10) + 0x10))(),
         piVar8 == (int *)0x0)) {
        piVar8 = (int *)FUN_005527b0();
        piVar8 = (int *)(**(code **)(*piVar8 + 0x10))();
      }
      uStack_8._0_1_ = 5;
      if (piVar8 == (int *)0x0) goto LAB_0058e3cd;
      iVar9 = (**(code **)(*piVar8 + 0xc))();
      uStack_24 = uStack_24 | 1;
      uStack_8._0_1_ = 4;
      param_3 = iVar9 + 0x10;
      if (pcVar10 != (char *)0x0) {
        do {
          cVar2 = *pcVar10;
          pcVar10 = pcVar10 + 1;
        } while (cVar2 != '\0');
        pcVar10 = pcVar10 + -((int)puVar7 + 0x35);
      }
      param_2 = *(int *)(iStack_14 + -0xc);
      param_1 = pcVar10 + param_2;
      if ((int)param_1 < 0) goto LAB_0058e3c3;
      if ((int)(*(int *)(iVar9 + 8) - (int)param_1 | 1U - *(int *)(iVar9 + 0xc)) < 0) {
        FUN_00552b90(param_1);
      }
      iVar9 = param_3;
      FUN_00557ba0(param_3,param_2,iStack_14,param_2);
      FUN_00557ba0(param_2 + iVar9,pcVar10,puVar7 + 0xd,pcVar10);
      if (*(int *)(iVar9 + -8) < (int)param_1) goto LAB_0058e3c3;
      *(char **)(iVar9 + -0xc) = param_1;
      param_1[iVar9] = '\0';
      DeleteFileA(iVar9);
      uStack_24 = uStack_24 & 0xfffffffe;
      uStack_8._0_1_ = 1;
      LOCK();
      piVar8 = (int *)(iVar9 + -4);
      iVar1 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar1 == 1 || iVar1 + -1 < 0) {
        (**(code **)(**(int **)(iVar9 + -0x10) + 4))((undefined4 *)(iVar9 + -0x10));
      }
      puVar7 = (undefined4 *)*puVar7;
      iStack_18 = iStack_18 + -1;
    } while (puVar7 != puStack_20);
  }
  FUN_0058dae0();
  LOCK();
  piVar8 = (int *)(iStack_14 + -4);
  iVar9 = *piVar8;
  *piVar8 = *piVar8 + -1;
  UNLOCK();
  if (iVar9 == 1 || iVar9 + -1 < 0) {
    (**(code **)(**(int **)(iStack_14 + -0x10) + 4))((undefined4 *)(iStack_14 + -0x10));
  }
  ExceptionList = pvStack_10;
  return;
LAB_0058e3c3:
  FUN_005522b0(0x80070057);
LAB_0058e3cd:
  FUN_005522b0(0x80004005);
  pcVar3 = (code *)swi(3);
  (*pcVar3)();
  return;
}



/* FUNCTION 4164 ; VA 0x0058e3e0 ; FUN_0058e3e0 */

void __fastcall FUN_0058e3e0(int param_1)

{
  if (*(int *)(param_1 + 0x20) == 0) {
    return;
  }
  *(undefined *)(*(int *)(param_1 + 0x20) + 0x2c) = 0;
  return;
}



/* FUNCTION 4165 ; VA 0x0058e3f0 ; FUN_0058e3f0 */

void FUN_0058e3f0(int *param_1,int param_2)

{
  code *pcVar1;
  uint *puVar2;
  int iVar3;
  int iVar4;
  
  if (param_2 != 0) {
    puVar2 = (uint *)FUN_005574c0();
    iVar3 = FUN_0171d0ba(*puVar2 | 2,puVar2[1],0,0,param_2,0,&stack0x0000000c);
    if (iVar3 < 0) {
      iVar3 = -1;
    }
    if (iVar3 < 0) goto LAB_0058e491;
    iVar4 = *param_1;
    if ((int)(1U - *(int *)(iVar4 + -4) | *(int *)(iVar4 + -8) - iVar3) < 0) {
      FUN_00552b90(iVar3);
      iVar4 = *param_1;
    }
    FUN_0171d0de(*puVar2,puVar2[1],iVar4,iVar3 + 1,param_2,0,&stack0x0000000c);
    if (iVar3 <= *(int *)(*param_1 + -8)) {
      *(int *)(*param_1 + -0xc) = iVar3;
      *(undefined *)(iVar3 + *param_1) = 0;
      return;
    }
  }
  FUN_005522b0(0x80070057);
LAB_0058e491:
  FUN_005522b0(0x80004005);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 4166 ; VA 0x0058e4a0 ; FUN_0058e4a0 */

void __fastcall FUN_0058e4a0(undefined4 param_1)

{
  undefined uVar1;
  
  uVar1 = FUN_005e2100(param_1);
  FUN_00592900(uVar1);
  return;
}



/* FUNCTION 4167 ; VA 0x0058e4c0 ; FUN_0058e4c0 */

void __fastcall FUN_0058e4c0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x20);
  if (iVar1 != 0) {
    if (DAT_01f754a0 != '\0') {
      FUN_016774b0(DAT_01f754a0,"Letting watcher thread know we\'re alive",0);
    }
    *(undefined *)(iVar1 + 0x2c) = 1;
    *(undefined *)(iVar1 + 0x2e) = 1;
    return;
  }
  return;
}



/* FUNCTION 4168 ; VA 0x0058e4d0 ; FUN_0058e4d0 */

void FUN_0058e4d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  void *pvStack_14;
  undefined *puStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &DAT_01c1f308;
  puStack_10 = &LAB_0170d9e8;
  pvStack_14 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_14;
  FUN_0058e570(param_1,param_2,param_3,param_4,param_5,param_6);
  ExceptionList = pvStack_14;
  return;
}



/* FUNCTION 4169 ; VA 0x0058e570 ; FUN_0058e570 */

undefined __thiscall
FUN_0058e570(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            ,undefined4 param_6,undefined4 param_7)

{
  undefined uVar1;
  char cVar2;
  int iVar3;
  
  FUN_0058e6c0(4,"StartProcessException...");
  uVar1 = FUN_005e14d0(param_2,param_3,param_4,param_5,param_6,param_7);
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8b48) &&
     (FUN_016f3809(&DAT_01ea8b48), DAT_01ea8b48 == -1)) {
    DAT_01ea8b45 = DAT_01ea8b14;
    FUN_016f37bf(&DAT_01ea8b48);
  }
  if ((DAT_01ea8b45 == '\0') && ((char)param_4 == '\0')) {
    DAT_01ea8b45 = '\x01';
    if (DAT_01ea8ff8 == '\0') {
      MessageBoxA(0,"An unexpected error occurred and Roblox needs to quit.  We\'re sorry!",
                  "Roblox Crash",0);
    }
    else {
      MessageBoxA(*(undefined4 *)(param_1 + 200),
                  "An unexpected error occurred and Roblox needs to quit.\nWe\'re sorry!",
                  "Roblox Crash",0x11010);
      if ((*(int *)(param_1 + 200) != 0) && (iVar3 = IsWindow(*(int *)(param_1 + 200)), iVar3 != 0))
      {
        ShowWindow(*(undefined4 *)(param_1 + 200),0xb);
      }
    }
  }
  if (DAT_01d593fc == '\0') {
    iVar3 = FUN_00590180();
    cVar2 = FUN_0058df30(iVar3 + 4);
    if (cVar2 != '\0') {
      return uVar1;
    }
  }
  FUN_0058e6c0(4,"Uploading crash analytics...");
  FUN_00593270(param_2);
  FUN_0058e6c0(4,"Done uploading crash analytics");
  return uVar1;
}



/* FUNCTION 4170 ; VA 0x0058e6c0 ; FUN_0058e6c0 */

void FUN_0058e6c0(undefined2 param_1,undefined4 param_2)

{
  switch(param_1) {
  case 0:
  case 4:
  case 8:
    FUN_0086f2f0(1,&DAT_018bd25c,param_2);
    return;
  case 1:
  case 0x10:
    FUN_0086f2f0(3,&DAT_018bd25c,param_2);
  }
  return;
}



/* FUNCTION 4171 ; VA 0x0058e730 ; FUN_0058e730 */

void __fastcall FUN_0058e730(int param_1)

{
  char *pcVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  undefined4 ****ppppuVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  char *pcVar8;
  uint uVar9;
  char *pcVar10;
  undefined4 ***apppuStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 ***apppuStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_0179729a;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  uStack_20 = 0xf;
  apppuStack_34[0] = (undefined4 ***)((uint)apppuStack_34[0] & 0xffffff00);
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018c0e58,4);
  iStack_8 = 0;
  iVar4 = FUN_00590180();
  FUN_0054ef60(iVar4 + 0x1c);
  ppppuVar5 = apppuStack_4c;
  if (0xf < uStack_38) {
    ppppuVar5 = (undefined4 ****)apppuStack_4c[0];
  }
  iStack_8._0_1_ = 1;
  FUN_00554150(ppppuVar5,uStack_3c);
  iStack_8._0_1_ = 0;
  uVar2 = (undefined)iStack_8;
  iStack_8._0_1_ = 0;
  if (0xf < uStack_38) {
    uVar9 = uStack_38 + 1;
    ppppuVar5 = (undefined4 ****)apppuStack_4c[0];
    if (0xfff < uVar9) {
      ppppuVar5 = (undefined4 ****)apppuStack_4c[0][-1];
      uVar9 = uStack_38 + 0x24;
      if (0x1f < (uint)((int)apppuStack_4c[0] + (-4 - (int)ppppuVar5))) {
        iStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar9);
  }
  puVar6 = (undefined4 *)FUN_01674e20(0x398);
  iStack_8._0_1_ = 2;
  puStack_1c = puVar6;
  if (puVar6 == (undefined4 *)0x0) {
    puVar6 = (undefined4 *)0x0;
  }
  else {
    uStack_18 = *(undefined4 *)(param_1 + 0x24);
    ppppuVar5 = apppuStack_34;
    if (0xf < uStack_20) {
      ppppuVar5 = (undefined4 ****)apppuStack_34[0];
    }
    puVar7 = (undefined4 *)FUN_00590180();
    uStack_14 = *puVar7;
    FUN_005e0580();
    iStack_8._0_1_ = 3;
    *puVar6 = RobloxCrashReporter::vftable;
    puVar6[0xe4] = 1;
    cVar3 = FUN_005e4be0();
    if (cVar3 != '\0') {
      puVar6[0xe4] = puVar6[0xe4] | 0x40;
    }
    FUN_0171dd10(puVar6 + 0x93,uStack_14,0x104);
    *(undefined *)((int)puVar6 + 0x34f) = 0;
    FUN_0171dd10(puVar6 + 0x33,ppppuVar5,0x80);
    *(undefined *)((int)puVar6 + 0x14b) = 0;
    iVar4 = FUN_00590180();
    puVar7 = (undefined4 *)(iVar4 + 4);
    if (0xf < *(uint *)(iVar4 + 0x18)) {
      puVar7 = (undefined4 *)*puVar7;
    }
    pcVar10 = (char *)(puVar6 + 0x53);
    FUN_0171dd10(pcVar10,puVar7,0x80);
    *(undefined *)((int)puVar6 + 0x1cb) = 0;
    pcVar8 = (char *)(puVar6 + 0x73);
    cVar3 = *pcVar10;
    while (cVar3 != '\0') {
      if (cVar3 != ' ') {
        if (cVar3 == ',') {
          *pcVar8 = '.';
        }
        else {
          *pcVar8 = cVar3;
        }
        pcVar8 = pcVar8 + 1;
      }
      pcVar1 = pcVar10 + 1;
      pcVar10 = pcVar10 + 1;
      cVar3 = *pcVar1;
    }
    *pcVar8 = '\0';
    FUN_0171dd10(puVar6 + 0xd4,uStack_18,0x40);
    *(undefined *)((int)puVar6 + 0x38f) = 0;
  }
  iVar4 = *(int *)(param_1 + 0x20);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  *(undefined4 **)(param_1 + 0x20) = puVar6;
  if (iVar4 != 0) {
    FUN_005e0950();
    FUN_01674ea0(iVar4,0x398);
  }
  FUN_005e1720();
  if (DAT_01d84e8d != '\0') {
    FUN_016774b0(DAT_01d84e8d,"CrashReporter Start",0);
  }
  if (0xf < uStack_20) {
    uVar9 = uStack_20 + 1;
    ppppuVar5 = (undefined4 ****)apppuStack_34[0];
    if (0xfff < uVar9) {
      ppppuVar5 = (undefined4 ****)apppuStack_34[0][-1];
      uVar9 = uStack_20 + 0x24;
      if (0x1f < (uint)((int)apppuStack_34[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar9);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4172 ; VA 0x0058e990 ; FUN_0058e990 */

uint __thiscall FUN_0058e990(int *param_1,uint param_2)

{
  uint in_EAX;
  int iVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2 == 0) {
    return in_EAX & 0xffffff00;
  }
  if (param_2 < 0xaaaaaab) {
    iVar1 = FUN_00577fb0(param_2);
    *param_1 = iVar1;
    param_1[1] = iVar1;
    iVar1 = *param_1 + param_2 * 0x18;
    param_1[2] = iVar1;
    return CONCAT31((int3)((uint)iVar1 >> 8),1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 4173 ; VA 0x0058e9f0 ; FUN_0058e9f0 */

void FUN_0058e9f0(int param_1,int param_2)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_01674e20(0x148);
  if (param_1 == 0) {
    *piVar1 = (int)piVar1;
    piVar1[1] = (int)piVar1;
    return;
  }
  *piVar1 = param_1;
  piVar1[1] = param_2;
  return;
}



/* FUNCTION 4174 ; VA 0x0058ea20 ; FUN_0058ea20 */

uint __thiscall FUN_0058ea20(int param_1,uint param_2)

{
  uint uVar1;
  
  param_2 = param_2 | 7;
  if (param_2 < 0x7fffffff) {
    uVar1 = *(uint *)(param_1 + 0x14);
    if (uVar1 <= 0x7ffffffe - (uVar1 >> 1)) {
      uVar1 = (uVar1 >> 1) + uVar1;
      if (param_2 < uVar1) {
        param_2 = uVar1;
      }
      return param_2;
    }
  }
  return 0x7ffffffe;
}



/* FUNCTION 4175 ; VA 0x0058ea60 ; FUN_0058ea60 */

void __thiscall FUN_0058ea60(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_0058cd80(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x18) * 0x18;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  *param_1 = param_2;
  param_1[1] = param_2 + param_3 * 0x18;
  param_1[2] = param_2 + param_4 * 0x18;
  return;
}



/* FUNCTION 4176 ; VA 0x0058eaf0 ; FUN_0058eaf0 */

void FUN_0058eaf0(int param_1,int param_2)

{
  if (param_1 != param_2) {
    do {
      FUN_0058dbf0();
      param_1 = param_1 + 0x3c;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 4177 ; VA 0x0058eb20 ; FUN_0058eb20 */

void __thiscall FUN_0058eb20(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_0058cd80(param_2,param_3,param_1);
  return;
}



/* FUNCTION 4178 ; VA 0x0058eb40 ; FUN_0058eb40 */

void __fastcall FUN_0058eb40(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_0058cd80(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x18) * 0x18;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 4179 ; VA 0x0058ebc0 ; FUN_0058ebc0 */

int FUN_0058ebc0(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017972c0;
  pvStack_10 = ExceptionList;
  uStack_7 = 0;
  if (param_1 != param_2) {
    puVar2 = param_1 + 0xe;
    ExceptionList = &pvStack_10;
    do {
      uStack_8 = 0;
      FUN_0054f050(puVar2 + -0xe);
      uStack_8 = 1;
      FUN_0054f050(puVar2 + -8);
      *(undefined4 *)(param_3 + 0x30) = 0;
      *(undefined4 *)(param_3 + 0x34) = 0;
      puVar1 = puVar2 + 1;
      *(undefined4 *)(param_3 + 0x38) = 0;
      *(undefined4 *)(param_3 + 0x30) = puVar2[-2];
      *(undefined4 *)(param_3 + 0x34) = puVar2[-1];
      *(undefined4 *)(param_3 + 0x38) = *puVar2;
      param_3 = param_3 + 0x3c;
      puVar2[-2] = 0;
      puVar2[-1] = 0;
      *puVar2 = 0;
      puVar2 = puVar2 + 0xf;
    } while (puVar1 != param_2);
  }
  ExceptionList = pvStack_10;
  return param_3;
}



/* FUNCTION 4180 ; VA 0x0058ec90 ; FUN_0058ec90 */

void __thiscall FUN_0058ec90(undefined4 param_1,int param_2,int param_3,int param_4)

{
  void **ppvVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01797178;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  ppvVar1 = &pvStack_10;
  if (param_2 != param_3) {
    do {
      FUN_0054f050(param_2);
      param_4 = param_4 + 0x18;
      param_2 = param_2 + 0x18;
      ppvVar1 = (void **)ExceptionList;
    } while (param_2 != param_3);
  }
  ExceptionList = ppvVar1;
  FUN_0058cd80(param_4,param_4,param_1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4181 ; VA 0x0058ed10 ; FUN_0058ed10 */

int * __thiscall FUN_0058ed10(int *param_1,undefined4 param_2,int *param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  code *pcVar4;
  int iVar5;
  int iVar6;
  int *piVar7;
  uint uVar8;
  
  uVar8 = (uint)param_3;
  uVar2 = param_1[5];
  if (param_3 <= uVar2) {
    param_3 = param_1;
    if (7 < uVar2) {
      param_3 = (int *)*param_1;
    }
    iVar5 = uVar8 * 2;
    param_1[4] = uVar8;
    FUN_0170cc70(param_3,param_2,iVar5);
    *(undefined2 *)(iVar5 + (int)param_3) = 0;
    return param_1;
  }
  if (0x7ffffffe < param_3) {
    FUN_00554040();
    pcVar4 = (code *)swi(3);
    piVar7 = (int *)(*pcVar4)();
    return piVar7;
  }
  uVar8 = (uint)param_3 | 7;
  if (uVar8 < 0x7fffffff) {
    if (0x7ffffffe - (uVar2 >> 1) < uVar2) {
      uVar8 = 0x7ffffffe;
    }
    else {
      uVar1 = (uVar2 >> 1) + uVar2;
      if (uVar8 < uVar1) {
        uVar8 = uVar1;
      }
    }
  }
  else {
    uVar8 = 0x7ffffffe;
  }
  iVar5 = FUN_005540c0(uVar8 + 1);
  param_1[5] = uVar8;
  param_1[4] = (int)param_3;
  FUN_0170c6f0(iVar5,param_2,(int)param_3 * 2);
  *(undefined2 *)((int)param_3 * 2 + iVar5) = 0;
  if (7 < uVar2) {
    iVar3 = *param_1;
    uVar8 = uVar2 * 2 + 2;
    iVar6 = iVar3;
    if (0xfff < uVar8) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar8 = uVar2 * 2 + 0x25;
      if (0x1f < (iVar3 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar8);
  }
  *param_1 = iVar5;
  return param_1;
}



/* FUNCTION 4182 ; VA 0x0058ee20 ; FUN_0058ee20 */

void FUN_0058ee20(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x3c;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 4183 ; VA 0x0058ee60 ; FUN_0058ee60 */

void __thiscall FUN_0058ee60(undefined4 *param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  puVar1 = param_2 + 4;
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  puVar2 = param_1 + 4;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  FUN_0058d4d0(param_1,*puVar2,param_3,param_2,*puVar1);
  return;
}



/* FUNCTION 4184 ; VA 0x0058eea0 ; FUN_0058eea0 */

void __thiscall FUN_0058eea0(undefined4 *param_1,char *param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  char cVar2;
  char *pcVar3;
  
  pcVar3 = param_2;
  do {
    cVar2 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar2 != '\0');
  puVar1 = param_1 + 4;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  FUN_0058d4d0(param_1,*puVar1,param_3,param_2,(int)pcVar3 - (int)(param_2 + 1));
  return;
}



/* FUNCTION 4185 ; VA 0x0058eee0 ; FUN_0058eee0 */

undefined4 * FUN_0058eee0(undefined4 *param_1,undefined4 *param_2)

{
  char cVar1;
  code *pcVar2;
  undefined4 ***pppuVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 ****ppppuVar7;
  int *piVar8;
  undefined4 *puVar9;
  int iVar10;
  char *pcVar11;
  char *pcVar12;
  uint uVar13;
  uint uVar14;
  byte abStack_188 [44];
  char acStack_15c [276];
  int iStack_48;
  uint uStack_44;
  int iStack_40;
  int iStack_3c;
  undefined4 ***pppuStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  int iStack_20;
  uint uStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01797312;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar14 = 1;
  uStack_8 = 0;
  uStack_14 = 1;
  uStack_1c = 1;
  uVar4 = FUN_00590180();
  FUN_0054e960(uVar4);
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  FUN_0058de40();
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  puVar5 = (undefined4 *)FUN_00551380(&iStack_3c,&iStack_18,param_2);
  iVar6 = FindFirstFileA(*puVar5,abStack_188);
  iStack_48 = iVar6;
  LOCK();
  piVar8 = (int *)(iStack_3c + -4);
  iVar10 = *piVar8;
  *piVar8 = *piVar8 + -1;
  UNLOCK();
  if (iVar10 == 1 || iVar10 + -1 < 0) {
    (**(code **)(**(int **)(iStack_3c + -0x10) + 4))((undefined4 *)(iStack_3c + -0x10));
  }
  if (iVar6 != -1) {
    do {
      uStack_44 = uVar14;
      if ((abStack_188[0] & 0x10) == 0) {
        pcVar11 = acStack_15c;
        uStack_28 = 0;
        uStack_24 = 0xf;
        pppuStack_38 = (undefined4 ***)((uint)pppuStack_38 & 0xffffff00);
        do {
          cVar1 = *pcVar11;
          pcVar11 = pcVar11 + 1;
        } while (cVar1 != '\0');
        FUN_005542c0(acStack_15c,(int)pcVar11 - (int)(acStack_15c + 1));
        pppuVar3 = pppuStack_38;
        ppppuVar7 = &pppuStack_38;
        if (0xf < uStack_24) {
          ppppuVar7 = (undefined4 ****)pppuStack_38;
        }
        iStack_20 = FUN_0058d4d0(ppppuVar7,uStack_28,0,&DAT_018bcce8,4);
        if (0xf < uStack_24) {
          uVar14 = uStack_24 + 1;
          ppppuVar7 = (undefined4 ****)pppuVar3;
          if (0xfff < uVar14) {
            ppppuVar7 = (undefined4 ****)pppuVar3[-1];
            uVar14 = uStack_24 + 0x24;
            if (0x1f < (uint)((int)pppuVar3 + (-4 - (int)ppppuVar7))) goto LAB_0058f24c;
          }
          FUN_01674ea0(ppppuVar7,uVar14);
        }
        uVar14 = uStack_14;
        if (iStack_20 == -1) {
          if ((*(int **)(iStack_18 + -0x10) == (int *)0x0) ||
             (piVar8 = (int *)(**(code **)(**(int **)(iStack_18 + -0x10) + 0x10))(),
             piVar8 == (int *)0x0)) {
            piVar8 = (int *)FUN_005527b0();
            piVar8 = (int *)(**(code **)(*piVar8 + 0x10))();
          }
          uStack_8._0_1_ = 3;
          if (piVar8 == (int *)0x0) {
            FUN_005522b0(0x80004005);
LAB_0058f24c:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
          puVar5 = (undefined4 *)(**(code **)(*piVar8 + 0xc))();
          pcVar12 = acStack_15c;
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          pcVar11 = (char *)(puVar5 + 4);
          uStack_1c = uStack_14 | 2;
          do {
            cVar1 = *pcVar12;
            pcVar12 = pcVar12 + 1;
          } while (cVar1 != '\0');
          uStack_14 = *(uint *)(iStack_18 + -0xc);
          iStack_20 = (int)pcVar12 - (int)(acStack_15c + 1);
          iStack_40 = iStack_20 + uStack_14;
          if (iStack_40 < 0) {
LAB_0058f251:
            FUN_005522b0(0x80070057);
            pcVar2 = (code *)swi(3);
            puVar5 = (undefined4 *)(*pcVar2)();
            return puVar5;
          }
          if ((int)(puVar5[2] - iStack_40 | 1 - puVar5[3]) < 0) {
            FUN_00552b90(iStack_40);
          }
          FUN_00557ba0(pcVar11,uStack_14,iStack_18,uStack_14);
          if (iStack_20 != 0) {
            if (pcVar11 + uStack_14 == (char *)0x0) {
              puVar9 = (undefined4 *)FUN_0171689d();
              *puVar9 = 0x16;
              FUN_01716793();
            }
            else {
              FUN_0170c6f0(pcVar11 + uStack_14,acStack_15c,iStack_20);
            }
          }
          if ((int)puVar5[2] < iStack_40) goto LAB_0058f251;
          puVar5[1] = iStack_40;
          pcVar11[iStack_40] = '\0';
          uStack_28 = 0;
          uStack_24 = 0xf;
          pppuStack_38 = (undefined4 ***)((uint)pppuStack_38 & 0xffffff00);
          pcVar12 = pcVar11;
          do {
            cVar1 = *pcVar12;
            pcVar12 = pcVar12 + 1;
          } while (cVar1 != '\0');
          FUN_005542c0(pcVar11,(int)pcVar12 - ((int)puVar5 + 0x11));
          pppuVar3 = pppuStack_38;
          uStack_8._0_1_ = 4;
          puVar9 = (undefined4 *)param_1[1];
          if ((undefined4 *)param_1[2] == puVar9) {
            FUN_0058d0a0(puVar9,&pppuStack_38);
            uVar14 = uStack_24;
          }
          else {
            pppuStack_38 = (undefined4 ***)((uint)pppuStack_38 & 0xffffff00);
            *puVar9 = pppuVar3;
            puVar9[1] = uStack_34;
            puVar9[2] = uStack_30;
            puVar9[3] = uStack_2c;
            puVar9[4] = uStack_28;
            puVar9[5] = uStack_24;
            param_1[1] = param_1[1] + 0x18;
            uVar14 = 0xf;
          }
          uStack_8._0_1_ = 2;
          if (0xf < uVar14) {
            uVar13 = uVar14 + 1;
            ppppuVar7 = (undefined4 ****)pppuStack_38;
            if (0xfff < uVar13) {
              ppppuVar7 = (undefined4 ****)pppuStack_38[-1];
              uVar13 = uVar14 + 0x24;
              if (0x1f < (uint)((int)pppuStack_38 + (-4 - (int)ppppuVar7))) goto LAB_0058f24c;
            }
            FUN_01674ea0(ppppuVar7,uVar13);
          }
          uStack_1c = uStack_44 & 0xfffffffd;
          uStack_8._0_1_ = 1;
          LOCK();
          piVar8 = puVar5 + 3;
          iVar10 = *piVar8;
          *piVar8 = *piVar8 + -1;
          UNLOCK();
          uVar14 = uStack_1c;
          uStack_14 = uStack_1c;
          if (iVar10 == 1 || iVar10 + -1 < 0) {
            (**(code **)(*(int *)*puVar5 + 4))(puVar5);
            uVar14 = uStack_14;
          }
        }
      }
      iVar10 = FindNextFileA(iStack_48,abStack_188);
    } while (iVar10 != 0);
  }
  LOCK();
  piVar8 = (int *)(iStack_18 + -4);
  iVar10 = *piVar8;
  *piVar8 = *piVar8 + -1;
  UNLOCK();
  if (iVar10 == 1 || iVar10 + -1 < 0) {
    (**(code **)(**(int **)(iStack_18 + -0x10) + 4))((undefined4 *)(iStack_18 + -0x10));
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4186 ; VA 0x0058f260 ; FUN_0058f260 */

undefined4 * FUN_0058f260(undefined4 *param_1)

{
  code *pcVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  undefined4 ****ppppuVar8;
  char *pcVar9;
  uint uVar10;
  uint uVar11;
  char *pcVar12;
  byte abStack_220 [44];
  char acStack_1f4 [276];
  uint auStack_e0 [4];
  undefined4 uStack_d0;
  uint uStack_cc;
  int iStack_c8;
  int iStack_c4;
  undefined4 ***apppuStack_c0 [4];
  int iStack_b0;
  uint uStack_ac;
  uint auStack_a8 [4];
  undefined4 uStack_98;
  uint uStack_94;
  undefined4 ***apppuStack_90 [4];
  undefined4 uStack_80;
  uint uStack_7c;
  undefined4 uStack_78;
  int iStack_74;
  int iStack_70;
  char *pcStack_6c;
  undefined4 ***pppuStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  uint uStack_58;
  uint uStack_54;
  char *pcStack_50;
  char *pcStack_4c;
  int iStack_48;
  char *pcStack_44;
  int iStack_40;
  char *pcStack_3c;
  undefined4 ***pppuStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  uint uStack_24;
  char *pcStack_20;
  char *pcStack_1c;
  char *pcStack_18;
  char *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017973d2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  pcVar12 = (char *)0x1;
  uStack_8 = 0;
  pcStack_14 = (char *)0x1;
  pcStack_18 = (char *)0x1;
  uVar3 = FUN_00590180();
  FUN_0054e960(uVar3);
  uStack_8 = 1;
  FUN_0058de40();
  puVar4 = (undefined4 *)FUN_00551380(&iStack_c4,&iStack_40,"*.dmp");
  iVar5 = FindFirstFileA(*puVar4,abStack_220);
  LOCK();
  piVar6 = (int *)(iStack_c4 + -4);
  iVar7 = *piVar6;
  *piVar6 = *piVar6 + -1;
  UNLOCK();
  iStack_c8 = iVar5;
  if (iVar7 == 1 || iVar7 + -1 < 0) {
    (**(code **)(**(int **)(iStack_c4 + -0x10) + 4))((undefined4 *)(iStack_c4 + -0x10));
  }
  if (iVar5 != -1) {
    do {
      pcStack_20 = pcVar12;
      if ((abStack_220[0] & 0x10) == 0) {
        if ((*(int **)(iStack_40 + -0x10) == (int *)0x0) ||
           (piVar6 = (int *)(**(code **)(**(int **)(iStack_40 + -0x10) + 0x10))(),
           piVar6 == (int *)0x0)) {
          piVar6 = (int *)FUN_005527b0();
          piVar6 = (int *)(**(code **)(*piVar6 + 0x10))();
        }
        uStack_8._0_1_ = 3;
        if (piVar6 == (int *)0x0) {
          FUN_005522b0(0x80004005);
LAB_0058fad7:
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
        iVar7 = (**(code **)(*piVar6 + 0xc))();
        pcStack_1c = acStack_1f4;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        pcStack_6c = (char *)(iVar7 + 0x10);
        pcStack_18 = (char *)((uint)pcStack_14 | 2);
        do {
          cVar2 = *pcStack_1c;
          pcStack_1c = pcStack_1c + 1;
        } while (cVar2 != '\0');
        pcStack_14 = *(char **)(iStack_40 + -0xc);
        pcStack_1c = pcStack_1c + -(int)(acStack_1f4 + 1);
        pcStack_44 = pcStack_1c + (int)pcStack_14;
        if ((int)pcStack_44 < 0) {
LAB_0058fae1:
          FUN_005522b0(0x80070057);
          pcVar1 = (code *)swi(3);
          puVar4 = (undefined4 *)(*pcVar1)();
          return puVar4;
        }
        if ((int)(*(int *)(iVar7 + 8) - (int)pcStack_44 | 1U - *(int *)(iVar7 + 0xc)) < 0) {
          FUN_00552b90(pcStack_44);
        }
        pcVar12 = pcStack_6c;
        FUN_00557ba0(pcStack_6c,pcStack_14,iStack_40,pcStack_14);
        if (pcStack_1c != (char *)0x0) {
          if (pcVar12 + (int)pcStack_14 == (char *)0x0) {
            puVar4 = (undefined4 *)FUN_0171689d();
            *puVar4 = 0x16;
            FUN_01716793();
          }
          else {
            FUN_0170c6f0(pcVar12 + (int)pcStack_14,acStack_1f4,pcStack_1c);
          }
        }
        pcStack_1c = pcVar12 + -0x10;
        if (*(int *)(pcVar12 + -8) < (int)pcStack_44) goto LAB_0058fae1;
        *(char **)(pcVar12 + -0xc) = pcStack_44;
        pcStack_44[(int)pcVar12] = '\0';
        iStack_b0 = 0;
        uStack_ac = 0xf;
        apppuStack_c0[0] = (undefined4 ***)((uint)apppuStack_c0[0] & 0xffffff00);
        pcVar9 = pcVar12;
        do {
          cVar2 = *pcVar9;
          pcVar9 = pcVar9 + 1;
        } while (cVar2 != '\0');
        FUN_005542c0(pcVar12,(int)pcVar9 - (int)(pcVar12 + 1));
        pcVar12 = (char *)((uint)pcStack_20 & 0xfffffffd);
        pcStack_14 = pcVar12;
        pcStack_18 = pcVar12;
        pcStack_3c = pcVar12;
        uStack_8._0_1_ = 5;
        LOCK();
        piVar6 = (int *)(pcStack_1c + 0xc);
        iVar7 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar7 + -1 < 1) {
          (**(code **)(**(int **)pcStack_1c + 4))(pcStack_1c);
        }
        if ((DAT_01d593fc != '\0') || (cVar2 = FUN_0058df30(apppuStack_c0), cVar2 == '\0')) {
          if (DAT_01d7a648 == '\0') {
            uStack_94 = 7;
            uStack_80 = 0;
            uStack_7c = 7;
            apppuStack_90[0] = (undefined4 ***)((uint)apppuStack_90[0] & 0xffff0000);
            uStack_78 = 0;
            iStack_74 = 0;
            iStack_70 = 0;
            uStack_8._0_1_ = 7;
            uStack_98 = 0;
            auStack_a8[0] = auStack_a8[0] & 0xffff0000;
            if (iStack_b0 != 0) {
              ppppuVar8 = apppuStack_c0;
              if (0xf < uStack_ac) {
                ppppuVar8 = (undefined4 ****)apppuStack_c0[0];
              }
              pcStack_20 = (char *)((int)ppppuVar8 + iStack_b0);
              ppppuVar8 = apppuStack_c0;
              if (0xf < uStack_ac) {
                ppppuVar8 = (undefined4 ****)apppuStack_c0[0];
              }
              uVar3 = FUN_01686580();
              FUN_01685950(ppppuVar8,pcStack_20,auStack_a8,uVar3);
              pcVar12 = pcStack_14;
            }
            pcVar9 = acStack_1f4;
            uStack_58 = 0;
            uStack_54 = 0xf;
            pppuStack_68 = (undefined4 ***)((uint)pppuStack_68 & 0xffffff00);
            do {
              cVar2 = *pcVar9;
              pcVar9 = pcVar9 + 1;
            } while (cVar2 != '\0');
            FUN_005542c0(acStack_1f4,(int)pcVar9 - (int)(acStack_1f4 + 1));
            uStack_8._0_1_ = 8;
            iStack_28 = 0;
            uVar10 = 9;
            if (uStack_58 < 9) {
              uVar10 = uStack_58;
            }
            ppppuVar8 = &pppuStack_68;
            if (0xf < uStack_54) {
              ppppuVar8 = (undefined4 ****)pppuStack_68;
            }
            uStack_24 = 0xf;
            pppuStack_38 = (undefined4 ***)((uint)pppuStack_38 & 0xffffff00);
            FUN_005542c0(ppppuVar8,uVar10);
            pcStack_18 = (char *)((uint)pcVar12 | 4);
            FUN_005507b0();
            pppuStack_68 = pppuStack_38;
            uStack_64 = uStack_34;
            uStack_60 = uStack_30;
            uStack_5c = uStack_2c;
            uStack_58 = iStack_28;
            uStack_54 = uStack_24;
            FUN_00558ce0(auStack_e0,&pppuStack_68,"*.txt");
            uStack_8._0_1_ = 9;
            FUN_0058eee0(&pcStack_50,auStack_e0);
            uStack_8._0_1_ = 10;
            pcStack_44 = pcStack_4c;
            pcVar12 = pcStack_50;
            if (pcStack_50 != pcStack_4c) {
              do {
                iStack_28 = 0;
                uStack_24 = 7;
                pppuStack_38 = (undefined4 ***)((uint)pppuStack_38 & 0xffff0000);
                uStack_8._0_1_ = 0xb;
                if (*(int *)(pcVar12 + 0x10) != 0) {
                  pcStack_20 = pcVar12;
                  if (0xf < *(uint *)(pcVar12 + 0x14)) {
                    pcStack_20 = *(char **)pcVar12;
                  }
                  pcStack_20 = pcStack_20 + *(int *)(pcVar12 + 0x10);
                  pcStack_14 = pcVar12;
                  if (0xf < *(uint *)(pcVar12 + 0x14)) {
                    pcStack_14 = *(char **)pcVar12;
                  }
                  uVar3 = FUN_01686580();
                  FUN_01685950(pcStack_14,pcStack_20,&pppuStack_38,uVar3);
                }
                uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
                if (iStack_70 == iStack_74) {
                  FUN_0058d1c0(iStack_74,&pppuStack_38);
                }
                else {
                  FUN_0054f050(&pppuStack_38);
                  iStack_74 = iStack_74 + 0x18;
                }
                uStack_8._0_1_ = 10;
                if (7 < uStack_24) {
                  uVar10 = uStack_24 * 2 + 2;
                  ppppuVar8 = (undefined4 ****)pppuStack_38;
                  if (0xfff < uVar10) {
                    ppppuVar8 = (undefined4 ****)pppuStack_38[-1];
                    uVar10 = uStack_24 * 2 + 0x25;
                    if (0x1f < (uint)((int)pppuStack_38 + (-4 - (int)ppppuVar8))) goto LAB_0058fad7;
                  }
                  FUN_01674ea0(ppppuVar8,uVar10);
                }
                pcVar12 = pcVar12 + 0x18;
              } while (pcVar12 != pcStack_44);
            }
            uStack_80 = 0;
            ppppuVar8 = apppuStack_90;
            if (7 < uStack_7c) {
              ppppuVar8 = (undefined4 ****)apppuStack_90[0];
            }
            *(undefined2 *)ppppuVar8 = 0;
            uVar3 = FUN_01686580();
            FUN_01685950(iStack_40,0,apppuStack_90,uVar3);
            pcStack_18 = (char *)((uint)pcStack_3c | 0xc);
            uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
            uVar10 = uStack_58 + 4;
            iStack_28 = 0;
            uStack_24 = 0xf;
            pppuStack_38 = (undefined4 ***)((uint)pppuStack_38 & 0xffffff00);
            pcStack_14 = pcStack_18;
            if (0xf < uVar10) {
              if (0x7fffffff < uVar10) {
                FUN_00554040();
                goto LAB_0058fae1;
              }
              uVar10 = uVar10 | 0xf;
              if (uVar10 < 0x80000000) {
                if (uVar10 < 0x16) {
                  uVar10 = 0x16;
                }
              }
              else {
                uVar10 = 0x7fffffff;
              }
              ppppuVar8 = (undefined4 ****)FUN_00554060(uVar10 + 1);
              *(undefined *)ppppuVar8 = pppuStack_38._0_1_;
              pppuStack_38 = ppppuVar8;
              uStack_24 = uVar10;
            }
            iStack_28 = 0;
            ppppuVar8 = &pppuStack_68;
            if (0xf < uStack_54) {
              ppppuVar8 = (undefined4 ****)pppuStack_68;
            }
            FUN_00554150(ppppuVar8,uStack_58);
            FUN_00554150(&DAT_018c0fb8,4);
            if (iStack_28 != 0) {
              ppppuVar8 = &pppuStack_38;
              if (0xf < uStack_24) {
                ppppuVar8 = (undefined4 ****)pppuStack_38;
              }
              pcStack_3c = (char *)((int)ppppuVar8 + iStack_28);
              ppppuVar8 = &pppuStack_38;
              if (0xf < uStack_24) {
                ppppuVar8 = (undefined4 ****)pppuStack_38;
              }
              uVar3 = FUN_01686580();
              FUN_01685950(ppppuVar8,pcStack_3c,apppuStack_90,uVar3);
            }
            pcVar12 = (char *)((uint)pcStack_14 & 0xfffffff7);
            uStack_8._0_1_ = 10;
            pcStack_18 = pcVar12;
            pcStack_14 = pcVar12;
            if (0xf < uStack_24) {
              uVar10 = uStack_24 + 1;
              ppppuVar8 = (undefined4 ****)pppuStack_38;
              if (0xfff < uVar10) {
                ppppuVar8 = (undefined4 ****)pppuStack_38[-1];
                uVar10 = uStack_24 + 0x24;
                if (0x1f < (uint)((int)pppuStack_38 + (-4 - (int)ppppuVar8))) goto LAB_0058fad7;
              }
              FUN_01674ea0(ppppuVar8,uVar10);
            }
            pcStack_1c = (char *)param_1[1];
            if ((char *)param_1[2] == pcStack_1c) {
              FUN_0058cdf0(pcStack_1c,auStack_a8);
            }
            else {
              pcStack_3c = pcStack_1c;
              FUN_0054f050(auStack_a8);
              uStack_8._0_1_ = 0xe;
              FUN_0054f050(apppuStack_90);
              uStack_8._0_1_ = 0xf;
              FUN_0058d6a0(&uStack_78);
              param_1[1] = param_1[1] + 0x3c;
            }
            uStack_8._0_1_ = 9;
            if (pcStack_50 != (char *)0x0) {
              FUN_00559570(pcStack_50,pcStack_4c,&pcStack_50);
              uVar10 = ((iStack_48 - (int)pcStack_50) / 0x18) * 0x18;
              pcVar9 = pcStack_50;
              if (0xfff < uVar10) {
                pcVar9 = *(char **)(pcStack_50 + -4);
                uVar10 = uVar10 + 0x23;
                if ((char *)0x1f < pcStack_50 + (-4 - (int)pcVar9)) goto LAB_0058fad7;
              }
              FUN_01674ea0(pcVar9,uVar10);
              pcStack_50 = (char *)0x0;
              pcStack_4c = (char *)0x0;
              iStack_48 = 0;
            }
            uStack_8._0_1_ = 8;
            if (0xf < uStack_cc) {
              uVar11 = uStack_cc + 1;
              uVar10 = auStack_e0[0];
              if (0xfff < uVar11) {
                uVar10 = *(uint *)(auStack_e0[0] - 4);
                uVar11 = uStack_cc + 0x24;
                if (0x1f < (auStack_e0[0] - uVar10) - 4) goto LAB_0058fad7;
              }
              FUN_01674ea0(uVar10,uVar11);
            }
            uStack_d0 = 0;
            uStack_cc = 0xf;
            auStack_e0[0] = auStack_e0[0] & 0xffffff00;
            uStack_8._0_1_ = 7;
            if (0xf < uStack_54) {
              uVar10 = uStack_54 + 1;
              ppppuVar8 = (undefined4 ****)pppuStack_68;
              if (0xfff < uVar10) {
                ppppuVar8 = (undefined4 ****)pppuStack_68[-1];
                uVar10 = uStack_54 + 0x24;
                if (0x1f < (uint)((int)pppuStack_68 + (-4 - (int)ppppuVar8))) goto LAB_0058fad7;
              }
              FUN_01674ea0(ppppuVar8,uVar10);
            }
            uStack_8._0_1_ = 5;
            FUN_0058eb40();
            if (7 < uStack_7c) {
              uVar10 = uStack_7c * 2 + 2;
              ppppuVar8 = (undefined4 ****)apppuStack_90[0];
              if (0xfff < uVar10) {
                ppppuVar8 = (undefined4 ****)apppuStack_90[0][-1];
                uVar10 = uStack_7c * 2 + 0x25;
                if (0x1f < (uint)((int)apppuStack_90[0] + (-4 - (int)ppppuVar8))) goto LAB_0058fad7;
              }
              FUN_01674ea0(ppppuVar8,uVar10);
            }
            uStack_80 = 0;
            uStack_7c = 7;
            apppuStack_90[0] = (undefined4 ***)((uint)apppuStack_90[0] & 0xffff0000);
            if (7 < uStack_94) {
              uVar10 = uStack_94 * 2 + 2;
              uVar11 = auStack_a8[0];
              if (0xfff < uVar10) {
                uVar11 = *(uint *)(auStack_a8[0] - 4);
                uVar10 = uStack_94 * 2 + 0x25;
                if (0x1f < (auStack_a8[0] - uVar11) - 4) goto LAB_0058fad7;
              }
              FUN_01674ea0(uVar11,uVar10);
            }
          }
          else {
            FUN_0058faf0(auStack_a8,apppuStack_c0);
            uStack_8._0_1_ = 6;
            FUN_005903b0(auStack_a8);
            FUN_0058dbf0();
          }
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_005507b0();
      }
      iVar7 = FindNextFileA(iStack_c8,abStack_220);
    } while (iVar7 != 0);
  }
  LOCK();
  piVar6 = (int *)(iStack_40 + -4);
  iVar7 = *piVar6;
  *piVar6 = *piVar6 + -1;
  UNLOCK();
  if (iVar7 == 1 || iVar7 + -1 < 0) {
    (**(code **)(**(int **)(iStack_40 + -0x10) + 4))((undefined4 *)(iStack_40 + -0x10));
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4187 ; VA 0x0058faf0 ; FUN_0058faf0 */

undefined4 * FUN_0058faf0(undefined4 *param_1,undefined4 *param_2)

{
  undefined uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 ****ppppuVar6;
  uint uVar7;
  uint uVar8;
  int aiStack_ec [5];
  uint uStack_d8;
  uint auStack_d4 [4];
  undefined4 uStack_c4;
  uint uStack_c0;
  uint auStack_bc [4];
  undefined4 uStack_ac;
  uint uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_94;
  uint uStack_90;
  undefined4 ***apppuStack_8c [4];
  undefined4 uStack_7c;
  uint uStack_78;
  undefined4 *puStack_74;
  undefined4 *puStack_70;
  undefined4 ***pppuStack_68;
  undefined4 *puStack_64;
  undefined4 ***pppuStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  undefined4 ***pppuStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar5 = param_2;
  puStack_c = &LAB_0179747b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[4] = 0;
  param_1[5] = 7;
  *(undefined2 *)param_1 = 0;
  pppuStack_68 = (undefined4 ***)(param_1 + 6);
  param_1[10] = 0;
  param_1[0xb] = 7;
  *(undefined2 *)pppuStack_68 = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  puVar4 = param_1;
  if (7 < (uint)param_1[5]) {
    puVar4 = (undefined4 *)*param_1;
  }
  param_1[4] = 0;
  *(undefined2 *)puVar4 = 0;
  iVar3 = param_2[4];
  if (iVar3 != 0) {
    puVar4 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar4 = (undefined4 *)*param_2;
    }
    iStack_18 = iVar3 + (int)puVar4;
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    uVar2 = FUN_01686580();
    FUN_01685950(param_2,iStack_18,param_1,uVar2);
    iVar3 = puVar5[4];
  }
  uStack_94 = 0;
  uStack_90 = 7;
  uStack_a4 = (uint)uStack_a4._2_2_ << 0x10;
  uStack_8 = 1;
  if (iVar3 != 0) {
    puVar4 = puVar5;
    if (0xf < (uint)puVar5[5]) {
      puVar4 = (undefined4 *)*puVar5;
    }
    if (0xf < (uint)puVar5[5]) {
      puVar5 = (undefined4 *)*puVar5;
    }
    uVar2 = FUN_01686580();
    FUN_01685950(puVar5,iVar3 + (int)puVar4,&uStack_a4,uVar2);
  }
  uStack_8 = 2;
  FUN_01686c70(&pppuStack_30);
  uStack_8._0_1_ = 3;
  FUN_005569d0(&pppuStack_60);
  uStack_8._0_1_ = 5;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 5;
  if (7 < uStack_1c) {
    uVar7 = uStack_1c * 2 + 2;
    ppppuVar6 = (undefined4 ****)pppuStack_30;
    if (0xfff < uVar7) {
      ppppuVar6 = (undefined4 ****)pppuStack_30[-1];
      uVar7 = uStack_1c * 2 + 0x25;
      if (0x1f < (uint)((int)pppuStack_30 + (-4 - (int)ppppuVar6))) {
LAB_00590113:
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar6,uVar7);
  }
  uStack_20 = 0;
  pppuStack_30 = (undefined4 ***)((uint)pppuStack_30 & 0xffff0000);
  uStack_1c = 7;
  FUN_01688660(auStack_d4);
  uStack_8._0_1_ = 6;
  uStack_20 = 0;
  uVar7 = 9;
  if ((uint)uStack_50 < 9) {
    uVar7 = (uint)uStack_50;
  }
  ppppuVar6 = &pppuStack_60;
  if (0xf < uStack_50._4_4_) {
    ppppuVar6 = (undefined4 ****)pppuStack_60;
  }
  uStack_1c = 0xf;
  pppuStack_30 = (undefined4 ***)((uint)pppuStack_30 & 0xffffff00);
  FUN_005542c0(ppppuVar6,uVar7);
  uStack_14 = 5;
  FUN_005507b0();
  pppuStack_60 = pppuStack_30;
  uStack_5c = uStack_2c;
  uStack_58 = uStack_28;
  uStack_54 = uStack_24;
  uStack_50 = CONCAT44(uStack_1c,uStack_20);
  FUN_00558ce0(auStack_bc,&pppuStack_60,"*.txt");
  uStack_8._0_1_ = 7;
  FUN_0058eee0(&puStack_74,auStack_bc);
  uStack_8._0_1_ = 8;
  puStack_64 = puStack_70;
  puVar4 = puStack_74;
  if (puStack_74 != puStack_70) {
    do {
      uStack_38 = 0;
      uStack_34 = 7;
      auStack_48[0] = auStack_48[0] & 0xffff0000;
      uStack_8._0_1_ = 9;
      if (puVar4[4] != 0) {
        puVar5 = puVar4;
        if (0xf < (uint)puVar4[5]) {
          puVar5 = (undefined4 *)*puVar4;
        }
        iStack_18 = (int)puVar5 + puVar4[4];
        param_2 = puVar4;
        if (0xf < (uint)puVar4[5]) {
          param_2 = (undefined4 *)*puVar4;
        }
        uVar2 = FUN_01686580();
        FUN_01685950(param_2,iStack_18,auStack_48,uVar2);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,10);
      if (param_1[0xe] == param_1[0xd]) {
        FUN_0058d1c0(param_1[0xd],auStack_48);
      }
      else {
        FUN_0054f050(auStack_48);
        param_1[0xd] = param_1[0xd] + 0x18;
      }
      uStack_8._0_1_ = 8;
      if (7 < uStack_34) {
        uVar7 = uStack_34 * 2 + 2;
        uVar8 = auStack_48[0];
        if (0xfff < uVar7) {
          uVar8 = *(uint *)(auStack_48[0] - 4);
          uVar7 = uStack_34 * 2 + 0x25;
          uVar1 = (undefined)uStack_8;
          if (0x1f < (auStack_48[0] - uVar8) - 4) goto LAB_00590113;
        }
        FUN_01674ea0(uVar8,uVar7);
      }
      puVar4 = puVar4 + 6;
    } while (puVar4 != puStack_64);
  }
  puVar4 = (undefined4 *)FUN_00558ce0(aiStack_ec,&pppuStack_60,&DAT_018c0fb8);
  uStack_38 = 0;
  uStack_34 = 7;
  auStack_48[0] = auStack_48[0] & 0xffff0000;
  iVar3 = puVar4[4];
  uStack_8._0_1_ = 0xc;
  if (iVar3 != 0) {
    puVar5 = puVar4;
    if (0xf < (uint)puVar4[5]) {
      puVar5 = (undefined4 *)*puVar4;
    }
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    uVar2 = FUN_01686580();
    FUN_01685950(puVar4,(int)puVar5 + iVar3,auStack_48,uVar2);
  }
  uStack_8._0_1_ = 0xd;
  FUN_0054f050(auStack_d4);
  uStack_8._0_1_ = 0xe;
  uVar2 = FUN_01686150(auStack_48);
  FUN_0054f050(uVar2);
  uStack_14 = 0xd;
  uStack_8._0_1_ = 0xd;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xd;
  if (7 < uStack_1c) {
    uVar7 = uStack_1c * 2 + 2;
    ppppuVar6 = (undefined4 ****)pppuStack_30;
    if (0xfff < uVar7) {
      ppppuVar6 = (undefined4 ****)pppuStack_30[-1];
      uVar7 = uStack_1c * 2 + 0x25;
      if (0x1f < (uint)((int)pppuStack_30 + (-4 - (int)ppppuVar6))) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar6,uVar7);
  }
  uStack_20 = 0;
  uStack_1c = 7;
  pppuStack_30 = (undefined4 ***)((uint)pppuStack_30 & 0xffff0000);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  if ((undefined4 ****)pppuStack_68 != apppuStack_8c) {
    ppppuVar6 = apppuStack_8c;
    if (7 < uStack_78) {
      ppppuVar6 = (undefined4 ****)apppuStack_8c[0];
    }
    FUN_0058ed10(ppppuVar6,uStack_7c);
  }
  if (7 < uStack_78) {
    uVar7 = uStack_78 * 2 + 2;
    ppppuVar6 = (undefined4 ****)apppuStack_8c[0];
    if (0xfff < uVar7) {
      ppppuVar6 = (undefined4 ****)apppuStack_8c[0][-1];
      uVar7 = uStack_78 * 2 + 0x25;
      if (0x1f < (uint)((int)apppuStack_8c[0] + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar6,uVar7);
  }
  if (7 < uStack_34) {
    uVar7 = uStack_34 * 2 + 2;
    uVar8 = auStack_48[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_48[0] - 4);
      uVar7 = uStack_34 * 2 + 0x25;
      if (0x1f < (auStack_48[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  uStack_38 = 0;
  uStack_34 = 7;
  auStack_48[0] = auStack_48[0] & 0xffff0000;
  if (0xf < uStack_d8) {
    uVar7 = uStack_d8 + 1;
    iVar3 = aiStack_ec[0];
    if (0xfff < uVar7) {
      iVar3 = *(int *)(aiStack_ec[0] + -4);
      uVar7 = uStack_d8 + 0x24;
      if (0x1f < (aiStack_ec[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar7);
  }
  thunk_FUN_00577a40();
  if (0xf < uStack_a8) {
    uVar8 = uStack_a8 + 1;
    uVar7 = auStack_bc[0];
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(auStack_bc[0] - 4);
      uVar8 = uStack_a8 + 0x24;
      if (0x1f < (auStack_bc[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  uStack_ac = 0;
  uStack_a8 = 0xf;
  auStack_bc[0] = auStack_bc[0] & 0xffffff00;
  if (7 < uStack_c0) {
    uVar7 = uStack_c0 * 2 + 2;
    uVar8 = auStack_d4[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_d4[0] - 4);
      uVar7 = uStack_c0 * 2 + 0x25;
      if (0x1f < (auStack_d4[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  uStack_c4 = 0;
  uStack_c0 = 7;
  auStack_d4[0] = auStack_d4[0] & 0xffff0000;
  if (0xf < uStack_50._4_4_) {
    uVar7 = uStack_50._4_4_ + 1;
    ppppuVar6 = (undefined4 ****)pppuStack_60;
    if (0xfff < uVar7) {
      ppppuVar6 = (undefined4 ****)pppuStack_60[-1];
      uVar7 = uStack_50._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppuStack_60 + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar6,uVar7);
  }
  uStack_50 = 0xf00000000;
  pppuStack_60 = (undefined4 ***)((uint)pppuStack_60 & 0xffffff00);
  if (7 < uStack_90) {
    uVar7 = uStack_90 * 2 + 2;
    iVar3 = uStack_a4;
    if (0xfff < uVar7) {
      iVar3 = *(int *)(uStack_a4 + -4);
      uVar7 = uStack_90 * 2 + 0x25;
      if (0x1f < (uStack_a4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar7);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4188 ; VA 0x00590150 ; FUN_00590150 */

undefined4 FUN_00590150(void)

{
  return DAT_01ea8b10;
}



/* FUNCTION 4189 ; VA 0x00590160 ; FUN_00590160 */

undefined4 FUN_00590160(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_00590180();
  FUN_0054ef60(iVar1 + 0x1c);
  return param_1;
}



/* FUNCTION 4190 ; VA 0x00590180 ; FUN_00590180 */

undefined4 __fastcall FUN_00590180(undefined4 param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017974ab;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8b40) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ea8b40,param_1);
    if (DAT_01ea8b40 == -1) {
      uStack_8 = 0;
      iVar1 = FUN_01674e20(0x34);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (iVar1 == 0) {
        DAT_01ea8b3c = 0;
      }
      else {
        DAT_01ea8b3c = FUN_0058d790(iVar1);
      }
      FUN_016f37bf(&DAT_01ea8b40);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ea8b3c;
}



/* FUNCTION 4191 ; VA 0x00590220 ; FUN_00590220 */

uint FUN_00590220(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  code *pcVar2;
  int *piVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017974c8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_005527b0();
  if (piVar3 != (int *)0x0) {
    iStack_14 = (**(code **)(*piVar3 + 0xc))();
    iStack_14 = iStack_14 + 0x10;
    uStack_8 = 1;
    FUN_0058e3f0(&iStack_14,"Assertion failed: %s\n%s(%d)",param_1,param_2,param_3);
    iVar1 = iStack_14;
    FUN_0058e6c0(2,iStack_14);
    puVar5 = (undefined4 *)(iVar1 + -0x10);
    LOCK();
    piVar3 = (int *)(iVar1 + -4);
    iVar1 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    uVar4 = iVar1 - 1;
    if ((int)uVar4 < 1) {
      uVar4 = (**(code **)(*(int *)*puVar5 + 4))(puVar5);
    }
    ExceptionList = pvStack_10;
    return uVar4 & 0xffffff00;
  }
  FUN_005522b0(0x80004005);
  pcVar2 = (code *)swi(3);
  uVar4 = (*pcVar2)();
  return uVar4;
}



/* FUNCTION 4192 ; VA 0x005902c0 ; FUN_005902c0 */

void FUN_005902c0(undefined4 param_1)

{
  FUN_0058e6c0(4,param_1);
  return;
}



/* FUNCTION 4193 ; VA 0x005902e0 ; FUN_005902e0 */

void FUN_005902e0(void)

{
  FUN_0058dfb0(&DAT_018bd1cc,0x400,0xe);
  FUN_0058dfb0("archive\\",0x400,0xe);
  return;
}



/* FUNCTION 4194 ; VA 0x00590310 ; FUN_00590310 */

void FUN_00590310(void)

{
  int iVar1;
  code *pcVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017974c8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_005527b0();
  if (piVar3 != (int *)0x0) {
    iStack_14 = (**(code **)(*piVar3 + 0xc))();
    iStack_14 = iStack_14 + 0x10;
    uStack_8 = 1;
    FUN_0058e3f0(&iStack_14,"Pure Call Error");
    iVar1 = iStack_14;
    FUN_0058e6c0(1,iStack_14);
    FUN_01675310("PureCallError",&DAT_018bc9b8);
    puVar4 = (undefined4 *)(iVar1 + -0x10);
    LOCK();
    piVar3 = (int *)(iVar1 + -4);
    iVar1 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (iVar1 == 1 || iVar1 + -1 < 0) {
      (**(code **)(*(int *)*puVar4 + 4))(puVar4);
    }
    ExceptionList = pvStack_10;
    return;
  }
  FUN_005522b0(0x80004005);
  pcVar2 = (code *)swi(3);
  (*pcVar2)();
  return;
}



/* FUNCTION 4195 ; VA 0x005903b0 ; FUN_005903b0 */

void __thiscall FUN_005903b0(int param_1,int param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017974f3;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 8) != *(int *)(param_1 + 4)) {
    ExceptionList = &pvStack_10;
    FUN_0054f050(param_2);
    uStack_8 = 0;
    FUN_0054f050(param_2 + 0x18);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_0058d6a0(param_2 + 0x30);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x3c;
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_0058cdf0(*(int *)(param_1 + 4),param_2);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4196 ; VA 0x00590440 ; FUN_00590440 */

void __thiscall FUN_00590440(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    puVar1[4] = 0;
    puVar1[5] = 0;
    uVar2 = param_2[1];
    uVar3 = param_2[2];
    uVar4 = param_2[3];
    *puVar1 = *param_2;
    puVar1[1] = uVar2;
    puVar1[2] = uVar3;
    puVar1[3] = uVar4;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(param_2 + 4);
    param_2[4] = 0;
    param_2[5] = 0xf;
    *(undefined *)param_2 = 0;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x18;
    return;
  }
  FUN_0058d0a0(puVar1,param_2);
  return;
}



/* FUNCTION 4197 ; VA 0x005904a0 ; FUN_005904a0 */

undefined4 __thiscall
FUN_005904a0(undefined4 *param_1,int *param_2,char *param_3,undefined4 *param_4)

{
  uint uVar1;
  char cVar2;
  int iVar3;
  char *pcVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int iVar7;
  char *pcVar8;
  bool bVar9;
  undefined4 *puStack_c;
  
  if (param_1[0xd] == 0) {
    pcVar4 = (char *)*param_2;
    while (pcVar4 != param_3) {
      if (param_1[10] == 0) {
        if (*(char *)((int)param_1 + 0x31) == '\0') break;
        iVar3 = FUN_0171dc29((int)*pcVar4);
        bVar9 = iVar3 == 0;
        pcVar4 = (char *)*param_2;
      }
      else {
        puVar5 = param_1 + 6;
        if (0xf < (uint)param_1[0xb]) {
          puVar5 = (undefined4 *)*puVar5;
        }
        if ((param_1[10] == 0) ||
           (iVar3 = FUN_0170db20(puVar5,(int)*pcVar4,param_1[10]), iVar3 == 0)) {
          bVar9 = true;
        }
        else {
          bVar9 = iVar3 - (int)puVar5 == -1;
        }
      }
      if (bVar9) break;
      pcVar4 = pcVar4 + 1;
      *param_2 = (int)pcVar4;
    }
  }
  pcVar4 = (char *)*param_2;
  puVar5 = param_4;
  if (param_1[0xd] == 0) {
    if (pcVar4 == param_3) {
      return 0;
    }
    cVar2 = FUN_005913c0(*pcVar4);
    if (cVar2 == '\0') {
      pcVar8 = (char *)*param_2;
      while (pcVar8 != param_3) {
        if (param_1[10] == 0) {
          if (*(char *)((int)param_1 + 0x31) != '\0') {
            iVar3 = FUN_0171dc29((int)*pcVar8);
            bVar9 = iVar3 == 0;
            pcVar8 = (char *)*param_2;
            goto LAB_005905d1;
          }
        }
        else {
          puVar6 = param_1 + 6;
          if (0xf < (uint)param_1[0xb]) {
            puVar6 = (undefined4 *)*puVar6;
          }
          if ((param_1[10] == 0) ||
             (iVar3 = FUN_0170db20(puVar6,(int)*pcVar8,param_1[10]), iVar3 == 0)) {
            bVar9 = true;
          }
          else {
            bVar9 = iVar3 - (int)puVar6 == -1;
          }
LAB_005905d1:
          if (!bVar9) break;
        }
        iVar3 = param_1[4];
        if (iVar3 == 0) {
          if (*(char *)(param_1 + 0xc) != '\0') {
            iVar3 = FUN_0171dbf8((int)*pcVar8);
            bVar9 = iVar3 == 0;
            pcVar8 = (char *)*param_2;
            goto LAB_0059063a;
          }
        }
        else {
          puStack_c = param_1;
          if (0xf < (uint)param_1[5]) {
            puStack_c = (undefined4 *)*param_1;
          }
          if ((iVar3 == 0) || (iVar3 = FUN_0170db20(puStack_c,(int)*pcVar8,iVar3), iVar3 == 0)) {
            bVar9 = true;
          }
          else {
            bVar9 = iVar3 - (int)puStack_c == -1;
          }
LAB_0059063a:
          if (!bVar9) break;
        }
        pcVar8 = pcVar8 + 1;
        *param_2 = (int)pcVar8;
      }
    }
    else {
      *param_2 = *param_2 + 1;
    }
  }
  else {
    if (pcVar4 == param_3) {
      if (*(char *)(param_1 + 0xe) != '\0') {
        return 0;
      }
      *(undefined *)(param_1 + 0xe) = 1;
      iVar3 = *param_2;
      uVar1 = param_4[5];
      puVar6 = param_4;
      if (0xf < uVar1) {
        puVar6 = (undefined4 *)*param_4;
      }
      if (0xf < uVar1) {
        puVar5 = (undefined4 *)*param_4;
      }
      iVar7 = (int)puVar6 + (param_4[4] - (int)puVar5);
      if (0xf < uVar1) {
        param_4 = (undefined4 *)*param_4;
      }
      goto LAB_005907c7;
    }
    cVar2 = FUN_005913c0(*pcVar4);
    if (cVar2 == '\0') {
      if ((*(char *)(param_1 + 0xe) != '\0') ||
         (cVar2 = FUN_00591350(*(undefined *)*param_2), cVar2 == '\0')) {
        cVar2 = FUN_00591350(*(undefined *)*param_2);
        if (cVar2 == '\0') {
          pcVar8 = (char *)*param_2;
        }
        else {
          *param_2 = *param_2 + 1;
          pcVar8 = (char *)*param_2;
          pcVar4 = pcVar8;
        }
        while (pcVar8 != param_3) {
          if (param_1[10] == 0) {
            if (*(char *)((int)param_1 + 0x31) != '\0') {
              iVar3 = FUN_0171dc29((int)*pcVar8);
              bVar9 = iVar3 == 0;
              pcVar8 = (char *)*param_2;
              goto LAB_00590771;
            }
          }
          else {
            puVar6 = param_1 + 6;
            if (0xf < (uint)param_1[0xb]) {
              puVar6 = (undefined4 *)*puVar6;
            }
            if ((param_1[10] == 0) ||
               (iVar3 = FUN_0170db20(puVar6,(int)*pcVar8,param_1[10]), iVar3 == 0)) {
              bVar9 = true;
            }
            else {
              bVar9 = iVar3 - (int)puVar6 == -1;
            }
LAB_00590771:
            if (!bVar9) break;
          }
          cVar2 = FUN_005913c0(*pcVar8);
          if (cVar2 != '\0') break;
          pcVar8 = (char *)(*param_2 + 1);
          *param_2 = (int)pcVar8;
        }
      }
      *(undefined *)(param_1 + 0xe) = 1;
    }
    else if (*(char *)(param_1 + 0xe) == '\0') {
      *(undefined *)(param_1 + 0xe) = 1;
    }
    else {
      *param_2 = *param_2 + 1;
      *(undefined *)(param_1 + 0xe) = 0;
    }
  }
  iVar3 = *param_2;
  uVar1 = param_4[5];
  puVar6 = param_4;
  if (0xf < uVar1) {
    puVar6 = (undefined4 *)*param_4;
  }
  if (0xf < uVar1) {
    puVar5 = (undefined4 *)*param_4;
  }
  iVar7 = (int)puVar6 + (param_4[4] - (int)puVar5);
  if (0xf < uVar1) {
    param_4 = (undefined4 *)*param_4;
  }
LAB_005907c7:
  FUN_00591430((int)puVar5 - (int)param_4,iVar7,pcVar4,iVar3 - (int)pcVar4);
  return 1;
}



/* FUNCTION 4198 ; VA 0x005907f0 ; FUN_005907f0 */

undefined2 * __thiscall FUN_005907f0(undefined2 *param_1,short *param_2)

{
  short sVar1;
  short *psVar2;
  
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 10) = 7;
  *param_1 = 0;
  psVar2 = param_2;
  do {
    sVar1 = *psVar2;
    psVar2 = psVar2 + 1;
  } while (sVar1 != 0);
  FUN_0058ed10(param_2,(int)psVar2 - (int)(param_2 + 1) >> 1);
  return param_1;
}



/* FUNCTION 4199 ; VA 0x00590840 ; FUN_00590840 */

int __thiscall FUN_00590840(int param_1)

{
  int *piVar1;
  undefined uVar2;
  undefined uStack00000034;
  undefined uStack00000035;
  undefined4 in_stack_00000038;
  undefined in_stack_0000003c;
  int in_stack_00000040;
  undefined4 in_stack_00000044;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01797523;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&stack0x00000004);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(&stack0x0000001c);
  *(undefined *)(param_1 + 0x30) = uStack00000034;
  *(undefined *)(param_1 + 0x31) = uStack00000035;
  *(undefined4 *)(param_1 + 0x34) = in_stack_00000038;
  *(undefined *)(param_1 + 0x38) = in_stack_0000003c;
  piVar1 = (int *)(param_1 + 0x3c);
  *piVar1 = in_stack_00000040;
  *(undefined4 *)(param_1 + 0x40) = in_stack_00000044;
  *(undefined *)(param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0xf;
  *(undefined *)(param_1 + 0x48) = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (*(char *)(param_1 + 0x44) == '\0') {
    if (*piVar1 == *(int *)(param_1 + 0x40)) {
      uVar2 = 0;
    }
    else {
      uVar2 = FUN_005904a0(piVar1,*(undefined4 *)(param_1 + 0x40),(undefined *)(param_1 + 0x48));
    }
    *(undefined *)(param_1 + 0x44) = uVar2;
  }
  FUN_005509f0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4200 ; VA 0x00590910 ; FUN_00590910 */

undefined4 * __fastcall FUN_00590910(undefined4 *param_1)

{
  param_1[1] = 0;
  param_1[4] = 0;
  *param_1 = 0x4e40000;
  param_1[2] = 0;
  param_1[3] = 0;
  return param_1;
}



/* FUNCTION 4201 ; VA 0x00590940 ; FUN_00590940 */

void __fastcall FUN_00590940(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x5c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x48);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)(param_1 + 0x5c) = 0xf;
  *(undefined *)(param_1 + 0x48) = 0;
  FUN_005509f0();
  return;
}



/* FUNCTION 4202 ; VA 0x005909a0 ; FUN_005909a0 */

void FUN_005909a0(void)

{
  FUN_005509f0();
  return;
}



/* FUNCTION 4203 ; VA 0x005909b0 ; FUN_005909b0 */

void __fastcall FUN_005909b0(undefined4 *param_1)

{
  param_1[4] = 0;
  if (param_1[1] != 0) {
    FUN_01674ea0(param_1[1]);
    param_1[1] = 0;
  }
  *param_1 = 0x4e40000;
  param_1[2] = 0;
  param_1[3] = 0;
  return;
}



/* FUNCTION 4204 ; VA 0x005909f0 ; FUN_005909f0 */

/* WARNING: Removing unreachable block (ram,0x00590da2) */
/* WARNING: Removing unreachable block (ram,0x00590db3) */
/* WARNING: Removing unreachable block (ram,0x00590dc7) */

undefined * FUN_005909f0(undefined *param_1)

{
  undefined4 ****ppppuVar1;
  uint uVar2;
  bool bVar3;
  undefined auStack_1a4 [48];
  undefined uStack_174;
  undefined uStack_173;
  undefined4 uStack_170;
  uint *puStack_16c;
  undefined4 ***pppuStack_168;
  undefined4 ***pppuStack_164;
  uint uStack_118;
  int iStack_114;
  char cStack_110;
  undefined4 ***pppuStack_10c;
  uint uStack_f8;
  uint auStack_f4 [4];
  undefined4 uStack_e4;
  uint uStack_e0;
  undefined4 ***apppuStack_dc [4];
  int iStack_cc;
  uint uStack_c8;
  undefined auStack_a0 [16];
  undefined4 uStack_90;
  undefined4 uStack_8c;
  uint uStack_88;
  int iStack_84;
  char cStack_80;
  undefined4 ***pppuStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined2 uStack_70;
  undefined4 uStack_6c;
  uint uStack_68;
  undefined4 ***pppuStack_64;
  undefined4 ***pppuStack_60;
  undefined auStack_5c [24];
  undefined auStack_44 [24];
  undefined uStack_2c;
  undefined uStack_2b;
  undefined4 uStack_28;
  undefined uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017975b3;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  pppuStack_164 = (undefined4 ***)0xb;
  pppuStack_168 = (undefined4 ***)0x18c1034;
  uStack_8 = 0;
  uStack_e4 = 0;
  uStack_e0 = 0xf;
  auStack_f4[0] = auStack_f4[0] & 0xffffff00;
  puStack_16c = (uint *)0x590a4e;
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  pppuStack_164 = (undefined4 ***)auStack_f4;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  pppuStack_168 = apppuStack_dc;
  puStack_16c = (uint *)0x590a6a;
  FUN_00590fa0();
  uStack_14 = 2;
  uStack_8._0_1_ = 0;
  if (0xf < uStack_e0) {
    pppuStack_164 = (undefined4 ***)(uStack_e0 + 1);
    uVar2 = auStack_f4[0];
    if (0xfff < pppuStack_164) {
      uVar2 = *(uint *)(auStack_f4[0] - 4);
      pppuStack_164 = (undefined4 ***)(uStack_e0 + 0x24);
      if (0x1f < (auStack_f4[0] - uVar2) - 4) {
LAB_00590ee7:
                    /* WARNING: Subroutine does not return */
        pppuStack_164 = (undefined4 ***)0x590eec;
        FUN_017167a3();
      }
    }
    puStack_16c = (uint *)0x590aac;
    pppuStack_168 = (undefined4 ***)uVar2;
    FUN_01674ea0();
  }
  uStack_90 = 0;
  uStack_8c = 0xf;
  auStack_a0[0] = 0;
  pppuStack_164 = (undefined4 ***)0x3;
  pppuStack_168 = (undefined4 ***)&DAT_018c102c;
  uStack_8._0_1_ = 3;
  uStack_8._1_3_ = 0;
  uStack_78 = 0;
  uStack_74 = 0xf;
  uStack_88 = uStack_88 & 0xffffff00;
  puStack_16c = (uint *)0x590afc;
  FUN_005542c0();
  uStack_70 = 0;
  uStack_6c = 0;
  uStack_68 = uStack_68 & 0xffffff00;
  pppuStack_64 = apppuStack_dc;
  if (0xf < uStack_c8) {
    pppuStack_64 = apppuStack_dc[0];
  }
  pppuStack_60 = apppuStack_dc;
  if (0xf < uStack_c8) {
    pppuStack_60 = apppuStack_dc[0];
  }
  pppuStack_60 = (undefined4 ***)(iStack_cc + (int)pppuStack_60);
  uStack_8._0_1_ = 5;
  puStack_18 = auStack_5c;
  pppuStack_164 = (undefined4 ***)auStack_a0;
  pppuStack_168 = (undefined4 ***)0x590b55;
  FUN_0054ef60();
  pppuStack_164 = (undefined4 ***)&uStack_88;
  uStack_8._0_1_ = 6;
  pppuStack_168 = (undefined4 ***)0x590b68;
  FUN_0054ef60();
  uStack_2c = (undefined)uStack_70;
  uStack_2b = uStack_70._1_1_;
  uStack_28 = uStack_6c;
  uStack_24 = (undefined)uStack_68;
  uStack_8._0_1_ = 8;
  pppuStack_164 = (undefined4 ***)0x590b8f;
  FUN_005509f0();
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  pppuStack_164 = pppuStack_60;
  uStack_14 = 3;
  pppuStack_168 = pppuStack_64;
  puStack_18 = auStack_1a4;
  FUN_0054ef60(auStack_5c);
  uStack_8._0_1_ = 9;
  FUN_0054ef60(auStack_44);
  uStack_174 = uStack_2c;
  uStack_173 = uStack_2b;
  uStack_170 = uStack_28;
  puStack_16c = (uint *)CONCAT31(puStack_16c._1_3_,uStack_24);
  uStack_8._0_1_ = 8;
  FUN_00590840();
  uVar2 = 7;
  uStack_14 = 7;
  uStack_8._0_1_ = 10;
  do {
    pppuStack_164 = pppuStack_60;
    pppuStack_168 = pppuStack_60;
    puStack_1c = auStack_1a4;
    puStack_18 = (undefined *)uVar2;
    FUN_0054ef60(auStack_5c);
    uStack_8._0_1_ = 0xb;
    FUN_0054ef60(auStack_44);
    uStack_174 = uStack_2c;
    uStack_173 = uStack_2b;
    uStack_170 = uStack_28;
    puStack_16c = (uint *)CONCAT31(puStack_16c._1_3_,uStack_24);
    uStack_8._0_1_ = 10;
    FUN_00590840();
    uStack_14 = uVar2 | 8;
    if ((cStack_110 == '\0') || (cStack_80 == '\0')) {
      bVar3 = cStack_110 != cStack_80;
    }
    else if ((uStack_118 == uStack_88) && (iStack_114 == iStack_84)) {
      bVar3 = false;
    }
    else {
      bVar3 = true;
    }
    if (0xf < uStack_f8) {
      pppuStack_164 = (undefined4 ***)(uStack_f8 + 1);
      ppppuVar1 = (undefined4 ****)pppuStack_10c;
      if (0xfff < pppuStack_164) {
        ppppuVar1 = (undefined4 ****)pppuStack_10c[-1];
        pppuStack_164 = (undefined4 ***)(uStack_f8 + 0x24);
        if (0x1f < (uint)((int)pppuStack_10c + (-4 - (int)ppppuVar1))) goto LAB_00590ee7;
      }
      puStack_16c = (uint *)0x590cd1;
      pppuStack_168 = ppppuVar1;
      FUN_01674ea0();
    }
    pppuStack_164 = (undefined4 ***)0x590cfa;
    FUN_005509f0();
    if (!bVar3) {
      if (0xf < uStack_68) {
        pppuStack_164 = (undefined4 ***)(uStack_68 + 1);
        ppppuVar1 = (undefined4 ****)pppuStack_7c;
        if (0xfff < pppuStack_164) {
          ppppuVar1 = (undefined4 ****)pppuStack_7c[-1];
          pppuStack_164 = (undefined4 ***)(uStack_68 + 0x24);
          if (0x1f < (uint)((int)pppuStack_7c + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
            pppuStack_164 = (undefined4 ***)0x590ef1;
            FUN_017167a3();
          }
        }
        puStack_16c = (uint *)0x590e73;
        pppuStack_168 = ppppuVar1;
        FUN_01674ea0();
      }
      uStack_6c = 0;
      uStack_68 = 0xf;
      pppuStack_7c = (undefined4 ***)((uint)pppuStack_7c & 0xffffff00);
      pppuStack_164 = (undefined4 ***)0x590e93;
      FUN_005509f0();
      pppuStack_164 = (undefined4 ***)0x590e9b;
      FUN_005509f0();
      if (0xf < uStack_c8) {
        pppuStack_164 = (undefined4 ***)(uStack_c8 + 1);
        ppppuVar1 = (undefined4 ****)apppuStack_dc[0];
        if (0xfff < pppuStack_164) {
          ppppuVar1 = (undefined4 ****)apppuStack_dc[0][-1];
          pppuStack_164 = (undefined4 ***)(uStack_c8 + 0x24);
          if (0x1f < (uint)((int)apppuStack_dc[0] + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
            pppuStack_164 = (undefined4 ***)&UNK_00590ef6;
            FUN_017167a3();
          }
        }
        puStack_16c = (uint *)0x590ece;
        pppuStack_168 = ppppuVar1;
        FUN_01674ea0();
      }
      ExceptionList = pvStack_10;
      return param_1;
    }
    pppuStack_164 = pppuStack_60;
    pppuStack_168 = pppuStack_64;
    puStack_20 = auStack_1a4;
    FUN_0054ef60(auStack_5c);
    uStack_8._0_1_ = 0xc;
    FUN_0054ef60(auStack_44);
    uStack_174 = uStack_2c;
    uStack_173 = uStack_2b;
    uStack_170 = uStack_28;
    puStack_16c = (uint *)CONCAT31(puStack_16c._1_3_,uStack_24);
    uStack_8._0_1_ = 10;
    FUN_00590840();
    uVar2 = (uint)puStack_18 | 0x18;
    if ((cStack_110 == '\0') || (cStack_80 == '\0')) {
      bVar3 = cStack_110 != cStack_80;
    }
    else if ((uStack_118 == uStack_88) && (iStack_114 == iStack_84)) {
      bVar3 = false;
    }
    else {
      bVar3 = true;
    }
    uStack_f8 = 0xf;
    pppuStack_10c = (undefined4 ***)((uint)pppuStack_10c & 0xffffff00);
    pppuStack_164 = (undefined4 ***)0x590df7;
    uStack_14 = uVar2;
    FUN_005509f0();
    if (bVar3) {
      pppuStack_164 = (undefined4 ***)0x1;
      pppuStack_168 = (undefined4 ***)&DAT_018c1030;
      puStack_16c = (uint *)0x590e0a;
      FUN_00554150();
    }
    pppuStack_164 = (undefined4 ***)uStack_6c;
    pppuStack_168 = &pppuStack_7c;
    if (0xf < uStack_68) {
      pppuStack_168 = pppuStack_7c;
    }
    puStack_16c = (uint *)0x590e21;
    FUN_00554150();
    pppuStack_164 = &pppuStack_7c;
    pppuStack_168 = (undefined4 ***)iStack_84;
    puStack_16c = &uStack_88;
    uStack_170 = 0x590e3a;
    cStack_80 = FUN_005904a0();
  } while( true );
}



/* FUNCTION 4205 ; VA 0x00590f00 ; FUN_00590f00 */

undefined4 FUN_00590f00(undefined4 param_1)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("FileVersion",0xb);
  uStack_8 = 0;
  FUN_00590fa0(param_1,auStack_28);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4206 ; VA 0x00590fa0 ; FUN_00590fa0 */

undefined * __thiscall FUN_00590fa0(undefined2 *param_1,undefined *param_2,char *param_3)

{
  char cVar1;
  undefined4 ****ppppuVar2;
  int iVar3;
  char *pcVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 ***apppuStack_30 [5];
  uint uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017975e1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_2 + 0x10) = 0;
  *(undefined4 *)(param_2 + 0x14) = 0xf;
  *param_2 = 0;
  uStack_8 = 0;
  uStack_14 = 1;
  puVar5 = (undefined4 *)param_3;
  if (0xf < *(uint *)((int)param_3 + 0x14)) {
    puVar5 = *(undefined4 **)param_3;
  }
  FUN_01675640(apppuStack_30,"\\StringFileInfo\\%04x%04x\\%s",*param_1,param_1[1],puVar5);
  uStack_8 = 1;
  param_3 = (char *)0x0;
  ppppuVar2 = apppuStack_30;
  if (0xf < uStack_1c) {
    ppppuVar2 = (undefined4 ****)apppuStack_30[0];
  }
  uStack_18 = 0;
  iVar3 = VerQueryValueA(*(undefined4 *)(param_1 + 2),ppppuVar2,&param_3,&uStack_18);
  if (iVar3 != 0) {
    pcVar4 = param_3;
    do {
      cVar1 = *pcVar4;
      pcVar4 = pcVar4 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(param_3,(int)pcVar4 - (int)(param_3 + 1));
  }
  if (0xf < uStack_1c) {
    uVar6 = uStack_1c + 1;
    ppppuVar2 = (undefined4 ****)apppuStack_30[0];
    if (0xfff < uVar6) {
      ppppuVar2 = (undefined4 ****)apppuStack_30[0][-1];
      uVar6 = uStack_1c + 0x24;
      if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar6);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 4207 ; VA 0x005910b0 ; FUN_005910b0 */

undefined4 __thiscall FUN_005910b0(undefined4 *param_1,uint param_2)

{
  short sVar1;
  undefined2 *puVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int iVar5;
  short *psVar6;
  uint uVar7;
  undefined4 uVar8;
  undefined auStack_61c [1000];
  short sStack_234;
  undefined auStack_232 [518];
  undefined4 uStack_2c;
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017975f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  GetModuleFileNameW(param_2,auStack_61c,500);
  GetShortPathNameW(auStack_61c,&sStack_234,0x104);
  uStack_1c = 0;
  psVar6 = &sStack_234;
  uStack_18 = 7;
  uStack_2c = (undefined4 *)((uint)uStack_2c._2_2_ << 0x10);
  do {
    sVar1 = *psVar6;
    psVar6 = psVar6 + 1;
  } while (sVar1 != 0);
  FUN_0058ed10(&sStack_234,(int)psVar6 - (int)auStack_232 >> 1);
  uStack_8 = 0;
  param_1[4] = 0;
  if (param_1[1] != 0) {
    FUN_01674ea0(param_1[1]);
    param_1[1] = 0;
  }
  uVar8 = 0;
  *param_1 = 0x4e40000;
  param_1[2] = 0;
  puVar3 = &uStack_2c;
  if (7 < uStack_18) {
    puVar3 = uStack_2c;
  }
  param_1[3] = 0;
  uStack_14 = 0;
  param_2 = GetFileVersionInfoSizeW(puVar3,&uStack_14);
  if (param_2 != 0) {
    uVar4 = FUN_01674e20(param_2);
    param_1[1] = uVar4;
    puVar3 = &uStack_2c;
    if (7 < uStack_18) {
      puVar3 = uStack_2c;
    }
    iVar5 = GetFileVersionInfoW(puVar3,uStack_14,param_2,uVar4);
    if (iVar5 != 0) {
      param_2 = 0;
      iVar5 = VerQueryValueA(param_1[1],&DAT_018bd1cc,param_1 + 4,&param_2);
      if (iVar5 != 0) {
        iVar5 = VerQueryValueA(param_1[1],"\\VarFileInfo\\Translation",param_1 + 2,&param_2);
        if ((iVar5 != 0) && (3 < param_2)) {
          puVar2 = (undefined2 *)param_1[2];
          param_1[3] = param_2 >> 2;
          *(undefined2 *)param_1 = *puVar2;
          *(undefined2 *)((int)param_1 + 2) = puVar2[1];
        }
        uVar8 = 1;
        goto LAB_0059122e;
      }
    }
  }
  if (param_1[1] != 0) {
    FUN_01674ea0(param_1[1]);
    param_1[1] = 0;
  }
LAB_0059122e:
  if (7 < uStack_18) {
    uVar7 = uStack_18 * 2 + 2;
    puVar3 = uStack_2c;
    if (0xfff < uVar7) {
      puVar3 = (undefined4 *)uStack_2c[-1];
      uVar7 = uStack_18 * 2 + 0x25;
      if (0x1f < (uint)((int)uStack_2c + (-4 - (int)puVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar3,uVar7);
  }
  ExceptionList = pvStack_10;
  return uVar8;
}



/* FUNCTION 4208 ; VA 0x00591280 ; FUN_00591280 */

undefined4 __thiscall FUN_00591280(int param_1,undefined4 param_2)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797618;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_1 + 8);
  uStack_8 = 0;
  FUN_0054ef60(param_1 + 0x20);
  uStack_8 = 0xffffffff;
  FUN_00590840();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 4209 ; VA 0x00591310 ; FUN_00591310 */

int __thiscall FUN_00591310(undefined4 *param_1,char param_2,uint param_3)

{
  uint *puVar1;
  int iVar2;
  
  puVar1 = param_1 + 4;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  if (param_3 < *puVar1) {
    iVar2 = FUN_0170db20((int)param_1 + param_3,(int)param_2,*puVar1 - param_3);
    if (iVar2 != 0) {
      return iVar2 - (int)param_1;
    }
  }
  return -1;
}



/* FUNCTION 4210 ; VA 0x00591350 ; FUN_00591350 */

bool __thiscall FUN_00591350(int param_1,char param_2)

{
  int iVar1;
  undefined4 *puVar2;
  
  if (*(int *)(param_1 + 0x28) == 0) {
    if (*(char *)(param_1 + 0x31) != '\0') {
      iVar1 = FUN_0171dc29((int)param_2);
      return iVar1 != 0;
    }
    return false;
  }
  puVar2 = (undefined4 *)(param_1 + 0x18);
  if (0xf < *(uint *)(param_1 + 0x2c)) {
    puVar2 = (undefined4 *)*puVar2;
  }
  if (*(int *)(param_1 + 0x28) != 0) {
    iVar1 = FUN_0170db20(puVar2,(int)param_2,*(int *)(param_1 + 0x28));
    if (iVar1 != 0) {
      return iVar1 - (int)puVar2 != -1;
    }
  }
  return false;
}



/* FUNCTION 4211 ; VA 0x005913c0 ; FUN_005913c0 */

bool __thiscall FUN_005913c0(undefined4 *param_1,char param_2)

{
  int iVar1;
  
  iVar1 = param_1[4];
  if (iVar1 == 0) {
    if (*(char *)(param_1 + 0xc) != '\0') {
      iVar1 = FUN_0171dbf8((int)param_2);
      return iVar1 != 0;
    }
    return false;
  }
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  if (iVar1 != 0) {
    iVar1 = FUN_0170db20(param_1,(int)param_2,iVar1);
    if (iVar1 != 0) {
      return iVar1 - (int)param_1 != -1;
    }
  }
  return false;
}



/* FUNCTION 4212 ; VA 0x00591430 ; FUN_00591430 */

int * __thiscall FUN_00591430(int *param_1,uint param_2,int *param_3,uint param_4,uint param_5)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  int *piVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  
  uVar8 = param_1[4];
  if (uVar8 < param_2) {
    FUN_00554050();
  }
  else {
    uVar3 = uVar8 - param_2;
    uVar10 = (uint)param_3;
    if (uVar3 < param_3) {
      uVar10 = uVar3;
    }
    uVar11 = param_1[5];
    if (uVar10 == param_5) {
      piVar6 = param_1;
      if (0xf < uVar11) {
        piVar6 = (int *)*param_1;
      }
      FUN_0170cc70((int)piVar6 + param_2,param_4,param_5);
      return param_1;
    }
    iVar9 = (uVar3 - uVar10) + 1;
    if (param_5 < uVar10) {
      param_1[4] = (uVar8 - uVar10) + param_5;
      piVar6 = param_1;
      if (0xf < uVar11) {
        piVar6 = (int *)*param_1;
      }
      iVar1 = (int)piVar6 + param_2;
      FUN_0170cc70(iVar1,param_4,param_5);
      FUN_0170cc70(iVar1 + param_5,uVar10 + iVar1,iVar9);
      return param_1;
    }
    uVar3 = param_5 - uVar10;
    if (uVar3 <= uVar11 - uVar8) {
      param_1[4] = uVar3 + uVar8;
      param_3 = param_1;
      if (0xf < uVar11) {
        param_3 = (int *)*param_1;
      }
      param_2 = (int)param_3 + param_2;
      uVar10 = uVar10 + param_2;
      uVar11 = param_5;
      if ((param_2 < param_4 + param_5) && (param_4 <= (int)param_3 + uVar8)) {
        if (param_4 < uVar10) {
          uVar11 = uVar10 - param_4;
        }
        else {
          uVar11 = 0;
        }
      }
      FUN_0170cc70(uVar3 + uVar10,uVar10,iVar9);
      FUN_0170cc70(param_2,param_4,uVar11);
      FUN_0170c6f0(param_2 + uVar11,uVar3 + uVar11 + param_4,param_5 - uVar11);
      return param_1;
    }
    if (uVar3 <= 0x7fffffff - uVar8) {
      uVar7 = uVar8 + uVar3 | 0xf;
      if (uVar7 < 0x80000000) {
        if (0x7fffffff - (uVar11 >> 1) < uVar11) {
          uVar7 = 0x7fffffff;
        }
        else {
          uVar4 = uVar11 + (uVar11 >> 1);
          if (uVar7 < uVar4) {
            uVar7 = uVar4;
          }
        }
      }
      else {
        uVar7 = 0x7fffffff;
      }
      iVar5 = FUN_00554060(uVar7 + 1);
      param_1[4] = uVar8 + uVar3;
      param_1[5] = uVar7;
      iVar1 = iVar5 + param_2;
      if (uVar11 < 0x10) {
        FUN_0170c6f0(iVar5,param_1,param_2);
        FUN_0170c6f0(iVar1,param_4,param_5);
        FUN_0170c6f0(iVar1 + param_5,param_2 + uVar10 + (int)param_1,iVar9);
        *param_1 = iVar5;
        return param_1;
      }
      iVar2 = *param_1;
      FUN_0170c6f0(iVar5,iVar2,param_2);
      FUN_0170c6f0(iVar1,param_4,param_5);
      FUN_0170c6f0(iVar1 + param_5,param_2 + iVar2 + uVar10,iVar9);
      uVar8 = uVar11 + 1;
      iVar9 = iVar2;
      if (uVar8 < 0x1000) {
LAB_00591640:
        FUN_01674ea0(iVar9,uVar8);
        *param_1 = iVar5;
        return param_1;
      }
      iVar9 = *(int *)(iVar2 + -4);
      uVar8 = uVar11 + 0x24;
      if ((iVar2 - iVar9) - 4U < 0x20) goto LAB_00591640;
      goto LAB_0059169d;
    }
  }
  FUN_00554040();
LAB_0059169d:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 4213 ; VA 0x005916b0 ; FUN_005916b0 */

undefined4 * __thiscall
FUN_005916b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_018c16ac;
  cVar3 = FUN_005918b0(param_2,param_3,param_4,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 4214 ; VA 0x005917a0 ; FUN_005917a0 */

undefined4 * FUN_005917a0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  
  if (param_1 != param_2) {
    do {
      if (param_3 != param_1) {
        puVar1 = param_1;
        if (7 < (uint)param_1[5]) {
          puVar1 = (undefined4 *)*param_1;
        }
        FUN_0058ed10(puVar1,param_1[4]);
      }
      param_1 = param_1 + 6;
      param_3 = param_3 + 6;
    } while (param_1 != param_2);
  }
  return param_3;
}



/* FUNCTION 4215 ; VA 0x005917e0 ; FUN_005917e0 */

void __thiscall FUN_005917e0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01797630;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<struct_ErrorUploader::data>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4216 ; VA 0x0059184e ; Catch_All@0059184e */

void Catch_All_0059184e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00592870(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 4217 ; VA 0x00591870 ; FUN_00591870 */

char * FUN_00591870(char *param_1,uint param_2)

{
  uint uVar1;
  
  do {
    param_1 = param_1 + -1;
    uVar1 = param_2 / 10;
    *param_1 = (char)param_2 + (char)uVar1 * -10 + '0';
    param_2 = uVar1;
  } while (uVar1 != 0);
  return param_1;
}



/* FUNCTION 4218 ; VA 0x005918b0 ; FUN_005918b0 */

undefined FUN_005918b0(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 *param_4)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined uVar5;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int *piStack_8;
  
  uStack_10 = param_1;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_c = param_2;
  piStack_8 = param_3;
  cVar4 = FUN_00585a40(&uStack_10);
  piVar2 = piStack_8;
  if (cVar4 == '\0') {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      piStack_8[1] = piStack_8[1] + 1;
      UNLOCK();
    }
    *param_4 = uStack_10;
    param_4[1] = 0;
    param_4[2] = 0;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      piStack_8[1] = piStack_8[1] + 1;
      UNLOCK();
    }
    param_4[1] = uStack_c;
    param_4[2] = piStack_8;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_8;
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar5 = 1;
  }
  else {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar5 = 0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  return uVar5;
}



/* FUNCTION 4219 ; VA 0x005919d0 ; FUN_005919d0 */

undefined4 * FUN_005919d0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
    piVar1 = param_4 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  piVar1 = param_4 + 1;
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_3;
  param_1[2] = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 4220 ; VA 0x00591ab0 ; FUN_00591ab0 */

int * FUN_00591ab0(int *param_1,undefined4 *param_2,byte param_3)

{
  int iVar1;
  char cVar2;
  undefined4 *puVar3;
  uint uVar4;
  int *piVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797650;
  pvStack_10 = ExceptionList;
  piVar5 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  ExceptionList = &pvStack_10;
  if (piVar5 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar5 + 4))();
  }
  uStack_8 = 0;
  cVar2 = FUN_00593b40(1);
  uStack_8 = 1;
  if (cVar2 != '\0') {
    uStack_8 = 2;
    puVar3 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar3 = (undefined4 *)*param_2;
    }
    param_2[4] = 0;
    *(undefined *)puVar3 = 0;
    piVar5 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
    if ((*(byte **)piVar5[7] == (byte *)0x0) || (*(int *)piVar5[0xb] < 1)) {
      uVar4 = (**(code **)(*piVar5 + 0x18))();
    }
    else {
      uVar4 = (uint)**(byte **)piVar5[7];
    }
    while( true ) {
      if (uVar4 == 0xffffffff) {
        piVar5 = (int *)FUN_00591bf5();
        return piVar5;
      }
      if (uVar4 == param_3) break;
      if (0x7ffffffe < (uint)param_2[4]) {
        piVar5 = (int *)FUN_00591bf5();
        return piVar5;
      }
      FUN_005558a0(uVar4);
      uVar4 = FUN_0058c090();
    }
    piVar5 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
    if (*(int *)piVar5[7] != 0) {
      iVar1 = *(int *)piVar5[0xb];
      if (0 < iVar1) {
        *(int *)piVar5[0xb] = iVar1 + -1;
        *(int *)piVar5[7] = *(int *)piVar5[7] + 1;
        piVar5 = (int *)FUN_00591bf5();
        return piVar5;
      }
    }
    (**(code **)(*piVar5 + 0x1c))();
    piVar5 = (int *)FUN_00591bf5();
    return piVar5;
  }
  uVar4 = *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc);
  uVar6 = uVar4 | 6;
  if (*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) != 0) {
    uVar6 = uVar4 | 2;
  }
  FUN_00554460(uVar6,0);
  uStack_8 = 4;
  piVar5 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar5 != (int *)0x0) {
    (**(code **)(*piVar5 + 8))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4221 ; VA 0x00591bd3 ; Catch_All@00591bd3 */

undefined * Catch_All_00591bd3(void)

{
  FUN_005565b0(4,1);
  return &DAT_00591bec;
}



/* FUNCTION 4222 ; VA 0x00591bf5 ; FUN_00591bf5 */

void FUN_00591bf5(void)

{
  int *piVar1;
  uint uVar2;
  uint uVar3;
  char unaff_BL;
  int unaff_EBP;
  int *unaff_ESI;
  uint unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  if (unaff_BL == '\0') {
    unaff_EDI = unaff_EDI | 2;
  }
  uVar3 = *(uint *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0xc) | unaff_EDI;
  uVar2 = uVar3 | 4;
  if (*(int *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0x38) != 0) {
    uVar2 = uVar3;
  }
  FUN_00554460(uVar2,0);
  *(undefined4 *)(unaff_EBP + -4) = 4;
  piVar1 = *(int **)(*(int *)(**(int **)(unaff_EBP + -0x28) + 4) + 0x38 +
                    (int)*(int **)(unaff_EBP + -0x28));
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 8))();
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 4223 ; VA 0x00591c60 ; FUN_00591c60 */

int * __thiscall
FUN_00591c60(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179769d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_5 != 0) {
    ExceptionList = &pvStack_10;
    *param_1 = (int)&PTR_018c1524;
    param_1[4] = (int)&DAT_018c152c;
    param_1[0x1e] = (int)std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
    uStack_8 = 0;
  }
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x18;
  param_1[2] = 0;
  param_1[3] = 0;
  FUN_00554f20(param_1 + 6,0);
  *(undefined ***)((int)param_1 + *(int *)(param_1[4] + 4) + 0x10) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(param_1[4] + 4) + 0xc + (int)param_1) = *(int *)(param_1[4] + 4) + -8;
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_iostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x20;
  uStack_8 = 5;
  *(undefined ***)((int)param_1 + *(int *)(*param_1 + 4)) =
       std::basic_fstream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -4 + (int)param_1) = *(int *)(*param_1 + 4) + -0x78;
  FUN_0054ee60();
  param_1[6] = (int)std::basic_filebuf<char,struct_std::char_traits<char>_>::vftable;
  param_1[9] = (int)(param_1 + 7);
  *(undefined *)(param_1 + 0x18) = 0;
  param_1[0xd] = (int)(param_1 + 0xb);
  param_1[0xe] = (int)(param_1 + 0xc);
  param_1[0x11] = (int)(param_1 + 0xf);
  param_1[0x12] = (int)(param_1 + 0x10);
  *(undefined *)((int)param_1 + 0x55) = 0;
  param_1[10] = (int)(param_1 + 8);
  param_1[8] = 0;
  *(undefined4 *)param_1[0xe] = 0;
  *(undefined4 *)param_1[0x12] = 0;
  *(undefined4 *)param_1[9] = 0;
  *(undefined4 *)param_1[0xd] = 0;
  *(undefined4 *)param_1[0x11] = 0;
  param_1[0x19] = 0;
  param_1[0x16] = DAT_01e90d08;
  param_1[0x17] = DAT_01e90d0c;
  param_1[0x14] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  iVar1 = FUN_005553b0(param_2,param_3,param_4);
  if (iVar1 == 0) {
    FUN_00554460((uint)(*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) == 0) * 4 + 2 |
                 *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc),0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4224 ; VA 0x00591e20 ; FUN_00591e20 */

undefined4 * __fastcall FUN_00591e20(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  puVar1 = (undefined4 *)FUN_01674e20(8);
  *param_1 = puVar1;
  *puVar1 = 0;
  puVar1[1] = 0;
  *(undefined4 **)*param_1 = param_1;
  return param_1;
}



/* FUNCTION 4225 ; VA 0x00591e70 ; FUN_00591e70 */

undefined4 * __thiscall FUN_00591e70(undefined4 *param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017976b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = param_2;
  *(undefined *)(param_1 + 1) = 0;
  if (param_2 != (int *)0x0) {
    iVar1 = GetCurrentThreadId();
    if (param_2[1] == iVar1) {
      *param_2 = *param_2 + 1;
    }
    else {
      FUN_005874f0();
      LOCK();
      param_2[1] = iVar1;
      UNLOCK();
      *param_2 = 1;
    }
    *(undefined *)(param_1 + 1) = 1;
    ExceptionList = pvStack_10;
    return param_1;
  }
  uVar2 = FUN_0056aeb0(1,"boost unique_lock has no mutex");
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_00564990(uVar2);
}



/* FUNCTION 4226 ; VA 0x00591f00 ; FUN_00591f00 */

undefined4 * __thiscall
FUN_00591f00(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4)

{
  int *piVar1;
  undefined3 uVar2;
  char cVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uVar8;
  uint uVar9;
  undefined4 uStack_5c;
  undefined *puStack_58;
  uint *puStack_54;
  char *pcStack_50;
  uint auStack_40 [2];
  undefined auStack_38 [24];
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797717;
  pvStack_10 = ExceptionList;
  pcStack_50 = (char *)0x5c;
  uStack_14 = 0;
  puStack_54 = (uint *)0x591f31;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  puVar4 = (undefined4 *)FUN_01674e20();
  uStack_8 = 0;
  puStack_1c = puVar4;
  if (puVar4 == (undefined4 *)0x0) {
    puStack_54 = (undefined4 *)0x0;
  }
  else {
    pcStack_50 = (char *)0x8;
    *puVar4 = 0;
    puVar4[1] = 0;
    puVar4[2] = 0;
    puVar4[3] = 0;
    puVar4[4] = 0;
    puStack_54 = (uint *)0x591f71;
    puVar5 = (undefined4 *)FUN_01674e20();
    *puVar4 = puVar5;
    *puVar5 = 0;
    puVar5[1] = 0;
    *(undefined4 **)*puVar4 = puVar4;
    puVar5 = puVar4 + 5;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    puStack_54 = (uint *)0x8;
    *puVar5 = 0;
    puVar4[6] = 0;
    puVar4[7] = 0;
    puVar4[8] = 0;
    puVar4[9] = 0;
    puStack_58 = (undefined *)0x591fb7;
    puStack_20 = puVar5;
    puVar6 = (undefined4 *)FUN_01674e20();
    *puVar5 = puVar6;
    *puVar6 = 0;
    puVar6[1] = 0;
    *(undefined4 **)*puVar5 = puVar5;
    puVar4[10] = 0;
    puVar4[0xb] = 0;
    puVar4[0xc] = 0;
    puVar4[0xd] = 0;
    puVar4[0xe] = 0;
    puVar4[0x13] = 0;
    puVar4[0x14] = 0xf;
    *(undefined *)(puVar4 + 0xf) = 0;
    puVar4[0x15] = 0;
    puVar4[0x16] = 0;
    puStack_54 = puVar4;
  }
  pcStack_50 = (char *)param_2;
  uStack_8 = 0xffffffff;
  *param_1 = 0;
  param_1[1] = 0;
  puStack_58 = (undefined *)0x592033;
  FUN_005917e0();
  param_1[2] = 0;
  uStack_8 = 2;
  if ((char)param_2 != '\0') {
    pcStack_50 = (char *)0x592050;
    cVar3 = FUN_0086d8a0();
    if (cVar3 != '\0') {
      pcStack_50 = (char *)0x8;
      puStack_54 = (uint *)0x59205f;
      iVar7 = FUN_01674e20();
      if (iVar7 == 0) {
        uVar8 = 0;
        uVar9 = uStack_14;
      }
      else {
        pcStack_50 = (char *)0x0;
        if (param_1[1] != 0) {
          LOCK();
          piVar1 = (int *)(param_1[1] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        FUN_005919d0(&uStack_5c,FUN_005944d0,*param_1,param_1[1]);
        FUN_005916b0();
        pcStack_50 = "ErrorUploader";
        puStack_54 = auStack_40;
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        uStack_14 = 1;
        puStack_58 = (undefined *)0x5920cb;
        uVar8 = FUN_015196a0();
        uVar9 = 1;
      }
      iVar7 = param_1[2];
      param_1[2] = uVar8;
      if (iVar7 != 0) {
        pcStack_50 = (char *)0x5920e3;
        FUN_01519bf0();
        pcStack_50 = (char *)0x8;
        puStack_58 = (undefined *)0x5920eb;
        puStack_54 = (uint *)iVar7;
        FUN_01674ea0();
      }
      uStack_8 = 2;
      if ((uVar9 & 1) != 0) {
        uStack_8._1_3_ = 0;
        uVar2 = uStack_8._1_3_;
        uStack_8._0_1_ = 6;
        uStack_8._1_3_ = 0;
        if (((auStack_40[0] != 0) && (uVar2 = uStack_8._1_3_, (auStack_40[0] & 1) == 0)) &&
           (*(code **)(auStack_40[0] & 0xfffffffe) != (code *)0x0)) {
          puStack_58 = auStack_38;
          pcStack_50 = (char *)0x2;
          uStack_5c = 0x59211b;
          puStack_54 = (uint *)puStack_58;
          (**(code **)(auStack_40[0] & 0xfffffffe))();
          uVar2 = uStack_8._1_3_;
        }
        uStack_8._1_3_ = uVar2;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
      }
    }
  }
  if (param_3 != (undefined4 *)&DAT_01d59430) {
    pcStack_50 = (char *)param_3[4];
    if (0xf < (uint)param_3[5]) {
      param_3 = (undefined4 *)*param_3;
    }
    puStack_58 = (undefined *)0x592143;
    puStack_54 = param_3;
    FUN_005542c0();
  }
  if (param_4 != &DAT_01d59448) {
    pcStack_50 = (char *)param_4[4];
    if (0xf < (uint)param_4[5]) {
      param_4 = (undefined4 *)*param_4;
    }
    puStack_58 = (undefined *)0x592164;
    puStack_54 = param_4;
    FUN_005542c0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4227 ; VA 0x00592180 ; FUN_00592180 */

undefined2 * __thiscall FUN_00592180(undefined2 *param_1,short *param_2)

{
  short sVar1;
  short *psVar2;
  
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 10) = 7;
  *param_1 = 0;
  psVar2 = param_2;
  do {
    sVar1 = *psVar2;
    psVar2 = psVar2 + 1;
  } while (sVar1 != 0);
  FUN_0058ed10(param_2,(int)psVar2 - (int)(param_2 + 1) >> 1);
  return param_1;
}



/* FUNCTION 4228 ; VA 0x005921d0 ; FUN_005921d0 */

void __fastcall FUN_005921d0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  iVar4 = param_1[4];
  while (iVar4 != 0) {
    FUN_0058dbf0();
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    iVar4 = param_1[4];
  }
  iVar4 = param_1[2];
  while (iVar4 != 0) {
    iVar4 = iVar4 + -1;
    iVar2 = *(int *)(param_1[1] + iVar4 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x3c);
    }
  }
  iVar4 = param_1[1];
  if (iVar4 != 0) {
    uVar3 = param_1[2] * 4;
    iVar2 = iVar4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar4 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar4 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 4229 ; VA 0x00592290 ; FUN_00592290 */

void __fastcall FUN_00592290(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  
  iVar5 = param_1[4];
  while (iVar5 != 0) {
    piVar1 = *(int **)(param_1[1] + (iVar5 + param_1[3] + -1 & param_1[2] - 1) * 4);
    uVar4 = piVar1[5];
    if (0xf < uVar4) {
      iVar5 = *piVar1;
      uVar3 = uVar4 + 1;
      iVar2 = iVar5;
      if (0xfff < uVar3) {
        iVar2 = *(int *)(iVar5 + -4);
        uVar3 = uVar4 + 0x24;
        if (0x1f < (iVar5 - iVar2) - 4U) goto LAB_0059237f;
      }
      FUN_01674ea0(iVar2,uVar3);
    }
    piVar1[4] = 0;
    piVar1[5] = 0xf;
    *(undefined *)piVar1 = 0;
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    iVar5 = param_1[4];
  }
  iVar5 = param_1[2];
  while (iVar5 != 0) {
    iVar5 = iVar5 + -1;
    iVar2 = *(int *)(param_1[1] + iVar5 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x18);
    }
  }
  iVar5 = param_1[1];
  if (iVar5 != 0) {
    uVar4 = param_1[2] * 4;
    iVar2 = iVar5;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(iVar5 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar5 - iVar2) - 4U) {
LAB_0059237f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 4230 ; VA 0x00592390 ; FUN_00592390 */

void __fastcall FUN_00592390(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  
  iVar5 = param_1[4];
  while (iVar5 != 0) {
    piVar1 = *(int **)(param_1[1] + (iVar5 + param_1[3] + -1 & param_1[2] - 1) * 4);
    uVar4 = piVar1[5];
    if (0xf < uVar4) {
      iVar5 = *piVar1;
      uVar3 = uVar4 + 1;
      iVar2 = iVar5;
      if (0xfff < uVar3) {
        iVar2 = *(int *)(iVar5 + -4);
        uVar3 = uVar4 + 0x24;
        if (0x1f < (iVar5 - iVar2) - 4U) goto LAB_0059237f;
      }
      FUN_01674ea0(iVar2,uVar3);
    }
    piVar1[4] = 0;
    piVar1[5] = 0xf;
    *(undefined *)piVar1 = 0;
    piVar1 = param_1 + 4;
    *piVar1 = *piVar1 + -1;
    if (*piVar1 == 0) {
      param_1[3] = 0;
    }
    iVar5 = param_1[4];
  }
  iVar5 = param_1[2];
  while (iVar5 != 0) {
    iVar5 = iVar5 + -1;
    iVar2 = *(int *)(param_1[1] + iVar5 * 4);
    if (iVar2 != 0) {
      FUN_01674ea0(iVar2,0x18);
    }
  }
  iVar5 = param_1[1];
  if (iVar5 != 0) {
    uVar4 = param_1[2] * 4;
    iVar2 = iVar5;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(iVar5 + -4);
      uVar4 = uVar4 + 0x23;
      if (0x1f < (iVar5 - iVar2) - 4U) {
LAB_0059237f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  param_1[2] = 0;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,8);
  *param_1 = 0;
  return;
}



/* FUNCTION 4231 ; VA 0x005923a0 ; FUN_005923a0 */

void __fastcall FUN_005923a0(undefined4 *param_1)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 1) != '\0') {
    piVar3 = (int *)*param_1;
    ExceptionList = &pvStack_10;
    *piVar3 = *piVar3 + -1;
    if (*piVar3 == 0) {
      LOCK();
      piVar3[1] = 0;
      UNLOCK();
      puVar1 = (uint *)(piVar3 + 2);
      LOCK();
      uVar2 = *puVar1;
      *puVar1 = *puVar1 + 0x80000000;
      UNLOCK();
      if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
        LOCK();
        uVar2 = *puVar1;
        *puVar1 = *puVar1 | 0x40000000;
        UNLOCK();
        if ((uVar2 >> 0x1e & 1) == 0) {
          uVar4 = FUN_00554e40();
          SetEvent(uVar4);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4232 ; VA 0x00592410 ; FUN_00592410 */

void __fastcall FUN_00592410(int param_1)

{
  int iVar1;
  
  LOCK();
  iVar1 = *(int *)(param_1 + 0xc);
  *(int *)(param_1 + 0xc) = 0;
  UNLOCK();
  if (iVar1 != 0) {
    CloseHandle(iVar1);
  }
  return;
}



/* FUNCTION 4233 ; VA 0x00592430 ; FUN_00592430 */

void __fastcall FUN_00592430(int *param_1)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piVar1 = *(int **)(*(int *)(*(int *)*param_1 + 4) + 0x38 + *param_1);
  if (piVar1 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar1 + 8))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4234 ; VA 0x00592480 ; FUN_00592480 */

int * __thiscall FUN_00592480(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  
  if (param_1 != param_2) {
    iVar6 = param_2[1];
    iVar2 = *param_2;
    iVar3 = *param_1;
    uVar4 = (iVar6 - iVar2) / 0x18;
    uVar7 = (param_1[1] - iVar3) / 0x18;
    uVar5 = (param_1[2] - iVar3) / 0x18;
    if (uVar5 < uVar4) {
      if (0xaaaaaaa < uVar4) {
                    /* WARNING: Subroutine does not return */
        FUN_00577c30();
      }
      uVar7 = uVar4;
      if ((uVar5 <= 0xaaaaaaa - (uVar5 >> 1)) && (uVar7 = (uVar5 >> 1) + uVar5, uVar7 < uVar4)) {
        uVar7 = uVar4;
      }
      if (iVar3 != 0) {
        FUN_0058cd80(iVar3,param_1[1],param_1);
        FUN_0057d2f0(*param_1,uVar5);
      }
      FUN_0058e990(uVar7);
      iVar6 = FUN_0058d5c0(iVar2,iVar6,*param_1);
      param_1[1] = iVar6;
      return param_1;
    }
    if (uVar7 < uVar4) {
      iVar1 = iVar2 + uVar7 * 0x18;
      FUN_005917a0(iVar2,iVar1,iVar3);
      iVar6 = FUN_0058d5c0(iVar1,iVar6,param_1[1]);
      param_1[1] = iVar6;
      return param_1;
    }
    iVar1 = iVar3 + uVar4 * 0x18;
    FUN_005917a0(iVar2,iVar6,iVar3);
    FUN_0058cd80(iVar1,param_1[1],param_1);
    param_1[1] = iVar1;
  }
  return param_1;
}



/* FUNCTION 4235 ; VA 0x005925c0 ; FUN_005925c0 */

int * __thiscall FUN_005925c0(int *param_1,undefined4 param_2)

{
  int iVar1;
  undefined *puVar2;
  char cVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  uint auStack_38 [2];
  int *piStack_30;
  undefined uStack_2c;
  undefined4 uStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797748;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffbc;
  iVar7 = *param_1;
  uStack_28 = 0;
  piVar5 = *(int **)(*(int *)(iVar7 + 4) + 0x38 + (int)param_1);
  ExceptionList = &pvStack_10;
  piStack_30 = param_1;
  piStack_18 = param_1;
  puVar2 = &stack0xffffffbc;
  if (piVar5 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*piVar5 + 4))();
    iVar7 = *param_1;
    puVar2 = puStack_14;
  }
  puStack_14 = puVar2;
  uStack_8 = 0;
  if (((*(int *)(*(int *)(iVar7 + 4) + 0xc + (int)param_1) == 0) &&
      (piVar5 = *(int **)(*(int *)(iVar7 + 4) + 0x3c + (int)param_1), piVar5 != (int *)0x0)) &&
     (piVar5 != param_1)) {
    FUN_00581480();
    iVar7 = *param_1;
  }
  iVar1 = *(int *)(*(int *)(iVar7 + 4) + 0xc + (int)param_1);
  uStack_2c = iVar1 == 0;
  uStack_8 = 1;
  if (iVar1 == 0) {
    piStack_20 = *(int **)(*(int *)(*(int *)(iVar7 + 4) + 0x30 + (int)param_1) + 4);
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    piStack_1c = piStack_20;
    (**(code **)(*piStack_20 + 4))();
    uStack_8._0_1_ = 3;
    piStack_20 = (int *)FUN_00564aa0(auStack_24);
    uStack_8._0_1_ = 4;
    if ((piStack_1c != (int *)0x0) &&
       (puVar4 = (undefined4 *)(**(code **)(*piStack_1c + 8))(), puVar4 != (undefined4 *)0x0)) {
      (**(code **)*puVar4)(1);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    iVar7 = *(int *)(*param_1 + 4) + (int)param_1;
    piStack_1c = (int *)CONCAT31(piStack_1c._1_3_,
                                 *(undefined *)(*(int *)(*param_1 + 4) + 0x40 + (int)param_1));
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    uVar8 = auStack_38[0];
    (**(code **)(*piStack_20 + 0xc))
              (auStack_38,auStack_38[0],*(undefined4 *)(iVar7 + 0x38),iVar7,piStack_1c,param_2);
    piVar5 = (int *)FUN_005926eb(uVar8);
    return piVar5;
  }
  uVar8 = *(uint *)((int)param_1 + *(int *)(*param_1 + 4) + 0xc);
  uVar6 = uVar8 | 4;
  if (*(int *)((int)param_1 + *(int *)(*param_1 + 4) + 0x38) != 0) {
    uVar6 = uVar8;
  }
  FUN_00554460(uVar6,0);
  uStack_8 = 7;
  cVar3 = thunk_FUN_0170e3b7();
  if (cVar3 == '\0') {
    FUN_00577770();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  piVar5 = *(int **)(*(int *)(*param_1 + 4) + 0x38 + (int)param_1);
  if (piVar5 != (int *)0x0) {
    (**(code **)(*piVar5 + 8))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 4236 ; VA 0x005926cc ; Catch_All@005926cc */

undefined * Catch_All_005926cc(void)

{
  FUN_005565b0(4,1);
  return &DAT_005926e5;
}



/* FUNCTION 4237 ; VA 0x005926eb ; FUN_005926eb */

void FUN_005926eb(void)

{
  int iVar1;
  int *piVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  int unaff_EBP;
  int *unaff_ESI;
  uint unaff_EDI;
  
  *(undefined4 *)(unaff_EBP + -4) = 1;
  uVar5 = *(uint *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0xc) | unaff_EDI;
  uVar4 = uVar5 | 4;
  if (*(int *)((int)unaff_ESI + *(int *)(*unaff_ESI + 4) + 0x38) != 0) {
    uVar4 = uVar5;
  }
  FUN_00554460(uVar4,0);
  *(undefined4 *)(unaff_EBP + -4) = 7;
  cVar3 = thunk_FUN_0170e3b7();
  if (cVar3 == '\0') {
    FUN_00577770();
  }
  iVar1 = *unaff_ESI;
  *(undefined *)(unaff_EBP + -4) = 8;
  piVar2 = *(int **)(*(int *)(iVar1 + 4) + 0x38 + (int)unaff_ESI);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 8))();
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 4238 ; VA 0x00592760 ; FUN_00592760 */

undefined4 __thiscall FUN_00592760(undefined4 param_1,undefined4 param_2)

{
  FUN_005558a0(param_2);
  return param_1;
}



/* FUNCTION 4239 ; VA 0x00592780 ; FUN_00592780 */

void __fastcall FUN_00592780(int *param_1)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar1 = param_1 + 0x1e;
  ExceptionList = &pvStack_10;
  *(undefined ***)(*(int *)(*param_1 + 4) + -0x78 + (int)piVar1) =
       std::basic_fstream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -0x7c + (int)piVar1) = *(int *)(*param_1 + 4) + -0x78;
  FUN_00550570();
  *(undefined ***)(*(int *)(*param_1 + 4) + -0x78 + (int)piVar1) =
       std::basic_iostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -0x7c + (int)piVar1) = *(int *)(*param_1 + 4) + -0x20;
  *(undefined ***)(*(int *)(param_1[4] + 4) + -0x68 + (int)piVar1) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(param_1[4] + 4) + -0x6c + (int)piVar1) = *(int *)(param_1[4] + 4) + -8;
  *(undefined ***)(*(int *)(*param_1 + 4) + -0x78 + (int)piVar1) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)(*(int *)(*param_1 + 4) + -0x7c + (int)piVar1) = *(int *)(*param_1 + 4) + -0x18;
  uStack_8 = 0;
  *piVar1 = (int)std::ios_base::vftable;
  FUN_016de551(piVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4240 ; VA 0x00592834 ; FUN_00592834 */

void FUN_00592834(void)

{
  FUN_00592840();
  return;
}



/* FUNCTION 4241 ; VA 0x00592840 ; FUN_00592840 */

int __thiscall FUN_00592840(int param_1,byte param_2)

{
  FUN_00592780();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1 + -0x78,0xc0);
  }
  return param_1 + -0x78;
}



/* FUNCTION 4242 ; VA 0x00592870 ; FUN_00592870 */

int __thiscall FUN_00592870(int param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x50);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x3c);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x4c) = 0;
  *(undefined4 *)(param_1 + 0x50) = 0xf;
  *(undefined *)(param_1 + 0x3c) = 0;
  LOCK();
  iVar2 = *(int *)(param_1 + 0x34);
  *(int *)(param_1 + 0x34) = 0;
  UNLOCK();
  if (iVar2 != 0) {
    CloseHandle(iVar2);
  }
  FUN_005921d0();
  FUN_00592290();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x5c);
  }
  return param_1;
}



/* FUNCTION 4243 ; VA 0x00592900 ; FUN_00592900 */

void FUN_00592900(void)

{
  uint *puVar1;
  int iVar2;
  undefined *puVar3;
  undefined4 *puVar4;
  undefined4 ****ppppuVar5;
  uint uVar6;
  uint uVar7;
  int aiStack_a0 [5];
  uint uStack_8c;
  undefined auStack_73 [3];
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  undefined4 ***apppuStack_58 [4];
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined8 uStack_30;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01797793;
  pvStack_10 = ExceptionList;
  uStack_18._0_4_ = 0;
  uStack_18._4_4_ = 0xf;
  uStack_28 = uStack_28 & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("HKEY_CURRENT_USER\\Software\\ROBLOX Corporation\\Roblox\\FilteredExceptionCrash",
               0x4b);
  uStack_8 = 0;
  FUN_01522a90(&uStack_28,1);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_18._4_4_) {
    uVar6 = uStack_18._4_4_ + 1;
    uVar7 = uStack_28;
    if (0xfff < uVar6) {
      uVar7 = *(uint *)(uStack_28 - 4);
      uVar6 = uStack_18._4_4_ + 0x24;
      if (0x1f < (uStack_28 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar6);
  }
  FUN_00558ce0(aiStack_a0,&DAT_01d59430,"CrashEvent");
  puVar4 = &DAT_01d59448;
  if (0xf < DAT_01d5945c) {
    puVar4 = DAT_01d59448;
  }
  uStack_8 = 1;
  puVar1 = (uint *)FUN_00554150(puVar4,DAT_01d59458);
  uStack_28 = *puVar1;
  uStack_24 = puVar1[1];
  uStack_20 = puVar1[2];
  uStack_1c = puVar1[3];
  uStack_18 = *(undefined8 *)(puVar1 + 4);
  puVar1[4] = 0;
  puVar1[5] = 0xf;
  *(undefined *)puVar1 = 0;
  uStack_8._0_1_ = 2;
  FUN_008783f0(&uStack_28,1,1);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_18._4_4_) {
    uVar6 = uStack_18._4_4_ + 1;
    uVar7 = uStack_28;
    if (0xfff < uVar6) {
      uVar7 = *(uint *)(uStack_28 - 4);
      uVar6 = uStack_18._4_4_ + 0x24;
      if (0x1f < (uStack_28 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar6);
  }
  uStack_18 = 0xf00000000;
  uStack_28 = uStack_28 & 0xffffff00;
  uStack_8 = 0xffffffff;
  if (0xf < uStack_8c) {
    uVar7 = uStack_8c + 1;
    iVar2 = aiStack_a0[0];
    if (0xfff < uVar7) {
      iVar2 = *(int *)(aiStack_a0[0] + -4);
      uVar7 = uStack_8c + 0x24;
      if (0x1f < (aiStack_a0[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar7);
  }
  if ((DAT_01f6e610 < 1) || (4 < DAT_01f6e610)) {
    iVar2 = 0;
  }
  else {
    iVar2 = DAT_01f6e610;
    if (DAT_01f6e610 < 0) {
      iVar2 = FUN_00591870(auStack_73,-DAT_01f6e610);
      *(undefined *)(iVar2 + -1) = 0x2d;
      puVar3 = (undefined *)(iVar2 + -1);
      goto LAB_00592ad5;
    }
  }
  puVar3 = (undefined *)FUN_00591870(auStack_73,iVar2);
LAB_00592ad5:
  uStack_48 = 0;
  uStack_44 = 0xf;
  apppuStack_58[0] = (undefined4 ***)((uint)apppuStack_58[0] & 0xffffff00);
  if (puVar3 != auStack_73) {
    FUN_005542c0(puVar3,(int)auStack_73 - (int)puVar3);
  }
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_00558ce0(auStack_70,&DAT_01d59430,"CrashEventServerType_");
  uVar7 = puVar4[4];
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if ((puVar4[5] - uVar7 < uStack_48) && (uVar7 <= uStack_44 - uStack_48)) {
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    puVar1 = (uint *)FUN_00585d40(0,puVar4,uVar7);
  }
  else {
    ppppuVar5 = apppuStack_58;
    if (0xf < uStack_44) {
      ppppuVar5 = (undefined4 ****)apppuStack_58[0];
    }
    puVar1 = (uint *)FUN_00554150(ppppuVar5,uStack_48);
  }
  uStack_40 = *puVar1;
  uStack_3c = puVar1[1];
  uStack_38 = puVar1[2];
  uStack_34 = puVar1[3];
  uStack_30 = *(undefined8 *)(puVar1 + 4);
  puVar1[4] = 0;
  puVar1[5] = 0xf;
  *(undefined *)puVar1 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_008783f0(&uStack_40,1,1);
  if (0xf < uStack_30._4_4_) {
    uVar6 = uStack_30._4_4_ + 1;
    uVar7 = uStack_40;
    if (0xfff < uVar6) {
      uVar7 = *(uint *)(uStack_40 - 4);
      uVar6 = uStack_30._4_4_ + 0x24;
      if (0x1f < (uStack_40 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar6);
  }
  uStack_30 = 0xf00000000;
  uStack_40 = uStack_40 & 0xffffff00;
  if (0xf < uStack_5c) {
    uVar6 = uStack_5c + 1;
    uVar7 = auStack_70[0];
    if (0xfff < uVar6) {
      uVar7 = *(uint *)(auStack_70[0] - 4);
      uVar6 = uStack_5c + 0x24;
      if (0x1f < (auStack_70[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar6);
  }
  uStack_60 = 0;
  uStack_5c = 0xf;
  auStack_70[0] = auStack_70[0] & 0xffffff00;
  if (0xf < uStack_44) {
    uVar7 = uStack_44 + 1;
    ppppuVar5 = (undefined4 ****)apppuStack_58[0];
    if (0xfff < uVar7) {
      ppppuVar5 = (undefined4 ****)apppuStack_58[0][-1];
      uVar7 = uStack_44 + 0x24;
      if (0x1f < (uint)((int)apppuStack_58[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4244 ; VA 0x00592c90 ; FUN_00592c90 */

void __fastcall FUN_00592c90(int *param_1)

{
  int *piVar1;
  undefined uVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  uint *puVar7;
  int iVar8;
  uint uVar9;
  undefined4 *puVar10;
  uint uVar11;
  uint auStack_84 [4];
  undefined4 uStack_74;
  uint uStack_70;
  uint auStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  undefined8 uStack_44;
  int iStack_3c;
  int iStack_38;
  int *piStack_30;
  int *piStack_2c;
  char cStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017977f3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = CreateMutexA(0,1,"RobloxCrashDumpUploaderMutex");
  if (iVar4 == 0) {
    if (DAT_01d84e8e != '\0') {
      uVar5 = GetLastError();
      FUN_01677520(DAT_01d84e8e,"CreateMutex error: %d",uVar5);
    }
  }
  else {
    iVar8 = GetLastError();
    if (iVar8 == 0xb7) {
      if (DAT_01d84e8d != '\0') {
        FUN_01677520(DAT_01d84e8d,"RobloxCrashDumpUploaderMutex already exists. Not uploading logs."
                    );
      }
      CloseHandle(iVar4);
      ExceptionList = pvStack_10;
      return;
    }
  }
  cVar3 = FUN_0086d8a0();
  if (cVar3 == '\0') {
    FUN_00590150();
    FUN_0058f260(&piStack_30);
    uStack_8 = 10;
    piStack_1c = piStack_2c;
    if (piStack_30 != piStack_2c) {
      piVar6 = piStack_30 + 0xc;
      do {
        piStack_24 = piVar6;
        FUN_00593cf0(piVar6 + -0xc,1,*(undefined4 *)(*param_1 + 0x38));
        iStack_20 = piVar6[1];
        iVar4 = *piVar6;
        if (iVar4 != iStack_20) {
          do {
            FUN_00593cf0(iVar4,0,*(undefined4 *)(*param_1 + 0x38));
            iVar4 = iVar4 + 0x18;
          } while (iVar4 != iStack_20);
        }
        piVar1 = piStack_24;
        FUN_00593cf0(piStack_24 + -6,0,*(undefined4 *)(*param_1 + 0x38));
        piVar6 = piVar1 + 0xf;
        piStack_24 = piVar6;
      } while (piVar1 + 3 != piStack_1c);
    }
  }
  else {
    FUN_00590150();
    FUN_0058f260(&iStack_3c);
    uStack_8 = 0;
    FUN_00591e70(*param_1 + 0x28);
    *(int *)(*param_1 + 0x58) = iVar4;
    *(int *)(*param_1 + 0x38) = (iStack_38 - iStack_3c) / 0x3c;
    piVar6 = (int *)*param_1;
    piStack_1c = (int *)0x0;
    if (0 < piVar6[0xe]) {
      iStack_20 = 0;
      do {
        uStack_8._0_1_ = 1;
        piStack_24 = piVar6;
        if (DAT_01d59414 <= (int)piStack_1c) break;
        uVar9 = piVar6[7];
        iStack_14 = iStack_3c + iStack_20;
        if (uVar9 <= piVar6[9] + 1U) {
          FUN_00593950(1);
          uVar9 = piVar6[7];
        }
        uVar9 = uVar9 - 1 & piVar6[8];
        piVar6[8] = uVar9;
        iStack_18 = (piVar6[7] - 1U & piVar6[9] + uVar9) * 4;
        iVar4 = piVar6[6];
        if (*(int *)(iStack_18 + iVar4) == 0) {
          uVar5 = FUN_01674e20(0x3c);
          *(undefined4 *)(iStack_18 + piVar6[6]) = uVar5;
          iVar4 = piVar6[6];
        }
        iStack_18 = *(undefined4 *)(iStack_18 + iVar4);
        FUN_0054f050(iStack_14);
        uStack_8._0_1_ = 2;
        FUN_0054f050(iStack_14 + 0x18);
        uStack_8._0_1_ = 3;
        FUN_0058d6a0(iStack_14 + 0x30);
        piStack_1c = (int *)((int)piStack_1c + 1);
        iStack_20 = iStack_20 + 0x3c;
        piStack_24[9] = piStack_24[9] + 1;
        piVar6 = (int *)*param_1;
        piStack_24 = piVar6;
      } while ((int)piStack_1c < piVar6[0xe]);
    }
    uStack_8._0_1_ = 1;
    iVar4 = piVar6[0xe];
    FUN_00558ce0(auStack_84,&DAT_01d59430,"Crash");
    puVar10 = &DAT_01d59448;
    if (0xf < DAT_01d5945c) {
      puVar10 = DAT_01d59448;
    }
    uStack_8._0_1_ = 4;
    puVar7 = (uint *)FUN_00554150(puVar10,DAT_01d59458);
    uStack_54 = *puVar7;
    uStack_50 = puVar7[1];
    uStack_4c = puVar7[2];
    uStack_48 = puVar7[3];
    uStack_44 = *(undefined8 *)(puVar7 + 4);
    puVar7[4] = 0;
    puVar7[5] = 0xf;
    *(undefined *)puVar7 = 0;
    uStack_8._0_1_ = 5;
    FUN_008783f0(&uStack_54,iVar4,1);
    uStack_8._0_1_ = 4;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 4;
    if (0xf < uStack_44._4_4_) {
      uVar11 = uStack_44._4_4_ + 1;
      uVar9 = uStack_54;
      if (0xfff < uVar11) {
        uVar9 = *(uint *)(uStack_54 - 4);
        uVar11 = uStack_44._4_4_ + 0x24;
        if (0x1f < (uStack_54 - uVar9) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar11);
    }
    uStack_44 = 0xf00000000;
    uStack_54 = uStack_54 & 0xffffff00;
    uStack_8._0_1_ = 1;
    uVar2 = (undefined)uStack_8;
    uStack_8._0_1_ = 1;
    if (0xf < uStack_70) {
      uVar11 = uStack_70 + 1;
      uVar9 = auStack_84[0];
      if (0xfff < uVar11) {
        uVar9 = *(uint *)(auStack_84[0] - 4);
        uVar11 = uStack_70 + 0x24;
        if (0x1f < (auStack_84[0] - uVar9) - 4) {
          uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar9,uVar11);
    }
    iVar4 = *param_1;
    if ((0 < *(int *)(iVar4 + 0x38)) && (DAT_01d84e8d != '\0')) {
      FUN_016774b0(DAT_01d84e8d,"Uploading %d crashes to Backtrace",*(int *)(iVar4 + 0x38));
      iVar4 = *param_1;
    }
    iVar4 = *(int *)(iVar4 + 0x38);
    if (DAT_01d59414 < iVar4) {
      uStack_74 = 0;
      uStack_70 = 0xf;
      auStack_84[0] = auStack_84[0] & 0xffffff00;
      FUN_005542c0(&DAT_018bc9b8,0);
      uStack_8._0_1_ = 6;
      uStack_5c = 0;
      uStack_58 = 0xf;
      auStack_6c[0] = auStack_6c[0] & 0xffffff00;
      FUN_005542c0("Too many dump files",0x13);
      uStack_8._0_1_ = 7;
      uStack_44._0_4_ = 0;
      uStack_44._4_4_ = 0xf;
      uStack_54 = uStack_54 & 0xffffff00;
      FUN_005542c0("TooManyDumpFiles",0x10);
      uStack_8._0_1_ = 8;
      FUN_00594330(&uStack_54,auStack_6c,auStack_84,iVar4);
      uStack_8._0_1_ = 7;
      uVar2 = (undefined)uStack_8;
      uStack_8._0_1_ = 7;
      if (0xf < uStack_44._4_4_) {
        uVar11 = uStack_44._4_4_ + 1;
        uVar9 = uStack_54;
        if (0xfff < uVar11) {
          uVar9 = *(uint *)(uStack_54 - 4);
          uVar11 = uStack_44._4_4_ + 0x24;
          if (0x1f < (uStack_54 - uVar9) - 4) {
            uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar9,uVar11);
      }
      uStack_44 = 0xf00000000;
      uStack_54 = uStack_54 & 0xffffff00;
      uStack_8._0_1_ = 6;
      uVar2 = (undefined)uStack_8;
      uStack_8._0_1_ = 6;
      if (0xf < uStack_58) {
        uVar11 = uStack_58 + 1;
        uVar9 = auStack_6c[0];
        if (0xfff < uVar11) {
          uVar9 = *(uint *)(auStack_6c[0] - 4);
          uVar11 = uStack_58 + 0x24;
          if (0x1f < (auStack_6c[0] - uVar9) - 4) {
            uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar9,uVar11);
      }
      uStack_5c = 0;
      uStack_58 = 0xf;
      auStack_6c[0] = auStack_6c[0] & 0xffffff00;
      uStack_8._0_1_ = 1;
      uVar2 = (undefined)uStack_8;
      uStack_8._0_1_ = 1;
      if (0xf < uStack_70) {
        uVar11 = uStack_70 + 1;
        uVar9 = auStack_84[0];
        if (0xfff < uVar11) {
          uVar9 = *(uint *)(auStack_84[0] - 4);
          uVar11 = uStack_70 + 0x24;
          if (0x1f < (auStack_84[0] - uVar9) - 4) {
            uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar9,uVar11);
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,9);
    if ((cStack_28 != '\0') && (*piStack_2c = *piStack_2c + -1, *piStack_2c == 0)) {
      LOCK();
      piStack_2c[1] = 0;
      UNLOCK();
      puVar7 = (uint *)(piStack_2c + 2);
      LOCK();
      uVar9 = *puVar7;
      *puVar7 = *puVar7 + 0x80000000;
      UNLOCK();
      if (((uVar9 & 0x40000000) == 0) && (-0x80000000 < (int)uVar9)) {
        LOCK();
        uVar9 = *puVar7;
        *puVar7 = *puVar7 | 0x40000000;
        UNLOCK();
        if ((uVar9 >> 0x1e & 1) == 0) {
          uVar5 = FUN_00554e40();
          SetEvent(uVar5);
        }
      }
    }
  }
  uStack_8 = 0xffffffff;
  FUN_0058db50();
  if (param_1[2] == 0) {
    cVar3 = FUN_0086d8a0();
    if (cVar3 != '\0') {
      do {
        if (param_1[1] != 0) {
          LOCK();
          piVar6 = (int *)(param_1[1] + 4);
          *piVar6 = *piVar6 + 1;
          UNLOCK();
        }
        iVar4 = FUN_005944d0(*param_1,param_1[1]);
      } while (iVar4 != 0);
    }
    ExceptionList = pvStack_10;
    return;
  }
  FUN_0151a5b0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4245 ; VA 0x00593270 ; FUN_00593270 */

void FUN_00593270(int *param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined uVar3;
  int iVar4;
  undefined4 *****pppppuVar5;
  undefined4 *puVar6;
  uint *puVar7;
  char *pcVar8;
  undefined4 ****ppppuVar9;
  char *pcVar10;
  uint uVar11;
  uint uVar12;
  float10 fVar13;
  undefined8 uVar14;
  int iStack_10c;
  undefined **appuStack_108 [2];
  undefined8 uStack_100;
  undefined **appuStack_f8 [16];
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_a4;
  undefined **ppuStack_a0;
  undefined4 ****appppuStack_54 [5];
  uint uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  uint uStack_30;
  undefined4 ****ppppuStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined8 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0179788b;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffe04;
  uStack_34 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0151f6f0(0xffffffff,0,0);
  uStack_8._0_1_ = 1;
  FUN_0151f850("SessionReport","AppStatusCrash");
  fVar13 = (float10)FUN_01683110();
  uStack_3c = (double)fVar13;
  FUN_0151fb00("PlayTime",uStack_3c);
  uVar14 = FUN_01522960();
  FUN_0151fc50("UsedMemoryKB",uVar14);
  iVar4 = FUN_00590150();
  if (iVar4 != 0) {
    if (*(int *)(iVar4 + 0x2c) == 0) {
      pcVar10 = "uninitialized";
    }
    else {
      pcVar10 = "inGame";
      if (*(int *)(iVar4 + 0x2c) != 1) {
        pcVar10 = "leaveGame";
      }
    }
    uStack_1c = 0xf00000000;
    ppppuStack_2c = (undefined4 ****)((uint)ppppuStack_2c & 0xffffff00);
    pcVar8 = pcVar10;
    do {
      cVar1 = *pcVar8;
      pcVar8 = pcVar8 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(pcVar10,(int)pcVar8 - (int)(pcVar10 + 1));
    uStack_8._0_1_ = 2;
    pppppuVar5 = &ppppuStack_2c;
    if (0xf < uStack_1c._4_4_) {
      pppppuVar5 = (undefined4 *****)ppppuStack_2c;
    }
    FUN_0151f850("GameState",pppppuVar5);
    uStack_8._0_1_ = 1;
    if (0xf < uStack_1c._4_4_) {
      uVar11 = uStack_1c._4_4_ + 1;
      pppppuVar5 = (undefined4 *****)ppppuStack_2c;
      if (0xfff < uVar11) {
        pppppuVar5 = (undefined4 *****)ppppuStack_2c[-1];
        uVar11 = uStack_1c._4_4_ + 0x24;
        if (0x1f < (uint)((int)ppppuStack_2c + (-4 - (int)pppppuVar5))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar5,uVar11);
    }
  }
  if (param_1 != (int *)0x0) {
    FUN_0151fa60("ExceptionCode",*(undefined4 *)*param_1);
    FUN_00565940(3,1);
    uStack_8._0_1_ = 3;
    FUN_005925c0();
    FUN_0058c420();
    uVar11 = 1;
    uStack_8._0_1_ = 4;
    pppppuVar5 = &ppppuStack_2c;
    if (0xf < uStack_1c._4_4_) {
      pppppuVar5 = (undefined4 *****)ppppuStack_2c;
    }
    FUN_0151f850("ExceptionAddress",pppppuVar5);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (0xf < uStack_1c._4_4_) {
      uVar12 = uStack_1c._4_4_ + 1;
      pppppuVar5 = (undefined4 *****)ppppuStack_2c;
      if (0xfff < uVar12) {
        pppppuVar5 = (undefined4 *****)ppppuStack_2c[-1];
        uVar12 = uStack_1c._4_4_ + 0x24;
        if (0x1f < (uint)((int)ppppuStack_2c + (-4 - (int)pppppuVar5))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar5,uVar12);
    }
    uStack_30 = 0;
    while( true ) {
      uStack_3c = (double)CONCAT44(uVar11,(undefined4)uStack_3c);
      if (*(uint *)(*param_1 + 0x10) <= uStack_30) break;
      appuStack_108[0] = &PTR_018bf148;
      appuStack_f8[0] = (undefined **)&DAT_018bf150;
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      ppuStack_a0 = std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
      uStack_34 = uVar11 | 2;
      uStack_a4 = 0x50;
      uStack_100 = 0;
      FUN_00554f20(appuStack_f8 + 2,0);
      *(undefined ***)((int)appuStack_f8 + (int)appuStack_f8[0][1]) =
           std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
      *(undefined **)((int)appuStack_f8 + (int)(appuStack_f8[0][1] + -4)) = appuStack_f8[0][1] + -8;
      *(undefined ***)((int)appuStack_108 + (int)appuStack_108[0][1]) =
           std::basic_iostream<char,struct_std::char_traits<char>_>::vftable;
      *(undefined **)((int)&iStack_10c + (int)appuStack_108[0][1]) = appuStack_108[0][1] + -0x20;
      uStack_8 = 10;
      *(undefined ***)((int)appuStack_108 + (int)appuStack_108[0][1]) =
           std::basic_stringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
           vftable;
      *(undefined **)((int)&iStack_10c + (int)appuStack_108[0][1]) = appuStack_108[0][1] + -0x68;
      FUN_0054ee60();
      appuStack_f8[2] =
           std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
           vftable;
      uStack_b8 = 0;
      uStack_b4 = 0;
      uStack_8._0_1_ = 0xb;
      FUN_0056ef60();
      FUN_0058c420();
      uVar11 = uStack_3c._4_4_ | 0x22;
      uStack_8._0_1_ = 0xc;
      pppppuVar5 = appppuStack_54;
      if (0xf < uStack_40) {
        pppppuVar5 = (undefined4 *****)appppuStack_54[0];
      }
      puVar6 = (undefined4 *)FUN_01675640(&ppppuStack_2c,"ExceptionParameter-%u");
      uStack_8._0_1_ = 0xd;
      if (0xf < (uint)puVar6[5]) {
        puVar6 = (undefined4 *)*puVar6;
      }
      FUN_0151f850(puVar6,pppppuVar5);
      uStack_8._0_1_ = 0xc;
      uVar3 = (undefined)uStack_8;
      uStack_8._0_1_ = 0xc;
      if (0xf < uStack_1c._4_4_) {
        pppppuVar5 = (undefined4 *****)ppppuStack_2c;
        if (0xfff < uStack_1c._4_4_ + 1) {
          pppppuVar5 = (undefined4 *****)ppppuStack_2c[-1];
          if (0x1f < (uint)((int)ppppuStack_2c + (-4 - (int)pppppuVar5))) {
            uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(pppppuVar5);
      }
      uStack_1c = 0xf00000000;
      ppppuStack_2c = (undefined4 ****)((uint)ppppuStack_2c & 0xffffff00);
      uStack_8._0_1_ = 0xb;
      uVar3 = (undefined)uStack_8;
      uStack_8._0_1_ = 0xb;
      if (0xf < uStack_40) {
        pppppuVar5 = (undefined4 *****)appppuStack_54[0];
        if (0xfff < uStack_40 + 1) {
          pppppuVar5 = (undefined4 *****)appppuStack_54[0][-1];
          if (0x1f < (uint)((int)appppuStack_54[0] + (-4 - (int)pppppuVar5))) {
            uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(pppppuVar5);
      }
      *(undefined ***)((int)appuStack_108 + (int)appuStack_108[0][1]) =
           std::basic_stringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
           vftable;
      *(undefined **)((int)&iStack_10c + (int)appuStack_108[0][1]) = appuStack_108[0][1] + -0x68;
      FUN_0056b950();
      *(undefined ***)((int)appuStack_108 + (int)appuStack_108[0][1]) =
           std::basic_iostream<char,struct_std::char_traits<char>_>::vftable;
      *(undefined **)((int)&iStack_10c + (int)appuStack_108[0][1]) = appuStack_108[0][1] + -0x20;
      *(undefined ***)((int)appuStack_f8 + (int)appuStack_f8[0][1]) =
           std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
      *(undefined **)((int)appuStack_f8 + (int)(appuStack_f8[0][1] + -4)) = appuStack_f8[0][1] + -8;
      *(undefined ***)((int)appuStack_108 + (int)appuStack_108[0][1]) =
           std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
      *(undefined **)((int)&iStack_10c + (int)appuStack_108[0][1]) = appuStack_108[0][1] + -0x18;
      uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
      ppuStack_a0 = std::ios_base::vftable;
      FUN_016de551();
      uStack_30 = uStack_30 + 1;
    }
    uStack_8._0_1_ = 1;
    FUN_005705c0();
  }
  FUN_00590150();
  puVar6 = (undefined4 *)FUN_00590160();
  uStack_8._0_1_ = 0xf;
  if (0xf < (uint)puVar6[5]) {
    puVar6 = (undefined4 *)*puVar6;
  }
  FUN_0151f850("SessionID",puVar6);
  uStack_8._0_1_ = 1;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_40) {
    uVar11 = uStack_40 + 1;
    pppppuVar5 = (undefined4 *****)appppuStack_54[0];
    if (0xfff < uVar11) {
      pppppuVar5 = (undefined4 *****)appppuStack_54[0][-1];
      uVar11 = uStack_40 + 0x24;
      if (0x1f < (uint)((int)appppuStack_54[0] + (-4 - (int)pppppuVar5))) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar5,uVar11);
  }
  uVar2 = DAT_01d59404;
  FUN_00558ce0(appppuStack_54,&DAT_01d59430,"CrashEvent");
  puVar6 = &DAT_01d59448;
  if (0xf < DAT_01d5945c) {
    puVar6 = DAT_01d59448;
  }
  uStack_8._0_1_ = 0x10;
  puVar7 = (uint *)FUN_00554150(puVar6,DAT_01d59458);
  ppppuStack_2c = (undefined4 ****)*puVar7;
  uStack_28 = puVar7[1];
  uStack_24 = puVar7[2];
  uStack_20 = puVar7[3];
  uStack_1c = *(undefined8 *)(puVar7 + 4);
  puVar7[4] = 0;
  puVar7[5] = 0xf;
  *(undefined *)puVar7 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
  FUN_01520d20(&ppppuStack_2c,uVar2,0);
  if (0xf < uStack_1c._4_4_) {
    uVar11 = uStack_1c._4_4_ + 1;
    ppppuVar9 = ppppuStack_2c;
    if (0xfff < uVar11) {
      ppppuVar9 = (undefined4 ****)ppppuStack_2c[-1];
      uVar11 = uStack_1c._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppuStack_2c + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar9,uVar11);
  }
  uStack_1c = 0xf00000000;
  ppppuStack_2c = (undefined4 ****)((uint)ppppuStack_2c & 0xffffff00);
  if (0xf < uStack_40) {
    uVar11 = uStack_40 + 1;
    pppppuVar5 = (undefined4 *****)appppuStack_54[0];
    if (0xfff < uVar11) {
      pppppuVar5 = (undefined4 *****)appppuStack_54[0][-1];
      uVar11 = uStack_40 + 0x24;
      if (0x1f < (uint)((int)appppuStack_54[0] + (-4 - (int)pppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar5,uVar11);
  }
  FUN_0151f7f0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 4246 ; VA 0x005938be ; Catch@005938be */

undefined4 Catch_005938be(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  if (DAT_01d84e8e != '\0') {
    uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x54) + 4))();
    FUN_01677520(DAT_01d84e8e,"Exception while uploading crash analytics: %s",uVar1);
  }
  return 0x5938ad;
}



/* FUNCTION 4247 ; VA 0x005938ed ; Catch_All@005938ed */

undefined4 Catch_All_005938ed(void)

{
  if (DAT_01d84e8e != '\0') {
    FUN_01677520(DAT_01d84e8e,"Exception while uploading crash analytics");
  }
  return 0x5938ad;
}



/* FUNCTION 4248 ; VA 0x00593940 ; FUN_00593940 */

void __fastcall FUN_00593940(int param_1)

{
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_00592870(1);
  }
  return;
}



/* FUNCTION 4249 ; VA 0x00593950 ; FUN_00593950 */

void __thiscall FUN_00593950(int param_1,uint param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  uVar5 = *(uint *)(param_1 + 8);
  uVar2 = 1;
  if (uVar5 != 0) {
    uVar2 = uVar5;
  }
  for (; (uVar4 = uVar2 - uVar5, uVar4 < param_2 || (uVar2 < 8)); uVar2 = uVar2 * 2) {
    if (0x4444444 - uVar2 < uVar2) {
      FUN_00593ce0();
LAB_00593b2c:
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  uVar1 = *(uint *)(param_1 + 0xc);
  uVar5 = uVar2 * 4;
  if (uVar2 < 0x40000000) {
    if (0xfff < uVar5) goto LAB_005939b4;
    if (uVar5 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_005939b4:
    uVar2 = uVar5 + 0x23;
    if (uVar2 <= uVar5) {
      uVar2 = 0xffffffff;
    }
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_00593b2c;
    uVar5 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar5 - 4) = iVar3;
  }
  iVar3 = *(int *)(param_1 + 4);
  iVar6 = uVar1 * 4 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  iVar3 = (*(int *)(param_1 + 8) * 4 - iVar6) + iVar3;
  iVar8 = uVar1 * 4 + uVar5;
  FUN_0170cc70(iVar8,iVar6,iVar3);
  iVar8 = iVar8 + iVar3;
  FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
  if (uVar4 < uVar1) {
    iVar7 = uVar4 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar7);
    iVar6 = *(int *)(param_1 + 4);
    iVar3 = iVar7 + iVar6;
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    iVar6 = (iVar6 - iVar3) + uVar1 * 4;
    FUN_0170cc70(uVar5,iVar3,iVar6);
    FUN_0170d1f0(iVar6 + uVar5,0,iVar7);
  }
  else {
    iVar3 = uVar1 * 4;
    FUN_0170cc70(iVar8,*(undefined4 *)(param_1 + 4),iVar3);
    FUN_0170d1f0(iVar8 + iVar3,0,(uVar4 - uVar1) * 4);
    FUN_0170d1f0(uVar5,0,iVar3);
  }
  iVar3 = *(int *)(param_1 + 4);
  if (iVar3 != 0) {
    uVar2 = *(int *)(param_1 + 8) * 4;
    iVar6 = iVar3;
    if (0xfff < uVar2) {
      iVar6 = *(int *)(iVar3 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar3 - iVar6) - 4U) goto LAB_00593b2c;
    }
    FUN_01674ea0(iVar6,uVar2);
  }
  *(uint *)(param_1 + 4) = uVar5;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + uVar4;
  return;
}


