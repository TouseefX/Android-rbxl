/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 28000 ; VA 0x00c399b0 ; FUN_00c399b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c399b0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809050;
  pvStack_10 = ExceptionList;
  if (DAT_01efb4a8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efb6c0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efb6c0);
      if (DAT_01efb6c0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c39010();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"RotateV",0,uStack_20,0,0,0x1b,0,&DAT_01efa9f8);
        _DAT_01efb6b8 = RBX::Creator<class_RBX::RotateV>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efb4b0,&DAT_01efb6b8);
        FUN_016f3654(FUN_018946e0);
        FUN_016f37bf(&DAT_01efb6c0);
      }
    }
    DAT_01efb4a8 = &DAT_01efb4b0;
  }
  ExceptionList = pvStack_10;
  return DAT_01efb4a8;
}



/* FUNCTION 28001 ; VA 0x00c39ab0 ; FUN_00c39ab0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c39ab0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809080;
  pvStack_10 = ExceptionList;
  if (DAT_01efb6c8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efb8e0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efb8e0);
      if (DAT_01efb8e0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c391f0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,&DAT_019696bc,0,uStack_20,0,0,0x1b,0,&DAT_01efa9f8);
        _DAT_01efb8d8 = RBX::Creator<class_RBX::Snap>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efb6d0,&DAT_01efb8d8);
        FUN_016f3654(FUN_01894740);
        FUN_016f37bf(&DAT_01efb8e0);
      }
    }
    DAT_01efb6c8 = &DAT_01efb6d0;
  }
  ExceptionList = pvStack_10;
  return DAT_01efb6c8;
}



/* FUNCTION 28002 ; VA 0x00c39bb0 ; FUN_00c39bb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c39bb0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018090b0;
  pvStack_10 = ExceptionList;
  if (DAT_01efb8e8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efbb00) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efbb00);
      if (DAT_01efbb00 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c391f0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,&DAT_019696c4,0,uStack_20,0,0,0x1b,0,&DAT_01efa9f8);
        _DAT_01efbaf8 = RBX::Creator<class_RBX::Weld>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efb8f0,&DAT_01efbaf8);
        FUN_016f3654(FUN_018947a0);
        FUN_016f37bf(&DAT_01efbb00);
      }
    }
    DAT_01efb8e8 = &DAT_01efb8f0;
  }
  ExceptionList = pvStack_10;
  return DAT_01efb8e8;
}



/* FUNCTION 28003 ; VA 0x00c39cb0 ; FUN_00c39cb0 */

int __thiscall FUN_00c39cb0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018090c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ManualGlue*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28004 ; VA 0x00c39d82 ; Catch_All@00c39d82 */

void Catch_All_00c39d82(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28005 ; VA 0x00c39da0 ; FUN_00c39da0 */

int __thiscall FUN_00c39da0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018090d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ManualWeld*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28006 ; VA 0x00c39e72 ; Catch_All@00c39e72 */

void Catch_All_00c39e72(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28007 ; VA 0x00c39e90 ; FUN_00c39e90 */

int __thiscall FUN_00c39e90(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018090e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Motor*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28008 ; VA 0x00c39f62 ; Catch_All@00c39f62 */

void Catch_All_00c39f62(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28009 ; VA 0x00c39f80 ; FUN_00c39f80 */

undefined4 * __thiscall FUN_00c39f80(undefined4 param_1,undefined4 *param_2,undefined8 *param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c3f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  puVar2 = (undefined4 *)FUN_01674e20(0x24);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 1;
    puVar2[2] = FUN_00c3bba0;
    puVar2[3] = _guard_check_icall;
    puVar2[4] = 0;
    puVar2[5] = param_1;
    *(undefined8 *)(puVar2 + 6) = *param_3;
    puVar2[8] = *(undefined4 *)(param_3 + 1);
  }
  FUN_016797d0(puVar2);
  *param_2 = puVar2;
  if (puVar2 != (undefined4 *)0x0) {
    LOCK();
    puVar2[1] = puVar2[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28010 ; VA 0x00c3a050 ; FUN_00c3a050 */

undefined4 * __thiscall FUN_00c3a050(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c3f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  puVar2 = (undefined4 *)FUN_01674e20(0x1c);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 1;
    puVar2[2] = FUN_00c3bbc0;
    puVar2[3] = _guard_check_icall;
    puVar2[4] = 0;
    puVar2[5] = param_1;
    puVar2[6] = *param_3;
  }
  FUN_016797d0(puVar2);
  *param_2 = puVar2;
  if (puVar2 != (undefined4 *)0x0) {
    LOCK();
    puVar2[1] = puVar2[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28011 ; VA 0x00c3a110 ; FUN_00c3a110 */

undefined4 * FUN_00c3a110(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01809157;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c392d0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x9c);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
    goto LAB_00c3a26c;
  }
  if (DAT_01efa9e0 == '\0') {
    puVar4 = (undefined4 *)FUN_01674e20(0xec);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (puVar4 == (undefined4 *)0x0) goto LAB_00c3a201;
    FUN_00cc2c60();
    *puVar4 = RBX::ManualGlueJoint::vftable;
    puVar4[2] = RBX::ManualGlueJoint::vftable;
    puVar4[0x39] = 0xffffffff;
    puVar4[0x3a] = 0xffffffff;
  }
  else {
    puVar4 = (undefined4 *)FUN_01674e20(0xa8);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (puVar4 == (undefined4 *)0x0) {
LAB_00c3a201:
      puVar4 = (undefined4 *)0x0;
    }
    else {
      FUN_00ca27c0();
      *puVar4 = RBX::WeldJoint::vftable;
      puVar4[2] = RBX::WeldJoint::vftable;
    }
  }
  uStack_8._0_1_ = 2;
  FUN_00c3a790(puVar4,"ManualGlue");
  uStack_8._0_1_ = 5;
  *puVar3 = RBX::Described<class_RBX::ManualSurfaceJointInstance,class_RBX::JointInstance>::vftable;
  puVar3[0x15] = RBX::Described<class_RBX::ManualSurfaceJointInstance,class_RBX::JointInstance>::
                 vftable;
  puVar3[0x1c] = RBX::Described<class_RBX::ManualSurfaceJointInstance,class_RBX::JointInstance>::
                 vftable;
  uVar5 = FUN_00c393d0();
  puVar3[3] = uVar5;
  uStack_8._0_1_ = 6;
  *puVar3 = RBX::DescribedCreatable<class_RBX::ManualGlue,class_RBX::ManualSurfaceJointInstance>::
            vftable;
  puVar3[0x15] = RBX::
                 DescribedCreatable<class_RBX::ManualGlue,class_RBX::ManualSurfaceJointInstance>::
                 vftable;
  puVar3[0x1c] = RBX::
                 DescribedCreatable<class_RBX::ManualGlue,class_RBX::ManualSurfaceJointInstance>::
                 vftable;
  uVar5 = FUN_00c392d0();
  puVar3[3] = uVar5;
  *puVar3 = RBX::ManualGlue::vftable;
  puVar3[0x15] = RBX::ManualGlue::vftable;
  puVar3[0x1c] = RBX::ManualGlue::vftable;
LAB_00c3a26c:
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c39cb0(puVar3,param_1);
  uStack_8 = 10;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28012 ; VA 0x00c3a2c0 ; FUN_00c3a2c0 */

undefined4 * FUN_00c3a2c0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018091d7;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c394b0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x9c);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
    goto LAB_00c3a41c;
  }
  if (DAT_01efa9e0 == '\0') {
    puVar4 = (undefined4 *)FUN_01674e20(0xb0);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (puVar4 == (undefined4 *)0x0) goto LAB_00c3a3b1;
    FUN_00ca27c0();
    *puVar4 = RBX::ManualWeldJoint::vftable;
    puVar4[2] = RBX::ManualWeldJoint::vftable;
    puVar4[0x2a] = 0xffffffff;
    puVar4[0x2b] = 0xffffffff;
  }
  else {
    puVar4 = (undefined4 *)FUN_01674e20(0xa8);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (puVar4 == (undefined4 *)0x0) {
LAB_00c3a3b1:
      puVar4 = (undefined4 *)0x0;
    }
    else {
      FUN_00ca27c0();
      *puVar4 = RBX::WeldJoint::vftable;
      puVar4[2] = RBX::WeldJoint::vftable;
    }
  }
  uStack_8._0_1_ = 2;
  FUN_00c3a790(puVar4,"ManualWeld");
  uStack_8._0_1_ = 5;
  *puVar3 = RBX::Described<class_RBX::ManualSurfaceJointInstance,class_RBX::JointInstance>::vftable;
  puVar3[0x15] = RBX::Described<class_RBX::ManualSurfaceJointInstance,class_RBX::JointInstance>::
                 vftable;
  puVar3[0x1c] = RBX::Described<class_RBX::ManualSurfaceJointInstance,class_RBX::JointInstance>::
                 vftable;
  uVar5 = FUN_00c393d0();
  puVar3[3] = uVar5;
  uStack_8._0_1_ = 6;
  *puVar3 = RBX::DescribedCreatable<class_RBX::ManualWeld,class_RBX::ManualSurfaceJointInstance>::
            vftable;
  puVar3[0x15] = RBX::
                 DescribedCreatable<class_RBX::ManualWeld,class_RBX::ManualSurfaceJointInstance>::
                 vftable;
  puVar3[0x1c] = RBX::
                 DescribedCreatable<class_RBX::ManualWeld,class_RBX::ManualSurfaceJointInstance>::
                 vftable;
  uVar5 = FUN_00c394b0();
  puVar3[3] = uVar5;
  *puVar3 = RBX::ManualWeld::vftable;
  puVar3[0x15] = RBX::ManualWeld::vftable;
  puVar3[0x1c] = RBX::ManualWeld::vftable;
LAB_00c3a41c:
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c39da0(puVar3,param_1);
  uStack_8 = 10;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28013 ; VA 0x00c3a470 ; FUN_00c3a470 */

undefined4 * FUN_00c3a470(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_0180923d;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c396b0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x9c);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    iVar1 = FUN_01674e20(0xd0);
    uStack_8._0_1_ = 3;
    if (iVar1 == 0) {
      uVar4 = 0;
    }
    else {
      uVar4 = FUN_01064620();
    }
    uStack_8._0_1_ = 2;
    FUN_00c3a790(uVar4,"Motor");
    uStack_8._0_1_ = 4;
    *puVar3 = RBX::DescribedCreatable<class_RBX::Motor,class_RBX::JointInstance>::vftable;
    puVar3[0x15] = RBX::DescribedCreatable<class_RBX::Motor,class_RBX::JointInstance>::vftable;
    puVar3[0x1c] = RBX::DescribedCreatable<class_RBX::Motor,class_RBX::JointInstance>::vftable;
    uVar4 = FUN_00c396b0();
    puVar3[3] = uVar4;
    puVar3[0x25] = RBX::IAnimatableJoint::vftable;
    *(undefined *)(puVar3 + 0x26) = 0;
    *puVar3 = RBX::Motor::vftable;
    puVar3[0x15] = RBX::Motor::vftable;
    puVar3[0x1c] = RBX::Motor::vftable;
    puVar3[0x25] = RBX::Motor::vftable;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c39e90(puVar3,param_1);
  uStack_8 = 8;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28014 ; VA 0x00c3a5c0 ; FUN_00c3a5c0 */

undefined4 FUN_00c3a5c0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  
  iVar2 = param_1[1];
  if (iVar2 != 0) {
    piVar5 = (int *)(iVar2 + 4);
    iVar2 = *(int *)(iVar2 + 4);
    while (iVar2 != 0) {
      LOCK();
      iVar4 = *piVar5;
      if (iVar2 == iVar4) {
        *piVar5 = iVar2 + 1;
        iVar4 = iVar2;
      }
      UNLOCK();
      if (iVar4 == iVar2) {
        piVar5 = (int *)param_1[1];
        uVar3 = *param_1;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar2 = piVar5[1] + -1;
          piVar5[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            piVar1 = piVar5 + 2;
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        return uVar3;
      }
      iVar2 = *piVar5;
    }
  }
  return 0;
}



/* FUNCTION 28015 ; VA 0x00c3a630 ; FUN_00c3a630 */

undefined4 * __fastcall FUN_00c3a630(undefined4 *param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180927c;
  pvStack_10 = ExceptionList;
  if (DAT_01efa9e0 == '\0') {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_01674e20(0xe4);
    uStack_8 = 1;
    if (iVar2 != 0) {
      puVar1 = (undefined4 *)FUN_00cc2c60();
      goto LAB_00c3a6b6;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    puVar1 = (undefined4 *)FUN_01674e20(0xa8);
    uStack_8 = 0;
    if (puVar1 != (undefined4 *)0x0) {
      FUN_00ca27c0();
      *puVar1 = RBX::WeldJoint::vftable;
      puVar1[2] = RBX::WeldJoint::vftable;
      goto LAB_00c3a6b6;
    }
  }
  puVar1 = (undefined4 *)0x0;
LAB_00c3a6b6:
  uStack_8 = 0xffffffff;
  FUN_00c3a790(puVar1,&DAT_019696e4);
  uStack_8 = 2;
  *param_1 = RBX::DescribedCreatable<class_RBX::Glue,class_RBX::JointInstance>::vftable;
  param_1[0x15] = RBX::DescribedCreatable<class_RBX::Glue,class_RBX::JointInstance>::vftable;
  param_1[0x1c] = RBX::DescribedCreatable<class_RBX::Glue,class_RBX::JointInstance>::vftable;
  uVar3 = FUN_00c390f0();
  param_1[3] = uVar3;
  *param_1 = RBX::Glue::vftable;
  param_1[0x15] = RBX::Glue::vftable;
  param_1[0x1c] = RBX::Glue::vftable;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28016 ; VA 0x00c3a790 ; FUN_00c3a790 */

undefined4 * __thiscall FUN_00c3a790(undefined4 *param_1,int param_2,undefined4 param_3)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018092d9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a650(param_3);
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::JointInstance,class_RBX::Instance>::vftable;
  uVar3 = FUN_00c391f0();
  param_1[3] = uVar3;
  param_1[0x15] = RBX::IAdornable::vftable;
  param_1[0x16] = 0xffffffff;
  param_1[0x17] = 0xffffffff;
  param_1[0x18] = 0xffffffff;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = RBX::IJointOwner::vftable;
  uStack_8._0_1_ = 2;
  uStack_8._1_3_ = 0;
  *param_1 = RBX::JointInstance::vftable;
  param_1[0x15] = RBX::JointInstance::vftable;
  param_1[0x1c] = RBX::JointInstance::vftable;
  FUN_016f4053(param_1 + 0x1d,8,2,FUN_005502b0,FUN_0056c200);
  uStack_8._0_1_ = 3;
  FUN_016f4053(param_1 + 0x21,4,2,FUN_00610ca0,FUN_005f60a0);
  *(undefined *)(param_1 + 0x23) = 1;
  param_1[0x24] = param_2;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (DAT_01ee41fc != '\0') {
    FUN_01677490(DAT_01ee41fc,"Joint Instance created: %p, joint: %p",param_1,param_2,0);
  }
  FUN_00ca48f0(param_1 + 0x1c);
  uVar3 = FUN_00b06640(*(undefined4 *)(param_2 + 0x2c));
  uVar4 = FUN_00b06640(*(undefined4 *)(param_2 + 0x30));
  puVar5 = (undefined4 *)FUN_0060dcd0(auStack_1c,uVar3);
  iVar6 = puVar5[1];
  if (iVar6 != 0) {
    LOCK();
    *(int *)(iVar6 + 8) = *(int *)(iVar6 + 8) + 1;
    UNLOCK();
    iVar6 = puVar5[1];
  }
  param_1[0x1d] = *puVar5;
  piVar2 = (int *)param_1[0x1e];
  param_1[0x1e] = iVar6;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[2] + -1;
    piVar2[2] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_18[1] + -1;
    piStack_18[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar6 = *piVar1 + -1;
      *piVar1 = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  puVar5 = (undefined4 *)FUN_0060dcd0(auStack_1c,uVar4);
  iVar6 = puVar5[1];
  if (iVar6 != 0) {
    LOCK();
    *(int *)(iVar6 + 8) = *(int *)(iVar6 + 8) + 1;
    UNLOCK();
    iVar6 = puVar5[1];
  }
  param_1[0x1f] = *puVar5;
  piVar2 = (int *)param_1[0x20];
  param_1[0x20] = iVar6;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar6 = piVar2[2] + -1;
    piVar2[2] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_18[1] + -1;
    piStack_18[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar2 = piStack_18 + 2;
      iVar6 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  iVar6 = param_1[0x24];
  *(undefined4 *)(iVar6 + 0xa0) = param_1[6];
  *(undefined4 *)(iVar6 + 0xa4) = param_1[7];
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28017 ; VA 0x00c3a9b0 ; FUN_00c3a9b0 */

undefined4 * __fastcall FUN_00c3a9b0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809312;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(0xf4);
  uStack_8 = 0;
  if (iVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_01063090();
  }
  uStack_8 = 0xffffffff;
  FUN_00c3a790(uVar2,"Motor6D");
  uStack_8 = 1;
  *param_1 = RBX::DescribedCreatable<class_RBX::Motor,class_RBX::JointInstance>::vftable;
  param_1[0x15] = RBX::DescribedCreatable<class_RBX::Motor,class_RBX::JointInstance>::vftable;
  param_1[0x1c] = RBX::DescribedCreatable<class_RBX::Motor,class_RBX::JointInstance>::vftable;
  uVar2 = FUN_00c396b0();
  param_1[3] = uVar2;
  param_1[0x25] = RBX::IAnimatableJoint::vftable;
  *(undefined *)(param_1 + 0x26) = 0;
  uStack_8 = 2;
  *param_1 = RBX::DescribedCreatable<class_RBX::Motor6D,class_RBX::Motor>::vftable;
  param_1[0x15] = RBX::DescribedCreatable<class_RBX::Motor6D,class_RBX::Motor>::vftable;
  param_1[0x1c] = RBX::DescribedCreatable<class_RBX::Motor6D,class_RBX::Motor>::vftable;
  param_1[0x25] = RBX::DescribedCreatable<class_RBX::Motor6D,class_RBX::Motor>::vftable;
  uVar2 = FUN_00c395b0();
  param_1[3] = uVar2;
  *param_1 = RBX::Motor6D::vftable;
  param_1[0x15] = RBX::Motor6D::vftable;
  param_1[0x1c] = RBX::Motor6D::vftable;
  param_1[0x25] = RBX::Motor6D::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28018 ; VA 0x00c3aaa0 ; FUN_00c3aaa0 */

undefined4 * __fastcall FUN_00c3aaa0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0180933a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_01674e20(0xb0);
  uStack_8 = 0;
  if (iVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_010807f0();
  }
  uStack_8 = 0xffffffff;
  FUN_00c3a790(uVar2,"Rotate");
  uStack_8 = 1;
  *param_1 = RBX::DescribedCreatable<class_RBX::Rotate,class_RBX::JointInstance>::vftable;
  param_1[0x15] = RBX::DescribedCreatable<class_RBX::Rotate,class_RBX::JointInstance>::vftable;
  param_1[0x1c] = RBX::DescribedCreatable<class_RBX::Rotate,class_RBX::JointInstance>::vftable;
  uVar2 = FUN_00c397b0();
  param_1[3] = uVar2;
  *param_1 = RBX::Rotate::vftable;
  param_1[0x15] = RBX::Rotate::vftable;
  param_1[0x1c] = RBX::Rotate::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28019 ; VA 0x00c3ab50 ; FUN_00c3ab50 */

undefined4 * __fastcall FUN_00c3ab50(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809372;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0xc0);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    FUN_010807f0();
    puVar1[0x2c] = 0;
    puVar1[0x2d] = 0;
    *puVar1 = RBX::RotatePJoint::vftable;
    puVar1[2] = RBX::RotatePJoint::vftable;
    puVar1[0x2e] = 0;
    puVar1[0x2f] = 0;
  }
  uStack_8 = 0xffffffff;
  FUN_00c3a790(puVar1,"RotateP");
  uStack_8 = 1;
  *param_1 = RBX::Described<class_RBX::DynamicRotate,class_RBX::JointInstance>::vftable;
  param_1[0x15] = RBX::Described<class_RBX::DynamicRotate,class_RBX::JointInstance>::vftable;
  param_1[0x1c] = RBX::Described<class_RBX::DynamicRotate,class_RBX::JointInstance>::vftable;
  uVar2 = FUN_00c39010();
  param_1[3] = uVar2;
  uStack_8 = 2;
  *param_1 = RBX::DescribedCreatable<class_RBX::RotateP,class_RBX::DynamicRotate>::vftable;
  param_1[0x15] = RBX::DescribedCreatable<class_RBX::RotateP,class_RBX::DynamicRotate>::vftable;
  param_1[0x1c] = RBX::DescribedCreatable<class_RBX::RotateP,class_RBX::DynamicRotate>::vftable;
  uVar2 = FUN_00c398b0();
  param_1[3] = uVar2;
  *param_1 = RBX::RotateP::vftable;
  param_1[0x15] = RBX::RotateP::vftable;
  param_1[0x1c] = RBX::RotateP::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28020 ; VA 0x00c3ac50 ; FUN_00c3ac50 */

undefined4 * __fastcall FUN_00c3ac50(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809372;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0xc0);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    FUN_010807f0();
    puVar1[0x2c] = 0;
    puVar1[0x2d] = 0;
    *puVar1 = RBX::RotateVJoint::vftable;
    puVar1[2] = RBX::RotateVJoint::vftable;
    puVar1[0x2e] = 0;
    puVar1[0x2f] = 0;
  }
  uStack_8 = 0xffffffff;
  FUN_00c3a790(puVar1,"RotateV");
  uStack_8 = 1;
  *param_1 = RBX::Described<class_RBX::DynamicRotate,class_RBX::JointInstance>::vftable;
  param_1[0x15] = RBX::Described<class_RBX::DynamicRotate,class_RBX::JointInstance>::vftable;
  param_1[0x1c] = RBX::Described<class_RBX::DynamicRotate,class_RBX::JointInstance>::vftable;
  uVar2 = FUN_00c39010();
  param_1[3] = uVar2;
  uStack_8 = 2;
  *param_1 = RBX::DescribedCreatable<class_RBX::RotateV,class_RBX::DynamicRotate>::vftable;
  param_1[0x15] = RBX::DescribedCreatable<class_RBX::RotateV,class_RBX::DynamicRotate>::vftable;
  param_1[0x1c] = RBX::DescribedCreatable<class_RBX::RotateV,class_RBX::DynamicRotate>::vftable;
  uVar2 = FUN_00c399b0();
  param_1[3] = uVar2;
  *param_1 = RBX::RotateV::vftable;
  param_1[0x15] = RBX::RotateV::vftable;
  param_1[0x1c] = RBX::RotateV::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28021 ; VA 0x00c3ad50 ; FUN_00c3ad50 */

undefined4 * __fastcall FUN_00c3ad50(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018093ac;
  pvStack_10 = ExceptionList;
  if (DAT_01efa9e0 == '\0') {
    ExceptionList = &pvStack_10;
    puVar1 = (undefined4 *)FUN_01674e20(0xa8);
    uStack_8 = 1;
    if (puVar1 != (undefined4 *)0x0) {
      FUN_00ca27c0();
      *puVar1 = RBX::SnapJoint::vftable;
      puVar1[2] = RBX::SnapJoint::vftable;
      goto LAB_00c3adde;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    puVar1 = (undefined4 *)FUN_01674e20(0xa8);
    uStack_8 = 0;
    if (puVar1 != (undefined4 *)0x0) {
      FUN_00ca27c0();
      *puVar1 = RBX::WeldJoint::vftable;
      puVar1[2] = RBX::WeldJoint::vftable;
      goto LAB_00c3adde;
    }
  }
  puVar1 = (undefined4 *)0x0;
LAB_00c3adde:
  uStack_8 = 0xffffffff;
  FUN_00c3a790(puVar1,&DAT_019696bc);
  uStack_8 = 2;
  *param_1 = RBX::DescribedCreatable<class_RBX::Snap,class_RBX::JointInstance>::vftable;
  param_1[0x15] = RBX::DescribedCreatable<class_RBX::Snap,class_RBX::JointInstance>::vftable;
  param_1[0x1c] = RBX::DescribedCreatable<class_RBX::Snap,class_RBX::JointInstance>::vftable;
  uVar2 = FUN_00c39ab0();
  param_1[3] = uVar2;
  *param_1 = RBX::Snap::vftable;
  param_1[0x15] = RBX::Snap::vftable;
  param_1[0x1c] = RBX::Snap::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28022 ; VA 0x00c3ae40 ; FUN_00c3ae40 */

undefined4 * __fastcall FUN_00c3ae40(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018093da;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0xa8);
  uStack_8 = 0;
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    FUN_00ca27c0();
    *puVar1 = RBX::WeldJoint::vftable;
    puVar1[2] = RBX::WeldJoint::vftable;
  }
  uStack_8 = 0xffffffff;
  FUN_00c3a790(puVar1,&DAT_019696c4);
  uStack_8 = 1;
  *param_1 = RBX::DescribedCreatable<class_RBX::Weld,class_RBX::JointInstance>::vftable;
  param_1[0x15] = RBX::DescribedCreatable<class_RBX::Weld,class_RBX::JointInstance>::vftable;
  param_1[0x1c] = RBX::DescribedCreatable<class_RBX::Weld,class_RBX::JointInstance>::vftable;
  uVar2 = FUN_00c39bb0();
  param_1[3] = uVar2;
  *param_1 = RBX::Weld::vftable;
  param_1[0x15] = RBX::Weld::vftable;
  param_1[0x1c] = RBX::Weld::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28023 ; VA 0x00c3af00 ; FUN_00c3af00 */

void __fastcall FUN_00c3af00(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Glue>::vftable;
  uVar1 = FUN_00c390f0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28024 ; VA 0x00c3af40 ; FUN_00c3af40 */

void __fastcall FUN_00c3af40(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::ManualGlue>::vftable;
  uVar1 = FUN_00c392d0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28025 ; VA 0x00c3af80 ; FUN_00c3af80 */

void __fastcall FUN_00c3af80(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::ManualWeld>::vftable;
  uVar1 = FUN_00c394b0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28026 ; VA 0x00c3afc0 ; FUN_00c3afc0 */

void __fastcall FUN_00c3afc0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Motor6D>::vftable;
  uVar1 = FUN_00c395b0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28027 ; VA 0x00c3b000 ; FUN_00c3b000 */

void __fastcall FUN_00c3b000(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Motor>::vftable;
  uVar1 = FUN_00c396b0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28028 ; VA 0x00c3b040 ; FUN_00c3b040 */

void __fastcall FUN_00c3b040(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Rotate>::vftable;
  uVar1 = FUN_00c397b0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28029 ; VA 0x00c3b080 ; FUN_00c3b080 */

void __fastcall FUN_00c3b080(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::RotateP>::vftable;
  uVar1 = FUN_00c398b0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28030 ; VA 0x00c3b0c0 ; FUN_00c3b0c0 */

void __fastcall FUN_00c3b0c0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::RotateV>::vftable;
  uVar1 = FUN_00c399b0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28031 ; VA 0x00c3b100 ; FUN_00c3b100 */

void __fastcall FUN_00c3b100(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Snap>::vftable;
  uVar1 = FUN_00c39ab0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28032 ; VA 0x00c3b140 ; FUN_00c3b140 */

void __fastcall FUN_00c3b140(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Weld>::vftable;
  uVar1 = FUN_00c39bb0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28033 ; VA 0x00c3b180 ; thunk_FUN_00c3b200 */

void __fastcall thunk_FUN_00c3b200(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::JointInstance::vftable;
  param_1[0x15] = RBX::JointInstance::vftable;
  param_1[0x1c] = RBX::JointInstance::vftable;
  if (DAT_01ee41fc != '\0') {
    FUN_01677490(DAT_01ee41fc,"Joint Instance destroyed: %p, joint: %p",param_1,param_1[0x24],0);
  }
  FUN_00ca48f0(0);
  FUN_00ca4900(0,0);
  FUN_00ca4900(1,0);
  if ((undefined4 *)param_1[0x24] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x24])(1);
  }
  param_1[0x24] = 0;
  FUN_016f32d1(param_1 + 0x21,4,2,FUN_005f60a0);
  FUN_016f32d1(param_1 + 0x1d,8,2,FUN_0056c200);
  FUN_0115a710();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28034 ; VA 0x00c3b190 ; FUN_00c3b190 */

void __fastcall FUN_00c3b190(int param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = *(int *)(param_1 + 0xd8);
  if (iVar1 != 0) {
    uVar3 = *(int *)(param_1 + 0xe0) - iVar1 & 0xfffffffc;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *(undefined4 *)(param_1 + 0xd8) = 0;
    *(undefined4 *)(param_1 + 0xdc) = 0;
    *(undefined4 *)(param_1 + 0xe0) = 0;
  }
  FUN_00ca2b60();
  return;
}



/* FUNCTION 28035 ; VA 0x00c3b200 ; FUN_00c3b200 */

void __fastcall FUN_00c3b200(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::JointInstance::vftable;
  param_1[0x15] = RBX::JointInstance::vftable;
  param_1[0x1c] = RBX::JointInstance::vftable;
  if (DAT_01ee41fc != '\0') {
    FUN_01677490(DAT_01ee41fc,"Joint Instance destroyed: %p, joint: %p",param_1,param_1[0x24],0);
  }
  FUN_00ca48f0(0);
  FUN_00ca4900(0,0);
  FUN_00ca4900(1,0);
  if ((undefined4 *)param_1[0x24] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x24])(1);
  }
  param_1[0x24] = 0;
  FUN_016f32d1(param_1 + 0x21,4,2,FUN_005f60a0);
  FUN_016f32d1(param_1 + 0x1d,8,2,FUN_0056c200);
  FUN_0115a710();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28036 ; VA 0x00c3b2f6 ; FUN_00c3b2f6 */

void FUN_00c3b2f6(void)

{
  FUN_00c3b3b0();
  return;
}



/* FUNCTION 28037 ; VA 0x00c3b2fe ; FUN_00c3b2fe */

void FUN_00c3b2fe(void)

{
  FUN_00c3b3e0();
  return;
}



/* FUNCTION 28038 ; VA 0x00c3b306 ; FUN_00c3b306 */

void FUN_00c3b306(void)

{
  FUN_00c3b410();
  return;
}



/* FUNCTION 28039 ; VA 0x00c3b30e ; FUN_00c3b30e */

void FUN_00c3b30e(void)

{
  FUN_00c3b440();
  return;
}



/* FUNCTION 28040 ; VA 0x00c3b320 ; FUN_00c3b320 */

undefined4 __thiscall FUN_00c3b320(undefined4 param_1,byte param_2)

{
  FUN_00c3b200();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x94);
  }
  return param_1;
}



/* FUNCTION 28041 ; VA 0x00c3b350 ; FUN_00c3b350 */

undefined4 __thiscall FUN_00c3b350(undefined4 param_1,byte param_2)

{
  FUN_00c3b200();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x9c);
  }
  return param_1;
}



/* FUNCTION 28042 ; VA 0x00c3b380 ; FUN_00c3b380 */

undefined4 __thiscall FUN_00c3b380(undefined4 param_1,byte param_2)

{
  FUN_00c3b200();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc4);
  }
  return param_1;
}



/* FUNCTION 28043 ; VA 0x00c3b3b0 ; FUN_00c3b3b0 */

undefined4 __thiscall FUN_00c3b3b0(undefined4 param_1,byte param_2)

{
  FUN_00c3b190();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xec);
  }
  return param_1;
}



/* FUNCTION 28044 ; VA 0x00c3b3e0 ; FUN_00c3b3e0 */

undefined4 __thiscall FUN_00c3b3e0(undefined4 param_1,byte param_2)

{
  FUN_00ca2b60();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xb0);
  }
  return param_1;
}



/* FUNCTION 28045 ; VA 0x00c3b410 ; FUN_00c3b410 */

undefined4 __thiscall FUN_00c3b410(undefined4 param_1,byte param_2)

{
  FUN_01080830();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc0);
  }
  return param_1;
}



/* FUNCTION 28046 ; VA 0x00c3b440 ; FUN_00c3b440 */

undefined4 __thiscall FUN_00c3b440(undefined4 param_1,byte param_2)

{
  FUN_01080890();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xc0);
  }
  return param_1;
}



/* FUNCTION 28047 ; VA 0x00c3b470 ; FUN_00c3b470 */

void FUN_00c3b470(int param_1)

{
  undefined4 uVar1;
  
  uVar1 = 0;
  if (*(float *)(param_1 + 0x18) <= 0.0) {
    uVar1 = DAT_018ce2f8;
  }
  FUN_010633e0(param_1,param_1 + 0xc,*(float *)(param_1 + 0x18),uVar1);
  return;
}



/* FUNCTION 28048 ; VA 0x00c3b4b0 ; FUN_00c3b4b0 */

void FUN_00c3b4b0(int param_1)

{
  undefined4 uVar1;
  
  uVar1 = 0;
  if (*(float *)(param_1 + 0x18) <= 0.0) {
    uVar1 = DAT_018ce2f8;
  }
  FUN_01064830(*(undefined4 *)(param_1 + 0x14),*(float *)(param_1 + 0x18),uVar1);
  return;
}



/* FUNCTION 28049 ; VA 0x00c3b4f0 ; FUN_00c3b4f0 */

undefined FUN_00c3b4f0(void)

{
  char cVar1;
  undefined4 uVar2;
  
  uVar2 = FUN_00be8480();
  cVar1 = FUN_00892700(uVar2);
  if (cVar1 == '\0') {
    uVar2 = FUN_00aff8c0();
    cVar1 = FUN_00892700(uVar2);
    if (cVar1 == '\0') {
      return 0;
    }
  }
  return 1;
}



/* FUNCTION 28050 ; VA 0x00c3b530 ; FUN_00c3b530 */

undefined4 * FUN_00c3b530(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00a94c60(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28051 ; VA 0x00c3b5a0 ; FUN_00c3b5a0 */

undefined4 * FUN_00c3b5a0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c3a110(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28052 ; VA 0x00c3b610 ; FUN_00c3b610 */

undefined4 * FUN_00c3b610(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c3a2c0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28053 ; VA 0x00c3b680 ; FUN_00c3b680 */

undefined4 * FUN_00c3b680(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_0099f370(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28054 ; VA 0x00c3b6f0 ; FUN_00c3b6f0 */

undefined4 * FUN_00c3b6f0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c3a470(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28055 ; VA 0x00c3b760 ; FUN_00c3b760 */

undefined4 * FUN_00c3b760(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00a94d20(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28056 ; VA 0x00c3b7d0 ; FUN_00c3b7d0 */

undefined4 * FUN_00c3b7d0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00a94de0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28057 ; VA 0x00c3b840 ; FUN_00c3b840 */

undefined4 * FUN_00c3b840(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00a94ea0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28058 ; VA 0x00c3b8b0 ; FUN_00c3b8b0 */

undefined4 * FUN_00c3b8b0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00a94f60(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28059 ; VA 0x00c3b920 ; FUN_00c3b920 */

undefined4 * FUN_00c3b920(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00a950e0(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28060 ; VA 0x00c3b990 ; FUN_00c3b990 */

void FUN_00c3b990(int *param_1,undefined4 param_2,int param_3,int param_4,undefined4 param_5,
                 undefined4 param_6)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  undefined auStack_c [4];
  int *piStack_8;
  
  if ((*param_1 != 0) && (*(int *)(*param_1 + 0x34) != 0)) {
    cVar2 = FUN_00c3d7a0(0,param_3);
    if (cVar2 != '\0') {
      FUN_008a4940(&DAT_02134d38);
    }
    cVar2 = FUN_00c3d7a0(1,param_4);
    if (cVar2 != '\0') {
      FUN_008a4940(&DAT_02134d74);
    }
    goto LAB_00c3bb52;
  }
  if (((param_3 == 0) || (iVar3 = FUN_008a1240(param_2), iVar3 == 0)) ||
     (iVar6 = *(int *)(iVar3 + 0xc), iVar4 = FUN_00c39bb0(),
     (uint)*(ushort *)(iVar4 + 0x1da) <
     (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
    iVar3 = 0;
  }
  if (DAT_01d68650 == '\0') {
    if (((iVar3 != 0) && (iVar6 = FUN_00c3a5c0(iVar3 + 0x74), iVar6 == param_3)) &&
       (iVar6 = FUN_00c3a5c0(iVar3 + 0x7c), iVar6 == param_4)) {
      uVar5 = FUN_0060dcd0(auStack_c,iVar3);
      FUN_005587e0(uVar5);
      FUN_00550b30();
      goto LAB_00c3bb52;
    }
LAB_00c3bad1:
    uVar5 = FUN_00a950e0(auStack_c);
    FUN_005587e0(uVar5);
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piStack_8 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    (**(code **)(*(int *)*param_1 + 0x38))(param_2);
  }
  else {
    if (iVar3 == 0) goto LAB_00c3bad1;
    uVar5 = FUN_0060dcd0(auStack_c,iVar3);
    FUN_005587e0(uVar5);
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_8[1] + -1;
      piStack_8[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piStack_8 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
  }
  cVar2 = FUN_00c3d7a0(0,param_3);
  if (cVar2 != '\0') {
    FUN_008a4940(&DAT_02134d38);
  }
  cVar2 = FUN_00c3d7a0(1,param_4);
  if (cVar2 != '\0') {
    FUN_008a4940(&DAT_02134d74);
  }
LAB_00c3bb52:
  FUN_00ca4830(0,param_5);
  FUN_008a4940(&DAT_02134e5c);
  FUN_00ca4830(1,param_6);
  FUN_008a4940(&DAT_02134e94);
  FUN_008a65e0(param_3,0);
  return;
}



/* FUNCTION 28061 ; VA 0x00c3bba0 ; FUN_00c3bba0 */

void FUN_00c3bba0(int param_1)

{
  FUN_00c3d9d0(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 0x1c),
               **(undefined **)(param_1 + 0x20));
  return;
}



/* FUNCTION 28062 ; VA 0x00c3bbc0 ; FUN_00c3bbc0 */

void FUN_00c3bbc0(undefined4 param_1,undefined4 param_2)

{
  FUN_00c3dc70(0,param_2);
  return;
}



/* FUNCTION 28063 ; VA 0x00c3bbe0 ; FUN_00c3bbe0 */

uint __fastcall FUN_00c3bbe0(int param_1)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  byte *pbVar4;
  byte *pbVar5;
  bool bVar6;
  
  pbVar4 = (byte *)(**(code **)(param_1 + 8))();
  pbVar5 = (byte *)(**(code **)(param_1 + 8))();
  puVar1 = (uint *)(pbVar4 + 0x10);
  if (0xf < *(uint *)(pbVar4 + 0x14)) {
    pbVar4 = *(byte **)pbVar4;
  }
  uVar2 = *(uint *)(pbVar5 + 0x10);
  if (0xf < *(uint *)(pbVar5 + 0x14)) {
    pbVar5 = *(byte **)pbVar5;
  }
  if (uVar2 != *puVar1) goto LAB_00c3bc78;
  while (uVar3 = uVar2 - 4, 3 < uVar2) {
    if (*(int *)pbVar5 != *(int *)pbVar4) goto LAB_00c3bc36;
    pbVar5 = pbVar5 + 4;
    pbVar4 = pbVar4 + 4;
    uVar2 = uVar3;
  }
  if (uVar3 == 0xfffffffc) {
LAB_00c3bc6a:
    pbVar5 = (byte *)0x0;
  }
  else {
LAB_00c3bc36:
    bVar6 = *pbVar5 < *pbVar4;
    if ((*pbVar5 == *pbVar4) &&
       ((uVar3 == 0xfffffffd ||
        ((bVar6 = pbVar5[1] < pbVar4[1], pbVar5[1] == pbVar4[1] &&
         ((uVar3 == 0xfffffffe ||
          ((bVar6 = pbVar5[2] < pbVar4[2], pbVar5[2] == pbVar4[2] &&
           ((uVar3 == 0xffffffff || (bVar6 = pbVar5[3] < pbVar4[3], pbVar5[3] == pbVar4[3]))))))))))
       )) goto LAB_00c3bc6a;
    pbVar5 = (byte *)(-(uint)bVar6 | 1);
  }
  if (pbVar5 == (byte *)0x0) {
    return 1;
  }
LAB_00c3bc78:
  return (uint)pbVar5 & 0xffffff00;
}



/* FUNCTION 28064 ; VA 0x00c3bc80 ; FUN_00c3bc80 */

undefined4 __fastcall FUN_00c3bc80(int param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = (**(code **)(param_1 + 8))();
  iVar3 = (**(code **)(param_1 + 8))();
  if ((NAN(*(float *)(iVar2 + 0x24)) || NAN(*(float *)(iVar3 + 0x24))) !=
      (*(float *)(iVar2 + 0x24) == *(float *)(iVar3 + 0x24))) {
    if ((NAN(*(float *)(iVar2 + 0x28)) || NAN(*(float *)(iVar3 + 0x28))) !=
        (*(float *)(iVar2 + 0x28) == *(float *)(iVar3 + 0x28))) {
      if ((NAN(*(float *)(iVar2 + 0x2c)) || NAN(*(float *)(iVar3 + 0x2c))) !=
          (*(float *)(iVar2 + 0x2c) == *(float *)(iVar3 + 0x2c))) {
        cVar1 = FUN_01160ab0(iVar3);
        if (cVar1 != '\0') {
          return 1;
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 28065 ; VA 0x00c3bcf0 ; FUN_00c3bcf0 */

void __fastcall FUN_00c3bcf0(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00c3bcf6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)**(undefined4 **)(param_1 + -0x24))();
  return;
}



/* FUNCTION 28066 ; VA 0x00c3bd10 ; FUN_00c3bd10 */

int __fastcall FUN_00c3bd10(int param_1)

{
  return *(int *)(param_1 + 0x90) + 0x40;
}



/* FUNCTION 28067 ; VA 0x00c3bd20 ; FUN_00c3bd20 */

int __fastcall FUN_00c3bd20(int param_1)

{
  return *(int *)(param_1 + 0x90) + 0x70;
}



/* FUNCTION 28068 ; VA 0x00c3bd30 ; FUN_00c3bd30 */

void FUN_00c3bd30(void)

{
  int iVar1;
  
  if (DAT_01efc374 == 0) {
    iVar1 = FUN_00c39010();
    DAT_01efc374 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28069 ; VA 0x00c3bd50 ; FUN_00c3bd50 */

void FUN_00c3bd50(void)

{
  int iVar1;
  
  if (DAT_01efc58c == 0) {
    iVar1 = FUN_00c391f0();
    DAT_01efc58c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28070 ; VA 0x00c3bd70 ; FUN_00c3bd70 */

void FUN_00c3bd70(void)

{
  int iVar1;
  
  if (DAT_01efbd1c == 0) {
    iVar1 = FUN_00c393d0();
    DAT_01efbd1c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28071 ; VA 0x00c3bd90 ; FUN_00c3bd90 */

void FUN_00c3bd90(void)

{
  int iVar1;
  
  if (DAT_01efac24 == 0) {
    iVar1 = FUN_00c390f0();
    DAT_01efac24 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28072 ; VA 0x00c3bdb0 ; FUN_00c3bdb0 */

void FUN_00c3bdb0(void)

{
  int iVar1;
  
  if (DAT_01efc15c == 0) {
    iVar1 = FUN_00c392d0();
    DAT_01efc15c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28073 ; VA 0x00c3bdd0 ; FUN_00c3bdd0 */

void FUN_00c3bdd0(void)

{
  int iVar1;
  
  if (DAT_01efbf3c == 0) {
    iVar1 = FUN_00c394b0();
    DAT_01efbf3c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28074 ; VA 0x00c3bdf0 ; FUN_00c3bdf0 */

void FUN_00c3bdf0(void)

{
  int iVar1;
  
  if (DAT_01efb064 == 0) {
    iVar1 = FUN_00c395b0();
    DAT_01efb064 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28075 ; VA 0x00c3be10 ; FUN_00c3be10 */

void FUN_00c3be10(void)

{
  int iVar1;
  
  if (DAT_01efae44 == 0) {
    iVar1 = FUN_00c396b0();
    DAT_01efae44 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28076 ; VA 0x00c3be30 ; FUN_00c3be30 */

void FUN_00c3be30(void)

{
  int iVar1;
  
  if (DAT_01efb284 == 0) {
    iVar1 = FUN_00c397b0();
    DAT_01efb284 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28077 ; VA 0x00c3be50 ; FUN_00c3be50 */

void FUN_00c3be50(void)

{
  int iVar1;
  
  if (DAT_01efb4a4 == 0) {
    iVar1 = FUN_00c398b0();
    DAT_01efb4a4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28078 ; VA 0x00c3be70 ; FUN_00c3be70 */

void FUN_00c3be70(void)

{
  int iVar1;
  
  if (DAT_01efb6c4 == 0) {
    iVar1 = FUN_00c399b0();
    DAT_01efb6c4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28079 ; VA 0x00c3be90 ; FUN_00c3be90 */

void FUN_00c3be90(void)

{
  int iVar1;
  
  if (DAT_01efb8e4 == 0) {
    iVar1 = FUN_00c39ab0();
    DAT_01efb8e4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28080 ; VA 0x00c3beb0 ; FUN_00c3beb0 */

void FUN_00c3beb0(void)

{
  int iVar1;
  
  if (DAT_01efbb04 == 0) {
    iVar1 = FUN_00c39bb0();
    DAT_01efbb04 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28081 ; VA 0x00c3bed0 ; FUN_00c3bed0 */

void FUN_00c3bed0(void)

{
  FUN_00c23310();
  return;
}



/* FUNCTION 28082 ; VA 0x00c3bee0 ; FUN_00c3bee0 */

float10 __fastcall FUN_00c3bee0(int param_1)

{
  return (float10)*(float *)(*(int *)(param_1 + 0x90) + 0xb4);
}



/* FUNCTION 28083 ; VA 0x00c3bef0 ; FUN_00c3bef0 */

float10 __fastcall FUN_00c3bef0(int param_1)

{
  return (float10)*(float *)(*(int *)(param_1 + 0x90) + 0xf0);
}



/* FUNCTION 28084 ; VA 0x00c3bf00 ; FUN_00c3bf00 */

float10 __fastcall FUN_00c3bf00(int param_1)

{
  return (float10)*(float *)(*(int *)(param_1 + 0x90) + 0xcc);
}



/* FUNCTION 28085 ; VA 0x00c3bfd0 ; FUN_00c3bfd0 */

float10 __fastcall FUN_00c3bfd0(int param_1)

{
  return (float10)*(float *)(*(int *)(param_1 + 0x90) + 0xec);
}



/* FUNCTION 28086 ; VA 0x00c3bfe0 ; FUN_00c3bfe0 */

float10 __fastcall FUN_00c3bfe0(int param_1)

{
  return (float10)*(float *)(*(int *)(param_1 + 0x90) + 200);
}



/* FUNCTION 28087 ; VA 0x00c3bff0 ; FUN_00c3bff0 */

undefined * __fastcall FUN_00c3bff0(int param_1)

{
  int iVar1;
  
  iVar1 = FUN_00c3a5c0(param_1 + -0x20);
  if (iVar1 != 0) {
    return *(undefined **)(iVar1 + 0x28);
  }
  return &DAT_01d6d81c;
}



/* FUNCTION 28088 ; VA 0x00c3c010 ; FUN_00c3c010 */

void __fastcall FUN_00c3c010(int param_1)

{
  FUN_00c3a5c0(param_1 + 0x74);
  return;
}



/* FUNCTION 28089 ; VA 0x00c3c020 ; FUN_00c3c020 */

void __fastcall FUN_00c3c020(int param_1)

{
  FUN_00c3a5c0(param_1 + 0x7c);
  return;
}



/* FUNCTION 28090 ; VA 0x00c3c030 ; FUN_00c3c030 */

undefined * __fastcall FUN_00c3c030(int param_1)

{
  int iVar1;
  
  iVar1 = FUN_00c3a5c0(param_1 + -0x18);
  if (iVar1 != 0) {
    return *(undefined **)(iVar1 + 0x28);
  }
  return &DAT_01d6d81c;
}



/* FUNCTION 28091 ; VA 0x00c3c050 ; FUN_00c3c050 */

int FUN_00c3c050(void)

{
  int iVar1;
  
  iVar1 = FUN_008a2610();
  return iVar1 + 4;
}



/* FUNCTION 28092 ; VA 0x00c3c060 ; FUN_00c3c060 */

undefined4 __fastcall FUN_00c3c060(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  if (*(int **)(param_1 + 0x90) == (int *)0x0) {
    iVar1 = 0x1c;
  }
  else {
    iVar1 = (**(code **)(**(int **)(param_1 + 0x90) + 0x10))();
  }
  if (DAT_01efa9e0 != '\0') {
    if (iVar1 == 0x1c) {
      return 0xffffffff;
    }
    return *(undefined4 *)(param_1 + 0x94);
  }
  uVar2 = 0xffffffff;
  if (iVar1 == 2) {
    return *(undefined4 *)(*(int *)(param_1 + 0x90) + 0xa8);
  }
  if (iVar1 == 0xb) {
    uVar2 = *(undefined4 *)(*(int *)(param_1 + 0x90) + 0xe4);
  }
  return uVar2;
}



/* FUNCTION 28093 ; VA 0x00c3c0d0 ; FUN_00c3c0d0 */

undefined4 __fastcall FUN_00c3c0d0(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  if (*(int **)(param_1 + 0x90) == (int *)0x0) {
    iVar1 = 0x1c;
  }
  else {
    iVar1 = (**(code **)(**(int **)(param_1 + 0x90) + 0x10))();
  }
  if (DAT_01efa9e0 != '\0') {
    if (iVar1 == 0x1c) {
      return 0xffffffff;
    }
    return *(undefined4 *)(param_1 + 0x98);
  }
  uVar2 = 0xffffffff;
  if (iVar1 == 2) {
    return *(undefined4 *)(*(int *)(param_1 + 0x90) + 0xac);
  }
  if (iVar1 == 0xb) {
    uVar2 = *(undefined4 *)(*(int *)(param_1 + 0x90) + 0xe8);
  }
  return uVar2;
}



/* FUNCTION 28094 ; VA 0x00c3c140 ; FUN_00c3c140 */

undefined4 FUN_00c3c140(undefined4 param_1)

{
  FUN_01063940(param_1);
  return param_1;
}



/* FUNCTION 28095 ; VA 0x00c3c160 ; FUN_00c3c160 */

undefined4 * __thiscall FUN_00c3c160(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  puVar4 = (undefined4 *)(**(code **)(param_1 + 8))();
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_2 = *puVar4;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  uVar1 = puVar4[5];
  uVar2 = puVar4[6];
  uVar3 = puVar4[7];
  param_2[4] = puVar4[4];
  param_2[5] = uVar1;
  param_2[6] = uVar2;
  param_2[7] = uVar3;
  uVar1 = puVar4[9];
  uVar2 = puVar4[10];
  uVar3 = puVar4[0xb];
  param_2[8] = puVar4[8];
  param_2[9] = uVar1;
  param_2[10] = uVar2;
  param_2[0xb] = uVar3;
  return param_2;
}



/* FUNCTION 28096 ; VA 0x00c3c190 ; FUN_00c3c190 */

uint __fastcall FUN_00c3c190(int param_1)

{
  uint uVar1;
  
  uVar1 = *(uint *)(param_1 + 0x90);
  if (*(int **)(uVar1 + 4) != (int *)0x0) {
    uVar1 = (**(code **)(**(int **)(uVar1 + 4) + 4))();
    if (uVar1 == 0xf) {
      return 1;
    }
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 28097 ; VA 0x00c3c1b0 ; FUN_00c3c1b0 */

void FUN_00c3c1b0(void)

{
  FUN_00ffd8c0();
  return;
}



/* FUNCTION 28098 ; VA 0x00c3c1c0 ; FUN_00c3c1c0 */

uint FUN_00c3c1c0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c390f0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28099 ; VA 0x00c3c1e0 ; FUN_00c3c1e0 */

uint FUN_00c3c1e0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c392d0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28100 ; VA 0x00c3c200 ; FUN_00c3c200 */

uint FUN_00c3c200(void)

{
  int iVar1;
  
  iVar1 = FUN_00c394b0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28101 ; VA 0x00c3c220 ; FUN_00c3c220 */

uint FUN_00c3c220(void)

{
  int iVar1;
  
  iVar1 = FUN_00c395b0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28102 ; VA 0x00c3c240 ; FUN_00c3c240 */

uint FUN_00c3c240(void)

{
  int iVar1;
  
  iVar1 = FUN_00c396b0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28103 ; VA 0x00c3c260 ; FUN_00c3c260 */

uint FUN_00c3c260(void)

{
  int iVar1;
  
  iVar1 = FUN_00c397b0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28104 ; VA 0x00c3c280 ; FUN_00c3c280 */

uint FUN_00c3c280(void)

{
  int iVar1;
  
  iVar1 = FUN_00c398b0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28105 ; VA 0x00c3c2a0 ; FUN_00c3c2a0 */

uint FUN_00c3c2a0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c399b0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28106 ; VA 0x00c3c2c0 ; FUN_00c3c2c0 */

uint FUN_00c3c2c0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c39ab0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28107 ; VA 0x00c3c2e0 ; FUN_00c3c2e0 */

uint FUN_00c3c2e0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c39bb0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 28108 ; VA 0x00c3c300 ; FUN_00c3c300 */

bool __thiscall FUN_00c3c300(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  bool bVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  piVar3 = (int *)FUN_0060dcd0(auStack_c,param_2);
  piVar1 = (int *)(*(int **)(param_1 + 0x58))[1];
  piVar4 = (int *)**(int **)(param_1 + 0x58);
  bVar5 = piVar4 == piVar1;
  if (!bVar5) {
    do {
      if (*piVar4 == *piVar3) break;
      piVar4 = piVar4 + 2;
    } while (piVar4 != piVar1);
    bVar5 = piVar4 == piVar1;
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_8[1] + -1;
    piStack_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return !bVar5;
  }
  return !bVar5;
}



/* FUNCTION 28109 ; VA 0x00c3c380 ; FUN_00c3c380 */

uint FUN_00c3c380(void)

{
  int iVar1;
  
  iVar1 = FUN_00c390f0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28110 ; VA 0x00c3c3a0 ; FUN_00c3c3a0 */

uint FUN_00c3c3a0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c392d0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28111 ; VA 0x00c3c3c0 ; FUN_00c3c3c0 */

uint FUN_00c3c3c0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c394b0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28112 ; VA 0x00c3c3e0 ; FUN_00c3c3e0 */

uint FUN_00c3c3e0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c395b0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28113 ; VA 0x00c3c400 ; FUN_00c3c400 */

uint FUN_00c3c400(void)

{
  int iVar1;
  
  iVar1 = FUN_00c396b0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28114 ; VA 0x00c3c420 ; FUN_00c3c420 */

uint FUN_00c3c420(void)

{
  int iVar1;
  
  iVar1 = FUN_00c397b0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28115 ; VA 0x00c3c440 ; FUN_00c3c440 */

uint FUN_00c3c440(void)

{
  int iVar1;
  
  iVar1 = FUN_00c398b0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28116 ; VA 0x00c3c460 ; FUN_00c3c460 */

uint FUN_00c3c460(void)

{
  int iVar1;
  
  iVar1 = FUN_00c399b0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28117 ; VA 0x00c3c480 ; FUN_00c3c480 */

uint FUN_00c3c480(void)

{
  int iVar1;
  
  iVar1 = FUN_00c39ab0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28118 ; VA 0x00c3c4a0 ; FUN_00c3c4a0 */

uint FUN_00c3c4a0(void)

{
  int iVar1;
  
  iVar1 = FUN_00c39bb0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 28119 ; VA 0x00c3c4c0 ; FUN_00c3c4c0 */

void FUN_00c3c4c0(undefined4 param_1)

{
  FUN_008a3ee0(param_1);
  FUN_00c3dc70(0,0);
  return;
}



/* FUNCTION 28120 ; VA 0x00c3c4e0 ; FUN_00c3c4e0 */

void __fastcall FUN_00c3c4e0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x90);
  *(undefined4 *)(iVar1 + 0xa0) = *(undefined4 *)(param_1 + 0x18);
  *(undefined4 *)(iVar1 + 0xa4) = *(undefined4 *)(param_1 + 0x1c);
  return;
}



/* FUNCTION 28121 ; VA 0x00c3c500 ; FUN_00c3c500 */

void __thiscall FUN_00c3c500(int param_1,undefined4 param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined8 *puVar5;
  undefined auStack_68 [48];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 uStack_14;
  undefined8 uStack_10;
  undefined4 uStack_8;
  
  if ((DAT_01d6f4b8 == '\0') && (DAT_01eecc60 != '\0')) {
    piVar1 = *(int **)(param_1 + 0x3c);
    iVar3 = (**(code **)(*piVar1 + 0x10))();
    if ((((0xd < iVar3 - 0xcU) || ((*(byte *)(piVar1 + 0x2b) & 2) != 0)) &&
        ((((iVar3 = (**(code **)(*piVar1 + 0x10))(), iVar3 - 1U < 6 ||
           (iVar3 = (**(code **)(*piVar1 + 0x10))(), iVar3 - 7U < 0x13)) ||
          (iVar3 = (**(code **)(*piVar1 + 0x10))(), iVar3 == 0x1a)) || (iVar3 == 0)))) &&
       ((cVar2 = FUN_00ffd8c0(), cVar2 != '\0' ||
        (iVar3 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x10))(), iVar3 - 7U < 0x13)))) {
      iVar3 = FUN_00c3a5c0(param_1 + 0x20);
      if (iVar3 == 0) {
        iVar3 = 0;
      }
      else {
        iVar3 = FUN_00c3a5c0(param_1 + 0x20);
        iVar3 = *(int *)(iVar3 + 0xa8);
      }
      iVar4 = FUN_00c3a5c0(param_1 + 0x28);
      if (iVar4 == 0) {
        iVar4 = 0;
      }
      else {
        iVar4 = FUN_00c3a5c0(param_1 + 0x28);
        iVar4 = *(int *)(iVar4 + 0xa8);
      }
      if (iVar3 == 0) {
        uStack_10 = 0;
        uStack_8 = 0;
      }
      else {
        iVar3 = FUN_00c157b0();
        uStack_10 = *(undefined8 *)(iVar3 + 0x24);
        uStack_8 = *(undefined4 *)(iVar3 + 0x2c);
      }
      uStack_28 = uStack_10;
      uStack_20 = uStack_8;
      if (iVar4 == 0) {
        uStack_10 = 0;
        uStack_8 = 0;
      }
      else {
        iVar3 = FUN_00c157b0();
        uStack_10 = *(undefined8 *)(iVar3 + 0x24);
        uStack_8 = *(undefined4 *)(iVar3 + 0x2c);
      }
      uStack_1c = uStack_10;
      uStack_14 = uStack_8;
      iVar3 = (**(code **)(**(int **)(param_1 + 0x3c) + 0x10))();
      if (iVar3 - 7U < 0x13) {
        cVar2 = FUN_00ffd8c0();
        if (cVar2 == '\0') {
          puVar5 = (undefined8 *)FUN_0115e920();
        }
        else {
          puVar5 = (undefined8 *)FUN_0115eb50();
        }
      }
      else {
        puVar5 = (undefined8 *)FUN_0115e940();
      }
      uStack_10 = *puVar5;
      uStack_8 = *(undefined4 *)(puVar5 + 1);
      FUN_0060efa0();
      uStack_38 = (undefined4)uStack_10;
      uStack_34 = uStack_10._4_4_;
      uStack_30 = uStack_8;
      uStack_2c = 0x3f800000;
      FUN_0114bfd0(param_2,auStack_68,&uStack_28,&uStack_1c,&uStack_38,0x3da3d70a);
    }
  }
  return;
}



/* FUNCTION 28122 ; VA 0x00c3c700 ; FUN_00c3c700 */

void __thiscall FUN_00c3c700(int param_1,undefined4 param_2)

{
  float fVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  float *pfVar6;
  float *pfVar7;
  undefined4 *puVar8;
  int iVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined auStack_70 [12];
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  int iStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  int iStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  int iStack_1c;
  float fStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809468;
  pvStack_10 = ExceptionList;
  if (DAT_01efa9e0 == '\0') {
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_00c3c500(param_2);
  iVar3 = FUN_00c3a5c0(param_1 + 0x20);
  if (iVar3 == 0) {
    iVar3 = 0;
  }
  else {
    iVar3 = FUN_00c3a5c0(param_1 + 0x20);
    iVar3 = *(int *)(iVar3 + 0xa8);
  }
  iVar4 = FUN_00c3a5c0(param_1 + 0x28);
  if (iVar4 == 0) {
    fStack_18 = 0.0;
  }
  else {
    iVar4 = FUN_00c3a5c0(param_1 + 0x28);
    fStack_18 = *(float *)(iVar4 + 0xa8);
  }
  if (iVar3 == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  if (fStack_18 == 0.0) {
    ExceptionList = pvStack_10;
    return;
  }
  iStack_4c = FUN_005c3ac0(param_1 + -0x54);
  if (iStack_4c == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_8 = 0;
  iVar4 = FUN_008aeed0();
  if (iVar4 != 0) {
    FUN_008aeed0();
    uVar5 = FUN_00c3a5c0(param_1 + 0x20);
    cVar2 = FUN_00c3c300(uVar5);
    if (cVar2 == '\0') {
      FUN_008aeed0();
      uVar5 = FUN_00c3a5c0(param_1 + 0x28);
      cVar2 = FUN_00c3c300(uVar5);
      if (cVar2 == '\0') {
        FUN_008aeed0();
        cVar2 = FUN_00c3c300(param_1 + -0x54);
        if (cVar2 == '\0') goto LAB_00c3caa4;
      }
    }
    fVar1 = fStack_18;
    iStack_40 = *(int *)(*(int *)(param_1 + 0x3c) + 0xe4);
    iStack_1c = *(int *)(*(int *)(param_1 + 0x3c) + 0xe8);
    if ((iStack_40 != -1) && (iStack_1c != -1)) {
      uStack_58 = 0;
      uStack_54 = 0;
      uStack_50 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      iStack_14 = 0;
      iVar4 = (**(code **)(**(int **)((int)fStack_18 + 0x1ac) + 0x38))(iStack_1c);
      if (0 < iVar4) {
        do {
          pfVar6 = (float *)FUN_00c157b0();
          pfVar7 = (float *)(**(code **)(**(int **)((int)fVar1 + 0x1ac) + 0x34))
                                      (&uStack_7c,iStack_1c,iStack_14);
          fStack_24 = pfVar7[1];
          fStack_18 = *pfVar7;
          fStack_2c = pfVar7[2];
          fStack_3c = pfVar6[6] * fStack_18 + pfVar6[7] * fStack_24 + pfVar6[8] * fStack_2c +
                      pfVar6[0xb];
          fStack_28 = pfVar6[1];
          fStack_20 = *pfVar6;
          fStack_30 = pfVar6[2];
          fStack_38 = pfVar6[3] * fStack_18 + pfVar6[4] * fStack_24 + pfVar6[5] * fStack_2c +
                      pfVar6[10];
          fStack_34 = pfVar6[9];
          pfVar6 = (float *)FUN_00c157b0();
          fVar10 = fStack_38 - pfVar6[10];
          fVar11 = fStack_3c - pfVar6[0xb];
          fVar12 = (fStack_18 * fStack_20 + fStack_24 * fStack_28 + fStack_2c * fStack_30 +
                   fStack_34) - pfVar6[9];
          fStack_5c = pfVar6[2] * fVar12 + pfVar6[5] * fVar10 + pfVar6[8] * fVar11;
          fStack_60 = pfVar6[1] * fVar12 + pfVar6[4] * fVar10 + pfVar6[7] * fVar11;
          fStack_64 = pfVar6[3] * fVar10 + *pfVar6 * fVar12 + pfVar6[6] * fVar11;
          FUN_008037c0(&fStack_64);
          iVar9 = iStack_14 + 1;
          iStack_14 = iVar9;
          iVar4 = (**(code **)(**(int **)((int)fVar1 + 0x1ac) + 0x38))(iStack_1c);
        } while (iVar9 < iVar4);
      }
      (**(code **)(**(int **)(iVar3 + 0x1ac) + 0x70))(auStack_70,&uStack_58,iStack_40);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      puVar8 = (undefined4 *)FUN_0115e930();
      uStack_80 = *puVar8;
      uStack_7c = puVar8[1];
      uStack_78 = puVar8[2];
      uStack_74 = 0x3f800000;
      uVar5 = FUN_00c157b0(auStack_70,&uStack_80,0x3dcccccd);
      FUN_0114c7a0(param_2,uVar5);
      FUN_00617ad0();
      FUN_00617ad0();
    }
  }
LAB_00c3caa4:
  FUN_00612e60();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28123 ; VA 0x00c3cac0 ; FUN_00c3cac0 */

void FUN_00c3cac0(void)

{
  FUN_00c3c500();
  return;
}



/* FUNCTION 28124 ; VA 0x00c3cad0 ; FUN_00c3cad0 */

void __thiscall FUN_00c3cad0(int param_1,undefined4 param_2)

{
  float fVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  float *pfVar6;
  float *pfVar7;
  undefined4 *puVar8;
  int iVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined auStack_70 [12];
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  int iStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  int iStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  int iStack_1c;
  float fStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809468;
  pvStack_10 = ExceptionList;
  if (DAT_01efa9e0 != '\0') {
    return;
  }
  ExceptionList = &pvStack_10;
  FUN_00c3c500(param_2);
  iVar3 = FUN_00c3a5c0(param_1 + 0x20);
  if (iVar3 == 0) {
    iVar3 = 0;
  }
  else {
    iVar3 = FUN_00c3a5c0(param_1 + 0x20);
    iVar3 = *(int *)(iVar3 + 0xa8);
  }
  iVar4 = FUN_00c3a5c0(param_1 + 0x28);
  if (iVar4 == 0) {
    fStack_18 = 0.0;
  }
  else {
    iVar4 = FUN_00c3a5c0(param_1 + 0x28);
    fStack_18 = *(float *)(iVar4 + 0xa8);
  }
  if (iVar3 == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  if (fStack_18 == 0.0) {
    ExceptionList = pvStack_10;
    return;
  }
  iStack_4c = FUN_005c3ac0(param_1 + -0x54);
  if (iStack_4c == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_8 = 0;
  iVar4 = FUN_008aeed0();
  if (iVar4 != 0) {
    FUN_008aeed0();
    uVar5 = FUN_00c3a5c0(param_1 + 0x20);
    cVar2 = FUN_00c3c300(uVar5);
    if (cVar2 == '\0') {
      FUN_008aeed0();
      uVar5 = FUN_00c3a5c0(param_1 + 0x28);
      cVar2 = FUN_00c3c300(uVar5);
      if (cVar2 == '\0') {
        FUN_008aeed0();
        cVar2 = FUN_00c3c300(param_1 + -0x54);
        if (cVar2 == '\0') goto LAB_00c3ce74;
      }
    }
    fVar1 = fStack_18;
    iStack_40 = *(int *)(*(int *)(param_1 + 0x3c) + 0xa8);
    iStack_1c = *(int *)(*(int *)(param_1 + 0x3c) + 0xac);
    if ((iStack_40 != -1) && (iStack_1c != -1)) {
      uStack_58 = 0;
      uStack_54 = 0;
      uStack_50 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      iStack_14 = 0;
      iVar4 = (**(code **)(**(int **)((int)fStack_18 + 0x1ac) + 0x38))(iStack_1c);
      if (0 < iVar4) {
        do {
          pfVar6 = (float *)FUN_00c157b0();
          pfVar7 = (float *)(**(code **)(**(int **)((int)fVar1 + 0x1ac) + 0x34))
                                      (&uStack_7c,iStack_1c,iStack_14);
          fStack_24 = pfVar7[1];
          fStack_18 = *pfVar7;
          fStack_2c = pfVar7[2];
          fStack_3c = pfVar6[6] * fStack_18 + pfVar6[7] * fStack_24 + pfVar6[8] * fStack_2c +
                      pfVar6[0xb];
          fStack_28 = pfVar6[1];
          fStack_20 = *pfVar6;
          fStack_30 = pfVar6[2];
          fStack_38 = pfVar6[3] * fStack_18 + pfVar6[4] * fStack_24 + pfVar6[5] * fStack_2c +
                      pfVar6[10];
          fStack_34 = pfVar6[9];
          pfVar6 = (float *)FUN_00c157b0();
          fVar10 = fStack_38 - pfVar6[10];
          fVar11 = fStack_3c - pfVar6[0xb];
          fVar12 = (fStack_18 * fStack_20 + fStack_24 * fStack_28 + fStack_2c * fStack_30 +
                   fStack_34) - pfVar6[9];
          fStack_5c = pfVar6[2] * fVar12 + pfVar6[5] * fVar10 + pfVar6[8] * fVar11;
          fStack_60 = pfVar6[1] * fVar12 + pfVar6[4] * fVar10 + pfVar6[7] * fVar11;
          fStack_64 = pfVar6[3] * fVar10 + *pfVar6 * fVar12 + pfVar6[6] * fVar11;
          FUN_008037c0(&fStack_64);
          iVar9 = iStack_14 + 1;
          iStack_14 = iVar9;
          iVar4 = (**(code **)(**(int **)((int)fVar1 + 0x1ac) + 0x38))(iStack_1c);
        } while (iVar9 < iVar4);
      }
      (**(code **)(**(int **)(iVar3 + 0x1ac) + 0x70))(auStack_70,&uStack_58,iStack_40);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      puVar8 = (undefined4 *)FUN_0115ee70();
      uStack_80 = *puVar8;
      uStack_7c = puVar8[1];
      uStack_78 = puVar8[2];
      uStack_74 = 0x3f800000;
      uVar5 = FUN_00c157b0(auStack_70,&uStack_80,0x3dcccccd);
      FUN_0114c7a0(param_2,uVar5);
      FUN_00617ad0();
      FUN_00617ad0();
    }
  }
LAB_00c3ce74:
  FUN_00612e60();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28125 ; VA 0x00c3ce90 ; FUN_00c3ce90 */

void FUN_00c3ce90(undefined4 param_1)

{
  FUN_01081480(param_1);
  return;
}



/* FUNCTION 28126 ; VA 0x00c3ceb0 ; FUN_00c3ceb0 */

void FUN_00c3ceb0(undefined4 param_1)

{
  FUN_00ca4830(0,param_1);
  FUN_008a4940(&DAT_02134e5c);
  return;
}



/* FUNCTION 28127 ; VA 0x00c3cee0 ; FUN_00c3cee0 */

void FUN_00c3cee0(undefined4 param_1)

{
  FUN_00ca4830(1,param_1);
  FUN_008a4940(&DAT_02134e94);
  return;
}



/* FUNCTION 28128 ; VA 0x00c3cf10 ; FUN_00c3cf10 */

void FUN_00c3cf10(float param_1)

{
  float10 fVar1;
  
  fVar1 = (float10)FUN_00c23310();
  if ((NAN(param_1) || NAN((float)fVar1)) == (param_1 == (float)fVar1)) {
    FUN_01063fa0(param_1);
    FUN_008a4940(&DAT_021350a0);
  }
  return;
}



/* FUNCTION 28129 ; VA 0x00c3cf60 ; FUN_00c3cf60 */

void __thiscall FUN_00c3cf60(int param_1,float param_2)

{
  float *pfVar1;
  
  pfVar1 = (float *)(*(int *)(param_1 + 0x90) + 0xb4);
  if ((NAN(param_2) || NAN(*pfVar1)) == (param_2 == *pfVar1)) {
    FUN_01064c60(param_2);
    FUN_008a4940(&DAT_021350a0);
  }
  return;
}



/* FUNCTION 28130 ; VA 0x00c3cfa0 ; FUN_00c3cfa0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00c3cfa0(int param_1,float param_2)

{
  float fVar1;
  int iVar2;
  
  iVar2 = *(int *)(param_1 + 0x90);
  fVar1 = *(float *)(iVar2 + 0xf0);
  if (DAT_01d68648 == '\0') {
    if ((NAN(param_2) || NAN(fVar1)) != (param_2 == fVar1)) {
      return;
    }
    if ((float)(double)CONCAT44((uint)((ulonglong)(double)(param_2 - fVar1) >> 0x20) &
                                DAT_018c0da0._4_4_,
                                SUB84((double)(param_2 - fVar1),0) & (uint)DAT_018c0da0) <=
        ((float)(double)CONCAT44((uint)((ulonglong)(double)param_2 >> 0x20) & DAT_018c0da0._4_4_,
                                 SUB84((double)param_2,0) & (uint)DAT_018c0da0) + DAT_018ce2f8) *
        _DAT_01969954) {
      return;
    }
    *(float *)(iVar2 + 0xf0) = param_2;
  }
  else {
    if ((NAN(param_2) || NAN(fVar1)) != (param_2 == fVar1)) {
      return;
    }
    if ((double)(float)(double)CONCAT44((uint)((ulonglong)(double)(param_2 - fVar1) >> 0x20) &
                                        DAT_018c0da0._4_4_,
                                        SUB84((double)(param_2 - fVar1),0) & (uint)DAT_018c0da0) <=
        (double)DAT_01d68634 * DAT_01969958) {
      return;
    }
    *(float *)(iVar2 + 0xf0) = param_2;
  }
  FUN_008a4940(&DAT_0213501c);
  FUN_008a4940(&DAT_021350a0);
  return;
}



/* FUNCTION 28131 ; VA 0x00c3d080 ; FUN_00c3d080 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00c3d080(int param_1,float param_2)

{
  float fVar1;
  
  fVar1 = *(float *)(*(int *)(param_1 + 0x90) + 0xcc);
  if (((NAN(param_2) || NAN(fVar1)) == (param_2 == fVar1)) &&
     (((float)(double)CONCAT44((uint)((ulonglong)(double)param_2 >> 0x20) & DAT_018c0da0._4_4_,
                               SUB84((double)param_2,0) & (uint)DAT_018c0da0) + DAT_018ce2f8) *
      _DAT_01969954 <
      (float)(double)CONCAT44((uint)((ulonglong)(double)(param_2 - fVar1) >> 0x20) &
                              DAT_018c0da0._4_4_,
                              SUB84((double)(param_2 - fVar1),0) & (uint)DAT_018c0da0))) {
    *(float *)(*(int *)(param_1 + 0x90) + 0xcc) = param_2;
    FUN_008a4940(&DAT_0213501c);
    FUN_008a4940(&DAT_021350a0);
  }
  return;
}



/* FUNCTION 28132 ; VA 0x00c3d100 ; FUN_00c3d100 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00c3d100(int param_1,float param_2)

{
  float fVar1;
  int iVar2;
  
  iVar2 = *(int *)(param_1 + 0x90);
  fVar1 = *(float *)(iVar2 + 0xf0);
  if (DAT_01d68648 == '\0') {
    if (((NAN(param_2) || NAN(fVar1)) == (param_2 == fVar1)) &&
       (((float)(double)CONCAT44((uint)((ulonglong)(double)param_2 >> 0x20) & DAT_018c0da0._4_4_,
                                 SUB84((double)param_2,0) & (uint)DAT_018c0da0) + DAT_018ce2f8) *
        _DAT_01969954 <
        (float)(double)CONCAT44((uint)((ulonglong)(double)(param_2 - fVar1) >> 0x20) &
                                DAT_018c0da0._4_4_,
                                SUB84((double)(param_2 - fVar1),0) & (uint)DAT_018c0da0))) {
      *(float *)(iVar2 + 0xf0) = param_2;
      FUN_008a4940();
      return;
    }
  }
  else if (((NAN(param_2) || NAN(fVar1)) == (param_2 == fVar1)) &&
          ((double)DAT_01d68634 * DAT_01969958 <
           (double)(float)(double)CONCAT44((uint)((ulonglong)(double)(param_2 - fVar1) >> 0x20) &
                                           DAT_018c0da0._4_4_,
                                           SUB84((double)(param_2 - fVar1),0) & (uint)DAT_018c0da0))
          ) {
    *(float *)(iVar2 + 0xf0) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 28133 ; VA 0x00c3d1e0 ; FUN_00c3d1e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00c3d1e0(int param_1,float param_2)

{
  float fVar1;
  
  fVar1 = *(float *)(*(int *)(param_1 + 0x90) + 0xcc);
  if (((NAN(param_2) || NAN(fVar1)) == (param_2 == fVar1)) &&
     (((float)(double)CONCAT44((uint)((ulonglong)(double)param_2 >> 0x20) & DAT_018c0da0._4_4_,
                               SUB84((double)param_2,0) & (uint)DAT_018c0da0) + DAT_018ce2f8) *
      _DAT_01969954 <
      (float)(double)CONCAT44((uint)((ulonglong)(double)(param_2 - fVar1) >> 0x20) &
                              DAT_018c0da0._4_4_,
                              SUB84((double)(param_2 - fVar1),0) & (uint)DAT_018c0da0))) {
    *(float *)(*(int *)(param_1 + 0x90) + 0xcc) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 28134 ; VA 0x00c3d250 ; FUN_00c3d250 */

void __thiscall FUN_00c3d250(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0x8c)) {
    *(char *)(param_1 + 0x8c) = param_2;
    FUN_00c3dc70(0,0);
    FUN_008a4940(&DAT_02134d00);
  }
  return;
}



/* FUNCTION 28135 ; VA 0x00c3d490 ; FUN_00c3d490 */

void __fastcall FUN_00c3d490(int param_1)

{
  undefined8 uVar1;
  undefined4 uVar2;
  undefined8 *puVar3;
  
  puVar3 = (undefined8 *)FUN_01077530(0);
  uVar1 = *puVar3;
  if (DAT_01efa9e0 == '\0') {
    uVar2 = *(undefined4 *)(puVar3 + 1);
    puVar3 = (undefined8 *)FUN_01077530(0);
    *puVar3 = uVar1;
    *(undefined4 *)(puVar3 + 1) = uVar2;
  }
  else {
    *(undefined8 *)(param_1 + 0x94) = uVar1;
    *(undefined4 *)(param_1 + 0x9c) = *(undefined4 *)(puVar3 + 1);
  }
  FUN_008a4940(&DAT_02134ecc);
  puVar3 = (undefined8 *)FUN_01077530(1);
  uVar1 = *puVar3;
  if (DAT_01efa9e0 == '\0') {
    uVar2 = *(undefined4 *)(puVar3 + 1);
    puVar3 = (undefined8 *)FUN_01077530(1);
    *puVar3 = uVar1;
    *(undefined4 *)(puVar3 + 1) = uVar2;
  }
  else {
    *(undefined8 *)(param_1 + 0xa0) = uVar1;
    *(undefined4 *)(param_1 + 0xa8) = *(undefined4 *)(puVar3 + 1);
  }
  FUN_008a4940(&DAT_02134f04);
  puVar3 = (undefined8 *)FUN_01077530(2);
  uVar1 = *puVar3;
  if (DAT_01efa9e0 == '\0') {
    uVar2 = *(undefined4 *)(puVar3 + 1);
    puVar3 = (undefined8 *)FUN_01077530(2);
    *puVar3 = uVar1;
    *(undefined4 *)(puVar3 + 1) = uVar2;
  }
  else {
    *(undefined8 *)(param_1 + 0xac) = uVar1;
    *(undefined4 *)(param_1 + 0xb4) = *(undefined4 *)(puVar3 + 1);
  }
  FUN_008a4940(&DAT_02134f3c);
  puVar3 = (undefined8 *)FUN_01077530(3);
  uVar1 = *puVar3;
  if (DAT_01efa9e0 == '\0') {
    uVar2 = *(undefined4 *)(puVar3 + 1);
    puVar3 = (undefined8 *)FUN_01077530(3);
    *puVar3 = uVar1;
    *(undefined4 *)(puVar3 + 1) = uVar2;
  }
  else {
    *(undefined8 *)(param_1 + 0xb8) = uVar1;
    *(undefined4 *)(param_1 + 0xc0) = *(undefined4 *)(puVar3 + 1);
  }
  FUN_008a4940(&DAT_02134f74);
  return;
}



/* FUNCTION 28136 ; VA 0x00c3d630 ; FUN_00c3d630 */

void __thiscall FUN_00c3d630(int param_1,undefined param_2)

{
  int iVar1;
  
  *(undefined *)(param_1 + 4) = param_2;
  iVar1 = FUN_00c3a5c0(param_1 + -0x18);
  if (iVar1 != 0) {
    iVar1 = FUN_00c155c0();
    if (iVar1 != 0) {
      *(undefined *)(iVar1 + 0x35) = param_2;
    }
  }
  return;
}



/* FUNCTION 28137 ; VA 0x00c3d670 ; FUN_00c3d670 */

void __thiscall FUN_00c3d670(int param_1,float param_2)

{
  float *pfVar1;
  
  pfVar1 = (float *)(*(int *)(param_1 + 0x90) + 0xec);
  if ((NAN(param_2) || NAN(*pfVar1)) == (param_2 == *pfVar1)) {
    *(float *)(*(int *)(param_1 + 0x90) + 0xec) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 28138 ; VA 0x00c3d6b0 ; FUN_00c3d6b0 */

void __thiscall FUN_00c3d6b0(int param_1,float param_2)

{
  float *pfVar1;
  
  pfVar1 = (float *)(*(int *)(param_1 + 0x90) + 200);
  if ((NAN(param_2) || NAN(*pfVar1)) == (param_2 == *pfVar1)) {
    *(float *)(*(int *)(param_1 + 0x90) + 200) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 28139 ; VA 0x00c3d6f0 ; FUN_00c3d6f0 */

void __thiscall FUN_00c3d6f0(undefined4 param_1,undefined4 param_2)

{
  if (DAT_01ee41fc != '\0') {
    FUN_016774b0(DAT_01ee41fc,"JointInstance %p named",param_1);
    if (DAT_01ee41fc != '\0') {
      FUN_01677760(DAT_01ee41fc,"Name: %s",param_2);
    }
  }
  FUN_008a6520(param_2);
  return;
}



/* FUNCTION 28140 ; VA 0x00c3d740 ; FUN_00c3d740 */

void FUN_00c3d740(undefined4 param_1)

{
  char cVar1;
  
  cVar1 = FUN_00c3d7a0(0,param_1);
  if (cVar1 != '\0') {
    FUN_008a4940(&DAT_02134d38);
  }
  return;
}



/* FUNCTION 28141 ; VA 0x00c3d770 ; FUN_00c3d770 */

void FUN_00c3d770(undefined4 param_1)

{
  char cVar1;
  
  cVar1 = FUN_00c3d7a0(1,param_1);
  if (cVar1 != '\0') {
    FUN_008a4940(&DAT_02134d74);
  }
  return;
}



/* FUNCTION 28142 ; VA 0x00c3d7a0 ; FUN_00c3d7a0 */

undefined4 __thiscall FUN_00c3d7a0(int param_1,int param_2,int param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar6 = (undefined4 *)(param_2 * 8 + 0x74 + param_1);
  iVar4 = FUN_00c3a5c0(puVar6);
  if (iVar4 != param_3) {
    FUN_01679490();
    puVar5 = (undefined4 *)FUN_0060e0c0(auStack_c,param_3);
    uVar1 = *puVar5;
    uVar2 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    *puVar6 = uVar1;
    piVar3 = (int *)puVar6[1];
    puVar6[1] = uVar2;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      piVar3 = piStack_8 + 2;
      iVar4 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    FUN_00c3dc70(1,0);
    return 1;
  }
  return 0;
}



/* FUNCTION 28143 ; VA 0x00c3d850 ; FUN_00c3d850 */

void __thiscall FUN_00c3d850(int param_1,int param_2)

{
  int iVar1;
  
  if (*(int **)(param_1 + 0x90) == (int *)0x0) {
    iVar1 = 0x1c;
  }
  else {
    iVar1 = (**(code **)(**(int **)(param_1 + 0x90) + 0x10))();
  }
  if (DAT_01efa9e0 == '\0') {
    if (iVar1 == 2) {
      if (param_2 != *(int *)(*(int *)(param_1 + 0x90) + 0xa8)) {
        *(int *)(*(int *)(param_1 + 0x90) + 0xa8) = param_2;
        FUN_008a4940(&DAT_02134dec);
        return;
      }
    }
    else if (iVar1 == 0xb) {
      if (param_2 != *(int *)(*(int *)(param_1 + 0x90) + 0xe4)) {
        *(int *)(*(int *)(param_1 + 0x90) + 0xe4) = param_2;
        FUN_008a4940(&DAT_02134dec);
      }
    }
  }
  else if (iVar1 != 0x1c) {
    *(int *)(param_1 + 0x94) = param_2;
    return;
  }
  return;
}



/* FUNCTION 28144 ; VA 0x00c3d8f0 ; FUN_00c3d8f0 */

void __thiscall FUN_00c3d8f0(int param_1,int param_2)

{
  int iVar1;
  
  if (*(int **)(param_1 + 0x90) == (int *)0x0) {
    iVar1 = 0x1c;
  }
  else {
    iVar1 = (**(code **)(**(int **)(param_1 + 0x90) + 0x10))();
  }
  if (DAT_01efa9e0 == '\0') {
    if (iVar1 == 2) {
      if (param_2 != *(int *)(*(int *)(param_1 + 0x90) + 0xac)) {
        *(int *)(*(int *)(param_1 + 0x90) + 0xac) = param_2;
        FUN_008a4940(&DAT_02134e24);
        return;
      }
    }
    else if (iVar1 == 0xb) {
      if (param_2 != *(int *)(*(int *)(param_1 + 0x90) + 0xe8)) {
        *(int *)(*(int *)(param_1 + 0x90) + 0xe8) = param_2;
        FUN_008a4940(&DAT_02134e24);
      }
    }
  }
  else if (iVar1 != 0x1c) {
    *(int *)(param_1 + 0x98) = param_2;
    return;
  }
  return;
}



/* FUNCTION 28145 ; VA 0x00c3d990 ; FUN_00c3d990 */

void __thiscall FUN_00c3d990(int param_1,undefined4 param_2)

{
  FUN_01064040(param_2);
                    /* WARNING: Could not recover jumptable at 0x00c3d9b9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(int *)(param_1 + 0x94) + 0x10))();
  return;
}



/* FUNCTION 28146 ; VA 0x00c3d9c0 ; FUN_00c3d9c0 */

undefined FUN_00c3d9c0(void)

{
  return DAT_01eecc60;
}



/* FUNCTION 28147 ; VA 0x00c3d9d0 ; FUN_00c3d9d0 */

void FUN_00c3d9d0(int param_1,int param_2,char param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  
  if (*(int **)(param_1 + 4) == (int *)0x0) {
    iVar1 = 0;
  }
  else {
    iVar7 = (**(code **)(**(int **)(param_1 + 4) + 4))();
    iVar1 = *(int *)(param_1 + 4);
    if (iVar7 == 0xf) {
      iVar1 = *(int *)(iVar1 + 4);
    }
    iVar1 = *(int *)(iVar1 + 0xc);
  }
  if (param_2 != 0) {
    iVar7 = *(int *)(param_1 + 0x2c);
    iVar6 = *(int *)(param_1 + 0x30);
    uVar2 = FUN_00b06640(iVar7);
    uVar3 = FUN_00b06640(*(undefined4 *)(param_1 + 0x30));
    iVar4 = FUN_00a9d3f0(uVar2);
    if (param_3 == '\0') {
      iVar5 = 0;
    }
    else {
      iVar5 = FUN_00a9d3f0(uVar3);
    }
    if (iVar7 == 0) {
      iVar7 = 0;
    }
    else {
      iVar7 = *(int *)(iVar7 + 0x1a8);
    }
    if ((param_3 == '\0') || (iVar6 == 0)) {
      iVar6 = 0;
    }
    else {
      iVar6 = *(int *)(iVar6 + 0x1a8);
    }
    if (((iVar4 != param_2) || (iVar7 != param_2)) ||
       ((param_3 != '\0' && ((iVar5 != param_2 || (iVar6 != param_2)))))) {
      param_2 = 0;
    }
  }
  if (param_2 != iVar1) {
    if (iVar1 != 0) {
      FUN_00bc0420(param_1);
    }
    if (param_2 != 0) {
      FUN_00bbe190(param_1);
    }
  }
  return;
}



/* FUNCTION 28148 ; VA 0x00c3dac0 ; FUN_00c3dac0 */

void __thiscall FUN_00c3dac0(char *param_1,int param_2,int param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char cVar4;
  int iStack_1c;
  int iStack_18;
  char *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar3 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809490;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00c3d9d0(param_2,param_3,*param_1);
  param_3 = *(int *)(param_1 + 4);
  if ((((char)param_4 == '\0') && (iVar3 != 0)) && (param_3 == iVar3)) {
    cVar4 = '\0';
  }
  else {
    FUN_01679490();
    FUN_01679490();
    cVar4 = (char)param_4;
  }
  if ((iVar3 != 0) &&
     (((cVar4 != '\0' || (param_3 != iVar3)) ||
      ((cVar4 = FUN_016793f0(), cVar4 == '\0' ||
       ((*param_1 != '\0' && (cVar4 = FUN_016793f0(), cVar4 == '\0')))))))) {
    iStack_1c = param_2;
    iStack_18 = iVar3;
    pcStack_14 = param_1;
    param_3 = FUN_00b06640(*(undefined4 *)(param_2 + 0x2c));
    param_4 = FUN_00b06640(*(undefined4 *)(param_2 + 0x30));
    if (param_3 != 0) {
      param_2 = FUN_00c39f80(&param_3,&iStack_1c);
      uStack_8 = 0;
      cVar4 = FUN_01679300(param_2);
      if (cVar4 != '\0') {
        FUN_01679490();
        FUN_016791c0(param_2);
      }
      uStack_8 = 0xffffffff;
      if (param_3 != 0) {
        piVar1 = (int *)(param_3 + 4);
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(param_3);
        }
      }
    }
    if (param_4 != 0) {
      param_4 = FUN_00c39f80(&param_2,&iStack_1c);
      uStack_8 = 1;
      cVar4 = FUN_01679300(param_4);
      if (cVar4 != '\0') {
        FUN_01679490();
        FUN_016791c0(param_4);
      }
      if (param_2 != 0) {
        piVar1 = (int *)(param_2 + 4);
        LOCK();
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          FUN_01674ea0(param_2);
        }
      }
    }
  }
  *(int *)(param_1 + 4) = iVar3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28149 ; VA 0x00c3dc70 ; FUN_00c3dc70 */

void __thiscall FUN_00c3dc70(int param_1,int param_2)

{
  int *piVar1;
  bool bVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018094c0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = FUN_00c3a5c0(param_1 + 0x74);
  iStack_1c = FUN_00c3a5c0(param_1 + 0x7c);
  if (DAT_01d68640 == '\0') {
    FUN_01679490();
    FUN_01679490();
  }
  iVar7 = *(int *)(param_1 + 0x90);
  piVar1 = *(int **)(iVar7 + 4);
  if (piVar1 == (int *)0x0) {
    iStack_20 = 0;
  }
  else {
    iVar6 = (**(code **)(*piVar1 + 4))();
    iVar7 = *(int *)(iVar7 + 4);
    if (iVar6 == 0xf) {
      iVar7 = *(int *)(iVar7 + 4);
    }
    iStack_20 = *(int *)(iVar7 + 0xc);
  }
  iVar6 = 0;
  iVar7 = 0;
  if (((*(char *)(param_1 + 0x8c) != '\0') && (iStack_18 != 0)) && (iStack_1c != 0)) {
    iVar7 = *(int *)(param_1 + 0x34);
    if ((iVar7 == 0) ||
       (iVar6 = *(int *)(iVar7 + 0xc), iVar4 = FUN_00be8480(),
       (uint)*(ushort *)(iVar4 + 0x1da) <
       (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8))) {
      iVar6 = FUN_00a9d0e0(iVar7);
    }
    else {
      iVar6 = FUN_005c3ac0(iVar7);
    }
    if (iVar6 != 0) {
      iVar7 = FUN_00a9d0e0(iStack_18);
      iVar4 = FUN_00a9d0e0(iStack_1c);
      if ((iVar6 == iVar7) && (iVar6 == iVar4)) {
        iVar7 = *(int *)(iVar6 + 0x1b4);
        goto LAB_00c3dd6f;
      }
    }
    iVar7 = 0;
  }
LAB_00c3dd6f:
  if ((iVar7 != iStack_20) || ((char)param_2 != '\0')) {
    if (iStack_20 != 0) {
      FUN_00bc0420(*(undefined4 *)(param_1 + 0x90));
    }
    if (iVar7 == 0) {
      FUN_00ca4900(0,0);
      FUN_00ca4900(1,0);
    }
    else {
      if ((*(char *)(iVar6 + 0x1b8) == '\0') &&
         (iVar4 = (**(code **)(**(int **)(param_1 + 0x90) + 0x10))(), iVar4 - 1U < 4)) {
        iStack_24 = *(int *)(iStack_18 + 0xa8);
        iStack_20 = *(int *)(iStack_1c + 0xa8);
        iVar4 = (**(code **)(**(int **)(iStack_24 + 0x1ac) + 8))();
        cStack_11 = iVar4 == 10;
        iVar4 = (**(code **)(**(int **)(iStack_20 + 0x1ac) + 8))();
        if ((bool)cStack_11 != (iVar4 == 10)) {
          if (cStack_11 == '\0') {
            uVar5 = FUN_0060efa0();
            FUN_00c3ceb0(uVar5);
            uVar5 = FUN_00c157b0();
          }
          else {
            uVar5 = FUN_00c157b0();
            FUN_00c3ceb0(uVar5);
            uVar5 = FUN_0060efa0();
          }
          FUN_00c3cee0(uVar5);
        }
      }
      FUN_00ca4900(0,*(undefined4 *)(iStack_18 + 0xa8));
      FUN_00ca4900(1,*(undefined4 *)(iStack_1c + 0xa8));
      if ((*(int *)(*(int *)(iStack_18 + 0xa8) + 0x1a8) != iVar7) ||
         (*(int *)(*(int *)(iStack_1c + 0xa8) + 0x1a8) != iVar7)) {
        goto LAB_00c3dec5;
      }
      FUN_00bbe190(*(undefined4 *)(param_1 + 0x90));
    }
  }
LAB_00c3dec5:
  if (DAT_01d68640 == '\0') {
    if (iVar6 == 0) {
      ExceptionList = pvStack_10;
      return;
    }
    param_2 = param_1;
    uVar5 = FUN_00c3a050(&iStack_24,&param_2);
    uStack_8 = 2;
    cVar3 = FUN_01679300(uVar5);
    if (cVar3 != '\0') {
      FUN_01679490();
      FUN_016791c0(uVar5);
    }
    uStack_8 = 0xffffffff;
    if (iStack_24 != 0) {
      piVar1 = (int *)(iStack_24 + 4);
      LOCK();
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        FUN_01674ea0(iStack_24);
      }
    }
    uVar5 = FUN_00c3a050(&iStack_1c,&param_2);
    uStack_8 = 3;
    cVar3 = FUN_01679300(uVar5);
    iVar7 = iStack_1c;
    if (cVar3 != '\0') {
      FUN_01679490();
      FUN_016791c0(uVar5);
      iVar7 = iStack_1c;
    }
  }
  else {
    if ((iVar6 == 0) || ((char)param_2 != '\0')) {
      FUN_01679490();
      FUN_01679490();
    }
    if (iVar6 == 0) {
      ExceptionList = pvStack_10;
      return;
    }
    cVar3 = FUN_016793f0();
    if ((cVar3 == '\0') || (cVar3 = FUN_016793f0(), cVar3 == '\0')) {
      bVar2 = true;
    }
    else {
      bVar2 = false;
    }
    if (((char)param_2 == '\0') && (!bVar2)) {
      ExceptionList = pvStack_10;
      return;
    }
    param_2 = param_1;
    uVar5 = FUN_00c3a050(&iStack_24,&param_2);
    uStack_8 = 0;
    cVar3 = FUN_01679300(uVar5);
    if (cVar3 != '\0') {
      FUN_01679490();
      FUN_016791c0(uVar5);
    }
    uStack_8 = 0xffffffff;
    if (iStack_24 != 0) {
      piVar1 = (int *)(iStack_24 + 4);
      LOCK();
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        FUN_01674ea0(iStack_24);
      }
    }
    uVar5 = FUN_00c3a050(&iStack_24,&param_2);
    uStack_8 = 1;
    cVar3 = FUN_01679300(uVar5);
    iVar7 = iStack_24;
    if (cVar3 != '\0') {
      FUN_01679490();
      FUN_016791c0(uVar5);
      iVar7 = iStack_24;
    }
  }
  if (iVar7 != 0) {
    piVar1 = (int *)(iVar7 + 4);
    LOCK();
    iVar6 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar6 == 1) {
      FUN_01674ea0(iVar7);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28150 ; VA 0x00c3e0d0 ; FUN_00c3e0d0 */

undefined4 __thiscall FUN_00c3e0d0(int param_1,uint *param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018094e0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00c3a5c0(param_1 + 0x74);
  iVar4 = FUN_00c3a5c0(param_1 + 0x7c);
  if (iVar3 == 0) {
LAB_00c3e13a:
    cVar1 = '\0';
  }
  else {
    if (*param_2 == 0) {
      uVar5 = FUN_0054fda0();
      uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0(uVar5);
    }
    cVar1 = (**(code **)((*param_2 & 0xfffffffe) + 4))(param_2 + 2,iVar3);
    if (cVar1 == '\0') goto LAB_00c3e13a;
    cVar1 = '\x01';
  }
  if (iVar4 != 0) {
    if (*param_2 == 0) {
      uVar5 = FUN_0054fda0();
      uStack_8 = 1;
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0(uVar5);
    }
    cVar2 = (**(code **)((*param_2 & 0xfffffffe) + 4))(param_2 + 2,iVar4);
    if (cVar2 != '\0') {
      cVar2 = '\x01';
      goto LAB_00c3e160;
    }
  }
  cVar2 = '\0';
LAB_00c3e160:
  if (cVar1 == cVar2) {
    uVar5 = FUN_008a89f0(param_2,param_3,param_4);
    ExceptionList = pvStack_10;
    return uVar5;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 28151 ; VA 0x00c3e1d0 ; FUN_00c3e1d0 */

undefined4 * __fastcall FUN_00c3e1d0(undefined4 *param_1)

{
  *param_1 = RBX::IMoving::vftable;
  FUN_016830f0(param_1 + 2);
  param_1[4] = 0;
  param_1[5] = 0xffffffff;
  param_1[6] = 0;
  return param_1;
}



/* FUNCTION 28152 ; VA 0x00c3e200 ; FUN_00c3e200 */

void __fastcall FUN_00c3e200(undefined4 *param_1)

{
  *param_1 = RBX::IMoving::vftable;
  return;
}



/* FUNCTION 28153 ; VA 0x00c3e210 ; FUN_00c3e210 */

void __fastcall FUN_00c3e210(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  *param_1 = RBX::IVisuallyMovingManager::vftable;
  FUN_0070a3d0();
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    uVar3 = param_1[3] - iVar1 & 0xfffffff8;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
  }
  return;
}



/* FUNCTION 28154 ; VA 0x00c3e280 ; FUN_00c3e280 */

void __fastcall FUN_00c3e280(undefined4 *param_1)

{
  (**(code **)*param_1)(0);
  if (param_1[4] != 0) {
    FUN_00c3e2c0(param_1);
  }
  return;
}



/* FUNCTION 28155 ; VA 0x00c3e2a0 ; FUN_00c3e2a0 */

void __fastcall FUN_00c3e2a0(int param_1)

{
  *(undefined4 *)(param_1 + 0x18) = 0;
  if (*(int *)(param_1 + 0x10) != 0) {
    FUN_00c3e430(param_1);
  }
  return;
}



/* FUNCTION 28156 ; VA 0x00c3e2c0 ; FUN_00c3e2c0 */

undefined4 __thiscall FUN_00c3e2c0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int aiStack_c [2];
  
  iVar2 = param_2;
  if (DAT_01d6866c == '\0') {
    if ((DAT_01d68674 == '\0') || (*(char *)(param_1 + 0x30) == '\0')) {
      FUN_00708ea0(aiStack_c,&param_2,param_2);
      return 1;
    }
  }
  else if ((DAT_01d68674 == '\0') || (*(char *)(param_1 + 0x30) == '\0')) {
    if (*(int *)(param_2 + 0x14) != -1) {
      *(undefined4 *)(*(int *)(param_1 + 4) + 4 + *(int *)(param_2 + 0x14) * 8) = 0x1e;
      *(undefined4 *)(param_2 + 0x18) = 0x1e;
      return 1;
    }
    *(int *)(param_2 + 0x14) = *(int *)(param_1 + 8) - *(int *)(param_1 + 4) >> 3;
    piVar1 = *(int **)(param_1 + 8);
    aiStack_c[0] = param_2;
    aiStack_c[1] = 0x1e;
    if (*(int **)(param_1 + 0xc) != piVar1) {
      *piVar1 = param_2;
      piVar1[1] = 0x1e;
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 8;
      *(undefined4 *)(param_2 + 0x18) = 0x1e;
      return 0;
    }
    FUN_006c6ad0(piVar1,aiStack_c);
    *(undefined4 *)(iVar2 + 0x18) = 0x1e;
    return 0;
  }
  return 0;
}



/* FUNCTION 28157 ; VA 0x00c3e3a0 ; FUN_00c3e3a0 */

void __fastcall FUN_00c3e3a0(undefined4 *param_1)

{
  char cVar1;
  
  if (DAT_01d6866c == '\0') {
    if (param_1[6] == 0) {
      if (DAT_01ee4200 != '\0') {
        FUN_016774b0(DAT_01ee4200,"IMoving::notifyVisuallyMoved wakes part %p",param_1);
      }
      param_1[6] = 0x1e;
      (**(code **)*param_1)(0);
      if (param_1[4] != 0) {
        FUN_00c3e2c0(param_1);
        return;
      }
    }
    else {
      param_1[6] = 0x1e;
    }
  }
  else if (param_1[4] != 0) {
    cVar1 = FUN_00c3e2c0(param_1);
    if (cVar1 != '\0') {
      if (DAT_01ee4200 != '\0') {
        FUN_016774b0(DAT_01ee4200,"IMoving::notifyVisuallyMoved wakes part %p",param_1);
      }
      (**(code **)*param_1)(0);
      return;
    }
  }
  return;
}



/* FUNCTION 28158 ; VA 0x00c3e430 ; FUN_00c3e430 */

bool __thiscall FUN_00c3e430(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  
  iVar4 = param_2;
  if (DAT_01d6866c == '\0') {
    iVar4 = FUN_0070cc60(&param_2);
    return iVar4 != 0;
  }
  iVar1 = *(int *)(param_2 + 0x14);
  if (iVar1 != -1) {
    iVar5 = (*(int *)(param_1 + 8) - *(int *)(param_1 + 4) >> 3) + -1;
    *(int *)(*(int *)(*(int *)(param_1 + 4) + iVar5 * 8) + 0x14) = iVar1;
    iVar2 = *(int *)(param_1 + 4);
    uVar3 = *(undefined4 *)(iVar2 + 4 + iVar5 * 8);
    *(undefined4 *)(iVar2 + iVar1 * 8) = *(undefined4 *)(iVar2 + iVar5 * 8);
    *(undefined4 *)(iVar2 + 4 + iVar1 * 8) = uVar3;
    *(undefined4 *)(param_2 + 0x14) = 0xffffffff;
    FUN_006c6ee0(iVar5,(int *)(param_1 + 4));
    *(undefined4 *)(iVar4 + 0x18) = 0;
    return true;
  }
  *(undefined4 *)(param_2 + 0x18) = 0;
  return false;
}



/* FUNCTION 28159 ; VA 0x00c3e4d0 ; FUN_00c3e4d0 */

void __thiscall FUN_00c3e4d0(int param_1,char param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809500;
  pvStack_10 = ExceptionList;
  if (((param_2 != *(char *)(param_1 + 0x30)) &&
      (ExceptionList = &pvStack_10, *(char *)(param_1 + 0x30) = param_2, DAT_01d68674 != '\0')) &&
     (param_2 == '\0')) {
    if (DAT_01d6866c != '\0') {
      piVar1 = *(int **)(param_1 + 8);
      for (piVar4 = *(int **)(param_1 + 4); piVar4 != piVar1; piVar4 = piVar4 + 2) {
        *(undefined4 *)(*piVar4 + 0x14) = 0xffffffff;
        *(undefined4 *)(*piVar4 + 0x18) = 0;
      }
    }
    uStack_3c = 0;
    uStack_38 = 0;
    uStack_34 = 0;
    uStack_38 = FUN_00575b50(0,0);
    uStack_30 = 0;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_8 = 1;
    uStack_3c = 0x3f800000;
    FUN_005cb500(8);
    if ((undefined4 *)(param_1 + 0x10) != &uStack_3c) {
      *(undefined4 *)(param_1 + 0x10) = uStack_3c;
      if ((undefined4 *)(param_1 + 0x1c) != &uStack_30) {
        FUN_0056d320();
        *(undefined4 *)(param_1 + 0x1c) = uStack_30;
        *(undefined4 *)(param_1 + 0x20) = uStack_2c;
        *(undefined4 *)(param_1 + 0x24) = uStack_28;
        uStack_30 = 0;
        uStack_2c = 0;
        uStack_28 = 0;
      }
      *(undefined4 *)(param_1 + 0x28) = uStack_24;
      *(undefined4 *)(param_1 + 0x2c) = uStack_20;
      puVar5 = (undefined4 *)(param_1 + 0x14);
      if (puVar5 != &uStack_38) {
        FUN_0087de00();
        uVar2 = *puVar5;
        *puVar5 = uStack_38;
        uVar3 = *(undefined4 *)(param_1 + 0x18);
        *(undefined4 *)(param_1 + 0x18) = uStack_34;
        uStack_38 = uVar2;
        uStack_34 = uVar3;
      }
      FUN_0070b540();
    }
    FUN_0070a3d0();
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
    if ((undefined4 *)(param_1 + 4) != &uStack_1c) {
      FUN_0056d380();
      *(undefined4 *)(param_1 + 4) = 0;
      *(undefined4 *)(param_1 + 8) = 0;
      *(undefined4 *)(param_1 + 0xc) = 0;
    }
    FUN_0056d380();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28160 ; VA 0x00c3e680 ; FUN_00c3e680 */

void __thiscall FUN_00c3e680(int param_1,undefined4 *param_2)

{
  *(undefined4 *)(param_1 + 8) = *param_2;
  *(undefined4 *)(param_1 + 0xc) = param_2[1];
  return;
}



/* FUNCTION 28161 ; VA 0x00c3e6a0 ; FUN_00c3e6a0 */

undefined4 __fastcall FUN_00c3e6a0(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x18);
  *(undefined4 *)(param_1 + 0x18) = 0x1e;
  return CONCAT31((int3)((uint)iVar1 >> 8),iVar1 == 0);
}



/* FUNCTION 28162 ; VA 0x00c3e6b0 ; FUN_00c3e6b0 */

void __thiscall FUN_00c3e6b0(undefined4 *param_1,int param_2)

{
  char cVar1;
  
  if (param_1[4] != 0) {
    cVar1 = FUN_00c3e430(param_1);
    if ((DAT_01d68684 != '\0') && (param_1[6] = 0, cVar1 != '\0')) {
      (**(code **)*param_1)(1);
    }
  }
  param_1[4] = param_2;
  if ((DAT_01d6866c == '\0') && (DAT_01d6868c == '\0')) {
    if ((param_2 != 0) && (0 < (int)param_1[6])) {
      (**(code **)*param_1)(0);
      if (param_1[4] != 0) {
        FUN_00c3e2c0(param_1);
        return;
      }
    }
  }
  else if (param_2 != 0) {
    param_1[6] = 0x1e;
    cVar1 = FUN_00c3e2c0(param_1);
    if (cVar1 != '\0') {
      (**(code **)*param_1)(0);
    }
  }
  return;
}



/* FUNCTION 28163 ; VA 0x00c3e740 ; FUN_00c3e740 */

void __fastcall FUN_00c3e740(int *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  char cVar5;
  undefined4 *puVar6;
  uint uVar7;
  int *piVar8;
  int *piVar9;
  uint uVar10;
  undefined8 uVar11;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809524;
  pvStack_10 = ExceptionList;
  if ((DAT_01d68674 == '\0') || (*(char *)(param_1 + 0xc) == '\0')) {
    ExceptionList = &pvStack_10;
    piStack_14 = param_1;
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efc5b0)
       && (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01efc5b0), DAT_01efc5b0 == -1)) {
      uStack_8 = 0;
      uVar11 = FUN_0152dab0(&DAT_018cb3fc,"updateVisuallySleeping",0xffffffff);
      iStack_18 = (int)((ulonglong)uVar11 >> 0x20);
      if (DAT_01d7ad40 != '\0') {
        FUN_01532a30(uVar11);
      }
      uStack_8 = 0xffffffff;
      DAT_01efc5a8 = (int)uVar11;
      DAT_01efc5ac = iStack_18;
      FUN_016f37bf(&DAT_01efc5b0);
    }
    iVar4 = DAT_01efc5ac;
    uVar3 = DAT_01efc5a8;
    uVar11 = FUN_01532c80(DAT_01efc5a8,DAT_01efc5ac);
    uStack_8 = 1;
    if (DAT_01d6866c == '\0') {
      param_1[2] = param_1[1];
      piVar8 = (int *)param_1[5];
      piVar9 = (int *)*piVar8;
      if (DAT_01d6867c == '\0') {
        if (piVar9 != piVar8) {
          do {
            piVar8 = (int *)piVar9[2];
            if (piVar8[6] < 2) {
              cVar5 = (**(code **)(*piVar8 + 0x14))();
              if (cVar5 == '\0') {
                piVar8[6] = 0;
                (**(code **)*piVar8)(1);
                puVar6 = (undefined4 *)FUN_0070cbb0(&iStack_18,piVar9);
                piVar9 = (int *)*puVar6;
              }
              else {
                piVar8[6] = 0x1e;
                piVar9 = (int *)*piVar9;
              }
            }
            else {
              piVar8[6] = piVar8[6] + -1;
              piVar9 = (int *)*piVar9;
            }
          } while (piVar9 != (undefined4 *)piStack_14[5]);
        }
      }
      else if (piVar9 != piVar8) {
        do {
          puVar6 = (undefined4 *)piVar9[2];
          if ((int)puVar6[6] < 2) {
            puVar6[6] = 0;
            (**(code **)*puVar6)(1);
            puVar6 = (undefined4 *)FUN_0070cbb0(&iStack_18,piVar9);
            piVar9 = (int *)*puVar6;
          }
          else {
            puVar6[6] = puVar6[6] + -1;
            piVar9 = (int *)*piVar9;
          }
        } while (piVar9 != (undefined4 *)param_1[5]);
      }
    }
    else {
      FUN_0070b540();
      piVar8 = param_1 + 1;
      uVar10 = 0;
      uVar7 = param_1[2] - *piVar8 >> 3;
      piStack_14 = piVar8;
      if (uVar7 != 0) {
        do {
          iVar1 = *piVar8;
          piVar9 = (int *)(iVar1 + 4 + uVar10 * 8);
          *piVar9 = *piVar9 + -1;
          if (*(int *)(iVar1 + 4 + uVar10 * 8) < 1) {
            iStack_18 = uVar7 - 1;
            puVar6 = *(undefined4 **)(*piVar8 + uVar10 * 8);
            *(uint *)(*(int *)(*piVar8 + iStack_18 * 8) + 0x14) = uVar10;
            iVar1 = *piVar8;
            uVar2 = *(undefined4 *)(iVar1 + 4 + iStack_18 * 8);
            *(undefined4 *)(iVar1 + uVar10 * 8) = *(undefined4 *)(iVar1 + iStack_18 * 8);
            *(undefined4 *)(iVar1 + 4 + uVar10 * 8) = uVar2;
            puVar6[5] = 0xffffffff;
            puVar6[6] = 0;
            FUN_006c6ee0(iStack_18,piStack_14);
            (**(code **)*puVar6)(1);
            uVar7 = piStack_14[1] - *piStack_14 >> 3;
            piVar8 = piStack_14;
          }
          else {
            uVar10 = uVar10 + 1;
          }
        } while (uVar10 < uVar7);
      }
    }
    uStack_8 = 2;
    FUN_0152dda0(uVar3,iVar4,uVar11);
    if (DAT_01d7ad40 != '\0') {
      FUN_01532d10(uVar3,iVar4,uVar11);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28164 ; VA 0x00c3e9d0 ; FUN_00c3e9d0 */

int * __thiscall
FUN_00c3e9d0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d64cb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c3ebd0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::TextBox,float>::
              GetSetImpl<float_(__thiscall_RBX::GuiTextMixin<class_RBX::TextBox,class_RBX::DescribedCreatable<class_RBX::TextBox,class_RBX::GuiObject>_>::*)(void)const_,void_(__thiscall_RBX::GuiTextMixin<class_RBX::TextBox,class_RBX::DescribedCreatable<class_RBX::TextBox,class_RBX::GuiObject>_>::*)(float)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::TextBox,float>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::TextBox,float>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28165 ; VA 0x00c3ead0 ; FUN_00c3ead0 */

int * __thiscall
FUN_00c3ead0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bc8db;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00c3ebd0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::TextBox,int>::
              GetSetImpl<int_(__thiscall_RBX::TextBox::*)(void)const_,void_(__thiscall_RBX::TextBox::*)(int)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::TextBox,int>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::TextBox,int>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28166 ; VA 0x00c3ebd0 ; FUN_00c3ebd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00c3ebd0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809550;
  pvStack_10 = ExceptionList;
  if (DAT_01efc5dc == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efc7f0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01efc7f0);
      if (DAT_01efc7f0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00c6de80();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"TextBox",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01efc7e8 = RBX::Creator<class_RBX::TextBox>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01efc5e0,&DAT_01efc7e8);
        FUN_016f3654(FUN_01894d80);
        FUN_016f37bf(&DAT_01efc7f0);
      }
    }
    DAT_01efc5dc = &DAT_01efc5e0;
  }
  ExceptionList = pvStack_10;
  return DAT_01efc5dc;
}



/* FUNCTION 28167 ; VA 0x00c3ecd0 ; FUN_00c3ecd0 */

void FUN_00c3ecd0(char *param_1,char *param_2)

{
  char *pcVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  char *pcVar6;
  
  if (param_1 != param_2) {
    pcVar6 = param_1 + 0x24;
    do {
      if (pcVar6[0x10] != '\0') {
        pcVar6[0x10] = '\0';
      }
      if (*pcVar6 != '\0') {
        *pcVar6 = '\0';
      }
      if (pcVar6[-8] != '\0') {
        pcVar6[-8] = '\0';
      }
      uVar2 = *(uint *)(pcVar6 + -0x10);
      if (0xf < uVar2) {
        iVar3 = *(int *)(pcVar6 + -0x24);
        uVar5 = uVar2 + 1;
        iVar4 = iVar3;
        if (0xfff < uVar5) {
          iVar4 = *(int *)(iVar3 + -4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar5);
      }
      pcVar6[-0xffffffff00000014] = '\0';
      pcVar6[-0xffffffff00000013] = '\0';
      pcVar6[-0xffffffff00000012] = '\0';
      pcVar6[-0xffffffff00000011] = '\0';
      pcVar6[-0xffffffff00000010] = '\x0f';
      pcVar6[-0xffffffff0000000f] = '\0';
      pcVar6[-0xffffffff0000000e] = '\0';
      pcVar6[-0xffffffff0000000d] = '\0';
      pcVar6[-0x24] = '\0';
      pcVar1 = pcVar6 + 0x18;
      pcVar6 = pcVar6 + 0x3c;
    } while (pcVar1 != param_2);
  }
  return;
}



/* FUNCTION 28168 ; VA 0x00c3ed60 ; FUN_00c3ed60 */

int __thiscall FUN_00c3ed60(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01809560;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::TextBox*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28169 ; VA 0x00c3ee32 ; Catch_All@00c3ee32 */

void Catch_All_00c3ee32(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 28170 ; VA 0x00c3ee50 ; FUN_00c3ee50 */

undefined4 * FUN_00c3ee50(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_018095a3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c3ebd0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x648);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c3f250();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00c3ed60(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28171 ; VA 0x00c3ef10 ; FUN_00c3ef10 */

int FUN_00c3ef10(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01ef1bf0,&LAB_00b7a3b0);
      uVar3 = FUN_00b7a890();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_00e44910();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar4;
    }
  }
  return 0;
}



/* FUNCTION 28172 ; VA 0x00c3f020 ; FUN_00c3f020 */

int FUN_00c3f020(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01eb1cbc,&LAB_007877a0);
      uVar3 = FUN_00787aa0();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_00d27ba0();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar4;
    }
  }
  return 0;
}



/* FUNCTION 28173 ; VA 0x00c3f130 ; FUN_00c3f130 */

undefined4 * __thiscall FUN_00c3f130(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  uVar1 = FUN_00c3ebd0();
  FUN_009cb970(uVar1,param_3,0,CONCAT44(uStack_1c,uStack_20),0);
  param_1[0xd] = param_2;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::TextBox,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::TextBox::*>
             ::vftable;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  if (param_1 + 10 != &uStack_20) {
    FUN_0068a760();
    param_1[10] = 0;
    param_1[0xb] = 0;
    param_1[0xc] = 0;
  }
  uStack_8 = 1;
  FUN_0068a760();
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::TextBox,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::TextBox::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28174 ; VA 0x00c3f200 ; FUN_00c3f200 */

undefined4 * __thiscall FUN_00c3f200(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = 0;
  param_1[4] = 0;
  if (param_2[4] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[4] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[3] = param_2[3];
  param_1[4] = param_2[4];
  return param_1;
}



/* FUNCTION 28175 ; VA 0x00c3f250 ; FUN_00c3f250 */

undefined4 * __fastcall FUN_00c3f250(undefined4 *param_1)

{
  undefined uVar1;
  undefined8 *puVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined auStack_24 [12];
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018096a2;
  pvStack_10 = ExceptionList;
  uStack_14 = 0x1a;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  puVar2 = (undefined8 *)FUN_00c98ad0(auStack_24);
  uStack_2c = 0;
  uStack_28 = 0xf;
  auStack_3c[0] = auStack_3c[0] & 0xffffff00;
  FUN_005542c0("TextBox",7);
  uStack_8 = 0;
  FUN_00c6f840("TextBox",1);
  uStack_8._0_1_ = 1;
  *param_1 = RBX::DescribedCreatable<class_RBX::TextBox,class_RBX::GuiObject>::vftable;
  param_1[0x15] = RBX::DescribedCreatable<class_RBX::TextBox,class_RBX::GuiObject>::vftable;
  uVar3 = FUN_00c3ebd0();
  param_1[3] = uVar3;
  param_1[0xd2] = RBX::IGuiText::vftable;
  *param_1 = RBX::
             GuiTextMixin<class_RBX::TextBox,class_RBX::DescribedCreatable<class_RBX::TextBox,class_RBX::GuiObject>_>
             ::vftable;
  param_1[0x15] =
       RBX::
       GuiTextMixin<class_RBX::TextBox,class_RBX::DescribedCreatable<class_RBX::TextBox,class_RBX::GuiObject>_>
       ::vftable;
  param_1[0xd2] =
       RBX::
       GuiTextMixin<class_RBX::TextBox,class_RBX::DescribedCreatable<class_RBX::TextBox,class_RBX::GuiObject>_>
       ::vftable;
  param_1[0xd3] = 0;
  param_1[0xd4] = 0;
  *(undefined2 *)(param_1 + 0xd5) = 0x101;
  *(undefined *)((int)param_1 + 0x356) = 1;
  param_1[0xd6] = 0;
  param_1[0xd7] = 0;
  param_1[0xd8] = 0;
  param_1[0xd9] = 0;
  param_1[0xda] = 0;
  param_1[0xdb] = 0;
  uStack_8._0_1_ = 6;
  *(undefined *)(param_1 + 0xdc) = 0;
  FUN_0054ef60(auStack_3c);
  param_1[0xe7] = 0;
  param_1[0xe8] = 0xf;
  *(undefined *)(param_1 + 0xe3) = 0;
  param_1[0xed] = 0;
  param_1[0xee] = 0xf;
  *(undefined *)(param_1 + 0xe9) = 0;
  param_1[0xef] = 0;
  param_1[0xf0] = 0;
  param_1[0xf1] = 8;
  *(undefined8 *)(param_1 + 0xf2) = *puVar2;
  param_1[0xf4] = *(undefined4 *)(puVar2 + 1);
  param_1[0xf5] = 0;
  param_1[0xf6] = 0;
  param_1[0xf7] = 0;
  param_1[0xf8] = 0;
  uStack_8._0_1_ = 9;
  param_1[0xf9] = 0x3f800000;
  *(undefined2 *)(param_1 + 0xfa) = 0;
  param_1[0xfb] = 0x3f800000;
  *(undefined *)(param_1 + 0xfc) = 0;
  param_1[0xfd] = 0x3f800000;
  param_1[0xfe] = 2;
  param_1[0xff] = 1;
  param_1[0x100] = 0;
  param_1[0x101] = 0;
  FUN_00d7edb0();
  param_1[0x14b] = 0;
  param_1[0x14c] = 0;
  param_1[0x14d] = 0;
  param_1[0x14e] = 0;
  *(undefined2 *)(param_1 + 0x14f) = 0;
  uStack_8._0_1_ = 0xb;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 0xb;
  if (0xf < uStack_28) {
    uVar5 = uStack_28 + 1;
    uVar4 = auStack_3c[0];
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(auStack_3c[0] - 4);
      uVar5 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar4) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  FUN_00f45140();
  *param_1 = RBX::TextBox::vftable;
  param_1[0x15] = RBX::TextBox::vftable;
  param_1[0xd2] = RBX::TextBox::vftable;
  param_1[0x150] = RBX::TextBox::vftable;
  *(undefined2 *)(param_1 + 0x152) = 0;
  *(undefined *)((int)param_1 + 0x54a) = 1;
  param_1[0x157] = 0;
  param_1[0x158] = 0xf;
  *(undefined *)(param_1 + 0x153) = 0;
  uStack_8._0_1_ = 0xd;
  param_1[0x15d] = 0;
  param_1[0x15e] = 0xf;
  *(undefined *)(param_1 + 0x159) = 0;
  FUN_005542c0("TextBox",7);
  param_1[0x163] = 0;
  param_1[0x164] = 0xf;
  *(undefined *)(param_1 + 0x15f) = 0;
  *(undefined8 *)(param_1 + 0x166) = 0;
  param_1[0x168] = 0x10001;
  *(undefined2 *)(param_1 + 0x169) = 0x100;
  *(undefined *)((int)param_1 + 0x5a6) = 0;
  param_1[0x16a] = 0;
  param_1[0x16b] = 0;
  param_1[0x16c] = 0;
  param_1[0x16d] = 0;
  param_1[0x16e] = 0;
  param_1[0x16f] = 0xffffffff;
  param_1[0x170] = 0xffffffff;
  param_1[0x178] = 0;
  *(undefined *)(param_1 + 0x17a) = 0;
  param_1[0x17b] = 0;
  param_1[0x17c] = 0;
  param_1[0x181] = 0;
  param_1[0x182] = 0xf;
  uStack_8._0_1_ = 0x11;
  *(undefined *)(param_1 + 0x17d) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 0x12;
  param_1[0x187] = 0;
  param_1[0x188] = 0xf;
  *(undefined *)(param_1 + 0x183) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
  puVar2 = (undefined8 *)FUN_0115eb40();
  *(undefined8 *)(param_1 + 0x189) = *puVar2;
  param_1[0x18b] = *(undefined4 *)(puVar2 + 1);
  param_1[0x18c] = 0;
  param_1[0x18d] = 0;
  param_1[0x18e] = 0;
  param_1[399] = 0;
  param_1[400] = 0;
  param_1[0x191] = 0;
  *(undefined *)((int)param_1 + 0x342) = 1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 28176 ; VA 0x00c3f6c0 ; FUN_00c3f6c0 */

void __fastcall FUN_00c3f6c0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::TextBox>::vftable;
  uVar1 = FUN_00c3ebd0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28177 ; VA 0x00c3f700 ; FUN_00c3f700 */

void __fastcall FUN_00c3f700(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008600a0();
  uVar2 = *(uint *)(param_1 + 0x3b8);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x3a4);
    uVar5 = uVar2 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00c3f894;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x3b4) = 0;
  *(undefined4 *)(param_1 + 0x3b8) = 0xf;
  *(undefined *)(param_1 + 0x3a4) = 0;
  uVar2 = *(uint *)(param_1 + 0x3a0);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x38c);
    uVar5 = uVar2 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) goto LAB_00c3f894;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 0x39c) = 0;
  *(undefined4 *)(param_1 + 0x3a0) = 0xf;
  *(undefined *)(param_1 + 0x38c) = 0;
  uVar2 = *(uint *)(param_1 + 0x388);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x374);
    uVar5 = uVar2 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_00c3f894:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  *(undefined4 *)(param_1 + 900) = 0;
  *(undefined4 *)(param_1 + 0x388) = 0xf;
  *(undefined *)(param_1 + 0x374) = 0;
  FUN_00c3f8a0();
  FUN_00c3f990();
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x350);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  FUN_00fa7100();
  FUN_00c32d60();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28178 ; VA 0x00c3f8a0 ; FUN_00c3f8a0 */

void __fastcall FUN_00c3f8a0(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int *piVar5;
  int *piVar6;
  
  piVar5 = (int *)*param_1;
  if (piVar5 != (int *)0x0) {
    piVar6 = (int *)param_1[1];
    if (piVar5 != piVar6) {
      do {
        if (*(char *)(piVar5 + 0xd) != '\0') {
          *(undefined *)(piVar5 + 0xd) = 0;
        }
        if (*(char *)(piVar5 + 9) != '\0') {
          *(undefined *)(piVar5 + 9) = 0;
        }
        if (*(char *)(piVar5 + 7) != '\0') {
          *(undefined *)(piVar5 + 7) = 0;
        }
        uVar4 = piVar5[5];
        if (0xf < uVar4) {
          iVar1 = *piVar5;
          uVar3 = uVar4 + 1;
          iVar2 = iVar1;
          if (0xfff < uVar3) {
            iVar2 = *(int *)(iVar1 + -4);
            uVar3 = uVar4 + 0x24;
            if (0x1f < (iVar1 - iVar2) - 4U) goto LAB_00c3f97f;
          }
          FUN_01674ea0(iVar2,uVar3);
        }
        piVar5[4] = 0;
        piVar5[5] = 0xf;
        *(undefined *)piVar5 = 0;
        piVar5 = piVar5 + 0xf;
      } while (piVar5 != piVar6);
      piVar5 = (int *)*param_1;
    }
    uVar4 = ((param_1[2] - (int)piVar5) / 0x3c) * 0x3c;
    piVar6 = piVar5;
    if (0xfff < uVar4) {
      piVar6 = (int *)piVar5[-1];
      uVar4 = uVar4 + 0x23;
      if ((undefined *)0x1f < (undefined *)((int)piVar5 + (-4 - (int)piVar6))) {
LAB_00c3f97f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar6,uVar4);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 28179 ; VA 0x00c3f990 ; FUN_00c3f990 */

void __fastcall FUN_00c3f990(int *param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    iVar3 = param_1[1];
    if (iVar2 != iVar3) {
      do {
        FUN_008600a0();
        iVar2 = iVar2 + 0x124;
      } while (iVar2 != iVar3);
      iVar2 = *param_1;
    }
    uVar1 = ((param_1[2] - iVar2) / 0x124) * 0x124;
    iVar3 = iVar2;
    if (0xfff < uVar1) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar1 = uVar1 + 0x23;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar1);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 28180 ; VA 0x00c3fa20 ; FUN_00c3fa20 */

void __fastcall FUN_00c3fa20(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  uStack_8 = 0;
  FUN_01679490();
  iVar3 = *(int *)(param_1 + 0x630);
  if (iVar3 != 0) {
    piVar1 = (int *)(iVar3 + 4);
    LOCK();
    iVar5 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar5 == 1) {
      FUN_01674ea0(iVar3);
    }
  }
  uVar4 = *(uint *)(param_1 + 0x620);
  if (0xf < uVar4) {
    iVar3 = *(int *)(param_1 + 0x60c);
    uVar6 = uVar4 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar4 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_00c3fcb4;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x61c) = 0;
  *(undefined4 *)(param_1 + 0x620) = 0xf;
  *(undefined *)(param_1 + 0x60c) = 0;
  uVar4 = *(uint *)(param_1 + 0x608);
  if (0xf < uVar4) {
    iVar3 = *(int *)(param_1 + 0x5f4);
    uVar6 = uVar4 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar4 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_00c3fcb4;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x604) = 0;
  *(undefined4 *)(param_1 + 0x608) = 0xf;
  *(undefined *)(param_1 + 0x5f4) = 0;
  piVar1 = *(int **)(param_1 + 0x5b4);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[2] + -1;
    piVar1[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar1 = *(int **)(param_1 + 0x5ac);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[1] + -1;
    piVar1[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uVar4 = *(uint *)(param_1 + 0x590);
  if (0xf < uVar4) {
    iVar3 = *(int *)(param_1 + 0x57c);
    uVar6 = uVar4 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar4 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_00c3fcb4;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x58c) = 0;
  *(undefined4 *)(param_1 + 0x590) = 0xf;
  *(undefined *)(param_1 + 0x57c) = 0;
  uVar4 = *(uint *)(param_1 + 0x578);
  if (0xf < uVar4) {
    iVar3 = *(int *)(param_1 + 0x564);
    uVar6 = uVar4 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar4 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_00c3fcb4;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x574) = 0;
  *(undefined4 *)(param_1 + 0x578) = 0xf;
  *(undefined *)(param_1 + 0x564) = 0;
  uVar4 = *(uint *)(param_1 + 0x560);
  if (0xf < uVar4) {
    iVar3 = *(int *)(param_1 + 0x54c);
    uVar6 = uVar4 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar4 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
LAB_00c3fcb4:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x55c) = 0;
  *(undefined4 *)(param_1 + 0x560) = 0xf;
  *(undefined *)(param_1 + 0x54c) = 0;
  FUN_00f45160();
  FUN_00c3f700();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28181 ; VA 0x00c3fcba ; FUN_00c3fcba */

void FUN_00c3fcba(void)

{
  FUN_00c3ff50();
  return;
}



/* FUNCTION 28182 ; VA 0x00c3fcc5 ; FUN_00c3fcc5 */

void FUN_00c3fcc5(void)

{
  FUN_00c40100();
  return;
}



/* FUNCTION 28183 ; VA 0x00c3fcd0 ; FUN_00c3fcd0 */

void FUN_00c3fcd0(void)

{
  FUN_00c40100();
  return;
}



/* FUNCTION 28184 ; VA 0x00c3fce0 ; FUN_00c3fce0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c3fce0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::TextService::FontSize>::vftable;
  _DAT_01f07b90 = _DAT_01f07b90 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 28185 ; VA 0x00c3fd10 ; FUN_00c3fd10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c3fd10(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::TextBox::ReturnKeyType>::vftable;
  _DAT_01efc800 = _DAT_01efc800 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 28186 ; VA 0x00c3fd40 ; FUN_00c3fd40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c3fd40(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::TextBox::TextInputType>::vftable;
  _DAT_01efc7f8 = _DAT_01efc7f8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 28187 ; VA 0x00c3fd70 ; FUN_00c3fd70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c3fd70(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::TextService::TextTruncate>::vftable;
  _DAT_01f07b98 = _DAT_01f07b98 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 28188 ; VA 0x00c3fda0 ; FUN_00c3fda0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c3fda0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::TextService::XAlignment>::vftable;
  _DAT_01f07b80 = _DAT_01f07b80 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 28189 ; VA 0x00c3fdd0 ; FUN_00c3fdd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00c3fdd0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::TextService::YAlignment>::vftable;
  _DAT_01f07b88 = _DAT_01f07b88 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 28190 ; VA 0x00c3fe00 ; FUN_00c3fe00 */

undefined4 * __thiscall FUN_00c3fe00(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Text::Font>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 28191 ; VA 0x00c3fe30 ; FUN_00c3fe30 */

undefined4 * __thiscall FUN_00c3fe30(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::TextService::FontSize>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 28192 ; VA 0x00c3fe60 ; FUN_00c3fe60 */

undefined4 * __thiscall FUN_00c3fe60(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::TextService::TextTruncate>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 28193 ; VA 0x00c3fe90 ; FUN_00c3fe90 */

undefined4 * __thiscall FUN_00c3fe90(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::TextService::XAlignment>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 28194 ; VA 0x00c3fec0 ; FUN_00c3fec0 */

undefined4 * __thiscall FUN_00c3fec0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::TextService::YAlignment>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 28195 ; VA 0x00c3fef0 ; FUN_00c3fef0 */

undefined4 * __thiscall FUN_00c3fef0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::TextBox::ReturnKeyType>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 28196 ; VA 0x00c3ff20 ; FUN_00c3ff20 */

undefined4 * __thiscall FUN_00c3ff20(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::TextBox::TextInputType>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 28197 ; VA 0x00c3ff50 ; FUN_00c3ff50 */

undefined4 __thiscall FUN_00c3ff50(undefined4 param_1,byte param_2)

{
  FUN_00c3f700();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x540);
  }
  return param_1;
}



/* FUNCTION 28198 ; VA 0x00c3ff80 ; FUN_00c3ff80 */

undefined4 * __thiscall FUN_00c3ff80(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Text::Font>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 28199 ; VA 0x00c3ffb0 ; FUN_00c3ffb0 */

undefined4 * __thiscall FUN_00c3ffb0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::TextService::FontSize>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 28200 ; VA 0x00c3ffe0 ; FUN_00c3ffe0 */

undefined4 * __thiscall FUN_00c3ffe0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::TextBox::ReturnKeyType>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 28201 ; VA 0x00c40010 ; FUN_00c40010 */

undefined4 * __thiscall FUN_00c40010(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::TextBox::TextInputType>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 28202 ; VA 0x00c40040 ; FUN_00c40040 */

undefined4 * __thiscall FUN_00c40040(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::TextService::TextTruncate>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 28203 ; VA 0x00c40070 ; FUN_00c40070 */

undefined4 * __thiscall FUN_00c40070(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::TextService::XAlignment>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 28204 ; VA 0x00c400a0 ; FUN_00c400a0 */

undefined4 * __thiscall FUN_00c400a0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::TextService::YAlignment>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 28205 ; VA 0x00c400d0 ; FUN_00c400d0 */

undefined4 __thiscall FUN_00c400d0(undefined4 param_1,byte param_2)

{
  FUN_00fa7100();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 28206 ; VA 0x00c40100 ; FUN_00c40100 */

undefined4 __thiscall FUN_00c40100(undefined4 param_1,byte param_2)

{
  FUN_00c3fa20();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x648);
  }
  return param_1;
}



/* FUNCTION 28207 ; VA 0x00c40130 ; FUN_00c40130 */

void FUN_00c40130(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  int iStack_38;
  int *piStack_34;
  int aiStack_2c [5];
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  piStack_34 = (int *)param_1;
  iStack_38 = 0xc40154;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_008acee0();
  if (iVar1 != 0) {
    piStack_34 = aiStack_2c;
    iStack_38 = 0xc40169;
    FUN_00d5c590();
    uStack_8 = 0;
    FUN_0060dcd0(&iStack_38,param_2);
    FUN_00b841e0(aiStack_2c);
    if (0xf < uStack_18) {
      piStack_34 = (int *)(uStack_18 + 1);
      iVar1 = aiStack_2c[0];
      if (0xfff < piStack_34) {
        iVar1 = *(int *)(aiStack_2c[0] + -4);
        piStack_34 = (int *)(uStack_18 + 0x24);
        if (0x1f < (aiStack_2c[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
          piStack_34 = (int *)&UNK_00c401d0;
          FUN_017167a3();
        }
      }
      iStack_38 = iVar1;
      FUN_01674ea0();
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28208 ; VA 0x00c401e0 ; FUN_00c401e0 */

bool FUN_00c401e0(int param_1)

{
  int iVar1;
  int *piVar2;
  bool bVar3;
  undefined auStack_34 [24];
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795d48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_008acee0(param_1);
  if ((iVar1 != 0) && (param_1 != 0)) {
    FUN_00d5c590(auStack_34);
    uStack_8 = 0;
    piVar2 = (int *)FUN_00b82590(auStack_1c,auStack_34);
    iStack_14 = *piVar2;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_18[1] + -1;
      piStack_18[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar2 = piStack_18 + 2;
        iVar1 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_18 + 4))();
        }
      }
    }
    if (iStack_14 == 0) {
      bVar3 = false;
    }
    else {
      iVar1 = FUN_008e43d0(iStack_14);
      bVar3 = iVar1 == param_1;
    }
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return bVar3;
  }
  ExceptionList = pvStack_10;
  return false;
}



/* FUNCTION 28209 ; VA 0x00c402b0 ; FUN_00c402b0 */

void FUN_00c402b0(char *param_1,char *param_2)

{
  char *pcVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  char *pcVar6;
  
  if (param_1 != param_2) {
    pcVar6 = param_1 + 0x24;
    do {
      if (pcVar6[0x10] != '\0') {
        pcVar6[0x10] = '\0';
      }
      if (*pcVar6 != '\0') {
        *pcVar6 = '\0';
      }
      if (pcVar6[-8] != '\0') {
        pcVar6[-8] = '\0';
      }
      uVar2 = *(uint *)(pcVar6 + -0x10);
      if (0xf < uVar2) {
        iVar3 = *(int *)(pcVar6 + -0x24);
        uVar5 = uVar2 + 1;
        iVar4 = iVar3;
        if (0xfff < uVar5) {
          iVar4 = *(int *)(iVar3 + -4);
          uVar5 = uVar2 + 0x24;
          if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar4,uVar5);
      }
      pcVar6[-0xffffffff00000014] = '\0';
      pcVar6[-0xffffffff00000013] = '\0';
      pcVar6[-0xffffffff00000012] = '\0';
      pcVar6[-0xffffffff00000011] = '\0';
      pcVar6[-0xffffffff00000010] = '\x0f';
      pcVar6[-0xffffffff0000000f] = '\0';
      pcVar6[-0xffffffff0000000e] = '\0';
      pcVar6[-0xffffffff0000000d] = '\0';
      pcVar6[-0x24] = '\0';
      pcVar1 = pcVar6 + 0x18;
      pcVar6 = pcVar6 + 0x3c;
    } while (pcVar1 != param_2);
  }
  return;
}



/* FUNCTION 28210 ; VA 0x00c40340 ; FUN_00c40340 */

void FUN_00c40340(int param_1,int param_2)

{
  if (param_1 != param_2) {
    do {
      FUN_008600a0();
      param_1 = param_1 + 0x124;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 28211 ; VA 0x00c40370 ; thunk_FUN_00c45750 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00c45750(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809b66;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efc86c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efc86c);
    if (DAT_01efc86c == -1) {
      uStack_8 = 0;
      FUN_009ca470("ReturnKeyType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01efc808 = RBX::Reflection::EnumDesc<enum_RBX::TextBox::ReturnKeyType>::vftable;
      FUN_009caf20(&DAT_01d68738,6);
      FUN_016f3654(&LAB_01894be0);
      FUN_016f37bf(&DAT_01efc86c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efc808;
}



/* FUNCTION 28212 ; VA 0x00c40380 ; thunk_FUN_00c45800 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00c45800(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809b86;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01efc8d4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01efc8d4);
    if (DAT_01efc8d4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("TextInputType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01efc870 = RBX::Reflection::EnumDesc<enum_RBX::TextBox::TextInputType>::vftable;
      FUN_009caf20(&DAT_01d686f8,8);
      FUN_016f3654(&LAB_01894c00);
      FUN_016f37bf(&DAT_01efc8d4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01efc870;
}



/* FUNCTION 28213 ; VA 0x00c40390 ; FUN_00c40390 */

void __fastcall FUN_00c40390(int param_1)

{
  int iVar1;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809958;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00fad240();
  if (*(char *)(param_1 + 0x549) != '\0') {
    *(undefined *)(param_1 + 0x549) = 0;
    iVar1 = FUN_00817fa0();
    if (iVar1 != 0) {
      FUN_00d66da0();
    }
  }
  if (*(char *)(param_1 + 0x54a) != '\0') {
    FUN_005542c0(&DAT_018bc9b8,0);
  }
  *(undefined *)(param_1 + 0x548) = 1;
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8 = 0;
  FUN_00c41a50(&uStack_18);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28214 ; VA 0x00c40430 ; FUN_00c40430 */

undefined4 * __thiscall
FUN_00c40430(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017d4581;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_009b0180;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 28215 ; VA 0x00c405d0 ; FUN_00c405d0 */

undefined4 __thiscall FUN_00c405d0(float *param_1,float *param_2)

{
  if ((((*param_1 <= *param_2) && (param_1[1] <= param_2[1])) && (*param_2 <= param_1[2])) &&
     (param_2[1] <= param_1[3])) {
    return 1;
  }
  return 0;
}



/* FUNCTION 28216 ; VA 0x00c40610 ; FUN_00c40610 */

void FUN_00c40610(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00c456c0();
    *param_2 = uVar3;
    iVar4 = FUN_00c45a60();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 28217 ; VA 0x00c40670 ; FUN_00c40670 */

void FUN_00c40670(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00c45750();
    *param_2 = uVar3;
    iVar4 = FUN_00c45ad0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 28218 ; VA 0x00c406d0 ; FUN_00c406d0 */

void FUN_00c406d0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00c45800();
    *param_2 = uVar3;
    iVar4 = FUN_00c45b40();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 28219 ; VA 0x00c40730 ; FUN_00c40730 */

void FUN_00c40730(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00c458b0();
    *param_2 = uVar3;
    iVar4 = FUN_00c45bb0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 28220 ; VA 0x00c40790 ; FUN_00c40790 */

void FUN_00c40790(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00c45940();
    *param_2 = uVar3;
    iVar4 = FUN_00c45c20();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 28221 ; VA 0x00c407f0 ; FUN_00c407f0 */

void FUN_00c407f0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00c459d0();
    *param_2 = uVar3;
    iVar4 = FUN_00c45c90();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 28222 ; VA 0x00c40850 ; FUN_00c40850 */

void FUN_00c40850(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00c456c0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28223 ; VA 0x00c40890 ; FUN_00c40890 */

void FUN_00c40890(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c45750();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28224 ; VA 0x00c408d0 ; FUN_00c408d0 */

void FUN_00c408d0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00c45800();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28225 ; VA 0x00c40910 ; FUN_00c40910 */

void FUN_00c40910(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00c458b0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28226 ; VA 0x00c40950 ; FUN_00c40950 */

void FUN_00c40950(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00c45940();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28227 ; VA 0x00c40990 ; FUN_00c40990 */

void FUN_00c40990(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00c459d0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28228 ; VA 0x00c409d0 ; FUN_00c409d0 */

undefined4 * FUN_00c409d0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00c3ee50(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 28229 ; VA 0x00c40a40 ; FUN_00c40a40 */

void FUN_00c40a40(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_2 * 0x124;
  iVar1 = param_1;
  if (0xfff < uVar2) {
    iVar1 = *(int *)(param_1 + -4);
    uVar2 = uVar2 + 0x23;
    if (0x1f < (param_1 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
  FUN_01674ea0(iVar1,uVar2);
  return;
}



/* FUNCTION 28230 ; VA 0x00c40a80 ; FUN_00c40a80 */

void __thiscall FUN_00c40a80(int param_1,undefined4 param_2,char *param_3,int *param_4)

{
  int *piVar1;
  char cVar2;
  undefined4 *******pppppppuVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  undefined4 *******pppppppuVar7;
  undefined4 *******pppppppuVar8;
  uint extraout_ECX;
  uint extraout_ECX_00;
  uint extraout_ECX_01;
  int iVar9;
  uint uVar10;
  uint extraout_EDX;
  int extraout_EDX_00;
  int iVar11;
  undefined auStack_64 [24];
  undefined4 ******appppppuStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined auStack_34 [12];
  undefined auStack_28 [4];
  int iStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01809998;
  pvStack_10 = ExceptionList;
  pppppppuVar7 = (undefined4 *******)(param_1 + 0x54c);
  ExceptionList = &pvStack_10;
  FUN_0054ef60(pppppppuVar7);
  auStack_28[0] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  (**(code **)(*(int *)(param_1 + 0x348) + 4))(&uStack_1c,auStack_28,0);
  uStack_8._0_1_ = 0;
  cStack_11 = '\0';
  if ((DAT_01d686d0 != '\0') && (*param_4 != 0)) {
    cStack_11 = FUN_00d81b40(0);
  }
  switch(param_2) {
  case 0:
    if (*(char *)(param_1 + 0x5a5) == '\0') {
      uVar4 = 0xffffffff;
      param_3 = (char *)0xffffffff;
      uVar10 = *(uint *)(param_1 + 0x5b8);
      break;
    }
    cVar2 = FUN_00c41790();
    if (cVar2 != '\0') goto switchD_00c40b11_caseD_f;
    if (*(int *)(param_3 + 0x10) != 0) {
      if (0xf < *(uint *)(param_3 + 0x14)) {
        param_3 = *(char **)param_3;
      }
      if ((*param_3 != '\0') && (*(int *)(param_1 + 0x55c) != 0)) {
        uVar5 = *(int *)(param_1 + 0x55c) - 1;
        uVar10 = *(uint *)(param_1 + 0x5b8);
        if ((int)uVar5 <= (int)*(uint *)(param_1 + 0x5b8)) {
          uVar10 = uVar5;
        }
        if (-1 < (int)uVar10) {
          uVar5 = *(uint *)(param_1 + 0x560);
          do {
            pppppppuVar3 = pppppppuVar7;
            if (0xf < uVar5) {
              pppppppuVar3 = (undefined4 *******)*pppppppuVar7;
            }
            cVar2 = FUN_00c42480(*(undefined *)((int)pppppppuVar3 + uVar10));
            uVar5 = extraout_ECX;
            if (cVar2 == '\0') goto joined_r0x00c40bd2;
            uVar10 = uVar10 - 1;
          } while (-1 < (int)uVar10);
        }
LAB_00c40ba2:
        uVar4 = FUN_0058c540(auStack_34,*(undefined4 *)(param_1 + 0x5b8),0xffffffff);
        FUN_005511f0(uVar4);
        FUN_005507b0();
        uVar4 = 0xffffffff;
        param_3 = (char *)0xffffffff;
        uVar10 = 0;
        break;
      }
    }
    if (((*(uint *)(param_1 + 0x55c) == 0) || (uVar10 = *(uint *)(param_1 + 0x5b8), (int)uVar10 < 1)
        ) || (*(uint *)(param_1 + 0x55c) < uVar10)) goto switchD_00c40b11_caseD_f;
    FUN_01543370(&uStack_1c,pppppppuVar7,uVar10 - 1);
    FUN_00554db0(uStack_1c,iStack_18);
    goto LAB_00c40c5e;
  case 1:
    if (*(char *)(param_1 + 0x5a5) == '\0') {
      uVar4 = 0xffffffff;
      param_3 = (char *)0xffffffff;
      uVar10 = *(uint *)(param_1 + 0x5b8);
    }
    else {
      cVar2 = FUN_00c41790();
      if (((cVar2 != '\0') || (*(uint *)(param_1 + 0x55c) == 0)) ||
         ((uVar10 = *(uint *)(param_1 + 0x5b8), (int)uVar10 < 0 ||
          (*(uint *)(param_1 + 0x55c) <= uVar10)))) goto switchD_00c40b11_caseD_f;
      FUN_01543370(&uStack_1c,pppppppuVar7,uVar10);
      FUN_00554db0(uStack_1c,iStack_18);
      uVar4 = 0xffffffff;
      param_3 = (char *)0xffffffff;
      uVar10 = uStack_1c;
    }
    break;
  case 2:
    cVar2 = FUN_00c45d00();
    if (cVar2 != '\0') {
      iVar6 = *(int *)(param_1 + 0x5b8);
      iVar11 = *(int *)(param_1 + 0x5c0);
      iVar9 = iVar11;
      if (iVar6 <= iVar11) {
        iVar9 = iVar6;
      }
      if (iVar11 <= iVar6) {
        iVar11 = iVar6;
      }
      FUN_0058c540(auStack_34,iVar9,iVar11 - iVar9);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      iVar6 = FUN_00c3ef10(param_1);
      if (iVar6 != 0) {
        FUN_00e45940(auStack_34);
      }
      if (*(char *)(param_1 + 0x5a5) != '\0') {
        FUN_00c41790();
      }
      uStack_8._0_1_ = 0;
      FUN_005507b0();
    }
    goto switchD_00c40b11_caseD_f;
  case 3:
    cVar2 = FUN_00c45d00();
    if (cVar2 != '\0') {
      iVar6 = *(int *)(param_1 + 0x5b8);
      iVar11 = *(int *)(param_1 + 0x5c0);
      iVar9 = iVar11;
      if (iVar6 <= iVar11) {
        iVar9 = iVar6;
      }
      if (iVar11 <= iVar6) {
        iVar11 = iVar6;
      }
      FUN_0058c540(auStack_34,iVar9,iVar11 - iVar9);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      iVar6 = FUN_00c3ef10(param_1);
      if (iVar6 != 0) {
        FUN_00e45940(auStack_34);
      }
      uStack_8._0_1_ = 0;
      FUN_005507b0();
    }
    goto switchD_00c40b11_caseD_f;
  case 4:
    if (*(char *)(param_1 + 0x5a5) != '\0') {
      if (*(int *)(param_1 + 0x5e0) == 0) {
        iStack_24 = 0;
        uStack_20 = 0xf;
        auStack_34[0] = 0;
        FUN_005542c0(&DAT_018bc9b8,0);
        uStack_8 = CONCAT31(uStack_8._1_3_,4);
        iVar6 = FUN_008acee0(param_1);
        if (iVar6 != 0) {
          uVar4 = FUN_00b83170(auStack_64);
          FUN_005511f0(uVar4);
          FUN_005507b0();
        }
        FUN_00c41790();
        if (((iStack_24 != 0) && (uVar10 = *(uint *)(param_1 + 0x5b8), -1 < (int)uVar10)) &&
           (uVar10 <= *(uint *)(param_1 + 0x55c))) {
          FUN_00585b80(uVar10,auStack_34);
          FUN_00c44da0(*(int *)(param_1 + 0x5b8) + iStack_24,0xffffffff,0xffffffff);
        }
        uStack_8._0_1_ = 0;
        FUN_005507b0();
      }
      goto switchD_00c40b11_caseD_f;
    }
    uVar4 = 0xffffffff;
    param_3 = (char *)0xffffffff;
    uVar10 = *(uint *)(param_1 + 0x5b8);
    break;
  case 5:
    if (*(char *)(param_1 + 0x5a5) == '\0') {
      uVar4 = 0xffffffff;
      param_3 = (char *)0xffffffff;
      uVar10 = *(uint *)(param_1 + 0x5b8);
    }
    else {
      if (*(int *)(param_1 + 0x5b8) < 0) goto switchD_00c40b11_caseD_f;
      FUN_00c41790();
      iVar6 = *(int *)(param_1 + 0x5b8);
      if (*(int *)(param_1 + 0x55c) < *(int *)(param_1 + 0x5b8)) {
        iVar6 = *(int *)(param_1 + 0x55c);
      }
      FUN_00585b80(iVar6,param_3);
      piVar1 = (int *)(param_3 + 0x10);
      uVar4 = 0xffffffff;
      param_3 = (char *)0xffffffff;
      uVar10 = *piVar1 + *(int *)(param_1 + 0x5b8);
    }
    break;
  case 6:
    if (DAT_01d686d0 == '\0') {
      cVar2 = FUN_00c45d00();
      uVar5 = *(uint *)(param_1 + 0x5b8);
      if (cVar2 == '\0') {
        if ((int)uVar5 < 1) goto switchD_00c40b11_caseD_f;
        FUN_01543370(&uStack_1c,pppppppuVar7,uVar5 - 1);
        uVar4 = 0xffffffff;
        param_3 = (char *)0xffffffff;
        uVar10 = uStack_1c;
      }
      else {
        uVar4 = 0xffffffff;
        param_3 = (char *)0xffffffff;
        uVar10 = *(uint *)(param_1 + 0x5c0);
        if ((int)uVar5 <= (int)*(uint *)(param_1 + 0x5c0)) {
          uVar10 = uVar5;
        }
      }
    }
    else {
      iVar6 = *(int *)(param_1 + 0x5b8) + -1;
      if (iVar6 < 1) {
        iVar6 = 0;
      }
      FUN_01543370(&uStack_1c,pppppppuVar7,iVar6);
      uVar10 = uStack_1c;
      param_4 = (int *)uStack_1c;
      param_3 = (char *)0xffffffff;
      cVar2 = FUN_00c45d00();
      if (cStack_11 == '\0') {
        if (cVar2 != '\0') {
          param_4 = (int *)*(uint *)(param_1 + 0x5c0);
          if ((int)*(uint *)(param_1 + 0x5b8) <= (int)*(uint *)(param_1 + 0x5c0)) {
            param_4 = (int *)*(uint *)(param_1 + 0x5b8);
          }
        }
      }
      else if (cVar2 == '\0') {
        param_3 = *(char **)(param_1 + 0x5b8);
        if (param_3 == (char *)uVar10) {
          param_3 = (char *)0xffffffff;
        }
      }
      else {
        param_3 = *(char **)(param_1 + 0x5c0);
        if (param_3 == (char *)uVar10) {
          param_3 = (char *)0xffffffff;
        }
      }
      uVar10 = FUN_00d7f1a0(param_4);
      if ((int *)uVar10 == param_4) {
        if (param_4 < *(uint *)(param_1 + 0x55c)) {
          pppppppuVar3 = pppppppuVar7;
          if (0xf < *(uint *)(param_1 + 0x560)) {
            pppppppuVar3 = (undefined4 *******)*pppppppuVar7;
          }
          cVar2 = FUN_00c42480(*(undefined *)((int)pppppppuVar3 + (int)param_4));
          if (cVar2 != '\0') goto LAB_00c4115d;
        }
        uVar4 = *(undefined4 *)(param_1 + 0x494);
        FUN_00c44da0(param_4,param_3,0xffffffff);
        FUN_00d7f5f0(uVar4);
        goto switchD_00c40b11_caseD_f;
      }
LAB_00c4115d:
      uVar4 = 0xffffffff;
      uVar10 = (uint)param_4;
    }
    break;
  case 7:
    if (DAT_01d686d0 == '\0') {
      cVar2 = FUN_00c45d00();
      if (cVar2 == '\0') {
        if (*(uint *)(param_1 + 0x55c) <= *(uint *)(param_1 + 0x5b8)) goto switchD_00c40b11_caseD_f;
        FUN_01543370(&uStack_1c,pppppppuVar7,*(uint *)(param_1 + 0x5b8));
        uVar4 = 0xffffffff;
        param_3 = (char *)0xffffffff;
        uVar10 = iStack_18 + uStack_1c;
      }
      else {
        uVar4 = 0xffffffff;
        param_3 = (char *)0xffffffff;
        uVar10 = *(uint *)(param_1 + 0x5c0);
        if ((int)*(uint *)(param_1 + 0x5c0) <= (int)*(uint *)(param_1 + 0x5b8)) {
          uVar10 = *(uint *)(param_1 + 0x5b8);
        }
      }
    }
    else {
      FUN_01543370(&uStack_1c,pppppppuVar7,*(undefined4 *)(param_1 + 0x5b8));
      uVar10 = iStack_18 + uStack_1c;
      param_3 = (char *)0xffffffff;
      cVar2 = FUN_00c45d00();
      if (cStack_11 == '\0') {
        if (cVar2 != '\0') {
          uVar10 = *(uint *)(param_1 + 0x5c0);
          if ((int)*(uint *)(param_1 + 0x5c0) <= (int)*(uint *)(param_1 + 0x5b8)) {
            uVar10 = *(uint *)(param_1 + 0x5b8);
          }
        }
      }
      else if (cVar2 == '\0') {
        param_3 = *(char **)(param_1 + 0x5b8);
        if (param_3 == (char *)uVar10) {
          param_3 = (char *)0xffffffff;
        }
      }
      else {
        param_3 = *(char **)(param_1 + 0x5c0);
        if (param_3 == (char *)uVar10) {
          param_3 = (char *)0xffffffff;
        }
      }
      uVar5 = FUN_00d7f1a0(uVar10);
      if ((uVar10 == uVar5) && (uVar10 < *(uint *)(param_1 + 0x55c))) {
        pppppppuVar3 = pppppppuVar7;
        if (0xf < *(uint *)(param_1 + 0x560)) {
          pppppppuVar3 = (undefined4 *******)*pppppppuVar7;
        }
        cVar2 = FUN_00c42480(*(undefined *)((int)pppppppuVar3 + uVar10));
        uVar5 = (uint)(cVar2 == '\0');
      }
      else {
        uVar5 = 0;
      }
      uVar4 = FUN_00d7f080(uVar5 + uVar10);
    }
    break;
  case 8:
    uVar4 = 0xffffffff;
    param_3 = (char *)0x0;
    uVar10 = *(uint *)(param_1 + 0x55c);
    break;
  case 9:
    if (DAT_01d686d0 == '\0') {
      iVar6 = FUN_00d7f280(*(undefined4 *)(param_1 + 0x5b8));
      pppppppuVar3 = pppppppuVar7;
      if (0xf < *(uint *)(param_1 + 0x560)) {
        pppppppuVar3 = (undefined4 *******)*pppppppuVar7;
      }
      if ((*(char *)((int)pppppppuVar3 + iVar6) == ' ') ||
         (*(char *)((int)pppppppuVar3 + iVar6) == '\t')) {
        iVar6 = iVar6 + 1;
      }
LAB_00c40e30:
      FUN_01543370(&uStack_1c,pppppppuVar7,iVar6);
      uVar4 = 0xffffffff;
      param_3 = (char *)0xffffffff;
      uVar10 = uStack_1c;
      break;
    }
    uVar4 = FUN_00c41f60(param_1 + 0x408,pppppppuVar7);
    iVar6 = FUN_00d7f280(uVar4);
    pppppppuVar3 = pppppppuVar7;
    if (0xf < *(uint *)(param_1 + 0x560)) {
      pppppppuVar3 = (undefined4 *******)*pppppppuVar7;
    }
    if ((*(char *)((int)pppppppuVar3 + iVar6) == ' ') ||
       (*(char *)((int)pppppppuVar3 + iVar6) == '\t')) {
      iVar6 = iVar6 + 1;
    }
    FUN_01543370(&uStack_1c,pppppppuVar7,iVar6);
    param_3 = (char *)0xffffffff;
    if (cStack_11 != '\0') {
      cVar2 = FUN_00c45d00();
      if (cVar2 == '\0') {
        param_3 = (char *)uStack_1c;
        if ((int)uStack_1c < (int)*(uint *)(param_1 + 0x5b8)) {
          param_3 = (char *)*(uint *)(param_1 + 0x5b8);
        }
      }
      else {
        param_3 = (char *)*(uint *)(param_1 + 0x5c0);
      }
      if ((char *)uStack_1c == param_3) {
        param_3 = (char *)0xffffffff;
      }
    }
    goto LAB_00c40df8;
  case 10:
    if (DAT_01d686d0 == '\0') {
      iVar6 = FUN_00d7f1a0(*(undefined4 *)(param_1 + 0x5b8));
      goto LAB_00c40e30;
    }
    uVar4 = FUN_00c41f60(param_1 + 0x408,pppppppuVar7);
    uVar10 = FUN_00d7f1a0(uVar4);
    iVar6 = 0;
    if (uVar10 < *(uint *)(param_1 + 0x55c)) {
      pppppppuVar3 = pppppppuVar7;
      if (0xf < *(uint *)(param_1 + 0x560)) {
        pppppppuVar3 = (undefined4 *******)*pppppppuVar7;
      }
      cVar2 = FUN_00c42480(*(undefined *)((int)pppppppuVar3 + uVar10));
      uVar10 = extraout_ECX_01;
      iVar6 = extraout_EDX_00;
      if (cVar2 == '\0') {
        iVar6 = 1;
      }
    }
    FUN_01543370(&uStack_1c,pppppppuVar7,uVar10 - iVar6);
    param_3 = (char *)0xffffffff;
    if (cStack_11 != '\0') {
      cVar2 = FUN_00c45d00();
      if (cVar2 == '\0') {
        param_3 = (char *)uStack_1c;
        if ((int)*(uint *)(param_1 + 0x5b8) < (int)uStack_1c) {
          param_3 = (char *)*(uint *)(param_1 + 0x5b8);
        }
      }
      else {
        param_3 = (char *)*(uint *)(param_1 + 0x5c0);
      }
      if ((char *)uStack_1c == param_3) {
        param_3 = (char *)0xffffffff;
      }
    }
    uVar4 = FUN_00d7f080(uVar4);
    uVar10 = uStack_1c;
    break;
  case 0xb:
    uVar10 = *(uint *)(param_1 + 0x5b8);
    uVar5 = *(uint *)(param_1 + 0x55c);
    if (uVar10 < uVar5) {
      do {
        pppppppuVar3 = pppppppuVar7;
        if (0xf < *(uint *)(param_1 + 0x560)) {
          pppppppuVar3 = (undefined4 *******)*pppppppuVar7;
        }
        cVar2 = *(char *)((int)pppppppuVar3 + uVar10);
      } while (((cVar2 != ' ') && (cVar2 != '\t')) &&
              ((cVar2 != '\n' && (uVar10 = uVar10 + 1, uVar10 < uVar5))));
      if (uVar10 < uVar5) {
        do {
          pppppppuVar3 = pppppppuVar7;
          if (0xf < *(uint *)(param_1 + 0x560)) {
            pppppppuVar3 = (undefined4 *******)*pppppppuVar7;
          }
          cVar2 = *(char *)((int)pppppppuVar3 + uVar10);
        } while ((((cVar2 == ' ') || (cVar2 == '\t')) || (cVar2 == '\n')) &&
                (uVar10 = uVar10 + 1, uVar10 < uVar5));
      }
    }
    goto LAB_00c40f67;
  case 0xc:
    uVar10 = *(int *)(param_1 + 0x5b8) - 1;
    if ((int)uVar10 < 0) {
LAB_00c41022:
      uVar10 = uVar10 + 1;
    }
    else {
      uVar5 = uVar10;
      do {
        uVar10 = uVar5;
        pppppppuVar3 = pppppppuVar7;
        if (0xf < *(uint *)(param_1 + 0x560)) {
          pppppppuVar3 = (undefined4 *******)*pppppppuVar7;
        }
        cVar2 = *(char *)((int)pppppppuVar3 + uVar10);
        if (((cVar2 != ' ') && (cVar2 != '\t')) && (cVar2 != '\n')) goto joined_r0x00c41000;
        uVar5 = uVar10 - 1;
      } while (-1 < (int)(uVar10 - 1));
    }
LAB_00c40f67:
    FUN_01543370(&uStack_1c,pppppppuVar7,uVar10);
    if (DAT_01d686d0 == '\0') {
LAB_00c40c5e:
      uVar4 = 0xffffffff;
      param_3 = (char *)0xffffffff;
      uVar10 = uStack_1c;
    }
    else {
      param_3 = (char *)0xffffffff;
      if (cStack_11 == '\0') {
LAB_00c40fbf:
        uVar4 = *(undefined4 *)(param_1 + 0x5b8);
      }
      else {
        cVar2 = FUN_00c45d00();
        if (cVar2 == '\0') {
          param_3 = *(char **)(param_1 + 0x5b8);
          if ((char *)uStack_1c == param_3) {
            param_3 = (char *)0xffffffff;
          }
          goto LAB_00c40fbf;
        }
        param_3 = *(char **)(param_1 + 0x5c0);
        uVar4 = *(undefined4 *)(param_1 + 0x5b8);
        if ((char *)uStack_1c == param_3) {
          param_3 = (char *)0xffffffff;
        }
      }
LAB_00c40df8:
      uVar4 = FUN_00d7f080(uVar4);
      uVar10 = uStack_1c;
    }
    break;
  case 0xd:
    if (DAT_01d686d0 == '\0') goto switchD_00c40b11_caseD_f;
    param_3 = (char *)0xffffffff;
    if (cStack_11 != '\0') {
      cVar2 = FUN_00c45d00();
      if (cVar2 != '\0') {
        param_3 = *(char **)(param_1 + 0x5c0);
        uVar4 = 0xffffffff;
        uVar10 = 0;
        break;
      }
      param_3 = *(char **)(param_1 + 0x5b8);
    }
    uVar4 = 0xffffffff;
    uVar10 = 0;
    break;
  case 0xe:
    if (DAT_01d686d0 == '\0') goto switchD_00c40b11_caseD_f;
    uVar4 = FUN_00d7f1a0(0x7fffffff);
    FUN_01543370(&uStack_1c,pppppppuVar7,uVar4);
    param_3 = (char *)0xffffffff;
    if (cStack_11 != '\0') {
      cVar2 = FUN_00c45d00();
      if (cVar2 != '\0') {
        param_3 = *(char **)(param_1 + 0x5c0);
        uVar4 = 0xffffffff;
        uVar10 = uStack_1c;
        break;
      }
      param_3 = *(char **)(param_1 + 0x5b8);
    }
    uVar4 = 0xffffffff;
    uVar10 = uStack_1c;
    break;
  default:
    goto switchD_00c40b11_caseD_f;
  }
LAB_00c4146f:
  FUN_00c44da0(uVar10,param_3,uVar4);
switchD_00c40b11_caseD_f:
  FUN_016830f0(&uStack_1c);
  if (*(char *)(param_1 + 0x549) != '\x01') {
    *(undefined *)(param_1 + 0x549) = 1;
    iVar6 = FUN_00817fa0();
    if (iVar6 != 0) {
      FUN_00d66da0();
    }
  }
  *(uint *)(param_1 + 0x598) = uStack_1c;
  *(int *)(param_1 + 0x59c) = iStack_18;
  if (*(char *)(param_1 + 0x5a5) == '\0') {
    if (pppppppuVar7 != appppppuStack_4c) {
      pppppppuVar7 = appppppuStack_4c;
      if (0xf < uStack_38) {
        pppppppuVar7 = (undefined4 *******)appppppuStack_4c[0];
      }
      FUN_005542c0(pppppppuVar7,uStack_3c);
    }
  }
  else {
    pppppppuVar3 = pppppppuVar7;
    if (0xf < *(uint *)(param_1 + 0x560)) {
      pppppppuVar3 = (undefined4 *******)*pppppppuVar7;
    }
    pppppppuVar8 = appppppuStack_4c;
    if (0xf < uStack_38) {
      pppppppuVar8 = (undefined4 *******)appppppuStack_4c[0];
    }
    cVar2 = FUN_0055c360(pppppppuVar8,uStack_3c,pppppppuVar3,*(undefined4 *)(param_1 + 0x55c));
    if (cVar2 == '\0') {
      FUN_0054ef60(pppppppuVar7);
      FUN_00fac790();
    }
  }
  if (0xf < uStack_38) {
    uVar10 = uStack_38 + 1;
    pppppppuVar7 = (undefined4 *******)appppppuStack_4c[0];
    if (0xfff < uVar10) {
      pppppppuVar7 = (undefined4 *******)((undefined4 *******)appppppuStack_4c[0])[-1];
      uVar10 = uStack_38 + 0x24;
      if (0x1f < (uint)((int)appppppuStack_4c[0] + (-4 - (int)pppppppuVar7))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppppuVar7,uVar10);
  }
  ExceptionList = pvStack_10;
  return;
joined_r0x00c41000:
  if ((int)uVar10 < 0) goto LAB_00c41022;
  pppppppuVar3 = pppppppuVar7;
  if (0xf < *(uint *)(param_1 + 0x560)) {
    pppppppuVar3 = (undefined4 *******)*pppppppuVar7;
  }
  cVar2 = *(char *)((int)pppppppuVar3 + uVar10);
  if (((cVar2 == ' ') || (cVar2 == '\t')) || (cVar2 == '\n')) goto LAB_00c41022;
  uVar10 = uVar10 - 1;
  goto joined_r0x00c41000;
joined_r0x00c40bd2:
  if ((int)uVar10 < 0) goto LAB_00c40ba2;
  pppppppuVar3 = pppppppuVar7;
  if (0xf < uVar5) {
    pppppppuVar3 = (undefined4 *******)*pppppppuVar7;
  }
  cVar2 = FUN_00c42480(*(undefined *)((int)pppppppuVar3 + uVar10));
  if (cVar2 != '\0') {
    if (-1 < (int)uVar10) {
      if (uVar10 == extraout_EDX) goto switchD_00c40b11_caseD_f;
      uVar4 = FUN_00554db0(uVar10,extraout_EDX - uVar10);
      FUN_00551230(uVar4);
      uVar4 = 0xffffffff;
      param_3 = (char *)0xffffffff;
      goto LAB_00c4146f;
    }
    goto LAB_00c40ba2;
  }
  uVar10 = uVar10 - 1;
  uVar5 = extraout_ECX_00;
  goto joined_r0x00c40bd2;
}



/* FUNCTION 28231 ; VA 0x00c415a0 ; FUN_00c415a0 */

void FUN_00c415a0(undefined4 param_1,undefined param_2,undefined4 param_3)

{
  uint uVar1;
  uint uVar2;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_14 = 0xf;
  uStack_18 = 1;
  auStack_28[0] = CONCAT31((int3)(auStack_28[0] >> 8),param_2) & 0xffff00ff;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00c40a80(param_1,auStack_28,param_3);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    uVar1 = auStack_28[0];
    if (0xfff < uVar2) {
      uVar1 = *(uint *)(auStack_28[0] - 4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar1) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 28232 ; VA 0x00c41640 ; FUN_00c41640 */

void FUN_00c41640(int param_1,char *param_2,undefined4 param_3,undefined4 param_4)

{
  uint *puVar1;
  int iVar2;
  char cVar3;
  byte bVar4;
  undefined4 uVar5;
  int iVar6;
  byte bVar7;
  char *pcVar8;
  uint uVar9;
  uint uVar10;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  uint uStack_8;
  
  iVar2 = *(int *)(param_1 + 0x18);
  cVar3 = FUN_00c401e0(iVar2);
  if (cVar3 != '\0') {
    uStack_c = 0;
    uStack_8 = 0xf;
    uStack_1c = uStack_1c & 0xffffff00;
    pcVar8 = param_2;
    do {
      cVar3 = *pcVar8;
      pcVar8 = pcVar8 + 1;
    } while (cVar3 != '\0');
    FUN_005542c0(param_2,(int)pcVar8 - (int)(param_2 + 1));
    puVar1 = (uint *)(iVar2 + 0x54c);
    if (puVar1 == &uStack_1c) {
      if (0xf < uStack_8) {
        uVar10 = uStack_8 + 1;
        uVar9 = uStack_1c;
        if (0xfff < uVar10) {
          uVar9 = *(uint *)(uStack_1c - 4);
          uVar10 = uStack_8 + 0x24;
          if (0x1f < (uStack_1c - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar9,uVar10);
      }
    }
    else {
      FUN_005507b0();
      *puVar1 = uStack_1c;
      *(undefined4 *)(iVar2 + 0x550) = uStack_18;
      *(undefined4 *)(iVar2 + 0x554) = uStack_14;
      *(undefined4 *)(iVar2 + 0x558) = uStack_10;
      *(ulonglong *)(iVar2 + 0x55c) = CONCAT44(uStack_8,uStack_c);
    }
    FUN_0054ef60(puVar1);
    FUN_00fac790();
    uVar5 = FUN_0097bf90(iVar2);
    iVar6 = FUN_009ba880(uVar5);
    if (iVar6 != 0) {
      bVar4 = FUN_01679ce0();
      bVar7 = 1;
      if ((bVar4 & 0x7f) != 0) {
        bVar7 = bVar4 & 0x7f;
      }
      *(byte *)(iVar6 + 0x224) = -bVar7;
    }
    FUN_00c40130(iVar2,0);
    FUN_00fad240();
    if (*(char *)(iVar2 + 0x549) != '\0') {
      *(undefined *)(iVar2 + 0x549) = 0;
      iVar6 = FUN_00817fa0();
      if (iVar6 != 0) {
        FUN_00d66da0();
      }
    }
    *(undefined4 *)(iVar2 + 0x5e0) = 0;
    FUN_00c44ec0(param_3,param_4);
  }
  return;
}



/* FUNCTION 28233 ; VA 0x00c41790 ; FUN_00c41790 */

undefined4 __fastcall FUN_00c41790(int param_1)

{
  uint uVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  
  uVar1 = *(uint *)(param_1 + 0x5b8);
  if ((uVar1 == 0xffffffff) || (uVar7 = *(uint *)(param_1 + 0x5c0), uVar7 == 0xffffffff)) {
    return 0;
  }
  puVar4 = (undefined4 *)(param_1 + 0x54c);
  uVar5 = uVar7;
  if ((int)uVar7 <= (int)uVar1) {
    uVar5 = uVar1;
  }
  if ((int)uVar1 <= (int)uVar7) {
    uVar7 = uVar1;
  }
  uVar1 = *(uint *)(param_1 + 0x55c);
  if (uVar7 <= uVar1) {
    uVar6 = uVar5 - uVar7;
    if (uVar1 - uVar7 < uVar5 - uVar7) {
      uVar6 = uVar1 - uVar7;
    }
    if (0xf < *(uint *)(param_1 + 0x560)) {
      puVar4 = (undefined4 *)*puVar4;
    }
    *(uint *)(param_1 + 0x55c) = uVar1 - uVar6;
    FUN_0170cc70((int)puVar4 + uVar7,(int)puVar4 + uVar7 + uVar6,((uVar1 - uVar6) - uVar7) + 1);
    FUN_00c44da0(uVar7,0xffffffff,0xffffffff);
    return 1;
  }
  FUN_00554050();
  pcVar2 = (code *)swi(3);
  uVar3 = (*pcVar2)();
  return uVar3;
}



/* FUNCTION 28234 ; VA 0x00c41820 ; FUN_00c41820 */

uint FUN_00c41820(uint param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  if (param_1 < (uint)param_2[4]) {
    while( true ) {
      puVar1 = param_2;
      if (0xf < (uint)param_2[5]) {
        puVar1 = (undefined4 *)*param_2;
      }
      if (*(char *)((int)puVar1 + param_1) == '\n') break;
      param_1 = param_1 + 1;
      if ((uint)param_2[4] <= param_1) {
        return param_1;
      }
    }
    param_1 = param_1 + 1;
  }
  return param_1;
}



/* FUNCTION 28235 ; VA 0x00c41860 ; FUN_00c41860 */

void FUN_00c41860(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  if (param_1 != 0) {
    do {
      puVar1 = param_2;
      if (0xf < (uint)param_2[5]) {
        puVar1 = (undefined4 *)*param_2;
      }
    } while ((*(char *)((int)puVar1 + param_1 + -1) != '\n') &&
            (param_1 = param_1 + -1, param_1 != 0));
  }
  return;
}



/* FUNCTION 28236 ; VA 0x00c41890 ; FUN_00c41890 */

void FUN_00c41890(uint param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  char cVar3;
  
  if (param_1 < (uint)param_2[4]) {
    puVar2 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar2 = (undefined4 *)*param_2;
    }
    cVar3 = *(char *)((int)puVar2 + param_1);
    if (((cVar3 == ' ') || (cVar3 == '\t')) || (cVar3 == '\n')) {
      cVar3 = '\x01';
    }
    else {
      cVar3 = '\0';
    }
    do {
      puVar2 = param_2;
      if (0xf < (uint)param_2[5]) {
        puVar2 = (undefined4 *)*param_2;
      }
      cVar1 = *(char *)((int)puVar2 + param_1);
      if (((cVar1 == ' ') || (cVar1 == '\t')) || (cVar1 == '\n')) {
        cVar1 = '\x01';
      }
      else {
        cVar1 = '\0';
      }
    } while ((cVar1 == cVar3) && (param_1 = param_1 + 1, param_1 < (uint)param_2[4]));
  }
  return;
}



/* FUNCTION 28237 ; VA 0x00c41900 ; FUN_00c41900 */

uint FUN_00c41900(uint param_1,undefined4 *param_2)

{
  uint uVar1;
  uint uVar2;
  char cVar3;
  char cVar4;
  undefined4 *puVar5;
  
  uVar1 = param_2[4];
  if (uVar1 == 0) {
    return uVar1;
  }
  uVar2 = param_2[5];
  if (param_1 < uVar1) {
    puVar5 = param_2;
    if (0xf < uVar2) {
      puVar5 = (undefined4 *)*param_2;
    }
    cVar3 = *(char *)((int)puVar5 + param_1);
  }
  else {
    puVar5 = param_2;
    if (0xf < uVar2) {
      puVar5 = (undefined4 *)*param_2;
    }
    cVar3 = *(char *)((int)puVar5 + (uVar1 - 1));
  }
  if (((cVar3 == ' ') || (cVar3 == '\t')) || (cVar3 == '\n')) {
    cVar3 = '\x01';
  }
  else {
    cVar3 = '\0';
  }
  if (param_1 != 0) {
    do {
      puVar5 = param_2;
      if (0xf < uVar2) {
        puVar5 = (undefined4 *)*param_2;
      }
      cVar4 = *(char *)((int)puVar5 + (param_1 - 1));
      if (((cVar4 == ' ') || (cVar4 == '\t')) || (cVar4 == '\n')) {
        cVar4 = '\x01';
      }
      else {
        cVar4 = '\0';
      }
    } while ((cVar4 == cVar3) && (param_1 = param_1 - 1, param_1 != 0));
  }
  return param_1;
}



/* FUNCTION 28238 ; VA 0x00c41980 ; FUN_00c41980 */

void FUN_00c41980(undefined4 param_1,int *param_2)

{
  undefined uVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  piVar2 = (int *)*param_2;
  iVar7 = *piVar2;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088daf0();
  if (iVar7 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  piVar4 = piVar2 + 2;
  iVar7 = *param_2;
  if (piVar2[1] == 0) {
    piVar4 = (int *)0x0;
  }
  iVar3 = *(int *)(iVar7 + 0xd0);
  uVar1 = *(undefined *)piVar4;
  iVar5 = FUN_0088cdc0();
  if (iVar3 == iVar5) {
    puVar6 = (undefined4 *)(iVar7 + 0xd8);
    if (*(int *)(iVar7 + 0xd4) == 0) {
      puVar6 = (undefined4 *)0x0;
    }
    iVar7 = puVar6[1];
    if (iVar7 != 0) {
      LOCK();
      *(int *)(iVar7 + 4) = *(int *)(iVar7 + 4) + 1;
      UNLOCK();
      iVar7 = puVar6[1];
    }
    uStack_8 = 0;
    FUN_009a5dd0(CONCAT31((int3)((uint)piVar4 >> 8),uVar1),*puVar6,iVar7);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 28239 ; VA 0x00c41a50 ; FUN_00c41a50 */

undefined4 __thiscall FUN_00c41a50(int param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  byte bVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 *puVar9;
  byte bVar10;
  undefined4 uVar11;
  undefined auStack_40 [24];
  undefined auStack_28 [8];
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018099d0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar5 = *(int *)(param_1 + 0x34);
    iVar4 = param_1;
    ExceptionList = &pvStack_10;
    if ((iVar5 != 0) && (iVar4 = iVar5, ExceptionList = &pvStack_10, *(int *)(iVar5 + 0x34) != 0)) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_005c8ac0();
    }
    if (((iVar4 != 0) &&
        (iVar5 = *(int *)(iVar4 + 0xc), iVar4 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar4 + 0x1d8) <=
        (uint)*(ushort *)(iVar4 + 0x1da))) && (iVar5 = FUN_00634d90(), iVar5 != 0)) {
      FUN_00d5c590(auStack_40);
      uStack_8 = 0;
      piVar6 = (int *)FUN_00b82590(&uStack_18,auStack_40);
      iVar5 = *piVar6;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if ((iVar5 == 0) ||
         (iVar4 = *(int *)(iVar5 + 0xc), iVar7 = FUN_00c3ebd0(),
         (uint)*(ushort *)(iVar7 + 0x1da) <
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8))) {
        iVar5 = 0;
      }
      piVar6 = piStack_14;
      uStack_8 = uStack_8 & 0xffffff00;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_14[1] + -1;
        piStack_14[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_14)();
          LOCK();
          piVar1 = piVar6 + 2;
          iVar4 = *piVar1 + -1;
          *piVar1 = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      if (((iVar5 != 0) && (iVar5 != param_1)) && (*(char *)(iVar5 + 0x5a1) != '\0')) {
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return 0;
      }
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
  }
  cVar2 = FUN_00c401e0(param_1);
  if (cVar2 != '\0') {
    ExceptionList = pvStack_10;
    return 0;
  }
  FUN_00c40130(param_1,param_1);
  FUN_00fab480(0);
  FUN_00fad240();
  if (*(char *)(param_1 + 0x54a) == '\0') {
    iVar5 = *param_2;
    if ((iVar5 != 0) &&
       (((*(int *)(iVar5 + 0x5c) == 0 && (*(int *)(iVar5 + 0x54) == 0)) ||
        (*(int *)(iVar5 + 0x54) == 7)))) {
      if (DAT_01d686d0 == '\0') {
        puVar9 = (undefined4 *)FUN_00d814c0(auStack_20);
        piVar6 = (int *)0xffffffff;
        uVar11 = 0xffffffff;
        uVar8 = FUN_00c41ee0(*puVar9,puVar9[1]);
      }
      else {
        uVar8 = FUN_00d814c0(auStack_20);
        FUN_00c41e50(&uStack_18,uVar8);
        uVar11 = 0xffffffff;
        uVar8 = uStack_18;
        piVar6 = piStack_14;
      }
      FUN_00c44da0(uVar8,uVar11,piVar6);
      if (*(int *)(param_1 + 0x5b8) != -1) {
        FUN_0088ddf0(param_2);
      }
      goto LAB_00c41bfc;
    }
  }
  else {
    FUN_005542c0(&DAT_018bc9b8,0);
    FUN_0054ef60(param_1 + 0x54c);
    FUN_00fac790();
  }
  FUN_00c44da0(*(undefined4 *)(param_1 + 0x55c),0xffffffff,0xffffffff);
LAB_00c41bfc:
  FUN_016830f0(&uStack_18);
  if (*(char *)(param_1 + 0x549) != '\x01') {
    *(undefined *)(param_1 + 0x549) = 1;
    iVar5 = FUN_00817fa0();
    if (iVar5 != 0) {
      FUN_00d66da0();
    }
  }
  *(undefined4 *)(param_1 + 0x598) = uStack_18;
  *(int **)(param_1 + 0x59c) = piStack_14;
  *(undefined4 *)(param_1 + 0x5e0) = 0;
  uVar8 = FUN_0097bf90(param_1);
  iVar5 = FUN_009ba880(uVar8);
  if (iVar5 != 0) {
    bVar3 = FUN_01679ce0();
    bVar10 = 1;
    if ((bVar3 & 0x7f) != 0) {
      bVar10 = bVar3 & 0x7f;
    }
    *(byte *)(iVar5 + 0x224) = bVar10;
  }
  iVar5 = FUN_008f7870(param_1);
  if (iVar5 != 0) {
    puVar9 = (undefined4 *)FUN_0060dcd0(auStack_20,param_1);
    uStack_8 = 2;
    uVar8 = *puVar9;
    uVar11 = puVar9[1];
    *puVar9 = 0;
    puVar9[1] = 0;
    FUN_0090ae80(uVar8,uVar11);
    uStack_8 = 0xffffffff;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar6 = piStack_1c + 2;
        iVar4 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
    *(undefined *)(iVar5 + 0x344) = 1;
  }
  FUN_006eccd0();
  iVar5 = FUN_009169f0(param_1);
  if ((iVar5 != 0) && (cVar2 = FUN_00d5c860(), cVar2 != '\0')) {
    puVar9 = (undefined4 *)FUN_0060dcd0(auStack_28,param_1);
    uStack_8 = 3;
    uVar8 = *puVar9;
    uVar11 = puVar9[1];
    *puVar9 = 0;
    puVar9[1] = 0;
    FUN_0089be10(uVar8,uVar11);
    FUN_00550b30();
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 28240 ; VA 0x00c41e20 ; FUN_00c41e20 */

void FUN_00c41e20(void)

{
  int iVar1;
  
  if (DAT_01efc7f4 == 0) {
    iVar1 = FUN_00c3ebd0();
    DAT_01efc7f4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 28241 ; VA 0x00c41e50 ; FUN_00c41e50 */

int * __thiscall FUN_00c41e50(int param_1,int *param_2,float *param_3)

{
  int *piVar1;
  bool bVar2;
  float fVar3;
  float afStack_14 [2];
  float afStack_c [2];
  
  bVar2 = DAT_01d686d0 != '\0';
  *param_2 = -1;
  param_2[1] = -1;
  if (bVar2) {
    if (*(int *)(param_1 + 900) != 0) {
      piVar1 = (int *)FUN_00fa76a0(afStack_c,param_3);
      *param_2 = *piVar1;
      param_2[1] = piVar1[1];
      if (-1 < *param_2) {
        return param_2;
      }
    }
    FUN_00d5c5d0(afStack_14);
    fVar3 = (afStack_c[0] + afStack_14[0]) * DAT_018ce2f4;
    if (*param_3 <= fVar3 && fVar3 != *param_3) {
      *param_2 = 0;
      return param_2;
    }
    *param_2 = *(int *)(param_1 + 0x55c);
  }
  return param_2;
}



/* FUNCTION 28242 ; VA 0x00c41ee0 ; FUN_00c41ee0 */

float __thiscall FUN_00c41ee0(int param_1,float param_2,undefined4 param_3)

{
  float fVar1;
  float afStack_14 [2];
  float afStack_c [2];
  
  if (DAT_01d686d0 != '\0') {
    FUN_00c41e50(afStack_c,&param_2);
    return afStack_c[0];
  }
  if ((*(int *)(param_1 + 900) != 0) &&
     (fVar1 = (float)FUN_00fa7890(param_2,param_3), -1 < (int)fVar1)) {
    return fVar1;
  }
  FUN_00d5c5d0(afStack_14);
  if ((afStack_14[0] + afStack_c[0]) * DAT_018ce2f4 <= param_2) {
    return *(float *)(param_1 + 0x55c);
  }
  return 0.0;
}



/* FUNCTION 28243 ; VA 0x00c41f60 ; FUN_00c41f60 */

int FUN_00c41f60(int param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  int iStack_c;
  int iStack_8;
  
  iVar1 = FUN_00d7f080(param_3);
  if ((*(int *)(param_1 + 0x8c) != -1) && (iVar1 != *(int *)(param_1 + 0x8c))) {
    FUN_01543370(&iStack_c,param_2,param_3);
    return iStack_8 + iStack_c;
  }
  return param_3;
}



/* FUNCTION 28244 ; VA 0x00c42000 ; FUN_00c42000 */

float10 __fastcall FUN_00c42000(int param_1)

{
  return (float10)*(int *)(param_1 + 0x3c4);
}



/* FUNCTION 28245 ; VA 0x00c42020 ; FUN_00c42020 */

uint __fastcall FUN_00c42020(int param_1)

{
  return param_1 + 0x348U & -(uint)(param_1 != 0);
}



/* FUNCTION 28246 ; VA 0x00c42070 ; FUN_00c42070 */

void __thiscall FUN_00c42070(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x62c);
  *param_2 = *(undefined8 *)(param_1 + 0x624);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 28247 ; VA 0x00c420e0 ; FUN_00c420e0 */

void __thiscall FUN_00c420e0(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x3d0);
  *param_2 = *(undefined8 *)(param_1 + 0x3c8);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 28248 ; VA 0x00c42100 ; FUN_00c42100 */

undefined4 __thiscall FUN_00c42100(int param_1,undefined4 param_2)

{
  FUN_00c987e0(param_2,*(undefined8 *)(param_1 + 0x3c8),*(undefined4 *)(param_1 + 0x3d0));
  return param_2;
}



/* FUNCTION 28249 ; VA 0x00c42160 ; FUN_00c42160 */

void __thiscall FUN_00c42160(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x3e0);
  *param_2 = *(undefined8 *)(param_1 + 0x3d8);
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}


