/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 23000 ; VA 0x00b00c70 ; FUN_00b00c70 */

undefined4 * __thiscall
FUN_00b00c70(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined auStack_100 [216];
  undefined8 uStack_28;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed1a1;
  pvStack_10 = ExceptionList;
  uStack_28 = param_2;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  uVar1 = FUN_00aff8c0();
  FUN_009cb970(uVar1,param_4,param_6,param_7,param_8);
  *(undefined8 *)(param_1 + 0xe) = uStack_28;
  param_1[0x10] = param_3;
  iStack_8 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::PartInstance,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_RBX::PartInstance::LocalTouchedSignal,class_RBX::PartInstance::LocalTouchedSignal*_(__thiscall_RBX::PartInstance::*)(bool)>
             ::vftable;
  FUN_0086e3d0(param_5);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_100,&uStack_28,param_6);
  iStack_8._0_1_ = 2;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = uStack_1c;
    param_1[0xb] = uStack_18;
    param_1[0xc] = uStack_14;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_100,0xd8,1,FUN_00688b10);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23001 ; VA 0x00b00db0 ; FUN_00b00db0 */

undefined4 * __thiscall
FUN_00b00db0(undefined4 *param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined auStack_100 [216];
  undefined8 uStack_28;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed1d1;
  pvStack_10 = ExceptionList;
  uStack_28 = param_2;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  uVar1 = FUN_00aff8c0();
  FUN_009cb970(uVar1,param_4,param_6,param_7,param_8);
  *(undefined8 *)(param_1 + 0xe) = uStack_28;
  param_1[0x10] = param_3;
  iStack_8 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::PartInstance,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_RBX::PartInstance::TouchedSignal,class_RBX::PartInstance::TouchedSignal*_(__thiscall_RBX::PartInstance::*)(bool)>
             ::vftable;
  FUN_0086e3d0(param_5);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_100,&uStack_28,param_6);
  iStack_8._0_1_ = 2;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = uStack_1c;
    param_1[0xb] = uStack_18;
    param_1[0xc] = uStack_14;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_100,0xd8,1,FUN_00688b10);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23002 ; VA 0x00b00ef0 ; FUN_00b00ef0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b00ef0(undefined4 *param_1,undefined4 param_2,int param_3)

{
  undefined4 uVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed299;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[0x15] = &DAT_0194e5e4;
    param_1[0x26] = &DAT_0194e5ec;
    param_1[0x3f] = RBX::IHasLocation::vftable;
    uStack_8 = 0;
  }
  FUN_00e70430(&DAT_0194e40c,0);
  *param_1 = RBX::Described<class_RBX::PartInstance,class_RBX::PVInstance>::vftable;
  uStack_8 = 1;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::Described<class_RBX::PartInstance,class_RBX::PVInstance>::vftable;
  uVar1 = FUN_00aff8c0();
  param_1[3] = uVar1;
  uStack_8 = 2;
  FUN_00c3e1d0();
  param_1[0x1e] = RBX::IAdornable::vftable;
  param_1[0x1f] = 0xffffffff;
  param_1[0x20] = 0xffffffff;
  param_1[0x21] = 0xffffffff;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = RBX::CameraSubject::vftable;
  *(undefined ***)(*(int *)(param_1[0x26] + 4) + 0x98 + (int)param_1) = RBX::CameraSubject::vftable;
  LOCK();
  _DAT_01eedc58 = _DAT_01eedc58 + 1;
  UNLOCK();
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  *param_1 = RBX::PartInstance::vftable;
  param_1[0x16] = RBX::PartInstance::vftable;
  param_1[0x1e] = RBX::PartInstance::vftable;
  param_1[0x25] = RBX::PartInstance::vftable;
  uStack_8._0_1_ = 7;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) = RBX::PartInstance::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xa8;
  iVar2 = FUN_01674e20(0x240);
  uStack_8._0_1_ = 8;
  if (iVar2 == 0) {
    uVar1 = 0;
  }
  else {
    uVar1 = FUN_00c130d0(3);
  }
  param_1[0x2a] = uVar1;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  *(undefined8 *)(param_1 + 0x2e) = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = &DAT_01a5a2a3;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  *(undefined2 *)(param_1 + 0x3a) = 0x101;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  if (DAT_01ee41fb != '\0') {
    FUN_01677490(DAT_01ee41fb,"PartInstance created: %p, primitive: %p",param_1,param_1[0x2a],0);
  }
  FUN_00c19160(1,3);
  FUN_00c19160(4,4);
  FUN_00c18e20(param_2);
  FUN_00c183c0(0x3e99999a);
  FUN_00c182b0(0x3f000000);
  FUN_00c180b0(0);
  FUN_00c18df0(0);
  FUN_00c185e0(param_1 + 0x16);
  FUN_00c18480(param_1 + 6);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23003 ; VA 0x00b011f0 ; FUN_00b011f0 */

undefined4 * __fastcall FUN_00b011f0(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0xbf000000;
  param_1[2] = 0x3f000000;
  return param_1;
}



/* FUNCTION 23004 ; VA 0x00b01210 ; FUN_00b01210 */

uint * __thiscall FUN_00b01210(uint *param_1,uint *param_2,undefined4 param_3)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  undefined auStack_1c [4];
  int *piStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed2c3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uVar2 = *param_2;
  puStack_14 = param_1;
  if (uVar2 != 0) {
    *param_1 = uVar2;
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_2 + 2,param_1 + 2,0);
    }
    else {
      uVar2 = param_2[3];
      uVar4 = param_2[4];
      uVar5 = param_2[5];
      param_1[2] = param_2[2];
      param_1[3] = uVar2;
      param_1[4] = uVar4;
      param_1[5] = uVar5;
      *(undefined8 *)(param_1 + 6) = *(undefined8 *)(param_2 + 6);
    }
  }
  uStack_8 = 0;
  puVar6 = (uint *)FUN_0060dcd0(auStack_1c,param_3);
  param_1[8] = 0;
  param_1[9] = 0;
  if (puVar6[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar6[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[8] = *puVar6;
  param_1[9] = puVar6[1];
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar3 = piStack_18[2] + -1;
      piStack_18[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if ((DAT_01d69070 != '\0') || (DAT_01d66be0 != '\0')) {
    FUN_00b08fb0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23005 ; VA 0x00b01310 ; FUN_00b01310 */

void __fastcall FUN_00b01310(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  iVar1 = *(int *)(param_1 + 0x44);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8d0();
  return;
}



/* FUNCTION 23006 ; VA 0x00b01380 ; FUN_00b01380 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00b01380(void)

{
  LOCK();
  _DAT_01eedc58 = _DAT_01eedc58 + -1;
  UNLOCK();
  return;
}



/* FUNCTION 23007 ; VA 0x00b01390 ; thunk_FUN_00e704a0 */

void __fastcall thunk_FUN_00e704a0(undefined4 *param_1)

{
  *param_1 = RBX::PVInstance::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) = RBX::PVInstance::vftable;
  FUN_0089b230();
  return;
}



/* FUNCTION 23008 ; VA 0x00b013a0 ; FUN_00b013a0 */

void __fastcall FUN_00b013a0(int *param_1)

{
  if (param_1[1] != 0) {
    if ((int *)param_1[2] != (int *)0x0) {
      *(int *)param_1[2] = *param_1;
    }
    if (*param_1 != 0) {
      *(int *)(*param_1 + 0xa4) = param_1[2];
    }
    *(int *)param_1[1] = *(int *)param_1[1] + -1;
    *param_1 = 0;
    param_1[2] = 0;
    param_1[1] = 0;
  }
  return;
}



/* FUNCTION 23009 ; VA 0x00b013e0 ; FUN_00b013e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00b013e0(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::PartInstance::vftable;
  param_1[0x16] = RBX::PartInstance::vftable;
  param_1[0x1e] = RBX::PartInstance::vftable;
  param_1[0x25] = RBX::PartInstance::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) = RBX::PartInstance::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xa8;
  if (DAT_01ee41fb != '\0') {
    FUN_01677490(DAT_01ee41fb,"PartInstance destroyed: %p, primitive: %p",param_1,param_1[0x2a],0);
  }
  FUN_016790b0();
  piVar2 = (int *)param_1[0x37];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = (int *)param_1[0x31];
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  if ((undefined4 *)param_1[0x2a] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x2a])(1);
  }
  if (param_1[0x28] != 0) {
    if ((undefined4 *)param_1[0x29] != (undefined4 *)0x0) {
      *(undefined4 *)param_1[0x29] = param_1[0x27];
    }
    if (param_1[0x27] != 0) {
      *(undefined4 *)(param_1[0x27] + 0xa4) = param_1[0x29];
    }
    *(int *)param_1[0x28] = *(int *)param_1[0x28] + -1;
    param_1[0x27] = 0;
    param_1[0x29] = 0;
    param_1[0x28] = 0;
  }
  LOCK();
  _DAT_01eedc58 = _DAT_01eedc58 + -1;
  UNLOCK();
  param_1[0x25] = RBX::CameraSubject::vftable;
  *(undefined ***)(*(int *)(param_1[0x26] + 4) + 0x98 + (int)param_1) = RBX::CameraSubject::vftable;
  FUN_0115a710();
  FUN_00c3e200();
  FUN_00e704a0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23010 ; VA 0x00b01550 ; FUN_00b01550 */

void __fastcall FUN_00b01550(uint *param_1)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  if ((DAT_01d69070 != '\0') || (ExceptionList = &pvStack_10, DAT_01d66be0 != '\0')) {
    ExceptionList = &pvStack_10;
    FUN_00587490(&iStack_18);
    if (iStack_18 != 0) {
      iVar4 = FUN_008a4100();
      LOCK();
      *(int *)(iVar4 + 0x9c) = *(int *)(iVar4 + 0x9c) + -1;
      UNLOCK();
      iVar4 = FUN_008a40f0();
      if (*(int *)(iVar4 + 0x94) + *(int *)(iVar4 + 0x9c) + *(int *)(iVar4 + 0x98) == 0) {
        FUN_00c184c0(0);
        iVar4 = FUN_00a9d1c0(iStack_18);
        if (iVar4 != 0) {
          FUN_00ce7ad0(*(undefined4 *)(iStack_18 + 0xa8));
        }
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_14[1] + -1;
      piStack_14[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar4 = piStack_14[2] + -1;
        piStack_14[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  piVar2 = (int *)param_1[9];
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  uVar3 = *param_1;
  uStack_8 = 0;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 2,param_1 + 2,2);
      }
    }
    *param_1 = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23011 ; VA 0x00b01670 ; FUN_00b01670 */

int FUN_00b01670(undefined4 param_1,int *param_2,int param_3)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  char *pcVar4;
  int iVar5;
  char *pcVar6;
  undefined uVar7;
  int *piVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == -0x18) {
    ExceptionList = &pvStack_10;
    if (DAT_01f3037c != '\0') {
      ExceptionList = &pvStack_10;
      FUN_01677520(DAT_01f3037c,"CSG API: empty result");
    }
    param_1 = 0;
    piVar8 = (int *)0x0;
  }
  else {
    if (param_3 != 0) {
      ExceptionList = &pvStack_10;
      if (DAT_01f3037c != '\0') {
        ExceptionList = &pvStack_10;
        uVar3 = FUN_011377d0(param_3);
        FUN_01677520(DAT_01f3037c,"CSG API: error: %s",uVar3);
      }
      pcVar4 = (char *)FUN_011377d0(param_3);
      uVar7 = 0;
      pcVar6 = pcVar4;
      do {
        cVar2 = *pcVar6;
        pcVar6 = pcVar6 + 1;
      } while (cVar2 != '\0');
      FUN_005542c0(pcVar4,(int)pcVar6 - (int)(pcVar4 + 1));
      iVar5 = FUN_005e65e0(uVar7);
      goto LAB_00b01786;
    }
    ExceptionList = &pvStack_10;
    if (DAT_01f3037c != '\0') {
      ExceptionList = &pvStack_10;
      FUN_01677520(DAT_01f3037c,"CSG API: success");
    }
    piVar8 = param_2;
    if (param_2 != (int *)0x0) {
      LOCK();
      param_2[1] = param_2[1] + 1;
      UNLOCK();
    }
  }
  iVar5 = FUN_0096e490(param_1,piVar8);
LAB_00b01786:
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar8 = param_2 + 1;
    iVar1 = *piVar8;
    iVar5 = *piVar8;
    *piVar8 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      iVar5 = (**(code **)*param_2)();
      LOCK();
      piVar8 = param_2 + 2;
      iVar1 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        iVar5 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 23012 ; VA 0x00b017d0 ; FUN_00b017d0 */

/* WARNING: Removing unreachable block (ram,0x00b01822) */
/* WARNING: Removing unreachable block (ram,0x00b01832) */
/* WARNING: Removing unreachable block (ram,0x00b01838) */

void __fastcall FUN_00b017d0(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed2e0;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23013 ; VA 0x00b01873 ; Catch@00b01873 */

undefined * Catch_00b01873(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_00b01884;
}



/* FUNCTION 23014 ; VA 0x00b018a0 ; FUN_00b018a0 */

int FUN_00b018a0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_0089be10(param_1,param_2);
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 23015 ; VA 0x00b01980 ; FUN_00b01980 */

void __fastcall FUN_00b01980(int *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00b01982. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x144))();
  return;
}



/* FUNCTION 23016 ; VA 0x00b019f8 ; FUN_00b019f8 */

void FUN_00b019f8(void)

{
  FUN_00b01a90();
  return;
}



/* FUNCTION 23017 ; VA 0x00b01a00 ; FUN_00b01a00 */

void FUN_00b01a00(void)

{
  FUN_00b01f00();
  return;
}



/* FUNCTION 23018 ; VA 0x00b01a10 ; FUN_00b01a10 */

int __thiscall FUN_00b01a10(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),0xc);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),0xc);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 23019 ; VA 0x00b01a60 ; FUN_00b01a60 */

undefined4 __thiscall FUN_00b01a60(undefined4 param_1,byte param_2)

{
  FUN_00b01310();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 23020 ; VA 0x00b01a90 ; FUN_00b01a90 */

undefined4 __thiscall FUN_00b01a90(undefined4 param_1,byte param_2)

{
  FUN_00e704a0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x5c);
  }
  return param_1;
}



/* FUNCTION 23021 ; VA 0x00b01ac0 ; FUN_00b01ac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b01ac0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::CollisionFidelity>::vftable;
  _DAT_01eedee8 = _DAT_01eedee8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 23022 ; VA 0x00b01af0 ; FUN_00b01af0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b01af0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::PartInstance::FormFactor>::vftable;
  _DAT_01eedee0 = _DAT_01eedee0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 23023 ; VA 0x00b01b20 ; FUN_00b01b20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b01b20(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::PartInstance::LegacyPartType>::vftable;
  _DAT_01eeded8 = _DAT_01eeded8 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 23024 ; VA 0x00b01b50 ; FUN_00b01b50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b01b50(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::NetworkOwnership>::vftable;
  _DAT_01ef8e34 = _DAT_01ef8e34 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 23025 ; VA 0x00b01b80 ; FUN_00b01b80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b01b80(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::RenderFidelity>::vftable;
  _DAT_01eedef0 = _DAT_01eedef0 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 23026 ; VA 0x00b01bb0 ; FUN_00b01bb0 */

undefined4 * __thiscall FUN_00b01bb0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Faces>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 23027 ; VA 0x00b01be0 ; FUN_00b01be0 */

undefined4 * __thiscall FUN_00b01be0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::BrickColor>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 23028 ; VA 0x00b01c10 ; FUN_00b01c10 */

undefined4 * __thiscall FUN_00b01c10(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3uint8>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 23029 ; VA 0x00b01c40 ; FUN_00b01c40 */

undefined4 * __thiscall FUN_00b01c40(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::NetworkOwnership>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 23030 ; VA 0x00b01c70 ; FUN_00b01c70 */

undefined4 * __thiscall FUN_00b01c70(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::SystemAddress>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 23031 ; VA 0x00b01ca0 ; FUN_00b01ca0 */

undefined4 * __thiscall FUN_00b01ca0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::CoordinateFrame>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 23032 ; VA 0x00b01cd0 ; FUN_00b01cd0 */

undefined4 * __thiscall FUN_00b01cd0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::PhysicalProperties>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 23033 ; VA 0x00b01d00 ; FUN_00b01d00 */

undefined4 __thiscall FUN_00b01d00(undefined4 param_1,byte param_2)

{
  FUN_009cba00();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 23034 ; VA 0x00b01d30 ; FUN_00b01d30 */

undefined4 __thiscall FUN_00b01d30(undefined4 param_1,byte param_2)

{
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x268);
  }
  return param_1;
}



/* FUNCTION 23035 ; VA 0x00b01d60 ; FUN_00b01d60 */

undefined4 * __thiscall FUN_00b01d60(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Color3uint8>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 23036 ; VA 0x00b01d90 ; FUN_00b01d90 */

undefined4 * __thiscall FUN_00b01d90(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Faces>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 23037 ; VA 0x00b01dc0 ; FUN_00b01dc0 */

undefined4 * __thiscall FUN_00b01dc0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::PhysicalProperties>::GetSet::
             vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 23038 ; VA 0x00b01df0 ; FUN_00b01df0 */

undefined4 * __thiscall FUN_00b01df0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::SystemAddress>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 23039 ; VA 0x00b01e20 ; FUN_00b01e20 */

undefined4 * __thiscall FUN_00b01e20(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::NetworkOwnership>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 23040 ; VA 0x00b01e50 ; FUN_00b01e50 */

int __thiscall FUN_00b01e50(int param_1,byte param_2)

{
  int *piVar1;
  int iVar2;
  
  FUN_005e6280();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  piVar1 = *(int **)(param_1 + 0x90);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_0089b310();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xd8);
  }
  return param_1;
}



/* FUNCTION 23041 ; VA 0x00b01f00 ; FUN_00b01f00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b01f00(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::PartInstance::vftable;
  param_1[0x16] = RBX::PartInstance::vftable;
  param_1[0x1e] = RBX::PartInstance::vftable;
  param_1[0x25] = RBX::PartInstance::vftable;
  uStack_8 = 0;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) = RBX::PartInstance::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xa8;
  if (DAT_01ee41fb != '\0') {
    FUN_01677490(DAT_01ee41fb,"PartInstance destroyed: %p, primitive: %p",param_1,param_1[0x2a],0);
  }
  FUN_016790b0();
  piVar2 = (int *)param_1[0x37];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[2] + -1;
    piVar2[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  piVar2 = (int *)param_1[0x31];
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  if ((undefined4 *)param_1[0x2a] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x2a])(1);
  }
  if (param_1[0x28] != 0) {
    if ((undefined4 *)param_1[0x29] != (undefined4 *)0x0) {
      *(undefined4 *)param_1[0x29] = param_1[0x27];
    }
    if (param_1[0x27] != 0) {
      *(undefined4 *)(param_1[0x27] + 0xa4) = param_1[0x29];
    }
    *(int *)param_1[0x28] = *(int *)param_1[0x28] + -1;
    param_1[0x27] = 0;
    param_1[0x29] = 0;
    param_1[0x28] = 0;
  }
  LOCK();
  _DAT_01eedc58 = _DAT_01eedc58 + -1;
  UNLOCK();
  param_1[0x25] = RBX::CameraSubject::vftable;
  *(undefined ***)(*(int *)(param_1[0x26] + 4) + 0x98 + (int)param_1) = RBX::CameraSubject::vftable;
  FUN_0115a710();
  FUN_00c3e200();
  FUN_00e704a0();
  param_1[0x3f] = RBX::IHasLocation::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x100);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23042 ; VA 0x00b020a0 ; FUN_00b020a0 */

void FUN_00b020a0(undefined8 *param_1)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  FUN_00c157b0();
  FUN_01162dc0(&fStack_8,&fStack_c,&fStack_10);
  fVar3 = fStack_10 * DAT_0194fa04 * DAT_018ce320;
  if (fVar3 < 0.0) {
    fVar3 = fVar3 - DAT_018ce2f4;
  }
  else {
    fVar3 = fVar3 + DAT_018ce2f4;
  }
  fVar1 = fStack_c * DAT_0194fa04 * DAT_018ce320;
  fVar3 = (float)(int)fVar3 / DAT_018ce320;
  if (fVar1 < 0.0) {
    fVar1 = fVar1 - DAT_018ce2f4;
  }
  else {
    fVar1 = fVar1 + DAT_018ce2f4;
  }
  fVar2 = fStack_8 * DAT_0194fa04 * DAT_018ce320;
  if (fVar2 < 0.0) {
    fVar2 = fVar2 - DAT_018ce2f4;
  }
  else {
    fVar2 = fVar2 + DAT_018ce2f4;
  }
  *param_1 = CONCAT44((float)(int)fVar1 / DAT_018ce320,(float)(int)fVar2 / DAT_018ce320);
  *(float *)(param_1 + 1) = fVar3;
  return;
}



/* FUNCTION 23043 ; VA 0x00b021a0 ; FUN_00b021a0 */

void __thiscall FUN_00b021a0(int *param_1,float *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  puVar2 = (undefined4 *)FUN_00c157b0();
  uStack_58 = *puVar2;
  uStack_54 = puVar2[1];
  uStack_50 = puVar2[2];
  uStack_4c = puVar2[3];
  uStack_48 = puVar2[4];
  uStack_44 = puVar2[5];
  uStack_40 = puVar2[6];
  uStack_3c = puVar2[7];
  uStack_38 = puVar2[8];
  uStack_34 = puVar2[9];
  uStack_30 = puVar2[10];
  uStack_2c = puVar2[0xb];
  FUN_01161480(&uStack_28,*param_2 * DAT_0190119c,param_2[1] * DAT_0190119c,
               param_2[2] * DAT_0190119c);
  cVar1 = FUN_01160b00(&uStack_58);
  if (cVar1 != '\0') {
    uStack_38 = uStack_8;
    uStack_58 = uStack_28;
    uStack_54 = uStack_24;
    uStack_50 = uStack_20;
    uStack_4c = uStack_1c;
    uStack_48 = uStack_18;
    uStack_44 = uStack_14;
    uStack_40 = uStack_10;
    uStack_3c = uStack_c;
    (**(code **)(*param_1 + 0x138))(&uStack_58);
    (**(code **)(*param_1 + 0x108))(&uStack_58);
    (**(code **)(*param_1 + 0x130))(2);
  }
  return;
}



/* FUNCTION 23044 ; VA 0x00b02270 ; FUN_00b02270 */

void FUN_00b02270(void)

{
  FUN_011349f0();
  return;
}



/* FUNCTION 23045 ; VA 0x00b02280 ; FUN_00b02280 */

void __thiscall FUN_00b02280(int param_1,float *param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0x20) + 0x2c);
  if (iVar1 != 0) {
    FUN_00f9f070();
    *(float *)(iVar1 + 0x17c) = *param_2 + *(float *)(iVar1 + 0x17c);
    *(float *)(iVar1 + 0x180) = param_2[1] + *(float *)(iVar1 + 0x180);
    *(float *)(iVar1 + 0x184) = param_2[2] + *(float *)(iVar1 + 0x184);
  }
  return;
}



/* FUNCTION 23046 ; VA 0x00b022e0 ; FUN_00b022e0 */

int __fastcall FUN_00b022e0(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed7e8;
  pvStack_10 = ExceptionList;
  if ((DAT_01d69068 != '\0') && (*(char *)(*(int *)(param_1 + 0xa8) + 0x226) == '\0')) {
    piVar2 = *(int **)(param_1 + 0x28);
    if (0xf < (uint)piVar2[5]) {
      piVar2 = (int *)*piVar2;
    }
    ExceptionList = &pvStack_10;
    iVar3 = FUN_0086f2f0(2,
                         "%s has TriggerTouchEvents set to False. No TouchInterest will be created."
                         ,piVar2);
    ExceptionList = pvStack_10;
    return iVar3;
  }
  ExceptionList = &pvStack_10;
  FUN_00aef140(&iStack_18);
  uStack_8 = 0;
  FUN_008a65e0(param_1,0);
  if (*(int *)(iStack_18 + 0x34) == param_1) {
    iVar3 = FUN_008a4100();
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[2] = piStack_14[2] + 1;
      UNLOCK();
    }
    *(int *)(iVar3 + 0x8c) = iStack_18;
    piVar2 = *(int **)(iVar3 + 0x90);
    *(int **)(iVar3 + 0x90) = piStack_14;
    if (piVar2 != (int *)0x0) {
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iStack_18 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iStack_18 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_14 + 1;
    iVar3 = *piVar2;
    iStack_18 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iStack_18 = (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piStack_14 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iStack_18 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iStack_18;
}



/* FUNCTION 23047 ; VA 0x00b023e0 ; FUN_00b023e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b023e0(int param_1,char param_2)

{
  int iVar1;
  float *pfVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  float10 fVar5;
  float fVar6;
  undefined auStack_d4 [36];
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  float fStack_88;
  float fStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  float fStack_10;
  double dStack_c;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0xa8) + 0x1ac);
  fStack_10 = *(float *)(iVar1 + 4) * DAT_018ce2f4;
  fStack_1c = (float)((uint)(*(float *)(iVar1 + 8) * DAT_018ce2f4) ^ DAT_018c4ea0);
  dStack_c = (double)fStack_10;
  fStack_14 = *(float *)(iVar1 + 0xc) * DAT_018ce2f4;
  fVar5 = (float10)FUN_01725280(dStack_c);
  fVar6 = (float)fVar5;
  if (fVar6 < 0.0) {
    fVar6 = fVar6 - DAT_018ce2f4;
  }
  else {
    fVar6 = fVar6 + DAT_018ce2f4;
  }
  fStack_20 = fStack_10 - (float)(int)fVar6;
  dStack_c = (double)fStack_14;
  fVar5 = (float10)FUN_01725280(dStack_c);
  dStack_c = (double)fVar5;
  fVar6 = (float)fVar5;
  if (fVar6 < 0.0) {
    fVar6 = fVar6 - DAT_018ce2f4;
  }
  else {
    fVar6 = fVar6 + DAT_018ce2f4;
  }
  uStack_30 = 0x3f800000;
  fStack_24 = fStack_14 - (float)(int)fVar6;
  uStack_50 = _DAT_018e3fb0;
  uStack_4c = _UNK_018e3fb4;
  uStack_48 = _UNK_018e3fb8;
  uStack_44 = _UNK_018e3fbc;
  uStack_40 = _DAT_018e3fb0;
  uStack_3c = _UNK_018e3fb4;
  uStack_38 = _UNK_018e3fb8;
  uStack_34 = _UNK_018e3fbc;
  uStack_2c._0_4_ = fStack_20;
  uStack_2c._4_4_ = fStack_1c;
  fStack_18 = fStack_24;
  pfVar2 = (float *)FUN_00c157b0();
  fStack_18 = pfVar2[6] * (float)uStack_2c + pfVar2[7] * uStack_2c._4_4_ + pfVar2[8] * fStack_24 +
              pfVar2[0xb];
  fStack_10 = pfVar2[3] * (float)uStack_2c + pfVar2[4] * uStack_2c._4_4_ + pfVar2[5] * fStack_24 +
              pfVar2[10];
  dStack_c = (double)(ulonglong)
                     (uint)(pfVar2[1] * uStack_2c._4_4_ + (float)uStack_2c * *pfVar2 +
                            pfVar2[2] * fStack_24 + pfVar2[9]);
  puVar3 = (undefined4 *)FUN_01160c20(auStack_d4,&uStack_50);
  uStack_b0 = *puVar3;
  uStack_ac = puVar3[1];
  uStack_a8 = puVar3[2];
  uStack_a4 = puVar3[3];
  uStack_a0 = puVar3[4];
  uStack_9c = puVar3[5];
  uStack_98 = puVar3[6];
  uStack_94 = puVar3[7];
  uStack_90 = puVar3[8];
  uStack_8c = SUB84(dStack_c,0);
  uStack_2c = CONCAT44(fStack_10,uStack_8c);
  fStack_24 = fStack_18;
  fStack_88 = fStack_10;
  fStack_84 = fStack_18;
  uStack_30 = uStack_90;
  if (param_2 == '\0') {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eedc68) {
      FUN_016f3809(&DAT_01eedc68);
      if (DAT_01eedc68 == -1) {
        _DAT_01eedc5c = 0x3f800000;
        _DAT_01eedc60 = 0x3dcccccd;
        _DAT_01eedc64 = 0x3f800000;
        FUN_016f37bf(&DAT_01eedc68);
      }
    }
    puVar3 = (undefined4 *)FUN_00c953b0(&uStack_50,&uStack_b0,&DAT_01eedc5c);
  }
  else {
    uVar4 = FUN_00f28020(&fStack_20);
    puVar3 = (undefined4 *)FUN_00c953b0(&uStack_50,&uStack_b0,uVar4);
  }
  uStack_80 = *puVar3;
  uStack_7c = puVar3[1];
  uStack_78 = puVar3[2];
  uStack_74 = puVar3[3];
  uStack_70 = puVar3[4];
  uStack_6c = puVar3[5];
  uStack_68 = puVar3[6];
  uStack_64 = puVar3[7];
  uStack_60 = puVar3[8];
  uStack_5c = puVar3[9];
  uStack_58 = puVar3[10];
  uStack_54 = puVar3[0xb];
  FUN_00c93230(&uStack_b0,&uStack_80,0x3727c5ac,0x3727c5ac);
  return;
}



/* FUNCTION 23048 ; VA 0x00b026e0 ; FUN_00b026e0 */

void __thiscall FUN_00b026e0(int param_1,float param_2,float param_3,float param_4)

{
  int iVar1;
  char cVar2;
  
  if ((DAT_01d66c24 != '\0') &&
     (((NAN(param_2) == (param_2 == 0.0) || (NAN(param_3) == (param_3 == 0.0))) ||
      (NAN(param_4) == (param_4 == 0.0))))) {
    cVar2 = FUN_01160820(param_2);
    if (cVar2 != '\0') {
      cVar2 = FUN_01160820(param_3);
      if (cVar2 != '\0') {
        cVar2 = FUN_01160820(param_4);
        if ((cVar2 != '\0') && (iVar1 = *(int *)(param_1 + 0xa8), *(int *)(iVar1 + 0x1a8) != 0)) {
          FUN_00bc1c10(iVar1,0);
          iVar1 = *(int *)(*(int *)(iVar1 + 0x70) + 0x2c);
          if (iVar1 != 0) {
            FUN_00f9f070();
            *(float *)(iVar1 + 0x188) = *(float *)(iVar1 + 0x188) + param_2;
            *(float *)(iVar1 + 0x18c) = param_3 + *(float *)(iVar1 + 0x18c);
            *(float *)(iVar1 + 400) = param_4 + *(float *)(iVar1 + 400);
          }
        }
      }
    }
  }
  return;
}



/* FUNCTION 23049 ; VA 0x00b027e0 ; FUN_00b027e0 */

void __thiscall FUN_00b027e0(int param_1,float param_2,float param_3,float param_4)

{
  int iVar1;
  char cVar2;
  
  if ((DAT_01d66c24 != '\0') &&
     (((NAN(param_2) == (param_2 == 0.0) || (NAN(param_3) == (param_3 == 0.0))) ||
      (NAN(param_4) == (param_4 == 0.0))))) {
    cVar2 = FUN_01160820(param_2);
    if (cVar2 != '\0') {
      cVar2 = FUN_01160820(param_3);
      if (cVar2 != '\0') {
        cVar2 = FUN_01160820(param_4);
        if ((cVar2 != '\0') && (iVar1 = *(int *)(param_1 + 0xa8), *(int *)(iVar1 + 0x1a8) != 0)) {
          FUN_00bc1c10(iVar1,0);
          iVar1 = *(int *)(*(int *)(iVar1 + 0x70) + 0x2c);
          if (iVar1 != 0) {
            FUN_00f9f070();
            *(float *)(iVar1 + 0x17c) = *(float *)(iVar1 + 0x17c) + param_2;
            *(float *)(iVar1 + 0x180) = param_3 + *(float *)(iVar1 + 0x180);
            *(float *)(iVar1 + 0x184) = param_4 + *(float *)(iVar1 + 0x184);
          }
        }
      }
    }
  }
  return;
}



/* FUNCTION 23050 ; VA 0x00b028e0 ; FUN_00b028e0 */

void __thiscall
FUN_00b028e0(int param_1,float param_2,float param_3,float param_4,float param_5,float param_6,
            float param_7)

{
  int iVar1;
  char cVar2;
  
  if ((DAT_01d66c24 != '\0') &&
     (((NAN(param_2) == (param_2 == 0.0) || (NAN(param_3) == (param_3 == 0.0))) ||
      (NAN(param_4) == (param_4 == 0.0))))) {
    cVar2 = FUN_01160820(param_2);
    if (cVar2 != '\0') {
      cVar2 = FUN_01160820(param_3);
      if (cVar2 != '\0') {
        cVar2 = FUN_01160820(param_4);
        if ((cVar2 != '\0') && (iVar1 = *(int *)(param_1 + 0xa8), *(int *)(iVar1 + 0x1a8) != 0)) {
          FUN_00bc1c10(iVar1,0);
          iVar1 = *(int *)(*(int *)(iVar1 + 0x70) + 0x2c);
          if (iVar1 != 0) {
            FUN_00f9f070();
            *(float *)(iVar1 + 0x17c) = *(float *)(iVar1 + 0x17c) + param_2;
            *(float *)(iVar1 + 0x180) = param_3 + *(float *)(iVar1 + 0x180);
            *(float *)(iVar1 + 0x184) = param_4 + *(float *)(iVar1 + 0x184);
            param_5 = param_5 - *(float *)(iVar1 + 0x3c);
            param_6 = param_6 - *(float *)(iVar1 + 0x40);
            param_7 = param_7 - *(float *)(iVar1 + 0x44);
            *(float *)(iVar1 + 0x18c) =
                 (param_7 * param_2 - param_5 * param_4) + *(float *)(iVar1 + 0x18c);
            *(float *)(iVar1 + 0x188) =
                 (param_6 * param_4 - param_7 * param_3) + *(float *)(iVar1 + 0x188);
            *(float *)(iVar1 + 400) =
                 (param_5 * param_3 - param_6 * param_2) + *(float *)(iVar1 + 400);
          }
        }
      }
    }
  }
  return;
}



/* FUNCTION 23051 ; VA 0x00b02a80 ; FUN_00b02a80 */

void FUN_00b02a80(int param_1,code *param_2,int param_3,int param_4,undefined4 *param_5,
                 undefined4 *param_6,undefined4 *param_7,uint *param_8,uint *param_9)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  uint *puVar5;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_7c;
  uint *puStack_78;
  uint *puStack_74;
  undefined4 uStack_70;
  uint auStack_6c [2];
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined8 uStack_54;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  code *pcStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed810;
  pvStack_10 = ExceptionList;
  puStack_1c = (undefined *)auStack_6c;
  iStack_14 = *(int *)(*(int *)(param_1 + 0x54) + param_4) + param_3 + param_1 + 0x54;
  pcStack_18 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01eeccf4);
  uVar2 = *param_7;
  uVar3 = *param_6;
  auStack_6c[0] = 0;
  uVar4 = *param_9;
  ExceptionList = &pvStack_10;
  puVar5 = auStack_6c;
  if (uVar4 != 0) {
    auStack_6c[0] = uVar4;
    if ((uVar4 & 1) == 0) {
      puStack_74 = &uStack_64;
      uStack_70 = 0;
      puStack_78 = param_9 + 2;
      uStack_7c = 0xb02b15;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar4 & 0xfffffffe))();
      puVar5 = (uint *)puStack_1c;
    }
    else {
      uStack_64 = param_9[2];
      uStack_60 = param_9[3];
      uStack_5c = param_9[4];
      uStack_58 = param_9[5];
      uStack_54 = *(undefined8 *)(param_9 + 6);
      ExceptionList = &pvStack_10;
      puVar5 = auStack_6c;
    }
  }
  puStack_1c = (undefined *)puVar5;
  uStack_8 = 0;
  uStack_90 = param_1;
  uVar4 = *param_8;
  if (uVar4 != 0) {
    if ((uVar4 & 1) == 0) {
      (**(code **)(uVar4 & 0xfffffffe))(param_8 + 2);
    }
    else {
      uStack_a8 = param_8[2];
      uStack_a4 = param_8[3];
      uStack_a0 = param_8[4];
      uStack_9c = param_8[5];
      uStack_98 = *(undefined8 *)(param_8 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_90 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_3c != 0) {
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_a8,0);
    }
    else {
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
      uStack_98 = uStack_24;
    }
  }
  FUN_00960570();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    uStack_90 = 2;
    uStack_98 = CONCAT44(&uStack_34,&uStack_34);
    uStack_9c = 0xb02bf7;
    (**(code **)(uStack_3c & 0xfffffffe))();
  }
  if (param_5[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_9c = *param_5;
  uStack_98 = CONCAT44(uVar3,param_5[1]);
  uStack_8 = 0xffffffff;
  uStack_a0 = 0xb02c40;
  uStack_90 = uVar2;
  (*pcStack_18)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23052 ; VA 0x00b02c50 ; FUN_00b02c50 */

undefined __thiscall FUN_00b02c50(int param_1,int param_2)

{
  int iVar1;
  undefined uVar2;
  int iVar3;
  int iVar4;
  undefined auStack_20 [12];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    iVar1 = *(int *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00aff8c0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) goto LAB_00b02ca3;
  }
  param_2 = 0;
LAB_00b02ca3:
  iStack_14 = *(int *)(param_1 + 0xa8);
  if (((param_2 != 0) && (*(int *)(iStack_14 + 0x1a8) != 0)) &&
     (iVar1 = *(int *)(param_2 + 0xa8), *(int *)(iStack_14 + 0x1a8) == *(int *)(iVar1 + 0x1a8))) {
    iVar3 = FUN_00ca1730(iVar1);
    iVar4 = FUN_00ca1730(iStack_14);
    if (iVar4 == iVar3) {
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return 0;
    }
    uVar2 = FUN_00ce0c40(iStack_14,iVar1);
    FUN_00550b30();
    ExceptionList = pvStack_10;
    return uVar2;
  }
  FUN_016756b0(auStack_20,
               "Both parts must be PartInstance descendants of WorldRoot to make this query.");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_20,&DAT_01c17198);
}



/* FUNCTION 23053 ; VA 0x00b02d50 ; FUN_00b02d50 */

undefined4 __thiscall FUN_00b02d50(int param_1,int *param_2,uint *param_3)

{
  char cVar1;
  uint *puVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  char *pcVar6;
  undefined4 uVar7;
  uint uStack_1c;
  uint uStack_18;
  uint uStack_14;
  uint uStack_10;
  int iStack_c;
  uint uStack_8;
  
  *param_2 = 0;
  puVar2 = param_3;
  if (0xf < param_3[5]) {
    puVar2 = (uint *)*param_3;
  }
  param_3[4] = 0;
  *(undefined *)puVar2 = 0;
  iStack_c = FUN_008b3380(param_1);
  if (iStack_c == 0) {
    uStack_8 = 0xf;
    uStack_1c = uStack_1c & 0xffffff00;
    FUN_005542c0("Can only call Network Ownership API on a part that is descendent of Workspace",
                 0x4d);
    if (param_3 != &uStack_1c) {
      FUN_005507b0();
      *param_3 = uStack_1c;
      param_3[1] = uStack_18;
      param_3[2] = uStack_14;
      param_3[3] = uStack_10;
      *(ulonglong *)(param_3 + 4) = CONCAT44(uStack_8,iStack_c);
      return 0;
    }
    if (0xf < uStack_8) {
      uVar5 = uStack_8 + 1;
      uVar4 = uStack_1c;
      if (0xfff < uVar5) {
        uVar4 = *(uint *)(uStack_1c - 4);
        uVar5 = uStack_8 + 0x24;
        if (0x1f < (uStack_1c - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar4,uVar5);
    }
    return 0;
  }
  cVar1 = FUN_00973950(param_1,1);
  if (cVar1 != '\0') {
    iStack_c = 0;
    uStack_8 = 0xf;
    uStack_1c = uStack_1c & 0xffffff00;
    FUN_005542c0("Network Ownership API can only be called from the Server.",0x39);
    if (param_3 != &uStack_1c) {
      FUN_005507b0();
      uVar4 = uStack_1c;
      uStack_1c = uStack_1c & 0xffffff00;
      *param_3 = uVar4;
      param_3[1] = uStack_18;
      param_3[2] = uStack_14;
      param_3[3] = uStack_10;
      *(ulonglong *)(param_3 + 4) = CONCAT44(uStack_8,iStack_c);
      iStack_c = 0;
      uStack_8 = 0xf;
    }
    FUN_005507b0();
    return 0;
  }
  iVar3 = (**(code **)(**(int **)(*(int *)(param_1 + 0xa8) + 0x1ac) + 8))();
  if (iVar3 == 10) {
    uVar7 = 0x2f;
    pcVar6 = "Network Ownership API cannot be used on Terrain";
  }
  else {
    iVar3 = FUN_00c15700();
    *param_2 = iVar3;
    if (iVar3 != 0) {
      return 1;
    }
    uVar7 = 0x5b;
    pcVar6 = 
    "Network Ownership API cannot be called on Anchored parts or parts welded to Anchored parts.";
  }
  uStack_1c = uStack_1c & 0xffffff00;
  uStack_8 = 0xf;
  iStack_c = 0;
  FUN_005542c0(pcVar6,uVar7);
  FUN_005511f0(&uStack_1c);
  FUN_005507b0();
  return 0;
}



/* FUNCTION 23054 ; VA 0x00b02f10 ; FUN_00b02f10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_00b02f10(int *param_1)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uStack_104;
  undefined *puStack_100;
  char acStack_fc [200];
  undefined4 *puStack_34;
  undefined4 *puStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed846;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = (undefined4 *)FUN_01674e20(0x18);
  if (puStack_14 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    puStack_14[1] = 1;
    puStack_14[2] = 1;
    *puStack_14 = std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
    puStack_14[3] = 0;
    puStack_14[4] = 0;
    puStack_14[5] = 0;
    puVar4 = puStack_14;
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  puStack_34 = puVar4 + 3;
  puStack_30 = puVar4;
  cVar1 = FUN_00b02d50(&puStack_14,auStack_2c);
  uStack_104 = FUN_0088daf0();
  puStack_100 = (undefined *)0x0;
  acStack_fc[0] = cVar1;
  puStack_100 = (undefined *)FUN_005c9ef0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar4[5] == puVar4[4]) {
    FUN_005ca4f0(puVar4[4],&uStack_104);
  }
  else {
    FUN_005caf00(&uStack_104);
    puVar4[4] = puVar4[4] + 0xd0;
  }
  uStack_8._0_1_ = 3;
  if (puStack_100 != (undefined *)0x0) {
    (**(code **)(puStack_100 + 8))(acStack_fc);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (cVar1 == '\0') {
    uStack_104 = FUN_0088cb40();
    puStack_100 = (undefined *)0x0;
    FUN_0054ef60(auStack_2c);
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ea8c48) {
      FUN_016f3809(&DAT_01ea8c48);
      if (DAT_01ea8c48 == -1) {
        _DAT_01ea8c3c = FUN_005c65f0;
        _DAT_01ea8c40 = FUN_005c93a0;
        DAT_01ea8c44 = FUN_005c77b0;
        FUN_016f37bf(&DAT_01ea8c48);
      }
    }
    puStack_100 = &DAT_01ea8c3c;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (puVar4[5] == puVar4[4]) {
      FUN_005ca4f0(puVar4[4],&uStack_104);
    }
    else {
      FUN_005caf00(&uStack_104);
      puVar4[4] = puVar4[4] + 0xd0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (puStack_100 != (undefined *)0x0) {
      (**(code **)(puStack_100 + 8))(acStack_fc);
    }
  }
  *param_1 = (int)(puVar4 + 3);
  param_1[1] = (int)puVar4;
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 23055 ; VA 0x00b03160 ; FUN_00b03160 */

void FUN_00b03160(undefined4 *param_1,undefined *param_2,undefined *param_3,int *param_4)

{
  char cVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  uint uVar8;
  uint uVar9;
  undefined4 uStack_10;
  uint uStack_c;
  char cStack_5;
  
  cStack_5 = '\0';
  puVar2 = (undefined4 *)FUN_0067ad50(&uStack_10);
  uStack_c = 0;
  *param_1 = *puVar2;
  *param_2 = 1;
  *param_3 = 1;
  iVar5 = param_4[1];
  iVar4 = *param_4;
  piVar7 = param_4;
  if (iVar5 - iVar4 >> 2 != 0) {
    do {
      iVar5 = *(int *)(iVar4 + uStack_c * 4);
      if (((((iVar5 == 0) ||
            (iVar5 = *(int *)(iVar5 + 0x1b0), uVar9 = -(uint)(iVar5 != 0) & iVar5 - 0x58U,
            uVar9 == 0)) || (iVar5 = *(int *)(uVar9 + 0x34), piVar7 = param_4, iVar5 == 0)) ||
          ((iVar4 = *(int *)(iVar5 + 0xc), iVar3 = FUN_00b63e30(), piVar7 = param_4,
           (uint)*(ushort *)(iVar3 + 0x1da) <
           (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) ||
           (iVar4 = FUN_009ba880(iVar5), piVar7 = param_4, iVar4 == 0)))) ||
         (iVar5 = FUN_00980070(iVar5), piVar7 = param_4, iVar5 == 0)) {
        uVar9 = uStack_c;
        if (cStack_5 == '\0') {
          cStack_5 = '\x01';
          *param_1 = *(undefined4 *)(*(int *)(*piVar7 + uStack_c * 4) + 0x1dc);
        }
        uStack_10 = *(undefined4 *)(*(int *)(*piVar7 + uStack_c * 4) + 0x1dc);
        cVar1 = FUN_005e0cd0(param_1);
        if (cVar1 != '\0') {
          *param_2 = 0;
        }
        uStack_c = uVar9;
        if (*(char *)(*(int *)(*piVar7 + uVar9 * 4) + 0x22c) != '\x01') {
          *param_3 = 0;
        }
      }
      else if (*(char *)(*(int *)(uVar9 + 0xa8) + 0x22c) != '\0') {
        *(undefined *)(*(int *)(uVar9 + 0xa8) + 0x22c) = 0;
        cVar1 = FUN_0098c5a0(uVar9,0);
        piVar7 = param_4;
        if (cVar1 != '\0') {
          FUN_008a4940(&DAT_01eed490);
          piVar7 = param_4;
        }
      }
      iVar5 = piVar7[1];
      uStack_c = uStack_c + 1;
      iVar4 = *piVar7;
    } while (uStack_c < (uint)(iVar5 - iVar4 >> 2));
  }
  uVar9 = 0;
  if (iVar5 - iVar4 >> 2 != 0) {
    do {
      iVar5 = *(int *)(iVar4 + uVar9 * 4);
      if (iVar5 == 0) {
        uVar8 = 0;
      }
      else {
        iVar5 = *(int *)(iVar5 + 0x1b0);
        uVar8 = -(uint)(iVar5 != 0) & iVar5 - 0x58U;
      }
      cVar1 = FUN_0098c5a0(uVar8,0);
      if ((cVar1 != '\0') && (*(char *)(*(int *)(uVar8 + 0xa8) + 0x22c) != '\0')) {
        *(undefined *)(*(int *)(uVar8 + 0xa8) + 0x22c) = 0;
        cVar1 = FUN_0098c5a0(uVar8,0);
        if (cVar1 != '\0') {
          FUN_008a4940(&DAT_01eed490);
        }
      }
      uVar9 = uVar9 + 1;
      iVar4 = *piVar7;
    } while (uVar9 < (uint)(piVar7[1] - iVar4 >> 2));
  }
  if (cStack_5 != '\0') {
    if (DAT_01d66c1c == '\0') {
      return;
    }
    uVar6 = FUN_0067ad50(&param_4);
    cVar1 = FUN_00a33d60(uVar6);
    if (cVar1 == '\0') {
      return;
    }
  }
  *param_2 = 0;
  *param_3 = 0;
  return;
}



/* FUNCTION 23056 ; VA 0x00b03390 ; FUN_00b03390 */

undefined4 __thiscall FUN_00b03390(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0xa8) + 0x1ac);
  fVar3 = *(float *)(iVar1 + 0xc) * DAT_018ce2f4;
  fVar5 = *(float *)(iVar1 + 4) * DAT_018ce2f4;
  fVar4 = *(float *)(iVar1 + 8) * DAT_018ce2f4;
  uVar2 = FUN_00c157b0(CONCAT44((uint)fVar4 ^ DAT_018c4ea0,(uint)fVar5 ^ DAT_018c4ea0),
                       (uint)fVar3 ^ DAT_018c4ea0,CONCAT44(fVar4,fVar5),fVar3);
  FUN_00c9f550(param_2,uVar2);
  return param_2;
}



/* FUNCTION 23057 ; VA 0x00b03420 ; FUN_00b03420 */

undefined4 FUN_00b03420(void)

{
  int iVar1;
  undefined *puVar2;
  
  iVar1 = FUN_00c15700();
  if (iVar1 != 0) {
    puVar2 = (undefined *)(*(int *)(iVar1 + 0x1b0) + 0x8c);
    if (*(int *)(iVar1 + 0x1b0) == 0) {
      puVar2 = (undefined *)0xe4;
    }
    return CONCAT31((int3)((uint)puVar2 >> 8),*puVar2);
  }
  return 0;
}



/* FUNCTION 23058 ; VA 0x00b03450 ; FUN_00b03450 */

undefined4 FUN_00b03450(undefined4 param_1,undefined4 param_2)

{
  bool bVar1;
  char cVar2;
  undefined4 uVar3;
  undefined auStack_c [4];
  undefined4 uStack_8;
  
  uVar3 = FUN_0067ad50(auStack_c);
  cVar2 = FUN_005e0cd0(uVar3);
  if (cVar2 != '\0') {
    uStack_8 = 2;
    cVar2 = FUN_005e0cd0(&uStack_8);
    if (cVar2 != '\0') {
      bVar1 = true;
      goto LAB_00b0348f;
    }
  }
  bVar1 = false;
LAB_00b0348f:
  cVar2 = FUN_005e0cd0(param_2);
  if ((bVar1) && (cVar2 != '\0')) {
    return 1;
  }
  return 0;
}



/* FUNCTION 23059 ; VA 0x00b034b0 ; FUN_00b034b0 */

uint __fastcall FUN_00b034b0(int param_1)

{
  char cVar1;
  uint uVar2;
  
  uVar2 = 0;
  while (((cVar1 = *(char *)(*(int *)(param_1 + 0xa8) + 0x22f + uVar2), cVar1 != '\x06' &&
          (cVar1 != '\b')) && (cVar1 != '\a'))) {
    uVar2 = uVar2 + 1;
    if (5 < (int)uVar2) {
      return uVar2 & 0xffffff00;
    }
  }
  return CONCAT31((int3)(uVar2 >> 8),1);
}



/* FUNCTION 23060 ; VA 0x00b034e0 ; FUN_00b034e0 */

undefined4 * __thiscall
FUN_00b034e0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  code *pcStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ed860;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
  }
  else {
    pcStack_1c = (code *)*(undefined8 *)(param_1 + 0x38);
    ExceptionList = &pvStack_10;
    (*pcStack_1c)(1);
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00aff9c0(param_2,param_4,param_5);
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23061 ; VA 0x00b035b0 ; FUN_00b035b0 */

undefined4 * __thiscall
FUN_00b035b0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  code *pcStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ed880;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
  }
  else {
    pcStack_1c = (code *)*(undefined8 *)(param_1 + 0x38);
    ExceptionList = &pvStack_10;
    (*pcStack_1c)(1);
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00affc20(param_2,param_4,param_5);
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23062 ; VA 0x00b03680 ; FUN_00b03680 */

undefined4 * __thiscall
FUN_00b03680(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  code *pcStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ed8c1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  pcStack_2c = (code *)*(undefined8 *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  uVar3 = (*pcStack_2c)(1);
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  FUN_006eccd0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_00b04eb0;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = uVar3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23063 ; VA 0x00b03850 ; FUN_00b03850 */

undefined4 * __thiscall
FUN_00b03850(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  code *pcStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ab301;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  pcStack_2c = (code *)*(undefined8 *)(param_1 + 0x38);
  ExceptionList = &pvStack_10;
  uVar3 = (*pcStack_2c)(1);
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar5 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_007037b0;
    puVar5[3] = FUN_0068b170;
    puVar5[4] = 0;
    puVar5[5] = uVar3;
    puVar5[6] = 0;
    puVar5[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar5[6] = param_4;
    puVar5[7] = param_5;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar4);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 23064 ; VA 0x00b03a10 ; FUN_00b03a10 */

void FUN_00b03a10(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00b0f580();
    *param_2 = uVar3;
    iVar4 = FUN_00b0f8e0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 23065 ; VA 0x00b03a70 ; FUN_00b03a70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00b03a70(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_00b0f630();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01eee10c) {
      FUN_016f3809(&DAT_01eee10c);
      if (DAT_01eee10c == -1) {
        _DAT_01eee100 = FUN_005c65e0;
        _DAT_01eee104 = FUN_005c65e0;
        _DAT_01eee108 = _guard_check_icall;
        FUN_016f37bf(&DAT_01eee10c);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01eee100) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01eee100;
  }
  return;
}



/* FUNCTION 23066 ; VA 0x00b03b30 ; FUN_00b03b30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00b03b30(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = FUN_00b0f6f0();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01eee12c) {
      FUN_016f3809(&DAT_01eee12c);
      if (DAT_01eee12c == -1) {
        _DAT_01eee120 = FUN_005c65e0;
        _DAT_01eee124 = FUN_005c65e0;
        _DAT_01eee128 = _guard_check_icall;
        FUN_016f37bf(&DAT_01eee12c);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01eee120) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01eee120;
  }
  return;
}



/* FUNCTION 23067 ; VA 0x00b03bf0 ; FUN_00b03bf0 */

void FUN_00b03bf0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = thunk_FUN_00b0f780();
    *param_2 = uVar3;
    iVar4 = FUN_00b0fa30();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 23068 ; VA 0x00b03c50 ; FUN_00b03c50 */

void FUN_00b03c50(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00b0f830();
    *param_2 = uVar3;
    iVar4 = FUN_00b0faa0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 23069 ; VA 0x00b03cb0 ; FUN_00b03cb0 */

void FUN_00b03cb0(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(param_1 + 0x43c);
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_0058c590(aiStack_28,*piVar1 - (int)piVar1,piVar1[1] - (int)piVar1);
  uStack_8 = 0;
  if (0xf < (uint)puVar2[5]) {
    puVar2 = (undefined4 *)*puVar2;
  }
  FUN_0087c450(&DAT_018c5f98,"PartInstance_ConvertToNewPhysicalProp",puVar2,0,0,0);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    iVar3 = aiStack_28[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_28[0] + -4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23070 ; VA 0x00b03d60 ; FUN_00b03d60 */

void FUN_00b03d60(int *param_1)

{
  float fVar1;
  float fVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined auStack_3c [4];
  float fStack_38;
  undefined auStack_24 [4];
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  code *pcStack_c;
  int iStack_8;
  
  if ((((param_1 != (int *)0x0) &&
       (iVar4 = param_1[3], iVar3 = FUN_00aff8c0(),
       (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
       (uint)*(ushort *)(iVar3 + 0x1da))) &&
      (iVar4 = (**(code **)(**(int **)(param_1[0x2a] + 0x1ac) + 8))(), iVar4 != 10)) &&
     (iVar4 = param_1[0x2a], **(char **)(iVar4 + 0x21c) == '\0')) {
    fVar1 = *(float *)(iVar4 + 0x214);
    uVar6 = (uint)DAT_018c0da0;
    uVar5 = (uint)((ulonglong)DAT_018c0da0 >> 0x20);
    if ((((NAN(fVar1) || NAN(DAT_018fde64)) == (fVar1 == DAT_018fde64)) &&
        (((float)(double)CONCAT44((uint)((ulonglong)(double)fVar1 >> 0x20) & uVar5,
                                  SUB84((double)fVar1,0) & uVar6) + DAT_018ce2f8) * DAT_018f76ac <
         (float)(double)CONCAT44((uint)((ulonglong)(double)(fVar1 - DAT_018fde64) >> 0x20) & uVar5,
                                 SUB84((double)(fVar1 - DAT_018fde64),0) & uVar6))) ||
       ((fVar1 = *(float *)(iVar4 + 0x218),
        (NAN(fVar1) || NAN(DAT_018ce2f4)) == (fVar1 == DAT_018ce2f4) &&
        (((float)(double)CONCAT44((uint)((ulonglong)(double)fVar1 >> 0x20) & uVar5,
                                  SUB84((double)fVar1,0) & uVar6) + DAT_018ce2f8) * DAT_018f76ac <
         (float)(double)CONCAT44((uint)((ulonglong)(double)(fVar1 - DAT_018ce2f4) >> 0x20) & uVar5,
                                 SUB84((double)(fVar1 - DAT_018ce2f4),0) & uVar6))))) {
      iVar4 = FUN_008f7870(param_1);
      if (iVar4 != 0) {
        pcStack_c = FUN_00b03cb0;
        iStack_8 = iVar4;
        FUN_0075d260(&DAT_01eedc7c,&pcStack_c);
      }
      FUN_00f9dd70(auStack_3c,param_1[0x2a]);
      fStack_20 = DAT_018daf54;
      if (DAT_018daf54 <= fStack_38) {
        fStack_20 = fStack_38;
      }
      fVar1 = *(float *)(param_1[0x2a] + 0x218);
      fVar2 = *(float *)(param_1[0x2a] + 0x214);
      auStack_24[0] = 1;
      if (DAT_018ce320 < fStack_20) {
        fStack_20 = 100.0;
      }
      fStack_1c = 0.0;
      if (0.0 <= fVar1) {
        fStack_1c = fVar1;
      }
      if (DAT_018ce2f8 < fStack_1c) {
        fStack_1c = 1.0;
      }
      fStack_18 = 0.0;
      if (0.0 <= fVar2) {
        fStack_18 = fVar2;
      }
      if (DAT_018daf58 < fStack_18) {
        fStack_18 = 2.0;
      }
      uStack_14 = 0x3f800000;
      uStack_10 = 0x3f800000;
      (**(code **)(*param_1 + 0x11c))(auStack_24);
    }
  }
  uVar6 = 0;
  iVar4 = FUN_005d6c30();
  if (iVar4 != 0) {
    do {
      FUN_00b03d60(*(undefined4 *)(*(int *)param_1[0xb] + uVar6 * 8));
      uVar6 = uVar6 + 1;
      uVar5 = FUN_005d6c30();
    } while (uVar6 < uVar5);
  }
  return;
}



/* FUNCTION 23071 ; VA 0x00b03f80 ; FUN_00b03f80 */

void FUN_00b03f80(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b0f580();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23072 ; VA 0x00b03fc0 ; FUN_00b03fc0 */

void FUN_00b03fc0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b0f630();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23073 ; VA 0x00b04000 ; FUN_00b04000 */

void FUN_00b04000(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b0f6f0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23074 ; VA 0x00b04040 ; FUN_00b04040 */

void FUN_00b04040(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00b0f780();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23075 ; VA 0x00b04080 ; FUN_00b04080 */

void FUN_00b04080(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b0f830();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23076 ; VA 0x00b040c0 ; FUN_00b040c0 */

void __thiscall FUN_00b040c0(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))((int)&param_2 + 1,param_2);
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,(int)&param_2 + 1);
  return;
}



/* FUNCTION 23077 ; VA 0x00b040f0 ; FUN_00b040f0 */

void __thiscall FUN_00b040f0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_1c [24];
  
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_1c,param_2);
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,auStack_1c);
  return;
}



/* FUNCTION 23078 ; VA 0x00b04120 ; FUN_00b04120 */

void FUN_00b04120(undefined4 *param_1,int *param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,uint param_6,undefined4 param_7,undefined4 param_8,
                 undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined8 param_12,
                 uint param_13,undefined4 param_14,undefined4 param_15,undefined4 param_16,
                 undefined4 param_17,undefined4 param_18,undefined8 param_19)

{
  char **ppcVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  undefined **ppuVar8;
  int *piVar9;
  int iVar10;
  char *pcStack_210;
  undefined4 uStack_20c;
  undefined uStack_208;
  undefined4 uStack_200;
  undefined4 *puStack_1fc;
  undefined4 *puStack_1f8;
  int **ppiStack_1f4;
  undefined auStack_1e8 [72];
  undefined auStack_1a0 [72];
  undefined auStack_158 [72];
  undefined auStack_110 [72];
  undefined auStack_c8 [72];
  int *piStack_80;
  int *piStack_7c;
  uint uStack_78;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined8 uStack_60;
  uint uStack_58;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined auStack_38 [4];
  int *piStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  undefined4 *puStack_1c;
  int **ppiStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ed96b;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  puStack_1f8 = (undefined4 *)0xb04152;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_008f7870();
  puStack_1c = (undefined4 *)param_1[1];
  puVar6 = (undefined4 *)*param_1;
  iVar10 = iVar3;
  if (puVar6 != puStack_1c) {
    do {
      ppiStack_1f4 = (int **)*puVar6;
      puStack_1f8 = (undefined4 *)0xb0416d;
      iVar4 = FUN_008f7870();
      iVar3 = iVar4;
      if (((iVar10 != 0) && (iVar3 = iVar10, iVar4 != 0)) && (iVar10 != iVar4)) {
        uStack_20c = 0x3c;
        pcStack_210 = "Objects passed to the CSG API didn\'t have the same DataModel";
        goto LAB_00b041ad;
      }
      puVar6 = puVar6 + 2;
      iVar10 = iVar3;
    } while (puVar6 != puStack_1c);
  }
  if (iVar3 == 0) {
    uStack_20c = 0x40;
    pcStack_210 = "CSG API requires at least one object to be linked to a DataModel";
  }
  else {
    if ((*(int *)(iVar3 + 0x4a0) == 2) || (*(int *)(iVar3 + 0x4a0) == 3)) {
      ppiStack_1f4 = (int **)0x268;
      puStack_1f8 = (undefined4 *)0xb042a4;
      piVar5 = (int *)FUN_01674e20();
      uStack_8._0_1_ = 3;
      if (piVar5 == (int *)0x0) {
        piVar9 = (int *)0x0;
        piStack_20 = piVar5;
      }
      else {
        ppiStack_1f4 = (int **)0x1;
        puStack_1f8 = (undefined4 *)&DAT_0194f658;
        piVar5[1] = 1;
        piVar5[2] = 1;
        *piVar5 = (int)std::_Ref_count_obj<class_RBX::CSGOperations2>::vftable;
        uStack_200 = 0xb042d8;
        puStack_1fc = (undefined4 *)iVar3;
        piStack_20 = piVar5;
        FUN_011346c0();
        piVar9 = piVar5;
      }
      piStack_28 = piVar9 + 4;
      ppiStack_1f4 = ppiStack_18;
      puStack_1f8 = (undefined4 *)auStack_38;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      puStack_1fc = (undefined4 *)0xb042f5;
      piStack_24 = piVar9;
      puVar6 = (undefined4 *)FUN_0060dcd0();
      uStack_30 = *puVar6;
      piVar5 = (int *)puVar6[1];
      *puVar6 = 0;
      puVar6[1] = 0;
      ppiStack_18 = (int **)piStack_34;
      piStack_2c = piVar5;
      piStack_20 = (int *)uStack_30;
      if (piStack_34 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_34[1] + -1;
        piStack_34[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          ppiStack_1f4 = (int **)0xb0432b;
          (**(code **)*piStack_34)();
          LOCK();
          iVar3 = (int)ppiStack_18[2] + -1;
          ppiStack_18[2] = (int *)iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            ppiStack_1f4 = (int **)0xb0433d;
            (**(code **)((int)*ppiStack_18 + 4))();
          }
        }
      }
      puStack_1c = &pcStack_210;
      ppiStack_18 = &piStack_80;
      if (piVar9 != (int *)0x0) {
        LOCK();
        piVar9[1] = piVar9[1] + 1;
        UNLOCK();
      }
      piStack_80 = piVar9 + 4;
      uStack_8._0_1_ = 6;
      uStack_78 = 0;
      piStack_7c = piVar9;
      ppcVar1 = &pcStack_210;
      if (param_6 != 0) {
        uStack_78 = param_6;
        if ((param_6 & 1) == 0) {
          (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_70,0);
          ppcVar1 = (char **)puStack_1c;
        }
        else {
          uStack_70 = param_8;
          uStack_6c = param_9;
          uStack_68 = param_10;
          uStack_64 = param_11;
          uStack_60 = param_12;
          ppcVar1 = &pcStack_210;
        }
      }
      puStack_1c = ppcVar1;
      uStack_8._0_1_ = 7;
      uStack_58 = 0;
      if (param_13 != 0) {
        uStack_58 = param_13;
        if ((param_13 & 1) == 0) {
          (**(code **)(param_13 & 0xfffffffe))(&param_15,&uStack_50,0);
        }
        else {
          uStack_50 = param_15;
          uStack_4c = param_16;
          uStack_48 = param_17;
          uStack_44 = param_18;
          uStack_40 = param_19;
        }
      }
      uStack_8._0_1_ = 8;
      FUN_00b005e0(&piStack_80);
      uStack_8._0_1_ = 9;
      *puStack_1c = 0;
      FUN_00b005e0(auStack_1e8);
      uStack_8._0_1_ = 10;
      FUN_00b005e0(auStack_1a0);
      uStack_8._0_1_ = 0xb;
      FUN_00b005e0(auStack_158);
      uStack_8._0_1_ = 0xc;
      cVar2 = FUN_00585a40(auStack_c8);
      if (cVar2 == '\0') {
        FUN_00b005e0(auStack_c8);
        uStack_8._0_1_ = 0xd;
        ppiStack_18 = (int **)FUN_01674e20(0x48);
        uStack_8._0_1_ = 0xe;
        if (ppiStack_18 == (int **)0x0) {
          uVar7 = 0;
        }
        else {
          uVar7 = FUN_00b005e0(auStack_110);
        }
        puStack_1c[2] = uVar7;
        FUN_009e2cd0();
        FUN_009e2cd0();
        cStack_11 = '\x01';
      }
      else {
        FUN_009e2cd0();
        cStack_11 = '\0';
      }
      FUN_009e2cd0();
      ppuVar8 = &PTR_FUN_0194f9ec;
      if (cStack_11 == '\0') {
        ppuVar8 = (undefined **)0x0;
      }
      *puStack_1c = ppuVar8;
      FUN_009e2cd0();
      FUN_009e2cd0();
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      FUN_009e2cd0();
      if (param_2 != (int *)0x0) {
        LOCK();
        param_2[1] = param_2[1] + 1;
        UNLOCK();
      }
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
      }
      FUN_01135ae0(piStack_20,piVar5,param_1,param_2,param_3,param_4,param_5);
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar3 = piVar5[1] + -1;
        piVar5[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          ppiStack_1f4 = (int **)0xb0457b;
          (**(code **)*piVar5)();
          LOCK();
          iVar3 = piVar5[2] + -1;
          piVar5[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            ppiStack_1f4 = (int **)0xb0458c;
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      if (piVar9 != (int *)0x0) {
        LOCK();
        iVar3 = piVar9[1] + -1;
        piVar9[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          ppiStack_1f4 = (int **)0xb045aa;
          (**(code **)*piVar9)();
          LOCK();
          iVar3 = piVar9[2] + -1;
          piVar9[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            ppiStack_1f4 = (int **)0xb045be;
            (**(code **)(*piVar9 + 4))();
          }
        }
      }
      goto LAB_00b041bd;
    }
    uStack_20c = 0x2b;
    pcStack_210 = "CSG API can only be called from the Server.";
  }
LAB_00b041ad:
  puStack_1f8 = (undefined4 *)0x0;
  ppiStack_1f4 = (int **)0xf;
  uStack_208 = 0;
  FUN_005542c0();
  uStack_20c = 0xb041ba;
  FUN_005e65e0();
LAB_00b041bd:
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar3 = param_2[1] + -1;
    param_2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      ppiStack_1f4 = (int **)0xb041d3;
      (**(code **)*param_2)();
      LOCK();
      piVar5 = param_2 + 2;
      iVar3 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        ppiStack_1f4 = (int **)0xb041e2;
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    puStack_1fc = &param_8;
    ppiStack_1f4 = (int **)0x2;
    uStack_200 = 0xb04203;
    puStack_1f8 = puStack_1fc;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  uStack_8 = 0x10;
  if (((param_13 != 0) && ((param_13 & 1) == 0)) &&
     (*(code **)(param_13 & 0xfffffffe) != (code *)0x0)) {
    puStack_1fc = &param_15;
    ppiStack_1f4 = (int **)0x2;
    uStack_200 = 0xb04231;
    puStack_1f8 = puStack_1fc;
    (**(code **)(param_13 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23079 ; VA 0x00b04246 ; FUN_00b04246 */

void FUN_00b04246(void)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int unaff_EBP;
  undefined uVar5;
  
  uVar5 = 0;
  FUN_005542c0("Objects passed to the CSG API didn\'t have the same DataModel",0x3c);
  FUN_005e65e0(uVar5);
  piVar2 = *(int **)(unaff_EBP + 0xc);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uVar3 = *(uint *)(unaff_EBP + 0x1c);
  *(undefined *)(unaff_EBP + -4) = 0xf;
  if (uVar3 != 0) {
    if (((uVar3 & 1) == 0) && (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uVar3 & 0xfffffffe))(unaff_EBP + 0x24,unaff_EBP + 0x24,2);
    }
    *(undefined4 *)(unaff_EBP + 0x1c) = 0;
  }
  uVar3 = *(uint *)(unaff_EBP + 0x3c);
  *(undefined4 *)(unaff_EBP + -4) = 0x10;
  if (((uVar3 != 0) && ((uVar3 & 1) == 0)) && (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uVar3 & 0xfffffffe))(unaff_EBP + 0x44,unaff_EBP + 0x44,2);
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 23080 ; VA 0x00b045d0 ; FUN_00b045d0 */

void __thiscall FUN_00b045d0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined8 uStack_1b4;
  undefined4 uStack_1ac;
  undefined4 uStack_ec;
  int iStack_e8;
  undefined8 uStack_e4;
  undefined4 uStack_dc;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar1 = *(undefined8 **)(param_1 + 0x44);
  if (puVar1 == (undefined8 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088d870();
    iStack_e8 = 0;
    uStack_e4 = *puVar1;
    uStack_dc = *(undefined4 *)(puVar1 + 1);
    iStack_e8 = FUN_006315b0();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar1 == (undefined8 *)0x0);
  uStack_14 = uVar4;
  uVar2 = FUN_0088d870();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar1 = *(undefined8 **)(param_1 + 0x48);
  if (puVar1 == (undefined8 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_1bc = FUN_0088d870();
    iStack_1b8 = 0;
    uStack_1b4 = *puVar1;
    uStack_1ac = *(undefined4 *)(puVar1 + 1);
    iStack_1b8 = FUN_006315b0();
    puVar5 = &uStack_1bc;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088d870();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(&uStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23081 ; VA 0x00b04810 ; FUN_00b04810 */

void __thiscall FUN_00b04810(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined4 auStack_1b4 [50];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01799280;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_0088daf0();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar4 = *(undefined4 **)(param_1 + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puStack_18 = &uStack_28c;
    uVar3 = 2;
  }
  else {
    uStack_ec = thunk_FUN_00890320();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_00890440();
    puStack_18 = &uStack_ec;
    uVar3 = 1;
  }
  uStack_8 = (uint)(puVar4 == (undefined4 *)0x0);
  uStack_14 = uVar3;
  uVar1 = thunk_FUN_00890320();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar3 & 2) != 0) {
    uVar3 = uVar3 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar3;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if ((uVar3 & 1) != 0) {
    uVar3 = uVar3 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar3;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x48);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar4 = &uStack_35c;
    uStack_8 = 5;
    uVar3 = uVar3 | 8;
  }
  else {
    uStack_1bc = FUN_0088c8c0();
    iStack_1b8 = 0;
    auStack_1b4[0] = *puVar4;
    iStack_1b8 = FUN_005c9cc0();
    puVar4 = &uStack_1bc;
    uStack_8 = 4;
    uVar3 = uVar3 | 4;
  }
  uStack_14 = uVar3;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar4);
  if ((uVar3 & 8) != 0) {
    uVar3 = uVar3 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar3;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar3 & 4) != 0) && (uStack_8 = 7, iStack_1b8 != 0)) {
    (**(code **)(iStack_1b8 + 8))(auStack_1b4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23082 ; VA 0x00b04a30 ; FUN_00b04a30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b04a30(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  int iStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798aa8;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  puStack_18 = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_0088cdc0();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 1;
    uVar6 = 2;
  }
  else {
    uStack_ec = FUN_0088cc80();
    puStack_e8 = (undefined4 *)0x0;
    if (puVar5[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar5[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar5;
    uStack_e0 = puVar5[1];
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eded74)
       && (FUN_016f3809(&DAT_01eded74), DAT_01eded74 == -1)) {
      DAT_01eded68 = FUN_0057bbb0;
      _DAT_01eded6c = FUN_005880a0;
      DAT_01eded70 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01eded74);
    }
    puStack_e8 = &DAT_01eded68;
    puVar5 = &uStack_ec;
    uStack_8 = 0;
    uVar6 = 1;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_0088cc80();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 2) != 0) {
    uVar6 = uVar6 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 1) != 0) {
    uVar6 = uVar6 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  iVar2 = iStack_1c;
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(iStack_1c + 0x48);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar5 = &uStack_1bc;
    uStack_8 = 5;
    uVar6 = uVar6 | 8;
  }
  else {
    uStack_ec = FUN_00b0f580();
    puStack_e8 = (undefined4 *)0x0;
    uStack_e4 = *puVar5;
    puStack_e8 = (undefined4 *)FUN_00b0f8e0();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar6 = uVar6 | 4;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_00b0f580();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 8) != 0) {
    uVar6 = uVar6 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar6;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar6 & 4) != 0) {
    uVar6 = uVar6 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar6;
    if (puStack_e8 != (undefined4 *)0x0) {
      (*(code *)puStack_e8[2])(&uStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(iVar2 + 0x4c);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar5 = &uStack_35c;
    uStack_8 = 9;
    uVar6 = uVar6 | 0x20;
  }
  else {
    uStack_28c = FUN_00b0f830();
    iStack_288 = 0;
    auStack_284[0] = *puVar5;
    iStack_288 = FUN_00b0faa0();
    puVar5 = &uStack_28c;
    uStack_8 = 8;
    uVar6 = uVar6 | 0x10;
  }
  uStack_14 = uVar6;
  uVar3 = FUN_00b0f830();
  uVar4 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar4,uVar3,puVar5);
  if ((uVar6 & 0x20) != 0) {
    uVar6 = uVar6 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar6;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar6 & 0x10) != 0) && (uStack_8 = 0xb, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23083 ; VA 0x00b04dd0 ; FUN_00b04dd0 */

void __fastcall FUN_00b04dd0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if ((DAT_01d69070 == '\0') && (DAT_01d66be0 == '\0')) {
    iVar1 = FUN_008a4100();
    LOCK();
    iVar2 = *(int *)(iVar1 + 0x98) + -1;
    *(int *)(iVar1 + 0x98) = iVar2;
    UNLOCK();
    if (iVar2 != 0) {
      return;
    }
    FUN_00b0a7c0();
    if (DAT_01d66c0c == '\0') {
      return;
    }
  }
  else {
    iVar1 = FUN_008a4100();
    LOCK();
    iVar2 = *(int *)(iVar1 + 0x98) + -1;
    *(int *)(iVar1 + 0x98) = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      FUN_00b0a7c0();
    }
    iVar2 = FUN_008a40f0();
    if (*(int *)(iVar2 + 0x9c) + *(int *)(iVar2 + 0x98) + *(int *)(iVar2 + 0x94) != 0) {
      return;
    }
    FUN_00c184c0(0);
  }
  iVar2 = FUN_00a9d1c0(param_1);
  if (iVar2 != 0) {
    FUN_00ce7ad0(*(undefined4 *)(param_1 + 0xa8));
  }
  return;
}



/* FUNCTION 23084 ; VA 0x00b04e70 ; FUN_00b04e70 */

void __fastcall FUN_00b04e70(int param_1)

{
  int iVar1;
  undefined4 uStack_10;
  
  uStack_10 = (code *)*(undefined8 *)(param_1 + 0x38);
  iVar1 = (*uStack_10)(0);
  if (iVar1 != 0) {
    FUN_016795b0();
  }
  return;
}



/* FUNCTION 23085 ; VA 0x00b04eb0 ; FUN_00b04eb0 */

void FUN_00b04eb0(int param_1,undefined4 param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017bbcf9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  iStack_8 = 0;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_f0 = FUN_0088d550();
  uStack_ec = 0;
  uStack_e8 = param_2;
  uStack_ec = FUN_00631380();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,piVar1);
  iStack_8._0_1_ = 2;
  (*pcVar2)(&uStack_1c);
  iStack_8._0_1_ = 3;
  FUN_00577b20();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  iStack_8 = 4;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23086 ; VA 0x00b04fb0 ; FUN_00b04fb0 */

int FUN_00b04fb0(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017b5e40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_0096e490(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 23087 ; VA 0x00b05080 ; FUN_00b05080 */

void FUN_00b05080(void)

{
  FUN_00b01550();
  return;
}



/* FUNCTION 23088 ; VA 0x00b05090 ; FUN_00b05090 */

undefined8 * FUN_00b05090(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eedc78) {
    FUN_016f3809(&DAT_01eedc78);
    if (DAT_01eedc78 == -1) {
      DAT_01eedc6c._0_4_ = 0;
      DAT_01eedc6c._4_4_ = 0xbf000000;
      DAT_01eedc74 = 0x3f000000;
      FUN_016f37bf(&DAT_01eedc78);
    }
  }
  return &DAT_01eedc6c;
}



/* FUNCTION 23089 ; VA 0x00b05100 ; FUN_00b05100 */

bool __fastcall FUN_00b05100(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iStack_8;
  
  iStack_8 = param_1;
  piVar1 = (int *)(**(code **)(param_1 + 8))(&stack0x00000004);
  piVar2 = (int *)(**(code **)(param_1 + 8))(&iStack_8);
  return *piVar1 == *piVar2;
}



/* FUNCTION 23090 ; VA 0x00b05160 ; FUN_00b05160 */

undefined4 __fastcall FUN_00b05160(int param_1)

{
  char *pcVar1;
  undefined2 *puVar2;
  char cStack00000005;
  undefined auStack_a [3];
  undefined auStack_7 [3];
  
  pcVar1 = (char *)(**(code **)(param_1 + 8))(auStack_7);
  puVar2 = (undefined2 *)(**(code **)(param_1 + 8))(auStack_a);
  if ((((char)*puVar2 == *pcVar1) &&
      (cStack00000005 = (char)((ushort)*puVar2 >> 8), cStack00000005 == pcVar1[1])) &&
     (*(char *)(puVar2 + 1) == pcVar1[2])) {
    return 1;
  }
  return 0;
}



/* FUNCTION 23091 ; VA 0x00b051e0 ; FUN_00b051e0 */

void __fastcall FUN_00b051e0(int param_1)

{
  undefined4 uVar1;
  int iStack_8;
  
  iStack_8 = param_1;
  (**(code **)(param_1 + 8))(&stack0x00000004);
  uVar1 = (**(code **)(param_1 + 8))(&iStack_8);
  FUN_00a33d60(uVar1);
  return;
}



/* FUNCTION 23092 ; VA 0x00b05240 ; FUN_00b05240 */

undefined4 __fastcall FUN_00b05240(int param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = (**(code **)(param_1 + 8))();
  iVar3 = (**(code **)(param_1 + 8))();
  if ((NAN(*(float *)(iVar2 + 0x24)) || NAN(*(float *)(iVar3 + 0x24))) !=
      (*(float *)(iVar2 + 0x24) == *(float *)(iVar3 + 0x24))) {
    if ((NAN(*(float *)(iVar2 + 0x28)) || NAN(*(float *)(iVar3 + 0x28))) !=
        (*(float *)(iVar2 + 0x28) == *(float *)(iVar3 + 0x28))) {
      if ((NAN(*(float *)(iVar2 + 0x2c)) || NAN(*(float *)(iVar3 + 0x2c))) !=
          (*(float *)(iVar2 + 0x2c) == *(float *)(iVar3 + 0x2c))) {
        cVar1 = FUN_01160ab0(iVar3);
        if (cVar1 != '\0') {
          return 1;
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 23093 ; VA 0x00b052d0 ; FUN_00b052d0 */

uint __fastcall FUN_00b052d0(int param_1)

{
  float *pfVar1;
  float fVar2;
  uint3 uVar3;
  char *pcVar4;
  char *pcVar5;
  char *pcVar6;
  undefined2 uVar7;
  
  pcVar4 = (char *)(**(code **)(param_1 + 8))();
  pcVar5 = (char *)(**(code **)(param_1 + 8))();
  pcVar6 = pcVar5;
  if (*pcVar4 == *pcVar5) {
    fVar2 = *(float *)(pcVar4 + 4);
    pfVar1 = (float *)(pcVar5 + 4);
    uVar7 = (undefined2)((uint)pcVar5 >> 0x10);
    pcVar6 = (char *)((uint)CONCAT21(uVar7,(fVar2 == *pfVar1) << 6 |
                                           (NAN(fVar2) || NAN(*pfVar1)) << 2 | 2U | fVar2 < *pfVar1)
                     << 8);
    if ((NAN(fVar2) || NAN(*pfVar1)) != (fVar2 == *pfVar1)) {
      fVar2 = *(float *)(pcVar4 + 0xc);
      pfVar1 = (float *)(pcVar5 + 0xc);
      pcVar6 = (char *)((uint)CONCAT21(uVar7,(fVar2 == *pfVar1) << 6 |
                                             (NAN(fVar2) || NAN(*pfVar1)) << 2 | 2U |
                                             fVar2 < *pfVar1) << 8);
      if ((NAN(fVar2) || NAN(*pfVar1)) != (fVar2 == *pfVar1)) {
        fVar2 = *(float *)(pcVar4 + 8);
        pfVar1 = (float *)(pcVar5 + 8);
        pcVar6 = (char *)((uint)CONCAT21(uVar7,(fVar2 == *pfVar1) << 6 |
                                               (NAN(fVar2) || NAN(*pfVar1)) << 2 | 2U |
                                               fVar2 < *pfVar1) << 8);
        if ((NAN(fVar2) || NAN(*pfVar1)) != (fVar2 == *pfVar1)) {
          fVar2 = *(float *)(pcVar4 + 0x10);
          pfVar1 = (float *)(pcVar5 + 0x10);
          pcVar6 = (char *)((uint)CONCAT21(uVar7,(fVar2 == *pfVar1) << 6 |
                                                 (NAN(fVar2) || NAN(*pfVar1)) << 2 | 2U |
                                                 fVar2 < *pfVar1) << 8);
          if ((NAN(fVar2) || NAN(*pfVar1)) != (fVar2 == *pfVar1)) {
            fVar2 = *(float *)(pcVar4 + 0x14);
            pfVar1 = (float *)(pcVar5 + 0x14);
            uVar3 = CONCAT21(uVar7,(fVar2 == *pfVar1) << 6 | (NAN(fVar2) || NAN(*pfVar1)) << 2 | 2U
                                   | fVar2 < *pfVar1);
            pcVar6 = (char *)((uint)uVar3 << 8);
            if ((NAN(fVar2) || NAN(*pfVar1)) != (fVar2 == *pfVar1)) {
              return CONCAT31(uVar3,1);
            }
          }
        }
      }
    }
  }
  return (uint)pcVar6 & 0xffffff00;
}



/* FUNCTION 23094 ; VA 0x00b05380 ; FUN_00b05380 */

int __fastcall FUN_00b05380(int param_1)

{
  float *pfVar1;
  float fVar2;
  uint3 uVar3;
  float *pfVar4;
  float *pfVar5;
  int iVar6;
  undefined2 uVar7;
  
  pfVar4 = (float *)(**(code **)(param_1 + 8))();
  pfVar5 = (float *)(**(code **)(param_1 + 8))();
  fVar2 = *pfVar4;
  uVar7 = (undefined2)((uint)pfVar5 >> 0x10);
  iVar6 = (uint)CONCAT21(uVar7,(fVar2 == *pfVar5) << 6 | (NAN(fVar2) || NAN(*pfVar5)) << 2 | 2U |
                               fVar2 < *pfVar5) << 8;
  if ((NAN(fVar2) || NAN(*pfVar5)) != (fVar2 == *pfVar5)) {
    fVar2 = pfVar4[1];
    pfVar1 = pfVar5 + 1;
    iVar6 = (uint)CONCAT21(uVar7,(fVar2 == *pfVar1) << 6 | (NAN(fVar2) || NAN(*pfVar1)) << 2 | 2U |
                                 fVar2 < *pfVar1) << 8;
    if ((NAN(fVar2) || NAN(*pfVar1)) != (fVar2 == *pfVar1)) {
      fVar2 = pfVar4[2];
      pfVar5 = pfVar5 + 2;
      uVar3 = CONCAT21(uVar7,(fVar2 == *pfVar5) << 6 | (NAN(fVar2) || NAN(*pfVar5)) << 2 | 2U |
                             fVar2 < *pfVar5);
      iVar6 = (uint)uVar3 << 8;
      if ((NAN(fVar2) || NAN(*pfVar5)) != (fVar2 == *pfVar5)) {
        return CONCAT31(uVar3,1);
      }
    }
  }
  return iVar6;
}



/* FUNCTION 23095 ; VA 0x00b05400 ; FUN_00b05400 */

void __thiscall FUN_00b05400(int param_1,undefined4 param_2,int *param_3,uint param_4)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  uint in_stack_0000002c;
  undefined4 uStack_f8;
  int iStack_f4;
  undefined auStack_f0 [200];
  undefined auStack_28 [4];
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar5 = param_3;
  puStack_c = &LAB_017ed9ab;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  param_3 = (int *)FUN_00b068b0(param_3,param_1 + 0x4c);
  uStack_1c = FUN_00b06680(piVar5,param_1 + 0x48);
  iVar3 = (**(code **)*piVar5)();
  if (iVar3 != 0) {
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_8._0_1_ = 2;
    uStack_f8 = FUN_00888530();
    iStack_f4 = 0;
    uStack_8._0_1_ = 3;
    cVar2 = (**(code **)(*piVar5 + 4))(1,&uStack_f8);
    if (cVar2 != '\0') {
      puVar4 = (undefined4 *)FUN_00889fa0();
      piVar5 = (int *)puVar4[1];
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
        piVar5 = (int *)puVar4[1];
      }
      uStack_18 = *puVar4;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      piStack_14 = piVar5;
      if (iStack_f4 != 0) {
        (**(code **)(iStack_f4 + 8))(auStack_f0);
      }
      FUN_00550b30();
      goto LAB_00b0552d;
    }
    uStack_8._0_1_ = 5;
    if (iStack_f4 != 0) {
      (**(code **)(iStack_f4 + 8))(auStack_f0);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00550b30();
  }
  puVar4 = *(undefined4 **)(param_1 + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    FUN_016756b0(auStack_28,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_28,&DAT_01c17198);
  }
  piVar5 = (int *)puVar4[1];
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = (int *)puVar4[1];
  }
  uStack_18 = *puVar4;
  piStack_14 = piVar5;
LAB_00b0552d:
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_00b02a80(param_2,*(undefined8 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x40),&uStack_18,
               &uStack_1c,&param_3,&param_4,&stack0x0000002c);
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar3 = piVar5[1] + -1;
    piVar5[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 8;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23096 ; VA 0x00b05610 ; FUN_00b05610 */

undefined4 __thiscall FUN_00b05610(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  code *pcStack_40;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017ed9c8;
  pvStack_1c = ExceptionList;
  pcStack_40 = (code *)*(undefined8 *)(param_1 + 0x38);
  ExceptionList = &pvStack_1c;
  uVar3 = (*pcStack_40)(auStack_2c);
  uStack_14 = 0;
  uStack_24 = FUN_009d5730(param_3,uVar3);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_28[1] + -1;
    piStack_28[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piStack_28 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return uStack_24;
}



/* FUNCTION 23097 ; VA 0x00b056c0 ; FUN_00b056c0 */

undefined4 __thiscall FUN_00b056c0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  code *pcStack_40;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017a9308;
  pvStack_1c = ExceptionList;
  pcStack_40 = (code *)*(undefined8 *)(param_1 + 0x38);
  ExceptionList = &pvStack_1c;
  uVar3 = (*pcStack_40)(auStack_2c);
  uStack_14 = 0;
  uStack_24 = FUN_009d5920(param_3,uVar3);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_28[1] + -1;
    piStack_28[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piStack_28 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return uStack_24;
}



/* FUNCTION 23098 ; VA 0x00b05770 ; FUN_00b05770 */

undefined4 __thiscall FUN_00b05770(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  code *pcStack_40;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017a9308;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_01256300(param_3);
  uVar2 = FUN_009d1aa0(param_3,param_4,1,iVar3 - param_4,param_1 + 0x44);
  uStack_24 = CONCAT31(uStack_24._1_3_,uVar2);
  pcStack_40 = (code *)*(undefined8 *)(param_1 + 0x38);
  uVar4 = (*pcStack_40)(auStack_2c,uStack_24);
  uStack_14 = 0;
  uStack_24 = FUN_009d5920(param_3,uVar4);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_28[1] + -1;
    piStack_28[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piStack_28 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return uStack_24;
}



/* FUNCTION 23099 ; VA 0x00b05850 ; FUN_00b05850 */

undefined4 __thiscall FUN_00b05850(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  code *pcStack_40;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017bc228;
  pvStack_1c = ExceptionList;
  pcStack_40 = (code *)*(undefined8 *)(param_1 + 0x38);
  ExceptionList = &pvStack_1c;
  uVar3 = (*pcStack_40)(auStack_2c);
  uStack_14 = 0;
  uStack_24 = FUN_009d5980(param_3,uVar3);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_28[1] + -1;
    piStack_28[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piStack_28 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return uStack_24;
}



/* FUNCTION 23100 ; VA 0x00b05900 ; FUN_00b05900 */

undefined4 __thiscall FUN_00b05900(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  undefined auStack_70 [48];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined4 uStack_18;
  undefined4 uStack_14;
  
  uStack_20 = *(undefined8 *)(param_1 + 0x38);
  puVar1 = (undefined4 *)(*(code *)uStack_20)(auStack_70);
  uStack_20._0_4_ = (code *)*puVar1;
  uStack_20._4_4_ = puVar1[1];
  uStack_18 = puVar1[2];
  uStack_14 = puVar1[3];
  uStack_30 = puVar1[4];
  uStack_2c = puVar1[5];
  uStack_28 = puVar1[6];
  uStack_24 = puVar1[7];
  uStack_40 = puVar1[8];
  uStack_3c = puVar1[9];
  uStack_38 = puVar1[10];
  uStack_34 = puVar1[0xb];
  puVar1 = (undefined4 *)FUN_0087ddc0(param_3,PTR_DAT_01d6d364,0x30,DAT_01ede6d4);
  *puVar1 = (code *)uStack_20;
  puVar1[1] = uStack_20._4_4_;
  puVar1[2] = uStack_18;
  puVar1[3] = uStack_14;
  puVar1[4] = uStack_30;
  puVar1[5] = uStack_2c;
  puVar1[6] = uStack_28;
  puVar1[7] = uStack_24;
  puVar1[8] = uStack_40;
  puVar1[9] = uStack_3c;
  puVar1[10] = uStack_38;
  puVar1[0xb] = uStack_34;
  return 1;
}



/* FUNCTION 23101 ; VA 0x00b059a0 ; FUN_00b059a0 */

undefined4 __thiscall FUN_00b059a0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  undefined8 uVar2;
  int iVar3;
  undefined4 *puVar4;
  code *pcStack_40;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017bc228;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_01256300(param_3);
  puVar4 = (undefined4 *)FUN_009d1340(auStack_2c,param_3,param_4,1,iVar3 - param_4,param_1 + 0x44);
  uVar2 = *(undefined8 *)(param_1 + 0x38);
  uStack_14 = 0;
  if (puVar4[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  pcStack_40 = (code *)uVar2;
  (*pcStack_40)(*puVar4,puVar4[1]);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_28[1] + -1;
    piStack_28[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      piVar1 = piStack_28 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 23102 ; VA 0x00b05a90 ; FUN_00b05a90 */

undefined4 FUN_00b05a90(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  undefined8 *puVar2;
  undefined auStack_40 [12];
  undefined auStack_34 [12];
  undefined8 uStack_28;
  undefined8 *puStack_18;
  int iStack_14;
  
  iVar1 = FUN_01256300(param_2);
  puStack_18 = (undefined8 *)
               FUN_009d16a0(auStack_34,param_2,param_3,2,iVar1 - param_3,iStack_14 + 0x48);
  puVar2 = (undefined8 *)FUN_009d16a0(auStack_40,param_2,param_3,1,iVar1 - param_3,iStack_14 + 0x44)
  ;
  uStack_28 = *(undefined8 *)(iStack_14 + 0x38);
  (*(code *)uStack_28)
            (*puVar2,*(undefined4 *)(puVar2 + 1),*puStack_18,*(undefined4 *)(puStack_18 + 1));
  return 0;
}



/* FUNCTION 23103 ; VA 0x00b05b50 ; FUN_00b05b50 */

undefined4 __thiscall FUN_00b05b50(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined8 *puVar2;
  undefined auStack_2c [12];
  undefined8 uStack_20;
  
  iVar1 = FUN_01256300(param_3);
  puVar2 = (undefined8 *)FUN_009d16a0(auStack_2c,param_3,param_4,1,iVar1 - param_4,param_1 + 0x44);
  uStack_20 = *(undefined8 *)(param_1 + 0x38);
  (*(code *)uStack_20)(*puVar2,*(undefined4 *)(puVar2 + 1));
  return 0;
}



/* FUNCTION 23104 ; VA 0x00b05bd0 ; FUN_00b05bd0 */

undefined4 __thiscall FUN_00b05bd0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  undefined8 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  code *pcStack_40;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017bc228;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar3 = FUN_01256300(param_3);
  puVar4 = (undefined4 *)FUN_009d1340(auStack_2c,param_3,param_4,1,iVar3 - param_4,param_1 + 0x44);
  uVar2 = *(undefined8 *)(param_1 + 0x38);
  uStack_14 = 0;
  if (puVar4[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar4[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  pcStack_40 = (code *)uVar2;
  uVar5 = (*pcStack_40)(*puVar4,puVar4[1]);
  uVar5 = FUN_009d5ac0(param_3,uVar5);
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_28[1] + -1;
    piStack_28[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      iVar3 = piStack_28[2] + -1;
      piStack_28[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_1c;
  return uVar5;
}



/* FUNCTION 23105 ; VA 0x00b05cd0 ; FUN_00b05cd0 */

void FUN_00b05cd0(undefined4 param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uStack_120;
  int iStack_11c;
  undefined auStack_118 [204];
  undefined auStack_4c [12];
  undefined8 uStack_40;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_017ed9f7;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar2 = FUN_01256300(param_2);
  iVar2 = iVar2 - param_3;
  uStack_2c = FUN_009d05b0(param_2,param_3,2,iVar2,iStack_24 + 0x48);
  if (0 < iVar2) {
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eded54)
       && (FUN_016f3809(&DAT_01eded54), DAT_01eded54 == -1)) {
      uStack_14 = 0;
      FUN_0088dcb0();
      FUN_016f3654(&LAB_01880900);
      uStack_14 = 0xffffffff;
      FUN_016f37bf(&DAT_01eded54);
    }
    cVar1 = FUN_009d1e20(&DAT_01edecf0,param_2,param_3 + 1,&uStack_28);
    if (cVar1 != '\0') goto LAB_00b05e1f;
  }
  if (0 < iVar2) {
    uStack_120 = FUN_00888530();
    iStack_11c = 0;
    uStack_14 = 1;
    cVar1 = FUN_009d1bf0(param_2,param_3 + 1,&uStack_120,1);
    if (cVar1 != '\0') {
      puVar3 = (undefined4 *)thunk_FUN_0088c260();
      uStack_28 = *puVar3;
      uStack_14 = 2;
      if (iStack_11c != 0) {
        (**(code **)(iStack_11c + 8))(auStack_118);
      }
      uStack_14 = 0xffffffff;
      goto LAB_00b05e1f;
    }
    uStack_14 = 3;
    if (iStack_11c != 0) {
      (**(code **)(iStack_11c + 8))(auStack_118);
    }
    uStack_14 = 0xffffffff;
  }
  if (*(undefined4 **)(iStack_24 + 0x44) == (undefined4 *)0x0) {
    FUN_016756b0(auStack_4c,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_4c,&DAT_01c17198);
  }
  uStack_28 = **(undefined4 **)(iStack_24 + 0x44);
LAB_00b05e1f:
  uStack_40 = *(undefined8 *)(iStack_24 + 0x38);
  uVar4 = (*(code *)uStack_40)(uStack_28,uStack_2c);
  FUN_009d5ac0(param_2,uVar4);
  ExceptionList = pvStack_1c;
  return;
}



/* FUNCTION 23106 ; VA 0x00b05ee0 ; FUN_00b05ee0 */

void __thiscall FUN_00b05ee0(int param_1,undefined4 param_2,undefined4 param_3)

{
  float10 fVar1;
  undefined4 uStack_20;
  
  uStack_20 = (code *)*(undefined8 *)(param_1 + 0x38);
  fVar1 = (float10)(*uStack_20)();
  FUN_009d5680(param_3,(float)fVar1);
  return;
}



/* FUNCTION 23107 ; VA 0x00b05f40 ; FUN_00b05f40 */

void __fastcall FUN_00b05f40(int param_1)

{
  int iVar1;
  
  iVar1 = FUN_00a9d0e0(param_1);
  if (iVar1 != 0) {
    FUN_00a9a500(*(undefined4 *)(param_1 + 0xa8),0,1,1);
  }
  return;
}



/* FUNCTION 23108 ; VA 0x00b05f70 ; FUN_00b05f70 */

void __thiscall FUN_00b05f70(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = FUN_00a9d0e0(param_1);
  if (iVar1 != 0) {
    FUN_00a9e590();
    FUN_00a97a80(param_1,0,0,param_2);
  }
  return;
}



/* FUNCTION 23109 ; VA 0x00b05fc0 ; FUN_00b05fc0 */

int __fastcall FUN_00b05fc0(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = *(int *)(param_1 + 0x34);
  while( true ) {
    if (iVar1 == 0) {
      return 0;
    }
    iVar2 = FUN_009ba880(iVar1);
    if (iVar2 != 0) break;
    iVar1 = *(int *)(iVar1 + 0x34);
  }
  return iVar2;
}



/* FUNCTION 23110 ; VA 0x00b05fe0 ; FUN_00b05fe0 */

void FUN_00b05fe0(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  
  if ((param_1 == 0) ||
     (iVar2 = *(int *)(param_1 + 0xc), iVar1 = FUN_00b63e30(),
     (uint)*(ushort *)(iVar1 + 0x1da) <
     (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8))) {
    uVar4 = 0;
    iVar2 = FUN_005d6c30();
    if (iVar2 != 0) {
      do {
        FUN_00b06050(*(undefined4 *)(**(int **)(param_1 + 0x2c) + uVar4 * 8),param_2);
        uVar4 = uVar4 + 1;
        uVar3 = FUN_005d6c30();
      } while (uVar4 < uVar3);
    }
  }
  return;
}



/* FUNCTION 23111 ; VA 0x00b06050 ; FUN_00b06050 */

uint FUN_00b06050(int param_1,int param_2)

{
  uint *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 uVar8;
  uint uVar9;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eda20;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    iVar3 = *(int *)(param_1 + 0xc);
    ExceptionList = &pvStack_10;
    iVar5 = FUN_00b63e30();
    if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
        (uint)*(ushort *)(iVar5 + 0x1da)) {
      puVar6 = (undefined4 *)FUN_0060dcd0(auStack_18,param_1);
      uStack_8 = 0;
      puVar4 = *(undefined4 **)(param_2 + 4);
      if (*(undefined4 **)(param_2 + 8) == puVar4) {
        uVar7 = FUN_00603a30(puVar4,puVar6);
      }
      else {
        *puVar4 = 0;
        puVar4[1] = 0;
        *puVar4 = *puVar6;
        uVar7 = puVar6[1];
        puVar4[1] = uVar7;
        *puVar6 = 0;
        puVar6[1] = 0;
        *(int *)(param_2 + 4) = *(int *)(param_2 + 4) + 8;
      }
      if (piStack_14 == (int *)0x0) {
        ExceptionList = pvStack_10;
        return uVar7;
      }
      LOCK();
      puVar1 = (uint *)(piStack_14 + 1);
      uVar7 = *puVar1;
      uVar9 = *puVar1;
      *puVar1 = uVar7 - 1;
      UNLOCK();
      if (uVar7 - 1 != 0) {
        ExceptionList = pvStack_10;
        return uVar9;
      }
      uVar7 = (**(code **)*piStack_14)();
      LOCK();
      piVar2 = piStack_14 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 != 1) {
        ExceptionList = pvStack_10;
        return uVar7;
      }
      uVar7 = (**(code **)(*piStack_14 + 4))();
      ExceptionList = pvStack_10;
      return uVar7;
    }
    iVar3 = *(int *)(param_1 + 0xc);
    iVar5 = FUN_00aff8c0();
    if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
        (uint)*(ushort *)(iVar5 + 0x1da)) {
      uVar8 = FUN_0060dcd0(auStack_20,param_1);
      uStack_8 = 1;
      FUN_008a4660(uVar8);
      uStack_8 = 0xffffffff;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar2 = piStack_1c + 2;
          iVar3 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
    }
  }
  uVar9 = 0;
  uVar7 = FUN_005d6c30();
  if (uVar7 != 0) {
    do {
      FUN_00b06050(*(undefined4 *)(**(int **)(param_1 + 0x2c) + uVar9 * 8),param_2);
      uVar9 = uVar9 + 1;
      uVar7 = FUN_005d6c30();
    } while (uVar9 < uVar7);
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 23112 ; VA 0x00b061f0 ; FUN_00b061f0 */

void FUN_00b061f0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eda40;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((param_1 != 0) &&
     (iVar4 = *(int *)(param_1 + 0xc), ExceptionList = &pvStack_10, iVar2 = FUN_00aff8c0(),
     (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
     (uint)*(ushort *)(iVar2 + 0x1da))) {
    puVar3 = (undefined4 *)FUN_0060dcd0(auStack_20,param_1);
    piStack_14 = (int *)puVar3[1];
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[2] = piStack_14[2] + 1;
      UNLOCK();
      piStack_14 = (int *)puVar3[1];
    }
    uStack_18 = *puVar3;
    puVar3 = *(undefined4 **)(param_2 + 4);
    uStack_8 = 1;
    if (*(undefined4 **)(param_2 + 8) == puVar3) {
      FUN_006ce750(puVar3,&uStack_18);
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_14[2] + -1;
        piStack_14[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    else {
      *puVar3 = uStack_18;
      puVar3[1] = piStack_14;
      *(int *)(param_2 + 4) = *(int *)(param_2 + 4) + 8;
    }
    uStack_8 = 0xffffffff;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piStack_1c + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  uVar6 = 0;
  iVar4 = FUN_005d6c30();
  if (iVar4 != 0) {
    do {
      FUN_00b061f0(*(undefined4 *)(**(int **)(param_1 + 0x2c) + uVar6 * 8),param_2);
      uVar6 = uVar6 + 1;
      uVar5 = FUN_005d6c30();
    } while (uVar6 < uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23113 ; VA 0x00b06320 ; FUN_00b06320 */

int __thiscall FUN_00b06320(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  code *pcStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017eda60;
  pvStack_10 = ExceptionList;
  param_3 = (int *)*param_3;
  iVar3 = *param_3;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0088cdc0();
  if (iVar3 == iVar1) {
    piVar2 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar2 = (int *)0x0;
    }
    piVar4 = (int *)piVar2[1];
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)piVar2[1];
    }
    iVar3 = *piVar2;
    uStack_8 = 0;
    pcStack_24 = (code *)*(undefined8 *)(param_1 + 0x38);
    (*pcStack_24)(1);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    piVar2 = piVar4 + 1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      *piVar2 = *piVar2 + 1;
      UNLOCK();
    }
    iVar3 = FUN_0089be10(iVar3,piVar4);
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar1 = *piVar2;
      iVar3 = *piVar2;
      *piVar2 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar3 = (**(code **)*piVar4)();
        LOCK();
        piVar2 = piVar4 + 2;
        iVar1 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          iVar3 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return iVar3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23114 ; VA 0x00b06430 ; FUN_00b06430 */

void __thiscall FUN_00b06430(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  code *pcStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  param_3 = (int *)*param_3;
  iVar3 = *param_3;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0088cdc0();
  if (iVar3 == iVar1) {
    piVar2 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar2 = (int *)0x0;
    }
    iVar3 = piVar2[1];
    if (iVar3 != 0) {
      LOCK();
      *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
      UNLOCK();
      iVar3 = piVar2[1];
    }
    iVar1 = *piVar2;
    uStack_8 = 0;
    pcStack_24 = (code *)*(undefined8 *)(param_1 + 0x38);
    (*pcStack_24)(1);
    FUN_00b018a0(iVar1,iVar3);
    ExceptionList = pvStack_10;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23115 ; VA 0x00b064f0 ; FUN_00b064f0 */

void __thiscall FUN_00b064f0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  code *pcStack_10;
  
  param_3 = (int *)*param_3;
  iVar1 = *param_3;
  iVar2 = FUN_0088d550();
  if (iVar1 == iVar2) {
    piVar3 = param_3 + 2;
    if (param_3[1] == 0) {
      piVar3 = (int *)0x0;
    }
    iVar1 = *piVar3;
    pcStack_10 = (code *)*(undefined8 *)(param_1 + 0x38);
    (*pcStack_10)(1);
    FUN_00b017d0(iVar1);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23116 ; VA 0x00b06560 ; FUN_00b06560 */

void __fastcall FUN_00b06560(int param_1)

{
  undefined4 uStack_10;
  
  uStack_10 = (code *)*(undefined8 *)(param_1 + 0x38);
  (*uStack_10)(1);
  FUN_006eccd0();
  return;
}



/* FUNCTION 23117 ; VA 0x00b065a0 ; FUN_00b065a0 */

void FUN_00b065a0(void)

{
  int iVar1;
  undefined **ppuStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017eda78;
  pvStack_10 = ExceptionList;
  ppuStack_14 = RBX::Instance::OutfitChangedSignalData::vftable;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_006150c0(4,&ppuStack_14);
  iVar1 = FUN_008a40f0();
  if (iVar1 != 0) {
    FUN_008a4100();
    FUN_006eccd0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23118 ; VA 0x00b06610 ; FUN_00b06610 */

uint FUN_00b06610(void)

{
  int iVar1;
  
  iVar1 = FUN_00ca1550();
  if (iVar1 != 0) {
    return -(uint)(*(int *)(iVar1 + 0x1b0) != 0) & *(int *)(iVar1 + 0x1b0) - 0x58U;
  }
  return 0;
}



/* FUNCTION 23119 ; VA 0x00b06640 ; FUN_00b06640 */

uint FUN_00b06640(int param_1)

{
  if (param_1 != 0) {
    return -(uint)(*(int *)(param_1 + 0x1b0) != 0) & *(int *)(param_1 + 0x1b0) - 0x58U;
  }
  return 0;
}



/* FUNCTION 23120 ; VA 0x00b06660 ; FUN_00b06660 */

undefined4 FUN_00b06660(undefined4 *param_1)

{
  return *param_1;
}



/* FUNCTION 23121 ; VA 0x00b06670 ; FUN_00b06670 */

undefined4 __fastcall FUN_00b06670(int param_1)

{
  return CONCAT31((int3)((uint)*(int *)(param_1 + 0xa8) >> 8),
                  *(undefined *)(*(int *)(param_1 + 0xa8) + 0x223));
}



/* FUNCTION 23122 ; VA 0x00b06680 ; FUN_00b06680 */

int * FUN_00b06680(int *param_1,int *param_2)

{
  code *pcVar1;
  int *piVar2;
  char cVar3;
  uint uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  int iVar9;
  undefined4 uVar10;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = (**(code **)*param_1)();
  if (uVar4 < 2) {
LAB_00b06827:
    if ((undefined4 *)*param_2 != (undefined4 *)0x0) {
      ExceptionList = pvStack_10;
      return *(int **)*param_2;
    }
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",2);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  pcVar1 = *(code **)(*piVar2 + 0x38);
  uVar5 = FUN_00b0f580();
  cVar3 = (*pcVar1)(2,uVar5,&param_1);
  if (cVar3 != '\0') {
    ExceptionList = pvStack_10;
    return param_1;
  }
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar3 = (**(code **)(*piVar2 + 4))(2,&iStack_ec);
  iVar9 = iStack_ec;
  if (cVar3 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
    goto LAB_00b06827;
  }
  iVar6 = FUN_00b0f580();
  iVar8 = iStack_ec;
  if (iVar9 == iVar6) {
    puVar7 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    if (puVar7 != (undefined4 *)0x0) goto LAB_00b067d2;
  }
  iVar6 = FUN_0088cb40();
  iVar9 = iStack_ec;
  if (iVar8 == iVar6) {
    iVar8 = FUN_0088cb40();
    if (iVar9 != iVar8) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar7 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    FUN_00b0f580();
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    cVar3 = FUN_009cb180(puVar7,&param_1);
    if (cVar3 != '\0') {
      FUN_00aff820(&param_1);
      iVar9 = FUN_00b0f580();
      iStack_ec = iVar9;
      iVar8 = FUN_00b0f580();
      if (iVar9 != iVar8) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar7 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar7 = (undefined4 *)0x0;
      }
LAB_00b067d2:
      piVar2 = (int *)*puVar7;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return piVar2;
    }
  }
  thunk_FUN_00b0f580();
  uVar5 = FUN_005543f0();
  uVar10 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar10,uVar5);
}



/* FUNCTION 23123 ; VA 0x00b068b0 ; FUN_00b068b0 */

int * FUN_00b068b0(int *param_1,int *param_2)

{
  code *pcVar1;
  int *piVar2;
  char cVar3;
  uint uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  int iVar9;
  undefined4 uVar10;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = (**(code **)*param_1)();
  if (uVar4 < 3) {
LAB_00b06a57:
    if ((undefined4 *)*param_2 != (undefined4 *)0x0) {
      ExceptionList = pvStack_10;
      return *(int **)*param_2;
    }
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",3);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  pcVar1 = *(code **)(*piVar2 + 0x38);
  uVar5 = FUN_00b0f830();
  cVar3 = (*pcVar1)(3,uVar5,&param_1);
  if (cVar3 != '\0') {
    ExceptionList = pvStack_10;
    return param_1;
  }
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar3 = (**(code **)(*piVar2 + 4))(3,&iStack_ec);
  iVar9 = iStack_ec;
  if (cVar3 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
    goto LAB_00b06a57;
  }
  iVar6 = FUN_00b0f830();
  iVar8 = iStack_ec;
  if (iVar9 == iVar6) {
    puVar7 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    if (puVar7 != (undefined4 *)0x0) goto LAB_00b06a02;
  }
  iVar6 = FUN_0088cb40();
  iVar9 = iStack_ec;
  if (iVar8 == iVar6) {
    iVar8 = FUN_0088cb40();
    if (iVar9 != iVar8) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar7 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    FUN_00b0f830();
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    cVar3 = FUN_009cb180(puVar7,&param_1);
    if (cVar3 != '\0') {
      FUN_00aff870(&param_1);
      iVar9 = FUN_00b0f830();
      iStack_ec = iVar9;
      iVar8 = FUN_00b0f830();
      if (iVar9 != iVar8) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar7 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar7 = (undefined4 *)0x0;
      }
LAB_00b06a02:
      piVar2 = (int *)*puVar7;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return piVar2;
    }
  }
  thunk_FUN_00b0f830();
  uVar5 = FUN_005543f0();
  uVar10 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar10,uVar5);
}



/* FUNCTION 23124 ; VA 0x00b06ae0 ; FUN_00b06ae0 */

void __thiscall FUN_00b06ae0(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  int iVar2;
  
  if ((DAT_01d66c24 != '\0') && (*(int *)(*(int *)(param_1 + 0xa8) + 0x1a8) != 0)) {
    iVar2 = FUN_00c155c0();
    if (iVar2 == 0) {
      iVar2 = FUN_00c157b0();
      uVar1 = *(undefined4 *)(iVar2 + 0x44);
      *param_2 = *(undefined8 *)(iVar2 + 0x3c);
      *(undefined4 *)(param_2 + 1) = uVar1;
      return;
    }
    iVar2 = FUN_00c157b0();
    uVar1 = *(undefined4 *)(iVar2 + 0x44);
    *param_2 = *(undefined8 *)(iVar2 + 0x3c);
    *(undefined4 *)(param_2 + 1) = uVar1;
    return;
  }
  *(undefined4 *)param_2 = 0;
  *(undefined4 *)((int)param_2 + 4) = 0;
  *(undefined4 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 23125 ; VA 0x00b06b70 ; FUN_00b06b70 */

float * __thiscall FUN_00b06b70(int param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float *pfVar10;
  undefined8 *puVar11;
  float fStack_10;
  float fStack_c;
  
  if (DAT_01d66c24 == '\0') {
    *param_2 = 0.0;
    param_2[1] = 0.0;
    param_2[2] = 0.0;
    return param_2;
  }
  if ((DAT_01d66c2c != '\0') && (*(int *)(*(int *)(param_1 + 0xa8) + 0x1a8) == 0)) {
    pfVar10 = (float *)FUN_00c157b0();
    fVar1 = pfVar10[6];
    fVar2 = pfVar10[3];
    puVar11 = (undefined8 *)(*(int *)(param_1 + 0xa8) + 200);
    if (*(int *)(param_1 + 0xa8) == 0) {
      puVar11 = (undefined8 *)0x78;
    }
    fVar9 = *(float *)(puVar11 + 1);
    fVar3 = pfVar10[7];
    fStack_10 = (float)*puVar11;
    fStack_c = (float)((ulonglong)*puVar11 >> 0x20);
    fVar4 = pfVar10[8];
    fVar5 = pfVar10[4];
    fVar6 = pfVar10[5];
    fVar7 = pfVar10[0xb];
    fVar8 = pfVar10[10];
    *param_2 = pfVar10[1] * fStack_c + *pfVar10 * fStack_10 + pfVar10[2] * fVar9 + pfVar10[9];
    param_2[1] = fVar2 * fStack_10 + fVar5 * fStack_c + fVar6 * fVar9 + fVar8;
    param_2[2] = fVar1 * fStack_10 + fVar3 * fStack_c + fVar4 * fVar9 + fVar7;
    return param_2;
  }
  FUN_00f9fa40(param_2);
  return param_2;
}



/* FUNCTION 23126 ; VA 0x00b06cb0 ; FUN_00b06cb0 */

void __thiscall FUN_00b06cb0(int param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  undefined8 uVar3;
  float fVar4;
  float fVar5;
  int iVar6;
  int iVar7;
  undefined8 *puVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fStack_10;
  float fStack_c;
  
  if ((DAT_01d66c24 != '\0') && (iVar7 = *(int *)(param_1 + 0xa8), *(int *)(iVar7 + 0x1a8) != 0)) {
    iVar6 = FUN_00c155c0();
    if (iVar6 == 0) {
      iVar7 = FUN_00c157b0();
      fVar4 = *(float *)(iVar7 + 0x38);
      *(undefined8 *)param_2 = *(undefined8 *)(iVar7 + 0x30);
      param_2[2] = fVar4;
      return;
    }
    iVar7 = *(int *)(iVar7 + 0x70);
    puVar8 = (undefined8 *)FUN_00f9fa20();
    uVar3 = *puVar8;
    fVar5 = *(float *)(puVar8 + 1);
    FUN_00fa07b0();
    fStack_10 = (float)uVar3;
    fStack_c = (float)((ulonglong)uVar3 >> 0x20);
    fVar4 = *(float *)(iVar7 + 0xf4);
    fVar11 = *(float *)(iVar7 + 0xc0) * fStack_10 + *(float *)(iVar7 + 0xc4) * fStack_c +
             *(float *)(iVar7 + 200) * fVar5;
    fVar1 = *(float *)(iVar7 + 0xf0);
    fVar10 = *(float *)(iVar7 + 0xd0) * fStack_c + *(float *)(iVar7 + 0xcc) * fStack_10 +
             *(float *)(iVar7 + 0xd4) * fVar5;
    fVar2 = *(float *)(iVar7 + 0xf8);
    fVar9 = *(float *)(iVar7 + 0xb8) * fStack_c + fStack_10 * *(float *)(iVar7 + 0xb4) +
            *(float *)(iVar7 + 0xbc) * fVar5;
    *param_2 = (fVar4 * fVar10 - fVar2 * fVar11) + *(float *)(iVar7 + 0xe4);
    fVar5 = *(float *)(iVar7 + 0xe8);
    param_2[2] = (fVar1 * fVar11 - fVar4 * fVar9) + *(float *)(iVar7 + 0xec);
    param_2[1] = (fVar2 * fVar9 - fVar1 * fVar10) + fVar5;
    return;
  }
  *param_2 = 0.0;
  param_2[1] = 0.0;
  param_2[2] = 0.0;
  return;
}



/* FUNCTION 23127 ; VA 0x00b06e60 ; FUN_00b06e60 */

float10 __fastcall FUN_00b06e60(int param_1)

{
  int iVar1;
  int iVar2;
  float10 fVar3;
  
  if (DAT_01d66c24 == '\0') {
    return (float10)0;
  }
  if (*(int *)(*(int *)(param_1 + 0xa8) + 0x1a8) == 0) {
    fVar3 = (float10)FUN_00c15620(param_1);
    return fVar3;
  }
  iVar1 = *(int *)(*(int *)(param_1 + 0xa8) + 0x70);
  if (*(char *)(iVar1 + 0x3d) != '\0') {
    return (float10)DAT_018e0028;
  }
  iVar2 = *(int *)(iVar1 + 0x24);
  if (iVar2 != 0) {
    if (*(char *)(iVar2 + 4) != '\0') {
      FUN_00f958d0();
    }
    return (float10)*(float *)(iVar2 + 0x14);
  }
  if ((*(char *)(iVar1 + 0x3c) != '\0') && (*(int *)(iVar1 + 0x20) != iVar1)) {
    return (float10)0.0;
  }
  return (float10)*(float *)(iVar1 + 0x84);
}



/* FUNCTION 23128 ; VA 0x00b06f00 ; FUN_00b06f00 */

undefined4 __fastcall FUN_00b06f00(int param_1)

{
  return CONCAT31((int3)((uint)*(int *)(param_1 + 0xa8) >> 8),
                  *(char *)(*(int *)(param_1 + 0xa8) + 0x225) == '\0');
}



/* FUNCTION 23129 ; VA 0x00b06f40 ; FUN_00b06f40 */

undefined __fastcall FUN_00b06f40(int param_1)

{
  return *(undefined *)(param_1 + 0xcb);
}



/* FUNCTION 23130 ; VA 0x00b06f50 ; FUN_00b06f50 */

void __thiscall FUN_00b06f50(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)(*(int *)(param_1 + 0xa8) + 200);
  if (*(int *)(param_1 + 0xa8) == 0) {
    puVar2 = (undefined8 *)0x78;
  }
  uVar1 = *(undefined4 *)(puVar2 + 1);
  *param_2 = *puVar2;
  *(undefined4 *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 23131 ; VA 0x00b06f80 ; FUN_00b06f80 */

undefined4 __fastcall FUN_00b06f80(int param_1)

{
  undefined4 uVar1;
  
  if (*(int *)(param_1 + 0xa8) == 0) {
    return 0;
  }
  uVar1 = FUN_00ff4d00(*(int *)(param_1 + 0xa8));
  return uVar1;
}



/* FUNCTION 23132 ; VA 0x00b06fa0 ; FUN_00b06fa0 */

undefined4 __fastcall FUN_00b06fa0(int param_1)

{
  return CONCAT31((int3)((uint)*(int *)(param_1 + 0xa8) >> 8),
                  *(undefined *)(*(int *)(param_1 + 0xa8) + 0x22a));
}



/* FUNCTION 23133 ; VA 0x00b06fb0 ; FUN_00b06fb0 */

undefined4 __thiscall FUN_00b06fb0(int param_1,undefined4 param_2)

{
  FUN_0115e8a0(param_1 + 200);
  return param_2;
}



/* FUNCTION 23134 ; VA 0x00b06fd0 ; FUN_00b06fd0 */

void __thiscall FUN_00b06fd0(int param_1,undefined2 *param_2)

{
  undefined uVar1;
  
  uVar1 = *(undefined *)(param_1 + 0xca);
  *param_2 = *(undefined2 *)(param_1 + 200);
  *(undefined *)(param_2 + 1) = uVar1;
  return;
}



/* FUNCTION 23135 ; VA 0x00b06ff0 ; FUN_00b06ff0 */

undefined4 __thiscall FUN_00b06ff0(int param_1,undefined4 param_2)

{
  FUN_00c98900(param_2,*(undefined3 *)(param_1 + 200));
  return param_2;
}



/* FUNCTION 23136 ; VA 0x00b07020 ; FUN_00b07020 */

void __thiscall FUN_00b07020(uint param_1,int *param_2,uint param_3)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  undefined4 uVar6;
  uint uVar7;
  int iVar8;
  byte bStack_4c;
  undefined auStack_4b [3];
  undefined4 uStack_48;
  int iStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 *puStack_34;
  undefined4 *puStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int iStack_20;
  int iStack_1c;
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edae0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_18 = param_1;
  iVar3 = FUN_00a9d0e0(param_1);
  if (iVar3 == 0) {
    uStack_14 = 0;
  }
  else {
    uStack_14 = FUN_00a9d3e0();
  }
  FUN_0088dc10(&iStack_20);
  iVar3 = iStack_20;
  uStack_8 = 0;
  if ((char)param_3 == '\0') {
    puVar4 = (undefined4 *)FUN_0060dcd0(&puStack_30,param_1);
    uStack_28 = *puVar4;
    piStack_24 = (int *)puVar4[1];
    *puVar4 = 0;
    puVar4[1] = 0;
    puVar4 = *(undefined4 **)(iVar3 + 4);
    uStack_8._0_1_ = 2;
    if (*(undefined4 **)(iVar3 + 8) == puVar4) {
      FUN_00603a30(puVar4,&uStack_28);
      piVar5 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar3 = *piVar1 + -1;
          *piVar1 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
    else {
      *puVar4 = uStack_28;
      puVar4[1] = piStack_24;
      *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 8;
    }
    piVar5 = piStack_2c;
    uStack_8 = (uint)uStack_8._1_3_ << 8;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    iVar8 = 0;
    iVar3 = *(int *)(uStack_18 + 0xa8);
    if (0 < *(int *)(iVar3 + 0x1d4) - *(int *)(iVar3 + 0x1d0) >> 3) {
      do {
        param_3 = *(int *)(*(int *)(iVar3 + 0x1d0) + 4 + iVar8 * 8);
        if (((param_3 != 0) &&
            (uVar7 = -(uint)(*(int *)(param_3 + 0x1b0) != 0) & *(int *)(param_3 + 0x1b0) - 0x58U,
            uVar7 != 0)) && (uVar7 != uStack_14)) {
          piVar5 = (int *)FUN_00c156d0(iVar8);
          iVar3 = (**(code **)(*piVar5 + 0x10))();
          if (iVar3 - 1U < 6) {
            puVar4 = (undefined4 *)
                     FUN_0060dcd0(&puStack_30,
                                  -(uint)(*(int *)(param_3 + 0x1b0) != 0) &
                                  *(int *)(param_3 + 0x1b0) - 0x58U);
            uStack_28 = *puVar4;
            piStack_24 = (int *)puVar4[1];
            *puVar4 = 0;
            puVar4[1] = 0;
            uStack_8 = CONCAT31(uStack_8._1_3_,4);
            FUN_008a4660(&uStack_28);
            piVar5 = piStack_24;
            if (piStack_24 != (int *)0x0) {
              LOCK();
              iVar3 = piStack_24[1] + -1;
              piStack_24[1] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)*piStack_24)();
                LOCK();
                piVar1 = piVar5 + 2;
                iVar3 = *piVar1 + -1;
                *piVar1 = iVar3;
                UNLOCK();
                if (iVar3 == 0) {
                  (**(code **)(*piVar5 + 4))();
                }
              }
            }
            piVar5 = piStack_2c;
            uStack_8 = uStack_8 & 0xffffff00;
            if (piStack_2c != (int *)0x0) {
              LOCK();
              iVar3 = piStack_2c[1] + -1;
              piStack_2c[1] = iVar3;
              UNLOCK();
              if (iVar3 == 0) {
                (**(code **)*piStack_2c)();
                LOCK();
                piVar1 = piVar5 + 2;
                iVar3 = *piVar1 + -1;
                *piVar1 = iVar3;
                UNLOCK();
                if (iVar3 == 0) {
                  (**(code **)(*piVar5 + 4))();
                }
              }
            }
          }
        }
        iVar8 = iVar8 + 1;
        iVar3 = *(int *)(uStack_18 + 0xa8);
      } while (iVar8 < *(int *)(iVar3 + 0x1d4) - *(int *)(iVar3 + 0x1d0) >> 3);
    }
  }
  else if ((*(int *)(param_1 + 0xa8) != 0) && (iVar3 = FUN_00c155c0(), iVar3 != 0)) {
    FUN_00c155c0();
    cVar2 = FUN_00ca0f40();
    if (cVar2 == '\0') {
      FUN_00c155c0();
      param_3 = CONCAT31(param_3._1_3_,DAT_01eeccf4);
      FUN_00557fc0(&iStack_20);
      FUN_00889110(&puStack_34,FUN_00b07700,param_3);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      uVar6 = FUN_00ca1550();
      if (piStack_2c != (int *)0x0) {
        LOCK();
        piStack_2c[1] = piStack_2c[1] + 1;
        UNLOCK();
      }
      FUN_00b004e0(puStack_34,puStack_30,piStack_2c,uVar6,0);
      if (piStack_2c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_2c[1] + -1;
        piStack_2c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_2c)();
          LOCK();
          piVar5 = piStack_2c + 2;
          iVar3 = *piVar5;
          *piVar5 = *piVar5 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piStack_2c + 4))();
          }
        }
      }
    }
    else {
      bStack_4c = 0;
      uStack_48 = FUN_00588320(0xb);
      iStack_44 = 0;
      uStack_40 = 0x3f800000;
      uStack_3c = 0;
      uStack_38 = 0;
      uStack_8._0_1_ = 6;
      puVar4 = (undefined4 *)FUN_0060dcd0(&puStack_30,param_1);
      uStack_28 = *puVar4;
      piStack_24 = (int *)puVar4[1];
      *puVar4 = 0;
      puVar4[1] = 0;
      uStack_8._0_1_ = 8;
      FUN_008a4660(&uStack_28);
      FUN_00550b30();
      uStack_8._0_1_ = 6;
      FUN_00550b30();
      iVar3 = (param_1 >> 3) + param_1;
      param_3 = param_1;
      FUN_00606ea0(&uStack_18,iVar3,&param_3,
                   -(uint)(auStack_4b + bStack_4c != (undefined *)0x0) &
                   (uint)(auStack_4b + bStack_4c + 1));
      if (uStack_18 == 0) {
        puStack_34 = &uStack_48;
        puStack_30 = (undefined4 *)0x0;
        uStack_8._0_1_ = 9;
        piStack_2c = (int *)((uint)piStack_2c & 0xffff0000);
        puStack_30 = (undefined4 *)FUN_01674e20(0xc);
        piStack_2c = (int *)CONCAT22(piStack_2c._2_2_,0x101);
        *puStack_30 = 0;
        puStack_30[1] = 0;
        puStack_30[2] = param_1;
        FUN_005d99d0(iStack_44 + 1);
        FUN_005c5550(&param_3,&puStack_34,iVar3);
        uStack_8._0_1_ = 6;
        if (puStack_30 != (undefined4 *)0x0) {
          FUN_01674ea0(puStack_30,0xc);
        }
      }
      FUN_00b07490(&iStack_20,&bStack_4c);
      FUN_006e27a0();
    }
  }
  *param_2 = iStack_20;
  param_2[1] = iStack_1c;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23137 ; VA 0x00b07490 ; FUN_00b07490 */

void __thiscall FUN_00b07490(int param_1,undefined4 param_2,byte *param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uStack_48;
  undefined4 *puStack_44;
  undefined2 uStack_40;
  undefined auStack_3c [4];
  int *piStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  undefined auStack_2c [4];
  int iStack_28;
  int iStack_24;
  int iStack_20;
  uint uStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edb08;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_28 = param_1;
  iVar2 = FUN_00a9bfa0(param_1);
  if (iVar2 == 0) {
    uStack_1c = 0;
  }
  else {
    uStack_1c = FUN_00a9d3e0();
  }
  iVar2 = *(int *)(param_1 + 0xa8);
  iStack_14 = 0;
  if (0 < *(int *)(iVar2 + 0x1d4) - *(int *)(iVar2 + 0x1d0) >> 3) {
    do {
      iVar6 = iStack_14;
      uVar7 = uStack_1c;
      iVar2 = *(int *)(*(int *)(iVar2 + 0x1d0) + 4 + iStack_14 * 8);
      if (iVar2 != 0) {
        piVar3 = (int *)FUN_00c156d0(iStack_14);
        iVar4 = (**(code **)(*piVar3 + 0x10))();
        if ((((iVar4 - 1U < 6) && (iVar2 = *(int *)(iVar2 + 0x1b0), iVar2 != 0)) &&
            (uVar8 = iVar2 - 0x58, uStack_18 = uVar8, uVar8 != 0)) && (uVar8 != uVar7)) {
          uVar7 = -(uint)(param_3 + *param_3 + 1 != (byte *)0x0) &
                  (uint)(param_3 + *param_3 + 1 + 1);
          iVar2 = (uVar8 >> 3) + uVar8;
          FUN_00606ea0(&iStack_20,iVar2,&uStack_18,uVar7);
          iVar6 = iStack_14;
          if (iStack_20 == 0) {
            FUN_00606ea0(&iStack_24,iVar2,&uStack_18,uVar7);
            if (iStack_24 == 0) {
              puStack_44 = (undefined4 *)0x0;
              uStack_48 = -(uint)(param_3 != (byte *)0xfffffffd) & (uint)(param_3 + 4);
              uStack_8 = 0;
              uStack_40 = 0;
              puStack_44 = (undefined4 *)FUN_01674e20(0xc);
              uStack_40 = 0x101;
              *puStack_44 = 0;
              puStack_44[1] = 0;
              puStack_44[2] = uVar8;
              FUN_005d99d0(*(int *)(param_3 + 8) + 1);
              FUN_005c5550(auStack_2c,&uStack_48,iVar2);
              uStack_8 = 0xffffffff;
              if (puStack_44 != (undefined4 *)0x0) {
                FUN_01674ea0(puStack_44,0xc);
              }
            }
            puVar5 = (undefined4 *)FUN_0060dcd0(auStack_3c,uVar8);
            uStack_34 = *puVar5;
            piStack_30 = (int *)puVar5[1];
            *puVar5 = 0;
            puVar5[1] = 0;
            uStack_8 = 2;
            FUN_008a4660(&uStack_34);
            piVar3 = piStack_30;
            if (piStack_30 != (int *)0x0) {
              LOCK();
              iVar2 = piStack_30[1] + -1;
              piStack_30[1] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)*piStack_30)();
                LOCK();
                piVar1 = piVar3 + 2;
                iVar2 = *piVar1 + -1;
                *piVar1 = iVar2;
                UNLOCK();
                if (iVar2 == 0) {
                  (**(code **)(*piVar3 + 4))();
                }
              }
            }
            piVar3 = piStack_38;
            uStack_8 = 0xffffffff;
            if (piStack_38 != (int *)0x0) {
              LOCK();
              iVar2 = piStack_38[1] + -1;
              piStack_38[1] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)*piStack_38)();
                LOCK();
                piVar1 = piVar3 + 2;
                iVar2 = *piVar1 + -1;
                *piVar1 = iVar2;
                UNLOCK();
                if (iVar2 == 0) {
                  (**(code **)(*piVar3 + 4))();
                }
              }
            }
            FUN_00b07490(param_2,param_3);
            iVar6 = iStack_14;
          }
        }
      }
      iStack_14 = iVar6 + 1;
      iVar2 = *(int *)(iStack_28 + 0xa8);
    } while (iStack_14 < *(int *)(iVar2 + 0x1d4) - *(int *)(iVar2 + 0x1d0) >> 3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23138 ; VA 0x00b07700 ; FUN_00b07700 */

void * FUN_00b07700(int param_1)

{
  uint *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  void *pvVar5;
  uint uVar6;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edb30;
  pvStack_10 = ExceptionList;
  pvVar5 = ExceptionList;
  if (param_1 != 0) {
    pvVar5 = (void *)(*(int *)(param_1 + 0x1b0) - 0x58);
    uVar6 = -(uint)(*(int *)(param_1 + 0x1b0) != 0) & (uint)pvVar5;
    if (uVar6 != 0) {
      ExceptionList = &pvStack_10;
      puVar4 = (undefined4 *)FUN_0060dcd0(auStack_20,uVar6);
      uStack_18 = *puVar4;
      piStack_14 = (int *)puVar4[1];
      *puVar4 = 0;
      puVar4[1] = 0;
      uStack_8 = 1;
      pvVar5 = (void *)FUN_008a4660(&uStack_18);
      piVar2 = piStack_14;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        puVar1 = (uint *)(piStack_14 + 1);
        uVar6 = *puVar1;
        pvVar5 = (void *)*puVar1;
        *puVar1 = uVar6 - 1;
        UNLOCK();
        if (uVar6 - 1 == 0) {
          (**(code **)*piStack_14)();
          LOCK();
          puVar1 = (uint *)(piVar2 + 2);
          uVar6 = *puVar1;
          pvVar5 = (void *)*puVar1;
          *puVar1 = uVar6 - 1;
          UNLOCK();
          if (uVar6 - 1 == 0) {
            pvVar5 = (void *)(**(code **)(*piVar2 + 4))();
          }
        }
      }
      if (piStack_1c != (int *)0x0) {
        LOCK();
        puVar1 = (uint *)(piStack_1c + 1);
        uVar6 = *puVar1;
        pvVar5 = (void *)*puVar1;
        *puVar1 = uVar6 - 1;
        UNLOCK();
        if (uVar6 - 1 == 0) {
          pvVar5 = (void *)(**(code **)*piStack_1c)();
          LOCK();
          piVar2 = piStack_1c + 2;
          iVar3 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            pvVar5 = (void *)(**(code **)(*piStack_1c + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 23139 ; VA 0x00b077e0 ; FUN_00b077e0 */

void FUN_00b077e0(void)

{
  FUN_00c157b0();
  return;
}



/* FUNCTION 23140 ; VA 0x00b077f0 ; FUN_00b077f0 */

undefined4 FUN_00b077f0(void)

{
  return 0x30;
}



/* FUNCTION 23141 ; VA 0x00b07810 ; FUN_00b07810 */

float10 __fastcall FUN_00b07810(int param_1)

{
  return (float10)*(float *)(*(int *)(param_1 + 0xa8) + 0x218);
}



/* FUNCTION 23142 ; VA 0x00b07820 ; FUN_00b07820 */

float10 __fastcall FUN_00b07820(int param_1)

{
  return (float10)*(float *)(*(int *)(param_1 + 0xa8) + 0x214);
}



/* FUNCTION 23143 ; VA 0x00b07830 ; FUN_00b07830 */

undefined4 __thiscall FUN_00b07830(int param_1,int param_2)

{
  int iVar1;
  undefined4 *puVar2;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0xa8) + 0x238);
  if (iVar1 != 0) {
    return *(undefined4 *)(iVar1 + param_2 * 0xc);
  }
  puVar2 = (undefined4 *)FUN_00b05090();
  return *puVar2;
}



/* FUNCTION 23144 ; VA 0x00b07860 ; FUN_00b07860 */

void __thiscall FUN_00b07860(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  undefined auStack_50 [4];
  int *piStack_4c;
  undefined auStack_48 [4];
  int *piStack_44;
  undefined auStack_40 [4];
  int *piStack_3c;
  int iStack_38;
  int iStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017edb78;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_0088dc10(&iStack_38);
  iStack_8 = 0;
  iStack_14 = 0;
  if (0 < *(int *)(*(int *)(param_1 + 0xa8) + 0x1d4) - *(int *)(*(int *)(param_1 + 0xa8) + 0x1d0) >>
          3) {
    do {
      piVar1 = (int *)FUN_00c156d0(iStack_14);
      iVar2 = FUN_00ca12e0();
      if (iVar2 != 0) {
        iVar3 = (**(code **)(*piVar1 + 0x10))();
        if ((iVar3 - 1U < 0xb) && (iVar3 != 4)) {
          puVar4 = (undefined4 *)FUN_0060dcd0(auStack_40,iVar2 + -0x70);
          uStack_20 = *puVar4;
          piStack_1c = (int *)puVar4[1];
          *puVar4 = 0;
          puVar4[1] = 0;
          puVar4 = *(undefined4 **)(iStack_38 + 4);
          iStack_8._0_1_ = 2;
          if (*(undefined4 **)(iStack_38 + 8) == puVar4) {
            FUN_00603a30(puVar4,&uStack_20);
            piVar1 = piStack_1c;
            piVar5 = piStack_3c;
            if (piStack_1c != (int *)0x0) {
              LOCK();
              iVar2 = piStack_1c[1] + -1;
              piStack_1c[1] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)*piStack_1c)();
                LOCK();
                piVar5 = piVar1 + 2;
                iVar2 = *piVar5 + -1;
                *piVar5 = iVar2;
                UNLOCK();
                piVar5 = piStack_3c;
                if (iVar2 == 0) {
                  (**(code **)(*piVar1 + 4))();
                  piVar5 = piStack_3c;
                }
              }
            }
          }
          else {
            *puVar4 = uStack_20;
            puVar4[1] = piStack_1c;
            *(int *)(iStack_38 + 4) = *(int *)(iStack_38 + 4) + 8;
            uStack_20 = 0;
            piStack_1c = (int *)0x0;
            piVar5 = piStack_3c;
          }
        }
        else {
          iVar3 = (**(code **)(*piVar1 + 0x10))();
          if (iVar3 == 4) {
            puVar4 = (undefined4 *)FUN_0060dcd0(auStack_48,iVar2 + -0x54);
            uStack_28 = *puVar4;
            piStack_24 = (int *)puVar4[1];
            *puVar4 = 0;
            puVar4[1] = 0;
            puVar4 = *(undefined4 **)(iStack_38 + 4);
            iStack_8._0_1_ = 4;
            if (*(undefined4 **)(iStack_38 + 8) == puVar4) {
              FUN_00603a30(puVar4,&uStack_28);
              piVar1 = piStack_24;
              piVar5 = piStack_44;
              if (piStack_24 != (int *)0x0) {
                LOCK();
                iVar2 = piStack_24[1] + -1;
                piStack_24[1] = iVar2;
                UNLOCK();
                piVar5 = piStack_44;
                if (iVar2 == 0) {
                  (**(code **)*piStack_24)();
                  LOCK();
                  piVar5 = piVar1 + 2;
                  iVar2 = *piVar5 + -1;
                  *piVar5 = iVar2;
                  UNLOCK();
                  piVar5 = piStack_44;
                  if (iVar2 == 0) {
                    (**(code **)(*piVar1 + 4))();
                    piVar5 = piStack_44;
                  }
                }
              }
            }
            else {
              *puVar4 = uStack_28;
              puVar4[1] = piStack_24;
              *(int *)(iStack_38 + 4) = *(int *)(iStack_38 + 4) + 8;
              uStack_28 = 0;
              piStack_24 = (int *)0x0;
              piVar5 = piStack_44;
            }
          }
          else {
            iVar3 = (**(code **)(*piVar1 + 0x10))();
            if (0xd < iVar3 - 0xcU) goto LAB_00b07ae3;
            puVar4 = (undefined4 *)FUN_0060dcd0(auStack_50,iVar2 + -0x54);
            uStack_30 = *puVar4;
            piStack_2c = (int *)puVar4[1];
            *puVar4 = 0;
            puVar4[1] = 0;
            puVar4 = *(undefined4 **)(iStack_38 + 4);
            iStack_8._0_1_ = 6;
            if (*(undefined4 **)(iStack_38 + 8) == puVar4) {
              FUN_00603a30(puVar4,&uStack_30);
              piVar1 = piStack_2c;
              piVar5 = piStack_4c;
              if (piStack_2c != (int *)0x0) {
                LOCK();
                iVar2 = piStack_2c[1] + -1;
                piStack_2c[1] = iVar2;
                UNLOCK();
                piVar5 = piStack_4c;
                if (iVar2 == 0) {
                  (**(code **)*piStack_2c)();
                  LOCK();
                  piVar5 = piVar1 + 2;
                  iVar2 = *piVar5 + -1;
                  *piVar5 = iVar2;
                  UNLOCK();
                  piVar5 = piStack_4c;
                  if (iVar2 == 0) {
                    (**(code **)(*piVar1 + 4))();
                    piVar5 = piStack_4c;
                  }
                }
              }
            }
            else {
              *puVar4 = uStack_30;
              puVar4[1] = piStack_2c;
              *(int *)(iStack_38 + 4) = *(int *)(iStack_38 + 4) + 8;
              uStack_30 = 0;
              piStack_2c = (int *)0x0;
              piVar5 = piStack_4c;
            }
          }
        }
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar2 = piVar5[1] + -1;
          piVar5[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar2 = piVar5[2] + -1;
            piVar5[2] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
      }
LAB_00b07ae3:
      iStack_14 = iStack_14 + 1;
    } while (iStack_14 <
             *(int *)(*(int *)(iStack_18 + 0xa8) + 0x1d4) -
             *(int *)(*(int *)(iStack_18 + 0xa8) + 0x1d0) >> 3);
  }
  *param_2 = iStack_38;
  param_2[1] = iStack_34;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23145 ; VA 0x00b07b30 ; FUN_00b07b30 */

void FUN_00b07b30(undefined8 *param_1)

{
  undefined4 uVar1;
  int iVar2;
  undefined auStack_4c [72];
  
  iVar2 = FUN_00c15e70(auStack_4c);
  uVar1 = *(undefined4 *)(iVar2 + 0x38);
  *param_1 = *(undefined8 *)(iVar2 + 0x30);
  *(undefined4 *)(param_1 + 1) = uVar1;
  return;
}



/* FUNCTION 23146 ; VA 0x00b07b60 ; FUN_00b07b60 */

int FUN_00b07b60(void)

{
  int iVar1;
  
  iVar1 = FUN_00c157b0();
  return iVar1 + 0x30;
}



/* FUNCTION 23147 ; VA 0x00b07b70 ; FUN_00b07b70 */

undefined FUN_00b07b70(int param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  
  if (param_1 != 0) {
    iVar3 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00aff8c0();
    if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      return *(undefined *)(param_1 + 0xe5);
    }
  }
  uVar5 = 0;
  iVar3 = FUN_005d6c30();
  if (iVar3 != 0) {
    do {
      cVar1 = FUN_00b07b70(*(undefined4 *)(**(int **)(param_1 + 0x2c) + uVar5 * 8));
      if (cVar1 != '\0') {
        return 1;
      }
      uVar5 = uVar5 + 1;
      uVar4 = FUN_005d6c30();
    } while (uVar5 < uVar4);
  }
  return 0;
}



/* FUNCTION 23148 ; VA 0x00b07bf0 ; FUN_00b07bf0 */

float10 __fastcall FUN_00b07bf0(int param_1)

{
  int iVar1;
  float10 fVar2;
  
  iVar1 = *(int *)(param_1 + 0xa8);
  if (*(int *)(iVar1 + 0x1a8) == 0) {
    fVar2 = (float10)FUN_00c15620(param_1);
    return (float10)(float)fVar2;
  }
  if ((*(char *)(iVar1 + 0x8c) != '\0') && (*(int *)(iVar1 + 0x70) != iVar1 + 0x50)) {
    return (float10)0.0;
  }
  return (float10)*(float *)(iVar1 + 0xd4);
}



/* FUNCTION 23149 ; VA 0x00b07c60 ; FUN_00b07c60 */

float10 FUN_00b07c60(void)

{
  return (float10)((float)DAT_01d66b94 / DAT_018ce324);
}



/* FUNCTION 23150 ; VA 0x00b07c90 ; FUN_00b07c90 */

undefined4 __fastcall FUN_00b07c90(int param_1)

{
  return CONCAT31((int3)((uint)*(int *)(param_1 + 0xa8) >> 8),
                  *(undefined *)(*(int *)(param_1 + 0xa8) + 0x228));
}



/* FUNCTION 23151 ; VA 0x00b07ca0 ; FUN_00b07ca0 */

void __thiscall FUN_00b07ca0(int param_1,undefined4 *param_2)

{
  *param_2 = *(undefined4 *)(*(int *)(param_1 + 0xa8) + 0x1dc);
  return;
}



/* FUNCTION 23152 ; VA 0x00b07cc0 ; FUN_00b07cc0 */

int * __thiscall FUN_00b07cc0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined auStack_78 [24];
  code *pcStack_60;
  undefined1 *puStack_5c;
  char *pcStack_58;
  undefined4 *puStack_54;
  undefined4 uStack_50;
  int *piStack_4c;
  undefined auStack_48 [16];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined1 *puStack_30;
  char *pcStack_2c;
  undefined4 *puStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017edba0;
  pvStack_10 = ExceptionList;
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = 0;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00b02d50(&iStack_14,auStack_48);
  if (cVar2 != '\0') {
    cVar2 = FUN_0098c5a0(param_1,1);
    if (cVar2 == '\0') {
      cVar2 = FUN_00971ce0(param_1,0);
      if (cVar2 != '\0') {
        FUN_0097c970(param_1,0);
      }
      *param_2 = 0;
      param_2[1] = 0;
    }
    else {
      iVar3 = FUN_008f7870(param_1);
      if (iVar3 != 0) {
        piVar1 = *(int **)(iVar3 + 0x43c);
        puStack_54 = (undefined4 *)
                     FUN_0058c590(auStack_78,*piVar1 - (int)piVar1,piVar1[1] - (int)piVar1);
        iStack_8._0_1_ = 1;
        if (0xf < (uint)puStack_54[5]) {
          puStack_54 = (undefined4 *)*puStack_54;
        }
        piStack_20 = (int *)((uint)piStack_20 & 0xffffff00);
        piStack_4c = piStack_20;
        puStack_30 = &DAT_018c5f98;
        pcStack_2c = "PartInstance_GetNetworkOwnerScript";
        uStack_24 = 0;
        pcStack_60 = FUN_0087c450;
        puStack_5c = &DAT_018c5f98;
        pcStack_58 = "PartInstance_GetNetworkOwnerScript";
        uStack_50 = 0;
        puStack_28 = puStack_54;
        FUN_008ab7d0(&DAT_01eedc8c,&pcStack_60);
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_005507b0();
      }
      uStack_18 = *(undefined4 *)(iStack_14 + 0x1dc);
      piVar4 = (int *)FUN_0097c020(&uStack_24,&uStack_18,param_1);
      piVar1 = piStack_20;
      iStack_14 = *piVar4;
      iStack_1c = piVar4[1];
      *piVar4 = 0;
      piVar4[1] = 0;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_20[1] + -1;
        piStack_20[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar4 = piVar1 + 2;
          iVar3 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      *param_2 = iStack_14;
      param_2[1] = iStack_1c;
    }
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return param_2;
  }
  uVar5 = FUN_005543f0();
  FUN_00550130(uVar5);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(&puStack_28,&DAT_01c17198);
}



/* FUNCTION 23153 ; VA 0x00b07e80 ; FUN_00b07e80 */

bool FUN_00b07e80(void)

{
  char cVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [12];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01799148;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00b02d50(&iStack_14,auStack_38);
  if (cVar1 == '\0') {
    uVar2 = FUN_005543f0();
    FUN_00550130(uVar2);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_20,&DAT_01c17198);
  }
  cVar1 = *(char *)(iStack_14 + 0x22c);
  if (0xf < uStack_24) {
    uVar4 = uStack_24 + 1;
    uVar3 = auStack_38[0];
    if (0xfff < uVar4) {
      uVar3 = *(uint *)(auStack_38[0] - 4);
      uVar4 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return cVar1 == '\0';
}



/* FUNCTION 23154 ; VA 0x00b07f40 ; FUN_00b07f40 */

undefined __fastcall FUN_00b07f40(int param_1)

{
  return *(undefined *)(*(int *)(param_1 + 0xa8) + 0x22c);
}



/* FUNCTION 23155 ; VA 0x00b07f50 ; FUN_00b07f50 */

int FUN_00b07f50(char param_1)

{
  int iVar1;
  
  iVar1 = FUN_008a40f0();
  if ((iVar1 == 0) && (param_1 == '\0')) {
    return 0;
  }
  iVar1 = FUN_008a4100();
  return iVar1 + 0xb0;
}



/* FUNCTION 23156 ; VA 0x00b07f80 ; FUN_00b07f80 */

int FUN_00b07f80(char param_1)

{
  int iVar1;
  
  iVar1 = FUN_008a40f0();
  if ((iVar1 == 0) && (param_1 == '\0')) {
    return 0;
  }
  iVar1 = FUN_008a4100();
  return iVar1 + 0xb8;
}



/* FUNCTION 23157 ; VA 0x00b07fb0 ; FUN_00b07fb0 */

int FUN_00b07fb0(char param_1)

{
  int iVar1;
  
  iVar1 = FUN_008a40f0();
  if ((iVar1 == 0) && (param_1 == '\0')) {
    return 0;
  }
  iVar1 = FUN_008a4100();
  return iVar1 + 0xc0;
}



/* FUNCTION 23158 ; VA 0x00b07fe0 ; FUN_00b07fe0 */

int FUN_00b07fe0(char param_1)

{
  int iVar1;
  
  iVar1 = FUN_008a40f0();
  if ((iVar1 == 0) && (param_1 == '\0')) {
    return 0;
  }
  iVar1 = FUN_008a4100();
  return iVar1 + 0xa8;
}



/* FUNCTION 23159 ; VA 0x00b08010 ; FUN_00b08010 */

void FUN_00b08010(undefined8 *param_1)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  FUN_00c157b0();
  FUN_01162f40(&fStack_c,&fStack_8,&fStack_10);
  fVar3 = fStack_10 * DAT_0194fa04 * DAT_018ce320;
  if (fVar3 < 0.0) {
    fVar3 = fVar3 - DAT_018ce2f4;
  }
  else {
    fVar3 = fVar3 + DAT_018ce2f4;
  }
  fVar1 = fStack_c * DAT_0194fa04 * DAT_018ce320;
  fVar3 = (float)(int)fVar3 / DAT_018ce320;
  if (fVar1 < 0.0) {
    fVar1 = fVar1 - DAT_018ce2f4;
  }
  else {
    fVar1 = fVar1 + DAT_018ce2f4;
  }
  fVar2 = fStack_8 * DAT_0194fa04 * DAT_018ce320;
  if (fVar2 < 0.0) {
    fVar2 = fVar2 - DAT_018ce2f4;
  }
  else {
    fVar2 = fVar2 + DAT_018ce2f4;
  }
  *param_1 = CONCAT44((float)(int)fVar1 / DAT_018ce320,(float)(int)fVar2 / DAT_018ce320);
  *(float *)(param_1 + 1) = fVar3;
  return;
}



/* FUNCTION 23160 ; VA 0x00b08110 ; FUN_00b08110 */

float10 __thiscall FUN_00b08110(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0xa8) + 0x238);
  if (iVar1 != 0) {
    return (float10)*(float *)(iVar1 + 4 + param_2 * 0xc);
  }
  iVar1 = FUN_00b05090();
  return (float10)*(float *)(iVar1 + 4);
}



/* FUNCTION 23161 ; VA 0x00b08140 ; FUN_00b08140 */

float10 __thiscall FUN_00b08140(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0xa8) + 0x238);
  if (iVar1 != 0) {
    return (float10)*(float *)(iVar1 + 8 + param_2 * 0xc);
  }
  iVar1 = FUN_00b05090();
  return (float10)*(float *)(iVar1 + 8);
}



/* FUNCTION 23162 ; VA 0x00b08170 ; FUN_00b08170 */

undefined4 * __thiscall FUN_00b08170(int *param_1,undefined4 *param_2)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  byte bVar5;
  undefined uVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 *puVar10;
  undefined4 uVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  
  iVar7 = param_1[0x2a];
  bVar1 = *(byte *)(iVar7 + 0x22f);
  bVar2 = *(byte *)(iVar7 + 0x230);
  bVar3 = *(byte *)(iVar7 + 0x231);
  bVar4 = *(byte *)(iVar7 + 0x232);
  bVar5 = *(byte *)(iVar7 + 0x233);
  uVar6 = *(undefined *)(iVar7 + 0x234);
  puVar10 = (undefined4 *)FUN_00c157b0();
  fVar12 = DAT_018ce2f8 - (float)param_1[0x35];
  fVar13 = DAT_018ce2f8 - (float)param_1[0x33];
  fVar14 = DAT_018ce2f8;
  if (0 < param_1[0x38]) {
    fVar14 = DAT_018ce2f4;
  }
  FUN_0115e8a0(param_1 + 0x32);
  iVar7 = *(int *)(param_1[0x2a] + 0x1ac);
  fVar14 = DAT_018ce2f8 - (DAT_018ce2f8 - fVar13 * fVar12 * fVar14);
  uVar11 = (**(code **)(*param_1 + 0xb4))();
  *(undefined8 *)(param_2 + 1) = *(undefined8 *)(iVar7 + 4);
  *param_2 = uVar11;
  uVar11 = *(undefined4 *)(iVar7 + 0xc);
  param_2[4] = uStack_2c;
  param_2[5] = uStack_28;
  param_2[6] = uStack_24;
  param_2[7] = fVar14;
  param_2[3] = uVar11;
  param_2[8] = (uint)bVar1;
  param_2[9] = (uint)bVar2;
  param_2[10] = (uint)bVar3;
  param_2[0xb] = (uint)bVar4;
  *(ulonglong *)(param_2 + 0xc) = (ulonglong)CONCAT14(uVar6,(uint)bVar5);
  uVar11 = puVar10[1];
  uVar8 = puVar10[2];
  uVar9 = puVar10[3];
  param_2[0xe] = *puVar10;
  param_2[0xf] = uVar11;
  param_2[0x10] = uVar8;
  param_2[0x11] = uVar9;
  uVar11 = puVar10[5];
  uVar8 = puVar10[6];
  uVar9 = puVar10[7];
  param_2[0x12] = puVar10[4];
  param_2[0x13] = uVar11;
  param_2[0x14] = uVar8;
  param_2[0x15] = uVar9;
  uVar11 = puVar10[9];
  uVar8 = puVar10[10];
  uVar9 = puVar10[0xb];
  param_2[0x16] = puVar10[8];
  param_2[0x17] = uVar11;
  param_2[0x18] = uVar8;
  param_2[0x19] = uVar9;
  return param_2;
}



/* FUNCTION 23163 ; VA 0x00b082f0 ; FUN_00b082f0 */

void __thiscall FUN_00b082f0(int param_1,undefined8 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0xa8) + 0x1ac);
  uVar2 = *(undefined4 *)(iVar1 + 0xc);
  *param_2 = *(undefined8 *)(iVar1 + 4);
  *(undefined4 *)(param_2 + 1) = uVar2;
  return;
}



/* FUNCTION 23164 ; VA 0x00b08320 ; FUN_00b08320 */

int __fastcall FUN_00b08320(int param_1)

{
  return *(int *)(*(int *)(param_1 + 0xa8) + 0x1ac) + 4;
}



/* FUNCTION 23165 ; VA 0x00b08330 ; FUN_00b08330 */

undefined4 __fastcall FUN_00b08330(int param_1)

{
  return *(undefined4 *)(*(int *)(param_1 + 0xa8) + 0x21c);
}



/* FUNCTION 23166 ; VA 0x00b08340 ; FUN_00b08340 */

undefined4 __thiscall FUN_00b08340(int param_1,undefined4 param_2,int param_3)

{
  float *pfVar1;
  int iVar2;
  float afStack_70 [4];
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  float fStack_1c;
  float fStack_18;
  float fStack_14;
  undefined8 uStack_10;
  float fStack_8;
  
  pfVar1 = (float *)FUN_00c157b0();
  afStack_70[0] = *pfVar1;
  afStack_70[1] = pfVar1[1];
  afStack_70[2] = pfVar1[2];
  afStack_70[3] = pfVar1[3];
  fStack_60 = pfVar1[4];
  fStack_5c = pfVar1[5];
  fStack_58 = pfVar1[6];
  fStack_54 = pfVar1[7];
  fStack_50 = pfVar1[8];
  fStack_4c = pfVar1[9];
  fStack_48 = pfVar1[10];
  fStack_44 = pfVar1[0xb];
  iVar2 = *(int *)(*(int *)(param_1 + 0xa8) + 0x1ac);
  uStack_10 = *(undefined8 *)(iVar2 + 4);
  fStack_8 = *(float *)(iVar2 + 0xc);
  pfVar1 = (float *)FUN_00d6a680(param_3);
  fStack_1c = (float)uStack_10 * *pfVar1;
  fStack_18 = pfVar1[1] * uStack_10._4_4_;
  fStack_14 = pfVar1[2] * fStack_8;
  FUN_00c95760(&fStack_28,&fStack_1c);
  if (fStack_24 <= fStack_28) {
    fStack_24 = fStack_28;
  }
  if (fStack_20 <= fStack_24) {
    fStack_20 = fStack_24;
  }
  fStack_20 = fStack_20 * DAT_018ce2f4;
  iVar2 = param_3 % 3;
  fStack_38 = (float)((param_3 / 3) * -2 + 1);
  fStack_40 = afStack_70[iVar2] * fStack_38;
  fStack_3c = afStack_70[iVar2 + 3] * fStack_38;
  fStack_38 = afStack_70[iVar2 + 6] * fStack_38;
  fStack_34 = fStack_40 * fStack_20 + fStack_4c;
  fStack_30 = fStack_3c * fStack_20 + fStack_48;
  fStack_2c = fStack_38 * fStack_20 + fStack_44;
  FUN_01166ea0(&fStack_40,&fStack_34);
  return param_2;
}



/* FUNCTION 23167 ; VA 0x00b084b0 ; FUN_00b084b0 */

undefined4 * FUN_00b084b0(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  puVar4 = (undefined4 *)FUN_00c157b0();
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_1 = *puVar4;
  param_1[1] = uVar1;
  param_1[2] = uVar2;
  param_1[3] = uVar3;
  uVar1 = puVar4[5];
  uVar2 = puVar4[6];
  uVar3 = puVar4[7];
  param_1[4] = puVar4[4];
  param_1[5] = uVar1;
  param_1[6] = uVar2;
  param_1[7] = uVar3;
  uVar1 = puVar4[9];
  uVar2 = puVar4[10];
  uVar3 = puVar4[0xb];
  param_1[8] = puVar4[8];
  param_1[9] = uVar1;
  param_1[10] = uVar2;
  param_1[0xb] = uVar3;
  return param_1;
}



/* FUNCTION 23168 ; VA 0x00b084e0 ; FUN_00b084e0 */

undefined2 __fastcall FUN_00b084e0(int param_1)

{
  return *(undefined2 *)(*(int *)(param_1 + 0xa8) + 0x220);
}



/* FUNCTION 23169 ; VA 0x00b084f0 ; FUN_00b084f0 */

undefined4 FUN_00b084f0(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00587490(auStack_c);
  uVar2 = *puVar4;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return uVar2;
  }
  return uVar2;
}



/* FUNCTION 23170 ; VA 0x00b08550 ; FUN_00b08550 */

undefined4 * __thiscall FUN_00b08550(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  uVar5 = 0;
  if (*(int *)(param_1 + 0xa8) != 0) {
    iVar3 = FUN_00c155c0();
    if (iVar3 != 0) {
      FUN_00c155c0();
      iVar3 = FUN_00ca1550();
      if (iVar3 == 0) {
        uVar5 = 0;
      }
      else {
        uVar5 = -(uint)(*(int *)(iVar3 + 0x1b0) != 0) & *(int *)(iVar3 + 0x1b0) - 0x58U;
      }
    }
  }
  puVar4 = (undefined4 *)FUN_0060dcd0(auStack_c,uVar5);
  *param_2 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_2[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_2;
  }
  return param_2;
}



/* FUNCTION 23171 ; VA 0x00b08600 ; FUN_00b08600 */

uint __fastcall FUN_00b08600(int param_1)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0xa8) != 0) {
    iVar1 = FUN_00c155c0();
    if (iVar1 != 0) {
      FUN_00c155c0();
      iVar1 = FUN_00ca1550();
      if (iVar1 != 0) {
        return *(int *)(iVar1 + 0x1b0) - 0x58U & -(uint)(*(int *)(iVar1 + 0x1b0) != 0);
      }
    }
  }
  return 0;
}



/* FUNCTION 23172 ; VA 0x00b08650 ; FUN_00b08650 */

int __fastcall FUN_00b08650(int param_1)

{
  return (int)*(char *)(*(int *)(param_1 + 0xa8) + 0x22b);
}



/* FUNCTION 23173 ; VA 0x00b08660 ; FUN_00b08660 */

int FUN_00b08660(void)

{
  int iVar1;
  
  iVar1 = FUN_00c157b0();
  return iVar1 + 0x3c;
}



/* FUNCTION 23174 ; VA 0x00b08670 ; FUN_00b08670 */

void __fastcall FUN_00b08670(int param_1)

{
  code *pcStack_30;
  undefined1 *puStack_2c;
  char *pcStack_28;
  char *pcStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  undefined1 *puStack_18;
  char *pcStack_14;
  char *pcStack_10;
  undefined4 uStack_c;
  uint uStack_8;
  
  if (DAT_01d66bfc != '\0') {
    uStack_8 = uStack_8 & 0xffffff00;
    uStack_1c = uStack_8;
    puStack_18 = &DAT_018c5f98;
    pcStack_14 = "PartInstance";
    pcStack_10 = "getSpecificGravity";
    uStack_c = 0;
    pcStack_30 = FUN_0087c450;
    puStack_2c = &DAT_018c5f98;
    pcStack_28 = "PartInstance";
    pcStack_24 = "getSpecificGravity";
    uStack_20 = 0;
    FUN_008ab7d0(&DAT_01eedc94,&pcStack_30);
  }
  FUN_00f9dd40(*(undefined4 *)(param_1 + 0xa8));
  return;
}



/* FUNCTION 23175 ; VA 0x00b086e0 ; FUN_00b086e0 */

undefined4 __thiscall FUN_00b086e0(int param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  float *pfVar1;
  int iVar2;
  float fVar3;
  float fVar4;
  undefined auStack_64 [12];
  undefined auStack_58 [12];
  undefined8 uStack_4c;
  uint uStack_44;
  undefined8 uStack_40;
  float fStack_38;
  undefined8 uStack_34;
  uint uStack_2c;
  undefined8 uStack_28;
  float fStack_20;
  uint uStack_14;
  float afStack_10 [3];
  
  FUN_00c157b0();
  FUN_01164300(auStack_64,param_3);
  iVar2 = *(int *)(*(int *)(param_1 + 0xa8) + 0x1ac);
  fStack_38 = *(float *)(iVar2 + 0xc) * DAT_018ce2f4;
  afStack_10[0] = 0.0;
  fVar4 = *(float *)(iVar2 + 4) * DAT_018ce2f4;
  afStack_10[1] = 0.0;
  fVar3 = *(float *)(iVar2 + 8) * DAT_018ce2f4;
  uStack_40 = CONCAT44(fVar3,fVar4);
  afStack_10[2] = 0.0;
  uStack_44 = (uint)fStack_38 ^ DAT_018c4ea0;
  uStack_4c = CONCAT44((uint)fVar3 ^ DAT_018c4ea0,(uint)fVar4 ^ DAT_018c4ea0);
  uStack_34 = CONCAT44((uint)fVar3 ^ DAT_018c4ea0,(uint)fVar4 ^ DAT_018c4ea0);
  uStack_28 = CONCAT44(fVar3,fVar4);
  uStack_2c = uStack_44;
  fStack_20 = fStack_38;
  uStack_14 = uStack_44;
  FUN_01167b90(auStack_64,auStack_58,&uStack_34,afStack_10,&DAT_01f307ac,&DAT_01f307bc);
  iVar2 = 0;
  do {
    fVar3 = afStack_10[iVar2];
    pfVar1 = (float *)((int)&uStack_40 + iVar2 * 4);
    if ((NAN(fVar3) || NAN(*pfVar1)) != (fVar3 == *pfVar1)) {
LAB_00b087fb:
      *param_4 = iVar2;
      FUN_0054fe00(param_1,iVar2);
      return param_2;
    }
    pfVar1 = (float *)((int)&uStack_4c + iVar2 * 4);
    if ((NAN(fVar3) || NAN(*pfVar1)) != (fVar3 == *pfVar1)) {
      iVar2 = iVar2 + 3;
      goto LAB_00b087fb;
    }
    iVar2 = iVar2 + 1;
    if (2 < iVar2) {
      FUN_0054fe00(0,0);
      return param_2;
    }
  } while( true );
}



/* FUNCTION 23176 ; VA 0x00b08820 ; FUN_00b08820 */

undefined4 __fastcall FUN_00b08820(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [8];
  
  if (DAT_01d6ca30 != '\0') {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar3 = FUN_00cfb1a0();
    if (((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
         (uint)*(ushort *)(iVar3 + 0x1da)) && ((*(byte *)(param_1 + 0xb4) & 8) == 0)) {
      puVar4 = (undefined4 *)FUN_00587490(auStack_c);
      uVar2 = *puVar4;
      FUN_00550b30();
      return uVar2;
    }
  }
  return 0;
}



/* FUNCTION 23177 ; VA 0x00b08890 ; FUN_00b08890 */

undefined __thiscall FUN_00b08890(int param_1,int param_2)

{
  return *(undefined *)(*(int *)(param_1 + 0xa8) + 0x22f + param_2);
}



/* FUNCTION 23178 ; VA 0x00b088b0 ; FUN_00b088b0 */

undefined4 * __thiscall FUN_00b088b0(int param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_00a9d1c0(param_1);
  if (iVar1 != 0) {
    FUN_00ce3550(param_2,*(undefined4 *)(param_1 + 0xa8),0x3951b717,1);
    return param_2;
  }
  *param_2 = 0;
  param_2[1] = 0;
  return param_2;
}



/* FUNCTION 23179 ; VA 0x00b08900 ; FUN_00b08900 */

int FUN_00b08900(void)

{
  int iVar1;
  
  iVar1 = FUN_00c157b0();
  return iVar1 + 0x24;
}



/* FUNCTION 23180 ; VA 0x00b08910 ; FUN_00b08910 */

float10 __fastcall FUN_00b08910(int param_1)

{
  float fVar1;
  
  fVar1 = DAT_018ce2f8;
  if (0 < *(int *)(param_1 + 0xe0)) {
    fVar1 = DAT_018ce2f4;
  }
  return (float10)(DAT_018ce2f8 -
                  (DAT_018ce2f8 - *(float *)(param_1 + 0xcc)) *
                  (DAT_018ce2f8 - *(float *)(param_1 + 0xd4)) * fVar1);
}



/* FUNCTION 23181 ; VA 0x00b08960 ; FUN_00b08960 */

void __thiscall FUN_00b08960(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)(**(code **)(param_1 + 8))(&stack0x00000008);
  *param_2 = *puVar1;
  return;
}



/* FUNCTION 23182 ; VA 0x00b089a0 ; FUN_00b089a0 */

undefined2 * __thiscall FUN_00b089a0(int param_1,undefined2 *param_2)

{
  undefined2 *puVar1;
  
  puVar1 = (undefined2 *)(**(code **)(param_1 + 8))(&stack0x00000009);
  *param_2 = *puVar1;
  *(undefined *)(param_2 + 1) = *(undefined *)(puVar1 + 1);
  return param_2;
}



/* FUNCTION 23183 ; VA 0x00b089e0 ; FUN_00b089e0 */

undefined4 * __thiscall FUN_00b089e0(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  puVar4 = (undefined4 *)(**(code **)(param_1 + 8))();
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_2 = *puVar4;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  uVar1 = puVar4[5];
  uVar2 = puVar4[6];
  uVar3 = puVar4[7];
  param_2[4] = puVar4[4];
  param_2[5] = uVar1;
  param_2[6] = uVar2;
  param_2[7] = uVar3;
  uVar1 = puVar4[9];
  uVar2 = puVar4[10];
  uVar3 = puVar4[0xb];
  param_2[8] = puVar4[8];
  param_2[9] = uVar1;
  param_2[10] = uVar2;
  param_2[0xb] = uVar3;
  return param_2;
}



/* FUNCTION 23184 ; VA 0x00b08a30 ; FUN_00b08a30 */

undefined4 * __thiscall FUN_00b08a30(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  puVar4 = (undefined4 *)(**(code **)(param_1 + 8))();
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_2 = *puVar4;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(puVar4 + 4);
  return param_2;
}



/* FUNCTION 23185 ; VA 0x00b08a70 ; FUN_00b08a70 */

undefined8 * __thiscall FUN_00b08a70(int param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)(**(code **)(param_1 + 8))();
  uVar1 = *(undefined4 *)(puVar2 + 1);
  *param_2 = *puVar2;
  *(undefined4 *)(param_2 + 1) = uVar1;
  return param_2;
}



/* FUNCTION 23186 ; VA 0x00b08ab0 ; FUN_00b08ab0 */

int __fastcall FUN_00b08ab0(int param_1)

{
  char cVar1;
  
  cVar1 = (**(code **)(param_1 + 8))();
  return (int)cVar1;
}



/* FUNCTION 23187 ; VA 0x00b08ae0 ; FUN_00b08ae0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b08ae0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined *puVar2;
  undefined4 *puVar3;
  undefined2 *puVar4;
  undefined4 uVar5;
  
  puVar4 = (undefined2 *)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))((int)&param_2 + 1,param_2);
  uVar5 = FUN_0088d0f0();
  puVar3 = param_3;
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  *param_3 = uVar5;
  if (*(int *)(iVar1 + 0x34) < DAT_01ead428) {
    FUN_016f3809(&DAT_01ead428);
    if (DAT_01ead428 == -1) {
      _DAT_01ead41c = FUN_00619ea0;
      _DAT_01ead420 = FUN_00619ea0;
      _DAT_01ead424 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead428);
    }
  }
  puVar2 = (undefined *)puVar3[1];
  if (puVar2 == &DAT_01ead41c) {
    *(undefined2 *)(puVar3 + 2) = *puVar4;
    *(undefined *)((int)puVar3 + 10) = *(undefined *)(puVar4 + 1);
    return;
  }
  if (puVar2 != (undefined *)0x0) {
    (**(code **)(puVar2 + 8))(puVar3 + 2);
    puVar3[1] = 0;
  }
  *(undefined2 *)(puVar3 + 2) = *puVar4;
  *(undefined *)((int)puVar3 + 10) = *(undefined *)(puVar4 + 1);
  puVar3[1] = &DAT_01ead41c;
  return;
}



/* FUNCTION 23188 ; VA 0x00b08bc0 ; FUN_00b08bc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b08bc0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  
  puVar4 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&param_2,param_2);
  uVar5 = FUN_0088d230();
  puVar3 = param_3;
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  *param_3 = uVar5;
  if (*(int *)(iVar1 + 0x34) < DAT_01ead448) {
    FUN_016f3809(&DAT_01ead448);
    if (DAT_01ead448 == -1) {
      _DAT_01ead43c = FUN_005c65e0;
      _DAT_01ead440 = FUN_005c65e0;
      _DAT_01ead444 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead448);
    }
  }
  puVar2 = (undefined *)puVar3[1];
  if (puVar2 == &DAT_01ead43c) {
    puVar3[2] = *puVar4;
    return;
  }
  if (puVar2 != (undefined *)0x0) {
    (**(code **)(puVar2 + 8))(puVar3 + 2);
    puVar3[1] = 0;
  }
  puVar3[2] = *puVar4;
  puVar3[1] = &DAT_01ead43c;
  return;
}



/* FUNCTION 23189 ; VA 0x00b08c90 ; FUN_00b08c90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b08c90(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined auStack_1c [24];
  
  puVar5 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(auStack_1c,param_2);
  uVar6 = FUN_0088d2d0();
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  *param_3 = uVar6;
  if (*(int *)(iVar1 + 0x34) < DAT_01ead338) {
    FUN_016f3809(&DAT_01ead338);
    if (DAT_01ead338 == -1) {
      _DAT_01ead32c = FUN_00619f80;
      _DAT_01ead330 = FUN_00619f80;
      _DAT_01ead334 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ead338);
    }
  }
  puVar2 = (undefined *)param_3[1];
  if (puVar2 == &DAT_01ead32c) {
    uVar6 = puVar5[1];
    uVar3 = puVar5[2];
    uVar4 = puVar5[3];
    param_3[2] = *puVar5;
    param_3[3] = uVar6;
    param_3[4] = uVar3;
    param_3[5] = uVar4;
    *(undefined8 *)(param_3 + 6) = *(undefined8 *)(puVar5 + 4);
    return;
  }
  if (puVar2 != (undefined *)0x0) {
    (**(code **)(puVar2 + 8))(param_3 + 2);
    param_3[1] = 0;
  }
  uVar6 = puVar5[1];
  uVar3 = puVar5[2];
  uVar4 = puVar5[3];
  param_3[2] = *puVar5;
  param_3[3] = uVar6;
  param_3[4] = uVar3;
  param_3[5] = uVar4;
  *(undefined8 *)(param_3 + 6) = *(undefined8 *)(puVar5 + 4);
  param_3[1] = &DAT_01ead32c;
  return;
}



/* FUNCTION 23190 ; VA 0x00b08d80 ; FUN_00b08d80 */

void __thiscall FUN_00b08d80(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int iVar5;
  
  puVar3 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&param_2,param_2);
  uVar4 = FUN_0088d550();
  puVar2 = param_3;
  *param_3 = uVar4;
  iVar5 = FUN_00631380();
  iVar1 = puVar2[1];
  if (iVar1 == iVar5) {
    puVar2[2] = *puVar3;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(puVar2 + 2);
    puVar2[1] = 0;
  }
  puVar2[2] = *puVar3;
  puVar2[1] = iVar5;
  return;
}



/* FUNCTION 23191 ; VA 0x00b08df0 ; FUN_00b08df0 */

void __thiscall FUN_00b08df0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00b0f780();
  *param_3 = uVar3;
  iVar4 = FUN_00b0fa30();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 23192 ; VA 0x00b08e50 ; FUN_00b08e50 */

void FUN_00b08e50(void)

{
  FUN_00b0fe90();
  FUN_008a2fd0();
  return;
}



/* FUNCTION 23193 ; VA 0x00b08e60 ; FUN_00b08e60 */

void __fastcall FUN_00b08e60(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_00a9d0e0(param_1);
  if (iVar1 != 0) {
    FUN_00a9e590();
  }
  return;
}



/* FUNCTION 23194 ; VA 0x00b08e80 ; FUN_00b08e80 */

void __fastcall FUN_00b08e80(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined auStack_9c [48];
  undefined auStack_6c [48];
  undefined auStack_3c [48];
  int iStack_c;
  int iStack_8;
  
  iVar1 = FUN_00a9d0e0(param_1);
  if (iVar1 != 0) {
    iVar1 = *(int *)(param_1 + 0xa8);
    FUN_00a9e6d0(1);
    FUN_00a9aa40(iVar1);
    iStack_c = 0;
    if (0 < (int)(*(int *)(iVar1 + 0x1d4) - *(int *)(iVar1 + 0x1d0) & 0xfffffff8U)) {
      do {
        piVar2 = (int *)FUN_00c156d0(iStack_c);
        if ((((piVar2 != (int *)0x0) && (iVar3 = (**(code **)(*piVar2 + 0x10))(), iVar3 - 1U < 0xb))
            && (iVar3 != 4)) &&
           (((iVar3 = (**(code **)(*piVar2 + 0x10))(), iVar3 - 1U < 6 &&
             (iStack_8 = piVar2[0xb], iStack_8 != 0)) && (piVar2[0xc] != 0)))) {
          FUN_0071fcc0(auStack_3c);
          uVar4 = FUN_00c157b0();
          FUN_0071f260(auStack_6c,uVar4);
          iVar3 = 0x40;
          if (iStack_8 == iVar1) {
            iVar3 = 0x70;
          }
          uVar4 = FUN_0071f260(auStack_9c,iVar3 + (int)piVar2);
          FUN_00ca4830(iStack_8 != iVar1,uVar4);
        }
        iStack_c = iStack_c + 1;
      } while (iStack_c < *(int *)(iVar1 + 0x1d4) - *(int *)(iVar1 + 0x1d0) >> 3);
    }
  }
  return;
}



/* FUNCTION 23195 ; VA 0x00b08fb0 ; FUN_00b08fb0 */

void __fastcall FUN_00b08fb0(int param_1)

{
  int iVar1;
  
  iVar1 = FUN_008a4100();
  LOCK();
  *(int *)(iVar1 + 0x9c) = *(int *)(iVar1 + 0x9c) + 1;
  UNLOCK();
  iVar1 = FUN_008a40f0();
  if (*(int *)(iVar1 + 0x9c) + *(int *)(iVar1 + 0x98) + *(int *)(iVar1 + 0x94) == 1) {
    FUN_00c184c0(1);
    iVar1 = FUN_00a9d1c0(param_1);
    if (iVar1 != 0) {
      FUN_00ce7ad0(*(undefined4 *)(param_1 + 0xa8));
    }
  }
  return;
}



/* FUNCTION 23196 ; VA 0x00b09010 ; FUN_00b09010 */

void __fastcall FUN_00b09010(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  if ((DAT_01d69070 == '\0') && (DAT_01d66be0 == '\0')) {
    iVar4 = FUN_008a4100();
    LOCK();
    piVar1 = (int *)(iVar4 + 0x98);
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    if (iVar4 != 0) {
      return;
    }
    FUN_00b022e0();
    if (DAT_01d66c0c == '\0') {
      return;
    }
  }
  else {
    iVar4 = FUN_008a4100();
    LOCK();
    piVar1 = (int *)(iVar4 + 0x98);
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    iVar5 = FUN_008a40f0();
    iVar2 = *(int *)(iVar5 + 0x9c);
    iVar3 = *(int *)(iVar5 + 0x98);
    iVar5 = *(int *)(iVar5 + 0x94);
    if (iVar4 == 0) {
      FUN_00b022e0();
    }
    if (iVar2 + iVar3 + iVar5 != 1) {
      return;
    }
    FUN_00c184c0(1);
  }
  iVar4 = FUN_00a9d1c0(param_1);
  if (iVar4 != 0) {
    FUN_00ce7ad0(*(undefined4 *)(param_1 + 0xa8));
  }
  return;
}



/* FUNCTION 23197 ; VA 0x00b090c0 ; FUN_00b090c0 */

undefined4 * __fastcall FUN_00b090c0(undefined4 param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edbc2;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0xd8);
  uStack_8 = 0;
  if (puVar1 != (undefined4 *)0x0) {
    FUN_0089a8e0();
    *puVar1 = RBX::PartInstance::OnDemandPartInstance::vftable;
    puVar1[0x20] = 0;
    puVar1[0x21] = 0;
    puVar1[0x22] = 0;
    puVar1[0x23] = 0;
    puVar1[0x24] = 0;
    puVar1[0x25] = 0;
    puVar1[0x26] = 0;
    puVar1[0x27] = 0;
    puVar1[0x28] = 0;
    puVar1[0x2a] = 0;
    puVar1[0x2c] = 0;
    puVar1[0x2e] = 0;
    puVar1[0x30] = 0;
    puVar1[0x31] = 0;
    *(undefined *)(puVar1 + 0x32) = 0;
    puVar1[0x33] = 0;
    puVar1[0x34] = 0;
    puVar1[0x35] = 0;
    puVar1[0x29] = param_1;
    puVar1[0x2b] = param_1;
    puVar1[0x2f] = param_1;
    puVar1[0x2d] = param_1;
    ExceptionList = pvStack_10;
    return puVar1;
  }
  ExceptionList = pvStack_10;
  return (undefined4 *)0x0;
}



/* FUNCTION 23198 ; VA 0x00b09200 ; FUN_00b09200 */

/* WARNING: Removing unreachable block (ram,0x00b09303) */
/* WARNING: Removing unreachable block (ram,0x00b0930f) */
/* WARNING: Removing unreachable block (ram,0x00b0931d) */

undefined4 FUN_00b09200(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bbdd1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 1;
  piVar1 = (int *)*param_1;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_f0 = FUN_0088cdc0();
  uStack_e8 = param_2;
  uStack_ec = 0;
  uStack_e4 = param_3;
  uStack_ec = FUN_006309e0();
  uStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,piVar1);
  uStack_8._0_1_ = 3;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 4;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  uVar3 = FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 23199 ; VA 0x00b09340 ; FUN_00b09340 */

/* WARNING: Removing unreachable block (ram,0x00b093a0) */
/* WARNING: Removing unreachable block (ram,0x00b093ac) */
/* WARNING: Removing unreachable block (ram,0x00b093ba) */

undefined4 FUN_00b09340(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b01670(param_2,param_3,param_4);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 23200 ; VA 0x00b093e0 ; FUN_00b093e0 */

uint __fastcall FUN_00b093e0(int param_1)

{
  uint uVar1;
  
  uVar1 = *(uint *)(param_1 + 0x48) & 1;
  if (DAT_01d65340 != '\0') {
    if (uVar1 != 0) {
      return (uint)(*(uint *)(param_1 + 0x48) != 3);
    }
    uVar1 = 0;
  }
  return uVar1;
}



/* FUNCTION 23201 ; VA 0x00b09400 ; FUN_00b09400 */

undefined4 FUN_00b09400(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined auStack_10 [4];
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 1;
  cVar1 = FUN_005e0cd0(&uStack_8);
  if (cVar1 != '\0') {
    uVar2 = FUN_0067ad50(auStack_10);
    cVar1 = FUN_005e0cd0(uVar2);
    if (cVar1 != '\0') {
      uStack_c = 2;
      cVar1 = FUN_005e0cd0(&uStack_c);
      if (cVar1 != '\0') {
        return 1;
      }
    }
  }
  return 0;
}



/* FUNCTION 23202 ; VA 0x00b09480 ; FUN_00b09480 */

undefined4 FUN_00b09480(void)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_00c156f0();
  if (iVar1 == 0) {
    return 0;
  }
  iVar1 = FUN_00c1a090();
  if (iVar1 != 0) {
    uVar2 = FUN_00c15600();
    return uVar2;
  }
  uVar2 = FUN_00c15600();
  return uVar2;
}



/* FUNCTION 23203 ; VA 0x00b094d0 ; FUN_00b094d0 */

undefined4 FUN_00b094d0(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  if ((param_1 != 0) && (iVar3 = *(int *)(param_1 + 0x34), iVar3 != 0)) {
    iVar2 = *(int *)(iVar3 + 0xc);
    iVar1 = FUN_00b63e30();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
        (uint)*(ushort *)(iVar1 + 0x1da)) {
      iVar2 = FUN_009ba880(iVar3);
      if (iVar2 != 0) {
        iVar3 = FUN_00980070(iVar3);
        if (iVar3 != 0) {
          return 1;
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 23204 ; VA 0x00b09530 ; FUN_00b09530 */

undefined4 __fastcall FUN_00b09530(int param_1)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  int *piVar4;
  uint uVar5;
  
  iVar1 = FUN_00c157b0();
  if (DAT_019203fc <=
      *(float *)(iVar1 + 0x30) * *(float *)(iVar1 + 0x30) +
      *(float *)(iVar1 + 0x34) * *(float *)(iVar1 + 0x34) +
      *(float *)(iVar1 + 0x38) * *(float *)(iVar1 + 0x38)) {
    piVar4 = (int *)(*(int *)(param_1 + 0xa8) + 0xc);
    iVar1 = *(int *)(*(int *)(param_1 + 0xa8) + 0xc);
    while (iVar1 != 0) {
      piVar4 = (int *)(-(uint)(iVar1 != 0) & iVar1 + 4U);
      iVar1 = *piVar4;
    }
    uVar5 = -(uint)(piVar4 != (int *)0x0) & (uint)(piVar4 + -1);
    if (uVar5 == 0) {
      piVar4 = (int *)&DAT_00000014;
    }
    else {
      piVar4 = (int *)(uVar5 + 0xc);
    }
    if (*piVar4 < 1) {
      iVar1 = FUN_00c156b0();
      piVar4 = (int *)(iVar1 + 4);
      iVar1 = *piVar4;
      while (iVar1 != 0) {
        piVar4 = (int *)(-(uint)(iVar1 != 0) & iVar1 + 4U);
        iVar1 = *piVar4;
      }
      piVar2 = piVar4 + 2;
      if (piVar4 == (int *)0x0) {
        piVar2 = (int *)&DAT_0000000c;
      }
      if (*piVar2 < 1) {
        uVar3 = FUN_00c155c0();
        iVar1 = FUN_00c19fc0(uVar3);
        if (*(int *)(iVar1 + 0x14) < 1) {
          return 1;
        }
      }
    }
  }
  return 0;
}



/* FUNCTION 23205 ; VA 0x00b09610 ; FUN_00b09610 */

undefined4 __thiscall FUN_00b09610(int param_1,undefined *param_2)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  char *pcVar4;
  int *piVar5;
  
  if (DAT_01d66c14 != '\0') {
    piVar5 = *(int **)(param_2 + 0x18);
    iVar3 = piVar5[4];
    piVar2 = piVar5;
    if (0xf < (uint)piVar5[5]) {
      piVar2 = (int *)*piVar5;
    }
    cVar1 = FUN_0055c360(piVar2,iVar3,"Surface",7);
    if (cVar1 == '\0') {
      if (0xf < (uint)piVar5[5]) {
        piVar5 = (int *)*piVar5;
      }
      cVar1 = FUN_0055c360(piVar5,iVar3,"Surface Inputs",0xe);
      if (cVar1 == '\0') goto LAB_00b0968f;
    }
    iVar3 = 0;
    while (*(char *)(*(int *)(param_1 + 0xa8) + 0x22f + iVar3) == '\0') {
      iVar3 = iVar3 + 1;
      if (5 < iVar3) {
        return 1;
      }
    }
  }
LAB_00b0968f:
  if (DAT_01d66c24 == '\0') {
    piVar5 = *(int **)(param_2 + 0x18);
    pcVar4 = PTR_DAT_01d66bdc;
    do {
      cVar1 = *pcVar4;
      pcVar4 = pcVar4 + 1;
    } while (cVar1 != '\0');
    piVar2 = piVar5 + 4;
    if (0xf < (uint)piVar5[5]) {
      piVar5 = (int *)*piVar5;
    }
    cVar1 = FUN_0055c360(piVar5,*piVar2,PTR_DAT_01d66bdc,(int)pcVar4 - (int)(PTR_DAT_01d66bdc + 1));
    if (cVar1 != '\0') {
      return 1;
    }
  }
  if (((DAT_01d66c34 == '\0') || ((param_2 != &DAT_0212a580 && (param_2 != &DAT_0212a5b8)))) &&
     ((DAT_01d69068 != '\0' || (param_2 != &DAT_0212a4a0)))) {
    return 0;
  }
  return 1;
}



/* FUNCTION 23206 ; VA 0x00b09710 ; FUN_00b09710 */

byte __fastcall FUN_00b09710(int param_1)

{
  return *(byte *)(param_1 + 0x4c) & 1;
}



/* FUNCTION 23207 ; VA 0x00b09720 ; FUN_00b09720 */

undefined FUN_00b09720(void)

{
  char cVar1;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 1;
  cVar1 = FUN_00a33d60(&uStack_8);
  if (cVar1 == '\0') {
    uStack_c = 2;
    cVar1 = FUN_00a33d60(&uStack_c);
    if (cVar1 == '\0') {
      return 0;
    }
  }
  return 1;
}



/* FUNCTION 23208 ; VA 0x00b09760 ; FUN_00b09760 */

int __fastcall FUN_00b09760(int param_1)

{
  int iVar1;
  uint3 uVar2;
  
  iVar1 = *(int *)(param_1 + 0xa8);
  uVar2 = (uint3)((uint)iVar1 >> 8);
  if ((((*(char *)(iVar1 + 0x233) == '\x04') && (*(char *)(iVar1 + 0x234) == '\0')) &&
      (*(char *)(iVar1 + 0x231) == '\0')) &&
     ((*(char *)(iVar1 + 0x232) == '\0' && (*(char *)(iVar1 + 0x22f) == '\0')))) {
    return CONCAT31(uVar2,1);
  }
  return (uint)uVar2 << 8;
}



/* FUNCTION 23209 ; VA 0x00b097a0 ; FUN_00b097a0 */

void FUN_00b097a0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b0f580();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23210 ; VA 0x00b097e0 ; FUN_00b097e0 */

void FUN_00b097e0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b0f630();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23211 ; VA 0x00b09820 ; FUN_00b09820 */

void FUN_00b09820(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b0f6f0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23212 ; VA 0x00b09860 ; FUN_00b09860 */

void FUN_00b09860(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00b0f780();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23213 ; VA 0x00b098a0 ; FUN_00b098a0 */

void FUN_00b098a0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b0f830();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 23214 ; VA 0x00b098e0 ; FUN_00b098e0 */

int * FUN_00b098e0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00b099b7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00b09936. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1ddb5c4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&RBX::Reflection::
                   ConnectGenericHelper<class_RBX::PartInstance::LocalTouchedSignal>::
                   RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 23215 ; VA 0x00b099d0 ; FUN_00b099d0 */

int * FUN_00b099d0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00b09aa7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00b09a26. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1ddb624);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&RBX::Reflection::ConnectGenericHelper<class_RBX::PartInstance::TouchedSignal>::
                   RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 23216 ; VA 0x00b09ac0 ; FUN_00b09ac0 */

void FUN_00b09ac0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffcf;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x48);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_00b005e0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_009e2cd0();
        FUN_01674ea0(iVar2,0x48);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1ddb588);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_aff7b6bf83f8807ee5a11fbe401a948b>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 23217 ; VA 0x00b09c10 ; FUN_00b09c10 */

bool __fastcall FUN_00b09c10(int param_1)

{
  double *pdVar1;
  undefined auStack_c [8];
  
  pdVar1 = (double *)FUN_01682800(auStack_c);
  return *(double *)(param_1 + 0xb8) <= *pdVar1 && *pdVar1 != *(double *)(param_1 + 0xb8);
}



/* FUNCTION 23218 ; VA 0x00b09c40 ; FUN_00b09c40 */

undefined4 FUN_00b09c40(int *param_1)

{
  int iVar1;
  
  iVar1 = *param_1;
  if ((iVar1 != 0) && (*(int *)(*(int *)(iVar1 + 0xa8) + 0x1a8) != 0)) {
    iVar1 = FUN_008b33d0(iVar1);
    if (iVar1 != 0) {
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 23219 ; VA 0x00b09c70 ; FUN_00b09c70 */

void __thiscall FUN_00b09c70(undefined4 param_1,undefined4 param_2)

{
  FUN_008a3ee0(param_2);
  FUN_00c905f0(param_1,param_2);
  FUN_00b10070();
  FUN_00b0fe90();
  return;
}



/* FUNCTION 23220 ; VA 0x00b09ca0 ; FUN_00b09ca0 */

void FUN_00b09ca0(void)

{
  int iVar1;
  
  iVar1 = FUN_008a40f0();
  if (iVar1 != 0) {
    FUN_008a4100();
    FUN_005e6780();
    return;
  }
  return;
}



/* FUNCTION 23221 ; VA 0x00b09cd0 ; FUN_00b09cd0 */

void __thiscall FUN_00b09cd0(int param_1,float param_2)

{
  if (DAT_018df580 <= param_2) {
    if (DAT_018f9978 <= param_2) {
      if (NAN(*(float *)(param_1 + 0x40)) == (*(float *)(param_1 + 0x40) == 0.0)) {
        *(undefined4 *)(param_1 + 0x40) = 0;
        FUN_008a4940();
        return;
      }
    }
    else if ((NAN(DAT_018ce2f4) || NAN(*(float *)(param_1 + 0x40))) ==
             (DAT_018ce2f4 == *(float *)(param_1 + 0x40))) {
      *(undefined4 *)(param_1 + 0x40) = 0x3f000000;
      FUN_008a4940();
      return;
    }
  }
  else if ((NAN(DAT_018ce2f8) || NAN(*(float *)(param_1 + 0x40))) ==
           (DAT_018ce2f8 == *(float *)(param_1 + 0x40))) {
    *(undefined4 *)(param_1 + 0x40) = 0x3f800000;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 23222 ; VA 0x00b09d80 ; FUN_00b09d80 */

void __thiscall FUN_00b09d80(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  if (DAT_01d6ca30 != '\0') {
    iVar3 = *(int *)(param_2 + 0xc);
    iVar1 = FUN_00d17fd0();
    iVar2 = 0;
    if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar1 + 0x1d8) <=
        (uint)*(ushort *)(iVar1 + 0x1da)) {
      iVar2 = param_2;
    }
    if (iVar2 != 0) {
      FUN_00b0ed70(iVar2);
    }
  }
  iVar3 = *(int *)(param_2 + 0xc);
  iVar2 = FUN_00aeecb0();
  if ((uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    if ((DAT_01d69070 == '\0') && (DAT_01d66be0 == '\0')) {
      iVar3 = FUN_008a4100();
      *(int *)(iVar3 + 0x94) = *(int *)(iVar3 + 0x94) + 1;
      return;
    }
    iVar3 = FUN_008a4100();
    *(int *)(iVar3 + 0x94) = *(int *)(iVar3 + 0x94) + 1;
    iVar3 = FUN_008a40f0();
    if (*(int *)(iVar3 + 0x9c) + *(int *)(iVar3 + 0x98) + *(int *)(iVar3 + 0x94) == 1) {
      FUN_00c184c0(1);
      iVar3 = FUN_00a9d1c0(param_1);
      if (iVar3 != 0) {
        FUN_00ce7ad0(*(undefined4 *)(param_1 + 0xa8));
      }
    }
  }
  return;
}



/* FUNCTION 23223 ; VA 0x00b09e80 ; FUN_00b09e80 */

void __thiscall FUN_00b09e80(int param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  undefined auStack_1c [4];
  int *piStack_18;
  uint uStack_14;
  int iStack_10;
  int iStack_c;
  char cStack_5;
  
  uStack_14 = 0;
  iStack_c = param_1;
  if (DAT_01d6ca30 != '\0') {
    piVar2 = (int *)FUN_00587490(auStack_1c);
    piVar5 = piStack_18;
    iStack_10 = *piVar2;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_18[1] + -1;
      piStack_18[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_18)();
        LOCK();
        piVar2 = piVar5 + 2;
        iVar4 = *piVar2 + -1;
        *piVar2 = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (param_2 == iStack_10) {
      puVar1 = *(undefined4 **)(param_1 + 0x2c);
      if (puVar1 != (undefined4 *)0x0) {
        piVar5 = (int *)puVar1[1];
        for (piVar2 = (int *)*puVar1; piVar2 != piVar5; piVar2 = piVar2 + 2) {
          iStack_10 = *piVar2;
          if ((iStack_10 != 0) &&
             (iVar4 = *(int *)(iStack_10 + 0xc), iVar3 = FUN_00d17fd0(), iVar6 = iStack_10,
             param_1 = iStack_c,
             (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
             (uint)*(ushort *)(iVar3 + 0x1da))) goto LAB_00b09f2f;
          param_1 = iStack_c;
        }
      }
      iVar6 = 0;
LAB_00b09f2f:
      FUN_00b0ed70(iVar6);
    }
  }
  iVar4 = FUN_008a40f0();
  uVar7 = uStack_14;
  if (iVar4 != 0) {
    FUN_008a40f0();
    piVar5 = (int *)FUN_00587490(auStack_1c);
    uVar7 = 1;
    if (param_2 == *piVar5) {
      cStack_5 = '\x01';
      goto LAB_00b09f7b;
    }
  }
  cStack_5 = '\0';
LAB_00b09f7b:
  if (((uVar7 & 1) != 0) && (piStack_18 != (int *)0x0)) {
    LOCK();
    iVar4 = piStack_18[1] + -1;
    piStack_18[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      iVar4 = piStack_18[2] + -1;
      piStack_18[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (cStack_5 != '\0') {
    iVar4 = FUN_008a4100();
    *(undefined4 *)(iVar4 + 0x8c) = 0;
    piVar5 = *(int **)(iVar4 + 0x90);
    *(undefined4 *)(iVar4 + 0x90) = 0;
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar5 + 4))();
      }
    }
  }
  iVar4 = *(int *)(param_2 + 0xc);
  iVar6 = FUN_00aeecb0();
  if ((uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
      (uint)*(ushort *)(iVar6 + 0x1da)) {
    if ((DAT_01d69070 == '\0') && (DAT_01d66be0 == '\0')) {
      iVar4 = FUN_008a4100();
      *(int *)(iVar4 + 0x94) = *(int *)(iVar4 + 0x94) + -1;
      return;
    }
    iVar4 = FUN_008a4100();
    *(int *)(iVar4 + 0x94) = *(int *)(iVar4 + 0x94) + -1;
    iVar4 = FUN_008a40f0();
    if (*(int *)(iVar4 + 0x9c) + *(int *)(iVar4 + 0x98) + *(int *)(iVar4 + 0x94) == 0) {
      FUN_00c184c0(0);
      iVar4 = FUN_00a9d1c0(param_1);
      if (iVar4 != 0) {
        FUN_00ce7ad0(*(undefined4 *)(param_1 + 0xa8));
      }
    }
  }
  return;
}



/* FUNCTION 23224 ; VA 0x00b0a090 ; FUN_00b0a090 */

void __fastcall FUN_00b0a090(int param_1)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_20 [4];
  int *piStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7668;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (*(int **)(param_1 + 0x58) != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(**(int **)(param_1 + 0x58) + 0x60))(param_1 + -0x58);
  }
  iVar4 = FUN_008a40f0();
  if (iVar4 != 0) {
    FUN_008a4100();
    puVar5 = (undefined4 *)FUN_0060dcd0(auStack_20,param_1 + -0x58);
    uStack_8 = 0;
    uVar2 = *puVar5;
    uVar3 = puVar5[1];
    *puVar5 = 0;
    puVar5[1] = 0;
    FUN_0089be10(uVar2,uVar3);
    uStack_8 = 0xffffffff;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar4 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        piVar1 = piStack_1c + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  FUN_00c14350();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23225 ; VA 0x00b0a170 ; FUN_00b0a170 */

void __fastcall FUN_00b0a170(int param_1)

{
  FUN_00c18480(param_1 + 0x18);
  return;
}



/* FUNCTION 23226 ; VA 0x00b0a180 ; FUN_00b0a180 */

void __fastcall FUN_00b0a180(int param_1)

{
  if (*(char *)(*(int *)(param_1 + 0x50) + 0x228) != '\0') {
    FUN_00c17190();
  }
  FUN_008a4940(&DAT_01eed8e0);
  return;
}



/* FUNCTION 23227 ; VA 0x00b0a1b0 ; FUN_00b0a1b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __fastcall FUN_00b0a1b0(int param_1)

{
  char cVar1;
  int iVar2;
  double *pdVar3;
  undefined8 uStack_c;
  
  if (*(char *)(*(int *)(param_1 + 0xa8) + 0x22c) != '\x01') {
    uStack_c = (double)CONCAT44(*(undefined4 *)(*(int *)(param_1 + 0xa8) + 0x1dc),
                                (undefined4)uStack_c);
    cVar1 = FUN_00b09400((int)&uStack_c + 4);
    if ((cVar1 != '\0') && (cVar1 = FUN_008b9b00(param_1), cVar1 != '\0')) {
      iVar2 = FUN_007097d0(*(undefined4 *)(param_1 + 0x34));
      if ((iVar2 != 0) && (iVar2 = FUN_00980070(iVar2), iVar2 != 0)) {
        return;
      }
      pdVar3 = (double *)FUN_01682800(&uStack_c);
      uStack_c = *pdVar3 + _PTR_018dad08;
      *(double *)(param_1 + 0xb8) = uStack_c;
      FUN_00b0df50(1);
    }
  }
  return;
}



/* FUNCTION 23228 ; VA 0x00b0a250 ; FUN_00b0a250 */

void FUN_00b0a250(void)

{
  FUN_008a4210();
  return;
}



/* FUNCTION 23229 ; VA 0x00b0a260 ; FUN_00b0a260 */

int __thiscall FUN_00b0a260(int param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a8348;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  puVar3 = (undefined4 *)FUN_0060dcd0(auStack_24,param_1 + -0x58);
  uStack_1c = *puVar3;
  piVar2 = (int *)puVar3[1];
  *puVar3 = 0;
  puVar3[1] = 0;
  uStack_8 = 0;
  piStack_18 = piVar2;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_20[1] + -1;
    piStack_20[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      iVar4 = piStack_20[2] + -1;
      piStack_20[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  iVar5 = iStack_14 + -0x58;
  iVar4 = FUN_008a40f0();
  if (iVar4 != 0) {
    FUN_008a4100();
    FUN_005e6780(param_2);
  }
  if (*(int **)(iStack_14 + 0x58) != (int *)0x0) {
    (**(code **)(**(int **)(iStack_14 + 0x58) + 0x5c))(param_2,iVar5);
  }
  iVar4 = FUN_0115b050();
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 1;
    iVar5 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      iVar4 = (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        iVar4 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 23230 ; VA 0x00b0a360 ; FUN_00b0a360 */

void FUN_00b0a360(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint uVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017abb78;
  pvStack_10 = ExceptionList;
  uVar7 = 0;
  ExceptionList = &pvStack_10;
  if (param_1[1] != 0) {
    do {
      iVar2 = *(int *)(*param_1 + uVar7 * 4);
      if (iVar2 == 0) {
        uVar5 = 0;
      }
      else {
        iVar2 = *(int *)(iVar2 + 0x1b0);
        uVar5 = -(uint)(iVar2 != 0) & iVar2 - 0x58U;
      }
      puVar6 = (undefined4 *)FUN_0060dcd0(auStack_18,uVar5);
      puVar3 = *(undefined4 **)(param_2 + 4);
      uStack_8 = 0;
      if (*(undefined4 **)(param_2 + 8) == puVar3) {
        FUN_007086e0(puVar3,puVar6);
      }
      else {
        *puVar3 = 0;
        puVar3[1] = 0;
        *puVar3 = *puVar6;
        puVar3[1] = puVar6[1];
        *puVar6 = 0;
        puVar6[1] = 0;
        *(int *)(param_2 + 4) = *(int *)(param_2 + 4) + 8;
      }
      piVar4 = piStack_14;
      uStack_8 = 0xffffffff;
      if (piStack_14 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_14[1] + -1;
        piStack_14[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piStack_14)();
          LOCK();
          piVar1 = piVar4 + 2;
          iVar2 = *piVar1 + -1;
          *piVar1 = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      uVar7 = uVar7 + 1;
    } while (uVar7 < (uint)param_1[1]);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23231 ; VA 0x00b0a450 ; FUN_00b0a450 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b0a450(int param_1,undefined *param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  char cVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  double *pdVar6;
  undefined auStack_c [8];
  
  if (param_2 != &DAT_01eed890) {
    FUN_009cba80(param_2,param_3,param_4);
    return;
  }
  piVar1 = (int *)*param_3;
  iVar5 = *piVar1;
  iVar4 = FUN_0088d550();
  if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  param_2 = (undefined *)0x1;
  param_3 = piVar1 + 2;
  if (piVar1[1] == 0) {
    param_3 = (int *)0x0;
  }
  param_3 = (int *)*param_3;
  cVar2 = FUN_00a33d60(&param_2);
  param_2 = *(undefined **)(*(int *)(param_1 + 0xa8) + 0x1dc);
  cVar3 = FUN_00a33d60(param_4);
  if ((((cVar2 == '\0') || (cVar3 == '\0')) && (iVar5 = FUN_008f7870(param_1), iVar5 != 0)) &&
     (*(int *)(iVar5 + 0x4a0) == 2)) {
    if (cVar2 == '\0') {
      return;
    }
    if (cVar3 == '\0') {
      return;
    }
  }
  FUN_00b0de70(param_3);
  pdVar6 = (double *)FUN_01682800(auStack_c);
  *(double *)(param_1 + 0xb8) = *pdVar6 + _PTR_018dad08;
  return;
}



/* FUNCTION 23232 ; VA 0x00b0a550 ; FUN_00b0a550 */

void __thiscall FUN_00b0a550(int param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  cVar1 = FUN_0087d4d0();
  if (cVar1 == '\0') {
    FUN_0060efa0();
    param_3 = 0;
    iVar2 = FUN_0087cde0(DAT_01ede5c0);
    if (iVar2 != 0) {
      FUN_0087cf20(&param_3);
    }
    uStack_10 = param_3;
    param_3 = 0;
    iVar2 = FUN_0087cde0(DAT_01ede5c4);
    if (iVar2 != 0) {
      FUN_0087cf20(&param_3);
    }
    uStack_c = param_3;
    param_3 = 0;
    iVar2 = FUN_0087cde0(DAT_01ede5c8);
    if (iVar2 != 0) {
      FUN_0087cf20(&param_3);
    }
    uStack_8 = param_3;
    param_3 = 0;
    iVar2 = FUN_0087cde0(DAT_01ede5cc);
    if (iVar2 != 0) {
      FUN_0087cf20(&param_3);
    }
    uStack_34 = param_3;
    param_3 = 0;
    iVar2 = FUN_0087cde0(DAT_01ede5d0);
    if (iVar2 != 0) {
      FUN_0087cf20(&param_3);
    }
    uStack_30 = param_3;
    param_3 = 0;
    iVar2 = FUN_0087cde0(DAT_01ede5d4);
    if (iVar2 != 0) {
      FUN_0087cf20(&param_3);
    }
    uStack_2c = param_3;
    param_3 = 0;
    iVar2 = FUN_0087cde0(DAT_01ede5d8);
    if (iVar2 != 0) {
      FUN_0087cf20(&param_3);
    }
    uStack_28 = param_3;
    param_3 = 0;
    iVar2 = FUN_0087cde0(DAT_01ede5dc);
    if (iVar2 != 0) {
      FUN_0087cf20(&param_3);
    }
    uStack_24 = param_3;
    param_3 = 0;
    iVar2 = FUN_0087cde0(DAT_01ede5e0);
    if (iVar2 != 0) {
      FUN_0087cf20(&param_3);
    }
    uStack_20 = param_3;
    param_3 = 0;
    iVar2 = FUN_0087cde0(DAT_01ede5e4);
    if (iVar2 != 0) {
      FUN_0087cf20(&param_3);
    }
    uStack_1c = param_3;
    param_3 = 0;
    iVar2 = FUN_0087cde0(DAT_01ede5e8);
    if (iVar2 != 0) {
      FUN_0087cf20(&param_3);
    }
    uStack_18 = param_3;
    param_3 = 0;
    iVar2 = FUN_0087cde0(DAT_01ede5ec);
    if (iVar2 != 0) {
      FUN_0087cf20(&param_3);
    }
    uStack_14 = param_3;
    (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_2,&uStack_34);
  }
  return;
}



/* FUNCTION 23233 ; VA 0x00b0a7c0 ; FUN_00b0a7c0 */

int FUN_00b0a7c0(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed7e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_008a40f0();
  if (iVar4 != 0) {
    FUN_008a4100();
    FUN_00587490(&iStack_18);
    uStack_8 = 0;
    if (iStack_18 != 0) {
      FUN_008a65e0(0,1);
    }
    iVar4 = FUN_008a4100();
    *(undefined4 *)(iVar4 + 0x8c) = 0;
    piVar3 = *(int **)(iVar4 + 0x90);
    *(undefined4 *)(iVar4 + 0x90) = 0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar3 = piStack_14 + 1;
      iVar2 = *piVar3;
      iVar4 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)*piStack_14)();
        LOCK();
        piVar3 = piStack_14 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar4 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 23234 ; VA 0x00b0a890 ; FUN_00b0a890 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b0a890(int param_1,int *param_2)

{
  undefined (*pauVar1) [16];
  undefined8 uVar3;
  undefined auVar4 [16];
  char cVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 *puVar9;
  int iVar10;
  undefined (*pauVar11) [16];
  undefined8 *puVar12;
  int *piVar13;
  float *pfVar14;
  float *pfVar15;
  int iVar16;
  char *pcVar17;
  undefined *puVar18;
  code *pcVar19;
  uint uVar20;
  char *pcVar21;
  float10 fVar22;
  float fVar23;
  float fVar24;
  float fVar25;
  undefined (**ppauVar26) [16];
  undefined auStack_220 [104];
  undefined auStack_1b8 [104];
  float fStack_150;
  float fStack_14c;
  float fStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined8 uStack_128;
  float fStack_120;
  undefined8 uStack_11c;
  undefined4 uStack_114;
  undefined auStack_110 [8];
  undefined (*pauStack_108) [16];
  undefined (*pauStack_104) [16];
  undefined (*pauStack_100) [16];
  undefined4 uStack_fc;
  undefined auStack_f8 [12];
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined auStack_dc [4];
  int iStack_d8;
  undefined8 uStack_d4;
  undefined (*pauStack_cc) [16];
  undefined (*pauStack_c8) [16];
  float fStack_c4;
  float fStack_c0;
  float fStack_bc;
  undefined8 uStack_b8;
  float fStack_b0;
  undefined (*pauStack_ac) [16];
  undefined (*pauStack_a8) [16];
  undefined (*pauStack_a4) [16];
  undefined8 uStack_a0;
  undefined (*pauStack_98) [16];
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined8 uStack_7c;
  undefined (*pauStack_74) [16];
  undefined (*pauStack_70) [16];
  undefined (*pauStack_6c) [16];
  undefined (*pauStack_68) [16];
  undefined (*pauStack_64) [16];
  float fStack_60;
  float fStack_5c;
  undefined (*pauStack_58) [16];
  undefined (*pauStack_54) [16];
  undefined (*pauStack_50) [16];
  undefined (*pauStack_4c) [16];
  char cStack_45;
  undefined8 uStack_44;
  float fStack_3c;
  undefined auStack_38 [4];
  code *pcStack_34;
  undefined4 uStack_30;
  undefined (*pauStack_2c) [16];
  undefined (*pauStack_28) [16];
  undefined (*pauStack_24) [16];
  code *pcStack_20;
  undefined (*pauStack_1c) [16];
  undefined (*pauStack_18) [16];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  undefined (*pauVar2) [16];
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017edbf9;
  pvStack_10 = ExceptionList;
  iStack_d8 = param_1 + -0x78;
  fVar23 = DAT_018ce2f8;
  if (0 < *(int *)(param_1 + 0x68)) {
    fVar23 = DAT_018ce2f4;
  }
  if (DAT_018ce2f8 <=
      DAT_018ce2f8 -
      (DAT_018ce2f8 - *(float *)(param_1 + 0x54)) * (DAT_018ce2f8 - *(float *)(param_1 + 0x5c)) *
      fVar23) {
    return;
  }
  if (*(int *)(*(int *)(param_1 + 0x30) + 0x1a8) == 0) {
    return;
  }
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  cVar5 = FUN_00b034b0();
  if (cVar5 != '\0') {
    uVar6 = FUN_0115eb40();
    uVar7 = FUN_00b08170(auStack_1b8);
    thunk_FUN_0114d950(uVar7,param_2,uVar6);
    param_1 = iStack_14;
  }
  pauStack_50 = (undefined (*) [16])0x0;
  pauStack_4c = (undefined (*) [16])0x0;
  if ((DAT_01eecc5a != '\0') && (iVar8 = FUN_00c155c0(), iVar8 != 0)) {
    FUN_00c155c0();
    iVar8 = FUN_0074b510();
    if ((iVar8 == 0) || (iVar8 == 3)) goto LAB_00b0a9f8;
    pauStack_24 = pauStack_50;
    pauStack_28 = pauStack_50;
    pauStack_2c = pauStack_50;
    switch(iVar8) {
    case 1:
    case 2:
      puVar9 = (undefined4 *)FUN_0115eb80();
      break;
    default:
      goto switchD_00b0a995_caseD_3;
    case 4:
      puVar9 = (undefined4 *)FUN_0115eb70();
      break;
    case 5:
      puVar9 = (undefined4 *)FUN_0115ee80();
    }
    pauStack_24 = (undefined (*) [16])puVar9[2];
    pauStack_28 = (undefined (*) [16])puVar9[1];
    pauStack_2c = (undefined (*) [16])*puVar9;
switchD_00b0a995_caseD_3:
    uVar7 = 0x3e19999a;
    ppauVar26 = &pauStack_2c;
    pcStack_20 = (code *)&DAT_3f800000;
    piVar13 = param_2;
    uVar6 = FUN_00b08170(auStack_1b8);
    FUN_0114df50(uVar6,piVar13,ppauVar26,uVar7);
  }
LAB_00b0a9f8:
  if ((DAT_01eecc5b != '\0') && (iVar8 = FUN_00c155c0(), iVar8 != 0)) {
    FUN_00c155c0();
    iVar8 = FUN_0074b510();
    if ((iVar8 == 0) || (iVar8 == 5)) goto LAB_00b0aaa1;
    pauVar11 = pauStack_50;
    pauVar2 = pauStack_50;
    pauVar1 = pauStack_50;
    switch(iVar8) {
    case 1:
    case 2:
      puVar9 = (undefined4 *)FUN_0115eb80();
      break;
    case 3:
      puVar9 = (undefined4 *)FUN_0115eb90();
      break;
    case 4:
      puVar9 = (undefined4 *)FUN_0115eb70();
      break;
    default:
      goto switchD_00b0aa3e_caseD_4;
    }
    pauVar11 = (undefined (*) [16])puVar9[2];
    pauVar2 = (undefined (*) [16])puVar9[1];
    pauVar1 = (undefined (*) [16])*puVar9;
switchD_00b0aa3e_caseD_4:
    pauStack_2c = pauVar1;
    pauStack_28 = pauVar2;
    pauStack_24 = pauVar11;
    uVar7 = 0x3e19999a;
    ppauVar26 = &pauStack_2c;
    pcStack_20 = (code *)&DAT_3f800000;
    piVar13 = param_2;
    uVar6 = FUN_00b08170(auStack_1b8);
    FUN_0114df50(uVar6,piVar13,ppauVar26,uVar7);
  }
LAB_00b0aaa1:
  if (DAT_01eecc5e != '\0') {
    FUN_00e70680(param_2);
  }
  if ((DAT_01eecc5d != '\0') && (*(char *)(*(int *)(param_1 + 0x30) + 0x223) != '\0')) {
    fVar22 = (float10)FUN_007b3d80();
    pcStack_34 = (code *)(float)fVar22;
    puVar9 = (undefined4 *)FUN_0115eb40();
    pauStack_2c = (undefined (*) [16])*puVar9;
    pauStack_28 = (undefined (*) [16])puVar9[1];
    pauStack_24 = (undefined (*) [16])puVar9[2];
    pcStack_20 = pcStack_34;
    uVar6 = FUN_00c157b0();
    uStack_44 = 0xbf80000000000000;
    fStack_3c = 0.0;
    uVar6 = FUN_00c935d0(&uStack_44,uVar6);
    uVar7 = FUN_00b08170(auStack_1b8);
    FUN_0114c5f0(uVar7,uVar6,param_2,&pauStack_2c,0x3e4ccccd);
  }
  if ((DAT_01eecc5f != '\0') && (cVar5 = FUN_00b023e0(0), cVar5 == '\0')) {
    puVar9 = (undefined4 *)FUN_0115ee80();
    uVar7 = 0x3e19999a;
    pauStack_2c = (undefined (*) [16])*puVar9;
    pauStack_28 = (undefined (*) [16])puVar9[1];
    pauStack_24 = (undefined (*) [16])puVar9[2];
    ppauVar26 = &pauStack_2c;
    pcStack_20 = (code *)&DAT_3f800000;
    piVar13 = param_2;
    uVar6 = FUN_00b08170(auStack_1b8);
    FUN_0114df50(uVar6,piVar13,ppauVar26,uVar7);
  }
  iVar8 = iStack_14;
  if ((DAT_01eecc60 != '\0') && (iVar10 = FUN_00c156f0(), iVar10 != 0)) {
    cVar5 = FUN_00c1a160(*(undefined4 *)(iVar8 + 0x30));
    if (cVar5 == '\0') {
      iVar10 = *(int *)(iVar8 + 0x30);
      iVar16 = FUN_00c1a100(iVar10);
      iVar8 = iStack_14;
      if (iVar16 == iVar10) {
        pcVar19 = *(code **)(*param_2 + 0x54);
        iVar8 = FUN_00c157b0();
        uVar6 = FUN_00709da0(iVar8 + 0x24);
        (*pcVar19)(uVar6);
        uStack_44 = 0x3ecccccd3ecccccd;
        fStack_3c = 0.4;
        pcVar19 = *(code **)(*param_2 + 0x5c);
        puVar9 = (undefined4 *)FUN_0115e920();
        pauStack_ac = (undefined (*) [16])0xbecccccd;
        pauStack_a8 = (undefined (*) [16])0xbecccccd;
        pauStack_a4 = (undefined (*) [16])0xbecccccd;
        pauStack_2c = (undefined (*) [16])*puVar9;
        pauStack_28 = (undefined (*) [16])puVar9[1];
        pauStack_24 = (undefined (*) [16])puVar9[2];
        pcStack_20 = (code *)&DAT_3f800000;
        uVar6 = FUN_00709d10(&pauStack_ac,&uStack_44);
        (*pcVar19)(uVar6,&pauStack_2c);
        iVar8 = iStack_14;
      }
      else {
        cVar5 = FUN_00ca1a80(*(undefined4 *)(iStack_14 + 0x30));
        if (cVar5 == '\0') {
          cVar5 = FUN_00ff4d10(*(undefined4 *)(iVar8 + 0x30));
          if (cVar5 != '\0') {
            pcVar19 = *(code **)(*param_2 + 0x54);
            iVar8 = FUN_00c157b0();
            uVar6 = FUN_00709da0(iVar8 + 0x24);
            (*pcVar19)(uVar6);
            pcVar19 = *(code **)(*param_2 + 0x78);
            puVar9 = (undefined4 *)FUN_0115eb70();
            pauStack_2c = (undefined (*) [16])*puVar9;
            pauStack_28 = (undefined (*) [16])puVar9[1];
            pauStack_24 = (undefined (*) [16])puVar9[2];
            pcStack_20 = (code *)&DAT_3f800000;
            (*pcVar19)(0x3e000000,0x3e800000,&pauStack_2c,1);
            iVar8 = iStack_14;
          }
        }
        else {
          pcVar19 = *(code **)(*param_2 + 0x54);
          iVar8 = FUN_00c157b0();
          uVar6 = FUN_00709da0(iVar8 + 0x24);
          (*pcVar19)(uVar6);
          pcVar19 = *(code **)(*param_2 + 100);
          pfVar14 = (float *)FUN_0115ee80();
          pauStack_2c = (undefined (*) [16])(*pfVar14 * DAT_018f994c);
          pauStack_28 = (undefined (*) [16])(pfVar14[1] * DAT_018f994c);
          pcStack_20 = (code *)&DAT_3f800000;
          pauStack_24 = (undefined (*) [16])(pfVar14[2] * DAT_018f994c);
          uStack_44 = 0;
          fStack_3c = 0.0;
          uVar6 = FUN_007a4af0(&uStack_44,0x3ecccccd);
          (*pcVar19)(uVar6,&pauStack_2c);
          iVar8 = iStack_14;
        }
      }
    }
    else {
      pcVar19 = *(code **)(*param_2 + 0x54);
      iVar8 = FUN_00c157b0();
      uVar6 = FUN_00709da0(iVar8 + 0x24);
      (*pcVar19)(uVar6);
      iVar8 = iStack_14;
      uStack_44 = 0x3ecccccd3ecccccd;
      fStack_3c = 0.4;
      cVar5 = FUN_00ca0f60(*(undefined4 *)(iStack_14 + 0x30));
      pcStack_34 = *(code **)(*param_2 + 0x5c);
      if (cVar5 == '\0') {
        puVar9 = (undefined4 *)FUN_0115eb70();
      }
      else {
        puVar9 = (undefined4 *)FUN_0115eb90();
      }
      pauStack_2c = (undefined (*) [16])*puVar9;
      pauStack_28 = (undefined (*) [16])puVar9[1];
      pauStack_24 = (undefined (*) [16])puVar9[2];
      pcStack_20 = (code *)&DAT_3f800000;
      pauStack_ac = (undefined (*) [16])0xbecccccd;
      pauStack_a8 = (undefined (*) [16])0xbecccccd;
      pauStack_a4 = (undefined (*) [16])0xbecccccd;
      uVar6 = FUN_00709d10(&pauStack_ac,&uStack_44);
      (*pcStack_34)(uVar6,&pauStack_2c);
    }
    if (DAT_01d6f4b8 != '\0') {
      pauStack_18 = *(undefined (**) [16])(iVar8 + 0x30);
      pauStack_1c = (undefined (*) [16])FUN_00c156b0();
      pauStack_64 = (undefined (*) [16])FUN_00c155c0();
      pcStack_34 = (code *)0x0;
      if (0 < *(int *)(pauStack_18[1] + 4)) {
        do {
          pauStack_58 = (undefined (*) [16])FUN_00c156b0();
          pauVar11 = (undefined (*) [16])FUN_00c155c0();
          iVar8 = FUN_00c157b0();
          uStack_44 = *(undefined8 *)(iVar8 + 0x24);
          fStack_3c = *(float *)(iVar8 + 0x2c);
          iVar8 = FUN_00c157b0();
          uStack_b8 = *(undefined8 *)(iVar8 + 0x24);
          fStack_b0 = *(float *)(iVar8 + 0x2c);
          if (pauStack_64 == pauVar11) {
            if (pauStack_58 == pauStack_1c) {
              puVar12 = (undefined8 *)FUN_0115eb40();
            }
            else {
              puVar12 = (undefined8 *)FUN_0115e920();
            }
          }
          else {
            puVar12 = (undefined8 *)FUN_0115e940();
          }
          uStack_a0 = *puVar12;
          pauStack_98 = *(undefined (**) [16])(puVar12 + 1);
          FUN_0060efa0();
          pauStack_2c = (undefined (*) [16])uStack_a0;
          pauStack_28 = uStack_a0._4_4_;
          pauStack_24 = pauStack_98;
          pcStack_20 = (code *)&DAT_3f800000;
          FUN_0114bfd0(param_2,&uStack_94,&uStack_44,&uStack_b8,&pauStack_2c,0x3da3d70a);
          pcStack_34 = pcStack_34 + 1;
          iVar8 = iStack_14;
        } while ((int)pcStack_34 < *(int *)(pauStack_18[1] + 4));
      }
    }
  }
  if (DAT_01eecc58 != '\0') {
    pcStack_34 = (code *)0x0;
    iVar10 = FUN_00c16390();
    if (0 < iVar10) {
      pcVar19 = (code *)0x0;
      do {
        piVar13 = (int *)FUN_00c15720(pcVar19);
        puVar12 = (undefined8 *)FUN_0115ee70();
        uVar3 = *puVar12;
        pauStack_cc = *(undefined (**) [16])(puVar12 + 1);
        uStack_d4 = uVar3;
        if (*(char *)((int)piVar13 + 0xd) == '\0') {
          uStack_d4._4_4_ = (undefined (*) [16])((ulonglong)uVar3 >> 0x20);
          pauStack_64 = uStack_d4._4_4_;
          uStack_d4._0_4_ = (undefined (*) [16])uVar3;
          pauStack_1c = (undefined (*) [16])uStack_d4;
          pauStack_18 = pauStack_cc;
        }
        else {
          puVar9 = (undefined4 *)FUN_0115eb90();
          pauStack_1c = (undefined (*) [16])*puVar9;
          pauStack_64 = (undefined (*) [16])puVar9[1];
          pauStack_18 = (undefined (*) [16])puVar9[2];
        }
        (**(code **)(*piVar13 + 0x34))(&uStack_a0,1);
        uStack_8 = 0;
        pauStack_58 = uStack_a0._4_4_;
        if ((undefined (*) [16])uStack_a0 != uStack_a0._4_4_) {
          pauStack_1c = (undefined (*) [16])((float)pauStack_1c * DAT_018f994c);
          fStack_c4 = 0.0;
          fStack_c0 = 0.0;
          fStack_bc = 0.0;
          pauStack_64 = (undefined (*) [16])((float)pauStack_64 * DAT_018f994c);
          pauStack_ac = (undefined (*) [16])0x0;
          pauStack_a8 = (undefined (*) [16])0x0;
          pauStack_a4 = (undefined (*) [16])0x0;
          pauStack_18 = (undefined (*) [16])((float)pauStack_18 * DAT_018f994c);
          pauVar11 = (undefined (*) [16])uStack_a0;
          do {
            auVar4 = *pauVar11;
            uStack_11c = auVar4._0_8_;
            uStack_e0 = *(undefined4 *)(pauVar11[1] + 8);
            uStack_e8 = (undefined4)*(undefined8 *)pauVar11[1];
            uStack_e4 = (undefined4)((ulonglong)*(undefined8 *)pauVar11[1] >> 0x20);
            auStack_f8 = auVar4._0_12_;
            uStack_ec = auVar4._12_4_;
            uStack_140 = _DAT_018e3fb0;
            uStack_13c = _UNK_018e3fb4;
            uStack_138 = _UNK_018e3fb8;
            uStack_134 = _UNK_018e3fbc;
            fStack_120 = 1.0;
            uStack_130 = _DAT_018e3fb0;
            uStack_12c = _UNK_018e3fb4;
            uStack_128 = CONCAT44(_UNK_018e3fbc,_UNK_018e3fb8);
            uStack_114 = auVar4._8_4_;
            (**(code **)(*param_2 + 0x54))(&uStack_140);
            pauStack_2c = pauStack_1c;
            pauStack_28 = pauStack_64;
            fStack_120 = fStack_bc;
            uStack_114 = uStack_e4;
            pauStack_24 = pauStack_18;
            uStack_128 = CONCAT44(fStack_c0,fStack_c4);
            uStack_11c = CONCAT44(uStack_e8,uStack_ec);
            pcStack_20 = (code *)&DAT_3f800000;
            (**(code **)(*param_2 + 0x80))(&uStack_128,&pauStack_2c);
            pauStack_108 = pauStack_1c;
            pauStack_6c = pauStack_a4;
            pauStack_104 = pauStack_64;
            pauStack_100 = pauStack_18;
            uStack_fc = 0x3f800000;
            pauStack_74 = pauStack_ac;
            pauStack_70 = pauStack_a8;
            pauStack_68 = (undefined (*) [16])0x3f000000;
            (**(code **)(*param_2 + 100))(&pauStack_74,&pauStack_108);
            pauVar11 = (undefined (*) [16])(pauVar11[1] + 0xc);
          } while (pauVar11 != pauStack_58);
        }
        uStack_8 = 0xffffffff;
        if ((undefined (*) [16])uStack_a0 != (undefined (*) [16])0x0) {
          uVar20 = (((int)pauStack_98 - (int)(undefined (*) [16])uStack_a0) / 0x1c) * 0x1c;
          pauVar11 = (undefined (*) [16])uStack_a0;
          if (0xfff < uVar20) {
            pauVar11 = *(undefined (**) [16])(((undefined (*) [16])uStack_a0)[-1] + 0xc);
            uVar20 = uVar20 + 0x23;
            if ((undefined *)0x1f <
                (undefined *)((int)(undefined (*) [16])uStack_a0 + (-4 - (int)pauVar11))) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(pauVar11,uVar20);
          uStack_a0 = 0;
          pauStack_98 = (undefined (*) [16])0x0;
        }
        iVar8 = iStack_14;
        pcStack_34 = pcStack_34 + 1;
        iVar10 = FUN_00c16390();
        pcVar19 = pcStack_34;
      } while ((int)pcStack_34 < iVar10);
    }
  }
  if (DAT_01eecc59 != '\0') {
    pcVar19 = *(code **)(*param_2 + 0x54);
    pfVar14 = (float *)FUN_00c157b0();
    pfVar15 = (float *)(**(code **)(**(int **)(*(int *)(iStack_14 + 0x30) + 0x1ac) + 0x5c))
                                 (&uStack_44);
    fVar23 = pfVar15[1];
    fVar24 = *pfVar15;
    fVar25 = pfVar15[2];
    fStack_b0 = pfVar14[6] * fVar24 + pfVar14[7] * fVar23 + pfVar14[8] * fVar25 + pfVar14[0xb];
    pauStack_6c = (undefined (*) [16])
                  (pfVar14[3] * fVar24 + pfVar14[4] * fVar23 + pfVar14[5] * fVar25 + pfVar14[10]);
    pauStack_70 = (undefined (*) [16])
                  (pfVar14[1] * fVar23 + *pfVar14 * fVar24 + pfVar14[2] * fVar25 + pfVar14[9]);
    uStack_94 = _DAT_018e3fb0;
    uStack_90 = _UNK_018e3fb4;
    uStack_8c = _UNK_018e3fb8;
    uStack_88 = _UNK_018e3fbc;
    uStack_84 = _DAT_018e3fb0;
    uStack_80 = _UNK_018e3fb4;
    uStack_7c = CONCAT44(_UNK_018e3fbc,_UNK_018e3fb8);
    pauStack_74 = (undefined (*) [16])0x3f800000;
    pauStack_68 = (undefined (*) [16])fStack_b0;
    (*pcVar19)(&uStack_94);
    pcVar19 = *(code **)(*param_2 + 100);
    pfVar14 = (float *)FUN_0115eb70();
    fStack_b0 = 0.0;
    pauStack_28 = (undefined (*) [16])(pfVar14[1] * DAT_018f994c);
    pauStack_6c = (undefined (*) [16])0x0;
    pauStack_24 = (undefined (*) [16])(pfVar14[2] * DAT_018f994c);
    pcStack_20 = (code *)0x3f800000;
    pauStack_2c = (undefined (*) [16])(*pfVar14 * DAT_018f994c);
    pauStack_68 = (undefined (*) [16])0x3e4ccccd;
    pauStack_74 = pauStack_50;
    pauStack_70 = pauStack_50;
    (*pcVar19)(&pauStack_74,&pauStack_2c);
    pcVar19 = *(code **)(*param_2 + 0x54);
    uVar6 = FUN_00c157b0();
    (*pcVar19)(uVar6);
    pcVar19 = *(code **)(*param_2 + 0x80);
    pfVar14 = (float *)FUN_0115eb90();
    fStack_b0 = 0.0;
    fStack_3c = 0.0;
    pauStack_24 = (undefined (*) [16])(pfVar14[2] * DAT_018ce2f4);
    pauStack_74 = (undefined (*) [16])0x0;
    pauStack_28 = (undefined (*) [16])(pfVar14[1] * DAT_018ce2f4);
    pauStack_68 = (undefined (*) [16])0x0;
    pauStack_2c = (undefined (*) [16])(*pfVar14 * DAT_018ce2f4);
    uStack_7c = CONCAT44(pauStack_50,pauStack_50);
    pcStack_20 = (code *)0x3f800000;
    pauStack_70 = (undefined (*) [16])DAT_018daf58;
    pauStack_6c = pauStack_50;
    (*pcVar19)(&uStack_7c,&pauStack_2c);
    pcVar19 = *(code **)(*param_2 + 0x80);
    pfVar14 = (float *)FUN_0115eb50();
    fStack_b0 = 0.0;
    fStack_3c = 0.0;
    pauStack_28 = (undefined (*) [16])(pfVar14[1] * DAT_018ce2f4);
    pauStack_74 = (undefined (*) [16])0x0;
    pauStack_24 = (undefined (*) [16])(pfVar14[2] * DAT_018ce2f4);
    pauStack_68 = (undefined (*) [16])0x0;
    uStack_7c = CONCAT44(pauStack_50,pauStack_50);
    pauStack_2c = (undefined (*) [16])(*pfVar14 * DAT_018ce2f4);
    pcStack_20 = (code *)0x3f800000;
    pauStack_70 = pauStack_50;
    pauStack_6c = (undefined (*) [16])DAT_018daf58;
    (*pcVar19)(&uStack_7c,&pauStack_2c);
    pcVar19 = *(code **)(*param_2 + 0x80);
    pfVar14 = (float *)FUN_0115e920();
    fStack_b0 = 0.0;
    fStack_3c = 2.0;
    pauStack_28 = (undefined (*) [16])(pfVar14[1] * DAT_018ce2f4);
    pauStack_74 = (undefined (*) [16])0x0;
    pauStack_24 = (undefined (*) [16])(pfVar14[2] * DAT_018ce2f4);
    pauStack_68 = (undefined (*) [16])0x40000000;
    pauStack_2c = (undefined (*) [16])(*pfVar14 * DAT_018ce2f4);
    uStack_7c = CONCAT44(pauStack_50,pauStack_50);
    pcStack_20 = (code *)&DAT_3f800000;
    pauStack_70 = pauStack_50;
    pauStack_6c = pauStack_50;
    (*pcVar19)(&uStack_7c,&pauStack_2c);
    pauStack_18 = (undefined (*) [16])0x0;
    iVar8 = iStack_14;
    if (0 < *(int *)(*(int *)(iStack_14 + 0x30) + 0x1d4) -
            *(int *)(*(int *)(iStack_14 + 0x30) + 0x1d0) >> 3) {
      do {
        pauStack_58 = (undefined (*) [16])FUN_00c156d0(pauStack_18);
        iVar10 = (**(code **)(*(int *)*pauStack_58 + 0x10))();
        if (iVar10 - 7U < 0x13) {
          fStack_c4 = 2.0;
          pcStack_34 = (code *)0x0;
          fStack_c0 = 0.0;
          fStack_bc = 0.0;
          pauStack_ac = (undefined (*) [16])0x0;
          pauStack_a8 = (undefined (*) [16])0x0;
          pauStack_a4 = (undefined (*) [16])0x0;
          uStack_a0 = 0x4000000000000000;
          pauStack_98 = (undefined (*) [16])0x0;
          uStack_d4 = 0;
          pauStack_cc = (undefined (*) [16])0x0;
          uStack_44 = 0;
          fStack_3c = 2.0;
          pauStack_54 = (undefined (*) [16])0x0;
          pauStack_50 = (undefined (*) [16])0x0;
          pauStack_4c = (undefined (*) [16])0x0;
          do {
            pcVar19 = *(code **)(*param_2 + 0x54);
            uVar6 = FUN_00ca3fa0(&uStack_94,pcStack_34);
            (*pcVar19)(uVar6);
            pcVar19 = *(code **)(*param_2 + 0x80);
            pfVar14 = (float *)FUN_0115eb90();
            pauStack_24 = (undefined (*) [16])(pfVar14[2] * DAT_018ce2f4);
            pauStack_74 = pauStack_a4;
            pauStack_68 = (undefined (*) [16])fStack_bc;
            uStack_7c = CONCAT44(pauStack_a8,pauStack_ac);
            pauStack_2c = (undefined (*) [16])(*pfVar14 * DAT_018ce2f4);
            pauStack_28 = (undefined (*) [16])(pfVar14[1] * DAT_018ce2f4);
            pcStack_20 = (code *)&DAT_3f800000;
            pauStack_70 = (undefined (*) [16])fStack_c4;
            pauStack_6c = (undefined (*) [16])fStack_c0;
            (*pcVar19)(&uStack_7c,&pauStack_2c);
            pcVar19 = *(code **)(*param_2 + 0x80);
            pfVar14 = (float *)FUN_0115eb50();
            pauStack_100 = (undefined (*) [16])(pfVar14[2] * DAT_018ce2f4);
            pauStack_74 = pauStack_cc;
            pauStack_68 = pauStack_98;
            pauStack_108 = (undefined (*) [16])(*pfVar14 * DAT_018ce2f4);
            pauStack_104 = (undefined (*) [16])(pfVar14[1] * DAT_018ce2f4);
            uStack_7c = uStack_d4;
            uStack_fc = 0x3f800000;
            pauStack_70 = (undefined (*) [16])uStack_a0;
            pauStack_6c = (undefined (*) [16])((ulonglong)uStack_a0 >> 0x20);
            (*pcVar19)(&uStack_7c,&pauStack_108);
            pcVar19 = *(code **)(*param_2 + 0x80);
            pfVar14 = (float *)FUN_0115e920();
            fStack_148 = pfVar14[2] * DAT_018ce2f4;
            uStack_144 = 0x3f800000;
            fStack_150 = *pfVar14 * DAT_018ce2f4;
            fStack_14c = pfVar14[1] * DAT_018ce2f4;
            uStack_7c = CONCAT44(pauStack_50,pauStack_54);
            pauStack_74 = pauStack_4c;
            pauStack_68 = (undefined (*) [16])fStack_3c;
            pauStack_70 = (undefined (*) [16])uStack_44;
            pauStack_6c = (undefined (*) [16])((ulonglong)uStack_44 >> 0x20);
            (*pcVar19)(&uStack_7c,&fStack_150);
            pcStack_34 = pcStack_34 + 1;
            iVar8 = iStack_14;
          } while ((int)pcStack_34 < 2);
        }
        pauStack_18 = (undefined (*) [16])(*pauStack_18 + 1);
      } while ((int)pauStack_18 <
               *(int *)(*(int *)(iVar8 + 0x30) + 0x1d4) - *(int *)(*(int *)(iVar8 + 0x30) + 0x1d0)
               >> 3);
    }
  }
  if ((((DAT_01d66bf4 != '\0') && (DAT_01eeeba9 != '\0')) && (iVar8 != 0x78)) &&
     (iVar10 = *(int *)(iVar8 + -0x6c), iVar16 = FUN_00b50240(), iVar8 = iStack_14,
     (uint)*(ushort *)(iVar10 + 0x1d8) - (uint)*(ushort *)(iVar16 + 0x1d8) <=
     (uint)*(ushort *)(iVar16 + 0x1da))) {
    FUN_00b53eb0(&pauStack_50);
    uStack_8 = 1;
    if (pauStack_50 != (undefined (*) [16])0x0) {
      FUN_00b54150(&fStack_60);
      pauStack_18 = pauStack_50;
      pcVar19 = *(code **)(*param_2 + 0x54);
      uVar6 = FUN_00c157b0();
      (*pcVar19)(uVar6);
      pauStack_1c = (undefined (*) [16])0x0;
      if (*(int *)pauStack_18[2] - *(int *)(pauStack_18[1] + 0xc) >> 2 != 0) {
        pcStack_34 = (code *)(iStack_14 + 0x50);
        do {
          pcVar19 = *(code **)(*param_2 + 0x48);
          puVar9 = (undefined4 *)FUN_0115e8a0(pcStack_34);
          uStack_ec = *puVar9;
          uStack_e8 = puVar9[1];
          uStack_e4 = puVar9[2];
          uStack_e0 = 0x3f800000;
          iVar8 = *(int *)pauStack_18[1];
          iVar10 = *(int *)(*(int *)(pauStack_18[1] + 0xc) + 4 + (int)pauStack_1c * 4) * 0x54;
          fStack_3c = *(float *)(iVar10 + 8 + iVar8) * (float)pauStack_58;
          uStack_44 = CONCAT44(*(float *)(iVar10 + 4 + iVar8) * fStack_5c,
                               fStack_60 * *(float *)(iVar10 + iVar8));
          iVar10 = *(int *)(*(int *)(pauStack_18[1] + 0xc) + (int)pauStack_1c * 4) * 0x54;
          pauStack_ac = (undefined (*) [16])(fStack_60 * *(float *)(iVar10 + iVar8));
          pauStack_a8 = (undefined (*) [16])(*(float *)(iVar10 + 4 + iVar8) * fStack_5c);
          pauStack_a4 = (undefined (*) [16])(*(float *)(iVar10 + 8 + iVar8) * (float)pauStack_58);
          (*pcVar19)(&pauStack_ac,&uStack_44,&uStack_ec);
          pcVar19 = *(code **)(*param_2 + 0x48);
          pfVar14 = (float *)FUN_0115e8a0(pcStack_34);
          fStack_120 = *pfVar14;
          uStack_11c = *(undefined8 *)(pfVar14 + 1);
          uStack_114 = 0x3f800000;
          iVar8 = *(int *)pauStack_18[1];
          iVar10 = *(int *)(*(int *)(pauStack_18[1] + 0xc) + 8 + (int)pauStack_1c * 4) * 0x54;
          fStack_c4 = fStack_60 * *(float *)(iVar10 + iVar8);
          fStack_c0 = *(float *)(iVar10 + 4 + iVar8) * fStack_5c;
          fStack_bc = *(float *)(iVar10 + 8 + iVar8) * (float)pauStack_58;
          iVar10 = *(int *)(*(int *)(pauStack_18[1] + 0xc) + 4 + (int)pauStack_1c * 4) * 0x54;
          pauStack_cc = (undefined (*) [16])(*(float *)(iVar10 + 8 + iVar8) * (float)pauStack_58);
          uStack_d4 = CONCAT44(*(float *)(iVar10 + 4 + iVar8) * fStack_5c,
                               fStack_60 * *(float *)(iVar10 + iVar8));
          (*pcVar19)(&uStack_d4,&fStack_c4,&fStack_120);
          pcVar19 = *(code **)(*param_2 + 0x48);
          puVar9 = (undefined4 *)FUN_0115e8a0(pcStack_34);
          pauStack_74 = (undefined (*) [16])*puVar9;
          pauStack_70 = (undefined (*) [16])puVar9[1];
          pauStack_6c = (undefined (*) [16])puVar9[2];
          pauStack_68 = (undefined (*) [16])0x3f800000;
          iVar8 = *(int *)pauStack_18[1];
          iVar10 = *(int *)(*(int *)(pauStack_18[1] + 0xc) + (int)pauStack_1c * 4) * 0x54;
          pauStack_98 = (undefined (*) [16])(*(float *)(iVar10 + 8 + iVar8) * (float)pauStack_58);
          uStack_a0 = CONCAT44(*(float *)(iVar10 + 4 + iVar8) * fStack_5c,
                               fStack_60 * *(float *)(iVar10 + iVar8));
          iVar10 = *(int *)(*(int *)(pauStack_18[1] + 0xc) + 8 + (int)pauStack_1c * 4) * 0x54;
          fStack_b0 = *(float *)(iVar10 + 8 + iVar8) * (float)pauStack_58;
          uStack_b8 = CONCAT44(*(float *)(iVar10 + 4 + iVar8) * fStack_5c,
                               fStack_60 * *(float *)(iVar10 + iVar8));
          (*pcVar19)(&uStack_b8,&uStack_a0,&pauStack_74);
          pauStack_1c = (undefined (*) [16])(*pauStack_1c + 3);
        } while (pauStack_1c <
                 (undefined (*) [16])(*(int *)pauStack_18[2] - *(int *)(pauStack_18[1] + 0xc) >> 2))
        ;
      }
    }
    pauVar11 = pauStack_4c;
    uStack_8 = 0xffffffff;
    iVar8 = iStack_14;
    if (pauStack_4c != (undefined (*) [16])0x0) {
      LOCK();
      iVar10 = *(int *)(*pauStack_4c + 4) + -1;
      *(int *)(*pauStack_4c + 4) = iVar10;
      UNLOCK();
      if (iVar10 == 0) {
        (*(code *)**(undefined4 **)*pauStack_4c)();
        LOCK();
        piVar13 = (int *)(*pauVar11 + 8);
        iVar10 = *piVar13 + -1;
        *piVar13 = iVar10;
        UNLOCK();
        iVar8 = iStack_14;
        if (iVar10 == 0) {
          (**(code **)(*(int *)*pauVar11 + 4))();
          iVar8 = iStack_14;
        }
      }
    }
  }
  if (((DAT_01edfaff != '\0') && (iVar10 = FUN_00c155c0(), iVar10 != 0)) &&
     (pauStack_58 = (undefined (*) [16])FUN_00c1a100(*(undefined4 *)(iVar8 + 0x30)),
     pauStack_58 != (undefined (*) [16])0x0)) {
    piVar13 = (int *)(*(int *)pauStack_58[0x1b] + 0x50);
    if (*(int *)pauStack_58[0x1b] == 0) {
      piVar13 = (int *)0xa8;
    }
    iVar8 = *(int *)(*piVar13 + 0x1dc);
    if (iVar8 == 1) {
      puVar12 = (undefined8 *)FUN_0115ee70();
LAB_00b0bcdd:
      pauStack_54 = (undefined (*) [16])*puVar12;
      pauStack_50 = (undefined (*) [16])((ulonglong)*puVar12 >> 0x20);
      pauStack_4c = *(undefined (**) [16])(puVar12 + 1);
    }
    else {
      if ((iVar8 == -1) || (iVar8 == 2)) {
        puVar12 = (undefined8 *)FUN_0115e910();
        goto LAB_00b0bcdd;
      }
      if (iVar8 == 3) {
        puVar12 = (undefined8 *)FUN_0115eb40();
        goto LAB_00b0bcdd;
      }
      FUN_00f81b20(&pauStack_54,iVar8);
    }
    pcStack_34 = (code *)FUN_00c155c0();
    cVar5 = FUN_00bb6f80(pcStack_34);
    pauVar1 = pauStack_54;
    pauVar2 = pauStack_50;
    pauVar11 = pauStack_4c;
    if ((cVar5 == '\0') &&
       ((*(int *)(pcStack_34 + 0x3c) == 2 || (*(int *)(pcStack_34 + 0x3c) == 3)))) {
      puVar9 = (undefined4 *)FUN_00f81c00(2);
      pauVar1 = (undefined (*) [16])*puVar9;
      pauVar2 = (undefined (*) [16])puVar9[1];
      pauVar11 = (undefined (*) [16])puVar9[2];
    }
    uVar7 = 0x3e19999a;
    ppauVar26 = &pauStack_74;
    pauStack_68 = (undefined (*) [16])0x3f800000;
    piVar13 = param_2;
    pauStack_74 = pauVar1;
    pauStack_70 = pauVar2;
    pauStack_6c = pauVar11;
    uVar6 = FUN_00b08170(auStack_1b8);
    FUN_0114df50(uVar6,piVar13,ppauVar26,uVar7);
    if (DAT_01d66c04 != '\0') {
      (**(code **)*param_2)();
      iVar8 = FUN_00b08170(auStack_1b8);
      FUN_00d23e50(&uStack_44,iVar8 + 0x5c);
      (**(code **)*param_2)();
      iVar8 = FUN_00712f10();
      iVar10 = FUN_00b08170(auStack_1b8);
      fVar24 = *(float *)(iVar8 + 0x24) - *(float *)(iVar10 + 0x5c);
      fVar23 = *(float *)(iVar8 + 0x28) - *(float *)(iVar10 + 0x60);
      fVar25 = *(float *)(iVar8 + 0x2c) - *(float *)(iVar10 + 100);
      if ((pcStack_34 == (code *)0x0) || (1 < *(int *)(pcStack_34 + 0x3c))) {
        cStack_45 = '\0';
      }
      else {
        cStack_45 = '\x01';
      }
      if ((DAT_01eecc68 == 0) ||
         (fVar24 * fVar24 + fVar23 * fVar23 + fVar25 * fVar25 < (float)DAT_01eecc68)) {
        pauStack_58 = *(undefined (**) [16])(*(int *)(iStack_14 + 0x30) + 0x1a0);
        if (pauStack_58 == (undefined (*) [16])0x0) {
          if (cStack_45 == '\0') {
            uStack_30 = _DAT_018e3fc0;
            pauStack_2c = _UNK_018e3fc4;
            pauStack_28 = _UNK_018e3fc8;
            pauStack_24 = _UNK_018e3fcc;
            pcStack_20 = (code *)0x0;
            pauStack_74 = _DAT_018e3fd0;
            pauStack_70 = _UNK_018e3fd4;
            pauStack_6c = _UNK_018e3fd8;
            pauStack_68 = (undefined (*) [16])_UNK_018e3fdc;
            pauStack_50 = (undefined (*) [16])0x0;
            pauStack_4c = (undefined (*) [16])0x0;
            pfVar14 = (float *)FUN_0115e910();
            fStack_120 = *pfVar14;
            uStack_11c = *(undefined8 *)(pfVar14 + 1);
            uStack_114 = 0x3f800000;
            puVar9 = (undefined4 *)FUN_0115ee70();
            uStack_ec = *puVar9;
            uStack_e8 = puVar9[1];
            uStack_e4 = puVar9[2];
            fStack_5c = (float)uStack_44;
            uStack_e0 = 0x3f800000;
            pauStack_58 = uStack_44._4_4_;
            uVar6 = FUN_01675640(auStack_110,&DAT_018fbf28);
            uStack_8 = 3;
            puVar18 = auStack_38;
            goto LAB_00b0bfa9;
          }
        }
        else {
          pcStack_34 = (code *)0x0;
          if ((*(int *)pauStack_58[3] != 0) &&
             (pcVar21 = *(char **)(pauStack_58[2] + 8), pcVar21 != (char *)0x0)) {
            pcVar19 = (code *)0x0;
            do {
              pcStack_34 = pcVar19 + 1;
              if (*pcVar21 == '\0') {
                pcStack_34 = pcVar19;
              }
              pcVar17 = pcVar21 + 0x60;
              if (pcVar17 == *(char **)(pauStack_58[2] + 4)) {
                pcVar17 = *(char **)pauStack_58[2];
              }
              pcVar21 = (char *)0x0;
              if (pcVar17 != *(char **)(pauStack_58[2] + 0xc)) {
                pcVar21 = pcVar17;
              }
              pcVar19 = pcStack_34;
            } while (pcVar21 != (char *)0x0);
          }
          if (cStack_45 == '\0') {
            uStack_30 = _DAT_018e3fc0;
            pauStack_2c = _UNK_018e3fc4;
            pauStack_28 = _UNK_018e3fc8;
            pauStack_24 = _UNK_018e3fcc;
            pcStack_20 = (code *)0x0;
            pauStack_74 = _DAT_018e3fd0;
            pauStack_70 = _UNK_018e3fd4;
            pauStack_6c = _UNK_018e3fd8;
            pauStack_68 = (undefined (*) [16])_UNK_018e3fdc;
            pauStack_50 = (undefined (*) [16])0x0;
            pauStack_4c = (undefined (*) [16])0x0;
            pfVar14 = (float *)FUN_0115e910();
            fStack_120 = *pfVar14;
            uStack_11c = *(undefined8 *)(pfVar14 + 1);
            uStack_114 = 0x3f800000;
            puVar9 = (undefined4 *)FUN_0115ee70();
            uStack_ec = *puVar9;
            uStack_e8 = puVar9[1];
            uStack_e4 = puVar9[2];
            fStack_5c = (float)uStack_44;
            uStack_e0 = 0x3f800000;
            pauStack_58 = uStack_44._4_4_;
            uVar6 = FUN_01675640(auStack_110,&DAT_018bed68,pcStack_34);
            uStack_8 = 2;
            puVar18 = auStack_dc;
LAB_00b0bfa9:
            FUN_0114e430(puVar18,uVar6,&fStack_5c,0x41400000,0,&uStack_ec,&fStack_120,0,1,0,
                         &pauStack_50,&pauStack_74,&uStack_30,1);
            uStack_8 = 0xffffffff;
            FUN_005507b0();
          }
        }
      }
    }
  }
  if ((DAT_01eecc62 != '\0') && (iVar8 = FUN_00c155c0(), iVar8 != 0)) {
    puVar9 = (undefined4 *)FUN_00f81be0(&pauStack_28,iVar8);
    pauStack_74 = (undefined (*) [16])*puVar9;
    uVar7 = 0x3e19999a;
    pauStack_70 = (undefined (*) [16])puVar9[1];
    pauStack_6c = (undefined (*) [16])puVar9[2];
    ppauVar26 = &pauStack_74;
    pauStack_68 = (undefined (*) [16])0x3f800000;
    piVar13 = param_2;
    uVar6 = FUN_00b08170(auStack_1b8);
    FUN_0114df50(uVar6,piVar13,ppauVar26,uVar7);
  }
  if ((DAT_01eecc61 != '\0') && (iVar8 = FUN_00c156f0(), iVar8 != 0)) {
    puVar9 = (undefined4 *)FUN_00f81be0(&pauStack_28,iVar8);
    pauStack_74 = (undefined (*) [16])*puVar9;
    uVar7 = 0x3e19999a;
    pauStack_70 = (undefined (*) [16])puVar9[1];
    pauStack_6c = (undefined (*) [16])puVar9[2];
    ppauVar26 = &pauStack_74;
    pauStack_68 = (undefined (*) [16])0x3f800000;
    piVar13 = param_2;
    uVar6 = FUN_00b08170(auStack_1b8);
    FUN_0114df50(uVar6,piVar13,ppauVar26,uVar7);
  }
  if (DAT_01eecc64 == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  if (DAT_01d66c3c == '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  iVar8 = FUN_00c155c0();
  if (iVar8 == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  cVar5 = *(char *)(iVar8 + 0x39);
  if (cVar5 == '\x01') {
    uVar6 = 0;
  }
  else {
    if (cVar5 != '\x02') {
      if (cVar5 != '\x04') {
        ExceptionList = pvStack_10;
        return;
      }
      puVar9 = (undefined4 *)FUN_00f81c00(9);
      pauStack_c8 = (undefined (*) [16])*puVar9;
      fStack_c4 = (float)puVar9[1];
      fStack_c0 = (float)puVar9[2];
      ppauVar26 = &pauStack_c8;
      puVar18 = auStack_220;
      fStack_bc = 1.0;
      goto LAB_00b0c26a;
    }
    uVar6 = 3;
  }
  puVar9 = (undefined4 *)FUN_00f81c00(uVar6);
  pauStack_74 = (undefined (*) [16])*puVar9;
  pauStack_70 = (undefined (*) [16])puVar9[1];
  pauStack_6c = (undefined (*) [16])puVar9[2];
  ppauVar26 = &pauStack_74;
  puVar18 = auStack_1b8;
  pauStack_68 = (undefined (*) [16])0x3f800000;
LAB_00b0c26a:
  uVar7 = 0x3e19999a;
  uVar6 = FUN_00b08170(puVar18);
  FUN_0114df50(uVar6,param_2,ppauVar26,uVar7);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23235 ; VA 0x00b0c2c0 ; FUN_00b0c2c0 */

void FUN_00b0c2c0(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined auStack_6c [104];
  
  uVar2 = 0x3ca3d70a;
  uVar1 = FUN_00b08170(auStack_6c);
  FUN_0114df80(uVar1,param_1,param_2,uVar2);
  return;
}



/* FUNCTION 23236 ; VA 0x00b0c2f0 ; FUN_00b0c2f0 */

void FUN_00b0c2f0(int *param_1,undefined4 param_2,undefined4 param_3)

{
  code *pcVar1;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017d0aa1;
  pvStack_10 = ExceptionList;
  pcVar1 = *(code **)(*param_1 + 8);
  ExceptionList = &pvStack_10;
  uStack_f0 = FUN_0088d550();
  uStack_ec = 0;
  uStack_e8 = param_2;
  uStack_ec = FUN_00631380();
  uStack_8 = 0;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  FUN_00687980(&uStack_f0,&uStack_20,param_1);
  uStack_8._0_1_ = 1;
  (*pcVar1)(uStack_14,&uStack_20,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00577b20();
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_f0,0xd0,1,FUN_0056e5b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23237 ; VA 0x00b0c3d0 ; FUN_00b0c3d0 */

int FUN_00b0c3d0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed7e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_008a40f0();
  if (iVar3 != 0) {
    FUN_008a4100();
    iVar3 = FUN_00587490(&iStack_18);
    uStack_8 = 0;
    if (iStack_18 != 0) {
      iVar3 = FUN_00aef900(param_1);
      if ((char)iVar3 != '\0') {
        FUN_008a4100();
        if (param_1[1] != 0) {
          LOCK();
          piVar1 = (int *)(param_1[1] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        iVar3 = FUN_00b018a0(*param_1,param_1[1]);
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 23238 ; VA 0x00b0c4a0 ; FUN_00b0c4a0 */

undefined4 FUN_00b0c4a0(void)

{
  int iVar1;
  
  iVar1 = FUN_008a40f0();
  if ((iVar1 != 0) &&
     (((*(int *)(iVar1 + 0xa0) != 0 || (*(int *)(iVar1 + 0xb8) != 0)) ||
      (0 < *(int *)(iVar1 + 0x94))))) {
    return 1;
  }
  return 0;
}



/* FUNCTION 23239 ; VA 0x00b0c4d0 ; FUN_00b0c4d0 */

int FUN_00b0c4d0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ed7e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_008a40f0();
  if (iVar3 != 0) {
    FUN_008a4100();
    iVar3 = FUN_00587490(&iStack_18);
    uStack_8 = 0;
    if (iStack_18 != 0) {
      iVar3 = FUN_00aef920(param_1);
      if ((char)iVar3 != '\0') {
        FUN_008a4100();
        if (param_1[1] != 0) {
          LOCK();
          piVar1 = (int *)(param_1[1] + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        iVar3 = FUN_00b018a0(*param_1,param_1[1]);
      }
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piStack_14 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar3 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 23240 ; VA 0x00b0c5a0 ; FUN_00b0c5a0 */

void __thiscall FUN_00b0c5a0(int param_1,double param_2)

{
  double *pdVar1;
  undefined auStack_c [8];
  
  pdVar1 = (double *)FUN_01682800(auStack_c);
  *(double *)(param_1 + 0xb8) = *pdVar1 + param_2;
  return;
}



/* FUNCTION 23241 ; VA 0x00b0c5e0 ; FUN_00b0c5e0 */

undefined __thiscall FUN_00b0c5e0(int *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined uVar1;
  
  uVar1 = FUN_00b0c610(param_2,param_3);
  (**(code **)(*param_1 + 0x130))(2);
  return uVar1;
}



/* FUNCTION 23242 ; VA 0x00b0c610 ; FUN_00b0c610 */

undefined4 __thiscall FUN_00b0c610(int *param_1,int param_2,uint param_3)

{
  int iVar1;
  char cVar2;
  float *pfVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  float fVar8;
  float fVar9;
  undefined auStack_c8 [12];
  float fStack_bc;
  float fStack_b8;
  float fStack_b4;
  float fStack_b0;
  float fStack_ac;
  float fStack_a8;
  float fStack_a4;
  float fStack_a0;
  float fStack_9c;
  undefined8 uStack_98;
  float fStack_90;
  float fStack_8c;
  float fStack_88;
  float fStack_84;
  float fStack_80;
  float fStack_7c;
  float fStack_78;
  float fStack_74;
  float fStack_70;
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  float fStack_60;
  float fStack_5c;
  float fStack_58;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  float fStack_48;
  float fStack_44;
  float fStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  float fStack_30;
  float fStack_2c;
  undefined8 uStack_24;
  undefined8 uStack_1c;
  float fStack_14;
  float afStack_10 [3];
  
  if (param_3 == 0) {
    return 0;
  }
  uStack_1c = *(undefined8 *)(*(int *)(param_1[0x2a] + 0x1ac) + 4);
  fStack_14 = *(float *)(*(int *)(param_1[0x2a] + 0x1ac) + 0xc);
  pfVar3 = (float *)FUN_00c157b0();
  afStack_10[0] = 0.0;
  afStack_10[1] = 0.0;
  afStack_10[2] = 0.0;
  fStack_68 = *pfVar3;
  fStack_64 = pfVar3[1];
  fStack_60 = pfVar3[2];
  fStack_5c = pfVar3[3];
  fStack_58 = pfVar3[4];
  fStack_54 = pfVar3[5];
  fStack_50 = pfVar3[6];
  fStack_4c = pfVar3[7];
  fStack_48 = pfVar3[8];
  fStack_44 = pfVar3[9];
  fStack_40 = pfVar3[10];
  fStack_3c = pfVar3[0xb];
  fVar8 = DAT_018f7864;
  if (param_2 < 3) {
    fVar8 = DAT_018ce2f8;
  }
  uStack_24 = (ulonglong)(uint)(float)(int)param_3;
  cVar2 = (**(code **)(*param_1 + 0xb0))();
  fVar9 = (float)uStack_24;
  if (cVar2 == '\0') {
    uStack_24 = CONCAT44(fVar9,fVar9);
    afStack_10[2] = fVar9;
    afStack_10[0] = fVar9;
    afStack_10[1] = fVar9;
  }
  else {
    afStack_10[param_2 % 3] = fVar9;
  }
  fStack_74 = (float)uStack_1c + afStack_10[0];
  fStack_70 = uStack_1c._4_4_ + afStack_10[1];
  fStack_6c = fStack_14 + afStack_10[2];
  (**(code **)(*param_1 + 0xe4))(&fStack_38,&fStack_74);
  fStack_34 = fStack_34 - uStack_1c._4_4_;
  fStack_38 = fStack_38 - (float)uStack_1c;
  fStack_30 = fStack_30 - fStack_14;
  fStack_9c = fStack_48;
  fStack_90 = (fStack_34 * fStack_4c + fStack_38 * fStack_50 + fStack_30 * fStack_48) * DAT_018ce2f4
              * fVar8 + fStack_3c;
  fStack_bc = fStack_68;
  fStack_b8 = fStack_64;
  fStack_b4 = fStack_60;
  fStack_b0 = fStack_5c;
  fStack_ac = fStack_58;
  fStack_a8 = fStack_54;
  fStack_a4 = fStack_50;
  fStack_a0 = fStack_4c;
  uStack_98 = CONCAT44((fStack_34 * fStack_58 + fStack_38 * fStack_5c + fStack_30 * fStack_54) *
                       DAT_018ce2f4 * fVar8 + fStack_40,
                       (fStack_34 * fStack_64 + fStack_38 * fStack_68 + fStack_30 * fStack_60) *
                       DAT_018ce2f4 * fVar8 + fStack_44);
  afStack_10[2] = fStack_90;
  (**(code **)(*param_1 + 0x108))(&fStack_bc);
  (**(code **)(*param_1 + 0xe8))(&fStack_38);
  (**(code **)(**(int **)(param_1[0x2a] + 0x1ac) + 0x14))(&fStack_8c);
  iVar4 = FUN_00a9d1c0(param_1);
  if ((iVar4 != 0) && (cVar2 = FUN_00ff2910(param_1,iVar4,DAT_01d70298,0xc3c80000), cVar2 != '\0'))
  {
    (**(code **)(*param_1 + 0x108))(&fStack_68);
    (**(code **)(*param_1 + 0xe8))(&uStack_1c);
    return 0;
  }
  (**(code **)(**(int **)(param_1[0x2a] + 0x1ac) + 0x14))(&fStack_80);
  param_3 = 0;
  uStack_24 = CONCAT44(fStack_80 / fStack_8c,(undefined4)uStack_24);
  fStack_2c = fStack_78 / fStack_84;
  iVar4 = FUN_005d6c30();
  if (iVar4 != 0) {
    do {
      iVar4 = *(int *)(*(int *)param_1[0xb] + param_3 * 8);
      iVar1 = *(int *)(iVar4 + 0xc);
      iVar5 = FUN_00d6bbd0();
      iVar7 = 0;
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
          (uint)*(ushort *)(iVar5 + 0x1da)) {
        iVar7 = iVar4;
      }
      if (iVar7 != 0) {
        pfVar3 = (float *)FUN_00a6bd00(auStack_c8);
        afStack_10[1] = pfVar3[1] * (fStack_7c / fStack_88);
        afStack_10[2] = pfVar3[2] * fStack_2c;
        afStack_10[0] = *pfVar3 * uStack_24._4_4_;
        FUN_00d6dad0(afStack_10);
      }
      param_3 = param_3 + 1;
      uVar6 = FUN_005d6c30();
    } while (param_3 < uVar6);
  }
  return 1;
}



/* FUNCTION 23243 ; VA 0x00b0c990 ; FUN_00b0c990 */

void FUN_00b0c990(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  char cVar2;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  
  cVar2 = FUN_00c93d40(param_2);
  uVar1 = DAT_018c45d0;
  if (cVar2 != '\0') {
    *param_1 = 0x3f800000;
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
    param_1[4] = 0x3f800000;
    param_1[5] = 0;
    param_1[6] = 0;
    param_1[7] = 0;
    param_1[8] = 0x3f800000;
    *(ulonglong *)(param_1 + 9) = (ulonglong)uVar1 << 0x20;
    param_1[0xb] = 0;
    return;
  }
  uStack_40 = *param_2;
  uStack_3c = param_2[1];
  uStack_38 = param_2[2];
  uStack_34 = param_2[3];
  uStack_30 = param_2[4];
  uStack_2c = param_2[5];
  uStack_28 = param_2[6];
  uStack_24 = param_2[7];
  uStack_20 = param_2[8];
  uStack_1c = param_2[9];
  uStack_18 = param_2[10];
  uStack_14 = param_2[0xb];
  FUN_00c94b40(&uStack_40);
  *param_1 = uStack_40;
  param_1[1] = uStack_3c;
  param_1[2] = uStack_38;
  param_1[3] = uStack_34;
  param_1[4] = uStack_30;
  param_1[5] = uStack_2c;
  param_1[6] = uStack_28;
  param_1[7] = uStack_24;
  param_1[8] = uStack_20;
  param_1[9] = uStack_1c;
  param_1[10] = uStack_18;
  param_1[0xb] = uStack_14;
  return;
}



/* FUNCTION 23244 ; VA 0x00b0ca50 ; FUN_00b0ca50 */

void __thiscall FUN_00b0ca50(int param_1,int param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  char cVar5;
  undefined4 uVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  int *piStack_30;
  int *piStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  char cStack_12;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017edc20;
  pvStack_10 = ExceptionList;
  iStack_1c = *(int *)(param_1 + 0xa8);
  cVar5 = (char)param_2;
  if (cVar5 != *(char *)(iStack_1c + 0x223)) {
    piStack_34 = (int *)0x0;
    piStack_30 = (int *)0x0;
    piStack_2c = (int *)0x0;
    uVar6 = 0xffffffff;
    iStack_8 = 0;
    cStack_11 = '\0';
    iStack_18 = param_1;
    if (cVar5 == '\0') {
      iVar3 = *(int *)(iStack_1c + 0x1d0);
      ExceptionList = &pvStack_10;
      if (0 < (int)(*(int *)(iStack_1c + 0x1d4) - iVar3 & 0xfffffff8U)) {
        iVar2 = 0;
        ExceptionList = &pvStack_10;
        do {
          if (*(int *)(iVar3 + 4 + iVar2 * 8) != 0) {
            piVar4 = (int *)FUN_00c156d0(iVar2);
            iVar3 = (**(code **)(*piVar4 + 0x10))();
            if (iVar3 - 1U < 4) {
              iVar3 = FUN_00c155c0();
              if ((iVar3 != 0) && (iVar7 = 0, 0 < *(int *)(iVar3 + 0x14))) {
                do {
                  FUN_00ca1550();
                  iStack_28 = FUN_00c15700();
                  if (iStack_28 != 0) {
                    if (piStack_2c == piStack_30) {
                      FUN_0063d9b0(piStack_30,&iStack_28);
                    }
                    else {
                      *piStack_30 = iStack_28;
                      piStack_30 = piStack_30 + 1;
                    }
                  }
                  iVar7 = iVar7 + 1;
                } while (iVar7 < *(int *)(iVar3 + 0x14));
              }
            }
            else {
              cVar1 = FUN_00c14800();
              if ((cVar1 == '\0') && (iStack_28 = FUN_00c15700(), iStack_28 != 0)) {
                if (piStack_2c == piStack_30) {
                  FUN_0063d9b0(piStack_30,&iStack_28);
                }
                else {
                  *piStack_30 = iStack_28;
                  piStack_30 = piStack_30 + 1;
                }
              }
            }
          }
          iVar2 = iVar2 + 1;
          iVar3 = *(int *)(iStack_1c + 0x1d0);
        } while (iVar2 < *(int *)(iStack_1c + 0x1d4) - iVar3 >> 3);
      }
      uVar6 = 0xffffffff;
      if (DAT_01d66c44 == '\0') {
        cStack_11 = FUN_00ca09e0(&piStack_34);
      }
      cStack_12 = param_2._3_1_;
      iVar2 = param_2;
      iVar3 = iStack_18;
    }
    else {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_00c15700();
      iStack_28 = iVar2;
      if (iVar2 == 0) {
        iVar2 = 0;
        cStack_12 = param_2._3_1_;
      }
      else {
        cStack_12 = *(char *)(iVar2 + 0x22c) == '\x01';
        uVar6 = *(undefined4 *)(iVar2 + 0x1dc);
        uStack_24 = uVar6;
        iVar3 = FUN_00c155c0();
        iVar7 = 0;
        iStack_1c = iVar3;
        if (0 < *(int *)(iVar3 + 0x14)) {
          do {
            iVar2 = *(int *)(*(int *)(iVar3 + 0x10) + iVar7 * 4);
            if ((-(uint)(iVar2 != 0) & iVar2 - 8U) != 0) {
              iVar2 = FUN_00ca1550();
              iStack_20 = iVar2;
              cVar1 = FUN_00c14800();
              if (cVar1 == '\0') {
                if (piStack_2c == piStack_30) {
                  FUN_0063d9b0(piStack_30,&iStack_20);
                }
                else {
                  *piStack_30 = iVar2;
                  piStack_30 = piStack_30 + 1;
                }
              }
            }
            iVar7 = iVar7 + 1;
            iVar2 = iStack_28;
            uVar6 = uStack_24;
          } while (iVar7 < *(int *)(iVar3 + 0x14));
        }
        if ((-(uint)(*(int *)(iStack_1c + 0xc) != 0) & *(int *)(iStack_1c + 0xc) - 8U) != 0) {
          iVar3 = FUN_00ca1550();
          iStack_28 = iVar3;
          cVar1 = FUN_00c14800();
          if (cVar1 == '\0') {
            if (piStack_2c == piStack_30) {
              FUN_0063d9b0(piStack_30,&iStack_28);
            }
            else {
              *piStack_30 = iVar3;
              piStack_30 = piStack_30 + 1;
            }
          }
        }
      }
      iVar3 = iStack_18;
      if (DAT_01d66c44 == '\0') {
        iStack_28 = FUN_00c15700();
        if (iStack_28 == 0) {
          cStack_11 = '\0';
        }
        else {
          uStack_40 = 0;
          uStack_3c = 0;
          uStack_38 = 0;
          iStack_8._0_1_ = 1;
          FUN_0063d9b0(0,&iStack_28);
          cStack_11 = FUN_00ca09e0(&uStack_40);
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          FUN_0056d320();
        }
      }
    }
    FUN_00c180b0(param_2);
    iVar3 = FUN_008f7870(iVar3);
    if (cVar5 == '\0') {
      if ((iVar3 != 0) && ((*(int *)(iVar3 + 0x4a0) == 2 || (*(int *)(iVar3 + 0x4a0) == 3)))) {
        FUN_00b0fef0(&piStack_34);
      }
      if (((DAT_01d66c44 == '\0') && (cStack_11 != '\0')) && (iVar3 = FUN_00c15700(), iVar3 != 0)) {
        uVar6 = FUN_00c155c0();
        FUN_00ca1cb0(uVar6);
      }
    }
    else {
      if ((iVar3 != 0) && ((*(int *)(iVar3 + 0x4a0) == 2 || (*(int *)(iVar3 + 0x4a0) == 3)))) {
        if (iVar2 != 0) {
          uVar8 = -(uint)(*(int *)(iVar2 + 0x1b0) != 0) & *(int *)(iVar2 + 0x1b0) - 0x58U;
          cVar1 = FUN_0098c5a0(uVar8,0);
          if ((cVar1 != '\0') && (*(char *)(*(int *)(uVar8 + 0xa8) + 0x22c) != '\0')) {
            *(undefined *)(*(int *)(uVar8 + 0xa8) + 0x22c) = 0;
            cVar1 = FUN_0098c5a0(uVar8,0);
            if (cVar1 != '\0') {
              FUN_008a4940(&DAT_01eed490);
            }
          }
        }
        uVar8 = 0;
        if ((int)piStack_30 - (int)piStack_34 >> 2 != 0) {
          do {
            iVar3 = FUN_00c15700();
            if ((((iVar3 != 0) &&
                 (uVar9 = -(uint)(*(int *)(iVar3 + 0x1b0) != 0) & *(int *)(iVar3 + 0x1b0) - 0x58U,
                 uVar9 != 0)) && (iVar3 = FUN_008f7870(uVar9), iVar3 != 0)) &&
               ((*(int *)(iVar3 + 0x4a0) == 2 || (*(int *)(iVar3 + 0x4a0) == 3)))) {
              if ((cStack_12 != '\0') && (*(char *)(*(int *)(uVar9 + 0xa8) + 0x22c) != '\x01')) {
                *(undefined *)(*(int *)(uVar9 + 0xa8) + 0x22c) = 1;
                cVar1 = FUN_0098c5a0(uVar9,0);
                if (cVar1 != '\0') {
                  FUN_008a4940(&DAT_01eed490);
                }
              }
              FUN_00b0df50(uVar6);
            }
            uVar8 = uVar8 + 1;
          } while (uVar8 < (uint)((int)piStack_30 - (int)piStack_34 >> 2));
        }
      }
      if ((DAT_01d66c44 == '\0') && (cStack_11 != '\0')) {
        uVar9 = 0;
        uVar8 = (uint)((int)piStack_30 + (3 - (int)piStack_34)) >> 2;
        if (piStack_30 < piStack_34) {
          uVar8 = 0;
        }
        if (uVar8 != 0) {
          do {
            uVar6 = FUN_00c155c0();
            FUN_00ca1cb0(uVar6);
            uVar9 = uVar9 + 1;
          } while (uVar9 != uVar8);
        }
      }
    }
    FUN_008a4940(&DAT_01eed578);
    if ((DAT_01d66bec != '\0') && (cVar5 != '\0')) {
      FUN_008a4940(&DAT_0212a430);
      FUN_00c14380();
    }
    if (piStack_34 != (int *)0x0) {
      uVar8 = (int)piStack_2c - (int)piStack_34 & 0xfffffffc;
      piVar4 = piStack_34;
      if (0xfff < uVar8) {
        piVar4 = (int *)piStack_34[-1];
        uVar8 = uVar8 + 0x23;
        if (0x1f < (uint)((int)piStack_34 + (-4 - (int)piVar4))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(piVar4,uVar8);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 23245 ; VA 0x00b0cf80 ; FUN_00b0cf80 */

void __thiscall FUN_00b0cf80(int param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  int iVar3;
  float *pfVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  undefined8 uStack_38;
  float fStack_30;
  undefined8 uStack_2c;
  float fStack_24;
  undefined8 uStack_20;
  undefined4 uStack_18;
  undefined8 uStack_14;
  float fStack_c;
  int iStack_8;
  
  if ((DAT_01d66c24 != '\0') && (*(int *)(*(int *)(param_1 + 0xa8) + 0x1a8) != 0)) {
    iVar3 = FUN_00c155c0();
    if (iVar3 == 0) {
      iVar3 = FUN_00c157b0();
      uStack_20 = *(undefined8 *)(iVar3 + 0x30);
      uStack_18 = *(undefined4 *)(iVar3 + 0x38);
      uStack_14 = *(undefined8 *)param_2;
      fStack_c = param_2[2];
      FUN_00c19180(&uStack_20);
      return;
    }
    FUN_00c155c0();
    iStack_8 = FUN_00ca1550();
    iVar3 = iStack_8 + 0x50;
    if (iStack_8 == 0) {
      iVar3 = 0;
    }
    FUN_00fa07b0();
    if ((((NAN(*(float *)(iVar3 + 0xf0)) || NAN(*param_2)) == (*(float *)(iVar3 + 0xf0) == *param_2)
         ) || ((NAN(*(float *)(iVar3 + 0xf4)) || NAN(param_2[1])) ==
               (*(float *)(iVar3 + 0xf4) == param_2[1]))) ||
       ((NAN(*(float *)(iVar3 + 0xf8)) || NAN(param_2[2])) ==
        (*(float *)(iVar3 + 0xf8) == param_2[2]))) {
      pfVar4 = (float *)FUN_00f9fa20();
      fVar8 = pfVar4[1];
      fVar1 = *pfVar4;
      fVar2 = pfVar4[2];
      fVar7 = *(float *)(iVar3 + 0xf0) - *param_2;
      fVar10 = *(float *)(iVar3 + 0xc0) * fVar1 + *(float *)(iVar3 + 0xc4) * fVar8 +
               *(float *)(iVar3 + 200) * fVar2;
      fVar5 = *(float *)(iVar3 + 0xf4) - param_2[1];
      fVar9 = *(float *)(iVar3 + 0xd0) * fVar8 + *(float *)(iVar3 + 0xcc) * fVar1 +
              *(float *)(iVar3 + 0xd4) * fVar2;
      fVar6 = *(float *)(iVar3 + 0xf8) - param_2[2];
      fVar8 = *(float *)(iVar3 + 0xb8) * fVar8 + fVar1 * *(float *)(iVar3 + 0xb4) +
              *(float *)(iVar3 + 0xbc) * fVar2;
      uStack_2c = *(undefined8 *)param_2;
      fStack_30 = (fVar7 * fVar10 - fVar5 * fVar8) + *(float *)(iVar3 + 0xec);
      fStack_24 = param_2[2];
      uStack_38 = CONCAT44((fVar6 * fVar8 - fVar7 * fVar9) + *(float *)(iVar3 + 0xe8),
                           (fVar5 * fVar9 - fVar6 * fVar10) + *(float *)(iVar3 + 0xe4));
      fStack_c = fStack_30;
      FUN_00c19180(&uStack_38);
      FUN_00b0a1b0();
      FUN_008a4940(&DAT_0212a6d0);
      FUN_008a4940(&DAT_0212a580);
      FUN_008a4940(&DAT_0212a5b8);
    }
  }
  return;
}



/* FUNCTION 23246 ; VA 0x00b0d1e0 ; FUN_00b0d1e0 */

void __thiscall FUN_00b0d1e0(int param_1,float *param_2)

{
  int iVar1;
  float *pfVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  undefined8 uStack_38;
  float fStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_24;
  undefined8 uStack_20;
  float fStack_18;
  undefined8 uStack_14;
  float fStack_c;
  float fStack_8;
  
  if ((DAT_01d66c24 != '\0') && (*(int *)(*(int *)(param_1 + 0xa8) + 0x1a8) != 0)) {
    iVar1 = FUN_00c155c0();
    if (iVar1 == 0) {
      iVar1 = FUN_00c157b0();
      uStack_14 = *(undefined8 *)(iVar1 + 0x3c);
      fStack_c = *(float *)(iVar1 + 0x44);
      uStack_20 = *(undefined8 *)param_2;
      fStack_18 = param_2[2];
      FUN_00c19180(&uStack_20);
      return;
    }
    FUN_00c155c0();
    iVar1 = FUN_00ca1550();
    if (iVar1 == 0) {
      iVar1 = 0;
      fStack_8 = 1.12104e-43;
    }
    else {
      iVar1 = iVar1 + 0x50;
      fStack_8 = (float)iVar1;
    }
    FUN_00fa07b0();
    pfVar2 = (float *)FUN_00f9fa20();
    fVar3 = pfVar2[1];
    fVar4 = *pfVar2;
    fVar5 = pfVar2[2];
    fStack_8 = *(float *)(iVar1 + 0xc0) * fVar4 + *(float *)(iVar1 + 0xc4) * fVar3 +
               *(float *)(iVar1 + 200) * fVar5;
    fVar6 = *(float *)(iVar1 + 0xd0) * fVar3 + *(float *)(iVar1 + 0xcc) * fVar4 +
            *(float *)(iVar1 + 0xd4) * fVar5;
    fVar5 = *(float *)(iVar1 + 0xb8) * fVar3 + fVar4 * *(float *)(iVar1 + 0xb4) +
            *(float *)(iVar1 + 0xbc) * fVar5;
    fVar4 = *param_2 - (*(float *)(iVar1 + 0xf4) * fVar6 - *(float *)(iVar1 + 0xf8) * fStack_8);
    fVar3 = param_2[1] - (*(float *)(iVar1 + 0xf8) * fVar5 - *(float *)(iVar1 + 0xf0) * fVar6);
    fStack_30 = param_2[2] -
                (*(float *)(iVar1 + 0xf0) * fStack_8 - *(float *)(iVar1 + 0xf4) * fVar5);
    uStack_14 = CONCAT44(fVar3,fVar4);
    if ((((NAN(*(float *)(iVar1 + 0xe4)) || NAN(fVar4)) == (*(float *)(iVar1 + 0xe4) == fVar4)) ||
        ((NAN(*(float *)(iVar1 + 0xe8)) || NAN(fVar3)) == (*(float *)(iVar1 + 0xe8) == fVar3))) ||
       ((NAN(*(float *)(iVar1 + 0xec)) || NAN(fStack_30)) == (*(float *)(iVar1 + 0xec) == fStack_30)
       )) {
      uStack_24 = *(undefined4 *)(iVar1 + 0xf8);
      uStack_38 = uStack_14;
      uStack_2c = *(undefined8 *)(iVar1 + 0xf0);
      fStack_c = fStack_30;
      FUN_00c19180(&uStack_38);
      FUN_00b0a1b0();
      FUN_008a4940(&DAT_0212a698);
      FUN_008a4940(&DAT_0212a580);
    }
  }
  return;
}



/* FUNCTION 23247 ; VA 0x00b0d450 ; FUN_00b0d450 */

void __thiscall FUN_00b0d450(int param_1,uint param_2)

{
  byte bVar1;
  
  bVar1 = (byte)param_2 ^ 1;
  param_2 = param_2 ^ 1;
  if (bVar1 != *(byte *)(*(int *)(param_1 + 0xa8) + 0x225)) {
    FUN_00c18df0(param_2);
    FUN_008a4940(&DAT_01eed5b0);
  }
  return;
}



/* FUNCTION 23248 ; VA 0x00b0d490 ; FUN_00b0d490 */

void __thiscall FUN_00b0d490(int param_1,undefined4 param_2)

{
  bool bVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  undefined auStack_10 [4];
  int *piStack_c;
  uint uStack_8;
  
  uStack_8 = 0;
  if (DAT_01d69068 == '\0') {
    return;
  }
  if (*(char *)(*(int *)(param_1 + 0xa8) + 0x226) == (char)param_2) {
    return;
  }
  FUN_00c18130(param_2);
  iVar2 = FUN_008a40f0();
  if ((char)param_2 != '\0') {
    if (0 < *(int *)(iVar2 + 0x9c) + *(int *)(iVar2 + 0x98) + *(int *)(iVar2 + 0x94)) {
      FUN_00b022e0();
      FUN_00c184c0(1);
    }
    goto LAB_00b0d588;
  }
  uVar4 = uStack_8;
  if (iVar2 == 0) {
LAB_00b0d507:
    bVar1 = false;
  }
  else {
    FUN_008a40f0();
    piVar3 = (int *)FUN_00587490(auStack_10);
    uVar4 = 1;
    if (*piVar3 == 0) goto LAB_00b0d507;
    bVar1 = true;
  }
  if (((uVar4 & 1) != 0) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar2 = piStack_c[1] + -1;
    piStack_c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar3 = piStack_c + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_c + 4))();
      }
    }
  }
  if (bVar1) {
    piVar3 = *(int **)(param_1 + 0x28);
    if (0xf < (uint)piVar3[5]) {
      piVar3 = (int *)*piVar3;
    }
    FUN_0086f2f0(2,"%s has TriggerTouchEvents set to False. TouchInterest will be removed.",piVar3);
    FUN_00b0a7c0();
  }
LAB_00b0d588:
  FUN_008a4940(&DAT_0212a4a0);
  return;
}



/* FUNCTION 23249 ; VA 0x00b0d5a0 ; FUN_00b0d5a0 */

void __thiscall FUN_00b0d5a0(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0xcb) != param_2) {
    *(char *)(param_1 + 0xcb) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}


