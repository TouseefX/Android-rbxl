/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 25250 ; VA 0x00b8c430 ; FUN_00b8c430 */

void FUN_00b8c430(undefined *param_1)

{
  int iVar1;
  
  iVar1 = FUN_00b92770();
  *(undefined2 *)(iVar1 + 0xc) = 0;
  *(undefined *)(iVar1 + 0xe) = *param_1;
  return;
}



/* FUNCTION 25251 ; VA 0x00b8c450 ; FUN_00b8c450 */

int FUN_00b8c450(undefined4 param_1,int *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  
  iVar3 = FUN_00575b80();
  *(undefined2 *)(iVar3 + 0xc) = 0;
  puVar2 = (undefined4 *)*param_2;
  *(undefined4 *)(iVar3 + 0x10) = 0;
  *(undefined4 *)(iVar3 + 0x14) = 0;
  if (puVar2[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar3 + 0x10) = *puVar2;
  *(undefined4 *)(iVar3 + 0x14) = puVar2[1];
  *(undefined4 *)(iVar3 + 0x18) = 0;
  return iVar3;
}



/* FUNCTION 25252 ; VA 0x00b8c4a0 ; FUN_00b8c4a0 */

int FUN_00b8c4a0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f98a0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00575b80();
  *(undefined2 *)(iVar1 + 0xc) = 0;
  uStack_8 = 0;
  *(undefined4 *)(iVar1 + 0x10) = *(undefined4 *)*param_2;
  *(undefined4 *)(iVar1 + 0x14) = 0;
  *(undefined4 *)(iVar1 + 0x18) = 0;
  uVar2 = FUN_00575b50(0,0);
  *(undefined4 *)(iVar1 + 0x14) = uVar2;
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 25253 ; VA 0x00b8c51a ; Catch_All@00b8c51a */

void Catch_All_00b8c51a(void)

{
  int unaff_EBP;
  
  FUN_00b928c0(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25254 ; VA 0x00b8c530 ; FUN_00b8c530 */

void __thiscall
FUN_00b8c530(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x9249247 < (uint)param_1[1]) {
    FUN_00b92790(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00b8c5e2:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00b8c5e2;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 25255 ; VA 0x00b8c690 ; FUN_00b8c690 */

void __thiscall
FUN_00b8c690(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x9249247 < (uint)param_1[1]) {
    FUN_00b927c0(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00b8c742:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00b8c742;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 25256 ; VA 0x00b8c7f0 ; FUN_00b8c7f0 */

void __thiscall
FUN_00b8c7f0(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  
  if (0xffffffd < (uint)param_1[1]) {
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  piVar3 = (int *)FUN_00b8c430(param_5);
  param_1[1] = param_1[1] + 1;
  piVar3[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = piVar3;
    *(int **)*param_1 = piVar3;
    iVar4 = *param_1;
  }
  else {
    if (param_3 != '\0') {
      *param_4 = piVar3;
      if (param_4 == *(undefined4 **)*param_1) {
        *(int **)*param_1 = piVar3;
      }
      goto LAB_00b8c848;
    }
    param_4[2] = piVar3;
    iVar4 = *param_1;
    if (param_4 != *(undefined4 **)(iVar4 + 8)) goto LAB_00b8c848;
  }
  *(int **)(iVar4 + 8) = piVar3;
LAB_00b8c848:
  cVar1 = *(char *)(piVar3[1] + 0xc);
  piVar6 = piVar3;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = piVar3;
      return;
    }
    piVar2 = (int *)piVar6[1];
    piVar5 = *(int **)piVar2[1];
    if (piVar2 == piVar5) {
      piVar5 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar5 + 3) == '\0') {
LAB_00b8c8a1:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar5 + 3) = 1;
        *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
        piVar6 = *(int **)(piVar6[1] + 4);
      }
      else {
        if (piVar6 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar6 = piVar2;
        }
        *(undefined *)(piVar6[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar6[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar5 + 3) == '\0') goto LAB_00b8c8a1;
      if (piVar6 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar6 = piVar2;
      }
      *(undefined *)(piVar6[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
      iVar4 = *(int *)(piVar6[1] + 4);
      piVar2 = *(int **)(iVar4 + 8);
      *(int *)(iVar4 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar4;
      }
      piVar2[1] = *(int *)(iVar4 + 4);
      if (iVar4 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar5 = *(int **)(iVar4 + 4);
        if (iVar4 == *piVar5) {
          *piVar5 = (int)piVar2;
        }
        else {
          piVar5[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar4;
      *(int **)(iVar4 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar6[1] + 0xc);
  } while( true );
}



/* FUNCTION 25257 ; VA 0x00b8c950 ; FUN_00b8c950 */

undefined4 * __thiscall
FUN_00b8c950(int *param_1,undefined4 *param_2,int *param_3,int param_4,undefined4 param_5)

{
  undefined *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  bool bVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f98b0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_00b8c530(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar2 = (int *)*param_1;
  if (param_3 == (int *)*piVar2) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*(uint *)(param_4 + 4) < (uint)param_3[5]) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_00b8c530(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar2) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*(uint *)(piVar2[2] + 0x14) < *(uint *)(param_4 + 4)) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_00b8c530(param_2,0,piVar2[2],param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    bVar4 = (uint)param_3[5] < *(uint *)(param_4 + 4);
    ExceptionList = &pvStack_10;
    puVar1 = &stack0xffffffd4;
    if (*(uint *)(param_4 + 4) < (uint)param_3[5]) {
      piStack_18 = param_3;
      ExceptionList = &pvStack_10;
      piVar2 = (int *)FUN_0056f560();
      if (*(uint *)(*piVar2 + 0x14) < *(uint *)(param_4 + 4)) {
        if (*(char *)(piStack_18[2] + 0xd) != '\0') {
          FUN_00b8c530(param_2,0,piStack_18,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00b8c530(param_2,1,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
      bVar4 = (uint)param_3[5] < *(uint *)(param_4 + 4);
      puVar1 = puStack_14;
    }
    puStack_14 = puVar1;
    if (bVar4) {
      piStack_18 = param_3;
      piVar2 = (int *)FUN_00551320();
      if ((*piVar2 == *param_1) || (*(uint *)(param_4 + 4) < (uint)piStack_18[5])) {
        if (*(char *)(param_3[2] + 0xd) != '\0') {
          FUN_00b8c530(param_2,0,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00b8c530(param_2,1,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = (undefined4 *)FUN_00b8cd70(auStack_20,0,param_4,param_5);
  *param_2 = *puVar3;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25258 ; VA 0x00b8cb42 ; Catch_All@00b8cb42 */

void Catch_All_00b8cb42(void)

{
  int unaff_EBP;
  
  FUN_00b92790(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25259 ; VA 0x00b8cb60 ; FUN_00b8cb60 */

undefined4 * __thiscall
FUN_00b8cb60(int *param_1,undefined4 *param_2,int *param_3,int *param_4,undefined4 param_5)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined *puVar4;
  int *piVar5;
  undefined4 *puVar6;
  bool bVar7;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f98c0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_00b8c690(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar5 = (int *)*param_1;
  if (param_3 == (int *)*piVar5) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*param_4 < param_3[4]) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_00b8c690(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar5) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*(int *)(piVar5[2] + 0x10) < *param_4) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_00b8c690(param_2,0,piVar5[2],param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    iVar1 = *param_4;
    iVar2 = param_3[4];
    bVar7 = SBORROW4(iVar2,iVar1);
    iVar3 = iVar2 - iVar1;
    ExceptionList = &pvStack_10;
    puVar4 = &stack0xffffffd4;
    if (iVar1 < iVar2) {
      piStack_18 = param_3;
      ExceptionList = &pvStack_10;
      piVar5 = (int *)FUN_0056f560();
      iVar3 = *param_4;
      if (*(int *)(*piVar5 + 0x10) < iVar3) {
        if (*(char *)(piStack_18[2] + 0xd) != '\0') {
          FUN_00b8c690(param_2,0,piStack_18,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00b8c690(param_2,1,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
      bVar7 = SBORROW4(param_3[4],iVar3);
      iVar3 = param_3[4] - iVar3;
      puVar4 = puStack_14;
    }
    puStack_14 = puVar4;
    if (bVar7 != iVar3 < 0) {
      piStack_18 = param_3;
      piVar5 = (int *)FUN_00551320();
      if ((*piVar5 == *param_1) || (*param_4 < piStack_18[4])) {
        if (*(char *)(param_3[2] + 0xd) != '\0') {
          FUN_00b8c690(param_2,0,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00b8c690(param_2,1,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = (undefined4 *)FUN_00b8cea0(auStack_20,0,param_4,param_5);
  *param_2 = *puVar6;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25260 ; VA 0x00b8cd4d ; Catch_All@00b8cd4d */

void Catch_All_00b8cd4d(void)

{
  int unaff_EBP;
  
  FUN_00b927c0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25261 ; VA 0x00b8cd70 ; FUN_00b8cd70 */

void __thiscall
FUN_00b8cd70(undefined4 *param_1,undefined4 *param_2,char param_3,int param_4,int param_5)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  int *piVar5;
  bool bVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f98d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piVar3 = (int *)*param_1;
  bVar6 = true;
  piVar5 = piVar3;
  if (*(char *)(piVar3[1] + 0xd) == '\0') {
    piVar3 = (int *)piVar3[1];
    do {
      piVar5 = piVar3;
      if (param_3 == '\0') {
        bVar6 = *(uint *)(param_4 + 4) < (uint)piVar5[5];
      }
      else {
        bVar6 = *(uint *)(param_4 + 4) <= (uint)piVar5[5];
      }
      if (bVar6 == false) {
        piVar3 = (int *)piVar5[2];
      }
      else {
        piVar3 = (int *)*piVar5;
      }
    } while (*(char *)((int)piVar3 + 0xd) == '\0');
    piVar3 = (int *)*param_1;
  }
  ExceptionList = &pvStack_10;
  _param_3 = piVar5;
  if (bVar6) {
    if (piVar5 == (int *)*piVar3) {
      bVar6 = true;
      ExceptionList = &pvStack_10;
      goto LAB_00b8cdf8;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  iVar2 = param_5;
  piVar3 = _param_3;
  if (*(uint *)(param_4 + 4) <= (uint)_param_3[5]) {
    piVar5 = *(int **)(param_5 + 0x14);
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[2] + -1;
      piVar5[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
    FUN_01674ea0(iVar2,0x1c);
    *param_2 = piVar3;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00b8cdf8:
  puVar4 = (undefined4 *)FUN_00b8c530(&param_3,bVar6,piVar5,param_4,param_5);
  *param_2 = *puVar4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25262 ; VA 0x00b8ce81 ; Catch_All@00b8ce81 */

void Catch_All_00b8ce81(void)

{
  int unaff_EBP;
  
  FUN_00b92790(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25263 ; VA 0x00b8cea0 ; FUN_00b8cea0 */

void __thiscall
FUN_00b8cea0(undefined4 *param_1,undefined4 *param_2,char param_3,int *param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int *piVar2;
  undefined4 *puVar3;
  int *piVar4;
  bool bVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f98e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piVar2 = (int *)*param_1;
  bVar5 = true;
  piVar4 = piVar2;
  if (*(char *)(piVar2[1] + 0xd) == '\0') {
    piVar2 = (int *)piVar2[1];
    do {
      piVar4 = piVar2;
      if (param_3 == '\0') {
        bVar5 = *param_4 < piVar4[4];
      }
      else {
        bVar5 = *param_4 <= piVar4[4];
      }
      if (bVar5 == false) {
        piVar2 = (int *)piVar4[2];
      }
      else {
        piVar2 = (int *)*piVar4;
      }
    } while (*(char *)((int)piVar2 + 0xd) == '\0');
    piVar2 = (int *)*param_1;
  }
  ExceptionList = &pvStack_10;
  _param_3 = piVar4;
  if (bVar5) {
    if (piVar4 == (int *)*piVar2) {
      bVar5 = true;
      ExceptionList = &pvStack_10;
      goto LAB_00b8cf27;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  uVar1 = param_5;
  piVar2 = _param_3;
  if (*param_4 <= _param_3[4]) {
    FUN_0056c7e0();
    FUN_01674ea0(uVar1,0x1c);
    *param_2 = piVar2;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00b8cf27:
  puVar3 = (undefined4 *)FUN_00b8c690(&param_3,bVar5,piVar4,param_4,param_5);
  *param_2 = *puVar3;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25264 ; VA 0x00b8cfa1 ; Catch_All@00b8cfa1 */

void Catch_All_00b8cfa1(void)

{
  int unaff_EBP;
  
  FUN_00b927c0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25265 ; VA 0x00b8cfc0 ; FUN_00b8cfc0 */

undefined4 * __thiscall
FUN_00b8cfc0(undefined4 *param_1,undefined4 *param_2,char param_3,char *param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *puVar4;
  int *piVar5;
  bool bVar6;
  int *piVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f98f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  bVar6 = true;
  piVar2 = (int *)*param_1;
  piVar7 = piVar2;
  if (*(char *)(piVar2[1] + 0xd) == '\0') {
    piVar5 = (int *)piVar2[1];
    do {
      piVar7 = piVar5;
      if (param_3 == '\0') {
        bVar6 = *param_4 < *(char *)((int)piVar7 + 0xe);
      }
      else {
        bVar6 = *param_4 <= *(char *)((int)piVar7 + 0xe);
      }
      if (bVar6 == false) {
        piVar5 = (int *)piVar7[2];
      }
      else {
        piVar5 = (int *)*piVar7;
      }
    } while (*(char *)((int)piVar5 + 0xd) == '\0');
  }
  piVar5 = piVar7;
  if (bVar6 != false) {
    if (piVar7 == (int *)*piVar2) {
      bVar6 = true;
      goto LAB_00b8d049;
    }
    if (*(char *)((int)piVar7 + 0xd) == '\0') {
      piVar5 = (int *)*piVar7;
      if (*(char *)((int)piVar5 + 0xd) == '\0') {
        cVar1 = *(char *)(piVar5[2] + 0xd);
        piVar2 = (int *)piVar5[2];
        while (cVar1 == '\0') {
          cVar1 = *(char *)(piVar2[2] + 0xd);
          piVar5 = piVar2;
          piVar2 = (int *)piVar2[2];
        }
      }
      else {
        cVar1 = *(char *)(piVar7[1] + 0xd);
        piVar2 = (int *)piVar7[1];
        piVar5 = piVar7;
        while ((piVar3 = piVar2, cVar1 == '\0' && (piVar5 == (int *)*piVar3))) {
          cVar1 = *(char *)(piVar3[1] + 0xd);
          piVar2 = (int *)piVar3[1];
          piVar5 = piVar3;
        }
        if (*(char *)((int)piVar5 + 0xd) == '\0') {
          piVar5 = piVar3;
        }
      }
    }
    else {
      piVar5 = (int *)piVar7[2];
    }
  }
  if (*param_4 <= *(char *)((int)piVar5 + 0xe)) {
    *param_2 = piVar5;
    *(undefined *)(param_2 + 1) = 0;
    return param_2;
  }
LAB_00b8d049:
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_00b8c7f0(&param_3,bVar6,piVar7,param_4,param_5);
  *param_2 = *puVar4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25266 ; VA 0x00b8d100 ; Catch_All@00b8d100 */

void Catch_All_00b8d100(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25267 ; VA 0x00b8d110 ; FUN_00b8d110 */

int __thiscall FUN_00b8d110(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9900;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ImageLabel*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25268 ; VA 0x00b8d1e2 ; Catch_All@00b8d1e2 */

void Catch_All_00b8d1e2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 25269 ; VA 0x00b8d200 ; FUN_00b8d200 */

undefined FUN_00b8d200(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8,
                      undefined4 param_9,undefined4 *param_10)

{
  char cVar1;
  undefined4 *puVar2;
  undefined uVar3;
  undefined4 *puStack_64;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined8 uStack_4c;
  undefined4 *apuStack_3c [2];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9937;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  apuStack_3c[0] = (undefined4 *)0x0;
  puStack_14 = param_1;
  ExceptionList = &pvStack_10;
  if (param_1 != (undefined4 *)0x0) {
    apuStack_3c[0] = param_1;
    if (((uint)param_1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)((uint)param_1 & 0xfffffffe))(&param_3,&uStack_34,0);
    }
    else {
      uStack_34 = param_3;
      uStack_30 = param_4;
      uStack_2c = param_5;
      uStack_28 = param_6;
      uStack_24 = param_7;
      ExceptionList = &pvStack_10;
    }
  }
  puStack_14 = param_1;
  uStack_8._0_1_ = 1;
  cVar1 = FUN_00585a40(apuStack_3c);
  if (cVar1 == '\0') {
    puStack_64 = (undefined4 *)0x0;
    if (apuStack_3c[0] != (undefined4 *)0x0) {
      puStack_64 = apuStack_3c[0];
      if (((uint)apuStack_3c[0] & 1) == 0) {
        (**(code **)((uint)apuStack_3c[0] & 0xfffffffe))(&uStack_34,&uStack_5c,0);
      }
      else {
        uStack_5c = uStack_34;
        uStack_58 = uStack_30;
        uStack_54 = uStack_2c;
        uStack_50 = uStack_28;
        uStack_4c = uStack_24;
      }
    }
    uStack_8._0_1_ = 2;
    puVar2 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar2;
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = 0;
      if (puStack_64 != (undefined4 *)0x0) {
        *puVar2 = puStack_64;
        if (((uint)puStack_64 & 1) == 0) {
          (**(code **)((uint)puStack_64 & 0xfffffffe))(&uStack_5c,puVar2 + 2,0);
        }
        else {
          puVar2[2] = uStack_5c;
          puVar2[3] = uStack_58;
          puVar2[4] = uStack_54;
          puVar2[5] = uStack_50;
          *(undefined8 *)(puVar2 + 6) = uStack_4c;
        }
      }
    }
    *param_10 = puVar2;
    uStack_8._0_1_ = 4;
    if (((puStack_64 != (undefined4 *)0x0) && (((uint)puStack_64 & 1) == 0)) &&
       (*(code **)((uint)puStack_64 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)((uint)puStack_64 & 0xfffffffe))(&uStack_5c,&uStack_5c,2);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (apuStack_3c[0] != (undefined4 *)0x0) {
      if ((((uint)apuStack_3c[0] & 1) == 0) &&
         (*(code **)((uint)apuStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)((uint)apuStack_3c[0] & 0xfffffffe))(&uStack_34,&uStack_34,2);
      }
      apuStack_3c[0] = (undefined4 *)0x0;
    }
    uVar3 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (apuStack_3c[0] != (undefined4 *)0x0) {
      if ((((uint)apuStack_3c[0] & 1) == 0) &&
         (*(code **)((uint)apuStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
        (**(code **)((uint)apuStack_3c[0] & 0xfffffffe))(&uStack_34,&uStack_34,2);
        puStack_14 = param_1;
      }
      apuStack_3c[0] = (undefined4 *)0x0;
    }
    uVar3 = 0;
    param_1 = puStack_14;
  }
  uStack_8 = 7;
  if (((param_1 != (undefined4 *)0x0) && (((uint)param_1 & 1) == 0)) &&
     (*(code **)((uint)param_1 & 0xfffffffe) != (code *)0x0)) {
    param_10._3_1_ = uVar3;
    (**(code **)((uint)param_1 & 0xfffffffe))(&param_3,&param_3,2);
    ExceptionList = pvStack_10;
    return param_10._3_1_;
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 25270 ; VA 0x00b8d410 ; FUN_00b8d410 */

undefined FUN_00b8d410(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined8 param_9,int *param_10)

{
  undefined4 uVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f996f;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00585a40(&param_1);
  uVar1 = param_1;
  if (cVar2 == '\0') {
    uStack_34 = 0;
    if (param_3 != 0) {
      uStack_34 = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_2c,0);
      }
      else {
        uStack_2c = param_5;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
      }
    }
    uStack_8._0_1_ = 1;
    puVar4 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 2;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[2] = 0;
      if (uStack_34 != 0) {
        puVar4[2] = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,puVar4 + 4,0);
        }
        else {
          puVar4[4] = uStack_2c;
          puVar4[5] = uStack_28;
          puVar4[6] = uStack_24;
          puVar4[7] = uStack_20;
          *(undefined8 *)(puVar4 + 8) = uStack_1c;
        }
      }
    }
    *param_10 = (int)puVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
       (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  uStack_8 = 4;
  param_10._3_1_ = uVar3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_10._3_1_;
}



/* FUNCTION 25271 ; VA 0x00b8d570 ; FUN_00b8d570 */

uint FUN_00b8d570(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  char cVar4;
  undefined4 *puVar5;
  undefined in_stack_00000030;
  undefined3 uStack00000034;
  undefined4 uStack_74;
  int *piStack_70;
  undefined auStack_6c [32];
  undefined uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  undefined auStack_3c [32];
  undefined uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017f99bf;
  pvStack_10 = ExceptionList;
  uStack_48 = param_1;
  puStack_14 = &uStack_44;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_44 = param_2;
  piStack_40 = param_3;
  uStack_8 = 1;
  uStack_7 = 0;
  FUN_00d88580(&stack0x00000010);
  uStack_1c = in_stack_00000030;
  uStack_8 = 2;
  cVar4 = FUN_00585a40(&uStack_48);
  uVar3 = uStack_48;
  if (cVar4 == '\0') {
    puStack_14 = &uStack_74;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      piStack_40[2] = piStack_40[2] + 1;
      UNLOCK();
    }
    uStack_74 = uStack_44;
    piStack_70 = piStack_40;
    uStack_8 = 3;
    FUN_00d88580(auStack_3c);
    uStack_4c = uStack_1c;
    uStack_8 = 4;
    puVar5 = (undefined4 *)FUN_01674e20(0x30);
    uStack_8 = 5;
    puStack_14 = puVar5;
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      puStack_18 = puVar5 + 1;
      *puVar5 = uVar3;
      *puStack_18 = 0;
      puVar5[2] = 0;
      if (piStack_70 != (int *)0x0) {
        LOCK();
        piStack_70[2] = piStack_70[2] + 1;
        UNLOCK();
      }
      *puStack_18 = uStack_74;
      puVar5[2] = piStack_70;
      uStack_8 = 6;
      FUN_00d88580(auStack_6c);
      *(undefined *)(puVar5 + 0xb) = uStack_4c;
    }
    *_uStack00000034 = (int)puVar5;
    FUN_00d88a30();
    if (piStack_70 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_70[2] + -1;
      piStack_70[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_70 + 4))();
      }
    }
    FUN_00d88a30();
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_40[2] + -1;
      piStack_40[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_40 + 4))();
      }
    }
    _uStack00000034 = (int *)CONCAT13(1,uStack00000034);
  }
  else {
    FUN_00d88a30();
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_40[2] + -1;
      piStack_40[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_40 + 4))();
      }
    }
    _uStack00000034 = (int *)((uint)_uStack00000034 & 0xffffff);
  }
  FUN_00d88a30();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return (uint)_uStack00000034 >> 0x18;
}



/* FUNCTION 25272 ; VA 0x00b8d740 ; FUN_00b8d740 */

undefined FUN_00b8d740(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 *param_7)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined uVar5;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  undefined4 uStack_8;
  
  uStack_20 = param_1;
  uStack_1c = param_2;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uStack_18 = param_3;
  piStack_14 = param_4;
  uStack_10 = param_5;
  cVar4 = FUN_00585a40(&uStack_20);
  piVar2 = piStack_14;
  if (cVar4 == '\0') {
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
    }
    uStack_8 = uStack_18;
    *param_7 = uStack_20;
    param_7[1] = uStack_1c;
    param_7[2] = 0;
    param_7[3] = 0;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
    }
    param_7[2] = uStack_18;
    param_7[3] = piStack_14;
    param_7[4] = uStack_10;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[1] + -1;
      piStack_14[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[1] + -1;
      piStack_14[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar5 = 1;
  }
  else {
    if (piStack_14 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_14[1] + -1;
      piStack_14[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_14)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar5 = 0;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar3 = param_4[1] + -1;
    param_4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar2 = param_4 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return uVar5;
}



/* FUNCTION 25273 ; VA 0x00b8d880 ; FUN_00b8d880 */

void __thiscall FUN_00b8d880(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined auStack_134 [40];
  undefined auStack_10c [24];
  undefined auStack_f4 [24];
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined auStack_d4 [40];
  undefined auStack_ac [24];
  undefined auStack_94 [24];
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 auStack_74 [10];
  undefined auStack_4c [24];
  undefined auStack_34 [24];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9a45;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined4 *)auStack_134;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  FUN_00b902d0(&stack0x0000000c);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(&stack0x00000034);
  uStack_8._0_1_ = 2;
  FUN_0054ef60(&stack0x0000004c);
  uStack_7c = param_2;
  uStack_78 = param_3;
  puStack_14 = auStack_74;
  uStack_8._0_1_ = 3;
  FUN_00b902d0(auStack_134);
  uStack_8._0_1_ = 4;
  FUN_0054ef60(auStack_10c);
  uStack_8._0_1_ = 5;
  FUN_0054ef60(auStack_f4);
  uStack_8._0_1_ = 6;
  cVar2 = FUN_00585a40(&uStack_7c);
  if (cVar2 == '\0') {
    uStack_dc = uStack_7c;
    uStack_d8 = uStack_78;
    puStack_14 = (undefined4 *)auStack_d4;
    FUN_00b902d0(auStack_74);
    uStack_8._0_1_ = 7;
    FUN_0054ef60(auStack_4c);
    uStack_8._0_1_ = 8;
    FUN_0054ef60(auStack_34);
    uStack_8._0_1_ = 9;
    puVar3 = (undefined4 *)FUN_01674e20(0x60);
    uStack_8._0_1_ = 10;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      puStack_1c = puVar3 + 2;
      *puVar3 = uStack_dc;
      puVar3[1] = uStack_d8;
      FUN_00b902d0(auStack_d4);
      uStack_8._0_1_ = 0xb;
      FUN_0054ef60(auStack_ac);
      uStack_8._0_1_ = 0xc;
      FUN_0054ef60(auStack_94);
    }
    param_1[2] = puVar3;
    FUN_00b91300();
    FUN_00b91300();
    bVar1 = true;
  }
  else {
    FUN_00b91300();
    bVar1 = false;
  }
  FUN_00b91300();
  ppuVar4 = &PTR_FUN_0195a2f0;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *puStack_18 = ppuVar4;
  FUN_00b91300();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25274 ; VA 0x00b8da80 ; FUN_00b8da80 */

uint * FUN_00b8da80(uint *param_1,uint param_2,undefined4 param_3,uint param_4,uint param_5,
                   uint param_6,uint param_7,undefined8 param_8)

{
  uint uStack_34;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined8 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9a60;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    uStack_34 = param_2;
    if ((param_2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_2c,0);
    }
    else {
      uStack_2c = param_4;
      uStack_28 = param_5;
      uStack_24 = param_6;
      uStack_20 = param_7;
      uStack_1c = param_8;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  if (uStack_34 != 0) {
    *param_1 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,param_1 + 2,0);
    }
    else {
      param_1[2] = uStack_2c;
      param_1[3] = uStack_28;
      param_1[4] = uStack_24;
      param_1[5] = uStack_20;
      *(undefined8 *)(param_1 + 6) = uStack_1c;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
     (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
  }
  uStack_8 = 3;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25275 ; VA 0x00b8db90 ; FUN_00b8db90 */

undefined4 *
FUN_00b8db90(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_c;
  int *piStack_8;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  piVar1 = param_4 + 1;
  if (param_4 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00b17bd0(param_3,param_4,param_5,param_6,param_7);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    piStack_8[1] = piStack_8[1] + 1;
    UNLOCK();
  }
  param_1[1] = uStack_c;
  param_1[2] = piStack_8;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_8[1] + -1;
    piStack_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      iVar2 = piStack_8[2] + -1;
      piStack_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 25276 ; VA 0x00b8dcb0 ; FUN_00b8dcb0 */

undefined4 * __thiscall
FUN_00b8dcb0(undefined4 param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined in_stack_00000034;
  undefined auStack_70 [28];
  undefined4 uStack_54;
  undefined4 *puStack_50;
  int *piStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9a90;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  puStack_50 = (undefined4 *)CONCAT31((int3)((uint)param_1 >> 8),in_stack_00000034);
  ExceptionList = &pvStack_10;
  _in_stack_00000034 = (undefined4 *)auStack_70;
  FUN_00d88580(&stack0x00000014);
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[2] = param_5[2] + 1;
    UNLOCK();
  }
  puVar3 = (undefined4 *)FUN_00b8ffe0(param_4,param_5);
  _in_stack_00000034 = param_2 + 1;
  *param_2 = param_3;
  *_in_stack_00000034 = 0;
  param_2[2] = 0;
  if (puVar3[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar3[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *_in_stack_00000034 = *puVar3;
  param_2[2] = puVar3[1];
  puStack_50 = puVar3 + 2;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_54 = 0xb8dd60;
  FUN_00d88580();
  *(undefined *)(param_2 + 0xb) = *(undefined *)(puVar3 + 10);
  puStack_50 = (undefined4 *)0xb8dd6e;
  FUN_00d88a30();
  if (piStack_3c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_3c[2] + -1;
    piStack_3c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_50 = (undefined4 *)0xb8dd86;
      (**(code **)(*piStack_3c + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      puStack_50 = (undefined4 *)0xb8dd9a;
      (**(code **)(*param_5 + 4))();
    }
  }
  puStack_50 = (undefined4 *)0xb8dda2;
  FUN_00d88a30();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25277 ; VA 0x00b8ddc0 ; FUN_00b8ddc0 */

undefined4 *
FUN_00b8ddc0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
    piVar1 = param_5 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  piVar1 = param_5 + 1;
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_4;
  param_1[3] = param_5;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
      return param_1;
    }
  }
  return param_1;
}



/* FUNCTION 25278 ; VA 0x00b8dee0 ; FUN_00b8dee0 */

undefined4 *
FUN_00b8dee0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            uint param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 *param_10,ulonglong param_11,uint param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16,undefined4 param_17,
            undefined8 param_18)

{
  undefined4 uVar1;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 *puStack_90;
  ulonglong uStack_8c;
  uint uStack_84;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 *puStack_70;
  undefined8 uStack_6c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9ac0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_84 = 0;
  ExceptionList = &pvStack_10;
  if (param_12 != 0) {
    uStack_84 = param_12;
    if ((param_12 & 1) == 0) {
      uStack_8c = ZEXT48(&uStack_7c);
      puStack_90 = &param_14;
      uStack_94 = 0xb8df47;
      ExceptionList = &pvStack_10;
      (**(code **)(param_12 & 0xfffffffe))();
    }
    else {
      uStack_7c = param_14;
      uStack_78 = param_15;
      uStack_74 = param_16;
      puStack_70 = (undefined4 *)param_17;
      uStack_6c = param_18;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  if (param_5 != 0) {
    if ((param_5 & 1) == 0) {
      (**(code **)(param_5 & 0xfffffffe))(&param_7,&uStack_9c,0);
    }
    else {
      uStack_9c = param_7;
      uStack_98 = param_8;
      uStack_94 = param_9;
      puStack_90 = param_10;
      uStack_8c = param_11;
    }
  }
  uStack_8._0_1_ = 1;
  uVar1 = FUN_00b8fd00(param_4);
  uStack_8._0_1_ = 3;
  *param_1 = param_2;
  param_1[1] = param_3;
  uStack_6c = CONCAT44(uVar1,0xb8dfc1);
  FUN_00b8fc30();
  uStack_6c = CONCAT44(0xb8dfc9,(undefined4)uStack_6c);
  FUN_0096ca80();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_5 != 0) && ((param_5 & 1) == 0)) && (*(code **)(param_5 & 0xfffffffe) != (code *)0x0))
  {
    puStack_70 = &param_7;
    uStack_6c = CONCAT44(2,puStack_70);
    uStack_74 = 0xb8dfea;
    (**(code **)(param_5 & 0xfffffffe))();
  }
  uStack_8 = 5;
  if (((param_12 != 0) && ((param_12 & 1) == 0)) &&
     (*(code **)(param_12 & 0xfffffffe) != (code *)0x0)) {
    puStack_70 = &param_14;
    uStack_6c = CONCAT44(2,puStack_70);
    uStack_74 = 0xb8e018;
    (**(code **)(param_12 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25279 ; VA 0x00b8e030 ; FUN_00b8e030 */

undefined4 *
FUN_00b8e030(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined8 param_12,undefined4 *param_13)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 in_stack_00000048;
  uint in_stack_0000004c;
  int in_stack_00000050;
  uint in_stack_00000064;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined8 uStack_b4;
  undefined4 uStack_9c;
  undefined4 *puStack_98;
  undefined4 uStack_8c;
  undefined4 *puStack_88;
  undefined4 *puStack_84;
  undefined *puStack_80;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9b18;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  puStack_98 = &stack0x00000050;
  uStack_9c = 0xb8e068;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8._0_1_ = 4;
  uStack_b4 = CONCAT44(&param_13,0xb8e080);
  FUN_0054ef60();
  uStack_8._0_1_ = 5;
  if (param_6 != 0) {
    if ((param_6 & 1) == 0) {
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_c4,0);
    }
    else {
      uStack_c4 = param_8;
      uStack_c0 = param_9;
      uStack_bc = param_10;
      uStack_b8 = param_11;
      uStack_b4 = param_12;
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 3;
  iVar2 = FUN_00b90110(param_4,param_5);
  uStack_8._0_1_ = 6;
  *param_1 = param_2;
  param_1[1] = param_3;
  puStack_84 = (undefined4 *)0xb8e11e;
  puStack_80 = (undefined *)iVar2;
  FUN_00b902d0();
  puStack_80 = (undefined *)(iVar2 + 0x28);
  uStack_8._0_1_ = 7;
  puStack_84 = (undefined4 *)0xb8e12e;
  FUN_0054ef60();
  puStack_80 = (undefined *)(iVar2 + 0x40);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  puStack_84 = (undefined4 *)0xb8e13e;
  FUN_0054ef60();
  puStack_80 = (undefined *)0xb8e146;
  FUN_00b91300();
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_80 = (undefined *)0xb8e15f;
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_80 = (undefined *)0xb8e16e;
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    puStack_88 = &param_8;
    puStack_80 = (undefined *)0x2;
    uStack_8c = 0xb8e18f;
    puStack_84 = puStack_88;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  if (0xf < in_stack_0000004c) {
    puStack_80 = (undefined *)(in_stack_0000004c + 1);
    puVar3 = param_13;
    if (0xfff < puStack_80) {
      puVar3 = (undefined4 *)param_13[-1];
      puStack_80 = (undefined *)(in_stack_0000004c + 0x24);
      if (0x1f < (uint)((int)param_13 + (-4 - (int)puVar3))) {
                    /* WARNING: Subroutine does not return */
        puStack_80 = (undefined *)0xb8e223;
        FUN_017167a3();
      }
    }
    puStack_88 = (undefined4 *)0xb8e1c6;
    puStack_84 = puVar3;
    FUN_01674ea0();
  }
  in_stack_00000048 = 0;
  in_stack_0000004c = 0xf;
  param_13 = (undefined4 *)((uint)param_13 & 0xffffff00);
  if (0xf < in_stack_00000064) {
    puStack_80 = (undefined *)(in_stack_00000064 + 1);
    iVar2 = in_stack_00000050;
    if (0xfff < puStack_80) {
      iVar2 = *(int *)(in_stack_00000050 + -4);
      puStack_80 = (undefined *)(in_stack_00000064 + 0x24);
      if (0x1f < (in_stack_00000050 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_80 = &UNK_00b8e228;
        FUN_017167a3();
      }
    }
    puStack_88 = (undefined4 *)0xb8e208;
    puStack_84 = (undefined4 *)iVar2;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25280 ; VA 0x00b8e230 ; FUN_00b8e230 */

undefined4 *
FUN_00b8e230(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 param_11,undefined8 param_12,undefined4 param_13)

{
  int iVar1;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined4 uStack_48;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9b48;
  pvStack_10 = ExceptionList;
  uStack_48 = param_13;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_6 != 0) {
    if ((param_6 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_6 & 0xfffffffe))(&param_8,&uStack_60,0);
    }
    else {
      uStack_60 = param_8;
      uStack_5c = param_9;
      uStack_58 = param_10;
      uStack_54 = param_11;
      uStack_50 = param_12;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_48 = FUN_00b8fe30(param_4,param_5);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  *param_1 = param_2;
  param_1[1] = param_3;
  uStack_50 = CONCAT44(0xb8e2e6,(undefined4)uStack_50);
  FUN_00b902d0();
  uStack_48 = 0xb8e2ee;
  FUN_00a7c840();
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar1 = param_5[1] + -1;
    param_5[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_48 = 0xb8e305;
      (**(code **)*param_5)();
      LOCK();
      iVar1 = param_5[2] + -1;
      param_5[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_48 = 0xb8e316;
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8 = 3;
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    uStack_48 = 2;
    uStack_50 = CONCAT44(&param_8,&param_8);
    uStack_54 = 0xb8e33a;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25281 ; VA 0x00b8e350 ; FUN_00b8e350 */

undefined4 *
FUN_00b8e350(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,uint param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10,undefined4 *param_11,ulonglong param_12)

{
  int *piVar1;
  int iVar2;
  uint *puVar3;
  uint auStack_8c [2];
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 *puStack_78;
  undefined8 uStack_74;
  undefined auStack_64 [40];
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  ulonglong uStack_24;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9b88;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_3c = 0;
  ExceptionList = &pvStack_10;
  if (param_6 != 0) {
    uStack_3c = param_6;
    if ((param_6 & 1) == 0) {
      uStack_74 = ZEXT48(&uStack_34);
      puStack_78 = &param_8;
      uStack_7c = 0xb8e3ae;
      ExceptionList = &pvStack_10;
      (**(code **)(param_6 & 0xfffffffe))();
    }
    else {
      uStack_34 = param_8;
      uStack_30 = param_9;
      uStack_2c = param_10;
      puStack_28 = param_11;
      uStack_24 = param_12;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_1c = param_4;
  piStack_18 = param_5;
  puStack_14 = (undefined *)auStack_8c;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  auStack_8c[0] = 0;
  puVar3 = auStack_8c;
  if (uStack_3c != 0) {
    auStack_8c[0] = uStack_3c;
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_84,0);
      puVar3 = (uint *)puStack_14;
    }
    else {
      uStack_84 = uStack_34;
      uStack_80 = uStack_30;
      uStack_7c = uStack_2c;
      puStack_78 = puStack_28;
      uStack_74 = uStack_24;
      puVar3 = auStack_8c;
    }
  }
  puStack_14 = (undefined *)puVar3;
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  FUN_00b90380(param_4,param_5);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_74 = CONCAT44(0xb8e44d,(undefined4)uStack_74);
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        uStack_74 = CONCAT44(0xb8e45d,(undefined4)uStack_74);
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 4;
  if (uStack_3c != 0) {
    if (((uStack_3c & 1) == 0) && (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_34;
      uStack_74 = CONCAT44(2,puStack_78);
      uStack_7c = 0xb8e482;
      (**(code **)(uStack_3c & 0xfffffffe))();
    }
    uStack_3c = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  *param_1 = param_2;
  param_1[1] = param_3;
  uStack_74 = CONCAT44(auStack_64,0xb8e4aa);
  FUN_00b902d0();
  uStack_74 = CONCAT44(0xb8e4b2,(undefined4)uStack_74);
  FUN_00a7c840();
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_74 = CONCAT44(0xb8e4c9,(undefined4)uStack_74);
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_74 = CONCAT44(0xb8e4db,(undefined4)uStack_74);
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  uStack_8 = 6;
  if (((param_6 != 0) && ((param_6 & 1) == 0)) && (*(code **)(param_6 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_8;
    uStack_74 = CONCAT44(2,puStack_78);
    uStack_7c = 0xb8e4ff;
    (**(code **)(param_6 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25282 ; VA 0x00b8e520 ; FUN_00b8e520 */

undefined4 *
FUN_00b8e520(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int *param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  
  if (param_5 != (int *)0x0) {
    LOCK();
    param_5[1] = param_5[1] + 1;
    UNLOCK();
    piVar1 = param_5 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  piVar1 = param_5 + 1;
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = 0;
  param_1[3] = 0;
  if (param_5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[2] = param_4;
  param_1[3] = param_5;
  param_1[4] = param_6;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
      return param_1;
    }
  }
  return param_1;
}



/* FUNCTION 25283 ; VA 0x00b8e650 ; FUN_00b8e650 */

undefined4 FUN_00b8e650(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_008e16d0();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 25284 ; VA 0x00b8e6b0 ; FUN_00b8e6b0 */

int FUN_00b8e6b0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c1868;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    iVar5 = *(int *)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    if ((iVar5 != 0) && (param_1 = iVar5, ExceptionList = &pvStack_10, *(int *)(iVar5 + 0x34) != 0))
    {
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar5 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      piVar3 = (int *)FUN_00636a50();
      iVar5 = *piVar3;
      if (iVar5 == 0) {
        FUN_008e1d00(&iStack_18);
        iStack_8 = iVar5;
        FUN_008a5700(param_1);
        FUN_005789c0(&DAT_01ead658,&LAB_00634090);
        uVar4 = FUN_006350d0();
        piVar3 = (int *)FUN_008aa140(uVar4);
        if (piStack_14 != (int *)0x0) {
          LOCK();
          piStack_14[1] = piStack_14[1] + 1;
          UNLOCK();
        }
        *piVar3 = iStack_18;
        piVar1 = (int *)piVar3[1];
        piVar3[1] = (int)piStack_14;
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar5 = piVar1[1] + -1;
          piVar1[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar5 = piVar1[2] + -1;
            piVar1[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        iVar5 = iStack_18;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          iVar2 = piStack_14[1] + -1;
          piStack_14[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_14)();
            LOCK();
            piVar3 = piStack_14 + 2;
            iVar2 = *piVar3;
            *piVar3 = *piVar3 + -1;
            UNLOCK();
            if (iVar2 == 1) {
              (**(code **)(*piStack_14 + 4))();
            }
          }
        }
      }
      ExceptionList = pvStack_10;
      return iVar5;
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 25285 ; VA 0x00b8e800 ; FUN_00b8e800 */

undefined4 * FUN_00b8e800(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9bd3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00ea2500();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x3f0);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00ea2600();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00b8d110(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25286 ; VA 0x00b8e8c0 ; FUN_00b8e8c0 */

void FUN_00b8e8c0(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  piVar2 = (int *)param_2[9];
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar4 = piVar2[1] + -1;
    piVar2[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = (int *)param_2[7];
  if (piVar2 != (int *)0x0) {
    LOCK();
    piVar1 = piVar2 + 2;
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  uVar3 = param_2[5];
  if (0xf < uVar3) {
    iVar4 = *param_2;
    uVar6 = uVar3 + 1;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = uVar3 + 0x24;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  return;
}



/* FUNCTION 25287 ; VA 0x00b8e960 ; FUN_00b8e960 */

int __fastcall FUN_00b8e960(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = *(int *)(param_1 + 0xc);
  iVar2 = FUN_00c6de80();
  iVar3 = 0;
  if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
      (uint)*(ushort *)(iVar2 + 0x1da)) {
    iVar3 = param_1;
  }
  return iVar3;
}



/* FUNCTION 25288 ; VA 0x00b8e990 ; FUN_00b8e990 */

int __fastcall FUN_00b8e990(int param_1)

{
  int iVar1;
  int iVar2;
  
  do {
    param_1 = *(int *)(param_1 + 0x34);
    if (param_1 == 0) {
      return 0;
    }
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00b56cd0();
  } while ((uint)*(ushort *)(iVar2 + 0x1da) <
           (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8));
  return param_1;
}



/* FUNCTION 25289 ; VA 0x00b8e9d0 ; FUN_00b8e9d0 */

void FUN_00b8e9d0(uint param_1)

{
  code *pcVar1;
  undefined uVar2;
  undefined4 uVar3;
  undefined4 *puStack_1bc;
  undefined auStack_1b8 [200];
  undefined auStack_f0 [4];
  undefined4 *puStack_ec;
  undefined auStack_e8 [216];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9c06;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00b56440(&stack0x00000024);
  uStack_8._0_1_ = 1;
  puStack_ec = (undefined4 *)0x0;
  if (puStack_1bc != (undefined4 *)0x0) {
    (*(code *)*puStack_1bc)(auStack_1b8,auStack_e8);
  }
  puStack_ec = puStack_1bc;
  uStack_8._0_1_ = 2;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (param_1 != 0) {
    pcVar1 = *(code **)((param_1 & 0xfffffffe) + 4);
    FUN_005caf00(auStack_f0);
    (*pcVar1)(&stack0x0000000c);
    uStack_8._0_1_ = 4;
    if (puStack_ec != (undefined4 *)0x0) {
      (*(code *)puStack_ec[2])(auStack_e8);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (puStack_1bc != (undefined4 *)0x0) {
      (*(code *)puStack_1bc[2])(auStack_1b8);
    }
    uStack_8 = 6;
    if (((param_1 != 0) && ((param_1 & 1) == 0)) &&
       (*(code **)(param_1 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_1 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
    }
    ExceptionList = pvStack_10;
    return;
  }
  uStack_8._0_1_ = uVar2;
  uVar3 = FUN_0054fda0();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar3);
}



/* FUNCTION 25290 ; VA 0x00b8eb10 ; FUN_00b8eb10 */

void FUN_00b8eb10(int param_1,int param_2,code *param_3,undefined4 param_4,undefined4 *param_5)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  uint *puVar5;
  uint uStack_5c;
  undefined auStack_54 [24];
  uint auStack_3c [2];
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f9c28;
  pvStack_10 = ExceptionList;
  puVar5 = (uint *)(param_1 + param_2);
  auStack_3c[0] = 0;
  uVar2 = *puVar5;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    auStack_3c[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))(puVar5 + 2,&uStack_34,0);
    }
    else {
      uStack_34 = puVar5[2];
      uStack_30 = puVar5[3];
      uStack_2c = puVar5[4];
      uStack_28 = puVar5[5];
      uStack_24 = *(undefined8 *)(puVar5 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8 = 0;
  piVar4 = (int *)param_5[2];
  uStack_1c = *param_5;
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4[1] = piVar4[1] + 1;
    UNLOCK();
    piVar4 = (int *)param_5[2];
  }
  uStack_18 = param_5[1];
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar4[1] = piVar4[1] + 1;
    UNLOCK();
  }
  piStack_14 = piVar4;
  FUN_00b8b6a0(uStack_1c,uStack_18,piVar4,0);
  iStack_8._0_1_ = 2;
  FUN_00b9e080(puVar5);
  iStack_8._0_1_ = 3;
  if (((uStack_5c != 0) && ((uStack_5c & 1) == 0)) &&
     (*(code **)(uStack_5c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_5c & 0xfffffffe))(auStack_54,auStack_54,2);
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  if (param_3 != (code *)0x0) {
    (*param_3)(auStack_3c);
  }
  iStack_8 = 4;
  if (((auStack_3c[0] != 0) && ((auStack_3c[0] & 1) == 0)) &&
     (*(code **)(auStack_3c[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_3c[0] & 0xfffffffe))(&uStack_34,&uStack_34,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25291 ; VA 0x00b8ec70 ; thunk_FUN_00b9d9a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b9d9a0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb516;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef25fc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef25fc);
    if (DAT_01ef25fc == -1) {
      uStack_8 = 0;
      FUN_009ca470("CenterDialogType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef2598 = RBX::Reflection::EnumDesc<enum_RBX::GuiService::CenterDialogType>::vftable;
      FUN_009caf20(&DAT_01d67960,4);
      FUN_016f3654(&LAB_01891200);
      FUN_016f37bf(&DAT_01ef25fc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef2598;
}



/* FUNCTION 25292 ; VA 0x00b8ec80 ; thunk_FUN_00b9dae0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b9dae0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb536;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef2664) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef2664);
    if (DAT_01ef2664 == -1) {
      uStack_8 = 0;
      FUN_009ca470("SpecialKey");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef2600 = RBX::Reflection::EnumDesc<enum_RBX::GuiService::SpecialKey>::vftable;
      FUN_009caf20(&DAT_01d67930,6);
      FUN_016f3654(&LAB_01891240);
      FUN_016f37bf(&DAT_01ef2664);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef2600;
}



/* FUNCTION 25293 ; VA 0x00b8ec90 ; thunk_FUN_00b9db90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * thunk_FUN_00b9db90(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb556;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef2594) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ef2594);
    if (DAT_01ef2594 == -1) {
      uStack_8 = 0;
      FUN_009ca470("UiMessageType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ef2530 = RBX::Reflection::EnumDesc<enum_RBX::GuiService::UiMessageType>::vftable;
      FUN_009caf20(&DAT_01d67980,2);
      FUN_016f3654(&LAB_01891260);
      FUN_016f37bf(&DAT_01ef2594);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ef2530;
}



/* FUNCTION 25294 ; VA 0x00b8eca0 ; FUN_00b8eca0 */

/* WARNING: Removing unreachable block (ram,0x00b8ed93) */
/* WARNING: Removing unreachable block (ram,0x00b8eda1) */
/* WARNING: Removing unreachable block (ram,0x00b8ede1) */
/* WARNING: Removing unreachable block (ram,0x00b8edb1) */

void FUN_00b8eca0(undefined4 param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f9c58;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)(*param_2 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0088cb40();
  if (iVar3 != iVar1) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  FUN_0054ef60();
  uStack_8 = 0;
  param_2 = (int *)*param_2;
  iVar3 = *param_2;
  iVar1 = FUN_0088cdc0();
  if (iVar3 != iVar1) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  piVar2 = param_2 + 2;
  if (param_2[1] == 0) {
    piVar2 = (int *)0x0;
  }
  iVar3 = piVar2[1];
  if (iVar3 != 0) {
    LOCK();
    *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
    UNLOCK();
    iVar3 = piVar2[1];
  }
  uStack_8 = 2;
  FUN_00b1ba80(*piVar2,iVar3,uStack_30,uStack_2c,uStack_28,uStack_24,CONCAT44(uStack_1c,uStack_20));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25295 ; VA 0x00b8edf0 ; FUN_00b8edf0 */

undefined4 FUN_00b8edf0(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_00b8ef6d:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_00b8ef6d;
  }
  iVar2 = FUN_00b9d9a0();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_00b8ef18;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_00b9d9a0();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_00b8bd10(&param_3);
      iVar4 = FUN_00b9d9a0();
      iStack_ec = iVar4;
      iVar5 = FUN_00b9d9a0();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_00b8ef18:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_00b9d9a0();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 25296 ; VA 0x00b8eff0 ; FUN_00b8eff0 */

undefined4 FUN_00b8eff0(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_00b8f16d:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_00b8f16d;
  }
  iVar2 = FUN_00b9dae0();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_00b8f118;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_00b9dae0();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_00b8bd60(&param_3);
      iVar4 = FUN_00b9dae0();
      iStack_ec = iVar4;
      iVar5 = FUN_00b9dae0();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_00b8f118:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_00b9dae0();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 25297 ; VA 0x00b8f1f0 ; FUN_00b8f1f0 */

undefined4 FUN_00b8f1f0(undefined4 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar4 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_4 < param_3) {
LAB_00b8f36d:
    uStack_8 = 0xffffffff;
    if ((undefined4 *)*param_5 == (undefined4 *)0x0) {
      FUN_016756b0(auStack_1c,"Argument %d missing or nil",iVar4);
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_1c,&DAT_01c17198);
    }
    ExceptionList = pvStack_10;
    return *(undefined4 *)*param_5;
  }
  param_2 = param_2 + param_3;
  ExceptionList = &pvStack_10;
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar1 = FUN_009d1bf0(param_1,param_2,&iStack_ec,1);
  iVar5 = iStack_ec;
  if (cVar1 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    goto LAB_00b8f36d;
  }
  iVar2 = FUN_00b9db90();
  iVar4 = iStack_ec;
  if (iVar5 == iVar2) {
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    if (puVar3 != (undefined4 *)0x0) goto LAB_00b8f318;
  }
  iVar2 = FUN_0088cb40();
  iVar5 = iStack_ec;
  if (iVar4 == iVar2) {
    iVar4 = FUN_0088cb40();
    if (iVar5 != iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar3 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar3 = (undefined4 *)0x0;
    }
    FUN_00b9db90();
    if (0xf < (uint)puVar3[5]) {
      puVar3 = (undefined4 *)*puVar3;
    }
    cVar1 = FUN_009cb180(puVar3,&param_3);
    if (cVar1 != '\0') {
      FUN_00b8bdb0(&param_3);
      iVar4 = FUN_00b9db90();
      iStack_ec = iVar4;
      iVar5 = FUN_00b9db90();
      if (iVar4 != iVar5) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar3 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar3 = (undefined4 *)0x0;
      }
LAB_00b8f318:
      uVar6 = *puVar3;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return uVar6;
    }
  }
  thunk_FUN_00b9db90();
  uVar6 = FUN_005543f0();
  uVar7 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar7,uVar6);
}



/* FUNCTION 25298 ; VA 0x00b8f3f0 ; FUN_00b8f3f0 */

undefined4 * __thiscall
FUN_00b8f3f0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 *param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f9cbb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_00b8c330();
  FUN_009cb790(uVar1,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::GuiService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar1 = FUN_00888530();
  param_1[9] = uVar1;
  if (param_1[0x10] == 0) {
    uStack_e8 = FUN_00888530();
    iStack_e4 = 0;
    param_6 = &uStack_e8;
    uStack_8 = 3;
    uVar3 = 2;
  }
  else {
    param_6 = (undefined4 *)FUN_005c13e0(param_1[0x10]);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar3 = 1;
  }
  uStack_14 = uVar3;
  uVar1 = FUN_0088cb40();
  uVar2 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar2,uVar1,param_6);
  if ((uVar3 & 2) != 0) {
    uVar3 = uVar3 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar3;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  if ((uVar3 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25299 ; VA 0x00b8f550 ; FUN_00b8f550 */

undefined4 * __thiscall
FUN_00b8f550(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined4 auStack_e0 [50];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f9d1b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_00b8c330();
  FUN_009cb790(uVar1,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::GuiService,void___cdecl(enum_RBX::GuiService::SpecialKey),1>::
             vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar1 = FUN_00888530();
  param_1[9] = uVar1;
  puVar2 = (undefined4 *)param_1[0x10];
  if (puVar2 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar2 = &uStack_1b8;
    uStack_8 = 3;
    uVar4 = 2;
  }
  else {
    uStack_e8 = FUN_00b9dae0();
    iStack_e4 = 0;
    auStack_e0[0] = *puVar2;
    iStack_e4 = FUN_00b9dcb0();
    puVar2 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_00b9dae0();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar4;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar4 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25300 ; VA 0x00b8f6d0 ; FUN_00b8f6d0 */

undefined4 * __thiscall
FUN_00b8f6d0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f9d7b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00b8c330();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::BoundFuncDesc<class_RBX::GuiService,void___cdecl(bool),1>::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_00888530();
  param_1[9] = uVar2;
  puVar1 = (undefined *)param_1[0x10];
  if (puVar1 == (undefined *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088daf0();
    iStack_e4 = 0;
    auStack_e0[0] = *puVar1;
    iStack_e4 = FUN_005c9ef0();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25301 ; VA 0x00b8f850 ; FUN_00b8f850 */

undefined4 * __thiscall
FUN_00b8f850(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 *param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f9cbb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_00b8c330();
  FUN_009cb790(uVar1,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::GuiService,bool___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar1 = FUN_0088daf0();
  param_1[9] = uVar1;
  if (param_1[0x10] == 0) {
    uStack_e8 = FUN_00888530();
    iStack_e4 = 0;
    param_6 = &uStack_e8;
    uStack_8 = 3;
    uVar3 = 2;
  }
  else {
    param_6 = (undefined4 *)FUN_005c13e0(param_1[0x10]);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar3 = 1;
  }
  uStack_14 = uVar3;
  uVar1 = FUN_0088cb40();
  uVar2 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar2,uVar1,param_6);
  if ((uVar3 & 2) != 0) {
    uVar3 = uVar3 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar3;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  if ((uVar3 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25302 ; VA 0x00b8f9b0 ; FUN_00b8f9b0 */

undefined4 * __thiscall
FUN_00b8f9b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined8 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  uVar1 = FUN_00b8c330();
  FUN_009cb970(uVar1,param_3,param_4,param_5,param_6);
  param_1[0xd] = param_2;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::GuiService,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::GuiService::*>
             ::vftable;
  uStack_20 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  if (param_1 + 10 != &uStack_20) {
    FUN_0068a760();
    param_1[10] = 0;
    param_1[0xb] = 0;
    param_1[0xc] = 0;
  }
  uStack_8 = 1;
  FUN_0068a760();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25303 ; VA 0x00b8fa70 ; FUN_00b8fa70 */

undefined4 * __thiscall
FUN_00b8fa70(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f9db1;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  puStack_20 = param_1;
  uVar1 = FUN_00b8c330();
  FUN_009cb970(uVar1,param_3,param_5,CONCAT44(uStack_28,uStack_2c),0);
  param_1[0xd] = param_2;
  iStack_8 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::GuiService,void___cdecl(bool),class_rbx::signal<void___cdecl(bool)>,class_rbx::signal<void___cdecl(bool)>_RBX::GuiService::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,param_5);
  iStack_8._0_1_ = 2;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = uStack_1c;
    param_1[0xb] = uStack_18;
    param_1[0xc] = uStack_14;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
  }
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::GuiService,void___cdecl(bool),class_rbx::signal<void___cdecl(bool)>,class_rbx::signal<void___cdecl(bool)>_RBX::GuiService::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25304 ; VA 0x00b8fbb0 ; FUN_00b8fbb0 */

undefined4 * __thiscall FUN_00b8fbb0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9dc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_2[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  uStack_8 = 0;
  FUN_00d88580(param_2 + 3);
  *(undefined *)(param_1 + 0xb) = *(undefined *)(param_2 + 0xb);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25305 ; VA 0x00b8fc30 ; FUN_00b8fc30 */

undefined4 * __thiscall FUN_00b8fc30(undefined4 *param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f9de8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = *param_2;
  param_1[2] = 0;
  uVar1 = param_2[2];
  if (uVar1 != 0) {
    param_1[2] = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
    }
    else {
      uVar2 = param_2[5];
      uVar3 = param_2[6];
      uVar4 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar2;
      param_1[6] = uVar3;
      param_1[7] = uVar4;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
    }
  }
  param_1[10] = 0;
  uVar1 = param_2[10];
  uStack_8 = 0;
  if (uVar1 != 0) {
    param_1[10] = uVar1;
    if ((uVar1 & 1) != 0) {
      uVar2 = param_2[0xd];
      uVar3 = param_2[0xe];
      uVar4 = param_2[0xf];
      param_1[0xc] = param_2[0xc];
      param_1[0xd] = uVar2;
      param_1[0xe] = uVar3;
      param_1[0xf] = uVar4;
      *(undefined8 *)(param_1 + 0x10) = *(undefined8 *)(param_2 + 0x10);
      ExceptionList = pvStack_10;
      return param_1;
    }
    (**(code **)(uVar1 & 0xfffffffe))(param_2 + 0xc,param_1 + 0xc,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25306 ; VA 0x00b8fd00 ; FUN_00b8fd00 */

undefined4 __thiscall
FUN_00b8fd00(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 *param_8,
            ulonglong param_9,uint param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined8 param_16)

{
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9e18;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_3c = 0;
  ExceptionList = &pvStack_10;
  if (param_10 != 0) {
    uStack_3c = param_10;
    if ((param_10 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = &param_12;
      uStack_4c = 0xb8fd6c;
      ExceptionList = &pvStack_10;
      (**(code **)(param_10 & 0xfffffffe))();
    }
    else {
      uStack_34 = param_12;
      uStack_30 = param_13;
      uStack_2c = param_14;
      puStack_28 = (undefined4 *)param_15;
      uStack_24 = param_16;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  if (param_3 != 0) {
    if ((param_3 & 1) == 0) {
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_54,0);
    }
    else {
      uStack_54 = param_5;
      uStack_50 = param_6;
      uStack_4c = param_7;
      puStack_48 = param_8;
      uStack_44 = param_9;
    }
  }
  uStack_8._0_1_ = 1;
  FUN_00b90530(param_2);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    puStack_28 = &param_5;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0xb8fde6;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  uStack_8 = 4;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    puStack_28 = &param_12;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0xb8fe14;
    (**(code **)(param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25307 ; VA 0x00b8fe30 ; FUN_00b8fe30 */

undefined4 __thiscall
FUN_00b8fe30(undefined4 param_1,undefined4 param_2,int *param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 *param_9,
            ulonglong param_10)

{
  int iVar1;
  uint *puVar2;
  uint auStack_68 [2];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 *puStack_54;
  undefined8 uStack_50;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  ulonglong uStack_28;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9e50;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_40 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    uStack_40 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_50 = ZEXT48(&uStack_38);
      puStack_54 = &param_6;
      uStack_58 = 0xb8fe93;
      ExceptionList = &pvStack_10;
      uStack_14 = param_1;
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_38 = param_6;
      uStack_34 = param_7;
      uStack_30 = param_8;
      puStack_2c = param_9;
      uStack_28 = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  uStack_20 = param_2;
  piStack_1c = param_3;
  puStack_18 = (undefined *)auStack_68;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  auStack_68[0] = 0;
  puVar2 = auStack_68;
  if (uStack_40 != 0) {
    auStack_68[0] = uStack_40;
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_60,0);
      puVar2 = (uint *)puStack_18;
    }
    else {
      uStack_60 = uStack_38;
      uStack_5c = uStack_34;
      uStack_58 = uStack_30;
      puStack_54 = puStack_2c;
      uStack_50 = uStack_28;
      puVar2 = auStack_68;
    }
  }
  puStack_18 = (undefined *)puVar2;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00b90380(uStack_14,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_50 = CONCAT44(0xb8ff35,(undefined4)uStack_50);
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_50 = CONCAT44(0xb8ff46,(undefined4)uStack_50);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_40 != 0) {
    if (((uStack_40 & 1) == 0) && (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
      puStack_54 = &uStack_38;
      uStack_50 = CONCAT44(2,puStack_54);
      uStack_58 = 0xb8ff6b;
      (**(code **)(uStack_40 & 0xfffffffe))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_50 = CONCAT44(0xb8ff8c,(undefined4)uStack_50);
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_50 = CONCAT44(0xb8ff9d,(undefined4)uStack_50);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_54 = &param_6;
    uStack_50 = CONCAT44(2,puStack_54);
    uStack_58 = 0xb8ffc1;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25308 ; VA 0x00b8ffe0 ; FUN_00b8ffe0 */

undefined4 * __thiscall FUN_00b8ffe0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined in_stack_0000002c;
  undefined auStack_64 [32];
  undefined auStack_44 [32];
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9e98;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00d88580(&stack0x0000000c);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_24 = param_2;
  piStack_20 = param_3;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00d88580(auStack_64);
  piVar1 = param_3 + 2;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_1c = param_2;
  piStack_18 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = 0;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_00d88580(auStack_44);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  FUN_00d88a30();
  *(undefined *)(param_1 + 10) = in_stack_0000002c;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  FUN_00d88a30();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  FUN_00d88a30();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25309 ; VA 0x00b90110 ; FUN_00b90110 */

undefined4 __thiscall
FUN_00b90110(undefined4 param_1,undefined4 param_2,int *param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10,undefined4 *param_11)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 in_stack_0000003c;
  uint in_stack_00000040;
  int in_stack_00000044;
  uint in_stack_00000058;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined8 uStack_60;
  undefined4 uStack_48;
  undefined4 *puStack_44;
  undefined4 uStack_38;
  undefined4 *puStack_34;
  undefined4 *puStack_30;
  undefined *puStack_2c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9ee0;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  puStack_44 = &stack0x00000044;
  uStack_48 = 0xb9014d;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8._0_1_ = 4;
  uStack_60 = CONCAT44(&param_11,0xb90165);
  FUN_0054ef60();
  uStack_8._0_1_ = 5;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_70,0);
    }
    else {
      uStack_70 = param_6;
      uStack_6c = param_7;
      uStack_68 = param_8;
      uStack_64 = param_9;
      uStack_60 = param_10;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00b90810(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      puStack_2c = (undefined *)0xb901f9;
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        puStack_2c = (undefined *)0xb90208;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_34 = &param_6;
    puStack_2c = (undefined *)0x2;
    uStack_38 = 0xb9022c;
    puStack_30 = puStack_34;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  if (0xf < in_stack_00000040) {
    puStack_2c = (undefined *)(in_stack_00000040 + 1);
    puVar2 = param_11;
    if (0xfff < puStack_2c) {
      puVar2 = (undefined4 *)param_11[-1];
      puStack_2c = (undefined *)(in_stack_00000040 + 0x24);
      if (0x1f < (uint)((int)param_11 + (-4 - (int)puVar2))) {
                    /* WARNING: Subroutine does not return */
        puStack_2c = (undefined *)0xb902c1;
        FUN_017167a3();
      }
    }
    puStack_34 = (undefined4 *)0xb90263;
    puStack_30 = puVar2;
    FUN_01674ea0();
  }
  in_stack_0000003c = 0;
  in_stack_00000040 = 0xf;
  param_11 = (undefined4 *)((uint)param_11 & 0xffffff00);
  if (0xf < in_stack_00000058) {
    puStack_2c = (undefined *)(in_stack_00000058 + 1);
    iVar3 = in_stack_00000044;
    if (0xfff < puStack_2c) {
      iVar3 = *(int *)(in_stack_00000044 + -4);
      puStack_2c = (undefined *)(in_stack_00000058 + 0x24);
      if (0x1f < (in_stack_00000044 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_2c = &UNK_00b902c6;
        FUN_017167a3();
      }
    }
    puStack_34 = (undefined4 *)0xb902a5;
    puStack_30 = (undefined4 *)iVar3;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25310 ; VA 0x00b902d0 ; FUN_00b902d0 */

undefined4 * __thiscall FUN_00b902d0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar6 = ExceptionList;
  puStack_c = &LAB_017f9ef8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = 0;
  uVar2 = param_2[2];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[2] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[5];
      uVar4 = param_2[6];
      uVar5 = param_2[7];
      param_1[4] = param_2[4];
      param_1[5] = uVar3;
      param_1[6] = uVar4;
      param_1[7] = uVar5;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(param_2 + 8);
      ExceptionList = pvVar6;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 4,param_1 + 4,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25311 ; VA 0x00b90380 ; FUN_00b90380 */

int __thiscall
FUN_00b90380(int param_1,undefined4 param_2,int *param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9f28;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_0060e3f0(param_2,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  *(undefined4 *)(param_1 + 8) = 0;
  if (param_4 != 0) {
    *(uint *)(param_1 + 8) = param_4;
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,param_1 + 0x10,0);
    }
    else {
      *(undefined4 *)(param_1 + 0x10) = param_6;
      *(undefined4 *)(param_1 + 0x14) = param_7;
      *(undefined4 *)(param_1 + 0x18) = param_8;
      *(undefined4 *)(param_1 + 0x1c) = param_9;
      *(undefined8 *)(param_1 + 0x20) = param_10;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = 3;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_4 & 0xfffffffe))(&param_6,&param_6,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25312 ; VA 0x00b90480 ; FUN_00b90480 */

undefined4 * __thiscall FUN_00b90480(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9f58;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  param_1[1] = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00d88580(&stack0x0000000c);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  FUN_00d88a30();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25313 ; VA 0x00b90530 ; FUN_00b90530 */

undefined4 * __thiscall
FUN_00b90530(undefined4 *param_1,undefined4 param_2,uint param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined8 param_9,uint param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined8 param_16)

{
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9f90;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_38 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  if (param_3 != 0) {
    uStack_38 = param_3;
    if ((param_3 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_30,0);
    }
    else {
      uStack_30 = param_5;
      uStack_2c = param_6;
      uStack_28 = param_7;
      uStack_24 = param_8;
      uStack_20 = param_9;
      ExceptionList = &pvStack_10;
    }
  }
  *param_1 = param_2;
  uStack_8._0_1_ = 2;
  param_1[2] = 0;
  if (uStack_38 != 0) {
    param_1[2] = uStack_38;
    if ((uStack_38 & 1) == 0) {
      (**(code **)(uStack_38 & 0xfffffffe))(&uStack_30,param_1 + 4,0);
    }
    else {
      param_1[4] = uStack_30;
      param_1[5] = uStack_2c;
      param_1[6] = uStack_28;
      param_1[7] = uStack_24;
      *(undefined8 *)(param_1 + 8) = uStack_20;
    }
  }
  uStack_8._0_1_ = 3;
  if (((uStack_38 != 0) && ((uStack_38 & 1) == 0)) &&
     (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_38 & 0xfffffffe))(&uStack_30,&uStack_30,2);
  }
  uStack_8._0_1_ = 4;
  param_1[10] = 0;
  if (param_10 != 0) {
    param_1[10] = param_10;
    if ((param_10 & 1) == 0) {
      (**(code **)(param_10 & 0xfffffffe))(&param_12,param_1 + 0xc,0);
    }
    else {
      param_1[0xc] = param_12;
      param_1[0xd] = param_13;
      param_1[0xe] = param_14;
      param_1[0xf] = param_15;
      *(undefined8 *)(param_1 + 0x10) = param_16;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  uStack_8 = 6;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_10 & 0xfffffffe))(&param_12,&param_12,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25314 ; VA 0x00b906c0 ; FUN_00b906c0 */

undefined4 __thiscall
FUN_00b906c0(undefined4 param_1,undefined4 param_2,int *param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 *param_9,
            undefined8 param_10,int param_11)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000040;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 *puStack_2c;
  undefined8 uStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f9fc0;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_38,0);
    }
    else {
      uStack_38 = param_6;
      uStack_34 = param_7;
      uStack_30 = param_8;
      puStack_2c = param_9;
      uStack_28 = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00b90380(param_2,param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_28 = CONCAT44(&param_11,0xb9076c);
  FUN_0054ef60();
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      uStack_28 = CONCAT44(0xb90785,(undefined4)uStack_28);
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        uStack_28 = CONCAT44(0xb90794,(undefined4)uStack_28);
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      puStack_2c = &param_6;
      uStack_28 = CONCAT44(2,puStack_2c);
      uStack_30 = 0xb907b8;
      (**(code **)(param_4 & 0xfffffffe))();
    }
  }
  if (0xf < in_stack_00000040) {
    uVar3 = in_stack_00000040 + 1;
    iVar2 = param_11;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_11 + -4);
      uVar3 = in_stack_00000040 + 0x24;
      if (0x1f < (param_11 - iVar2) - 4U) {
        uStack_28 = CONCAT44(&UNK_00b9080b,(undefined4)uStack_28);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_28 = CONCAT44(uVar3,iVar2);
    puStack_2c = (undefined4 *)0xb907ef;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25315 ; VA 0x00b90810 ; FUN_00b90810 */

undefined4 __thiscall
FUN_00b90810(undefined4 param_1,undefined4 param_2,int *param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10,undefined4 *param_11)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 in_stack_0000003c;
  uint in_stack_00000040;
  int in_stack_00000044;
  uint in_stack_00000058;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_34;
  undefined4 *puStack_30;
  undefined4 *puStack_2c;
  undefined4 *puStack_28;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fa000;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  uStack_44 = CONCAT44(&param_11,0xb9084d);
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8._0_1_ = 4;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_54,0);
    }
    else {
      uStack_54 = param_6;
      uStack_50 = param_7;
      uStack_4c = param_8;
      uStack_48 = param_9;
      uStack_44 = param_10;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 3;
  FUN_00b906c0(param_2,param_3);
  puStack_28 = &stack0x00000044;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  puStack_2c = (undefined4 *)0xb908d8;
  FUN_0054ef60();
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      puStack_28 = (undefined4 *)0xb908f1;
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        puStack_28 = (undefined4 *)0xb90900;
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_30 = &param_6;
    puStack_28 = (undefined4 *)0x2;
    uStack_34 = 0xb90924;
    puStack_2c = puStack_30;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  if (0xf < in_stack_00000040) {
    puStack_28 = (undefined4 *)(in_stack_00000040 + 1);
    puVar2 = param_11;
    if (0xfff < puStack_28) {
      puVar2 = (undefined4 *)param_11[-1];
      puStack_28 = (undefined4 *)(in_stack_00000040 + 0x24);
      if (0x1f < (uint)((int)param_11 + (-4 - (int)puVar2))) {
                    /* WARNING: Subroutine does not return */
        puStack_28 = (undefined4 *)0xb909b9;
        FUN_017167a3();
      }
    }
    puStack_30 = (undefined4 *)0xb9095b;
    puStack_2c = puVar2;
    FUN_01674ea0();
  }
  in_stack_0000003c = 0;
  in_stack_00000040 = 0xf;
  param_11 = (undefined4 *)((uint)param_11 & 0xffffff00);
  if (0xf < in_stack_00000058) {
    puStack_28 = (undefined4 *)(in_stack_00000058 + 1);
    iVar3 = in_stack_00000044;
    if (0xfff < puStack_28) {
      iVar3 = *(int *)(in_stack_00000044 + -4);
      puStack_28 = (undefined4 *)(in_stack_00000058 + 0x24);
      if (0x1f < (in_stack_00000044 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_28 = (undefined4 *)&UNK_00b909be;
        FUN_017167a3();
      }
    }
    puStack_30 = (undefined4 *)0xb9099d;
    puStack_2c = (undefined4 *)iVar3;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 25316 ; VA 0x00b909c0 ; FUN_00b909c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __fastcall FUN_00b909c0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined auStack_44 [4];
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined1 *puStack_34;
  char *pcStack_30;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa248;
  pvStack_10 = ExceptionList;
  pcStack_30 = "GuiService";
  puStack_34 = (undefined1 *)0xb909ec;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0089a650();
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::GuiService,class_RBX::ServiceInstance>::vftable;
  pcStack_30 = (char *)0xb90a02;
  uVar4 = FUN_00b8c330();
  param_1[3] = uVar4;
  *param_1 = RBX::GuiService::vftable;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  *(undefined2 *)(param_1 + 0x2b) = 0;
  *(undefined *)((int)param_1 + 0xae) = 0;
  param_1[0x2c] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x3a] = 0;
  param_1[0x3d] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0x44480000;
  param_1[0x3d] = 0x44160000;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  param_1[0x42] = 0;
  param_1[0x43] = 0;
  param_1[0x44] = 0;
  param_1[0x45] = 0;
  param_1[0x46] = 0;
  param_1[0x47] = 0;
  pcStack_30 = (char *)0x0;
  param_1[0x4c] = 0;
  param_1[0x4d] = 0xf;
  puStack_34 = &DAT_018bc9b8;
  uStack_8._0_1_ = 0x1b;
  uStack_8._1_3_ = 0;
  *(undefined *)(param_1 + 0x48) = 0;
  uStack_38 = 0xb90bd9;
  FUN_005542c0();
  param_1[0x52] = 0;
  param_1[0x53] = 0xf;
  *(undefined *)(param_1 + 0x4e) = 0;
  param_1[0x54] = 1;
  pcStack_30 = (char *)0xb;
  *(undefined *)(param_1 + 0x55) = 0;
  puStack_34 = (undefined1 *)0xb90c0c;
  uVar4 = FUN_00588320();
  param_1[0x56] = uVar4;
  param_1[0x57] = 0;
  param_1[0x58] = 0x3f800000;
  param_1[0x59] = 0;
  param_1[0x5a] = 0;
  param_1[0x5b] = 0x101;
  puStack_34 = (undefined1 *)0xb;
  *(undefined *)(param_1 + 0x5c) = 0;
  uStack_38 = 0xb90c52;
  uVar4 = FUN_00588320();
  param_1[0x5d] = uVar4;
  param_1[0x5e] = 0;
  param_1[0x5f] = 0x3f800000;
  param_1[0x60] = 0;
  param_1[0x61] = 0;
  *(undefined2 *)(param_1 + 0x62) = 0x101;
  param_1[99] = 0;
  param_1[100] = 0;
  param_1[0x65] = 0;
  param_1[0x66] = 0;
  param_1[0x67] = 0;
  param_1[0x68] = 0;
  param_1[0x69] = 0;
  param_1[0x6a] = 0;
  param_1[0x6b] = 0;
  param_1[0x6c] = 0;
  param_1[0x6d] = 0;
  param_1[0x6e] = 0;
  param_1[0x6f] = 0;
  param_1[0x70] = 0;
  puVar6 = param_1 + 0x72;
  param_1[0x71] = 0;
  uStack_8._0_1_ = 0x26;
  *puVar6 = 0;
  param_1[0x73] = 0;
  pcStack_30 = (char *)0xb90d43;
  piStack_18 = puVar6;
  uVar4 = FUN_00575ad0();
  *puVar6 = uVar4;
  puVar6 = param_1 + 0x74;
  uStack_8._0_1_ = 0x27;
  *puVar6 = 0;
  param_1[0x75] = 0;
  pcStack_30 = (char *)0xb90d66;
  piStack_18 = puVar6;
  uVar4 = FUN_00575ad0();
  *puVar6 = uVar4;
  uStack_8._0_1_ = 0x28;
  puVar6 = param_1 + 0x76;
  *puVar6 = 0;
  param_1[0x77] = 0;
  pcStack_30 = (char *)0xb90d89;
  piStack_18 = puVar6;
  uVar4 = FUN_00b92750();
  *puVar6 = uVar4;
  piVar3 = param_1 + 0x78;
  uStack_8._0_1_ = 0x29;
  *piVar3 = 0;
  param_1[0x79] = 0;
  pcStack_30 = (char *)0xb90dac;
  piStack_18 = piVar3;
  iVar5 = FUN_0089c660();
  *piVar3 = iVar5;
  pcStack_30 = auStack_1c;
  *(undefined *)(param_1 + 0x7a) = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x2a);
  param_1[0x39] = 0x1010101;
  puStack_34 = (undefined1 *)0xb90dcc;
  puVar6 = (undefined4 *)FUN_00b8e800();
  uVar4 = *puVar6;
  uVar2 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  param_1[0x67] = uVar4;
  piVar3 = (int *)param_1[0x68];
  param_1[0x68] = uVar2;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar5 = piVar3[1] + -1;
    piVar3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      pcStack_30 = (char *)0xb90e07;
      (**(code **)*piVar3)();
      LOCK();
      iVar5 = piVar3[2] + -1;
      piVar3[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        pcStack_30 = (char *)0xb90e1a;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piVar3 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_18[1] + -1;
    piStack_18[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      pcStack_30 = (char *)0xb90e31;
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        pcStack_30 = (char *)0xb90e43;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  piStack_18 = (int *)auStack_44;
  puStack_34 = (undefined1 *)0x0;
  pcStack_30 = (char *)0xf;
  auStack_44[0] = 0;
  FUN_005542c0("rbxasset://textures/ui/SelectionBox.png",0x27);
  uStack_8._0_1_ = 0x2b;
  FUN_009cbbb0(auStack_44);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x2a);
  FUN_01008e50();
  puVar6 = puStack_14;
  pcStack_30 = (char *)0x3f800000;
  puStack_34 = (undefined1 *)0xb90e9e;
  FUN_00c7bce0();
  uStack_3c = _DAT_0195a360;
  uStack_38 = _UNK_0195a364;
  puStack_34 = (undefined1 *)_UNK_0195a368;
  pcStack_30 = (char *)_UNK_0195a36c;
  uStack_40 = 0xb90eb8;
  FUN_010093e0();
  pcStack_30 = (char *)0x1;
  puStack_34 = (undefined1 *)0xb90ec5;
  FUN_01009230();
  pcStack_30 = (char *)0xe;
  puStack_34 = (undefined1 *)0x3f800000;
  uStack_38 = 0xe;
  uStack_3c = 0x3f800000;
  uStack_40 = 0xb90ee7;
  puVar7 = (undefined4 *)FUN_00da7df0();
  uStack_3c = *puVar7;
  uStack_38 = puVar7[1];
  puStack_34 = (undefined1 *)puVar7[2];
  pcStack_30 = (char *)puVar7[3];
  uStack_40 = 0xb90ef9;
  FUN_00c7c8c0();
  pcStack_30 = (char *)0xfffffff9;
  puStack_34 = (undefined1 *)0x0;
  uStack_38 = 0xfffffff9;
  uStack_3c = 0;
  uStack_40 = 0xb90f1b;
  puVar7 = (undefined4 *)FUN_00da7df0();
  uStack_3c = *puVar7;
  uStack_38 = puVar7[1];
  puStack_34 = (undefined1 *)puVar7[2];
  pcStack_30 = (char *)puVar7[3];
  uStack_40 = 0xb90f2d;
  FUN_00c7c400();
  ExceptionList = pvStack_10;
  return puVar6;
}



/* FUNCTION 25317 ; VA 0x00b90f40 ; FUN_00b90f40 */

void __fastcall FUN_00b90f40(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int **)(param_1 + 0x4c) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0x4c) + 4))(1);
  }
  if (*(int **)(param_1 + 0x48) != (int *)0x0) {
    (**(code **)(**(int **)(param_1 + 0x48) + 4))(1);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 != 0) {
    piVar2 = *(int **)(iVar1 + 4);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar3 = piVar2[1] + -1;
      piVar2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_01674ea0(iVar1,8);
  }
  FUN_009cb8b0();
  return;
}



/* FUNCTION 25318 ; VA 0x00b90fc0 ; FUN_00b90fc0 */

void __fastcall FUN_00b90fc0(int *param_1)

{
  int iVar1;
  int *piVar2;
  void **ppvVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  piVar5 = *(int **)(iVar1 + 4);
  uStack_8 = 0;
  iVar4 = iVar1;
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (*(char *)((int)piVar5 + 0xd) == '\0') {
    do {
      FUN_00b92880(piVar5[2]);
      piVar2 = (int *)*piVar5;
      FUN_01674ea0(piVar5,0x10);
      piVar5 = piVar2;
    } while (*(char *)((int)piVar2 + 0xd) == '\0');
    iVar4 = *param_1;
    ppvVar3 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar3;
  *(int *)(iVar4 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25319 ; VA 0x00b91060 ; FUN_00b91060 */

int __fastcall FUN_00b91060(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_00d88a30();
  piVar3 = *(int **)(param_1 + 8);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x00b9107f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar4 = (**(code **)(*piVar3 + 4))();
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 25320 ; VA 0x00b91090 ; FUN_00b91090 */

void FUN_00b91090(void)

{
  FUN_00a7c840();
  return;
}



/* FUNCTION 25321 ; VA 0x00b910a0 ; FUN_00b910a0 */

void FUN_00b910a0(void)

{
  FUN_00b91300();
  return;
}



/* FUNCTION 25322 ; VA 0x00b910b0 ; thunk_FUN_00a7c840 */

code * __fastcall thunk_FUN_00a7c840(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  code *pcVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar6 = *(code **)(param_1 + 8);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar6 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar6 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x10,param_1 + 0x10,2);
      }
    }
    *(undefined4 *)(param_1 + 8) = 0;
  }
  piVar5 = *(int **)(param_1 + 4);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      pcVar6 = (code *)(**(code **)*piVar5)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 25323 ; VA 0x00b910c0 ; FUN_00b910c0 */

int __fastcall FUN_00b910c0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = FUN_00d88a30();
  piVar3 = *(int **)(param_1 + 4);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar1 = piVar3 + 2;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x00b910df. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      iVar4 = (**(code **)(*piVar3 + 4))();
      return iVar4;
    }
  }
  return iVar4;
}



/* FUNCTION 25324 ; VA 0x00b910f0 ; thunk_FUN_00b91300 */

void __fastcall thunk_FUN_00b91300(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x54);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x40);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00b9138f;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x50) = 0;
  *(undefined4 *)(param_1 + 0x54) = 0xf;
  *(undefined *)(param_1 + 0x40) = 0;
  uVar1 = *(uint *)(param_1 + 0x3c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x28);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00b9138f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0xf;
  *(undefined *)(param_1 + 0x28) = 0;
  FUN_00a7c840();
  return;
}



/* FUNCTION 25325 ; VA 0x00b91100 ; FUN_00b91100 */

void __fastcall FUN_00b91100(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  piVar3 = (int *)*param_1;
  piVar4 = (int *)*piVar3;
  ExceptionList = &pvStack_10;
  *piVar3 = (int)piVar3;
  *(int *)(*param_1 + 4) = *param_1;
  param_1[1] = 0;
  piVar3 = (int *)*param_1;
  if (piVar4 != piVar3) {
    do {
      piVar1 = (int *)*piVar4;
      uVar2 = piVar4[2];
      uStack_8 = 0;
      if (uVar2 != 0) {
        if ((uVar2 & 1) == 0) {
          if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
            (**(code **)(uVar2 & 0xfffffffe))(piVar4 + 4,piVar4 + 4,2);
          }
        }
        piVar4[2] = 0;
      }
      uStack_8 = 0xffffffff;
      FUN_01674ea0(piVar4,0x28);
      piVar3 = (int *)*param_1;
      piVar4 = piVar1;
    } while (piVar1 != piVar3);
  }
  FUN_01674ea0(piVar3,0x28);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25326 ; VA 0x00b911b0 ; FUN_00b911b0 */

void __fastcall FUN_00b911b0(undefined4 *param_1)

{
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00b96ac0(&puStack_14,*(undefined4 *)*param_1,(undefined4 *)*param_1);
  FUN_01674ea0(*param_1,0x1c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25327 ; VA 0x00b91200 ; FUN_00b91200 */

void __fastcall FUN_00b91200(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00b92830(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x1c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25328 ; VA 0x00b91260 ; FUN_00b91260 */

void __fastcall FUN_00b91260(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_00b8e8c0(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x30);
  }
  return;
}



/* FUNCTION 25329 ; VA 0x00b91290 ; FUN_00b91290 */

void __fastcall FUN_00b91290(int *param_1)

{
  int iVar1;
  int *piVar2;
  void **ppvVar3;
  int iVar4;
  int *piVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  piVar5 = *(int **)(iVar1 + 4);
  uStack_8 = 0;
  iVar4 = iVar1;
  ExceptionList = &pvStack_10;
  ppvVar3 = &pvStack_10;
  if (*(char *)((int)piVar5 + 0xd) == '\0') {
    do {
      FUN_00b92880(piVar5[2]);
      piVar2 = (int *)*piVar5;
      FUN_01674ea0(piVar5,0x10);
      piVar5 = piVar2;
    } while (*(char *)((int)piVar2 + 0xd) == '\0');
    iVar4 = *param_1;
    ppvVar3 = (void **)ExceptionList;
  }
  ExceptionList = ppvVar3;
  *(int *)(iVar4 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25330 ; VA 0x00b912a0 ; FUN_00b912a0 */

void __fastcall FUN_00b912a0(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x3c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x28);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0xf;
  *(undefined *)(param_1 + 0x28) = 0;
  FUN_00a7c840();
  return;
}



/* FUNCTION 25331 ; VA 0x00b91300 ; FUN_00b91300 */

void __fastcall FUN_00b91300(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x54);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x40);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00b9138f;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x50) = 0;
  *(undefined4 *)(param_1 + 0x54) = 0xf;
  *(undefined *)(param_1 + 0x40) = 0;
  uVar1 = *(uint *)(param_1 + 0x3c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x28);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00b9138f:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0xf;
  *(undefined *)(param_1 + 0x28) = 0;
  FUN_00a7c840();
  return;
}



/* FUNCTION 25332 ; VA 0x00b913a0 ; FUN_00b913a0 */

void __fastcall FUN_00b913a0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00b8e8c0(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x30);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 25333 ; VA 0x00b91450 ; FUN_00b91450 */

void __fastcall FUN_00b91450(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_00b8e8c0(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x30);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 25334 ; VA 0x00b91460 ; FUN_00b91460 */

void __fastcall FUN_00b91460(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a950;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::GuiService::vftable;
  puStack_14 = param_1;
  FUN_0089ad50();
  FUN_00b90fc0();
  uStack_8 = 0;
  FUN_00b96ac0(&puStack_14,*(undefined4 *)param_1[0x74],(undefined4 *)param_1[0x74]);
  FUN_01674ea0(param_1[0x74],0x1c);
  iVar2 = param_1[0x72];
  piVar1 = param_1 + 0x72;
  uStack_8 = 1;
  FUN_00b92830(*(undefined4 *)(iVar2 + 4));
  *(int *)(*piVar1 + 4) = iVar2;
  *(int *)*piVar1 = iVar2;
  *(int *)(*piVar1 + 8) = iVar2;
  param_1[0x73] = 0;
  FUN_01674ea0(*piVar1,0x1c);
  FUN_005e6280();
  uStack_8 = 2;
  FUN_01679490();
  iVar2 = param_1[0x6d];
  if (iVar2 != 0) {
    piVar1 = (int *)(iVar2 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar2);
    }
  }
  piVar1 = (int *)param_1[0x6c];
  uStack_8 = 0xffffffff;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar1 = (int *)param_1[0x6a];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar1 = (int *)param_1[0x68];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[1] + -1;
    piVar1[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  piVar1 = (int *)param_1[0x66];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar1 = (int *)param_1[100];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_00612580();
  FUN_00b913a0();
  uVar3 = param_1[0x53];
  if (0xf < uVar3) {
    iVar2 = param_1[0x4e];
    uVar5 = uVar3 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar3 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) goto LAB_00b91806;
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x52] = 0;
  param_1[0x53] = 0xf;
  *(undefined *)(param_1 + 0x4e) = 0;
  uVar3 = param_1[0x4d];
  if (0xf < uVar3) {
    iVar2 = param_1[0x48];
    uVar5 = uVar3 + 1;
    iVar4 = iVar2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar2 + -4);
      uVar5 = uVar3 + 0x24;
      if (0x1f < (iVar2 - iVar4) - 4U) {
LAB_00b91806:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[0x4c] = 0;
  param_1[0x4d] = 0xf;
  *(undefined *)(param_1 + 0x48) = 0;
  uStack_8 = 3;
  FUN_01679490();
  iVar2 = param_1[0x46];
  if (iVar2 != 0) {
    piVar1 = (int *)(iVar2 + 4);
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      FUN_01674ea0(iVar2);
    }
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  uVar3 = param_1[0x2c];
  uStack_8 = 4;
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
        (**(code **)(uVar3 & 0xfffffffe))(param_1 + 0x2e,param_1 + 0x2e,2);
      }
    }
    param_1[0x2c] = 0;
  }
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_016790b0();
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25335 ; VA 0x00b91810 ; FUN_00b91810 */

undefined4 * __thiscall FUN_00b91810(int *param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  int iStack_8;
  
  puVar4 = (undefined4 *)*param_1;
  if (*(char *)((int)puVar4[1] + 0xd) == '\0') {
    puVar1 = (undefined4 *)puVar4[1];
    do {
      if ((uint)puVar1[5] < *(uint *)(param_2 + 4)) {
        puVar2 = (undefined4 *)puVar1[2];
      }
      else {
        puVar2 = (undefined4 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((int)puVar2 + 0xd) == '\0');
    if ((puVar4 != (undefined4 *)*param_1) && ((uint)puVar4[5] <= *(uint *)(param_2 + 4))) {
      return puVar4 + 6;
    }
  }
  iStack_8 = param_2;
  iVar3 = FUN_00b8c450(&DAT_018bdeda,&iStack_8,(int)&param_2 + 3);
  FUN_00b8c950(&param_2,puVar4,iVar3 + 0x10,iVar3);
  return (undefined4 *)(param_2 + 0x18);
}



/* FUNCTION 25336 ; VA 0x00b91890 ; FUN_00b91890 */

int * __thiscall FUN_00b91890(int *param_1,int *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piStack_8;
  
  puVar4 = (undefined4 *)*param_1;
  if (*(char *)((int)puVar4[1] + 0xd) == '\0') {
    puVar1 = (undefined4 *)puVar4[1];
    do {
      if ((int)puVar1[4] < *param_2) {
        puVar2 = (undefined4 *)puVar1[2];
      }
      else {
        puVar2 = (undefined4 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((int)puVar2 + 0xd) == '\0');
    if ((puVar4 != (undefined4 *)*param_1) && ((int)puVar4[4] <= *param_2)) {
      return puVar4 + 5;
    }
  }
  piStack_8 = param_2;
  iVar3 = FUN_00b8c4a0(&DAT_018bdeda,&piStack_8,(int)&param_2 + 3);
  FUN_00b8cb60(&param_2,puVar4,iVar3 + 0x10,iVar3);
  return param_2 + 5;
}



/* FUNCTION 25337 ; VA 0x00b91910 ; FUN_00b91910 */

int * __thiscall FUN_00b91910(byte *param_1,int param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  byte *pbVar9;
  undefined4 *puVar10;
  int aiStack_3c [5];
  uint uStack_28;
  uint uStack_24;
  int *piStack_20;
  undefined2 uStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iVar5 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa270;
  pvStack_10 = ExceptionList;
  pbVar9 = param_1 + *param_1 + 1;
  ExceptionList = &pvStack_10;
  uStack_14 = FUN_0055c740(pbVar9,param_2);
  FUN_00562fc0(&param_2,uStack_14,iVar5,-(uint)(pbVar9 != (byte *)0x0) & (uint)(pbVar9 + 1));
  if (param_2 != 0) {
    ExceptionList = pvStack_10;
    return (int *)(param_2 + 8);
  }
  piStack_20 = (int *)0x0;
  uStack_1c = 0;
  uStack_24 = -(uint)(param_1 != (byte *)0xfffffffd) & (uint)(param_1 + 4);
  iStack_8 = 0;
  FUN_0054ef60(iVar5);
  iStack_8._0_1_ = 1;
  FUN_00b94440();
  piVar4 = piStack_20;
  piStack_18 = piStack_20 + 2;
  FUN_0054ef60(aiStack_3c);
  piVar4[8] = 0;
  piVar4[9] = 0;
  piVar4[10] = 0;
  piVar4[0xb] = 0;
  uStack_1c = CONCAT11(1,(undefined)uStack_1c);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_28) {
    uVar8 = uStack_28 + 1;
    iVar5 = aiStack_3c[0];
    if (0xfff < uVar8) {
      iVar5 = *(int *)(aiStack_3c[0] + -4);
      uVar8 = uStack_28 + 0x24;
      if (0x1f < (aiStack_3c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar8);
  }
  uVar2 = *(uint *)(param_1 + 8);
  uVar8 = uVar2 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar8 = FUN_005d6bb0(uVar8);
    if (uVar8 <= *(uint *)(param_1 + 4)) {
      uVar8 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar8);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar8) {
    param_2 = 1;
    uVar6 = uVar2 >> 1;
    if (uVar2 + (uVar2 >> 1) <= uVar8) {
      uVar6 = 1;
    }
    iVar5 = FUN_005d6bb0(uVar6 + uVar2);
    if (iVar5 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar5);
      puVar10 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar10;
      while (puVar3 != (undefined4 *)0x0) {
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar3[1] % *(uint *)(param_1 + 4)) * 4) == 0
           ) {
          *piVar1 = (int)puVar10;
          puVar10 = puVar3;
        }
        else {
          *puVar10 = *puVar3;
          *puVar3 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar3;
        }
        puVar3 = (undefined4 *)*puVar10;
      }
    }
  }
  piVar4[1] = uStack_14;
  uStack_14 = uStack_14 % *(uint *)(param_1 + 4);
  piVar7 = *(int **)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + uStack_14 * 4);
  if (piVar7 == (int *)0x0) {
    piVar7 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
    if (*piVar7 != 0) {
      *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar7 + 4) % *(uint *)(param_1 + 4)) * 4) =
           piVar4;
    }
    *piVar1 = (int)piVar7;
    *piVar4 = *piVar7;
  }
  else {
    *piVar4 = *piVar7;
    piVar7 = (int *)*piVar1;
  }
  *piVar7 = (int)piVar4;
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  ExceptionList = pvStack_10;
  return piStack_18;
}



/* FUNCTION 25338 ; VA 0x00b91b20 ; FUN_00b91b20 */

/* WARNING: Removing unreachable block (ram,0x00b91c5a) */
/* WARNING: Removing unreachable block (ram,0x00b91c10) */
/* WARNING: Removing unreachable block (ram,0x00b91c1e) */
/* WARNING: Removing unreachable block (ram,0x00b91d0e) */
/* WARNING: Removing unreachable block (ram,0x00b91c32) */
/* WARNING: Removing unreachable block (ram,0x00b91c68) */
/* WARNING: Removing unreachable block (ram,0x00b91d13) */
/* WARNING: Removing unreachable block (ram,0x00b91c7c) */

void __thiscall
FUN_00b91b20(uint *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,uint param_14)

{
  code *pcVar1;
  uint in_stack_00000054;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fa2b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 3;
  if (*param_1 == 0) {
    ExceptionList = &pvStack_10;
    FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0();
  }
  pcVar1 = *(code **)((*param_1 & 0xfffffffe) + 4);
  ExceptionList = &pvStack_10;
  FUN_005880d0();
  uStack_8._0_1_ = 5;
  FUN_005880d0();
  uStack_8._0_1_ = 3;
  (*pcVar1)(param_1 + 2,param_2,param_3,param_4,param_5,CONCAT44(param_7,param_6),param_8,param_9,
            param_10,param_11,CONCAT44(param_13,param_12));
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((param_14 != 0) && ((param_14 & 1) == 0)) &&
     (*(code **)(param_14 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_14 & 0xfffffffe))();
  }
  uStack_8 = 7;
  if (((in_stack_00000054 != 0) && ((in_stack_00000054 & 1) == 0)) &&
     (*(code **)(in_stack_00000054 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000054 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25339 ; VA 0x00b91d20 ; FUN_00b91d20 */

void __thiscall
FUN_00b91d20(undefined4 *param_1,undefined4 param_2,uint param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 *param_8,
            ulonglong param_9,uint param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined8 param_16)

{
  code *pcVar1;
  uint *puVar2;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint auStack_3c [2];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fa2d8;
  pvStack_10 = ExceptionList;
  param_2 = auStack_3c;
  pcVar1 = (code *)*param_1;
  uStack_8 = 1;
  auStack_3c[0] = 0;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_3c;
  if (param_10 != 0) {
    auStack_3c[0] = param_10;
    if ((param_10 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = &param_12;
      uStack_4c = 0xb91d8e;
      ExceptionList = &pvStack_10;
      (**(code **)(param_10 & 0xfffffffe))();
      puVar2 = param_2;
    }
    else {
      uStack_34 = param_12;
      uStack_30 = param_13;
      uStack_2c = param_14;
      uStack_28 = param_15;
      uStack_24 = param_16;
      ExceptionList = &pvStack_10;
      puVar2 = auStack_3c;
    }
  }
  param_2 = puVar2;
  uStack_8._0_1_ = 2;
  if (param_3 != 0) {
    if ((param_3 & 1) == 0) {
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_54,0);
    }
    else {
      uStack_54 = param_5;
      uStack_50 = param_6;
      uStack_4c = param_7;
      puStack_48 = param_8;
      uStack_44 = param_9;
    }
  }
  uStack_8._0_1_ = 1;
  (*pcVar1)();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  uStack_8 = 4;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(param_10 & 0xfffffffe))(&param_12,&param_12,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25340 ; VA 0x00b91e50 ; FUN_00b91e50 */

/* WARNING: Removing unreachable block (ram,0x00b91ea2) */
/* WARNING: Removing unreachable block (ram,0x00b91eb2) */
/* WARNING: Removing unreachable block (ram,0x00b91eb8) */

void * __thiscall
FUN_00b91e50(int *param_1,undefined4 param_2,int *param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fa310;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar3 = FUN_01675290(0);
    uStack_8._0_1_ = 4;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    pvVar4 = (void *)FUN_01675290(uVar3);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)(*param_3 + 4))();
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    piVar1 = param_5 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      pvVar4 = (void *)(**(code **)(*param_5 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 25341 ; VA 0x00b91f38 ; Catch@00b91f38 */

undefined * Catch_00b91f38(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00b91f49;
}



/* FUNCTION 25342 ; VA 0x00b91f60 ; FUN_00b91f60 */

/* WARNING: Removing unreachable block (ram,0x00b91fb2) */
/* WARNING: Removing unreachable block (ram,0x00b91fc2) */
/* WARNING: Removing unreachable block (ram,0x00b91fc8) */

void __fastcall FUN_00b91f60(int *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa330;
  pvStack_10 = ExceptionList;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8 = 2;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = 4;
    FUN_01675290(uVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25343 ; VA 0x00b9200c ; Catch@00b9200c */

undefined * Catch_00b9200c(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x20));
  return &DAT_00b9201d;
}



/* FUNCTION 25344 ; VA 0x00b92030 ; FUN_00b92030 */

/* WARNING: Removing unreachable block (ram,0x00b920ce) */
/* WARNING: Removing unreachable block (ram,0x00b920de) */
/* WARNING: Removing unreachable block (ram,0x00b920e4) */

void __thiscall FUN_00b92030(int *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000020;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fa358;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*param_1 != 0) {
    ExceptionList = &pvStack_10;
    uVar1 = FUN_01675290(0);
    uStack_8._0_1_ = 3;
    FUN_005e6300(param_1);
    FUN_0056c630();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    FUN_01675290(uVar1);
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  if (0xf < in_stack_00000020) {
    uVar3 = in_stack_00000020 + 1;
    iVar2 = param_4;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_4 + -4);
      uVar3 = in_stack_00000020 + 0x24;
      if (0x1f < (param_4 - iVar2) - 4U) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25345 ; VA 0x00b92135 ; Catch@00b92135 */

undefined * Catch_00b92135(void)

{
  int unaff_EBP;
  
  FUN_01679980(*(undefined4 *)(unaff_EBP + -0x24));
  return &DAT_00b92146;
}



/* FUNCTION 25346 ; VA 0x00b92160 ; FUN_00b92160 */

int __thiscall FUN_00b92160(int param_1,byte param_2)

{
  if (*(int *)(param_1 + 0x4c) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x4c),4);
  }
  if (*(int *)(param_1 + 0x48) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x48),4);
  }
  if (*(int *)(param_1 + 0x44) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x44),4);
  }
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),4);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 25347 ; VA 0x00b921d0 ; FUN_00b921d0 */

undefined4 __thiscall FUN_00b921d0(undefined4 param_1,byte param_2)

{
  FUN_00b90f40();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x50);
  }
  return param_1;
}



/* FUNCTION 25348 ; VA 0x00b92200 ; FUN_00b92200 */

int __thiscall FUN_00b92200(int param_1,byte param_2)

{
  FUN_005c4ac0();
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),4);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 25349 ; VA 0x00b92240 ; FUN_00b92240 */

int __thiscall FUN_00b92240(int param_1,byte param_2)

{
  FUN_005c4ac0();
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),8);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 25350 ; VA 0x00b92280 ; FUN_00b92280 */

int __thiscall FUN_00b92280(int param_1,byte param_2)

{
  FUN_005c4ac0();
  if (*(int *)(param_1 + 0x40) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 0x40),1);
  }
  FUN_009cb8b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x48);
  }
  return param_1;
}



/* FUNCTION 25351 ; VA 0x00b922c0 ; FUN_00b922c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b922c0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::GuiService::CenterDialogType>::vftable;
  _DAT_01ef2520 = _DAT_01ef2520 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 25352 ; VA 0x00b922f0 ; FUN_00b922f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b922f0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::ConnectionError>::vftable;
  _DAT_01f17c70 = _DAT_01f17c70 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 25353 ; VA 0x00b92320 ; FUN_00b92320 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b92320(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::GuiService::SpecialKey>::vftable;
  _DAT_01ef2518 = _DAT_01ef2518 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 25354 ; VA 0x00b92350 ; FUN_00b92350 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00b92350(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::GuiService::UiMessageType>::vftable;
  _DAT_01ef2528 = _DAT_01ef2528 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 25355 ; VA 0x00b92380 ; FUN_00b92380 */

undefined4 * __thiscall FUN_00b92380(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Folder*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 25356 ; VA 0x00b923b0 ; FUN_00b923b0 */

undefined4 * __thiscall FUN_00b923b0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::Folder*>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 25357 ; VA 0x00b923e0 ; FUN_00b923e0 */

undefined4 __thiscall FUN_00b923e0(undefined4 param_1,byte param_2)

{
  FUN_00b91460();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x1f0);
  }
  return param_1;
}



/* FUNCTION 25358 ; VA 0x00b92410 ; FUN_00b92410 */

void __thiscall FUN_00b92410(int param_1,undefined4 param_2)

{
  int *piVar1;
  undefined auStack_10 [4];
  undefined auStack_c [4];
  undefined4 uStack_8;
  
  if (DAT_01d67918 == '\0') {
    uStack_8 = param_2;
    piVar1 = (int *)FUN_00b97590(auStack_c,&uStack_8);
    if (*piVar1 == *(int *)(param_1 + 0x1e0)) {
      FUN_00b50590(auStack_10,0,&param_2,param_2);
    }
  }
  return;
}



/* FUNCTION 25359 ; VA 0x00b92460 ; FUN_00b92460 */

undefined4 __thiscall FUN_00b92460(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int *piVar2;
  undefined uVar3;
  int iStack_8;
  
  uVar1 = param_2;
  if (DAT_01d67918 == '\0') {
    iStack_8 = param_1;
    piVar2 = (int *)FUN_00b97590(&iStack_8,&param_2);
    if (*piVar2 != *(int *)(param_1 + 0x1e0)) {
      uVar3 = 0;
      FUN_005542c0(&DAT_018bc9b8,0);
      FUN_006ecd90(uVar1,uVar3);
      return 1;
    }
  }
  return 0;
}



/* FUNCTION 25360 ; VA 0x00b924e0 ; FUN_00b924e0 */

void __fastcall FUN_00b924e0(int param_1)

{
  undefined4 uVar1;
  int iStack_8;
  
  if ((DAT_01d67918 == '\0') &&
     (iStack_8 = param_1, FUN_00b97590(&iStack_8,&stack0x00000004),
     iStack_8 != *(int *)(param_1 + 0x1e0))) {
    uVar1 = FUN_00553830(iStack_8);
    FUN_01674ea0(uVar1,0x14);
  }
  return;
}



/* FUNCTION 25361 ; VA 0x00b92530 ; FUN_00b92530 */

void FUN_00b92530(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  bool bVar4;
  int *in_stack_00000020;
  undefined4 in_stack_0000002c;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined auStack_30 [8];
  int iStack_28;
  int *piStack_24;
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017faae8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffb8;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&iStack_28);
  piVar1 = in_stack_00000020;
  uStack_8._0_1_ = 2;
  if (iStack_28 == 0) {
LAB_00b926d2:
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_24[1] + -1;
      piStack_24[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        iVar3 = piStack_24[2] + -1;
        piStack_24[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piStack_24 + 4))();
        }
      }
    }
    if (param_2 == (int *)0x0) goto LAB_00b9270c;
    LOCK();
    piVar1 = param_2 + 2;
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    bVar4 = iVar3 == 1;
  }
  else {
    piStack_1c = in_stack_00000020;
    LOCK();
    DAT_01e90cd4 = DAT_01e90cd4 + 1;
    UNLOCK();
    piStack_18 = in_stack_00000020;
    if (in_stack_00000020 != (int *)0x0) {
      LOCK();
      *in_stack_00000020 = *in_stack_00000020 + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 3;
    if ((in_stack_00000020 == (int *)0x0) || (in_stack_00000020[2] == 0)) {
LAB_00b92694:
      uStack_8._0_1_ = 2;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          FUN_00d88950();
          FUN_01674ea0(piVar1,0x10);
        }
      }
      LOCK();
      DAT_01e90cd4 = DAT_01e90cd4 + -1;
      UNLOCK();
      FUN_00c7cd30(in_stack_0000002c);
      goto LAB_00b926d2;
    }
    iVar3 = *(int *)(iStack_28 + 0x34);
    if ((iVar3 != 0) && (iStack_28 = iVar3, *(int *)(iVar3 + 0x34) != 0)) {
      iStack_28 = FUN_005c8ac0();
    }
    if (((iStack_28 == 0) ||
        (iVar3 = *(int *)(iStack_28 + 0xc), iVar2 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar2 + 0x1da) <
        (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) ||
       (iVar3 = FUN_0055ea10(), iVar3 == 0)) goto LAB_00b92694;
    uStack_3c = 0;
    uStack_38 = 0;
    uStack_34 = 0;
    uStack_8._0_1_ = 5;
    FUN_0094b750(auStack_30,&stack0x0000000c,&uStack_3c);
    FUN_00550b30();
    uStack_8._0_1_ = 6;
    FUN_00577b20();
    FUN_0089b430();
    FUN_00550b30();
    if (param_2 == (int *)0x0) goto LAB_00b9270c;
    LOCK();
    iVar3 = param_2[2] + -1;
    param_2[2] = iVar3;
    bVar4 = iVar3 == 0;
    UNLOCK();
  }
  if (bVar4) {
    (**(code **)(*param_2 + 4))();
  }
LAB_00b9270c:
  FUN_00d88a30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25362 ; VA 0x00b92664 ; Catch@00b92664 */

undefined * Catch_00b92664(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x1c) + 4))();
  FUN_0086f2f0(3,"Unexpected error while invoking callback: %s",uVar1);
  return &DAT_00b92682;
}



/* FUNCTION 25363 ; VA 0x00b92750 ; FUN_00b92750 */

void FUN_00b92750(void)

{
  int iVar1;
  
  iVar1 = FUN_01674e20(0x10);
  *(int *)iVar1 = iVar1;
  *(int *)(iVar1 + 4) = iVar1;
  *(int *)(iVar1 + 8) = iVar1;
  *(undefined2 *)(iVar1 + 0xc) = 0x101;
  return;
}



/* FUNCTION 25364 ; VA 0x00b92770 ; FUN_00b92770 */

void __fastcall FUN_00b92770(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  *puVar1 = *param_1;
  puVar1[1] = *param_1;
  puVar1[2] = *param_1;
  return;
}



/* FUNCTION 25365 ; VA 0x00b92790 ; FUN_00b92790 */

void FUN_00b92790(int param_1)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = *(int **)(param_1 + 0x14);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = piVar1[2] + -1;
    piVar1[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_01674ea0(param_1,0x1c);
  return;
}



/* FUNCTION 25366 ; VA 0x00b927c0 ; FUN_00b927c0 */

void FUN_00b927c0(undefined4 param_1)

{
  FUN_0056c7e0();
  FUN_01674ea0(param_1,0x1c);
  return;
}



/* FUNCTION 25367 ; VA 0x00b927e0 ; FUN_00b927e0 */

void FUN_00b927e0(int *param_1)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_00b927e0(param_1[2]);
    piVar2 = (int *)param_1[5];
    piVar3 = (int *)*param_1;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[2] + -1;
      piVar2[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    FUN_01674ea0(param_1,0x1c);
    param_1 = piVar3;
    cVar1 = *(char *)((int)piVar3 + 0xd);
  }
  return;
}



/* FUNCTION 25368 ; VA 0x00b92830 ; FUN_00b92830 */

void FUN_00b92830(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_00b92830(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_0056c7e0();
    FUN_01674ea0(param_1,0x1c);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 25369 ; VA 0x00b92880 ; FUN_00b92880 */

void FUN_00b92880(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_00b92880(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_01674ea0(param_1,0x10);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 25370 ; VA 0x00b928c0 ; FUN_00b928c0 */

void FUN_00b928c0(undefined4 param_1)

{
  FUN_01674ea0(param_1,0x1c);
  return;
}



/* FUNCTION 25371 ; VA 0x00b928e0 ; FUN_00b928e0 */

void __thiscall FUN_00b928e0(int param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  undefined uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int iVar7;
  int *piVar8;
  int *piVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  undefined auStack_94 [28];
  undefined4 uStack_78;
  undefined auStack_74 [8];
  undefined4 uStack_6c;
  undefined4 uStack_54;
  int *piStack_50;
  int *piStack_4c;
  int *piStack_48;
  int iStack_38;
  int *piStack_34;
  undefined auStack_30 [4];
  int *piStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fab30;
  pvStack_10 = ExceptionList;
  piStack_48 = &param_2;
  uStack_8 = 2;
  piStack_4c = &iStack_38;
  piStack_50 = (int *)0xb92917;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_00a13580();
  uStack_8._0_1_ = 3;
  if (iStack_38 == 0) {
    piStack_4c = (int *)auStack_30;
    piStack_48 = (int *)0x1959cec;
    piStack_50 = (int *)0xb92d21;
    FUN_016756b0();
    piStack_4c = (int *)auStack_30;
    piStack_48 = (int *)&DAT_01c17198;
                    /* WARNING: Subroutine does not return */
    piStack_50 = (int *)0xb92d32;
    FUN_0170c2a8();
  }
  piStack_48 = (int *)iStack_38;
  piStack_4c = &iStack_24;
  piStack_50 = (int *)0xb92933;
  FUN_0060e0c0();
  puVar10 = *(undefined4 **)(param_1 + 0x1d0);
  iStack_1c = param_1 + 0x1d0;
  uStack_8._0_1_ = 4;
  uVar4 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  puVar5 = puVar10;
  puVar11 = (undefined4 *)puVar10[1];
  if (*(char *)((int)puVar10[1] + 0xd) == '\0') {
    do {
      puVar6 = puVar11;
      if ((int *)puVar6[5] < piStack_20) {
        puVar11 = (undefined4 *)puVar6[2];
        puVar6 = puVar5;
      }
      else {
        puVar11 = (undefined4 *)*puVar6;
      }
      puVar5 = puVar6;
    } while (*(char *)((int)puVar11 + 0xd) == '\0');
    if ((puVar6 == puVar10) || (piStack_20 < (int *)puVar6[5])) goto LAB_00b92974;
  }
  else {
LAB_00b92974:
    puVar6 = puVar10;
  }
  if (puVar6 != puVar10) {
    iVar7 = puVar6[6];
    if (iVar7 == 0) {
      piStack_4c = (int *)0xb929d8;
      piStack_48 = puVar6;
      iVar7 = FUN_00553830();
      piVar9 = *(int **)(iVar7 + 0x14);
      if (piVar9 != (int *)0x0) {
        LOCK();
        iVar2 = piVar9[2] + -1;
        piVar9[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          piStack_48 = (int *)0xb929ef;
          (**(code **)(*piVar9 + 4))();
        }
      }
      piStack_48 = (int *)0x1c;
      piStack_50 = (int *)0xb929f7;
      piStack_4c = (int *)iVar7;
      FUN_01674ea0();
    }
    else {
      if (*(int *)(iVar7 + 8) != param_4) {
        piStack_4c = (int *)auStack_30;
        piStack_48 = (int *)0x1959d10;
        piStack_50 = (int *)0xb92d40;
        uStack_8._0_1_ = uVar4;
        FUN_016756b0();
        piStack_4c = (int *)auStack_30;
        piStack_48 = (int *)&DAT_01c17198;
                    /* WARNING: Subroutine does not return */
        piStack_50 = (int *)&UNK_00b92d51;
        FUN_0170c2a8();
      }
      if (iVar7 == *(int *)(param_1 + 0x1c4)) {
        piStack_48 = (int *)0xb929a0;
        FUN_0056c200();
        piStack_48 = (int *)0xb929a8;
        FUN_00550b30();
        piStack_48 = (int *)0xb929b0;
        FUN_00550b30();
        goto LAB_00b92cf0;
      }
      piStack_50 = &param_2;
      uStack_54 = 0xb929c3;
      FUN_00557fc0();
      piStack_50 = (int *)0xb929ca;
      FUN_00b9bcd0();
    }
  }
  piStack_48 = (int *)0x0;
  piStack_4c = (int *)0x0;
  piStack_2c = (int *)0x0;
  uStack_28 = 0;
  piStack_50 = (int *)0xb92a14;
  piVar8 = (int *)FUN_008ed990();
  piStack_48 = (int *)0x50;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  piStack_4c = (int *)0xb92a24;
  piStack_2c = piVar8;
  piVar9 = (int *)FUN_01674e20();
  if (piVar9 == (int *)0x0) {
    piVar9 = (int *)0x0;
    piStack_18 = (int *)0x0;
  }
  else {
    piStack_48 = (int *)0x50;
    piStack_4c = (int *)0x0;
    uStack_54 = 0xb92a3a;
    piStack_50 = piVar9;
    piStack_18 = piVar9;
    FUN_0170d1f0();
    *piVar9 = 0;
    piVar9[1] = 0;
    piVar9[4] = 0;
    piVar9[0xc] = 0;
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piStack_20[2] = piStack_20[2] + 1;
    UNLOCK();
  }
  *piVar9 = iStack_24;
  piVar1 = (int *)piVar9[1];
  piVar9[1] = (int)piStack_20;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar7 = piVar1[2] + -1;
    piVar1[2] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      piStack_48 = (int *)0xb92a8c;
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar9[2] = param_4;
  uStack_78 = 1;
  FUN_00d88580(&stack0x00000010);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piStack_20[2] = piStack_20[2] + 1;
    UNLOCK();
  }
  FUN_00b8dcb0(auStack_74,FUN_00b92530,iStack_24,piStack_20);
  uStack_78 = 0xb92ae5;
  FUN_00b8bbe0();
  uStack_78 = 0;
  FUN_00d88580(&stack0x00000030);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piStack_20[2] = piStack_20[2] + 1;
    UNLOCK();
  }
  FUN_00b8dcb0(auStack_74,FUN_00b92530,iStack_24,piStack_20);
  uStack_78 = 0xb92b38;
  FUN_00b8bbe0();
  piStack_48 = &iStack_24;
  piStack_4c = (int *)0xb92b44;
  puVar10 = (undefined4 *)FUN_00b91810();
  *puVar10 = piVar9;
  iVar7 = iStack_14;
  if (*(int *)(iStack_14 + 0x1c4) == 0) {
LAB_00b92bdb:
    *(int **)(iVar7 + 0x1c4) = piVar9;
    piStack_4c = (int *)0xb92be7;
    piStack_48 = (int *)iVar7;
    FUN_008f7870();
    piStack_48 = (int *)0x1;
    uStack_6c = 0;
    FUN_0054f510(*(int *)(iStack_14 + 0x1c4) + 0x10);
    FUN_00b8da80(auStack_94);
    FUN_00b8b170();
    uStack_6c = 0xb92c28;
    FUN_0090ca30();
    piVar8 = piStack_2c;
  }
  else {
    iVar7 = piVar9[2];
    iVar2 = *(int *)(*(int *)(iStack_14 + 0x1c4) + 8);
    if ((iVar2 < iVar7) || (((iVar2 <= iVar7 && (iVar7 != 1)) && (iVar7 - 2U < 3)))) {
      piStack_48 = (int *)iStack_14;
      piStack_4c = (int *)0xb92b85;
      FUN_008f7870();
      piStack_48 = (int *)0x1;
      uStack_6c = 0;
      FUN_0054f510(*(int *)(iStack_14 + 0x1c4) + 0x30);
      FUN_00b8da80(auStack_94);
      FUN_00b8b170();
      uStack_6c = 0xb92bc6;
      FUN_0090ca30();
      iVar7 = iStack_14;
      piStack_48 = (int *)0x1;
      piStack_4c = *(int **)(iStack_14 + 0x1c4);
      piStack_50 = (int *)0xb92bd8;
      FUN_00b9bc10();
      piVar9 = piStack_18;
      goto LAB_00b92bdb;
    }
    piStack_48 = (int *)0x0;
    piStack_50 = (int *)0xb92b7a;
    piStack_4c = piVar9;
    FUN_00b9bc10();
  }
  piVar9 = (int *)*piVar8;
  *piVar8 = (int)piVar8;
  uStack_8._0_1_ = 4;
  piVar8[1] = (int)piVar8;
  while (piVar9 != piVar8) {
    piVar1 = (int *)*piVar9;
    uVar3 = piVar9[2];
    uStack_8._0_1_ = 6;
    if (uVar3 != 0) {
      if ((uVar3 & 1) == 0) {
        piStack_50 = piVar9 + 4;
        if (*(code **)(uVar3 & 0xfffffffe) != (code *)0x0) {
          piStack_48 = (int *)0x2;
          uStack_54 = 0xb92c63;
          piStack_4c = piStack_50;
          (**(code **)(uVar3 & 0xfffffffe))();
        }
      }
      piVar9[2] = 0;
    }
    piStack_48 = (int *)0x28;
    uStack_8._0_1_ = 4;
    piStack_50 = (int *)0xb92c79;
    piStack_4c = piVar9;
    FUN_01674ea0();
    piVar9 = piVar1;
  }
  piStack_48 = (int *)0x28;
  piStack_50 = (int *)0xb92c8a;
  piStack_4c = piVar8;
  FUN_01674ea0();
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_20[2] + -1;
    piStack_20[2] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      piStack_48 = (int *)0xb92ca5;
      (**(code **)(*piStack_20 + 4))();
    }
  }
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar7 = piStack_34[1] + -1;
    piStack_34[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      piStack_48 = (int *)0xb92cbb;
      (**(code **)*piStack_34)();
      LOCK();
      iVar7 = piStack_34[2] + -1;
      piStack_34[2] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        piStack_48 = (int *)0xb92ccb;
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  piVar9 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar7 = param_3[1] + -1;
    param_3[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      piStack_48 = (int *)0xb92ce1;
      (**(code **)*param_3)();
      LOCK();
      piVar8 = piVar9 + 2;
      iVar7 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        piStack_48 = (int *)0xb92cf0;
        (**(code **)(*piVar9 + 4))();
      }
    }
  }
LAB_00b92cf0:
  piStack_48 = (int *)0xb92cf8;
  FUN_00d88a30();
  piStack_48 = (int *)0xb92d00;
  FUN_00d88a30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25372 ; VA 0x00b92d60 ; FUN_00b92d60 */

void __thiscall FUN_00b92d60(int param_1,char *param_2)

{
  char *pcVar1;
  int *piVar2;
  uint uVar3;
  int in_stack_00000014;
  uint in_stack_00000018;
  undefined auStack_20 [4];
  undefined auStack_1c [4];
  undefined auStack_18 [7];
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (DAT_01d6e86c == '\0') {
    if (in_stack_00000014 != 1) {
      ExceptionList = &pvStack_10;
      FUN_016756b0(auStack_20,"GuiService:AddKey requires a string with a single character");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_20,&DAT_01c17198);
    }
    pcVar1 = (char *)&param_2;
    if (0xf < in_stack_00000018) {
      pcVar1 = param_2;
    }
    ExceptionList = &pvStack_10;
    uStack_11 = FUN_01725677((int)*pcVar1);
    piVar2 = (int *)FUN_00b97540(auStack_18,&uStack_11);
    if (*piVar2 == *(int *)(param_1 + 0x1d8)) {
      FUN_00b8cfc0(auStack_1c,0,&uStack_11,in_stack_00000018);
    }
    FUN_005507b0();
  }
  else if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    pcVar1 = param_2;
    if (0xfff < uVar3) {
      pcVar1 = *(char **)(param_2 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if ((char *)0x1f < param_2 + (-4 - (int)pcVar1)) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0(pcVar1,uVar3);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25373 ; VA 0x00b92e70 ; FUN_00b92e70 */

int __thiscall FUN_00b92e70(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fab48;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_0060e0c0(auStack_18,param_2);
  puVar3 = *(undefined4 **)(param_1 + 0x1bc);
  uStack_8 = 0;
  if (*(undefined4 **)(param_1 + 0x1c0) == puVar3) {
    iVar5 = FUN_006ce750(puVar3,puVar4);
  }
  else {
    *puVar3 = 0;
    puVar3[1] = 0;
    *puVar3 = *puVar4;
    iVar5 = puVar4[1];
    puVar3[1] = iVar5;
    *puVar4 = 0;
    puVar4[1] = 0;
    *(int *)(param_1 + 0x1bc) = *(int *)(param_1 + 0x1bc) + 8;
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 2;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)(*piStack_14 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 25374 ; VA 0x00b92f10 ; FUN_00b92f10 */

int __thiscall FUN_00b92f10(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  int iVar7;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  int *in_stack_00000020;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fab80;
  pvStack_10 = ExceptionList;
  iVar7 = param_1 + 0x155 + (uint)*(byte *)(param_1 + 0x154);
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_0055c740(iVar7,&param_2);
  FUN_00562fc0(&iStack_14,uVar4,&param_2,-(uint)(iVar7 != 0) & iVar7 + 1U);
  if (iStack_14 != 0) {
    puVar5 = &param_2;
    if (0xf < in_stack_00000018) {
      puVar5 = param_2;
    }
    FUN_0086f2f0(2,
                 "GuiService:AddSelectionTuple already has selection group with name %s, overwriting selection group."
                 ,puVar5);
    FUN_0054ef60(&param_2);
    FUN_00b9c250();
  }
  uStack_28 = 0;
  piStack_24 = (int *)0x0;
  uStack_18 = 0;
  iStack_14 = 0;
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    in_stack_00000020[1] = in_stack_00000020[1] + 1;
    UNLOCK();
  }
  uStack_20 = in_stack_0000001c;
  piStack_1c = in_stack_00000020;
  puVar5 = &uStack_28;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00b91910(&param_2);
  iVar7 = FUN_00b56bf0(puVar5);
  piVar2 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_1c + 1;
    iVar3 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar7 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar7 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_24 + 2;
    iVar3 = *piVar2;
    iVar7 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar7 = (**(code **)(*piStack_24 + 4))();
    }
  }
  if (0xf < in_stack_00000018) {
    uVar6 = in_stack_00000018 + 1;
    puVar5 = param_2;
    if (0xfff < uVar6) {
      puVar5 = (undefined4 *)param_2[-1];
      uVar6 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar7 = FUN_01674ea0(puVar5,uVar6);
  }
  piVar2 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = (undefined4 *)((uint)param_2 & 0xffffff00);
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000020 + 1;
    iVar3 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar7 = (**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar7 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 25375 ; VA 0x00b930c0 ; FUN_00b930c0 */

int FUN_00b930c0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  int *piVar7;
  int iVar8;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  int in_stack_0000001c;
  int *in_stack_00000020;
  int iStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  byte *pbStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar8 = in_stack_0000001c;
  puStack_c = &LAB_017fabb8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (in_stack_0000001c != 0) {
    iVar2 = *(int *)(in_stack_0000001c + 0xc);
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00c6de80();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) goto LAB_00b93114;
  }
  iVar8 = 0;
LAB_00b93114:
  FUN_0060dcd0(&iStack_28,iVar8);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iStack_28 == 0) {
    puVar5 = &param_1;
    if (0xf < in_stack_00000018) {
      puVar5 = param_1;
    }
    iVar8 = FUN_0086f2f0(3,
                         "GuiService:AddSelectionParent for group name %s: parent is not a GuiObject."
                         ,puVar5);
    piVar7 = piStack_24;
  }
  else {
    pbStack_18 = (byte *)(iStack_14 + 0x154);
    iVar8 = iStack_14 + 0x155 + (uint)*pbStack_18;
    uVar4 = FUN_0055c740(iVar8,&param_1);
    FUN_00562fc0(&iStack_1c,uVar4,&param_1,-(uint)(iVar8 != 0) & iVar8 + 1U);
    if (iStack_1c != 0) {
      puVar5 = &param_1;
      if (0xf < in_stack_00000018) {
        puVar5 = param_1;
      }
      FUN_0086f2f0(2,
                   "GuiService:AddSelectionParent already has selection group with name %s, overwriting selection group."
                   ,puVar5);
      FUN_0054ef60(&param_1);
      FUN_00b9c250();
    }
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[2] = piStack_24[2] + 1;
      UNLOCK();
    }
    iStack_38 = iStack_28;
    piStack_34 = piStack_24;
    uStack_30 = 0;
    piStack_2c = (int *)0x0;
    uStack_20 = 0;
    iStack_1c = 0;
    piVar7 = &iStack_38;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_00b91910(&param_1);
    iVar8 = FUN_00b56bf0(piVar7);
    piVar7 = piStack_2c;
    if (piStack_2c != (int *)0x0) {
      LOCK();
      piVar1 = piStack_2c + 1;
      iVar2 = *piVar1;
      iVar8 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar2 = *piVar1;
        iVar8 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          iVar8 = (**(code **)(*piVar7 + 4))();
        }
      }
    }
    piVar7 = piStack_24;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_34 + 2;
      iVar2 = *piVar1;
      iVar8 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar8 = (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  if (piVar7 != (int *)0x0) {
    LOCK();
    piVar1 = piVar7 + 1;
    iVar2 = *piVar1;
    iVar8 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar7)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar2 = *piVar1;
      iVar8 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar8 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000018) {
    uVar6 = in_stack_00000018 + 1;
    puVar5 = param_1;
    if (0xfff < uVar6) {
      puVar5 = (undefined4 *)param_1[-1];
      uVar6 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar8 = FUN_01674ea0(puVar5,uVar6);
  }
  piVar7 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = (undefined4 *)((uint)param_1 & 0xffffff00);
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000020 + 1;
    iVar2 = *piVar1;
    iVar8 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar8 = (**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar7 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar8 = (**(code **)(*piVar7 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 25376 ; VA 0x00b932f0 ; FUN_00b932f0 */

void FUN_00b932f0(undefined4 *param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  uint uVar3;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fabe0;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_14 = 0;
  puVar1 = &param_1;
  if (0xf < in_stack_00000018) {
    puVar1 = param_1;
  }
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_005542c0(puVar1,in_stack_00000014);
  uStack_14 = in_stack_0000001c;
  FUN_005e6780(auStack_2c);
  if (0xf < uStack_18) {
    uVar2 = uStack_18 + 1;
    uVar3 = auStack_2c[0];
    if (0xfff < uVar2) {
      uVar3 = *(uint *)(auStack_2c[0] - 4);
      uVar2 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar2);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    puVar1 = param_1;
    if (0xfff < uVar3) {
      puVar1 = (undefined4 *)param_1[-1];
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar1,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25377 ; VA 0x00b933f0 ; FUN_00b933f0 */

void FUN_00b933f0(undefined4 param_1,code *param_2,undefined4 param_3,uint *param_4,uint *param_5)

{
  uint uVar1;
  uint *puVar2;
  uint *puVar3;
  uint uStack_a8;
  uint uStack_a4;
  uint uStack_a0;
  uint uStack_9c;
  undefined8 uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_7c;
  uint *puStack_78;
  uint *puStack_74;
  undefined4 uStack_70;
  uint auStack_6c [2];
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined8 uStack_54;
  uint uStack_3c;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  code *pcStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fac00;
  pvStack_10 = ExceptionList;
  puStack_18 = (undefined *)auStack_6c;
  puStack_1c = (undefined *)auStack_6c;
  pcStack_14 = param_2;
  param_1 = CONCAT31(param_1._1_3_,DAT_01ef22f0);
  auStack_6c[0] = 0;
  uVar1 = *param_5;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_6c;
  puVar3 = auStack_6c;
  if (uVar1 != 0) {
    auStack_6c[0] = uVar1;
    if ((uVar1 & 1) == 0) {
      puStack_74 = &uStack_64;
      uStack_70 = 0;
      puStack_78 = param_5 + 2;
      uStack_7c = 0xb93467;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar1 & 0xfffffffe))();
      puVar2 = (uint *)puStack_1c;
      puVar3 = (uint *)puStack_18;
    }
    else {
      uStack_64 = param_5[2];
      uStack_60 = param_5[3];
      uStack_5c = param_5[4];
      uStack_58 = param_5[5];
      uStack_54 = *(undefined8 *)(param_5 + 6);
      ExceptionList = &pvStack_10;
      puVar2 = auStack_6c;
      puVar3 = auStack_6c;
    }
  }
  puStack_18 = (undefined *)puVar3;
  puStack_1c = (undefined *)puVar2;
  uStack_8 = 0;
  uStack_90 = param_1;
  uVar1 = *param_4;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_4 + 2);
    }
    else {
      uStack_a8 = param_4[2];
      uStack_a4 = param_4[3];
      uStack_a0 = param_4[4];
      uStack_9c = param_4[5];
      uStack_98 = *(undefined8 *)(param_4 + 6);
    }
  }
  FUN_008bfbf0();
  uStack_90 = 0;
  uStack_8._0_1_ = 1;
  if (uStack_3c != 0) {
    if ((uStack_3c & 1) == 0) {
      (**(code **)(uStack_3c & 0xfffffffe))(&uStack_34,&uStack_a8,0);
    }
    else {
      uStack_a8 = uStack_34;
      uStack_a4 = uStack_30;
      uStack_a0 = uStack_2c;
      uStack_9c = uStack_28;
      uStack_98 = uStack_24;
    }
  }
  FUN_00b8b4d0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_3c != 0) && ((uStack_3c & 1) == 0)) &&
     (*(code **)(uStack_3c & 0xfffffffe) != (code *)0x0)) {
    uStack_90 = 2;
    uStack_98 = CONCAT44(&uStack_34,&uStack_34);
    uStack_9c = 0xb93549;
    (**(code **)(uStack_3c & 0xfffffffe))();
  }
  uStack_8 = 0xffffffff;
  uStack_90 = 0xb93563;
  (*pcStack_14)();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25378 ; VA 0x00b93580 ; FUN_00b93580 */

void FUN_00b93580(undefined4 param_1,int *param_2,uint param_3)

{
  int iVar1;
  undefined uVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  int *piVar6;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  uint in_stack_00000024;
  undefined4 in_stack_00000034;
  uint in_stack_00000038;
  uint in_stack_0000003c;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 *in_stack_00000050;
  ulonglong in_stack_00000054;
  uint in_stack_0000005c;
  undefined4 in_stack_00000064;
  undefined4 in_stack_00000068;
  undefined4 in_stack_0000006c;
  undefined4 in_stack_00000070;
  undefined8 in_stack_00000074;
  uint auStack_138 [2];
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 *puStack_124;
  ulonglong uStack_120;
  uint auStack_118 [2];
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 *puStack_104;
  undefined8 uStack_100;
  undefined auStack_f0 [4];
  int iStack_ec;
  undefined auStack_e8 [200];
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fac5e;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  uStack_100 = 0x1800b935ae;
  ExceptionList = &pvStack_10;
  piStack_18 = (int *)FUN_01674e20();
  if (piStack_18 == (int *)0x0) {
    piVar6 = (int *)0x0;
  }
  else {
    piStack_18[1] = 1;
    piStack_18[2] = 1;
    *piStack_18 = (int)std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
    piStack_18[3] = 0;
    piStack_18[4] = 0;
    piStack_18[5] = 0;
    piVar6 = piStack_18;
  }
  uStack_8._0_1_ = 5;
  uStack_100 = CONCAT44(&param_3,0xb93603);
  piStack_20 = piVar6 + 3;
  piStack_1c = piVar6;
  FUN_005c13e0();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (piVar6[5] == piVar6[4]) {
    uStack_100 = CONCAT44(auStack_f0,piVar6[4]);
    puStack_104 = (undefined4 *)0xb9362e;
    FUN_005ca4f0();
  }
  else {
    uStack_100 = CONCAT44(auStack_f0,0xb9361d);
    FUN_005caf00();
    piVar6[4] = piVar6[4] + 0xd0;
  }
  uStack_8._0_1_ = 7;
  if (iStack_ec != 0) {
    uStack_100 = CONCAT44(auStack_e8,0xb93648);
    (**(code **)(iStack_ec + 8))();
  }
  uStack_8._0_1_ = 5;
  uStack_100 = CONCAT44(&stack0x00000024,0xb9365e);
  FUN_005c13e0();
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (piVar6[5] == piVar6[4]) {
    uStack_100 = CONCAT44(auStack_f0,piVar6[4]);
    puStack_104 = (undefined4 *)0xb93689;
    FUN_005ca4f0();
  }
  else {
    uStack_100 = CONCAT44(auStack_f0,0xb93678);
    FUN_005caf00();
    piVar6[4] = piVar6[4] + 0xd0;
  }
  uStack_8._0_1_ = 9;
  if (iStack_ec != 0) {
    uStack_100 = CONCAT44(auStack_e8,0xb936a3);
    (**(code **)(iStack_ec + 8))();
  }
  piStack_18 = (int *)auStack_118;
  puStack_14 = (undefined *)auStack_118;
  uStack_8._0_1_ = 5;
  auStack_118[0] = 0;
  puVar3 = auStack_118;
  if (in_stack_0000005c != 0) {
    auStack_118[0] = in_stack_0000005c;
    if ((in_stack_0000005c & 1) == 0) {
      uStack_120 = ZEXT48(&uStack_110);
      puStack_124 = &stack0x00000064;
      uStack_128 = 0xb936ee;
      (**(code **)(in_stack_0000005c & 0xfffffffe))();
      puVar3 = (uint *)piStack_18;
    }
    else {
      uStack_110 = in_stack_00000064;
      uStack_10c = in_stack_00000068;
      uStack_108 = in_stack_0000006c;
      puStack_104 = (undefined4 *)in_stack_00000070;
      uStack_100 = in_stack_00000074;
      puVar3 = auStack_118;
    }
  }
  piStack_18 = (int *)puVar3;
  puStack_14 = (undefined *)auStack_138;
  uStack_8._0_1_ = 10;
  auStack_138[0] = 0;
  puVar3 = auStack_138;
  if (in_stack_0000003c != 0) {
    auStack_138[0] = in_stack_0000003c;
    if ((in_stack_0000003c & 1) == 0) {
      (**(code **)(in_stack_0000003c & 0xfffffffe))(&stack0x00000044,&uStack_130,0);
      puVar3 = (uint *)puStack_14;
    }
    else {
      uStack_130 = in_stack_00000044;
      uStack_12c = in_stack_00000048;
      uStack_128 = in_stack_0000004c;
      puStack_124 = in_stack_00000050;
      uStack_120 = in_stack_00000054;
      puVar3 = auStack_138;
    }
  }
  puStack_14 = (undefined *)puVar3;
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar6[1] = piVar6[1] + 1;
    UNLOCK();
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    param_2[1] = param_2[1] + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_00f50180(param_1,param_2,piVar6 + 3,piVar6);
  if (piVar6 != (int *)0x0) {
    LOCK();
    iVar1 = piVar6[1] + -1;
    piVar6[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_100 = CONCAT44(0xb937a2,(undefined4)uStack_100);
      (**(code **)*piVar6)();
      LOCK();
      iVar1 = piVar6[2] + -1;
      piVar6[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_100 = CONCAT44(0xb937b2,(undefined4)uStack_100);
        (**(code **)(*piVar6 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    iVar1 = param_2[1] + -1;
    param_2[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_100 = CONCAT44(0xb937c8,(undefined4)uStack_100);
      (**(code **)*param_2)();
      LOCK();
      piVar6 = param_2 + 2;
      iVar1 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        uStack_100 = CONCAT44(0xb937d7,(undefined4)uStack_100);
        (**(code **)(*param_2 + 4))();
      }
    }
  }
  uStack_8._0_1_ = 2;
  if (0xf < in_stack_00000020) {
    uVar5 = in_stack_00000020 + 1;
    uVar4 = param_3;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(param_3 - 4);
      uVar5 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - uVar4) - 4) {
        uStack_100 = CONCAT44(0xb938d2,(undefined4)uStack_100);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_100 = CONCAT44(uVar5,uVar4);
    puStack_104 = (undefined4 *)0xb9380c;
    FUN_01674ea0();
  }
  in_stack_0000001c = 0;
  in_stack_00000020 = 0xf;
  param_3 = param_3 & 0xffffff00;
  uStack_8._0_1_ = 1;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000038) {
    uVar5 = in_stack_00000038 + 1;
    uVar4 = in_stack_00000024;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(in_stack_00000024 - 4);
      uVar5 = in_stack_00000038 + 0x24;
      if (0x1f < (in_stack_00000024 - uVar4) - 4) {
        uStack_100 = CONCAT44(&UNK_00b938d7,(undefined4)uStack_100);
        uStack_8._0_1_ = uVar2;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_100 = CONCAT44(uVar5,uVar4);
    puStack_104 = (undefined4 *)0xb93856;
    FUN_01674ea0();
  }
  in_stack_00000034 = 0;
  in_stack_00000038 = 0xf;
  in_stack_00000024 = in_stack_00000024 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (in_stack_0000003c != 0) {
    if (((in_stack_0000003c & 1) == 0) &&
       (*(code **)(in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
      puStack_104 = &stack0x00000044;
      uStack_100 = CONCAT44(2,puStack_104);
      uStack_108 = 0xb9388c;
      (**(code **)(in_stack_0000003c & 0xfffffffe))();
    }
    in_stack_0000003c = 0;
  }
  uStack_8 = 0xc;
  if (((in_stack_0000005c != 0) && ((in_stack_0000005c & 1) == 0)) &&
     (*(code **)(in_stack_0000005c & 0xfffffffe) != (code *)0x0)) {
    puStack_104 = &stack0x00000064;
    uStack_100 = CONCAT44(2,puStack_104);
    uStack_108 = 0xb938ba;
    (**(code **)(in_stack_0000005c & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25379 ; VA 0x00b938e0 ; FUN_00b938e0 */

/* WARNING: Removing unreachable block (ram,0x00b9395f) */
/* WARNING: Removing unreachable block (ram,0x00b9397b) */
/* WARNING: Removing unreachable block (ram,0x00b93967) */
/* WARNING: Removing unreachable block (ram,0x00b93a16) */
/* WARNING: Removing unreachable block (ram,0x00b93a1a) */
/* WARNING: Removing unreachable block (ram,0x00b93a23) */

void __thiscall FUN_00b938e0(int param_1,int param_2)

{
  code *pcVar1;
  uint uVar2;
  uint *puVar3;
  uint auStack_54 [2];
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fac88;
  pvStack_10 = ExceptionList;
  puVar3 = (uint *)(*(int *)(param_1 + 0x38) + param_2);
  uStack_14 = *(undefined4 *)(param_1 + 0x44);
  pcVar1 = *(code **)(param_1 + 0x40);
  uStack_8 = 0;
  uVar2 = *puVar3;
  auStack_54[0] = 0;
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    auStack_54[0] = uVar2;
    if ((uVar2 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))(puVar3 + 2,&uStack_4c,0);
    }
    else {
      uStack_4c = puVar3[2];
      uStack_48 = puVar3[3];
      uStack_44 = puVar3[4];
      uStack_40 = puVar3[5];
      uStack_3c = *(undefined8 *)(puVar3 + 6);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_34 = 0;
  uStack_8._0_1_ = 2;
  FUN_00b9e080(puVar3);
  uStack_8._0_1_ = 3;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
    }
    uStack_34 = 0;
  }
  uStack_8._0_1_ = 1;
  if (pcVar1 != (code *)0x0) {
    (*pcVar1)(auStack_54);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((auStack_54[0] != 0) && ((auStack_54[0] & 1) == 0)) &&
     (*(code **)(auStack_54[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_54[0] & 0xfffffffe))(&uStack_4c,&uStack_4c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25380 ; VA 0x00b93a40 ; FUN_00b93a40 */

void __fastcall FUN_00b93a40(int param_1)

{
  undefined4 ****ppppuVar1;
  uint uVar2;
  undefined4 ***apppuStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_18 = 0xf;
  apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  if ((undefined4 ****)(param_1 + 0x120) != apppuStack_2c) {
    ppppuVar1 = apppuStack_2c;
    if (0xf < uStack_18) {
      ppppuVar1 = (undefined4 ****)apppuStack_2c[0];
    }
    FUN_005542c0(ppppuVar1,uStack_1c);
  }
  *(undefined4 *)(param_1 + 0x11c) = 0;
  FUN_0054ef60((undefined4 ****)(param_1 + 0x120));
  FUN_006ecaa0();
  if (0xf < uStack_18) {
    uVar2 = uStack_18 + 1;
    ppppuVar1 = (undefined4 ****)apppuStack_2c[0];
    if (0xfff < uVar2) {
      ppppuVar1 = (undefined4 ****)apppuStack_2c[0][-1];
      uVar2 = uStack_18 + 0x24;
      if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25381 ; VA 0x00b93b20 ; FUN_00b93b20 */

undefined __thiscall FUN_00b93b20(undefined4 param_1,byte *param_2)

{
  int *piVar1;
  byte bVar2;
  int iVar3;
  undefined4 uVar4;
  byte *pbVar5;
  uint uVar6;
  undefined uVar7;
  byte *pbVar8;
  bool bVar9;
  uint in_stack_00000018;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017facb0;
  pvStack_10 = ExceptionList;
  pbVar8 = (byte *)&param_2;
  if (0xf < in_stack_00000018) {
    pbVar8 = param_2;
  }
  uVar7 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_008f7870(param_1);
  FUN_005c4330(&iStack_18,uVar4);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (iStack_18 != 0) {
    pbVar5 = &DAT_0195a0e8;
    do {
      bVar2 = *pbVar8;
      bVar9 = bVar2 < *pbVar5;
      if (bVar2 != *pbVar5) {
LAB_00b93b94:
        uVar6 = -(uint)bVar9 | 1;
        goto LAB_00b93b99;
      }
      if (bVar2 == 0) break;
      bVar2 = pbVar8[1];
      bVar9 = bVar2 < pbVar5[1];
      if (bVar2 != pbVar5[1]) goto LAB_00b93b94;
      pbVar8 = pbVar8 + 2;
      pbVar5 = pbVar5 + 2;
    } while (bVar2 != 0);
    uVar6 = 0;
LAB_00b93b99:
    if (uVar6 == 0) {
      FUN_00f69420();
      uVar7 = 1;
    }
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_14[1] + -1;
    piStack_14[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000018) {
    uVar6 = in_stack_00000018 + 1;
    pbVar8 = param_2;
    if (0xfff < uVar6) {
      pbVar8 = *(byte **)(param_2 + -4);
      uVar6 = in_stack_00000018 + 0x24;
      if ((byte *)0x1f < param_2 + (-4 - (int)pbVar8)) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pbVar8,uVar6);
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 25382 ; VA 0x00b93c20 ; FUN_00b93c20 */

undefined4 * __thiscall
FUN_00b93c20(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017facf1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b96340;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25383 ; VA 0x00b93dc0 ; FUN_00b93dc0 */

undefined4 * __thiscall
FUN_00b93dc0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fad31;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b964b0;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25384 ; VA 0x00b93f60 ; FUN_00b93f60 */

undefined4 * __thiscall
FUN_00b93f60(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fad71;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b96600;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25385 ; VA 0x00b94100 ; FUN_00b94100 */

undefined4 * __thiscall
FUN_00b94100(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fadb1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b96740;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25386 ; VA 0x00b942a0 ; FUN_00b942a0 */

undefined4 * __thiscall
FUN_00b942a0(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fadf1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_00b96880;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25387 ; VA 0x00b94440 ; FUN_00b94440 */

void __fastcall FUN_00b94440(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  if (param_1[1] == 0) {
    *(undefined2 *)(param_1 + 2) = 0;
    puVar1 = (undefined4 *)FUN_01674e20(0x30);
    param_1[1] = puVar1;
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    puVar1[6] = 0;
    puVar1[7] = 0;
    puVar1[8] = 0;
    puVar1[9] = 0;
    *(undefined8 *)(puVar1 + 10) = 0;
    *(undefined *)(param_1 + 2) = 1;
    return;
  }
  if (*(char *)((int)param_1 + 9) != '\0') {
    FUN_00b8e8c0(*param_1,param_1[1] + 8);
    *(undefined *)((int)param_1 + 9) = 0;
  }
  return;
}



/* FUNCTION 25388 ; VA 0x00b944a0 ; FUN_00b944a0 */

void FUN_00b944a0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00b9d9a0();
    *param_2 = uVar3;
    iVar4 = FUN_00b9dc40();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 25389 ; VA 0x00b94500 ; FUN_00b94500 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00b94500(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = thunk_FUN_00b9da50();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ef2734) {
      FUN_016f3809(&DAT_01ef2734);
      if (DAT_01ef2734 == -1) {
        _DAT_01ef2728 = FUN_005c65e0;
        _DAT_01ef272c = FUN_005c65e0;
        _DAT_01ef2730 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ef2734);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01ef2728) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01ef2728;
  }
  return;
}



/* FUNCTION 25390 ; VA 0x00b945c0 ; FUN_00b945c0 */

void FUN_00b945c0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00b9dae0();
    *param_2 = uVar3;
    iVar4 = FUN_00b9dcb0();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 25391 ; VA 0x00b94620 ; FUN_00b94620 */

void FUN_00b94620(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uStack_8;
  
  cVar2 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar2 != '\0') {
    uVar3 = FUN_00b9db90();
    *param_2 = uVar3;
    iVar4 = FUN_00b9dd20();
    iVar1 = param_2[1];
    if (iVar1 == iVar4) {
      param_2[2] = uStack_8;
      return;
    }
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = iVar4;
  }
  return;
}



/* FUNCTION 25392 ; VA 0x00b94680 ; FUN_00b94680 */

void FUN_00b94680(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b9d9a0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25393 ; VA 0x00b946c0 ; FUN_00b946c0 */

void FUN_00b946c0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00b9da50();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25394 ; VA 0x00b94700 ; FUN_00b94700 */

void FUN_00b94700(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b9dae0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25395 ; VA 0x00b94740 ; FUN_00b94740 */

void FUN_00b94740(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b9db90();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25396 ; VA 0x00b94780 ; FUN_00b94780 */

void __thiscall
FUN_00b94780(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ba5;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar3 = *(undefined4 **)(param_1 + 0x40);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_005c9cc0();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar3 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x44);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar3 = &uStack_1bc;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_005c9cc0();
    puVar3 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 4) != 0) {
    uVar4 = uVar4 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x48);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar3 = &uStack_1bc;
    uStack_8 = 9;
    uVar4 = uVar4 | 0x20;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_005c9cc0();
    puVar3 = &uStack_ec;
    uStack_8 = 8;
    uVar4 = uVar4 | 0x10;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 0x20) != 0) {
    uVar4 = uVar4 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 0x10) != 0) {
    uVar4 = uVar4 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar3 = &uStack_35c;
    uStack_8 = 0xd;
    uVar4 = uVar4 | 0x80;
  }
  else {
    uStack_28c = FUN_0088c8c0();
    iStack_288 = 0;
    auStack_284[0] = *puVar3;
    iStack_288 = FUN_005c9cc0();
    puVar3 = &uStack_28c;
    uStack_8 = 0xc;
    uVar4 = uVar4 | 0x40;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar2 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((char)uVar4 < '\0') {
    uVar4 = uVar4 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 0x40) != 0) && (uStack_8 = 0xf, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25397 ; VA 0x00b94b80 ; FUN_00b94b80 */

void __thiscall
FUN_00b94b80(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 uStack_35c;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined4 auStack_284 [50];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ba5;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar3 = *(undefined4 **)(param_1 + 0x40);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_0088c960();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_00630820();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar3 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar1 = FUN_0088c960();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x44);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar3 = &uStack_1bc;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_0088c960();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_00630820();
    puVar3 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c960();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 4) != 0) {
    uVar4 = uVar4 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x48);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar3 = &uStack_1bc;
    uStack_8 = 9;
    uVar4 = uVar4 | 0x20;
  }
  else {
    uStack_ec = FUN_0088c960();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_00630820();
    puVar3 = &uStack_ec;
    uStack_8 = 8;
    uVar4 = uVar4 | 0x10;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c960();
  uVar2 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 0x20) != 0) {
    uVar4 = uVar4 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 0x10) != 0) {
    uVar4 = uVar4 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = *(undefined4 **)(param_1 + 0x4c);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_35c = FUN_00888530();
    iStack_358 = 0;
    puVar3 = &uStack_35c;
    uStack_8 = 0xd;
    uVar4 = uVar4 | 0x80;
  }
  else {
    uStack_28c = FUN_0088c960();
    iStack_288 = 0;
    auStack_284[0] = *puVar3;
    iStack_288 = FUN_00630820();
    puVar3 = &uStack_28c;
    uStack_8 = 0xc;
    uVar4 = uVar4 | 0x40;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c960();
  uVar2 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((char)uVar4 < '\0') {
    uVar4 = uVar4 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  if (((uVar4 & 0x40) != 0) && (uStack_8 = 0xf, iStack_288 != 0)) {
    (**(code **)(iStack_288 + 8))(auStack_284);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25398 ; VA 0x00b94f90 ; FUN_00b94f90 */

void __thiscall FUN_00b94f90(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [204];
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0aa0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_005c13e0(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x44) == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    puVar4 = (undefined4 *)FUN_005c13e0(*(int *)(param_1 + 0x44));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25399 ; VA 0x00b95170 ; FUN_00b95170 */

void __thiscall FUN_00b95170(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd560;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar4 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_005c13e0(iVar1);
    uVar4 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar4;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = *(undefined4 **)(param_1 + 0x44);
  if (puVar5 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar5 = &uStack_28c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    uStack_ec = FUN_0088c8c0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar5;
    iStack_e8 = FUN_005c9cc0();
    puVar5 = &uStack_ec;
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088c8c0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar5);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_e8 != 0)) {
    (**(code **)(iStack_e8 + 8))(auStack_e4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25400 ; VA 0x00b95370 ; FUN_00b95370 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b95370(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  undefined4 *puStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bd560;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar3 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar3;
  iVar2 = *(int *)(param_1 + 0x40);
  if (iVar2 == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_005c13e0(iVar2);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar2 == 0);
  uStack_14 = uVar5;
  uVar3 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar4,uVar3,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_358 != 0) {
      (**(code **)(iStack_358 + 8))(auStack_354);
    }
  }
  uStack_8 = 0xffffffff;
  puVar6 = *(undefined4 **)(param_1 + 0x44);
  if (puVar6 == (undefined4 *)0x0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar6 = &uStack_28c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_0088cbe0();
    puStack_e8 = (undefined4 *)0x0;
    if (puVar6[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar6[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e4 = *puVar6;
    uStack_e0 = puVar6[1];
    if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead3c8)
       && (FUN_016f3809(&DAT_01ead3c8), DAT_01ead3c8 == -1)) {
      DAT_01ead3bc = FUN_0057bbb0;
      _DAT_01ead3c0 = FUN_005880a0;
      DAT_01ead3c4 = FUN_0057d5e0;
      FUN_016f37bf(&DAT_01ead3c8);
    }
    puStack_e8 = &DAT_01ead3bc;
    puVar6 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar3 = FUN_0088cbe0();
  uVar4 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar4,uVar3,puVar6);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, puStack_e8 != (undefined4 *)0x0)) {
    (*(code *)puStack_e8[2])(&uStack_e4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25401 ; VA 0x00b95600 ; FUN_00b95600 */

void __thiscall FUN_00b95600(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [204];
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0aa0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_005c13e0(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x44) == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    puVar4 = (undefined4 *)FUN_006874f0(*(int *)(param_1 + 0x44));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25402 ; VA 0x00b957e0 ; FUN_00b957e0 */

void __thiscall FUN_00b957e0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [204];
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0aa0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_006874f0(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x44) == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    puVar4 = (undefined4 *)FUN_005c13e0(*(int *)(param_1 + 0x44));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25403 ; VA 0x00b959c0 ; FUN_00b959c0 */

void __thiscall
FUN_00b959c0(int param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017e6655;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_006874f0(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  uStack_8 = 0xffffffff;
  puVar4 = *(undefined4 **)(param_1 + 0x44);
  if (puVar4 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    uStack_ec = FUN_00b9d9a0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar4;
    iStack_e8 = FUN_00b9dc40();
    puVar4 = &uStack_ec;
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_00b9d9a0();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 4) != 0) {
    uVar5 = uVar5 & 0xfffffffb;
    uStack_8 = 7;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x48) == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    param_2 = &uStack_1bc;
    uStack_8 = 9;
    uVar5 = uVar5 | 0x20;
  }
  else {
    param_2 = (undefined4 *)FUN_008bc7a0(*(int *)(param_1 + 0x48));
    uStack_8 = 8;
    uVar5 = uVar5 | 0x10;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_00d88470();
  uVar3 = FUN_0086e3d0(param_4);
  FUN_00888b30(uVar3,uVar2,param_2);
  if ((uVar5 & 0x20) != 0) {
    uVar5 = uVar5 & 0xffffffdf;
    uStack_8 = 10;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 0x10) != 0) {
    uVar5 = uVar5 & 0xffffffef;
    uStack_8 = 0xb;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x4c) == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar4 = &uStack_28c;
    uStack_8 = 0xd;
    uVar5 = uVar5 | 0x80;
  }
  else {
    puVar4 = (undefined4 *)FUN_008bc7a0(*(int *)(param_1 + 0x4c));
    uStack_8 = 0xc;
    uVar5 = uVar5 | 0x40;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_00d88470();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((char)uVar5 < '\0') {
    uVar5 = uVar5 & 0xffffff7f;
    uStack_8 = 0xe;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar5 & 0x40) != 0) && (uStack_8 = 0xf, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25404 ; VA 0x00b95d60 ; FUN_00b95d60 */

void __thiscall FUN_00b95d60(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  uint uVar4;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8320;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar1 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar1;
  puVar3 = *(undefined4 **)(param_1 + 0x40);
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar4 = 2;
  }
  else {
    uStack_ec = FUN_00b9db90();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar3;
    iStack_e8 = FUN_00b9dd20();
    puStack_18 = &uStack_ec;
    uVar4 = 1;
  }
  uStack_8 = (uint)(puVar3 == (undefined4 *)0x0);
  uStack_14 = uVar4;
  uVar1 = FUN_00b9db90();
  uVar2 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar2,uVar1,puStack_18);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar4;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar4 & 1) != 0) {
    uVar4 = uVar4 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar4;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x44) == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar3 = &uStack_28c;
    uStack_8 = 5;
    uVar4 = uVar4 | 8;
  }
  else {
    puVar3 = (undefined4 *)FUN_005c13e0(*(int *)(param_1 + 0x44));
    uStack_8 = 4;
    uVar4 = uVar4 | 4;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088cb40();
  uVar2 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uVar4 & 8) != 0) {
    uVar4 = uVar4 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar4 & 4) != 0) && (uStack_8 = 7, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25405 ; VA 0x00b95f60 ; FUN_00b95f60 */

void __thiscall FUN_00b95f60(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [204];
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a0aa0;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  iVar1 = *(int *)(param_1 + 0x40);
  if (iVar1 == 0) {
    uStack_ec = FUN_00888530();
    iStack_e8 = 0;
    puStack_18 = &uStack_ec;
    uVar5 = 2;
  }
  else {
    puStack_18 = (undefined4 *)FUN_005c1470(iVar1);
    uVar5 = 1;
  }
  uStack_8 = (uint)(iVar1 == 0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x44) == 0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puVar4 = &uStack_1bc;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    puVar4 = (undefined4 *)FUN_005c13e0(*(int *)(param_1 + 0x44));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25406 ; VA 0x00b96140 ; FUN_00b96140 */

void __thiscall FUN_00b96140(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iStack_358;
  undefined auStack_354 [200];
  undefined4 uStack_28c;
  int iStack_288;
  undefined auStack_284 [200];
  undefined4 uStack_1bc;
  int iStack_1b8;
  undefined auStack_1b4 [200];
  undefined4 uStack_ec;
  int iStack_e8;
  undefined auStack_e4 [200];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c8320;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_1c = (undefined4 *)(param_1 + 0x24);
  uVar2 = FUN_00888530();
  *(undefined4 *)(param_1 + 0x24) = uVar2;
  puVar1 = *(undefined **)(param_1 + 0x40);
  if (puVar1 == (undefined *)0x0) {
    uStack_1bc = FUN_00888530();
    iStack_1b8 = 0;
    puStack_18 = &uStack_1bc;
    uVar5 = 2;
  }
  else {
    uStack_ec = FUN_0088daf0();
    iStack_e8 = 0;
    auStack_e4[0] = *puVar1;
    iStack_e8 = FUN_005c9ef0();
    puStack_18 = &uStack_ec;
    uVar5 = 1;
  }
  uStack_8 = (uint)(puVar1 == (undefined *)0x0);
  uStack_14 = uVar5;
  uVar2 = FUN_0088daf0();
  uVar3 = FUN_0086e3d0(param_2);
  FUN_00888b30(uVar3,uVar2,puStack_18);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 2;
    uStack_14 = uVar5;
    if (iStack_1b8 != 0) {
      (**(code **)(iStack_1b8 + 8))(auStack_1b4);
    }
  }
  if ((uVar5 & 1) != 0) {
    uVar5 = uVar5 & 0xfffffffe;
    uStack_8 = 3;
    uStack_14 = uVar5;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
  }
  uStack_8 = 0xffffffff;
  if (*(int *)(param_1 + 0x44) == 0) {
    uStack_28c = FUN_00888530();
    iStack_288 = 0;
    puVar4 = &uStack_28c;
    uStack_8 = 5;
    uVar5 = uVar5 | 8;
  }
  else {
    puVar4 = (undefined4 *)FUN_005c13e0(*(int *)(param_1 + 0x44));
    uStack_8 = 4;
    uVar5 = uVar5 | 4;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_3);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uVar5 & 8) != 0) {
    uVar5 = uVar5 & 0xfffffff7;
    uStack_8 = 6;
    uStack_14 = uVar5;
    if (iStack_288 != 0) {
      (**(code **)(iStack_288 + 8))(auStack_284);
    }
  }
  if (((uVar5 & 4) != 0) && (uStack_8 = 7, iStack_358 != 0)) {
    (**(code **)(iStack_358 + 8))(auStack_354);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25407 ; VA 0x00b96340 ; FUN_00b96340 */

void FUN_00b96340(int param_1,uint param_2)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  int in_stack_00000020;
  uint in_stack_00000034;
  undefined auStack_1c0 [416];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017cf8f4;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 2;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  FUN_005c13e0(&param_2);
  uStack_8._0_1_ = 3;
  FUN_005c13e0(&stack0x00000020);
  uStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(auStack_1c0,&uStack_20,piVar1);
  uStack_8._0_1_ = 5;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8._0_1_ = 2;
  FUN_016f32d1(auStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_01675290(uVar3);
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    uVar6 = param_2;
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(param_2 - 4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar5);
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (0xf < in_stack_00000034) {
    uVar6 = in_stack_00000034 + 1;
    iVar4 = in_stack_00000020;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(in_stack_00000020 + -4);
      uVar6 = in_stack_00000034 + 0x24;
      if (0x1f < (in_stack_00000020 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25408 ; VA 0x00b964b0 ; FUN_00b964b0 */

int FUN_00b964b0(int param_1,undefined4 param_2,int *param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  code *pcVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint in_stack_00000024;
  undefined auStack_1c0 [416];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f0124;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar5 = FUN_01675290(DAT_02110da8);
  piVar3 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 2;
  pcVar4 = *(code **)(*piVar3 + 4);
  uStack_20 = uVar5;
  FUN_006874f0(&param_2);
  uStack_8._0_1_ = 3;
  FUN_005c13e0(&param_4);
  uStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(auStack_1c0,&uStack_20,piVar3);
  uStack_8._0_1_ = 5;
  (*pcVar4)(&uStack_1c);
  uStack_8._0_1_ = 6;
  FUN_00577b20();
  uStack_8._0_1_ = 2;
  FUN_016f32d1(auStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  iVar6 = FUN_01675290(uVar5);
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000024) {
    uVar7 = in_stack_00000024 + 1;
    iVar6 = param_4;
    if (0xfff < uVar7) {
      iVar6 = *(int *)(param_4 + -4);
      uVar7 = in_stack_00000024 + 0x24;
      if (0x1f < (param_4 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar6 = FUN_01674ea0(iVar6,uVar7);
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 25409 ; VA 0x00b96600 ; FUN_00b96600 */

void FUN_00b96600(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_00000020;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aa13c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = FUN_00b9dae0();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1bc = FUN_00b9dcb0();
  uStack_8._0_1_ = 2;
  FUN_005c13e0(&param_3);
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  uStack_8._0_1_ = 4;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_01675290(uVar3);
  if (0xf < in_stack_00000020) {
    uVar5 = in_stack_00000020 + 1;
    iVar4 = param_3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_3 + -4);
      uVar5 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25410 ; VA 0x00b96740 ; FUN_00b96740 */

void FUN_00b96740(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_00000020;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined4 uStack_1b8;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aa13c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  uStack_1c0 = FUN_00b9db90();
  uStack_1bc = 0;
  uStack_1b8 = param_2;
  uStack_1bc = FUN_00b9dd20();
  uStack_8._0_1_ = 2;
  FUN_005c13e0(&param_3);
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(&uStack_1c0,&uStack_20,piVar1);
  uStack_8._0_1_ = 4;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(&uStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_01675290(uVar3);
  if (0xf < in_stack_00000020) {
    uVar5 = in_stack_00000020 + 1;
    iVar4 = param_3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_3 + -4);
      uVar5 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25411 ; VA 0x00b96880 ; FUN_00b96880 */

void FUN_00b96880(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_00000024;
  undefined auStack_1c0 [416];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fae3c;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_01675290(DAT_02110da8);
  piVar1 = *(int **)(param_1 + 0x18);
  uStack_8._0_1_ = 1;
  pcVar2 = *(code **)(*piVar1 + 4);
  uStack_20 = uVar3;
  FUN_005c1470(&param_2);
  uStack_8._0_1_ = 2;
  FUN_005c13e0(&param_4);
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687980(auStack_1c0,&uStack_20,piVar1);
  uStack_8._0_1_ = 4;
  (*pcVar2)(&uStack_1c);
  uStack_8._0_1_ = 5;
  FUN_00577b20();
  uStack_8._0_1_ = 1;
  FUN_016f32d1(auStack_1c0,0xd0,2,FUN_0056e5b0);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  FUN_01675290(uVar3);
  if (0xf < in_stack_00000024) {
    uVar5 = in_stack_00000024 + 1;
    iVar4 = param_4;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_4 + -4);
      uVar5 = in_stack_00000024 + 0x24;
      if (0x1f < (param_4 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25412 ; VA 0x00b969b0 ; FUN_00b969b0 */

void FUN_00b969b0(int param_1)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x18) != 0) {
    iVar1 = FUN_00817fa0();
    if (iVar1 != 0) {
      FUN_00d66da0();
      return;
    }
  }
  return;
}



/* FUNCTION 25413 ; VA 0x00b969d0 ; FUN_00b969d0 */

void FUN_00b969d0(int param_1)

{
  undefined4 uVar1;
  uint uVar2;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  int iStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c47f8;
  pvStack_10 = ExceptionList;
  uVar1 = *(undefined4 *)(param_1 + 0x20);
  uStack_3c = 0;
  uVar2 = *(uint *)(param_1 + 0x48);
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_3c = uVar2;
    if ((uVar2 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      iStack_48 = param_1 + 0x50;
      uStack_4c = 0xb96a35;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_34 = *(undefined4 *)(param_1 + 0x50);
      uStack_30 = *(undefined4 *)(param_1 + 0x54);
      uStack_2c = *(undefined4 *)(param_1 + 0x58);
      uStack_28 = *(undefined4 *)(param_1 + 0x5c);
      uStack_24 = *(undefined8 *)(param_1 + 0x60);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar2 = *(uint *)(param_1 + 0x28);
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(param_1 + 0x30,&uStack_54,0);
    }
    else {
      uStack_54 = *(undefined4 *)(param_1 + 0x30);
      uStack_50 = *(undefined4 *)(param_1 + 0x34);
      uStack_4c = *(undefined4 *)(param_1 + 0x38);
      iStack_48 = *(int *)(param_1 + 0x3c);
      uStack_44 = *(ulonglong *)(param_1 + 0x40);
    }
  }
  uStack_8 = 0xffffffff;
  FUN_00b91d20(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25414 ; VA 0x00b96ab0 ; FUN_00b96ab0 */

void FUN_00b96ab0(void)

{
  FUN_0096ca80();
  return;
}



/* FUNCTION 25415 ; VA 0x00b96ac0 ; FUN_00b96ac0 */

void __thiscall FUN_00b96ac0(int *param_1,undefined4 *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  void **ppvVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_1;
  ppvVar3 = &pvStack_10;
  if ((param_3 == (int *)*piVar1) && (ppvVar3 = &pvStack_10, param_4 == piVar1)) {
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_00b927e0(piVar1[1]);
    *(int **)(*param_1 + 4) = piVar1;
    *(int **)*param_1 = piVar1;
    *(int **)(*param_1 + 8) = piVar1;
    param_1[1] = 0;
    *param_2 = *(undefined4 *)*param_1;
    ExceptionList = pvStack_10;
    return;
  }
  while (ExceptionList = ppvVar3, param_3 != param_4) {
    FUN_00551320();
    FUN_00551320();
    iVar4 = FUN_00553830(param_3);
    piVar1 = *(int **)(iVar4 + 0x14);
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    FUN_01674ea0(iVar4,0x1c);
    ppvVar3 = (void **)ExceptionList;
  }
  *param_2 = param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25416 ; VA 0x00b96b90 ; FUN_00b96b90 */

void __thiscall FUN_00b96b90(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint in_stack_0000002c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3d80;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_00b933f0(param_2,*(undefined4 *)(param_1 + 0x38),*(undefined4 *)(param_1 + 0x3c),&param_4,
               &stack0x0000002c);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_4 != 0) {
    if (((param_4 & 1) == 0) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_4 & 0xfffffffe))(&stack0x00000014,&stack0x00000014,2);
    }
    param_4 = 0;
  }
  uStack_8 = 3;
  if (((in_stack_0000002c != 0) && ((in_stack_0000002c & 1) == 0)) &&
     (*(code **)(in_stack_0000002c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000002c & 0xfffffffe))(&stack0x00000034,&stack0x00000034,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25417 ; VA 0x00b96c30 ; FUN_00b96c30 */

undefined4 __thiscall FUN_00b96c30(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined4 uVar4;
  undefined auStack_24 [12];
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179e158;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_3);
  puVar3 = (undefined8 *)FUN_009d16a0(auStack_24,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  uVar4 = (**(code **)(param_1 + 0x38))(auStack_18,*puVar3,*(undefined4 *)(puVar3 + 1));
  uStack_8 = 0;
  uVar4 = FUN_009d5980(param_3,uVar4);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 25418 ; VA 0x00b96cf0 ; FUN_00b96cf0 */

undefined4 __thiscall FUN_00b96cf0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fae5c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = (**(code **)(param_1 + 0x38))();
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ef26f4) {
    FUN_016f3809(&DAT_01ef26f4);
    if (DAT_01ef26f4 == -1) {
      uStack_8 = 0;
      FUN_00e06fb0();
      FUN_016f3654(&LAB_01891220);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ef26f4);
    }
  }
  iVar2 = FUN_009cb050(uVar1);
  if (iVar2 == 0) {
    FUN_01256980(param_3);
  }
  else {
    FUN_00880a00(param_3,iVar2);
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 25419 ; VA 0x00b96dc0 ; FUN_00b96dc0 */

void __thiscall FUN_00b96dc0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  
  uVar1 = (**(code **)(param_1 + 0x38))();
  FUN_009d5650(param_3,uVar1);
  return;
}



/* FUNCTION 25420 ; VA 0x00b96de0 ; FUN_00b96de0 */

undefined4 __thiscall FUN_00b96de0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  iVar1 = FUN_01256300(param_3);
  iVar1 = iVar1 - param_4;
  uVar2 = FUN_009d05b0(param_3,param_4,4,iVar1,param_1 + 0x4c);
  uVar3 = FUN_009d05b0(param_3,param_4,3,iVar1,param_1 + 0x48);
  uVar4 = FUN_009d05b0(param_3,param_4,2,iVar1,param_1 + 0x44);
  uVar5 = FUN_009d05b0(param_3,param_4,1,iVar1,param_1 + 0x40);
  (**(code **)(param_1 + 0x38))(uVar5,uVar4,uVar3,uVar2);
  return 0;
}



/* FUNCTION 25421 ; VA 0x00b96e80 ; FUN_00b96e80 */

undefined4 __thiscall FUN_00b96e80(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  float10 fVar2;
  float10 fVar3;
  float10 fVar4;
  float10 fVar5;
  
  iVar1 = FUN_01256300(param_3);
  iVar1 = iVar1 - param_4;
  fVar2 = (float10)FUN_009d0730(param_3,param_4,4,iVar1,param_1 + 0x4c);
  fVar3 = (float10)FUN_009d0730(param_3,param_4,3,iVar1,param_1 + 0x48);
  fVar4 = (float10)FUN_009d0730(param_3,param_4,2,iVar1,param_1 + 0x44);
  fVar5 = (float10)FUN_009d0730(param_3,param_4,1,iVar1,param_1 + 0x40);
  (**(code **)(param_1 + 0x38))((float)fVar5,(float)fVar4,(float)fVar3,(float)fVar2);
  return 0;
}



/* FUNCTION 25422 ; VA 0x00b96f40 ; FUN_00b96f40 */

undefined4 FUN_00b96f40(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined auStack_1c [4];
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fae88;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300();
  iVar4 = FUN_009d0b50(auStack_1c,param_2,param_3,2,iVar3 - param_3);
  uStack_8 = 0;
  uVar5 = FUN_009d09d0(auStack_34,param_2,param_3,1,iVar3 - param_3,iStack_14 + 0x40);
  pcVar2 = *(code **)(iStack_14 + 0x38);
  if (*(int *)(iVar4 + 4) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar4 + 4) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 2;
  FUN_0054ef60(uVar5);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  (*pcVar2)();
  if (0xf < uStack_20) {
    uVar7 = uStack_20 + 1;
    uVar6 = auStack_34[0];
    if (0xfff < uVar7) {
      uVar6 = *(uint *)(auStack_34[0] - 4);
      uVar7 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar7);
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piStack_18 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 25423 ; VA 0x00b97090 ; FUN_00b97090 */

undefined4 FUN_00b97090(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  code *pcVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_44 [36];
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017faec0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_01256300();
  uStack_18 = FUN_009d1820();
  uStack_8 = 0;
  uStack_1c = FUN_009d1820(auStack_44,param_2,param_3,3,iVar4 - param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (1 < iVar4 - param_3) {
    FUN_00b9d9a0();
    cVar3 = FUN_009d1e20();
    if (cVar3 != '\0') goto LAB_00b9713e;
  }
  param_2 = FUN_00b8edf0();
LAB_00b9713e:
  puVar5 = (undefined4 *)FUN_009d1340();
  uStack_8._0_1_ = 2;
  pcVar2 = *(code **)(iStack_14 + 0x38);
  FUN_00d88580(uStack_18);
  uStack_8._0_1_ = 3;
  FUN_00d88580(uStack_1c);
  if (puVar5[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar5[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  (*pcVar2)(*puVar5,puVar5[1],param_2);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_20[1] + -1;
    piStack_20[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_20)();
      LOCK();
      piVar1 = piStack_20 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
  }
  FUN_00d88a30();
  FUN_00d88a30();
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 25424 ; VA 0x00b97210 ; FUN_00b97210 */

undefined4 __thiscall FUN_00b97210(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  
  uVar1 = param_3;
  iVar3 = FUN_01256300(param_3);
  iVar3 = iVar3 - param_4;
  if (0 < iVar3) {
    uVar4 = FUN_00b9dae0();
    cVar2 = FUN_009d1e20(uVar4,uVar1,param_4 + 1,&param_3);
    uVar4 = param_3;
    if (cVar2 != '\0') goto LAB_00b97266;
  }
  uVar4 = FUN_00b8eff0(uVar1,param_4,1,iVar3,param_1 + 0x40);
LAB_00b97266:
  (**(code **)(param_1 + 0x38))(uVar4);
  return 0;
}



/* FUNCTION 25425 ; VA 0x00b97280 ; FUN_00b97280 */

undefined4 FUN_00b97280(undefined4 param_1,undefined4 param_2,int param_3)

{
  code *pcVar1;
  undefined4 uVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  int aiStack_30 [5];
  uint uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_01256300(param_2);
  iVar4 = iVar4 - param_3;
  uStack_18 = FUN_009d09d0(aiStack_30,uVar2,param_3,2,iVar4,iStack_14 + 0x44);
  uStack_8 = 0;
  if (0 < iVar4) {
    uVar5 = FUN_00b9db90();
    cVar3 = FUN_009d1e20(uVar5,uVar2,param_3 + 1,&param_2);
    uVar5 = param_2;
    if (cVar3 != '\0') goto LAB_00b9730e;
  }
  uVar5 = FUN_00b8f1f0(uVar2,param_3,1,iVar4,iStack_14 + 0x40);
LAB_00b9730e:
  pcVar1 = *(code **)(iStack_14 + 0x38);
  param_3 = uVar5;
  FUN_0054ef60(uStack_18);
  (*pcVar1)(param_3);
  if (0xf < uStack_1c) {
    uVar6 = uStack_1c + 1;
    iVar4 = aiStack_30[0];
    if (0xfff < uVar6) {
      iVar4 = *(int *)(aiStack_30[0] + -4);
      uVar6 = uStack_1c + 0x24;
      if (0x1f < (aiStack_30[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 25426 ; VA 0x00b97380 ; FUN_00b97380 */

undefined4 FUN_00b97380(undefined4 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  undefined8 uVar3;
  int aiStack_4c [5];
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  code *pcStack_28;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  
  puStack_20 = &stack0xfffffffc;
  uStack_14 = 0xffffffff;
  puStack_18 = &LAB_01794d38;
  pvStack_1c = ExceptionList;
  ExceptionList = &pvStack_1c;
  iVar1 = FUN_01256300(param_2);
  uStack_2c = FUN_009d09d0(aiStack_4c,param_2,param_3,2,iVar1 - param_3,(int)pcStack_28 + 0x44);
  uStack_14 = 0;
  uVar3 = FUN_009d1940(param_2,param_3,1,iVar1 - param_3,(int)pcStack_28 + 0x40);
  uStack_30 = (undefined4)uVar3;
  pcStack_28 = *(code **)((int)pcStack_28 + 0x38);
  FUN_0054ef60(uStack_2c);
  (*pcStack_28)(uStack_30,(int)((ulonglong)uVar3 >> 0x20));
  if (0xf < uStack_38) {
    uVar2 = uStack_38 + 1;
    iVar1 = aiStack_4c[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_4c[0] + -4);
      uVar2 = uStack_38 + 0x24;
      if (0x1f < (aiStack_4c[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_1c;
  return 0;
}



/* FUNCTION 25427 ; VA 0x00b97470 ; FUN_00b97470 */

undefined4 FUN_00b97470(undefined4 param_1,undefined4 param_2,int param_3)

{
  code *pcVar1;
  undefined uVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  int aiStack_2c [5];
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_01256300(param_2);
  uVar4 = FUN_009d09d0(aiStack_2c,param_2,param_3,2,iVar3 - param_3,iStack_14 + 0x44);
  uStack_8 = 0;
  uVar2 = FUN_009d1aa0(param_2,param_3,1,iVar3 - param_3,iStack_14 + 0x40);
  pcVar1 = *(code **)(iStack_14 + 0x38);
  FUN_0054ef60(uVar4);
  (*pcVar1)(uVar2);
  if (0xf < uStack_18) {
    uVar5 = uStack_18 + 1;
    iVar3 = aiStack_2c[0];
    if (0xfff < uVar5) {
      iVar3 = *(int *)(aiStack_2c[0] + -4);
      uVar5 = uStack_18 + 0x24;
      if (0x1f < (aiStack_2c[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 25428 ; VA 0x00b97540 ; FUN_00b97540 */

void __thiscall FUN_00b97540(int *param_1,int *param_2,char *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar1 = (undefined4 *)*param_1;
  if (*(char *)((int)puVar1[1] + 0xd) == '\0') {
    puVar2 = (undefined4 *)puVar1[1];
    puVar4 = puVar1;
    do {
      if (*(char *)((int)puVar2 + 0xe) < *param_3) {
        puVar3 = (undefined4 *)puVar2[2];
      }
      else {
        puVar3 = (undefined4 *)*puVar2;
        puVar4 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((int)puVar3 + 0xd) == '\0');
    if ((puVar4 != puVar1) && (*(char *)((int)puVar4 + 0xe) <= *param_3)) {
      *param_2 = (int)puVar4;
      return;
    }
  }
  *param_2 = (int)puVar1;
  return;
}



/* FUNCTION 25429 ; VA 0x00b97590 ; FUN_00b97590 */

void __thiscall FUN_00b97590(int *param_1,int *param_2,int *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar1 = (undefined4 *)*param_1;
  if (*(char *)((int)puVar1[1] + 0xd) == '\0') {
    puVar2 = (undefined4 *)puVar1[1];
    puVar4 = puVar1;
    do {
      if ((int)puVar2[4] < *param_3) {
        puVar3 = (undefined4 *)puVar2[2];
      }
      else {
        puVar3 = (undefined4 *)*puVar2;
        puVar4 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((int)puVar3 + 0xd) == '\0');
    if ((puVar4 != puVar1) && ((int)puVar4[4] <= *param_3)) {
      *param_2 = (int)puVar4;
      return;
    }
  }
  *param_2 = (int)puVar1;
  return;
}



/* FUNCTION 25430 ; VA 0x00b975e0 ; FUN_00b975e0 */

void FUN_00b975e0(undefined4 param_1,undefined4 param_2)

{
  FUN_00b8eca0(param_1,param_2,param_2);
  return;
}



/* FUNCTION 25431 ; VA 0x00b97600 ; FUN_00b97600 */

/* WARNING: Removing unreachable block (ram,0x00b976cc) */
/* WARNING: Removing unreachable block (ram,0x00b976da) */
/* WARNING: Removing unreachable block (ram,0x00b9771a) */
/* WARNING: Removing unreachable block (ram,0x00b976ea) */

void FUN_00b97600(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_2;
  iVar2 = *piVar1;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00b9dae0();
  if (iVar2 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  piVar4 = piVar1 + 2;
  if (piVar1[1] == 0) {
    piVar4 = (int *)0x0;
  }
  iVar2 = *piVar4;
  iVar3 = *(int *)(*param_2 + 0xd0);
  iVar5 = FUN_0088cb40();
  if (iVar3 != iVar5) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  FUN_0054ef60();
  uStack_8 = 0;
  FUN_006ecd90(iVar2,uStack_30,uStack_2c,uStack_28,uStack_24,CONCAT44(uStack_1c,uStack_20));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25432 ; VA 0x00b97720 ; FUN_00b97720 */

/* WARNING: Removing unreachable block (ram,0x00b977ec) */
/* WARNING: Removing unreachable block (ram,0x00b977fa) */
/* WARNING: Removing unreachable block (ram,0x00b9783a) */
/* WARNING: Removing unreachable block (ram,0x00b9780a) */

void FUN_00b97720(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_2;
  iVar2 = *piVar1;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_00b9db90();
  if (iVar2 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  piVar4 = piVar1 + 2;
  if (piVar1[1] == 0) {
    piVar4 = (int *)0x0;
  }
  iVar2 = *piVar4;
  iVar3 = *(int *)(*param_2 + 0xd0);
  iVar5 = FUN_0088cb40();
  if (iVar3 != iVar5) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  FUN_0054ef60();
  uStack_8 = 0;
  FUN_006ecd90(iVar2,uStack_30,uStack_2c,uStack_28,uStack_24,CONCAT44(uStack_1c,uStack_20));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25433 ; VA 0x00b97840 ; FUN_00b97840 */

/* WARNING: Removing unreachable block (ram,0x00b97915) */
/* WARNING: Removing unreachable block (ram,0x00b97923) */
/* WARNING: Removing unreachable block (ram,0x00b97963) */
/* WARNING: Removing unreachable block (ram,0x00b97933) */

void FUN_00b97840(undefined4 param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795d48;
  pvStack_10 = ExceptionList;
  piVar1 = (int *)*param_2;
  iVar2 = *piVar1;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_0088da50();
  if (iVar2 != iVar4) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  piVar5 = piVar1 + 2;
  if (piVar1[1] == 0) {
    piVar5 = (int *)0x0;
  }
  iVar2 = *piVar5;
  iVar4 = piVar5[1];
  iVar3 = *(int *)(*param_2 + 0xd0);
  iVar6 = FUN_0088cb40();
  if (iVar3 != iVar6) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0();
  }
  FUN_0054ef60();
  uStack_8 = 0;
  FUN_00b92030(iVar2,iVar4,uStack_34,uStack_30,uStack_2c,uStack_28,CONCAT44(uStack_20,uStack_24));
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25434 ; VA 0x00b97970 ; FUN_00b97970 */

void FUN_00b97970(undefined param_1)

{
  DAT_01ef1770 = param_1;
  return;
}



/* FUNCTION 25435 ; VA 0x00b979f0 ; FUN_00b979f0 */

int * __thiscall FUN_00b979f0(int param_1,int *param_2,float param_3,float param_4,float param_5)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  uint uVar5;
  int *piVar6;
  float fVar7;
  double dVar8;
  float fVar9;
  float fVar10;
  undefined uVar11;
  undefined auStack_6c [4];
  int *piStack_68;
  int iStack_64;
  int *piStack_60;
  int iStack_5c;
  int *piStack_58;
  int *piStack_54;
  int *piStack_50;
  undefined4 uStack_4c;
  int *piStack_48;
  undefined4 uStack_44;
  int *piStack_40;
  undefined4 uStack_3c;
  int *piStack_38;
  undefined4 uStack_34;
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  float fStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017faf09;
  pvStack_10 = ExceptionList;
  fStack_24 = DAT_018e0028;
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  param_2[1] = 0;
  uStack_8 = 0;
  uVar4 = 1;
  uStack_14 = 1;
  if (param_1 != 0) {
    iStack_18 = *(int *)(param_1 + 0x34);
    iVar1 = param_1;
    if ((iStack_18 != 0) && (iVar1 = iStack_18, *(int *)(iStack_18 + 0x34) != 0)) {
      iVar1 = FUN_005c8ac0();
    }
    iStack_18 = iVar1;
    if (((iStack_18 != 0) &&
        (iVar1 = *(int *)(iStack_18 + 0xc), iVar2 = FUN_008a8c30(),
        (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da))) && (iVar1 = FUN_00899040(), iVar1 != 0)) {
      uVar11 = 0;
      FUN_005542c0("Dialog",6);
      FUN_00d130d0(&piStack_54,uVar11);
      uStack_8 = 1;
      if ((piStack_54 != (int *)0x0) &&
         (piVar6 = (int *)*piStack_54, piVar6 != (int *)piStack_54[1])) {
        do {
          if ((*piVar6 == 0) ||
             (iVar1 = *(int *)(*piVar6 + 0xc), iVar2 = FUN_00dd5b30(),
             (uint)*(ushort *)(iVar2 + 0x1da) <
             (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) {
            uVar5 = uVar4 | 4;
            piStack_30 = (int *)0x0;
            puVar3 = &uStack_34;
            iStack_18 = 0;
          }
          else {
            piStack_38 = (int *)piVar6[1];
            iStack_18 = *piVar6;
            if (piStack_38 != (int *)0x0) {
              LOCK();
              piStack_38[1] = piStack_38[1] + 1;
              UNLOCK();
              piStack_38 = (int *)piVar6[1];
            }
            uVar5 = uVar4 | 2;
            puVar3 = &uStack_3c;
          }
          uVar4 = uVar5 | 8;
          piStack_58 = (int *)puVar3[1];
          *puVar3 = 0;
          puVar3[1] = 0;
          iStack_5c = iStack_18;
          piStack_1c = piStack_58;
          uStack_14 = uVar4;
          if (((uVar5 & 4) != 0) &&
             (uVar4 = uVar5 & 0xfffffffb | 8, uStack_14 = uVar4, piStack_30 != (int *)0x0)) {
            LOCK();
            iVar1 = piStack_30[1] + -1;
            piStack_30[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piStack_30)();
              LOCK();
              iVar1 = piStack_30[2] + -1;
              piStack_30[2] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)(*piStack_30 + 4))();
              }
            }
          }
          if (((uVar4 & 2) != 0) &&
             (uVar4 = uVar4 & 0xfffffffd, uStack_14 = uVar4, piStack_38 != (int *)0x0)) {
            LOCK();
            iVar1 = piStack_38[1] + -1;
            piStack_38[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piStack_38)();
              LOCK();
              iVar1 = piStack_38[2] + -1;
              piStack_38[2] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)(*piStack_38 + 4))();
              }
            }
          }
          uStack_8._0_1_ = 2;
          if (iStack_18 != 0) {
            piStack_28 = (int *)FUN_0060dcd0(auStack_6c,*(undefined4 *)(iStack_18 + 0x34));
            uStack_8 = CONCAT31(uStack_8._1_3_,3);
            if ((*piStack_28 == 0) ||
               (iVar1 = *(int *)(*piStack_28 + 0xc), iVar2 = FUN_00aff8c0(),
               (uint)*(ushort *)(iVar2 + 0x1da) <
               (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8))) {
              uVar5 = uVar4 | 0x20;
              piStack_40 = (int *)0x0;
              puVar3 = &uStack_44;
              iStack_20 = 0;
            }
            else {
              piStack_48 = (int *)piStack_28[1];
              iStack_20 = *piStack_28;
              if (piStack_48 != (int *)0x0) {
                LOCK();
                piStack_48[1] = piStack_48[1] + 1;
                UNLOCK();
                piStack_48 = (int *)piStack_28[1];
              }
              uVar5 = uVar4 | 0x10;
              puVar3 = &uStack_4c;
            }
            piStack_60 = (int *)puVar3[1];
            uVar4 = uVar5 | 0x40;
            *puVar3 = 0;
            puVar3[1] = 0;
            iStack_64 = iStack_20;
            piStack_28 = piStack_60;
            uStack_14 = uVar4;
            if (((uVar5 & 0x20) != 0) &&
               (uVar4 = uVar5 & 0xffffffdf | 0x40, uStack_14 = uVar4, piStack_40 != (int *)0x0)) {
              LOCK();
              iVar1 = piStack_40[1] + -1;
              piStack_40[1] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)*piStack_40)();
                LOCK();
                iVar1 = piStack_40[2] + -1;
                piStack_40[2] = iVar1;
                UNLOCK();
                if (iVar1 == 0) {
                  (**(code **)(*piStack_40 + 4))();
                }
              }
            }
            if (((uVar4 & 0x10) != 0) &&
               (uVar4 = uVar4 & 0xffffffef, uStack_14 = uVar4, piStack_48 != (int *)0x0)) {
              LOCK();
              iVar1 = piStack_48[1] + -1;
              piStack_48[1] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)*piStack_48)();
                LOCK();
                iVar1 = piStack_48[2] + -1;
                piStack_48[2] = iVar1;
                UNLOCK();
                if (iVar1 == 0) {
                  (**(code **)(*piStack_48 + 4))();
                }
              }
            }
            uStack_8._0_1_ = 5;
            piStack_2c = piStack_68;
            if (piStack_68 != (int *)0x0) {
              LOCK();
              iVar1 = piStack_68[1] + -1;
              piStack_68[1] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)*piStack_68)();
                LOCK();
                iVar1 = piStack_2c[2] + -1;
                piStack_2c[2] = iVar1;
                UNLOCK();
                if (iVar1 == 0) {
                  (**(code **)(*piStack_2c + 4))();
                }
              }
            }
            if (iStack_20 != 0) {
              iVar1 = FUN_00b077e0();
              fVar10 = *(float *)(iVar1 + 0x28) - param_4;
              fVar9 = *(float *)(iVar1 + 0x24) - param_3;
              fVar7 = *(float *)(iVar1 + 0x2c) - param_5;
              dVar8 = (double)(fVar10 * fVar10 + fVar9 * fVar9 + fVar7 * fVar7);
              FUN_017267a0();
              fVar7 = (float)dVar8;
              if ((fVar7 < fStack_24) && (fVar7 < *(float *)(iStack_18 + 0x58))) {
                if (piStack_1c != (int *)0x0) {
                  LOCK();
                  piStack_1c[1] = piStack_1c[1] + 1;
                  UNLOCK();
                }
                *param_2 = iStack_18;
                piStack_2c = (int *)param_2[1];
                param_2[1] = (int)piStack_1c;
                fStack_24 = fVar7;
                if (piStack_2c != (int *)0x0) {
                  LOCK();
                  iVar1 = piStack_2c[1] + -1;
                  piStack_2c[1] = iVar1;
                  UNLOCK();
                  if (iVar1 == 0) {
                    (**(code **)*piStack_2c)();
                    LOCK();
                    iVar1 = piStack_2c[2] + -1;
                    piStack_2c[2] = iVar1;
                    UNLOCK();
                    if (iVar1 == 0) {
                      (**(code **)(*piStack_2c + 4))();
                    }
                  }
                }
              }
            }
            if (piStack_28 != (int *)0x0) {
              LOCK();
              iVar1 = piStack_28[1] + -1;
              piStack_28[1] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)*piStack_28)();
                LOCK();
                iVar1 = piStack_28[2] + -1;
                piStack_28[2] = iVar1;
                UNLOCK();
                if (iVar1 == 0) {
                  (**(code **)(*piStack_28 + 4))();
                }
              }
            }
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          if (piStack_1c != (int *)0x0) {
            LOCK();
            iVar1 = piStack_1c[1] + -1;
            piStack_1c[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piStack_1c)();
              LOCK();
              iVar1 = piStack_1c[2] + -1;
              piStack_1c[2] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)(*piStack_1c + 4))();
              }
            }
          }
          piVar6 = piVar6 + 2;
        } while (piVar6 != (int *)piStack_54[1]);
      }
      if (piStack_50 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_50[1] + -1;
        piStack_50[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_50)();
          LOCK();
          piVar6 = piStack_50 + 2;
          iVar1 = *piVar6;
          *piVar6 = *piVar6 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_50 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25436 ; VA 0x00b97eb0 ; FUN_00b97eb0 */

undefined4 __thiscall FUN_00b97eb0(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x120);
  return param_2;
}



/* FUNCTION 25437 ; VA 0x00b97ee0 ; FUN_00b97ee0 */

void __thiscall FUN_00b97ee0(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x78);
  *param_2 = *(undefined4 *)(param_1 + 0x74);
  param_2[1] = uVar1;
  return;
}



/* FUNCTION 25438 ; VA 0x00b97f10 ; FUN_00b97f10 */

void __thiscall FUN_00b97f10(int param_1,int *param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined auStack_f8 [4];
  int iStack_f4;
  undefined auStack_f0 [200];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017faf3e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_01674e20(0xc);
  if (puVar2 == (undefined4 *)0x0) {
    puVar2 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = 0;
    puVar2[1] = 0;
    puVar2[2] = 0;
  }
  iStack_18 = 0;
  iStack_14 = 0;
  FUN_0055ba30(puVar2,param_2);
  uStack_20 = *(undefined4 *)(param_1 + 0xf8);
  uStack_1c = *(undefined4 *)(param_1 + 0xfc);
  uStack_28 = *(undefined4 *)(param_1 + 0x100);
  uStack_24 = *(undefined4 *)(param_1 + 0x104);
  uStack_8 = 0;
  FUN_00b56440(&uStack_20);
  iVar1 = iStack_18;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (*(int *)(iStack_18 + 8) == *(int *)(iStack_18 + 4)) {
    FUN_005ca4f0(*(int *)(iStack_18 + 4),auStack_f8);
  }
  else {
    FUN_005caf00(auStack_f8);
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 0xd0;
  }
  uStack_8._0_1_ = 2;
  if (iStack_f4 != 0) {
    (**(code **)(iStack_f4 + 8))(auStack_f0);
  }
  uStack_8._0_1_ = 0;
  FUN_00b56440(&uStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (*(int *)(iVar1 + 8) == *(int *)(iVar1 + 4)) {
    FUN_005ca4f0(*(int *)(iVar1 + 4),auStack_f8);
  }
  else {
    FUN_005caf00(auStack_f8);
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 0xd0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (iStack_f4 != 0) {
    (**(code **)(iStack_f4 + 8))(auStack_f0);
  }
  param_2[1] = iStack_14;
  *param_2 = iVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25439 ; VA 0x00b98080 ; FUN_00b98080 */

undefined4 __thiscall FUN_00b98080(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  int aiStack_64 [2];
  int iStack_5c;
  int aiStack_50 [2];
  int iStack_48;
  int aiStack_3c [2];
  int iStack_34;
  int *piStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017faf88;
  pvStack_10 = ExceptionList;
  iStack_20 = 0;
  piStack_1c = (int *)0x0;
  iStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  if (param_1 != 0) {
    iVar6 = *(int *)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    if ((iVar6 != 0) && (param_1 = iVar6, ExceptionList = &pvStack_10, *(int *)(iVar6 + 0x34) != 0))
    {
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar6 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01ead638,&LAB_006340f0);
      uVar3 = FUN_006353d0();
      piVar4 = (int *)FUN_008aa140(uVar3);
      piStack_14 = piVar4;
      if (*piVar4 == 0) {
        uVar3 = FUN_00b774a0();
        piVar5 = (int *)FUN_008a9ba0(auStack_28,uVar3);
        piVar4 = piStack_14;
        iVar6 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piStack_14 = iVar6;
        piVar5 = (int *)piStack_14[1];
        piStack_14[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar6 = piVar5[1] + -1;
          piVar5[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar6 = piVar5[2] + -1;
            piVar5[2] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_24 != (int *)0x0) {
          LOCK();
          iVar6 = piStack_24[1] + -1;
          piStack_24[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            (**(code **)*piStack_24)();
            LOCK();
            iVar6 = piStack_24[2] + -1;
            piStack_24[2] = iVar6;
            UNLOCK();
            if (iVar6 == 0) {
              (**(code **)(*piStack_24 + 4))();
            }
          }
        }
      }
      piVar5 = piStack_1c;
      iVar6 = *piVar4;
      if (iVar6 != 0) {
        piVar4 = *(int **)(iVar6 + 0x6c);
        if (piVar4 != (int *)0x0) {
          LOCK();
          piVar4[1] = piVar4[1] + 1;
          UNLOCK();
          piVar4 = *(int **)(iVar6 + 0x6c);
        }
        iStack_20 = *(int *)(iVar6 + 0x68);
        if (piStack_1c != (int *)0x0) {
          LOCK();
          iVar6 = piStack_1c[1] + -1;
          piStack_1c[1] = iVar6;
          UNLOCK();
          if (iVar6 == 0) {
            puVar1 = (undefined4 *)*piStack_1c;
            piStack_1c = piVar4;
            (*(code *)*puVar1)();
            LOCK();
            piVar4 = piVar5 + 2;
            iVar6 = *piVar4 + -1;
            *piVar4 = iVar6;
            UNLOCK();
            piVar4 = piStack_1c;
            if (iVar6 == 0) {
              (**(code **)(*piVar5 + 4))();
              piVar4 = piStack_1c;
            }
          }
        }
        piStack_1c = piVar4;
        iVar6 = iStack_18;
        if ((iStack_20 != 0) && (iVar2 = FUN_008f7870(iStack_18), iVar2 != 0)) {
          FUN_00906640(aiStack_3c,&iStack_20);
          iStack_8._0_1_ = 1;
          if ((aiStack_3c[0] == 1) || (iStack_34 == 1)) {
            FUN_008b4190(auStack_28);
            iStack_8 = CONCAT31(iStack_8._1_3_,2);
            uVar3 = FUN_00b8e960();
            FUN_0060e0c0(param_2,uVar3);
            FUN_00550b30();
            if (piStack_2c != (int *)0x0) {
              LOCK();
              piVar4 = piStack_2c + 2;
              iVar6 = *piVar4;
              *piVar4 = *piVar4 + -1;
              UNLOCK();
              if (iVar6 == 1) {
                (**(code **)(*piStack_2c + 4))();
              }
            }
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return param_2;
          }
          iVar6 = FUN_005c3ac0(iVar6);
          if (iVar6 != 0) {
            FUN_008b4950(aiStack_50,&iStack_20);
            iStack_8._0_1_ = 3;
            if ((aiStack_50[0] == 1) || (iStack_48 == 1)) {
              FUN_008b4190(auStack_28);
              iStack_8 = CONCAT31(iStack_8._1_3_,4);
              uVar3 = FUN_00b8e960();
              FUN_0060e0c0(param_2,uVar3);
              FUN_00550b30();
LAB_00b9834d:
              FUN_008ae7d0();
              FUN_008ae7d0();
              FUN_00550b30();
              ExceptionList = pvStack_10;
              return param_2;
            }
            FUN_008b4e80(aiStack_64,&iStack_20);
            if ((aiStack_64[0] == 1) || (iStack_5c == 1)) {
              FUN_008b4190(auStack_28);
              iStack_8 = CONCAT31(iStack_8._1_3_,6);
              uVar3 = FUN_00b8e960();
              FUN_0060e0c0(param_2,uVar3);
              FUN_00550b30();
              FUN_008ae7d0();
              goto LAB_00b9834d;
            }
            FUN_008ae7d0();
            FUN_008ae7d0();
          }
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          FUN_008ae7d0();
        }
      }
    }
  }
  FUN_0060e0c0(param_2,0);
  piVar4 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar6 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar5 = piVar4 + 2;
      iVar6 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 25440 ; VA 0x00b98420 ; FUN_00b98420 */

void FUN_00b98420(undefined4 *param_1)

{
  char cVar1;
  char *pcVar2;
  int iVar3;
  int iVar4;
  char *pcVar5;
  int iVar6;
  undefined4 uVar7;
  uint uVar8;
  uint uVar9;
  undefined **ppuVar10;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fafb0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00888650(&uStack_24);
  uStack_8 = 0;
  ppuVar10 = &PTR_DAT_01d67808;
  iVar4 = 0;
  do {
    pcVar2 = *ppuVar10;
    iStack_1c = iVar4 + 1;
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = auStack_3c[0] & 0xffffff00;
    pcVar5 = pcVar2;
    do {
      cVar1 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar1 != '\0');
    iStack_18 = iVar4;
    FUN_005542c0(pcVar2,(int)pcVar5 - (int)(pcVar2 + 1));
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar6 = FUN_005c4c00(auStack_3c);
    uVar7 = FUN_0088c8c0();
    *(undefined4 *)(iVar6 + 0x18) = uVar7;
    iStack_14 = FUN_005c9cc0();
    iVar3 = *(int *)(iVar6 + 0x1c);
    if (iVar3 == iStack_14) {
      *(int *)(iVar6 + 0x20) = iVar4;
    }
    else {
      if (iVar3 != 0) {
        (**(code **)(iVar3 + 8))((int *)(iVar6 + 0x20));
      }
      *(int *)(iVar6 + 0x20) = iStack_18;
      *(int *)(iVar6 + 0x1c) = iStack_14;
    }
    uStack_8 = uStack_8 & 0xffffff00;
    if (0xf < uStack_28) {
      uVar9 = uStack_28 + 1;
      uVar8 = auStack_3c[0];
      if (0xfff < uVar9) {
        uVar8 = *(uint *)(auStack_3c[0] - 4);
        uVar9 = uStack_28 + 0x24;
        if (0x1f < (auStack_3c[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar9);
    }
    ppuVar10 = ppuVar10 + 1;
    iVar4 = iStack_1c;
  } while (ppuVar10 != (undefined **)&DAT_01d678a0);
  *param_1 = uStack_24;
  param_1[1] = uStack_20;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25441 ; VA 0x00b98550 ; FUN_00b98550 */

void __thiscall FUN_00b98550(int param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fafe8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00888650(&uStack_18);
  uStack_8 = 0;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0(&DAT_01959d48,3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar2 = FUN_005c4c00(auStack_30);
  uVar3 = FUN_0088c960();
  *(undefined4 *)(iVar2 + 0x18) = uVar3;
  iVar4 = FUN_00630820();
  iVar1 = *(int *)(iVar2 + 0x1c);
  if (iVar1 == iVar4) {
    *(undefined4 *)(iVar2 + 0x20) = *(undefined4 *)(param_1 + 0x108);
  }
  else {
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(iVar2 + 0x20);
      *(undefined4 *)(iVar2 + 0x1c) = 0;
    }
    *(undefined4 *)(iVar2 + 0x20) = *(undefined4 *)(param_1 + 0x108);
    *(int *)(iVar2 + 0x1c) = iVar4;
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_1c) {
    uVar6 = uStack_1c + 1;
    uVar5 = auStack_30[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_30[0] - 4);
      uVar6 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("bottom",6);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iVar2 = FUN_005c4c00(auStack_30);
  uVar3 = FUN_0088c960();
  *(undefined4 *)(iVar2 + 0x18) = uVar3;
  iVar4 = FUN_00630820();
  iVar1 = *(int *)(iVar2 + 0x1c);
  if (iVar1 == iVar4) {
    *(undefined4 *)(iVar2 + 0x20) = *(undefined4 *)(param_1 + 0x10c);
  }
  else {
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(iVar2 + 0x20);
      *(undefined4 *)(iVar2 + 0x1c) = 0;
    }
    *(undefined4 *)(iVar2 + 0x20) = *(undefined4 *)(param_1 + 0x10c);
    *(int *)(iVar2 + 0x1c) = iVar4;
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_1c) {
    uVar6 = uStack_1c + 1;
    uVar5 = auStack_30[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_30[0] - 4);
      uVar6 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0(&DAT_01959d54,4);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  iVar2 = FUN_005c4c00(auStack_30);
  uVar3 = FUN_0088c960();
  *(undefined4 *)(iVar2 + 0x18) = uVar3;
  iVar4 = FUN_00630820();
  iVar1 = *(int *)(iVar2 + 0x1c);
  if (iVar1 == iVar4) {
    *(undefined4 *)(iVar2 + 0x20) = *(undefined4 *)(param_1 + 0x110);
  }
  else {
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(iVar2 + 0x20);
      *(undefined4 *)(iVar2 + 0x1c) = 0;
    }
    *(undefined4 *)(iVar2 + 0x20) = *(undefined4 *)(param_1 + 0x110);
    *(int *)(iVar2 + 0x1c) = iVar4;
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_1c) {
    uVar6 = uStack_1c + 1;
    uVar5 = auStack_30[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_30[0] - 4);
      uVar6 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("right",5);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  iVar2 = FUN_005c4c00(auStack_30);
  uVar3 = FUN_0088c960();
  *(undefined4 *)(iVar2 + 0x18) = uVar3;
  iVar4 = FUN_00630820();
  iVar1 = *(int *)(iVar2 + 0x1c);
  if (iVar1 == iVar4) {
    *(undefined4 *)(iVar2 + 0x20) = *(undefined4 *)(param_1 + 0x114);
  }
  else {
    if (iVar1 != 0) {
      (**(code **)(iVar1 + 8))(iVar2 + 0x20);
      *(undefined4 *)(iVar2 + 0x1c) = 0;
    }
    *(undefined4 *)(iVar2 + 0x20) = *(undefined4 *)(param_1 + 0x114);
    *(int *)(iVar2 + 0x1c) = iVar4;
  }
  if (0xf < uStack_1c) {
    uVar6 = uStack_1c + 1;
    uVar5 = auStack_30[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_30[0] - 4);
      uVar6 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  *param_2 = uStack_18;
  param_2[1] = uStack_14;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25442 ; VA 0x00b98870 ; FUN_00b98870 */

void __thiscall FUN_00b98870(undefined4 param_1,float *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  iVar4 = FUN_00b8e6b0(param_1);
  if ((iVar4 != 0) && (puVar1 = *(undefined4 **)(iVar4 + 0x2c), puVar1 != (undefined4 *)0x0)) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar4 = *piVar6;
      if ((iVar4 != 0) &&
         (iVar3 = *(int *)(iVar4 + 0xc), iVar5 = FUN_00c68a10(),
         (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        if (iVar4 != 0) {
          *param_2 = *(float *)(iVar4 + 0x16c) - *(float *)(iVar4 + 0x164);
          param_2[1] = *(float *)(iVar4 + 0x170) - *(float *)(iVar4 + 0x168);
          return;
        }
        break;
      }
    }
  }
  *param_2 = 0.0;
  param_2[1] = 0.0;
  return;
}



/* FUNCTION 25443 ; VA 0x00b98920 ; FUN_00b98920 */

void __thiscall
FUN_00b98920(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 *param_7,ulonglong param_8,uint param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined8 param_15)

{
  int *piVar1;
  uint *puVar2;
  char cVar3;
  float *pfVar4;
  int iVar5;
  int iVar6;
  undefined *puVar7;
  uint auStack_c8 [2];
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 *puStack_b4;
  undefined8 uStack_b0;
  uint auStack_a8 [2];
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 *puStack_94;
  undefined8 uStack_90;
  undefined auStack_80 [80];
  undefined auStack_30 [4];
  undefined4 *puStack_2c;
  undefined *puStack_28;
  undefined4 uStack_24;
  undefined4 *puStack_20;
  int iStack_1c;
  int iStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fb060;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  uStack_8 = 1;
  uStack_90 = CONCAT44(auStack_30,0xb98959);
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  pfVar4 = (float *)FUN_00b98870();
  if ((NAN(*pfVar4) == (*pfVar4 == 0.0)) || (NAN(pfVar4[1]) == (pfVar4[1] == 0.0))) {
    puStack_2c = auStack_a8;
    puStack_28 = (undefined *)auStack_a8;
    auStack_a8[0] = 0;
    puVar2 = auStack_a8;
    if (param_9 != 0) {
      auStack_a8[0] = param_9;
      if ((param_9 & 1) == 0) {
        uStack_b0 = ZEXT48(&uStack_a0);
        puStack_b4 = &param_11;
        uStack_b8 = 0xb98b71;
        (**(code **)(param_9 & 0xfffffffe))();
        puVar2 = puStack_2c;
      }
      else {
        uStack_a0 = param_11;
        uStack_9c = param_12;
        uStack_98 = param_13;
        puStack_94 = (undefined4 *)param_14;
        uStack_90 = param_15;
        puVar2 = auStack_a8;
      }
    }
    puStack_2c = puVar2;
    puStack_28 = (undefined *)auStack_c8;
    uStack_8._0_1_ = 9;
    auStack_c8[0] = 0;
    puVar2 = auStack_c8;
    if (param_2 != 0) {
      auStack_c8[0] = param_2;
      if ((param_2 & 1) == 0) {
        (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_c0,0);
        puVar2 = (uint *)puStack_28;
      }
      else {
        uStack_c0 = param_4;
        uStack_bc = param_5;
        uStack_b8 = param_6;
        puStack_b4 = param_7;
        uStack_b0 = param_8;
        puVar2 = auStack_c8;
      }
    }
    puStack_28 = (undefined *)puVar2;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00b98c30();
  }
  else if (param_1 != 0) {
    iVar6 = *(int *)(param_1 + 0x34);
    if ((iVar6 != 0) && (param_1 = iVar6, *(int *)(iVar6 + 0x34) != 0)) {
      uStack_90 = CONCAT44(0xb9899c,(undefined4)uStack_90);
      param_1 = FUN_005c8ac0();
    }
    if (param_1 != 0) {
      iVar6 = *(int *)(param_1 + 0xc);
      uStack_90 = CONCAT44(0xb989b2,(undefined4)uStack_90);
      iVar5 = FUN_008a8c30();
      if ((uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
          (uint)*(ushort *)(iVar5 + 0x1da)) {
        uStack_90 = CONCAT44(0xb989d8,(undefined4)uStack_90);
        iVar6 = FUN_005f5170();
        if (iVar6 != 0) {
          puStack_20 = auStack_a8;
          iStack_18 = iVar6 + 0xd4;
          uStack_b0 = CONCAT44(&param_9,0xb989f9);
          FUN_0054f510();
          uStack_8._0_1_ = 2;
          FUN_0054f510(&param_2);
          uStack_8._0_1_ = 1;
          puStack_20 = (undefined4 *)FUN_00b8dee0(auStack_80,FUN_00b98c30,0,iStack_1c);
          uStack_8._0_1_ = 4;
          puVar7 = (undefined *)FUN_01675290(DAT_02110da8);
          uStack_8._0_1_ = 5;
          uStack_90 = 0x6800b98a47;
          puStack_28 = puVar7;
          puStack_14 = (undefined4 *)FUN_01674e20();
          puStack_2c = puStack_14;
          if (puStack_14 == (undefined4 *)0x0) {
            puStack_14 = (undefined4 *)0x0;
          }
          else {
            *puStack_14 = 0;
            puStack_14[1] = 1;
            puStack_14[2] = FUN_00b969d0;
            puStack_14[3] = FUN_00b96ab0;
            puStack_14[4] = 0;
            puStack_14[5] = iStack_18;
            uStack_8._0_1_ = 7;
            puStack_14[6] = *puStack_20;
            puStack_14[7] = puStack_20[1];
            uStack_90 = CONCAT44(puStack_20 + 2,0xb98a99);
            FUN_00b8fc30();
          }
          uStack_8._0_1_ = 5;
          uStack_90 = CONCAT44(puStack_14,0xb98aaa);
          FUN_016797d0();
          if (puStack_14 != (undefined4 *)0x0) {
            LOCK();
            puStack_14[1] = puStack_14[1] + 1;
            UNLOCK();
          }
          uStack_24 = 1;
          uStack_8._0_1_ = 8;
          uStack_90 = CONCAT44(puVar7,0xb98ace);
          FUN_01675290();
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          uStack_90 = CONCAT44(&puStack_14,0xb98ae9);
          cVar3 = FUN_01679300();
          if (cVar3 != '\0') {
            uStack_90 = CONCAT44(0xb98af4,(undefined4)uStack_90);
            FUN_01679490();
            uStack_90 = CONCAT44(&puStack_14,0xb98aff);
            FUN_016791c0();
          }
          if (puStack_14 != (undefined4 *)0x0) {
            piVar1 = puStack_14 + 1;
            LOCK();
            iVar6 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar6 == 1) {
              uStack_90 = CONCAT44(puStack_14,0xb98b1d);
              FUN_01674ea0();
            }
          }
          uStack_90 = CONCAT44(0xb98b28,(undefined4)uStack_90);
          FUN_0096ca80();
        }
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,10);
  if (param_2 != 0) {
    if (((param_2 & 1) == 0) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0)) {
      puStack_94 = &param_4;
      uStack_90 = CONCAT44(2,puStack_94);
      uStack_98 = 0xb98be8;
      (**(code **)(param_2 & 0xfffffffe))();
    }
    param_2 = 0;
  }
  uStack_8 = 0xb;
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    puStack_94 = &param_11;
    uStack_90 = CONCAT44(2,puStack_94);
    uStack_98 = 0xb98c16;
    (**(code **)(param_9 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25444 ; VA 0x00b98c30 ; FUN_00b98c30 */

void FUN_00b98c30(uint param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  uint in_stack_00000024;
  undefined auStack_24 [12];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fb088;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_01679490();
  puVar1 = (undefined4 *)FUN_00b98870(auStack_24);
  uStack_18 = *puVar1;
  uStack_14 = puVar1[1];
  if (param_1 == 0) {
    uVar2 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar2);
  }
  (**(code **)((param_1 & 0xfffffffe) + 4))(&stack0x0000000c,uStack_18,uStack_14);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_1 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
  }
  uStack_8 = 4;
  if (((in_stack_00000024 != 0) && ((in_stack_00000024 & 1) == 0)) &&
     (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&stack0x0000002c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25445 ; VA 0x00b98d10 ; FUN_00b98d10 */

int FUN_00b98d10(void)

{
  int *piVar1;
  int iVar2;
  int iStack_c;
  int *piStack_8;
  
  FUN_00587490(&iStack_c);
  if (iStack_c != 0) {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_8[1] + -1;
      piStack_8[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piStack_8 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return iStack_c;
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_8[1] + -1;
    piStack_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  return 0;
}



/* FUNCTION 25446 ; VA 0x00b98d90 ; FUN_00b98d90 */

int FUN_00b98d90(int param_1)

{
  int *piVar1;
  int iVar2;
  int iStack_c;
  int *piStack_8;
  
  if (param_1 != 0) {
    FUN_00b56db0();
  }
  FUN_00587490(&iStack_c);
  if (iStack_c == 0) {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_8[1] + -1;
      piStack_8[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piStack_8 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return 0;
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_8[1] + -1;
    piStack_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  return iStack_c;
}



/* FUNCTION 25447 ; VA 0x00b98e50 ; FUN_00b98e50 */

int FUN_00b98e50(void)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iStack_10;
  int *piStack_c;
  
  FUN_00587490(&iStack_10);
  piVar1 = piStack_c;
  if (iStack_10 == 0) {
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        piVar2 = piVar1 + 2;
        iVar3 = *piVar2 + -1;
        *piVar2 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
    FUN_00587490(&iStack_10);
    if (iStack_10 == 0) {
      if (piStack_c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_c[1] + -1;
        piStack_c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_c)();
          LOCK();
          piVar1 = piStack_c + 2;
          iVar3 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piStack_c + 4))();
          }
        }
      }
      return 0;
    }
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        piVar1 = piStack_c + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          (**(code **)(*piStack_c + 4))();
          return iStack_10;
        }
      }
    }
  }
  else if (piStack_c != (int *)0x0) {
    LOCK();
    iVar3 = piStack_c[1] + -1;
    piStack_c[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piStack_c + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_c + 4))();
      }
    }
  }
  return iStack_10;
}



/* FUNCTION 25448 ; VA 0x00b98f40 ; FUN_00b98f40 */

int FUN_00b98f40(void)

{
  int *piVar1;
  int iVar2;
  int iStack_c;
  int *piStack_8;
  
  FUN_00587490(&iStack_c);
  if (iStack_c != 0) {
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_8[1] + -1;
      piStack_8[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar1 = piStack_8 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return iStack_c;
  }
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_8[1] + -1;
    piStack_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  return 0;
}



/* FUNCTION 25449 ; VA 0x00b98fc0 ; FUN_00b98fc0 */

undefined4 * __thiscall FUN_00b98fc0(int param_1,undefined4 *param_2,int param_3,int *param_4)

{
  int iVar1;
  void **ppvVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  undefined4 *puVar8;
  int *piStack_38;
  int *piStack_34;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017fb0c8;
  iStack_8 = 0;
  pvStack_10 = ExceptionList;
  if (*(int *)(param_1 + 0x15c) == 0) {
    puVar8 = (undefined4 *)0x0;
    ppvVar2 = &pvStack_10;
  }
  else {
    puVar8 = *(undefined4 **)(*(int *)(param_1 + 0x168) + *(int *)(param_1 + 0x158) * 4);
    ppvVar2 = &pvStack_10;
  }
  do {
    ExceptionList = ppvVar2;
    if (puVar8 == (undefined4 *)0x0) {
      *param_2 = 0;
      param_2[1] = 0;
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_4 != (int *)0x0) {
        LOCK();
        iVar1 = param_4[1] + -1;
        param_4[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*param_4)();
          LOCK();
          piVar6 = param_4 + 2;
          iVar1 = *piVar6;
          *piVar6 = *piVar6 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*param_4 + 4))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return param_2;
    }
    iVar1 = puVar8[9];
    iVar3 = 0;
    piVar6 = (int *)0x0;
    if (iVar1 != 0) {
      piVar6 = (int *)(iVar1 + 4);
      iVar1 = *(int *)(iVar1 + 4);
      while (iVar1 != 0) {
        LOCK();
        iVar3 = *piVar6;
        if (iVar1 == iVar3) {
          *piVar6 = iVar1 + 1;
          iVar3 = iVar1;
        }
        UNLOCK();
        if (iVar3 == iVar1) {
          iVar3 = puVar8[8];
          piVar6 = (int *)puVar8[9];
          goto LAB_00b99049;
        }
        iVar1 = *piVar6;
      }
      iVar3 = 0;
      piVar6 = (int *)0x0;
    }
LAB_00b99049:
    iStack_8._1_3_ = (uint3)((uint)iStack_8 >> 8);
    iStack_8._0_1_ = 1;
    if (iVar3 != 0) {
      if (param_3 == iVar3) {
LAB_00b99249:
        *param_2 = 0;
        param_2[1] = 0;
        if (puVar8[9] != 0) {
          LOCK();
          piVar7 = (int *)(puVar8[9] + 8);
          *piVar7 = *piVar7 + 1;
          UNLOCK();
        }
        *param_2 = puVar8[8];
        param_2[1] = puVar8[9];
        param_2[2] = 0;
        param_2[3] = 0;
        if (puVar8[0xb] != 0) {
          LOCK();
          piVar7 = (int *)(puVar8[0xb] + 4);
          *piVar7 = *piVar7 + 1;
          UNLOCK();
        }
        param_2[2] = puVar8[10];
        param_2[3] = puVar8[0xb];
        if (piVar6 != (int *)0x0) {
          LOCK();
          iVar1 = piVar6[1] + -1;
          piVar6[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar6)();
            LOCK();
            iVar1 = piVar6[2] + -1;
            piVar6[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar6 + 4))();
            }
          }
        }
        if (param_4 != (int *)0x0) {
          LOCK();
          iVar1 = param_4[1] + -1;
          param_4[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*param_4)();
            LOCK();
            piVar6 = param_4 + 2;
            iVar1 = *piVar6;
            *piVar6 = *piVar6 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*param_4 + 4))();
            }
          }
        }
        ExceptionList = pvStack_10;
        return param_2;
      }
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
      }
      if (iVar3 == *(int *)(param_3 + 0x34)) {
        cStack_11 = '\x01';
      }
      else if (*(int *)(param_3 + 0x34) == 0) {
        cStack_11 = '\0';
      }
      else {
        cStack_11 = FUN_00620ec0(iVar3);
      }
      iStack_8._0_1_ = 1;
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar1 = piVar6[1] + -1;
        piVar6[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          iVar1 = piVar6[2] + -1;
          piVar6[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      if (cStack_11 != '\0') goto LAB_00b99249;
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar1 = piVar6[1] + -1;
      piVar6[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        iVar1 = piVar6[2] + -1;
        piVar6[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    piVar6 = (int *)puVar8[0xb];
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = (int *)puVar8[0xb];
    }
    piVar7 = (int *)puVar8[10];
    iStack_8._0_1_ = 3;
    if ((piVar7 != (int *)0x0) &&
       (iVar1 = piVar7[1] - *piVar7 >> 0x1f, (piVar7[1] - *piVar7) / 0xd0 + iVar1 != iVar1)) {
      FUN_006d07c0(puVar8[10]);
      iStack_8._0_1_ = 4;
      piVar7 = piStack_38;
      if (piStack_38 != piStack_34) {
        do {
          iVar1 = *piVar7;
          iVar3 = FUN_0088cdc0();
          if (iVar1 == iVar3) {
            iVar1 = *piVar7;
            iVar3 = FUN_0088cdc0();
            if (iVar1 != iVar3) {
                    /* WARNING: Subroutine does not return */
              FUN_016757c0("Variant cast failed");
            }
            piVar4 = piVar7 + 2;
            if (piVar7[1] == 0) {
              piVar4 = (int *)0x0;
            }
            piVar5 = (int *)piVar4[1];
            if (piVar5 != (int *)0x0) {
              LOCK();
              piVar5[1] = piVar5[1] + 1;
              UNLOCK();
              piVar5 = (int *)piVar4[1];
            }
            if (*piVar4 == param_3) {
              *param_2 = 0;
              param_2[1] = 0;
              if (puVar8[9] != 0) {
                LOCK();
                piVar7 = (int *)(puVar8[9] + 8);
                *piVar7 = *piVar7 + 1;
                UNLOCK();
              }
              *param_2 = puVar8[8];
              param_2[1] = puVar8[9];
              param_2[2] = 0;
              param_2[3] = 0;
              if (puVar8[0xb] != 0) {
                LOCK();
                piVar7 = (int *)(puVar8[0xb] + 4);
                *piVar7 = *piVar7 + 1;
                UNLOCK();
              }
              param_2[2] = puVar8[10];
              param_2[3] = puVar8[0xb];
              if (piVar5 != (int *)0x0) {
                LOCK();
                iVar1 = piVar5[1] + -1;
                piVar5[1] = iVar1;
                UNLOCK();
                if (iVar1 == 0) {
                  (**(code **)*piVar5)();
                  LOCK();
                  iVar1 = piVar5[2] + -1;
                  piVar5[2] = iVar1;
                  UNLOCK();
                  if (iVar1 == 0) {
                    (**(code **)(*piVar5 + 4))();
                  }
                }
              }
              iStack_8 = CONCAT31(iStack_8._1_3_,5);
              FUN_00577b20();
              if (piVar6 != (int *)0x0) {
                LOCK();
                iVar1 = piVar6[1] + -1;
                piVar6[1] = iVar1;
                UNLOCK();
                if (iVar1 == 0) {
                  (**(code **)*piVar6)();
                  LOCK();
                  iVar1 = piVar6[2] + -1;
                  piVar6[2] = iVar1;
                  UNLOCK();
                  if (iVar1 == 0) {
                    (**(code **)(*piVar6 + 4))();
                  }
                }
              }
              if (param_4 == (int *)0x0) {
                ExceptionList = pvStack_10;
                return param_2;
              }
              LOCK();
              iVar1 = param_4[1] + -1;
              param_4[1] = iVar1;
              UNLOCK();
              if (iVar1 != 0) {
                ExceptionList = pvStack_10;
                return param_2;
              }
              (**(code **)*param_4)();
              LOCK();
              piVar6 = param_4 + 2;
              iVar1 = *piVar6;
              *piVar6 = *piVar6 + -1;
              UNLOCK();
              if (iVar1 != 1) {
                ExceptionList = pvStack_10;
                return param_2;
              }
              (**(code **)(*param_4 + 4))();
              ExceptionList = pvStack_10;
              return param_2;
            }
            if (piVar5 != (int *)0x0) {
              LOCK();
              iVar1 = piVar5[1] + -1;
              piVar5[1] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)*piVar5)();
                LOCK();
                iVar1 = piVar5[2] + -1;
                piVar5[2] = iVar1;
                UNLOCK();
                if (iVar1 == 0) {
                  (**(code **)(*piVar5 + 4))();
                }
              }
            }
          }
          piVar7 = piVar7 + 0x34;
        } while (piVar7 != piStack_34);
      }
      iStack_8._0_1_ = 6;
      FUN_00577b20();
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (piVar6 != (int *)0x0) {
      LOCK();
      iVar1 = piVar6[1] + -1;
      piVar6[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar6)();
        LOCK();
        iVar1 = piVar6[2] + -1;
        piVar6[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar6 + 4))();
        }
      }
    }
    puVar8 = (undefined4 *)*puVar8;
    ppvVar2 = (void **)ExceptionList;
  } while( true );
}



/* FUNCTION 25450 ; VA 0x00b99400 ; FUN_00b99400 */

undefined4 __thiscall FUN_00b99400(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x138);
  return param_2;
}



/* FUNCTION 25451 ; VA 0x00b99440 ; FUN_00b99440 */

void __thiscall FUN_00b99440(int param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint in_stack_00000018;
  
  *(undefined *)(param_1 + 0x1e8) = 0;
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  return;
}



/* FUNCTION 25452 ; VA 0x00b99490 ; FUN_00b99490 */

void __thiscall FUN_00b99490(int param_1,uint param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fb0f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *(undefined *)(param_1 + 0x1e8) = 0;
  if (param_2 != 0) {
    (**(code **)((param_2 & 0xfffffffe) + 4))(&stack0x0000000c);
    uStack_8 = 2;
    if (((param_2 != 0) && ((param_2 & 1) == 0)) &&
       (*(code **)(param_2 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_2 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
    }
    ExceptionList = pvStack_10;
    return;
  }
  uVar1 = FUN_0054fda0();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar1);
}



/* FUNCTION 25453 ; VA 0x00b99520 ; FUN_00b99520 */

void FUN_00b99520(uint param_1)

{
  int iVar1;
  uint uVar2;
  int in_stack_00000024;
  uint in_stack_00000038;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (((param_1 != 0) && (ExceptionList = &pvStack_10, (param_1 & 1) == 0)) &&
     (ExceptionList = &pvStack_10, *(code **)(param_1 & 0xfffffffe) != (code *)0x0)) {
    ExceptionList = &pvStack_10;
    (**(code **)(param_1 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
  }
  if (0xf < in_stack_00000038) {
    uVar2 = in_stack_00000038 + 1;
    iVar1 = in_stack_00000024;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(in_stack_00000024 + -4);
      uVar2 = in_stack_00000038 + 0x24;
      if (0x1f < (in_stack_00000024 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25454 ; VA 0x00b995b0 ; FUN_00b995b0 */

void FUN_00b995b0(uint param_1)

{
  undefined4 uVar1;
  char in_stack_00000024;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fb0f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (in_stack_00000024 != '\0') {
    if (param_1 == 0) {
      ExceptionList = &pvStack_10;
      uVar1 = FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0(uVar1);
    }
    ExceptionList = &pvStack_10;
    (**(code **)((param_1 & 0xfffffffe) + 4))(&stack0x0000000c);
  }
  uStack_8 = 2;
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_1 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25455 ; VA 0x00b99640 ; FUN_00b99640 */

void FUN_00b99640(uint param_1)

{
  char cVar1;
  undefined4 *puVar2;
  char cStack00000024;
  char cStack00000027;
  undefined4 uStack_200;
  undefined4 *puStack_1fc;
  undefined auStack_1f8 [32];
  undefined4 uStack_1d8;
  undefined auStack_1d4 [24];
  undefined4 uStack_1bc;
  undefined4 *puStack_1b8;
  code *pcStack_1b4;
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined4 *puStack_1a8;
  int aiStack_1a4 [7];
  undefined4 uStack_188;
  undefined4 *puStack_184;
  undefined **appuStack_180 [2];
  undefined4 *puStack_178;
  undefined4 uStack_170;
  undefined *puStack_16c;
  undefined *puStack_168;
  undefined *puStack_164;
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined auStack_144 [40];
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined auStack_114 [40];
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined auStack_e4 [40];
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined auStack_b4 [40];
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined auStack_84 [40];
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined auStack_54 [40];
  undefined *puStack_2c;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017fb179;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  if (cStack00000024 == '\0') {
    puStack_168 = (undefined *)0xb99697;
    ExceptionList = &pvStack_10;
    iStack_24 = FUN_0097bfc0();
    if (iStack_24 != 0) {
      puStack_2c = (undefined *)appuStack_180;
      uStack_14 = CONCAT31(uStack_14._1_3_,DAT_01ef22f0);
      puStack_184 = (undefined4 *)(uint)DAT_01ef22f0;
      iStack_1c = DAT_01d677dc >> 0x1f;
      _cStack00000024 = aiStack_1a4;
      iStack_20 = DAT_01d677dc;
      puStack_1a8 = &param_1;
      uStack_1ac = 0xb996d7;
      FUN_0054f510();
      pcStack_1b4 = (code *)&uStack_1ac;
      iStack_8._0_1_ = 2;
      puStack_1b8 = (undefined4 *)0xb996e7;
      FUN_0060dcd0();
      iStack_8._0_1_ = 0;
      puStack_1b8 = &uStack_14c;
      uStack_1b0 = 0;
      pcStack_1b4 = FUN_00b99520;
      uStack_1bc = 0xb99701;
      FUN_00b8e230();
      uStack_11c = uStack_14c;
      uStack_118 = uStack_148;
      puStack_184 = (undefined4 *)auStack_144;
      iStack_8._0_1_ = 3;
      uStack_188 = 0xb99732;
      FUN_00b902d0();
      uStack_ec = uStack_11c;
      uStack_e8 = uStack_118;
      puStack_184 = (undefined4 *)auStack_114;
      iStack_8._0_1_ = 4;
      appuStack_180[0] = (undefined **)0x0;
      uStack_188 = 0xb99766;
      FUN_00b902d0();
      uStack_bc = uStack_ec;
      uStack_b8 = uStack_e8;
      puStack_184 = (undefined4 *)auStack_e4;
      iStack_8._0_1_ = 5;
      uStack_188 = 0xb99794;
      FUN_00b902d0();
      uStack_5c = uStack_bc;
      uStack_58 = uStack_b8;
      puStack_184 = (undefined4 *)auStack_b4;
      iStack_8._0_1_ = 6;
      uStack_188 = 0xb997b9;
      FUN_00b902d0();
      puStack_184 = &uStack_5c;
      iStack_8._0_1_ = 7;
      uStack_188 = 0xb997c6;
      cVar1 = FUN_00585a40();
      if (cVar1 == '\0') {
        uStack_8c = uStack_5c;
        uStack_88 = uStack_58;
        puStack_184 = (undefined4 *)auStack_54;
        uStack_188 = 0xb997eb;
        FUN_00b902d0();
        puStack_184 = (undefined4 *)0x30;
        iStack_8._0_1_ = 8;
        uStack_188 = 0xb997f6;
        puVar2 = (undefined4 *)FUN_01674e20();
        iStack_8._0_1_ = 9;
        if (puVar2 == (undefined4 *)0x0) {
          puStack_178 = (undefined4 *)0x0;
          _cStack00000024 = puVar2;
        }
        else {
          puStack_184 = (undefined4 *)auStack_84;
          *puVar2 = uStack_8c;
          puVar2[1] = uStack_88;
          uStack_188 = 0xb99823;
          _cStack00000024 = puVar2;
          FUN_00b902d0();
          puStack_178 = puVar2;
        }
        puStack_184 = (undefined4 *)0xb99832;
        FUN_00a7c840();
        puStack_184 = (undefined4 *)0xb9983a;
        FUN_00a7c840();
        _cStack00000024 = (int *)CONCAT13(1,_cStack00000024);
      }
      else {
        puStack_184 = (undefined4 *)0xb99848;
        FUN_00a7c840();
        _cStack00000024 = (int *)((uint)_cStack00000024 & 0xffffff);
      }
      puStack_184 = (undefined4 *)0xb99857;
      FUN_00a7c840();
      appuStack_180[0] = &PTR_FUN_0195a324;
      if (cStack00000027 == '\0') {
        appuStack_180[0] = (undefined **)0x0;
      }
      puStack_184 = (undefined4 *)0xb99871;
      FUN_00a7c840();
      puStack_184 = (undefined4 *)0xb9987c;
      FUN_00a7c840();
      puStack_184 = (undefined4 *)0xb99887;
      FUN_00a7c840();
      iStack_8._0_1_ = 10;
      puStack_1fc = &param_1;
      aiStack_1a4[0] = 0;
      uStack_1d8 = uStack_14;
      _cStack00000024 = (int *)auStack_1f8;
      uStack_200 = 0xb998ab;
      FUN_0054f510();
      iStack_8._0_1_ = 0xb;
      FUN_0060dcd0(&uStack_200,uStack_18);
      iStack_8._0_1_ = 10;
      FUN_00b8e230(auStack_1d4,FUN_00b995b0,0);
      uStack_1d8 = 0xb998db;
      FUN_00b8ba30();
      aiStack_1a4[0] = iStack_1c;
      puStack_1a8 = (undefined4 *)iStack_20;
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      uStack_1ac = 0xb998ed;
      FUN_00929da0();
    }
  }
  else {
    if (param_1 == 0) {
      puStack_164 = (undefined *)0xb99931;
      ExceptionList = &pvStack_10;
      puStack_164 = (undefined *)FUN_0054fda0();
      iStack_8 = CONCAT31(iStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
      puStack_168 = &UNK_00b9993b;
      FUN_0054e5e0();
    }
    puStack_164 = &stack0x0000000c;
    puStack_168 = (undefined *)0xb99689;
    ExceptionList = &pvStack_10;
    (**(code **)((param_1 & 0xfffffffe) + 4))();
  }
  iStack_8 = 0xc;
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    puStack_16c = &stack0x0000000c;
    puStack_164 = (undefined *)0x2;
    uStack_170 = 0xb99911;
    puStack_168 = puStack_16c;
    (**(code **)(param_1 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25456 ; VA 0x00b99940 ; FUN_00b99940 */

int __thiscall FUN_00b99940(undefined4 param_1,int param_2,int *param_3,int param_4)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  bool bVar4;
  bool bVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  uint uVar9;
  uint in_stack_00000020;
  undefined auStack_2c [4];
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fb1a8;
  pvStack_10 = ExceptionList;
  uStack_18 = param_1;
  iStack_14 = 0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    iVar8 = *(int *)(param_2 + 0xc);
    ExceptionList = &pvStack_10;
    iVar6 = FUN_00e2c3f0();
    if ((uint)*(ushort *)(iVar8 + 0x1d8) - (uint)*(ushort *)(iVar6 + 0x1d8) <=
        (uint)*(ushort *)(iVar6 + 0x1da)) {
      iStack_14 = param_2;
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      piStack_24 = param_3;
      bVar5 = true;
      bVar4 = false;
      puVar7 = &uStack_28;
      goto LAB_00b999ce;
    }
  }
  piStack_1c = (int *)0x0;
  puVar7 = &uStack_20;
  iStack_14 = 0;
  bVar5 = false;
  bVar4 = true;
LAB_00b999ce:
  piVar3 = (int *)puVar7[1];
  *puVar7 = 0;
  puVar7[1] = 0;
  if (bVar4) {
    if (piStack_1c != (int *)0x0) {
      LOCK();
      iVar8 = piStack_1c[1] + -1;
      piStack_1c[1] = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)*piStack_1c)();
        LOCK();
        iVar8 = piStack_1c[2] + -1;
        piStack_1c[2] = iVar8;
        UNLOCK();
        if (iVar8 == 0) {
          (**(code **)(*piStack_1c + 4))();
        }
      }
    }
  }
  piVar2 = piStack_24;
  if ((bVar5) && (piStack_24 != (int *)0x0)) {
    LOCK();
    iVar8 = piStack_24[1] + -1;
    piStack_24[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar8 = *piVar1 + -1;
      *piVar1 = iVar8;
      UNLOCK();
      if (iVar8 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iStack_14 != 0) {
    FUN_0054ef60(&param_4);
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    iVar8 = FUN_00b1ba80(param_2,param_3);
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar2 = piVar3 + 1;
      iVar6 = *piVar2;
      iVar8 = *piVar2;
      *piVar2 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        (**(code **)*piVar3)();
        LOCK();
        piVar2 = piVar3 + 2;
        iVar6 = *piVar2;
        iVar8 = *piVar2;
        *piVar2 = iVar6 + -1;
        UNLOCK();
        if (iVar6 + -1 == 0) {
          iVar8 = (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      piVar3 = param_3 + 1;
      iVar6 = *piVar3;
      iVar8 = *piVar3;
      *piVar3 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        iVar8 = (**(code **)*param_3)();
        LOCK();
        piVar3 = param_3 + 2;
        iVar6 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          iVar8 = (**(code **)(*param_3 + 4))();
        }
      }
    }
    if (0xf < in_stack_00000020) {
      uVar9 = in_stack_00000020 + 1;
      iVar8 = param_4;
      if (0xfff < uVar9) {
        iVar8 = *(int *)(param_4 + -4);
        uVar9 = in_stack_00000020 + 0x24;
        if (0x1f < (param_4 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      iVar8 = FUN_01674ea0(iVar8,uVar9);
    }
    ExceptionList = pvStack_10;
    return iVar8;
  }
  FUN_016756b0(auStack_2c,
               "GuiService:InspectPlayerFromHumanoidDescription - Expected a HumanoidDescription object."
              );
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_2c,&DAT_01c17198);
}



/* FUNCTION 25457 ; VA 0x00b99b50 ; FUN_00b99b50 */

void FUN_00b99b50(int param_1,int param_2)

{
  undefined uVar1;
  undefined auStack_14 [16];
  
  if ((param_2 < 1) && ((param_2 < 0 || (param_1 == 0)))) {
    FUN_016756b0(auStack_14,"GuiService:InspectPlayerFromUserId - Got invalid userId.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_14,&DAT_01c17198);
  }
  uVar1 = 0;
  FUN_005542c0("developerThroughUserId",0x16);
  FUN_00b99bc0(param_1,param_2,uVar1);
  return;
}



/* FUNCTION 25458 ; VA 0x00b99bc0 ; FUN_00b99bc0 */

void FUN_00b99bc0(int param_1,int param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  uint in_stack_00000020;
  undefined auStack_20 [16];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aa158;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if ((param_2 < 1) && ((param_2 < 0 || (param_1 == 0)))) {
    ExceptionList = &pvStack_10;
    FUN_016756b0(auStack_20,"GuiService:InspectPlayerFromUserId - Got invalid userId.");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_20,&DAT_01c17198);
  }
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_3);
  FUN_00b92030(param_1,param_2);
  if (0xf < in_stack_00000020) {
    uVar2 = in_stack_00000020 + 1;
    iVar1 = param_3;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_3 + -4);
      uVar2 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25459 ; VA 0x00b99c80 ; FUN_00b99c80 */

int * FUN_00b99c80(int param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char cVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  undefined4 *puVar8;
  uint uVar9;
  int *piVar10;
  undefined *puStack_90;
  int iStack_8c;
  undefined *puStack_88;
  char *pcStack_84;
  int **ppiStack_80;
  undefined auStack_70 [24];
  undefined auStack_58 [4];
  int *piStack_54;
  undefined auStack_50 [4];
  int *piStack_4c;
  int iStack_48;
  int *piStack_44;
  undefined auStack_40 [4];
  undefined auStack_3c [4];
  int *piStack_38;
  undefined auStack_34 [4];
  int *piStack_30;
  int *piStack_2c;
  int *piStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb212;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  if ((char)param_2 == '\0') {
    ppiStack_80 = (int **)auStack_50;
    pcStack_84 = (char *)0xb99cd5;
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_00587490();
    uVar9 = 2;
  }
  else {
    ppiStack_80 = (int **)auStack_58;
    pcStack_84 = (char *)0xb99cbf;
    ExceptionList = &pvStack_10;
    piVar5 = (int *)FUN_00587490();
    uVar9 = 1;
  }
  iStack_48 = *piVar5;
  piStack_44 = (int *)piVar5[1];
  *piVar5 = 0;
  piVar5[1] = 0;
  iStack_8 = 0;
  piStack_2c = piStack_44;
  iStack_20 = iStack_48;
  uStack_18 = uVar9;
  if (((uVar9 & 2) != 0) &&
     (uVar9 = uVar9 & 0xfffffffd, uStack_18 = uVar9, piStack_4c != (int *)0x0)) {
    LOCK();
    piVar10 = piStack_4c + 1;
    iVar6 = *piVar10;
    piVar5 = (int *)*piVar10;
    *piVar10 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      ppiStack_80 = (int **)0xb99d26;
      (**(code **)*piStack_4c)();
      LOCK();
      piVar10 = piStack_4c + 2;
      iVar6 = *piVar10;
      piVar5 = (int *)*piVar10;
      *piVar10 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        ppiStack_80 = (int **)0xb99d36;
        piVar5 = (int *)(**(code **)(*piStack_4c + 4))();
      }
    }
  }
  if (((uVar9 & 1) != 0) &&
     (uVar9 = uVar9 & 0xfffffffe, uStack_18 = uVar9, piStack_54 != (int *)0x0)) {
    LOCK();
    piVar10 = piStack_54 + 1;
    iVar6 = *piVar10;
    piVar5 = (int *)*piVar10;
    *piVar10 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      ppiStack_80 = (int **)0xb99d57;
      (**(code **)*piStack_54)();
      LOCK();
      piVar10 = piStack_54 + 2;
      iVar6 = *piVar10;
      piVar5 = (int *)*piVar10;
      *piVar10 = iVar6 + -1;
      UNLOCK();
      if (iVar6 + -1 == 0) {
        ppiStack_80 = (int **)0xb99d67;
        piVar5 = (int *)(**(code **)(*piStack_54 + 4))();
      }
    }
  }
  if (iStack_20 != param_1) {
    ppiStack_80 = (int **)iStack_1c;
    pcStack_84 = (char *)0xb99d7c;
    iStack_24 = FUN_00b7a450();
    cStack_11 = *(char *)(iStack_24 + 0x70);
    if (param_1 != 0) {
      ppiStack_80 = (int **)0xb99d93;
      iVar6 = FUN_00b8e990();
      if (iVar6 == 0) {
        ppiStack_80 = (int **)auStack_70;
        pcStack_84 = (char *)0xb9a0d2;
        FUN_008a2380();
        iStack_8 = CONCAT31(iStack_8._1_3_,1);
        ppiStack_80 = (int **)0xb9a0dd;
        ppiStack_80 = (int **)FUN_005543f0();
        puStack_88 = auStack_40;
        pcStack_84 = 
        "Cannot set GuiService.SelectedObject to %s because it is not a descendant of a PlayerGui";
        iStack_8c = 0xb9a0ec;
        FUN_016756b0();
        pcStack_84 = auStack_40;
        ppiStack_80 = (int **)&DAT_01c17198;
                    /* WARNING: Subroutine does not return */
        puStack_88 = &UNK_00b9a0fd;
        FUN_0170c2a8();
      }
    }
    if (iStack_20 != 0) {
      ppiStack_80 = (int **)0xb99dad;
      FUN_006eccd0();
      iVar6 = *(int *)(iStack_20 + 0xc);
      ppiStack_80 = (int **)0xb99db8;
      iVar7 = FUN_00c6dcc0();
      if ((uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
          (uint)*(ushort *)(iVar7 + 0x1da)) {
        ppiStack_80 = (int **)0xb99ddd;
        FUN_00c75d90();
        if (((DAT_01d67920 != '\0') && ((char)param_2 == '\0')) && (cStack_11 != '\0')) {
          ppiStack_80 = (int **)(int)*(float *)(iStack_24 + 0x78);
          pcStack_84 = (char *)(int)*(float *)(iStack_24 + 0x74);
          puStack_88 = (undefined *)0xb99e0c;
          FUN_006150c0();
        }
      }
      ppiStack_80 = (int **)0xb99e13;
      iVar6 = FUN_00817fa0();
      if (iVar6 != 0) {
        ppiStack_80 = (int **)0xb99e1e;
        FUN_00d66da0();
      }
    }
    ppiStack_80 = (int **)param_1;
    if ((char)param_2 == '\0') {
      pcStack_84 = auStack_3c;
      puStack_88 = (undefined *)0xb99e69;
      puVar8 = (undefined4 *)FUN_0060e0c0();
      uVar9 = uVar9 | 8;
      uVar2 = *puVar8;
      uVar3 = puVar8[1];
      *puVar8 = 0;
      puVar8[1] = 0;
      *(undefined4 *)(iStack_1c + 0x18c) = uVar2;
      piVar5 = *(int **)(iStack_1c + 400);
      *(undefined4 *)(iStack_1c + 400) = uVar3;
    }
    else {
      pcStack_84 = auStack_34;
      puStack_88 = (undefined *)0xb99e31;
      puVar8 = (undefined4 *)FUN_0060e0c0();
      uVar2 = *puVar8;
      uVar9 = uVar9 | 4;
      uVar3 = puVar8[1];
      *puVar8 = 0;
      puVar8[1] = 0;
      *(undefined4 *)(iStack_1c + 0x194) = uVar2;
      piVar5 = *(int **)(iStack_1c + 0x198);
      *(undefined4 *)(iStack_1c + 0x198) = uVar3;
    }
    uStack_18 = uVar9;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar6 = piVar5[2] + -1;
      piVar5[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        ppiStack_80 = (int **)0xb99eab;
        (**(code **)(*piVar5 + 4))();
      }
    }
    if (((uVar9 & 8) != 0) &&
       (uVar9 = uVar9 & 0xfffffff7, uStack_18 = uVar9, piStack_38 != (int *)0x0)) {
      LOCK();
      iVar6 = piStack_38[2] + -1;
      piStack_38[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        ppiStack_80 = (int **)0xb99ecb;
        (**(code **)(*piStack_38 + 4))();
      }
    }
    iStack_8 = 0;
    if (((uVar9 & 4) != 0) &&
       (uVar9 = uVar9 & 0xfffffffb, uStack_18 = uVar9, piStack_30 != (int *)0x0)) {
      LOCK();
      iVar6 = piStack_30[2] + -1;
      piStack_30[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        ppiStack_80 = (int **)0xb99ef2;
        (**(code **)(*piStack_30 + 4))();
      }
    }
    if (DAT_01d688d0 != '\0') {
      ppiStack_80 = (int **)0xb99f09;
      cVar4 = FUN_016793f0();
      if (cVar4 != '\0') {
        ppiStack_80 = (int **)0xb99f18;
        FUN_01679490();
      }
    }
    if (param_1 != 0) {
      ppiStack_80 = (int **)0xb99f2b;
      FUN_006eccd0();
      ppiStack_80 = (int **)0xb99f32;
      iVar6 = FUN_00817fa0();
      if (iVar6 != 0) {
        ppiStack_80 = (int **)0xb99f3d;
        FUN_00d66da0();
      }
      if (((DAT_01d67920 != '\0') && ((char)param_2 == '\0')) && (cStack_11 != '\0')) {
        ppiStack_80 = (int **)(int)*(float *)(iStack_24 + 0x78);
        pcStack_84 = (char *)(int)*(float *)(iStack_24 + 0x74);
        puStack_88 = (undefined *)0xb99f6c;
        FUN_006150c0();
      }
      if ((DAT_01d688d0 != '\0') && (*(int *)(param_1 + 0x170) != 0)) {
        iStack_24 = *(int *)(param_1 + 0x170) + 0x1a4;
        ppiStack_80 = (int **)DAT_02110da8;
        iStack_8._0_1_ = 3;
        pcStack_84 = (char *)0xb99f9e;
        piVar5 = (int *)FUN_01675290();
        pcStack_84 = (char *)0x1c;
        iStack_8._0_1_ = 4;
        puStack_88 = (undefined *)0xb99fae;
        piStack_30 = piVar5;
        piStack_38 = (int *)FUN_01674e20();
        if (piStack_38 == (int *)0x0) {
          piVar10 = (int *)0x0;
        }
        else {
          *piStack_38 = 0;
          piStack_38[1] = 1;
          piStack_38[2] = (int)FUN_00b969b0;
          piStack_38[3] = (int)_guard_check_icall;
          piStack_38[4] = 0;
          piStack_38[5] = iStack_24;
          piStack_38[6] = param_1;
          piVar10 = piStack_38;
        }
        pcStack_84 = (char *)0xb99ff2;
        ppiStack_80 = (int **)piVar10;
        FUN_016797d0();
        if (piVar10 != (int *)0x0) {
          LOCK();
          piVar10[1] = piVar10[1] + 1;
          UNLOCK();
        }
        uStack_18 = uVar9 | 0x10;
        iStack_8._0_1_ = 5;
        pcStack_84 = (char *)0xb9a015;
        ppiStack_80 = (int **)piVar5;
        piStack_28 = piVar10;
        FUN_01675290();
        ppiStack_80 = &piStack_28;
        iStack_8._0_1_ = 3;
        pcStack_84 = (char *)0xb9a02e;
        FUN_00614020();
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        ppiStack_80 = (int **)0xb9a03a;
        FUN_0056e750();
      }
    }
    if ((char)param_2 == '\0') {
      ppiStack_80 = (int **)&DAT_02130438;
    }
    else {
      ppiStack_80 = (int **)&DAT_02130474;
    }
    pcStack_84 = (char *)0xb9a05b;
    FUN_008a4940();
    ppiStack_80 = (int **)param_2;
    puStack_90 = (undefined *)&puStack_88;
    iStack_8c = param_1;
    FUN_0060e0c0();
    iStack_8._0_1_ = 6;
    FUN_0060e0c0(&puStack_90,iStack_20);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    piVar5 = (int *)FUN_00b91e50();
  }
  piVar10 = piStack_2c;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_2c + 1;
    iVar6 = *piVar1;
    piVar5 = (int *)*piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      ppiStack_80 = (int **)0xb9a0a5;
      piVar5 = (int *)(**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piVar10 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        ppiStack_80 = (int **)0xb9a0b4;
        piVar5 = (int *)(**(code **)(*piVar10 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 25460 ; VA 0x00b9a100 ; FUN_00b9a100 */

void FUN_00b9a100(int *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  
  puVar2 = (undefined4 *)*param_1;
  pcVar3 = (code *)*puVar2;
  FUN_00d88580(puVar2 + 3);
  if (puVar2[2] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[2] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar3)(puVar2[1],puVar2[2]);
  return;
}



/* FUNCTION 25461 ; VA 0x00b9a150 ; FUN_00b9a150 */

void FUN_00b9a150(undefined4 *param_1)

{
  (*(code *)*param_1)(param_1[4]);
  return;
}



/* FUNCTION 25462 ; VA 0x00b9a170 ; FUN_00b9a170 */

int FUN_00b9a170(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fb230;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar3 = *(uint *)*param_1;
  if (uVar3 == 0) {
    ExceptionList = &pvStack_10;
    uVar5 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar5);
  }
  ExceptionList = &pvStack_10;
  iVar4 = (**(code **)((uVar3 & 0xfffffffe) + 4))((uint *)*param_1 + 2);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 25463 ; VA 0x00b9a200 ; FUN_00b9a200 */

void FUN_00b9a200(undefined4 *param_1,int param_2)

{
  code *pcVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_0000001c;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017969d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&param_2);
  pcVar1 = (code *)*param_1;
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(aiStack_28);
  (*pcVar1)();
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25464 ; VA 0x00b9a2d0 ; FUN_00b9a2d0 */

code * FUN_00b9a2d0(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  code *pcVar4;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 *puStack_44;
  ulonglong uStack_40;
  code *pcStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 *puStack_1c;
  ulonglong uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fb250;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pcStack_30 = (code *)0x0;
  puVar3 = (undefined4 *)*param_1;
  pcVar4 = (code *)puVar3[4];
  ExceptionList = &pvStack_10;
  if (pcVar4 != (code *)0x0) {
    pcStack_30 = pcVar4;
    if (((uint)pcVar4 & 1) == 0) {
      uStack_40 = ZEXT48(&uStack_28);
      puStack_44 = puVar3 + 6;
      uStack_48 = 0xb9a334;
      ExceptionList = &pvStack_10;
      (**(code **)((uint)pcVar4 & 0xfffffffe))();
    }
    else {
      uStack_28 = puVar3[6];
      uStack_24 = puVar3[7];
      uStack_20 = puVar3[8];
      puStack_1c = (undefined4 *)puVar3[9];
      uStack_18 = *(ulonglong *)(puVar3 + 10);
      ExceptionList = &pvStack_10;
    }
  }
  pcVar4 = (code *)*puVar3;
  uStack_8._0_1_ = 1;
  if (pcStack_30 != (code *)0x0) {
    if (((uint)pcStack_30 & 1) == 0) {
      (**(code **)((uint)pcStack_30 & 0xfffffffe))(&uStack_28,&uStack_50,0);
    }
    else {
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
      uStack_48 = uStack_20;
      puStack_44 = puStack_1c;
      uStack_40 = uStack_18;
    }
  }
  (*pcVar4)();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((pcStack_30 != (code *)0x0) && (((uint)pcStack_30 & 1) == 0)) &&
     (pcStack_30 = *(code **)((uint)pcStack_30 & 0xfffffffe), pcStack_30 != (code *)0x0)) {
    pcStack_30 = (code *)(*pcStack_30)(&uStack_28,&uStack_28,2);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    pcStack_30 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pcStack_30 = (code *)(**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pcStack_30 = (code *)(**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcStack_30;
}



/* FUNCTION 25465 ; VA 0x00b9a3f0 ; FUN_00b9a3f0 */

void FUN_00b9a3f0(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar1 = *param_1;
  param_1 = &param_2;
  ExceptionList = &pvStack_10;
  FUN_00b8c070(param_1,uVar1,&param_1,0);
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    iVar2 = param_2;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_2 + -4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25466 ; VA 0x00b9a470 ; FUN_00b9a470 */

void FUN_00b9a470(int *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  uint uVar2;
  code *pcVar3;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  uint uStack_30;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb268;
  pvStack_10 = ExceptionList;
  uStack_30 = 0;
  puVar1 = (undefined4 *)*param_1;
  uVar2 = puVar1[4];
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_30 = uVar2;
    if ((uVar2 & 1) == 0) {
      uStack_3c = 0;
      uStack_44 = CONCAT44(&uStack_28,puVar1 + 6);
      uStack_48 = 0xb9a4cd;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_28 = puVar1[6];
      uStack_24 = puVar1[7];
      uStack_20 = puVar1[8];
      uStack_1c = puVar1[9];
      uStack_18 = *(undefined8 *)(puVar1 + 10);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_3c = param_2;
  pcVar3 = (code *)*puVar1;
  uStack_8 = 0;
  if (uStack_30 != 0) {
    if ((uStack_30 & 1) == 0) {
      (**(code **)(uStack_30 & 0xfffffffe))(&uStack_28,&uStack_54,0);
    }
    else {
      uStack_54 = uStack_28;
      uStack_50 = uStack_24;
      uStack_4c = uStack_20;
      uStack_48 = uStack_1c;
      uStack_44 = uStack_18;
    }
  }
  (*pcVar3)();
  uStack_8 = 1;
  if (((uStack_30 != 0) && ((uStack_30 & 1) == 0)) &&
     (*(code **)(uStack_30 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_30 & 0xfffffffe))(&uStack_28,&uStack_28,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25467 ; VA 0x00b9a570 ; FUN_00b9a570 */

void FUN_00b9a570(int *param_1)

{
  int iVar1;
  uint uVar2;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined4 uStack_40;
  int iStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb290;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  iStack_3c = iVar1 + 0x48;
  uStack_40 = 0xb9a5a6;
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  uStack_8 = 0;
  uStack_58 = CONCAT44(iVar1 + 0x30,0xb9a5be);
  FUN_0054ef60();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar2 = *(uint *)(iVar1 + 0x10);
  if (uVar2 != 0) {
    if ((uVar2 & 1) == 0) {
      (**(code **)(uVar2 & 0xfffffffe))(iVar1 + 0x18,&uStack_68,0);
    }
    else {
      uStack_68 = *(undefined4 *)(iVar1 + 0x18);
      uStack_64 = *(undefined4 *)(iVar1 + 0x1c);
      uStack_60 = *(undefined4 *)(iVar1 + 0x20);
      uStack_5c = *(undefined4 *)(iVar1 + 0x24);
      uStack_58 = *(undefined8 *)(iVar1 + 0x28);
    }
  }
  uStack_8 = 0xffffffff;
  FUN_00b8c1d0(iVar1 + 8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25468 ; VA 0x00b9a630 ; FUN_00b9a630 */

void FUN_00b9a630(undefined4 param_1,uint param_2)

{
  undefined uVar1;
  uint uVar2;
  uint uVar3;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_00000020;
  undefined4 in_stack_00000030;
  uint in_stack_00000034;
  uint in_stack_00000038;
  uint in_stack_00000058;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fb2c0;
  pvStack_10 = ExceptionList;
  puStack_20 = &param_2;
  uStack_8 = 3;
  puStack_1c = &stack0x00000020;
  puStack_18 = &stack0x00000038;
  puStack_14 = &stack0x00000058;
  ExceptionList = &pvStack_10;
  FUN_00b8bf40(param_1,param_1,&puStack_20,0);
  uStack_8._0_1_ = 2;
  if (0xf < in_stack_0000001c) {
    uVar3 = in_stack_0000001c + 1;
    uVar2 = param_2;
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(param_2 - 4);
      uVar3 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_2 = param_2 & 0xffffff00;
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000034) {
    uVar3 = in_stack_00000034 + 1;
    uVar2 = in_stack_00000020;
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(in_stack_00000020 - 4);
      uVar3 = in_stack_00000034 + 0x24;
      if (0x1f < (in_stack_00000020 - uVar2) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  in_stack_00000030 = 0;
  in_stack_00000034 = 0xf;
  in_stack_00000020 = in_stack_00000020 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (in_stack_00000038 != 0) {
    if (((in_stack_00000038 & 1) == 0) &&
       (*(code **)(in_stack_00000038 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000038 & 0xfffffffe))(&stack0x00000040,&stack0x00000040,2);
    }
    in_stack_00000038 = 0;
  }
  uStack_8 = 5;
  if (((in_stack_00000058 != 0) && ((in_stack_00000058 & 1) == 0)) &&
     (*(code **)(in_stack_00000058 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000058 & 0xfffffffe))(&stack0x00000060,&stack0x00000060,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25469 ; VA 0x00b9a7a0 ; FUN_00b9a7a0 */

void FUN_00b9a7a0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b9d9a0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25470 ; VA 0x00b9a7e0 ; FUN_00b9a7e0 */

void FUN_00b9a7e0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00b9da50();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25471 ; VA 0x00b9a820 ; FUN_00b9a820 */

void FUN_00b9a820(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b9dae0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25472 ; VA 0x00b9a860 ; FUN_00b9a860 */

void FUN_00b9a860(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_00b9db90();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 25473 ; VA 0x00b9a8a0 ; FUN_00b9a8a0 */

void FUN_00b9a8a0(int *param_1,int *param_2,int param_3)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar3 != 0) {
        iVar4 = FUN_005e5f00(iVar4);
        *param_2 = iVar4;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      puVar1 = (uint *)*param_2;
      if (puVar1 != (uint *)0x0) {
        uVar2 = *puVar1;
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(puVar1 + 2,puVar1 + 2,2);
            }
          }
          *puVar1 = 0;
        }
        FUN_01674ea0(puVar1,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1dee404);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<struct_boost::_bi::unspecified,class_boost::function<void___cdecl(void)>,class_boost::_bi::list0>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 25474 ; VA 0x00b9aa10 ; FUN_00b9aa10 */

void FUN_00b9aa10(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008c1ba0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 8);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x10,iVar3 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar3 + 8) = 0;
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dedf64);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>,class_G3D::Vector2),class_boost::_bi::list2<class_boost::_bi::value<class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 25475 ; VA 0x00b9ab80 ; FUN_00b9ab80 */

int * FUN_00b9ab80(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (param_1[2] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[2] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[2];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00b9ac62. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[2];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00b9abd6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dee78c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>)>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list5<class_boost::_bi::value<class_std::shared_ptr<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>)>_>_>,struct_boost::arg<1>,struct_boost::arg<2>,struct_boost::arg<3>,struct_boost::arg<4>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 25476 ; VA 0x00b9ac80 ; FUN_00b9ac80 */

void FUN_00b9ac80(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbc1f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x30);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_00b8fbb0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00d88a30();
        piVar1 = *(int **)(iVar3 + 8);
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar2 = piVar1[2] + -1;
          piVar1[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
        FUN_01674ea0(iVar3,0x30);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dee69c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::GuiObject>,class_RBX::Lua::WeakFunctionRef,bool),class_boost::_bi::list3<class_boost::_bi::value<class_std::weak_ptr<class_RBX::GuiObject>_>,class_boost::_bi::value<class_RBX::Lua::WeakFunctionRef>,class_boost::_bi::value<bool>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 25477 ; VA 0x00b9ade0 ; FUN_00b9ade0 */

int * FUN_00b9ade0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      piVar3 = (int *)param_1[3];
      param_2[3] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[3];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00b9aec8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[3];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00b9ae36. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dee03c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf1<void,class_RBX::GuiService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::list2<class_boost::_bi::value<class_std::shared_ptr<class_RBX::GuiService>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 25478 ; VA 0x00b9aee0 ; FUN_00b9aee0 */

void FUN_00b9aee0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbc1f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x30);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        FUN_00b902d0(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a7c840();
        FUN_01674ea0(iVar3,0x30);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dee11c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf1<void,class_RBX::GuiService,class_boost::function<void___cdecl(void)>_>,class_boost::_bi::list2<class_boost::_bi::value<class_std::shared_ptr<class_RBX::GuiService>_>,class_boost::_bi::value<class_boost::function<void___cdecl(void)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 25479 ; VA 0x00b9b040 ; FUN_00b9b040 */

int * FUN_00b9b040(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      piVar3 = (int *)param_1[4];
      param_2[4] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[3];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00b9b12e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[3];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00b9b096. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1dee5d4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf1<void,class_RBX::GuiService,enum_RBX::GuiService::GuiType>,class_boost::_bi::list2<class_boost::_bi::value<class_std::shared_ptr<class_RBX::GuiService>_>,class_boost::_bi::value<enum_RBX::GuiService::GuiType>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 25480 ; VA 0x00b9b150 ; FUN_00b9b150 */

void FUN_00b9b150(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbc1f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x30);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        FUN_00b902d0(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a7c840();
        FUN_01674ea0(iVar3,0x30);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dee1f4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf2<void,class_RBX::GuiService,class_boost::function<void___cdecl(void)>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::list3<class_boost::_bi::value<class_std::shared_ptr<class_RBX::GuiService>_>,class_boost::_bi::value<class_boost::function<void___cdecl(void)>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 25481 ; VA 0x00b9b2b0 ; FUN_00b9b2b0 */

void FUN_00b9b2b0(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017cbc1f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x30);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        puVar2[1] = puVar1[1];
        FUN_00b902d0(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_00a7c840();
        FUN_01674ea0(iVar3,0x30);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dee31c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf2<void,class_RBX::GuiService,class_boost::function<void___cdecl(void)>,bool>,class_boost::_bi::list3<class_boost::_bi::value<class_std::shared_ptr<class_RBX::GuiService>_>,class_boost::_bi::value<class_boost::function<void___cdecl(void)>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 25482 ; VA 0x00b9b410 ; FUN_00b9b410 */

void FUN_00b9b410(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb2ef;
  pvStack_10 = ExceptionList;
  if (param_3 == 4) {
    *param_2 = (int)&boost::_bi::
                     bind_t<void,class_boost::_mfi::mf3<void,class_RBX::GuiService,class_boost::function<void___cdecl(void)>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::list4<class_boost::_bi::value<class_std::shared_ptr<class_RBX::GuiService>_>,class_boost::_bi::value<class_boost::function<void___cdecl(void)>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>_>
                     ::RTTI_Type_Descriptor;
    *(undefined2 *)(param_2 + 1) = 0;
    return;
  }
  if (param_3 == 0) {
    puVar1 = (undefined4 *)*param_1;
    ExceptionList = &pvStack_10;
    puVar2 = (undefined4 *)FUN_01674e20(0x60);
    uStack_8 = 0;
    if (puVar2 == (undefined4 *)0x0) {
      puVar2 = (undefined4 *)0x0;
    }
    else {
      *puVar2 = *puVar1;
      puVar2[1] = puVar1[1];
      FUN_00b902d0(puVar1 + 2);
      uStack_8._0_1_ = 1;
      FUN_0054ef60(puVar1 + 0xc);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_0054ef60(puVar1 + 0x12);
    }
    *param_2 = (int)puVar2;
    ExceptionList = pvStack_10;
    return;
  }
  if (param_3 == 1) {
    *param_2 = *param_1;
    *param_1 = 0;
    return;
  }
  if (param_3 == 2) {
    iVar3 = *param_2;
    if (iVar3 != 0) {
      ExceptionList = &pvStack_10;
      FUN_00b91300();
      FUN_01674ea0(iVar3,0x60);
    }
    *param_2 = 0;
    ExceptionList = pvStack_10;
    return;
  }
  if (param_3 != 3) {
    *param_2 = (int)&boost::_bi::
                     bind_t<void,class_boost::_mfi::mf3<void,class_RBX::GuiService,class_boost::function<void___cdecl(void)>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::list4<class_boost::_bi::value<class_std::shared_ptr<class_RBX::GuiService>_>,class_boost::_bi::value<class_boost::function<void___cdecl(void)>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_boost::_bi::value<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>_>
                     ::RTTI_Type_Descriptor;
    *(undefined2 *)(param_2 + 1) = 0;
    return;
  }
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0170d8dd(*param_2 + 4,0x1dee464);
  if (iVar3 == 0) {
    *param_2 = *param_1;
    ExceptionList = pvStack_10;
    return;
  }
  *param_2 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25483 ; VA 0x00b9b5a0 ; FUN_00b9b5a0 */

void __thiscall FUN_00b9b5a0(undefined4 param_1,undefined4 *param_2)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_ffffff58;
  undefined4 uVar5;
  undefined4 in_stack_ffffff5c;
  undefined4 in_stack_ffffff60;
  undefined4 in_stack_ffffff64;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined auStack_8c [124];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fb313;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (DAT_01d67908 != '\0') {
    uVar7 = 0xb9b5d4;
    ExceptionList = &pvStack_10;
    iVar2 = FUN_00b8e650(param_1);
    if (iVar2 != 0) {
      FUN_0054ef60(&param_2);
      FUN_00ea08b0(in_stack_ffffff58,in_stack_ffffff5c,in_stack_ffffff60,in_stack_ffffff64,uVar7,
                   param_1);
    }
    goto LAB_00b9b6bb;
  }
  puVar3 = &param_2;
  if (0xf < in_stack_00000018) {
    puVar3 = param_2;
  }
  ExceptionList = &pvStack_10;
  FUN_0151bda0(auStack_8c,puVar3,in_stack_00000014);
  uVar7 = 0;
  puVar3 = &param_2;
  if (0xf < in_stack_00000018) {
    puVar3 = param_2;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar5 = 0xb9b636;
  cVar1 = FUN_014cd610(puVar3,0);
  if (cVar1 == '\0') {
    cVar1 = FUN_0151c660("www.youtube.com");
    if (cVar1 != '\0') {
      cVar1 = FUN_0151ce60("/watch");
      if (cVar1 != '\0') goto LAB_00b9b678;
    }
    FUN_0086edd0(2,"GuiService::OpenBrowserWindow() was called on non-whitelisted url.",6);
  }
  else {
LAB_00b9b678:
    uVar8 = 1;
    uVar6 = 0xb9b680;
    cVar1 = FUN_0097c970(param_1,1);
    if (cVar1 == '\0') {
      FUN_0086edd0(2,
                   "GuiService::OpenBrowserWindow() was called on not a client (use local scripts on this call)."
                   ,6);
    }
    else {
      FUN_0054ef60(&param_2);
      FUN_006ecaa0(uVar5,puVar3,uVar7,uVar6,param_1,uVar8);
    }
  }
  FUN_0056d9d0();
LAB_00b9b6bb:
  if (0xf < in_stack_00000018) {
    uVar4 = in_stack_00000018 + 1;
    puVar3 = param_2;
    if (0xfff < uVar4) {
      puVar3 = (undefined4 *)param_2[-1];
      uVar4 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25484 ; VA 0x00b9b710 ; FUN_00b9b710 */

void FUN_00b9b710(uint param_1)

{
  char cVar1;
  int iVar2;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  int in_stack_0000001c;
  uint in_stack_00000030;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fb340;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (DAT_01d67908 == '\0') {
    ExceptionList = &pvStack_10;
    cVar1 = FUN_014cd610();
    if (cVar1 == '\0') {
      FUN_0086edd0();
    }
    else {
      cVar1 = FUN_0097c970();
      if (cVar1 == '\0') {
        FUN_0086edd0();
      }
      else {
        FUN_0054ef60(&stack0x0000001c);
        uStack_8._0_1_ = 3;
        FUN_0054ef60(&param_1);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_0096ea40();
      }
    }
  }
  else {
    ExceptionList = &pvStack_10;
    iVar2 = FUN_00b8e650();
    if (iVar2 != 0) {
      FUN_0054ef60(&stack0x0000001c);
      uStack_8._0_1_ = 2;
      FUN_0054ef60(&param_1);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_00ea0ac0();
    }
  }
  if (0xf < in_stack_00000018) {
    if ((0xfff < in_stack_00000018 + 1) && (0x1f < (param_1 - *(int *)(param_1 - 4)) - 4)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  if (0xf < in_stack_00000030) {
    if ((0xfff < in_stack_00000030 + 1) &&
       (0x1f < (in_stack_0000001c - *(int *)(in_stack_0000001c + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25485 ; VA 0x00b9b890 ; FUN_00b9b890 */

undefined4 __thiscall FUN_00b9b890(int param_1,int *param_2)

{
  char cVar1;
  undefined uVar2;
  byte bVar3;
  undefined *puVar4;
  int iVar5;
  int *piVar6;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined8 uStack_54;
  undefined auStack_4c [4];
  undefined4 uStack_48;
  undefined4 *puStack_44;
  int iStack_40;
  undefined **ppuStack_3c;
  int iStack_38;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  uint uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  piVar6 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb360;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined *)0x0;
  if (DAT_01d67918 == '\0') {
    if (DAT_01d6e86c == '\0') goto LAB_00b9b9a8;
    if ((*(int *)(*param_2 + 0x54) != 0x14) && (*(int *)(*param_2 + 0x54) != 8)) goto LAB_00b9b9a0;
    iStack_38 = 0xb9b8eb;
    ExceptionList = &pvStack_10;
    cVar1 = FUN_00d81930();
    puVar4 = puStack_14;
    if (cVar1 == '\0') {
      iStack_38 = 0xb9b8f6;
      cVar1 = FUN_00d819a0();
      puVar4 = puStack_14;
      if (cVar1 != '\0') goto LAB_00b9b91e;
      iStack_38 = *piVar6 + 0x90;
      ppuStack_3c = (undefined **)0xb9b90a;
      FUN_0054ef60();
      puVar4 = (undefined *)0x5;
      if (iStack_1c != 1) goto LAB_00b9b91e;
      param_2 = (int *)CONCAT13(1,param_2._0_3_);
    }
    else {
LAB_00b9b91e:
      param_2 = (int *)((uint)param_2 & 0xffffff);
    }
    if (((uint)puVar4 & 1) != 0) {
      iStack_38 = 0xb9b92e;
      FUN_005507b0();
    }
    if (param_2._3_1_ == '\0') {
      ExceptionList = pvStack_10;
      return 0;
    }
    iStack_38 = *piVar6 + 0x90;
    ppuStack_3c = (undefined **)0xb9b948;
    FUN_0054ef60();
    iStack_38 = 1;
    puStack_44 = &uStack_2c;
    if (0xf < uStack_18) {
      puStack_44 = uStack_2c;
    }
    ppuStack_3c = (undefined **)&DAT_018c36fc;
    iStack_40 = iStack_1c;
    uStack_48 = 0xb9b963;
    uVar2 = FUN_0055c360();
    param_2 = (int *)CONCAT13(uVar2,param_2._0_3_);
    iStack_38 = 0xb9b971;
    FUN_005507b0();
    if (param_2._3_1_ == '\0') {
      ExceptionList = pvStack_10;
      return 0;
    }
LAB_00b9b97b:
    iStack_38 = 5;
  }
  else {
LAB_00b9b9a0:
    ExceptionList = &pvStack_10;
    if (DAT_01d6e86c == '\0') {
LAB_00b9b9a8:
      iStack_38 = 0xb9b9af;
      ExceptionList = &pvStack_10;
      cVar1 = FUN_00d81270();
      if (cVar1 == '\0') {
        iStack_38 = 0xb9b9b8;
        cVar1 = FUN_00554b40();
        if ((cVar1 == '\0') || (*(int *)(*piVar6 + 0x54) != 8)) goto LAB_00b9bb4e;
      }
      iStack_38 = 0xb9b9d3;
      cVar1 = FUN_00d81930();
      if (cVar1 != '\0') {
        ExceptionList = pvStack_10;
        return 0;
      }
      iStack_38 = 0xb9b9e2;
      cVar1 = FUN_00d819a0();
      if (cVar1 != '\0') {
        ExceptionList = pvStack_10;
        return 0;
      }
      if (DAT_01d67918 == '\0') {
        if (*(char *)(*piVar6 + 0xbc) != '/') {
          iStack_38 = 0xb9ba03;
          cVar1 = FUN_00554b40();
          if (cVar1 != '\0') {
            iStack_38 = *piVar6 + 0x90;
            ppuStack_3c = (undefined **)0xb9ba17;
            FUN_0054ef60();
            puStack_14 = (undefined *)0x12;
            iStack_38 = 1;
            puStack_44 = &uStack_2c;
            if (0xf < uStack_18) {
              puStack_44 = uStack_2c;
            }
            ppuStack_3c = (undefined **)&DAT_018c36fc;
            iStack_40 = iStack_1c;
            uStack_48 = 0xb9ba39;
            iVar5 = FUN_0055c2d0();
            if (iVar5 == 0) goto LAB_00b9ba40;
          }
          goto LAB_00b9ba46;
        }
LAB_00b9ba40:
        param_2 = (int *)CONCAT13(1,param_2._0_3_);
      }
      else {
LAB_00b9ba46:
        param_2 = (int *)((uint)param_2 & 0xffffff);
      }
      if (((uint)puStack_14 & 2) != 0) {
        iStack_38 = 0xb9ba58;
        FUN_005507b0();
      }
      if (param_2._3_1_ == '\0') {
        iStack_38 = (int)*(char *)(*piVar6 + 0xbc);
        ppuStack_3c = (undefined **)0xb9ba73;
        bVar3 = FUN_01725677();
        iStack_38 = (int)&param_2 + 3;
        ppuStack_3c = &puStack_14;
        iStack_40 = 0xb9ba8c;
        param_2._3_1_ = bVar3;
        piVar6 = (int *)FUN_00b97540();
        if (*piVar6 == *(int *)(param_1 + 0x1d8)) {
          ExceptionList = pvStack_10;
          return 0;
        }
        iStack_1c = 0;
        uStack_18 = 0xf;
        uStack_2c = (undefined4 *)((uint)uStack_2c & 0xffffff00);
        puStack_14 = auStack_4c;
        uStack_8 = 0;
        ppuStack_3c = (undefined **)0x0;
        iStack_38 = 0xf;
        uStack_54 = 0x18bc9b8;
        auStack_4c[0] = 0;
        uStack_58 = 0xb9bad8;
        FUN_005542c0();
        puStack_14 = (undefined *)&uStack_64;
        uStack_2c._0_2_ = (ushort)param_2._3_1_;
        uStack_64 = uStack_2c;
        uStack_60 = uStack_28;
        uStack_5c = uStack_24;
        uStack_58 = uStack_20;
        uStack_54 = CONCAT44(uStack_18,1);
        iStack_1c = 0;
        uStack_18 = 0xf;
        uStack_2c = (undefined4 *)((uint)uStack_2c._2_2_ << 0x10);
        uStack_8 = uStack_8 & 0xffffff00;
        FUN_0096ea40();
        iStack_38 = 0xb9bb3a;
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return 1;
      }
      goto LAB_00b9b97b;
    }
LAB_00b9bb4e:
    switch(*(int *)(*piVar6 + 0xa8) + -0x115) {
    case 0:
      iStack_38 = 0;
      break;
    case 1:
      iStack_38 = 1;
      break;
    case 2:
      iStack_38 = 2;
      break;
    case 3:
      iStack_38 = 3;
      break;
    case 4:
      iStack_38 = 4;
      break;
    default:
      goto switchD_00b9bb60_caseD_5;
    }
  }
  ppuStack_3c = (undefined **)0xb9b984;
  cVar1 = FUN_00b92460();
  if (cVar1 != '\0') {
    ExceptionList = pvStack_10;
    return 1;
  }
switchD_00b9bb60_caseD_5:
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 25486 ; VA 0x00b9bbc0 ; FUN_00b9bbc0 */

void __thiscall FUN_00b9bbc0(undefined4 *param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  
  iVar1 = *(int *)*param_1;
  puVar2 = *(undefined4 **)(iVar1 + 4);
  uVar3 = FUN_00602bf0(iVar1,puVar2,param_2);
  if (param_1[1] != 0x15555554) {
    param_1[1] = param_1[1] + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puVar2 = uVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 25487 ; VA 0x00b9bc10 ; FUN_00b9bc10 */

void FUN_00b9bc10(int param_1,char param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int *piVar4;
  
  piVar4 = (int *)(param_1 + 8);
  if (*piVar4 != 1) {
    if (2 < *piVar4 - 2U) {
      return;
    }
    FUN_00b91890(piVar4);
    FUN_00b9bbc0(&param_1);
    return;
  }
  piVar4 = (int *)FUN_00b91890(piVar4);
  if (param_2 == '\0') {
    iVar1 = *piVar4;
    puVar2 = *(undefined4 **)(iVar1 + 4);
    uVar3 = FUN_00602bf0(iVar1,puVar2,&param_1);
    if (piVar4[1] != 0x15555554) {
      piVar4[1] = piVar4[1] + 1;
      *(undefined4 *)(iVar1 + 4) = uVar3;
      *puVar2 = uVar3;
      return;
    }
  }
  else {
    iVar1 = *(int *)*piVar4;
    puVar2 = *(undefined4 **)(iVar1 + 4);
    uVar3 = FUN_00602bf0(iVar1,puVar2,&param_1);
    if (piVar4[1] != 0x15555554) {
      piVar4[1] = piVar4[1] + 1;
      *(undefined4 *)(iVar1 + 4) = uVar3;
      *puVar2 = uVar3;
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 25488 ; VA 0x00b9bc47 ; FUN_00b9bc47 */

void __fastcall FUN_00b9bc47(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined4 uVar4;
  int unaff_EBP;
  
  piVar3 = (int *)FUN_00b91890(param_2);
  if (*(char *)(unaff_EBP + 0xc) == '\0') {
    iVar1 = *piVar3;
    puVar2 = *(undefined4 **)(iVar1 + 4);
    uVar4 = FUN_00602bf0(iVar1,puVar2,unaff_EBP + 8);
    if (piVar3[1] != 0x15555554) {
      piVar3[1] = piVar3[1] + 1;
      *(undefined4 *)(iVar1 + 4) = uVar4;
      *puVar2 = uVar4;
      return;
    }
  }
  else {
    iVar1 = *(int *)*piVar3;
    puVar2 = *(undefined4 **)(iVar1 + 4);
    uVar4 = FUN_00602bf0(iVar1,puVar2,unaff_EBP + 8);
    if (piVar3[1] != 0x15555554) {
      piVar3[1] = piVar3[1] + 1;
      *(undefined4 *)(iVar1 + 4) = uVar4;
      *puVar2 = uVar4;
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 25489 ; VA 0x00b9bcd0 ; FUN_00b9bcd0 */

int * __thiscall FUN_00b9bcd0(int param_1,undefined4 param_2,int *param_3)

{
  uint uVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  int **ppiVar7;
  int **ppiVar8;
  int **ppiVar9;
  int *piVar10;
  int **ppiVar11;
  undefined auStack_9c [40];
  undefined4 uStack_74;
  undefined4 uStack_5c;
  int **ppiStack_58;
  int **ppiStack_54;
  int *piStack_50;
  undefined auStack_40 [12];
  int iStack_34;
  int *piStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fb388;
  pvStack_10 = ExceptionList;
  piStack_50 = &param_2;
  uStack_8 = 0;
  ppiStack_54 = (int **)&iStack_34;
  ppiStack_58 = (int **)0xb9bd07;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_00a13580();
  uStack_8._0_1_ = 1;
  if (iStack_34 == 0) {
    ppiStack_54 = (int **)auStack_40;
    piStack_50 = (int *)0x1959cec;
    ppiStack_58 = (int **)0xb9bfeb;
    FUN_016756b0();
    ppiStack_54 = (int **)auStack_40;
    piStack_50 = (int *)&DAT_01c17198;
                    /* WARNING: Subroutine does not return */
    ppiStack_58 = (int **)&UNK_00b9bffc;
    FUN_0170c2a8();
  }
  piStack_50 = (int *)iStack_34;
  ppiStack_54 = (int **)auStack_2c;
  ppiStack_58 = (int **)0xb9bd23;
  FUN_0060e0c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  piStack_50 = (int *)auStack_2c;
  ppiStack_54 = (int **)0xb9bd3e;
  piStack_20 = (int *)(param_1 + 0x1d0);
  piVar4 = (int *)FUN_00b91810();
  piVar10 = (int *)*piVar4;
  piStack_24 = piVar10;
  if (piVar10 == (int *)0x0) goto LAB_00b9bf40;
  piVar4 = *(int **)(param_1 + 0x1d0);
  piVar6 = (int *)piVar4[1];
  cVar3 = *(char *)((int)piVar6 + 0xd);
  piStack_1c = piVar4;
  piStack_14 = piVar6;
  while (cVar3 == '\0') {
    if ((int *)piStack_14[5] < piStack_28) {
      piVar5 = (int *)piStack_14[2];
      piStack_14 = piStack_1c;
    }
    else {
      if ((*(char *)((int)piVar4 + 0xd) != '\0') && (piStack_28 < (int *)piStack_14[5])) {
        piVar4 = piStack_14;
      }
      piVar5 = (int *)*piStack_14;
    }
    piStack_1c = piStack_14;
    piStack_14 = piVar5;
    cVar3 = *(char *)((int)piVar5 + 0xd);
  }
  if (*(char *)((int)piVar4 + 0xd) == '\0') {
    piVar6 = (int *)*piVar4;
  }
  cVar3 = *(char *)((int)piVar6 + 0xd);
  while (piStack_14 = piStack_1c, cVar3 == '\0') {
    if (piStack_28 < (int *)piVar6[5]) {
      piVar5 = (int *)*piVar6;
      piVar4 = piVar6;
    }
    else {
      piVar5 = (int *)piVar6[2];
    }
    piVar6 = piVar5;
    cVar3 = *(char *)((int)piVar5 + 0xd);
  }
  while (piStack_1c != piVar4) {
    piStack_50 = (int *)0xb9bdbb;
    FUN_00551320();
  }
  ppiStack_58 = &piStack_1c;
  uStack_5c = 0xb9bdd1;
  ppiStack_54 = (int **)piStack_14;
  piStack_50 = piVar4;
  FUN_00b96ac0();
  piStack_50 = piVar10 + 2;
  ppiStack_54 = (int **)0xb9bde3;
  piVar4 = (int *)FUN_00b91890();
  ppiVar9 = (int **)*piVar4;
  ppiVar7 = (int **)*ppiVar9;
  ppiVar11 = ppiVar9;
  piStack_1c = piVar4;
  if ((int **)*ppiVar9 != ppiVar9) {
    do {
      ppiVar9 = ppiVar11;
      if ((ppiVar7[2] == piVar10) && (ppiVar9 = ppiVar7, ppiVar7 + 2 != &piStack_20)) {
        ppiVar8 = (int **)*ppiVar7;
        piStack_50 = (int *)0xc;
        *ppiVar7[1] = (int)ppiVar8;
        (*ppiVar7)[1] = (int)ppiVar7[1];
        piStack_1c[1] = piStack_1c[1] + -1;
        ppiStack_58 = (int **)0xb9bfd0;
        ppiStack_54 = ppiVar7;
        FUN_01674ea0();
        piVar4 = piStack_1c;
      }
      else {
        ppiVar8 = (int **)*ppiVar7;
        ppiVar11 = ppiVar9;
      }
      ppiVar9 = (int **)*piVar4;
      ppiVar7 = ppiVar8;
    } while (ppiVar8 != ppiVar9);
  }
  if (ppiVar11 != ppiVar9) {
    piStack_50 = (int *)0xc;
    *ppiVar11[1] = (int)*ppiVar11;
    (*ppiVar11)[1] = (int)ppiVar11[1];
    piVar4[1] = piVar4[1] + -1;
    ppiStack_58 = (int **)0xb9be2d;
    ppiStack_54 = ppiVar11;
    FUN_01674ea0();
  }
  iVar2 = iStack_18;
  if (piVar10 == *(int **)(iStack_18 + 0x1c4)) {
    piStack_50 = (int *)0x4;
    *(undefined4 *)(iStack_18 + 0x1c4) = 0;
    ppiStack_54 = (int **)0xb9be52;
    cVar3 = FUN_00b9d920();
    if (cVar3 == '\0') {
      piStack_50 = (int *)0x3;
      ppiStack_54 = (int **)0xb9be5f;
      cVar3 = FUN_00b9d920();
      if (cVar3 == '\0') {
        piStack_50 = (int *)0x2;
        ppiStack_54 = (int **)0xb9be6c;
        cVar3 = FUN_00b9d920();
        if (cVar3 == '\0') {
          piStack_50 = (int *)0x1;
          ppiStack_54 = (int **)0xb9be79;
          cVar3 = FUN_00b9d920();
          if (cVar3 == '\0') goto LAB_00b9bec7;
        }
      }
    }
    piStack_50 = (int *)iVar2;
    ppiStack_54 = (int **)0xb9be83;
    FUN_008f7870();
    piStack_50 = (int *)0x1;
    uStack_74 = 0;
    FUN_0054f510(*(int *)(iStack_18 + 0x1c4) + 0x10);
    FUN_00b8da80(auStack_9c);
    FUN_00b8b170();
    uStack_74 = 0xb9bec4;
    FUN_0090ca30();
    piVar10 = piStack_24;
  }
LAB_00b9bec7:
  uVar1 = piVar10[0xc];
  uStack_8._0_1_ = 3;
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        piStack_50 = (int *)0x2;
        uStack_5c = 0xb9bee8;
        ppiStack_58 = (int **)(piVar10 + 0xe);
        ppiStack_54 = (int **)(piVar10 + 0xe);
        (**(code **)(uVar1 & 0xfffffffe))();
      }
    }
    piVar10[0xc] = 0;
  }
  uVar1 = piVar10[4];
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uVar1 != 0) {
    if ((uVar1 & 1) == 0) {
      if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
        piStack_50 = (int *)0x2;
        uStack_5c = 0xb9bf13;
        ppiStack_58 = (int **)(piVar10 + 6);
        ppiStack_54 = (int **)(piVar10 + 6);
        (**(code **)(uVar1 & 0xfffffffe))();
      }
    }
    piVar10[4] = 0;
  }
  piVar4 = (int *)piVar10[1];
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = piVar4[2] + -1;
    piVar4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      piStack_50 = (int *)0xb9bf35;
      (**(code **)(*piVar4 + 4))();
    }
  }
  piStack_50 = (int *)0x50;
  ppiStack_58 = (int **)0xb9bf3d;
  ppiStack_54 = (int **)piVar10;
  piVar4 = (int *)FUN_01674ea0();
LAB_00b9bf40:
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piVar10 = piStack_28 + 2;
    iVar2 = *piVar10;
    piVar4 = (int *)*piVar10;
    *piVar10 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_50 = (int *)0xb9bf55;
      piVar4 = (int *)(**(code **)(*piStack_28 + 4))();
    }
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    piVar10 = piStack_30 + 1;
    iVar2 = *piVar10;
    piVar4 = (int *)*piVar10;
    *piVar10 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_50 = (int *)0xb9bf6b;
      (**(code **)*piStack_30)();
      LOCK();
      piVar10 = piStack_30 + 2;
      iVar2 = *piVar10;
      piVar4 = (int *)*piVar10;
      *piVar10 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piStack_50 = (int *)0xb9bf7b;
        piVar4 = (int *)(**(code **)(*piStack_30 + 4))();
      }
    }
  }
  piVar10 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar6 = param_3 + 1;
    iVar2 = *piVar6;
    piVar4 = (int *)*piVar6;
    *piVar6 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_50 = (int *)0xb9bf91;
      piVar4 = (int *)(**(code **)*param_3)();
      LOCK();
      piVar6 = piVar10 + 2;
      iVar2 = *piVar6;
      *piVar6 = *piVar6 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_50 = (int *)0xb9bfa0;
        piVar4 = (int *)(**(code **)(*piVar10 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar4;
}



/* FUNCTION 25490 ; VA 0x00b9c000 ; FUN_00b9c000 */

void __thiscall FUN_00b9c000(int param_1,char *param_2)

{
  char *pcVar1;
  undefined4 uVar2;
  uint uVar3;
  int in_stack_00000014;
  uint in_stack_00000018;
  undefined auStack_24 [12];
  int iStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (DAT_01d6e86c == '\0') {
    if (in_stack_00000014 != 1) {
      ExceptionList = &pvStack_10;
      FUN_016756b0(auStack_24,"GuiService:RemoveKey requires a string with a single character");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_24,&DAT_01c17198);
    }
    pcVar1 = (char *)&param_2;
    if (0xf < in_stack_00000018) {
      pcVar1 = param_2;
    }
    ExceptionList = &pvStack_10;
    uStack_11 = FUN_01725677((int)*pcVar1);
    FUN_00b97540(&iStack_18,&uStack_11);
    if (iStack_18 != *(int *)(param_1 + 0x1d8)) {
      uVar2 = FUN_00553830(iStack_18);
      FUN_01674ea0(uVar2,0x10);
    }
    FUN_005507b0();
  }
  else if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    pcVar1 = param_2;
    if (0xfff < uVar3) {
      pcVar1 = *(char **)(param_2 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if ((char *)0x1f < param_2 + (-4 - (int)pcVar1)) {
        ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    ExceptionList = &pvStack_10;
    FUN_01674ea0(pcVar1,uVar3);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 25491 ; VA 0x00b9c110 ; FUN_00b9c110 */

void __thiscall FUN_00b9c110(int param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  
  piVar5 = *(int **)(param_1 + 0x1b8);
  if (piVar5 == *(int **)(param_1 + 0x1bc)) {
    return;
  }
  do {
    iVar1 = piVar5[1];
    if (iVar1 != 0) {
      piVar6 = (int *)(iVar1 + 4);
      iVar1 = *(int *)(iVar1 + 4);
      while (iVar1 != 0) {
        LOCK();
        iVar3 = *piVar6;
        if (iVar1 == iVar3) {
          *piVar6 = iVar1 + 1;
          iVar3 = iVar1;
        }
        UNLOCK();
        if (iVar3 == iVar1) {
          piVar6 = (int *)piVar5[1];
          if ((*piVar5 != 0) && (*piVar5 == param_2)) {
            piVar5 = piVar5 + 2;
            piVar4 = *(int **)(param_1 + 0x1bc);
            if (piVar5 != piVar4) {
              do {
                iVar1 = *piVar5;
                iVar3 = piVar5[1];
                *piVar5 = 0;
                piVar5[1] = 0;
                piVar5[-2] = iVar1;
                piVar2 = (int *)piVar5[-1];
                piVar5[-1] = iVar3;
                if (piVar2 != (int *)0x0) {
                  LOCK();
                  iVar1 = piVar2[2] + -1;
                  piVar2[2] = iVar1;
                  UNLOCK();
                  if (iVar1 == 0) {
                    (**(code **)(*piVar2 + 4))();
                  }
                }
                piVar5 = piVar5 + 2;
              } while (piVar5 != piVar4);
              piVar4 = *(int **)(param_1 + 0x1bc);
            }
            piVar5 = (int *)piVar4[-1];
            if (piVar5 != (int *)0x0) {
              LOCK();
              iVar1 = piVar5[2] + -1;
              piVar5[2] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)(*piVar5 + 4))();
              }
            }
            *(int *)(param_1 + 0x1bc) = *(int *)(param_1 + 0x1bc) + -8;
            if (piVar6 == (int *)0x0) {
              return;
            }
            LOCK();
            iVar1 = piVar6[1] + -1;
            piVar6[1] = iVar1;
            UNLOCK();
            if (iVar1 != 0) {
              return;
            }
            (**(code **)*piVar6)();
            LOCK();
            piVar5 = piVar6 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 != 1) {
              return;
            }
            (**(code **)(*piVar6 + 4))();
            return;
          }
          if (piVar6 != (int *)0x0) {
            LOCK();
            iVar1 = piVar6[1] + -1;
            piVar6[1] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)*piVar6)();
              LOCK();
              iVar1 = piVar6[2] + -1;
              piVar6[2] = iVar1;
              UNLOCK();
              if (iVar1 == 0) {
                (**(code **)(*piVar6 + 4))();
              }
            }
          }
          break;
        }
        iVar1 = *piVar6;
      }
    }
    piVar5 = piVar5 + 2;
    if (piVar5 == *(int **)(param_1 + 0x1bc)) {
      return;
    }
  } while( true );
}



/* FUNCTION 25492 ; VA 0x00b9c250 ; FUN_00b9c250 */

uint __thiscall FUN_00b9c250(int param_1,int param_2)

{
  uint uVar1;
  int *piVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  int *piVar8;
  bool bVar9;
  uint in_stack_00000018;
  int *piStack_c;
  int iStack_8;
  
  iVar7 = param_1 + 0x155 + (uint)*(byte *)(param_1 + 0x154);
  iStack_8 = param_1;
  uVar3 = FUN_0055c740(iVar7,&param_2);
  uVar4 = FUN_00562fc0(&piStack_c,uVar3,&param_2,-(uint)(iVar7 != 0) & iVar7 + 1U);
  if (piStack_c != (int *)0x0) {
    uVar5 = (uint)piStack_c[1] % *(uint *)(param_1 + 0x158);
    piVar2 = *(int **)(*(int *)(iStack_8 + 0x168) + uVar5 * 4);
    for (piVar8 = (int *)*piVar2; piVar8 != piStack_c; piVar8 = (int *)*piVar8) {
      piVar2 = piVar8;
    }
    uVar1 = iStack_8 + 0x158;
    bVar9 = iStack_8 != -0x157;
    piStack_c = (int *)*piStack_c;
    do {
      *piVar2 = *piVar8;
      FUN_00b8e8c0(-(uint)bVar9 & uVar1,piVar8 + 2);
      FUN_01674ea0(piVar8,0x30);
      *(int *)(iStack_8 + 0x15c) = *(int *)(iStack_8 + 0x15c) + -1;
      uVar6 = uVar5;
      if (*piVar2 == 0) {
LAB_00b9c323:
        uVar4 = *(uint *)(iStack_8 + 0x168);
        if (*(int **)(uVar4 + uVar5 * 4) == piVar2) {
          *(undefined4 *)(uVar4 + uVar5 * 4) = 0;
        }
      }
      else {
        uVar6 = *(uint *)(*piVar2 + 4);
        uVar4 = uVar6 / *(uint *)(iStack_8 + 0x158);
        uVar6 = uVar6 % *(uint *)(iStack_8 + 0x158);
        if (uVar5 != uVar6) {
          *(int **)(*(int *)(iStack_8 + 0x168) + uVar6 * 4) = piVar2;
          goto LAB_00b9c323;
        }
      }
      piVar8 = (int *)*piVar2;
      uVar5 = uVar6;
    } while (piVar8 != piStack_c);
  }
  if (0xf < in_stack_00000018) {
    uVar4 = in_stack_00000018 + 1;
    iVar7 = param_2;
    if (0xfff < uVar4) {
      iVar7 = *(int *)(param_2 + -4);
      uVar4 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uVar4 = FUN_01674ea0(iVar7,uVar4);
  }
  return uVar4;
}



/* FUNCTION 25493 ; VA 0x00b9c390 ; FUN_00b9c390 */

undefined __thiscall FUN_00b9c390(int param_1,undefined4 param_2,undefined4 *param_3)

{
  code **ppcVar1;
  code **ppcVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  int in_stack_00000020;
  uint in_stack_00000034;
  code *apcStack_174 [2];
  undefined4 uStack_16c;
  undefined4 uStack_168;
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined8 uStack_15c;
  code *pcStack_154;
  int iStack_150;
  uint *puStack_14c;
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined4 *apuStack_140 [3];
  undefined4 uStack_134;
  undefined4 *puStack_130;
  undefined4 *puStack_12c;
  undefined *puStack_128;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined auStack_114 [40];
  undefined auStack_ec [24];
  undefined auStack_d4 [24];
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined auStack_b4 [40];
  undefined auStack_8c [24];
  undefined auStack_74 [24];
  uint auStack_5c [2];
  undefined4 auStack_54 [6];
  code *pcStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017fb40e;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (*(int *)(param_1 + 0xb0) == 0) {
    param_2._3_1_ = 0;
    ExceptionList = &pvStack_10;
  }
  else {
    puStack_128 = (undefined *)0x0;
    uStack_144 = param_2;
    pcStack_154 = (code *)&puStack_14c;
    uStack_15c = CONCAT44(0xb9c3dc,(undefined4)uStack_15c);
    ExceptionList = &pvStack_10;
    iStack_150 = param_1;
    FUN_0060dcd0();
    iStack_150 = 0;
    pcStack_154 = FUN_00b9e230;
    uStack_15c = CONCAT44(apuStack_140,0xb9c3ec);
    FUN_00b8e520();
    uStack_144 = 0xb9c3f7;
    FUN_00b8b930();
    uStack_8._0_1_ = 2;
    apuStack_140[0] = &stack0x00000020;
    uStack_144 = 0xb9c412;
    FUN_0054ef60();
    puStack_14 = (undefined *)&pcStack_154;
    uStack_8._0_1_ = 3;
    uStack_15c = CONCAT44(&param_3,0xb9c427);
    FUN_0054ef60();
    puStack_1c = (undefined *)apcStack_174;
    puStack_18 = (undefined *)apcStack_174;
    uStack_8._0_1_ = 4;
    apcStack_174[0] = (code *)0x0;
    ppcVar1 = apcStack_174;
    ppcVar2 = apcStack_174;
    if (pcStack_3c != (code *)0x0) {
      apcStack_174[0] = pcStack_3c;
      if (((uint)pcStack_3c & 1) == 0) {
        (**(code **)((uint)pcStack_3c & 0xfffffffe))();
        ppcVar1 = (code **)puStack_1c;
        ppcVar2 = (code **)puStack_18;
      }
      else {
        uStack_16c = uStack_34;
        uStack_168 = uStack_30;
        uStack_164 = uStack_2c;
        uStack_160 = uStack_28;
        uStack_15c = uStack_24;
        ppcVar1 = apcStack_174;
        ppcVar2 = apcStack_174;
      }
    }
    puStack_18 = (undefined *)ppcVar2;
    puStack_1c = (undefined *)ppcVar1;
    uStack_8._0_1_ = 5;
    FUN_0060dcd0();
    uStack_8._0_1_ = 2;
    FUN_00b8e030(&uStack_11c);
    uStack_bc = uStack_11c;
    uStack_b8 = uStack_118;
    puStack_128 = auStack_114;
    uStack_8._0_1_ = 6;
    puStack_12c = (undefined4 *)0xb9c4d0;
    FUN_00b902d0();
    puStack_128 = auStack_ec;
    uStack_8._0_1_ = 7;
    puStack_12c = (undefined4 *)0xb9c4e6;
    FUN_0054ef60();
    puStack_128 = auStack_d4;
    uStack_8._0_1_ = 8;
    puStack_12c = (undefined4 *)0xb9c4f9;
    FUN_0054ef60();
    auStack_5c[0] = 0;
    uStack_8._0_1_ = 9;
    FUN_00b902d0(auStack_b4);
    uStack_8._0_1_ = 10;
    FUN_0054ef60(auStack_8c);
    uStack_8._0_1_ = 0xb;
    FUN_0054ef60(auStack_74);
    uStack_8._0_1_ = 9;
    FUN_00b8d880();
    puStack_128 = (undefined *)0xb9c56b;
    FUN_00b91300();
    puStack_128 = (undefined *)0xb9c576;
    FUN_00b91300();
    uStack_8._0_1_ = 0xc;
    puStack_12c = (undefined4 *)0xb9c580;
    puStack_128 = (undefined *)param_1;
    FUN_008f7870();
    puStack_128 = (undefined *)0x1;
    puStack_14c = auStack_5c;
    uStack_148 = 0;
    iStack_150 = 0xb9c59e;
    FUN_005880d0();
    puStack_14c = (uint *)0xb9c5a5;
    FUN_0090ca30();
    uStack_8._0_1_ = 0xd;
    if (auStack_5c[0] != 0) {
      if (((auStack_5c[0] & 1) == 0) && (*(code **)(auStack_5c[0] & 0xfffffffe) != (code *)0x0)) {
        puStack_130 = auStack_54;
        puStack_128 = (undefined *)0x2;
        uStack_134 = 0xb9c5c6;
        puStack_12c = puStack_130;
        (**(code **)(auStack_5c[0] & 0xfffffffe))();
      }
      auStack_5c[0] = 0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
    if (((pcStack_3c != (code *)0x0) && (((uint)pcStack_3c & 1) == 0)) &&
       (*(code **)((uint)pcStack_3c & 0xfffffffe) != (code *)0x0)) {
      puStack_130 = &uStack_34;
      puStack_128 = (undefined *)0x2;
      uStack_134 = 0xb9c5f1;
      puStack_12c = puStack_130;
      (**(code **)((uint)pcStack_3c & 0xfffffffe))();
    }
    param_2._3_1_ = 1;
  }
  if (0xf < in_stack_0000001c) {
    puStack_128 = (undefined *)(in_stack_0000001c + 1);
    puVar3 = param_3;
    if (0xfff < puStack_128) {
      puVar3 = (undefined4 *)param_3[-1];
      puStack_128 = (undefined *)(in_stack_0000001c + 0x24);
      if (0x1f < (uint)((int)param_3 + (-4 - (int)puVar3))) {
                    /* WARNING: Subroutine does not return */
        puStack_128 = (undefined *)0xb9c68a;
        FUN_017167a3();
      }
    }
    puStack_130 = (undefined4 *)0xb9c62b;
    puStack_12c = puVar3;
    FUN_01674ea0();
  }
  in_stack_00000018 = 0;
  in_stack_0000001c = 0xf;
  param_3 = (undefined4 *)((uint)param_3 & 0xffffff00);
  if (0xf < in_stack_00000034) {
    puStack_128 = (undefined *)(in_stack_00000034 + 1);
    iVar4 = in_stack_00000020;
    if (0xfff < puStack_128) {
      iVar4 = *(int *)(in_stack_00000020 + -4);
      puStack_128 = (undefined *)(in_stack_00000034 + 0x24);
      if (0x1f < (in_stack_00000020 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_128 = &UNK_00b9c68f;
        FUN_017167a3();
      }
    }
    puStack_130 = (undefined4 *)0xb9c66d;
    puStack_12c = (undefined4 *)iVar4;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_2._3_1_;
}



/* FUNCTION 25494 ; VA 0x00b9c690 ; FUN_00b9c690 */

void __thiscall FUN_00b9c690(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  
  if (param_1 != 0) {
    iVar3 = *(int *)(param_1 + 0x34);
    if ((iVar3 != 0) && (param_1 = iVar3, *(int *)(iVar3 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((((param_1 != 0) &&
         (iVar3 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
         (uint)*(ushort *)(iVar3 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
         (uint)*(ushort *)(iVar2 + 0x1da))) && (iVar3 = FUN_008e25a0(), iVar3 != 0)) &&
       (((cVar1 = FUN_00ed4d10(param_2), cVar1 != '\0' &&
         (FUN_008a4940(&DAT_021304b0), DAT_01d67920 != '\0')) &&
        ((*(char *)(iVar3 + 0x70) != '\0' && ((char)param_2 == '\0')))))) {
      FUN_00ed4d30(0);
    }
  }
  return;
}



/* FUNCTION 25495 ; VA 0x00b9c730 ; FUN_00b9c730 */

void __thiscall FUN_00b9c730(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined auStack_14 [4];
  int *piStack_10;
  int iStack_c;
  int iStack_8;
  
  iStack_c = param_1;
  piVar2 = (int *)FUN_00587490(auStack_14);
  piVar1 = piStack_10;
  iStack_8 = *piVar2;
  if (piStack_10 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_10[1] + -1;
    piStack_10[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_10)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2 + -1;
      *piVar2 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (param_2 != iStack_8) {
    puVar3 = (undefined4 *)FUN_0060dcd0(auStack_14,param_2);
    iVar4 = puVar3[1];
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 8) = *(int *)(iVar4 + 8) + 1;
      UNLOCK();
      iVar4 = puVar3[1];
    }
    *(undefined4 *)(param_1 + 0x1ac) = *puVar3;
    piVar1 = *(int **)(param_1 + 0x1b0);
    *(int *)(param_1 + 0x1b0) = iVar4;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_10[1] + -1;
      piStack_10[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_10)();
        LOCK();
        piVar1 = piStack_10 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_10 + 4))();
        }
      }
    }
    FUN_008a4940(&DAT_0213075c);
  }
  return;
}



/* FUNCTION 25496 ; VA 0x00b9c800 ; FUN_00b9c800 */

void __thiscall FUN_00b9c800(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0x16d)) {
    *(char *)(param_1 + 0x16d) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 25497 ; VA 0x00b9c830 ; FUN_00b9c830 */

void __thiscall FUN_00b9c830(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined auStack_14 [4];
  int *piStack_10;
  int iStack_c;
  int iStack_8;
  
  iStack_c = param_1;
  piVar2 = (int *)FUN_00587490(auStack_14);
  piVar1 = piStack_10;
  iStack_8 = *piVar2;
  if (piStack_10 != (int *)0x0) {
    LOCK();
    iVar4 = piStack_10[1] + -1;
    piStack_10[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piStack_10)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar4 = *piVar2 + -1;
      *piVar2 = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (param_2 != iStack_8) {
    puVar3 = (undefined4 *)FUN_0060dcd0(auStack_14,param_2);
    iVar4 = puVar3[1];
    if (iVar4 != 0) {
      LOCK();
      *(int *)(iVar4 + 8) = *(int *)(iVar4 + 8) + 1;
      UNLOCK();
      iVar4 = puVar3[1];
    }
    *(undefined4 *)(param_1 + 0x1a4) = *puVar3;
    piVar1 = *(int **)(param_1 + 0x1a8);
    *(int *)(param_1 + 0x1a8) = iVar4;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar4 = piVar1[2] + -1;
      piVar1[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_10[1] + -1;
      piStack_10[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piStack_10)();
        LOCK();
        piVar1 = piStack_10 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piStack_10 + 4))();
        }
      }
    }
    FUN_008a4940(&DAT_02130720);
  }
  return;
}



/* FUNCTION 25498 ; VA 0x00b9c900 ; FUN_00b9c900 */

void __thiscall FUN_00b9c900(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0x188) = param_2;
  FUN_005e6780();
  return;
}



/* FUNCTION 25499 ; VA 0x00b9c920 ; FUN_00b9c920 */

void __thiscall FUN_00b9c920(int param_1,char param_2)

{
  if (*(char *)(param_1 + 0x16f) != param_2) {
    *(char *)(param_1 + 0x16f) = param_2;
    FUN_005e6780();
    return;
  }
  return;
}


