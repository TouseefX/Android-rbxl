/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 1000 ; VA 0x004bf480 ; FUN_004bf480 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bf480(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef60e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb790(uVar1,s_PromptRobloxPurchase_0212bf58,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212b748 =
       RBX::Reflection::BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(__int64,bool),2>::
       vftable;
  _DAT_0212b780 = FUN_00b2fd10;
  _DAT_0212b784 = 0;
  DAT_0212b788 = 0;
  DAT_0212b78c = 0;
  uStack_8 = 2;
  FUN_00921d30();
  FUN_016f3654(&LAB_0188d5e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1001 ; VA 0x004bf540 ; FUN_004bf540 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bf540(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef63e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb790(uVar1,s_PromptThirdPartyPurchase_0212bbec,3,CONCAT44(uVar3,uVar2),0);
  _DAT_0212af08 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_0212af40 = FUN_00b30170;
  _DAT_0212af44 = 0;
  DAT_0212af48 = 0;
  _DAT_0212af4c = 0;
  uStack_8 = 2;
  FUN_00b1fcc0();
  FUN_016f3654(&LAB_0188d620);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1002 ; VA 0x004bf600 ; FUN_004bf600 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bf600(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef65a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb820(uVar1,s_GetDeveloperProductsAsync_0212bd94,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212b358 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::MarketplaceService,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_0212b390 = FUN_00b26110;
  _DAT_0212b394 = 0;
  _DAT_0212b37c = FUN_0088cdc0();
  FUN_016f3654(&LAB_0188d680);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1003 ; VA 0x004bf6a0 ; FUN_004bf6a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bf6a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef68e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb820(uVar1,s_GetProductInfo_0212bc3c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0212afd0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::MarketplaceService,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(__int64,enum_RBX::MarketplaceService::InfoType),2>
       ::vftable;
  _DAT_0212b008 = FUN_00b265e0;
  _DAT_0212b00c = 0;
  DAT_0212b010 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  DAT_0212b014 = (undefined4 *)FUN_01674e20(4);
  if (DAT_0212b014 == (undefined4 *)0x0) {
    DAT_0212b014 = (undefined4 *)0x0;
  }
  else {
    *DAT_0212b014 = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00b21350();
  FUN_016f3654(&LAB_0188d690);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1004 ; VA 0x004bf780 ; FUN_004bf780 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bf780(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef6aa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb820(uVar1,s_GetRobuxBalance_0212bc2c,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212af90 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::MarketplaceService,int___cdecl(void),0>::
       vftable;
  _DAT_0212afc8 = FUN_00b274b0;
  _DAT_0212afcc = 0;
  _DAT_0212afb4 = FUN_0088c8c0();
  FUN_016f3654(&LAB_0188d6d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1005 ; VA 0x004bf820 ; FUN_004bf820 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bf820(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef6de;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb820(uVar1,s_IsPlayerSubscribed_0212bdc8,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0212b3e0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::MarketplaceService,bool___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64),2>
       ::vftable;
  _DAT_0212b418 = FUN_00b28970;
  _DAT_0212b41c = 0;
  _DAT_0212b420 = 0;
  _DAT_0212b424 = 0;
  uStack_8 = 2;
  FUN_00b21580();
  FUN_016f3654(&LAB_0188d6e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1006 ; VA 0x004bf8e0 ; FUN_004bf8e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bf8e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef72c;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb820(uVar1,s_PerformPurchase_0212bac0,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212acc0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::MarketplaceService,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(enum_RBX::MarketplaceService::InfoType,__int64,int,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,bool),5>
       ::vftable;
  _DAT_0212acf8 = FUN_00b2c9d0;
  _DAT_0212acfc = 0;
  _DAT_0212ad00 = 0;
  _DAT_0212ad04 = 0;
  _DAT_0212ad08 = 0;
  _DAT_0212ad0c = 0;
  _DAT_0212ad10 = 0;
  uStack_8 = 5;
  FUN_00b20e40(s_infoType_0212bab4,s_productId_0212b810,s_expectedPrice_0212baa4,
               s_requestId_0212ba98,s_isRobloxPurchase_0212ba84);
  FUN_016f3654(&LAB_0188d6f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1007 ; VA 0x004bf9d0 ; FUN_004bf9d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bf9d0(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef78c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b12040();
  FUN_009cb790(uVar2,s_PlayerCanMakePurchases_0212bbd4,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0212aec0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MarketplaceService,bool___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_0212aef8 = FUN_00b2ce50;
  _DAT_0212aefc = 0;
  DAT_0212af00 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0212aee4 = FUN_0088daf0();
  puVar4 = DAT_0212af00;
  if (DAT_0212af00 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cdc0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_006309e0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_player_0211f800);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_0188d700);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1008 ; VA 0x004bfba0 ; FUN_004bfba0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bfba0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef7be;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb820(uVar1,s_PlayerOwnsAsset_0212bc4c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0212b018 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::MarketplaceService,bool___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64),2>
       ::vftable;
  _DAT_0212b050 = FUN_00b2cf60;
  _DAT_0212b054 = 0;
  _DAT_0212b058 = 0;
  _DAT_0212b05c = 0;
  uStack_8 = 2;
  FUN_00b21580();
  FUN_016f3654(&LAB_0188d750);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1009 ; VA 0x004bfc60 ; FUN_004bfc60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bfc60(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef7ee;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb790(uVar1,s_PromptGamePassPurchase_0212bd5c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0212b2d0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64),2>
       ::vftable;
  _DAT_0212b308 = FUN_00b2f230;
  _DAT_0212b30c = 0;
  _DAT_0212b310 = 0;
  _DAT_0212b314 = 0;
  uStack_8 = 2;
  FUN_00b20160();
  FUN_016f3654(&LAB_0188d760);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1010 ; VA 0x004bfd20 ; FUN_004bfd20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bfd20(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef81e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb790(uVar1,s_PromptSubscriptionCancellation_0212be1c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0212b4b0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64),2>
       ::vftable;
  _DAT_0212b4e8 = FUN_00b2fd30;
  _DAT_0212b4ec = 0;
  _DAT_0212b4f0 = 0;
  _DAT_0212b4f4 = 0;
  uStack_8 = 2;
  FUN_00b20160();
  FUN_016f3654(&LAB_0188d770);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1011 ; VA 0x004bfde0 ; FUN_004bfde0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bfde0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef84e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb790(uVar1,s_PromptSubscriptionPurchase_0212bddc,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0212b428 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64),2>
       ::vftable;
  _DAT_0212b460 = FUN_00b2ff50;
  _DAT_0212b464 = 0;
  _DAT_0212b468 = 0;
  _DAT_0212b46c = 0;
  uStack_8 = 2;
  FUN_00b20160();
  FUN_016f3654(&LAB_0188d780);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1012 ; VA 0x004bfea0 ; FUN_004bfea0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bfea0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef87e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb790(uVar1,s_ReportAssetSale_0212ba74,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212ac78 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int),2>
       ::vftable;
  _DAT_0212acb0 = FUN_00b30790;
  _DAT_0212acb4 = 0;
  _DAT_0212acb8 = 0;
  DAT_0212acbc = 0;
  uStack_8 = 2;
  FUN_00b1f780();
  FUN_016f3654(&LAB_0188d790);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1013 ; VA 0x004bff60 ; FUN_004bff60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004bff60(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef89a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb790(uVar1,s_ReportRobuxUpsellStarted_0212ba4c,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212ac38 =
       RBX::Reflection::BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(void),0>::vftable;
  _DAT_0212ac70 = FUN_00b30c20;
  _DAT_0212ac74 = 0;
  _DAT_0212ac5c = FUN_00888530();
  FUN_016f3654(&LAB_0188d7c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1014 ; VA 0x004c0000 ; FUN_004c0000 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c0000(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef8ce;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb790(uVar1,s_SignalAssetTypePurchased_0212b8d0,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212a960 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::AssetService::AssetType),2>
       ::vftable;
  _DAT_0212a998 = FUN_00b30e00;
  _DAT_0212a99c = 0;
  _DAT_0212a9a0 = 0;
  _DAT_0212a9a4 = 0;
  uStack_8 = 2;
  FUN_00b1ff10();
  FUN_016f3654(&LAB_0188d7d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1015 ; VA 0x004c00c0 ; FUN_004c00c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c00c0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef908;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb790(uVar1,s_SignalClientPurchaseSuccess_0212b9a4,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212aae8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,__int64,__int64),3>
       ::vftable;
  _DAT_0212ab20 = FUN_00b30ea0;
  _DAT_0212ab24 = 0;
  _DAT_0212ab28 = 0;
  DAT_0212ab2c = 0;
  DAT_0212ab30 = 0;
  uStack_8 = 3;
  FUN_00b1f9a0(s_ticket_0212b99c,s_playerId_02119448,s_productId_0212b810);
  FUN_016f3654(&LAB_0188d7e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1016 ; VA 0x004c0190 ; FUN_004c0190 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c0190(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef92a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb790(uVar1,s_SignalMockPurchasePremium_0212bf04,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212b6c0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(void),0>::vftable;
  _DAT_0212b6f8 = &DAT_00b30fb0;
  _DAT_0212b6fc = 0;
  _DAT_0212b6e4 = FUN_00888530();
  FUN_016f3654(&LAB_0188d820);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1017 ; VA 0x004c0230 ; FUN_004c0230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c0230(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef968;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb790(uVar1,s_SignalPromptBundlePurchaseFinish_0212b8a0,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212a910 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64,bool),3>
       ::vftable;
  _DAT_0212a948 = FUN_00b30fc0;
  _DAT_0212a94c = 0;
  _DAT_0212a950 = 0;
  _DAT_0212a954 = 0;
  _DAT_0212a958 = 0;
  uStack_8 = 3;
  FUN_00b203b0(s_player_0211f800,s_bundleId_0212b894,s_success_02119b1c);
  FUN_016f3654(&LAB_0188d830);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1018 ; VA 0x004c0300 ; FUN_004c0300 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c0300(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef9a8;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb790(uVar1,s_SignalPromptGamePassPurchaseFini_0212b86c,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212a8c0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64,bool),3>
       ::vftable;
  _DAT_0212a8f8 = FUN_00b31060;
  _DAT_0212a8fc = 0;
  _DAT_0212a900 = 0;
  _DAT_0212a904 = 0;
  _DAT_0212a908 = 0;
  uStack_8 = 3;
  FUN_00b203b0(s_player_0211f800,s_gamePassId_0212b860,s_success_02119b1c);
  FUN_016f3654(&LAB_0188d840);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1019 ; VA 0x004c03d0 ; FUN_004c03d0 */

void FUN_004c03d0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b15950(FUN_00b31100,0,s_SignalPromptPremiumPurchaseFinis_0212bf34,
               s_didTryPurchasing_0212bf20,5,uStack_10,0);
  FUN_016f3654(&LAB_0188d850);
  return;
}



/* FUNCTION 1020 ; VA 0x004c0430 ; FUN_004c0430 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c0430(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ef9e8;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb790(uVar1,s_SignalPromptProductPurchaseFinis_0212b81c,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212a820 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(__int64,__int64,bool),3>::vftable;
  _DAT_0212a858 = FUN_00b311e0;
  _DAT_0212a85c = 0;
  DAT_0212a860 = 0;
  DAT_0212a864 = 0;
  DAT_0212a868 = 0;
  uStack_8 = 3;
  FUN_00b20b20(s_userId_0211fb64,s_productId_0212b810,s_success_02119b1c);
  FUN_016f3654(&LAB_0188d870);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1021 ; VA 0x004c0500 ; FUN_004c0500 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c0500(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017efa28;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb790(uVar1,s_SignalPromptPurchaseFinished_0212b840,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212a870 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64,bool),3>
       ::vftable;
  _DAT_0212a8a8 = FUN_00b31350;
  _DAT_0212a8ac = 0;
  _DAT_0212a8b0 = 0;
  _DAT_0212a8b4 = 0;
  _DAT_0212a8b8 = 0;
  uStack_8 = 3;
  FUN_00b203b0(s_player_0211f800,s_assetId_0211bf40,s_success_02119b1c);
  FUN_016f3654(&LAB_0188d8c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1022 ; VA 0x004c05d0 ; FUN_004c05d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c05d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017efa68;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb790(uVar1,s_SignalPromptSubscriptionCancella_0212bb74,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212ade8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64,bool),3>
       ::vftable;
  _DAT_0212ae20 = FUN_00b314b0;
  _DAT_0212ae24 = 0;
  _DAT_0212ae28 = 0;
  _DAT_0212ae2c = 0;
  _DAT_0212ae30 = 0;
  uStack_8 = 3;
  FUN_00b203b0(s_player_0211f800,s_subscriptionId_0212bad0,s_wasCanceled_0212bb68);
  FUN_016f3654(&LAB_0188d8d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1023 ; VA 0x004c06a0 ; FUN_004c06a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c06a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017efaa8;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b12040(uVar2,0);
  FUN_009cb790(uVar1,s_SignalPromptSubscriptionPurchase_0212bb14,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212ad58 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::MarketplaceService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,__int64,bool),3>
       ::vftable;
  _DAT_0212ad90 = FUN_00b31550;
  _DAT_0212ad94 = 0;
  _DAT_0212ad98 = 0;
  _DAT_0212ad9c = 0;
  _DAT_0212ada0 = 0;
  uStack_8 = 3;
  FUN_00b203b0(s_player_0211f800,s_subscriptionId_0212bad0,s_wasPurchased_0212bb04);
  FUN_016f3654(&LAB_0188d8e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1024 ; VA 0x004c0770 ; FUN_004c0770 */

void FUN_004c0770(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b15950(FUN_00b315f0,0,s_SignalServerLuaDialogClosed_0212bd40,s_value_0211ab70,5,uStack_10,0)
  ;
  FUN_016f3654(&LAB_0188d8f0);
  return;
}



/* FUNCTION 1025 ; VA 0x004c0810 ; FUN_004c0810 */

void FUN_004c0810(void)

{
  undefined4 *puVar1;
  undefined8 uStack_14;
  undefined4 uStack_8;
  
  puVar1 = (undefined4 *)FUN_0056a920();
  uStack_8 = *puVar1;
  uStack_14 = FUN_016f39b0(0,1000000,0);
  FUN_005672c0(&uStack_8,&uStack_14);
  return;
}



/* FUNCTION 1026 ; VA 0x004c08a0 ; FUN_004c08a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c08a0(void)

{
  undefined4 uVar1;
  int iVar2;
  undefined *puVar3;
  undefined auStack_420 [16];
  undefined4 uStack_410;
  undefined4 uStack_40c;
  undefined4 uStack_408;
  undefined uStack_404;
  undefined4 uStack_3f4;
  undefined4 uStack_3f0;
  undefined4 uStack_3ec;
  undefined uStack_3e8;
  undefined4 uStack_3d8;
  undefined4 uStack_3d4;
  undefined4 uStack_3d0;
  undefined uStack_3cc;
  undefined4 uStack_3bc;
  undefined4 uStack_3b8;
  undefined4 uStack_3b4;
  undefined uStack_3b0;
  undefined4 uStack_3a0;
  undefined4 uStack_39c;
  undefined4 uStack_398;
  undefined uStack_394;
  undefined4 uStack_384;
  undefined4 uStack_380;
  undefined4 uStack_37c;
  undefined uStack_378;
  undefined4 uStack_368;
  undefined4 uStack_364;
  undefined4 uStack_360;
  undefined uStack_35c;
  undefined4 uStack_34c;
  undefined4 uStack_348;
  undefined4 uStack_344;
  undefined uStack_340;
  undefined4 uStack_330;
  undefined4 uStack_32c;
  undefined4 uStack_328;
  undefined uStack_324;
  undefined4 uStack_314;
  undefined4 uStack_310;
  undefined4 uStack_30c;
  undefined uStack_308;
  undefined4 uStack_2f8;
  undefined4 uStack_2f4;
  undefined4 uStack_2f0;
  undefined uStack_2ec;
  undefined4 uStack_2dc;
  undefined4 uStack_2d8;
  undefined4 uStack_2d4;
  undefined uStack_2d0;
  undefined4 uStack_2c0;
  undefined4 uStack_2bc;
  undefined4 uStack_2b8;
  undefined uStack_2b4;
  undefined4 uStack_2a4;
  undefined4 uStack_2a0;
  undefined4 uStack_29c;
  undefined uStack_298;
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined uStack_27c;
  undefined4 uStack_26c;
  undefined4 uStack_268;
  undefined4 uStack_264;
  undefined uStack_260;
  undefined4 uStack_250;
  undefined4 uStack_24c;
  undefined4 uStack_248;
  undefined uStack_244;
  undefined4 uStack_234;
  undefined4 uStack_230;
  undefined4 uStack_22c;
  undefined uStack_228;
  undefined4 uStack_218;
  undefined4 uStack_214;
  undefined4 uStack_210;
  undefined uStack_20c;
  undefined4 uStack_1fc;
  undefined4 uStack_1f8;
  undefined4 uStack_1f4;
  undefined uStack_1f0;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined4 uStack_1d8;
  undefined uStack_1d4;
  undefined4 uStack_1c4;
  undefined4 uStack_1c0;
  undefined4 uStack_1bc;
  undefined uStack_1b8;
  undefined4 uStack_1a8;
  undefined4 uStack_1a4;
  undefined4 uStack_1a0;
  undefined uStack_19c;
  undefined4 uStack_18c;
  undefined4 uStack_188;
  undefined4 uStack_184;
  undefined uStack_180;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  undefined4 uStack_168;
  undefined uStack_164;
  undefined4 uStack_154;
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined uStack_148;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined uStack_12c;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined uStack_110;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined4 uStack_f8;
  undefined uStack_f4;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined uStack_d8;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined uStack_bc;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined uStack_a0;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined uStack_84;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined uStack_68;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined uStack_4c;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined uStack_30;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2803;
  pvStack_10 = ExceptionList;
  uStack_410 = 0;
  uStack_40c = 0xf;
  auStack_420[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_01952230,4);
  uStack_408 = 0;
  uStack_8 = 0;
  uStack_3f4 = 0;
  uStack_3f0 = 0xf;
  uStack_404 = 0;
  FUN_005542c0(&DAT_01952238,2);
  uStack_3ec = 1;
  uStack_8._0_1_ = 1;
  uStack_3d8 = 0;
  uStack_3d4 = 0xf;
  uStack_3e8 = 0;
  FUN_005542c0(&DAT_0195223c,4);
  uStack_3d0 = 2;
  uStack_8._0_1_ = 2;
  uStack_3bc = 0;
  uStack_3b8 = 0xf;
  uStack_3cc = 0;
  FUN_005542c0(&DAT_01952244,3);
  uStack_3b4 = 3;
  uStack_8._0_1_ = 3;
  uStack_3a0 = 0;
  uStack_39c = 0xf;
  uStack_3b0 = 0;
  FUN_005542c0(&DAT_01952248,2);
  uStack_398 = 4;
  uStack_8._0_1_ = 4;
  uStack_384 = 0;
  uStack_380 = 0xf;
  uStack_394 = 0;
  FUN_005542c0(&DAT_018bc904,1);
  uStack_37c = 5;
  uStack_8._0_1_ = 5;
  uStack_368 = 0;
  uStack_364 = 0xf;
  uStack_378 = 0;
  FUN_005542c0(&DAT_0195224c,4);
  uStack_360 = 6;
  uStack_8._0_1_ = 6;
  uStack_34c = 0;
  uStack_348 = 0xf;
  uStack_35c = 0;
  FUN_005542c0(&DAT_01952254,3);
  uStack_344 = 7;
  uStack_8._0_1_ = 7;
  uStack_330 = 0;
  uStack_32c = 0xf;
  uStack_340 = 0;
  FUN_005542c0(&DAT_01952258,2);
  uStack_328 = 8;
  uStack_8._0_1_ = 8;
  uStack_314 = 0;
  uStack_310 = 0xf;
  uStack_324 = 0;
  FUN_005542c0(&DAT_018bc908,1);
  uStack_30c = 9;
  uStack_8._0_1_ = 9;
  uStack_2f8 = 0;
  uStack_2f4 = 0xf;
  uStack_308 = 0;
  FUN_005542c0(&DAT_0195225c,4);
  uStack_2f0 = 10;
  uStack_8._0_1_ = 10;
  uStack_2dc = 0;
  uStack_2d8 = 0xf;
  uStack_2ec = 0;
  FUN_005542c0(&DAT_01952264,3);
  uStack_2d4 = 0xb;
  uStack_8._0_1_ = 0xb;
  uStack_2c0 = 0;
  uStack_2bc = 0xf;
  uStack_2d0 = 0;
  FUN_005542c0(&DAT_01952268,2);
  uStack_2b8 = 0xc;
  uStack_8._0_1_ = 0xc;
  uStack_2a4 = 0;
  uStack_2a0 = 0xf;
  uStack_2b4 = 0;
  FUN_005542c0(&DAT_018d4fd0,1);
  uStack_29c = 0xd;
  uStack_8._0_1_ = 0xd;
  uStack_288 = 0;
  uStack_284 = 0xf;
  uStack_298 = 0;
  FUN_005542c0(&DAT_0195226c,2);
  uStack_280 = 0xe;
  uStack_8._0_1_ = 0xe;
  uStack_26c = 0;
  uStack_268 = 0xf;
  uStack_27c = 0;
  FUN_005542c0(&DAT_0192b7d8,1);
  uStack_264 = 0xf;
  uStack_8._0_1_ = 0xf;
  uStack_250 = 0;
  uStack_24c = 0xf;
  uStack_260 = 0;
  FUN_005542c0(&DAT_01952270,2);
  uStack_248 = 0x10;
  uStack_8._0_1_ = 0x10;
  uStack_234 = 0;
  uStack_230 = 0xf;
  uStack_244 = 0;
  FUN_005542c0(&DAT_0193a3e0,1);
  uStack_22c = 0x11;
  uStack_8._0_1_ = 0x11;
  uStack_218 = 0;
  uStack_214 = 0xf;
  uStack_228 = 0;
  FUN_005542c0(&DAT_01952274,2);
  uStack_210 = 0x12;
  uStack_8._0_1_ = 0x12;
  uStack_1fc = 0;
  uStack_1f8 = 0xf;
  uStack_20c = 0;
  FUN_005542c0(&DAT_01952278,1);
  uStack_1f4 = 0x13;
  uStack_8._0_1_ = 0x13;
  uStack_1e0 = 0;
  uStack_1dc = 0xf;
  uStack_1f0 = 0;
  FUN_005542c0(&DAT_0195227c,3);
  uStack_1d8 = 0x14;
  uStack_8._0_1_ = 0x14;
  uStack_1c4 = 0;
  uStack_1c0 = 0xf;
  uStack_1d4 = 0;
  FUN_005542c0(&DAT_01952280,2);
  uStack_1bc = 0x15;
  uStack_8._0_1_ = 0x15;
  uStack_1a8 = 0;
  uStack_1a4 = 0xf;
  uStack_1b8 = 0;
  FUN_005542c0(&DAT_018bc900,1);
  uStack_1a0 = 0x16;
  uStack_8._0_1_ = 0x16;
  uStack_18c = 0;
  uStack_188 = 0xf;
  uStack_19c = 0;
  FUN_005542c0(&DAT_01952284,2);
  uStack_184 = 0x17;
  uStack_8._0_1_ = 0x17;
  uStack_170 = 0;
  uStack_16c = 0xf;
  uStack_180 = 0;
  FUN_005542c0(&DAT_018d5050,1);
  uStack_168 = 0x18;
  uStack_8._0_1_ = 0x18;
  uStack_154 = 0;
  uStack_150 = 0xf;
  uStack_164 = 0;
  FUN_005542c0(&DAT_01952288,1);
  uStack_14c = 0x19;
  uStack_8._0_1_ = 0x19;
  uStack_138 = 0;
  uStack_134 = 0xf;
  uStack_148 = 0;
  FUN_005542c0(&DAT_018c34b0,1);
  uStack_130 = 0x1a;
  uStack_8._0_1_ = 0x1a;
  uStack_11c = 0;
  uStack_118 = 0xf;
  uStack_12c = 0;
  FUN_005542c0(&DAT_0195228c,3);
  uStack_114 = 0x1b;
  uStack_8._0_1_ = 0x1b;
  uStack_100 = 0;
  uStack_fc = 0xf;
  uStack_110 = 0;
  FUN_005542c0(&DAT_01952290,2);
  uStack_f8 = 0x1c;
  uStack_8._0_1_ = 0x1c;
  uStack_e4 = 0;
  uStack_e0 = 0xf;
  uStack_f4 = 0;
  FUN_005542c0(&DAT_01952294,4);
  uStack_dc = 0x1d;
  uStack_8._0_1_ = 0x1d;
  uStack_c8 = 0;
  uStack_c4 = 0xf;
  uStack_d8 = 0;
  FUN_005542c0(&DAT_0195229c,3);
  uStack_c0 = 0x1e;
  uStack_8._0_1_ = 0x1e;
  uStack_ac = 0;
  uStack_a8 = 0xf;
  uStack_bc = 0;
  FUN_005542c0(&DAT_019522a0,2);
  uStack_a4 = 0x1f;
  uStack_8._0_1_ = 0x1f;
  uStack_90 = 0;
  uStack_8c = 0xf;
  uStack_a0 = 0;
  FUN_005542c0(&DAT_018fab0c,1);
  uStack_88 = 0x20;
  uStack_8._0_1_ = 0x20;
  uStack_74 = 0;
  uStack_70 = 0xf;
  uStack_84 = 0;
  FUN_005542c0(&DAT_019522a4,4);
  uStack_6c = 0x21;
  uStack_8._0_1_ = 0x21;
  uStack_58 = 0;
  uStack_54 = 0xf;
  uStack_68 = 0;
  FUN_005542c0(&DAT_019522ac,3);
  uStack_50 = 0x22;
  uStack_8._0_1_ = 0x22;
  uStack_3c = 0;
  uStack_38 = 0xf;
  uStack_4c = 0;
  FUN_005542c0(&DAT_019522b0,2);
  uStack_34 = 0x23;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x23);
  uStack_20 = 0;
  uStack_1c = 0xf;
  uStack_30 = 0;
  FUN_005542c0(&DAT_018c8ecc,1);
  uStack_18 = 0x24;
  uStack_8 = 0x24;
  DAT_01eee638 = 0;
  _DAT_01eee63c = 0;
  DAT_01eee638 = FUN_00575af0();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x25);
  puVar3 = auStack_420;
  do {
    uVar1 = DAT_01eee638;
    iVar2 = FUN_00b35190(puVar3);
    FUN_00b358f0(auStack_14,uVar1,iVar2 + 0x10,iVar2);
    puVar3 = puVar3 + 0x1c;
  } while (puVar3 != auStack_14);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(auStack_420,0x1c,0x25,FUN_005507b0);
  FUN_016f3654(FUN_0188dad0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1027 ; VA 0x004c13b0 ; FUN_004c13b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c13b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f371c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b4b860();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Constraints::WeldConstraint,int>::
              GetSetImpl<int_(__thiscall_RBX::Constraints::WeldConstraint::*)(void)const_,void_(__thiscall_RBX::Constraints::WeldConstraint::*)(int)>
              ::vftable;
    puVar3[2] = &LAB_00b4c0c0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00b4d170;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,s_State_0211d030,s_Behavior_0211a8f8,uStack_24,0,0,0xe,0,0,0);
  DAT_0212c144 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0212c178 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0212c168 = _DAT_0212c168 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0212c144[2])();
    if (cVar1 != '\0') {
      _DAT_0212c168 = _DAT_0212c168 & 0xfffffff3;
    }
  }
  DAT_0212c144 = RBX::Reflection::PropDescriptor<class_RBX::Constraints::WeldConstraint,int>::
                 vftable;
  FUN_016f3654(&LAB_0188dc00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1028 ; VA 0x004c1740 ; FUN_004c1740 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c1740(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f383c;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b4d210();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0xb4e030;
    *(undefined8 *)(puVar3 + 6) = 0xb4d852;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::TriangleMeshPart,class_RBX::SharedString>::
              GetSetImpl<class_RBX::SharedString_const&_(__thiscall_RBX::TriangleMeshPart::*)(void)const_,void_(__thiscall_RBX::TriangleMeshPart::*)(class_RBX::SharedString_const&)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d4b0();
  FUN_009ca670(uVar2,uVar4,"PhysicalConfigData",&DAT_018dbc3c,uStack_3c,0,0,0xe,6,6,0);
  DAT_01eee8d8 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::SharedString>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01eee90c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01eee8fc = _DAT_01eee8fc & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01eee8d8[2])();
    if (cVar1 != '\0') {
      _DAT_01eee8fc = _DAT_01eee8fc & 0xfffffff3;
    }
  }
  DAT_01eee8d8 = RBX::Reflection::
                 PropDescriptor<class_RBX::TriangleMeshPart,class_RBX::SharedString>::vftable;
  FUN_016f3654(&LAB_0188dce0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1029 ; VA 0x004c1890 ; FUN_004c1890 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c1890(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3864;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b0f580();
  uVar3 = FUN_00b4d210();
  FUN_009ca670(uVar3,uVar2,"CollisionFidelity","Behavior",uStack_3c,0,0,0x15,0,1,1);
  uStack_8 = 0;
  DAT_01eee910 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::TriangleMeshPart,enum_RBX::CollisionFidelity>::
                 vftable;
  _DAT_01eee944 = uVar2;
  DAT_01eee948 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_01eee948 == (undefined4 *)0x0) {
    DAT_01eee948 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_01eee948 + 2) = 0xb4def0;
    *(undefined8 *)(DAT_01eee948 + 6) = 0xb4f5a0;
    *DAT_01eee948 =
         RBX::Reflection::PropDescriptor<class_RBX::TriangleMeshPart,enum_RBX::CollisionFidelity>::
         GetSetImpl<enum_RBX::CollisionFidelity_(__thiscall_RBX::TriangleMeshPart::*)(void)const_,void_(__thiscall_RBX::TriangleMeshPart::*)(enum_RBX::CollisionFidelity)>
         ::vftable;
    DAT_01eee948[4] = 0;
    DAT_01eee948[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01eee94c = FUN_00b0f580();
  cVar1 = (*(code *)DAT_01eee910[3])();
  if (cVar1 != '\0') {
    _DAT_01eee934 = _DAT_01eee934 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01eee910[2])();
  if (cVar1 != '\0') {
    _DAT_01eee934 = _DAT_01eee934 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0188dd00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1030 ; VA 0x004c19d0 ; FUN_004c19d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c19d0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f388c;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b4d210();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0xb4dfd0;
    *(undefined8 *)(puVar3 + 6) = 0xb4f680;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::TriangleMeshPart,class_RBX::BinaryString>::
              GetSetImpl<class_RBX::BinaryString_const&_(__thiscall_RBX::TriangleMeshPart::*)(void)const_,void_(__thiscall_RBX::TriangleMeshPart::*)(class_RBX::BinaryString_const&)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cf00();
  FUN_009ca670(uVar2,uVar4,"LODData",&DAT_018dbc3c,uStack_3c,0,0,0xe,6,6,0);
  DAT_01eee950 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::BinaryString>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01eee984 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01eee974 = _DAT_01eee974 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01eee950[2])();
    if (cVar1 != '\0') {
      _DAT_01eee974 = _DAT_01eee974 & 0xfffffff3;
    }
  }
  DAT_01eee950 = RBX::Reflection::
                 PropDescriptor<class_RBX::TriangleMeshPart,class_RBX::BinaryString>::vftable;
  FUN_016f3654(&LAB_0188dd20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1031 ; VA 0x004c1b90 ; FUN_004c1b90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c1b90(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3d9c;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b50240();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0x731570;
    *(undefined8 *)(puVar3 + 6) = 0xb54fb0;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PartOperation,class_RBX::ContentId>::
              GetSetImpl<class_RBX::ContentId_const&_(__thiscall_RBX::PartOperation::*)(void)const_,void_(__thiscall_RBX::PartOperation::*)(class_RBX::ContentId)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,"AssetId",&DAT_018dbc3c,uStack_3c,0,0,0xe,6,6,0);
  DAT_01eeed90 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::ContentId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01eeedc4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01eeedb4 = _DAT_01eeedb4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01eeed90[2])();
    if (cVar1 != '\0') {
      _DAT_01eeedb4 = _DAT_01eeedb4 & 0xfffffff3;
    }
  }
  DAT_01eeed90 = RBX::Reflection::PropDescriptor<class_RBX::PartOperation,class_RBX::ContentId>::
                 vftable;
  FUN_016f3654(&LAB_0188dd50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1032 ; VA 0x004c1ce0 ; FUN_004c1ce0 */

void FUN_004c1ce0(void)

{
  FUN_00b4ff40("ChildData2",&DAT_018dbc3c,0xb53a50,0,0xb55090,0,0,0,0,0xc,6);
  FUN_016f3654(&LAB_0188dd70);
  return;
}



/* FUNCTION 1033 ; VA 0x004c1d70 ; FUN_004c1d70 */

void FUN_004c1d70(void)

{
  FUN_00b4fe30("ChildData",&DAT_018dbc3c,0xb53a60,0,0xb550f0,0,0,0,0,0xc,6);
  FUN_016f3654(&LAB_0188dd90);
  return;
}



/* FUNCTION 1034 ; VA 0x004c1e00 ; FUN_004c1e00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c1e00(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3dc4;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b0f630();
  uVar3 = FUN_00b50240();
  FUN_009ca670(uVar3,uVar2,&DAT_0194e7f4,&DAT_018dbc3c,uStack_3c,0,0,0xe,6,6,1);
  uStack_8 = 0;
  DAT_01eeed50 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::PartOperation,enum_RBX::PartInstance::FormFactor>::
                 vftable;
  _DAT_01eeed84 = uVar2;
  DAT_01eeed88 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_01eeed88 == (undefined4 *)0x0) {
    DAT_01eeed88 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_01eeed88 + 2) = 0xb51a7e;
    *(undefined8 *)(DAT_01eeed88 + 6) = 0xb55160;
    *DAT_01eeed88 =
         RBX::Reflection::
         PropDescriptor<class_RBX::PartOperation,enum_RBX::PartInstance::FormFactor>::
         GetSetImpl<enum_RBX::PartInstance::FormFactor_(__thiscall_RBX::PartOperation::*)(void)const_,void_(__thiscall_RBX::PartOperation::*)(enum_RBX::PartInstance::FormFactor)>
         ::vftable;
    DAT_01eeed88[4] = 0;
    DAT_01eeed88[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01eeed8c = FUN_00b0f630();
  cVar1 = (*(code *)DAT_01eeed50[3])();
  if (cVar1 != '\0') {
    _DAT_01eeed74 = _DAT_01eeed74 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01eeed50[2])();
  if (cVar1 != '\0') {
    _DAT_01eeed74 = _DAT_01eeed74 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0188ddb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1035 ; VA 0x004c1f40 ; FUN_004c1f40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c1f40(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3dec;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b50240();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0x74adf0;
    *(undefined8 *)(puVar3 + 6) = 0xb55180;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PartOperation,class_G3D::Vector3>::
              GetSetImpl<class_G3D::Vector3_(__thiscall_RBX::PartOperation::*)(void)const_,void_(__thiscall_RBX::PartOperation::*)(class_G3D::Vector3_const&)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d870();
  FUN_009ca670(uVar2,uVar4,"InitialSize",&DAT_018dbc3c,uStack_3c,0,0,0xe,6,6,0);
  DAT_01eeecdc = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01eeed10 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01eeed00 = _DAT_01eeed00 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01eeecdc[2])();
    if (cVar1 != '\0') {
      _DAT_01eeed00 = _DAT_01eeed00 & 0xfffffff3;
    }
  }
  DAT_01eeecdc = RBX::Reflection::PropDescriptor<class_RBX::PartOperation,class_G3D::Vector3>::
                 vftable;
  FUN_016f3654(&LAB_0188ddd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1036 ; VA 0x004c2090 ; FUN_004c2090 */

void FUN_004c2090(void)

{
  FUN_00b4ff40("MeshData2",&DAT_018dbc3c,0x76df80,0,0xb55450,0,0,0,0,0xe,6);
  FUN_016f3654(&LAB_0188ddf0);
  return;
}



/* FUNCTION 1037 ; VA 0x004c2120 ; FUN_004c2120 */

void FUN_004c2120(void)

{
  FUN_00b4fe30("MeshData",&DAT_018dbc3c,0x76df90,0,0xb554b0,0,0,0,0,0xe,6);
  FUN_016f3654(&LAB_0188de10);
  return;
}



/* FUNCTION 1038 ; VA 0x004c21b0 ; FUN_004c21b0 */

void FUN_004c21b0(void)

{
  FUN_00b4fe30("PhysicsData",&DAT_018dbc3c,0x93a140,0,0xb51a86,0,0,0,0,0xe,6);
  FUN_016f3654(&LAB_0188de30);
  return;
}



/* FUNCTION 1039 ; VA 0x004c2240 ; FUN_004c2240 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c2240(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3e1c;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b50240();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0xb541e0;
    *(undefined8 *)(puVar3 + 6) = 0xb55a90;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PartOperation,float>::
              GetSetImpl<float_(__thiscall_RBX::PartOperation::*)(void)const_,void_(__thiscall_RBX::PartOperation::*)(float)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,"SmoothingAngle","Appearance",uStack_3c,0,0,0x1f,0,1,0);
  DAT_01eeee40 = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01eeee74 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01eeee64 = _DAT_01eeee64 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01eeee40[2])();
    if (cVar1 != '\0') {
      _DAT_01eeee64 = _DAT_01eeee64 & 0xfffffff3;
    }
  }
  DAT_01eeee40 = RBX::Reflection::PropDescriptor<class_RBX::PartOperation,float>::vftable;
  FUN_016f3654(&LAB_0188de50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1040 ; VA 0x004c2390 ; FUN_004c2390 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c2390(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_30;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3e4c;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b50240();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0xb54200;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PartOperation,int>::
              GetImpl<int_(__thiscall_RBX::PartOperation::*)(void)const_>::vftable;
    puVar3[4] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,"TriangleCount",&DAT_018dbc3c,uStack_30,0,0,0x1d,0,0,0);
  DAT_01eeee08 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01eeee3c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01eeee2c = _DAT_01eeee2c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01eeee08[2])();
    if (cVar1 != '\0') {
      _DAT_01eeee2c = _DAT_01eeee2c & 0xfffffff3;
    }
  }
  DAT_01eeee08 = RBX::Reflection::PropDescriptor<class_RBX::PartOperation,int>::vftable;
  FUN_016f3654(&LAB_0188de70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1041 ; VA 0x004c24c0 ; FUN_004c24c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c24c0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3e7c;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b50240();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0x74b640;
    *(undefined8 *)(puVar3 + 6) = 0xb55ba0;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PartOperation,bool>::
              GetSetImpl<bool_(__thiscall_RBX::PartOperation::*)(void)const_,void_(__thiscall_RBX::PartOperation::*)(bool)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,"UsePartColor",&DAT_018dbc3c,uStack_3c,0,0,0x1f,0,0,0);
  DAT_01eeed14 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01eeed48 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01eeed38 = _DAT_01eeed38 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01eeed14[2])();
    if (cVar1 != '\0') {
      _DAT_01eeed38 = _DAT_01eeed38 & 0xfffffff3;
    }
  }
  DAT_01eeed14 = RBX::Reflection::PropDescriptor<class_RBX::PartOperation,bool>::vftable;
  FUN_016f3654(&LAB_0188de90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1042 ; VA 0x004c2610 ; FUN_004c2610 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c2610(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3ea4;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b0f830();
  uVar3 = FUN_00b50240();
  FUN_009ca670(uVar3,uVar2,"RenderFidelity","Appearance",uStack_3c,0,0,0x1f,0,1,1);
  uStack_8 = 0;
  DAT_01eeedc8 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::PartOperation,enum_RBX::RenderFidelity>::vftable;
  _DAT_01eeedfc = uVar2;
  DAT_01eeee00 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_01eeee00 == (undefined4 *)0x0) {
    DAT_01eeee00 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_01eeee00 + 2) = 0x7b44e0;
    *(undefined8 *)(DAT_01eeee00 + 6) = 0xb55940;
    *DAT_01eeee00 =
         RBX::Reflection::PropDescriptor<class_RBX::PartOperation,enum_RBX::RenderFidelity>::
         GetSetImpl<enum_RBX::RenderFidelity_(__thiscall_RBX::PartOperation::*)(void)const_,void_(__thiscall_RBX::PartOperation::*)(enum_RBX::RenderFidelity)>
         ::vftable;
    DAT_01eeee00[4] = 0;
    DAT_01eeee00[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_01eeee04 = FUN_00b0f830();
  cVar1 = (*(code *)DAT_01eeedc8[3])();
  if (cVar1 != '\0') {
    _DAT_01eeedec = _DAT_01eeedec & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01eeedc8[2])();
  if (cVar1 != '\0') {
    _DAT_01eeedec = _DAT_01eeedec & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0188deb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1043 ; VA 0x004c2820 ; FUN_004c2820 */

void FUN_004c2820(void)

{
  undefined4 *puVar1;
  undefined auStack_14 [16];
  
  puVar1 = (undefined4 *)FUN_009cb3a0(auStack_14,0x1f);
  FUN_00b564e0(s_ResetPlayerGuiOnSpawn_0212c91c,&DAT_021197d4,&LAB_00928000,0,FUN_00b61ae0,0,*puVar1
               ,puVar1[1],puVar1[2],puVar1[3],0);
  FUN_016f3654(&LAB_0188dff0);
  return;
}



/* FUNCTION 1044 ; VA 0x004c2880 ; FUN_004c2880 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c2880(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f45f4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b62060();
  uVar3 = FUN_00b56e90();
  FUN_009ca670(uVar3,uVar2,s_ScreenOrientation_0212c8d8,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0212c3d8 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::PlayerGui,enum_RBX::BasePlayerGui::ScreenOrientation>
                 ::vftable;
  _DAT_0212c40c = uVar2;
  DAT_0212c410 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0212c410 == (undefined4 *)0x0) {
    DAT_0212c410 = (undefined4 *)0x0;
  }
  else {
    *DAT_0212c410 =
         RBX::Reflection::
         PropDescriptor<class_RBX::PlayerGui,enum_RBX::BasePlayerGui::ScreenOrientation>::
         GetSetImpl<enum_RBX::BasePlayerGui::ScreenOrientation_(__thiscall_RBX::PlayerGui::*)(void)const_,void_(__thiscall_RBX::PlayerGui::*)(enum_RBX::BasePlayerGui::ScreenOrientation)>
         ::vftable;
    DAT_0212c410[2] = FUN_00a63240;
    DAT_0212c410[3] = 0;
    DAT_0212c410[4] = FUN_00b61b10;
    DAT_0212c410[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0212c414 = FUN_00b62060();
  cVar1 = (*(code *)DAT_0212c3d8[3])();
  if (cVar1 != '\0') {
    _DAT_0212c3fc = _DAT_0212c3fc & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0212c3d8[2])();
  if (cVar1 != '\0') {
    _DAT_0212c3fc = _DAT_0212c3fc & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0188e010);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1045 ; VA 0x004c29a0 ; FUN_004c29a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c29a0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4614;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b62060();
  uVar3 = FUN_00b56f90();
  FUN_009ca670(uVar3,uVar2,s_ScreenOrientation_0212c8d8,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0212c6e8 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::StarterGuiService,enum_RBX::BasePlayerGui::ScreenOrientation>
                 ::vftable;
  _DAT_0212c71c = uVar2;
  DAT_0212c720 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0212c720 == (undefined4 *)0x0) {
    DAT_0212c720 = (undefined4 *)0x0;
  }
  else {
    *DAT_0212c720 =
         RBX::Reflection::
         PropDescriptor<class_RBX::StarterGuiService,enum_RBX::BasePlayerGui::ScreenOrientation>::
         GetSetImpl<enum_RBX::BasePlayerGui::ScreenOrientation_(__thiscall_RBX::StarterGuiService::*)(void)const_,void_(__thiscall_RBX::StarterGuiService::*)(enum_RBX::BasePlayerGui::ScreenOrientation)>
         ::vftable;
    DAT_0212c720[2] = FUN_005fb8c0;
    DAT_0212c720[3] = 0;
    DAT_0212c720[4] = FUN_00b61c70;
    DAT_0212c720[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0212c724 = FUN_00b62060();
  cVar1 = (*(code *)DAT_0212c6e8[3])();
  if (cVar1 != '\0') {
    _DAT_0212c70c = _DAT_0212c70c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0212c6e8[2])();
  if (cVar1 != '\0') {
    _DAT_0212c70c = _DAT_0212c70c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0188e030);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1046 ; VA 0x004c2c60 ; FUN_004c2c60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c2c60(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4648;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b56db0(uVar2,0);
  FUN_009cb790(uVar1,s_SetUserGuiRendering_0212ca00,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212c728 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::CoreGuiService,void___cdecl(bool,class_std::shared_ptr<class_RBX::Instance>,enum_RBX::NormalId),3>
       ::vftable;
  _DAT_0212c760 = FUN_00b61ec0;
  _DAT_0212c764 = 0;
  _DAT_0212c768 = 0;
  _DAT_0212c76c = 0;
  _DAT_0212c770 = 0;
  uStack_8 = 3;
  FUN_00b5c5a0(s_enabled_02123dec,s_guiAdornee_0212c9f4,s_faceId_0212c9ec);
  FUN_016f3654(&LAB_0188e0d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1047 ; VA 0x004c2d30 ; FUN_004c2d30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c2d30(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f468e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b56f90();
  FUN_009cb970(uVar1,s_CoreGuiChangedSignal_0212c97c,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0212c5c4 = 0xd4;
  iStack_8 = 0;
  _DAT_0212c590 =
       RBX::Reflection::
       EventDesc<class_RBX::StarterGuiService,void___cdecl(enum_RBX::StarterGuiService::CoreGuiType,bool),class_rbx::signal<void___cdecl(enum_RBX::StarterGuiService::CoreGuiType,bool)>,class_rbx::signal<void___cdecl(enum_RBX::StarterGuiService::CoreGuiType,bool)>_RBX::StarterGuiService::*>
       ::vftable;
  FUN_0086e3d0(s_coreGuiType_0212c948);
  FUN_00b61fb0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_enabled_02123dec);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_0212c5b8 = uStack_1c;
  _DAT_0212c5bc = uStack_18;
  _DAT_0212c5c0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_0212c590 =
       RBX::Reflection::
       EventDesc<class_RBX::StarterGuiService,void___cdecl(enum_RBX::StarterGuiService::CoreGuiType,bool),class_rbx::signal<void___cdecl(enum_RBX::StarterGuiService::CoreGuiType,bool)>,class_rbx::signal<void___cdecl(enum_RBX::StarterGuiService::CoreGuiType,bool)>_RBX::StarterGuiService::*>
       ::vftable;
  FUN_016f3654(&LAB_0188e0e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1048 ; VA 0x004c2ea0 ; FUN_004c2ea0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c2ea0(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f46c3;
  pvStack_10 = ExceptionList;
  uStack_28 = 0;
  uStack_2c = CONCAT31(uStack_2c._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b56e90();
  FUN_009cb970(uVar1,s_TopbarTransparencyChangedSignal_0212c8b8,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0212c3d4 = 0x98;
  iStack_8 = 0;
  _DAT_0212c3a0 =
       RBX::Reflection::
       EventDesc<class_RBX::PlayerGui,void___cdecl(float),class_rbx::signal<void___cdecl(float)>,class_rbx::signal<void___cdecl(float)>_RBX::PlayerGui::*>
       ::vftable;
  FUN_0086e3d0(s_transparency_0212c878);
  FUN_0088c960();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0212c3c8 = uStack_1c;
  _DAT_0212c3cc = uStack_18;
  _DAT_0212c3d0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  FUN_016f3654(&LAB_0188e0f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1049 ; VA 0x004c2fe0 ; FUN_004c2fe0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c2fe0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f471c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b56f90();
  FUN_009cb820(uVar1,s_GetCore_0212c9e4,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0212c6a0 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::StarterGuiService,class_RBX::Reflection::Variant___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_0212c6d8 = FUN_00b5e860;
  _DAT_0212c6dc = 0;
  DAT_0212c6e0 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0212c6c4 = FUN_00888410();
  if (DAT_0212c6e0 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_0212c6e0);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_parameterName_0212c9a0);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_0188e100);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1050 ; VA 0x004c3160 ; FUN_004c3160 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c3160(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f477c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b56f90();
  FUN_009cb790(uVar1,s_GetCoreGuiEnabled_0212c968,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0212c548 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::StarterGuiService,bool___cdecl(enum_RBX::StarterGuiService::CoreGuiType),1>
       ::vftable;
  _DAT_0212c580 = FUN_00b5ec90;
  _DAT_0212c584 = 0;
  DAT_0212c588 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0212c56c = FUN_0088daf0();
  puVar3 = DAT_0212c588;
  if (DAT_0212c588 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_00b61fb0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00b62210();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_00b61fb0();
  uVar2 = FUN_0086e3d0(s_coreGuiType_0212c948);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_0188e120);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1051 ; VA 0x004c3300 ; FUN_004c3300 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c3300(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f47ae;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b56cd0(uVar2,0);
  FUN_009cb790(uVar1,s_GetGuiObjectsAtPosition_0212c830,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0212c210 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::BasePlayerGui,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(int,int),2>
       ::vftable;
  _DAT_0212c248 = FUN_00b5ee10;
  _DAT_0212c24c = 0;
  DAT_0212c250 = 0;
  DAT_0212c254 = 0;
  uStack_8 = 2;
  FUN_00b5c110();
  FUN_016f3654(&LAB_0188e140);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1052 ; VA 0x004c33c0 ; FUN_004c33c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c33c0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f47de;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b56cd0(uVar2,0);
  FUN_009cb790(uVar1,s_GetGuiObjectsInCircle_0212c848,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212c258 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::BasePlayerGui,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>___cdecl(class_G3D::Vector2,float),2>
       ::vftable;
  _DAT_0212c290 = FUN_00b5ee60;
  _DAT_0212c294 = 0;
  DAT_0212c298 = 0;
  DAT_0212c29c = 0;
  uStack_8 = 2;
  FUN_00b5c330();
  FUN_016f3654(&LAB_0188e180);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1053 ; VA 0x004c3480 ; FUN_004c3480 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c3480(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f47fa;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b56e90(uVar2,0);
  FUN_009cb790(uVar1,s_GetTopbarTransparency_0212c8a0,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212c360 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PlayerGui,float___cdecl(void),0>::vftable;
  _DAT_0212c398 = FUN_00b5f150;
  _DAT_0212c39c = 0;
  _DAT_0212c384 = FUN_0088c960();
  FUN_016f3654(&LAB_0188e1c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1054 ; VA 0x004c3520 ; FUN_004c3520 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c3520(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f482e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b56f90(uVar2,0);
  FUN_009cb790(uVar1,s_RegisterGetCore_0212c9cc,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212c610 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::StarterGuiService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Lua::WeakFunctionRef),2>
       ::vftable;
  _DAT_0212c648 = FUN_00b60720;
  _DAT_0212c64c = 0;
  _DAT_0212c650 = 0;
  DAT_0212c654 = 0;
  uStack_8 = 2;
  FUN_00b5cb50();
  FUN_016f3654(&LAB_0188e1d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1055 ; VA 0x004c35e0 ; FUN_004c35e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c35e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f485e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b56f90(uVar2,0);
  FUN_009cb790(uVar1,s_RegisterSetCore_0212c9b0,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212c5c8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::StarterGuiService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Lua::WeakFunctionRef),2>
       ::vftable;
  _DAT_0212c600 = FUN_00b607e0;
  _DAT_0212c604 = 0;
  _DAT_0212c608 = 0;
  DAT_0212c60c = 0;
  uStack_8 = 2;
  FUN_00b5cb50();
  FUN_016f3654(&LAB_0188e200);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1056 ; VA 0x004c36a0 ; FUN_004c36a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c36a0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f48b6;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uStack_1c0 = FUN_00888530();
  iStack_1bc = 0;
  uStack_8 = 0;
  FUN_005caf00(&uStack_1c0);
  uStack_8._0_1_ = 1;
  uVar1 = FUN_00b56f90();
  FUN_009cb790(uVar1,s_SetCore_0212c9dc,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0212c658 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::StarterGuiService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant),2>
       ::vftable;
  _DAT_0212c690 = FUN_00b616a0;
  _DAT_0212c694 = 0;
  _DAT_0212c698 = 0;
  uStack_8._0_1_ = 3;
  puVar2 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 4;
  puStack_14 = puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    DAT_0212c69c = (undefined4 *)0x0;
  }
  else {
    *puVar2 = uStack_f0;
    puVar2[1] = 0;
    if (puStack_ec != (undefined4 *)0x0) {
      (*(code *)*puStack_ec)();
    }
    puVar2[1] = puStack_ec;
    DAT_0212c69c = puVar2;
  }
  uStack_8._0_1_ = 5;
  FUN_00b5c940();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (puStack_ec != (undefined4 *)0x0) {
    (*(code *)puStack_ec[2])(auStack_e8);
  }
  uStack_8 = 7;
  if (iStack_1bc != 0) {
    (**(code **)(iStack_1bc + 8))(auStack_1b8);
  }
  FUN_016f3654(FUN_0188e230);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1057 ; VA 0x004c3820 ; FUN_004c3820 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c3820(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f48de;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b56f90(uVar2,0);
  FUN_009cb790(uVar1,s_SetCoreGuiEnabled_0212c954,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0212c500 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::StarterGuiService,void___cdecl(enum_RBX::StarterGuiService::CoreGuiType,bool),2>
       ::vftable;
  _DAT_0212c538 = FUN_00b61930;
  _DAT_0212c53c = 0;
  DAT_0212c540 = 0;
  DAT_0212c544 = 0;
  uStack_8 = 2;
  FUN_00b5cdc0();
  FUN_016f3654(&LAB_0188e2a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1058 ; VA 0x004c38e0 ; FUN_004c38e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c38e0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f493c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_1c = 0;
  uStack_20 = CONCAT31(uStack_20._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b56e90();
  FUN_009cb790(uVar1,s_SetTopbarTransparency_0212c888,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0212c318 =
       RBX::Reflection::BoundFuncDesc<class_RBX::PlayerGui,void___cdecl(float),1>::vftable;
  _DAT_0212c350 = FUN_00b61e30;
  _DAT_0212c354 = 0;
  DAT_0212c358 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0212c33c = FUN_00888530();
  if (DAT_0212c358 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_006ea440(DAT_0212c358);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088c960();
  uVar3 = FUN_0086e3d0(s_transparency_0212c878);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_0188e2e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1059 ; VA 0x004c3a60 ; FUN_004c3a60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c3a60(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f495a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b56db0(uVar2,0);
  FUN_009cb790(uVar1,s_TakeScreenshot_0212ca14,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212c778 =
       RBX::Reflection::BoundFuncDesc<class_RBX::CoreGuiService,void___cdecl(void),0>::vftable;
  _DAT_0212c7b0 = &LAB_00b622f0;
  _DAT_0212c7b4 = 0;
  _DAT_0212c79c = FUN_00888530();
  FUN_016f3654(&LAB_0188e300);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1060 ; VA 0x004c3b00 ; FUN_004c3b00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c3b00(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f497a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b56db0(uVar2,0);
  FUN_009cb790(uVar1,s_ToggleRecording_0212ca24,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212c7b8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::CoreGuiService,void___cdecl(void),0>::vftable;
  _DAT_0212c7f0 = &LAB_00b62310;
  _DAT_0212c7f4 = 0;
  _DAT_0212c7dc = FUN_00888530();
  FUN_016f3654(&LAB_0188e310);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1061 ; VA 0x004c3bf0 ; FUN_004c3bf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c3bf0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f49a4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b62160();
  uVar3 = FUN_00b56db0();
  FUN_009ca670(uVar3,uVar2,s_SelectionImageObject_0212c860,s_Appearance_02119800,uStack_24,0,0,0x1f,
               5,5,0);
  uStack_8 = 0;
  DAT_0212c2dc = RBX::Reflection::RefPropDescriptor<class_RBX::CoreGuiService,class_RBX::GuiObject>
                 ::vftable;
  _DAT_0212c310 =
       RBX::Reflection::RefPropDescriptor<class_RBX::CoreGuiService,class_RBX::GuiObject>::vftable;
  DAT_0212c314 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0212c314 == (undefined4 *)0x0) {
    DAT_0212c314 = (undefined4 *)0x0;
  }
  else {
    *DAT_0212c314 =
         RBX::Reflection::PropDescriptor<class_RBX::CoreGuiService,class_RBX::GuiObject*>::
         GetSetImpl<class_RBX::GuiObject*_(__thiscall_RBX::BasePlayerGui::*)(void)const_,void_(__thiscall_RBX::CoreGuiService::*)(class_RBX::GuiObject*)>
         ::vftable;
    DAT_0212c314[2] = FUN_00b5f140;
    DAT_0212c314[3] = 0;
    DAT_0212c314[4] = &LAB_008af4eb;
    DAT_0212c314[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  cVar1 = (*(code *)DAT_0212c2dc[3])();
  if (cVar1 != '\0') {
    _DAT_0212c300 = _DAT_0212c300 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0212c2dc[2])();
  if (cVar1 != '\0') {
    _DAT_0212c300 = _DAT_0212c300 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0188e380);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1062 ; VA 0x004c3d10 ; FUN_004c3d10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c3d10(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f49c4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b62160();
  uVar3 = FUN_00b56e90();
  FUN_009ca670(uVar3,uVar2,s_SelectionImageObject_0212c860,s_Appearance_02119800,uStack_24,0,0,0x1f,
               0,0,0);
  uStack_8 = 0;
  DAT_0212c2a0 = RBX::Reflection::RefPropDescriptor<class_RBX::PlayerGui,class_RBX::GuiObject>::
                 vftable;
  _DAT_0212c2d4 =
       RBX::Reflection::RefPropDescriptor<class_RBX::PlayerGui,class_RBX::GuiObject>::vftable;
  DAT_0212c2d8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0212c2d8 == (undefined4 *)0x0) {
    DAT_0212c2d8 = (undefined4 *)0x0;
  }
  else {
    *DAT_0212c2d8 =
         RBX::Reflection::PropDescriptor<class_RBX::PlayerGui,class_RBX::GuiObject*>::
         GetSetImpl<class_RBX::GuiObject*_(__thiscall_RBX::BasePlayerGui::*)(void)const_,void_(__thiscall_RBX::PlayerGui::*)(class_RBX::GuiObject*)>
         ::vftable;
    DAT_0212c2d8[2] = FUN_00b5f140;
    DAT_0212c2d8[3] = 0;
    DAT_0212c2d8[4] = &LAB_008af4eb;
    DAT_0212c2d8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  cVar1 = (*(code *)DAT_0212c2a0[3])();
  if (cVar1 != '\0') {
    _DAT_0212c2c4 = _DAT_0212c2c4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0212c2a0[2])();
  if (cVar1 != '\0') {
    _DAT_0212c2c4 = _DAT_0212c2c4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0188e3a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1063 ; VA 0x004c3e30 ; FUN_004c3e30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c3e30(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f49ec;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b56db0();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::CoreGuiService,int>::
              GetImpl<int_(__thiscall_RBX::CoreGuiService::*)(void)const_>::vftable;
    puVar3[2] = FUN_00554ed0;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,s_Version_0212ca34,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_0212c7f8 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0212c82c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0212c81c = _DAT_0212c81c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0212c7f8[2])();
    if (cVar1 != '\0') {
      _DAT_0212c81c = _DAT_0212c81c & 0xfffffff3;
    }
  }
  DAT_0212c7f8 = RBX::Reflection::PropDescriptor<class_RBX::CoreGuiService,int>::vftable;
  FUN_016f3654(&LAB_0188e3c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1064 ; VA 0x004c3f50 ; FUN_004c3f50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c3f50(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f4a14;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b62060();
  uVar3 = FUN_00b56e90();
  FUN_009ca670(uVar3,uVar2,s_CurrentScreenOrientation_0212c8ec,&DAT_021197d4,uStack_24,0,0,0x13,0,0,
               1);
  uStack_8 = 0;
  DAT_0212c418 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::PlayerGui,enum_RBX::BasePlayerGui::ScreenOrientation>
                 ::vftable;
  _DAT_0212c44c = uVar2;
  DAT_0212c450 = (undefined4 *)FUN_01674e20(0x10);
  if (DAT_0212c450 == (undefined4 *)0x0) {
    DAT_0212c450 = (undefined4 *)0x0;
  }
  else {
    *DAT_0212c450 =
         RBX::Reflection::
         PropDescriptor<class_RBX::PlayerGui,enum_RBX::BasePlayerGui::ScreenOrientation>::
         GetImpl<enum_RBX::BasePlayerGui::ScreenOrientation_(__thiscall_RBX::PlayerGui::*)(void)const_>
         ::vftable;
    DAT_0212c450[2] = FUN_00b5ece0;
    DAT_0212c450[3] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0212c454 = FUN_00b62060();
  cVar1 = (*(code *)DAT_0212c418[3])();
  if (cVar1 != '\0') {
    _DAT_0212c43c = _DAT_0212c43c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0212c418[2])();
  if (cVar1 != '\0') {
    _DAT_0212c43c = _DAT_0212c43c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0188e3e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1065 ; VA 0x004c4060 ; FUN_004c4060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c4060(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f505c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b623e0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ServerScriptService,bool>::
              GetSetImpl<bool_(__thiscall_RBX::ServerScriptService::*)(void)const_,void_(__thiscall_RBX::ServerScriptService::*)(bool)>
              ::vftable;
    puVar3[2] = FUN_009501e0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00b62870;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_LoadStringEnabled_0212ca74,s_Behavior_0211a8f8,uStack_24,0,0,0xd,0,0,0)
  ;
  DAT_0212ca3c = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0212ca70 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0212ca60 = _DAT_0212ca60 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0212ca3c[2])();
    if (cVar1 != '\0') {
      _DAT_0212ca60 = _DAT_0212ca60 & 0xfffffff3;
    }
  }
  DAT_0212ca3c = RBX::Reflection::PropDescriptor<class_RBX::ServerScriptService,bool>::vftable;
  FUN_016f3654(&LAB_0188e4a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1066 ; VA 0x004c4320 ; FUN_004c4320 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c4320(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f518a;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b629b0(uVar2,0);
  FUN_009cb790(uVar1,s_ConvertToSmooth_0212a1ec,1,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212cbd8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::TerrainRegion,void___cdecl(void),0>::vftable;
  _DAT_0212cc10 = FUN_00b630e0;
  _DAT_0212cc14 = 0;
  _DAT_0212cbfc = FUN_00888530();
  FUN_016f3654(&LAB_0188e560);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1067 ; VA 0x004c43c0 ; FUN_004c43c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c43c0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f51bc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b629b0();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::TerrainRegion,class_G3D::Vector3>::
              GetImpl<class_G3D::Vector3_(__thiscall_RBX::TerrainRegion::*)(void)const_>::vftable;
    puVar3[2] = FUN_00b63950;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d870();
  FUN_009ca670(uVar2,uVar4,s_SizeInCells_0212cc18,&DAT_021197d4,uStack_24,0,0,0x15,0,0,0);
  DAT_0212ca88 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0212cabc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0212caac = _DAT_0212caac & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0212ca88[2])();
    if (cVar1 != '\0') {
      _DAT_0212caac = _DAT_0212caac & 0xfffffff3;
    }
  }
  DAT_0212ca88 = RBX::Reflection::PropDescriptor<class_RBX::TerrainRegion,class_G3D::Vector3>::
                 vftable;
  FUN_016f3654(&LAB_0188e570);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1068 ; VA 0x004c46b0 ; FUN_004c46b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c46b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f53a4;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b671d0();
  uVar3 = FUN_00b63e30();
  FUN_009ca670(uVar3,uVar2,s_LevelOfDetail_0212d2e8,s_Appearance_02119800,uStack_3c,0,0,0x1f,1,1,1);
  uStack_8 = 0;
  DAT_0212ccf0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::ModelInstance,enum_RBX::ModelLevelOfDetail>::vftable;
  _DAT_0212cd24 = uVar2;
  DAT_0212cd28 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_0212cd28 == (undefined4 *)0x0) {
    DAT_0212cd28 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_0212cd28 + 2) = 0xb659a0;
    *(undefined8 *)(DAT_0212cd28 + 6) = 0xb66b20;
    *DAT_0212cd28 =
         RBX::Reflection::PropDescriptor<class_RBX::ModelInstance,enum_RBX::ModelLevelOfDetail>::
         GetSetImpl<enum_RBX::ModelLevelOfDetail_const_(__thiscall_RBX::ModelInstance::*)(void)const_,void_(__thiscall_RBX::ModelInstance::*)(enum_RBX::ModelLevelOfDetail)>
         ::vftable;
    DAT_0212cd28[4] = 0;
    DAT_0212cd28[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0212cd2c = FUN_00b671d0();
  cVar1 = (*(code *)DAT_0212ccf0[3])();
  if (cVar1 != '\0') {
    _DAT_0212cd14 = _DAT_0212cd14 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0212ccf0[2])();
  if (cVar1 != '\0') {
    _DAT_0212cd14 = _DAT_0212cd14 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0188e650);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1069 ; VA 0x004c47f0 ; FUN_004c47f0 */

void FUN_004c47f0(void)

{
  FUN_00b63d20(s_ModelMeshCFrame_0212d2b8,&DAT_021197d4,0xb65b40,0,0xb66c40,0,0,0,0,0xe,0);
  FUN_016f3654(&LAB_0188e670);
  return;
}



/* FUNCTION 1070 ; VA 0x004c4880 ; FUN_004c4880 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c4880(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f53cc;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b63e30();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0xb4dfd0;
    *(undefined8 *)(puVar3 + 6) = 0xb66cc0;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ModelInstance,class_RBX::SharedString>::
              GetSetImpl<class_RBX::SharedString_const&_(__thiscall_RBX::ModelInstance::*)(void)const_,void_(__thiscall_RBX::ModelInstance::*)(class_RBX::SharedString_const&)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d4b0();
  FUN_009ca670(uVar2,uVar4,s_ModelMeshData_0212d2d8,&DAT_021197d4,uStack_3c,0,0,0xe,0,0,0);
  DAT_0212ccb8 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::SharedString>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0212ccec = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0212ccdc = _DAT_0212ccdc & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0212ccb8[2])();
    if (cVar1 != '\0') {
      _DAT_0212ccdc = _DAT_0212ccdc & 0xfffffff3;
    }
  }
  DAT_0212ccb8 = RBX::Reflection::PropDescriptor<class_RBX::ModelInstance,class_RBX::SharedString>::
                 vftable;
  FUN_016f3654(&LAB_0188e690);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1071 ; VA 0x004c49d0 ; FUN_004c49d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c49d0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_3c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f53fc;
  pvStack_10 = ExceptionList;
  uStack_3c = uStack_3c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b63e30();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(puVar3 + 2) = 0xb65b50;
    *(undefined8 *)(puVar3 + 6) = 0xb66d00;
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::ModelInstance,class_G3D::Vector3>::
              GetSetImpl<class_G3D::Vector3_const&_(__thiscall_RBX::ModelInstance::*)(void)const_,void_(__thiscall_RBX::ModelInstance::*)(class_G3D::Vector3_const&)>
              ::vftable;
    puVar3[4] = 0;
    puVar3[8] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d870();
  FUN_009ca670(uVar2,uVar4,s_ModelMeshSize_0212d2c8,&DAT_021197d4,uStack_3c,0,0,0xe,0,0,0);
  DAT_0212cc80 = RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0212ccb4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0212cca4 = _DAT_0212cca4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0212cc80[2])();
    if (cVar1 != '\0') {
      _DAT_0212cca4 = _DAT_0212cca4 & 0xfffffff3;
    }
  }
  DAT_0212cc80 = RBX::Reflection::PropDescriptor<class_RBX::ModelInstance,class_G3D::Vector3>::
                 vftable;
  FUN_016f3654(&LAB_0188e6b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1072 ; VA 0x004c4cb0 ; FUN_004c4cb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c4cb0(void)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f541a;
  pvStack_10 = ExceptionList;
  uStack_1c = CONCAT31(uStack_1c._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b63e30();
  FUN_009cb790(uVar1,s_breakJoints_0212d3a4,0,CONCAT44(&DAT_0212cda8,uStack_1c),0);
  _DAT_0212d0f8 = 0xb64cd0;
  uStack_8 = 0;
  _DAT_0212d0c0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ModelInstance,void___cdecl(void),0>::vftable;
  _DAT_0212d100 = 0;
  _DAT_0212d0e4 = FUN_00888530();
  FUN_016f3654(&LAB_0188e6f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1073 ; VA 0x004c4d60 ; FUN_004c4d60 */

void FUN_004c4d60(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00b642b0(0xe70530,0,s_moveTo_0212d3b0,s_location_02123e14,0,CONCAT44(&DAT_0212cf58,uStack_10),
               0);
  FUN_016f3654(&LAB_0188e700);
  return;
}



/* FUNCTION 1074 ; VA 0x004c4dd0 ; FUN_004c4dd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c4dd0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f543a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b63e30();
  FUN_009cb790(uVar1,s_BreakJoints_0211ba08,0,uStack_1c,0);
  _DAT_0212cde0 = 0xb64cd0;
  uStack_8 = 0;
  _DAT_0212cda8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ModelInstance,void___cdecl(void),0>::vftable;
  _DAT_0212cde8 = 0;
  _DAT_0212cdcc = FUN_00888530();
  FUN_016f3654(&LAB_0188e720);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1075 ; VA 0x004c4e80 ; FUN_004c4e80 */

void FUN_004c4e80(void)

{
  FUN_00b63d20(s_ModelInPrimary_0212d2f8,&DAT_021197d4,0x763950,0,0xb66c10,0,0,0,0,0xe,0);
  FUN_016f3654(&LAB_0188e730);
  return;
}



/* FUNCTION 1076 ; VA 0x004c4f10 ; FUN_004c4f10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c4f10(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f545a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b63e30();
  FUN_009cb790(uVar1,s_MakeJoints_0211b9fc,0,uStack_1c,0);
  _DAT_0212ce28 = 0xb661a0;
  uStack_8 = 0;
  _DAT_0212cdf0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ModelInstance,void___cdecl(void),0>::vftable;
  _DAT_0212ce30 = 0;
  _DAT_0212ce14 = FUN_00888530();
  FUN_016f3654(&LAB_0188e750);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1077 ; VA 0x004c4fc0 ; FUN_004c4fc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c4fc0(void)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f547a;
  pvStack_10 = ExceptionList;
  uStack_1c = CONCAT31(uStack_1c._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b63e30();
  FUN_009cb790(uVar1,s_makeJoints_0212d398,0,CONCAT44(&DAT_0212cdf0,uStack_1c),0);
  _DAT_0212d0b0 = 0xb661a0;
  uStack_8 = 0;
  _DAT_0212d078 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ModelInstance,void___cdecl(void),0>::vftable;
  _DAT_0212d0b8 = 0;
  _DAT_0212d09c = FUN_00888530();
  FUN_016f3654(&LAB_0188e760);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1078 ; VA 0x004c5070 ; FUN_004c5070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c5070(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffc4;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f54b0;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffc4 & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x1f;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee410c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee410c,uVar3,0,0,0x1f);
    if (DAT_01ee410c == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01ee40e8 = RBX::Reflection::RefType<class_RBX::PartInstance*>::vftable;
      FUN_016f3654(&LAB_01887330);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ee410c);
    }
  }
  uVar2 = FUN_00b63e30();
  FUN_009ca670(uVar2,&DAT_01ee40e8,s_PrimaryPart_0212d308,&DAT_021197d4,uVar3,uVar4,uVar5,uVar6,0,0,
               0);
  uStack_8 = 1;
  DAT_0212cd68 = RBX::Reflection::
                 RefPropDescriptor<class_RBX::ModelInstance,class_RBX::PartInstance>::vftable;
  _DAT_0212cd9c =
       RBX::Reflection::RefPropDescriptor<class_RBX::ModelInstance,class_RBX::PartInstance>::vftable
  ;
  DAT_0212cda0 = (undefined4 *)FUN_01674e20(0x28);
  if (DAT_0212cda0 == (undefined4 *)0x0) {
    DAT_0212cda0 = (undefined4 *)0x0;
  }
  else {
    *(undefined8 *)(DAT_0212cda0 + 2) = 0xb65ea0;
    *(undefined8 *)(DAT_0212cda0 + 6) = 0xb67030;
    *DAT_0212cda0 =
         RBX::Reflection::PropDescriptor<class_RBX::ModelInstance,class_RBX::PartInstance*>::
         GetSetImpl<class_RBX::PartInstance*_(__thiscall_RBX::ModelInstance::*)(void)const_,void_(__thiscall_RBX::ModelInstance::*)(class_RBX::PartInstance*)>
         ::vftable;
    DAT_0212cda0[4] = 0;
    DAT_0212cda0[8] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_0212cd68[3])();
  if (cVar1 != '\0') {
    _DAT_0212cd8c = _DAT_0212cd8c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0212cd68[2])();
  if (cVar1 != '\0') {
    _DAT_0212cd8c = _DAT_0212cd8c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0188e770);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1079 ; VA 0x004c5230 ; FUN_004c5230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c5230(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f54ca;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b63e30();
  FUN_009cb790(uVar1,s_GetBoundingBox_0212d368,0,uStack_1c,0);
  _DAT_0212cfd8 = 0xb65790;
  uStack_8 = 0;
  _DAT_0212cfa0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ModelInstance,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0212cfe0 = 0;
  _DAT_0212cfc4 = FUN_0088cbe0();
  FUN_016f3654(&LAB_0188e790);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1080 ; VA 0x004c52e0 ; FUN_004c52e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c52e0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f54ea;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b63e30();
  FUN_009cb790(uVar1,s_GetExtentsSize_0212d314,0,uStack_1c,0);
  _DAT_0212ce70 = 0xb64df0;
  uStack_8 = 0;
  _DAT_0212ce38 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ModelInstance,class_G3D::Vector3___cdecl(void),0>::
       vftable;
  _DAT_0212ce78 = 0;
  _DAT_0212ce5c = FUN_0088d870();
  FUN_016f3654(&LAB_0188e7a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1081 ; VA 0x004c5390 ; FUN_004c5390 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c5390(void)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f550a;
  pvStack_10 = ExceptionList;
  uStack_1c = CONCAT31(uStack_1c._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b63e30();
  FUN_009cb790(uVar1,s_GetModelCFrame_0212d388,0,CONCAT44(&DAT_0212cec8,uStack_1c),0);
  _DAT_0212d068 = 0xb64cf0;
  uStack_8 = 0;
  _DAT_0212d030 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ModelInstance,class_G3D::CoordinateFrame___cdecl(void),0>::vftable;
  _DAT_0212d070 = 0;
  _DAT_0212d054 = FUN_00b00260();
  FUN_016f3654(&LAB_0188e7b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1082 ; VA 0x004c5440 ; FUN_004c5440 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c5440(void)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f552a;
  pvStack_10 = ExceptionList;
  uStack_1c = CONCAT31(uStack_1c._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b63e30();
  FUN_009cb790(uVar1,s_GetModelSize_0212d378,0,CONCAT44(&DAT_0212ce38,uStack_1c),0);
  _DAT_0212d020 = 0xb64df0;
  uStack_8 = 0;
  _DAT_0212cfe8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ModelInstance,class_G3D::Vector3___cdecl(void),0>::
       vftable;
  _DAT_0212d028 = 0;
  _DAT_0212d00c = FUN_0088d870();
  FUN_016f3654(&LAB_0188e7c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1083 ; VA 0x004c54f0 ; FUN_004c54f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c54f0(void)

{
  undefined4 uVar1;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f554a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b63e30();
  FUN_009cb790(uVar1,s_GetPrimaryPartCFrame_0212d338,0,uStack_1c,0);
  _DAT_0212cf00 = 0xb65c40;
  uStack_8 = 0;
  _DAT_0212cec8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ModelInstance,class_G3D::CoordinateFrame___cdecl(void),0>::vftable;
  _DAT_0212cf08 = 0;
  _DAT_0212ceec = FUN_00b00260();
  FUN_016f3654(&LAB_0188e7d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1084 ; VA 0x004c55a0 ; FUN_004c55a0 */

void FUN_004c55a0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b642b0(0xe70570,0,s_MoveTo_02123e20,s_position_0211fd1c,0,uStack_10,0);
  FUN_016f3654(&LAB_0188e7e0);
  return;
}



/* FUNCTION 1085 ; VA 0x004c5610 ; FUN_004c5610 */

void FUN_004c5610(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00b642b0(0xe70530,0,&DAT_0212d3b8,s_location_02123e14,0,CONCAT44(&DAT_0212cf58,uStack_10),0);
  FUN_016f3654(&LAB_0188e800);
  return;
}



/* FUNCTION 1086 ; VA 0x004c5680 ; FUN_004c5680 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c5680(void)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f556a;
  pvStack_10 = ExceptionList;
  uStack_1c = CONCAT31(uStack_1c._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b63e30();
  FUN_009cb790(uVar1,s_ResetOrientationToIdentity_0212d3d8,0,CONCAT44(&DAT_0212cf10,uStack_1c),0);
  _DAT_0212d218 = 0xb66630;
  uStack_8 = 0;
  _DAT_0212d1e0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ModelInstance,void___cdecl(void),0>::vftable;
  _DAT_0212d220 = 0;
  _DAT_0212d204 = FUN_00888530();
  FUN_016f3654(&LAB_0188e820);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1087 ; VA 0x004c5730 ; FUN_004c5730 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c5730(void)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f558a;
  pvStack_10 = ExceptionList;
  uStack_1c = CONCAT31(uStack_1c._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b63e30();
  FUN_009cb790(uVar1,s_SetIdentityOrientation_0212d3c0,0,CONCAT44(&DAT_0212cf10,uStack_1c),0);
  _DAT_0212d1d0 = 0xb669d0;
  uStack_8 = 0;
  _DAT_0212d198 =
       RBX::Reflection::BoundFuncDesc<class_RBX::ModelInstance,void___cdecl(void),0>::vftable;
  _DAT_0212d1d8 = 0;
  _DAT_0212d1bc = FUN_00888530();
  FUN_016f3654(&LAB_0188e830);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1088 ; VA 0x004c57e0 ; FUN_004c57e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c57e0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1cc;
  int iStack_1c8;
  undefined auStack_1c4 [200];
  undefined4 uStack_fc;
  int iStack_f8;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  code *pcStack_2c;
  undefined4 uStack_28;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f55ec;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  pcStack_2c = FUN_00b66dc0;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b63e30();
  FUN_009cb790(uVar1,s_SetPrimaryPartCFrame_0212d350,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0212cf48 = CONCAT44(uStack_28,pcStack_2c);
  _DAT_0212cf10 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::ModelInstance,void___cdecl(class_G3D::CoordinateFrame),1>::vftable;
  _DAT_0212cf50 = 0;
  DAT_0212cf54 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0212cf34 = FUN_00888530();
  puVar3 = DAT_0212cf54;
  if (DAT_0212cf54 == (undefined4 *)0x0) {
    uStack_1cc = FUN_00888530();
    iStack_1c8 = 0;
    puVar3 = &uStack_1cc;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_fc = FUN_00b00260();
    iStack_f8 = 0;
    uStack_f4 = *puVar3;
    uStack_f0 = puVar3[1];
    uStack_ec = puVar3[2];
    uStack_e8 = puVar3[3];
    uStack_e4 = puVar3[4];
    uStack_e0 = puVar3[5];
    uStack_dc = puVar3[6];
    uStack_d8 = puVar3[7];
    uStack_d4 = puVar3[8];
    uStack_d0 = puVar3[9];
    uStack_cc = puVar3[10];
    uStack_c8 = puVar3[0xb];
    iStack_f8 = FUN_00630d60();
    puVar3 = &uStack_fc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_00b00260();
  uVar2 = FUN_0086e3d0(s_cframe_0212a324);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1c8 != 0) {
      (**(code **)(iStack_1c8 + 8))(auStack_1c4);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_f8 != 0) {
      (**(code **)(iStack_f8 + 8))(&uStack_f4);
    }
  }
  FUN_016f3654(&LAB_0188e840);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1089 ; VA 0x004c59b0 ; FUN_004c59b0 */

void FUN_004c59b0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b642b0(0xb672f0,0,s_TranslateBy_0212d32c,s_delta_0212d324,0,uStack_10,0);
  FUN_016f3654(&LAB_0188e860);
  return;
}



/* FUNCTION 1090 ; VA 0x004c5a40 ; FUN_004c5a40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c5a40(void)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_6c;
  undefined uStack_68;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined uStack_4c;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined uStack_30;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 auStack_18 [2];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5d31;
  pvStack_10 = ExceptionList;
  uStack_6c = 0;
  uStack_58 = 0;
  uStack_54 = 0xf;
  uStack_68 = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("Default",7);
  uStack_8 = 0;
  uStack_50 = 1;
  uStack_3c = 0;
  uStack_38 = 0xf;
  uStack_4c = 0;
  FUN_005542c0("Acquire",7);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uStack_34 = 2;
  uStack_20 = 0;
  uStack_1c = 0xf;
  uStack_30 = 0;
  FUN_005542c0("Spend",5);
  uStack_8 = 2;
  _DAT_01ef0628 = 0;
  DAT_01ef062c = (int *)0x0;
  DAT_01ef0630 = 0;
  DAT_01ef062c = (int *)FUN_00616d10(0,0);
  DAT_01ef0634 = 0;
  _DAT_01ef0638 = 0;
  _DAT_01ef063c = 0;
  uStack_8._0_1_ = 4;
  _DAT_01ef0628 = 0x3f800000;
  FUN_005cb500(8);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  puVar4 = &uStack_6c;
  do {
    iVar1 = *DAT_01ef062c;
    puVar2 = *(undefined4 **)(iVar1 + 4);
    uVar3 = FUN_00a4e720(iVar1,puVar2,puVar4);
    if (DAT_01ef0630 == 0x71c71c6) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    DAT_01ef0630 = DAT_01ef0630 + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puVar2 = uVar3;
    FUN_00a4eef0(auStack_18,*DAT_01ef062c + 8,*DAT_01ef062c);
    puVar4 = puVar4 + 7;
  } while (puVar4 != auStack_18);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&uStack_6c,0x1c,3,FUN_0056c780);
  FUN_016f3654(&LAB_0188e960);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1091 ; VA 0x004c5c00 ; FUN_004c5c00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c5c00(void)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  void **ppvVar4;
  undefined auStack_c0 [8];
  void *pvStack_b8;
  undefined uStack_b4;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined uStack_98;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined uStack_7c;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined uStack_60;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined uStack_44;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined uStack_28;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5da2;
  pvStack_10 = ExceptionList;
  pvStack_b8 = (void *)0x0;
  uStack_a4 = 0;
  uStack_a0 = 0xf;
  uStack_b4 = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("Trace",5);
  uStack_8 = 0;
  uStack_9c = 1;
  uStack_88 = 0;
  uStack_84 = 0xf;
  uStack_98 = 0;
  FUN_005542c0("Debug",5);
  uStack_8._0_1_ = 1;
  uStack_80 = 2;
  uStack_6c = 0;
  uStack_68 = 0xf;
  uStack_7c = 0;
  FUN_005542c0("Information",0xb);
  uStack_8._0_1_ = 2;
  uStack_64 = 3;
  uStack_50 = 0;
  uStack_4c = 0xf;
  uStack_60 = 0;
  FUN_005542c0("Warning",7);
  uStack_8._0_1_ = 3;
  uStack_48 = 4;
  uStack_34 = 0;
  uStack_30 = 0xf;
  uStack_44 = 0;
  FUN_005542c0("Error",5);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  uStack_2c = 5;
  uStack_18 = 0;
  uStack_14 = 0xf;
  uStack_28 = 0;
  FUN_005542c0("Fatal",5);
  uStack_8 = 5;
  _DAT_01ef0668 = 0;
  DAT_01ef066c = (int *)0x0;
  DAT_01ef0670 = 0;
  DAT_01ef066c = (int *)FUN_00616d10(0,0);
  DAT_01ef0674 = 0;
  _DAT_01ef0678 = 0;
  _DAT_01ef067c = 0;
  uStack_8._0_1_ = 7;
  _DAT_01ef0668 = 0x3f800000;
  FUN_005cb500(8);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  ppvVar4 = &pvStack_b8;
  do {
    iVar1 = *DAT_01ef066c;
    puVar2 = *(undefined4 **)(iVar1 + 4);
    uVar3 = FUN_00a4e720(iVar1,puVar2,ppvVar4);
    if (DAT_01ef0670 == 0x71c71c6) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    DAT_01ef0670 = DAT_01ef0670 + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puVar2 = uVar3;
    FUN_00a4eef0(auStack_c0,*DAT_01ef066c + 8,*DAT_01ef066c);
    ppvVar4 = ppvVar4 + 7;
  } while (ppvVar4 != &pvStack_10);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&pvStack_b8,0x1c,6,FUN_0056c780);
  FUN_016f3654(&LAB_0188e970);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1092 ; VA 0x004c5e70 ; FUN_004c5e70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c5e70(void)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  void **ppvVar4;
  undefined auStack_a4 [8];
  void *pvStack_9c;
  undefined uStack_98;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined uStack_7c;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined uStack_60;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined uStack_44;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined uStack_28;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5e07;
  pvStack_10 = ExceptionList;
  pvStack_9c = (void *)0x0;
  uStack_88 = 0;
  uStack_84 = 0xf;
  uStack_98 = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("Default",7);
  uStack_8 = 0;
  uStack_80 = 1;
  uStack_6c = 0;
  uStack_68 = 0xf;
  uStack_7c = 0;
  FUN_005542c0("Begin",5);
  uStack_8._0_1_ = 1;
  uStack_64 = 2;
  uStack_50 = 0;
  uStack_4c = 0xf;
  uStack_60 = 0;
  FUN_005542c0("Complete",8);
  uStack_8._0_1_ = 2;
  uStack_48 = 3;
  uStack_34 = 0;
  uStack_30 = 0xf;
  uStack_44 = 0;
  FUN_005542c0("Abandon",7);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_2c = 4;
  uStack_18 = 0;
  uStack_14 = 0xf;
  uStack_28 = 0;
  FUN_005542c0(&DAT_019569dc,4);
  uStack_8 = 4;
  _DAT_01ef0648 = 0;
  DAT_01ef064c = (int *)0x0;
  DAT_01ef0650 = 0;
  DAT_01ef064c = (int *)FUN_00616d10(0,0);
  DAT_01ef0654 = 0;
  _DAT_01ef0658 = 0;
  _DAT_01ef065c = 0;
  uStack_8._0_1_ = 6;
  _DAT_01ef0648 = 0x3f800000;
  FUN_005cb500(8);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  ppvVar4 = &pvStack_9c;
  do {
    iVar1 = *DAT_01ef064c;
    puVar2 = *(undefined4 **)(iVar1 + 4);
    uVar3 = FUN_00a4e720(iVar1,puVar2,ppvVar4);
    if (DAT_01ef0650 == 0x71c71c6) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    DAT_01ef0650 = DAT_01ef0650 + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puVar2 = uVar3;
    FUN_00a4eef0(auStack_a4,*DAT_01ef064c + 8,*DAT_01ef064c);
    ppvVar4 = ppvVar4 + 7;
  } while (ppvVar4 != &pvStack_10);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(&pvStack_9c,0x1c,5,FUN_0056c780);
  FUN_016f3654(&LAB_0188e980);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1093 ; VA 0x004c6a70 ; FUN_004c6a70 */

void FUN_004c6a70(void)

{
  undefined auStack_374 [416];
  undefined4 uStack_1d4;
  undefined8 uStack_1d0;
  undefined *puStack_1c8;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5e6e;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  puStack_1c8 = (undefined *)0x4c6a9f;
  ExceptionList = &pvStack_10;
  uStack_1c0 = FUN_00888530();
  iStack_1bc = 0;
  uStack_8 = 0;
  puStack_1c8 = (undefined *)0x4c6abb;
  uStack_f0 = FUN_00888530();
  iStack_ec = 0;
  uStack_1d0 = CONCAT44(uStack_1c,uStack_20);
  uStack_8._0_1_ = 1;
  uStack_1d4 = 0;
  puStack_14 = auStack_374;
  puStack_1c8 = (undefined *)0x0;
  FUN_005caf00(&uStack_f0);
  uStack_8._0_1_ = 2;
  FUN_005caf00(&uStack_1c0);
  uStack_8._0_1_ = 1;
  FUN_00b697c0(FUN_00b6f230,0,s_FireLogEvent_0212d6b4,s_player_0211f800,s_logLevel_0212d6a8,
               s_message_02119b14,s_debugInfo_0212d69c,s_customData_0212d604);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (iStack_ec != 0) {
    puStack_1c8 = auStack_e8;
    uStack_1d0 = CONCAT44(0x4c6b62,(undefined4)uStack_1d0);
    (**(code **)(iStack_ec + 8))();
  }
  uStack_8 = 4;
  if (iStack_1bc != 0) {
    puStack_1c8 = auStack_1b8;
    uStack_1d0 = CONCAT44(0x4c6b82,(undefined4)uStack_1d0);
    (**(code **)(iStack_1bc + 8))();
  }
  puStack_1c8 = &LAB_0188f7f0;
  uStack_1d0 = CONCAT44(0x4c6b8f,(undefined4)uStack_1d0);
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1094 ; VA 0x004c6bb0 ; FUN_004c6bb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c6bb0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5e9e;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b67d80(uVar2,0);
  FUN_009cb790(uVar1,s_FireEvent_0212d5f8,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0212d418 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::AnalyticsService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&,class_RBX::Reflection::Variant_const&),2>
       ::vftable;
  _DAT_0212d450 = FUN_00b6e870;
  _DAT_0212d454 = 0;
  _DAT_0212d458 = 0;
  DAT_0212d45c = 0;
  uStack_8 = 2;
  FUN_0089f290();
  FUN_016f3654(FUN_0188f800);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1095 ; VA 0x004c6c70 ; FUN_004c6c70 */

void FUN_004c6c70(void)

{
  undefined auStack_374 [416];
  undefined4 uStack_1d4;
  undefined8 uStack_1d0;
  undefined *puStack_1c8;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5e6e;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  puStack_1c8 = (undefined *)0x4c6c9f;
  ExceptionList = &pvStack_10;
  uStack_1c0 = FUN_00888530();
  iStack_1bc = 0;
  uStack_8 = 0;
  puStack_1c8 = (undefined *)0x4c6cbb;
  uStack_f0 = FUN_00888530();
  iStack_ec = 0;
  uStack_1d0 = CONCAT44(uStack_1c,uStack_20);
  uStack_8._0_1_ = 1;
  uStack_1d4 = 0;
  puStack_14 = auStack_374;
  puStack_1c8 = (undefined *)0x0;
  FUN_005caf00(&uStack_f0);
  uStack_8._0_1_ = 2;
  FUN_005caf00(&uStack_1c0);
  uStack_8._0_1_ = 1;
  FUN_00b69450(FUN_00b6eac0,0,s_FireInGameEconomyEvent_0212d648,s_player_0211f800,
               s_itemName_0212d63c,s_economyAction_0212d62c,s_itemCategory_0212d61c,
               s_amount_02123dcc,s_currency_0212d610,s_location_02123e14,s_customData_0212d604);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (iStack_ec != 0) {
    puStack_1c8 = auStack_e8;
    uStack_1d0 = CONCAT44(0x4c6d71,(undefined4)uStack_1d0);
    (**(code **)(iStack_ec + 8))();
  }
  uStack_8 = 4;
  if (iStack_1bc != 0) {
    puStack_1c8 = auStack_1b8;
    uStack_1d0 = CONCAT44(0x4c6d91,(undefined4)uStack_1d0);
    (**(code **)(iStack_1bc + 8))();
  }
  puStack_1c8 = &LAB_0188f870;
  uStack_1d0 = CONCAT44(0x4c6d9e,(undefined4)uStack_1d0);
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1096 ; VA 0x004c6db0 ; FUN_004c6db0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c6db0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined4 *puStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5f00;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uStack_1c0 = FUN_00888530();
  iStack_1bc = 0;
  uStack_8 = 0;
  FUN_005caf00(&uStack_1c0);
  uStack_8._0_1_ = 1;
  uVar1 = FUN_00b67d80();
  FUN_009cb790(uVar1,s_FireCustomEvent_0212d6d4,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0212d570 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::AnalyticsService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant),3>
       ::vftable;
  _DAT_0212d5a8 = FUN_00b6e570;
  _DAT_0212d5ac = 0;
  _DAT_0212d5b0 = 0;
  _DAT_0212d5b4 = 0;
  uStack_8._0_1_ = 4;
  puVar2 = (undefined4 *)FUN_01674e20(0xd0);
  uStack_8._0_1_ = 5;
  puStack_14 = puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    _DAT_0212d5b8 = (undefined4 *)0x0;
  }
  else {
    *puVar2 = uStack_f0;
    puVar2[1] = 0;
    if (puStack_ec != (undefined4 *)0x0) {
      (*(code *)*puStack_ec)();
    }
    puVar2[1] = puStack_ec;
    _DAT_0212d5b8 = puVar2;
  }
  uStack_8._0_1_ = 6;
  FUN_00b6b9c0(s_player_0211f800,s_eventCategory_0212d6c4,s_customData_0212d604);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (puStack_ec != (undefined4 *)0x0) {
    (*(code *)puStack_ec[2])(auStack_e8);
  }
  uStack_8 = 8;
  if (iStack_1bc != 0) {
    (**(code **)(iStack_1bc + 8))(auStack_1b8);
  }
  FUN_016f3654(&LAB_0188f880);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1097 ; VA 0x004c6f40 ; FUN_004c6f40 */

void FUN_004c6f40(void)

{
  undefined auStack_514 [624];
  undefined4 uStack_2a4;
  undefined8 uStack_2a0;
  undefined *puStack_298;
  undefined4 uStack_290;
  int iStack_28c;
  undefined auStack_288 [200];
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f5f41;
  pvStack_10 = ExceptionList;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  puStack_298 = (undefined *)0x4c6f6f;
  ExceptionList = &pvStack_10;
  uStack_290 = FUN_00888530();
  iStack_28c = 0;
  uStack_8 = 0;
  puStack_298 = (undefined *)0x4c6f8b;
  uStack_1c0 = FUN_00888530();
  iStack_1bc = 0;
  uStack_8._0_1_ = 1;
  puStack_298 = (undefined *)0x4c6fa4;
  uStack_f0 = FUN_00888530();
  iStack_ec = 0;
  uStack_2a0 = CONCAT44(uStack_1c,uStack_20);
  uStack_8._0_1_ = 2;
  uStack_2a4 = 0;
  puStack_14 = auStack_514;
  puStack_298 = (undefined *)0x0;
  FUN_005caf00(&uStack_f0);
  uStack_8._0_1_ = 3;
  FUN_005caf00(&uStack_1c0);
  uStack_8._0_1_ = 4;
  FUN_005caf00(&uStack_290);
  uStack_8._0_1_ = 2;
  FUN_00b69600(FUN_00b6fd00,0,s_FirePlayerProgressionEvent_0212d680,s_player_0211f800,
               s_category_0211cfd0,s_progressionStatus_0212d66c,s_location_02123e14,
               s_statistics_0212d660,s_customData_0212d604);
  uStack_8._0_1_ = 5;
  if (iStack_ec != 0) {
    puStack_298 = auStack_e8;
    uStack_2a0 = CONCAT44(0x4c7066,(undefined4)uStack_2a0);
    (**(code **)(iStack_ec + 8))();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (iStack_1bc != 0) {
    puStack_298 = auStack_1b8;
    uStack_2a0 = CONCAT44(0x4c7083,(undefined4)uStack_2a0);
    (**(code **)(iStack_1bc + 8))();
  }
  uStack_8 = 7;
  if (iStack_28c != 0) {
    puStack_298 = auStack_288;
    uStack_2a0 = CONCAT44(0x4c70a3,(undefined4)uStack_2a0);
    (**(code **)(iStack_28c + 8))();
  }
  puStack_298 = &LAB_0188f890;
  uStack_2a0 = CONCAT44(0x4c70b0,(undefined4)uStack_2a0);
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1098 ; VA 0x004c7100 ; FUN_004c7100 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c7100(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6fba;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b73ae0(uVar2,0);
  FUN_009cb790(uVar1,"GetHash",3,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_01ef0af8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::Script,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(void),0>
       ::vftable;
  _DAT_01ef0b30 = FUN_00b74dc0;
  _DAT_01ef0b34 = 0;
  _DAT_01ef0b1c = FUN_0088cb40();
  FUN_016f3654(&LAB_0188f9e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1099 ; VA 0x004c71c0 ; FUN_004c71c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c71c0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f6fec;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b73900();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::BaseScript,bool>::
              GetSetImpl<bool_(__thiscall_RBX::BaseScript::*)(void)const_,void_(__thiscall_RBX::BaseScript::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_00926b00;
    puVar3[3] = 0;
    puVar3[4] = FUN_00b75500;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,"Disabled","Behavior",uStack_24,0,0,0x1f,0,0,0);
  DAT_01ef0ac0 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01ef0af4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01ef0ae4 = _DAT_01ef0ae4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01ef0ac0[2])();
    if (cVar1 != '\0') {
      _DAT_01ef0ae4 = _DAT_01ef0ae4 & 0xfffffff3;
    }
  }
  DAT_01ef0ac0 = RBX::Reflection::PropDescriptor<class_RBX::BaseScript,bool>::vftable;
  FUN_016f3654(&LAB_0188fab0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1100 ; VA 0x004c72f0 ; FUN_004c72f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c72f0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f701c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b73ae0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Script,class_RBX::ProtectedString>::
              GetSetImpl<class_RBX::ProtectedString_const&_(__thiscall_RBX::Script::*)(void)const_,void_(__thiscall_RBX::Script::*)(class_RBX::ProtectedString_const&)>
              ::vftable;
    puVar3[2] = FUN_00b74d90;
    puVar3[3] = 0;
    puVar3[4] = FUN_00b75530;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_00886600();
  FUN_009ca670(uVar2,uVar4,"Source",&DAT_018dbc3c,uStack_24,0,0,0x1f,1,1,0);
  DAT_01ef0a50 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::ProtectedString>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01ef0a84 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01ef0a74 = _DAT_01ef0a74 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01ef0a50[2])();
    if (cVar1 != '\0') {
      _DAT_01ef0a74 = _DAT_01ef0a74 & 0xfffffff3;
    }
  }
  DAT_01ef0a50 = RBX::Reflection::PropDescriptor<class_RBX::Script,class_RBX::ProtectedString>::
                 vftable;
  FUN_016f3654(&LAB_0188fad0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1101 ; VA 0x004c7420 ; FUN_004c7420 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c7420(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f704c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b73900();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::BaseScript,class_RBX::ContentId>::
              GetSetImpl<class_RBX::ContentId_const&_(__thiscall_RBX::LuaSourceContainer::*)(void)const_,void_(__thiscall_RBX::LuaSourceContainer::*)(class_RBX::ContentId_const&)>
              ::vftable;
    puVar3[2] = FUN_00ae4430;
    puVar3[3] = 0;
    puVar3[4] = FUN_00ae67a0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d190();
  FUN_009ca670(uVar2,uVar4,"LinkedSource",&DAT_018dbc3c,uStack_24,0,0,0x1f,0,0,0);
  DAT_01ef0a88 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::ContentId>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01ef0abc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01ef0aac = _DAT_01ef0aac & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01ef0a88[2])();
    if (cVar1 != '\0') {
      _DAT_01ef0aac = _DAT_01ef0aac & 0xfffffff3;
    }
  }
  DAT_01ef0a88 = RBX::Reflection::PropDescriptor<class_RBX::BaseScript,class_RBX::ContentId>::
                 vftable;
  FUN_016f3654(&LAB_0188faf0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1102 ; VA 0x004c7650 ; FUN_004c7650 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c7650(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f732c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b75d90();
  FUN_009cb790(uVar2,"GetScriptFilePath",5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_01ef11c8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::CoreScriptSyncService,class_RBX::Reflection::Variant___cdecl(class_std::shared_ptr<class_RBX::Instance>_const&),1>
       ::vftable;
  _DAT_01ef1200 = FUN_00b77050;
  _DAT_01ef1204 = 0;
  DAT_01ef1208 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_01ef11ec = FUN_00888410();
  puVar4 = DAT_01ef1208;
  if (DAT_01ef1208 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cdc0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_006309e0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0("script");
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_0188fc40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1103 ; VA 0x004c7b10 ; FUN_004c7b10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c7b10(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7dec;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b7a090();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::UserInputService,double>::
              GetImpl<double_(__thiscall_RBX::UserInputService::*)(void)const_>::vftable;
    puVar3[2] = &LAB_00b83460;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088ca00();
  FUN_009ca670(uVar2,uVar4,s_OnScreenKeyboardAnimationDuratio_0212ef50,&DAT_021197d4,uStack_24,0,0,
               0x15,5,5,0);
  DAT_0212e780 = RBX::Reflection::TypedPropertyDescriptor<double>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0212e7b4 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0212e7a4 = _DAT_0212e7a4 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0212e780[2])();
    if (cVar1 != '\0') {
      _DAT_0212e7a4 = _DAT_0212e7a4 & 0xfffffff3;
    }
  }
  DAT_0212e780 = RBX::Reflection::PropDescriptor<class_RBX::UserInputService,double>::vftable;
  FUN_016f3654(&LAB_0188fe00);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1104 ; VA 0x004c7d80 ; FUN_004c7d80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c7d80(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7e1c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b7a090();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::UserInputService,float>::
              GetSetImpl<float_(__thiscall_RBX::UserInputService::*)(void)const_,void_(__thiscall_RBX::UserInputService::*)(float)>
              ::vftable;
    puVar3[2] = &LAB_00b82b80;
    puVar3[3] = 0;
    puVar3[4] = FUN_00b84300;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c960();
  FUN_009ca670(uVar2,uVar4,s_MouseDeltaSensitivity_0212ebf8,&DAT_021197d4,uStack_24,0,0,0x15,0,0,0);
  DAT_0212de88 = RBX::Reflection::TypedPropertyDescriptor<float>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_0212debc = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0212deac = _DAT_0212deac & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_0212de88[2])();
    if (cVar1 != '\0') {
      _DAT_0212deac = _DAT_0212deac & 0xfffffff3;
    }
  }
  DAT_0212de88 = RBX::Reflection::PropDescriptor<class_RBX::UserInputService,float>::vftable;
  FUN_016f3654(&LAB_0188fe80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1105 ; VA 0x004c7eb0 ; FUN_004c7eb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c7eb0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7e44;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b798a0();
  uVar3 = FUN_00b7a090();
  FUN_009ca670(uVar3,uVar2,s_MouseBehavior_0212ebe8,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_0212de48 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::UserInputService,enum_RBX::MouseService::MouseType>::
                 vftable;
  _DAT_0212de7c = uVar2;
  DAT_0212de80 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0212de80 == (undefined4 *)0x0) {
    DAT_0212de80 = (undefined4 *)0x0;
  }
  else {
    *DAT_0212de80 =
         RBX::Reflection::
         PropDescriptor<class_RBX::UserInputService,enum_RBX::MouseService::MouseType>::
         GetSetImpl<enum_RBX::MouseService::MouseType_(__thiscall_RBX::UserInputService::*)(void)const_,void_(__thiscall_RBX::UserInputService::*)(enum_RBX::MouseService::MouseType)>
         ::vftable;
    DAT_0212de80[2] = &LAB_00b82bf0;
    DAT_0212de80[3] = 0;
    DAT_0212de80[4] = FUN_00b84330;
    DAT_0212de80[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0212de84 = FUN_00b798a0();
  cVar1 = (*(code *)DAT_0212de48[3])();
  if (cVar1 != '\0') {
    _DAT_0212de6c = _DAT_0212de6c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0212de48[2])();
  if (cVar1 != '\0') {
    _DAT_0212de6c = _DAT_0212de6c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0188fea0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1106 ; VA 0x004c7fd0 ; FUN_004c7fd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c7fd0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7e64;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b79950();
  uVar3 = FUN_00b7a090();
  FUN_009ca670(uVar3,uVar2,s_OverrideMouseIconBehavior_0212ebcc,&DAT_021197d4,uStack_24,0,0,0x13,5,5
               ,1);
  uStack_8 = 0;
  DAT_0212de08 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::UserInputService,enum_RBX::MouseService::OverrideMouseIconBehavior>
                 ::vftable;
  _DAT_0212de3c = uVar2;
  DAT_0212de40 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_0212de40 == (undefined4 *)0x0) {
    DAT_0212de40 = (undefined4 *)0x0;
  }
  else {
    *DAT_0212de40 =
         RBX::Reflection::
         PropDescriptor<class_RBX::UserInputService,enum_RBX::MouseService::OverrideMouseIconBehavior>
         ::
         GetSetImpl<enum_RBX::MouseService::OverrideMouseIconBehavior_(__thiscall_RBX::UserInputService::*)(void)const_,void_(__thiscall_RBX::UserInputService::*)(enum_RBX::MouseService::OverrideMouseIconBehavior)>
         ::vftable;
    DAT_0212de40[2] = &LAB_00b83160;
    DAT_0212de40[3] = 0;
    DAT_0212de40[4] = FUN_00b843b0;
    DAT_0212de40[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0212de44 = FUN_00b79950();
  cVar1 = (*(code *)DAT_0212de08[3])();
  if (cVar1 != '\0') {
    _DAT_0212de2c = _DAT_0212de2c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_0212de08[2])();
  if (cVar1 != '\0') {
    _DAT_0212de2c = _DAT_0212de2c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_0188fec0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1107 ; VA 0x004c81d0 ; FUN_004c81d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c81d0(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7e9e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090();
  FUN_009cb970(uVar1,s_DeviceRotationChanged_0212ed10,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0212e188 = FUN_00b82ef0;
  _DAT_0212e18c = 0;
  iStack_8 = 0;
  _DAT_0212e150 =
       RBX::Reflection::
       EventDesc<class_RBX::UserInputService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_G3D::CoordinateFrame),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_G3D::CoordinateFrame)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_G3D::CoordinateFrame)>*_(__thiscall_RBX::UserInputService::*)(bool)>
       ::vftable;
  FUN_0086e3d0(s_rotation_0212ea70);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_cframe_0212a324);
  FUN_00b00260();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_0212e178 = uStack_1c;
  _DAT_0212e17c = uStack_18;
  _DAT_0212e180 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_0212e150 =
       RBX::Reflection::
       EventDesc<class_RBX::UserInputService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_G3D::CoordinateFrame),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_G3D::CoordinateFrame)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_G3D::CoordinateFrame)>*_(__thiscall_RBX::UserInputService::*)(bool)>
       ::vftable;
  FUN_016f3654(&LAB_0188fef0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1108 ; VA 0x004c8380 ; FUN_004c8380 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c8380(void)

{
  undefined4 uVar1;
  undefined auStack_38c [864];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7ef4;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090();
  FUN_009cb970(uVar1,s_PointerAction_0212ec84,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0212dffc = 0x128;
  iStack_8 = 0;
  _DAT_0212dfc8 =
       RBX::Reflection::
       EventDesc<class_RBX::UserInputService,void___cdecl(float,class_G3D::Vector2,float,bool),class_rbx::signal<void___cdecl(float,class_G3D::Vector2,float,bool)>,class_rbx::signal<void___cdecl(float,class_G3D::Vector2,float,bool)>_RBX::UserInputService::*>
       ::vftable;
  FUN_0086e3d0(s_wheel_0212ec7c);
  FUN_0088c960();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(&DAT_0212ec78);
  FUN_0088d730();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_pinch_0212ec70);
  FUN_0088c960();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  FUN_0086e3d0(s_gameProcessedEvent_0212e9e4);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 4;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_38c,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  _DAT_0212dff0 = uStack_1c;
  _DAT_0212dff4 = uStack_18;
  _DAT_0212dff8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 6;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_38c,0xd8,4,FUN_00688b10);
  _DAT_0212dfc8 =
       RBX::Reflection::
       EventDesc<class_RBX::UserInputService,void___cdecl(float,class_G3D::Vector2,float,bool),class_rbx::signal<void___cdecl(float,class_G3D::Vector2,float,bool)>,class_rbx::signal<void___cdecl(float,class_G3D::Vector2,float,bool)>_RBX::UserInputService::*>
       ::vftable;
  FUN_016f3654(&LAB_0188ff10);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1109 ; VA 0x004c8540 ; FUN_004c8540 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c8540(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7f23;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090();
  FUN_009cb970(uVar1,s_StatusBarTapped_0212e9b8,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0212d8fc = 0xfc;
  iStack_8 = 0;
  _DAT_0212d8c8 =
       RBX::Reflection::
       EventDesc<class_RBX::UserInputService,void___cdecl(class_G3D::Vector2),class_rbx::signal<void___cdecl(class_G3D::Vector2)>,class_rbx::signal<void___cdecl(class_G3D::Vector2)>_RBX::UserInputService::*>
       ::vftable;
  FUN_0086e3d0(s_position_0211fd1c);
  FUN_0088d730();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0212d8f0 = uStack_1c;
  _DAT_0212d8f4 = uStack_18;
  _DAT_0212d8f8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  _DAT_0212d8c8 =
       RBX::Reflection::
       EventDesc<class_RBX::UserInputService,void___cdecl(class_G3D::Vector2),class_rbx::signal<void___cdecl(class_G3D::Vector2)>,class_rbx::signal<void___cdecl(class_G3D::Vector2)>_RBX::UserInputService::*>
       ::vftable;
  FUN_016f3654(&LAB_0188ff20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1110 ; VA 0x004c86f0 ; FUN_004c86f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c86f0(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7f5e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090();
  FUN_009cb970(uVar1,s_TouchTapInWorld_0212eab8,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0212daf4 = 0x78;
  iStack_8 = 0;
  _DAT_0212dac0 =
       RBX::Reflection::
       EventDesc<class_RBX::UserInputService,void___cdecl(class_G3D::Vector2,bool),class_rbx::signal<void___cdecl(class_G3D::Vector2,bool)>,class_rbx::signal<void___cdecl(class_G3D::Vector2,bool)>_RBX::UserInputService::*>
       ::vftable;
  FUN_0086e3d0(s_position_0211fd1c);
  FUN_0088d730();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_processedByUI_0212eaa8);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_0212dae8 = uStack_1c;
  _DAT_0212daec = uStack_18;
  _DAT_0212daf0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_0212dac0 =
       RBX::Reflection::
       EventDesc<class_RBX::UserInputService,void___cdecl(class_G3D::Vector2,bool),class_rbx::signal<void___cdecl(class_G3D::Vector2,bool)>,class_rbx::signal<void___cdecl(class_G3D::Vector2,bool)>_RBX::UserInputService::*>
       ::vftable;
  FUN_016f3654(&LAB_0188ff50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1111 ; VA 0x004c88c0 ; FUN_004c88c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c88c0(void)

{
  undefined4 uVar1;
  undefined auStack_2b4 [648];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7fa9;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090();
  FUN_009cb970(uVar1,s_TouchLongPress_0212ea60,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0212da4c = 0x6c;
  iStack_8 = 0;
  _DAT_0212da18 =
       RBX::Reflection::
       EventDesc<class_RBX::UserInputService,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,enum_RBX::InputObject::UserInputState,bool),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,enum_RBX::InputObject::UserInputState,bool)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,enum_RBX::InputObject::UserInputState,bool)>_RBX::UserInputService::*>
       ::vftable;
  FUN_0086e3d0(s_touchPositions_0212e9f8);
  FUN_008882f0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_state_02123f08);
  thunk_FUN_00d82070();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_gameProcessedEvent_0212e9e4);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b4,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_0212da40 = uStack_1c;
  _DAT_0212da44 = uStack_18;
  _DAT_0212da48 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b4,0xd8,3,FUN_00688b10);
  _DAT_0212da18 =
       RBX::Reflection::
       EventDesc<class_RBX::UserInputService,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,enum_RBX::InputObject::UserInputState,bool),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,enum_RBX::InputObject::UserInputState,bool)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,enum_RBX::InputObject::UserInputState,bool)>_RBX::UserInputService::*>
       ::vftable;
  FUN_016f3654(&LAB_0188ff80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1112 ; VA 0x004c8a60 ; FUN_004c8a60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c8a60(void)

{
  undefined4 extraout_var;
  
  FUN_00b7b160(0x74,s_TouchPan_0212ea9c,s_touchPositions_0212e9f8,s_totalTranslation_0212ea88,
               s_velocity_0212ea14,s_state_02123f08,s_gameProcessedEvent_0212e9e4,0,0,0,0);
  _DAT_0212da88 =
       RBX::Reflection::
       EventDesc<class_RBX::UserInputService,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_G3D::Vector2,class_G3D::Vector2,enum_RBX::InputObject::UserInputState,bool),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_G3D::Vector2,class_G3D::Vector2,enum_RBX::InputObject::UserInputState,bool)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,class_G3D::Vector2,class_G3D::Vector2,enum_RBX::InputObject::UserInputState,bool)>_RBX::UserInputService::*>
       ::vftable;
  FUN_016f3654(&LAB_0188ff90,extraout_var);
  return;
}



/* FUNCTION 1113 ; VA 0x004c8ad0 ; FUN_004c8ad0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c8ad0(void)

{
  undefined4 extraout_var;
  
  FUN_00b7afb0(100,s_TouchPinch_0212ea28,s_touchPositions_0212e9f8,s_scale_0212ea20,
               s_velocity_0212ea14,s_state_02123f08,s_gameProcessedEvent_0212e9e4,0,0,0,0);
  _DAT_0212d9a8 =
       RBX::Reflection::
       EventDesc<class_RBX::UserInputService,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,float,float,enum_RBX::InputObject::UserInputState,bool),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,float,float,enum_RBX::InputObject::UserInputState,bool)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,float,float,enum_RBX::InputObject::UserInputState,bool)>_RBX::UserInputService::*>
       ::vftable;
  FUN_016f3654(&LAB_0188ffa0,extraout_var);
  return;
}



/* FUNCTION 1114 ; VA 0x004c8b40 ; FUN_004c8b40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c8b40(void)

{
  undefined4 extraout_var;
  
  FUN_00b7afb0(0x70,s_TouchRotate_0212ea7c,s_touchPositions_0212e9f8,s_rotation_0212ea70,
               s_velocity_0212ea14,s_state_02123f08,s_gameProcessedEvent_0212e9e4,0,0,0,0);
  _DAT_0212da50 =
       RBX::Reflection::
       EventDesc<class_RBX::UserInputService,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,float,float,enum_RBX::InputObject::UserInputState,bool),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,float,float,enum_RBX::InputObject::UserInputState,bool)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,float,float,enum_RBX::InputObject::UserInputState,bool)>_RBX::UserInputService::*>
       ::vftable;
  FUN_016f3654(&LAB_0188ffb0,extraout_var);
  return;
}



/* FUNCTION 1115 ; VA 0x004c8bb0 ; FUN_004c8bb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c8bb0(void)

{
  undefined4 uVar1;
  undefined auStack_2b4 [648];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f7ff9;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090();
  FUN_009cb970(uVar1,s_TouchSwipe_0212ea54,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0212da14 = 0x68;
  iStack_8 = 0;
  _DAT_0212d9e0 =
       RBX::Reflection::
       EventDesc<class_RBX::UserInputService,void___cdecl(enum_RBX::GuiSwipeDirection,int,bool),class_rbx::signal<void___cdecl(enum_RBX::GuiSwipeDirection,int,bool)>,class_rbx::signal<void___cdecl(enum_RBX::GuiSwipeDirection,int,bool)>_RBX::UserInputService::*>
       ::vftable;
  FUN_0086e3d0(s_swipeDirection_0212ea44);
  FUN_00b84860();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_numberOfTouches_0212ea34);
  FUN_0088c8c0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  FUN_0086e3d0(s_gameProcessedEvent_0212e9e4);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_2b4,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  _DAT_0212da08 = uStack_1c;
  _DAT_0212da0c = uStack_18;
  _DAT_0212da10 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 5;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_2b4,0xd8,3,FUN_00688b10);
  _DAT_0212d9e0 =
       RBX::Reflection::
       EventDesc<class_RBX::UserInputService,void___cdecl(enum_RBX::GuiSwipeDirection,int,bool),class_rbx::signal<void___cdecl(enum_RBX::GuiSwipeDirection,int,bool)>,class_rbx::signal<void___cdecl(enum_RBX::GuiSwipeDirection,int,bool)>_RBX::UserInputService::*>
       ::vftable;
  FUN_016f3654(&LAB_0188ffc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1116 ; VA 0x004c8d50 ; FUN_004c8d50 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c8d50(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f803e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090();
  FUN_009cb970(uVar1,s_TouchTap_0212ea08,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0212d9a4 = 0x60;
  iStack_8 = 0;
  _DAT_0212d970 =
       RBX::Reflection::
       EventDesc<class_RBX::UserInputService,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,bool),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,bool)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,bool)>_RBX::UserInputService::*>
       ::vftable;
  FUN_0086e3d0(s_touchPositions_0212e9f8);
  FUN_008882f0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_gameProcessedEvent_0212e9e4);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_0212d998 = uStack_1c;
  _DAT_0212d99c = uStack_18;
  _DAT_0212d9a0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_0212d970 =
       RBX::Reflection::
       EventDesc<class_RBX::UserInputService,void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,bool),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,bool)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>,bool)>_RBX::UserInputService::*>
       ::vftable;
  FUN_016f3654(&LAB_0188ffd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1117 ; VA 0x004c8ef0 ; FUN_004c8ef0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c8ef0(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f807e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090();
  FUN_009cb970(uVar1,s_UserCFrameChanged_0212eef0,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0212e6d4 = 0x100;
  iStack_8 = 0;
  _DAT_0212e6a0 =
       RBX::Reflection::
       EventDesc<class_RBX::UserInputService,void___cdecl(enum_RBX::VRService::UserCFrame,class_G3D::CoordinateFrame),class_rbx::signal<void___cdecl(enum_RBX::VRService::UserCFrame,class_G3D::CoordinateFrame)>,class_rbx::signal<void___cdecl(enum_RBX::VRService::UserCFrame,class_G3D::CoordinateFrame)>_RBX::UserInputService::*>
       ::vftable;
  FUN_0086e3d0(&DAT_0212eed8);
  thunk_FUN_00b849a0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_value_0211ab70);
  FUN_00b00260();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_0212e6c8 = uStack_1c;
  _DAT_0212e6cc = uStack_18;
  _DAT_0212e6d0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_0212e6a0 =
       RBX::Reflection::
       EventDesc<class_RBX::UserInputService,void___cdecl(enum_RBX::VRService::UserCFrame,class_G3D::CoordinateFrame),class_rbx::signal<void___cdecl(enum_RBX::VRService::UserCFrame,class_G3D::CoordinateFrame)>,class_rbx::signal<void___cdecl(enum_RBX::VRService::UserCFrame,class_G3D::CoordinateFrame)>_RBX::UserInputService::*>
       ::vftable;
  FUN_016f3654(&LAB_0188fff0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1118 ; VA 0x004c9180 ; FUN_004c9180 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c9180(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f80dc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090();
  FUN_009cb790(uVar1,s_GetUserCFrame_0212eee0,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0212e658 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UserInputService,class_G3D::CoordinateFrame___cdecl(enum_RBX::VRService::UserCFrame),1>
       ::vftable;
  _DAT_0212e690 = FUN_00b83670;
  _DAT_0212e694 = 0;
  DAT_0212e698 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0212e67c = FUN_00b00260();
  puVar3 = DAT_0212e698;
  if (DAT_0212e698 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = thunk_FUN_00b849a0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00b84b30();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = thunk_FUN_00b849a0();
  uVar2 = FUN_0086e3d0(&DAT_0212eed8);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01890060);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1119 ; VA 0x004c9320 ; FUN_004c9320 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c9320(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f80fa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090(uVar2,0);
  FUN_009cb790(uVar1,s_RecenterUserHeadCFrame_0212eec0,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212e618 =
       RBX::Reflection::BoundFuncDesc<class_RBX::UserInputService,void___cdecl(void),0>::vftable;
  _DAT_0212e650 = &DAT_00b83f90;
  _DAT_0212e654 = 0;
  _DAT_0212e63c = FUN_00888530();
  FUN_016f3654(&LAB_01890080);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1120 ; VA 0x004c93c0 ; FUN_004c93c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c93c0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f811a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090(uVar2,0);
  FUN_009cb790(uVar1,s_GetConnectedGamepads_0212ed94,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212e2c0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UserInputService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0212e2f8 = FUN_00b82450;
  _DAT_0212e2fc = 0;
  _DAT_0212e2e4 = FUN_008882f0();
  FUN_016f3654(&LAB_01890090);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1121 ; VA 0x004c9460 ; FUN_004c9460 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c9460(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f813a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090(uVar2,0);
  FUN_009cb790(uVar1,s_GetDeviceAcceleration_0212ed28,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212e190 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UserInputService,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_0212e1c8 = FUN_00b82300;
  _DAT_0212e1cc = 0;
  _DAT_0212e1b4 = FUN_0088cdc0();
  FUN_016f3654(&LAB_018900a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1122 ; VA 0x004c9500 ; FUN_004c9500 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c9500(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f815a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090(uVar2,0);
  FUN_009cb790(uVar1,s_GetDeviceGravity_0212ed40,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212e1d0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UserInputService,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_0212e208 = FUN_00b82830;
  _DAT_0212e20c = 0;
  _DAT_0212e1f4 = FUN_0088cdc0();
  FUN_016f3654(&LAB_018900b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1123 ; VA 0x004c95a0 ; FUN_004c95a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c95a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f817a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090(uVar2,0);
  FUN_009cb790(uVar1,s_GetDeviceRotation_0212ed54,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212e210 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UserInputService,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0212e248 = FUN_00b831f0;
  _DAT_0212e24c = 0;
  _DAT_0212e234 = FUN_0088cbe0();
  FUN_016f3654(&LAB_018900c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1124 ; VA 0x004c9640 ; FUN_004c9640 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c9640(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f819a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090(uVar2,0);
  FUN_009cb790(uVar1,s_GetDeviceType_0212e92c,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212d730 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UserInputService,enum_RBX::DeviceTypeEnum___cdecl(void),0>::vftable;
  _DAT_0212d768 = &LAB_00b82560;
  _DAT_0212d76c = 0;
  _DAT_0212d754 = thunk_FUN_00b847d0();
  FUN_016f3654(&LAB_018900d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1125 ; VA 0x004c96e0 ; FUN_004c96e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c96e0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f81ba;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090(uVar2,0);
  FUN_009cb790(uVar1,s_GetFocusedTextBox_0212eb68,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212dce8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UserInputService,class_std::shared_ptr<class_RBX::Instance>___cdecl(void),0>
       ::vftable;
  _DAT_0212dd20 = FUN_00b82570;
  _DAT_0212dd24 = 0;
  _DAT_0212dd0c = FUN_0088cdc0();
  FUN_016f3654(&LAB_018900e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1126 ; VA 0x004c9780 ; FUN_004c9780 */

void FUN_004c9780(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b7ae20(FUN_00b825b0,0,s_GetGamepadConnected_0212edb8,s_gamepadNum_0212edac,0,uStack_10,0);
  FUN_016f3654(&LAB_018900f0);
  return;
}



/* FUNCTION 1127 ; VA 0x004c97e0 ; FUN_004c97e0 */

void FUN_004c97e0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b7aca0(FUN_00b82640,0,s_GetGamepadState_0212ee18,s_gamepadNum_0212edac,0,uStack_10,0);
  FUN_016f3654(&LAB_01890110);
  return;
}



/* FUNCTION 1128 ; VA 0x004c9840 ; FUN_004c9840 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c9840(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f81ee;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090(uVar2,0);
  FUN_009cb790(uVar1,s_IsGamepadButtonDown_0212ee04,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0212e3b8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UserInputService,bool___cdecl(enum_RBX::InputObject::UserInputType,enum_RBX::KeyCode),2>
       ::vftable;
  _DAT_0212e3f0 = FUN_00b829d0;
  _DAT_0212e3f4 = 0;
  DAT_0212e3f8 = 0;
  DAT_0212e3fc = 0;
  uStack_8 = 2;
  FUN_00b7f810();
  FUN_016f3654(&LAB_01890130);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1129 ; VA 0x004c9900 ; FUN_004c9900 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c9900(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f820a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090(uVar2,0);
  FUN_009cb790(uVar1,s_GetKeysPressed_0212ec94,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212e000 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UserInputService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0212e038 = FUN_00b82b30;
  _DAT_0212e03c = 0;
  _DAT_0212e024 = FUN_008882f0();
  FUN_016f3654(&LAB_01890170);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1130 ; VA 0x004c99a0 ; FUN_004c99a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c99a0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f822a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090(uVar2,0);
  FUN_009cb790(uVar1,s_GetLastInputType_0212e93c,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212d770 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UserInputService,enum_RBX::InputObject::UserInputType___cdecl(void),0>
       ::vftable;
  _DAT_0212d7a8 = FUN_00b82b00;
  _DAT_0212d7ac = 0;
  _DAT_0212d794 = thunk_FUN_00b84a30();
  FUN_016f3654(&LAB_01890180);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1131 ; VA 0x004c9a40 ; FUN_004c9a40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c9a40(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f824a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090(uVar2,0);
  FUN_009cb790(uVar1,s_GetMouseDelta_0212ec48,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212df48 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UserInputService,class_G3D::Vector2___cdecl(void),0>::vftable;
  _DAT_0212df80 = FUN_00b82b60;
  _DAT_0212df84 = 0;
  _DAT_0212df6c = FUN_0088d730();
  FUN_016f3654(&LAB_01890190);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1132 ; VA 0x004c9ae0 ; FUN_004c9ae0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c9ae0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f826a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090(uVar2,0);
  FUN_009cb790(uVar1,s_GetMouseLocation_0212ec34,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212df08 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UserInputService,class_G3D::Vector2___cdecl(void),0>::vftable;
  _DAT_0212df40 = FUN_00b82bd0;
  _DAT_0212df44 = 0;
  _DAT_0212df2c = FUN_0088d730();
  FUN_016f3654(&LAB_018901a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1133 ; VA 0x004c9b80 ; FUN_004c9b80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c9b80(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f828a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090(uVar2,0);
  FUN_009cb790(uVar1,s_GetNavigationGamepads_0212ee54,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212e4d8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UserInputService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0212e510 = FUN_00b82c20;
  _DAT_0212e514 = 0;
  _DAT_0212e4fc = FUN_008882f0();
  FUN_016f3654(&LAB_018901b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1134 ; VA 0x004c9c20 ; FUN_004c9c20 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c9c20(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f82aa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090(uVar2,0);
  FUN_009cb790(uVar1,s_GetPlatform_0212e920,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212d6f0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UserInputService,enum_RBX::PlatformEnum___cdecl(void),0>::vftable;
  _DAT_0212d728 = FUN_00b83190;
  _DAT_0212d72c = 0;
  _DAT_0212d714 = thunk_FUN_00b84910();
  FUN_016f3654(&LAB_018901c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1135 ; VA 0x004c9cc0 ; FUN_004c9cc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c9cc0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f82ca;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090(uVar2,0);
  FUN_009cb790(uVar1,s_GetMouseButtonsPressed_0212ec58,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212df88 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UserInputService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0212dfc0 = FUN_00b831b0;
  _DAT_0212dfc4 = 0;
  _DAT_0212dfac = FUN_008882f0();
  FUN_016f3654(&LAB_018901d0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1136 ; VA 0x004c9d60 ; FUN_004c9d60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c9d60(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f832c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090();
  FUN_009cb790(uVar1,s_GetStringForKeyCode_0212ecb8,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0212e088 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UserInputService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(enum_RBX::KeyCode),1>
       ::vftable;
  _DAT_0212e0c0 = FUN_00b834e0;
  _DAT_0212e0c4 = 0;
  DAT_0212e0c8 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0212e0ac = FUN_0088cb40();
  puVar3 = DAT_0212e0c8;
  if (DAT_0212e0c8 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = thunk_FUN_00896d50();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00897340();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = thunk_FUN_00896d50();
  uVar2 = FUN_0086e3d0(s_keyCode_0212eca4);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_018901e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1137 ; VA 0x004c9f00 ; FUN_004c9f00 */

void FUN_004c9f00(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b7aca0(FUN_00b83570,0,s_GetSupportedGamepadKeyCodes_0212ee38,s_gamepadNum_0212edac,0,
               uStack_10,0);
  FUN_016f3654(&LAB_01890200);
  return;
}



/* FUNCTION 1138 ; VA 0x004c9f60 ; FUN_004c9f60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004c9f60(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f835e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090(uVar2,0);
  FUN_009cb790(uVar1,s_GamepadSupports_0212ee28,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0212e448 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UserInputService,bool___cdecl(enum_RBX::InputObject::UserInputType,enum_RBX::KeyCode),2>
       ::vftable;
  _DAT_0212e480 = FUN_00b81c70;
  _DAT_0212e484 = 0;
  DAT_0212e488 = 0;
  DAT_0212e48c = 0;
  uStack_8 = 2;
  FUN_00b7f810();
  FUN_016f3654(&LAB_01890220);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1139 ; VA 0x004ca020 ; FUN_004ca020 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ca020(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f83bc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090();
  FUN_009cb790(uVar1,s_IsKeyDown_0212ecac,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0212e040 =
       RBX::Reflection::BoundFuncDesc<class_RBX::UserInputService,bool___cdecl(enum_RBX::KeyCode),1>
       ::vftable;
  _DAT_0212e078 = FUN_00b839e0;
  _DAT_0212e07c = 0;
  DAT_0212e080 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0212e064 = FUN_0088daf0();
  puVar3 = DAT_0212e080;
  if (DAT_0212e080 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = thunk_FUN_00896d50();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00897340();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = thunk_FUN_00896d50();
  uVar2 = FUN_0086e3d0(s_keyCode_0212eca4);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01890260);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1140 ; VA 0x004ca1c0 ; FUN_004ca1c0 */

void FUN_004ca1c0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b7ae20(FUN_00b839f0,0,s_IsMouseButtonPressed_0212ec1c,s_mouseButton_0212ec10,0,uStack_10,0);
  FUN_016f3654(&LAB_01890280);
  return;
}



/* FUNCTION 1141 ; VA 0x004ca220 ; FUN_004ca220 */

void FUN_004ca220(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b7ae20(FUN_00b83a00,0,s_IsNavigationGamepad_0212ee78,s_gamepadEnum_0212ee6c,0,uStack_10,0);
  FUN_016f3654(&LAB_018902a0);
  return;
}



/* FUNCTION 1142 ; VA 0x004ca280 ; FUN_004ca280 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ca280(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8402;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090(uVar2,0);
  FUN_009cb790(uVar1,s_SendAppUISizes_0212efec,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212e898 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UserInputService,void___cdecl(class_G3D::Vector2_const&,class_G3D::Vector2_const&,class_G3D::Vector2_const&,class_G3D::Vector2_const&),4>
       ::vftable;
  _DAT_0212e8d0 = FUN_00b83ff0;
  _DAT_0212e8d4 = 0;
  DAT_0212e8d8 = 0;
  DAT_0212e8dc = 0;
  DAT_0212e8e0 = 0;
  DAT_0212e8e4 = 0;
  uStack_8 = 4;
  FUN_00b7f1c0(s_statusBarSize_0212efdc,s_navBarSize_0212efd0,s_bottomBarSize_0212efc0,
               s_rightBarSize_0212efb0);
  FUN_016f3654(&LAB_018902c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1143 ; VA 0x004ca360 ; FUN_004ca360 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ca360(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f842e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b7a090(uVar2,0);
  FUN_009cb790(uVar1,s_SetNavigationGamepad_0212ee8c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0212e560 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::UserInputService,void___cdecl(enum_RBX::InputObject::UserInputType,bool),2>
       ::vftable;
  _DAT_0212e598 = FUN_00b84340;
  _DAT_0212e59c = 0;
  DAT_0212e5a0 = 0;
  DAT_0212e5a4 = 0;
  uStack_8 = 2;
  FUN_00b7f5f0();
  FUN_016f3654(&LAB_01890320);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1144 ; VA 0x004cada0 ; FUN_004cada0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cada0(void)

{
  undefined4 uVar1;
  undefined auStack_108 [216];
  uint uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8f63;
  pvStack_10 = ExceptionList;
  uStack_30 = uStack_30 & 0xffffff00;
  uStack_2c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b85410();
  FUN_009cb970(uVar1,s_InternalDelete_0212f540,0,CONCAT44(uStack_2c,uStack_30),0);
  _DAT_0212f04c = 0x68;
  iStack_8 = 0;
  _DAT_0212f018 =
       RBX::Reflection::
       EventDesc<class_RBX::InsertService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::InsertService::*>
       ::vftable;
  FUN_0086e3d0(s_instance_02126630);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_108,&uStack_30,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0212f040 = uStack_1c;
  _DAT_0212f044 = uStack_18;
  _DAT_0212f048 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_108,0xd8,1,FUN_00688b10);
  _DAT_0212f018 =
       RBX::Reflection::
       RemoteEventDesc<class_RBX::InsertService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::InsertService::*>
       ::vftable;
  _DAT_0212f050 = 0;
  _DAT_0212f054 = 0;
  FUN_016f3654(&LAB_01890650);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1145 ; VA 0x004caf00 ; FUN_004caf00 */

void FUN_004caf00(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b85c10(FUN_006159b0,0,s_ApproveAssetId_0212f550,s_assetId_0211bf40,0,uStack_10,0);
  FUN_016f3654(&LAB_01890660);
  return;
}



/* FUNCTION 1146 ; VA 0x004caf60 ; FUN_004caf60 */

void FUN_004caf60(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b85c10(FUN_006159b0,0,s_ApproveAssetVersionId_0212f570,s_assetVersionId_0212f560,0,uStack_10
               ,0);
  FUN_016f3654(&LAB_01890680);
  return;
}



/* FUNCTION 1147 ; VA 0x004cafc0 ; FUN_004cafc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cafc0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8f98;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b85410(uVar2,0);
  FUN_009cb820(uVar1,s_CreateMeshPartAsync_0212f6a8,1,CONCAT44(uVar3,uVar2),0);
  _DAT_0212f480 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::InsertService,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_RBX::MeshId,enum_RBX::CollisionFidelity,enum_RBX::RenderFidelity),3>
       ::vftable;
  _DAT_0212f4b8 = FUN_00b86cf0;
  _DAT_0212f4bc = 0;
  _DAT_0212f4c0 = 0;
  DAT_0212f4c4 = 0;
  DAT_0212f4c8 = 0;
  uStack_8 = 3;
  FUN_00b87120(s_meshId_0211c0a0,s_collisionFidelity_0212f694,s_renderFidelity_0212f684);
  FUN_016f3654(&LAB_018906a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1148 ; VA 0x004cb090 ; FUN_004cb090 */

void FUN_004cb090(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b85d70(FUN_00b88550,0,s_GetCollection_0212f608,s_categoryId_0212f5fc,0,uStack_10,0);
  FUN_016f3654(&LAB_018906e0);
  return;
}



/* FUNCTION 1149 ; VA 0x004cb0f0 ; FUN_004cb0f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cb0f0(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8fba;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_0212f178;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b85410(uVar2,&DAT_0212f178);
  FUN_009cb820(uVar1,s_GetBaseCategories_0212f5d4,0,CONCAT44(puVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212f200 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::InsertService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0212f238 = FUN_00b883c0;
  _DAT_0212f23c = 0;
  _DAT_0212f224 = FUN_008882f0();
  FUN_016f3654(&LAB_01890700);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1150 ; VA 0x004cb190 ; FUN_004cb190 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cb190(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f8fda;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b85410(uVar2,0);
  FUN_009cb820(uVar1,s_GetBaseSets_0212f5bc,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212f178 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::InsertService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0212f1b0 = FUN_00b883c0;
  _DAT_0212f1b4 = 0;
  _DAT_0212f19c = FUN_008882f0();
  FUN_016f3654(&LAB_01890710);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1151 ; VA 0x004cb230 ; FUN_004cb230 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cb230(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f900e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b85410(uVar2,0);
  FUN_009cb820(uVar1,s_GetFreeDecals_0212f5ac,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0212f130 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::InsertService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int),2>
       ::vftable;
  _DAT_0212f168 = FUN_00b886e0;
  _DAT_0212f16c = 0;
  _DAT_0212f170 = 0;
  DAT_0212f174 = 0;
  uStack_8 = 2;
  FUN_00b86eb0();
  FUN_016f3654(&LAB_01890720);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1152 ; VA 0x004cb2f0 ; FUN_004cb2f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cb2f0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f903e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b85410(uVar2,0);
  FUN_009cb820(uVar1,s_GetFreeModels_0212f59c,0,CONCAT44(uVar3,uVar2),0);
  _DAT_0212f0e8 =
       RBX::Reflection::
       BoundYieldFuncDesc<class_RBX::InsertService,class_std::shared_ptr<class_std::vector<class_RBX::Reflection::Variant,class_std::allocator<class_RBX::Reflection::Variant>_>_const_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int),2>
       ::vftable;
  _DAT_0212f120 = FUN_00b888d0;
  _DAT_0212f124 = 0;
  _DAT_0212f128 = 0;
  DAT_0212f12c = 0;
  uStack_8 = 2;
  FUN_00b86eb0();
  FUN_016f3654(&LAB_01890750);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1153 ; VA 0x004cb3b0 ; FUN_004cb3b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cb3b0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f909c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b85410();
  FUN_009cb820(uVar1,s_GetLatestAssetVersionAsync_0212f644,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0212f3a8 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::InsertService,__int64___cdecl(__int64),1>::
       vftable;
  _DAT_0212f3e0 = FUN_00b88ac0;
  _DAT_0212f3e4 = 0;
  DAT_0212f3e8 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0212f3cc = FUN_0088da50();
  if (DAT_0212f3e8 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c1470(DAT_0212f3e8);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(s_assetId_0211bf40);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_01890780);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1154 ; VA 0x004cb530 ; FUN_004cb530 */

void FUN_004cb530(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00b85d70(FUN_00b892b0,0,s_GetUserCategories_0212f5e8,s_userId_0211fb64,0,
               CONCAT44(&DAT_0212f1b8,uStack_10),0);
  FUN_016f3654(&LAB_018907a0);
  return;
}



/* FUNCTION 1155 ; VA 0x004cb590 ; FUN_004cb590 */

void FUN_004cb590(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b85d70(FUN_00b892b0,0,s_GetUserSets_0212f5c8,s_userId_0211fb64,0,uStack_10,0);
  FUN_016f3654(&LAB_018907c0);
  return;
}



/* FUNCTION 1156 ; VA 0x004cb5f0 ; FUN_004cb5f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cb5f0(void)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f90fc;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_1c = 0;
  uStack_20 = CONCAT31(uStack_20._1_3_,1);
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b85410();
  FUN_009cb790(uVar2,s_Insert_0212f67c,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0212f438 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::InsertService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_0212f470 = FUN_00b89440;
  _DAT_0212f474 = 0;
  DAT_0212f478 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0212f45c = FUN_00888530();
  puVar4 = DAT_0212f478;
  if (DAT_0212f478 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088cdc0();
    iStack_ec = 0;
    if (puVar4[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar4[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e8 = *puVar4;
    uStack_e4 = puVar4[1];
    iStack_ec = FUN_006309e0();
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_instance_02126630);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_018907e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1157 ; VA 0x004cb7c0 ; FUN_004cb7c0 */

void FUN_004cb7c0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b85ed0(FUN_00b899e0,0,s_LoadAsset_0212f618,s_assetId_0211bf40,0,uStack_10,0);
  FUN_016f3654(&LAB_01890830);
  return;
}



/* FUNCTION 1158 ; VA 0x004cb820 ; FUN_004cb820 */

void FUN_004cb820(void)

{
  undefined4 uStack_10;
  
  uStack_10 = CONCAT31(uStack_10._1_3_,1);
  FUN_00b85ed0(FUN_00b899e0,0,s_loadAsset_0212f624,s_assetId_0211bf40,0,
               CONCAT44(&DAT_0212f2d0,uStack_10),0);
  FUN_016f3654(&LAB_01890850);
  return;
}



/* FUNCTION 1159 ; VA 0x004cb880 ; FUN_004cb880 */

void FUN_004cb880(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b85ed0(FUN_00b89b20,0,s_LoadAssetVersion_0212f630,s_assetVersionId_0212f560,0,uStack_10,0);
  FUN_016f3654(&LAB_01890870);
  return;
}



/* FUNCTION 1160 ; VA 0x004cb8e0 ; FUN_004cb8e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cb8e0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f915c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b85410();
  FUN_009cb790(uVar1,s_LoadLocalAsset_0212f66c,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0212f3f0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::InsertService,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
       ::vftable;
  _DAT_0212f428 = FUN_00b89ec0;
  _DAT_0212f42c = 0;
  DAT_0212f430 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0212f414 = FUN_0088cdc0();
  if (DAT_0212f430 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c13e0(DAT_0212f430);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(s_assetPath_0212f660);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_01890890);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1161 ; VA 0x004cbcf0 ; FUN_004cbcf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cbcf0(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("NativeCloseIntercept",0x14);
  _DAT_01ef22dc = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 1162 ; VA 0x004cbd60 ; FUN_004cbd60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cbd60(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("OpenExternalBrowser",0x13);
  _DAT_01ef22ec = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 1163 ; VA 0x004cbe70 ; FUN_004cbe70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cbe70(void)

{
  undefined uVar1;
  
  FUN_00ceb430();
  uVar1 = 0;
  FUN_005542c0("VirtualCursorEnabled",0x14);
  _DAT_01ef22e4 = FUN_00ceb4f0(uVar1);
  return;
}



/* FUNCTION 1164 ; VA 0x004cbef0 ; FUN_004cbef0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cbef0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa37a;
  pvStack_10 = ExceptionList;
  uStack_1c = uStack_1c & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330();
  FUN_00f50070(uVar1,s_SendCoreUiNotification_02130ec8,uStack_1c,0,5);
  uStack_8 = 0;
  _DAT_02130558 =
       RBX::Reflection::
       BoundAsyncCallbackDesc<class_RBX::GuiService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_02130590 = 0xb0;
  _DAT_02130598 = 0;
  _DAT_0213059c = 0;
  _DAT_0213057c = FUN_00888530();
  uVar1 = FUN_0088cb40();
  uVar2 = FUN_0086e3d0(s_title_02130ec0);
  FUN_00888aa0(uVar2,uVar1);
  uVar1 = FUN_0088cb40();
  uVar2 = FUN_0086e3d0(&DAT_02126680);
  FUN_00888aa0(uVar2,uVar1);
  FUN_016f3654(&LAB_01890af0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1165 ; VA 0x004cbfe0 ; FUN_004cbfe0 */

void FUN_004cbfe0(void)

{
  FUN_00b8f9b0(0x6c,s_BrowserWindowClosed_02130a74,5,1,0);
  FUN_016f3654(&LAB_01890b00);
  return;
}



/* FUNCTION 1166 ; VA 0x004cc030 ; FUN_004cc030 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cc030(void)

{
  undefined4 extraout_var;
  
  FUN_00b8f9b0(0xd8,s_CloseInspectMenuRequest_02130d94,5,0,0,0);
  _DAT_021302c0 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiService,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::GuiService::*>
       ::vftable;
  FUN_016f3654(&LAB_01890b10,extraout_var);
  return;
}



/* FUNCTION 1167 ; VA 0x004cc0e0 ; FUN_004cc0e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cc0e0(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa3be;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330();
  FUN_009cb970(uVar1,s_InspectPlayerFromHumanoidDescrip_02130d68,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021302bc = 0xd4;
  iStack_8 = 0;
  _DAT_02130288 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::GuiService::*>
       ::vftable;
  FUN_0086e3d0(s_humanoidDescription_0211f980);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(&DAT_0211a93c);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_021302b0 = uStack_1c;
  _DAT_021302b4 = uStack_18;
  _DAT_021302b8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_02130288 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::GuiService::*>
       ::vftable;
  FUN_016f3654(&LAB_01890b40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1168 ; VA 0x004cc250 ; FUN_004cc250 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cc250(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa3fe;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330();
  FUN_009cb970(uVar1,s_InspectPlayerFromUserIdWithCtxRe_02130d40,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02130284 = 0xd0;
  iStack_8 = 0;
  _DAT_02130250 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiService,void___cdecl(__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::GuiService::*>
       ::vftable;
  FUN_0086e3d0(s_userId_0211fb64);
  FUN_0088da50();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(&DAT_02130ce0);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02130278 = uStack_1c;
  _DAT_0213027c = uStack_18;
  _DAT_02130280 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_02130250 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiService,void___cdecl(__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::GuiService::*>
       ::vftable;
  FUN_016f3654(&LAB_01890b50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1169 ; VA 0x004cc3c0 ; FUN_004cc3c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cc3c0(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa43e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330();
  FUN_009cb970(uVar1,s_KeyPressed_02130908,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0212f794 = 0x74;
  iStack_8 = 0;
  _DAT_0212f760 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::GuiService::*>
       ::vftable;
  FUN_0086e3d0(&DAT_0211f870);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_modifiers_021308fc);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_0212f788 = uStack_1c;
  _DAT_0212f78c = uStack_18;
  _DAT_0212f790 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_0212f760 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::GuiService::*>
       ::vftable;
  FUN_016f3654(&LAB_01890b60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1170 ; VA 0x004cc530 ; FUN_004cc530 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cc530(void)

{
  undefined4 extraout_var;
  
  FUN_00b8f9b0(0x8c,s_MenuClosed_02130f24,0,0,0,0);
  _DAT_02130658 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiService,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::GuiService::*>
       ::vftable;
  FUN_016f3654(&LAB_01890b70,extraout_var);
  return;
}



/* FUNCTION 1171 ; VA 0x004cc580 ; FUN_004cc580 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cc580(void)

{
  undefined4 extraout_var;
  
  FUN_00b8f9b0(0x88,s_MenuOpened_02130f18,0,0,0,0);
  _DAT_02130620 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiService,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::GuiService::*>
       ::vftable;
  FUN_016f3654(&LAB_01890b80,extraout_var);
  return;
}



/* FUNCTION 1172 ; VA 0x004cc5d0 ; FUN_004cc5d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cc5d0(void)

{
  undefined4 extraout_var;
  
  FUN_00b8f9b0(0x94,s_NativeClose_02130bd4,5,0,0,0);
  _DAT_0212fee0 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiService,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::GuiService::*>
       ::vftable;
  FUN_016f3654(&LAB_01890b90,extraout_var);
  return;
}



/* FUNCTION 1173 ; VA 0x004cc650 ; FUN_004cc650 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cc650(void)

{
  undefined4 uVar1;
  undefined auStack_104 [216];
  undefined4 uStack_2c;
  undefined *puStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa473;
  pvStack_10 = ExceptionList;
  uStack_2c = CONCAT31(uStack_2c._1_3_,1);
  puStack_28 = &DAT_0212fd38;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330();
  FUN_009cb970(uVar1,s_ErrorMessageChanged_02130ba8,5,CONCAT44(puStack_28,uStack_2c),0);
  _DAT_0212fea4 = 0x7c;
  iStack_8 = 0;
  _DAT_0212fe70 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::GuiService::*>
       ::vftable;
  FUN_0086e3d0(s_newErrorMessage_02130b98);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_104,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 2;
  FUN_0068a760();
  _DAT_0212fe98 = uStack_1c;
  _DAT_0212fe9c = uStack_18;
  _DAT_0212fea0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_104,0xd8,1,FUN_00688b10);
  FUN_016f3654(&LAB_01890bb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1174 ; VA 0x004cc790 ; FUN_004cc790 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cc790(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa4ae;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330();
  FUN_009cb970(uVar1,s_UiMessageChanged_02130b48,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0212fd6c = 0x80;
  iStack_8 = 0;
  _DAT_0212fd38 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiService,void___cdecl(enum_RBX::GuiService::UiMessageType,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(enum_RBX::GuiService::UiMessageType,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(enum_RBX::GuiService::UiMessageType,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::GuiService::*>
       ::vftable;
  FUN_0086e3d0(s_msgType_02130b10);
  FUN_00b9db90();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_newUiMessage_02130b38);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_0212fd60 = uStack_1c;
  _DAT_0212fd64 = uStack_18;
  _DAT_0212fd68 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_0212fd38 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiService,void___cdecl(enum_RBX::GuiService::UiMessageType,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(enum_RBX::GuiService::UiMessageType,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(enum_RBX::GuiService::UiMessageType,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::GuiService::*>
       ::vftable;
  FUN_016f3654(&LAB_01890bc0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1175 ; VA 0x004cc900 ; FUN_004cc900 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cc900(void)

{
  undefined4 extraout_var;
  
  FUN_00b8f9b0(0x60,s_SafeZoneOffsetsChanged_02130a34,5,0,0,0);
  _DAT_0212faa8 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiService,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::GuiService::*>
       ::vftable;
  FUN_016f3654(&LAB_01890bd0,extraout_var);
  return;
}



/* FUNCTION 1176 ; VA 0x004cc950 ; FUN_004cc950 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cc950(void)

{
  undefined4 extraout_var;
  
  FUN_00b8f9b0(0x84,s_ShowLeaveConfirmation_02130bbc,5,0,0,0);
  _DAT_0212fea8 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiService,void___cdecl(void),class_rbx::signal<void___cdecl(void)>,class_rbx::signal<void___cdecl(void)>_RBX::GuiService::*>
       ::vftable;
  FUN_016f3654(&LAB_01890be0,extraout_var);
  return;
}



/* FUNCTION 1177 ; VA 0x004cc9a0 ; FUN_004cc9a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cc9a0(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa4ee;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330();
  FUN_009cb970(uVar1,s_SpecialKeyPressed_02130914,5,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_0212f7cc = 0x78;
  iStack_8 = 0;
  _DAT_0212f798 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiService,void___cdecl(enum_RBX::GuiService::SpecialKey,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(enum_RBX::GuiService::SpecialKey,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(enum_RBX::GuiService::SpecialKey,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::GuiService::*>
       ::vftable;
  FUN_0086e3d0(&DAT_0211f870);
  FUN_00b9dae0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_modifiers_021308fc);
  FUN_0088cb40();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_0212f7c0 = uStack_1c;
  _DAT_0212f7c4 = uStack_18;
  _DAT_0212f7c8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_0212f798 =
       RBX::Reflection::
       EventDesc<class_RBX::GuiService,void___cdecl(enum_RBX::GuiService::SpecialKey,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::signal<void___cdecl(enum_RBX::GuiService::SpecialKey,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::signal<void___cdecl(enum_RBX::GuiService::SpecialKey,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::GuiService::*>
       ::vftable;
  FUN_016f3654(&LAB_01890bf0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1178 ; VA 0x004ccb10 ; FUN_004ccb10 */

void FUN_004ccb10(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b8f850(FUN_00b93b20,0,s_CloseStatsBasedOnInputString_02130f4c,s_input_02125224,5,uStack_10,0
              );
  FUN_016f3654(&LAB_01890c00);
  return;
}



/* FUNCTION 1179 ; VA 0x004ccb70 ; FUN_004ccb70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ccb70(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa50a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_GetBrickCount_02130ae8,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212fc70 = RBX::Reflection::BoundFuncDesc<class_RBX::GuiService,int___cdecl(void),0>::vftable
  ;
  _DAT_0212fca8 = &LAB_00b979e0;
  _DAT_0212fcac = 0;
  _DAT_0212fc94 = FUN_0088c8c0();
  FUN_016f3654(&LAB_01890c20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1180 ; VA 0x004ccc10 ; FUN_004ccc10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ccc10(void)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  undefined *puStack_ec;
  undefined8 uStack_e8;
  undefined4 uStack_e0;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa56c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b8c330();
  FUN_009cb790(uVar2,s_GetClosestDialogToPosition_02130acc,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0212fc28 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GuiService,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_G3D::Vector3),1>
       ::vftable;
  _DAT_0212fc60 = FUN_00b979f0;
  _DAT_0212fc64 = 0;
  DAT_0212fc68 = (undefined8 *)0x0;
  uStack_8 = 1;
  _DAT_0212fc4c = FUN_0088cdc0();
  puVar1 = DAT_0212fc68;
  if (DAT_0212fc68 == (undefined8 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar4 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_0088d870();
    puStack_ec = (undefined *)0x0;
    uStack_e8 = *puVar1;
    uStack_e0 = *(undefined4 *)(puVar1 + 1);
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ead408) {
      FUN_016f3809(&DAT_01ead408);
      if (DAT_01ead408 == -1) {
        _DAT_01ead3fc = FUN_005c6600;
        _DAT_01ead400 = FUN_005c6600;
        DAT_01ead404 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ead408);
      }
    }
    puStack_ec = &DAT_01ead3fc;
    puVar4 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar2 = FUN_0088d870();
  uVar3 = FUN_0086e3d0(s_position_0211fd1c);
  FUN_00888b30(uVar3,uVar2,puVar4);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (puStack_ec != (undefined *)0x0) {
      (**(code **)(puStack_ec + 8))(&uStack_e8);
    }
  }
  FUN_016f3654(&LAB_01890c30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1181 ; VA 0x004cce30 ; FUN_004cce30 */

void FUN_004cce30(void)

{
  FUN_00b8f3f0(FUN_00b9b5a0,0,s_OpenBrowserWindow_02130a60,&DAT_0211c024,5,1,0);
  FUN_016f3654(&LAB_01890c50);
  return;
}



/* FUNCTION 1182 ; VA 0x004cce90 ; FUN_004cce90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cce90(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa59e;
  pvStack_10 = ExceptionList;
  uVar3 = 0;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_OpenNativeOverlay_02130fa4,5,CONCAT44(uVar3,uVar2),0);
  _DAT_021307d8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GuiService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_02130810 = FUN_00b9b710;
  _DAT_02130814 = 0;
  _DAT_02130818 = 0;
  _DAT_0213081c = 0;
  uStack_8 = 2;
  FUN_00b94f90();
  FUN_016f3654(&LAB_01890c70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1183 ; VA 0x004ccf50 ; FUN_004ccf50 */

void FUN_004ccf50(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b8f850(FUN_00b9d6d0,0,s_ShowStatsBasedOnInputString_02130f30,s_input_02125224,5,uStack_10,0)
  ;
  FUN_016f3654(&LAB_01890c90);
  return;
}



/* FUNCTION 1184 ; VA 0x004ccfb0 ; FUN_004ccfb0 */

void FUN_004ccfb0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b8f3f0(FUN_00b92d60,0,s_AddKey_02130928,&DAT_0211f870,5,uStack_10,0);
  FUN_016f3654(&LAB_01890cb0);
  return;
}



/* FUNCTION 1185 ; VA 0x004cd010 ; FUN_004cd010 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cd010(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa5ce;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_AddSelectionParent_02130c64,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02130020 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GuiService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::Instance>),2>
       ::vftable;
  _DAT_02130058 = FUN_00b930c0;
  _DAT_0213005c = 0;
  _DAT_02130060 = 0;
  DAT_02130064 = 0;
  uStack_8 = 2;
  FUN_00b95600();
  FUN_016f3654(&LAB_01890cd0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1186 ; VA 0x004cd0d0 ; FUN_004cd0d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cd0d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa5fe;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_AddSelectionTuple_02130c84,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02130068 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GuiService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>),2>
       ::vftable;
  _DAT_021300a0 = FUN_00b92f10;
  _DAT_021300a4 = 0;
  _DAT_021300a8 = 0;
  DAT_021300ac = 0;
  uStack_8 = 2;
  FUN_00b95370();
  FUN_016f3654(&LAB_01890d30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1187 ; VA 0x004cd190 ; FUN_004cd190 */

void FUN_004cd190(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b8f550(FUN_00b92410,0,s_AddSpecialKey_0213093c,&DAT_0211f870,5,uStack_10,0);
  FUN_016f3654(&LAB_01890d90);
  return;
}



/* FUNCTION 1188 ; VA 0x004cd1f0 ; FUN_004cd1f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cd1f0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa62e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_BroadcastNotification_02130a9c,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212fba0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GuiService,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,int),2>
       ::vftable;
  _DAT_0212fbd8 = FUN_00b932f0;
  _DAT_0212fbdc = 0;
  _DAT_0212fbe0 = 0;
  DAT_0212fbe4 = 0;
  uStack_8 = 2;
  FUN_00b95170();
  FUN_016f3654(&LAB_01890db0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1189 ; VA 0x004cd2b0 ; FUN_004cd2b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cd2b0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa64a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_ClearError_02130b8c,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212fe30 =
       RBX::Reflection::BoundFuncDesc<class_RBX::GuiService,void___cdecl(void),0>::vftable;
  _DAT_0212fe68 = FUN_00b93a40;
  _DAT_0212fe6c = 0;
  _DAT_0212fe54 = FUN_00888530();
  FUN_016f3654(&LAB_01890de0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1190 ; VA 0x004cd350 ; FUN_004cd350 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cd350(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa66a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_CloseInspectMenu_02130d2c,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02130210 =
       RBX::Reflection::BoundFuncDesc<class_RBX::GuiService,void___cdecl(void),0>::vftable;
  _DAT_02130248 = &LAB_00b93b10;
  _DAT_0213024c = 0;
  _DAT_02130234 = FUN_00888530();
  FUN_016f3654(&LAB_01890df0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1191 ; VA 0x004cd3f0 ; FUN_004cd3f0 */

void FUN_004cd3f0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b8f6d0(FUN_00b97970,0,s_ForceTenFootInterface_02130c14,s_isForced_02130c08,5,uStack_10,0);
  FUN_016f3654(&LAB_01890e00);
  return;
}



/* FUNCTION 1192 ; VA 0x004cd450 ; FUN_004cd450 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cd450(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa68a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_GetInspectMenuEnabled_02130cb0,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_021300f8 =
       RBX::Reflection::BoundFuncDesc<class_RBX::GuiService,bool___cdecl(void),0>::vftable;
  _DAT_02130130 = &LAB_00b97e80;
  _DAT_02130134 = 0;
  _DAT_0213011c = FUN_0088daf0();
  FUN_016f3654(&LAB_01890e20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1193 ; VA 0x004cd4f0 ; FUN_004cd4f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cd4f0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa6aa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_GetEmotesMenuOpen_02130fd4,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02130868 =
       RBX::Reflection::BoundFuncDesc<class_RBX::GuiService,bool___cdecl(void),0>::vftable;
  _DAT_021308a0 = &LAB_00b97e90;
  _DAT_021308a4 = 0;
  _DAT_0213088c = FUN_0088daf0();
  FUN_016f3654(&LAB_01890e30);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1194 ; VA 0x004cd590 ; FUN_004cd590 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cd590(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa6ca;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_GetErrorCode_02130b6c,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212fdb0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GuiService,enum_RBX::ConnectionError___cdecl(void),0>::vftable;
  _DAT_0212fde8 = &LAB_00b97ea0;
  _DAT_0212fdec = 0;
  _DAT_0212fdd4 = thunk_FUN_00b9da50();
  FUN_016f3654(&LAB_01890e40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1195 ; VA 0x004cd630 ; FUN_004cd630 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cd630(void)

{
  undefined4 uVar1;
  undefined4 in_stack_ffffffe4;
  undefined4 uVar2;
  undefined *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa6ea;
  pvStack_10 = ExceptionList;
  uVar2 = CONCAT31((int3)((uint)in_stack_ffffffe4 >> 8),1);
  puVar3 = &DAT_0212fcf8;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,&DAT_0212fcf8);
  FUN_009cb790(uVar1,s_GetErrorMessage_02130b5c,5,CONCAT44(puVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212fd70 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GuiService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(void),0>
       ::vftable;
  _DAT_0212fda8 = FUN_00b97eb0;
  _DAT_0212fdac = 0;
  _DAT_0212fd94 = FUN_0088cb40();
  FUN_016f3654(&LAB_01890e50);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1196 ; VA 0x004cd6d0 ; FUN_004cd6d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cd6d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa70a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_GetErrorType_02130b7c,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212fdf0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GuiService,enum_RBX::ConnectionError___cdecl(void),0>::vftable;
  _DAT_0212fe28 = &LAB_00b97ed0;
  _DAT_0212fe2c = 0;
  _DAT_0212fe14 = thunk_FUN_00b9da50();
  FUN_016f3654(&LAB_01890e60);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1197 ; VA 0x004cd770 ; FUN_004cd770 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cd770(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa72a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_GetGuiInset_021309e4,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212f9d8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GuiService,class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0212fa10 = FUN_00b97f10;
  _DAT_0212fa14 = 0;
  _DAT_0212f9fc = FUN_0088cbe0();
  FUN_016f3654(&LAB_01890e70);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1198 ; VA 0x004cd810 ; FUN_004cd810 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cd810(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa74a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_GetGameplayPausedNotificationEna_02130df4,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02130378 =
       RBX::Reflection::BoundFuncDesc<class_RBX::GuiService,bool___cdecl(void),0>::vftable;
  _DAT_021303b0 = &LAB_00b98410;
  _DAT_021303b4 = 0;
  _DAT_0213039c = FUN_0088daf0();
  FUN_016f3654(&LAB_01890e80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1199 ; VA 0x004cd8b0 ; FUN_004cd8b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cd8b0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa76a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_GetNotificationTypeList_02130ab4,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212fbe8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GuiService,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0212fc20 = FUN_00b98420;
  _DAT_0212fc24 = 0;
  _DAT_0212fc0c = FUN_008881d0();
  FUN_016f3654(&LAB_01890e90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1200 ; VA 0x004cd950 ; FUN_004cd950 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cd950(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa78a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_GetResolutionScale_02130f90,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02130798 = RBX::Reflection::BoundFuncDesc<class_RBX::GuiService,int___cdecl(void),0>::vftable
  ;
  _DAT_021307d0 = FUN_0070ddc0;
  _DAT_021307d4 = 0;
  _DAT_021307bc = FUN_0088c8c0();
  FUN_016f3654(&LAB_01890ea0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1201 ; VA 0x004cd9f0 ; FUN_004cd9f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cd9f0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa7aa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_GetSafeZoneOffsets_02130a20,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212fa68 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GuiService,class_std::shared_ptr<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_const_>___cdecl(void),0>
       ::vftable;
  _DAT_0212faa0 = FUN_00b98550;
  _DAT_0212faa4 = 0;
  _DAT_0212fa8c = FUN_008881d0();
  FUN_016f3654(&LAB_01890eb0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1202 ; VA 0x004cda90 ; FUN_004cda90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cda90(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa7ca;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb820(uVar1,s_GetScreenResolution_02130a4c,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212fae0 =
       RBX::Reflection::BoundYieldFuncDesc<class_RBX::GuiService,class_G3D::Vector2___cdecl(void),0>
       ::vftable;
  _DAT_0212fb18 = FUN_00b98920;
  _DAT_0212fb1c = 0;
  _DAT_0212fb04 = FUN_0088d730();
  FUN_016f3654(&LAB_01890ec0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1203 ; VA 0x004cdb30 ; FUN_004cdb30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cdb30(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa7ea;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_GetUiMessage_02130b28,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212fcf8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GuiService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(void),0>
       ::vftable;
  _DAT_0212fd30 = FUN_00b99400;
  _DAT_0212fd34 = 0;
  _DAT_0212fd1c = FUN_0088cb40();
  FUN_016f3654(&LAB_01890ed0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1204 ; VA 0x004cdbd0 ; FUN_004cdbd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cdbd0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa832;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_SetGlobalGuiInset_021309d0,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212f988 =
       RBX::Reflection::BoundFuncDesc<class_RBX::GuiService,void___cdecl(int,int,int,int),4>::
       vftable;
  _DAT_0212f9c0 = FUN_00b9cb60;
  _DAT_0212f9c4 = 0;
  DAT_0212f9c8 = 0;
  DAT_0212f9cc = 0;
  DAT_0212f9d0 = 0;
  DAT_0212f9d4 = 0;
  uStack_8 = 4;
  FUN_00b94780(&DAT_021309cc,&DAT_021309c8,&DAT_021309c4,&DAT_021309c0);
  FUN_016f3654(&LAB_01890ee0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1205 ; VA 0x004cdcb0 ; FUN_004cdcb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cdcb0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa88c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330();
  FUN_009cb790(uVar1,s_RemoveCenterDialog_021309ac,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0212f940 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GuiService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
       ::vftable;
  _DAT_0212f978 = FUN_00b9bcd0;
  _DAT_0212f97c = 0;
  DAT_0212f980 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0212f964 = FUN_00888530();
  if (DAT_0212f980 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_006874f0(DAT_0212f980);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088cdc0();
  uVar3 = FUN_0086e3d0(s_dialog_02130994);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_01890f40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1206 ; VA 0x004cde30 ; FUN_004cde30 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cde30(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa8be;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_InspectPlayerFromHumanoidDescrip_02130d04,0,CONCAT44(uVar3,uVar2),0);
  _DAT_021301c8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GuiService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_02130200 = FUN_00b99940;
  _DAT_02130204 = 0;
  DAT_02130208 = 0;
  _DAT_0213020c = 0;
  uStack_8 = 2;
  FUN_00b957e0();
  FUN_016f3654(&LAB_01890f90);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1207 ; VA 0x004cdef0 ; FUN_004cdef0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cdef0(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined auStack_e8 [200];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa91c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330();
  FUN_009cb790(uVar1,s_InspectPlayerFromUserId_02130cc8,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02130138 =
       RBX::Reflection::BoundFuncDesc<class_RBX::GuiService,void___cdecl(__int64),1>::vftable;
  _DAT_02130170 = FUN_00b99b50;
  _DAT_02130174 = 0;
  DAT_02130178 = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213015c = FUN_00888530();
  if (DAT_02130178 == 0) {
    uStack_f0 = FUN_00888530();
    iStack_ec = 0;
    puVar2 = &uStack_f0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    puVar2 = (undefined4 *)FUN_005c1470(DAT_02130178);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(s_userId_0211fb64);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  FUN_016f3654(&LAB_01890ff0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1208 ; VA 0x004ce070 ; FUN_004ce070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ce070(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa94e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_InspectPlayerFromUserIdWithCtx_02130ce4,5,CONCAT44(uVar3,uVar2),0);
  _DAT_02130180 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GuiService,void___cdecl(__int64,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_021301b8 = FUN_00b99bc0;
  _DAT_021301bc = 0;
  DAT_021301c0 = 0;
  _DAT_021301c4 = 0;
  uStack_8 = 2;
  FUN_00b95f60();
  FUN_016f3654(&LAB_01891010);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1209 ; VA 0x004ce130 ; FUN_004ce130 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ce130(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa96a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_IsMemoryTrackerEnabled_02130c2c,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212ffe0 =
       RBX::Reflection::BoundFuncDesc<class_RBX::GuiService,bool___cdecl(void),0>::vftable;
  _DAT_02130018 = &LAB_00b9a780;
  _DAT_0213001c = 0;
  _DAT_02130004 = FUN_0088daf0();
  FUN_016f3654(&LAB_01891040);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1210 ; VA 0x004ce1d0 ; FUN_004ce1d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ce1d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa98a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_IsTenFootInterface_02130bf4,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212ff58 =
       RBX::Reflection::BoundFuncDesc<class_RBX::GuiService,bool___cdecl(void),0>::vftable;
  _DAT_0212ff90 = &LAB_00b9a790;
  _DAT_0212ff94 = 0;
  _DAT_0212ff7c = FUN_0088daf0();
  FUN_016f3654(&LAB_01891050);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1211 ; VA 0x004ce270 ; FUN_004ce270 */

void FUN_004ce270(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b8f3f0(FUN_00b9c000,0,s_RemoveKey_02130930,&DAT_0211f870,5,uStack_10,0);
  FUN_016f3654(&LAB_01891060);
  return;
}



/* FUNCTION 1212 ; VA 0x004ce2d0 ; FUN_004ce2d0 */

void FUN_004ce2d0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b8f3f0(FUN_00b9c250,0,s_RemoveSelectionGroup_02130e38,s_selectionName_02130c54,0,uStack_10,0
              );
  FUN_016f3654(&LAB_01891080);
  return;
}



/* FUNCTION 1213 ; VA 0x004ce330 ; FUN_004ce330 */

void FUN_004ce330(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b8f550(FUN_00b924e0,0,s_RemoveSpecialKey_0213094c,&DAT_0211f870,5,uStack_10,0);
  FUN_016f3654(&LAB_018910a0);
  return;
}



/* FUNCTION 1214 ; VA 0x004ce390 ; FUN_004ce390 */

void FUN_004ce390(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b8f6d0(FUN_00b9c900,0,s_SetInspectMenuEnabled_02130c98,s_enabled_02123dec,0,uStack_10,0);
  FUN_016f3654(&LAB_018910c0);
  return;
}



/* FUNCTION 1215 ; VA 0x004ce3f0 ; FUN_004ce3f0 */

void FUN_004ce3f0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b8f6d0(FUN_00b9c920,0,s_SetEmotesMenuOpen_02130fc0,s_isOpen_02130fb8,0,uStack_10,0);
  FUN_016f3654(&LAB_018910e0);
  return;
}



/* FUNCTION 1216 ; VA 0x004ce450 ; FUN_004ce450 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ce450(void)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fa9d5;
  pvStack_10 = ExceptionList;
  pcVar3 = &DAT_02130eec;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  uStack_8 = 0;
  uVar2 = FUN_00b8c330();
  FUN_009cb790(uVar2,s_SetMenuIsOpen_02130f08,5,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_021305d8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GuiService,void___cdecl(bool,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_02130610 = FUN_00b9cc10;
  _DAT_02130614 = 0;
  DAT_02130618 = 0;
  uStack_8._0_1_ = 2;
  iStack_14 = FUN_01674e20(0x18);
  uStack_8._0_1_ = 3;
  if (iStack_14 == 0) {
    _DAT_0213061c = 0;
  }
  else {
    _DAT_0213061c = FUN_0054ef60(auStack_38);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00b96140();
  if (0xf < uStack_24) {
    if (0xfff < uStack_24 + 1) {
      if (0x1f < (auStack_38[0] - *(int *)(auStack_38[0] - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  FUN_016f3654(&LAB_01891100);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1217 ; VA 0x004ce5a0 ; FUN_004ce5a0 */

void FUN_004ce5a0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00b8f6d0(FUN_00b9cdc0,0,s_SetGameplayPausedNotificationEna_02130dcc,s_enabled_02123dec,0,
               uStack_10,0);
  FUN_016f3654(&LAB_01891130);
  return;
}



/* FUNCTION 1218 ; VA 0x004ce600 ; FUN_004ce600 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ce600(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017faa12;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_SetSafeZoneOffsets_02130a0c,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212fa18 =
       RBX::Reflection::BoundFuncDesc<class_RBX::GuiService,void___cdecl(float,float,float,float),4>
       ::vftable;
  _DAT_0212fa50 = FUN_00b9cf70;
  _DAT_0212fa54 = 0;
  DAT_0212fa58 = 0;
  DAT_0212fa5c = 0;
  DAT_0212fa60 = 0;
  DAT_0212fa64 = 0;
  uStack_8 = 4;
  FUN_00b94b80(&DAT_02130a08,s_bottom_02130a00,&DAT_021309f8,s_right_021309f0);
  FUN_016f3654(&LAB_01891150);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1219 ; VA 0x004ce6e0 ; FUN_004ce6e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ce6e0(void)

{
  char cVar1;
  undefined4 uVar2;
  char *pcVar3;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  uint uStack_20;
  undefined4 uStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017faa55;
  pvStack_10 = ExceptionList;
  pcVar3 = &DAT_02130af8;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  uStack_8 = 0;
  uVar2 = FUN_00b8c330();
  FUN_009cb790(uVar2,s_SetUiMessage_02130b18,3,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_0212fcb0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GuiService,void___cdecl(enum_RBX::GuiService::UiMessageType,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),2>
       ::vftable;
  _DAT_0212fce8 = FUN_00b9d0b0;
  _DAT_0212fcec = 0;
  DAT_0212fcf0 = 0;
  uStack_8._0_1_ = 2;
  iStack_14 = FUN_01674e20(0x18);
  uStack_8._0_1_ = 3;
  if (iStack_14 == 0) {
    _DAT_0212fcf4 = 0;
  }
  else {
    _DAT_0212fcf4 = FUN_0054ef60(auStack_38);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_00b95d60();
  if (0xf < uStack_24) {
    if (0xfff < uStack_24 + 1) {
      if (0x1f < (auStack_38[0] - *(int *)(auStack_38[0] - 4)) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  FUN_016f3654(&LAB_018911b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1220 ; VA 0x004ce830 ; FUN_004ce830 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ce830(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017faa92;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_AddCenterDialog_0213099c,5,CONCAT44(uVar3,uVar2),0);
  _DAT_0212f8f0 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::GuiService,void___cdecl(class_std::shared_ptr<class_RBX::Instance>,enum_RBX::GuiService::CenterDialogType,class_RBX::Lua::WeakFunctionRef,class_RBX::Lua::WeakFunctionRef),4>
       ::vftable;
  _DAT_0212f928 = FUN_00b928e0;
  _DAT_0212f92c = 0;
  _DAT_0212f930 = 0;
  _DAT_0212f934 = 0;
  _DAT_0212f938 = 0;
  _DAT_0212f93c = 0;
  uStack_8 = 4;
  FUN_00b959c0(s_dialog_02130994,s_centerDialogType_02130980,s_showFunction_02130970,
               s_hideFunction_02130960);
  FUN_016f3654(&LAB_018911e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1221 ; VA 0x004ce910 ; FUN_004ce910 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ce910(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017faaaa;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b8c330(uVar2,0);
  FUN_009cb790(uVar1,s_ToggleFullscreen_02130be0,5,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_0212ff18 =
       RBX::Reflection::BoundFuncDesc<class_RBX::GuiService,void___cdecl(void),0>::vftable;
  _DAT_0212ff50 = FUN_00b9e110;
  _DAT_0212ff54 = 0;
  _DAT_0212ff3c = FUN_00888530();
  FUN_016f3654(&LAB_018911f0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1222 ; VA 0x004ceeb0 ; FUN_004ceeb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004ceeb0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fb65c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b9e640();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::Folder,int>::
              GetSetImpl<int_(__thiscall_RBX::Folder::*)(void)const_,void_(__thiscall_RBX::Folder::*)(int)>
              ::vftable;
    puVar3[2] = FUN_00b9e920;
    puVar3[3] = 0;
    puVar3[4] = FUN_00b9ea50;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088c8c0();
  FUN_009ca670(uVar2,uVar4,"ReplicatedGuiInsertionOrder",&DAT_018dbc3c,uStack_24,0,0,0x22,6,6,0);
  DAT_01ef2738 = RBX::Reflection::TypedPropertyDescriptor<int>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01ef276c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01ef275c = _DAT_01ef275c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01ef2738[2])();
    if (cVar1 != '\0') {
      _DAT_01ef275c = _DAT_01ef275c & 0xfffffff3;
    }
  }
  DAT_01ef2738 = RBX::Reflection::PropDescriptor<class_RBX::Folder,int>::vftable;
  FUN_016f3654(&LAB_018913a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1223 ; VA 0x004cf0a0 ; FUN_004cf0a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cf0a0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fbc4c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00ba0840();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::FileSyncItem,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetSetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::FileSyncItem::*)(void)const_,void_(__thiscall_RBX::FileSyncItem::*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const&)>
              ::vftable;
    puVar3[2] = FUN_00ba4f60;
    puVar3[3] = 0;
    puVar3[4] = FUN_00ba89c0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,&DAT_0195a9ec,&DAT_018dbc3c,uStack_24,0,0,0x1d,5,5,0);
  DAT_01ef2c28 = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_01ef2c5c = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_01ef2c4c = _DAT_01ef2c4c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_01ef2c28[2])();
    if (cVar1 != '\0') {
      _DAT_01ef2c4c = _DAT_01ef2c4c & 0xfffffff3;
    }
  }
  DAT_01ef2c28 = RBX::Reflection::
                 PropDescriptor<class_RBX::FileSyncItem,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_01891470);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1224 ; VA 0x004cf1d0 ; FUN_004cf1d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cf1d0(void)

{
  char cVar1;
  undefined4 uVar2;
  uint in_stack_ffffffdc;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fbc80;
  pvStack_10 = ExceptionList;
  uVar3 = in_stack_ffffffdc & 0xffffff00;
  uVar4 = 0;
  uVar5 = 0;
  uVar6 = 0x15;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01edf874) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01edf874,uVar3,0,0,0x15);
    if (DAT_01edf874 == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01edf850 = RBX::Reflection::RefType<class_RBX::Instance*>::vftable;
      FUN_016f3654(&LAB_018813c0);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01edf874);
    }
  }
  uVar2 = FUN_00ba0840();
  FUN_009ca670(uVar2,&DAT_01edf850,"Target",&DAT_018dbc3c,uVar3,uVar4,uVar5,uVar6,5,5,0);
  uStack_8 = 1;
  DAT_01ef2c60 = RBX::Reflection::RefPropDescriptor<class_RBX::FileSyncItem,class_RBX::Instance>::
                 vftable;
  _DAT_01ef2c94 =
       RBX::Reflection::RefPropDescriptor<class_RBX::FileSyncItem,class_RBX::Instance>::vftable;
  DAT_01ef2c98 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_01ef2c98 == (undefined4 *)0x0) {
    DAT_01ef2c98 = (undefined4 *)0x0;
  }
  else {
    *DAT_01ef2c98 =
         RBX::Reflection::PropDescriptor<class_RBX::FileSyncItem,class_RBX::Instance*>::
         GetSetImpl<class_RBX::Instance*_(__thiscall_RBX::FileSyncItem::*)(void)const_,void_(__thiscall_RBX::FileSyncItem::*)(class_RBX::Instance*)>
         ::vftable;
    DAT_01ef2c98[2] = &LAB_00ba5950;
    DAT_01ef2c98[3] = 0;
    DAT_01ef2c98[4] = FUN_00ba8ce0;
    DAT_01ef2c98[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (*(code *)DAT_01ef2c60[3])();
  if (cVar1 != '\0') {
    _DAT_01ef2c84 = _DAT_01ef2c84 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_01ef2c60[2])();
  if (cVar1 != '\0') {
    _DAT_01ef2c84 = _DAT_01ef2c84 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01891490);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1225 ; VA 0x004cf3e0 ; FUN_004cf3e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cf3e0(void)

{
  undefined4 uVar1;
  int iVar2;
  undefined *puVar3;
  undefined auStack_2c [16];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fca2d;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("blank@roblox.com",0x10);
  uStack_8 = 0;
  DAT_01ef2ec0 = 0;
  _DAT_01ef2ec4 = 0;
  DAT_01ef2ec0 = FUN_00575b30();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  puVar3 = auStack_2c;
  do {
    uVar1 = DAT_01ef2ec0;
    iVar2 = FUN_00559300(puVar3);
    FUN_0064c760(auStack_14,uVar1,iVar2 + 0x10,iVar2);
    puVar3 = puVar3 + 0x18;
  } while (puVar3 != auStack_14);
  uStack_8 = 0xffffffff;
  FUN_016f32d1(auStack_2c,0x18,1,FUN_005507b0);
  FUN_016f3654(FUN_01891510);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1226 ; VA 0x004cf5b0 ; FUN_004cf5b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cf5b0(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd12e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00baf370();
  FUN_009cb970(uVar1,s_TouchpadModeChanged_021313dc,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021312fc = 0x68;
  iStack_8 = 0;
  _DAT_021312c8 =
       RBX::Reflection::
       EventDesc<class_RBX::VRService,void___cdecl(enum_RBX::VRService::VRTouchpad,enum_RBX::VRService::VRTouchpadMode),class_rbx::signal<void___cdecl(enum_RBX::VRService::VRTouchpad,enum_RBX::VRService::VRTouchpadMode)>,class_rbx::signal<void___cdecl(enum_RBX::VRService::VRTouchpad,enum_RBX::VRService::VRTouchpadMode)>_RBX::VRService::*>
       ::vftable;
  FUN_0086e3d0(&DAT_021313b8);
  FUN_00bb1980();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(&DAT_021313b0);
  FUN_00bb1a30();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_021312f0 = uStack_1c;
  _DAT_021312f4 = uStack_18;
  _DAT_021312f8 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_021312c8 =
       RBX::Reflection::
       EventDesc<class_RBX::VRService,void___cdecl(enum_RBX::VRService::VRTouchpad,enum_RBX::VRService::VRTouchpadMode),class_rbx::signal<void___cdecl(enum_RBX::VRService::VRTouchpad,enum_RBX::VRService::VRTouchpadMode)>,class_rbx::signal<void___cdecl(enum_RBX::VRService::VRTouchpad,enum_RBX::VRService::VRTouchpadMode)>_RBX::VRService::*>
       ::vftable;
  FUN_016f3654(&LAB_01891600);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1227 ; VA 0x004cf720 ; FUN_004cf720 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cf720(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd16e;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00baf370();
  FUN_009cb970(uVar1,s_UserCFrameEnabled_02131364,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021311b4 = 0x5c;
  iStack_8 = 0;
  _DAT_02131180 =
       RBX::Reflection::
       EventDesc<class_RBX::VRService,void___cdecl(enum_RBX::VRService::UserCFrame,bool),class_rbx::signal<void___cdecl(enum_RBX::VRService::UserCFrame,bool)>,class_rbx::signal<void___cdecl(enum_RBX::VRService::UserCFrame,bool)>_RBX::VRService::*>
       ::vftable;
  FUN_0086e3d0(&DAT_0212eed8);
  FUN_00b849a0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_enabled_02123dec);
  FUN_0088daf0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_021311a8 = uStack_1c;
  _DAT_021311ac = uStack_18;
  _DAT_021311b0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_02131180 =
       RBX::Reflection::
       EventDesc<class_RBX::VRService,void___cdecl(enum_RBX::VRService::UserCFrame,bool),class_rbx::signal<void___cdecl(enum_RBX::VRService::UserCFrame,bool)>,class_rbx::signal<void___cdecl(enum_RBX::VRService::UserCFrame,bool)>_RBX::VRService::*>
       ::vftable;
  FUN_016f3654(&LAB_01891610);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1228 ; VA 0x004cf890 ; FUN_004cf890 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cf890(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd1ae;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00baf370();
  FUN_009cb970(uVar1,s_UserCFrameChanged_0212eef0,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_021310f4 = 0x58;
  iStack_8 = 0;
  _DAT_021310c0 =
       RBX::Reflection::
       EventDesc<class_RBX::VRService,void___cdecl(enum_RBX::VRService::UserCFrame,class_G3D::CoordinateFrame),class_rbx::signal<void___cdecl(enum_RBX::VRService::UserCFrame,class_G3D::CoordinateFrame)>,class_rbx::signal<void___cdecl(enum_RBX::VRService::UserCFrame,class_G3D::CoordinateFrame)>_RBX::VRService::*>
       ::vftable;
  FUN_0086e3d0(&DAT_0212eed8);
  FUN_00b849a0();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_value_0211ab70);
  FUN_00b00260();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_021310e8 = uStack_1c;
  _DAT_021310ec = uStack_18;
  _DAT_021310f0 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_021310c0 =
       RBX::Reflection::
       EventDesc<class_RBX::VRService,void___cdecl(enum_RBX::VRService::UserCFrame,class_G3D::CoordinateFrame),class_rbx::signal<void___cdecl(enum_RBX::VRService::UserCFrame,class_G3D::CoordinateFrame)>,class_rbx::signal<void___cdecl(enum_RBX::VRService::UserCFrame,class_G3D::CoordinateFrame)>_RBX::VRService::*>
       ::vftable;
  FUN_016f3654(&LAB_01891620);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1229 ; VA 0x004cfa00 ; FUN_004cfa00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cfa00(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd20c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00baf370();
  FUN_009cb790(uVar1,s_GetTouchpadMode_021313cc,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02131280 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::VRService,enum_RBX::VRService::VRTouchpadMode___cdecl(enum_RBX::VRService::VRTouchpad),1>
       ::vftable;
  _DAT_021312b8 = FUN_00bb1460;
  _DAT_021312bc = 0;
  DAT_021312c0 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_021312a4 = FUN_00bb1a30();
  puVar3 = DAT_021312c0;
  if (DAT_021312c0 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_00bb1980();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00bb1ae0();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_00bb1980();
  uVar2 = FUN_0086e3d0(&DAT_021313b8);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01891630);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1230 ; VA 0x004cfba0 ; FUN_004cfba0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cfba0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd26c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00baf370();
  FUN_009cb790(uVar1,s_GetUserCFrameEnabled_0213134c,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02131138 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::VRService,bool___cdecl(enum_RBX::VRService::UserCFrame),1>::vftable;
  _DAT_02131170 = FUN_00bb1440;
  _DAT_02131174 = 0;
  DAT_02131178 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213115c = FUN_0088daf0();
  puVar3 = DAT_02131178;
  if (DAT_02131178 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_00b849a0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00b84b30();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_00b849a0();
  uVar2 = FUN_0086e3d0(&DAT_0212eed8);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01891650);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1231 ; VA 0x004cfd40 ; FUN_004cfd40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cfd40(void)

{
  undefined4 uVar1;
  undefined auStack_1dc [432];
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd2ae;
  pvStack_10 = ExceptionList;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_28 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00baf370();
  FUN_009cb970(uVar1,s_NavigationRequested_0213139c,0,CONCAT44(uStack_28,uStack_2c),0);
  _DAT_02131234 = 100;
  iStack_8 = 0;
  _DAT_02131200 =
       RBX::Reflection::
       EventDesc<class_RBX::VRService,void___cdecl(class_G3D::CoordinateFrame,enum_RBX::VRService::UserCFrame),class_rbx::signal<void___cdecl(class_G3D::CoordinateFrame,enum_RBX::VRService::UserCFrame)>,class_rbx::signal<void___cdecl(class_G3D::CoordinateFrame,enum_RBX::VRService::UserCFrame)>_RBX::VRService::*>
       ::vftable;
  FUN_0086e3d0(s_cframe_0212a324);
  FUN_00b00260();
  FUN_00888740();
  iStack_8._0_1_ = 1;
  FUN_0086e3d0(s_inputUserCFrame_02131378);
  FUN_00b849a0();
  FUN_00888740();
  iStack_8._0_1_ = 2;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  FUN_00687810(auStack_1dc,&uStack_2c,uStack_20);
  iStack_8._0_1_ = 3;
  FUN_0068a760();
  _DAT_02131228 = uStack_1c;
  _DAT_0213122c = uStack_18;
  _DAT_02131230 = uStack_14;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_14 = 0;
  iStack_8._0_1_ = 4;
  FUN_0068a760();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_016f32d1(auStack_1dc,0xd8,2,FUN_00688b10);
  _DAT_02131200 =
       RBX::Reflection::
       EventDesc<class_RBX::VRService,void___cdecl(class_G3D::CoordinateFrame,enum_RBX::VRService::UserCFrame),class_rbx::signal<void___cdecl(class_G3D::CoordinateFrame,enum_RBX::VRService::UserCFrame)>,class_rbx::signal<void___cdecl(class_G3D::CoordinateFrame,enum_RBX::VRService::UserCFrame)>_RBX::VRService::*>
       ::vftable;
  FUN_016f3654(&LAB_01891670);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1232 ; VA 0x004cfeb0 ; FUN_004cfeb0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cfeb0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd2de;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00baf370(uVar2,0);
  FUN_009cb790(uVar1,s_RequestNavigation_02131388,0,CONCAT44(uVar3,uVar2),0);
  _DAT_021311b8 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::VRService,void___cdecl(class_G3D::CoordinateFrame,enum_RBX::VRService::UserCFrame),2>
       ::vftable;
  _DAT_021311f0 = FUN_00bb1600;
  _DAT_021311f4 = 0;
  DAT_021311f8 = 0;
  DAT_021311fc = 0;
  uStack_8 = 2;
  FUN_00bb0620();
  FUN_016f3654(&LAB_01891680);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1233 ; VA 0x004cff70 ; FUN_004cff70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004cff70(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd30e;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00baf370(uVar2,0);
  FUN_009cb790(uVar1,s_SetTouchpadMode_021313bc,0,CONCAT44(uVar3,uVar2),0);
  _DAT_02131238 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::VRService,void___cdecl(enum_RBX::VRService::VRTouchpad,enum_RBX::VRService::VRTouchpadMode),2>
       ::vftable;
  _DAT_02131270 = FUN_00bb1900;
  _DAT_02131274 = 0;
  DAT_02131278 = 0;
  DAT_0213127c = 0;
  uStack_8 = 2;
  FUN_00bb0820();
  FUN_016f3654(&LAB_018916c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1234 ; VA 0x004d0030 ; FUN_004d0030 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d0030(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uStack_1c0;
  int iStack_1bc;
  undefined auStack_1b8 [200];
  undefined4 uStack_f0;
  int iStack_ec;
  undefined4 auStack_e8 [50];
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd36c;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_20 = uStack_20 & 0xffffff00;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00baf370();
  FUN_009cb790(uVar1,s_GetUserCFrame_0212eee0,0,CONCAT44(uStack_1c,uStack_20),0);
  _DAT_02131078 =
       RBX::Reflection::
       BoundFuncDesc<class_RBX::VRService,class_G3D::CoordinateFrame___cdecl(enum_RBX::VRService::UserCFrame),1>
       ::vftable;
  _DAT_021310b0 = FUN_00b83710;
  _DAT_021310b4 = 0;
  DAT_021310b8 = (undefined4 *)0x0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  _DAT_0213109c = FUN_00b00260();
  puVar3 = DAT_021310b8;
  if (DAT_021310b8 == (undefined4 *)0x0) {
    uStack_1c0 = FUN_00888530();
    iStack_1bc = 0;
    puVar3 = &uStack_1c0;
    uStack_8 = 3;
    uStack_14 = 2;
  }
  else {
    uStack_f0 = FUN_00b849a0();
    iStack_ec = 0;
    auStack_e8[0] = *puVar3;
    iStack_ec = FUN_00b84b30();
    puVar3 = &uStack_f0;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uStack_14 = 1;
  }
  uVar1 = FUN_00b849a0();
  uVar2 = FUN_0086e3d0(&DAT_0212eed8);
  FUN_00888b30(uVar2,uVar1,puVar3);
  if ((uStack_14 & 2) != 0) {
    uStack_14 = uStack_14 & 0xfffffffd;
    uStack_8 = 4;
    if (iStack_1bc != 0) {
      (**(code **)(iStack_1bc + 8))(auStack_1b8);
    }
  }
  uStack_8 = 1;
  if ((uStack_14 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_ec != 0) {
      (**(code **)(iStack_ec + 8))(auStack_e8);
    }
  }
  FUN_016f3654(&LAB_01891700);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1235 ; VA 0x004d01d0 ; FUN_004d01d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d01d0(void)

{
  undefined4 uVar1;
  uint in_stack_ffffffe4;
  uint uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd38a;
  pvStack_10 = ExceptionList;
  uVar2 = in_stack_ffffffe4 & 0xffffff00;
  uVar3 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00baf370(uVar2,0);
  FUN_009cb790(uVar1,s_RecenterUserHeadCFrame_0212eec0,0,CONCAT44(uVar3,uVar2),0);
  uStack_8 = 0;
  _DAT_02131038 = RBX::Reflection::BoundFuncDesc<class_RBX::VRService,void___cdecl(void),0>::vftable
  ;
  _DAT_02131070 = &LAB_00bb15f0;
  _DAT_02131074 = 0;
  _DAT_0213105c = FUN_00888530();
  FUN_016f3654(&LAB_01891720);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1236 ; VA 0x004d0270 ; FUN_004d0270 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d0270(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd3b4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b849a0();
  uVar3 = FUN_00baf370();
  FUN_009ca670(uVar3,uVar2,s_GuiInputUserCFrame_02131338,&DAT_021197d4,uStack_24,0,0,0x13,0,0,1);
  uStack_8 = 0;
  DAT_021310f8 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::VRService,enum_RBX::VRService::UserCFrame>::vftable;
  _DAT_0213112c = uVar2;
  DAT_02131130 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02131130 == (undefined4 *)0x0) {
    DAT_02131130 = (undefined4 *)0x0;
  }
  else {
    *DAT_02131130 =
         RBX::Reflection::PropDescriptor<class_RBX::VRService,enum_RBX::VRService::UserCFrame>::
         GetSetImpl<enum_RBX::VRService::UserCFrame_(__thiscall_RBX::VRService::*)(void)const_,void_(__thiscall_RBX::VRService::*)(enum_RBX::VRService::UserCFrame)>
         ::vftable;
    DAT_02131130[2] = &LAB_00bb1420;
    DAT_02131130[3] = 0;
    DAT_02131130[4] = FUN_00bb16b0;
    DAT_02131130[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02131134 = FUN_00b849a0();
  cVar1 = (*(code *)DAT_021310f8[3])();
  if (cVar1 != '\0') {
    _DAT_0213111c = _DAT_0213111c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_021310f8[2])();
  if (cVar1 != '\0') {
    _DAT_0213111c = _DAT_0213111c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01891770);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1237 ; VA 0x004d0390 ; FUN_004d0390 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d0390(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd3dc;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00baf370();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::VRService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::VRService::*)(void)const_>
              ::vftable;
    puVar3[2] = FUN_0063b3d0;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,s_VRDeviceName_021313f0,&DAT_021197d4,uStack_24,0,0,0x13,5,5,0);
  DAT_02131300 = RBX::Reflection::
                 TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02131334 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02131324 = _DAT_02131324 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02131300[2])();
    if (cVar1 != '\0') {
      _DAT_02131324 = _DAT_02131324 & 0xfffffff3;
    }
  }
  DAT_02131300 = RBX::Reflection::
                 PropDescriptor<class_RBX::VRService,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                 ::vftable;
  FUN_016f3654(&LAB_01891790);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1238 ; VA 0x004d04b0 ; FUN_004d04b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d04b0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd40c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00baf370();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::VRService,bool>::
              GetImpl<bool_(__thiscall_RBX::VRService::*)(void)const_>::vftable;
    puVar3[2] = FUN_008b4230;
    puVar3[3] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_VREnabled_0212eeb4,&DAT_021197d4,uStack_24,0,0,0x1f,0,0,0);
  DAT_02131000 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_02131034 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_02131024 = _DAT_02131024 & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02131000[2])();
    if (cVar1 != '\0') {
      _DAT_02131024 = _DAT_02131024 & 0xfffffff3;
    }
  }
  DAT_02131000 = RBX::Reflection::PropDescriptor<class_RBX::VRService,bool>::vftable;
  FUN_016f3654(&LAB_018917b0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1239 ; VA 0x004d05d0 ; FUN_004d05d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d05d0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd73c;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00bb25e0();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::StarterPlayerService,bool>::
              GetSetImpl<bool_(__thiscall_RBX::StarterPlayerService::*)(void)const_,void_(__thiscall_RBX::StarterPlayerService::*)(bool)>
              ::vftable;
    puVar3[2] = &LAB_00bb3bc0;
    puVar3[3] = 0;
    puVar3[4] = FUN_00bb49e0;
    puVar3[5] = 0;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar2,uVar4,s_AllowCustomAnimations_02131cb8,s_Character_0211faa0,uStack_24,0,0,0x1e,
               0,5,0);
  DAT_02131578 = RBX::Reflection::TypedPropertyDescriptor<bool>::vftable;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  DAT_021315ac = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    cVar1 = FUN_005c9300();
    if (cVar1 != '\0') {
      _DAT_0213159c = _DAT_0213159c & 0xffffffeb;
    }
    cVar1 = (*(code *)DAT_02131578[2])();
    if (cVar1 != '\0') {
      _DAT_0213159c = _DAT_0213159c & 0xfffffff3;
    }
  }
  DAT_02131578 = RBX::Reflection::PropDescriptor<class_RBX::StarterPlayerService,bool>::vftable;
  FUN_016f3654(&LAB_018917e0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1240 ; VA 0x004d07f0 ; FUN_004d07f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d07f0(void)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd75a;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00bb25e0();
  FUN_00684820(uVar3,s_CharacterUseJumpPower_02131ed8,s_Character_Jump_Settings_02131ec0,0);
  uStack_8 = 0;
  DAT_021319b0 = RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20();
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::StarterPlayerService>::
              vftable;
    puVar4[1] = &DAT_021319b0;
    puVar4[2] = 0x128;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  if (DAT_021319e4 != (undefined4 *)0x0) {
    puVar1 = (undefined4 *)*DAT_021319e4;
    DAT_021319e4 = puVar4;
    (*(code *)*puVar1)();
    puVar4 = DAT_021319e4;
  }
  DAT_021319e4 = puVar4;
  cVar2 = (*(code *)DAT_021319b0[3])();
  if (cVar2 != '\0') {
    _DAT_021319d4 = _DAT_021319d4 & 0xffffffeb;
  }
  cVar2 = (*(code *)DAT_021319b0[2])();
  if (cVar2 != '\0') {
    _DAT_021319d4 = _DAT_021319d4 & 0xfffffff3;
  }
  FUN_016f3654();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1241 ; VA 0x004d0cd0 ; FUN_004d0cd0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d0cd0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd784;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00935b10();
  uVar3 = FUN_00bb25e0();
  FUN_009ca670(uVar3,uVar2,s_CameraMode_0211ff3c,s_Camera_0211ff34,uStack_24,0,0,0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02131b38 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::StarterPlayerService,enum_RBX::Camera::CameraMode>::
                 vftable;
  _DAT_02131b6c = uVar2;
  DAT_02131b70 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02131b70 == (undefined4 *)0x0) {
    DAT_02131b70 = (undefined4 *)0x0;
  }
  else {
    *DAT_02131b70 =
         RBX::Reflection::
         PropDescriptor<class_RBX::StarterPlayerService,enum_RBX::Camera::CameraMode>::
         GetSetImpl<enum_RBX::Camera::CameraMode_(__thiscall_RBX::StarterPlayerService::*)(void)const_,void_(__thiscall_RBX::StarterPlayerService::*)(enum_RBX::Camera::CameraMode)>
         ::vftable;
    DAT_02131b70[2] = FUN_00819220;
    DAT_02131b70[3] = 0;
    DAT_02131b70[4] = FUN_00bb4b30;
    DAT_02131b70[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02131b74 = FUN_00935b10();
  cVar1 = (*(code *)DAT_02131b38[3])();
  if (cVar1 != '\0') {
    _DAT_02131b5c = _DAT_02131b5c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02131b38[2])();
  if (cVar1 != '\0') {
    _DAT_02131b5c = _DAT_02131b5c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01891960);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1242 ; VA 0x004d0df0 ; FUN_004d0df0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d0df0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd7a4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00935ba0();
  uVar3 = FUN_00bb25e0();
  FUN_009ca670(uVar3,uVar2,s_DevCameraOcclusionMode_0211ffb8,s_Camera_0211ff34,uStack_24,0,0,0x1f,0,
               0,1);
  uStack_8 = 0;
  DAT_02131480 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::StarterPlayerService,enum_RBX::StarterPlayerService::DeveloperCameraOcclusionMode>
                 ::vftable;
  _DAT_021314b4 = uVar2;
  DAT_021314b8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_021314b8 == (undefined4 *)0x0) {
    DAT_021314b8 = (undefined4 *)0x0;
  }
  else {
    *DAT_021314b8 =
         RBX::Reflection::
         PropDescriptor<class_RBX::StarterPlayerService,enum_RBX::StarterPlayerService::DeveloperCameraOcclusionMode>
         ::
         GetSetImpl<enum_RBX::StarterPlayerService::DeveloperCameraOcclusionMode_(__thiscall_RBX::StarterPlayerService::*)(void)const_,void_(__thiscall_RBX::StarterPlayerService::*)(enum_RBX::StarterPlayerService::DeveloperCameraOcclusionMode)>
         ::vftable;
    DAT_021314b8[2] = &LAB_00926d90;
    DAT_021314b8[3] = 0;
    DAT_021314b8[4] = FUN_00bb4b50;
    DAT_021314b8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_021314bc = FUN_00935ba0();
  cVar1 = (*(code *)DAT_02131480[3])();
  if (cVar1 != '\0') {
    _DAT_021314a4 = _DAT_021314a4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02131480[2])();
  if (cVar1 != '\0') {
    _DAT_021314a4 = _DAT_021314a4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01891980);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1243 ; VA 0x004d0f10 ; FUN_004d0f10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d0f10(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd7c4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00935cc0();
  uVar3 = FUN_00bb25e0();
  FUN_009ca670(uVar3,uVar2,s_DevComputerMovementMode_0211fff0,s_Controls_02131c94,uStack_24,0,0,0x1f
               ,0,0,1);
  uStack_8 = 0;
  DAT_02131500 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::StarterPlayerService,enum_RBX::StarterPlayerService::DeveloperComputerMovementMode>
                 ::vftable;
  _DAT_02131534 = uVar2;
  DAT_02131538 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02131538 == (undefined4 *)0x0) {
    DAT_02131538 = (undefined4 *)0x0;
  }
  else {
    *DAT_02131538 =
         RBX::Reflection::
         PropDescriptor<class_RBX::StarterPlayerService,enum_RBX::StarterPlayerService::DeveloperComputerMovementMode>
         ::
         GetSetImpl<enum_RBX::StarterPlayerService::DeveloperComputerMovementMode_(__thiscall_RBX::StarterPlayerService::*)(void)const_,void_(__thiscall_RBX::StarterPlayerService::*)(enum_RBX::StarterPlayerService::DeveloperComputerMovementMode)>
         ::vftable;
    DAT_02131538[2] = FUN_00849fa0;
    DAT_02131538[3] = 0;
    DAT_02131538[4] = FUN_00bb4bb0;
    DAT_02131538[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213153c = FUN_00935cc0();
  cVar1 = (*(code *)DAT_02131500[3])();
  if (cVar1 != '\0') {
    _DAT_02131524 = _DAT_02131524 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02131500[2])();
  if (cVar1 != '\0') {
    _DAT_02131524 = _DAT_02131524 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018919a0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1244 ; VA 0x004d1030 ; FUN_004d1030 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d1030(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd7e4;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00935de0();
  uVar3 = FUN_00bb25e0();
  FUN_009ca670(uVar3,uVar2,s_DevTouchMovementMode_0211ffd8,s_Controls_02131c94,uStack_24,0,0,0x1f,0,
               0,1);
  uStack_8 = 0;
  DAT_021314c0 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::StarterPlayerService,enum_RBX::StarterPlayerService::DeveloperTouchMovementMode>
                 ::vftable;
  _DAT_021314f4 = uVar2;
  DAT_021314f8 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_021314f8 == (undefined4 *)0x0) {
    DAT_021314f8 = (undefined4 *)0x0;
  }
  else {
    *DAT_021314f8 =
         RBX::Reflection::
         PropDescriptor<class_RBX::StarterPlayerService,enum_RBX::StarterPlayerService::DeveloperTouchMovementMode>
         ::
         GetSetImpl<enum_RBX::StarterPlayerService::DeveloperTouchMovementMode_(__thiscall_RBX::StarterPlayerService::*)(void)const_,void_(__thiscall_RBX::StarterPlayerService::*)(enum_RBX::StarterPlayerService::DeveloperTouchMovementMode)>
         ::vftable;
    DAT_021314f8[2] = &LAB_00685250;
    DAT_021314f8[3] = 0;
    DAT_021314f8[4] = FUN_00bb4c10;
    DAT_021314f8[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_021314fc = FUN_00935de0();
  cVar1 = (*(code *)DAT_021314c0[3])();
  if (cVar1 != '\0') {
    _DAT_021314e4 = _DAT_021314e4 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_021314c0[2])();
  if (cVar1 != '\0') {
    _DAT_021314e4 = _DAT_021314e4 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_018919c0);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1245 ; VA 0x004d12d0 ; FUN_004d12d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d12d0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd804;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00935c30();
  uVar3 = FUN_00bb25e0();
  FUN_009ca670(uVar3,uVar2,s_DevComputerCameraMovementMode_02131c74,s_Camera_0211ff34,uStack_24,0,0,
               0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02131440 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::StarterPlayerService,enum_RBX::StarterPlayerService::DeveloperComputerCameraMovementMode>
                 ::vftable;
  _DAT_02131474 = uVar2;
  DAT_02131478 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02131478 == (undefined4 *)0x0) {
    DAT_02131478 = (undefined4 *)0x0;
  }
  else {
    *DAT_02131478 =
         RBX::Reflection::
         PropDescriptor<class_RBX::StarterPlayerService,enum_RBX::StarterPlayerService::DeveloperComputerCameraMovementMode>
         ::
         GetSetImpl<enum_RBX::StarterPlayerService::DeveloperComputerCameraMovementMode_(__thiscall_RBX::StarterPlayerService::*)(void)const_,void_(__thiscall_RBX::StarterPlayerService::*)(enum_RBX::StarterPlayerService::DeveloperComputerCameraMovementMode)>
         ::vftable;
    DAT_02131478[2] = FUN_006d9080;
    DAT_02131478[3] = 0;
    DAT_02131478[4] = FUN_00bb4b80;
    DAT_02131478[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213147c = FUN_00935c30();
  cVar1 = (*(code *)DAT_02131440[3])();
  if (cVar1 != '\0') {
    _DAT_02131464 = _DAT_02131464 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02131440[2])();
  if (cVar1 != '\0') {
    _DAT_02131464 = _DAT_02131464 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01891a20);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1246 ; VA 0x004d13f0 ; FUN_004d13f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d13f0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd824;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00935d50();
  uVar3 = FUN_00bb25e0();
  FUN_009ca670(uVar3,uVar2,s_DevTouchCameraMovementMode_02131c58,s_Camera_0211ff34,uStack_24,0,0,
               0x1f,0,0,1);
  uStack_8 = 0;
  DAT_02131400 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::StarterPlayerService,enum_RBX::StarterPlayerService::DeveloperTouchCameraMovementMode>
                 ::vftable;
  _DAT_02131434 = uVar2;
  DAT_02131438 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02131438 == (undefined4 *)0x0) {
    DAT_02131438 = (undefined4 *)0x0;
  }
  else {
    *DAT_02131438 =
         RBX::Reflection::
         PropDescriptor<class_RBX::StarterPlayerService,enum_RBX::StarterPlayerService::DeveloperTouchCameraMovementMode>
         ::
         GetSetImpl<enum_RBX::StarterPlayerService::DeveloperTouchCameraMovementMode_(__thiscall_RBX::StarterPlayerService::*)(void)const_,void_(__thiscall_RBX::StarterPlayerService::*)(enum_RBX::StarterPlayerService::DeveloperTouchCameraMovementMode)>
         ::vftable;
    DAT_02131438[2] = FUN_0086b740;
    DAT_02131438[3] = 0;
    DAT_02131438[4] = FUN_00bb4be0;
    DAT_02131438[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_0213143c = FUN_00935d50();
  cVar1 = (*(code *)DAT_02131400[3])();
  if (cVar1 != '\0') {
    _DAT_02131424 = _DAT_02131424 & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02131400[2])();
  if (cVar1 != '\0') {
    _DAT_02131424 = _DAT_02131424 & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01891a40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1247 ; VA 0x004d15d0 ; FUN_004d15d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d15d0(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd844;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0090bd10();
  uVar3 = FUN_00bb25e0();
  FUN_009ca670(uVar3,uVar2,s_GameSettingsAvatar_02131ce4,s_Character_0211faa0,uStack_24,0,0,0x1c,5,5
               ,1);
  uStack_8 = 0;
  DAT_021315e8 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::StarterPlayerService,enum_RBX::GameAvatarType>::
                 vftable;
  _DAT_0213161c = uVar2;
  DAT_02131620 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02131620 == (undefined4 *)0x0) {
    DAT_02131620 = (undefined4 *)0x0;
  }
  else {
    *DAT_02131620 =
         RBX::Reflection::PropDescriptor<class_RBX::StarterPlayerService,enum_RBX::GameAvatarType>::
         GetSetImpl<enum_RBX::GameAvatarType_(__thiscall_RBX::StarterPlayerService::*)(void)const_,void_(__thiscall_RBX::StarterPlayerService::*)(enum_RBX::GameAvatarType)>
         ::vftable;
    DAT_02131620[2] = FUN_0074a340;
    DAT_02131620[3] = 0;
    DAT_02131620[4] = FUN_00bb4c60;
    DAT_02131620[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02131624 = FUN_0090bd10();
  cVar1 = (*(code *)DAT_021315e8[3])();
  if (cVar1 != '\0') {
    _DAT_0213160c = _DAT_0213160c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_021315e8[2])();
  if (cVar1 != '\0') {
    _DAT_0213160c = _DAT_0213160c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01891a80);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1248 ; VA 0x004d1880 ; FUN_004d1880 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004d1880(void)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017fd864;
  pvStack_10 = ExceptionList;
  uStack_24 = uStack_24 & 0xffffff00;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0090c0c0();
  uVar3 = FUN_00bb25e0();
  FUN_009ca670(uVar3,uVar2,s_GameSettingsR15Collision_02131cf8,s_Character_0211faa0,uStack_24,0,0,
               0x1c,5,5,1);
  uStack_8 = 0;
  DAT_02131628 = RBX::Reflection::
                 EnumPropDescriptor<class_RBX::StarterPlayerService,enum_RBX::R15CollisionType>::
                 vftable;
  _DAT_0213165c = uVar2;
  DAT_02131660 = (undefined4 *)FUN_01674e20(0x18);
  if (DAT_02131660 == (undefined4 *)0x0) {
    DAT_02131660 = (undefined4 *)0x0;
  }
  else {
    *DAT_02131660 =
         RBX::Reflection::PropDescriptor<class_RBX::StarterPlayerService,enum_RBX::R15CollisionType>
         ::
         GetSetImpl<enum_RBX::R15CollisionType_(__thiscall_RBX::StarterPlayerService::*)(void)const_,void_(__thiscall_RBX::StarterPlayerService::*)(enum_RBX::R15CollisionType)>
         ::vftable;
    DAT_02131660[2] = FUN_008389e0;
    DAT_02131660[3] = 0;
    DAT_02131660[4] = FUN_00bb4d70;
    DAT_02131660[5] = 0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  _DAT_02131664 = FUN_0090c0c0();
  cVar1 = (*(code *)DAT_02131628[3])();
  if (cVar1 != '\0') {
    _DAT_0213164c = _DAT_0213164c & 0xffffffeb;
  }
  cVar1 = (*(code *)DAT_02131628[2])();
  if (cVar1 != '\0') {
    _DAT_0213164c = _DAT_0213164c & 0xfffffff3;
  }
  FUN_016f3654(&LAB_01891b40);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 1249 ; VA 0x004d28a0 ; FUN_004d28a0 */

void FUN_004d28a0(void)

{
  uint uStack_10;
  
  uStack_10 = uStack_10 & 0xffffff00;
  FUN_00bc5930(FUN_00bcb7d0,0,s_GetAsyncFullUrl_0213219c,s_apiUrl_02132194,s_priority_02121eec,
               s_httpRequestType_0211cf5c,0,0,5,uStack_10,0);
  FUN_016f3654(&LAB_01891f40);
  return;
}


