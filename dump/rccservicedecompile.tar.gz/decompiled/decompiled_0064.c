/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 16000 ; VA 0x0090e400 ; FUN_0090e400 */

int __thiscall FUN_0090e400(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c5840;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::GlobalBasicSettings*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16001 ; VA 0x0090e4d2 ; Catch_All@0090e4d2 */

void Catch_All_0090e4d2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16002 ; VA 0x0090e4f0 ; FUN_0090e4f0 */

undefined4 * FUN_0090e4f0(undefined4 *param_1)

{
  undefined uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c58c1;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0090de90();
  uVar3 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar2 + 0x1dc) != (undefined4 *)0x0) {
    uVar3 = **(undefined4 **)(iVar2 + 0x1dc);
  }
  uVar3 = FUN_01675290(uVar3);
  uStack_8 = 1;
  uStack_18 = uVar3;
  puVar4 = (undefined4 *)FUN_01674e20(0x9c);
  uStack_8._0_1_ = 2;
  puStack_1c = puVar4;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    uVar5 = FUN_0090f910(auStack_4c);
    uStack_8._0_1_ = 3;
    FUN_008a93c0();
    uStack_8._0_1_ = 4;
    *puVar4 = RBX::Described<class_RBX::Settings,class_RBX::ServiceProvider>::vftable;
    uVar6 = FUN_0090e050();
    puVar4[3] = uVar6;
    uStack_8._0_1_ = 5;
    *puVar4 = RBX::Settings::vftable;
    FUN_0054ef60(uVar5);
    *(undefined *)(puVar4 + 0x24) = 0;
    uStack_8._0_1_ = 6;
    *puVar4 = RBX::Described<class_RBX::GlobalAdvancedSettings,class_RBX::Settings>::vftable;
    uVar5 = FUN_0090de90();
    puVar4[3] = uVar5;
    uStack_8._0_1_ = 8;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < uStack_38) {
      uVar8 = uStack_38 + 1;
      uVar7 = auStack_4c[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_4c[0] - 4);
        uVar8 = uStack_38 + 0x24;
        if (0x1f < (auStack_4c[0] - uVar7) - 4) {
          uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    *puVar4 = RBX::GlobalAdvancedSettings::vftable;
    uStack_3c = 0;
    uStack_38 = 0xf;
    auStack_4c[0] = auStack_4c[0] & 0xffffff00;
    puVar4[0x25] = 0;
    puVar4[0x26] = 0;
    uStack_8._0_1_ = 9;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("Global Settings",0xf);
    uStack_8._0_1_ = 10;
    FUN_008a6520(auStack_34);
    uStack_8._0_1_ = 9;
    if (0xf < uStack_20) {
      uVar8 = uStack_20 + 1;
      uVar7 = auStack_34[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_34[0] - 4);
        uVar8 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0090e310(puVar4,puStack_1c);
  uStack_14 = 1;
  uStack_8 = 0xe;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16003 ; VA 0x0090e6e0 ; FUN_0090e6e0 */

undefined4 * FUN_0090e6e0(undefined4 *param_1)

{
  undefined uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c594f;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0090df70();
  uVar3 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar2 + 0x1dc) != (undefined4 *)0x0) {
    uVar3 = **(undefined4 **)(iVar2 + 0x1dc);
  }
  uVar3 = FUN_01675290(uVar3);
  uStack_8 = 1;
  uStack_18 = uVar3;
  puVar4 = (undefined4 *)FUN_01674e20(0xb4);
  uStack_8._0_1_ = 2;
  puStack_1c = puVar4;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    uVar5 = FUN_0090fb40(auStack_4c);
    uStack_8._0_1_ = 3;
    FUN_008a93c0();
    uStack_8._0_1_ = 4;
    *puVar4 = RBX::Described<class_RBX::Settings,class_RBX::ServiceProvider>::vftable;
    uVar6 = FUN_0090e050();
    puVar4[3] = uVar6;
    uStack_8._0_1_ = 5;
    *puVar4 = RBX::Settings::vftable;
    FUN_0054ef60(uVar5);
    *(undefined *)(puVar4 + 0x24) = 0;
    uStack_8._0_1_ = 6;
    *puVar4 = RBX::Described<class_RBX::GlobalBasicSettings,class_RBX::Settings>::vftable;
    uVar5 = FUN_0090df70();
    puVar4[3] = uVar5;
    uStack_8._0_1_ = 8;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 8;
    if (0xf < uStack_38) {
      uVar8 = uStack_38 + 1;
      uVar7 = auStack_4c[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_4c[0] - 4);
        uVar8 = uStack_38 + 0x24;
        if (0x1f < (auStack_4c[0] - uVar7) - 4) {
          uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    *puVar4 = RBX::GlobalBasicSettings::vftable;
    puVar4[0x29] = 0;
    puVar4[0x2a] = 0xf;
    uStack_3c = 0;
    uStack_38 = 0xf;
    auStack_4c[0] = auStack_4c[0] & 0xffffff00;
    *(undefined *)(puVar4 + 0x25) = 0;
    puVar4[0x2b] = 0;
    puVar4[0x2c] = 0;
    uStack_8._0_1_ = 10;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_005542c0("GlobalBasicSettings",0x13);
    uStack_8._0_1_ = 0xb;
    FUN_008a6520(auStack_34);
    uStack_8._0_1_ = 10;
    if (0xf < uStack_20) {
      uVar8 = uStack_20 + 1;
      uVar7 = auStack_34[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_34[0] - 4);
        uVar8 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_0090e400(puVar4,puStack_1c);
  uStack_14 = 1;
  uStack_8 = 0xf;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16004 ; VA 0x0090e8f0 ; FUN_0090e8f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall
FUN_0090e8f0(byte *param_1,int *param_2,uint *param_3,undefined4 *param_4,int *param_5)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  byte *pbVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar5 = (int)param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5968;
  pvStack_10 = ExceptionList;
  pbVar10 = param_1 + *param_1 + 1;
  ExceptionList = &pvStack_10;
  uVar6 = FUN_0055c740(pbVar10,param_3);
  FUN_00562fc0(&param_3,uVar6,iVar5,-(uint)(pbVar10 != (byte *)0x0) & (uint)(pbVar10 + 1));
  if (param_3 != (uint *)0x0) {
    *param_2 = (int)param_3;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
  uStack_8 = 0;
  FUN_00619cd0();
  _DAT_00000008 = *param_4;
  _DAT_0000000c = param_4[1];
  _DAT_00000010 = param_4[2];
  _DAT_00000014 = param_4[3];
  _DAT_00000018 = *(undefined8 *)(param_4 + 4);
  param_4[4] = 0;
  param_4[5] = 0xf;
  *(undefined *)param_4 = 0;
  _DAT_00000020 = *param_5;
  LOCK();
  *(int *)(_DAT_00000020 + 0x28) = *(int *)(_DAT_00000020 + 0x28) + 1;
  UNLOCK();
  uVar3 = *(uint *)(param_1 + 8);
  uVar7 = uVar3 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar7 = FUN_005c9310(uVar7);
    if (uVar7 <= *(uint *)(param_1 + 4)) {
      uVar7 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar7);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar7) {
    param_3 = (uint *)0x1;
    uVar8 = uVar3 >> 1;
    if (uVar3 + (uVar3 >> 1) <= uVar7) {
      uVar8 = 1;
    }
    uVar7 = FUN_005c9310(uVar8 + *(int *)(param_1 + 8));
    param_3 = (uint *)(param_1 + 4);
    if (uVar7 != *param_3) {
      FUN_005d2b00(uVar7);
      puVar9 = (undefined4 *)(*(int *)(param_1 + 0x14) + *param_3 * 4);
      puVar4 = (undefined4 *)*puVar9;
      while (puVar4 != (undefined4 *)0x0) {
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *param_3) * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *param_3) * 4) == 0) {
          *piVar1 = (int)puVar9;
          puVar9 = puVar4;
        }
        else {
          *puVar9 = *puVar4;
          *puVar4 = *(undefined4 *)*piVar1;
          *(undefined4 **)*piVar1 = puVar4;
        }
        puVar4 = (undefined4 *)*puVar9;
      }
    }
  }
  uVar7 = *(uint *)(param_1 + 4);
  piVar1 = (int *)(*(int *)(param_1 + 0x14) + (uVar6 % uVar7) * 4);
  _DAT_00000004 = uVar6;
  if ((int *)*piVar1 == (int *)0x0) {
    piVar2 = (int *)(*(int *)(param_1 + 0x14) + uVar7 * 4);
    if (*piVar2 != 0) {
      *(undefined4 *)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar2 + 4) % uVar7) * 4) = 0;
    }
    *piVar1 = (int)piVar2;
    _DAT_00000000 = *piVar2;
    *piVar2 = 0;
  }
  else {
    _DAT_00000000 = *(int *)*piVar1;
    *(undefined4 *)*piVar1 = 0;
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = 0;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16005 ; VA 0x0090eaf0 ; FUN_0090eaf0 */

uint FUN_0090eaf0(undefined4 *param_1,char *param_2,uint param_3)

{
  undefined uVar1;
  int *piVar2;
  char *pcVar3;
  char cVar4;
  char cVar5;
  int *piVar6;
  undefined4 *puVar7;
  char *pcVar8;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined4 *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c5988;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piVar2 = *(int **)(param_3 + 4);
  ExceptionList = &pvStack_10;
  piStack_1c = piVar2;
  (**(code **)(*piVar2 + 4))();
  uStack_8 = 1;
  puStack_18 = param_1;
  if (0xf < (uint)param_1[5]) {
    puStack_18 = (undefined4 *)*param_1;
  }
  puStack_18 = (undefined4 *)(param_1[4] + (int)puStack_18);
  pcVar3 = param_2;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  do {
    pcVar8 = pcVar3;
    pcVar3 = pcVar8 + 1;
  } while (*pcVar8 != '\0');
  if (param_1 != puStack_18) {
    do {
      if (param_2 == pcVar8) goto LAB_0090ec02;
      uVar1 = *(undefined *)param_1;
      piVar6 = (int *)FUN_0054e7d0(auStack_20);
      cVar4 = (**(code **)(*piVar6 + 0x18))(uVar1);
      uStack_14 = CONCAT31(uStack_14._1_3_,*param_2);
      piVar6 = (int *)FUN_0054e7d0(auStack_20);
      cVar5 = (**(code **)(*piVar6 + 0x18))(uStack_14);
      if (cVar4 != cVar5) {
        uStack_8 = 2;
        if ((piVar2 != (int *)0x0) &&
           (puVar7 = (undefined4 *)(**(code **)(*piVar2 + 8))(), puVar7 != (undefined4 *)0x0)) {
          (**(code **)*puVar7)(1);
        }
        ExceptionList = pvStack_10;
        return 0;
      }
      param_1 = (undefined4 *)((int)param_1 + 1);
      param_2 = param_2 + 1;
    } while (param_1 != puStack_18);
  }
  if (param_2 == pcVar8) {
LAB_0090ec02:
    param_3 = 0x1000000;
    if (param_1 == puStack_18) goto LAB_0090ec0e;
  }
  param_3 = 0;
LAB_0090ec0e:
  uStack_8 = 3;
  if ((piVar2 != (int *)0x0) &&
     (puVar7 = (undefined4 *)(**(code **)(*piVar2 + 8))(), puVar7 != (undefined4 *)0x0)) {
    (**(code **)*puVar7)(1);
  }
  ExceptionList = pvStack_10;
  return param_3 >> 0x18;
}



/* FUNCTION 16006 ; VA 0x0090ec40 ; FUN_0090ec40 */

void * __thiscall FUN_0090ec40(int param_1,byte *param_2)

{
  undefined4 *puVar1;
  int iVar2;
  byte bVar3;
  void *pvVar4;
  int *piVar5;
  int *piVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017c59b0;
  puVar7 = *(undefined4 **)(param_1 + 0x2c);
  pvVar4 = ExceptionList;
  if (puVar7 != (undefined4 *)0x0) {
    piVar5 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar5 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
      piVar5 = *(int **)(param_1 + 0x30);
      puVar7 = *(undefined4 **)(param_1 + 0x2c);
    }
    puVar1 = (undefined4 *)puVar7[1];
    puVar7 = (undefined4 *)*puVar7;
    iStack_8 = 0;
    pvVar4 = pvStack_10;
    for (; puVar7 != puVar1; puVar7 = puVar7 + 2) {
      piVar6 = (int *)puVar7[1];
      if (piVar6 != (int *)0x0) {
        LOCK();
        piVar6[1] = piVar6[1] + 1;
        UNLOCK();
        piVar6 = (int *)puVar7[1];
      }
      iStack_8._1_3_ = (uint3)((uint)iStack_8 >> 8);
      iStack_8._0_1_ = 1;
      bVar3 = (**(code **)(**(int **)(param_2 + 4) + 0xa4))(*puVar7);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      *param_2 = *param_2 | bVar3;
      if (piVar6 != (int *)0x0) {
        LOCK();
        iVar2 = piVar6[1] + -1;
        piVar6[1] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)*piVar6)();
          LOCK();
          iVar2 = piVar6[2] + -1;
          piVar6[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
      pvVar4 = (void *)FUN_0090ec40(param_2);
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar6 = piVar5 + 1;
      iVar2 = *piVar6;
      pvVar4 = (void *)*piVar6;
      *piVar6 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)*piVar5)();
        LOCK();
        piVar6 = piVar5 + 2;
        iVar2 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar4 = (void *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 16007 ; VA 0x0090ed40 ; FUN_0090ed40 */

undefined4 * __thiscall FUN_0090ed40(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c59d0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008a93c0();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::Settings,class_RBX::ServiceProvider>::vftable;
  uVar1 = FUN_0090e050();
  param_1[3] = uVar1;
  uStack_8 = 1;
  *param_1 = RBX::Settings::vftable;
  FUN_0054ef60(param_2);
  *(undefined *)(param_1 + 0x24) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16008 ; VA 0x0090edb0 ; thunk_FUN_0090ee50 */

void __fastcall thunk_FUN_0090ee50(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x8c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x78);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x88) = 0;
  *(undefined4 *)(param_1 + 0x8c) = 0xf;
  *(undefined *)(param_1 + 0x78) = 0;
  FUN_008a9470();
  return;
}



/* FUNCTION 16009 ; VA 0x0090edc0 ; FUN_0090edc0 */

void __fastcall FUN_0090edc0(int *param_1)

{
  if (*param_1 != 0) {
    FUN_00882a40(1);
  }
  return;
}



/* FUNCTION 16010 ; VA 0x0090edd0 ; FUN_0090edd0 */

void __fastcall FUN_0090edd0(int *param_1)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  if (*param_1 != 0) {
    FUN_0075c360(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar3 = param_1[2] - iVar1 & 0xfffffff0;
    iVar2 = iVar1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(iVar1 + -4);
      uVar3 = uVar3 + 0x23;
      if (0x1f < (iVar1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 16011 ; VA 0x0090ee30 ; FUN_0090ee30 */

void __fastcall FUN_0090ee30(undefined4 *param_1)

{
  FUN_0090edd0();
  FUN_00611f60();
  *param_1 = RBX::IReferenceBinder::vftable;
  return;
}



/* FUNCTION 16012 ; VA 0x0090ee50 ; FUN_0090ee50 */

void __fastcall FUN_0090ee50(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x8c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x78);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x88) = 0;
  *(undefined4 *)(param_1 + 0x8c) = 0xf;
  *(undefined *)(param_1 + 0x78) = 0;
  FUN_008a9470();
  return;
}



/* FUNCTION 16013 ; VA 0x0090eeb0 ; thunk_FUN_0090eec0 */

void __fastcall thunk_FUN_0090eec0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)(param_1 + 0x20);
  ExceptionList = &pvStack_10;
  if (iVar3 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 0x14) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 0x10) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 0x10) * 4);
      ExceptionList = &pvStack_10;
      do {
        *puVar1 = *puVar6;
        FUN_005f53f0(-(uint)(param_1 != -0xf) & param_1 + 0x10U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x28);
        *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x20);
    }
    iVar2 = *(int *)(param_1 + 0x10) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x20) = 0;
    *(undefined4 *)(param_1 + 0x1c) = 0;
  }
  iVar3 = *(int *)(param_1 + 4);
  uStack_8 = 0;
  FUN_00882a90(*(undefined4 *)(iVar3 + 4));
  *(int *)(*(int *)(param_1 + 4) + 4) = iVar3;
  **(int **)(param_1 + 4) = iVar3;
  *(int *)(*(int *)(param_1 + 4) + 8) = iVar3;
  *(undefined4 *)(param_1 + 8) = 0;
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x1c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16014 ; VA 0x0090eec0 ; FUN_0090eec0 */

void __fastcall FUN_0090eec0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)(param_1 + 0x20);
  ExceptionList = &pvStack_10;
  if (iVar3 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 0x14) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 0x10) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 0x10) * 4);
      ExceptionList = &pvStack_10;
      do {
        *puVar1 = *puVar6;
        FUN_005f53f0(-(uint)(param_1 != -0xf) & param_1 + 0x10U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x28);
        *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x20);
    }
    iVar2 = *(int *)(param_1 + 0x10) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x20) = 0;
    *(undefined4 *)(param_1 + 0x1c) = 0;
  }
  iVar3 = *(int *)(param_1 + 4);
  uStack_8 = 0;
  FUN_00882a90(*(undefined4 *)(iVar3 + 4));
  *(int *)(*(int *)(param_1 + 4) + 4) = iVar3;
  **(int **)(param_1 + 4) = iVar3;
  *(int *)(*(int *)(param_1 + 4) + 8) = iVar3;
  *(undefined4 *)(param_1 + 8) = 0;
  FUN_01674ea0(*(undefined4 *)(param_1 + 4),0x1c);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16015 ; VA 0x0090efc0 ; FUN_0090efc0 */

undefined4 __thiscall FUN_0090efc0(undefined4 param_1,byte param_2)

{
  FUN_0090ee50();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x94);
  }
  return param_1;
}



/* FUNCTION 16016 ; VA 0x0090eff0 ; FUN_0090eff0 */

undefined4 * __thiscall FUN_0090eff0(undefined4 *param_1,byte param_2)

{
  int iVar1;
  
  *param_1 = RBX::GlobalAdvancedSettings::vftable;
  LOCK();
  iVar1 = param_1[0x26];
  param_1[0x26] = 0;
  UNLOCK();
  if (iVar1 != 0) {
    CloseHandle(iVar1);
  }
  FUN_0090ee50();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x9c);
  }
  return param_1;
}



/* FUNCTION 16017 ; VA 0x0090f040 ; FUN_0090f040 */

undefined4 * __thiscall FUN_0090f040(undefined4 *param_1,byte param_2)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = RBX::GlobalBasicSettings::vftable;
  LOCK();
  iVar1 = param_1[0x2c];
  param_1[0x2c] = 0;
  UNLOCK();
  if (iVar1 != 0) {
    CloseHandle(iVar1);
  }
  uVar2 = param_1[0x2a];
  if (0xf < uVar2) {
    iVar1 = param_1[0x25];
    uVar4 = uVar2 + 1;
    iVar3 = iVar1;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar4 = uVar2 + 0x24;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x29] = 0;
  param_1[0x2a] = 0xf;
  *(undefined *)(param_1 + 0x25) = 0;
  FUN_0090ee50();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xb4);
  }
  return param_1;
}



/* FUNCTION 16018 ; VA 0x0090f0e0 ; FUN_0090f0e0 */

undefined4 * __thiscall FUN_0090f0e0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::IReferenceBinder::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 16019 ; VA 0x0090f110 ; FUN_0090f110 */

undefined4 * __thiscall FUN_0090f110(undefined4 *param_1,byte param_2)

{
  FUN_0090edd0();
  FUN_00611f60();
  *param_1 = RBX::IReferenceBinder::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 16020 ; VA 0x0090f1e0 ; FUN_0090f1e0 */

int * __thiscall FUN_0090f1e0(undefined4 param_1,int *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (param_2 != param_3) {
    iVar2 = (int)param_4 - (int)param_2;
    piVar3 = param_2 + 3;
    do {
      *param_4 = piVar3[-3];
      param_4[1] = piVar3[-2];
      param_4[2] = 0;
      *(undefined4 *)(iVar2 + (int)piVar3) = 0;
      if (*piVar3 != 0) {
        LOCK();
        piVar1 = (int *)(*piVar3 + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      param_4[2] = piVar3[-1];
      param_4 = param_4 + 4;
      *(int *)(iVar2 + (int)piVar3) = *piVar3;
      piVar1 = piVar3 + 1;
      piVar3 = piVar3 + 4;
    } while (piVar1 != param_3);
  }
  FUN_0075c360(param_4,param_4,param_1);
  return param_4;
}



/* FUNCTION 16021 ; VA 0x0090f250 ; FUN_0090f250 */

void __fastcall FUN_0090f250(int *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0090f256. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x18))();
  return;
}



/* FUNCTION 16022 ; VA 0x0090f260 ; FUN_0090f260 */

undefined4 __fastcall FUN_0090f260(undefined4 param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5b3b;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee10a8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee10a8,param_1);
    if (DAT_01ee10a8 == -1) {
      uStack_8 = 0;
      iVar1 = FUN_01674e20(8);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (iVar1 == 0) {
        DAT_01ee10a4 = 0;
      }
      else {
        DAT_01ee10a4 = FUN_0090e4f0(iVar1,iVar1);
      }
      FUN_016f37bf(&DAT_01ee10a8);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee10a4;
}



/* FUNCTION 16023 ; VA 0x0090f300 ; FUN_0090f300 */

undefined4 __fastcall FUN_0090f300(undefined4 param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5b6b;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee10b8) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee10b8,param_1);
    if (DAT_01ee10b8 == -1) {
      uStack_8 = 0;
      iVar1 = FUN_01674e20(8);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (iVar1 == 0) {
        DAT_01ee10b4 = 0;
      }
      else {
        DAT_01ee10b4 = FUN_0090e6e0(iVar1,iVar1);
      }
      FUN_016f37bf(&DAT_01ee10b8);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee10b4;
}



/* FUNCTION 16024 ; VA 0x0090f3a0 ; FUN_0090f3a0 */

undefined4 __thiscall FUN_0090f3a0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int aiStack_40 [5];
  uint uStack_2c;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179ee70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_3);
  uVar3 = FUN_009d09d0(aiStack_40,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_8 = 0;
  FUN_0054ef60(uVar3);
  uVar3 = (*pcVar1)(aiStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  uVar3 = FUN_009d5710(param_3,uVar3);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    iVar2 = aiStack_40[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_40[0] + -4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 16025 ; VA 0x0090f4a0 ; FUN_0090f4a0 */

undefined4 __thiscall FUN_0090f4a0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_01256300(param_3);
  uVar3 = FUN_009d09d0(aiStack_28,param_3,param_4,1,iVar2 - param_4,param_1 + 0x40);
  pcVar1 = *(code **)(param_1 + 0x38);
  uStack_8 = 0;
  FUN_0054ef60(uVar3);
  uVar3 = (*pcVar1)();
  uVar3 = FUN_009d5ac0(param_3,uVar3);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar3;
}



/* FUNCTION 16026 ; VA 0x0090f560 ; FUN_0090f560 */

void FUN_0090f560(void)

{
  int iVar1;
  
  if (DAT_01ee14ec == 0) {
    iVar1 = FUN_0090de90();
    DAT_01ee14ec = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 16027 ; VA 0x0090f580 ; FUN_0090f580 */

void FUN_0090f580(void)

{
  int iVar1;
  
  if (DAT_01ee1704 == 0) {
    iVar1 = FUN_0090df70();
    DAT_01ee1704 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 16028 ; VA 0x0090f5a0 ; FUN_0090f5a0 */

void FUN_0090f5a0(void)

{
  int iVar1;
  
  if (DAT_01ee12d4 == 0) {
    iVar1 = FUN_0090e050();
    DAT_01ee12d4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 16029 ; VA 0x0090f5c0 ; FUN_0090f5c0 */

undefined FUN_0090f5c0(char *param_1)

{
  char cVar1;
  undefined uVar2;
  int *piVar3;
  undefined4 *puVar4;
  char *pcVar5;
  char *pcVar6;
  uint uVar7;
  uint uVar8;
  uint in_stack_00000018;
  uint auStack_48 [4];
  undefined4 uStack_38;
  uint uStack_34;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017c5ba0;
  pvStack_10 = ExceptionList;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  uStack_8 = 1;
  uStack_7 = 0;
  pcVar6 = (char *)&param_1;
  if (0xf < in_stack_00000018) {
    pcVar6 = param_1;
  }
  uStack_38 = 0;
  uStack_34 = 0xf;
  auStack_48[0] = auStack_48[0] & 0xffffff00;
  pcVar5 = pcVar6;
  do {
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(pcVar6,(int)pcVar5 - (int)(pcVar6 + 1));
  uStack_8 = 2;
  cVar1 = FUN_016779b0(auStack_48,auStack_30,0);
  uStack_8 = 1;
  uVar2 = uStack_8;
  uStack_8 = 1;
  if (0xf < uStack_34) {
    uVar7 = uStack_34 + 1;
    uVar8 = auStack_48[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_48[0] - 4);
      uVar7 = uStack_34 + 0x24;
      if (0x1f < (auStack_48[0] - uVar8) - 4) goto LAB_0090f760;
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  if (cVar1 != '\0') {
    uStack_8 = 3;
    piVar3 = (int *)FUN_016de181(1);
    uStack_8 = 4;
    piStack_14 = piVar3;
    uVar2 = FUN_0090eaf0(auStack_30,&DAT_018bdf50,auStack_18);
    _uStack_8 = CONCAT31(uStack_7,5);
    if (piVar3 != (int *)0x0) {
      puVar4 = (undefined4 *)(**(code **)(*piVar3 + 8))();
      if (puVar4 != (undefined4 *)0x0) {
        (**(code **)*puVar4)(1);
      }
    }
    if (0xf < uStack_1c) {
      uVar7 = uStack_1c + 1;
      uVar8 = auStack_30[0];
      if (0xfff < uVar7) {
        uVar8 = *(uint *)(auStack_30[0] - 4);
        uVar7 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar7);
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    if (0xf < in_stack_00000018) {
      uVar8 = in_stack_00000018 + 1;
      pcVar6 = param_1;
      if (0xfff < uVar8) {
        pcVar6 = *(char **)(param_1 + -4);
        uVar8 = in_stack_00000018 + 0x24;
        if ((char *)0x1f < param_1 + (-4 - (int)pcVar6)) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pcVar6,uVar8);
    }
    ExceptionList = pvStack_10;
    return uVar2;
  }
  FUN_00910e70(&param_1);
  uVar2 = uStack_8;
LAB_0090f760:
  uStack_8 = uVar2;
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 16030 ; VA 0x0090f770 ; FUN_0090f770 */

undefined * FUN_0090f770(undefined *param_1,char *param_2)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  uint uVar4;
  uint uVar5;
  uint in_stack_0000001c;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c5bd9;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  uStack_14 = 1;
  pcVar3 = (char *)&param_2;
  if (0xf < in_stack_0000001c) {
    pcVar3 = param_2;
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  pcVar2 = pcVar3;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(pcVar3,(int)pcVar2 - (int)(pcVar3 + 1));
  uStack_8._0_1_ = 2;
  cVar1 = FUN_016779b0(auStack_2c,param_1,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    uVar5 = auStack_2c[0];
    if (0xfff < uVar4) {
      uVar5 = *(uint *)(auStack_2c[0] - 4);
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar5) - 4) goto LAB_0090f887;
    }
    FUN_01674ea0(uVar5,uVar4);
  }
  if (cVar1 != '\0') {
    if (0xf < in_stack_0000001c) {
      uVar5 = in_stack_0000001c + 1;
      pcVar3 = param_2;
      if (0xfff < uVar5) {
        pcVar3 = *(char **)(param_2 + -4);
        uVar5 = in_stack_0000001c + 0x24;
        if ((char *)0x1f < param_2 + (-4 - (int)pcVar3)) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pcVar3,uVar5);
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_00910e70(&param_2);
LAB_0090f887:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 16031 ; VA 0x0090f8a0 ; FUN_0090f8a0 */

undefined4 __thiscall FUN_0090f8a0(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar3 = param_1 + 5 + (uint)*(byte *)(param_1 + 4);
  uVar2 = FUN_0055c740(iVar3,param_2);
  FUN_00562fc0(&param_2,uVar2,param_2,-(uint)(iVar3 != 0) & iVar3 + 1U);
  if (param_2 == 0) {
    return 0;
  }
  iVar3 = *(int *)(param_2 + 0x20);
  LOCK();
  piVar1 = (int *)(iVar3 + 0x28);
  *piVar1 = *piVar1 + 1;
  UNLOCK();
  param_2 = *param_3;
  *param_3 = iVar3;
  FUN_0056cd30();
  return 1;
}



/* FUNCTION 16032 ; VA 0x0090f910 ; FUN_0090f910 */

undefined * FUN_0090f910(undefined *param_1)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *****pppppuVar3;
  undefined4 ****ppppuVar4;
  uint uVar5;
  undefined4 *****pppppuVar6;
  int iVar7;
  undefined4 ****appppuStack_44 [4];
  int iStack_34;
  uint uStack_30;
  undefined4 ****appppuStack_2c [4];
  int iStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5c32;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_01518d10(appppuStack_2c,1,0,0);
  uStack_8 = 1;
  iStack_34 = 0;
  uStack_30 = 0xf;
  appppuStack_44[0] = (undefined4 ****)((uint)appppuStack_44[0] & 0xffffff00);
  uStack_14 = 2;
  if (iStack_1c != 0) {
    pppppuVar3 = appppuStack_2c;
    if (7 < uStack_18) {
      pppppuVar3 = (undefined4 *****)appppuStack_2c[0];
    }
    iVar2 = iStack_1c * 2;
    pppppuVar6 = appppuStack_2c;
    if (7 < uStack_18) {
      pppppuVar6 = (undefined4 *****)appppuStack_2c[0];
    }
    uVar1 = FUN_01686580();
    FUN_01685a20(pppppuVar6,(int)pppppuVar3 + iVar2,appppuStack_44,uVar1);
  }
  iVar2 = iStack_34;
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_30) {
    uVar5 = uStack_30 + 1;
    ppppuVar4 = appppuStack_44[0];
    if (0xfff < uVar5) {
      ppppuVar4 = (undefined4 ****)appppuStack_44[0][-1];
      uVar5 = uStack_30 + 0x24;
      if (0x1f < (uint)((int)appppuStack_44[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar4,uVar5);
  }
  if (iVar2 != 0) {
    iVar2 = FUN_01687bc0();
    iStack_34 = 0;
    uStack_30 = 0xf;
    appppuStack_44[0] = (undefined4 ****)((uint)appppuStack_44[0] & 0xffffff00);
    FUN_005542c0("GlobalSettings_13.xml",0x15);
    uStack_8._0_1_ = 2;
    if (iStack_34 != 0) {
      pppppuVar3 = appppuStack_44;
      if (0xf < uStack_30) {
        pppppuVar3 = (undefined4 *****)appppuStack_44[0];
      }
      iVar7 = (int)pppppuVar3 + iStack_34;
      pppppuVar3 = appppuStack_44;
      if (0xf < uStack_30) {
        pppppuVar3 = (undefined4 *****)appppuStack_44[0];
      }
      uVar1 = FUN_01686580();
      FUN_01685950(pppppuVar3,iVar7,appppuStack_2c,uVar1);
    }
    uStack_8 = (uint)uStack_8._1_3_ << 8;
    if (0xf < uStack_30) {
      uVar5 = uStack_30 + 1;
      pppppuVar3 = (undefined4 *****)appppuStack_44[0];
      if (0xfff < uVar5) {
        pppppuVar3 = (undefined4 *****)appppuStack_44[0][-1];
        uVar5 = uStack_30 + 0x24;
        if (0x1f < (uint)((int)appppuStack_44[0] + (-4 - (int)pppppuVar3))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar3,uVar5);
    }
    iStack_34 = 0;
    uStack_30 = 0xf;
    appppuStack_44[0] = (undefined4 ****)((uint)appppuStack_44[0] & 0xffffff00);
    if (iVar2 != 0) {
      FUN_01687c10(iVar2);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_14 = 4;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  if (iStack_1c != 0) {
    pppppuVar3 = appppuStack_2c;
    if (7 < uStack_18) {
      pppppuVar3 = (undefined4 *****)appppuStack_2c[0];
    }
    pppppuVar6 = appppuStack_2c;
    if (7 < uStack_18) {
      pppppuVar6 = (undefined4 *****)appppuStack_2c[0];
    }
    uVar1 = FUN_01686580();
    FUN_01685a20(pppppuVar6,(int)pppppuVar3 + iStack_1c * 2,param_1,uVar1);
  }
  if (7 < uStack_18) {
    uVar5 = uStack_18 * 2 + 2;
    pppppuVar3 = (undefined4 *****)appppuStack_2c[0];
    if (0xfff < uVar5) {
      pppppuVar3 = (undefined4 *****)appppuStack_2c[0][-1];
      uVar5 = uStack_18 * 2 + 0x25;
      if (0x1f < (uint)((int)appppuStack_2c[0] + (-4 - (int)pppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16033 ; VA 0x0090fb40 ; FUN_0090fb40 */

undefined * FUN_0090fb40(undefined *param_1)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *****pppppuVar3;
  undefined4 ****ppppuVar4;
  uint uVar5;
  undefined4 *****pppppuVar6;
  int iVar7;
  undefined4 ****appppuStack_44 [4];
  int iStack_34;
  uint uStack_30;
  undefined4 ****appppuStack_2c [4];
  int iStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5c32;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  FUN_01518d10(appppuStack_2c,1,0,0);
  uStack_8 = 1;
  iStack_34 = 0;
  uStack_30 = 0xf;
  appppuStack_44[0] = (undefined4 ****)((uint)appppuStack_44[0] & 0xffffff00);
  uStack_14 = 2;
  if (iStack_1c != 0) {
    pppppuVar3 = appppuStack_2c;
    if (7 < uStack_18) {
      pppppuVar3 = (undefined4 *****)appppuStack_2c[0];
    }
    iVar2 = iStack_1c * 2;
    pppppuVar6 = appppuStack_2c;
    if (7 < uStack_18) {
      pppppuVar6 = (undefined4 *****)appppuStack_2c[0];
    }
    uVar1 = FUN_01686580();
    FUN_01685a20(pppppuVar6,(int)pppppuVar3 + iVar2,appppuStack_44,uVar1);
  }
  iVar2 = iStack_34;
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_30) {
    uVar5 = uStack_30 + 1;
    ppppuVar4 = appppuStack_44[0];
    if (0xfff < uVar5) {
      ppppuVar4 = (undefined4 ****)appppuStack_44[0][-1];
      uVar5 = uStack_30 + 0x24;
      if (0x1f < (uint)((int)appppuStack_44[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar4,uVar5);
  }
  if (iVar2 != 0) {
    iVar2 = FUN_01687bc0();
    iStack_34 = 0;
    uStack_30 = 0xf;
    appppuStack_44[0] = (undefined4 ****)((uint)appppuStack_44[0] & 0xffffff00);
    FUN_005542c0("GlobalBasicSettings_13.xml",0x1a);
    uStack_8._0_1_ = 2;
    if (iStack_34 != 0) {
      pppppuVar3 = appppuStack_44;
      if (0xf < uStack_30) {
        pppppuVar3 = (undefined4 *****)appppuStack_44[0];
      }
      iVar7 = (int)pppppuVar3 + iStack_34;
      pppppuVar3 = appppuStack_44;
      if (0xf < uStack_30) {
        pppppuVar3 = (undefined4 *****)appppuStack_44[0];
      }
      uVar1 = FUN_01686580();
      FUN_01685950(pppppuVar3,iVar7,appppuStack_2c,uVar1);
    }
    uStack_8 = (uint)uStack_8._1_3_ << 8;
    if (0xf < uStack_30) {
      uVar5 = uStack_30 + 1;
      pppppuVar3 = (undefined4 *****)appppuStack_44[0];
      if (0xfff < uVar5) {
        pppppuVar3 = (undefined4 *****)appppuStack_44[0][-1];
        uVar5 = uStack_30 + 0x24;
        if (0x1f < (uint)((int)appppuStack_44[0] + (-4 - (int)pppppuVar3))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppuVar3,uVar5);
    }
    iStack_34 = 0;
    uStack_30 = 0xf;
    appppuStack_44[0] = (undefined4 ****)((uint)appppuStack_44[0] & 0xffffff00);
    if (iVar2 != 0) {
      FUN_01687c10(iVar2);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_14 = 4;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  if (iStack_1c != 0) {
    pppppuVar3 = appppuStack_2c;
    if (7 < uStack_18) {
      pppppuVar3 = (undefined4 *****)appppuStack_2c[0];
    }
    pppppuVar6 = appppuStack_2c;
    if (7 < uStack_18) {
      pppppuVar6 = (undefined4 *****)appppuStack_2c[0];
    }
    uVar1 = FUN_01686580();
    FUN_01685a20(pppppuVar6,(int)pppppuVar3 + iStack_1c * 2,param_1,uVar1);
  }
  if (7 < uStack_18) {
    uVar5 = uStack_18 * 2 + 2;
    pppppuVar3 = (undefined4 *****)appppuStack_2c[0];
    if (0xfff < uVar5) {
      pppppuVar3 = (undefined4 *****)appppuStack_2c[0][-1];
      uVar5 = uStack_18 * 2 + 0x25;
      if (0x1f < (uint)((int)appppuStack_2c[0] + (-4 - (int)pppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16034 ; VA 0x0090fd90 ; FUN_0090fd90 */

uint FUN_0090fd90(undefined4 param_1)

{
  uint uVar1;
  
  uVar1 = FUN_0170d75d(param_1,0,&RBX::Instance::RTTI_Type_Descriptor,
                       &RBX::GlobalBasicSettings::Item::RTTI_Type_Descriptor,0);
  if (uVar1 == 0) {
    uVar1 = FUN_0170d75d(param_1,0,&RBX::Instance::RTTI_Type_Descriptor,
                         &RBX::GlobalAdvancedSettings::Item::RTTI_Type_Descriptor,0);
    if (uVar1 == 0) {
      uVar1 = FUN_0170d75d(param_1,0,&RBX::Instance::RTTI_Type_Descriptor,
                           &RBX::Selection::RTTI_Type_Descriptor,0);
      if (uVar1 == 0) {
        return 1;
      }
    }
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 16035 ; VA 0x0090fe00 ; FUN_0090fe00 */

undefined FUN_0090fe00(byte *param_1)

{
  byte bVar1;
  byte ***pppbVar2;
  char cVar3;
  undefined uVar4;
  uint uVar5;
  int *piVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  byte ****ppppbVar9;
  byte *pbVar10;
  byte *pbVar11;
  uint uVar12;
  bool bVar13;
  uint in_stack_00000014;
  uint in_stack_00000018;
  uint auStack_68 [4];
  uint uStack_58;
  uint uStack_54;
  byte ***apppbStack_50 [4];
  uint uStack_40;
  uint uStack_3c;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [4];
  undefined auStack_1c [4];
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c5c81;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  uStack_40 = 0;
  uStack_3c = 0xf;
  apppbStack_50[0] = (byte ***)((uint)apppbStack_50[0] & 0xffffff00);
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_0192a9d8,4);
  pppbVar2 = apppbStack_50[0];
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  ppppbVar9 = apppbStack_50;
  if (0xf < uStack_3c) {
    ppppbVar9 = (byte ****)apppbStack_50[0];
  }
  uStack_8._0_1_ = 2;
  uStack_14 = uStack_40;
  if (in_stack_00000014 < uStack_40) {
    uStack_14 = in_stack_00000014;
  }
  pbVar11 = (byte *)&param_1;
  if (0xf < in_stack_00000018) {
    pbVar11 = param_1;
  }
  uVar5 = uStack_14;
  if (uStack_40 < uStack_14) {
    uVar5 = uStack_40;
  }
  while (uVar12 = uVar5 - 4, 3 < uVar5) {
    if (*(byte ****)pbVar11 != *ppppbVar9) goto LAB_0090feaa;
    pbVar11 = pbVar11 + 4;
    ppppbVar9 = ppppbVar9 + 1;
    uVar5 = uVar12;
  }
  if (uVar12 == 0xfffffffc) {
LAB_0090fede:
    uVar5 = 0;
  }
  else {
LAB_0090feaa:
    bVar13 = *pbVar11 < *(byte *)ppppbVar9;
    if ((*pbVar11 == *(byte *)ppppbVar9) &&
       ((uVar12 == 0xfffffffd ||
        ((bVar13 = pbVar11[1] < *(byte *)((int)ppppbVar9 + 1),
         pbVar11[1] == *(byte *)((int)ppppbVar9 + 1) &&
         ((uVar12 == 0xfffffffe ||
          ((bVar13 = pbVar11[2] < *(byte *)((int)ppppbVar9 + 2),
           pbVar11[2] == *(byte *)((int)ppppbVar9 + 2) &&
           ((uVar12 == 0xffffffff ||
            (bVar13 = pbVar11[3] < *(byte *)((int)ppppbVar9 + 3),
            pbVar11[3] == *(byte *)((int)ppppbVar9 + 3))))))))))))) goto LAB_0090fede;
    uVar5 = -(uint)bVar13 | 1;
  }
  if (((uVar5 == 0) && (uStack_40 <= uStack_14)) && (uStack_14 <= uStack_40)) {
    pbVar11 = (byte *)&param_1;
    if (0xf < in_stack_00000018) {
      pbVar11 = param_1;
    }
    uStack_54 = 0xf;
    auStack_68[0] = auStack_68[0] & 0xffffff00;
    pbVar10 = pbVar11;
    do {
      bVar1 = *pbVar10;
      pbVar10 = pbVar10 + 1;
    } while (bVar1 != 0);
    uStack_58 = uVar5;
    FUN_005542c0(pbVar11,(int)pbVar10 - (int)(pbVar11 + 1));
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    piStack_18 = (int *)0x1;
    cVar3 = FUN_016779b0(auStack_68,auStack_38,1);
    if (cVar3 != '\0') {
      bVar13 = true;
      goto LAB_0090ff42;
    }
  }
  bVar13 = false;
LAB_0090ff42:
  uStack_8 = 2;
  if ((((uint)piStack_18 & 1) != 0) && (0xf < uStack_54)) {
    uVar12 = uStack_54 + 1;
    uVar5 = auStack_68[0];
    if (0xfff < uVar12) {
      uVar5 = *(uint *)(auStack_68[0] - 4);
      uVar12 = uStack_54 + 0x24;
      if (0x1f < (auStack_68[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar12);
  }
  if (bVar13) {
    uStack_8._0_1_ = 4;
    piVar6 = (int *)FUN_016de181(1);
    uStack_8._0_1_ = 5;
    piStack_18 = piVar6;
    uVar4 = FUN_0090eaf0(auStack_38,&DAT_018bdf50,auStack_1c);
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if ((piVar6 != (int *)0x0) &&
       (puVar7 = (undefined4 *)(**(code **)(*piVar6 + 8))(), puVar7 != (undefined4 *)0x0)) {
      (**(code **)*puVar7)(1);
    }
    if (0xf < uStack_24) {
      uVar12 = uStack_24 + 1;
      uVar5 = auStack_38[0];
      if (0xfff < uVar12) {
        uVar5 = *(uint *)(auStack_38[0] - 4);
        uVar12 = uStack_24 + 0x24;
        if (0x1f < (auStack_38[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar12);
    }
    uStack_28 = 0;
    uStack_24 = 0xf;
    auStack_38[0] = auStack_38[0] & 0xffffff00;
    if (0xf < uStack_3c) {
      uVar5 = uStack_3c + 1;
      ppppbVar9 = (byte ****)pppbVar2;
      if (0xfff < uVar5) {
        ppppbVar9 = (byte ****)pppbVar2[-1];
        uVar5 = uStack_3c + 0x24;
        if ((byte *)0x1f < (byte *)((int)pppbVar2 + (-4 - (int)ppppbVar9))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppbVar9,uVar5);
    }
    if (0xf < in_stack_00000018) {
      uVar5 = in_stack_00000018 + 1;
      pbVar11 = param_1;
      if (0xfff < uVar5) {
        pbVar11 = *(byte **)(param_1 + -4);
        uVar5 = in_stack_00000018 + 0x24;
        if ((byte *)0x1f < param_1 + (-4 - (int)pbVar11)) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pbVar11,uVar5);
    }
    ExceptionList = pvStack_10;
    return uVar4;
  }
  uVar8 = FUN_005543f0();
  uVar8 = FUN_01675640(auStack_68,"Flag %s does not exist",uVar8);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  FUN_005500e0(uVar8);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_20,&DAT_01c17198);
}



/* FUNCTION 16036 ; VA 0x009100e0 ; FUN_009100e0 */

int FUN_009100e0(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5c98;
  pvStack_10 = ExceptionList;
  uVar5 = 0;
  ExceptionList = &pvStack_10;
  do {
    if (*(code **)((int)&DAT_01ee0d90 + uVar5) != (code *)0x0) {
      (**(code **)((int)&DAT_01ee0d90 + uVar5))();
    }
    uVar5 = uVar5 + 4;
  } while (uVar5 < 0x20);
  if (DAT_01d63fc8 != '\0') {
    iVar4 = FUN_00910450(param_1);
    ExceptionList = pvStack_10;
    return iVar4;
  }
  uStack_18 = 0;
  piStack_14 = (int *)0x0;
  uStack_8 = 0;
  iVar4 = FUN_00910570(param_1,&uStack_18);
  piVar3 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 16037 ; VA 0x009101a0 ; FUN_009101a0 */

int * __thiscall FUN_009101a0(int param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5cc8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01ee0d8c != (code *)0x0) {
    ExceptionList = &pvStack_10;
    (*DAT_01ee0d8c)();
  }
  if (DAT_01d63fc8 == '\0') {
    piStack_18 = (int *)0x0;
    piStack_14 = (int *)0x0;
    uStack_8 = 3;
    piVar3 = (int *)FUN_00910570(param_2,&piStack_18);
    if (piStack_18 == (int *)0x0) goto LAB_00910347;
    uVar4 = FUN_0086e8f0(&DAT_0191c70c);
    iVar5 = FUN_0087cde0(uVar4);
    if (iVar5 == 0) {
      piVar3 = (int *)FUN_00550b30();
      ExceptionList = pvStack_10;
      return piVar3;
    }
    uVar4 = FUN_0086e8f0("referent");
    iVar5 = FUN_0087cdb0(uVar4);
    if (iVar5 != 0) {
      FUN_0087d060(param_1 + 0x94);
    }
    uVar6 = *(uint *)(param_1 + 0xa4);
    piVar3 = (int *)(param_1 + 0x94);
  }
  else {
    FUN_00910450(param_2);
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    FUN_005542c0("UserGameSettings",0x10);
    uStack_8 = 0;
    FUN_008a1410(&piStack_18,auStack_30);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    if (0xf < uStack_1c) {
      uVar7 = uStack_1c + 1;
      uVar6 = auStack_30[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_30[0] - 4);
        uVar7 = uStack_1c + 0x24;
        if (0x1f < (auStack_30[0] - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
    uStack_20 = 0;
    uStack_1c = 0xf;
    auStack_30[0] = auStack_30[0] & 0xffffff00;
    piVar3 = piStack_18;
    if ((piStack_18 == (int *)0x0) || (piVar3 = (int *)piStack_18[4], piVar3 == (int *)0x0))
    goto LAB_00910347;
    if ((int *)(param_1 + 0x94) != piVar3) {
      piVar1 = piVar3 + 4;
      if (0xf < (uint)piVar3[5]) {
        piVar3 = (int *)*piVar3;
      }
      piVar3 = (int *)FUN_005542c0(piVar3,*piVar1);
    }
    uVar6 = *(uint *)(param_1 + 0xa4);
  }
  if (uVar6 < 0x23) {
    piVar3 = (int *)FUN_01531ce0(param_1 + 0x94);
  }
LAB_00910347:
  piVar1 = piStack_14;
  uStack_8 = 0xffffffff;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar2 = piStack_14 + 1;
    iVar5 = *piVar2;
    piVar3 = (int *)*piVar2;
    *piVar2 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      piVar3 = (int *)(**(code **)*piStack_14)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar5 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        piVar3 = (int *)(**(code **)(*piVar1 + 4))();
      }
    }
  }
  if (*(uint *)(param_1 + 0xa4) < 0x23) {
    piVar3 = (int *)FUN_01531ce0(param_1 + 0x94);
  }
  ExceptionList = pvStack_10;
  return piVar3;
}



/* FUNCTION 16038 ; VA 0x009103b0 ; FUN_009103b0 */

int FUN_009103b0(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5c98;
  pvStack_10 = ExceptionList;
  if (DAT_01d63fc8 == '\0') {
    uStack_18 = 0;
    piStack_14 = (int *)0x0;
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    iVar4 = FUN_00910570(param_1,&uStack_18);
    piVar3 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar1 = piStack_14 + 1;
      iVar2 = *piVar1;
      iVar4 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar4 = (**(code **)*piStack_14)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          iVar4 = (**(code **)(*piVar3 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return iVar4;
  }
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00910450(param_1);
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 16039 ; VA 0x00910450 ; FUN_00910450 */

void __thiscall FUN_00910450(int param_1,int param_2)

{
  undefined4 *puVar1;
  int aiStack_100 [3];
  byte abStack_f4 [172];
  undefined auStack_48 [24];
  int aiStack_30 [4];
  int iStack_20;
  uint uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5cfb;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffef4;
  if (*(int *)(param_2 + 0x10) == 0) {
    param_2 = param_1 + 0x78;
  }
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_2);
  uStack_8 = 0;
  if (iStack_20 != 0) {
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    puVar1 = (undefined4 *)FUN_0151a8d0(auStack_48,aiStack_30);
    uStack_8._0_1_ = 2;
    if (7 < (uint)puVar1[5]) {
      puVar1 = (undefined4 *)*puVar1;
    }
    FUN_0054ebd0(puVar1,0x21,0x40,1);
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_00550800();
    if ((abStack_f4[*(int *)(aiStack_100[0] + 4)] & 6) == 0) {
      FUN_00f70100(aiStack_100,param_1,0);
    }
    FUN_00551650();
  }
  if (0xf < uStack_1c) {
    if (0xfff < uStack_1c + 1) {
      if ((aiStack_30[0] - *(int *)(aiStack_30[0] + -4)) - 4U < 0x20) {
        FUN_0091054c();
        return;
      }
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0(aiStack_30[0],uStack_1c + 1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16040 ; VA 0x0091052e ; Catch@0091052e */

undefined4 Catch_0091052e(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x14) + 4))();
  FUN_0086f2f0(1,"Exception thrown in loadState %s",uVar1);
  return 0x910506;
}



/* FUNCTION 16041 ; VA 0x0091054c ; FUN_0091054c */

void __fastcall FUN_0091054c(undefined4 param_1,undefined4 param_2)

{
  int unaff_EBP;
  
  FUN_01674ea0(param_1,param_2);
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 16042 ; VA 0x00910570 ; FUN_00910570 */

void __thiscall FUN_00910570(int param_1,int param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined **ppuVar7;
  undefined **ppuVar8;
  int iStack_158;
  byte abStack_14c [4];
  undefined auStack_148 [168];
  undefined auStack_a0 [24];
  undefined auStack_88 [4];
  int *piStack_84;
  int aiStack_7c [4];
  int iStack_6c;
  uint uStack_68;
  undefined **ppuStack_64;
  int *piStack_48;
  undefined4 uStack_44;
  undefined **ppuStack_40;
  undefined uStack_3c;
  undefined *puStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 *puStack_24;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5d46;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffe9c;
  iVar4 = param_2;
  if (*(int *)(param_2 + 0x10) == 0) {
    iVar4 = param_1 + 0x78;
  }
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_0054ef60(iVar4);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  if (iStack_6c != 0) {
    uStack_8._0_1_ = 1;
    uStack_8._1_3_ = 0;
    puVar5 = (undefined4 *)FUN_0151a8d0(auStack_a0,aiStack_7c);
    uStack_8._0_1_ = 2;
    if (7 < (uint)puVar5[5]) {
      puVar5 = (undefined4 *)*puVar5;
    }
    FUN_0054ebd0(puVar5,0x21,0x40,1);
    uStack_8._0_1_ = 4;
    FUN_00550800();
    if ((abStack_14c[*(int *)(iStack_158 + 4)] & 6) == 0) {
      FUN_008828b0(auStack_148);
      uStack_8._0_1_ = 5;
      ppuStack_64 = TextXmlParser::vftable;
      piStack_48 = (int *)0x0;
      uStack_44 = 0;
      piStack_48 = (int *)FUN_005535a0();
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      puVar6 = (undefined4 *)FUN_00883a10(auStack_88);
      puVar5 = param_3;
      uVar1 = *puVar6;
      uVar2 = puVar6[1];
      *puVar6 = 0;
      puVar6[1] = 0;
      *param_3 = uVar1;
      piVar3 = (int *)param_3[1];
      param_3[1] = uVar2;
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar4 = piVar3[1] + -1;
        piVar3[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
      if (piStack_84 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_84[1] + -1;
        piStack_84[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_84)();
          LOCK();
          piVar3 = piStack_84 + 2;
          iVar4 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piStack_84 + 4))();
          }
        }
      }
      ppuStack_40 = RBX::MergeBinder::vftable;
      uStack_3c = 0;
      param_2 = 0xb;
      ppuVar7 = (undefined **)
                FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&param_2);
      ppuVar8 = ppuVar7 + -1;
      if (ppuVar7 != &boost::lock_error::vftable_meta_ptr) {
        ppuVar8 = ppuVar7;
      }
      puStack_38 = *ppuVar8;
      uStack_34 = 0;
      uStack_30 = 0x3f800000;
      uStack_2c = 0;
      uStack_28 = 0;
      puStack_24 = (undefined4 *)0x0;
      puStack_20 = (undefined4 *)0x0;
      uStack_1c = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      FUN_008a4ce0(*puVar5,&ppuStack_40,3);
      puVar5 = puStack_20;
      for (puVar6 = puStack_24; puVar6 != puVar5; puVar6 = puVar6 + 4) {
        (*(code *)**(undefined4 **)*puVar6)(puVar6[1],puVar6 + 2);
      }
      FUN_0075c360(puStack_24,puStack_20,&puStack_24);
      puStack_20 = puStack_24;
      FUN_0090edd0();
      FUN_00611f60();
      piVar3 = piStack_48;
      ppuStack_40 = RBX::IReferenceBinder::vftable;
      uStack_8._0_1_ = 8;
      FUN_005537e0(piStack_48[1]);
      piStack_48[1] = (int)piVar3;
      *piStack_48 = (int)piVar3;
      piStack_48[2] = (int)piVar3;
      uStack_44 = 0;
      FUN_01674ea0(piStack_48,0x40);
      FUN_00550da0();
    }
    FUN_00551650();
  }
  if (0xf < uStack_68) {
    if (0xfff < uStack_68 + 1) {
      if ((aiStack_7c[0] - *(int *)(aiStack_7c[0] + -4)) - 4U < 0x20) {
        FUN_0091081b();
        return;
      }
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0(aiStack_7c[0],uStack_68 + 1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16043 ; VA 0x009107fd ; Catch@009107fd */

undefined4 Catch_009107fd(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x7c) + 4))();
  FUN_0086f2f0(1,"Exception thrown in loadState %s",uVar1);
  return 0x9105b9;
}



/* FUNCTION 16044 ; VA 0x0091081b ; FUN_0091081b */

void __fastcall FUN_0091081b(undefined4 param_1,undefined4 param_2)

{
  int unaff_EBP;
  
  FUN_01674ea0(param_1,param_2);
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 16045 ; VA 0x00910840 ; FUN_00910840 */

undefined FUN_00910840(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  char cVar4;
  undefined uVar5;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bc778;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  piStack_14 = (int *)0x0;
  puStack_28 = &uStack_18;
  uStack_8 = 0;
  uStack_2c = 0x910881;
  ExceptionList = &pvStack_10;
  cVar4 = FUN_0087d210();
  if (cVar4 == '\0') {
    puStack_28 = (undefined4 *)DAT_01ede584;
    uStack_2c = 0x9108af;
    cVar4 = FUN_0087d470();
    if (cVar4 == '\0') {
      uVar5 = 0;
    }
    else {
      uVar5 = 1;
    }
  }
  else {
    FUN_006ebdf0(&uStack_2c,param_2);
    FUN_00d85960();
    uVar5 = 1;
  }
  piVar3 = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_14[1] + -1;
    piStack_14[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      puStack_28 = (undefined4 *)0x9108d2;
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_28 = (undefined4 *)0x9108e1;
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 16046 ; VA 0x00910900 ; FUN_00910900 */

undefined FUN_00910900(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  char cVar5;
  undefined uVar6;
  undefined4 *puStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c5d60;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar5 = FUN_0087d210(&uStack_1c);
  if (cVar5 == '\0') {
    cVar5 = FUN_0087d470(DAT_01ede584);
    if (cVar5 == '\0') {
      uVar6 = 0;
      goto LAB_00910a1d;
    }
  }
  else {
    cVar5 = FUN_00554d10();
    if (cVar5 == '\0') {
      (**(code **)*param_3)(param_2,&uStack_1c);
      uVar6 = 1;
      goto LAB_00910a1d;
    }
    puStack_2c = param_3;
    uStack_28 = param_2;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[1] = piStack_18[1] + 1;
      UNLOCK();
    }
    uStack_24 = uStack_1c;
    piStack_20 = piStack_18;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    puVar2 = *(undefined4 **)(iStack_14 + 0x20);
    if (*(undefined4 **)(iStack_14 + 0x24) == puVar2) {
      FUN_0090e130(puVar2,&puStack_2c);
    }
    else {
      *puVar2 = param_3;
      puVar2[1] = param_2;
      puVar2[2] = 0;
      puVar2[3] = 0;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      puVar2[2] = uStack_1c;
      puVar2[3] = piStack_18;
      *(int *)(iStack_14 + 0x20) = *(int *)(iStack_14 + 0x20) + 0x10;
    }
    piVar4 = piStack_20;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar3 = piStack_20[1] + -1;
      piStack_20[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar4 + 4))();
          uVar6 = 1;
          goto LAB_00910a1d;
        }
      }
    }
  }
  uVar6 = 1;
LAB_00910a1d:
  piVar4 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_18[1] + -1;
    piStack_18[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 16047 ; VA 0x00910a60 ; FUN_00910a60 */

void * __fastcall FUN_00910a60(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  void *pvVar4;
  int *piVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a0698;
  puVar6 = *(undefined4 **)(param_1 + 0x2c);
  pvVar4 = ExceptionList;
  if (puVar6 != (undefined4 *)0x0) {
    piVar5 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar5 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar5[1] = piVar5[1] + 1;
      UNLOCK();
      puVar6 = *(undefined4 **)(param_1 + 0x2c);
      piVar5 = *(int **)(param_1 + 0x30);
    }
    puVar3 = (undefined4 *)puVar6[1];
    puVar6 = (undefined4 *)*puVar6;
    uStack_8 = 0;
    pvVar4 = pvStack_10;
    for (; puVar6 != puVar3; puVar6 = puVar6 + 2) {
      if (puVar6[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar6[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      pvVar4 = (void *)FUN_00910b20(*puVar6,puVar6[1]);
    }
    if (piVar5 != (int *)0x0) {
      LOCK();
      piVar1 = piVar5 + 1;
      iVar2 = *piVar1;
      pvVar4 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar4 = (void *)(**(code **)*piVar5)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar4 = (void *)(**(code **)(*piVar5 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 16048 ; VA 0x00910b20 ; FUN_00910b20 */

void * FUN_00910b20(int *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017a0d48;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 != (int *)0x0) {
    iVar2 = param_1[3];
    ExceptionList = &pvStack_10;
    iVar3 = thunk_FUN_00897b90();
    pvVar4 = (void *)(uint)*(ushort *)(iVar3 + 0x1da);
    if ((void *)((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) <= pvVar4) {
      pvVar4 = (void *)(**(code **)(*param_1 + 0xa4))();
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    pvVar4 = (void *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      pvVar4 = (void *)(**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        pvVar4 = (void *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 16049 ; VA 0x00910bb0 ; FUN_00910bb0 */

undefined4 __fastcall FUN_00910bb0(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  
  puVar2 = *(undefined4 **)(param_1 + 0x20);
  puVar3 = *(undefined4 **)(param_1 + 0x1c);
  puVar1 = (undefined4 *)(param_1 + 0x1c);
  if (puVar3 != puVar2) {
    do {
      (*(code *)**(undefined4 **)*puVar3)(puVar3[1],puVar3 + 2);
      puVar3 = puVar3 + 4;
    } while (puVar3 != puVar2);
    puVar2 = *(undefined4 **)(param_1 + 0x20);
  }
  FUN_0075c360(*puVar1,puVar2,puVar1);
  *(undefined4 *)(param_1 + 0x20) = *puVar1;
  return CONCAT31((int3)((uint)*puVar1 >> 8),1);
}



/* FUNCTION 16050 ; VA 0x00910bf0 ; FUN_00910bf0 */

void __fastcall FUN_00910bf0(int param_1)

{
  int iVar1;
  undefined **ppuVar2;
  undefined4 ***pppuVar3;
  undefined **ppuVar4;
  undefined auStack_128 [176];
  undefined **ppuStack_78;
  int iStack_50;
  undefined4 **appuStack_4c [4];
  int iStack_3c;
  uint uStack_38;
  undefined auStack_34 [4];
  undefined *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  char acStack_1c [4];
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5d9b;
  pvStack_10 = ExceptionList;
  acStack_1c[0] = '\0';
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_0090ec40(acStack_1c);
  if ((*(char *)(param_1 + 0x90) == '\0') && (acStack_1c[0] == '\0')) {
    FUN_0054ef60(param_1 + 0x78);
    uStack_8 = 0;
    if (iStack_3c == 0) {
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return;
    }
    iVar1 = FUN_00f27310();
    auStack_34[0] = 0;
    uStack_14 = 0xb;
    iStack_50 = iVar1;
    ppuVar2 = (undefined **)
              FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&uStack_14);
    ppuVar4 = ppuVar2 + -1;
    if (ppuVar2 != &boost::lock_error::vftable_meta_ptr) {
      ppuVar4 = ppuVar2;
    }
    puStack_30 = *ppuVar4;
    uStack_2c = 0;
    uStack_28 = 0x3f800000;
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_8._0_1_ = 2;
    FUN_008a8880(iVar1,3,auStack_34);
    pppuVar3 = appuStack_4c;
    if (0xf < uStack_38) {
      pppuVar3 = (undefined4 ***)appuStack_4c[0];
    }
    FUN_00565320(pppuVar3,0x22,0x40,1);
    uStack_8._0_1_ = 3;
    FUN_00882920(auStack_128);
    ppuStack_78 = TextXmlWriter::vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    FUN_00885590(iVar1,auStack_34);
    FUN_0090eec0();
    FUN_00570460();
    FUN_00612650();
    if (iVar1 != 0) {
      FUN_00882a40(1);
    }
    FUN_005507b0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16051 ; VA 0x00910d60 ; FUN_00910d60 */

undefined FUN_00910d60(undefined4 param_1,undefined4 param_2)

{
  undefined auStack_c [4];
  undefined uStack_8;
  
  FUN_0090e8f0(auStack_c,param_1,param_1,param_2);
  return uStack_8;
}



/* FUNCTION 16052 ; VA 0x00910d90 ; FUN_00910d90 */

undefined4 FUN_00910d90(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c3f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_01ee1098);
  uStack_8 = 0;
  FUN_005789c0(&DAT_01ee10ac,&LAB_0090fd70);
  uVar2 = FUN_0090f260();
  uStack_8 = 1;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 16053 ; VA 0x00910e00 ; FUN_00910e00 */

undefined4 FUN_00910e00(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c3f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_01ee1098);
  uStack_8 = 0;
  FUN_005789c0(&DAT_01ee10bc,&LAB_0090fd80);
  uVar2 = FUN_0090f300();
  uStack_8 = 1;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return uVar2;
}



/* FUNCTION 16054 ; VA 0x00910e70 ; FUN_00910e70 */

void FUN_00910e70(undefined4 *param_1)

{
  undefined4 ***pppuVar1;
  undefined4 **appuStack_34 [5];
  uint uStack_20;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795d48;
  pvStack_10 = ExceptionList;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  ExceptionList = &pvStack_10;
  FUN_01675640(appuStack_34,"Flag %s referenced from Lua isn\'t defined in C++ code",param_1);
  uStack_8 = 0;
  if (DAT_01d84e8d != '\0') {
    pppuVar1 = appuStack_34;
    if (0xf < uStack_20) {
      pppuVar1 = (undefined4 ***)appuStack_34[0];
    }
    FUN_01677650(DAT_01d84e8d,&DAT_018bd25c,pppuVar1);
  }
  FUN_005500e0(appuStack_34);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 16055 ; VA 0x00910f00 ; FUN_00910f00 */

void __thiscall FUN_00910f00(int *param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined auStack_10 [4];
  char acStack_c [4];
  int *piStack_8;
  
  cVar1 = (**(code **)(*param_1 + 0xa4))(param_3);
  if (cVar1 == '\0') {
    acStack_c[0] = cVar1;
    piStack_8 = param_1;
    FUN_0090ec40(acStack_c);
    if (acStack_c[0] == '\0') {
      FUN_008a7cf0(param_2,param_3);
      return;
    }
  }
  FUN_016756b0(auStack_10,"Not allowed to add that under settings");
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 16056 ; VA 0x00910f70 ; FUN_00910f70 */

void FUN_00910f70(void)

{
  char cVar1;
  int *piVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5db0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar2 = (int *)FUN_01255560();
  if (*piVar2 != 0) {
    uStack_8 = 0;
    uVar3 = FUN_01255560();
    cVar1 = FUN_01255580(uVar3,5);
    if (cVar1 == '\0') {
      FUN_01255600(5,"set settings parent");
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16057 ; VA 0x00910fd9 ; Catch@00910fd9 */

void Catch_00910fd9(void)

{
  int unaff_EBP;
  
  FUN_0086f2f0(3,"Insufficient permissions to set settings parent");
  FUN_0054fe90(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -0x20,&DAT_01c243ac);
}



/* FUNCTION 16058 ; VA 0x00911010 ; FUN_00911010 */

void FUN_00911010(void)

{
  char cVar1;
  int *piVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5dc0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar2 = (int *)FUN_01255560();
  if (*piVar2 != 0) {
    uStack_8 = 0;
    uVar3 = FUN_01255560();
    cVar1 = FUN_01255580(uVar3,5);
    if (cVar1 == '\0') {
      FUN_01255600(5,"set UserSettings parent");
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16059 ; VA 0x00911079 ; Catch@00911079 */

void Catch_00911079(void)

{
  int unaff_EBP;
  
  FUN_0086f2f0(3,"Insufficient permissions to set UserSettings parent");
  FUN_0054fe90(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(unaff_EBP + -0x20,&DAT_01c243ac);
}



/* FUNCTION 16060 ; VA 0x009110b0 ; FUN_009110b0 */

int * __thiscall
FUN_009110b0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5deb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00911380();
  puVar3 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::TaskSchedulerSettings,double>::
              GetImpl<double_(__thiscall_RBX::TaskSchedulerSettings::*)(void)const_>::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088ca00();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_7,param_8,param_9,param_10,param_11,param_11,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<double>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::TaskSchedulerSettings,double>::
                    vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::PropDescriptor<class_RBX::TaskSchedulerSettings,double>::
                    vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16061 ; VA 0x009111b0 ; FUN_009111b0 */

int * __thiscall
FUN_009111b0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5e23;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_009112a0();
  uStack_8 = 0;
  uVar4 = FUN_0088daf0();
  FUN_009ca670(uVar3,uVar4,param_2,param_3,param_5,param_6,param_7,param_8,param_9,param_9,0);
  param_1[0xd] = 0;
  uStack_8 = 3;
  *param_1 = (int)RBX::Reflection::BoundProp<bool,1>::vftable;
  puVar5 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = RBX::Reflection::BoundProp<bool,1>::BoundPropGetSet<class_RBX::DebugSettings>::vftable
    ;
    puVar5[1] = param_1;
    puVar5[2] = param_4;
    puVar5[4] = 0;
    puVar5[5] = 0;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar5;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16062 ; VA 0x009112a0 ; FUN_009112a0 */

undefined * FUN_009112a0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5e3c;
  pvStack_10 = ExceptionList;
  if (DAT_01ee171c == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee1928) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee1928);
      if (DAT_01ee1928 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"DebugSettings",1,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01883c40);
        FUN_016f37bf(&DAT_01ee1928);
      }
    }
    DAT_01ee171c = &DAT_01ee1720;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee171c;
}



/* FUNCTION 16063 ; VA 0x00911380 ; FUN_00911380 */

undefined * FUN_00911380(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5e5c;
  pvStack_10 = ExceptionList;
  if (DAT_01ee1930 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee1b40) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee1b40);
      if (DAT_01ee1b40 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"TaskScheduler",1,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01883c50);
        FUN_016f37bf(&DAT_01ee1b40);
      }
    }
    DAT_01ee1930 = &DAT_01ee1938;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee1930;
}



/* FUNCTION 16064 ; VA 0x00911460 ; FUN_00911460 */

int __thiscall FUN_00911460(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c5e70;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::DebugSettings*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16065 ; VA 0x00911532 ; Catch_All@00911532 */

void Catch_All_00911532(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16066 ; VA 0x00911550 ; FUN_00911550 */

undefined4 * FUN_00911550(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c5eb0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_009112a0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x5c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00911740();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00911460(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16067 ; VA 0x00911610 ; FUN_00911610 */

undefined4 * __fastcall FUN_00911610(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("EnviromentalPhysicsThrottle");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::EThrottleType>::vftable;
  FUN_009caf20(&DAT_01d64050,7);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16068 ; VA 0x00911670 ; FUN_00911670 */

undefined4 * __fastcall FUN_00911670(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("TickCountSampleMethod");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Time::SampleMethod>::vftable;
  FUN_009caf20(&DAT_01d64088,3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16069 ; VA 0x009116d0 ; FUN_009116d0 */

undefined4 * __fastcall FUN_009116d0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("ThreadPoolConfig");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::TaskScheduler::ThreadPoolConfig>::vftable;
  FUN_009caf20(&DAT_01d63ff8,0xb);
  FUN_009cab70(0xc9,"PartialThread",0);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16070 ; VA 0x00911740 ; FUN_00911740 */

/* WARNING: Removing unreachable block (ram,0x009118ef) */
/* WARNING: Removing unreachable block (ram,0x009118fd) */
/* WARNING: Removing unreachable block (ram,0x00911956) */
/* WARNING: Removing unreachable block (ram,0x0091190d) */

undefined4 * __fastcall FUN_00911740(undefined4 *param_1)

{
  char cVar1;
  undefined *puVar2;
  undefined4 uVar3;
  char *pcVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [12];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5ef0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0170d1f0(param_1,0,0x54);
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::DebugSettings,class_RBX::GlobalAdvancedSettings::Item>::
             vftable;
  uVar3 = FUN_009112a0();
  param_1[3] = uVar3;
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 1;
  *param_1 = RBX::GlobalAdvancedSettingsItem<class_RBX::DebugSettings>::vftable;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  FUN_005542c0("DebugSettings",0xd);
  uStack_8._0_1_ = 2;
  FUN_008a6520(auStack_38);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_24) {
    uVar6 = uStack_24 + 1;
    uVar5 = auStack_38[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_38[0] - 4);
      uVar6 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  puVar2 = PTR_DAT_01d63fec;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  if (DAT_01ee1708 != (undefined4 *)0x0) {
    FUN_016756b0(auStack_20,"singleton %s already exists","DebugSettings");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_20,&DAT_01c17198);
  }
  uStack_8 = 3;
  DAT_01ee1708 = param_1;
  *param_1 = RBX::DebugSettings::vftable;
  *(undefined2 *)(param_1 + 0x16) = 1;
  *(undefined *)((int)param_1 + 0x5a) = 0;
  pcVar4 = puVar2;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(puVar2,(int)pcVar4 - (int)(puVar2 + 1));
  uStack_8._0_1_ = 4;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  pcVar4 = PTR_DAT_01d63fec;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(PTR_DAT_01d63fec,(int)pcVar4 - (int)(PTR_DAT_01d63fec + 1));
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_008a6520(auStack_38);
  if (0xf < uStack_24) {
    uVar6 = uStack_24 + 1;
    uVar5 = auStack_38[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_38[0] - 4);
      uVar6 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16071 ; VA 0x00911960 ; FUN_00911960 */

/* WARNING: Removing unreachable block (ram,0x00911b0f) */
/* WARNING: Removing unreachable block (ram,0x00911b1d) */
/* WARNING: Removing unreachable block (ram,0x00911b76) */
/* WARNING: Removing unreachable block (ram,0x00911b2d) */

undefined4 * __fastcall FUN_00911960(undefined4 *param_1)

{
  char cVar1;
  undefined *puVar2;
  undefined4 uVar3;
  char *pcVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_38 [4];
  undefined4 uStack_28;
  uint uStack_24;
  undefined auStack_20 [12];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5f30;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0170d1f0(param_1,0,0x54);
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::
             Described<class_RBX::TaskSchedulerSettings,class_RBX::GlobalAdvancedSettings::Item>::
             vftable;
  uVar3 = FUN_00911380();
  param_1[3] = uVar3;
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 1;
  *param_1 = RBX::GlobalAdvancedSettingsItem<class_RBX::TaskSchedulerSettings>::vftable;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  FUN_005542c0("TaskScheduler",0xd);
  uStack_8._0_1_ = 2;
  FUN_008a6520(auStack_38);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_24) {
    uVar6 = uStack_24 + 1;
    uVar5 = auStack_38[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_38[0] - 4);
      uVar6 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  puVar2 = PTR_DAT_01d63ff0;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  if (DAT_01ea8524 != (undefined4 *)0x0) {
    FUN_016756b0(auStack_20,"singleton %s already exists","TaskScheduler");
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_20,&DAT_01c17198);
  }
  uStack_8 = 3;
  DAT_01ea8524 = param_1;
  *param_1 = RBX::TaskSchedulerSettings::vftable;
  param_1[0x16] = 0;
  pcVar4 = puVar2;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(puVar2,(int)pcVar4 - (int)(puVar2 + 1));
  uStack_8._0_1_ = 4;
  uStack_28 = 0;
  uStack_24 = 0xf;
  auStack_38[0] = auStack_38[0] & 0xffffff00;
  pcVar4 = PTR_DAT_01d63ff0;
  do {
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(PTR_DAT_01d63ff0,(int)pcVar4 - (int)(PTR_DAT_01d63ff0 + 1));
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_008a6520(auStack_38);
  if (0xf < uStack_24) {
    uVar6 = uStack_24 + 1;
    uVar5 = auStack_38[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_38[0] - 4);
      uVar6 = uStack_24 + 0x24;
      if (0x1f < (auStack_38[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16072 ; VA 0x00911b80 ; FUN_00911b80 */

void __fastcall FUN_00911b80(undefined4 *param_1)

{
  *param_1 = RBX::GlobalAdvancedSettingsItem<class_RBX::DebugSettings>::vftable;
  DAT_01ee1708 = 0;
  FUN_0089b230();
  return;
}



/* FUNCTION 16073 ; VA 0x00911ba0 ; FUN_00911ba0 */

void __fastcall FUN_00911ba0(undefined4 *param_1)

{
  *param_1 = RBX::GlobalAdvancedSettingsItem<class_RBX::TaskSchedulerSettings>::vftable;
  DAT_01ea8524 = 0;
  FUN_0089b230();
  return;
}



/* FUNCTION 16074 ; VA 0x00911bc0 ; FUN_00911bc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_00911bc0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::EThrottleType>::vftable;
  _DAT_01ef3a04 = _DAT_01ef3a04 + 1;
  FUN_009ca750();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,100);
  }
  return param_1;
}



/* FUNCTION 16075 ; VA 0x00911bf0 ; FUN_00911bf0 */

undefined4 * __thiscall FUN_00911bf0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<double>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x10);
  }
  return param_1;
}



/* FUNCTION 16076 ; VA 0x00911c20 ; FUN_00911c20 */

undefined4 * __thiscall FUN_00911c20(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Time::SampleMethod>::GetSet::vftable
  ;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 16077 ; VA 0x00911c50 ; FUN_00911c50 */

undefined4 * __thiscall FUN_00911c50(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::TaskScheduler::ThreadPoolConfig>::
             GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x18);
  }
  return param_1;
}



/* FUNCTION 16078 ; VA 0x00911c80 ; FUN_00911c80 */

undefined4 * __thiscall FUN_00911c80(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::GlobalAdvancedSettingsItem<class_RBX::DebugSettings>::vftable;
  DAT_01ee1708 = 0;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 16079 ; VA 0x00911cc0 ; FUN_00911cc0 */

undefined4 * __thiscall FUN_00911cc0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::GlobalAdvancedSettingsItem<class_RBX::TaskSchedulerSettings>::vftable;
  DAT_01ea8524 = 0;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 16080 ; VA 0x00911d00 ; FUN_00911d00 */

undefined4 * __thiscall FUN_00911d00(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::GlobalAdvancedSettingsItem<class_RBX::DebugSettings>::vftable;
  DAT_01ee1708 = 0;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x5c);
  }
  return param_1;
}



/* FUNCTION 16081 ; VA 0x00911d40 ; FUN_00911d40 */

undefined4 * __thiscall FUN_00911d40(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::Time::SampleMethod>::GetSet::vftable
  ;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 16082 ; VA 0x00911d70 ; FUN_00911d70 */

undefined4 * __thiscall FUN_00911d70(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::TaskScheduler::ThreadPoolConfig>::
             GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 16083 ; VA 0x00911da0 ; FUN_00911da0 */

undefined4 * __thiscall FUN_00911da0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::GlobalAdvancedSettingsItem<class_RBX::TaskSchedulerSettings>::vftable;
  DAT_01ea8524 = 0;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x5c);
  }
  return param_1;
}



/* FUNCTION 16084 ; VA 0x00911de0 ; FUN_00911de0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00911de0(undefined4 param_1,undefined4 *param_2)

{
  undefined *puVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uStack_8;
  
  cVar3 = FUN_009cb5f0(param_1,&uStack_8);
  if (cVar3 != '\0') {
    uVar4 = thunk_FUN_00bc0d60();
    iVar2 = _tls_index;
    *param_2 = uVar4;
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + iVar2 * 4) + 0x34) < DAT_01ee1b54) {
      FUN_016f3809(&DAT_01ee1b54);
      if (DAT_01ee1b54 == -1) {
        _DAT_01ee1b48 = FUN_005c65e0;
        _DAT_01ee1b4c = FUN_005c65e0;
        _DAT_01ee1b50 = _guard_check_icall;
        FUN_016f37bf(&DAT_01ee1b54);
      }
    }
    puVar1 = (undefined *)param_2[1];
    if (puVar1 == &DAT_01ee1b48) {
      param_2[2] = uStack_8;
      return;
    }
    if (puVar1 != (undefined *)0x0) {
      (**(code **)(puVar1 + 8))(param_2 + 2);
    }
    param_2[2] = uStack_8;
    param_2[1] = &DAT_01ee1b48;
  }
  return;
}



/* FUNCTION 16085 ; VA 0x00911ea0 ; FUN_00911ea0 */

void FUN_00911ea0(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00bc0d60();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    *param_2 = *piVar3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16086 ; VA 0x00911ee0 ; FUN_00911ee0 */

undefined __fastcall FUN_00911ee0(int param_1)

{
  uint *puVar1;
  byte *pbVar2;
  byte *pbVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  undefined uVar7;
  bool bVar8;
  int aiStack_40 [5];
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794d38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  pbVar2 = (byte *)(**(code **)(param_1 + 8))(aiStack_40);
  uStack_8 = 0;
  pbVar3 = (byte *)(**(code **)(param_1 + 8))(auStack_28);
  puVar1 = (uint *)(pbVar2 + 0x10);
  if (0xf < *(uint *)(pbVar2 + 0x14)) {
    pbVar2 = *(byte **)pbVar2;
  }
  uVar4 = *(uint *)(pbVar3 + 0x10);
  if (0xf < *(uint *)(pbVar3 + 0x14)) {
    pbVar3 = *(byte **)pbVar3;
  }
  if (uVar4 == *puVar1) {
    while (uVar6 = uVar4 - 4, 3 < uVar4) {
      if (*(int *)pbVar3 != *(int *)pbVar2) goto LAB_00911f5e;
      pbVar3 = pbVar3 + 4;
      pbVar2 = pbVar2 + 4;
      uVar4 = uVar6;
    }
    if (uVar6 == 0xfffffffc) {
LAB_00911f92:
      uVar4 = 0;
    }
    else {
LAB_00911f5e:
      bVar8 = *pbVar3 < *pbVar2;
      if ((*pbVar3 == *pbVar2) &&
         ((uVar6 == 0xfffffffd ||
          ((bVar8 = pbVar3[1] < pbVar2[1], pbVar3[1] == pbVar2[1] &&
           ((uVar6 == 0xfffffffe ||
            ((bVar8 = pbVar3[2] < pbVar2[2], pbVar3[2] == pbVar2[2] &&
             ((uVar6 == 0xffffffff || (bVar8 = pbVar3[3] < pbVar2[3], pbVar3[3] == pbVar2[3]))))))))
          )))) goto LAB_00911f92;
      uVar4 = -(uint)bVar8 | 1;
    }
    if (uVar4 == 0) {
      uVar7 = 1;
      goto LAB_00911f9e;
    }
  }
  uVar7 = 0;
LAB_00911f9e:
  if (0xf < uStack_14) {
    uVar6 = uStack_14 + 1;
    uVar4 = auStack_28[0];
    if (0xfff < uVar6) {
      uVar4 = *(uint *)(auStack_28[0] - 4);
      uVar6 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar6);
  }
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    iVar5 = aiStack_40[0];
    if (0xfff < uVar4) {
      iVar5 = *(int *)(aiStack_40[0] + -4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar4);
  }
  ExceptionList = pvStack_10;
  return uVar7;
}



/* FUNCTION 16087 ; VA 0x00912030 ; FUN_00912030 */

int __fastcall FUN_00912030(int param_1)

{
  double dVar1;
  double dVar2;
  uint3 uVar3;
  undefined2 extraout_var;
  float10 fVar4;
  
  fVar4 = (float10)(**(code **)(param_1 + 8))();
  dVar1 = (double)fVar4;
  fVar4 = (float10)(**(code **)(param_1 + 8))();
  dVar2 = (double)fVar4;
  uVar3 = CONCAT21(extraout_var,
                   (dVar1 == dVar2) << 6 | (NAN(dVar1) || NAN(dVar2)) << 2 | 2U | dVar1 < dVar2);
  if ((NAN(dVar1) || NAN(dVar2)) != (dVar1 == dVar2)) {
    return CONCAT31(uVar3,1);
  }
  return (uint)uVar3 << 8;
}



/* FUNCTION 16088 ; VA 0x00912080 ; FUN_00912080 */

void FUN_00912080(void)

{
  int iVar1;
  
  if (DAT_01ee192c == 0) {
    iVar1 = FUN_009112a0();
    DAT_01ee192c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 16089 ; VA 0x009120a0 ; FUN_009120a0 */

void FUN_009120a0(void)

{
  int iVar1;
  
  if (DAT_01ee1b44 == 0) {
    iVar1 = FUN_00911380();
    DAT_01ee1b44 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 16090 ; VA 0x009120e0 ; FUN_009120e0 */

undefined4 FUN_009120e0(undefined4 param_1)

{
  FUN_0054ef60(&DAT_01d63fd4);
  return param_1;
}



/* FUNCTION 16091 ; VA 0x00912100 ; FUN_00912100 */

/* WARNING: Removing unreachable block (ram,0x00912152) */
/* WARNING: Removing unreachable block (ram,0x00912165) */
/* WARNING: Removing unreachable block (ram,0x0091216c) */
/* WARNING: Removing unreachable block (ram,0x00912173) */

undefined4 FUN_00912100(undefined4 param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796168;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  FUN_0054ef60(&DAT_01d63fd4);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16092 ; VA 0x009121a0 ; FUN_009121a0 */

void __thiscall FUN_009121a0(int *param_1,undefined4 param_2)

{
  param_2 = (**(code **)(*param_1 + 0x44))(param_2);
  FUN_005c1740(&param_2);
  return;
}



/* FUNCTION 16093 ; VA 0x009121c0 ; FUN_009121c0 */

void __thiscall FUN_009121c0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00896f00();
  *param_3 = uVar3;
  iVar4 = FUN_00897420();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 16094 ; VA 0x00912220 ; FUN_00912220 */

void __thiscall FUN_00912220(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00897160();
  *param_3 = uVar3;
  iVar4 = FUN_00897570();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 16095 ; VA 0x00912280 ; FUN_00912280 */

void * FUN_00912280(void)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  void *pvVar5;
  undefined4 uVar6;
  undefined auStack_20 [4];
  int *piStack_1c;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5fc0;
  pvStack_10 = ExceptionList;
  pvVar5 = ExceptionList;
  if (DAT_01ee1708 == 0) {
    ExceptionList = &pvStack_10;
    piVar4 = (int *)FUN_00910d90();
    cStack_14 = '\0';
    iVar3 = *piVar4;
    puStack_18 = (uint *)(iVar3 + 0x94);
    pvVar5 = (void *)FUN_00587410();
    uStack_8 = 0;
    if (DAT_01ee1708 == 0) {
      FUN_00911550(auStack_20);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      pvVar5 = (void *)FUN_008a65e0(iVar3,0);
      if (piStack_1c != (int *)0x0) {
        LOCK();
        puVar1 = (uint *)(piStack_1c + 1);
        uVar2 = *puVar1;
        pvVar5 = (void *)*puVar1;
        *puVar1 = uVar2 - 1;
        UNLOCK();
        if (uVar2 - 1 == 0) {
          pvVar5 = (void *)(**(code **)*piStack_1c)();
          LOCK();
          piVar4 = piStack_1c + 2;
          iVar3 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            pvVar5 = (void *)(**(code **)(*piStack_1c + 4))();
          }
        }
      }
    }
    uStack_8 = 2;
    if (cStack_14 != '\0') {
      LOCK();
      pvVar5 = (void *)*puStack_18;
      *puStack_18 = *puStack_18 + 0x80000000;
      UNLOCK();
      if ((((uint)pvVar5 & 0x40000000) == 0) && (-0x80000000 < (int)pvVar5)) {
        LOCK();
        uVar2 = *puStack_18;
        *puStack_18 = *puStack_18 | 0x40000000;
        UNLOCK();
        if ((uVar2 >> 0x1e & 1) == 0) {
          uVar6 = FUN_00554e40();
          pvVar5 = (void *)SetEvent(uVar6);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 16096 ; VA 0x00912370 ; FUN_00912370 */

void * FUN_00912370(void)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  void *pvVar5;
  undefined4 uVar6;
  undefined auStack_20 [4];
  int *piStack_1c;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5fe0;
  pvStack_10 = ExceptionList;
  pvVar5 = ExceptionList;
  if (DAT_01ea8524 == 0) {
    ExceptionList = &pvStack_10;
    piVar4 = (int *)FUN_00910d90();
    cStack_14 = '\0';
    iVar3 = *piVar4;
    puStack_18 = (uint *)(iVar3 + 0x94);
    pvVar5 = (void *)FUN_00587410();
    uStack_8 = 0;
    if (DAT_01ea8524 == 0) {
      FUN_0055eba0(auStack_20);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      pvVar5 = (void *)FUN_008a65e0(iVar3,0);
      if (piStack_1c != (int *)0x0) {
        LOCK();
        puVar1 = (uint *)(piStack_1c + 1);
        uVar2 = *puVar1;
        pvVar5 = (void *)*puVar1;
        *puVar1 = uVar2 - 1;
        UNLOCK();
        if (uVar2 - 1 == 0) {
          pvVar5 = (void *)(**(code **)*piStack_1c)();
          LOCK();
          piVar4 = piStack_1c + 2;
          iVar3 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            pvVar5 = (void *)(**(code **)(*piStack_1c + 4))();
          }
        }
      }
    }
    uStack_8 = 2;
    if (cStack_14 != '\0') {
      LOCK();
      pvVar5 = (void *)*puStack_18;
      *puStack_18 = *puStack_18 + 0x80000000;
      UNLOCK();
      if ((((uint)pvVar5 & 0x40000000) == 0) && (-0x80000000 < (int)pvVar5)) {
        LOCK();
        uVar2 = *puStack_18;
        *puStack_18 = *puStack_18 | 0x40000000;
        UNLOCK();
        if ((uVar2 >> 0x1e & 1) == 0) {
          uVar6 = FUN_00554e40();
          pvVar5 = (void *)SetEvent(uVar6);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 16097 ; VA 0x00912480 ; FUN_00912480 */

void FUN_00912480(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_00bc0d60();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16098 ; VA 0x009124e0 ; FUN_009124e0 */

void FUN_009124e0(void)

{
  char cVar1;
  uint uVar2;
  char *pcVar3;
  uint uVar4;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  pcVar3 = PTR_DAT_01d63fec;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(PTR_DAT_01d63fec,(int)pcVar3 - (int)(PTR_DAT_01d63fec + 1));
  uStack_8 = 0;
  FUN_008a6520(auStack_28);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16099 ; VA 0x009125a0 ; FUN_009125a0 */

void FUN_009125a0(void)

{
  char cVar1;
  uint uVar2;
  char *pcVar3;
  uint uVar4;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  pcVar3 = PTR_DAT_01d63ff0;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(PTR_DAT_01d63ff0,(int)pcVar3 - (int)(PTR_DAT_01d63ff0 + 1));
  uStack_8 = 0;
  FUN_008a6520(auStack_28);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16100 ; VA 0x00912660 ; FUN_00912660 */

/* WARNING: Removing unreachable block (ram,0x009126bc) */
/* WARNING: Removing unreachable block (ram,0x009126cf) */
/* WARNING: Removing unreachable block (ram,0x009126d6) */
/* WARNING: Removing unreachable block (ram,0x009126dd) */

void FUN_00912660(undefined4 *param_1)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6000;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  puVar1 = &param_1;
  if (0xf < in_stack_00000018) {
    puVar1 = param_1;
  }
  uStack_8._0_1_ = 1;
  FUN_005542c0(puVar1,in_stack_00000014);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (0xf < in_stack_00000018) {
    uVar2 = in_stack_00000018 + 1;
    puVar1 = param_1;
    if (0xfff < uVar2) {
      puVar1 = (undefined4 *)param_1[-1];
      uVar2 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16101 ; VA 0x00912730 ; FUN_00912730 */

void __thiscall FUN_00912730(int param_1,int param_2)

{
  FUN_0151ddb0(param_2);
  if (param_2 != *(int *)(param_1 + 0x58)) {
    *(int *)(param_1 + 0x58) = param_2;
    FUN_008a4940(&DAT_0211d678);
  }
  return;
}



/* FUNCTION 16102 ; VA 0x00912760 ; FUN_00912760 */

void FUN_00912760(undefined4 param_1)

{
  DAT_01d85084 = param_1;
  return;
}



/* FUNCTION 16103 ; VA 0x00912770 ; FUN_00912770 */

void __thiscall FUN_00912770(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00896f00();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16104 ; VA 0x009127c0 ; FUN_009127c0 */

void __thiscall FUN_009127c0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00897160();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16105 ; VA 0x00912810 ; FUN_00912810 */

int FUN_00912810(void)

{
  uint uVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  undefined auStack_20 [4];
  int *piStack_1c;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5fc0;
  pvStack_10 = ExceptionList;
  iVar4 = DAT_01ee1708;
  if (DAT_01ee1708 == 0) {
    ExceptionList = &pvStack_10;
    piVar2 = (int *)FUN_00910d90();
    cStack_14 = '\0';
    iVar4 = *piVar2;
    puStack_18 = (uint *)(iVar4 + 0x94);
    FUN_00587410();
    uStack_8 = 0;
    if (DAT_01ee1708 == 0) {
      FUN_00911550(auStack_20);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_008a65e0(iVar4,0);
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar4 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar2 = piStack_1c + 2;
          iVar4 = *piVar2;
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piStack_1c + 4))();
          }
        }
      }
    }
    iVar4 = DAT_01ee1708;
    uStack_8 = 2;
    if (cStack_14 != '\0') {
      LOCK();
      uVar1 = *puStack_18;
      *puStack_18 = *puStack_18 + 0x80000000;
      UNLOCK();
      if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
        LOCK();
        uVar1 = *puStack_18;
        *puStack_18 = *puStack_18 | 0x40000000;
        UNLOCK();
        if ((uVar1 >> 0x1e & 1) == 0) {
          uVar3 = FUN_00554e40();
          SetEvent(uVar3);
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 16106 ; VA 0x00912900 ; FUN_00912900 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00912900(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee1b54) {
    FUN_016f3809(&DAT_01ee1b54);
    if (DAT_01ee1b54 == -1) {
      _DAT_01ee1b48 = FUN_005c65e0;
      _DAT_01ee1b4c = FUN_005c65e0;
      _DAT_01ee1b50 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee1b54);
    }
  }
  return &DAT_01ee1b48;
}



/* FUNCTION 16107 ; VA 0x00912980 ; FUN_00912980 */

undefined4 * __thiscall FUN_00912980(undefined4 *param_1,undefined8 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_0088d870();
  *param_1 = uVar1;
  param_1[1] = 0;
  *(undefined8 *)(param_1 + 2) = *param_2;
  param_1[4] = *(undefined4 *)(param_2 + 1);
  uVar1 = FUN_006315b0();
  param_1[1] = uVar1;
  return param_1;
}



/* FUNCTION 16108 ; VA 0x009129c0 ; FUN_009129c0 */

undefined4 * __thiscall FUN_009129c0(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01932714;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 16109 ; VA 0x00912af0 ; FUN_00912af0 */

undefined4 * __thiscall FUN_00912af0(undefined4 *param_1,undefined param_2)

{
  char cVar1;
  
  *param_1 = 0;
  cVar1 = FUN_00585a40(&param_2);
  if (cVar1 == '\0') {
    *param_1 = &DAT_01932661;
    return param_1;
  }
  *param_1 = 0;
  return param_1;
}



/* FUNCTION 16110 ; VA 0x00912b40 ; FUN_00912b40 */

undefined4 * __thiscall FUN_00912b40(undefined4 *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  int *piStack_c;
  char cStack_5;
  
  *param_1 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  piStack_10 = param_3;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_0193272c;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (piStack_c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_c[2] + -1;
    piStack_c[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*piStack_c + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 16111 ; VA 0x00912c70 ; FUN_00912c70 */

undefined4 * __thiscall FUN_00912c70(undefined4 *param_1,undefined param_2)

{
  char cVar1;
  
  *param_1 = 0;
  cVar1 = FUN_00585a40(&param_2);
  if (cVar1 == '\0') {
    *param_1 = &DAT_01932689;
    return param_1;
  }
  *param_1 = 0;
  return param_1;
}



/* FUNCTION 16112 ; VA 0x00912cc0 ; FUN_00912cc0 */

undefined4 * __thiscall
FUN_00912cc0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  FUN_00915490(param_2,param_3,param_4,param_5);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 16113 ; VA 0x00912d50 ; FUN_00912d50 */

undefined4 * __thiscall
FUN_00912d50(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined **ppuVar3;
  undefined4 auStack_a0 [2];
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6028;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_40 = param_2;
  uStack_38 = 0;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_74 = 0;
      puStack_78 = &uStack_30;
      uStack_80 = CONCAT44(&param_6,0x912dbd);
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = CONCAT44(param_11,param_10);
    }
  }
  uVar1 = uStack_40;
  uStack_8._0_1_ = 1;
  puVar2 = param_1 + 2;
  uStack_60 = 0;
  if (uStack_38 != 0) {
    uStack_60 = uStack_38;
    if ((uStack_38 & 1) == 0) {
      puStack_78 = &uStack_58;
      uStack_74 = 0;
      uStack_80 = CONCAT44(&uStack_30,0x912e09);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    else {
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
      uStack_48 = uStack_20;
    }
  }
  uStack_74 = param_11;
  uStack_8._0_1_ = 2;
  puStack_18 = (undefined *)auStack_a0;
  uStack_98 = 0;
  auStack_a0[0] = uVar1;
  puStack_78 = puVar2;
  puVar2 = auStack_a0;
  if (uStack_60 != 0) {
    uStack_98 = uStack_60;
    if ((uStack_60 & 1) == 0) {
      (**(code **)(uStack_60 & 0xfffffffe))(&uStack_58,&uStack_90,0);
      puVar2 = (undefined4 *)puStack_18;
    }
    else {
      uStack_90 = uStack_58;
      uStack_8c = uStack_54;
      uStack_88 = uStack_50;
      uStack_84 = uStack_4c;
      uStack_80 = uStack_48;
      puVar2 = auStack_a0;
    }
  }
  puStack_18 = (undefined *)puVar2;
  ppuVar3 = &PTR_FUN_01932750;
  cStack_11 = FUN_009155b0();
  uStack_8._0_1_ = 3;
  if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
     (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_58;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x912e93);
    (**(code **)(uStack_60 & 0xfffffffe))();
  }
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_38 != 0) {
    if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_30;
      uStack_74 = 2;
      uStack_80 = CONCAT44(puStack_78,0x912ece);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    uStack_38 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_6;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x912efc);
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16114 ; VA 0x00912f20 ; FUN_00912f20 */

undefined4 __thiscall
FUN_00912f20(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10)

{
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6048;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_34,0);
    }
    else {
      uStack_34 = param_6;
      uStack_30 = param_7;
      uStack_2c = param_8;
      uStack_28 = param_9;
      uStack_24 = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  FUN_00912d50();
  uStack_8 = 1;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    uStack_1c = 2;
    uStack_24 = CONCAT44(&param_6,&param_6);
    uStack_28 = 0x912fbe;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16115 ; VA 0x00912fe0 ; FUN_00912fe0 */

undefined4 * __thiscall FUN_00912fe0(undefined4 *param_1,undefined4 param_2)

{
  bool bVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined **ppuVar4;
  undefined auStack_124 [48];
  undefined4 uStack_f4;
  undefined auStack_ec [48];
  undefined4 uStack_bc;
  undefined auStack_b4 [48];
  undefined4 uStack_84;
  undefined auStack_7c [48];
  undefined4 auStack_4c [2];
  undefined auStack_44 [48];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c60a8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_009190b0(&stack0x0000000c);
  uStack_f4 = param_2;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  FUN_009190b0(auStack_124);
  uStack_bc = uStack_f4;
  uStack_8._0_1_ = 2;
  FUN_009190b0(auStack_ec);
  auStack_4c[0] = uStack_bc;
  uStack_8._0_1_ = 3;
  FUN_009190b0(auStack_b4);
  uStack_8._0_1_ = 4;
  cVar2 = FUN_00585a40(auStack_4c);
  if (cVar2 == '\0') {
    uStack_84 = auStack_4c[0];
    FUN_009190b0(auStack_44);
    uStack_8._0_1_ = 5;
    puVar3 = (undefined4 *)FUN_01674e20(0x38);
    uStack_8._0_1_ = 6;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uStack_84;
      FUN_009190b0(auStack_7c);
    }
    param_1[2] = puVar3;
    FUN_0091a340();
    FUN_0091a340();
    bVar1 = true;
  }
  else {
    FUN_0091a340();
    bVar1 = false;
  }
  FUN_0091a340();
  ppuVar4 = &PTR_FUN_019326fc;
  if (!bVar1) {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  FUN_0091a340();
  FUN_0091a340();
  FUN_0091a340();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16116 ; VA 0x00913150 ; FUN_00913150 */

undefined4 * __thiscall FUN_00913150(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_0088cdc0();
  *param_1 = uVar1;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[2] = *param_2;
  param_1[3] = param_2[1];
  *param_2 = 0;
  param_2[1] = 0;
  uVar1 = FUN_006309e0();
  param_1[1] = uVar1;
  return param_1;
}



/* FUNCTION 16117 ; VA 0x009131b0 ; FUN_009131b0 */

int * __thiscall
FUN_009131b0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c60c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00913630();
  FUN_006846c0(uVar3,param_2,param_3,0,param_5,param_6,param_7,param_8,param_9);
  uStack_8 = 0;
  *param_1 = (int)RBX::Reflection::BoundProp<float,1>::vftable;
  puVar4 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = RBX::Reflection::BoundProp<float,1>::BoundPropGetSet<class_RBX::Player>::vftable;
    puVar4[1] = param_1;
    puVar4[2] = param_4;
    puVar4[4] = 0;
    puVar4[5] = 0;
  }
  puVar1 = (undefined4 *)param_1[0xd];
  param_1[0xd] = (int)puVar4;
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(1);
  }
  cVar2 = (**(code **)(*param_1 + 0xc))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar2 = (**(code **)(*param_1 + 8))();
  if (cVar2 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16118 ; VA 0x00913280 ; FUN_00913280 */

undefined4 * __thiscall FUN_00913280(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_0088da50();
  *param_1 = uVar1;
  param_1[1] = 0;
  param_1[2] = *param_2;
  param_1[3] = param_2[1];
  uVar1 = FUN_005c9e80();
  param_1[1] = uVar1;
  return param_1;
}



/* FUNCTION 16119 ; VA 0x009132c0 ; FUN_009132c0 */

uint * __thiscall
FUN_009132c0(uint *param_1,undefined4 param_2,undefined4 param_3,int *param_4,undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  uint auStack_54 [2];
  undefined auStack_4c [24];
  uint auStack_34 [2];
  undefined auStack_2c [28];
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017c60f8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[2] = param_4[2] + 1;
    UNLOCK();
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  auStack_34[0] = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  FUN_00915370(param_2,param_3,param_4,param_5);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_1 != auStack_34) {
    auStack_54[0] = 0;
    uStack_8 = 2;
    FUN_005880d0(auStack_34);
    FUN_005880d0(param_1);
    FUN_005880d0(auStack_54);
    uStack_8 = 3;
    if (((auStack_54[0] != 0) && ((auStack_54[0] & 1) == 0)) &&
       (*(code **)(auStack_54[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_54[0] & 0xfffffffe))(auStack_4c,auStack_4c,2);
    }
  }
  _uStack_8 = CONCAT31(uStack_7,4);
  if (((auStack_34[0] != 0) && ((auStack_34[0] & 1) == 0)) &&
     (*(code **)(auStack_34[0] & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(auStack_34[0] & 0xfffffffe))(auStack_2c,auStack_2c,2);
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16120 ; VA 0x00913410 ; FUN_00913410 */

void __thiscall
FUN_00913410(undefined4 *param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  
  pcVar2 = (code *)*param_3;
  uVar3 = *(undefined4 *)*param_4;
  uVar4 = param_1[2];
  uVar5 = param_1[3];
  uVar6 = param_1[4];
  if (uVar6 != 0) {
    if ((uVar6 & 1) == 0) {
      (**(code **)(uVar6 & 0xfffffffe))(param_1 + 6,&uStack_30,0);
    }
    else {
      uStack_30 = param_1[6];
      uStack_2c = param_1[7];
      uStack_28 = param_1[8];
      uStack_24 = param_1[9];
      uStack_20 = *(undefined8 *)(param_1 + 10);
    }
  }
  puVar7 = (undefined4 *)param_4[2];
  if (puVar7[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar7[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar8 = *puVar7;
  uVar9 = puVar7[1];
  puVar7 = (undefined4 *)param_4[1];
  if (puVar7[1] != 0) {
    LOCK();
    piVar1 = (int *)(puVar7[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uVar10 = *puVar7;
  uVar11 = puVar7[1];
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  (*pcVar2)(*param_1,param_1[1],uVar4,uVar5,uVar3,uVar10,uVar11,uVar8,uVar9);
  return;
}



/* FUNCTION 16121 ; VA 0x00913510 ; FUN_00913510 */

int FUN_00913510(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  code *pcVar7;
  int iVar8;
  int *piVar9;
  int *piVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6120;
  pvStack_10 = ExceptionList;
  uVar3 = *(undefined4 *)*param_3;
  puVar4 = (undefined4 *)param_3[2];
  piVar9 = (int *)puVar4[1];
  ExceptionList = &pvStack_10;
  if (piVar9 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar9[1] = piVar9[1] + 1;
    UNLOCK();
    piVar9 = (int *)puVar4[1];
  }
  uVar5 = *puVar4;
  puVar4 = (undefined4 *)param_3[1];
  piVar10 = (int *)puVar4[1];
  if (piVar10 != (int *)0x0) {
    LOCK();
    piVar10[1] = piVar10[1] + 1;
    UNLOCK();
    piVar10 = (int *)puVar4[1];
  }
  uVar6 = *puVar4;
  uStack_8 = 1;
  pcVar7 = (code *)*param_2;
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar9[1] = piVar9[1] + 1;
    UNLOCK();
  }
  if (piVar10 != (int *)0x0) {
    LOCK();
    piVar10[1] = piVar10[1] + 1;
    UNLOCK();
  }
  iVar8 = (*pcVar7)(uVar3,uVar6,piVar10,uVar5,piVar9);
  if (piVar10 != (int *)0x0) {
    piVar1 = piVar10 + 1;
    LOCK();
    iVar2 = *piVar1;
    iVar8 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar10)();
      LOCK();
      piVar1 = piVar10 + 2;
      iVar2 = *piVar1;
      iVar8 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar8 = (**(code **)(*piVar10 + 4))();
      }
    }
  }
  if (piVar9 != (int *)0x0) {
    LOCK();
    piVar10 = piVar9 + 1;
    iVar2 = *piVar10;
    iVar8 = *piVar10;
    *piVar10 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar8 = (**(code **)*piVar9)();
      LOCK();
      piVar10 = piVar9 + 2;
      iVar2 = *piVar10;
      *piVar10 = *piVar10 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar8 = (**(code **)(*piVar9 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar8;
}



/* FUNCTION 16122 ; VA 0x00913630 ; FUN_00913630 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00913630(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c6150;
  pvStack_10 = ExceptionList;
  if (DAT_01ee1c80 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee1e98) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee1e98);
      if (DAT_01ee1e98 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"Player",0,uStack_20,0,0,0x13,0,0);
        _DAT_01ee1e90 = RBX::Creator<class_RBX::Player>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee1c88,&DAT_01ee1e90);
        FUN_016f3654(FUN_01884f20);
        FUN_016f37bf(&DAT_01ee1e98);
      }
    }
    DAT_01ee1c80 = &DAT_01ee1c88;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee1c80;
}



/* FUNCTION 16123 ; VA 0x00913730 ; FUN_00913730 */

int FUN_00913730(undefined4 param_1,undefined4 param_2,uint *param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c6160;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_008ed990(param_1,param_2);
  uStack_8 = 0;
  *(undefined4 *)(iVar4 + 8) = 0;
  uVar1 = *param_3;
  if (uVar1 != 0) {
    *(uint *)(iVar4 + 8) = uVar1;
    if ((uVar1 & 1) == 0) {
      (**(code **)(uVar1 & 0xfffffffe))(param_3 + 2,iVar4 + 0x10,0);
    }
    else {
      uVar1 = param_3[3];
      uVar2 = param_3[4];
      uVar3 = param_3[5];
      *(uint *)(iVar4 + 0x10) = param_3[2];
      *(uint *)(iVar4 + 0x14) = uVar1;
      *(uint *)(iVar4 + 0x18) = uVar2;
      *(uint *)(iVar4 + 0x1c) = uVar3;
      *(undefined8 *)(iVar4 + 0x20) = *(undefined8 *)(param_3 + 6);
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 16124 ; VA 0x009137c0 ; Catch_All@009137c0 */

void Catch_All_009137c0(void)

{
  int unaff_EBP;
  
  FUN_005f6c10(*(undefined4 *)(unaff_EBP + 0xc),1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16125 ; VA 0x009137e0 ; FUN_009137e0 */

int FUN_009137e0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  
  iVar1 = FUN_005cb2b0(param_1,param_2);
  *(undefined4 *)(iVar1 + 8) = *param_3;
  *(undefined4 *)(iVar1 + 0xc) = param_3[1];
  *(undefined4 *)(iVar1 + 0x10) = param_3[2];
  *(undefined4 *)(iVar1 + 0x14) = 0;
  *(undefined4 *)(iVar1 + 0x18) = 0;
  *(undefined4 *)(iVar1 + 0x14) = param_3[3];
  *(undefined4 *)(iVar1 + 0x18) = param_3[4];
  param_3[3] = 0;
  param_3[4] = 0;
  return iVar1;
}



/* FUNCTION 16126 ; VA 0x00913840 ; FUN_00913840 */

int __thiscall FUN_00913840(uint *param_1,uint param_2,int param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  uStack_8 = 0xff;
  uStack_7 = 0xffffff;
  puStack_c = &LAB_017c6188;
  pvStack_10 = ExceptionList;
  uVar2 = *param_1;
  iVar4 = (int)(param_1[1] - uVar2) / 0x28;
  if (iVar4 == 0x6666666) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar4 + 1;
  uVar7 = (int)(param_1[2] - uVar2) / 0x28;
  uVar9 = uVar1;
  if ((uVar7 <= 0x6666666 - (uVar7 >> 1)) && (uVar9 = (uVar7 >> 1) + uVar7, uVar9 < uVar1)) {
    uVar9 = uVar1;
  }
  uVar7 = uVar9 * 0x28;
  if (uVar9 < 0x6666667) {
    if (0xfff < uVar7) goto LAB_009138fd;
    if (uVar7 == 0) {
      uVar7 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar7 = FUN_01674e20(uVar7);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_009138fd:
    uVar3 = uVar7 + 0x23;
    if (uVar3 <= uVar7) {
      uVar3 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) goto LAB_00913ab4;
    uVar7 = iVar4 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar4;
  }
  iVar5 = ((int)(param_2 - uVar2) / 0x28) * 0x28;
  iVar4 = iVar5 + uVar7;
  *(undefined4 *)(iVar4 + 0x24) = 0;
  uStack_8 = 1;
  uStack_7 = 0;
  if (*(undefined4 **)(param_3 + 0x24) != (undefined4 *)0x0) {
    uVar6 = (**(code **)**(undefined4 **)(param_3 + 0x24))(iVar4);
    *(undefined4 *)(iVar5 + uVar7 + 0x24) = uVar6;
  }
  uVar2 = param_1[1];
  uStack_8 = 0;
  if (param_2 == uVar2) {
    uVar8 = uVar7;
    for (uVar3 = *param_1; uStack_8 = 2, uVar3 != uVar2; uVar3 = uVar3 + 0x28) {
      *(undefined4 *)(uVar8 + 0x24) = 0;
      uStack_8 = 3;
      if (*(undefined4 **)(uVar3 + 0x24) != (undefined4 *)0x0) {
        uVar6 = (**(code **)**(undefined4 **)(uVar3 + 0x24))(uVar8);
        *(undefined4 *)(uVar8 + 0x24) = uVar6;
      }
      uVar8 = uVar8 + 0x28;
    }
    FUN_0072a040();
  }
  else {
    FUN_0091d170(*param_1,param_2,uVar7);
    FUN_0091d170(param_2,param_1[1],iVar4 + 0x28);
  }
  if (*param_1 != 0) {
    FUN_005f6200(*param_1,param_1[1]);
    uVar2 = *param_1;
    uVar8 = ((int)(param_1[2] - *param_1) / 0x28) * 0x28;
    uVar3 = uVar2;
    if (0xfff < uVar8) {
      uVar3 = *(uint *)(uVar2 - 4);
      uVar8 = uVar8 + 0x23;
      if (0x1f < (uVar2 - uVar3) - 4) {
LAB_00913ab4:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar3,uVar8);
  }
  *param_1 = uVar7;
  param_1[1] = uVar7 + uVar1 * 0x28;
  param_1[2] = uVar7 + uVar9 * 0x28;
  ExceptionList = pvStack_10;
  return *param_1 + iVar5;
}



/* FUNCTION 16127 ; VA 0x00913a8a ; Catch_All@00913a8a */

void Catch_All_00913a8a(void)

{
  int unaff_EBP;
  
  FUN_005f6200(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x24));
  FUN_005f6c10(*(undefined4 *)(unaff_EBP + -0x2c),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16128 ; VA 0x00913ac0 ; FUN_00913ac0 */

void __thiscall
FUN_00913ac0(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0xaaaaaa8 < (uint)param_1[1]) {
    FUN_0091d010(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00913b72:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00913b72;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 16129 ; VA 0x00913c20 ; FUN_00913c20 */

void __thiscall
FUN_00913c20(undefined4 *param_1,undefined4 *param_2,char param_3,uint *param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  undefined4 *puVar5;
  int *piVar6;
  bool bVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c61a0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  bVar7 = true;
  piVar2 = (int *)*param_1;
  piVar6 = piVar2;
  if (*(char *)(piVar2[1] + 0xd) == '\0') {
    piVar4 = (int *)piVar2[1];
    do {
      piVar6 = piVar4;
      if (param_3 == '\0') {
        bVar7 = *param_4 < (uint)piVar6[4];
      }
      else {
        bVar7 = *param_4 <= (uint)piVar6[4];
      }
      if (bVar7 == false) {
        piVar4 = (int *)piVar6[2];
      }
      else {
        piVar4 = (int *)*piVar6;
      }
    } while (*(char *)((int)piVar4 + 0xd) == '\0');
  }
  piVar4 = piVar6;
  if (bVar7 != false) {
    if (piVar6 == (int *)*piVar2) {
      bVar7 = true;
      goto LAB_00913cb5;
    }
    if (*(char *)((int)piVar6 + 0xd) == '\0') {
      piVar4 = (int *)*piVar6;
      if (*(char *)((int)piVar4 + 0xd) == '\0') {
        cVar1 = *(char *)(piVar4[2] + 0xd);
        piVar2 = (int *)piVar4[2];
        while (cVar1 == '\0') {
          cVar1 = *(char *)(piVar2[2] + 0xd);
          piVar4 = piVar2;
          piVar2 = (int *)piVar2[2];
        }
      }
      else {
        cVar1 = *(char *)(piVar6[1] + 0xd);
        piVar2 = (int *)piVar6[1];
        piVar4 = piVar6;
        while ((piVar3 = piVar2, cVar1 == '\0' && (piVar4 == (int *)*piVar3))) {
          cVar1 = *(char *)(piVar3[1] + 0xd);
          piVar2 = (int *)piVar3[1];
          piVar4 = piVar3;
        }
        if (*(char *)((int)piVar4 + 0xd) == '\0') {
          piVar4 = piVar3;
        }
      }
    }
    else {
      piVar4 = (int *)piVar6[2];
    }
  }
  if (*param_4 <= (uint)piVar4[4]) {
    ExceptionList = &pvStack_10;
    FUN_0091d010(param_5);
    *param_2 = piVar4;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00913cb5:
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_00913ac0(&param_3,bVar7,piVar6,param_4,param_5);
  *param_2 = *puVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16130 ; VA 0x00913d75 ; Catch_All@00913d75 */

void Catch_All_00913d75(void)

{
  int unaff_EBP;
  
  FUN_0091d010(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16131 ; VA 0x00913d90 ; FUN_00913d90 */

void __thiscall FUN_00913d90(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c61b0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<struct_RakNet::SystemAddress>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16132 ; VA 0x00913dfe ; Catch_All@00913dfe */

void Catch_All_00913dfe(void)

{
  int unaff_EBP;
  
  FUN_01674ea0(*(undefined4 *)(unaff_EBP + 8),0x20);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16133 ; VA 0x00913e20 ; FUN_00913e20 */

void __thiscall FUN_00913e20(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c61c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::PersistentDataStore>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16134 ; VA 0x00913e8e ; Catch_All@00913e8e */

void Catch_All_00913e8e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_0091cd20(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16135 ; VA 0x00913eb0 ; FUN_00913eb0 */

int __thiscall FUN_00913eb0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c61d0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::NumericValue<double>*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16136 ; VA 0x00913f82 ; Catch_All@00913f82 */

void Catch_All_00913f82(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16137 ; VA 0x00913fa0 ; FUN_00913fa0 */

int __thiscall FUN_00913fa0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c61e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Backpack*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16138 ; VA 0x00914072 ; Catch_All@00914072 */

void Catch_All_00914072(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16139 ; VA 0x00914090 ; FUN_00914090 */

int __thiscall FUN_00914090(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c61f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::GroupService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16140 ; VA 0x00914162 ; Catch_All@00914162 */

void Catch_All_00914162(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16141 ; VA 0x00914180 ; FUN_00914180 */

int __thiscall FUN_00914180(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6200;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::LuaWebService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16142 ; VA 0x00914252 ; Catch_All@00914252 */

void Catch_All_00914252(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16143 ; VA 0x00914270 ; FUN_00914270 */

int __thiscall FUN_00914270(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6210;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Player*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16144 ; VA 0x00914342 ; Catch_All@00914342 */

void Catch_All_00914342(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16145 ; VA 0x00914360 ; FUN_00914360 */

int __thiscall FUN_00914360(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6220;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::PlayerGui*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16146 ; VA 0x00914432 ; Catch_All@00914432 */

void Catch_All_00914432(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16147 ; VA 0x00914450 ; FUN_00914450 */

int __thiscall FUN_00914450(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6230;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::PlayerMouse*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16148 ; VA 0x00914522 ; Catch_All@00914522 */

void Catch_All_00914522(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16149 ; VA 0x00914540 ; FUN_00914540 */

int __thiscall FUN_00914540(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6240;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::PlayerScripts*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16150 ; VA 0x00914612 ; Catch_All@00914612 */

void Catch_All_00914612(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16151 ; VA 0x00914630 ; FUN_00914630 */

int __thiscall FUN_00914630(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6250;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::SpawnerService*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16152 ; VA 0x00914702 ; Catch_All@00914702 */

void Catch_All_00914702(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16153 ; VA 0x00914720 ; FUN_00914720 */

void __thiscall
FUN_00914720(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_18 = param_3;
  uStack_1c = param_2;
  uStack_14 = param_4;
  uStack_10 = param_5;
  cVar3 = FUN_00585a40(&uStack_1c);
  if (cVar3 == '\0') {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_10;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_1c;
    param_1[3] = piStack_18;
    param_1[4] = uStack_14;
    param_1[5] = uStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_019326a0;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 16154 ; VA 0x00914840 ; FUN_00914840 */

void __thiscall FUN_00914840(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_14;
  int *piStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_10 = param_3;
  uStack_14 = param_2;
  uStack_c = param_4;
  cVar3 = FUN_00585a40(&uStack_14);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = piStack_10;
    param_1[4] = uStack_c;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_019326e0;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 16155 ; VA 0x00914950 ; FUN_00914950 */

void __thiscall
FUN_00914950(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_18 = param_3;
  uStack_1c = param_2;
  uStack_14 = param_4;
  uStack_10 = param_5;
  cVar3 = FUN_00585a40(&uStack_1c);
  if (cVar3 == '\0') {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_10;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_1c;
    param_1[3] = piStack_18;
    param_1[4] = uStack_14;
    param_1[5] = uStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01932670;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 16156 ; VA 0x00914a70 ; FUN_00914a70 */

void __thiscall
FUN_00914a70(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_18 = param_3;
  uStack_1c = param_2;
  uStack_14 = param_4;
  uStack_10 = param_5;
  cVar3 = FUN_00585a40(&uStack_1c);
  if (cVar3 == '\0') {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_10;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_1c;
    param_1[3] = piStack_18;
    param_1[4] = uStack_14;
    param_1[5] = uStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_019326b0;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 16157 ; VA 0x00914b90 ; FUN_00914b90 */

void __thiscall
FUN_00914b90(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_18 = param_3;
  uStack_1c = param_2;
  uStack_14 = param_4;
  uStack_10 = param_5;
  cVar3 = FUN_00585a40(&uStack_1c);
  if (cVar3 == '\0') {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_10;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_1c;
    param_1[3] = piStack_18;
    param_1[4] = uStack_14;
    param_1[5] = uStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_019326a8;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 16158 ; VA 0x00914cb0 ; FUN_00914cb0 */

void __thiscall
FUN_00914cb0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_18 = param_3;
  uStack_1c = param_2;
  uStack_14 = param_4;
  uStack_10 = param_5;
  cVar3 = FUN_00585a40(&uStack_1c);
  if (cVar3 == '\0') {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_10;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_1c;
    param_1[3] = piStack_18;
    param_1[4] = uStack_14;
    param_1[5] = uStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01932678;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 16159 ; VA 0x00914dd0 ; FUN_00914dd0 */

void __thiscall
FUN_00914dd0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_18 = param_3;
  uStack_1c = param_2;
  uStack_14 = param_4;
  uStack_10 = param_5;
  cVar3 = FUN_00585a40(&uStack_1c);
  if (cVar3 == '\0') {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_10;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_1c;
    param_1[3] = piStack_18;
    param_1[4] = uStack_14;
    param_1[5] = uStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01932698;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 16160 ; VA 0x00914ef0 ; FUN_00914ef0 */

void __thiscall
FUN_00914ef0(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_18 = param_3;
  uStack_1c = param_2;
  uStack_14 = param_4;
  uStack_10 = param_5;
  cVar3 = FUN_00585a40(&uStack_1c);
  if (cVar3 == '\0') {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_10;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_1c;
    param_1[3] = piStack_18;
    param_1[4] = uStack_14;
    param_1[5] = uStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01932680;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 16161 ; VA 0x00915010 ; FUN_00915010 */

void __thiscall
FUN_00915010(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_18 = param_3;
  uStack_1c = param_2;
  uStack_14 = param_4;
  uStack_10 = param_5;
  cVar3 = FUN_00585a40(&uStack_1c);
  if (cVar3 == '\0') {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_10;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_1c;
    param_1[3] = piStack_18;
    param_1[4] = uStack_14;
    param_1[5] = uStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01932658;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 16162 ; VA 0x00915130 ; FUN_00915130 */

void __thiscall
FUN_00915130(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_18 = param_3;
  uStack_1c = param_2;
  uStack_14 = param_4;
  uStack_10 = param_5;
  cVar3 = FUN_00585a40(&uStack_1c);
  if (cVar3 == '\0') {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_10;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_1c;
    param_1[3] = piStack_18;
    param_1[4] = uStack_14;
    param_1[5] = uStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01932690;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 16163 ; VA 0x00915250 ; FUN_00915250 */

void __thiscall
FUN_00915250(undefined4 *param_1,undefined4 param_2,int *param_3,undefined4 param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  piStack_18 = param_3;
  uStack_1c = param_2;
  uStack_14 = param_4;
  uStack_10 = param_5;
  cVar3 = FUN_00585a40(&uStack_1c);
  if (cVar3 == '\0') {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    uStack_c = uStack_10;
    param_1[2] = 0;
    param_1[3] = 0;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      piStack_18[2] = piStack_18[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_1c;
    param_1[3] = piStack_18;
    param_1[4] = uStack_14;
    param_1[5] = uStack_10;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[2] + -1;
    param_3[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_3 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01932668;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_3 + 4))();
    }
  }
  return;
}



/* FUNCTION 16164 ; VA 0x00915370 ; FUN_00915370 */

void __thiscall
FUN_00915370(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_18;
  undefined4 uStack_14;
  int *piStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_18 = param_2;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  piStack_10 = param_4;
  uStack_14 = param_3;
  uStack_c = param_5;
  cVar3 = FUN_00585a40(&uStack_18);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_18;
    param_1[3] = 0;
    param_1[4] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[3] = uStack_14;
    param_1[4] = piStack_10;
    param_1[5] = uStack_c;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01932758;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return;
}



/* FUNCTION 16165 ; VA 0x00915490 ; FUN_00915490 */

void __thiscall
FUN_00915490(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  undefined4 uStack_18;
  undefined4 uStack_14;
  int *piStack_10;
  undefined4 uStack_c;
  char cStack_5;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_18 = param_2;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  piStack_10 = param_4;
  uStack_14 = param_3;
  uStack_c = param_5;
  cVar3 = FUN_00585a40(&uStack_18);
  if (cVar3 == '\0') {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_18;
    param_1[3] = 0;
    param_1[4] = 0;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      piStack_10[2] = piStack_10[2] + 1;
      UNLOCK();
    }
    param_1[3] = uStack_14;
    param_1[4] = piStack_10;
    param_1[5] = uStack_c;
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\x01';
  }
  else {
    if (piStack_10 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    cStack_5 = '\0';
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ppuVar4 = &PTR_FUN_01932734;
  if (cStack_5 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return;
}



/* FUNCTION 16166 ; VA 0x009155b0 ; FUN_009155b0 */

undefined FUN_009155b0(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined8 param_9,int *param_10)

{
  undefined4 uVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c627f;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00585a40(&param_1);
  uVar1 = param_1;
  if (cVar2 == '\0') {
    uStack_34 = 0;
    if (param_3 != 0) {
      uStack_34 = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_2c,0);
      }
      else {
        uStack_2c = param_5;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
      }
    }
    uStack_8._0_1_ = 1;
    puVar4 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 2;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[2] = 0;
      if (uStack_34 != 0) {
        puVar4[2] = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,puVar4 + 4,0);
        }
        else {
          puVar4[4] = uStack_2c;
          puVar4[5] = uStack_28;
          puVar4[6] = uStack_24;
          puVar4[7] = uStack_20;
          *(undefined8 *)(puVar4 + 8) = uStack_1c;
        }
      }
    }
    *param_10 = (int)puVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
       (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  uStack_8 = 4;
  param_10._3_1_ = uVar3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_10._3_1_;
}



/* FUNCTION 16167 ; VA 0x00915710 ; FUN_00915710 */

void __thiscall FUN_00915710(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  char cVar4;
  undefined **ppuVar5;
  undefined4 uStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 *puStack_8;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  uStack_14 = param_2;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
  }
  piStack_c = param_4;
  uStack_10 = param_3;
  puStack_8 = param_1;
  cVar4 = FUN_00585a40(&uStack_14);
  if (cVar4 == '\0') {
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[2] = piStack_c[2] + 1;
      UNLOCK();
    }
    param_1[2] = uStack_14;
    param_1[3] = 0;
    param_1[4] = 0;
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[2] = piStack_c[2] + 1;
      UNLOCK();
    }
    param_1[3] = uStack_10;
    param_1[4] = piStack_c;
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    bVar3 = true;
  }
  else {
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar2 = piStack_c[2] + -1;
      piStack_c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_c + 4))();
      }
    }
    bVar3 = false;
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  ppuVar5 = &PTR_FUN_01932604;
  if (!bVar3) {
    ppuVar5 = (undefined **)0x0;
  }
  *puStack_8 = ppuVar5;
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return;
}



/* FUNCTION 16168 ; VA 0x00915820 ; FUN_00915820 */

undefined4 *
FUN_00915820(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[2] = param_4[2] + 1;
    UNLOCK();
    piVar1 = param_4 + 2;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_4 + 4))();
    }
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
    LOCK();
    iVar2 = param_4[2] + -1;
    param_4[2] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  piVar1 = param_4 + 2;
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_3;
  param_1[2] = param_4;
  param_1[3] = param_5;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*param_4 + 4))();
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    piVar1 = param_4 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_4 + 4))();
    }
  }
  return param_1;
}



/* FUNCTION 16169 ; VA 0x009158f0 ; FUN_009158f0 */

undefined4 * FUN_009158f0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
    piVar1 = param_4 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  piVar1 = param_4 + 1;
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  param_1[1] = param_3;
  param_1[2] = param_4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 16170 ; VA 0x00915a00 ; FUN_00915a00 */

undefined4 *
FUN_00915a00(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,uint param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13,undefined4 param_14,undefined4 param_15,undefined8 param_16)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 *puStack_58;
  undefined8 uStack_54;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c62a8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_10 != 0) {
    if ((param_10 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_10 & 0xfffffffe))(&param_12,&uStack_64,0);
    }
    else {
      uStack_64 = param_12;
      uStack_60 = param_13;
      uStack_5c = param_14;
      puStack_58 = (undefined4 *)param_15;
      uStack_54 = param_16;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  uVar2 = FUN_00919170(param_3,param_4,param_5,param_6,param_7,param_8,param_9);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  *param_1 = param_2;
  uStack_54 = CONCAT44(uVar2,0x915ac6);
  FUN_009190b0();
  uStack_54 = CONCAT44(0x915ace,(undefined4)uStack_54);
  FUN_0091a340();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar1 = param_4[1] + -1;
    param_4[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      uStack_54 = CONCAT44(0x915ae5,(undefined4)uStack_54);
      (**(code **)*param_4)();
      LOCK();
      iVar1 = param_4[2] + -1;
      param_4[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        uStack_54 = CONCAT44(0x915af6,(undefined4)uStack_54);
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  uStack_8 = 3;
  if (((param_10 != 0) && ((param_10 & 1) == 0)) &&
     (*(code **)(param_10 & 0xfffffffe) != (code *)0x0)) {
    puStack_58 = &param_12;
    uStack_54 = CONCAT44(2,puStack_58);
    uStack_5c = 0x915b1a;
    (**(code **)(param_10 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16171 ; VA 0x00915b50 ; FUN_00915b50 */

undefined4 * __thiscall FUN_00915b50(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c62e1;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006eccd0();
  uStack_8 = 0;
  uVar2 = FUN_01675290(DAT_02110da8);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = 0;
    puVar3[1] = 1;
    puVar3[2] = FUN_00923110;
    puVar3[3] = FUN_0068b170;
    puVar3[4] = 0;
    puVar3[5] = param_1;
    puVar3[6] = 0;
    puVar3[7] = 0;
    if (param_3[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_3[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puVar3[6] = *param_3;
    puVar3[7] = param_3[1];
  }
  FUN_016797d0(puVar3);
  *param_2 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    LOCK();
    puVar3[1] = puVar3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16172 ; VA 0x00915c50 ; FUN_00915c50 */

undefined4 * __thiscall FUN_00915c50(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c3f8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  puVar3 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = 0;
    puVar3[1] = 1;
    puVar3[2] = FUN_009232d0;
    puVar3[3] = FUN_0068b170;
    puVar3[4] = 0;
    puVar3[5] = param_1;
    puVar3[6] = 0;
    puVar3[7] = 0;
    if (param_3[1] != 0) {
      LOCK();
      piVar1 = (int *)(param_3[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    puVar3[6] = *param_3;
    puVar3[7] = param_3[1];
  }
  FUN_016797d0(puVar3);
  *param_2 = puVar3;
  if (puVar3 != (undefined4 *)0x0) {
    LOCK();
    puVar3[1] = puVar3[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16173 ; VA 0x00915d30 ; FUN_00915d30 */

undefined4 * __thiscall FUN_00915d30(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a6248;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_02110da8);
  uStack_8 = 0;
  puVar5 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 1;
    puVar5[2] = FUN_0067baa0;
    puVar5[3] = _guard_check_icall;
    puVar5[4] = 0;
    puVar5[5] = param_1;
    uVar1 = param_3[1];
    uVar2 = param_3[2];
    uVar3 = param_3[3];
    puVar5[6] = *param_3;
    puVar5[7] = uVar1;
    puVar5[8] = uVar2;
    puVar5[9] = uVar3;
  }
  FUN_016797d0(puVar5);
  *param_2 = puVar5;
  if (puVar5 != (undefined4 *)0x0) {
    LOCK();
    puVar5[1] = puVar5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 1;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16174 ; VA 0x00915df0 ; FUN_00915df0 */

int * __fastcall FUN_00915df0(int *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  int *piStack_8;
  
  iVar3 = *param_1;
  piStack_8 = param_1;
  iVar2 = thunk_FUN_005f32d0();
  if (iVar3 == iVar2) {
    piVar6 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar6 = (int *)0x0;
    }
    if (piVar6 != (int *)0x0) {
      return piVar6;
    }
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 != iVar2) {
LAB_00915e8b:
    thunk_FUN_005f32d0();
    uVar4 = FUN_005543f0();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Unable to cast %s to %s",uVar5,uVar4);
  }
  iVar3 = *param_1;
  iVar2 = FUN_0088cb40();
  if (iVar3 == iVar2) {
    iVar3 = param_1[1];
    FUN_005f32d0();
    piVar7 = param_1 + 2;
    piVar6 = piVar7;
    if (iVar3 == 0) {
      piVar6 = (int *)0x0;
    }
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    cVar1 = FUN_009cb180(piVar6,&piStack_8);
    if (cVar1 == '\0') goto LAB_00915e8b;
    FUN_005ed730(&piStack_8);
    iVar3 = thunk_FUN_005f32d0();
    *param_1 = iVar3;
    iVar2 = thunk_FUN_005f32d0();
    if (iVar3 == iVar2) {
      if (param_1[1] == 0) {
        piVar7 = (int *)0x0;
      }
      return piVar7;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16175 ; VA 0x00915ec0 ; FUN_00915ec0 */

undefined4 * FUN_00915ec0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6320;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00daf5e0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x68);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00db24d0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00913eb0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16176 ; VA 0x00915f80 ; FUN_00915f80 */

undefined4 * FUN_00915f80(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6360;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c91ca0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x58);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c91da0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00913fa0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16177 ; VA 0x00916040 ; FUN_00916040 */

undefined4 * FUN_00916040(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c63a3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00ca9700();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x80);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00cabac0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00914090(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16178 ; VA 0x00916100 ; FUN_00916100 */

int FUN_00916100(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c63b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ee22f8,&LAB_00915b30);
  uVar2 = FUN_00916b40();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00ca9800();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00916040(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ee22f8,&LAB_00915b30);
      uVar2 = FUN_00916b40();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 16179 ; VA 0x00916290 ; FUN_00916290 */

undefined4 * FUN_00916290(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6403;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00e49b60();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x80);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00e4fb40();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00914180(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16180 ; VA 0x00916350 ; FUN_00916350 */

int FUN_00916350(void)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  int iStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c6418;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005789c0(&DAT_01ee22f0,&LAB_00915b40);
  uVar2 = FUN_00916bc0();
  piVar3 = (int *)FUN_008aa140(uVar2);
  iVar5 = *piVar3;
  if (*piVar3 == 0) {
    uVar2 = FUN_00e49e00();
    piVar4 = (int *)FUN_008a9ba0(auStack_24,uVar2);
    iVar5 = *piVar4;
    iVar1 = piVar4[1];
    *piVar4 = 0;
    piVar4[1] = 0;
    *piVar3 = iVar5;
    piVar4 = (int *)piVar3[1];
    piVar3[1] = iVar1;
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar5 = piVar4[1] + -1;
      piVar4[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piVar4)();
        LOCK();
        iVar5 = piVar4[2] + -1;
        piVar4[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_20[1] + -1;
      piStack_20[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar5 = piStack_20[2] + -1;
        piStack_20[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
    }
    iVar5 = *piVar3;
    if (*piVar3 == 0) {
      FUN_00916290(&iStack_1c);
      uStack_8 = 0;
      FUN_008a5700(uStack_14);
      FUN_005789c0(&DAT_01ee22f0,&LAB_00915b40);
      uVar2 = FUN_00916bc0();
      piVar3 = (int *)FUN_008aa140(uVar2);
      if (piStack_18 != (int *)0x0) {
        LOCK();
        piStack_18[1] = piStack_18[1] + 1;
        UNLOCK();
      }
      *piVar3 = iStack_1c;
      piVar4 = (int *)piVar3[1];
      piVar3[1] = (int)piStack_18;
      if (piVar4 != (int *)0x0) {
        LOCK();
        iVar5 = piVar4[1] + -1;
        piVar4[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar4)();
          LOCK();
          iVar5 = piVar4[2] + -1;
          piVar4[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar4 + 4))();
          }
        }
      }
      iVar5 = iStack_1c;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar1 = piStack_18[1] + -1;
        piStack_18[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar3 = piStack_18 + 2;
          iVar1 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 16181 ; VA 0x009164e0 ; FUN_009164e0 */

undefined4 * FUN_009164e0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6463;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00913630();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x540);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00919490();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00914270(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16182 ; VA 0x009165a0 ; FUN_009165a0 */

undefined4 * FUN_009165a0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c64a3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b56e90();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xa0);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00b5a320();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00914360(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16183 ; VA 0x00916660 ; FUN_00916660 */

undefined4 * FUN_00916660(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c64e3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00e8a2a0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xb4);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00e8a380();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00914450(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16184 ; VA 0x00916720 ; FUN_00916720 */

undefined4 * FUN_00916720(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6523;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00c4b770();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x98);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00c4cbf0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00914540(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16185 ; VA 0x009167e0 ; FUN_009167e0 */

undefined4 * FUN_009167e0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6560;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00e46aa0();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x70);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00e46eb0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00914630(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16186 ; VA 0x009168a0 ; FUN_009168a0 */

int FUN_009168a0(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c6578;
  pvStack_10 = ExceptionList;
  if (param_1 != 0) {
    iVar5 = *(int *)(param_1 + 0x34);
    ExceptionList = &pvStack_10;
    if ((iVar5 != 0) && (param_1 = iVar5, ExceptionList = &pvStack_10, *(int *)(iVar5 + 0x34) != 0))
    {
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar5 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar5 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      piVar3 = (int *)FUN_008e5480();
      iVar5 = *piVar3;
      if (iVar5 == 0) {
        FUN_009167e0(&iStack_18);
        iStack_8 = iVar5;
        FUN_008a5700(param_1);
        FUN_005789c0(&DAT_01ee0d38,&LAB_008e0ed0);
        uVar4 = FUN_008e4020();
        piVar3 = (int *)FUN_008aa140(uVar4);
        if (piStack_14 != (int *)0x0) {
          LOCK();
          piStack_14[1] = piStack_14[1] + 1;
          UNLOCK();
        }
        *piVar3 = iStack_18;
        piVar1 = (int *)piVar3[1];
        piVar3[1] = (int)piStack_14;
        if (piVar1 != (int *)0x0) {
          LOCK();
          iVar5 = piVar1[1] + -1;
          piVar1[1] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)*piVar1)();
            LOCK();
            iVar5 = piVar1[2] + -1;
            piVar1[2] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)(*piVar1 + 4))();
            }
          }
        }
        iVar5 = iStack_18;
        if (piStack_14 != (int *)0x0) {
          LOCK();
          iVar2 = piStack_14[1] + -1;
          piStack_14[1] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)*piStack_14)();
            LOCK();
            piVar3 = piStack_14 + 2;
            iVar2 = *piVar3;
            *piVar3 = *piVar3 + -1;
            UNLOCK();
            if (iVar2 == 1) {
              (**(code **)(*piStack_14 + 4))();
            }
          }
        }
      }
      ExceptionList = pvStack_10;
      return iVar5;
    }
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 16187 ; VA 0x009169f0 ; FUN_009169f0 */

undefined4 FUN_009169f0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_00634d90();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 16188 ; VA 0x00916a50 ; FUN_00916a50 */

void FUN_00916a50(undefined4 param_1,int param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_2 + 0x18);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_2 + 4);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_2 + 0x14) = 0;
  *(undefined4 *)(param_2 + 0x18) = 0xf;
  *(undefined *)(param_2 + 4) = 0;
  return;
}



/* FUNCTION 16189 ; VA 0x00916ab0 ; FUN_00916ab0 */

void FUN_00916ab0(undefined4 param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0072e210();
  FUN_01674ea0(param_2[6],0x18);
  uVar1 = param_2[5];
  if (0xf < uVar1) {
    iVar2 = *param_2;
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_2[4] = 0;
  param_2[5] = 0xf;
  *(undefined *)param_2 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16190 ; VA 0x00916b40 ; FUN_00916b40 */

undefined4 FUN_00916b40(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c659c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee231c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee231c);
    if (DAT_01ee231c == -1) {
      uStack_8 = 0;
      DAT_01ee2318 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ee231c);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee2318;
}



/* FUNCTION 16191 ; VA 0x00916bc0 ; FUN_00916bc0 */

undefined4 FUN_00916bc0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c65bc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee2314) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee2314);
    if (DAT_01ee2314 == -1) {
      uStack_8 = 0;
      DAT_01ee2310 = FUN_008a9ed0();
      FUN_016f37bf(&DAT_01ee2314);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee2310;
}



/* FUNCTION 16192 ; VA 0x00916c40 ; FUN_00916c40 */

int * __thiscall FUN_00916c40(byte *param_1,int *param_2,int *param_3,int *param_4)

{
  uint *puVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int *piVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  undefined4 *puVar13;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c65d8;
  pvStack_10 = ExceptionList;
  uVar11 = param_3[1];
  if (((int)uVar11 < 1) && ((int)uVar11 < 0)) {
    uVar11 = ~uVar11;
  }
  uVar11 = (uVar11 >> 2) + uVar11 * 0x40 + *param_3 ^ uVar11;
  ExceptionList = &pvStack_10;
  FUN_00606ff0(&iStack_14,uVar11,param_3,
               -(uint)(param_1 + *param_1 + 1 != (byte *)0x0) & (uint)(param_1 + *param_1 + 1 + 1));
  if (iStack_14 == 0) {
    uStack_8 = 0;
    iStack_14 = 0;
    piVar9 = (int *)FUN_01674e20(0x18);
    iStack_14 = CONCAT22(iStack_14._2_2_,0x101);
    *piVar9 = 0;
    piVar9[1] = 0;
    piVar9[2] = 0;
    piVar9[3] = 0;
    piVar9[4] = 0;
    piVar9[5] = 0;
    iVar6 = param_4[1];
    iVar7 = param_4[2];
    iVar8 = param_4[3];
    piVar9[2] = *param_4;
    piVar9[3] = iVar6;
    piVar9[4] = iVar7;
    piVar9[5] = iVar8;
    uVar4 = *(uint *)(param_1 + 8);
    uVar10 = uVar4 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar10 = FUN_005c9310(uVar10);
      if (uVar10 <= *(uint *)(param_1 + 4)) {
        uVar10 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar10);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar10) {
      uVar12 = uVar4 >> 1;
      if (uVar4 + (uVar4 >> 1) <= uVar10) {
        uVar12 = 1;
      }
      uVar10 = FUN_005c9310(uVar12 + *(int *)(param_1 + 8));
      puVar1 = (uint *)(param_1 + 4);
      if (uVar10 != *puVar1) {
        FUN_005d2b00(uVar10);
        puVar13 = (undefined4 *)(*(int *)(param_1 + 0x14) + *puVar1 * 4);
        puVar5 = (undefined4 *)*puVar13;
        while (puVar5 != (undefined4 *)0x0) {
          piVar2 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar5[1] % *puVar1) * 4);
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar5[1] % *puVar1) * 4) == 0) {
            *piVar2 = (int)puVar13;
            puVar13 = puVar5;
          }
          else {
            *puVar13 = *puVar5;
            *puVar5 = *(undefined4 *)*piVar2;
            *(undefined4 **)*piVar2 = puVar5;
          }
          puVar5 = (undefined4 *)*puVar13;
        }
      }
    }
    piVar9[1] = uVar11;
    uVar10 = *(uint *)(param_1 + 4);
    piVar2 = (int *)(*(int *)(param_1 + 0x14) + (uVar11 % uVar10) * 4);
    if ((int *)*piVar2 == (int *)0x0) {
      piVar3 = (int *)(*(int *)(param_1 + 0x14) + uVar10 * 4);
      if (*piVar3 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar3 + 4) % uVar10) * 4) = piVar9;
      }
      *piVar2 = (int)piVar3;
      *piVar9 = *piVar3;
      *piVar3 = (int)piVar9;
    }
    else {
      *piVar9 = *(int *)*piVar2;
      *(int **)*piVar2 = piVar9;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *param_2 = (int)piVar9;
    *(undefined *)(param_2 + 1) = 1;
    ExceptionList = pvStack_10;
    return param_2;
  }
  *param_2 = iStack_14;
  *(undefined *)(param_2 + 1) = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16193 ; VA 0x00916e50 ; FUN_00916e50 */

undefined4 * FUN_00916e50(undefined4 *param_1,int param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c661c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  param_1[8] = &DAT_01930024;
  param_1[10] = boost::exception_detail::clone_base::vftable;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::out_of_range::vftable;
  puVar1 = param_1 + 3;
  uStack_8 = 1;
  *puVar1 = boost::exception::vftable;
  piVar2 = *(int **)(param_2 + 0x10);
  param_1[4] = piVar2;
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_std::out_of_range>_>
             ::vftable;
  *puVar1 = boost::exception_detail::
            clone_impl<struct_boost::exception_detail::error_info_injector<class_std::out_of_range>_>
            ::vftable;
  uStack_8 = 2;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_std::out_of_range>_>::
       vftable;
  *(int *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = *(int *)(param_1[8] + 4) + -8;
  FUN_00554960(puVar1,param_2 + 0xc);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16194 ; VA 0x00916f30 ; FUN_00916f30 */

undefined4 * FUN_00916f30(undefined4 *param_1,int param_2)

{
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  param_1[3] = boost::exception::vftable;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0xffffffff;
  *param_1 = boost::exception_detail::error_info_injector<class_std::out_of_range>::vftable;
  param_1[3] = boost::exception_detail::error_info_injector<class_std::out_of_range>::vftable;
  return param_1;
}



/* FUNCTION 16195 ; VA 0x00916f90 ; FUN_00916f90 */

int * FUN_00916f90(int *param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if ((*param_2 == 0) ||
     (iVar7 = *(int *)(*param_2 + 0xc), iVar5 = FUN_00e63280(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    piStack_c = (int *)0x0;
    puVar6 = &uStack_10;
    bVar3 = false;
    bVar2 = true;
    iVar7 = 0;
  }
  else {
    piStack_14 = (int *)param_2[1];
    iVar7 = *param_2;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)param_2[1];
    }
    puVar6 = &uStack_18;
    bVar3 = true;
    bVar2 = false;
  }
  iVar5 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar4 = piStack_c;
  param_1[1] = iVar5;
  *param_1 = iVar7;
  if ((bVar2) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_c[1] + -1;
    piStack_c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_14;
  if ((bVar3) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_14[1] + -1;
    piStack_14[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 16196 ; VA 0x00917080 ; FUN_00917080 */

int * FUN_00917080(int *param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if ((*param_2 == 0) ||
     (iVar7 = *(int *)(*param_2 + 0xc), iVar5 = FUN_00e2c3f0(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    piStack_c = (int *)0x0;
    puVar6 = &uStack_10;
    bVar3 = false;
    bVar2 = true;
    iVar7 = 0;
  }
  else {
    piStack_14 = (int *)param_2[1];
    iVar7 = *param_2;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)param_2[1];
    }
    puVar6 = &uStack_18;
    bVar3 = true;
    bVar2 = false;
  }
  iVar5 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar4 = piStack_c;
  param_1[1] = iVar5;
  *param_1 = iVar7;
  if ((bVar2) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_c[1] + -1;
    piStack_c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_14;
  if ((bVar3) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_14[1] + -1;
    piStack_14[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 16197 ; VA 0x00917170 ; FUN_00917170 */

undefined4 FUN_00917170(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      puVar3 = (undefined4 *)FUN_00677130();
      return *puVar3;
    }
  }
  return 0;
}



/* FUNCTION 16198 ; VA 0x009171d0 ; FUN_009171d0 */

int FUN_009171d0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01eaad5c,&LAB_005f4450);
      uVar3 = FUN_005f5610();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_00a36f60();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar4;
    }
  }
  return 0;
}



/* FUNCTION 16199 ; VA 0x009172e0 ; FUN_009172e0 */

int FUN_009172e0(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  FUN_005789c0(&DAT_01eadd4c,&LAB_00670d30);
  uVar3 = FUN_00676230();
  piVar4 = (int *)FUN_008aa140(uVar3);
  if (*piVar4 == 0) {
    uVar3 = FUN_00b57090();
    piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
    iVar1 = *piVar5;
    iVar2 = piVar5[1];
    *piVar5 = 0;
    piVar5[1] = 0;
    *piVar4 = iVar1;
    piVar5 = (int *)piVar4[1];
    piVar4[1] = iVar2;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[1] + -1;
      piVar5[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piVar5)();
        LOCK();
        iVar1 = piVar5[2] + -1;
        piVar5[2] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (piStack_8 != (int *)0x0) {
      LOCK();
      iVar1 = piStack_8[1] + -1;
      piStack_8[1] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)*piStack_8)();
        LOCK();
        piVar5 = piStack_8 + 2;
        iVar1 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          (**(code **)(*piStack_8 + 4))();
        }
      }
    }
    return *piVar4;
  }
  return *piVar4;
}



/* FUNCTION 16200 ; VA 0x009173a0 ; FUN_009173a0 */

int FUN_009173a0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  undefined auStack_c [4];
  int *piStack_8;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      FUN_005789c0(&DAT_01eadd4c,&LAB_00670d30);
      uVar3 = FUN_00676230();
      piVar4 = (int *)FUN_008aa140(uVar3);
      if (*piVar4 == 0) {
        uVar3 = FUN_00b57090();
        piVar5 = (int *)FUN_008a9ba0(auStack_c,uVar3);
        iVar1 = *piVar5;
        iVar2 = piVar5[1];
        *piVar5 = 0;
        piVar5[1] = 0;
        *piVar4 = iVar1;
        piVar5 = (int *)piVar4[1];
        piVar4[1] = iVar2;
        if (piVar5 != (int *)0x0) {
          LOCK();
          iVar1 = piVar5[1] + -1;
          piVar5[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piVar5)();
            LOCK();
            iVar1 = piVar5[2] + -1;
            piVar5[2] = iVar1;
            UNLOCK();
            if (iVar1 == 0) {
              (**(code **)(*piVar5 + 4))();
            }
          }
        }
        if (piStack_8 != (int *)0x0) {
          LOCK();
          iVar1 = piStack_8[1] + -1;
          piStack_8[1] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)*piStack_8)();
            LOCK();
            piVar5 = piStack_8 + 2;
            iVar1 = *piVar5;
            *piVar5 = *piVar5 + -1;
            UNLOCK();
            if (iVar1 == 1) {
              (**(code **)(*piStack_8 + 4))();
            }
          }
        }
      }
      return *piVar4;
    }
  }
  return 0;
}



/* FUNCTION 16201 ; VA 0x009174b0 ; FUN_009174b0 */

undefined4 FUN_009174b0(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      uVar3 = FUN_008e46b0();
      return uVar3;
    }
  }
  return 0;
}



/* FUNCTION 16202 ; VA 0x00917510 ; FUN_00917510 */

int __fastcall FUN_00917510(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    piVar2 = (int *)puVar1[1];
    for (piVar6 = (int *)*puVar1; piVar6 != piVar2; piVar6 = piVar6 + 2) {
      iVar3 = *piVar6;
      if ((iVar3 != 0) &&
         (iVar4 = *(int *)(iVar3 + 0xc), iVar5 = FUN_00c4b870(),
         (uint)*(ushort *)(iVar4 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
         (uint)*(ushort *)(iVar5 + 0x1da))) {
        return iVar3;
      }
    }
  }
  return 0;
}



/* FUNCTION 16203 ; VA 0x00917570 ; FUN_00917570 */

code * FUN_00917570(code *param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined *puVar4;
  int *in_stack_00000028;
  undefined auStack_1bc [4];
  undefined4 uStack_1b8;
  undefined auStack_1b4 [184];
  undefined4 uStack_fc;
  undefined *puStack_f8;
  undefined *puStack_f4;
  undefined *puStack_f0;
  undefined4 *puStack_e0;
  undefined auStack_dc [200];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c664b;
  pvStack_10 = ExceptionList;
  puStack_f0 = &stack0x00000024;
  uStack_8 = 1;
  puStack_f4 = (undefined *)0x9175a6;
  ExceptionList = &pvStack_10;
  FUN_005c1420();
  puStack_14 = auStack_1bc;
  uStack_8._0_1_ = 2;
  uStack_1b8 = 0;
  puVar4 = auStack_1bc;
  if (puStack_e0 != (undefined4 *)0x0) {
    (*(code *)*puStack_e0)(auStack_dc,auStack_1b4);
    puVar4 = puStack_14;
  }
  puStack_14 = puVar4;
  FUN_008c6ce0();
  uStack_8._0_1_ = 3;
  if (puStack_e0 != (undefined4 *)0x0) {
    puStack_f0 = auStack_dc;
    puStack_f4 = (undefined *)0x91760b;
    (*(code *)puStack_e0[2])();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (((param_1 != (code *)0x0) && (((uint)param_1 & 1) == 0)) &&
     (param_1 = *(code **)((uint)param_1 & 0xfffffffe), param_1 != (code *)0x0)) {
    puStack_f8 = &stack0x0000000c;
    puStack_f0 = (undefined *)0x2;
    uStack_fc = 0x91762f;
    puStack_f4 = puStack_f8;
    param_1 = (code *)(*param_1)();
  }
  piVar3 = in_stack_00000028;
  if (in_stack_00000028 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000028 + 1;
    iVar2 = *piVar1;
    param_1 = (code *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      puStack_f0 = (undefined *)0x917652;
      param_1 = (code *)(**(code **)*in_stack_00000028)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        puStack_f0 = (undefined *)0x917661;
        param_1 = (code *)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16204 ; VA 0x00917680 ; FUN_00917680 */

void FUN_00917680(undefined4 param_1)

{
  undefined4 uVar1;
  undefined auStack_5c [44];
  undefined auStack_30 [32];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c6668;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00916f30(auStack_30,param_1);
  uStack_8 = 0;
  FUN_00916e50(auStack_5c,uVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_5c,&DAT_01c63f44);
}



/* FUNCTION 16205 ; VA 0x009176d0 ; FUN_009176d0 */

/* WARNING: Removing unreachable block (ram,0x009177d5) */
/* WARNING: Removing unreachable block (ram,0x009177e3) */
/* WARNING: Removing unreachable block (ram,0x00917823) */
/* WARNING: Removing unreachable block (ram,0x009177f3) */

void FUN_009176d0(undefined4 param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  int iVar6;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5408;
  pvStack_10 = ExceptionList;
  iVar6 = *param_2;
  iVar1 = *(int *)(iVar6 + 0xd0);
  ExceptionList = &pvStack_10;
  iVar3 = FUN_0088cdc0();
  if (iVar1 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  puVar4 = (undefined4 *)(iVar6 + 0xd8);
  if (*(int *)(iVar6 + 0xd4) == 0) {
    puVar4 = (undefined4 *)0x0;
  }
  iVar6 = puVar4[1];
  if (iVar6 != 0) {
    LOCK();
    *(int *)(iVar6 + 4) = *(int *)(iVar6 + 4) + 1;
    UNLOCK();
    iVar6 = puVar4[1];
  }
  uVar2 = *puVar4;
  uStack_8 = 0;
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar3 = FUN_0088cb40();
  if (iVar1 != iVar3) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Variant cast failed");
  }
  piVar5 = param_2 + 2;
  if (param_2[1] == 0) {
    piVar5 = (int *)0x0;
  }
  FUN_0054ef60(piVar5);
  uStack_8 = 2;
  FUN_00688d70(uStack_38,uStack_34,uStack_30,uStack_2c,CONCAT44(uStack_24,uStack_28),uVar2,iVar6);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16206 ; VA 0x00917830 ; FUN_00917830 */

void * __thiscall FUN_00917830(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  code *pcVar4;
  void *pvVar5;
  int *piVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a0698;
  puVar7 = *(undefined4 **)(param_1 + 0x2c);
  pvVar5 = ExceptionList;
  if (puVar7 != (undefined4 *)0x0) {
    piVar6 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar6 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar6[1] = piVar6[1] + 1;
      UNLOCK();
      piVar6 = *(int **)(param_1 + 0x30);
      puVar7 = *(undefined4 **)(param_1 + 0x2c);
    }
    puVar3 = (undefined4 *)puVar7[1];
    puVar7 = (undefined4 *)*puVar7;
    uStack_8 = 0;
    pvVar5 = pvStack_10;
    for (; puVar7 != puVar3; puVar7 = puVar7 + 2) {
      pcVar4 = (code *)*param_2;
      if (puVar7[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar7[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      (*pcVar4)(*puVar7,puVar7[1]);
      pvVar5 = (void *)FUN_00917830(param_2);
    }
    if (piVar6 != (int *)0x0) {
      LOCK();
      piVar1 = piVar6 + 1;
      iVar2 = *piVar1;
      pvVar5 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar5 = (void *)(**(code **)*piVar6)();
        LOCK();
        piVar1 = piVar6 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar5 = (void *)(**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar5;
}



/* FUNCTION 16207 ; VA 0x00917910 ; FUN_00917910 */

void * __thiscall FUN_00917910(int param_1,undefined4 *param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  code *pcVar5;
  void *pvVar6;
  int *piVar7;
  undefined4 *puVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvStack_10 = ExceptionList;
  puStack_c = &LAB_017a0698;
  puVar8 = *(undefined4 **)(param_1 + 0x2c);
  pvVar6 = ExceptionList;
  if (puVar8 != (undefined4 *)0x0) {
    piVar7 = *(int **)(param_1 + 0x30);
    ExceptionList = &pvStack_10;
    if (piVar7 != (int *)0x0) {
      LOCK();
      ExceptionList = &pvStack_10;
      piVar7[1] = piVar7[1] + 1;
      UNLOCK();
      piVar7 = *(int **)(param_1 + 0x30);
      puVar8 = *(undefined4 **)(param_1 + 0x2c);
    }
    puVar3 = (undefined4 *)puVar8[1];
    puVar8 = (undefined4 *)*puVar8;
    uStack_8 = 0;
    pvVar6 = pvStack_10;
    for (; puVar8 != puVar3; puVar8 = puVar8 + 2) {
      uVar4 = param_2[1];
      pcVar5 = (code *)*param_2;
      if (puVar8[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar8[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      (*pcVar5)(*puVar8,puVar8[1],uVar4);
      pvVar6 = (void *)FUN_00917910(param_2);
    }
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar1 = piVar7 + 1;
      iVar2 = *piVar1;
      pvVar6 = (void *)*piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        pvVar6 = (void *)(**(code **)*piVar7)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          pvVar6 = (void *)(**(code **)(*piVar7 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar6;
}



/* FUNCTION 16208 ; VA 0x009179f0 ; FUN_009179f0 */

undefined4 * __thiscall
FUN_009179f0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c66cb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00913630();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::Player,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_0088cb40();
  param_1[9] = uVar2;
  iVar1 = param_1[0x10];
  if (iVar1 == 0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088cb40();
    iStack_e4 = 0;
    FUN_0054ef60(iVar1);
    iStack_e4 = FUN_005c9d30();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16209 ; VA 0x00917b70 ; FUN_00917b70 */

undefined4 * __thiscall
FUN_00917b70(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c66cb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00913630();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::Player,class_std::shared_ptr<class_RBX::Instance>___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_0088cdc0();
  param_1[9] = uVar2;
  iVar1 = param_1[0x10];
  if (iVar1 == 0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088cb40();
    iStack_e4 = 0;
    FUN_0054ef60(iVar1);
    iStack_e4 = FUN_005c9d30();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16210 ; VA 0x00917cf0 ; FUN_00917cf0 */

undefined4 * __thiscall
FUN_00917cf0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c66cb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00913630();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::Player,double___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_0088ca00();
  param_1[9] = uVar2;
  iVar1 = param_1[0x10];
  if (iVar1 == 0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088cb40();
    iStack_e4 = 0;
    FUN_0054ef60(iVar1);
    iStack_e4 = FUN_005c9d30();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16211 ; VA 0x00917e70 ; FUN_00917e70 */

undefined4 * __thiscall
FUN_00917e70(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined4 auStack_e0 [50];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c672b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_00913630();
  FUN_009cb790(uVar1,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::BoundFuncDesc<class_RBX::Player,void___cdecl(int),1>::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar1 = FUN_00888530();
  param_1[9] = uVar1;
  puVar2 = (undefined4 *)param_1[0x10];
  if (puVar2 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar2 = &uStack_1b8;
    uStack_8 = 3;
    uVar4 = 2;
  }
  else {
    uStack_e8 = FUN_0088c8c0();
    iStack_e4 = 0;
    auStack_e0[0] = *puVar2;
    iStack_e4 = FUN_005c9cc0();
    puVar2 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088c8c0();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar4;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar4 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16212 ; VA 0x00917ff0 ; FUN_00917ff0 */

undefined4 * __thiscall
FUN_00917ff0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,int param_6)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  uint in_stack_00000028;
  undefined4 *in_stack_0000002c;
  undefined8 in_stack_00000030;
  undefined4 in_stack_00000038;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c67a2;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00913630();
  FUN_009cb790(uVar2,param_4,in_stack_0000002c,in_stack_00000030,in_stack_00000038);
  param_1[0xe] = param_2;
  uStack_8._0_1_ = 1;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::Player,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
             ::vftable;
  param_1[0xf] = param_3;
  in_stack_0000002c = (undefined4 *)FUN_01674e20(0x18);
  uStack_8._0_1_ = 2;
  if (in_stack_0000002c == (undefined4 *)0x0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_0054ef60(&param_6);
  }
  param_1[0x10] = uVar2;
  uStack_8._0_1_ = 3;
  uVar2 = FUN_00888530();
  param_1[9] = uVar2;
  iVar1 = param_1[0x10];
  if (iVar1 == 0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    in_stack_0000002c = &uStack_1b8;
    uStack_8 = 5;
    uVar4 = 2;
  }
  else {
    uStack_e8 = FUN_0088cb40();
    iStack_e4 = 0;
    FUN_0054ef60(iVar1);
    iStack_e4 = FUN_005c9d30();
    in_stack_0000002c = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar2 = FUN_0088cb40();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar2,in_stack_0000002c);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 6;
    uStack_14 = uVar4;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  uStack_8 = 3;
  if ((uVar4 & 1) != 0) {
    uStack_8 = 7;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  if (0xf < in_stack_00000028) {
    if (0xfff < in_stack_00000028 + 1) {
      if (0x1f < (param_6 - *(int *)(param_6 + -4)) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16213 ; VA 0x009181d0 ; FUN_009181d0 */

undefined4 * __thiscall
FUN_009181d0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c67fb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00913630();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::Player,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_00888530();
  param_1[9] = uVar2;
  puVar3 = (undefined4 *)param_1[0x10];
  if (puVar3 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088cdc0();
    iStack_e4 = 0;
    if (puVar3[1] != 0) {
      LOCK();
      piVar1 = (int *)(puVar3[1] + 4);
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    uStack_e0 = *puVar3;
    uStack_dc = puVar3[1];
    iStack_e4 = FUN_006309e0();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cdc0();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(&uStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16214 ; VA 0x00918370 ; FUN_00918370 */

undefined4 * __thiscall
FUN_00918370(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c685b;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00913630();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::BoundFuncDesc<class_RBX::Player,void___cdecl(bool),1>::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_00888530();
  param_1[9] = uVar2;
  puVar1 = (undefined *)param_1[0x10];
  if (puVar1 == (undefined *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088daf0();
    iStack_e4 = 0;
    auStack_e0[0] = *puVar1;
    iStack_e4 = FUN_005c9ef0();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088daf0();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16215 ; VA 0x009184f0 ; FUN_009184f0 */

undefined4 * __thiscall
FUN_009184f0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined auStack_e0 [200];
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c66cb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar2 = FUN_00913630();
  FUN_009cb790(uVar2,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::
             BoundFuncDesc<class_RBX::Player,bool___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),1>
             ::vftable;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar2 = FUN_0088daf0();
  param_1[9] = uVar2;
  iVar1 = param_1[0x10];
  if (iVar1 == 0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar3 = &uStack_1b8;
    uStack_8 = 3;
    uVar5 = 2;
  }
  else {
    uStack_e8 = FUN_0088cb40();
    iStack_e4 = 0;
    FUN_0054ef60(iVar1);
    iStack_e4 = FUN_005c9d30();
    puVar3 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar5 = 1;
  }
  uStack_14 = uVar5;
  uVar2 = FUN_0088cb40();
  uVar4 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar4,uVar2,puVar3);
  if ((uVar5 & 2) != 0) {
    uVar5 = uVar5 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar5;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar5 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(auStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16216 ; VA 0x00918670 ; FUN_00918670 */

undefined4 * __thiscall
FUN_00918670(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 uStack_1b8;
  int iStack_1b4;
  undefined auStack_1b0 [200];
  undefined4 uStack_e8;
  int iStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c68bb;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  uVar1 = FUN_00913630();
  FUN_009cb820(uVar1,param_4,param_6,param_7,param_8);
  param_1[0xe] = param_2;
  *param_1 = RBX::Reflection::BoundYieldFuncDesc<class_RBX::Player,bool___cdecl(__int64),1>::vftable
  ;
  param_1[0xf] = param_3;
  param_1[0x10] = 0;
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uVar1 = FUN_0088daf0();
  param_1[9] = uVar1;
  puVar2 = (undefined4 *)param_1[0x10];
  if (puVar2 == (undefined4 *)0x0) {
    uStack_1b8 = FUN_00888530();
    iStack_1b4 = 0;
    puVar2 = &uStack_1b8;
    uStack_8 = 3;
    uVar4 = 2;
  }
  else {
    uStack_e8 = FUN_0088da50();
    iStack_e4 = 0;
    uStack_e0 = *puVar2;
    uStack_dc = puVar2[1];
    iStack_e4 = FUN_005c9e80();
    puVar2 = &uStack_e8;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    uVar4 = 1;
  }
  uStack_14 = uVar4;
  uVar1 = FUN_0088da50();
  uVar3 = FUN_0086e3d0(param_5);
  FUN_00888b30(uVar3,uVar1,puVar2);
  if ((uVar4 & 2) != 0) {
    uVar4 = uVar4 & 0xfffffffd;
    uStack_8 = 4;
    uStack_14 = uVar4;
    if (iStack_1b4 != 0) {
      (**(code **)(iStack_1b4 + 8))(auStack_1b0);
    }
  }
  if ((uVar4 & 1) != 0) {
    uStack_8 = 5;
    if (iStack_e4 != 0) {
      (**(code **)(iStack_e4 + 8))(&uStack_e0);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16217 ; VA 0x009187f0 ; FUN_009187f0 */

undefined4 * __fastcall FUN_009187f0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("ChatMode");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Player::ChatMode>::vftable;
  FUN_009caf20(&DAT_01d642b8,2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16218 ; VA 0x00918850 ; FUN_00918850 */

undefined4 * __fastcall FUN_00918850(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("ChatPrivacyMode");
  uStack_8 = 0;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::Player::ChatPrivacyMode>::vftable;
  FUN_009caf20(&DAT_01d642c8,3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16219 ; VA 0x009188b0 ; FUN_009188b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __fastcall FUN_009188b0(undefined4 *param_1)

{
  int iVar1;
  void *pvVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017a5038;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_009ca470("MembershipType");
  pvVar2 = ThreadLocalStoragePointer;
  iVar1 = _tls_index;
  *param_1 = RBX::Reflection::EnumDesc<enum_RBX::MembershipType>::vftable;
  uStack_8 = 0;
  if (*(int *)(*(int *)((int)pvVar2 + iVar1 * 4) + 0x34) < DAT_01ee1c7c) {
    FUN_016f3809(&DAT_01ee1c7c);
    if (DAT_01ee1c7c == -1) {
      _DAT_01d64294 = PTR_DAT_01d6423c;
      _DAT_01d6429c = PTR_s_BuildersClub_01d64240;
      _DAT_01d642a4 = PTR_s_TurboBuildersClub_01d64244;
      _DAT_01d642ac = PTR_s_OutrageousBuildersClub_01d64248;
      _DAT_01d642b4 = PTR_s_Premium_01d6424c;
      FUN_016f37bf(&DAT_01ee1c7c);
    }
  }
  FUN_009caf20(&DAT_01d64290,5);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16220 ; VA 0x00918980 ; FUN_00918980 */

undefined4 * __thiscall
FUN_00918980(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 uVar1;
  undefined auStack_110 [216];
  undefined8 uStack_38;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017c68f1;
  pvStack_1c = ExceptionList;
  uStack_38 = param_6;
  ExceptionList = &pvStack_1c;
  puStack_30 = param_1;
  uVar1 = FUN_00913630();
  FUN_009cb970(uVar1,param_3,param_5,uStack_38,param_7);
  param_1[0xd] = param_2;
  iStack_14 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::Player,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::Player::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cb40();
  FUN_00888740();
  iStack_14._0_1_ = 1;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687810(auStack_110,&uStack_38,puStack_30);
  iStack_14._0_1_ = 2;
  if (param_1 + 10 != &uStack_2c) {
    FUN_0068a760();
    param_1[10] = uStack_2c;
    param_1[0xb] = uStack_28;
    param_1[0xc] = uStack_24;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
  }
  iStack_14._0_1_ = 3;
  FUN_0068a760();
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_016f32d1(auStack_110,0xd8,1,FUN_00688b10);
  param_1[0xe] = param_9;
  param_1[0xf] = param_8;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::Player,void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_rbx::remote_signal<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_RBX::Player::*>
             ::vftable;
  ExceptionList = pvStack_1c;
  return param_1;
}



/* FUNCTION 16221 ; VA 0x00918ae0 ; FUN_00918ae0 */

undefined4 * __thiscall
FUN_00918ae0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9)

{
  undefined4 uVar1;
  undefined auStack_110 [216];
  undefined8 uStack_38;
  undefined4 *puStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  void *pvStack_1c;
  undefined *puStack_18;
  int iStack_14;
  
  puStack_20 = &stack0xfffffffc;
  iStack_14 = 0xffffffff;
  puStack_18 = &LAB_017c6921;
  pvStack_1c = ExceptionList;
  uStack_38 = param_6;
  ExceptionList = &pvStack_1c;
  puStack_30 = param_1;
  uVar1 = FUN_00913630();
  FUN_009cb970(uVar1,param_3,param_5,uStack_38,param_7);
  param_1[0xd] = param_2;
  iStack_14 = 0;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::Player,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Player::*>
             ::vftable;
  FUN_0086e3d0(param_4);
  FUN_0088cdc0();
  FUN_00888740();
  iStack_14._0_1_ = 1;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  FUN_00687810(auStack_110,&uStack_38,puStack_30);
  iStack_14._0_1_ = 2;
  if (param_1 + 10 != &uStack_2c) {
    FUN_0068a760();
    param_1[10] = uStack_2c;
    param_1[0xb] = uStack_28;
    param_1[0xc] = uStack_24;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
  }
  iStack_14._0_1_ = 3;
  FUN_0068a760();
  iStack_14 = (uint)iStack_14._1_3_ << 8;
  FUN_016f32d1(auStack_110,0xd8,1,FUN_00688b10);
  param_1[0xe] = param_9;
  param_1[0xf] = param_8;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::Player,void___cdecl(class_std::shared_ptr<class_RBX::Instance>),class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>,class_rbx::remote_signal<void___cdecl(class_std::shared_ptr<class_RBX::Instance>)>_RBX::Player::*>
             ::vftable;
  ExceptionList = pvStack_1c;
  return param_1;
}



/* FUNCTION 16222 ; VA 0x00918c40 ; FUN_00918c40 */

undefined4 * __thiscall
FUN_00918c40(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined8 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795db0;
  pvStack_10 = ExceptionList;
  uStack_18 = param_5;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00913630();
  FUN_009cb970(uVar1,param_3,param_4,uStack_18,param_6);
  param_1[0xd] = param_2;
  *param_1 = RBX::Reflection::
             EventDesc<class_RBX::Player,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::Player::*>
             ::vftable;
  uStack_1c = 0;
  uStack_18 = 0;
  uStack_8 = 0;
  if (param_1 + 10 != &uStack_1c) {
    FUN_0068a760();
    param_1[10] = 0;
    param_1[0xb] = 0;
    param_1[0xc] = 0;
  }
  uStack_8 = 1;
  FUN_0068a760();
  param_1[0xe] = param_8;
  param_1[0xf] = param_7;
  *param_1 = RBX::Reflection::
             RemoteEventDesc<class_RBX::Player,void___cdecl(void),class_rbx::remote_signal<void___cdecl(void)>,class_rbx::remote_signal<void___cdecl(void)>_RBX::Player::*>
             ::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16223 ; VA 0x00918d20 ; FUN_00918d20 */

/* WARNING: Removing unreachable block (ram,0x00918db3) */

int * __thiscall
FUN_00918d20(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c694b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0088cfa0();
  FUN_009ca670(param_2,uVar2,param_3,param_4,param_6,param_7,param_8,param_9,param_10,param_10,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_RBX::BrickColor>::vftable;
  param_1[0xd] = param_5;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_5 != 0) {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16224 ; VA 0x00918dd0 ; FUN_00918dd0 */

/* WARNING: Removing unreachable block (ram,0x00918e63) */

int * __thiscall
FUN_00918dd0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c697b;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b00260();
  FUN_009ca670(param_2,uVar2,param_3,param_4,param_6,param_7,param_8,param_9,param_10,param_10,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_G3D::CoordinateFrame>::vftable;
  param_1[0xd] = param_5;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_5 != 0) {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16225 ; VA 0x00918e80 ; FUN_00918e80 */

/* WARNING: Removing unreachable block (ram,0x00918f13) */

int * __thiscall
FUN_00918e80(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined4 param_10)

{
  char cVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c69ab;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0088d870();
  FUN_009ca670(param_2,uVar2,param_3,param_4,param_6,param_7,param_8,param_9,param_10,param_10,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_G3D::Vector3>::vftable;
  param_1[0xd] = param_5;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (param_5 != 0) {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16226 ; VA 0x00918f30 ; FUN_00918f30 */

undefined4 * __thiscall FUN_00918f30(undefined4 *param_1,int param_2,int param_3)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794074;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_3 != 0) {
    ExceptionList = &pvStack_10;
    param_1[8] = &DAT_01930024;
    param_1[10] = boost::exception_detail::clone_base::vftable;
  }
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::out_of_range::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 1;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::
             clone_impl<struct_boost::exception_detail::error_info_injector<class_std::out_of_range>_>
             ::vftable;
  param_1[3] = boost::exception_detail::
               clone_impl<struct_boost::exception_detail::error_info_injector<class_std::out_of_range>_>
               ::vftable;
  *(undefined ***)(*(int *)(param_1[8] + 4) + 0x20 + (int)param_1) =
       boost::exception_detail::
       clone_impl<struct_boost::exception_detail::error_info_injector<class_std::out_of_range>_>::
       vftable;
  *(undefined4 *)(*(int *)(param_1[8] + 4) + 0x1c + (int)param_1) = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16227 ; VA 0x00919010 ; FUN_00919010 */

undefined4 * __thiscall FUN_00919010(undefined4 *param_1,int param_2)

{
  int *piVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794298;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  FUN_0170c226(param_2 + 4,param_1 + 1);
  *param_1 = std::out_of_range::vftable;
  param_1[3] = boost::exception::vftable;
  piVar1 = *(int **)(param_2 + 0x10);
  uStack_8 = 0;
  param_1[4] = piVar1;
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0xc))();
  }
  param_1[5] = *(undefined4 *)(param_2 + 0x14);
  param_1[6] = *(undefined4 *)(param_2 + 0x18);
  param_1[7] = *(undefined4 *)(param_2 + 0x1c);
  *param_1 = boost::exception_detail::error_info_injector<class_std::out_of_range>::vftable;
  param_1[3] = boost::exception_detail::error_info_injector<class_std::out_of_range>::vftable;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16228 ; VA 0x009190b0 ; FUN_009190b0 */

undefined4 * __thiscall FUN_009190b0(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pvVar6 = ExceptionList;
  puStack_c = &LAB_017c69c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  param_1[3] = param_2[3];
  param_1[4] = 0;
  uVar2 = param_2[4];
  uStack_8 = 0;
  if (uVar2 != 0) {
    param_1[4] = uVar2;
    if ((uVar2 & 1) != 0) {
      uVar3 = param_2[7];
      uVar4 = param_2[8];
      uVar5 = param_2[9];
      param_1[6] = param_2[6];
      param_1[7] = uVar3;
      param_1[8] = uVar4;
      param_1[9] = uVar5;
      *(undefined8 *)(param_1 + 10) = *(undefined8 *)(param_2 + 10);
      ExceptionList = pvVar6;
      return param_1;
    }
    (**(code **)(uVar2 & 0xfffffffe))(param_2 + 6,param_1 + 6,0);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16229 ; VA 0x00919170 ; FUN_00919170 */

int __thiscall
FUN_00919170(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,uint param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined8 param_15)

{
  int iVar1;
  uint uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined8 uStack_28;
  undefined4 uStack_20;
  int *piStack_1c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c6a08;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  uStack_40 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  if (param_9 != 0) {
    uStack_40 = param_9;
    if ((param_9 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_9 & 0xfffffffe))(&param_11,&uStack_38,0);
    }
    else {
      uStack_38 = param_11;
      uStack_34 = param_12;
      uStack_30 = param_13;
      uStack_2c = param_14;
      uStack_28 = param_15;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_20 = param_2;
  piStack_1c = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  FUN_00919320(param_2,param_3,param_4,param_5,param_6,param_7,param_8);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  *(undefined4 *)(param_1 + 0x10) = 0;
  if (uStack_40 != 0) {
    *(uint *)(param_1 + 0x10) = uStack_40;
    if ((uStack_40 & 1) == 0) {
      (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,param_1 + 0x18,0);
    }
    else {
      *(undefined4 *)(param_1 + 0x18) = uStack_38;
      *(undefined4 *)(param_1 + 0x1c) = uStack_34;
      *(undefined4 *)(param_1 + 0x20) = uStack_30;
      *(undefined4 *)(param_1 + 0x24) = uStack_2c;
      *(undefined8 *)(param_1 + 0x28) = uStack_28;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
     (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_38,2);
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = param_3[1] + -1;
    param_3[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar1 = param_3[2] + -1;
      param_3[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = 6;
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_9 & 0xfffffffe))(&param_11,&param_11,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16230 ; VA 0x00919320 ; FUN_00919320 */

int __thiscall
FUN_00919320(int param_1,undefined4 param_2,int *param_3,undefined4 param_4,undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    piVar1 = param_3 + 1;
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  piVar1 = param_3 + 1;
  if (param_3 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_0060e3f0(param_2,param_3);
  *(undefined4 *)(param_1 + 8) = param_4;
  *(undefined4 *)(param_1 + 0xc) = param_5;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar2 = param_3[2] + -1;
      param_3[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
    if (param_3 != (int *)0x0) {
      LOCK();
      iVar2 = param_3[1] + -1;
      param_3[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_3)();
        LOCK();
        iVar2 = param_3[2] + -1;
        param_3[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*param_3 + 4))();
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar2 = param_3[1] + -1;
    param_3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 16231 ; VA 0x00919430 ; FUN_00919430 */

undefined * __fastcall FUN_00919430(undefined *param_1)

{
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0xf;
  *param_1 = 0;
  *(undefined4 *)(param_1 + 0x28) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0xf;
  param_1[0x18] = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)(param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 0x40) = 0;
  return param_1;
}



/* FUNCTION 16232 ; VA 0x00919490 ; FUN_00919490 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __fastcall FUN_00919490(undefined4 *param_1)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  undefined **ppuVar4;
  undefined4 uVar5;
  undefined **ppuVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  float fStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c6db9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_1c = param_1;
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::Player,class_RBX::Instance>::vftable;
  uVar3 = FUN_00913630();
  param_1[3] = uVar3;
  LOCK();
  _DAT_01ee170c = _DAT_01ee170c + 1;
  UNLOCK();
  *param_1 = RBX::Player::vftable;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  uStack_8._0_1_ = 8;
  uStack_8._1_3_ = 0;
  FUN_016830f0(param_1 + 0x22);
  param_1[0x24] = 0xffffffff;
  param_1[0x25] = 1;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 45000;
  param_1[0x2a] = 0x1000001;
  param_1[0x2b] = 0x1000000;
  *(undefined *)(param_1 + 0x2c) = 1;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0x3f800000;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0x3f800000;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0x3f800000;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 1;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0x550aa3b2;
  param_1[0x3f] = 0;
  param_1[0x44] = 0;
  param_1[0x45] = 0xf;
  uStack_8._0_1_ = 10;
  *(undefined *)(param_1 + 0x40) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 0xb;
  param_1[0x4a] = 0;
  param_1[0x4b] = 0xf;
  *(undefined *)(param_1 + 0x46) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  param_1[0x4c] = 0;
  param_1[0x4d] = 0;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  param_1[0x50] = 0;
  param_1[0x52] = 0;
  param_1[0x5e] = 0;
  param_1[0x5f] = 0xf;
  *(undefined *)(param_1 + 0x5a) = 0;
  param_1[0x60] = 0;
  puVar1 = param_1 + 0x69;
  param_1[0x61] = 0;
  param_1[0x62] = 0x41200000;
  param_1[99] = 0x447a0000;
  *(undefined *)(param_1 + 100) = 0;
  param_1[0x65] = 0x7fc00000;
  param_1[0x66] = 0x7fc00000;
  param_1[0x67] = 0x7fc00000;
  param_1[0x68] = 1;
  uStack_8._0_1_ = 0x13;
  *puVar1 = 0;
  param_1[0x6a] = 0;
  puStack_18 = puVar1;
  uVar3 = FUN_00845d90();
  *puVar1 = uVar3;
  param_1[0x6b] = 0;
  param_1[0x6c] = 0;
  param_1[0x71] = 0;
  param_1[0x72] = 0xf;
  *(undefined *)(param_1 + 0x6d) = 0;
  param_1[0x77] = 0;
  param_1[0x78] = 0xf;
  *(undefined *)(param_1 + 0x73) = 0;
  param_1[0x7d] = 0;
  param_1[0x7e] = 0xf;
  *(undefined *)(param_1 + 0x79) = 0;
  param_1[0x83] = 0;
  param_1[0x84] = 0xf;
  *(undefined *)(param_1 + 0x7f) = 0;
  param_1[0x89] = 0;
  param_1[0x8a] = 0xf;
  *(undefined *)(param_1 + 0x85) = 0;
  uStack_8._0_1_ = 0x1a;
  param_1[0x8f] = 0;
  param_1[0x90] = 0xf;
  *(undefined *)(param_1 + 0x8b) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 0x1b;
  param_1[0x95] = 0;
  param_1[0x96] = 0xf;
  *(undefined *)(param_1 + 0x91) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  param_1[0x97] = 0;
  param_1[0x98] = 0;
  param_1[0x99] = 0x1000000;
  param_1[0x9a] = 0;
  param_1[0x9b] = 0;
  param_1[0x9c] = 0;
  param_1[0x9d] = 0xffffffff;
  param_1[0xa2] = 0;
  param_1[0xa3] = 0xf;
  *(undefined *)(param_1 + 0x9e) = 0;
  param_1[0xa8] = 0;
  param_1[0xa9] = 0xf;
  *(undefined *)(param_1 + 0xa4) = 0;
  param_1[0xae] = 0;
  param_1[0xaf] = 0xf;
  *(undefined *)(param_1 + 0xaa) = 0;
  param_1[0xb0] = 0;
  param_1[0xb1] = 0x3f800000;
  param_1[0xb2] = 0;
  param_1[0xb3] = 0;
  param_1[0xb4] = 0;
  param_1[0xb5] = 0x3f800000;
  param_1[0xb6] = 0;
  param_1[0xb7] = 0;
  param_1[0xb8] = 0;
  param_1[0xb9] = 0x3f800000;
  param_1[0xba] = 0;
  param_1[0xbb] = 0;
  param_1[0xbc] = 0;
  param_1[0xbe] = 0;
  param_1[0xbf] = 0;
  param_1[0xc0] = 0;
  param_1[0xc1] = 0;
  param_1[0xc2] = 0;
  param_1[0xc3] = 0;
  param_1[0xc4] = 0;
  *(undefined *)(param_1 + 0xc5) = 0;
  *(undefined *)(param_1 + 0xc6) = 0;
  fStack_14 = 1.54143e-44;
  ppuVar4 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&fStack_14);
  if (ppuVar4 == &boost::lock_error::vftable_meta_ptr) {
    ppuVar4 = (undefined **)&DAT_018be194;
  }
  param_1[199] = *ppuVar4;
  param_1[200] = 0;
  param_1[0xc9] = 0x3f800000;
  param_1[0xca] = 0;
  param_1[0xcb] = 0;
  uVar3 = DAT_01d6410c;
  puVar1 = param_1 + 0xcd;
  param_1[0xcc] =
       RBX::
       LRUCache<__int64,class_std::shared_ptr<class_RBX::Animation>,struct_boost::hash<__int64>_>::
       vftable;
  uStack_8._0_1_ = 0x23;
  *puVar1 = 0;
  param_1[0xce] = 0;
  puStack_18 = puVar1;
  uVar5 = FUN_005cb2b0(0,0);
  *puVar1 = uVar5;
  *(undefined *)(param_1 + 0xcf) = 0;
  fStack_14 = 1.54143e-44;
  ppuVar6 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&fStack_14);
  ppuVar4 = ppuVar6 + -1;
  if (ppuVar6 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar4 = ppuVar6;
  }
  param_1[0xd0] = *ppuVar4;
  param_1[0xd1] = 0;
  param_1[0xd2] = 0x3f800000;
  param_1[0xd3] = 0;
  param_1[0xd4] = 0;
  param_1[0xd5] = 0;
  param_1[0xcc] =
       RBX::
       SizeEnforcedLRUCache<__int64,class_std::shared_ptr<class_RBX::Animation>,struct_boost::hash<__int64>_>
       ::vftable;
  param_1[0xd6] = uVar3;
  param_1[0xd7] = 0;
  param_1[0xd8] = 0;
  puVar1 = param_1 + 0xd9;
  uStack_8._0_1_ = 0x25;
  *puVar1 = 0;
  param_1[0xda] = 0;
  puStack_18 = puVar1;
  uVar3 = FUN_008ed990(0,0);
  *puVar1 = uVar3;
  param_1[0xdb] = 0;
  param_1[0xdc] = 0;
  param_1[0xdd] = 0;
  param_1[0xde] = 0;
  uStack_8._0_1_ = 0x28;
  FUN_01682800(param_1 + 0xe0);
  param_1[0xe2] = 0;
  param_1[0xe3] = 0;
  param_1[0xe4] = 0;
  param_1[0xe5] = 0;
  param_1[0xe6] = 0;
  param_1[0xe7] = 0;
  param_1[0xe8] = 0;
  param_1[0xe9] = 0;
  param_1[0xea] = 0;
  param_1[0xeb] = 0;
  param_1[0xec] = 0;
  param_1[0xed] = 0;
  param_1[0xee] = 0;
  param_1[0xef] = 0;
  param_1[0xf0] = 0;
  param_1[0xf1] = 0;
  param_1[0xf2] = 0;
  param_1[0xf3] = 0;
  param_1[0xf4] = 0;
  param_1[0xf5] = 0;
  param_1[0xf6] = 0;
  param_1[0xf7] = 0;
  param_1[0xf8] = 0;
  param_1[0xf9] = 0;
  param_1[0xfa] = 0;
  param_1[0xfb] = 0;
  param_1[0xfc] = 0;
  param_1[0xfd] = 0;
  param_1[0xfe] = 0;
  param_1[0xff] = 0;
  param_1[0x100] = 0;
  param_1[0x101] = 0;
  fStack_14 = (float)DAT_01ee1b60;
  uStack_8._0_1_ = 0x3b;
  puStack_18 = (undefined4 *)(float)DAT_01ee1b64;
  FUN_016830f0(param_1 + 0x102);
  param_1[0x105] = fStack_14;
  param_1[0x106] = puStack_18;
  param_1[0x104] = 0;
  puStack_18 = (undefined4 *)(float)DAT_01ee1b6c;
  fStack_14 = (float)DAT_01ee1b68;
  FUN_016830f0(param_1 + 0x108);
  param_1[0x10b] = puStack_18;
  param_1[0x10c] = puStack_18;
  param_1[0x10d] = fStack_14;
  param_1[0x10a] = 0;
  param_1[0x10e] = 0;
  param_1[0x10f] = 0;
  param_1[0x110] = 0;
  *(undefined *)(param_1 + 0x111) = 0;
  *(undefined8 *)(param_1 + 0x112) = 0;
  param_1[0x114] = 0;
  param_1[0x115] = 0;
  param_1[0x11a] = 0;
  param_1[0x11b] = 0xf;
  *(undefined *)(param_1 + 0x116) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8._0_1_ = 0x3c;
  param_1[0x120] = 0;
  param_1[0x121] = 0xf;
  *(undefined *)(param_1 + 0x11c) = 0;
  FUN_005542c0(&DAT_018bc9b8,0);
  param_1[0x122] = 0;
  param_1[0x123] = 0;
  param_1[0x124] = 0;
  param_1[0x125] = 0;
  param_1[0x126] = 0;
  param_1[0x127] = 0;
  param_1[0x128] = 0x42c80000;
  param_1[0x129] = 0x42c80000;
  iVar7 = DAT_01d67a50;
  param_1[299] = 0x3f000000;
  param_1[300] = 0;
  param_1[0x12d] = 0;
  param_1[0x12e] = 0;
  param_1[0x12f] = 0;
  param_1[0x130] = 0;
  param_1[0x131] = 0x10000;
  param_1[0x132] = 0;
  param_1[0x12a] = (float)iVar7;
  param_1[0x137] = 0;
  param_1[0x138] = 0xf;
  *(undefined *)(param_1 + 0x133) = 0;
  param_1[0x13d] = 0;
  param_1[0x13e] = 0xf;
  *(undefined *)(param_1 + 0x139) = 0;
  param_1[0x13f] = 0;
  param_1[0x140] = 0;
  param_1[0x141] = 0;
  param_1[0x142] = 0;
  param_1[0x143] = 0;
  puVar1 = param_1 + 0x144;
  uStack_8._0_1_ = 0x40;
  *puVar1 = 0;
  param_1[0x145] = 0;
  param_1[0x146] = 0;
  puStack_18 = puVar1;
  uVar3 = FUN_005e9aa0(0,0);
  param_1[0x145] = uVar3;
  param_1[0x147] = 0;
  param_1[0x148] = 0;
  param_1[0x149] = 0;
  uStack_8._0_1_ = 0x42;
  *puVar1 = 0x3f800000;
  FUN_005cb500(8);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x43);
  FUN_0054d840(param_1);
  *(undefined8 *)(param_1 + 0x14e) = 0;
  uVar3 = FUN_01255560();
  cVar2 = FUN_01255580(uVar3,4);
  if (cVar2 == '\0') {
    FUN_01255600(4,"create a Player");
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = auStack_34[0] & 0xffffff00;
  FUN_005542c0("Player",6);
  uStack_8 = CONCAT31(uStack_8._1_3_,0x44);
  uVar3 = FUN_01255560();
  cVar2 = FUN_01255580(uVar3,4);
  if (cVar2 == '\0') {
    FUN_01255600(4,"set a Player\'s name");
  }
  FUN_008a6520(auStack_34);
  iVar7 = FUN_009171d0(param_1);
  if (iVar7 != 0) {
    FUN_00a3e1e0(auStack_34);
  }
  if (0xf < uStack_20) {
    uVar9 = uStack_20 + 1;
    uVar8 = auStack_34[0];
    if (0xfff < uVar9) {
      uVar8 = *(uint *)(auStack_34[0] - 4);
      uVar9 = uStack_20 + 0x24;
      if (0x1f < (auStack_34[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar9);
  }
  if (DAT_01d6422c != '\0') {
    param_1[0x62] = (float)DAT_01d64144;
    param_1[99] = (float)DAT_01d6414c;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16233 ; VA 0x0091a050 ; FUN_0091a050 */

undefined4 * __thiscall FUN_0091a050(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  uStack_c = param_2;
  *param_1 = std::exception::vftable;
  *(undefined8 *)(param_1 + 1) = 0;
  _uStack_8 = CONCAT31((int3)((uint)param_1 >> 8),1);
  FUN_0170c226(&uStack_c,param_1 + 1);
  *param_1 = std::out_of_range::vftable;
  return param_1;
}



/* FUNCTION 16234 ; VA 0x0091a0a0 ; FUN_0091a0a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0091a0a0(void)

{
  LOCK();
  _DAT_01ee170c = _DAT_01ee170c + -1;
  UNLOCK();
  return;
}



/* FUNCTION 16235 ; VA 0x0091a0b0 ; FUN_0091a0b0 */

void __fastcall FUN_0091a0b0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Player>::vftable;
  uVar1 = FUN_00913630(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16236 ; VA 0x0091a0f0 ; FUN_0091a0f0 */

void __fastcall FUN_0091a0f0(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  *param_1 = RBX::
             LRUCache<__int64,class_std::shared_ptr<class_RBX::Animation>,struct_boost::hash<__int64>_>
             ::vftable;
  FUN_0091ec60();
  if (param_1[5] != 0) {
    puVar1 = (undefined4 *)(param_1[8] + param_1[4] * 4);
    puVar2 = (undefined4 *)*puVar1;
    do {
      *puVar1 = *puVar2;
      FUN_01674ea0(puVar2,0x18);
      param_1[5] = param_1[5] + -1;
      puVar2 = (undefined4 *)*puVar1;
    } while (puVar2 != (undefined4 *)0x0);
    puVar2 = (undefined4 *)param_1[8];
    puVar1 = puVar2 + param_1[4];
    for (; puVar2 != puVar1; puVar2 = puVar2 + 1) {
      *puVar2 = 0;
    }
  }
  param_1[9] = 0;
  FUN_0056d250();
  FUN_0091ec60();
  FUN_01674ea0(param_1[1],0x20);
  return;
}



/* FUNCTION 16237 ; VA 0x0091a180 ; FUN_0091a180 */

void __fastcall FUN_0091a180(undefined4 *param_1)

{
  *param_1 = RBX::
             SizeEnforcedLRUCache<__int64,class_std::shared_ptr<class_RBX::Animation>,struct_boost::hash<__int64>_>
             ::vftable;
  FUN_0091a0f0();
  return;
}



/* FUNCTION 16238 ; VA 0x0091a190 ; FUN_0091a190 */

void FUN_0091a190(void)

{
  FUN_0091a340();
  return;
}



/* FUNCTION 16239 ; VA 0x0091a1a0 ; FUN_0091a1a0 */

void __fastcall FUN_0091a1a0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = param_1[1];
  if (iVar1 != 0) {
    if (*(char *)((int)param_1 + 9) != '\0') {
      FUN_00916a50(*param_1,iVar1 + 8);
      iVar1 = param_1[1];
    }
    FUN_01674ea0(iVar1,0x24);
  }
  return;
}



/* FUNCTION 16240 ; VA 0x0091a1d0 ; FUN_0091a1d0 */

void __fastcall FUN_0091a1d0(undefined4 *param_1)

{
  char cVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = boost::exception_detail::error_info_injector<class_std::out_of_range>::vftable;
  param_1[3] = boost::exception::vftable;
  uStack_8 = 0;
  if ((int *)param_1[4] != (int *)0x0) {
    cVar1 = (**(code **)(*(int *)param_1[4] + 0x10))();
    if (cVar1 != '\0') {
      param_1[4] = 0;
    }
  }
  *param_1 = std::exception::vftable;
  FUN_0170c289(param_1 + 1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16241 ; VA 0x0091a240 ; thunk_FUN_0091a340 */

code * __fastcall thunk_FUN_0091a340(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  code *pcVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar6 = *(code **)(param_1 + 0x10);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar6 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar6 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x18,param_1 + 0x18,2);
      }
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  piVar5 = *(int **)(param_1 + 4);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      pcVar6 = (code *)(**(code **)*piVar5)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 16242 ; VA 0x0091a250 ; FUN_0091a250 */

void __fastcall FUN_0091a250(undefined4 *param_1)

{
  FUN_0091ecd0();
  FUN_01674ea0(*param_1,0x28);
  return;
}



/* FUNCTION 16243 ; VA 0x0091a270 ; FUN_0091a270 */

void __fastcall FUN_0091a270(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0091d080(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  FUN_01674ea0(*param_1,0x38);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16244 ; VA 0x0091a2d0 ; FUN_0091a2d0 */

void FUN_0091a2d0(void)

{
  FUN_016790b0();
  FUN_016790b0();
  return;
}



/* FUNCTION 16245 ; VA 0x0091a2f0 ; FUN_0091a2f0 */

void __fastcall FUN_0091a2f0(undefined4 *param_1)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_0072e210();
  FUN_01674ea0(*param_1,0x18);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16246 ; VA 0x0091a340 ; FUN_0091a340 */

code * __fastcall FUN_0091a340(int param_1)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int *piVar5;
  code *pcVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  pcVar6 = *(code **)(param_1 + 0x10);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar6 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar6 & 1) == 0) {
      pcVar6 = *(code **)((uint)pcVar6 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar6 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar6 = (code *)(*pcVar6)(param_1 + 0x18,param_1 + 0x18,2);
      }
    }
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  piVar5 = *(int **)(param_1 + 4);
  if (piVar5 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar5 + 1);
    uVar3 = *puVar1;
    pcVar6 = (code *)*puVar1;
    *puVar1 = uVar3 - 1;
    UNLOCK();
    if (uVar3 - 1 == 0) {
      pcVar6 = (code *)(**(code **)*piVar5)();
      LOCK();
      piVar2 = piVar5 + 2;
      iVar4 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        pcVar6 = (code *)(**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return pcVar6;
}



/* FUNCTION 16247 ; VA 0x0091a3d0 ; FUN_0091a3d0 */

void __fastcall FUN_0091a3d0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  if (*(int *)(param_1 + 0x14) != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      puVar7 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar7;
        uVar6 = puVar7[8];
        if (0xf < uVar6) {
          iVar2 = puVar7[3];
          uVar5 = uVar6 + 1;
          iVar3 = iVar2;
          if (0xfff < uVar5) {
            iVar3 = *(int *)(iVar2 + -4);
            uVar5 = uVar6 + 0x24;
            if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_0091a48d;
          }
          FUN_01674ea0(iVar3,uVar5);
        }
        puVar7[7] = 0;
        puVar7[8] = 0xf;
        *(undefined *)(puVar7 + 3) = 0;
        FUN_01674ea0(puVar7,0x24);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar3 = *(int *)(param_1 + 0x14);
    iVar4 = iVar3;
    if (0xfff < uVar6) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
LAB_0091a48d:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 16248 ; VA 0x0091a4a0 ; FUN_0091a4a0 */

void __fastcall FUN_0091a4a0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      ExceptionList = &pvStack_10;
      do {
        *puVar1 = *puVar6;
        FUN_00916ab0(-(uint)(param_1 != -3) & param_1 + 4U,puVar6 + 2);
        FUN_01674ea0(puVar6,0x28);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16249 ; VA 0x0091a570 ; FUN_0091a570 */

void __fastcall FUN_0091a570(int *param_1)

{
  if (*param_1 != 0) {
    FUN_01674ea0(*param_1,0x40);
  }
  return;
}


