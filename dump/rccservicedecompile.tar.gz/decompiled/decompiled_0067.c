/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 16750 ; VA 0x00935260 ; FUN_00935260 */

void __thiscall FUN_00935260(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00935b10();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16751 ; VA 0x009352b0 ; FUN_009352b0 */

void __thiscall FUN_009352b0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_005f3000();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16752 ; VA 0x00935300 ; FUN_00935300 */

void __thiscall FUN_00935300(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_005f3120();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16753 ; VA 0x00935350 ; FUN_00935350 */

void __thiscall FUN_00935350(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00935ba0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16754 ; VA 0x009353a0 ; FUN_009353a0 */

void __thiscall FUN_009353a0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00935c30();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16755 ; VA 0x009353f0 ; FUN_009353f0 */

void __thiscall FUN_009353f0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00935cc0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16756 ; VA 0x00935440 ; FUN_00935440 */

void __thiscall FUN_00935440(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00935d50();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16757 ; VA 0x00935490 ; FUN_00935490 */

void __thiscall FUN_00935490(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00935de0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16758 ; VA 0x009354e0 ; FUN_009354e0 */

void __thiscall FUN_009354e0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_005f32d0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16759 ; VA 0x00935530 ; FUN_00935530 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint __thiscall FUN_00935530(uint param_1,uint param_2,int *param_3)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  uint *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  int iVar8;
  uint uVar9;
  int iVar10;
  undefined **ppuVar11;
  undefined *puVar12;
  undefined **ppuVar13;
  undefined *puVar14;
  uint uVar15;
  uint *puVar16;
  float10 fVar17;
  uint uStack_80;
  uint uStack_7c;
  uint uStack_78;
  uint uStack_74;
  uint uStack_70;
  undefined *puStack_6c;
  undefined8 uStack_68;
  undefined auStack_58 [4];
  undefined *puStack_54;
  int iStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  int iStack_44;
  double dStack_40;
  undefined4 uStack_38;
  int *piStack_34;
  undefined *puStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint *puStack_24;
  undefined4 *puStack_20;
  uint *puStack_1c;
  uint uStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017c95e8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  uStack_18 = param_1;
  if (param_1 == 0) goto LAB_009355b9;
  uVar15 = *(uint *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (uVar15 == 0) {
LAB_00935570:
    uVar15 = param_1;
  }
  else {
    ExceptionList = &pvStack_10;
    if (*(int *)(uVar15 + 0x34) != 0) {
      uStack_68 = (double)CONCAT44(0x935570,(undefined4)uStack_68);
      ExceptionList = &pvStack_10;
      param_1 = FUN_005c8ac0();
      goto LAB_00935570;
    }
  }
  if (uVar15 != 0) {
    iVar10 = *(int *)(uVar15 + 0xc);
    uStack_68 = (double)CONCAT44(0x93557e,(undefined4)uStack_68);
    iVar8 = FUN_008a8c30();
    param_1 = (uint)*(ushort *)(iVar8 + 0x1da);
    if ((uint)*(ushort *)(iVar10 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8) <= param_1) {
      uStack_68 = (double)CONCAT44(0x9355a0,(undefined4)uStack_68);
      param_1 = FUN_00634d90();
      if (param_1 != 0) {
        uStack_68 = (double)CONCAT44(0x9355ab,(undefined4)uStack_68);
        param_1 = FUN_00b83620();
        if ((char)param_1 != '\0') {
          uStack_68 = 2.12676635890225e-314;
          param_1 = FUN_009c2d10();
        }
      }
    }
  }
LAB_009355b9:
  uVar9 = uStack_18;
  uStack_68 = (double)CONCAT44(CONCAT31((int3)(param_1 >> 8),*(undefined *)(uStack_18 + 0x267)),
                               0x9355cb);
  FUN_009c2d70();
  uVar15 = *(uint *)(uVar9 + 0x34);
  if ((uVar15 != 0) && (uVar9 = uVar15, *(int *)(uVar15 + 0x34) != 0)) {
    uStack_68 = (double)CONCAT44(0x9355de,(undefined4)uStack_68);
    uVar9 = FUN_005c8ac0();
  }
  if (uVar9 != 0) {
    iVar10 = *(int *)(uVar9 + 0xc);
    uStack_68 = (double)CONCAT44(0x9355f4,(undefined4)uStack_68);
    iVar8 = FUN_008a8c30();
    if ((uint)*(ushort *)(iVar10 + 0x1d8) - (uint)*(ushort *)(iVar8 + 0x1d8) <=
        (uint)*(ushort *)(iVar8 + 0x1da)) {
      uStack_68 = (double)CONCAT44(0x93561a,(undefined4)uStack_68);
      iVar10 = FUN_00562f00();
      if (iVar10 != 0) {
        piVar1 = (int *)(iVar10 + 0x144);
        uStack_68 = (double)CONCAT44(0x93562d,(undefined4)uStack_68);
        iVar10 = (**(code **)(*piVar1 + 4))();
        if (iVar10 != 0) {
          uStack_68 = (double)CONCAT44(0x93563a,(undefined4)uStack_68);
          (**(code **)(*piVar1 + 4))();
          uStack_68 = (double)CONCAT44(0x935641,(undefined4)uStack_68);
          iVar10 = FUN_00d215f0();
          if (iVar10 == 0) {
            uStack_68 = (double)CONCAT44(0x93564e,(undefined4)uStack_68);
            (**(code **)(*piVar1 + 4))();
            uStack_68 = (double)CONCAT44(param_2,0x935658);
            FUN_00d24b00();
            uStack_68 = (double)CONCAT44(0x935661,(undefined4)uStack_68);
            (**(code **)(*piVar1 + 4))();
            uStack_68 = 1.0614749610213e-313;
            FUN_00d24d00();
            uStack_68 = (double)CONCAT44(0x935673,(undefined4)uStack_68);
            (**(code **)(*piVar1 + 4))();
            uStack_68 = 4194304.008992793;
            FUN_00d24fe0();
            uStack_68 = (double)CONCAT44(0x93568b,(undefined4)uStack_68);
            (**(code **)(*piVar1 + 4))();
            uStack_68 = -0.007812500016750424;
            FUN_00d27430();
          }
        }
      }
    }
  }
  puVar3 = *(undefined4 **)(param_2 + 0x2c);
  if (puVar3 != (undefined4 *)0x0) {
    puVar4 = (uint *)puVar3[1];
    for (puVar16 = (uint *)*puVar3; puVar16 != puVar4; puVar16 = puVar16 + 2) {
      param_2 = *puVar16;
      uStack_2c = param_2;
      if (param_2 != 0) {
        uStack_28 = *(uint *)(param_2 + 0xc);
        uStack_68 = (double)CONCAT44(0x9356cc,(undefined4)uStack_68);
        iVar10 = FUN_00e2c3f0();
        uVar15 = uStack_2c;
        param_2 = (uint)*(ushort *)(iVar10 + 0x1da);
        if ((uint)*(ushort *)(uStack_28 + 0x1d8) - (uint)*(ushort *)(iVar10 + 0x1d8) <= param_2) {
          if (uStack_2c != 0) {
            puStack_30 = auStack_58;
            iVar10 = uStack_2c + 0x220;
            auStack_58[0] = 0;
            uStack_68 = ((double)*(int *)(uStack_2c + 0x228) +
                        (double)(&DAT_018c0d90)[-(*(int *)(uStack_2c + 0x228) >> 0x1f)]) /
                        (double)*(float *)(uStack_2c + 0x22c);
            puStack_6c = (undefined *)0x93574a;
            dStack_40 = uStack_68;
            fVar17 = (float10)FUN_01725280();
            dStack_40 = (double)fVar17;
            if (dStack_40 + DAT_018c0d60 < _DAT_018c4e98) {
              uStack_68 = (double)CONCAT44(0x935771,(undefined4)uStack_68);
              uStack_28 = FUN_016f3eb1();
            }
            else {
              uStack_28 = 0xffffffff;
            }
            uStack_68 = (double)CONCAT44(&uStack_28,&boost::lock_error::vftable_meta_ptr);
            puStack_6c = &DAT_018be100;
            uStack_70 = 0x935787;
            ppuVar11 = (undefined **)FUN_00563d40();
            uStack_4c = *(undefined4 *)(uVar15 + 0x22c);
            ppuVar13 = ppuVar11 + -1;
            if (ppuVar11 != &boost::lock_error::vftable_meta_ptr) {
              ppuVar13 = ppuVar11;
            }
            puStack_54 = *ppuVar13;
            iStack_50 = 0;
            uStack_48 = 0;
            iStack_44 = 0;
            uStack_8 = 1;
            uStack_68 = (double)CONCAT44(iVar10,0x9357c6);
            FUN_00928cb0();
            if (iStack_50 == 0) {
              puStack_20 = (undefined4 *)0x0;
            }
            else {
              puStack_20 = *(undefined4 **)(iStack_44 + (int)puStack_54 * 4);
            }
            for (; puStack_20 != (undefined4 *)0x0; puStack_20 = (undefined4 *)*puStack_20) {
              uStack_8 = 2;
              puStack_1c = puStack_20 + 3;
              uStack_68 = (double)CONCAT44(puStack_1c,&dStack_40);
              puStack_6c = (undefined *)0x9357fa;
              FUN_00e2ff10();
              puVar6 = dStack_40._0_4_;
              uStack_8 = 3;
              puVar3 = (undefined4 *)*dStack_40._0_4_;
              while (puVar3 != puVar6) {
                puStack_24 = (uint *)puVar3[4];
                uStack_28 = puVar3[5];
                uStack_68 = *(double *)(puVar3 + 4);
                if (DAT_01d63f08 == '\0') {
                  uStack_68 = (double)CONCAT44(uStack_18,&uStack_38);
                  puStack_6c = (undefined *)0x935918;
                  FUN_0060e0c0();
                  puStack_30 = (undefined *)&uStack_80;
                  _uStack_8 = CONCAT31(uStack_7,4);
                  if (piStack_34 != (int *)0x0) {
                    LOCK();
                    piStack_34[2] = piStack_34[2] + 1;
                    UNLOCK();
                    LOCK();
                    piStack_34[2] = piStack_34[2] + 1;
                    UNLOCK();
                  }
                  FUN_009129c0(uStack_38,piStack_34,0);
                  if (piStack_34 != (int *)0x0) {
                    LOCK();
                    iVar10 = piStack_34[2] + -1;
                    piStack_34[2] = iVar10;
                    UNLOCK();
                    if (iVar10 == 0) {
                      (**(code **)(*piStack_34 + 4))();
                    }
                  }
                  FUN_0091ed60(puStack_24,uStack_28);
                  uStack_8 = 3;
                  if (piStack_34 != (int *)0x0) {
                    LOCK();
                    iVar10 = piStack_34[2] + -1;
                    piStack_34[2] = iVar10;
                    UNLOCK();
                    if (iVar10 == 0) {
                      uStack_68 = (double)CONCAT44(0x935997,(undefined4)uStack_68);
                      (**(code **)(*piStack_34 + 4))();
                    }
                  }
                }
                else {
                  puStack_14 = &uStack_80;
                  uStack_70 = 0;
                  puStack_6c = (undefined *)0x0;
                  uStack_28 = puStack_1c[4];
                  puStack_24 = puStack_1c;
                  if (0xf < puStack_1c[5]) {
                    puStack_24 = (uint *)*puStack_1c;
                  }
                  if (uStack_28 < 0x10) {
                    uStack_80 = *puStack_24;
                    uStack_7c = puStack_24[1];
                    uStack_78 = puStack_24[2];
                    uStack_74 = puStack_24[3];
                    puStack_6c = (undefined *)0xf;
                    uStack_70 = uStack_28;
                    puStack_14 = &uStack_80;
                    FUN_0092fd40();
                  }
                  else {
                    puStack_30 = (undefined *)(uStack_28 | 0xf);
                    if ((undefined *)0x7fffffff < puStack_30) {
                      puStack_30 = (undefined *)0x7fffffff;
                    }
                    puVar14 = puStack_30 + 1;
                    if (puVar14 < &DAT_00001000) {
                      if (puVar14 == (undefined *)0x0) {
                        uVar15 = 0;
                        puStack_14 = &uStack_80;
                      }
                      else {
                        uVar15 = FUN_01674e20(puVar14);
                      }
                    }
                    else {
                      puVar12 = puStack_30 + 0x24;
                      if (puVar12 <= puVar14) {
                        puVar12 = (undefined *)0xffffffff;
                      }
                      puStack_14 = &uStack_80;
                      iVar10 = FUN_01674e20(puVar12);
                      if (iVar10 == 0) {
                    /* WARNING: Subroutine does not return */
                        FUN_017167a3();
                      }
                      uVar15 = iVar10 + 0x23U & 0xffffffe0;
                      *(int *)(uVar15 - 4) = iVar10;
                    }
                    *puStack_14 = uVar15;
                    FUN_0170c6f0(uVar15,puStack_24,uStack_28 + 1);
                    puVar4 = puStack_14;
                    puStack_14[4] = uStack_28;
                    puVar4[5] = (uint)puStack_30;
                    FUN_0092fd40();
                  }
                }
                puVar5 = (undefined4 *)puVar3[2];
                if (*(char *)((int)puVar5 + 0xd) == '\0') {
                  cVar2 = *(char *)((int)*puVar5 + 0xd);
                  puVar3 = puVar5;
                  puVar5 = (undefined4 *)*puVar5;
                  while (cVar2 == '\0') {
                    cVar2 = *(char *)((int)*puVar5 + 0xd);
                    puVar3 = puVar5;
                    puVar5 = (undefined4 *)*puVar5;
                  }
                }
                else {
                  cVar2 = *(char *)((int)puVar3[1] + 0xd);
                  puVar7 = (undefined4 *)puVar3[1];
                  puVar5 = puVar3;
                  while ((puVar3 = puVar7, cVar2 == '\0' && (puVar5 == (undefined4 *)puVar3[2]))) {
                    cVar2 = *(char *)((int)puVar3[1] + 0xd);
                    puVar7 = (undefined4 *)puVar3[1];
                    puVar5 = puVar3;
                  }
                }
              }
              uStack_8 = 5;
              uStack_68 = (double)CONCAT44(0x9359f0,(undefined4)uStack_68);
              FUN_0072e210();
              uStack_68 = (double)CONCAT44(0x18,dStack_40._0_4_);
              puStack_6c = (undefined *)0x9359fa;
              FUN_01674ea0();
            }
            uStack_8 = 2;
            uStack_68 = (double)CONCAT44(0x935a1d,(undefined4)uStack_68);
            param_2 = FUN_0091a3d0();
          }
          break;
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar4 = (uint *)(param_3 + 1);
    uVar15 = *puVar4;
    param_2 = *puVar4;
    *puVar4 = uVar15 - 1;
    UNLOCK();
    if (uVar15 - 1 == 0) {
      uStack_68 = (double)CONCAT44(0x935a36,(undefined4)uStack_68);
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar10 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar10 == 1) {
        uStack_68 = (double)CONCAT44(0x935a45,(undefined4)uStack_68);
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16760 ; VA 0x00935a60 ; FUN_00935a60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00935a60(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9616;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee1f0c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee1f0c);
    if (DAT_01ee1f0c == -1) {
      uStack_8 = 0;
      FUN_009ca470("AvatarContextMenuOption");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee1ea8 = RBX::Reflection::EnumDesc<enum_RBX::Player::AvatarContextMenuOption>::vftable;
      FUN_009caf20(&DAT_01d642e0,4);
      FUN_016f3654(&LAB_01884980);
      FUN_016f37bf(&DAT_01ee1f0c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee1ea8;
}



/* FUNCTION 16761 ; VA 0x00935b10 ; FUN_00935b10 */

undefined * FUN_00935b10(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c962c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee21f4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee21f4);
    if (DAT_01ee21f4 == -1) {
      uStack_8 = 0;
      FUN_00d1f1a0();
      FUN_016f3654(&LAB_018849a0);
      FUN_016f37bf(&DAT_01ee21f4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee2190;
}



/* FUNCTION 16762 ; VA 0x00935ba0 ; FUN_00935ba0 */

undefined * FUN_00935ba0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c964c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee20bc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee20bc);
    if (DAT_01ee20bc == -1) {
      uStack_8 = 0;
      FUN_00bb2cc0();
      FUN_016f3654(&LAB_018849c0);
      FUN_016f37bf(&DAT_01ee20bc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee2058;
}



/* FUNCTION 16763 ; VA 0x00935c30 ; FUN_00935c30 */

undefined * FUN_00935c30(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c966c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee2124) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee2124);
    if (DAT_01ee2124 == -1) {
      uStack_8 = 0;
      FUN_00bb2d20();
      FUN_016f3654(&LAB_018849e0);
      FUN_016f37bf(&DAT_01ee2124);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee20c0;
}



/* FUNCTION 16764 ; VA 0x00935cc0 ; FUN_00935cc0 */

undefined * FUN_00935cc0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c968c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee1fec) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee1fec);
    if (DAT_01ee1fec == -1) {
      uStack_8 = 0;
      FUN_00bb2d80();
      FUN_016f3654(&LAB_01884a00);
      FUN_016f37bf(&DAT_01ee1fec);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee1f88;
}



/* FUNCTION 16765 ; VA 0x00935d50 ; FUN_00935d50 */

undefined * FUN_00935d50(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c96ac;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee218c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee218c);
    if (DAT_01ee218c == -1) {
      uStack_8 = 0;
      FUN_00bb2de0();
      FUN_016f3654(&LAB_01884a20);
      FUN_016f37bf(&DAT_01ee218c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee2128;
}



/* FUNCTION 16766 ; VA 0x00935de0 ; FUN_00935de0 */

undefined * FUN_00935de0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c96cc;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee2054) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee2054);
    if (DAT_01ee2054 == -1) {
      uStack_8 = 0;
      FUN_00bb2e40();
      FUN_016f3654(&LAB_01884a40);
      FUN_016f37bf(&DAT_01ee2054);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee1ff0;
}



/* FUNCTION 16767 ; VA 0x00935e70 ; FUN_00935e70 */

undefined * FUN_00935e70(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c96ec;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee225c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee225c);
    if (DAT_01ee225c == -1) {
      uStack_8 = 0;
      FUN_00becc20();
      FUN_016f3654(&LAB_01884a60);
      FUN_016f37bf(&DAT_01ee225c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee21f8;
}



/* FUNCTION 16768 ; VA 0x00935f00 ; FUN_00935f00 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00935f00(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee228c) {
    FUN_016f3809(&DAT_01ee228c);
    if (DAT_01ee228c == -1) {
      _DAT_01ee2280 = FUN_005c65e0;
      _DAT_01ee2284 = FUN_005c65e0;
      _DAT_01ee2288 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee228c);
    }
  }
  return &DAT_01ee2280;
}



/* FUNCTION 16769 ; VA 0x00935f70 ; FUN_00935f70 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00935f70(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee22bc) {
    FUN_016f3809(&DAT_01ee22bc);
    if (DAT_01ee22bc == -1) {
      _DAT_01ee22b0 = FUN_005c65e0;
      _DAT_01ee22b4 = FUN_005c65e0;
      _DAT_01ee22b8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee22bc);
    }
  }
  return &DAT_01ee22b0;
}



/* FUNCTION 16770 ; VA 0x00935ff0 ; FUN_00935ff0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00935ff0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee22ac) {
    FUN_016f3809(&DAT_01ee22ac);
    if (DAT_01ee22ac == -1) {
      _DAT_01ee22a0 = FUN_005c65e0;
      _DAT_01ee22a4 = FUN_005c65e0;
      _DAT_01ee22a8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee22ac);
    }
  }
  return &DAT_01ee22a0;
}



/* FUNCTION 16771 ; VA 0x00936060 ; FUN_00936060 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00936060(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee22dc) {
    FUN_016f3809(&DAT_01ee22dc);
    if (DAT_01ee22dc == -1) {
      _DAT_01ee22d0 = FUN_005c65e0;
      _DAT_01ee22d4 = FUN_005c65e0;
      _DAT_01ee22d8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee22dc);
    }
  }
  return &DAT_01ee22d0;
}



/* FUNCTION 16772 ; VA 0x009360d0 ; FUN_009360d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009360d0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee229c) {
    FUN_016f3809(&DAT_01ee229c);
    if (DAT_01ee229c == -1) {
      _DAT_01ee2290 = FUN_005c65e0;
      _DAT_01ee2294 = FUN_005c65e0;
      _DAT_01ee2298 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee229c);
    }
  }
  return &DAT_01ee2290;
}



/* FUNCTION 16773 ; VA 0x00936140 ; FUN_00936140 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00936140(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee22cc) {
    FUN_016f3809(&DAT_01ee22cc);
    if (DAT_01ee22cc == -1) {
      _DAT_01ee22c0 = FUN_005c65e0;
      _DAT_01ee22c4 = FUN_005c65e0;
      _DAT_01ee22c8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee22cc);
    }
  }
  return &DAT_01ee22c0;
}



/* FUNCTION 16774 ; VA 0x009361b0 ; FUN_009361b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_009361b0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee227c) {
    FUN_016f3809(&DAT_01ee227c);
    if (DAT_01ee227c == -1) {
      _DAT_01ee2270 = FUN_005c65e0;
      _DAT_01ee2274 = FUN_005c65e0;
      _DAT_01ee2278 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee227c);
    }
  }
  return &DAT_01ee2270;
}



/* FUNCTION 16775 ; VA 0x00936220 ; FUN_00936220 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00936220(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee230c) {
    FUN_016f3809(&DAT_01ee230c);
    if (DAT_01ee230c == -1) {
      _DAT_01ee2300 = FUN_005c65e0;
      _DAT_01ee2304 = FUN_005c65e0;
      _DAT_01ee2308 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee230c);
    }
  }
  return &DAT_01ee2300;
}



/* FUNCTION 16776 ; VA 0x00936290 ; FUN_00936290 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00936290(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee226c) {
    FUN_016f3809(&DAT_01ee226c);
    if (DAT_01ee226c == -1) {
      _DAT_01ee2260 = FUN_005c65e0;
      _DAT_01ee2264 = FUN_005c65e0;
      _DAT_01ee2268 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee226c);
    }
  }
  return &DAT_01ee2260;
}



/* FUNCTION 16777 ; VA 0x00936300 ; FUN_00936300 */

void __thiscall
FUN_00936300(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined auStack_c [8];
  
  FUN_008f7870(param_1);
  if ((char)param_4 != '\0') {
    FUN_005e5570(auStack_c,&param_2,param_4);
    return;
  }
  FUN_00923b40(&param_2);
  return;
}



/* FUNCTION 16778 ; VA 0x00936350 ; FUN_00936350 */

void __thiscall FUN_00936350(int *param_1,float param_2)

{
  code *pcVar1;
  float fVar2;
  float fVar3;
  undefined4 uStack_f4;
  undefined4 uStack_f0;
  float fStack_ec;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9721;
  pvStack_10 = ExceptionList;
  fVar2 = DAT_018ce2f8;
  if (DAT_018ce2f8 <= param_2) {
    fVar2 = param_2;
  }
  fVar3 = (float)param_1[99];
  if (fVar2 <= (float)param_1[99]) {
    fVar3 = fVar2;
  }
  if ((NAN(fVar3) || NAN((float)param_1[0x62])) == (fVar3 == (float)param_1[0x62])) {
    uStack_24 = 0;
    uStack_20 = 0;
    ExceptionList = &pvStack_10;
    FUN_0091b810(fVar3);
    pcVar1 = *(code **)(*param_1 + 8);
    uStack_f4 = FUN_0088c960();
    uStack_f0 = 0;
    fStack_ec = fVar3;
    uStack_f0 = FUN_00630820();
    uStack_8 = 0;
    uStack_1c = 0;
    uStack_18 = 0;
    uStack_14 = 0;
    FUN_00687980(&uStack_f4,&uStack_24,fVar3);
    uStack_8._0_1_ = 1;
    (*pcVar1)(&DAT_0211e9d8,&uStack_1c,&uStack_24);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00577b20();
    uStack_8 = 0xffffffff;
    FUN_016f32d1(&uStack_f4,0xd0,1,FUN_0056e5b0);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16779 ; VA 0x00936480 ; FUN_00936480 */

void FUN_00936480(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined auStack_10 [12];
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00961580();
    iVar3 = 0;
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      iVar3 = param_1;
    }
    if (iVar3 == 0) {
      FUN_016756b0(auStack_10,"Parent of Player can not be changed");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_10,&DAT_01c17198);
    }
  }
  return;
}



/* FUNCTION 16780 ; VA 0x009364f0 ; FUN_009364f0 */

void __thiscall FUN_009364f0(int param_1,uint param_2)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  uint in_stack_00000024;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c9748;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  if (*(char *)(param_1 + 0xa9) == '\0') {
    iVar1 = *(int *)(param_1 + 0x364);
    puVar2 = *(undefined4 **)(iVar1 + 4);
    ExceptionList = &pvStack_10;
    uVar3 = FUN_00913730(iVar1,puVar2,&param_2);
    if (*(int *)(param_1 + 0x368) == 0x6666665) {
                    /* WARNING: Subroutine does not return */
      FUN_016ddcd9("list<T> too long");
    }
    *(int *)(param_1 + 0x368) = *(int *)(param_1 + 0x368) + 1;
    *(undefined4 *)(iVar1 + 4) = uVar3;
    *puVar2 = uVar3;
  }
  else {
    if (param_2 == 0) {
      ExceptionList = &pvStack_10;
      uVar3 = FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
      FUN_0054e5e0(uVar3);
    }
    ExceptionList = &pvStack_10;
    (**(code **)((param_2 & 0xfffffffe) + 4))(&stack0x0000000c,1);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (param_2 != 0) {
    if (((param_2 & 1) == 0) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(param_2 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
    }
    param_2 = 0;
  }
  uStack_8 = 4;
  if (((in_stack_00000024 != 0) && ((in_stack_00000024 & 1) == 0)) &&
     (*(code **)(in_stack_00000024 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_00000024 & 0xfffffffe))(&stack0x0000002c,&stack0x0000002c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16781 ; VA 0x00936600 ; FUN_00936600 */

/* WARNING: Removing unreachable block (ram,0x009367ba) */
/* WARNING: Removing unreachable block (ram,0x009367bf) */
/* WARNING: Removing unreachable block (ram,0x009367d5) */
/* WARNING: Removing unreachable block (ram,0x009366e9) */

void FUN_00936600(uint *param_1)

{
  uint uVar1;
  uint *puVar2;
  uint *puVar3;
  undefined4 uVar4;
  int iVar5;
  longlong lVar6;
  longlong lVar7;
  undefined8 uVar8;
  longlong lVar9;
  undefined4 uVar10;
  undefined4 uStack_70;
  uint *puStack_6c;
  undefined auStack_3c [8];
  undefined auStack_34 [8];
  uint uStack_2c;
  int iStack_28;
  uint uStack_24;
  int iStack_20;
  uint *puStack_1c;
  char cStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017c9778;
  pvStack_10 = ExceptionList;
  uStack_24 = 0;
  iStack_20 = 0;
  puStack_1c = &uStack_24;
  uStack_8 = 1;
  uStack_7 = 0;
  cStack_18 = '\0';
  puStack_6c = (uint *)0x93666c;
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 2;
  while( true ) {
    puStack_6c = (uint *)auStack_34;
    uStack_70 = 0x93667c;
    puVar3 = (uint *)FUN_0168ea80();
    puVar2 = puStack_1c;
    if (((int)param_1[1] < (int)puVar3[1]) ||
       (((int)param_1[1] <= (int)puVar3[1] && (*param_1 <= *puVar3)))) break;
    puStack_6c = &uStack_2c;
    uStack_70 = 0x9366a0;
    FUN_0168ea80();
    if ((iStack_28 <= (int)param_1[1]) && ((iStack_28 < (int)param_1[1] || (uStack_2c < *param_1))))
    {
      iStack_14 = *param_1 - uStack_2c;
      puStack_6c = (uint *)0x0;
      uStack_70 = 1000000;
      iVar5 = (param_1[1] - iStack_28) - (uint)(*param_1 < uStack_2c);
      lVar6 = FUN_016f3900(iStack_14,iVar5);
      puStack_6c = (uint *)0x0;
      uStack_70 = 1000000;
      lVar9 = lVar6;
      lVar7 = FUN_016f39b0(lVar6);
      if (lVar7 < CONCAT44(iVar5,iStack_14)) {
        lVar6 = lVar6 + 1;
      }
      if (DAT_01ea94c0 == (code *)0x0) {
        uVar4 = GetModuleHandleA("KERNEL32.DLL","GetTickCount64");
        DAT_01ea94c0 = (code *)GetProcAddress(uVar4);
        if (DAT_01ea94c0 == (code *)0x0) {
          DAT_01ea94c0 = FUN_005efd30;
        }
      }
      uVar8 = (*DAT_01ea94c0)();
      uVar10 = (undefined4)((ulonglong)lVar9 >> 0x20);
      uVar4 = 1;
      FUN_005f0a90(&uStack_70,FUN_005f1e70,uVar8,lVar6,1);
      FUN_00560fc0(&puStack_1c,uVar8,lVar6,uVar4,uVar10);
      puStack_6c = (uint *)auStack_3c;
      uStack_70 = 0x93676e;
      FUN_0168ea80();
    }
  }
  _uStack_8 = CONCAT31(uStack_7,3);
  if (cStack_18 != '\0') {
    LOCK();
    uVar1 = *puStack_1c;
    *puStack_1c = *puStack_1c + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puVar2;
      *puVar2 = *puVar2 | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        puStack_6c = (uint *)0x9367a6;
        puStack_6c = (uint *)FUN_00554e40();
        uStack_70 = 0x9367ad;
        SetEvent();
      }
    }
  }
  puStack_6c = (uint *)0x9367ca;
  FUN_0056d500();
  puStack_6c = (uint *)iStack_20;
  LOCK();
  UNLOCK();
  LOCK();
  iStack_20 = 0;
  UNLOCK();
  if (puStack_6c != (uint *)0x0) {
    uStack_70 = 0x9367e6;
    CloseHandle();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16782 ; VA 0x00936800 ; FUN_00936800 */

void FUN_00936800(undefined4 param_1)

{
  undefined uVar1;
  undefined4 *****pppppuVar2;
  int iVar3;
  uint uVar4;
  int aiStack_114 [5];
  undefined auStack_100 [76];
  int iStack_b4;
  undefined **appuStack_a0 [18];
  int aiStack_58 [5];
  uint uStack_44;
  undefined4 ****appppuStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 ****ppppuStack_28;
  undefined4 ***pppuStack_24;
  undefined4 ***pppuStack_20;
  undefined4 ***pppuStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c97b6;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (DAT_01d6520f != '\0') {
    ExceptionList = &pvStack_10;
    FUN_01677520(DAT_01d6520f,"LoadClientSettingsFromLocal group: \"%s\"",param_1);
  }
  uStack_18 = 0xf00000000;
  ppppuStack_28 = (undefined4 ****)((uint)ppppuStack_28 & 0xffffff00);
  uStack_8 = 0;
  FUN_009376d0(appppuStack_40,0,param_1);
  pppppuVar2 = appppuStack_40;
  if (7 < uStack_2c) {
    pppppuVar2 = (undefined4 *****)appppuStack_40[0];
  }
  uStack_8._0_1_ = 1;
  FUN_0054ebd0(pppppuVar2,1,0x40,1);
  uStack_8._0_1_ = 2;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (iStack_b4 != 0) {
    FUN_00565940(3,1);
    uStack_8._0_1_ = 3;
    FUN_0056f130(auStack_100);
    pppppuVar2 = (undefined4 *****)FUN_0058c4d0(aiStack_58);
    if (&ppppuStack_28 != pppppuVar2) {
      FUN_005507b0();
      ppppuStack_28 = *pppppuVar2;
      pppuStack_24 = pppppuVar2[1];
      pppuStack_20 = pppppuVar2[2];
      pppuStack_1c = pppppuVar2[3];
      uStack_18 = *(undefined8 *)(pppppuVar2 + 4);
      pppppuVar2[4] = (undefined4 ****)0x0;
      pppppuVar2[5] = (undefined4 ****)0xf;
      *(undefined *)pppppuVar2 = 0;
    }
    if (0xf < uStack_44) {
      uVar4 = uStack_44 + 1;
      iVar3 = aiStack_58[0];
      if (0xfff < uVar4) {
        iVar3 = *(int *)(aiStack_58[0] + -4);
        uVar4 = uStack_44 + 0x24;
        if (0x1f < (aiStack_58[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar4);
    }
    if ((int)uStack_18 != 0) {
      if (DAT_01d84e8d != '\0') {
        pppppuVar2 = &ppppuStack_28;
        if (0xf < uStack_18._4_4_) {
          pppppuVar2 = (undefined4 *****)ppppuStack_28;
        }
        FUN_01677520(DAT_01d84e8d,"LoadClientSettingsFromLocal: \"%s\"",pppppuVar2);
      }
      pppppuVar2 = &ppppuStack_28;
      if (0xf < uStack_18._4_4_) {
        pppppuVar2 = (undefined4 *****)ppppuStack_28;
      }
      FUN_01683ce0(pppppuVar2);
      FUN_005705c0();
      goto LAB_009369aa;
    }
    uStack_8._0_1_ = 2;
    FUN_005705c0();
    uVar1 = (undefined)uStack_8;
  }
  uStack_8._0_1_ = uVar1;
  if (DAT_01d6520f != '\0') {
    FUN_016774b0(DAT_01d6520f,"LoadClientSettingsFromLocal: Couldn\'t fetch any data from local",0);
  }
LAB_009369aa:
  *(undefined ***)((int)aiStack_114 + *(int *)(aiStack_114[1] + 4) + 4) =
       std::basic_ifstream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)((int)aiStack_114 + *(int *)(aiStack_114[1] + 4)) = *(int *)(aiStack_114[1] + 4) + -0x70;
  FUN_00550570();
  *(undefined ***)((int)aiStack_114 + *(int *)(aiStack_114[1] + 4) + 4) =
       std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  *(int *)((int)aiStack_114 + *(int *)(aiStack_114[1] + 4)) = *(int *)(aiStack_114[1] + 4) + -0x18;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  appuStack_a0[0] = std::ios_base::vftable;
  FUN_016de551(appuStack_a0);
  if (7 < uStack_2c) {
    uVar4 = uStack_2c * 2 + 2;
    pppppuVar2 = (undefined4 *****)appppuStack_40[0];
    if (0xfff < uVar4) {
      pppppuVar2 = (undefined4 *****)appppuStack_40[0][-1];
      uVar4 = uStack_2c * 2 + 0x25;
      if (0x1f < (uint)((int)appppuStack_40[0] + (-4 - (int)pppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar2,uVar4);
  }
  uStack_30 = 0;
  uStack_2c = 7;
  appppuStack_40[0] = (undefined4 ****)((uint)appppuStack_40[0] & 0xffff0000);
  if (0xf < uStack_18._4_4_) {
    uVar4 = uStack_18._4_4_ + 1;
    pppppuVar2 = (undefined4 *****)ppppuStack_28;
    if (0xfff < uVar4) {
      pppppuVar2 = (undefined4 *****)ppppuStack_28[-1];
      uVar4 = uStack_18._4_4_ + 0x24;
      if (0x1f < (uint)((int)ppppuStack_28 + (-4 - (int)pppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16783 ; VA 0x00936ac0 ; FUN_00936ac0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint * FUN_00936ac0(uint *param_1,undefined4 *param_2)

{
  code *pcVar1;
  int iVar2;
  byte *pbVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iVar6;
  uint *puVar7;
  byte *pbVar8;
  byte *pbVar9;
  uint uVar10;
  undefined4 *puVar11;
  bool bVar12;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar11 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  puStack_14 = param_2;
  if (0xf < (uint)param_2[5]) {
    puStack_14 = (undefined4 *)*param_2;
  }
  ExceptionList = &pvStack_10;
  if (5 < (uint)param_2[4]) {
    iVar2 = param_2[4] - 5;
    ExceptionList = &pvStack_10;
    for (pbVar3 = (byte *)FUN_0170db20(puStack_14,0x68,iVar2); pbVar3 != (byte *)0x0;
        pbVar3 = (byte *)FUN_0170db20(pbVar3 + 1,0x68,(int)puStack_14 + (iVar2 - (int)(pbVar3 + 1)))
        ) {
      param_2 = (undefined4 *)0x2;
      pbVar9 = &DAT_019327e4;
      pbVar8 = pbVar3;
      if (*(int *)pbVar3 == _DAT_019327e4) {
        pbVar8 = pbVar3 + 4;
        param_2 = (undefined4 *)0xfffffffe;
        pbVar9 = &DAT_019327e8;
      }
      bVar12 = *pbVar8 < *pbVar9;
      if (((*pbVar8 == *pbVar9) && (bVar12 = pbVar8[1] < pbVar9[1], pbVar8[1] == pbVar9[1])) &&
         ((param_2 == (undefined4 *)0xfffffffe ||
          ((bVar12 = pbVar8[2] < pbVar9[2], pbVar8[2] == pbVar9[2] &&
           (bVar12 = pbVar8[3] < pbVar9[3], pbVar8[3] == pbVar9[3])))))) {
        uVar4 = 0;
      }
      else {
        uVar4 = -(uint)bVar12 | 1;
      }
      if (uVar4 == 0) {
        if ((int)pbVar3 - (int)puStack_14 != -1) {
          uStack_30 = uStack_30 & 0xffffff00;
          uStack_8 = 0;
          FUN_0058a190(puVar11[4] + 1);
          uVar10 = ((int)pbVar3 - (int)puStack_14) + 4;
          uVar4 = uVar10;
          if ((uint)puVar11[4] < uVar10) {
            uVar4 = puVar11[4];
          }
          puVar5 = puVar11;
          if (0xf < (uint)puVar11[5]) {
            puVar5 = (undefined4 *)*puVar11;
          }
          FUN_00554150(puVar5,uVar4);
          FUN_00578160(1,0x73);
          if (uVar10 <= (uint)puVar11[4]) {
            iVar6 = puVar11[4] - uVar10;
            iVar2 = -1;
            if (iVar6 != -1) {
              iVar2 = iVar6;
            }
            if (0xf < (uint)puVar11[5]) {
              puVar11 = (undefined4 *)*puVar11;
            }
            FUN_00554150((int)puVar11 + uVar10,iVar2);
            param_1[4] = 0;
            param_1[5] = 0;
            *param_1 = uStack_30;
            param_1[1] = uStack_2c;
            param_1[2] = uStack_28;
            param_1[3] = uStack_24;
            param_1[4] = 0;
            param_1[5] = 0xf;
            ExceptionList = pvStack_10;
            return param_1;
          }
          FUN_00554050();
          pcVar1 = (code *)swi(3);
          puVar7 = (uint *)(*pcVar1)();
          return puVar7;
        }
        break;
      }
    }
  }
  FUN_0054ef60(puVar11);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16784 ; VA 0x00936c60 ; FUN_00936c60 */

void FUN_00936c60(undefined4 param_1,undefined4 param_2,int param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int iVar1;
  undefined *apuStack_cc [2];
  code *pcStack_c4;
  int *piStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  int *piStack_b4;
  int iStack_b0;
  undefined *puStack_ac;
  int aiStack_34 [5];
  uint uStack_20;
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c97de;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff58;
  piStack_c0 = aiStack_34;
  puStack_ac = (undefined *)param_7;
  uStack_8 = 0;
  iStack_b0 = param_6;
  piStack_b4 = (int *)param_5;
  uStack_b8 = param_4;
  uStack_bc = param_2;
  pcStack_c4 = (code *)0x936ca3;
  ExceptionList = &pvStack_10;
  FUN_00d83430();
  piStack_b4 = aiStack_34;
  puStack_ac = (undefined *)0x0;
  iStack_b0 = 0;
  uStack_8._0_1_ = 1;
  if (*(int *)(param_3 + 0x10) == 0) {
    uStack_b8 = 0x936d13;
    FUN_014cc090();
    puStack_ac = (undefined *)0x0;
    puStack_18 = (undefined *)apuStack_cc;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    apuStack_cc[0] = (undefined *)0x0;
    FUN_005d6520(&pcStack_c4,&pcStack_c4,2);
    pcStack_c4 = _guard_check_icall;
    apuStack_cc[0] = &DAT_018c6f1d;
    FUN_014ccc70();
  }
  else {
    uStack_b8 = 0x936cc6;
    FUN_014cc090();
    puStack_ac = (undefined *)0x0;
    puStack_18 = (undefined *)apuStack_cc;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    apuStack_cc[0] = (undefined *)0x0;
    FUN_005d6520(&pcStack_c4,&pcStack_c4,2);
    pcStack_c4 = _guard_check_icall;
    apuStack_cc[0] = &DAT_018c6f1d;
    FUN_014cd990(param_3,&DAT_01d79f68,1);
  }
  puStack_ac = (undefined *)0x936d5c;
  FUN_0056db40();
  if (0xf < uStack_20) {
    puStack_ac = (undefined *)(uStack_20 + 1);
    iVar1 = aiStack_34[0];
    if (0xfff < puStack_ac) {
      iVar1 = *(int *)(aiStack_34[0] + -4);
      puStack_ac = (undefined *)(uStack_20 + 0x24);
      if (0x1f < (aiStack_34[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_ac = &UNK_00936dcc;
        FUN_017167a3();
      }
    }
    piStack_b4 = (int *)0x936d89;
    iStack_b0 = iVar1;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16785 ; VA 0x00936d9d ; Catch@00936d9d */

undefined4 Catch_00936d9d(void)

{
  undefined4 uVar1;
  int *piVar2;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x18) + 4))();
  piVar2 = *(int **)(unaff_EBP + 0xc);
  if (0xf < (uint)piVar2[5]) {
    piVar2 = (int *)*piVar2;
  }
  FUN_0086f2f0(3,"ReportStat \'%s\' failed. %s\n",piVar2,uVar1);
  return 0x936d8c;
}



/* FUNCTION 16786 ; VA 0x00936dd0 ; FUN_00936dd0 */

void FUN_00936dd0(undefined4 param_1,undefined4 param_2,int param_3,undefined4 param_4,
                 undefined4 param_5)

{
  int iVar1;
  int iVar2;
  undefined4 ****ppppuVar3;
  undefined4 uVar4;
  undefined4 ****ppppuVar5;
  uint uVar6;
  undefined auStack_c8 [160];
  undefined4 ***apppuStack_28 [4];
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c980b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00565940(3,1);
  uStack_8 = 0;
  if (*(int *)(param_3 + 0x10) != 0) {
    FUN_0054ef60(param_3);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    while( true ) {
      uVar6 = uStack_14;
      iVar2 = iStack_18;
      ppppuVar5 = (undefined4 ****)apppuStack_28[0];
      ppppuVar3 = apppuStack_28;
      if (0xf < uStack_14) {
        ppppuVar3 = (undefined4 ****)apppuStack_28[0];
      }
      if (iStack_18 == 0) break;
      iVar1 = FUN_0170db20(ppppuVar3,10,iStack_18);
      if ((iVar1 == 0) || (iVar1 - (int)ppppuVar3 == -1)) break;
      ppppuVar3 = apppuStack_28;
      if (0xf < uVar6) {
        ppppuVar3 = ppppuVar5;
      }
      iVar2 = FUN_0170db20(ppppuVar3,10,iVar2);
      if (iVar2 == 0) {
        iVar2 = -1;
      }
      else {
        iVar2 = iVar2 - (int)ppppuVar3;
      }
      FUN_00591430(iVar2,1,&DAT_0193298c,3);
    }
    do {
      ppppuVar3 = apppuStack_28;
      if (0xf < uVar6) {
        ppppuVar3 = ppppuVar5;
      }
      if (iVar2 == 0) goto LAB_00936ef9;
      iVar1 = FUN_0170db20(ppppuVar3,9,iVar2);
      if ((iVar1 == 0) || (iVar1 - (int)ppppuVar3 == -1)) goto LAB_00936ef9;
      ppppuVar3 = apppuStack_28;
      if (0xf < uVar6) {
        ppppuVar3 = ppppuVar5;
      }
      iVar2 = FUN_0170db20(ppppuVar3,9,iVar2);
      if (iVar2 == 0) {
        iVar2 = -1;
      }
      else {
        iVar2 = iVar2 - (int)ppppuVar3;
      }
      FUN_00591430(iVar2,1,&DAT_0193298c,3);
      ppppuVar5 = (undefined4 ****)apppuStack_28[0];
      iVar2 = iStack_18;
      uVar6 = uStack_14;
    } while( true );
  }
LAB_00936f5d:
  FUN_005ed940(auStack_c8,0);
  uVar4 = FUN_0058c4d0(apppuStack_28);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00936c60(param_1,param_2,uVar4,0,0,param_4,param_5);
  if (0xf < uStack_14) {
    uVar6 = uStack_14 + 1;
    ppppuVar5 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar6) {
      ppppuVar5 = (undefined4 ****)apppuStack_28[0][-1];
      uVar6 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar6);
  }
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return;
LAB_00936ef9:
  uVar4 = FUN_00558890(auStack_c8,"string\tmessage\t");
  ppppuVar5 = apppuStack_28;
  if (0xf < uStack_14) {
    ppppuVar5 = (undefined4 ****)apppuStack_28[0];
  }
  FUN_0055b3b0(uVar4,ppppuVar5,iStack_18);
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_14) {
    uVar6 = uStack_14 + 1;
    ppppuVar5 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar6) {
      ppppuVar5 = (undefined4 ****)apppuStack_28[0][-1];
      uVar6 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar5,uVar6);
  }
  goto LAB_00936f5d;
}



/* FUNCTION 16787 ; VA 0x00936ff0 ; FUN_00936ff0 */

void FUN_00936ff0(undefined4 *param_1,uint param_2,uint param_3)

{
  code *pcVar1;
  uint uVar2;
  
  if (param_2 <= (uint)param_1[4]) {
    uVar2 = param_1[4] - param_2;
    if (uVar2 < param_3) {
      param_3 = uVar2;
    }
    if (0xf < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    FUN_00554150((int)param_1 + param_2,param_3);
    return;
  }
  FUN_00554050();
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 16788 ; VA 0x00937030 ; FUN_00937030 */

void FUN_00937030(char *param_1,int param_2,int param_3,undefined4 *param_4,undefined4 param_5)

{
  char cVar1;
  double *pdVar2;
  char *pcVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  double dStack_60;
  int aiStack_58 [5];
  uint uStack_44;
  double dStack_40;
  uint uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  uint uStack_20;
  double dStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c983b;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff2c;
  ExceptionList = &pvStack_10;
  FUN_016830f0(&dStack_40);
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  pcVar3 = param_1;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(param_1,(int)pcVar3 - (int)(param_1 + 1));
  uStack_8 = 0;
  FUN_00891110(aiStack_58,&uStack_34,param_5);
  uStack_8._0_1_ = 2;
  if (0xf < uStack_20) {
    uVar5 = uStack_20 + 1;
    uVar6 = uStack_34;
    if (0xfff < uVar5) {
      uVar6 = *(uint *)(uStack_34 - 4);
      uVar5 = uStack_20 + 0x24;
      if (0x1f < (uStack_34 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar6,uVar5);
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  uStack_34 = uStack_34 & 0xffffff00;
  FUN_014cc090(aiStack_58,0,0);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_014cd0a0(param_4 + 7,0,0);
  pdVar2 = (double *)FUN_016830f0(&dStack_1c);
  uStack_8 = 3;
  dStack_1c = *pdVar2 - dStack_40;
  *(double *)(param_4 + 0xe) = dStack_1c;
  *(undefined *)(param_3 + 0xc) = 0;
  FUN_016830f0(&dStack_60);
  FUN_01684540(param_4 + 7);
  pdVar2 = (double *)FUN_016830f0(&dStack_1c);
  dStack_1c = *pdVar2 - dStack_60;
  *(double *)(param_4 + 0x10) = dStack_1c;
  if (*(char *)(param_3 + 0xc) == '\0') {
    FUN_005542c0(&DAT_018bc9b8,0);
    *param_4 = 0;
    if (param_2 != 0) {
      FUN_00936800(param_2,param_3);
    }
    FUN_01678ee0();
    FUN_00878940();
  }
  else {
    FUN_0054ef60(param_3 + 0x10);
    if (param_4 + 1 == &uStack_34) {
      if (0xf < uStack_20) {
        uVar5 = uStack_20 + 1;
        uVar6 = uStack_34;
        if (0xfff < uVar5) {
          uVar6 = *(uint *)(uStack_34 - 4);
          uVar5 = uStack_20 + 0x24;
          if (0x1f < (uStack_34 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar6,uVar5);
      }
      *param_4 = 2;
    }
    else {
      FUN_005507b0();
      param_4[1] = uStack_34;
      param_4[2] = uStack_30;
      param_4[3] = uStack_2c;
      param_4[4] = uStack_28;
      *(ulonglong *)(param_4 + 5) = CONCAT44(uStack_20,uStack_24);
      *param_4 = 2;
    }
  }
  FUN_0056db40();
  if (0xf < uStack_44) {
    uVar6 = uStack_44 + 1;
    iVar4 = aiStack_58[0];
    if (0xfff < uVar6) {
      iVar4 = *(int *)(aiStack_58[0] + -4);
      uVar6 = uStack_44 + 0x24;
      if (0x1f < (aiStack_58[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16789 ; VA 0x00937291 ; Catch@00937291 */

undefined * Catch_00937291(void)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  double *pdVar4;
  int unaff_EBP;
  int iVar5;
  
  piVar1 = *(int **)(unaff_EBP + -0x34);
  if (DAT_01d84e8e != '\0') {
    iVar5 = unaff_EBP + -0x54;
    if (0xf < *(uint *)(unaff_EBP + -0x40)) {
      iVar5 = *(int *)(unaff_EBP + -0x54);
    }
    uVar3 = (**(code **)(*piVar1 + 4))();
    FUN_01677520(DAT_01d84e8e,
                 "blockingFetchAndLoadSettingsFromCdn exception: %s while fetching settings from %s"
                 ,uVar3,iVar5);
  }
  pdVar4 = (double *)FUN_016830f0(unaff_EBP + -0x18);
  puVar2 = *(undefined4 **)(unaff_EBP + 0x14);
  *(double *)(unaff_EBP + -0x18) = *pdVar4 - *(double *)(unaff_EBP + -0x3c);
  puVar2[0xe] = *(undefined4 *)(unaff_EBP + -0x18);
  puVar2[0xf] = *(undefined4 *)(unaff_EBP + -0x14);
  uVar3 = (**(code **)(*piVar1 + 4))();
  FUN_00551260(uVar3);
  *puVar2 = 1;
  *(undefined8 *)(unaff_EBP + -0x18) = 0;
  puVar2[0x10] = *(undefined4 *)(unaff_EBP + -0x18);
  puVar2[0x11] = *(undefined4 *)(unaff_EBP + -0x14);
  return &DAT_00937323;
}



/* FUNCTION 16790 ; VA 0x00937360 ; FUN_00937360 */

void FUN_00937360(undefined4 param_1,int param_2,int param_3,undefined4 *param_4)

{
  undefined4 ****ppppuVar1;
  int iVar2;
  uint *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  double *pdVar7;
  undefined4 *****pppppuVar8;
  uint uVar9;
  uint uVar10;
  undefined4 uVar11;
  uint auStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  undefined4 ****ppppuStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  uint uStack_40;
  undefined auStack_3c [8];
  double dStack_34;
  double dStack_2c;
  undefined8 uStack_24;
  uint uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9860;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_016830f0(&dStack_34);
  puVar6 = param_4 + 7;
  iStack_18 = DAT_01d64304;
  do {
    if (iStack_18 < 1) {
      puVar6 = (undefined4 *)FUN_0151a940(auStack_6c,param_1);
      uStack_8 = 0;
      if (0xf < (uint)puVar6[5]) {
        puVar6 = (undefined4 *)*puVar6;
      }
      FUN_01675640(&ppppuStack_54,
                   "blockingFetchAndLoadSettingsFromFile failed to read settings from file %s",
                   puVar6);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      if (0xf < uStack_58) {
        uVar9 = uStack_58 + 1;
        uVar10 = auStack_6c[0];
        if (0xfff < uVar9) {
          uVar10 = *(uint *)(auStack_6c[0] - 4);
          uVar9 = uStack_58 + 0x24;
          if (0x1f < (auStack_6c[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar10,uVar9);
      }
      uStack_5c = 0;
      uStack_58 = 0xf;
      auStack_6c[0] = auStack_6c[0] & 0xffffff00;
      if (DAT_01d84e8e != '\0') {
        pppppuVar8 = &ppppuStack_54;
        if (0xf < uStack_40) {
          pppppuVar8 = (undefined4 *****)ppppuStack_54;
        }
        FUN_01677520(DAT_01d84e8e,&DAT_018bd25c,pppppuVar8);
      }
      pdVar7 = (double *)FUN_016830f0(auStack_3c);
      uStack_24 = *pdVar7 - dStack_34;
      *(double *)(param_4 + 0xe) = uStack_24;
      if ((undefined4 *****)(param_4 + 1) != &ppppuStack_54) {
        pppppuVar8 = &ppppuStack_54;
        if (0xf < uStack_40) {
          pppppuVar8 = (undefined4 *****)ppppuStack_54;
        }
        FUN_005542c0(pppppuVar8,uStack_44);
      }
      uStack_24 = 0.0;
      param_4[0x10] = 0;
      param_4[0x11] = 0;
      *param_4 = 1;
      if (0xf < uStack_40) {
        uVar10 = uStack_40 + 1;
        pppppuVar8 = (undefined4 *****)ppppuStack_54;
        if (0xfff < uVar10) {
          pppppuVar8 = (undefined4 *****)ppppuStack_54[-1];
          uVar10 = uStack_40 + 0x24;
          if (0x1f < (uint)((int)ppppuStack_54 + (-4 - (int)pppppuVar8))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(pppppuVar8,uVar10);
      }
      ExceptionList = pvStack_10;
      return;
    }
    iVar2 = FUN_015190f0(param_1);
    iStack_14 = iVar2;
    if (iVar2 == 0) {
      puVar3 = (uint *)FUN_0168ea80(auStack_3c);
      uStack_24 = (double)CONCAT44(puVar3[1] + (uint)(0xfff0bdbf < *puVar3),*puVar3 + 1000000);
      FUN_00936600(&uStack_24);
    }
    else {
      FUN_01718e22(iVar2,0,2);
      uVar10 = FUN_01726462(iVar2);
      FUN_01718e22(iStack_14,0,0);
      if ((uint)param_4[0xb] < uVar10) {
        FUN_00578160(uVar10 - param_4[0xb],0);
      }
      else {
        puVar4 = puVar6;
        if (0xf < (uint)param_4[0xc]) {
          puVar4 = (undefined4 *)*puVar6;
        }
        param_4[0xb] = uVar10;
        *(undefined *)((int)puVar4 + uVar10) = 0;
      }
      uVar11 = 1;
      uVar9 = uVar10;
      iVar2 = iStack_14;
      uVar5 = FUN_0056f430(0);
      uStack_1c = FUN_017189e9(uVar5,uVar11,uVar9,iVar2);
      FUN_01718190(iStack_14);
      if (uVar10 == uStack_1c) {
        *(undefined *)(param_3 + 0xc) = 0;
        FUN_016830f0(&dStack_2c);
        FUN_01684540(puVar6);
        pdVar7 = (double *)FUN_016830f0(auStack_3c);
        uStack_24 = *pdVar7 - dStack_2c;
        *(double *)(param_4 + 0x10) = uStack_24;
        if (*(char *)(param_3 + 0xc) != '\0') {
          FUN_0054ef60(param_3 + 0x10);
          if ((undefined4 *****)(param_4 + 1) != &ppppuStack_54) {
            FUN_005507b0();
            ppppuVar1 = ppppuStack_54;
            ppppuStack_54 = (undefined4 ****)((uint)ppppuStack_54 & 0xffffff00);
            param_4[1] = ppppuVar1;
            param_4[2] = uStack_50;
            param_4[3] = uStack_4c;
            param_4[4] = uStack_48;
            *(ulonglong *)(param_4 + 5) = CONCAT44(uStack_40,uStack_44);
            uStack_44 = 0;
            uStack_40 = 0xf;
          }
          FUN_005507b0();
          *param_4 = 2;
          ExceptionList = pvStack_10;
          return;
        }
        FUN_005542c0(&DAT_018bc9b8,0);
        *param_4 = 0;
        if (param_2 != 0) {
          FUN_00936800(param_2,param_3);
        }
        FUN_01678ee0();
        FUN_00878940();
        ExceptionList = pvStack_10;
        return;
      }
      if (DAT_01d84e8e != '\0') {
        FUN_01677520(DAT_01d84e8e,
                     "Settings file modified while being read, tell size was %zu but read size was %zu"
                     ,uVar10,uStack_1c);
      }
    }
    iStack_18 = iStack_18 + -1;
  } while( true );
}



/* FUNCTION 16791 ; VA 0x009376d0 ; FUN_009376d0 */

undefined4 FUN_009376d0(undefined4 param_1,undefined4 param_2,char *param_3)

{
  undefined8 uVar1;
  char cVar2;
  int *piVar3;
  undefined4 uVar4;
  char *pcVar5;
  undefined4 ****ppppuVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  int iStack_88;
  uint uStack_74;
  uint auStack_70 [4];
  undefined4 uStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined4 uStack_48;
  uint uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 ***pppuStack_28;
  int iStack_24;
  int iStack_20;
  int iStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c98a3;
  pvStack_10 = ExceptionList;
  uStack_48 = 0;
  uStack_44 = 0xf;
  uStack_58 = uStack_58 & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0(".json",5);
  uStack_8 = 0;
  pcVar5 = param_3;
  do {
    cVar2 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar2 != '\0');
  piVar3 = (int *)FUN_00585d40(0,param_3,(int)pcVar5 - (int)(param_3 + 1));
  pppuStack_28 = (undefined4 ***)*piVar3;
  iStack_24 = piVar3[1];
  iStack_20 = piVar3[2];
  iStack_1c = piVar3[3];
  uVar1 = *(undefined8 *)(piVar3 + 4);
  piVar3[4] = 0;
  piVar3[5] = 0xf;
  *(undefined *)piVar3 = 0;
  uStack_30 = 0;
  uStack_2c = 7;
  uStack_40 = (uint)uStack_40._2_2_ << 0x10;
  uStack_18._0_4_ = (int)uVar1;
  uStack_8._0_1_ = 2;
  if ((int)uStack_18 != 0) {
    uStack_18._4_4_ = (uint)((ulonglong)uVar1 >> 0x20);
    ppppuVar6 = &pppuStack_28;
    if (0xf < uStack_18._4_4_) {
      ppppuVar6 = (undefined4 ****)pppuStack_28;
    }
    iVar9 = (int)ppppuVar6 + (int)uStack_18;
    ppppuVar6 = &pppuStack_28;
    if (0xf < uStack_18._4_4_) {
      ppppuVar6 = (undefined4 ****)pppuStack_28;
    }
    uStack_18 = uVar1;
    uVar4 = FUN_01686580();
    FUN_01685950(ppppuVar6,iVar9,&uStack_40,uVar4);
    uVar1 = uStack_18;
  }
  uStack_18 = uVar1;
  uStack_8._0_1_ = 3;
  uVar4 = FUN_01518d10(auStack_70,param_2,3,"ClientSettings");
  uStack_8._0_1_ = 4;
  FUN_0054f050(uVar4);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  uVar4 = FUN_01686150(&uStack_40);
  FUN_0054f050(uVar4);
  if (7 < uStack_74) {
    uVar7 = uStack_74 * 2 + 2;
    iVar9 = iStack_88;
    if (0xfff < uVar7) {
      iVar9 = *(int *)(iStack_88 + -4);
      uVar7 = uStack_74 * 2 + 0x25;
      if (0x1f < (iStack_88 - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar9,uVar7);
  }
  if (7 < uStack_5c) {
    uVar7 = uStack_5c * 2 + 2;
    uVar8 = auStack_70[0];
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(auStack_70[0] - 4);
      uVar7 = uStack_5c * 2 + 0x25;
      if (0x1f < (auStack_70[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  uStack_60 = 0;
  uStack_5c = 7;
  auStack_70[0] = auStack_70[0] & 0xffff0000;
  if (7 < uStack_2c) {
    uVar7 = uStack_2c * 2 + 2;
    uVar8 = uStack_40;
    if (0xfff < uVar7) {
      uVar8 = *(uint *)(uStack_40 - 4);
      uVar7 = uStack_2c * 2 + 0x25;
      if (0x1f < (uStack_40 - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar7);
  }
  uStack_30 = 0;
  uStack_2c = 7;
  uStack_40 = uStack_40 & 0xffff0000;
  if (0xf < uStack_18._4_4_) {
    uVar7 = uStack_18._4_4_ + 1;
    ppppuVar6 = (undefined4 ****)pppuStack_28;
    if (0xfff < uVar7) {
      ppppuVar6 = (undefined4 ****)pppuStack_28[-1];
      uVar7 = uStack_18._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppuStack_28 + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar6,uVar7);
  }
  uStack_18 = 0xf00000000;
  pppuStack_28 = (undefined4 ***)((uint)pppuStack_28 & 0xffffff00);
  if (0xf < uStack_44) {
    uVar8 = uStack_44 + 1;
    uVar7 = uStack_58;
    if (0xfff < uVar8) {
      uVar7 = *(uint *)(uStack_58 - 4);
      uVar8 = uStack_44 + 0x24;
      if (0x1f < (uStack_58 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar8);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16792 ; VA 0x00937970 ; FUN_00937970 */

undefined4 FUN_00937970(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  uint *puVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  uint uVar7;
  int iVar8;
  undefined auStack_1c [8];
  int iStack_14;
  int iStack_10;
  uint uStack_c;
  int iStack_8;
  
  iStack_8 = DAT_01d64304;
  if (0 < DAT_01d64304) {
    do {
      iVar8 = iStack_8;
      iVar1 = FUN_015190f0(param_1);
      if (iVar1 == 0) {
        puVar2 = (uint *)FUN_0168ea80(auStack_1c);
        iStack_14 = *puVar2 + 1000000;
        iStack_10 = puVar2[1] + (uint)(0xfff0bdbf < *puVar2);
        FUN_00936600(&iStack_14);
        iStack_8 = iVar8;
      }
      else {
        FUN_01718e22(iVar1,0,2);
        uVar3 = FUN_01726462(iVar1);
        FUN_01718e22(iVar1,0,0);
        if ((uint)param_2[4] < uVar3) {
          FUN_00578160(uVar3 - param_2[4],0);
        }
        else {
          puVar4 = param_2;
          if (0xf < (uint)param_2[5]) {
            puVar4 = (undefined4 *)*param_2;
          }
          param_2[4] = uVar3;
          *(undefined *)((int)puVar4 + uVar3) = 0;
        }
        uVar6 = 1;
        uVar7 = uVar3;
        iVar8 = iVar1;
        uVar5 = FUN_0056f430(0);
        uStack_c = FUN_017189e9(uVar5,uVar6,uVar7,iVar8);
        FUN_01718190(iVar1);
        if (uVar3 == uStack_c) {
          return 1;
        }
        if (DAT_01d84e8e != '\0') {
          FUN_01677520(DAT_01d84e8e,
                       "Settings file modified while being read, tell size was %zu but read size was %zu"
                       ,uVar3,uStack_c);
        }
      }
      iStack_8 = iStack_8 + -1;
    } while (0 < iStack_8);
  }
  return 0;
}



/* FUNCTION 16793 ; VA 0x00937a80 ; FUN_00937a80 */

int * __thiscall
FUN_00937a80(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
            undefined4 param_13)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c0d8b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00937b90();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::GameSettings,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
              ::
              GetSetImpl<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_(__thiscall_RBX::GameSettings::*)(void)const_,void_(__thiscall_RBX::GameSettings::*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cb40();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_13,0);
  *param_1 = (int)RBX::Reflection::
                  TypedPropertyDescriptor<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                  ::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::GameSettings,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                    ::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::GameSettings,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                    ::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16794 ; VA 0x00937b90 ; FUN_00937b90 */

undefined * FUN_00937b90(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c98bc;
  pvStack_10 = ExceptionList;
  if (DAT_01ee2340 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee2550) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee2550);
      if (DAT_01ee2550 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,&DAT_019329e0,1,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01885050);
        FUN_016f37bf(&DAT_01ee2550);
      }
    }
    DAT_01ee2340 = &DAT_01ee2348;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee2340;
}



/* FUNCTION 16795 ; VA 0x00937c70 ; FUN_00937c70 */

undefined4 * __fastcall FUN_00937c70(undefined4 *param_1)

{
  char cVar1;
  undefined *puVar2;
  undefined4 uVar3;
  char *pcVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  uint uStack_2c;
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9927;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_0170d1f0(param_1,0,0x54);
  FUN_0089a7a0();
  uStack_8 = 0;
  *param_1 = RBX::Described<class_RBX::GameSettings,class_RBX::GlobalAdvancedSettings::Item>::
             vftable;
  uVar3 = FUN_00937b90();
  param_1[3] = uVar3;
  *(undefined *)(param_1 + 0x15) = 1;
  uStack_8 = 1;
  *param_1 = RBX::GlobalAdvancedSettingsItem<class_RBX::GameSettings>::vftable;
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  FUN_005542c0(&DAT_019329e0,0xc);
  uStack_8._0_1_ = 2;
  FUN_008a6520(auStack_44);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_30) {
    uVar6 = uStack_30 + 1;
    uVar5 = auStack_44[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_44[0] - 4);
      uVar6 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar5,uVar6);
  }
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  if (DAT_01ea8528 == (undefined4 *)0x0) {
    DAT_01ea8528 = param_1;
    *param_1 = RBX::GameSettings::vftable;
    param_1[0x16] = 100;
    param_1[0x17] = 0x32;
    param_1[0x18] = &DAT_bf800000;
    param_1[0x19] = &DAT_bf800000;
    param_1[0x1e] = 0;
    param_1[0x1f] = 0xf;
    uStack_8 = 3;
    *(undefined *)(param_1 + 0x1a) = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8._0_1_ = 4;
    param_1[0x24] = 0;
    param_1[0x25] = 0xf;
    *(undefined *)(param_1 + 0x20) = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    *(undefined *)(param_1 + 0x26) = 0;
    param_1[0x27] = 0;
    puVar2 = PTR_DAT_01d6431c;
    uStack_8._0_1_ = 6;
    *(undefined *)(param_1 + 0x28) = 1;
    param_1[0x29] = 1;
    *(undefined2 *)(param_1 + 0x2a) = 1;
    uStack_1c = 0;
    uStack_18 = 0xf;
    uStack_2c = uStack_2c & 0xffffff00;
    pcVar4 = puVar2;
    do {
      cVar1 = *pcVar4;
      pcVar4 = pcVar4 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(puVar2,(int)pcVar4 - (int)(puVar2 + 1));
    uStack_8._0_1_ = 7;
    uStack_34 = 0;
    uStack_30 = 0xf;
    auStack_44[0] = auStack_44[0] & 0xffffff00;
    pcVar4 = PTR_DAT_01d6431c;
    do {
      cVar1 = *pcVar4;
      pcVar4 = pcVar4 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(PTR_DAT_01d6431c,(int)pcVar4 - (int)(PTR_DAT_01d6431c + 1));
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    FUN_008a6520(auStack_44);
    if (0xf < uStack_30) {
      uVar6 = uStack_30 + 1;
      uVar5 = auStack_44[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_44[0] - 4);
        uVar6 = uStack_30 + 0x24;
        if (0x1f < (auStack_44[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    if (0xf < uStack_18) {
      uVar6 = uStack_18 + 1;
      uVar5 = uStack_2c;
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(uStack_2c - 4);
        uVar6 = uStack_18 + 0x24;
        if (0x1f < (uStack_2c - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_016756b0(auStack_20,"singleton %s already exists",&DAT_019329e0);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_20,&DAT_01c17198);
}



/* FUNCTION 16796 ; VA 0x00937f20 ; FUN_00937f20 */

void __fastcall FUN_00937f20(undefined4 *param_1)

{
  *param_1 = RBX::GlobalAdvancedSettingsItem<class_RBX::GameSettings>::vftable;
  DAT_01ea8528 = 0;
  FUN_0089b230();
  return;
}



/* FUNCTION 16797 ; VA 0x00937f40 ; FUN_00937f40 */

undefined4 * __thiscall FUN_00937f40(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::GlobalAdvancedSettingsItem<class_RBX::GameSettings>::vftable;
  DAT_01ea8528 = 0;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x58);
  }
  return param_1;
}



/* FUNCTION 16798 ; VA 0x00937f80 ; FUN_00937f80 */

undefined4 * __thiscall FUN_00937f80(undefined4 *param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  *param_1 = RBX::GameSettings::vftable;
  FUN_016790b0();
  uVar1 = param_1[0x25];
  if (0xf < uVar1) {
    iVar2 = param_1[0x20];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00938060;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x24] = 0;
  param_1[0x25] = 0xf;
  *(undefined *)(param_1 + 0x20) = 0;
  uVar1 = param_1[0x1f];
  if (0xf < uVar1) {
    iVar2 = param_1[0x1a];
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00938060:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  param_1[0x1e] = 0;
  param_1[0x1f] = 0xf;
  *(undefined *)(param_1 + 0x1a) = 0;
  *param_1 = RBX::GlobalAdvancedSettingsItem<class_RBX::GameSettings>::vftable;
  DAT_01ea8528 = 0;
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xac);
  }
  return param_1;
}



/* FUNCTION 16799 ; VA 0x00938070 ; FUN_00938070 */

undefined4 * __thiscall
FUN_00938070(int param_1,undefined4 *param_2,int param_3,undefined4 param_4,int *param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3b51;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (param_3 == 0) {
    ExceptionList = &pvStack_10;
    *param_2 = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      iVar2 = param_5[1] + -1;
      param_5[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)*param_5)();
        LOCK();
        piVar1 = param_5 + 2;
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          (**(code **)(*param_5 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar2 = *(int *)(param_1 + 0x34);
  ExceptionList = &pvStack_10;
  if (param_5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_5[1] = param_5[1] + 1;
    UNLOCK();
  }
  uStack_8 = 2;
  uVar3 = FUN_01675290(DAT_02110da8);
  uStack_8 = 3;
  puVar4 = (undefined4 *)FUN_01674e20(0x20);
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    *puVar4 = 0;
    puVar4[1] = 1;
    puVar4[2] = FUN_008f4680;
    puVar4[3] = FUN_0068b170;
    puVar4[4] = 0;
    puVar4[5] = iVar2 + param_3;
    puVar4[6] = 0;
    puVar4[7] = 0;
    if (param_5 != (int *)0x0) {
      LOCK();
      param_5[1] = param_5[1] + 1;
      UNLOCK();
    }
    puVar4[6] = param_4;
    puVar4[7] = param_5;
  }
  FUN_016797d0(puVar4);
  *param_2 = puVar4;
  if (puVar4 != (undefined4 *)0x0) {
    LOCK();
    puVar4[1] = puVar4[1] + 1;
    UNLOCK();
  }
  uStack_8 = 4;
  FUN_01675290(uVar3);
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      iVar2 = param_5[2] + -1;
      param_5[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar2 = param_5[1] + -1;
    param_5[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_5)();
      LOCK();
      piVar1 = param_5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16800 ; VA 0x00938210 ; FUN_00938210 */

void FUN_00938210(undefined4 param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  param_2 = (int *)*param_2;
  iVar1 = *param_2;
  iVar2 = FUN_0088daf0();
  if (iVar1 == iVar2) {
    piVar3 = param_2 + 2;
    if (param_2[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_005e6780(*(undefined *)piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16801 ; VA 0x00938260 ; FUN_00938260 */

void FUN_00938260(void)

{
  int iVar1;
  
  if (DAT_01ee2554 == 0) {
    iVar1 = FUN_00937b90();
    DAT_01ee2554 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 16802 ; VA 0x00938280 ; FUN_00938280 */

undefined4 __thiscall FUN_00938280(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x68);
  return param_2;
}



/* FUNCTION 16803 ; VA 0x009382a0 ; FUN_009382a0 */

undefined4 __thiscall FUN_009382a0(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x80);
  return param_2;
}



/* FUNCTION 16804 ; VA 0x009382d0 ; FUN_009382d0 */

undefined4 __thiscall FUN_009382d0(int param_1,undefined *param_2)

{
  if ((*(char *)(param_1 + 0x98) != '\0') &&
     ((param_2 == &DAT_021201e0 || (param_2 == &DAT_02120218)))) {
    return 1;
  }
  return 0;
}



/* FUNCTION 16805 ; VA 0x00938300 ; FUN_00938300 */

void __thiscall FUN_00938300(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  char *pcVar4;
  char ****ppppcVar5;
  int *piVar6;
  char *pcVar7;
  int iVar8;
  char ****ppppcVar9;
  uint uVar10;
  int iVar11;
  int *piVar12;
  int iVar13;
  int iVar14;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  char ***apppcStack_4c [4];
  int iStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  undefined *puStack_24;
  undefined *puStack_20;
  int iStack_1c;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c99f0;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  piVar12 = (int *)(param_1 + 0x68);
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  cVar2 = FUN_00558b30(piVar12,&param_2);
  if (cVar2 == '\0') {
    if ((undefined4 **)piVar12 != &param_2) {
      puVar3 = &param_2;
      if (0xf < in_stack_00000018) {
        puVar3 = param_2;
      }
      FUN_005542c0(puVar3,in_stack_00000014);
    }
    if (*(char *)(param_1 + 0x98) == '\0') {
      iVar14 = 0;
      uStack_34 = 0;
      iVar11 = 0;
      iStack_30 = 0;
      iStack_2c = 0;
      iStack_8._0_1_ = 1;
      piVar6 = piVar12;
      if (0xf < *(uint *)(param_1 + 0x7c)) {
        piVar6 = (int *)*piVar12;
      }
      if (0xf < *(uint *)(param_1 + 0x7c)) {
        piVar12 = (int *)*piVar12;
      }
      iStack_28 = 0;
      puStack_24 = (undefined *)0x0;
      puStack_20 = (undefined *)0x0;
      FUN_0064d160(piVar12,*(int *)(param_1 + 0x78) + (int)piVar6,in_stack_00000018);
      iStack_8._0_1_ = 2;
      uStack_11 = 0;
      if (puStack_20 == puStack_24) {
        FUN_0064c160(puStack_24,&uStack_11);
      }
      else {
        *puStack_24 = 0;
        puStack_24 = puStack_24 + 1;
      }
      pcVar4 = (char *)FUN_01728649(iStack_28,&DAT_018d1b9c);
      uVar1 = uStack_34;
      while (pcVar4 != (char *)0x0) {
        iStack_3c = 0;
        uStack_38 = 0xf;
        apppcStack_4c[0] = (char ***)((uint)apppcStack_4c[0] & 0xffffff00);
        pcVar7 = pcVar4;
        do {
          cVar2 = *pcVar7;
          pcVar7 = pcVar7 + 1;
        } while (cVar2 != '\0');
        uStack_34 = uVar1;
        FUN_005542c0(pcVar4,(int)pcVar7 - (int)(pcVar4 + 1));
        iStack_8 = CONCAT31(iStack_8._1_3_,3);
        ppppcVar9 = apppcStack_4c;
        if (0xf < uStack_38) {
          ppppcVar9 = (char ****)apppcStack_4c[0];
        }
        ppppcVar5 = apppcStack_4c;
        if (0xf < uStack_38) {
          ppppcVar5 = (char ****)apppcStack_4c[0];
        }
        iVar8 = 0;
        iVar13 = ((int)ppppcVar9 + iStack_3c) - (int)ppppcVar5;
        if ((char ****)((int)ppppcVar9 + iStack_3c) < ppppcVar5) {
          iVar13 = 0;
        }
        if (iVar13 != 0) {
          do {
            if (*(char *)ppppcVar5 == '\\') {
              *(char *)ppppcVar5 = '/';
            }
            iVar8 = iVar8 + 1;
            ppppcVar5 = (char ****)((int)ppppcVar5 + 1);
          } while (iVar8 != iVar13);
        }
        if (iVar11 == iVar14) {
          FUN_00559960(iVar14,apppcStack_4c);
          iVar11 = iStack_2c;
        }
        else {
          FUN_0054ef60(apppcStack_4c);
          iStack_30 = iVar14 + 0x18;
        }
        iVar14 = iStack_30;
        pcVar4 = (char *)FUN_01728649(0,&DAT_018d1b9c);
        iStack_8._0_1_ = 2;
        uVar1 = uStack_34;
        if (0xf < uStack_38) {
          uVar10 = uStack_38 + 1;
          ppppcVar9 = (char ****)apppcStack_4c[0];
          if (0xfff < uVar10) {
            ppppcVar9 = (char ****)apppcStack_4c[0][-1];
            uVar10 = uStack_38 + 0x24;
            if ((char *)0x1f < (char *)((int)apppcStack_4c[0] + (-4 - (int)ppppcVar9)))
            goto LAB_0093859a;
          }
          FUN_01674ea0(ppppcVar9,uVar10);
          uVar1 = uStack_34;
        }
      }
      uStack_34 = 0;
      iStack_30 = 0;
      iStack_2c = 0;
      FUN_00b75480(uVar1,iVar14,iVar11);
      iStack_8._0_1_ = 1;
      if (iStack_28 != 0) {
        uVar10 = (int)puStack_20 - iStack_28;
        iVar14 = iStack_28;
        if (0xfff < uVar10) {
          iVar14 = *(int *)(iStack_28 + -4);
          uVar10 = uVar10 + 0x23;
          if (0x1f < (iStack_28 - iVar14) - 4U) {
LAB_0093859a:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(iVar14,uVar10);
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      thunk_FUN_00577a40();
    }
    FUN_008a4940(&DAT_021201e0);
  }
  if (0xf < in_stack_00000018) {
    uVar10 = in_stack_00000018 + 1;
    puVar3 = param_2;
    if (0xfff < uVar10) {
      puVar3 = (undefined4 *)param_2[-1];
      uVar10 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar3,uVar10);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16806 ; VA 0x009385b0 ; FUN_009385b0 */

void FUN_009385b0(void)

{
  char cVar1;
  uint uVar2;
  char *pcVar3;
  uint uVar4;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  pcVar3 = PTR_DAT_01d6431c;
  do {
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(PTR_DAT_01d6431c,(int)pcVar3 - (int)(PTR_DAT_01d6431c + 1));
  uStack_8 = 0;
  FUN_008a6520(auStack_28);
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar4) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16807 ; VA 0x00938670 ; FUN_00938670 */

void __thiscall FUN_00938670(int param_1,undefined4 *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  puVar3 = (undefined4 *)(param_1 + 0x80);
  ExceptionList = &pvStack_10;
  cVar1 = FUN_00558b30(puVar3,&param_2);
  if (cVar1 == '\0') {
    if ((undefined4 **)puVar3 != &param_2) {
      puVar2 = &param_2;
      if (0xf < in_stack_00000018) {
        puVar2 = param_2;
      }
      FUN_005542c0(puVar2,in_stack_00000014);
    }
    if (*(char *)(param_1 + 0x98) == '\0') {
      FUN_0054ef60(puVar3);
      FUN_00b758e0();
    }
    FUN_008a4940(&DAT_02120218);
  }
  if (0xf < in_stack_00000018) {
    uVar4 = in_stack_00000018 + 1;
    puVar3 = param_2;
    if (0xfff < uVar4) {
      puVar3 = (undefined4 *)param_2[-1];
      uVar4 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16808 ; VA 0x00938740 ; FUN_00938740 */

void __thiscall FUN_00938740(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0xa8) = param_2;
  return;
}



/* FUNCTION 16809 ; VA 0x00938750 ; FUN_00938750 */

void __thiscall FUN_00938750(int param_1,undefined4 param_2)

{
  if (DAT_01d64314 != '\0') {
    if (*(char *)(param_1 + 0xa9) == (char)param_2) {
      return;
    }
    *(char *)(param_1 + 0xa9) = (char)param_2;
    FUN_008a4940(&DAT_021202c0);
  }
  FUN_005e6780(param_2);
  return;
}



/* FUNCTION 16810 ; VA 0x00938790 ; FUN_00938790 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00938790(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9a20;
  pvStack_10 = ExceptionList;
  if (DAT_01ee2560 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee2778) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee2778);
      if (DAT_01ee2778 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00d14e90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"CSGDictionaryService",1,uStack_20,0,0,0x1b,6,0);
        _DAT_01ee2770 = RBX::Creator<class_RBX::CSGDictionaryService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee2568,&DAT_01ee2770);
        FUN_016f3654(FUN_01885060);
        FUN_016f37bf(&DAT_01ee2778);
      }
    }
    DAT_01ee2560 = &DAT_01ee2568;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee2560;
}



/* FUNCTION 16811 ; VA 0x00938890 ; FUN_00938890 */

void FUN_00938890(void)

{
  int iVar1;
  
  if (DAT_01ee277c == 0) {
    iVar1 = FUN_00938790();
    DAT_01ee277c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 16812 ; VA 0x009388b0 ; FUN_009388b0 */

void __thiscall FUN_009388b0(uint *param_1,int *param_2,int param_3,int param_4)

{
  int *piVar1;
  int *piVar2;
  bool bVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  int *piVar10;
  uint uVar11;
  uint uVar12;
  int *piVar13;
  
  uVar7 = param_4 - param_3 >> 3;
  iVar5 = (int)((int)param_2 - *param_1) >> 3;
  if ((uVar7 == 1) && (param_2 == (int *)param_1[1])) {
    bVar3 = true;
  }
  else {
    bVar3 = false;
    if (uVar7 == 0) {
      return;
    }
  }
  uVar12 = param_1[1];
  if (uVar7 <= (uint)((int)(param_1[2] - uVar12) >> 3)) {
    if (uVar7 < (uint)((int)(uVar12 - (int)param_2) >> 3)) {
      piVar13 = (int *)(uVar12 + uVar7 * -8);
      uVar8 = FUN_005c23f0(piVar13,uVar12,uVar12,param_1);
      param_1[1] = uVar8;
      if (piVar13 != param_2) {
        piVar10 = (int *)(uVar12 + 4);
        do {
          iVar5 = piVar13[-1];
          piVar1 = piVar13 + -2;
          piVar2 = piVar10 + -2;
          iVar9 = *piVar1;
          piVar13[-1] = 0;
          *piVar1 = 0;
          piVar10[-3] = iVar9;
          piVar13 = (int *)*piVar2;
          *piVar2 = iVar5;
          if (piVar13 != (int *)0x0) {
            LOCK();
            iVar5 = piVar13[1] + -1;
            piVar13[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*piVar13)();
              LOCK();
              iVar5 = piVar13[2] + -1;
              piVar13[2] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)(*piVar13 + 4))();
              }
            }
          }
          piVar10 = piVar2;
          piVar13 = piVar1;
        } while (piVar1 != param_2);
      }
      FUN_005596d0(param_2,param_2 + uVar7 * 2,param_1);
    }
    else {
      uVar7 = FUN_005c23f0(param_2,uVar12,param_2 + uVar7 * 2,param_1);
      param_1[1] = uVar7;
      FUN_005596d0(param_2,uVar12,param_1);
    }
    FUN_0055c480(param_3,param_4,param_2);
    return;
  }
  iVar9 = (int)(uVar12 - *param_1) >> 3;
  if (0x1fffffffU - iVar9 < uVar7) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar11 = (int)(param_1[2] - *param_1) >> 3;
  uVar8 = uVar7 + iVar9;
  uVar12 = uVar8;
  if ((uVar11 <= 0x1fffffff - (uVar11 >> 1)) && (uVar12 = uVar11 + (uVar11 >> 1), uVar12 < uVar8)) {
    uVar12 = uVar8;
  }
  uVar11 = uVar12 * 8;
  if (uVar12 < 0x20000000) {
    uVar12 = uVar11;
    if (0xfff < uVar11) goto LAB_00938960;
    if (uVar11 == 0) {
      uVar12 = 0;
    }
    else {
      uVar12 = FUN_01674e20(uVar11);
    }
  }
  else {
    uVar12 = 0xffffffff;
LAB_00938960:
    uVar4 = uVar12 + 0x23;
    if (uVar4 <= uVar12) {
      uVar4 = 0xffffffff;
    }
    iVar9 = FUN_01674e20(uVar4);
    if (iVar9 == 0) goto LAB_00938b34;
    uVar12 = iVar9 + 0x23U & 0xffffffe0;
    *(int *)(uVar12 - 4) = iVar9;
  }
  FUN_0055c480(param_3,param_4,uVar12 + iVar5 * 8);
  if (bVar3) {
    FUN_005c23f0(*param_1,param_1[1],uVar12,param_1);
  }
  else {
    FUN_005c23f0(*param_1,param_2,uVar12,param_1);
    FUN_005c23f0(param_2,param_1[1],uVar12 + (uVar7 + iVar5) * 8,param_1);
  }
  if (*param_1 != 0) {
    FUN_005596d0(*param_1,param_1[1],param_1);
    uVar7 = *param_1;
    uVar6 = param_1[2] - uVar7 & 0xfffffff8;
    uVar4 = uVar7;
    if (0xfff < uVar6) {
      uVar4 = *(uint *)(uVar7 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar7 - uVar4) - 4) {
LAB_00938b34:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar6);
  }
  *param_1 = uVar12;
  param_1[1] = uVar12 + uVar8 * 8;
  param_1[2] = uVar11 + uVar12;
  return;
}



/* FUNCTION 16813 ; VA 0x00938b40 ; FUN_00938b40 */

code * FUN_00938b40(undefined4 param_1,int param_2)

{
  uint *puVar1;
  uint uVar2;
  int *piVar3;
  code *pcVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  pcVar4 = *(code **)(param_2 + 0x10);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (pcVar4 != (code *)0x0) {
    ExceptionList = &pvStack_10;
    if (((uint)pcVar4 & 1) == 0) {
      pcVar4 = *(code **)((uint)pcVar4 & 0xfffffffe);
      ExceptionList = &pvStack_10;
      if (pcVar4 != (code *)0x0) {
        ExceptionList = &pvStack_10;
        pcVar4 = (code *)(*pcVar4)(param_2 + 0x18,param_2 + 0x18,2);
      }
    }
    *(undefined4 *)(param_2 + 0x10) = 0;
  }
  piVar3 = *(int **)(param_2 + 0xc);
  if (piVar3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(piVar3 + 2);
    uVar2 = *puVar1;
    pcVar4 = (code *)*puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      pcVar4 = (code *)(**(code **)(*piVar3 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return pcVar4;
}



/* FUNCTION 16814 ; VA 0x00938bb0 ; FUN_00938bb0 */

void __thiscall FUN_00938bb0(byte *param_1,int *param_2,uint *param_3,int param_4)

{
  uint *puVar1;
  int *piVar2;
  uint uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  uint uVar9;
  byte *pbVar10;
  undefined4 *puVar11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar5 = (int)param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9a38;
  pvStack_10 = ExceptionList;
  pbVar10 = param_1 + *param_1 + 1;
  ExceptionList = &pvStack_10;
  uVar6 = FUN_0055c740(pbVar10,param_3);
  FUN_00562fc0(&param_3,uVar6,iVar5,-(uint)(pbVar10 != (byte *)0x0) & (uint)(pbVar10 + 1));
  if (param_3 == (uint *)0x0) {
    uStack_8 = 0;
    piVar7 = (int *)FUN_01674e20(0x28);
    iVar5 = param_4;
    *piVar7 = 0;
    piVar7[1] = 0;
    piVar7[2] = 0;
    piVar7[3] = 0;
    piVar7[4] = 0;
    piVar7[5] = 0;
    piVar7[6] = 0;
    piVar7[7] = 0;
    piVar7[8] = 0;
    piVar7[9] = 0;
    FUN_0054ef60(param_4);
    piVar7[8] = 0;
    piVar7[9] = 0;
    piVar7[8] = *(int *)(iVar5 + 0x18);
    piVar7[9] = *(int *)(iVar5 + 0x1c);
    *(undefined4 *)(iVar5 + 0x18) = 0;
    *(undefined4 *)(iVar5 + 0x1c) = 0;
    uVar3 = *(uint *)(param_1 + 8);
    uVar8 = uVar3 + 1;
    if (*(int *)(param_1 + 0x14) == 0) {
      uVar8 = FUN_005d6bb0(uVar8);
      if (uVar8 <= *(uint *)(param_1 + 4)) {
        uVar8 = *(uint *)(param_1 + 4);
      }
      FUN_005d2b00(uVar8);
    }
    else if (*(uint *)(param_1 + 0x10) < uVar8) {
      param_3 = (uint *)0x1;
      uVar9 = uVar3 >> 1;
      if ((uVar3 >> 1) + uVar3 <= uVar8) {
        uVar9 = 1;
      }
      uVar8 = FUN_005d6bb0(uVar9 + uVar3);
      puVar1 = (uint *)(param_1 + 4);
      if (uVar8 != *puVar1) {
        param_3 = puVar1;
        FUN_005d2b00(uVar8);
        puVar11 = (undefined4 *)(*(int *)(param_1 + 0x14) + *puVar1 * 4);
        puVar4 = (undefined4 *)*puVar11;
        while (puVar4 != (undefined4 *)0x0) {
          piVar2 = (int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *param_3) * 4);
          if (*(int *)(*(int *)(param_1 + 0x14) + ((uint)puVar4[1] % *param_3) * 4) == 0) {
            *piVar2 = (int)puVar11;
            puVar11 = puVar4;
          }
          else {
            *puVar11 = *puVar4;
            *puVar4 = *(undefined4 *)*piVar2;
            *(undefined4 **)*piVar2 = puVar4;
          }
          puVar4 = (undefined4 *)*puVar11;
        }
      }
    }
    piVar7[1] = uVar6;
    uVar8 = *(uint *)(param_1 + 4);
    iVar5 = *(int *)(param_1 + 0x14);
    puVar11 = (undefined4 *)(iVar5 + (uVar6 % uVar8) * 4);
    if (*(int *)(iVar5 + (uVar6 % uVar8) * 4) == 0) {
      piVar2 = (int *)(iVar5 + uVar8 * 4);
      if (*piVar2 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar2 + 4) % uVar8) * 4) = piVar7;
      }
      *puVar11 = piVar2;
      *piVar7 = *piVar2;
      *piVar2 = (int)piVar7;
    }
    else {
      *piVar7 = *(int *)*puVar11;
      *(int **)*puVar11 = piVar7;
    }
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
    *param_2 = (int)piVar7;
    *(undefined *)(param_2 + 1) = 1;
    ExceptionList = pvStack_10;
    return;
  }
  *(undefined *)(param_2 + 1) = 0;
  *param_2 = (int)param_3;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16815 ; VA 0x00938dc0 ; FUN_00938dc0 */

int * FUN_00938dc0(int *param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if ((*param_2 == 0) ||
     (iVar7 = *(int *)(*param_2 + 0xc), iVar5 = FUN_00daf7e0(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    piStack_c = (int *)0x0;
    puVar6 = &uStack_10;
    bVar3 = false;
    bVar2 = true;
    iVar7 = 0;
  }
  else {
    piStack_14 = (int *)param_2[1];
    iVar7 = *param_2;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)param_2[1];
    }
    puVar6 = &uStack_18;
    bVar3 = true;
    bVar2 = false;
  }
  iVar5 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar4 = piStack_c;
  param_1[1] = iVar5;
  *param_1 = iVar7;
  if ((bVar2) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_c[1] + -1;
    piStack_c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_14;
  if ((bVar3) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_14[1] + -1;
    piStack_14[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 16816 ; VA 0x00938eb0 ; FUN_00938eb0 */

int * FUN_00938eb0(int *param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if ((*param_2 == 0) ||
     (iVar7 = *(int *)(*param_2 + 0xc), iVar5 = FUN_00b50240(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    piStack_c = (int *)0x0;
    puVar6 = &uStack_10;
    bVar3 = false;
    bVar2 = true;
    iVar7 = 0;
  }
  else {
    piStack_14 = (int *)param_2[1];
    iVar7 = *param_2;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)param_2[1];
    }
    puVar6 = &uStack_18;
    bVar3 = true;
    bVar2 = false;
  }
  iVar5 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar4 = piStack_c;
  param_1[1] = iVar5;
  *param_1 = iVar7;
  if ((bVar2) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_c[1] + -1;
    piStack_c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_14;
  if ((bVar3) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_14[1] + -1;
    piStack_14[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 16817 ; VA 0x00938fa0 ; FUN_00938fa0 */

uint FUN_00938fa0(int param_1)

{
  int iVar1;
  uint in_EAX;
  int iVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0xc);
    iVar2 = FUN_00cfb1a0();
    return (uint)CONCAT11((char)(*(ushort *)(iVar2 + 0x1da) >> 8),
                          (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
                          (uint)*(ushort *)(iVar2 + 0x1da));
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 16818 ; VA 0x00938fe0 ; FUN_00938fe0 */

undefined4 * __fastcall FUN_00938fe0(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9a84;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00d15c40();
  uStack_8 = 0;
  *param_1 = RBX::DescribedCreatable<class_RBX::CSGDictionaryService,class_RBX::FlyweightService>::
             vftable;
  uVar1 = FUN_00938790();
  param_1[3] = uVar1;
  *param_1 = RBX::CSGDictionaryService::vftable;
  uStack_8 = 1;
  *(undefined *)(param_1 + 0x2a) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[0x2b] = uVar1;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0x3f800000;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  *(undefined *)(param_1 + 0x30) = 0;
  uVar1 = FUN_00588320(0xb);
  param_1[0x31] = uVar1;
  param_1[0x32] = 0;
  param_1[0x33] = 0x3f800000;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  uStack_8._0_1_ = 3;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("CSGDictionaryService",0x14);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16819 ; VA 0x00939120 ; FUN_00939120 */

void __fastcall FUN_00939120(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::CSGDictionaryService>::vftable;
  uVar1 = FUN_00938790(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16820 ; VA 0x00939160 ; thunk_FUN_00939740 */

void __fastcall thunk_FUN_00939740(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0xa4);
  ExceptionList = &pvStack_10;
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 0x98) != 0) {
      puVar7 = *(undefined4 **)(iVar4 + *(int *)(param_1 + 0x94) * 4);
      puVar2 = (undefined4 *)(iVar4 + *(int *)(param_1 + 0x94) * 4);
      ExceptionList = &pvStack_10;
      do {
        *puVar2 = *puVar7;
        FUN_009399a0(0);
        FUN_01674ea0(puVar7,0x38);
        *(int *)(param_1 + 0x98) = *(int *)(param_1 + 0x98) + -1;
        puVar7 = (undefined4 *)*puVar2;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0xa4);
    }
    iVar3 = *(int *)(param_1 + 0x94) * 4;
    uVar6 = iVar3 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar3 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_00939964;
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0xa4) = 0;
    *(undefined4 *)(param_1 + 0xa0) = 0;
  }
  iVar4 = *(int *)(param_1 + 0x8c);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 0x80) != 0) {
      puVar7 = *(undefined4 **)(iVar4 + *(int *)(param_1 + 0x7c) * 4);
      puVar2 = (undefined4 *)(iVar4 + *(int *)(param_1 + 0x7c) * 4);
      do {
        *puVar2 = *puVar7;
        FUN_009391a0();
        FUN_01674ea0(puVar7,0x38);
        *(int *)(param_1 + 0x80) = *(int *)(param_1 + 0x80) + -1;
        puVar7 = (undefined4 *)*puVar2;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x8c);
    }
    iVar3 = *(int *)(param_1 + 0x7c) * 4;
    uVar6 = iVar3 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar3 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_00939964;
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x8c) = 0;
    *(undefined4 *)(param_1 + 0x88) = 0;
  }
  uStack_8 = 0;
  FUN_01679490();
  iVar4 = *(int *)(param_1 + 0x74);
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar4 = *(int *)(param_1 + 0x70);
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  iVar4 = *(int *)(param_1 + 0x6c);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 0x60) != 0) {
      FUN_00939d90(iVar4 + *(int *)(param_1 + 0x5c) * 4,0);
      iVar4 = *(int *)(param_1 + 0x6c);
    }
    if (iVar4 != iVar4 + (*(int *)(param_1 + 0x5c) + 1) * 4) {
      iVar4 = *(int *)(param_1 + 0x6c);
    }
    iVar3 = *(int *)(param_1 + 0x5c) * 4;
    uVar6 = iVar3 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar3 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
LAB_00939964:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x6c) = 0;
    *(undefined4 *)(param_1 + 0x68) = 0;
  }
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16821 ; VA 0x00939170 ; FUN_00939170 */

void __fastcall FUN_00939170(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if (iVar1 != 0) {
    if (*(char *)(param_1 + 9) != '\0') {
      FUN_0056cac0();
      iVar1 = *(int *)(param_1 + 4);
    }
    FUN_01674ea0(iVar1,0x28);
  }
  return;
}



/* FUNCTION 16822 ; VA 0x009391a0 ; FUN_009391a0 */

void __fastcall FUN_009391a0(int *param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar4 = param_1[0xb];
  ExceptionList = &pvStack_10;
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    if (param_1[8] != 0) {
      puVar7 = *(undefined4 **)(iVar4 + param_1[7] * 4);
      puVar1 = (undefined4 *)(iVar4 + param_1[7] * 4);
      ExceptionList = &pvStack_10;
      do {
        *puVar1 = *puVar7;
        uVar6 = puVar7[6];
        uStack_8 = 0;
        if (uVar6 != 0) {
          if ((uVar6 & 1) == 0) {
            if (*(code **)(uVar6 & 0xfffffffe) != (code *)0x0) {
              (**(code **)(uVar6 & 0xfffffffe))(puVar7 + 8,puVar7 + 8,2);
            }
          }
          puVar7[6] = 0;
        }
        piVar2 = (int *)puVar7[5];
        uStack_8 = 0xffffffff;
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar4 = piVar2[2] + -1;
          piVar2[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar2 + 4))();
          }
        }
        FUN_01674ea0(puVar7,0x38);
        param_1[8] = param_1[8] + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = param_1[0xb];
    }
    uVar6 = param_1[7] * 4 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar6) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar6 = param_1[7] * 4 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) goto LAB_009392ca;
    }
    FUN_01674ea0(iVar3,uVar6);
    param_1[0xb] = 0;
    param_1[10] = 0;
  }
  uVar6 = param_1[5];
  if (0xf < uVar6) {
    iVar4 = *param_1;
    uVar5 = uVar6 + 1;
    iVar3 = iVar4;
    if (0xfff < uVar5) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar5 = uVar6 + 0x24;
      if (0x1f < (iVar4 - iVar3) - 4U) {
LAB_009392ca:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar5);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16823 ; VA 0x009392d0 ; FUN_009392d0 */

void __fastcall FUN_009392d0(int *param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  piVar1 = (int *)param_1[7];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar3 = piVar1[2] + -1;
    piVar1[2] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  uVar2 = param_1[5];
  if (0xf < uVar2) {
    iVar3 = *param_1;
    uVar5 = uVar2 + 1;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  return;
}



/* FUNCTION 16824 ; VA 0x00939340 ; FUN_00939340 */

void __fastcall FUN_00939340(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00939cf0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 16825 ; VA 0x009393c0 ; FUN_009393c0 */

void __fastcall FUN_009393c0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_009391a0();
        FUN_01674ea0(puVar6,0x38);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 16826 ; VA 0x00939450 ; FUN_00939450 */

void __fastcall FUN_00939450(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      do {
        *puVar1 = *puVar6;
        FUN_009399a0(0);
        FUN_01674ea0(puVar6,0x38);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 16827 ; VA 0x009394e0 ; FUN_009394e0 */

void __fastcall FUN_009394e0(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00939d90(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 16828 ; VA 0x00939560 ; FUN_00939560 */

void __fastcall FUN_00939560(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      puVar7 = *(undefined4 **)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      ExceptionList = &pvStack_10;
      do {
        *puVar1 = *puVar7;
        uVar6 = puVar7[6];
        uStack_8 = 0;
        if (uVar6 != 0) {
          if ((uVar6 & 1) == 0) {
            if (*(code **)(uVar6 & 0xfffffffe) != (code *)0x0) {
              (**(code **)(uVar6 & 0xfffffffe))(puVar7 + 8,puVar7 + 8,2);
            }
          }
          puVar7[6] = 0;
        }
        piVar3 = (int *)puVar7[5];
        uStack_8 = 0xffffffff;
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
        FUN_01674ea0(puVar7,0x38);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar7 = (undefined4 *)*puVar1;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16829 ; VA 0x00939650 ; FUN_00939650 */

void __fastcall FUN_00939650(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar3 = *(int *)(param_1 + 0x14);
  if (iVar3 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 8) != 0) {
      puVar6 = *(undefined4 **)(iVar3 + *(int *)(param_1 + 4) * 4);
      puVar1 = (undefined4 *)(iVar3 + *(int *)(param_1 + 4) * 4);
      ExceptionList = &pvStack_10;
      do {
        *puVar1 = *puVar6;
        uVar5 = puVar6[4];
        uStack_8 = 0;
        if (uVar5 != 0) {
          if ((uVar5 & 1) == 0) {
            if (*(code **)(uVar5 & 0xfffffffe) != (code *)0x0) {
              (**(code **)(uVar5 & 0xfffffffe))(puVar6 + 6,puVar6 + 6,2);
            }
          }
          puVar6[4] = 0;
        }
        uStack_8 = 0xffffffff;
        FUN_01674ea0(puVar6,0x30);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar5 = iVar2 + 4;
    iVar4 = iVar3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(iVar3 + -4);
      uVar5 = iVar2 + 0x27;
      if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar5);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16830 ; VA 0x00939730 ; FUN_00939730 */

void __fastcall FUN_00939730(int param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      FUN_00939cf0(iVar4 + *(int *)(param_1 + 4) * 4,0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar1 = *(int *)(param_1 + 4) * 4;
    uVar2 = iVar1 + 4;
    iVar3 = iVar4;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar4 + -4);
      uVar2 = iVar1 + 0x27;
      if (0x1f < (iVar4 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 16831 ; VA 0x00939740 ; FUN_00939740 */

void __fastcall FUN_00939740(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 *puVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01794980;
  pvStack_10 = ExceptionList;
  iVar4 = *(int *)(param_1 + 0xa4);
  ExceptionList = &pvStack_10;
  if (iVar4 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_1 + 0x98) != 0) {
      puVar7 = *(undefined4 **)(iVar4 + *(int *)(param_1 + 0x94) * 4);
      puVar2 = (undefined4 *)(iVar4 + *(int *)(param_1 + 0x94) * 4);
      ExceptionList = &pvStack_10;
      do {
        *puVar2 = *puVar7;
        FUN_009399a0(0);
        FUN_01674ea0(puVar7,0x38);
        *(int *)(param_1 + 0x98) = *(int *)(param_1 + 0x98) + -1;
        puVar7 = (undefined4 *)*puVar2;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0xa4);
    }
    iVar3 = *(int *)(param_1 + 0x94) * 4;
    uVar6 = iVar3 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar3 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_00939964;
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0xa4) = 0;
    *(undefined4 *)(param_1 + 0xa0) = 0;
  }
  iVar4 = *(int *)(param_1 + 0x8c);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 0x80) != 0) {
      puVar7 = *(undefined4 **)(iVar4 + *(int *)(param_1 + 0x7c) * 4);
      puVar2 = (undefined4 *)(iVar4 + *(int *)(param_1 + 0x7c) * 4);
      do {
        *puVar2 = *puVar7;
        FUN_009391a0();
        FUN_01674ea0(puVar7,0x38);
        *(int *)(param_1 + 0x80) = *(int *)(param_1 + 0x80) + -1;
        puVar7 = (undefined4 *)*puVar2;
      } while (puVar7 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x8c);
    }
    iVar3 = *(int *)(param_1 + 0x7c) * 4;
    uVar6 = iVar3 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar3 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) goto LAB_00939964;
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x8c) = 0;
    *(undefined4 *)(param_1 + 0x88) = 0;
  }
  uStack_8 = 0;
  FUN_01679490();
  iVar4 = *(int *)(param_1 + 0x74);
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = 1;
  FUN_01679490();
  iVar4 = *(int *)(param_1 + 0x70);
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  iVar4 = *(int *)(param_1 + 0x6c);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 0x60) != 0) {
      FUN_00939d90(iVar4 + *(int *)(param_1 + 0x5c) * 4,0);
      iVar4 = *(int *)(param_1 + 0x6c);
    }
    if (iVar4 != iVar4 + (*(int *)(param_1 + 0x5c) + 1) * 4) {
      iVar4 = *(int *)(param_1 + 0x6c);
    }
    iVar3 = *(int *)(param_1 + 0x5c) * 4;
    uVar6 = iVar3 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar3 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
LAB_00939964:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x6c) = 0;
    *(undefined4 *)(param_1 + 0x68) = 0;
  }
  FUN_0089b230();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16832 ; VA 0x00939970 ; FUN_00939970 */

undefined4 __thiscall FUN_00939970(undefined4 param_1,byte param_2)

{
  FUN_00939740();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xa8);
  }
  return param_1;
}



/* FUNCTION 16833 ; VA 0x009399a0 ; FUN_009399a0 */

int * __thiscall FUN_009399a0(int *param_1,byte param_2)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792010;
  pvStack_10 = ExceptionList;
  iVar3 = param_1[0xb];
  ExceptionList = &pvStack_10;
  if (iVar3 != 0) {
    ExceptionList = &pvStack_10;
    if (param_1[8] != 0) {
      puVar6 = *(undefined4 **)(iVar3 + param_1[7] * 4);
      puVar1 = (undefined4 *)(iVar3 + param_1[7] * 4);
      ExceptionList = &pvStack_10;
      do {
        *puVar1 = *puVar6;
        uVar5 = puVar6[4];
        uStack_8 = 0;
        if (uVar5 != 0) {
          if ((uVar5 & 1) == 0) {
            if (*(code **)(uVar5 & 0xfffffffe) != (code *)0x0) {
              (**(code **)(uVar5 & 0xfffffffe))(puVar6 + 6,puVar6 + 6,2);
            }
          }
          puVar6[4] = 0;
        }
        uStack_8 = 0xffffffff;
        FUN_01674ea0(puVar6,0x30);
        param_1[8] = param_1[8] + -1;
        puVar6 = (undefined4 *)*puVar1;
      } while (puVar6 != (undefined4 *)0x0);
      iVar3 = param_1[0xb];
    }
    uVar5 = param_1[7] * 4 + 4;
    iVar2 = iVar3;
    if (0xfff < uVar5) {
      iVar2 = *(int *)(iVar3 + -4);
      uVar5 = param_1[7] * 4 + 0x27;
      if (0x1f < (iVar3 - iVar2) - 4U) goto LAB_00939acd;
    }
    FUN_01674ea0(iVar2,uVar5);
    param_1[0xb] = 0;
    param_1[10] = 0;
  }
  uVar5 = param_1[5];
  if (0xf < uVar5) {
    iVar3 = *param_1;
    uVar4 = uVar5 + 1;
    iVar2 = iVar3;
    if (0xfff < uVar4) {
      iVar2 = *(int *)(iVar3 + -4);
      uVar4 = uVar5 + 0x24;
      if (0x1f < (iVar3 - iVar2) - 4U) {
LAB_00939acd:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  param_1[4] = 0;
  param_1[5] = 0xf;
  *(undefined *)param_1 = 0;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x30);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16834 ; VA 0x00939ae0 ; FUN_00939ae0 */

undefined4 * __thiscall FUN_00939ae0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::CSGDictionaryService::vftable;
  FUN_00939340();
  FUN_00939340();
  FUN_00939740();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xd8);
  }
  return param_1;
}



/* FUNCTION 16835 ; VA 0x00939b30 ; FUN_00939b30 */

int __thiscall FUN_00939b30(byte *param_1,int param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7d18;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 8) != 0) {
    param_1 = param_1 + *param_1 + 1;
    ExceptionList = &pvStack_10;
    uVar2 = FUN_0055c740(param_1,param_2);
    FUN_00562fc0(&param_2,uVar2,param_2,-(uint)(param_1 != (byte *)0x0) & (uint)(param_1 + 1));
    if (param_2 != 0) {
      ExceptionList = pvStack_10;
      return param_2 + 0x20;
    }
  }
  uVar2 = FUN_0091a050("Unable to find key in unordered_map.");
  uStack_8 = 0;
  FUN_00917680(uVar2);
  pcVar1 = (code *)swi(3);
  iVar3 = (*pcVar1)();
  return iVar3;
}



/* FUNCTION 16836 ; VA 0x00939bc0 ; FUN_00939bc0 */

int __thiscall FUN_00939bc0(int param_1,int param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c7d18;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 8) != 0) {
    ExceptionList = &pvStack_10;
    FUN_00939e30(&param_2,param_2);
    if (param_2 != 0) {
      ExceptionList = pvStack_10;
      return param_2 + 0x20;
    }
  }
  uVar2 = FUN_0091a050("Unable to find key in unordered_map.");
  uStack_8 = 0;
  FUN_00917680(uVar2);
  pcVar1 = (code *)swi(3);
  iVar3 = (*pcVar1)();
  return iVar3;
}



/* FUNCTION 16837 ; VA 0x00939c30 ; FUN_00939c30 */

bool __thiscall FUN_00939c30(byte *param_1,int param_2)

{
  undefined4 uVar1;
  
  param_1 = param_1 + *param_1 + 1;
  uVar1 = FUN_0055c740(param_1,param_2);
  FUN_00562fc0(&param_2,uVar1,param_2,-(uint)(param_1 != (byte *)0x0) & (uint)(param_1 + 1));
  return param_2 != 0;
}



/* FUNCTION 16838 ; VA 0x00939c80 ; FUN_00939c80 */

undefined4 * FUN_00939c80(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_0055df40(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 16839 ; VA 0x00939cf0 ; FUN_00939cf0 */

int __thiscall FUN_00939cf0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_0056cac0();
    FUN_01674ea0(puVar1,0x28);
    iVar2 = iVar2 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 16840 ; VA 0x00939d40 ; FUN_00939d40 */

int __thiscall FUN_00939d40(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = 0;
  puVar1 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar1;
    FUN_009391a0();
    FUN_01674ea0(puVar1,0x38);
    iVar2 = iVar2 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar1 = (undefined4 *)*param_2;
  } while (puVar1 != param_3);
  return iVar2;
}



/* FUNCTION 16841 ; VA 0x00939d90 ; FUN_00939d90 */

int __thiscall FUN_00939d90(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  undefined4 *puVar7;
  
  iVar6 = 0;
  puVar7 = (undefined4 *)*param_2;
  do {
    *param_2 = *puVar7;
    piVar1 = (int *)puVar7[9];
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar3 = piVar1[2] + -1;
      piVar1[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    uVar2 = puVar7[7];
    if (0xf < uVar2) {
      iVar3 = puVar7[2];
      uVar5 = uVar2 + 1;
      iVar4 = iVar3;
      if (0xfff < uVar5) {
        iVar4 = *(int *)(iVar3 + -4);
        uVar5 = uVar2 + 0x24;
        if (0x1f < (iVar3 - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar5);
    }
    puVar7[6] = 0;
    puVar7[7] = 0xf;
    *(undefined *)(puVar7 + 2) = 0;
    FUN_01674ea0(puVar7,0x2c);
    iVar6 = iVar6 + 1;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
    puVar7 = (undefined4 *)*param_2;
  } while (puVar7 != param_3);
  return iVar6;
}



/* FUNCTION 16842 ; VA 0x00939e30 ; FUN_00939e30 */

void __thiscall FUN_00939e30(byte *param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  char cVar2;
  uint uVar3;
  int *piVar4;
  undefined4 *puVar5;
  uint uVar6;
  int *piVar7;
  
  uVar3 = FUN_0055c740(param_1 + *param_1 + 1,param_3);
  uVar1 = *(uint *)(param_1 + 4);
  uVar6 = uVar3 % uVar1;
  if (*(int *)(param_1 + 8) == 0) {
    piVar7 = (int *)0x0;
  }
  else {
    puVar5 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar6 * 4);
    if (puVar5 == (undefined4 *)0x0) {
      piVar7 = (int *)0x0;
    }
    else {
      piVar7 = (int *)*puVar5;
    }
    if (piVar7 != (int *)0x0) {
      do {
        if (uVar3 == piVar7[1]) {
          piVar4 = piVar7 + 2;
          if (0xf < (uint)piVar7[7]) {
            piVar4 = (int *)*piVar4;
          }
          puVar5 = param_3;
          if (0xf < (uint)param_3[5]) {
            puVar5 = (undefined4 *)*param_3;
          }
          cVar2 = FUN_0055c360(puVar5,param_3[4],piVar4,piVar7[6]);
          if (cVar2 != '\0') break;
        }
        else if ((uint)piVar7[1] % uVar1 != uVar6) {
          *param_2 = 0;
          return;
        }
        piVar7 = (int *)*piVar7;
        if (piVar7 == (int *)0x0) {
          *param_2 = 0;
          return;
        }
      } while( true );
    }
  }
  *param_2 = piVar7;
  return;
}



/* FUNCTION 16843 ; VA 0x00939ef0 ; FUN_00939ef0 */

undefined4 * __thiscall FUN_00939ef0(int param_1,undefined4 *param_2,int param_3)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined auStack_44 [36];
  int iStack_20;
  undefined4 uStack_1c;
  undefined auStack_18 [4];
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar2 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9aa8;
  pvStack_10 = ExceptionList;
  puVar6 = (undefined4 *)(param_3 + 0x168);
  if (4 < *(uint *)(param_3 + 0x178)) {
    ExceptionList = &pvStack_10;
    FUN_00d16ca0(auStack_44,puVar6);
    uStack_8 = 0;
    if (0xf < *(uint *)(iVar2 + 0x17c)) {
      puVar6 = (undefined4 *)*puVar6;
    }
    iVar2 = FUN_01723e00(puVar6,&DAT_01932cec,4);
    if (iVar2 == 0) {
      iVar2 = param_1 + 0xa9 + (uint)*(byte *)(param_1 + 0xa8);
      uVar3 = FUN_0055c740(iVar2,auStack_44);
      FUN_00562fc0(&param_3,uVar3,auStack_44,-(uint)(iVar2 != 0) & iVar2 + 1U);
      if (param_3 != 0) {
        puVar6 = (undefined4 *)FUN_00939b30(auStack_44);
        *param_2 = 0;
        param_2[1] = 0;
        if (puVar6[1] != 0) {
          LOCK();
          piVar4 = (int *)(puVar6[1] + 4);
          *piVar4 = *piVar4 + 1;
          UNLOCK();
        }
        *param_2 = *puVar6;
        param_2[1] = puVar6[1];
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return param_2;
      }
      iVar2 = FUN_00939c30(auStack_44);
      if (iVar2 != 0) {
        uVar3 = FUN_00939b30(auStack_44);
        FUN_00557fc0(uVar3);
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return param_2;
      }
      piVar4 = (int *)FUN_00939e30(auStack_18,auStack_44);
      if (*piVar4 != 0) {
        if ((*(int *)(param_1 + 0x60) == 0) || (FUN_00939e30(&iStack_14,auStack_44), iStack_14 == 0)
           ) {
          uVar3 = FUN_0091a050("Unable to find key in unordered_map.");
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_00917680(uVar3);
          pcVar1 = (code *)swi(3);
          puVar6 = (undefined4 *)(*pcVar1)();
          return puVar6;
        }
        iVar2 = *(int *)(iStack_14 + 0x24);
        iStack_20 = 0;
        uStack_1c = 0;
        if (iVar2 != 0) {
          piVar4 = (int *)(iVar2 + 4);
          iVar2 = *(int *)(iVar2 + 4);
          while (iVar2 != 0) {
            LOCK();
            iVar5 = *piVar4;
            if (iVar2 == iVar5) {
              *piVar4 = iVar2 + 1;
              iVar5 = iVar2;
            }
            UNLOCK();
            if (iVar5 == iVar2) {
              iStack_20 = *(int *)(iStack_14 + 0x20);
              uStack_1c = *(undefined4 *)(iStack_14 + 0x24);
              break;
            }
            iVar2 = *piVar4;
          }
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        if (iStack_20 != 0) {
          FUN_0054ef60(auStack_44);
          FUN_0093a150(param_2);
          FUN_00550b30();
          FUN_005507b0();
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00550b30();
      }
    }
    FUN_005507b0();
  }
  *param_2 = 0;
  param_2[1] = 0;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16844 ; VA 0x0093a150 ; FUN_0093a150 */

undefined4 * __thiscall FUN_0093a150(int param_1,undefined4 *param_2,int param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint in_stack_0000001c;
  int in_stack_00000020;
  uint uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_4c;
  int *piStack_48;
  uint uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined auStack_24 [8];
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c9ae8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_01ee2558);
  uStack_8._0_1_ = 1;
  uStack_14 = uVar2;
  puVar3 = (undefined4 *)FUN_00cfa7a0();
  uVar4 = (**(code **)*puVar3)();
  uStack_1c = 0;
  piStack_18 = (int *)0x0;
  FUN_00727ee0(uVar4,param_2);
  uStack_8._0_1_ = 2;
  FUN_00cf9ed0(in_stack_00000020);
  in_stack_00000020 = param_1 + 0xc0;
  FUN_0054ef60(&param_3);
  piVar1 = piStack_18;
  uStack_64 = uStack_44;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piStack_18[1] = piStack_18[1] + 1;
    UNLOCK();
  }
  uStack_44 = uStack_44 & 0xffffff00;
  uStack_60 = uStack_40;
  uStack_5c = uStack_3c;
  uStack_58 = uStack_38;
  uStack_4c = uStack_1c;
  uStack_34 = 0;
  uStack_30 = 0xf;
  piStack_48 = piStack_18;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_8._0_1_ = 4;
  FUN_00938bb0(auStack_24,&uStack_64,&uStack_64);
  FUN_0056cac0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_0056cac0();
  puVar3 = (undefined4 *)FUN_00939b30(&param_3);
  iVar5 = puVar3[1];
  *param_2 = 0;
  param_2[1] = 0;
  if (iVar5 != 0) {
    LOCK();
    *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
    UNLOCK();
    iVar5 = puVar3[1];
  }
  *param_2 = *puVar3;
  param_2[1] = iVar5;
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar5 = piVar1[1] + -1;
    piVar1[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      iVar5 = piVar1[2] + -1;
      piVar1[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_01675290(uVar2);
  if (0xf < in_stack_0000001c) {
    uVar6 = in_stack_0000001c + 1;
    iVar5 = param_3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(param_3 + -4);
      uVar6 = in_stack_0000001c + 0x24;
      if (0x1f < (param_3 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16845 ; VA 0x0093a300 ; FUN_0093a300 */

uint FUN_0093a300(void)

{
  int iVar1;
  
  iVar1 = FUN_00938790();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 16846 ; VA 0x0093a320 ; FUN_0093a320 */

uint FUN_0093a320(void)

{
  int iVar1;
  
  iVar1 = FUN_00938790();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 16847 ; VA 0x0093a340 ; FUN_0093a340 */

void __thiscall FUN_0093a340(int *param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  
  if (param_2 != 0) {
    iVar1 = *(int *)(param_2 + 0xc);
    iVar3 = FUN_00b50240();
    if ((uint)*(ushort *)(iVar3 + 0x1da) <
        (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) {
      iVar1 = *(int *)(param_2 + 0xc);
      iVar3 = FUN_00cfb1a0();
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
          (uint)*(ushort *)(iVar3 + 0x1da)) {
        FUN_0093a960(param_2,1);
      }
    }
    else {
      FUN_0093aac0(param_2,1);
    }
  }
  piVar2 = *(int **)(param_2 + 0x2c);
  if ((piVar2 != (int *)0x0) && (puVar4 = (undefined4 *)*piVar2, puVar4 != (undefined4 *)piVar2[1]))
  {
    do {
      (**(code **)(*param_1 + 0xa4))(*puVar4);
      puVar4 = puVar4 + 2;
    } while (puVar4 != *(undefined4 **)(*(int *)(param_2 + 0x2c) + 4));
  }
  return;
}



/* FUNCTION 16848 ; VA 0x0093a3e0 ; FUN_0093a3e0 */

void __fastcall FUN_0093a3e0(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 *puStack_20;
  undefined4 *puStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c9b08;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(param_1 + 0x2c);
  if (piVar1 != (int *)0x0) {
    if (piVar1[1] - *piVar1 >> 3 != 0) {
      puStack_20 = (undefined4 *)0x0;
      puStack_1c = (undefined4 *)0x0;
      iStack_18 = 0;
      uStack_8 = 0;
      ExceptionList = &pvStack_10;
      FUN_009388b0(0,*piVar1,piVar1[1],uStack_14);
      puVar2 = puStack_20;
      puVar4 = puStack_20;
      if (puStack_20 != puStack_1c) {
        do {
          if (puVar4[1] != 0) {
            LOCK();
            piVar1 = (int *)(puVar4[1] + 4);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
          }
          FUN_0093a4f0(*puVar4,puVar4[1]);
          puVar4 = puVar4 + 2;
        } while (puVar4 != puStack_1c);
      }
      if (puVar2 != (undefined4 *)0x0) {
        FUN_005596d0(puVar2,puStack_1c,&puStack_20);
        uVar3 = iStack_18 - (int)puVar2 & 0xfffffff8;
        puVar4 = puVar2;
        if (0xfff < uVar3) {
          puVar4 = (undefined4 *)puVar2[-1];
          uVar3 = uVar3 + 0x23;
          if (0x1f < (uint)((int)puVar2 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(puVar4,uVar3);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16849 ; VA 0x0093a4f0 ; FUN_0093a4f0 */

uint __thiscall FUN_0093a4f0(int param_1,uint param_2,int *param_3)

{
  uint *puVar1;
  uint uVar2;
  bool bVar3;
  bool bVar4;
  char cVar5;
  uint uVar6;
  int iVar7;
  undefined4 uVar8;
  int iVar9;
  undefined4 ****ppppuVar10;
  undefined4 *puVar11;
  int *piVar12;
  int *piVar13;
  int *piVar14;
  undefined4 ***apppuStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  int *piStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  uint uStack_20;
  int *piStack_1c;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c9b30;
  pvStack_10 = ExceptionList;
  piStack_34 = (int *)0x0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iStack_18 = param_1;
  uVar6 = FUN_00d17300(param_2,param_3);
  if ((char)uVar6 != '\0') {
    iVar7 = FUN_008f7870(param_1);
    if ((iVar7 == 0) || (iVar7 == -0xc)) {
      uVar8 = 0;
    }
    else {
      uVar8 = FUN_0055e310();
    }
    FUN_008a65e0(uVar8,0);
    if ((param_2 == 0) ||
       (iVar7 = *(int *)(param_2 + 0xc), iVar9 = FUN_00daf7e0(),
       (uint)*(ushort *)(iVar9 + 0x1da) <
       (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar9 + 0x1d8))) {
      piStack_2c = (int *)0x0;
      puVar11 = &uStack_30;
      uStack_14 = 0;
      bVar4 = false;
      bVar3 = true;
    }
    else {
      uStack_14 = param_2;
      if (param_3 != (int *)0x0) {
        LOCK();
        param_3[1] = param_3[1] + 1;
        UNLOCK();
      }
      puVar11 = &uStack_28;
      piStack_24 = param_3;
      bVar4 = true;
      bVar3 = false;
    }
    piStack_34 = (int *)puVar11[1];
    *puVar11 = 0;
    uStack_20 = uStack_14;
    puVar11[1] = 0;
    piVar13 = piStack_2c;
    piStack_1c = piStack_34;
    if ((bVar3) && (piStack_2c != (int *)0x0)) {
      LOCK();
      iVar7 = piStack_2c[1] + -1;
      piStack_2c[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_2c)();
        LOCK();
        piVar14 = piVar13 + 2;
        iVar7 = *piVar14 + -1;
        *piVar14 = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar13 + 4))();
        }
      }
    }
    piVar13 = piStack_24;
    if ((bVar4) && (piStack_24 != (int *)0x0)) {
      LOCK();
      iVar7 = piStack_24[1] + -1;
      piStack_24[1] = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar14 = piVar13 + 2;
        iVar7 = *piVar14 + -1;
        *piVar14 = iVar7;
        UNLOCK();
        if (iVar7 == 0) {
          (**(code **)(*piVar13 + 4))();
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    uVar6 = uStack_14;
    if (uStack_14 != 0) {
      FUN_00b74b30(apppuStack_4c,uStack_14 + 0x54);
      iVar7 = iStack_18;
      if (*(int *)(iStack_18 + 0x60) != 0) {
        piStack_24 = (int *)FUN_0055c740((byte *)(iStack_18 + 0x58) +
                                         *(byte *)(iStack_18 + 0x58) + 1,apppuStack_4c);
        piStack_1c = *(int **)(iVar7 + 0x5c);
        uStack_14 = (uint)piStack_24 % (uint)piStack_1c;
        piStack_2c = (int *)(uStack_14 * 4);
        piVar13 = *(int **)((int)piStack_2c + *(int *)(iVar7 + 0x6c));
        if ((piVar13 != (int *)0x0) && (piVar14 = (int *)*piVar13, piVar14 != (int *)0x0)) {
          while ((uint)piVar14[1] % (uint)piStack_1c == uStack_14) {
            if ((int *)piVar14[1] == piStack_24) {
              piVar12 = piVar14 + 2;
              if (0xf < (uint)piVar14[7]) {
                piVar12 = (int *)*piVar12;
              }
              ppppuVar10 = apppuStack_4c;
              if (0xf < uStack_38) {
                ppppuVar10 = (undefined4 ****)apppuStack_4c[0];
              }
              cVar5 = FUN_0055c360(ppppuVar10,uStack_3c,piVar12,piVar14[6]);
              iVar7 = iStack_18;
              if (cVar5 != '\0') {
                FUN_00939d90(piVar13,*piVar14);
                if (*piVar13 != 0) {
                  uVar6 = *(uint *)(*piVar13 + 4) % *(uint *)(iVar7 + 0x5c);
                  if (uStack_14 == uVar6) break;
                  *(int **)(*(int *)(iVar7 + 0x6c) + uVar6 * 4) = piVar13;
                }
                puVar11 = (undefined4 *)(*(int *)(iVar7 + 0x6c) + (int)piStack_2c);
                if ((int *)*puVar11 == piVar13) {
                  *puVar11 = 0;
                }
                break;
              }
            }
            piVar12 = (int *)*piVar14;
            piVar13 = piVar14;
            piVar14 = piVar12;
            if (piVar12 == (int *)0x0) break;
          }
        }
      }
      uVar6 = FUN_005507b0();
    }
    piVar13 = piStack_34;
    if (piStack_34 != (int *)0x0) {
      LOCK();
      puVar1 = (uint *)(piStack_34 + 1);
      uVar2 = *puVar1;
      uVar6 = *puVar1;
      *puVar1 = uVar2 - 1;
      UNLOCK();
      if (uVar2 - 1 == 0) {
        (**(code **)*piStack_34)();
        LOCK();
        puVar1 = (uint *)(piVar13 + 2);
        uVar2 = *puVar1;
        uVar6 = *puVar1;
        *puVar1 = uVar2 - 1;
        UNLOCK();
        if (uVar2 - 1 == 0) {
          uVar6 = (**(code **)(*piVar13 + 4))();
        }
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    puVar1 = (uint *)(param_3 + 1);
    uVar2 = *puVar1;
    uVar6 = *puVar1;
    *puVar1 = uVar2 - 1;
    UNLOCK();
    if (uVar2 - 1 == 0) {
      uVar6 = (**(code **)*param_3)();
      LOCK();
      piVar13 = param_3 + 2;
      iVar7 = *piVar13;
      *piVar13 = *piVar13 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        uVar6 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar6;
}



/* FUNCTION 16850 ; VA 0x0093a7c0 ; FUN_0093a7c0 */

void FUN_0093a7c0(int *param_1)

{
  int iVar1;
  uint uVar2;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba918;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(param_1 + 0x3e);
  uStack_8 = 0;
  FUN_00d178f0(aiStack_28);
  (**(code **)(*param_1 + 0x154))(aiStack_28);
  if (0xf < uStack_14) {
    uVar2 = uStack_14 + 1;
    iVar1 = aiStack_28[0];
    if (0xfff < uVar2) {
      iVar1 = *(int *)(aiStack_28[0] + -4);
      uVar2 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16851 ; VA 0x0093a860 ; FUN_0093a860 */

void FUN_0093a860(int *param_1)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ba918;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  uStack_8 = 0;
  puVar1 = (uint *)(param_1 + 0x5a);
  ExceptionList = &pvStack_10;
  if (auStack_28 != puVar1) {
    if (0xf < (uint)param_1[0x5f]) {
      puVar1 = (uint *)*puVar1;
    }
    ExceptionList = &pvStack_10;
    FUN_005542c0(puVar1,param_1[0x5e]);
  }
  FUN_00d178f0(auStack_28);
  FUN_00b554b0(auStack_28);
  puVar1 = (uint *)(param_1 + 0x3e);
  if (auStack_28 != puVar1) {
    if (0xf < (uint)param_1[0x43]) {
      puVar1 = (uint *)*puVar1;
    }
    FUN_005542c0(puVar1,param_1[0x42]);
  }
  FUN_00d178f0(auStack_28);
  (**(code **)(*param_1 + 0x154))(auStack_28);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16852 ; VA 0x0093a960 ; FUN_0093a960 */

void FUN_0093a960(int *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_44 [4];
  int iStack_34;
  uint uStack_30;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9b58;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_01675290(DAT_01ee2558);
  iStack_8 = 0;
  uStack_14 = uVar1;
  FUN_0054ef60(param_1 + 0x3e);
  iStack_8._0_1_ = 1;
  if (iStack_34 != 0) {
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
    FUN_005542c0("PhysicsData",0xb);
    iStack_8._0_1_ = 2;
    FUN_00d17a30(auStack_44,param_2,auStack_2c);
    iStack_8._0_1_ = 1;
    if (0xf < uStack_18) {
      uVar3 = uStack_18 + 1;
      uVar2 = auStack_2c[0];
      if (0xfff < uVar3) {
        uVar2 = *(uint *)(auStack_2c[0] - 4);
        uVar3 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar2,uVar3);
    }
    uStack_1c = 0;
    uStack_18 = 0xf;
    auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  }
  (**(code **)(*param_1 + 0x154))(auStack_44);
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if (0xf < uStack_30) {
    uVar3 = uStack_30 + 1;
    uVar2 = auStack_44[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_44[0] - 4);
      uVar3 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  iStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  iStack_8 = 3;
  FUN_01675290(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16853 ; VA 0x0093aac0 ; FUN_0093aac0 */

void FUN_0093aac0(int *param_1,undefined4 param_2)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c9b88;
  pvStack_10 = ExceptionList;
  iStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = auStack_28[0] & 0xffffff00;
  iStack_8 = 0;
  puVar1 = (uint *)(param_1 + 0x5a);
  ExceptionList = &pvStack_10;
  if (auStack_28 != puVar1) {
    if (0xf < (uint)param_1[0x5f]) {
      puVar1 = (uint *)*puVar1;
    }
    ExceptionList = &pvStack_10;
    FUN_005542c0(puVar1,param_1[0x5e]);
    if (iStack_18 != 0) {
      uStack_30 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = auStack_40[0] & 0xffffff00;
      FUN_005542c0("MeshData",8);
      iStack_8._0_1_ = 1;
      FUN_00d17a30(auStack_28,param_2,auStack_40);
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      if (0xf < uStack_2c) {
        uVar3 = uStack_2c + 1;
        uVar2 = auStack_40[0];
        if (0xfff < uVar3) {
          uVar2 = *(uint *)(auStack_40[0] - 4);
          uVar3 = uStack_2c + 0x24;
          if (0x1f < (auStack_40[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar2,uVar3);
      }
      FUN_00b554b0(auStack_28);
    }
  }
  puVar1 = (uint *)(param_1 + 0x3e);
  if (auStack_28 != puVar1) {
    if (0xf < (uint)param_1[0x43]) {
      puVar1 = (uint *)*puVar1;
    }
    FUN_005542c0(puVar1,param_1[0x42]);
  }
  if (iStack_18 != 0) {
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_005542c0("PhysicsData",0xb);
    iStack_8._0_1_ = 2;
    FUN_00d17a30(auStack_28,param_2,auStack_40);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_2c) {
      uVar3 = uStack_2c + 1;
      uVar2 = auStack_40[0];
      if (0xfff < uVar3) {
        uVar2 = *(uint *)(auStack_40[0] - 4);
        uVar3 = uStack_2c + 0x24;
        if (0x1f < (auStack_40[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar2,uVar3);
    }
  }
  (**(code **)(*param_1 + 0x154))(auStack_28);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    uVar2 = auStack_28[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_28[0] - 4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (auStack_28[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16854 ; VA 0x0093aca0 ; FUN_0093aca0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0093aca0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9bc0;
  pvStack_10 = ExceptionList;
  if (DAT_01ee2780 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee2998) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee2998);
      if (DAT_01ee2998 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00d14e90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"NonReplicatedCSGDictionaryService",1,uStack_20,0,0,0x1b,6,0);
        _DAT_01ee2990 = RBX::Creator<class_RBX::NonReplicatedCSGDictionaryService>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee2788,&DAT_01ee2990);
        FUN_016f3654(FUN_018850c0);
        FUN_016f37bf(&DAT_01ee2998);
      }
    }
    DAT_01ee2780 = &DAT_01ee2788;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee2780;
}



/* FUNCTION 16855 ; VA 0x0093ada0 ; FUN_0093ada0 */

void FUN_0093ada0(void)

{
  int iVar1;
  
  if (DAT_01ee299c == 0) {
    iVar1 = FUN_0093aca0();
    DAT_01ee299c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 16856 ; VA 0x0093adc0 ; FUN_0093adc0 */

undefined4 * __fastcall FUN_0093adc0(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9be8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00d15c40();
  uStack_8 = 0;
  *param_1 = RBX::
             DescribedCreatable<class_RBX::NonReplicatedCSGDictionaryService,class_RBX::FlyweightService>
             ::vftable;
  uVar1 = FUN_0093aca0();
  param_1[3] = uVar1;
  uStack_8 = 1;
  *param_1 = RBX::NonReplicatedCSGDictionaryService::vftable;
  uStack_1c = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  FUN_005542c0("NonReplicatedCSGDictionaryService",0x21);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_008a6520(auStack_2c);
  if (0xf < uStack_18) {
    uVar3 = uStack_18 + 1;
    uVar2 = auStack_2c[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_2c[0] - 4);
      uVar3 = uStack_18 + 0x24;
      if (0x1f < (auStack_2c[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16857 ; VA 0x0093ae80 ; FUN_0093ae80 */

void __fastcall FUN_0093ae80(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::NonReplicatedCSGDictionaryService>::vftable;
  uVar1 = FUN_0093aca0(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16858 ; VA 0x0093aec0 ; FUN_0093aec0 */

undefined4 * FUN_0093aec0(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_0055e250(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 16859 ; VA 0x0093af30 ; FUN_0093af30 */

uint FUN_0093af30(void)

{
  int iVar1;
  
  iVar1 = FUN_0093aca0();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 16860 ; VA 0x0093af50 ; FUN_0093af50 */

uint FUN_0093af50(void)

{
  int iVar1;
  
  iVar1 = FUN_0093aca0();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 16861 ; VA 0x0093af70 ; FUN_0093af70 */

void __thiscall FUN_0093af70(int *param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  
  if ((param_2 != 0) &&
     (iVar1 = *(int *)(param_2 + 0xc), iVar3 = FUN_00b50240(),
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
     (uint)*(ushort *)(iVar3 + 0x1da))) {
    FUN_0093b080(param_2,1);
  }
  piVar2 = *(int **)(param_2 + 0x2c);
  if ((piVar2 != (int *)0x0) && (puVar4 = (undefined4 *)*piVar2, puVar4 != (undefined4 *)piVar2[1]))
  {
    do {
      (**(code **)(*param_1 + 0xa4))(*puVar4);
      puVar4 = puVar4 + 2;
    } while (puVar4 != *(undefined4 **)(*(int *)(param_2 + 0x2c) + 4));
  }
  return;
}



/* FUNCTION 16862 ; VA 0x0093afe0 ; FUN_0093afe0 */

void FUN_0093afe0(void)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ba918;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b53a60();
  FUN_0054ef60(uVar1);
  uStack_8 = 0;
  FUN_00d178f0(aiStack_28);
  FUN_00b550f0(aiStack_28);
  if (0xf < uStack_14) {
    uVar3 = uStack_14 + 1;
    iVar2 = aiStack_28[0];
    if (0xfff < uVar3) {
      iVar2 = *(int *)(aiStack_28[0] + -4);
      uVar3 = uStack_14 + 0x24;
      if (0x1f < (aiStack_28[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16863 ; VA 0x0093b080 ; FUN_0093b080 */

void FUN_0093b080(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int aiStack_40 [4];
  int iStack_30;
  uint uStack_2c;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9c10;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_00b53a60();
  FUN_0054ef60(uVar1);
  iStack_8 = 0;
  if (iStack_30 != 0) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    FUN_005542c0("ChildData",9);
    iStack_8._0_1_ = 1;
    FUN_00d17a30(aiStack_40,param_2,auStack_28);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_14) {
      uVar3 = uStack_14 + 1;
      uVar4 = auStack_28[0];
      if (0xfff < uVar3) {
        uVar4 = *(uint *)(auStack_28[0] - 4);
        uVar3 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar4,uVar3);
    }
    FUN_00b550f0(aiStack_40);
  }
  if (0xf < uStack_2c) {
    uVar4 = uStack_2c + 1;
    iVar2 = aiStack_40[0];
    if (0xfff < uVar4) {
      iVar2 = *(int *)(aiStack_40[0] + -4);
      uVar4 = uStack_2c + 0x24;
      if (0x1f < (aiStack_40[0] - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16864 ; VA 0x0093b180 ; FUN_0093b180 */

int * __thiscall FUN_0093b180(int *param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9c30;
  pvStack_10 = ExceptionList;
  uStack_1c = param_2;
  uStack_18 = param_3;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  iVar2 = FUN_0093b920(&uStack_1c);
  *param_1 = iVar2;
  if (iVar2 != 0) {
    LOCK();
    *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
    UNLOCK();
  }
  uStack_8 = 0;
  cVar1 = FUN_0168a8f0();
  if (cVar1 != '\0') {
    ExceptionList = pvStack_10;
    return param_1;
  }
  uVar3 = FUN_005503c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
  FUN_0054e630(uVar3);
}



/* FUNCTION 16865 ; VA 0x0093b200 ; FUN_0093b200 */

int __thiscall FUN_0093b200(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9c48;
  pvStack_10 = ExceptionList;
  iVar5 = *param_1;
  iVar2 = (param_1[1] - iVar5) / 0x30;
  if (iVar2 == 0x5555555) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar6 = iVar2 + 1;
  uVar3 = (param_1[2] - iVar5) / 0x30;
  uVar8 = uVar6;
  if ((uVar3 <= 0x5555555 - (uVar3 >> 1)) && (uVar8 = (uVar3 >> 1) + uVar3, uVar8 < uVar6)) {
    uVar8 = uVar6;
  }
  ExceptionList = &pvStack_10;
  iVar4 = FUN_00847730(uVar8);
  uStack_8 = 0;
  iVar5 = ((param_2 - iVar5) / 0x30) * 0x30;
  FUN_0054ef60(param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_0054ef60(param_4);
  if (param_2 == param_1[1]) {
    FUN_0093b470(*param_1,param_1[1],iVar4,param_1);
  }
  else {
    FUN_0093b470(*param_1,param_2,iVar4,param_1);
    FUN_0093b470(param_2,param_1[1],iVar5 + iVar4 + 0x30,param_1);
  }
  if (*param_1 != 0) {
    FUN_008bd9e0(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar6 = ((param_1[2] - iVar1) / 0x30) * 0x30;
    iVar7 = iVar1;
    if (0xfff < uVar6) {
      iVar7 = *(int *)(iVar1 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar1 - iVar7) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar7,uVar6);
  }
  *param_1 = iVar4;
  param_1[1] = (iVar2 * 3 + 3) * 0x10 + iVar4;
  param_1[2] = uVar8 * 0x30 + iVar4;
  ExceptionList = pvStack_10;
  return *param_1 + iVar5;
}



/* FUNCTION 16866 ; VA 0x0093b3a9 ; Catch_All@0093b3a9 */

void Catch_All_0093b3a9(void)

{
  int unaff_EBP;
  
  FUN_008c7710(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x18));
  FUN_007c6100(*(undefined4 *)(unaff_EBP + -0x20),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16867 ; VA 0x0093b3e0 ; FUN_0093b3e0 */

void __thiscall FUN_0093b3e0(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c9c60;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_`anonymous_namespace'::DynamicSettingsPicker>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16868 ; VA 0x0093b44e ; Catch_All@0093b44e */

void Catch_All_0093b44e(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16869 ; VA 0x0093b470 ; FUN_0093b470 */

undefined4 *
FUN_0093b470(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  
  puVar6 = param_3;
  if (param_1 != param_2) {
    puVar5 = param_1 + 0xb;
    do {
      puVar6[4] = 0;
      puVar6[5] = 0;
      puVar1 = puVar5 + 1;
      uVar2 = puVar5[-10];
      uVar3 = puVar5[-9];
      uVar4 = puVar5[-8];
      *puVar6 = puVar5[-0xb];
      puVar6[1] = uVar2;
      puVar6[2] = uVar3;
      puVar6[3] = uVar4;
      *(undefined8 *)(puVar6 + 4) = *(undefined8 *)(puVar5 + -7);
      puVar5[-7] = 0;
      puVar5[-6] = 0xf;
      *(undefined *)(puVar5 + -0xb) = 0;
      puVar6[10] = 0;
      *(undefined4 *)((int)param_3 + (-0x30 - (int)param_1) + (int)(puVar5 + 0xc)) = 0;
      uVar2 = puVar5[-4];
      uVar3 = puVar5[-3];
      uVar4 = puVar5[-2];
      puVar6[6] = puVar5[-5];
      puVar6[7] = uVar2;
      puVar6[8] = uVar3;
      puVar6[9] = uVar4;
      *(undefined8 *)(puVar6 + 10) = *(undefined8 *)(puVar5 + -1);
      puVar6 = puVar6 + 0xc;
      puVar5[-1] = 0;
      *puVar5 = 0xf;
      *(undefined *)(puVar5 + -5) = 0;
      puVar5 = puVar5 + 0xc;
    } while (puVar1 != param_2);
  }
  FUN_008bd9e0(puVar6,puVar6,param_4);
  return puVar6;
}



/* FUNCTION 16870 ; VA 0x0093b520 ; FUN_0093b520 */

undefined ** __thiscall FUN_0093b520(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  bool bVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  undefined **ppuVar6;
  int *in_stack_00000040;
  undefined auStack_d8 [64];
  undefined auStack_98 [4];
  int *piStack_94;
  int aiStack_80 [9];
  int *piStack_5c;
  undefined auStack_58 [4];
  int *piStack_54;
  int aiStack_40 [9];
  int *piStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c9ca5;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  FUN_0093ba60(&param_2);
  uStack_8._0_1_ = 1;
  FUN_0093ba60(auStack_98);
  uStack_8._0_1_ = 2;
  cVar4 = FUN_00585a40(auStack_d8);
  if (cVar4 == '\0') {
    FUN_0093ba60(auStack_d8);
    uStack_8._0_1_ = 3;
    iStack_18 = FUN_01674e20(0x40);
    uStack_8._0_1_ = 4;
    if (iStack_18 == 0) {
      iVar5 = 0;
    }
    else {
      iVar5 = FUN_0093ba60(auStack_58);
    }
    param_1[2] = iVar5;
    if (piStack_1c != (int *)0x0) {
      (**(code **)(*piStack_1c + 0x10))(piStack_1c != aiStack_40);
      piStack_1c = (int *)0x0;
    }
    if (piStack_54 != (int *)0x0) {
      LOCK();
      iVar5 = piStack_54[1] + -1;
      piStack_54[1] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)*piStack_54)();
        LOCK();
        iVar5 = piStack_54[2] + -1;
        piStack_54[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piStack_54 + 4))();
        }
      }
    }
    FUN_0093bb60();
    bVar2 = true;
  }
  else {
    FUN_0093bb60();
    bVar2 = false;
  }
  if (piStack_5c != (int *)0x0) {
    (**(code **)(*piStack_5c + 0x10))(piStack_5c != aiStack_80);
    piStack_5c = (int *)0x0;
  }
  if (piStack_94 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_94[1] + -1;
    piStack_94[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_94)();
      LOCK();
      iVar5 = piStack_94[2] + -1;
      piStack_94[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_94 + 4))();
      }
    }
  }
  ppuVar6 = &PTR_FUN_019333d8;
  if (!bVar2) {
    ppuVar6 = (undefined **)0x0;
  }
  *piStack_14 = (int)ppuVar6;
  if (in_stack_00000040 != (int *)0x0) {
    ppuVar6 = (undefined **)
              (**(code **)(*in_stack_00000040 + 0x10))(in_stack_00000040 != (int *)&stack0x0000001c)
    ;
    in_stack_00000040 = (int *)0x0;
  }
  piVar3 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar5 = *piVar1;
    ppuVar6 = (undefined **)*piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      ppuVar6 = (undefined **)(**(code **)*param_3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar5 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        ppuVar6 = (undefined **)(**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return ppuVar6;
}



/* FUNCTION 16871 ; VA 0x0093b6e0 ; FUN_0093b6e0 */

void __thiscall FUN_0093b6e0(undefined4 *param_1)

{
  bool bVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  undefined **ppuVar5;
  int *piVar6;
  int *in_stack_00000028;
  int aiStack_94 [9];
  int *piStack_70;
  int aiStack_6c [9];
  int *piStack_48;
  int *piStack_44;
  int aiStack_40 [9];
  int *piStack_1c;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined uStack_8;
  undefined3 uStack_7;
  
  puStack_c = &LAB_017c9d02;
  pvStack_10 = ExceptionList;
  piStack_14 = aiStack_94;
  piStack_70 = (int *)0x0;
  uStack_8 = 1;
  uStack_7 = 0;
  ExceptionList = &pvStack_10;
  puStack_18 = param_1;
  if (in_stack_00000028 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    piStack_70 = (int *)(**(code **)*in_stack_00000028)(aiStack_94);
  }
  piStack_14 = aiStack_40;
  piStack_1c = (int *)0x0;
  uStack_8 = 3;
  if (piStack_70 != (int *)0x0) {
    piStack_1c = (int *)(**(code **)*piStack_70)(aiStack_40);
  }
  piVar6 = piStack_70;
  piVar3 = in_stack_00000028;
  uStack_8 = 4;
  cVar2 = FUN_00585a40(aiStack_40);
  if (cVar2 == '\0') {
    piStack_14 = aiStack_6c;
    piStack_48 = (int *)0x0;
    uStack_8 = 5;
    if (piStack_1c != (int *)0x0) {
      piStack_48 = (int *)(**(code **)*piStack_1c)(aiStack_6c);
    }
    uStack_8 = 6;
    piVar3 = (int *)FUN_01674e20(0x28);
    uStack_8 = 7;
    piStack_14 = piVar3;
    if (piVar3 == (int *)0x0) {
      piVar3 = (int *)0x0;
    }
    else {
      piVar3[9] = 0;
      uStack_8 = 8;
      piStack_44 = piVar3;
      if (piStack_48 != (int *)0x0) {
        iVar4 = (**(code **)*piStack_48)(piVar3);
        piVar3[9] = iVar4;
      }
    }
    param_1[2] = piVar3;
    if (piStack_48 != (int *)0x0) {
      (**(code **)(*piStack_48 + 0x10))(piStack_48 != aiStack_6c);
      piStack_48 = (int *)0x0;
    }
    if (piStack_1c != (int *)0x0) {
      (**(code **)(*piStack_1c + 0x10))(piStack_1c != aiStack_40);
      piStack_1c = (int *)0x0;
    }
    bVar1 = true;
    piVar6 = piStack_70;
    piVar3 = in_stack_00000028;
  }
  else {
    if (piStack_1c != (int *)0x0) {
      (**(code **)(*piStack_1c + 0x10))(piStack_1c != aiStack_40);
      piStack_1c = (int *)0x0;
      piVar6 = piStack_70;
      piVar3 = in_stack_00000028;
    }
    bVar1 = false;
  }
  if (piVar6 != (int *)0x0) {
    (**(code **)(*piVar6 + 0x10))(piVar6 != aiStack_94);
    piVar3 = in_stack_00000028;
  }
  ppuVar5 = &PTR_FUN_019333d0;
  if (!bVar1) {
    ppuVar5 = (undefined **)0x0;
  }
  *puStack_18 = ppuVar5;
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 0x10))(piVar3 != (int *)&stack0x00000004);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16872 ; VA 0x0093b8b0 ; FUN_0093b8b0 */

void FUN_0093b8b0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  param_2[4] = 0;
  param_2[5] = 0;
  uVar1 = param_3[1];
  uVar2 = param_3[2];
  uVar3 = param_3[3];
  *param_2 = *param_3;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(param_3 + 4);
  param_3[4] = 0;
  param_3[5] = 0xf;
  *(undefined *)param_3 = 0;
  param_2[10] = 0;
  param_2[0xb] = 0;
  uVar1 = param_3[7];
  uVar2 = param_3[8];
  uVar3 = param_3[9];
  param_2[6] = param_3[6];
  param_2[7] = uVar1;
  param_2[8] = uVar2;
  param_2[9] = uVar3;
  *(undefined8 *)(param_2 + 10) = *(undefined8 *)(param_3 + 10);
  param_3[10] = 0;
  param_3[0xb] = 0xf;
  *(undefined *)(param_3 + 6) = 0;
  return;
}



/* FUNCTION 16873 ; VA 0x0093b920 ; FUN_0093b920 */

undefined4 * FUN_0093b920(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9d4c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = GetProcessHeap(0,0x44);
  puVar2 = (undefined4 *)HeapAlloc(uVar1);
  if (puVar2 == (undefined4 *)0x0) {
    uVar1 = FUN_0054fbc0();
    uStack_8 = 0;
    FUN_005648a0(uVar1);
  }
  else {
    *puVar2 = boost::detail::thread_data_base::vftable;
    puVar2[1] = 0;
    puVar2[2] = 0;
    puVar2[3] = 0;
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    puVar2[4] = 0;
    puVar2[5] = 0;
    uVar1 = FUN_00575ab0();
    puVar2[4] = uVar1;
    puVar2[6] = 0;
    puVar2[7] = 0;
    puVar2[8] = 0;
    puVar2[9] = 0;
    puVar2[10] = 0;
    puVar2[0xb] = 0;
    puVar2[0xc] = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    iVar3 = CreateEventA(0,1,0,0);
    if (iVar3 != 0) {
      puVar2[0xd] = iVar3;
      *(undefined *)(puVar2 + 0xe) = 1;
      *puVar2 = boost::detail::
                thread_data<class_boost::_bi::bind_t<void,class_boost::_mfi::mf0<void,class_RBX::DynamicFastVariableReloader>,class_boost::_bi::list1<class_boost::_bi::value<class_RBX::DynamicFastVariableReloader*>_>_>_>
                ::vftable;
      puVar2[0xf] = *param_1;
      puVar2[0x10] = param_1[1];
      ExceptionList = pvStack_10;
      return puVar2;
    }
  }
  uVar1 = FUN_005503c0();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
                    /* WARNING: Subroutine does not return */
  FUN_0054e630(uVar1);
}



/* FUNCTION 16874 ; VA 0x0093ba19 ; Catch_All@0093ba19 */

void Catch_All_0093ba19(void)

{
  int unaff_EBP;
  
  FUN_00581530(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16875 ; VA 0x0093ba60 ; FUN_0093ba60 */

undefined4 * __thiscall FUN_0093ba60(undefined4 *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c9d70;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  if (param_2[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_2[1] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  uVar4 = param_2[3];
  uVar2 = param_2[4];
  uVar3 = param_2[5];
  param_1[2] = param_2[2];
  param_1[3] = uVar4;
  param_1[4] = uVar2;
  param_1[5] = uVar3;
  param_1[0xf] = 0;
  uStack_8 = 1;
  if ((undefined4 *)param_2[0xf] != (undefined4 *)0x0) {
    uVar4 = (*(code *)**(undefined4 **)param_2[0xf])(param_1 + 6);
    param_1[0xf] = uVar4;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16876 ; VA 0x0093baf0 ; FUN_0093baf0 */

undefined4 * __fastcall FUN_0093baf0(undefined4 *param_1)

{
  undefined4 uVar1;
  
  *param_1 = SimpleJSON::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar1 = FUN_00575af0();
  param_1[1] = uVar1;
  *(undefined *)(param_1 + 3) = 0;
  param_1[8] = 0;
  param_1[9] = 0xf;
  *(undefined *)(param_1 + 4) = 0;
  *param_1 = _anon_F14EEA2A::DynamicSettingsPicker::vftable;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  return param_1;
}



/* FUNCTION 16877 ; VA 0x0093bb60 ; FUN_0093bb60 */

void __fastcall FUN_0093bb60(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_1 + 0x3c);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x10))(piVar2 != (int *)(param_1 + 0x18));
    *(undefined4 *)(param_1 + 0x3c) = 0;
  }
  piVar2 = *(int **)(param_1 + 4);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
                    /* WARNING: Could not recover jumptable at 0x0093bbaa. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar2 + 4))();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 16878 ; VA 0x0093bbb0 ; FUN_0093bbb0 */

void __fastcall FUN_0093bbb0(undefined4 *param_1)

{
  FUN_008bd9e0(*param_1,param_1[1],param_1[2]);
  return;
}



/* FUNCTION 16879 ; VA 0x0093bbd0 ; FUN_0093bbd0 */

void __fastcall FUN_0093bbd0(int *param_1)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined8 uVar6;
  int aiStack_114 [8];
  undefined4 uStack_f4;
  int *piStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e0;
  undefined4 *puStack_dc;
  undefined4 **ppuStack_d8;
  undefined8 uStack_d4;
  undefined auStack_88 [8];
  int aiStack_80 [4];
  undefined4 *apuStack_70 [4];
  undefined4 uStack_60;
  int *piStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined8 uStack_50;
  undefined4 uStack_48;
  int aiStack_44 [2];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int *piStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9de7;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee29e8) {
    uStack_d4._4_4_ = &DAT_01ee29e8;
    uStack_d4._0_4_ = (char *)0x93bf42;
    ExceptionList = &pvStack_10;
    FUN_016f3809();
    if (DAT_01ee29e8 == -1) {
      uStack_d4._4_4_ = (int *)0xffffffff;
      uStack_d4._0_4_ = "Dynamic Flag Reloader";
      ppuStack_d8 = (undefined4 **)0x18fb0a4;
      uStack_8 = 0;
      puStack_dc = (undefined4 *)0x93bf6a;
      uVar6 = FUN_0152dab0();
      DAT_01ee29e4 = (undefined4)((ulonglong)uVar6 >> 0x20);
      DAT_01ee29e0 = (undefined4)uVar6;
      puStack_dc = &DAT_01ee29e8;
      uStack_8 = 0xffffffff;
      uStack_e0 = 0x93bf86;
      FUN_016f37bf();
    }
  }
  uStack_d4._4_4_ = (int *)DAT_01ee29e4;
  uStack_d4._0_4_ = (char *)DAT_01ee29e0;
  uStack_1c = DAT_01ee29e0;
  uStack_48 = DAT_01ee29e4;
  uStack_58 = DAT_01ee29e0;
  uStack_54 = DAT_01ee29e4;
  ppuStack_d8 = (undefined4 **)0x93bc34;
  uStack_50 = FUN_0152d930();
  uStack_8 = 1;
  uStack_d4._4_4_ = (int *)0x93bc49;
  FUN_016772a0();
  if (DAT_01d6436c == '\0') {
    iVar1 = *(int *)(*param_1 + 0x2c);
    for (iVar5 = *(int *)(*param_1 + 0x28); iVar5 != iVar1; iVar5 = iVar5 + 0x30) {
      uStack_d4._4_4_ = (int *)0x0;
      uStack_d4._0_4_ = (char *)0x2;
      ppuStack_d8 = (undefined4 **)(iVar5 + 0x18);
      uStack_e0 = 0x93be23;
      puStack_dc = (undefined4 *)iVar5;
      FUN_016780e0();
    }
  }
  else {
    iStack_18 = 0;
    if (0 < (int)DAT_01ee29ac) {
      uStack_d4._4_4_ = (int *)0x93bc6b;
      iStack_18 = FUN_0093c740();
    }
    uStack_d4._4_4_ = (int *)0x0;
    uStack_d4._0_4_ = (char *)0x0;
    uStack_3c = 0;
    uStack_38 = 0;
    uStack_34 = 0;
    ppuStack_d8 = (undefined4 **)0x93bc8f;
    uStack_38 = FUN_005cb2b0();
    uStack_30 = 0;
    uStack_2c = 0;
    uStack_28 = 0;
    uStack_d4._4_4_ = (int *)0x8;
    uStack_8._0_1_ = 3;
    uStack_3c = 0x3f800000;
    uStack_d4._0_4_ = (char *)0x93bcbc;
    FUN_005cb500();
    uVar2 = uStack_1c;
    uStack_8._0_1_ = 4;
    iVar1 = *(int *)(*param_1 + 0x2c);
    for (iVar5 = *(int *)(*param_1 + 0x28); iVar5 != iVar1; iVar5 = iVar5 + 0x30) {
      uStack_d4._4_4_ = (int *)0x0;
      uStack_d4._0_4_ = (char *)0x2;
      ppuStack_d8 = (undefined4 **)(iVar5 + 0x18);
      uStack_e0 = 0x93bcde;
      puStack_dc = (undefined4 *)iVar5;
      FUN_016780e0();
      ppuStack_d8 = (undefined4 **)auStack_88;
      uStack_d4._4_4_ = (int *)uVar2;
      puStack_dc = (undefined4 *)0x93bcf2;
      uStack_d4._0_4_ = (char *)iVar5;
      FUN_00870280();
    }
    uStack_d4._4_4_ = (int *)0x2;
    uStack_d4._0_4_ = (char *)&uStack_3c;
    ppuStack_d8 = (undefined4 **)FUN_0093ccc0;
    puStack_dc = (undefined4 *)0x93bd09;
    FUN_01677790();
    if (0 < (int)DAT_01ee29ac) {
      uStack_d4._4_4_ = (int *)0x93bd1e;
      iVar5 = FUN_0093c740();
      iVar1 = iStack_18;
      if (iStack_18 != iVar5) {
        uStack_d4._4_4_ = (int *)0x0;
        uStack_d4._0_4_ = (char *)0x0;
        ppuStack_d8 = (undefined4 **)0xffffffff;
        puStack_dc = (undefined4 *)0x93bd3c;
        FUN_0151f6f0();
        uStack_d4._4_4_ = (int *)DAT_01d7a884;
        uStack_8._0_1_ = 5;
        uStack_d4._0_4_ = "Datacenter";
        ppuStack_d8 = (undefined4 **)0x93bd56;
        FUN_0151f9c0();
        uStack_d4._4_4_ = (int *)iVar1;
        uStack_d4._0_4_ = "OriginalVariance";
        ppuStack_d8 = (undefined4 **)0x93bd67;
        FUN_0151f9c0();
        uStack_d4._0_4_ = "ResultVariance";
        ppuStack_d8 = (undefined4 **)0x93bd78;
        uStack_d4._4_4_ = (int *)iVar5;
        FUN_0151f9c0();
        puVar4 = DAT_01ee29ac;
        uStack_d4._4_4_ = (int *)0x21;
        uStack_d4._0_4_ = "DynamicVariableReloadVarianceTest";
        uStack_60 = 0;
        piStack_5c = (int *)&DAT_0000000f;
        apuStack_70[0] = (undefined4 *)((uint)apuStack_70[0] & 0xffffff00);
        ppuStack_d8 = (undefined4 **)0x93bd9f;
        FUN_005542c0();
        uStack_d4._4_4_ = (int *)0x0;
        uStack_d4._0_4_ = (char *)puVar4;
        ppuStack_d8 = apuStack_70;
        uStack_8._0_1_ = 6;
        puStack_dc = (undefined4 *)0x93bdb5;
        FUN_01520d20();
        uStack_8._0_1_ = 5;
        if (&DAT_0000000f < piStack_5c) {
          uStack_d4._4_4_ = (int *)((int)piStack_5c + 1);
          puVar4 = apuStack_70[0];
          if ((int *)0xfff < uStack_d4._4_4_) {
            puVar4 = (undefined4 *)apuStack_70[0][-1];
            uStack_d4._4_4_ = piStack_5c + 9;
            if (0x1f < (uint)((int)apuStack_70[0] + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
              uStack_d4._4_4_ = (int *)&UNK_0093bf93;
              FUN_017167a3();
            }
          }
          ppuStack_d8 = (undefined4 **)0x93bdea;
          uStack_d4._0_4_ = (char *)puVar4;
          FUN_01674ea0();
        }
        uStack_d4._4_4_ = (int *)0x93bdf8;
        FUN_0151f7f0();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    uStack_d4._4_4_ = (int *)0x93be04;
    FUN_005cafb0();
    param_1 = piStack_14;
  }
  uStack_d4._4_4_ = (int *)0x2;
  uStack_d4._0_4_ = (char *)(param_1 + 2);
  ppuStack_d8 = (undefined4 **)FUN_0093d990;
  puStack_dc = (undefined4 *)0x93be3d;
  FUN_01677790();
  if ((undefined4 *)param_1[0xf] != (undefined4 *)0x0) {
    piStack_5c = (int *)0x0;
    piStack_14 = aiStack_80;
    piStack_f0 = aiStack_80;
    uStack_8._0_1_ = 7;
    uStack_f4 = 0x93be69;
    piStack_5c = (int *)(*(code *)**(undefined4 **)param_1[0xf])();
    piStack_14 = aiStack_44;
    piStack_20 = (int *)0x0;
    uStack_8._0_1_ = 9;
    if (piStack_5c != (int *)0x0) {
      piStack_f0 = aiStack_44;
      uStack_f4 = 0x93be8b;
      piStack_20 = (int *)(**(code **)*piStack_5c)();
    }
    piStack_14 = aiStack_114;
    uStack_ec = 0;
    piStack_f0 = (int *)0x0;
    uStack_8._0_1_ = 0xb;
    piVar3 = aiStack_114;
    if (piStack_20 != (int *)0x0) {
      piStack_f0 = (int *)(**(code **)*piStack_20)(aiStack_114);
      piVar3 = piStack_14;
    }
    piStack_14 = piVar3;
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    FUN_0093b6e0();
    if (piStack_20 != (int *)0x0) {
      piStack_f0 = (int *)CONCAT31((int3)((uint)aiStack_44 >> 8),piStack_20 != aiStack_44);
      uStack_f4 = 0x93bedb;
      (**(code **)(*piStack_20 + 0x10))();
      piStack_20 = (int *)0x0;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (piStack_5c != (int *)0x0) {
      piStack_f0 = (int *)CONCAT31((int3)((uint)aiStack_80 >> 8),piStack_5c != aiStack_80);
      uStack_f4 = 0x93befd;
      (**(code **)(*piStack_5c + 0x10))();
      piStack_5c = (int *)0x0;
    }
    piStack_f0 = (int *)0x93bf09;
    FUN_0151ded0();
  }
  uStack_8 = 0xc;
  ppuStack_d8 = (undefined4 **)uStack_48;
  puStack_dc = (undefined4 *)uStack_1c;
  uStack_e0 = 0x93bf24;
  uStack_d4 = uStack_50;
  FUN_0152dda0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16880 ; VA 0x0093bfa0 ; FUN_0093bfa0 */

undefined4 __thiscall FUN_0093bfa0(undefined4 param_1,byte param_2)

{
  FUN_016894b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x44);
  }
  return param_1;
}



/* FUNCTION 16881 ; VA 0x0093bfd0 ; FUN_0093bfd0 */

undefined4 __thiscall FUN_0093bfd0(undefined4 param_1,byte param_2)

{
  FUN_008c7c70();
  FUN_0056e4b0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x34);
  }
  return param_1;
}



/* FUNCTION 16882 ; VA 0x0093c000 ; FUN_0093c000 */

void __thiscall FUN_0093c000(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9e08;
  pvStack_10 = ExceptionList;
  if (param_4 == 2) {
    if (*(int *)(param_1 + 0x30) != *(int *)(param_1 + 0x2c)) {
      ExceptionList = &pvStack_10;
      FUN_0054ef60(param_2);
      uStack_8 = 0;
      FUN_0054ef60(param_3);
      *(int *)(param_1 + 0x2c) = *(int *)(param_1 + 0x2c) + 0x30;
      ExceptionList = pvStack_10;
      return;
    }
    ExceptionList = &pvStack_10;
    FUN_0093b200(*(int *)(param_1 + 0x2c),param_2,param_3);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16883 ; VA 0x0093c080 ; FUN_0093c080 */

void __thiscall FUN_0093c080(int *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (*param_1 != 0) {
    FUN_008bd9e0(*param_1,param_1[1],param_1);
    iVar1 = *param_1;
    uVar2 = ((param_1[2] - iVar1) / 0x30) * 0x30;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
  }
  *param_1 = param_2;
  param_1[1] = param_3 * 0x30 + param_2;
  param_1[2] = param_4 * 0x30 + param_2;
  return;
}



/* FUNCTION 16884 ; VA 0x0093c110 ; FUN_0093c110 */

void __thiscall FUN_0093c110(int param_1,undefined4 *param_2)

{
  *param_2 = std::
             _Func_impl_no_alloc<void_(__cdecl*)(enum_RBX::HttpErrorCode,class_RBX::HttpResponse&),void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
             ::vftable;
  param_2[1] = *(undefined4 *)(param_1 + 4);
  return;
}



/* FUNCTION 16885 ; VA 0x0093c130 ; FUN_0093c130 */

void __thiscall FUN_0093c130(int param_1,undefined4 *param_2,undefined4 param_3)

{
  (**(code **)(param_1 + 4))(*param_2,param_3);
  return;
}



/* FUNCTION 16886 ; VA 0x0093c150 ; FUN_0093c150 */

TypeDescriptor * FUN_0093c150(void)

{
  return &TypeDescriptor_01db6640;
}



/* FUNCTION 16887 ; VA 0x0093c160 ; FUN_0093c160 */

void __thiscall
FUN_0093c160(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_0093b470(param_2,param_3,param_4,param_1);
  return;
}



/* FUNCTION 16888 ; VA 0x0093c180 ; FUN_0093c180 */

void FUN_0093c180(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined auStack_94 [4];
  int *piStack_90;
  int aiStack_7c [9];
  int *piStack_58;
  undefined4 uStack_54;
  int *piStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  int aiStack_3c [9];
  int *piStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c9e43;
  pvStack_10 = ExceptionList;
  puStack_14 = &uStack_54;
  piStack_50 = (int *)param_1[1];
  ExceptionList = &pvStack_10;
  if (piStack_50 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piStack_50[1] = piStack_50[1] + 1;
    UNLOCK();
    piStack_50 = (int *)param_1[1];
  }
  uStack_54 = *param_1;
  piStack_18 = (int *)0x0;
  uStack_4c = *param_2;
  uStack_48 = param_2[1];
  uStack_44 = param_2[2];
  uStack_40 = param_2[3];
  uStack_8 = 1;
  if (*(undefined4 **)(param_3 + 0x24) != (undefined4 *)0x0) {
    piStack_18 = (int *)(**(code **)**(undefined4 **)(param_3 + 0x24))(aiStack_3c);
  }
  uStack_8 = 2;
  FUN_0093ba60(&uStack_54);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uVar4 = 0;
  FUN_0093ba60(auStack_94);
  FUN_0093b520();
  if (piStack_58 != (int *)0x0) {
    (**(code **)(*piStack_58 + 0x10))
              (CONCAT31((int3)((uint)aiStack_7c >> 8),piStack_58 != aiStack_7c),uVar4);
    piStack_58 = (int *)0x0;
  }
  if (piStack_90 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_90[1] + -1;
    piStack_90[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_90)();
      LOCK();
      iVar2 = piStack_90[2] + -1;
      piStack_90[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_90 + 4))();
      }
    }
  }
  uStack_8 = 0xffffffff;
  if (piStack_18 != (int *)0x0) {
    (**(code **)(*piStack_18 + 0x10))(piStack_18 != aiStack_3c);
    piStack_18 = (int *)0x0;
  }
  piVar3 = piStack_50;
  if (piStack_50 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_50[1] + -1;
    piStack_50[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_50)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_0151de50();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16889 ; VA 0x0093c2f0 ; FUN_0093c2f0 */

int FUN_0093c2f0(int param_1,int param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  double *pdVar5;
  int *piVar6;
  int *piVar7;
  undefined *puVar8;
  int *piVar9;
  uint uVar10;
  int *piVar11;
  bool bVar12;
  undefined auStack_44 [4];
  uint uStack_40;
  undefined4 uStack_3c;
  undefined auStack_38 [16];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9f04;
  pvStack_10 = ExceptionList;
  uStack_40 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0093cd70();
  if (*(char *)(iVar2 + 0xe8) == '\0') {
    iVar3 = FUN_01674e20(0x34);
    uStack_20 = (double)CONCAT44(iVar3,(undefined4)uStack_20);
    uStack_8 = 0;
    if (iVar3 == 0) {
      uVar4 = 0;
    }
    else {
      FUN_0170d1f0(iVar3,0,0x34);
      uVar4 = FUN_0093baf0();
    }
    uStack_8 = 0xffffffff;
    iStack_18 = 0;
    piStack_14 = (int *)0x0;
    FUN_0093b3e0(uVar4,uStack_20._4_4_);
    uStack_8 = 1;
    uStack_20._0_5_ = CONCAT14(param_1 != 0,(undefined4)uStack_20);
    if ((*(int *)(param_2 + 0xc) - 200U < 100) && (*(int *)(param_2 + 0xc) != 0xca)) {
      cVar1 = '\0';
    }
    else {
      cVar1 = '\x01';
    }
    bVar12 = false;
    uStack_3c = CONCAT31(uStack_3c._1_3_,cVar1);
    if (((param_1 == 0) && (*(int *)(param_2 + 0x50) != 0)) && (cVar1 == '\0')) {
      FUN_01684540(param_2 + 0x40);
      bVar12 = *(char *)(iStack_18 + 0xc) == '\0';
    }
    iVar3 = FUN_016dee6d(iVar2);
    if (iVar3 != 0) {
      FUN_016df3c9(iVar3);
    }
    uStack_8._0_1_ = 2;
    if (bVar12) {
      pdVar5 = (double *)FUN_016830f0(auStack_44);
      piVar6 = (int *)(iVar2 + 0x68);
      uStack_20 = (*pdVar5 - *(double *)(iVar2 + 0x48)) * DAT_018c0d70;
      if (0xf < *(uint *)(iVar2 + 0x7c)) {
        piVar6 = (int *)*piVar6;
      }
      uVar4 = FUN_01675640(auStack_38,"DynamicVariableReloadSuccess-%s",piVar6);
      uStack_8._0_1_ = 3;
      FUN_00878cf0(uVar4,SUB84(uStack_20,0),(int)((ulonglong)uStack_20 >> 0x20),0);
      uStack_8._0_1_ = 2;
      FUN_005507b0();
      piVar11 = (int *)(param_2 + 0x40);
      piVar6 = (int *)(iVar2 + 0x80);
      piVar9 = piVar11;
      if (0xf < *(uint *)(param_2 + 0x54)) {
        piVar9 = (int *)*piVar11;
      }
      piVar7 = piVar6;
      if (0xf < *(uint *)(iVar2 + 0x94)) {
        piVar7 = (int *)*piVar6;
      }
      cVar1 = FUN_0055c360(piVar7,*(undefined4 *)(iVar2 + 0x90),piVar9,
                           *(undefined4 *)(param_2 + 0x50));
      if ((cVar1 == '\0') && (FUN_0093c180(&iStack_18,iVar2 + 0x38,iVar2 + 0xb8), piVar6 != piVar11)
         ) {
        if (0xf < *(uint *)(param_2 + 0x54)) {
          piVar11 = (int *)*piVar11;
        }
        FUN_005542c0(piVar11,*(undefined4 *)(param_2 + 0x50));
      }
    }
    else {
      iVar3 = iVar2 + 0x68;
      if (0xf < *(uint *)(iVar2 + 0x7c)) {
        iVar3 = *(int *)(iVar2 + 0x68);
      }
      uVar4 = FUN_01675640(auStack_38,"DynamicVariableReloadError-%s",iVar3);
      uStack_8._0_1_ = 4;
      FUN_008783f0(uVar4,1,0);
      uStack_8._0_1_ = 2;
      FUN_005507b0();
      if (DAT_01ee29a4 != 0) {
        FUN_0151f6f0(0xffffffff,0,0);
        uStack_8._0_1_ = 5;
        FUN_0151f950("ApplicationName",iVar2 + 0x68);
        FUN_0151fcf0("TransportFailure",uStack_20._4_4_);
        FUN_0151fcf0("StatusFailure",uStack_3c);
        if (param_1 == 0) {
          if (cVar1 == '\0') {
            FUN_0054ef60(iStack_18 + 0x10);
            puVar8 = auStack_38;
            uVar10 = 0x14;
          }
          else {
            puVar8 = (undefined *)FUN_0054ef60(param_2 + 0x10);
            uVar10 = 2;
          }
          uVar4 = FUN_0054ef20(puVar8);
          uStack_8 = 9;
          uVar10 = uVar10 | 8;
        }
        else {
          uVar4 = FUN_0054ef60(param_2 + 0x74);
          uStack_8 = CONCAT31(uStack_8._1_3_,6);
          uVar10 = 1;
        }
        uStack_40 = uVar10;
        FUN_0151f950("Error",uVar4);
        if ((uVar10 & 8) != 0) {
          uVar10 = uVar10 & 0xfffffff7;
          FUN_005507b0();
        }
        if ((uVar10 & 4) != 0) {
          uVar10 = uVar10 & 0xfffffffb;
          FUN_005507b0();
        }
        if ((uVar10 & 2) != 0) {
          uVar10 = uVar10 & 0xfffffffd;
          FUN_005507b0();
        }
        uStack_8 = 5;
        if ((uVar10 & 1) != 0) {
          FUN_005507b0();
        }
        piVar6 = (int *)(param_2 + 0x40);
        uStack_28 = 0;
        uStack_24 = 0xf;
        auStack_38[0] = 0;
        uVar4 = 0x80;
        if (*(uint *)(param_2 + 0x50) < 0x80) {
          uVar4 = *(undefined4 *)(param_2 + 0x50);
        }
        if (0xf < *(uint *)(param_2 + 0x54)) {
          piVar6 = (int *)*piVar6;
        }
        FUN_005542c0(piVar6,uVar4);
        uStack_8._0_1_ = 10;
        FUN_0151f950(&DAT_018c3bf4,auStack_38);
        uStack_8._0_1_ = 5;
        FUN_005507b0();
        pdVar5 = (double *)FUN_016830f0(&uStack_20);
        FUN_0151fb00("LatencyMs",(*pdVar5 - *(double *)(iVar2 + 0x48)) * DAT_018c0d70);
        iVar3 = DAT_01ee29a4;
        uStack_28 = 0;
        uStack_24 = 0xf;
        auStack_38[0] = 0;
        FUN_005542c0("DynamicVariableReloadRequestErrorInfo",0x25);
        uStack_8._0_1_ = 0xb;
        FUN_01520d20(auStack_38,iVar3,0);
        FUN_005507b0();
        FUN_0151f7f0();
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    iVar2 = FUN_016deec8(iVar2);
    if (iVar2 != 0) {
      iVar2 = FUN_016df3c9(iVar2);
    }
    piVar6 = piStack_14;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar9 = piStack_14 + 1;
      iVar3 = *piVar9;
      iVar2 = *piVar9;
      *piVar9 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar2 = (**(code **)*piStack_14)();
        LOCK();
        piVar9 = piVar6 + 2;
        iVar3 = *piVar9;
        *piVar9 = *piVar9 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          iVar2 = (**(code **)(*piVar6 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar2;
}



/* FUNCTION 16890 ; VA 0x0093c740 ; FUN_0093c740 */

byte FUN_0093c740(void)

{
  char cVar1;
  undefined4 *puVar2;
  byte bVar3;
  byte bVar4;
  
  bVar4 = DAT_01d64374 != '\0';
  if (DAT_01d64350 != 0xc) {
    bVar4 = bVar4 | 2;
  }
  if (DAT_01d64358 != 0x22) {
    bVar4 = bVar4 | 4;
  }
  puVar2 = &DAT_01d6437c;
  if (0xf < DAT_01d64390) {
    puVar2 = DAT_01d6437c;
  }
  cVar1 = FUN_0055c360(puVar2,DAT_01d6438c,&DAT_0193320c,3);
  bVar3 = bVar4 | 8;
  if (cVar1 != '\0') {
    bVar3 = bVar4;
  }
  puVar2 = &DAT_01d64394;
  if (0xf < DAT_01d643a8) {
    puVar2 = DAT_01d64394;
  }
  cVar1 = FUN_0055c360(puVar2,DAT_01d643a4,&DAT_01933210,3);
  bVar4 = bVar3 | 0x10;
  if (cVar1 != '\0') {
    bVar4 = bVar3;
  }
  return bVar4;
}



/* FUNCTION 16891 ; VA 0x0093c7e0 ; FUN_0093c7e0 */

void FUN_0093c7e0(void)

{
  FUN_0093bbd0();
  return;
}



/* FUNCTION 16892 ; VA 0x0093c7f0 ; FUN_0093c7f0 */

int FUN_0093c7f0(void)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined auStack_18 [4];
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9f20;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0093cd70();
  *(undefined *)(iVar1 + 0xe8) = 1;
  uStack_8 = 0;
  iVar2 = FUN_016dee6d(iVar1);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  piVar6 = *(int **)(iVar1 + 0xe4);
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar6[1] = piVar6[1] + 1;
    UNLOCK();
    piVar6 = *(int **)(iVar1 + 0xe4);
  }
  iVar2 = *(int *)(iVar1 + 0xe0);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar1 = FUN_016deec8(iVar1);
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (iVar2 != 0) {
    FUN_014c9340();
  }
  FUN_0151f3f0();
  iVar1 = FUN_0168a370();
  if ((char)iVar1 != '\0') {
    piVar3 = (int *)FUN_01689dd0(auStack_14);
    piVar4 = (int *)FUN_01689df0(auStack_18);
    if (*piVar3 == *piVar4) {
      uVar5 = FUN_0056b4a0(0x24,"boost thread: trying joining itself");
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
      FUN_0054e630(uVar5);
    }
    iVar1 = FUN_0168a200();
  }
  if (piVar6 != (int *)0x0) {
    LOCK();
    piVar3 = piVar6 + 1;
    iVar2 = *piVar3;
    iVar1 = *piVar3;
    *piVar3 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar1 = (**(code **)*piVar6)();
      LOCK();
      piVar3 = piVar6 + 2;
      iVar2 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar1 = (**(code **)(*piVar6 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 16893 ; VA 0x0093c920 ; FUN_0093c920 */

void FUN_0093c920(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c000f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x40);
      uStack_8 = 0;
      if (iVar3 == 0) {
        *param_2 = 0;
        ExceptionList = pvStack_10;
        return;
      }
      iVar4 = FUN_0093ba60(iVar4);
      *param_2 = iVar4;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar4 = *param_2;
      if (iVar4 != 0) {
        piVar2 = *(int **)(iVar4 + 0x3c);
        ExceptionList = &pvStack_10;
        if (piVar2 != (int *)0x0) {
          ExceptionList = &pvStack_10;
          (**(code **)(*piVar2 + 0x10))(piVar2 != (int *)(iVar4 + 0x18));
          *(undefined4 *)(iVar4 + 0x3c) = 0;
        }
        piVar2 = *(int **)(iVar4 + 4);
        if (piVar2 != (int *)0x0) {
          LOCK();
          iVar3 = piVar2[1] + -1;
          piVar2[1] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)*piVar2)();
            LOCK();
            piVar1 = piVar2 + 2;
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
              (**(code **)(*piVar2 + 4))();
            }
          }
        }
        FUN_01674ea0(iVar4,0x40);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1db667c);
      if (iVar4 != 0) {
        *param_2 = 0;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = *param_1;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_6e55951cc367e68f43ec945b23dc4b39>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 16894 ; VA 0x0093cab0 ; FUN_0093cab0 */

void FUN_0093cab0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9f47;
  pvStack_10 = ExceptionList;
  if (param_3 == 4) {
    *param_2 = (int)&<lambda_7ae155e2e42e5d30ce3fa70d7bceb3a7>::RTTI_Type_Descriptor;
    *(undefined2 *)(param_2 + 1) = 0;
    return;
  }
  if (param_3 == 0) {
    iVar5 = *param_1;
    ExceptionList = &pvStack_10;
    iVar3 = FUN_01674e20(0x28);
    if (iVar3 == 0) {
      iVar3 = 0;
    }
    else {
      *(undefined4 *)(iVar3 + 0x24) = 0;
      uStack_8 = 1;
      if (*(undefined4 **)(iVar5 + 0x24) != (undefined4 *)0x0) {
        uVar4 = (**(code **)**(undefined4 **)(iVar5 + 0x24))(iVar3);
        *(undefined4 *)(iVar3 + 0x24) = uVar4;
      }
    }
    *param_2 = iVar3;
    ExceptionList = pvStack_10;
    return;
  }
  if (param_3 == 1) {
    *param_2 = *param_1;
    *param_1 = 0;
    return;
  }
  if (param_3 == 2) {
    piVar1 = (int *)*param_2;
    if (piVar1 != (int *)0x0) {
      piVar2 = (int *)piVar1[9];
      ExceptionList = &pvStack_10;
      if (piVar2 != (int *)0x0) {
        ExceptionList = &pvStack_10;
        (**(code **)(*piVar2 + 0x10))(piVar2 != piVar1);
        piVar1[9] = 0;
      }
      FUN_01674ea0(piVar1,0x28);
    }
    *param_2 = 0;
    ExceptionList = pvStack_10;
    return;
  }
  if (param_3 != 3) {
    *param_2 = (int)&<lambda_7ae155e2e42e5d30ce3fa70d7bceb3a7>::RTTI_Type_Descriptor;
    *(undefined2 *)(param_2 + 1) = 0;
    return;
  }
  ExceptionList = &pvStack_10;
  iVar5 = FUN_0170d8dd(*param_2 + 4,0x1db66b4);
  if (iVar5 == 0) {
    *param_2 = *param_1;
    ExceptionList = pvStack_10;
    return;
  }
  *param_2 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16895 ; VA 0x0093cc30 ; FUN_0093cc30 */

void FUN_0093cc30(undefined4 param_1)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a9e8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0093cd70();
  uVar3 = uVar1;
  iVar2 = FUN_016dee6d(uVar1);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  uVar4 = 1;
  uStack_8 = 0;
  FUN_0072a2b0(param_1);
  uStack_8 = 1;
  iVar2 = FUN_016deec8(uVar1);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2,uVar3,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16896 ; VA 0x0093ccc0 ; FUN_0093ccc0 */

void FUN_0093ccc0(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_0076d640(param_1);
  if (iVar1 == 0) {
    FUN_01678000(param_1);
  }
  return;
}



/* FUNCTION 16897 ; VA 0x0093cce0 ; FUN_0093cce0 */

void __fastcall FUN_0093cce0(int param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0093cce8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(param_1 + 0x3c))();
  return;
}



/* FUNCTION 16898 ; VA 0x0093ccf0 ; FUN_0093ccf0 */

void FUN_0093ccf0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_0093cd70();
  iVar2 = FUN_016dee6d(iVar1);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  *(undefined4 *)(iVar1 + 0x38) = param_1;
  *(undefined4 *)(iVar1 + 0x3c) = param_2;
  *(undefined4 *)(iVar1 + 0x40) = param_3;
  uStack_8 = 0;
  iVar1 = FUN_016deec8(iVar1);
  if (iVar1 != 0) {
    FUN_016df3c9(iVar1);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16899 ; VA 0x0093cd70 ; FUN_0093cd70 */

int __fastcall FUN_0093cd70(undefined4 param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9f91;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee29f0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee29f0,param_1);
    if (DAT_01ee29f0 == -1) {
      uStack_8 = 0;
      iVar1 = FUN_01674e20(0xf0);
      uStack_8._0_1_ = 1;
      if (iVar1 == 0) {
        iVar1 = 0;
      }
      else {
        FUN_016dee4c(iVar1,2);
        uStack_8._0_1_ = 2;
        FUN_00610ca0();
        uStack_8._0_1_ = 3;
        FUN_0151f360(1);
        *(undefined4 *)(iVar1 + 0x38) = 0xffffffff;
        *(undefined4 *)(iVar1 + 0x3c) = 0xffffffff;
        *(undefined4 *)(iVar1 + 0x40) = 0xffffffff;
        *(undefined8 *)(iVar1 + 0x48) = 0;
        *(undefined4 *)(iVar1 + 0x60) = 0;
        *(undefined4 *)(iVar1 + 100) = 0xf;
        *(undefined *)(iVar1 + 0x50) = 0;
        *(undefined4 *)(iVar1 + 0x78) = 0;
        *(undefined4 *)(iVar1 + 0x7c) = 0xf;
        *(undefined *)(iVar1 + 0x68) = 0;
        *(undefined4 *)(iVar1 + 0x90) = 0;
        *(undefined4 *)(iVar1 + 0x94) = 0xf;
        *(undefined *)(iVar1 + 0x80) = 0;
        *(undefined4 *)(iVar1 + 0x98) = 0;
        *(undefined4 *)(iVar1 + 0xac) = 0;
        *(undefined4 *)(iVar1 + 0xb0) = 7;
        *(undefined2 *)(iVar1 + 0x9c) = 0;
        *(undefined4 *)(iVar1 + 0xdc) = 0;
        *(undefined4 *)(iVar1 + 0xe0) = 0;
        *(undefined4 *)(iVar1 + 0xe4) = 0;
        *(undefined *)(iVar1 + 0xe8) = 0;
      }
      DAT_01ee29ec = iVar1;
      FUN_016f37bf(&DAT_01ee29f0);
    }
  }
  ExceptionList = pvStack_10;
  return DAT_01ee29ec;
}



/* FUNCTION 16900 ; VA 0x0093cee0 ; FUN_0093cee0 */

void FUN_0093cee0(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined auStack_20 [8];
  int iStack_18;
  undefined uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9fa8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0093cd70();
  iStack_18 = iVar2;
  iVar3 = FUN_016dee6d(iVar2);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  uStack_14 = 1;
  uStack_8 = 0;
  puVar4 = (undefined4 *)FUN_016830f0(auStack_20);
  *(undefined4 *)(iVar2 + 0x48) = *puVar4;
  *(undefined4 *)(iVar2 + 0x4c) = puVar4[1];
  if ((undefined4 *)(iVar2 + 0x68) != param_2) {
    puVar4 = param_2;
    if (0xf < (uint)param_2[5]) {
      puVar4 = (undefined4 *)*param_2;
    }
    FUN_005542c0(puVar4,param_2[4]);
  }
  if ((undefined4 *)(iVar2 + 0x80) != param_3) {
    puVar4 = param_3 + 4;
    if (0xf < (uint)param_3[5]) {
      param_3 = (undefined4 *)*param_3;
    }
    FUN_005542c0(param_3,*puVar4);
  }
  if ((undefined4 *)(iVar2 + 0x9c) != param_1) {
    puVar4 = param_1 + 4;
    if (7 < (uint)param_1[5]) {
      param_1 = (undefined4 *)*param_1;
    }
    FUN_0058ed10(param_1,*puVar4);
  }
  *(undefined4 *)(iVar2 + 0x98) = 1;
  if ((undefined4 *)(iVar2 + 0x50) != param_4) {
    puVar4 = param_4 + 4;
    if (0xf < (uint)param_4[5]) {
      param_4 = (undefined4 *)*param_4;
    }
    FUN_005542c0(param_4,*puVar4);
  }
  cVar1 = FUN_0168a370();
  if (cVar1 == '\0') {
    uVar5 = FUN_0093b180(FUN_0093d1a0,iVar2,0);
    FUN_005e0cb0(uVar5);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_016899e0();
    if (param_2 != (undefined4 *)0x0) {
      LOCK();
      iVar3 = param_2[1] + -1;
      param_2[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_2)(0);
        uVar5 = GetProcessHeap(0,param_2);
        HeapFree(uVar5);
      }
    }
  }
  uStack_8 = 2;
  iVar2 = FUN_016deec8(iVar2);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16901 ; VA 0x0093d050 ; FUN_0093d050 */

void FUN_0093d050(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined auStack_20 [8];
  int iStack_18;
  undefined uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c9fa8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0093cd70();
  iStack_18 = iVar2;
  iVar3 = FUN_016dee6d(iVar2);
  if (iVar3 != 0) {
    FUN_016df3c9(iVar3);
  }
  uStack_14 = 1;
  uStack_8 = 0;
  puVar4 = (undefined4 *)FUN_016830f0(auStack_20);
  *(undefined4 *)(iVar2 + 0x48) = *puVar4;
  *(undefined4 *)(iVar2 + 0x4c) = puVar4[1];
  if ((undefined4 *)(iVar2 + 0x50) != param_1) {
    puVar4 = param_1;
    if (0xf < (uint)param_1[5]) {
      puVar4 = (undefined4 *)*param_1;
    }
    FUN_005542c0(puVar4,param_1[4]);
  }
  if ((undefined4 *)(iVar2 + 0x68) != param_2) {
    puVar4 = param_2 + 4;
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    FUN_005542c0(param_2,*puVar4);
  }
  if ((undefined4 *)(iVar2 + 0x80) != param_3) {
    puVar4 = param_3 + 4;
    if (0xf < (uint)param_3[5]) {
      param_3 = (undefined4 *)*param_3;
    }
    FUN_005542c0(param_3,*puVar4);
  }
  *(undefined4 *)(iVar2 + 0x98) = 0;
  cVar1 = FUN_0168a370();
  if (cVar1 == '\0') {
    uVar5 = FUN_0093b180(FUN_0093d1a0,iVar2,0);
    FUN_005e0cb0(uVar5);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_016899e0();
    if (param_1 != (undefined4 *)0x0) {
      LOCK();
      iVar3 = param_1[1] + -1;
      param_1[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*param_1)(0);
        uVar5 = GetProcessHeap(0,param_1);
        HeapFree(uVar5);
      }
    }
  }
  uStack_8 = 2;
  iVar2 = FUN_016deec8(iVar2);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16902 ; VA 0x0093d1a0 ; FUN_0093d1a0 */

void __fastcall FUN_0093d1a0(int param_1)

{
  undefined4 *****pppppuVar1;
  int *piVar2;
  undefined uVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *****pppppuVar7;
  uint *puVar8;
  int iVar9;
  undefined4 *puVar10;
  int *****pppppiVar11;
  int *****pppppiVar12;
  int *piVar13;
  undefined *puVar14;
  int *****pppppiVar15;
  uint uVar16;
  undefined ***pppuVar17;
  uint uVar18;
  undefined auStack_b8 [8];
  int iStack_b0;
  undefined uStack_ac;
  int iStack_a8;
  undefined uStack_a4;
  undefined4 ****appppuStack_9c [4];
  undefined4 uStack_8c;
  uint uStack_88;
  uint auStack_84 [4];
  undefined4 uStack_74;
  uint uStack_70;
  int iStack_6c;
  undefined **ppuStack_68;
  code *pcStack_64;
  uint auStack_58 [4];
  undefined4 uStack_48;
  undefined ***pppuStack_44;
  int ****appppiStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  int iStack_28;
  int *piStack_24;
  int iStack_20;
  int iStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca053;
  pvStack_10 = ExceptionList;
  uStack_8c = 0;
  uStack_88 = 0xf;
  appppuStack_9c[0] = (undefined4 ****)((uint)appppuStack_9c[0] & 0xffffff00);
  uStack_74 = 0;
  uStack_70 = 7;
  auStack_84[0] = auStack_84[0] & 0xffff0000;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  iStack_28 = param_1;
  iVar5 = FUN_016dee6d(param_1);
  if (iVar5 != 0) {
    FUN_016df3c9(iVar5);
  }
  piStack_24 = (int *)CONCAT31(piStack_24._1_3_,1);
  uStack_8._0_1_ = 2;
  uVar6 = FUN_0151b520();
  pppppuVar7 = (undefined4 *****)FUN_00891110(auStack_58,param_1 + 0x50,uVar6);
  uStack_8._0_1_ = 3;
  if (appppuStack_9c != pppppuVar7) {
    pppppuVar1 = pppppuVar7 + 4;
    if ((undefined4 ****)0xf < pppppuVar7[5]) {
      pppppuVar7 = (undefined4 *****)*pppppuVar7;
    }
    FUN_005542c0(pppppuVar7,*pppppuVar1);
  }
  uStack_8._0_1_ = 2;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (&DAT_0000000f < pppuStack_44) {
    pppuVar17 = (undefined ***)((int)pppuStack_44 + 1);
    uVar18 = auStack_58[0];
    if ((undefined ***)0xfff < pppuVar17) {
      uVar18 = *(uint *)(auStack_58[0] - 4);
      pppuVar17 = pppuStack_44 + 9;
      if (0x1f < (auStack_58[0] - uVar18) - 4) {
LAB_0093d975:
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar18,pppuVar17);
  }
  iVar5 = *(int *)(param_1 + 0x98);
  puVar8 = (uint *)(param_1 + 0x9c);
  iStack_20 = iVar5;
  if (auStack_84 != puVar8) {
    if (7 < *(uint *)(param_1 + 0xb0)) {
      puVar8 = (uint *)*puVar8;
    }
    FUN_0058ed10(puVar8,*(undefined4 *)(param_1 + 0xac));
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  iVar9 = FUN_016deec8(param_1);
  if (iVar9 != 0) {
    FUN_016df3c9(iVar9);
  }
  uStack_8._0_1_ = 1;
  cVar4 = FUN_0151f440(DAT_01d6432c * 1000);
  do {
    if (cVar4 != '\0') {
      if (7 < uStack_70) {
        uVar18 = uStack_70 * 2 + 2;
        uVar16 = auStack_84[0];
        if (0xfff < uVar18) {
          uVar16 = *(uint *)(auStack_84[0] - 4);
          uVar18 = uStack_70 * 2 + 0x25;
          if (0x1f < (auStack_84[0] - uVar16) - 4) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(uVar16,uVar18);
      }
      uStack_74 = 0;
      uStack_70 = 7;
      auStack_84[0] = auStack_84[0] & 0xffff0000;
      if (0xf < uStack_88) {
        uVar18 = uStack_88 + 1;
        pppppuVar7 = (undefined4 *****)appppuStack_9c[0];
        if (0xfff < uVar18) {
          pppppuVar7 = (undefined4 *****)appppuStack_9c[0][-1];
          uVar18 = uStack_88 + 0x24;
          if (0x1f < (uint)((int)appppuStack_9c[0] + (-4 - (int)pppppuVar7))) {
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(pppppuVar7,uVar18);
      }
      ExceptionList = pvStack_10;
      return;
    }
    iStack_a8 = param_1;
    iVar9 = FUN_016dee6d(param_1);
    if (iVar9 != 0) {
      FUN_016df3c9(iVar9);
    }
    uStack_a4 = 1;
    uStack_8._0_1_ = 5;
    if (DAT_01d80e6c == '\0') {
      puVar14 = (undefined *)(param_1 + 0x80);
      if (0xf < *(uint *)(param_1 + 0x94)) {
        puVar14 = *(undefined **)(param_1 + 0x80);
      }
      *(undefined4 *)(param_1 + 0x90) = 0;
      *puVar14 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      iVar9 = FUN_016deec8(param_1);
      if (iVar9 != 0) {
        FUN_016df3c9(iVar9);
      }
      uStack_8._0_1_ = 1;
      uVar3 = (undefined)uStack_8;
    }
    else {
      puVar10 = (undefined4 *)FUN_016830f0(auStack_b8);
      *(undefined4 *)(param_1 + 0x48) = *puVar10;
      *(undefined4 *)(param_1 + 0x4c) = puVar10[1];
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      iVar9 = FUN_016deec8(param_1);
      if (iVar9 != 0) {
        FUN_016df3c9(iVar9);
      }
      uStack_8._0_1_ = 1;
      if (iVar5 == 1) {
        iVar9 = FUN_0093cd70();
        iVar5 = iStack_20;
        uVar3 = (undefined)uStack_8;
        if (*(char *)(iVar9 + 0xe8) == '\0') {
          uStack_30 = 0;
          uStack_2c = 0xf;
          appppiStack_40[0] = (int ****)((uint)appppiStack_40[0] & 0xffffff00);
          uStack_8._0_1_ = 8;
          cStack_11 = FUN_00937970(auStack_84,appppiStack_40);
          iStack_6c = FUN_01674e20(0x34);
          uStack_8._0_1_ = 9;
          if (iStack_6c == 0) {
            uVar6 = 0;
          }
          else {
            FUN_0170d1f0(iStack_6c,0,0x34);
            uVar6 = FUN_0093baf0();
          }
          uStack_8._0_1_ = 8;
          iStack_28 = 0;
          piStack_24 = (int *)0x0;
          FUN_0093b3e0(uVar6,iStack_6c);
          iVar5 = iStack_28;
          uStack_8 = CONCAT31(uStack_8._1_3_,10);
          if (cStack_11 != '\0') {
            FUN_01684540(appppiStack_40);
            cStack_11 = *(char *)(iVar5 + 0xc) == '\0';
          }
          iStack_b0 = iVar9;
          iVar5 = FUN_016dee6d(iVar9);
          if (iVar5 != 0) {
            FUN_016df3c9(iVar5);
          }
          uStack_ac = 1;
          piVar13 = (int *)(iVar9 + 0x68);
          uStack_8._0_1_ = 0xb;
          if (cStack_11 == '\0') {
            if (0xf < *(uint *)(iVar9 + 0x7c)) {
              piVar13 = (int *)*piVar13;
            }
            uVar6 = FUN_01675640(auStack_58,"DynamicVariableFileReloadFailure-%s",piVar13);
            uStack_8._0_1_ = 0xd;
            FUN_008783f0(uVar6,1,0);
            uStack_8._0_1_ = 0xb;
            if (&DAT_0000000f < pppuStack_44) {
              pppuVar17 = (undefined ***)((int)pppuStack_44 + 1);
              uVar18 = auStack_58[0];
              if ((undefined ***)0xfff < pppuVar17) {
                uVar18 = *(uint *)(auStack_58[0] - 4);
                pppuVar17 = pppuStack_44 + 9;
                uVar3 = (undefined)uStack_8;
                if (0x1f < (auStack_58[0] - uVar18) - 4) goto LAB_0093d975;
              }
              FUN_01674ea0(uVar18,pppuVar17);
            }
            if (DAT_01ee29a8 != 0) {
              FUN_0151f6f0(0xffffffff,0,0);
              uStack_8._0_1_ = 0xe;
              uVar6 = FUN_005569d0(auStack_58);
              uStack_8._0_1_ = 0xf;
              FUN_0151f950("FilePath",uVar6);
              uStack_8._0_1_ = 0xe;
              FUN_005507b0();
              FUN_0151f9c0("Datacenter",DAT_01d7a884);
              iVar5 = DAT_01ee29a8;
              uStack_48 = 0;
              pppuStack_44 = (undefined ***)&DAT_0000000f;
              auStack_58[0] = auStack_58[0] & 0xffffff00;
              FUN_005542c0("DynamicVariableFileReloadRequestErrorInfo",0x29);
              uStack_8._0_1_ = 0x10;
              FUN_01520d20(auStack_58,iVar5,0);
              FUN_005507b0();
              FUN_0151f7f0();
            }
          }
          else {
            if (0xf < *(uint *)(iVar9 + 0x7c)) {
              piVar13 = (int *)*piVar13;
            }
            uVar6 = FUN_01675640(auStack_58,"DynamicVariableFileReloadSuccess-%s",piVar13);
            uStack_8._0_1_ = 0xc;
            FUN_008783f0(uVar6,1,0);
            uStack_8._0_1_ = 0xb;
            if (&DAT_0000000f < pppuStack_44) {
              pppuVar17 = (undefined ***)((int)pppuStack_44 + 1);
              uVar18 = auStack_58[0];
              if ((undefined ***)0xfff < pppuVar17) {
                uVar18 = *(uint *)(auStack_58[0] - 4);
                pppuVar17 = pppuStack_44 + 9;
                uVar3 = (undefined)uStack_8;
                if (0x1f < (auStack_58[0] - uVar18) - 4) goto LAB_0093d975;
              }
              FUN_01674ea0(uVar18,pppuVar17);
            }
            pppppiVar12 = (int *****)(iVar9 + 0x80);
            pppppiVar11 = appppiStack_40;
            if (0xf < uStack_2c) {
              pppppiVar11 = (int *****)appppiStack_40[0];
            }
            pppppiVar15 = pppppiVar12;
            if (0xf < *(uint *)(iVar9 + 0x94)) {
              pppppiVar15 = (int *****)*pppppiVar12;
            }
            cVar4 = FUN_0055c360(pppppiVar15,*(undefined4 *)(iVar9 + 0x90),pppppiVar11,uStack_30);
            if (cVar4 == '\0') {
              FUN_0093c180(&iStack_28,iVar9 + 0x38,iVar9 + 0xb8);
              if (pppppiVar12 != appppiStack_40) {
                pppppiVar12 = appppiStack_40;
                if (0xf < uStack_2c) {
                  pppppiVar12 = (int *****)appppiStack_40[0];
                }
                FUN_005542c0(pppppiVar12,uStack_30);
              }
            }
          }
          uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
          iVar5 = FUN_016deec8(iVar9);
          if (iVar5 != 0) {
            FUN_016df3c9(iVar5);
          }
          piVar13 = piStack_24;
          if (piStack_24 != (int *)0x0) {
            LOCK();
            iVar5 = piStack_24[1] + -1;
            piStack_24[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*piStack_24)();
              LOCK();
              piVar2 = piVar13 + 2;
              iVar5 = *piVar2 + -1;
              *piVar2 = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)(*piVar13 + 4))();
              }
            }
          }
          uStack_8._0_1_ = 1;
          iVar5 = iStack_20;
          uVar3 = (undefined)uStack_8;
          if (0xf < uStack_2c) {
            uVar18 = uStack_2c + 1;
            pppppiVar12 = (int *****)appppiStack_40[0];
            if (0xfff < uVar18) {
              pppppiVar12 = (int *****)appppiStack_40[0][-1];
              uVar18 = uStack_2c + 0x24;
              if (0x1f < (uint)((int)appppiStack_40[0] + (-4 - (int)pppppiVar12)))
              goto LAB_0093d975;
            }
            FUN_01674ea0(pppppiVar12,uVar18);
            iVar5 = iStack_20;
            uVar3 = (undefined)uStack_8;
          }
        }
      }
      else {
        FUN_014c9d60(&iStack_1c,0);
        pppppuVar7 = appppuStack_9c;
        if (0xf < uStack_88) {
          pppppuVar7 = (undefined4 *****)appppuStack_9c[0];
        }
        uStack_8._0_1_ = 0x12;
        FUN_014cbbc0(pppppuVar7,uStack_8c);
        *(undefined4 *)(iStack_1c + 0xb0) = 0;
        FUN_014cba40();
        pppuStack_44 = &ppuStack_68;
        ppuStack_68 = std::
                      _Func_impl_no_alloc<void_(__cdecl*)(enum_RBX::HttpErrorCode,class_RBX::HttpResponse&),void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
                      ::vftable;
        pcStack_64 = FUN_0093c2f0;
        uStack_8._0_1_ = 0x13;
        FUN_014cb530(pppuStack_44);
        uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
        if (pppuStack_44 != (undefined ***)0x0) {
          (*(code *)(*pppuStack_44)[4])
                    (CONCAT31((int3)((uint)&ppuStack_68 >> 8),pppuStack_44 != &ppuStack_68));
        }
        iVar9 = FUN_016dee6d(param_1);
        if (iVar9 != 0) {
          FUN_016df3c9(iVar9);
        }
        if (piStack_18 != (int *)0x0) {
          LOCK();
          piStack_18[1] = piStack_18[1] + 1;
          UNLOCK();
        }
        *(int *)(param_1 + 0xe0) = iStack_1c;
        piVar13 = *(int **)(param_1 + 0xe4);
        *(int **)(param_1 + 0xe4) = piStack_18;
        if (piVar13 != (int *)0x0) {
          LOCK();
          iVar9 = piVar13[1] + -1;
          piVar13[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piVar13)();
            LOCK();
            iVar9 = piVar13[2] + -1;
            piVar13[2] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piVar13 + 4))();
            }
          }
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
        iVar9 = FUN_016deec8(param_1);
        if (iVar9 != 0) {
          FUN_016df3c9(iVar9);
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
        cVar4 = FUN_014cbca0(DAT_01d6433c);
        if (cVar4 == '\0') {
          FUN_014c9340();
        }
        iVar9 = FUN_016dee6d(param_1);
        if (iVar9 != 0) {
          FUN_016df3c9(iVar9);
        }
        *(undefined4 *)(param_1 + 0xe0) = 0;
        piVar13 = *(int **)(param_1 + 0xe4);
        *(undefined4 *)(param_1 + 0xe4) = 0;
        if (piVar13 != (int *)0x0) {
          LOCK();
          iVar9 = piVar13[1] + -1;
          piVar13[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piVar13)();
            LOCK();
            iVar9 = piVar13[2] + -1;
            piVar13[2] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piVar13 + 4))();
            }
          }
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
        iVar9 = FUN_016deec8(param_1);
        if (iVar9 != 0) {
          FUN_016df3c9(iVar9);
        }
        piVar13 = piStack_18;
        uStack_8._0_1_ = 1;
        uVar3 = (undefined)uStack_8;
        uStack_8._0_1_ = 1;
        if (piStack_18 != (int *)0x0) {
          LOCK();
          iVar9 = piStack_18[1] + -1;
          piStack_18[1] = iVar9;
          UNLOCK();
          uVar3 = (undefined)uStack_8;
          if (iVar9 == 0) {
            (**(code **)*piStack_18)();
            LOCK();
            piVar2 = piVar13 + 2;
            iVar9 = *piVar2 + -1;
            *piVar2 = iVar9;
            UNLOCK();
            uVar3 = (undefined)uStack_8;
            if (iVar9 == 0) {
              (**(code **)(*piVar13 + 4))();
              uVar3 = (undefined)uStack_8;
            }
          }
        }
      }
    }
    uStack_8._0_1_ = uVar3;
    cVar4 = FUN_0151f440(DAT_01d6432c * 1000);
  } while( true );
}



/* FUNCTION 16903 ; VA 0x0093d990 ; FUN_0093d990 */

void FUN_0093d990(undefined4 param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4,
                 undefined4 *param_5)

{
  void **ppvVar1;
  char cVar2;
  uint *puVar3;
  int iVar4;
  uint uVar5;
  uint *puVar6;
  uint *puVar7;
  uint uVar8;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint *puStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint *puStack_24;
  uint uStack_20;
  uint *puStack_1c;
  uint *puStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ca070;
  pvStack_10 = ExceptionList;
  if (param_5 != (undefined4 *)0x0) {
    ExceptionList = &pvStack_10;
    if (-1 < (int)param_5[2]) {
      puVar7 = (uint *)param_4[1];
      puVar6 = (uint *)*param_4;
      ExceptionList = &pvStack_10;
      ppvVar1 = &pvStack_10;
      puStack_1c = puVar7;
      if (puVar6 != puVar7) {
        do {
          ExceptionList = ppvVar1;
          puStack_18 = (uint *)puVar6[4];
          puStack_24 = (uint *)0x0;
          uStack_20 = 0;
          puStack_14 = puVar6;
          if (0xf < puVar6[5]) {
            puStack_14 = (uint *)*puVar6;
          }
          if (&DAT_0000000f < puStack_18) {
            uVar8 = (uint)puStack_18 | 0xf;
            if (0x7fffffff < uVar8) {
              uVar8 = 0x7fffffff;
            }
            uStack_34 = FUN_00554060(uVar8 + 1);
            FUN_0170c6f0(uStack_34,puStack_14,(undefined *)((int)puStack_18 + 1));
            puVar7 = puStack_1c;
            uStack_20 = uVar8;
          }
          else {
            uStack_34 = *puStack_14;
            uStack_30 = puStack_14[1];
            uStack_2c = puStack_14[2];
            uStack_28 = puStack_14[3];
            uStack_20 = 0xf;
          }
          uStack_8 = 0;
          puStack_24 = puStack_18;
          cVar2 = FUN_01677b00(param_1,&uStack_34,param_5[2],(int)param_5[2] >> 0x1f);
          if (cVar2 != '\0') {
            if (uStack_20 < 0x10) {
              ExceptionList = pvStack_10;
              return;
            }
            puVar7 = (uint *)(uStack_20 + 1);
            uVar8 = uStack_34;
            if (puVar7 < &DAT_00001000) goto LAB_0093dc60;
            uVar8 = *(uint *)(uStack_34 - 4);
            puVar7 = (uint *)(uStack_20 + 0x24);
            if ((uStack_34 - uVar8) - 4 < 0x20) goto LAB_0093dc60;
            goto LAB_0093dc7a;
          }
          uStack_8 = 0xffffffff;
          if (0xf < uStack_20) {
            uVar5 = uStack_20 + 1;
            uVar8 = uStack_34;
            if (0xfff < uVar5) {
              uVar8 = *(uint *)(uStack_34 - 4);
              uVar5 = uStack_20 + 0x24;
              if (0x1f < (uStack_34 - uVar8) - 4) goto LAB_0093dc7a;
            }
            FUN_01674ea0(uVar8,uVar5);
          }
          puVar6 = puVar6 + 6;
          ppvVar1 = (void **)ExceptionList;
        } while (puVar6 != puVar7);
      }
    }
    if (-1 < (int)param_5[1]) {
      puVar7 = (uint *)*param_3;
      puStack_14 = (uint *)param_3[1];
      if (puVar7 != puStack_14) {
        do {
          uVar8 = puVar7[4];
          uStack_3c = 0;
          puStack_38 = (uint *)0x0;
          puStack_18 = puVar7;
          if (0xf < puVar7[5]) {
            puStack_18 = (uint *)*puVar7;
          }
          if (uVar8 < 0x10) {
            uStack_4c = *puStack_18;
            uStack_48 = puStack_18[1];
            uStack_44 = puStack_18[2];
            uStack_40 = puStack_18[3];
            puStack_38 = (uint *)&DAT_0000000f;
          }
          else {
            puStack_1c = (uint *)(uVar8 | 0xf);
            if ((uint *)0x7fffffff < puStack_1c) {
              puStack_1c = (uint *)0x7fffffff;
            }
            puVar6 = (uint *)((int)puStack_1c + 1);
            if (puVar6 < &DAT_00001000) {
              if (puVar6 == (uint *)0x0) {
                uStack_4c = 0;
              }
              else {
                uStack_4c = FUN_01674e20(puVar6);
              }
            }
            else {
              puVar3 = puStack_1c + 9;
              if (puVar3 <= puVar6) {
                puVar3 = (uint *)0xffffffff;
              }
              iVar4 = FUN_01674e20(puVar3);
              if (iVar4 == 0) {
LAB_0093dc7a:
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
              uStack_4c = iVar4 + 0x23U & 0xffffffe0;
              *(int *)(uStack_4c - 4) = iVar4;
            }
            FUN_0170c6f0(uStack_4c,puStack_18,uVar8 + 1);
            puStack_38 = puStack_1c;
          }
          uStack_8 = 1;
          uStack_3c = uVar8;
          cVar2 = FUN_01677b00(param_1,&uStack_4c,*param_5,param_5[1]);
          if (cVar2 != '\0') {
            if (puStack_38 <= &DAT_0000000f) {
              ExceptionList = pvStack_10;
              return;
            }
            puVar7 = (uint *)((int)puStack_38 + 1);
            uVar8 = uStack_4c;
            if ((uint *)0xfff < puVar7) {
              uVar8 = *(uint *)(uStack_4c - 4);
              puVar7 = puStack_38 + 9;
              if (0x1f < (uStack_4c - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
                FUN_017167a3();
              }
            }
LAB_0093dc60:
            FUN_01674ea0(uVar8,puVar7);
            ExceptionList = pvStack_10;
            return;
          }
          uStack_8 = 0xffffffff;
          if (&DAT_0000000f < puStack_38) {
            puVar6 = (uint *)((int)puStack_38 + 1);
            uVar8 = uStack_4c;
            if ((uint *)0xfff < puVar6) {
              uVar8 = *(uint *)(uStack_4c - 4);
              puVar6 = puStack_38 + 9;
              if (0x1f < (uStack_4c - uVar8) - 4) goto LAB_0093dc7a;
            }
            FUN_01674ea0(uVar8,puVar6);
          }
          puVar7 = puVar7 + 6;
        } while (puVar7 != puStack_14);
      }
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16904 ; VA 0x0093dc90 ; FUN_0093dc90 */

undefined4 * __thiscall FUN_0093dc90(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca080;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  puVar1 = (undefined4 *)FUN_01674e20(0x14);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = boost::detail::
              sp_counted_impl_pd<struct_boost::thread_specific_ptr<int>::delete_data*,struct_boost::detail::do_heap_delete<struct_boost::thread_specific_ptr<int>::delete_data>_>
              ::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = puVar1;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16905 ; VA 0x0093dd03 ; Catch_All@0093dd03 */

void Catch_All_0093dd03(void)

{
  int unaff_EBP;
  
  FUN_008ec4d0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16906 ; VA 0x0093dd20 ; FUN_0093dd20 */

undefined4 * __thiscall FUN_0093dd20(undefined4 *param_1,undefined4 param_2)

{
  char cVar1;
  undefined **ppuVar2;
  uint in_stack_00000034;
  undefined4 auStack_110 [17];
  undefined4 uStack_cc;
  undefined *puStack_c8;
  undefined *puStack_c4;
  undefined4 *puStack_c0;
  undefined auStack_ac [40];
  uint uStack_84;
  undefined auStack_7c [24];
  undefined4 uStack_64;
  undefined auStack_5c [40];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca0ab;
  pvStack_10 = ExceptionList;
  puStack_c0 = (undefined4 *)&stack0x0000000c;
  uStack_8 = 0;
  puStack_c4 = (undefined *)0x93dd64;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00944b60();
  uStack_64 = param_2;
  puStack_c0 = (undefined4 *)auStack_ac;
  uStack_8._0_1_ = 1;
  *param_1 = 0;
  puStack_c4 = (undefined *)0x93dd86;
  FUN_00944b60();
  puStack_c0 = param_1 + 2;
  uStack_8._0_1_ = 2;
  puStack_14 = auStack_110;
  auStack_110[0] = uStack_64;
  FUN_00944b60(auStack_5c);
  ppuVar2 = &PTR_FUN_01934d90;
  cVar1 = FUN_00941650();
  if (cVar1 == '\0') {
    ppuVar2 = (undefined **)0x0;
  }
  *param_1 = ppuVar2;
  uStack_8._0_1_ = 3;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      puStack_c8 = auStack_2c;
      puStack_c0 = (undefined4 *)0x2;
      uStack_cc = 0x93dddd;
      puStack_c4 = puStack_c8;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  puStack_c0 = (undefined4 *)0x93ddef;
  FUN_00946a50();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_84 != 0) {
    if (((uStack_84 & 1) == 0) && (*(code **)(uStack_84 & 0xfffffffe) != (code *)0x0)) {
      puStack_c8 = auStack_7c;
      puStack_c0 = (undefined4 *)0x2;
      uStack_cc = 0x93de10;
      puStack_c4 = puStack_c8;
      (**(code **)(uStack_84 & 0xfffffffe))();
    }
    uStack_84 = 0;
  }
  puStack_c0 = (undefined4 *)0x93de25;
  FUN_00946a50();
  uStack_8 = 5;
  if (in_stack_00000034 != 0) {
    if (((in_stack_00000034 & 1) == 0) &&
       (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
      puStack_c8 = &stack0x0000003c;
      puStack_c0 = (undefined4 *)0x2;
      uStack_cc = 0x93de49;
      puStack_c4 = puStack_c8;
      (**(code **)(in_stack_00000034 & 0xfffffffe))();
    }
    in_stack_00000034 = 0;
  }
  puStack_c0 = (undefined4 *)0x93de5b;
  FUN_00946a50();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16907 ; VA 0x0093de70 ; FUN_0093de70 */

undefined4 * __thiscall
FUN_0093de70(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined **ppuVar3;
  undefined4 auStack_a0 [2];
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca0d8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_40 = param_2;
  uStack_38 = 0;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_74 = 0;
      puStack_78 = &uStack_30;
      uStack_80 = CONCAT44(&param_6,0x93dedd);
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = CONCAT44(param_11,param_10);
    }
  }
  uVar1 = uStack_40;
  uStack_8._0_1_ = 1;
  puVar2 = param_1 + 2;
  uStack_60 = 0;
  if (uStack_38 != 0) {
    uStack_60 = uStack_38;
    if ((uStack_38 & 1) == 0) {
      puStack_78 = &uStack_58;
      uStack_74 = 0;
      uStack_80 = CONCAT44(&uStack_30,0x93df29);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    else {
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
      uStack_48 = uStack_20;
    }
  }
  uStack_74 = param_11;
  uStack_8._0_1_ = 2;
  puStack_18 = (undefined *)auStack_a0;
  uStack_98 = 0;
  auStack_a0[0] = uVar1;
  puStack_78 = puVar2;
  puVar2 = auStack_a0;
  if (uStack_60 != 0) {
    uStack_98 = uStack_60;
    if ((uStack_60 & 1) == 0) {
      (**(code **)(uStack_60 & 0xfffffffe))(&uStack_58,&uStack_90,0);
      puVar2 = (undefined4 *)puStack_18;
    }
    else {
      uStack_90 = uStack_58;
      uStack_8c = uStack_54;
      uStack_88 = uStack_50;
      uStack_84 = uStack_4c;
      uStack_80 = uStack_48;
      puVar2 = auStack_a0;
    }
  }
  puStack_18 = (undefined *)puVar2;
  ppuVar3 = &PTR_FUN_01934d88;
  cStack_11 = FUN_009417e0();
  uStack_8._0_1_ = 3;
  if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
     (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_58;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x93dfb3);
    (**(code **)(uStack_60 & 0xfffffffe))();
  }
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_38 != 0) {
    if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_30;
      uStack_74 = 2;
      uStack_80 = CONCAT44(puStack_78,0x93dfee);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    uStack_38 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_6;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x93e01c);
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16908 ; VA 0x0093e040 ; FUN_0093e040 */

undefined4 * __thiscall
FUN_0093e040(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined **ppuVar3;
  undefined4 auStack_a0 [2];
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca108;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_40 = param_2;
  uStack_38 = 0;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_74 = 0;
      puStack_78 = &uStack_30;
      uStack_80 = CONCAT44(&param_6,0x93e0ad);
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = CONCAT44(param_11,param_10);
    }
  }
  uVar1 = uStack_40;
  uStack_8._0_1_ = 1;
  puVar2 = param_1 + 2;
  uStack_60 = 0;
  if (uStack_38 != 0) {
    uStack_60 = uStack_38;
    if ((uStack_38 & 1) == 0) {
      puStack_78 = &uStack_58;
      uStack_74 = 0;
      uStack_80 = CONCAT44(&uStack_30,0x93e0f9);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    else {
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
      uStack_48 = uStack_20;
    }
  }
  uStack_74 = param_11;
  uStack_8._0_1_ = 2;
  puStack_18 = (undefined *)auStack_a0;
  uStack_98 = 0;
  auStack_a0[0] = uVar1;
  puStack_78 = puVar2;
  puVar2 = auStack_a0;
  if (uStack_60 != 0) {
    uStack_98 = uStack_60;
    if ((uStack_60 & 1) == 0) {
      (**(code **)(uStack_60 & 0xfffffffe))(&uStack_58,&uStack_90,0);
      puVar2 = (undefined4 *)puStack_18;
    }
    else {
      uStack_90 = uStack_58;
      uStack_8c = uStack_54;
      uStack_88 = uStack_50;
      uStack_84 = uStack_4c;
      uStack_80 = uStack_48;
      puVar2 = auStack_a0;
    }
  }
  puStack_18 = (undefined *)puVar2;
  ppuVar3 = &PTR_FUN_01934d80;
  cStack_11 = FUN_00941940();
  uStack_8._0_1_ = 3;
  if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
     (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_58;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x93e183);
    (**(code **)(uStack_60 & 0xfffffffe))();
  }
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_38 != 0) {
    if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_30;
      uStack_74 = 2;
      uStack_80 = CONCAT44(puStack_78,0x93e1be);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    uStack_38 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_6;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x93e1ec);
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16909 ; VA 0x0093e210 ; FUN_0093e210 */

undefined4 * __thiscall
FUN_0093e210(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined **ppuVar3;
  undefined4 auStack_a0 [2];
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca138;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_40 = param_2;
  uStack_38 = 0;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_74 = 0;
      puStack_78 = &uStack_30;
      uStack_80 = CONCAT44(&param_6,0x93e27d);
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = CONCAT44(param_11,param_10);
    }
  }
  uVar1 = uStack_40;
  uStack_8._0_1_ = 1;
  puVar2 = param_1 + 2;
  uStack_60 = 0;
  if (uStack_38 != 0) {
    uStack_60 = uStack_38;
    if ((uStack_38 & 1) == 0) {
      puStack_78 = &uStack_58;
      uStack_74 = 0;
      uStack_80 = CONCAT44(&uStack_30,0x93e2c9);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    else {
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
      uStack_48 = uStack_20;
    }
  }
  uStack_74 = param_11;
  uStack_8._0_1_ = 2;
  puStack_18 = (undefined *)auStack_a0;
  uStack_98 = 0;
  auStack_a0[0] = uVar1;
  puStack_78 = puVar2;
  puVar2 = auStack_a0;
  if (uStack_60 != 0) {
    uStack_98 = uStack_60;
    if ((uStack_60 & 1) == 0) {
      (**(code **)(uStack_60 & 0xfffffffe))(&uStack_58,&uStack_90,0);
      puVar2 = (undefined4 *)puStack_18;
    }
    else {
      uStack_90 = uStack_58;
      uStack_8c = uStack_54;
      uStack_88 = uStack_50;
      uStack_84 = uStack_4c;
      uStack_80 = uStack_48;
      puVar2 = auStack_a0;
    }
  }
  puStack_18 = (undefined *)puVar2;
  ppuVar3 = &PTR_FUN_01934db8;
  cStack_11 = FUN_00941aa0();
  uStack_8._0_1_ = 3;
  if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
     (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_58;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x93e353);
    (**(code **)(uStack_60 & 0xfffffffe))();
  }
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_38 != 0) {
    if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_30;
      uStack_74 = 2;
      uStack_80 = CONCAT44(puStack_78,0x93e38e);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    uStack_38 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_6;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x93e3bc);
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16910 ; VA 0x0093e3e0 ; FUN_0093e3e0 */

undefined4 * __thiscall
FUN_0093e3e0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined **ppuVar3;
  undefined4 auStack_a0 [2];
  uint uStack_98;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 *puStack_78;
  undefined4 uStack_74;
  uint uStack_60;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  undefined4 uStack_40;
  uint uStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined8 uStack_20;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca168;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  uStack_40 = param_2;
  uStack_38 = 0;
  if (param_4 != 0) {
    uStack_38 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_74 = 0;
      puStack_78 = &uStack_30;
      uStack_80 = CONCAT44(&param_6,0x93e44d);
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_30 = param_6;
      uStack_2c = param_7;
      uStack_28 = param_8;
      uStack_24 = param_9;
      uStack_20 = CONCAT44(param_11,param_10);
    }
  }
  uVar1 = uStack_40;
  uStack_8._0_1_ = 1;
  puVar2 = param_1 + 2;
  uStack_60 = 0;
  if (uStack_38 != 0) {
    uStack_60 = uStack_38;
    if ((uStack_38 & 1) == 0) {
      puStack_78 = &uStack_58;
      uStack_74 = 0;
      uStack_80 = CONCAT44(&uStack_30,0x93e499);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    else {
      uStack_58 = uStack_30;
      uStack_54 = uStack_2c;
      uStack_50 = uStack_28;
      uStack_4c = uStack_24;
      uStack_48 = uStack_20;
    }
  }
  uStack_74 = param_11;
  uStack_8._0_1_ = 2;
  puStack_18 = (undefined *)auStack_a0;
  uStack_98 = 0;
  auStack_a0[0] = uVar1;
  puStack_78 = puVar2;
  puVar2 = auStack_a0;
  if (uStack_60 != 0) {
    uStack_98 = uStack_60;
    if ((uStack_60 & 1) == 0) {
      (**(code **)(uStack_60 & 0xfffffffe))(&uStack_58,&uStack_90,0);
      puVar2 = (undefined4 *)puStack_18;
    }
    else {
      uStack_90 = uStack_58;
      uStack_8c = uStack_54;
      uStack_88 = uStack_50;
      uStack_84 = uStack_4c;
      uStack_80 = uStack_48;
      puVar2 = auStack_a0;
    }
  }
  puStack_18 = (undefined *)puVar2;
  ppuVar3 = &PTR_FUN_01934db0;
  cStack_11 = FUN_00941c00();
  uStack_8._0_1_ = 3;
  if (((uStack_60 != 0) && ((uStack_60 & 1) == 0)) &&
     (*(code **)(uStack_60 & 0xfffffffe) != (code *)0x0)) {
    puStack_78 = &uStack_58;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x93e523);
    (**(code **)(uStack_60 & 0xfffffffe))();
  }
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  *param_1 = ppuVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_38 != 0) {
    if (((uStack_38 & 1) == 0) && (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
      puStack_78 = &uStack_30;
      uStack_74 = 2;
      uStack_80 = CONCAT44(puStack_78,0x93e55e);
      (**(code **)(uStack_38 & 0xfffffffe))();
    }
    uStack_38 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_78 = &param_6;
    uStack_74 = 2;
    uStack_80 = CONCAT44(puStack_78,0x93e58c);
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16911 ; VA 0x0093e5b0 ; FUN_0093e5b0 */

undefined4 * __thiscall
FUN_0093e5b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_01934da8;
  cVar3 = FUN_005918b0(param_2,param_3,param_4,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 16912 ; VA 0x0093e6a0 ; FUN_0093e6a0 */

undefined4 * __thiscall
FUN_0093e6a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_01934da0;
  cVar3 = FUN_00941d60(param_2,param_3,param_4,param_5,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 16913 ; VA 0x0093e7a0 ; FUN_0093e7a0 */

undefined4 __thiscall FUN_0093e7a0(undefined4 param_1,undefined4 param_2)

{
  bool bVar1;
  char cVar2;
  undefined auStack_14c [40];
  undefined4 uStack_124;
  undefined auStack_11c [40];
  undefined4 uStack_f4;
  undefined auStack_ec [40];
  undefined4 uStack_c4;
  undefined auStack_bc [40];
  undefined4 uStack_94;
  undefined auStack_8c [40];
  undefined4 auStack_64 [2];
  undefined auStack_5c [40];
  undefined **ppuStack_34;
  undefined4 *apuStack_2c [6];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca1de;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00944900(&stack0x0000000c);
  uStack_124 = param_2;
  uStack_8._0_1_ = 1;
  FUN_00944900(auStack_14c);
  uStack_f4 = uStack_124;
  uStack_8._0_1_ = 2;
  ppuStack_34 = (undefined **)0x0;
  FUN_00944900(auStack_11c);
  uStack_c4 = uStack_f4;
  uStack_8._0_1_ = 3;
  FUN_00944900(auStack_ec);
  auStack_64[0] = uStack_c4;
  uStack_8._0_1_ = 4;
  FUN_00944900(auStack_bc);
  uStack_8._0_1_ = 5;
  cVar2 = FUN_00585a40(auStack_64);
  if (cVar2 == '\0') {
    uStack_94 = auStack_64[0];
    FUN_00944900(auStack_5c);
    uStack_8._0_1_ = 6;
    apuStack_2c[0] = (undefined4 *)FUN_01674e20(0x30);
    uStack_8._0_1_ = 7;
    puStack_14 = apuStack_2c[0];
    if (apuStack_2c[0] == (undefined4 *)0x0) {
      apuStack_2c[0] = (undefined4 *)0x0;
    }
    else {
      *apuStack_2c[0] = uStack_94;
      FUN_00944900(auStack_8c);
    }
    FUN_00946a50();
    FUN_00946a50();
    bVar1 = true;
  }
  else {
    FUN_00946a50();
    bVar1 = false;
  }
  FUN_00946a50();
  ppuStack_34 = &PTR_FUN_01934d98;
  if (!bVar1) {
    ppuStack_34 = (undefined **)0x0;
  }
  FUN_00946a50();
  FUN_00946a50();
  FUN_00946a50();
  uStack_8._0_1_ = 8;
  FUN_0095e770(param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (((ppuStack_34 != (undefined **)0x0) && (((uint)ppuStack_34 & 1) == 0)) &&
     (*(code **)((uint)ppuStack_34 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)((uint)ppuStack_34 & 0xfffffffe))(apuStack_2c,apuStack_2c,2);
  }
  FUN_00946a50();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16914 ; VA 0x0093e980 ; FUN_0093e980 */

undefined4 __thiscall
FUN_0093e980(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10)

{
  undefined4 *puVar1;
  undefined4 auStack_8c [2];
  uint uStack_84;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca208;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_54 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    uStack_54 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_64 = 0;
      uStack_6c = CONCAT44(&uStack_4c,&param_6);
      uStack_70 = 0x93e9e5;
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_4c = param_6;
      uStack_48 = param_7;
      uStack_44 = param_8;
      uStack_40 = param_9;
      uStack_3c = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_64 = 0;
  puStack_14 = (undefined *)auStack_8c;
  uStack_8._0_1_ = 1;
  auStack_8c[0] = param_2;
  uStack_84 = 0;
  puVar1 = auStack_8c;
  if (uStack_54 != 0) {
    uStack_84 = uStack_54;
    if ((uStack_54 & 1) == 0) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_7c,0);
      puVar1 = (undefined4 *)puStack_14;
    }
    else {
      uStack_7c = uStack_4c;
      uStack_78 = uStack_48;
      uStack_74 = uStack_44;
      uStack_70 = uStack_40;
      uStack_6c = uStack_3c;
      puVar1 = auStack_8c;
    }
  }
  puStack_14 = (undefined *)puVar1;
  FUN_0093de70();
  uStack_8._0_1_ = 2;
  if (((uStack_54 != 0) && ((uStack_54 & 1) == 0)) &&
     (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
    uStack_64 = 2;
    uStack_6c = CONCAT44(&uStack_4c,&uStack_4c);
    uStack_70 = 0x93ea66;
    (**(code **)(uStack_54 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 3;
  uStack_6c = CONCAT44(0x93ea7d,(undefined4)uStack_6c);
  uStack_64 = param_1;
  FUN_0095e770();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      uStack_64 = 2;
      uStack_6c = CONCAT44(auStack_2c,auStack_2c);
      uStack_70 = 0x93ea9e;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    uStack_64 = 2;
    uStack_6c = CONCAT44(&param_6,&param_6);
    uStack_70 = 0x93eacc;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16915 ; VA 0x0093eaf0 ; FUN_0093eaf0 */

undefined4 __thiscall
FUN_0093eaf0(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10)

{
  undefined4 *puVar1;
  undefined4 auStack_8c [2];
  uint uStack_84;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca238;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_54 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    uStack_54 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_64 = 0;
      uStack_6c = CONCAT44(&uStack_4c,&param_6);
      uStack_70 = 0x93eb55;
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_4c = param_6;
      uStack_48 = param_7;
      uStack_44 = param_8;
      uStack_40 = param_9;
      uStack_3c = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_64 = 0;
  puStack_14 = (undefined *)auStack_8c;
  uStack_8._0_1_ = 1;
  auStack_8c[0] = param_2;
  uStack_84 = 0;
  puVar1 = auStack_8c;
  if (uStack_54 != 0) {
    uStack_84 = uStack_54;
    if ((uStack_54 & 1) == 0) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_7c,0);
      puVar1 = (undefined4 *)puStack_14;
    }
    else {
      uStack_7c = uStack_4c;
      uStack_78 = uStack_48;
      uStack_74 = uStack_44;
      uStack_70 = uStack_40;
      uStack_6c = uStack_3c;
      puVar1 = auStack_8c;
    }
  }
  puStack_14 = (undefined *)puVar1;
  FUN_0093e040();
  uStack_8._0_1_ = 2;
  if (((uStack_54 != 0) && ((uStack_54 & 1) == 0)) &&
     (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
    uStack_64 = 2;
    uStack_6c = CONCAT44(&uStack_4c,&uStack_4c);
    uStack_70 = 0x93ebd6;
    (**(code **)(uStack_54 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 3;
  uStack_6c = CONCAT44(0x93ebed,(undefined4)uStack_6c);
  uStack_64 = param_1;
  FUN_0095e770();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      uStack_64 = 2;
      uStack_6c = CONCAT44(auStack_2c,auStack_2c);
      uStack_70 = 0x93ec0e;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    uStack_64 = 2;
    uStack_6c = CONCAT44(&param_6,&param_6);
    uStack_70 = 0x93ec3c;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16916 ; VA 0x0093ec60 ; FUN_0093ec60 */

undefined4 __thiscall
FUN_0093ec60(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10)

{
  undefined4 *puVar1;
  undefined4 auStack_8c [2];
  uint uStack_84;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca268;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_54 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    uStack_54 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_64 = 0;
      uStack_6c = CONCAT44(&uStack_4c,&param_6);
      uStack_70 = 0x93ecc5;
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_4c = param_6;
      uStack_48 = param_7;
      uStack_44 = param_8;
      uStack_40 = param_9;
      uStack_3c = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_64 = 0;
  puStack_14 = (undefined *)auStack_8c;
  uStack_8._0_1_ = 1;
  auStack_8c[0] = param_2;
  uStack_84 = 0;
  puVar1 = auStack_8c;
  if (uStack_54 != 0) {
    uStack_84 = uStack_54;
    if ((uStack_54 & 1) == 0) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_7c,0);
      puVar1 = (undefined4 *)puStack_14;
    }
    else {
      uStack_7c = uStack_4c;
      uStack_78 = uStack_48;
      uStack_74 = uStack_44;
      uStack_70 = uStack_40;
      uStack_6c = uStack_3c;
      puVar1 = auStack_8c;
    }
  }
  puStack_14 = (undefined *)puVar1;
  FUN_0093e210();
  uStack_8._0_1_ = 2;
  if (((uStack_54 != 0) && ((uStack_54 & 1) == 0)) &&
     (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
    uStack_64 = 2;
    uStack_6c = CONCAT44(&uStack_4c,&uStack_4c);
    uStack_70 = 0x93ed46;
    (**(code **)(uStack_54 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 3;
  uStack_6c = CONCAT44(0x93ed5d,(undefined4)uStack_6c);
  uStack_64 = param_1;
  FUN_0095e770();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      uStack_64 = 2;
      uStack_6c = CONCAT44(auStack_2c,auStack_2c);
      uStack_70 = 0x93ed7e;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    uStack_64 = 2;
    uStack_6c = CONCAT44(&param_6,&param_6);
    uStack_70 = 0x93edac;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16917 ; VA 0x0093edd0 ; FUN_0093edd0 */

undefined4 __thiscall
FUN_0093edd0(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10)

{
  undefined4 *puVar1;
  undefined4 auStack_8c [2];
  uint uStack_84;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined8 uStack_6c;
  undefined4 uStack_64;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca298;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_54 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    uStack_54 = param_4;
    if ((param_4 & 1) == 0) {
      uStack_64 = 0;
      uStack_6c = CONCAT44(&uStack_4c,&param_6);
      uStack_70 = 0x93ee35;
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))();
    }
    else {
      uStack_4c = param_6;
      uStack_48 = param_7;
      uStack_44 = param_8;
      uStack_40 = param_9;
      uStack_3c = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_64 = 0;
  puStack_14 = (undefined *)auStack_8c;
  uStack_8._0_1_ = 1;
  auStack_8c[0] = param_2;
  uStack_84 = 0;
  puVar1 = auStack_8c;
  if (uStack_54 != 0) {
    uStack_84 = uStack_54;
    if ((uStack_54 & 1) == 0) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_7c,0);
      puVar1 = (undefined4 *)puStack_14;
    }
    else {
      uStack_7c = uStack_4c;
      uStack_78 = uStack_48;
      uStack_74 = uStack_44;
      uStack_70 = uStack_40;
      uStack_6c = uStack_3c;
      puVar1 = auStack_8c;
    }
  }
  puStack_14 = (undefined *)puVar1;
  FUN_0093e3e0();
  uStack_8._0_1_ = 2;
  if (((uStack_54 != 0) && ((uStack_54 & 1) == 0)) &&
     (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
    uStack_64 = 2;
    uStack_6c = CONCAT44(&uStack_4c,&uStack_4c);
    uStack_70 = 0x93eeb6;
    (**(code **)(uStack_54 & 0xfffffffe))();
  }
  uStack_8._0_1_ = 3;
  uStack_6c = CONCAT44(0x93eecd,(undefined4)uStack_6c);
  uStack_64 = param_1;
  FUN_0095e770();
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      uStack_64 = 2;
      uStack_6c = CONCAT44(auStack_2c,auStack_2c);
      uStack_70 = 0x93eeee;
      (**(code **)(uStack_34 & 0xfffffffe))();
    }
    uStack_34 = 0;
  }
  uStack_8 = 5;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    uStack_64 = 2;
    uStack_6c = CONCAT44(&param_6,&param_6);
    uStack_70 = 0x93ef1c;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16918 ; VA 0x0093ef40 ; FUN_0093ef40 */

undefined4 __thiscall
FUN_0093ef40(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  uint uStack_34;
  undefined auStack_2c [28];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca2c0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  FUN_0093e5b0(param_2,param_3,param_4,0);
  uStack_8._0_1_ = 1;
  FUN_0095e770(param_1);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
     (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16919 ; VA 0x0093f010 ; FUN_0093f010 */

undefined * FUN_0093f010(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ca2dc;
  pvStack_10 = ExceptionList;
  if (DAT_01ee2d90 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee2fa0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee2fa0);
      if (DAT_01ee2fa0 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"RuntimeScriptService",1,uStack_20,0,0,1,0,0);
        FUN_016f3654(&LAB_018853f0);
        FUN_016f37bf(&DAT_01ee2fa0);
      }
    }
    DAT_01ee2d90 = &DAT_01ee2d98;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee2d90;
}



/* FUNCTION 16920 ; VA 0x0093f0f0 ; FUN_0093f0f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0093f0f0(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ca310;
  pvStack_10 = ExceptionList;
  if (DAT_01ee2b74 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee2d88) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee2d88);
      if (DAT_01ee2d88 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"ScriptContext",1,uStack_20,0,0,1,0,0);
        _DAT_01ee2d80 = RBX::Creator<class_RBX::ScriptContext>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01ee2b78,&DAT_01ee2d80);
        FUN_016f3654(FUN_01885400);
        FUN_016f37bf(&DAT_01ee2d88);
      }
    }
    DAT_01ee2b74 = &DAT_01ee2b78;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee2b74;
}



/* FUNCTION 16921 ; VA 0x0093f1f0 ; FUN_0093f1f0 */

void FUN_0093f1f0(void)

{
  int iVar1;
  
  if (DAT_01ee2fa4 == 0) {
    iVar1 = FUN_0093f010();
    DAT_01ee2fa4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 16922 ; VA 0x0093f210 ; FUN_0093f210 */

void FUN_0093f210(void)

{
  int iVar1;
  
  if (DAT_01ee2d8c == 0) {
    iVar1 = FUN_0093f0f0();
    DAT_01ee2d8c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 16923 ; VA 0x0093f230 ; FUN_0093f230 */

void __thiscall FUN_0093f230(int *param_1,int param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = (param_3 - param_2) / 0xc;
  iVar1 = param_1[1];
  iVar4 = *param_1;
  uVar6 = (iVar1 - iVar4) / 0xc;
  uVar3 = (param_1[2] - iVar4) / 0xc;
  if (uVar2 <= uVar3) {
    if (uVar6 < uVar2) {
      iVar1 = param_2 + uVar6 * 0xc;
      FUN_0093f4f0(param_2,iVar1,iVar4);
      iVar4 = FUN_009414e0(iVar1,param_3,param_1[1],param_1);
      param_1[1] = iVar4;
      return;
    }
    FUN_0093f4f0(param_2,param_3,iVar4);
    iVar1 = param_1[1];
    iVar4 = iVar4 + uVar2 * 0xc;
    for (iVar5 = iVar4; iVar5 != iVar1; iVar5 = iVar5 + 0xc) {
      FUN_00947910();
    }
    param_1[1] = iVar4;
    return;
  }
  if (uVar2 < 0x15555556) {
    uVar6 = uVar2;
    if ((uVar3 <= 0x15555555 - (uVar3 >> 1)) && (uVar6 = (uVar3 >> 1) + uVar3, uVar6 < uVar2)) {
      uVar6 = uVar2;
    }
    if (iVar4 != 0) {
      if (iVar4 != iVar1) {
        do {
          FUN_00947910();
          iVar4 = iVar4 + 0xc;
        } while (iVar4 != iVar1);
        iVar4 = *param_1;
      }
      FUN_0061a4e0(iVar4,uVar3);
    }
    FUN_0085bef0(uVar6);
    iVar4 = FUN_009414e0(param_2,param_3,*param_1,param_1);
    param_1[1] = iVar4;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_00577c30();
}



/* FUNCTION 16924 ; VA 0x0093f390 ; FUN_0093f390 */

void FUN_0093f390(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  int iVar1;
  
  iVar1 = FUN_0068a6a0(param_1,param_2);
  *(undefined4 *)(iVar1 + 8) = *(undefined4 *)*param_4;
  *(undefined4 *)(iVar1 + 0xc) = 0;
  *(undefined4 *)(iVar1 + 0x10) = 0;
  return;
}



/* FUNCTION 16925 ; VA 0x0093f3c0 ; FUN_0093f3c0 */

int FUN_0093f3c0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ca320;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00949c50();
  uStack_8 = 0;
  *(undefined2 *)(iVar1 + 0xc) = 0;
  FUN_0054ef60(*param_2);
  *(undefined4 *)(iVar1 + 0x38) = 0;
  *(undefined4 *)(iVar1 + 0x3c) = 0xf;
  *(undefined *)(iVar1 + 0x28) = 0;
  *(undefined4 *)(iVar1 + 0x40) = 0;
  *(undefined4 *)(iVar1 + 0x44) = 0;
  *(undefined4 *)(iVar1 + 0x48) = 0;
  ExceptionList = pvStack_10;
  return iVar1;
}



/* FUNCTION 16926 ; VA 0x0093f444 ; Catch_All@0093f444 */

void Catch_All_0093f444(void)

{
  int unaff_EBP;
  
  FUN_00949f90(*(undefined4 *)(unaff_EBP + -0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16927 ; VA 0x0093f460 ; FUN_0093f460 */

int FUN_0093f460(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = FUN_00601de0();
  *(undefined2 *)(iVar2 + 0xc) = 0;
  *(undefined4 *)(iVar2 + 0x10) = 0;
  *(undefined4 *)(iVar2 + 0x14) = 0;
  if (param_1[1] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[1] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar2 + 0x10) = *param_1;
  *(undefined4 *)(iVar2 + 0x14) = param_1[1];
  return iVar2;
}



/* FUNCTION 16928 ; VA 0x0093f4a0 ; FUN_0093f4a0 */

int FUN_0093f4a0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = FUN_00601de0();
  *(undefined2 *)(iVar1 + 0xc) = 0;
  *(undefined4 *)(iVar1 + 0x10) = 0;
  *(undefined4 *)(iVar1 + 0x14) = 0;
  *(undefined4 *)(iVar1 + 0x10) = *param_1;
  *(undefined4 *)(iVar1 + 0x14) = param_1[1];
  *param_1 = 0;
  param_1[1] = 0;
  return iVar1;
}



/* FUNCTION 16929 ; VA 0x0093f4f0 ; FUN_0093f4f0 */

undefined4 * FUN_0093f4f0(int *param_1,int *param_2,undefined4 *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  
  if (param_1 != param_2) {
    iVar4 = (int)param_3 - (int)param_1;
    piVar5 = param_1 + 2;
    do {
      piVar1 = (int *)piVar5[-2];
      if (piVar1 != (int *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      piVar2 = (int *)*param_3;
      *param_3 = piVar1;
      if (piVar2 != (int *)0x0) {
        LOCK();
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          FUN_00d88950();
          FUN_01674ea0(piVar2,0x10);
        }
      }
      iVar3 = *piVar5;
      if (iVar3 != 0) {
        LOCK();
        *(int *)(iVar3 + 4) = *(int *)(iVar3 + 4) + 1;
        UNLOCK();
        iVar3 = *piVar5;
      }
      param_3[1] = piVar5[-1];
      piVar1 = *(int **)(iVar4 + (int)piVar5);
      *(int *)(iVar4 + (int)piVar5) = iVar3;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar3 = piVar1[1] + -1;
        piVar1[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piVar1)();
          LOCK();
          iVar3 = piVar1[2] + -1;
          piVar1[2] = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar1 + 4))();
          }
        }
      }
      param_3 = param_3 + 3;
      piVar1 = piVar5 + 1;
      piVar5 = piVar5 + 3;
    } while (piVar1 != param_2);
  }
  return param_3;
}



/* FUNCTION 16930 ; VA 0x0093f5b0 ; FUN_0093f5b0 */

void FUN_0093f5b0(uint *param_1,uint *param_2)

{
  int iVar1;
  uint uVar2;
  int *piVar3;
  
  if (param_1 != param_2) {
    do {
      uVar2 = *param_1;
      if (uVar2 != 0) {
        piVar3 = (int *)(uVar2 + 4);
        LOCK();
        iVar1 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if ((iVar1 == 1) &&
           (piVar3 = (int *)(-(uint)(piVar3 != (int *)0x0) & uVar2), piVar3 != (int *)0x0)) {
          (**(code **)(*piVar3 + 4))(1);
        }
      }
      param_1 = param_1 + 6;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 16931 ; VA 0x0093f600 ; FUN_0093f600 */

int __thiscall FUN_0093f600(uint *param_1,uint param_2,undefined4 *param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  uint uVar12;
  
  uVar12 = *param_1;
  iVar11 = param_2 - uVar12;
  iVar6 = (int)(param_1[1] - uVar12) >> 4;
  if (iVar6 == 0xfffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar6 + 1;
  uVar9 = (int)(param_1[2] - uVar12) >> 4;
  uVar12 = uVar1;
  if ((uVar9 <= 0xfffffff - (uVar9 >> 1)) && (uVar12 = (uVar9 >> 1) + uVar9, uVar12 < uVar1)) {
    uVar12 = uVar1;
  }
  uVar9 = uVar12 * 0x10;
  if (uVar12 < 0x10000000) {
    uVar12 = uVar9;
    if (0xfff < uVar9) goto LAB_0093f670;
    if (uVar9 == 0) {
      uVar12 = 0;
    }
    else {
      uVar12 = FUN_01674e20(uVar9);
    }
  }
  else {
    uVar12 = 0xffffffff;
LAB_0093f670:
    uVar7 = uVar12 + 0x23;
    if (uVar7 <= uVar12) {
      uVar7 = 0xffffffff;
    }
    iVar6 = FUN_01674e20(uVar7);
    if (iVar6 == 0) goto LAB_0093f791;
    uVar12 = iVar6 + 0x23U & 0xffffffe0;
    *(int *)(uVar12 - 4) = iVar6;
  }
  iVar6 = (iVar11 >> 4) * 0x10;
  puVar2 = (undefined4 *)(iVar6 + uVar12);
  uVar3 = param_3[1];
  uVar4 = param_3[2];
  uVar5 = param_3[3];
  *puVar2 = *param_3;
  puVar2[1] = uVar3;
  puVar2[2] = uVar4;
  puVar2[3] = uVar5;
  if (param_2 == param_1[1]) {
    FUN_0055b6b0((int)&param_2 + 3,&param_2,&param_2);
    FUN_0170cc70(uVar12,*param_1,param_1[1] - *param_1);
  }
  else {
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(uVar12,*param_1,param_2 - *param_1);
    FUN_0055b6b0((int)&param_3 + 3,&param_3,&param_3);
    FUN_0170cc70(puVar2 + 4,param_2,param_1[1] - param_2);
  }
  uVar7 = *param_1;
  if (uVar7 != 0) {
    uVar10 = param_1[2] - uVar7 & 0xfffffff0;
    uVar8 = uVar7;
    if (0xfff < uVar10) {
      uVar8 = *(uint *)(uVar7 - 4);
      uVar10 = uVar10 + 0x23;
      if (0x1f < (uVar7 - uVar8) - 4) {
LAB_0093f791:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar10);
  }
  *param_1 = uVar12;
  param_1[1] = uVar1 * 0x10 + uVar12;
  param_1[2] = uVar9 + uVar12;
  return *param_1 + iVar6;
}



/* FUNCTION 16932 ; VA 0x0093f7a0 ; FUN_0093f7a0 */

int __thiscall FUN_0093f7a0(uint *param_1,uint param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ca343;
  pvStack_10 = ExceptionList;
  uVar8 = *param_1;
  iVar1 = (int)(param_1[1] - *param_1) / 0x50;
  if (iVar1 == 0x3333333) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar5 = iVar1 + 1;
  uVar2 = (int)(param_1[2] - *param_1) / 0x50;
  uVar7 = uVar5;
  if ((uVar2 <= 0x3333333 - (uVar2 >> 1)) && (uVar7 = (uVar2 >> 1) + uVar2, uVar7 < uVar5)) {
    uVar7 = uVar5;
  }
  uVar5 = uVar7 * 0x50;
  if (uVar7 < 0x3333334) {
    uVar7 = uVar5;
    if (0xfff < uVar5) goto LAB_0093f857;
    if (uVar5 == 0) {
      uVar7 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar7 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar7 = 0xffffffff;
LAB_0093f857:
    uVar2 = uVar7 + 0x23;
    if (uVar2 <= uVar7) {
      uVar2 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar3 = FUN_01674e20(uVar2);
    if (iVar3 == 0) goto LAB_0093f9ed;
    uVar7 = iVar3 + 0x23U & 0xffffffe0;
    *(int *)(uVar7 - 4) = iVar3;
  }
  uStack_8 = 0;
  iVar4 = ((int)(param_2 - uVar8) / 0x50) * 0x50;
  iVar3 = iVar4 + uVar7;
  FUN_0054ef60(param_3);
  uStack_8._0_1_ = 1;
  FUN_0054ef60(param_3 + 0x18);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00569460(param_3 + 0x30);
  *(undefined8 *)(iVar3 + 0x40) = *(undefined8 *)(param_3 + 0x40);
  *(undefined4 *)(iVar3 + 0x48) = *(undefined4 *)(param_3 + 0x48);
  if (param_2 == param_1[1]) {
    FUN_00941550(*param_1,param_1[1],uVar7,param_1);
  }
  else {
    FUN_00941550(*param_1,param_2,uVar7,param_1);
    FUN_00941550(param_2,param_1[1],iVar3 + 0x50,param_1);
  }
  uVar8 = *param_1;
  if (uVar8 != 0) {
    uVar2 = param_1[1];
    if (uVar8 != uVar2) {
      do {
        FUN_006fe4e0();
        uVar8 = uVar8 + 0x50;
      } while (uVar8 != uVar2);
      uVar8 = *param_1;
    }
    uVar6 = ((int)(param_1[2] - uVar8) / 0x50) * 0x50;
    uVar2 = uVar8;
    if (0xfff < uVar6) {
      uVar2 = *(uint *)(uVar8 - 4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uVar8 - uVar2) - 4) {
LAB_0093f9ed:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar6);
  }
  *param_1 = uVar7;
  param_1[1] = (iVar1 * 5 + 5) * 0x10 + uVar7;
  param_1[2] = uVar5 + uVar7;
  ExceptionList = pvStack_10;
  return *param_1 + iVar4;
}



/* FUNCTION 16933 ; VA 0x0093f9c4 ; Catch_All@0093f9c4 */

void Catch_All_0093f9c4(void)

{
  int unaff_EBP;
  
  FUN_006fea10(*(undefined4 *)(unaff_EBP + -0x28),*(undefined4 *)(unaff_EBP + -0x28));
  FUN_006fec30(*(undefined4 *)(unaff_EBP + -0x14),*(undefined4 *)(unaff_EBP + -0x18));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16934 ; VA 0x0093fa00 ; FUN_0093fa00 */

int __thiscall FUN_0093fa00(int *param_1,int param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  
  iVar5 = *param_1;
  iVar2 = (param_1[1] - iVar5) / 0xc;
  if (iVar2 == 0x15555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar6 = iVar2 + 1;
  uVar3 = (param_1[2] - iVar5) / 0xc;
  uVar7 = uVar6;
  if ((uVar3 <= 0x15555555 - (uVar3 >> 1)) && (uVar7 = (uVar3 >> 1) + uVar3, uVar7 < uVar6)) {
    uVar7 = uVar6;
  }
  iVar4 = FUN_00618050(uVar7);
  piVar1 = (int *)*param_3;
  iVar5 = ((param_2 - iVar5) / 0xc) * 0xc;
  *(int **)(iVar5 + iVar4) = piVar1;
  if (piVar1 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar5 + 4 + iVar4) = 0;
  *(undefined4 *)(iVar5 + 8 + iVar4) = 0;
  if (param_3[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_3[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  *(undefined4 *)(iVar5 + 4 + iVar4) = param_3[1];
  *(undefined4 *)(iVar5 + 8 + iVar4) = param_3[2];
  if (param_2 == param_1[1]) {
    FUN_009414e0(*param_1,param_1[1],iVar4,param_1);
  }
  else {
    FUN_0094a1c0(*param_1,param_2,iVar4);
    FUN_0094a1c0(param_2,param_1[1],iVar5 + 0xc + iVar4);
  }
  iVar8 = *param_1;
  if (iVar8 != 0) {
    iVar9 = param_1[1];
    if (iVar8 != iVar9) {
      do {
        FUN_00947910();
        iVar8 = iVar8 + 0xc;
      } while (iVar8 != iVar9);
      iVar8 = *param_1;
    }
    uVar6 = ((param_1[2] - iVar8) / 0xc) * 0xc;
    iVar9 = iVar8;
    if (0xfff < uVar6) {
      iVar9 = *(int *)(iVar8 + -4);
      uVar6 = uVar6 + 0x23;
      if (0x1f < (iVar8 - iVar9) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar9,uVar6);
  }
  *param_1 = iVar4;
  param_1[1] = iVar4 + (iVar2 * 3 + 3) * 4;
  param_1[2] = iVar4 + uVar7 * 0xc;
  return *param_1 + iVar5;
}



/* FUNCTION 16935 ; VA 0x0093fbb0 ; FUN_0093fbb0 */

int __thiscall FUN_0093fbb0(int *param_1,undefined4 *param_2,undefined4 param_3)

{
  uint uVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  undefined4 *puVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ca36b;
  pvStack_10 = ExceptionList;
  iVar8 = *param_1;
  iVar4 = (int)param_2 - iVar8 >> 6;
  iVar5 = param_1[1] - iVar8 >> 6;
  if (iVar5 == 0x3ffffff) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar5 + 1;
  uVar9 = param_1[2] - iVar8 >> 6;
  uVar6 = uVar1;
  if ((uVar9 <= 0x3ffffff - (uVar9 >> 1)) && (uVar6 = (uVar9 >> 1) + uVar9, uVar6 < uVar1)) {
    uVar6 = uVar1;
  }
  uVar9 = uVar6 << 6;
  if (uVar6 < 0x4000000) {
    if (0xfff < uVar9) goto LAB_0093fc43;
    if (uVar9 == 0) {
      puVar11 = (undefined4 *)0x0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      puVar11 = (undefined4 *)FUN_01674e20(uVar9);
    }
  }
  else {
    uVar9 = 0xffffffff;
LAB_0093fc43:
    uVar7 = uVar9 + 0x23;
    if (uVar7 <= uVar9) {
      uVar7 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar8 = FUN_01674e20(uVar7);
    if (iVar8 == 0) goto LAB_0093fdee;
    puVar11 = (undefined4 *)(iVar8 + 0x23U & 0xffffffe0);
    puVar11[-1] = iVar8;
  }
  uStack_8 = 0;
  FUN_00942ca0(param_1,puVar11 + iVar4 * 0x10,param_3);
  puVar3 = (undefined4 *)param_1[1];
  if (param_2 == puVar3) {
    puVar12 = (undefined4 *)*param_1;
    puVar10 = puVar11;
    while( true ) {
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (puVar12 == puVar3) break;
      *puVar10 = 0;
      puVar10[1] = 0;
      if (puVar12[1] != 0) {
        LOCK();
        piVar2 = (int *)(puVar12[1] + 8);
        *piVar2 = *piVar2 + 1;
        UNLOCK();
      }
      *puVar10 = *puVar12;
      puVar10[1] = puVar12[1];
      uStack_8._0_1_ = 2;
      FUN_0054ef60(puVar12 + 2);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      FUN_00d88580(puVar12 + 8);
      puVar10 = puVar10 + 0x10;
      puVar12 = puVar12 + 0x10;
    }
  }
  else {
    FUN_0094a150(*param_1,param_2,puVar11);
    FUN_0094a150(param_2,param_1[1],puVar11 + iVar4 * 0x10 + 0x10);
  }
  iVar8 = *param_1;
  if (iVar8 != 0) {
    iVar5 = param_1[1];
    if (iVar8 != iVar5) {
      do {
        FUN_00947650();
        iVar8 = iVar8 + 0x40;
      } while (iVar8 != iVar5);
      iVar8 = *param_1;
    }
    uVar9 = param_1[2] - iVar8 & 0xffffffc0;
    iVar5 = iVar8;
    if (0xfff < uVar9) {
      iVar5 = *(int *)(iVar8 + -4);
      uVar9 = uVar9 + 0x23;
      if (0x1f < (iVar8 - iVar5) - 4U) {
LAB_0093fdee:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar9);
  }
  *param_1 = (int)puVar11;
  param_1[1] = (int)(puVar11 + uVar1 * 0x10);
  param_1[2] = (int)(puVar11 + uVar6 * 0x10);
  ExceptionList = pvStack_10;
  return *param_1 + iVar4 * 0x40;
}



/* FUNCTION 16936 ; VA 0x0093fdc4 ; Catch_All@0093fdc4 */

void Catch_All_0093fdc4(void)

{
  int unaff_EBP;
  
  FUN_00949cf0(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x20));
  FUN_0089eda0(*(undefined4 *)(unaff_EBP + -0x2c),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16937 ; VA 0x0093fe00 ; FUN_0093fe00 */

int __thiscall FUN_0093fe00(uint *param_1,uint param_2,undefined4 param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int *piVar7;
  int *piVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ca388;
  pvStack_10 = ExceptionList;
  uVar6 = *param_1;
  iVar4 = (int)(param_1[1] - *param_1) / 0x1c;
  if (iVar4 == 0x9249249) {
    ExceptionList = &pvStack_10;
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar4 + 1;
  uVar5 = (int)(param_1[2] - *param_1) / 0x1c;
  uVar2 = uVar1;
  if ((uVar5 <= 0x9249249 - (uVar5 >> 1)) && (uVar2 = (uVar5 >> 1) + uVar5, uVar2 < uVar1)) {
    uVar2 = uVar1;
  }
  uVar5 = uVar2 * 0x1c;
  if (uVar2 < 0x924924a) {
    if (0xfff < uVar5) goto LAB_0093fec3;
    if (uVar5 == 0) {
      uVar5 = 0;
      ExceptionList = &pvStack_10;
    }
    else {
      ExceptionList = &pvStack_10;
      uVar5 = FUN_01674e20(uVar5);
    }
  }
  else {
    uVar5 = 0xffffffff;
LAB_0093fec3:
    uVar3 = uVar5 + 0x23;
    if (uVar3 <= uVar5) {
      uVar3 = 0xffffffff;
    }
    ExceptionList = &pvStack_10;
    iVar4 = FUN_01674e20(uVar3);
    if (iVar4 == 0) goto LAB_00940063;
    uVar5 = iVar4 + 0x23U & 0xffffffe0;
    *(int *)(uVar5 - 4) = iVar4;
  }
  iVar4 = ((int)(param_2 - uVar6) / 0x1c) * 0x1c;
  uStack_8 = 0;
  FUN_00d88710(param_3);
  uVar6 = param_1[1];
  if (param_2 == uVar6) {
    uVar3 = *param_1;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    for (; uVar3 != uVar6; uVar3 = uVar3 + 0x1c) {
      FUN_00d88710(uVar3);
    }
  }
  else {
    FUN_0094a240(*param_1,param_2,uVar5);
    FUN_0094a240(param_2,param_1[1],iVar4 + uVar5 + 0x1c);
  }
  piVar7 = (int *)*param_1;
  if (piVar7 != (int *)0x0) {
    piVar8 = (int *)param_1[1];
    if (piVar7 != piVar8) {
      do {
        (**(code **)(*piVar7 + 4))(0);
        piVar7 = piVar7 + 7;
      } while (piVar7 != piVar8);
      piVar7 = (int *)*param_1;
    }
    uVar6 = ((int)(param_1[2] - (int)piVar7) / 0x1c) * 0x1c;
    piVar8 = piVar7;
    if (0xfff < uVar6) {
      piVar8 = (int *)piVar7[-1];
      uVar6 = uVar6 + 0x23;
      if (0x1f < (uint)((int)piVar7 + (-4 - (int)piVar8))) {
LAB_00940063:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar8,uVar6);
  }
  *param_1 = uVar5;
  param_1[1] = uVar5 + uVar1 * 0x1c;
  param_1[2] = uVar5 + uVar2 * 0x1c;
  ExceptionList = pvStack_10;
  return *param_1 + iVar4;
}



/* FUNCTION 16938 ; VA 0x00940039 ; Catch_All@00940039 */

void Catch_All_00940039(void)

{
  int unaff_EBP;
  
  FUN_00949d20(*(undefined4 *)(unaff_EBP + -0x18),*(undefined4 *)(unaff_EBP + -0x20));
  FUN_007c60b0(*(undefined4 *)(unaff_EBP + -0x30),*(undefined4 *)(unaff_EBP + -0x1c));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16939 ; VA 0x00940070 ; FUN_00940070 */

void __thiscall FUN_00940070(float *param_1,float *param_2,byte *param_3,float *param_4)

{
  float fVar1;
  float *pfVar2;
  float fVar3;
  uint uVar4;
  float fVar5;
  undefined auStack_24 [8];
  float *pfStack_1c;
  float *pfStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca3a0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  uStack_8 = 0;
  fVar3 = param_1[1];
  uVar4 = (uint)param_1[6] &
          ((((*param_3 ^ 0x811c9dc5) * 0x1000193 ^ (uint)param_3[1]) * 0x1000193 ^ (uint)param_3[2])
           * 0x1000193 ^ (uint)param_3[3]) * 0x1000193;
  fVar5 = *(float *)((int)param_1[3] + uVar4 * 8);
  pfStack_1c = param_1;
  if (fVar3 != fVar5) {
    fVar3 = **(float **)((int)param_1[3] + 4 + uVar4 * 8);
    while (fVar3 != fVar5) {
      fVar3 = *(float *)((int)fVar3 + 4);
      if (*(int *)param_3 == *(int *)((int)fVar3 + 8)) {
        ExceptionList = &pvStack_10;
        puStack_14 = &stack0xffffffd0;
        FUN_00949d50(param_4);
        *param_2 = fVar3;
        *(undefined *)(param_2 + 1) = 0;
        ExceptionList = pvStack_10;
        return;
      }
    }
  }
  pfStack_18 = param_4;
  fVar5 = *param_4;
  ExceptionList = &pvStack_10;
  if (fVar3 != fVar5) {
    ExceptionList = &pvStack_10;
    *(float *)param_4[1] = fVar5;
    **(float **)((int)fVar5 + 4) = fVar3;
    **(undefined4 **)((int)fVar3 + 4) = param_4;
    fVar1 = *(float *)((int)fVar3 + 4);
    *(undefined4 *)((int)fVar3 + 4) = *(undefined4 *)((int)fVar5 + 4);
    *(float *)((int)fVar5 + 4) = param_4[1];
    param_4[1] = fVar1;
  }
  fVar5 = param_1[3];
  fVar1 = *(float *)((int)fVar5 + uVar4 * 8);
  if (fVar1 == param_1[1]) {
    *(float **)((int)fVar5 + uVar4 * 8) = param_4;
    *(float **)((int)param_1[3] + 4 + uVar4 * 8) = param_4;
  }
  else if (fVar1 == fVar3) {
    *(float **)((int)fVar5 + uVar4 * 8) = param_4;
  }
  else {
    pfVar2 = (float *)**(undefined4 **)((int)fVar5 + 4 + uVar4 * 8);
    *(float **)((int)fVar5 + 4 + uVar4 * 8) = pfVar2;
    if (pfVar2 != param_4) {
      *(undefined4 *)((int)param_1[3] + 4 + uVar4 * 8) =
           *(undefined4 *)(*(int *)((int)param_1[3] + 4 + uVar4 * 8) + 4);
    }
  }
  fVar3 = param_1[7];
  uStack_8 = 2;
  fVar5 = (float)((double)(int)param_1[2] + (double)(&DAT_018c0d90)[-((int)param_1[2] >> 0x1f)]) /
          (float)((double)(int)fVar3 + (double)(&DAT_018c0d90)[-((int)fVar3 >> 0x1f)]);
  if (*param_1 <= fVar5 && fVar5 != *param_1) {
    if ((uint)fVar3 < 0x200) {
      fVar3 = (float)((int)fVar3 << 3);
    }
    else if ((uint)fVar3 < 0x1fffffff) {
      fVar3 = (float)((int)fVar3 * 2);
    }
    FUN_005cb500(fVar3);
    pfVar2 = (float *)param_1[1];
    if ((float *)*pfVar2 != pfVar2) {
      fVar3 = pfVar2[1];
      do {
        fVar5 = *(float *)param_1[1];
        FUN_00940070(auStack_24,(int)fVar5 + 8,fVar5);
      } while (fVar5 != fVar3);
    }
  }
  *param_2 = (float)param_4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16940 ; VA 0x0094023a ; Catch_All@0094023a */

void Catch_All_0094023a(void)

{
  undefined4 *puVar1;
  int unaff_EBP;
  
  puVar1 = (undefined4 *)FUN_005cb640(unaff_EBP + 8,*(undefined4 *)(unaff_EBP + -0x14));
  FUN_00943040(unaff_EBP + 0xc,*puVar1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16941 ; VA 0x00940270 ; FUN_00940270 */

void __thiscall
FUN_00940270(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0x35e50d5 < (uint)param_1[1]) {
    FUN_00949db0(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00940322:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00940322;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 16942 ; VA 0x009403d0 ; FUN_009403d0 */

void __thiscall
FUN_009403d0(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5,
            int *param_6)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  
  if (0xaaaaaa8 < (uint)param_1[1]) {
    FUN_00949dd0(param_6);
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  param_1[1] = param_1[1] + 1;
  param_6[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = param_6;
    *(int **)*param_1 = param_6;
    *(int **)(*param_1 + 8) = param_6;
  }
  else if (param_3 == '\0') {
    param_4[2] = param_6;
    if (param_4 == *(undefined4 **)(*param_1 + 8)) {
      *(int **)(*param_1 + 8) = param_6;
    }
  }
  else {
    *param_4 = param_6;
    if (param_4 == *(undefined4 **)*param_1) {
      *(int **)*param_1 = param_6;
    }
  }
  cVar1 = *(char *)(param_6[1] + 0xc);
  piVar5 = param_6;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = param_6;
      return;
    }
    piVar2 = (int *)piVar5[1];
    piVar4 = *(int **)piVar2[1];
    if (piVar2 == piVar4) {
      piVar4 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar4 + 3) == '\0') {
LAB_00940482:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar4 + 3) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        piVar5 = *(int **)(piVar5[1] + 4);
      }
      else {
        if (piVar5 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar5 = piVar2;
        }
        *(undefined *)(piVar5[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar5[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar4 + 3) == '\0') goto LAB_00940482;
      if (piVar5 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar5 = piVar2;
      }
      *(undefined *)(piVar5[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar5[1] + 4) + 0xc) = 0;
      iVar3 = *(int *)(piVar5[1] + 4);
      piVar2 = *(int **)(iVar3 + 8);
      *(int *)(iVar3 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar3;
      }
      piVar2[1] = *(int *)(iVar3 + 4);
      if (iVar3 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar4 = *(int **)(iVar3 + 4);
        if (iVar3 == *piVar4) {
          *piVar4 = (int)piVar2;
        }
        else {
          piVar4[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar3;
      *(int **)(iVar3 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar5[1] + 0xc);
  } while( true );
}



/* FUNCTION 16943 ; VA 0x00940530 ; FUN_00940530 */

void __thiscall
FUN_00940530(int *param_1,undefined4 *param_2,char param_3,undefined4 *param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  
  if (0xaaaaaa8 < (uint)param_1[1]) {
                    /* WARNING: Subroutine does not return */
    FUN_016ddcd9("map/set<T> too long");
  }
  piVar3 = (int *)FUN_0093f4a0(param_5);
  param_1[1] = param_1[1] + 1;
  piVar3[1] = (int)param_4;
  if (param_4 == (undefined4 *)*param_1) {
    ((undefined4 *)*param_1)[1] = piVar3;
    *(int **)*param_1 = piVar3;
    iVar4 = *param_1;
  }
  else {
    if (param_3 != '\0') {
      *param_4 = piVar3;
      if (param_4 == *(undefined4 **)*param_1) {
        *(int **)*param_1 = piVar3;
      }
      goto LAB_00940588;
    }
    param_4[2] = piVar3;
    iVar4 = *param_1;
    if (param_4 != *(undefined4 **)(iVar4 + 8)) goto LAB_00940588;
  }
  *(int **)(iVar4 + 8) = piVar3;
LAB_00940588:
  cVar1 = *(char *)(piVar3[1] + 0xc);
  piVar6 = piVar3;
  do {
    if (cVar1 != '\0') {
      *(undefined *)(*(int *)(*param_1 + 4) + 0xc) = 1;
      *param_2 = piVar3;
      return;
    }
    piVar2 = (int *)piVar6[1];
    piVar5 = *(int **)piVar2[1];
    if (piVar2 == piVar5) {
      piVar5 = (int *)((undefined4 *)piVar2[1])[2];
      if (*(char *)(piVar5 + 3) == '\0') {
LAB_009405e1:
        *(undefined *)(piVar2 + 3) = 1;
        *(undefined *)(piVar5 + 3) = 1;
        *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
        piVar6 = *(int **)(piVar6[1] + 4);
      }
      else {
        if (piVar6 == (int *)piVar2[2]) {
          FUN_00553e40(piVar2);
          piVar6 = piVar2;
        }
        *(undefined *)(piVar6[1] + 0xc) = 1;
        *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
        FUN_00553f50(*(undefined4 *)(piVar6[1] + 4));
      }
    }
    else {
      if (*(char *)(piVar5 + 3) == '\0') goto LAB_009405e1;
      if (piVar6 == (int *)*piVar2) {
        FUN_00553f50(piVar2);
        piVar6 = piVar2;
      }
      *(undefined *)(piVar6[1] + 0xc) = 1;
      *(undefined *)(*(int *)(piVar6[1] + 4) + 0xc) = 0;
      iVar4 = *(int *)(piVar6[1] + 4);
      piVar2 = *(int **)(iVar4 + 8);
      *(int *)(iVar4 + 8) = *piVar2;
      if (*(char *)(*piVar2 + 0xd) == '\0') {
        *(int *)(*piVar2 + 4) = iVar4;
      }
      piVar2[1] = *(int *)(iVar4 + 4);
      if (iVar4 == *(int *)(*param_1 + 4)) {
        *(int **)(*param_1 + 4) = piVar2;
      }
      else {
        piVar5 = *(int **)(iVar4 + 4);
        if (iVar4 == *piVar5) {
          *piVar5 = (int)piVar2;
        }
        else {
          piVar5[2] = (int)piVar2;
        }
      }
      *piVar2 = iVar4;
      *(int **)(iVar4 + 4) = piVar2;
    }
    cVar1 = *(char *)(piVar6[1] + 0xc);
  } while( true );
}



/* FUNCTION 16944 ; VA 0x00940690 ; FUN_00940690 */

undefined4 * __thiscall
FUN_00940690(int *param_1,undefined4 *param_2,int *param_3,undefined4 *param_4,undefined4 param_5)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca3b0;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)0x0;
  puStack_14 = &stack0xffffffd4;
  uStack_8 = 0;
  piStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_00940270(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar3 = (int *)*param_1;
  if (param_3 == (int *)*piVar3) {
    piVar3 = param_3 + 4;
    if (0xf < (uint)param_3[9]) {
      piVar3 = (int *)*piVar3;
    }
    puVar5 = param_4;
    if (0xf < (uint)param_4[5]) {
      puVar5 = (undefined4 *)*param_4;
    }
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    iVar2 = FUN_0055c2d0(puVar5,param_4[4],piVar3,param_3[8]);
    if (iVar2 < 0) {
      FUN_00940270(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar3) {
    iVar2 = piVar3[2];
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    cVar1 = FUN_00570370(iVar2 + 0x10,param_4);
    if (cVar1 != '\0') {
      FUN_00940270(param_2,0,iVar2,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    ExceptionList = &pvStack_10;
    cVar1 = FUN_00570370(param_4,param_3 + 4);
    if (cVar1 != '\0') {
      piStack_18 = param_3;
      piVar3 = (int *)FUN_0056f560();
      cVar1 = FUN_00570370(*piVar3 + 0x10,param_4);
      if (cVar1 != '\0') {
        if (*(char *)(piStack_18[2] + 0xd) == '\0') {
          FUN_00940270(param_2,1,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00940270(param_2,0,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
    cVar1 = FUN_00570370(param_3 + 4,param_4);
    if (cVar1 != '\0') {
      piStack_18 = param_3;
      piVar4 = (int *)FUN_00551320();
      piVar3 = piStack_18;
      if ((*piVar4 == *param_1) || (cVar1 = FUN_00570370(param_4,piStack_18 + 4), cVar1 != '\0')) {
        if (*(char *)(param_3[2] + 0xd) == '\0') {
          FUN_00940270(param_2,1,piVar3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_00940270(param_2,0,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar5 = (undefined4 *)FUN_00940b00(auStack_20,0,param_4,param_5);
  *param_2 = *puVar5;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16945 ; VA 0x009408d8 ; Catch_All@009408d8 */

void Catch_All_009408d8(void)

{
  int unaff_EBP;
  
  FUN_00949db0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16946 ; VA 0x009408f0 ; FUN_009408f0 */

undefined4 * __thiscall
FUN_009408f0(undefined4 *param_1,undefined4 *param_2,int *param_3,int param_4,undefined4 param_5)

{
  undefined *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  bool bVar4;
  undefined auStack_20 [4];
  undefined4 *puStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca3c0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd4;
  piStack_18 = (int *)0x0;
  uStack_8 = 0;
  puStack_1c = param_1;
  if (param_1[1] == 0) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    FUN_009403d0(param_2,1,*param_1,param_4,param_5);
    ExceptionList = pvStack_10;
    return param_2;
  }
  piVar2 = (int *)*param_1;
  if (param_3 == (int *)*piVar2) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*(uint *)(param_4 + 4) < (uint)param_3[5]) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_009403d0(param_2,1,param_3,param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else if (param_3 == piVar2) {
    ExceptionList = &pvStack_10;
    puStack_14 = &stack0xffffffd4;
    if (*(uint *)(piVar2[2] + 0x14) < *(uint *)(param_4 + 4)) {
      ExceptionList = &pvStack_10;
      puStack_14 = &stack0xffffffd4;
      FUN_009403d0(param_2,0,piVar2[2],param_4,param_5);
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  else {
    bVar4 = (uint)param_3[5] < *(uint *)(param_4 + 4);
    ExceptionList = &pvStack_10;
    puVar1 = &stack0xffffffd4;
    if (*(uint *)(param_4 + 4) < (uint)param_3[5]) {
      piStack_18 = param_3;
      ExceptionList = &pvStack_10;
      piVar2 = (int *)FUN_0056f560();
      if (*(uint *)(*piVar2 + 0x14) < *(uint *)(param_4 + 4)) {
        if (*(char *)(piStack_18[2] + 0xd) != '\0') {
          FUN_009403d0(param_2,0,piStack_18,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_009403d0(param_2,1,param_3,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
      bVar4 = (uint)param_3[5] < *(uint *)(param_4 + 4);
      puVar1 = puStack_14;
    }
    puStack_14 = puVar1;
    if (bVar4) {
      piStack_18 = param_3;
      FUN_00551320();
      if ((piStack_18 == (int *)*param_1) || (*(uint *)(param_4 + 4) < (uint)piStack_18[5])) {
        if (*(char *)(param_3[2] + 0xd) != '\0') {
          FUN_009403d0(param_2,0,param_3,param_4,param_5);
          ExceptionList = pvStack_10;
          return param_2;
        }
        FUN_009403d0(param_2,1,piStack_18,param_4,param_5);
        ExceptionList = pvStack_10;
        return param_2;
      }
    }
  }
  uStack_8 = 0xffffffff;
  puVar3 = (undefined4 *)FUN_00940c80(auStack_20,0,param_4,param_5);
  *param_2 = *puVar3;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16947 ; VA 0x00940ae0 ; Catch_All@00940ae0 */

void Catch_All_00940ae0(void)

{
  int unaff_EBP;
  
  FUN_00949dd0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16948 ; VA 0x00940b00 ; FUN_00940b00 */

void __thiscall
FUN_00940b00(undefined4 *param_1,undefined4 *param_2,int *param_3,undefined4 *param_4,
            undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  undefined4 uVar3;
  byte bVar4;
  int *piVar5;
  byte extraout_var;
  byte extraout_var_00;
  undefined4 *puVar6;
  int *piVar7;
  int iVar8;
  undefined4 *puVar9;
  int *piVar10;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar6 = param_4;
  puStack_c = &LAB_017ca3d0;
  piVar7 = (int *)*param_1;
  bVar4 = 1;
  uStack_8 = 0;
  cVar1 = *(char *)(piVar7[1] + 0xd);
  piVar5 = piVar7;
  piVar2 = (int *)piVar7[1];
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  while (cVar1 == '\0') {
    piVar5 = piVar2 + 4;
    if ((char)param_3 == '\0') {
      if (0xf < (uint)piVar2[9]) {
        piVar5 = (int *)*piVar5;
      }
      puVar9 = puVar6;
      if (0xf < (uint)puVar6[5]) {
        puVar9 = (undefined4 *)*puVar6;
      }
      FUN_0055c2d0(puVar9,puVar6[4],piVar5,piVar2[8]);
      bVar4 = extraout_var_00 >> 7;
    }
    else {
      puVar9 = puVar6;
      if (0xf < (uint)puVar6[5]) {
        puVar9 = (undefined4 *)*puVar6;
      }
      if (0xf < (uint)piVar2[9]) {
        piVar5 = (int *)*piVar5;
      }
      FUN_0055c2d0(piVar5,piVar2[8],puVar9,puVar6[4]);
      bVar4 = extraout_var >> 7 ^ 1;
    }
    if (bVar4 == 0) {
      piVar10 = (int *)piVar2[2];
    }
    else {
      piVar10 = (int *)*piVar2;
    }
    piVar5 = piVar2;
    piVar2 = piVar10;
    cVar1 = *(char *)((int)piVar10 + 0xd);
  }
  param_3 = piVar5;
  if (bVar4 != 0) {
    if (piVar5 == (int *)*piVar7) {
      bVar4 = 1;
      goto LAB_00940bcc;
    }
    FUN_0056f560();
  }
  piVar2 = param_3;
  piVar7 = param_3 + 4;
  puVar9 = puVar6;
  if (0xf < (uint)puVar6[5]) {
    puVar9 = (undefined4 *)*puVar6;
  }
  if (0xf < (uint)param_3[9]) {
    piVar7 = (int *)*piVar7;
  }
  iVar8 = FUN_0055c2d0(piVar7,param_3[8],puVar9,puVar6[4]);
  uVar3 = param_5;
  if (-1 < iVar8) {
    FUN_00946840();
    FUN_01674ea0(uVar3,0x4c);
    *param_2 = piVar2;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00940bcc:
  puVar6 = (undefined4 *)FUN_00940270(&param_3,bVar4,piVar5,puVar6,param_5);
  *param_2 = *puVar6;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16949 ; VA 0x00940c6a ; Catch_All@00940c6a */

void Catch_All_00940c6a(void)

{
  int unaff_EBP;
  
  FUN_00949db0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16950 ; VA 0x00940c80 ; FUN_00940c80 */

void __thiscall
FUN_00940c80(undefined4 *param_1,undefined4 *param_2,char param_3,int param_4,int param_5)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  int *piVar5;
  bool bVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca3e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piVar3 = (int *)*param_1;
  bVar6 = true;
  piVar5 = piVar3;
  if (*(char *)(piVar3[1] + 0xd) == '\0') {
    piVar3 = (int *)piVar3[1];
    do {
      piVar5 = piVar3;
      if (param_3 == '\0') {
        bVar6 = *(uint *)(param_4 + 4) < (uint)piVar5[5];
      }
      else {
        bVar6 = *(uint *)(param_4 + 4) <= (uint)piVar5[5];
      }
      if (bVar6 == false) {
        piVar3 = (int *)piVar5[2];
      }
      else {
        piVar3 = (int *)*piVar5;
      }
    } while (*(char *)((int)piVar3 + 0xd) == '\0');
    piVar3 = (int *)*param_1;
  }
  ExceptionList = &pvStack_10;
  _param_3 = piVar5;
  if (bVar6) {
    if (piVar5 == (int *)*piVar3) {
      bVar6 = true;
      ExceptionList = &pvStack_10;
      goto LAB_00940d08;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  iVar2 = param_5;
  piVar3 = _param_3;
  if (*(uint *)(param_4 + 4) <= (uint)_param_3[5]) {
    piVar5 = *(int **)(param_5 + 0x14);
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar1 = piVar5[2] + -1;
      piVar5[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
    FUN_01674ea0(iVar2,0x18);
    *param_2 = piVar3;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return;
  }
LAB_00940d08:
  puVar4 = (undefined4 *)FUN_009403d0(&param_3,bVar6,piVar5,param_4,param_5);
  *param_2 = *puVar4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16951 ; VA 0x00940d91 ; Catch_All@00940d91 */

void Catch_All_00940d91(void)

{
  int unaff_EBP;
  
  FUN_00949dd0(*(undefined4 *)(unaff_EBP + 0x14));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16952 ; VA 0x00940db0 ; FUN_00940db0 */

undefined4 * __thiscall
FUN_00940db0(undefined4 *param_1,undefined4 *param_2,char param_3,int param_4,undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  bool bVar5;
  int *piVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  iVar2 = param_4;
  puStack_c = &LAB_017ca3f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  bVar5 = true;
  piVar1 = (int *)*param_1;
  piVar6 = piVar1;
  if (*(char *)(piVar1[1] + 0xd) == '\0') {
    piVar3 = (int *)piVar1[1];
    do {
      piVar6 = piVar3;
      if (param_3 == '\0') {
        bVar5 = *(uint *)(param_4 + 4) < (uint)piVar6[5];
      }
      else {
        bVar5 = *(uint *)(param_4 + 4) <= (uint)piVar6[5];
      }
      if (bVar5 == false) {
        piVar3 = (int *)piVar6[2];
      }
      else {
        piVar3 = (int *)*piVar6;
      }
    } while (*(char *)((int)piVar3 + 0xd) == '\0');
  }
  ExceptionList = &pvStack_10;
  _param_3 = piVar6;
  if (bVar5 != false) {
    if (piVar6 == (int *)*piVar1) {
      bVar5 = true;
      ExceptionList = &pvStack_10;
      goto LAB_00940e42;
    }
    ExceptionList = &pvStack_10;
    FUN_0056f560();
  }
  if (*(uint *)(iVar2 + 4) <= (uint)_param_3[5]) {
    *param_2 = _param_3;
    *(undefined *)(param_2 + 1) = 0;
    ExceptionList = pvStack_10;
    return param_2;
  }
LAB_00940e42:
  puVar4 = (undefined4 *)FUN_00940530(&param_3,bVar5,piVar6,iVar2,param_5);
  *param_2 = *puVar4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16953 ; VA 0x00940ea6 ; Catch_All@00940ea6 */

void Catch_All_00940ea6(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16954 ; VA 0x00940eb0 ; FUN_00940eb0 */

undefined4 * __thiscall
FUN_00940eb0(undefined4 *param_1,undefined4 *param_2,char param_3,int param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *puVar4;
  int *piVar5;
  int *piVar6;
  bool bVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca400;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  bVar7 = true;
  piVar2 = (int *)*param_1;
  piVar6 = piVar2;
  if (*(char *)(piVar2[1] + 0xd) == '\0') {
    piVar5 = (int *)piVar2[1];
    do {
      piVar6 = piVar5;
      if (param_3 == '\0') {
        bVar7 = *(uint *)(param_4 + 4) < (uint)piVar6[5];
      }
      else {
        bVar7 = *(uint *)(param_4 + 4) <= (uint)piVar6[5];
      }
      if (bVar7 == false) {
        piVar5 = (int *)piVar6[2];
      }
      else {
        piVar5 = (int *)*piVar6;
      }
    } while (*(char *)((int)piVar5 + 0xd) == '\0');
  }
  piVar5 = piVar6;
  if (bVar7 != false) {
    if (piVar6 == (int *)*piVar2) {
      bVar7 = true;
      goto LAB_00940f3a;
    }
    if (*(char *)((int)piVar6 + 0xd) == '\0') {
      piVar5 = (int *)*piVar6;
      if (*(char *)((int)piVar5 + 0xd) == '\0') {
        cVar1 = *(char *)(piVar5[2] + 0xd);
        piVar2 = (int *)piVar5[2];
        while (cVar1 == '\0') {
          cVar1 = *(char *)(piVar2[2] + 0xd);
          piVar5 = piVar2;
          piVar2 = (int *)piVar2[2];
        }
      }
      else {
        cVar1 = *(char *)(piVar6[1] + 0xd);
        piVar2 = (int *)piVar6[1];
        piVar5 = piVar6;
        while ((piVar3 = piVar2, cVar1 == '\0' && (piVar5 == (int *)*piVar3))) {
          cVar1 = *(char *)(piVar3[1] + 0xd);
          piVar2 = (int *)piVar3[1];
          piVar5 = piVar3;
        }
        if (*(char *)((int)piVar5 + 0xd) == '\0') {
          piVar5 = piVar3;
        }
      }
    }
    else {
      piVar5 = (int *)piVar6[2];
    }
  }
  if (*(uint *)(param_4 + 4) <= (uint)piVar5[5]) {
    *param_2 = piVar5;
    *(undefined *)(param_2 + 1) = 0;
    return param_2;
  }
LAB_00940f3a:
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_00940530(&param_3,bVar7,piVar6,param_4,param_5);
  *param_2 = *puVar4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16955 ; VA 0x00940ff1 ; Catch_All@00940ff1 */

void Catch_All_00940ff1(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16956 ; VA 0x00941000 ; FUN_00941000 */

void __thiscall FUN_00941000(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca410;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<struct_RobloxExtraSpace::Shared>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16957 ; VA 0x0094106e ; Catch_All@0094106e */

void Catch_All_0094106e(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00949770(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16958 ; VA 0x00941090 ; FUN_00941090 */

int __thiscall FUN_00941090(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca420;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::_Ref_count<class_RBX::PluginManagerInterface>::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16959 ; VA 0x00941164 ; Catch_All@00941164 */

void Catch_All_00941164(void)

{
  int unaff_EBP;
  
  if (*(undefined4 **)(unaff_EBP + 8) != (undefined4 *)0x0) {
    (**(code **)**(undefined4 **)(unaff_EBP + 8))(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16960 ; VA 0x00941180 ; FUN_00941180 */

void __thiscall FUN_00941180(undefined4 *param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca430;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  puVar1 = (undefined4 *)FUN_01674e20(0x10);
  if (puVar1 == (undefined4 *)0x0) {
    puVar1 = (undefined4 *)0x0;
  }
  else {
    puVar1[1] = 1;
    puVar1[2] = 1;
    *puVar1 = std::_Ref_count<class_RBX::ScriptStats>::vftable;
    puVar1[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = puVar1;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16961 ; VA 0x009411ee ; Catch_All@009411ee */

void Catch_All_009411ee(void)

{
  int unaff_EBP;
  
  if (*(int *)(unaff_EBP + 8) != 0) {
    FUN_00949740(1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16962 ; VA 0x00941210 ; FUN_00941210 */

int __thiscall FUN_00941210(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca440;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::CoreScript*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16963 ; VA 0x009412e2 ; Catch_All@009412e2 */

void Catch_All_009412e2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16964 ; VA 0x00941300 ; FUN_00941300 */

int __thiscall FUN_00941300(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca450;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::LuaSettings*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16965 ; VA 0x009413d2 ; Catch_All@009413d2 */

void Catch_All_009413d2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16966 ; VA 0x009413f0 ; FUN_009413f0 */

int __thiscall FUN_009413f0(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca460;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::ModelInstance*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 16967 ; VA 0x009414c2 ; Catch_All@009414c2 */

void Catch_All_009414c2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16968 ; VA 0x009414e0 ; FUN_009414e0 */

undefined4 * FUN_009414e0(int *param_1,int *param_2,undefined4 *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  if (param_1 != param_2) {
    iVar3 = (int)param_3 - (int)param_1;
    piVar2 = param_1 + 2;
    do {
      piVar1 = (int *)piVar2[-2];
      *param_3 = piVar1;
      if (piVar1 != (int *)0x0) {
        LOCK();
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      param_3[1] = 0;
      *(undefined4 *)(iVar3 + (int)piVar2) = 0;
      if (*piVar2 != 0) {
        LOCK();
        piVar1 = (int *)(*piVar2 + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      param_3[1] = piVar2[-1];
      param_3 = param_3 + 3;
      *(int *)(iVar3 + (int)piVar2) = *piVar2;
      piVar1 = piVar2 + 1;
      piVar2 = piVar2 + 3;
    } while (piVar1 != param_2);
  }
  return param_3;
}



/* FUNCTION 16969 ; VA 0x00941550 ; FUN_00941550 */

undefined4 * FUN_00941550(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  
  puVar8 = param_3;
  if (param_1 != param_2) {
    puVar6 = param_1 + 0xd;
    puVar7 = param_3 + 0xe;
    do {
      puVar7[-10] = 0;
      puVar1 = puVar6 + 0x14;
      puVar7[-9] = 0;
      uVar3 = puVar6[-0xc];
      uVar4 = puVar6[-0xb];
      uVar5 = puVar6[-10];
      *puVar8 = puVar6[-0xd];
      puVar8[1] = uVar3;
      puVar8[2] = uVar4;
      puVar8[3] = uVar5;
      *(undefined8 *)(puVar8 + 4) = *(undefined8 *)(puVar6 + -9);
      puVar8 = puVar8 + 0x14;
      puVar6[-9] = 0;
      puVar6[-8] = 0xf;
      *(undefined *)(puVar6 + -0xd) = 0;
      puVar7[-4] = 0;
      puVar7[-3] = 0;
      uVar3 = puVar6[-6];
      uVar4 = puVar6[-5];
      uVar5 = puVar6[-4];
      puVar7[-8] = puVar6[-7];
      puVar7[-7] = uVar3;
      puVar7[-6] = uVar4;
      puVar7[-5] = uVar5;
      *(undefined8 *)(puVar7 + -4) = *(undefined8 *)(puVar6 + -3);
      puVar6[-3] = 0;
      puVar6[-2] = 0xf;
      *(undefined *)(puVar6 + -7) = 0;
      puVar7[-2] = 0;
      *(undefined4 *)((int)param_3 + (-0x50 - (int)param_1) + (int)puVar1) = 0;
      *puVar7 = 0;
      puVar7[-2] = puVar6[-1];
      *(undefined4 *)((int)param_3 + (-0x50 - (int)param_1) + (int)puVar1) = *puVar6;
      *puVar7 = puVar6[1];
      puVar6[-1] = 0;
      *puVar6 = 0;
      puVar6[1] = 0;
      *(undefined8 *)(puVar7 + 2) = *(undefined8 *)(puVar6 + 3);
      puVar7[4] = puVar6[5];
      puVar2 = puVar6 + 7;
      puVar6 = puVar1;
      puVar7 = puVar7 + 0x14;
    } while (puVar2 != param_2);
  }
  return puVar8;
}



/* FUNCTION 16970 ; VA 0x00941650 ; FUN_00941650 */

undefined FUN_00941650(undefined4 param_1)

{
  undefined4 uVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined uVar4;
  uint in_stack_00000034;
  int *in_stack_00000054;
  undefined auStack_ac [40];
  uint uStack_84;
  undefined auStack_7c [24];
  undefined4 auStack_64 [2];
  undefined auStack_5c [40];
  uint uStack_34;
  undefined auStack_2c [24];
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca49a;
  pvStack_10 = ExceptionList;
  auStack_64[0] = param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00944b60(&stack0x0000000c);
  uStack_8._0_1_ = 1;
  cVar2 = FUN_00585a40(auStack_64);
  uVar1 = auStack_64[0];
  if (cVar2 == '\0') {
    FUN_00944b60(auStack_5c);
    uStack_8._0_1_ = 2;
    puVar3 = (undefined4 *)FUN_01674e20(0x50);
    uStack_8._0_1_ = 3;
    puStack_14 = puVar3;
    if (puVar3 == (undefined4 *)0x0) {
      puVar3 = (undefined4 *)0x0;
    }
    else {
      *puVar3 = uVar1;
      FUN_00944b60(auStack_ac);
    }
    *in_stack_00000054 = (int)puVar3;
    uStack_8._0_1_ = 4;
    if (uStack_84 != 0) {
      if (((uStack_84 & 1) == 0) && (*(code **)(uStack_84 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_84 & 0xfffffffe))(auStack_7c,auStack_7c,2);
      }
      uStack_84 = 0;
    }
    FUN_00946a50();
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_00946a50();
    uVar4 = 1;
  }
  else {
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (uStack_34 != 0) {
      if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
        (**(code **)(uStack_34 & 0xfffffffe))(auStack_2c,auStack_2c,2);
      }
      uStack_34 = 0;
    }
    FUN_00946a50();
    uVar4 = 0;
  }
  uStack_8 = 7;
  if (in_stack_00000034 != 0) {
    if (((in_stack_00000034 & 1) == 0) &&
       (*(code **)(in_stack_00000034 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_00000034 & 0xfffffffe))(&stack0x0000003c,&stack0x0000003c,2);
    }
    in_stack_00000034 = 0;
  }
  FUN_00946a50();
  ExceptionList = pvStack_10;
  return uVar4;
}



/* FUNCTION 16971 ; VA 0x009417e0 ; FUN_009417e0 */

undefined FUN_009417e0(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined8 param_9,int *param_10)

{
  undefined4 uVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca4cf;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00585a40(&param_1);
  uVar1 = param_1;
  if (cVar2 == '\0') {
    uStack_34 = 0;
    if (param_3 != 0) {
      uStack_34 = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_2c,0);
      }
      else {
        uStack_2c = param_5;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
      }
    }
    uStack_8._0_1_ = 1;
    puVar4 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 2;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[2] = 0;
      if (uStack_34 != 0) {
        puVar4[2] = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,puVar4 + 4,0);
        }
        else {
          puVar4[4] = uStack_2c;
          puVar4[5] = uStack_28;
          puVar4[6] = uStack_24;
          puVar4[7] = uStack_20;
          *(undefined8 *)(puVar4 + 8) = uStack_1c;
        }
      }
    }
    *param_10 = (int)puVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
       (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  uStack_8 = 4;
  param_10._3_1_ = uVar3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_10._3_1_;
}



/* FUNCTION 16972 ; VA 0x00941940 ; FUN_00941940 */

undefined FUN_00941940(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined8 param_9,int *param_10)

{
  undefined4 uVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca4ff;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00585a40(&param_1);
  uVar1 = param_1;
  if (cVar2 == '\0') {
    uStack_34 = 0;
    if (param_3 != 0) {
      uStack_34 = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_2c,0);
      }
      else {
        uStack_2c = param_5;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
      }
    }
    uStack_8._0_1_ = 1;
    puVar4 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 2;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[2] = 0;
      if (uStack_34 != 0) {
        puVar4[2] = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,puVar4 + 4,0);
        }
        else {
          puVar4[4] = uStack_2c;
          puVar4[5] = uStack_28;
          puVar4[6] = uStack_24;
          puVar4[7] = uStack_20;
          *(undefined8 *)(puVar4 + 8) = uStack_1c;
        }
      }
    }
    *param_10 = (int)puVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
       (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  uStack_8 = 4;
  param_10._3_1_ = uVar3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_10._3_1_;
}



/* FUNCTION 16973 ; VA 0x00941aa0 ; FUN_00941aa0 */

undefined FUN_00941aa0(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined8 param_9,int *param_10)

{
  undefined4 uVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca52f;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00585a40(&param_1);
  uVar1 = param_1;
  if (cVar2 == '\0') {
    uStack_34 = 0;
    if (param_3 != 0) {
      uStack_34 = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_2c,0);
      }
      else {
        uStack_2c = param_5;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
      }
    }
    uStack_8._0_1_ = 1;
    puVar4 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 2;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[2] = 0;
      if (uStack_34 != 0) {
        puVar4[2] = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,puVar4 + 4,0);
        }
        else {
          puVar4[4] = uStack_2c;
          puVar4[5] = uStack_28;
          puVar4[6] = uStack_24;
          puVar4[7] = uStack_20;
          *(undefined8 *)(puVar4 + 8) = uStack_1c;
        }
      }
    }
    *param_10 = (int)puVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
       (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  uStack_8 = 4;
  param_10._3_1_ = uVar3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_10._3_1_;
}



/* FUNCTION 16974 ; VA 0x00941c00 ; FUN_00941c00 */

undefined FUN_00941c00(undefined4 param_1,undefined4 param_2,uint param_3,undefined4 param_4,
                      undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                      undefined8 param_9,int *param_10)

{
  undefined4 uVar1;
  char cVar2;
  undefined uVar3;
  undefined4 *puVar4;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca55f;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar2 = FUN_00585a40(&param_1);
  uVar1 = param_1;
  if (cVar2 == '\0') {
    uStack_34 = 0;
    if (param_3 != 0) {
      uStack_34 = param_3;
      if ((param_3 & 1) == 0) {
        (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_2c,0);
      }
      else {
        uStack_2c = param_5;
        uStack_28 = param_6;
        uStack_24 = param_7;
        uStack_20 = param_8;
        uStack_1c = param_9;
      }
    }
    uStack_8._0_1_ = 1;
    puVar4 = (undefined4 *)FUN_01674e20(0x28);
    uStack_8._0_1_ = 2;
    puStack_14 = puVar4;
    if (puVar4 == (undefined4 *)0x0) {
      puVar4 = (undefined4 *)0x0;
    }
    else {
      *puVar4 = uVar1;
      puVar4[2] = 0;
      if (uStack_34 != 0) {
        puVar4[2] = uStack_34;
        if ((uStack_34 & 1) == 0) {
          (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,puVar4 + 4,0);
        }
        else {
          puVar4[4] = uStack_2c;
          puVar4[5] = uStack_28;
          puVar4[6] = uStack_24;
          puVar4[7] = uStack_20;
          *(undefined8 *)(puVar4 + 8) = uStack_1c;
        }
      }
    }
    *param_10 = (int)puVar4;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
       (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uVar3 = 1;
  }
  else {
    uVar3 = 0;
  }
  uStack_8 = 4;
  param_10._3_1_ = uVar3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_3 & 0xfffffffe))(&param_5,&param_5,2);
  }
  ExceptionList = pvStack_10;
  return param_10._3_1_;
}



/* FUNCTION 16975 ; VA 0x00941d60 ; FUN_00941d60 */

undefined FUN_00941d60(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 param_4,
                      undefined4 *param_5)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  char cVar4;
  undefined uVar5;
  undefined4 uStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_14 = param_1;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_10 = param_2;
  piStack_c = param_3;
  uStack_8 = param_4;
  cVar4 = FUN_00585a40(&uStack_14);
  piVar2 = piStack_c;
  if (cVar4 == '\0') {
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[1] = piStack_c[1] + 1;
      UNLOCK();
    }
    *param_5 = uStack_14;
    param_5[1] = 0;
    param_5[2] = 0;
    if (piStack_c != (int *)0x0) {
      LOCK();
      piStack_c[1] = piStack_c[1] + 1;
      UNLOCK();
    }
    param_5[1] = uStack_10;
    param_5[2] = piStack_c;
    param_5[3] = uStack_8;
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = piStack_c;
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        piVar1 = piVar2 + 2;
        iVar3 = *piVar1 + -1;
        *piVar1 = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar5 = 1;
  }
  else {
    if (piStack_c != (int *)0x0) {
      LOCK();
      iVar3 = piStack_c[1] + -1;
      piStack_c[1] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)*piStack_c)();
        LOCK();
        iVar3 = piVar2[2] + -1;
        piVar2[2] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    uVar5 = 0;
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar3 = param_3[1] + -1;
    param_3[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  return uVar5;
}



/* FUNCTION 16976 ; VA 0x00941e90 ; FUN_00941e90 */

undefined4 *
FUN_00941e90(undefined4 *param_1,undefined4 param_2,int *param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,
            undefined8 param_10)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 *puStack_50;
  undefined8 uStack_4c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca588;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    if ((param_4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_5c,0);
    }
    else {
      uStack_5c = param_6;
      uStack_58 = param_7;
      uStack_54 = param_8;
      puStack_50 = (undefined4 *)param_9;
      uStack_4c = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    *param_3 = *param_3 + 1;
    UNLOCK();
  }
  uVar2 = FUN_009449a0(param_3);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  *param_1 = param_2;
  uStack_4c = CONCAT44(uVar2,0x941f2a);
  FUN_00944900();
  uStack_4c = CONCAT44(0x941f32,(undefined4)uStack_4c);
  FUN_00946a50();
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = *param_3;
    *param_3 = *param_3 + -1;
    UNLOCK();
    if ((iVar1 == 1) && (param_3 != (int *)0x0)) {
      uStack_4c = CONCAT44(0x941f50,(undefined4)uStack_4c);
      FUN_00d88950();
      uStack_4c = CONCAT44(0x10,param_3);
      puStack_50 = (undefined4 *)0x941f58;
      FUN_01674ea0();
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  uStack_8 = 3;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_50 = &param_6;
    uStack_4c = CONCAT44(2,puStack_50);
    uStack_54 = 0x941f86;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16977 ; VA 0x00941fa0 ; FUN_00941fa0 */

undefined4 *
FUN_00941fa0(undefined4 *param_1,undefined4 param_2,int *param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 *param_9,
            ulonglong param_10,uint param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined *param_16,undefined8 param_17)

{
  int iVar1;
  uint *puVar2;
  undefined4 uVar3;
  uint auStack_a8 [2];
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 *puStack_94;
  ulonglong uStack_90;
  uint auStack_88 [2];
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 *puStack_74;
  undefined8 uStack_70;
  uint uStack_38;
  undefined auStack_30 [24];
  undefined *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca5c8;
  pvStack_10 = ExceptionList;
  puStack_14 = (undefined *)auStack_88;
  puStack_18 = (undefined *)auStack_88;
  uStack_8 = 2;
  auStack_88[0] = 0;
  ExceptionList = &pvStack_10;
  puVar2 = auStack_88;
  if (param_11 != 0) {
    auStack_88[0] = param_11;
    if ((param_11 & 1) == 0) {
      uStack_90 = ZEXT48(&uStack_80);
      puStack_94 = &param_13;
      uStack_98 = 0x942008;
      ExceptionList = &pvStack_10;
      (**(code **)(param_11 & 0xfffffffe))();
      puVar2 = (uint *)puStack_14;
    }
    else {
      uStack_80 = param_13;
      uStack_7c = param_14;
      uStack_78 = param_15;
      puStack_74 = (undefined4 *)param_16;
      uStack_70 = param_17;
      ExceptionList = &pvStack_10;
      puVar2 = auStack_88;
    }
  }
  puStack_14 = (undefined *)puVar2;
  puStack_18 = (undefined *)auStack_a8;
  uStack_8._0_1_ = 3;
  auStack_a8[0] = 0;
  puVar2 = auStack_a8;
  if (param_4 != 0) {
    auStack_a8[0] = param_4;
    if ((param_4 & 1) == 0) {
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_a0,0);
      puVar2 = (uint *)puStack_18;
    }
    else {
      uStack_a0 = param_6;
      uStack_9c = param_7;
      uStack_98 = param_8;
      puStack_94 = param_9;
      uStack_90 = param_10;
      puVar2 = auStack_a8;
    }
  }
  puStack_18 = (undefined *)puVar2;
  if (param_3 != (int *)0x0) {
    LOCK();
    *param_3 = *param_3 + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 2;
  uVar3 = FUN_00944c50(param_3);
  uStack_8._0_1_ = 4;
  *param_1 = param_2;
  uStack_70 = CONCAT44(uVar3,0x942089);
  FUN_00944b60();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (((uStack_38 != 0) && ((uStack_38 & 1) == 0)) &&
     (*(code **)(uStack_38 & 0xfffffffe) != (code *)0x0)) {
    puStack_74 = (undefined4 *)auStack_30;
    uStack_70 = CONCAT44(2,puStack_74);
    uStack_78 = 0x9420aa;
    (**(code **)(uStack_38 & 0xfffffffe))();
  }
  uStack_70 = CONCAT44(0x9420bc,(undefined4)uStack_70);
  FUN_00946a50();
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar1 = *param_3;
    *param_3 = *param_3 + -1;
    UNLOCK();
    if ((iVar1 == 1) && (param_3 != (int *)0x0)) {
      uStack_70 = CONCAT44(0x9420da,(undefined4)uStack_70);
      FUN_00d88950();
      uStack_70 = CONCAT44(0x10,param_3);
      puStack_74 = (undefined4 *)0x9420e2;
      FUN_01674ea0();
    }
  }
  LOCK();
  DAT_01e90cd4 = DAT_01e90cd4 + -1;
  UNLOCK();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    puStack_74 = &param_6;
    uStack_70 = CONCAT44(2,puStack_74);
    uStack_78 = 0x94210d;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 7;
  if (((param_11 != 0) && ((param_11 & 1) == 0)) &&
     (*(code **)(param_11 & 0xfffffffe) != (code *)0x0)) {
    puStack_74 = &param_13;
    uStack_70 = CONCAT44(2,puStack_74);
    uStack_78 = 0x94213b;
    (**(code **)(param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16978 ; VA 0x00942150 ; FUN_00942150 */

undefined4 *
FUN_00942150(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10)

{
  uint uStack_74;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined8 uStack_5c;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca600;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    uStack_34 = param_4;
    if ((param_4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_2c,0);
    }
    else {
      uStack_2c = param_6;
      uStack_28 = param_7;
      uStack_24 = param_8;
      uStack_20 = param_9;
      uStack_1c = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 1;
  uStack_74 = 0;
  if (uStack_34 != 0) {
    uStack_74 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_6c,0);
    }
    else {
      uStack_6c = uStack_2c;
      uStack_68 = uStack_28;
      uStack_64 = uStack_24;
      uStack_60 = uStack_20;
      uStack_5c = uStack_1c;
    }
  }
  uStack_8._0_1_ = 2;
  uStack_54 = 0;
  if (uStack_74 != 0) {
    uStack_54 = uStack_74;
    if ((uStack_74 & 1) == 0) {
      (**(code **)(uStack_74 & 0xfffffffe))(&uStack_6c,&uStack_4c,0);
    }
    else {
      uStack_4c = uStack_6c;
      uStack_48 = uStack_68;
      uStack_44 = uStack_64;
      uStack_40 = uStack_60;
      uStack_3c = uStack_5c;
    }
  }
  uStack_8._0_1_ = 3;
  if (((uStack_74 != 0) && ((uStack_74 & 1) == 0)) &&
     (*(code **)(uStack_74 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_74 & 0xfffffffe))(&uStack_6c,&uStack_6c,2);
  }
  uStack_8._0_1_ = 4;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uStack_34 = 0;
  }
  uStack_8._0_1_ = 5;
  *param_1 = param_2;
  param_1[2] = 0;
  if (uStack_54 != 0) {
    param_1[2] = uStack_54;
    if ((uStack_54 & 1) == 0) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,param_1 + 4,0);
    }
    else {
      param_1[4] = uStack_4c;
      param_1[5] = uStack_48;
      param_1[6] = uStack_44;
      param_1[7] = uStack_40;
      *(undefined8 *)(param_1 + 8) = uStack_3c;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (uStack_54 != 0) {
    if (((uStack_54 & 1) == 0) && (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_4c,2);
    }
    uStack_54 = 0;
  }
  uStack_8 = 7;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_4 & 0xfffffffe))(&param_6,&param_6,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16979 ; VA 0x00942360 ; FUN_00942360 */

undefined4 *
FUN_00942360(undefined4 *param_1,undefined4 param_2,undefined4 param_3,uint param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined8 param_10)

{
  uint uStack_74;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined8 uStack_5c;
  uint uStack_54;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca630;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_34 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != 0) {
    uStack_34 = param_4;
    if ((param_4 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_2c,0);
    }
    else {
      uStack_2c = param_6;
      uStack_28 = param_7;
      uStack_24 = param_8;
      uStack_20 = param_9;
      uStack_1c = param_10;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 1;
  uStack_74 = 0;
  if (uStack_34 != 0) {
    uStack_74 = uStack_34;
    if ((uStack_34 & 1) == 0) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_6c,0);
    }
    else {
      uStack_6c = uStack_2c;
      uStack_68 = uStack_28;
      uStack_64 = uStack_24;
      uStack_60 = uStack_20;
      uStack_5c = uStack_1c;
    }
  }
  uStack_8._0_1_ = 2;
  uStack_54 = 0;
  if (uStack_74 != 0) {
    uStack_54 = uStack_74;
    if ((uStack_74 & 1) == 0) {
      (**(code **)(uStack_74 & 0xfffffffe))(&uStack_6c,&uStack_4c,0);
    }
    else {
      uStack_4c = uStack_6c;
      uStack_48 = uStack_68;
      uStack_44 = uStack_64;
      uStack_40 = uStack_60;
      uStack_3c = uStack_5c;
    }
  }
  uStack_8._0_1_ = 3;
  if (((uStack_74 != 0) && ((uStack_74 & 1) == 0)) &&
     (*(code **)(uStack_74 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_74 & 0xfffffffe))(&uStack_6c,&uStack_6c,2);
  }
  uStack_8._0_1_ = 4;
  if (uStack_34 != 0) {
    if (((uStack_34 & 1) == 0) && (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
    }
    uStack_34 = 0;
  }
  uStack_8._0_1_ = 5;
  *param_1 = param_2;
  param_1[2] = 0;
  if (uStack_54 != 0) {
    param_1[2] = uStack_54;
    if ((uStack_54 & 1) == 0) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,param_1 + 4,0);
    }
    else {
      param_1[4] = uStack_4c;
      param_1[5] = uStack_48;
      param_1[6] = uStack_44;
      param_1[7] = uStack_40;
      *(undefined8 *)(param_1 + 8) = uStack_3c;
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (uStack_54 != 0) {
    if (((uStack_54 & 1) == 0) && (*(code **)(uStack_54 & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(uStack_54 & 0xfffffffe))(&uStack_4c,&uStack_4c,2);
    }
    uStack_54 = 0;
  }
  uStack_8 = 7;
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_4 & 0xfffffffe))(&param_6,&param_6,2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16980 ; VA 0x00942570 ; FUN_00942570 */

undefined4 *
FUN_00942570(undefined4 *param_1,undefined4 param_2,uint param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined8 param_9,undefined4 param_10)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint *puVar4;
  uint auStack_5c [2];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca650;
  pvStack_10 = ExceptionList;
  uStack_3c = param_10;
  uStack_8 = 0;
  puStack_14 = (undefined *)auStack_5c;
  auStack_5c[0] = 0;
  ExceptionList = &pvStack_10;
  puVar4 = auStack_5c;
  if (param_3 != 0) {
    auStack_5c[0] = param_3;
    if ((param_3 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_54,0);
      puVar4 = (uint *)puStack_14;
    }
    else {
      uStack_54 = param_5;
      uStack_50 = param_6;
      uStack_4c = param_7;
      uStack_48 = param_8;
      uStack_44 = param_9;
      ExceptionList = &pvStack_10;
      puVar4 = auStack_5c;
    }
  }
  puStack_14 = (undefined *)puVar4;
  puVar4 = (uint *)FUN_009445c0();
  uStack_8._0_1_ = 1;
  *param_1 = param_2;
  param_1[2] = 0;
  uVar1 = *puVar4;
  if (uVar1 != 0) {
    param_1[2] = uVar1;
    if ((uVar1 & 1) == 0) {
      uStack_3c = 0;
      uStack_44 = CONCAT44(param_1 + 4,puVar4 + 2);
      uStack_48 = 0x94262a;
      (**(code **)(uVar1 & 0xfffffffe))();
    }
    else {
      uVar1 = puVar4[3];
      uVar2 = puVar4[4];
      uVar3 = puVar4[5];
      param_1[4] = puVar4[2];
      param_1[5] = uVar1;
      param_1[6] = uVar2;
      param_1[7] = uVar3;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(puVar4 + 6);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
     (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
    uStack_3c = 2;
    uStack_44 = CONCAT44(auStack_2c,auStack_2c);
    uStack_48 = 0x94264e;
    (**(code **)(uStack_34 & 0xfffffffe))();
  }
  uStack_8 = 3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    uStack_3c = 2;
    uStack_44 = CONCAT44(&param_5,&param_5);
    uStack_48 = 0x94267c;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16981 ; VA 0x00942690 ; FUN_00942690 */

undefined4 *
FUN_00942690(undefined4 *param_1,undefined4 param_2,uint param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined8 param_9,undefined4 param_10)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint *puVar4;
  uint auStack_5c [2];
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_3c;
  uint uStack_34;
  undefined auStack_2c [24];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca670;
  pvStack_10 = ExceptionList;
  uStack_3c = param_10;
  uStack_8 = 0;
  puStack_14 = (undefined *)auStack_5c;
  auStack_5c[0] = 0;
  ExceptionList = &pvStack_10;
  puVar4 = auStack_5c;
  if (param_3 != 0) {
    auStack_5c[0] = param_3;
    if ((param_3 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_3 & 0xfffffffe))(&param_5,&uStack_54,0);
      puVar4 = (uint *)puStack_14;
    }
    else {
      uStack_54 = param_5;
      uStack_50 = param_6;
      uStack_4c = param_7;
      uStack_48 = param_8;
      uStack_44 = param_9;
      ExceptionList = &pvStack_10;
      puVar4 = auStack_5c;
    }
  }
  puStack_14 = (undefined *)puVar4;
  puVar4 = (uint *)FUN_00944760();
  uStack_8._0_1_ = 1;
  *param_1 = param_2;
  param_1[2] = 0;
  uVar1 = *puVar4;
  if (uVar1 != 0) {
    param_1[2] = uVar1;
    if ((uVar1 & 1) == 0) {
      uStack_3c = 0;
      uStack_44 = CONCAT44(param_1 + 4,puVar4 + 2);
      uStack_48 = 0x94274a;
      (**(code **)(uVar1 & 0xfffffffe))();
    }
    else {
      uVar1 = puVar4[3];
      uVar2 = puVar4[4];
      uVar3 = puVar4[5];
      param_1[4] = puVar4[2];
      param_1[5] = uVar1;
      param_1[6] = uVar2;
      param_1[7] = uVar3;
      *(undefined8 *)(param_1 + 8) = *(undefined8 *)(puVar4 + 6);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
     (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
    uStack_3c = 2;
    uStack_44 = CONCAT44(auStack_2c,auStack_2c);
    uStack_48 = 0x94276e;
    (**(code **)(uStack_34 & 0xfffffffe))();
  }
  uStack_8 = 3;
  if (((param_3 != 0) && ((param_3 & 1) == 0)) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0))
  {
    uStack_3c = 2;
    uStack_44 = CONCAT44(&param_5,&param_5);
    uStack_48 = 0x94279c;
    (**(code **)(param_3 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16982 ; VA 0x009427b0 ; FUN_009427b0 */

undefined4 *
FUN_009427b0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,int *param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
            ,undefined4 param_10,undefined4 param_11,undefined8 param_12,undefined4 param_13,
            undefined4 param_14,undefined4 param_15,undefined4 param_16)

{
  int *piVar1;
  int iVar2;
  undefined auStack_4c [72];
  
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    param_6[1] = param_6[1] + 1;
    UNLOCK();
  }
  piVar1 = param_4 + 1;
  if (param_4 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_009453b0(param_3,param_4,param_5,param_6,param_7,param_8,param_9,param_10,param_11,param_12,
               param_13,param_14,param_15,param_16);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      iVar2 = param_6[2] + -1;
      param_6[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  *param_1 = param_2;
  FUN_00944dc0(auStack_4c);
  FUN_0056b650();
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_6 != (int *)0x0) {
    LOCK();
    iVar2 = param_6[1] + -1;
    param_6[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_6)();
      LOCK();
      piVar1 = param_6 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_6 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 16983 ; VA 0x00942910 ; FUN_00942910 */

undefined4 *
FUN_00942910(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_14;
  int *piStack_10;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  piVar1 = param_4 + 1;
  if (param_4 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00944e50(param_3,param_4,param_5);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (piStack_10 != (int *)0x0) {
    LOCK();
    piStack_10[1] = piStack_10[1] + 1;
    UNLOCK();
  }
  param_1[1] = uStack_14;
  param_1[2] = piStack_10;
  param_1[3] = param_6;
  if (piStack_10 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_10[1] + -1;
    piStack_10[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_10)();
      LOCK();
      iVar2 = piStack_10[2] + -1;
      piStack_10[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 16984 ; VA 0x00942a30 ; FUN_00942a30 */

undefined4 *
FUN_00942a30(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,
            undefined4 param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_c;
  int *piStack_8;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  piVar1 = param_4 + 1;
  if (param_4 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_00944e50(param_3,param_4,param_5);
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  *param_1 = param_2;
  param_1[1] = 0;
  param_1[2] = 0;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    piStack_8[1] = piStack_8[1] + 1;
    UNLOCK();
  }
  param_1[1] = uStack_c;
  param_1[2] = piStack_8;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_8[1] + -1;
    piStack_8[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      iVar2 = piStack_8[2] + -1;
      piStack_8[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 16985 ; VA 0x00942b20 ; FUN_00942b20 */

void FUN_00942b20(int *param_1,undefined4 *param_2)

{
  int iVar1;
  int iStack_6c;
  int iStack_68;
  char cStack_64;
  int iStack_60;
  char acStack_5c [72];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca688;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff88;
  iStack_6c = -0x3ea8cf1e;
  iStack_68 = 0x7f0725e3;
  cStack_64 = '\0';
  iStack_60 = 0;
  acStack_5c[0] = '\0';
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = iStack_60;
  do {
    iStack_60 = iVar1;
    if (*param_1 == iStack_6c) {
LAB_00942bf2:
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        CloseHandle(iStack_60);
      }
      ExceptionList = pvStack_10;
      return;
    }
    LOCK();
    iVar1 = *param_1;
    if (iVar1 == 0) {
      *param_1 = iStack_68;
      iVar1 = 0;
    }
    UNLOCK();
    if (iVar1 == 0) {
      if (iStack_60 == 0) {
        if (acStack_5c[0] == '\0') {
          FUN_005881c0(acStack_5c,param_1);
        }
        iVar1 = OpenEventA(0x100002,0,acStack_5c);
        if ((iStack_60 != 0) && (iStack_60 != -1)) {
          CloseHandle(iStack_60);
        }
        iStack_60 = iVar1;
        if (iVar1 != 0) goto LAB_00942bca;
      }
      else {
LAB_00942bca:
        ResetEvent(iStack_60);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      (*(code *)*param_2)(param_2[2],param_2[3]);
      FUN_0057b500(param_1,&iStack_6c);
      goto LAB_00942bf2;
    }
    if (cStack_64 == '\0') {
      LOCK();
      param_1[1] = param_1[1] + 1;
      UNLOCK();
      cStack_64 = '\x01';
      if (*param_1 == iStack_6c) goto LAB_00942bf2;
      if (iStack_60 != 0) goto LAB_00942c6c;
      if (acStack_5c[0] == '\0') {
        FUN_005881c0(acStack_5c,param_1);
      }
      iVar1 = CreateEventA(0,1,0,acStack_5c);
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        CloseHandle(iStack_60);
      }
    }
    else {
LAB_00942c6c:
      WaitForSingleObjectEx(iStack_60,0xffffffff,0);
      iVar1 = iStack_60;
    }
  } while( true );
}



/* FUNCTION 16986 ; VA 0x00942c7c ; Catch_All@00942c7c */

void Catch_All_00942c7c(void)

{
  int unaff_EBP;
  
  FUN_0058a8e0(*(undefined4 *)(unaff_EBP + 8),unaff_EBP + -0x68);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 16987 ; VA 0x00942ca0 ; FUN_00942ca0 */

void FUN_00942ca0(undefined4 param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca6b3;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_2 = 0;
  param_2[1] = 0;
  *param_2 = *param_3;
  param_2[1] = param_3[1];
  *param_3 = 0;
  param_3[1] = 0;
  param_2[6] = 0;
  param_2[7] = 0;
  uVar1 = param_3[3];
  uVar2 = param_3[4];
  uVar3 = param_3[5];
  param_2[2] = param_3[2];
  param_2[3] = uVar1;
  param_2[4] = uVar2;
  param_2[5] = uVar3;
  *(undefined8 *)(param_2 + 6) = *(undefined8 *)(param_3 + 6);
  param_3[6] = 0;
  param_3[7] = 0xf;
  *(undefined *)(param_3 + 2) = 0;
  uStack_8 = 1;
  FUN_00d88580(param_3 + 8);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 16988 ; VA 0x00942d40 ; FUN_00942d40 */

undefined4 * FUN_00942d40(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca6f3;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00a34610();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0xe4);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00a348d0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00941210(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16989 ; VA 0x00942e00 ; FUN_00942e00 */

undefined4 * FUN_00942e00(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca730;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00e44390();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x70);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00e44470();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00941300(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16990 ; VA 0x00942ec0 ; FUN_00942ec0 */

undefined4 * FUN_00942ec0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017ca773;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b63e30();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x14c);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00b64520(1);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_009413f0(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 16991 ; VA 0x00942f90 ; FUN_00942f90 */

void FUN_00942f90(undefined4 param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = *(int **)(param_2 + 0x24);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      iVar3 = piVar2[2] + -1;
      piVar2[2] = iVar3;
      UNLOCK();
      if (iVar3 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  piVar2 = *(int **)(param_2 + 0x1c);
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_00946e40();
  return;
}



/* FUNCTION 16992 ; VA 0x00943000 ; FUN_00943000 */

void __thiscall FUN_00943000(int param_1,undefined4 param_2)

{
  if (*(int *)(param_1 + 8) != *(int *)(param_1 + 4)) {
    FUN_00942ca0(param_1);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x40;
    return;
  }
  FUN_0093fbb0(*(int *)(param_1 + 4),param_2);
  return;
}



/* FUNCTION 16993 ; VA 0x00943040 ; FUN_00943040 */

undefined4 __thiscall FUN_00943040(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = (*(uint *)(param_1 + 0x18) &
          ((((*(byte *)(param_3 + 2) ^ 0x811c9dc5) * 0x1000193 ^ (uint)*(byte *)((int)param_3 + 9))
            * 0x1000193 ^ (uint)*(byte *)((int)param_3 + 10)) * 0x1000193 ^
          (uint)*(byte *)((int)param_3 + 0xb)) * 0x1000193) * 8;
  piVar2 = (int *)(*(int *)(param_1 + 0xc) + iVar1);
  if ((int *)piVar2[1] == param_3) {
    if ((int *)*piVar2 == param_3) {
      *piVar2 = *(int *)(param_1 + 4);
      *(undefined4 *)(iVar1 + 4 + *(int *)(param_1 + 0xc)) = *(undefined4 *)(param_1 + 4);
    }
    else {
      piVar2[1] = param_3[1];
    }
  }
  else if ((int *)*piVar2 == param_3) {
    *piVar2 = *param_3;
  }
  FUN_0094e5a0(param_2,param_3);
  return param_2;
}



/* FUNCTION 16994 ; VA 0x009430d0 ; FUN_009430d0 */

int * FUN_009430d0(int *param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if ((*param_2 == 0) ||
     (iVar7 = *(int *)(*param_2 + 0xc), iVar5 = FUN_00ae2430(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    piStack_c = (int *)0x0;
    puVar6 = &uStack_10;
    bVar3 = false;
    bVar2 = true;
    iVar7 = 0;
  }
  else {
    piStack_14 = (int *)param_2[1];
    iVar7 = *param_2;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)param_2[1];
    }
    puVar6 = &uStack_18;
    bVar3 = true;
    bVar2 = false;
  }
  iVar5 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar4 = piStack_c;
  param_1[1] = iVar5;
  *param_1 = iVar7;
  if ((bVar2) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_c[1] + -1;
    piStack_c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_14;
  if ((bVar3) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_14[1] + -1;
    piStack_14[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 16995 ; VA 0x009431c0 ; FUN_009431c0 */

int * FUN_009431c0(int *param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  bool bVar3;
  int *piVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uStack_18;
  int *piStack_14;
  undefined4 uStack_10;
  int *piStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0;
  if ((*param_2 == 0) ||
     (iVar7 = *(int *)(*param_2 + 0xc), iVar5 = FUN_009ec190(),
     (uint)*(ushort *)(iVar5 + 0x1da) <
     (uint)*(ushort *)(iVar7 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8))) {
    piStack_c = (int *)0x0;
    puVar6 = &uStack_10;
    bVar3 = false;
    bVar2 = true;
    iVar7 = 0;
  }
  else {
    piStack_14 = (int *)param_2[1];
    iVar7 = *param_2;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piStack_14[1] = piStack_14[1] + 1;
      UNLOCK();
      piStack_14 = (int *)param_2[1];
    }
    puVar6 = &uStack_18;
    bVar3 = true;
    bVar2 = false;
  }
  iVar5 = puVar6[1];
  *puVar6 = 0;
  puVar6[1] = 0;
  piVar4 = piStack_c;
  param_1[1] = iVar5;
  *param_1 = iVar7;
  if ((bVar2) && (piStack_c != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_c[1] + -1;
    piStack_c[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_c)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1 + -1;
      *piVar1 = iVar7;
      UNLOCK();
      if (iVar7 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_14;
  if ((bVar3) && (piStack_14 != (int *)0x0)) {
    LOCK();
    iVar7 = piStack_14[1] + -1;
    piStack_14[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 16996 ; VA 0x009432b0 ; FUN_009432b0 */

int __fastcall FUN_009432b0(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  iVar1 = *(int *)(param_1 + 0x34);
  piVar4 = (int *)(param_1 + 0x34);
  while( true ) {
    if (iVar1 == 0) {
      return 0;
    }
    iVar2 = *(int *)(iVar1 + 0xc);
    iVar3 = FUN_00e70750();
    if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) break;
    piVar4 = (int *)(*piVar4 + 0x34);
    iVar1 = *piVar4;
  }
  return iVar1;
}



/* FUNCTION 16997 ; VA 0x00943300 ; FUN_00943300 */

undefined4 __thiscall FUN_00943300(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088caa0();
  if (iVar1 != iVar2) {
    puVar4 = (undefined4 *)param_1[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_1 + 2,auStack_d8);
      puVar4 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    uVar5 = thunk_FUN_0088beb0();
    FUN_0088dd80(uVar5);
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar1 = *param_1;
  iVar2 = FUN_0088caa0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_0088dd80(piVar3);
    ExceptionList = pvStack_10;
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16998 ; VA 0x00943400 ; FUN_00943400 */

undefined4 __thiscall FUN_00943400(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00a8dcc0();
  if (iVar1 != iVar2) {
    puVar4 = (undefined4 *)param_1[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_1 + 2,auStack_d8);
      puVar4 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    uVar5 = thunk_FUN_00a8d930();
    FUN_00a8df50(uVar5);
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar1 = *param_1;
  iVar2 = FUN_00a8dcc0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_00a8df50(piVar3);
    ExceptionList = pvStack_10;
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 16999 ; VA 0x00943500 ; FUN_00943500 */

undefined4 __thiscall FUN_00943500(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00a92ae0();
  if (iVar1 != iVar2) {
    puVar4 = (undefined4 *)param_1[1];
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)*puVar4)(param_1 + 2,auStack_d8);
      puVar4 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    uVar7 = 0x64078678;
    uVar6 = 0xe4078678;
    uVar5 = thunk_FUN_00a92750(0xe4078678,0x64078678);
    FUN_00a92cb0(uVar5,uVar6,uVar7);
    uStack_8 = 1;
    if (puVar4 != (undefined4 *)0x0) {
      (*(code *)puVar4[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar1 = *param_1;
  iVar2 = FUN_00a92ae0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_00a92cb0(piVar3,0xe4078678,0x64078678);
    ExceptionList = pvStack_10;
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}


