/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 15750 ; VA 0x008f77b0 ; FUN_008f77b0 */

undefined4 * __thiscall FUN_008f77b0(int param_1,undefined4 *param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  uint *puStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01796168;
  pvStack_10 = ExceptionList;
  cStack_14 = '\0';
  puStack_18 = (uint *)(param_1 + 0x24);
  ExceptionList = &pvStack_10;
  FUN_00587410();
  uStack_8 = 0;
  FUN_0058cb00(&puStack_18,1);
  puVar2 = *(undefined4 **)(param_1 + 0x88);
  *param_2 = *puVar2;
  param_2[1] = puVar2[1];
  *puVar2 = 0;
  puVar2[1] = 0;
  uStack_8 = 1;
  if (cStack_14 != '\0') {
    LOCK();
    uVar1 = *puStack_18;
    *puStack_18 = *puStack_18 + 0x80000000;
    UNLOCK();
    if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
      LOCK();
      uVar1 = *puStack_18;
      *puStack_18 = *puStack_18 | 0x40000000;
      UNLOCK();
      if ((uVar1 >> 0x1e & 1) == 0) {
        uVar3 = FUN_00554e40();
        SetEvent(uVar3);
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15751 ; VA 0x008f7870 ; FUN_008f7870 */

int FUN_008f7870(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 != 0) {
    if (*(int *)(param_1 + 0x34) != 0) {
      param_1 = FUN_005c8ac0();
    }
    if (param_1 != 0) {
      iVar1 = *(int *)(param_1 + 0xc);
      iVar2 = FUN_008dcf60();
      if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
          (uint)*(ushort *)(iVar2 + 0x1da)) {
        return param_1 + -0xc;
      }
    }
  }
  return 0;
}



/* FUNCTION 15752 ; VA 0x008f78c0 ; FUN_008f78c0 */

int FUN_008f78c0(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (param_1 == 0) {
    return 0;
  }
  iVar1 = *(int *)(param_1 + 0x34);
  if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
    param_1 = FUN_005c8ac0();
  }
  if ((param_1 != 0) &&
     (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008dcf60(),
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
     (uint)*(ushort *)(iVar2 + 0x1da))) {
    return param_1 + -0xc;
  }
  return 0;
}



/* FUNCTION 15753 ; VA 0x008f7920 ; FUN_008f7920 */

int * FUN_008f7920(int *param_1,int *param_2)

{
  code *pcVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined4 uVar9;
  int iStack_ec;
  int iStack_e8;
  undefined4 auStack_e4 [50];
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar2 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01798ebb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = (**(code **)*param_1)();
  if (iVar4 == 0) {
LAB_008f7ac7:
    if ((undefined4 *)*param_2 != (undefined4 *)0x0) {
      ExceptionList = pvStack_10;
      return *(int **)*param_2;
    }
    FUN_016756b0(auStack_1c,"Argument %d missing or nil",1);
                    /* WARNING: Subroutine does not return */
    FUN_0170c2a8(auStack_1c,&DAT_01c17198);
  }
  pcVar1 = *(code **)(*piVar2 + 0x38);
  uVar5 = FUN_008a7680();
  cVar3 = (*pcVar1)(1,uVar5,&param_1);
  if (cVar3 != '\0') {
    ExceptionList = pvStack_10;
    return param_1;
  }
  iStack_ec = FUN_00888530();
  iStack_e8 = 0;
  uStack_8 = 0;
  cVar3 = (**(code **)(*piVar2 + 4))(1,&iStack_ec);
  iVar4 = iStack_ec;
  if (cVar3 == '\0') {
    uStack_8 = 2;
    if (iStack_e8 != 0) {
      (**(code **)(iStack_e8 + 8))(auStack_e4);
    }
    uStack_8 = 0xffffffff;
    goto LAB_008f7ac7;
  }
  iVar6 = thunk_FUN_008a7680();
  iVar8 = iStack_ec;
  if (iVar4 == iVar6) {
    puVar7 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    if (puVar7 != (undefined4 *)0x0) goto LAB_008f7a72;
  }
  iVar6 = FUN_0088cb40();
  iVar4 = iStack_ec;
  if (iVar8 == iVar6) {
    iVar8 = FUN_0088cb40();
    if (iVar4 != iVar8) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    puVar7 = auStack_e4;
    if (iStack_e8 == 0) {
      puVar7 = (undefined4 *)0x0;
    }
    FUN_008a7680();
    if (0xf < (uint)puVar7[5]) {
      puVar7 = (undefined4 *)*puVar7;
    }
    cVar3 = FUN_009cb180(puVar7,&param_1);
    if (cVar3 != '\0') {
      FUN_00897ae0(&param_1);
      iVar4 = thunk_FUN_008a7680();
      iStack_ec = iVar4;
      iVar8 = thunk_FUN_008a7680();
      if (iVar4 != iVar8) {
                    /* WARNING: Subroutine does not return */
        FUN_016757c0("Variant cast failed");
      }
      puVar7 = auStack_e4;
      if (iStack_e8 == 0) {
        puVar7 = (undefined4 *)0x0;
      }
LAB_008f7a72:
      piVar2 = (int *)*puVar7;
      uStack_8 = 1;
      if (iStack_e8 != 0) {
        (**(code **)(iStack_e8 + 8))(auStack_e4);
      }
      ExceptionList = pvStack_10;
      return piVar2;
    }
  }
  thunk_FUN_008a7680();
  uVar5 = FUN_005543f0();
  uVar9 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Unable to cast %s to %s",uVar9,uVar5);
}



/* FUNCTION 15754 ; VA 0x008f7b60 ; FUN_008f7b60 */

void FUN_008f7b60(void)

{
  FUN_00bbddd0();
  return;
}



/* FUNCTION 15755 ; VA 0x008f7b80 ; FUN_008f7b80 */

void FUN_008f7b80(void)

{
  FUN_00bbdde0();
  return;
}



/* FUNCTION 15756 ; VA 0x008f7ba0 ; FUN_008f7ba0 */

void FUN_008f7ba0(void)

{
  FUN_00838a60();
  return;
}



/* FUNCTION 15757 ; VA 0x008f7bd0 ; FUN_008f7bd0 */

undefined FUN_008f7bd0(undefined4 param_1)

{
  int iVar1;
  
  if (DAT_01d635c4 != '\0') {
    iVar1 = FUN_008f78c0(param_1);
    if (iVar1 != 0) {
      return *(undefined *)(iVar1 + 0x24c);
    }
  }
  return 0;
}



/* FUNCTION 15758 ; VA 0x008f7c00 ; FUN_008f7c00 */

void FUN_008f7c00(void)

{
  int iVar1;
  
  if (DAT_01ee089c == 0) {
    iVar1 = FUN_008dcf60();
    DAT_01ee089c = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 15759 ; VA 0x008f7c20 ; thunk_FUN_00c9ab50 */

void thunk_FUN_00c9ab50(void)

{
  int iVar1;
  
  if (DAT_01f02274 == 0) {
    iVar1 = FUN_00c9aa70();
    DAT_01f02274 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 15760 ; VA 0x008f7c30 ; thunk_FUN_00e59530 */

void thunk_FUN_00e59530(void)

{
  int iVar1;
  
  if (DAT_01f1ce44 == 0) {
    iVar1 = FUN_00e59450();
    DAT_01f1ce44 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 15761 ; VA 0x008f7c50 ; FUN_008f7c50 */

undefined4 __fastcall FUN_008f7c50(int param_1)

{
  return *(undefined4 *)(*(int *)(*(int *)(param_1 + 0x1b8) + 0x1b4) + 0x58);
}



/* FUNCTION 15762 ; VA 0x008f7c60 ; FUN_008f7c60 */

void FUN_008f7c60(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = DAT_01eeb57c;
  *param_1 = 0;
  param_1[1] = 0;
  if (iVar1 != 0) {
    LOCK();
    *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
    UNLOCK();
    iVar1 = DAT_01eeb57c;
  }
  *param_1 = DAT_01eeb578;
  param_1[1] = iVar1;
  return;
}



/* FUNCTION 15763 ; VA 0x008f7ca0 ; FUN_008f7ca0 */

undefined FUN_008f7ca0(int param_1)

{
  undefined uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00ceb430();
  uVar1 = FUN_00ceb2f0(&param_1);
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar2 = param_1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_1 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15764 ; VA 0x008f7d20 ; FUN_008f7d20 */

undefined FUN_008f7d20(int param_1)

{
  undefined uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008e4c40(&param_1);
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar2 = param_1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_1 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15765 ; VA 0x008f7da0 ; FUN_008f7da0 */

undefined4 FUN_008f7da0(int param_1)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008e4770(&param_1);
  if (0xf < in_stack_00000018) {
    uVar3 = in_stack_00000018 + 1;
    iVar2 = param_1;
    if (0xfff < uVar3) {
      iVar2 = *(int *)(param_1 + -4);
      uVar3 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - iVar2) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar2,uVar3);
  }
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15766 ; VA 0x008f7e20 ; FUN_008f7e20 */

undefined4 FUN_008f7e20(undefined4 param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint in_stack_0000001c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_008e49a0(param_1,&param_2);
  if (0xf < in_stack_0000001c) {
    uVar2 = in_stack_0000001c + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15767 ; VA 0x008f7eb0 ; FUN_008f7eb0 */

undefined4 __fastcall FUN_008f7eb0(int param_1)

{
  if (*(int *)(param_1 + 0x1a0) != 0) {
    return *(undefined4 *)(*(int *)(param_1 + 0x1a0) + 0x70);
  }
  return 2;
}



/* FUNCTION 15768 ; VA 0x008f7ed0 ; FUN_008f7ed0 */

float10 __fastcall FUN_008f7ed0(int param_1)

{
  return (float10)*(double *)(*(int *)(param_1 + 0x1a8) + 0x70);
}



/* FUNCTION 15769 ; VA 0x008f7f00 ; FUN_008f7f00 */

undefined4 __fastcall FUN_008f7f00(int param_1)

{
  if (((DAT_01d635e4 != '\0') && (*(int *)(param_1 + 0x158) != 6)) &&
     (*(int *)(param_1 + 0x158) != 0)) {
    return 1;
  }
  return 0;
}



/* FUNCTION 15770 ; VA 0x008f7f30 ; FUN_008f7f30 */

void __thiscall FUN_008f7f30(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0x1b8) + 0x1b4);
  uVar2 = *(undefined4 *)(iVar1 + 0x5dc);
  uVar3 = *(undefined4 *)(iVar1 + 0x5e0);
  *param_2 = *(undefined4 *)(iVar1 + 0x5d8);
  param_2[1] = uVar2;
  *param_3 = uVar3;
  return;
}



/* FUNCTION 15771 ; VA 0x008f7f60 ; FUN_008f7f60 */

void __thiscall FUN_008f7f60(int param_1,undefined4 **param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 *puVar8;
  undefined4 *puStack_34;
  undefined4 *puStack_30;
  int iStack_2c;
  uint uStack_28;
  uint uStack_24;
  undefined4 *puStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c40b8;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(*(int *)(param_1 + 0x1b8) + 0x1b4);
  puVar6 = (undefined4 *)(iVar1 + 0x5e8);
  ExceptionList = &pvStack_10;
  FUN_008e8010(puVar6);
  puVar5 = puStack_34;
  *(undefined4 *)(iVar1 + 0x5ec) = *puVar6;
  uStack_8 = 0;
  if (param_2 != &puStack_34) {
    puStack_20 = puStack_30;
    uStack_28 = (int)puStack_30 - (int)puStack_34;
    puStack_18 = *param_2;
    uStack_1c = (int)uStack_28 >> 4;
    uStack_24 = (int)param_2[2] - (int)puStack_18 >> 4;
    uVar7 = (int)param_2[1] - (int)puStack_18 >> 4;
    if (uStack_24 < uStack_1c) {
      if (0xfffffff < uStack_1c) {
                    /* WARNING: Subroutine does not return */
        FUN_00577c30();
      }
      uStack_28 = uStack_24 >> 1;
      uVar7 = uStack_1c;
      if ((uStack_24 <= 0xfffffff - uStack_28) &&
         (uVar7 = uStack_28 + uStack_24, uStack_28 + uStack_24 < uStack_1c)) {
        uVar7 = uStack_1c;
      }
      uStack_1c = uVar7;
      if (puStack_18 != (undefined4 *)0x0) {
        FUN_0061a3e0(puStack_18,uStack_24);
      }
      FUN_008ed8d0(uStack_1c);
      puVar6 = *param_2;
      for (; puVar5 != puStack_20; puVar5 = puVar5 + 4) {
        uVar2 = puVar5[1];
        uVar3 = puVar5[2];
        uVar4 = puVar5[3];
        *puVar6 = *puVar5;
        puVar6[1] = uVar2;
        puVar6[2] = uVar3;
        puVar6[3] = uVar4;
        puVar6 = puVar6 + 4;
      }
    }
    else if (uVar7 < uStack_1c) {
      puVar8 = puStack_34 + uVar7 * 4;
      FUN_0055b6b0(&uStack_11,&uStack_28,&uStack_28);
      FUN_0170cc70(puStack_18,puVar5,(int)puVar8 - (int)puVar5);
      puVar6 = param_2[1];
      for (; puVar8 != puStack_20; puVar8 = puVar8 + 4) {
        uVar2 = puVar8[1];
        uVar3 = puVar8[2];
        uVar4 = puVar8[3];
        *puVar6 = *puVar8;
        puVar6[1] = uVar2;
        puVar6[2] = uVar3;
        puVar6[3] = uVar4;
        puVar6 = puVar6 + 4;
      }
    }
    else {
      FUN_0055b6b0(&uStack_11,&uStack_24,&uStack_24);
      puVar6 = puStack_18;
      FUN_0170cc70(puStack_18,puVar5,uStack_28);
      puVar6 = puVar6 + uStack_1c * 4;
    }
    param_2[1] = puVar6;
  }
  if (puStack_34 != (undefined4 *)0x0) {
    uVar7 = iStack_2c - (int)puStack_34 & 0xfffffff0;
    puVar5 = puStack_34;
    if (0xfff < uVar7) {
      puVar5 = (undefined4 *)puStack_34[-1];
      uVar7 = uVar7 + 0x23;
      if (0x1f < (uint)((int)puStack_34 + (-4 - (int)puVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar5,uVar7);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15772 ; VA 0x008f8140 ; FUN_008f8140 */

undefined __fastcall FUN_008f8140(int param_1)

{
  uint uVar1;
  
  uVar1 = -(uint)(param_1 != 0) & param_1 + 0xcU;
  FUN_0098c5a0(uVar1,1);
  FUN_00973950(uVar1,1);
  return *(undefined *)(param_1 + 0x33c);
}



/* FUNCTION 15773 ; VA 0x008f8170 ; FUN_008f8170 */

int * FUN_008f8170(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 uStack_120;
  int iStack_11c;
  uint uStack_118;
  int *piStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined8 uStack_108;
  undefined4 uStack_50;
  undefined4 *puStack_4c;
  undefined4 *puStack_48;
  undefined4 uStack_44;
  int iStack_40;
  int iStack_3c;
  uint uStack_38;
  int *piStack_34;
  uint uStack_30;
  int *piStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c416d;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_005cac50(&iStack_40);
  uStack_8 = 0;
  FUN_005cac50(&uStack_30);
  uStack_8._0_1_ = 1;
  uStack_18 = 0;
  uStack_14 = 0xf;
  uStack_28 = uStack_28 & 0xffffff00;
  FUN_005542c0(&DAT_018c387c,4);
  uStack_8._0_1_ = 2;
  uStack_120 = FUN_0088cb40();
  iStack_11c = 0;
  uStack_118 = uStack_28;
  piStack_114 = (int *)uStack_24;
  uStack_110 = uStack_20;
  uStack_10c = uStack_1c;
  uStack_28 = uStack_28 & 0xffffff00;
  uStack_108 = CONCAT44(uStack_14,uStack_18);
  uStack_18 = 0;
  uStack_14 = 0xf;
  iStack_11c = FUN_005c9d30();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (*(int *)(uStack_30 + 8) == *(int *)(uStack_30 + 4)) {
    FUN_005ca4f0(*(int *)(uStack_30 + 4),&uStack_120);
  }
  else {
    FUN_005caf00(&uStack_120);
    *(int *)(uStack_30 + 4) = *(int *)(uStack_30 + 4) + 0xd0;
  }
  uStack_8._0_1_ = 4;
  if (iStack_11c != 0) {
    (**(code **)(iStack_11c + 8))(&uStack_118);
  }
  uStack_8._0_1_ = 1;
  uStack_18 = 0;
  uStack_14 = 0xf;
  uStack_28 = uStack_28 & 0xffffff00;
  FUN_005542c0("averageDutyCycle",0x10);
  uStack_8._0_1_ = 5;
  uStack_120 = FUN_0088cb40();
  iStack_11c = 0;
  uStack_118 = uStack_28;
  piStack_114 = (int *)uStack_24;
  uStack_110 = uStack_20;
  uStack_10c = uStack_1c;
  uStack_28 = uStack_28 & 0xffffff00;
  uStack_108 = CONCAT44(uStack_14,uStack_18);
  uStack_18 = 0;
  uStack_14 = 0xf;
  iStack_11c = FUN_005c9d30();
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  if (*(int *)(uStack_30 + 8) == *(int *)(uStack_30 + 4)) {
    FUN_005ca4f0(*(int *)(uStack_30 + 4),&uStack_120);
  }
  else {
    FUN_005caf00(&uStack_120);
    *(int *)(uStack_30 + 4) = *(int *)(uStack_30 + 4) + 0xd0;
  }
  uStack_8._0_1_ = 7;
  if (iStack_11c != 0) {
    (**(code **)(iStack_11c + 8))(&uStack_118);
  }
  uStack_8._0_1_ = 1;
  uStack_18 = 0;
  uStack_14 = 0xf;
  uStack_28 = uStack_28 & 0xffffff00;
  FUN_005542c0("averageStepsPerSecond",0x15);
  uStack_8._0_1_ = 8;
  uStack_120 = FUN_0088cb40();
  iStack_11c = 0;
  uStack_118 = uStack_28;
  piStack_114 = (int *)uStack_24;
  uStack_110 = uStack_20;
  uStack_10c = uStack_1c;
  uStack_28 = uStack_28 & 0xffffff00;
  uStack_108 = CONCAT44(uStack_14,uStack_18);
  uStack_18 = 0;
  uStack_14 = 0xf;
  iStack_11c = FUN_005c9d30();
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (*(int *)(uStack_30 + 8) == *(int *)(uStack_30 + 4)) {
    FUN_005ca4f0(*(int *)(uStack_30 + 4),&uStack_120);
  }
  else {
    FUN_005caf00(&uStack_120);
    *(int *)(uStack_30 + 4) = *(int *)(uStack_30 + 4) + 0xd0;
  }
  uStack_8._0_1_ = 10;
  if (iStack_11c != 0) {
    (**(code **)(iStack_11c + 8))(&uStack_118);
  }
  uStack_8._0_1_ = 1;
  uStack_18 = 0;
  uStack_14 = 0xf;
  uStack_28 = uStack_28 & 0xffffff00;
  FUN_005542c0("averageStepTime",0xf);
  uStack_8._0_1_ = 0xb;
  uStack_120 = FUN_0088cb40();
  iStack_11c = 0;
  uStack_118 = uStack_28;
  piStack_114 = (int *)uStack_24;
  uStack_110 = uStack_20;
  uStack_10c = uStack_1c;
  uStack_28 = uStack_28 & 0xffffff00;
  uStack_108 = CONCAT44(uStack_14,uStack_18);
  uStack_18 = 0;
  uStack_14 = 0xf;
  iStack_11c = FUN_005c9d30();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  if (*(int *)(uStack_30 + 8) == *(int *)(uStack_30 + 4)) {
    FUN_005ca4f0(*(int *)(uStack_30 + 4),&uStack_120);
  }
  else {
    FUN_005caf00(&uStack_120);
    *(int *)(uStack_30 + 4) = *(int *)(uStack_30 + 4) + 0xd0;
  }
  uStack_8._0_1_ = 0xd;
  if (iStack_11c != 0) {
    (**(code **)(iStack_11c + 8))(&uStack_118);
  }
  uStack_8._0_1_ = 1;
  uStack_18 = 0;
  uStack_14 = 0xf;
  uStack_28 = uStack_28 & 0xffffff00;
  FUN_005542c0("averageError",0xc);
  uStack_8._0_1_ = 0xe;
  uStack_120 = FUN_0088cb40();
  iStack_11c = 0;
  uStack_118 = uStack_28;
  piStack_114 = (int *)uStack_24;
  uStack_110 = uStack_20;
  uStack_10c = uStack_1c;
  uStack_28 = uStack_28 & 0xffffff00;
  uStack_108 = CONCAT44(uStack_14,uStack_18);
  uStack_18 = 0;
  uStack_14 = 0xf;
  iStack_11c = FUN_005c9d30();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
  if (*(int *)(uStack_30 + 8) == *(int *)(uStack_30 + 4)) {
    FUN_005ca4f0(*(int *)(uStack_30 + 4),&uStack_120);
  }
  else {
    FUN_005caf00(&uStack_120);
    *(int *)(uStack_30 + 4) = *(int *)(uStack_30 + 4) + 0xd0;
  }
  uStack_8._0_1_ = 0x10;
  if (iStack_11c != 0) {
    (**(code **)(iStack_11c + 8))(&uStack_118);
  }
  uStack_8._0_1_ = 1;
  uStack_18 = 0;
  uStack_14 = 0xf;
  uStack_28 = uStack_28 & 0xffffff00;
  FUN_005542c0("isRunning",9);
  uStack_8._0_1_ = 0x11;
  uStack_120 = FUN_0088cb40();
  iStack_11c = 0;
  uStack_118 = uStack_28;
  piStack_114 = (int *)uStack_24;
  uStack_110 = uStack_20;
  uStack_10c = uStack_1c;
  uStack_28 = uStack_28 & 0xffffff00;
  uStack_108 = CONCAT44(uStack_14,uStack_18);
  uStack_18 = 0;
  uStack_14 = 0xf;
  iStack_11c = FUN_005c9d30();
  uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
  if (*(int *)(uStack_30 + 8) == *(int *)(uStack_30 + 4)) {
    FUN_005ca4f0(*(int *)(uStack_30 + 4),&uStack_120);
  }
  else {
    FUN_005caf00(&uStack_120);
    *(int *)(uStack_30 + 4) = *(int *)(uStack_30 + 4) + 0xd0;
  }
  uStack_8._0_1_ = 0x13;
  if (iStack_11c != 0) {
    (**(code **)(iStack_11c + 8))(&uStack_118);
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piStack_2c[1] = piStack_2c[1] + 1;
    UNLOCK();
  }
  uStack_38 = uStack_30;
  piStack_34 = piStack_2c;
  uStack_8._0_1_ = 0x14;
  uStack_120 = FUN_008882f0();
  iStack_11c = 0;
  uStack_118 = uStack_30;
  piStack_114 = piStack_2c;
  uStack_38 = 0;
  piStack_34 = (int *)0x0;
  iStack_11c = FUN_005c9da0();
  iVar2 = iStack_40;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
  if (*(int *)(iStack_40 + 8) == *(int *)(iStack_40 + 4)) {
    FUN_005ca4f0(*(int *)(iStack_40 + 4),&uStack_120);
  }
  else {
    FUN_005caf00(&uStack_120);
    *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 0xd0;
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
  if (iStack_11c != 0) {
    (**(code **)(iStack_11c + 8))(&uStack_118);
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piStack_2c + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  puStack_4c = (undefined4 *)0x0;
  puStack_48 = (undefined4 *)0x0;
  uStack_44 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
  FUN_0151da40(&puStack_4c);
  piStack_2c = puStack_48;
  puVar3 = puStack_4c;
  if (puStack_4c != puStack_48) {
    do {
      if (puVar3[1] != 0) {
        LOCK();
        piVar1 = (int *)(puVar3[1] + 4);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
      }
      FUN_008ee620(uStack_50,*puVar3,puVar3[1],iStack_40);
      puVar3 = puVar3 + 2;
    } while (puVar3 != piStack_2c);
  }
  param_1[1] = iStack_3c;
  *param_1 = iStack_40;
  FUN_00641040();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15774 ; VA 0x008f8770 ; FUN_008f8770 */

undefined4 __fastcall FUN_008f8770(int param_1)

{
  return *(undefined4 *)(param_1 + 0xa8);
}



/* FUNCTION 15775 ; VA 0x008f87a0 ; FUN_008f87a0 */

undefined4 __fastcall FUN_008f87a0(int param_1)

{
  return *(undefined4 *)(*(int *)(*(int *)(param_1 + 0x1b8) + 0x1b4) + 0x6f4);
}



/* FUNCTION 15776 ; VA 0x008f87d0 ; FUN_008f87d0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __thiscall FUN_008f87d0(int param_1,undefined4 param_2,code *param_3)

{
  longlong lVar1;
  code *pcVar2;
  undefined uVar3;
  char cVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined *puVar7;
  uint uVar8;
  undefined4 uVar9;
  int *piVar10;
  code *pcVar11;
  int iVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  float10 fVar16;
  float10 fVar17;
  float10 fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  undefined auStack_c8 [16];
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined auStack_ac [24];
  undefined auStack_94 [16];
  undefined4 uStack_84;
  undefined4 uStack_80;
  int iStack_7c;
  undefined auStack_78 [16];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined8 uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined auStack_48 [16];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  double dStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  pcVar2 = param_3;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c43bb;
  pvStack_10 = ExceptionList;
  uStack_b0 = 0;
  uStack_58 = (double)CONCAT44(param_1,(undefined4)uStack_58);
  iVar12 = *(int *)(*(int *)(param_1 + 0x1b8) + 0x1b4);
  iVar5 = 0xb;
  if (*(uint *)(param_3 + 0x10) < 0xb) {
    iVar5 = *(int *)(param_3 + 0x10);
  }
  pcVar11 = param_3;
  if (0xf < *(uint *)(param_3 + 0x14)) {
    pcVar11 = *(code **)param_3;
  }
  ExceptionList = &pvStack_10;
  iStack_7c = iVar12;
  iVar5 = FUN_0055c2d0(pcVar11,iVar5,"RenderStats",0xb);
  if (iVar5 == 0) goto LAB_008f883d;
  iVar5 = 3;
  if (*(uint *)(pcVar2 + 0x10) < 3) {
    iVar5 = *(int *)(pcVar2 + 0x10);
  }
  pcVar11 = pcVar2;
  if (0xf < *(uint *)(pcVar2 + 0x14)) {
    pcVar11 = *(code **)pcVar2;
  }
  iVar5 = FUN_0055c2d0(pcVar11,iVar5,&DAT_0192c004,3);
  if (iVar5 == 0) {
    param_3 = *(code **)(**(int **)(param_1 + 0x1d4) + 8);
    fVar16 = (float10)(*param_3)(pcVar2);
    FUN_01675640(param_2,&DAT_0192c008,(double)fVar16);
    ExceptionList = pvStack_10;
    return param_2;
  }
  uStack_60 = CONCAT44(param_1 + 0xc,(undefined4)uStack_60);
  uVar3 = FUN_0098c5a0(param_1 + 0xc,1);
  param_3 = (code *)CONCAT13(uVar3,param_3._0_3_);
  pcVar11 = pcVar2;
  if (0xf < *(uint *)(pcVar2 + 0x14)) {
    pcVar11 = *(code **)pcVar2;
  }
  iVar5 = FUN_0055c2d0(pcVar11,*(int *)(pcVar2 + 0x10),"PlacelauncherStats",0x12);
  if (iVar5 == 0) {
    if (param_3._3_1_ == '\0') {
      param_3 = *(code **)(param_1 + 0x4c4);
      if ((NAN((float)param_3) || NAN(DAT_018f7864)) != ((float)param_3 == DAT_018f7864)) {
        FUN_01675640(param_2,"Waiting...");
        ExceptionList = pvStack_10;
        return param_2;
      }
      FUN_016830f0(&dStack_18);
      FUN_01675640();
      ExceptionList = pvStack_10;
      return param_2;
    }
LAB_008f88e9:
    FUN_01675640(param_2,"This is a server");
    ExceptionList = pvStack_10;
    return param_2;
  }
  pcVar11 = pcVar2;
  if (0xf < *(uint *)(pcVar2 + 0x14)) {
    pcVar11 = *(code **)pcVar2;
  }
  cVar4 = FUN_0055c360(pcVar11,*(int *)(pcVar2 + 0x10),"IPTypeAndDataCenter",0x13);
  if (cVar4 != '\0') {
    if (param_3._3_1_ != '\0') goto LAB_008f88e9;
    if (*(int *)(param_1 + 0x328) == 0) {
      puVar6 = (undefined4 *)FUN_015301f0(auStack_ac);
      uStack_8 = 0;
      if (0xf < (uint)puVar6[5]) {
        puVar6 = (undefined4 *)*puVar6;
      }
      FUN_01675640(param_2,"Waiting... %s",puVar6);
    }
    else {
      puVar6 = (undefined4 *)FUN_015301f0(auStack_ac);
      uStack_8 = 1;
      if (0xf < (uint)puVar6[5]) {
        puVar6 = (undefined4 *)*puVar6;
      }
      piVar10 = (int *)(param_1 + 0x318);
      if (0xf < *(uint *)(param_1 + 0x32c)) {
        piVar10 = (int *)*piVar10;
      }
      puVar7 = &DAT_0192c080;
      if (*(char *)(param_1 + 0x4a4) == '\0') {
        puVar7 = &DAT_0192c088;
      }
      FUN_01675640(param_2,"%s, %s (ID: %d) %s",puVar7,piVar10,*(undefined4 *)(param_1 + 0x314),
                   puVar6);
    }
    goto LAB_008fb377;
  }
  pcVar11 = pcVar2;
  if (0xf < *(uint *)(pcVar2 + 0x14)) {
    pcVar11 = *(code **)pcVar2;
  }
  cVar4 = FUN_0055c360(pcVar11,*(int *)(pcVar2 + 0x10),"JoinStart",9);
  if (cVar4 != '\0') {
    if (param_3._3_1_ == '\0') {
      fVar20 = *(float *)(param_1 + 0x308);
      if (fVar20 < 0.0) {
        puVar6 = (undefined4 *)(param_1 + 0x4ac);
        if (0xf < *(uint *)(param_1 + 0x4c0)) {
          puVar6 = (undefined4 *)*puVar6;
        }
        FUN_01675640(param_2,"Waiting..., join status: %s",puVar6);
        ExceptionList = pvStack_10;
        return param_2;
      }
      if (*(char *)(param_1 + 0x240) != '\0') {
        FUN_01675640(param_2,"%.3f sec, join status: Joined",(double)fVar20);
        ExceptionList = pvStack_10;
        return param_2;
      }
      puVar6 = (undefined4 *)(param_1 + 0x4ac);
      if (0xf < *(uint *)(param_1 + 0x4c0)) {
        puVar6 = (undefined4 *)*puVar6;
      }
      FUN_01675640(param_2,"%.3f sec, join status: %s",(double)fVar20,puVar6);
      ExceptionList = pvStack_10;
      return param_2;
    }
    goto LAB_008f88e9;
  }
  pcVar11 = pcVar2;
  if (0xf < *(uint *)(pcVar2 + 0x14)) {
    pcVar11 = *(code **)pcVar2;
  }
  cVar4 = FUN_0055c360(pcVar11,*(int *)(pcVar2 + 0x10),"RakNetPasswordAccepted",0x16);
  if (cVar4 != '\0') {
    fVar20 = *(float *)(param_1 + 0x30c);
LAB_008f8b35:
    if (fVar20 < 0.0) {
      FUN_01675640(param_2,"Waiting...");
      ExceptionList = pvStack_10;
      return param_2;
    }
    FUN_01675640(param_2,"%.3f sec",(double)fVar20);
    ExceptionList = pvStack_10;
    return param_2;
  }
  pcVar11 = pcVar2;
  if (0xf < *(uint *)(pcVar2 + 0x14)) {
    pcVar11 = *(code **)pcVar2;
  }
  cVar4 = FUN_0055c360(pcVar11,*(int *)(pcVar2 + 0x10),"FinishedReceivingInitialGameData",0x20);
  if (cVar4 != '\0') {
    fVar20 = *(float *)(param_1 + 0x310);
    goto LAB_008f8b35;
  }
  param_3 = (code *)FUN_005cf810();
  if (param_3 != (code *)0x0) {
    uStack_b8 = 0;
    uStack_b4 = 0xf;
    auStack_c8[0] = 0;
    FUN_005542c0(&DAT_018c5904,7);
    uStack_8 = 2;
    iVar5 = FUN_008a1240(auStack_c8);
    if (iVar5 == 0) {
      iVar5 = 0;
    }
    else {
      iVar5 = iVar5 + 4;
    }
    FUN_0060ddd0(&dStack_18,iVar5);
    uStack_8._0_1_ = 4;
    FUN_005507b0();
    if ((dStack_18._0_4_ != (undefined4 *)0x0) && (uVar8 = FUN_005d6c30(), 1 < uVar8)) {
      param_3 = *(code **)(**(int **)((int)dStack_18._0_4_ + 0x2c) + 8);
      if (param_3 != (code *)0x0) {
        uStack_68 = 0;
        uStack_64 = 0xf;
        auStack_78[0] = 0;
        FUN_005542c0("Stats",5);
        uStack_8._0_1_ = 5;
        FUN_008a1240(auStack_78);
        uVar9 = FUN_008a1240(pcVar2);
        uVar9 = FUN_0063f7f0(uVar9);
        uStack_50 = CONCAT44(uVar9,(undefined4)uStack_50);
        uStack_8._0_1_ = 4;
        FUN_005507b0();
        if (uStack_50._4_4_ != (int *)0x0) {
          (**(code **)(*uStack_50._4_4_ + 0xa4))();
          FUN_01675640(param_2,&DAT_0192c108,(int)*(undefined8 *)((int)uStack_50._4_4_ + 0x58),
                       (int)((ulonglong)*(undefined8 *)((int)uStack_50._4_4_ + 0x58) >> 0x20));
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return param_2;
        }
        pcVar11 = pcVar2;
        if (0xf < *(uint *)(pcVar2 + 0x14)) {
          pcVar11 = *(code **)pcVar2;
        }
        cVar4 = FUN_0055c360(pcVar11,*(int *)(pcVar2 + 0x10),"RakNetPing",10);
        if (cVar4 != '\0') {
          uStack_68 = 0;
          uStack_64 = 0xf;
          auStack_78[0] = 0;
          FUN_005542c0(&DAT_018c5ca8,4);
          uStack_8 = CONCAT31(uStack_8._1_3_,6);
          FUN_008a1240(auStack_78);
          piVar10 = (int *)FUN_005cf720();
          (**(code **)(*piVar10 + 0xa4))();
          FUN_0054ef60(piVar10 + 0x18);
          FUN_005507b0();
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return param_2;
        }
        pcVar11 = pcVar2;
        if (0xf < *(uint *)(pcVar2 + 0x14)) {
          pcVar11 = *(code **)pcVar2;
        }
        cVar4 = FUN_0055c360(pcVar11,*(int *)(pcVar2 + 0x10),"GeneralStats",0xc);
        if (cVar4 != '\0') {
          uStack_38 = 0;
          uStack_34 = 0xf;
          auStack_48[0] = 0;
          FUN_005542c0("StreamingEnabled",0x10);
          uStack_8._0_1_ = 7;
          FUN_008a1240(auStack_48);
          piVar10 = (int *)FUN_005cf720();
          (**(code **)(*piVar10 + 0xa4))();
          uStack_20 = 0;
          uStack_1c = 0xf;
          auStack_30[0] = 0;
          FUN_005542c0("Data Ping",9);
          uStack_8._0_1_ = 8;
          FUN_008a1240(auStack_30);
          piVar10 = (int *)FUN_005cf720();
          (**(code **)(*piVar10 + 0xa4))();
          uStack_58 = *(double *)(piVar10 + 0x16);
          uStack_84 = 0;
          uStack_80 = 0xf;
          auStack_94[0] = 0;
          FUN_005542c0("Send kBps",9);
          uStack_8._0_1_ = 9;
          FUN_008a1240(auStack_94);
          uStack_68 = 0;
          uStack_64 = 0xf;
          auStack_78[0] = 0;
          FUN_005542c0("MtuSize",7);
          uStack_8 = CONCAT31(uStack_8._1_3_,10);
          FUN_008a1240(auStack_78);
          piVar10 = (int *)FUN_005cf720();
          (**(code **)(*piVar10 + 0xa4))();
          FUN_01675640();
          FUN_005507b0();
          FUN_005507b0();
          FUN_005507b0();
LAB_008f8f09:
          FUN_005507b0();
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return param_2;
        }
        pcVar11 = pcVar2;
        if (0xf < *(uint *)(pcVar2 + 0x14)) {
          pcVar11 = *(code **)pcVar2;
        }
        cVar4 = FUN_0055c360(pcVar11,*(int *)(pcVar2 + 0x10),"OutgoingStats",0xd);
        if (cVar4 != '\0') {
          uStack_38 = 0;
          uStack_34 = 0xf;
          auStack_48[0] = 0;
          FUN_005542c0("Send kBps",9);
          uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
          FUN_008a1240(auStack_48);
          piVar10 = (int *)FUN_005cf720();
          (**(code **)(*piVar10 + 0xa4))();
          FUN_01675640(param_2,&DAT_018e4308,(int)*(undefined8 *)(piVar10 + 0x16),
                       (int)((ulonglong)*(undefined8 *)(piVar10 + 0x16) >> 0x20));
          goto LAB_008f8f09;
        }
        pcVar11 = pcVar2;
        if (0xf < *(uint *)(pcVar2 + 0x14)) {
          pcVar11 = *(code **)pcVar2;
        }
        cVar4 = FUN_0055c360(pcVar11,*(int *)(pcVar2 + 0x10),"IncomingStats",0xd);
        if (cVar4 != '\0') {
          uStack_84 = 0;
          uStack_80 = 0xf;
          auStack_94[0] = 0;
          FUN_005542c0("Packet Queue",0xc);
          uStack_8._0_1_ = 0xc;
          FUN_008a1240(auStack_94);
          piVar10 = (int *)FUN_005cf720();
          (**(code **)(*piVar10 + 0xa4))();
          uStack_58 = *(double *)(piVar10 + 0x16);
          uStack_20 = 0;
          uStack_1c = 0xf;
          auStack_30[0] = 0;
          FUN_005542c0("Received Packets",0x10);
          uStack_8._0_1_ = 0xd;
          FUN_008a1240(auStack_30);
          piVar10 = (int *)FUN_005cf720();
          (**(code **)(*piVar10 + 0xa4))();
          uStack_50 = *(undefined8 *)(piVar10 + 0x16);
          uStack_38 = 0;
          uStack_34 = 0xf;
          auStack_48[0] = 0;
          FUN_005542c0("Receive kBps",0xc);
          uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
          FUN_008a1240(auStack_48);
          piVar10 = (int *)FUN_005cf720();
          (**(code **)(*piVar10 + 0xa4))();
          FUN_01675640(param_2,"%.2f, %.2f, %.0f",(int)*(undefined8 *)(piVar10 + 0x16),
                       (int)((ulonglong)*(undefined8 *)(piVar10 + 0x16) >> 0x20),(int)uStack_50,
                       (int)((ulonglong)uStack_50 >> 0x20),SUB84(uStack_58,0),
                       (int)((ulonglong)uStack_58 >> 0x20));
          FUN_005507b0();
          FUN_005507b0();
          FUN_005507b0();
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return param_2;
        }
        pcVar11 = pcVar2;
        if (0xf < *(uint *)(pcVar2 + 0x14)) {
          pcVar11 = *(code **)pcVar2;
        }
        cVar4 = FUN_0055c360(pcVar11,*(int *)(pcVar2 + 0x10),"InData",6);
        if (cVar4 != '\0') {
          uStack_38 = 0;
          uStack_34 = 0xf;
          auStack_48[0] = 0;
          FUN_005542c0("Received Data Packets",0x15);
          uStack_8._0_1_ = 0xf;
          FUN_008a1240(auStack_48);
          piVar10 = (int *)FUN_005cf720();
          uStack_8._0_1_ = 4;
          FUN_005507b0();
          (**(code **)(*piVar10 + 0xa4))();
          uStack_20 = 0;
          uStack_1c = 0xf;
          auStack_30[0] = 0;
          uStack_50._4_4_ = (int *)(float)*(double *)(piVar10 + 0x16);
          FUN_005542c0(&DAT_018dbc90,4);
          uStack_8._0_1_ = 0x10;
          FUN_008a1240(auStack_30);
          piVar10 = (int *)FUN_005cf720();
          (**(code **)(*piVar10 + 0xa4))();
          param_3 = (code *)(float)*(double *)(piVar10 + 0x16);
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          FUN_005507b0();
          FUN_01675640(param_2,"%.2f, %.2f, %.2fB",
                       (double)(((float)param_3 * (float)uStack_50._4_4_) / DAT_018ce324),
                       (double)(float)uStack_50._4_4_,(double)(float)param_3);
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return param_2;
        }
        pcVar11 = pcVar2;
        if (0xf < *(uint *)(pcVar2 + 0x14)) {
          pcVar11 = *(code **)pcVar2;
        }
        cVar4 = FUN_0055c360(pcVar11,*(int *)(pcVar2 + 0x10),"InPhysics",9);
        if (cVar4 != '\0') {
          uStack_38 = 0;
          uStack_34 = 0xf;
          auStack_48[0] = 0;
          FUN_005542c0("Received Physics Packets",0x18);
          uStack_8._0_1_ = 0x11;
          FUN_008a1240(auStack_48);
          piVar10 = (int *)FUN_005cf720();
          uStack_8._0_1_ = 4;
          FUN_005507b0();
          (**(code **)(*piVar10 + 0xa4))();
          uStack_20 = 0;
          uStack_1c = 0xf;
          auStack_30[0] = 0;
          uStack_50._4_4_ = (int *)(float)*(double *)(piVar10 + 0x16);
          FUN_005542c0(&DAT_018dbc90,4);
          uStack_8._0_1_ = 0x12;
          FUN_008a1240(auStack_30);
          piVar10 = (int *)FUN_005cf720();
          (**(code **)(*piVar10 + 0xa4))();
          param_3 = (code *)(float)*(double *)(piVar10 + 0x16);
          uStack_8._0_1_ = 4;
          FUN_005507b0();
          uStack_20 = 0;
          uStack_1c = 0xf;
          auStack_30[0] = 0;
          uStack_60._4_4_ = ((float)param_3 * (float)uStack_50._4_4_) / DAT_018ce324;
          FUN_005542c0("Average Lag",0xb);
          uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
          FUN_008a1240(auStack_30);
          piVar10 = (int *)FUN_005cf720();
          (**(code **)(*piVar10 + 0xa4))();
          FUN_01675640(param_2,"%.2f, %.2f, %.2fB, %.2f",(double)uStack_60._4_4_,
                       (double)(float)uStack_50._4_4_,(double)(float)param_3,
                       (int)*(undefined8 *)(piVar10 + 0x16),
                       (int)((ulonglong)*(undefined8 *)(piVar10 + 0x16) >> 0x20));
          FUN_005507b0();
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return param_2;
        }
        pcVar11 = pcVar2;
        if (0xf < *(uint *)(pcVar2 + 0x14)) {
          pcVar11 = *(code **)pcVar2;
        }
        cVar4 = FUN_0055c360(pcVar11,*(int *)(pcVar2 + 0x10),"InTouches",9);
        if (cVar4 != '\0') {
          uStack_38 = 0;
          uStack_34 = 0xf;
          auStack_48[0] = 0;
          FUN_005542c0("Received Touch Packets",0x16);
          uStack_8._0_1_ = 0x14;
          FUN_008a1240(auStack_48);
          piVar10 = (int *)FUN_005cf720();
          uStack_8._0_1_ = 4;
          FUN_005507b0();
          (**(code **)(*piVar10 + 0xa4))();
          uStack_20 = 0;
          uStack_1c = 0xf;
          auStack_30[0] = 0;
          uStack_50._4_4_ = (int *)(float)*(double *)(piVar10 + 0x16);
          FUN_005542c0(&DAT_018dbc90,4);
          uStack_8._0_1_ = 0x15;
          FUN_008a1240(auStack_30);
          piVar10 = (int *)FUN_005cf720();
          (**(code **)(*piVar10 + 0xa4))();
          param_3 = (code *)(float)*(double *)(piVar10 + 0x16);
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          FUN_005507b0();
          FUN_01675640(param_2,"%.2f, %.2f, %.2fB",
                       (double)(((float)param_3 * (float)uStack_50._4_4_) / DAT_018ce324),
                       (double)(float)uStack_50._4_4_,(double)(float)param_3);
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return param_2;
        }
        pcVar11 = pcVar2;
        if (0xf < *(uint *)(pcVar2 + 0x14)) {
          pcVar11 = *(code **)pcVar2;
        }
        cVar4 = FUN_0055c360(pcVar11,*(int *)(pcVar2 + 0x10),"InClusters",10);
        if (cVar4 != '\0') {
          uStack_38 = 0;
          uStack_34 = 0xf;
          auStack_48[0] = 0;
          FUN_005542c0("Received Cluster Packets",0x18);
          uStack_8._0_1_ = 0x16;
          FUN_008a1240(auStack_48);
          piVar10 = (int *)FUN_005cf720();
          uStack_8._0_1_ = 4;
          FUN_005507b0();
          (**(code **)(*piVar10 + 0xa4))();
          uStack_20 = 0;
          uStack_1c = 0xf;
          auStack_30[0] = 0;
          uStack_50._4_4_ = (int *)(float)*(double *)(piVar10 + 0x16);
          FUN_005542c0(&DAT_018dbc90,4);
          uStack_8._0_1_ = 0x17;
          FUN_008a1240(auStack_30);
          piVar10 = (int *)FUN_005cf720();
          (**(code **)(*piVar10 + 0xa4))();
          param_3 = (code *)(float)*(double *)(piVar10 + 0x16);
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          FUN_005507b0();
          FUN_01675640(param_2,"%.2f, %.2f, %.2fB",
                       (double)(((float)param_3 * (float)uStack_50._4_4_) / DAT_018ce324),
                       (double)(float)uStack_50._4_4_,(double)(float)param_3);
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return param_2;
        }
        pcVar11 = pcVar2;
        if (0xf < *(uint *)(pcVar2 + 0x14)) {
          pcVar11 = *(code **)pcVar2;
        }
        cVar4 = FUN_0055c360(pcVar11,*(int *)(pcVar2 + 0x10),"OutPhysics",10);
        if (cVar4 != '\0') {
          uStack_38 = 0;
          uStack_34 = 0xf;
          auStack_48[0] = 0;
          FUN_005542c0("Sent Physics Packets",0x14);
          uStack_8._0_1_ = 0x18;
          FUN_008a1240(auStack_48);
          piVar10 = (int *)FUN_005cf720();
          uStack_8._0_1_ = 4;
          FUN_005507b0();
          (**(code **)(*piVar10 + 0xa4))();
          uStack_20 = 0;
          uStack_1c = 0xf;
          auStack_30[0] = 0;
          uStack_50._4_4_ = (int *)(float)*(double *)(piVar10 + 0x16);
          FUN_005542c0(&DAT_018dbc90,4);
          uStack_8._0_1_ = 0x19;
          FUN_008a1240(auStack_30);
          piVar10 = (int *)FUN_005cf720();
          (**(code **)(*piVar10 + 0xa4))();
          param_3 = (code *)(float)*(double *)(piVar10 + 0x16);
          uStack_8._0_1_ = 4;
          FUN_005507b0();
          uStack_20 = 0;
          uStack_1c = 0xf;
          auStack_30[0] = 0;
          uStack_60._4_4_ = ((float)param_3 * (float)uStack_50._4_4_) / DAT_018ce324;
          FUN_005542c0("Throttle",8);
          uStack_8 = CONCAT31(uStack_8._1_3_,0x1a);
          FUN_008a1240(auStack_30);
          piVar10 = (int *)FUN_005cf720();
          (**(code **)(*piVar10 + 0xa4))();
          FUN_01675640(param_2,"%.2f, %.2f, %.2fB, %.2f%%",(double)uStack_60._4_4_,
                       (double)(float)uStack_50._4_4_,(double)(float)param_3,
                       (int)*(undefined8 *)(piVar10 + 0x16),
                       (int)((ulonglong)*(undefined8 *)(piVar10 + 0x16) >> 0x20));
          FUN_005507b0();
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return param_2;
        }
        pcVar11 = pcVar2;
        if (0xf < *(uint *)(pcVar2 + 0x14)) {
          pcVar11 = *(code **)pcVar2;
        }
        cVar4 = FUN_0055c360(pcVar11,*(int *)(pcVar2 + 0x10),"OutData",7);
        if (cVar4 != '\0') {
          uStack_38 = 0;
          uStack_34 = 0xf;
          auStack_48[0] = 0;
          FUN_005542c0("Sent Data Packets",0x11);
          uStack_8._0_1_ = 0x1b;
          FUN_008a1240(auStack_48);
          piVar10 = (int *)FUN_005cf720();
          uStack_8._0_1_ = 4;
          FUN_005507b0();
          (**(code **)(*piVar10 + 0xa4))();
          uStack_20 = 0;
          uStack_1c = 0xf;
          auStack_30[0] = 0;
          uStack_50._4_4_ = (int *)(float)*(double *)(piVar10 + 0x16);
          FUN_005542c0(&DAT_018dbc90,4);
          uStack_8._0_1_ = 0x1c;
          FUN_008a1240(auStack_30);
          piVar10 = (int *)FUN_005cf720();
          (**(code **)(*piVar10 + 0xa4))();
          param_3 = (code *)(float)*(double *)(piVar10 + 0x16);
          uStack_8._0_1_ = 4;
          FUN_005507b0();
          uStack_20 = 0;
          uStack_1c = 0xf;
          auStack_30[0] = 0;
          uStack_60._4_4_ = ((float)param_3 * (float)uStack_50._4_4_) / DAT_018ce324;
          FUN_005542c0("Throttle",8);
          uStack_8 = CONCAT31(uStack_8._1_3_,0x1d);
          FUN_008a1240(auStack_30);
          piVar10 = (int *)FUN_005cf720();
          (**(code **)(*piVar10 + 0xa4))();
          FUN_01675640(param_2,"%.2f, %.2f, %.2fB, %.2f%%",(double)uStack_60._4_4_,
                       (double)(float)uStack_50._4_4_,(double)(float)param_3,
                       (int)*(undefined8 *)(piVar10 + 0x16),
                       (int)((ulonglong)*(undefined8 *)(piVar10 + 0x16) >> 0x20));
          FUN_005507b0();
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return param_2;
        }
        pcVar11 = pcVar2;
        if (0xf < *(uint *)(pcVar2 + 0x14)) {
          pcVar11 = *(code **)pcVar2;
        }
        cVar4 = FUN_0055c360(pcVar11,*(int *)(pcVar2 + 0x10),"OutTouches",10);
        if (cVar4 != '\0') {
          uStack_38 = 0;
          uStack_34 = 0xf;
          auStack_48[0] = 0;
          FUN_005542c0("SentTouchPackets",0x10);
          uStack_8._0_1_ = 0x1e;
          FUN_008a1240(auStack_48);
          piVar10 = (int *)FUN_005cf720();
          uStack_8._0_1_ = 4;
          FUN_005507b0();
          (**(code **)(*piVar10 + 0xa4))();
          uStack_20 = 0;
          uStack_1c = 0xf;
          auStack_30[0] = 0;
          uStack_50._4_4_ = (int *)(float)*(double *)(piVar10 + 0x16);
          FUN_005542c0(&DAT_018dbc90,4);
          uStack_8._0_1_ = 0x1f;
          FUN_008a1240(auStack_30);
          piVar10 = (int *)FUN_005cf720();
          (**(code **)(*piVar10 + 0xa4))();
          param_3 = (code *)(float)*(double *)(piVar10 + 0x16);
          uStack_8._0_1_ = 4;
          FUN_005507b0();
          uStack_20 = 0;
          uStack_1c = 0xf;
          auStack_30[0] = 0;
          uStack_60._4_4_ = ((float)param_3 * (float)uStack_50._4_4_) / DAT_018ce324;
          FUN_005542c0("WaitingTouches",0xe);
          uStack_8 = CONCAT31(uStack_8._1_3_,0x20);
          FUN_008a1240(auStack_30);
          piVar10 = (int *)FUN_005cf720();
          (**(code **)(*piVar10 + 0xa4))();
          FUN_01675640(param_2,"%.2f, %.2f, %.2fB, %.0f",(double)uStack_60._4_4_,
                       (double)(float)uStack_50._4_4_,(double)(float)param_3,
                       (int)*(undefined8 *)(piVar10 + 0x16),
                       (int)((ulonglong)*(undefined8 *)(piVar10 + 0x16) >> 0x20));
          FUN_005507b0();
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return param_2;
        }
        pcVar11 = pcVar2;
        if (0xf < *(uint *)(pcVar2 + 0x14)) {
          pcVar11 = *(code **)pcVar2;
        }
        cVar4 = FUN_0055c360(pcVar11,*(int *)(pcVar2 + 0x10),"OutClusters",0xb);
        if (cVar4 != '\0') {
          uStack_38 = 0;
          uStack_34 = 0xf;
          auStack_48[0] = 0;
          FUN_005542c0("Sent Cluster Packets",0x14);
          uStack_8._0_1_ = 0x21;
          FUN_008a1240(auStack_48);
          piVar10 = (int *)FUN_005cf720();
          uStack_8._0_1_ = 4;
          FUN_005507b0();
          (**(code **)(*piVar10 + 0xa4))();
          uStack_20 = 0;
          uStack_1c = 0xf;
          auStack_30[0] = 0;
          uStack_50._4_4_ = (int *)(float)*(double *)(piVar10 + 0x16);
          FUN_005542c0(&DAT_018dbc90,4);
          uStack_8._0_1_ = 0x22;
          FUN_008a1240(auStack_30);
          piVar10 = (int *)FUN_005cf720();
          (**(code **)(*piVar10 + 0xa4))();
          param_3 = (code *)(float)*(double *)(piVar10 + 0x16);
          uStack_8 = CONCAT31(uStack_8._1_3_,4);
          FUN_005507b0();
          FUN_01675640(param_2,"%.2f, %.2f, %.2fB",
                       (double)(((float)param_3 * (float)uStack_50._4_4_) / DAT_018ce324),
                       (double)(float)uStack_50._4_4_,(double)(float)param_3);
          FUN_00550b30();
          ExceptionList = pvStack_10;
          return param_2;
        }
        if (DAT_01d5be00 == '\0') {
LAB_008fa249:
          cVar4 = FUN_00558b60(pcVar2,"FreeMemory");
          if (cVar4 != '\0') {
            FUN_005f35a0();
            fVar16 = (float10)FUN_00685260();
            param_3 = (code *)(float)fVar16;
            FUN_01675640(param_2,"%.2fMB",(double)(float)param_3);
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return param_2;
          }
          cVar4 = FUN_00558b60(pcVar2,"MemoryLevel");
          if (cVar4 != '\0') {
            iVar12 = FUN_005f35a0();
            lVar1 = (longlong)*(int *)(iVar12 + 0xc4) << 0x14;
            uVar9 = FUN_01533fb0((int)lVar1,(int)((ulonglong)lVar1 >> 0x20));
            FUN_01675640(param_2,&DAT_018bed68,uVar9);
            FUN_00550b30();
            ExceptionList = pvStack_10;
            return param_2;
          }
          if ((DAT_01d5be00 == '\0') ||
             ((((cVar4 = FUN_00558b60(pcVar2,"StreamingAvgReadTimePerItem"), cVar4 == '\0' &&
                (cVar4 = FUN_00558b60(pcVar2,"StreamingAvgInstancesPerItem"), cVar4 == '\0')) &&
               (cVar4 = FUN_00558b60(pcVar2,"StreamingRequestedInstanceAvg"), cVar4 == '\0')) &&
              (((cVar4 = FUN_00558b60(pcVar2,"StreamingPendingRequestCount"), cVar4 == '\0' &&
                (cVar4 = FUN_00558b60(pcVar2,"StreamingNumRegionsToGC"), cVar4 == '\0')) &&
               ((cVar4 = FUN_00558b60(pcVar2,"StreamingGCDistance"), cVar4 == '\0' &&
                (cVar4 = FUN_00558b60(pcVar2,"StreamingNumRegions"), cVar4 == '\0')))))))) {
            cVar4 = FUN_00558b60(pcVar2,"TotalDataStats");
            if (cVar4 != '\0') {
              FUN_0054eff0("TotalOutDataBW");
              uStack_8._0_1_ = 0x32;
              FUN_008a1240(auStack_30);
              piVar10 = (int *)FUN_005cf720();
              (**(code **)(*piVar10 + 0xa4))();
              uStack_58 = *(double *)(piVar10 + 0x16) * _DAT_018e2368;
              FUN_0054eff0("TotalInDataBW");
              uStack_8 = CONCAT31(uStack_8._1_3_,0x33);
              FUN_008a1240(auStack_48);
              piVar10 = (int *)FUN_005cf720();
              (**(code **)(*piVar10 + 0xa4))();
              FUN_01675640(param_2,"%.2f KBps IN, %.2f KBps OUT",
                           *(double *)(piVar10 + 0x16) * _DAT_018e2368,SUB84(uStack_58,0),
                           (int)((ulonglong)uStack_58 >> 0x20));
LAB_008f9fb3:
              FUN_005507b0();
              FUN_005507b0();
              FUN_00550b30();
              ExceptionList = pvStack_10;
              return param_2;
            }
            cVar4 = FUN_00558b60(pcVar2,"TotalRakIOStats");
            if (cVar4 != '\0') {
              FUN_0054eff0("TotalRakOut");
              uStack_8._0_1_ = 0x34;
              FUN_008a1240(auStack_30);
              piVar10 = (int *)FUN_005cf720();
              (**(code **)(*piVar10 + 0xa4))();
              uStack_58 = *(double *)(piVar10 + 0x16) * _DAT_018e2368;
              FUN_0054eff0("TotalRakIn");
              uStack_8 = CONCAT31(uStack_8._1_3_,0x35);
              FUN_008a1240(auStack_48);
              piVar10 = (int *)FUN_005cf720();
              (**(code **)(*piVar10 + 0xa4))();
              FUN_01675640(param_2,"%.2f KB IN, %.2f KB OUT",
                           *(double *)(piVar10 + 0x16) * _DAT_018e2368,SUB84(uStack_58,0),
                           (int)((ulonglong)uStack_58 >> 0x20));
              goto LAB_008f9fb3;
            }
            cVar4 = FUN_00558b60(pcVar2,"RakNetHealthStats");
            if (cVar4 != '\0') {
              FUN_0054eff0("Stats");
              uStack_8._0_1_ = 0x36;
              uVar9 = FUN_008a1240(auStack_48);
              uVar9 = FUN_0063f7f0(uVar9);
              uStack_50 = CONCAT44(uVar9,(undefined4)uStack_50);
              uStack_8._0_1_ = 4;
              FUN_005507b0();
              if (uStack_50._4_4_ != (int *)0x0) {
                FUN_0054eff0("packetlossTotal");
                uStack_8._0_1_ = 0x37;
                FUN_008a1240(auStack_ac);
                piVar10 = (int *)FUN_005cf720();
                (**(code **)(*piVar10 + 0xa4))();
                uStack_58 = *(double *)(piVar10 + 0x16);
                FUN_0054eff0("MaxPacketLoss");
                uStack_8._0_1_ = 0x38;
                FUN_008a1240(auStack_78);
                piVar10 = (int *)FUN_005cf720();
                (**(code **)(*piVar10 + 0xa4))();
                uStack_50 = *(undefined8 *)(piVar10 + 0x16);
                FUN_0054eff0("packetlossLastSecond");
                uStack_8._0_1_ = 0x39;
                FUN_008a1240(auStack_94);
                piVar10 = (int *)FUN_005cf720();
                (**(code **)(*piVar10 + 0xa4))();
                uStack_60 = *(undefined8 *)(piVar10 + 0x16);
                FUN_0054eff0("OutBufferHealth");
                uStack_8 = CONCAT31(uStack_8._1_3_,0x3a);
                FUN_008a1240(auStack_30);
                piVar10 = (int *)FUN_005cf720();
                (**(code **)(*piVar10 + 0xa4))();
                FUN_01675640(param_2,"%.3f, %.2f %.2f, %.0f",*(undefined8 *)(piVar10 + 0x16),
                             (int)uStack_60,(int)((ulonglong)uStack_60 >> 0x20),(int)uStack_50,
                             (int)((ulonglong)uStack_50 >> 0x20),SUB84(uStack_58,0),
                             (int)((ulonglong)uStack_58 >> 0x20));
                FUN_005507b0();
                FUN_005507b0();
                FUN_005507b0();
                FUN_005507b0();
                FUN_00550b30();
                ExceptionList = pvStack_10;
                return param_2;
              }
            }
            goto LAB_008fa0eb;
          }
          FUN_0054eff0("Streaming");
          uStack_8._0_1_ = 0x2f;
          FUN_0058c540(auStack_48,uStack_20,0xffffffff);
          uStack_8._0_1_ = 0x30;
          FUN_0054eff0("Received Stream Data");
          uStack_8._0_1_ = 0x31;
          FUN_008a1240(auStack_94);
          param_3 = (code *)FUN_005cf720();
          uStack_8 = CONCAT31(uStack_8._1_3_,0x30);
          FUN_005507b0();
          if (param_3 != (code *)0x0) {
            FUN_008a1240(auStack_48);
            param_3 = (code *)FUN_005cf720();
            if (param_3 != (code *)0x0) {
              (**(code **)(*(int *)param_3 + 0xa4))();
              FUN_01675640(param_2,&DAT_018e4308,(int)*(undefined8 *)(param_3 + 0x58),
                           (int)((ulonglong)*(undefined8 *)(param_3 + 0x58) >> 0x20));
              goto LAB_008f9fb3;
            }
          }
LAB_008fa429:
          FUN_005507b0();
        }
        else {
          pcVar11 = pcVar2;
          if (0xf < *(uint *)(pcVar2 + 0x14)) {
            pcVar11 = *(code **)pcVar2;
          }
          cVar4 = FUN_0055c360(pcVar11,*(int *)(pcVar2 + 0x10),"InPhysicsCharacter",0x12);
          if (((((cVar4 == '\0') &&
                (cVar4 = FUN_00558b60(pcVar2,"InPhysicsMechanism"), cVar4 == '\0')) &&
               (cVar4 = FUN_00558b60(pcVar2,"InPhysicsCFrameOnly"), cVar4 == '\0')) &&
              ((cVar4 = FUN_00558b60(pcVar2,"InPhysicsTranslation"), cVar4 == '\0' &&
               (cVar4 = FUN_00558b60(pcVar2,"InPhysicsRotation"), cVar4 == '\0')))) &&
             (cVar4 = FUN_00558b60(pcVar2,"InPhysicsVelocity"), cVar4 == '\0')) {
            cVar4 = FUN_00558b60(pcVar2,"OutPhysicsCharacter");
            if (((cVar4 == '\0') &&
                (cVar4 = FUN_00558b60(pcVar2,"OutPhysicsMechanism"), cVar4 == '\0')) &&
               ((cVar4 = FUN_00558b60(pcVar2,"OutPhysicsCFrameOnly"), cVar4 == '\0' &&
                (((cVar4 = FUN_00558b60(pcVar2,"OutPhysicsTranslation"), cVar4 == '\0' &&
                  (cVar4 = FUN_00558b60(pcVar2,"OutPhysicsRotation"), cVar4 == '\0')) &&
                 (cVar4 = FUN_00558b60(pcVar2,"OutPhysicsVelocity"), cVar4 == '\0')))))) {
              cVar4 = FUN_00558b60(pcVar2,"InDataInstanceNew");
              if (((cVar4 == '\0') &&
                  (cVar4 = FUN_00558b60(pcVar2,"InDataInstanceDelete"), cVar4 == '\0')) &&
                 ((cVar4 = FUN_00558b60(pcVar2,"InDataPing"), cVar4 == '\0' &&
                  ((((cVar4 = FUN_00558b60(pcVar2,"InDataData"), cVar4 == '\0' &&
                     (cVar4 = FUN_00558b60(pcVar2,"InDataBehavior"), cVar4 == '\0')) &&
                    ((cVar4 = FUN_00558b60(pcVar2,"InDataState"), cVar4 == '\0' &&
                     (((cVar4 = FUN_00558b60(pcVar2,"InDataAppearance"), cVar4 == '\0' &&
                       (cVar4 = FUN_00558b60(pcVar2,"InDataTeam"), cVar4 == '\0')) &&
                      (cVar4 = FUN_00558b60(pcVar2,"InDataVideo"), cVar4 == '\0')))))) &&
                   ((cVar4 = FUN_00558b60(pcVar2,"InDataControl"), cVar4 == '\0' &&
                    (cVar4 = FUN_00558b60(pcVar2,"InDataEvents"), cVar4 == '\0')))))))) {
                cVar4 = FUN_00558b60(pcVar2,"OutDataInstanceNew");
                if ((((cVar4 == '\0') &&
                     (cVar4 = FUN_00558b60(pcVar2,"OutDataInstanceDelete"), cVar4 == '\0')) &&
                    ((cVar4 = FUN_00558b60(pcVar2,"OutDataPing"), cVar4 == '\0' &&
                     (((((cVar4 = FUN_00558b60(pcVar2,"OutDataData"), cVar4 == '\0' &&
                         (cVar4 = FUN_00558b60(pcVar2,"OutDataBehavior"), cVar4 == '\0')) &&
                        (cVar4 = FUN_00558b60(pcVar2,"OutDataState"), cVar4 == '\0')) &&
                       ((cVar4 = FUN_00558b60(pcVar2,"OutDataAppearance"), cVar4 == '\0' &&
                        (cVar4 = FUN_00558b60(pcVar2,"OutDataTeam"), cVar4 == '\0')))) &&
                      (cVar4 = FUN_00558b60(pcVar2,"OutDataVideo"), cVar4 == '\0')))))) &&
                   ((cVar4 = FUN_00558b60(pcVar2,"OutDataControl"), cVar4 == '\0' &&
                    (cVar4 = FUN_00558b60(pcVar2,"OutDataEvents"), cVar4 == '\0'))))
                goto LAB_008fa249;
                FUN_0054eff0("OutData");
                uStack_8._0_1_ = 0x2c;
                FUN_0058c540(auStack_48,uStack_20,0xffffffff);
                uStack_8._0_1_ = 0x2d;
                FUN_0054eff0("Send Data Types");
                uStack_8._0_1_ = 0x2e;
                FUN_008a1240(auStack_94);
                param_3 = (code *)FUN_005cf720();
                uStack_8 = CONCAT31(uStack_8._1_3_,0x2d);
              }
              else {
                FUN_0054eff0("InData");
                uStack_8._0_1_ = 0x29;
                FUN_0058c540(auStack_48,uStack_20,0xffffffff);
                uStack_8._0_1_ = 0x2a;
                FUN_0054eff0("Received Data Types");
                uStack_8._0_1_ = 0x2b;
                FUN_008a1240(auStack_94);
                param_3 = (code *)FUN_005cf720();
                uStack_8 = CONCAT31(uStack_8._1_3_,0x2a);
              }
              FUN_005507b0();
              if (param_3 != (code *)0x0) {
                FUN_008a1240(auStack_48);
                iVar5 = FUN_005cf720();
                if (iVar5 != 0) {
                  FUN_008f7020(param_2,iVar5);
                  goto LAB_008f9fb3;
                }
              }
              goto LAB_008fa429;
            }
            uStack_68 = 0;
            uStack_64 = 0xf;
            auStack_78[0] = 0;
            FUN_005542c0("OutPhysics",10);
            uStack_8._0_1_ = 0x26;
            FUN_0058c540(auStack_48,uStack_68,0xffffffff);
            uStack_8._0_1_ = 0x27;
            FUN_0054eff0("OutPhysicsDetails");
            uStack_8._0_1_ = 0x28;
            FUN_008a1240(auStack_30);
            param_3 = (code *)FUN_005cf720();
            uStack_8 = CONCAT31(uStack_8._1_3_,0x27);
            FUN_005507b0();
            if (param_3 != (code *)0x0) {
              FUN_008a1240(auStack_48);
              iVar5 = FUN_005cf720();
              if (iVar5 != 0) {
                FUN_008f7020(param_2,iVar5);
                FUN_005507b0();
                FUN_005507b0();
                FUN_00550b30();
                ExceptionList = pvStack_10;
                return param_2;
              }
            }
          }
          else {
            uStack_68 = 0;
            uStack_64 = 0xf;
            auStack_78[0] = 0;
            FUN_005542c0("InPhysics",9);
            uStack_8._0_1_ = 0x23;
            FUN_0058c540(auStack_30,uStack_68,0xffffffff);
            uStack_8._0_1_ = 0x24;
            uStack_38 = 0;
            uStack_34 = 0xf;
            auStack_48[0] = 0;
            FUN_005542c0("InPhysicsDetails",0x10);
            uStack_8._0_1_ = 0x25;
            FUN_008a1240(auStack_48);
            param_3 = (code *)FUN_005cf720();
            uStack_8 = CONCAT31(uStack_8._1_3_,0x24);
            FUN_005507b0();
            if (param_3 != (code *)0x0) {
              FUN_008a1240(auStack_30);
              iVar5 = FUN_005cf720();
              if (iVar5 != 0) {
                FUN_008f7020(param_2,iVar5);
                FUN_005507b0();
                FUN_005507b0();
                FUN_00550b30();
                ExceptionList = pvStack_10;
                return param_2;
              }
            }
          }
          FUN_005507b0();
        }
        FUN_005507b0();
      }
    }
LAB_008fa0eb:
    uStack_8 = 0xffffffff;
    FUN_00550b30();
  }
  cVar4 = FUN_00558b60(pcVar2,&DAT_018cb3fc);
  if (cVar4 == '\0') {
    cVar4 = FUN_00558b60(pcVar2,"PhysicsReal");
    if (cVar4 != '\0') {
      fVar17 = (float10)FUN_00bbd8f0();
      fVar16 = (float10)DAT_018ce318;
      dStack_18 = (double)(fVar17 * fVar16);
      fVar18 = (float10)FUN_00bbd8f0();
      param_3 = (code *)(float)fVar18;
      fVar18 = (float10)FUN_00999e90();
      dStack_18 = (double)(fVar18 * (float10)(float)param_3);
      FUN_01675640(param_2,"%.1f/s  throttle@%d%%",dStack_18,(int)(fVar17 * fVar16));
      ExceptionList = pvStack_10;
      return param_2;
    }
    cVar4 = FUN_00558b60(pcVar2,"Heartbeat");
    if (cVar4 == '\0') {
      cVar4 = FUN_00558b60(pcVar2,"Network Send");
      if ((cVar4 == '\0') && (cVar4 = FUN_00558b60(pcVar2,"Network Receive"), cVar4 == '\0')) {
        cVar4 = FUN_00558b60(pcVar2,"Render");
        if (cVar4 == '\0') {
          cVar4 = FUN_00558b60(pcVar2,"MouseMove");
          if (cVar4 != '\0') {
            fVar16 = (float10)FUN_00646790();
            dStack_18 = (double)fVar16;
            fVar16 = (float10)FUN_00646790();
            uStack_58 = (double)fVar16;
            FUN_01675640(param_2,"%.1f/s -> %.1f/s",uStack_58,SUB84(dStack_18,0),
                         (int)((ulonglong)dStack_18 >> 0x20));
            ExceptionList = pvStack_10;
            return param_2;
          }
          cVar4 = FUN_00558b60(pcVar2,"Effective FPS");
          if (cVar4 == '\0') {
            cVar4 = FUN_00558b60(pcVar2,"Render Nominal FPS");
            if (cVar4 != '\0') {
              param_3 = *(code **)(**(int **)(param_1 + 0x1d4) + 8);
              fVar16 = (float10)(*param_3)(pcVar2);
              FUN_01675640(param_2,"%.1f/s",(double)fVar16);
              ExceptionList = pvStack_10;
              return param_2;
            }
            cVar4 = FUN_00558b60(pcVar2,"Delta Between Renders");
            if (cVar4 != '\0') {
              param_3 = *(code **)(**(int **)(param_1 + 0x1d4) + 8);
              fVar16 = (float10)(*param_3)(pcVar2);
              FUN_01675640(param_2,&DAT_0192c008,(double)fVar16);
              ExceptionList = pvStack_10;
              return param_2;
            }
            cVar4 = FUN_00558b60(pcVar2,"Total Render");
            if (cVar4 != '\0') {
              param_3 = *(code **)(**(int **)(param_1 + 0x1d4) + 8);
              fVar16 = (float10)(*param_3)(pcVar2);
              FUN_01675640(param_2,&DAT_0192c008,(double)fVar16);
              ExceptionList = pvStack_10;
              return param_2;
            }
            cVar4 = FUN_00558b60(pcVar2,"Render Prepare");
            if (cVar4 != '\0') {
              param_3 = *(code **)(**(int **)(param_1 + 0x1d4) + 8);
              fVar16 = (float10)(*param_3)(pcVar2);
              FUN_01675640(param_2,&DAT_0192c008,(double)fVar16);
              ExceptionList = pvStack_10;
              return param_2;
            }
            cVar4 = FUN_00558b60(pcVar2,"Present Time");
            if (cVar4 != '\0') {
              param_3 = *(code **)(**(int **)(param_1 + 0x1d4) + 8);
              fVar16 = (float10)(*param_3)(pcVar2);
              FUN_01675640(param_2,&DAT_0192c008,(double)fVar16);
              ExceptionList = pvStack_10;
              return param_2;
            }
            cVar4 = FUN_00558b60(pcVar2,"GPU Delay");
            if (cVar4 != '\0') {
              param_3 = *(code **)(**(int **)(param_1 + 0x1d4) + 8);
              fVar16 = (float10)(*param_3)(pcVar2);
              FUN_01675640(param_2,&DAT_0192c008,(double)fVar16);
              ExceptionList = pvStack_10;
              return param_2;
            }
            cVar4 = FUN_00558b60(pcVar2,"RequestQueueSize");
            if (cVar4 == '\0') {
              cVar4 = FUN_00558b60(pcVar2,"drawId");
              if (cVar4 != '\0') {
                FUN_009ee270(param_2,param_1 + 0x1d0);
                ExceptionList = pvStack_10;
                return param_2;
              }
              cVar4 = FUN_00558b60(pcVar2,"worldId");
              if (cVar4 == '\0') {
                cVar4 = FUN_00558b60(pcVar2,"Graphics Mode");
                if (cVar4 == '\0') {
                  cVar4 = FUN_00558b60(pcVar2,"Particles");
                  if (cVar4 != '\0') {
                    param_3 = *(code **)(**(int **)(param_1 + 0x1d4) + 8);
                    fVar16 = (float10)(*param_3)(pcVar2);
                    dStack_18 = (double)fVar16;
                    uStack_58 = (double)CONCAT44((int)fVar16,(undefined4)uStack_58);
                    FUN_009ee270(param_2,(int)&uStack_58 + 4);
                    ExceptionList = pvStack_10;
                    return param_2;
                  }
                  cVar4 = FUN_00558b60(pcVar2,"Shadow Casters");
                  if (cVar4 != '\0') {
                    param_3 = *(code **)(**(int **)(param_1 + 0x1d4) + 8);
                    fVar16 = (float10)(*param_3)(pcVar2);
                    dStack_18 = (double)fVar16;
                    uStack_58 = (double)CONCAT44((int)fVar16,(undefined4)uStack_58);
                    FUN_009ee270(param_2,(int)&uStack_58 + 4);
                    ExceptionList = pvStack_10;
                    return param_2;
                  }
                  cVar4 = FUN_00558b60(pcVar2,"Bevels");
                  if (cVar4 == '\0') {
                    cVar4 = FUN_00558b60(pcVar2,"Video Memory");
                    if (cVar4 != '\0') {
                      param_3 = *(code **)(**(int **)(param_1 + 0x1d4) + 8);
                      (*param_3)(pcVar2);
                      uVar9 = FUN_016f4180();
                      FUN_009ff9e0(param_2,uVar9);
                      ExceptionList = pvStack_10;
                      return param_2;
                    }
                    cVar4 = FUN_00558b60(pcVar2,"Player Radius");
                    if (cVar4 != '\0') {
                      iVar12 = FUN_0063f120(uStack_60._4_4_);
                      iVar12 = (*(int **)(iVar12 + 0xb8))[1] - **(int **)(iVar12 + 0xb8) >> 3;
                      if (iVar12 != 0) {
                        FUN_005d57a0(&dStack_18);
                        fVar20 = 0.0;
                        uStack_8 = 0x40;
                        fVar21 = 0.0;
                        for (piVar10 = (int *)*dStack_18._0_4_; piVar10 != (int *)dStack_18._0_4_[1]
                            ; piVar10 = piVar10 + 2) {
                          fVar20 = fVar20 + *(float *)(*piVar10 + 0x188);
                          fVar21 = fVar21 + *(float *)(*piVar10 + 0x18c);
                        }
                        fVar19 = (float)iVar12;
                        FUN_01675640(param_2,"%d / %d",(int)(fVar20 / fVar19),(int)(fVar21 / fVar19)
                                    );
                        FUN_00550b30();
                        ExceptionList = pvStack_10;
                        return param_2;
                      }
                      FUN_0054eff0(&DAT_018d27e8);
                      ExceptionList = pvStack_10;
                      return param_2;
                    }
                    cVar4 = FUN_00558b60(pcVar2,"numPrimitives");
                    if (cVar4 != '\0') {
                      FUN_009ee270(param_2,param_1 + 0x22c);
                      ExceptionList = pvStack_10;
                      return param_2;
                    }
                    cVar4 = FUN_00558b60(pcVar2,"numMovingPrimitives");
                    if (cVar4 == '\0') {
                      cVar4 = FUN_00558b60(pcVar2,"numJoints");
                      if (cVar4 == '\0') {
                        cVar4 = FUN_00558b60(pcVar2,"numInstances");
                        iVar5 = DAT_01ea851c;
                        if (cVar4 == '\0') {
                          cVar4 = FUN_00558b60(pcVar2,"numContactsAll");
                          if (cVar4 != '\0') {
                            uVar9 = FUN_00bbdc60(2);
                            uVar13 = FUN_00bbdc60(1);
                            uVar14 = FUN_00bbdc60(0);
                            uVar15 = FUN_00bbdd30();
                            FUN_01675640(param_2,"%d  %d  %d  %d",uVar15,uVar14,uVar13,uVar9);
                            ExceptionList = pvStack_10;
                            return param_2;
                          }
                          cVar4 = FUN_00558b60(pcVar2,"numContacts");
                          if (cVar4 == '\0') {
                            cVar4 = FUN_00558b60(pcVar2,"numContactsInCollisionStage");
                            if (cVar4 == '\0') {
                              cVar4 = FUN_00558b60(pcVar2,"numSteppingContacts");
                              if (cVar4 == '\0') {
                                cVar4 = FUN_00558b60(pcVar2,"numTouchingContacts");
                                if (cVar4 == '\0') {
                                  cVar4 = FUN_00558b60(pcVar2,"maxTreeDepth");
                                  if (cVar4 == '\0') {
                                    cVar4 = FUN_00558b60(pcVar2,"contactPairHitRatio");
                                    if ((cVar4 != '\0') ||
                                       (cVar4 = FUN_00558b60(pcVar2,"contactFeatureHitRatio"),
                                       cVar4 != '\0')) {
LAB_008faf8f:
                                      param_3 = (code *)0x0;
                                      FUN_009ee330(param_2,&param_3);
                                      ExceptionList = pvStack_10;
                                      return param_2;
                                    }
                                    cVar4 = FUN_00558b60(pcVar2,"numLinkCalls");
                                    if (cVar4 == '\0') {
                                      cVar4 = FUN_00558b60(pcVar2,"numHashNodes");
                                      if (cVar4 == '\0') {
                                        cVar4 = FUN_00558b60(pcVar2,"maxBucketSize");
                                        if (cVar4 == '\0') {
                                          cVar4 = FUN_00558b60(pcVar2,"environmentSpeed");
                                          if (cVar4 != '\0') {
                                            fVar16 = (float10)FUN_00bbd8f0();
LAB_008fb030:
                                            param_3 = (code *)(float)fVar16;
                                            FUN_009ee330(param_2,&param_3);
                                            ExceptionList = pvStack_10;
                                            return param_2;
                                          }
                                          cVar4 = FUN_00558b60(pcVar2,"gravity");
                                          if (cVar4 != '\0') {
                                            param_3 = *(code **)(iVar12 + 0xc4);
                                            FUN_009ee330(param_2,&param_3);
                                            ExceptionList = pvStack_10;
                                            return param_2;
                                          }
                                          cVar4 = FUN_00558b60(pcVar2,"targetWorldStepsPerFrame");
                                          if (cVar4 != '\0') {
                                            FUN_008bbce0();
                                            FUN_009cb090(param_2,*(undefined4 *)
                                                                  (*(int *)(param_1 + 0x1b8) + 0x310
                                                                  ));
                                            ExceptionList = pvStack_10;
                                            return param_2;
                                          }
                                          cVar4 = FUN_00558b60(pcVar2,"pGSSolverActive");
                                          if (cVar4 != '\0') {
                                            param_3 = (code *)CONCAT13(1,param_3._0_3_);
                                            FUN_009ee570(param_2,(int)&param_3 + 3);
                                            ExceptionList = pvStack_10;
                                            return param_2;
                                          }
                                          cVar4 = FUN_00558b60(pcVar2,"numBodiesAll");
                                          if (cVar4 != '\0') {
                                            uVar9 = *(undefined4 *)(*(int *)(iVar12 + 0x6f0) + 0xc);
LAB_008fb0f5:
                                            FUN_01675640(param_2,&DAT_018bed68,uVar9);
                                            ExceptionList = pvStack_10;
                                            return param_2;
                                          }
                                          cVar4 = FUN_00558b60(pcVar2,"numConnectorsAll");
                                          if (cVar4 != '\0') {
                                            uVar9 = FUN_00f38230();
                                            uVar13 = FUN_00f38240();
                                            uVar14 = FUN_00f38220();
                                            uVar15 = FUN_00f38210();
                                            FUN_01675640(param_2,"%d %d %d %d",uVar15,uVar14,uVar13,
                                                         uVar9);
                                            ExceptionList = pvStack_10;
                                            return param_2;
                                          }
                                          cVar4 = FUN_00558b60(pcVar2,"numBodies");
                                          if (cVar4 == '\0') {
                                            cVar4 = FUN_00558b60(pcVar2,"maxBodies");
                                            if (cVar4 != '\0') {
                                              iVar5 = *(int *)(*(int *)(iVar12 + 0x6f0) + 0xc);
                                              goto LAB_008fabd4;
                                            }
                                            cVar4 = FUN_00558b60(pcVar2,"numLeafBodies");
                                            if (cVar4 == '\0') {
                                              cVar4 = FUN_00558b60(pcVar2,"numConnectorsAndPoints");
                                              if (cVar4 != '\0') {
                                                uVar9 = FUN_00f38210();
                                                goto LAB_008fb0f5;
                                              }
                                              cVar4 = FUN_00558b60(pcVar2,"numIterations");
                                              if (cVar4 != '\0') {
                                                iVar12 = *(int *)(iVar12 + 0x6f0);
                                                FUN_01675640(param_2,"%d %d (%f %f)",
                                                             *(undefined4 *)(iVar12 + 0x18),
                                                             *(undefined4 *)(iVar12 + 0x14),
                                                             (double)*(float *)(iVar12 + 0x20),
                                                             (double)*(float *)(iVar12 + 0x1c));
                                                ExceptionList = pvStack_10;
                                                return param_2;
                                              }
                                              cVar4 = FUN_00558b60(pcVar2,"numConstraints");
                                              if (cVar4 != '\0') {
                                                iVar5 = FUN_00f38210();
                                                goto LAB_008fabd4;
                                              }
                                              cVar4 = FUN_00558b60(pcVar2,"numPoints");
                                              if (cVar4 == '\0') {
                                                cVar4 = FUN_00558b60(pcVar2,
                                                  "percentConnectorsActive");
                                                if (cVar4 != '\0') goto LAB_008faf8f;
                                                cVar4 = FUN_00558b60(pcVar2,"energyBody");
                                                if (cVar4 == '\0') {
                                                  cVar4 = FUN_00558b60(pcVar2,"energyConnector");
                                                  if (cVar4 == '\0') {
                                                    cVar4 = FUN_00558b60(pcVar2,"energyTotal");
                                                    if (cVar4 != '\0') {
                                                      fVar16 = (float10)FUN_0090ce20();
                                                      uStack_50 = CONCAT44((float)fVar16,
                                                                           (undefined4)uStack_50);
                                                      FUN_009ee330(param_2,(int)&uStack_50 + 4);
                                                      ExceptionList = pvStack_10;
                                                      return param_2;
                                                    }
                                                    FUN_0054eff0(&DAT_018d743c);
                                                    ExceptionList = pvStack_10;
                                                    return param_2;
                                                  }
                                                  fVar16 = (float10)FUN_00926d70();
                                                }
                                                else {
                                                  fVar16 = (float10)FUN_00926d70();
                                                }
                                                goto LAB_008fb030;
                                              }
                                            }
                                          }
                                          param_3 = (code *)0x0;
                                          iVar5 = (int)param_3;
                                        }
                                        else {
                                          iVar5 = FUN_00bbdc40();
                                        }
                                      }
                                      else {
                                        iVar5 = FUN_00bbdd40();
                                      }
                                    }
                                    else {
                                      iVar5 = *(int *)(iVar12 + 0x644);
                                    }
                                  }
                                  else {
                                    iVar5 = FUN_00bbdc60(3);
                                  }
                                }
                                else {
                                  iVar5 = FUN_00bbdc60(2);
                                }
                              }
                              else {
                                iVar5 = FUN_00bbdc60(1);
                              }
                            }
                            else {
                              iVar5 = FUN_00bbdc60(0);
                            }
                          }
                          else {
                            iVar5 = FUN_00bbdd30();
                          }
                        }
                      }
                      else {
                        param_3 = *(code **)(iVar12 + 0x63c);
                        iVar12 = FUN_008e4510(uStack_60._4_4_);
                        iVar5 = (int)param_3;
                        if (iVar12 != 0) {
                          iVar12 = FUN_005d6c30();
                          iVar5 = (int)param_3 + iVar12;
                        }
                      }
                    }
                    else {
                      iVar5 = *(int *)(*(int *)(param_1 + 0x1b8) + 0x160);
                    }
                    goto LAB_008fabd4;
                  }
                }
LAB_008f883d:
                (**(code **)(**(int **)(param_1 + 0x1d4) + 4))(param_2,pcVar2);
                ExceptionList = pvStack_10;
                return param_2;
              }
              iVar5 = *(int *)(iVar12 + 0x50);
            }
            else {
              FUN_005c2760();
              iVar5 = FUN_008ce8b0();
            }
LAB_008fabd4:
            param_3 = (code *)iVar5;
            FUN_009ee270(param_2,&param_3);
            ExceptionList = pvStack_10;
            return param_2;
          }
          param_3 = *(code **)(**(int **)(param_1 + 0x1d4) + 8);
          FUN_0054eff0("Delta Between Renders");
          uStack_8 = 0x3f;
          fVar16 = (float10)(*param_3)(auStack_ac);
          FUN_01675640(param_2,"%.1f/s",(double)((float10)DAT_018c0d70 / fVar16));
        }
        else {
          param_3 = *(code **)(**(int **)(param_1 + 0x1d4) + 8);
          FUN_0054eff0("Render Duty");
          uStack_8 = 0x3c;
          fVar16 = (float10)(*param_3)(auStack_30);
          dStack_18 = (double)(fVar16 * (float10)DAT_018ce318);
          param_3 = *(code **)(**(int **)(param_1 + 0x1d4) + 8);
          FUN_0054eff0("Render Job Time");
          uStack_8._0_1_ = 0x3d;
          fVar16 = (float10)(*param_3)(auStack_48);
          dStack_18 = (double)(fVar16 * (float10)DAT_018c0d70);
          param_3 = *(code **)(**(int **)(param_1 + 0x1d4) + 8);
          FUN_0054eff0("Render FPS");
          uStack_8 = CONCAT31(uStack_8._1_3_,0x3e);
          fVar16 = (float10)(*param_3)(auStack_ac);
          uStack_58 = (double)fVar16;
          FUN_01675640();
          FUN_005507b0();
          FUN_005507b0();
        }
      }
      else {
        piVar10 = *(int **)(param_1 + 0x1d8);
        if (piVar10 == (int *)0x0) {
          uVar9 = FUN_0054eff0(&DAT_018bc9b8);
        }
        else {
          uVar9 = (**(code **)(*piVar10 + 4))(auStack_48,pcVar2);
        }
        FUN_0054ef20(uVar9);
        if (piVar10 == (int *)0x0) {
          FUN_005507b0();
          ExceptionList = pvStack_10;
          return param_2;
        }
      }
LAB_008fb377:
      FUN_005507b0();
      ExceptionList = pvStack_10;
      return param_2;
    }
    fVar16 = (float10)FUN_009994c0();
    dStack_18 = (double)(fVar16 * (float10)DAT_018ce318);
    fVar16 = (float10)FUN_009994b0();
    dStack_18 = (double)(fVar16 * (float10)DAT_018c0d70);
    fVar16 = (float10)FUN_009994d0();
  }
  else {
    fVar16 = (float10)FUN_009997c0();
    dStack_18 = (double)(fVar16 * (float10)DAT_018ce318);
    fVar16 = (float10)FUN_009997b0();
    dStack_18 = (double)(fVar16 * (float10)DAT_018c0d70);
    fVar16 = (float10)FUN_00999e90();
  }
  uStack_58 = (double)fVar16;
  FUN_01675640();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15777 ; VA 0x008fb3a0 ; FUN_008fb3a0 */

float10 __thiscall FUN_008fb3a0(int param_1,undefined4 *param_2)

{
  code *pcVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  undefined4 *puVar5;
  int *piVar6;
  undefined4 uVar7;
  uint uVar8;
  bool bVar9;
  float10 fVar10;
  undefined auStack_54 [16];
  undefined4 uStack_44;
  undefined4 uStack_40;
  uint auStack_3c [4];
  undefined4 uStack_2c;
  uint uStack_28;
  undefined auStack_24 [4];
  double dStack_20;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c444a;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uVar4 = param_2[5];
  puVar5 = param_2;
  if (0xf < uVar4) {
    puVar5 = (undefined4 *)*param_2;
  }
  ExceptionList = &pvStack_10;
  cVar2 = FUN_0055c360(puVar5,param_2[4],"Render FPS",10);
  if (cVar2 != '\0') {
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = auStack_3c[0] & 0xffffff00;
    pcVar1 = *(code **)(**(int **)(param_1 + 0x1d4) + 8);
    FUN_005542c0("Render FPS",10);
    uStack_8 = 0;
    fVar10 = (float10)(*pcVar1)(auStack_3c);
    dStack_20 = (double)fVar10;
    if (uStack_28 < 0x10) {
      ExceptionList = pvStack_10;
      return fVar10;
    }
    uVar8 = uStack_28 + 1;
    uVar4 = auStack_3c[0];
    if (0xfff < uVar8) {
      uVar4 = *(uint *)(auStack_3c[0] - 4);
      uVar8 = uStack_28 + 0x24;
      if (0x1f < (auStack_3c[0] - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar8);
    ExceptionList = pvStack_10;
    return (float10)dStack_20;
  }
  puVar5 = param_2;
  if (0xf < uVar4) {
    puVar5 = (undefined4 *)*param_2;
  }
  cVar2 = FUN_0055c360(puVar5,param_2[4],"Render CPU",10);
  if (cVar2 != '\0') {
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = auStack_3c[0] & 0xffffff00;
    pcVar1 = *(code **)(**(int **)(param_1 + 0x1d4) + 8);
    FUN_005542c0("Render Duty",0xb);
    uStack_8 = 1;
    fVar10 = (float10)(*pcVar1)(auStack_3c);
    dStack_20 = (double)(fVar10 * (float10)DAT_018ce318);
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return (float10)dStack_20;
  }
  puVar5 = param_2;
  if (0xf < uVar4) {
    puVar5 = (undefined4 *)*param_2;
  }
  cVar2 = FUN_0055c360(puVar5,param_2[4],"Render Time",0xb);
  if (cVar2 != '\0') {
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = auStack_3c[0] & 0xffffff00;
    pcVar1 = *(code **)(**(int **)(param_1 + 0x1d4) + 8);
    FUN_005542c0("Render Job Time",0xf);
    uStack_8 = 2;
    fVar10 = (float10)(*pcVar1)(auStack_3c);
    dStack_20 = (double)(fVar10 * (float10)DAT_018c0d70);
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return (float10)dStack_20;
  }
  puVar5 = param_2;
  if (0xf < uVar4) {
    puVar5 = (undefined4 *)*param_2;
  }
  cVar2 = FUN_0055c360(puVar5,param_2[4],"Physics FPS",0xb);
  if (cVar2 != '\0') {
    fVar10 = (float10)FUN_00999e90();
    ExceptionList = pvStack_10;
    return fVar10;
  }
  puVar5 = param_2;
  if (0xf < uVar4) {
    puVar5 = (undefined4 *)*param_2;
  }
  cVar2 = FUN_0055c360(puVar5,param_2[4],"Physics CPU",0xb);
  if (cVar2 != '\0') {
    fVar10 = (float10)FUN_009997c0();
    ExceptionList = pvStack_10;
    return fVar10 * (float10)DAT_018ce318;
  }
  puVar5 = param_2;
  if (0xf < uVar4) {
    puVar5 = (undefined4 *)*param_2;
  }
  cVar2 = FUN_0055c360(puVar5,param_2[4],"Physics Time",0xc);
  if (cVar2 != '\0') {
    fVar10 = (float10)FUN_009997b0();
    ExceptionList = pvStack_10;
    return fVar10 * (float10)DAT_018c0d70;
  }
  puVar5 = param_2;
  if (0xf < uVar4) {
    puVar5 = (undefined4 *)*param_2;
  }
  cVar2 = FUN_0055c360(puVar5,param_2[4],"Network Receive CPU",0x13);
  if (cVar2 == '\0') {
    puVar5 = param_2;
    if (0xf < uVar4) {
      puVar5 = (undefined4 *)*param_2;
    }
    cVar2 = FUN_0055c360(puVar5,param_2[4],"Network Receive Time",0x14);
    if (cVar2 != '\0') {
      if (*(int **)(param_1 + 0x1d8) == (int *)0x0) {
        bVar9 = (uStack_14 & 2) == 0;
        fVar10 = (float10)0.0;
      }
      else {
        uStack_2c = 0;
        pcVar1 = *(code **)(**(int **)(param_1 + 0x1d8) + 8);
        uStack_28 = 0xf;
        auStack_3c[0] = auStack_3c[0] & 0xffffff00;
        FUN_005542c0("Network Receive Time",0x14);
        uStack_8 = 4;
        uStack_14 = 2;
        fVar10 = (float10)(*pcVar1)(auStack_3c);
        bVar9 = (uStack_14 & 2) == 0;
      }
      goto LAB_008fb6d0;
    }
    puVar5 = param_2;
    if (0xf < uVar4) {
      puVar5 = (undefined4 *)*param_2;
    }
    cVar2 = FUN_0055c360(puVar5,param_2[4],"Frame Time",10);
    if (cVar2 == '\0') {
      puVar5 = param_2;
      if (0xf < uVar4) {
        puVar5 = (undefined4 *)*param_2;
      }
      cVar2 = FUN_0055c360(puVar5,param_2[4],"Effective FPS",0xd);
      if (cVar2 != '\0') {
        uStack_2c = 0;
        uStack_28 = 0xf;
        auStack_3c[0] = auStack_3c[0] & 0xffffff00;
        pcVar1 = *(code **)(**(int **)(param_1 + 0x1d4) + 8);
        FUN_005542c0("Delta Between Renders",0x15);
        uStack_8 = 6;
        fVar10 = (float10)(*pcVar1)(auStack_3c);
        dStack_20 = (double)((float10)DAT_018c0d70 / fVar10);
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return (float10)dStack_20;
      }
      iVar3 = FUN_005cf810();
      if (iVar3 == 0) {
LAB_008fb9d5:
        ExceptionList = pvStack_10;
        return (float10)0;
      }
      uStack_2c = 0;
      uStack_28 = 0xf;
      auStack_3c[0] = auStack_3c[0] & 0xffffff00;
      FUN_005542c0(&DAT_018c5904,7);
      uStack_8 = 7;
      iVar3 = FUN_008a1240(auStack_3c);
      if (iVar3 == 0) {
        iVar3 = 0;
      }
      else {
        iVar3 = iVar3 + 4;
      }
      FUN_0060ddd0(&iStack_18,iVar3);
      uStack_8._0_1_ = 9;
      FUN_005507b0();
      if (((iStack_18 == 0) || (uVar4 = FUN_005d6c30(), uVar4 < 2)) ||
         (*(int *)(**(int **)(iStack_18 + 0x2c) + 8) == 0)) {
        FUN_00550b30();
        goto LAB_008fb9d5;
      }
      uVar4 = param_2[5];
      uVar7 = param_2[4];
      puVar5 = param_2;
      if (0xf < uVar4) {
        puVar5 = (undefined4 *)*param_2;
      }
      cVar2 = FUN_0055c360(puVar5,uVar7,"Received Physics Packets",0x18);
      if (cVar2 == '\0') {
        if (0xf < uVar4) {
          param_2 = (undefined4 *)*param_2;
        }
        cVar2 = FUN_0055c360(param_2,uVar7,"Data Ping",9);
        if (cVar2 == '\0') {
          uStack_8 = 0xffffffff;
          FUN_00550b30();
          uVar7 = FUN_005543f0();
          FUN_016756b0(auStack_24,"%s is not a valid metric.",uVar7);
                    /* WARNING: Subroutine does not return */
          FUN_0170c2a8(auStack_24,&DAT_01c17198);
        }
        uStack_44 = 0;
        uStack_40 = 0xf;
        auStack_54[0] = 0;
        FUN_005542c0("Data Ping",9);
        uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
      }
      else {
        uStack_44 = 0;
        uStack_40 = 0xf;
        auStack_54[0] = 0;
        FUN_005542c0("Received Physics Packets",0x18);
        uStack_8 = CONCAT31(uStack_8._1_3_,10);
      }
      FUN_008a1240(auStack_54);
      piVar6 = (int *)FUN_005cf720();
      (**(code **)(*piVar6 + 0xa4))();
      dStack_20 = *(double *)(piVar6 + 0x16);
      FUN_005507b0();
      FUN_00550b30();
      goto LAB_008fb6dd;
    }
    uStack_2c = 0;
    uStack_28 = 0xf;
    auStack_3c[0] = auStack_3c[0] & 0xffffff00;
    pcVar1 = *(code **)(**(int **)(param_1 + 0x1d4) + 8);
    FUN_005542c0("Delta Between Renders",0x15);
    uStack_8 = 5;
    fVar10 = (float10)(*pcVar1)(auStack_3c);
    dStack_20 = (double)fVar10;
  }
  else {
    if (*(int **)(param_1 + 0x1d8) == (int *)0x0) {
      fVar10 = (float10)0.0;
    }
    else {
      uStack_2c = 0;
      pcVar1 = *(code **)(**(int **)(param_1 + 0x1d8) + 8);
      uStack_28 = 0xf;
      auStack_3c[0] = auStack_3c[0] & 0xffffff00;
      FUN_005542c0("Network Receive CPU",0x13);
      uStack_8 = 3;
      uStack_14 = 1;
      fVar10 = (float10)(*pcVar1)(auStack_3c);
    }
    bVar9 = (uStack_14 & 1) == 0;
LAB_008fb6d0:
    dStack_20 = (double)fVar10;
    if (bVar9) goto LAB_008fb6dd;
  }
  FUN_005507b0();
LAB_008fb6dd:
  ExceptionList = pvStack_10;
  return (float10)dStack_20;
}



/* FUNCTION 15778 ; VA 0x008fba30 ; FUN_008fba30 */

int FUN_008fba30(void)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_00564080();
  if (*piVar1 == 0) {
    return 0;
  }
  piVar1 = *(int **)(*piVar1 + 0xb8);
  return piVar1[1] - *piVar1 >> 3;
}



/* FUNCTION 15779 ; VA 0x008fba50 ; FUN_008fba50 */

undefined4 * __thiscall FUN_008fba50(int param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  undefined4 *puStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c4468;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piStack_14 = (int *)(param_1 + 0x330);
  FUN_005875d0(&param_2,param_2);
  puVar5 = param_2;
  if (param_2 != *(undefined4 **)(param_1 + 0x330)) {
    piVar3 = param_2 + 4;
    if (0xf < (uint)param_2[9]) {
      piVar3 = (int *)*piVar3;
    }
    puVar7 = puVar2;
    if (0xf < (uint)puVar2[5]) {
      puVar7 = (undefined4 *)*puVar2;
    }
    iVar4 = FUN_0055c2d0(puVar7,puVar2[4],piVar3,param_2[8]);
    if (-1 < iVar4) {
      ExceptionList = pvStack_10;
      return (undefined4 *)puVar5[10];
    }
  }
  puVar5 = (undefined4 *)FUN_01674e20(0x14);
  param_2 = puVar5;
  if (puVar5 == (undefined4 *)0x0) {
    puVar5 = (undefined4 *)0x0;
  }
  else {
    *puVar5 = 0;
    puVar5[1] = 0;
    puVar5[2] = 0;
    puVar5[3] = 0;
    *(undefined *)(puVar5 + 4) = 0;
    puVar5[2] = 0;
    piVar3 = (int *)puVar5[3];
    puVar5[3] = 0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
    *puVar5 = 0;
    piVar3 = (int *)puVar5[1];
    puVar5[1] = 0;
    if (piVar3 != (int *)0x0) {
      LOCK();
      iVar4 = piVar3[2] + -1;
      piVar3[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  FUN_008de1d0(puVar5,param_2);
  uStack_8 = 0;
  FUN_005875d0(&param_2,puVar2);
  puVar7 = param_2;
  if (param_2 != (undefined4 *)*piStack_14) {
    puVar6 = param_2 + 4;
    if (0xf < (uint)param_2[9]) {
      puVar6 = (undefined4 *)*puVar6;
    }
    puVar8 = puVar2;
    if (0xf < (uint)puVar2[5]) {
      puVar8 = (undefined4 *)*puVar2;
    }
    iVar4 = FUN_0055c2d0(puVar8,puVar2[4],puVar6,param_2[8]);
    if (-1 < iVar4) goto LAB_008fbbdc;
  }
  puStack_18 = puVar2;
  iVar4 = FUN_00559280(&DAT_018bdeda,&puStack_18,(int)&param_2 + 3);
  FUN_008dd9c0(&param_2,puVar7,iVar4 + 0x10,iVar4);
  puVar7 = param_2;
LAB_008fbbdc:
  puVar7[10] = 0;
  piVar3 = (int *)puVar7[0xb];
  puVar7[0xb] = 0;
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar4 = piVar3[1] + -1;
    piVar3[1] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 15780 ; VA 0x008fbc30 ; FUN_008fbc30 */

undefined4 __fastcall FUN_008fbc30(int param_1)

{
  if (*(int *)(param_1 + 0x1a0) != 0) {
    return *(undefined4 *)(*(int *)(param_1 + 0x1a0) + 0x74);
  }
  return 0;
}



/* FUNCTION 15781 ; VA 0x008fbc50 ; FUN_008fbc50 */

uint __fastcall FUN_008fbc50(int param_1)

{
  uint uVar1;
  
  if (*(int *)(param_1 + 0x250) != 0) {
    uVar1 = FUN_0090de60();
    return uVar1;
  }
  return (uint)*(byte *)(param_1 + 0x344);
}



/* FUNCTION 15782 ; VA 0x008fbc70 ; FUN_008fbc70 */

void __thiscall FUN_008fbc70(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  puVar5 = *(undefined4 **)(param_1 + 0x418);
  puVar4 = puVar5;
  puVar3 = (undefined4 *)puVar5[1];
  if (*(char *)((int)puVar5[1] + 0xd) == '\0') {
    do {
      puVar5 = puVar3;
      piVar2 = puVar5 + 4;
      puVar3 = param_3;
      if (0xf < (uint)param_3[5]) {
        puVar3 = (undefined4 *)*param_3;
      }
      if (0xf < (uint)puVar5[9]) {
        piVar2 = (int *)*piVar2;
      }
      iVar1 = FUN_0055c2d0(piVar2,puVar5[8],puVar3,param_3[4]);
      if (iVar1 < 0) {
        puVar3 = (undefined4 *)puVar5[2];
        puVar5 = puVar4;
      }
      else {
        puVar3 = (undefined4 *)*puVar5;
      }
      puVar4 = puVar5;
    } while (*(char *)((int)puVar3 + 0xd) == '\0');
    puVar4 = *(undefined4 **)(param_1 + 0x418);
  }
  if (puVar5 != puVar4) {
    piVar2 = puVar5 + 4;
    if (0xf < (uint)puVar5[9]) {
      piVar2 = (int *)*piVar2;
    }
    puVar3 = param_3 + 4;
    if (0xf < (uint)param_3[5]) {
      param_3 = (undefined4 *)*param_3;
    }
    iVar1 = FUN_0055c2d0(param_3,*puVar3,piVar2,puVar5[8]);
    if (-1 < iVar1) goto LAB_008fbd05;
  }
  puVar5 = puVar4;
LAB_008fbd05:
  *param_2 = 0;
  param_2[1] = 0;
  if (puVar5 != puVar4) {
    iVar1 = puVar5[0xb];
    if (iVar1 != 0) {
      LOCK();
      *(int *)(iVar1 + 4) = *(int *)(iVar1 + 4) + 1;
      UNLOCK();
      iVar1 = puVar5[0xb];
    }
    *param_2 = puVar5[10];
    param_2[1] = iVar1;
  }
  return;
}



/* FUNCTION 15783 ; VA 0x008fbd40 ; FUN_008fbd40 */

undefined4 __fastcall FUN_008fbd40(int param_1)

{
  return *(undefined4 *)(param_1 + 0x158);
}



/* FUNCTION 15784 ; VA 0x008fbd60 ; FUN_008fbd60 */

undefined4 __thiscall FUN_008fbd60(int param_1,undefined4 param_2)

{
  char cVar1;
  
  cVar1 = FUN_00973950(-(uint)(param_1 != 0) & param_1 + 0xcU,1);
  if (cVar1 != '\0') {
    FUN_0086f2f0(2,"PrivateServerId cannot be checked on the client, please check on the server.");
  }
  FUN_0054ef60(param_1 + 0x468);
  return param_2;
}



/* FUNCTION 15785 ; VA 0x008fbdb0 ; FUN_008fbdb0 */

undefined8 __fastcall FUN_008fbdb0(int param_1)

{
  char cVar1;
  
  cVar1 = FUN_00973950(-(uint)(param_1 != 0) & param_1 + 0xcU,1);
  if (cVar1 != '\0') {
    FUN_0086f2f0(2,
                 "PrivateServerOwnerId cannot be checked on the client, please check on the server."
                );
  }
  return *(undefined8 *)(param_1 + 0x480);
}



/* FUNCTION 15786 ; VA 0x008fbdf0 ; FUN_008fbdf0 */

undefined4 * __thiscall FUN_008fbdf0(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  int iVar5;
  uint uVar6;
  int aiStack_1c [5];
  uint uStack_8;
  
  puVar4 = (undefined4 *)(**(code **)(param_1 + 8))(aiStack_1c);
  param_2[4] = 0;
  param_2[5] = 0;
  uVar1 = puVar4[1];
  uVar2 = puVar4[2];
  uVar3 = puVar4[3];
  *param_2 = *puVar4;
  param_2[1] = uVar1;
  param_2[2] = uVar2;
  param_2[3] = uVar3;
  *(undefined8 *)(param_2 + 4) = *(undefined8 *)(puVar4 + 4);
  puVar4[4] = 0;
  puVar4[5] = 0xf;
  *(undefined *)puVar4 = 0;
  if (0xf < uStack_8) {
    uVar6 = uStack_8 + 1;
    iVar5 = aiStack_1c[0];
    if (0xfff < uVar6) {
      iVar5 = *(int *)(aiStack_1c[0] + -4);
      uVar6 = uStack_8 + 0x24;
      if (0x1f < (aiStack_1c[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  return param_2;
}



/* FUNCTION 15787 ; VA 0x008fbe90 ; FUN_008fbe90 */

void __fastcall FUN_008fbe90(int param_1)

{
  (**(code **)(param_1 + 8))();
  return;
}



/* FUNCTION 15788 ; VA 0x008fbeb0 ; FUN_008fbeb0 */

void __thiscall FUN_008fbeb0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_0090bc60();
  *param_3 = uVar3;
  iVar4 = FUN_0090c290();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 15789 ; VA 0x008fbf10 ; FUN_008fbf10 */

void __thiscall FUN_008fbf10(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_0063cc40();
  *param_3 = uVar3;
  iVar4 = FUN_0063ccd0();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 15790 ; VA 0x008fbf70 ; FUN_008fbf70 */

void __thiscall FUN_008fbf70(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_0090bd10();
  *param_3 = uVar3;
  iVar4 = FUN_0090c300();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 15791 ; VA 0x008fbfd0 ; FUN_008fbfd0 */

void __thiscall FUN_008fbfd0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_0090bdc0();
  *param_3 = uVar3;
  iVar4 = FUN_0090c370();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 15792 ; VA 0x008fc030 ; FUN_008fc030 */

void __thiscall FUN_008fc030(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_0090bf80();
  *param_3 = uVar3;
  iVar4 = FUN_0090c450();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 15793 ; VA 0x008fc090 ; FUN_008fc090 */

void __thiscall FUN_008fc090(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = FUN_0090c0c0();
  *param_3 = uVar3;
  iVar4 = FUN_0090c530();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 15794 ; VA 0x008fc0f0 ; FUN_008fc0f0 */

void FUN_008fc0f0(void)

{
  FUN_00bbe0a0();
  return;
}



/* FUNCTION 15795 ; VA 0x008fc110 ; FUN_008fc110 */

void FUN_008fc110(void)

{
  FUN_00bc0230();
  return;
}



/* FUNCTION 15796 ; VA 0x008fc130 ; FUN_008fc130 */

int __thiscall FUN_008fc130(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = FUN_0170d8dd(param_2 + 4,0x1da97c4);
  if (iVar1 == 0) {
    return param_1 + 0x10;
  }
  return 0;
}



/* FUNCTION 15797 ; VA 0x008fc160 ; FUN_008fc160 */

void FUN_008fc160(uint param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *****pppppuVar3;
  char cVar4;
  undefined4 ******ppppppuVar5;
  int iVar6;
  char *pcVar7;
  undefined4 uVar8;
  int *piVar9;
  uint uVar10;
  uint uVar11;
  undefined4 *puVar12;
  uint in_stack_00000024;
  uint in_stack_00000028;
  uint auStack_4c [4];
  undefined4 uStack_3c;
  uint uStack_38;
  undefined4 *****apppppuStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  int iStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c44a0;
  pvStack_10 = ExceptionList;
  iStack_1c = 0;
  piStack_18 = (int *)0x0;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  cVar4 = FUN_00e57b80(in_stack_00000024,in_stack_00000028,&iStack_1c,auStack_4c);
  iVar2 = iStack_1c;
  if (cVar4 == '\0') goto LAB_008fc310;
  uStack_24 = 0;
  uStack_20 = 0xf;
  apppppuStack_34[0] = (undefined4 *****)((uint)apppppuStack_34[0] & 0xffffff00);
  FUN_005542c0("CanManage",9);
  in_stack_00000028 = FUN_005702d0(apppppuStack_34);
  uVar11 = uStack_20;
  pppppuVar3 = apppppuStack_34[0];
  in_stack_00000024 = *(uint *)(iVar2 + 4);
  uStack_14 = in_stack_00000028 % in_stack_00000024;
  if (*(int *)(iVar2 + 8) == 0) {
LAB_008fc277:
    puVar12 = (undefined4 *)0x0;
  }
  else {
    puVar12 = *(undefined4 **)(*(int *)(iVar2 + 0x14) + uStack_14 * 4);
    uVar10 = in_stack_00000028;
    if (puVar12 == (undefined4 *)0x0) {
      puVar12 = (undefined4 *)0x0;
    }
    else {
      puVar12 = (undefined4 *)*puVar12;
    }
    for (; puVar12 != (undefined4 *)0x0; puVar12 = (undefined4 *)*puVar12) {
      if (uVar10 == puVar12[1]) {
        piVar9 = puVar12 + 2;
        if (0xf < (uint)puVar12[7]) {
          piVar9 = (int *)*piVar9;
        }
        ppppppuVar5 = apppppuStack_34;
        if (0xf < uVar11) {
          ppppppuVar5 = (undefined4 ******)pppppuVar3;
        }
        cVar4 = FUN_0055c360(ppppppuVar5,uStack_24,piVar9,puVar12[6]);
        uVar10 = in_stack_00000028;
        if (cVar4 != '\0') break;
      }
      else if ((uint)puVar12[1] % in_stack_00000024 != uStack_14) goto LAB_008fc277;
    }
  }
  if (0xf < uVar11) {
    uVar10 = uVar11 + 1;
    ppppppuVar5 = (undefined4 ******)pppppuVar3;
    if (0xfff < uVar10) {
      ppppppuVar5 = (undefined4 ******)pppppuVar3[-1];
      uVar10 = uVar11 + 0x24;
      if (0x1f < (uint)((int)pppppuVar3 + (-4 - (int)ppppppuVar5))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppppuVar5,uVar10);
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  apppppuStack_34[0] = (undefined4 *****)((uint)apppppuStack_34[0] & 0xffffff00);
  if ((puVar12 == (undefined4 *)0x0) || (iVar2 = puVar12[8], iVar6 = FUN_0088daf0(), iVar2 != iVar6)
     ) {
LAB_008fc2ef:
    in_stack_00000028 = in_stack_00000028 & 0xffffff00;
  }
  else {
    iVar2 = puVar12[8];
    iVar6 = FUN_0088daf0();
    if (iVar2 != iVar6) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Variant cast failed");
    }
    in_stack_00000028 = CONCAT31(in_stack_00000028._1_3_,1);
    pcVar7 = (char *)(puVar12 + 10);
    if (puVar12[9] == 0) {
      pcVar7 = (char *)0x0;
    }
    if (*pcVar7 == '\0') goto LAB_008fc2ef;
  }
  if (param_1 == 0) {
    uVar8 = FUN_0054fda0();
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
                    /* WARNING: Subroutine does not return */
    FUN_0054e5e0(uVar8);
  }
  (**(code **)((param_1 & 0xfffffffe) + 4))(&stack0x0000000c,in_stack_00000028);
LAB_008fc310:
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_38) {
    uVar10 = uStack_38 + 1;
    uVar11 = auStack_4c[0];
    if (0xfff < uVar10) {
      uVar11 = *(uint *)(auStack_4c[0] - 4);
      uVar10 = uStack_38 + 0x24;
      if (0x1f < (auStack_4c[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar10);
  }
  piVar9 = piStack_18;
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = auStack_4c[0] & 0xffffff00;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar9 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar9 + 4))();
      }
    }
  }
  uStack_8 = 4;
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_1 & 0xfffffffe))(&stack0x0000000c,&stack0x0000000c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15798 ; VA 0x008fc3f0 ; FUN_008fc3f0 */

void __thiscall FUN_008fc3f0(int param_1,uint param_2)

{
  undefined uVar1;
  uint uVar2;
  int in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  uint in_stack_00000020;
  uint in_stack_00000040;
  undefined auStack_fc [72];
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  char *pcStack_ac;
  undefined4 uStack_a8;
  undefined uStack_a4;
  undefined4 uStack_9c;
  undefined4 *puStack_98;
  undefined *puStack_94;
  undefined *puStack_90;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c44d8;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  if (*(int *)(param_1 + 0x4a0) == 3) {
    if (in_stack_00000014 == 0) {
      uStack_a8 = 9;
      puStack_94 = (undefined *)0x0;
      puStack_90 = (undefined *)0xf;
      pcStack_ac = "Empty URL";
      uStack_a4 = 0;
      uStack_b0 = 0x8fc474;
      ExceptionList = &pvStack_10;
      FUN_005542c0();
      uStack_a8 = 0x8fc47c;
      FUN_005e65e0();
    }
    else {
      puStack_90 = (undefined *)DAT_0211c340;
      puStack_94 = (undefined *)0x8fc48c;
      ExceptionList = &pvStack_10;
      FUN_00909d30();
      puStack_98 = &param_2;
      puStack_90 = (undefined *)0x0;
      puStack_94 = (undefined *)in_stack_0000001c;
      uStack_9c = 0x8fc4a0;
      FUN_014cc090();
      uVar1 = DAT_01ee05ac;
      puStack_90 = (undefined *)0x0;
      in_stack_0000001c = CONCAT31(in_stack_0000001c._1_3_,DAT_01ee05ad);
      uStack_8._0_1_ = 3;
      uStack_b4 = 0;
      FUN_0054f510(&stack0x00000040);
      uStack_8._0_1_ = 4;
      FUN_0054f510(&stack0x00000020);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      FUN_008e0790(auStack_fc,FUN_008ed2f0,uVar1,in_stack_0000001c);
      FUN_008dbd00();
      uStack_b4 = 0x8fc510;
      FUN_014ccc70();
      puStack_90 = (undefined *)0x8fc518;
      FUN_0056db40();
    }
  }
  else {
    uStack_a8 = 0x38;
    puStack_94 = (undefined *)0x0;
    puStack_90 = (undefined *)0xf;
    pcStack_ac = "Game:HttpGetAsync is only available in non-networked DMs";
    uStack_a4 = 0;
    uStack_b0 = 0x8fc43f;
    ExceptionList = &pvStack_10;
    FUN_005542c0();
    uStack_a8 = 0x8fc447;
    FUN_005e65e0();
  }
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    puStack_90 = (undefined *)(in_stack_00000018 + 1);
    uVar2 = param_2;
    if (0xfff < puStack_90) {
      uVar2 = *(uint *)(param_2 - 4);
      puStack_90 = (undefined *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_90 = &UNK_008fc5cb;
        FUN_017167a3();
      }
    }
    puStack_98 = (undefined4 *)0x8fc54d;
    puStack_94 = (undefined *)uVar2;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (in_stack_00000020 != 0) {
    if (((in_stack_00000020 & 1) == 0) &&
       (*(code **)(in_stack_00000020 & 0xfffffffe) != (code *)0x0)) {
      puStack_98 = (undefined4 *)&stack0x00000028;
      puStack_90 = (undefined *)0x2;
      uStack_9c = 0x8fc583;
      puStack_94 = (undefined *)puStack_98;
      (**(code **)(in_stack_00000020 & 0xfffffffe))();
    }
    in_stack_00000020 = 0;
  }
  uStack_8 = 6;
  if (((in_stack_00000040 != 0) && ((in_stack_00000040 & 1) == 0)) &&
     (*(code **)(in_stack_00000040 & 0xfffffffe) != (code *)0x0)) {
    puStack_98 = (undefined4 *)&stack0x00000048;
    puStack_90 = (undefined *)0x2;
    uStack_9c = 0x8fc5b1;
    puStack_94 = (undefined *)puStack_98;
    (**(code **)(in_stack_00000040 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15799 ; VA 0x008fc5d0 ; FUN_008fc5d0 */

void __thiscall FUN_008fc5d0(int param_1,uint param_2)

{
  bool bVar1;
  undefined uVar2;
  uint uVar3;
  undefined4 unaff_EBX;
  int in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  uint in_stack_0000002c;
  uint in_stack_00000030;
  uint in_stack_00000034;
  undefined4 in_stack_00000044;
  uint in_stack_00000048;
  uint in_stack_0000004c;
  uint in_stack_00000050;
  uint in_stack_00000070;
  undefined auStack_100 [60];
  undefined4 uStack_c4;
  undefined4 *puStack_c0;
  undefined4 *puStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  char *pcStack_b0;
  undefined4 uStack_ac;
  undefined uStack_a8;
  undefined4 uStack_a0;
  undefined4 *puStack_9c;
  undefined *puStack_98;
  undefined *puStack_94;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c4528;
  pvStack_10 = ExceptionList;
  uStack_8 = 4;
  if (*(int *)(param_1 + 0x4a0) == 3) {
    if (in_stack_00000014 == 0) {
      uStack_ac = 9;
      puStack_98 = (undefined *)0x0;
      puStack_94 = (undefined *)0xf;
      pcStack_b0 = "Empty URL";
      uStack_a8 = 0;
      uStack_b4 = 0x8fc655;
      ExceptionList = &pvStack_10;
      FUN_005542c0();
      uStack_ac = 0x8fc65d;
      FUN_005e65e0();
    }
    else {
      puStack_94 = (undefined *)DAT_0211c388;
      puStack_98 = (undefined *)0x8fc66d;
      ExceptionList = &pvStack_10;
      FUN_00909d30();
      puStack_9c = &param_2;
      puStack_94 = (undefined *)0x0;
      puStack_98 = (undefined *)in_stack_0000004c;
      uStack_a0 = 0x8fc681;
      FUN_014cc090();
      uVar2 = DAT_01ee05ac;
      puStack_94 = (undefined *)0x0;
      bVar1 = 0x100 < in_stack_0000002c;
      in_stack_0000004c = CONCAT31(in_stack_0000004c._1_3_,DAT_01ee05ad);
      uStack_8._0_1_ = 5;
      uStack_b8 = 0;
      FUN_0054f510(&stack0x00000070);
      uStack_8._0_1_ = 6;
      FUN_0054f510(&stack0x00000050);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      FUN_008e0790(auStack_100,FUN_008ed2f0,uVar2,in_stack_0000004c);
      FUN_008dbd00();
      puStack_bc = &stack0x00000034;
      puStack_c0 = &stack0x0000001c;
      uStack_c4 = 0x8fc704;
      uStack_b8 = CONCAT31((int3)((uint)unaff_EBX >> 8),bVar1);
      FUN_014cd990();
      puStack_94 = (undefined *)0x8fc70c;
      FUN_0056db40();
    }
  }
  else {
    uStack_ac = 0x39;
    puStack_98 = (undefined *)0x0;
    puStack_94 = (undefined *)0xf;
    pcStack_b0 = "Game:HttpPostAsync is only available in non-networked DMs";
    uStack_a8 = 0;
    uStack_b4 = 0x8fc620;
    ExceptionList = &pvStack_10;
    FUN_005542c0();
    uStack_ac = 0x8fc628;
    FUN_005e65e0();
  }
  uStack_8._0_1_ = 3;
  if (0xf < in_stack_00000018) {
    puStack_94 = (undefined *)(in_stack_00000018 + 1);
    uVar3 = param_2;
    if (0xfff < puStack_94) {
      uVar3 = *(uint *)(param_2 - 4);
      puStack_94 = (undefined *)(in_stack_00000018 + 0x24);
      if (0x1f < (param_2 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_94 = (undefined *)0x8fc854;
        FUN_017167a3();
      }
    }
    puStack_9c = (undefined4 *)0x8fc741;
    puStack_98 = (undefined *)uVar3;
    FUN_01674ea0();
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  uStack_8._0_1_ = 2;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 2;
  if (0xf < in_stack_00000030) {
    puStack_94 = (undefined *)(in_stack_00000030 + 1);
    uVar3 = in_stack_0000001c;
    if (0xfff < puStack_94) {
      uVar3 = *(uint *)(in_stack_0000001c - 4);
      puStack_94 = (undefined *)(in_stack_00000030 + 0x24);
      if (0x1f < (in_stack_0000001c - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_94 = (undefined *)0x8fc859;
        uStack_8._0_1_ = uVar2;
        FUN_017167a3();
      }
    }
    puStack_9c = (undefined4 *)0x8fc78b;
    puStack_98 = (undefined *)uVar3;
    FUN_01674ea0();
  }
  in_stack_0000002c = 0;
  in_stack_00000030 = 0xf;
  in_stack_0000001c = in_stack_0000001c & 0xffffff00;
  uStack_8._0_1_ = 1;
  uVar2 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000048) {
    puStack_94 = (undefined *)(in_stack_00000048 + 1);
    uVar3 = in_stack_00000034;
    if (0xfff < puStack_94) {
      uVar3 = *(uint *)(in_stack_00000034 - 4);
      puStack_94 = (undefined *)(in_stack_00000048 + 0x24);
      if (0x1f < (in_stack_00000034 - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
        puStack_94 = &UNK_008fc85e;
        uStack_8._0_1_ = uVar2;
        FUN_017167a3();
      }
    }
    puStack_9c = (undefined4 *)0x8fc7d5;
    puStack_98 = (undefined *)uVar3;
    FUN_01674ea0();
  }
  in_stack_00000044 = 0;
  in_stack_00000048 = 0xf;
  in_stack_00000034 = in_stack_00000034 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (in_stack_00000050 != 0) {
    if (((in_stack_00000050 & 1) == 0) &&
       (*(code **)(in_stack_00000050 & 0xfffffffe) != (code *)0x0)) {
      puStack_9c = (undefined4 *)&stack0x00000058;
      puStack_94 = (undefined *)0x2;
      uStack_a0 = 0x8fc80b;
      puStack_98 = (undefined *)puStack_9c;
      (**(code **)(in_stack_00000050 & 0xfffffffe))();
    }
    in_stack_00000050 = 0;
  }
  uStack_8 = 8;
  if (((in_stack_00000070 != 0) && ((in_stack_00000070 & 1) == 0)) &&
     (*(code **)(in_stack_00000070 & 0xfffffffe) != (code *)0x0)) {
    puStack_9c = (undefined4 *)&stack0x00000078;
    puStack_94 = (undefined *)0x2;
    uStack_a0 = 0x8fc839;
    puStack_98 = (undefined *)puStack_9c;
    (**(code **)(in_stack_00000070 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15800 ; VA 0x008fc870 ; FUN_008fc870 */

void __thiscall FUN_008fc870(int *param_1,char param_2,int param_3)

{
  int *piVar1;
  undefined4 uVar2;
  char cVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  int iVar7;
  int *piVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  uint auStack_64 [4];
  undefined4 uStack_54;
  uint uStack_50;
  code *pcStack_4c;
  undefined4 uStack_48;
  int *piStack_44;
  int *piStack_40;
  undefined auStack_3c [4];
  int *piStack_38;
  undefined auStack_34 [4];
  int *piStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c45e1;
  pvStack_10 = ExceptionList;
  piStack_30 = (int *)0x0;
  piVar8 = param_1 + 3;
  ExceptionList = &pvStack_10;
  piStack_1c = piVar8;
  piStack_18 = param_1;
  FUN_008a5700(piVar8);
  if (DAT_01d6360c != '\0') {
    FUN_0086f2f0(1,"Hello from: %s","Fancy Robot");
  }
  FUN_00674180();
  FUN_00c28380(*(undefined *)(param_3 + 0x8c));
  piVar4 = (int *)FUN_00563fd0();
  if (*piVar4 == 0) {
    FUN_0055e250(&piStack_44);
    uStack_8 = 0;
    FUN_008a5700(piVar8);
    FUN_005789c0(&DAT_01ea8ad0,&LAB_0055d560);
    uVar5 = FUN_00560bc0();
    piStack_38 = (int *)FUN_008aa140(uVar5);
    if (piStack_40 != (int *)0x0) {
      LOCK();
      piStack_40[1] = piStack_40[1] + 1;
      UNLOCK();
    }
    *piStack_38 = (int)piStack_44;
    piStack_28 = (int *)piStack_38[1];
    piStack_38[1] = (int)piStack_40;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_28[1] + -1;
      piStack_28[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        iVar9 = piStack_28[2] + -1;
        piStack_28[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
    uStack_8 = 0xffffffff;
    piStack_38 = piStack_40;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_40[1] + -1;
      piStack_40[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_40)();
        LOCK();
        iVar9 = piStack_38[2] + -1;
        piStack_38[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_38 + 4))();
        }
      }
    }
  }
  piVar4 = (int *)FUN_00563f20();
  if (*piVar4 == 0) {
    FUN_0055df40(&piStack_44);
    uStack_8 = 1;
    FUN_008a5700(piVar8);
    FUN_005789c0(&DAT_01ea8ac8,&LAB_0055d550);
    uVar5 = FUN_00560b40();
    piStack_38 = (int *)FUN_008aa140(uVar5);
    if (piStack_40 != (int *)0x0) {
      LOCK();
      piStack_40[1] = piStack_40[1] + 1;
      UNLOCK();
    }
    *piStack_38 = (int)piStack_44;
    piStack_28 = (int *)piStack_38[1];
    piStack_38[1] = (int)piStack_40;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_28[1] + -1;
      piStack_28[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        iVar9 = piStack_28[2] + -1;
        piStack_28[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
    uStack_8 = 0xffffffff;
    piStack_38 = piStack_40;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_40[1] + -1;
      piStack_40[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_40)();
        LOCK();
        iVar9 = piStack_38[2] + -1;
        piStack_38[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_38 + 4))();
        }
      }
    }
  }
  FUN_00671e00();
  FUN_005c2760();
  FUN_008bfe60();
  piVar4 = (int *)FUN_00636b00();
  if (*piVar4 == 0) {
    FUN_00634830(&piStack_44);
    uStack_8 = 2;
    FUN_008a5700(piVar8);
    FUN_005789c0(&DAT_01ead5f8,&LAB_006340d0);
    uVar5 = FUN_006352d0();
    piStack_38 = (int *)FUN_008aa140(uVar5);
    if (piStack_40 != (int *)0x0) {
      LOCK();
      piStack_40[1] = piStack_40[1] + 1;
      UNLOCK();
    }
    *piStack_38 = (int)piStack_44;
    piStack_28 = (int *)piStack_38[1];
    piStack_38[1] = (int)piStack_40;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_28[1] + -1;
      piStack_28[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        iVar9 = piStack_28[2] + -1;
        piStack_28[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
    uStack_8 = 0xffffffff;
    piStack_38 = piStack_40;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_40[1] + -1;
      piStack_40[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_40)();
        LOCK();
        iVar9 = piStack_38[2] + -1;
        piStack_38[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_38 + 4))();
        }
      }
    }
  }
  piVar4 = (int *)FUN_00677080();
  if (*piVar4 == 0) {
    FUN_00671530(&piStack_44);
    uStack_8 = 3;
    FUN_008a5700(piVar8);
    FUN_005789c0(&DAT_01eadd64,&LAB_00670c10);
    uVar5 = FUN_00675930();
    piStack_38 = (int *)FUN_008aa140(uVar5);
    if (piStack_40 != (int *)0x0) {
      LOCK();
      piStack_40[1] = piStack_40[1] + 1;
      UNLOCK();
    }
    *piStack_38 = (int)piStack_44;
    piStack_28 = (int *)piStack_38[1];
    piStack_38[1] = (int)piStack_40;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_28[1] + -1;
      piStack_28[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        iVar9 = piStack_28[2] + -1;
        piStack_28[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
    uStack_8 = 0xffffffff;
    piStack_38 = piStack_40;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_40[1] + -1;
      piStack_40[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_40)();
        LOCK();
        iVar9 = piStack_38[2] + -1;
        piStack_38[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_38 + 4))();
        }
      }
    }
  }
  FUN_00672050();
  FUN_00672860();
  FUN_006710f0();
  FUN_008e2b50();
  piVar4 = (int *)FUN_00677290();
  if (*piVar4 == 0) {
    FUN_00672ef0(&piStack_44);
    uStack_8 = 4;
    FUN_008a5700(piVar8);
    FUN_005789c0(&DAT_01eadd34,&LAB_00670cb0);
    uVar5 = FUN_00675e30();
    piStack_38 = (int *)FUN_008aa140(uVar5);
    if (piStack_40 != (int *)0x0) {
      LOCK();
      piStack_40[1] = piStack_40[1] + 1;
      UNLOCK();
    }
    *piStack_38 = (int)piStack_44;
    piStack_28 = (int *)piStack_38[1];
    piStack_38[1] = (int)piStack_40;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_28[1] + -1;
      piStack_28[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        iVar9 = piStack_28[2] + -1;
        piStack_28[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
    uStack_8 = 0xffffffff;
    piStack_38 = piStack_40;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_40[1] + -1;
      piStack_40[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_40)();
        LOCK();
        iVar9 = piStack_38[2] + -1;
        piStack_38[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_38 + 4))();
        }
      }
    }
  }
  FUN_008e29a0();
  FUN_008e3430();
  piVar4 = (int *)FUN_00787b20();
  if (*piVar4 == 0) {
    FUN_007877f0(&piStack_24);
    uStack_8 = 5;
    FUN_008a5700(piVar8);
    FUN_005789c0(&DAT_01eb1cbc,&LAB_007877a0);
    uVar5 = FUN_00787aa0();
    piStack_38 = (int *)FUN_008aa140(uVar5);
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piStack_20[1] = piStack_20[1] + 1;
      UNLOCK();
    }
    *piStack_38 = (int)piStack_24;
    piStack_28 = (int *)piStack_38[1];
    piStack_38[1] = (int)piStack_20;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_28[1] + -1;
      piStack_28[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        iVar9 = piStack_28[2] + -1;
        piStack_28[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
    piStack_28 = piStack_24;
    uStack_8 = 0xffffffff;
    piStack_38 = piStack_20;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_20[1] + -1;
      piStack_20[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar9 = piStack_38[2] + -1;
        piStack_38[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_38 + 4))();
        }
      }
    }
  }
  if (*(char *)(param_3 + 0x79) != '\0') {
    FUN_00d2b0b0();
  }
  if ((DAT_01d665a0 != '\0') && (DAT_01d665a8 != '\0')) {
    FUN_006725b0();
  }
  if (DAT_01d656f0 != '\0') {
    FUN_00674870();
  }
  if (DAT_01d635f4 != '\0') {
    FUN_006751b0();
  }
  uVar5 = FUN_0063f510();
  piVar4 = (int *)FUN_0060dcd0(&piStack_44,uVar5);
  iVar9 = *piVar4;
  iVar7 = piVar4[1];
  *piVar4 = 0;
  piVar4[1] = 0;
  piStack_18[0x68] = iVar9;
  piStack_38 = (int *)piStack_18[0x69];
  piStack_18[0x69] = iVar7;
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_38[1] + -1;
    piStack_38[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_38)();
      LOCK();
      iVar9 = piStack_38[2] + -1;
      piStack_38[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  piStack_38 = piStack_40;
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_40[1] + -1;
    piStack_40[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_40)();
      LOCK();
      iVar9 = piStack_38[2] + -1;
      piStack_38[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  uVar5 = FUN_00674620();
  piVar4 = (int *)FUN_0060dcd0(&piStack_44,uVar5);
  iVar9 = *piVar4;
  iVar7 = piVar4[1];
  *piVar4 = 0;
  piVar4[1] = 0;
  piStack_18[100] = iVar9;
  piStack_38 = (int *)piStack_18[0x65];
  piStack_18[0x65] = iVar7;
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_38[1] + -1;
    piStack_38[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_38)();
      LOCK();
      iVar9 = piStack_38[2] + -1;
      piStack_38[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  piStack_38 = piStack_40;
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_40[1] + -1;
    piStack_40[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_40)();
      LOCK();
      iVar9 = piStack_38[2] + -1;
      piStack_38[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  uVar5 = FUN_006743d0();
  piVar4 = (int *)FUN_0060dcd0(&piStack_44,uVar5);
  iVar9 = *piVar4;
  iVar7 = piVar4[1];
  *piVar4 = 0;
  piVar4[1] = 0;
  piStack_18[0x66] = iVar9;
  piStack_38 = (int *)piStack_18[0x67];
  piStack_18[0x67] = iVar7;
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_38[1] + -1;
    piStack_38[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_38)();
      LOCK();
      iVar9 = piStack_38[2] + -1;
      piStack_38[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  piStack_38 = piStack_40;
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_40[1] + -1;
    piStack_40[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_40)();
      LOCK();
      iVar9 = piStack_38[2] + -1;
      piStack_38[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  puVar6 = (undefined4 *)FUN_00636a50();
  piVar4 = (int *)*puVar6;
  if ((int *)*puVar6 == (int *)0x0) {
    FUN_008e1d00(&piStack_24);
    uStack_8 = 6;
    FUN_008a5700(piVar8);
    FUN_005789c0(&DAT_01ead658,&LAB_00634090);
    uVar5 = FUN_006350d0();
    piStack_38 = (int *)FUN_008aa140(uVar5);
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piStack_20[1] = piStack_20[1] + 1;
      UNLOCK();
    }
    *piStack_38 = (int)piStack_24;
    piStack_28 = (int *)piStack_38[1];
    piStack_38[1] = (int)piStack_20;
    if (piStack_28 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_28[1] + -1;
      piStack_28[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_28)();
        LOCK();
        iVar9 = piStack_28[2] + -1;
        piStack_28[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
    }
    piStack_28 = piStack_24;
    uStack_8 = 0xffffffff;
    piStack_38 = piStack_20;
    piVar4 = piStack_24;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_20[1] + -1;
      piStack_20[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        iVar9 = piStack_38[2] + -1;
        piStack_38[2] = iVar9;
        UNLOCK();
        piVar4 = piStack_28;
        if (iVar9 == 0) {
          (**(code **)(*piStack_38 + 4))();
          piVar4 = piStack_28;
        }
      }
    }
  }
  piVar4 = (int *)FUN_0060dcd0(&piStack_44,piVar4);
  iVar9 = *piVar4;
  iVar7 = piVar4[1];
  *piVar4 = 0;
  piVar4[1] = 0;
  piStack_18[0x60] = iVar9;
  piStack_38 = (int *)piStack_18[0x61];
  piStack_18[0x61] = iVar7;
  if (piStack_38 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_38[1] + -1;
    piStack_38[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_38)();
      LOCK();
      iVar9 = piStack_38[2] + -1;
      piStack_38[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  piStack_38 = piStack_40;
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_40[1] + -1;
    piStack_40[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_40)();
      LOCK();
      iVar9 = piStack_38[2] + -1;
      piStack_38[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  if (piVar8 != (int *)0x0) {
    puVar6 = (undefined4 *)FUN_005f5690();
    piStack_20 = (int *)*puVar6;
    if (piStack_20 == (int *)0x0) {
      FUN_005f4c10(&piStack_44);
      uStack_8 = 7;
      FUN_008a5700(piVar8);
      FUN_005789c0(&DAT_01eaad5c,&LAB_005f4450);
      uVar5 = FUN_005f5610();
      piStack_38 = (int *)FUN_008aa140(uVar5);
      if (piStack_40 != (int *)0x0) {
        LOCK();
        piStack_40[1] = piStack_40[1] + 1;
        UNLOCK();
      }
      *piStack_38 = (int)piStack_44;
      piStack_28 = (int *)piStack_38[1];
      piStack_38[1] = (int)piStack_40;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar9 = piStack_28[1] + -1;
        piStack_28[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          iVar9 = piStack_28[2] + -1;
          piStack_28[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piStack_28 + 4))();
          }
        }
      }
      piStack_20 = piStack_44;
      uStack_8 = 0xffffffff;
      piStack_38 = piStack_40;
      if (piStack_40 != (int *)0x0) {
        LOCK();
        iVar9 = piStack_40[1] + -1;
        piStack_40[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piStack_40)();
          LOCK();
          iVar9 = piStack_38[2] + -1;
          piStack_38[2] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piStack_38 + 4))();
          }
        }
      }
      if (piStack_20 == (int *)0x0) goto LAB_008fd260;
    }
    FUN_00a4d2a0(param_3);
    uStack_54 = 0;
    uStack_50 = 0xf;
    auStack_64[0] = auStack_64[0] & 0xffffff00;
    FUN_005542c0("DataModel::initializeContents",0x1d);
    uStack_8 = 8;
    FUN_00a4d0c0(param_3 + 0x18,auStack_64);
    uStack_8 = 0xffffffff;
    if (0xf < uStack_50) {
      uVar11 = uStack_50 + 1;
      uVar10 = auStack_64[0];
      if (0xfff < uVar11) {
        uVar10 = *(uint *)(auStack_64[0] - 4);
        uVar11 = uStack_50 + 0x24;
        if (0x1f < (auStack_64[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar10,uVar11);
    }
    if (*(int *)(param_3 + 0x58) != 0) {
      FUN_00a4c5c0(param_3 + 0x48);
    }
    if (*(int *)(param_3 + 0x70) != 0) {
      FUN_00a4c1e0(param_3 + 0x60);
    }
  }
LAB_008fd260:
  if ((DAT_01d63584 != '\0') || (DAT_01d665a8 != '\0')) {
    if (piVar8 != (int *)0x0) {
      FUN_00672ab0();
    }
    if (DAT_01d63584 != '\0') {
      cVar3 = '\0';
      if (*(char *)(param_3 + 0x8e) != '\0') {
        cVar3 = (*(char *)(param_3 + 0x8d) == '\0') + '\x01';
      }
      FUN_00c0e9e0(cVar3);
    }
  }
  if ((*(char *)(param_3 + 0x78) != '\0') || (DAT_01d635b4 == '\0')) {
    FUN_00a3da40(piStack_18);
  }
  FUN_00b5efb0(&piStack_44);
  piStack_38 = piStack_40;
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_40[1] + -1;
    piStack_40[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_40)();
      LOCK();
      iVar9 = piStack_38[2] + -1;
      piStack_38[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piStack_38 + 4))();
      }
    }
  }
  if ((piVar8 != (int *)0x0) && (piStack_38 = (int *)FUN_00674d10(), piStack_38 != (int *)0x0)) {
    if (DAT_01eeb57c != (int *)0x0) {
      LOCK();
      DAT_01eeb57c[1] = DAT_01eeb57c[1] + 1;
      UNLOCK();
    }
    piStack_20 = DAT_01eeb57c;
    piStack_28 = DAT_01eeb578;
    if ((DAT_01eeb578 == (int *)0x0) || (cStack_11 = '\x01', DAT_01eeb4f1 == '\0')) {
      cStack_11 = '\0';
    }
    if (DAT_01eeb57c != (int *)0x0) {
      piStack_30 = (int *)0x0;
      LOCK();
      iVar9 = DAT_01eeb57c[1] + -1;
      DAT_01eeb57c[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_20)();
        piStack_30 = (int *)0x0;
        LOCK();
        iVar9 = piStack_20[2] + -1;
        piStack_20[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_20 + 4))();
        }
      }
      piStack_20 = DAT_01eeb57c;
    }
    piStack_30 = (int *)0x0;
    DAT_01eeb57c = piStack_20;
    piStack_28 = DAT_01eeb578;
    if (cStack_11 != '\0') {
      if (piStack_20 != (int *)0x0) {
        LOCK();
        piStack_20[1] = piStack_20[1] + 1;
        UNLOCK();
        piStack_20 = DAT_01eeb57c;
        piStack_28 = DAT_01eeb578;
      }
      uStack_8 = 9;
      DAT_01eeb578 = piStack_28;
      DAT_01eeb57c = piStack_20;
      piStack_44 = piStack_28;
      piStack_40 = piStack_20;
      if ((piStack_28 == (int *)0x0) ||
         (iVar9 = piStack_28[3], iVar7 = FUN_00c68a10(),
         (uint)*(ushort *)(iVar7 + 0x1da) <
         (uint)*(ushort *)(iVar9 + 0x1d8) - (uint)*(ushort *)(iVar7 + 0x1d8))) {
        piStack_28 = (int *)0x0;
      }
      piVar8 = piStack_20;
      uStack_8 = 0xffffffff;
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar9 = piStack_20[1] + -1;
        piStack_20[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar4 = piVar8 + 2;
          iVar9 = *piVar4 + -1;
          *piVar4 = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      if (piStack_28 != (int *)0x0) {
        FUN_0089d950(&piStack_44,3);
        if (piStack_40 != (int *)0x0) {
          LOCK();
          piStack_40[1] = piStack_40[1] + 1;
          UNLOCK();
        }
        piStack_38[0x1d] = (int)piStack_44;
        piStack_20 = (int *)piStack_38[0x1e];
        piStack_38[0x1e] = (int)piStack_40;
        if (piStack_20 != (int *)0x0) {
          LOCK();
          iVar9 = piStack_20[1] + -1;
          piStack_20[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piStack_20)();
            LOCK();
            iVar9 = piStack_20[2] + -1;
            piStack_20[2] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piStack_20 + 4))();
            }
          }
        }
        piVar8 = piStack_40;
        if (piStack_40 != (int *)0x0) {
          LOCK();
          iVar9 = piStack_40[1] + -1;
          piStack_40[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piStack_40)();
            LOCK();
            piVar4 = piVar8 + 2;
            iVar9 = *piVar4 + -1;
            *piVar4 = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piVar8 + 4))();
            }
          }
        }
        piStack_40 = (int *)piStack_38[0x1e];
        if (piStack_40 != (int *)0x0) {
          LOCK();
          piStack_40[1] = piStack_40[1] + 1;
          UNLOCK();
          piStack_40 = (int *)piStack_38[0x1e];
        }
        piStack_44 = (int *)piStack_38[0x1d];
        uStack_8 = 10;
        puVar6 = (undefined4 *)FUN_00b5efb0(auStack_3c);
        uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
        FUN_008a65e0(*puVar6,0);
        FUN_00550b30();
        uStack_8 = 0xffffffff;
        FUN_00550b30();
        FUN_0089d950(&piStack_44,3);
        if (piStack_40 != (int *)0x0) {
          LOCK();
          piStack_40[1] = piStack_40[1] + 1;
          UNLOCK();
        }
        piVar8 = DAT_01eeb57c;
        DAT_01eeb578 = piStack_44;
        piStack_38 = DAT_01eeb57c;
        DAT_01eeb57c = piStack_40;
        if (piVar8 != (int *)0x0) {
          LOCK();
          iVar9 = piVar8[1] + -1;
          piVar8[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piVar8)();
            LOCK();
            iVar9 = piStack_38[2] + -1;
            piStack_38[2] = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piStack_38 + 4))();
            }
          }
        }
        piVar8 = piStack_40;
        if (piStack_40 != (int *)0x0) {
          LOCK();
          iVar9 = piStack_40[1] + -1;
          piStack_40[1] = iVar9;
          UNLOCK();
          if (iVar9 == 0) {
            (**(code **)*piStack_40)();
            LOCK();
            piVar4 = piVar8 + 2;
            iVar9 = *piVar4 + -1;
            *piVar4 = iVar9;
            UNLOCK();
            if (iVar9 == 0) {
              (**(code **)(*piVar8 + 4))();
            }
          }
        }
      }
    }
  }
  uVar5 = FUN_005f5170();
  piVar8 = (int *)FUN_0060dcd0(&piStack_44,uVar5);
  iVar9 = *piVar8;
  iVar7 = piVar8[1];
  *piVar8 = 0;
  piVar8[1] = 0;
  piStack_18[0x6a] = iVar9;
  piVar8 = (int *)piStack_18[0x6b];
  piStack_18[0x6b] = iVar7;
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar9 = piVar8[1] + -1;
    piVar8[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      iVar9 = piVar8[2] + -1;
      piVar8[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  piVar8 = piStack_40;
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_40[1] + -1;
    piStack_40[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_40)();
      LOCK();
      piVar4 = piVar8 + 2;
      iVar9 = *piVar4 + -1;
      *piVar4 = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  piVar8 = piStack_18;
  FUN_008ba310();
  FUN_00995680(piVar8[0x72]);
  if (param_2 != '\0') {
    FUN_00999ec0();
  }
  piStack_38 = (int *)(piVar8[0x6a] + 0xd8);
  pcStack_4c = FUN_00902130;
  uStack_48 = 0;
  piStack_44 = piVar8;
  uStack_8 = 0xc;
  piVar8 = (int *)FUN_01675290(DAT_02110da8);
  uStack_8._0_1_ = 0xd;
  piStack_28 = piVar8;
  _param_2 = (undefined4 *)FUN_01674e20(0x28);
  if (_param_2 == (undefined4 *)0x0) {
    _param_2 = (undefined4 *)0x0;
  }
  else {
    *_param_2 = 0;
    _param_2[1] = 1;
    _param_2[2] = FUN_00819150;
    _param_2[3] = _guard_check_icall;
    _param_2[4] = 0;
    _param_2[5] = piStack_38;
    _param_2[6] = pcStack_4c;
    _param_2[7] = uStack_48;
    _param_2[8] = piStack_44;
    _param_2[9] = piStack_40;
  }
  FUN_016797d0(_param_2);
  piStack_20 = _param_2;
  if (_param_2 != (undefined4 *)0x0) {
    LOCK();
    _param_2[1] = _param_2[1] + 1;
    UNLOCK();
  }
  piStack_30 = (int *)0x2;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  FUN_01675290(piVar8);
  uStack_8 = 0xffffffff;
  if (_param_2 != (undefined4 *)0x0) {
    piVar8 = _param_2 + 1;
    LOCK();
    iVar9 = *piVar8;
    *piVar8 = *piVar8 + -1;
    UNLOCK();
    if (iVar9 == 1) {
      FUN_01674ea0(_param_2);
    }
  }
  piVar8 = piStack_1c;
  piVar4 = (int *)FUN_006771e0();
  if (*piVar4 == 0) {
    FUN_00671a90(&piStack_44);
    uStack_8 = 0xf;
    FUN_008a5700(piVar8);
    FUN_005789c0(&DAT_01eadd54,&LAB_00670c30);
    uVar5 = FUN_00675a30();
    piVar4 = (int *)FUN_008aa140(uVar5);
    if (piStack_40 != (int *)0x0) {
      LOCK();
      piStack_40[1] = piStack_40[1] + 1;
      UNLOCK();
    }
    *piVar4 = (int)piStack_44;
    piStack_38 = (int *)piVar4[1];
    piVar4[1] = (int)piStack_40;
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_38[1] + -1;
      piStack_38[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_38)();
        LOCK();
        iVar9 = piStack_38[2] + -1;
        piStack_38[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_38 + 4))();
        }
      }
    }
    piVar4 = piStack_40;
    uStack_8 = 0xffffffff;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_40[1] + -1;
      piStack_40[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_40)();
        LOCK();
        piVar1 = piVar4 + 2;
        iVar9 = *piVar1 + -1;
        *piVar1 = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  FUN_00899040();
  FUN_008e2da0();
  FUN_005f4830();
  FUN_008e2750();
  FUN_00671840();
  FUN_00634b40();
  FUN_008e2350();
  FUN_008e2040();
  FUN_006342d0();
  FUN_00674d10();
  FUN_0055e560();
  piVar4 = (int *)FUN_00636c60();
  piVar4 = (int *)*piVar4;
  if (piVar4 == (int *)0x0) {
    FUN_00634cd0(&piStack_44);
    uStack_8 = 0x10;
    FUN_008a5700(piVar8);
    FUN_005789c0(&DAT_01ead600,&LAB_00634100);
    uVar5 = FUN_00635450();
    piVar4 = (int *)FUN_008aa140(uVar5);
    if (piStack_40 != (int *)0x0) {
      LOCK();
      piStack_40[1] = piStack_40[1] + 1;
      UNLOCK();
    }
    *piVar4 = (int)piStack_44;
    piStack_38 = (int *)piVar4[1];
    piVar4[1] = (int)piStack_40;
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_38[1] + -1;
      piStack_38[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_38)();
        LOCK();
        iVar9 = piStack_38[2] + -1;
        piStack_38[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_38 + 4))();
        }
      }
    }
    piVar4 = piStack_44;
    uStack_8 = 0xffffffff;
    piStack_38 = piStack_40;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_40[1] + -1;
      piStack_40[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_40)();
        LOCK();
        iVar9 = piStack_38[2] + -1;
        piStack_38[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_38 + 4))();
        }
      }
    }
  }
  piVar4 = (int *)FUN_0060dcd0(auStack_34,piVar4);
  iVar9 = *piVar4;
  iVar7 = piVar4[1];
  *piVar4 = 0;
  piVar4[1] = 0;
  piStack_18[0x6c] = iVar9;
  piVar4 = (int *)piStack_18[0x6d];
  piStack_18[0x6d] = iVar7;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar9 = piVar4[1] + -1;
    piVar4[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar9 = piVar4[2] + -1;
      piVar4[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_30;
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_30[1] + -1;
    piStack_30[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar9 = *piVar1 + -1;
      *piVar1 = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_008e3680();
  uVar5 = FUN_008e1920();
  piVar4 = (int *)FUN_0060dcd0(&piStack_44,uVar5);
  iVar9 = *piVar4;
  iVar7 = piVar4[1];
  *piVar4 = 0;
  piVar4[1] = 0;
  piStack_18[0x62] = iVar9;
  piVar4 = (int *)piStack_18[99];
  piStack_18[99] = iVar7;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar9 = piVar4[1] + -1;
    piVar4[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      iVar9 = piVar4[2] + -1;
      piVar4[2] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  piVar4 = piStack_40;
  if (piStack_40 != (int *)0x0) {
    LOCK();
    iVar9 = piStack_40[1] + -1;
    piStack_40[1] = iVar9;
    UNLOCK();
    if (iVar9 == 0) {
      (**(code **)*piStack_40)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar9 = *piVar1 + -1;
      *piVar1 = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_008e3120();
  FUN_008e1480();
  piVar4 = (int *)FUN_008e5530();
  if (*piVar4 == 0) {
    FUN_008e32b0(&piStack_44);
    uStack_8 = 0x11;
    FUN_008a5700(piVar8);
    FUN_005789c0(&DAT_01ee0c18,&LAB_008e0ee0);
    uVar5 = FUN_008e40a0();
    piVar8 = (int *)FUN_008aa140(uVar5);
    if (piStack_40 != (int *)0x0) {
      LOCK();
      piStack_40[1] = piStack_40[1] + 1;
      UNLOCK();
    }
    *piVar8 = (int)piStack_44;
    piStack_38 = (int *)piVar8[1];
    piVar8[1] = (int)piStack_40;
    if (piStack_38 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_38[1] + -1;
      piStack_38[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_38)();
        LOCK();
        iVar9 = piStack_38[2] + -1;
        piStack_38[2] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piStack_38 + 4))();
        }
      }
    }
    piVar8 = piStack_40;
    uStack_8 = 0xffffffff;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar9 = piStack_40[1] + -1;
      piStack_40[1] = iVar9;
      UNLOCK();
      if (iVar9 == 0) {
        (**(code **)*piStack_40)();
        LOCK();
        piVar4 = piVar8 + 2;
        iVar9 = *piVar4 + -1;
        *piVar4 = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
  }
  if ((DAT_01d6ea2c != '\0') || (DAT_01d6ddc0 != '\0')) {
    FUN_008e16d0();
  }
  iVar9 = FUN_008e1230();
  if (iVar9 != 0) {
    piVar8 = (int *)FUN_00f5b150(&piStack_44);
    iVar9 = *piVar8;
    FUN_00550b30();
    if (iVar9 == 0) {
      puVar6 = (undefined4 *)FUN_0153ef20(auStack_2c);
      uStack_8 = 0x12;
      uVar5 = *puVar6;
      uVar2 = puVar6[1];
      *puVar6 = 0;
      puVar6[1] = 0;
      FUN_00f5ab80(uVar5,uVar2);
      piVar8 = piStack_28;
      uStack_8 = 0xffffffff;
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar9 = piStack_28[1] + -1;
        piStack_28[1] = iVar9;
        UNLOCK();
        if (iVar9 == 0) {
          (**(code **)*piStack_28)();
          LOCK();
          piVar4 = piVar8 + 2;
          iVar9 = *piVar4;
          *piVar4 = *piVar4 + -1;
          UNLOCK();
          if (iVar9 == 1) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
    }
  }
  FUN_00671340();
  if (DAT_01d63554 != '\0') {
    FUN_0090afe0(*(undefined4 *)(param_3 + 0x80),*(undefined4 *)(param_3 + 0x84));
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15801 ; VA 0x008fdbc0 ; FUN_008fdbc0 */

void FUN_008fdbc0(uint param_1)

{
  int iVar1;
  char cVar2;
  undefined **ppuVar3;
  uint uVar4;
  uint uVar5;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  uint in_stack_0000001c;
  undefined4 in_stack_00000024;
  undefined4 in_stack_00000028;
  undefined4 in_stack_0000002c;
  undefined4 in_stack_00000030;
  undefined8 in_stack_00000034;
  uint in_stack_0000003c;
  undefined4 in_stack_00000044;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined8 in_stack_00000054;
  undefined4 uVar6;
  undefined auStack_294 [104];
  undefined auStack_22c [104];
  undefined auStack_1c4 [104];
  undefined auStack_15c [104];
  undefined auStack_f4 [104];
  undefined auStack_8c [4];
  undefined4 uStack_88;
  int *piStack_84;
  uint uStack_7c;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined8 uStack_64;
  uint uStack_5c;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined8 uStack_44;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  undefined *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c4682;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  uStack_1c = FUN_005c2760();
  FUN_0060e0c0(&uStack_24,uStack_1c);
  uStack_8._0_1_ = 3;
  FUN_008ccd70();
  puStack_18 = auStack_8c;
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piStack_20[2] = piStack_20[2] + 1;
    UNLOCK();
  }
  uStack_88 = uStack_24;
  piStack_84 = piStack_20;
  uStack_8._0_1_ = 4;
  uStack_7c = 0;
  if (in_stack_0000001c != 0) {
    uStack_7c = in_stack_0000001c;
    if ((in_stack_0000001c & 1) == 0) {
      (**(code **)(in_stack_0000001c & 0xfffffffe))(&stack0x00000024,&uStack_74,0);
    }
    else {
      uStack_74 = in_stack_00000024;
      uStack_70 = in_stack_00000028;
      uStack_6c = in_stack_0000002c;
      uStack_68 = in_stack_00000030;
      uStack_64 = in_stack_00000034;
    }
  }
  uStack_8._0_1_ = 5;
  uStack_5c = 0;
  if (in_stack_0000003c != 0) {
    uStack_5c = in_stack_0000003c;
    if ((in_stack_0000003c & 1) == 0) {
      (**(code **)(in_stack_0000003c & 0xfffffffe))(&stack0x00000044,&uStack_54,0);
    }
    else {
      uStack_54 = in_stack_00000044;
      uStack_50 = in_stack_00000048;
      uStack_4c = in_stack_0000004c;
      uStack_48 = in_stack_00000050;
      uStack_44 = in_stack_00000054;
    }
  }
  uStack_8._0_1_ = 6;
  FUN_0054ef60(&param_1);
  uStack_8._0_1_ = 7;
  FUN_008e6b20(auStack_8c);
  uStack_8._0_1_ = 8;
  uVar6 = 0;
  FUN_008e6b20(auStack_294);
  uStack_8._0_1_ = 9;
  FUN_008e6b20(auStack_22c);
  uStack_8._0_1_ = 10;
  FUN_008e6b20(auStack_1c4);
  uStack_8._0_1_ = 0xb;
  cVar2 = FUN_00585a40(auStack_f4,uVar6);
  if (cVar2 == '\0') {
    FUN_008e6b20(auStack_f4);
    uStack_8._0_1_ = 0xc;
    puStack_18 = (undefined *)FUN_01674e20(0x68);
    uStack_8._0_1_ = 0xd;
    if (puStack_18 != (undefined *)0x0) {
      FUN_008e6b20(auStack_15c);
    }
    FUN_008e9da0();
    FUN_008e9da0();
    cStack_11 = '\x01';
  }
  else {
    FUN_008e9da0();
    cStack_11 = '\0';
  }
  FUN_008e9da0();
  ppuVar3 = &PTR_FUN_0192d390;
  if (cStack_11 == '\0') {
    ppuVar3 = (undefined **)0x0;
  }
  FUN_008e9da0(ppuVar3);
  FUN_008e9da0();
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_008e9da0();
  FUN_008d0d60(&param_1,0x41f00000,ppuVar3);
  if (piStack_20 != (int *)0x0) {
    LOCK();
    iVar1 = piStack_20[2] + -1;
    piStack_20[2] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      (**(code **)(*piStack_20 + 4))();
    }
  }
  uStack_8._0_1_ = 1;
  if (0xf < in_stack_00000018) {
    uVar5 = in_stack_00000018 + 1;
    uVar4 = param_1;
    if (0xfff < uVar5) {
      uVar4 = *(uint *)(param_1 - 4);
      uVar5 = in_stack_00000018 + 0x24;
      if (0x1f < (param_1 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar4,uVar5);
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = param_1 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
  if (in_stack_0000001c != 0) {
    if (((in_stack_0000001c & 1) == 0) &&
       (*(code **)(in_stack_0000001c & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(in_stack_0000001c & 0xfffffffe))(&stack0x00000024,&stack0x00000024,2);
    }
    in_stack_0000001c = 0;
  }
  uStack_8 = 0xf;
  if (((in_stack_0000003c != 0) && ((in_stack_0000003c & 1) == 0)) &&
     (*(code **)(in_stack_0000003c & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(in_stack_0000003c & 0xfffffffe))(&stack0x00000044,&stack0x00000044,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15802 ; VA 0x008fdee0 ; FUN_008fdee0 */

void FUN_008fdee0(int *param_1)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = *param_1;
  if (*(int *)(iVar2 + 0xc) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(iVar2 + 0xc) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_008ec500(*(undefined4 *)(iVar2 + 8),*(undefined4 *)(iVar2 + 0xc));
  return;
}



/* FUNCTION 15803 ; VA 0x008fdf20 ; FUN_008fdf20 */

void FUN_008fdf20(void)

{
  FUN_008ebc80();
  return;
}



/* FUNCTION 15804 ; VA 0x008fdf30 ; FUN_008fdf30 */

void FUN_008fdf30(int *param_1)

{
  uint *puVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01792078;
  pvStack_10 = ExceptionList;
  puVar1 = (uint *)*param_1;
  if (*puVar1 != 0) {
    ExceptionList = &pvStack_10;
    (**(code **)((*puVar1 & 0xfffffffe) + 4))(puVar1 + 2,*(undefined *)(puVar1 + 8));
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0054fda0();
  uStack_8 = 0;
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar2);
}



/* FUNCTION 15805 ; VA 0x008fdfa0 ; FUN_008fdfa0 */

void FUN_008fdfa0(int param_1)

{
  int *piVar1;
  undefined4 uVar2;
  
  uVar2 = *(undefined4 *)(param_1 + 8);
  if (*(int *)(param_1 + 0x10) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x10) + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_008ec5c0(uVar2,*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
  return;
}



/* FUNCTION 15806 ; VA 0x008fdfe0 ; FUN_008fdfe0 */

int FUN_008fdfe0(int *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  undefined8 uVar7;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c46a4;
  pvStack_10 = ExceptionList;
  piVar5 = (int *)param_1[1];
  ExceptionList = &pvStack_10;
  if (piVar5 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piVar5[1] = piVar5[1] + 1;
    UNLOCK();
    piVar5 = (int *)param_1[1];
  }
  iVar6 = *param_1;
  iStack_8 = 0;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0618) {
    FUN_016f3809(&DAT_01ee0618);
    if (DAT_01ee0618 == -1) {
      iStack_8._0_1_ = 1;
      uVar7 = FUN_0152dab0(&DAT_018e1178,"LegacyLock::shutdown",0xffffffff);
      DAT_01ee0614 = (undefined4)((ulonglong)uVar7 >> 0x20);
      DAT_01ee0610 = (undefined4)uVar7;
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_016f37bf(&DAT_01ee0618);
    }
  }
  uVar4 = DAT_01ee0614;
  uVar3 = DAT_01ee0610;
  uVar7 = FUN_0152d930(DAT_01ee0610,DAT_01ee0614);
  *(undefined *)(iVar6 + 8) = 1;
  FUN_0151f3f0();
  iStack_8 = CONCAT31(iStack_8._1_3_,2);
  iVar6 = FUN_0152dda0(uVar3,uVar4,uVar7);
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar1 = piVar5 + 1;
    iVar2 = *piVar1;
    iVar6 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar6 = (**(code **)*piVar5)();
      LOCK();
      piVar1 = piVar5 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar6 = (**(code **)(*piVar5 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar6;
}



/* FUNCTION 15807 ; VA 0x008fe110 ; FUN_008fe110 */

/* WARNING: Removing unreachable block (ram,0x008fe16c) */
/* WARNING: Removing unreachable block (ram,0x008fe178) */
/* WARNING: Removing unreachable block (ram,0x008fe186) */

undefined4 FUN_008fe110(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c46b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008ec2a0(param_2,param_3);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15808 ; VA 0x008fe1a0 ; FUN_008fe1a0 */

int FUN_008fe1a0(undefined4 *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined8 uVar6;
  undefined4 uStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c46ec;
  pvStack_10 = ExceptionList;
  piStack_18 = (int *)param_1[1];
  ExceptionList = &pvStack_10;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    piStack_18[1] = piStack_18[1] + 1;
    UNLOCK();
    piStack_18 = (int *)param_1[1];
  }
  uStack_1c = *param_1;
  iStack_8 = 0;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0608) {
    FUN_016f3809(&DAT_01ee0608);
    if (DAT_01ee0608 == -1) {
      iStack_8._0_1_ = 1;
      uVar6 = FUN_0152dab0(&DAT_018e1178,"LegacyLock",0xffffffff);
      DAT_01ee0604 = (undefined4)((ulonglong)uVar6 >> 0x20);
      DAT_01ee0600 = (undefined4)uVar6;
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      FUN_016f37bf(&DAT_01ee0608);
    }
  }
  uVar3 = DAT_01ee0604;
  uStack_14 = DAT_01ee0600;
  uVar6 = FUN_0152d930(DAT_01ee0600,DAT_01ee0604);
  iStack_8._0_1_ = 2;
  FUN_0151f3f0();
  FUN_0151f430();
  FUN_005789c0(&DAT_01ee05e0,&LAB_0090a090);
  FUN_00909f90();
  FUN_00907bb0(&uStack_1c);
  iStack_8 = CONCAT31(iStack_8._1_3_,3);
  iVar5 = FUN_0152dda0(uStack_14,uVar3,uVar6);
  piVar4 = piStack_18;
  if (piStack_18 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_18 + 1;
    iVar2 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar5 = (**(code **)*piStack_18)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar5 = (**(code **)(*piVar4 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15809 ; VA 0x008fe300 ; FUN_008fe300 */

void FUN_008fe300(int *param_1)

{
  uint *puVar1;
  uint uVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c4718;
  pvStack_10 = ExceptionList;
  puVar1 = (uint *)*param_1;
  uVar4 = puVar1[0xb];
  ExceptionList = &pvStack_10;
  if (uVar4 != 0) {
    LOCK();
    ExceptionList = &pvStack_10;
    *(int *)(uVar4 + 4) = *(int *)(uVar4 + 4) + 1;
    UNLOCK();
    uVar4 = puVar1[0xb];
  }
  uVar2 = puVar1[10];
  uVar5 = puVar1[9];
  if (uVar5 != 0) {
    LOCK();
    *(int *)(uVar5 + 4) = *(int *)(uVar5 + 4) + 1;
    UNLOCK();
    uVar5 = puVar1[9];
  }
  uStack_8 = 1;
  if (*puVar1 != 0) {
    (**(code **)((*puVar1 & 0xfffffffe) + 4))(puVar1 + 2,puVar1[8],uVar5,uVar2,uVar4);
    ExceptionList = pvStack_10;
    return;
  }
  uVar3 = FUN_0054fda0();
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
                    /* WARNING: Subroutine does not return */
  FUN_0054e5e0(uVar3);
}



/* FUNCTION 15810 ; VA 0x008fe3d0 ; FUN_008fe3d0 */

void FUN_008fe3d0(int *param_1,int param_2)

{
  undefined4 *puVar1;
  code *pcVar2;
  uint uVar3;
  uint in_stack_0000001c;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined8 uStack_3c;
  undefined4 uStack_28;
  int iStack_24;
  undefined *puStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c4740;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  puVar1 = (undefined4 *)*param_1;
  pcVar2 = (code *)*puVar1;
  uStack_3c = CONCAT44(&param_2,0x8fe40a);
  ExceptionList = &pvStack_10;
  FUN_0054ef60();
  iStack_8._0_1_ = 1;
  uVar3 = puVar1[2];
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(puVar1 + 4,&uStack_4c,0);
    }
    else {
      uStack_4c = puVar1[4];
      uStack_48 = puVar1[5];
      uStack_44 = puVar1[6];
      uStack_40 = puVar1[7];
      uStack_3c = *(undefined8 *)(puVar1 + 8);
    }
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  (*pcVar2)();
  if (0xf < in_stack_0000001c) {
    puStack_20 = (undefined *)(in_stack_0000001c + 1);
    iStack_24 = param_2;
    if (0xfff < puStack_20) {
      iStack_24 = *(int *)(param_2 + -4);
      puStack_20 = (undefined *)(in_stack_0000001c + 0x24);
      if (0x1f < (param_2 - iStack_24) - 4U) {
                    /* WARNING: Subroutine does not return */
        puStack_20 = &UNK_008fe4a0;
        FUN_017167a3();
      }
    }
    uStack_28 = 0x8fe488;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15811 ; VA 0x008fe4b0 ; FUN_008fe4b0 */

int FUN_008fe4b0(int *param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  code *pcVar4;
  uint uVar5;
  uint3 uVar6;
  int iVar7;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined8 uStack_2c;
  undefined4 uStack_24;
  int *piStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c4760;
  pvStack_10 = ExceptionList;
  puVar3 = (undefined4 *)*param_1;
  pcVar4 = (code *)*puVar3;
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_24 = param_2;
  piStack_20 = param_3;
  iStack_8._1_3_ = 0;
  uVar6 = iStack_8._1_3_;
  iStack_8._0_1_ = 1;
  iStack_8._1_3_ = 0;
  uVar5 = puVar3[2];
  if (uVar5 != 0) {
    if ((uVar5 & 1) == 0) {
      (**(code **)(uVar5 & 0xfffffffe))(puVar3 + 4,&uStack_3c,0);
      uVar6 = iStack_8._1_3_;
    }
    else {
      uStack_3c = puVar3[4];
      uStack_38 = puVar3[5];
      uStack_34 = puVar3[6];
      uStack_30 = puVar3[7];
      uStack_2c = *(undefined8 *)(puVar3 + 8);
      uVar6 = iStack_8._1_3_;
    }
  }
  iStack_8._1_3_ = uVar6;
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  iVar7 = (*pcVar4)();
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar7 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piStack_20 = (int *)0x8fe56e;
      iVar7 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piStack_20 = (int *)0x8fe57d;
        iVar7 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar7;
}



/* FUNCTION 15812 ; VA 0x008fe590 ; FUN_008fe590 */

void FUN_008fe590(int *param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_0000001c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c4780;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  puVar2 = (undefined4 *)*param_1;
  pcVar3 = (code *)*puVar2;
  uVar5 = puVar2[4];
  ExceptionList = &pvStack_10;
  if (uVar5 != 0) {
    if ((uVar5 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar5 & 0xfffffffe))(puVar2 + 6,&uStack_34,0);
    }
    else {
      uStack_34 = puVar2[6];
      uStack_30 = puVar2[7];
      uStack_2c = puVar2[8];
      uStack_28 = puVar2[9];
      uStack_24 = *(undefined8 *)(puVar2 + 10);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8._0_1_ = 1;
  FUN_0054ef60(&param_2);
  if (puVar2[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  (*pcVar3)(puVar2[2],puVar2[3]);
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar4 = param_2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_2 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar4) - 4U) {
        uStack_24 = CONCAT44(&UNK_008fe688,(undefined4)uStack_24);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_24 = CONCAT44(uVar5,iVar4);
    uStack_28 = 0x8fe670;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15813 ; VA 0x008fe690 ; FUN_008fe690 */

void FUN_008fe690(int *param_1,int param_2)

{
  int *piVar1;
  undefined4 *puVar2;
  code *pcVar3;
  int iVar4;
  uint uVar5;
  uint in_stack_0000001c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c47a0;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  puVar2 = (undefined4 *)*param_1;
  pcVar3 = (code *)*puVar2;
  uVar5 = puVar2[4];
  ExceptionList = &pvStack_10;
  if (uVar5 != 0) {
    if ((uVar5 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(uVar5 & 0xfffffffe))(puVar2 + 6,&uStack_34,0);
    }
    else {
      uStack_34 = puVar2[6];
      uStack_30 = puVar2[7];
      uStack_2c = puVar2[8];
      uStack_28 = puVar2[9];
      uStack_24 = *(undefined8 *)(puVar2 + 10);
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8._0_1_ = 1;
  FUN_0054ef60(&param_2);
  if (puVar2[3] != 0) {
    LOCK();
    piVar1 = (int *)(puVar2[3] + 8);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  (*pcVar3)(puVar2[2],puVar2[3]);
  if (0xf < in_stack_0000001c) {
    uVar5 = in_stack_0000001c + 1;
    iVar4 = param_2;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_2 + -4);
      uVar5 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar4) - 4U) {
        uStack_24 = CONCAT44(&UNK_008fe788,(undefined4)uStack_24);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_24 = CONCAT44(uVar5,iVar4);
    uStack_28 = 0x8fe770;
    FUN_01674ea0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15814 ; VA 0x008fe790 ; FUN_008fe790 */

int FUN_008fe790(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c47b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uVar3 = *(undefined4 *)(param_1 + 8);
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x10) != 0) {
    LOCK();
    piVar1 = (int *)(*(int *)(param_1 + 0x10) + 4);
    ExceptionList = &pvStack_10;
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  iVar4 = FUN_008ec5c0(uVar3,*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 15815 ; VA 0x008fe820 ; FUN_008fe820 */

void FUN_008fe820(undefined4 param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint in_stack_0000001c;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01795bd8;
  pvStack_10 = ExceptionList;
  puStack_14 = &param_2;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_008dce40(param_1,param_1,&puStack_14,0);
  if (0xf < in_stack_0000001c) {
    uVar2 = in_stack_0000001c + 1;
    iVar1 = param_2;
    if (0xfff < uVar2) {
      iVar1 = *(int *)(param_2 + -4);
      uVar2 = in_stack_0000001c + 0x24;
      if (0x1f < (param_2 - iVar1) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar1,uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15816 ; VA 0x008fe8a0 ; FUN_008fe8a0 */

int FUN_008fe8a0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795cf8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00587490(&uStack_18);
  piVar5 = *(int **)(param_1 + 0xc);
  uStack_8 = 0;
  if (piVar5 != (int *)0x0) {
    LOCK();
    piVar5[2] = piVar5[2] + 1;
    UNLOCK();
    piVar5 = *(int **)(param_1 + 0xc);
  }
  uVar3 = *(undefined4 *)(param_1 + 8);
  piVar1 = piVar5 + 2;
  if (piVar5 != (int *)0x0) {
    LOCK();
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  FUN_008db890(uVar3,piVar5,0);
  if (piVar5 != (int *)0x0) {
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      (**(code **)(*piVar5 + 4))();
    }
  }
  iVar4 = FUN_008ed3f0(uStack_18,param_2,param_3);
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar5 = piStack_14 + 1;
    iVar2 = *piVar5;
    iVar4 = *piVar5;
    *piVar5 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*piStack_14)();
      LOCK();
      piVar5 = piStack_14 + 2;
      iVar2 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 15817 ; VA 0x008fe970 ; FUN_008fe970 */

/* WARNING: Removing unreachable block (ram,0x008fe9fa) */
/* WARNING: Removing unreachable block (ram,0x008fea03) */
/* WARNING: Removing unreachable block (ram,0x008fea12) */
/* WARNING: Removing unreachable block (ram,0x008fea20) */
/* WARNING: Removing unreachable block (ram,0x008fea29) */
/* WARNING: Removing unreachable block (ram,0x008fea37) */

undefined4
FUN_008fe970(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c47e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008eb960(param_2,param_3,param_4,param_5);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15818 ; VA 0x008fea50 ; FUN_008fea50 */

/* WARNING: Removing unreachable block (ram,0x008feadd) */
/* WARNING: Removing unreachable block (ram,0x008feae6) */
/* WARNING: Removing unreachable block (ram,0x008feaf5) */
/* WARNING: Removing unreachable block (ram,0x008feb03) */
/* WARNING: Removing unreachable block (ram,0x008feb0c) */
/* WARNING: Removing unreachable block (ram,0x008feb1a) */

undefined4
FUN_008fea50(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c47e0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008ebaa0(param_2,param_3,param_4,param_5);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15819 ; VA 0x008feb40 ; FUN_008feb40 */

void FUN_008feb40(int *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  code *pcVar2;
  uint uVar3;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c47f8;
  pvStack_10 = ExceptionList;
  puVar1 = (undefined4 *)*param_1;
  pcVar2 = (code *)*puVar1;
  uStack_3c = 0;
  uVar3 = puVar1[10];
  ExceptionList = &pvStack_10;
  if (uVar3 != 0) {
    uStack_3c = uVar3;
    if ((uVar3 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = puVar1 + 0xc;
      uStack_4c = 0x8feba6;
      ExceptionList = &pvStack_10;
      (**(code **)(uVar3 & 0xfffffffe))();
    }
    else {
      uStack_34 = puVar1[0xc];
      uStack_30 = puVar1[0xd];
      uStack_2c = puVar1[0xe];
      uStack_28 = puVar1[0xf];
      uStack_24 = *(undefined8 *)(puVar1 + 0x10);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8 = 0;
  uVar3 = puVar1[2];
  if (uVar3 != 0) {
    if ((uVar3 & 1) == 0) {
      (**(code **)(uVar3 & 0xfffffffe))(puVar1 + 4,&uStack_54,0);
    }
    else {
      uStack_54 = puVar1[4];
      uStack_50 = puVar1[5];
      uStack_4c = puVar1[6];
      puStack_48 = (undefined4 *)puVar1[7];
      uStack_44 = *(ulonglong *)(puVar1 + 8);
    }
  }
  uStack_8 = 0xffffffff;
  (*pcVar2)(param_2,param_3);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15820 ; VA 0x008fec20 ; FUN_008fec20 */

void FUN_008fec20(undefined4 *param_1,uint param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 *param_7,ulonglong param_8,
                 uint param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
                 undefined4 param_13,undefined4 param_14,undefined8 param_15)

{
  int *piVar1;
  code *pcVar2;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 *puStack_48;
  ulonglong uStack_44;
  uint uStack_3c;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 *puStack_28;
  undefined8 uStack_24;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c4828;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  pcVar2 = (code *)*param_1;
  uStack_3c = 0;
  ExceptionList = &pvStack_10;
  if (param_9 != 0) {
    uStack_3c = param_9;
    if ((param_9 & 1) == 0) {
      uStack_44 = ZEXT48(&uStack_34);
      puStack_48 = &param_11;
      uStack_4c = 0x8fec8b;
      ExceptionList = &pvStack_10;
      (**(code **)(param_9 & 0xfffffffe))();
    }
    else {
      uStack_34 = param_11;
      uStack_30 = param_12;
      uStack_2c = param_13;
      puStack_28 = (undefined4 *)param_14;
      uStack_24 = param_15;
      ExceptionList = &pvStack_10;
    }
  }
  uStack_8._0_1_ = 2;
  if (param_2 != 0) {
    if ((param_2 & 1) == 0) {
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_54,0);
    }
    else {
      uStack_54 = param_4;
      uStack_50 = param_5;
      uStack_4c = param_6;
      puStack_48 = param_7;
      uStack_44 = param_8;
    }
  }
  if (param_1[2] != 0) {
    LOCK();
    piVar1 = (int *)(param_1[2] + 4);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  (*pcVar2)(param_1[1],param_1[2]);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    puStack_28 = &param_4;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0x8fed28;
    (**(code **)(param_2 & 0xfffffffe))();
  }
  uStack_8 = 4;
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    puStack_28 = &param_11;
    uStack_24 = CONCAT44(2,puStack_28);
    uStack_2c = 0x8fed56;
    (**(code **)(param_9 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15821 ; VA 0x008fed70 ; FUN_008fed70 */

void FUN_008fed70(int *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  code *pcVar3;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined8 uStack_4c;
  undefined4 *puStack_44;
  undefined4 uStack_40;
  uint uStack_34;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c4848;
  pvStack_10 = ExceptionList;
  uStack_34 = 0;
  puVar1 = (undefined4 *)*param_1;
  uVar2 = puVar1[4];
  ExceptionList = &pvStack_10;
  if (uVar2 != 0) {
    uStack_34 = uVar2;
    if ((uVar2 & 1) == 0) {
      puStack_44 = &uStack_2c;
      uStack_40 = 0;
      uStack_4c = CONCAT44(puVar1 + 6,0x8fedd3);
      ExceptionList = &pvStack_10;
      (**(code **)(uVar2 & 0xfffffffe))();
    }
    else {
      uStack_2c = puVar1[6];
      uStack_28 = puVar1[7];
      uStack_24 = puVar1[8];
      uStack_20 = puVar1[9];
      uStack_1c = *(undefined8 *)(puVar1 + 10);
      ExceptionList = &pvStack_10;
    }
  }
  uStack_40 = param_3;
  puStack_44 = (undefined4 *)param_2;
  pcVar3 = (code *)*puVar1;
  uStack_8 = 0;
  if (uStack_34 != 0) {
    if ((uStack_34 & 1) == 0) {
      (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_5c,0);
    }
    else {
      uStack_5c = uStack_2c;
      uStack_58 = uStack_28;
      uStack_54 = uStack_24;
      uStack_50 = uStack_20;
      uStack_4c = uStack_1c;
    }
  }
  (*pcVar3)();
  uStack_8 = 1;
  if (((uStack_34 != 0) && ((uStack_34 & 1) == 0)) &&
     (*(code **)(uStack_34 & 0xfffffffe) != (code *)0x0)) {
    (**(code **)(uStack_34 & 0xfffffffe))(&uStack_2c,&uStack_2c,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15822 ; VA 0x008fee70 ; FUN_008fee70 */

/* WARNING: Removing unreachable block (ram,0x008fef00) */
/* WARNING: Removing unreachable block (ram,0x008fef09) */
/* WARNING: Removing unreachable block (ram,0x008fef18) */
/* WARNING: Removing unreachable block (ram,0x008fef26) */
/* WARNING: Removing unreachable block (ram,0x008fef2f) */
/* WARNING: Removing unreachable block (ram,0x008fef3d) */

undefined4
FUN_008fee70(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017bfa90;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_008eb620(param_2,param_3,param_4,param_5,param_6);
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15823 ; VA 0x008fef60 ; FUN_008fef60 */

/* WARNING: Removing unreachable block (ram,0x008ff02f) */
/* WARNING: Removing unreachable block (ram,0x008ff038) */
/* WARNING: Removing unreachable block (ram,0x008ff047) */
/* WARNING: Removing unreachable block (ram,0x008ff05d) */
/* WARNING: Removing unreachable block (ram,0x008ff066) */
/* WARNING: Removing unreachable block (ram,0x008ff074) */

undefined4
FUN_008fef60(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c4878;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  ExceptionList = &pvStack_10;
  FUN_008ebf00(param_2,param_3,param_4,0,param_6,param_7,param_8,param_9,param_10,param_11,param_12)
  ;
  uVar1 = FUN_0056cfd0();
  ExceptionList = pvStack_10;
  return uVar1;
}



/* FUNCTION 15824 ; VA 0x008ff090 ; FUN_008ff090 */

undefined __fastcall FUN_008ff090(int param_1)

{
  return *(undefined *)(param_1 + 0x1d8);
}



/* FUNCTION 15825 ; VA 0x008ff0a0 ; FUN_008ff0a0 */

bool __fastcall FUN_008ff0a0(int param_1)

{
  return *(int *)(param_1 + 0x158) == 0;
}



/* FUNCTION 15826 ; VA 0x008ff0b0 ; FUN_008ff0b0 */

undefined4 __thiscall FUN_008ff0b0(int param_1,byte param_2)

{
  uint uVar1;
  
  uVar1 = 1 << (param_2 & 0x1f);
  return CONCAT31((int3)(uVar1 >> 8),(*(uint *)(param_1 + 0x464) & uVar1) != 0);
}



/* FUNCTION 15827 ; VA 0x008ff0d0 ; FUN_008ff0d0 */

bool __fastcall FUN_008ff0d0(int param_1)

{
  return *(int *)(param_1 + 0x158) != 6;
}



/* FUNCTION 15828 ; VA 0x008ff0e0 ; FUN_008ff0e0 */

uint __thiscall FUN_008ff0e0(int param_1,uint param_2)

{
  uint in_EAX;
  
  if ((((*(int *)(param_1 + 0x54) == 8) && (in_EAX = *(uint *)(param_1 + 0x5c), in_EAX != 2)) &&
      (in_EAX != 4)) && (in_EAX = *(uint *)(param_1 + 0xa8), in_EAX == param_2)) {
    return CONCAT31((int3)(in_EAX >> 8),1);
  }
  return in_EAX & 0xffffff00;
}



/* FUNCTION 15829 ; VA 0x008ff110 ; FUN_008ff110 */

uint __thiscall FUN_008ff110(int param_1,uint param_2)

{
  uint uVar1;
  
  uVar1 = FUN_00d81a70();
  if (((char)uVar1 != '\0') && (uVar1 = *(uint *)(param_1 + 0xa8), uVar1 == param_2)) {
    return CONCAT31((int3)(uVar1 >> 8),1);
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 15830 ; VA 0x008ff140 ; FUN_008ff140 */

uint __thiscall FUN_008ff140(int param_1,uint param_2)

{
  uint uVar1;
  
  uVar1 = FUN_00d81ac0();
  if (((char)uVar1 != '\0') && (uVar1 = *(uint *)(param_1 + 0xa8), uVar1 == param_2)) {
    return CONCAT31((int3)(uVar1 >> 8),1);
  }
  return uVar1 & 0xffffff00;
}



/* FUNCTION 15831 ; VA 0x008ff170 ; FUN_008ff170 */

undefined __fastcall FUN_008ff170(int param_1)

{
  undefined uVar1;
  undefined4 *****pppppuVar2;
  undefined4 *puVar3;
  uint uVar4;
  undefined4 ****appppuStack_1c [4];
  undefined4 uStack_c;
  uint uStack_8;
  
  FUN_0054ef60(param_1 + 0xc0);
  puVar3 = &DAT_01d6d1f4;
  if (0xf < DAT_01d6d208) {
    puVar3 = DAT_01d6d1f4;
  }
  pppppuVar2 = appppuStack_1c;
  if (0xf < uStack_8) {
    pppppuVar2 = (undefined4 *****)appppuStack_1c[0];
  }
  uVar1 = FUN_0055c360(pppppuVar2,uStack_c,puVar3,DAT_01d6d204);
  if (0xf < uStack_8) {
    uVar4 = uStack_8 + 1;
    pppppuVar2 = (undefined4 *****)appppuStack_1c[0];
    if (0xfff < uVar4) {
      pppppuVar2 = (undefined4 *****)appppuStack_1c[0][-1];
      uVar4 = uStack_8 + 0x24;
      if (0x1f < (uint)((int)appppuStack_1c[0] + (-4 - (int)pppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(pppppuVar2,uVar4);
  }
  return uVar1;
}



/* FUNCTION 15832 ; VA 0x008ff200 ; FUN_008ff200 */

int * __fastcall FUN_008ff200(int *param_1)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  undefined4 *puVar6;
  int *piVar7;
  int iStack_24;
  int *piStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c48aa;
  pvStack_10 = ExceptionList;
  puVar1 = (undefined4 *)(&DAT_01ea8970 + ((uint)param_1 % 0x29) * 4);
  ExceptionList = &pvStack_10;
  piVar5 = (int *)FUN_00587580();
  iVar3 = *param_1;
  piVar4 = (int *)param_1[1];
  piVar7 = piVar4 + 1;
  if (piVar4 != (int *)0x0) {
    LOCK();
    *piVar7 = *piVar7 + 1;
    UNLOCK();
  }
  *puVar1 = 0;
  uStack_8 = 0;
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar7;
    piVar5 = (int *)*piVar7;
    *piVar7 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)(*piVar4 + 4))();
      LOCK();
      piVar7 = piVar4 + 2;
      iVar2 = *piVar7;
      piVar5 = (int *)*piVar7;
      *piVar7 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        piVar5 = (int *)(**(code **)(*piVar4 + 8))();
      }
    }
  }
  if (iVar3 == 0) {
    piVar7 = (int *)0x0;
    uStack_8 = 1;
    puVar6 = (undefined4 *)FUN_01674e20(0x90);
    uStack_8._0_1_ = 2;
    if (puVar6 == (undefined4 *)0x0) {
      puVar6 = (undefined4 *)0x0;
    }
    else {
      FUN_0056b2c0();
      *puVar6 = boost::detail::
                shared_state<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>,class_std::allocator<class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_>_>_>_>_>
                ::vftable;
      puVar6[0x22] = 0;
    }
    uStack_8._0_1_ = 1;
    FUN_008db210(puVar6);
    FUN_00587580();
    piVar5 = (int *)*param_1;
    if ((piVar5 == (int *)0x0) && (param_1[1] == 0)) {
      *param_1 = iStack_24;
      piVar5 = (int *)param_1[1];
      param_1[1] = (int)piStack_20;
      *puVar1 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      piStack_20 = piVar5;
    }
    else {
      piVar7 = (int *)param_1[1];
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar7[1] = piVar7[1] + 1;
        UNLOCK();
      }
      *puVar1 = 0;
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
    }
    if (piStack_20 != (int *)0x0) {
      LOCK();
      piVar4 = piStack_20 + 1;
      iVar3 = *piVar4;
      piVar5 = (int *)*piVar4;
      *piVar4 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        (**(code **)(*piStack_20 + 4))();
        LOCK();
        piVar4 = piStack_20 + 2;
        iVar3 = *piVar4;
        piVar5 = (int *)*piVar4;
        *piVar4 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          piVar5 = (int *)(**(code **)(*piStack_20 + 8))();
        }
      }
    }
    uStack_8 = 6;
    if (piVar7 != (int *)0x0) {
      LOCK();
      piVar4 = piVar7 + 1;
      iVar3 = *piVar4;
      piVar5 = (int *)*piVar4;
      *piVar4 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        piVar5 = (int *)(**(code **)(*piVar7 + 4))();
        LOCK();
        piVar4 = piVar7 + 2;
        iVar3 = *piVar4;
        *piVar4 = *piVar4 + -1;
        UNLOCK();
        if (iVar3 == 1) {
          piVar5 = (int *)(**(code **)(*piVar7 + 8))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 15833 ; VA 0x008ff3b0 ; FUN_008ff3b0 */

int __thiscall FUN_008ff3b0(int param_1,undefined4 *param_2)

{
  int iVar1;
  int *piVar2;
  undefined uVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  float10 fVar9;
  uint in_stack_00000018;
  undefined auStack_68 [24];
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  double dStack_38;
  double dStack_30;
  double dStack_28;
  double dStack_20;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c48e8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if (*(char *)(param_1 + 0x1de) == '\0') {
    puVar4 = &param_2;
    if (0xf < in_stack_00000018) {
      puVar4 = param_2;
    }
    ExceptionList = &pvStack_10;
    FUN_0086f2f0(1,"DataModel Loading %s",puVar4);
    fVar9 = (float10)FUN_01683110();
    iVar5 = param_1 + 0xc;
    dStack_28 = (double)fVar9;
    if (iVar5 != 0) {
      FUN_005c2760();
    }
    uStack_40 = 0;
    uStack_3c = 0xf;
    auStack_50[0] = auStack_50[0] & 0xffffff00;
    FUN_005542c0("Place",5);
    uStack_8._0_1_ = 2;
    FUN_008ce100(&uStack_18,&param_2,auStack_50,0);
    uStack_8._0_1_ = 4;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 4;
    if (0xf < uStack_3c) {
      uVar7 = uStack_3c + 1;
      uVar8 = auStack_50[0];
      if (0xfff < uVar7) {
        uVar8 = *(uint *)(auStack_50[0] - 4);
        uVar7 = uStack_3c + 0x24;
        if (0x1f < (auStack_50[0] - uVar8) - 4) {
          uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar8,uVar7);
    }
    uStack_40 = 0;
    uStack_3c = 0xf;
    auStack_50[0] = auStack_50[0] & 0xffffff00;
    fVar9 = (float10)FUN_01683110();
    dStack_20 = (double)fVar9;
    if (*(char *)(param_1 + 0x1de) == '\0') {
      FUN_00f25d60(uStack_18,param_1);
      uVar6 = FUN_005c2760(iVar5);
      FUN_00ae4030(uVar6);
      fVar9 = (float10)FUN_01683110();
      dStack_30 = (double)fVar9;
      FUN_0090daf0();
      piVar2 = *(int **)(param_1 + 0x43c);
      FUN_008b5970(*piVar2 - (int)piVar2,piVar2[1] - (int)piVar2);
      FUN_00b03d60(iVar5);
      fVar9 = (float10)FUN_01683110();
      dStack_38 = (double)fVar9;
      *(double *)(*(int *)(param_1 + 0x1b8) + 0x2e8) = dStack_20 - dStack_28;
      *(double *)(*(int *)(param_1 + 0x1b8) + 0x2f0) = dStack_30 - dStack_20;
      *(double *)(*(int *)(param_1 + 0x1b8) + 0x2f8) = dStack_38 - dStack_30;
      FUN_008b1800();
      if (*(char *)(param_1 + 0x1de) != '\x01') {
        *(undefined *)(param_1 + 0x1de) = 1;
        FUN_006eccd0();
      }
      if (iVar5 != 0) {
        FUN_00634b40();
      }
      iVar5 = FUN_00b8a0a0();
    }
    else {
      puVar4 = (undefined4 *)FUN_009cc5b0(auStack_68);
      uStack_8._0_1_ = 5;
      if (0xf < (uint)puVar4[5]) {
        puVar4 = (undefined4 *)*puVar4;
      }
      FUN_0087c6f0("Error","loadContent re-entrant post",puVar4,0,0,0,3);
      iVar5 = FUN_005507b0();
    }
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar2 = piStack_14 + 1;
      iVar1 = *piVar2;
      iVar5 = *piVar2;
      *piVar2 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        iVar5 = (**(code **)*piStack_14)();
        LOCK();
        piVar2 = piStack_14 + 2;
        iVar1 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          iVar5 = (**(code **)(*piStack_14 + 4))();
        }
      }
    }
  }
  else {
    ExceptionList = &pvStack_10;
    puVar4 = (undefined4 *)FUN_009cc5b0(auStack_50);
    uStack_8._0_1_ = 1;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    iVar5 = FUN_0087c6f0("Error","loadContent re-entrant",puVar4,0,0,0,3);
    if (0xf < uStack_3c) {
      uVar7 = uStack_3c + 1;
      uVar8 = auStack_50[0];
      if (0xfff < uVar7) {
        uVar8 = *(uint *)(auStack_50[0] - 4);
        uVar7 = uStack_3c + 0x24;
        if (0x1f < (auStack_50[0] - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      iVar5 = FUN_01674ea0(uVar8,uVar7);
    }
  }
  if (0xf < in_stack_00000018) {
    uVar8 = in_stack_00000018 + 1;
    puVar4 = param_2;
    if (0xfff < uVar8) {
      puVar4 = (undefined4 *)param_2[-1];
      uVar8 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_2 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar5 = FUN_01674ea0(puVar4,uVar8);
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15834 ; VA 0x008ff6c0 ; FUN_008ff6c0 */

void __thiscall FUN_008ff6c0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  int aiStack_28 [5];
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0x1de) == '\0') {
    ExceptionList = &pvStack_10;
    FUN_00f25d60(param_4,param_1);
    iVar4 = param_1 + 0xc;
    uVar3 = FUN_005c2760(iVar4);
    FUN_00ae4030(uVar3);
    FUN_0090daf0();
    piVar1 = *(int **)(param_1 + 0x43c);
    FUN_008b5970(*piVar1 - (int)piVar1,piVar1[1] - (int)piVar1);
    FUN_00b03d60(iVar4);
    FUN_008b1800();
    if (*(char *)(param_1 + 0x1de) != '\x01') {
      *(undefined *)(param_1 + 0x1de) = 1;
      FUN_006eccd0();
    }
    if (iVar4 != 0) {
      FUN_00634b40();
    }
    FUN_00b8a0a0();
  }
  else {
    ExceptionList = &pvStack_10;
    puVar2 = (undefined4 *)FUN_01675640(aiStack_28,&DAT_018bed48,param_2,param_3);
    uStack_8 = 0;
    if (0xf < (uint)puVar2[5]) {
      puVar2 = (undefined4 *)*puVar2;
    }
    FUN_0087c6f0("Error","loadContent re-entrant",puVar2,0,0,0,3);
    if (0xf < uStack_14) {
      uVar5 = uStack_14 + 1;
      iVar4 = aiStack_28[0];
      if (0xfff < uVar5) {
        iVar4 = *(int *)(aiStack_28[0] + -4);
        uVar5 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar4,uVar5);
      ExceptionList = pvStack_10;
      return;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15835 ; VA 0x008ff775 ; FUN_008ff775 */

void FUN_008ff775(void)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  int unaff_EBP;
  int unaff_EDI;
  
  FUN_00f25d60(*(undefined4 *)(unaff_EBP + 0x10));
  iVar1 = unaff_EDI + 0xc;
  uVar3 = FUN_005c2760(iVar1);
  FUN_00ae4030(uVar3);
  FUN_0090daf0();
  piVar2 = *(int **)(unaff_EDI + 0x43c);
  FUN_008b5970(*piVar2 - (int)piVar2,piVar2[1] - (int)piVar2);
  FUN_00b03d60(iVar1);
  FUN_008b1800();
  if (*(char *)(unaff_EDI + 0x1de) != '\x01') {
    *(undefined *)(unaff_EDI + 0x1de) = 1;
    FUN_006eccd0();
  }
  if (iVar1 != 0) {
    FUN_00634b40();
  }
  FUN_00b8a0a0();
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return;
}



/* FUNCTION 15836 ; VA 0x008ff820 ; FUN_008ff820 */

int __thiscall FUN_008ff820(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 ****ppppuVar4;
  int iVar5;
  uint uVar6;
  int aiStack_50 [5];
  uint uStack_3c;
  undefined4 ***apppuStack_38 [4];
  int iStack_28;
  uint uStack_24;
  int *piStack_20;
  int *piStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c4918;
  pvStack_10 = ExceptionList;
  if (*(char *)(param_1 + 0x268) == '\0') {
    ExceptionList = &pvStack_10;
    *(undefined *)(param_1 + 0x268) = 1;
    iStack_14 = param_1;
    if (param_1 != -0xc) {
      FUN_005c2760();
    }
    uVar2 = FUN_008cd320();
    FUN_0054ef60(uVar2);
    uStack_8 = 0;
    if (iStack_28 != 0) {
      ppppuVar4 = apppuStack_38;
      if (0xf < uStack_24) {
        ppppuVar4 = (undefined4 ****)apppuStack_38[0];
      }
      if (*(char *)(iStack_28 + -1 + (int)ppppuVar4) != '/') {
        FUN_005558a0(0x2f);
      }
    }
    iStack_18 = FUN_00635890();
    if (iStack_18 != 0) {
      FUN_006eccd0();
    }
    piVar3 = (int *)FUN_01674e20(0x40);
    if (piVar3 == (int *)0x0) {
      piVar3 = (int *)0x0;
    }
    else {
      piVar3[1] = 1;
      piVar3[2] = 1;
      *piVar3 = (int)std::_Ref_count_obj<class_RBX::CorescriptConfigurer>::vftable;
      piVar3[4] = 0;
      piVar3[5] = 0;
      piVar3[7] = 0;
      piVar3[8] = 0;
      piVar3[3] = (int)RBX::CorescriptConfigurer::vftable;
      piVar3[0xe] = 0;
      piVar3[0xf] = 0xf;
      *(undefined *)(piVar3 + 10) = 0;
    }
    piStack_20 = piVar3 + 3;
    piStack_1c = piVar3;
    if ((piStack_20 != (int *)0x0) && ((piVar3[5] == 0 || (*(int *)(piVar3[5] + 4) == 0)))) {
      if (piVar3 != (int *)0x0) {
        LOCK();
        piVar3[1] = piVar3[1] + 1;
        UNLOCK();
        if (piVar3 != (int *)0x0) {
          LOCK();
          piVar3[2] = piVar3[2] + 1;
          UNLOCK();
        }
      }
      piVar3[4] = (int)piStack_20;
      piVar1 = (int *)piVar3[5];
      piVar3[5] = (int)piVar3;
      if (piVar1 != (int *)0x0) {
        LOCK();
        iVar5 = piVar1[2] + -1;
        piVar1[2] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar5 = piVar3[1] + -1;
        piVar3[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piVar3)();
          LOCK();
          iVar5 = piVar3[2] + -1;
          piVar3[2] = iVar5;
          UNLOCK();
          if (iVar5 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
      }
    }
    uStack_8._0_1_ = 1;
    if (piVar3 + 10 != param_3) {
      piVar1 = param_3 + 4;
      if (0xf < (uint)param_3[5]) {
        param_3 = (int *)*param_3;
      }
      FUN_005542c0(param_3,*piVar1);
    }
    FUN_005ffa40(param_2);
    ppppuVar4 = apppuStack_38;
    if (0xf < uStack_24) {
      ppppuVar4 = (undefined4 ****)apppuStack_38[0];
    }
    uVar2 = FUN_01675640(aiStack_50,"{ \"BaseUrl\": \"%s\" }",ppppuVar4);
    uStack_8._0_1_ = 2;
    param_1 = FUN_0063a390(7,iStack_14,uVar2,0);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (0xf < uStack_3c) {
      uVar6 = uStack_3c + 1;
      iVar5 = aiStack_50[0];
      if (0xfff < uVar6) {
        iVar5 = *(int *)(aiStack_50[0] + -4);
        uVar6 = uStack_3c + 0x24;
        if (0x1f < (aiStack_50[0] - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      param_1 = FUN_01674ea0(iVar5,uVar6);
    }
    if (iStack_18 != 0) {
      param_1 = FUN_006eccd0();
    }
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 1;
      iVar5 = *piVar1;
      param_1 = *piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        param_1 = (**(code **)*piVar3)();
        LOCK();
        piVar1 = piVar3 + 2;
        iVar5 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar5 == 1) {
          param_1 = (**(code **)(*piVar3 + 4))();
        }
      }
    }
    if (0xf < uStack_24) {
      uVar6 = uStack_24 + 1;
      ppppuVar4 = (undefined4 ****)apppuStack_38[0];
      if (0xfff < uVar6) {
        ppppuVar4 = (undefined4 ****)apppuStack_38[0][-1];
        uVar6 = uStack_24 + 0x24;
        if (0x1f < (uint)((int)apppuStack_38[0] + (-4 - (int)ppppuVar4))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      param_1 = FUN_01674ea0(ppppuVar4,uVar6);
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15837 ; VA 0x008ffaa0 ; FUN_008ffaa0 */

int FUN_008ffaa0(int param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined auStack_58 [24];
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  char acStack_1c [4];
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c4950;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0("Connection",10);
  uStack_8._0_1_ = 1;
  iVar4 = FUN_00a34a10(acStack_1c,auStack_40,param_1,0);
  uStack_8._0_1_ = 3;
  uVar3 = (undefined)uStack_8;
  uStack_8._0_1_ = 3;
  if (0xf < uStack_2c) {
    uVar6 = uStack_2c + 1;
    uVar5 = auStack_40[0];
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(auStack_40[0] - 4);
      uVar6 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar5) - 4) {
        uStack_8._0_1_ = uVar3;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(uVar5,uVar6);
  }
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  if (acStack_1c[0] != '\0') {
    iVar4 = FUN_008e2f30(-(uint)(param_1 != 0) & param_1 + 0xcU);
    if (iVar4 != 0) {
      if (DAT_01d64500 == '\0') {
        FUN_01255470(3,0,0,0);
        iVar4 = FUN_0094ee10(auStack_58,auStack_18,"Connection");
      }
      else {
        uStack_28 = 0;
        uStack_24 = 0;
        uStack_20 = 0;
        uStack_8._0_1_ = 4;
        FUN_01255470(3,0,0,0);
        FUN_00951870(auStack_58,auStack_18,"Connection",&uStack_28);
        uStack_8._0_1_ = 5;
        iVar4 = FUN_00577b20();
      }
    }
    if (acStack_1c[0] != '\0') {
      FUN_0056cd30();
      iVar4 = FUN_0056cd30();
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*param_2 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 15838 ; VA 0x008ffc40 ; FUN_008ffc40 */

void FUN_008ffc40(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0090bc60();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15839 ; VA 0x008ffc80 ; FUN_008ffc80 */

void FUN_008ffc80(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0090bd10();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15840 ; VA 0x008ffcc0 ; FUN_008ffcc0 */

void FUN_008ffcc0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0090bdc0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15841 ; VA 0x008ffd00 ; FUN_008ffd00 */

void FUN_008ffd00(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0090bea0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15842 ; VA 0x008ffd40 ; FUN_008ffd40 */

void FUN_008ffd40(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0090bf80();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15843 ; VA 0x008ffd80 ; FUN_008ffd80 */

void FUN_008ffd80(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = thunk_FUN_0090c030();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15844 ; VA 0x008ffdc0 ; FUN_008ffdc0 */

void FUN_008ffdc0(int *param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar1 = *param_1;
  iVar2 = FUN_0090c0c0();
  if (iVar1 == iVar2) {
    piVar3 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar3 = (int *)0x0;
    }
    FUN_009cb050(*piVar3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15845 ; VA 0x008ffe00 ; FUN_008ffe00 */

void FUN_008ffe00(undefined4 *param_1)

{
  undefined4 *puVar1;
  undefined4 ****ppppuVar2;
  undefined4 ****ppppuVar3;
  uint uVar4;
  undefined4 ****ppppuVar5;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 *in_stack_0000001c;
  undefined4 in_stack_0000002c;
  uint in_stack_00000030;
  undefined4 *in_stack_00000034;
  undefined4 in_stack_00000044;
  uint in_stack_00000048;
  int in_stack_0000004c;
  undefined4 ***apppuStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  undefined4 ***apppuStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 ***apppuStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c4990;
  pvStack_10 = ExceptionList;
  uStack_8 = 2;
  puVar1 = &param_1;
  if (0xf < in_stack_00000018) {
    puVar1 = param_1;
  }
  ExceptionList = &pvStack_10;
  FUN_0151d700(apppuStack_5c,puVar1,in_stack_00000014);
  uStack_8._0_1_ = 3;
  puVar1 = &stack0x0000001c;
  if (0xf < in_stack_00000030) {
    puVar1 = in_stack_0000001c;
  }
  FUN_0151d700(apppuStack_44,puVar1,in_stack_0000002c);
  uStack_8._0_1_ = 4;
  puVar1 = &stack0x00000034;
  if (0xf < in_stack_00000048) {
    puVar1 = in_stack_00000034;
  }
  FUN_0151d700(apppuStack_2c,puVar1,in_stack_00000044);
  ppppuVar3 = apppuStack_2c;
  if (0xf < uStack_18) {
    ppppuVar3 = (undefined4 ****)apppuStack_2c[0];
  }
  ppppuVar5 = apppuStack_44;
  if (0xf < uStack_30) {
    ppppuVar5 = (undefined4 ****)apppuStack_44[0];
  }
  ppppuVar2 = apppuStack_5c;
  if (0xf < uStack_48) {
    ppppuVar2 = (undefined4 ****)apppuStack_5c[0];
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  FUN_0087c450(ppppuVar2,ppppuVar5,ppppuVar3,in_stack_0000004c,in_stack_0000004c >> 0x1f,0);
  if (0xf < uStack_18) {
    uVar4 = uStack_18 + 1;
    ppppuVar3 = (undefined4 ****)apppuStack_2c[0];
    if (0xfff < uVar4) {
      ppppuVar3 = (undefined4 ****)apppuStack_2c[0][-1];
      uVar4 = uStack_18 + 0x24;
      if (0x1f < (uint)((int)apppuStack_2c[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar3,uVar4);
  }
  uStack_1c = 0;
  uStack_18 = 0xf;
  apppuStack_2c[0] = (undefined4 ***)((uint)apppuStack_2c[0] & 0xffffff00);
  if (0xf < uStack_30) {
    uVar4 = uStack_30 + 1;
    ppppuVar3 = (undefined4 ****)apppuStack_44[0];
    if (0xfff < uVar4) {
      ppppuVar3 = (undefined4 ****)apppuStack_44[0][-1];
      uVar4 = uStack_30 + 0x24;
      if (0x1f < (uint)((int)apppuStack_44[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar3,uVar4);
  }
  uStack_34 = 0;
  uStack_30 = 0xf;
  apppuStack_44[0] = (undefined4 ***)((uint)apppuStack_44[0] & 0xffffff00);
  if (0xf < uStack_48) {
    uVar4 = uStack_48 + 1;
    ppppuVar3 = (undefined4 ****)apppuStack_5c[0];
    if (0xfff < uVar4) {
      ppppuVar3 = (undefined4 ****)apppuStack_5c[0][-1];
      uVar4 = uStack_48 + 0x24;
      if (0x1f < (uint)((int)apppuStack_5c[0] + (-4 - (int)ppppuVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar3,uVar4);
  }
  uStack_4c = 0;
  uStack_48 = 0xf;
  apppuStack_5c[0] = (undefined4 ***)((uint)apppuStack_5c[0] & 0xffffff00);
  if (0xf < in_stack_00000018) {
    uVar4 = in_stack_00000018 + 1;
    puVar1 = param_1;
    if (0xfff < uVar4) {
      puVar1 = (undefined4 *)param_1[-1];
      uVar4 = in_stack_00000018 + 0x24;
      if (0x1f < (uint)((int)param_1 + (-4 - (int)puVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar1,uVar4);
  }
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_1 = (undefined4 *)((uint)param_1 & 0xffffff00);
  if (0xf < in_stack_00000030) {
    uVar4 = in_stack_00000030 + 1;
    puVar1 = in_stack_0000001c;
    if (0xfff < uVar4) {
      puVar1 = (undefined4 *)in_stack_0000001c[-1];
      uVar4 = in_stack_00000030 + 0x24;
      if (0x1f < (uint)((int)in_stack_0000001c + (-4 - (int)puVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar1,uVar4);
  }
  in_stack_0000002c = 0;
  in_stack_00000030 = 0xf;
  in_stack_0000001c = (undefined4 *)((uint)in_stack_0000001c & 0xffffff00);
  if (0xf < in_stack_00000048) {
    uVar4 = in_stack_00000048 + 1;
    puVar1 = in_stack_00000034;
    if (0xfff < uVar4) {
      puVar1 = (undefined4 *)in_stack_00000034[-1];
      uVar4 = in_stack_00000048 + 0x24;
      if (0x1f < (uint)((int)in_stack_00000034 + (-4 - (int)puVar1))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar1,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15846 ; VA 0x00900090 ; FUN_00900090 */

void FUN_00900090(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = 0;
      param_2[3] = 0;
      if (param_1[3] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[3] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      if (param_3 != 1) {
        return;
      }
      piVar3 = (int *)param_1[3];
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[2] + -1;
        piVar3[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
      piVar3 = (int *)param_1[1];
      if (piVar3 == (int *)0x0) {
        return;
      }
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 != 1) {
        return;
      }
                    /* WARNING: Could not recover jumptable at 0x00900194. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar3 + 4))();
      return;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[3];
      if (piVar3 != (int *)0x0) {
        LOCK();
        iVar2 = piVar3[2] + -1;
        piVar3[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piVar3 + 4))();
        }
      }
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return;
      }
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 != 1) {
        return;
      }
                    /* WARNING: Could not recover jumptable at 0x009000e6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar3 + 4))();
      return;
    }
    if (param_3 == 3) {
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1da9ee0);
      piVar3 = (int *)0x0;
      if (iVar2 == 0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return;
    }
  }
  *param_2 = (int)&<lambda_38e73deea91218fd4d8abe950aaef86c>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 15847 ; VA 0x009001b0 ; FUN_009001b0 */

void FUN_009001b0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179a13f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x50);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008e66d0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008e9ac0();
        FUN_01674ea0(iVar2,0x50);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1daa32c);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_5ba111968921352a8e7968ff9a54b0d7>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15848 ; VA 0x00900300 ; FUN_00900300 */

int * FUN_00900300(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x009003d7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00900356. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daa510);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_66a25a478e2130c6202618ba7a13e41c>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 15849 ; VA 0x009003f0 ; FUN_009003f0 */

void FUN_009003f0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffcf;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x48);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008e67f0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008e9ba0();
        FUN_01674ea0(iVar2,0x48);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1daa2f4);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_7c948c89354980eef5f9f0f130281f18>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15850 ; VA 0x00900540 ; FUN_00900540 */

int * FUN_00900540(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x009005eb. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x0090057e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daa214);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_9df699ae5314c426461ab48b894588de>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 15851 ; VA 0x00900600 ; FUN_00900600 */

void FUN_00900600(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffcf;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x48);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008e68f0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008e9ba0();
        FUN_01674ea0(iVar2,0x48);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1daa24c);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_a7632e5c95c11918ee1ca176e8bf9774>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15852 ; VA 0x00900750 ; FUN_00900750 */

void FUN_00900750(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ad59f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x78);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008e69f0(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008e9c70();
        FUN_01674ea0(iVar2,0x78);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1daa2bc);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_b5f30603b33d0cc0e5856399e3213ef9>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15853 ; VA 0x009008a0 ; FUN_009008a0 */

void FUN_009008a0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int iVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c007f;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar2 = *param_1;
      ExceptionList = &pvStack_10;
      iVar1 = FUN_01674e20(0x68);
      uStack_8 = 0;
      if (iVar1 != 0) {
        iVar2 = FUN_008e6b20(iVar2);
        *param_2 = iVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar2 = *param_2;
      if (iVar2 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008e9da0();
        FUN_01674ea0(iVar2,0x68);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar2 = FUN_0170d8dd(*param_2 + 4,0x1daa284);
      if (iVar2 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&<lambda_d14a04b357089c9c513a056dec7ea978>::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15854 ; VA 0x009009f0 ; FUN_009009f0 */

int * FUN_009009f0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00900ac7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00900a46. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daa364);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_d74b8cfce77966fc9625466f602214cb>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 15855 ; VA 0x00900ae0 ; FUN_00900ae0 */

int * FUN_00900ae0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00900bb7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00900b36. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daa548);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_ea4f7872761da925b816f66f731ab376>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 15856 ; VA 0x00900bd0 ; FUN_00900bd0 */

int * FUN_00900bd0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar3;
  int *piVar4;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = 0;
      param_2[1] = 0;
      if (param_1[1] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[1] + 8);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      *param_2 = *param_1;
      piVar3 = (int *)param_1[1];
      param_2[1] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[1];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00900c7b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[1];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00900c0e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1da9f18);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&<lambda_feecedf5089cb246572979fb17036cf9>::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 15857 ; VA 0x00900c90 ; FUN_00900c90 */

void FUN_00900c90(int *param_1,int *param_2,int param_3)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c49af;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x30);
      uStack_8 = 0;
      if (iVar3 != 0) {
        iVar4 = FUN_008e7190(iVar4);
        *param_2 = iVar4;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      puVar1 = (uint *)*param_2;
      if (puVar1 != (uint *)0x0) {
        ExceptionList = &pvStack_10;
        FUN_0056b650();
        uVar2 = *puVar1;
        uStack_8 = 1;
        if (uVar2 != 0) {
          if ((uVar2 & 1) == 0) {
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              (**(code **)(uVar2 & 0xfffffffe))(puVar1 + 2,puVar1 + 2,2);
            }
          }
          *puVar1 = 0;
        }
        FUN_01674ea0(puVar1,0x30);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1da9d74);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<struct_boost::_bi::unspecified,class_boost::function<void___cdecl(class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::shared_ptr<class_std::exception>)>,class_boost::_bi::list2<class_boost::_bi::value<class_std::shared_ptr<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>_>,class_boost::_bi::value<class_std::shared_ptr<class_std::exception>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15858 ; VA 0x00900e00 ; FUN_00900e00 */

void FUN_00900e00(int *param_1,int *param_2,int param_3)

{
  uint *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar4 = *param_1;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar3 != 0) {
        iVar4 = FUN_008e7230(iVar4);
        *param_2 = iVar4;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      puVar1 = (uint *)*param_2;
      if (puVar1 != (uint *)0x0) {
        uVar2 = *puVar1;
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(puVar1 + 2,puVar1 + 2,2);
            }
          }
          *puVar1 = 0;
        }
        FUN_01674ea0(puVar1,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar4 = FUN_0170d8dd(*param_2 + 4,0x1daa76c);
      if (iVar4 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<struct_boost::_bi::unspecified,class_boost::function<void___cdecl(bool)>,class_boost::_bi::list1<class_boost::_bi::value<bool>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15859 ; VA 0x00900f70 ; FUN_00900f70 */

void FUN_00900f70(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017bffcf;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar2 = (undefined4 *)FUN_01674e20(0x48);
      uStack_8 = 0;
      if (puVar2 != (undefined4 *)0x0) {
        *puVar2 = *puVar1;
        FUN_008e7950(puVar1 + 2);
        *param_2 = (int)puVar2;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        ExceptionList = &pvStack_10;
        FUN_008c3510();
        FUN_01674ea0(iVar3,0x48);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1daa39c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>*,class_std::exception*,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list4<struct_boost::arg<1>,struct_boost::arg<2>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15860 ; VA 0x009010c0 ; FUN_009010c0 */

void FUN_009010c0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      return;
    }
    if (param_3 == 2) {
      return;
    }
    if (param_3 == 3) {
      iVar1 = FUN_0170d8dd(*param_2 + 4,0x1da9bc4);
      piVar2 = (int *)0x0;
      if (iVar1 == 0) {
        piVar2 = param_1;
      }
      *param_2 = (int)piVar2;
      return;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_RBX::DataModel*),class_boost::_bi::list1<class_boost::_bi::value<class_RBX::DataModel*>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return;
}



/* FUNCTION 15861 ; VA 0x00901130 ; FUN_00901130 */

void FUN_00901130(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008c1ba0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 8);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x10,iVar3 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar3 + 8) = 0;
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1da9abc);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>),class_boost::_bi::list2<class_boost::_bi::value<class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15862 ; VA 0x009012a0 ; FUN_009012a0 */

void FUN_009012a0(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008c1ba0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 8);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x10,iVar3 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar3 + 8) = 0;
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1da98ac);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>,class_std::shared_ptr<class_std::vector<class_std::shared_ptr<class_RBX::Instance>,class_std::allocator<class_std::shared_ptr<class_RBX::Instance>_>_>_const_>),class_boost::_bi::list2<class_boost::_bi::value<class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15863 ; VA 0x00901410 ; FUN_00901410 */

void FUN_00901410(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c00df;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x28);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008c1ba0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 8);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x10,iVar3 + 0x10,2);
            }
          }
          *(undefined4 *)(iVar3 + 8) = 0;
        }
        FUN_01674ea0(iVar3,0x28);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1da99f4);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>,bool),class_boost::_bi::list2<class_boost::_bi::value<class_boost::function<void___cdecl(class_RBX::Reflection::Variant)>_>,struct_boost::arg<1>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15864 ; VA 0x00901580 ; FUN_00901580 */

int * FUN_00901580(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = 0;
      param_2[2] = 0;
      if (param_1[2] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[2] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[1] = param_1[1];
      piVar3 = (int *)param_1[2];
      param_2[2] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[2];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00901662. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[2];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x009015d6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daa7e4);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::shared_ptr<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>)>_>,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list3<class_boost::_bi::value<class_std::shared_ptr<class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>,class_boost::function<void___cdecl(class_std::shared_ptr<struct_RBX::Reflection::Tuple_const_>)>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>)>_>_>,struct_boost::arg<1>,struct_boost::arg<2>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 15865 ; VA 0x00901680 ; FUN_00901680 */

void FUN_00901680(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c49af;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar5 = (undefined4 *)FUN_01674e20(0x30);
      uStack_8 = 0;
      if (puVar5 != (undefined4 *)0x0) {
        *puVar5 = *puVar1;
        FUN_008e75a0(puVar1 + 2);
        *param_2 = (int)puVar5;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar6 = *param_2;
      if (iVar6 != 0) {
        uVar2 = *(uint *)(iVar6 + 0x10);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(iVar6 + 0x18,iVar6 + 0x18,2);
            }
          }
          *(undefined4 *)(iVar6 + 0x10) = 0;
        }
        piVar3 = *(int **)(iVar6 + 0xc);
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
        FUN_01674ea0(iVar6,0x30);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar6 = FUN_0170d8dd(*param_2 + 4,0x1da9f54);
      if (iVar6 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::DataModel>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>),class_boost::_bi::list3<class_boost::_bi::value<class_std::weak_ptr<class_RBX::DataModel>_>,struct_boost::arg<1>,class_boost::_bi::value<class_boost::function<void___cdecl(class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15866 ; VA 0x00901810 ; FUN_00901810 */

void FUN_00901810(int *param_1,int *param_2,int param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c49af;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      puVar1 = (undefined4 *)*param_1;
      ExceptionList = &pvStack_10;
      puVar5 = (undefined4 *)FUN_01674e20(0x30);
      uStack_8 = 0;
      if (puVar5 != (undefined4 *)0x0) {
        *puVar5 = *puVar1;
        FUN_008e75a0(puVar1 + 2);
        *param_2 = (int)puVar5;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar6 = *param_2;
      if (iVar6 != 0) {
        uVar2 = *(uint *)(iVar6 + 0x10);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar2 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar2 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar2 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar2 & 0xfffffffe))(iVar6 + 0x18,iVar6 + 0x18,2);
            }
          }
          *(undefined4 *)(iVar6 + 0x10) = 0;
        }
        piVar3 = *(int **)(iVar6 + 0xc);
        if (piVar3 != (int *)0x0) {
          LOCK();
          iVar4 = piVar3[2] + -1;
          piVar3[2] = iVar4;
          UNLOCK();
          if (iVar4 == 0) {
            (**(code **)(*piVar3 + 4))();
          }
        }
        FUN_01674ea0(iVar6,0x30);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar6 = FUN_0170d8dd(*param_2 + 4,0x1daa0f4);
      if (iVar6 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,void_(__cdecl*)(class_std::weak_ptr<class_RBX::DataModel>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_boost::function<void___cdecl(void)>),class_boost::_bi::list3<class_boost::_bi::value<class_std::weak_ptr<class_RBX::DataModel>_>,struct_boost::arg<1>,class_boost::_bi::value<class_boost::function<void___cdecl(void)>_>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15867 ; VA 0x009019a0 ; FUN_009019a0 */

int * FUN_009019a0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      param_2[3] = 0;
      param_2[4] = 0;
      if (param_1[4] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[4] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[3] = param_1[3];
      piVar3 = (int *)param_1[4];
      param_2[4] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[4];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00901a8e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[4];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x009019f6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daa69c);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf1<void,class_RBX::DataModel,class_std::shared_ptr<class_RBX::CEvent>_>,class_boost::_bi::list2<class_boost::_bi::value<class_RBX::DataModel*>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::CEvent>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 15868 ; VA 0x00901ab0 ; FUN_00901ab0 */

int * FUN_00901ab0(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_3 != 4) {
    if ((param_3 == 0) || (param_3 == 1)) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      param_2[3] = 0;
      param_2[4] = 0;
      if (param_1[4] != 0) {
        LOCK();
        piVar3 = (int *)(param_1[4] + 4);
        *piVar3 = *piVar3 + 1;
        UNLOCK();
      }
      param_2[3] = param_1[3];
      piVar3 = (int *)param_1[4];
      param_2[4] = (int)piVar3;
      if (param_3 != 1) {
        return piVar3;
      }
      piVar4 = (int *)param_1[4];
      if (piVar4 == (int *)0x0) {
        return piVar3;
      }
      LOCK();
      piVar3 = piVar4 + 1;
      iVar1 = *piVar3;
      piVar2 = (int *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar4)();
      LOCK();
      piVar3 = piVar4 + 2;
      iVar1 = *piVar3;
      *piVar3 = *piVar3 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00901b9e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar4 + 4))();
      return piVar3;
    }
    if (param_3 == 2) {
      piVar3 = (int *)param_2[4];
      if (piVar3 == (int *)0x0) {
        return param_2;
      }
      LOCK();
      piVar4 = piVar3 + 1;
      iVar1 = *piVar4;
      piVar2 = (int *)*piVar4;
      *piVar4 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 != 0) {
        return piVar2;
      }
      piVar2 = (int *)(**(code **)*piVar3)();
      LOCK();
      piVar4 = piVar3 + 2;
      iVar1 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar1 != 1) {
        return piVar2;
      }
                    /* WARNING: Could not recover jumptable at 0x00901b06. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      piVar3 = (int *)(**(code **)(*piVar3 + 4))();
      return piVar3;
    }
    if (param_3 == 3) {
      piVar4 = (int *)FUN_0170d8dd(*param_2 + 4,0x1daa584);
      piVar3 = (int *)0x0;
      if (piVar4 == (int *)0x0) {
        piVar3 = param_1;
      }
      *param_2 = (int)piVar3;
      return piVar4;
    }
  }
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf2<void,class_RBX::DataModel,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_std::shared_ptr<class_RBX::CEvent>_>,class_boost::_bi::list3<class_boost::_bi::value<class_RBX::DataModel*>,struct_boost::arg<1>,class_boost::_bi::value<class_std::shared_ptr<class_RBX::CEvent>_>_>_>
                   ::RTTI_Type_Descriptor;
  *(undefined2 *)(param_2 + 1) = 0;
  return param_2;
}



/* FUNCTION 15869 ; VA 0x00901bc0 ; FUN_00901bc0 */

void FUN_00901bc0(int *param_1,int *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c49af;
  pvStack_10 = ExceptionList;
  if (param_3 != 4) {
    if (param_3 == 0) {
      iVar3 = *param_1;
      ExceptionList = &pvStack_10;
      iVar2 = FUN_01674e20(0x30);
      uStack_8 = 0;
      if (iVar2 != 0) {
        iVar3 = FUN_008e72f0(iVar3);
        *param_2 = iVar3;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 1) {
      *param_2 = *param_1;
      *param_1 = 0;
      return;
    }
    if (param_3 == 2) {
      iVar3 = *param_2;
      if (iVar3 != 0) {
        uVar1 = *(uint *)(iVar3 + 0x10);
        uStack_8 = 1;
        ExceptionList = &pvStack_10;
        if (uVar1 != 0) {
          ExceptionList = &pvStack_10;
          if ((uVar1 & 1) == 0) {
            ExceptionList = &pvStack_10;
            if (*(code **)(uVar1 & 0xfffffffe) != (code *)0x0) {
              ExceptionList = &pvStack_10;
              (**(code **)(uVar1 & 0xfffffffe))(iVar3 + 0x18,iVar3 + 0x18,2);
            }
          }
          *(undefined4 *)(iVar3 + 0x10) = 0;
        }
        FUN_01674ea0(iVar3,0x30);
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
    if (param_3 == 3) {
      ExceptionList = &pvStack_10;
      iVar3 = FUN_0170d8dd(*param_2 + 4,0x1da9c3c);
      if (iVar3 == 0) {
        *param_2 = *param_1;
        ExceptionList = pvStack_10;
        return;
      }
      *param_2 = 0;
      ExceptionList = pvStack_10;
      return;
    }
  }
  *(undefined2 *)(param_2 + 1) = 0;
  *param_2 = (int)&boost::_bi::
                   bind_t<void,class_boost::_mfi::mf3<void,class_RBX::DataModel,class_boost::function<void___cdecl(bool)>,class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>*,class_std::exception*>,class_boost::_bi::list4<class_boost::_bi::value<class_RBX::DataModel*>,class_boost::_bi::value<class_boost::function<void___cdecl(bool)>_>,struct_boost::arg<1>,struct_boost::arg<2>_>_>
                   ::RTTI_Type_Descriptor;
  return;
}



/* FUNCTION 15870 ; VA 0x00901d30 ; FUN_00901d30 */

int __thiscall FUN_00901d30(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c49c8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar3 = FUN_006fdf60();
  if (*(int *)(param_1 + 0x498) == 0) {
    if (iVar3 != 0) {
      iVar3 = FUN_00cd5490();
      if ((char)iVar3 != '\0') goto LAB_00901d7b;
    }
    iVar3 = FUN_0151f3f0();
  }
LAB_00901d7b:
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 15871 ; VA 0x00901dc0 ; FUN_00901dc0 */

void __fastcall FUN_00901dc0(int param_1)

{
  if (*(int *)(param_1 + 0x1a0) != 0) {
    FUN_00bb3ba0();
    return;
  }
  return;
}



/* FUNCTION 15872 ; VA 0x00901de0 ; FUN_00901de0 */

int __thiscall FUN_00901de0(int param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  int *in_stack_00000020;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c49f0;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (DAT_01d65192 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_01677760(DAT_01d65192,"onBoundCloseFunctionError - %s",&param_2);
  }
  *(int *)(param_1 + 0x498) = *(int *)(param_1 + 0x498) + -1;
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    in_stack_00000020[1] = in_stack_00000020[1] + 1;
    UNLOCK();
  }
  iVar4 = FUN_00901d30(in_stack_0000001c,in_stack_00000020);
  if (0xf < in_stack_00000018) {
    uVar6 = in_stack_00000018 + 1;
    uVar5 = param_2;
    if (0xfff < uVar6) {
      uVar5 = *(uint *)(param_2 - 4);
      uVar6 = in_stack_00000018 + 0x24;
      if (0x1f < (param_2 - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar4 = FUN_01674ea0(uVar5,uVar6);
  }
  piVar3 = in_stack_00000020;
  in_stack_00000014 = 0;
  in_stack_00000018 = 0xf;
  param_2 = param_2 & 0xffffff00;
  if (in_stack_00000020 != (int *)0x0) {
    LOCK();
    piVar1 = in_stack_00000020 + 1;
    iVar2 = *piVar1;
    iVar4 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar4 = (**(code **)*in_stack_00000020)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar4 = (**(code **)(*piVar3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar4;
}



/* FUNCTION 15873 ; VA 0x00901ee0 ; FUN_00901ee0 */

int __thiscall FUN_00901ee0(int param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c49c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(int *)(param_1 + 0x498) = *(int *)(param_1 + 0x498) + -1;
  uStack_8 = 0;
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  iVar3 = FUN_00901d30(param_2,param_3);
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 15874 ; VA 0x00901f70 ; FUN_00901f70 */

void FUN_00901f70(undefined4 param_1)

{
  char cVar1;
  
  FUN_008a9ee0(param_1);
  cVar1 = FUN_00983290(param_1);
  if (cVar1 != '\0') {
    FUN_008bb1f0();
  }
  return;
}



/* FUNCTION 15875 ; VA 0x00901fa0 ; FUN_00901fa0 */

void __thiscall FUN_00901fa0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined auStack_18 [4];
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  uStack_c = param_3;
  uStack_10 = param_2;
  uStack_14 = 0x901fb1;
  FUN_008a40d0();
  uStack_c = 1;
  uStack_10 = 0x901fbb;
  (*(code *)**(undefined4 **)(param_1 + -8))();
  if (*(int *)(param_1 + 0x2a0) != 0) {
    uStack_10 = param_3;
    FUN_0060dcd0(auStack_18,param_2);
    FUN_0089bf10();
  }
  return;
}



/* FUNCTION 15876 ; VA 0x00901ff0 ; FUN_00901ff0 */

void __thiscall FUN_00901ff0(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  
  *(int *)(param_1 + 0x224) = *(int *)(param_1 + 0x224) + 1;
  if (param_2 != 0) {
    iVar1 = *(int *)(param_2 + 0xc);
    iVar2 = FUN_00aff8c0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      *(int *)(param_1 + 0x220) = *(int *)(param_1 + 0x220) + 1;
    }
  }
  FUN_008aa0f0(param_2);
                    /* WARNING: Could not recover jumptable at 0x00902047. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)**(undefined4 **)(param_1 + -8))();
  return;
}



/* FUNCTION 15877 ; VA 0x00902050 ; FUN_00902050 */

void __thiscall FUN_00902050(int param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  *(int *)(param_1 + 0x224) = *(int *)(param_1 + 0x224) + -1;
  if (*param_2 != 0) {
    iVar1 = *(int *)(*param_2 + 0xc);
    iVar2 = FUN_00aff8c0();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
        (uint)*(ushort *)(iVar2 + 0x1da)) {
      *(int *)(param_1 + 0x220) = *(int *)(param_1 + 0x220) + -1;
    }
  }
  FUN_008aa110(param_2);
                    /* WARNING: Could not recover jumptable at 0x009020a9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)**(undefined4 **)(param_1 + -8))();
  return;
}



/* FUNCTION 15878 ; VA 0x009020b0 ; FUN_009020b0 */

void __thiscall FUN_009020b0(int param_1,int param_2)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0xb8) != 0) {
    iVar1 = FUN_0097bf90(param_1 + 0xc);
    if ((iVar1 != 0) && (*(int *)(param_2 + 0x34) == iVar1)) {
      FUN_006eccd0();
    }
  }
  return;
}



/* FUNCTION 15879 ; VA 0x009020f0 ; FUN_009020f0 */

void __thiscall FUN_009020f0(int param_1,int param_2)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0xbc) != 0) {
    iVar1 = FUN_0097bf90(param_1 + 0xc);
    if ((iVar1 != 0) && (*(int *)(param_2 + 0x34) == iVar1)) {
      FUN_006eccd0();
    }
  }
  return;
}



/* FUNCTION 15880 ; VA 0x00902130 ; FUN_00902130 */

void __thiscall FUN_00902130(int param_1,int param_2,int param_3)

{
  if (*(char *)(param_1 + 0x1dd) != '\0') {
    if (param_3 == 0) {
      if (param_2 == 1) {
        FUN_008b9860();
      }
    }
    else {
      if (param_3 == 1) {
        FUN_008bc070();
        return;
      }
      if (param_3 == 2) {
        FUN_008bc1f0();
        return;
      }
    }
  }
  return;
}



/* FUNCTION 15881 ; VA 0x00902190 ; FUN_00902190 */

undefined4 * __thiscall FUN_00902190(undefined4 *param_1,undefined4 *param_2,undefined8 param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  int *piVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7668;
  pvStack_10 = ExceptionList;
  puVar5 = param_1;
  if ((param_1[0x31] != 0) &&
     (ExceptionList = &pvStack_10, puVar4 = (undefined4 *)FUN_0097bf90(param_1 + 3), puVar5 = puVar4
     , puVar4 != (undefined4 *)0x0)) {
    puVar2 = (undefined4 *)param_2[1];
    puVar5 = puVar2;
    for (param_2 = (undefined4 *)*param_2; param_2 != puVar2; param_2 = param_2 + 2) {
      iVar3 = param_2[1];
      puVar5 = (undefined4 *)0x0;
      piVar7 = (int *)0x0;
      if (iVar3 != 0) {
        piVar7 = (int *)(iVar3 + 4);
        iVar3 = *(int *)(iVar3 + 4);
        while (iVar3 != 0) {
          LOCK();
          iVar6 = *piVar7;
          if (iVar3 == iVar6) {
            *piVar7 = iVar3 + 1;
            iVar6 = iVar3;
          }
          UNLOCK();
          if (iVar6 == iVar3) {
            puVar5 = (undefined4 *)*param_2;
            piVar7 = (int *)param_2[1];
            goto LAB_0090222c;
          }
          iVar3 = *piVar7;
        }
        puVar5 = (undefined4 *)0x0;
        piVar7 = (int *)0x0;
      }
LAB_0090222c:
      uStack_8 = 0;
      if ((puVar5 != (undefined4 *)0x0) && ((undefined4 *)puVar5[0xd] == puVar4)) {
        *(undefined *)(param_1 + 0x9e) = 1;
        puVar5 = (undefined4 *)FUN_008ec650(param_3);
        if (piVar7 == (int *)0x0) {
          ExceptionList = pvStack_10;
          return puVar5;
        }
        LOCK();
        piVar1 = piVar7 + 1;
        iVar3 = *piVar1;
        puVar5 = (undefined4 *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 != 0) {
          ExceptionList = pvStack_10;
          return puVar5;
        }
        puVar5 = (undefined4 *)(**(code **)*piVar7)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 != 1) {
          ExceptionList = pvStack_10;
          return puVar5;
        }
        puVar5 = (undefined4 *)(**(code **)(*piVar7 + 4))();
        ExceptionList = pvStack_10;
        return puVar5;
      }
      uStack_8 = 0xffffffff;
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar1 = piVar7 + 1;
        iVar3 = *piVar1;
        puVar5 = (undefined4 *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar3 = *piVar1;
          puVar5 = (undefined4 *)*piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            puVar5 = (undefined4 *)(**(code **)(*piVar7 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 15882 ; VA 0x009022e0 ; FUN_009022e0 */

undefined4 * __thiscall FUN_009022e0(int param_1,undefined4 *param_2,undefined8 param_3)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  int *piVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b7668;
  pvStack_10 = ExceptionList;
  puVar5 = (undefined4 *)(param_1 + 0xc0);
  if ((*(int *)(param_1 + 0xc0) != 0) &&
     (ExceptionList = &pvStack_10, puVar4 = (undefined4 *)FUN_0097bf90(param_1 + 0xc),
     puVar5 = puVar4, puVar4 != (undefined4 *)0x0)) {
    puVar2 = (undefined4 *)param_2[1];
    puVar5 = puVar2;
    for (param_2 = (undefined4 *)*param_2; param_2 != puVar2; param_2 = param_2 + 2) {
      iVar3 = param_2[1];
      puVar5 = (undefined4 *)0x0;
      piVar7 = (int *)0x0;
      if (iVar3 != 0) {
        piVar7 = (int *)(iVar3 + 4);
        iVar3 = *(int *)(iVar3 + 4);
        while (iVar3 != 0) {
          LOCK();
          iVar6 = *piVar7;
          if (iVar3 == iVar6) {
            *piVar7 = iVar3 + 1;
            iVar6 = iVar3;
          }
          UNLOCK();
          if (iVar6 == iVar3) {
            puVar5 = (undefined4 *)*param_2;
            piVar7 = (int *)param_2[1];
            goto LAB_0090237c;
          }
          iVar3 = *piVar7;
        }
        puVar5 = (undefined4 *)0x0;
        piVar7 = (int *)0x0;
      }
LAB_0090237c:
      uStack_8 = 0;
      if ((puVar5 != (undefined4 *)0x0) && ((undefined4 *)puVar5[0xd] == puVar4)) {
        puVar5 = (undefined4 *)FUN_008ec650(param_3);
        if (piVar7 == (int *)0x0) {
          ExceptionList = pvStack_10;
          return puVar5;
        }
        LOCK();
        piVar1 = piVar7 + 1;
        iVar3 = *piVar1;
        puVar5 = (undefined4 *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 != 0) {
          ExceptionList = pvStack_10;
          return puVar5;
        }
        puVar5 = (undefined4 *)(**(code **)*piVar7)();
        LOCK();
        piVar1 = piVar7 + 2;
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 != 1) {
          ExceptionList = pvStack_10;
          return puVar5;
        }
        puVar5 = (undefined4 *)(**(code **)(*piVar7 + 4))();
        ExceptionList = pvStack_10;
        return puVar5;
      }
      uStack_8 = 0xffffffff;
      if (piVar7 != (int *)0x0) {
        LOCK();
        piVar1 = piVar7 + 1;
        iVar3 = *piVar1;
        puVar5 = (undefined4 *)*piVar1;
        *piVar1 = iVar3 + -1;
        UNLOCK();
        if (iVar3 + -1 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          piVar1 = piVar7 + 2;
          iVar3 = *piVar1;
          puVar5 = (undefined4 *)*piVar1;
          *piVar1 = iVar3 + -1;
          UNLOCK();
          if (iVar3 + -1 == 0) {
            puVar5 = (undefined4 *)(**(code **)(*piVar7 + 4))();
          }
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar5;
}



/* FUNCTION 15883 ; VA 0x00902420 ; FUN_00902420 */

void __fastcall FUN_00902420(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  *(undefined4 *)(param_1 + 0x260) = 0;
  piVar2 = *(int **)(param_1 + 0x264);
  *(undefined4 *)(param_1 + 0x264) = 0;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar3 = piVar2[1] + -1;
    piVar2[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar2)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar2 + 4))();
      }
    }
  }
  FUN_01679490();
  return;
}



/* FUNCTION 15884 ; VA 0x009024a0 ; FUN_009024a0 */

undefined FUN_009024a0(int param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  uint uVar1;
  undefined **ppuVar2;
  int iVar3;
  undefined4 ****ppppuVar4;
  undefined uVar5;
  int iVar6;
  int iVar7;
  undefined *puStack_58;
  undefined4 ***pppuStack_54;
  undefined4 ***pppuStack_50;
  int iStack_4c;
  int iStack_48;
  undefined4 ***pppuStack_44;
  undefined *puStack_40;
  undefined4 ***pppuStack_3c;
  undefined4 ***pppuStack_2c;
  int iStack_28;
  undefined4 uStack_24;
  undefined4 ***apppuStack_20 [2];
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c4a10;
  pvStack_10 = ExceptionList;
  if (param_4 == 0) {
    return 0;
  }
  pppuStack_2c = (undefined4 ****)0x0;
  iStack_28 = 0;
  uStack_24 = 0;
  pppuStack_3c = (undefined4 ***)0x1;
  pppuStack_44 = apppuStack_20;
  iStack_8 = 0;
  puStack_40 = &DAT_018d1b9c;
  apppuStack_20[0] = (undefined4 ****)0x0;
  uStack_18 = 1;
  iStack_48 = 0x902511;
  ExceptionList = &pvStack_10;
  FUN_0170cc70();
  iStack_48 = param_4;
  pppuStack_50 = (undefined4 ***)((int)apppuStack_20 + uStack_18);
  pppuStack_54 = apppuStack_20;
  iStack_4c = (int)pppuStack_50 - (int)pppuStack_54;
  puStack_58 = (undefined *)0x90252b;
  FUN_0063e660();
  iStack_8._0_1_ = 1;
  iStack_4c = 1;
  ppuVar2 = &puStack_58;
  pppuStack_50 = (undefined4 ***)uStack_18;
  puStack_58 = (undefined *)0x0;
  if (uStack_18 < 9) {
    ppppuVar4 = apppuStack_20;
  }
  else {
    ppuVar2 = (undefined **)FUN_01674e20(uStack_18);
    ppppuVar4 = (undefined4 ****)apppuStack_20[0];
    puStack_58 = (undefined *)ppuVar2;
  }
  FUN_0170c6f0(ppuVar2,ppppuVar4,pppuStack_50);
  FUN_0063fec0(&iStack_48);
  pppuStack_50 = &pppuStack_2c;
  iStack_4c = param_2;
  pppuStack_54 = (undefined4 ***)0x902584;
  FUN_0064f4f0();
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  if ((8 < uStack_18) && ((undefined4 ****)apppuStack_20[0] != (undefined4 ****)0x0)) {
    pppuStack_3c = apppuStack_20[0];
    puStack_40 = (undefined *)0x90259e;
    FUN_01674ea0();
  }
  uVar1 = (iStack_28 - (int)pppuStack_2c) / 0x18;
  if ((1 < uVar1) && (iVar6 = 1, 1 < (int)uVar1)) {
    iVar7 = 0x18;
    do {
      iStack_14 = *(int *)(param_4 + 0x44c);
      pppuStack_44 = (undefined4 ***)(iVar7 + (int)pppuStack_2c);
      if (0xf < *(uint *)(iVar7 + 0x14 + (int)pppuStack_2c)) {
        pppuStack_44 = (undefined4 ***)*pppuStack_44;
      }
      pppuStack_3c = (undefined4 ***)0xa;
      puStack_40 = (undefined *)0x0;
      iStack_48 = 0x9025f2;
      iVar3 = FUN_0171d785();
      if (iStack_14 == iVar3) {
        pppuStack_3c = (undefined4 ***)0x0;
        puStack_40 = (undefined *)0x3f;
        pppuStack_44 = pppuStack_2c;
        iStack_48 = param_1;
        iStack_4c = 0x902647;
        FUN_016780e0();
        uVar5 = 1;
        goto LAB_0090261d;
      }
      iVar6 = iVar6 + 1;
      iVar7 = iVar7 + 0x18;
    } while (iVar6 < (iStack_28 - (int)pppuStack_2c) / 0x18);
  }
  uVar5 = 0;
LAB_0090261d:
  pppuStack_3c = (undefined4 ***)0x902625;
  FUN_00577a40();
  ExceptionList = pvStack_10;
  return uVar5;
}



/* FUNCTION 15885 ; VA 0x00902650 ; FUN_00902650 */

float10 __thiscall FUN_00902650(int param_1,undefined4 param_2,float param_3,double param_4)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  float10 fVar5;
  float fVar6;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c4a28;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_01675290();
  uStack_8 = 0;
  if (*(char *)(param_1 + 0x1dd) != '\0') {
    iVar2 = FUN_008bc5d0();
    if ((iVar2 != 0) || (DAT_01d633d0 == '\0')) {
      if (DAT_01d67c90 == '\0') {
        fVar5 = (float10)FUN_00bb5be0();
        fVar6 = (float)(fVar5 * (float10)iVar2);
      }
      else {
        fVar6 = (float)iVar2 * *(float *)(*(int *)(*(int *)(param_1 + 0x1b8) + 0x1b4) + 0x610);
      }
      piVar3 = (int *)FUN_00bbddc0();
      cVar1 = FUN_0090daf0();
      if (cVar1 == '\0') {
        FUN_008aff70();
        param_3 = 0.0;
      }
      else {
        FUN_00998c80((double)fVar6);
        if (DAT_01d67ca8 == '\0') {
          FUN_008aff70();
        }
        if (*piVar3 == 3) {
          uVar4 = FUN_0097bfc0();
        }
        else {
          uVar4 = 0;
        }
        if (DAT_01ee04ad != '\0') {
          FUN_016774d0(DAT_01ee04ad,
                       "DataModel::PhysicsStep dt: %f, dtCyclicExecutive: %f, dutyDt: %f",
                       (float)(double)CONCAT44(param_3,param_2),fVar6,(float)param_4,0);
        }
        FUN_00cc2a50(uVar4,*(undefined4 *)(param_1 + 0x1b8),(double)fVar6,CONCAT44(param_3,param_2),
                     param_4);
        fVar5 = (float10)FUN_008b7430();
        param_3 = (float)fVar5;
        if (DAT_01ee04ae != '\0') {
          FUN_016774d0(DAT_01ee04ae,"DataModel::physicsStepped: %4.7f",param_3,0,0,0);
          *(int *)(param_1 + 0x238) = *(int *)(param_1 + 0x238) + 1;
          goto LAB_00902878;
        }
      }
      *(int *)(param_1 + 0x238) = *(int *)(param_1 + 0x238) + 1;
      goto LAB_00902878;
    }
  }
  param_3 = 0.0;
LAB_00902878:
  uStack_8 = 3;
  FUN_01675290();
  ExceptionList = pvStack_10;
  return (float10)param_3;
}



/* FUNCTION 15886 ; VA 0x009028a0 ; FUN_009028a0 */

/* WARNING: Removing unreachable block (ram,0x009029af) */
/* WARNING: Removing unreachable block (ram,0x009029b2) */
/* WARNING: Removing unreachable block (ram,0x009029f4) */
/* WARNING: Removing unreachable block (ram,0x009029bb) */
/* WARNING: Removing unreachable block (ram,0x009029ff) */
/* WARNING: Removing unreachable block (ram,0x00902a07) */
/* WARNING: Removing unreachable block (ram,0x0090298a) */
/* WARNING: Removing unreachable block (ram,0x00902995) */
/* WARNING: Removing unreachable block (ram,0x00902a26) */

undefined4 * __thiscall FUN_009028a0(int *param_1,undefined4 *param_2)

{
  uint *puVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c4a71;
  pvStack_10 = ExceptionList;
  puVar1 = (uint *)(param_1 + 5);
  ExceptionList = &pvStack_10;
  do {
    LOCK();
    uVar2 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
  } while ((uVar2 & 1) != 0);
  puVar3 = (undefined4 *)*param_1;
  uStack_8 = 1;
  if (puVar3 == (undefined4 *)0x0) {
    uVar5 = 0;
    uVar4 = 0;
  }
  else {
    uVar5 = *puVar3;
    uVar4 = *puVar3;
  }
  FUN_008dde00(uVar4,param_1[3],uVar5,param_1[4] + param_1[3],param_2);
  FUN_008ee150();
  param_1[6] = 0;
  param_1[7] = 0;
  *puVar1 = 0;
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  uStack_8 = 2;
  FUN_008ee280();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15887 ; VA 0x00902a30 ; FUN_00902a30 */

undefined4 __thiscall FUN_00902a30(int *param_1,undefined4 *param_2)

{
  uint *puVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  puVar1 = (uint *)(param_1 + 5);
  do {
    LOCK();
    uVar6 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
  } while ((uVar6 & 1) != 0);
  if (param_1[4] == 0) {
    uVar3 = 0;
  }
  else {
    if ((int *)*param_1 == (int *)0x0) {
      iVar4 = 0;
    }
    else {
      iVar4 = *(int *)*param_1;
    }
    uVar6 = param_1[3] & 1;
    iVar4 = *(int *)(*(int *)(iVar4 + 4) + ((uint)param_1[3] >> 1 & *(int *)(iVar4 + 8) - 1U) * 4);
    iVar5 = *(int *)(iVar4 + 4 + uVar6 * 8);
    if (iVar5 != 0) {
      LOCK();
      *(int *)(iVar5 + 4) = *(int *)(iVar5 + 4) + 1;
      UNLOCK();
      iVar5 = *(int *)(iVar4 + 4 + uVar6 * 8);
    }
    *param_2 = *(undefined4 *)(iVar4 + uVar6 * 8);
    piVar2 = (int *)param_2[1];
    param_2[1] = iVar5;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = *(int **)(*(int *)(param_1[1] + ((uint)param_1[3] >> 1 & param_1[2] - 1U) * 4) + 4 +
                      (param_1[3] & 1U) * 8);
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    piVar2 = param_1 + 4;
    *piVar2 = *piVar2 + -1;
    if (*piVar2 == 0) {
      param_1[3] = 0;
      uVar3 = 1;
    }
    else {
      param_1[3] = param_1[3] + 1;
      uVar3 = 1;
    }
  }
  *puVar1 = 0;
  return uVar3;
}



/* FUNCTION 15888 ; VA 0x00902b30 ; FUN_00902b30 */

void __thiscall FUN_00902b30(int param_1,undefined4 *param_2,int *param_3)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  bool bVar4;
  undefined auStack_5b0 [16];
  undefined4 uStack_5a0;
  undefined4 uStack_59c;
  undefined auStack_598 [16];
  undefined4 uStack_588;
  undefined4 uStack_584;
  undefined auStack_580 [16];
  undefined4 uStack_570;
  undefined4 uStack_56c;
  undefined auStack_568 [16];
  undefined4 uStack_558;
  undefined4 uStack_554;
  undefined auStack_550 [16];
  undefined4 uStack_540;
  undefined4 uStack_53c;
  undefined auStack_538 [16];
  undefined4 uStack_528;
  undefined4 uStack_524;
  undefined auStack_520 [16];
  undefined4 uStack_510;
  undefined4 uStack_50c;
  undefined auStack_508 [16];
  undefined4 uStack_4f8;
  undefined4 uStack_4f4;
  undefined auStack_4f0 [16];
  undefined4 uStack_4e0;
  undefined4 uStack_4dc;
  undefined auStack_4d8 [16];
  undefined4 uStack_4c8;
  undefined4 uStack_4c4;
  undefined auStack_4c0 [16];
  undefined4 uStack_4b0;
  undefined4 uStack_4ac;
  undefined auStack_4a8 [16];
  undefined4 uStack_498;
  undefined4 uStack_494;
  undefined auStack_490 [16];
  undefined4 uStack_480;
  undefined4 uStack_47c;
  undefined auStack_478 [16];
  undefined4 uStack_468;
  undefined4 uStack_464;
  undefined auStack_460 [16];
  undefined4 uStack_450;
  undefined4 uStack_44c;
  undefined auStack_448 [16];
  undefined4 uStack_438;
  undefined4 uStack_434;
  undefined auStack_430 [16];
  undefined4 uStack_420;
  undefined4 uStack_41c;
  undefined auStack_418 [16];
  undefined4 uStack_408;
  undefined4 uStack_404;
  undefined auStack_400 [16];
  undefined4 uStack_3f0;
  undefined4 uStack_3ec;
  undefined auStack_3e8 [16];
  undefined4 uStack_3d8;
  undefined4 uStack_3d4;
  undefined auStack_3d0 [16];
  undefined4 uStack_3c0;
  undefined4 uStack_3bc;
  undefined auStack_3b8 [16];
  undefined4 uStack_3a8;
  undefined4 uStack_3a4;
  undefined auStack_3a0 [16];
  undefined4 uStack_390;
  undefined4 uStack_38c;
  undefined auStack_388 [16];
  undefined4 uStack_378;
  undefined4 uStack_374;
  undefined auStack_370 [16];
  undefined4 uStack_360;
  undefined4 uStack_35c;
  undefined auStack_358 [16];
  undefined4 uStack_348;
  undefined4 uStack_344;
  undefined auStack_340 [16];
  undefined4 uStack_330;
  undefined4 uStack_32c;
  undefined auStack_328 [16];
  undefined4 uStack_318;
  undefined4 uStack_314;
  undefined auStack_310 [16];
  undefined4 uStack_300;
  undefined4 uStack_2fc;
  undefined auStack_2f8 [16];
  undefined4 uStack_2e8;
  undefined4 uStack_2e4;
  undefined auStack_2e0 [16];
  undefined4 uStack_2d0;
  undefined4 uStack_2cc;
  undefined auStack_2c8 [16];
  undefined4 uStack_2b8;
  undefined4 uStack_2b4;
  undefined auStack_2b0 [16];
  undefined4 uStack_2a0;
  undefined4 uStack_29c;
  undefined auStack_298 [16];
  undefined4 uStack_288;
  undefined4 uStack_284;
  undefined auStack_280 [16];
  undefined4 uStack_270;
  undefined4 uStack_26c;
  undefined auStack_268 [16];
  int iStack_258;
  undefined4 uStack_254;
  undefined auStack_250 [16];
  undefined4 uStack_240;
  undefined4 uStack_23c;
  undefined auStack_238 [16];
  undefined4 uStack_228;
  undefined4 uStack_224;
  undefined auStack_220 [16];
  undefined4 uStack_210;
  undefined4 uStack_20c;
  undefined auStack_208 [16];
  undefined4 uStack_1f8;
  undefined4 uStack_1f4;
  undefined auStack_1f0 [16];
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  undefined auStack_1d8 [16];
  undefined4 uStack_1c8;
  undefined4 uStack_1c4;
  undefined auStack_1c0 [16];
  undefined4 uStack_1b0;
  undefined4 uStack_1ac;
  undefined auStack_1a8 [16];
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined auStack_190 [16];
  undefined4 uStack_180;
  undefined4 uStack_17c;
  undefined auStack_178 [16];
  undefined4 uStack_168;
  undefined4 uStack_164;
  undefined auStack_160 [16];
  undefined4 uStack_150;
  undefined4 uStack_14c;
  undefined auStack_148 [16];
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined auStack_130 [16];
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined auStack_118 [16];
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined auStack_100 [16];
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined auStack_e8 [16];
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined auStack_d0 [16];
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined auStack_b8 [16];
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined auStack_a0 [16];
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined auStack_88 [16];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined auStack_70 [16];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined auStack_58 [16];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c4d08;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((((*(char *)(param_1 + 0x24b) != '\0') &&
       (iVar2 = *param_3, ExceptionList = &pvStack_10, *(int *)(iVar2 + 0x54) == 8)) &&
      (ExceptionList = &pvStack_10, *(int *)(iVar2 + 0x5c) != 2)) &&
     (((ExceptionList = &pvStack_10, *(int *)(iVar2 + 0x5c) != 4 &&
       (ExceptionList = &pvStack_10, *(int *)(iVar2 + 0xa8) == 0x31)) &&
      ((ExceptionList = &pvStack_10, cVar1 = FUN_00d81ac0(), cVar1 != '\0' &&
       (*(int *)(iVar2 + 0xa8) == 0x31)))))) {
    FUN_00f68cc0();
  }
  cVar1 = FUN_00554b40();
  if ((cVar1 == '\0') || (*(int *)(*param_3 + 0x54) != 0x14)) {
LAB_00902bcc:
    if ((*(int *)(*param_3 + 0x54) == 8) && (*(int *)(*param_3 + 0x5c) == 2)) {
      iVar2 = FUN_0090c170();
      *(undefined *)(iVar2 + 0xbe) = 0;
    }
    if (((*(int *)(*param_3 + 0x54) == 8) && (iVar2 = *(int *)(*param_3 + 0x5c), iVar2 != 2)) &&
       (iVar2 != 4)) {
      cVar1 = FUN_00554b40();
      if (cVar1 == '\0') {
        FUN_00636b00();
        cVar1 = FUN_00b9b890(param_3);
        if (cVar1 != '\0') goto LAB_00903ce8;
      }
      iVar2 = (**(code **)(*(int *)(*(int *)(param_1 + 0x1b8) + 0x144) + 8))();
      bVar4 = true;
      if (iVar2 != 0) {
        bVar4 = *(int *)(iVar2 + 0x1ac) != 5;
      }
      iVar2 = (**(code **)(*(int *)(*(int *)(param_1 + 0x1b8) + 0x144) + 8))();
      if ((iVar2 != 0) && (cVar1 = FUN_00d229b0(), cVar1 != '\0')) {
        bVar4 = false;
      }
      iVar2 = *(int *)(*param_3 + 0xa8);
      if (iVar2 < 0x6a) {
        if (iVar2 == 0x69) {
          if (bVar4) {
            if (DAT_01d6357c == '\0') {
              uStack_120 = 0;
              uStack_11c = 0xf;
              auStack_130[0] = 0;
              FUN_005542c0(&DAT_0192b748,2);
              uStack_8 = 1;
              uStack_108 = 0;
              uStack_104 = 0xf;
              auStack_118[0] = 0;
              FUN_005542c0(&DAT_0192b74c,4);
              uStack_8._0_1_ = 2;
              uStack_f0 = 0;
              uStack_ec = 0xf;
              auStack_100[0] = 0;
              FUN_005542c0("Camera",6);
              uStack_8 = CONCAT31(uStack_8._1_3_,3);
              piVar3 = (int *)FUN_009954d0(auStack_100,auStack_118,auStack_130);
              FUN_005507b0();
              FUN_005507b0();
            }
            else {
              uStack_d8 = 0;
              uStack_d4 = 0xf;
              auStack_e8[0] = 0;
              FUN_005542c0("CameraZoomIn",0xc);
              uStack_8 = 0;
              piVar3 = (int *)FUN_009955f0(auStack_e8);
            }
            goto LAB_00903cb6;
          }
        }
        else if (iVar2 == 8) {
          if (((param_1 != -0xc) && (iVar2 = FUN_0055e560(), iVar2 != 0)) &&
             (*(int *)(iVar2 + 0xf4) != 0)) {
            FUN_00c481e0(*(int *)(iVar2 + 0xf4));
          }
        }
        else if (iVar2 == 0x2c) {
          if ((bVar4) &&
             (iVar2 = (**(code **)(*(int *)(*(int *)(param_1 + 0x1b8) + 0x144) + 8))(),
             *(int *)(iVar2 + 0x1ac) != 6)) {
            if (DAT_01d6357c == '\0') {
              uStack_c0 = 0;
              uStack_bc = 0xf;
              auStack_d0[0] = 0;
              FUN_005542c0(&DAT_018fab04,4);
              uStack_8 = 9;
              uStack_a8 = 0;
              uStack_a4 = 0xf;
              auStack_b8[0] = 0;
              FUN_005542c0(&DAT_0192b780,3);
              uStack_8._0_1_ = 10;
              uStack_90 = 0;
              uStack_8c = 0xf;
              auStack_a0[0] = 0;
              FUN_005542c0("Camera",6);
              uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
              piVar3 = (int *)FUN_009954d0(auStack_a0,auStack_b8,auStack_d0);
              FUN_005507b0();
              FUN_005507b0();
            }
            else {
              uStack_78 = 0;
              uStack_74 = 0xf;
              auStack_88[0] = 0;
              FUN_005542c0("CameraPanLeft",0xd);
              uStack_8 = 8;
              piVar3 = (int *)FUN_009955f0(auStack_88);
            }
            goto LAB_00903cb6;
          }
        }
        else if (((iVar2 == 0x2e) && (bVar4)) &&
                (iVar2 = (**(code **)(*(int *)(*(int *)(param_1 + 0x1b8) + 0x144) + 8))(),
                *(int *)(iVar2 + 0x1ac) != 6)) {
          if (DAT_01d6357c == '\0') {
            uStack_60 = 0;
            uStack_5c = 0xf;
            auStack_70[0] = 0;
            FUN_005542c0(&DAT_018fab10,5);
            uStack_8 = 0xd;
            uStack_48 = 0;
            uStack_44 = 0xf;
            auStack_58[0] = 0;
            FUN_005542c0(&DAT_0192b780,3);
            uStack_8._0_1_ = 0xe;
            uStack_30 = 0;
            uStack_2c = 0xf;
            auStack_40[0] = 0;
            FUN_005542c0("Camera",6);
            uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
            piVar3 = (int *)FUN_009954d0(auStack_40,auStack_58,auStack_70);
            FUN_005507b0();
            FUN_005507b0();
          }
          else {
            uStack_18 = 0;
            uStack_14 = 0xf;
            auStack_28[0] = 0;
            FUN_005542c0("CameraPanRight",0xe);
            uStack_8 = 0xc;
            piVar3 = (int *)FUN_009955f0(auStack_28);
          }
          goto LAB_00903cb6;
        }
      }
      else {
        switch(iVar2) {
        case 0x6f:
          if (bVar4) {
            if (DAT_01d6357c == '\0') {
              uStack_180 = 0;
              uStack_17c = 0xf;
              auStack_190[0] = 0;
              FUN_005542c0(&DAT_0192b76c,3);
              uStack_8 = 5;
              uStack_168 = 0;
              uStack_164 = 0xf;
              auStack_178[0] = 0;
              FUN_005542c0(&DAT_0192b74c,4);
              uStack_8._0_1_ = 6;
              uStack_150 = 0;
              uStack_14c = 0xf;
              auStack_160[0] = 0;
              FUN_005542c0("Camera",6);
              uStack_8 = CONCAT31(uStack_8._1_3_,7);
              piVar3 = (int *)FUN_009954d0(auStack_160,auStack_178,auStack_190);
              FUN_005507b0();
              FUN_005507b0();
            }
            else {
              uStack_138 = 0;
              uStack_134 = 0xf;
              auStack_148[0] = 0;
              FUN_005542c0("CameraZoomOut",0xd);
              uStack_8 = 4;
              piVar3 = (int *)FUN_009955f0(auStack_148);
            }
LAB_00903cb6:
            uStack_8 = 0xffffffff;
            FUN_005507b0();
            if (piVar3 != (int *)0x0) goto LAB_00903cca;
          }
          break;
        case 0x118:
          if (bVar4) {
            if (DAT_01d6357c == '\0') {
              uStack_1e0 = 0;
              uStack_1dc = 0xf;
              auStack_1f0[0] = 0;
              FUN_005542c0(&DAT_0192b7a4,2);
              uStack_8 = 0x11;
              uStack_1c8 = 0;
              uStack_1c4 = 0xf;
              auStack_1d8[0] = 0;
              FUN_005542c0(&DAT_0192b7a8,4);
              uStack_8._0_1_ = 0x12;
              uStack_1b0 = 0;
              uStack_1ac = 0xf;
              auStack_1c0[0] = 0;
              FUN_005542c0("Camera",6);
              uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
              piVar3 = (int *)FUN_009954d0(auStack_1c0,auStack_1d8,auStack_1f0);
              FUN_005507b0();
              FUN_005507b0();
            }
            else {
              uStack_198 = 0;
              uStack_194 = 0xf;
              auStack_1a8[0] = 0;
              FUN_005542c0("CameraTiltUp",0xc);
              uStack_8 = 0x10;
              piVar3 = (int *)FUN_009955f0(auStack_1a8);
            }
            goto LAB_00903cb6;
          }
          break;
        case 0x119:
          if (bVar4) {
            if (DAT_01d6357c == '\0') {
              uStack_240 = 0;
              uStack_23c = 0xf;
              auStack_250[0] = 0;
              FUN_005542c0(&DAT_0192b7c0,4);
              uStack_8 = 0x15;
              uStack_228 = 0;
              uStack_224 = 0xf;
              auStack_238[0] = 0;
              FUN_005542c0(&DAT_0192b7a8,4);
              uStack_8._0_1_ = 0x16;
              uStack_210 = 0;
              uStack_20c = 0xf;
              auStack_220[0] = 0;
              FUN_005542c0("Camera",6);
              uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
              piVar3 = (int *)FUN_009954d0(auStack_220,auStack_238,auStack_250);
              FUN_005507b0();
              FUN_005507b0();
            }
            else {
              uStack_1f8 = 0;
              uStack_1f4 = 0xf;
              auStack_208[0] = 0;
              FUN_005542c0("CameraTiltDown",0xe);
              uStack_8 = 0x14;
              piVar3 = (int *)FUN_009955f0(auStack_208);
            }
            goto LAB_00903cb6;
          }
          break;
        case 0x11a:
          iVar2 = FUN_0090c170();
          if ((*(char *)(iVar2 + 0xc4) == '\0') && (DAT_01d6ddc0 == '\0')) {
            iVar2 = FUN_00d816c0();
            if (iVar2 == 0) {
              if (DAT_01d6357c == '\0') {
                uStack_2a0 = 0;
                uStack_29c = 0xf;
                auStack_2b0[0] = 0;
                FUN_005542c0(&DAT_0192b7d0,1);
                uStack_8 = 0x19;
                uStack_288 = 0;
                uStack_284 = 0xf;
                auStack_298[0] = 0;
                FUN_005542c0(&DAT_0192b7d4,2);
                uStack_8._0_1_ = 0x1a;
                uStack_270 = 0;
                uStack_26c = 0xf;
                auStack_280[0] = 0;
                FUN_005542c0(&DAT_0192b7d8,1);
                uStack_8 = CONCAT31(uStack_8._1_3_,0x1b);
                piVar3 = (int *)FUN_009954d0(auStack_280,auStack_298,auStack_2b0);
                FUN_005507b0();
                FUN_005507b0();
              }
              else {
                uStack_254 = 0xf;
                auStack_268[0] = 0;
                iStack_258 = iVar2;
                FUN_005542c0(&DAT_0192b7c8,4);
                uStack_8 = 0x18;
                piVar3 = (int *)FUN_009955f0(auStack_268);
              }
            }
            else if (DAT_01d6357c == '\0') {
              uStack_300 = 0;
              uStack_2fc = 0xf;
              auStack_310[0] = 0;
              FUN_005542c0(&DAT_0192b7dc,2);
              uStack_8 = 0x1d;
              uStack_2e8 = 0;
              uStack_2e4 = 0xf;
              auStack_2f8[0] = 0;
              FUN_005542c0(&DAT_0192b7e0,2);
              uStack_8._0_1_ = 0x1e;
              uStack_2d0 = 0;
              uStack_2cc = 0xf;
              auStack_2e0[0] = 0;
              FUN_005542c0(&DAT_018bc900,1);
              uStack_8 = CONCAT31(uStack_8._1_3_,0x1f);
              piVar3 = (int *)FUN_009954d0(auStack_2e0,auStack_2f8,auStack_310);
              FUN_005507b0();
              FUN_005507b0();
            }
            else {
              uStack_2b8 = 0;
              uStack_2b4 = 0xf;
              auStack_2c8[0] = 0;
              FUN_005542c0("Stats",5);
              uStack_8 = 0x1c;
              piVar3 = (int *)FUN_009955f0(auStack_2c8);
            }
            goto LAB_00903cb6;
          }
          break;
        case 0x11b:
          iVar2 = FUN_0090c170();
          if (((*(char *)(iVar2 + 0xc4) == '\0') &&
              (cVar1 = FUN_008ff140(*(undefined4 *)(*param_3 + 0xa8)), cVar1 != '\0')) &&
             (DAT_01d6ddc0 == '\0')) {
            if (DAT_01d6357c == '\0') {
              uStack_360 = 0;
              uStack_35c = 0xf;
              auStack_370[0] = 0;
              FUN_005542c0("Stats",5);
              uStack_8 = 0x21;
              uStack_348 = 0;
              uStack_344 = 0xf;
              auStack_358[0] = 0;
              FUN_005542c0("Render",6);
              uStack_8._0_1_ = 0x22;
              uStack_330 = 0;
              uStack_32c = 0xf;
              auStack_340[0] = 0;
              FUN_005542c0(&DAT_018bc9b8,0);
              uStack_8 = CONCAT31(uStack_8._1_3_,0x23);
              piVar3 = (int *)FUN_009954d0(auStack_340,auStack_358,auStack_370);
              FUN_005507b0();
              FUN_005507b0();
            }
            else {
              uStack_318 = 0;
              uStack_314 = 0xf;
              auStack_328[0] = 0;
              FUN_005542c0("RenderStats",0xb);
              uStack_8 = 0x20;
              piVar3 = (int *)FUN_009955f0(auStack_328);
            }
            goto LAB_00903cb6;
          }
          break;
        case 0x11c:
          iVar2 = FUN_0090c170();
          if (((*(char *)(iVar2 + 0xc4) == '\0') &&
              (cVar1 = FUN_008ff140(*(undefined4 *)(*param_3 + 0xa8)), cVar1 != '\0')) &&
             (DAT_01d6ddc0 == '\0')) {
            cVar1 = FUN_008ff110(*(undefined4 *)(*param_3 + 0xa8));
            if (cVar1 == '\0') {
              if (DAT_01d6357c == '\0') {
                uStack_3c0 = 0;
                uStack_3bc = 0xf;
                auStack_3d0[0] = 0;
                FUN_005542c0("Stats",5);
                uStack_8 = 0x25;
                uStack_3a8 = 0;
                uStack_3a4 = 0xf;
                auStack_3b8[0] = 0;
                FUN_005542c0(&DAT_018bc9b8,0);
                uStack_8._0_1_ = 0x26;
                uStack_390 = 0;
                uStack_38c = 0xf;
                auStack_3a0[0] = 0;
                FUN_005542c0(&DAT_018c5904,7);
                uStack_8 = CONCAT31(uStack_8._1_3_,0x27);
                piVar3 = (int *)FUN_009954d0(auStack_3a0,auStack_3b8,auStack_3d0);
                FUN_005507b0();
                FUN_005507b0();
              }
              else {
                uStack_378 = 0;
                uStack_374 = 0xf;
                auStack_388[0] = 0;
                FUN_005542c0("NetworkStats",0xc);
                uStack_8 = 0x24;
                piVar3 = (int *)FUN_009955f0(auStack_388);
              }
              goto LAB_00903cb6;
            }
            FUN_00f690c0();
          }
          break;
        case 0x11d:
          iVar2 = FUN_0090c170();
          if (((*(char *)(iVar2 + 0xc4) == '\0') &&
              (cVar1 = FUN_008ff140(*(undefined4 *)(*param_3 + 0xa8)), cVar1 != '\0')) &&
             (DAT_01d6ddc0 == '\0')) {
            if (DAT_01d6357c == '\0') {
              uStack_420 = 0;
              uStack_41c = 0xf;
              auStack_430[0] = 0;
              FUN_005542c0(&DAT_018bc9b8,0);
              uStack_8 = 0x29;
              uStack_408 = 0;
              uStack_404 = 0xf;
              auStack_418[0] = 0;
              FUN_005542c0("Stats",5);
              uStack_8._0_1_ = 0x2a;
              uStack_3f0 = 0;
              uStack_3ec = 0xf;
              auStack_400[0] = 0;
              FUN_005542c0(&DAT_018cb3fc,7);
              uStack_8 = CONCAT31(uStack_8._1_3_,0x2b);
              piVar3 = (int *)FUN_009954d0(auStack_400,auStack_418,auStack_430);
              FUN_005507b0();
              FUN_005507b0();
            }
            else {
              uStack_3d8 = 0;
              uStack_3d4 = 0xf;
              auStack_3e8[0] = 0;
              FUN_005542c0("PhysicsStats",0xc);
              uStack_8 = 0x28;
              piVar3 = (int *)FUN_009955f0(auStack_3e8);
            }
            goto LAB_00903cb6;
          }
          break;
        case 0x11e:
          if (((DAT_01d6ddc0 == '\0') && (iVar2 = FUN_0090c170(), *(char *)(iVar2 + 0xc4) == '\0'))
             && (cVar1 = FUN_008ff140(*(undefined4 *)(*param_3 + 0xa8)), cVar1 != '\0')) {
            if (DAT_01d6357c == '\0') {
              uStack_480 = 0;
              uStack_47c = 0xf;
              auStack_490[0] = 0;
              FUN_005542c0("Stats",5);
              uStack_8 = 0x2d;
              uStack_468 = 0;
              uStack_464 = 0xf;
              auStack_478[0] = 0;
              FUN_005542c0(&DAT_018bc9b8,0);
              uStack_8._0_1_ = 0x2e;
              uStack_450 = 0;
              uStack_44c = 0xf;
              auStack_460[0] = 0;
              FUN_005542c0("Summary",7);
              uStack_8 = CONCAT31(uStack_8._1_3_,0x2f);
              piVar3 = (int *)FUN_009954d0(auStack_460,auStack_478,auStack_490);
              FUN_005507b0();
              FUN_005507b0();
            }
            else {
              uStack_438 = 0;
              uStack_434 = 0xf;
              auStack_448[0] = 0;
              FUN_005542c0("SummaryStats",0xc);
              uStack_8 = 0x2c;
              piVar3 = (int *)FUN_009955f0(auStack_448);
            }
            goto LAB_00903cb6;
          }
          break;
        case 0x121:
          cVar1 = FUN_008ff110(iVar2);
          if (((cVar1 != '\0') && (iVar2 = *(int *)(*(int *)(param_1 + 0x1b8) + 0x1b4), iVar2 != 0))
             && (iVar2 = *(int *)(iVar2 + 0x6f0), iVar2 != 0)) {
            cVar1 = FUN_008ff140(*(undefined4 *)(*param_3 + 0xa8));
            (**(code **)(**(int **)(iVar2 + 0x2c) + 0x38))(cVar1 == '\0');
          }
          break;
        case 0x123:
          cVar1 = FUN_008ff140(iVar2);
          if (cVar1 == '\0') {
            FUN_005e6780(1);
          }
          else {
            FUN_005e6780(0);
          }
          break;
        case 0x124:
          if (DAT_01d6357c == '\0') {
            uStack_4e0 = 0;
            uStack_4dc = 0xf;
            auStack_4f0[0] = 0;
            FUN_005542c0("Screen",6);
            uStack_8 = 0x31;
            uStack_4c8 = 0;
            uStack_4c4 = 0xf;
            auStack_4d8[0] = 0;
            FUN_005542c0(&DAT_0192b844,4);
            uStack_8._0_1_ = 0x32;
            uStack_4b0 = 0;
            uStack_4ac = 0xf;
            auStack_4c0[0] = 0;
            FUN_005542c0("Toggle",6);
            uStack_8 = CONCAT31(uStack_8._1_3_,0x33);
            piVar3 = (int *)FUN_009954d0(auStack_4c0,auStack_4d8,auStack_4f0);
            FUN_005507b0();
            FUN_005507b0();
          }
          else {
            uStack_498 = 0;
            uStack_494 = 0xf;
            auStack_4a8[0] = 0;
            FUN_005542c0("ToggleFullScreen",0x10);
            uStack_8 = 0x30;
            piVar3 = (int *)FUN_009955f0(auStack_4a8);
          }
          uStack_8 = 0xffffffff;
          FUN_005507b0();
          if (piVar3 == (int *)0x0) {
            iVar2 = FUN_008e44d0(param_1 + 0xc);
            if (iVar2 != 0) {
              FUN_00b9e110();
            }
          }
          else {
LAB_00903cca:
            cVar1 = (**(code **)(*piVar3 + 4))();
            if (cVar1 != '\0') {
              FUN_008f4460(piVar3,param_1 + 4);
              goto LAB_00903ce8;
            }
          }
          break;
        case 0x125:
          if (DAT_01d6ddc0 == '\0') {
            if (DAT_01d6357c == '\0') {
              uStack_540 = 0;
              uStack_53c = 0xf;
              auStack_550[0] = 0;
              FUN_005542c0(&DAT_018bc9b8,0);
              uStack_8 = 0x35;
              uStack_528 = 0;
              uStack_524 = 0xf;
              auStack_538[0] = 0;
              FUN_005542c0("Toggle",6);
              uStack_8._0_1_ = 0x36;
              uStack_510 = 0;
              uStack_50c = 0xf;
              auStack_520[0] = 0;
              FUN_005542c0("Record",6);
              uStack_8 = CONCAT31(uStack_8._1_3_,0x37);
              piVar3 = (int *)FUN_009954d0(auStack_520,auStack_538,auStack_550);
              FUN_005507b0();
              FUN_005507b0();
            }
            else {
              uStack_4f8 = 0;
              uStack_4f4 = 0xf;
              auStack_508[0] = 0;
              FUN_005542c0("RecordToggle",0xc);
              uStack_8 = 0x34;
              piVar3 = (int *)FUN_009955f0(auStack_508);
            }
            uStack_8 = 0xffffffff;
            FUN_005507b0();
            if (piVar3 != (int *)0x0) goto LAB_00903cca;
            iVar2 = FUN_008e44d0(param_1 + 0xc);
            if (iVar2 != 0) {
              FUN_006eccd0();
            }
          }
          break;
        case 0x133:
        case 0x134:
          iVar2 = FUN_0090c170();
          *(undefined *)(iVar2 + 0xbe) = 1;
          break;
        case 0x13c:
        case 0x13d:
          if (DAT_01d6ddc0 == '\0') {
            if (DAT_01d6357c == '\0') {
              uStack_5a0 = 0;
              uStack_59c = 0xf;
              auStack_5b0[0] = 0;
              FUN_005542c0(&DAT_0192b870,4);
              uStack_8 = 0x39;
              uStack_588 = 0;
              uStack_584 = 0xf;
              auStack_598[0] = 0;
              FUN_005542c0("Screen",6);
              uStack_8._0_1_ = 0x3a;
              uStack_570 = 0;
              uStack_56c = 0xf;
              auStack_580[0] = 0;
              FUN_005542c0(&DAT_018bc9b8,0);
              uStack_8 = CONCAT31(uStack_8._1_3_,0x3b);
              piVar3 = (int *)FUN_009954d0(auStack_580,auStack_598,auStack_5b0);
              FUN_005507b0();
              FUN_005507b0();
            }
            else {
              uStack_558 = 0;
              uStack_554 = 0xf;
              auStack_568[0] = 0;
              FUN_005542c0("Screenshot",10);
              uStack_8 = 0x38;
              piVar3 = (int *)FUN_009955f0(auStack_568);
            }
            uStack_8 = 0xffffffff;
            FUN_005507b0();
            if (piVar3 != (int *)0x0) goto LAB_00903cca;
            iVar2 = FUN_008e44d0(param_1 + 0xc);
            if (iVar2 != 0) {
              FUN_006eccd0();
            }
          }
        }
      }
    }
    *param_2 = 0;
  }
  else {
    FUN_00636b00();
    cVar1 = FUN_00b9b890(param_3);
    if (cVar1 == '\0') goto LAB_00902bcc;
LAB_00903ce8:
    *param_2 = 1;
  }
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[4] = 0;
  param_2[3] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15889 ; VA 0x00904310 ; FUN_00904310 */

void __thiscall FUN_00904310(int param_1,undefined4 *param_2,int *param_3)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  undefined auStack_d0 [16];
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined auStack_b8 [16];
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined auStack_a0 [16];
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined auStack_88 [16];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined auStack_70 [16];
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined auStack_58 [16];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c4d6c;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = (**(code **)(*(int *)(*(int *)(param_1 + 0x1b8) + 0x144) + 8))();
  if ((((((iVar2 == 0) || (cVar1 = FUN_00d229b0(), cVar1 == '\0')) &&
        (*(int *)(*param_3 + 0x54) == 3)) &&
       (((iVar2 = (**(code **)(*(int *)(*(int *)(param_1 + 0x1b8) + 0x144) + 8))(), iVar2 == 0 ||
         (*(int *)(iVar2 + 0x1ac) != 5)) || (iVar2 = FUN_0097bfc0(param_1 + 0xc), iVar2 == 0)))) &&
      ((*(int *)(param_1 + 0x1b0) != 0 && (cVar1 = FUN_00b839e0(0x132), cVar1 == '\0')))) &&
     ((cVar1 = FUN_00b839e0(0x131), cVar1 == '\0' &&
      ((((cVar1 = FUN_00b839e0(0x130), cVar1 == '\0' && (cVar1 = FUN_00b839e0(0x12f), cVar1 == '\0')
         ) && (cVar1 = FUN_00b839e0(0x134), cVar1 == '\0')) &&
       ((cVar1 = FUN_00b839e0(0x133), cVar1 == '\0' &&
        (iVar2 = *param_3, *(int *)(iVar2 + 0x54) == 3)))))))) {
    if (*(float *)(iVar2 + 0x68) <= 0.0) {
      if (0.0 < *(float *)(iVar2 + 0x68) || *(float *)(iVar2 + 0x68) == 0.0) goto LAB_009046a7;
      if (DAT_01d6357c == '\0') {
        uStack_c0 = 0;
        uStack_bc = 0xf;
        auStack_d0[0] = 0;
        FUN_005542c0(&DAT_0192b76c,3);
        uStack_8 = 5;
        uStack_a8 = 0;
        uStack_a4 = 0xf;
        auStack_b8[0] = 0;
        FUN_005542c0(&DAT_0192b74c,4);
        uStack_8._0_1_ = 6;
        uStack_90 = 0;
        uStack_8c = 0xf;
        auStack_a0[0] = 0;
        FUN_005542c0("Camera",6);
        uStack_8 = CONCAT31(uStack_8._1_3_,7);
        piVar3 = (int *)FUN_009954d0(auStack_a0,auStack_b8,auStack_d0);
        FUN_005507b0();
        FUN_005507b0();
      }
      else {
        uStack_78 = 0;
        uStack_74 = 0xf;
        auStack_88[0] = 0;
        FUN_005542c0("CameraZoomOut",0xd);
        uStack_8 = 4;
        piVar3 = (int *)FUN_009955f0(auStack_88);
      }
    }
    else if (DAT_01d6357c == '\0') {
      uStack_60 = 0;
      uStack_5c = 0xf;
      auStack_70[0] = 0;
      FUN_005542c0(&DAT_0192b748,2);
      uStack_8 = 1;
      uStack_48 = 0;
      uStack_44 = 0xf;
      auStack_58[0] = 0;
      FUN_005542c0(&DAT_0192b74c,4);
      uStack_8._0_1_ = 2;
      uStack_30 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = 0;
      FUN_005542c0("Camera",6);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      piVar3 = (int *)FUN_009954d0(auStack_40,auStack_58,auStack_70);
      FUN_005507b0();
      FUN_005507b0();
    }
    else {
      uStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0("CameraZoomIn",0xc);
      uStack_8 = 0;
      piVar3 = (int *)FUN_009955f0(auStack_28);
    }
    uStack_8 = 0xffffffff;
    FUN_005507b0();
    if ((piVar3 != (int *)0x0) && (cVar1 = (**(code **)(*piVar3 + 4))(), cVar1 != '\0')) {
      FUN_008f4460(piVar3,param_1 + 4);
    }
  }
LAB_009046a7:
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[4] = 0;
  param_2[3] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15890 ; VA 0x009046e0 ; FUN_009046e0 */

undefined4 * __thiscall FUN_009046e0(int param_1,undefined4 *param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  undefined auStack_10 [12];
  
  iVar4 = *(int *)(param_1 + 0x1b8);
  if (iVar4 == 0) {
    *param_2 = 0;
    param_2[1] = 0;
    param_2[2] = 0;
    param_2[3] = 0;
    param_2[4] = 0;
    return param_2;
  }
  if ((((*(int *)(iVar4 + 0x214) == 0) && (iVar1 = *param_3, *(int *)(iVar1 + 0x54) == 8)) &&
      (*(int *)(iVar1 + 0x5c) != 2)) &&
     ((*(int *)(iVar1 + 0x5c) != 4 && (*(int *)(iVar1 + 0xa8) == 0x121)))) {
    uVar3 = FUN_00d816c0();
    if ((uVar3 & 0xcc0) != 0) {
      FUN_008b1790();
    }
  }
  iVar4 = *(int *)(iVar4 + 0x214);
  if (iVar4 != 0) {
    if (((*(char *)(iVar4 + 0x20) != '\0') && (*(uint *)(*param_3 + 0x54) < 5)) &&
       (*(uint *)(*param_3 + 0x54) == 3)) {
      iVar4 = FUN_00d81770(auStack_10);
      iVar4 = (int)*(float *)(iVar4 + 8);
      uVar3 = FUN_00d816c0();
      if ((uVar3 & 0xcc0) != 0) {
        iVar4 = iVar4 * 10;
      }
      uVar3 = FUN_00d816c0();
      if ((uVar3 & 3) != 0) {
        FUN_00ccce80(iVar4);
        FUN_0090cc40(param_2);
        return param_2;
      }
      FUN_00cccec0(iVar4);
      FUN_0090cc40(param_2);
      return param_2;
    }
    iVar1 = *param_3;
    if (((*(int *)(iVar1 + 0x54) == 8) && (iVar2 = *(int *)(iVar1 + 0x5c), iVar2 != 2)) &&
       (iVar2 != 4)) {
      if (((iVar2 != 2) && (iVar2 != 4)) && (*(int *)(iVar1 + 0xa8) == 0x121)) {
        uVar3 = FUN_00d816c0();
        if ((uVar3 & 0xcc0) != 0) {
          *(bool *)(iVar4 + 0x20) = *(char *)(iVar4 + 0x20) == '\0';
          FUN_0090cc40(param_2);
          return param_2;
        }
      }
      iVar4 = *param_3;
      if (((*(int *)(iVar4 + 0x54) == 8) && (*(int *)(iVar4 + 0x5c) != 2)) &&
         ((*(int *)(iVar4 + 0x5c) != 4 && (*(int *)(iVar4 + 0xa8) == 0x75)))) {
        uVar3 = FUN_00d816c0();
        if ((uVar3 & 0xcc0) != 0) {
          FUN_00ccd930();
          FUN_0090cc40(param_2);
          return param_2;
        }
      }
    }
  }
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  return param_2;
}



/* FUNCTION 15891 ; VA 0x009048b0 ; FUN_009048b0 */

bool __thiscall FUN_009048b0(int *param_1,int *param_2,undefined *param_3)

{
  double dVar1;
  int *piVar2;
  double dVar3;
  char cVar4;
  undefined uVar5;
  char cVar6;
  short sVar7;
  int *piVar8;
  undefined4 uVar9;
  int iVar10;
  uint uVar11;
  int iVar12;
  undefined4 *puVar13;
  uint uVar14;
  bool bVar15;
  double dVar16;
  uint auStack_94 [4];
  undefined4 uStack_84;
  uint uStack_80;
  undefined8 uStack_7c;
  undefined auStack_74 [4];
  int *piStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  int iStack_64;
  undefined4 uStack_60;
  int *piStack_5c;
  undefined auStack_58 [4];
  undefined auStack_54 [16];
  int *piStack_44;
  undefined4 *puStack_40;
  int iStack_3c;
  int iStack_38;
  int *piStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined8 uStack_1c;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c4db3;
  pvStack_10 = ExceptionList;
  uStack_7c = (double)(ulonglong)(uint)uStack_7c;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(*param_2 + 0xc0);
  uStack_14 = 0x10;
  uStack_8 = 0;
  puStack_40 = (undefined4 *)FUN_008fba50(auStack_94);
  uStack_8 = 0xffffffff;
  if (0xf < uStack_80) {
    uVar14 = uStack_80 + 1;
    uVar11 = auStack_94[0];
    if (0xfff < uVar14) {
      uVar11 = *(uint *)(auStack_94[0] - 4);
      uVar14 = uStack_80 + 0x24;
      if (0x1f < (auStack_94[0] - uVar11) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar11,uVar14);
  }
  uStack_84 = 0;
  uStack_80 = 0xf;
  auStack_94[0] = auStack_94[0] & 0xffffff00;
  *param_3 = 0;
  if (*(char *)((int)param_1 + 0x1dd) == '\0') {
    ExceptionList = pvStack_10;
    return false;
  }
  cVar6 = '\0';
  cVar4 = FUN_008ff170();
  if (cVar4 != '\0') {
    if (*(int *)(*param_2 + 0x54) == 4) {
      if (*(char *)(param_1 + 0x48) == '\0') {
        FUN_016827a0(&iStack_38);
        uStack_7c = (double)CONCAT44(piStack_34,iStack_38) - *(double *)(param_1 + 0x46);
        param_1[0x46] = iStack_38;
        param_1[0x47] = (int)piStack_34;
        uStack_1c = uStack_7c;
        sVar7 = FUN_017265ed(&uStack_7c);
        dVar3 = DAT_018c0d60;
        if (sVar7 < 1) {
          dVar1 = *(double *)(param_1 + 0x4a);
          dVar16 = uStack_1c;
          if (*(char *)(param_1 + 0x52) == '\0') {
            dVar16 = (DAT_018c0d60 - dVar1) * *(double *)(param_1 + 0x4e) + dVar1 * uStack_1c;
          }
          *(double *)(param_1 + 0x4c) = uStack_1c;
          *(double *)(param_1 + 0x4e) = dVar16;
          *(undefined *)(param_1 + 0x52) = 0;
          *(double *)(param_1 + 0x50) =
               (dVar3 - dVar1) * *(double *)(param_1 + 0x50) +
               dVar1 * (uStack_1c - dVar16) * (uStack_1c - dVar16);
        }
      }
      else {
        FUN_016827a0(&iStack_38);
        param_1[0x46] = iStack_38;
        param_1[0x47] = (int)piStack_34;
        *(undefined *)(param_1 + 0x48) = 0;
      }
    }
    if ((*(int *)(*param_2 + 0x54) == 1) && (*(int *)(*param_2 + 0x5c) == 2)) {
      if (DAT_01ee41ed != '\0') {
        FUN_016774b0(DAT_01ee41ed,"Cancelling Right mouse pan",0);
      }
      FUN_008b0040();
    }
    if (param_1 != (int *)0xfffffff4) {
      piVar8 = (int *)FUN_00636b00();
      if (*piVar8 != 0) {
        cVar6 = *(char *)(*piVar8 + 0x16e);
      }
    }
  }
  piStack_20 = (int *)0x0;
  iStack_30 = 0;
  uStack_2c = 0;
  uStack_28 = 0;
  uStack_24 = 0;
  iStack_38 = 0;
  piStack_34 = (int *)0x0;
  uStack_8 = 2;
  cVar4 = FUN_008ff170();
  if (cVar4 != '\0') {
    uVar9 = FUN_00587490(&uStack_1c);
    FUN_005587e0(uVar9);
    piVar8 = uStack_1c._4_4_;
    if (uStack_1c._4_4_ != (int *)0x0) {
      LOCK();
      iVar12 = uStack_1c._4_4_[1] + -1;
      uStack_1c._4_4_[1] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        (**(code **)*uStack_1c._4_4_)();
        LOCK();
        piVar2 = piVar8 + 2;
        iVar12 = *piVar2 + -1;
        *piVar2 = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          (**(code **)(*piVar8 + 4))();
        }
      }
    }
    if (iStack_38 == 0) {
      *(undefined *)(param_1 + 0xd1) = 0;
    }
  }
  if (DAT_01ee41ed != '\0') {
    FUN_016774b0(DAT_01ee41ed,"Starting handing out events...",0);
  }
  if (*(int *)(*param_2 + 0x54) == 4) {
    puStack_40[2] = 0;
    piVar8 = (int *)puStack_40[3];
    puStack_40[3] = 0;
    if (piVar8 != (int *)0x0) {
      LOCK();
      iVar12 = piVar8[2] + -1;
      piVar8[2] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  if (param_1 == (int *)0xfffffff4) {
    iStack_3c = 0;
  }
  else {
    piVar8 = (int *)FUN_00636c60();
    iStack_3c = *piVar8;
    if (iStack_3c != 0) {
      FUN_0054ef60(*param_2 + 0xc0);
      uStack_14 = 0x30;
      uStack_8._0_1_ = 3;
      piStack_70 = (int *)FUN_00b82590(&uStack_1c,auStack_58);
      piStack_70 = (int *)*piStack_70;
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      if ((piStack_70 == (int *)0x0) ||
         (iVar12 = piStack_70[3], iVar10 = FUN_00c3ebd0(),
         (uint)*(ushort *)(iVar10 + 0x1da) <
         (uint)*(ushort *)(iVar12 + 0x1d8) - (uint)*(ushort *)(iVar10 + 0x1d8))) {
        piStack_70 = (int *)0x0;
      }
      piVar8 = uStack_1c._4_4_;
      if (uStack_1c._4_4_ != (int *)0x0) {
        LOCK();
        iVar12 = uStack_1c._4_4_[1] + -1;
        uStack_1c._4_4_[1] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          (**(code **)*uStack_1c._4_4_)();
          LOCK();
          piVar2 = piVar8 + 2;
          iVar12 = *piVar2 + -1;
          *piVar2 = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            (**(code **)(*piVar8 + 4))();
          }
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_005507b0();
      if (piStack_70 != (int *)0x0) {
        uVar9 = (**(code **)(*piStack_70 + 0x120))(&uStack_6c,param_2);
        FUN_008eb5c0(uVar9);
        if (piStack_5c != (int *)0x0) {
          LOCK();
          iVar12 = piStack_5c[2] + -1;
          piStack_5c[2] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            (**(code **)(*piStack_5c + 4))();
          }
        }
      }
    }
  }
  *(undefined *)(puStack_40 + 4) = 0;
  cVar4 = FUN_008ff170();
  if (cVar4 == '\0') {
LAB_00904ea5:
    if (iStack_30 != 1) {
      uVar9 = FUN_009058a0(auStack_54,param_2);
      FUN_008eb5c0(uVar9);
      if (piStack_44 != (int *)0x0) {
        LOCK();
        iVar12 = piStack_44[2] + -1;
        piStack_44[2] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          (**(code **)(*piStack_44 + 4))();
        }
      }
      if (iStack_30 != 1) {
        if ((param_1 != (int *)0xfffffff4) && (piVar8 = (int *)FUN_008e5530(), *piVar8 != 0)) {
          uVar9 = FUN_00e6d910(auStack_54,param_2);
          FUN_008eb5c0(uVar9);
          if (piStack_44 != (int *)0x0) {
            LOCK();
            iVar12 = piStack_44[2] + -1;
            piStack_44[2] = iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              (**(code **)(*piStack_44 + 4))();
            }
          }
        }
        if ((iStack_30 != 1) && (iVar12 = FUN_008e4530(param_1 + 3), iVar12 != 0)) {
          uVar9 = FUN_00b79310(auStack_54,param_2);
          FUN_008eb5c0(uVar9);
          if (piStack_44 != (int *)0x0) {
            LOCK();
            iVar12 = piStack_44[2] + -1;
            piStack_44[2] = iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              (**(code **)(*piStack_44 + 4))();
            }
          }
        }
      }
    }
  }
  else {
    if ((DAT_01d68e50 != '\0') && (iStack_30 != 1)) {
      if (DAT_01ee41ed != '\0') {
        FUN_016774b0(DAT_01ee41ed,"Handing to Convex Decomp Debugger",0);
      }
      uVar9 = FUN_009046e0(&uStack_6c,param_2);
      FUN_008eb5c0(uVar9);
      if (piStack_5c != (int *)0x0) {
        LOCK();
        iVar12 = piStack_5c[2] + -1;
        piStack_5c[2] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          (**(code **)(*piStack_5c + 4))();
        }
      }
    }
    if (DAT_01d6f4b0 == '\0') {
LAB_00904d66:
      if (iStack_30 != 1) {
        if (DAT_01ee41ed != '\0') {
          FUN_016774b0(DAT_01ee41ed,"Handing to GuiHiding",0);
        }
        uVar9 = FUN_00905750(&uStack_6c,param_2);
        FUN_008eb5c0(uVar9);
        if (piStack_5c != (int *)0x0) {
          LOCK();
          iVar12 = piStack_5c[2] + -1;
          piStack_5c[2] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            (**(code **)(*piStack_5c + 4))();
          }
        }
        if (iStack_30 != 1) {
          if (DAT_01ee41ed != '\0') {
            FUN_016774b0(DAT_01ee41ed,"Handing to Profiler",0);
          }
          uVar9 = FUN_00907010(&uStack_6c,param_2);
          FUN_008eb5c0(uVar9);
          if (piStack_5c != (int *)0x0) {
            LOCK();
            iVar12 = piStack_5c[2] + -1;
            piStack_5c[2] = iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              (**(code **)(*piStack_5c + 4))();
            }
          }
          if (iStack_30 != 1) {
            if (DAT_01ee41ed != '\0') {
              FUN_016774b0(DAT_01ee41ed,"Handing to EventCallback",0);
            }
            if ((code *)param_1[0x13c] != (code *)0x0) {
              cVar4 = (*(code *)param_1[0x13c])(*param_2);
              if (cVar4 == '\0') {
                uVar9 = FUN_008b6b50(&uStack_6c);
                uVar11 = 2;
              }
              else {
                uVar9 = FUN_0090cc40(auStack_54);
                uVar11 = 1;
              }
              uVar11 = uVar11 | uStack_14;
              FUN_008eb5c0(uVar9);
              uStack_14 = uVar11;
              if ((uVar11 & 2) != 0) {
                uStack_14 = uVar11 & 0xfffffffd;
                FUN_008ae7d0();
              }
              if ((uStack_14 & 1) != 0) {
                uStack_14 = uStack_14 & 0xfffffffe;
                FUN_008ae7d0();
              }
            }
            goto LAB_00904ea5;
          }
        }
      }
    }
    else if (iStack_30 != 1) {
      if (DAT_01ee41ed != '\0') {
        FUN_016774b0(DAT_01ee41ed,"Handing to Network Physics Debugger",0);
      }
      uVar9 = FUN_009061a0(&uStack_6c,param_2);
      FUN_008eb5c0(uVar9);
      if (piStack_5c != (int *)0x0) {
        LOCK();
        iVar12 = piStack_5c[2] + -1;
        piStack_5c[2] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          (**(code **)(*piStack_5c + 4))();
        }
      }
      goto LAB_00904d66;
    }
  }
  if (param_1[0x56] - 4U < 2) {
    uVar9 = FUN_00b82b00();
    iVar12 = FUN_00ed3bf0(uVar9);
    if (iVar12 == -1) {
      if (((iStack_30 == 1) && (iStack_38 != 0)) && (iStack_38 != param_1[0x6e])) {
LAB_00904fb8:
        uVar5 = 1;
      }
      else {
        piVar8 = (int *)FUN_00587490(&uStack_1c);
        uStack_14 = uStack_14 | 4;
        if (*piVar8 != 0) goto LAB_00904fb8;
        uVar5 = 0;
      }
      *(undefined *)(param_1 + 0x73) = uVar5;
      if ((uStack_14 & 4) != 0) {
        uStack_14 = uStack_14 & 0xfffffffb;
        FUN_00550b30();
      }
    }
  }
  cVar4 = FUN_008ff170();
  if (cVar4 == '\0') {
    if (iStack_30 != 1) {
      if (DAT_01ee41ed != '\0') {
        FUN_016774b0(DAT_01ee41ed,"Handing to Plugin Gui Widgets",0);
      }
      uVar9 = (**(code **)(*param_1 + 0x14))(auStack_54,param_2);
      FUN_008eb5c0(uVar9);
      if (piStack_44 != (int *)0x0) {
        LOCK();
        iVar12 = piStack_44[2] + -1;
        piStack_44[2] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          (**(code **)(*piStack_44 + 4))();
        }
      }
    }
    goto LAB_0090566f;
  }
  piVar8 = (int *)FUN_00636b00();
  uStack_7c = (double)CONCAT44(*piVar8,(uint)uStack_7c);
  if (iStack_30 != 1) {
    if (*(char *)(*piVar8 + 0xe4) != '\0') {
      if (DAT_01ee41ed != '\0') {
        FUN_016774b0(DAT_01ee41ed,"Handing to Core Gui",0);
      }
      FUN_00b603e0(&uStack_6c,param_2);
      uStack_14 = uStack_14 | 0x40;
      *(bool *)(param_1[0xce] + 0x10) = iStack_64 == 1;
      FUN_008eb5c0(&uStack_6c);
      if (piStack_5c != (int *)0x0) {
        LOCK();
        iVar12 = piStack_5c[2] + -1;
        piStack_5c[2] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          (**(code **)(*piStack_5c + 4))();
        }
      }
    }
    if (iStack_30 != 1) {
      if (((*(int *)(*param_2 + 0x54) == 8) && (iVar12 = *(int *)(*param_2 + 0x5c), iVar12 != 2)) &&
         ((iVar12 != 4 && ((*(char *)(param_1 + 0xd1) == '\0' && (param_1 != (int *)0xfffffff4))))))
      {
        piVar8 = (int *)FUN_008e53d0();
        if (*piVar8 == 0) {
          FUN_008e24e0(&uStack_1c);
          uStack_8 = CONCAT31(uStack_8._1_3_,5);
          FUN_008a5700(param_1 + 3);
          FUN_005789c0(&DAT_01ee0d10,&LAB_008e0e70);
          uVar9 = FUN_008e3d20();
          puVar13 = (undefined4 *)FUN_008aa140(uVar9);
          if (uStack_1c._4_4_ != (int *)0x0) {
            LOCK();
            *(int *)((int)uStack_1c._4_4_ + 4) = *(int *)((int)uStack_1c._4_4_ + 4) + 1;
            UNLOCK();
          }
          *puVar13 = (int)uStack_1c;
          piStack_70 = (int *)puVar13[1];
          puVar13[1] = uStack_1c._4_4_;
          if (piStack_70 != (int *)0x0) {
            LOCK();
            iVar12 = piStack_70[1] + -1;
            piStack_70[1] = iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              (**(code **)*piStack_70)();
              LOCK();
              iVar12 = piStack_70[2] + -1;
              piStack_70[2] = iVar12;
              UNLOCK();
              if (iVar12 == 0) {
                (**(code **)(*piStack_70 + 4))();
              }
            }
          }
          iVar12 = (int)uStack_1c;
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          piStack_70 = uStack_1c._4_4_;
          if (uStack_1c._4_4_ != (int *)0x0) {
            LOCK();
            iVar10 = uStack_1c._4_4_[1] + -1;
            uStack_1c._4_4_[1] = iVar10;
            UNLOCK();
            if (iVar10 == 0) {
              (**(code **)*uStack_1c._4_4_)();
              LOCK();
              iVar10 = piStack_70[2] + -1;
              piStack_70[2] = iVar10;
              UNLOCK();
              if (iVar10 == 0) {
                (**(code **)(*piStack_70 + 4))();
              }
            }
          }
          if (iVar12 == 0) goto LAB_009051bd;
        }
        if (DAT_01ee41ed != '\0') {
          FUN_016774b0(DAT_01ee41ed,"Handing to gamepadService for keyboard event",0);
        }
        uVar9 = FUN_00b82ae0(auStack_74,param_2);
        uVar9 = FUN_00ed4e50(auStack_54,uVar9);
        FUN_008eb5c0(uVar9);
        FUN_008ae7d0();
      }
LAB_009051bd:
      if (iStack_30 != 1) {
        if (DAT_01ee41ed != '\0') {
          FUN_016774b0(DAT_01ee41ed,"Handing to processCoreGamepadEvent",0);
        }
        if ((param_1 == (int *)0xfffffff4) || (piVar8 = (int *)FUN_008e53d0(), *piVar8 == 0)) {
          piStack_5c = (int *)0x0;
          uStack_6c = 0;
          uStack_68 = 0;
          iStack_64 = 0;
          uStack_60 = 0;
        }
        else {
          FUN_00ed4ac0(&uStack_6c,param_2);
        }
        uVar11 = uStack_14 | 0x80;
        FUN_008eb5c0(&uStack_6c);
        if (piStack_5c != (int *)0x0) {
          LOCK();
          iVar12 = piStack_5c[2] + -1;
          piStack_5c[2] = iVar12;
          UNLOCK();
          if (iVar12 == 0) {
            (**(code **)(*piStack_5c + 4))();
          }
        }
        uStack_14 = uVar11;
        if (iStack_30 != 1) {
          if (DAT_01ee41ed != '\0') {
            FUN_016774b0(DAT_01ee41ed,"Handing to ContextActionService Core Bindings",0);
          }
          uVar9 = FUN_00dfddb0(auStack_54,param_2);
          FUN_008eb5c0(uVar9);
          uStack_14 = uVar11;
          if (piStack_44 != (int *)0x0) {
            LOCK();
            iVar12 = piStack_44[2] + -1;
            piStack_44[2] = iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              (**(code **)(*piStack_44 + 4))();
              uStack_14 = uVar11;
            }
          }
        }
      }
    }
  }
  if (DAT_01d68228 == '\0') {
LAB_00905319:
    if (iStack_30 != 1) {
      if (DAT_01ee41ed != '\0') {
        FUN_016774b0(DAT_01ee41ed,"Handing to Accelerators",0);
      }
      uVar9 = (**(code **)(*param_1 + 0xc))(auStack_54,param_2);
      FUN_008eb5c0(uVar9);
      if (piStack_44 != (int *)0x0) {
        LOCK();
        iVar12 = piStack_44[2] + -1;
        piStack_44[2] = iVar12;
        UNLOCK();
        if (iVar12 == 0) {
          (**(code **)(*piStack_44 + 4))();
        }
      }
      if (iStack_30 != 1) {
        if ((cVar6 == '\0') && (*(char *)(uStack_7c._4_4_ + 0xe5) != '\0')) {
          uVar9 = FUN_009066d0(auStack_54,param_2);
          FUN_008eb5c0(uVar9);
          FUN_008ae7d0();
        }
        if (iStack_30 != 1) {
          if (DAT_01ee41ed != '\0') {
            FUN_016774b0(DAT_01ee41ed,"Handing to PlayerGui Rendered in 3d",0);
          }
          uVar9 = FUN_008b4950(auStack_54,param_2);
          FUN_008eb5c0(uVar9);
          if (piStack_44 != (int *)0x0) {
            LOCK();
            iVar12 = piStack_44[2] + -1;
            piStack_44[2] = iVar12;
            UNLOCK();
            if (iVar12 == 0) {
              (**(code **)(*piStack_44 + 4))();
            }
          }
          if (iStack_30 != 1) {
            if (cVar6 == '\0') {
              if (DAT_01ee41ed != '\0') {
                FUN_016774b0(DAT_01ee41ed,"Handing to processDevGamepadEvent",0);
              }
              if ((param_1 == (int *)0xfffffff4) || (piVar8 = (int *)FUN_008e53d0(), *piVar8 == 0))
              {
                piStack_5c = (int *)0x0;
                uStack_6c = 0;
                uStack_68 = 0;
                iStack_64 = 0;
                uStack_60 = 0;
              }
              else {
                FUN_00ed4b70(&uStack_6c,param_2);
              }
              uVar11 = uStack_14 | 0x100;
              uStack_14 = uVar11;
              FUN_008eb5c0(&uStack_6c);
              if (piStack_5c != (int *)0x0) {
                LOCK();
                iVar12 = piStack_5c[2] + -1;
                piStack_5c[2] = iVar12;
                UNLOCK();
                uStack_14 = uVar11;
                if (iVar12 == 0) {
                  (**(code **)(*piStack_5c + 4))();
                  uStack_14 = uVar11;
                }
              }
            }
            if (iStack_30 != 1) {
              if (DAT_01ee41ed != '\0') {
                FUN_016774b0(DAT_01ee41ed,"Handing to ContextActionService Dev Bindings",0);
              }
              uVar9 = FUN_00dfde10(auStack_54,param_2,cVar6);
              FUN_008eb5c0(uVar9);
              if (piStack_44 != (int *)0x0) {
                LOCK();
                iVar12 = piStack_44[2] + -1;
                piStack_44[2] = iVar12;
                UNLOCK();
                if (iVar12 == 0) {
                  (**(code **)(*piStack_44 + 4))();
                }
              }
              if ((iStack_30 != 1) && (cVar6 == '\0')) {
                if (DAT_01ee41ed != '\0') {
                  FUN_016774b0(DAT_01ee41ed,"Handing to Camera Process",0);
                }
                uVar9 = (**(code **)(*param_1 + 0x10))(auStack_54,param_2);
                FUN_008eb5c0(uVar9);
                if (piStack_44 != (int *)0x0) {
                  LOCK();
                  iVar12 = piStack_44[2] + -1;
                  piStack_44[2] = iVar12;
                  UNLOCK();
                  if (iVar12 == 0) {
                    (**(code **)(*piStack_44 + 4))();
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  else if (DAT_01d635ec == '\0') {
    if (iStack_30 != 1) {
LAB_009052d0:
      if (DAT_01ee41ed != '\0') {
        FUN_016774b0(DAT_01ee41ed,"Handing to ProximityPromptService",0);
      }
      iVar12 = FUN_008e45f0(param_1 + 3);
      if (iVar12 != 0) {
        uVar9 = FUN_00c11ec0(auStack_54,param_2);
        FUN_008eb5c0(uVar9);
        FUN_008ae7d0();
      }
      goto LAB_00905319;
    }
  }
  else if (iStack_30 != 1) {
    if (cVar6 == '\0') goto LAB_009052d0;
    goto LAB_00905319;
  }
  uVar9 = FUN_00b82b00();
  iVar12 = FUN_00ed3bf0(uVar9);
  if (iVar12 == -1) {
    if (((iStack_30 == 1) && (iStack_38 != 0)) && (uVar11 = uStack_14, iStack_38 != param_1[0x6e]))
    {
LAB_00905584:
      uVar5 = 1;
    }
    else {
      piVar8 = (int *)FUN_00587490(&uStack_1c);
      uVar11 = uStack_14 | 8;
      if (*piVar8 != 0) goto LAB_00905584;
      uVar5 = 0;
    }
    *(undefined *)(param_1 + 0x73) = uVar5;
    if ((uVar11 & 8) != 0) {
      FUN_00550b30();
    }
  }
  if (((iStack_30 != 1) && (cVar6 == '\0')) && (cVar6 = FUN_00d81cb0(), cVar6 != '\0')) {
    if (DAT_01ee41ed != '\0') {
      FUN_016774b0(DAT_01ee41ed,"Handing to Workspace",0);
    }
    uVar9 = (**(code **)(*(int *)param_1[0x6e] + 0xac))(auStack_54,param_2);
    FUN_008eb5c0(uVar9);
    FUN_008ae7d0();
  }
  uVar11 = *(uint *)(*param_2 + 0x54);
  if ((uVar11 < 5) ||
     ((((uVar11 == 8 && (iVar12 = *(int *)(*param_2 + 0x5c), iVar12 != 2)) && (iVar12 != 4)) ||
      (cVar6 = FUN_00d81a20(), cVar6 != '\0')))) {
    FUN_0092ef80(param_1 + 3);
  }
LAB_0090566f:
  FUN_00587490(&uStack_1c);
  piVar8 = uStack_1c._4_4_;
  if (uStack_1c._4_4_ != (int *)0x0) {
    LOCK();
    uStack_1c._4_4_[2] = uStack_1c._4_4_[2] + 1;
    UNLOCK();
  }
  *puStack_40 = (int)uStack_1c;
  piVar2 = (int *)puStack_40[1];
  puStack_40[1] = uStack_1c._4_4_;
  if (piVar2 != (int *)0x0) {
    LOCK();
    iVar12 = piVar2[2] + -1;
    piVar2[2] = iVar12;
    UNLOCK();
    if (iVar12 == 0) {
      (**(code **)(*piVar2 + 4))();
    }
  }
  if (piVar8 != (int *)0x0) {
    LOCK();
    iVar12 = piVar8[1] + -1;
    piVar8[1] = iVar12;
    UNLOCK();
    if (iVar12 == 0) {
      (**(code **)*piVar8)();
      LOCK();
      iVar12 = piVar8[2] + -1;
      piVar8[2] = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  if (DAT_01ee41ed != '\0') {
    FUN_016774b0(DAT_01ee41ed,"DM event processed",0);
  }
  piVar8 = piStack_34;
  bVar15 = iStack_30 == 1;
  if (piStack_34 != (int *)0x0) {
    LOCK();
    iVar12 = piStack_34[1] + -1;
    piStack_34[1] = iVar12;
    UNLOCK();
    if (iVar12 == 0) {
      (**(code **)*piStack_34)();
      LOCK();
      piVar2 = piVar8 + 2;
      iVar12 = *piVar2 + -1;
      *piVar2 = iVar12;
      UNLOCK();
      if (iVar12 == 0) {
        (**(code **)(*piVar8 + 4))();
      }
    }
  }
  if (piStack_20 != (int *)0x0) {
    LOCK();
    piVar8 = piStack_20 + 2;
    iVar12 = *piVar8;
    *piVar8 = *piVar8 + -1;
    UNLOCK();
    if (iVar12 == 1) {
      (**(code **)(*piStack_20 + 4))();
    }
  }
  ExceptionList = pvStack_10;
  return bVar15;
}



/* FUNCTION 15892 ; VA 0x00905750 ; FUN_00905750 */

undefined4 * __thiscall FUN_00905750(int param_1,undefined4 *param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  
  if ((((*(int *)(param_1 + 0x158) != 0) && (iVar1 = *param_3, *(int *)(iVar1 + 0x54) == 8)) &&
      (iVar2 = *(int *)(iVar1 + 0x5c), iVar2 != 2)) && (iVar2 != 4)) {
    if (((iVar2 == 2) || (iVar2 == 4)) ||
       ((*(int *)(iVar1 + 0xa8) != 0x67 ||
        ((uVar3 = FUN_00d816c0(), (uVar3 & 0xcc0) == 0 || (uVar3 = FUN_00d816c0(), (uVar3 & 1) == 0)
         ))))) {
      iVar1 = *param_3;
      if (((((*(int *)(iVar1 + 0x54) == 8) && (*(int *)(iVar1 + 0x5c) != 2)) &&
           (*(int *)(iVar1 + 0x5c) != 4)) &&
          ((*(int *)(iVar1 + 0xa8) == 99 && (uVar3 = FUN_00d816c0(), (uVar3 & 0xcc0) != 0)))) &&
         (uVar3 = FUN_00d816c0(), (uVar3 & 1) != 0)) {
        FUN_00636b00();
        uVar4 = 1;
      }
      else {
        iVar1 = *param_3;
        if (((*(int *)(iVar1 + 0x54) != 8) || (*(int *)(iVar1 + 0x5c) == 2)) ||
           ((*(int *)(iVar1 + 0x5c) == 4 ||
            (((*(int *)(iVar1 + 0xa8) != 0x62 || (uVar3 = FUN_00d816c0(), (uVar3 & 0xcc0) == 0)) ||
             (uVar3 = FUN_00d816c0(), (uVar3 & 1) == 0)))))) goto LAB_00905869;
        FUN_00636b00();
        FUN_00b9e250(2);
        uVar4 = 3;
      }
    }
    else {
      FUN_00636b00();
      uVar4 = 0;
    }
    FUN_00b9e250(uVar4);
    FUN_0090cc40(param_2);
    return param_2;
  }
LAB_00905869:
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  return param_2;
}



/* FUNCTION 15893 ; VA 0x009058a0 ; FUN_009058a0 */

undefined4 * FUN_009058a0(undefined4 *param_1,int *param_2)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  int *piVar4;
  int iVar5;
  undefined8 *puVar6;
  code *pcVar7;
  undefined4 uVar8;
  uint uVar9;
  uint uVar10;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined auStack_38 [8];
  undefined auStack_30 [4];
  undefined auStack_2c [4];
  int *piStack_28;
  int *piStack_24;
  int *piStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c4de9;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  uStack_14 = 1;
  piStack_24 = (int *)0x0;
  piStack_20 = (int *)0x0;
  uStack_8 = 1;
  FUN_0054ef60(*param_2 + 0xc0);
  uStack_14 = 3;
  uStack_8._0_1_ = 2;
  FUN_008fba50(auStack_50);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  if (0xf < uStack_3c) {
    uVar10 = uStack_3c + 1;
    uVar9 = auStack_50[0];
    if (0xfff < uVar10) {
      uVar9 = *(uint *)(auStack_50[0] - 4);
      uVar10 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar10);
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  piVar4 = (int *)FUN_00587490(auStack_2c);
  piStack_20 = (int *)piVar4[1];
  piVar1 = (int *)*piVar4;
  *piVar4 = 0;
  piVar4[1] = 0;
  piStack_18 = piStack_28;
  piStack_24 = piVar1;
  piStack_1c = piStack_20;
  if (piStack_28 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_28[1] + -1;
    piStack_28[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_28)();
      LOCK();
      iVar2 = piStack_18[2] + -1;
      piStack_18[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_18 + 4))();
      }
    }
  }
  if (piVar1 != (int *)0x0) {
    if (DAT_01ee41ed != '\0') {
      FUN_016774b0(DAT_01ee41ed,"Handing to GUI target: %p",piVar1);
    }
    iVar2 = piVar1[3];
    iVar5 = FUN_00c3ebd0();
    if ((uint)*(ushort *)(iVar5 + 0x1da) <
        (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8)) {
      iVar2 = piVar1[3];
      iVar5 = FUN_00d5e4a0();
      if ((uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar5 + 0x1d8) <=
          (uint)*(ushort *)(iVar5 + 0x1da)) {
        uVar8 = (**(code **)(*piVar1 + 0xa4))(auStack_38,param_2);
        FUN_008eb5c0(uVar8);
        if (piStack_28 != (int *)0x0) {
          LOCK();
          iVar2 = piStack_28[2] + -1;
          piStack_28[2] = iVar2;
          UNLOCK();
          if (iVar2 == 0) {
            (**(code **)(*piStack_28 + 4))();
          }
        }
      }
    }
    else {
      piVar4 = (int *)FUN_00817fa0();
      if (piVar4 != (int *)0x0) {
        iVar2 = *param_2;
        puVar6 = (undefined8 *)(**(code **)(*piVar4 + 0x120))(auStack_30,param_2);
        uVar8 = *(undefined4 *)(puVar6 + 1);
        *(undefined8 *)(iVar2 + 0x78) = *puVar6;
        *(undefined4 *)(iVar2 + 0x80) = uVar8;
      }
      if ((*(int *)(*param_2 + 0x54) == 8) || (cVar3 = FUN_00d81a20(), cVar3 != '\0')) {
        pcVar7 = *(code **)(*piVar1 + 0xa4);
      }
      else {
        pcVar7 = *(code **)(*piVar1 + 0x120);
      }
      uVar8 = (*pcVar7)(auStack_38,param_2);
      FUN_008eb5c0(uVar8);
      if (piStack_28 != (int *)0x0) {
        LOCK();
        iVar2 = piStack_28[2] + -1;
        piStack_28[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          (**(code **)(*piStack_28 + 4))();
        }
      }
      piStack_28 = (int *)0x0;
      iVar2 = *param_2;
      *(undefined8 *)(iVar2 + 0x78) = 0;
      *(undefined4 *)(iVar2 + 0x80) = 0;
    }
  }
  piVar1 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_1c)();
      LOCK();
      piVar4 = piVar1 + 2;
      iVar2 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15894 ; VA 0x00905b60 ; FUN_00905b60 */

void __thiscall
FUN_00905b60(undefined4 param_1,void **param_2,int ***param_3,int *param_4,undefined4 param_5,
            int *param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9,longlong param_10,
            longlong *param_11)

{
  int iVar1;
  void *pvVar2;
  undefined8 *puVar3;
  void **ppvVar4;
  undefined *puVar5;
  int ***pppiVar6;
  int **ppiVar7;
  longlong *plVar8;
  int **ppiVar9;
  int *piVar10;
  undefined4 *puVar11;
  TypeDescriptor *pTVar12;
  uint uVar13;
  int *piVar14;
  int **ppiStack_f8;
  undefined *puStack_f4;
  int *piStack_f0;
  void *pvStack_ec;
  int *piStack_e8;
  undefined4 uStack_e4;
  undefined8 uStack_e0;
  undefined8 uStack_d8;
  int *piStack_d0;
  int *piStack_cc;
  void *pvStack_c8;
  int *piStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  longlong lStack_b4;
  int *piStack_ac;
  int *piStack_a8;
  void *pvStack_a4;
  int *piStack_a0;
  int aiStack_9c [3];
  undefined4 uStack_90;
  undefined auStack_8c [12];
  undefined4 uStack_80;
  int *piStack_7c;
  undefined4 uStack_78;
  TypeDescriptor *pTStack_74;
  TypeDescriptor *pTStack_70;
  int *piStack_6c;
  int **ppiStack_60;
  TypeDescriptor TStack_58;
  int *piStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  TypeDescriptor TStack_40;
  int *piStack_38;
  int *piStack_34;
  TypeDescriptor TStack_30;
  TypeDescriptor TStack_28;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar14 = (int *)param_2;
  puStack_c = &LAB_017c4e57;
  pvStack_10 = ExceptionList;
  uStack_20 = param_1;
  piStack_1c = (int *)0x0;
  uStack_8 = 0;
  if (param_2 == (void **)0x0) {
    TStack_30.spare = (int *)0x0;
    pTVar12 = &TStack_30;
    puStack_14 = (undefined *)0x2;
    piStack_38 = (int *)0x0;
    ExceptionList = &pvStack_10;
  }
  else {
    piStack_6c = (int *)0x24;
    pTStack_70 = (TypeDescriptor *)0x905b9c;
    ExceptionList = &pvStack_10;
    piVar10 = (int *)FUN_01674e20();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    param_2 = (void **)piVar10;
    if (piVar10 == (int *)0x0) {
      pTVar12 = &TStack_28;
      TStack_28.spare = (int *)0x0;
      piStack_38 = (int *)&DAT_0000000c;
      puStack_14 = (undefined *)0x11;
    }
    else {
      piVar10[1] = 1;
      piStack_6c = piVar14;
      piVar10[2] = 1;
      *piVar10 = (int)std::
                      _Ref_count_obj<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>
                      ::vftable;
      pTStack_70 = (TypeDescriptor *)0x905bc9;
      FUN_0054ef60();
      piStack_38 = piVar10 + 3;
      TStack_28.spare = piVar10;
      pTVar12 = &TStack_28;
      puStack_14 = (undefined *)0x11;
    }
  }
  piStack_18 = piStack_38;
  piStack_34 = (int *)pTVar12->spare;
  pTVar12->pVFTable = (void *)0x0;
  pTVar12->spare = (void *)0x0;
  pvVar2 = TStack_30.spare;
  piStack_1c = piStack_34;
  if ((((uint)puStack_14 & 2) != 0) &&
     (puStack_14 = (undefined *)((uint)puStack_14 & 0xfffffffd),
     (int *)TStack_30.spare != (int *)0x0)) {
    LOCK();
    iVar1 = *(int *)((int)TStack_30.spare + 4) + -1;
    *(int *)((int)TStack_30.spare + 4) = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
                    /* WARNING: Load size is inaccurate */
      piStack_6c = (int *)0x905c3d;
      (*(code *)**TStack_30.spare)();
      LOCK();
      piVar14 = (int *)((int)pvVar2 + 8);
      iVar1 = *piVar14 + -1;
      *piVar14 = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
                    /* WARNING: Load size is inaccurate */
        piStack_6c = (int *)0x905c4d;
        (**(code **)(*pvVar2 + 4))();
      }
    }
  }
  pvVar2 = TStack_28.spare;
  if ((((uint)puStack_14 & 1) != 0) &&
     (puStack_14 = (undefined *)((uint)puStack_14 & 0xfffffffe),
     (int *)TStack_28.spare != (int *)0x0)) {
    LOCK();
    iVar1 = *(int *)((int)TStack_28.spare + 4) + -1;
    *(int *)((int)TStack_28.spare + 4) = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
                    /* WARNING: Load size is inaccurate */
      piStack_6c = (int *)0x905c71;
      (*(code *)**TStack_28.spare)();
      LOCK();
      piVar14 = (int *)((int)pvVar2 + 8);
      iVar1 = *piVar14 + -1;
      *piVar14 = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
                    /* WARNING: Load size is inaccurate */
        piStack_6c = (int *)0x905c81;
        (**(code **)(*pvVar2 + 4))();
      }
    }
  }
  piVar14 = (int *)param_3;
  TStack_28.pVFTable = (void *)0x0;
  TStack_28.spare = (void *)0x0;
  piStack_6c = (int *)0x0;
  pTStack_70 = &RBX::http_status_error::RTTI_Type_Descriptor;
  pTStack_74 = &std::exception::RTTI_Type_Descriptor;
  uStack_78 = 0;
  piStack_7c = (int *)param_3;
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  uStack_80 = 0x905caa;
  piStack_6c = (int *)FUN_0170d75d();
  if (piStack_6c == (int *)0x0) {
    if (piVar14 == (int *)0x0) {
      TStack_30.spare = (int *)0x0;
      pTVar12 = &TStack_30;
      uVar13 = 8;
      param_2 = (void **)0x0;
    }
    else {
      piStack_6c = (int *)0x905cee;
      param_2 = (void **)(**(code **)(*piVar14 + 4))();
      piStack_6c = (int *)&param_2;
      pTStack_70 = (TypeDescriptor *)&param_3;
      param_3 = (int ***)0x0;
      pTStack_74 = &TStack_40;
      uStack_78 = 0x905d09;
      pTVar12 = (TypeDescriptor *)FUN_008e5230();
      uVar13 = 4;
      param_2 = (void **)pTVar12->pVFTable;
    }
    param_3 = (int ***)(uVar13 | (uint)puStack_14);
    piVar14 = (int *)pTVar12->spare;
    pTVar12->pVFTable = (void *)0x0;
    pTVar12->spare = (void *)0x0;
    TStack_28.pVFTable = param_2;
    TStack_28.spare = piVar14;
    if ((((uint)param_3 & 8) != 0) &&
       (param_3 = (int ***)((uint)param_3 & 0xfffffff7), (int *)TStack_30.spare != (int *)0x0)) {
      LOCK();
      iVar1 = *(int *)((int)TStack_30.spare + 4) + -1;
      *(int *)((int)TStack_30.spare + 4) = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
                    /* WARNING: Load size is inaccurate */
        piStack_6c = (int *)0x905d63;
        (*(code *)**TStack_30.spare)();
        LOCK();
        iVar1 = *(int *)((int)TStack_30.spare + 8) + -1;
        *(int *)((int)TStack_30.spare + 8) = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
                    /* WARNING: Load size is inaccurate */
          piStack_6c = (int *)0x905d74;
          (**(code **)(*TStack_30.spare + 4))();
        }
      }
    }
    uVar13 = (uint)param_3 & 4;
    param_3 = (int ***)TStack_40.spare;
    if (uVar13 == 0) goto LAB_00905daa;
  }
  else {
    pTStack_70 = &TStack_30;
    pTStack_74 = (TypeDescriptor *)0x905cbb;
    puVar11 = (undefined4 *)FUN_008e5180();
    param_2 = (void **)*puVar11;
    piVar14 = (int *)puVar11[1];
    *puVar11 = 0;
    puVar11[1] = 0;
    param_3 = (int ***)TStack_30.spare;
    TStack_28.pVFTable = param_2;
    TStack_28.spare = piVar14;
  }
  if (param_3 != (int ***)0x0) {
    LOCK();
    iVar1 = ((int *)param_3)[1] + -1;
    ((int *)param_3)[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      piStack_6c = (int *)0x905d96;
      (*(code *)**param_3)();
      LOCK();
      iVar1 = ((int *)param_3)[2] + -1;
      ((int *)param_3)[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        piStack_6c = (int *)0x905da7;
        (**(code **)((int)*param_3 + 4))();
      }
    }
  }
LAB_00905daa:
  if ((char)param_11 == '\0') {
    piStack_6c = (int *)0x1;
    uStack_90 = 0;
    param_11 = (longlong *)&uStack_c0;
    param_3 = (int ***)&pvStack_c8;
    if (piVar14 != (int *)0x0) {
      LOCK();
      piVar14[1] = piVar14[1] + 1;
      UNLOCK();
    }
    puStack_14 = (undefined *)&piStack_d0;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    piStack_d0 = piStack_18;
    piStack_cc = piStack_1c;
    piStack_18 = (int *)&piStack_f0;
    uStack_8._0_1_ = 10;
    piStack_f0 = (int *)0x0;
    puVar5 = auStack_8c;
    ppvVar4 = &pvStack_c8;
    puVar11 = &uStack_c0;
    pvStack_c8 = param_2;
    piStack_c4 = piVar14;
    ppiVar7 = &piStack_f0;
    ppiVar9 = &piStack_d0;
    if (param_4 != (int *)0x0) {
      piStack_f0 = param_4;
      if (((uint)param_4 & 1) == 0) {
        ppiStack_f8 = &piStack_e8;
        puStack_f4 = (undefined *)0x0;
        param_2 = (void **)auStack_8c;
        (**(code **)((uint)param_4 & 0xfffffffe))(&param_6);
        puVar5 = (undefined *)param_2;
        ppvVar4 = param_3;
        puVar11 = (undefined4 *)param_11;
        ppiVar7 = (int **)piStack_18;
        ppiVar9 = (int **)puStack_14;
      }
      else {
        piStack_e8 = param_6;
        uStack_e4 = param_7;
        uStack_e0 = CONCAT44(param_9,param_8);
        uStack_d8 = param_10;
        puVar5 = auStack_8c;
        ppvVar4 = &pvStack_c8;
        puVar11 = &uStack_c0;
        ppiVar7 = &piStack_f0;
        ppiVar9 = &piStack_d0;
      }
    }
    puStack_14 = (undefined *)ppiVar9;
    piStack_18 = (int *)ppiVar7;
    param_11 = (longlong *)puVar11;
    param_3 = (int ***)ppvVar4;
    param_2 = (void **)puVar5;
    puStack_f4 = (undefined *)param_11;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    ppiStack_f8 = (int **)0x905fbb;
    FUN_008e0450();
    piStack_c4 = (int *)0x905fc6;
    FUN_008dba20();
    uStack_90 = 0x905fce;
    FUN_0090ca30();
  }
  else {
    piStack_6c = (int *)0x0;
    param_11 = (longlong *)aiStack_9c;
    if (piVar14 != (int *)0x0) {
      LOCK();
      piVar14[1] = piVar14[1] + 1;
      UNLOCK();
    }
    param_3 = (int ***)&piStack_ac;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piStack_1c[1] = piStack_1c[1] + 1;
      UNLOCK();
    }
    piStack_ac = piStack_18;
    piStack_a8 = piStack_1c;
    piStack_18 = (int *)&piStack_cc;
    uStack_8._0_1_ = 5;
    piStack_cc = (int *)0x0;
    ppvVar4 = &pvStack_a4;
    ppiVar7 = &piStack_ac;
    piVar10 = aiStack_9c;
    pvStack_a4 = param_2;
    piStack_a0 = piVar14;
    ppiVar9 = &piStack_cc;
    if (param_4 != (int *)0x0) {
      piStack_cc = param_4;
      if (((uint)param_4 & 1) == 0) {
        piStack_d0 = (int *)0x0;
        uStack_d8 = CONCAT44(&piStack_c4,&param_6);
        uStack_e0 = CONCAT44(0x905e4b,(undefined4)uStack_e0);
        param_2 = &pvStack_a4;
        (**(code **)((uint)param_4 & 0xfffffffe))();
        ppvVar4 = param_2;
        ppiVar7 = (int **)param_3;
        piVar10 = (int *)param_11;
        ppiVar9 = (int **)piStack_18;
      }
      else {
        piStack_c4 = param_6;
        uStack_c0 = param_7;
        uStack_bc = param_8;
        uStack_b8 = param_9;
        lStack_b4 = param_10;
        ppvVar4 = &pvStack_a4;
        ppiVar7 = &piStack_ac;
        piVar10 = aiStack_9c;
        ppiVar9 = &piStack_cc;
      }
    }
    piStack_18 = (int *)ppiVar9;
    param_11 = (longlong *)piVar10;
    param_3 = (int ***)ppiVar7;
    param_2 = ppvVar4;
    piStack_d0 = (int *)param_11;
    uStack_8._0_1_ = 3;
    uStack_d8._4_4_ = 0x905e5a;
    FUN_008e0450();
    piStack_a0 = (int *)0x905e65;
    FUN_008dba20();
    piStack_6c = (int *)0x1;
    param_11 = &lStack_b4;
    uStack_b8 = 1;
    param_2 = (void **)&uStack_d8;
    uStack_d8 = (ulonglong)uStack_d8._4_4_ << 0x20;
    param_3 = &ppiStack_f8;
    uStack_8._0_1_ = 7;
    ppiStack_f8 = (int **)0x0;
    puVar3 = &uStack_d8;
    pppiVar6 = &ppiStack_f8;
    plVar8 = &lStack_b4;
    if (ppiStack_60 != (int **)0x0) {
      ppiStack_f8 = ppiStack_60;
      if (((uint)ppiStack_60 & 1) == 0) {
        (**(code **)((uint)ppiStack_60 & 0xfffffffe))(&TStack_58,&piStack_f0,0);
        puVar3 = (undefined8 *)param_2;
        pppiVar6 = param_3;
        plVar8 = param_11;
      }
      else {
        piStack_f0 = (int *)TStack_58.pVFTable;
        pvStack_ec = TStack_58.spare;
        piStack_e8 = piStack_50;
        uStack_e4 = uStack_4c;
        uStack_e0 = uStack_48;
        puVar3 = &uStack_d8;
        pppiVar6 = &ppiStack_f8;
        plVar8 = &lStack_b4;
      }
    }
    param_11 = plVar8;
    param_3 = pppiVar6;
    param_2 = (void **)puVar3;
    uStack_8._0_1_ = 6;
    FUN_008e8d60();
    uStack_b8 = 0x905ed9;
    FUN_0090cb30();
    uStack_8 = CONCAT31(uStack_8._1_3_,8);
    if (((ppiStack_60 != (int **)0x0) && (((uint)ppiStack_60 & 1) == 0)) &&
       (*(code **)((uint)ppiStack_60 & 0xfffffffe) != (code *)0x0)) {
      pTStack_74 = &TStack_58;
      piStack_6c = (int *)0x2;
      uStack_78 = 0x905efe;
      pTStack_70 = pTStack_74;
      (**(code **)((uint)ppiStack_60 & 0xfffffffe))();
    }
  }
  if (piVar14 != (int *)0x0) {
    LOCK();
    iVar1 = piVar14[1] + -1;
    piVar14[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      piStack_6c = (int *)0x905fe1;
      (**(code **)*piVar14)();
      LOCK();
      iVar1 = piVar14[2] + -1;
      piVar14[2] = iVar1;
      UNLOCK();
      if (iVar1 == 0) {
        piStack_6c = (int *)0x905ff1;
        (**(code **)(*piVar14 + 4))();
      }
    }
  }
  piVar14 = piStack_1c;
  if (piStack_1c != (int *)0x0) {
    LOCK();
    iVar1 = piStack_1c[1] + -1;
    piStack_1c[1] = iVar1;
    UNLOCK();
    if (iVar1 == 0) {
      piStack_6c = (int *)0x906007;
      (**(code **)*piStack_1c)();
      LOCK();
      piVar10 = piVar14 + 2;
      iVar1 = *piVar10;
      *piVar10 = *piVar10 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        piStack_6c = (int *)0x906016;
        (**(code **)(*piVar14 + 4))();
      }
    }
  }
  uStack_8 = 0xb;
  if (((param_4 != (int *)0x0) && (((uint)param_4 & 1) == 0)) &&
     (*(code **)((uint)param_4 & 0xfffffffe) != (code *)0x0)) {
    pTStack_74 = (TypeDescriptor *)&param_6;
    piStack_6c = (int *)0x2;
    uStack_78 = 0x90603a;
    pTStack_70 = pTStack_74;
    (**(code **)((uint)param_4 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15895 ; VA 0x00906050 ; FUN_00906050 */

uint __thiscall FUN_00906050(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  undefined uVar3;
  char cVar4;
  int iVar5;
  uint uVar6;
  undefined uStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c4e80;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  if ((*(char *)(param_1 + 0x1dd) == '\0') || (param_2 == 0)) {
    uVar6 = 0;
    ExceptionList = &pvStack_10;
  }
  else {
    uVar6 = 0;
    uStack_11 = 0;
    ExceptionList = &pvStack_10;
    if (*(int *)(param_2 + 0x54) != 0x16) {
      ExceptionList = &pvStack_10;
      uVar3 = FUN_009048b0(&param_2,&uStack_11);
      uVar6 = (uint)CONCAT11(uStack_11,uVar3);
    }
    cVar4 = FUN_008ff170();
    if (cVar4 != '\0') {
      FUN_005e6780(&param_2);
      iVar5 = FUN_0097bfc0(param_1 + 0xc);
      if (iVar5 != 0) {
        if (*(int *)(iVar5 + 0x498) != 0) {
          LOCK();
          piVar1 = (int *)(*(int *)(iVar5 + 0x498) + 4);
          *piVar1 = *piVar1 + 1;
          UNLOCK();
        }
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        if (*(int **)(iVar5 + 0x494) != (int *)0x0) {
          if ((((char)uVar6 == '\0') || ((char)(uVar6 >> 8) != '\0')) ||
             (*(uint *)(param_2 + 0x54) == 4)) {
            (**(code **)(**(int **)(iVar5 + 0x494) + 0xa4))(&param_2);
          }
          else if (*(uint *)(param_2 + 0x54) < 5) {
            FUN_00e89020(&param_2);
            FUN_00550b30();
            goto LAB_00906146;
          }
        }
        FUN_00550b30();
      }
    }
  }
LAB_00906146:
  piVar1 = param_3;
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar5 = param_3[1] + -1;
    param_3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*param_3)();
      LOCK();
      piVar2 = piVar1 + 2;
      iVar5 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    ExceptionList = pvStack_10;
    return uVar6 & 0xff;
  }
  ExceptionList = pvStack_10;
  return uVar6 & 0xff;
}



/* FUNCTION 15896 ; VA 0x009061a0 ; FUN_009061a0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __thiscall FUN_009061a0(int param_1,undefined4 *param_2,int *param_3)

{
  int *piVar1;
  char cVar2;
  uint uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  int iVar7;
  bool bVar8;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  int *piStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  uStack_c = 0;
  iVar4 = *(int *)(*(int *)(param_1 + 0x1b8) + 0x1b4);
  if (iVar4 == 0) {
    iVar7 = 0;
  }
  else {
    iVar7 = *(int *)(iVar4 + 0x110);
  }
  iStack_8 = param_1;
  if (iVar7 == 0) {
    iVar7 = *param_3;
    if ((((*(int *)(iVar7 + 0x54) != 8) || (*(int *)(iVar7 + 0x5c) == 2)) ||
        (*(int *)(iVar7 + 0x5c) == 4)) ||
       ((*(int *)(iVar7 + 0xa8) != 0x121 || (uVar3 = FUN_00d816c0(), (uVar3 & 0xcc0) == 0))))
    goto LAB_00906612;
    if (*(int *)(*(int *)(iStack_8 + 0x1b8) + 0x1b4) != 0) {
      FUN_00bc2790(1);
    }
    if (iVar4 == 0) {
      iVar4 = 0;
    }
    else {
      iVar4 = *(int *)(iVar4 + 0x110);
    }
    if (iVar4 == 0) goto LAB_00906612;
  }
  iVar4 = *param_3;
  uVar3 = *(uint *)(iVar4 + 0x54);
  if ((uVar3 < 5) && (uVar3 == 3)) {
    iVar4 = FUN_00d81770(&uStack_18);
    iVar4 = (int)*(float *)(iVar4 + 8);
    uVar3 = FUN_00d816c0();
    if ((uVar3 & 0xcc0) != 0) {
      iVar4 = iVar4 * 10;
    }
    cVar2 = FUN_00f446b0(iVar4);
    bVar8 = cVar2 == '\0';
    if (bVar8) {
      piStack_10 = (int *)0x0;
      uStack_20 = 0;
      uStack_1c = 0;
      uStack_18 = 0;
      uStack_14 = 0;
      puVar5 = &uStack_20;
    }
    else {
      puVar5 = &uStack_34;
      uStack_34 = _DAT_0192d580;
      uStack_30 = _UNK_0192d584;
      uStack_2c = _UNK_0192d588;
      uStack_28 = _UNK_0192d58c;
      piStack_24 = (int *)0x0;
    }
    FUN_008ad9c0(puVar5);
    if ((bVar8) && (piStack_10 != (int *)0x0)) {
      LOCK();
      iVar4 = piStack_10[2] + -1;
      piStack_10[2] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_10 + 4))();
      }
    }
    if (bVar8) {
      return param_2;
    }
    if (piStack_24 == (int *)0x0) {
      return param_2;
    }
    LOCK();
    piVar1 = piStack_24 + 2;
    iVar4 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar4 != 1) {
      return param_2;
    }
    (**(code **)(*piStack_24 + 4))();
    return param_2;
  }
  if (((uVar3 != 8) || (iVar7 = *(int *)(iVar4 + 0x5c), iVar7 == 2)) || (iVar7 == 4)) {
LAB_00906612:
    *param_2 = 0;
    param_2[1] = 0;
    param_2[2] = 0;
    param_2[3] = 0;
    param_2[4] = 0;
    return param_2;
  }
  if (((iVar7 == 2) || (iVar7 == 4)) ||
     ((*(int *)(iVar4 + 0xa8) != 0x121 || (uVar3 = FUN_00d816c0(), (uVar3 & 0xcc0) == 0)))) {
    iVar4 = *param_3;
    if (((*(int *)(iVar4 + 0x54) == 8) && (*(int *)(iVar4 + 0x5c) != 2)) &&
       ((*(int *)(iVar4 + 0x5c) != 4 &&
        ((*(int *)(iVar4 + 0xa8) == 0x70 && (uVar3 = FUN_00d816c0(), (uVar3 & 0xcc0) != 0)))))) {
      cVar2 = FUN_00f44c80();
      if (cVar2 != '\0') {
        uVar6 = FUN_0090cc40(&uStack_20);
        iVar7 = 0x20;
        iVar4 = 0;
        goto LAB_009065e4;
      }
      uVar6 = FUN_008b6b50(&uStack_34);
      iVar4 = 0x40;
    }
    else {
      iVar4 = *param_3;
      if ((((*(int *)(iVar4 + 0x54) == 8) && (*(int *)(iVar4 + 0x5c) != 2)) &&
          (*(int *)(iVar4 + 0x5c) != 4)) &&
         ((*(int *)(iVar4 + 0xa8) == 0x79 && (uVar3 = FUN_00d816c0(), (uVar3 & 0xcc0) != 0)))) {
        cVar2 = FUN_00f44d10();
        if (cVar2 != '\0') {
          uVar6 = FUN_0090cc40(&uStack_20);
          iVar7 = 0x80;
          iVar4 = 0;
          goto LAB_009065e4;
        }
        uVar6 = FUN_008b6b50(&uStack_34);
        iVar4 = 0x100;
      }
      else {
        cVar2 = FUN_008ff0e0(0x75);
        if ((cVar2 == '\0') || (uVar3 = FUN_00d816c0(), (uVar3 & 0xcc0) == 0)) {
          cVar2 = FUN_008ff0e0(0x69);
          if ((cVar2 == '\0') || (uVar3 = FUN_00d816c0(), (uVar3 & 0xcc0) == 0)) {
            cVar2 = FUN_008ff0e0(0x6f);
            if ((cVar2 == '\0') || (uVar3 = FUN_00d816c0(), (uVar3 & 0xcc0) == 0)) {
              cVar2 = FUN_008ff0e0(0x6c);
              if ((cVar2 == '\0') || (uVar3 = FUN_00d816c0(), (uVar3 & 0xcc0) == 0)) {
                cVar2 = FUN_008ff0e0(0x6b);
                if ((cVar2 == '\0') || (uVar3 = FUN_00d816c0(), (uVar3 & 0xcc0) == 0))
                goto LAB_00906612;
                cVar2 = FUN_00f44cd0();
                if (cVar2 != '\0') {
                  uVar6 = FUN_0090cc40(&uStack_20);
                  iVar7 = 0x20000;
                  iVar4 = 0;
                  goto LAB_009065e4;
                }
                uVar6 = FUN_008b6b50(&uStack_34);
                iVar4 = 0x40000;
              }
              else {
                cVar2 = FUN_00f44cf0();
                if (cVar2 != '\0') {
                  uVar6 = FUN_0090cc40(&uStack_20);
                  iVar7 = 0x8000;
                  iVar4 = 0;
                  goto LAB_009065e4;
                }
                uVar6 = FUN_008b6b50(&uStack_34);
                iVar4 = 0x10000;
              }
            }
            else {
              cVar2 = FUN_00f44cc0();
              if (cVar2 != '\0') {
                uVar6 = FUN_0090cc40(&uStack_20);
                iVar7 = 0x2000;
                iVar4 = 0;
                goto LAB_009065e4;
              }
              uVar6 = FUN_008b6b50(&uStack_34);
              iVar4 = 0x4000;
            }
          }
          else {
            cVar2 = FUN_00f44ca0();
            if (cVar2 != '\0') {
              uVar6 = FUN_0090cc40(&uStack_20);
              iVar7 = 0x800;
              iVar4 = 0;
              goto LAB_009065e4;
            }
            uVar6 = FUN_008b6b50(&uStack_34);
            iVar4 = 0x1000;
          }
        }
        else {
          cVar2 = FUN_00f44cb0();
          if (cVar2 != '\0') {
            uVar6 = FUN_0090cc40(&uStack_20);
            iVar7 = 0x200;
            iVar4 = 0;
            goto LAB_009065e4;
          }
          uVar6 = FUN_008b6b50(&uStack_34);
          iVar4 = 0x400;
        }
      }
    }
  }
  else {
    cVar2 = FUN_00f44d20();
    if (cVar2 != '\0') {
      uVar6 = FUN_0090cc40(&uStack_20);
      iVar7 = 8;
      iVar4 = 0;
      goto LAB_009065e4;
    }
    uVar6 = FUN_008b6b50(&uStack_34);
    iVar4 = 0x10;
  }
  iVar7 = 0;
LAB_009065e4:
  FUN_008ad9c0(uVar6);
  if (iVar4 != 0) {
    FUN_008ae7d0();
  }
  if (iVar7 != 0) {
    FUN_008ae7d0();
  }
  return param_2;
}



/* FUNCTION 15897 ; VA 0x00906640 ; FUN_00906640 */

undefined4 * __thiscall FUN_00906640(int param_1,undefined4 *param_2,undefined4 param_3)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x158) == 0) {
    if (*(char *)(*(int *)(param_1 + 0x198) + 0xde) != '\0') {
      FUN_00b606d0(param_2,param_3);
      return param_2;
    }
  }
  else {
    if (param_1 == -0xc) {
      iVar1 = 0;
    }
    else {
      iVar1 = FUN_0055e560();
    }
    if (*(int *)(iVar1 + 0xf4) != 0) {
      iVar1 = FUN_00676e20();
      if (iVar1 != 0) {
        FUN_00b603e0(param_2,param_3);
        return param_2;
      }
    }
  }
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  return param_2;
}



/* FUNCTION 15898 ; VA 0x009066d0 ; FUN_009066d0 */

undefined4 * __thiscall FUN_009066d0(int param_1,undefined4 *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  undefined auStack_40 [4];
  int *piStack_3c;
  undefined auStack_38 [4];
  int *piStack_34;
  int iStack_30;
  int *piStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined4 *puStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017c4eb9;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  if (DAT_01ee41ed != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ee41ed,"Handing to Player Gui",0);
  }
  if (*(int *)(param_1 + 0x158) == 0) {
    if (*(char *)(*(int *)(param_1 + 0x198) + 0xde) != '\0') {
      FUN_00b606d0(param_2,param_3);
      goto LAB_00906798;
    }
  }
  else {
    if (param_1 == -0xc) {
      iVar2 = 0;
    }
    else {
      iVar2 = FUN_0055e560();
    }
    if ((*(int *)(iVar2 + 0xf4) != 0) && (iVar2 = FUN_00676e20(), iVar2 != 0)) {
      FUN_00b603e0(param_2,param_3);
      goto LAB_00906798;
    }
  }
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
LAB_00906798:
  uStack_8 = 0;
  uStack_1c = 3;
  *(bool *)(*(int *)(param_1 + 0x338) + 0x10) = param_2[2] == 1;
  if (param_2[2] != 1) {
    ExceptionList = pvStack_10;
    return param_2;
  }
  FUN_00587490(&iStack_28);
  uStack_8 = 1;
  param_3 = iStack_28;
  if ((iStack_28 == 0) ||
     (iVar2 = *(int *)(iStack_28 + 0xc), iVar3 = FUN_00c6dcc0(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    param_3 = 0;
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    iVar2 = piStack_24[1] + -1;
    piStack_24[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_24 + 4))();
      }
    }
  }
  if (param_3 != 0) {
    puVar4 = (undefined4 *)FUN_0060e0c0(auStack_38,param_3);
    piVar5 = (int *)0x0;
    uStack_14 = 0;
    puStack_20 = (undefined4 *)(*(int *)(iStack_18 + 0x338) + 8);
    iVar2 = puVar4[1];
    if (iVar2 != 0) {
      iVar3 = *(int *)(iVar2 + 4);
      piVar5 = (int *)(iVar2 + 4);
      if (iVar3 == 0) {
        piVar5 = (int *)0x0;
      }
      else {
        do {
          LOCK();
          iVar2 = *piVar5;
          if (iVar3 == iVar2) {
            *piVar5 = iVar3 + 1;
            iVar2 = iVar3;
          }
          UNLOCK();
          if (iVar2 == iVar3) {
            piVar5 = (int *)puVar4[1];
            uStack_14 = *puVar4;
            if (piVar5 != (int *)0x0) {
              LOCK();
              piVar5[2] = piVar5[2] + 1;
              UNLOCK();
              LOCK();
              iVar2 = piVar5[1] + -1;
              piVar5[1] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)*piVar5)();
                LOCK();
                iVar2 = piVar5[2] + -1;
                piVar5[2] = iVar2;
                UNLOCK();
                if (iVar2 == 0) {
                  (**(code **)(*piVar5 + 4))();
                }
              }
            }
            goto LAB_0090689c;
          }
          iVar3 = *piVar5;
        } while (iVar3 != 0);
        piVar5 = (int *)0x0;
      }
    }
LAB_0090689c:
    *puVar4 = 0;
    piVar1 = (int *)puVar4[1];
    puVar4[1] = 0;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    *puStack_20 = uStack_14;
    piVar1 = (int *)puStack_20[1];
    puStack_20[1] = piVar5;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piStack_34 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_34[2] + -1;
      piStack_34[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_34 + 4))();
      }
    }
  }
  FUN_00587490(&iStack_30);
  uStack_8 = 2;
  param_3 = iStack_30;
  if ((iStack_30 == 0) ||
     (iVar2 = *(int *)(iStack_30 + 0xc), iVar3 = FUN_00c3ebd0(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar2 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    param_3 = 0;
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (piStack_2c != (int *)0x0) {
    LOCK();
    iVar2 = piStack_2c[1] + -1;
    piStack_2c[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piStack_2c)();
      LOCK();
      iVar2 = piStack_2c[2] + -1;
      piStack_2c[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piStack_2c + 4))();
      }
    }
  }
  if (param_3 != 0) {
    puVar4 = (undefined4 *)FUN_0060e0c0(auStack_40,param_3);
    piVar5 = (int *)0x0;
    uStack_14 = 0;
    puStack_20 = (undefined4 *)(*(int *)(iStack_18 + 0x338) + 8);
    iStack_18 = puVar4[1];
    if (iStack_18 != 0) {
      iVar2 = *(int *)(iStack_18 + 4);
      while (iVar2 != 0) {
        LOCK();
        iVar3 = *(int *)(iStack_18 + 4);
        if (iVar2 == iVar3) {
          *(int *)(iStack_18 + 4) = iVar2 + 1;
          iVar3 = iVar2;
        }
        UNLOCK();
        if (iVar3 == iVar2) {
          uStack_14 = *puVar4;
          piVar5 = (int *)puVar4[1];
          if (piVar5 != (int *)0x0) {
            LOCK();
            piVar5[2] = piVar5[2] + 1;
            UNLOCK();
            LOCK();
            iVar2 = piVar5[1] + -1;
            piVar5[1] = iVar2;
            UNLOCK();
            if (iVar2 == 0) {
              (**(code **)*piVar5)();
              LOCK();
              iVar2 = piVar5[2] + -1;
              piVar5[2] = iVar2;
              UNLOCK();
              if (iVar2 == 0) {
                (**(code **)(*piVar5 + 4))();
              }
            }
          }
          break;
        }
        iVar2 = *(int *)(iStack_18 + 4);
      }
    }
    *puVar4 = 0;
    piVar1 = (int *)puVar4[1];
    puVar4[1] = 0;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    *puStack_20 = uStack_14;
    piVar1 = (int *)puStack_20[1];
    puStack_20[1] = piVar5;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar2 = piVar1[2] + -1;
      piVar1[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piStack_3c != (int *)0x0) {
      LOCK();
      piVar5 = piStack_3c + 2;
      iVar2 = *piVar5;
      *piVar5 = *piVar5 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piStack_3c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15899 ; VA 0x00906af0 ; FUN_00906af0 */

undefined4 * __thiscall FUN_00906af0(int param_1,undefined4 *param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  undefined4 ***pppuVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  int *piVar7;
  undefined4 *puVar8;
  undefined4 ****ppppuVar9;
  uint uVar10;
  uint uVar11;
  undefined4 ***apppuStack_68 [4];
  undefined4 uStack_58;
  uint uStack_54;
  undefined4 ***apppuStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  int *piStack_38;
  int *piStack_34;
  int iStack_30;
  int *piStack_2c;
  int *piStack_28;
  int iStack_24;
  undefined auStack_20 [4];
  int *piStack_1c;
  int *piStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c4ef0;
  pvStack_10 = ExceptionList;
  uVar11 = -(uint)(param_1 != 0) & param_1 + 0xcU;
  ExceptionList = &pvStack_10;
  if (uVar11 != 0) {
    ExceptionList = &pvStack_10;
    FUN_005789c0(&DAT_01ee0d20,&LAB_008e0ea0);
    uVar4 = FUN_008e3ea0();
    piStack_18 = (int *)FUN_008aa140(uVar4);
    if (*piStack_18 == 0) {
      uVar4 = FUN_00f51690();
      piVar5 = (int *)FUN_008a9ba0(auStack_20,uVar4);
      iVar1 = *piVar5;
      iVar2 = piVar5[1];
      *piVar5 = 0;
      piVar5[1] = 0;
      *piStack_18 = iVar1;
      piVar5 = (int *)piStack_18[1];
      piStack_18[1] = iVar2;
      if (piVar5 != (int *)0x0) {
        LOCK();
        iVar1 = piVar5[1] + -1;
        piVar5[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar5)();
          LOCK();
          iVar1 = piVar5[2] + -1;
          piVar5[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
      piVar5 = piStack_1c;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar1 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar7 = piVar5 + 2;
          iVar1 = *piVar7 + -1;
          *piVar7 = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
  }
  FUN_00f51870(&piStack_38);
  uStack_8._0_1_ = 0;
  uStack_8._1_3_ = 0;
  piStack_18 = piStack_34;
  piVar5 = piStack_38;
  if (piStack_38 != piStack_34) {
    do {
      piStack_1c = (int *)*piVar5;
      FUN_0054ef60(*param_3 + 0xc0);
      uStack_8._0_1_ = 1;
      puVar6 = (undefined4 *)FUN_00f51060(apppuStack_50);
      pppuVar3 = apppuStack_68[0];
      ppppuVar9 = apppuStack_68;
      if (0xf < uStack_54) {
        ppppuVar9 = (undefined4 ****)apppuStack_68[0];
      }
      puVar8 = puVar6 + 4;
      if (0xf < (uint)puVar6[5]) {
        puVar6 = (undefined4 *)*puVar6;
      }
      cStack_11 = FUN_0055c360(puVar6,*puVar8,ppppuVar9,uStack_58);
      if (0xf < uStack_3c) {
        uVar10 = uStack_3c + 1;
        ppppuVar9 = (undefined4 ****)apppuStack_50[0];
        if (0xfff < uVar10) {
          ppppuVar9 = (undefined4 ****)apppuStack_50[0][-1];
          uVar10 = uStack_3c + 0x24;
          if (0x1f < (uint)((int)apppuStack_50[0] + (-4 - (int)ppppuVar9))) goto LAB_00907002;
        }
        FUN_01674ea0(ppppuVar9,uVar10);
      }
      uStack_40 = 0;
      uStack_3c = 0xf;
      apppuStack_50[0] = (undefined4 ***)((uint)apppuStack_50[0] & 0xffffff00);
      uStack_8._0_1_ = 0;
      if (0xf < uStack_54) {
        uVar10 = uStack_54 + 1;
        ppppuVar9 = (undefined4 ****)pppuVar3;
        if (0xfff < uVar10) {
          ppppuVar9 = (undefined4 ****)pppuVar3[-1];
          uVar10 = uStack_54 + 0x24;
          if (0x1f < (uint)((int)pppuVar3 + (-4 - (int)ppppuVar9))) goto LAB_00907002;
        }
        FUN_01674ea0(ppppuVar9,uVar10);
      }
      if (cStack_11 != '\0') {
        (**(code **)(*piStack_1c + 0xa4))(param_2,param_3);
        goto LAB_00906d8d;
      }
      piVar5 = piVar5 + 1;
    } while (piVar5 != piStack_18);
  }
  if (uVar11 != 0) {
    FUN_005789c0(&DAT_01ee0d28,&LAB_008e0eb0);
    uVar4 = FUN_008e3f20();
    piVar5 = (int *)FUN_008aa140(uVar4);
    if (*piVar5 == 0) {
      uVar4 = FUN_00f516b0();
      piVar7 = (int *)FUN_008a9ba0(auStack_20,uVar4);
      iVar1 = *piVar7;
      iVar2 = piVar7[1];
      *piVar7 = 0;
      piVar7[1] = 0;
      *piVar5 = iVar1;
      piVar7 = (int *)piVar5[1];
      piVar5[1] = iVar2;
      if (piVar7 != (int *)0x0) {
        LOCK();
        iVar1 = piVar7[1] + -1;
        piVar7[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piVar7)();
          LOCK();
          iVar1 = piVar7[2] + -1;
          piVar7[2] = iVar1;
          UNLOCK();
          if (iVar1 == 0) {
            (**(code **)(*piVar7 + 4))();
          }
        }
      }
      piVar5 = piStack_1c;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar1 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar1;
        UNLOCK();
        if (iVar1 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar7 = piVar5 + 2;
          iVar1 = *piVar7;
          *piVar7 = *piVar7 + -1;
          UNLOCK();
          if (iVar1 == 1) {
            (**(code **)(*piVar5 + 4))();
          }
        }
      }
    }
  }
  FUN_00f51870(&piStack_2c);
  uStack_8._0_1_ = 2;
  piStack_1c = piStack_28;
  piVar5 = piStack_2c;
  if (piStack_2c != piStack_28) {
    do {
      piStack_18 = (int *)*piVar5;
      FUN_0054ef60(*param_3 + 0xc0);
      uStack_8._0_1_ = 3;
      puVar8 = (undefined4 *)FUN_00f51060(apppuStack_68);
      uVar11 = uStack_3c;
      pppuVar3 = apppuStack_50[0];
      puVar6 = puVar8 + 4;
      ppppuVar9 = apppuStack_50;
      if (0xf < uStack_3c) {
        ppppuVar9 = (undefined4 ****)apppuStack_50[0];
      }
      if (0xf < (uint)puVar8[5]) {
        puVar8 = (undefined4 *)*puVar8;
      }
      cStack_11 = FUN_0055c360(puVar8,*puVar6,ppppuVar9,uStack_40);
      if (0xf < uStack_54) {
        uVar10 = uStack_54 + 1;
        ppppuVar9 = (undefined4 ****)apppuStack_68[0];
        if (0xfff < uVar10) {
          ppppuVar9 = (undefined4 ****)apppuStack_68[0][-1];
          uVar10 = uStack_54 + 0x24;
          if (0x1f < (uint)((int)apppuStack_68[0] + (-4 - (int)ppppuVar9))) goto LAB_00907002;
        }
        FUN_01674ea0(ppppuVar9,uVar10);
      }
      uStack_58 = 0;
      uStack_54 = 0xf;
      apppuStack_68[0] = (undefined4 ***)((uint)apppuStack_68[0] & 0xffffff00);
      uStack_8._0_1_ = 2;
      if (0xf < uVar11) {
        uVar10 = uVar11 + 1;
        ppppuVar9 = (undefined4 ****)pppuVar3;
        if (0xfff < uVar10) {
          ppppuVar9 = (undefined4 ****)pppuVar3[-1];
          uVar10 = uVar11 + 0x24;
          if (0x1f < (uint)((int)pppuVar3 + (-4 - (int)ppppuVar9))) goto LAB_00907002;
        }
        FUN_01674ea0(ppppuVar9,uVar10);
      }
      if (cStack_11 != '\0') {
        (**(code **)(*piStack_18 + 0xa4))(param_2,param_3);
        if (piStack_2c != (int *)0x0) {
          uVar11 = iStack_24 - (int)piStack_2c & 0xfffffffc;
          piVar5 = piStack_2c;
          if (0xfff < uVar11) {
            piVar5 = (int *)piStack_2c[-1];
            uVar11 = uVar11 + 0x23;
            if (0x1f < (uint)((int)piStack_2c + (-4 - (int)piVar5))) {
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(piVar5,uVar11);
          piStack_2c = (int *)0x0;
          piStack_28 = (int *)0x0;
          iStack_24 = 0;
        }
LAB_00906d8d:
        if (piStack_38 != (int *)0x0) {
          uVar11 = iStack_30 - (int)piStack_38 & 0xfffffffc;
          piVar5 = piStack_38;
          if (0xfff < uVar11) {
            piVar5 = (int *)piStack_38[-1];
            uVar11 = uVar11 + 0x23;
            if (0x1f < (uint)((int)piStack_38 + (-4 - (int)piVar5))) goto LAB_00907002;
          }
          FUN_01674ea0(piVar5,uVar11);
        }
        ExceptionList = pvStack_10;
        return param_2;
      }
      piVar5 = piVar5 + 1;
    } while (piVar5 != piStack_1c);
  }
  *param_2 = 0;
  param_2[1] = 0;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  if (piStack_2c != (int *)0x0) {
    uVar11 = iStack_24 - (int)piStack_2c & 0xfffffffc;
    piVar5 = piStack_2c;
    if (0xfff < uVar11) {
      piVar5 = (int *)piStack_2c[-1];
      uVar11 = uVar11 + 0x23;
      if (0x1f < (uint)((int)piStack_2c + (-4 - (int)piVar5))) goto LAB_00907002;
    }
    FUN_01674ea0(piVar5,uVar11);
    piStack_2c = (int *)0x0;
    piStack_28 = (int *)0x0;
    iStack_24 = 0;
  }
  if (piStack_38 != (int *)0x0) {
    uVar11 = iStack_30 - (int)piStack_38 & 0xfffffffc;
    piVar5 = piStack_38;
    if (0xfff < uVar11) {
      piVar5 = (int *)piStack_38[-1];
      uVar11 = uVar11 + 0x23;
      if (0x1f < (uint)((int)piStack_38 + (-4 - (int)piVar5))) {
LAB_00907002:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar5,uVar11);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15900 ; VA 0x00907010 ; FUN_00907010 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint * FUN_00907010(uint *param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  float *pfVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 *puVar7;
  uint uVar8;
  bool bVar9;
  undefined auStack_70 [20];
  undefined auStack_5c [20];
  undefined auStack_48 [4];
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar1 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c4f08;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  if (DAT_01d6ddc0 != '\0') {
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
    param_1[4] = 0;
    return param_1;
  }
  iVar6 = *param_2;
  if (*(uint *)(iVar6 + 0x54) < 5) {
    uVar8 = 1;
    ExceptionList = &pvStack_10;
    pfVar3 = (float *)FUN_00d81770(&uStack_28);
    iStack_18 = (int)*pfVar3;
    iVar4 = FUN_00d81770(&uStack_28);
    iVar6 = *param_2;
    param_2 = (int *)0x0;
    iStack_14 = (int)*(float *)(iVar4 + 4);
    if (*(int *)(iVar6 + 0x54) == 3) {
      uVar8 = 3;
      iVar4 = FUN_00d81770(&uStack_28);
      iVar6 = *piVar1;
      param_2 = (int *)(int)*(float *)(iVar4 + 8);
    }
    if ((*(int *)(iVar6 + 0x5c) == 0) &&
       (((iVar4 = *(int *)(iVar6 + 0x54), iVar4 == 0 || (iVar4 == 1)) || (iVar4 == 2)))) {
      uVar8 = uVar8 | 4;
    }
    else {
      iVar4 = 0;
      if ((*(int *)(iVar6 + 0x5c) == 2) &&
         (((iVar6 = *(int *)(iVar6 + 0x54), iVar6 == 0 || (iVar6 == 1)) || (iVar6 == 2)))) {
        uVar8 = uVar8 | 8;
        iVar4 = iVar6;
      }
    }
    cVar2 = FUN_0152dbe0(uVar8,iStack_18,iStack_14,param_2,iVar4);
    bVar9 = cVar2 == '\0';
    if (bVar9) {
      piStack_20 = (int *)0x0;
      puVar7 = &uStack_24;
      uStack_30 = 0;
      uStack_2c = 0;
      uStack_28 = 0;
      uStack_24 = 0;
    }
    else {
      puVar7 = &uStack_38;
      piStack_34 = (int *)0x0;
      uStack_44 = _DAT_0192d580;
      uStack_40 = _UNK_0192d584;
      uStack_3c = _UNK_0192d588;
      uStack_38 = _UNK_0192d58c;
    }
    *puVar7 = 0;
    *param_1 = (uint)!bVar9;
    uVar8 = puVar7[1];
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
    param_1[4] = uVar8;
    puVar7[1] = 0;
    if ((bVar9) && (piStack_20 != (int *)0x0)) {
      LOCK();
      iVar6 = piStack_20[2] + -1;
      piStack_20[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piStack_20 + 4))();
      }
    }
    if ((!bVar9) && (piStack_34 != (int *)0x0)) {
      LOCK();
      piVar1 = piStack_34 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piStack_34 + 4))();
        ExceptionList = pvStack_10;
        return param_1;
      }
    }
  }
  else {
    if (((*(uint *)(iVar6 + 0x54) != 8) || (iVar4 = *(int *)(iVar6 + 0x5c), iVar4 == 2)) ||
       (iVar4 == 4)) {
LAB_00907381:
      *param_1 = 0;
      param_1[1] = 0;
      param_1[2] = 0;
      param_1[3] = 0;
      param_1[4] = 0;
      ExceptionList = pvStack_10;
      return param_1;
    }
    ExceptionList = &pvStack_10;
    if (((iVar4 == 2) || (ExceptionList = &pvStack_10, iVar4 == 4)) ||
       ((ExceptionList = &pvStack_10, *(int *)(iVar6 + 0xa8) != 0x11f ||
        (ExceptionList = &pvStack_10, uVar8 = FUN_00d816c0(), (uVar8 & 0xcc0) == 0)))) {
      iVar6 = *param_2;
      if (((*(int *)(iVar6 + 0x54) != 8) || (*(int *)(iVar6 + 0x5c) == 2)) ||
         ((*(int *)(iVar6 + 0x5c) == 4 ||
          ((*(int *)(iVar6 + 0xa8) != 0x70 || (uVar8 = FUN_00d816c0(), (uVar8 & 0xcc0) == 0))))))
      goto LAB_00907381;
      cVar2 = FUN_0152e2c0();
      if (cVar2 == '\0') {
        uVar5 = FUN_008b6b50(auStack_5c);
      }
      else {
        uVar5 = FUN_0090cc40(auStack_70);
      }
      FUN_008ad9c0(uVar5);
      if (cVar2 == '\0') {
        FUN_008ae7d0();
      }
      else {
        FUN_008ae7d0();
      }
    }
    else {
      if (DAT_01d63c48 != '\0') {
        uStack_38 = 0;
        piStack_34 = (int *)&DAT_0000000f;
        auStack_48[0] = 0;
        FUN_005542c0("MicroprofilerShortcutPressed",0x1c);
        uStack_8 = 0;
        FUN_008783f0(auStack_48,1,0);
        uStack_8 = 0xffffffff;
        FUN_005507b0();
      }
      cVar2 = FUN_0152e330();
      if (cVar2 == '\0') {
        uVar5 = FUN_008b6b50(&uStack_44);
      }
      else {
        uVar5 = FUN_0090cc40(&uStack_30);
      }
      FUN_008ad9c0(uVar5);
      if (cVar2 != '\0') {
        FUN_008ae7d0();
        ExceptionList = pvStack_10;
        return param_1;
      }
      FUN_008ae7d0();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 15901 ; VA 0x00907070 ; FUN_00907070 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint * FUN_00907070(void)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  char cVar6;
  float *pfVar7;
  int iVar8;
  int iVar9;
  undefined4 uVar10;
  int iVar11;
  undefined4 *puVar12;
  int unaff_EBP;
  uint uVar13;
  uint *puVar14;
  bool bVar15;
  
  piVar2 = *(int **)(unaff_EBP + 0xc);
  iVar11 = *piVar2;
  if (*(uint *)(iVar11 + 0x54) < 5) {
    uVar13 = 1;
    pfVar7 = (float *)FUN_00d81770(unaff_EBP + -0x24);
    *(int *)(unaff_EBP + -0x14) = (int)*pfVar7;
    iVar8 = FUN_00d81770(unaff_EBP + -0x24);
    iVar11 = *piVar2;
    *(undefined4 *)(unaff_EBP + 0xc) = 0;
    iVar9 = *(int *)(iVar11 + 0x54);
    *(int *)(unaff_EBP + -0x10) = (int)*(float *)(iVar8 + 4);
    if (iVar9 == 3) {
      uVar13 = 3;
      iVar9 = FUN_00d81770(unaff_EBP + -0x24);
      iVar11 = *piVar2;
      *(int *)(unaff_EBP + 0xc) = (int)*(float *)(iVar9 + 8);
    }
    if ((*(int *)(iVar11 + 0x5c) == 0) &&
       (((iVar9 = *(int *)(iVar11 + 0x54), iVar9 == 0 || (iVar9 == 1)) || (iVar9 == 2)))) {
      uVar13 = uVar13 | 4;
    }
    else {
      iVar9 = 0;
      if ((*(int *)(iVar11 + 0x5c) == 2) &&
         (((iVar11 = *(int *)(iVar11 + 0x54), iVar11 == 0 || (iVar11 == 1)) || (iVar11 == 2)))) {
        uVar13 = uVar13 | 8;
        iVar9 = iVar11;
      }
    }
    cVar6 = FUN_0152dbe0(uVar13,*(undefined4 *)(unaff_EBP + -0x14),
                         *(undefined4 *)(unaff_EBP + -0x10),*(undefined4 *)(unaff_EBP + 0xc),iVar9);
    uVar5 = _UNK_0192d58c;
    uVar4 = _UNK_0192d588;
    uVar3 = _UNK_0192d584;
    uVar10 = _DAT_0192d580;
    bVar15 = cVar6 == '\0';
    if (bVar15) {
      *(undefined4 *)(unaff_EBP + -0x1c) = 0;
      puVar12 = (undefined4 *)(unaff_EBP + -0x20);
      *(undefined4 *)(unaff_EBP + -0x2c) = 0;
      *(undefined4 *)(unaff_EBP + -0x28) = 0;
      *(undefined4 *)(unaff_EBP + -0x24) = 0;
      *(undefined4 *)(unaff_EBP + -0x20) = 0;
    }
    else {
      puVar12 = (undefined4 *)(unaff_EBP + -0x34);
      *(undefined4 *)(unaff_EBP + -0x30) = 0;
      *(undefined4 *)(unaff_EBP + -0x40) = uVar10;
      *(undefined4 *)(unaff_EBP + -0x3c) = uVar3;
      *(undefined4 *)(unaff_EBP + -0x38) = uVar4;
      *(undefined4 *)(unaff_EBP + -0x34) = uVar5;
    }
    puVar14 = *(uint **)(unaff_EBP + 8);
    *puVar12 = 0;
    *puVar14 = (uint)!bVar15;
    uVar13 = puVar12[1];
    puVar14[1] = 0;
    puVar14[2] = 0;
    puVar14[3] = 0;
    puVar14[4] = uVar13;
    puVar12[1] = 0;
    if ((bVar15) && (piVar2 = *(int **)(unaff_EBP + -0x1c), piVar2 != (int *)0x0)) {
      LOCK();
      iVar11 = piVar2[2] + -1;
      piVar2[2] = iVar11;
      UNLOCK();
      if (iVar11 == 0) {
        (**(code **)(*piVar2 + 4))();
      }
    }
    if ((!bVar15) && (piVar2 = *(int **)(unaff_EBP + -0x30), piVar2 != (int *)0x0)) {
      LOCK();
      piVar1 = piVar2 + 2;
      iVar11 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar11 == 1) {
        (**(code **)(*piVar2 + 4))();
        ExceptionList = *(void **)(unaff_EBP + -0xc);
        return puVar14;
      }
    }
  }
  else {
    if (((*(uint *)(iVar11 + 0x54) != 8) || (iVar9 = *(int *)(iVar11 + 0x5c), iVar9 == 2)) ||
       (iVar9 == 4)) {
LAB_00907381:
      puVar14 = *(uint **)(unaff_EBP + 8);
      ExceptionList = *(void **)(unaff_EBP + -0xc);
      *puVar14 = 0;
      puVar14[1] = 0;
      puVar14[2] = 0;
      puVar14[3] = 0;
      puVar14[4] = 0;
      return puVar14;
    }
    if (((iVar9 == 2) || (iVar9 == 4)) ||
       ((*(int *)(iVar11 + 0xa8) != 0x11f || (uVar13 = FUN_00d816c0(), (uVar13 & 0xcc0) == 0)))) {
      iVar11 = *piVar2;
      if (((*(int *)(iVar11 + 0x54) != 8) || (*(int *)(iVar11 + 0x5c) == 2)) ||
         ((*(int *)(iVar11 + 0x5c) == 4 ||
          ((*(int *)(iVar11 + 0xa8) != 0x70 || (uVar13 = FUN_00d816c0(), (uVar13 & 0xcc0) == 0))))))
      goto LAB_00907381;
      cVar6 = FUN_0152e2c0();
      if (cVar6 == '\0') {
        uVar10 = FUN_008b6b50(unaff_EBP + -0x58);
      }
      else {
        uVar10 = FUN_0090cc40(unaff_EBP + -0x6c);
      }
      puVar14 = *(uint **)(unaff_EBP + 8);
      FUN_008ad9c0(uVar10);
      if (cVar6 == '\0') {
        FUN_008ae7d0();
      }
      else {
        FUN_008ae7d0();
      }
    }
    else {
      if (DAT_01d63c48 != '\0') {
        *(undefined4 *)(unaff_EBP + -0x34) = 0;
        *(undefined4 *)(unaff_EBP + -0x30) = 0xf;
        *(undefined *)(unaff_EBP + -0x44) = 0;
        FUN_005542c0("MicroprofilerShortcutPressed",0x1c);
        *(undefined4 *)(unaff_EBP + -4) = 0;
        FUN_008783f0(unaff_EBP + -0x44,1,0);
        *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
        FUN_005507b0();
      }
      cVar6 = FUN_0152e330();
      if (cVar6 == '\0') {
        uVar10 = FUN_008b6b50(unaff_EBP + -0x40);
      }
      else {
        uVar10 = FUN_0090cc40(unaff_EBP + -0x2c);
      }
      puVar14 = *(uint **)(unaff_EBP + 8);
      FUN_008ad9c0(uVar10);
      if (cVar6 != '\0') {
        FUN_008ae7d0();
        ExceptionList = *(void **)(unaff_EBP + -0xc);
        return puVar14;
      }
      FUN_008ae7d0();
    }
  }
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  return puVar14;
}



/* FUNCTION 15902 ; VA 0x009073c0 ; FUN_009073c0 */

/* WARNING: Removing unreachable block (ram,0x0090751d) */
/* WARNING: Removing unreachable block (ram,0x00907539) */
/* WARNING: Removing unreachable block (ram,0x0090760a) */
/* WARNING: Removing unreachable block (ram,0x0090755b) */
/* WARNING: Removing unreachable block (ram,0x00907577) */
/* WARNING: Removing unreachable block (ram,0x00907582) */
/* WARNING: Removing unreachable block (ram,0x0090758c) */
/* WARNING: Removing unreachable block (ram,0x0090759c) */

void __fastcall FUN_009073c0(int param_1)

{
  uint *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  int *piVar8;
  undefined8 uVar9;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c4f53;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar4 = FUN_01675290(DAT_01ee04dc);
  uStack_8 = 0;
  if (DAT_01d6514b != '\0') {
    FUN_016774b0(DAT_01d6514b,"Process shutdown tasks start",0);
  }
  iVar3 = *(int *)(param_1 + 0x140);
  piVar8 = (int *)(param_1 + 0x130);
  iStack_14 = 0;
  if (0 < iVar3) {
    puVar1 = (uint *)(param_1 + 0x144);
    do {
      do {
        LOCK();
        uVar7 = *puVar1;
        *puVar1 = *puVar1 | 1;
        UNLOCK();
      } while ((uVar7 & 1) != 0);
      uStack_8._0_1_ = 2;
      if (*(int *)(param_1 + 0x140) == 0) {
        *puVar1 = 0;
        break;
      }
      if ((piVar8 == (int *)0x0) || ((int *)*piVar8 == (int *)0x0)) {
        iVar5 = 0;
      }
      else {
        iVar5 = *(int *)*piVar8;
      }
      iVar5 = *(int *)(*(int *)(iVar5 + 4) +
                      (*(int *)(iVar5 + 8) - 1U & *(uint *)(param_1 + 0x13c)) * 4);
      FUN_008eb2b0(iVar5);
      FUN_008eb2b0(iVar5 + 0x20);
      FUN_008c3510();
      piVar2 = (int *)(param_1 + 0x140);
      *piVar2 = *piVar2 + -1;
      if (*piVar2 == 0) {
        *(undefined4 *)(param_1 + 0x13c) = 0;
        uVar7 = 0;
      }
      else {
        *(int *)(param_1 + 0x13c) = *(int *)(param_1 + 0x13c) + 1;
        uVar7 = *(uint *)(param_1 + 0x13c);
      }
      if (*(int *)(param_1 + 0x140) == 0) {
        uVar9 = 0;
      }
      else {
        puVar6 = (undefined4 *)*piVar8;
        if (puVar6 != (undefined4 *)0x0) {
          puVar6 = (undefined4 *)*puVar6;
        }
        uVar9 = *(undefined8 *)(*(int *)(puVar6[1] + (puVar6[2] - 1 & uVar7) * 4) + 0x48);
      }
      *(undefined8 *)(param_1 + 0x148) = uVar9;
      *puVar1 = 0;
      iStack_14 = iStack_14 + 1;
    } while (iStack_14 < iVar3);
  }
  uStack_8._0_1_ = 1;
  if (DAT_01d6514b != '\0') {
    FUN_016774b0(DAT_01d6514b,"Process shutdown tasks finish",0);
  }
  FUN_008c3510();
  uStack_8 = 7;
  FUN_01675290(uVar4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15903 ; VA 0x00907620 ; FUN_00907620 */

void __fastcall FUN_00907620(int param_1)

{
  uint *puVar1;
  int *piVar2;
  undefined uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  int *piVar8;
  uint *puVar9;
  int iVar10;
  undefined8 uVar11;
  undefined auStack_158 [72];
  undefined8 uStack_110;
  undefined auStack_108 [72];
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  uint auStack_a0 [2];
  undefined auStack_98 [24];
  undefined4 uStack_80;
  char cStack_60;
  int iStack_58;
  int iStack_54;
  uint *puStack_50;
  uint *puStack_4c;
  undefined4 uStack_48;
  int iStack_44;
  int iStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int iStack_30;
  int *piStack_2c;
  uint *puStack_28;
  int iStack_24;
  int *piStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c4ff5;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  uStack_38 = FUN_01675290(DAT_01ee04dc);
  iStack_8._0_1_ = 0;
  iStack_8._1_3_ = 0;
  if (DAT_01d6514b != '\0') {
    FUN_016774b0(DAT_01d6514b,"Process tasks start",0);
  }
  if (DAT_01d63604 == '\0') {
    auStack_a0[0] = 0;
    uStack_80 = 0;
    iStack_18 = *(int *)(param_1 + 0x140);
    piVar8 = (int *)(param_1 + 0x130);
    iStack_14 = 0;
    if (0 < iStack_18) {
      puVar1 = (uint *)(param_1 + 0x144);
      puVar9 = puVar1;
      puStack_28 = puVar1;
      do {
        do {
          LOCK();
          uVar7 = *puVar9;
          *puVar9 = *puVar9 | 1;
          UNLOCK();
        } while ((uVar7 & 1) != 0);
        iStack_8._0_1_ = 10;
        if (piVar8[4] == 0) {
          *puVar9 = 0;
          break;
        }
        if ((piVar8 == (int *)0x0) || ((int *)*piVar8 == (int *)0x0)) {
          iVar5 = 0;
        }
        else {
          iVar5 = *(int *)*piVar8;
        }
        iVar5 = *(int *)(*(int *)(iVar5 + 4) + (*(int *)(iVar5 + 8) - 1U & piVar8[3]) * 4);
        FUN_008eb2b0(iVar5);
        FUN_008eb2b0(iVar5 + 0x20);
        iVar10 = iStack_1c;
        cStack_60 = *(char *)(iVar5 + 0x40);
        piVar8 = (int *)(iStack_1c + 0x130);
        FUN_008c3510();
        piVar2 = (int *)(iVar10 + 0x140);
        *piVar2 = *piVar2 + -1;
        if (*piVar2 == 0) {
          *(undefined4 *)(iVar10 + 0x13c) = 0;
          uVar7 = 0;
        }
        else {
          *(int *)(iVar10 + 0x13c) = *(int *)(iVar10 + 0x13c) + 1;
          uVar7 = *(uint *)(iVar10 + 0x13c);
        }
        if (*(int *)(iVar10 + 0x140) == 0) {
          uVar11 = 0;
        }
        else {
          puVar6 = (undefined4 *)*piVar8;
          if (puVar6 != (undefined4 *)0x0) {
            puVar6 = (undefined4 *)*puVar6;
          }
          uVar11 = *(undefined8 *)(*(int *)(puVar6[1] + (puVar6[2] - 1 & uVar7) * 4) + 0x48);
        }
        *(undefined8 *)(iVar10 + 0x148) = uVar11;
        iStack_8._0_1_ = 9;
        uVar3 = (undefined)iStack_8;
        iStack_8._0_1_ = 9;
        *puVar9 = 0;
        if ((cStack_60 == '\0') &&
           (puVar9 = puStack_28, *(char *)(*(int *)(iStack_1c + 0x11c) + 0x2fc) != '\0')) {
          FUN_008e8ca0(auStack_a0);
          iStack_8._0_1_ = 0xf;
          FUN_01682800(&uStack_110);
          do {
            LOCK();
            uVar7 = *puVar1;
            *puVar1 = *puVar1 | 1;
            UNLOCK();
          } while ((uVar7 & 1) != 0);
          iStack_8._0_1_ = 0x11;
          if (*(int *)(iVar10 + 0x140) == 0) {
            *(undefined8 *)(iVar10 + 0x148) = uStack_110;
          }
          puStack_50 = puVar1;
          FUN_00907d40(auStack_158);
          *puVar1 = 0;
          FUN_008c3510();
          puVar9 = puStack_28;
        }
        else {
          iStack_8._0_1_ = uVar3;
          FUN_00587490(&iStack_24);
          iStack_8._0_1_ = 0xb;
          if (iStack_24 != 0) {
            uStack_34 = FUN_01675290(DAT_01ee04dc);
            iStack_8._0_1_ = 0xc;
            uVar3 = (undefined)iStack_8;
            iStack_8._0_1_ = 0xc;
            if (auStack_a0[0] == 0) {
              iStack_8._0_1_ = uVar3;
              uVar4 = FUN_0054fda0();
              iStack_8 = CONCAT31(iStack_8._1_3_,0xd);
                    /* WARNING: Subroutine does not return */
              FUN_0054e5e0(uVar4);
            }
            (**(code **)((auStack_a0[0] & 0xfffffffe) + 4))(auStack_98,iStack_24);
            iStack_8._0_1_ = 0xe;
            FUN_01675290(uStack_34);
          }
          if (piStack_20 != (int *)0x0) {
            LOCK();
            iVar5 = piStack_20[1] + -1;
            piStack_20[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*piStack_20)();
              LOCK();
              iVar5 = piStack_20[2] + -1;
              piStack_20[2] = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)(*piStack_20 + 4))();
              }
            }
          }
        }
        iStack_14 = iStack_14 + 1;
      } while (iStack_14 < iStack_18);
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_008c3510();
  }
  else {
    FUN_009028a0(&iStack_44);
    iStack_8._0_1_ = 1;
    iStack_18 = iStack_44 + ((iStack_40 - iStack_44) / 0x48) * 0x48;
    iStack_14 = iStack_18;
    if (iStack_44 != iStack_18) {
      iVar10 = iStack_44 + 0x48;
      iVar5 = param_1;
      do {
        if ((*(char *)(iVar10 + -8) == '\0') && (*(char *)(*(int *)(iVar5 + 0x11c) + 0x2fc) != '\0')
           ) {
          if ((iVar10 + -0x48 != iVar10) && (iVar10 != iStack_14)) {
            FUN_008de0a0(iVar10 + -0x48,iVar10);
            FUN_008de0a0(iVar10,iStack_14);
            FUN_008de0a0(iVar10 + -0x48,iStack_14);
          }
          iStack_18 = iStack_18 + -0x48;
        }
        else {
          FUN_00587490(&iStack_30);
          iStack_8._0_1_ = 2;
          if (iStack_30 != 0) {
            uVar4 = FUN_01675290(DAT_01ee04dc);
            iStack_8._0_1_ = 3;
            uVar3 = (undefined)iStack_8;
            iStack_8._0_1_ = 3;
            uStack_48 = uVar4;
            if (*(uint *)(iVar10 + -0x48) == 0) {
              iStack_8._0_1_ = uVar3;
              uVar4 = FUN_0054fda0();
              iStack_8 = CONCAT31(iStack_8._1_3_,4);
                    /* WARNING: Subroutine does not return */
              FUN_0054e5e0(uVar4);
            }
            (**(code **)((*(uint *)(iVar10 + -0x48) & 0xfffffffe) + 4))(iVar10 + -0x40,iStack_30);
            iStack_8._0_1_ = 5;
            FUN_01675290(uVar4);
          }
          piVar8 = piStack_2c;
          iStack_8._0_1_ = 1;
          if (piStack_2c != (int *)0x0) {
            LOCK();
            iVar5 = piStack_2c[1] + -1;
            piStack_2c[1] = iVar5;
            UNLOCK();
            if (iVar5 == 0) {
              (**(code **)*piStack_2c)();
              LOCK();
              piVar2 = piVar8 + 2;
              iVar5 = *piVar2 + -1;
              *piVar2 = iVar5;
              UNLOCK();
              if (iVar5 == 0) {
                (**(code **)(*piVar8 + 4))();
              }
            }
          }
          iVar10 = iVar10 + 0x48;
        }
        iVar5 = iStack_1c;
      } while (iVar10 + -0x48 != iStack_18);
    }
    iStack_54 = (iStack_14 - iStack_18) / 0x48;
    iStack_58 = iStack_18;
    if (iStack_54 != 0) {
      puStack_4c = (uint *)(param_1 + 0x144);
      do {
        LOCK();
        uVar7 = *puStack_4c;
        *puStack_4c = *puStack_4c | 1;
        UNLOCK();
      } while ((uVar7 & 1) != 0);
      iStack_14 = *(int *)(param_1 + 0x140);
      iVar5 = iStack_18 + iStack_54 * 0x48;
      iStack_8._0_1_ = 6;
      iStack_1c = iVar5;
      for (; iStack_18 != iVar5; iStack_18 = iStack_18 + 0x48) {
        FUN_008e8ca0(iStack_18);
        iStack_8._0_1_ = 7;
        FUN_01682800(&uStack_c0);
        uVar7 = *(uint *)(param_1 + 0x138);
        iStack_8 = CONCAT31(iStack_8._1_3_,8);
        if (uVar7 <= *(int *)(param_1 + 0x140) + 1U) {
          FUN_008edde0(1);
          uVar7 = *(uint *)(param_1 + 0x138);
        }
        uVar7 = uVar7 - 1 & *(uint *)(param_1 + 0x13c);
        *(uint *)(param_1 + 0x13c) = uVar7;
        uVar7 = *(int *)(param_1 + 0x138) - 1U & *(int *)(param_1 + 0x140) + uVar7;
        iVar10 = *(int *)(param_1 + 0x134);
        if (*(int *)(iVar10 + uVar7 * 4) == 0) {
          uVar4 = FUN_01674e20(0x50);
          *(undefined4 *)(*(int *)(param_1 + 0x134) + uVar7 * 4) = uVar4;
          iVar10 = *(int *)(param_1 + 0x134);
        }
        iVar10 = *(int *)(iVar10 + uVar7 * 4);
        FUN_008e8ca0(auStack_108);
        *(undefined4 *)(iVar10 + 0x48) = uStack_c0;
        *(undefined4 *)(iVar10 + 0x4c) = uStack_bc;
        *(int *)(param_1 + 0x140) = *(int *)(param_1 + 0x140) + 1;
        iStack_8._0_1_ = 6;
        FUN_008c3510();
      }
      if (iStack_14 == 0) {
        if (((int *)(param_1 + 0x130) == (int *)0x0) ||
           (piVar8 = *(int **)(param_1 + 0x130), piVar8 == (int *)0x0)) {
          iVar5 = 0;
        }
        else {
          iVar5 = *piVar8;
        }
        *(undefined8 *)(param_1 + 0x148) =
             *(undefined8 *)
              (*(int *)(*(int *)(iVar5 + 4) +
                       (*(int *)(iVar5 + 8) - 1U & *(uint *)(param_1 + 0x13c)) * 4) + 0x48);
      }
      *(undefined4 *)(param_1 + 0x144) = 0;
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_008ea690();
  }
  if (DAT_01d6514b != '\0') {
    FUN_016774b0(DAT_01d6514b,"Process tasks finish",0);
  }
  iStack_8 = 0x12;
  FUN_01675290(uStack_38);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15904 ; VA 0x00907bb0 ; FUN_00907bb0 */

void __thiscall FUN_00907bb0(int param_1,undefined4 *param_2)

{
  uint *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  int iVar7;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_0179e768;
  pvStack_10 = ExceptionList;
  puVar1 = (uint *)(param_1 + 0x14);
  ExceptionList = &pvStack_10;
  do {
    LOCK();
    uVar5 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
    uStack_8 = (uint)((uVar5 & 1) != 0);
  } while (uStack_8 != 0);
  uVar5 = *(uint *)(param_1 + 0xc);
  if (((uVar5 + *(int *)(param_1 + 0x10) & 1) == 0) &&
     (*(uint *)(param_1 + 8) <= *(int *)(param_1 + 0x10) + 2U >> 1)) {
    FUN_006176e0(1);
    uVar5 = *(uint *)(param_1 + 0xc);
  }
  uVar5 = *(int *)(param_1 + 8) * 2 - 1U & uVar5;
  *(uint *)(param_1 + 0xc) = uVar5;
  uVar5 = *(int *)(param_1 + 0x10) + uVar5;
  iVar4 = (*(int *)(param_1 + 8) - 1U & uVar5 >> 1) * 4;
  iVar7 = *(int *)(param_1 + 4);
  if (*(int *)(iVar7 + iVar4) == 0) {
    uVar6 = FUN_01674e20(0x10);
    *(undefined4 *)(iVar4 + *(int *)(param_1 + 4)) = uVar6;
    iVar7 = *(int *)(param_1 + 4);
  }
  iVar4 = *(int *)(iVar4 + iVar7);
  uVar5 = uVar5 & 1;
  *(undefined4 *)(iVar4 + uVar5 * 8) = 0;
  *(undefined4 *)(iVar4 + 4 + uVar5 * 8) = 0;
  puVar3 = (undefined4 *)(iVar4 + uVar5 * 8);
  if (param_2[1] != 0) {
    LOCK();
    piVar2 = (int *)(param_2[1] + 4);
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  *puVar3 = *param_2;
  puVar3[1] = param_2[1];
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
  *puVar1 = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15905 ; VA 0x00907ca0 ; FUN_00907ca0 */

void __thiscall FUN_00907ca0(int param_1,undefined4 param_2)

{
  uint *puVar1;
  uint uVar2;
  undefined auStack_60 [72];
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5018;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_008e8ca0(param_2);
  uStack_8 = 0;
  FUN_01682800(&uStack_18);
  puVar1 = (uint *)(param_1 + 0x14);
  do {
    LOCK();
    uVar2 = *puVar1;
    *puVar1 = *puVar1 | 1;
    UNLOCK();
  } while ((uVar2 & 1) != 0);
  uStack_8 = 2;
  if (*(int *)(param_1 + 0x10) == 0) {
    *(undefined8 *)(param_1 + 0x18) = uStack_18;
  }
  FUN_00907d40(auStack_60);
  *puVar1 = 0;
  FUN_008c3510();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15906 ; VA 0x00907d40 ; FUN_00907d40 */

void __thiscall FUN_00907d40(int param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  
  uVar4 = *(uint *)(param_1 + 8);
  if (uVar4 <= *(int *)(param_1 + 0x10) + 1U) {
    FUN_008edde0(1);
    uVar4 = *(uint *)(param_1 + 8);
  }
  *(uint *)(param_1 + 0xc) = *(uint *)(param_1 + 0xc) & uVar4 - 1;
  uVar4 = *(int *)(param_1 + 0x10) + *(int *)(param_1 + 0xc) & *(int *)(param_1 + 8) - 1U;
  iVar3 = *(int *)(param_1 + 4);
  iVar1 = uVar4 * 4;
  if (*(int *)(iVar3 + uVar4 * 4) == 0) {
    uVar2 = FUN_01674e20(0x50);
    *(undefined4 *)(iVar1 + *(int *)(param_1 + 4)) = uVar2;
    iVar3 = *(int *)(param_1 + 4);
  }
  iVar1 = *(int *)(iVar1 + iVar3);
  FUN_008e8ca0(param_2);
  *(undefined4 *)(iVar1 + 0x48) = *(undefined4 *)(param_2 + 0x48);
  *(undefined4 *)(iVar1 + 0x4c) = *(undefined4 *)(param_2 + 0x4c);
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
  return;
}



/* FUNCTION 15907 ; VA 0x00907dc0 ; FUN_00907dc0 */

void __thiscall FUN_00907dc0(int param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  puVar1 = *(undefined4 **)(param_1 + 4);
  if (*(undefined4 **)(param_1 + 8) != puVar1) {
    puVar1[4] = 0;
    puVar1[5] = 0;
    uVar2 = param_2[1];
    uVar3 = param_2[2];
    uVar4 = param_2[3];
    *puVar1 = *param_2;
    puVar1[1] = uVar2;
    puVar1[2] = uVar3;
    puVar1[3] = uVar4;
    *(undefined8 *)(puVar1 + 4) = *(undefined8 *)(param_2 + 4);
    param_2[4] = 0;
    param_2[5] = 0xf;
    *(undefined *)param_2 = 0;
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0x18;
    return;
  }
  FUN_008dd570(puVar1,param_2);
  return;
}



/* FUNCTION 15908 ; VA 0x00907e20 ; FUN_00907e20 */

void __thiscall
FUN_00907e20(int param_1,uint param_2,undefined4 param_3,uint param_4,uint param_5,uint param_6,
            uint param_7,undefined8 param_8)

{
  uint *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c5038;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01d5a508 != '\0') {
    puVar1 = *(uint **)(param_1 + 0x280);
    if (*(uint **)(param_1 + 0x284) == puVar1) {
      ExceptionList = &pvStack_10;
      FUN_008dd140(puVar1,&param_2);
    }
    else {
      ExceptionList = &pvStack_10;
      *puVar1 = 0;
      if (param_2 != 0) {
        *puVar1 = param_2;
        if ((param_2 & 1) != 0) {
          puVar1[2] = param_4;
          puVar1[3] = param_5;
          puVar1[4] = param_6;
          puVar1[5] = param_7;
          *(undefined8 *)(puVar1 + 6) = param_8;
          *(int *)(param_1 + 0x280) = *(int *)(param_1 + 0x280) + 0x20;
          goto LAB_00907eb4;
        }
        (**(code **)(param_2 & 0xfffffffe))(&param_4,puVar1 + 2,0);
      }
      *(int *)(param_1 + 0x280) = *(int *)(param_1 + 0x280) + 0x20;
    }
  }
LAB_00907eb4:
  uStack_8 = 1;
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_2 & 0xfffffffe))(&param_4,&param_4,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15909 ; VA 0x00907ef0 ; FUN_00907ef0 */

int FUN_00907ef0(int param_1,int param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int iStack_18;
  char cStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c5070;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (*(int *)(param_1 + 0x10) == 0) {
    ExceptionList = &pvStack_10;
    FUN_01531f50();
  }
  FUN_0054ef60();
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  uStack_8._0_1_ = 1;
  FUN_008dd0c0();
  FUN_008ddc20(&iStack_18,0);
  uStack_8._0_1_ = 0;
  iVar3 = FUN_0056cac0();
  if ((cStack_14 == '\0') && (iVar3 = *(int *)(iStack_18 + 0x28), iVar3 != param_2)) {
    FUN_01531f50();
    FUN_0054ef60();
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 2;
    FUN_008dd0c0();
    FUN_008ddc20(&iStack_18,0);
    uStack_8._0_1_ = 0;
    iVar3 = FUN_0056cac0();
  }
  if (DAT_01d656d0 != '\0') {
    if (param_3 != (int *)0x0) {
      LOCK();
      param_3[1] = param_3[1] + 1;
      UNLOCK();
    }
    uStack_8._0_1_ = 3;
    FUN_0054ef60(param_1);
    uStack_8._0_1_ = 0;
    iVar3 = FUN_008ec720();
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar1 = param_3 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      iVar3 = (**(code **)*param_3)();
      LOCK();
      piVar1 = param_3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        iVar3 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 15910 ; VA 0x00908080 ; FUN_00908080 */

undefined4 __thiscall FUN_00908080(int param_1,int param_2)

{
  if (*(int *)(param_2 + 0xa0) == param_1) {
    if (*(int *)(param_2 + 0xa0) != 0) {
      if (*(undefined4 **)(param_2 + 0xa4) != (undefined4 *)0x0) {
        **(undefined4 **)(param_2 + 0xa4) = *(undefined4 *)(param_2 + 0x9c);
      }
      if (*(int *)(param_2 + 0x9c) != 0) {
        *(undefined4 *)(*(int *)(param_2 + 0x9c) + 0xa4) = *(undefined4 *)(param_2 + 0xa4);
      }
      **(int **)(param_2 + 0xa0) = **(int **)(param_2 + 0xa0) + -1;
      *(undefined4 *)(param_2 + 0x9c) = 0;
      *(undefined4 *)(param_2 + 0xa4) = 0;
      *(undefined4 *)(param_2 + 0xa0) = 0;
    }
    return 1;
  }
  return 0;
}



/* FUNCTION 15911 ; VA 0x00908100 ; FUN_00908100 */

void __thiscall FUN_00908100(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  *(undefined4 *)(param_1 + 0x1d4) = param_3;
  FUN_00f69470();
  uStack_c = 0;
  uStack_8 = 0;
  (**(code **)(**(int **)(param_1 + 0x1c0) + 0x24))(param_2,&uStack_c);
  *(undefined4 *)(param_1 + 0x1d4) = 0;
  return;
}



/* FUNCTION 15912 ; VA 0x00908150 ; FUN_00908150 */

void __thiscall FUN_00908150(int *param_1,int param_2,int param_3)

{
  int *piVar1;
  char cVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  char cVar6;
  int *piVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined8 uVar17;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5094;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0628) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ee0628), cVar3 = DAT_01d7ad48,
     DAT_01ee0628 == -1)) {
    uStack_8 = 0;
    uVar17 = FUN_0152dab0("Render","Pass2d",0xffffffff);
    if ((cVar3 != '\0') && (DAT_01d7ad40 != '\0')) {
      FUN_01532a30(uVar17);
    }
    uStack_8 = 0xffffffff;
    DAT_01ee0620 = (int)uVar17;
    DAT_01ee0624 = (int)((ulonglong)uVar17 >> 0x20);
    FUN_016f37bf(&DAT_01ee0628);
  }
  uVar5 = DAT_01ee0624;
  uVar4 = DAT_01ee0620;
  cVar3 = DAT_01d7ad48;
  uVar17 = FUN_01532c80(DAT_01ee0620,DAT_01ee0624);
  uStack_8 = 1;
  if (((*(char *)((int)param_1 + 0x1dd) == '\0') || (param_2 == 0)) || (param_3 == 0))
  goto LAB_0090830e;
  piVar1 = param_1 + 3;
  if (piVar1 == (int *)0x0) {
LAB_00908212:
    uVar13 = 0;
    uVar14 = 0;
    uVar15 = 0;
    uVar16 = 0;
  }
  else {
    piVar7 = (int *)FUN_00636b00();
    iVar8 = *piVar7;
    if (iVar8 == 0) goto LAB_00908212;
    uVar13 = *(undefined4 *)(iVar8 + 0xf8);
    uVar14 = *(undefined4 *)(iVar8 + 0xfc);
    uVar15 = *(undefined4 *)(iVar8 + 0x100);
    uVar16 = *(undefined4 *)(iVar8 + 0x104);
  }
  *(undefined4 *)(param_2 + 4) = uVar13;
  *(undefined4 *)(param_2 + 8) = uVar14;
  *(undefined4 *)(param_2 + 0xc) = uVar15;
  *(undefined4 *)(param_2 + 0x10) = uVar16;
  (**(code **)(*(int *)(param_1[0x6e] + 0x58) + 0x10))(param_2);
  piVar7 = (int *)FUN_00636b00();
  cVar2 = *(char *)(*piVar7 + 0xe4);
  if (*(char *)(*piVar7 + 0xe5) != '\0') {
    iVar8 = FUN_0097bfc0(piVar1);
    cVar6 = FUN_00983210(piVar1);
    if ((cVar6 == '\0') && (iVar8 != 0)) {
      uVar12 = 0;
      iVar9 = FUN_005d6c30();
      if (iVar9 != 0) {
        do {
          iVar9 = *(int *)(**(int **)(iVar8 + 0x2c) + uVar12 * 8);
          if ((iVar9 != 0) &&
             (iVar9 = *(int *)(iVar9 + 0xc), iVar10 = FUN_00b56e90(),
             (uint)*(ushort *)(iVar9 + 0x1d8) - (uint)*(ushort *)(iVar10 + 0x1d8) <=
             (uint)*(ushort *)(iVar10 + 0x1da))) {
            FUN_00b608a0(param_2);
          }
          uVar12 = uVar12 + 1;
          uVar11 = FUN_005d6c30();
        } while (uVar12 < uVar11);
      }
    }
    else {
      FUN_00b60d60(param_2);
    }
  }
  if (cVar2 != '\0') {
    FUN_00b608a0(param_2);
    if (*(char *)(param_1 + 0x73) == '\0') {
      FUN_008b3420();
      FUN_00f30a00(param_2);
    }
    (**(code **)(*param_1 + 0x1c))(param_2);
  }
LAB_0090830e:
  uStack_8 = 2;
  FUN_0152dda0(uVar4,uVar5,uVar17);
  if ((cVar3 != '\0') && (DAT_01d7ad40 != '\0')) {
    FUN_01532d10(uVar4,uVar5,uVar17);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15913 ; VA 0x00908400 ; FUN_00908400 */

void __thiscall FUN_00908400(int param_1,int *param_2)

{
  int iVar1;
  code *pcVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  char cVar8;
  int *piVar9;
  int iVar10;
  undefined4 uVar11;
  undefined8 uVar12;
  undefined8 uVar13;
  int iStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5104;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  ExceptionList = &pvStack_10;
  if ((*(int *)(iVar1 + 0x34) < DAT_01ee0638) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ee0638), cVar3 = DAT_01d7ad48,
     DAT_01ee0638 == -1)) {
    uStack_8 = 0;
    uVar12 = FUN_0152dab0("Render","Pass3dAdorn",0xffffffff);
    if ((cVar3 != '\0') && (DAT_01d7ad40 != '\0')) {
      FUN_01532a30(uVar12);
    }
    uStack_8 = 0xffffffff;
    DAT_01ee0630 = (int)uVar12;
    DAT_01ee0634 = (int)((ulonglong)uVar12 >> 0x20);
    FUN_016f37bf(&DAT_01ee0638);
  }
  uVar5 = DAT_01ee0634;
  uVar4 = DAT_01ee0630;
  cVar3 = DAT_01d7ad48;
  uVar12 = FUN_01532c80(DAT_01ee0630,DAT_01ee0634);
  uStack_8 = 1;
  if ((*(char *)(param_1 + 0x1dd) != '\0') &&
     (*(int *)(param_1 + 0x1d0) = *(int *)(param_1 + 0x1d0) + 1, param_2 != (int *)0x0)) {
    if ((*(int *)(iVar1 + 0x34) < DAT_01ee0648) && (FUN_016f3809(&DAT_01ee0648), DAT_01ee0648 == -1)
       ) {
      uStack_8._0_1_ = 2;
      uVar13 = FUN_0152dab0("Render","RenderWorkspaceAdorns",0xffffffff);
      DAT_01ee0644 = (undefined4)((ulonglong)uVar13 >> 0x20);
      DAT_01ee0640 = (undefined4)uVar13;
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_016f37bf(&DAT_01ee0648);
    }
    uVar7 = DAT_01ee0644;
    uVar6 = DAT_01ee0640;
    uVar13 = FUN_0152d930(DAT_01ee0640,DAT_01ee0644);
    uStack_8._0_1_ = 3;
    (**(code **)(*(int *)(*(int *)(param_1 + 0x1b8) + 0x58) + 0x18))(param_2);
    uStack_8._0_1_ = 4;
    FUN_0152dda0(uVar6,uVar7,uVar13);
    uStack_8._0_1_ = 1;
    if (param_1 == -0xc) {
      iStack_20 = 0;
      iVar10 = 0;
    }
    else {
      iStack_20 = FUN_0055e560();
      piVar9 = (int *)FUN_00636b00();
      iVar10 = *piVar9;
    }
    if (*(char *)(iVar10 + 0xe7) != '\0') {
      if ((*(int *)(iVar1 + 0x34) < DAT_01ee0658) &&
         (FUN_016f3809(&DAT_01ee0658), DAT_01ee0658 == -1)) {
        uStack_8._0_1_ = 5;
        uVar13 = FUN_0152dab0("Render","PlayerAdorns",0xffffffff);
        DAT_01ee0654 = (undefined4)((ulonglong)uVar13 >> 0x20);
        DAT_01ee0650 = (undefined4)uVar13;
        uStack_8._0_1_ = 1;
        FUN_016f37bf(&DAT_01ee0658);
      }
      uVar7 = DAT_01ee0654;
      uVar6 = DAT_01ee0650;
      uVar13 = FUN_0152d930(DAT_01ee0650,DAT_01ee0654);
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
      if ((*(int *)(iStack_20 + 0xf4) == 0) ||
         (cVar8 = FUN_00983210(*(int *)(iStack_20 + 0xf4)), cVar8 != '\0')) {
        FUN_00b60d90(param_2);
      }
      else {
        iVar10 = FUN_00676e20();
        if (iVar10 != 0) {
          FUN_00b60d80(param_2);
        }
      }
      uStack_8._0_1_ = 7;
      FUN_0152dda0(uVar6,uVar7,uVar13);
      uStack_8._0_1_ = 1;
    }
    if ((*(int *)(iVar1 + 0x34) < DAT_01ee0668) && (FUN_016f3809(&DAT_01ee0668), DAT_01ee0668 == -1)
       ) {
      uStack_8._0_1_ = 8;
      uVar13 = FUN_0152dab0("Render","CoreGuiAdorns",0xffffffff);
      DAT_01ee0664 = (undefined4)((ulonglong)uVar13 >> 0x20);
      DAT_01ee0660 = (undefined4)uVar13;
      uStack_8._0_1_ = 1;
      FUN_016f37bf(&DAT_01ee0668);
    }
    uVar7 = DAT_01ee0664;
    uVar6 = DAT_01ee0660;
    uVar13 = FUN_0152d930(DAT_01ee0660,DAT_01ee0664);
    uStack_8._0_1_ = 9;
    FUN_00b60d80(param_2);
    uStack_8._0_1_ = 10;
    FUN_0152dda0(uVar6,uVar7,uVar13);
    uStack_8._0_1_ = 1;
    if (*(char *)(param_1 + 0x1cc) == '\0') {
      (**(code **)(**(int **)(*(int *)(param_1 + 0x1b8) + 0x250) + 0x18))(param_2);
    }
    if ((*(int *)(iVar1 + 0x34) < DAT_01ee0678) && (FUN_016f3809(&DAT_01ee0678), DAT_01ee0678 == -1)
       ) {
      uStack_8._0_1_ = 0xb;
      uVar13 = FUN_0152dab0("Render","DebugAdorns",0xffffffff);
      DAT_01ee0674 = (undefined4)((ulonglong)uVar13 >> 0x20);
      DAT_01ee0670 = (undefined4)uVar13;
      uStack_8._0_1_ = 1;
      FUN_016f37bf(&DAT_01ee0678);
    }
    uVar7 = DAT_01ee0674;
    uVar6 = DAT_01ee0670;
    uVar13 = FUN_0152d930(DAT_01ee0670,DAT_01ee0674);
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    if (DAT_01edfb00 != '\0') {
      if (param_1 != -0xc) {
        FUN_0055e560();
      }
      FUN_0098a3d0(param_2);
    }
    if ((DAT_01edfb01 != '\0') ||
       ((*(char *)(param_1 + 0x24b) != '\0' && (*(int *)(*(int *)(param_1 + 0x488) + 8) == 4)))) {
      pcVar2 = *(code **)(*param_2 + 0x54);
      uVar11 = FUN_0060efa0();
      (*pcVar2)(uVar11);
      if (*(int *)(iStack_20 + 0xf4) != 0) {
        FUN_00930610(param_2);
      }
    }
    iVar1 = *(int *)(*(int *)(param_1 + 0x1b8) + 0x1b4);
    if (((iVar1 != 0) && (iVar1 = *(int *)(iVar1 + 0x110), iVar1 != 0)) &&
       (*(char *)(iVar1 + 1) != '\0')) {
      pcVar2 = *(code **)(*param_2 + 0x54);
      uVar11 = FUN_0060efa0();
      (*pcVar2)(uVar11);
      FUN_00f3e5e0(param_2);
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
    FUN_0152dda0(uVar6,uVar7,uVar13);
  }
  uStack_8 = 0xe;
  FUN_0152dda0(uVar4,uVar5,uVar12);
  if ((cVar3 != '\0') && (DAT_01d7ad40 != '\0')) {
    FUN_01532d10(uVar4,uVar5,uVar12);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15914 ; VA 0x00908980 ; FUN_00908980 */

void __thiscall
FUN_00908980(int *param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined8 param_8,uint param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined8 param_15)

{
  int *piVar1;
  int iVar2;
  undefined uVar3;
  int *piVar4;
  undefined auStack_1d4 [4];
  undefined4 uStack_1d0;
  undefined4 *puStack_1cc;
  undefined auStack_1c8 [8];
  undefined4 uStack_1c0;
  undefined *puStack_1bc;
  code *pcStack_1b8;
  undefined auStack_1b4 [4];
  undefined4 uStack_1b0;
  undefined4 *puStack_1ac;
  undefined4 uStack_1a8;
  undefined *puStack_1a4;
  char *pcStack_1a0;
  int iStack_19c;
  int iStack_198;
  undefined auStack_194 [8];
  undefined4 uStack_18c;
  undefined auStack_188 [12];
  undefined4 uStack_17c;
  undefined4 uStack_178;
  int iStack_174;
  int *piStack_170;
  undefined4 uStack_15c;
  undefined4 uStack_158;
  int aiStack_154 [2];
  undefined4 uStack_14c;
  int **ppiStack_148;
  int iStack_144;
  undefined4 *puStack_140;
  int **ppiStack_13c;
  undefined ***pppuStack_138;
  int iStack_114;
  int *piStack_110;
  int iStack_c4;
  int *piStack_c0;
  uint uStack_bc;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined8 uStack_a4;
  uint uStack_9c;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined8 uStack_84;
  undefined **ppuStack_7c;
  int iStack_78;
  int *piStack_74;
  int iStack_70;
  int *apiStack_6c [5];
  undefined ***pppuStack_58;
  int *apiStack_54 [2];
  int iStack_4c;
  int *piStack_48;
  int iStack_44;
  int *piStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  int *piStack_34;
  undefined *puStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  int *piStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c51ff;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  piStack_14 = param_1;
  if (DAT_01ee04ac != 0) {
    pppuStack_138 = (undefined ***)0x0;
    puStack_140 = (undefined4 *)(uint)DAT_01ee04ac;
    ppiStack_13c = (int **)0x192cbfc;
    iStack_144 = 0x9089c5;
    ExceptionList = &pvStack_10;
    FUN_016774b0();
  }
  if (DAT_01d635fc == '\0') {
    if ((-(uint)(param_1 != (int *)0x0) & (uint)(param_1 + 3)) != 0) {
      pppuStack_138 = (undefined ***)0x908dba;
      piStack_34 = (int *)FUN_008e29a0();
      if (piStack_34 != (int *)0x0) {
        puStack_1ac = &param_9;
        piStack_24 = aiStack_154;
        puStack_30 = (undefined *)CONCAT31(puStack_30._1_3_,DAT_01ee05ac);
        uStack_3c = CONCAT31(uStack_3c._1_3_,DAT_01ee05ac);
        uStack_158 = 0;
        piStack_18 = &uStack_1a8;
        uStack_1b0 = 0x908df1;
        FUN_0054f510();
        puStack_1ac = (undefined4 *)puStack_30;
        uStack_8._0_1_ = 0x12;
        puStack_1bc = auStack_1b4;
        pcStack_1b8 = (code *)piStack_14;
        uStack_1c0 = 0x908e06;
        FUN_005e5de0();
        uStack_8._0_1_ = 1;
        pcStack_1b8 = FUN_008f72c0;
        uStack_1c0 = 0x908e18;
        puStack_1bc = auStack_188;
        FUN_008e08e0();
        uStack_18c = 0x908e22;
        FUN_008dc660();
        piStack_18 = &iStack_174;
        uStack_8._0_1_ = 0x13;
        puStack_1cc = &param_2;
        uStack_178 = 0;
        puStack_30 = auStack_1c8;
        uStack_1d0 = 0x908e46;
        FUN_0054f510();
        puStack_1cc = (undefined4 *)uStack_3c;
        uStack_8._0_1_ = 0x14;
        FUN_005e5de0(auStack_1d4,piStack_14);
        uStack_8._0_1_ = 0x13;
        FUN_008e0a20(&uStack_1a8,FUN_008f7690);
        puStack_1ac = (undefined4 *)0x908e77;
        FUN_008dc7d0();
        param_1 = piStack_14;
        uStack_178 = 0;
        uStack_17c = 0;
        puStack_1a4 = auStack_194;
        uStack_8._0_1_ = 0x15;
        iStack_198 = piStack_14[0x111];
        iStack_19c = piStack_14[0x110];
        pcStack_1a0 = "v1.1/game-start-info/?universeId=%lld";
        uStack_1a8 = 0x908e9e;
        FUN_01675640();
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        iStack_198 = 0x908ead;
        FUN_00bcb3b0();
      }
    }
    if (DAT_01d5b258 == '\0') goto LAB_00908ff0;
    uStack_20 = 0;
    piStack_1c = (int *)0x0;
    piStack_18 = (int *)((uint)piStack_18 & 0xffffff00);
    pppuStack_138 = (undefined ***)&uStack_20;
    uStack_8._0_1_ = 0x16;
    ppiStack_13c = (int **)0x908edf;
    FUN_008eb410();
    uStack_8._0_1_ = 1;
    pppuStack_138 = (undefined ***)0x908eeb;
    FUN_00872220();
    ppiStack_13c = (int **)&iStack_28;
    *(undefined *)((int)param_1 + 0x24a) = 1;
    puStack_140 = (undefined4 *)0x908efc;
    pppuStack_138 = (undefined ***)param_1;
    FUN_005e5de0();
    puStack_140 = (undefined4 *)param_1[0x111];
    ppiStack_148 = apiStack_6c;
    uStack_8._0_1_ = 0x17;
    iStack_144 = param_1[0x110];
    uStack_14c = 0x908f15;
    puStack_140 = (undefined4 *)FUN_00f527f0();
    pppuStack_138 = (undefined ***)0x0;
    ppiStack_13c = (int **)0x0;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
    iStack_144 = 0x908f2c;
    FUN_014cc090();
    pppuStack_138 = (undefined ***)0x908f34;
    FUN_005507b0();
    piVar4 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[2] = piStack_24[2] + 1;
      UNLOCK();
    }
    iVar2 = iStack_28;
    iStack_38 = iStack_28;
    piStack_34 = piVar4;
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[2] = piVar4[2] + 1;
      UNLOCK();
    }
    iStack_4c = iVar2;
    piStack_48 = piVar4;
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[2] = piVar4[2] + 1;
      UNLOCK();
    }
    iStack_44 = iVar2;
    piStack_40 = piVar4;
    pppuStack_138 = (undefined ***)0x0;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x1c);
    piStack_170 = &iStack_4c;
    uStack_15c = 0;
    iStack_174 = 0x908f7f;
    FUN_008e6670();
    piStack_170 = (int *)0x908f86;
    FUN_008db3c0();
    uStack_15c = 0x908f91;
    FUN_014ccc70();
    piVar1 = piStack_40;
    if (piStack_40 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_40[2] + -1;
      piStack_40[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        pppuStack_138 = (undefined ***)0x908fa9;
        (**(code **)(*piVar1 + 4))();
      }
    }
    piVar1 = piStack_48;
    if (piStack_48 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_48[2] + -1;
      piStack_48[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        pppuStack_138 = (undefined ***)0x908fbe;
        (**(code **)(*piVar1 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar2 = piVar4[2] + -1;
      piVar4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        pppuStack_138 = (undefined ***)0x908fd2;
        (**(code **)(*piVar4 + 4))();
      }
    }
    pppuStack_138 = (undefined ***)0x908fdd;
    FUN_0056db40();
    if (piVar4 == (int *)0x0) goto LAB_00908ff0;
  }
  else {
    ppiStack_13c = &piStack_1c;
    pppuStack_138 = (undefined ***)0x0;
    puStack_140 = (undefined4 *)0x9089e0;
    FUN_014c9d60();
    puStack_140 = (undefined4 *)param_1[0x111];
    ppiStack_148 = apiStack_54;
    iStack_144 = param_1[0x110];
    uStack_8._0_1_ = 2;
    uStack_14c = 0x9089fc;
    ppiStack_13c = (int **)FUN_00f524c0();
    pppuStack_138 = (undefined ***)((int *)ppiStack_13c)[4];
    uStack_8._0_1_ = 3;
    if (0xf < (uint)((int *)ppiStack_13c)[5]) {
      ppiStack_13c = (int **)*ppiStack_13c;
    }
    puStack_140 = (undefined4 *)0x908a1c;
    FUN_014cbbc0();
    uStack_8._0_1_ = 2;
    uVar3 = (undefined)uStack_8;
    uStack_8._0_1_ = 2;
    if (&DAT_0000000f < piStack_40) {
      pppuStack_138 = (undefined ***)((int)piStack_40 + 1);
      piVar4 = apiStack_54[0];
      if ((int *)0xfff < pppuStack_138) {
        piVar4 = (int *)apiStack_54[0][-1];
        pppuStack_138 = (undefined ***)(piStack_40 + 9);
        if (0x1f < (uint)((int)apiStack_54[0] + (-4 - (int)piVar4))) {
                    /* WARNING: Subroutine does not return */
          pppuStack_138 = (undefined ***)&UNK_00909059;
          uStack_8._0_1_ = uVar3;
          FUN_017167a3();
        }
      }
      puStack_140 = (undefined4 *)0x908a51;
      ppiStack_13c = (int **)piVar4;
      FUN_01674ea0();
    }
    piStack_1c[0x2c] = 0;
    pppuStack_138 = (undefined ***)0x908a69;
    FUN_014cba40();
    ppiStack_13c = (int **)&iStack_28;
    puStack_140 = (undefined4 *)0x908a73;
    pppuStack_138 = (undefined ***)param_1;
    FUN_005e5de0();
    piVar4 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[2] = piStack_24[2] + 1;
      UNLOCK();
    }
    iStack_c4 = iStack_28;
    piStack_c0 = piStack_24;
    uStack_8._0_1_ = 5;
    uStack_bc = 0;
    if (param_2 != 0) {
      uStack_bc = param_2;
      if ((param_2 & 1) == 0) {
        ppiStack_13c = (int **)&uStack_b4;
        pppuStack_138 = (undefined ***)0x0;
        puStack_140 = &param_4;
        iStack_144 = 0x908af1;
        (**(code **)(param_2 & 0xfffffffe))();
      }
      else {
        uStack_b4 = param_4;
        uStack_b0 = param_5;
        uStack_ac = param_6;
        uStack_a8 = param_7;
        uStack_a4 = param_8;
      }
    }
    uStack_8._0_1_ = 6;
    uStack_9c = 0;
    if (param_9 != 0) {
      uStack_9c = param_9;
      if ((param_9 & 1) == 0) {
        ppiStack_13c = (int **)&uStack_94;
        pppuStack_138 = (undefined ***)0x0;
        puStack_140 = &param_11;
        iStack_144 = 0x908b3e;
        (**(code **)(param_9 & 0xfffffffe))();
      }
      else {
        uStack_94 = param_11;
        uStack_90 = param_12;
        uStack_8c = param_13;
        uStack_88 = param_14;
        uStack_84 = param_15;
      }
    }
    piStack_34 = &iStack_114;
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[2] = piVar4[2] + 1;
      UNLOCK();
    }
    iStack_114 = iStack_28;
    piStack_110 = piVar4;
    pppuStack_138 = (undefined ***)&iStack_c4;
    uStack_8._0_1_ = 8;
    ppiStack_13c = (int **)0x908b8b;
    FUN_008e68f0();
    pppuStack_58 = (undefined ***)0x0;
    pppuStack_138 = (undefined ***)&iStack_114;
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    ppiStack_13c = (int **)0x908ba2;
    pppuStack_58 = (undefined ***)FUN_008dd7f0();
    pppuStack_138 = (undefined ***)0x908bb3;
    FUN_008e9ba0();
    if (piStack_110 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_110[2] + -1;
      piStack_110[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        pppuStack_138 = (undefined ***)0x908bce;
        (**(code **)(*piStack_110 + 4))();
      }
    }
    pppuStack_138 = &ppuStack_7c;
    uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
    ppiStack_13c = (int **)0x908bde;
    FUN_014cb530();
    if (pppuStack_58 != (undefined ***)0x0) {
      pppuStack_138 =
           (undefined ***)CONCAT31((int3)((uint)&ppuStack_7c >> 8),pppuStack_58 != &ppuStack_7c);
      ppiStack_13c = (int **)0x908bf5;
      (*(code *)(*pppuStack_58)[4])();
    }
    pppuStack_138 = (undefined ***)0x908c00;
    FUN_008e9ba0();
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_24[2] + -1;
      piStack_24[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        pppuStack_138 = (undefined ***)0x908c15;
        (**(code **)(*piStack_24 + 4))();
      }
    }
    piStack_14 = piStack_18;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar2 = piStack_18[1] + -1;
      piStack_18[1] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        pppuStack_138 = (undefined ***)0x908c2c;
        (**(code **)*piStack_18)();
        LOCK();
        iVar2 = piStack_14[2] + -1;
        piStack_14[2] = iVar2;
        UNLOCK();
        if (iVar2 == 0) {
          pppuStack_138 = (undefined ***)0x908c3d;
          (**(code **)(*piStack_14 + 4))();
        }
      }
    }
    if (DAT_01d5b258 == '\0') goto LAB_00908ff0;
    uStack_2c = 0;
    iStack_28 = 0;
    piStack_24 = (int *)((uint)piStack_24 & 0xffffff00);
    pppuStack_138 = (undefined ***)&uStack_2c;
    uStack_8._0_1_ = 0xc;
    ppiStack_13c = (int **)0x908c6f;
    FUN_008eb410();
    uStack_8._0_1_ = 1;
    pppuStack_138 = (undefined ***)0x908c7b;
    FUN_00872220();
    ppiStack_13c = &piStack_1c;
    *(undefined *)((int)param_1 + 0x24a) = 1;
    pppuStack_138 = (undefined ***)0x0;
    puStack_140 = (undefined4 *)0x908c8d;
    FUN_014c9d60();
    puStack_140 = (undefined4 *)param_1[0x111];
    iStack_144 = param_1[0x110];
    piStack_14 = piStack_1c;
    ppiStack_148 = apiStack_54;
    uStack_8._0_1_ = 0xd;
    uStack_14c = 0x908cac;
    ppiStack_13c = (int **)FUN_00f527f0();
    pppuStack_138 = (undefined ***)ppiStack_13c[4];
    uStack_8._0_1_ = 0xe;
    if (0xf < ppiStack_13c[5]) {
      ppiStack_13c = (int **)*ppiStack_13c;
    }
    puStack_140 = (undefined4 *)0x908ccd;
    FUN_014cbbc0();
    uStack_8._0_1_ = 0xd;
    pppuStack_138 = (undefined ***)0x908cd9;
    FUN_005507b0();
    piStack_1c[0x2c] = 0;
    pppuStack_138 = (undefined ***)0x908cee;
    FUN_014cba40();
    ppiStack_13c = (int **)&iStack_28;
    puStack_140 = (undefined4 *)0x908cf8;
    pppuStack_138 = (undefined ***)param_1;
    FUN_005e5de0();
    piVar4 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      piStack_24[2] = piStack_24[2] + 1;
      UNLOCK();
    }
    iStack_38 = iStack_28;
    piStack_34 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      piVar1 = piStack_24 + 2;
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
      LOCK();
      *piVar1 = *piVar1 + 1;
      UNLOCK();
    }
    pppuStack_138 = &ppuStack_7c;
    ppuStack_7c = std::
                  _Func_impl_no_alloc<class_<lambda_c6c643c68cd5f4fa41e08dd852f2ae65>,void,enum_RBX::HttpErrorCode,class_RBX::HttpResponse&>
                  ::vftable;
    iStack_78 = iStack_28;
    piStack_74 = piStack_24;
    iStack_70 = iStack_28;
    apiStack_6c[0] = piStack_24;
    uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
    ppiStack_13c = (int **)0x908d42;
    pppuStack_58 = pppuStack_138;
    FUN_014cb530();
    if (pppuStack_58 != (undefined ***)0x0) {
      pppuStack_138 =
           (undefined ***)CONCAT31((int3)((uint)&ppuStack_7c >> 8),pppuStack_58 != &ppuStack_7c);
      ppiStack_13c = (int **)0x908d59;
      (*(code *)(*pppuStack_58)[4])();
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      iVar2 = piVar4[2] + -1;
      piVar4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        pppuStack_138 = (undefined ***)0x908d6f;
        (**(code **)(*piVar4 + 4))();
      }
      LOCK();
      iVar2 = piVar4[2] + -1;
      piVar4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        pppuStack_138 = (undefined ***)0x908d81;
        (**(code **)(*piVar4 + 4))();
      }
    }
    piVar4 = piStack_18;
    if (piStack_18 == (int *)0x0) goto LAB_00908ff0;
    LOCK();
    iVar2 = piStack_18[1] + -1;
    piStack_18[1] = iVar2;
    UNLOCK();
    if (iVar2 != 0) goto LAB_00908ff0;
    pppuStack_138 = (undefined ***)0x908d9f;
    (**(code **)*piStack_18)();
  }
  LOCK();
  piVar1 = piVar4 + 2;
  iVar2 = *piVar1;
  *piVar1 = *piVar1 + -1;
  UNLOCK();
  if (iVar2 == 1) {
    pppuStack_138 = (undefined ***)0x908ff0;
    (**(code **)(*piVar4 + 4))();
  }
LAB_00908ff0:
  uStack_8 = CONCAT31(uStack_8._1_3_,0x1d);
  if (param_2 != 0) {
    if (((param_2 & 1) == 0) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0)) {
      puStack_140 = &param_4;
      pppuStack_138 = (undefined ***)0x2;
      iStack_144 = 0x909011;
      ppiStack_13c = (int **)puStack_140;
      (**(code **)(param_2 & 0xfffffffe))();
    }
    param_2 = 0;
  }
  uStack_8 = 0x1e;
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    puStack_140 = &param_11;
    pppuStack_138 = (undefined ***)0x2;
    iStack_144 = 0x90903f;
    ppiStack_13c = (int **)puStack_140;
    (**(code **)(param_9 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15915 ; VA 0x00909060 ; FUN_00909060 */

void __thiscall FUN_00909060(undefined4 *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar3 = (undefined4 *)FUN_01674e20(4);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = param_2;
  }
  puVar4 = (undefined4 *)FUN_01689e40(param_1);
  if (puVar4 != puVar3) {
    uVar1 = *param_1;
    iVar2 = param_1[1];
    if (iVar2 != 0) {
      LOCK();
      *(int *)(iVar2 + 4) = *(int *)(iVar2 + 4) + 1;
      UNLOCK();
    }
    FUN_0168a720(param_1,uVar1,iVar2,puVar3,1);
  }
  return;
}



/* FUNCTION 15916 ; VA 0x009090c0 ; FUN_009090c0 */

/* WARNING: Type propagation algorithm not settling */

code ** __thiscall FUN_009090c0(int ****param_1,int ****param_2,code ***param_3)

{
  code ***pppcVar1;
  code **ppcVar2;
  undefined *puVar3;
  undefined4 *puVar4;
  char cVar5;
  int *piVar6;
  int iVar7;
  int ***pppiVar8;
  code **ppcVar9;
  undefined **ppuVar10;
  int ***pppiVar11;
  uint uVar12;
  bool bVar13;
  undefined4 uVar14;
  int ****ppppiVar15;
  code *pcVar16;
  undefined4 uVar17;
  int ****ppppiVar18;
  int ****ppppiStack_14c;
  int ****ppppiStack_148;
  int ****ppppiStack_144;
  int ****ppppiStack_140;
  code *pcStack_13c;
  undefined *puStack_138;
  int ****ppppiStack_134;
  int ****ppppiStack_130;
  int ****ppppiStack_12c;
  int ****ppppiStack_128;
  int ****ppppiStack_124;
  code ***pppcStack_120;
  undefined auStack_11c [12];
  undefined4 uStack_110;
  code ****ppppcStack_10c;
  code ****ppppcStack_108;
  int ****ppppiStack_104;
  undefined auStack_f8 [20];
  int ****ppppiStack_e4;
  code ***pppcStack_d8;
  int ****ppppiStack_d4;
  code **appcStack_d0 [2];
  code ***apppcStack_c8 [4];
  int ****ppppiStack_b8;
  code **appcStack_b0 [2];
  code ***apppcStack_a8 [4];
  int *piStack_98;
  int ****ppppiStack_8c;
  int ****ppppiStack_88;
  int ***pppiStack_84;
  code *pcStack_80;
  undefined4 uStack_7c;
  undefined *puStack_78;
  int ****ppppiStack_74;
  int ****ppppiStack_6c;
  undefined4 uStack_68;
  int ***pppiStack_64;
  code *pcStack_60;
  undefined4 uStack_5c;
  undefined *puStack_58;
  int ****ppppiStack_54;
  undefined *puStack_4c;
  undefined *puStack_48;
  undefined *puStack_44;
  int ****ppppiStack_40;
  undefined *puStack_3c;
  code ***pppcStack_38;
  code *pcStack_34;
  int ***pppiStack_30;
  undefined4 *puStack_2c;
  int ****ppppiStack_28;
  undefined *puStack_24;
  int ****ppppiStack_20;
  int ****ppppiStack_1c;
  int ****ppppiStack_18;
  int ****ppppiStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c52cc;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  ppppiStack_1c = param_1;
  if (param_1 == (int ****)0x0) {
LAB_00909111:
    ppppiStack_d4 = (int ****)0x0;
  }
  else {
    ppppiStack_104 = (int ****)0x1c;
    ppppcStack_108 = (code ****)0x9090f7;
    ExceptionList = &pvStack_10;
    puStack_24 = (undefined *)FUN_01674e20();
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    if (puStack_24 == (undefined *)0x0) goto LAB_00909111;
    ppppiStack_104 = (int ****)0x1;
    ppppcStack_10c = (code ****)0x90910f;
    ppppcStack_108 = (code ****)param_1;
    ppppiStack_d4 = (int ****)FUN_008e8e20();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  *(code *)(param_1 + 0x127) = (code)0x1;
  ppppiStack_40 = ppppiStack_d4;
  if (*(code *)((int)param_1 + 0x241) != (code)0x0) {
    if (DAT_01d635ac != '\0') {
      if (DAT_01d65192 != 0) {
        ppppiStack_104 = (int ****)0x0;
        ppppcStack_10c = (code ****)(uint)DAT_01d65192;
        ppppcStack_108 = (code ****)0x192b10c;
        uStack_110 = 0x909156;
        FUN_016774b0();
      }
      if (param_1 != (int ****)0xfffffff4) {
        ppppiStack_104 = (int ****)0x909165;
        piVar6 = (int *)FUN_00563f20();
        if (*piVar6 != 0) {
          ppppiStack_104 = (int ****)0x909170;
          FUN_00d16030();
        }
      }
      bVar13 = param_1 != (int ****)0xfffffff4;
      param_1 = ppppiStack_1c;
      if (bVar13) {
        ppppiStack_104 = (int ****)0x90917b;
        piVar6 = (int *)FUN_00563fd0();
        param_1 = ppppiStack_1c;
        if (*piVar6 != 0) {
          ppppiStack_104 = (int ****)0x909186;
          FUN_00d16030();
          param_1 = ppppiStack_1c;
        }
      }
    }
    if (DAT_01d65192 != 0) {
      ppppiStack_104 = (int ****)0x0;
      ppppcStack_10c = (code ****)(uint)DAT_01d65192;
      ppppcStack_108 = (code ****)0x192b140;
      uStack_110 = 0x9091a2;
      FUN_016774b0();
    }
    if (DAT_01d65a50 != '\0') {
      ppppiStack_104 = param_1 + 3;
      ppppcStack_108 = (code ****)0x9091b7;
      iVar7 = FUN_005cf8d0();
      if ((9999 < DAT_01ee5c3c) || ((iVar7 != 0 && (*(char *)(iVar7 + 0xee) != '\0')))) {
        ppppiStack_104 = (int ****)0x0;
        ppppcStack_108 = (code ****)0x0;
        ppppcStack_10c = (code ****)&ppppiStack_8c;
        uStack_110 = 0x9091e6;
        FUN_005ea890();
        goto LAB_009091f5;
      }
    }
    ppppiStack_104 = (int ****)0x0;
    ppppcStack_108 = (code ****)0x0;
    ppppcStack_10c = (code ****)0x0;
    uStack_110 = 0x9091f5;
    FUN_005e6850();
  }
LAB_009091f5:
  for (uVar12 = 0;
      (pppiVar11 = param_1[0xe], pppiVar11 != (int ***)0x0 &&
      (uVar12 < (uint)((int)pppiVar11[1] - (int)*pppiVar11 >> 3))); uVar12 = uVar12 + 1) {
    ppppiStack_20 = (int ****)(*pppiVar11)[uVar12 * 2];
    if (ppppiStack_20 != (int ****)0x0) {
      pppiVar11 = ppppiStack_20[3];
      ppppiStack_104 = (int ****)0x90921e;
      iVar7 = FUN_00cce370();
      param_1 = ppppiStack_1c;
      if ((uint)*(ushort *)(pppiVar11 + 0x76) - (uint)*(ushort *)(iVar7 + 0x1d8) <=
          (uint)*(ushort *)(iVar7 + 0x1da)) {
        ppppiStack_104 = (int ****)0x909241;
        FUN_00cd0ce0();
        param_1 = ppppiStack_1c;
      }
    }
  }
  if (param_1 != (int ****)0xfffffff4) {
    ppppiStack_104 = (int ****)0x909259;
    iVar7 = FUN_006fdf60();
    if (iVar7 != 0) {
      ppppiStack_20 = (int ****)&pppcStack_120;
      ppppiStack_124 = (int ****)0x0;
      if (param_3 != (code ***)0x0) {
        LOCK();
        param_3[1] = (code **)((int)param_3[1] + 1);
        UNLOCK();
      }
      ppppiStack_14c = (int ****)0x0;
      ppppiStack_144 = param_2;
      ppppiStack_140 = (int ****)param_3;
      ppppiStack_148 = param_1;
      FUN_008ab6d0(&pcStack_13c,FUN_00901d30);
      ppppiStack_140 = (int ****)0x9092ad;
      FUN_008dca40();
      ppppiStack_124 = (int ****)0x9092b4;
      FUN_00cd8240();
    }
    if (param_1 != (int ****)0xfffffff4) {
      ppppiStack_104 = (int ****)0x9092c2;
      piVar6 = (int *)FUN_00564080();
      iVar7 = *piVar6;
      if (((iVar7 != 0) && (0 < (*(int **)(iVar7 + 0xb8))[1] - **(int **)(iVar7 + 0xb8) >> 3)) &&
         (*(int *)(iVar7 + 0x2ac) != 0)) {
        ppppiStack_104 = (int ****)0x9092e8;
        FUN_00978df0();
      }
    }
  }
  param_1[0x126] = (int ***)0x0;
  param_1[0x126] = (int ***)((int)param_1[0x125] + (uint)(param_1[0xb6] != (int ***)0x0));
  if (param_1[0xb6] != (int ***)0x0) {
    if (DAT_01d65192 != 0) {
      ppppiStack_104 = (int ****)0x0;
      ppppcStack_10c = (code ****)(uint)DAT_01d65192;
      ppppcStack_108 = (code ****)0x192b15c;
      uStack_110 = 0x90932e;
      FUN_016774b0();
    }
    ppppiStack_104 = (int ****)0x0;
    puStack_138 = auStack_11c;
    ppppiStack_20 = (int ****)CONCAT31(ppppiStack_20._1_3_,DAT_01ee05ac);
    if (param_3 != (code ***)0x0) {
      LOCK();
      param_3[1] = (code **)((int)param_3[1] + 1);
      UNLOCK();
    }
    ppppiStack_128 = ppppiStack_20;
    ppppiStack_130 = (int ****)0x0;
    ppppiStack_124 = param_2;
    ppppiStack_134 = (int ****)FUN_00901de0;
    pppcStack_120 = param_3;
    pcStack_13c = (code *)0x90937f;
    ppppiStack_12c = param_1;
    FUN_008e0b60();
    pppcStack_120 = (code ***)0x909389;
    FUN_008dcb40();
    ppppiStack_104 = (int ****)0x0;
    ppppiStack_134 = (int ****)auStack_11c;
    if (param_3 != (code ***)0x0) {
      LOCK();
      param_3[1] = (code **)((int)param_3[1] + 1);
      UNLOCK();
    }
    ppppiStack_12c = (int ****)0x0;
    ppppiStack_124 = param_2;
    ppppiStack_130 = (int ****)FUN_00901ee0;
    pppcStack_120 = param_3;
    puStack_138 = (undefined *)0x9093c6;
    ppppiStack_128 = param_1;
    FUN_008ab6d0();
    pppcStack_120 = (code ***)0x9093d4;
    FUN_008dc940();
    uStack_8._0_1_ = 4;
    if (param_1[0xb6] == (int ***)0x0) {
      ppppiStack_104 = (int ****)0x909d22;
      ppppiStack_104 = (int ****)FUN_0054fda0();
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
                    /* WARNING: Subroutine does not return */
      ppppcStack_108 = (code ****)&UNK_00909d2c;
      FUN_0054e5e0();
    }
    puStack_24 = (undefined *)&pppcStack_120;
    ppppiStack_18 = (int ****)&pppcStack_120;
    ppppiStack_124 = (int ****)appcStack_b0;
    pcVar16 = *(code **)(((uint)param_1[0xb6] & 0xfffffffe) + 4);
    pppcStack_120 = (code ***)0x0;
    ppppiStack_128 = (int ****)0x909409;
    FUN_005880d0();
    ppppiStack_18 = (int ****)&ppppiStack_140;
    uStack_8._0_1_ = 6;
    ppppiStack_144 = (int ****)appcStack_d0;
    ppppiStack_140 = (int ****)0x0;
    ppppiStack_148 = (int ****)0x909427;
    FUN_005880d0();
    ppppiStack_144 = ppppiStack_1c + 0xb8;
    uStack_8._0_1_ = 4;
    ppppiStack_148 = (int ****)0x909436;
    (*pcVar16)();
    uStack_8._0_1_ = 7;
    if (appcStack_d0[0] != (code **)0x0) {
      if ((((uint)appcStack_d0[0] & 1) == 0) &&
         (*(code **)((uint)appcStack_d0[0] & 0xfffffffe) != (code *)0x0)) {
        ppppcStack_10c = apppcStack_c8;
        ppppiStack_104 = (int ****)0x2;
        uStack_110 = 0x909460;
        ppppcStack_108 = ppppcStack_10c;
        (**(code **)((uint)appcStack_d0[0] & 0xfffffffe))();
      }
      appcStack_d0[0] = (code **)0x0;
    }
    uStack_8._0_1_ = 8;
    if (((appcStack_b0[0] != (code **)0x0) && (((uint)appcStack_b0[0] & 1) == 0)) &&
       (*(code **)((uint)appcStack_b0[0] & 0xfffffffe) != (code *)0x0)) {
      ppppcStack_10c = apppcStack_a8;
      ppppiStack_104 = (int ****)0x2;
      uStack_110 = 0x909494;
      ppppcStack_108 = ppppcStack_10c;
      (**(code **)((uint)appcStack_b0[0] & 0xfffffffe))();
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    param_1 = ppppiStack_1c;
  }
  pppiVar11 = (int ***)*param_1[0x124];
  if (pppiVar11 != param_1[0x124]) {
    do {
      ppppiStack_104 = (int ****)(pppiVar11 + 2);
      ppppcStack_108 = (code ****)0x9094c0;
      FUN_00d88580();
      ppppiStack_104 = (int ****)0x1c;
      uStack_8._0_1_ = 9;
      ppppcStack_108 = (code ****)0x9094cb;
      ppppiStack_18 = (int ****)FUN_01674e20();
      if (ppppiStack_18 == (int ****)0x0) {
        pppcStack_38 = (code ***)0x0;
      }
      else {
        ((code ***)ppppiStack_18)[1] = (code **)0x0;
        LOCK();
        DAT_01e90cd8 = DAT_01e90cd8 + 1;
        UNLOCK();
        *ppppiStack_18 = (int ***)RBX::Lua::WeakThreadRef::vftable;
        ((code ***)ppppiStack_18)[3] = (code **)0x0;
        ((code ***)ppppiStack_18)[4] = (code **)0x0;
        ((code ***)ppppiStack_18)[5] = (code **)0x0;
        ((code ***)ppppiStack_18)[6] = (code **)0x0;
        pppcStack_38 = (code ***)ppppiStack_18;
      }
      if (pppcStack_38 == (code ***)0x0) {
        ppppiStack_14 = (int ****)&DAT_00000004;
      }
      else {
        ppppiStack_14 = (int ****)(pppcStack_38 + 1);
        LOCK();
        *ppppiStack_14 = (int ***)((int)*ppppiStack_14 + 1);
        UNLOCK();
      }
      ppppiStack_104 = (int ****)0x18;
      uStack_8._0_1_ = 10;
      ppppcStack_108 = (code ****)0x90953b;
      pppcStack_d8 = pppcStack_38;
      ppppiStack_18 = (int ****)FUN_01674e20();
      if (ppppiStack_18 == (int ****)0x0) {
        ppppiStack_28 = (int ****)0x0;
      }
      else {
        ppppiStack_18[1] = (int ***)0x1;
        ppppiStack_18[2] = (int ***)0x1;
        *ppppiStack_18 = (int ***)std::_Ref_count_obj<struct_RBX::Reflection::Tuple>::vftable;
        ppppiStack_18[3] = (int ***)0x0;
        ppppiStack_18[4] = (int ***)0x0;
        ppppiStack_18[5] = (int ***)0x0;
        ppppiStack_28 = ppppiStack_18;
      }
      ppppiStack_8c = ppppiStack_28 + 3;
      ppppiStack_88 = ppppiStack_28;
      if (DAT_01d63564 == '\0') {
        puStack_3c = (undefined *)&ppppiStack_104;
        puStack_24 = (undefined *)CONCAT31(puStack_24._1_3_,DAT_01ee05ac);
        ppppiStack_104 = (int ****)pppcStack_38;
        if (pppcStack_38 != (code ***)0x0) {
          LOCK();
          *ppppiStack_14 = (int ***)((int)*ppppiStack_14 + 1);
          UNLOCK();
        }
        puStack_4c = (undefined *)&ppppiStack_124;
        ppppiStack_20 = (int ****)&ppppiStack_124;
        ppppiStack_140 = &pppiStack_64;
        if (param_3 != (code ***)0x0) {
          LOCK();
          param_3[1] = (code **)((int)param_3[1] + 1);
          UNLOCK();
        }
        ppppiStack_130 = (int ****)puStack_24;
        ppppiStack_134 = ppppiStack_1c;
        ppppiStack_12c = param_2;
        puStack_138 = (undefined *)0x0;
        pcStack_13c = FUN_00901de0;
        ppppiStack_128 = (int ****)param_3;
        ppppiStack_144 = (int ****)0x9099be;
        FUN_008e0b60();
        ppppiVar18 = ppppiStack_20;
        ppppiVar15 = ppppiStack_54;
        ppppiStack_134 = (int ****)puStack_58;
        ppppiStack_18 = (int ****)pppiStack_64;
        pcStack_34 = pcStack_60;
        pppiStack_30 = (int ***)uStack_5c;
        if (ppppiStack_54 != (int ****)0x0) {
          LOCK();
          ppppiStack_54[1] = (int ***)((int)ppppiStack_54[1] + 1);
          UNLOCK();
        }
        ppppiStack_14 = ppppiStack_54;
        *ppppiStack_20 = (int ***)0x0;
        if (ppppiVar15 != (int ****)0x0) {
          LOCK();
          ppppiVar15 = ppppiVar15 + 1;
          *ppppiVar15 = (int ***)((int)*ppppiVar15 + 1);
          UNLOCK();
        }
        ppppiStack_128 = ppppiVar18 + 2;
        ppppiStack_140 = ppppiStack_18;
        pcStack_13c = pcStack_34;
        puStack_138 = (undefined *)pppiStack_30;
        if (ppppiStack_14 != (int ****)0x0) {
          LOCK();
          ppppiStack_14[1] = (int ***)((int)ppppiStack_14[1] + 1);
          UNLOCK();
        }
        ppppiStack_130 = ppppiStack_14;
        ppppiStack_144 = (int ****)0x909a3e;
        cVar5 = FUN_008e0150();
        ppuVar10 = &PTR_FUN_0192d328;
        if (cVar5 == '\0') {
          ppuVar10 = (undefined **)0x0;
        }
        *ppppiStack_20 = (int ***)ppuVar10;
        if (ppppiStack_14 != (int ****)0x0) {
          LOCK();
          pppiVar8 = (int ***)((int)ppppiStack_14[1] + -1);
          ppppiStack_14[1] = pppiVar8;
          UNLOCK();
          if (pppiVar8 == (int ***)0x0) {
            ppppiStack_128 = (int ****)0x909a63;
            (*(code *)**ppppiStack_14)();
            LOCK();
            pppiVar8 = (int ***)((int)ppppiStack_14[2] + -1);
            ppppiStack_14[2] = pppiVar8;
            UNLOCK();
            if (pppiVar8 == (int ***)0x0) {
              ppppiStack_128 = (int ****)0x909a74;
              (*(code *)(*ppppiStack_14)[1])();
            }
          }
          if (ppppiStack_14 != (int ****)0x0) {
            LOCK();
            pppiVar8 = (int ***)((int)ppppiStack_14[1] + -1);
            ppppiStack_14[1] = pppiVar8;
            UNLOCK();
            if (pppiVar8 == (int ***)0x0) {
              ppppiStack_128 = (int ****)0x909a88;
              (*(code *)**ppppiStack_14)();
              LOCK();
              pppiVar8 = (int ***)((int)ppppiStack_14[2] + -1);
              ppppiStack_14[2] = pppiVar8;
              UNLOCK();
              if (pppiVar8 == (int ***)0x0) {
                ppppiStack_128 = (int ****)0x909a99;
                (*(code *)(*ppppiStack_14)[1])();
              }
            }
          }
        }
        ppppiStack_18 = ppppiStack_54;
        if (ppppiStack_54 != (int ****)0x0) {
          LOCK();
          pppiVar8 = (int ***)((int)ppppiStack_54[1] + -1);
          ppppiStack_54[1] = pppiVar8;
          UNLOCK();
          if (pppiVar8 == (int ***)0x0) {
            ppppiStack_128 = (int ****)0x909ab0;
            (*(code *)**ppppiStack_54)();
            LOCK();
            pppiVar8 = (int ***)((int)ppppiStack_18[2] + -1);
            ppppiStack_18[2] = pppiVar8;
            UNLOCK();
            if (pppiVar8 == (int ***)0x0) {
              ppppiStack_128 = (int ****)0x909ac1;
              (*(code *)(*ppppiStack_18)[1])();
            }
          }
        }
        puStack_48 = (undefined *)&ppppiStack_144;
        ppppiStack_14 = (int ****)&ppppiStack_144;
        ppppiVar15 = (int ****)apppcStack_c8;
        if (param_3 != (code ***)0x0) {
          LOCK();
          param_3[1] = (code **)((int)param_3[1] + 1);
          UNLOCK();
        }
        uVar17 = 0;
        ppppiStack_14c = param_2;
        pcVar16 = FUN_00901ee0;
        ppppiStack_148 = (int ****)param_3;
        uVar14 = 0x909b08;
        ppppiVar18 = ppppiStack_1c;
        FUN_008ab6d0(ppppiVar15,FUN_00901ee0,0,ppppiStack_1c);
        ppppiStack_148 = (int ****)apppcStack_c8;
        ppppiStack_14c = (int ****)0x909b1d;
        FUN_008e72a0();
        *ppppiStack_14 = (int ***)0x0;
        ppppiStack_148 = (int ****)apppcStack_a8;
        ppppiStack_14c = (int ****)0x909b35;
        FUN_008e72a0();
        ppppiStack_148 = ppppiStack_14 + 2;
        FUN_008e72a0(&pppiStack_84);
        cVar5 = FUN_008e0150(uVar14,ppppiVar15,pcVar16,uVar17,ppppiVar18);
        ppuVar10 = &PTR_FUN_0192d320;
        if (cVar5 == '\0') {
          ppuVar10 = (undefined **)0x0;
        }
        *ppppiStack_14 = (int ***)ppuVar10;
        if (ppppiStack_74 != (int ****)0x0) {
          LOCK();
          pppiVar8 = (int ***)((int)ppppiStack_74[1] + -1);
          ppppiStack_74[1] = pppiVar8;
          UNLOCK();
          if (pppiVar8 == (int ***)0x0) {
            ppppiStack_148 = (int ****)0x909b79;
            (*(code *)**ppppiStack_74)();
            LOCK();
            pppiVar8 = (int ***)((int)ppppiStack_74[2] + -1);
            ppppiStack_74[2] = pppiVar8;
            UNLOCK();
            if (pppiVar8 == (int ***)0x0) {
              ppppiStack_148 = (int ****)0x909b8a;
              (*(code *)(*ppppiStack_74)[1])();
            }
          }
        }
        if (piStack_98 != (int *)0x0) {
          LOCK();
          iVar7 = piStack_98[1] + -1;
          piStack_98[1] = iVar7;
          UNLOCK();
          if (iVar7 == 0) {
            ppppiStack_148 = (int ****)0x909ba1;
            (**(code **)*piStack_98)();
            LOCK();
            iVar7 = piStack_98[2] + -1;
            piStack_98[2] = iVar7;
            UNLOCK();
            if (iVar7 == 0) {
              ppppiStack_148 = (int ****)0x909bb5;
              (**(code **)(*piStack_98 + 4))();
            }
          }
        }
        ppppiStack_18 = ppppiStack_b8;
        if (ppppiStack_b8 != (int ****)0x0) {
          LOCK();
          pppiVar8 = (int ***)((int)ppppiStack_b8[1] + -1);
          ppppiStack_b8[1] = pppiVar8;
          UNLOCK();
          if (pppiVar8 == (int ***)0x0) {
            ppppiStack_148 = (int ****)0x909bcf;
            (*(code *)**ppppiStack_b8)();
            LOCK();
            pppiVar8 = (int ***)((int)ppppiStack_18[2] + -1);
            ppppiStack_18[2] = pppiVar8;
            UNLOCK();
            if (pppiVar8 == (int ***)0x0) {
              ppppiStack_148 = (int ****)0x909be0;
              (*(code *)(*ppppiStack_18)[1])();
            }
          }
        }
        puStack_44 = (undefined *)&ppppiStack_14c;
        if (ppppiStack_28 != (int ****)0x0) {
          LOCK();
          ppppiStack_28[1] = (int ***)((int)ppppiStack_28[1] + 1);
          UNLOCK();
        }
        ppppiStack_14c = ppppiStack_28 + 3;
        ppppiStack_148 = ppppiStack_28;
        uStack_8._0_1_ = 0x15;
        FUN_00d88580(auStack_f8);
        uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
        FUN_0094a8d0();
      }
      else {
        ppppiStack_20 = ppppiStack_e4;
        LOCK();
        DAT_01e90cd4 = DAT_01e90cd4 + 1;
        UNLOCK();
        ppppiStack_6c = ppppiStack_e4;
        if (ppppiStack_e4 == (int ****)0x0) {
          pppiVar8 = (int ***)0x0;
        }
        else {
          LOCK();
          *ppppiStack_e4 = (int ***)((int)*ppppiStack_e4 + 1);
          UNLOCK();
          pppiVar8 = ppppiStack_e4[2];
        }
        if (pppiVar8 == (int ***)0x0) {
          puStack_3c = (undefined *)&ppppcStack_108;
          if (param_3 != (code ***)0x0) {
            LOCK();
            param_3[1] = (code **)((int)param_3[1] + 1);
            UNLOCK();
          }
          ppppcStack_108 = (code ****)param_2;
          ppppiStack_104 = (int ****)param_3;
          uStack_8._0_1_ = 0x11;
          ppppiStack_124 = (int ****)0x1f;
          uStack_110 = 0;
          ppppcStack_10c = (code ****)&DAT_0000000f;
          ppppiStack_128 = (int ****)0x192b178;
          pppcStack_120 = (code ***)((uint)pppcStack_120 & 0xffffff00);
          ppppiStack_12c = (int ****)0x90991b;
          FUN_005542c0();
          uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
          ppppiStack_124 = (int ****)0x909927;
          FUN_00901de0();
        }
        else {
          puStack_44 = (undefined *)&ppppiStack_104;
          uStack_68 = CONCAT31(uStack_68._1_3_,DAT_01ee05ac);
          ppppiStack_104 = (int ****)pppcStack_38;
          if (pppcStack_38 != (code ***)0x0) {
            LOCK();
            pppcStack_38[1] = (code **)((int)pppcStack_38[1] + 1);
            UNLOCK();
          }
          puStack_48 = (undefined *)&ppppiStack_124;
          puStack_2c = &ppppiStack_124;
          ppppiStack_140 = &pppiStack_84;
          if (param_3 != (code ***)0x0) {
            LOCK();
            param_3[1] = (code **)((int)param_3[1] + 1);
            UNLOCK();
          }
          ppppiStack_130 = (int ****)uStack_68;
          ppppiStack_12c = param_2;
          ppppiStack_128 = (int ****)param_3;
          ppppiStack_134 = ppppiStack_1c;
          puStack_138 = (undefined *)0x0;
          pcStack_13c = FUN_00901de0;
          ppppiStack_144 = (int ****)0x909635;
          FUN_008e0b60();
          puVar4 = puStack_2c;
          ppppiVar15 = ppppiStack_74;
          ppppiStack_134 = (int ****)puStack_78;
          pppiStack_30 = pppiStack_84;
          pcStack_34 = pcStack_80;
          ppppiStack_18 = (int ****)uStack_7c;
          if (ppppiStack_74 != (int ****)0x0) {
            LOCK();
            ppppiStack_74[1] = (int ***)((int)ppppiStack_74[1] + 1);
            UNLOCK();
          }
          ppppiStack_14 = ppppiStack_74;
          *puStack_2c = 0;
          if (ppppiVar15 != (int ****)0x0) {
            LOCK();
            ppppiVar15 = ppppiVar15 + 1;
            *ppppiVar15 = (int ***)((int)*ppppiVar15 + 1);
            UNLOCK();
          }
          ppppiStack_128 = (int ****)(puVar4 + 2);
          ppppiStack_140 = (int ****)pppiStack_30;
          pcStack_13c = pcStack_34;
          puStack_138 = (undefined *)ppppiStack_18;
          if (ppppiStack_14 != (int ****)0x0) {
            LOCK();
            ppppiStack_14[1] = (int ***)((int)ppppiStack_14[1] + 1);
            UNLOCK();
          }
          ppppiStack_130 = ppppiStack_14;
          ppppiStack_144 = (int ****)0x9096b5;
          cVar5 = FUN_008e0150();
          ppuVar10 = &PTR_FUN_0192d328;
          if (cVar5 == '\0') {
            ppuVar10 = (undefined **)0x0;
          }
          *puStack_2c = ppuVar10;
          if (ppppiStack_14 != (int ****)0x0) {
            LOCK();
            pppiVar8 = (int ***)((int)ppppiStack_14[1] + -1);
            ppppiStack_14[1] = pppiVar8;
            UNLOCK();
            if (pppiVar8 == (int ***)0x0) {
              ppppiStack_128 = (int ****)0x9096da;
              (*(code *)**ppppiStack_14)();
              LOCK();
              pppiVar8 = (int ***)((int)ppppiStack_14[2] + -1);
              ppppiStack_14[2] = pppiVar8;
              UNLOCK();
              if (pppiVar8 == (int ***)0x0) {
                ppppiStack_128 = (int ****)0x9096eb;
                (*(code *)(*ppppiStack_14)[1])();
              }
            }
            if (ppppiStack_14 != (int ****)0x0) {
              LOCK();
              pppiVar8 = (int ***)((int)ppppiStack_14[1] + -1);
              ppppiStack_14[1] = pppiVar8;
              UNLOCK();
              if (pppiVar8 == (int ***)0x0) {
                ppppiStack_128 = (int ****)0x9096ff;
                (*(code *)**ppppiStack_14)();
                LOCK();
                pppiVar8 = (int ***)((int)ppppiStack_14[2] + -1);
                ppppiStack_14[2] = pppiVar8;
                UNLOCK();
                if (pppiVar8 == (int ***)0x0) {
                  ppppiStack_128 = (int ****)0x909710;
                  (*(code *)(*ppppiStack_14)[1])();
                }
              }
            }
          }
          ppppiStack_18 = ppppiStack_74;
          if (ppppiStack_74 != (int ****)0x0) {
            LOCK();
            pppiVar8 = (int ***)((int)ppppiStack_74[1] + -1);
            ppppiStack_74[1] = pppiVar8;
            UNLOCK();
            if (pppiVar8 == (int ***)0x0) {
              ppppiStack_128 = (int ****)0x909727;
              (*(code *)**ppppiStack_74)();
              LOCK();
              pppiVar8 = (int ***)((int)ppppiStack_18[2] + -1);
              ppppiStack_18[2] = pppiVar8;
              UNLOCK();
              if (pppiVar8 == (int ***)0x0) {
                ppppiStack_128 = (int ****)0x909738;
                (*(code *)(*ppppiStack_18)[1])();
              }
            }
          }
          puStack_4c = (undefined *)&ppppiStack_144;
          puStack_2c = &ppppiStack_144;
          if (param_3 != (code ***)0x0) {
            LOCK();
            param_3[1] = (code **)((int)param_3[1] + 1);
            UNLOCK();
          }
          ppppiStack_14c = param_2;
          ppppiStack_148 = (int ****)param_3;
          FUN_008ab6d0(&pppiStack_64,FUN_00901ee0,0,ppppiStack_1c);
          puVar4 = puStack_2c;
          ppppiVar15 = ppppiStack_54;
          puVar3 = puStack_58;
          ppppiStack_18 = (int ****)pppiStack_64;
          pcStack_34 = pcStack_60;
          pppiStack_30 = (int ***)uStack_5c;
          if (ppppiStack_54 != (int ****)0x0) {
            LOCK();
            ppppiStack_54[1] = (int ***)((int)ppppiStack_54[1] + 1);
            UNLOCK();
          }
          ppppiStack_14 = ppppiStack_54;
          *puStack_2c = 0;
          if (ppppiVar15 != (int ****)0x0) {
            LOCK();
            ppppiVar15 = ppppiVar15 + 1;
            *ppppiVar15 = (int ***)((int)*ppppiVar15 + 1);
            UNLOCK();
          }
          ppppiStack_148 = (int ****)(puVar4 + 2);
          if (ppppiStack_14 != (int ****)0x0) {
            LOCK();
            ppppiStack_14[1] = (int ***)((int)ppppiStack_14[1] + 1);
            UNLOCK();
          }
          cVar5 = FUN_008e0150(ppppiStack_18,pcStack_34,pppiStack_30,puVar3,ppppiStack_14);
          ppuVar10 = &PTR_FUN_0192d320;
          if (cVar5 == '\0') {
            ppuVar10 = (undefined **)0x0;
          }
          *puStack_2c = ppuVar10;
          if (ppppiStack_14 != (int ****)0x0) {
            LOCK();
            pppiVar8 = (int ***)((int)ppppiStack_14[1] + -1);
            ppppiStack_14[1] = pppiVar8;
            UNLOCK();
            if (pppiVar8 == (int ***)0x0) {
              ppppiStack_148 = (int ****)0x909821;
              (*(code *)**ppppiStack_14)();
              LOCK();
              pppiVar8 = (int ***)((int)ppppiStack_14[2] + -1);
              ppppiStack_14[2] = pppiVar8;
              UNLOCK();
              if (pppiVar8 == (int ***)0x0) {
                ppppiStack_148 = (int ****)0x909832;
                (*(code *)(*ppppiStack_14)[1])();
              }
            }
            if (ppppiStack_14 != (int ****)0x0) {
              LOCK();
              pppiVar8 = (int ***)((int)ppppiStack_14[1] + -1);
              ppppiStack_14[1] = pppiVar8;
              UNLOCK();
              if (pppiVar8 == (int ***)0x0) {
                ppppiStack_148 = (int ****)0x909846;
                (*(code *)**ppppiStack_14)();
                LOCK();
                pppiVar8 = (int ***)((int)ppppiStack_14[2] + -1);
                ppppiStack_14[2] = pppiVar8;
                UNLOCK();
                if (pppiVar8 == (int ***)0x0) {
                  ppppiStack_148 = (int ****)0x909857;
                  (*(code *)(*ppppiStack_14)[1])();
                }
              }
            }
          }
          ppppiStack_18 = ppppiStack_54;
          if (ppppiStack_54 != (int ****)0x0) {
            LOCK();
            pppiVar8 = (int ***)((int)ppppiStack_54[1] + -1);
            ppppiStack_54[1] = pppiVar8;
            UNLOCK();
            if (pppiVar8 == (int ***)0x0) {
              ppppiStack_148 = (int ****)0x90986e;
              (*(code *)**ppppiStack_54)();
              LOCK();
              pppiVar8 = (int ***)((int)ppppiStack_18[2] + -1);
              ppppiStack_18[2] = pppiVar8;
              UNLOCK();
              if (pppiVar8 == (int ***)0x0) {
                ppppiStack_148 = (int ****)0x90987f;
                (*(code *)(*ppppiStack_18)[1])();
              }
            }
          }
          puStack_3c = (undefined *)&ppppiStack_14c;
          if (ppppiStack_28 != (int ****)0x0) {
            LOCK();
            ppppiStack_28[1] = (int ***)((int)ppppiStack_28[1] + 1);
            UNLOCK();
          }
          ppppiStack_14c = ppppiStack_28 + 3;
          ppppiStack_148 = ppppiStack_28;
          uStack_8._0_1_ = 0x10;
          FUN_00d88580(auStack_f8);
          uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
          FUN_0094a8d0();
        }
        if (ppppiStack_20 != (int ****)0x0) {
          LOCK();
          pppiVar8 = *ppppiStack_20;
          *ppppiStack_20 = (int ***)((int)*ppppiStack_20 + -1);
          UNLOCK();
          if (pppiVar8 == (int ***)0x1) {
            ppppiStack_104 = (int ****)0x90993e;
            FUN_00d88950();
            ppppiStack_104 = (int ****)0x10;
            ppppcStack_108 = (code ****)ppppiStack_20;
            ppppcStack_10c = (code ****)0x909948;
            FUN_01674ea0();
          }
        }
        LOCK();
        DAT_01e90cd4 = DAT_01e90cd4 + -1;
        UNLOCK();
      }
      if (ppppiStack_28 != (int ****)0x0) {
        LOCK();
        pppiVar8 = (int ***)((int)ppppiStack_28[1] + -1);
        ppppiStack_28[1] = pppiVar8;
        UNLOCK();
        if (pppiVar8 == (int ***)0x0) {
          ppppiStack_104 = (int ****)0x909c3d;
          (*(code *)**ppppiStack_28)();
          LOCK();
          pppiVar8 = (int ***)((int)ppppiStack_28[2] + -1);
          ppppiStack_28[2] = pppiVar8;
          UNLOCK();
          if (pppiVar8 == (int ***)0x0) {
            ppppiStack_104 = (int ****)0x909c4e;
            (*(code *)(*ppppiStack_28)[1])();
          }
        }
      }
      if (pppcStack_38 != (code ***)0x0) {
        pppcVar1 = pppcStack_38 + 1;
        LOCK();
        ppcVar9 = *pppcVar1;
        *pppcVar1 = (code **)((int)*pppcVar1 + -1);
        UNLOCK();
        if (((ppcVar9 == (code **)0x1) && (pppcVar1 != (code ***)0x0)) &&
           (pppcStack_38 != (code ***)0x0)) {
          ppppiStack_104 = (int ****)0x1;
          ppppcStack_108 = (code ****)0x909c73;
          (*(*pppcStack_38)[1])();
        }
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      ppppiStack_104 = (int ****)0x909c82;
      FUN_00d88a30();
      pppiVar11 = (int ***)*pppiVar11;
    } while (pppiVar11 != ppppiStack_1c[0x124]);
  }
  if (param_3 != (code ***)0x0) {
    LOCK();
    param_3[1] = (code **)((int)param_3[1] + 1);
    UNLOCK();
  }
  ppppcStack_108 = (code ****)param_2;
  ppppiStack_104 = (int ****)param_3;
  ppppcStack_10c = (code ****)0x909cc7;
  ppcVar9 = (code **)FUN_00901d30();
  ppppiVar15 = ppppiStack_40;
  if (ppppiStack_40 != (int ****)0x0) {
    ppppiStack_104 = (int ****)0x909cd5;
    FUN_008eafb0();
    ppppiStack_104 = (int ****)0x1c;
    ppppcStack_108 = (code ****)ppppiVar15;
    ppppcStack_10c = (code ****)0x909cdd;
    ppcVar9 = (code **)FUN_01674ea0();
  }
  if (param_3 != (code ***)0x0) {
    LOCK();
    pppcVar1 = param_3 + 1;
    ppcVar2 = *pppcVar1;
    ppcVar9 = *pppcVar1;
    *pppcVar1 = (code **)((int)ppcVar2 + -1);
    UNLOCK();
    if ((code **)((int)ppcVar2 + -1) == (code **)0x0) {
      ppppiStack_104 = (int ****)0x909cf6;
      ppcVar9 = (code **)(***param_3)();
      LOCK();
      pppcVar1 = param_3 + 2;
      ppcVar2 = *pppcVar1;
      *pppcVar1 = (code **)((int)*pppcVar1 + -1);
      UNLOCK();
      if (ppcVar2 == (code **)0x1) {
        ppppiStack_104 = (int ****)0x909d05;
        ppcVar9 = (code **)(*(*param_3)[1])();
      }
    }
  }
  ExceptionList = pvStack_10;
  return ppcVar9;
}



/* FUNCTION 15917 ; VA 0x00909d30 ; FUN_00909d30 */

void FUN_00909d30(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined auStack_10 [12];
  
  uVar2 = FUN_01255560();
  cVar1 = FUN_01255580(uVar2,5);
  if (cVar1 == '\0') {
    FUN_01255600(5,0);
  }
  if (param_1 == 5) {
    return;
  }
  FUN_00550130(&DAT_018bc9b8);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_10,&DAT_01c17198);
}



/* FUNCTION 15918 ; VA 0x00909d80 ; FUN_00909d80 */

void __thiscall FUN_00909d80(int param_1,undefined4 param_2)

{
  uint uVar1;
  undefined4 uVar2;
  uint *puVar3;
  uint *puVar4;
  uint uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c52f0;
  pvStack_10 = ExceptionList;
  if (DAT_01d5a508 != '\0') {
    puStack_14 = *(uint **)(param_1 + 0x280);
    puVar3 = *(uint **)(param_1 + 0x27c);
    if (puVar3 != puStack_14) {
      puVar4 = puVar3 + 2;
      ExceptionList = &pvStack_10;
      do {
        uStack_8 = 0xffffffff;
        uVar1 = *puVar3;
        uStack_40 = 0;
        if (uVar1 != 0) {
          uStack_40 = uVar1;
          if ((uVar1 & 1) == 0) {
            (**(code **)(uVar1 & 0xfffffffe))(puVar4,&uStack_38,0);
          }
          else {
            uStack_38 = *puVar4;
            uStack_34 = puVar4[1];
            uStack_30 = puVar4[2];
            uStack_2c = puVar4[3];
            uStack_28 = puVar4[4];
            uStack_24 = puVar4[5];
          }
        }
        uStack_8 = 0;
        if (uStack_40 == 0) {
          uVar2 = FUN_0054fda0();
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
                    /* WARNING: Subroutine does not return */
          FUN_0054e5e0(uVar2);
        }
        (**(code **)((uStack_40 & 0xfffffffe) + 4))(&uStack_38,param_2);
        uStack_8 = 2;
        if (((uStack_40 != 0) && ((uStack_40 & 1) == 0)) &&
           (*(code **)(uStack_40 & 0xfffffffe) != (code *)0x0)) {
          (**(code **)(uStack_40 & 0xfffffffe))(&uStack_38,&uStack_38,2);
        }
        puVar3 = puVar3 + 8;
        puVar4 = puVar4 + 8;
      } while (puVar3 != puStack_14);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15919 ; VA 0x00909e80 ; FUN_00909e80 */

void FUN_00909e80(float *param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  
  fVar1 = param_2[1];
  if (fVar1 < 0.0) {
    fVar1 = fVar1 - DAT_018ce2f4;
  }
  else {
    fVar1 = fVar1 + DAT_018ce2f4;
  }
  fVar2 = *param_2;
  if (fVar2 < 0.0) {
    fVar2 = fVar2 - DAT_018ce2f4;
  }
  else {
    fVar2 = fVar2 + DAT_018ce2f4;
  }
  param_1[1] = (float)(int)fVar1;
  *param_1 = (float)(int)fVar2;
  return;
}



/* FUNCTION 15920 ; VA 0x00909ee0 ; FUN_00909ee0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * __fastcall FUN_00909ee0(undefined4 param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c530c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee05f0) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee05f0,param_1);
    if (DAT_01ee05f0 == -1) {
      uStack_8 = 0;
      uVar1 = FUN_008e4ea0();
      _DAT_01ee05e8 = uVar1;
      FUN_008db180(uVar1,param_1);
      _guard_check_icall(&DAT_01ee05e8,uVar1,uVar1);
      FUN_016f3654(FUN_018832c0);
      FUN_016f37bf(&DAT_01ee05f0);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee05e8;
}



/* FUNCTION 15921 ; VA 0x00909f90 ; FUN_00909f90 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * __fastcall FUN_00909f90(undefined4 param_1)

{
  undefined4 *puVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c532c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee05dc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee05dc,param_1);
    if (DAT_01ee05dc == -1) {
      uStack_8 = 0;
      DAT_01ee05c4 = (undefined4 *)0x0;
      _DAT_01ee05c8 = 0;
      _DAT_01ee05cc = 0;
      _DAT_01ee05d0 = 0;
      _DAT_01ee05d4 = 0;
      puVar1 = (undefined4 *)FUN_01674e20(8);
      DAT_01ee05c4 = puVar1;
      *puVar1 = 0;
      puVar1[1] = 0;
      *DAT_01ee05c4 = &DAT_01ee05c4;
      _DAT_01ee05d8 = 0;
      FUN_016f3654(&LAB_01883350);
      FUN_016f37bf(&DAT_01ee05dc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee05c4;
}



/* FUNCTION 15922 ; VA 0x0090a0a0 ; FUN_0090a0a0 */

void FUN_0090a0a0(undefined4 param_1)

{
  char cVar1;
  int iVar2;
  code *pcStack_c;
  undefined4 uStack_8;
  
  if ((DAT_01d65a50 == '\0') ||
     ((iVar2 = FUN_005cf8d0(), DAT_01ee5c3c < 10000 &&
      ((iVar2 == 0 || (*(char *)(iVar2 + 0xee) == '\0')))))) {
    FUN_005e6850(0,0,0);
  }
  else {
    FUN_005ea890(&pcStack_c,0,0);
  }
  FUN_005cf2a0();
  pcStack_c = FUN_0090a0a0;
  uStack_8 = param_1;
  cVar1 = FUN_00585a40(&pcStack_c);
  if (cVar1 == '\0') {
    FUN_009eef30(&DAT_0192d3d9);
    return;
  }
  FUN_009eef30(0);
  return;
}



/* FUNCTION 15923 ; VA 0x0090a180 ; FUN_0090a180 */

void __thiscall FUN_0090a180(int param_1,undefined4 param_2,uint param_3)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  bool bVar6;
  uint in_stack_00000028;
  char *pcStack_48;
  undefined4 uStack_44;
  undefined uStack_40;
  undefined4 uStack_38;
  undefined *puStack_34;
  undefined *puStack_30;
  undefined4 *puStack_2c;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c5358;
  pvStack_10 = ExceptionList;
  piVar3 = *(int **)(param_1 + 0x43c);
  uStack_8 = 1;
  bVar6 = -1 < piVar3[1] - (int)piVar3;
  if (((int *)piVar3[1] != piVar3 && bVar6) || ((bVar6 && ((int *)*piVar3 != piVar3)))) {
    puStack_2c = &uStack_20;
    puStack_30 = (undefined *)0x90a1d9;
    ExceptionList = &pvStack_10;
    FUN_016830f0();
    if ((double)CONCAT44(uStack_1c,uStack_20) - *(double *)(param_1 + 0x178) <= DAT_018cf108) {
      iVar2 = *(int *)(param_1 + 0x160);
    }
    else {
      *(undefined4 *)(param_1 + 0x178) = uStack_20;
      *(undefined4 *)(param_1 + 0x17c) = uStack_1c;
      iVar2 = 0;
      *(undefined4 *)(param_1 + 0x164) = 0;
    }
    piVar3 = *(int **)(param_1 + 0x170);
    *(int *)(param_1 + 0x160) = iVar2 + 1;
    iVar5 = *(int *)(param_1 + 0x164);
    if (iVar5 < 1) {
      iVar5 = 0;
    }
    *(int *)(param_1 + 0x164) = iVar5;
    if (piVar3 == (int *)0x0) {
      piVar3 = *(int **)(param_1 + 0x168);
    }
    iVar4 = *piVar3;
    if (*(int **)(param_1 + 0x16c) != (int *)0x0) {
      iVar4 = iVar4 + **(int **)(param_1 + 0x16c) * iVar5;
    }
    if (iVar4 < iVar2 + 1) {
      uStack_44 = 0x25;
      pcStack_48 = "Game:SavePlace requests limit reached";
    }
    else {
      puStack_2c = (undefined4 *)0x1;
      puStack_34 = (undefined *)0x90a275;
      puStack_30 = (undefined *)(param_1 + 0xc);
      cVar1 = FUN_0097c970();
      if (cVar1 == '\0') {
        puStack_2c = (undefined4 *)0x1;
        puStack_34 = (undefined *)0x90a292;
        puStack_30 = (undefined *)(param_1 + 0xc);
        cVar1 = FUN_00971ce0();
        if (cVar1 != '\0') {
          puStack_2c = (undefined4 *)&LAB_0090a370;
          puStack_30 = &DAT_01ee05bc;
          puStack_34 = (undefined *)0x90a2a8;
          FUN_005789c0();
          puStack_14 = (undefined *)&pcStack_48;
          FUN_0054f510(&stack0x00000028);
          uStack_8._0_1_ = 2;
          FUN_0054f510(&param_3);
          uStack_8 = CONCAT31(uStack_8._1_3_,1);
          FUN_0090a390();
          goto LAB_0090a302;
        }
        uStack_44 = 0x36;
        pcStack_48 = "Game:SavePlace could not determine if client or server";
      }
      else {
        uStack_44 = 0x4e;
        pcStack_48 = 
        "Game:SavePlace can only be called from a server script, aborting save function";
      }
    }
  }
  else {
    uStack_44 = 0x24;
    pcStack_48 = "Game:SavePlace placeID is not valid!";
    ExceptionList = &pvStack_10;
  }
  puStack_30 = (undefined *)0x0;
  puStack_2c = (undefined4 *)0xf;
  uStack_40 = 0;
  FUN_005542c0();
  uStack_44 = 0x90a302;
  FUN_005e65e0();
LAB_0090a302:
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if (param_3 != 0) {
    if (((param_3 & 1) == 0) && (*(code **)(param_3 & 0xfffffffe) != (code *)0x0)) {
      puStack_34 = &stack0x00000010;
      puStack_2c = (undefined4 *)0x2;
      uStack_38 = 0x90a323;
      puStack_30 = puStack_34;
      (**(code **)(param_3 & 0xfffffffe))();
    }
    param_3 = 0;
  }
  uStack_8 = 4;
  if (((in_stack_00000028 != 0) && ((in_stack_00000028 & 1) == 0)) &&
     (*(code **)(in_stack_00000028 & 0xfffffffe) != (code *)0x0)) {
    puStack_34 = &stack0x00000030;
    puStack_2c = (undefined4 *)0x2;
    uStack_38 = 0x90a351;
    puStack_30 = puStack_34;
    (**(code **)(in_stack_00000028 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15924 ; VA 0x0090a390 ; FUN_0090a390 */

void __thiscall
FUN_0090a390(int param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined8 param_8,uint param_9,
            undefined4 param_10,undefined4 param_11,undefined4 param_12,undefined4 param_13,
            undefined4 param_14,undefined8 param_15)

{
  undefined uVar1;
  undefined *puVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 ****ppppuVar5;
  uint *puVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  uint auStack_118 [2];
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined8 uStack_100;
  undefined4 uStack_f8;
  undefined auStack_f4 [36];
  undefined4 uStack_d0;
  uint *puStack_cc;
  undefined4 uStack_b8;
  undefined4 *puStack_b4;
  undefined4 *puStack_b0;
  undefined4 uStack_ac;
  uint auStack_a8 [2];
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 *puStack_94;
  undefined8 uStack_90;
  undefined4 ***apppuStack_80 [4];
  int iStack_70;
  uint uStack_6c;
  undefined4 ***pppuStack_68;
  int iStack_64;
  int iStack_60;
  int iStack_5c;
  undefined8 uStack_58;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  undefined8 uStack_40;
  uint uStack_38;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined *puStack_1c;
  undefined *puStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c53c1;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  piVar3 = *(int **)(param_1 + 0x43c);
  uStack_8 = 1;
  iVar7 = piVar3[1] - (int)piVar3;
  iVar8 = *piVar3 - (int)piVar3;
  if ((iVar7 < 1) && (iVar7 < 0)) {
    puStack_94 = (undefined4 *)((int)&uStack_24 + 1);
    uStack_90 = CONCAT44(-(iVar7 + (uint)(iVar8 != 0)),-iVar8);
    uStack_98 = 0x90a3e8;
    ExceptionList = &pvStack_10;
    iVar7 = FUN_0055c3d0();
    *(undefined *)(iVar7 + -1) = 0x2d;
    iVar7 = iVar7 + -1;
  }
  else {
    uStack_90 = CONCAT44(iVar7,iVar8);
    puStack_94 = (undefined4 *)((int)&uStack_24 + 1);
    uStack_98 = 0x90a3fc;
    ExceptionList = &pvStack_10;
    iVar7 = FUN_0055c3d0();
  }
  uStack_40._0_4_ = 0;
  uStack_40._4_4_ = 0xf;
  uStack_50 = uStack_50 & 0xffffff00;
  if (iVar7 != (int)&uStack_24 + 1) {
    uStack_90 = CONCAT44(((int)&uStack_24 + 1) - iVar7,iVar7);
    puStack_94 = (undefined4 *)0x90a426;
    FUN_005542c0();
  }
  uStack_90 = 0x90192ad10;
  puStack_94 = (undefined4 *)0x0;
  uStack_8._0_1_ = 2;
  uStack_98 = 0x90a43b;
  piVar3 = (int *)FUN_00585d40();
  pppuStack_68 = (undefined4 ***)*piVar3;
  iStack_64 = piVar3[1];
  iStack_60 = piVar3[2];
  iStack_5c = piVar3[3];
  uStack_58 = *(undefined8 *)(piVar3 + 4);
  piVar3[4] = 0;
  piVar3[5] = 0xf;
  *(undefined *)piVar3 = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  if (0xf < uStack_40._4_4_) {
    uVar9 = uStack_40._4_4_ + 1;
    uVar10 = uStack_50;
    if (0xfff < uVar9) {
      uVar10 = *(uint *)(uStack_50 - 4);
      uVar9 = uStack_40._4_4_ + 0x24;
      if (0x1f < (uStack_50 - uVar10) - 4) {
        uStack_90 = CONCAT44(0x90a7a4,(undefined4)uStack_90);
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_90 = CONCAT44(uVar9,uVar10);
    puStack_94 = (undefined4 *)0x90a492;
    FUN_01674ea0();
  }
  uStack_90 = 0x130192ad1c;
  uStack_40 = 0xf00000000;
  uStack_50 = uStack_50 & 0xffffff00;
  puStack_94 = (undefined4 *)0x90a4b6;
  FUN_00554150();
  if (param_1 != -0xc) {
    uStack_90 = CONCAT44(0x90a4c2,(undefined4)uStack_90);
    FUN_005c2760();
  }
  uStack_90 = CONCAT44(0x90a4cd,(undefined4)uStack_90);
  uVar4 = FUN_008cd320();
  uStack_90 = CONCAT44(uVar4,0x90a4d6);
  FUN_0054ef60();
  uStack_8._0_1_ = 6;
  uStack_28 = 0;
  uStack_24 = 0xf;
  uStack_38 = uStack_38 & 0xffffff00;
  uStack_14 = 0xf;
  uStack_90 = CONCAT44(iStack_70 + 0x1f,0x90a502);
  FUN_0058a190();
  ppppuVar5 = apppuStack_80;
  if (0xf < uStack_6c) {
    ppppuVar5 = (undefined4 ****)apppuStack_80[0];
  }
  uStack_90 = CONCAT44(iStack_70,ppppuVar5);
  puStack_94 = (undefined4 *)0x90a517;
  FUN_00554150();
  uStack_90 = 0x1f0192ad30;
  puStack_94 = (undefined4 *)0x90a526;
  FUN_00554150();
  ppppuVar5 = &pppuStack_68;
  if (0xf < uStack_58._4_4_) {
    ppppuVar5 = (undefined4 ****)pppuStack_68;
  }
  uStack_90 = CONCAT44((int)uStack_58,ppppuVar5);
  puStack_94 = (undefined4 *)0x90a53d;
  puVar6 = (uint *)FUN_00554150();
  uStack_14 = 0x1f;
  uStack_50 = *puVar6;
  uStack_4c = puVar6[1];
  uStack_48 = puVar6[2];
  uStack_44 = puVar6[3];
  uStack_40 = *(undefined8 *)(puVar6 + 4);
  puVar6[4] = 0;
  puVar6[5] = 0xf;
  *(undefined *)puVar6 = 0;
  puStack_1c = (undefined *)auStack_a8;
  puStack_18 = (undefined *)auStack_a8;
  uStack_8._0_1_ = 7;
  auStack_a8[0] = 0;
  puVar6 = auStack_a8;
  if (param_9 != 0) {
    auStack_a8[0] = param_9;
    if ((param_9 & 1) == 0) {
      puStack_b0 = &uStack_a0;
      uStack_ac = 0;
      puStack_b4 = &param_11;
      uStack_b8 = 0x90a5bc;
      (**(code **)(param_9 & 0xfffffffe))();
      puVar6 = (uint *)puStack_1c;
    }
    else {
      uStack_a0 = param_11;
      uStack_9c = param_12;
      uStack_98 = param_13;
      puStack_94 = (undefined4 *)param_14;
      uStack_90 = param_15;
      puVar6 = auStack_a8;
    }
  }
  puStack_1c = (undefined *)puVar6;
  uStack_8._0_1_ = 8;
  puStack_cc = (uint *)0x0;
  puStack_18 = auStack_f4;
  uStack_f8 = 1;
  puStack_20 = (undefined *)auStack_118;
  auStack_118[0] = 0;
  puVar6 = auStack_118;
  puVar2 = auStack_f4;
  if (param_2 != 0) {
    auStack_118[0] = param_2;
    if ((param_2 & 1) == 0) {
      (**(code **)(param_2 & 0xfffffffe))(&param_4,&uStack_110,0);
      puVar6 = (uint *)puStack_20;
      puVar2 = puStack_18;
    }
    else {
      uStack_110 = param_4;
      uStack_10c = param_5;
      uStack_108 = param_6;
      uStack_104 = param_7;
      uStack_100 = param_8;
      puVar6 = auStack_118;
      puVar2 = auStack_f4;
    }
  }
  puStack_18 = puVar2;
  puStack_20 = (undefined *)puVar6;
  FUN_008e0670(puStack_18);
  uStack_f8 = 0x90a628;
  FUN_008dbb40();
  puStack_cc = &uStack_50;
  uStack_8._0_1_ = 7;
  uStack_d0 = 0x90a637;
  FUN_005ec3f0();
  uStack_8._0_1_ = 6;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 6;
  if (0xf < uStack_40._4_4_) {
    uVar9 = uStack_40._4_4_ + 1;
    uVar10 = uStack_50;
    if (0xfff < uVar9) {
      uVar10 = *(uint *)(uStack_50 - 4);
      uVar9 = uStack_40._4_4_ + 0x24;
      if (0x1f < (uStack_50 - uVar10) - 4) {
        uStack_90 = CONCAT44(0x90a7a9,(undefined4)uStack_90);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_90 = CONCAT44(uVar9,uVar10);
    puStack_94 = (undefined4 *)0x90a66c;
    FUN_01674ea0();
  }
  uStack_40 = 0xf00000000;
  uStack_50 = uStack_50 & 0xffffff00;
  uStack_8._0_1_ = 5;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 5;
  if (0xf < uStack_24) {
    uVar9 = uStack_24 + 1;
    uVar10 = uStack_38;
    if (0xfff < uVar9) {
      uVar10 = *(uint *)(uStack_38 - 4);
      uVar9 = uStack_24 + 0x24;
      if (0x1f < (uStack_38 - uVar10) - 4) {
        uStack_90 = CONCAT44(0x90a7ae,(undefined4)uStack_90);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_90 = CONCAT44(uVar9,uVar10);
    puStack_94 = (undefined4 *)0x90a6b6;
    FUN_01674ea0();
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  uStack_38 = uStack_38 & 0xffffff00;
  uStack_8._0_1_ = 4;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 4;
  if (0xf < uStack_6c) {
    uVar10 = uStack_6c + 1;
    ppppuVar5 = (undefined4 ****)apppuStack_80[0];
    if (0xfff < uVar10) {
      ppppuVar5 = (undefined4 ****)apppuStack_80[0][-1];
      uVar10 = uStack_6c + 0x24;
      if (0x1f < (uint)((int)apppuStack_80[0] + (-4 - (int)ppppuVar5))) {
        uStack_90 = CONCAT44(0x90a7b3,(undefined4)uStack_90);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_90 = CONCAT44(uVar10,ppppuVar5);
    puStack_94 = (undefined4 *)0x90a700;
    FUN_01674ea0();
  }
  uStack_8._0_1_ = 1;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 1;
  if (0xf < uStack_58._4_4_) {
    uVar10 = uStack_58._4_4_ + 1;
    ppppuVar5 = (undefined4 ****)pppuStack_68;
    if (0xfff < uVar10) {
      ppppuVar5 = (undefined4 ****)pppuStack_68[-1];
      uVar10 = uStack_58._4_4_ + 0x24;
      if (0x1f < (uint)((int)pppuStack_68 + (-4 - (int)ppppuVar5))) {
        uStack_90 = CONCAT44(&UNK_0090a7b8,(undefined4)uStack_90);
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    uStack_90 = CONCAT44(uVar10,ppppuVar5);
    puStack_94 = (undefined4 *)0x90a738;
    FUN_01674ea0();
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  if (((param_2 != 0) && ((param_2 & 1) == 0)) && (*(code **)(param_2 & 0xfffffffe) != (code *)0x0))
  {
    puStack_94 = &param_4;
    uStack_90 = CONCAT44(2,puStack_94);
    uStack_98 = 0x90a75c;
    (**(code **)(param_2 & 0xfffffffe))();
  }
  uStack_8 = 10;
  if (((param_9 != 0) && ((param_9 & 1) == 0)) && (*(code **)(param_9 & 0xfffffffe) != (code *)0x0))
  {
    puStack_94 = &param_11;
    uStack_90 = CONCAT44(2,puStack_94);
    uStack_98 = 0x90a78a;
    (**(code **)(param_9 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15925 ; VA 0x0090a7c0 ; FUN_0090a7c0 */

void __thiscall FUN_0090a7c0(int param_1,int param_2)

{
  if (param_2 != *(int *)(param_1 + 0x244)) {
    *(int *)(param_1 + 0x244) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 15926 ; VA 0x0090a7f0 ; FUN_0090a7f0 */

void __thiscall FUN_0090a7f0(int param_1,char param_2)

{
  char cVar1;
  
  if (DAT_01ee04ac != '\0') {
    FUN_016774b0(DAT_01ee04ac,"DataModel::requestGameStartInfo setCanRequestUniverseInfo",0);
  }
  if (param_2 != *(char *)(param_1 + 0x248)) {
    if (DAT_01ee04ac != '\0') {
      FUN_016774b0(DAT_01ee04ac,"DataModel::requestGameStartInfo setCanRequestUniverseInfo setting",
                   0);
    }
    *(char *)(param_1 + 0x248) = param_2;
    if ((param_2 != '\0') && (*(char *)(param_1 + 0x249) != '\0')) {
      cVar1 = FUN_00971ce0(param_1 + 0xc,1);
      if (cVar1 != '\0') {
        FUN_00908980(0);
      }
    }
  }
  return;
}



/* FUNCTION 15927 ; VA 0x0090a890 ; FUN_0090a890 */

void __thiscall FUN_0090a890(int param_1,int param_2,int param_3,int param_4)

{
  int *piVar1;
  
  piVar1 = *(int **)(param_1 + 0x454);
  if ((*piVar1 - (int)piVar1 != param_2) || (piVar1[1] - (int)piVar1 != param_3)) {
    *piVar1 = param_2 + (int)piVar1;
    piVar1[1] = param_3 + (int)piVar1;
    FUN_008a4940(&DAT_0211c624);
  }
  if (*(int *)(param_1 + 0x458) != param_4) {
    *(int *)(param_1 + 0x458) = param_4;
    FUN_008a4940(&DAT_0211c758);
  }
  return;
}



/* FUNCTION 15928 ; VA 0x0090a900 ; FUN_0090a900 */

void __thiscall FUN_0090a900(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0x1d8) = param_2;
  return;
}



/* FUNCTION 15929 ; VA 0x0090a910 ; FUN_0090a910 */

undefined __thiscall FUN_0090a910(int param_1,int param_2)

{
  code *pcVar1;
  char cVar2;
  undefined uVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  uint in_stack_00000018;
  undefined in_stack_0000001c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  cVar2 = FUN_00baac40();
  if (cVar2 == '\0') {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("FastFlag Test API is not available");
  }
  iVar6 = param_1 + 0x4d5 + (uint)*(byte *)(param_1 + 0x4d4);
  uVar4 = FUN_005702d0(&param_2);
  FUN_00562fc0(&iStack_14,uVar4,&param_2,-(uint)(iVar6 != 0) & iVar6 + 1U);
  if (iStack_14 != 0) {
    uVar3 = FUN_008e4c40(&param_2);
    FUN_00602370(&stack0x0000001c);
    if (0xf < in_stack_00000018) {
      uVar5 = in_stack_00000018 + 1;
      iVar6 = param_2;
      if (0xfff < uVar5) {
        iVar6 = *(int *)(param_2 + -4);
        uVar5 = in_stack_00000018 + 0x24;
        if (0x1f < (param_2 - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar6,uVar5);
    }
    ExceptionList = pvStack_10;
    return uVar3;
  }
  FUN_00910e70(&param_2);
  pcVar1 = (code *)swi(3);
  uVar3 = (*pcVar1)();
  return uVar3;
}



/* FUNCTION 15930 ; VA 0x0090aa00 ; FUN_0090aa00 */

undefined4 __thiscall FUN_0090aa00(int param_1,int param_2)

{
  int iVar1;
  code *pcVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  uint in_stack_00000018;
  undefined4 in_stack_0000001c;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  cVar3 = FUN_00baac40();
  if (cVar3 == '\0') {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("FastFlag Test API is not available");
  }
  iVar8 = param_1 + 0x4d5 + (uint)*(byte *)(param_1 + 0x4d4);
  uVar4 = FUN_005702d0(&param_2);
  FUN_00562fc0(&iStack_14,uVar4,&param_2,-(uint)(iVar8 != 0) & iVar8 + 1U);
  iVar8 = iStack_14;
  if (iStack_14 != 0) {
    uVar4 = FUN_008e4770(&param_2);
    uVar5 = FUN_0088c8c0();
    *(undefined4 *)(iVar8 + 0x20) = uVar5;
    iVar6 = FUN_005c9cc0();
    iVar1 = *(int *)(iVar8 + 0x24);
    if (iVar1 == iVar6) {
      *(undefined4 *)(iVar8 + 0x28) = in_stack_0000001c;
    }
    else {
      if (iVar1 != 0) {
        (**(code **)(iVar1 + 8))(iVar8 + 0x28);
      }
      *(undefined4 *)(iVar8 + 0x28) = in_stack_0000001c;
      *(int *)(iVar8 + 0x24) = iVar6;
    }
    if (0xf < in_stack_00000018) {
      uVar7 = in_stack_00000018 + 1;
      iVar8 = param_2;
      if (0xfff < uVar7) {
        iVar8 = *(int *)(param_2 + -4);
        uVar7 = in_stack_00000018 + 0x24;
        if (0x1f < (param_2 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar8,uVar7);
    }
    ExceptionList = pvStack_10;
    return uVar4;
  }
  FUN_00910e70(&param_2);
  pcVar2 = (code *)swi(3);
  uVar4 = (*pcVar2)();
  return uVar4;
}



/* FUNCTION 15931 ; VA 0x0090ab20 ; FUN_0090ab20 */

undefined4 __thiscall FUN_0090ab20(int param_1,undefined4 param_2,uint param_3)

{
  code *pcVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 ***pppuVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  undefined4 in_stack_00000018;
  uint in_stack_0000001c;
  int in_stack_00000020;
  uint in_stack_00000034;
  undefined4 **appuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c5401;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_0054ef60(&stack0x00000020);
  uStack_8 = 3;
  cVar2 = FUN_00baac40();
  if (cVar2 == '\0') {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("FastFlag Test API is not available");
  }
  iVar8 = param_1 + 0x4d5 + (uint)*(byte *)(param_1 + 0x4d4);
  uVar3 = FUN_005702d0(&param_3);
  FUN_00562fc0(&iStack_14,uVar3,&param_3,-(uint)(iVar8 != 0) & iVar8 + 1U);
  if (iStack_14 != 0) {
    FUN_008e49a0(param_2,&param_3);
    uStack_18 = 2;
    uVar3 = FUN_0088cb40();
    *(undefined4 *)(iStack_14 + 0x20) = uVar3;
    iVar4 = FUN_005c9d30();
    iVar8 = *(int *)(iStack_14 + 0x24);
    if (iVar8 == iVar4) {
      if ((undefined4 ***)(iStack_14 + 0x28) != appuStack_30) {
        pppuVar5 = appuStack_30;
        if (0xf < uStack_1c) {
          pppuVar5 = (undefined4 ***)appuStack_30[0];
        }
        FUN_005542c0(pppuVar5,uStack_20);
      }
    }
    else {
      if (iVar8 != 0) {
        (**(code **)(iVar8 + 8))(iStack_14 + 0x28);
        *(undefined4 *)(iStack_14 + 0x24) = 0;
      }
      FUN_0054ef60(appuStack_30);
      *(int *)(iStack_14 + 0x24) = iVar4;
    }
    FUN_005507b0();
    if (0xf < in_stack_0000001c) {
      uVar6 = in_stack_0000001c + 1;
      uVar7 = param_3;
      if (0xfff < uVar6) {
        uVar7 = *(uint *)(param_3 - 4);
        uVar6 = in_stack_0000001c + 0x24;
        if (0x1f < (param_3 - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar6);
    }
    in_stack_00000018 = 0;
    in_stack_0000001c = 0xf;
    param_3 = param_3 & 0xffffff00;
    if (0xf < in_stack_00000034) {
      uVar7 = in_stack_00000034 + 1;
      iVar8 = in_stack_00000020;
      if (0xfff < uVar7) {
        iVar8 = *(int *)(in_stack_00000020 + -4);
        uVar7 = in_stack_00000034 + 0x24;
        if (0x1f < (in_stack_00000020 - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar8,uVar7);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  FUN_00910e70(&param_3);
  pcVar1 = (code *)swi(3);
  uVar3 = (*pcVar1)();
  return uVar3;
}



/* FUNCTION 15932 ; VA 0x0090acd0 ; FUN_0090acd0 */

void __thiscall FUN_0090acd0(int param_1,char param_2)

{
  if (param_2 != *(char *)(param_1 + 0x242)) {
    *(char *)(param_1 + 0x242) = param_2;
    FUN_008a4940();
    return;
  }
  return;
}



/* FUNCTION 15933 ; VA 0x0090ad00 ; FUN_0090ad00 */

void __fastcall FUN_0090ad00(int param_1)

{
  if (*(int *)(param_1 + 0x1a0) != 0) {
    FUN_00bb4c60();
    return;
  }
  return;
}



/* FUNCTION 15934 ; VA 0x0090ad20 ; FUN_0090ad20 */

int FUN_0090ad20(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  code *pcStack_2c;
  undefined4 uStack_28;
  int *piStack_24;
  int iStack_20;
  int *piStack_1c;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c5420;
  pvStack_10 = ExceptionList;
  piStack_14 = (int *)CONCAT31(piStack_14._1_3_,DAT_01ee05ad);
  uStack_8 = 0;
  piStack_1c = (int *)CONCAT31(piStack_1c._1_3_,DAT_01ee05ac);
  ExceptionList = &pvStack_10;
  if (param_3 != (int *)0x0) {
    LOCK();
    ExceptionList = &pvStack_10;
    param_3[1] = param_3[1] + 1;
    UNLOCK();
    LOCK();
    param_3[1] = param_3[1] + 1;
    UNLOCK();
  }
  puVar4 = (undefined4 *)FUN_008e74b0(param_2,param_3,piStack_1c,piStack_14);
  pcStack_2c = FUN_008ef0d0;
  piStack_24 = (int *)puVar4[1];
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piStack_24[1] = piStack_24[1] + 1;
    UNLOCK();
    piStack_24 = (int *)puVar4[1];
  }
  uStack_28 = *puVar4;
  piStack_1c = piStack_14;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    iVar5 = piStack_14[1] + -1;
    piStack_14[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      iVar5 = piStack_1c[2] + -1;
      piStack_1c[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*piStack_1c + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    iVar5 = param_3[1] + -1;
    param_3[1] = iVar5;
    UNLOCK();
    if (iVar5 == 0) {
      (**(code **)*param_3)();
      LOCK();
      iVar5 = param_3[2] + -1;
      param_3[2] = iVar5;
      UNLOCK();
      if (iVar5 == 0) {
        (**(code **)(*param_3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar5 = FUN_008e62e0(param_1,*(undefined4 *)(iStack_20 + 0x38),*(undefined4 *)(iStack_20 + 0x40),
                       *(undefined4 *)(iStack_20 + 0x44),&pcStack_2c);
  piVar2 = piStack_24;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_24 + 1;
    iVar3 = *piVar1;
    iVar5 = *piVar1;
    *piVar1 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      (**(code **)*piStack_24)();
      LOCK();
      piVar1 = piVar2 + 2;
      iVar3 = *piVar1;
      iVar5 = *piVar1;
      *piVar1 = iVar3 + -1;
      UNLOCK();
      if (iVar3 + -1 == 0) {
        iVar5 = (**(code **)(*piVar2 + 4))();
      }
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar3 = *piVar2;
    iVar5 = *piVar2;
    *piVar2 = iVar3 + -1;
    UNLOCK();
    if (iVar3 + -1 == 0) {
      iVar5 = (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar3 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        iVar5 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15935 ; VA 0x0090ae80 ; FUN_0090ae80 */

int __thiscall FUN_0090ae80(int param_1,int param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  
  piVar2 = *(int **)(param_1 + 0x338);
  if (param_3 != (int *)0x0) {
    LOCK();
    param_3[2] = param_3[2] + 1;
    UNLOCK();
  }
  *piVar2 = param_2;
  piVar3 = (int *)piVar2[1];
  piVar2[1] = (int)param_3;
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar2 = piVar3 + 2;
    iVar1 = *piVar2;
    param_2 = *piVar2;
    *piVar2 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      param_2 = (**(code **)(*piVar3 + 4))();
    }
  }
  if (param_3 != (int *)0x0) {
    LOCK();
    piVar2 = param_3 + 1;
    iVar1 = *piVar2;
    param_2 = *piVar2;
    *piVar2 = iVar1 + -1;
    UNLOCK();
    if (iVar1 + -1 == 0) {
      param_2 = (**(code **)*param_3)();
      LOCK();
      piVar2 = param_3 + 2;
      iVar1 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar1 == 1) {
        param_2 = (**(code **)(*param_3 + 4))();
      }
    }
  }
  return param_2;
}



/* FUNCTION 15936 ; VA 0x0090aef0 ; FUN_0090aef0 */

int * __thiscall FUN_0090aef0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5438;
  pvStack_10 = ExceptionList;
  uStack_20 = param_2;
  uStack_28 = 0;
  uStack_24 = 0;
  uStack_1c = param_3;
  ExceptionList = &pvStack_10;
  piVar3 = (int *)FUN_00b5efb0(&iStack_18);
  uStack_8 = 0;
  if (iStack_18 != 0) {
    piVar3 = (int *)FUN_00d69a10(&uStack_28);
  }
  uStack_8 = 0xffffffff;
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    piVar3 = (int *)*piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      piVar3 = (int *)(**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        piVar3 = (int *)(**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if ((param_1 != -0xc) && (piVar3 = (int *)FUN_00636b00(), *piVar3 != 0)) {
    piVar3 = (int *)FUN_00b9d1b0(&uStack_28);
  }
  ExceptionList = pvStack_10;
  return piVar3;
}



/* FUNCTION 15937 ; VA 0x0090afc0 ; FUN_0090afc0 */

void __thiscall FUN_0090afc0(int param_1,undefined param_2)

{
  *(undefined *)(param_1 + 0x33c) = param_2;
  return;
}



/* FUNCTION 15938 ; VA 0x0090afd0 ; FUN_0090afd0 */

void __thiscall FUN_0090afd0(int param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x1d8) = param_2;
  return;
}



/* FUNCTION 15939 ; VA 0x0090afe0 ; FUN_0090afe0 */

undefined4 __thiscall FUN_0090afe0(int param_1,int param_2,int param_3)

{
  int *piVar1;
  
  piVar1 = *(int **)(param_1 + 0x43c);
  if ((*piVar1 - (int)piVar1 == param_2) && (piVar1[1] - (int)piVar1 == param_3)) {
    return 0;
  }
  *piVar1 = param_2 + (int)piVar1;
  piVar1[1] = param_3 + (int)piVar1;
  FUN_008a4940(&DAT_0211c57c);
  return 1;
}



/* FUNCTION 15940 ; VA 0x0090b030 ; FUN_0090b030 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0090b030(int param_1,int param_2,int param_3,int param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  int aiStack_20 [5];
  uint uStack_c;
  char cStack_5;
  
  if (DAT_01d65192 != '\0') {
    FUN_016774b0(DAT_01d65192,"Setting DataCenter ID %d",param_4);
    if (DAT_01d65192 != '\0') {
      FUN_016774b0(DAT_01d65192,"Setting place ID %lld",param_2);
    }
  }
  FUN_0151a9b0(param_2,param_3);
  cStack_5 = '\0';
  if ((*(int *)(param_1 + 0x44c) != param_4) && (param_4 != -1)) {
    *(int *)(param_1 + 0x44c) = param_4;
    cStack_5 = '\x01';
  }
  piVar1 = *(int **)(param_1 + 0x43c);
  if ((*piVar1 - (int)piVar1 != param_2) || (piVar1[1] - (int)piVar1 != param_3)) {
    *piVar1 = param_2 + (int)piVar1;
    piVar1[1] = (int)piVar1 + param_3;
    FUN_008a4940(&DAT_0211c57c);
    cStack_5 = '\x01';
  }
  puVar2 = (undefined4 *)FUN_01675640(aiStack_20,&DAT_018bed48,param_2,param_3);
  if (puVar2 != &DAT_01d79c80) {
    FUN_005507b0();
    DAT_01d79c80 = *puVar2;
    uRam01d79c84 = puVar2[1];
    uRam01d79c88 = puVar2[2];
    uRam01d79c8c = puVar2[3];
    _DAT_01d79c90 = *(undefined8 *)(puVar2 + 4);
    puVar2[4] = 0;
    puVar2[5] = 0xf;
    *(undefined *)puVar2 = 0;
  }
  if (0xf < uStack_c) {
    uVar4 = uStack_c + 1;
    iVar3 = aiStack_20[0];
    if (0xfff < uVar4) {
      iVar3 = *(int *)(aiStack_20[0] + -4);
      uVar4 = uStack_c + 0x24;
      if (0x1f < (aiStack_20[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  FUN_015224b0(param_2,param_3);
  DAT_01d7a884 = param_4;
  piVar1 = *(int **)(param_1 + 0x43c);
  FUN_0093ccf0(*piVar1 - (int)piVar1,piVar1[1] - (int)piVar1,*(undefined4 *)(param_1 + 0x44c));
  if (cStack_5 != '\0') {
    FUN_01677790(FUN_0090d930,param_1,0x3f);
    if (DAT_01d84e98 != '\0') {
      FUN_01677070(param_2,param_3);
    }
  }
  return;
}



/* FUNCTION 15941 ; VA 0x0090b1c0 ; FUN_0090b1c0 */

void __thiscall FUN_0090b1c0(int param_1,int param_2)

{
  if (DAT_01d65192 != '\0') {
    FUN_016774b0(DAT_01d65192,"Setting place version %u",param_2);
  }
  if (*(int *)(param_1 + 0x450) != param_2) {
    *(int *)(param_1 + 0x450) = param_2;
    FUN_008a4940(&DAT_0211c5b4);
    FUN_008ba2d0(*(undefined4 *)(param_1 + 0x450));
  }
  return;
}



/* FUNCTION 15942 ; VA 0x0090b220 ; FUN_0090b220 */

void __fastcall FUN_0090b220(int param_1)

{
  if (*(int *)(param_1 + 0x1a0) != 0) {
    FUN_00bb4d70();
    return;
  }
  return;
}



/* FUNCTION 15943 ; VA 0x0090b240 ; FUN_0090b240 */

void __thiscall FUN_0090b240(int *param_1,int *param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  
  piVar2 = param_3;
  if ((param_3 != (int *)0x0) &&
     (iVar1 = param_3[3], iVar3 = FUN_008aa870(),
     (uint)*(ushort *)(iVar3 + 0x1da) <
     (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8))) {
    piVar6 = (int *)param_1[1];
    if (0xf < (uint)piVar6[5]) {
      piVar6 = (int *)*piVar6;
    }
    if (param_2 == (int *)0x0) {
      param_2 = (int *)&DAT_018e3e8c;
    }
    else {
      (**(code **)(*param_2 + 0x10))();
      param_2 = (int *)FUN_005543f0();
    }
    (**(code **)(*piVar2 + 0x10))();
    uVar4 = FUN_005543f0();
    (**(code **)(*param_1 + 0x4c))();
    uVar5 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Expected %s got %s for %s:%s.",uVar5,uVar4,param_2,piVar6);
  }
  param_3 = piVar2;
  (**(code **)(*(int *)param_1[0xe] + 0x10))(param_2,&param_3);
  return;
}



/* FUNCTION 15944 ; VA 0x0090b2f0 ; FUN_0090b2f0 */

int * FUN_0090b2f0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  undefined4 ****ppppuVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  uint in_stack_00000020;
  undefined4 ***apppuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c5468;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  FUN_009cc5b0(apppuStack_30);
  ppppuVar3 = apppuStack_30;
  if (0xf < uStack_1c) {
    ppppuVar3 = (undefined4 ****)apppuStack_30[0];
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  piVar2 = (int *)FUN_01683990(ppppuVar3,uStack_20,10,&uStack_18);
  if ((char)piVar2 == '\0') {
    if (DAT_01d84e8e != '\0') {
      ppppuVar3 = apppuStack_30;
      if (0xf < uStack_1c) {
        ppppuVar3 = (undefined4 ****)apppuStack_30[0];
      }
      piVar2 = (int *)FUN_01677650(DAT_01d84e8e,
                                   "Invalid argument to setSourceAssetIdOnResults: assetId must convert to an integer. Got \"%s\""
                                   ,ppppuVar3);
    }
  }
  else {
    iVar4 = param_1[1];
    piVar2 = param_1;
    for (iVar6 = *param_1; iVar6 != iVar4; iVar6 = iVar6 + 8) {
      piVar2 = (int *)FUN_008a6f80(uStack_18,uStack_14);
    }
  }
  if (0xf < uStack_1c) {
    uVar5 = uStack_1c + 1;
    ppppuVar3 = (undefined4 ****)apppuStack_30[0];
    if (0xfff < uVar5) {
      ppppuVar3 = (undefined4 ****)apppuStack_30[0][-1];
      uVar5 = uStack_1c + 0x24;
      if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar3))) goto LAB_0090b44a;
    }
    piVar2 = (int *)FUN_01674ea0(ppppuVar3,uVar5);
  }
  apppuStack_30[0] = (undefined4 ***)((uint)apppuStack_30[0] & 0xffffff00);
  uStack_1c = 0xf;
  uStack_20 = 0;
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 1;
    iVar4 = *piVar1;
    piVar2 = (int *)*piVar1;
    *piVar1 = iVar4 + -1;
    UNLOCK();
    if (iVar4 + -1 == 0) {
      piVar2 = (int *)(**(code **)*param_2)();
      LOCK();
      piVar1 = param_2 + 2;
      iVar4 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar4 == 1) {
        piVar2 = (int *)(**(code **)(*param_2 + 4))();
      }
    }
  }
  if (0xf < in_stack_00000020) {
    uVar5 = in_stack_00000020 + 1;
    iVar4 = param_3;
    if (0xfff < uVar5) {
      iVar4 = *(int *)(param_3 + -4);
      uVar5 = in_stack_00000020 + 0x24;
      if (0x1f < (param_3 - iVar4) - 4U) {
LAB_0090b44a:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    piVar2 = (int *)FUN_01674ea0(iVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return piVar2;
}



/* FUNCTION 15945 ; VA 0x0090b450 ; FUN_0090b450 */

void FUN_0090b450(undefined4 param_1,undefined4 param_2)

{
  FUN_0090b480(param_1,param_2,0);
  return;
}



/* FUNCTION 15946 ; VA 0x0090b480 ; FUN_0090b480 */

void __thiscall
FUN_0090b480(int param_1,int param_2,undefined4 *param_3,uint param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined4 param_8,undefined4 *param_9,
            ulonglong param_10,undefined4 *param_11,undefined4 param_12,undefined4 ****param_13,
            undefined *param_14,undefined4 ****param_15,uint param_16,undefined8 param_17)

{
  uint *puVar1;
  char cVar2;
  undefined4 **ppuVar3;
  undefined4 ****ppppuVar4;
  undefined4 ****ppppuVar5;
  uint uVar6;
  uint auStack_8c [2];
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 ***pppuStack_78;
  undefined8 uStack_74;
  undefined4 *puStack_6c;
  undefined4 ***pppuStack_68;
  undefined4 ***pppuStack_64;
  undefined *puStack_60;
  undefined4 ***pppuStack_5c;
  undefined4 **ppuStack_58;
  undefined8 uStack_54;
  undefined4 ***apppuStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  undefined4 ***pppuStack_2c;
  undefined4 ***pppuStack_28;
  uint uStack_24;
  undefined4 ***apppuStack_20 [2];
  int **ppiStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c54b8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (DAT_01ee04ac != 0) {
    ppuStack_58 = (undefined4 **)(uint)DAT_01ee04ac;
    uStack_54 = CONCAT44(param_2,"DataModel::setUniverseId %lld");
    pppuStack_5c = (undefined4 ****)0x90b4c1;
    ExceptionList = &pvStack_10;
    FUN_016774b0();
  }
  if ((param_2 != *(int *)(param_1 + 0x440)) || (param_3 != *(undefined4 **)(param_1 + 0x444))) {
    *(int *)(param_1 + 0x440) = param_2;
    *(undefined4 **)(param_1 + 0x444) = param_3;
    uStack_54 = 0x211c5ec0090b4f4;
    FUN_008a4940();
    if (DAT_01d635c4 != '\0') {
      pppuStack_5c = apppuStack_44;
      uStack_54 = *(undefined8 *)(param_1 + 0x440);
      ppuStack_58 = (undefined4 **)&DAT_018bed48;
      puStack_60 = (undefined *)0x90b51b;
      FUN_01675640();
      pppuStack_2c = (undefined4 ****)0x0;
      pppuStack_28 = (undefined4 ****)0x0;
      uStack_24 = 0;
      puStack_60 = (undefined *)0x1;
      pppuStack_68 = apppuStack_20;
      uStack_8._0_1_ = 3;
      pppuStack_64 = (undefined4 ***)&DAT_018d1b9c;
      apppuStack_20[0] = (undefined4 ****)0x0;
      ppiStack_18 = (int **)0x1;
      puStack_6c = (undefined4 *)0x90b552;
      FUN_0170cc70();
      puStack_6c = param_3;
      pppuStack_78 = apppuStack_20;
      uStack_74 = CONCAT44(((int)apppuStack_20 + (int)ppiStack_18) - (int)pppuStack_78,
                           (int)apppuStack_20 + (int)ppiStack_18);
      uStack_7c = 0x90b56c;
      FUN_0063e660();
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      puStack_60 = (undefined *)0x1;
      ppuVar3 = &puStack_6c;
      pppuStack_64 = (undefined4 ***)ppiStack_18;
      puStack_6c = (undefined4 *)0x0;
      if (ppiStack_18 < (undefined4 ***)0x9) {
        ppppuVar5 = apppuStack_20;
      }
      else {
        uStack_74 = CONCAT44(ppiStack_18,0x90b59b);
        ppuVar3 = (undefined4 **)FUN_01674e20();
        ppppuVar5 = (undefined4 ****)apppuStack_20[0];
        puStack_6c = ppuVar3;
      }
      uStack_74 = CONCAT44(pppuStack_64,ppppuVar5);
      uStack_7c = 0x90b5ae;
      pppuStack_78 = (undefined4 ***)ppuVar3;
      FUN_0170c6f0();
      uStack_74 = CONCAT44(&pppuStack_5c,0x90b5b9);
      FUN_0063fec0();
      pppuStack_64 = &pppuStack_2c;
      puStack_60 = &DAT_01d635cc;
      pppuStack_68 = (undefined4 ***)0x90b5ca;
      FUN_0063f980();
      if (((undefined4 ***)0x8 < ppiStack_18) &&
         ((undefined4 ****)apppuStack_20[0] != (undefined4 ****)0x0)) {
        uStack_54 = CONCAT44(apppuStack_20[0],0x90b5e0);
        FUN_01674ea0();
      }
      *(undefined *)(param_1 + 0x24c) = 0;
      ppppuVar5 = (undefined4 ****)pppuStack_2c;
      if (pppuStack_2c != pppuStack_28) {
        do {
          ppppuVar4 = apppuStack_44;
          if (0xf < uStack_30) {
            ppppuVar4 = (undefined4 ****)apppuStack_44[0];
          }
          pppuStack_5c = ppppuVar5;
          if ((undefined4 ***)0xf < ppppuVar5[5]) {
            pppuStack_5c = *ppppuVar5;
          }
          uStack_54 = CONCAT44(uStack_34,ppppuVar4);
          ppuStack_58 = ppppuVar5[4];
          puStack_60 = (undefined *)0x90b614;
          cVar2 = FUN_0055c360();
          if (cVar2 != '\0') {
            *(undefined *)(param_1 + 0x24c) = 1;
            break;
          }
          ppppuVar5 = ppppuVar5 + 6;
        } while (ppppuVar5 != (undefined4 ****)pppuStack_28);
      }
      uStack_54 = CONCAT44(0x90b634,(undefined4)uStack_54);
      FUN_00577a40();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      if (0xf < uStack_30) {
        uVar6 = uStack_30 + 1;
        ppppuVar5 = (undefined4 ****)apppuStack_44[0];
        if (0xfff < uVar6) {
          ppppuVar5 = (undefined4 ****)apppuStack_44[0][-1];
          uVar6 = uStack_30 + 0x24;
          if (0x1f < (uint)((int)apppuStack_44[0] + (-4 - (int)ppppuVar5))) {
            uStack_54 = CONCAT44(&UNK_0090b7e6,(undefined4)uStack_54);
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        uStack_54 = CONCAT44(uVar6,ppppuVar5);
        ppuStack_58 = (undefined4 **)0x90b669;
        FUN_01674ea0();
      }
    }
    uStack_54 = CONCAT44(1,param_1 + 0xc);
    ppuStack_58 = (undefined4 **)0x90b677;
    cVar2 = FUN_00971ce0();
    if (cVar2 != '\0') {
      if (DAT_01ee04ac != 0) {
        ppuStack_58 = (undefined4 **)(uint)DAT_01ee04ac;
        uStack_54 = 0x192cc7c;
        pppuStack_5c = (undefined4 ****)0x90b69b;
        FUN_016774b0();
      }
      pppuStack_2c = (undefined4 ****)0x0;
      pppuStack_28 = (undefined4 ****)0x0;
      uStack_24 = uStack_24 & 0xffffff00;
      uStack_8._0_1_ = 5;
      uStack_54 = CONCAT44(&pppuStack_2c,0x90b6c3);
      FUN_008eb410();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uStack_54 = CONCAT44(0x90b6cf,(undefined4)uStack_54);
      FUN_00872220();
      *(undefined *)(param_1 + 0x249) = 1;
      if (*(char *)(param_1 + 0x248) != '\0') {
        puStack_14 = (undefined *)&puStack_6c;
        puStack_6c = (undefined4 *)0x0;
        if (param_11 != (undefined4 *)0x0) {
          puStack_6c = param_11;
          if (((uint)param_11 & 1) == 0) {
            uStack_74 = ZEXT48(&pppuStack_64);
            pppuStack_78 = &param_13;
            uStack_7c = 0x90b727;
            (**(code **)((uint)param_11 & 0xfffffffe))();
          }
          else {
            pppuStack_64 = param_13;
            puStack_60 = param_14;
            pppuStack_5c = param_15;
            ppuStack_58 = (undefined4 **)param_16;
            uStack_54 = param_17;
          }
        }
        puStack_14 = (undefined *)auStack_8c;
        uStack_8._0_1_ = 6;
        auStack_8c[0] = 0;
        puVar1 = auStack_8c;
        if (param_4 != 0) {
          auStack_8c[0] = param_4;
          if ((param_4 & 1) == 0) {
            (**(code **)(param_4 & 0xfffffffe))(&param_6,&uStack_84,0);
            puVar1 = (uint *)puStack_14;
          }
          else {
            uStack_84 = param_6;
            uStack_80 = param_7;
            uStack_7c = param_8;
            pppuStack_78 = (undefined4 ***)param_9;
            uStack_74 = param_10;
            puVar1 = auStack_8c;
          }
        }
        puStack_14 = (undefined *)puVar1;
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_00908980();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (((param_4 != 0) && ((param_4 & 1) == 0)) && (*(code **)(param_4 & 0xfffffffe) != (code *)0x0))
  {
    ppuStack_58 = (undefined4 **)&param_6;
    uStack_54 = CONCAT44(2,ppuStack_58);
    pppuStack_5c = (undefined4 ***)0x90b79e;
    (**(code **)(param_4 & 0xfffffffe))();
  }
  uStack_8 = 8;
  if (((param_11 != (undefined4 *)0x0) && (((uint)param_11 & 1) == 0)) &&
     (*(code **)((uint)param_11 & 0xfffffffe) != (code *)0x0)) {
    ppuStack_58 = &param_13;
    uStack_54 = CONCAT44(2,ppuStack_58);
    pppuStack_5c = (undefined4 ***)0x90b7cc;
    (**(code **)((uint)param_11 & 0xfffffffe))();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15947 ; VA 0x0090b7f0 ; FUN_0090b7f0 */

void __thiscall FUN_0090b7f0(int param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  uint uVar5;
  uint uVar6;
  int *piVar7;
  undefined4 in_stack_00000014;
  uint in_stack_00000018;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar6 = in_stack_00000018;
  piVar7 = param_2;
  puStack_c = &LAB_01798858;
  pvStack_10 = ExceptionList;
  piVar3 = (int *)(param_1 + 0x468);
  uStack_8 = 0;
  piVar4 = piVar3;
  if (0xf < *(uint *)(param_1 + 0x47c)) {
    piVar4 = (int *)*piVar3;
  }
  piVar2 = (int *)&param_2;
  if (0xf < in_stack_00000018) {
    piVar2 = param_2;
  }
  ExceptionList = &pvStack_10;
  cVar1 = FUN_0055c360(piVar2,in_stack_00000014,piVar4,*(undefined4 *)(param_1 + 0x478));
  if (cVar1 == '\0') {
    if ((int **)piVar3 != &param_2) {
      piVar3 = (int *)&param_2;
      if (0xf < uVar6) {
        piVar3 = piVar7;
      }
      FUN_005542c0(piVar3,in_stack_00000014);
    }
    FUN_008a4940(&DAT_0211caa8);
    uVar6 = in_stack_00000018;
    piVar7 = param_2;
  }
  if (0xf < uVar6) {
    uVar5 = uVar6 + 1;
    piVar3 = piVar7;
    if (0xfff < uVar5) {
      piVar3 = (int *)piVar7[-1];
      uVar5 = uVar6 + 0x24;
      if (0x1f < (uint)((int)piVar7 + (-4 - (int)piVar3))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(piVar3,uVar5);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15948 ; VA 0x0090b8d0 ; FUN_0090b8d0 */

void __thiscall FUN_0090b8d0(int param_1,int param_2,int param_3)

{
  if ((param_2 != *(int *)(param_1 + 0x480)) || (param_3 != *(int *)(param_1 + 0x484))) {
    *(int *)(param_1 + 0x480) = param_2;
    *(int *)(param_1 + 0x484) = param_3;
    FUN_008a4940(&DAT_0211cae0);
  }
  return;
}



/* FUNCTION 15949 ; VA 0x0090b910 ; FUN_0090b910 */

void __thiscall FUN_0090b910(int param_1,undefined4 param_2,undefined4 *param_3)

{
  (**(code **)(param_1 + 0x10))(*param_3);
  return;
}



/* FUNCTION 15950 ; VA 0x0090b940 ; FUN_0090b940 */

void __thiscall FUN_0090b940(int param_1,undefined4 param_2,undefined *param_3)

{
  (**(code **)(param_1 + 0x10))(*param_3);
  return;
}



/* FUNCTION 15951 ; VA 0x0090b970 ; FUN_0090b970 */

void __thiscall FUN_0090b970(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_0090bc60();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15952 ; VA 0x0090b9c0 ; FUN_0090b9c0 */

void __thiscall FUN_0090b9c0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_0063cc40();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15953 ; VA 0x0090ba10 ; FUN_0090ba10 */

void __thiscall FUN_0090ba10(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_0090bd10();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15954 ; VA 0x0090ba60 ; FUN_0090ba60 */

void __thiscall FUN_0090ba60(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_0090bdc0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15955 ; VA 0x0090bab0 ; FUN_0090bab0 */

void __thiscall FUN_0090bab0(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_0090bf80();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15956 ; VA 0x0090bb00 ; FUN_0090bb00 */

void __thiscall FUN_0090bb00(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = FUN_0090c0c0();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 15957 ; VA 0x0090bb50 ; FUN_0090bb50 */

void __fastcall FUN_0090bb50(int param_1)

{
  char cVar1;
  undefined4 ****ppppuVar2;
  uint uVar3;
  undefined *puVar4;
  undefined4 ***apppuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  code *pcStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *(undefined *)(param_1 + 0x241) = 1;
  FUN_00f576e0();
  uStack_8 = 0;
  if ((undefined4 ****)(param_1 + 0x424) != apppuStack_30) {
    ppppuVar2 = apppuStack_30;
    if (0xf < uStack_1c) {
      ppppuVar2 = (undefined4 ****)apppuStack_30[0];
    }
    FUN_005542c0(ppppuVar2,uStack_20);
  }
  uStack_8 = 0xffffffff;
  if (0xf < uStack_1c) {
    uVar3 = uStack_1c + 1;
    ppppuVar2 = (undefined4 ****)apppuStack_30[0];
    if (0xfff < uVar3) {
      ppppuVar2 = (undefined4 ****)apppuStack_30[0][-1];
      uVar3 = uStack_1c + 0x24;
      if (0x1f < (uint)((int)apppuStack_30[0] + (-4 - (int)ppppuVar2))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar2,uVar3);
  }
  FUN_005cf2a0();
  pcStack_18 = FUN_0090a0a0;
  iStack_14 = param_1;
  cVar1 = FUN_00585a40(&pcStack_18);
  if (cVar1 == '\0') {
    puVar4 = &DAT_0192d3d9;
  }
  else {
    puVar4 = (undefined *)0x0;
  }
  FUN_009eef30(puVar4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15958 ; VA 0x0090bc60 ; FUN_0090bc60 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0090bc60(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c54e6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0a74) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0a74);
    if (DAT_01ee0a74 == -1) {
      uStack_8 = 0;
      FUN_009ca470("AvatarJointPositionType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee0a10 = RBX::Reflection::EnumDesc<enum_RBX::AvatarJointPositionType>::vftable;
      FUN_009caf20(&DAT_01d63730,2);
      FUN_016f3654(&LAB_01882fe0);
      FUN_016f37bf(&DAT_01ee0a74);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee0a10;
}



/* FUNCTION 15959 ; VA 0x0090bd10 ; FUN_0090bd10 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0090bd10(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5506;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0b44) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0b44);
    if (DAT_01ee0b44 == -1) {
      uStack_8 = 0;
      FUN_009ca470("GameAvatarType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee0ae0 = RBX::Reflection::EnumDesc<enum_RBX::GameAvatarType>::vftable;
      FUN_009caf20(&DAT_01d63708,3);
      FUN_016f3654(&LAB_01883000);
      FUN_016f37bf(&DAT_01ee0b44);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee0ae0;
}



/* FUNCTION 15960 ; VA 0x0090bdc0 ; FUN_0090bdc0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0090bdc0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5526;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee09a4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee09a4);
    if (DAT_01ee09a4 == -1) {
      uStack_8 = 0;
      FUN_009ca470("GearGenreSetting");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee0940 = RBX::Reflection::EnumDesc<enum_RBX::DataModel::GearGenreSetting>::vftable;
      FUN_009cafc0(&DAT_01d63698,2,1,0);
      FUN_016f3654(&LAB_01883020);
      FUN_016f37bf();
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee0940;
}



/* FUNCTION 15961 ; VA 0x0090bea0 ; FUN_0090bea0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0090bea0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5546;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee093c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee093c);
    if (DAT_01ee093c == -1) {
      uStack_8 = 0;
      FUN_009ca470("GearType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee08d8 = RBX::Reflection::EnumDesc<enum_RBX::DataModel::GearType>::vftable;
      FUN_009cafc0(&DAT_01d636a8,9,1,0);
      FUN_016f3654(&LAB_01883040);
      FUN_016f37bf();
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee08d8;
}



/* FUNCTION 15962 ; VA 0x0090bf80 ; FUN_0090bf80 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0090bf80(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5566;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0a0c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0a0c);
    if (DAT_01ee0a0c == -1) {
      uStack_8 = 0;
      FUN_009ca470("Genre");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee09a8 = RBX::Reflection::EnumDesc<enum_RBX::DataModel::Genre>::vftable;
      FUN_009caf20(&DAT_01d63628,0xe);
      FUN_016f3654(&LAB_01883060);
      FUN_016f37bf(&DAT_01ee0a0c);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee09a8;
}



/* FUNCTION 15963 ; VA 0x0090c030 ; FUN_0090c030 */

undefined * FUN_0090c030(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c557c;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0bd4) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0bd4);
    if (DAT_01ee0bd4 == -1) {
      uStack_8 = 0;
      FUN_00bc5af0();
      FUN_016f3654(&LAB_01883080);
      FUN_016f37bf(&DAT_01ee0bd4);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee0b70;
}



/* FUNCTION 15964 ; VA 0x0090c0c0 ; FUN_0090c0c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0090c0c0(void)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c55a6;
  pvStack_10 = ExceptionList;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0adc) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee0adc);
    if (DAT_01ee0adc == -1) {
      uStack_8 = 0;
      FUN_009ca470("R15CollisionType");
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      _DAT_01ee0a78 = RBX::Reflection::EnumDesc<enum_RBX::R15CollisionType>::vftable;
      FUN_009caf20(&DAT_01d63720,2);
      FUN_016f3654(&LAB_018830a0);
      FUN_016f37bf(&DAT_01ee0adc);
    }
  }
  ExceptionList = pvStack_10;
  return &DAT_01ee0a78;
}



/* FUNCTION 15965 ; VA 0x0090c170 ; FUN_0090c170 */

int FUN_0090c170(void)

{
  uint uVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  undefined auStack_24 [4];
  int *piStack_20;
  uint *puStack_1c;
  char cStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c55c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_01675290(DAT_01ee1098);
  uStack_8 = 0;
  iVar5 = DAT_01ee05b8;
  uStack_14 = uVar2;
  if (DAT_01ee05b8 == 0) {
    piVar3 = (int *)FUN_00910e00();
    cStack_18 = '\0';
    iVar5 = *piVar3;
    puStack_1c = (uint *)(iVar5 + 0xac);
    FUN_00587410();
    uStack_8._0_1_ = 2;
    if (DAT_01ee05b8 == 0) {
      FUN_008e21d0(auStack_24);
      uStack_8._0_1_ = 3;
      FUN_008a65e0(iVar5,0);
      if (piStack_20 != (int *)0x0) {
        LOCK();
        iVar5 = piStack_20[1] + -1;
        piStack_20[1] = iVar5;
        UNLOCK();
        if (iVar5 == 0) {
          (**(code **)*piStack_20)();
          LOCK();
          piVar3 = piStack_20 + 2;
          iVar5 = *piVar3;
          *piVar3 = *piVar3 + -1;
          UNLOCK();
          if (iVar5 == 1) {
            (**(code **)(*piStack_20 + 4))();
          }
        }
      }
    }
    iVar5 = DAT_01ee05b8;
    uStack_8 = CONCAT31(uStack_8._1_3_,4);
    if (cStack_18 != '\0') {
      LOCK();
      uVar1 = *puStack_1c;
      *puStack_1c = *puStack_1c + 0x80000000;
      UNLOCK();
      if (((uVar1 & 0x40000000) == 0) && (-0x80000000 < (int)uVar1)) {
        LOCK();
        uVar1 = *puStack_1c;
        *puStack_1c = *puStack_1c | 0x40000000;
        UNLOCK();
        if ((uVar1 >> 0x1e & 1) == 0) {
          uVar4 = FUN_00554e40();
          SetEvent(uVar4);
        }
      }
    }
  }
  uStack_8 = 5;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return iVar5;
}



/* FUNCTION 15966 ; VA 0x0090c290 ; FUN_0090c290 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0090c290(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0c5c) {
    FUN_016f3809(&DAT_01ee0c5c);
    if (DAT_01ee0c5c == -1) {
      _DAT_01ee0c50 = FUN_005c65e0;
      _DAT_01ee0c54 = FUN_005c65e0;
      _DAT_01ee0c58 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee0c5c);
    }
  }
  return &DAT_01ee0c50;
}



/* FUNCTION 15967 ; VA 0x0090c300 ; FUN_0090c300 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0090c300(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0c7c) {
    FUN_016f3809(&DAT_01ee0c7c);
    if (DAT_01ee0c7c == -1) {
      _DAT_01ee0c70 = FUN_005c65e0;
      _DAT_01ee0c74 = FUN_005c65e0;
      _DAT_01ee0c78 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee0c7c);
    }
  }
  return &DAT_01ee0c70;
}



/* FUNCTION 15968 ; VA 0x0090c370 ; FUN_0090c370 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0090c370(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0c9c) {
    FUN_016f3809(&DAT_01ee0c9c);
    if (DAT_01ee0c9c == -1) {
      _DAT_01ee0c90 = FUN_005c65e0;
      _DAT_01ee0c94 = FUN_005c65e0;
      _DAT_01ee0c98 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee0c9c);
    }
  }
  return &DAT_01ee0c90;
}



/* FUNCTION 15969 ; VA 0x0090c3e0 ; FUN_0090c3e0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0090c3e0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0c8c) {
    FUN_016f3809(&DAT_01ee0c8c);
    if (DAT_01ee0c8c == -1) {
      _DAT_01ee0c80 = FUN_005c65e0;
      _DAT_01ee0c84 = FUN_005c65e0;
      _DAT_01ee0c88 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee0c8c);
    }
  }
  return &DAT_01ee0c80;
}



/* FUNCTION 15970 ; VA 0x0090c450 ; FUN_0090c450 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0090c450(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0cac) {
    FUN_016f3809(&DAT_01ee0cac);
    if (DAT_01ee0cac == -1) {
      _DAT_01ee0ca0 = FUN_005c65e0;
      _DAT_01ee0ca4 = FUN_005c65e0;
      _DAT_01ee0ca8 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee0cac);
    }
  }
  return &DAT_01ee0ca0;
}



/* FUNCTION 15971 ; VA 0x0090c4c0 ; FUN_0090c4c0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0090c4c0(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0c3c) {
    FUN_016f3809(&DAT_01ee0c3c);
    if (DAT_01ee0c3c == -1) {
      _DAT_01ee0c30 = FUN_005c65e0;
      _DAT_01ee0c34 = FUN_005c65e0;
      _DAT_01ee0c38 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee0c3c);
    }
  }
  return &DAT_01ee0c30;
}



/* FUNCTION 15972 ; VA 0x0090c530 ; FUN_0090c530 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_0090c530(void)

{
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0c6c) {
    FUN_016f3809(&DAT_01ee0c6c);
    if (DAT_01ee0c6c == -1) {
      _DAT_01ee0c60 = FUN_005c65e0;
      _DAT_01ee0c64 = FUN_005c65e0;
      _DAT_01ee0c68 = _guard_check_icall;
      FUN_016f37bf(&DAT_01ee0c6c);
    }
  }
  return &DAT_01ee0c60;
}



/* FUNCTION 15973 ; VA 0x0090c5a0 ; FUN_0090c5a0 */

void __thiscall FUN_0090c5a0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c55e0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_00f5d580(*(undefined4 *)(param_1 + 0x1b8),param_3);
  uStack_8 = 0;
  FUN_008ff820(param_2,param_4);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15974 ; VA 0x0090c5fe ; Catch@0090c5fe */

undefined4 Catch_0090c5fe(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  
  uVar1 = (**(code **)(**(int **)(unaff_EBP + -0x14) + 4))();
  FUN_0086f2f0(3,"Failed to load core scripts: %s",uVar1);
  return 0x90c5eb;
}



/* FUNCTION 15975 ; VA 0x0090c620 ; FUN_0090c620 */

void __thiscall FUN_0090c620(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_28 [4];
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01793968;
  pvStack_10 = ExceptionList;
  iVar1 = *(int *)(param_1 + 0x4a0);
  if (iVar1 != 2) {
    uStack_18 = 0;
    uStack_14 = 0xf;
    auStack_28[0] = auStack_28[0] & 0xffffff00;
    ExceptionList = &pvStack_10;
    FUN_005542c0(&DAT_018bc9b8,0);
    uStack_8 = 0;
    uVar2 = 2;
    if (iVar1 != 3) {
      uVar2 = 0;
    }
    FUN_0090c5a0(uVar2,param_2,auStack_28);
    if (0xf < uStack_14) {
      uVar4 = uStack_14 + 1;
      uVar3 = auStack_28[0];
      if (0xfff < uVar4) {
        uVar3 = *(uint *)(auStack_28[0] - 4);
        uVar4 = uStack_14 + 0x24;
        if (0x1f < (auStack_28[0] - uVar3) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar3,uVar4);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15976 ; VA 0x0090c6e0 ; FUN_0090c6e0 */

undefined4 __fastcall FUN_0090c6e0(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  int iStack_34;
  int *piStack_30;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  int iStack_20;
  int iStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5610;
  pvStack_10 = ExceptionList;
  iStack_20 = *(int *)(param_1 + 0x140);
  if (iStack_20 == 0) {
    return 1;
  }
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  if (DAT_01f754a4 != '\0') {
    uStack_24 = *(undefined4 *)(param_1 + 0xf8);
    iVar6 = *(int *)(param_1 + 300);
    uStack_2c = 0;
    piStack_28 = (int *)0x0;
    ExceptionList = &pvStack_10;
    if (iVar6 != 0) {
      piVar1 = (int *)(iVar6 + 4);
      iVar6 = *(int *)(iVar6 + 4);
      ExceptionList = &pvStack_10;
      while (iVar6 != 0) {
        LOCK();
        iVar5 = *piVar1;
        if (iVar6 == iVar5) {
          *piVar1 = iVar6 + 1;
          iVar5 = iVar6;
        }
        UNLOCK();
        if (iVar5 == iVar6) {
          uStack_2c = *(undefined4 *)(param_1 + 0x128);
          piStack_28 = *(int **)(param_1 + 300);
          break;
        }
        iVar6 = *piVar1;
      }
    }
    piVar1 = piStack_28;
    uStack_8 = 0;
    FUN_01677490(DAT_01f754a4,"GenericJob::Step dataModel(%d) type(%d) taskCount(%d)",uStack_2c,
                 uStack_24,iStack_20);
    uStack_8 = 0xffffffff;
    if (piVar1 != (int *)0x0) {
      LOCK();
      iVar6 = piVar1[1] + -1;
      piVar1[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piVar1)();
        LOCK();
        iVar6 = piVar1[2] + -1;
        piVar1[2] = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar1 + 4))();
        }
      }
    }
  }
  iVar6 = *(int *)(param_1 + 0xf8);
  if ((iVar6 != 1) && ((iVar6 < 7 || (8 < iVar6)))) {
    FUN_00907620();
    ExceptionList = pvStack_10;
    return 1;
  }
  FUN_00587490(&iStack_34);
  uStack_8 = 1;
  if (iStack_34 == 0) {
    if (piStack_30 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_30[1] + -1;
      piStack_30[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_30)();
        LOCK();
        piVar1 = piStack_30 + 2;
        iVar6 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          (**(code **)(*piStack_30 + 4))();
        }
      }
    }
    ExceptionList = pvStack_10;
    return 0;
  }
  iStack_14 = iStack_34 + 0xc;
  if (iStack_14 != 0) {
    if (*(int *)(iStack_34 + 0x40) != 0) {
      iStack_14 = FUN_005c8ac0();
    }
    if ((iStack_14 != 0) &&
       (iVar6 = *(int *)(iStack_14 + 0xc), iVar2 = FUN_008dcf60(), iVar5 = iStack_14,
       (uint)*(ushort *)(iVar6 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      iVar6 = iStack_14 + -0xc;
      iVar2 = iVar6;
      if (iVar6 != 0) {
        iVar2 = iStack_14 + 0x3dc;
        iStack_18 = iVar2;
        iStack_14 = iVar6;
        iVar3 = FUN_016dee6d(iVar2);
        if (iVar3 != 0) {
          FUN_016df3c9(iVar3);
        }
        uStack_8._0_1_ = 2;
        if ((DAT_01d635a4 != '\0') &&
           (((*(int *)(iVar5 + 0x294) != 0 || (*(int *)(iStack_14 + 0x2a4) != 0)) ||
            (iVar6 = iStack_14, iVar2 = iStack_18, *(int *)(iStack_14 + 0x2a8) != 0)))) {
          FUN_01675310("InvalidAccess",&DAT_018bc9b8);
          iVar6 = iStack_14;
          iVar2 = iStack_18;
        }
        *(undefined4 *)(iVar6 + 0x2a0) = 1;
        uVar4 = GetCurrentThreadId();
        *(undefined4 *)(iVar6 + 0x2a8) = uVar4;
        uStack_8 = CONCAT31(uStack_8._1_3_,3);
        iVar5 = FUN_016deec8(iVar2);
        iVar2 = iStack_14;
        if (iVar5 != 0) {
          FUN_016df3c9(iVar5);
          iVar2 = iStack_14;
        }
      }
      goto LAB_0090c944;
    }
  }
  iVar6 = 0;
  iStack_14 = 0;
  iVar2 = iStack_14;
LAB_0090c944:
  iStack_14 = iVar2;
  uStack_8._0_1_ = 4;
  FUN_00907620();
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (iVar6 != 0) {
    iVar5 = FUN_016dee6d(iVar6 + 1000);
    if (iVar5 != 0) {
      FUN_016df3c9(iVar5);
    }
    iVar5 = iVar6;
    if ((DAT_01d635a4 != '\0') &&
       (((*(int *)(iVar6 + 0x2a0) != 1 || (*(int *)(iStack_14 + 0x2a4) != 0)) ||
        (iVar2 = GetCurrentThreadId(), iVar5 = iStack_14, *(int *)(iStack_14 + 0x2a8) != iVar2)))) {
      FUN_01675310("InvalidAccess",&DAT_018bc9b8);
      iVar5 = iStack_14;
    }
    *(undefined4 *)(iVar5 + 0x2a0) = 0;
    *(undefined4 *)(iVar5 + 0x2a8) = 0;
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    iVar6 = FUN_016deec8(iVar6 + 1000);
    if (iVar6 != 0) {
      FUN_016df3c9(iVar6);
    }
  }
  if (piStack_30 != (int *)0x0) {
    LOCK();
    iVar6 = piStack_30[1] + -1;
    piStack_30[1] = iVar6;
    UNLOCK();
    if (iVar6 == 0) {
      (**(code **)*piStack_30)();
      LOCK();
      piVar1 = piStack_30 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        (**(code **)(*piStack_30 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return 1;
}



/* FUNCTION 15977 ; VA 0x0090ca30 ; FUN_0090ca30 */

void FUN_0090ca30(uint param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined4 param_8)

{
  undefined4 uVar1;
  uint auStack_30 [2];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  puStack_c = &LAB_017c5630;
  pvStack_10 = ExceptionList;
  iStack_8 = 0;
  auStack_30[0] = 0;
  ExceptionList = &pvStack_10;
  if (param_1 != 0) {
    auStack_30[0] = param_1;
    if ((param_1 & 1) == 0) {
      ExceptionList = &pvStack_10;
      (**(code **)(param_1 & 0xfffffffe))(&param_3,&uStack_28,0);
    }
    else {
      uStack_28 = param_3;
      uStack_24 = param_4;
      uStack_20 = param_5;
      uStack_1c = param_6;
      uStack_18 = param_7;
      ExceptionList = &pvStack_10;
    }
  }
  iStack_8._0_1_ = 1;
  uVar1 = 0;
  FUN_005880d0(auStack_30);
  iStack_8._0_1_ = 2;
  if (auStack_30[0] != 0) {
    if (((auStack_30[0] & 1) == 0) && (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_30[0] & 0xfffffffe))(&uStack_28,&uStack_28,2,uVar1);
    }
    auStack_30[0] = 0;
  }
  iStack_8 = (uint)iStack_8._1_3_ << 8;
  FUN_0090cb30(uVar1);
  iStack_8 = 3;
  if (((param_1 != 0) && ((param_1 & 1) == 0)) && (*(code **)(param_1 & 0xfffffffe) != (code *)0x0))
  {
    (**(code **)(param_1 & 0xfffffffe))(&param_3,&param_3,2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15978 ; VA 0x0090cb30 ; FUN_0090cb30 */

void __thiscall FUN_0090cb30(int param_1)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int in_stack_0000004c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c5658;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_016dee6d(param_1 + 0x360);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  piVar3 = *(int **)(param_1 + 0x394 + in_stack_0000004c * 8);
  if (piVar3 != (int *)0x0) {
    LOCK();
    piVar3[1] = piVar3[1] + 1;
    UNLOCK();
    piVar3 = *(int **)(param_1 + 0x394 + in_stack_0000004c * 8);
  }
  iVar2 = *(int *)(param_1 + 0x390 + in_stack_0000004c * 8);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iVar2 != 0) {
    FUN_00907ca0(&stack0x00000004);
    if (DAT_01d635bc == '\0') {
      if (piVar3 != (int *)0x0) {
        LOCK();
        piVar3[1] = piVar3[1] + 1;
        UNLOCK();
      }
      FUN_0151dbc0(iVar2,piVar3);
    }
  }
  if (piVar3 != (int *)0x0) {
    LOCK();
    iVar2 = piVar3[1] + -1;
    piVar3[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*piVar3)();
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar3 + 4))();
      }
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  iVar2 = FUN_016deec8(param_1 + 0x360);
  if (iVar2 != 0) {
    FUN_016df3c9(iVar2);
  }
  FUN_008c3510();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15979 ; VA 0x0090cc40 ; FUN_0090cc40 */

void FUN_0090cc40(undefined4 *param_1)

{
  *param_1 = 1;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  return;
}



/* FUNCTION 15980 ; VA 0x0090cc70 ; FUN_0090cc70 */

void __thiscall FUN_0090cc70(int param_1,int param_2)

{
  uint auStack_30 [2];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c5678;
  pvStack_10 = ExceptionList;
  if (param_2 != param_1) {
    auStack_30[0] = 0;
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_005880d0(param_1);
    FUN_005880d0(param_2);
    FUN_005880d0(auStack_30);
    uStack_8 = 1;
    if (((auStack_30[0] != 0) && ((auStack_30[0] & 1) == 0)) &&
       (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_30[0] & 0xfffffffe))(auStack_28,auStack_28,2);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15981 ; VA 0x0090cd00 ; FUN_0090cd00 */

void __thiscall FUN_0090cd00(int param_1,int param_2)

{
  uint auStack_30 [2];
  undefined auStack_28 [24];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c5698;
  pvStack_10 = ExceptionList;
  if (param_2 != param_1) {
    auStack_30[0] = 0;
    uStack_8 = 0;
    ExceptionList = &pvStack_10;
    FUN_005880d0(param_1);
    FUN_005880d0(param_2);
    FUN_005880d0(auStack_30);
    uStack_8 = 1;
    if (((auStack_30[0] != 0) && ((auStack_30[0] & 1) == 0)) &&
       (*(code **)(auStack_30[0] & 0xfffffffe) != (code *)0x0)) {
      (**(code **)(auStack_30[0] & 0xfffffffe))(auStack_28,auStack_28,2);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15982 ; VA 0x0090cd90 ; FUN_0090cd90 */

void FUN_0090cd90(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 ***pppuVar1;
  undefined4 **appuStack_34 [5];
  uint uStack_20;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795d48;
  pvStack_10 = ExceptionList;
  if (0xf < (uint)param_1[5]) {
    param_1 = (undefined4 *)*param_1;
  }
  if (0xf < (uint)param_2[5]) {
    param_2 = (undefined4 *)*param_2;
  }
  ExceptionList = &pvStack_10;
  FUN_01675640(appuStack_34,"Flag %s registration from Lua failed, because of %s",param_2,param_1);
  uStack_8 = 0;
  if (DAT_01d84e8d != '\0') {
    pppuVar1 = appuStack_34;
    if (0xf < uStack_20) {
      pppuVar1 = (undefined4 ***)appuStack_34[0];
    }
    FUN_01677650(DAT_01d84e8d,&DAT_018bd25c,pppuVar1);
  }
  FUN_005500e0(appuStack_34);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_1c,&DAT_01c17198);
}



/* FUNCTION 15983 ; VA 0x0090ce20 ; FUN_0090ce20 */

float10 FUN_0090ce20(void)

{
  float10 fVar1;
  float10 fVar2;
  
  fVar1 = (float10)FUN_00926d70();
  fVar2 = (float10)FUN_00926d70();
  return fVar2 + (float10)(float)fVar1;
}



/* FUNCTION 15984 ; VA 0x0090ce40 ; FUN_0090ce40 */

int FUN_0090ce40(undefined4 param_1,int *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  uint in_stack_00000020;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3ff8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (DAT_01ee04ac != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ee04ac,"DataModel::universeConfigurationLoadedError",0);
  }
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iStack_18 != 0) {
    if (DAT_01ee04ac != '\0') {
      puVar4 = &param_3;
      if (0xf < in_stack_00000020) {
        puVar4 = param_3;
      }
      FUN_01677650(DAT_01ee04ac,"DataModel::universeConfigurationLoadedError %s",puVar4);
    }
    iVar3 = FUN_0087afe0();
    *(undefined *)(iStack_18 + 0x24a) = 0;
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iVar3 = (**(code **)(*param_2 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    uVar5 = in_stack_00000020 + 1;
    puVar4 = param_3;
    if (0xfff < uVar5) {
      puVar4 = (undefined4 *)param_3[-1];
      uVar5 = in_stack_00000020 + 0x24;
      if (0x1f < (uint)((int)param_3 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar3 = FUN_01674ea0(puVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 15985 ; VA 0x0090cf60 ; FUN_0090cf60 */

int FUN_0090cf60(undefined4 param_1,int *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  int in_stack_0000001c;
  uint in_stack_00000020;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c3ff8;
  pvStack_10 = ExceptionList;
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  if (DAT_01ee04ac != '\0') {
    ExceptionList = &pvStack_10;
    FUN_016774b0(DAT_01ee04ac,"DataModel::universeConfigurationLoadedSuccess",0);
  }
  iVar3 = FUN_00587490(&iStack_18);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (iStack_18 != 0) {
    if (in_stack_0000001c != 0) {
      if (DAT_01ee04ac != '\0') {
        puVar4 = &param_3;
        if (0xf < in_stack_00000020) {
          puVar4 = param_3;
        }
        FUN_01677650(DAT_01ee04ac,"DataModel::universeConfigurationLoadedSuccess %s",puVar4);
      }
      FUN_00672300();
      FUN_00bfe0d0(&param_3);
    }
    iVar3 = FUN_0087afe0();
    *(undefined *)(iStack_18 + 0x24a) = 0;
  }
  if (piStack_14 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_14 + 1;
    iVar2 = *piVar1;
    iVar3 = *piVar1;
    *piVar1 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piStack_14)();
      LOCK();
      piVar1 = piStack_14 + 2;
      iVar2 = *piVar1;
      iVar3 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        iVar3 = (**(code **)(*piStack_14 + 4))();
      }
    }
  }
  if (param_2 != (int *)0x0) {
    LOCK();
    piVar1 = param_2 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      iVar3 = (**(code **)(*param_2 + 4))();
    }
  }
  if (0xf < in_stack_00000020) {
    uVar5 = in_stack_00000020 + 1;
    puVar4 = param_3;
    if (0xfff < uVar5) {
      puVar4 = (undefined4 *)param_3[-1];
      uVar5 = in_stack_00000020 + 0x24;
      if (0x1f < (uint)((int)param_3 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    iVar3 = FUN_01674ea0(puVar4,uVar5);
  }
  ExceptionList = pvStack_10;
  return iVar3;
}



/* FUNCTION 15986 ; VA 0x0090d090 ; FUN_0090d090 */

void __fastcall FUN_0090d090(int param_1)

{
  uint *puVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int aiStack_58 [5];
  uint uStack_44;
  uint uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c56c0;
  pvStack_10 = ExceptionList;
  puVar1 = (uint *)(param_1 + 0x348);
  ExceptionList = &pvStack_10;
  FUN_0054ef60(puVar1);
  iStack_8 = 0;
  if (*(char *)(param_1 + 0x1cc) == '\0') {
    FUN_008b3530(&uStack_40);
    uVar6 = uStack_40;
    iStack_8._0_1_ = 1;
    if (iStack_30 == 0) {
      iVar4 = FUN_008e4530(param_1 + 0xc);
      if (iVar4 == 0) {
        iStack_8 = (uint)iStack_8._1_3_ << 8;
        FUN_005507b0();
        goto LAB_0090d138;
      }
      FUN_00b78690(&uStack_28,1,0);
    }
    else {
      uStack_40 = uStack_40 & 0xffffff00;
      uStack_28 = uVar6;
      uStack_24 = uStack_3c;
      uStack_20 = uStack_38;
      uStack_1c = uStack_34;
      uStack_18 = CONCAT44(uStack_2c,iStack_30);
      iStack_30 = 0;
      uStack_2c = 0xf;
    }
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    FUN_005507b0();
  }
  else {
    iVar4 = FUN_008e4530(param_1 + 0xc);
    if (iVar4 != 0) {
      FUN_00b78690(&uStack_28,1,0);
      goto LAB_0090d17c;
    }
LAB_0090d138:
    uStack_18 = 0xf00000000;
    uStack_28 = uStack_28 & 0xffffff00;
  }
LAB_0090d17c:
  if (puVar1 == &uStack_28) {
    if (0xf < uStack_18._4_4_) {
      uVar5 = uStack_18._4_4_ + 1;
      uVar6 = uStack_28;
      if (0xfff < uVar5) {
        uVar6 = *(uint *)(uStack_28 - 4);
        uVar5 = uStack_18._4_4_ + 0x24;
        if (0x1f < (uStack_28 - uVar6) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar5);
    }
  }
  else {
    FUN_005507b0();
    *puVar1 = uStack_28;
    *(undefined4 *)(param_1 + 0x34c) = uStack_24;
    *(undefined4 *)(param_1 + 0x350) = uStack_20;
    *(undefined4 *)(param_1 + 0x354) = uStack_1c;
    *(undefined8 *)(param_1 + 0x358) = uStack_18;
  }
  cVar3 = FUN_00684460(aiStack_58,puVar1);
  if (cVar3 != '\0') {
    *(undefined4 *)(param_1 + 0x260) = 0;
    piVar2 = *(int **)(param_1 + 0x264);
    *(undefined4 *)(param_1 + 0x264) = 0;
    if (piVar2 != (int *)0x0) {
      LOCK();
      iVar4 = piVar2[1] + -1;
      piVar2[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)*piVar2)();
        LOCK();
        iVar4 = piVar2[2] + -1;
        piVar2[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar2 + 4))();
        }
      }
    }
    FUN_006eccd0();
  }
  if (0xf < uStack_44) {
    uVar6 = uStack_44 + 1;
    iVar4 = aiStack_58[0];
    if (0xfff < uVar6) {
      iVar4 = *(int *)(aiStack_58[0] + -4);
      uVar6 = uStack_44 + 0x24;
      if (0x1f < (aiStack_58[0] - iVar4) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar4,uVar6);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15987 ; VA 0x0090d280 ; FUN_0090d280 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_0090d280(int param_1,int *param_2)

{
  bool bVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  code **ppcVar6;
  int *piVar7;
  float *pfVar8;
  undefined4 uVar9;
  undefined4 *puVar10;
  int iVar11;
  float fVar12;
  float fVar13;
  code *pcVar14;
  undefined auStack_d0 [16];
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined uStack_b8;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  undefined uStack_a0;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined auStack_84 [16];
  int *piStack_74;
  undefined4 uStack_70;
  undefined auStack_6c [4];
  int iStack_68;
  undefined auStack_64 [4];
  int iStack_60;
  int iStack_5c;
  int *apiStack_58 [2];
  undefined auStack_50 [4];
  undefined4 uStack_4c;
  code *pcStack_48;
  float fStack_44;
  code *pcStack_40;
  float fStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  code *pcStack_30;
  undefined4 *puStack_2c;
  float fStack_28;
  float fStack_24;
  float fStack_20;
  undefined uStack_19;
  undefined4 *puStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  piVar2 = param_2;
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017c576a;
  pvStack_10 = ExceptionList;
  fStack_20 = 0.0;
  ExceptionList = &pvStack_10;
  iStack_68 = param_1;
  cVar3 = FUN_0152dd50();
  if (cVar3 != '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  iVar11 = param_1 + 0xc;
  if (param_1 == 0) {
    iVar11 = 0;
  }
  if (iVar11 == 0) {
    iVar4 = 0;
  }
  else {
    iVar4 = FUN_008e1b70();
  }
  if (iVar4 == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  fStack_24 = (float)FUN_008e4530(iVar11);
  if (fStack_24 == 0.0) {
    ExceptionList = pvStack_10;
    return;
  }
  FUN_0090d090();
  puStack_18 = (undefined4 *)FUN_008e4530(iVar11);
  if (puStack_18 == (undefined4 *)0x0) {
    ExceptionList = pvStack_10;
    return;
  }
  iVar4 = FUN_00b82b00();
  if (iVar4 == 7) {
    ExceptionList = pvStack_10;
    return;
  }
  if (puStack_18[0x2c] == 2) {
    ExceptionList = pvStack_10;
    return;
  }
  if (puStack_18[0x2c] != 1) {
    if (*(char *)(puStack_18 + 0x2a) == '\0') {
      ExceptionList = pvStack_10;
      return;
    }
    iVar11 = FUN_0097bfc0(iVar11);
    if (iVar11 == 0) {
LAB_0090d367:
      cStack_11 = '\0';
    }
    else {
      cVar3 = FUN_00983210(param_1 + 0xc);
      cStack_11 = '\x01';
      if (cVar3 != '\0') goto LAB_0090d367;
    }
    cVar3 = FUN_00585a40();
    if ((cVar3 == '\0') || (cStack_11 != '\0')) {
      cStack_11 = '\x01';
    }
    else {
      cStack_11 = '\0';
    }
    if (DAT_01d63574 == '\0') {
      cVar3 = FUN_00b83ad0();
      if (cVar3 == '\0') {
        if (cStack_11 == '\0') {
          ExceptionList = pvStack_10;
          return;
        }
        cVar3 = FUN_00b82b90();
      }
      else {
        if (cStack_11 == '\0') {
          ExceptionList = pvStack_10;
          return;
        }
        cVar3 = *(char *)(puStack_18 + 0x2a);
      }
    }
    else {
      if (cStack_11 == '\0') {
        ExceptionList = pvStack_10;
        return;
      }
      cVar3 = FUN_00b82b90();
      if (cVar3 != '\0') goto LAB_0090d400;
      uVar5 = FUN_00b82b00();
      iVar11 = FUN_00ed3bf0(uVar5);
      cVar3 = iVar11 != -1;
    }
    if (cVar3 == '\0') {
      ExceptionList = pvStack_10;
      return;
    }
  }
LAB_0090d400:
  iStack_60 = param_1 + 0x348;
  if (*(int *)(param_1 + 0x358) == 0) {
    ExceptionList = pvStack_10;
    return;
  }
  iStack_5c = param_1 + 0x340;
  uStack_19 = 0;
  cVar3 = FUN_016793f0();
  if (cVar3 == '\0') {
    fStack_28 = (float)(**(code **)(*param_2 + 0x14))();
    pcStack_48 = FUN_00902420;
    fStack_44 = 0.0;
    iStack_8 = 0;
    pcStack_40 = (code *)param_1;
    uVar5 = FUN_01675290(DAT_02110da8);
    iStack_8._0_1_ = 1;
    uStack_4c = uVar5;
    puStack_2c = (undefined4 *)FUN_01674e20(0x28);
    if (puStack_2c == (undefined4 *)0x0) {
      puVar10 = (undefined4 *)0x0;
    }
    else {
      *puStack_2c = 0;
      puStack_2c[1] = 1;
      puStack_2c[2] = FUN_0067baa0;
      puStack_2c[3] = _guard_check_icall;
      puStack_2c[4] = 0;
      puStack_2c[5] = fStack_28;
      puStack_2c[6] = pcStack_48;
      puStack_2c[7] = fStack_44;
      puStack_2c[8] = pcStack_40;
      puStack_2c[9] = fStack_3c;
      puVar10 = puStack_2c;
    }
    FUN_016797d0(puVar10);
    if (puVar10 != (undefined4 *)0x0) {
      LOCK();
      puVar10[1] = puVar10[1] + 1;
      UNLOCK();
    }
    fStack_20 = 4.48416e-44;
    iStack_8._0_1_ = 2;
    puStack_18 = puVar10;
    FUN_01675290(uVar5);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    cVar3 = FUN_01679300(&puStack_18);
    if (cVar3 != '\0') {
      FUN_01679490();
      FUN_016791c0(&puStack_18);
    }
    iStack_8 = 0xffffffff;
    FUN_0056e750();
    param_1 = iStack_68;
  }
  piVar7 = *(int **)(param_1 + 0x260);
  if (piVar7 == (int *)0x0) {
    auStack_84[0] = 0;
    uStack_70 = 0xf;
    pcVar14 = *(code **)(*param_2 + 0x10);
    piStack_74 = piVar7;
    FUN_005542c0("Mouse Cursor",0xc);
    iStack_8 = 3;
    uVar5 = FUN_00d102b0(auStack_84);
    iStack_8 = CONCAT31(iStack_8._1_3_,4);
    uVar5 = (*pcVar14)(auStack_50,iStack_60,&uStack_19,uVar5,0);
    FUN_005587e0(uVar5);
    FUN_00550b30();
    FUN_00637950();
    iStack_8 = 0xffffffff;
    FUN_005507b0();
    piVar7 = *(int **)(param_1 + 0x260);
  }
  cVar3 = (**(code **)(*piVar7 + 8))();
  if (cVar3 == '\0') {
    uStack_c0 = 0;
    uStack_bc = 0xf;
    auStack_d0[0] = 0;
    uStack_a8 = 0;
    uStack_a4 = 0xf;
    uStack_b8 = 0;
    pcVar14 = *(code **)(*param_2 + 0x10);
    uStack_90 = 0;
    uStack_8c = 0xf;
    uStack_a0 = 0;
    iStack_8 = 6;
    fStack_20 = 2.8026e-45;
    uVar5 = FUN_00b78690(auStack_84,0,0);
    iStack_8 = 7;
    fStack_20 = 8.40779e-45;
    ppcVar6 = (code **)(*pcVar14)(auStack_50,uVar5,&uStack_19,auStack_d0,0);
    puStack_18 = (undefined4 *)0xe;
  }
  else {
    puStack_2c = *(undefined4 **)(param_1 + 0x264);
    if (puStack_2c != (undefined4 *)0x0) {
      LOCK();
      puStack_2c[1] = puStack_2c[1] + 1;
      UNLOCK();
      puStack_2c = *(undefined4 **)(param_1 + 0x264);
    }
    pcStack_30 = *(code **)(param_1 + 0x260);
    ppcVar6 = &pcStack_30;
    puStack_18 = (undefined4 *)0x1;
  }
  FUN_00557f90(ppcVar6);
  iStack_8 = 8;
  if (((uint)puStack_18 & 8) != 0) {
    puStack_18 = (undefined4 *)((uint)puStack_18 & 0xfffffff7);
    FUN_00550b30();
  }
  if (((uint)puStack_18 & 4) != 0) {
    puStack_18 = (undefined4 *)((uint)puStack_18 & 0xfffffffb);
    FUN_005507b0();
  }
  if (((uint)puStack_18 & 2) != 0) {
    puStack_18 = (undefined4 *)((uint)puStack_18 & 0xfffffffd);
    FUN_00637950();
  }
  iStack_8 = CONCAT31(iStack_8._1_3_,0xb);
  if (((uint)puStack_18 & 1) != 0) {
    puStack_18 = (undefined4 *)((uint)puStack_18 & 0xfffffffe);
    FUN_00550b30();
  }
  cVar3 = (**(code **)(*apiStack_58[0] + 8))();
  puVar10 = puStack_18;
  if (cVar3 != '\0') {
    piVar7 = (int *)FUN_008b3500(&pcStack_30);
    puVar10 = (undefined4 *)((uint)puStack_18 | 0x10);
    if (*piVar7 != 0) {
      bVar1 = true;
      goto LAB_0090d719;
    }
  }
  bVar1 = false;
LAB_0090d719:
  if (((uint)puVar10 & 0x10) != 0) {
    FUN_00550b30();
  }
  if (bVar1) {
    pfVar8 = (float *)(**(code **)(*apiStack_58[0] + 4))(&pcStack_30);
    fVar12 = (pfVar8[1] + 0.0) * DAT_018ce2f4;
    fVar13 = (*pfVar8 + 0.0) * DAT_018ce2f4;
    fStack_24 = 0.0 - fVar12;
    fVar12 = pfVar8[1] - fVar12;
    fStack_28 = 0.0 - fVar13;
    fVar13 = *pfVar8 - fVar13;
    param_2 = (int *)fVar12;
    if (fStack_24 < fVar12) {
      param_2 = (int *)fStack_24;
    }
    fStack_20 = fVar13;
    if (fStack_28 < fVar13) {
      fStack_20 = fStack_28;
    }
    if (fStack_24 <= fVar12) {
      fStack_24 = fVar12;
    }
    if (fStack_28 <= fVar13) {
      fStack_28 = fVar13;
    }
    FUN_008b3500(&pcStack_30);
    iStack_8._0_1_ = 0xc;
    pfVar8 = (float *)FUN_00d814c0(auStack_64);
    fStack_44 = pfVar8[1];
    fVar13 = fStack_44 + fStack_24;
    fStack_3c = fStack_44 + (float)param_2;
    pcVar14 = (code *)(*pfVar8 + fStack_28);
    pcStack_40 = (code *)(*pfVar8 + fStack_20);
    fVar12 = fStack_24;
    if (fStack_3c < fVar13) {
      fVar12 = (float)param_2;
    }
    fStack_44 = fStack_44 + fVar12;
    pcStack_48 = pcVar14;
    if ((float)pcStack_40 < (float)pcVar14) {
      pcStack_48 = pcStack_40;
    }
    if (fStack_3c <= fVar13) {
      fStack_3c = fVar13;
    }
    if ((float)pcStack_40 <= (float)pcVar14) {
      pcStack_40 = pcVar14;
    }
    iStack_8._0_1_ = 0xb;
    FUN_00550b30();
    pcStack_30 = pcStack_40;
    puStack_2c = (undefined4 *)fStack_3c;
    uVar5 = FUN_00909e80(auStack_64,&pcStack_30);
    pcStack_30 = pcStack_48;
    puStack_2c = (undefined4 *)fStack_44;
    uVar9 = FUN_00909e80(auStack_6c,&pcStack_30);
    puVar10 = (undefined4 *)FUN_006ae8d0(&uStack_38,uVar9,uVar5);
    pcStack_48 = (code *)*puVar10;
    fStack_44 = (float)puVar10[1];
    pcStack_40 = (code *)puVar10[2];
    fStack_3c = (float)puVar10[3];
    FUN_0114eb50(0,apiStack_58,0);
    (**(code **)(*piVar2 + 0x28))(1);
    uStack_38 = _DAT_018e0040;
    uStack_34 = _UNK_018e0044;
    pcStack_30 = _UNK_018e0048;
    puStack_2c = (undefined4 *)_UNK_018e004c;
    FUN_0114e910(&pcStack_48,&uStack_38);
    (**(code **)(*piVar2 + 0x2c))();
    pcStack_30 = (code *)0x0;
    puStack_2c = (undefined4 *)0x0;
    iStack_8 = CONCAT31(iStack_8._1_3_,0xd);
    FUN_0114eb50(0,&pcStack_30,0);
    FUN_00550b30();
  }
  FUN_00550b30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15988 ; VA 0x0090d930 ; FUN_0090d930 */

void FUN_0090d930(undefined4 param_1,undefined4 param_2,int *param_3,undefined4 *param_4,int param_5
                 )

{
  char cVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  int iStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  uint uStack_24;
  uint uStack_20;
  int *piStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01795d48;
  pvStack_10 = ExceptionList;
  if (param_5 != 0) {
    ExceptionList = &pvStack_10;
    if (*(int *)(param_5 + 0x44c) != -1) {
      piVar3 = (int *)param_4[1];
      ExceptionList = &pvStack_10;
      piStack_1c = piVar3;
      for (piVar5 = (int *)*param_4; piVar5 != piVar3; piVar5 = piVar5 + 6) {
        uStack_18 = piVar5[4];
        uStack_24 = 0;
        uStack_20 = 0;
        piStack_14 = piVar5;
        if (0xf < (uint)piVar5[5]) {
          piStack_14 = (int *)*piVar5;
        }
        if (uStack_18 < 0x10) {
          iStack_34 = *piStack_14;
          iStack_30 = piStack_14[1];
          iStack_2c = piStack_14[2];
          iStack_28 = piStack_14[3];
          uStack_20 = 0xf;
        }
        else {
          uVar2 = uStack_18 | 0xf;
          if (0x7fffffff < uVar2) {
            uVar2 = 0x7fffffff;
          }
          iStack_34 = FUN_00554060(uVar2 + 1);
          FUN_0170c6f0(iStack_34,piStack_14,uStack_18 + 1);
          piVar3 = piStack_1c;
          uStack_20 = uVar2;
        }
        uStack_8 = 0;
        uStack_24 = uStack_18;
        cVar1 = FUN_009024a0(param_1,&iStack_34,param_5,param_5);
        if (cVar1 != '\0') {
          if (uStack_20 < 0x10) {
            ExceptionList = pvStack_10;
            return;
          }
          uVar2 = uStack_20 + 1;
          iVar4 = iStack_34;
          if (0xfff < uVar2) {
            iVar4 = *(int *)(iStack_34 + -4);
            uVar2 = uStack_20 + 0x24;
            if (0x1f < (iStack_34 - iVar4) - 4U) {
LAB_0090dadb:
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar4,uVar2);
          ExceptionList = pvStack_10;
          return;
        }
        uStack_8 = 0xffffffff;
        if (0xf < uStack_20) {
          uVar2 = uStack_20 + 1;
          iVar4 = iStack_34;
          if (0xfff < uVar2) {
            iVar4 = *(int *)(iStack_34 + -4);
            uVar2 = uStack_20 + 0x24;
            if (0x1f < (iStack_34 - iVar4) - 4U) goto LAB_0090dadb;
          }
          FUN_01674ea0(iVar4,uVar2);
        }
      }
    }
    iVar4 = param_3[1];
    if (*param_3 != iVar4) {
      do {
        piVar3 = *(int **)(param_5 + 0x43c);
        iVar4 = iVar4 + -0x18;
        cVar1 = FUN_01677d10(param_1,iVar4,*piVar3 - (int)piVar3,piVar3[1] - (int)piVar3);
        if (cVar1 != '\0') {
          ExceptionList = pvStack_10;
          return;
        }
      } while (iVar4 != *param_3);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15989 ; VA 0x0090daf0 ; FUN_0090daf0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined __fastcall FUN_0090daf0(int param_1)

{
  int iVar1;
  double dVar2;
  char cVar3;
  undefined uVar4;
  int *piVar5;
  undefined4 *puVar6;
  float10 fVar7;
  undefined8 uVar8;
  undefined8 uStack_2c;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined8 uStack_1c;
  bool bStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c5794;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee0688) &&
     (ExceptionList = &pvStack_10, FUN_016f3809(&DAT_01ee0688), DAT_01ee0688 == -1)) {
    uStack_8 = 0;
    uVar8 = FUN_0152dab0(&DAT_018cb3fc,"updatePhysicsInstructions",0xffffffff);
    DAT_01ee0684 = (undefined4)((ulonglong)uVar8 >> 0x20);
    DAT_01ee0680 = (undefined4)uVar8;
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01ee0688);
  }
  uStack_24 = DAT_01ee0680;
  uStack_20 = DAT_01ee0684;
  uVar8 = FUN_0152d930(DAT_01ee0680,DAT_01ee0684);
  uStack_8 = 1;
  piVar5 = (int *)FUN_00bbddc0();
  uStack_1c = (double)CONCAT44(piVar5,(undefined4)uStack_1c);
  *(undefined8 *)(*(int *)(param_1 + 0x228) + 0x58) = 0;
  *(undefined *)(*(int *)(param_1 + 0x228) + 0x60) = 0;
  iVar1 = *piVar5;
  dVar2 = _PTR_018cf0f8;
  if (iVar1 == 0) {
LAB_0090dc4f:
    *(double *)(*(int *)(param_1 + 0x228) + 0x58) = dVar2;
    bStack_11 = *(int *)(*(int *)(param_1 + 0x1a8) + 0x68) == 1;
  }
  else {
    if (iVar1 == 3) {
      iVar1 = param_1 + 0xc;
      cVar3 = FUN_00973950(iVar1,1);
      if (cVar3 != '\0') {
        puVar6 = (undefined4 *)FUN_0097bfe0((int)&uStack_2c + 4,iVar1);
        *(undefined4 *)(uStack_1c._4_4_ + 4) = *puVar6;
        if (iVar1 != 0) {
          FUN_0055e560();
        }
        FUN_00971f60(uStack_1c._4_4_);
        fVar7 = (float10)FUN_00cc2890();
        uStack_1c = (double)fVar7;
        *(double *)(*(int *)(param_1 + 0x228) + 0x58) = uStack_1c;
        uVar4 = FUN_0092fd30(iVar1);
        *(undefined *)(*(int *)(param_1 + 0x228) + 0x60) = uVar4;
        fVar7 = (float10)FUN_00927510(iVar1);
        uStack_1c = (double)fVar7;
        bStack_11 = true;
        *(double *)(*(int *)(param_1 + 0x228) + 0x68) = uStack_1c;
        goto LAB_0090dc68;
      }
    }
    else if (iVar1 == 4) {
      piVar5[2] = 0;
      piVar5[3] = 0;
      piVar5[4] = 0;
      piVar5[5] = 0;
      fVar7 = (float10)FUN_00cc28a0();
      uStack_2c = (double)fVar7;
      dVar2 = uStack_2c;
      goto LAB_0090dc4f;
    }
    bStack_11 = false;
  }
LAB_0090dc68:
  uStack_8 = 6;
  FUN_0152dda0(uStack_24,uStack_20,uVar8);
  ExceptionList = pvStack_10;
  return bStack_11;
}



/* FUNCTION 15990 ; VA 0x0090dcf0 ; FUN_0090dcf0 */

void __fastcall FUN_0090dcf0(int *param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179b738;
  pvStack_10 = ExceptionList;
  if ((int *)*param_1 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    (**(code **)(*(int *)*param_1 + 8))(0);
    ExceptionList = pvStack_10;
    return;
  }
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0056acb0();
  uStack_8 = 0;
  FUN_00564940(uVar2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 15991 ; VA 0x0090dd40 ; FUN_0090dd40 */

void * __fastcall FUN_0090dd40(int param_1)

{
  int iVar1;
  code *pcVar2;
  int *piVar3;
  void *pvVar4;
  undefined4 uVar5;
  undefined auStack_20 [4];
  int *piStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c57c0;
  pvStack_10 = ExceptionList;
  pvVar4 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(char *)(param_1 + 0x249) != '\0') {
    ExceptionList = &pvStack_10;
    piVar3 = (int *)FUN_00876b60(auStack_18);
    uStack_8 = 0;
    if ((int *)*piVar3 == (int *)0x0) {
      uVar5 = FUN_0056acb0();
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_00564940(uVar5);
      goto LAB_0090de44;
    }
    pvVar4 = (void *)(**(code **)(*(int *)*piVar3 + 8))(0);
    uStack_8 = 2;
    if (piStack_14 != (int *)0x0) {
      LOCK();
      piVar3 = piStack_14 + 1;
      iVar1 = *piVar3;
      pvVar4 = (void *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        (**(code **)(*piStack_14 + 4))();
        LOCK();
        piVar3 = piStack_14 + 2;
        iVar1 = *piVar3;
        pvVar4 = (void *)*piVar3;
        *piVar3 = iVar1 + -1;
        UNLOCK();
        if (iVar1 + -1 == 0) {
          pvVar4 = (void *)(**(code **)(*piStack_14 + 8))();
        }
      }
    }
  }
  uStack_8 = 0xffffffff;
  if (*(char *)(param_1 + 0x24a) != '\0') {
    piVar3 = (int *)FUN_00876b60(auStack_20);
    uStack_8 = 3;
    if ((int *)*piVar3 == (int *)0x0) {
LAB_0090de44:
      uVar5 = FUN_0056acb0();
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_00564940(uVar5);
      pcVar2 = (code *)swi(3);
      pvVar4 = (void *)(*pcVar2)();
      return pvVar4;
    }
    pvVar4 = (void *)(**(code **)(*(int *)*piVar3 + 8))(0);
    uStack_8 = 5;
    if (piStack_1c != (int *)0x0) {
      LOCK();
      piVar3 = piStack_1c + 1;
      iVar1 = *piVar3;
      pvVar4 = (void *)*piVar3;
      *piVar3 = iVar1 + -1;
      UNLOCK();
      if (iVar1 + -1 == 0) {
        pvVar4 = (void *)(**(code **)(*piStack_1c + 4))();
        LOCK();
        piVar3 = piStack_1c + 2;
        iVar1 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar1 == 1) {
          pvVar4 = (void *)(**(code **)(*piStack_1c + 8))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return pvVar4;
}



/* FUNCTION 15992 ; VA 0x0090de60 ; FUN_0090de60 */

int __fastcall FUN_0090de60(int param_1)

{
  int iVar1;
  uint3 uVar2;
  
  iVar1 = *(int *)(param_1 + 0x14);
  uVar2 = (uint3)((uint)iVar1 >> 8);
  if (iVar1 != 0) {
    return CONCAT31(uVar2,*(undefined *)(iVar1 + 0x344));
  }
  return (uint)uVar2 << 8;
}



/* FUNCTION 15993 ; VA 0x0090de80 ; thunk_FUN_00f6ed60 */

void thunk_FUN_00f6ed60(void)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  uint *puStack_28;
  int *piStack_24;
  uint *puStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_018470c4;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  _guard_check_icall();
  FUN_014cd1c0(4);
  iVar3 = FUN_0154e460();
  if ((iVar3 < 0) && (DAT_01d84e8e != '\0')) {
    FUN_016774b0(DAT_01d84e8e,"Unable to initialize libsodium.",0);
  }
  FUN_00892d00();
  if ((*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01f2d824) &&
     (FUN_016f3809(&DAT_01f2d824), DAT_01f2d824 == -1)) {
    uStack_8 = 0;
    FUN_00895650();
    uStack_8 = 0xffffffff;
    FUN_016f37bf(&DAT_01f2d824);
  }
  FUN_00910d90();
  uVar4 = FUN_01675290(DAT_01ee1098);
  uStack_8 = 1;
  uStack_18 = uVar4;
  if (DAT_01ee05b8 == 0) {
    piVar6 = (int *)FUN_00910e00();
    iStack_14 = *piVar6;
    FUN_005693c0(iStack_14 + 0xac);
    uStack_8._0_1_ = 3;
    if (DAT_01ee05b8 == 0) {
      FUN_008e21d0(&puStack_20);
      uStack_8._0_1_ = 4;
      FUN_008a65e0(iStack_14,0);
      piVar6 = piStack_1c;
      if (piStack_1c != (int *)0x0) {
        LOCK();
        iVar3 = piStack_1c[1] + -1;
        piStack_1c[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_1c)();
          LOCK();
          piVar1 = piVar6 + 2;
          iVar3 = *piVar1 + -1;
          *piVar1 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    if ((char)piStack_24 != '\0') {
      LOCK();
      uVar2 = *puStack_28;
      *puStack_28 = *puStack_28 + 0x80000000;
      UNLOCK();
      if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
        LOCK();
        uVar2 = *puStack_28;
        *puStack_28 = *puStack_28 | 0x40000000;
        UNLOCK();
        if ((uVar2 >> 0x1e & 1) == 0) {
          uVar5 = FUN_00554e40();
          SetEvent(uVar5);
        }
      }
    }
    uStack_8 = 6;
  }
  else {
    uStack_8 = 2;
  }
  FUN_01675290(uVar4);
  uStack_8 = 0xffffffff;
  if (DAT_01ea8528 == 0) {
    piVar6 = (int *)FUN_00910d90();
    iVar3 = *piVar6;
    FUN_005693c0(iVar3 + 0x94);
    uStack_8 = 7;
    if (DAT_01ea8528 == 0) {
      FUN_0055e190(&puStack_28);
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      FUN_008a65e0(iVar3,0);
      piVar6 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar1 = piVar6 + 2;
          iVar3 = *piVar1 + -1;
          *piVar1 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
    }
    uStack_8 = 9;
    if ((char)piStack_1c != '\0') {
      LOCK();
      uVar2 = *puStack_20;
      *puStack_20 = *puStack_20 + 0x80000000;
      UNLOCK();
      if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
        LOCK();
        uVar2 = *puStack_20;
        *puStack_20 = *puStack_20 | 0x40000000;
        UNLOCK();
        if ((uVar2 >> 0x1e & 1) == 0) {
          uVar4 = FUN_00554e40();
          SetEvent(uVar4);
        }
      }
    }
  }
  uStack_8 = 0xffffffff;
  if (DAT_01ee2b08 == 0) {
    piVar6 = (int *)FUN_00910d90();
    iVar3 = *piVar6;
    FUN_005693c0(iVar3 + 0x94);
    uStack_8 = 10;
    if (DAT_01ee2b08 == 0) {
      FUN_00942e00(&puStack_28);
      uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
      FUN_008a65e0(iVar3,0);
      piVar6 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar1 = piVar6 + 2;
          iVar3 = *piVar1 + -1;
          *piVar1 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
    }
    uStack_8 = 0xc;
    if ((char)piStack_1c != '\0') {
      LOCK();
      uVar2 = *puStack_20;
      *puStack_20 = *puStack_20 + 0x80000000;
      UNLOCK();
      if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
        LOCK();
        uVar2 = *puStack_20;
        *puStack_20 = *puStack_20 | 0x40000000;
        UNLOCK();
        if ((uVar2 >> 0x1e & 1) == 0) {
          uVar4 = FUN_00554e40();
          SetEvent(uVar4);
        }
      }
    }
  }
  uStack_8 = 0xffffffff;
  if (DAT_01ee1708 == 0) {
    piVar6 = (int *)FUN_00910d90();
    iVar3 = *piVar6;
    FUN_005693c0(iVar3 + 0x94);
    uStack_8 = 0xd;
    if (DAT_01ee1708 == 0) {
      FUN_00911550(&puStack_28);
      uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
      FUN_008a65e0(iVar3,0);
      piVar6 = piStack_24;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar1 = piVar6 + 2;
          iVar3 = *piVar1 + -1;
          *piVar1 = iVar3;
          UNLOCK();
          if (iVar3 == 0) {
            (**(code **)(*piVar6 + 4))();
          }
        }
      }
    }
    uStack_8 = 0xf;
    if ((char)piStack_1c != '\0') {
      LOCK();
      uVar2 = *puStack_20;
      *puStack_20 = *puStack_20 + 0x80000000;
      UNLOCK();
      if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
        LOCK();
        uVar2 = *puStack_20;
        *puStack_20 = *puStack_20 | 0x40000000;
        UNLOCK();
        if ((uVar2 >> 0x1e & 1) == 0) {
          uVar4 = FUN_00554e40();
          SetEvent(uVar4);
        }
      }
    }
  }
  uStack_8 = 0xffffffff;
  if (DAT_01ef8178 == 0) {
    piVar6 = (int *)FUN_00910d90();
    iVar3 = *piVar6;
    FUN_005693c0(iVar3 + 0x94);
    uStack_8 = 0x10;
    if (DAT_01ef8178 == 0) {
      FUN_00c00d00(&puStack_28);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
      FUN_008a65e0(iVar3,0);
      if (piStack_24 != (int *)0x0) {
        LOCK();
        iVar3 = piStack_24[1] + -1;
        piStack_24[1] = iVar3;
        UNLOCK();
        if (iVar3 == 0) {
          (**(code **)*piStack_24)();
          LOCK();
          piVar6 = piStack_24 + 2;
          iVar3 = *piVar6;
          *piVar6 = *piVar6 + -1;
          UNLOCK();
          if (iVar3 == 1) {
            (**(code **)(*piStack_24 + 4))();
          }
        }
      }
    }
    uStack_8 = 0x12;
    if ((char)piStack_1c != '\0') {
      LOCK();
      uVar2 = *puStack_20;
      *puStack_20 = *puStack_20 + 0x80000000;
      UNLOCK();
      if (((uVar2 & 0x40000000) == 0) && (-0x80000000 < (int)uVar2)) {
        LOCK();
        uVar2 = *puStack_20;
        *puStack_20 = *puStack_20 | 0x40000000;
        UNLOCK();
        if ((uVar2 >> 0x1e & 1) == 0) {
          uVar4 = FUN_00554e40();
          SetEvent(uVar4);
        }
      }
    }
  }
  uStack_8 = 0xffffffff;
  FUN_0107c570();
  FUN_00bbe160();
  thunk_FUN_016798e0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 15994 ; VA 0x0090de90 ; FUN_0090de90 */

undefined * FUN_0090de90(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c57dc;
  pvStack_10 = ExceptionList;
  if (DAT_01ee12d8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee14e8) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee14e8);
      if (DAT_01ee14e8 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_0090e050();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"GlobalSettings",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01883a30);
        FUN_016f37bf(&DAT_01ee14e8);
      }
    }
    DAT_01ee12d8 = &DAT_01ee12e0;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee12d8;
}



/* FUNCTION 15995 ; VA 0x0090df70 ; FUN_0090df70 */

undefined * FUN_0090df70(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c57fc;
  pvStack_10 = ExceptionList;
  if (DAT_01ee14f0 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee1700) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee1700);
      if (DAT_01ee1700 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_0090e050();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"UserSettings",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01883a40);
        FUN_016f37bf(&DAT_01ee1700);
      }
    }
    DAT_01ee14f0 = &DAT_01ee14f8;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee14f0;
}



/* FUNCTION 15996 ; VA 0x0090e050 ; FUN_0090e050 */

undefined * FUN_0090e050(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017c581c;
  pvStack_10 = ExceptionList;
  if (DAT_01ee10c4 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee12d0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01ee12d0);
      if (DAT_01ee12d0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_008a8c30();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"GenericSettings",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_01883a50);
        FUN_016f37bf(&DAT_01ee12d0);
      }
    }
    DAT_01ee10c4 = &DAT_01ee10c8;
  }
  ExceptionList = pvStack_10;
  return DAT_01ee10c4;
}



/* FUNCTION 15997 ; VA 0x0090e130 ; FUN_0090e130 */

int __thiscall FUN_0090e130(int *param_1,undefined4 *param_2,undefined4 *param_3)

{
  uint uVar1;
  int *piVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  uint uVar10;
  undefined4 *puVar11;
  undefined4 *puVar12;
  undefined4 *puVar13;
  undefined4 *puVar14;
  
  iVar9 = *param_1;
  iVar5 = (int)param_2 - iVar9 >> 4;
  iVar6 = param_1[1] - iVar9 >> 4;
  if (iVar6 == 0xfffffff) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar1 = iVar6 + 1;
  uVar10 = param_1[2] - iVar9 >> 4;
  uVar7 = uVar1;
  if ((uVar10 <= 0xfffffff - (uVar10 >> 1)) && (uVar7 = (uVar10 >> 1) + uVar10, uVar7 < uVar1)) {
    uVar7 = uVar1;
  }
  uVar10 = uVar7 * 0x10;
  if (uVar7 < 0x10000000) {
    if (0xfff < uVar10) goto LAB_0090e1a3;
    if (uVar10 == 0) {
      puVar13 = (undefined4 *)0x0;
    }
    else {
      puVar13 = (undefined4 *)FUN_01674e20(uVar10);
    }
  }
  else {
    uVar10 = 0xffffffff;
LAB_0090e1a3:
    uVar8 = uVar10 + 0x23;
    if (uVar8 <= uVar10) {
      uVar8 = 0xffffffff;
    }
    iVar9 = FUN_01674e20(uVar8);
    if (iVar9 == 0) goto LAB_0090e301;
    puVar13 = (undefined4 *)(iVar9 + 0x23U & 0xffffffe0);
    puVar13[-1] = iVar9;
  }
  puVar14 = puVar13 + iVar5 * 4;
  *puVar14 = *param_3;
  puVar14[1] = param_3[1];
  puVar14[2] = 0;
  puVar14[3] = 0;
  if (param_3[3] != 0) {
    LOCK();
    piVar2 = (int *)(param_3[3] + 4);
    *piVar2 = *piVar2 + 1;
    UNLOCK();
  }
  puVar14[2] = param_3[2];
  puVar14[3] = param_3[3];
  puVar4 = (undefined4 *)param_1[1];
  puVar11 = (undefined4 *)*param_1;
  if (param_2 == puVar4) {
    puVar14 = puVar13;
    if (puVar11 != puVar4) {
      puVar12 = puVar13 + 3;
      do {
        *puVar14 = *puVar11;
        puVar12[-2] = puVar11[1];
        puVar12[-1] = 0;
        *puVar12 = 0;
        if (puVar11[3] != 0) {
          LOCK();
          piVar2 = (int *)(puVar11[3] + 4);
          *piVar2 = *piVar2 + 1;
          UNLOCK();
        }
        puVar14 = puVar14 + 4;
        puVar12[-1] = puVar11[2];
        puVar3 = puVar11 + 3;
        puVar11 = puVar11 + 4;
        *puVar12 = *puVar3;
        puVar12 = puVar12 + 4;
      } while (puVar11 != puVar4);
    }
    FUN_0075c360(puVar14,puVar14,param_1);
  }
  else {
    FUN_0090f1e0(puVar11,param_2,puVar13);
    FUN_0090f1e0(param_2,param_1[1],puVar14 + 4);
  }
  if (*param_1 != 0) {
    FUN_0075c360(*param_1,param_1[1],param_1);
    iVar9 = *param_1;
    uVar10 = param_1[2] - iVar9 & 0xfffffff0;
    iVar6 = iVar9;
    if (0xfff < uVar10) {
      iVar6 = *(int *)(iVar9 + -4);
      uVar10 = uVar10 + 0x23;
      if (0x1f < (iVar9 - iVar6) - 4U) {
LAB_0090e301:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar6,uVar10);
  }
  *param_1 = (int)puVar13;
  param_1[1] = (int)(puVar13 + uVar1 * 4);
  param_1[2] = (int)(puVar13 + uVar7 * 4);
  return *param_1 + iVar5 * 0x10;
}



/* FUNCTION 15998 ; VA 0x0090e310 ; FUN_0090e310 */

int __thiscall FUN_0090e310(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017c5830;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::GlobalAdvancedSettings*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 15999 ; VA 0x0090e3e2 ; Catch_All@0090e3e2 */

void Catch_All_0090e3e2(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}


