/* RCCService.exe: Ghidra-generated C-like pseudocode. NOT compilable original source.
   Sections are inferred native functions, not independently buildable C translation units. */


/* FUNCTION 24000 ; VA 0x00b3f0a0 ; FUN_00b3f0a0 */

undefined4 * __thiscall FUN_00b3f0a0(undefined4 *param_1,byte param_2)

{
  *param_1 = boost::date_time::year_based_generator<class_boost::gregorian::date>::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 24001 ; VA 0x00b3f0d0 ; FUN_00b3f0d0 */

void FUN_00b3f0d0(undefined4 param_1,undefined4 *param_2)

{
  int *piVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined uVar5;
  ushort uVar6;
  ushort uVar7;
  ushort uVar8;
  int *piVar9;
  uint uVar10;
  undefined4 *puVar11;
  uint *puVar12;
  undefined auStack_1a4 [24];
  undefined auStack_18c [24];
  undefined uStack_174;
  undefined uStack_173;
  undefined4 uStack_170;
  undefined uStack_16c;
  undefined4 *puStack_168;
  int iStack_164;
  undefined auStack_160 [24];
  undefined auStack_148 [24];
  undefined uStack_130;
  undefined uStack_12f;
  undefined4 uStack_12c;
  undefined uStack_128;
  uint uStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  uint uStack_10c;
  undefined4 uStack_108;
  undefined4 uStack_104;
  undefined4 uStack_100;
  undefined uStack_f4;
  undefined uStack_f3;
  undefined4 uStack_f0;
  undefined uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined uStack_e0;
  uint uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined8 uStack_cc;
  undefined uStack_c4;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined uStack_ac;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined2 uStack_94;
  undefined4 uStack_90;
  undefined uStack_8c;
  uint uStack_88;
  uint uStack_84;
  uint uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  uint uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined uStack_50;
  undefined uStack_4f;
  undefined4 uStack_4c;
  undefined uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined uStack_3c;
  uint uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  uint uStack_24;
  int iStack_20;
  undefined4 *puStack_1c;
  int *piStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f28b7;
  pvStack_10 = ExceptionList;
  uStack_14 = CONCAT13(uStack_14._3_1_,0x2e4d);
  uStack_b4 = 0;
  uStack_b0 = 0xf;
  uStack_c4 = 0;
  puVar12 = &uStack_14;
  uStack_8 = 0;
  uStack_9c = 0;
  uStack_98 = 0xf;
  uStack_ac = 0;
  do {
    cVar2 = *(char *)puVar12;
    puVar12 = (uint *)((int)puVar12 + 1);
  } while (cVar2 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0();
  uStack_94 = 0;
  uStack_90 = 0;
  uStack_8c = 0;
  uStack_8 = 2;
  FUN_0054ef60();
  uStack_8._0_1_ = 3;
  FUN_0054ef60();
  uStack_174 = (undefined)uStack_94;
  uStack_173 = uStack_94._1_1_;
  uStack_170 = uStack_90;
  uStack_16c = uStack_8c;
  uStack_8._0_1_ = 4;
  puVar11 = param_2;
  puStack_168 = param_2;
  if (0xf < (uint)param_2[5]) {
    puStack_168 = (undefined4 *)*param_2;
    puVar11 = (undefined4 *)*param_2;
  }
  iStack_164 = param_2[4] + (int)puVar11;
  FUN_0054ef60();
  uStack_8._0_1_ = 5;
  FUN_0054ef60();
  uStack_130 = (undefined)uStack_94;
  uStack_12f = uStack_94._1_1_;
  uStack_12c = uStack_90;
  uStack_128 = uStack_8c;
  uStack_8._0_1_ = 6;
  FUN_0054ef60(auStack_1a4);
  uStack_8._0_1_ = 7;
  FUN_0054ef60(auStack_18c);
  uStack_8._0_1_ = 6;
  FUN_00590840();
  uStack_8._0_1_ = 8;
  FUN_00b34d50();
  uStack_8._0_1_ = 9;
  uVar6 = FUN_009d6080();
  piVar9 = (int *)(uint)uVar6;
  uStack_8._0_1_ = 8;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  if (0xf < uStack_24) {
    if ((0xfff < uStack_24 + 1) && (0x1f < (uStack_38 - *(int *)(uStack_38 - 4)) - 4)) {
      uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  uStack_38 = uStack_38 & 0xffffff00;
  FUN_005509f0();
  FUN_00b34d50();
  uStack_8._0_1_ = 10;
  uStack_88 = FUN_009d6080();
  uStack_88 = uStack_88 & 0xffff;
  uStack_8._0_1_ = 8;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  if (0xf < uStack_24) {
    if ((0xfff < uStack_24 + 1) && (0x1f < (uStack_38 - *(int *)(uStack_38 - 4)) - 4)) {
      uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  uStack_38 = uStack_38 & 0xffffff00;
  FUN_005509f0();
  uStack_84 = FUN_009d6080();
  uStack_84 = uStack_84 & 0xffff;
  FUN_0054ef60(auStack_160);
  uStack_8._0_1_ = 0xb;
  FUN_0054ef60(auStack_148);
  uStack_8._0_1_ = 8;
  FUN_00590840();
  FUN_005507b0();
  uStack_124 = uStack_80;
  uStack_80 = uStack_80 & 0xffffff00;
  uStack_120 = uStack_7c;
  uStack_11c = uStack_78;
  uStack_118 = uStack_74;
  uStack_70 = 0;
  uStack_6c = 0xf;
  FUN_005507b0();
  uStack_f4 = uStack_50;
  uStack_f3 = uStack_4f;
  uStack_f0 = uStack_4c;
  uStack_ec = uStack_48;
  uStack_e8 = uStack_44;
  uStack_10c = uStack_68;
  uStack_108 = uStack_64;
  uStack_104 = uStack_60;
  uStack_100 = uStack_5c;
  uStack_e4 = uStack_40;
  uStack_58 = 0;
  uStack_54 = 0xf;
  uStack_68 = uStack_68 & 0xffffff00;
  uStack_e0 = uStack_3c;
  FUN_005507b0();
  uStack_dc = uStack_38;
  uStack_38 = uStack_38 & 0xffffff00;
  uStack_d8 = uStack_34;
  uStack_d4 = uStack_30;
  uStack_d0 = uStack_2c;
  uStack_cc = CONCAT44(uStack_24,uStack_28);
  uStack_28 = 0;
  uStack_24 = 0xf;
  FUN_005509f0();
  FUN_00b34d50();
  uStack_8._0_1_ = 0xc;
  uVar7 = FUN_009d6080();
  uStack_8._0_1_ = 8;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  if (0xf < uStack_24) {
    if ((0xfff < uStack_24 + 1) && (0x1f < (uStack_38 - *(int *)(uStack_38 - 4)) - 4)) {
      uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  uStack_38 = uStack_38 & 0xffffff00;
  FUN_005509f0();
  FUN_00b34d50();
  uStack_8._0_1_ = 0xd;
  uVar10 = FUN_009d6080();
  uStack_14 = uVar10 & 0xffff;
  uStack_8._0_1_ = 8;
  uVar5 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  if (0xf < uStack_24) {
    if ((0xfff < uStack_24 + 1) && (0x1f < (uStack_38 - *(int *)(uStack_38 - 4)) - 4)) {
      uStack_8._0_1_ = uVar5;
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
    FUN_01674ea0();
  }
  uStack_28 = 0;
  uStack_24 = 0xf;
  uStack_38 = uStack_38 & 0xffffff00;
  FUN_005509f0();
  uVar8 = FUN_009d6080();
  puVar11 = (undefined4 *)FUN_01674e20();
  uStack_8._0_1_ = 0xe;
  if (puVar11 == (undefined4 *)0x0) {
    puVar11 = (undefined4 *)0x0;
LAB_00b3f74e:
    piStack_18 = (int *)0x0;
    uStack_8._0_1_ = 0x10;
    puStack_1c = puVar11;
    puVar11 = (undefined4 *)FUN_00b33ab0();
    uVar3 = *puVar11;
    *puVar11 = piStack_18;
    uStack_8._0_1_ = 0x11;
    piStack_18 = (int *)uVar3;
    if (piVar9 != (int *)0x0) {
      LOCK();
      iVar4 = piVar9[1] + -1;
      piVar9[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar9 + 4))();
        LOCK();
        iVar4 = piVar9[2] + -1;
        piVar9[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar9 + 8))();
        }
      }
    }
    _guard_check_icall();
    piVar1 = piStack_18;
    piStack_18 = (int *)0x0;
    *(undefined4 **)(iStack_20 + 0x88) = puStack_1c;
    puStack_1c = (undefined4 *)0x0;
    piVar9 = *(int **)(iStack_20 + 0x8c);
    *(int **)(iStack_20 + 0x8c) = piVar1;
    uStack_8._0_1_ = 0x12;
    if (piVar9 != (int *)0x0) {
      LOCK();
      iVar4 = piVar9[1] + -1;
      piVar9[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piVar9 + 4))();
        LOCK();
        iVar4 = piVar9[2] + -1;
        piVar9[2] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)(*piVar9 + 8))();
        }
      }
    }
    piVar9 = piStack_18;
    uStack_8._0_1_ = 0x13;
    if (piStack_18 != (int *)0x0) {
      LOCK();
      iVar4 = piStack_18[1] + -1;
      piStack_18[1] = iVar4;
      UNLOCK();
      if (iVar4 == 0) {
        (**(code **)(*piStack_18 + 4))();
        LOCK();
        piVar1 = piVar9 + 2;
        iVar4 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar4 == 1) {
          (**(code **)(*piVar9 + 8))();
        }
      }
    }
    if (uStack_cc._4_4_ < 0x10) {
LAB_00b3f862:
      uStack_cc = 0xf00000000;
      uStack_dc = uStack_dc & 0xffffff00;
      FUN_005509f0();
      FUN_005509f0();
      FUN_005509f0();
      FUN_005509f0();
      ExceptionList = pvStack_10;
      return;
    }
    if ((uStack_cc._4_4_ + 1 < 0x1000) || ((uStack_dc - *(int *)(uStack_dc - 4)) - 4 < 0x20)) {
      FUN_01674ea0();
      goto LAB_00b3f862;
    }
    goto LAB_00b3f91f;
  }
  if (uVar7 + 1 < 2) {
    FUN_00588640();
LAB_00b3f8d9:
    FUN_00588640();
LAB_00b3f8e3:
    FUN_00b47210();
LAB_00b3f8ed:
    FUN_00b47210();
LAB_00b3f8f7:
    FUN_00588640();
LAB_00b3f901:
    FUN_00588640();
LAB_00b3f90b:
    FUN_00b47210();
  }
  else {
    if (0xc < uVar7) goto LAB_00b3f8d9;
    if (uVar8 == 0xffffffff) goto LAB_00b3f8e3;
    if (6 < uVar8) goto LAB_00b3f8ed;
    uStack_8._0_1_ = 0xf;
    if ((int)piVar9 + 1U < 2) goto LAB_00b3f8f7;
    if (0xc < uVar6) goto LAB_00b3f901;
    if ((uStack_84 & 0xffff) == 0xffffffff) goto LAB_00b3f90b;
    if ((ushort)uStack_84 < 7) {
      *puVar11 = boost::date_time::day_calc_dst_rule<struct_boost::local_time::nth_kday_rule_spec>::
                 vftable;
      *(ushort *)(puVar11 + 4) = (ushort)uStack_84;
      puVar11[3] = uStack_88 & 0xffff;
      *(ushort *)(puVar11 + 2) = uVar6;
      puVar11[1] = boost::date_time::nth_kday_of_month<class_boost::gregorian::date>::vftable;
      puVar11[5] = boost::date_time::nth_kday_of_month<class_boost::gregorian::date>::vftable;
      *(ushort *)(puVar11 + 6) = uVar7;
      puVar11[7] = uStack_14 & 0xffff;
      *(ushort *)(puVar11 + 8) = uVar8;
      goto LAB_00b3f74e;
    }
  }
  FUN_00b47210();
LAB_00b3f91f:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 24002 ; VA 0x00b3f930 ; FUN_00b3f930 */

void __thiscall FUN_00b3f930(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  
  for (puVar1 = *(undefined4 **)(param_1 + 0x2c); puVar1 != (undefined4 *)0x0;
      puVar1 = (undefined4 *)*puVar1) {
    (*(code *)puVar1[2])(param_2,param_1,puVar1[1]);
  }
  return;
}



/* FUNCTION 24003 ; VA 0x00b3f960 ; FUN_00b3f960 */

void __thiscall FUN_00b3f960(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined auStack_24 [8];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f28d0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  puVar1 = param_1 + 1;
  ExceptionList = &pvStack_10;
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  puStack_18 = param_1;
  FUN_00a15350();
  *param_1 = *puVar2;
  param_2 = (undefined4 *)*puVar1;
  uStack_8 = 0;
  FUN_00a1ab20((int)(puVar2[4] - puVar2[3]) >> 2,&param_2);
  puVar2 = (undefined4 *)puVar2[1];
  puVar4 = (undefined4 *)*puVar2;
  while( true ) {
    if (puVar4 == puVar2) {
      ExceptionList = pvStack_10;
      return;
    }
    param_2 = *(undefined4 **)*puVar1;
    puStack_1c = *(undefined4 **)((int)param_2 + 4);
    uVar3 = FUN_00b35080(param_2,puStack_1c,puVar4 + 2);
    if (param_1[2] == 0x71c71c6) break;
    param_1[2] = param_1[2] + 1;
    *(undefined4 *)((int)param_2 + 4) = uVar3;
    *puStack_1c = uVar3;
    FUN_00b35560(auStack_24,*(int *)*puVar1 + 8,*(int *)*puVar1);
    puVar4 = (undefined4 *)*puVar4;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 24004 ; VA 0x00b3fa44 ; Catch_All@00b3fa44 */

void Catch_All_00b3fa44(void)

{
  FUN_00b40f30();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24005 ; VA 0x00b3fa60 ; FUN_00b3fa60 */

void __thiscall FUN_00b3fa60(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined auStack_24 [8];
  undefined4 *puStack_1c;
  undefined4 *puStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar2 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f28e0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffffd0;
  puVar1 = param_1 + 1;
  ExceptionList = &pvStack_10;
  param_1[6] = param_2[6];
  param_1[7] = param_2[7];
  puStack_18 = param_1;
  FUN_00a3fce0();
  *param_1 = *puVar2;
  param_2 = (undefined4 *)*puVar1;
  uStack_8 = 0;
  FUN_00a1ab20((int)(puVar2[4] - puVar2[3]) >> 2,&param_2);
  puVar2 = (undefined4 *)puVar2[1];
  puVar4 = (undefined4 *)*puVar2;
  while( true ) {
    if (puVar4 == puVar2) {
      ExceptionList = pvStack_10;
      return;
    }
    param_2 = *(undefined4 **)*puVar1;
    puStack_1c = *(undefined4 **)((int)param_2 + 4);
    uVar3 = FUN_00b35100(param_2,puStack_1c,puVar4 + 2);
    if (param_1[2] == 0x4924923) break;
    param_1[2] = param_1[2] + 1;
    *(undefined4 *)((int)param_2 + 4) = uVar3;
    *puStack_1c = uVar3;
    FUN_00a377b0(auStack_24,*(int *)*puVar1 + 8,*(int *)*puVar1);
    puVar4 = (undefined4 *)*puVar4;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016ddcd9("list<T> too long");
}



/* FUNCTION 24006 ; VA 0x00b3fb44 ; Catch_All@00b3fb44 */

void Catch_All_00b3fb44(void)

{
  FUN_00a52860();
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24007 ; VA 0x00b3fb60 ; FUN_00b3fb60 */

void FUN_00b3fb60(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_00b3fb60(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_00b3d060();
    FUN_01674ea0(param_1,0x20);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 24008 ; VA 0x00b3fbb0 ; FUN_00b3fbb0 */

void FUN_00b3fbb0(int *param_1)

{
  char cVar1;
  int *piVar2;
  
  cVar1 = *(char *)((int)param_1 + 0xd);
  while (cVar1 == '\0') {
    FUN_00b3fbb0(param_1[2]);
    piVar2 = (int *)*param_1;
    FUN_005509f0();
    FUN_01674ea0(param_1,0x44);
    param_1 = piVar2;
    cVar1 = *(char *)((int)piVar2 + 0xd);
  }
  return;
}



/* FUNCTION 24009 ; VA 0x00b3fc00 ; FUN_00b3fc00 */

void __thiscall FUN_00b3fc00(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar1 = param_1[1];
  iVar2 = *param_1;
  uVar3 = FUN_00577fb0(param_2);
  FUN_0055c6d0(*param_1,param_1[1],uVar3,param_1);
  FUN_00575cd0(uVar3,(iVar1 - iVar2) / 0x18,param_2);
  return;
}



/* FUNCTION 24010 ; VA 0x00b3fc50 ; FUN_00b3fc50 */

void __fastcall FUN_00b3fc50(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00b3fb60(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24011 ; VA 0x00b3fcb0 ; FUN_00b3fcb0 */

void __fastcall FUN_00b3fcb0(int *param_1)

{
  int iVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01791da0;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00b3fbb0(*(undefined4 *)(iVar1 + 4));
  *(int *)(*param_1 + 4) = iVar1;
  *(int *)*param_1 = iVar1;
  *(int *)(*param_1 + 8) = iVar1;
  param_1[1] = 0;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24012 ; VA 0x00b3fd10 ; FUN_00b3fd10 */

int __thiscall FUN_00b3fd10(int param_1,int param_2)

{
  code *pcVar1;
  int iVar2;
  
  FUN_0097be30(&param_2,param_2);
  if (param_2 != *(int *)(param_1 + 4)) {
    return param_2 + 0x20;
  }
  FUN_016ddcf9("invalid unordered_map<K, T> key");
  pcVar1 = (code *)swi(3);
  iVar2 = (*pcVar1)();
  return iVar2;
}



/* FUNCTION 24013 ; VA 0x00b3fd40 ; FUN_00b3fd40 */

void __thiscall FUN_00b3fd40(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x6c);
  *param_2 = *(undefined4 *)(param_1 + 0x68);
  param_2[1] = uVar1;
  return;
}



/* FUNCTION 24014 ; VA 0x00b3fd60 ; FUN_00b3fd60 */

void __thiscall FUN_00b3fd60(int param_1,undefined4 *param_2)

{
  code *pcVar1;
  char cVar2;
  char cVar3;
  undefined4 *puVar4;
  int iVar5;
  char *pcVar6;
  bool bVar7;
  undefined8 uVar8;
  int iStack_1ec;
  int iStack_1e8;
  char cStack_1e4;
  int iStack_1e0;
  uint uStack_1cc;
  int iStack_18c;
  int iStack_188;
  int iStack_12c;
  int iStack_128;
  undefined auStack_100 [24];
  undefined auStack_e8 [24];
  undefined uStack_d0;
  undefined uStack_cf;
  undefined4 uStack_cc;
  undefined uStack_c8;
  undefined4 *puStack_c4;
  int iStack_c0;
  undefined auStack_bc [24];
  undefined auStack_a4 [24];
  undefined uStack_8c;
  undefined uStack_8b;
  undefined4 uStack_88;
  undefined uStack_84;
  undefined uStack_80;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined uStack_68;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined2 uStack_50;
  undefined4 uStack_4c;
  undefined uStack_48;
  undefined4 uStack_44;
  uint uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  uint uStack_34;
  int iStack_30;
  undefined4 uStack_20;
  uint uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f298a;
  pvStack_10 = ExceptionList;
  uStack_14 = CONCAT22(uStack_14._2_2_,0x2f);
  uStack_70 = 0;
  uStack_6c = 0xf;
  uStack_80 = 0;
  pcVar6 = (char *)&uStack_14;
  uStack_8 = 0;
  uStack_58 = 0;
  uStack_54 = 0xf;
  uStack_68 = 0;
  do {
    cVar2 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar2 != '\0');
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_005542c0();
  uStack_50 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_8 = 2;
  puVar4 = param_2;
  puStack_c4 = param_2;
  if (0xf < (uint)param_2[5]) {
    puStack_c4 = (undefined4 *)*param_2;
    puVar4 = (undefined4 *)*param_2;
  }
  iStack_c0 = param_2[4] + (int)puVar4;
  FUN_0054ef60();
  uStack_8._0_1_ = 3;
  FUN_0054ef60();
  uStack_8c = (undefined)uStack_50;
  uStack_8b = uStack_50._1_1_;
  uStack_88 = uStack_4c;
  uStack_84 = uStack_48;
  uStack_8._0_1_ = 4;
  FUN_0054ef60();
  uStack_8._0_1_ = 5;
  FUN_0054ef60();
  uStack_d0 = (undefined)uStack_50;
  uStack_cf = uStack_50._1_1_;
  uStack_cc = uStack_4c;
  uStack_c8 = uStack_48;
  uStack_8._0_1_ = 6;
  FUN_0054ef60(auStack_bc);
  uStack_8._0_1_ = 7;
  FUN_0054ef60(auStack_a4);
  uStack_8._0_1_ = 6;
  FUN_00590840();
  uStack_8._0_1_ = 8;
  FUN_0054ef60(auStack_100);
  uStack_8._0_1_ = 9;
  FUN_0054ef60(auStack_e8);
  uStack_8._0_1_ = 8;
  FUN_00590840();
  uStack_8._0_1_ = 10;
  pcVar6 = (char *)FUN_0054ef60();
  uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
  if (*(int *)(pcVar6 + 0x10) != 0) {
    if (0xf < *(uint *)(pcVar6 + 0x14)) {
      pcVar6 = *(char **)pcVar6;
    }
    cVar2 = *pcVar6;
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    if (0xf < uStack_1c) {
      if ((0xfff < uStack_1c + 1) && (0x1f < (iStack_30 - *(int *)(iStack_30 + -4)) - 4U))
      goto LAB_00b40404;
      FUN_01674ea0();
    }
    if (cVar2 == 'M') {
      FUN_00b3f0d0();
    }
    else if (cVar2 == 'J') {
      FUN_00b467b0();
    }
    else {
      FUN_00b46650();
    }
    cVar2 = FUN_005904a0();
    cVar3 = FUN_005904a0();
    FUN_0054ef60(auStack_bc);
    uStack_8._0_1_ = 0xc;
    FUN_0054ef60(auStack_a4);
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    FUN_00590840();
    if ((cStack_1e4 == '\0') || (cVar2 == '\0')) {
      bVar7 = cStack_1e4 != cVar2;
    }
    else if ((iStack_1ec == iStack_12c) && (iStack_1e8 == iStack_128)) {
      bVar7 = false;
    }
    else {
      bVar7 = true;
    }
    if (0xf < uStack_1cc) {
      if ((0xfff < uStack_1cc + 1) && (0x1f < (iStack_1e0 - *(int *)(iStack_1e0 + -4)) - 4U)) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      FUN_01674ea0();
    }
    FUN_005509f0();
    if (bVar7) {
      puVar4 = (undefined4 *)FUN_009d6260();
      *(undefined4 *)(param_1 + 0x78) = *puVar4;
      *(undefined4 *)(param_1 + 0x7c) = puVar4[1];
    }
    else {
      uVar8 = FUN_016f39b0();
      *(undefined8 *)(param_1 + 0x78) = uVar8;
    }
    uStack_14 = 0;
    uVar8 = FUN_016f39b0();
    uStack_40 = (uint)((ulonglong)uVar8 >> 0x20);
    uStack_3c = (undefined4)uVar8;
    uStack_38 = uStack_3c;
    uStack_34 = uStack_40;
    iVar5 = FUN_00874e00();
    if (iVar5 != -1) {
      uVar8 = FUN_016f39b0();
      uStack_34 = (uint)((ulonglong)uVar8 >> 0x20);
      uStack_44 = (undefined4)uVar8;
      uStack_20 = uStack_44;
      uStack_1c = uStack_34;
      iVar5 = FUN_00874e00();
      if (iVar5 == -1) {
        iVar5 = FUN_00591280();
        if ((*(char *)(iVar5 + 0x44) == '\0') || (cVar3 == '\0')) {
          bVar7 = *(char *)(iVar5 + 0x44) != cVar3;
        }
        else if ((*(int *)(iVar5 + 0x3c) == iStack_18c) && (*(int *)(iVar5 + 0x40) == iStack_188)) {
          bVar7 = false;
        }
        else {
          bVar7 = true;
        }
        FUN_00590940();
        if (bVar7) {
          puVar4 = (undefined4 *)FUN_009d6260();
          *(undefined4 *)(iStack_18 + 0x80) = *puVar4;
          *(undefined4 *)(iStack_18 + 0x84) = puVar4[1];
        }
        else {
          uVar8 = FUN_016f39b0();
          *(undefined8 *)(iStack_18 + 0x80) = uVar8;
        }
        uStack_20 = uStack_3c;
        uStack_1c = uStack_40;
        iVar5 = FUN_00874e00();
        if (iVar5 != -1) {
          uStack_20 = uStack_44;
          uStack_1c = uStack_34;
          iVar5 = FUN_00874e00();
          if (iVar5 == -1) {
            FUN_00590940();
            FUN_00590940();
            FUN_005509f0();
            FUN_005509f0();
            FUN_005509f0();
            ExceptionList = pvStack_10;
            return;
          }
        }
        FUN_005ef620();
        FUN_0087c420();
        uStack_8._0_1_ = 0xf;
        FUN_00b3cbd0();
        uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
        FUN_00b38ee0();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
      }
    }
    FUN_005ef620();
    FUN_0087c420();
    uStack_8._0_1_ = 0xd;
    FUN_00b3cbd0();
    uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
    FUN_00b38ee0();
  }
  FUN_00554050();
LAB_00b40404:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 24015 ; VA 0x00b403ce ; FUN_00b403ce */

void FUN_00b403ce(void)

{
  undefined4 uVar1;
  int unaff_EBP;
  undefined4 unaff_EDI;
  
  FUN_005ef620(unaff_EDI);
  uVar1 = FUN_0087c420(unaff_EBP + -0x23c);
  *(undefined *)(unaff_EBP + -4) = 0xd;
  uVar1 = FUN_00b3cbd0(uVar1);
  *(undefined *)(unaff_EBP + -4) = 0xe;
  FUN_00b38ee0(uVar1);
  FUN_00554050();
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 24016 ; VA 0x00b40440 ; FUN_00b40440 */

void FUN_00b40440(char *param_1)

{
  char cVar1;
  code *pcVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  char *pcVar7;
  uint uVar8;
  char *pcVar9;
  uint uVar10;
  char *pcVar11;
  int iVar12;
  undefined8 uVar13;
  undefined **ppuStack_180;
  undefined auStack_17c [72];
  undefined4 uStack_134;
  undefined **ppuStack_130;
  uint uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  uint uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  uint uStack_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  uint uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  uint uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  uint uStack_74;
  uint uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  int iStack_60;
  uint uStack_5c;
  uint uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_48;
  uint uStack_44;
  char *pcStack_40;
  uint uStack_3c;
  int iStack_38;
  int iStack_34;
  int iStack_30;
  uint uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  uint uStack_18;
  undefined2 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2a5e;
  pvStack_10 = ExceptionList;
  iStack_34 = 0;
  pcVar9 = (char *)&uStack_14;
  uStack_14 = 0;
  iStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  do {
    cVar1 = *pcVar9;
    pcVar9 = pcVar9 + 1;
  } while (cVar1 != '\0');
  ExceptionList = &pvStack_10;
  FUN_005542c0(&uStack_14,(int)pcVar9 - ((int)&uStack_14 + 1));
  ppuStack_180 = &PTR_018be314;
  uStack_8 = 1;
  iStack_34 = 1;
  ppuStack_130 = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_134 = 0x48;
  FUN_00554f20(auStack_17c,0);
  uStack_8 = 3;
  *(undefined ***)(auStack_17c + (int)(ppuStack_180[1] + -4)) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(auStack_17c + (int)(ppuStack_180[1] + -8)) = ppuStack_180[1] + -0x50;
  FUN_005657a0(&uStack_2c,2);
  uStack_8._0_1_ = 5;
  if (0xf < uStack_18) {
    uVar10 = uStack_18 + 1;
    uVar8 = uStack_2c;
    if (0xfff < uVar10) {
      uVar8 = *(uint *)(uStack_2c - 4);
      uVar10 = uStack_18 + 0x24;
      if (0x1f < (uStack_2c - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar10);
  }
  pcVar9 = param_1;
  if (0xf < *(uint *)(param_1 + 0x14)) {
    pcVar9 = *(char **)param_1;
  }
  pcVar11 = pcVar9 + *(int *)(param_1 + 0x10);
  uStack_78 = 0;
  uStack_74 = 0xf;
  uStack_88 = uStack_88 & 0xffffff00;
  iStack_60 = 0;
  uStack_5c = 0xf;
  uStack_70 = uStack_70 & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  pcStack_40 = pcVar11;
  iVar3 = FUN_0171dafd((int)*pcVar9);
  while (iVar3 != 0) {
    cVar1 = *pcVar9;
    pcVar9 = pcVar9 + 1;
    FUN_005ed940(&ppuStack_180,cVar1);
    iVar3 = FUN_0171dafd();
  }
  FUN_0058c420(&uStack_58);
  FUN_005507b0();
  pcVar7 = (char *)&uStack_14;
  iStack_1c = 0;
  uStack_18 = 0xf;
  uStack_88 = uStack_58;
  uStack_84 = uStack_54;
  uStack_80 = uStack_50;
  uStack_7c = uStack_4c;
  uStack_2c = uStack_2c & 0xffffff00;
  uStack_78 = uStack_48;
  uStack_74 = uStack_44;
  do {
    cVar1 = *pcVar7;
    pcVar7 = pcVar7 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(&uStack_14,(int)pcVar7 - ((int)&uStack_14 + 1));
  uStack_8._0_1_ = 8;
  FUN_00577980();
  FUN_00576f70();
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (0xf < uStack_18) {
    uVar10 = uStack_18 + 1;
    uVar8 = uStack_2c;
    if (0xfff < uVar10) {
      uVar8 = *(uint *)(uStack_2c - 4);
      uVar10 = uStack_18 + 0x24;
      if (0x1f < (uStack_2c - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar10);
  }
  if (pcVar9 == pcVar11) goto LAB_00b40acb;
  do {
    iVar3 = FUN_0171dafd((int)*pcVar9);
    if (iVar3 != 0) break;
    cVar1 = *pcVar9;
    pcVar9 = pcVar9 + 1;
    FUN_005ed940(&ppuStack_180,cVar1);
  } while (pcVar9 != pcVar11);
  FUN_0058c420(&uStack_58);
  uStack_8._0_1_ = 9;
  puVar4 = (undefined4 *)FUN_009d6260(&iStack_1c,&uStack_58);
  uStack_8._0_1_ = 7;
  *(undefined4 *)(iStack_30 + 0x68) = *puVar4;
  *(undefined4 *)(iStack_30 + 0x6c) = puVar4[1];
  if (0xf < uStack_44) {
    uVar10 = uStack_44 + 1;
    uVar8 = uStack_58;
    if (0xfff < uVar10) {
      uVar8 = *(uint *)(uStack_58 - 4);
      uVar10 = uStack_44 + 0x24;
      if (0x1f < (uStack_58 - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar10);
  }
  pcVar11 = (char *)&uStack_14;
  iStack_1c = 0;
  uStack_18 = 0xf;
  uStack_2c = uStack_2c & 0xffffff00;
  do {
    cVar1 = *pcVar11;
    pcVar11 = pcVar11 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(&uStack_14,(int)pcVar11 - ((int)&uStack_14 + 1));
  uStack_8._0_1_ = 10;
  FUN_00577980();
  FUN_00576f70();
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  if (0xf < uStack_18) {
    uVar10 = uStack_18 + 1;
    uVar8 = uStack_2c;
    if (0xfff < uVar10) {
      uVar8 = *(uint *)(uStack_2c - 4);
      uVar10 = uStack_18 + 0x24;
      if (0x1f < (uStack_2c - uVar8) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar8,uVar10);
  }
  uStack_3c = 0;
  iStack_34 = 0;
  iStack_38 = 0;
  uVar13 = FUN_016f39b0(0xa8c0,1000000,0);
  iStack_1c = -(int)uVar13;
  uStack_18 = (-(int)((ulonglong)uVar13 >> 0x20) - iStack_38) - (uint)((int)uVar13 != 0);
  iVar12 = iStack_30 + 0x68;
  iVar3 = FUN_00874e00(&iStack_1c);
  if (iVar3 != -1) {
    uVar13 = FUN_016f39b0(uStack_3c + 0xc4e0,iStack_34 + (uint)(0xffff3b1f < uStack_3c),1000000,0);
    iStack_1c = (int)uVar13;
    uStack_18 = (int)((ulonglong)uVar13 >> 0x20) + iStack_38;
    iVar3 = FUN_00874e00(iVar12);
    pcVar11 = pcStack_40;
    if (iVar3 != -1) {
      if (pcVar9 == pcStack_40) {
LAB_00b40acb:
        FUN_0054ef60(&uStack_88);
        uStack_8._0_1_ = 0x12;
        FUN_0054ef60(&uStack_88);
        uStack_8._0_1_ = 0x13;
        FUN_0054ef60(&uStack_70);
        uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
        FUN_0054ef60(&uStack_70);
        if ((uint *)(iStack_30 + 4) != &uStack_e8) {
          FUN_005507b0();
          uVar8 = uStack_e8;
          uStack_e8 = uStack_e8 & 0xffffff00;
          *(uint *)(iStack_30 + 4) = uVar8;
          *(undefined4 *)(iStack_30 + 8) = uStack_e4;
          *(undefined4 *)(iStack_30 + 0xc) = uStack_e0;
          *(undefined4 *)(iStack_30 + 0x10) = uStack_dc;
          *(ulonglong *)(iStack_30 + 0x14) = CONCAT44(uStack_d4,uStack_d8);
          uStack_d8 = 0;
          uStack_d4 = 0xf;
        }
        if ((uint *)(iStack_30 + 0x1c) != &uStack_d0) {
          FUN_005507b0();
          uVar8 = uStack_d0;
          uStack_d0 = uStack_d0 & 0xffffff00;
          *(uint *)(iStack_30 + 0x1c) = uVar8;
          *(undefined4 *)(iStack_30 + 0x20) = uStack_cc;
          *(undefined4 *)(iStack_30 + 0x24) = uStack_c8;
          *(undefined4 *)(iStack_30 + 0x28) = uStack_c4;
          *(ulonglong *)(iStack_30 + 0x2c) = CONCAT44(uStack_bc,uStack_c0);
          uStack_c0 = 0;
          uStack_bc = 0xf;
        }
        if ((uint *)(iStack_30 + 0x34) != &uStack_b8) {
          FUN_005507b0();
          uVar8 = uStack_b8;
          uStack_b8 = uStack_b8 & 0xffffff00;
          *(uint *)(iStack_30 + 0x34) = uVar8;
          *(undefined4 *)(iStack_30 + 0x38) = uStack_b4;
          *(undefined4 *)(iStack_30 + 0x3c) = uStack_b0;
          *(undefined4 *)(iStack_30 + 0x40) = uStack_ac;
          *(ulonglong *)(iStack_30 + 0x44) = CONCAT44(uStack_a4,uStack_a8);
          uStack_a8 = 0;
          uStack_a4 = 0xf;
        }
        if ((uint *)(iStack_30 + 0x4c) != &uStack_a0) {
          FUN_005507b0();
          uVar8 = uStack_a0;
          uStack_a0 = uStack_a0 & 0xffffff00;
          *(uint *)(iStack_30 + 0x4c) = uVar8;
          *(undefined4 *)(iStack_30 + 0x50) = uStack_9c;
          *(undefined4 *)(iStack_30 + 0x54) = uStack_98;
          *(undefined4 *)(iStack_30 + 0x58) = uStack_94;
          *(ulonglong *)(iStack_30 + 0x5c) = CONCAT44(uStack_8c,uStack_90);
          uStack_90 = 0;
          uStack_8c = 0xf;
        }
        FUN_006375f0();
        FUN_005507b0();
        FUN_005507b0();
        FUN_00570540();
        ExceptionList = pvStack_10;
        return;
      }
      *(undefined *)(iStack_30 + 100) = 1;
      do {
        iVar3 = FUN_0171dafd((int)*pcVar9);
        if (iVar3 == 0) break;
        cVar1 = *pcVar9;
        pcVar9 = pcVar9 + 1;
        FUN_005ed940(&ppuStack_180,cVar1);
      } while (pcVar9 != pcVar11);
      FUN_0058c420(&uStack_2c);
      FUN_005507b0();
      uStack_70 = uStack_2c;
      uStack_2c = uStack_2c & 0xffffff00;
      uStack_6c = uStack_28;
      uStack_68 = uStack_24;
      uStack_64 = uStack_20;
      iStack_60 = iStack_1c;
      uStack_5c = uStack_18;
      iStack_1c = 0;
      uStack_18 = 0xf;
      FUN_005507b0();
      pcVar7 = (char *)&uStack_14;
      iStack_1c = 0;
      uStack_18 = 0xf;
      uStack_2c = uStack_2c & 0xffffff00;
      do {
        cVar1 = *pcVar7;
        pcVar7 = pcVar7 + 1;
      } while (cVar1 != '\0');
      FUN_005542c0(&uStack_14,(int)pcVar7 - ((int)&uStack_14 + 1));
      uStack_8._0_1_ = 0xd;
      FUN_00577980();
      FUN_00576f70();
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
      FUN_005507b0();
      uVar8 = uStack_3c;
      if (pcVar9 == pcVar11) {
        uVar13 = FUN_016f39b0(uStack_3c + 0xe10,iStack_34 + (uint)(0xfffff1ef < uStack_3c),1000000,0
                             );
        puVar4 = (undefined4 *)(iStack_30 + 0x70);
        *puVar4 = (int)uVar13;
        *(int *)(iStack_30 + 0x74) = (int)((ulonglong)uVar13 >> 0x20) + iStack_38;
      }
      else {
        do {
          iVar3 = FUN_0171dafd((int)*pcVar9);
          if (iVar3 != 0) break;
          cVar1 = *pcVar9;
          pcVar9 = pcVar9 + 1;
          FUN_005ed940(&ppuStack_180,cVar1);
        } while (pcVar9 != pcVar11);
        FUN_0058c420(&uStack_58);
        uStack_8._0_1_ = 0xe;
        puVar5 = (undefined4 *)FUN_009d6260(&iStack_1c,&uStack_58);
        puVar4 = (undefined4 *)(iStack_30 + 0x70);
        uStack_8._0_1_ = 7;
        *puVar4 = *puVar5;
        *(undefined4 *)(iStack_30 + 0x74) = puVar5[1];
        FUN_005507b0();
        pcVar9 = (char *)&uStack_14;
        iStack_1c = 0;
        uStack_18 = 0xf;
        uStack_2c = uStack_2c & 0xffffff00;
        do {
          cVar1 = *pcVar9;
          pcVar9 = pcVar9 + 1;
        } while (cVar1 != '\0');
        FUN_005542c0(&uStack_14,(int)pcVar9 - ((int)&uStack_14 + 1));
        uStack_8._0_1_ = 0xf;
        FUN_00577980();
        FUN_00576f70();
        uStack_8 = CONCAT31(uStack_8._1_3_,7);
        FUN_005507b0();
        uVar8 = uStack_3c;
      }
      FUN_005ef640(0xffffffe8,0,0,0,0);
      iVar3 = FUN_00874e00(puVar4);
      if (iVar3 == -1) {
        uVar13 = FUN_016f39b0(uVar8 + 0x15180,iStack_34 + (uint)(0xfffeae7f < uVar8),1000000,0);
        iStack_1c = (int)uVar13;
        uStack_18 = (int)((ulonglong)uVar13 >> 0x20) + iStack_38;
        iVar3 = FUN_00874e00(&iStack_1c);
        if (iVar3 == -1) goto LAB_00b40acb;
      }
      FUN_005ef620();
      uVar6 = FUN_0087c420();
      uStack_8._0_1_ = 0x10;
      uVar6 = FUN_00b3c990(uVar6);
      uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
      FUN_00b38e40(uVar6);
    }
  }
  FUN_005ef620();
  uVar6 = FUN_0087c420();
  uStack_8._0_1_ = 0xb;
  uVar6 = FUN_00b3cbd0(uVar6);
  uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
  FUN_00b38ee0(uVar6);
  pcVar2 = (code *)swi(3);
  (*pcVar2)();
  return;
}



/* FUNCTION 24017 ; VA 0x00b40ce0 ; FUN_00b40ce0 */

undefined4
FUN_00b40ce0(undefined4 param_1,undefined4 param_2,undefined4 param_3,int *param_4,int *param_5)

{
  int *piVar1;
  code *pcVar2;
  bool bVar3;
  int *piVar4;
  char cVar5;
  undefined4 *puVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  undefined4 uVar13;
  undefined8 uVar14;
  undefined auStack_68 [8];
  undefined auStack_60 [8];
  undefined auStack_58 [8];
  undefined auStack_50 [8];
  undefined auStack_48 [8];
  undefined auStack_40 [8];
  undefined auStack_38 [8];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined auStack_28 [4];
  undefined4 auStack_24 [2];
  undefined4 uStack_1c;
  undefined4 *puStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f2a91;
  pvStack_10 = ExceptionList;
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_8 = 1;
  puStack_14 = (undefined4 *)0x1;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    cVar5 = (**(code **)(*param_4 + 0x14))();
    if (cVar5 != '\0') {
      bVar3 = true;
      goto LAB_00b40d3d;
    }
  }
  bVar3 = false;
LAB_00b40d3d:
  uStack_8 = 0;
  if (bVar3) {
    puStack_14 = (undefined4 *)(**(code **)(*param_4 + 0x24))(auStack_38);
    pcVar2 = *(code **)(*param_4 + 0x1c);
    FUN_00b43600(auStack_24,param_1);
    (*pcVar2)(auStack_40,auStack_24[0]);
    puStack_18 = (undefined4 *)FUN_00b4a230(auStack_48);
    pcVar2 = *(code **)(*param_4 + 0x1c);
    FUN_00b43600(auStack_24,param_1);
    (*pcVar2)(auStack_50,auStack_24[0]);
    uStack_1c = FUN_00b41a70(auStack_28);
    pcVar2 = *(code **)(*param_4 + 0x18);
    FUN_00b43600(auStack_24,param_1);
    (*pcVar2)(auStack_58,auStack_24[0]);
    puVar6 = (undefined4 *)FUN_00b4a230(auStack_60);
    pcVar2 = *(code **)(*param_4 + 0x18);
    FUN_00b43600(auStack_24,param_1);
    (*pcVar2)(auStack_68,auStack_24[0]);
    auStack_24[0] = FUN_00b41a70(&uStack_2c);
    uVar14 = FUN_016f3900(*puVar6,puVar6[1],60000000,0);
    iVar7 = FUN_016f4270(uVar14,0x3c,0);
    iVar8 = FUN_016f3900(*puVar6,puVar6[1],3600000000,0);
    puVar6 = puStack_18;
    uVar14 = FUN_016f3900(*puStack_18,puStack_18[1],60000000,0);
    iVar9 = FUN_016f4270(uVar14,0x3c,0);
    iVar10 = FUN_016f3900(*puVar6,puVar6[1],3600000000,0);
    uVar14 = FUN_016f3900(*puStack_14,puStack_14[1],60000000,0);
    iVar11 = FUN_016f4270(uVar14,0x3c,0);
    iVar12 = FUN_016f3900(*puStack_14,puStack_14[1],3600000000,0);
    uVar13 = FUN_00b46c70(&param_1,&param_2,auStack_24[0],iVar7 + iVar8 * 0x3c,uStack_1c,
                          iVar9 + iVar10 * 0x3c,iVar11 + iVar12 * 0x3c);
  }
  else {
    uVar13 = 0;
  }
  piVar4 = param_5;
  uStack_8 = 3;
  if (param_5 != (int *)0x0) {
    LOCK();
    iVar7 = param_5[1] + -1;
    param_5[1] = iVar7;
    UNLOCK();
    if (iVar7 == 0) {
      (**(code **)(*param_5 + 4))();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar7 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar7 == 1) {
        (**(code **)(*piVar4 + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return uVar13;
}



/* FUNCTION 24018 ; VA 0x00b40f30 ; FUN_00b40f30 */

void __fastcall FUN_00b40f30(int param_1)

{
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  FUN_00a15350();
  if ((uint)(*(int *)(param_1 + 0x14) - *(int *)(param_1 + 0xc) >> 2) < 0x10) {
    FUN_005cb650(0x10);
  }
  iStack_14 = *(int *)(param_1 + 4);
  FUN_00a1ab20(0x10,&iStack_14);
  *(undefined4 *)(param_1 + 0x18) = 7;
  *(undefined4 *)(param_1 + 0x1c) = 8;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24019 ; VA 0x00b40fa1 ; FUN_00b40fa1 */

void FUN_00b40fa1(void)

{
  FUN_00b40fc0();
  return;
}



/* FUNCTION 24020 ; VA 0x00b40fc0 ; FUN_00b40fc0 */

int __fastcall FUN_00b40fc0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2adb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_01952784;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = boost::local_time::ambiguous_result::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::ambiguous_result>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::ambiguous_result>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::ambiguous_result>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 24021 ; VA 0x00b410d7 ; FUN_00b410d7 */

void FUN_00b410d7(void)

{
  FUN_00b410e0();
  return;
}



/* FUNCTION 24022 ; VA 0x00b410e0 ; FUN_00b410e0 */

int __fastcall FUN_00b410e0(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2b2b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_01952870;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = boost::local_time::bad_adjustment::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_adjustment>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_adjustment>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_adjustment>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 24023 ; VA 0x00b411f7 ; FUN_00b411f7 */

void FUN_00b411f7(void)

{
  FUN_00b41200();
  return;
}



/* FUNCTION 24024 ; VA 0x00b41200 ; FUN_00b41200 */

int __fastcall FUN_00b41200(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2b7b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_01951d88;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = boost::gregorian::bad_day_of_year::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_year>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_year>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_day_of_year>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 24025 ; VA 0x00b41317 ; FUN_00b41317 */

void FUN_00b41317(void)

{
  FUN_00b41320();
  return;
}



/* FUNCTION 24026 ; VA 0x00b41320 ; FUN_00b41320 */

int __fastcall FUN_00b41320(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2bcb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_01952830;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = boost::local_time::bad_offset::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_offset>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_offset>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::bad_offset>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 24027 ; VA 0x00b41437 ; FUN_00b41437 */

void FUN_00b41437(void)

{
  FUN_00b41440();
  return;
}



/* FUNCTION 24028 ; VA 0x00b41440 ; FUN_00b41440 */

int __fastcall FUN_00b41440(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2c1b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_01951dc8;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = boost::gregorian::bad_weekday::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_weekday>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_weekday>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::gregorian::bad_weekday>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 24029 ; VA 0x00b41557 ; FUN_00b41557 */

void FUN_00b41557(void)

{
  FUN_00b41560();
  return;
}



/* FUNCTION 24030 ; VA 0x00b41560 ; FUN_00b41560 */

int __fastcall FUN_00b41560(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2c6b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_019527c4;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = boost::local_time::time_label_invalid::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::time_label_invalid>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::time_label_invalid>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<struct_boost::local_time::time_label_invalid>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 24031 ; VA 0x00b41677 ; FUN_00b41677 */

void FUN_00b41677(void)

{
  FUN_00b41680();
  return;
}



/* FUNCTION 24032 ; VA 0x00b41680 ; FUN_00b41680 */

int __fastcall FUN_00b41680(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2cbb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  puVar3 = (undefined4 *)FUN_01674e20(0x2c);
  uStack_8 = 0;
  if (puVar3 != (undefined4 *)0x0) {
    puVar3[8] = &DAT_019527f0;
    puVar3[10] = boost::exception_detail::clone_base::vftable;
    *puVar3 = std::exception::vftable;
    *(undefined8 *)(puVar3 + 1) = 0;
    FUN_0170c226(param_1 + -0x24,puVar3 + 1);
    *puVar3 = std::invalid_argument::vftable;
    puVar1 = puVar3 + 3;
    uStack_8 = 2;
    *puVar1 = boost::exception::vftable;
    piVar2 = *(int **)(param_1 + -0x18);
    puVar3[4] = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0xc))();
    }
    puVar3[5] = *(undefined4 *)(param_1 + -0x14);
    puVar3[6] = *(undefined4 *)(param_1 + -0x10);
    puVar3[7] = *(undefined4 *)(param_1 + -0xc);
    *puVar3 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_std::invalid_argument>_>
              ::vftable;
    *puVar1 = boost::exception_detail::
              clone_impl<struct_boost::exception_detail::error_info_injector<class_std::invalid_argument>_>
              ::vftable;
    uStack_8 = 3;
    *(undefined ***)(*(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3) =
         boost::exception_detail::
         clone_impl<struct_boost::exception_detail::error_info_injector<class_std::invalid_argument>_>
         ::vftable;
    *(int *)(*(int *)(puVar3[8] + 4) + 0x1c + (int)puVar3) = *(int *)(puVar3[8] + 4) + -8;
    FUN_00554960(puVar1,param_1 + -0x1c);
    ExceptionList = pvStack_10;
    return *(int *)(puVar3[8] + 4) + 0x20 + (int)puVar3;
  }
  ExceptionList = pvStack_10;
  return 0;
}



/* FUNCTION 24033 ; VA 0x00b417a0 ; FUN_00b417a0 */

undefined4 *
FUN_00b417a0(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4,int *param_5,
            char param_6)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  undefined auStack_38 [8];
  undefined auStack_30 [8];
  undefined auStack_28 [8];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f2cd8;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  if (param_4 != (int *)0x0) {
    ExceptionList = &pvStack_10;
    if ((param_6 != '\0') &&
       (ExceptionList = &pvStack_10, cVar3 = (**(code **)(*param_4 + 0x14))(), cVar3 != '\0')) {
      uVar4 = (**(code **)(*param_4 + 0x24))(&uStack_20);
      FUN_00b3e2e0(&uStack_18,uVar4);
    }
    uVar4 = (**(code **)(*param_4 + 0x20))(auStack_28);
    FUN_00b4a230(auStack_30);
    puVar5 = (undefined4 *)FUN_00602640(auStack_38,uVar4);
    uStack_18 = *puVar5;
    uStack_14 = puVar5[1];
    uVar4 = FUN_00b41a70(&param_6);
    FUN_005672c0(uVar4,&uStack_18);
    param_2 = uStack_20;
    param_3 = uStack_1c;
  }
  *param_1 = param_2;
  param_1[1] = param_3;
  uStack_8 = 2;
  if (param_5 == (int *)0x0) {
    ExceptionList = pvStack_10;
    return param_1;
  }
  LOCK();
  iVar2 = param_5[1] + -1;
  param_5[1] = iVar2;
  UNLOCK();
  if (iVar2 == 0) {
    (**(code **)(*param_5 + 4))();
    LOCK();
    piVar1 = param_5 + 2;
    iVar2 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar2 == 1) {
      (**(code **)(*param_5 + 8))();
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24034 ; VA 0x00b418c0 ; FUN_00b418c0 */

undefined4 FUN_00b418c0(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  undefined8 uStack_20;
  int iStack_18;
  int iStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  uStack_10 = 0xfffffffe;
  uStack_c = 0x7fffffff;
  uVar1 = FUN_0056a9c0(0);
  FUN_005672c0(uVar1,&uStack_10);
  if ((*param_2 == iStack_18) && (param_2[1] == iStack_14)) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Invalid Datetime.\n");
  }
  FUN_006d31a0(&iStack_18,&DAT_01eee630);
  uStack_20 = FUN_016f3900(iStack_18,iStack_14,1000,0);
  FUN_009ee550(param_1,&uStack_20);
  return param_1;
}



/* FUNCTION 24035 ; VA 0x00b41950 ; FUN_00b41950 */

undefined4 FUN_00b41950(undefined4 param_1,undefined4 *param_2)

{
  code *pcVar1;
  undefined4 *puVar2;
  ushort uVar3;
  undefined4 uVar4;
  uint uVar5;
  uint extraout_ECX;
  uint extraout_ECX_00;
  uint extraout_ECX_01;
  uint extraout_ECX_02;
  uint extraout_ECX_03;
  uint uVar6;
  uint uVar7;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  puVar2 = param_2;
  uVar5 = (uint)*(ushort *)(param_2 + 3);
  uVar7 = 1;
  if (uVar5 + 1 < 2) {
    FUN_00588600(1,uVar5,0,1);
    uVar5 = extraout_ECX;
LAB_00b41a28:
    uVar6 = 1;
    FUN_00588600(1,uVar5,1,uVar7);
    uVar5 = extraout_ECX_00;
LAB_00b41a32:
    FUN_00588640(1,uVar5,0,uVar6,uVar7);
    uVar5 = extraout_ECX_01;
LAB_00b41a3c:
    uVar4 = 1;
    FUN_00588640(1,uVar5,1,uVar6,uVar7);
    uVar5 = extraout_ECX_02;
  }
  else {
    if (0x1f < uVar5) goto LAB_00b41a28;
    uVar7 = (uint)*(ushort *)(param_2 + 3);
    uVar5 = (uint)(ushort)(*(short *)(param_2 + 4) + 1U);
    uVar6 = 1;
    if (uVar5 + 1 < 2) goto LAB_00b41a32;
    if (0xc < uVar5) goto LAB_00b41a3c;
    uVar6 = (uint)(ushort)(*(short *)(param_2 + 4) + 1U);
    uVar3 = *(short *)(param_2 + 5) + 0x76c;
    uVar5 = (uint)uVar3;
    uVar4 = 0x578;
    if (0x578 < uVar5 + 1) {
      if (uVar3 < 0x2711) {
        FUN_0056a920(uVar3,uVar6,uVar7);
        FUN_005ef640(puVar2[2],puVar2[1],*puVar2,0,0);
        uStack_14 = uStack_c;
        uStack_10 = uStack_8;
        FUN_005672c0(&param_2,&uStack_14);
        return param_1;
      }
      goto LAB_00b41a53;
    }
  }
  FUN_00588680(0x578,uVar5,0,uVar4,uVar6);
  uVar5 = extraout_ECX_03;
LAB_00b41a53:
  FUN_00588680(0x578,uVar5,1,uVar4,uVar6);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 24036 ; VA 0x00b41a70 ; FUN_00b41a70 */

undefined4 * __thiscall FUN_00b41a70(int *param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_c [8];
  
  iVar1 = *param_1;
  iVar2 = param_1[1];
  if ((((iVar1 != 0) || (iVar2 != -0x80000000)) && ((iVar1 != -1 || (iVar2 != 0x7fffffff)))) &&
     ((iVar1 != -2 || (iVar2 != 0x7fffffff)))) {
    uVar3 = FUN_016f3900(iVar1,iVar2,0x1dd76000,0x14);
    FUN_00b43600(auStack_c,uVar3);
    uVar3 = FUN_0057d1d0(auStack_c);
    *param_2 = uVar3;
    return param_2;
  }
  if ((iVar1 == -2) && (iVar2 == 0x7fffffff)) {
    FUN_0056a9c0(0);
    return param_2;
  }
  if ((iVar1 == 0) && (iVar2 == -0x80000000)) {
    FUN_0056a9c0(1);
    return param_2;
  }
  if ((iVar1 != -1) || (uVar3 = 2, iVar2 != 0x7fffffff)) {
    uVar3 = 5;
  }
  FUN_0056a9c0(uVar3);
  return param_2;
}



/* FUNCTION 24037 ; VA 0x00b41b40 ; FUN_00b41b40 */

undefined2 * __thiscall FUN_00b41b40(undefined4 *param_1,undefined2 *param_2)

{
  code *pcVar1;
  undefined2 *puVar2;
  uint uVar3;
  uint extraout_ECX;
  uint uVar4;
  undefined2 uStack_c;
  ushort uStack_a;
  ushort uStack_8;
  
  FUN_00b43600(&uStack_c,*param_1);
  uVar3 = (int)(0xe - (uint)uStack_a) / 0xc & 0xffff;
  uVar4 = CONCAT22(uStack_a,uStack_c) - uVar3 & 0xffff;
  uVar4 = (int)((uint)uStack_8 +
               (uVar4 >> 2) + uVar4 +
               (((uVar3 * 0xc + -2 + CONCAT22(uStack_8,uStack_a) & 0xffff) * 0x1f) / 0xc -
               uVar4 / 100) + uVar4 / 400) % 7;
  uVar3 = uVar4 & 0xffff;
  *param_2 = 0;
  if (uVar3 == 0xffffffff) {
    FUN_00b47210(0,0xffffffff,0);
    uVar3 = extraout_ECX;
  }
  else if (uVar3 < 7) {
    *param_2 = (short)uVar4;
    return param_2;
  }
  FUN_00b47210(0,uVar3,1);
  pcVar1 = (code *)swi(3);
  puVar2 = (undefined2 *)(*pcVar1)();
  return puVar2;
}



/* FUNCTION 24038 ; VA 0x00b41c10 ; FUN_00b41c10 */

ushort * __thiscall FUN_00b41c10(undefined4 *param_1,ushort *param_2)

{
  code *pcVar1;
  ushort uVar2;
  short *psVar3;
  ushort *puVar4;
  undefined2 extraout_var;
  uint uVar5;
  uint extraout_ECX;
  undefined4 auStack_10 [2];
  undefined auStack_8 [4];
  
  FUN_00b43600(auStack_10,*param_1);
  FUN_0056a920(auStack_10[0],CONCAT22(extraout_var,1),1);
  psVar3 = (short *)FUN_00b3df00(auStack_10,auStack_8);
  uVar2 = *psVar3 + 1;
  *param_2 = 1;
  uVar5 = (uint)uVar2;
  if (uVar5 + 1 < 2) {
    FUN_00b471d0(1,uVar5,0);
    uVar5 = extraout_ECX;
  }
  else if (uVar2 < 0x16f) {
    *param_2 = uVar2;
    return param_2;
  }
  FUN_00b471d0(1,uVar5,1);
  pcVar1 = (code *)swi(3);
  puVar4 = (ushort *)(*pcVar1)();
  return puVar4;
}



/* FUNCTION 24039 ; VA 0x00b41ca0 ; FUN_00b41ca0 */

undefined4 * __thiscall
FUN_00b41ca0(int param_1,undefined4 *param_2,undefined4 param_3,int *param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,undefined param_8,char param_9)

{
  uint uVar1;
  byte bVar2;
  byte *pbVar3;
  uint uVar4;
  undefined4 ***pppuVar5;
  undefined4 ****ppppuVar6;
  int iVar7;
  uint uVar8;
  byte *pbVar9;
  int iVar10;
  uint uVar11;
  undefined4 ****ppppuVar12;
  int iVar13;
  undefined4 ***apppuStack_40 [4];
  int iStack_30;
  uint uStack_2c;
  undefined2 uStack_28;
  char cStack_26;
  undefined uStack_25;
  undefined uStack_24;
  undefined4 uStack_20;
  int iStack_1c;
  uint uStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794d38;
  pvStack_10 = ExceptionList;
  uStack_24 = DAT_01952404;
  iStack_14 = 0;
  uStack_18 = 0xf;
  apppuStack_40[0] = (undefined4 ***)((uint)apppuStack_40[0] & 0xffffff00);
  uStack_8 = 0;
  uStack_28 = (undefined2)DAT_01952400;
  if (param_9 == '\0') {
    uStack_25 = (undefined)((uint)DAT_01952400 >> 0x18);
    _uStack_28 = CONCAT12(param_8,uStack_28);
  }
  else {
    _uStack_28 = CONCAT12(param_9,uStack_28);
    _uStack_28 = CONCAT13(param_8,_uStack_28);
  }
  uVar8 = 0x10;
  ExceptionList = &pvStack_10;
  iStack_1c = param_1;
  while( true ) {
    uStack_2c = uStack_18;
    if (uStack_18 - iStack_14 < uVar8) {
      iStack_30 = iStack_14;
      if (0x7fffffffU - iStack_14 < uVar8) {
        FUN_00554040();
        goto LAB_00b41f7c;
      }
      uVar11 = iStack_14 + uVar8 | 0xf;
      if (uVar11 < 0x80000000) {
        if (0x7fffffff - (uStack_18 >> 1) < uStack_18) {
          uVar11 = 0x7fffffff;
        }
        else {
          uVar1 = uStack_18 + (uStack_18 >> 1);
          if (uVar11 < uVar1) {
            uVar11 = uVar1;
          }
        }
      }
      else {
        uVar11 = 0x7fffffff;
      }
      uVar1 = uVar11 + 1;
      if (uVar1 < 0x1000) {
        if (uVar1 == 0) {
          ppppuVar12 = (undefined4 ****)0x0;
        }
        else {
          ppppuVar12 = (undefined4 ****)FUN_01674e20(uVar1);
        }
      }
      else {
        uVar4 = uVar11 + 0x24;
        if (uVar4 <= uVar1) {
          uVar4 = 0xffffffff;
        }
        pppuVar5 = (undefined4 ***)FUN_01674e20(uVar4);
        if (pppuVar5 == (undefined4 ***)0x0) goto LAB_00b41f7c;
        ppppuVar12 = (undefined4 ****)((int)pppuVar5 + 0x23U & 0xffffffe0);
        ppppuVar12[-1] = pppuVar5;
      }
      pppuVar5 = apppuStack_40[0];
      iStack_30 = iStack_14 + uVar8;
      uStack_2c = uVar11;
      if (uStack_18 < 0x10) {
        FUN_0170c6f0(ppppuVar12,apppuStack_40,iStack_14);
        iVar10 = iStack_14 + (int)ppppuVar12;
        FUN_0170d1f0(iVar10,0,uVar8);
        *(undefined *)(iVar10 + uVar8) = 0;
        apppuStack_40[0] = ppppuVar12;
      }
      else {
        FUN_0170c6f0(ppppuVar12,apppuStack_40[0],iStack_14);
        iVar10 = iStack_14 + (int)ppppuVar12;
        FUN_0170d1f0(iVar10,0,uVar8);
        uVar11 = uStack_18 + 1;
        *(undefined *)(iVar10 + uVar8) = 0;
        ppppuVar6 = (undefined4 ****)pppuVar5;
        if (0xfff < uVar11) {
          ppppuVar6 = (undefined4 ****)pppuVar5[-1];
          uVar11 = uStack_18 + 0x24;
          if (0x1f < (uint)((int)pppuVar5 + (-4 - (int)ppppuVar6))) goto LAB_00b41f7c;
        }
        FUN_01674ea0(ppppuVar6,uVar11);
        apppuStack_40[0] = ppppuVar12;
      }
    }
    else {
      ppppuVar12 = apppuStack_40;
      if (0xf < uStack_18) {
        ppppuVar12 = (undefined4 ****)apppuStack_40[0];
      }
      iStack_30 = uVar8 + iStack_14;
      iVar10 = (int)ppppuVar12 + iStack_14;
      FUN_0170d1f0(iVar10,0,uVar8);
      *(undefined *)(uVar8 + iVar10) = 0;
    }
    ppppuVar12 = apppuStack_40;
    if (0xf < uStack_2c) {
      ppppuVar12 = (undefined4 ****)apppuStack_40[0];
    }
    iVar10 = FUN_01724ddc(ppppuVar12,iStack_30,&uStack_28,param_7,*(undefined4 *)(iStack_1c + 8));
    if (iVar10 != 0) break;
    uStack_18 = uStack_2c;
    uVar8 = uVar8 * 2;
    iStack_14 = iStack_30;
  }
  ppppuVar12 = apppuStack_40;
  if (0xf < uStack_2c) {
    ppppuVar12 = (undefined4 ****)apppuStack_40[0];
  }
  uStack_20 = param_3;
  ppppuVar6 = apppuStack_40;
  if (0xf < uStack_2c) {
    ppppuVar6 = (undefined4 ****)apppuStack_40[0];
  }
  iVar13 = 0;
  pbVar9 = (byte *)((int)ppppuVar6 + 1);
  iVar7 = (iVar10 + (int)ppppuVar12) - (int)pbVar9;
  if ((byte *)(iVar10 + (int)ppppuVar12) < pbVar9) {
    iVar7 = 0;
  }
  if (iVar7 != 0) {
    do {
      if (param_4 == (int *)0x0) {
LAB_00b41f16:
        uStack_20 = CONCAT31(uStack_20._1_3_,1);
      }
      else {
        bVar2 = *pbVar9;
        if (*(int *)param_4[8] == 0) {
LAB_00b41f01:
          uVar8 = (**(code **)(*param_4 + 0xc))(bVar2);
        }
        else {
          iVar10 = *(int *)param_4[0xc];
          if (iVar10 < 1) goto LAB_00b41f01;
          *(int *)param_4[0xc] = iVar10 + -1;
          pbVar3 = *(byte **)param_4[8];
          *(byte **)param_4[8] = pbVar3 + 1;
          *pbVar3 = bVar2;
          uVar8 = (uint)bVar2;
        }
        if (uVar8 == 0xffffffff) goto LAB_00b41f16;
      }
      iVar13 = iVar13 + 1;
      pbVar9 = pbVar9 + 1;
    } while (iVar13 != iVar7);
  }
  *param_2 = uStack_20;
  param_2[1] = param_4;
  if (0xf < uStack_2c) {
    uVar8 = uStack_2c + 1;
    ppppuVar12 = (undefined4 ****)apppuStack_40[0];
    if (0xfff < uVar8) {
      ppppuVar12 = (undefined4 ****)apppuStack_40[0][-1];
      uVar8 = uStack_2c + 0x24;
      if (0x1f < (uint)((int)apppuStack_40[0] + (-4 - (int)ppppuVar12))) {
LAB_00b41f7c:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar12,uVar8);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24040 ; VA 0x00b41f90 ; FUN_00b41f90 */

void __thiscall
FUN_00b41f90(int param_1,undefined4 *param_2,undefined4 param_3,int *param_4,undefined4 param_5,
            undefined4 param_6,uint param_7)

{
  int *piVar1;
  undefined uVar2;
  uint uVar3;
  int iVar4;
  undefined *puVar5;
  int iVar6;
  undefined4 *puVar7;
  int iVar8;
  undefined4 *puVar9;
  
  iVar6 = *(int *)(param_1 + 0xc0);
  if (param_7 < (uint)((*(int *)(param_1 + 0xc4) - iVar6) / 0x18)) {
    uVar3 = *(uint *)(iVar6 + 0x14 + param_7 * 0x18);
    puVar9 = (undefined4 *)(iVar6 + param_7 * 0x18);
    puVar7 = puVar9;
    if (0xf < uVar3) {
      puVar7 = (undefined4 *)*puVar9;
    }
    piVar1 = puVar9 + 4;
    if (0xf < uVar3) {
      puVar9 = (undefined4 *)*puVar9;
    }
    iVar6 = ((int)puVar7 + *piVar1) - (int)puVar9;
    iVar8 = 0;
    if ((undefined4 *)((int)puVar7 + *piVar1) < puVar9) {
      iVar6 = 0;
    }
    if (iVar6 != 0) {
      do {
        if (param_4 != (int *)0x0) {
          uVar2 = *(undefined *)puVar9;
          if (*(int *)param_4[8] != 0) {
            iVar4 = *(int *)param_4[0xc];
            if (0 < iVar4) {
              *(int *)param_4[0xc] = iVar4 + -1;
              puVar5 = *(undefined **)param_4[8];
              *(undefined **)param_4[8] = puVar5 + 1;
              *puVar5 = uVar2;
              goto LAB_00b42030;
            }
          }
          (**(code **)(*param_4 + 0xc))(uVar2);
        }
LAB_00b42030:
        iVar8 = iVar8 + 1;
        puVar9 = (undefined4 *)((int)puVar9 + 1);
      } while (iVar8 != iVar6);
    }
  }
  *param_2 = param_3;
  param_2[1] = param_4;
  return;
}



/* FUNCTION 24041 ; VA 0x00b42050 ; FUN_00b42050 */

undefined4 __thiscall
FUN_00b42050(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,int param_7,undefined4 *param_8)

{
  int *piVar1;
  int iVar2;
  char *pcVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int iVar6;
  int *piVar7;
  char *pcVar8;
  int iVar9;
  int *piVar10;
  uint uVar11;
  int in_stack_0000002c;
  uint in_stack_00000030;
  undefined4 uStack_1c;
  undefined auStack_18 [4];
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f2d00;
  pvStack_10 = ExceptionList;
  iVar2 = *(int *)(param_1 + 0xf0);
  iVar9 = *(int *)(param_1 + 0xf4) - iVar2;
  uStack_8 = 0;
  iVar6 = iVar9 >> 0x1f;
  ExceptionList = &pvStack_10;
  if (iVar9 / 0x18 + iVar6 != iVar6) {
    puVar4 = (undefined4 *)(iVar2 + *(int *)(param_7 + 0x18) * 0x18);
    puVar5 = puVar4;
    if (0xf < *(uint *)(iVar2 + 0x14 + *(int *)(param_7 + 0x18) * 0x18)) {
      puVar5 = (undefined4 *)*puVar4;
    }
    piStack_14 = (int *)(puVar4[4] + (int)puVar5);
    pcVar3 = "%A";
    do {
      pcVar8 = pcVar3;
      pcVar3 = pcVar8 + 1;
    } while (*pcVar8 != '\0');
    ExceptionList = &pvStack_10;
    FUN_00635b90(&param_8,CONCAT44(pcVar8,&DAT_019522cc));
  }
  iVar6 = *(int *)(param_1 + 0xe8) - *(int *)(param_1 + 0xe4);
  iVar2 = iVar6 >> 0x1f;
  if (iVar6 / 0x18 + iVar2 != iVar2) {
    piVar10 = (int *)(*(int *)(param_1 + 0xe4) + *(int *)(param_7 + 0x18) * 0x18);
    piStack_14 = piVar10;
    if (0xf < (uint)piVar10[5]) {
      piStack_14 = (int *)*piVar10;
    }
    piStack_14 = (int *)(piVar10[4] + (int)piStack_14);
    if (0xf < (uint)piVar10[5]) {
      piVar10 = (int *)*piVar10;
    }
    pcVar3 = "%a";
    do {
      pcVar8 = pcVar3;
      pcVar3 = pcVar8 + 1;
    } while (*pcVar8 != '\0');
    FUN_00635b90(&param_8,CONCAT44(pcVar8,&DAT_019522d0),uStack_1c,piVar10,piStack_14);
  }
  iVar6 = *(int *)(param_1 + 0xdc) - *(int *)(param_1 + 0xd8);
  iVar2 = iVar6 >> 0x1f;
  if (iVar6 / 0x18 + iVar2 != iVar2) {
    piVar10 = (int *)(*(int *)(param_1 + 0xd8) + *(int *)(param_7 + 0x10) * 0x18);
    piStack_14 = piVar10;
    if (0xf < (uint)piVar10[5]) {
      piStack_14 = (int *)*piVar10;
    }
    piStack_14 = (int *)(piVar10[4] + (int)piStack_14);
    if (0xf < (uint)piVar10[5]) {
      piVar10 = (int *)*piVar10;
    }
    pcVar3 = "%B";
    do {
      pcVar8 = pcVar3;
      pcVar3 = pcVar8 + 1;
    } while (*pcVar8 != '\0');
    FUN_00635b90(&param_8,CONCAT44(pcVar8,&DAT_019522d4),uStack_1c,piVar10,piStack_14);
  }
  iVar2 = *(int *)(param_1 + 0xcc);
  iVar9 = *(int *)(param_1 + 0xd0) - iVar2;
  iVar6 = iVar9 >> 0x1f;
  if (iVar9 / 0x18 + iVar6 != iVar6) {
    uVar11 = *(uint *)(iVar2 + 0x14 + *(int *)(param_7 + 0x10) * 0x18);
    piVar10 = (int *)(iVar2 + *(int *)(param_7 + 0x10) * 0x18);
    piVar7 = piVar10;
    if (0xf < uVar11) {
      piVar7 = (int *)*piVar10;
    }
    piVar1 = piVar10 + 4;
    if (0xf < uVar11) {
      piVar10 = (int *)*piVar10;
    }
    pcVar3 = "%b";
    do {
      pcVar8 = pcVar3;
      pcVar3 = pcVar8 + 1;
    } while (*pcVar8 != '\0');
    FUN_00635b90(&param_8,CONCAT44(pcVar8,&DAT_019522d8),uStack_1c,piVar10,*piVar1 + (int)piVar7);
  }
  puVar4 = &param_8;
  if (0xf < in_stack_00000030) {
    puVar4 = param_8;
  }
  piVar10 = *(int **)(*(int *)(param_5 + 0x30) + 4);
  uStack_8._0_1_ = 1;
  piStack_14 = piVar10;
  (**(code **)(*piVar10 + 4))();
  uStack_8._0_1_ = 2;
  FUN_00b39180(auStack_18);
  FUN_00b499b0(param_2,param_3,param_4,param_5,param_6,param_7,puVar4,
               in_stack_0000002c + (int)puVar4);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  if ((piVar10 != (int *)0x0) &&
     (puVar4 = (undefined4 *)(**(code **)(*piVar10 + 8))(), puVar4 != (undefined4 *)0x0)) {
    (**(code **)*puVar4)(1);
  }
  if (0xf < in_stack_00000030) {
    uVar11 = in_stack_00000030 + 1;
    puVar4 = param_8;
    if (0xfff < uVar11) {
      puVar4 = (undefined4 *)param_8[-1];
      uVar11 = in_stack_00000030 + 0x24;
      if (0x1f < (uint)((int)param_8 + (-4 - (int)puVar4))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(puVar4,uVar11);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24042 ; VA 0x00b42370 ; FUN_00b42370 */

undefined4 __thiscall FUN_00b42370(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  FUN_0056a9c0(0);
  if (*(char *)(param_1 + 100) != '\0') {
    puVar1 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x88) + 0xc))(&uStack_8,param_3);
    uStack_8 = *puVar1;
  }
  uStack_10 = *(undefined4 *)(param_1 + 0x80);
  uStack_c = *(undefined4 *)(param_1 + 0x84);
  FUN_005672c0(&uStack_8,&uStack_10);
  return param_2;
}



/* FUNCTION 24043 ; VA 0x00b423e0 ; FUN_00b423e0 */

undefined4 __thiscall FUN_00b423e0(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  FUN_0056a9c0(0);
  if (*(char *)(param_1 + 100) != '\0') {
    puVar1 = (undefined4 *)(**(code **)(**(int **)(param_1 + 0x88) + 4))(&uStack_8,param_3);
    uStack_8 = *puVar1;
  }
  uStack_10 = *(undefined4 *)(param_1 + 0x78);
  uStack_c = *(undefined4 *)(param_1 + 0x7c);
  FUN_005672c0(&uStack_8,&uStack_10);
  return param_2;
}



/* FUNCTION 24044 ; VA 0x00b42440 ; FUN_00b42440 */

void __thiscall FUN_00b42440(int param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x74);
  *param_2 = *(undefined4 *)(param_1 + 0x70);
  param_2[1] = uVar1;
  return;
}



/* FUNCTION 24045 ; VA 0x00b42460 ; FUN_00b42460 */

undefined4 __thiscall FUN_00b42460(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x4c);
  return param_2;
}



/* FUNCTION 24046 ; VA 0x00b42480 ; FUN_00b42480 */

undefined4 __thiscall FUN_00b42480(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x34);
  return param_2;
}



/* FUNCTION 24047 ; VA 0x00b424a0 ; FUN_00b424a0 */

void __thiscall
FUN_00b424a0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int iStack_28;
  undefined4 uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f2d18;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  iStack_18 = 0;
  iStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00559960(0,param_2);
  iVar3 = iStack_14;
  iVar1 = iStack_18;
  if (iStack_14 == iStack_18) {
    FUN_00559960(iStack_18,param_3);
    iVar3 = iStack_14;
  }
  else {
    FUN_0054ef60(param_3);
    iStack_18 = iVar1 + 0x18;
  }
  iVar1 = iStack_18;
  if (iVar3 == iStack_18) {
    FUN_00559960(iStack_18,param_4);
    iVar3 = iStack_14;
  }
  else {
    FUN_0054ef60(param_4);
    iStack_18 = iVar1 + 0x18;
  }
  iVar1 = iStack_18;
  if (iVar3 == iStack_18) {
    FUN_00559960(iStack_18,param_5);
    iVar3 = iStack_14;
  }
  else {
    FUN_0054ef60(param_5);
    iStack_18 = iVar1 + 0x18;
  }
  iVar1 = iStack_18;
  if (iVar3 == iStack_18) {
    FUN_00559960(iStack_18,param_6);
    iVar3 = iStack_14;
  }
  else {
    FUN_0054ef60(param_6);
    iStack_18 = iVar1 + 0x18;
  }
  iVar1 = iStack_18;
  if (iVar3 == iStack_18) {
    FUN_00559960(iStack_18,param_7);
    iVar3 = iStack_14;
  }
  else {
    FUN_0054ef60(param_7);
    iStack_18 = iVar1 + 0x18;
  }
  iVar1 = iStack_18;
  if (iVar3 == iStack_18) {
    FUN_00559960(iStack_18,param_8);
    iVar3 = iStack_14;
  }
  else {
    FUN_0054ef60(param_8);
    iStack_18 = iVar1 + 0x18;
  }
  iVar1 = iStack_18;
  if (iVar3 == iStack_18) {
    FUN_00559960(iStack_18,param_9);
    iVar3 = iStack_14;
  }
  else {
    FUN_0054ef60(param_9);
    iStack_18 = iVar1 + 0x18;
  }
  iVar1 = iStack_18;
  if (iVar3 == iStack_18) {
    FUN_00559960(iStack_18,param_10);
  }
  else {
    FUN_0054ef60(param_10);
    iStack_18 = iVar1 + 0x18;
  }
  FUN_00637260(&uStack_1c);
  piVar2 = (int *)FUN_00b3c0c0();
  if (param_1 != piVar2) {
    iVar1 = *param_1;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00b3fb60(*(undefined4 *)(iVar1 + 4));
    *(int *)(*param_1 + 4) = iVar1;
    *(int *)*param_1 = iVar1;
    *(int *)(*param_1 + 8) = iVar1;
    param_1[1] = 0;
    iVar1 = *param_1;
    *param_1 = *piVar2;
    *piVar2 = iVar1;
    iVar1 = param_1[1];
    param_1[1] = piVar2[1];
    piVar2[1] = iVar1;
  }
  *(undefined2 *)(param_1 + 2) = *(undefined2 *)(piVar2 + 2);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00b3fb60(*(undefined4 *)(iStack_28 + 4));
  *(int *)(iStack_28 + 4) = iStack_28;
  *(int *)iStack_28 = iStack_28;
  *(int *)(iStack_28 + 8) = iStack_28;
  FUN_01674ea0(iStack_28,0x20);
  FUN_00577a40();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24048 ; VA 0x00b426d0 ; FUN_00b426d0 */

undefined4 __thiscall FUN_00b426d0(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(*(int *)(param_1 + 0x14) + 4))(param_2,param_3);
  return param_2;
}



/* FUNCTION 24049 ; VA 0x00b426f0 ; FUN_00b426f0 */

undefined4 __thiscall FUN_00b426f0(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(*(int *)(param_1 + 0xc) + 4))(param_2,param_3);
  return param_2;
}



/* FUNCTION 24050 ; VA 0x00b42710 ; FUN_00b42710 */

undefined4 __thiscall FUN_00b42710(int param_1,undefined4 param_2)

{
  (**(code **)(*(int *)(param_1 + 0x14) + 8))(param_2);
  return param_2;
}



/* FUNCTION 24051 ; VA 0x00b42730 ; FUN_00b42730 */

undefined4 __thiscall FUN_00b42730(int param_1,undefined4 param_2)

{
  (**(code **)(*(int *)(param_1 + 0xc) + 8))(param_2);
  return param_2;
}



/* FUNCTION 24052 ; VA 0x00b42750 ; FUN_00b42750 */

uint * FUN_00b42750(uint *param_1,int *param_2,undefined4 *param_3,undefined4 param_4)

{
  code *pcVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  uint uVar7;
  undefined4 ****ppppuVar8;
  uint *puVar9;
  uint *puVar10;
  undefined4 ***apppuStack_6c [4];
  undefined4 uStack_5c;
  uint uStack_58;
  uint uStack_54;
  uint uStack_50;
  uint uStack_4c;
  uint uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 ***apppuStack_3c [4];
  int iStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  uint *puStack_1c;
  int iStack_18;
  uint *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2d50;
  pvStack_10 = ExceptionList;
  uStack_20 = 0xfffffffe;
  puStack_1c = (uint *)0x7fffffff;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_0056a9c0(0);
  FUN_005672c0(uVar3,&uStack_20);
  if ((*param_2 == iStack_18) && ((uint *)param_2[1] == puStack_14)) {
    param_1[4] = 0;
    param_1[5] = 0xf;
    *(undefined *)param_1 = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    ExceptionList = pvStack_10;
    return param_1;
  }
  uStack_44 = 0;
  uStack_40 = 0xf;
  uStack_54 = uStack_54 & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  puVar10 = (uint *)0x0;
  iStack_8 = 0;
  puStack_14 = (uint *)0x0;
  if (param_3[4] != 0) {
    do {
      puVar6 = param_3;
      if (0xf < (uint)param_3[5]) {
        puVar6 = (undefined4 *)*param_3;
      }
      uStack_24 = CONCAT31(uStack_24._1_3_,*(undefined *)((int)puVar6 + (int)puVar10));
      FUN_00b44c30(apppuStack_3c,param_3,puVar10);
      ppppuVar8 = apppuStack_3c;
      if (0xf < uStack_28) {
        ppppuVar8 = (undefined4 ****)apppuStack_3c[0];
      }
      iStack_8._0_1_ = 1;
      cVar2 = FUN_0055c360(ppppuVar8,iStack_2c,&DAT_018bc9b8,0);
      if (cVar2 == '\0') {
        puStack_1c = DAT_01eee638;
        puVar10 = (uint *)DAT_01eee638[1];
        if (*(char *)((int)puVar10 + 0xd) != '\0') {
LAB_00b42a43:
          FUN_016ddcf9("invalid map<K, T> key");
          pcVar1 = (code *)swi(3);
          puVar10 = (uint *)(*pcVar1)();
          return puVar10;
        }
        do {
          puVar9 = puVar10 + 4;
          if (0xf < puVar10[9]) {
            puVar9 = (uint *)*puVar9;
          }
          ppppuVar8 = apppuStack_3c;
          if (0xf < uStack_28) {
            ppppuVar8 = (undefined4 ****)apppuStack_3c[0];
          }
          iVar4 = FUN_0055c2d0(ppppuVar8,iStack_2c,puVar9,puVar10[8]);
          if (iVar4 < 0) {
            puVar9 = (uint *)puVar10[2];
          }
          else {
            puVar9 = (uint *)*puVar10;
            puStack_1c = puVar10;
          }
          puVar10 = puVar9;
        } while (*(char *)((int)puVar9 + 0xd) == '\0');
        if (puStack_1c == DAT_01eee638) goto LAB_00b42a43;
        puVar10 = puStack_1c + 4;
        ppppuVar8 = apppuStack_3c;
        if (0xf < uStack_28) {
          ppppuVar8 = (undefined4 ****)apppuStack_3c[0];
        }
        if (0xf < puStack_1c[9]) {
          puVar10 = (uint *)*puVar10;
        }
        iVar4 = FUN_0055c2d0(puVar10,puStack_1c[8],ppppuVar8,iStack_2c);
        if (iVar4 < 0) goto LAB_00b42a43;
        puVar5 = (undefined4 *)FUN_00b450e0(apppuStack_6c,param_2,puStack_1c + 10,param_4);
        puVar6 = puVar5 + 4;
        iStack_8._0_1_ = 2;
        if (0xf < (uint)puVar5[5]) {
          puVar5 = (undefined4 *)*puVar5;
        }
        FUN_00554150(puVar5,*puVar6);
        FUN_005507b0();
        puVar10 = (uint *)((int)puStack_14 + iStack_2c);
      }
      else {
        if ((char)uStack_24 == '[') {
          puVar9 = (uint *)param_3[4];
          puStack_1c = (uint *)((int)puVar10 + 1);
          puVar10 = puStack_1c;
          if (puStack_1c < puVar9) {
            do {
              puVar6 = param_3;
              if (0xf < (uint)param_3[5]) {
                puVar6 = (undefined4 *)*param_3;
              }
            } while ((*(char *)((int)puVar6 + (int)puVar10) != ']') &&
                    (puVar10 = (uint *)((int)puVar10 + 1), puVar10 < puVar9));
          }
          uStack_5c = 0;
          uVar7 = (int)puVar10 + (-1 - (int)puStack_14);
          uStack_58 = 0xf;
          apppuStack_6c[0] = (undefined4 ***)((uint)apppuStack_6c[0] & 0xffffff00);
          if (puVar9 < puStack_1c) {
            FUN_00554050();
            goto LAB_00b42a43;
          }
          if ((uint)((int)puVar9 - (int)puStack_1c) < uVar7) {
            uVar7 = (int)puVar9 - (int)puStack_1c;
          }
          puVar6 = param_3;
          if (0xf < (uint)param_3[5]) {
            puVar6 = (undefined4 *)*param_3;
          }
          FUN_005542c0((int)puVar6 + (int)puStack_1c,uVar7);
          ppppuVar8 = apppuStack_6c;
          if (0xf < uStack_58) {
            ppppuVar8 = (undefined4 ****)apppuStack_6c[0];
          }
          iStack_8._0_1_ = 3;
          FUN_00554150(ppppuVar8,uStack_5c);
          FUN_005507b0();
        }
        else {
          FUN_005558a0(uStack_24);
        }
        puVar10 = (uint *)((int)puVar10 + 1);
      }
      iStack_8 = (uint)iStack_8._1_3_ << 8;
      puStack_14 = puVar10;
      FUN_005507b0();
    } while (puVar10 < (uint *)param_3[4]);
  }
  uVar7 = uStack_54;
  uStack_54 = uStack_54 & 0xffffff00;
  param_1[4] = 0;
  param_1[5] = 0;
  *param_1 = uVar7;
  param_1[1] = uStack_50;
  param_1[2] = uStack_4c;
  param_1[3] = uStack_48;
  *(ulonglong *)(param_1 + 4) = CONCAT44(uStack_40,uStack_44);
  uStack_44 = 0;
  uStack_40 = 0xf;
  FUN_005507b0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24053 ; VA 0x00b42a50 ; FUN_00b42a50 */

/* WARNING: Type propagation algorithm not settling */

undefined * FUN_00b42a50(undefined *param_1,uint *param_2,char param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  undefined8 uVar6;
  undefined auStack_c4 [12];
  int iStack_b8;
  undefined **appuStack_b4 [15];
  undefined4 uStack_78;
  undefined4 auStack_74 [3];
  undefined4 uStack_68;
  undefined **ppuStack_64;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2d8f;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  uVar4 = param_2[1];
  uVar3 = *param_2;
  ExceptionList = &pvStack_10;
  uVar6 = FUN_016f3900(uVar3,uVar4,1000000,0);
  uVar6 = FUN_016f39b0(uVar6,1000000,0);
  uVar5 = uVar3 - (uint)uVar6;
  uVar4 = (uVar4 - (int)((ulonglong)uVar6 >> 0x20)) - (uint)(uVar3 < (uint)uVar6);
  if ((param_3 != '\0') && (uVar5 == 0 && uVar4 == 0)) {
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    ExceptionList = pvStack_10;
    return param_1;
  }
  appuStack_b4[0] = &PTR_018be314;
  uVar3 = (int)uVar4 >> 0x1f;
  uVar5 = uVar5 ^ uVar3;
  uStack_8 = 0;
  uStack_14 = 4;
  ppuStack_64 = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_68 = 0x48;
  FUN_00554f20(appuStack_b4 + 1,0);
  uStack_8 = 2;
  *(undefined ***)(appuStack_b4[0][1] + (int)appuStack_b4) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)((int)&iStack_b8 + (int)appuStack_b4[0][1]) = appuStack_b4[0][1] + -0x50;
  FUN_0054ee60();
  appuStack_b4[1] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  uStack_78 = 0;
  auStack_74[0] = 4;
  uStack_8 = 3;
  uVar1 = FUN_016de368();
  FUN_00b460e0(auStack_1c,uVar1);
  uStack_8._0_1_ = 4;
  if (piStack_18 != (int *)0x0) {
    puVar2 = (undefined4 *)(**(code **)(*piStack_18 + 8))();
    if (puVar2 != (undefined4 *)0x0) {
      (**(code **)*puVar2)(1);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  puVar2 = (undefined4 *)FUN_016df519(auStack_c4,6,0);
  (*(code *)*puVar2)(appuStack_b4[0][1] + (int)appuStack_b4,puVar2[2],puVar2[3]);
  *(undefined *)((int)auStack_74 + (int)appuStack_b4[0][1]) = 0x30;
  FUN_00872bd0(uVar5 - uVar3,((uVar4 ^ uVar3) - uVar3) - (uint)(uVar5 < uVar3));
  FUN_0058c420(param_1);
  FUN_00570540();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24054 ; VA 0x00b42c30 ; FUN_00b42c30 */

/* WARNING: Removing unreachable block (ram,0x00b42ecb) */

undefined4 *
FUN_00b42c30(undefined4 *param_1,ushort param_2,ushort param_3,ushort param_4,undefined4 param_5,
            undefined4 param_6,undefined4 param_7,int param_8,int param_9)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined2 extraout_var;
  uint uVar4;
  uint extraout_ECX;
  uint extraout_ECX_00;
  uint extraout_ECX_01;
  uint extraout_ECX_02;
  uint extraout_ECX_03;
  int iVar5;
  undefined8 uVar6;
  longlong lVar7;
  uint uVar8;
  undefined4 uVar9;
  undefined auStack_fc [36];
  undefined auStack_d8 [36];
  undefined auStack_b4 [8];
  undefined auStack_ac [8];
  undefined auStack_a4 [8];
  undefined auStack_9c [8];
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  uint uStack_88;
  int iStack_84;
  int iStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined auStack_70 [4];
  undefined auStack_6c [4];
  undefined auStack_68 [4];
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  uint uStack_58;
  int iStack_54;
  int iStack_50;
  undefined8 uStack_4c;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined auStack_38 [8];
  undefined4 uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2da0;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xfffffef8;
  uStack_2c = 0xfffffffe;
  uStack_28 = 0x7fffffff;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_0056a9c0(0);
  FUN_005672c0(uVar1,&uStack_2c);
  FUN_00b4a230(auStack_38);
  uVar1 = (undefined4)DAT_018d8a10;
  uVar3 = (undefined4)((ulonglong)DAT_018d8a10 >> 0x20);
  FUN_01726ab0();
  uVar4 = (uint)param_4;
  uStack_8 = 0;
  uVar9 = CONCAT22(extraout_var,1);
  iVar5 = (int)((double)CONCAT44(uVar3,uVar1) * (double)param_8);
  if (uVar4 + 1 < 2) {
    FUN_00588600(1,uVar4,0,uVar9);
    uVar4 = extraout_ECX;
LAB_00b42fd7:
    uVar8 = 1;
    FUN_00588600(1,uVar4,1,uVar9);
    uVar4 = extraout_ECX_00;
LAB_00b42fe1:
    FUN_00588640(1,uVar4,0,uVar8,uVar9);
    uVar4 = extraout_ECX_01;
LAB_00b42feb:
    uVar1 = 1;
    FUN_00588640(1,uVar4,1,uVar8,uVar9);
    uVar4 = extraout_ECX_02;
LAB_00b42ff5:
    FUN_00588680(0x578,uVar4,0,uVar1,uVar8);
    uVar4 = extraout_ECX_03;
  }
  else {
    if (0x1f < uVar4) goto LAB_00b42fd7;
    uVar9 = CONCAT22(extraout_var,param_4);
    uVar4 = (uint)param_3;
    uVar8 = 1;
    if (uVar4 + 1 < 2) goto LAB_00b42fe1;
    if (0xc < uVar4) goto LAB_00b42feb;
    uVar8 = (uint)param_3;
    uVar4 = (uint)param_2;
    uVar1 = 0x578;
    if (uVar4 + 1 < 0x579) goto LAB_00b42ff5;
    if (param_2 < 0x2711) {
      puVar2 = (undefined4 *)FUN_0056a920(param_2,uVar8,uVar9);
      uVar1 = *puVar2;
      FUN_005ef640(param_5,param_6,param_7,iVar5,iVar5 >> 0x1f);
      uStack_30 = uVar1;
      FUN_005672c0(&uStack_30,auStack_38);
      uVar1 = uStack_18;
      uStack_24 = uStack_1c;
      uStack_20 = uStack_18;
      uStack_8 = 0xffffffff;
      FUN_00b483a0(&uStack_24);
      if (param_9 == 0) {
        puVar2 = (undefined4 *)FUN_00b4b490(auStack_38,uStack_1c,uStack_18);
        uVar1 = *puVar2;
        uVar3 = puVar2[1];
        param_1[1] = uStack_18;
        *param_1 = uStack_1c;
        param_1[2] = uVar1;
        param_1[3] = uVar3;
        ExceptionList = pvStack_10;
        return param_1;
      }
      if (param_9 != 1) {
        FUN_0060f000();
        ExceptionList = pvStack_10;
        return param_1;
      }
      puVar2 = (undefined4 *)FUN_00b4a230(auStack_9c);
      uVar6 = FUN_016f3900(*puVar2,puVar2[1],1000000,0);
      uStack_64 = FUN_016f4270(uVar6,0x3c,0);
      puVar2 = (undefined4 *)FUN_00b4a230(auStack_a4);
      uVar6 = FUN_016f3900(*puVar2,puVar2[1],60000000,0);
      uStack_60 = FUN_016f4270(uVar6,0x3c,0);
      puVar2 = (undefined4 *)FUN_00b4a230(auStack_ac);
      uStack_5c = FUN_016f3900(*puVar2,puVar2[1],3600000000,0);
      puVar2 = (undefined4 *)FUN_00b41a70(auStack_68);
      FUN_00b43600(&uStack_2c,*puVar2);
      uStack_58 = uStack_28 & 0xffff;
      puVar2 = (undefined4 *)FUN_00b41a70(auStack_6c);
      FUN_00b43600(&uStack_2c,*puVar2);
      iStack_54 = (uStack_2c >> 0x10) - 1;
      puVar2 = (undefined4 *)FUN_00b41a70(auStack_70);
      FUN_00b43600(&uStack_2c,*puVar2);
      iStack_80 = (uStack_2c & 0xffff) - 0x76c;
      uStack_4c = 0;
      uStack_44 = 0;
      uStack_94 = uStack_64;
      uStack_90 = uStack_60;
      uStack_8c = uStack_5c;
      uStack_88 = uStack_58;
      uStack_74 = 0;
      iStack_84 = iStack_54;
      uStack_7c = 0;
      uStack_78 = 0;
      iStack_50 = iStack_80;
      lVar7 = FUN_01724b94(&uStack_94);
      if (lVar7 < 1) {
        FUN_00b4b420(&uStack_24);
        FUN_00b46ea0(auStack_38);
        uVar3 = FUN_006d31a0(auStack_b4,auStack_38);
        FUN_00b3e000(&uStack_24,uVar3);
LAB_00b42f6c:
        *param_1 = uStack_24;
        param_1[1] = uStack_20;
        param_1[2] = uStack_1c;
        param_1[3] = uVar1;
        ExceptionList = pvStack_10;
        return param_1;
      }
      uStack_44 = uStack_74;
      uStack_40 = FUN_01724b94(&uStack_64);
      uStack_30 = (undefined4)((ulonglong)uStack_40 >> 0x20);
      uStack_18 = (undefined4)uStack_40;
      iVar5 = FUN_017243ef(auStack_d8,&uStack_40);
      if (iVar5 == 0) {
        iVar5 = FUN_017246b2(auStack_fc,&uStack_40);
        if (iVar5 == 0) {
          FUN_00b48520(&uStack_24,auStack_d8);
          goto LAB_00b42f6c;
        }
      }
      goto LAB_00b4300f;
    }
  }
  FUN_00588680(0x578,uVar4,1,uVar1,uVar8);
LAB_00b4300f:
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Error interpreting timestamp as a date/time (%lld)\n",uStack_18,uStack_30);
}



/* FUNCTION 24055 ; VA 0x00b42fc3 ; Catch@00b42fc3 */

void Catch_00b42fc3(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_016757c0(
              "Error interpreting year, month, day, hour, minute, second as a precise point in time. Fields out of range."
              );
}



/* FUNCTION 24056 ; VA 0x00b43020 ; FUN_00b43020 */

undefined4 * FUN_00b43020(undefined4 *param_1,undefined4 param_2)

{
  char cVar1;
  undefined *puVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  uint uVar7;
  char *pcVar8;
  uint uVar9;
  undefined **appuStack_e8 [2];
  undefined8 uStack_e0;
  undefined auStack_d8 [76];
  undefined4 uStack_8c;
  undefined **ppuStack_88;
  uint auStack_40 [2];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  uint uStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined4 uStack_20;
  int *piStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f2e2d;
  pvStack_10 = ExceptionList;
  appuStack_e8[0] = &PTR_018bffbc;
  uStack_8 = 0;
  uStack_14 = 2;
  ppuStack_88 = std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  uStack_8c = 0x48;
  uStack_e0 = 0;
  ExceptionList = &pvStack_10;
  FUN_00554f20(auStack_d8,0);
  uStack_8 = 2;
  *(undefined ***)((int)appuStack_e8 + (int)appuStack_e8[0][1]) =
       std::basic_istringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(auStack_d8 + (int)(appuStack_e8[0][1] + -0x14)) = appuStack_e8[0][1] + -0x60;
  FUN_005657a0(param_2,1);
  uStack_8 = 3;
  piVar4 = (int *)FUN_01674e20(0xf0);
  uStack_8._0_1_ = 4;
  piStack_24 = piVar4;
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = auStack_40[0] & 0xffffff00;
    FUN_005542c0("%Y-%m-%d %H:%M:%S%F %ZP",0x17);
    uStack_8 = CONCAT31(uStack_8._1_3_,5);
    uStack_14 = 3;
    FUN_00b3a9d0(auStack_40,0);
    *piVar4 = (int)boost::date_time::
                   time_input_facet<class_boost::posix_time::ptime,char,class_std::istreambuf_iterator<char,struct_std::char_traits<char>_>_>
                   ::vftable;
    puVar2 = PTR_DAT_01d66f70;
    piVar4[0x3a] = 0;
    piVar4[0x3b] = 0xf;
    uStack_8 = 6;
    piStack_1c = (int *)(puVar2 + 1);
    *(undefined *)(piVar4 + 0x36) = 0;
    pcVar8 = puVar2;
    do {
      cVar1 = *pcVar8;
      pcVar8 = pcVar8 + 1;
    } while (cVar1 != '\0');
    FUN_005542c0(puVar2,(int)pcVar8 - (int)piStack_1c);
  }
  uStack_8 = 3;
  if (((uStack_14 & 1) != 0) && (0xf < uStack_2c)) {
    uVar9 = uStack_2c + 1;
    uVar7 = auStack_40[0];
    if (0xfff < uVar9) {
      uVar7 = *(uint *)(auStack_40[0] - 4);
      uVar9 = uStack_2c + 0x24;
      if (0x1f < (auStack_40[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar7,uVar9);
  }
  uVar5 = FUN_016de368(piVar4);
  uVar5 = FUN_00b33de0(uVar5,piVar4);
  uStack_8._0_1_ = 8;
  FUN_00b460e0(auStack_28,uVar5);
  uStack_8._0_1_ = 9;
  if (piStack_24 != (int *)0x0) {
    puVar6 = (undefined4 *)(**(code **)(*piStack_24 + 8))();
    if (puVar6 != (undefined4 *)0x0) {
      (**(code **)*puVar6)(1);
    }
  }
  uStack_8._0_1_ = 10;
  if (piStack_1c != (int *)0x0) {
    puVar6 = (undefined4 *)(**(code **)(*piStack_1c + 8))();
    if (puVar6 != (undefined4 *)0x0) {
      (**(code **)*puVar6)(1);
    }
  }
  uStack_18 = 0;
  uStack_14 = 0;
  uStack_8._0_1_ = 0xb;
  uStack_20 = 0xfffffffe;
  piStack_1c = (int *)0x7fffffff;
  uVar5 = FUN_0056a9c0(0);
  FUN_005672c0(uVar5,&uStack_20);
  uStack_38 = uStack_18;
  uStack_34 = uStack_14;
  uStack_30 = 0;
  uStack_2c = 0;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  uStack_18 = 0xfffffffe;
  uStack_14 = 0x7fffffff;
  uVar5 = FUN_0056a9c0(0);
  FUN_005672c0(uVar5,&uStack_18);
  piVar4 = (int *)FUN_00b33ec0(appuStack_e8,&uStack_38);
  uVar3 = uStack_34;
  uVar5 = uStack_38;
  if ((*(byte *)(*(int *)(*piVar4 + 4) + 0xc + (int)piVar4) & 6) == 0) {
    uStack_20 = uStack_38;
    piStack_1c = (int *)uStack_34;
    FUN_00b483a0(&uStack_20);
    puVar6 = (undefined4 *)FUN_00b4b490(auStack_28,uVar5,uVar3);
    *param_1 = uStack_38;
    param_1[2] = *puVar6;
    param_1[3] = puVar6[1];
    param_1[1] = uVar3;
    FUN_00b3d840();
    FUN_005703e0();
    ExceptionList = pvStack_10;
    return param_1;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Invalid ISO 8601 date.\n");
}



/* FUNCTION 24057 ; VA 0x00b43330 ; FUN_00b43330 */

uint * FUN_00b43330(uint *param_1,uint param_2,uint param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint *puVar5;
  undefined auStack_54 [36];
  undefined auStack_30 [36];
  undefined auStack_c [8];
  
  uVar4 = param_3 + 4 + (uint)(0xcfdd65ff < param_2);
  if ((0x3f < uVar4) || ((0x3e < uVar4 && (0x3016db7f < param_2 + 0x30229a00)))) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Error interpreting timestamp as a precise point in time. Fields out of range. UnixTimestamp should be between %lld and %lld."
                 ,0xcfdd6600,0xfffffffb,0xfff4417f,0x3a);
  }
  if ((param_3 < 8) && ((param_3 < 7 || (param_2 < 0x933fff80)))) {
    FUN_00b45090(auStack_54,auStack_30,param_2,param_3);
    puVar5 = (uint *)FUN_00b48520(&param_2,auStack_30);
    uVar4 = *puVar5;
    uVar1 = puVar5[1];
    puVar5 = (uint *)FUN_00b48520(auStack_c,auStack_54);
    uVar2 = *puVar5;
    param_1[3] = uVar1;
    *param_1 = uVar2;
    uVar1 = puVar5[1];
    param_1[2] = uVar4;
    param_1[1] = uVar1;
    return param_1;
  }
  FUN_00b44e20(&param_2,param_2,param_3);
  uVar3 = param_3;
  uVar2 = param_2;
  puVar5 = (uint *)FUN_00b4b490(&param_2,param_2,param_3);
  uVar4 = *puVar5;
  uVar1 = puVar5[1];
  param_1[1] = uVar3;
  *param_1 = uVar2;
  param_1[3] = uVar1;
  param_1[2] = uVar4;
  return param_1;
}



/* FUNCTION 24058 ; VA 0x00b43410 ; FUN_00b43410 */

/* WARNING: Removing unreachable block (ram,0x00b43474) */
/* WARNING: Removing unreachable block (ram,0x00b43487) */

undefined4 * FUN_00b43410(undefined4 *param_1,uint param_2,int param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  double dVar6;
  ulonglong uVar7;
  undefined auStack_80 [36];
  undefined auStack_5c [36];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined auStack_28 [8];
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  undefined auStack_18 [4];
  undefined4 uStack_14;
  undefined8 uStack_10;
  undefined4 uStack_8;
  
  uVar3 = param_3 + 0x105c + (uint)(0xf8d66fff < param_2);
  if ((uVar3 < 0xf6d4) && ((uVar3 < 0xf6d3 || (param_2 + 0x7299000 < 0xd9496c00)))) {
    uVar7 = FUN_016f3900(param_2,param_3,1000,0);
    uStack_14 = (undefined4)(uVar7 >> 0x20);
    uStack_1c = (undefined4)uVar7;
    if (0x3f3016db7f < uVar7 + 0x430229a00) {
                    /* WARNING: Subroutine does not return */
      FUN_016757c0("Error interpreting timestamp as a precise point in time. Fields out of range. UnixTimestamp should be between %lld and %lld."
                   ,0xcfdd6600,0xfffffffb,0xfff4417f,0x3a);
    }
    if (uVar7 < 0x7933fff80) {
      FUN_00b45090(auStack_80,auStack_5c,uVar7);
      puVar4 = (undefined4 *)FUN_00b48520(&uStack_10,auStack_5c);
      uVar1 = *puVar4;
      uVar2 = puVar4[1];
      puVar4 = (undefined4 *)FUN_00b48520(auStack_28,auStack_80);
      uStack_10._0_4_ = *puVar4;
      uStack_10._4_4_ = puVar4[1];
      uStack_30 = uVar1;
      uStack_2c = uVar2;
      uStack_8 = (undefined4)uStack_10;
    }
    else {
      FUN_00b44e20(&uStack_10,uVar7);
      puVar4 = (undefined4 *)FUN_00b4b490(auStack_28,(undefined4)uStack_10,uStack_10._4_4_);
      uStack_30 = *puVar4;
      uStack_2c = puVar4[1];
    }
    uStack_38 = (undefined4)uStack_10;
    uStack_34 = uStack_10._4_4_;
    FUN_00b4a230(auStack_28);
    dVar6 = DAT_018d8a10;
    FUN_01726ab0();
    uStack_10 = dVar6;
    FUN_016f39b0(uStack_1c,uStack_14,1000,0);
    FUN_016f4020();
    uVar5 = FUN_005ef640(0,0,0,(int)(uStack_10 * dVar6),(int)(uStack_10 * dVar6) >> 0x1f);
    puVar4 = (undefined4 *)FUN_00b3e000(auStack_20,uVar5);
    uVar1 = *puVar4;
    uVar2 = puVar4[1];
    puVar4 = (undefined4 *)FUN_00b3e000(auStack_18,uVar5);
    *param_1 = *puVar4;
    uVar5 = puVar4[1];
    param_1[2] = uVar1;
    param_1[3] = uVar2;
    param_1[1] = uVar5;
    return param_1;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Error interpreting timestampMillis as a precise point in time. Fields out of range. UnixTimestampMillis should be between %lld and %lld."
               ,0xf8d67000,0xffffefa3,0xd21fdbff,58999);
}



/* FUNCTION 24059 ; VA 0x00b43600 ; FUN_00b43600 */

void FUN_00b43600(ushort *param_1,int param_2)

{
  code *pcVar1;
  uint uVar2;
  ushort uVar3;
  uint uVar4;
  uint extraout_ECX;
  uint extraout_EDX;
  uint extraout_EDX_00;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  
  uVar2 = ((param_2 + 0x7d2c) * 4 + 3U) / 0x23ab1;
  iVar5 = (param_2 + 0x7d2c) - (uVar2 * 0x23ab1 >> 2);
  uVar10 = (iVar5 * 4 + 3U) / 0x5b5;
  iVar5 = iVar5 - (uVar10 * 0x5b5 >> 2);
  uVar8 = (iVar5 * 5 + 2U) / 0x99;
  uVar6 = (iVar5 - (uVar8 * 0x99 + 2) / 5) + 1;
  uVar4 = uVar8 / 10 & 0xffff;
  uVar7 = uVar6 & 0xffff;
  uVar9 = uVar8 + uVar4 * -0xc + 3;
  uVar8 = uVar9 & 0xffff;
  uVar10 = uVar2 * 100 + -0x12c0 + uVar4 + uVar10;
  uVar2 = uVar10 & 0xffff;
  if (uVar2 + 1 < 0x579) {
    FUN_00588680(0x578,uVar2,0);
    uVar2 = extraout_ECX;
LAB_00b436f5:
    FUN_00588680(0x578,uVar2,1);
LAB_00b43702:
    FUN_00588600(1,uVar7,0);
LAB_00b4370c:
    FUN_00588600(1,uVar7,1);
    uVar8 = extraout_EDX;
  }
  else {
    uVar3 = (ushort)uVar10;
    if (10000 < uVar3) goto LAB_00b436f5;
    if (uVar7 + 1 < 2) goto LAB_00b43702;
    if (0x1f < uVar7) goto LAB_00b4370c;
    if (1 < uVar8 + 1) {
      if (uVar8 < 0xd) {
        param_1[2] = (ushort)uVar6;
        *param_1 = uVar3;
        param_1[1] = (ushort)uVar9;
        return;
      }
      goto LAB_00b43720;
    }
  }
  FUN_00588640(1,uVar8,0);
  uVar8 = extraout_EDX_00;
LAB_00b43720:
  FUN_00588640(1,uVar8,1);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 24060 ; VA 0x00b43730 ; FUN_00b43730 */

undefined4 FUN_00b43730(undefined4 param_1,uint param_2)

{
  undefined4 *puVar1;
  int iVar2;
  longlong lVar3;
  longlong lStack_14;
  undefined4 uStack_8;
  
  puVar1 = (undefined4 *)FUN_0056a920();
  uStack_8 = *puVar1;
  lVar3 = FUN_016f39b0(0,1000000,0);
  lStack_14 = lVar3;
  FUN_005672c0(&uStack_8,&lStack_14);
  if ((int)param_2 < 0) {
    lVar3 = (longlong)(int)((param_2 ^ (int)param_2 >> 0x1f) - ((int)param_2 >> 0x1f)) * 1000000 +
            lVar3;
    iVar2 = (int)lVar3;
    lStack_14 = CONCAT44(-((int)((ulonglong)lVar3 >> 0x20) + (uint)(iVar2 != 0)),-iVar2);
  }
  else {
    lStack_14 = (longlong)(int)param_2 * 1000000 + lVar3;
  }
  FUN_00b3e000(param_1,&lStack_14);
  return param_1;
}



/* FUNCTION 24061 ; VA 0x00b43800 ; FUN_00b43800 */

int * FUN_00b43800(int *param_1,int *param_2,undefined4 param_3,int param_4,undefined4 *param_5,
                  undefined4 param_6,int param_7)

{
  int *piVar1;
  byte *pbVar2;
  int *piVar3;
  char cVar4;
  undefined uVar5;
  ushort uVar6;
  uint uVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined2 *puVar10;
  char *pcVar11;
  undefined2 extraout_var;
  short sVar12;
  char *pcVar13;
  char *pcVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined4 uVar17;
  undefined auStack_a2 [8];
  undefined auStack_9a [2];
  undefined auStack_98 [2];
  undefined auStack_96 [2];
  undefined4 uStack_94;
  undefined4 uStack_90;
  int iStack_8c;
  int iStack_88;
  int iStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined auStack_78 [16];
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  uint uStack_5c;
  uint uStack_58;
  char acStack_54 [4];
  char acStack_50 [4];
  char acStack_4c [4];
  char *pcStack_48;
  uint uStack_44;
  undefined auStack_40 [16];
  uint uStack_30;
  undefined4 uStack_2c;
  ushort uStack_28;
  short sStack_26;
  char cStack_21;
  undefined8 uStack_20;
  int iStack_18;
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar15 = param_3;
  piVar3 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2e98;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff50;
  ExceptionList = &pvStack_10;
  cVar4 = FUN_00a8d280(param_2,param_3);
  while (cVar4 == '\0') {
    if (*(char *)(piVar3 + 1) == '\0') {
      piVar1 = (int *)*piVar3;
      if (piVar1 == (int *)0x0) {
LAB_00b43872:
        *piVar3 = 0;
      }
      else {
        if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
          uVar7 = (**(code **)(*piVar1 + 0x18))();
        }
        else {
          uVar7 = (uint)**(byte **)piVar1[7];
        }
        if (uVar7 == 0xffffffff) goto LAB_00b43872;
        *(char *)((int)piVar3 + 5) = (char)uVar7;
      }
      *(undefined *)(piVar3 + 1) = 1;
    }
    iVar8 = FUN_0171dc29((int)*(char *)((int)piVar3 + 5));
    if (iVar8 == 0) break;
    piVar1 = (int *)*piVar3;
    if (piVar1 == (int *)0x0) {
LAB_00b438c6:
      *piVar3 = 0;
      *(undefined *)(piVar3 + 1) = 1;
    }
    else {
      if (*(int *)piVar1[7] == 0) {
LAB_00b438b6:
        uVar7 = (**(code **)(*piVar1 + 0x1c))();
      }
      else {
        iVar8 = *(int *)piVar1[0xb];
        if (iVar8 < 1) goto LAB_00b438b6;
        *(int *)piVar1[0xb] = iVar8 + -1;
        pbVar2 = *(byte **)piVar1[7];
        *(byte **)piVar1[7] = pbVar2 + 1;
        uVar7 = (uint)*pbVar2;
      }
      if (uVar7 == 0xffffffff) goto LAB_00b438c6;
      *(undefined *)(piVar3 + 1) = 0;
    }
    cVar4 = FUN_00a8d280(piVar3,uVar15);
  }
  uStack_44 = uStack_44 & 0xffffff00;
  cStack_21 = '\0';
  uStack_58 = uStack_58 & 0xffffff00;
  cVar4 = FUN_00a8d280(piVar3,uVar15);
  if (cVar4 != '\0') goto LAB_00b43951;
  if (*(char *)(piVar3 + 1) == '\0') {
    piVar1 = (int *)*piVar3;
    if (piVar1 == (int *)0x0) {
LAB_00b4392c:
      *piVar3 = 0;
    }
    else {
      if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
        uVar7 = (**(code **)(*piVar1 + 0x18))();
      }
      else {
        uVar7 = (uint)**(byte **)piVar1[7];
      }
      if (uVar7 == 0xffffffff) goto LAB_00b4392c;
      *(char *)((int)piVar3 + 5) = (char)uVar7;
    }
    *(undefined *)(piVar3 + 1) = 1;
  }
  if ((*(char *)((int)piVar3 + 5) == '-') || (cVar4 = FUN_00a8e710(), cVar4 == '+')) {
    uVar5 = FUN_00a8e710();
    uStack_58 = CONCAT31(uStack_58._1_3_,uVar5);
  }
LAB_00b43951:
  iStack_8c = 0;
  iStack_88 = 0;
  iStack_84 = 0;
  uStack_60 = CONCAT22(uStack_60._2_2_,0x578);
  uStack_80 = CONCAT22(uStack_80._2_2_,1);
  uStack_7c = CONCAT22(uStack_7c._2_2_,1);
  uStack_20 = 0;
  uStack_5c = 0;
  uStack_8 = 0;
  piVar1 = *(int **)(*(int *)(param_4 + 0x30) + 4);
  (**(code **)(*piVar1 + 4))();
  uStack_8 = 1;
  FUN_016dda75(0);
  if (DAT_01eeae4c == 0) {
    FUN_016dda75(0);
    if (DAT_01eeae4c == 0) {
      DAT_01eeae4c = DAT_021130c8 + 1;
      DAT_021130c8 = DAT_01eeae4c;
    }
    FUN_016ddacd();
  }
  if ((((uint)piVar1[3] <= DAT_01eeae4c) || (*(int *)(piVar1[2] + DAT_01eeae4c * 4) == 0)) &&
     (*(char *)(piVar1 + 5) != '\0')) {
    FUN_016de17b();
  }
  FUN_016ddacd();
  uStack_8 = 2;
  if ((piVar1 != (int *)0x0) &&
     (puVar9 = (undefined4 *)(**(code **)(*piVar1 + 8))(), puVar9 != (undefined4 *)0x0)) {
    (**(code **)*puVar9)(1);
  }
  pcStack_48 = (char *)(iStack_18 + 8);
  uStack_8 = 0xffffffff;
  pcVar14 = pcStack_48;
  if (0xf < *(uint *)(iStack_18 + 0x1c)) {
    pcVar14 = *(char **)pcStack_48;
  }
LAB_00b43a40:
  while( true ) {
    pcVar11 = pcStack_48;
    if (0xf < *(uint *)(pcStack_48 + 0x14)) {
      pcVar11 = *(char **)pcStack_48;
    }
    if ((pcVar14 == pcVar11 + *(int *)(pcStack_48 + 0x10)) ||
       (cVar4 = FUN_00a8d280(piVar3,uVar15), cVar4 != '\0')) goto LAB_00b4427d;
    if (*pcVar14 != '%') break;
    pcVar13 = pcVar14 + 1;
    pcVar11 = pcStack_48;
    if (0xf < *(uint *)(pcStack_48 + 0x14)) {
      pcVar11 = *(char **)pcStack_48;
    }
    if (pcVar13 == pcVar11 + *(int *)(pcStack_48 + 0x10)) {
LAB_00b4427d:
      FUN_0056a9c0(0);
      sVar12 = (short)uStack_5c;
      if (sVar12 < 1) {
        puVar9 = (undefined4 *)FUN_0056a920(uStack_60,uStack_80,uStack_7c);
      }
      else {
        uVar17 = CONCAT22(extraout_var,0x1f);
        uVar15 = 0xc;
        uVar16 = 0xc;
        FUN_0056ace0(uStack_60 + -1);
        FUN_0056a920(uVar15,uVar16,uVar17);
        param_7 = (int)sVar12;
        puVar9 = (undefined4 *)FUN_00b3e0c0(&param_2,&param_7);
      }
      uVar15 = *puVar9;
      FUN_005ef640(iStack_8c,iStack_88,iStack_84,(undefined4)uStack_20,uStack_20._4_4_);
      uStack_94 = (undefined4)uStack_20;
      uStack_90 = uStack_20._4_4_;
      param_7 = uVar15;
      FUN_005672c0(&param_7,&uStack_94);
      *param_5 = (undefined4)uStack_20;
      param_5[1] = uStack_20._4_4_;
      *param_1 = *piVar3;
      param_1[1] = piVar3[1];
      ExceptionList = pvStack_10;
      return param_1;
    }
    cVar4 = *pcVar13;
    if (cVar4 == '%') {
      piVar1 = (int *)*piVar3;
      if (piVar1 != (int *)0x0) {
        if (*(int *)piVar1[7] == 0) {
LAB_00b441e6:
          uVar7 = (**(code **)(*piVar1 + 0x1c))();
        }
        else {
          iVar8 = *(int *)piVar1[0xb];
          if (iVar8 < 1) goto LAB_00b441e6;
          *(int *)piVar1[0xb] = iVar8 + -1;
          pbVar2 = *(byte **)piVar1[7];
          *(byte **)piVar1[7] = pbVar2 + 1;
          uVar7 = (uint)*pbVar2;
        }
        if (uVar7 != 0xffffffff) {
          *(undefined *)(piVar3 + 1) = 0;
          goto switchD_00b43aae_caseD_43;
        }
      }
      *piVar3 = 0;
      *(undefined *)(piVar3 + 1) = 1;
      goto switchD_00b43aae_caseD_43;
    }
    switch(cVar4) {
    case 'A':
    case 'a':
    case 'w':
      acStack_54[1] = cVar4;
      pcVar14 = acStack_54;
      acStack_54[0] = '%';
      acStack_54[2] = 0;
      uStack_68 = 0;
      uStack_64 = 0xf;
      auStack_78[0] = 0;
      do {
        cVar4 = *pcVar14;
        pcVar14 = pcVar14 + 1;
      } while (cVar4 != '\0');
      FUN_005542c0(acStack_54,(int)pcVar14 - (int)(acStack_54 + 1));
      uStack_28 = 0;
      uStack_30 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = 0;
      sStack_26 = -1;
      uStack_8 = 0x1d;
      FUN_0054ef60(auStack_78);
      FUN_00b47b40(auStack_9a,piVar3,uVar15);
      uVar5 = (undefined)uStack_44;
      if (uStack_28 < uStack_30) {
        uVar5 = 1;
      }
      uStack_44 = CONCAT31(uStack_44._1_3_,uVar5);
      goto LAB_00b43b45;
    case 'B':
    case 'b':
    case 'm':
      acStack_50[1] = cVar4;
      pcVar14 = acStack_50;
      acStack_50[0] = '%';
      acStack_50[2] = 0;
      uStack_68 = 0;
      uStack_64 = 0xf;
      auStack_78[0] = 0;
      do {
        cVar4 = *pcVar14;
        pcVar14 = pcVar14 + 1;
      } while (cVar4 != '\0');
      FUN_005542c0(acStack_50,(int)pcVar14 - (int)(acStack_50 + 1));
      uStack_28 = 0;
      uStack_30 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = 0;
      sStack_26 = -1;
      uStack_8 = 0x19;
      FUN_0054ef60(auStack_78);
      puVar10 = (undefined2 *)FUN_00b47610(auStack_98,piVar3,uVar15);
      uStack_44 = uStack_44 & 0xff;
      uStack_80 = CONCAT22(uStack_80._2_2_,*puVar10);
      if (uStack_28 < uStack_30) {
        uStack_44 = 1;
      }
      goto LAB_00b43b45;
    case 'F':
      cVar4 = FUN_00a8e710();
      if (cVar4 == '.') goto LAB_00b440bf;
      goto LAB_00b440d4;
    case 'H':
      uStack_30 = 0;
      uStack_28 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = 0;
      sStack_26 = -1;
      uStack_8 = 0x23;
      param_4 = CONCAT13(0x30,(undefined3)param_4);
      iStack_8c = FUN_00b37680(piVar3,uVar15,auStack_40,2,(int)&param_4 + 3);
      if (iStack_8c == -1) {
LAB_00b43f9d:
        FUN_00b35da0(param_1,piVar3,uVar15,param_5,uStack_58);
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return param_1;
      }
      goto LAB_00b43e90;
    case 'M':
      uStack_30 = 0;
      uStack_28 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = 0;
      sStack_26 = -1;
      uStack_8 = 0x24;
      param_4 = CONCAT13(0x30,(undefined3)param_4);
      iStack_88 = FUN_00b37680(piVar3,uVar15,auStack_40,2,(int)&param_4 + 3);
      if (iStack_88 == -1) {
        FUN_00b35da0(param_1,piVar3,uVar15,param_5,uStack_58);
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return param_1;
      }
      goto LAB_00b43e90;
    case 'S':
    case 's':
      uStack_30 = 0;
      uStack_28 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = 0;
      sStack_26 = -1;
      uStack_8 = 0x25;
      param_4 = CONCAT13(0x30,(undefined3)param_4);
      iStack_84 = FUN_00b37680(piVar3,uVar15,auStack_40,2,(int)&param_4 + 3);
      if (iStack_84 == -1) goto LAB_00b43f9d;
      uStack_8 = 0xffffffff;
      if (*pcVar13 != 'S') {
        FUN_005507b0();
        goto switchD_00b43aae_caseD_66;
      }
      FUN_005507b0();
      break;
    case 'Y':
    case 'y':
      acStack_4c[1] = cVar4;
      pcVar14 = acStack_4c;
      acStack_4c[0] = '%';
      acStack_4c[2] = 0;
      uStack_68 = 0;
      uStack_64 = 0xf;
      auStack_78[0] = 0;
      do {
        cVar4 = *pcVar14;
        pcVar14 = pcVar14 + 1;
      } while (cVar4 != '\0');
      FUN_005542c0(acStack_4c,(int)pcVar14 - (int)(acStack_4c + 1));
      uStack_28 = 0;
      uStack_30 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = 0;
      sStack_26 = -1;
      uStack_8 = 0x15;
      FUN_0054ef60(auStack_78);
      puVar10 = (undefined2 *)FUN_00b48070(auStack_96,piVar3,uVar15);
      uStack_60 = CONCAT22(uStack_60._2_2_,*puVar10);
LAB_00b43b45:
      FUN_005507b0();
      uStack_8 = 0xffffffff;
      FUN_005507b0();
      break;
    case 'Z':
      if ((char)param_7 == '\0') goto LAB_00b440d4;
      pcVar13 = pcVar14 + 2;
      if (*pcVar13 == 'P') {
        cVar4 = FUN_00a8d280(piVar3,uVar15);
        while (cVar4 == '\0') {
          cVar4 = FUN_00a8e710();
          iVar8 = FUN_0171dc29((int)cVar4);
          if (iVar8 == 0) break;
          FUN_00a8e760();
          cVar4 = FUN_00a8d280(piVar3,uVar15);
        }
        cVar4 = FUN_00a8d280(piVar3,uVar15);
        while (cVar4 == '\0') {
          cVar4 = FUN_00a8e710();
          iVar8 = FUN_0171dc29((int)cVar4);
          if (iVar8 != 0) break;
          uVar5 = FUN_00a8e710();
          uStack_90 = CONCAT31(uStack_90._1_3_,uVar5);
          FUN_005558a0(uStack_90);
          FUN_00a8e760();
          cVar4 = FUN_00a8d280(piVar3,uVar15);
        }
        break;
      }
      goto LAB_00b44209;
    case 'd':
      uStack_8 = 0x20;
      puVar10 = (undefined2 *)FUN_00b47250(auStack_a2,piVar3,uVar15);
      uStack_8 = 0xffffffff;
      uStack_7c = CONCAT22(uStack_7c._2_2_,*puVar10);
      break;
    case 'f':
switchD_00b43aae_caseD_66:
      cVar4 = FUN_00a8e710();
      if (cVar4 != '.') {
        FUN_00b35da0(param_1,piVar3,uVar15,param_5,uStack_58);
        ExceptionList = pvStack_10;
        return param_1;
      }
LAB_00b440bf:
      FUN_00a8e760();
      FUN_00b473e0(piVar3,uVar15,&uStack_20);
LAB_00b440d4:
      uStack_44 = CONCAT31(uStack_44._1_3_,1);
      break;
    case 'j':
      uStack_30 = 0;
      uStack_28 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = 0;
      sStack_26 = -1;
      uStack_8 = 0x1f;
      param_4 = CONCAT13(0x30,(undefined3)param_4);
      uVar6 = FUN_00b37410(piVar3,uVar15,auStack_40,3,(int)&param_4 + 3);
      uStack_5c = (uint)uVar6;
      if ((uVar6 == 0xffff) && (cVar4 = FUN_00b46f70(piVar3,uVar15,auStack_40), cVar4 != '\0')) {
        FUN_0061f5c0(&uStack_20,(int)sStack_26);
        *param_5 = (undefined4)uStack_20;
        param_5[1] = uStack_20._4_4_;
        *param_1 = *piVar3;
        param_1[1] = piVar3[1];
        FUN_005507b0();
        ExceptionList = pvStack_10;
        return param_1;
      }
      FUN_00b39ac0(uStack_5c);
LAB_00b43e90:
      uStack_8 = 0xffffffff;
      FUN_005507b0();
    }
switchD_00b43aae_caseD_43:
    if (cStack_21 == '\0') {
      pcVar14 = pcVar13 + 1;
    }
    else {
LAB_00b44209:
      cStack_21 = '\0';
      pcVar14 = pcVar13;
    }
  }
  pcVar14 = pcVar14 + 1;
  if ((char)uStack_44 != '\0') goto code_r0x00b44220;
  piVar1 = (int *)*piVar3;
  if (piVar1 != (int *)0x0) {
    if (*(int *)piVar1[7] == 0) {
LAB_00b44255:
      uVar7 = (**(code **)(*piVar1 + 0x1c))();
    }
    else {
      iVar8 = *(int *)piVar1[0xb];
      if (iVar8 < 1) goto LAB_00b44255;
      *(int *)piVar1[0xb] = iVar8 + -1;
      pbVar2 = *(byte **)piVar1[7];
      *(byte **)piVar1[7] = pbVar2 + 1;
      uVar7 = (uint)*pbVar2;
    }
    if (uVar7 != 0xffffffff) {
      *(undefined *)(piVar3 + 1) = 0;
      goto LAB_00b43a40;
    }
  }
  *piVar3 = 0;
  *(undefined *)(piVar3 + 1) = 1;
  goto LAB_00b43a40;
code_r0x00b44220:
  uStack_44 = uStack_44 & 0xffffff00;
  goto LAB_00b43a40;
}



/* FUNCTION 24062 ; VA 0x00b43b61 ; Catch@00b43b61 */

undefined * Catch_00b43b61(void)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  int unaff_EBP;
  
  puVar1 = *(undefined4 **)(unaff_EBP + 0xc);
  cVar3 = FUN_00b46f70(puVar1,*(undefined4 *)(unaff_EBP + 0x10),unaff_EBP + -0x3c);
  if (cVar3 != '\0') {
    FUN_0061f5c0(unaff_EBP + -0x1c,(int)*(short *)(unaff_EBP + -0x22));
    puVar2 = *(undefined4 **)(unaff_EBP + 0x18);
    *puVar2 = *(undefined4 *)(unaff_EBP + -0x1c);
    puVar2[1] = *(undefined4 *)(unaff_EBP + -0x18);
    puVar2 = *(undefined4 **)(unaff_EBP + 8);
    *puVar2 = *puVar1;
    puVar2[1] = puVar1[1];
    return &DAT_00b43bb4;
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24063 ; VA 0x00b43c8a ; Catch@00b43c8a */

undefined * Catch_00b43c8a(void)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  int unaff_EBP;
  
  puVar1 = *(undefined4 **)(unaff_EBP + 0xc);
  cVar3 = FUN_00b46f70(puVar1,*(undefined4 *)(unaff_EBP + 0x10),unaff_EBP + -0x3c);
  if (cVar3 != '\0') {
    FUN_0061f5c0(unaff_EBP + -0x1c,(int)*(short *)(unaff_EBP + -0x22));
    puVar2 = *(undefined4 **)(unaff_EBP + 0x18);
    *puVar2 = *(undefined4 *)(unaff_EBP + -0x1c);
    puVar2[1] = *(undefined4 *)(unaff_EBP + -0x18);
    puVar2 = *(undefined4 **)(unaff_EBP + 8);
    *puVar2 = *puVar1;
    puVar2[1] = puVar1[1];
    return &DAT_00b43bb4;
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24064 ; VA 0x00b43cdd ; caseD_41 */

/* WARNING (jumptable): Unable to track spacebase fully for stack */

int * __fastcall switchD_00b43aae::caseD_41(char param_1)

{
  int *piVar1;
  byte *pbVar2;
  char cVar3;
  undefined uVar4;
  ushort uVar5;
  undefined2 *puVar6;
  int iVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 *puVar10;
  char *pcVar11;
  undefined2 extraout_var;
  undefined4 unaff_EBX;
  int unaff_EBP;
  short sVar12;
  char *unaff_ESI;
  int *unaff_EDI;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  
code_r0x00b43cdd:
  *(char *)(unaff_EBP + -0x4f) = param_1;
  pcVar11 = (char *)(unaff_EBP + -0x50);
  *(undefined *)(unaff_EBP + -0x50) = 0x25;
  *(undefined *)(unaff_EBP + -0x4e) = 0;
  *(undefined4 *)(unaff_EBP + -100) = 0;
  *(undefined4 *)(unaff_EBP + -0x60) = 0xf;
  *(undefined *)(unaff_EBP + -0x74) = 0;
  do {
    cVar3 = *pcVar11;
    pcVar11 = pcVar11 + 1;
  } while (cVar3 != '\0');
  FUN_005542c0(unaff_EBP + -0x50,(int)pcVar11 - (unaff_EBP + -0x4f));
  *(undefined4 *)(unaff_EBP + -4) = 0x1b;
  *(undefined2 *)(unaff_EBP + -0x24) = 0;
  *(undefined4 *)(unaff_EBP + -0x2c) = 0;
  *(undefined4 *)(unaff_EBP + -0x28) = 0xf;
  *(undefined *)(unaff_EBP + -0x3c) = 0;
  *(undefined2 *)(unaff_EBP + -0x22) = 0xffff;
  *(undefined *)(unaff_EBP + -4) = 0x1d;
  FUN_0054ef60(unaff_EBP + -0x74);
  FUN_00b47b40(unaff_EBP + -0x96,unaff_EDI,unaff_EBX);
  uVar4 = (undefined)*(undefined4 *)(unaff_EBP + -0x40);
  if ((uint)*(ushort *)(unaff_EBP + -0x24) < *(uint *)(unaff_EBP + -0x2c)) {
    uVar4 = 1;
  }
  *(undefined *)(unaff_EBP + -0x40) = uVar4;
LAB_00b43b45:
  FUN_005507b0();
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  FUN_005507b0();
switchD_00b43aae_caseD_43:
  puVar9 = *(undefined4 **)(unaff_EBP + -0x44);
  if (*(char *)(unaff_EBP + -0x1d) == '\0') {
    pcVar11 = unaff_ESI + 1;
    goto LAB_00b43a40;
  }
LAB_00b44209:
  *(undefined *)(unaff_EBP + -0x1d) = 0;
  pcVar11 = unaff_ESI;
LAB_00b43a40:
  while( true ) {
    puVar10 = puVar9;
    if (0xf < (uint)puVar9[5]) {
      puVar10 = (undefined4 *)*puVar9;
    }
    if ((pcVar11 == (char *)(puVar9[4] + (int)puVar10)) || (cVar3 = FUN_00a8d280(), cVar3 != '\0'))
    goto LAB_00b4427d;
    if (*pcVar11 == '%') break;
    pcVar11 = pcVar11 + 1;
    if (*(char *)(unaff_EBP + -0x40) == '\0') {
      piVar1 = (int *)*unaff_EDI;
      if (piVar1 == (int *)0x0) {
LAB_00b4426b:
        puVar9 = *(undefined4 **)(unaff_EBP + -0x44);
        *unaff_EDI = 0;
        *(undefined *)(unaff_EDI + 1) = 1;
      }
      else {
        if (*(int *)piVar1[7] == 0) {
LAB_00b44255:
          uVar8 = (**(code **)(*piVar1 + 0x1c))();
        }
        else {
          iVar7 = *(int *)piVar1[0xb];
          if (iVar7 < 1) goto LAB_00b44255;
          *(int *)piVar1[0xb] = iVar7 + -1;
          pbVar2 = *(byte **)piVar1[7];
          *(byte **)piVar1[7] = pbVar2 + 1;
          uVar8 = (uint)*pbVar2;
        }
        if (uVar8 == 0xffffffff) goto LAB_00b4426b;
        puVar9 = *(undefined4 **)(unaff_EBP + -0x44);
        *(undefined *)(unaff_EDI + 1) = 0;
      }
    }
    else {
      puVar9 = *(undefined4 **)(unaff_EBP + -0x44);
      *(undefined *)(unaff_EBP + -0x40) = 0;
    }
  }
  puVar9 = *(undefined4 **)(unaff_EBP + -0x44);
  unaff_ESI = pcVar11 + 1;
  puVar10 = puVar9;
  if (0xf < (uint)puVar9[5]) {
    puVar10 = (undefined4 *)*puVar9;
  }
  if (unaff_ESI == (char *)(puVar9[4] + (int)puVar10)) {
LAB_00b4427d:
    FUN_0056a9c0(0);
    sVar12 = (short)*(undefined4 *)(unaff_EBP + -0x58);
    if (sVar12 < 1) {
      puVar9 = (undefined4 *)
               FUN_0056a920(*(undefined4 *)(unaff_EBP + -0x5c),*(undefined4 *)(unaff_EBP + -0x7c),
                            *(undefined4 *)(unaff_EBP + -0x78));
    }
    else {
      uVar15 = CONCAT22(extraout_var,0x1f);
      uVar13 = 0xc;
      uVar14 = 0xc;
      FUN_0056ace0(*(int *)(unaff_EBP + -0x5c) + -1);
      FUN_0056a920(uVar13,uVar14,uVar15);
      *(int *)(unaff_EBP + 0x20) = (int)sVar12;
      puVar9 = (undefined4 *)FUN_00b3e0c0(unaff_EBP + 0xc,unaff_EBP + 0x20);
    }
    uVar13 = *puVar9;
    FUN_005ef640(*(undefined4 *)(unaff_EBP + -0x88),*(undefined4 *)(unaff_EBP + -0x84),
                 *(undefined4 *)(unaff_EBP + -0x80),*(undefined4 *)(unaff_EBP + -0x1c),
                 *(undefined4 *)(unaff_EBP + -0x18));
    *(undefined4 *)(unaff_EBP + -0x90) = *(undefined4 *)(unaff_EBP + -0x1c);
    *(undefined4 *)(unaff_EBP + -0x8c) = *(undefined4 *)(unaff_EBP + -0x18);
    *(undefined4 *)(unaff_EBP + 0x20) = uVar13;
    FUN_005672c0(unaff_EBP + 0x20,unaff_EBP + -0x90);
    puVar9 = *(undefined4 **)(unaff_EBP + 0x18);
    *puVar9 = *(undefined4 *)(unaff_EBP + -0x1c);
    puVar9[1] = *(undefined4 *)(unaff_EBP + -0x18);
    piVar1 = *(int **)(unaff_EBP + 8);
    *piVar1 = *unaff_EDI;
    piVar1[1] = unaff_EDI[1];
    ExceptionList = *(void **)(unaff_EBP + -0xc);
    return piVar1;
  }
  param_1 = *unaff_ESI;
  if (param_1 == '%') {
    piVar1 = (int *)*unaff_EDI;
    if (piVar1 != (int *)0x0) {
      if (*(int *)piVar1[7] == 0) {
LAB_00b441e6:
        uVar8 = (**(code **)(*piVar1 + 0x1c))();
      }
      else {
        iVar7 = *(int *)piVar1[0xb];
        if (iVar7 < 1) goto LAB_00b441e6;
        *(int *)piVar1[0xb] = iVar7 + -1;
        pbVar2 = *(byte **)piVar1[7];
        *(byte **)piVar1[7] = pbVar2 + 1;
        uVar8 = (uint)*pbVar2;
      }
      if (uVar8 != 0xffffffff) {
        *(undefined *)(unaff_EDI + 1) = 0;
        goto switchD_00b43aae_caseD_43;
      }
    }
    *unaff_EDI = 0;
    *(undefined *)(unaff_EDI + 1) = 1;
    goto switchD_00b43aae_caseD_43;
  }
  switch(param_1) {
  case 'A':
  case 'a':
  case 'w':
    goto code_r0x00b43cdd;
  case 'B':
  case 'b':
  case 'm':
    goto switchD_00b43aae_caseD_42;
  default:
    goto switchD_00b43aae_caseD_43;
  case 'F':
    cVar3 = FUN_00a8e710();
    if (cVar3 == '.') goto LAB_00b440bf;
    goto LAB_00b440d4;
  case 'H':
    *(undefined4 *)(unaff_EBP + -0x2c) = 0;
    *(undefined2 *)(unaff_EBP + -0x24) = 0;
    *(undefined4 *)(unaff_EBP + -0x28) = 0xf;
    *(undefined *)(unaff_EBP + -0x3c) = 0;
    *(undefined2 *)(unaff_EBP + -0x22) = 0xffff;
    *(undefined4 *)(unaff_EBP + -4) = 0x23;
    *(undefined *)(unaff_EBP + 0x17) = 0x30;
    iVar7 = FUN_00b37680();
    *(int *)(unaff_EBP + -0x88) = iVar7;
    if (iVar7 == -1) {
LAB_00b43f9d:
      piVar1 = *(int **)(unaff_EBP + 8);
      FUN_00b35da0(piVar1,unaff_EDI,unaff_EBX,*(undefined4 *)(unaff_EBP + 0x18),
                   *(undefined4 *)(unaff_EBP + -0x54));
      FUN_005507b0();
      ExceptionList = *(void **)(unaff_EBP + -0xc);
      return piVar1;
    }
    break;
  case 'M':
    *(undefined4 *)(unaff_EBP + -0x2c) = 0;
    *(undefined2 *)(unaff_EBP + -0x24) = 0;
    *(undefined4 *)(unaff_EBP + -0x28) = 0xf;
    *(undefined *)(unaff_EBP + -0x3c) = 0;
    *(undefined2 *)(unaff_EBP + -0x22) = 0xffff;
    *(undefined4 *)(unaff_EBP + -4) = 0x24;
    *(undefined *)(unaff_EBP + 0x17) = 0x30;
    iVar7 = FUN_00b37680();
    *(int *)(unaff_EBP + -0x84) = iVar7;
    if (iVar7 == -1) {
      piVar1 = *(int **)(unaff_EBP + 8);
      FUN_00b35da0(piVar1,unaff_EDI,unaff_EBX,*(undefined4 *)(unaff_EBP + 0x18),
                   *(undefined4 *)(unaff_EBP + -0x54));
      FUN_005507b0();
      ExceptionList = *(void **)(unaff_EBP + -0xc);
      return piVar1;
    }
    break;
  case 'S':
  case 's':
    *(undefined4 *)(unaff_EBP + -0x2c) = 0;
    *(undefined2 *)(unaff_EBP + -0x24) = 0;
    *(undefined4 *)(unaff_EBP + -0x28) = 0xf;
    *(undefined *)(unaff_EBP + -0x3c) = 0;
    *(undefined2 *)(unaff_EBP + -0x22) = 0xffff;
    *(undefined4 *)(unaff_EBP + -4) = 0x25;
    *(undefined *)(unaff_EBP + 0x17) = 0x30;
    iVar7 = FUN_00b37680();
    *(int *)(unaff_EBP + -0x80) = iVar7;
    if (iVar7 == -1) goto LAB_00b43f9d;
    cVar3 = *unaff_ESI;
    *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
    if (cVar3 != 'S') {
      FUN_005507b0();
      goto switchD_00b43aae_caseD_66;
    }
    FUN_005507b0();
    goto switchD_00b43aae_caseD_43;
  case 'Y':
  case 'y':
    goto switchD_00b43aae_caseD_59;
  case 'Z':
    if (*(char *)(unaff_EBP + 0x20) == '\0') goto LAB_00b440d4;
    unaff_ESI = pcVar11 + 2;
    if (*unaff_ESI == 'P') goto code_r0x00b44123;
    goto LAB_00b44209;
  case 'd':
    *(undefined4 *)(unaff_EBP + -4) = 0x20;
    puVar6 = (undefined2 *)FUN_00b47250(unaff_EBP + -0x9e,unaff_EDI,unaff_EBX);
    *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
    *(undefined2 *)(unaff_EBP + -0x78) = *puVar6;
    goto switchD_00b43aae_caseD_43;
  case 'f':
switchD_00b43aae_caseD_66:
    cVar3 = FUN_00a8e710();
    if (cVar3 != '.') {
      piVar1 = *(int **)(unaff_EBP + 8);
      FUN_00b35da0(piVar1,unaff_EDI,unaff_EBX,*(undefined4 *)(unaff_EBP + 0x18),
                   *(undefined4 *)(unaff_EBP + -0x54));
      ExceptionList = *(void **)(unaff_EBP + -0xc);
      return piVar1;
    }
LAB_00b440bf:
    FUN_00a8e760();
    FUN_00b473e0(unaff_EDI,unaff_EBX,unaff_EBP + -0x1c);
LAB_00b440d4:
    *(undefined *)(unaff_EBP + -0x40) = 1;
    goto switchD_00b43aae_caseD_43;
  case 'j':
    *(undefined4 *)(unaff_EBP + -0x2c) = 0;
    *(undefined2 *)(unaff_EBP + -0x24) = 0;
    *(undefined4 *)(unaff_EBP + -0x28) = 0xf;
    *(undefined *)(unaff_EBP + -0x3c) = 0;
    *(undefined2 *)(unaff_EBP + -0x22) = 0xffff;
    *(undefined4 *)(unaff_EBP + -4) = 0x1f;
    *(undefined *)(unaff_EBP + 0x17) = 0x30;
    uVar5 = FUN_00b37410();
    uVar8 = (uint)uVar5;
    *(uint *)(unaff_EBP + -0x58) = uVar8;
    if (uVar5 == 0xffff) {
      cVar3 = FUN_00b46f70(unaff_EDI,unaff_EBX,unaff_EBP + -0x3c);
      if (cVar3 != '\0') {
        FUN_0061f5c0(unaff_EBP + -0x1c,(int)*(short *)(unaff_EBP + -0x22));
        puVar9 = *(undefined4 **)(unaff_EBP + 0x18);
        piVar1 = *(int **)(unaff_EBP + 8);
        *puVar9 = *(undefined4 *)(unaff_EBP + -0x1c);
        puVar9[1] = *(undefined4 *)(unaff_EBP + -0x18);
        *piVar1 = *unaff_EDI;
        piVar1[1] = unaff_EDI[1];
        FUN_005507b0();
        ExceptionList = *(void **)(unaff_EBP + -0xc);
        return piVar1;
      }
      uVar8 = *(uint *)(unaff_EBP + -0x58);
    }
    FUN_00b39ac0(uVar8);
  }
  *(undefined4 *)(unaff_EBP + -4) = 0xffffffff;
  FUN_005507b0();
  goto switchD_00b43aae_caseD_43;
code_r0x00b44123:
  cVar3 = FUN_00a8d280();
  while (cVar3 == '\0') {
    cVar3 = FUN_00a8e710();
    iVar7 = FUN_0171dc29((int)cVar3);
    if (iVar7 == 0) break;
    FUN_00a8e760();
    cVar3 = FUN_00a8d280();
  }
  cVar3 = FUN_00a8d280();
  while (cVar3 == '\0') {
    cVar3 = FUN_00a8e710();
    iVar7 = FUN_0171dc29((int)cVar3);
    if (iVar7 != 0) break;
    uVar4 = FUN_00a8e710();
    *(undefined *)(unaff_EBP + -0x8c) = uVar4;
    FUN_005558a0(*(undefined4 *)(unaff_EBP + -0x8c));
    FUN_00a8e760();
    cVar3 = FUN_00a8d280();
  }
  goto switchD_00b43aae_caseD_43;
switchD_00b43aae_caseD_59:
  *(char *)(unaff_EBP + -0x47) = param_1;
  pcVar11 = (char *)(unaff_EBP + -0x48);
  *(undefined *)(unaff_EBP + -0x48) = 0x25;
  *(undefined *)(unaff_EBP + -0x46) = 0;
  *(undefined4 *)(unaff_EBP + -100) = 0;
  *(undefined4 *)(unaff_EBP + -0x60) = 0xf;
  *(undefined *)(unaff_EBP + -0x74) = 0;
  do {
    cVar3 = *pcVar11;
    pcVar11 = pcVar11 + 1;
  } while (cVar3 != '\0');
  FUN_005542c0(unaff_EBP + -0x48,(int)pcVar11 - (unaff_EBP + -0x47));
  *(undefined4 *)(unaff_EBP + -4) = 0x13;
  *(undefined2 *)(unaff_EBP + -0x24) = 0;
  *(undefined4 *)(unaff_EBP + -0x2c) = 0;
  *(undefined4 *)(unaff_EBP + -0x28) = 0xf;
  *(undefined *)(unaff_EBP + -0x3c) = 0;
  *(undefined2 *)(unaff_EBP + -0x22) = 0xffff;
  *(undefined *)(unaff_EBP + -4) = 0x15;
  FUN_0054ef60(unaff_EBP + -0x74);
  puVar6 = (undefined2 *)FUN_00b48070(unaff_EBP + -0x92,unaff_EDI,unaff_EBX);
  *(undefined2 *)(unaff_EBP + -0x5c) = *puVar6;
  goto LAB_00b43b45;
switchD_00b43aae_caseD_42:
  *(char *)(unaff_EBP + -0x4b) = param_1;
  pcVar11 = (char *)(unaff_EBP + -0x4c);
  *(undefined *)(unaff_EBP + -0x4c) = 0x25;
  *(undefined *)(unaff_EBP + -0x4a) = 0;
  *(undefined4 *)(unaff_EBP + -100) = 0;
  *(undefined4 *)(unaff_EBP + -0x60) = 0xf;
  *(undefined *)(unaff_EBP + -0x74) = 0;
  do {
    cVar3 = *pcVar11;
    pcVar11 = pcVar11 + 1;
  } while (cVar3 != '\0');
  FUN_005542c0(unaff_EBP + -0x4c,(int)pcVar11 - (unaff_EBP + -0x4b));
  *(undefined4 *)(unaff_EBP + -4) = 0x17;
  *(undefined2 *)(unaff_EBP + -0x24) = 0;
  *(undefined4 *)(unaff_EBP + -0x2c) = 0;
  *(undefined4 *)(unaff_EBP + -0x28) = 0xf;
  *(undefined *)(unaff_EBP + -0x3c) = 0;
  *(undefined2 *)(unaff_EBP + -0x22) = 0xffff;
  *(undefined *)(unaff_EBP + -4) = 0x19;
  FUN_0054ef60(unaff_EBP + -0x74);
  puVar6 = (undefined2 *)FUN_00b47610(unaff_EBP + -0x94,unaff_EDI,unaff_EBX);
  uVar8 = *(uint *)(unaff_EBP + -0x40) & 0xff;
  *(undefined2 *)(unaff_EBP + -0x7c) = *puVar6;
  if ((uint)*(ushort *)(unaff_EBP + -0x24) < *(uint *)(unaff_EBP + -0x2c)) {
    uVar8 = 1;
  }
  *(uint *)(unaff_EBP + -0x40) = uVar8;
  goto LAB_00b43b45;
}



/* FUNCTION 24065 ; VA 0x00b43d83 ; Catch@00b43d83 */

undefined * Catch_00b43d83(void)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  int unaff_EBP;
  
  puVar1 = *(undefined4 **)(unaff_EBP + 0xc);
  cVar3 = FUN_00b46f70(puVar1,*(undefined4 *)(unaff_EBP + 0x10),unaff_EBP + -0x3c);
  if (cVar3 != '\0') {
    FUN_0061f5c0(unaff_EBP + -0x1c,(int)*(short *)(unaff_EBP + -0x22));
    puVar2 = *(undefined4 **)(unaff_EBP + 0x18);
    *puVar2 = *(undefined4 *)(unaff_EBP + -0x1c);
    puVar2[1] = *(undefined4 *)(unaff_EBP + -0x18);
    puVar2 = *(undefined4 **)(unaff_EBP + 8);
    *puVar2 = *puVar1;
    puVar2[1] = puVar1[1];
    return &DAT_00b43bb4;
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24066 ; VA 0x00b43ed2 ; Catch@00b43ed2 */

undefined * Catch_00b43ed2(void)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  int unaff_EBP;
  
  *(undefined4 *)(unaff_EBP + -0x2c) = 0;
  *(undefined2 *)(unaff_EBP + -0x24) = 0;
  *(undefined4 *)(unaff_EBP + -0x28) = 0xf;
  *(undefined *)(unaff_EBP + -0x3c) = 0;
  *(undefined2 *)(unaff_EBP + -0x22) = 0xffff;
  puVar1 = *(undefined4 **)(unaff_EBP + 0xc);
  *(undefined *)(unaff_EBP + -4) = 0x22;
  cVar3 = FUN_00b46f70(puVar1,*(undefined4 *)(unaff_EBP + 0x10),unaff_EBP + -0x3c);
  if (cVar3 != '\0') {
    FUN_0061f5c0(unaff_EBP + -0x1c,(int)*(short *)(unaff_EBP + -0x22));
    puVar2 = *(undefined4 **)(unaff_EBP + 0x18);
    *puVar2 = *(undefined4 *)(unaff_EBP + -0x1c);
    puVar2[1] = *(undefined4 *)(unaff_EBP + -0x18);
    puVar2 = *(undefined4 **)(unaff_EBP + 8);
    *puVar2 = *puVar1;
    puVar2[1] = puVar1[1];
    FUN_005507b0();
    return &LAB_00b43bc4;
  }
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24067 ; VA 0x00b443d0 ; FUN_00b443d0 */

uint * FUN_00b443d0(uint *param_1,int param_2,int param_3,int *param_4)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 *puVar6;
  uint *puVar7;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint uStack_28;
  uint uStack_24;
  uint uStack_20;
  uint uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2ec0;
  pvStack_10 = ExceptionList;
  uStack_30 = 0;
  uStack_2c = 0xf;
  uStack_40 = uStack_40 & 0xffffff00;
  ExceptionList = &pvStack_10;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 0;
  uStack_18 = 0;
  uStack_14 = 0xf;
  uStack_28 = uStack_28 & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_8 = 1;
  puVar2 = (undefined4 *)*param_4;
  puVar3 = (undefined4 *)*puVar2;
  uVar5 = uStack_40;
  while ((puVar3 != puVar2 && ((int)puVar3[4] <= param_2 * 100 + param_3))) {
    puVar7 = puVar3 + 5;
    uStack_40 = uVar5;
    if (&uStack_40 != puVar7) {
      if (0xf < (uint)puVar3[10]) {
        puVar7 = (uint *)*puVar7;
      }
      FUN_005542c0(puVar7,puVar3[9]);
    }
    puVar7 = puVar3 + 0xb;
    if (&uStack_28 != puVar7) {
      if (0xf < (uint)puVar3[0x10]) {
        puVar7 = (uint *)*puVar7;
      }
      FUN_005542c0(puVar7,puVar3[0xf]);
    }
    puVar4 = (undefined4 *)puVar3[2];
    uVar5 = uStack_40;
    if (*(char *)((int)puVar4 + 0xd) == '\0') {
      cVar1 = *(char *)((int)*puVar4 + 0xd);
      puVar3 = puVar4;
      puVar4 = (undefined4 *)*puVar4;
      while (cVar1 == '\0') {
        cVar1 = *(char *)((int)*puVar4 + 0xd);
        puVar3 = puVar4;
        puVar4 = (undefined4 *)*puVar4;
      }
    }
    else {
      cVar1 = *(char *)((int)puVar3[1] + 0xd);
      puVar6 = (undefined4 *)puVar3[1];
      puVar4 = puVar3;
      while ((puVar3 = puVar6, cVar1 == '\0' && (puVar4 == (undefined4 *)puVar3[2]))) {
        cVar1 = *(char *)((int)puVar3[1] + 0xd);
        puVar6 = (undefined4 *)puVar3[1];
        puVar4 = puVar3;
      }
    }
  }
  uStack_40 = uVar5 & 0xffffff00;
  param_1[4] = 0;
  param_1[5] = 0;
  *param_1 = uVar5;
  param_1[1] = uStack_3c;
  param_1[2] = uStack_38;
  param_1[3] = uStack_34;
  *(ulonglong *)(param_1 + 4) = CONCAT44(uStack_2c,uStack_30);
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[6] = uStack_28;
  param_1[7] = uStack_24;
  param_1[8] = uStack_20;
  param_1[9] = uStack_1c;
  uStack_30 = 0;
  uStack_2c = 0xf;
  *(ulonglong *)(param_1 + 10) = CONCAT44(uStack_14,uStack_18);
  uStack_18 = 0;
  uStack_14 = 0xf;
  uStack_28 = uStack_28 & 0xffffff00;
  FUN_005509f0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24068 ; VA 0x00b44580 ; FUN_00b44580 */

int * __thiscall FUN_00b44580(undefined4 *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 uVar7;
  int *piVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  double dVar12;
  undefined8 uVar13;
  uint auStack_44 [4];
  undefined4 uStack_34;
  uint uStack_30;
  int *piStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  ushort uStack_1c;
  ushort uStack_1a;
  ushort uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2f10;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  piVar1 = (int *)FUN_01674e20(0x24);
  piStack_14 = piVar1;
  if (piVar1 == (int *)0x0) {
    piVar1 = (int *)0x0;
  }
  else {
    piVar1[1] = 1;
    piVar1[2] = 1;
    *piVar1 = (int)std::
                   _Ref_count_obj<class_boost::unordered::unordered_map<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>,class_RBX::Reflection::Variant,struct_boost::hash<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,struct_std::equal_to<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_>,class_std::allocator<struct_std::pair<class_std::basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>_const_,class_RBX::Reflection::Variant>_>_>_>
                   ::vftable;
    *(undefined *)(piVar1 + 3) = 0;
    iVar2 = FUN_00588320(0xb);
    piVar1[4] = iVar2;
    piVar1[5] = 0;
    piVar1[6] = 0x3f800000;
    piVar1[7] = 0;
    piVar1[8] = 0;
  }
  piStack_2c = piVar1 + 3;
  uStack_8 = 0;
  if (param_3 != 0) {
    param_1 = param_1 + 2;
  }
  uStack_24 = *param_1;
  uStack_20 = param_1[1];
  piStack_28 = piVar1;
  FUN_00b483a0(&uStack_24);
  puVar3 = (undefined4 *)FUN_00b41a70(&piStack_14);
  FUN_00b43600(&uStack_1c,*puVar3);
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  FUN_005542c0(&DAT_019521f8,4);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  iVar4 = FUN_005c4c00(auStack_44);
  uVar5 = FUN_0088c8c0();
  *(undefined4 *)(iVar4 + 0x18) = uVar5;
  iVar6 = FUN_005c9cc0();
  iVar2 = *(int *)(iVar4 + 0x1c);
  if (iVar2 == iVar6) {
    *(uint *)(iVar4 + 0x20) = (uint)uStack_1c;
  }
  else {
    if (iVar2 != 0) {
      (**(code **)(iVar2 + 8))(iVar4 + 0x20);
    }
    *(uint *)(iVar4 + 0x20) = (uint)uStack_1c;
    *(int *)(iVar4 + 0x1c) = iVar6;
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_30) {
    uVar11 = uStack_30 + 1;
    uVar10 = auStack_44[0];
    if (0xfff < uVar11) {
      uVar10 = *(uint *)(auStack_44[0] - 4);
      uVar11 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar11);
  }
  puVar3 = (undefined4 *)FUN_00b41a70(&piStack_14);
  FUN_00b43600(&uStack_1c,*puVar3);
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  FUN_005542c0("Month",5);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  iVar4 = FUN_005c4c00(auStack_44);
  uVar5 = FUN_0088c8c0();
  *(undefined4 *)(iVar4 + 0x18) = uVar5;
  iVar6 = FUN_005c9cc0();
  iVar2 = *(int *)(iVar4 + 0x1c);
  if (iVar2 == iVar6) {
    *(uint *)(iVar4 + 0x20) = (uint)uStack_1a;
  }
  else {
    if (iVar2 != 0) {
      (**(code **)(iVar2 + 8))(iVar4 + 0x20);
    }
    *(uint *)(iVar4 + 0x20) = (uint)uStack_1a;
    *(int *)(iVar4 + 0x1c) = iVar6;
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_30) {
    uVar11 = uStack_30 + 1;
    uVar10 = auStack_44[0];
    if (0xfff < uVar11) {
      uVar10 = *(uint *)(auStack_44[0] - 4);
      uVar11 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar11);
  }
  puVar3 = (undefined4 *)FUN_00b41a70(&piStack_14);
  FUN_00b43600(&uStack_1c,*puVar3);
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  FUN_005542c0(&DAT_01952208,3);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  iVar4 = FUN_005c4c00(auStack_44);
  uVar5 = FUN_0088c8c0();
  *(undefined4 *)(iVar4 + 0x18) = uVar5;
  iVar6 = FUN_005c9cc0();
  iVar2 = *(int *)(iVar4 + 0x1c);
  if (iVar2 == iVar6) {
    *(uint *)(iVar4 + 0x20) = (uint)uStack_18;
  }
  else {
    if (iVar2 != 0) {
      (**(code **)(iVar2 + 8))(iVar4 + 0x20);
    }
    *(uint *)(iVar4 + 0x20) = (uint)uStack_18;
    *(int *)(iVar4 + 0x1c) = iVar6;
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_30) {
    uVar11 = uStack_30 + 1;
    uVar10 = auStack_44[0];
    if (0xfff < uVar11) {
      uVar10 = *(uint *)(auStack_44[0] - 4);
      uVar11 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar11);
  }
  puVar3 = (undefined4 *)FUN_00b4a230(&uStack_1c);
  uVar5 = FUN_016f3900(*puVar3,puVar3[1],3600000000,0);
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  FUN_005542c0(&DAT_0195220c,4);
  uStack_8 = CONCAT31(uStack_8._1_3_,4);
  iVar4 = FUN_005c4c00(auStack_44);
  uVar7 = FUN_0088c8c0();
  *(undefined4 *)(iVar4 + 0x18) = uVar7;
  iVar6 = FUN_005c9cc0();
  iVar2 = *(int *)(iVar4 + 0x1c);
  if (iVar2 == iVar6) {
    *(undefined4 *)(iVar4 + 0x20) = uVar5;
  }
  else {
    if (iVar2 != 0) {
      (**(code **)(iVar2 + 8))(iVar4 + 0x20);
    }
    *(undefined4 *)(iVar4 + 0x20) = uVar5;
    *(int *)(iVar4 + 0x1c) = iVar6;
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_30) {
    uVar11 = uStack_30 + 1;
    uVar10 = auStack_44[0];
    if (0xfff < uVar11) {
      uVar10 = *(uint *)(auStack_44[0] - 4);
      uVar11 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar11);
  }
  puVar3 = (undefined4 *)FUN_00b4a230(&uStack_1c);
  uVar13 = FUN_016f3900(*puVar3,puVar3[1],60000000,0);
  uVar5 = FUN_016f4270(uVar13,0x3c,0);
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  FUN_005542c0("Minute",6);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  iVar4 = FUN_005c4c00(auStack_44);
  uVar7 = FUN_0088c8c0();
  *(undefined4 *)(iVar4 + 0x18) = uVar7;
  iVar6 = FUN_005c9cc0();
  iVar2 = *(int *)(iVar4 + 0x1c);
  if (iVar2 == iVar6) {
    *(undefined4 *)(iVar4 + 0x20) = uVar5;
  }
  else {
    if (iVar2 != 0) {
      (**(code **)(iVar2 + 8))(iVar4 + 0x20);
    }
    *(undefined4 *)(iVar4 + 0x20) = uVar5;
    *(int *)(iVar4 + 0x1c) = iVar6;
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_30) {
    uVar11 = uStack_30 + 1;
    uVar10 = auStack_44[0];
    if (0xfff < uVar11) {
      uVar10 = *(uint *)(auStack_44[0] - 4);
      uVar11 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar11);
  }
  puVar3 = (undefined4 *)FUN_00b4a230(&uStack_1c);
  uVar13 = FUN_016f3900(*puVar3,puVar3[1],1000000,0);
  uVar5 = FUN_016f4270(uVar13,0x3c,0);
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  FUN_005542c0("Second",6);
  uStack_8 = CONCAT31(uStack_8._1_3_,6);
  iVar4 = FUN_005c4c00(auStack_44);
  uVar7 = FUN_0088c8c0();
  *(undefined4 *)(iVar4 + 0x18) = uVar7;
  iVar6 = FUN_005c9cc0();
  iVar2 = *(int *)(iVar4 + 0x1c);
  if (iVar2 == iVar6) {
    *(undefined4 *)(iVar4 + 0x20) = uVar5;
  }
  else {
    if (iVar2 != 0) {
      (**(code **)(iVar2 + 8))(iVar4 + 0x20);
    }
    *(undefined4 *)(iVar4 + 0x20) = uVar5;
    *(int *)(iVar4 + 0x1c) = iVar6;
  }
  uStack_8 = uStack_8 & 0xffffff00;
  if (0xf < uStack_30) {
    uVar11 = uStack_30 + 1;
    uVar10 = auStack_44[0];
    if (0xfff < uVar11) {
      uVar10 = *(uint *)(auStack_44[0] - 4);
      uVar11 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar11);
  }
  FUN_00b4a230(&uStack_1c);
  piVar8 = (int *)FUN_00b4a230(&uStack_1c);
  iVar2 = *piVar8;
  iVar4 = FUN_016f3900(iVar2,piVar8[1],1000000,0);
  iVar2 = iVar2 + iVar4 * -1000000;
  if (iVar2 < 1) {
    iVar2 = 0;
  }
  else {
    dVar12 = DAT_018d8a10;
    FUN_01726ab0();
    iVar2 = (int)((double)iVar2 / dVar12);
  }
  uStack_34 = 0;
  uStack_30 = 0xf;
  auStack_44[0] = auStack_44[0] & 0xffffff00;
  FUN_005542c0("Millisecond",0xb);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  iVar6 = FUN_005c4c00(auStack_44);
  uVar5 = FUN_0088c8c0();
  *(undefined4 *)(iVar6 + 0x18) = uVar5;
  iVar9 = FUN_005c9cc0();
  iVar4 = *(int *)(iVar6 + 0x1c);
  if (iVar4 == iVar9) {
    *(int *)(iVar6 + 0x20) = iVar2;
  }
  else {
    if (iVar4 != 0) {
      (**(code **)(iVar4 + 8))(iVar6 + 0x20);
    }
    *(int *)(iVar6 + 0x20) = iVar2;
    *(int *)(iVar6 + 0x1c) = iVar9;
  }
  if (0xf < uStack_30) {
    uVar11 = uStack_30 + 1;
    uVar10 = auStack_44[0];
    if (0xfff < uVar11) {
      uVar10 = *(uint *)(auStack_44[0] - 4);
      uVar11 = uStack_30 + 0x24;
      if (0x1f < (auStack_44[0] - uVar10) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar10,uVar11);
  }
  piVar8 = piVar1 + 1;
  *param_2 = 0;
  param_2[1] = 0;
  if (piVar1 != (int *)0x0) {
    LOCK();
    *piVar8 = *piVar8 + 1;
    UNLOCK();
  }
  param_2[1] = (int)piVar1;
  *param_2 = (int)(piVar1 + 3);
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar2 = *piVar8;
    *piVar8 = iVar2 + -1;
    UNLOCK();
    if (iVar2 + -1 == 0) {
      (**(code **)*piVar1)();
      LOCK();
      piVar8 = piVar1 + 2;
      iVar2 = *piVar8;
      *piVar8 = *piVar8 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*piVar1 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24069 ; VA 0x00b44c30 ; FUN_00b44c30 */

/* WARNING: Type propagation algorithm not settling */

undefined * FUN_00b44c30(undefined *param_1,undefined4 *param_2,uint param_3)

{
  int *piVar1;
  code *pcVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  char cVar5;
  undefined4 *puVar6;
  int *piVar7;
  uint uVar8;
  undefined4 *puVar9;
  undefined4 *******pppppppuVar10;
  undefined *puVar11;
  uint uVar12;
  undefined4 *******apppppppuStack_30 [4];
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *******pppppppuStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puVar3 = DAT_01eee638;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017961a8;
  puVar6 = param_2;
  if (0xf < (uint)param_2[5]) {
    puVar6 = (undefined4 *)*param_2;
  }
  cStack_11 = *(char *)((int)puVar6 + param_3);
  puVar6 = (undefined4 *)*DAT_01eee638;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  do {
    if (puVar6 == puVar3) {
      *(undefined4 *)(param_1 + 0x10) = 0;
      *(undefined4 *)(param_1 + 0x14) = 0xf;
      *param_1 = 0;
      FUN_005542c0(&DAT_018bc9b8,0);
      ExceptionList = pvStack_10;
      return param_1;
    }
    piVar1 = puVar6 + 4;
    piVar7 = piVar1;
    if (0xf < (uint)puVar6[9]) {
      piVar7 = (int *)*piVar1;
    }
    if (cStack_11 == *(char *)piVar7) {
      uStack_20 = 0;
      uStack_1c = 0xf;
      apppppppuStack_30[0] = (undefined4 *******)((uint)apppppppuStack_30[0] & 0xffffff00);
      if ((uint)param_2[4] < param_3) {
        FUN_00554050();
        pcVar2 = (code *)swi(3);
        puVar11 = (undefined *)(*pcVar2)();
        return puVar11;
      }
      uVar8 = param_2[4] - param_3;
      uVar12 = puVar6[8];
      if (uVar8 < (uint)puVar6[8]) {
        uVar12 = uVar8;
      }
      puVar9 = param_2;
      if (0xf < (uint)param_2[5]) {
        puVar9 = (undefined4 *)*param_2;
      }
      FUN_005542c0((int)puVar9 + param_3,uVar12);
      uStack_8 = 0;
      piVar7 = piVar1;
      if (0xf < (uint)puVar6[9]) {
        piVar7 = (int *)*piVar1;
      }
      pppppppuVar10 = apppppppuStack_30;
      if (0xf < uStack_1c) {
        pppppppuVar10 = apppppppuStack_30[0];
      }
      pppppppuStack_18 = apppppppuStack_30[0];
      cVar5 = FUN_0055c360(pppppppuVar10,uStack_20,piVar7,puVar6[8]);
      if (cVar5 != '\0') {
        FUN_0054ef60(piVar1);
        if (uStack_1c < 0x10) {
          ExceptionList = pvStack_10;
          return param_1;
        }
        uVar12 = uStack_1c + 1;
        pppppppuVar10 = pppppppuStack_18;
        if (0xfff < uVar12) {
          pppppppuVar10 = (undefined4 *******)pppppppuStack_18[-1];
          uVar12 = uStack_1c + 0x24;
          if (0x1f < (uint)((int)pppppppuStack_18 + (-4 - (int)pppppppuVar10))) {
LAB_00b44e0f:
                    /* WARNING: Subroutine does not return */
            FUN_017167a3();
          }
        }
        FUN_01674ea0(pppppppuVar10,uVar12);
        ExceptionList = pvStack_10;
        return param_1;
      }
      uStack_8 = 0xffffffff;
      if (0xf < uStack_1c) {
        uVar12 = uStack_1c + 1;
        pppppppuVar10 = pppppppuStack_18;
        if (0xfff < uVar12) {
          pppppppuVar10 = (undefined4 *******)pppppppuStack_18[-1];
          uVar12 = uStack_1c + 0x24;
          if (0x1f < (uint)((int)pppppppuStack_18 + (-4 - (int)pppppppuVar10))) goto LAB_00b44e0f;
        }
        FUN_01674ea0(pppppppuVar10,uVar12);
      }
    }
    puVar9 = (undefined4 *)puVar6[2];
    if (*(char *)((int)puVar9 + 0xd) == '\0') {
      cVar5 = *(char *)((int)*puVar9 + 0xd);
      puVar6 = puVar9;
      puVar9 = (undefined4 *)*puVar9;
      while (cVar5 == '\0') {
        cVar5 = *(char *)((int)*puVar9 + 0xd);
        puVar6 = puVar9;
        puVar9 = (undefined4 *)*puVar9;
      }
    }
    else {
      cVar5 = *(char *)((int)puVar6[1] + 0xd);
      puVar4 = (undefined4 *)puVar6[1];
      puVar9 = puVar6;
      while ((puVar6 = puVar4, cVar5 == '\0' && (puVar9 == (undefined4 *)puVar6[2]))) {
        cVar5 = *(char *)((int)puVar6[1] + 0xd);
        puVar4 = (undefined4 *)puVar6[1];
        puVar9 = puVar6;
      }
    }
  } while( true );
}



/* FUNCTION 24070 ; VA 0x00b44e20 ; FUN_00b44e20 */

longlong * FUN_00b44e20(longlong *param_1,longlong param_2)

{
  uint uVar1;
  undefined4 *puVar2;
  int iVar3;
  uint *puVar4;
  int *piVar5;
  longlong lVar6;
  undefined8 uStack_14;
  undefined auStack_c [8];
  
  uVar1 = (uint)param_2;
  if ((int)param_2._4_4_ < 1) {
    if ((((param_2 < 0) || ((uint)param_2 < 0x7fe81781)) && (-2 < (int)param_2._4_4_)) &&
       ((param_2._4_4_ < 0x80000000 || (0x8017e87f < (uint)param_2)))) {
      puVar2 = (undefined4 *)FUN_0056a920();
      param_2 = CONCAT44(*puVar2,(uint)param_2);
      lVar6 = FUN_016f39b0(0,1000000,0);
      uStack_14 = lVar6;
      FUN_005672c0((int)&param_2 + 4,&uStack_14);
      if ((int)uVar1 < 0) {
        lVar6 = (longlong)(int)((uVar1 ^ (int)uVar1 >> 0x1f) - ((int)uVar1 >> 0x1f)) * 1000000 +
                lVar6;
        iVar3 = (int)lVar6;
        param_2 = CONCAT44(-((int)((ulonglong)lVar6 >> 0x20) + (uint)(iVar3 != 0)),-iVar3);
      }
      else {
        param_2 = (longlong)(int)uVar1 * 1000000 + lVar6;
      }
      FUN_00b3e000(&uStack_14,&param_2);
      *param_1 = uStack_14;
      return param_1;
    }
    if ((param_2 < 0) || (((int)param_2._4_4_ < 1 && ((uint)param_2 == 0)))) {
      puVar4 = (uint *)FUN_00b44e20();
      param_2 = FUN_016f39b0(0,1000000,0);
      param_2 = param_2 + 0x79fb33094e000;
      uVar1 = puVar4[1];
      uStack_14._0_4_ = *puVar4;
      if ((((uint)uStack_14 != 0) || (uVar1 != 0x80000000)) &&
         (((((uint)uStack_14 != 0xffffffff || (uVar1 != 0x7fffffff)) &&
           (((uint)uStack_14 != 0xfffffffe || (uVar1 != 0x7fffffff)))) &&
          (((param_2 != -0x8000000000000000 && (param_2 != 0x7fffffffffffffff)) &&
           (param_2 != 0x7ffffffffffffffe)))))) {
        *(uint *)((int)param_1 + 4) =
             (uVar1 - (int)((ulonglong)param_2 >> 0x20)) - (uint)((uint)uStack_14 < (uint)param_2);
        *(uint *)param_1 = (uint)uStack_14 - (uint)param_2;
        return param_1;
      }
      uStack_14._4_4_ = puVar4[1];
      piVar5 = (int *)FUN_00602640(auStack_c,&param_2);
      iVar3 = piVar5[1];
      *(int *)param_1 = *piVar5;
      *(int *)((int)param_1 + 4) = iVar3;
      return param_1;
    }
  }
  FUN_00b44e20();
  param_2 = FUN_016f39b0(0,1000000,0);
  param_2 = param_2 + 0x79fb33094e000;
  FUN_00b3e000(param_1,&param_2);
  return param_1;
}



/* FUNCTION 24071 ; VA 0x00b45090 ; FUN_00b45090 */

void FUN_00b45090(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  uStack_c = param_3;
  uStack_8 = param_4;
  iVar1 = FUN_017243ef(param_1,&uStack_c);
  if (iVar1 == 0) {
    iVar1 = FUN_017246b2(param_2,&uStack_c);
    if (iVar1 == 0) {
      return;
    }
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Error interpreting timestamp as a date/time (%lld)\n",param_3,param_4);
}



/* FUNCTION 24072 ; VA 0x00b450e0 ; FUN_00b450e0 */

undefined *
FUN_00b450e0(undefined *param_1,undefined4 param_2,undefined4 *param_3,undefined *param_4)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  ushort *puVar4;
  undefined *puVar5;
  int iVar6;
  uint uVar7;
  bool bVar8;
  double in_XMM0_Qa;
  double dVar9;
  undefined8 uVar10;
  undefined auStack_198 [4];
  ushort uStack_194;
  ushort auStack_190 [50];
  undefined auStack_12c [40];
  uint uStack_104;
  uint uStack_100;
  int iStack_fc;
  int iStack_f8;
  int iStack_f0;
  int iStack_ec;
  int iStack_e4;
  int iStack_e0;
  int iStack_d8;
  int iStack_d4;
  int iStack_cc;
  int iStack_c8;
  undefined4 *puStack_bc;
  undefined auStack_a0 [4];
  int iStack_9c;
  undefined auStack_78 [2];
  ushort uStack_76;
  undefined8 uStack_70;
  undefined auStack_66 [2];
  uint uStack_64;
  uint uStack_60;
  uint uStack_5c;
  undefined auStack_58 [24];
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f300e;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar3 = FUN_00fc4ed0(param_4);
  FUN_00b3c6c0(uVar3);
  uStack_8 = 0;
  uStack_18 = 0;
  uStack_14 = 0xf;
  auStack_28[0] = 0;
  FUN_005542c0("en-us",5);
  uStack_8._0_1_ = 1;
  uVar3 = FUN_00fc4ed0(auStack_28);
  FUN_00b3c6c0(uVar3);
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_00b41a70(&uStack_60);
  FUN_00b4a230(&uStack_70);
  FUN_00b43600(auStack_190,uStack_60);
  FUN_00b43600(auStack_78,uStack_60);
  FUN_00b43600(auStack_198,uStack_60);
  puVar4 = (ushort *)FUN_00b41c10(auStack_66);
  uStack_100 = (uint)*puVar4;
  puVar4 = (ushort *)FUN_00b41b40(auStack_66);
  uVar2 = uStack_70._4_4_;
  uVar3 = (uint)uStack_70;
  uStack_60 = (uint)*puVar4;
  uStack_5c = FUN_016f3900((uint)uStack_70,uStack_70._4_4_,3600000000,0);
  uVar10 = FUN_016f3900(uVar3,uVar2,60000000,0);
  uStack_64 = FUN_016f4270(uVar10,0x3c,0);
  uVar10 = FUN_016f3900(uVar3,uVar2,1000000,0);
  uStack_104 = FUN_016f4270(uVar10,0x3c,0);
  uVar10 = FUN_016f39b0(uVar10,1000000,0);
  iVar6 = (int)((ulonglong)uVar10 >> 0x20);
  uVar7 = (uint)((uint)uStack_70 < (uint)uVar10);
  uVar1 = uStack_70._4_4_ - iVar6;
  bVar8 = (int)(uVar1 - uVar7) < 0;
  if ((bVar8) ||
     ((uVar1 == uVar7 || (SBORROW4(uStack_70._4_4_,iVar6) != SBORROW4(uVar1,uVar7)) != bVar8 &&
      ((uint)uStack_70 == (uint)uVar10)))) {
    iVar6 = 0;
  }
  else {
    FUN_016f4020();
    dVar9 = DAT_018d8a10;
    uStack_70 = in_XMM0_Qa;
    FUN_01726ab0();
    iVar6 = (int)(uStack_70 / dVar9);
  }
  switch(*param_3) {
  case 0:
    FUN_01675640(param_1,&DAT_019522b4,auStack_190[0]);
    goto LAB_00b45a5f;
  case 1:
    uVar7 = (uint)auStack_190[0] % 100;
    goto LAB_00b452b6;
  case 2:
    if ((uStack_76 != 0) &&
       (iStack_f0 = iStack_fc, (uint)uStack_76 <= (uint)((iStack_f8 - iStack_fc) / 0x18)))
    goto LAB_00b452fb;
    uVar7 = (uint)uStack_76;
    goto LAB_00b452b6;
  case 3:
    if ((uStack_76 == 0) || ((uint)((iStack_ec - iStack_f0) / 0x18) < (uint)uStack_76)) {
      FUN_01675640(param_1,&DAT_018bed68,uStack_76);
      goto LAB_00b45a5f;
    }
LAB_00b452fb:
    FUN_0054ef60(iStack_f0 + (uStack_76 - 1) * 0x18);
    goto LAB_00b4530d;
  case 4:
    uVar7 = (uint)uStack_76;
    goto LAB_00b452b6;
  case 5:
    FUN_01675640(param_1,&DAT_018bed68,uStack_76);
    goto LAB_00b45a5f;
  case 6:
    FUN_01675640(param_1,&DAT_019522c4,uStack_100 & 0xffff);
    goto LAB_00b45a5f;
  case 7:
    FUN_01675640(param_1,&DAT_018bed68,uStack_100 & 0xffff);
    goto LAB_00b45a5f;
  case 8:
    uVar7 = (uint)uStack_194;
    goto LAB_00b452b6;
  case 9:
    FUN_01675640(param_1,&DAT_018bed68,uStack_194);
    goto LAB_00b45a5f;
  case 10:
    iStack_c8 = iStack_e0;
    iStack_cc = iStack_e4;
    goto LAB_00b4542d;
  case 0xb:
    iStack_c8 = iStack_d4;
    iStack_cc = iStack_d8;
    goto LAB_00b4542d;
  case 0xc:
LAB_00b4542d:
    uVar7 = uStack_60 & 0xffff;
    if (uVar7 < (uint)((iStack_c8 - iStack_cc) / 0x18)) {
      FUN_0054ef60(iStack_cc + uVar7 * 0x18);
      FUN_00b3da90();
      FUN_005507b0();
      FUN_00b3da90();
      ExceptionList = pvStack_10;
      return param_1;
    }
    goto LAB_00b4544b;
  case 0xd:
    uVar7 = uStack_60 & 0xffff;
    goto LAB_00b4544b;
  case 0xe:
    uVar7 = uStack_5c;
    goto LAB_00b452b6;
  case 0xf:
    uVar7 = uStack_5c;
    goto LAB_00b4544b;
  case 0x10:
    uVar7 = (int)(uStack_5c + 0xb) % 0xc + 1;
    goto LAB_00b452b6;
  case 0x11:
    uVar7 = (int)(uStack_5c + 0xb) % 0xc + 1;
    goto LAB_00b4544b;
  case 0x12:
    uVar7 = uStack_64;
    goto LAB_00b452b6;
  case 0x13:
    uVar7 = uStack_64;
    goto LAB_00b4544b;
  case 0x14:
    FUN_01675640(param_1,&DAT_019522c4,iVar6);
    goto LAB_00b45a5f;
  case 0x15:
    uVar7 = iVar6 / 10;
    goto LAB_00b452b6;
  case 0x16:
    uVar7 = iVar6 / 100;
    goto LAB_00b4544b;
  case 0x17:
    uVar7 = uStack_104;
LAB_00b452b6:
    FUN_01675640(param_1,&DAT_019522bc,uVar7);
    goto LAB_00b45a5f;
  case 0x18:
    uVar7 = uStack_104;
LAB_00b4544b:
    FUN_01675640(param_1,&DAT_018bed68,uVar7);
    goto LAB_00b45a5f;
  case 0x19:
    if (iStack_9c != 0) {
      iVar6 = FUN_00b443d0(auStack_58,uStack_5c,uStack_64,auStack_a0);
      uStack_8 = CONCAT31(uStack_8._1_3_,4);
      FUN_0054ef60(iVar6 + 0x18);
      FUN_005509f0();
      goto LAB_00b4530d;
    }
    iVar6 = FUN_00b443d0(auStack_58,uStack_5c,uStack_64,auStack_12c);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    iVar6 = iVar6 + 0x18;
    goto LAB_00b455a0;
  case 0x1a:
    if (iStack_9c == 0) {
      iVar6 = FUN_00b443d0(auStack_58,uStack_5c,uStack_64,auStack_12c);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
    }
    else {
      iVar6 = FUN_00b443d0(auStack_58,uStack_5c,uStack_64,auStack_a0);
      uStack_8 = CONCAT31(uStack_8._1_3_,6);
    }
LAB_00b455a0:
    FUN_0054ef60(iVar6);
    FUN_005509f0();
LAB_00b4530d:
    FUN_00b3da90();
    FUN_005507b0();
    FUN_00b3da90();
    ExceptionList = pvStack_10;
    return param_1;
  case 0x1b:
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = 0;
    FUN_005542c0(&DAT_0195228c,3);
    FUN_0097be30(&param_3,auStack_40);
    FUN_005507b0();
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = 0;
    FUN_005542c0(&DAT_0195228c,3);
    if (param_3 == puStack_bc) {
      uStack_8 = CONCAT31(uStack_8._1_3_,7);
LAB_00b456a5:
      puVar5 = auStack_28;
    }
    else {
      uStack_8 = CONCAT31(uStack_8._1_3_,8);
      puVar5 = param_4;
    }
    break;
  case 0x1c:
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = 0;
    FUN_005542c0(&DAT_01952290,2);
    FUN_0097be30(&param_3,auStack_40);
    FUN_005507b0();
    uStack_30 = 0;
    uStack_2c = 0xf;
    auStack_40[0] = 0;
    FUN_005542c0(&DAT_01952290,2);
    if (param_3 == puStack_bc) {
      uStack_8 = CONCAT31(uStack_8._1_3_,9);
      goto LAB_00b456a5;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,10);
    puVar5 = param_4;
    break;
  case 0x1d:
    FUN_0054eff0(&DAT_01952294);
    FUN_0097be30(&param_3,auStack_40);
    FUN_005507b0();
    FUN_0054eff0(&DAT_01952294);
    if (param_3 == puStack_bc) {
      uStack_8 = CONCAT31(uStack_8._1_3_,0xb);
      goto LAB_00b456a5;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
    puVar5 = param_4;
    break;
  case 0x1e:
    FUN_0054eff0(&DAT_0195229c);
    FUN_0097be30(&param_3,auStack_40);
    FUN_005507b0();
    FUN_0054eff0(&DAT_0195229c);
    if (param_3 == puStack_bc) {
      uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
      goto LAB_00b456a5;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0xe);
    puVar5 = param_4;
    break;
  case 0x1f:
    FUN_0054eff0(&DAT_019522a0);
    FUN_0097be30(&param_3,auStack_40);
    FUN_005507b0();
    FUN_0054eff0(&DAT_019522a0);
    if (param_3 == puStack_bc) {
      uStack_8 = CONCAT31(uStack_8._1_3_,0xf);
      goto LAB_00b456a5;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x10);
    puVar5 = param_4;
    break;
  case 0x20:
    FUN_0054eff0(&DAT_018fab0c);
    FUN_0097be30(&param_3,auStack_40);
    FUN_005507b0();
    FUN_0054eff0(&DAT_018fab0c);
    if (param_3 == puStack_bc) {
      uStack_8 = CONCAT31(uStack_8._1_3_,0x11);
      goto LAB_00b456a5;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x12);
    puVar5 = param_4;
    break;
  case 0x21:
    FUN_0054eff0(&DAT_019522a4);
    FUN_0097be30(&param_3,auStack_40);
    FUN_005507b0();
    FUN_0054eff0(&DAT_019522a4);
    if (param_3 == puStack_bc) {
      uStack_8 = CONCAT31(uStack_8._1_3_,0x13);
      goto LAB_00b456a5;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x14);
    puVar5 = param_4;
    break;
  case 0x22:
    FUN_0054eff0(&DAT_019522ac);
    FUN_0097be30(&param_3,auStack_40);
    FUN_005507b0();
    FUN_0054eff0(&DAT_019522ac);
    if (param_3 == puStack_bc) {
      uStack_8 = CONCAT31(uStack_8._1_3_,0x15);
      goto LAB_00b456a5;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x16);
    puVar5 = param_4;
    break;
  case 0x23:
    FUN_0054eff0(&DAT_019522b0);
    FUN_0097be30(&param_3,auStack_40);
    FUN_005507b0();
    FUN_0054eff0(&DAT_019522b0);
    if (param_3 == puStack_bc) {
      uStack_8 = CONCAT31(uStack_8._1_3_,0x17);
      goto LAB_00b456a5;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x18);
    puVar5 = param_4;
    break;
  case 0x24:
    FUN_0054eff0(&DAT_018c8ecc);
    FUN_0097be30(&param_3,auStack_40);
    FUN_005507b0();
    FUN_0054eff0(&DAT_018c8ecc);
    if (param_3 == puStack_bc) {
      uStack_8 = CONCAT31(uStack_8._1_3_,0x19);
      goto LAB_00b456a5;
    }
    uStack_8 = CONCAT31(uStack_8._1_3_,0x1a);
    puVar5 = param_4;
    break;
  default:
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x14) = 0xf;
    *param_1 = 0;
    FUN_005542c0(&DAT_018bc9b8,0);
    goto LAB_00b45a5f;
  }
  uVar3 = FUN_00b3fd10(auStack_40);
  FUN_00b42750(param_1,param_2,uVar3,puVar5);
  FUN_005507b0();
LAB_00b45a5f:
  FUN_00b3da90();
  FUN_005507b0();
  FUN_00b3da90();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24073 ; VA 0x00b45b30 ; FUN_00b45b30 */

void __fastcall FUN_00b45b30(int *param_1)

{
  undefined4 uVar1;
  int iStack_18;
  int iStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  uStack_10 = 0xfffffffe;
  uStack_c = 0x7fffffff;
  uVar1 = FUN_0056a9c0(0);
  FUN_005672c0(uVar1,&uStack_10);
  if ((*param_1 == iStack_18) && (param_1[1] == iStack_14)) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Invalid Datetime.\n");
  }
  FUN_006d31a0(&iStack_18,&DAT_01eee630);
  FUN_016f3900(iStack_18,iStack_14,1000000,0);
  return;
}



/* FUNCTION 24074 ; VA 0x00b45ba0 ; FUN_00b45ba0 */

void __fastcall FUN_00b45ba0(int *param_1)

{
  undefined4 uVar1;
  int iStack_18;
  int iStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  uStack_10 = 0xfffffffe;
  uStack_c = 0x7fffffff;
  uVar1 = FUN_0056a9c0(0);
  FUN_005672c0(uVar1,&uStack_10);
  if ((*param_1 == iStack_18) && (param_1[1] == iStack_14)) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Invalid Datetime.\n");
  }
  FUN_006d31a0(&iStack_18,&DAT_01eee630);
  FUN_016f3900(iStack_18,iStack_14,1000,0);
  return;
}



/* FUNCTION 24075 ; VA 0x00b45c10 ; FUN_00b45c10 */

int * __thiscall FUN_00b45c10(int param_1,int *param_2,undefined4 param_3)

{
  code *pcVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  ushort uVar6;
  uint uVar7;
  int iVar8;
  uint extraout_ECX;
  uint uVar9;
  undefined2 uStack_14;
  ushort uStack_12;
  ushort uStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  piVar5 = param_2;
  param_2 = (int *)CONCAT22(param_2._2_2_,*(undefined2 *)(param_1 + 4));
  iStack_8 = param_1;
  FUN_0056a920(param_3,param_2,1);
  param_2 = (int *)(uint)*(ushort *)(param_1 + 0xc);
  uStack_c = 7;
  FUN_00b43600(&uStack_14,*piVar5);
  uVar7 = (int)(0xe - (uint)uStack_12) / 0xc & 0xffff;
  uVar9 = CONCAT22(uStack_12,uStack_14) - uVar7 & 0xffff;
  iVar3 = (uint)uStack_10 +
          (uVar9 >> 2) + uVar9 +
          (((uVar7 * 0xc + -2 + CONCAT22(uStack_10,uStack_12) & 0xffff) * 0x1f) / 0xc - uVar9 / 100)
          + uVar9 / 400;
  iVar2 = iStack_8;
  do {
    uVar7 = iVar3 % 7 & 0xffff;
    iStack_8 = iVar2;
    if (uVar7 == 0xffffffff) {
LAB_00b45e40:
      FUN_00b47210(0,uVar7,0);
      pcVar1 = (code *)swi(3);
      piVar5 = (int *)(*pcVar1)();
      return piVar5;
    }
    uVar6 = (ushort)(iVar3 % 7);
    if (6 < uVar6) {
      FUN_00b47210(0,uVar7,1);
      uVar7 = extraout_ECX;
      goto LAB_00b45e40;
    }
    iVar3 = *piVar5;
    if ((ushort)param_2 == uVar6) {
      iVar8 = 1;
      if (1 < *(int *)(iVar2 + 8)) {
        do {
          if ((((iVar3 != 0) && (iVar3 != -1)) && (iVar3 != -2)) ||
             (((iVar3 != -2 && (iVar3 != 0)) && (iVar3 != -1)))) {
            iVar3 = iVar3 + 7;
          }
          iVar8 = iVar8 + 1;
          *piVar5 = iVar3;
        } while (iVar8 < *(int *)(iVar2 + 8));
      }
      FUN_00b43600(&uStack_14,iVar3);
      if (uStack_12 != *(ushort *)(iVar2 + 4)) {
        piVar4 = (int *)FUN_00b3ddf0(&param_2,&uStack_c);
        *piVar5 = *piVar4;
      }
      return piVar5;
    }
    if ((((iVar3 != 0) && (iVar3 != -1)) && (iVar3 != -2)) ||
       (((iVar3 != -2 && (iVar3 != 0)) && (iVar3 != -1)))) {
      iVar3 = iVar3 + 1;
    }
    *piVar5 = iVar3;
    param_2 = (int *)(uint)*(ushort *)(iVar2 + 0xc);
    FUN_00b43600(&uStack_14,iVar3);
    uVar7 = (int)(0xe - (uint)uStack_12) / 0xc & 0xffff;
    uVar9 = CONCAT22(uStack_12,uStack_14) - uVar7 & 0xffff;
    iVar3 = (uint)uStack_10 +
            (uVar9 >> 2) + uVar9 +
            (((uVar7 * 0xc + -2 + CONCAT22(uStack_10,uStack_12) & 0xffff) * 0x1f) / 0xc -
            uVar9 / 100) + uVar9 / 400;
    iVar2 = iStack_8;
  } while( true );
}



/* FUNCTION 24076 ; VA 0x00b45e50 ; FUN_00b45e50 */

undefined4 __thiscall FUN_00b45e50(int param_1,undefined4 param_2,uint param_3)

{
  ulonglong uVar1;
  code *pcVar2;
  undefined2 uVar3;
  undefined4 uVar4;
  undefined auStack_cc [152];
  undefined auStack_34 [36];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f303b;
  pvStack_10 = ExceptionList;
  if (((*(short *)(param_1 + 4) == 0x1d) && (*(short *)(param_1 + 6) == 2)) &&
     (((param_3 & 3) != 0 ||
      ((uVar1 = (ulonglong)(param_3 & 0xffff) % 100, (int)uVar1 == 0 &&
       ((int)((uVar1 << 0x20 | (ulonglong)(param_3 & 0xffff)) % 400) != 0)))))) {
    ExceptionList = &pvStack_10;
    FUN_00565520(2,1);
    uStack_8 = 0;
    FUN_00558890(auStack_cc,"No Feb 29th in given year of ");
    uVar3 = FUN_0056f540();
    uVar4 = FUN_00b3dc40(uVar3,&DAT_018c1030);
    FUN_00558890(uVar4);
    uVar4 = FUN_0058c400(auStack_34);
    uVar4 = FUN_00b3ce00(uVar4);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00b38fd0(uVar4);
    pcVar2 = (code *)swi(3);
    uVar4 = (*pcVar2)();
    return uVar4;
  }
  ExceptionList = &pvStack_10;
  FUN_0056a920(param_3,*(undefined2 *)(param_1 + 6),*(undefined2 *)(param_1 + 4));
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24077 ; VA 0x00b45f40 ; FUN_00b45f40 */

undefined __fastcall FUN_00b45f40(int param_1)

{
  return *(undefined *)(param_1 + 100);
}



/* FUNCTION 24078 ; VA 0x00b45f50 ; FUN_00b45f50 */

/* WARNING: Type propagation algorithm not settling */

undefined4 FUN_00b45f50(undefined4 param_1,undefined4 *param_2,int param_3)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined auStack_c4 [12];
  int iStack_b8;
  undefined **appuStack_b4 [15];
  undefined4 uStack_78;
  undefined4 auStack_74 [3];
  undefined4 uStack_68;
  undefined **ppuStack_64;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f2d8f;
  pvStack_10 = ExceptionList;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  uVar1 = FUN_016f3900(*param_2,param_2[1],3600000000,0);
  appuStack_b4[0] = &PTR_018be314;
  uStack_8 = 0;
  uStack_14 = 4;
  ppuStack_64 = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_68 = 0x48;
  FUN_00554f20(appuStack_b4 + 1,0);
  uStack_8 = 2;
  *(undefined ***)(appuStack_b4[0][1] + (int)appuStack_b4) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)((int)&iStack_b8 + (int)appuStack_b4[0][1]) = appuStack_b4[0][1] + -0x50;
  FUN_0054ee60();
  appuStack_b4[1] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  uStack_78 = 0;
  auStack_74[0] = 4;
  uStack_8 = 3;
  uVar2 = FUN_016de368();
  FUN_00b460e0(auStack_1c,uVar2);
  uStack_8._0_1_ = 4;
  if (piStack_18 != (int *)0x0) {
    puVar3 = (undefined4 *)(**(code **)(*piStack_18 + 8))();
    if (puVar3 != (undefined4 *)0x0) {
      (**(code **)*puVar3)(1);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  puVar3 = (undefined4 *)FUN_016df519(auStack_c4,param_3,param_3 >> 0x1f);
  (*(code *)*puVar3)(appuStack_b4[0][1] + (int)appuStack_b4,puVar3[2],puVar3[3]);
  *(undefined *)((int)auStack_74 + (int)appuStack_b4[0][1]) = 0x30;
  FUN_005af260((uVar1 ^ (int)uVar1 >> 0x1f) - ((int)uVar1 >> 0x1f));
  FUN_0058c420(param_1);
  FUN_00570540();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24079 ; VA 0x00b460e0 ; FUN_00b460e0 */

undefined4 __thiscall FUN_00b460e0(int param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f3082;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00b461e0(param_2,param_3);
  piVar1 = *(int **)(param_1 + 0x38);
  if (piVar1 != (int *)0x0) {
    piVar2 = *(int **)(piVar1[0xd] + 4);
    uStack_8._0_1_ = 2;
    uStack_8._1_3_ = 0;
    (**(code **)(*piVar2 + 4))();
    uStack_8._0_1_ = 1;
    (**(code **)(*piVar1 + 0x38))(param_3);
    iVar3 = piVar1[0xd];
    piVar1 = *(int **)(iVar3 + 4);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    if (piVar1 != *(int **)(param_3 + 4)) {
      puVar4 = (undefined4 *)(**(code **)(*piVar1 + 8))();
      if (puVar4 != (undefined4 *)0x0) {
        (**(code **)*puVar4)(1);
      }
      piVar1 = *(int **)(param_3 + 4);
      *(int **)(iVar3 + 4) = piVar1;
      (**(code **)(*piVar1 + 4))();
    }
    uStack_8 = 4;
    if (piVar2 != (int *)0x0) {
      puVar4 = (undefined4 *)(**(code **)(*piVar2 + 8))();
      if (puVar4 != (undefined4 *)0x0) {
        (**(code **)*puVar4)(1);
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24080 ; VA 0x00b461e0 ; FUN_00b461e0 */

int __thiscall FUN_00b461e0(int param_1,int param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  puStack_c = &LAB_017f30a9;
  pvStack_10 = ExceptionList;
  piVar1 = *(int **)(*(int *)(param_1 + 0x30) + 4);
  uStack_8 = 1;
  ExceptionList = &pvStack_10;
  *(int **)(param_2 + 4) = piVar1;
  (**(code **)(*piVar1 + 4))();
  iVar2 = *(int *)(param_1 + 0x30);
  piVar1 = *(int **)(iVar2 + 4);
  uStack_8 = 2;
  if (piVar1 != *(int **)(param_3 + 4)) {
    puVar3 = (undefined4 *)(**(code **)(*piVar1 + 8))();
    if (puVar3 != (undefined4 *)0x0) {
      (**(code **)*puVar3)(1);
    }
    piVar1 = *(int **)(param_3 + 4);
    *(int **)(iVar2 + 4) = piVar1;
    (**(code **)(*piVar1 + 4))();
  }
  puVar3 = *(undefined4 **)(param_1 + 0x2c);
  uStack_8 = uStack_8 & 0xffffff00;
  for (; puVar3 != (undefined4 *)0x0; puVar3 = (undefined4 *)*puVar3) {
    (*(code *)puVar3[2])(1,param_1,puVar3[1]);
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24081 ; VA 0x00b46290 ; FUN_00b46290 */

void __thiscall FUN_00b46290(undefined4 param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 uVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined auStack_a8 [8];
  undefined auStack_a0 [8];
  undefined auStack_98 [8];
  undefined auStack_90 [8];
  undefined auStack_88 [16];
  undefined auStack_78 [4];
  int *piStack_74;
  undefined4 uStack_70;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined2 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined2 uStack_54;
  undefined auStack_50 [4];
  int *piStack_4c;
  undefined4 uStack_48;
  undefined2 uStack_44;
  undefined auStack_40 [4];
  int *piStack_3c;
  int iStack_38;
  undefined2 uStack_34;
  undefined4 uStack_30;
  uint uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  undefined2 uStack_20;
  int *piStack_1c;
  int iStack_18;
  undefined2 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3103;
  pvStack_10 = ExceptionList;
  uStack_2c = 0;
  uVar2 = param_2[4];
  ExceptionList = &pvStack_10;
  uStack_30 = param_1;
  if (uVar2 != 0) {
    do {
      if (uStack_2c == 0) {
        iVar3 = uVar2 - 1;
        if (iVar3 == 0) {
          piStack_1c = (int *)iVar3;
          iStack_18 = iVar3;
          piStack_1c = (int *)FUN_00575ab0();
          uStack_14 = (undefined2)param_3;
          uStack_8 = 0;
          puVar5 = param_2;
          if (0xf < (uint)param_2[5]) {
            puVar5 = (undefined4 *)*param_2;
          }
          auStack_40[0] = *(undefined *)puVar5;
          piStack_3c = (int *)0x0;
          iStack_38 = 0;
          piVar4 = (int *)FUN_00575ab0();
          iVar3 = iStack_38;
          piStack_3c = piStack_1c;
          iStack_38 = iStack_18;
          iStack_18 = iVar3;
          uStack_34 = uStack_14;
          uStack_8._0_1_ = 1;
          piStack_1c = piVar4;
          FUN_00b35cf0(auStack_90,0,auStack_40,param_3);
          piVar4 = piStack_3c;
          uStack_8 = CONCAT31(uStack_8._1_3_,2);
          FUN_00b3fb60(piStack_3c[1]);
          piStack_3c[1] = (int)piVar4;
          *piStack_3c = (int)piVar4;
          piStack_3c[2] = (int)piVar4;
          iStack_38 = 0;
          FUN_01674ea0(piStack_3c,0x20);
          piVar4 = piStack_1c;
          uStack_8 = 3;
          FUN_00b3fb60(piStack_1c[1]);
          uStack_8 = 0xffffffff;
          piStack_1c[1] = (int)piVar4;
          *piStack_1c = (int)piVar4;
          piStack_1c[2] = (int)piVar4;
          iStack_18 = 0;
          FUN_01674ea0(piStack_1c,0x20);
        }
        else {
          piStack_28 = (int *)0x0;
          uStack_24 = 0;
          piStack_28 = (int *)FUN_00575ab0();
          uStack_20 = 0xffff;
          uStack_8 = 4;
          puVar5 = param_2;
          if (0xf < (uint)param_2[5]) {
            puVar5 = (undefined4 *)*param_2;
          }
          auStack_50[0] = *(undefined *)puVar5;
          piStack_4c = (int *)0x0;
          uStack_48 = 0;
          piVar4 = (int *)FUN_00575ab0();
          uVar1 = uStack_48;
          piStack_4c = piStack_28;
          uStack_48 = uStack_24;
          uStack_24 = uVar1;
          uStack_44 = uStack_20;
          uStack_8._0_1_ = 5;
          piStack_28 = piVar4;
          FUN_00b35cf0(auStack_98,0,auStack_50,param_3);
          piVar4 = piStack_4c;
          uStack_8 = CONCAT31(uStack_8._1_3_,6);
          FUN_00b3fb60(piStack_4c[1]);
          piStack_4c[1] = (int)piVar4;
          *piStack_4c = (int)piVar4;
          piStack_4c[2] = (int)piVar4;
          uStack_48 = 0;
          FUN_01674ea0(piStack_4c,0x20);
          piVar4 = piStack_28;
          uStack_8 = 7;
          FUN_00b3fb60(piStack_28[1]);
          uStack_8 = 0xffffffff;
          piStack_28[1] = (int)piVar4;
          *piStack_28 = (int)piVar4;
          piStack_28[2] = (int)piVar4;
          uStack_24 = 0;
          FUN_01674ea0(piStack_28,0x20);
        }
      }
      else if (uStack_2c == uVar2 - 1) {
        uStack_5c = 0;
        uStack_58 = 0;
        uStack_5c = FUN_00575ab0();
        uStack_54 = (undefined2)param_3;
        uStack_8 = 8;
        puVar5 = param_2;
        if (0xf < (uint)param_2[5]) {
          puVar5 = (undefined4 *)*param_2;
        }
        auStack_78[0] = *(undefined *)((int)puVar5 + uStack_2c);
        FUN_00b3c070(&uStack_5c);
        uStack_8._0_1_ = 9;
        FUN_00b35cf0(auStack_a0,0,auStack_78,param_3);
        piVar4 = piStack_74;
        uStack_8 = CONCAT31(uStack_8._1_3_,10);
        FUN_00b3fb60(piStack_74[1]);
        piStack_74[1] = (int)piVar4;
        *piStack_74 = (int)piVar4;
        piStack_74[2] = (int)piVar4;
        uStack_70 = 0;
        FUN_0054db70(piStack_74,0x20);
        uStack_8 = 0xffffffff;
        FUN_00b3d060();
      }
      else {
        uStack_68 = 0;
        uStack_64 = 0;
        uStack_68 = FUN_00575ab0();
        uStack_60 = 0xffff;
        uStack_8 = 0xb;
        puVar5 = param_2;
        if (0xf < (uint)param_2[5]) {
          puVar5 = (undefined4 *)*param_2;
        }
        auStack_88[0] = *(undefined *)((int)puVar5 + uStack_2c);
        FUN_00b3c070(&uStack_68);
        uStack_8 = CONCAT31(uStack_8._1_3_,0xc);
        FUN_00b35cf0(auStack_a8,0,auStack_88,param_3);
        FUN_00b3d060();
        uStack_8 = 0xffffffff;
        FUN_00b3d060();
      }
      uVar2 = param_2[4];
      uStack_2c = uStack_2c + 1;
    } while (uStack_2c < uVar2);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24082 ; VA 0x00b46650 ; FUN_00b46650 */

undefined4 * __thiscall FUN_00b46650(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  undefined4 *puVar7;
  int *piStack_24;
  undefined2 uStack_1c;
  undefined2 uStack_1a;
  undefined2 uStack_14;
  undefined2 uStack_12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3127;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar5 = FUN_009d6100(param_2);
  iVar6 = FUN_009d6100(param_3);
  puVar7 = (undefined4 *)FUN_01674e20(0x14);
  uStack_8 = 0;
  if (puVar7 == (undefined4 *)0x0) {
    puVar7 = (undefined4 *)0x0;
  }
  else {
    FUN_00b3b360(iVar6 + 1);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    FUN_00b3b360(iVar5 + 1);
    *puVar7 = boost::date_time::day_calc_dst_rule<struct_boost::local_time::partial_date_rule_spec>
              ::vftable;
    puVar7[1] = boost::date_time::partial_date<class_boost::gregorian::date>::vftable;
    *(undefined2 *)(puVar7 + 2) = uStack_14;
    *(undefined2 *)((int)puVar7 + 10) = uStack_12;
    puVar7[3] = boost::date_time::partial_date<class_boost::gregorian::date>::vftable;
    *(undefined2 *)(puVar7 + 4) = uStack_1c;
    *(undefined2 *)((int)puVar7 + 0x12) = uStack_1a;
  }
  uStack_8 = 0xffffffff;
  puVar7 = (undefined4 *)FUN_00b33b40(puVar7);
  uVar2 = *puVar7;
  uVar3 = puVar7[1];
  puVar7[1] = 0;
  *puVar7 = 0;
  *(undefined4 *)(param_1 + 0x88) = uVar2;
  piVar4 = *(int **)(param_1 + 0x8c);
  *(undefined4 *)(param_1 + 0x8c) = uVar3;
  uStack_8 = 2;
  if (piVar4 != (int *)0x0) {
    LOCK();
    piVar1 = piVar4 + 1;
    iVar5 = *piVar1;
    puVar7 = (undefined4 *)*piVar1;
    *piVar1 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      (**(code **)(*piVar4 + 4))();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar5 = *piVar1;
      puVar7 = (undefined4 *)*piVar1;
      *piVar1 = iVar5 + -1;
      UNLOCK();
      if (iVar5 + -1 == 0) {
        puVar7 = (undefined4 *)(**(code **)(*piVar4 + 8))();
      }
    }
  }
  uStack_8 = 3;
  if (piStack_24 != (int *)0x0) {
    LOCK();
    piVar4 = piStack_24 + 1;
    iVar5 = *piVar4;
    puVar7 = (undefined4 *)*piVar4;
    *piVar4 = iVar5 + -1;
    UNLOCK();
    if (iVar5 + -1 == 0) {
      puVar7 = (undefined4 *)(**(code **)(*piStack_24 + 4))();
      LOCK();
      piVar4 = piStack_24 + 2;
      iVar5 = *piVar4;
      *piVar4 = *piVar4 + -1;
      UNLOCK();
      if (iVar5 == 1) {
        puVar7 = (undefined4 *)(**(code **)(*piStack_24 + 8))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return puVar7;
}



/* FUNCTION 24083 ; VA 0x00b467b0 ; FUN_00b467b0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int __thiscall FUN_00b467b0(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  byte bVar6;
  int iVar7;
  uint uVar8;
  undefined4 *puVar9;
  uint extraout_ECX;
  uint extraout_ECX_00;
  char *extraout_ECX_01;
  uint uVar10;
  uint extraout_EDX;
  uint extraout_EDX_00;
  int *extraout_EDX_01;
  ushort uVar11;
  uint uVar12;
  uint uVar13;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  uint uStack_54;
  uint *puStack_50;
  uint auStack_40 [4];
  undefined4 uStack_30;
  uint uStack_2c;
  int *piStack_24;
  undefined **ppuStack_20;
  undefined2 uStack_1c;
  ushort uStack_1a;
  int iStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3167;
  pvStack_10 = ExceptionList;
  uVar13 = 1;
  uStack_30 = 0;
  uStack_2c = 0xf;
  auStack_40[0] = auStack_40[0] & 0xffffff00;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  if (param_2[4] != 0) {
    iVar7 = param_2[4] + -1;
    puStack_50 = (uint *)-1;
    if (iVar7 != -1) {
      puStack_50 = (uint *)iVar7;
    }
    if (0xf < (uint)param_2[5]) {
      param_2 = (undefined4 *)*param_2;
    }
    uStack_54 = (int)param_2 + 1;
    uStack_58 = 0xb46815;
    ExceptionList = &pvStack_10;
    FUN_005542c0();
    puStack_50 = auStack_40;
    uStack_8 = 0;
    uStack_54 = 0xb46825;
    uVar8 = FUN_009d6100();
    uStack_8 = 0xffffffff;
    uStack_14 = uVar8;
    if (0xf < uStack_2c) {
      puStack_50 = (uint *)(uStack_2c + 1);
      uVar12 = auStack_40[0];
      if (0xfff < puStack_50) {
        uVar12 = *(uint *)(auStack_40[0] - 4);
        puStack_50 = (uint *)(uStack_2c + 0x24);
        if (0x1f < (auStack_40[0] - uVar12) - 4) goto LAB_00b46b8f;
      }
      uStack_58 = 0xb46865;
      uStack_54 = uVar12;
      FUN_01674ea0();
    }
    do {
      if (0xc < (ushort)uVar13) {
        puStack_50 = (uint *)0x1;
        uStack_58 = 1;
        uStack_5c = 0xb46b8a;
        uStack_54 = uVar13;
        FUN_00588640();
        goto LAB_00b46b8a;
      }
      uVar12 = uVar13 & 0xffff;
      switch(uVar12) {
      case 2:
        iVar7 = 0x1c;
        break;
      default:
        iVar7 = 0x1f;
        break;
      case 4:
      case 6:
      case 9:
      case 0xb:
        iVar7 = 0x1e;
      }
      if ((int)uVar8 < iVar7) {
        uVar8 = 1;
        uStack_30 = 0;
        uStack_2c = 0xf;
        auStack_40[0] = auStack_40[0] & 0xffffff00;
        if (param_3[4] == 0) goto LAB_00b46bb2;
        iVar7 = param_3[4] + -1;
        puStack_50 = (uint *)-1;
        if (iVar7 != -1) {
          puStack_50 = (uint *)iVar7;
        }
        if (0xf < (uint)param_3[5]) {
          param_3 = (undefined4 *)*param_3;
        }
        uStack_54 = (int)param_3 + 1;
        uStack_58 = 0xb46944;
        FUN_005542c0();
        puStack_50 = auStack_40;
        uStack_8 = 1;
        uStack_54 = 0xb46954;
        param_2 = (undefined4 *)FUN_009d6100();
        uStack_8 = 0xffffffff;
        if (uStack_2c < 0x10) goto LAB_00b469a0;
        puStack_50 = (uint *)(uStack_2c + 1);
        uVar12 = auStack_40[0];
        if (0xfff < puStack_50) {
          uVar12 = *(uint *)(auStack_40[0] - 4);
          puStack_50 = (uint *)(uStack_2c + 0x24);
          if (0x1f < (auStack_40[0] - uVar12) - 4) goto LAB_00b46bb7;
        }
        uStack_58 = 0xb46996;
        uStack_54 = uVar12;
        FUN_01674ea0();
        goto LAB_00b469a0;
      }
      uVar10 = uVar13 & 0xffff;
      uVar13 = uVar13 + 1;
      if (uVar12 + 1 < 2) goto LAB_00b46ba8;
      if (0xc < uVar10) goto LAB_00b46b9e;
      switch(uVar12) {
      case 2:
        iVar7 = 0x1c;
        break;
      default:
        iVar7 = 0x1f;
        break;
      case 4:
      case 6:
      case 9:
      case 0xb:
        iVar7 = 0x1e;
      }
      uVar8 = uVar8 - iVar7;
      uStack_14 = uVar8;
    } while (1 < (uVar13 & 0xffff) + 1);
    puStack_50 = (uint *)0x0;
    uStack_58 = 1;
    uStack_5c = 0xb46b9e;
    uStack_54 = uVar13;
    FUN_00588640();
    uVar10 = extraout_EDX;
LAB_00b46b9e:
    puStack_50 = (uint *)0x1;
    uStack_58 = 1;
    uStack_5c = 0xb46ba8;
    uStack_54 = uVar10;
    FUN_00588640();
    uVar10 = extraout_EDX_00;
LAB_00b46ba8:
    puStack_50 = (uint *)0x0;
    uStack_58 = 1;
    uStack_5c = 0xb46bb2;
    uStack_54 = uVar10;
    FUN_00588640();
LAB_00b46bb2:
    puStack_50 = (uint *)0xb46bb7;
    FUN_00554050();
LAB_00b46bb7:
                    /* WARNING: Subroutine does not return */
    puStack_50 = (uint *)0xb46bbc;
    FUN_017167a3();
  }
LAB_00b46b8a:
  puStack_50 = (uint *)0xb46b8f;
  FUN_00554050();
LAB_00b46b8f:
                    /* WARNING: Subroutine does not return */
  puStack_50 = (uint *)0xb46b94;
  FUN_017167a3();
  while( true ) {
    uVar12 = uVar8 & 0xffff;
    switch(uVar12) {
    case 2:
      iVar7 = 0x1c;
      break;
    default:
      iVar7 = 0x1f;
      break;
    case 4:
    case 6:
    case 9:
    case 0xb:
      iVar7 = 0x1e;
    }
    if ((int)param_2 <= iVar7) {
      puStack_50 = (uint *)0x14;
      uStack_54 = 0xb46a3a;
      puStack_50 = (uint *)FUN_01674e20();
      uStack_8 = 2;
      if (puStack_50 == (undefined4 *)0x0) {
        puStack_50 = (undefined4 *)0x0;
      }
      else {
        if (uVar12 + 1 < 2) goto LAB_00b46bc6;
        uStack_54 = (uint)param_2 & 0xffff;
        if (uStack_54 + 1 < 2) goto LAB_00b46bd0;
        if (0x1f < uStack_54) goto LAB_00b46bda;
        ppuStack_20 = boost::date_time::partial_date<class_boost::gregorian::date>::vftable;
        uStack_1c = SUB42(param_2,0);
        uStack_8 = 3;
        uStack_1a = uVar11;
        if ((uVar13 & 0xffff) + 1 < 2) goto LAB_00b46be4;
        uVar12 = uStack_14 & 0xffff;
        if (uVar12 + 1 < 2) goto LAB_00b46bee;
        if (0x1f < uVar12) goto LAB_00b46bf8;
        *puStack_50 = (uint)boost::date_time::
                            day_calc_dst_rule<struct_boost::local_time::partial_date_rule_spec>::
                            vftable;
        puStack_50[1] = (uint)boost::date_time::partial_date<class_boost::gregorian::date>::vftable;
        *(short *)(puStack_50 + 2) = (short)uStack_14;
        *(ushort *)((int)puStack_50 + 10) = (ushort)uVar13;
        puStack_50[3] = (uint)boost::date_time::partial_date<class_boost::gregorian::date>::vftable;
        *(undefined2 *)(puStack_50 + 4) = uStack_1c;
        *(ushort *)((int)puStack_50 + 0x12) = uVar11;
      }
      uStack_8 = 0xffffffff;
      uStack_54 = 0xb46aeb;
      puVar9 = (undefined4 *)FUN_00b33b40();
      uVar3 = *puVar9;
      uVar4 = puVar9[1];
      puVar9[1] = 0;
      *puVar9 = 0;
      *(undefined4 *)(iStack_18 + 0x88) = uVar3;
      piVar5 = *(int **)(iStack_18 + 0x8c);
      *(undefined4 *)(iStack_18 + 0x8c) = uVar4;
      uStack_8 = 4;
      iVar7 = iStack_18;
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar2 = *piVar1;
        iVar7 = *piVar1;
        *piVar1 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          puStack_50 = (uint *)0xb46b30;
          (**(code **)(*piVar5 + 4))();
          LOCK();
          piVar1 = piVar5 + 2;
          iVar2 = *piVar1;
          iVar7 = *piVar1;
          *piVar1 = iVar2 + -1;
          UNLOCK();
          if (iVar2 + -1 == 0) {
            puStack_50 = (uint *)0xb46b40;
            iVar7 = (**(code **)(*piVar5 + 8))();
          }
        }
      }
      uStack_8 = 5;
      if (piStack_24 != (int *)0x0) {
        LOCK();
        piVar5 = piStack_24 + 1;
        iVar2 = *piVar5;
        iVar7 = *piVar5;
        *piVar5 = iVar2 + -1;
        UNLOCK();
        if (iVar2 + -1 == 0) {
          puStack_50 = (uint *)0xb46b5e;
          iVar7 = (**(code **)(*piStack_24 + 4))();
          LOCK();
          piVar5 = piStack_24 + 2;
          iVar2 = *piVar5;
          *piVar5 = *piVar5 + -1;
          UNLOCK();
          if (iVar2 == 1) {
            puStack_50 = (uint *)0xb46b6d;
            iVar7 = (**(code **)(*piStack_24 + 8))();
          }
        }
      }
      ExceptionList = pvStack_10;
      return iVar7;
    }
    uVar10 = uVar8 & 0xffff;
    uVar8 = uVar8 + 1;
    if (uVar12 + 1 < 2) goto LAB_00b46ba8;
    if (0xc < uVar10) goto LAB_00b46b9e;
    switch(uVar12) {
    case 2:
      iVar7 = 0x1c;
      break;
    default:
      iVar7 = 0x1f;
      break;
    case 4:
    case 6:
    case 9:
    case 0xb:
      iVar7 = 0x1e;
    }
    param_2 = (undefined4 *)((int)param_2 - iVar7);
    if ((uVar8 & 0xffff) + 1 < 2) break;
LAB_00b469a0:
    uVar11 = (ushort)uVar8;
    if (0xc < uVar11) goto LAB_00b46c02;
  }
  puStack_50 = (uint *)0x0;
  uStack_58 = 1;
  uStack_5c = 0xb46bc6;
  uStack_54 = uVar8;
  FUN_00588640();
LAB_00b46bc6:
  puStack_50 = (uint *)0x0;
  uStack_58 = 1;
  uStack_5c = 0xb46bd0;
  uStack_54 = uVar8;
  FUN_00588640();
  uStack_54 = extraout_ECX;
LAB_00b46bd0:
  puStack_50 = (uint *)0x0;
  uStack_58 = 1;
  uStack_5c = 0xb46bda;
  FUN_00588600();
  uStack_54 = extraout_ECX_00;
LAB_00b46bda:
  puStack_50 = (uint *)0x1;
  uStack_58 = 1;
  uStack_5c = 0xb46be4;
  FUN_00588600();
LAB_00b46be4:
  puStack_50 = (uint *)0x0;
  uStack_58 = 1;
  uStack_5c = 0xb46bee;
  uStack_54 = uVar13;
  FUN_00588640();
LAB_00b46bee:
  puStack_50 = (uint *)0x0;
  uStack_58 = 1;
  uStack_5c = 0xb46bf8;
  uStack_54 = uVar12;
  FUN_00588600();
LAB_00b46bf8:
  puStack_50 = (uint *)0x1;
  uStack_58 = 1;
  uStack_5c = 0xb46c02;
  uStack_54 = uVar12;
  FUN_00588600();
LAB_00b46c02:
  puStack_50 = (uint *)0x1;
  uStack_58 = 1;
  uStack_5c = 0xb46c0c;
  uStack_54 = uVar8;
  FUN_00588640();
  uVar3 = _DAT_0000b468;
  *extraout_EDX_01 =
       *extraout_EDX_01 +
       CONCAT31((int3)((uint)_DAT_0000b468 >> 8),
                (char)_DAT_0000b468 + *extraout_ECX_01 + *extraout_ECX_01 + *(char *)extraout_EDX_01
               );
  *(int *)(uVar8 - 0x70) = (int)&uStack_5c + *(int *)(uVar8 - 0x70);
  bVar6 = in(0x68);
  iVar7 = CONCAT22((short)((uint)uVar3 >> 0x10),(ushort)bVar6);
  *(byte *)extraout_EDX_01 = *(char *)extraout_EDX_01 + bVar6;
  *extraout_EDX_01 = *extraout_EDX_01 + iVar7;
  *extraout_EDX_01 = *extraout_EDX_01 + iVar7;
  return CONCAT31((int3)((uint)iVar7 >> 8),bVar6 + *extraout_ECX_01 + *extraout_ECX_01);
}



/* FUNCTION 24084 ; VA 0x00b46c70 ; FUN_00b46c70 */

char FUN_00b46c70(uint *param_1,undefined4 param_2,uint *param_3,uint param_4,uint *param_5,
                 int param_6,int param_7)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  char cVar6;
  undefined8 uVar7;
  undefined8 uStack_c;
  
  uVar5 = *param_3;
  uVar1 = *param_5;
  uVar2 = *param_1;
  if (uVar5 < uVar1) {
    if ((uVar5 < uVar2) && (uVar2 < uVar1)) {
      return '\x01';
    }
    if (uVar5 <= uVar2) {
      if (uVar1 < uVar2) {
        return '\0';
      }
LAB_00b46cc1:
      if (uVar2 == uVar5) {
        if ((int)param_4 < 0) {
          uVar7 = FUN_016f39b0((longlong)
                               (int)((param_4 ^ (int)param_4 >> 0x1f) - ((int)param_4 >> 0x1f)) *
                               0x3c,1000000,0);
          uStack_c = CONCAT44(-(uint)((int)uVar7 != 0) - (int)((ulonglong)uVar7 >> 0x20),-(int)uVar7
                             );
        }
        else {
          uStack_c = FUN_016f39b0((longlong)(int)param_4 * 0x3c,1000000,0);
        }
        iVar3 = FUN_00874e00(&uStack_c);
        if (iVar3 == -1) {
          return '\0';
        }
        uVar4 = FUN_005ef640(0,param_7 + param_4,0,0,0);
        iVar3 = FUN_00874e00(uVar4);
        return (iVar3 == -1) * '\x02' + '\x01';
      }
      if (uVar2 != uVar1) {
        return '\x03';
      }
      uVar5 = param_6 - param_7;
      if ((int)uVar5 < 0) {
        uVar7 = FUN_016f39b0((longlong)(int)((uVar5 ^ (int)uVar5 >> 0x1f) - ((int)uVar5 >> 0x1f)) *
                             0x3c,1000000,0);
        uStack_c = CONCAT44(-(uint)((int)uVar7 != 0) - (int)((ulonglong)uVar7 >> 0x20),-(int)uVar7);
      }
      else {
        uStack_c = FUN_016f39b0((longlong)(int)uVar5 * 0x3c,1000000,0);
      }
      iVar3 = FUN_00874e00(&uStack_c);
      if (iVar3 == -1) {
        return '\x01';
      }
      uVar4 = FUN_005ef640(0,param_6,0,0,0);
      iVar3 = FUN_00874e00(uVar4);
      cVar6 = '\x02';
      if (iVar3 != -1) {
        cVar6 = '\0';
      }
      return cVar6;
    }
  }
  else if ((uVar5 <= uVar2) || (uVar2 <= uVar1)) {
    if (uVar5 < uVar2) {
      return '\x01';
    }
    if (uVar2 < uVar1) {
      return '\x01';
    }
    goto LAB_00b46cc1;
  }
  return '\0';
}



/* FUNCTION 24085 ; VA 0x00b46ea0 ; FUN_00b46ea0 */

undefined4 FUN_00b46ea0(undefined4 param_1)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3188;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0171e1b0(auStack_18);
  iVar2 = FUN_0172468b(auStack_18);
  if (iVar2 != 0) {
    FUN_00b41950(param_1,iVar2);
    ExceptionList = pvStack_10;
    return param_1;
  }
  uVar3 = FUN_00550130("could not convert calendar time to local time");
  uStack_8 = 0;
  FUN_005ef340(uVar3);
  pcVar1 = (code *)swi(3);
  uVar3 = (*pcVar1)();
  return uVar3;
}



/* FUNCTION 24086 ; VA 0x00b46f10 ; FUN_00b46f10 */

void FUN_00b46f10(undefined4 param_1)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179c0b8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0172468b(param_1);
  if (iVar2 != 0) {
    ExceptionList = pvStack_10;
    return;
  }
  uVar3 = FUN_00550130("could not convert calendar time to local time");
  uStack_8 = 0;
  FUN_005ef340(uVar3);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 24087 ; VA 0x00b46f70 ; FUN_00b46f70 */

bool FUN_00b46f70(undefined4 param_1,undefined4 param_2,int param_3)

{
  undefined4 uStack_8;
  
  uStack_8 = 0;
  FUN_00b46fa0(param_1,param_2,param_3,&uStack_8);
  return *(short *)(param_3 + 0x1a) != -1;
}



/* FUNCTION 24088 ; VA 0x00b46fa0 ; FUN_00b46fa0 */

undefined2 __thiscall
FUN_00b46fa0(int *param_1,int *param_2,undefined4 param_3,undefined4 *param_4,uint *param_5)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  byte *pbVar4;
  undefined4 *puVar5;
  bool bVar6;
  int *piVar7;
  char cVar8;
  char cVar9;
  undefined uVar10;
  undefined4 *puVar11;
  uint uVar12;
  undefined4 *puVar13;
  undefined4 *puVar14;
  
  piVar7 = param_2;
  *param_5 = *param_5 + 1;
  bVar6 = true;
  if ((uint)param_4[4] < *param_5) {
    cVar8 = FUN_00a8d280(param_2,param_3);
    if (cVar8 != '\0') {
      return 0;
    }
    cVar8 = FUN_00a8e710();
  }
  else {
    bVar6 = false;
    puVar13 = param_4;
    if (0xf < (uint)param_4[5]) {
      puVar13 = (undefined4 *)*param_4;
    }
    cVar8 = *(char *)((*param_5 - 1) + (int)puVar13);
  }
  cVar9 = FUN_01725677((int)cVar8);
  param_2 = (int *)*param_1;
  puVar13 = (undefined4 *)param_2[1];
  cVar8 = *(char *)((int)puVar13 + 0xd);
  puVar5 = param_2;
  puVar14 = puVar13;
  cVar1 = cVar8;
  while (cVar1 == '\0') {
    if (*(char *)(puVar14 + 4) < cVar9) {
      puVar11 = (undefined4 *)puVar14[2];
      puVar14 = puVar5;
    }
    else {
      puVar11 = (undefined4 *)*puVar14;
    }
    puVar5 = puVar14;
    puVar14 = puVar11;
    cVar1 = *(char *)((int)puVar11 + 0xd);
  }
  while (cVar8 == '\0') {
    if (cVar9 < *(char *)(puVar13 + 4)) {
      puVar14 = (undefined4 *)*puVar13;
      param_2 = puVar13;
    }
    else {
      puVar14 = (undefined4 *)puVar13[2];
    }
    puVar13 = puVar14;
    cVar8 = *(char *)((int)puVar14 + 0xd);
  }
  if (puVar5 == param_2) {
    return *(undefined2 *)((int)param_4 + 0x1a);
  }
  do {
    if (bVar6) {
      if (*(char *)(piVar7 + 1) == '\0') {
        piVar2 = (int *)*piVar7;
        if (piVar2 == (int *)0x0) {
LAB_00b470a0:
          *piVar7 = 0;
        }
        else {
          if ((*(byte **)piVar2[7] == (byte *)0x0) || (*(int *)piVar2[0xb] < 1)) {
            uVar12 = (**(code **)(*piVar2 + 0x18))();
          }
          else {
            uVar12 = (uint)**(byte **)piVar2[7];
          }
          if (uVar12 == 0xffffffff) goto LAB_00b470a0;
          *(char *)((int)piVar7 + 5) = (char)uVar12;
        }
        *(undefined *)(piVar7 + 1) = 1;
      }
      piVar2 = (int *)*piVar7;
      if (piVar2 == (int *)0x0) {
LAB_00b470e1:
        *piVar7 = 0;
        uVar10 = 1;
      }
      else {
        if (*(int *)piVar2[7] == 0) {
LAB_00b470d3:
          uVar12 = (**(code **)(*piVar2 + 0x1c))();
        }
        else {
          iVar3 = *(int *)piVar2[0xb];
          if (iVar3 < 1) goto LAB_00b470d3;
          *(int *)piVar2[0xb] = iVar3 + -1;
          pbVar4 = *(byte **)piVar2[7];
          *(byte **)piVar2[7] = pbVar4 + 1;
          uVar12 = (uint)*pbVar4;
        }
        if (uVar12 == 0xffffffff) goto LAB_00b470e1;
        uVar10 = 0;
      }
      *(undefined *)(piVar7 + 1) = uVar10;
      FUN_005558a0(cVar9);
    }
    if ((*(short *)(puVar5 + 7) != -1) && ((uint)*(ushort *)(param_4 + 6) < *param_5)) {
      *(short *)((int)param_4 + 0x1a) = *(short *)(puVar5 + 7);
      *(undefined2 *)(param_4 + 6) = *(undefined2 *)param_5;
    }
    FUN_00b46fa0(piVar7,param_3,param_4,param_5);
    *param_5 = *param_5 - 1;
    uVar12 = *param_5;
    FUN_00551320();
    bVar6 = (bool)((uint)param_4[4] < uVar12 & bVar6);
    if (puVar5 == param_2) {
      return *(undefined2 *)((int)param_4 + 0x1a);
    }
  } while( true );
}



/* FUNCTION 24089 ; VA 0x00b47170 ; FUN_00b47170 */

void FUN_00b47170(undefined4 *param_1)

{
  undefined auStack_1c [8];
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  FUN_005f0a90(&uStack_14,FUN_005f1e70);
  FUN_00b49d60(&uStack_c,&uStack_14);
  FUN_005f0a90(auStack_1c,FUN_00b46f10);
  FUN_00b49d60(&uStack_14,auStack_1c);
  *param_1 = uStack_c;
  param_1[1] = uStack_8;
  param_1[2] = uStack_14;
  param_1[3] = uStack_10;
  return;
}



/* FUNCTION 24090 ; VA 0x00b471d0 ; FUN_00b471d0 */

void FUN_00b471d0(void)

{
  code *pcVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f31a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b3cae0();
  uStack_8 = 0;
  FUN_00b38e90(uVar2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 24091 ; VA 0x00b47210 ; FUN_00b47210 */

void FUN_00b47210(void)

{
  code *pcVar1;
  undefined4 uVar2;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f31c8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b3cd20();
  uStack_8 = 0;
  FUN_00b38f30(uVar2);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}



/* FUNCTION 24092 ; VA 0x00b47250 ; FUN_00b47250 */

ushort * FUN_00b47250(ushort *param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  byte *pbVar2;
  int *piVar3;
  undefined4 uVar4;
  char cVar5;
  ushort uVar6;
  uint uVar7;
  int iVar8;
  uint extraout_ECX;
  uint uVar9;
  uint auStack_2c [4];
  undefined4 uStack_1c;
  uint uStack_18;
  undefined2 uStack_14;
  undefined2 uStack_12;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar4 = param_3;
  piVar3 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f31e8;
  pvStack_10 = ExceptionList;
  cVar5 = *(char *)(param_2 + 1);
  ExceptionList = &pvStack_10;
LAB_00b47276:
  do {
    if (cVar5 == '\0') {
      piVar1 = (int *)*piVar3;
      if (piVar1 == (int *)0x0) {
LAB_00b472a5:
        *piVar3 = 0;
      }
      else {
        if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
          uVar7 = (**(code **)(*piVar1 + 0x18))();
        }
        else {
          uVar7 = (uint)**(byte **)piVar1[7];
        }
        if (uVar7 == 0xffffffff) goto LAB_00b472a5;
        *(char *)((int)piVar3 + 5) = (char)uVar7;
      }
      *(undefined *)(piVar3 + 1) = 1;
    }
    iVar8 = FUN_0171dc29((int)*(char *)((int)piVar3 + 5));
    if (iVar8 == 0) break;
    cVar5 = FUN_00a8d280(piVar3,uVar4);
    if (cVar5 != '\0') break;
    piVar1 = (int *)*piVar3;
    if (piVar1 != (int *)0x0) {
      if (*(int *)piVar1[7] == 0) {
LAB_00b472f7:
        uVar7 = (**(code **)(*piVar1 + 0x1c))();
      }
      else {
        iVar8 = *(int *)piVar1[0xb];
        if (iVar8 < 1) goto LAB_00b472f7;
        *(int *)piVar1[0xb] = iVar8 + -1;
        pbVar2 = *(byte **)piVar1[7];
        *(byte **)piVar1[7] = pbVar2 + 1;
        uVar7 = (uint)*pbVar2;
      }
      if (uVar7 != 0xffffffff) {
        *(undefined *)(piVar3 + 1) = 0;
        cVar5 = '\0';
        goto LAB_00b47276;
      }
    }
    *piVar3 = 0;
    cVar5 = '\x01';
    *(undefined *)(piVar3 + 1) = 1;
  } while( true );
  uStack_1c = 0;
  uStack_14 = 0;
  uStack_18 = 0xf;
  auStack_2c[0] = auStack_2c[0] & 0xffffff00;
  uStack_12 = 0xffff;
  uStack_8 = 0;
  param_2 = (int *)CONCAT13(0x30,param_2._0_3_);
  uVar6 = FUN_00b371a0(piVar3,uVar4,auStack_2c,2,(int)&param_2 + 3);
  uVar7 = (uint)uVar6;
  *param_1 = 1;
  if (uVar7 + 1 < 2) {
    FUN_00588600(1,uVar7,0);
    uVar7 = extraout_ECX;
  }
  else if (uVar7 < 0x20) {
    *param_1 = uVar6;
    if (0xf < uStack_18) {
      uVar9 = uStack_18 + 1;
      uVar7 = auStack_2c[0];
      if (0xfff < uVar9) {
        uVar7 = *(uint *)(auStack_2c[0] - 4);
        uVar9 = uStack_18 + 0x24;
        if (0x1f < (auStack_2c[0] - uVar7) - 4) goto LAB_00b473d1;
      }
      FUN_01674ea0(uVar7,uVar9);
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_00588600(1,uVar7,1);
LAB_00b473d1:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 24093 ; VA 0x00b473e0 ; FUN_00b473e0 */

void FUN_00b473e0(int *param_1,undefined4 param_2,undefined8 *param_3)

{
  int *piVar1;
  byte *pbVar2;
  char cVar3;
  uint uVar4;
  int iVar5;
  undefined4 ****ppppuVar6;
  undefined8 uVar7;
  undefined auStack_40 [16];
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 ***apppuStack_28 [4];
  uint uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017aa5a0;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_14 = 0xf;
  apppuStack_28[0] = (undefined4 ***)((uint)apppuStack_28[0] & 0xffffff00);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  cVar3 = FUN_00a8d280(param_1,param_2);
  while (cVar3 == '\0') {
    if (*(char *)(param_1 + 1) == '\0') {
      piVar1 = (int *)*param_1;
      if (piVar1 == (int *)0x0) {
LAB_00b47461:
        *param_1 = 0;
      }
      else {
        if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
          uVar4 = (**(code **)(*piVar1 + 0x18))();
        }
        else {
          uVar4 = (uint)**(byte **)piVar1[7];
        }
        if (uVar4 == 0xffffffff) goto LAB_00b47461;
        *(char *)((int)param_1 + 5) = (char)uVar4;
      }
      *(undefined *)(param_1 + 1) = 1;
    }
    iVar5 = FUN_0171db62((int)*(char *)((int)param_1 + 5));
    if (iVar5 == 0) break;
    if (*(char *)(param_1 + 1) == '\0') {
      piVar1 = (int *)*param_1;
      if (piVar1 == (int *)0x0) {
LAB_00b474b1:
        *param_1 = 0;
      }
      else {
        if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
          uVar4 = (**(code **)(*piVar1 + 0x18))();
        }
        else {
          uVar4 = (uint)**(byte **)piVar1[7];
        }
        if (uVar4 == 0xffffffff) goto LAB_00b474b1;
        *(char *)((int)param_1 + 5) = (char)uVar4;
      }
      *(undefined *)(param_1 + 1) = 1;
    }
    FUN_005558a0(*(undefined *)((int)param_1 + 5));
    piVar1 = (int *)*param_1;
    if (piVar1 == (int *)0x0) {
LAB_00b47505:
      *param_1 = 0;
      *(undefined *)(param_1 + 1) = 1;
    }
    else {
      if (*(int *)piVar1[7] == 0) {
LAB_00b474f5:
        uVar4 = (**(code **)(*piVar1 + 0x1c))();
      }
      else {
        iVar5 = *(int *)piVar1[0xb];
        if (iVar5 < 1) goto LAB_00b474f5;
        *(int *)piVar1[0xb] = iVar5 + -1;
        pbVar2 = *(byte **)piVar1[7];
        *(byte **)piVar1[7] = pbVar2 + 1;
        uVar4 = (uint)*pbVar2;
      }
      if (uVar4 == 0xffffffff) goto LAB_00b47505;
      *(undefined *)(param_1 + 1) = 0;
    }
    cVar3 = FUN_00a8d280(param_1,param_2);
  }
  if (uStack_18 != 0) {
    if (uStack_18 < 6) {
      uVar7 = FUN_009d61a0(apppuStack_28);
      iVar5 = 1;
      *param_3 = uVar7;
      for (uVar4 = 6 - uStack_18 & 0xffff; uVar4 != 0; uVar4 = uVar4 - 1) {
        iVar5 = iVar5 * 10;
      }
      uVar7 = FUN_016f39b0(iVar5,0,*(undefined4 *)param_3,(int)((ulonglong)uVar7 >> 0x20));
      *param_3 = uVar7;
    }
    else {
      ppppuVar6 = apppuStack_28;
      if (0xf < uStack_14) {
        ppppuVar6 = (undefined4 ****)apppuStack_28[0];
      }
      uStack_30 = 0;
      uStack_2c = 0xf;
      auStack_40[0] = 0;
      FUN_005542c0(ppppuVar6,6);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uVar7 = FUN_009d61a0(auStack_40);
      *param_3 = uVar7;
      FUN_005507b0();
    }
  }
  if (0xf < uStack_14) {
    uVar4 = uStack_14 + 1;
    ppppuVar6 = (undefined4 ****)apppuStack_28[0];
    if (0xfff < uVar4) {
      ppppuVar6 = (undefined4 ****)apppuStack_28[0][-1];
      uVar4 = uStack_14 + 0x24;
      if (0x1f < (uint)((int)apppuStack_28[0] + (-4 - (int)ppppuVar6))) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(ppppuVar6,uVar4);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24094 ; VA 0x00b47610 ; FUN_00b47610 */

ushort * __thiscall
FUN_00b47610(undefined4 param_1,ushort *param_2,int *param_3,undefined4 param_4,char *param_5)

{
  int *piVar1;
  byte *pbVar2;
  uint uVar3;
  int *piVar4;
  undefined4 uVar5;
  char cVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  char *pcVar10;
  uint uVar11;
  uint extraout_EDX;
  char *pcVar12;
  int in_stack_00000020;
  uint in_stack_00000024;
  uint *in_stack_00000028;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined2 uStack_24;
  undefined2 uStack_22;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uVar5 = param_4;
  piVar4 = param_3;
  puStack_c = &LAB_017f323a;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_20 = 0;
  uStack_8 = 0;
  cStack_11 = '\0';
  cVar6 = *(char *)(param_3 + 1);
  ExceptionList = &pvStack_10;
  uStack_1c = param_1;
  do {
    if (cVar6 == '\0') {
      piVar1 = (int *)*piVar4;
      if (piVar1 == (int *)0x0) {
LAB_00b47678:
        *piVar4 = 0;
      }
      else {
        if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
          uVar7 = (**(code **)(*piVar1 + 0x18))();
        }
        else {
          uVar7 = (uint)**(byte **)piVar1[7];
        }
        if (uVar7 == 0xffffffff) goto LAB_00b47678;
        *(char *)((int)piVar4 + 5) = (char)uVar7;
      }
      *(undefined *)(piVar4 + 1) = 1;
    }
    iVar8 = FUN_0171dc29((int)*(char *)((int)piVar4 + 5));
    if ((iVar8 == 0) || (cVar6 = FUN_00a8d280(piVar4,uVar5), cVar6 != '\0')) break;
    piVar1 = (int *)*piVar4;
    if (piVar1 == (int *)0x0) {
LAB_00b476e1:
      *piVar4 = 0;
      cVar6 = '\x01';
      *(undefined *)(piVar4 + 1) = 1;
    }
    else {
      if (*(int *)piVar1[7] == 0) {
LAB_00b476ca:
        uVar7 = (**(code **)(*piVar1 + 0x1c))();
      }
      else {
        iVar8 = *(int *)piVar1[0xb];
        if (iVar8 < 1) goto LAB_00b476ca;
        *(int *)piVar1[0xb] = iVar8 + -1;
        pbVar2 = *(byte **)piVar1[7];
        *(byte **)piVar1[7] = pbVar2 + 1;
        uVar7 = (uint)*pbVar2;
      }
      if (uVar7 == 0xffffffff) goto LAB_00b476e1;
      *(undefined *)(piVar4 + 1) = 0;
      cVar6 = '\0';
    }
  } while( true );
  param_3 = (int *)0x0;
  pcVar12 = (char *)&param_5;
  if (0xf < in_stack_00000024) {
    pcVar12 = param_5;
  }
LAB_00b47702:
  pcVar10 = (char *)&param_5;
  if (0xf < in_stack_00000024) {
    pcVar10 = param_5;
  }
  if ((pcVar12 == pcVar10 + in_stack_00000020) ||
     (cVar6 = FUN_00a8d280(piVar4,param_4), cVar6 != '\0')) goto LAB_00b47ac2;
  if (*pcVar12 != '%') {
    pcVar12 = pcVar12 + 1;
    if (cStack_11 == '\0') {
      if (*(char *)(piVar4 + 1) == '\0') {
        piVar1 = (int *)*piVar4;
        if (piVar1 == (int *)0x0) {
LAB_00b47a6b:
          *piVar4 = 0;
        }
        else {
          if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
            uVar7 = (**(code **)(*piVar1 + 0x18))();
          }
          else {
            uVar7 = (uint)**(byte **)piVar1[7];
          }
          if (uVar7 == 0xffffffff) goto LAB_00b47a6b;
          *(char *)((int)piVar4 + 5) = (char)uVar7;
        }
        *(undefined *)(piVar4 + 1) = 1;
      }
      piVar1 = (int *)*piVar4;
      if (piVar1 != (int *)0x0) {
        if (*(int *)piVar1[7] == 0) {
LAB_00b47a9e:
          uVar7 = (**(code **)(*piVar1 + 0x1c))();
        }
        else {
          iVar8 = *(int *)piVar1[0xb];
          if (iVar8 < 1) goto LAB_00b47a9e;
          *(int *)piVar1[0xb] = iVar8 + -1;
          pbVar2 = *(byte **)piVar1[7];
          *(byte **)piVar1[7] = pbVar2 + 1;
          uVar7 = (uint)*pbVar2;
        }
        if (uVar7 != 0xffffffff) {
          *(undefined *)(piVar4 + 1) = 0;
          goto LAB_00b47702;
        }
      }
      *piVar4 = 0;
      *(undefined *)(piVar4 + 1) = 1;
      goto LAB_00b47702;
    }
    cStack_11 = '\0';
    goto LAB_00b47702;
  }
  pcVar10 = (char *)&param_5;
  if (0xf < in_stack_00000024) {
    pcVar10 = param_5;
  }
  if (pcVar12 + 1 != pcVar10 + in_stack_00000020) {
    cVar6 = pcVar12[1];
    if (cVar6 == '%') {
      if (*(char *)(piVar4 + 1) == '\0') {
        piVar1 = (int *)*piVar4;
        if (piVar1 == (int *)0x0) {
LAB_00b479cf:
          *piVar4 = 0;
        }
        else {
          if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
            uVar7 = (**(code **)(*piVar1 + 0x18))();
          }
          else {
            uVar7 = (uint)**(byte **)piVar1[7];
          }
          if (uVar7 == 0xffffffff) goto LAB_00b479cf;
          *(char *)((int)piVar4 + 5) = (char)uVar7;
        }
        *(undefined *)(piVar4 + 1) = 1;
      }
      piVar1 = (int *)*piVar4;
      if (piVar1 != (int *)0x0) {
        if (*(int *)piVar1[7] == 0) {
LAB_00b47a02:
          uVar7 = (**(code **)(*piVar1 + 0x1c))();
        }
        else {
          iVar8 = *(int *)piVar1[0xb];
          if (iVar8 < 1) goto LAB_00b47a02;
          *(int *)piVar1[0xb] = iVar8 + -1;
          pbVar2 = *(byte **)piVar1[7];
          *(byte **)piVar1[7] = pbVar2 + 1;
          uVar7 = (uint)*pbVar2;
        }
        if (uVar7 != 0xffffffff) {
          *(undefined *)(piVar4 + 1) = 0;
          pcVar12 = pcVar12 + 2;
          goto LAB_00b47702;
        }
      }
      *piVar4 = 0;
      *(undefined *)(piVar4 + 1) = 1;
    }
    else if (cVar6 == 'B') {
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      uStack_24 = 0;
      uStack_22 = 0xffff;
      uStack_20 = uStack_18 | 2;
      param_3 = (int *)0x0;
      uStack_2c = 0;
      uStack_28 = 0xf;
      uStack_3c = (uint)uStack_3c._1_3_ << 8;
      uStack_18 = uStack_20;
      FUN_00b46fa0(piVar4,param_4,&uStack_3c,&param_3);
      if (in_stack_00000028 != &uStack_3c) {
        uVar7 = in_stack_00000028[5];
        if (0xf < uVar7) {
          uVar3 = *in_stack_00000028;
          uVar11 = uVar7 + 1;
          uVar9 = uVar3;
          if (0xfff < uVar11) {
            uVar9 = *(uint *)(uVar3 - 4);
            uVar11 = uVar7 + 0x24;
            if (0x1f < (uVar3 - uVar9) - 4) goto LAB_00b47b3a;
          }
          FUN_01674ea0(uVar9,uVar11);
        }
        uVar7 = uStack_3c;
        uStack_3c = uStack_3c & 0xffffff00;
        *in_stack_00000028 = uVar7;
        in_stack_00000028[1] = uStack_38;
        in_stack_00000028[2] = uStack_34;
        in_stack_00000028[3] = uStack_30;
        in_stack_00000028[4] = uStack_2c;
        in_stack_00000028[5] = uStack_28;
        uStack_2c = 0;
        uStack_28 = 0xf;
      }
      uStack_18 = uStack_18 & 0xfffffffd;
      *(undefined2 *)(in_stack_00000028 + 6) = uStack_24;
      *(undefined2 *)((int)in_stack_00000028 + 0x1a) = uStack_22;
      uStack_8 = uStack_8 & 0xffffff00;
      if (0xf < uStack_28) {
        uVar11 = uStack_28 + 1;
        uVar7 = uStack_3c;
        if (0xfff < uVar11) {
          uVar7 = *(uint *)(uStack_3c - 4);
          uVar11 = uStack_28 + 0x24;
          if (0x1f < (uStack_3c - uVar7) - 4) goto LAB_00b47b3a;
        }
        FUN_01674ea0(uVar7,uVar11);
      }
      param_3 = (int *)(uint)*(ushort *)((int)in_stack_00000028 + 0x1a);
      if ((uint)*(ushort *)(in_stack_00000028 + 6) < in_stack_00000028[4]) {
        cStack_11 = '\x01';
        pcVar12 = pcVar12 + 2;
        goto LAB_00b47702;
      }
    }
    else if (cVar6 == 'b') {
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uStack_24 = 0;
      uStack_22 = 0xffff;
      uStack_20 = uStack_18 | 1;
      param_3 = (int *)0x0;
      uStack_2c = 0;
      uStack_28 = 0xf;
      uStack_3c = (uint)uStack_3c._1_3_ << 8;
      uStack_18 = uStack_20;
      FUN_00b46fa0(piVar4,param_4,&uStack_3c,&param_3);
      if (in_stack_00000028 != &uStack_3c) {
        FUN_005507b0();
        uVar7 = uStack_3c;
        uStack_3c = uStack_3c & 0xffffff00;
        *in_stack_00000028 = uVar7;
        in_stack_00000028[1] = uStack_38;
        in_stack_00000028[2] = uStack_34;
        in_stack_00000028[3] = uStack_30;
        in_stack_00000028[4] = uStack_2c;
        in_stack_00000028[5] = uStack_28;
        uStack_2c = 0;
        uStack_28 = 0xf;
      }
      uStack_18 = uStack_18 & 0xfffffffe;
      *(undefined2 *)(in_stack_00000028 + 6) = uStack_24;
      *(undefined2 *)((int)in_stack_00000028 + 0x1a) = uStack_22;
      uStack_8 = uStack_8 & 0xffffff00;
      if (0xf < uStack_28) {
        uVar11 = uStack_28 + 1;
        uVar7 = uStack_3c;
        if (0xfff < uVar11) {
          uVar7 = *(uint *)(uStack_3c - 4);
          uVar11 = uStack_28 + 0x24;
          if (0x1f < (uStack_3c - uVar7) - 4) goto LAB_00b47b3a;
        }
        FUN_01674ea0(uVar7,uVar11);
      }
      param_3 = (int *)(uint)*(ushort *)((int)in_stack_00000028 + 0x1a);
      if ((uint)*(ushort *)(in_stack_00000028 + 6) < in_stack_00000028[4]) {
        cStack_11 = '\x01';
        pcVar12 = pcVar12 + 2;
        goto LAB_00b47702;
      }
    }
    else if (cVar6 == 'm') {
      uVar7 = FUN_00b392f0(piVar4,param_4,2);
      param_3 = (int *)(uVar7 & 0xffff);
      pcVar12 = pcVar12 + 2;
      goto LAB_00b47702;
    }
    pcVar12 = pcVar12 + 2;
    goto LAB_00b47702;
  }
LAB_00b47ac2:
  *param_2 = 1;
  if (((uint)param_3 & 0xffff) + 1 < 2) {
    FUN_00588640(1,param_3,0);
    uVar7 = extraout_EDX;
  }
  else {
    uVar7 = (uint)param_3;
    if ((ushort)param_3 < 0xd) {
      *param_2 = (ushort)param_3;
      if (0xf < in_stack_00000024) {
        uVar7 = in_stack_00000024 + 1;
        pcVar12 = param_5;
        if (0xfff < uVar7) {
          pcVar12 = *(char **)(param_5 + -4);
          uVar7 = in_stack_00000024 + 0x24;
          if ((char *)0x1f < param_5 + (-4 - (int)pcVar12)) goto LAB_00b47b3a;
        }
        FUN_01674ea0(pcVar12,uVar7);
      }
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  FUN_00588640(1,uVar7,1);
LAB_00b47b3a:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 24095 ; VA 0x00b47b40 ; FUN_00b47b40 */

ushort * __thiscall
FUN_00b47b40(undefined4 param_1,ushort *param_2,int *param_3,undefined4 param_4,char *param_5)

{
  int *piVar1;
  byte *pbVar2;
  uint uVar3;
  int *piVar4;
  undefined4 uVar5;
  char cVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  char *pcVar10;
  uint uVar11;
  uint extraout_EDX;
  char *pcVar12;
  int in_stack_00000020;
  uint in_stack_00000024;
  uint *in_stack_00000028;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  undefined2 uStack_24;
  undefined2 uStack_22;
  uint uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uVar5 = param_4;
  piVar4 = param_3;
  puStack_c = &LAB_017f323a;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_20 = 0;
  uStack_8 = 0;
  cStack_11 = '\0';
  cVar6 = *(char *)(param_3 + 1);
  ExceptionList = &pvStack_10;
  uStack_1c = param_1;
  do {
    if (cVar6 == '\0') {
      piVar1 = (int *)*piVar4;
      if (piVar1 == (int *)0x0) {
LAB_00b47ba8:
        *piVar4 = 0;
      }
      else {
        if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
          uVar7 = (**(code **)(*piVar1 + 0x18))();
        }
        else {
          uVar7 = (uint)**(byte **)piVar1[7];
        }
        if (uVar7 == 0xffffffff) goto LAB_00b47ba8;
        *(char *)((int)piVar4 + 5) = (char)uVar7;
      }
      *(undefined *)(piVar4 + 1) = 1;
    }
    iVar8 = FUN_0171dc29((int)*(char *)((int)piVar4 + 5));
    if ((iVar8 == 0) || (cVar6 = FUN_00a8d280(piVar4,uVar5), cVar6 != '\0')) break;
    piVar1 = (int *)*piVar4;
    if (piVar1 == (int *)0x0) {
LAB_00b47c11:
      *piVar4 = 0;
      cVar6 = '\x01';
      *(undefined *)(piVar4 + 1) = 1;
    }
    else {
      if (*(int *)piVar1[7] == 0) {
LAB_00b47bfa:
        uVar7 = (**(code **)(*piVar1 + 0x1c))();
      }
      else {
        iVar8 = *(int *)piVar1[0xb];
        if (iVar8 < 1) goto LAB_00b47bfa;
        *(int *)piVar1[0xb] = iVar8 + -1;
        pbVar2 = *(byte **)piVar1[7];
        *(byte **)piVar1[7] = pbVar2 + 1;
        uVar7 = (uint)*pbVar2;
      }
      if (uVar7 == 0xffffffff) goto LAB_00b47c11;
      *(undefined *)(piVar4 + 1) = 0;
      cVar6 = '\0';
    }
  } while( true );
  param_3 = (int *)0x0;
  pcVar12 = (char *)&param_5;
  if (0xf < in_stack_00000024) {
    pcVar12 = param_5;
  }
LAB_00b47c32:
  pcVar10 = (char *)&param_5;
  if (0xf < in_stack_00000024) {
    pcVar10 = param_5;
  }
  if ((pcVar12 == pcVar10 + in_stack_00000020) ||
     (cVar6 = FUN_00a8d280(piVar4,param_4), cVar6 != '\0')) goto LAB_00b47ff2;
  if (*pcVar12 != '%') {
    pcVar12 = pcVar12 + 1;
    if (cStack_11 == '\0') {
      if (*(char *)(piVar4 + 1) == '\0') {
        piVar1 = (int *)*piVar4;
        if (piVar1 == (int *)0x0) {
LAB_00b47f9b:
          *piVar4 = 0;
        }
        else {
          if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
            uVar7 = (**(code **)(*piVar1 + 0x18))();
          }
          else {
            uVar7 = (uint)**(byte **)piVar1[7];
          }
          if (uVar7 == 0xffffffff) goto LAB_00b47f9b;
          *(char *)((int)piVar4 + 5) = (char)uVar7;
        }
        *(undefined *)(piVar4 + 1) = 1;
      }
      piVar1 = (int *)*piVar4;
      if (piVar1 != (int *)0x0) {
        if (*(int *)piVar1[7] == 0) {
LAB_00b47fce:
          uVar7 = (**(code **)(*piVar1 + 0x1c))();
        }
        else {
          iVar8 = *(int *)piVar1[0xb];
          if (iVar8 < 1) goto LAB_00b47fce;
          *(int *)piVar1[0xb] = iVar8 + -1;
          pbVar2 = *(byte **)piVar1[7];
          *(byte **)piVar1[7] = pbVar2 + 1;
          uVar7 = (uint)*pbVar2;
        }
        if (uVar7 != 0xffffffff) {
          *(undefined *)(piVar4 + 1) = 0;
          goto LAB_00b47c32;
        }
      }
      *piVar4 = 0;
      *(undefined *)(piVar4 + 1) = 1;
      goto LAB_00b47c32;
    }
    cStack_11 = '\0';
    goto LAB_00b47c32;
  }
  pcVar10 = (char *)&param_5;
  if (0xf < in_stack_00000024) {
    pcVar10 = param_5;
  }
  if (pcVar12 + 1 != pcVar10 + in_stack_00000020) {
    cVar6 = pcVar12[1];
    if (cVar6 == '%') {
      if (*(char *)(piVar4 + 1) == '\0') {
        piVar1 = (int *)*piVar4;
        if (piVar1 == (int *)0x0) {
LAB_00b47eff:
          *piVar4 = 0;
        }
        else {
          if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
            uVar7 = (**(code **)(*piVar1 + 0x18))();
          }
          else {
            uVar7 = (uint)**(byte **)piVar1[7];
          }
          if (uVar7 == 0xffffffff) goto LAB_00b47eff;
          *(char *)((int)piVar4 + 5) = (char)uVar7;
        }
        *(undefined *)(piVar4 + 1) = 1;
      }
      piVar1 = (int *)*piVar4;
      if (piVar1 != (int *)0x0) {
        if (*(int *)piVar1[7] == 0) {
LAB_00b47f32:
          uVar7 = (**(code **)(*piVar1 + 0x1c))();
        }
        else {
          iVar8 = *(int *)piVar1[0xb];
          if (iVar8 < 1) goto LAB_00b47f32;
          *(int *)piVar1[0xb] = iVar8 + -1;
          pbVar2 = *(byte **)piVar1[7];
          *(byte **)piVar1[7] = pbVar2 + 1;
          uVar7 = (uint)*pbVar2;
        }
        if (uVar7 != 0xffffffff) {
          *(undefined *)(piVar4 + 1) = 0;
          pcVar12 = pcVar12 + 2;
          goto LAB_00b47c32;
        }
      }
      *piVar4 = 0;
      *(undefined *)(piVar4 + 1) = 1;
    }
    else if (cVar6 == 'A') {
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      uStack_24 = 0;
      uStack_22 = 0xffff;
      uStack_20 = uStack_18 | 2;
      param_3 = (int *)0x0;
      uStack_2c = 0;
      uStack_28 = 0xf;
      uStack_3c = (uint)uStack_3c._1_3_ << 8;
      uStack_18 = uStack_20;
      FUN_00b46fa0(piVar4,param_4,&uStack_3c,&param_3);
      if (in_stack_00000028 != &uStack_3c) {
        uVar7 = in_stack_00000028[5];
        if (0xf < uVar7) {
          uVar3 = *in_stack_00000028;
          uVar11 = uVar7 + 1;
          uVar9 = uVar3;
          if (0xfff < uVar11) {
            uVar9 = *(uint *)(uVar3 - 4);
            uVar11 = uVar7 + 0x24;
            if (0x1f < (uVar3 - uVar9) - 4) goto LAB_00b48067;
          }
          FUN_01674ea0(uVar9,uVar11);
        }
        uVar7 = uStack_3c;
        uStack_3c = uStack_3c & 0xffffff00;
        *in_stack_00000028 = uVar7;
        in_stack_00000028[1] = uStack_38;
        in_stack_00000028[2] = uStack_34;
        in_stack_00000028[3] = uStack_30;
        in_stack_00000028[4] = uStack_2c;
        in_stack_00000028[5] = uStack_28;
        uStack_2c = 0;
        uStack_28 = 0xf;
      }
      uStack_18 = uStack_18 & 0xfffffffd;
      *(undefined2 *)(in_stack_00000028 + 6) = uStack_24;
      *(undefined2 *)((int)in_stack_00000028 + 0x1a) = uStack_22;
      uStack_8 = uStack_8 & 0xffffff00;
      if (0xf < uStack_28) {
        uVar11 = uStack_28 + 1;
        uVar7 = uStack_3c;
        if (0xfff < uVar11) {
          uVar7 = *(uint *)(uStack_3c - 4);
          uVar11 = uStack_28 + 0x24;
          if (0x1f < (uStack_3c - uVar7) - 4) goto LAB_00b48067;
        }
        FUN_01674ea0(uVar7,uVar11);
      }
      param_3 = (int *)(uint)*(ushort *)((int)in_stack_00000028 + 0x1a);
      if ((uint)*(ushort *)(in_stack_00000028 + 6) < in_stack_00000028[4]) {
        cStack_11 = '\x01';
        pcVar12 = pcVar12 + 2;
        goto LAB_00b47c32;
      }
    }
    else if (cVar6 == 'a') {
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      uStack_24 = 0;
      uStack_22 = 0xffff;
      uStack_20 = uStack_18 | 1;
      param_3 = (int *)0x0;
      uStack_2c = 0;
      uStack_28 = 0xf;
      uStack_3c = (uint)uStack_3c._1_3_ << 8;
      uStack_18 = uStack_20;
      FUN_00b46fa0(piVar4,param_4,&uStack_3c,&param_3);
      if (in_stack_00000028 != &uStack_3c) {
        FUN_005507b0();
        uVar7 = uStack_3c;
        uStack_3c = uStack_3c & 0xffffff00;
        *in_stack_00000028 = uVar7;
        in_stack_00000028[1] = uStack_38;
        in_stack_00000028[2] = uStack_34;
        in_stack_00000028[3] = uStack_30;
        in_stack_00000028[4] = uStack_2c;
        in_stack_00000028[5] = uStack_28;
        uStack_2c = 0;
        uStack_28 = 0xf;
      }
      uStack_18 = uStack_18 & 0xfffffffe;
      *(undefined2 *)(in_stack_00000028 + 6) = uStack_24;
      *(undefined2 *)((int)in_stack_00000028 + 0x1a) = uStack_22;
      uStack_8 = uStack_8 & 0xffffff00;
      if (0xf < uStack_28) {
        uVar11 = uStack_28 + 1;
        uVar7 = uStack_3c;
        if (0xfff < uVar11) {
          uVar7 = *(uint *)(uStack_3c - 4);
          uVar11 = uStack_28 + 0x24;
          if (0x1f < (uStack_3c - uVar7) - 4) goto LAB_00b48067;
        }
        FUN_01674ea0(uVar7,uVar11);
      }
      param_3 = (int *)(uint)*(ushort *)((int)in_stack_00000028 + 0x1a);
      if ((uint)*(ushort *)(in_stack_00000028 + 6) < in_stack_00000028[4]) {
        cStack_11 = '\x01';
        pcVar12 = pcVar12 + 2;
        goto LAB_00b47c32;
      }
    }
    else if (cVar6 == 'w') {
      uVar7 = FUN_00b392f0(piVar4,param_4,2);
      param_3 = (int *)(uVar7 & 0xffff);
      pcVar12 = pcVar12 + 2;
      goto LAB_00b47c32;
    }
    pcVar12 = pcVar12 + 2;
    goto LAB_00b47c32;
  }
LAB_00b47ff2:
  *param_2 = 0;
  if (((uint)param_3 & 0xffff) == 0xffffffff) {
    FUN_00b47210(0,param_3,0);
    uVar7 = extraout_EDX;
  }
  else {
    uVar7 = (uint)param_3;
    if ((ushort)param_3 < 7) {
      *param_2 = (ushort)param_3;
      if (0xf < in_stack_00000024) {
        uVar7 = in_stack_00000024 + 1;
        pcVar12 = param_5;
        if (0xfff < uVar7) {
          pcVar12 = *(char **)(param_5 + -4);
          uVar7 = in_stack_00000024 + 0x24;
          if ((char *)0x1f < param_5 + (-4 - (int)pcVar12)) goto LAB_00b48067;
        }
        FUN_01674ea0(pcVar12,uVar7);
      }
      ExceptionList = pvStack_10;
      return param_2;
    }
  }
  FUN_00b47210(0,uVar7,1);
LAB_00b48067:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 24096 ; VA 0x00b48070 ; FUN_00b48070 */

ushort * FUN_00b48070(ushort *param_1,int *param_2,undefined4 param_3,char *param_4)

{
  int *piVar1;
  byte *pbVar2;
  int *piVar3;
  undefined4 uVar4;
  char cVar5;
  short sVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  char *pcVar10;
  char *pcVar11;
  int in_stack_00000020;
  uint in_stack_00000024;
  undefined4 in_stack_00000028;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uVar4 = param_3;
  piVar3 = param_2;
  puStack_c = &LAB_017f3258;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  cVar5 = *(char *)(param_2 + 1);
  ExceptionList = &pvStack_10;
LAB_00b480a0:
  do {
    if (cVar5 == '\0') {
      piVar1 = (int *)*piVar3;
      if (piVar1 == (int *)0x0) {
LAB_00b480cf:
        *piVar3 = 0;
      }
      else {
        if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
          uVar7 = (**(code **)(*piVar1 + 0x18))();
        }
        else {
          uVar7 = (uint)**(byte **)piVar1[7];
        }
        if (uVar7 == 0xffffffff) goto LAB_00b480cf;
        *(char *)((int)piVar3 + 5) = (char)uVar7;
      }
      *(undefined *)(piVar3 + 1) = 1;
    }
    iVar8 = FUN_0171dc29((int)*(char *)((int)piVar3 + 5));
    if (iVar8 == 0) break;
    cVar5 = FUN_00a8d280(piVar3,uVar4);
    if (cVar5 != '\0') break;
    piVar1 = (int *)*piVar3;
    if (piVar1 != (int *)0x0) {
      if (*(int *)piVar1[7] == 0) {
LAB_00b48121:
        uVar7 = (**(code **)(*piVar1 + 0x1c))();
      }
      else {
        iVar8 = *(int *)piVar1[0xb];
        if (iVar8 < 1) goto LAB_00b48121;
        *(int *)piVar1[0xb] = iVar8 + -1;
        pbVar2 = *(byte **)piVar1[7];
        *(byte **)piVar1[7] = pbVar2 + 1;
        uVar7 = (uint)*pbVar2;
      }
      if (uVar7 != 0xffffffff) {
        *(undefined *)(piVar3 + 1) = 0;
        cVar5 = '\0';
        goto LAB_00b480a0;
      }
    }
    *piVar3 = 0;
    cVar5 = '\x01';
    *(undefined *)(piVar3 + 1) = 1;
  } while( true );
  uVar7 = 0;
  pcVar11 = (char *)&param_4;
  if (0xf < in_stack_00000024) {
    pcVar11 = param_4;
  }
LAB_00b48154:
  do {
    pcVar10 = (char *)&param_4;
    if (0xf < in_stack_00000024) {
      pcVar10 = param_4;
    }
    if (pcVar11 == pcVar10 + in_stack_00000020) break;
    cVar5 = FUN_00a8d280(piVar3,param_3);
    if (cVar5 != '\0') break;
    if (*pcVar11 == '%') {
      pcVar10 = (char *)&param_4;
      if (0xf < in_stack_00000024) {
        pcVar10 = param_4;
      }
      if (pcVar11 + 1 == pcVar10 + in_stack_00000020) break;
      cVar5 = pcVar11[1];
      if (cVar5 == '%') {
        if (*(char *)(piVar3 + 1) == '\0') {
          piVar1 = (int *)*piVar3;
          if (piVar1 == (int *)0x0) {
LAB_00b48231:
            *piVar3 = 0;
          }
          else {
            if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
              uVar9 = (**(code **)(*piVar1 + 0x18))();
            }
            else {
              uVar9 = (uint)**(byte **)piVar1[7];
            }
            if (uVar9 == 0xffffffff) goto LAB_00b48231;
            *(char *)((int)piVar3 + 5) = (char)uVar9;
          }
          *(undefined *)(piVar3 + 1) = 1;
        }
        piVar1 = (int *)*piVar3;
        if (piVar1 != (int *)0x0) {
          if (*(int *)piVar1[7] == 0) {
LAB_00b48264:
            uVar9 = (**(code **)(*piVar1 + 0x1c))();
          }
          else {
            iVar8 = *(int *)piVar1[0xb];
            if (iVar8 < 1) goto LAB_00b48264;
            *(int *)piVar1[0xb] = iVar8 + -1;
            pbVar2 = *(byte **)piVar1[7];
            *(byte **)piVar1[7] = pbVar2 + 1;
            uVar9 = (uint)*pbVar2;
          }
          if (uVar9 != 0xffffffff) {
            *(undefined *)(piVar3 + 1) = 0;
            pcVar11 = pcVar11 + 2;
            goto LAB_00b48154;
          }
        }
        *piVar3 = 0;
        *(undefined *)(piVar3 + 1) = 1;
      }
      else {
        if (cVar5 == 'Y') {
          param_2 = (int *)CONCAT13(0x30,param_2._0_3_);
          uVar7 = FUN_00b371a0(piVar3,param_3,in_stack_00000028,4,(int)&param_2 + 3);
          uVar7 = uVar7 & 0xffff;
          pcVar11 = pcVar11 + 2;
          goto LAB_00b48154;
        }
        if (cVar5 == 'y') {
          param_2 = (int *)CONCAT13(0x30,param_2._0_3_);
          sVar6 = FUN_00b371a0(piVar3,param_3,in_stack_00000028,2,(int)&param_2 + 3);
          pcVar11 = pcVar11 + 2;
          uVar7 = (uint)(ushort)(sVar6 + 2000);
          goto LAB_00b48154;
        }
      }
      pcVar11 = pcVar11 + 2;
      goto LAB_00b48154;
    }
    pcVar11 = pcVar11 + 1;
    if (*(char *)(piVar3 + 1) == '\0') {
      piVar1 = (int *)*piVar3;
      if (piVar1 == (int *)0x0) {
LAB_00b482ba:
        *piVar3 = 0;
      }
      else {
        if ((*(byte **)piVar1[7] == (byte *)0x0) || (*(int *)piVar1[0xb] < 1)) {
          uVar9 = (**(code **)(*piVar1 + 0x18))();
        }
        else {
          uVar9 = (uint)**(byte **)piVar1[7];
        }
        if (uVar9 == 0xffffffff) goto LAB_00b482ba;
        *(char *)((int)piVar3 + 5) = (char)uVar9;
      }
      *(undefined *)(piVar3 + 1) = 1;
    }
    piVar1 = (int *)*piVar3;
    if (piVar1 != (int *)0x0) {
      if (*(int *)piVar1[7] == 0) {
LAB_00b482ed:
        uVar9 = (**(code **)(*piVar1 + 0x1c))();
      }
      else {
        iVar8 = *(int *)piVar1[0xb];
        if (iVar8 < 1) goto LAB_00b482ed;
        *(int *)piVar1[0xb] = iVar8 + -1;
        pbVar2 = *(byte **)piVar1[7];
        *(byte **)piVar1[7] = pbVar2 + 1;
        uVar9 = (uint)*pbVar2;
      }
      if (uVar9 != 0xffffffff) {
        *(undefined *)(piVar3 + 1) = 0;
        goto LAB_00b48154;
      }
    }
    *piVar3 = 0;
    *(undefined *)(piVar3 + 1) = 1;
  } while( true );
  *param_1 = 0x578;
  if (uVar7 + 1 < 0x579) {
    FUN_00588680(0x578,uVar7,0);
  }
  else if ((ushort)uVar7 < 0x2711) {
    *param_1 = (ushort)uVar7;
    if (0xf < in_stack_00000024) {
      uVar7 = in_stack_00000024 + 1;
      pcVar11 = param_4;
      if (0xfff < uVar7) {
        pcVar11 = *(char **)(param_4 + -4);
        uVar7 = in_stack_00000024 + 0x24;
        if ((char *)0x1f < param_4 + (-4 - (int)pcVar11)) goto LAB_00b48391;
      }
      FUN_01674ea0(pcVar11,uVar7);
    }
    ExceptionList = pvStack_10;
    return param_1;
  }
  FUN_00588680(0x578,uVar7,1);
LAB_00b48391:
                    /* WARNING: Subroutine does not return */
  FUN_017167a3();
}



/* FUNCTION 24097 ; VA 0x00b483a0 ; FUN_00b483a0 */

undefined4 FUN_00b483a0(uint *param_1)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint *puVar5;
  undefined4 *puVar6;
  undefined auStack_70 [24];
  undefined auStack_58 [48];
  uint uStack_28;
  uint uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3280;
  pvStack_10 = ExceptionList;
  uStack_20 = 0xfffffffe;
  uStack_1c = 0x7fffffff;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_0056a9c0(0);
  FUN_005672c0(uVar2,&uStack_20);
  if ((*param_1 == uStack_28) && (param_1[1] == uStack_24)) {
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Invalid Datetime.\n");
  }
  FUN_005ef640(0x18,0,0,0,0);
  uVar2 = FUN_005ef640(0,0,0,1,0);
  FUN_00614fe0(&uStack_20,uVar2);
  puVar6 = &uStack_20;
  uVar2 = FUN_0056a9c0(4);
  FUN_005672c0(uVar2,puVar6);
  if (((int)uStack_24 <= (int)param_1[1]) &&
     (((int)uStack_24 < (int)param_1[1] || (uStack_28 < *param_1)))) {
    uVar4 = 4;
    uVar3 = 0xb48499;
    FUN_00610c80(4);
    FUN_00610c80(4);
    FUN_00b3c6a0(uVar3,uVar4,uVar2,puVar6);
    FUN_00b4a2f0(auStack_58);
    uStack_8 = 0;
    uVar2 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Over the max DateTime supported: %s",uVar2);
  }
  puVar5 = &uStack_28;
  uVar2 = 3;
  FUN_0061f5c0(puVar5,3);
  uVar1 = param_1[1];
  if (((int)uVar1 <= (int)uStack_24) && (((int)uVar1 < (int)uStack_24 || (*param_1 < uStack_28)))) {
    uVar4 = 3;
    uVar3 = 0xb484dd;
    FUN_00610c80(3);
    FUN_00610c80(3);
    FUN_00b3c6a0(uVar3,uVar4,puVar5,uVar2);
    FUN_00b4a2f0(auStack_70);
    uStack_8 = 1;
    uVar2 = FUN_005543f0();
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Below the min DateTime supported: %s",uVar2);
  }
  ExceptionList = pvStack_10;
  return CONCAT31((int3)(uVar1 >> 8),1);
}



/* FUNCTION 24098 ; VA 0x00b48520 ; FUN_00b48520 */

undefined4 FUN_00b48520(undefined4 param_1,undefined4 *param_2)

{
  code *pcVar1;
  undefined4 *puVar2;
  ushort uVar3;
  undefined4 uVar4;
  uint uVar5;
  uint extraout_ECX;
  uint extraout_ECX_00;
  uint extraout_ECX_01;
  uint extraout_ECX_02;
  uint extraout_ECX_03;
  uint uVar6;
  uint uVar7;
  undefined auStack_c [8];
  
  puVar2 = param_2;
  uVar5 = (uint)*(ushort *)(param_2 + 3);
  uVar7 = 1;
  if (uVar5 + 1 < 2) {
    FUN_00588600(1,uVar5,0,1);
    uVar5 = extraout_ECX;
LAB_00b485ec:
    uVar6 = 1;
    FUN_00588600(1,uVar5,1,uVar7);
    uVar5 = extraout_ECX_00;
LAB_00b485f6:
    FUN_00588640(1,uVar5,0,uVar6,uVar7);
    uVar5 = extraout_ECX_01;
LAB_00b48600:
    uVar4 = 1;
    FUN_00588640(1,uVar5,1,uVar6,uVar7);
    uVar5 = extraout_ECX_02;
  }
  else {
    if (0x1f < uVar5) goto LAB_00b485ec;
    uVar7 = (uint)*(ushort *)(param_2 + 3);
    uVar5 = (uint)(ushort)(*(short *)(param_2 + 4) + 1U);
    uVar6 = 1;
    if (uVar5 + 1 < 2) goto LAB_00b485f6;
    if (0xc < uVar5) goto LAB_00b48600;
    uVar6 = (uint)(ushort)(*(short *)(param_2 + 4) + 1U);
    uVar3 = *(short *)(param_2 + 5) + 0x76c;
    uVar5 = (uint)uVar3;
    uVar4 = 0x578;
    if (0x578 < uVar5 + 1) {
      if (uVar3 < 0x2711) {
        FUN_0056a920(uVar3,uVar6,uVar7);
        FUN_005ef640(puVar2[2],puVar2[1],*puVar2,0,0);
        FUN_005672c0(&param_2,auStack_c);
        return param_1;
      }
      goto LAB_00b48617;
    }
  }
  FUN_00588680(0x578,uVar5,0,uVar4,uVar6);
  uVar5 = extraout_ECX_03;
LAB_00b48617:
  FUN_00588680(0x578,uVar5,1,uVar4,uVar6);
  pcVar1 = (code *)swi(3);
  uVar4 = (*pcVar1)();
  return uVar4;
}



/* FUNCTION 24099 ; VA 0x00b48630 ; FUN_00b48630 */

undefined4 __thiscall
FUN_00b48630(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,int *param_7)

{
  int iVar1;
  code *pcVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined auStack_4c [36];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  iVar1 = *param_7;
  if (((iVar1 != -2) && (iVar1 != 0)) && (iVar1 != -1)) {
    puVar3 = (undefined4 *)FUN_00b4b2d0(auStack_4c,param_7);
    uStack_28 = *puVar3;
    uStack_24 = puVar3[1];
    uStack_20 = puVar3[2];
    uStack_1c = puVar3[3];
    uStack_18 = puVar3[4];
    uStack_14 = puVar3[5];
    uStack_10 = puVar3[6];
    uStack_c = puVar3[7];
    uStack_8 = puVar3[8];
    pcVar2 = *(code **)(*param_1 + 0x18);
    FUN_0054ef60(param_1 + 2);
    (*pcVar2)(param_2,param_3,param_4,param_5,param_6,&uStack_28);
    return param_2;
  }
  if (iVar1 == -2) {
    uVar4 = 0;
  }
  else if (iVar1 == 0) {
    uVar4 = 1;
  }
  else {
    uVar4 = 5;
    if (iVar1 == -1) {
      uVar4 = 2;
    }
  }
  (**(code **)(*param_1 + 0x14))(param_2,param_3,param_4,param_5,param_6,uVar4);
  return param_2;
}



/* FUNCTION 24100 ; VA 0x00b486f0 ; FUN_00b486f0 */

/* WARNING: Type propagation algorithm not settling */

undefined4 __thiscall
FUN_00b486f0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,int *param_7)

{
  char cVar1;
  int iVar2;
  code *pcVar3;
  int *piVar4;
  undefined uVar5;
  int *piVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 *******pppppppuVar9;
  int *piVar10;
  undefined4 *puVar11;
  char *pcVar12;
  uint uVar13;
  undefined8 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined auStack_170 [36];
  undefined4 uStack_14c;
  undefined4 uStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined4 uStack_13c;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  int iStack_12c;
  undefined **appuStack_128 [15];
  int iStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_dc;
  undefined **ppuStack_d8;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 auStack_84 [6];
  int *piStack_6c;
  int aiStack_68 [5];
  uint uStack_54;
  undefined4 *******pppppppuStack_50;
  undefined4 ******ppppppuStack_4c;
  undefined4 ******ppppppuStack_48;
  undefined4 ******ppppppuStack_44;
  undefined8 uStack_40;
  undefined1 *puStack_38;
  char *pcStack_34;
  int *piStack_30;
  char *pcStack_2c;
  undefined auStack_28 [8];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3361;
  pvStack_10 = ExceptionList;
  uVar13 = 0;
  pcStack_2c = (char *)0x0;
  iVar8 = *param_7;
  iVar2 = param_7[1];
  piStack_6c = param_1;
  if ((((iVar8 != -2) || (iVar2 != 0x7fffffff)) && ((iVar8 != -1 || (iVar2 != 0x7fffffff)))) &&
     ((iVar8 != 0 || (iVar2 != -0x80000000)))) {
    ExceptionList = &pvStack_10;
    FUN_0054ef60(param_1 + 2);
    uStack_8 = 0;
    pcVar12 = "%H:%M:%S";
    do {
      pcStack_2c = pcVar12;
      pcVar12 = pcStack_2c + 1;
    } while (*pcStack_2c != '\0');
    pcVar12 = "%T";
    do {
      pcStack_34 = pcVar12;
      pcVar12 = pcStack_34 + 1;
    } while (*pcStack_34 != '\0');
    puStack_38 = &DAT_01952450;
    FUN_00b36aa0(aiStack_68,CONCAT44(pcStack_34,&DAT_01952450),piStack_30,&DAT_01952454,pcStack_2c);
    pcVar12 = "%H:%M";
    do {
      pcStack_2c = pcVar12;
      pcVar12 = pcStack_2c + 1;
    } while (*pcStack_2c != '\0');
    pcVar12 = "%R";
    do {
      pcStack_34 = pcVar12;
      pcVar12 = pcStack_34 + 1;
    } while (*pcStack_34 != '\0');
    puStack_38 = &DAT_01952460;
    piVar6 = aiStack_68;
    FUN_00b36aa0(piVar6,CONCAT44(pcStack_34,&DAT_01952460),piStack_30,&DAT_01952464,pcStack_2c);
    uStack_40 = 0xf00000000;
    pppppppuStack_50 = (undefined4 *******)((uint)pppppppuStack_50 & 0xffffff00);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar8 = FUN_0058eea0(PTR_DAT_01d66f7c,0);
    if (iVar8 != -1) {
      uVar15 = 0;
      uVar7 = FUN_00b4a230(&pcStack_34);
      pppppppuVar9 = (undefined4 *******)FUN_00b42a50(auStack_84,uVar7,uVar15);
      if (&pppppppuStack_50 != (undefined4 ********)pppppppuVar9) {
        FUN_005507b0();
        pppppppuStack_50 = (undefined4 *******)*pppppppuVar9;
        ppppppuStack_4c = pppppppuVar9[1];
        ppppppuStack_48 = pppppppuVar9[2];
        ppppppuStack_44 = pppppppuVar9[3];
        uStack_40 = *(undefined8 *)(pppppppuVar9 + 4);
        pppppppuVar9[4] = (undefined4 ******)0x0;
        pppppppuVar9[5] = (undefined4 ******)0xf;
        *(undefined *)pppppppuVar9 = 0;
      }
      FUN_005507b0();
      piVar4 = *(int **)(*(int *)(param_5 + 0x30) + 4);
      uStack_8._0_1_ = 2;
      piStack_30 = piVar4;
      (**(code **)(*piVar4 + 4))();
      uVar13 = 1;
      uStack_8._0_1_ = 3;
      piVar10 = (int *)FUN_00564bf0(&pcStack_34);
      uVar5 = (**(code **)(*piVar10 + 0xc))();
      pcStack_2c = (char *)CONCAT31(pcStack_2c._1_3_,uVar5);
      uStack_8._0_1_ = 4;
      if (piVar4 != (int *)0x0) {
        puVar11 = (undefined4 *)(**(code **)(*piVar4 + 8))();
        if (puVar11 != (undefined4 *)0x0) {
          (**(code **)*puVar11)(1);
        }
      }
      uStack_8._0_1_ = 1;
      iStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      pcVar12 = PTR_DAT_01d66f80;
      do {
        cVar1 = *pcVar12;
        pcVar12 = pcVar12 + 1;
      } while (cVar1 != '\0');
      FUN_005542c0(PTR_DAT_01d66f80,(int)pcVar12 - (int)(PTR_DAT_01d66f80 + 1));
      uStack_8._0_1_ = 5;
      FUN_005558a0(pcStack_2c);
      pppppppuVar9 = &pppppppuStack_50;
      if (0xf < uStack_40._4_4_) {
        pppppppuVar9 = pppppppuStack_50;
      }
      FUN_00554150(pppppppuVar9,(int)uStack_40);
      FUN_00b38cc0(aiStack_68,&PTR_DAT_01d66f7c,auStack_28);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_005507b0();
    }
    iVar8 = FUN_0058eea0(PTR_DAT_01d66f9c,0);
    if (iVar8 != -1) {
      iStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0(&DAT_018bc9b8,0);
      iVar8 = iStack_18;
      uVar13 = uVar13 | 6;
      FUN_005507b0();
      if (iVar8 == 0) {
        FUN_00b36960(aiStack_68,&PTR_DAT_01d66f9c);
      }
      else {
        iStack_18 = 0;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        uStack_8._0_1_ = 6;
        FUN_00b38cc0(aiStack_68,&PTR_DAT_01d66f9c,auStack_28);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_005507b0();
      }
    }
    iVar8 = FUN_0058eea0(PTR_DAT_01d66f90,0);
    if (iVar8 != -1) {
      iStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0(&DAT_018bc9b8,0);
      iVar8 = iStack_18;
      piStack_30 = (int *)(uVar13 | 0x18);
      FUN_005507b0();
      if (iVar8 == 0) {
        appuStack_128[0] = &PTR_018be314;
        uStack_8 = CONCAT31(uStack_8._1_3_,7);
        pcStack_2c = (char *)(uVar13 | 0x38);
        ppuStack_d8 = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
        uStack_dc = 0x48;
        FUN_00554f20(appuStack_128 + 1,0);
        uStack_8 = 9;
        *(undefined ***)(appuStack_128[0][1] + (int)appuStack_128) =
             std::
             basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
             vftable;
        *(undefined **)((int)&iStack_12c + (int)appuStack_128[0][1]) = appuStack_128[0][1] + -0x50;
        FUN_0054ee60();
        appuStack_128[1] =
             std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
             vftable;
        iStack_ec = iVar8;
        uStack_e8 = 4;
        uStack_8._0_1_ = 10;
        FUN_005ed940(appuStack_128,0x20);
        FUN_00558890();
        FUN_0058c420(auStack_28);
        uVar13 = (uint)piStack_30 | 0xa0;
        uStack_8._0_1_ = 0xb;
        FUN_00b36a00(aiStack_68,auStack_28);
        FUN_005507b0();
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_00570540();
      }
      else {
        iStack_18 = 0;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        FUN_005542c0(&DAT_018bc9b8,0);
        uVar13 = uVar13 | 0x318;
        uStack_8._0_1_ = 0xc;
        FUN_00b38cc0(aiStack_68,&PTR_DAT_01d66f90,auStack_28);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_005507b0();
      }
    }
    iVar8 = FUN_0058eea0(PTR_DAT_01d66f8c,0);
    if (iVar8 != -1) {
      iStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0(&DAT_018bc9b8,0);
      iVar8 = iStack_18;
      FUN_005507b0();
      if (iVar8 == 0) {
        appuStack_128[0] = &PTR_018be314;
        uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
        pcStack_2c = (char *)(uVar13 | 0x1c00);
        ppuStack_d8 = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
        uStack_dc = 0x48;
        FUN_00554f20(appuStack_128 + 1,0);
        uStack_8 = 0xf;
        *(undefined ***)(appuStack_128[0][1] + (int)appuStack_128) =
             std::
             basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
             vftable;
        *(undefined **)((int)&iStack_12c + (int)appuStack_128[0][1]) = appuStack_128[0][1] + -0x50;
        FUN_0054ee60();
        appuStack_128[1] =
             std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
             vftable;
        iStack_ec = iVar8;
        uStack_e8 = 4;
        uStack_8._0_1_ = 0x10;
        FUN_005ed940(appuStack_128,0x20);
        FUN_00558890();
        FUN_0058c420(auStack_28);
        uStack_8._0_1_ = 0x11;
        FUN_00b36a00(aiStack_68,auStack_28);
        FUN_005507b0();
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_00570540();
      }
      else {
        iStack_18 = 0;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        FUN_005542c0(&DAT_018bc9b8,0);
        uStack_8._0_1_ = 0x12;
        FUN_00b38cc0(aiStack_68,&PTR_DAT_01d66f8c,auStack_28);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_005507b0();
      }
    }
    iVar8 = FUN_0058eea0(PTR_DAT_01d66f98,0);
    if (iVar8 != -1) {
      iStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0(&DAT_018bc9b8,0);
      iVar8 = iStack_18;
      FUN_005507b0();
      if (iVar8 == 0) {
        FUN_00b36960(aiStack_68,&PTR_DAT_01d66f98);
      }
      else {
        iStack_18 = 0;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        FUN_005542c0(&DAT_018bc9b8,0);
        uStack_8._0_1_ = 0x13;
        FUN_00b38cc0(aiStack_68,&PTR_DAT_01d66f98,auStack_28);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_005507b0();
      }
    }
    iVar8 = FUN_0058eea0(PTR_DAT_01d66f94,0);
    if (iVar8 != -1) {
      iStack_18 = 0;
      uStack_14 = 0xf;
      auStack_28[0] = 0;
      FUN_005542c0(&DAT_018bc9b8,0);
      iVar8 = iStack_18;
      FUN_005507b0();
      if (iVar8 == 0) {
        FUN_00b36960(aiStack_68,&PTR_DAT_01d66f94);
      }
      else {
        iStack_18 = 0;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        FUN_005542c0(&DAT_018bc9b8,0);
        uStack_8._0_1_ = 0x14;
        FUN_00b38cc0(aiStack_68,&PTR_DAT_01d66f94,auStack_28);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_005507b0();
      }
    }
    iVar8 = FUN_0058eea0(PTR_DAT_01d66f74,0);
    if (iVar8 != -1) {
      if ((int)uStack_40 == 0) {
        uVar15 = 0;
        uVar7 = FUN_00b4a230(&pcStack_34);
        pppppppuVar9 = (undefined4 *******)FUN_00b42a50(auStack_84,uVar7,uVar15);
        if (&pppppppuStack_50 != (undefined4 ********)pppppppuVar9) {
          FUN_005507b0();
          pppppppuStack_50 = (undefined4 *******)*pppppppuVar9;
          ppppppuStack_4c = pppppppuVar9[1];
          ppppppuStack_48 = pppppppuVar9[2];
          ppppppuStack_44 = pppppppuVar9[3];
          uStack_40 = *(undefined8 *)(pppppppuVar9 + 4);
          pppppppuVar9[4] = (undefined4 ******)0x0;
          pppppppuVar9[5] = (undefined4 ******)0xf;
          *(undefined *)pppppppuVar9 = 0;
        }
        FUN_005507b0();
      }
      FUN_00b38cc0(aiStack_68,&PTR_DAT_01d66f74,&pppppppuStack_50);
    }
    iVar8 = FUN_0058eea0(PTR_DAT_01d66f78,0);
    if (iVar8 != -1) {
      uVar15 = 1;
      uVar7 = FUN_00b4a230(&pcStack_34);
      pppppppuVar9 = (undefined4 *******)FUN_00b42a50(auStack_84,uVar7,uVar15);
      if (&pppppppuStack_50 != (undefined4 ********)pppppppuVar9) {
        FUN_005507b0();
        pppppppuStack_50 = (undefined4 *******)*pppppppuVar9;
        ppppppuStack_4c = pppppppuVar9[1];
        ppppppuStack_48 = pppppppuVar9[2];
        ppppppuStack_44 = pppppppuVar9[3];
        uStack_40 = *(undefined8 *)(pppppppuVar9 + 4);
        pppppppuVar9[4] = (undefined4 ******)0x0;
        pppppppuVar9[5] = (undefined4 ******)0xf;
        *(undefined *)pppppppuVar9 = 0;
      }
      FUN_005507b0();
      if ((int)uStack_40 == 0) {
        FUN_00b36960(aiStack_68,&PTR_DAT_01d66f78);
      }
      else {
        piVar4 = *(int **)(*(int *)(param_5 + 0x30) + 4);
        uStack_8._0_1_ = 0x15;
        piStack_30 = piVar4;
        (**(code **)(*piVar4 + 4))();
        uStack_8._0_1_ = 0x16;
        piVar10 = (int *)FUN_00564bf0(&pcStack_34);
        uVar5 = (**(code **)(*piVar10 + 0xc))();
        uStack_8._0_1_ = 0x17;
        if (piVar4 != (int *)0x0) {
          puVar11 = (undefined4 *)(**(code **)(*piVar4 + 8))();
          if (puVar11 != (undefined4 *)0x0) {
            (**(code **)*puVar11)(1);
          }
        }
        iStack_18 = 0;
        uStack_14 = 0xf;
        auStack_28[0] = 0;
        uStack_8._0_1_ = 0x18;
        FUN_005558a0(uVar5);
        pppppppuVar9 = &pppppppuStack_50;
        if (0xf < uStack_40._4_4_) {
          pppppppuVar9 = pppppppuStack_50;
        }
        FUN_00554150(pppppppuVar9,(int)uStack_40);
        FUN_00b38cc0(aiStack_68,&PTR_DAT_01d66f78,auStack_28);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        FUN_005507b0();
      }
    }
    uVar7 = FUN_00b41a70(&pcStack_2c);
    puVar11 = (undefined4 *)FUN_00b4b2d0(auStack_170,uVar7);
    uStack_90 = *puVar11;
    uStack_8c = puVar11[1];
    uStack_88 = puVar11[2];
    auStack_84[0] = puVar11[3];
    uStack_20 = puVar11[4];
    uStack_1c = puVar11[5];
    iStack_18 = puVar11[6];
    uStack_14 = puVar11[7];
    FUN_00b4a230(&pcStack_34);
    uStack_88 = FUN_016f3900();
    FUN_016f3900();
    uStack_8c = FUN_016f4270();
    uVar14 = FUN_016f3900();
    uVar7 = (undefined4)((ulonglong)uVar14 >> 0x20);
    uVar16 = 0;
    uVar15 = 0x3c;
    uVar14 = CONCAT44((int)uVar14,0xb49120);
    uStack_14c = FUN_016f4270();
    iStack_12c = -1;
    uStack_148 = uStack_8c;
    uStack_144 = uStack_88;
    uStack_140 = auStack_84[0];
    pcVar3 = *(code **)(*piStack_6c + 0x18);
    uStack_13c = uStack_20;
    uStack_138 = uStack_1c;
    uStack_134 = iStack_18;
    uStack_130 = uStack_14;
    uStack_90 = uStack_14c;
    FUN_0054ef60(aiStack_68);
    (*pcVar3)(param_2,param_3,param_4,param_5,param_6,&uStack_14c,piVar6,uVar14,uVar7,uVar15,uVar16)
    ;
    if (0xf < uStack_40._4_4_) {
      uVar13 = uStack_40._4_4_ + 1;
      pppppppuVar9 = pppppppuStack_50;
      if (0xfff < uVar13) {
        pppppppuVar9 = (undefined4 *******)pppppppuStack_50[-1];
        uVar13 = uStack_40._4_4_ + 0x24;
        if (0x1f < (uint)((int)pppppppuStack_50 + (-4 - (int)pppppppuVar9))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(pppppppuVar9,uVar13);
    }
    uStack_40 = 0xf00000000;
    pppppppuStack_50 = (undefined4 *******)((uint)pppppppuStack_50 & 0xffffff00);
    if (0xf < uStack_54) {
      uVar13 = uStack_54 + 1;
      iVar8 = aiStack_68[0];
      if (0xfff < uVar13) {
        iVar8 = *(int *)(aiStack_68[0] + -4);
        uVar13 = uStack_54 + 0x24;
        if (0x1f < (aiStack_68[0] - iVar8) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar8,uVar13);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  pcVar3 = *(code **)(*param_1 + 0x14);
  ExceptionList = &pvStack_10;
  piVar6 = (int *)FUN_00b41a70(&piStack_30);
  iVar8 = *piVar6;
  if (iVar8 == -2) {
    uVar7 = 0;
  }
  else if (iVar8 == 0) {
    uVar7 = 1;
  }
  else {
    uVar7 = 5;
    if (iVar8 == -1) {
      uVar7 = 2;
    }
  }
  (*pcVar3)(param_2,param_3,param_4,param_5,param_6,uVar7);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24101 ; VA 0x00b49210 ; FUN_00b49210 */

undefined4 __thiscall
FUN_00b49210(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
            undefined4 param_6,int *param_7)

{
  char cVar1;
  int *piVar2;
  code *pcVar3;
  undefined uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  uint *puVar8;
  undefined4 ****ppppuVar9;
  int *piVar10;
  undefined4 *puVar11;
  uint uVar12;
  char *pcVar13;
  char *pcVar14;
  uint uVar15;
  undefined8 uVar16;
  int *piVar17;
  undefined4 uVar18;
  undefined4 uVar19;
  int iStack_a0;
  int iStack_9c;
  int iStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined1 *puStack_88;
  char *pcStack_84;
  int *piStack_80;
  uint uStack_7c;
  uint uStack_78;
  uint uStack_74;
  uint uStack_70;
  undefined8 uStack_6c;
  int iStack_64;
  int iStack_60;
  int iStack_5c;
  undefined8 uStack_58;
  undefined8 uStack_50;
  char *pcStack_48;
  undefined4 uStack_44;
  int aiStack_40 [5];
  uint uStack_2c;
  undefined4 ***pppuStack_28;
  undefined4 **ppuStack_24;
  undefined4 **ppuStack_20;
  undefined4 **ppuStack_1c;
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f33a8;
  pvStack_10 = ExceptionList;
  iVar6 = *param_7;
  iVar7 = param_7[1];
  if ((((iVar6 != 0) || (iVar7 != -0x80000000)) && ((iVar6 != -1 || (iVar7 != 0x7fffffff)))) &&
     ((iVar6 != -2 || (iVar7 != 0x7fffffff)))) {
    ExceptionList = &pvStack_10;
    FUN_0054ef60(param_1 + 0x3f);
    uStack_8 = 0;
    pcStack_84 = (char *)0x0;
    piStack_80 = (int *)0x0;
    iVar6 = FUN_00874e00(&pcStack_84);
    if (iVar6 == -1) {
      FUN_00b38c50(aiStack_40,&PTR_DAT_01d66fa4,&PTR_DAT_01d66fa8);
      FUN_00b38c50(aiStack_40,&PTR_DAT_01d66fa0,&PTR_DAT_01d66fa8);
    }
    else {
      FUN_00b36960(aiStack_40,&PTR_DAT_01d66fa4);
      FUN_00b38c50(aiStack_40,&PTR_DAT_01d66fa0,&PTR_DAT_01d66fac);
    }
    pcVar14 = "%H:%M:%S";
    do {
      pcVar13 = pcVar14;
      pcVar14 = pcVar13 + 1;
    } while (*pcVar13 != '\0');
    pcVar14 = "%T";
    do {
      pcStack_84 = pcVar14;
      pcVar14 = pcStack_84 + 1;
    } while (*pcStack_84 != '\0');
    puStack_88 = &DAT_01952450;
    FUN_00b36aa0(aiStack_40,CONCAT44(pcStack_84,&DAT_01952450),piStack_80,&DAT_01952454,pcVar13);
    pcVar14 = "%H:%M";
    do {
      pcVar13 = pcVar14;
      pcVar14 = pcVar13 + 1;
    } while (*pcVar13 != '\0');
    pcVar14 = "%R";
    do {
      pcStack_84 = pcVar14;
      pcVar14 = pcStack_84 + 1;
    } while (*pcStack_84 != '\0');
    puStack_88 = &DAT_01952460;
    piVar17 = aiStack_40;
    FUN_00b36aa0(piVar17,CONCAT44(pcStack_84,&DAT_01952460),piStack_80,&DAT_01952464,pcVar13);
    uStack_6c = 0xf00000000;
    uStack_7c = uStack_7c & 0xffffff00;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    iVar7 = FUN_0058eea0(PTR_DAT_01d66f88,0);
    iVar6 = 0;
    if (iVar7 != -1) {
      puVar8 = (uint *)FUN_00b45f50(&uStack_58,param_7,2);
      if (&uStack_7c != puVar8) {
        FUN_005507b0();
        uStack_7c = *puVar8;
        uStack_78 = puVar8[1];
        uStack_74 = puVar8[2];
        uStack_70 = puVar8[3];
        uStack_6c = *(undefined8 *)(puVar8 + 4);
        puVar8[4] = 0;
        puVar8[5] = 0xf;
        *(undefined *)puVar8 = 0;
      }
      FUN_005507b0();
      FUN_00b38cc0(aiStack_40,&PTR_DAT_01d66f88,&uStack_7c);
      iVar6 = (int)uStack_6c;
    }
    iVar7 = FUN_0058eea0(PTR_DAT_01d66f84,0);
    if (iVar7 != -1) {
      if (iVar6 == 0) {
        puVar8 = (uint *)FUN_00b45f50(&uStack_58,param_7,2);
        if (&uStack_7c != puVar8) {
          FUN_005507b0();
          uStack_7c = *puVar8;
          uStack_78 = puVar8[1];
          uStack_74 = puVar8[2];
          uStack_70 = puVar8[3];
          uStack_6c = *(undefined8 *)(puVar8 + 4);
          puVar8[4] = 0;
          puVar8[5] = 0xf;
          *(undefined *)puVar8 = 0;
        }
        FUN_005507b0();
      }
      FUN_00b38cc0(aiStack_40,&PTR_DAT_01d66f84,&uStack_7c);
    }
    uStack_18 = 0xf00000000;
    pppuStack_28 = (undefined4 ***)((uint)pppuStack_28 & 0xffffff00);
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    iVar7 = FUN_0058eea0(PTR_DAT_01d66f7c,0);
    iVar6 = 0;
    if (iVar7 != -1) {
      ppppuVar9 = (undefined4 ****)FUN_00b42a50(&uStack_94,param_7,0);
      if (&pppuStack_28 != ppppuVar9) {
        FUN_005507b0();
        pppuStack_28 = *ppppuVar9;
        ppuStack_24 = ppppuVar9[1];
        ppuStack_20 = ppppuVar9[2];
        ppuStack_1c = ppppuVar9[3];
        uStack_18 = *(undefined8 *)(ppppuVar9 + 4);
        ppppuVar9[4] = (undefined4 ***)0x0;
        ppppuVar9[5] = (undefined4 ***)0xf;
        *(undefined *)ppppuVar9 = 0;
      }
      FUN_005507b0();
      piVar2 = *(int **)(*(int *)(param_5 + 0x30) + 4);
      uStack_8._0_1_ = 3;
      piStack_80 = piVar2;
      (**(code **)(*piVar2 + 4))();
      uStack_8._0_1_ = 4;
      piVar10 = (int *)FUN_00564bf0(&pcStack_84);
      uVar4 = (**(code **)(*piVar10 + 0xc))();
      uStack_8._0_1_ = 5;
      if (piVar2 != (int *)0x0) {
        puVar11 = (undefined4 *)(**(code **)(*piVar2 + 8))();
        if (puVar11 != (undefined4 *)0x0) {
          (**(code **)*puVar11)(1);
        }
      }
      uStack_8._0_1_ = 2;
      pcStack_48 = (char *)0x0;
      uStack_44 = 0xf;
      uStack_58 = uStack_58 & 0xffffffffffffff00;
      pcVar14 = PTR_DAT_01d66f80;
      do {
        cVar1 = *pcVar14;
        pcVar14 = pcVar14 + 1;
      } while (cVar1 != '\0');
      FUN_005542c0(PTR_DAT_01d66f80,(int)pcVar14 - (int)(PTR_DAT_01d66f80 + 1));
      uStack_8._0_1_ = 6;
      FUN_005558a0(uVar4);
      ppppuVar9 = &pppuStack_28;
      if (0xf < uStack_18._4_4_) {
        ppppuVar9 = (undefined4 ****)pppuStack_28;
      }
      FUN_00554150(ppppuVar9,(int)uStack_18);
      FUN_00b38cc0(aiStack_40,&PTR_DAT_01d66f7c,&uStack_58);
      uStack_8 = CONCAT31(uStack_8._1_3_,2);
      FUN_005507b0();
      iVar6 = (int)uStack_18;
    }
    iVar7 = FUN_0058eea0(PTR_DAT_01d66f74,0);
    if (iVar7 != -1) {
      if (iVar6 == 0) {
        ppppuVar9 = (undefined4 ****)FUN_00b42a50(&uStack_58,param_7,0);
        if (&pppuStack_28 != ppppuVar9) {
          FUN_005507b0();
          pppuStack_28 = *ppppuVar9;
          ppuStack_24 = ppppuVar9[1];
          ppuStack_20 = ppppuVar9[2];
          ppuStack_1c = ppppuVar9[3];
          uStack_18 = *(undefined8 *)(ppppuVar9 + 4);
          ppppuVar9[4] = (undefined4 ***)0x0;
          ppppuVar9[5] = (undefined4 ***)0xf;
          *(undefined *)ppppuVar9 = 0;
        }
        FUN_005507b0();
      }
      FUN_00b38cc0(aiStack_40,&PTR_DAT_01d66f74,&pppuStack_28);
    }
    iVar6 = FUN_0058eea0(PTR_DAT_01d66f78,0);
    if (iVar6 != -1) {
      ppppuVar9 = (undefined4 ****)FUN_00b42a50(&uStack_58,param_7,1);
      if (&pppuStack_28 != ppppuVar9) {
        FUN_005507b0();
        pppuStack_28 = *ppppuVar9;
        ppuStack_24 = ppppuVar9[1];
        ppuStack_20 = ppppuVar9[2];
        ppuStack_1c = ppppuVar9[3];
        uStack_18 = *(undefined8 *)(ppppuVar9 + 4);
        ppppuVar9[4] = (undefined4 ***)0x0;
        ppppuVar9[5] = (undefined4 ***)0xf;
        *(undefined *)ppppuVar9 = 0;
      }
      FUN_005507b0();
      if ((int)uStack_18 == 0) {
        FUN_00b36960(aiStack_40,&PTR_DAT_01d66f78);
      }
      else {
        piVar2 = *(int **)(*(int *)(param_5 + 0x30) + 4);
        uStack_8._0_1_ = 7;
        piStack_80 = piVar2;
        (**(code **)(*piVar2 + 4))();
        uStack_8._0_1_ = 8;
        piVar10 = (int *)FUN_00564bf0(&pcStack_84);
        uVar4 = (**(code **)(*piVar10 + 0xc))();
        uStack_8._0_1_ = 9;
        if (piVar2 != (int *)0x0) {
          puVar11 = (undefined4 *)(**(code **)(*piVar2 + 8))();
          if (puVar11 != (undefined4 *)0x0) {
            (**(code **)*puVar11)(1);
          }
        }
        pcStack_48 = (char *)0x0;
        uStack_44 = 0xf;
        uStack_58 = uStack_58 & 0xffffffffffffff00;
        uStack_8._0_1_ = 10;
        FUN_005558a0(uVar4);
        ppppuVar9 = &pppuStack_28;
        if (0xf < uStack_18._4_4_) {
          ppppuVar9 = (undefined4 ****)pppuStack_28;
        }
        FUN_00554150(ppppuVar9,(int)uStack_18);
        FUN_00b38cc0(aiStack_40,&PTR_DAT_01d66f78,&uStack_58);
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_005507b0();
      }
    }
    pcStack_48 = (char *)0x0;
    uStack_58 = 0;
    uStack_50 = 0;
    uVar12 = FUN_016f3900();
    iStack_5c = (uVar12 ^ (int)uVar12 >> 0x1f) - ((int)uVar12 >> 0x1f);
    FUN_016f3900();
    uVar12 = FUN_016f4270();
    iStack_60 = (uVar12 ^ (int)uVar12 >> 0x1f) - ((int)uVar12 >> 0x1f);
    uVar16 = FUN_016f3900();
    uVar5 = (undefined4)((ulonglong)uVar16 >> 0x20);
    uVar19 = 0;
    uVar18 = 0x3c;
    uVar16 = CONCAT44((int)uVar16,0xb4986c);
    uVar12 = FUN_016f4270();
    piStack_80 = (int *)0xffffffff;
    iStack_a0 = (uVar12 ^ (int)uVar12 >> 0x1f) - ((int)uVar12 >> 0x1f);
    iStack_9c = iStack_60;
    iStack_98 = iStack_5c;
    uStack_94 = (undefined4)uStack_58;
    pcVar3 = *(code **)(*param_1 + 0x18);
    uStack_90 = uStack_58._4_4_;
    uStack_8c = (undefined4)uStack_50;
    puStack_88 = (undefined1 *)uStack_50._4_4_;
    pcStack_84 = pcStack_48;
    iStack_64 = iStack_a0;
    FUN_0054ef60(aiStack_40);
    (*pcVar3)(param_2,param_3,param_4,param_5,param_6,&iStack_a0,piVar17,uVar16,uVar5,uVar18,uVar19)
    ;
    if (0xf < uStack_18._4_4_) {
      uVar12 = uStack_18._4_4_ + 1;
      ppppuVar9 = (undefined4 ****)pppuStack_28;
      if (0xfff < uVar12) {
        ppppuVar9 = (undefined4 ****)pppuStack_28[-1];
        uVar12 = uStack_18._4_4_ + 0x24;
        if (0x1f < (uint)((int)pppuStack_28 + (-4 - (int)ppppuVar9))) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(ppppuVar9,uVar12);
    }
    uStack_18 = 0xf00000000;
    pppuStack_28 = (undefined4 ***)((uint)pppuStack_28 & 0xffffff00);
    if (0xf < uStack_6c._4_4_) {
      uVar15 = uStack_6c._4_4_ + 1;
      uVar12 = uStack_7c;
      if (0xfff < uVar15) {
        uVar12 = *(uint *)(uStack_7c - 4);
        uVar15 = uStack_6c._4_4_ + 0x24;
        if (0x1f < (uStack_7c - uVar12) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar12,uVar15);
    }
    uStack_6c = 0xf00000000;
    uStack_7c = uStack_7c & 0xffffff00;
    if (0xf < uStack_2c) {
      uVar12 = uStack_2c + 1;
      iVar6 = aiStack_40[0];
      if (0xfff < uVar12) {
        iVar6 = *(int *)(aiStack_40[0] + -4);
        uVar12 = uStack_2c + 0x24;
        if (0x1f < (aiStack_40[0] - iVar6) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar6,uVar12);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar6 = *param_7;
  iVar7 = param_7[1];
  if ((iVar6 == -2) && (iVar7 == 0x7fffffff)) {
    uVar5 = 0;
  }
  else if ((iVar6 == 0) && (iVar7 == -0x80000000)) {
    uVar5 = 1;
  }
  else if ((iVar6 != -1) || (uVar5 = 2, iVar7 != 0x7fffffff)) {
    uVar5 = 5;
  }
  ExceptionList = &pvStack_10;
  (**(code **)(*param_1 + 0x14))(param_2,param_3,param_4,param_5,param_6,uVar5);
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24102 ; VA 0x00b499b0 ; FUN_00b499b0 */

void FUN_00b499b0(undefined4 *param_1,undefined4 param_2,int *param_3,int param_4,undefined4 param_5
                 ,undefined4 param_6,byte *param_7,byte *param_8)

{
  byte bVar1;
  int *piVar2;
  int iVar3;
  byte *pbVar4;
  char cVar5;
  byte bVar6;
  undefined uVar7;
  int *piVar8;
  undefined4 *puVar9;
  uint uVar10;
  byte *pbVar11;
  undefined auStack_38 [8];
  int *piStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f33c8;
  pvStack_10 = ExceptionList;
  piVar2 = *(int **)(*(int *)(param_4 + 0x30) + 4);
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piStack_28 = piVar2;
  (**(code **)(*piVar2 + 4))();
  uStack_8 = 1;
  piVar8 = (int *)FUN_0054e7d0(auStack_2c);
  uStack_8 = 2;
  piStack_14 = piVar8;
  if ((piVar2 != (int *)0x0) &&
     (puVar9 = (undefined4 *)(**(code **)(*piVar2 + 8))(), puVar9 != (undefined4 *)0x0)) {
    (**(code **)*puVar9)(1);
  }
  uStack_8 = 0xffffffff;
  if (param_7 != param_8) {
    do {
      uStack_20 = CONCAT31(uStack_20._1_3_,*param_7);
      cVar5 = (**(code **)(*piVar8 + 0x28))(uStack_20,0);
      if (cVar5 == '%') {
        pbVar11 = param_7 + 1;
        if (pbVar11 == param_8) {
          if (param_3 != (int *)0x0) {
            bVar6 = *param_7;
LAB_00b49bab:
            if (*(int *)param_3[8] == 0) {
LAB_00b49bd0:
              uVar10 = (**(code **)(*param_3 + 0xc))(bVar6);
            }
            else {
              iVar3 = *(int *)param_3[0xc];
              if (iVar3 < 1) goto LAB_00b49bd0;
              *(int *)param_3[0xc] = iVar3 + -1;
              pbVar11 = *(byte **)param_3[8];
              *(byte **)param_3[8] = pbVar11 + 1;
              *pbVar11 = bVar6;
              uVar10 = (uint)bVar6;
            }
            if (uVar10 != 0xffffffff) break;
          }
LAB_00b49be9:
          param_2 = CONCAT31(param_2._1_3_,1);
          break;
        }
        uStack_24 = CONCAT31(uStack_24._1_3_,*pbVar11);
        bVar6 = (**(code **)(*piVar8 + 0x28))(uStack_24,0);
        piVar8 = piStack_14;
        uVar10 = uStack_18;
        bVar1 = *param_7;
        uStack_1c = CONCAT31(uStack_1c._1_3_,bVar6);
        uStack_18 = uStack_18 & 0xffffff00;
        if ((((bVar6 == 0x45) || (bVar6 == 0x4f)) || (bVar6 == 0x51)) || (bVar6 == 0x23)) {
          pbVar11 = param_7 + 2;
          if (pbVar11 == param_8) {
            if (param_3 == (int *)0x0) {
LAB_00b49ba3:
              param_2 = CONCAT31(param_2._1_3_,1);
            }
            else {
              if (*(int *)param_3[8] == 0) {
LAB_00b49b8e:
                uVar10 = (**(code **)(*param_3 + 0xc))(bVar1);
              }
              else {
                iVar3 = *(int *)param_3[0xc];
                if (iVar3 < 1) goto LAB_00b49b8e;
                *(int *)param_3[0xc] = iVar3 + -1;
                pbVar11 = *(byte **)param_3[8];
                *(byte **)param_3[8] = pbVar11 + 1;
                *pbVar11 = bVar1;
                uVar10 = (uint)bVar1;
              }
              if (uVar10 == 0xffffffff) goto LAB_00b49ba3;
            }
            if (param_3 != (int *)0x0) goto LAB_00b49bab;
            goto LAB_00b49be9;
          }
          uStack_18 = CONCAT31(SUB43(uVar10,1),bVar6);
          piStack_28 = (int *)CONCAT31(piStack_28._1_3_,*pbVar11);
          uVar7 = (**(code **)(*piStack_14 + 0x28))(piStack_28,0);
          uStack_1c = CONCAT31(uStack_1c._1_3_,uVar7);
        }
        puVar9 = (undefined4 *)
                 (**(code **)(*piStack_30 + 0xc))
                           (auStack_38,param_2,param_3,param_4,param_5,param_6,uStack_1c,uStack_18);
        param_2 = *puVar9;
        param_3 = (int *)puVar9[1];
      }
      else {
        pbVar11 = param_7;
        if (param_3 != (int *)0x0) {
          bVar6 = *param_7;
          if (*(int *)param_3[8] == 0) {
LAB_00b49aa3:
            uVar10 = (**(code **)(*param_3 + 0xc))(bVar6);
          }
          else {
            iVar3 = *(int *)param_3[0xc];
            if (iVar3 < 1) goto LAB_00b49aa3;
            *(int *)param_3[0xc] = iVar3 + -1;
            pbVar4 = *(byte **)param_3[8];
            *(byte **)param_3[8] = pbVar4 + 1;
            *pbVar4 = bVar6;
            uVar10 = (uint)bVar6;
          }
          if (uVar10 != 0xffffffff) goto LAB_00b49b53;
        }
        param_2 = CONCAT31(param_2._1_3_,1);
      }
LAB_00b49b53:
      param_7 = pbVar11 + 1;
    } while (param_7 != param_8);
  }
  param_1[1] = param_3;
  *param_1 = param_2;
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24103 ; VA 0x00b49bfe ; FUN_00b49bfe */

void FUN_00b49bfe(void)

{
  FUN_00b49c10();
  return;
}



/* FUNCTION 24104 ; VA 0x00b49c10 ; FUN_00b49c10 */

void __fastcall FUN_00b49c10(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00b394a0(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c9b77c);
}



/* FUNCTION 24105 ; VA 0x00b49c33 ; FUN_00b49c33 */

void FUN_00b49c33(void)

{
  FUN_00b49c40();
  return;
}



/* FUNCTION 24106 ; VA 0x00b49c40 ; FUN_00b49c40 */

void __fastcall FUN_00b49c40(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00b39580(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c9b974);
}



/* FUNCTION 24107 ; VA 0x00b49c63 ; FUN_00b49c63 */

void FUN_00b49c63(void)

{
  FUN_00b49c70();
  return;
}



/* FUNCTION 24108 ; VA 0x00b49c70 ; FUN_00b49c70 */

void __fastcall FUN_00b49c70(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00b39660(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c9b66c);
}



/* FUNCTION 24109 ; VA 0x00b49c93 ; FUN_00b49c93 */

void FUN_00b49c93(void)

{
  FUN_00b49ca0();
  return;
}



/* FUNCTION 24110 ; VA 0x00b49ca0 ; FUN_00b49ca0 */

void __fastcall FUN_00b49ca0(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00b39740(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c9b8ec);
}



/* FUNCTION 24111 ; VA 0x00b49cc3 ; FUN_00b49cc3 */

void FUN_00b49cc3(void)

{
  FUN_00b49cd0();
  return;
}



/* FUNCTION 24112 ; VA 0x00b49cd0 ; FUN_00b49cd0 */

void __fastcall FUN_00b49cd0(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00b39820(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c9b6f4);
}



/* FUNCTION 24113 ; VA 0x00b49cf3 ; FUN_00b49cf3 */

void FUN_00b49cf3(void)

{
  FUN_00b49d00();
  return;
}



/* FUNCTION 24114 ; VA 0x00b49d00 ; FUN_00b49d00 */

void __fastcall FUN_00b49d00(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00b39900(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c9b800);
}



/* FUNCTION 24115 ; VA 0x00b49d23 ; FUN_00b49d23 */

void FUN_00b49d23(void)

{
  FUN_00b49d30();
  return;
}



/* FUNCTION 24116 ; VA 0x00b49d30 ; FUN_00b49d30 */

void __fastcall FUN_00b49d30(int param_1)

{
  undefined auStack_30 [44];
  
  FUN_00b399e0(param_1 + -0x28,1);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(auStack_30,&DAT_01c9b884);
}



/* FUNCTION 24117 ; VA 0x00b49d60 ; FUN_00b49d60 */

undefined4 * FUN_00b49d60(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  double dVar9;
  undefined8 uVar10;
  undefined auStack_3c [8];
  undefined auStack_34 [8];
  undefined auStack_2c [8];
  undefined auStack_24 [4];
  undefined auStack_20 [4];
  undefined4 uStack_1c;
  undefined auStack_18 [4];
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  int iStack_8;
  
  FUN_00b4a230(auStack_24);
  piVar2 = (int *)FUN_00b4a230(auStack_24);
  iVar5 = *piVar2;
  iVar3 = FUN_016f3900(iVar5,piVar2[1],1000000,0);
  iStack_8 = iVar5 + iVar3 * -1000000;
  if (0 < iStack_8) {
    puVar4 = (undefined4 *)FUN_00b4a230(auStack_2c);
    uVar6 = *puVar4;
    uVar7 = puVar4[1];
    puVar4 = (undefined4 *)FUN_00b4a230(auStack_34);
    uStack_10 = *puVar4;
    uStack_c = puVar4[1];
    puVar4 = (undefined4 *)FUN_00b4a230(auStack_3c);
    uStack_1c = *puVar4;
    uStack_14 = puVar4[1];
    puVar4 = (undefined4 *)FUN_00b41a70(auStack_20);
    uVar1 = *puVar4;
    dVar9 = DAT_018d8a10;
    FUN_01726ab0();
    iVar5 = iStack_8 - iStack_8 % (int)dVar9;
    iVar3 = iVar5 >> 0x1f;
    uVar10 = FUN_016f3900(uVar6,uVar7,1000000,0);
    uVar6 = FUN_016f4270(uVar10,0x3c,0);
    uVar10 = FUN_016f3900(uStack_10,uStack_c,60000000,0);
    uVar7 = FUN_016f4270(uVar10,0x3c,0);
    uVar8 = FUN_016f3900(uStack_1c,uStack_14,3600000000,0);
    FUN_005ef640(uVar8,uVar7,uVar6,iVar5,iVar3);
    uStack_1c = uVar1;
    FUN_005672c0(&uStack_1c,auStack_18);
    return param_1;
  }
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  return param_1;
}



/* FUNCTION 24118 ; VA 0x00b49ea0 ; FUN_00b49ea0 */

void FUN_00b49ea0(void)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = "%Y-%m-%d";
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_019522e4,pcVar2 + -0x19522e4);
  return;
}



/* FUNCTION 24119 ; VA 0x00b49ed0 ; FUN_00b49ed0 */

void FUN_00b49ed0(void)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = "%Y-%m-%d";
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_019520e8,pcVar2 + -0x19520e8);
  return;
}



/* FUNCTION 24120 ; VA 0x00b49f00 ; FUN_00b49f00 */

void FUN_00b49f00(void)

{
  char cVar1;
  char *pcVar2;
  
  pcVar2 = PTR_DAT_01d66fb4;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(PTR_DAT_01d66fb4,(int)pcVar2 - (int)(PTR_DAT_01d66fb4 + 1));
  return;
}



/* FUNCTION 24121 ; VA 0x00b49f30 ; FUN_00b49f30 */

void FUN_00b49f30(void)

{
  char cVar1;
  char *pcVar2;
  
  pcVar2 = PTR_DAT_01d66f68;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(PTR_DAT_01d66f68,(int)pcVar2 - (int)(PTR_DAT_01d66f68 + 1));
  return;
}



/* FUNCTION 24122 ; VA 0x00b49f60 ; FUN_00b49f60 */

void FUN_00b49f60(void)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = "%Y%m%d";
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_019522dc,pcVar2 + -0x19522dc);
  return;
}



/* FUNCTION 24123 ; VA 0x00b49f90 ; FUN_00b49f90 */

void FUN_00b49f90(void)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = "%Y%m%d";
  do {
    pcVar2 = pcVar1;
    pcVar1 = pcVar2 + 1;
  } while (*pcVar2 != '\0');
  FUN_005542c0(&DAT_019520e0,pcVar2 + -0x19520e0);
  return;
}



/* FUNCTION 24124 ; VA 0x00b49fc0 ; FUN_00b49fc0 */

void FUN_00b49fc0(void)

{
  char cVar1;
  char *pcVar2;
  
  pcVar2 = PTR_DAT_01d66fb0;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(PTR_DAT_01d66fb0,(int)pcVar2 - (int)(PTR_DAT_01d66fb0 + 1));
  return;
}



/* FUNCTION 24125 ; VA 0x00b49ff0 ; FUN_00b49ff0 */

void FUN_00b49ff0(void)

{
  char cVar1;
  char *pcVar2;
  
  pcVar2 = PTR_DAT_01d66f64;
  do {
    cVar1 = *pcVar2;
    pcVar2 = pcVar2 + 1;
  } while (cVar1 != '\0');
  FUN_005542c0(PTR_DAT_01d66f64,(int)pcVar2 - (int)(PTR_DAT_01d66f64 + 1));
  return;
}



/* FUNCTION 24126 ; VA 0x00b4a020 ; FUN_00b4a020 */

undefined4 __thiscall FUN_00b4a020(int param_1,undefined4 param_2,undefined4 param_3)

{
  (**(code **)(*(int *)(param_1 + 4) + 4))(param_2,param_3);
  return param_2;
}



/* FUNCTION 24127 ; VA 0x00b4a040 ; FUN_00b4a040 */

undefined4 __thiscall FUN_00b4a040(int param_1,undefined4 param_2)

{
  (**(code **)(*(int *)(param_1 + 4) + 8))(param_2);
  return param_2;
}



/* FUNCTION 24128 ; VA 0x00b4a060 ; FUN_00b4a060 */

undefined4 __thiscall FUN_00b4a060(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 0x1c);
  return param_2;
}



/* FUNCTION 24129 ; VA 0x00b4a080 ; FUN_00b4a080 */

undefined4 __thiscall FUN_00b4a080(int param_1,undefined4 param_2)

{
  FUN_0054ef60(param_1 + 4);
  return param_2;
}



/* FUNCTION 24130 ; VA 0x00b4a0a0 ; FUN_00b4a0a0 */

void __thiscall
FUN_00b4a0a0(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  int iStack_28;
  undefined4 uStack_1c;
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f2d18;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  iStack_18 = 0;
  iStack_14 = 0;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  FUN_00559960(0,param_2);
  iVar3 = iStack_14;
  iVar1 = iStack_18;
  if (iStack_14 == iStack_18) {
    FUN_00559960(iStack_18,param_3);
    iVar3 = iStack_14;
  }
  else {
    FUN_0054ef60(param_3);
    iStack_18 = iVar1 + 0x18;
  }
  iVar1 = iStack_18;
  if (iVar3 == iStack_18) {
    FUN_00559960(iStack_18,param_4);
    iVar3 = iStack_14;
  }
  else {
    FUN_0054ef60(param_4);
    iStack_18 = iVar1 + 0x18;
  }
  iVar1 = iStack_18;
  if (iVar3 == iStack_18) {
    FUN_00559960(iStack_18,param_5);
    iVar3 = iStack_14;
  }
  else {
    FUN_0054ef60(param_5);
    iStack_18 = iVar1 + 0x18;
  }
  iVar1 = iStack_18;
  if (iVar3 == iStack_18) {
    FUN_00559960(iStack_18,param_6);
  }
  else {
    FUN_0054ef60(param_6);
    iStack_18 = iVar1 + 0x18;
  }
  FUN_00637260(&uStack_1c);
  piVar2 = (int *)FUN_00b3c0c0();
  if (param_1 != piVar2) {
    iVar1 = *param_1;
    uStack_8 = CONCAT31(uStack_8._1_3_,2);
    FUN_00b3fb60(*(undefined4 *)(iVar1 + 4));
    *(int *)(*param_1 + 4) = iVar1;
    *(int *)*param_1 = iVar1;
    *(int *)(*param_1 + 8) = iVar1;
    param_1[1] = 0;
    iVar1 = *param_1;
    *param_1 = *piVar2;
    *piVar2 = iVar1;
    iVar1 = param_1[1];
    param_1[1] = piVar2[1];
    piVar2[1] = iVar1;
  }
  *(undefined2 *)(param_1 + 2) = *(undefined2 *)(piVar2 + 2);
  uStack_8 = CONCAT31(uStack_8._1_3_,3);
  FUN_00b3fb60(*(undefined4 *)(iStack_28 + 4));
  *(int *)(iStack_28 + 4) = iStack_28;
  *(int *)iStack_28 = iStack_28;
  *(int *)(iStack_28 + 8) = iStack_28;
  FUN_01674ea0(iStack_28,0x20);
  FUN_00577a40();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24131 ; VA 0x00b4a230 ; FUN_00b4a230 */

undefined4 __thiscall FUN_00b4a230(int *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  
  iVar1 = *param_1;
  iVar2 = param_1[1];
  if ((((iVar1 != 0) || (iVar2 != -0x80000000)) && ((iVar1 != -1 || (iVar2 != 0x7fffffff)))) &&
     ((iVar1 != -2 || (iVar2 != 0x7fffffff)))) {
    uVar4 = FUN_016f4270(iVar1,iVar2,0x1dd76000,0x14);
    FUN_005ef640(0,0,0,uVar4);
    return param_2;
  }
  if ((iVar1 == -2) && (iVar2 == 0x7fffffff)) {
    FUN_0056b510(0);
    return param_2;
  }
  if ((iVar1 == 0) && (iVar2 == -0x80000000)) {
    FUN_0056b510(1);
    return param_2;
  }
  if ((iVar1 != -1) || (uVar3 = 2, iVar2 != 0x7fffffff)) {
    uVar3 = 5;
  }
  FUN_0056b510(uVar3);
  return param_2;
}



/* FUNCTION 24132 ; VA 0x00b4a2f0 ; FUN_00b4a2f0 */

undefined4 FUN_00b4a2f0(undefined4 param_1)

{
  char *pcVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  char *pcVar4;
  uint uVar5;
  int iStack_170;
  undefined uStack_16c;
  undefined4 uStack_15c;
  undefined4 uStack_158;
  undefined uStack_154;
  undefined4 uStack_144;
  undefined4 uStack_140;
  undefined uStack_13c;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined uStack_124;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  int aiStack_108 [2];
  undefined ***pppuStack_100;
  undefined4 uStack_fc;
  undefined **appuStack_ec [2];
  undefined8 uStack_e4;
  undefined **appuStack_dc [16];
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_88;
  undefined **ppuStack_84;
  int iStack_30;
  undefined auStack_2c [4];
  int *piStack_28;
  int *piStack_20;
  undefined4 uStack_1c;
  uint uStack_18;
  undefined1 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3476;
  pvStack_10 = ExceptionList;
  uVar5 = 0;
  uStack_18 = 0;
  pppuStack_100 = (undefined ***)0xb4a321;
  ExceptionList = &pvStack_10;
  FUN_00b483a0();
  pppuStack_100 = (undefined ***)0x114;
  aiStack_108[1] = 0xb4a32b;
  iStack_30 = FUN_01674e20();
  uStack_8 = 0;
  if (iStack_30 == 0) {
    uVar2 = 0;
  }
  else {
    uStack_fc = 0xb4a346;
    uVar2 = FUN_00b3bcb0();
    uStack_fc = 0;
    piStack_20 = aiStack_108;
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    uVar5 = 1;
    uStack_18 = 1;
    uStack_10c = 0xb4a363;
    FUN_00b39f50();
    piStack_28 = &iStack_170;
    uStack_8 = 2;
    iStack_170 = 1;
    uStack_15c = 0;
    uStack_158 = 0xf;
    uStack_16c = 0;
    puStack_14 = &DAT_01952341;
    pcVar1 = "/";
    do {
      pcVar4 = pcVar1;
      pcVar1 = pcVar4 + 1;
    } while (*pcVar4 != '\0');
    uStack_10c = uVar2;
    FUN_005542c0(&DAT_01952340,pcVar4 + -0x1952340);
    uStack_144 = 0;
    uStack_8._0_1_ = 3;
    uStack_140 = 0xf;
    uStack_154 = 0;
    puStack_14 = &DAT_01952345;
    pcVar1 = "[";
    do {
      pcVar4 = pcVar1;
      pcVar1 = pcVar4 + 1;
    } while (*pcVar4 != '\0');
    FUN_005542c0(&DAT_01952344,pcVar4 + -0x1952344);
    uStack_12c = 0;
    uStack_8._0_1_ = 4;
    uStack_128 = 0xf;
    uStack_13c = 0;
    puStack_14 = &DAT_01952349;
    pcVar1 = ")";
    do {
      pcVar4 = pcVar1;
      pcVar1 = pcVar4 + 1;
    } while (*pcVar4 != '\0');
    FUN_005542c0(&DAT_01952348,pcVar4 + -0x1952348);
    uStack_114 = 0;
    uStack_110 = 0xf;
    uStack_8._0_1_ = 5;
    uStack_124 = 0;
    pcVar1 = "]";
    do {
      pcVar4 = pcVar1;
      pcVar1 = pcVar4 + 1;
    } while (*pcVar4 != '\0');
    FUN_005542c0(&DAT_0195234c,pcVar4 + -0x195234c);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    uVar2 = FUN_00b3c490("%Y-%m-%dT%TZ");
  }
  if (uVar5 != 0) {
    uVar5 = 0;
    uStack_fc = 0xb4a47e;
    FUN_00577a40();
  }
  appuStack_ec[0] = &PTR_018bf148;
  appuStack_dc[0] = (undefined **)&DAT_018bf150;
  uStack_fc = 0;
  pppuStack_100 = appuStack_dc + 2;
  uStack_8 = 7;
  ppuStack_84 = std::basic_istream<char,struct_std::char_traits<char>_>::vftable;
  uStack_18 = uVar5 | 4;
  uStack_88 = 0x50;
  uStack_e4 = 0;
  aiStack_108[1] = 0xb4a4cc;
  FUN_00554f20();
  *(undefined ***)((int)appuStack_dc + (int)appuStack_dc[0][1]) =
       std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)((int)appuStack_dc + (int)(appuStack_dc[0][1] + -4)) = appuStack_dc[0][1] + -8;
  *(undefined ***)((int)appuStack_ec + (int)appuStack_ec[0][1]) =
       std::basic_iostream<char,struct_std::char_traits<char>_>::vftable;
  *(undefined **)(appuStack_ec[0][1] + (int)&stack0xffffff10) = appuStack_ec[0][1] + -0x20;
  uStack_8 = 0xc;
  *(undefined ***)((int)appuStack_ec + (int)appuStack_ec[0][1]) =
       std::basic_stringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(appuStack_ec[0][1] + (int)&stack0xffffff10) = appuStack_ec[0][1] + -0x68;
  uStack_fc = 0xb4a553;
  FUN_0054ee60();
  appuStack_dc[2] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  uStack_9c = 0;
  uStack_98 = 0;
  uStack_8 = 0xd;
  pppuStack_100 = (undefined ***)0xb4a58f;
  uStack_fc = uVar2;
  pppuStack_100 = (undefined ***)FUN_016de368();
  aiStack_108[1] = 0xb4a598;
  uStack_fc = FUN_00b33d00();
  pppuStack_100 = (undefined ***)auStack_2c;
  uStack_8._0_1_ = 0xe;
  aiStack_108[1] = 0xb4a5a8;
  FUN_00b460e0();
  uStack_8._0_1_ = 0xf;
  if (piStack_28 != (int *)0x0) {
    uStack_fc = 0xb4a5b8;
    puVar3 = (undefined4 *)(**(code **)(*piStack_28 + 8))();
    if (puVar3 != (undefined4 *)0x0) {
      uStack_fc = 1;
      pppuStack_100 = (undefined ***)0xb4a5c6;
      (**(code **)*puVar3)();
    }
  }
  uStack_8._0_1_ = 0x10;
  if (piStack_20 != (int *)0x0) {
    uStack_fc = 0xb4a5d6;
    puVar3 = (undefined4 *)(**(code **)(*piStack_20 + 8))();
    if (puVar3 != (undefined4 *)0x0) {
      uStack_fc = 1;
      pppuStack_100 = (undefined ***)0xb4a5e4;
      (**(code **)*puVar3)();
    }
  }
  uStack_fc = uStack_1c;
  pppuStack_100 = appuStack_dc;
  uStack_8 = CONCAT31(uStack_8._1_3_,0xd);
  aiStack_108[1] = 0xb4a5f7;
  FUN_00b34910();
  uStack_fc = param_1;
  pppuStack_100 = (undefined ***)0xb4a609;
  FUN_0058c420();
  uStack_fc = 0xb4a614;
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24133 ; VA 0x00b4a630 ; FUN_00b4a630 */

undefined4 __thiscall
FUN_00b4a630(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            int param_5)

{
  undefined4 uStack_c;
  undefined4 uStack_8;
  
  if (param_5 != 0) {
    param_1 = param_1 + 2;
  }
  uStack_c = *param_1;
  uStack_8 = param_1[1];
  FUN_00b483a0(&uStack_c);
  FUN_00b42750(param_2,&uStack_c,param_3,param_4);
  return param_2;
}



/* FUNCTION 24134 ; VA 0x00b4a680 ; FUN_00b4a680 */

/* WARNING: Type propagation algorithm not settling */

undefined4 __thiscall FUN_00b4a680(int *param_1,undefined4 param_2)

{
  undefined uVar1;
  undefined4 *puVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  uint uVar8;
  uint uVar9;
  undefined8 uVar10;
  undefined **appuStack_10c [15];
  undefined4 uStack_d0;
  undefined4 auStack_cc [3];
  undefined4 uStack_c0;
  undefined **ppuStack_bc;
  int aiStack_74 [5];
  uint uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  uint auStack_50 [4];
  undefined4 uStack_40;
  uint uStack_3c;
  undefined auStack_38 [16];
  undefined8 uStack_28;
  undefined auStack_20 [8];
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f3503;
  pvStack_10 = ExceptionList;
  appuStack_10c[0] = &PTR_018be314;
  uStack_8 = 1;
  uStack_54 = 2;
  ppuStack_bc = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_c0 = 0x48;
  ExceptionList = &pvStack_10;
  FUN_00554f20(appuStack_10c + 1,0);
  uStack_8 = 3;
  *(undefined ***)(appuStack_10c[0][1] + (int)appuStack_10c) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(appuStack_10c[0][1] + (int)&stack0xfffffef0) = appuStack_10c[0][1] + -0x50;
  FUN_0054ee60();
  appuStack_10c[1] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  uStack_d0 = 0;
  auStack_cc[0] = 4;
  uStack_8 = 0;
  uStack_5c = 0;
  uStack_58 = 0;
  *(undefined *)((int)auStack_cc + (int)appuStack_10c[0][1]) = 0x30;
  uStack_8._0_1_ = 5;
  puVar2 = (undefined4 *)(**(code **)(*param_1 + 8))(auStack_50);
  puVar5 = puVar2 + 4;
  uStack_8._0_1_ = 6;
  if (0xf < (uint)puVar2[5]) {
    puVar2 = (undefined4 *)*puVar2;
  }
  FUN_0055b3b0(appuStack_10c,puVar2,*puVar5);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (0xf < uStack_3c) {
    uVar8 = uStack_3c + 1;
    uVar9 = auStack_50[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_50[0] - 4);
      uVar8 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  (**(code **)(*param_1 + 0x20))(auStack_18);
  uStack_28 = 0;
  iVar3 = FUN_00874e00(&uStack_28);
  if (iVar3 == -1) {
    piVar4 = (int *)FUN_005ed940(appuStack_10c,0x2d);
    puVar5 = (undefined4 *)FUN_016df519(auStack_38,2,0);
    (*(code *)*puVar5)(*(int *)(*piVar4 + 4) + (int)piVar4,puVar5[2],puVar5[3]);
    (**(code **)(*param_1 + 0x20))(auStack_18);
    puVar5 = (undefined4 *)FUN_009d6f80(&uStack_28,0xffffffff);
  }
  else {
    piVar4 = (int *)FUN_005ed940(appuStack_10c,0x2b);
    puVar5 = (undefined4 *)FUN_016df519(auStack_38,2,0);
    (*(code *)*puVar5)(*(int *)(*piVar4 + 4) + (int)piVar4,puVar5[2],puVar5[3]);
    puVar5 = (undefined4 *)(**(code **)(*param_1 + 0x20))(auStack_18);
  }
  uVar6 = FUN_016f3900(*puVar5,puVar5[1],3600000000,0);
  FUN_005af260(uVar6);
  puVar5 = (undefined4 *)(**(code **)(*param_1 + 0x20))(auStack_18);
  uVar10 = FUN_016f3900(*puVar5,puVar5[1],60000000,0);
  iVar3 = FUN_016f4270(uVar10,0x3c,0);
  if (iVar3 == 0) {
    puVar5 = (undefined4 *)(**(code **)(*param_1 + 0x20))(auStack_18);
    uVar10 = FUN_016f3900(*puVar5,puVar5[1],1000000,0);
    iVar3 = FUN_016f4270(uVar10,0x3c,0);
    if (iVar3 != 0) goto LAB_00b4a8e6;
  }
  else {
LAB_00b4a8e6:
    piVar4 = (int *)FUN_005ed940(appuStack_10c,0x3a);
    puVar5 = (undefined4 *)FUN_016df519(auStack_38,2,0);
    (*(code *)*puVar5)(*(int *)(*piVar4 + 4) + (int)piVar4,puVar5[2],puVar5[3]);
    puVar5 = (undefined4 *)(**(code **)(*param_1 + 0x20))(auStack_18);
    uVar10 = FUN_016f3900(*puVar5,puVar5[1],60000000,0);
    uVar6 = FUN_016f4270(uVar10,0x3c,0);
    FUN_005af260(uVar6);
    puVar5 = (undefined4 *)(**(code **)(*param_1 + 0x20))(auStack_18);
    uVar10 = FUN_016f3900(*puVar5,puVar5[1],1000000,0);
    iVar3 = FUN_016f4270(uVar10,0x3c,0);
    if (iVar3 != 0) {
      piVar4 = (int *)FUN_005ed940(appuStack_10c,0x3a);
      puVar5 = (undefined4 *)FUN_016df519(auStack_38,2,0);
      (*(code *)*puVar5)(*(int *)(*piVar4 + 4) + (int)piVar4,puVar5[2],puVar5[3]);
      puVar5 = (undefined4 *)(**(code **)(*param_1 + 0x20))(auStack_18);
      uVar10 = FUN_016f3900(*puVar5,puVar5[1],1000000,0);
      uVar6 = FUN_016f4270(uVar10,0x3c,0);
      FUN_005af260(uVar6);
    }
  }
  if (param_1[0x22] == 0) goto LAB_00b4b017;
  puVar2 = (undefined4 *)(**(code **)(*param_1 + 4))(auStack_50);
  puVar5 = puVar2 + 4;
  uStack_8._0_1_ = 7;
  if (0xf < (uint)puVar2[5]) {
    puVar2 = (undefined4 *)*puVar2;
  }
  FUN_0055b3b0(appuStack_10c,puVar2,*puVar5);
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (0xf < uStack_3c) {
    uVar8 = uStack_3c + 1;
    uVar9 = auStack_50[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_50[0] - 4);
      uVar8 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar9) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  (**(code **)(*param_1 + 0x24))(auStack_18);
  uStack_28 = 0;
  iVar3 = FUN_00874e00(&uStack_28);
  if (iVar3 == -1) {
    piVar4 = (int *)FUN_005ed940(appuStack_10c,0x2d);
    puVar5 = (undefined4 *)FUN_016df519(auStack_38,2,0);
    (*(code *)*puVar5)(*(int *)(*piVar4 + 4) + (int)piVar4,puVar5[2],puVar5[3]);
    (**(code **)(*param_1 + 0x24))(auStack_18);
    puVar5 = (undefined4 *)FUN_009d6f80(&uStack_28,0xffffffff);
  }
  else {
    piVar4 = (int *)FUN_005ed940(appuStack_10c,0x2b);
    puVar5 = (undefined4 *)FUN_016df519(auStack_38,2,0);
    (*(code *)*puVar5)(*(int *)(*piVar4 + 4) + (int)piVar4,puVar5[2],puVar5[3]);
    puVar5 = (undefined4 *)(**(code **)(*param_1 + 0x24))(auStack_18);
  }
  uVar6 = FUN_016f3900(*puVar5,puVar5[1],3600000000,0);
  FUN_005af260(uVar6);
  puVar5 = (undefined4 *)(**(code **)(*param_1 + 0x24))(auStack_18);
  uVar10 = FUN_016f3900(*puVar5,puVar5[1],60000000,0);
  iVar3 = FUN_016f4270(uVar10,0x3c,0);
  if (iVar3 == 0) {
    puVar5 = (undefined4 *)(**(code **)(*param_1 + 0x24))(auStack_18);
    uVar10 = FUN_016f3900(*puVar5,puVar5[1],1000000,0);
    iVar3 = FUN_016f4270(uVar10,0x3c,0);
    if (iVar3 != 0) goto LAB_00b4ab5c;
  }
  else {
LAB_00b4ab5c:
    piVar4 = (int *)FUN_005ed940(appuStack_10c,0x3a);
    puVar5 = (undefined4 *)FUN_016df519(auStack_38,2,0);
    (*(code *)*puVar5)(*(int *)(*piVar4 + 4) + (int)piVar4,puVar5[2],puVar5[3]);
    puVar5 = (undefined4 *)(**(code **)(*param_1 + 0x24))(auStack_18);
    uVar10 = FUN_016f3900(*puVar5,puVar5[1],60000000,0);
    uVar6 = FUN_016f4270(uVar10,0x3c,0);
    FUN_005af260(uVar6);
    puVar5 = (undefined4 *)(**(code **)(*param_1 + 0x24))(auStack_18);
    uVar10 = FUN_016f3900(*puVar5,puVar5[1],1000000,0);
    iVar3 = FUN_016f4270(uVar10,0x3c,0);
    if (iVar3 != 0) {
      piVar4 = (int *)FUN_005ed940(appuStack_10c,0x3a);
      puVar5 = (undefined4 *)FUN_016df519(auStack_38,2,0);
      (*(code *)*puVar5)(*(int *)(*piVar4 + 4) + (int)piVar4,puVar5[2],puVar5[3]);
      puVar5 = (undefined4 *)(**(code **)(*param_1 + 0x24))(auStack_18);
      uVar10 = FUN_016f3900(*puVar5,puVar5[1],1000000,0);
      uVar6 = FUN_016f4270(uVar10,0x3c,0);
      FUN_005af260(uVar6);
    }
  }
  uVar6 = FUN_005ed940(appuStack_10c,0x2c);
  uVar7 = (**(code **)(*(int *)param_1[0x22] + 8))(aiStack_74);
  uStack_8._0_1_ = 8;
  puVar2 = (undefined4 *)FUN_00b35f60(auStack_50,uVar7);
  puVar5 = puVar2 + 4;
  uStack_8._0_1_ = 9;
  if (0xf < (uint)puVar2[5]) {
    puVar2 = (undefined4 *)*puVar2;
  }
  uVar6 = FUN_0055b3b0(uVar6,puVar2,*puVar5);
  piVar4 = (int *)FUN_005ed940(uVar6,0x2f);
  puVar5 = (undefined4 *)FUN_016df519(auStack_38,2,0);
  (*(code *)*puVar5)(*(int *)(*piVar4 + 4) + (int)piVar4,puVar5[2],puVar5[3]);
  uVar6 = FUN_016f3900(param_1[0x1e],param_1[0x1f],3600000000,0);
  uVar6 = FUN_005af260(uVar6,0x3a);
  piVar4 = (int *)FUN_005ed940(uVar6);
  puVar5 = (undefined4 *)FUN_016df519(auStack_20,2,0);
  (*(code *)*puVar5)(*(int *)(*piVar4 + 4) + (int)piVar4,puVar5[2],puVar5[3]);
  uVar10 = FUN_016f3900(param_1[0x1e],param_1[0x1f],60000000,0);
  uVar6 = FUN_016f4270(uVar10,0x3c,0);
  FUN_005af260(uVar6);
  uStack_8._0_1_ = 8;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 8;
  if (0xf < uStack_3c) {
    uVar8 = uStack_3c + 1;
    uVar9 = auStack_50[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_50[0] - 4);
      uVar8 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar9) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (0xf < uStack_60) {
    uVar9 = uStack_60 + 1;
    iVar3 = aiStack_74[0];
    if (0xfff < uVar9) {
      iVar3 = *(int *)(aiStack_74[0] + -4);
      uVar9 = uStack_60 + 0x24;
      if (0x1f < (aiStack_74[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar9);
  }
  uVar10 = FUN_016f3900(param_1[0x1e],param_1[0x1f],1000000,0);
  iVar3 = FUN_016f4270(uVar10,0x3c,0);
  if (iVar3 != 0) {
    piVar4 = (int *)FUN_005ed940(appuStack_10c,0x3a);
    puVar5 = (undefined4 *)FUN_016df519(auStack_38,2,0);
    (*(code *)*puVar5)(*(int *)(*piVar4 + 4) + (int)piVar4,puVar5[2],puVar5[3]);
    uVar10 = FUN_016f3900(param_1[0x1e],param_1[0x1f],1000000,0);
    uVar6 = FUN_016f4270(uVar10,0x3c,0);
    FUN_005af260(uVar6);
  }
  uVar6 = FUN_005ed940(appuStack_10c,0x2c);
  uVar7 = (**(code **)(*(int *)param_1[0x22] + 0x10))(aiStack_74);
  uStack_8._0_1_ = 10;
  puVar2 = (undefined4 *)FUN_00b35f60(auStack_50,uVar7);
  puVar5 = puVar2 + 4;
  uStack_8._0_1_ = 0xb;
  if (0xf < (uint)puVar2[5]) {
    puVar2 = (undefined4 *)*puVar2;
  }
  uVar6 = FUN_0055b3b0(uVar6,puVar2,*puVar5);
  piVar4 = (int *)FUN_005ed940(uVar6,0x2f);
  puVar5 = (undefined4 *)FUN_016df519(auStack_38,2,0);
  (*(code *)*puVar5)(*(int *)(*piVar4 + 4) + (int)piVar4,puVar5[2],puVar5[3]);
  uVar6 = FUN_016f3900(param_1[0x20],param_1[0x21],3600000000,0);
  uVar6 = FUN_005af260(uVar6,0x3a);
  piVar4 = (int *)FUN_005ed940(uVar6);
  puVar5 = (undefined4 *)FUN_016df519(auStack_20,2,0);
  (*(code *)*puVar5)(*(int *)(*piVar4 + 4) + (int)piVar4,puVar5[2],puVar5[3]);
  uVar10 = FUN_016f3900(param_1[0x20],param_1[0x21],60000000,0);
  uVar6 = FUN_016f4270(uVar10,0x3c,0);
  FUN_005af260(uVar6);
  uStack_8._0_1_ = 10;
  uVar1 = (undefined)uStack_8;
  uStack_8._0_1_ = 10;
  if (0xf < uStack_3c) {
    uVar8 = uStack_3c + 1;
    uVar9 = auStack_50[0];
    if (0xfff < uVar8) {
      uVar9 = *(uint *)(auStack_50[0] - 4);
      uVar8 = uStack_3c + 0x24;
      if (0x1f < (auStack_50[0] - uVar9) - 4) {
        uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar9,uVar8);
  }
  uStack_40 = 0;
  uStack_3c = 0xf;
  auStack_50[0] = auStack_50[0] & 0xffffff00;
  uStack_8 = CONCAT31(uStack_8._1_3_,5);
  if (0xf < uStack_60) {
    uVar9 = uStack_60 + 1;
    iVar3 = aiStack_74[0];
    if (0xfff < uVar9) {
      iVar3 = *(int *)(aiStack_74[0] + -4);
      uVar9 = uStack_60 + 0x24;
      if (0x1f < (aiStack_74[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar9);
  }
  uVar10 = FUN_016f3900(param_1[0x20],param_1[0x21],1000000,0);
  iVar3 = FUN_016f4270(uVar10,0x3c,0);
  if (iVar3 != 0) {
    piVar4 = (int *)FUN_005ed940(appuStack_10c,0x3a);
    puVar5 = (undefined4 *)FUN_016df519(auStack_38,2,0);
    (*(code *)*puVar5)(*(int *)(*piVar4 + 4) + (int)piVar4,puVar5[2],puVar5[3]);
    uVar10 = FUN_016f3900(param_1[0x20],param_1[0x21],1000000,0);
    uVar6 = FUN_016f4270(uVar10,0x3c,0);
    FUN_005af260(uVar6);
  }
LAB_00b4b017:
  FUN_0058c420(param_2);
  FUN_00570540();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24135 ; VA 0x00b4b070 ; FUN_00b4b070 */

/* WARNING: Type propagation algorithm not settling */

undefined4 __thiscall FUN_00b4b070(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined **appuStack_ac [15];
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_60;
  undefined **ppuStack_5c;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f353f;
  pvStack_10 = ExceptionList;
  appuStack_ac[0] = &PTR_018be314;
  uStack_8 = 0;
  uStack_14 = 2;
  ppuStack_5c = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_60 = 0x48;
  ExceptionList = &pvStack_10;
  FUN_00554f20(appuStack_ac + 1,0);
  uStack_8 = 2;
  *(undefined ***)(appuStack_ac[0][1] + (int)appuStack_ac) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(appuStack_ac[0][1] + (int)&stack0xffffff50) = appuStack_ac[0][1] + -0x50;
  FUN_0054ee60();
  appuStack_ac[1] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  uStack_70 = 0;
  uStack_6c = 4;
  uStack_8 = 3;
  FUN_005ed940(appuStack_ac,0x4d);
  uVar1 = FUN_005af260(*(undefined2 *)(param_1 + 4),0x2e);
  FUN_005ed940(uVar1);
  uVar1 = FUN_005af260(*(undefined4 *)(param_1 + 8),0x2e);
  FUN_005ed940(uVar1);
  FUN_005af260(*(undefined2 *)(param_1 + 0xc));
  FUN_0058c420(param_2);
  FUN_00570540();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24136 ; VA 0x00b4b1a0 ; FUN_00b4b1a0 */

/* WARNING: Type propagation algorithm not settling */

undefined4 __thiscall FUN_00b4b1a0(int param_1,undefined4 param_2)

{
  short *psVar1;
  undefined2 extraout_var;
  undefined **appuStack_b4 [15];
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_68;
  undefined **ppuStack_64;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f357f;
  pvStack_10 = ExceptionList;
  appuStack_b4[0] = &PTR_018be314;
  uStack_8 = 0;
  uStack_1c = 2;
  ppuStack_64 = std::basic_ostream<char,struct_std::char_traits<char>_>::vftable;
  uStack_68 = 0x48;
  ExceptionList = &pvStack_10;
  FUN_00554f20(appuStack_b4 + 1,0);
  uStack_8 = 2;
  *(undefined ***)(appuStack_b4[0][1] + (int)appuStack_b4) =
       std::basic_ostringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)(appuStack_b4[0][1] + (int)&stack0xffffff48) = appuStack_b4[0][1] + -0x50;
  FUN_0054ee60();
  appuStack_b4[1] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  uStack_78 = 0;
  uStack_74 = 4;
  uStack_18 = CONCAT22(uStack_18._2_2_,*(undefined2 *)(param_1 + 4));
  uStack_14 = CONCAT22(uStack_14._2_2_,*(undefined2 *)(param_1 + 6));
  uStack_8 = 3;
  FUN_0056a920(CONCAT22(extraout_var,0x7d4),uStack_14,uStack_18);
  psVar1 = (short *)FUN_00b41c10((int)&uStack_18 + 2);
  FUN_00b3dc40(*psVar1 + -1);
  FUN_0058c420(param_2);
  FUN_00570540();
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24137 ; VA 0x00b4b2d0 ; FUN_00b4b2d0 */

undefined4 * FUN_00b4b2d0(undefined4 *param_1,int *param_2)

{
  int iVar1;
  code *pcVar2;
  int *piVar3;
  ushort *puVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  char *pcVar8;
  undefined auStack_34 [16];
  undefined4 uStack_24;
  undefined4 uStack_20;
  ushort uStack_18;
  ushort uStack_16;
  ushort uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar3 = param_2;
  puVar7 = param_1;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f35a0;
  pvStack_10 = ExceptionList;
  iVar1 = *param_2;
  if (((iVar1 != -2) && (iVar1 != 0)) && (iVar1 != -1)) {
    ExceptionList = &pvStack_10;
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[5] = 0;
    param_1[6] = 0;
    param_1[7] = 0;
    param_1[8] = 0;
    FUN_00b43600(&uStack_18,iVar1);
    puVar7[5] = uStack_18 - 0x76c;
    puVar7[4] = uStack_16 - 1;
    puVar7[3] = (uint)uStack_14;
    puVar4 = (ushort *)FUN_00b41b40((int)&param_2 + 2);
    puVar7[6] = (uint)*puVar4;
    puVar4 = (ushort *)FUN_00b41c10((int)&param_1 + 2);
    puVar7[8] = 0xffffffff;
    puVar7[7] = *puVar4 - 1;
    ExceptionList = pvStack_10;
    return puVar7;
  }
  uStack_24 = 0;
  uStack_20 = 0xf;
  auStack_34[0] = 0;
  ExceptionList = &pvStack_10;
  FUN_005542c0("tm unable to handle ",0x14);
  iVar1 = *piVar3;
  uStack_8 = 0;
  if (iVar1 == -2) {
    iVar5 = 0;
  }
  else if (iVar1 == 0) {
    iVar5 = 1;
  }
  else {
    iVar5 = 5;
    if (iVar1 == -1) {
      iVar5 = 2;
    }
  }
  if (iVar5 == 0) {
    pcVar8 = "not-a-date-time value";
  }
  else if (iVar5 == 1) {
    pcVar8 = "-infinity date value";
  }
  else if (iVar5 == 2) {
    pcVar8 = "+infinity date value";
  }
  else {
    pcVar8 = "a special date value";
  }
  FUN_00551620(pcVar8);
  uVar6 = FUN_0056b060(auStack_34);
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_00917680(uVar6);
  pcVar2 = (code *)swi(3);
  puVar7 = (undefined4 *)(*pcVar2)();
  return puVar7;
}



/* FUNCTION 24138 ; VA 0x00b4b420 ; FUN_00b4b420 */

undefined4 FUN_00b4b420(undefined4 param_1)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  undefined auStack_18 [8];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3188;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_0171e1b0(auStack_18);
  iVar2 = FUN_017243c8(auStack_18);
  if (iVar2 != 0) {
    FUN_00b41950(param_1,iVar2);
    ExceptionList = pvStack_10;
    return param_1;
  }
  uVar3 = FUN_00550130("could not convert calendar time to UTC time");
  uStack_8 = 0;
  FUN_005ef340(uVar3);
  pcVar1 = (code *)swi(3);
  uVar3 = (*pcVar1)();
  return uVar3;
}



/* FUNCTION 24139 ; VA 0x00b4b490 ; FUN_00b4b490 */

/* WARNING: Removing unreachable block (ram,0x00b4b4db) */

undefined4 FUN_00b4b490(undefined4 param_1)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  ulonglong uVar4;
  undefined auStack_7c [36];
  undefined auStack_58 [40];
  undefined auStack_30 [8];
  undefined auStack_28 [8];
  undefined auStack_20 [8];
  undefined8 uStack_18;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f35c0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  FUN_006d31a0(&uStack_18,&DAT_01eee630);
  uVar4 = FUN_016f3900((undefined4)uStack_18,uStack_18._4_4_,1000000,0);
  if (uVar4 < 0x7933fff80) {
    uStack_18 = uVar4;
    iVar2 = FUN_017243ef(auStack_7c,&uStack_18);
    if (iVar2 == 0) {
      iVar2 = FUN_017246b2(auStack_58,&uStack_18);
      if (iVar2 == 0) {
        FUN_00b48520(param_1,auStack_58);
        ExceptionList = pvStack_10;
        return param_1;
      }
    }
                    /* WARNING: Subroutine does not return */
    FUN_016757c0("Error interpreting timestamp as a date/time (%lld)\n",uVar4);
  }
  FUN_0171e1b0(&uStack_18);
  iVar2 = FUN_017243c8(&uStack_18);
  if (iVar2 == 0) {
    uVar3 = FUN_00550130("could not convert calendar time to UTC time");
    uStack_8 = 0;
    FUN_005ef340(uVar3);
  }
  else {
    FUN_00b41950(auStack_20,iVar2);
    FUN_0171e1b0(&uStack_18);
    iVar2 = FUN_0172468b(&uStack_18);
    if (iVar2 != 0) {
      FUN_00b41950(auStack_28,iVar2);
      uVar3 = FUN_006d31a0(auStack_30,auStack_20);
      FUN_00b3e000(param_1,uVar3);
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  uVar3 = FUN_00550130("could not convert calendar time to local time");
  uStack_8 = 1;
  FUN_005ef340(uVar3);
  pcVar1 = (code *)swi(3);
  uVar3 = (*pcVar1)();
  return uVar3;
}



/* FUNCTION 24140 ; VA 0x00b4b600 ; FUN_00b4b600 */

int * __thiscall
FUN_00b4b600(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f35eb;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b4b860();
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::Constraints::WeldConstraint,class_G3D::CoordinateFrame>::
              GetSetImpl<class_G3D::CoordinateFrame_(__thiscall_RBX::Constraints::WeldConstraint::*)(void)const_,void_(__thiscall_RBX::Constraints::WeldConstraint::*)(class_G3D::CoordinateFrame_const&)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_00b00260();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_G3D::CoordinateFrame>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::Constraints::WeldConstraint,class_G3D::CoordinateFrame>
                    ::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::Constraints::WeldConstraint,class_G3D::CoordinateFrame>
                    ::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24141 ; VA 0x00b4b700 ; FUN_00b4b700 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __thiscall
FUN_00b4b700(int *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f361f;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01ee410c) {
    ExceptionList = &pvStack_10;
    FUN_016f3809(&DAT_01ee410c);
    if (DAT_01ee410c == -1) {
      uStack_8 = 0;
      FUN_008887b0("Object",&DAT_0191c6bc,0x32,0,0,0);
      _DAT_01ee40e8 = RBX::Reflection::RefType<class_RBX::PartInstance*>::vftable;
      FUN_016f3654(&LAB_01887330);
      uStack_8 = 0xffffffff;
      FUN_016f37bf(&DAT_01ee410c);
    }
  }
  uVar2 = FUN_00b4b860();
  FUN_009ca670(uVar2,&DAT_01ee40e8,param_2,param_3,param_8,param_9,param_10,param_11,param_12,
               param_12,0);
  param_1[0xd] = (int)RBX::IIDREF::vftable;
  uStack_8 = 1;
  *param_1 = (int)RBX::Reflection::
                  RefPropDescriptor<class_RBX::Constraints::WeldConstraint,class_RBX::PartInstance>
                  ::vftable;
  param_1[0xd] = (int)RBX::Reflection::
                      RefPropDescriptor<class_RBX::Constraints::WeldConstraint,class_RBX::PartInstance>
                      ::vftable;
  puVar3 = (undefined4 *)FUN_01674e20(0x18);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::
              PropDescriptor<class_RBX::Constraints::WeldConstraint,class_RBX::PartInstance*>::
              GetSetImpl<class_RBX::PartInstance*_(__thiscall_RBX::Constraints::WeldConstraint::*)(void)const_,void_(__thiscall_RBX::Constraints::WeldConstraint::*)(class_RBX::PartInstance*)>
              ::vftable;
    puVar3[2] = param_4;
    puVar3[3] = param_5;
    puVar3[4] = param_6;
    puVar3[5] = param_7;
  }
  param_1[0xe] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  cVar1 = (**(code **)(*param_1 + 0xc))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xffffffeb;
  }
  cVar1 = (**(code **)(*param_1 + 8))();
  if (cVar1 != '\0') {
    param_1[9] = param_1[9] & 0xfffffff3;
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24142 ; VA 0x00b4b860 ; FUN_00b4b860 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b4b860(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3650;
  pvStack_10 = ExceptionList;
  if (DAT_01eee6ac == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eee8c0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eee8c0);
      if (DAT_01eee8c0 == -1) {
        uStack_8 = 0;
        uVar1 = thunk_FUN_00897b90();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"WeldConstraint",0,uStack_20,0,0,0x1b,0,&DAT_01f0228c);
        _DAT_01eee8b8 = RBX::Creator<class_RBX::Constraints::WeldConstraint>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01eee6b0,&DAT_01eee8b8);
        FUN_016f3654(FUN_0188dc80);
        FUN_016f37bf(&DAT_01eee8c0);
      }
    }
    DAT_01eee6ac = &DAT_01eee6b0;
  }
  ExceptionList = pvStack_10;
  return DAT_01eee6ac;
}



/* FUNCTION 24143 ; VA 0x00b4b960 ; FUN_00b4b960 */

int __thiscall FUN_00b4b960(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f3660;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::Constraints::WeldConstraint*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24144 ; VA 0x00b4ba32 ; Catch_All@00b4ba32 */

void Catch_All_00b4ba32(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24145 ; VA 0x00b4ba50 ; FUN_00b4ba50 */

undefined4 * FUN_00b4ba50(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f36ee;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b4b860();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  puVar3 = (undefined4 *)FUN_01674e20(0x7c);
  uStack_8._0_1_ = 2;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    FUN_0089a650("WeldConstraint");
    uStack_8._0_1_ = 3;
    *puVar3 = RBX::DescribedCreatable<class_RBX::Constraints::WeldConstraint,class_RBX::Instance>::
              vftable;
    uVar4 = FUN_00b4b860();
    puVar3[3] = uVar4;
    puVar3[0x15] = RBX::IJointOwner::vftable;
    uStack_8._0_1_ = 4;
    *puVar3 = RBX::Constraints::WeldConstraint::vftable;
    puVar3[0x15] = RBX::Constraints::WeldConstraint::vftable;
    puVar5 = (undefined4 *)FUN_01674e20(0xa8);
    uStack_8._0_1_ = 5;
    if (puVar5 == (undefined4 *)0x0) {
      puVar5 = (undefined4 *)0x0;
    }
    else {
      FUN_00ca27c0();
      *puVar5 = RBX::ExplicitWeldJoint::vftable;
      puVar5[2] = RBX::ExplicitWeldJoint::vftable;
    }
    puVar3[0x16] = puVar5;
    puVar3[0x17] = 0;
    puVar3[0x18] = 0;
    puVar3[0x19] = 0;
    puVar3[0x1a] = 0;
    puVar3[0x1b] = 0;
    puVar3[0x1c] = 0;
    uStack_8._0_1_ = 9;
    *(undefined *)(puVar3 + 0x1d) = 0x57;
    puVar3[0x1e] = 0;
    FUN_00ca48f0(puVar3 + 0x15);
    iVar1 = puVar3[0x16];
    *(undefined4 *)(iVar1 + 0xa0) = puVar3[6];
    *(undefined4 *)(iVar1 + 0xa4) = puVar3[7];
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00b4b960(puVar3,param_1);
  uStack_8 = 0xd;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24146 ; VA 0x00b4bbe0 ; FUN_00b4bbe0 */

void __fastcall FUN_00b4bbe0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::Constraints::WeldConstraint>::vftable;
  uVar1 = FUN_00b4b860(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24147 ; VA 0x00b4bc1c ; FUN_00b4bc1c */

void FUN_00b4bc1c(void)

{
  FUN_00b4bc30();
  return;
}



/* FUNCTION 24148 ; VA 0x00b4bc30 ; FUN_00b4bc30 */

undefined4 __thiscall FUN_00b4bc30(undefined4 param_1,byte param_2)

{
  FUN_00ca2b60();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0xa8);
  }
  return param_1;
}



/* FUNCTION 24149 ; VA 0x00b4bc60 ; FUN_00b4bc60 */

undefined4 * __thiscall FUN_00b4bc60(undefined4 *param_1,byte param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_01794b50;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Constraints::WeldConstraint::vftable;
  param_1[0x15] = RBX::Constraints::WeldConstraint::vftable;
  FUN_00ca48f0(0);
  if ((undefined4 *)param_1[0x16] != (undefined4 *)0x0) {
    (*(code *)**(undefined4 **)param_1[0x16])(1);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  FUN_01679490();
  iVar4 = param_1[0x1c];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  FUN_01679490();
  iVar4 = param_1[0x1b];
  if (iVar4 != 0) {
    piVar1 = (int *)(iVar4 + 4);
    LOCK();
    iVar3 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar3 == 1) {
      FUN_01674ea0(iVar4);
    }
  }
  piVar1 = (int *)param_1[0x1a];
  if (piVar1 != (int *)0x0) {
    LOCK();
    iVar4 = piVar1[2] + -1;
    piVar1[2] = iVar4;
    UNLOCK();
    if (iVar4 == 0) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  piVar1 = (int *)param_1[0x18];
  if (piVar1 != (int *)0x0) {
    LOCK();
    piVar2 = piVar1 + 2;
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar4 == 1) {
      (**(code **)(*piVar1 + 4))();
    }
  }
  FUN_0089b230();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x7c);
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24150 ; VA 0x00b4bd60 ; FUN_00b4bd60 */

undefined4 * FUN_00b4bd60(undefined4 *param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00b4ba50(auStack_c);
  *param_1 = *puVar4;
  uVar2 = puVar4[1];
  *puVar4 = 0;
  puVar4[1] = 0;
  param_1[1] = uVar2;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return param_1;
  }
  return param_1;
}



/* FUNCTION 24151 ; VA 0x00b4bdd0 ; FUN_00b4bdd0 */

void __fastcall FUN_00b4bdd0(int param_1)

{
  byte bVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined auStack_68 [48];
  undefined auStack_38 [48];
  int iStack_8;
  
  *(byte *)(param_1 + 0x74) = *(byte *)(param_1 + 0x74) & 0xf7;
  iVar3 = *(int *)(param_1 + 0x58);
  if (iVar3 != 0) {
    if (*(int **)(iVar3 + 4) != (int *)0x0) {
      iVar2 = (**(code **)(**(int **)(iVar3 + 4) + 4))();
      if (iVar2 == 0xf) {
        iVar3 = *(int *)(*(int *)(iVar3 + 4) + 4);
      }
      else {
        iVar3 = *(int *)(iVar3 + 4);
      }
      if (*(int *)(iVar3 + 0xc) != 0) {
        FUN_00bc0420(*(undefined4 *)(param_1 + 0x58));
      }
    }
    FUN_00ca4900(0,0);
    FUN_00ca4900(1,0);
  }
  if ((*(int *)(param_1 + 0x78) != 0) && (*(int *)(*(int *)(param_1 + 0x78) + 0x1b4) != 0)) {
    iVar3 = FUN_00b4c020();
    iStack_8 = iVar3;
    iVar2 = FUN_00b4c070();
    if ((iVar3 != 0) && (iVar2 != 0)) {
      iVar3 = FUN_00a9d0e0(iVar3);
      iVar4 = FUN_00a9d0e0(iVar2);
      if ((iVar3 == *(int *)(param_1 + 0x78)) && (iVar4 == *(int *)(param_1 + 0x78))) {
        *(byte *)(param_1 + 0x74) = *(byte *)(param_1 + 0x74) | 8;
        bVar1 = *(byte *)(param_1 + 0x74);
        if ((bVar1 & 1) != 0) {
          iVar3 = *(int *)(iVar2 + 0xa8);
          iStack_8 = *(int *)(iStack_8 + 0xa8);
          if (((bVar1 & 0x30) != 0) || ((DAT_01d66ffc != '\0' && ((bVar1 & 2) == 0)))) {
            if (DAT_01d66ffc != '\0') {
              *(byte *)(param_1 + 0x74) = bVar1 | 2;
              FUN_008a4940(&DAT_0212c144);
              FUN_008a4940(&DAT_0212c09c);
              bVar1 = *(byte *)(param_1 + 0x74);
            }
            *(byte *)(param_1 + 0x74) = bVar1 & 0x3f | 0x40;
            if (DAT_01d66ffc == '\0') {
              uVar5 = FUN_0060efa0();
              FUN_00ca4830(1,uVar5);
            }
            FUN_00c157b0();
            FUN_0071fcc0(auStack_38);
            uVar5 = FUN_00c157b0();
            uVar5 = FUN_0071f260(auStack_68,uVar5);
            FUN_00b4c660(uVar5);
          }
          iVar2 = iStack_8;
          FUN_00ca4900(0,iStack_8);
          FUN_00ca4900(1,iVar3);
          iVar2 = *(int *)(iVar2 + 0x1a8);
          if (((iVar2 != 0) && (iVar2 == *(int *)(*(int *)(param_1 + 0x78) + 0x1b4))) &&
             (iVar2 == *(int *)(iVar3 + 0x1a8))) {
            FUN_00bbe190(*(undefined4 *)(param_1 + 0x58));
          }
        }
      }
    }
  }
  return;
}



/* FUNCTION 24152 ; VA 0x00b4bf90 ; FUN_00b4bf90 */

void FUN_00b4bf90(void)

{
  FUN_00b4bdd0();
  return;
}



/* FUNCTION 24153 ; VA 0x00b4bfa0 ; FUN_00b4bfa0 */

void __thiscall FUN_00b4bfa0(int param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  iVar1 = *(int *)(param_1 + 0x58);
  uVar2 = *(undefined4 *)(iVar1 + 0x44);
  uVar3 = *(undefined4 *)(iVar1 + 0x48);
  uVar4 = *(undefined4 *)(iVar1 + 0x4c);
  *param_2 = *(undefined4 *)(iVar1 + 0x40);
  param_2[1] = uVar2;
  param_2[2] = uVar3;
  param_2[3] = uVar4;
  uVar2 = *(undefined4 *)(iVar1 + 0x54);
  uVar3 = *(undefined4 *)(iVar1 + 0x58);
  uVar4 = *(undefined4 *)(iVar1 + 0x5c);
  param_2[4] = *(undefined4 *)(iVar1 + 0x50);
  param_2[5] = uVar2;
  param_2[6] = uVar3;
  param_2[7] = uVar4;
  uVar2 = *(undefined4 *)(iVar1 + 100);
  uVar3 = *(undefined4 *)(iVar1 + 0x68);
  uVar4 = *(undefined4 *)(iVar1 + 0x6c);
  param_2[8] = *(undefined4 *)(iVar1 + 0x60);
  param_2[9] = uVar2;
  param_2[10] = uVar3;
  param_2[0xb] = uVar4;
  return;
}



/* FUNCTION 24154 ; VA 0x00b4bfd0 ; FUN_00b4bfd0 */

void __thiscall FUN_00b4bfd0(int param_1,undefined4 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  iVar1 = *(int *)(param_1 + 0x58);
  uVar2 = *(undefined4 *)(iVar1 + 0x74);
  uVar3 = *(undefined4 *)(iVar1 + 0x78);
  uVar4 = *(undefined4 *)(iVar1 + 0x7c);
  *param_2 = *(undefined4 *)(iVar1 + 0x70);
  param_2[1] = uVar2;
  param_2[2] = uVar3;
  param_2[3] = uVar4;
  uVar2 = *(undefined4 *)(iVar1 + 0x84);
  uVar3 = *(undefined4 *)(iVar1 + 0x88);
  uVar4 = *(undefined4 *)(iVar1 + 0x8c);
  param_2[4] = *(undefined4 *)(iVar1 + 0x80);
  param_2[5] = uVar2;
  param_2[6] = uVar3;
  param_2[7] = uVar4;
  uVar2 = *(undefined4 *)(iVar1 + 0x94);
  uVar3 = *(undefined4 *)(iVar1 + 0x98);
  uVar4 = *(undefined4 *)(iVar1 + 0x9c);
  param_2[8] = *(undefined4 *)(iVar1 + 0x90);
  param_2[9] = uVar2;
  param_2[10] = uVar3;
  param_2[0xb] = uVar4;
  return;
}



/* FUNCTION 24155 ; VA 0x00b4c000 ; FUN_00b4c000 */

void FUN_00b4c000(void)

{
  int iVar1;
  
  if (DAT_01eee8c4 == 0) {
    iVar1 = FUN_00b4b860();
    DAT_01eee8c4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 24156 ; VA 0x00b4c020 ; FUN_00b4c020 */

undefined4 FUN_00b4c020(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00587490(auStack_c);
  uVar2 = *puVar4;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return uVar2;
  }
  return uVar2;
}



/* FUNCTION 24157 ; VA 0x00b4c070 ; FUN_00b4c070 */

undefined4 FUN_00b4c070(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined auStack_c [4];
  int *piStack_8;
  
  puVar4 = (undefined4 *)FUN_00587490(auStack_c);
  uVar2 = *puVar4;
  if (piStack_8 != (int *)0x0) {
    LOCK();
    iVar3 = piStack_8[1] + -1;
    piStack_8[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piStack_8)();
      LOCK();
      piVar1 = piStack_8 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piStack_8 + 4))();
      }
    }
    return uVar2;
  }
  return uVar2;
}



/* FUNCTION 24158 ; VA 0x00b4c100 ; FUN_00b4c100 */

uint FUN_00b4c100(void)

{
  int iVar1;
  
  iVar1 = FUN_00b4b860();
  return *(uint *)(iVar1 + 0x1d4) >> 3 & 0xffffff01;
}



/* FUNCTION 24159 ; VA 0x00b4c120 ; FUN_00b4c120 */

uint FUN_00b4c120(void)

{
  int iVar1;
  
  iVar1 = FUN_00b4b860();
  return *(uint *)(iVar1 + 0x1d4) >> 2 & 0xffffff01;
}



/* FUNCTION 24160 ; VA 0x00b4c140 ; FUN_00b4c140 */

void __thiscall FUN_00b4c140(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  FUN_008a3ee0(param_2);
  uVar1 = FUN_00a9d0e0(param_1);
  *(undefined4 *)(param_1 + 0x78) = uVar1;
  FUN_00b4bdd0();
  return;
}



/* FUNCTION 24161 ; VA 0x00b4c170 ; FUN_00b4c170 */

void __fastcall FUN_00b4c170(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x58);
  *(undefined4 *)(iVar1 + 0xa0) = *(undefined4 *)(param_1 + 0x18);
  *(undefined4 *)(iVar1 + 0xa4) = *(undefined4 *)(param_1 + 0x1c);
  return;
}



/* FUNCTION 24162 ; VA 0x00b4c190 ; FUN_00b4c190 */

void __thiscall FUN_00b4c190(int param_1,int param_2)

{
  undefined8 uVar1;
  bool bVar2;
  bool bVar3;
  bool bVar4;
  char *pcVar5;
  char cVar6;
  int *piVar7;
  int iVar8;
  char *pcVar9;
  int iVar10;
  undefined8 *puVar11;
  undefined4 *puVar12;
  int iVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  int *piVar16;
  int **ppiVar17;
  float fVar18;
  double dVar19;
  undefined8 uStack_c4;
  float fStack_bc;
  char *pcStack_b8;
  int *piStack_b4;
  int *piStack_b0;
  int *piStack_ac;
  int iStack_a8;
  undefined8 uStack_a4;
  undefined4 uStack_9c;
  int *piStack_98;
  int *piStack_94;
  int *piStack_90;
  undefined8 uStack_8c;
  float fStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined auStack_50 [12];
  undefined auStack_44 [12];
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  if ((*(byte *)(param_1 + 0x74) & 8) == 0) {
    return;
  }
  iStack_a8 = param_1;
  piVar7 = (int *)FUN_00587490(&piStack_98);
  piVar16 = piStack_94;
  pcStack_b8 = (char *)*piVar7;
  if (piStack_94 != (int *)0x0) {
    LOCK();
    iVar13 = piStack_94[1] + -1;
    piStack_94[1] = iVar13;
    UNLOCK();
    if (iVar13 == 0) {
      (**(code **)*piStack_94)();
      LOCK();
      piVar7 = piVar16 + 2;
      iVar13 = *piVar7 + -1;
      *piVar7 = iVar13;
      UNLOCK();
      if (iVar13 == 0) {
        (**(code **)(*piVar16 + 4))();
      }
    }
  }
  piVar7 = (int *)FUN_00587490(&piStack_b4);
  piVar16 = piStack_b0;
  iVar13 = *piVar7;
  if (piStack_b0 != (int *)0x0) {
    LOCK();
    iVar8 = piStack_b0[1] + -1;
    piStack_b0[1] = iVar8;
    UNLOCK();
    if (iVar8 == 0) {
      (**(code **)*piStack_b0)();
      LOCK();
      piVar7 = piVar16 + 2;
      iVar8 = *piVar7;
      *piVar7 = *piVar7 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        (**(code **)(*piVar16 + 4))();
      }
    }
  }
  pcVar5 = pcStack_b8;
  if (pcStack_b8 == (char *)0x0) {
    return;
  }
  if (iVar13 == 0) {
    return;
  }
  if (*(int **)(*(int *)(pcStack_b8 + 0xa8) + 0x1ac) == (int *)0x0) {
LAB_00b4c263:
    bVar3 = false;
  }
  else {
    iVar8 = (**(code **)(**(int **)(*(int *)(pcStack_b8 + 0xa8) + 0x1ac) + 8))();
    bVar3 = true;
    if (iVar8 != 10) goto LAB_00b4c263;
  }
  piVar16 = *(int **)(*(int *)(iVar13 + 0xa8) + 0x1ac);
  if (piVar16 == (int *)0x0) {
LAB_00b4c28b:
    bVar4 = false;
  }
  else {
    iVar8 = (**(code **)(*piVar16 + 8))();
    bVar4 = true;
    if (iVar8 != 10) goto LAB_00b4c28b;
  }
  iVar8 = iStack_a8;
  if ((*(int *)(iStack_a8 + 0x58) == 0) || (cVar6 = FUN_00ffd8c0(), cVar6 == '\0')) {
    bVar2 = false;
  }
  else {
    bVar2 = true;
  }
  iVar10 = *(int *)(param_2 + 4);
  if (iVar10 == 1) {
    pcStack_b8 = "Inactive";
    pcVar9 = "Active";
    if (!bVar2) {
      pcVar9 = "Inactive";
    }
    FUN_00f2da20(99,"Widget Description",pcVar9);
    iVar10 = *(int *)(param_2 + 4);
  }
  piVar16 = *(int **)(iVar8 + 0x28);
  if (0xf < (uint)piVar16[5]) {
    piVar16 = (int *)*piVar16;
  }
  if (iVar10 == 1) {
    FUN_00f2da20(0x32,&DAT_018d8974,piVar16);
    iVar10 = *(int *)(param_2 + 4);
  }
  piVar16 = *(int **)(pcVar5 + 0x28);
  if (0xf < (uint)piVar16[5]) {
    piVar16 = (int *)*piVar16;
  }
  if (iVar10 == 1) {
    FUN_00f2da20(0x32,"Part0",piVar16);
    iVar10 = *(int *)(param_2 + 4);
  }
  piVar16 = *(int **)(iVar13 + 0x28);
  if (0xf < (uint)piVar16[5]) {
    piVar16 = (int *)*piVar16;
  }
  if (iVar10 == 1) {
    FUN_00f2da20(0x32,"Part1",piVar16);
  }
  if ((*(int *)(iVar8 + 0x58) == 0) || (cVar6 = FUN_00ffd8c0(), cVar6 == '\0')) {
    puVar11 = (undefined8 *)FUN_0115eb40();
  }
  else {
    puVar11 = (undefined8 *)FUN_0115eb50();
  }
  uStack_c4 = *puVar11;
  fStack_bc = *(float *)(puVar11 + 1);
  uStack_a4 = uStack_c4;
  uStack_9c = fStack_bc;
  if (bVar3) {
    puVar12 = (undefined4 *)FUN_00b077e0();
  }
  else {
    puVar12 = (undefined4 *)FUN_00b077e0();
    if (!bVar4) {
      uStack_c4 = *(undefined8 *)(puVar12 + 9);
      fStack_bc = (float)puVar12[0xb];
      iVar13 = FUN_00b077e0();
      uVar1 = *(undefined8 *)(iVar13 + 0x24);
      uStack_8c._0_4_ = (float)uVar1;
      uStack_8c._4_4_ = (float)((ulonglong)uVar1 >> 0x20);
      fStack_84 = *(float *)(iVar13 + 0x2c);
      dVar19 = (double)((uStack_8c._4_4_ - uStack_c4._4_4_) * (uStack_8c._4_4_ - uStack_c4._4_4_) +
                        ((float)uStack_8c - (float)(int *)uStack_c4) *
                        ((float)uStack_8c - (float)(int *)uStack_c4) +
                       (fStack_84 - fStack_bc) * (fStack_84 - fStack_bc));
      uStack_8c = uVar1;
      FUN_017267a0();
      if (DAT_018daf54 < (float)dVar19) {
        FUN_01002e50(&uStack_c4,&uStack_8c,*(float *)(param_2 + 0x18) * DAT_01952ddc,&uStack_a4);
        puVar12 = (undefined4 *)FUN_00b077e0();
        uStack_38 = *puVar12;
        uStack_34 = puVar12[1];
        uStack_30 = puVar12[2];
        uStack_2c = puVar12[3];
        uStack_28 = puVar12[4];
        uStack_24 = puVar12[5];
        uStack_20 = puVar12[6];
        uStack_1c = puVar12[7];
        uStack_18 = puVar12[8];
        uStack_14 = puVar12[9];
        uStack_10 = puVar12[10];
        uStack_c = puVar12[0xb];
        fVar18 = *(float *)(param_2 + 0x18) * DAT_018fde58;
        piStack_98 = (int *)(fVar18 + fVar18);
        piStack_94 = piStack_98;
        piStack_90 = piStack_98;
        uVar14 = FUN_011612d0(auStack_50,1);
        uVar15 = FUN_011612d0(auStack_44,0);
        FUN_01001c90(&uStack_14,uVar15,uVar14,&piStack_98,&uStack_a4);
      }
      puVar12 = (undefined4 *)FUN_00b077e0();
      uStack_80 = *puVar12;
      uStack_7c = puVar12[1];
      uStack_78 = puVar12[2];
      uStack_74 = puVar12[3];
      uStack_70 = puVar12[4];
      uStack_6c = puVar12[5];
      uStack_68 = puVar12[6];
      uStack_64 = puVar12[7];
      uStack_60 = puVar12[8];
      uStack_5c = puVar12[9];
      uStack_58 = puVar12[10];
      uStack_54 = puVar12[0xb];
      fVar18 = *(float *)(param_2 + 0x18) * DAT_018fde58;
      piStack_b4 = (int *)(fVar18 + fVar18);
      piStack_b0 = piStack_b4;
      piStack_ac = piStack_b4;
      uVar14 = FUN_011612d0(auStack_44,1);
      uVar15 = FUN_011612d0(auStack_50,0);
      ppiVar17 = &piStack_b4;
      goto LAB_00b4c5e3;
    }
  }
  uStack_80 = *puVar12;
  uStack_7c = puVar12[1];
  uStack_78 = puVar12[2];
  uStack_74 = puVar12[3];
  uStack_70 = puVar12[4];
  uStack_6c = puVar12[5];
  uStack_68 = puVar12[6];
  uStack_64 = puVar12[7];
  uStack_60 = puVar12[8];
  uStack_5c = puVar12[9];
  uStack_58 = puVar12[10];
  uStack_54 = puVar12[0xb];
  fStack_bc = *(float *)(param_2 + 0x18) * DAT_018fde58;
  fStack_bc = fStack_bc + fStack_bc;
  uStack_c4 = CONCAT44(fStack_bc,fStack_bc);
  uVar14 = FUN_011612d0(auStack_44,1);
  uVar15 = FUN_011612d0(auStack_50,0);
  ppiVar17 = (int **)&uStack_c4;
LAB_00b4c5e3:
  FUN_01001c90(&uStack_5c,uVar15,uVar14,ppiVar17,&uStack_a4);
  return;
}



/* FUNCTION 24163 ; VA 0x00b4c600 ; FUN_00b4c600 */

void __fastcall FUN_00b4c600(int param_1)

{
  byte bVar1;
  
  bVar1 = *(byte *)(param_1 + 0x74);
  *(byte *)(param_1 + 0x74) = bVar1 & 0xf | 0x50;
  if ((bVar1 & 2) != 0) {
    *(byte *)(param_1 + 0x74) = bVar1 & 0xd | 0x50;
    FUN_00b4bdd0();
    if ((DAT_01d66ffc != '\0') && ((*(byte *)(param_1 + 0x74) & 2) == 0)) {
      FUN_008a4940(&DAT_0212c144);
      if (DAT_01d6700c == '\0') {
        FUN_008a4940(&DAT_0212c09c);
      }
    }
    return;
  }
  FUN_00b4bdd0();
  return;
}



/* FUNCTION 24164 ; VA 0x00b4c660 ; FUN_00b4c660 */

void __thiscall FUN_00b4c660(int param_1,int param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  undefined auStack_64 [48];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  *(byte *)(param_1 + 0x74) = *(byte *)(param_1 + 0x74) & 0xcf;
  if (0x3f < *(byte *)(param_1 + 0x74)) {
    iVar1 = *(int *)(param_1 + 0x58);
    uStack_34 = *(undefined4 *)(iVar1 + 0x40);
    uStack_30 = *(undefined4 *)(iVar1 + 0x44);
    uStack_2c = *(undefined4 *)(iVar1 + 0x48);
    uStack_28 = *(undefined4 *)(iVar1 + 0x4c);
    uStack_24 = *(undefined4 *)(iVar1 + 0x50);
    uStack_20 = *(undefined4 *)(iVar1 + 0x54);
    uStack_1c = *(undefined4 *)(iVar1 + 0x58);
    uStack_18 = *(undefined4 *)(iVar1 + 0x5c);
    uStack_14 = *(undefined4 *)(iVar1 + 0x60);
    fStack_10 = *(float *)(iVar1 + 100);
    fStack_c = *(float *)(iVar1 + 0x68);
    fStack_8 = *(float *)(iVar1 + 0x6c);
    if (((((NAN(*(float *)(param_2 + 0x24)) || NAN(fStack_10)) ==
           (*(float *)(param_2 + 0x24) == fStack_10)) ||
         ((NAN(*(float *)(param_2 + 0x28)) || NAN(fStack_c)) ==
          (*(float *)(param_2 + 0x28) == fStack_c))) ||
        ((NAN(*(float *)(param_2 + 0x2c)) || NAN(fStack_8)) ==
         (*(float *)(param_2 + 0x2c) == fStack_8))) ||
       (cVar2 = FUN_01160ab0(&uStack_34), cVar2 == '\0')) {
      FUN_00ca4830(0,param_2);
      if (DAT_01d66ff4 == '\0') {
        uVar3 = FUN_0060efa0();
        FUN_00ca4830(1,uVar3);
      }
      else {
        uVar3 = FUN_0071fcc0(&uStack_34);
        FUN_00ca4830(1,uVar3);
      }
      goto LAB_00b4c77b;
    }
    if (0x3f < *(byte *)(param_1 + 0x74)) {
      return;
    }
  }
  uVar3 = FUN_0071fcc0(&uStack_34);
  uVar3 = FUN_0071f260(auStack_64,uVar3);
  FUN_00ca4830(0,uVar3);
  if (DAT_01d66ff4 == '\0') {
    uVar3 = FUN_0060efa0();
  }
  else {
    uVar3 = FUN_0071fcc0(auStack_64);
  }
  FUN_00ca4830(1,uVar3);
  *(byte *)(param_1 + 0x74) = *(byte *)(param_1 + 0x74) & 0x3f | 0x40;
LAB_00b4c77b:
  if (DAT_01d6700c == '\0') {
    FUN_008a4940(&DAT_0212c09c);
  }
  if (DAT_01d66ffc != '\0') {
    FUN_008a4940(&DAT_0212c144);
  }
  if (DAT_01d6700c != '\0') {
    FUN_008a4940(&DAT_0212c09c);
  }
  return;
}



/* FUNCTION 24165 ; VA 0x00b4c7d0 ; FUN_00b4c7d0 */

void __thiscall FUN_00b4c7d0(int param_1,int param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  undefined auStack_64 [48];
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  float fStack_10;
  float fStack_c;
  float fStack_8;
  
  iVar1 = *(int *)(param_1 + 0x58);
  *(byte *)(param_1 + 0x74) = *(byte *)(param_1 + 0x74) & 0x3f;
  uStack_34 = *(undefined4 *)(iVar1 + 0x70);
  uStack_30 = *(undefined4 *)(iVar1 + 0x74);
  uStack_2c = *(undefined4 *)(iVar1 + 0x78);
  uStack_28 = *(undefined4 *)(iVar1 + 0x7c);
  uStack_24 = *(undefined4 *)(iVar1 + 0x80);
  uStack_20 = *(undefined4 *)(iVar1 + 0x84);
  uStack_1c = *(undefined4 *)(iVar1 + 0x88);
  uStack_18 = *(undefined4 *)(iVar1 + 0x8c);
  uStack_14 = *(undefined4 *)(iVar1 + 0x90);
  fStack_10 = *(float *)(iVar1 + 0x94);
  fStack_c = *(float *)(iVar1 + 0x98);
  fStack_8 = *(float *)(iVar1 + 0x9c);
  if (((((NAN(*(float *)(param_2 + 0x24)) || NAN(fStack_10)) !=
         (*(float *)(param_2 + 0x24) == fStack_10)) &&
       ((NAN(*(float *)(param_2 + 0x28)) || NAN(fStack_c)) !=
        (*(float *)(param_2 + 0x28) == fStack_c))) &&
      ((NAN(*(float *)(param_2 + 0x2c)) || NAN(fStack_8)) !=
       (*(float *)(param_2 + 0x2c) == fStack_8))) &&
     (cVar2 = FUN_01160ab0(&uStack_34), cVar2 != '\0')) {
    return;
  }
  if ((*(byte *)(param_1 + 0x74) & 0x30) != 0) {
    FUN_00ca4830(1,param_2);
    FUN_008a4940(&DAT_0212c0d4);
    return;
  }
  uVar3 = FUN_0071fcc0(&uStack_34);
  uVar3 = FUN_0071f260(auStack_64,uVar3);
  FUN_00ca4830(0,uVar3);
  if (DAT_01d66ff4 == '\0') {
    uVar3 = FUN_0060efa0();
  }
  else {
    uVar3 = FUN_0071fcc0(auStack_64);
  }
  FUN_00ca4830(1,uVar3);
  *(byte *)(param_1 + 0x74) = *(byte *)(param_1 + 0x74) & 0x3f | 0x40;
  FUN_008a4940(&DAT_0212c09c);
  return;
}



/* FUNCTION 24166 ; VA 0x00b4c8e0 ; FUN_00b4c8e0 */

void __thiscall FUN_00b4c8e0(int param_1,byte param_2)

{
  if (param_2 != (*(byte *)(param_1 + 0x74) & 1)) {
    *(byte *)(param_1 + 0x74) = (*(byte *)(param_1 + 0x74) & 0xfe | param_2) & 0xfb | param_2 << 2;
    if (DAT_01d66ffc == '\0') {
      FUN_00b4bdd0();
    }
    else {
      FUN_00b4c600();
    }
    if ((DAT_01d66ffc == '\0') && ((*(byte *)(param_1 + 0x74) & 1) == 0)) {
      *(byte *)(param_1 + 0x74) = *(byte *)(param_1 + 0x74) & 0xf | 0x50;
    }
    FUN_008a4940(&DAT_0212c10c);
  }
  return;
}



/* FUNCTION 24167 ; VA 0x00b4c950 ; FUN_00b4c950 */

int * __thiscall FUN_00b4c950(int param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  int *piStack_30;
  int *piStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3759;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_00587490(&piStack_30);
  uStack_8 = 0;
  piVar5 = param_2;
  if (piStack_30 != param_2) {
    puVar3 = (undefined4 *)FUN_0060dcd0(auStack_28,param_2);
    iVar6 = puVar3[1];
    if (iVar6 != 0) {
      LOCK();
      *(int *)(iVar6 + 8) = *(int *)(iVar6 + 8) + 1;
      UNLOCK();
      iVar6 = puVar3[1];
    }
    *(undefined4 *)(param_1 + 0x5c) = *puVar3;
    piVar5 = *(int **)(param_1 + 0x60);
    *(int *)(param_1 + 0x60) = iVar6;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar6 = piVar5[2] + -1;
      piVar5[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
    piVar5 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_24[1] + -1;
      piStack_24[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar6 = *piVar1 + -1;
        *piVar1 = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (param_2 == (int *)0x0) {
      FUN_01679490();
    }
    else {
      piStack_14 = param_2 + 0x3c;
      uStack_8._0_1_ = 1;
      uVar4 = FUN_01675290(DAT_02110da8);
      uStack_8._0_1_ = 2;
      uStack_20 = uVar4;
      piStack_24 = (int *)FUN_01674e20(0x1c);
      if (piStack_24 == (int *)0x0) {
        piVar5 = (int *)0x0;
      }
      else {
        *piStack_24 = 0;
        piStack_24[1] = 1;
        piStack_24[2] = (int)FUN_00b4bf90;
        piStack_24[3] = (int)_guard_check_icall;
        piStack_24[4] = 0;
        piStack_24[5] = (int)piStack_14;
        piStack_24[6] = iStack_18;
        piVar5 = piStack_24;
      }
      FUN_016797d0(piVar5);
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
      }
      uStack_1c = 1;
      uStack_8._0_1_ = 3;
      param_2 = piVar5;
      FUN_01675290(uVar4);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      cVar2 = FUN_01679300(&param_2);
      if (cVar2 != '\0') {
        FUN_01679490();
        FUN_016791c0(&param_2);
      }
      uStack_8 = uStack_8 & 0xffffff00;
      if (param_2 != (int *)0x0) {
        piVar5 = param_2 + 1;
        LOCK();
        iVar6 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          FUN_01674ea0(param_2);
        }
      }
    }
    FUN_00b4c600();
    piVar5 = (int *)FUN_008a4940(&DAT_0212c024);
    if (DAT_01d67004 != '\0') {
      piVar5 = (int *)FUN_008a4940(&DAT_0212bfac);
    }
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_2c + 1;
    iVar6 = *piVar1;
    piVar5 = (int *)*piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      piVar5 = (int *)(**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piStack_2c + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        piVar5 = (int *)(**(code **)(*piStack_2c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 24168 ; VA 0x00b4cb50 ; FUN_00b4cb50 */

int * __thiscall FUN_00b4cb50(int param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  int *piStack_2c;
  int *piStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3799;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&piStack_2c);
  uStack_8 = 0;
  piVar5 = param_2;
  if (piStack_2c != param_2) {
    puVar3 = (undefined4 *)FUN_0060dcd0(auStack_24,param_2);
    iVar6 = puVar3[1];
    if (iVar6 != 0) {
      LOCK();
      *(int *)(iVar6 + 8) = *(int *)(iVar6 + 8) + 1;
      UNLOCK();
      iVar6 = puVar3[1];
    }
    *(undefined4 *)(param_1 + 0x5c) = *puVar3;
    piVar5 = *(int **)(param_1 + 0x60);
    *(int *)(param_1 + 0x60) = iVar6;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar6 = piVar5[2] + -1;
      piVar5[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
    piVar5 = piStack_20;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_20[1] + -1;
      piStack_20[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar6 = *piVar1 + -1;
        *piVar1 = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (param_2 == (int *)0x0) {
      FUN_01679490();
    }
    else {
      piStack_14 = param_2 + 0x3c;
      uStack_8._0_1_ = 1;
      uVar4 = FUN_01675290(DAT_02110da8);
      uStack_8._0_1_ = 2;
      uStack_1c = uVar4;
      piStack_20 = (int *)FUN_01674e20(0x1c);
      if (piStack_20 == (int *)0x0) {
        piVar5 = (int *)0x0;
      }
      else {
        *piStack_20 = 0;
        piStack_20[1] = 1;
        piStack_20[2] = (int)FUN_00b4bf90;
        piStack_20[3] = (int)_guard_check_icall;
        piStack_20[4] = 0;
        piStack_20[5] = (int)piStack_14;
        piStack_20[6] = param_1;
        piVar5 = piStack_20;
      }
      FUN_016797d0(piVar5);
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
      }
      uStack_18 = 1;
      uStack_8._0_1_ = 3;
      param_2 = piVar5;
      FUN_01675290(uVar4);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      cVar2 = FUN_01679300(&param_2);
      if (cVar2 != '\0') {
        FUN_01679490();
        FUN_016791c0(&param_2);
      }
      uStack_8 = uStack_8 & 0xffffff00;
      if (param_2 != (int *)0x0) {
        piVar5 = param_2 + 1;
        LOCK();
        iVar6 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          FUN_01674ea0(param_2);
        }
      }
    }
    *(byte *)(param_1 + 0x74) = *(byte *)(param_1 + 0x74) & 0xcf;
    piVar5 = (int *)FUN_00b4bdd0();
    if (DAT_01d66fec != '\0') {
      piVar5 = (int *)FUN_008a4940(&DAT_0212c024);
    }
    if (DAT_01d67004 != '\0') {
      piVar5 = (int *)FUN_008a4940(&DAT_0212bfac);
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_28 + 1;
    iVar6 = *piVar1;
    piVar5 = (int *)*piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      piVar5 = (int *)(**(code **)*piStack_28)();
      LOCK();
      piVar1 = piStack_28 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        piVar5 = (int *)(**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 24169 ; VA 0x00b4cd60 ; FUN_00b4cd60 */

int * __thiscall FUN_00b4cd60(int param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  int *piStack_30;
  int *piStack_2c;
  undefined auStack_28 [4];
  int *piStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3759;
  pvStack_10 = ExceptionList;
  uStack_1c = 0;
  ExceptionList = &pvStack_10;
  iStack_18 = param_1;
  FUN_00587490(&piStack_30);
  uStack_8 = 0;
  piVar5 = param_2;
  if (piStack_30 != param_2) {
    puVar3 = (undefined4 *)FUN_0060dcd0(auStack_28,param_2);
    iVar6 = puVar3[1];
    if (iVar6 != 0) {
      LOCK();
      *(int *)(iVar6 + 8) = *(int *)(iVar6 + 8) + 1;
      UNLOCK();
      iVar6 = puVar3[1];
    }
    *(undefined4 *)(param_1 + 100) = *puVar3;
    piVar5 = *(int **)(param_1 + 0x68);
    *(int *)(param_1 + 0x68) = iVar6;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar6 = piVar5[2] + -1;
      piVar5[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
    piVar5 = piStack_24;
    if (piStack_24 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_24[1] + -1;
      piStack_24[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_24)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar6 = *piVar1 + -1;
        *piVar1 = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (param_2 == (int *)0x0) {
      FUN_01679490();
    }
    else {
      piStack_14 = param_2 + 0x3c;
      uStack_8._0_1_ = 1;
      uVar4 = FUN_01675290(DAT_02110da8);
      uStack_8._0_1_ = 2;
      uStack_20 = uVar4;
      piStack_24 = (int *)FUN_01674e20(0x1c);
      if (piStack_24 == (int *)0x0) {
        piVar5 = (int *)0x0;
      }
      else {
        *piStack_24 = 0;
        piStack_24[1] = 1;
        piStack_24[2] = (int)FUN_00b4bf90;
        piStack_24[3] = (int)_guard_check_icall;
        piStack_24[4] = 0;
        piStack_24[5] = (int)piStack_14;
        piStack_24[6] = iStack_18;
        piVar5 = piStack_24;
      }
      FUN_016797d0(piVar5);
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
      }
      uStack_1c = 1;
      uStack_8._0_1_ = 3;
      param_2 = piVar5;
      FUN_01675290(uVar4);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      cVar2 = FUN_01679300(&param_2);
      if (cVar2 != '\0') {
        FUN_01679490();
        FUN_016791c0(&param_2);
      }
      uStack_8 = uStack_8 & 0xffffff00;
      if (param_2 != (int *)0x0) {
        piVar5 = param_2 + 1;
        LOCK();
        iVar6 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          FUN_01674ea0(param_2);
        }
      }
    }
    FUN_00b4c600();
    piVar5 = (int *)FUN_008a4940(&DAT_0212c060);
    if (DAT_01d67004 != '\0') {
      piVar5 = (int *)FUN_008a4940(&DAT_0212bfe8);
    }
  }
  if (piStack_2c != (int *)0x0) {
    LOCK();
    piVar1 = piStack_2c + 1;
    iVar6 = *piVar1;
    piVar5 = (int *)*piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      piVar5 = (int *)(**(code **)*piStack_2c)();
      LOCK();
      piVar1 = piStack_2c + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        piVar5 = (int *)(**(code **)(*piStack_2c + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 24170 ; VA 0x00b4cf60 ; FUN_00b4cf60 */

int * __thiscall FUN_00b4cf60(int param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  int *piStack_2c;
  int *piStack_28;
  undefined auStack_24 [4];
  int *piStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  int *piStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  uint uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3799;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  FUN_00587490(&piStack_2c);
  uStack_8 = 0;
  piVar5 = param_2;
  if (piStack_2c != param_2) {
    puVar3 = (undefined4 *)FUN_0060dcd0(auStack_24,param_2);
    iVar6 = puVar3[1];
    if (iVar6 != 0) {
      LOCK();
      *(int *)(iVar6 + 8) = *(int *)(iVar6 + 8) + 1;
      UNLOCK();
      iVar6 = puVar3[1];
    }
    *(undefined4 *)(param_1 + 100) = *puVar3;
    piVar5 = *(int **)(param_1 + 0x68);
    *(int *)(param_1 + 0x68) = iVar6;
    if (piVar5 != (int *)0x0) {
      LOCK();
      iVar6 = piVar5[2] + -1;
      piVar5[2] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)(*piVar5 + 4))();
      }
    }
    piVar5 = piStack_20;
    if (piStack_20 != (int *)0x0) {
      LOCK();
      iVar6 = piStack_20[1] + -1;
      piStack_20[1] = iVar6;
      UNLOCK();
      if (iVar6 == 0) {
        (**(code **)*piStack_20)();
        LOCK();
        piVar1 = piVar5 + 2;
        iVar6 = *piVar1 + -1;
        *piVar1 = iVar6;
        UNLOCK();
        if (iVar6 == 0) {
          (**(code **)(*piVar5 + 4))();
        }
      }
    }
    if (param_2 == (int *)0x0) {
      FUN_01679490();
    }
    else {
      piStack_14 = param_2 + 0x3c;
      uStack_8._0_1_ = 1;
      uVar4 = FUN_01675290(DAT_02110da8);
      uStack_8._0_1_ = 2;
      uStack_1c = uVar4;
      piStack_20 = (int *)FUN_01674e20(0x1c);
      if (piStack_20 == (int *)0x0) {
        piVar5 = (int *)0x0;
      }
      else {
        *piStack_20 = 0;
        piStack_20[1] = 1;
        piStack_20[2] = (int)FUN_00b4bf90;
        piStack_20[3] = (int)_guard_check_icall;
        piStack_20[4] = 0;
        piStack_20[5] = (int)piStack_14;
        piStack_20[6] = param_1;
        piVar5 = piStack_20;
      }
      FUN_016797d0(piVar5);
      if (piVar5 != (int *)0x0) {
        LOCK();
        piVar5[1] = piVar5[1] + 1;
        UNLOCK();
      }
      uStack_18 = 1;
      uStack_8._0_1_ = 3;
      param_2 = piVar5;
      FUN_01675290(uVar4);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      cVar2 = FUN_01679300(&param_2);
      if (cVar2 != '\0') {
        FUN_01679490();
        FUN_016791c0(&param_2);
      }
      uStack_8 = uStack_8 & 0xffffff00;
      if (param_2 != (int *)0x0) {
        piVar5 = param_2 + 1;
        LOCK();
        iVar6 = *piVar5;
        *piVar5 = *piVar5 + -1;
        UNLOCK();
        if (iVar6 == 1) {
          FUN_01674ea0(param_2);
        }
      }
    }
    *(byte *)(param_1 + 0x74) = *(byte *)(param_1 + 0x74) & 0xcf;
    piVar5 = (int *)FUN_00b4bdd0();
    if (DAT_01d66fec != '\0') {
      piVar5 = (int *)FUN_008a4940(&DAT_0212c060);
    }
    if (DAT_01d67004 != '\0') {
      piVar5 = (int *)FUN_008a4940(&DAT_0212bfe8);
    }
  }
  if (piStack_28 != (int *)0x0) {
    LOCK();
    piVar1 = piStack_28 + 1;
    iVar6 = *piVar1;
    piVar5 = (int *)*piVar1;
    *piVar1 = iVar6 + -1;
    UNLOCK();
    if (iVar6 + -1 == 0) {
      piVar5 = (int *)(**(code **)*piStack_28)();
      LOCK();
      piVar1 = piStack_28 + 2;
      iVar6 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar6 == 1) {
        piVar5 = (int *)(**(code **)(*piStack_28 + 4))();
      }
    }
  }
  ExceptionList = pvStack_10;
  return piVar5;
}



/* FUNCTION 24171 ; VA 0x00b4d170 ; FUN_00b4d170 */

void __thiscall FUN_00b4d170(int param_1,uint param_2)

{
  byte bVar1;
  byte bVar2;
  
  bVar1 = *(byte *)(param_1 + 0x74);
  if (((bVar1 >> 1 & 1) * 2 | bVar1 & 1) != param_2) {
    bVar2 = (byte)param_2 & 1;
    *(byte *)(param_1 + 0x74) =
         ((byte)param_2 & 0xfe ^ bVar1) & 2 ^ (bVar1 & 0xfa | bVar2 | bVar2 << 2);
    if (DAT_01d66ffc != '\0') {
      FUN_00b4bdd0();
      FUN_008a4940(&DAT_0212c144);
      if (DAT_01d6700c == '\0') {
        FUN_008a4940(&DAT_0212c09c);
      }
      if ((bVar1 & 1) != (param_2 & 1)) {
        FUN_008a4940(&DAT_0212c10c);
      }
    }
  }
  return;
}



/* FUNCTION 24172 ; VA 0x00b4d210 ; FUN_00b4d210 */

undefined * FUN_00b4d210(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f37bc;
  pvStack_10 = ExceptionList;
  if (DAT_01eee994 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eeeba0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eeeba0);
      if (DAT_01eeeba0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00aff8c0();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"TriangleMeshPart",0,uStack_20,0,0,0x1b,0,0);
        FUN_016f3654(&LAB_0188dd40);
        FUN_016f37bf(&DAT_01eeeba0);
      }
    }
    DAT_01eee994 = &DAT_01eee998;
  }
  ExceptionList = pvStack_10;
  return DAT_01eee994;
}



/* FUNCTION 24173 ; VA 0x00b4d2f0 ; FUN_00b4d2f0 */

void FUN_00b4d2f0(int *param_1)

{
  int iVar1;
  int iStack_6c;
  int iStack_68;
  char cStack_64;
  int iStack_60;
  char acStack_5c [72];
  undefined *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f37d8;
  pvStack_10 = ExceptionList;
  puStack_14 = &stack0xffffff88;
  iStack_6c = -0x3ea8cf1e;
  iStack_68 = 0x7f0725e3;
  cStack_64 = '\0';
  iStack_60 = 0;
  acStack_5c[0] = '\0';
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = iStack_60;
  do {
    iStack_60 = iVar1;
    if (*param_1 == iStack_6c) {
LAB_00b4d3d3:
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        CloseHandle(iStack_60);
      }
      ExceptionList = pvStack_10;
      return;
    }
    LOCK();
    iVar1 = *param_1;
    if (iVar1 == 0) {
      *param_1 = iStack_68;
      iVar1 = 0;
    }
    UNLOCK();
    if (iVar1 == 0) {
      if (iStack_60 == 0) {
        if (acStack_5c[0] == '\0') {
          FUN_005881c0(acStack_5c,param_1);
        }
        iVar1 = OpenEventA(0x100002,0,acStack_5c);
        if ((iStack_60 != 0) && (iStack_60 != -1)) {
          CloseHandle(iStack_60);
        }
        iStack_60 = iVar1;
        if (iVar1 != 0) goto LAB_00b4d39e;
      }
      else {
LAB_00b4d39e:
        ResetEvent(iStack_60);
      }
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_0087c450(&DAT_018bee70,"MigrateTriangleMeshData3",&DAT_018bc9b8,0,0,0);
      FUN_0057b500(param_1,&iStack_6c);
      goto LAB_00b4d3d3;
    }
    if (cStack_64 == '\0') {
      LOCK();
      param_1[1] = param_1[1] + 1;
      UNLOCK();
      cStack_64 = '\x01';
      if (*param_1 == iStack_6c) goto LAB_00b4d3d3;
      if (iStack_60 != 0) goto LAB_00b4d44d;
      if (acStack_5c[0] == '\0') {
        FUN_005881c0(acStack_5c,param_1);
      }
      iVar1 = CreateEventA(0,1,0,acStack_5c);
      if ((iStack_60 != 0) && (iStack_60 != -1)) {
        CloseHandle(iStack_60);
      }
    }
    else {
LAB_00b4d44d:
      WaitForSingleObjectEx(iStack_60,0xffffffff,0);
      iVar1 = iStack_60;
    }
  } while( true );
}



/* FUNCTION 24174 ; VA 0x00b4d45d ; Catch_All@00b4d45d */

void Catch_All_00b4d45d(void)

{
  int unaff_EBP;
  
  FUN_0058a8e0(*(undefined4 *)(unaff_EBP + 8),unaff_EBP + -0x68);
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24175 ; VA 0x00b4d480 ; FUN_00b4d480 */

int * __thiscall FUN_00b4d480(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  undefined auStack_d8 [200];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_0179394b;
  pvStack_10 = ExceptionList;
  iVar1 = *param_1;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_0088d4b0();
  if (iVar1 != iVar2) {
    puVar3 = (undefined4 *)param_1[1];
    if (puVar3 != (undefined4 *)0x0) {
      (*(code *)*puVar3)(param_1 + 2,auStack_d8);
      puVar3 = (undefined4 *)param_1[1];
    }
    uStack_8 = 0;
    piVar4 = (int *)FUN_0088b330();
    iVar1 = *piVar4;
    *param_2 = iVar1;
    LOCK();
    piVar4 = (int *)(iVar1 + 0x28);
    *piVar4 = *piVar4 + 1;
    UNLOCK();
    uStack_8 = 1;
    if (puVar3 != (undefined4 *)0x0) {
      (*(code *)puVar3[2])(auStack_d8);
    }
    ExceptionList = pvStack_10;
    return param_2;
  }
  iVar1 = *param_1;
  iVar2 = FUN_0088d4b0();
  if (iVar1 == iVar2) {
    piVar4 = param_1 + 2;
    if (param_1[1] == 0) {
      piVar4 = (int *)0x0;
    }
    iVar1 = *piVar4;
    *param_2 = iVar1;
    LOCK();
    piVar4 = (int *)(iVar1 + 0x28);
    *piVar4 = *piVar4 + 1;
    UNLOCK();
    ExceptionList = pvStack_10;
    return param_2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24176 ; VA 0x00b4d580 ; FUN_00b4d580 */

undefined4 * __fastcall FUN_00b4d580(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 *puStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f380e;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  uStack_24 = 0x40800000;
  uStack_20 = 0x3f99999a;
  uStack_1c = 0x40000000;
  ExceptionList = &pvStack_10;
  puStack_14 = param_1;
  FUN_00b00ef0(&uStack_24,0);
  *param_1 = RBX::Described<class_RBX::TriangleMeshPart,class_RBX::PartInstance>::vftable;
  param_1[0x16] = RBX::Described<class_RBX::TriangleMeshPart,class_RBX::PartInstance>::vftable;
  param_1[0x1e] = RBX::Described<class_RBX::TriangleMeshPart,class_RBX::PartInstance>::vftable;
  param_1[0x25] = RBX::Described<class_RBX::TriangleMeshPart,class_RBX::PartInstance>::vftable;
  uStack_8 = 1;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::Described<class_RBX::TriangleMeshPart,class_RBX::PartInstance>::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0xa8;
  uVar1 = FUN_00b4d210();
  param_1[3] = uVar1;
  *param_1 = RBX::TriangleMeshPart::vftable;
  param_1[0x16] = RBX::TriangleMeshPart::vftable;
  param_1[0x1e] = RBX::TriangleMeshPart::vftable;
  param_1[0x25] = RBX::TriangleMeshPart::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::TriangleMeshPart::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0x100
  ;
  param_1[0x42] = 0;
  param_1[0x43] = 0xf;
  *(undefined *)(param_1 + 0x3e) = 0;
  uStack_8 = 3;
  FUN_00a33c70();
  param_1[0x45] = 0;
  param_1[0x46] = 0;
  param_1[0x47] = 0;
  param_1[0x4c] = 0;
  param_1[0x4d] = 0xf;
  *(undefined *)(param_1 + 0x48) = 0;
  param_1[0x4e] = 1;
  param_1[0x4f] = 0;
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24177 ; VA 0x00b4d6e0 ; FUN_00b4d6e0 */

void __fastcall FUN_00b4d6e0(int param_1)

{
  if (*(int *)(param_1 + 4) != 0) {
    FUN_01674ea0(*(int *)(param_1 + 4),0x24);
  }
  return;
}



/* FUNCTION 24178 ; VA 0x00b4d700 ; FUN_00b4d700 */

void __fastcall FUN_00b4d700(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar3;
        FUN_01674ea0(puVar3,0x24);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar3 = (undefined4 *)*puVar1;
      } while (puVar3 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 24179 ; VA 0x00b4d780 ; FUN_00b4d780 */

void __fastcall FUN_00b4d780(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  iVar4 = *(int *)(param_1 + 0x14);
  if (iVar4 != 0) {
    if (*(int *)(param_1 + 8) != 0) {
      puVar1 = (undefined4 *)(iVar4 + *(int *)(param_1 + 4) * 4);
      puVar3 = (undefined4 *)*puVar1;
      do {
        *puVar1 = *puVar3;
        FUN_01674ea0(puVar3,0x24);
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + -1;
        puVar3 = (undefined4 *)*puVar1;
      } while (puVar3 != (undefined4 *)0x0);
      iVar4 = *(int *)(param_1 + 0x14);
    }
    iVar2 = *(int *)(param_1 + 4) * 4;
    uVar6 = iVar2 + 4;
    iVar5 = iVar4;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar4 + -4);
      uVar6 = iVar2 + 0x27;
      if (0x1f < (iVar4 - iVar5) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
    *(undefined4 *)(param_1 + 0x14) = 0;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}



/* FUNCTION 24180 ; VA 0x00b4d790 ; FUN_00b4d790 */

void __fastcall FUN_00b4d790(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x134);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x120);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00b4d84c;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x130) = 0;
  *(undefined4 *)(param_1 + 0x134) = 0xf;
  *(undefined *)(param_1 + 0x120) = 0;
  FUN_0056cd30();
  uVar1 = *(uint *)(param_1 + 0x10c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0xf8);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00b4d84c:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x108) = 0;
  *(undefined4 *)(param_1 + 0x10c) = 0xf;
  *(undefined *)(param_1 + 0xf8) = 0;
  FUN_00b013e0();
  return;
}



/* FUNCTION 24181 ; VA 0x00b4d85a ; FUN_00b4d85a */

void FUN_00b4d85a(void)

{
  FUN_00b4d930();
  return;
}



/* FUNCTION 24182 ; VA 0x00b4d870 ; FUN_00b4d870 */

undefined4 * __thiscall FUN_00b4d870(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::CollisionFidelity>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 24183 ; VA 0x00b4d8a0 ; FUN_00b4d8a0 */

undefined4 * __thiscall FUN_00b4d8a0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::SharedString>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x28);
  }
  return param_1;
}



/* FUNCTION 24184 ; VA 0x00b4d8d0 ; FUN_00b4d8d0 */

undefined4 * __thiscall FUN_00b4d8d0(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<class_RBX::SharedString>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 24185 ; VA 0x00b4d900 ; FUN_00b4d900 */

undefined4 * __thiscall FUN_00b4d900(undefined4 *param_1,byte param_2)

{
  *param_1 = RBX::Reflection::TypedPropertyDescriptor<enum_RBX::CollisionFidelity>::GetSet::vftable;
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,4);
  }
  return param_1;
}



/* FUNCTION 24186 ; VA 0x00b4d930 ; FUN_00b4d930 */

int __thiscall FUN_00b4d930(int param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x134);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x120);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00b4da09;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x130) = 0;
  *(undefined4 *)(param_1 + 0x134) = 0xf;
  *(undefined *)(param_1 + 0x120) = 0;
  FUN_0056cd30();
  uVar1 = *(uint *)(param_1 + 0x10c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0xf8);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00b4da09:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x108) = 0;
  *(undefined4 *)(param_1 + 0x10c) = 0xf;
  *(undefined *)(param_1 + 0xf8) = 0;
  FUN_00b013e0();
  if ((param_2 & 1) != 0) {
    FUN_01674ea0(param_1,0x158);
  }
  return param_1;
}



/* FUNCTION 24187 ; VA 0x00b4da10 ; FUN_00b4da10 */

void __thiscall FUN_00b4da10(int param_1,undefined4 param_2,undefined4 param_3)

{
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017ad2a8;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  (**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&param_2,param_2);
  uStack_8 = 0;
  (**(code **)(**(int **)(param_1 + 0x34) + 0x10))(param_3,&param_2);
  FUN_0056cd30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24188 ; VA 0x00b4da70 ; FUN_00b4da70 */

void __thiscall FUN_00b4da70(int param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int *piVar3;
  uint uVar4;
  undefined4 *puVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  
  uVar9 = *(uint *)(*(int *)(param_3 + 4) + 0xc);
  uVar8 = uVar9 % *(uint *)(param_1 + 4);
  if (*(int *)(param_1 + 8) == 0) {
LAB_00b4dad2:
    iVar10 = 0;
  }
  else {
    piVar3 = *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4);
    if (piVar3 == (int *)0x0) {
      iVar10 = 0;
    }
    else {
      iVar10 = *piVar3;
    }
    for (; iVar10 != 0; iVar10 = **(int **)(iVar10 + 4)) {
      if (uVar9 == *(uint *)(iVar10 + 8)) {
        if (uVar9 == *(uint *)(iVar10 + 0xc)) break;
      }
      else if (*(uint *)(iVar10 + 8) % *(uint *)(param_1 + 4) != uVar8) goto LAB_00b4dad2;
    }
  }
  uVar4 = *(uint *)(param_1 + 8);
  uVar8 = uVar4 + 1;
  if (*(int *)(param_1 + 0x14) == 0) {
    uVar8 = FUN_005c9310(uVar8);
    if (uVar8 <= *(uint *)(param_1 + 4)) {
      uVar8 = *(uint *)(param_1 + 4);
    }
    FUN_005d2b00(uVar8);
  }
  else if (*(uint *)(param_1 + 0x10) < uVar8) {
    uVar7 = uVar4 >> 1;
    if ((uVar4 >> 1) + uVar4 <= uVar8) {
      uVar7 = 1;
    }
    iVar6 = FUN_005c9310(uVar7 + uVar4);
    if (iVar6 != *(int *)(param_1 + 4)) {
      FUN_005d2b00(iVar6);
      iVar6 = *(int *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      piVar3 = (int *)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 4) * 4);
      while (iVar6 != 0) {
        piVar2 = *(int **)(iVar6 + 4);
        uVar8 = (uint)piVar2[2] % *(uint *)(param_1 + 4);
        piVar1 = (int *)(*(int *)(param_1 + 0x14) + uVar8 * 4);
        if (*(int *)(*(int *)(param_1 + 0x14) + uVar8 * 4) == 0) {
          *piVar1 = (int)piVar3;
          iVar6 = *piVar2;
          piVar3 = piVar2;
        }
        else {
          iVar6 = *piVar2;
          *piVar2 = *(int *)*piVar1;
          *(int *)*piVar1 = *piVar3;
          *piVar3 = iVar6;
        }
      }
    }
  }
  piVar3 = *(int **)(param_3 + 4);
  *(undefined4 *)(param_3 + 4) = 0;
  piVar3[2] = uVar9;
  if (iVar10 == 0) {
    uVar9 = uVar9 % *(uint *)(param_1 + 4);
    puVar5 = *(undefined4 **)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    piVar1 = (int *)(*(int *)(param_1 + 0x14) + uVar9 * 4);
    if (puVar5 == (undefined4 *)0x0) {
      piVar2 = (int *)(*(int *)(param_1 + 0x14) + *(uint *)(param_1 + 4) * 4);
      if (*piVar2 != 0) {
        *(int **)(*(int *)(param_1 + 0x14) + (*(uint *)(*piVar2 + 8) % *(uint *)(param_1 + 4)) * 4)
             = piVar3;
      }
      *piVar1 = (int)piVar2;
      *piVar3 = *piVar2;
      *piVar2 = (int)piVar3;
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      *param_2 = (int)piVar3;
      return;
    }
    *piVar3 = *puVar5;
    *(int **)*piVar1 = piVar3;
  }
  else {
    *piVar3 = **(undefined4 **)(iVar10 + 4);
    piVar3[1] = *(int *)(iVar10 + 4);
    **(int **)(iVar10 + 4) = (int)piVar3;
    *(int **)(iVar10 + 4) = piVar3;
    if ((*piVar3 != 0) &&
       (uVar8 = *(uint *)(*piVar3 + 8) % *(uint *)(param_1 + 4),
       uVar8 != uVar9 % *(uint *)(param_1 + 4))) {
      *(int **)(*(int *)(param_1 + 0x14) + uVar8 * 4) = piVar3;
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      *param_2 = (int)piVar3;
      return;
    }
  }
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  *param_2 = (int)piVar3;
  return;
}



/* FUNCTION 24189 ; VA 0x00b4dc40 ; FUN_00b4dc40 */

void __fastcall FUN_00b4dc40(int param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  
  puVar3 = (undefined4 *)(**(code **)(param_1 + 8))();
  puVar4 = (undefined4 *)(**(code **)(param_1 + 8))();
  puVar1 = puVar4 + 4;
  if (0xf < (uint)puVar4[5]) {
    puVar4 = (undefined4 *)*puVar4;
  }
  puVar2 = puVar3 + 4;
  if (0xf < (uint)puVar3[5]) {
    puVar3 = (undefined4 *)*puVar3;
  }
  FUN_0055c360(puVar3,*puVar2,puVar4,*puVar1);
  return;
}



/* FUNCTION 24190 ; VA 0x00b4dcb0 ; FUN_00b4dcb0 */

void __fastcall FUN_00b4dcb0(int param_1)

{
  undefined4 uVar1;
  
  (**(code **)(param_1 + 8))();
  uVar1 = (**(code **)(param_1 + 8))();
  FUN_00a33d60(uVar1);
  return;
}



/* FUNCTION 24191 ; VA 0x00b4dd00 ; FUN_00b4dd00 */

void __thiscall FUN_00b4dd00(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  undefined auStack_40 [24];
  int aiStack_28 [3];
  undefined4 uStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f38d0;
  pvStack_10 = ExceptionList;
  if (param_2 == 2) {
    ExceptionList = &pvStack_10;
    FUN_00c17120(3);
    pcVar1 = *(code **)(*param_1 + 0x158);
    uVar2 = FUN_00ccaa10(aiStack_28);
    uStack_8 = 0;
    uVar2 = FUN_00a33be0(uVar2);
    uStack_8 = CONCAT31(uStack_8._1_3_,1);
    (*pcVar1)(uVar2);
    FUN_0056cd30();
    if (0xf < uStack_14) {
      uVar4 = uStack_14 + 1;
      iVar3 = aiStack_28[0];
      if (0xfff < uVar4) {
        iVar3 = *(int *)(aiStack_28[0] + -4);
        uVar4 = uStack_14 + 0x24;
        if (0x1f < (aiStack_28[0] - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar4);
      ExceptionList = pvStack_10;
      return;
    }
  }
  else {
    if ((param_2 == 0) || (param_2 == 3)) {
      uVar2 = 0;
      uStack_1c = CONCAT31(uStack_1c._1_3_,(param_2 == 3) + '\x02');
      uStack_18 = param_3;
      ExceptionList = &pvStack_10;
      iVar3 = FUN_008f7870(param_1);
      if ((iVar3 != 0) && (*(int *)(iVar3 + 0x1b8) != 0)) {
        uVar2 = *(undefined4 *)(*(int *)(iVar3 + 0x1b8) + 0x214);
      }
      pcVar1 = *(code **)(*param_1 + 0x158);
      uVar2 = FUN_00cc8c80(aiStack_28,uStack_1c,uStack_18,param_4,uVar2);
      uStack_8 = 2;
      uVar2 = FUN_00a33be0(uVar2);
      uStack_8 = CONCAT31(uStack_8._1_3_,3);
      (*pcVar1)(uVar2);
      FUN_0056cd30();
    }
    else {
      if (param_2 != 1) {
        return;
      }
      uStack_1c = CONCAT31(uStack_1c._1_3_,1);
      uStack_18 = param_3;
      pcVar1 = *(code **)(*param_1 + 0x158);
      ExceptionList = &pvStack_10;
      uVar2 = FUN_00cca0e0(auStack_40,uStack_1c,param_3,param_4);
      uStack_8 = 4;
      uVar2 = FUN_00a33be0(uVar2);
      uStack_8 = CONCAT31(uStack_8._1_3_,5);
      (*pcVar1)(uVar2);
      FUN_0056cd30();
    }
    FUN_005507b0();
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24192 ; VA 0x00b4ded0 ; FUN_00b4ded0 */

void FUN_00b4ded0(void)

{
  int iVar1;
  
  if (DAT_01eeeba4 == 0) {
    iVar1 = FUN_00b4d210();
    DAT_01eeeba4 = *(int *)(iVar1 + 4);
  }
  return;
}



/* FUNCTION 24193 ; VA 0x00b4def0 ; FUN_00b4def0 */

bool __fastcall FUN_00b4def0(int param_1)

{
  undefined4 *puVar1;
  int iVar2;
  char cVar3;
  
  iVar2 = FUN_00c15b40();
  if (iVar2 == 0xb) {
    if (param_1 == 0) {
      iVar2 = 0;
    }
    else {
      iVar2 = *(int *)(param_1 + 0xa8);
    }
    cVar3 = '\0';
    puVar1 = *(undefined4 **)(*(int *)(iVar2 + 0x1ac) + 0x24);
    if ((puVar1 != (undefined4 *)0x0) &&
       (cVar3 = *(char *)(puVar1 + 1), *(int *)(*(int *)(iVar2 + 0x1ac) + 0x14) < DAT_019786c4)) {
      iVar2 = (**(code **)(*(int *)*puVar1 + 0x58))();
      return iVar2 == 1;
    }
    if (cVar3 == '\x01') {
      return true;
    }
    if (cVar3 == '\x02') {
      return false;
    }
    if (cVar3 == '\x03') {
      return (bool)3;
    }
  }
  return (bool)2;
}



/* FUNCTION 24194 ; VA 0x00b4df70 ; FUN_00b4df70 */

void __thiscall FUN_00b4df70(int param_1,float *param_2)

{
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  
  fVar3 = DAT_018c45c4;
  fVar2 = DAT_018f76ac;
  if (DAT_018f76ac <= *(float *)(param_1 + 0x114)) {
    fVar2 = *(float *)(param_1 + 0x114);
  }
  fVar1 = DAT_018c45c4;
  if (fVar2 <= DAT_018c45c4) {
    fVar1 = fVar2;
  }
  fVar2 = DAT_018f76ac;
  if (DAT_018f76ac <= *(float *)(param_1 + 0x118)) {
    fVar2 = *(float *)(param_1 + 0x118);
  }
  fVar4 = DAT_018f76ac;
  if (DAT_018f76ac <= *(float *)(param_1 + 0x11c)) {
    fVar4 = *(float *)(param_1 + 0x11c);
  }
  *param_2 = fVar1;
  fVar1 = fVar3;
  if (fVar2 <= fVar3) {
    fVar1 = fVar2;
  }
  if (fVar4 <= fVar3) {
    fVar3 = fVar4;
  }
  param_2[1] = fVar1;
  param_2[2] = fVar3;
  return;
}



/* FUNCTION 24195 ; VA 0x00b4dfd0 ; FUN_00b4dfd0 */

int __fastcall FUN_00b4dfd0(int param_1)

{
  return param_1 + 0x120;
}



/* FUNCTION 24196 ; VA 0x00b4dfe0 ; FUN_00b4dfe0 */

float10 __fastcall FUN_00b4dfe0(int param_1)

{
  if ((DAT_01d67050 != '\0') && (*(int *)(param_1 + 0x138) == 0)) {
    return (float10)0.0;
  }
  return (float10)*(float *)(param_1 + 0x138 + *(int *)(param_1 + 0x138) * 4);
}



/* FUNCTION 24197 ; VA 0x00b4e01f ; FUN_00b4e01f */

void FUN_00b4e01f(void)

{
  FUN_00afc020();
  return;
}



/* FUNCTION 24198 ; VA 0x00b4e030 ; FUN_00b4e030 */

int __fastcall FUN_00b4e030(int param_1)

{
  return param_1 + 0x110;
}



/* FUNCTION 24199 ; VA 0x00b4e040 ; FUN_00b4e040 */

uint FUN_00b4e040(void)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  uint uVar3;
  
  puVar2 = (undefined4 *)FUN_00a33fa0();
  puVar1 = puVar2 + 4;
  if (0xf < (uint)puVar2[5]) {
    puVar2 = (undefined4 *)*puVar2;
  }
  uVar3 = FUN_0055c360(puVar2,*puVar1,&DAT_018bc9b8,0);
  return uVar3 ^ 1;
}



/* FUNCTION 24200 ; VA 0x00b4e070 ; FUN_00b4e070 */

undefined4 __thiscall FUN_00b4e070(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  
  uVar1 = (**(code **)(param_1 + 8))();
  FUN_0054ef60(uVar1);
  return param_2;
}



/* FUNCTION 24201 ; VA 0x00b4e0b0 ; FUN_00b4e0b0 */

void __thiscall FUN_00b4e0b0(int param_1,int *param_2)

{
  int iVar1;
  int *piVar2;
  
  piVar2 = (int *)(**(code **)(param_1 + 8))();
  iVar1 = *piVar2;
  *param_2 = iVar1;
  LOCK();
  piVar2 = (int *)(iVar1 + 0x28);
  *piVar2 = *piVar2 + 1;
  UNLOCK();
  return;
}



/* FUNCTION 24202 ; VA 0x00b4e0f0 ; FUN_00b4e0f0 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b4e0f0(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined *puVar2;
  int *piVar3;
  undefined4 uVar4;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9c38;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  piVar3 = (int *)(**(code **)(**(int **)(param_1 + 0x34) + 0xc))(&iStack_14,param_2);
  uStack_8 = 0;
  uVar4 = FUN_0088d4b0();
  iVar1 = *(int *)((int)ThreadLocalStoragePointer + _tls_index * 4);
  *param_3 = uVar4;
  if (*(int *)(iVar1 + 0x34) < DAT_01ead2c8) {
    FUN_016f3809(&DAT_01ead2c8);
    if (DAT_01ead2c8 == -1) {
      _DAT_01ead2bc = FUN_0061a010;
      _DAT_01ead2c0 = FUN_0061a010;
      _DAT_01ead2c4 = FUN_0061bd50;
      FUN_016f37bf(&DAT_01ead2c8);
    }
  }
  puVar2 = (undefined *)param_3[1];
  if (puVar2 == &DAT_01ead2bc) {
    iVar1 = *piVar3;
    LOCK();
    piVar3 = (int *)(iVar1 + 0x28);
    *piVar3 = *piVar3 + 1;
    UNLOCK();
    param_3[2] = iVar1;
    FUN_0056cd30();
  }
  else {
    if (puVar2 != (undefined *)0x0) {
      (**(code **)(puVar2 + 8))(param_3 + 2);
      param_3[1] = 0;
    }
    iVar1 = *piVar3;
    param_3[2] = iVar1;
    LOCK();
    piVar3 = (int *)(iVar1 + 0x28);
    *piVar3 = *piVar3 + 1;
    UNLOCK();
    param_3[1] = &DAT_01ead2bc;
  }
  FUN_0056cd30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24203 ; VA 0x00b4e200 ; FUN_00b4e200 */

void __thiscall FUN_00b4e200(int param_1,undefined4 param_2,undefined4 *param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0x38) + 0xc))(param_2);
  uVar3 = thunk_FUN_00b0f580();
  *param_3 = uVar3;
  iVar4 = FUN_00b0f8e0();
  iVar1 = param_3[1];
  if (iVar1 == iVar4) {
    param_3[2] = uVar2;
    return;
  }
  if (iVar1 != 0) {
    (**(code **)(iVar1 + 8))(param_3 + 2);
  }
  param_3[2] = uVar2;
  param_3[1] = iVar4;
  return;
}



/* FUNCTION 24204 ; VA 0x00b4e260 ; FUN_00b4e260 */

void __thiscall FUN_00b4e260(int *param_1,int param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  code *pcVar7;
  int *piVar8;
  undefined auStack_168 [52];
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  undefined4 uStack_11c;
  undefined4 uStack_118;
  undefined4 uStack_114;
  undefined4 uStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  int iStack_104;
  undefined **appuStack_100 [4];
  undefined *puStack_f0;
  undefined **appuStack_e8 [3];
  int *piStack_dc;
  int *piStack_d8;
  int *piStack_cc;
  uint *puStack_c8;
  int *piStack_bc;
  uint uStack_b0;
  uint uStack_ac;
  undefined **ppuStack_98;
  undefined auStack_50 [4];
  undefined auStack_4c [16];
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined auStack_34 [16];
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_18;
  undefined auStack_14 [4];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f395b;
  pvStack_10 = ExceptionList;
  uStack_18 = 0;
  ExceptionList = &pvStack_10;
  if (DAT_01d62d44 != '\0') {
    ExceptionList = &pvStack_10;
    FUN_00b4d2f0(&DAT_01eee98c,auStack_14);
  }
  if (param_2 != 0) {
    piVar8 = param_1 + 0x3e;
    cVar1 = FUN_00d173f0(piVar8);
    if (cVar1 != '\0') {
      FUN_00d178f0(piVar8);
      cVar1 = FUN_00d173f0(piVar8);
      if (cVar1 != '\0') {
        FUN_00b4f410(param_1);
        uStack_24 = 0;
        uStack_20 = 0xf;
        auStack_34[0] = 0;
        pcVar7 = *(code **)(*param_1 + 0x158);
        FUN_005542c0(&DAT_018bc9b8,0);
        uStack_8 = 0;
        uVar2 = FUN_00a33be0(auStack_34);
        uStack_8 = CONCAT31(uStack_8._1_3_,1);
        goto LAB_00b4e35e;
      }
    }
  }
  piVar8 = param_1 + 0x3e;
  cVar1 = FUN_00ccdd10(piVar8);
  if (cVar1 != '\0') {
    FUN_00b4f410(param_1);
    pcVar7 = *(code **)(*param_1 + 0x158);
    uVar2 = FUN_00ccaa10(auStack_34);
    uStack_8 = 2;
    uVar2 = FUN_00a33be0(uVar2);
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
LAB_00b4e35e:
    (*pcVar7)(uVar2);
    FUN_0056cd30();
    FUN_005507b0();
    ExceptionList = pvStack_10;
    return;
  }
  cVar1 = FUN_00ccdc50(piVar8,auStack_50);
  if (cVar1 == '\0') {
    FUN_00b4f410(param_1);
    FUN_00b4e5d0();
    ExceptionList = pvStack_10;
    return;
  }
  appuStack_100[0] = &PTR_018bf148;
  puStack_f0 = &DAT_018bf150;
  ppuStack_98 = std::basic_ios<char,struct_std::char_traits<char>_>::vftable;
  uStack_8 = 4;
  uStack_18 = 1;
  FUN_00564f30(appuStack_e8,0);
  uStack_8 = 5;
  *(undefined ***)((int)appuStack_100 + (int)appuStack_100[0][1]) =
       std::basic_stringstream<char,struct_std::char_traits<char>,class_std::allocator<char>_>::
       vftable;
  *(undefined **)((int)appuStack_100 + (int)(appuStack_100[0][1] + -4)) =
       appuStack_100[0][1] + -0x68;
  FUN_0054ee60();
  appuStack_e8[0] =
       std::basic_stringbuf<char,struct_std::char_traits<char>,class_std::allocator<char>_>::vftable
  ;
  uStack_b0 = 0;
  uStack_ac = 0;
  uStack_8 = 6;
  FUN_005af750(PTR_s_CSGPHS_01d67044,6,0);
  FUN_005af750(&DAT_019786c0,4,0);
  puVar3 = (undefined4 *)FUN_00cc77d0(auStack_168,piVar8,param_1 + 0x45);
  uStack_134 = *puVar3;
  uStack_130 = puVar3[1];
  uStack_12c = puVar3[2];
  uStack_128 = puVar3[3];
  uStack_124 = puVar3[4];
  uStack_120 = puVar3[5];
  uStack_11c = puVar3[6];
  uStack_118 = puVar3[7];
  uStack_114 = puVar3[8];
  uStack_110 = puVar3[9];
  uStack_10c = puVar3[10];
  uStack_108 = puVar3[0xb];
  iStack_104 = puVar3[0xc];
  FUN_00ccd020(appuStack_100,&uStack_134);
  if (0xf < (uint)param_1[0x43]) {
    piVar8 = (int *)*piVar8;
  }
  FUN_005af750((int)piVar8 + 10,param_1[0x42] + -10,0);
  FUN_00b4f410(param_1);
  pcVar7 = *(code **)(*param_1 + 0x158);
  uStack_8 = CONCAT31(uStack_8._1_3_,7);
  uStack_3c = 0;
  uStack_38 = 0xf;
  auStack_4c[0] = 0;
  uStack_18 = 5;
  if (((uStack_ac & 2) == 0) && (uVar5 = *puStack_c8, uVar5 != 0)) {
    if (uVar5 < uStack_b0) {
      uVar5 = uStack_b0;
    }
    iVar4 = *piStack_d8;
    iVar6 = uVar5 - iVar4;
  }
  else {
    if (((uStack_ac & 4) != 0) || (*piStack_cc == 0)) goto LAB_00b4e57d;
    iVar4 = *piStack_dc;
    iVar6 = (*piStack_cc - iVar4) + *piStack_bc;
  }
  FUN_005542c0(iVar4,iVar6);
LAB_00b4e57d:
  uStack_8 = 8;
  uVar2 = FUN_00a33be0(auStack_4c);
  uStack_8 = CONCAT31(uStack_8._1_3_,9);
  (*pcVar7)(uVar2);
  FUN_0056cd30();
  FUN_005507b0();
  FUN_005705c0();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24205 ; VA 0x00b4e5d0 ; FUN_00b4e5d0 */

void __fastcall FUN_00b4e5d0(undefined4 param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_1c [12];
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3978;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  iVar4 = FUN_008f7870(param_1);
  if (iVar4 != 0) {
    cVar3 = FUN_008ff0a0();
    if (cVar3 == '\0') {
      FUN_00c18400(3);
    }
    else if (*(int *)(iVar4 + 0x2b0) != 0) {
      puVar5 = (undefined4 *)FUN_0060dcd0(auStack_1c,param_1,iVar4);
      uStack_8 = 0;
      uVar1 = *puVar5;
      uVar2 = puVar5[1];
      *puVar5 = 0;
      puVar5[1] = 0;
      FUN_0089bf10(uVar1,uVar2,iVar4);
      FUN_00550b30();
      ExceptionList = pvStack_10;
      return;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24206 ; VA 0x00b4e6a0 ; FUN_00b4e6a0 */

void __thiscall FUN_00b4e6a0(int param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  
  puVar1 = *(undefined8 **)(param_1 + 4);
  if (*(undefined8 **)(param_1 + 8) != puVar1) {
    *puVar1 = *param_2;
    *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_2 + 1);
    *(int *)(param_1 + 4) = *(int *)(param_1 + 4) + 0xc;
    return;
  }
  FUN_006c6920(puVar1,param_2);
  return;
}



/* FUNCTION 24207 ; VA 0x00b4e6e0 ; FUN_00b4e6e0 */

void __thiscall FUN_00b4e6e0(int *param_1,int *param_2,undefined4 param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  uint uVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  float10 fVar9;
  float fVar10;
  int iStack_78;
  int iStack_70;
  int *piStack_6c;
  int *piStack_68;
  int iStack_64;
  int *piStack_60;
  int iStack_5c;
  int iStack_58;
  float fStack_54;
  float fStack_50;
  float fStack_4c;
  undefined4 uStack_48;
  int iStack_3c;
  int *piStack_38;
  int *piStack_34;
  uint uStack_30;
  float fStack_2c;
  int iStack_28;
  float fStack_24;
  int iStack_20;
  int iStack_1c;
  int *piStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f39ab;
  pvStack_10 = ExceptionList;
  uVar3 = param_1[4];
  uVar7 = param_1[9];
  ExceptionList = &pvStack_10;
  if (uVar3 <= uVar7) {
    uVar7 = -(uint)(uVar3 != 0) & uVar3 - 1;
    ExceptionList = &pvStack_10;
    param_1[9] = uVar7;
  }
  iStack_20 = param_1[2];
  if ((param_1[1] - iStack_20) / 0x24 <= (int)uVar7) {
    uVar7 = uVar7 - (param_1[1] - *param_1) / 0x24;
  }
  iStack_14 = uVar7 * 9;
  iVar8 = 0;
  iVar6 = *(int *)(iStack_20 + 0x18 + uVar7 * 0x24);
  iStack_3c = *(int *)(iStack_20 + 0x1c + uVar7 * 0x24);
  piStack_18 = param_1;
  if (iVar6 != iStack_3c) {
    do {
      iStack_1c = iVar6;
      FUN_00650440(iVar6 + 0x10);
      uStack_8 = 0;
      FUN_00650440(iVar6 + 0x1c);
      uStack_8 = CONCAT31(uStack_8._1_3_,1);
      FUN_00650440(iVar6 + 0x28);
      uStack_8 = 2;
      FUN_01679a70(iVar8,0);
      iVar8 = iVar8 + 1;
      uStack_30 = (int)piStack_68 - (int)piStack_6c;
      piStack_38 = piStack_6c;
      iStack_28 = iVar8;
      if (uStack_30 < 4) {
        uStack_8 = 0xffffffff;
        if (piStack_60 != (int *)0x0) {
          uVar3 = iStack_58 - (int)piStack_60 & 0xfffffffc;
          piVar4 = piStack_60;
          if (0xfff < uVar3) {
            piVar4 = (int *)piStack_60[-1];
            uVar3 = uVar3 + 0x23;
            if (0x1f < (uint)((int)piStack_60 + (-4 - (int)piVar4))) goto LAB_00b4eab2;
          }
          FUN_01674ea0(piVar4,uVar3);
        }
        if (piStack_6c != (int *)0x0) {
          uVar3 = iStack_64 - (int)piStack_6c & 0xfffffffc;
          piVar4 = piStack_6c;
          if (0xfff < uVar3) {
            piVar4 = (int *)piStack_6c[-1];
            uVar3 = uVar3 + 0x23;
            if (0x1f < (uint)((int)piStack_6c + (-4 - (int)piVar4))) goto LAB_00b4eab2;
          }
          FUN_01674ea0(piVar4,uVar3);
        }
        if (iStack_78 != 0) {
          uVar3 = iStack_70 - iStack_78 & 0xfffffffc;
          iVar6 = iStack_78;
          if (0xfff < uVar3) {
            iVar6 = *(int *)(iStack_78 + -4);
            uVar3 = uVar3 + 0x23;
            if (0x1f < (iStack_78 - iVar6) - 4U) {
LAB_00b4eab2:
                    /* WARNING: Subroutine does not return */
              FUN_017167a3();
            }
          }
          FUN_01674ea0(iVar6,uVar3);
        }
      }
      else {
        fVar9 = (float10)FUN_01679fb0();
        fStack_2c = (float)fVar9;
        fVar9 = (float10)FUN_01679fb0();
        fStack_24 = (float)fVar9;
        fVar9 = (float10)FUN_01679fb0();
        piVar4 = piStack_18;
        fStack_50 = fStack_24;
        fStack_4c = fStack_2c;
        uStack_48 = param_3;
        fStack_2c = (float)((uint)(iStack_5c - (int)piStack_60 >> 2) / 3);
        fStack_54 = (float)fVar9;
        piStack_34 = piStack_60;
        piStack_18[0xd] = piStack_18[0xc];
        if (fStack_2c == 0.0) {
          uVar3 = 0;
          uStack_30 = uStack_30 + 3 >> 2;
          if (piStack_68 < piStack_6c) {
            uStack_30 = 0;
          }
          iVar6 = iStack_14;
          piVar5 = piStack_6c;
          if (uStack_30 != 0) {
            do {
              puVar1 = (undefined8 *)(*(int *)(iStack_20 + 0xc + iVar6 * 4) + *piVar5 * 0xc);
              puVar2 = (undefined8 *)piVar4[0xd];
              if ((undefined8 *)piVar4[0xe] == puVar2) {
                FUN_006c6920(puVar2,puVar1);
                iVar6 = iStack_14;
              }
              else {
                *puVar2 = *puVar1;
                *(undefined4 *)(puVar2 + 1) = *(undefined4 *)(puVar1 + 1);
                piVar4[0xd] = piVar4[0xd] + 0xc;
              }
              uVar3 = uVar3 + 1;
              piVar5 = piVar5 + 1;
            } while (uVar3 != uStack_30);
          }
          iVar6 = *param_2;
          fVar10 = (float)1;
        }
        else {
          piVar5 = piStack_60;
          fVar10 = (float)(uint)fStack_2c;
          if (fStack_2c != 0.0) {
            do {
              fStack_24 = fVar10;
              iVar8 = 3;
              iVar6 = iStack_14;
              do {
                puVar1 = (undefined8 *)(*(int *)(iStack_20 + 0xc + iVar6 * 4) + *piVar5 * 0xc);
                puVar2 = (undefined8 *)piVar4[0xd];
                if ((undefined8 *)piVar4[0xe] == puVar2) {
                  FUN_006c6920(puVar2,puVar1);
                  iVar6 = iStack_14;
                }
                else {
                  *puVar2 = *puVar1;
                  *(undefined4 *)(puVar2 + 1) = *(undefined4 *)(puVar1 + 1);
                  piVar4[0xd] = piVar4[0xd] + 0xc;
                }
                piVar5 = piVar5 + 1;
                iVar8 = iVar8 + -1;
              } while (iVar8 != 0);
              fVar10 = (float)((int)fStack_24 - 1U);
            } while ((int)fStack_24 - 1U != 0);
            fStack_24 = 0.0;
          }
          iVar6 = *param_2;
          fVar10 = fStack_2c;
        }
        (**(code **)(iVar6 + 0x90))(piVar4[0xc],fVar10,&fStack_54);
        uStack_8 = 0xffffffff;
        if (piStack_34 != (int *)0x0) {
          uVar3 = iStack_58 - (int)piStack_34 & 0xfffffffc;
          piVar4 = piStack_34;
          if (0xfff < uVar3) {
            piVar4 = (int *)piStack_34[-1];
            uVar3 = uVar3 + 0x23;
            if (0x1f < (uint)((int)piStack_34 + (-4 - (int)piVar4))) goto LAB_00b4eab2;
          }
          FUN_01674ea0(piVar4,uVar3);
        }
        if (piStack_38 != (int *)0x0) {
          uVar3 = iStack_64 - (int)piStack_38 & 0xfffffffc;
          piVar4 = piStack_38;
          if (0xfff < uVar3) {
            piVar4 = (int *)piStack_38[-1];
            uVar3 = uVar3 + 0x23;
            if (0x1f < (uint)((int)piStack_38 + (-4 - (int)piVar4))) goto LAB_00b4eab2;
          }
          FUN_01674ea0(piVar4,uVar3);
        }
        iVar8 = iStack_28;
        if (iStack_78 != 0) {
          uVar3 = iStack_70 - iStack_78 & 0xfffffffc;
          iVar6 = iStack_78;
          if (0xfff < uVar3) {
            iVar6 = *(int *)(iStack_78 + -4);
            uVar3 = uVar3 + 0x23;
            if (0x1f < (iStack_78 - iVar6) - 4U) goto LAB_00b4eab2;
          }
          FUN_01674ea0(iVar6,uVar3);
          iVar8 = iStack_28;
        }
      }
      iVar6 = iStack_1c + 0x34;
    } while (iVar6 != iStack_3c);
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24208 ; VA 0x00b4eac0 ; FUN_00b4eac0 */

void __thiscall FUN_00b4eac0(int param_1,int *param_2)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  
  if ((*(char *)(param_1 + 0x20) != '\0') && (*(int *)(param_1 + 0x10) != 0)) {
    pcVar1 = *(code **)(*param_2 + 0x54);
    uVar3 = FUN_0060efa0();
    (*pcVar1)(uVar3);
    iVar2 = *(int *)(param_1 + 0x2c);
    if (iVar2 != 0) {
      if (iVar2 != 1) {
        if (iVar2 != 2) {
          return;
        }
        FUN_00b4e6e0(param_2,0x3f800000);
      }
      FUN_00b4eb40(param_2);
      return;
    }
    FUN_00b4e6e0(param_2,0x3f800000);
  }
  return;
}



/* FUNCTION 24209 ; VA 0x00b4eb40 ; FUN_00b4eb40 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __thiscall FUN_00b4eb40(int *param_1,int *param_2)

{
  undefined8 *puVar1;
  int *piVar2;
  int iVar3;
  undefined **ppuVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined **ppuVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  float *pfVar11;
  undefined4 *puVar12;
  float *pfVar13;
  int *piVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  undefined4 uVar19;
  int iStack_110;
  undefined4 uStack_10c;
  undefined4 uStack_108;
  char acStack_104 [4];
  int iStack_100;
  uint uStack_fc;
  int iStack_f8;
  int iStack_f4;
  int iStack_f0;
  undefined4 uStack_ec;
  undefined8 uStack_e8;
  float fStack_e0;
  undefined4 uStack_dc;
  undefined8 uStack_d8;
  float fStack_d0;
  undefined4 uStack_cc;
  undefined uStack_c8;
  float *pfStack_c4;
  int iStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  int iStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  char acStack_a4 [4];
  undefined8 uStack_a0;
  float fStack_98;
  float fStack_94;
  undefined8 uStack_90;
  float fStack_88;
  float fStack_84;
  int iStack_80;
  float fStack_7c;
  undefined auStack_78 [4];
  int *piStack_74;
  float fStack_70;
  float fStack_6c;
  float fStack_68;
  float fStack_64;
  float **ppfStack_60;
  undefined4 *puStack_5c;
  undefined2 uStack_58;
  float fStack_54;
  undefined8 uStack_50;
  char acStack_48 [4];
  int iStack_44;
  uint uStack_40;
  float fStack_3c;
  float fStack_38;
  float fStack_34;
  undefined4 uStack_30;
  float *pfStack_2c;
  int iStack_28;
  int iStack_24;
  uint uStack_20;
  int *piStack_1c;
  int *piStack_18;
  float *pfStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  int iStack_8;
  
  iStack_8 = 0xffffffff;
  puStack_c = &LAB_017f39de;
  pvStack_10 = ExceptionList;
  uVar9 = param_1[4];
  uVar10 = param_1[9];
  ExceptionList = &pvStack_10;
  if (uVar9 <= uVar10) {
    uVar10 = -(uint)(uVar9 != 0) & uVar9 - 1;
    ExceptionList = &pvStack_10;
    param_1[9] = uVar10;
  }
  iStack_24 = param_1[2];
  if ((param_1[1] - iStack_24) / 0x24 <= (int)uVar10) {
    uVar10 = uVar10 - (param_1[1] - *param_1) / 0x24;
  }
  iStack_28 = uVar10 * 9;
  iVar8 = 0;
  fStack_54 = DAT_018c45c4;
  for (iVar3 = *(int *)(iStack_24 + uVar10 * 0x24); iVar3 != *(int *)(iStack_24 + 4 + uVar10 * 0x24)
      ; iVar3 = iVar3 + 0x1c) {
    if ((iVar8 == 0) || (*(float *)(iVar3 + 0xc) <= fStack_54)) {
      fStack_54 = *(float *)(iVar3 + 0xc);
      iVar8 = iVar3;
    }
  }
  uStack_20 = *(int *)(iStack_24 + 0x18 + uVar10 * 0x24);
  iVar8 = *(int *)(iStack_24 + 0x1c + uVar10 * 0x24) - uStack_20;
  pfStack_14 = (float *)0x0;
  iVar3 = iVar8 >> 0x1f;
  piStack_1c = param_1;
  if (iVar8 / 0x34 + iVar3 != iVar3) {
    piStack_18 = (int *)0x0;
    do {
      if (3 < (uint)(*(int *)(uStack_20 + 0x20 + (int)piStack_18) -
                    *(int *)(uStack_20 + 0x1c + (int)piStack_18))) {
        if (*(char *)(uStack_20 + 0xc + (int)piStack_18) == '\0') {
          uStack_90 = *(undefined8 *)(uStack_20 + (int)piStack_18);
          fStack_88 = *(float *)(uStack_20 + 8 + (int)piStack_18);
          fStack_84 = 0.3;
          (**(code **)(*param_2 + 100))(&uStack_90,&DAT_01d67024);
        }
        else {
          fStack_94 = 0.3;
          uStack_a0 = *(undefined8 *)(uStack_20 + (int)piStack_18);
          fStack_98 = *(float *)(uStack_20 + 8 + (int)piStack_18);
          (**(code **)(*param_2 + 100))();
        }
      }
      piStack_18 = (int *)((int)piStack_18 + 0x34);
      pfStack_14 = (float *)((int)pfStack_14 + 1);
      uStack_20 = *(int *)(iStack_24 + 0x18 + iStack_28 * 4);
    } while (pfStack_14 <
             (float *)((int)(*(int *)(iStack_24 + 0x1c + iStack_28 * 4) - uStack_20) / 0x34));
  }
  uStack_20 = 0;
  uStack_c8 = 0;
  fStack_70 = (float)DAT_01d68dcc / DAT_018d0938;
  pfStack_14 = (float *)&DAT_0000000b;
  ppuVar4 = (undefined **)
            FUN_00563d40(&DAT_018be100,&boost::lock_error::vftable_meta_ptr,&pfStack_14);
  ppuVar7 = ppuVar4 + -1;
  if (ppuVar4 != &boost::lock_error::vftable_meta_ptr) {
    ppuVar7 = ppuVar4;
  }
  pfStack_c4 = (float *)*ppuVar7;
  iStack_c0 = 0;
  uStack_bc = 0x3f800000;
  uStack_b8 = 0;
  iStack_b4 = 0;
  iStack_8 = 0;
  piStack_74 = *(int **)(iStack_24 + 4 + iStack_28 * 4);
  piStack_18 = *(int **)(iStack_24 + iStack_28 * 4);
  piVar14 = piStack_1c;
  fVar18 = DAT_018ce2f8;
  pfStack_2c = pfStack_c4;
  if (piStack_18 != piStack_74) {
    do {
      if ((*(char *)((int)piVar14 + 0x21) == '\0') ||
         (uStack_20 ==
          (uint)piVar14[10] %
          (uint)((*(int *)(iStack_24 + 4 + iStack_28 * 4) - *(int *)(iStack_24 + iStack_28 * 4)) /
                0x1c))) {
        fVar15 = (float)piStack_18[3];
        fVar17 = fStack_70;
        if (fVar15 < fStack_70) {
          fVar17 = fVar15;
        }
        fVar17 = fVar17 / fStack_70;
        uStack_30 = 0x3f800000;
        pfStack_14 = (float *)0x1;
        fStack_34 = (fVar18 - fVar17) * 0.0;
        fStack_38 = fVar17 * 0.0 + (fVar18 - fVar17);
        fStack_3c = fVar17 + fStack_34;
        fStack_34 = fVar17 * 0.0 + fStack_34;
        if (((NAN(fVar15) || NAN(fStack_54)) != (fVar15 == fStack_54)) && (fVar15 < fStack_70)) {
          fStack_3c = 0.0;
          fStack_38 = 0.0;
          fStack_34 = 1.0;
          pfStack_14 = (float *)0x2;
        }
        iVar3 = *(int *)(iStack_24 + 0x18 + iStack_28 * 4);
        pfVar13 = (float *)(*piStack_18 * 0x34 + iVar3);
        pfVar11 = (float *)(piStack_18[1] * 0x34 + iVar3);
        (**(code **)(*param_2 + 0x4c))(pfVar13,pfVar11,&fStack_3c,(float)((int)pfStack_14 << 3),0,0)
        ;
        fStack_64 = (pfVar11[2] + pfVar13[2]) * DAT_018ce2f4;
        fStack_6c = (*pfVar11 + *pfVar13) * DAT_018ce2f4;
        fStack_68 = (pfVar11[1] + pfVar13[1]) * DAT_018ce2f4;
        iStack_f0 = (int)((double)fStack_64 / DAT_018db070);
        iStack_f4 = (int)((double)fStack_68 / DAT_018db070);
        iStack_f8 = (int)((double)fStack_6c / DAT_018db070);
        (**(code **)*param_2)();
        FUN_00d23e50(&uStack_ac,&fStack_6c);
        (**(code **)*param_2)();
        iVar3 = FUN_00712f10();
        piVar2 = piStack_18;
        fVar17 = *(float *)(iVar3 + 0x24) - fStack_6c;
        fVar15 = *(float *)(iVar3 + 0x28) - fStack_68;
        fVar16 = *(float *)(iVar3 + 0x2c) - fStack_64;
        if ((*(char *)((int)piStack_1c + 0x21) != '\0') ||
           (piVar14 = piStack_1c, fVar18 = DAT_018ce2f8,
           fVar15 * fVar15 + fVar17 * fVar17 + fVar16 * fVar16 < DAT_01919f9c)) {
          uStack_50 = CONCAT44(uStack_a8,uStack_ac);
          acStack_48[0] = acStack_a4[0];
          acStack_48[1] = acStack_a4[1];
          acStack_48[2] = acStack_a4[2];
          acStack_48[3] = acStack_a4[3];
          uStack_40 = piStack_18[3];
          iStack_44 = piStack_18[2];
          iStack_110 = FUN_00a6ce70();
          uStack_fc = uStack_40;
          ppfStack_60 = &pfStack_c4;
          uStack_10c = (undefined4)uStack_50;
          uStack_108 = uStack_50._4_4_;
          acStack_104[0] = acStack_48[0];
          acStack_104[1] = acStack_48[1];
          acStack_104[2] = acStack_48[2];
          acStack_104[3] = acStack_48[3];
          iStack_100 = iStack_44;
          puStack_5c = (undefined4 *)0x0;
          iStack_8._0_1_ = 1;
          uStack_58 = 0;
          puStack_5c = (undefined4 *)FUN_01674e20(0x24);
          uStack_58 = 0x101;
          *puStack_5c = 0;
          puStack_5c[2] = 0;
          puStack_5c[1] = puStack_5c;
          puStack_5c[3] = iStack_110;
          puStack_5c[4] = uStack_10c;
          puStack_5c[5] = uStack_108;
          puStack_5c[6] = acStack_104;
          puStack_5c[7] = iStack_100;
          puStack_5c[8] = uStack_fc;
          FUN_00b4da70(&fStack_7c,&ppfStack_60);
          iStack_8 = (uint)iStack_8._1_3_ << 8;
          if (puStack_5c != (undefined4 *)0x0) {
            FUN_01674ea0();
          }
          pfStack_2c = (float *)piVar2[5];
          pfStack_14 = (float *)piVar2[4];
          iVar3 = (int)pfStack_2c - (int)pfStack_14 >> 0x1f;
          piVar14 = piStack_1c;
          fVar18 = DAT_018ce2f8;
          if ((((int)pfStack_2c - (int)pfStack_14) / 0x1c + iVar3 != iVar3) &&
             (pfStack_14 != pfStack_2c)) {
            pfVar11 = pfStack_14 + 3;
            do {
              pfVar13 = pfVar11 + 1;
              if ((NAN(*pfStack_14) || NAN(DAT_018ce2f0)) == (*pfStack_14 == DAT_018ce2f0)) {
                uStack_50 = CONCAT44(_DAT_01919fa0,(undefined4)uStack_50);
                acStack_48[0] = UNK_01919fa4;
                acStack_48[1] = UNK_01919fa5;
                acStack_48[2] = UNK_01919fa6;
                acStack_48[3] = UNK_01919fa7;
                iStack_44 = _UNK_01919fa8;
                uStack_40 = _UNK_01919fac;
                uStack_dc = 0x3dcccccd;
                uStack_e8 = *(undefined8 *)pfVar13;
                fStack_e0 = pfVar11[3];
                (**(code **)(*param_2 + 100))();
                fVar18 = *pfStack_14;
                iVar3 = *param_2;
                fStack_88 = pfVar11[2] + pfVar11[-1] * fVar18;
                uVar19 = 0x40800000;
                fStack_84 = pfVar11[3] + *pfVar11 * fVar18;
                uStack_90 = CONCAT44(*pfVar13 + pfVar11[-2] * fVar18,(undefined4)uStack_90);
                puVar1 = &uStack_90;
              }
              else {
                uStack_50 = CONCAT44(s_333_333_333__01953480._0_4_,(undefined4)uStack_50);
                acStack_48[0] = s_333_333_333__01953480[4];
                acStack_48[1] = s_333_333_333__01953480[5];
                acStack_48[2] = s_333_333_333__01953480[6];
                acStack_48[3] = s_333_333_333__01953480[7];
                iStack_44._0_1_ = s_333_333_333__01953480[8];
                iStack_44._1_1_ = s_333_333_333__01953480[9];
                iStack_44._2_1_ = s_333_333_333__01953480[10];
                iStack_44._3_1_ = s_333_333_333__01953480[0xb];
                uStack_40 = ram0x0195348c;
                uStack_cc = 0x3d4ccccd;
                uStack_d8 = *(undefined8 *)pfVar13;
                fStack_d0 = pfVar11[3];
                (**(code **)(*param_2 + 100))();
                iVar3 = *param_2;
                uVar19 = 0x40000000;
                puVar1 = &uStack_a0;
                fStack_98 = pfVar11[2] + pfVar11[-1] * DAT_018fde58 * DAT_018df580;
                fStack_94 = pfVar11[3] + *pfVar11 * DAT_018fde58 * DAT_018df580;
                uStack_a0 = CONCAT44(*pfVar13 + pfVar11[-2] * DAT_018fde58 * DAT_018df580,
                                     (undefined4)uStack_a0);
              }
              (**(code **)(iVar3 + 0x4c))(pfVar13,(int)puVar1 + 4,(int)&uStack_50 + 4,uVar19,0,0);
              pfVar11 = pfVar11 + 7;
              pfStack_14 = pfStack_14 + 7;
              piVar14 = piStack_1c;
              fVar18 = DAT_018ce2f8;
            } while (pfStack_14 != pfStack_2c);
          }
        }
      }
      uStack_20 = uStack_20 + 1;
      piStack_18 = piStack_18 + 7;
    } while (piStack_18 != piStack_74);
  }
  iVar3 = -1;
  iVar8 = 0;
  if (iStack_c0 == 0) {
    puVar12 = (undefined4 *)0x0;
  }
  else {
    puVar12 = *(undefined4 **)(iStack_b4 + (int)pfStack_c4 * 4);
  }
  do {
    if (puVar12 == (undefined4 *)0x0) {
      FUN_00b4d700();
      ExceptionList = pvStack_10;
      return;
    }
    iVar5 = iVar8 + 0x10;
    uStack_dc = 0;
    uStack_e8 = CONCAT44(_UNK_018e3fc8,_UNK_018e3fc4);
    iVar8 = 0;
    if (puVar12[3] == iVar3) {
      iVar8 = iVar5;
    }
    iStack_44 = 0;
    uStack_d8 = CONCAT44(_UNK_018e3fd4,_DAT_018e3fd0);
    uStack_40 = 0;
    uStack_ec = _DAT_018e3fc0;
    fStack_e0 = _UNK_018e3fcc;
    fStack_d0 = _UNK_018e3fd8;
    uStack_cc = _UNK_018e3fdc;
    pfVar11 = (float *)FUN_0115e910();
    fStack_3c = *pfVar11;
    fStack_38 = pfVar11[1];
    fStack_34 = pfVar11[2];
    uStack_30 = 0x3f800000;
    puVar6 = (undefined4 *)FUN_0115ee70();
    uStack_b0 = *puVar6;
    fStack_7c = (float)iVar8 + (float)puVar12[5];
    uStack_ac = puVar6[1];
    uStack_a8 = puVar6[2];
    iStack_80 = puVar12[4];
    acStack_a4[0] = '\0';
    acStack_a4[1] = '\0';
    acStack_a4[2] = -0x80;
    acStack_a4[3] = '?';
    uVar19 = FUN_01675640(&iStack_110,"ID: %d, e: %4.4f",puVar12[7],(double)(float)puVar12[8]);
    iStack_8._0_1_ = 2;
    FUN_0114e430(auStack_78,uVar19,&iStack_80,0x41000000,0,&uStack_b0,&fStack_3c,0,1,0,&iStack_44,
                 &uStack_d8,&uStack_ec,1);
    iStack_8 = (uint)iStack_8._1_3_ << 8;
    if (0xf < uStack_fc) {
      uVar9 = uStack_fc + 1;
      iVar3 = iStack_110;
      if (0xfff < uVar9) {
        iVar3 = *(int *)(iStack_110 + -4);
        uVar9 = uStack_fc + 0x24;
        if (0x1f < (iStack_110 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(iVar3,uVar9);
    }
    iVar3 = puVar12[3];
    puVar12 = (undefined4 *)*puVar12;
  } while( true );
}



/* FUNCTION 24210 ; VA 0x00b4f410 ; FUN_00b4f410 */

void FUN_00b4f410(int *param_1)

{
  int iVar1;
  code *pcVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  uint uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  uint uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3a00;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_1 == (int *)0x0) {
LAB_00b4f503:
    param_1 = (int *)0x0;
  }
  else {
    iVar1 = param_1[3];
    ExceptionList = &pvStack_10;
    iVar3 = FUN_00b50240();
    if ((uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8) <=
        (uint)*(ushort *)(iVar3 + 0x1da)) {
      uStack_18 = 0;
      pcVar2 = *(code **)(*param_1 + 0x154);
      uStack_14 = 0xf;
      uStack_28 = uStack_28 & 0xffffff00;
      FUN_005542c0(&DAT_018bc9b8,0);
      uStack_40 = uStack_28;
      uStack_3c = uStack_24;
      uStack_38 = uStack_20;
      uStack_34 = uStack_1c;
      uStack_30 = CONCAT44(uStack_14,uStack_18);
      uStack_8 = 0;
      (*pcVar2)(&uStack_40);
      if (uStack_30._4_4_ < 0x10) {
        ExceptionList = pvStack_10;
        return;
      }
      uVar5 = uStack_30._4_4_ + 1;
      uVar4 = uStack_40;
      if (0xfff < uVar5) {
        uVar4 = *(uint *)(uStack_40 - 4);
        uVar5 = uStack_30._4_4_ + 0x24;
        if (0x1f < (uStack_40 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      goto LAB_00b4f575;
    }
    iVar1 = param_1[3];
    iVar3 = FUN_00cfb1a0();
    if ((uint)*(ushort *)(iVar3 + 0x1da) <
        (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar3 + 0x1d8)) goto LAB_00b4f503;
  }
  uStack_18 = 0;
  pcVar2 = *(code **)(*param_1 + 0x154);
  uStack_14 = 0xf;
  uStack_28 = uStack_28 & 0xffffff00;
  FUN_005542c0(&DAT_018bc9b8,0);
  uStack_58 = uStack_28;
  uStack_54 = uStack_24;
  uStack_50 = uStack_20;
  uStack_4c = uStack_1c;
  uStack_48 = CONCAT44(uStack_14,uStack_18);
  uStack_8 = 1;
  (*pcVar2)(&uStack_58);
  if (uStack_48._4_4_ < 0x10) {
    ExceptionList = pvStack_10;
    return;
  }
  uVar5 = uStack_48._4_4_ + 1;
  uVar4 = uStack_58;
  if (0xfff < uVar5) {
    uVar4 = *(uint *)(uStack_58 - 4);
    uVar5 = uStack_48._4_4_ + 0x24;
    if (0x1f < (uStack_58 - uVar4) - 4) {
                    /* WARNING: Subroutine does not return */
      FUN_017167a3();
    }
  }
LAB_00b4f575:
  FUN_01674ea0(uVar4,uVar5);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24211 ; VA 0x00b4f5a0 ; FUN_00b4f5a0 */

void __thiscall FUN_00b4f5a0(undefined4 param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined auStack_1c [4];
  int *piStack_18;
  undefined4 uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3978;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uStack_14 = param_1;
  iVar4 = FUN_00b4def0();
  if (iVar4 != param_2) {
    iVar4 = FUN_008f7870(param_1);
    if (iVar4 != 0) {
      puVar5 = (undefined4 *)FUN_0060dcd0(auStack_1c,param_1,param_2);
      uStack_8 = 0;
      uVar2 = *puVar5;
      uVar3 = puVar5[1];
      *puVar5 = 0;
      puVar5[1] = 0;
      FUN_0089bf10(uVar2,uVar3,param_2);
      uStack_8 = 0xffffffff;
      if (piStack_18 != (int *)0x0) {
        LOCK();
        iVar4 = piStack_18[1] + -1;
        piStack_18[1] = iVar4;
        UNLOCK();
        if (iVar4 == 0) {
          (**(code **)*piStack_18)();
          LOCK();
          piVar1 = piStack_18 + 2;
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*piStack_18 + 4))();
          }
        }
      }
      FUN_008a4940(&DAT_01eee910);
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24212 ; VA 0x00b4f680 ; FUN_00b4f680 */

void __thiscall FUN_00b4f680(int param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  int iStack_d4;
  byte abStack_c8 [164];
  undefined auStack_24 [12];
  int iStack_18;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  piVar5 = param_2;
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3a26;
  pvStack_10 = ExceptionList;
  if (DAT_01d6c7ac == '\0') {
    return;
  }
  piVar3 = (int *)(param_1 + 0x120);
  piVar2 = param_2;
  if (0xf < (uint)param_2[5]) {
    piVar2 = (int *)*param_2;
  }
  piVar4 = piVar3;
  if (0xf < *(uint *)(param_1 + 0x134)) {
    piVar4 = (int *)*piVar3;
  }
  ExceptionList = &pvStack_10;
  cVar1 = FUN_0055c360(piVar4,*(undefined4 *)(param_1 + 0x130),piVar2,param_2[4]);
  if (cVar1 != '\0') {
    ExceptionList = pvStack_10;
    return;
  }
  *(undefined4 *)(param_1 + 0x138) = 0;
  if (DAT_01d67050 != '\0') {
    param_2 = (int *)piVar5[4];
    piVar2 = piVar5;
    if (0xf < (uint)piVar5[5]) {
      piVar2 = (int *)*piVar5;
    }
    cVar1 = FUN_0055c360(piVar2,param_2,&DAT_018bc9b8,0);
    if (cVar1 != '\0') {
      if (piVar3 != piVar5) {
        if (0xf < (uint)piVar5[5]) {
          piVar5 = (int *)*piVar5;
        }
        FUN_005542c0(piVar5,param_2);
      }
      goto LAB_00b4f8cc;
    }
  }
  if (DAT_01d67048 == '\0') {
    if (piVar3 != piVar5) {
      piVar3 = piVar5;
      if (0xf < (uint)piVar5[5]) {
        piVar3 = (int *)*piVar5;
      }
      FUN_005542c0(piVar3,piVar5[4]);
    }
    iStack_14 = 0;
    FUN_00729510(piVar5,3,1);
    uStack_8 = 1;
    FUN_005af630(&iStack_14,4,0);
    iVar6 = 0;
    if (0 < iStack_14) {
      do {
        iStack_18 = 0;
        FUN_005af630(&iStack_18,4,0);
        iVar6 = iVar6 + 1;
        *(int *)(param_1 + 0x13c + *(int *)(param_1 + 0x138) * 4) = iStack_18;
        *(int *)(param_1 + 0x138) = *(int *)(param_1 + 0x138) + 1;
      } while (iVar6 < iStack_14);
    }
  }
  else {
    param_2 = (int *)0x0;
    FUN_00729510(piVar5,3,1);
    uStack_8 = 0;
    FUN_005af630(&param_2,4,0);
    if (((abStack_c8[*(int *)(iStack_d4 + 4)] & 6) != 0) || (3 < (int)param_2 - 1U)) {
      FUN_016756b0(auStack_24,"Error while decoding triangle mesh LOD data: malformed LOD count");
                    /* WARNING: Subroutine does not return */
      FUN_0170c2a8(auStack_24,&DAT_01c17198);
    }
    iStack_18 = 0;
    if (0 < (int)param_2) {
      piVar3 = (int *)(param_1 + 0x13c);
      do {
        iStack_14 = 0;
        FUN_005af630(&iStack_14,4,0);
        if ((abStack_c8[*(int *)(iStack_d4 + 4)] & 6) != 0) {
          FUN_016756b0(auStack_24,"Error while decoding triangle mesh LOD data: malformed LOD error"
                      );
                    /* WARNING: Subroutine does not return */
          FUN_0170c2a8(auStack_24,&DAT_01c17198);
        }
        iStack_18 = iStack_18 + 1;
        *piVar3 = iStack_14;
        piVar3 = piVar3 + 1;
      } while (iStack_18 < (int)param_2);
    }
    *(int **)(param_1 + 0x138) = param_2;
    if ((int *)(param_1 + 0x120) != piVar5) {
      piVar3 = piVar5 + 4;
      if (0xf < (uint)piVar5[5]) {
        piVar5 = (int *)*piVar5;
      }
      FUN_005542c0(piVar5,*piVar3);
    }
  }
  uStack_8 = 0xffffffff;
  FUN_005705c0();
LAB_00b4f8cc:
  FUN_008a4940(&DAT_01eee950);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24213 ; VA 0x00b4f930 ; FUN_00b4f930 */

void __thiscall FUN_00b4f930(int param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  
  cVar2 = FUN_005e0cd0(param_2);
  if (cVar2 != '\0') {
    iVar3 = *param_2;
    LOCK();
    piVar1 = (int *)(iVar3 + 0x28);
    *piVar1 = *piVar1 + 1;
    UNLOCK();
    *(int *)(param_1 + 0x110) = iVar3;
    FUN_0056cd30();
    if (DAT_01d6c804 == '\0') {
      FUN_00b4fa80();
      FUN_008a4940(&DAT_01eee8d8);
    }
    else {
      iVar3 = FUN_00b4def0();
      FUN_00b4fa80();
      FUN_008a4940(&DAT_01eee8d8);
      iVar4 = FUN_00b4def0();
      if (iVar3 != iVar4) {
        FUN_005e6780(&DAT_01eee910);
        return;
      }
    }
  }
  return;
}



/* FUNCTION 24214 ; VA 0x00b4f9d0 ; FUN_00b4f9d0 */

void __thiscall FUN_00b4f9d0(int param_1,undefined4 param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  int iStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017b9c38;
  pvStack_10 = ExceptionList;
  pcVar1 = *(code **)(**(int **)(param_1 + 0x34) + 0x10);
  ExceptionList = &pvStack_10;
  iStack_14 = param_1;
  uVar2 = FUN_00b4d480(&iStack_14);
  uStack_8 = 0;
  (*pcVar1)(param_2,uVar2);
  FUN_0056cd30();
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24215 ; VA 0x00b4fa30 ; FUN_00b4fa30 */

void __thiscall FUN_00b4fa30(int param_1,undefined4 param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  piVar2 = param_3;
  iVar1 = *param_3;
  iVar3 = thunk_FUN_00b0f580();
  if (iVar1 == iVar3) {
    param_3 = piVar2 + 2;
    if (piVar2[1] == 0) {
      param_3 = (int *)0x0;
    }
    param_3 = (int *)*param_3;
    (**(code **)(**(int **)(param_1 + 0x38) + 0x10))(param_2,&param_3);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_016757c0("Variant cast failed");
}



/* FUNCTION 24216 ; VA 0x00b4fa80 ; FUN_00b4fa80 */

void __fastcall FUN_00b4fa80(int *param_1)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  uint uVar7;
  uint uVar8;
  float10 fVar9;
  double dVar10;
  undefined auStack_74 [16];
  undefined4 uStack_64;
  undefined4 uStack_60;
  uint auStack_5c [4];
  undefined4 uStack_4c;
  uint uStack_48;
  undefined auStack_44 [12];
  undefined auStack_38 [12];
  double dStack_2c;
  double dStack_24;
  undefined8 uStack_1c;
  char cStack_11;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3a38;
  pvStack_10 = ExceptionList;
  uStack_1c = (double)(ulonglong)(uint)uStack_1c;
  ExceptionList = &pvStack_10;
  puVar2 = (undefined4 *)FUN_00a33fa0();
  puVar3 = puVar2;
  if (0xf < (uint)puVar2[5]) {
    puVar3 = (undefined4 *)*puVar2;
  }
  cVar1 = FUN_0055c360(puVar3,puVar2[4],&DAT_018bc9b8,0);
  if ((cVar1 == '\0') && (cVar1 = FUN_00ccdd10(puVar2), cVar1 == '\0')) {
    puVar4 = (undefined4 *)FUN_00ccba10(auStack_5c);
    uStack_1c = (double)CONCAT44(1,(uint)uStack_1c);
    puVar3 = puVar4 + 4;
    if (0xf < (uint)puVar4[5]) {
      puVar4 = (undefined4 *)*puVar4;
    }
    puVar6 = puVar2;
    if (0xf < (uint)puVar2[5]) {
      puVar6 = (undefined4 *)*puVar2;
    }
    cVar1 = FUN_0055c360(puVar6,puVar2[4],puVar4,*puVar3);
    cStack_11 = '\0';
    if (cVar1 == '\0') goto LAB_00b4fb21;
  }
  cStack_11 = '\x01';
LAB_00b4fb21:
  if (((ulonglong)uStack_1c & 0x100000000) != 0) {
    if (0xf < uStack_48) {
      uVar8 = uStack_48 + 1;
      uVar7 = auStack_5c[0];
      if (0xfff < uVar8) {
        uVar7 = *(uint *)(auStack_5c[0] - 4);
        uVar8 = uStack_48 + 0x24;
        if (0x1f < (auStack_5c[0] - uVar7) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar7,uVar8);
    }
    uStack_4c = 0;
    uStack_48 = 0xf;
    auStack_5c[0] = auStack_5c[0] & 0xffffff00;
  }
  if (cStack_11 == '\0') {
    iVar5 = FUN_00c15b40();
    if (iVar5 != 0xb) {
      FUN_00c17120(0xb);
    }
    dVar10 = (double)((float)param_1[0x45] * (float)param_1[0x45] +
                      (float)param_1[0x46] * (float)param_1[0x46] +
                     (float)param_1[0x47] * (float)param_1[0x47]);
    if (NAN(dVar10) == (dVar10 == 0.0)) {
      uStack_1c = (double)CONCAT44((uint)((ulonglong)dVar10 >> 0x20) & DAT_018c0da0._4_4_,
                                   SUB84(dVar10,0) & (uint)DAT_018c0da0) + DAT_018c0d60;
      dStack_2c = (double)CONCAT44((uint)((ulonglong)(dVar10 - 0.0) >> 0x20) & DAT_018c0da0._4_4_,
                                   SUB84(dVar10 - 0.0,0) & (uint)DAT_018c0da0);
      fVar9 = (float10)FUN_01160810();
      dStack_24 = (double)fVar9;
      dVar10 = DAT_018f76b0;
      if ((NAN(uStack_1c) || NAN(dStack_24)) == (uStack_1c == dStack_24)) {
        dVar10 = uStack_1c * DAT_018f76b0;
      }
      if ((dVar10 < dStack_2c) &&
         ((DAT_01d67058 == '\0' ||
          (((cVar1 = FUN_01160820(param_1[0x45]), cVar1 != '\0' &&
            (cVar1 = FUN_01160820(param_1[0x46]), cVar1 != '\0')) &&
           (cVar1 = FUN_01160820(param_1[0x47]), cVar1 != '\0')))))) {
        uStack_64 = 0;
        uStack_60 = 0xf;
        auStack_74[0] = 0;
        uStack_8 = 0;
        FUN_00a33e40(auStack_74);
        if (param_1 == (int *)0x0) {
          iVar5 = 0;
        }
        else {
          iVar5 = param_1[0x2a];
        }
        uStack_1c._4_4_ = *(int *)(iVar5 + 0x1ac);
        (**(code **)(*param_1 + 0x160))(auStack_44);
        (**(code **)(*param_1 + 0x15c))(auStack_38);
        iVar5 = uStack_1c._4_4_;
        cVar1 = FUN_00ccd1b0(auStack_74,puVar2,auStack_44,auStack_38);
        if (cVar1 == '\0') {
          if ((*(int *)(iVar5 + 0x14) < DAT_01d67068) && (*(int *)(iVar5 + 0x14) != -1)) {
            FUN_00b4e5d0();
          }
        }
        else {
          if (DAT_01d6c804 == '\0') {
            FUN_008a4940(&DAT_01eee910);
          }
          FUN_00c154f0();
          FUN_00c19d80();
        }
        FUN_005507b0();
      }
    }
  }
  else {
    iVar5 = FUN_00c15b40();
    if (iVar5 != 3) {
      if (param_1 != (int *)0x0) {
        FUN_00c17120(3);
        ExceptionList = pvStack_10;
        return;
      }
      FUN_00c17120(3);
      ExceptionList = pvStack_10;
      return;
    }
  }
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24217 ; VA 0x00b4fdd0 ; FUN_00b4fdd0 */

void __thiscall FUN_00b4fdd0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  
  iVar1 = FUN_00c15b40();
  if (iVar1 == 0xb) {
    FUN_00ccdb90(param_1 + 0x110,param_2,param_3);
    FUN_00c19d80();
  }
  return;
}



/* FUNCTION 24218 ; VA 0x00b4fe30 ; FUN_00b4fe30 */

int * __thiscall
FUN_00b4fe30(int *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017baf5b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b50240();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PartOperation,class_RBX::BinaryString>::
              GetSetImpl<class_RBX::BinaryString_const&_(__thiscall_RBX::PartOperation::*)(void)const_,void_(__thiscall_RBX::PartOperation::*)(class_RBX::BinaryString_const&)>
              ::vftable;
    *(undefined8 *)(puVar3 + 2) = param_4;
    puVar3[4] = param_5;
    *(undefined8 *)(puVar3 + 6) = param_6;
    puVar3[8] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088cf00();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_RBX::BinaryString>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::PartOperation,class_RBX::BinaryString>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::PartOperation,class_RBX::BinaryString>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24219 ; VA 0x00b4ff40 ; FUN_00b4ff40 */

int * __thiscall
FUN_00b4ff40(int *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
            undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined4 param_8,
            undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3a6b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  uVar2 = FUN_00b50240();
  puVar3 = (undefined4 *)FUN_01674e20(0x28);
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    *puVar3 = RBX::Reflection::PropDescriptor<class_RBX::PartOperation,class_RBX::SharedString>::
              GetSetImpl<class_RBX::SharedString_const&_(__thiscall_RBX::PartOperation::*)(void)const_,void_(__thiscall_RBX::PartOperation::*)(class_RBX::SharedString_const&)>
              ::vftable;
    *(undefined8 *)(puVar3 + 2) = param_4;
    puVar3[4] = param_5;
    *(undefined8 *)(puVar3 + 6) = param_6;
    puVar3[8] = param_7;
  }
  uStack_8 = 0;
  uVar4 = FUN_0088d4b0();
  FUN_009ca670(uVar2,uVar4,param_2,param_3,param_8,param_9,param_10,param_11,param_12,param_12,0);
  *param_1 = (int)RBX::Reflection::TypedPropertyDescriptor<class_RBX::SharedString>::vftable;
  param_1[0xd] = (int)puVar3;
  uStack_8 = CONCAT31(uStack_8._1_3_,2);
  if (puVar3 == (undefined4 *)0x0) {
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::PartOperation,class_RBX::SharedString>::vftable;
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0xc))();
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xffffffeb;
    }
    cVar1 = (**(code **)(*param_1 + 8))();
    *param_1 = (int)RBX::Reflection::
                    PropDescriptor<class_RBX::PartOperation,class_RBX::SharedString>::vftable;
    if (cVar1 != '\0') {
      param_1[9] = param_1[9] & 0xfffffff3;
      ExceptionList = pvStack_10;
      return param_1;
    }
  }
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24220 ; VA 0x00b50050 ; FUN_00b50050 */

undefined4 * __thiscall
FUN_00b50050(undefined4 *param_1,undefined4 param_2,undefined4 param_3,int *param_4)

{
  int *piVar1;
  int iVar2;
  char cVar3;
  undefined **ppuVar4;
  
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  *param_1 = 0;
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    param_4[1] = param_4[1] + 1;
    UNLOCK();
  }
  ppuVar4 = &PTR_FUN_019545c0;
  cVar3 = FUN_005918b0(param_2,param_3,param_4,param_1 + 2);
  if (cVar3 == '\0') {
    ppuVar4 = (undefined **)0x0;
  }
  *param_1 = ppuVar4;
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      iVar2 = param_4[2] + -1;
      param_4[2] = iVar2;
      UNLOCK();
      if (iVar2 == 0) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  if (param_4 != (int *)0x0) {
    LOCK();
    iVar2 = param_4[1] + -1;
    param_4[1] = iVar2;
    UNLOCK();
    if (iVar2 == 0) {
      (**(code **)*param_4)();
      LOCK();
      piVar1 = param_4 + 2;
      iVar2 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar2 == 1) {
        (**(code **)(*param_4 + 4))();
      }
    }
  }
  return param_1;
}



/* FUNCTION 24221 ; VA 0x00b50140 ; FUN_00b50140 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b50140(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3aa0;
  pvStack_10 = ExceptionList;
  if (DAT_01eef2c8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eef4e0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eef4e0);
      if (DAT_01eef4e0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00b50240();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"NegateOperation",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01eef4d8 = RBX::Creator<class_RBX::NegateOperation>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01eef2d0,&DAT_01eef4d8);
        FUN_016f3654(FUN_0188ded0);
        FUN_016f37bf(&DAT_01eef4e0);
      }
    }
    DAT_01eef2c8 = &DAT_01eef2d0;
  }
  ExceptionList = pvStack_10;
  return DAT_01eef2c8;
}



/* FUNCTION 24222 ; VA 0x00b50240 ; FUN_00b50240 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b50240(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3ad0;
  pvStack_10 = ExceptionList;
  if (DAT_01eeee88 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eef0a0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eef0a0);
      if (DAT_01eef0a0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00b4d210();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"PartOperation",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01eef098 = RBX::Creator<class_RBX::PartOperation>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01eeee90,&DAT_01eef098);
        FUN_016f3654(FUN_0188df30);
        FUN_016f37bf(&DAT_01eef0a0);
      }
    }
    DAT_01eeee88 = &DAT_01eeee90;
  }
  ExceptionList = pvStack_10;
  return DAT_01eeee88;
}



/* FUNCTION 24223 ; VA 0x00b50340 ; FUN_00b50340 */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined * FUN_00b50340(void)

{
  undefined4 uVar1;
  uint uStack_20;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3b00;
  pvStack_10 = ExceptionList;
  if (DAT_01eef0a8 == (undefined *)0x0) {
    if (*(int *)(*(int *)((int)ThreadLocalStoragePointer + _tls_index * 4) + 0x34) < DAT_01eef2c0) {
      ExceptionList = &pvStack_10;
      FUN_016f3809(&DAT_01eef2c0);
      if (DAT_01eef2c0 == -1) {
        uStack_8 = 0;
        uVar1 = FUN_00b50240();
        uStack_20 = uStack_20 & 0xffffff00;
        FUN_00891fc0(uVar1,"UnionOperation",0,uStack_20,0,0,0x1b,0,0);
        _DAT_01eef2b8 = RBX::Creator<class_RBX::UnionOperation>::vftable;
        uStack_8 = CONCAT31(uStack_8._1_3_,2);
        FUN_00893bd0(&DAT_01eef0b0,&DAT_01eef2b8);
        FUN_016f3654(FUN_0188df90);
        FUN_016f37bf(&DAT_01eef2c0);
      }
    }
    DAT_01eef0a8 = &DAT_01eef0b0;
  }
  ExceptionList = pvStack_10;
  return DAT_01eef0a8;
}



/* FUNCTION 24224 ; VA 0x00b50440 ; FUN_00b50440 */

int __thiscall FUN_00b50440(int *param_1,undefined8 *param_2,undefined8 *param_3)

{
  int iVar1;
  uint uVar2;
  undefined8 *puVar3;
  int iVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  uint uVar8;
  undefined8 *puVar9;
  
  iVar4 = *param_1;
  iVar1 = (param_1[1] - *param_1) / 0xc;
  if (iVar1 == 0x15555555) {
                    /* WARNING: Subroutine does not return */
    FUN_00577c30();
  }
  uVar2 = (param_1[2] - *param_1) / 0xc;
  uVar8 = iVar1 + 1;
  if (uVar2 <= 0x15555555 - (uVar2 >> 1)) {
    uVar8 = (uVar2 >> 1) + uVar2;
    if (uVar8 < iVar1 + 1U) {
      uVar8 = iVar1 + 1U;
    }
  }
  puVar3 = (undefined8 *)FUN_00618050(uVar8);
  iVar4 = (((int)param_2 - iVar4) / 0xc) * 0xc;
  puVar5 = (undefined8 *)(iVar4 + (int)puVar3);
  *puVar5 = *param_3;
  *(undefined4 *)(puVar5 + 1) = *(undefined4 *)(param_3 + 1);
  puVar9 = (undefined8 *)param_1[1];
  puVar6 = (undefined8 *)*param_1;
  puVar7 = puVar3;
  if (param_2 == puVar9) {
    for (; puVar6 != puVar9; puVar6 = (undefined8 *)((int)puVar6 + 0xc)) {
      *puVar7 = *puVar6;
      *(undefined4 *)(puVar7 + 1) = *(undefined4 *)(puVar6 + 1);
      puVar7 = (undefined8 *)((int)puVar7 + 0xc);
    }
  }
  else {
    if (puVar6 != param_2) {
      do {
        *puVar7 = *puVar6;
        puVar9 = puVar6 + 1;
        puVar6 = (undefined8 *)((int)puVar6 + 0xc);
        *(undefined4 *)(puVar7 + 1) = *(undefined4 *)puVar9;
        puVar7 = (undefined8 *)((int)puVar7 + 0xc);
      } while (puVar6 != param_2);
      puVar9 = (undefined8 *)param_1[1];
    }
    if (param_2 != puVar9) {
      do {
        *(undefined8 *)((int)puVar5 + 0xc) = *param_2;
        puVar6 = param_2 + 1;
        param_2 = (undefined8 *)((int)param_2 + 0xc);
        *(undefined4 *)((int)puVar5 + 0x14) = *(undefined4 *)puVar6;
        puVar5 = (undefined8 *)((int)puVar5 + 0xc);
      } while (param_2 != puVar9);
    }
  }
  FUN_006bf950(puVar3,iVar1 + 1,uVar8);
  return *param_1 + iVar4;
}



/* FUNCTION 24225 ; VA 0x00b50590 ; FUN_00b50590 */

undefined4 * __thiscall
FUN_00b50590(undefined4 *param_1,undefined4 *param_2,char param_3,int *param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *puVar4;
  int *piVar5;
  bool bVar6;
  int *piVar7;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f3b10;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  bVar6 = true;
  piVar2 = (int *)*param_1;
  piVar7 = piVar2;
  if (*(char *)(piVar2[1] + 0xd) == '\0') {
    piVar5 = (int *)piVar2[1];
    do {
      piVar7 = piVar5;
      if (param_3 == '\0') {
        bVar6 = *param_4 < piVar7[4];
      }
      else {
        bVar6 = *param_4 <= piVar7[4];
      }
      if (bVar6 == false) {
        piVar5 = (int *)piVar7[2];
      }
      else {
        piVar5 = (int *)*piVar7;
      }
    } while (*(char *)((int)piVar5 + 0xd) == '\0');
  }
  piVar5 = piVar7;
  if (bVar6 != false) {
    if (piVar7 == (int *)*piVar2) {
      bVar6 = true;
      goto LAB_00b50619;
    }
    if (*(char *)((int)piVar7 + 0xd) == '\0') {
      piVar5 = (int *)*piVar7;
      if (*(char *)((int)piVar5 + 0xd) == '\0') {
        cVar1 = *(char *)(piVar5[2] + 0xd);
        piVar2 = (int *)piVar5[2];
        while (cVar1 == '\0') {
          cVar1 = *(char *)(piVar2[2] + 0xd);
          piVar5 = piVar2;
          piVar2 = (int *)piVar2[2];
        }
      }
      else {
        cVar1 = *(char *)(piVar7[1] + 0xd);
        piVar2 = (int *)piVar7[1];
        piVar5 = piVar7;
        while ((piVar3 = piVar2, cVar1 == '\0' && (piVar5 == (int *)*piVar3))) {
          cVar1 = *(char *)(piVar3[1] + 0xd);
          piVar2 = (int *)piVar3[1];
          piVar5 = piVar3;
        }
        if (*(char *)((int)piVar5 + 0xd) == '\0') {
          piVar5 = piVar3;
        }
      }
    }
    else {
      piVar5 = (int *)piVar7[2];
    }
  }
  if (*param_4 <= piVar5[4]) {
    *param_2 = piVar5;
    *(undefined *)(param_2 + 1) = 0;
    return param_2;
  }
LAB_00b50619:
  ExceptionList = &pvStack_10;
  puVar4 = (undefined4 *)FUN_00898100(&param_3,bVar6,piVar7,param_4,param_5);
  *param_2 = *puVar4;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24226 ; VA 0x00b506d0 ; Catch_All@00b506d0 */

void Catch_All_00b506d0(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24227 ; VA 0x00b506e0 ; FUN_00b506e0 */

undefined4 * __thiscall
FUN_00b506e0(undefined4 *param_1,undefined4 *param_2,char param_3,int *param_4,undefined4 param_5)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  int *piVar6;
  int *piVar7;
  bool bVar8;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f3b20;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  piVar2 = (int *)*param_1;
  bVar8 = true;
  piVar7 = piVar2;
  if (*(char *)(piVar2[1] + 0xd) == '\0') {
    iVar3 = *param_4;
    piVar6 = (int *)piVar2[1];
    do {
      piVar7 = piVar6;
      if (param_3 == '\0') {
        if ((piVar7[4] <= iVar3) && ((piVar7[4] < iVar3 || (piVar7[5] <= param_4[1])))) {
          bVar8 = false;
          goto LAB_00b50768;
        }
        bVar8 = true;
LAB_00b50772:
        piVar6 = (int *)*piVar7;
      }
      else {
        if ((piVar7[4] < iVar3) || ((piVar7[4] <= iVar3 && (piVar7[5] < param_4[1])))) {
          bVar8 = false;
        }
        else {
          bVar8 = true;
        }
        if (bVar8 != false) goto LAB_00b50772;
LAB_00b50768:
        piVar6 = (int *)piVar7[2];
      }
    } while (*(char *)((int)piVar6 + 0xd) == '\0');
  }
  piVar6 = piVar7;
  if (bVar8) {
    if (piVar7 == (int *)*piVar2) {
      bVar8 = true;
      goto LAB_00b50792;
    }
    if (*(char *)((int)piVar7 + 0xd) == '\0') {
      piVar6 = (int *)*piVar7;
      if (*(char *)((int)piVar6 + 0xd) == '\0') {
        cVar1 = *(char *)(piVar6[2] + 0xd);
        piVar2 = (int *)piVar6[2];
        while (cVar1 == '\0') {
          cVar1 = *(char *)(piVar2[2] + 0xd);
          piVar6 = piVar2;
          piVar2 = (int *)piVar2[2];
        }
      }
      else {
        cVar1 = *(char *)(piVar7[1] + 0xd);
        piVar2 = (int *)piVar7[1];
        piVar6 = piVar7;
        while ((piVar4 = piVar2, cVar1 == '\0' && (piVar6 == (int *)*piVar4))) {
          cVar1 = *(char *)(piVar4[1] + 0xd);
          piVar2 = (int *)piVar4[1];
          piVar6 = piVar4;
        }
        if (*(char *)((int)piVar6 + 0xd) == '\0') {
          piVar6 = piVar4;
        }
      }
    }
    else {
      piVar6 = (int *)piVar7[2];
    }
  }
  if ((*param_4 <= piVar6[4]) && ((*param_4 < piVar6[4] || (param_4[1] <= piVar6[5])))) {
    *param_2 = piVar6;
    *(undefined *)(param_2 + 1) = 0;
    return param_2;
  }
LAB_00b50792:
  ExceptionList = &pvStack_10;
  puVar5 = (undefined4 *)FUN_007267c0(&param_3,bVar8,piVar7,param_4,param_5);
  *param_2 = *puVar5;
  *(undefined *)(param_2 + 1) = 1;
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24228 ; VA 0x00b5085a ; Catch_All@00b5085a */

void Catch_All_00b5085a(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24229 ; VA 0x00b50870 ; FUN_00b50870 */

int __thiscall FUN_00b50870(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f3b30;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::NegateOperation*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24230 ; VA 0x00b50942 ; Catch_All@00b50942 */

void Catch_All_00b50942(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24231 ; VA 0x00b50960 ; FUN_00b50960 */

int __thiscall FUN_00b50960(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f3b40;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::PartOperation*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24232 ; VA 0x00b50a32 ; Catch_All@00b50a32 */

void Catch_All_00b50a32(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24233 ; VA 0x00b50a50 ; FUN_00b50a50 */

int __thiscall FUN_00b50a50(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f3b50;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  piVar4 = (int *)FUN_01674e20(0x10);
  if (piVar4 == (int *)0x0) {
    piVar4 = (int *)0x0;
  }
  else {
    piVar4[1] = 1;
    piVar4[2] = 1;
    *piVar4 = (int)std::
                   _Ref_count_resource<class_RBX::UnionOperation*,class_RBX::Creatable<class_RBX::Instance>::Deleter>
                   ::vftable;
    piVar4[3] = param_2;
  }
  *param_1 = param_2;
  param_1[1] = (int)piVar4;
  if ((param_2 != 0) && ((*(int *)(param_2 + 8) == 0 || (*(int *)(*(int *)(param_2 + 8) + 4) == 0)))
     ) {
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar4[1] = piVar4[1] + 1;
      UNLOCK();
      piVar4 = (int *)param_1[1];
      if (piVar4 != (int *)0x0) {
        LOCK();
        piVar4[2] = piVar4[2] + 1;
        UNLOCK();
      }
    }
    *(int *)(param_2 + 4) = param_2;
    piVar3 = *(int **)(param_2 + 8);
    *(int **)(param_2 + 8) = piVar4;
    if (piVar3 != (int *)0x0) {
      LOCK();
      piVar1 = piVar3 + 2;
      iVar2 = *piVar1;
      param_2 = *piVar1;
      *piVar1 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)(*piVar3 + 4))();
      }
    }
    if (piVar4 != (int *)0x0) {
      LOCK();
      piVar3 = piVar4 + 1;
      iVar2 = *piVar3;
      param_2 = *piVar3;
      *piVar3 = iVar2 + -1;
      UNLOCK();
      if (iVar2 + -1 == 0) {
        param_2 = (**(code **)*piVar4)();
        LOCK();
        piVar3 = piVar4 + 2;
        iVar2 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar2 == 1) {
          param_2 = (**(code **)(*piVar4 + 4))();
        }
      }
    }
  }
  ExceptionList = pvStack_10;
  return param_2;
}



/* FUNCTION 24234 ; VA 0x00b50b22 ; Catch_All@00b50b22 */

void Catch_All_00b50b22(void)

{
  int unaff_EBP;
  
  FUN_005703b0(*(undefined4 *)(unaff_EBP + 8));
                    /* WARNING: Subroutine does not return */
  FUN_0170c2a8(0,0);
}



/* FUNCTION 24235 ; VA 0x00b50b40 ; FUN_00b50b40 */

void FUN_00b50b40(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  if (param_1 != param_2) {
    do {
      uVar2 = param_1[1];
      uVar3 = param_1[2];
      uVar4 = param_1[3];
      *param_3 = *param_1;
      param_3[1] = uVar2;
      param_3[2] = uVar3;
      param_3[3] = uVar4;
      uVar2 = param_1[5];
      uVar3 = param_1[6];
      uVar4 = param_1[7];
      param_3[4] = param_1[4];
      param_3[5] = uVar2;
      param_3[6] = uVar3;
      param_3[7] = uVar4;
      uVar2 = param_1[9];
      uVar3 = param_1[10];
      uVar4 = param_1[0xb];
      param_3[8] = param_1[8];
      param_3[9] = uVar2;
      param_3[10] = uVar3;
      param_3[0xb] = uVar4;
      uVar2 = param_1[0xd];
      uVar3 = param_1[0xe];
      uVar4 = param_1[0xf];
      param_3[0xc] = param_1[0xc];
      param_3[0xd] = uVar2;
      param_3[0xe] = uVar3;
      param_3[0xf] = uVar4;
      uVar2 = param_1[0x11];
      uVar3 = param_1[0x12];
      uVar4 = param_1[0x13];
      param_3[0x10] = param_1[0x10];
      param_3[0x11] = uVar2;
      param_3[0x12] = uVar3;
      param_3[0x13] = uVar4;
      puVar1 = param_1 + 0x14;
      param_1 = param_1 + 0x15;
      param_3[0x14] = *puVar1;
      param_3 = param_3 + 0x15;
    } while (param_1 != param_2);
  }
  return;
}



/* FUNCTION 24236 ; VA 0x00b50b90 ; FUN_00b50b90 */

undefined4 * FUN_00b50b90(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f3bca;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b50140();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  uStack_18 = uVar2;
  puVar3 = (undefined4 *)FUN_01674e20(0x1c8);
  puStack_1c = puVar3;
  if (puVar3 == (undefined4 *)0x0) {
    puVar3 = (undefined4 *)0x0;
  }
  else {
    puVar3[0x15] = &DAT_01954044;
    puVar3[0x26] = &DAT_0195404c;
    puVar3[0x71] = RBX::IHasLocation::vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    uStack_14 = 2;
    FUN_00b51210(0);
    *puVar3 = RBX::DescribedCreatable<class_RBX::NegateOperation,class_RBX::PartOperation>::vftable;
    puVar3[0x16] = RBX::DescribedCreatable<class_RBX::NegateOperation,class_RBX::PartOperation>::
                   vftable;
    puVar3[0x1e] = RBX::DescribedCreatable<class_RBX::NegateOperation,class_RBX::PartOperation>::
                   vftable;
    puVar3[0x25] = RBX::DescribedCreatable<class_RBX::NegateOperation,class_RBX::PartOperation>::
                   vftable;
    uStack_8 = 5;
    *(undefined ***)(*(int *)(puVar3[0x15] + 4) + 0x54 + (int)puVar3) =
         RBX::DescribedCreatable<class_RBX::NegateOperation,class_RBX::PartOperation>::vftable;
    *(int *)(*(int *)(puVar3[0x15] + 4) + 0x50 + (int)puVar3) = *(int *)(puVar3[0x15] + 4) + -0x170;
    uVar4 = FUN_00b50140();
    puVar3[3] = uVar4;
    *puVar3 = RBX::NegateOperation::vftable;
    puVar3[0x16] = RBX::NegateOperation::vftable;
    puVar3[0x1e] = RBX::NegateOperation::vftable;
    puVar3[0x25] = RBX::NegateOperation::vftable;
    uStack_8 = 6;
    *(undefined ***)(*(int *)(puVar3[0x15] + 4) + 0x54 + (int)puVar3) =
         RBX::NegateOperation::vftable;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    *(int *)(*(int *)(puVar3[0x15] + 4) + 0x50 + (int)puVar3) = *(int *)(puVar3[0x15] + 4) + -0x170;
    FUN_005542c0("NegativePart",0xc);
    uStack_8._0_1_ = 7;
    FUN_00b0dd50(auStack_34);
    uStack_8 = CONCAT31(uStack_8._1_3_,6);
    if (0xf < uStack_20) {
      uVar6 = uStack_20 + 1;
      uVar5 = auStack_34[0];
      if (0xfff < uVar6) {
        uVar5 = *(uint *)(auStack_34[0] - 4);
        uVar6 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar5) - 4) {
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar5,uVar6);
    }
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    FUN_00b0ef80(0x3dcccccd);
    FUN_00b0ca50(1);
    FUN_00b0d450(0);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00b50870(puVar3,puStack_1c);
  uStack_14 = uStack_14 | 1;
  uStack_8 = 0xb;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24237 ; VA 0x00b50db0 ; FUN_00b50db0 */

undefined4 * FUN_00b50db0(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f3c13;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  ExceptionList = &pvStack_10;
  iVar1 = FUN_00b50240();
  uVar2 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar1 + 0x1dc) != (undefined4 *)0x0) {
    uVar2 = **(undefined4 **)(iVar1 + 0x1dc);
  }
  uVar2 = FUN_01675290(uVar2);
  uStack_8 = 1;
  iVar1 = FUN_01674e20(0x1c8);
  uStack_8._0_1_ = 2;
  if (iVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_00b51210(1);
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00b50960(uVar3,param_1);
  uStack_8 = 6;
  FUN_01675290(uVar2);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24238 ; VA 0x00b50e80 ; FUN_00b50e80 */

undefined4 * FUN_00b50e80(undefined4 *param_1)

{
  undefined uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  uint auStack_34 [4];
  undefined4 uStack_24;
  uint uStack_20;
  undefined4 *puStack_1c;
  undefined4 uStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  puStack_c = &LAB_017f3c8a;
  pvStack_10 = ExceptionList;
  uStack_8 = 0;
  uStack_14 = 0;
  ExceptionList = &pvStack_10;
  iVar2 = FUN_00b50340();
  uVar3 = DAT_01edf5b0;
  if (*(undefined4 **)(iVar2 + 0x1dc) != (undefined4 *)0x0) {
    uVar3 = **(undefined4 **)(iVar2 + 0x1dc);
  }
  uVar3 = FUN_01675290(uVar3);
  uStack_8._0_1_ = 1;
  uStack_8._1_3_ = 0;
  uStack_18 = uVar3;
  puVar4 = (undefined4 *)FUN_01674e20(0x1c8);
  puStack_1c = puVar4;
  if (puVar4 == (undefined4 *)0x0) {
    puVar4 = (undefined4 *)0x0;
  }
  else {
    puVar4[0x15] = &DAT_01953c8c;
    puVar4[0x26] = &DAT_01953c94;
    puVar4[0x71] = RBX::IHasLocation::vftable;
    uStack_8 = CONCAT31(uStack_8._1_3_,3);
    uStack_14 = 2;
    FUN_00b51210(0);
    *puVar4 = RBX::DescribedCreatable<class_RBX::UnionOperation,class_RBX::PartOperation>::vftable;
    puVar4[0x16] = RBX::DescribedCreatable<class_RBX::UnionOperation,class_RBX::PartOperation>::
                   vftable;
    puVar4[0x1e] = RBX::DescribedCreatable<class_RBX::UnionOperation,class_RBX::PartOperation>::
                   vftable;
    puVar4[0x25] = RBX::DescribedCreatable<class_RBX::UnionOperation,class_RBX::PartOperation>::
                   vftable;
    uStack_8 = 5;
    *(undefined ***)(*(int *)(puVar4[0x15] + 4) + 0x54 + (int)puVar4) =
         RBX::DescribedCreatable<class_RBX::UnionOperation,class_RBX::PartOperation>::vftable;
    *(int *)(*(int *)(puVar4[0x15] + 4) + 0x50 + (int)puVar4) = *(int *)(puVar4[0x15] + 4) + -0x170;
    uVar5 = FUN_00b50340();
    puVar4[3] = uVar5;
    *puVar4 = RBX::UnionOperation::vftable;
    puVar4[0x16] = RBX::UnionOperation::vftable;
    puVar4[0x1e] = RBX::UnionOperation::vftable;
    puVar4[0x25] = RBX::UnionOperation::vftable;
    uStack_8 = 6;
    *(undefined ***)(*(int *)(puVar4[0x15] + 4) + 0x54 + (int)puVar4) = RBX::UnionOperation::vftable
    ;
    uStack_24 = 0;
    uStack_20 = 0xf;
    auStack_34[0] = auStack_34[0] & 0xffffff00;
    *(int *)(*(int *)(puVar4[0x15] + 4) + 0x50 + (int)puVar4) = *(int *)(puVar4[0x15] + 4) + -0x170;
    FUN_005542c0("Union",5);
    uStack_8._0_1_ = 7;
    FUN_00b0dd50(auStack_34);
    uStack_8._0_1_ = 6;
    uVar1 = (undefined)uStack_8;
    uStack_8._0_1_ = 6;
    if (0xf < uStack_20) {
      uVar7 = uStack_20 + 1;
      uVar6 = auStack_34[0];
      if (0xfff < uVar7) {
        uVar6 = *(uint *)(auStack_34[0] - 4);
        uVar7 = uStack_20 + 0x24;
        if (0x1f < (auStack_34[0] - uVar6) - 4) {
          uStack_8._0_1_ = uVar1;
                    /* WARNING: Subroutine does not return */
          FUN_017167a3();
        }
      }
      FUN_01674ea0(uVar6,uVar7);
    }
  }
  uStack_8 = CONCAT31(uStack_8._1_3_,1);
  *param_1 = 0;
  param_1[1] = 0;
  FUN_00b50a50(puVar4,puStack_1c);
  uStack_14 = uStack_14 | 1;
  uStack_8 = 0xb;
  FUN_01675290(uVar3);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24239 ; VA 0x00b51060 ; FUN_00b51060 */

undefined4 FUN_00b51060(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x34);
    if ((iVar1 != 0) && (param_1 = iVar1, *(int *)(iVar1 + 0x34) != 0)) {
      param_1 = FUN_005c8ac0();
    }
    if ((param_1 != 0) &&
       (iVar1 = *(int *)(param_1 + 0xc), iVar2 = FUN_008a8c30(),
       (uint)*(ushort *)(iVar1 + 0x1d8) - (uint)*(ushort *)(iVar2 + 0x1d8) <=
       (uint)*(ushort *)(iVar2 + 0x1da))) {
      puVar3 = (undefined4 *)FUN_00563f20();
      return *puVar3;
    }
  }
  return 0;
}



/* FUNCTION 24240 ; VA 0x00b510c0 ; FUN_00b510c0 */

uint * __thiscall FUN_00b510c0(uint *param_1,int *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  uint uVar9;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  uVar9 = (param_2[1] - *param_2) / 0x54;
  if (uVar9 != 0) {
    if (0x30c30c3 < uVar9) {
                    /* WARNING: Subroutine does not return */
      FUN_00577c30();
    }
    uVar9 = uVar9 * 0x54;
    if (uVar9 < 0x1000) {
      if (uVar9 == 0) {
        uVar5 = 0;
      }
      else {
        uVar5 = FUN_01674e20(uVar9);
      }
    }
    else {
      uVar5 = uVar9 + 0x23;
      if (uVar5 <= uVar9) {
        uVar5 = 0xffffffff;
      }
      iVar6 = FUN_01674e20(uVar5);
      if (iVar6 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
      uVar5 = iVar6 + 0x23U & 0xffffffe0;
      *(int *)(uVar5 - 4) = iVar6;
    }
    *param_1 = uVar5;
    param_1[1] = uVar5;
    param_1[2] = *param_1 + uVar9;
    puVar1 = (undefined4 *)param_2[1];
    puVar8 = (undefined4 *)*param_1;
    for (puVar7 = (undefined4 *)*param_2; puVar7 != puVar1; puVar7 = puVar7 + 0x15) {
      uVar2 = puVar7[1];
      uVar3 = puVar7[2];
      uVar4 = puVar7[3];
      *puVar8 = *puVar7;
      puVar8[1] = uVar2;
      puVar8[2] = uVar3;
      puVar8[3] = uVar4;
      uVar2 = puVar7[5];
      uVar3 = puVar7[6];
      uVar4 = puVar7[7];
      puVar8[4] = puVar7[4];
      puVar8[5] = uVar2;
      puVar8[6] = uVar3;
      puVar8[7] = uVar4;
      uVar2 = puVar7[9];
      uVar3 = puVar7[10];
      uVar4 = puVar7[0xb];
      puVar8[8] = puVar7[8];
      puVar8[9] = uVar2;
      puVar8[10] = uVar3;
      puVar8[0xb] = uVar4;
      uVar2 = puVar7[0xd];
      uVar3 = puVar7[0xe];
      uVar4 = puVar7[0xf];
      puVar8[0xc] = puVar7[0xc];
      puVar8[0xd] = uVar2;
      puVar8[0xe] = uVar3;
      puVar8[0xf] = uVar4;
      uVar2 = puVar7[0x11];
      uVar3 = puVar7[0x12];
      uVar4 = puVar7[0x13];
      puVar8[0x10] = puVar7[0x10];
      puVar8[0x11] = uVar2;
      puVar8[0x12] = uVar3;
      puVar8[0x13] = uVar4;
      puVar8[0x14] = puVar7[0x14];
      puVar8 = puVar8 + 0x15;
    }
    param_1[1] = (uint)puVar8;
  }
  return param_1;
}



/* FUNCTION 24241 ; VA 0x00b511b0 ; FUN_00b511b0 */

undefined4 * __thiscall FUN_00b511b0(undefined4 *param_1,int param_2,undefined8 *param_3)

{
  char cVar1;
  undefined8 *puVar2;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  cVar1 = FUN_00b51cc0(param_2);
  if (cVar1 != '\0') {
    puVar2 = (undefined8 *)*param_1;
    if (param_2 != 0) {
      do {
        *puVar2 = *param_3;
        *(undefined4 *)(puVar2 + 1) = *(undefined4 *)(param_3 + 1);
        puVar2 = (undefined8 *)((int)puVar2 + 0xc);
        param_2 = param_2 + -1;
      } while (param_2 != 0);
    }
    param_1[1] = puVar2;
  }
  return param_1;
}



/* FUNCTION 24242 ; VA 0x00b51210 ; FUN_00b51210 */

undefined4 * __thiscall FUN_00b51210(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint auStack_30 [3];
  undefined4 uStack_24;
  undefined4 uStack_20;
  uint uStack_1c;
  undefined4 *puStack_18;
  uint uStack_14;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_017f3d2b;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  if (param_2 != 0) {
    ExceptionList = &pvStack_10;
    param_1[0x15] = &DAT_019538d4;
    param_1[0x26] = &DAT_019538dc;
    param_1[0x71] = RBX::IHasLocation::vftable;
    uStack_8 = 0;
  }
  uStack_14 = (uint)(param_2 != 0);
  puStack_18 = param_1;
  FUN_00b4d580(0);
  *param_1 = RBX::DescribedCreatable<class_RBX::PartOperation,class_RBX::TriangleMeshPart>::vftable;
  param_1[0x16] =
       RBX::DescribedCreatable<class_RBX::PartOperation,class_RBX::TriangleMeshPart>::vftable;
  param_1[0x1e] =
       RBX::DescribedCreatable<class_RBX::PartOperation,class_RBX::TriangleMeshPart>::vftable;
  param_1[0x25] =
       RBX::DescribedCreatable<class_RBX::PartOperation,class_RBX::TriangleMeshPart>::vftable;
  uStack_8 = 1;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) =
       RBX::DescribedCreatable<class_RBX::PartOperation,class_RBX::TriangleMeshPart>::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0x100
  ;
  uVar1 = FUN_00b50240();
  param_1[3] = uVar1;
  *param_1 = RBX::PartOperation::vftable;
  param_1[0x16] = RBX::PartOperation::vftable;
  param_1[0x1e] = RBX::PartOperation::vftable;
  param_1[0x25] = RBX::PartOperation::vftable;
  *(undefined ***)(*(int *)(param_1[0x15] + 4) + 0x54 + (int)param_1) = RBX::PartOperation::vftable;
  *(int *)(*(int *)(param_1[0x15] + 4) + 0x50 + (int)param_1) = *(int *)(param_1[0x15] + 4) + -0x170
  ;
  param_1[0x58] = 0;
  param_1[0x59] = 0xf;
  *(undefined *)(param_1 + 0x54) = 0;
  param_1[0x5e] = 0;
  param_1[0x5f] = 0xf;
  *(undefined *)(param_1 + 0x5a) = 0;
  uStack_8._0_1_ = 4;
  uStack_8._1_3_ = 0;
  FUN_00a33c70();
  uStack_8._0_1_ = 5;
  FUN_00a33c70();
  param_1[0x62] = 1;
  *(undefined *)(param_1 + 99) = 0;
  param_1[100] = 0;
  param_1[0x65] = 0;
  *(undefined *)(param_1 + 0x66) = 0;
  *(undefined *)(param_1 + 0x68) = 0;
  param_1[0x6d] = 0;
  param_1[0x6e] = 0xf;
  *(undefined *)(param_1 + 0x69) = 0;
  uStack_8._0_1_ = 8;
  uStack_20 = 0;
  uStack_1c = 0xf;
  auStack_30[0] = auStack_30[0] & 0xffffff00;
  FUN_005542c0("PartOperation",0xd);
  uStack_8._0_1_ = 9;
  FUN_00b0dd50(auStack_30);
  uStack_8 = CONCAT31(uStack_8._1_3_,8);
  if (0xf < uStack_1c) {
    uVar3 = uStack_1c + 1;
    uVar2 = auStack_30[0];
    if (0xfff < uVar3) {
      uVar2 = *(uint *)(auStack_30[0] - 4);
      uVar3 = uStack_1c + 0x24;
      if (0x1f < (auStack_30[0] - uVar2) - 4) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(uVar2,uVar3);
  }
  *(ulonglong *)(param_1 + 0x45) = CONCAT44(DAT_018ce2f8,DAT_018ce2f8);
  param_1[0x47] = 0x3f800000;
  uStack_24 = 0x3f800000;
  uStack_20 = 0x3f800000;
  uStack_1c = 0x3f800000;
  FUN_00b0d620(&uStack_24);
  FUN_00b0ee60(1,0);
  FUN_00b0ee60(4,0);
  param_1[0x67] = 3;
  FUN_00c18400(0xb);
  ExceptionList = pvStack_10;
  return param_1;
}



/* FUNCTION 24243 ; VA 0x00b514a0 ; FUN_00b514a0 */

void __fastcall FUN_00b514a0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::NegateOperation>::vftable;
  uVar1 = FUN_00b50140(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24244 ; VA 0x00b514e0 ; FUN_00b514e0 */

void __fastcall FUN_00b514e0(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::PartOperation>::vftable;
  uVar1 = FUN_00b50240(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24245 ; VA 0x00b51520 ; FUN_00b51520 */

void __fastcall FUN_00b51520(undefined4 *param_1)

{
  undefined4 uVar1;
  void *pvStack_10;
  undefined *puStack_c;
  undefined4 uStack_8;
  
  uStack_8 = 0xffffffff;
  puStack_c = &LAB_01791fe0;
  pvStack_10 = ExceptionList;
  ExceptionList = &pvStack_10;
  *param_1 = RBX::Creator<class_RBX::UnionOperation>::vftable;
  uVar1 = FUN_00b50340(0);
  FUN_00893bd0(uVar1);
  ExceptionList = pvStack_10;
  return;
}



/* FUNCTION 24246 ; VA 0x00b51560 ; thunk_FUN_00b51590 */

void __fastcall thunk_FUN_00b51590(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x1b8);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x1a4);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_00b516db;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x1b4) = 0;
  *(undefined4 *)(param_1 + 0x1b8) = 0xf;
  *(undefined *)(param_1 + 0x1a4) = 0;
  piVar4 = *(int **)(param_1 + 0x194);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_0056cd30();
  FUN_0056cd30();
  uVar2 = *(uint *)(param_1 + 0x17c);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x168);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_00b516db;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x178) = 0;
  *(undefined4 *)(param_1 + 0x17c) = 0xf;
  *(undefined *)(param_1 + 0x168) = 0;
  uVar2 = *(uint *)(param_1 + 0x164);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x150);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
LAB_00b516db:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x160) = 0;
  *(undefined4 *)(param_1 + 0x164) = 0xf;
  *(undefined *)(param_1 + 0x150) = 0;
  FUN_00b4d790();
  return;
}



/* FUNCTION 24247 ; VA 0x00b51570 ; thunk_FUN_00b4d790 */

void __fastcall thunk_FUN_00b4d790(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  
  uVar1 = *(uint *)(param_1 + 0x134);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0x120);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) goto LAB_00b4d84c;
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x130) = 0;
  *(undefined4 *)(param_1 + 0x134) = 0xf;
  *(undefined *)(param_1 + 0x120) = 0;
  FUN_0056cd30();
  uVar1 = *(uint *)(param_1 + 0x10c);
  if (0xf < uVar1) {
    iVar2 = *(int *)(param_1 + 0xf8);
    uVar4 = uVar1 + 1;
    iVar3 = iVar2;
    if (0xfff < uVar4) {
      iVar3 = *(int *)(iVar2 + -4);
      uVar4 = uVar1 + 0x24;
      if (0x1f < (iVar2 - iVar3) - 4U) {
LAB_00b4d84c:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar4);
  }
  *(undefined4 *)(param_1 + 0x108) = 0;
  *(undefined4 *)(param_1 + 0x10c) = 0xf;
  *(undefined *)(param_1 + 0xf8) = 0;
  FUN_00b013e0();
  return;
}



/* FUNCTION 24248 ; VA 0x00b51580 ; thunk_FUN_00b51d80 */

void __fastcall thunk_FUN_00b51d80(int *param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  iVar1 = *param_1;
  if (iVar1 != 0) {
    uVar2 = ((param_1[2] - iVar1) / 0x54) * 0x54;
    iVar3 = iVar1;
    if (0xfff < uVar2) {
      iVar3 = *(int *)(iVar1 + -4);
      uVar2 = uVar2 + 0x23;
      if (0x1f < (iVar1 - iVar3) - 4U) {
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar3,uVar2);
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}



/* FUNCTION 24249 ; VA 0x00b51590 ; FUN_00b51590 */

void __fastcall FUN_00b51590(int param_1)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  
  uVar2 = *(uint *)(param_1 + 0x1b8);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x1a4);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_00b516db;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x1b4) = 0;
  *(undefined4 *)(param_1 + 0x1b8) = 0xf;
  *(undefined *)(param_1 + 0x1a4) = 0;
  piVar4 = *(int **)(param_1 + 0x194);
  if (piVar4 != (int *)0x0) {
    LOCK();
    iVar3 = piVar4[1] + -1;
    piVar4[1] = iVar3;
    UNLOCK();
    if (iVar3 == 0) {
      (**(code **)*piVar4)();
      LOCK();
      piVar1 = piVar4 + 2;
      iVar3 = *piVar1;
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (iVar3 == 1) {
        (**(code **)(*piVar4 + 4))();
      }
    }
  }
  FUN_0056cd30();
  FUN_0056cd30();
  uVar2 = *(uint *)(param_1 + 0x17c);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x168);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) goto LAB_00b516db;
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x178) = 0;
  *(undefined4 *)(param_1 + 0x17c) = 0xf;
  *(undefined *)(param_1 + 0x168) = 0;
  uVar2 = *(uint *)(param_1 + 0x164);
  if (0xf < uVar2) {
    iVar3 = *(int *)(param_1 + 0x150);
    uVar6 = uVar2 + 1;
    iVar5 = iVar3;
    if (0xfff < uVar6) {
      iVar5 = *(int *)(iVar3 + -4);
      uVar6 = uVar2 + 0x24;
      if (0x1f < (iVar3 - iVar5) - 4U) {
LAB_00b516db:
                    /* WARNING: Subroutine does not return */
        FUN_017167a3();
      }
    }
    FUN_01674ea0(iVar5,uVar6);
  }
  *(undefined4 *)(param_1 + 0x160) = 0;
  *(undefined4 *)(param_1 + 0x164) = 0xf;
  *(undefined *)(param_1 + 0x150) = 0;
  FUN_00b4d790();
  return;
}


